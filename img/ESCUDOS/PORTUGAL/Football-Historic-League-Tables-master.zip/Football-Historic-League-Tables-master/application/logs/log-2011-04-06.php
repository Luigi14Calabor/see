<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2011-04-06 00:10:37 --> Config Class Initialized
DEBUG - 2011-04-06 00:10:37 --> Hooks Class Initialized
DEBUG - 2011-04-06 00:10:37 --> Utf8 Class Initialized
DEBUG - 2011-04-06 00:10:37 --> UTF-8 Support Enabled
DEBUG - 2011-04-06 00:10:37 --> URI Class Initialized
DEBUG - 2011-04-06 00:10:37 --> Router Class Initialized
DEBUG - 2011-04-06 00:10:37 --> Output Class Initialized
DEBUG - 2011-04-06 00:10:37 --> Input Class Initialized
DEBUG - 2011-04-06 00:10:37 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-06 00:10:37 --> Language Class Initialized
DEBUG - 2011-04-06 00:10:37 --> Loader Class Initialized
DEBUG - 2011-04-06 00:10:37 --> Controller Class Initialized
ERROR - 2011-04-06 00:10:37 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-06 00:10:37 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-06 00:10:37 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-06 00:10:37 --> Model Class Initialized
DEBUG - 2011-04-06 00:10:37 --> Model Class Initialized
DEBUG - 2011-04-06 00:10:37 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-06 00:10:37 --> Database Driver Class Initialized
DEBUG - 2011-04-06 00:10:37 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-06 00:10:37 --> Helper loaded: url_helper
DEBUG - 2011-04-06 00:10:37 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-06 00:10:37 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-06 00:10:37 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-06 00:10:37 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-06 00:10:37 --> Final output sent to browser
DEBUG - 2011-04-06 00:10:37 --> Total execution time: 0.2826
DEBUG - 2011-04-06 00:30:52 --> Config Class Initialized
DEBUG - 2011-04-06 00:30:52 --> Hooks Class Initialized
DEBUG - 2011-04-06 00:30:52 --> Utf8 Class Initialized
DEBUG - 2011-04-06 00:30:52 --> UTF-8 Support Enabled
DEBUG - 2011-04-06 00:30:52 --> URI Class Initialized
DEBUG - 2011-04-06 00:30:52 --> Router Class Initialized
DEBUG - 2011-04-06 00:30:52 --> Output Class Initialized
DEBUG - 2011-04-06 00:30:52 --> Input Class Initialized
DEBUG - 2011-04-06 00:30:52 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-06 00:30:52 --> Language Class Initialized
DEBUG - 2011-04-06 00:30:52 --> Loader Class Initialized
DEBUG - 2011-04-06 00:30:52 --> Controller Class Initialized
ERROR - 2011-04-06 00:30:52 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-06 00:30:52 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-06 00:30:52 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-06 00:30:52 --> Model Class Initialized
DEBUG - 2011-04-06 00:30:52 --> Model Class Initialized
DEBUG - 2011-04-06 00:30:52 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-06 00:30:52 --> Database Driver Class Initialized
DEBUG - 2011-04-06 00:30:52 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-06 00:30:52 --> Helper loaded: url_helper
DEBUG - 2011-04-06 00:30:52 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-06 00:30:52 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-06 00:30:52 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-06 00:30:52 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-06 00:30:52 --> Final output sent to browser
DEBUG - 2011-04-06 00:30:52 --> Total execution time: 0.2240
DEBUG - 2011-04-06 00:30:53 --> Config Class Initialized
DEBUG - 2011-04-06 00:30:53 --> Hooks Class Initialized
DEBUG - 2011-04-06 00:30:53 --> Utf8 Class Initialized
DEBUG - 2011-04-06 00:30:53 --> UTF-8 Support Enabled
DEBUG - 2011-04-06 00:30:53 --> URI Class Initialized
DEBUG - 2011-04-06 00:30:53 --> Router Class Initialized
DEBUG - 2011-04-06 00:30:53 --> Output Class Initialized
DEBUG - 2011-04-06 00:30:53 --> Input Class Initialized
DEBUG - 2011-04-06 00:30:53 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-06 00:30:53 --> Language Class Initialized
DEBUG - 2011-04-06 00:30:53 --> Loader Class Initialized
DEBUG - 2011-04-06 00:30:53 --> Controller Class Initialized
DEBUG - 2011-04-06 00:30:53 --> Model Class Initialized
DEBUG - 2011-04-06 00:30:53 --> Model Class Initialized
DEBUG - 2011-04-06 00:30:53 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-06 00:30:53 --> Database Driver Class Initialized
DEBUG - 2011-04-06 00:30:54 --> Final output sent to browser
DEBUG - 2011-04-06 00:30:54 --> Total execution time: 0.7802
DEBUG - 2011-04-06 00:30:54 --> Config Class Initialized
DEBUG - 2011-04-06 00:30:54 --> Hooks Class Initialized
DEBUG - 2011-04-06 00:30:54 --> Utf8 Class Initialized
DEBUG - 2011-04-06 00:30:54 --> UTF-8 Support Enabled
DEBUG - 2011-04-06 00:30:54 --> URI Class Initialized
DEBUG - 2011-04-06 00:30:54 --> Router Class Initialized
ERROR - 2011-04-06 00:30:54 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-06 00:31:02 --> Config Class Initialized
DEBUG - 2011-04-06 00:31:02 --> Hooks Class Initialized
DEBUG - 2011-04-06 00:31:02 --> Utf8 Class Initialized
DEBUG - 2011-04-06 00:31:02 --> UTF-8 Support Enabled
DEBUG - 2011-04-06 00:31:02 --> URI Class Initialized
DEBUG - 2011-04-06 00:31:02 --> Router Class Initialized
DEBUG - 2011-04-06 00:31:02 --> Output Class Initialized
DEBUG - 2011-04-06 00:31:02 --> Input Class Initialized
DEBUG - 2011-04-06 00:31:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-06 00:31:02 --> Language Class Initialized
DEBUG - 2011-04-06 00:31:02 --> Loader Class Initialized
DEBUG - 2011-04-06 00:31:02 --> Controller Class Initialized
ERROR - 2011-04-06 00:31:02 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-06 00:31:03 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-06 00:31:03 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-06 00:31:03 --> Model Class Initialized
DEBUG - 2011-04-06 00:31:03 --> Model Class Initialized
DEBUG - 2011-04-06 00:31:03 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-06 00:31:03 --> Database Driver Class Initialized
DEBUG - 2011-04-06 00:31:03 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-06 00:31:03 --> Helper loaded: url_helper
DEBUG - 2011-04-06 00:31:03 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-06 00:31:03 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-06 00:31:03 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-06 00:31:03 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-06 00:31:03 --> Final output sent to browser
DEBUG - 2011-04-06 00:31:03 --> Total execution time: 0.0287
DEBUG - 2011-04-06 00:31:03 --> Config Class Initialized
DEBUG - 2011-04-06 00:31:03 --> Hooks Class Initialized
DEBUG - 2011-04-06 00:31:03 --> Utf8 Class Initialized
DEBUG - 2011-04-06 00:31:03 --> UTF-8 Support Enabled
DEBUG - 2011-04-06 00:31:03 --> URI Class Initialized
DEBUG - 2011-04-06 00:31:03 --> Router Class Initialized
DEBUG - 2011-04-06 00:31:03 --> Output Class Initialized
DEBUG - 2011-04-06 00:31:03 --> Input Class Initialized
DEBUG - 2011-04-06 00:31:03 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-06 00:31:03 --> Language Class Initialized
DEBUG - 2011-04-06 00:31:03 --> Loader Class Initialized
DEBUG - 2011-04-06 00:31:03 --> Controller Class Initialized
DEBUG - 2011-04-06 00:31:03 --> Model Class Initialized
DEBUG - 2011-04-06 00:31:03 --> Model Class Initialized
DEBUG - 2011-04-06 00:31:03 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-06 00:31:03 --> Database Driver Class Initialized
DEBUG - 2011-04-06 00:31:04 --> Final output sent to browser
DEBUG - 2011-04-06 00:31:04 --> Total execution time: 0.6411
DEBUG - 2011-04-06 00:31:12 --> Config Class Initialized
DEBUG - 2011-04-06 00:31:12 --> Hooks Class Initialized
DEBUG - 2011-04-06 00:31:12 --> Utf8 Class Initialized
DEBUG - 2011-04-06 00:31:12 --> UTF-8 Support Enabled
DEBUG - 2011-04-06 00:31:12 --> URI Class Initialized
DEBUG - 2011-04-06 00:31:12 --> Router Class Initialized
DEBUG - 2011-04-06 00:31:12 --> Output Class Initialized
DEBUG - 2011-04-06 00:31:12 --> Input Class Initialized
DEBUG - 2011-04-06 00:31:12 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-06 00:31:12 --> Language Class Initialized
DEBUG - 2011-04-06 00:31:12 --> Loader Class Initialized
DEBUG - 2011-04-06 00:31:12 --> Controller Class Initialized
ERROR - 2011-04-06 00:31:12 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-06 00:31:12 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-06 00:31:12 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-06 00:31:12 --> Model Class Initialized
DEBUG - 2011-04-06 00:31:12 --> Model Class Initialized
DEBUG - 2011-04-06 00:31:12 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-06 00:31:12 --> Database Driver Class Initialized
DEBUG - 2011-04-06 00:31:12 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-06 00:31:12 --> Helper loaded: url_helper
DEBUG - 2011-04-06 00:31:12 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-06 00:31:12 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-06 00:31:12 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-06 00:31:12 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-06 00:31:12 --> Final output sent to browser
DEBUG - 2011-04-06 00:31:12 --> Total execution time: 0.0284
DEBUG - 2011-04-06 00:31:13 --> Config Class Initialized
DEBUG - 2011-04-06 00:31:13 --> Hooks Class Initialized
DEBUG - 2011-04-06 00:31:13 --> Utf8 Class Initialized
DEBUG - 2011-04-06 00:31:13 --> UTF-8 Support Enabled
DEBUG - 2011-04-06 00:31:13 --> URI Class Initialized
DEBUG - 2011-04-06 00:31:13 --> Router Class Initialized
DEBUG - 2011-04-06 00:31:13 --> Output Class Initialized
DEBUG - 2011-04-06 00:31:13 --> Input Class Initialized
DEBUG - 2011-04-06 00:31:13 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-06 00:31:13 --> Language Class Initialized
DEBUG - 2011-04-06 00:31:13 --> Loader Class Initialized
DEBUG - 2011-04-06 00:31:13 --> Controller Class Initialized
DEBUG - 2011-04-06 00:31:13 --> Model Class Initialized
DEBUG - 2011-04-06 00:31:13 --> Model Class Initialized
DEBUG - 2011-04-06 00:31:13 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-06 00:31:13 --> Database Driver Class Initialized
DEBUG - 2011-04-06 00:31:14 --> Final output sent to browser
DEBUG - 2011-04-06 00:31:14 --> Total execution time: 0.7021
DEBUG - 2011-04-06 00:31:21 --> Config Class Initialized
DEBUG - 2011-04-06 00:31:21 --> Hooks Class Initialized
DEBUG - 2011-04-06 00:31:21 --> Utf8 Class Initialized
DEBUG - 2011-04-06 00:31:21 --> UTF-8 Support Enabled
DEBUG - 2011-04-06 00:31:21 --> URI Class Initialized
DEBUG - 2011-04-06 00:31:21 --> Router Class Initialized
DEBUG - 2011-04-06 00:31:21 --> Output Class Initialized
DEBUG - 2011-04-06 00:31:21 --> Input Class Initialized
DEBUG - 2011-04-06 00:31:21 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-06 00:31:21 --> Language Class Initialized
DEBUG - 2011-04-06 00:31:21 --> Loader Class Initialized
DEBUG - 2011-04-06 00:31:21 --> Controller Class Initialized
ERROR - 2011-04-06 00:31:21 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-06 00:31:21 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-06 00:31:21 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-06 00:31:21 --> Model Class Initialized
DEBUG - 2011-04-06 00:31:21 --> Model Class Initialized
DEBUG - 2011-04-06 00:31:21 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-06 00:31:21 --> Database Driver Class Initialized
DEBUG - 2011-04-06 00:31:21 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-06 00:31:21 --> Helper loaded: url_helper
DEBUG - 2011-04-06 00:31:21 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-06 00:31:21 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-06 00:31:21 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-06 00:31:21 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-06 00:31:21 --> Final output sent to browser
DEBUG - 2011-04-06 00:31:21 --> Total execution time: 0.0293
DEBUG - 2011-04-06 00:31:23 --> Config Class Initialized
DEBUG - 2011-04-06 00:31:23 --> Hooks Class Initialized
DEBUG - 2011-04-06 00:31:23 --> Utf8 Class Initialized
DEBUG - 2011-04-06 00:31:23 --> UTF-8 Support Enabled
DEBUG - 2011-04-06 00:31:23 --> URI Class Initialized
DEBUG - 2011-04-06 00:31:23 --> Router Class Initialized
DEBUG - 2011-04-06 00:31:23 --> Output Class Initialized
DEBUG - 2011-04-06 00:31:23 --> Input Class Initialized
DEBUG - 2011-04-06 00:31:23 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-06 00:31:23 --> Language Class Initialized
DEBUG - 2011-04-06 00:31:23 --> Loader Class Initialized
DEBUG - 2011-04-06 00:31:23 --> Controller Class Initialized
DEBUG - 2011-04-06 00:31:23 --> Model Class Initialized
DEBUG - 2011-04-06 00:31:23 --> Model Class Initialized
DEBUG - 2011-04-06 00:31:23 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-06 00:31:23 --> Database Driver Class Initialized
DEBUG - 2011-04-06 00:31:23 --> Final output sent to browser
DEBUG - 2011-04-06 00:31:23 --> Total execution time: 0.7039
DEBUG - 2011-04-06 01:02:50 --> Config Class Initialized
DEBUG - 2011-04-06 01:02:51 --> Hooks Class Initialized
DEBUG - 2011-04-06 01:02:51 --> Utf8 Class Initialized
DEBUG - 2011-04-06 01:02:51 --> UTF-8 Support Enabled
DEBUG - 2011-04-06 01:02:51 --> URI Class Initialized
DEBUG - 2011-04-06 01:02:51 --> Router Class Initialized
DEBUG - 2011-04-06 01:02:51 --> No URI present. Default controller set.
DEBUG - 2011-04-06 01:02:51 --> Output Class Initialized
DEBUG - 2011-04-06 01:02:51 --> Input Class Initialized
DEBUG - 2011-04-06 01:02:51 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-06 01:02:51 --> Language Class Initialized
DEBUG - 2011-04-06 01:02:51 --> Loader Class Initialized
DEBUG - 2011-04-06 01:02:51 --> Controller Class Initialized
DEBUG - 2011-04-06 01:02:51 --> File loaded: application/views/splash/main.php
DEBUG - 2011-04-06 01:02:51 --> Helper loaded: url_helper
DEBUG - 2011-04-06 01:02:51 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-06 01:02:51 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-06 01:02:51 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-06 01:02:51 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-06 01:02:51 --> Final output sent to browser
DEBUG - 2011-04-06 01:02:51 --> Total execution time: 0.1837
DEBUG - 2011-04-06 01:05:42 --> Config Class Initialized
DEBUG - 2011-04-06 01:05:42 --> Hooks Class Initialized
DEBUG - 2011-04-06 01:05:42 --> Utf8 Class Initialized
DEBUG - 2011-04-06 01:05:42 --> UTF-8 Support Enabled
DEBUG - 2011-04-06 01:05:42 --> URI Class Initialized
DEBUG - 2011-04-06 01:05:42 --> Router Class Initialized
DEBUG - 2011-04-06 01:05:42 --> Output Class Initialized
DEBUG - 2011-04-06 01:05:42 --> Input Class Initialized
DEBUG - 2011-04-06 01:05:42 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-06 01:05:42 --> Language Class Initialized
DEBUG - 2011-04-06 01:05:42 --> Loader Class Initialized
DEBUG - 2011-04-06 01:05:42 --> Controller Class Initialized
ERROR - 2011-04-06 01:05:42 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-06 01:05:42 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-06 01:05:42 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-06 01:05:42 --> Model Class Initialized
DEBUG - 2011-04-06 01:05:42 --> Model Class Initialized
DEBUG - 2011-04-06 01:05:42 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-06 01:05:42 --> Database Driver Class Initialized
DEBUG - 2011-04-06 01:05:42 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-06 01:05:42 --> Helper loaded: url_helper
DEBUG - 2011-04-06 01:05:42 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-06 01:05:42 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-06 01:05:42 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-06 01:05:42 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-06 01:05:42 --> Final output sent to browser
DEBUG - 2011-04-06 01:05:42 --> Total execution time: 0.2198
DEBUG - 2011-04-06 01:05:43 --> Config Class Initialized
DEBUG - 2011-04-06 01:05:43 --> Hooks Class Initialized
DEBUG - 2011-04-06 01:05:43 --> Utf8 Class Initialized
DEBUG - 2011-04-06 01:05:43 --> UTF-8 Support Enabled
DEBUG - 2011-04-06 01:05:43 --> URI Class Initialized
DEBUG - 2011-04-06 01:05:43 --> Router Class Initialized
DEBUG - 2011-04-06 01:05:43 --> Output Class Initialized
DEBUG - 2011-04-06 01:05:43 --> Input Class Initialized
DEBUG - 2011-04-06 01:05:43 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-06 01:05:43 --> Language Class Initialized
DEBUG - 2011-04-06 01:05:43 --> Loader Class Initialized
DEBUG - 2011-04-06 01:05:43 --> Controller Class Initialized
DEBUG - 2011-04-06 01:05:43 --> Model Class Initialized
DEBUG - 2011-04-06 01:05:43 --> Model Class Initialized
DEBUG - 2011-04-06 01:05:43 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-06 01:05:43 --> Database Driver Class Initialized
DEBUG - 2011-04-06 01:05:44 --> Final output sent to browser
DEBUG - 2011-04-06 01:05:44 --> Total execution time: 0.7251
DEBUG - 2011-04-06 01:05:46 --> Config Class Initialized
DEBUG - 2011-04-06 01:05:46 --> Hooks Class Initialized
DEBUG - 2011-04-06 01:05:46 --> Utf8 Class Initialized
DEBUG - 2011-04-06 01:05:46 --> UTF-8 Support Enabled
DEBUG - 2011-04-06 01:05:46 --> URI Class Initialized
DEBUG - 2011-04-06 01:05:46 --> Router Class Initialized
ERROR - 2011-04-06 01:05:46 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-06 01:05:46 --> Config Class Initialized
DEBUG - 2011-04-06 01:05:46 --> Hooks Class Initialized
DEBUG - 2011-04-06 01:05:46 --> Utf8 Class Initialized
DEBUG - 2011-04-06 01:05:46 --> UTF-8 Support Enabled
DEBUG - 2011-04-06 01:05:46 --> URI Class Initialized
DEBUG - 2011-04-06 01:05:46 --> Router Class Initialized
ERROR - 2011-04-06 01:05:46 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-06 01:06:42 --> Config Class Initialized
DEBUG - 2011-04-06 01:06:42 --> Hooks Class Initialized
DEBUG - 2011-04-06 01:06:42 --> Utf8 Class Initialized
DEBUG - 2011-04-06 01:06:42 --> UTF-8 Support Enabled
DEBUG - 2011-04-06 01:06:42 --> URI Class Initialized
DEBUG - 2011-04-06 01:06:42 --> Router Class Initialized
DEBUG - 2011-04-06 01:06:42 --> Output Class Initialized
DEBUG - 2011-04-06 01:06:42 --> Input Class Initialized
DEBUG - 2011-04-06 01:06:42 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-06 01:06:42 --> Language Class Initialized
DEBUG - 2011-04-06 01:06:42 --> Loader Class Initialized
DEBUG - 2011-04-06 01:06:42 --> Controller Class Initialized
ERROR - 2011-04-06 01:06:42 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-06 01:06:42 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-06 01:06:42 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-06 01:06:42 --> Model Class Initialized
DEBUG - 2011-04-06 01:06:42 --> Model Class Initialized
DEBUG - 2011-04-06 01:06:42 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-06 01:06:42 --> Database Driver Class Initialized
DEBUG - 2011-04-06 01:06:42 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-06 01:06:42 --> Helper loaded: url_helper
DEBUG - 2011-04-06 01:06:42 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-06 01:06:42 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-06 01:06:42 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-06 01:06:42 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-06 01:06:42 --> Final output sent to browser
DEBUG - 2011-04-06 01:06:42 --> Total execution time: 0.1025
DEBUG - 2011-04-06 01:06:43 --> Config Class Initialized
DEBUG - 2011-04-06 01:06:43 --> Hooks Class Initialized
DEBUG - 2011-04-06 01:06:43 --> Utf8 Class Initialized
DEBUG - 2011-04-06 01:06:43 --> UTF-8 Support Enabled
DEBUG - 2011-04-06 01:06:43 --> URI Class Initialized
DEBUG - 2011-04-06 01:06:43 --> Router Class Initialized
DEBUG - 2011-04-06 01:06:43 --> Output Class Initialized
DEBUG - 2011-04-06 01:06:43 --> Input Class Initialized
DEBUG - 2011-04-06 01:06:43 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-06 01:06:43 --> Language Class Initialized
DEBUG - 2011-04-06 01:06:43 --> Loader Class Initialized
DEBUG - 2011-04-06 01:06:43 --> Controller Class Initialized
DEBUG - 2011-04-06 01:06:43 --> Model Class Initialized
DEBUG - 2011-04-06 01:06:43 --> Model Class Initialized
DEBUG - 2011-04-06 01:06:43 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-06 01:06:43 --> Database Driver Class Initialized
DEBUG - 2011-04-06 01:06:44 --> Final output sent to browser
DEBUG - 2011-04-06 01:06:44 --> Total execution time: 1.0065
DEBUG - 2011-04-06 01:06:55 --> Config Class Initialized
DEBUG - 2011-04-06 01:06:55 --> Hooks Class Initialized
DEBUG - 2011-04-06 01:06:55 --> Utf8 Class Initialized
DEBUG - 2011-04-06 01:06:55 --> UTF-8 Support Enabled
DEBUG - 2011-04-06 01:06:55 --> URI Class Initialized
DEBUG - 2011-04-06 01:06:55 --> Router Class Initialized
DEBUG - 2011-04-06 01:06:55 --> Output Class Initialized
DEBUG - 2011-04-06 01:06:55 --> Input Class Initialized
DEBUG - 2011-04-06 01:06:55 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-06 01:06:55 --> Language Class Initialized
DEBUG - 2011-04-06 01:06:55 --> Loader Class Initialized
DEBUG - 2011-04-06 01:06:55 --> Controller Class Initialized
ERROR - 2011-04-06 01:06:55 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-06 01:06:55 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-06 01:06:55 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-06 01:06:55 --> Model Class Initialized
DEBUG - 2011-04-06 01:06:55 --> Model Class Initialized
DEBUG - 2011-04-06 01:06:55 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-06 01:06:55 --> Database Driver Class Initialized
DEBUG - 2011-04-06 01:06:55 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-06 01:06:55 --> Helper loaded: url_helper
DEBUG - 2011-04-06 01:06:55 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-06 01:06:55 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-06 01:06:55 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-06 01:06:55 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-06 01:06:55 --> Final output sent to browser
DEBUG - 2011-04-06 01:06:55 --> Total execution time: 0.0614
DEBUG - 2011-04-06 01:06:56 --> Config Class Initialized
DEBUG - 2011-04-06 01:06:56 --> Hooks Class Initialized
DEBUG - 2011-04-06 01:06:56 --> Utf8 Class Initialized
DEBUG - 2011-04-06 01:06:56 --> UTF-8 Support Enabled
DEBUG - 2011-04-06 01:06:56 --> URI Class Initialized
DEBUG - 2011-04-06 01:06:56 --> Router Class Initialized
DEBUG - 2011-04-06 01:06:56 --> Output Class Initialized
DEBUG - 2011-04-06 01:06:56 --> Input Class Initialized
DEBUG - 2011-04-06 01:06:56 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-06 01:06:56 --> Language Class Initialized
DEBUG - 2011-04-06 01:06:56 --> Loader Class Initialized
DEBUG - 2011-04-06 01:06:56 --> Controller Class Initialized
DEBUG - 2011-04-06 01:06:56 --> Model Class Initialized
DEBUG - 2011-04-06 01:06:56 --> Model Class Initialized
DEBUG - 2011-04-06 01:06:56 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-06 01:06:56 --> Database Driver Class Initialized
DEBUG - 2011-04-06 01:06:57 --> Final output sent to browser
DEBUG - 2011-04-06 01:06:57 --> Total execution time: 0.6602
DEBUG - 2011-04-06 01:07:09 --> Config Class Initialized
DEBUG - 2011-04-06 01:07:09 --> Hooks Class Initialized
DEBUG - 2011-04-06 01:07:09 --> Utf8 Class Initialized
DEBUG - 2011-04-06 01:07:09 --> UTF-8 Support Enabled
DEBUG - 2011-04-06 01:07:09 --> URI Class Initialized
DEBUG - 2011-04-06 01:07:09 --> Router Class Initialized
DEBUG - 2011-04-06 01:07:09 --> Output Class Initialized
DEBUG - 2011-04-06 01:07:09 --> Input Class Initialized
DEBUG - 2011-04-06 01:07:09 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-06 01:07:09 --> Language Class Initialized
DEBUG - 2011-04-06 01:07:09 --> Loader Class Initialized
DEBUG - 2011-04-06 01:07:09 --> Controller Class Initialized
ERROR - 2011-04-06 01:07:09 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-06 01:07:09 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-06 01:07:09 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-06 01:07:09 --> Model Class Initialized
DEBUG - 2011-04-06 01:07:09 --> Model Class Initialized
DEBUG - 2011-04-06 01:07:09 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-06 01:07:09 --> Database Driver Class Initialized
DEBUG - 2011-04-06 01:07:09 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-06 01:07:09 --> Helper loaded: url_helper
DEBUG - 2011-04-06 01:07:09 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-06 01:07:09 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-06 01:07:09 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-06 01:07:09 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-06 01:07:09 --> Final output sent to browser
DEBUG - 2011-04-06 01:07:09 --> Total execution time: 0.0514
DEBUG - 2011-04-06 01:07:09 --> Config Class Initialized
DEBUG - 2011-04-06 01:07:09 --> Hooks Class Initialized
DEBUG - 2011-04-06 01:07:09 --> Utf8 Class Initialized
DEBUG - 2011-04-06 01:07:09 --> UTF-8 Support Enabled
DEBUG - 2011-04-06 01:07:09 --> URI Class Initialized
DEBUG - 2011-04-06 01:07:09 --> Router Class Initialized
DEBUG - 2011-04-06 01:07:09 --> Output Class Initialized
DEBUG - 2011-04-06 01:07:09 --> Input Class Initialized
DEBUG - 2011-04-06 01:07:09 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-06 01:07:09 --> Language Class Initialized
DEBUG - 2011-04-06 01:07:09 --> Loader Class Initialized
DEBUG - 2011-04-06 01:07:09 --> Controller Class Initialized
DEBUG - 2011-04-06 01:07:09 --> Model Class Initialized
DEBUG - 2011-04-06 01:07:09 --> Model Class Initialized
DEBUG - 2011-04-06 01:07:09 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-06 01:07:09 --> Database Driver Class Initialized
DEBUG - 2011-04-06 01:07:10 --> Final output sent to browser
DEBUG - 2011-04-06 01:07:10 --> Total execution time: 0.6539
DEBUG - 2011-04-06 01:07:17 --> Config Class Initialized
DEBUG - 2011-04-06 01:07:17 --> Hooks Class Initialized
DEBUG - 2011-04-06 01:07:17 --> Utf8 Class Initialized
DEBUG - 2011-04-06 01:07:17 --> UTF-8 Support Enabled
DEBUG - 2011-04-06 01:07:17 --> URI Class Initialized
DEBUG - 2011-04-06 01:07:17 --> Router Class Initialized
DEBUG - 2011-04-06 01:07:17 --> Output Class Initialized
DEBUG - 2011-04-06 01:07:17 --> Input Class Initialized
DEBUG - 2011-04-06 01:07:17 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-06 01:07:17 --> Language Class Initialized
DEBUG - 2011-04-06 01:07:17 --> Loader Class Initialized
DEBUG - 2011-04-06 01:07:17 --> Controller Class Initialized
ERROR - 2011-04-06 01:07:17 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-06 01:07:17 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-06 01:07:17 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-06 01:07:17 --> Model Class Initialized
DEBUG - 2011-04-06 01:07:17 --> Model Class Initialized
DEBUG - 2011-04-06 01:07:17 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-06 01:07:17 --> Database Driver Class Initialized
DEBUG - 2011-04-06 01:07:17 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-06 01:07:17 --> Helper loaded: url_helper
DEBUG - 2011-04-06 01:07:17 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-06 01:07:17 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-06 01:07:17 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-06 01:07:17 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-06 01:07:17 --> Final output sent to browser
DEBUG - 2011-04-06 01:07:17 --> Total execution time: 0.0291
DEBUG - 2011-04-06 01:07:17 --> Config Class Initialized
DEBUG - 2011-04-06 01:07:17 --> Hooks Class Initialized
DEBUG - 2011-04-06 01:07:17 --> Utf8 Class Initialized
DEBUG - 2011-04-06 01:07:17 --> UTF-8 Support Enabled
DEBUG - 2011-04-06 01:07:17 --> URI Class Initialized
DEBUG - 2011-04-06 01:07:17 --> Router Class Initialized
DEBUG - 2011-04-06 01:07:17 --> Output Class Initialized
DEBUG - 2011-04-06 01:07:17 --> Input Class Initialized
DEBUG - 2011-04-06 01:07:17 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-06 01:07:17 --> Language Class Initialized
DEBUG - 2011-04-06 01:07:17 --> Loader Class Initialized
DEBUG - 2011-04-06 01:07:17 --> Controller Class Initialized
DEBUG - 2011-04-06 01:07:17 --> Model Class Initialized
DEBUG - 2011-04-06 01:07:17 --> Model Class Initialized
DEBUG - 2011-04-06 01:07:17 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-06 01:07:17 --> Database Driver Class Initialized
DEBUG - 2011-04-06 01:07:18 --> Final output sent to browser
DEBUG - 2011-04-06 01:07:18 --> Total execution time: 0.6233
DEBUG - 2011-04-06 01:07:22 --> Config Class Initialized
DEBUG - 2011-04-06 01:07:22 --> Hooks Class Initialized
DEBUG - 2011-04-06 01:07:22 --> Utf8 Class Initialized
DEBUG - 2011-04-06 01:07:22 --> UTF-8 Support Enabled
DEBUG - 2011-04-06 01:07:22 --> URI Class Initialized
DEBUG - 2011-04-06 01:07:22 --> Router Class Initialized
DEBUG - 2011-04-06 01:07:22 --> Output Class Initialized
DEBUG - 2011-04-06 01:07:22 --> Input Class Initialized
DEBUG - 2011-04-06 01:07:22 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-06 01:07:22 --> Language Class Initialized
DEBUG - 2011-04-06 01:07:22 --> Loader Class Initialized
DEBUG - 2011-04-06 01:07:22 --> Controller Class Initialized
ERROR - 2011-04-06 01:07:22 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-06 01:07:22 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-06 01:07:22 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-06 01:07:22 --> Model Class Initialized
DEBUG - 2011-04-06 01:07:22 --> Model Class Initialized
DEBUG - 2011-04-06 01:07:22 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-06 01:07:22 --> Database Driver Class Initialized
DEBUG - 2011-04-06 01:07:22 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-06 01:07:22 --> Helper loaded: url_helper
DEBUG - 2011-04-06 01:07:22 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-06 01:07:22 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-06 01:07:22 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-06 01:07:22 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-06 01:07:22 --> Final output sent to browser
DEBUG - 2011-04-06 01:07:22 --> Total execution time: 0.0371
DEBUG - 2011-04-06 01:07:28 --> Config Class Initialized
DEBUG - 2011-04-06 01:07:28 --> Hooks Class Initialized
DEBUG - 2011-04-06 01:07:28 --> Utf8 Class Initialized
DEBUG - 2011-04-06 01:07:28 --> UTF-8 Support Enabled
DEBUG - 2011-04-06 01:07:28 --> URI Class Initialized
DEBUG - 2011-04-06 01:07:28 --> Router Class Initialized
DEBUG - 2011-04-06 01:07:28 --> Output Class Initialized
DEBUG - 2011-04-06 01:07:28 --> Input Class Initialized
DEBUG - 2011-04-06 01:07:28 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-06 01:07:28 --> Language Class Initialized
DEBUG - 2011-04-06 01:07:28 --> Loader Class Initialized
DEBUG - 2011-04-06 01:07:28 --> Controller Class Initialized
ERROR - 2011-04-06 01:07:28 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-06 01:07:28 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-06 01:07:28 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-06 01:07:28 --> Model Class Initialized
DEBUG - 2011-04-06 01:07:28 --> Model Class Initialized
DEBUG - 2011-04-06 01:07:28 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-06 01:07:28 --> Database Driver Class Initialized
DEBUG - 2011-04-06 01:07:28 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-06 01:07:28 --> Helper loaded: url_helper
DEBUG - 2011-04-06 01:07:28 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-06 01:07:28 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-06 01:07:28 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-06 01:07:28 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-06 01:07:28 --> Final output sent to browser
DEBUG - 2011-04-06 01:07:28 --> Total execution time: 0.0522
DEBUG - 2011-04-06 01:07:28 --> Config Class Initialized
DEBUG - 2011-04-06 01:07:28 --> Hooks Class Initialized
DEBUG - 2011-04-06 01:07:28 --> Utf8 Class Initialized
DEBUG - 2011-04-06 01:07:28 --> UTF-8 Support Enabled
DEBUG - 2011-04-06 01:07:28 --> URI Class Initialized
DEBUG - 2011-04-06 01:07:28 --> Router Class Initialized
DEBUG - 2011-04-06 01:07:28 --> Output Class Initialized
DEBUG - 2011-04-06 01:07:28 --> Input Class Initialized
DEBUG - 2011-04-06 01:07:28 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-06 01:07:28 --> Language Class Initialized
DEBUG - 2011-04-06 01:07:28 --> Loader Class Initialized
DEBUG - 2011-04-06 01:07:28 --> Controller Class Initialized
DEBUG - 2011-04-06 01:07:28 --> Model Class Initialized
DEBUG - 2011-04-06 01:07:28 --> Model Class Initialized
DEBUG - 2011-04-06 01:07:28 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-06 01:07:28 --> Database Driver Class Initialized
DEBUG - 2011-04-06 01:07:29 --> Final output sent to browser
DEBUG - 2011-04-06 01:07:29 --> Total execution time: 0.6170
DEBUG - 2011-04-06 01:07:49 --> Config Class Initialized
DEBUG - 2011-04-06 01:07:49 --> Hooks Class Initialized
DEBUG - 2011-04-06 01:07:49 --> Utf8 Class Initialized
DEBUG - 2011-04-06 01:07:49 --> UTF-8 Support Enabled
DEBUG - 2011-04-06 01:07:49 --> URI Class Initialized
DEBUG - 2011-04-06 01:07:49 --> Router Class Initialized
DEBUG - 2011-04-06 01:07:49 --> Output Class Initialized
DEBUG - 2011-04-06 01:07:49 --> Input Class Initialized
DEBUG - 2011-04-06 01:07:49 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-06 01:07:49 --> Language Class Initialized
DEBUG - 2011-04-06 01:07:49 --> Loader Class Initialized
DEBUG - 2011-04-06 01:07:49 --> Controller Class Initialized
ERROR - 2011-04-06 01:07:49 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-06 01:07:49 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-06 01:07:49 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-06 01:07:49 --> Model Class Initialized
DEBUG - 2011-04-06 01:07:49 --> Model Class Initialized
DEBUG - 2011-04-06 01:07:49 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-06 01:07:49 --> Database Driver Class Initialized
DEBUG - 2011-04-06 01:07:49 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-06 01:07:49 --> Helper loaded: url_helper
DEBUG - 2011-04-06 01:07:49 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-06 01:07:49 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-06 01:07:49 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-06 01:07:49 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-06 01:07:49 --> Final output sent to browser
DEBUG - 2011-04-06 01:07:49 --> Total execution time: 0.0320
DEBUG - 2011-04-06 01:07:50 --> Config Class Initialized
DEBUG - 2011-04-06 01:07:50 --> Hooks Class Initialized
DEBUG - 2011-04-06 01:07:50 --> Utf8 Class Initialized
DEBUG - 2011-04-06 01:07:50 --> UTF-8 Support Enabled
DEBUG - 2011-04-06 01:07:50 --> URI Class Initialized
DEBUG - 2011-04-06 01:07:50 --> Router Class Initialized
DEBUG - 2011-04-06 01:07:50 --> Output Class Initialized
DEBUG - 2011-04-06 01:07:50 --> Input Class Initialized
DEBUG - 2011-04-06 01:07:50 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-06 01:07:50 --> Language Class Initialized
DEBUG - 2011-04-06 01:07:50 --> Loader Class Initialized
DEBUG - 2011-04-06 01:07:50 --> Controller Class Initialized
DEBUG - 2011-04-06 01:07:50 --> Model Class Initialized
DEBUG - 2011-04-06 01:07:50 --> Model Class Initialized
DEBUG - 2011-04-06 01:07:50 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-06 01:07:50 --> Database Driver Class Initialized
DEBUG - 2011-04-06 01:07:50 --> Final output sent to browser
DEBUG - 2011-04-06 01:07:50 --> Total execution time: 0.6032
DEBUG - 2011-04-06 01:07:50 --> Config Class Initialized
DEBUG - 2011-04-06 01:07:50 --> Hooks Class Initialized
DEBUG - 2011-04-06 01:07:50 --> Utf8 Class Initialized
DEBUG - 2011-04-06 01:07:50 --> UTF-8 Support Enabled
DEBUG - 2011-04-06 01:07:50 --> URI Class Initialized
DEBUG - 2011-04-06 01:07:50 --> Router Class Initialized
ERROR - 2011-04-06 01:07:50 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-04-06 01:07:51 --> Config Class Initialized
DEBUG - 2011-04-06 01:07:51 --> Hooks Class Initialized
DEBUG - 2011-04-06 01:07:51 --> Utf8 Class Initialized
DEBUG - 2011-04-06 01:07:51 --> UTF-8 Support Enabled
DEBUG - 2011-04-06 01:07:51 --> URI Class Initialized
DEBUG - 2011-04-06 01:07:51 --> Router Class Initialized
DEBUG - 2011-04-06 01:07:51 --> Output Class Initialized
DEBUG - 2011-04-06 01:07:51 --> Input Class Initialized
DEBUG - 2011-04-06 01:07:51 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-06 01:07:51 --> Language Class Initialized
DEBUG - 2011-04-06 01:07:51 --> Loader Class Initialized
DEBUG - 2011-04-06 01:07:51 --> Controller Class Initialized
ERROR - 2011-04-06 01:07:51 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-06 01:07:51 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-06 01:07:51 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-06 01:07:51 --> Model Class Initialized
DEBUG - 2011-04-06 01:07:51 --> Model Class Initialized
DEBUG - 2011-04-06 01:07:51 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-06 01:07:51 --> Database Driver Class Initialized
DEBUG - 2011-04-06 01:07:51 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-06 01:07:51 --> Helper loaded: url_helper
DEBUG - 2011-04-06 01:07:51 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-06 01:07:51 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-06 01:07:51 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-06 01:07:51 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-06 01:07:51 --> Final output sent to browser
DEBUG - 2011-04-06 01:07:51 --> Total execution time: 0.0297
DEBUG - 2011-04-06 01:12:13 --> Config Class Initialized
DEBUG - 2011-04-06 01:12:13 --> Hooks Class Initialized
DEBUG - 2011-04-06 01:12:13 --> Utf8 Class Initialized
DEBUG - 2011-04-06 01:12:13 --> UTF-8 Support Enabled
DEBUG - 2011-04-06 01:12:13 --> URI Class Initialized
DEBUG - 2011-04-06 01:12:13 --> Router Class Initialized
DEBUG - 2011-04-06 01:12:13 --> Output Class Initialized
DEBUG - 2011-04-06 01:12:13 --> Input Class Initialized
DEBUG - 2011-04-06 01:12:13 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-06 01:12:13 --> Language Class Initialized
DEBUG - 2011-04-06 01:12:13 --> Loader Class Initialized
DEBUG - 2011-04-06 01:12:13 --> Controller Class Initialized
ERROR - 2011-04-06 01:12:13 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-06 01:12:13 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-06 01:12:13 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-06 01:12:13 --> Model Class Initialized
DEBUG - 2011-04-06 01:12:13 --> Model Class Initialized
DEBUG - 2011-04-06 01:12:13 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-06 01:12:13 --> Database Driver Class Initialized
DEBUG - 2011-04-06 01:12:13 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-06 01:12:13 --> Helper loaded: url_helper
DEBUG - 2011-04-06 01:12:13 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-06 01:12:13 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-06 01:12:13 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-06 01:12:13 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-06 01:12:13 --> Final output sent to browser
DEBUG - 2011-04-06 01:12:13 --> Total execution time: 0.0299
DEBUG - 2011-04-06 01:12:14 --> Config Class Initialized
DEBUG - 2011-04-06 01:12:14 --> Hooks Class Initialized
DEBUG - 2011-04-06 01:12:14 --> Utf8 Class Initialized
DEBUG - 2011-04-06 01:12:14 --> UTF-8 Support Enabled
DEBUG - 2011-04-06 01:12:14 --> URI Class Initialized
DEBUG - 2011-04-06 01:12:14 --> Router Class Initialized
DEBUG - 2011-04-06 01:12:14 --> Output Class Initialized
DEBUG - 2011-04-06 01:12:14 --> Input Class Initialized
DEBUG - 2011-04-06 01:12:14 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-06 01:12:14 --> Language Class Initialized
DEBUG - 2011-04-06 01:12:14 --> Loader Class Initialized
DEBUG - 2011-04-06 01:12:14 --> Controller Class Initialized
DEBUG - 2011-04-06 01:12:14 --> Model Class Initialized
DEBUG - 2011-04-06 01:12:14 --> Model Class Initialized
DEBUG - 2011-04-06 01:12:14 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-06 01:12:14 --> Database Driver Class Initialized
DEBUG - 2011-04-06 01:12:15 --> Final output sent to browser
DEBUG - 2011-04-06 01:12:15 --> Total execution time: 0.5505
DEBUG - 2011-04-06 01:12:16 --> Config Class Initialized
DEBUG - 2011-04-06 01:12:16 --> Hooks Class Initialized
DEBUG - 2011-04-06 01:12:16 --> Utf8 Class Initialized
DEBUG - 2011-04-06 01:12:16 --> UTF-8 Support Enabled
DEBUG - 2011-04-06 01:12:16 --> URI Class Initialized
DEBUG - 2011-04-06 01:12:16 --> Router Class Initialized
ERROR - 2011-04-06 01:12:16 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-06 01:16:04 --> Config Class Initialized
DEBUG - 2011-04-06 01:16:04 --> Hooks Class Initialized
DEBUG - 2011-04-06 01:16:04 --> Utf8 Class Initialized
DEBUG - 2011-04-06 01:16:04 --> UTF-8 Support Enabled
DEBUG - 2011-04-06 01:16:04 --> URI Class Initialized
DEBUG - 2011-04-06 01:16:04 --> Router Class Initialized
DEBUG - 2011-04-06 01:16:04 --> Output Class Initialized
DEBUG - 2011-04-06 01:16:04 --> Input Class Initialized
DEBUG - 2011-04-06 01:16:04 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-06 01:16:04 --> Language Class Initialized
DEBUG - 2011-04-06 01:16:04 --> Loader Class Initialized
DEBUG - 2011-04-06 01:16:04 --> Controller Class Initialized
ERROR - 2011-04-06 01:16:04 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-06 01:16:04 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-06 01:16:04 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-06 01:16:04 --> Model Class Initialized
DEBUG - 2011-04-06 01:16:04 --> Model Class Initialized
DEBUG - 2011-04-06 01:16:04 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-06 01:16:04 --> Database Driver Class Initialized
DEBUG - 2011-04-06 01:16:04 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-06 01:16:04 --> Helper loaded: url_helper
DEBUG - 2011-04-06 01:16:04 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-06 01:16:04 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-06 01:16:04 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-06 01:16:04 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-06 01:16:04 --> Final output sent to browser
DEBUG - 2011-04-06 01:16:04 --> Total execution time: 0.0332
DEBUG - 2011-04-06 01:16:05 --> Config Class Initialized
DEBUG - 2011-04-06 01:16:05 --> Hooks Class Initialized
DEBUG - 2011-04-06 01:16:05 --> Utf8 Class Initialized
DEBUG - 2011-04-06 01:16:05 --> UTF-8 Support Enabled
DEBUG - 2011-04-06 01:16:05 --> URI Class Initialized
DEBUG - 2011-04-06 01:16:05 --> Router Class Initialized
DEBUG - 2011-04-06 01:16:05 --> Output Class Initialized
DEBUG - 2011-04-06 01:16:05 --> Input Class Initialized
DEBUG - 2011-04-06 01:16:05 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-06 01:16:05 --> Language Class Initialized
DEBUG - 2011-04-06 01:16:05 --> Loader Class Initialized
DEBUG - 2011-04-06 01:16:05 --> Controller Class Initialized
DEBUG - 2011-04-06 01:16:05 --> Model Class Initialized
DEBUG - 2011-04-06 01:16:05 --> Model Class Initialized
DEBUG - 2011-04-06 01:16:05 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-06 01:16:05 --> Database Driver Class Initialized
DEBUG - 2011-04-06 01:16:06 --> Final output sent to browser
DEBUG - 2011-04-06 01:16:06 --> Total execution time: 0.5997
DEBUG - 2011-04-06 01:16:07 --> Config Class Initialized
DEBUG - 2011-04-06 01:16:07 --> Hooks Class Initialized
DEBUG - 2011-04-06 01:16:07 --> Utf8 Class Initialized
DEBUG - 2011-04-06 01:16:07 --> UTF-8 Support Enabled
DEBUG - 2011-04-06 01:16:07 --> URI Class Initialized
DEBUG - 2011-04-06 01:16:07 --> Router Class Initialized
ERROR - 2011-04-06 01:16:07 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-06 01:16:25 --> Config Class Initialized
DEBUG - 2011-04-06 01:16:25 --> Hooks Class Initialized
DEBUG - 2011-04-06 01:16:25 --> Utf8 Class Initialized
DEBUG - 2011-04-06 01:16:25 --> UTF-8 Support Enabled
DEBUG - 2011-04-06 01:16:25 --> URI Class Initialized
DEBUG - 2011-04-06 01:16:25 --> Router Class Initialized
DEBUG - 2011-04-06 01:16:25 --> Output Class Initialized
DEBUG - 2011-04-06 01:16:25 --> Input Class Initialized
DEBUG - 2011-04-06 01:16:25 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-06 01:16:25 --> Language Class Initialized
DEBUG - 2011-04-06 01:16:25 --> Loader Class Initialized
DEBUG - 2011-04-06 01:16:25 --> Controller Class Initialized
ERROR - 2011-04-06 01:16:25 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-06 01:16:25 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-06 01:16:25 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-06 01:16:25 --> Model Class Initialized
DEBUG - 2011-04-06 01:16:25 --> Model Class Initialized
DEBUG - 2011-04-06 01:16:25 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-06 01:16:25 --> Database Driver Class Initialized
DEBUG - 2011-04-06 01:16:25 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-06 01:16:25 --> Helper loaded: url_helper
DEBUG - 2011-04-06 01:16:25 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-06 01:16:25 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-06 01:16:25 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-06 01:16:25 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-06 01:16:25 --> Final output sent to browser
DEBUG - 2011-04-06 01:16:25 --> Total execution time: 0.0287
DEBUG - 2011-04-06 01:16:27 --> Config Class Initialized
DEBUG - 2011-04-06 01:16:27 --> Hooks Class Initialized
DEBUG - 2011-04-06 01:16:27 --> Utf8 Class Initialized
DEBUG - 2011-04-06 01:16:27 --> UTF-8 Support Enabled
DEBUG - 2011-04-06 01:16:27 --> URI Class Initialized
DEBUG - 2011-04-06 01:16:27 --> Router Class Initialized
DEBUG - 2011-04-06 01:16:27 --> Output Class Initialized
DEBUG - 2011-04-06 01:16:27 --> Input Class Initialized
DEBUG - 2011-04-06 01:16:27 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-06 01:16:27 --> Language Class Initialized
DEBUG - 2011-04-06 01:16:27 --> Loader Class Initialized
DEBUG - 2011-04-06 01:16:27 --> Controller Class Initialized
DEBUG - 2011-04-06 01:16:27 --> Model Class Initialized
DEBUG - 2011-04-06 01:16:27 --> Model Class Initialized
DEBUG - 2011-04-06 01:16:27 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-06 01:16:27 --> Database Driver Class Initialized
DEBUG - 2011-04-06 01:16:27 --> Final output sent to browser
DEBUG - 2011-04-06 01:16:27 --> Total execution time: 0.7691
DEBUG - 2011-04-06 01:16:29 --> Config Class Initialized
DEBUG - 2011-04-06 01:16:29 --> Hooks Class Initialized
DEBUG - 2011-04-06 01:16:29 --> Utf8 Class Initialized
DEBUG - 2011-04-06 01:16:29 --> UTF-8 Support Enabled
DEBUG - 2011-04-06 01:16:29 --> URI Class Initialized
DEBUG - 2011-04-06 01:16:29 --> Router Class Initialized
ERROR - 2011-04-06 01:16:29 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-06 01:16:56 --> Config Class Initialized
DEBUG - 2011-04-06 01:16:56 --> Hooks Class Initialized
DEBUG - 2011-04-06 01:16:56 --> Utf8 Class Initialized
DEBUG - 2011-04-06 01:16:56 --> UTF-8 Support Enabled
DEBUG - 2011-04-06 01:16:56 --> URI Class Initialized
DEBUG - 2011-04-06 01:16:56 --> Router Class Initialized
DEBUG - 2011-04-06 01:16:56 --> Output Class Initialized
DEBUG - 2011-04-06 01:16:56 --> Input Class Initialized
DEBUG - 2011-04-06 01:16:56 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-06 01:16:56 --> Language Class Initialized
DEBUG - 2011-04-06 01:16:56 --> Loader Class Initialized
DEBUG - 2011-04-06 01:16:56 --> Controller Class Initialized
ERROR - 2011-04-06 01:16:56 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-06 01:16:56 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-06 01:16:56 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-06 01:16:56 --> Model Class Initialized
DEBUG - 2011-04-06 01:16:56 --> Model Class Initialized
DEBUG - 2011-04-06 01:16:56 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-06 01:16:56 --> Database Driver Class Initialized
DEBUG - 2011-04-06 01:16:56 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-06 01:16:56 --> Helper loaded: url_helper
DEBUG - 2011-04-06 01:16:56 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-06 01:16:56 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-06 01:16:56 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-06 01:16:56 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-06 01:16:56 --> Final output sent to browser
DEBUG - 2011-04-06 01:16:56 --> Total execution time: 0.0288
DEBUG - 2011-04-06 01:16:56 --> Config Class Initialized
DEBUG - 2011-04-06 01:16:56 --> Hooks Class Initialized
DEBUG - 2011-04-06 01:16:56 --> Utf8 Class Initialized
DEBUG - 2011-04-06 01:16:56 --> UTF-8 Support Enabled
DEBUG - 2011-04-06 01:16:56 --> URI Class Initialized
DEBUG - 2011-04-06 01:16:56 --> Router Class Initialized
DEBUG - 2011-04-06 01:16:56 --> Output Class Initialized
DEBUG - 2011-04-06 01:16:56 --> Input Class Initialized
DEBUG - 2011-04-06 01:16:56 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-06 01:16:56 --> Language Class Initialized
DEBUG - 2011-04-06 01:16:56 --> Loader Class Initialized
DEBUG - 2011-04-06 01:16:56 --> Controller Class Initialized
DEBUG - 2011-04-06 01:16:56 --> Model Class Initialized
DEBUG - 2011-04-06 01:16:56 --> Model Class Initialized
DEBUG - 2011-04-06 01:16:56 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-06 01:16:56 --> Database Driver Class Initialized
DEBUG - 2011-04-06 01:16:57 --> Final output sent to browser
DEBUG - 2011-04-06 01:16:57 --> Total execution time: 0.5945
DEBUG - 2011-04-06 01:16:59 --> Config Class Initialized
DEBUG - 2011-04-06 01:16:59 --> Hooks Class Initialized
DEBUG - 2011-04-06 01:16:59 --> Utf8 Class Initialized
DEBUG - 2011-04-06 01:16:59 --> UTF-8 Support Enabled
DEBUG - 2011-04-06 01:16:59 --> URI Class Initialized
DEBUG - 2011-04-06 01:16:59 --> Router Class Initialized
ERROR - 2011-04-06 01:16:59 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-06 01:17:17 --> Config Class Initialized
DEBUG - 2011-04-06 01:17:17 --> Hooks Class Initialized
DEBUG - 2011-04-06 01:17:17 --> Utf8 Class Initialized
DEBUG - 2011-04-06 01:17:17 --> UTF-8 Support Enabled
DEBUG - 2011-04-06 01:17:17 --> URI Class Initialized
DEBUG - 2011-04-06 01:17:17 --> Router Class Initialized
DEBUG - 2011-04-06 01:17:17 --> Output Class Initialized
DEBUG - 2011-04-06 01:17:17 --> Input Class Initialized
DEBUG - 2011-04-06 01:17:17 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-06 01:17:17 --> Language Class Initialized
DEBUG - 2011-04-06 01:17:17 --> Loader Class Initialized
DEBUG - 2011-04-06 01:17:17 --> Controller Class Initialized
ERROR - 2011-04-06 01:17:17 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-06 01:17:17 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-06 01:17:17 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-06 01:17:17 --> Model Class Initialized
DEBUG - 2011-04-06 01:17:17 --> Model Class Initialized
DEBUG - 2011-04-06 01:17:17 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-06 01:17:17 --> Database Driver Class Initialized
DEBUG - 2011-04-06 01:17:17 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-06 01:17:17 --> Helper loaded: url_helper
DEBUG - 2011-04-06 01:17:17 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-06 01:17:17 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-06 01:17:17 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-06 01:17:17 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-06 01:17:17 --> Final output sent to browser
DEBUG - 2011-04-06 01:17:17 --> Total execution time: 0.0311
DEBUG - 2011-04-06 01:17:18 --> Config Class Initialized
DEBUG - 2011-04-06 01:17:18 --> Hooks Class Initialized
DEBUG - 2011-04-06 01:17:18 --> Utf8 Class Initialized
DEBUG - 2011-04-06 01:17:18 --> UTF-8 Support Enabled
DEBUG - 2011-04-06 01:17:18 --> URI Class Initialized
DEBUG - 2011-04-06 01:17:18 --> Router Class Initialized
DEBUG - 2011-04-06 01:17:18 --> Output Class Initialized
DEBUG - 2011-04-06 01:17:18 --> Input Class Initialized
DEBUG - 2011-04-06 01:17:18 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-06 01:17:18 --> Language Class Initialized
DEBUG - 2011-04-06 01:17:18 --> Loader Class Initialized
DEBUG - 2011-04-06 01:17:18 --> Controller Class Initialized
DEBUG - 2011-04-06 01:17:18 --> Model Class Initialized
DEBUG - 2011-04-06 01:17:18 --> Model Class Initialized
DEBUG - 2011-04-06 01:17:18 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-06 01:17:18 --> Database Driver Class Initialized
DEBUG - 2011-04-06 01:17:19 --> Final output sent to browser
DEBUG - 2011-04-06 01:17:19 --> Total execution time: 0.6030
DEBUG - 2011-04-06 01:17:20 --> Config Class Initialized
DEBUG - 2011-04-06 01:17:20 --> Hooks Class Initialized
DEBUG - 2011-04-06 01:17:20 --> Utf8 Class Initialized
DEBUG - 2011-04-06 01:17:20 --> UTF-8 Support Enabled
DEBUG - 2011-04-06 01:17:20 --> URI Class Initialized
DEBUG - 2011-04-06 01:17:20 --> Router Class Initialized
ERROR - 2011-04-06 01:17:20 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-06 01:17:31 --> Config Class Initialized
DEBUG - 2011-04-06 01:17:31 --> Hooks Class Initialized
DEBUG - 2011-04-06 01:17:31 --> Utf8 Class Initialized
DEBUG - 2011-04-06 01:17:31 --> UTF-8 Support Enabled
DEBUG - 2011-04-06 01:17:31 --> URI Class Initialized
DEBUG - 2011-04-06 01:17:31 --> Router Class Initialized
DEBUG - 2011-04-06 01:17:31 --> Output Class Initialized
DEBUG - 2011-04-06 01:17:31 --> Input Class Initialized
DEBUG - 2011-04-06 01:17:31 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-06 01:17:31 --> Language Class Initialized
DEBUG - 2011-04-06 01:17:31 --> Loader Class Initialized
DEBUG - 2011-04-06 01:17:31 --> Controller Class Initialized
ERROR - 2011-04-06 01:17:31 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-06 01:17:31 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-06 01:17:31 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-06 01:17:31 --> Model Class Initialized
DEBUG - 2011-04-06 01:17:31 --> Model Class Initialized
DEBUG - 2011-04-06 01:17:31 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-06 01:17:31 --> Database Driver Class Initialized
DEBUG - 2011-04-06 01:17:31 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-06 01:17:31 --> Helper loaded: url_helper
DEBUG - 2011-04-06 01:17:31 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-06 01:17:31 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-06 01:17:31 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-06 01:17:31 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-06 01:17:31 --> Final output sent to browser
DEBUG - 2011-04-06 01:17:31 --> Total execution time: 0.0283
DEBUG - 2011-04-06 01:17:31 --> Config Class Initialized
DEBUG - 2011-04-06 01:17:31 --> Hooks Class Initialized
DEBUG - 2011-04-06 01:17:31 --> Utf8 Class Initialized
DEBUG - 2011-04-06 01:17:31 --> UTF-8 Support Enabled
DEBUG - 2011-04-06 01:17:31 --> URI Class Initialized
DEBUG - 2011-04-06 01:17:31 --> Router Class Initialized
DEBUG - 2011-04-06 01:17:31 --> Output Class Initialized
DEBUG - 2011-04-06 01:17:31 --> Input Class Initialized
DEBUG - 2011-04-06 01:17:31 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-06 01:17:31 --> Language Class Initialized
DEBUG - 2011-04-06 01:17:31 --> Loader Class Initialized
DEBUG - 2011-04-06 01:17:31 --> Controller Class Initialized
DEBUG - 2011-04-06 01:17:31 --> Model Class Initialized
DEBUG - 2011-04-06 01:17:31 --> Model Class Initialized
DEBUG - 2011-04-06 01:17:31 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-06 01:17:31 --> Database Driver Class Initialized
DEBUG - 2011-04-06 01:17:33 --> Final output sent to browser
DEBUG - 2011-04-06 01:17:33 --> Total execution time: 1.6733
DEBUG - 2011-04-06 01:17:36 --> Config Class Initialized
DEBUG - 2011-04-06 01:17:36 --> Hooks Class Initialized
DEBUG - 2011-04-06 01:17:36 --> Utf8 Class Initialized
DEBUG - 2011-04-06 01:17:36 --> UTF-8 Support Enabled
DEBUG - 2011-04-06 01:17:36 --> URI Class Initialized
DEBUG - 2011-04-06 01:17:36 --> Router Class Initialized
ERROR - 2011-04-06 01:17:36 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-06 01:18:02 --> Config Class Initialized
DEBUG - 2011-04-06 01:18:02 --> Hooks Class Initialized
DEBUG - 2011-04-06 01:18:02 --> Utf8 Class Initialized
DEBUG - 2011-04-06 01:18:02 --> UTF-8 Support Enabled
DEBUG - 2011-04-06 01:18:02 --> URI Class Initialized
DEBUG - 2011-04-06 01:18:02 --> Router Class Initialized
DEBUG - 2011-04-06 01:18:02 --> Output Class Initialized
DEBUG - 2011-04-06 01:18:02 --> Input Class Initialized
DEBUG - 2011-04-06 01:18:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-06 01:18:02 --> Language Class Initialized
DEBUG - 2011-04-06 01:18:02 --> Loader Class Initialized
DEBUG - 2011-04-06 01:18:02 --> Controller Class Initialized
ERROR - 2011-04-06 01:18:02 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-06 01:18:02 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-06 01:18:02 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-06 01:18:02 --> Model Class Initialized
DEBUG - 2011-04-06 01:18:02 --> Model Class Initialized
DEBUG - 2011-04-06 01:18:02 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-06 01:18:02 --> Database Driver Class Initialized
DEBUG - 2011-04-06 01:18:02 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-06 01:18:02 --> Helper loaded: url_helper
DEBUG - 2011-04-06 01:18:02 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-06 01:18:02 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-06 01:18:02 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-06 01:18:02 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-06 01:18:02 --> Final output sent to browser
DEBUG - 2011-04-06 01:18:02 --> Total execution time: 0.0286
DEBUG - 2011-04-06 01:18:03 --> Config Class Initialized
DEBUG - 2011-04-06 01:18:03 --> Hooks Class Initialized
DEBUG - 2011-04-06 01:18:03 --> Utf8 Class Initialized
DEBUG - 2011-04-06 01:18:03 --> UTF-8 Support Enabled
DEBUG - 2011-04-06 01:18:03 --> URI Class Initialized
DEBUG - 2011-04-06 01:18:03 --> Router Class Initialized
DEBUG - 2011-04-06 01:18:03 --> Output Class Initialized
DEBUG - 2011-04-06 01:18:03 --> Input Class Initialized
DEBUG - 2011-04-06 01:18:03 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-06 01:18:03 --> Language Class Initialized
DEBUG - 2011-04-06 01:18:03 --> Loader Class Initialized
DEBUG - 2011-04-06 01:18:03 --> Controller Class Initialized
DEBUG - 2011-04-06 01:18:03 --> Model Class Initialized
DEBUG - 2011-04-06 01:18:03 --> Model Class Initialized
DEBUG - 2011-04-06 01:18:03 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-06 01:18:03 --> Database Driver Class Initialized
DEBUG - 2011-04-06 01:18:03 --> Final output sent to browser
DEBUG - 2011-04-06 01:18:03 --> Total execution time: 0.5995
DEBUG - 2011-04-06 01:18:06 --> Config Class Initialized
DEBUG - 2011-04-06 01:18:06 --> Hooks Class Initialized
DEBUG - 2011-04-06 01:18:06 --> Utf8 Class Initialized
DEBUG - 2011-04-06 01:18:06 --> UTF-8 Support Enabled
DEBUG - 2011-04-06 01:18:06 --> URI Class Initialized
DEBUG - 2011-04-06 01:18:06 --> Router Class Initialized
ERROR - 2011-04-06 01:18:06 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-06 01:18:53 --> Config Class Initialized
DEBUG - 2011-04-06 01:18:53 --> Hooks Class Initialized
DEBUG - 2011-04-06 01:18:53 --> Utf8 Class Initialized
DEBUG - 2011-04-06 01:18:53 --> UTF-8 Support Enabled
DEBUG - 2011-04-06 01:18:53 --> URI Class Initialized
DEBUG - 2011-04-06 01:18:53 --> Router Class Initialized
DEBUG - 2011-04-06 01:18:53 --> Output Class Initialized
DEBUG - 2011-04-06 01:18:53 --> Input Class Initialized
DEBUG - 2011-04-06 01:18:53 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-06 01:18:53 --> Language Class Initialized
DEBUG - 2011-04-06 01:18:53 --> Loader Class Initialized
DEBUG - 2011-04-06 01:18:53 --> Controller Class Initialized
ERROR - 2011-04-06 01:18:53 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-06 01:18:53 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-06 01:18:53 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-06 01:18:53 --> Model Class Initialized
DEBUG - 2011-04-06 01:18:53 --> Model Class Initialized
DEBUG - 2011-04-06 01:18:53 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-06 01:18:53 --> Database Driver Class Initialized
DEBUG - 2011-04-06 01:18:53 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-06 01:18:53 --> Helper loaded: url_helper
DEBUG - 2011-04-06 01:18:53 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-06 01:18:53 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-06 01:18:53 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-06 01:18:53 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-06 01:18:53 --> Final output sent to browser
DEBUG - 2011-04-06 01:18:53 --> Total execution time: 0.0287
DEBUG - 2011-04-06 01:18:54 --> Config Class Initialized
DEBUG - 2011-04-06 01:18:54 --> Hooks Class Initialized
DEBUG - 2011-04-06 01:18:54 --> Utf8 Class Initialized
DEBUG - 2011-04-06 01:18:54 --> UTF-8 Support Enabled
DEBUG - 2011-04-06 01:18:54 --> URI Class Initialized
DEBUG - 2011-04-06 01:18:54 --> Router Class Initialized
DEBUG - 2011-04-06 01:18:54 --> Output Class Initialized
DEBUG - 2011-04-06 01:18:54 --> Input Class Initialized
DEBUG - 2011-04-06 01:18:54 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-06 01:18:54 --> Language Class Initialized
DEBUG - 2011-04-06 01:18:54 --> Loader Class Initialized
DEBUG - 2011-04-06 01:18:54 --> Controller Class Initialized
DEBUG - 2011-04-06 01:18:54 --> Model Class Initialized
DEBUG - 2011-04-06 01:18:54 --> Model Class Initialized
DEBUG - 2011-04-06 01:18:54 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-06 01:18:54 --> Database Driver Class Initialized
DEBUG - 2011-04-06 01:18:55 --> Final output sent to browser
DEBUG - 2011-04-06 01:18:55 --> Total execution time: 0.6478
DEBUG - 2011-04-06 01:18:57 --> Config Class Initialized
DEBUG - 2011-04-06 01:18:57 --> Hooks Class Initialized
DEBUG - 2011-04-06 01:18:57 --> Utf8 Class Initialized
DEBUG - 2011-04-06 01:18:57 --> UTF-8 Support Enabled
DEBUG - 2011-04-06 01:18:57 --> URI Class Initialized
DEBUG - 2011-04-06 01:18:57 --> Router Class Initialized
ERROR - 2011-04-06 01:18:57 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-06 01:19:24 --> Config Class Initialized
DEBUG - 2011-04-06 01:19:24 --> Hooks Class Initialized
DEBUG - 2011-04-06 01:19:24 --> Utf8 Class Initialized
DEBUG - 2011-04-06 01:19:24 --> UTF-8 Support Enabled
DEBUG - 2011-04-06 01:19:24 --> URI Class Initialized
DEBUG - 2011-04-06 01:19:24 --> Router Class Initialized
DEBUG - 2011-04-06 01:19:24 --> Output Class Initialized
DEBUG - 2011-04-06 01:19:24 --> Input Class Initialized
DEBUG - 2011-04-06 01:19:24 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-06 01:19:24 --> Language Class Initialized
DEBUG - 2011-04-06 01:19:24 --> Loader Class Initialized
DEBUG - 2011-04-06 01:19:24 --> Controller Class Initialized
ERROR - 2011-04-06 01:19:24 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-06 01:19:24 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-06 01:19:24 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-06 01:19:24 --> Model Class Initialized
DEBUG - 2011-04-06 01:19:24 --> Model Class Initialized
DEBUG - 2011-04-06 01:19:24 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-06 01:19:24 --> Database Driver Class Initialized
DEBUG - 2011-04-06 01:19:24 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-06 01:19:24 --> Helper loaded: url_helper
DEBUG - 2011-04-06 01:19:24 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-06 01:19:24 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-06 01:19:24 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-06 01:19:24 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-06 01:19:24 --> Final output sent to browser
DEBUG - 2011-04-06 01:19:24 --> Total execution time: 0.0560
DEBUG - 2011-04-06 01:19:25 --> Config Class Initialized
DEBUG - 2011-04-06 01:19:25 --> Hooks Class Initialized
DEBUG - 2011-04-06 01:19:25 --> Utf8 Class Initialized
DEBUG - 2011-04-06 01:19:25 --> UTF-8 Support Enabled
DEBUG - 2011-04-06 01:19:25 --> URI Class Initialized
DEBUG - 2011-04-06 01:19:25 --> Router Class Initialized
DEBUG - 2011-04-06 01:19:25 --> Output Class Initialized
DEBUG - 2011-04-06 01:19:25 --> Input Class Initialized
DEBUG - 2011-04-06 01:19:25 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-06 01:19:25 --> Language Class Initialized
DEBUG - 2011-04-06 01:19:25 --> Loader Class Initialized
DEBUG - 2011-04-06 01:19:25 --> Controller Class Initialized
DEBUG - 2011-04-06 01:19:25 --> Model Class Initialized
DEBUG - 2011-04-06 01:19:25 --> Model Class Initialized
DEBUG - 2011-04-06 01:19:25 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-06 01:19:25 --> Database Driver Class Initialized
DEBUG - 2011-04-06 01:19:25 --> Final output sent to browser
DEBUG - 2011-04-06 01:19:25 --> Total execution time: 0.6288
DEBUG - 2011-04-06 01:19:27 --> Config Class Initialized
DEBUG - 2011-04-06 01:19:27 --> Hooks Class Initialized
DEBUG - 2011-04-06 01:19:27 --> Utf8 Class Initialized
DEBUG - 2011-04-06 01:19:27 --> UTF-8 Support Enabled
DEBUG - 2011-04-06 01:19:27 --> URI Class Initialized
DEBUG - 2011-04-06 01:19:27 --> Router Class Initialized
ERROR - 2011-04-06 01:19:27 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-06 01:20:04 --> Config Class Initialized
DEBUG - 2011-04-06 01:20:04 --> Hooks Class Initialized
DEBUG - 2011-04-06 01:20:04 --> Utf8 Class Initialized
DEBUG - 2011-04-06 01:20:04 --> UTF-8 Support Enabled
DEBUG - 2011-04-06 01:20:04 --> URI Class Initialized
DEBUG - 2011-04-06 01:20:04 --> Router Class Initialized
DEBUG - 2011-04-06 01:20:04 --> Output Class Initialized
DEBUG - 2011-04-06 01:20:04 --> Input Class Initialized
DEBUG - 2011-04-06 01:20:04 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-06 01:20:04 --> Language Class Initialized
DEBUG - 2011-04-06 01:20:04 --> Loader Class Initialized
DEBUG - 2011-04-06 01:20:04 --> Controller Class Initialized
ERROR - 2011-04-06 01:20:04 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-06 01:20:04 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-06 01:20:04 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-06 01:20:04 --> Model Class Initialized
DEBUG - 2011-04-06 01:20:04 --> Model Class Initialized
DEBUG - 2011-04-06 01:20:04 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-06 01:20:04 --> Database Driver Class Initialized
DEBUG - 2011-04-06 01:20:04 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-06 01:20:04 --> Helper loaded: url_helper
DEBUG - 2011-04-06 01:20:04 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-06 01:20:04 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-06 01:20:04 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-06 01:20:04 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-06 01:20:04 --> Final output sent to browser
DEBUG - 2011-04-06 01:20:04 --> Total execution time: 0.0327
DEBUG - 2011-04-06 01:20:04 --> Config Class Initialized
DEBUG - 2011-04-06 01:20:04 --> Hooks Class Initialized
DEBUG - 2011-04-06 01:20:04 --> Utf8 Class Initialized
DEBUG - 2011-04-06 01:20:04 --> UTF-8 Support Enabled
DEBUG - 2011-04-06 01:20:04 --> URI Class Initialized
DEBUG - 2011-04-06 01:20:04 --> Router Class Initialized
DEBUG - 2011-04-06 01:20:04 --> Output Class Initialized
DEBUG - 2011-04-06 01:20:04 --> Input Class Initialized
DEBUG - 2011-04-06 01:20:04 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-06 01:20:04 --> Language Class Initialized
DEBUG - 2011-04-06 01:20:04 --> Loader Class Initialized
DEBUG - 2011-04-06 01:20:04 --> Controller Class Initialized
DEBUG - 2011-04-06 01:20:04 --> Model Class Initialized
DEBUG - 2011-04-06 01:20:04 --> Model Class Initialized
DEBUG - 2011-04-06 01:20:04 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-06 01:20:04 --> Database Driver Class Initialized
DEBUG - 2011-04-06 01:20:05 --> Final output sent to browser
DEBUG - 2011-04-06 01:20:05 --> Total execution time: 0.5952
DEBUG - 2011-04-06 01:20:07 --> Config Class Initialized
DEBUG - 2011-04-06 01:20:07 --> Hooks Class Initialized
DEBUG - 2011-04-06 01:20:07 --> Utf8 Class Initialized
DEBUG - 2011-04-06 01:20:07 --> UTF-8 Support Enabled
DEBUG - 2011-04-06 01:20:07 --> URI Class Initialized
DEBUG - 2011-04-06 01:20:07 --> Router Class Initialized
ERROR - 2011-04-06 01:20:07 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-06 01:20:28 --> Config Class Initialized
DEBUG - 2011-04-06 01:20:28 --> Hooks Class Initialized
DEBUG - 2011-04-06 01:20:28 --> Utf8 Class Initialized
DEBUG - 2011-04-06 01:20:28 --> UTF-8 Support Enabled
DEBUG - 2011-04-06 01:20:28 --> URI Class Initialized
DEBUG - 2011-04-06 01:20:28 --> Router Class Initialized
DEBUG - 2011-04-06 01:20:28 --> Output Class Initialized
DEBUG - 2011-04-06 01:20:28 --> Input Class Initialized
DEBUG - 2011-04-06 01:20:28 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-06 01:20:28 --> Language Class Initialized
DEBUG - 2011-04-06 01:20:28 --> Loader Class Initialized
DEBUG - 2011-04-06 01:20:28 --> Controller Class Initialized
ERROR - 2011-04-06 01:20:28 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-06 01:20:28 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-06 01:20:28 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-06 01:20:28 --> Model Class Initialized
DEBUG - 2011-04-06 01:20:28 --> Model Class Initialized
DEBUG - 2011-04-06 01:20:28 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-06 01:20:28 --> Database Driver Class Initialized
DEBUG - 2011-04-06 01:20:28 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-06 01:20:28 --> Helper loaded: url_helper
DEBUG - 2011-04-06 01:20:28 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-06 01:20:28 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-06 01:20:28 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-06 01:20:28 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-06 01:20:28 --> Final output sent to browser
DEBUG - 2011-04-06 01:20:28 --> Total execution time: 0.0285
DEBUG - 2011-04-06 01:20:29 --> Config Class Initialized
DEBUG - 2011-04-06 01:20:29 --> Hooks Class Initialized
DEBUG - 2011-04-06 01:20:29 --> Utf8 Class Initialized
DEBUG - 2011-04-06 01:20:29 --> UTF-8 Support Enabled
DEBUG - 2011-04-06 01:20:29 --> URI Class Initialized
DEBUG - 2011-04-06 01:20:29 --> Router Class Initialized
DEBUG - 2011-04-06 01:20:29 --> Output Class Initialized
DEBUG - 2011-04-06 01:20:29 --> Input Class Initialized
DEBUG - 2011-04-06 01:20:29 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-06 01:20:29 --> Language Class Initialized
DEBUG - 2011-04-06 01:20:29 --> Loader Class Initialized
DEBUG - 2011-04-06 01:20:29 --> Controller Class Initialized
DEBUG - 2011-04-06 01:20:29 --> Model Class Initialized
DEBUG - 2011-04-06 01:20:29 --> Model Class Initialized
DEBUG - 2011-04-06 01:20:29 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-06 01:20:29 --> Database Driver Class Initialized
DEBUG - 2011-04-06 01:20:29 --> Final output sent to browser
DEBUG - 2011-04-06 01:20:29 --> Total execution time: 0.5812
DEBUG - 2011-04-06 01:20:31 --> Config Class Initialized
DEBUG - 2011-04-06 01:20:31 --> Hooks Class Initialized
DEBUG - 2011-04-06 01:20:31 --> Utf8 Class Initialized
DEBUG - 2011-04-06 01:20:31 --> UTF-8 Support Enabled
DEBUG - 2011-04-06 01:20:31 --> URI Class Initialized
DEBUG - 2011-04-06 01:20:31 --> Router Class Initialized
ERROR - 2011-04-06 01:20:31 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-06 01:20:58 --> Config Class Initialized
DEBUG - 2011-04-06 01:20:58 --> Hooks Class Initialized
DEBUG - 2011-04-06 01:20:58 --> Utf8 Class Initialized
DEBUG - 2011-04-06 01:20:58 --> UTF-8 Support Enabled
DEBUG - 2011-04-06 01:20:58 --> URI Class Initialized
DEBUG - 2011-04-06 01:20:58 --> Router Class Initialized
DEBUG - 2011-04-06 01:20:58 --> Output Class Initialized
DEBUG - 2011-04-06 01:20:58 --> Input Class Initialized
DEBUG - 2011-04-06 01:20:58 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-06 01:20:58 --> Language Class Initialized
DEBUG - 2011-04-06 01:20:58 --> Loader Class Initialized
DEBUG - 2011-04-06 01:20:58 --> Controller Class Initialized
ERROR - 2011-04-06 01:20:58 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-06 01:20:58 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-06 01:20:58 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-06 01:20:58 --> Model Class Initialized
DEBUG - 2011-04-06 01:20:58 --> Model Class Initialized
DEBUG - 2011-04-06 01:20:58 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-06 01:20:58 --> Database Driver Class Initialized
DEBUG - 2011-04-06 01:20:58 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-06 01:20:58 --> Helper loaded: url_helper
DEBUG - 2011-04-06 01:20:58 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-06 01:20:58 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-06 01:20:58 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-06 01:20:58 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-06 01:20:58 --> Final output sent to browser
DEBUG - 2011-04-06 01:20:58 --> Total execution time: 0.0300
DEBUG - 2011-04-06 01:23:28 --> Config Class Initialized
DEBUG - 2011-04-06 01:23:28 --> Hooks Class Initialized
DEBUG - 2011-04-06 01:23:28 --> Utf8 Class Initialized
DEBUG - 2011-04-06 01:23:28 --> UTF-8 Support Enabled
DEBUG - 2011-04-06 01:23:28 --> URI Class Initialized
DEBUG - 2011-04-06 01:23:28 --> Router Class Initialized
DEBUG - 2011-04-06 01:23:28 --> Output Class Initialized
DEBUG - 2011-04-06 01:23:28 --> Input Class Initialized
DEBUG - 2011-04-06 01:23:28 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-06 01:23:28 --> Language Class Initialized
DEBUG - 2011-04-06 01:23:28 --> Loader Class Initialized
DEBUG - 2011-04-06 01:23:28 --> Controller Class Initialized
DEBUG - 2011-04-06 01:23:28 --> Model Class Initialized
DEBUG - 2011-04-06 01:23:28 --> Model Class Initialized
DEBUG - 2011-04-06 01:23:28 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-06 01:23:28 --> Database Driver Class Initialized
DEBUG - 2011-04-06 01:23:29 --> Final output sent to browser
DEBUG - 2011-04-06 01:23:29 --> Total execution time: 0.6085
DEBUG - 2011-04-06 01:27:40 --> Config Class Initialized
DEBUG - 2011-04-06 01:27:40 --> Hooks Class Initialized
DEBUG - 2011-04-06 01:27:40 --> Utf8 Class Initialized
DEBUG - 2011-04-06 01:27:40 --> UTF-8 Support Enabled
DEBUG - 2011-04-06 01:27:40 --> URI Class Initialized
DEBUG - 2011-04-06 01:27:40 --> Router Class Initialized
DEBUG - 2011-04-06 01:27:40 --> Output Class Initialized
DEBUG - 2011-04-06 01:27:40 --> Input Class Initialized
DEBUG - 2011-04-06 01:27:40 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-06 01:27:40 --> Language Class Initialized
DEBUG - 2011-04-06 01:27:40 --> Loader Class Initialized
DEBUG - 2011-04-06 01:27:40 --> Controller Class Initialized
ERROR - 2011-04-06 01:27:40 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-06 01:27:40 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-06 01:27:40 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-06 01:27:40 --> Model Class Initialized
DEBUG - 2011-04-06 01:27:40 --> Model Class Initialized
DEBUG - 2011-04-06 01:27:40 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-06 01:27:40 --> Database Driver Class Initialized
DEBUG - 2011-04-06 01:27:40 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-06 01:27:40 --> Helper loaded: url_helper
DEBUG - 2011-04-06 01:27:40 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-06 01:27:40 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-06 01:27:40 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-06 01:27:40 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-06 01:27:40 --> Final output sent to browser
DEBUG - 2011-04-06 01:27:40 --> Total execution time: 0.0331
DEBUG - 2011-04-06 01:27:41 --> Config Class Initialized
DEBUG - 2011-04-06 01:27:41 --> Hooks Class Initialized
DEBUG - 2011-04-06 01:27:41 --> Utf8 Class Initialized
DEBUG - 2011-04-06 01:27:41 --> UTF-8 Support Enabled
DEBUG - 2011-04-06 01:27:41 --> URI Class Initialized
DEBUG - 2011-04-06 01:27:41 --> Router Class Initialized
DEBUG - 2011-04-06 01:27:41 --> Output Class Initialized
DEBUG - 2011-04-06 01:27:41 --> Input Class Initialized
DEBUG - 2011-04-06 01:27:41 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-06 01:27:41 --> Language Class Initialized
DEBUG - 2011-04-06 01:27:41 --> Loader Class Initialized
DEBUG - 2011-04-06 01:27:41 --> Controller Class Initialized
DEBUG - 2011-04-06 01:27:41 --> Model Class Initialized
DEBUG - 2011-04-06 01:27:41 --> Model Class Initialized
DEBUG - 2011-04-06 01:27:41 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-06 01:27:41 --> Database Driver Class Initialized
DEBUG - 2011-04-06 01:27:42 --> Final output sent to browser
DEBUG - 2011-04-06 01:27:42 --> Total execution time: 0.7133
DEBUG - 2011-04-06 01:27:43 --> Config Class Initialized
DEBUG - 2011-04-06 01:27:43 --> Hooks Class Initialized
DEBUG - 2011-04-06 01:27:43 --> Utf8 Class Initialized
DEBUG - 2011-04-06 01:27:43 --> UTF-8 Support Enabled
DEBUG - 2011-04-06 01:27:43 --> URI Class Initialized
DEBUG - 2011-04-06 01:27:43 --> Router Class Initialized
ERROR - 2011-04-06 01:27:43 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-06 01:27:57 --> Config Class Initialized
DEBUG - 2011-04-06 01:27:57 --> Hooks Class Initialized
DEBUG - 2011-04-06 01:27:57 --> Utf8 Class Initialized
DEBUG - 2011-04-06 01:27:57 --> UTF-8 Support Enabled
DEBUG - 2011-04-06 01:27:57 --> URI Class Initialized
DEBUG - 2011-04-06 01:27:57 --> Router Class Initialized
DEBUG - 2011-04-06 01:27:57 --> Output Class Initialized
DEBUG - 2011-04-06 01:27:57 --> Input Class Initialized
DEBUG - 2011-04-06 01:27:57 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-06 01:27:57 --> Language Class Initialized
DEBUG - 2011-04-06 01:27:57 --> Loader Class Initialized
DEBUG - 2011-04-06 01:27:57 --> Controller Class Initialized
ERROR - 2011-04-06 01:27:57 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-06 01:27:57 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-06 01:27:57 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-06 01:27:57 --> Model Class Initialized
DEBUG - 2011-04-06 01:27:57 --> Model Class Initialized
DEBUG - 2011-04-06 01:27:57 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-06 01:27:57 --> Database Driver Class Initialized
DEBUG - 2011-04-06 01:27:57 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-06 01:27:57 --> Helper loaded: url_helper
DEBUG - 2011-04-06 01:27:57 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-06 01:27:57 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-06 01:27:57 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-06 01:27:57 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-06 01:27:57 --> Final output sent to browser
DEBUG - 2011-04-06 01:27:57 --> Total execution time: 0.0495
DEBUG - 2011-04-06 01:27:58 --> Config Class Initialized
DEBUG - 2011-04-06 01:27:58 --> Hooks Class Initialized
DEBUG - 2011-04-06 01:27:58 --> Utf8 Class Initialized
DEBUG - 2011-04-06 01:27:58 --> UTF-8 Support Enabled
DEBUG - 2011-04-06 01:27:58 --> URI Class Initialized
DEBUG - 2011-04-06 01:27:58 --> Router Class Initialized
DEBUG - 2011-04-06 01:27:58 --> Output Class Initialized
DEBUG - 2011-04-06 01:27:58 --> Input Class Initialized
DEBUG - 2011-04-06 01:27:58 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-06 01:27:58 --> Language Class Initialized
DEBUG - 2011-04-06 01:27:58 --> Loader Class Initialized
DEBUG - 2011-04-06 01:27:58 --> Controller Class Initialized
DEBUG - 2011-04-06 01:27:58 --> Model Class Initialized
DEBUG - 2011-04-06 01:27:58 --> Model Class Initialized
DEBUG - 2011-04-06 01:27:58 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-06 01:27:58 --> Database Driver Class Initialized
DEBUG - 2011-04-06 01:27:59 --> Final output sent to browser
DEBUG - 2011-04-06 01:27:59 --> Total execution time: 0.5454
DEBUG - 2011-04-06 01:28:10 --> Config Class Initialized
DEBUG - 2011-04-06 01:28:10 --> Hooks Class Initialized
DEBUG - 2011-04-06 01:28:10 --> Utf8 Class Initialized
DEBUG - 2011-04-06 01:28:10 --> UTF-8 Support Enabled
DEBUG - 2011-04-06 01:28:10 --> URI Class Initialized
DEBUG - 2011-04-06 01:28:10 --> Router Class Initialized
DEBUG - 2011-04-06 01:28:10 --> Output Class Initialized
DEBUG - 2011-04-06 01:28:10 --> Input Class Initialized
DEBUG - 2011-04-06 01:28:10 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-06 01:28:10 --> Language Class Initialized
DEBUG - 2011-04-06 01:28:10 --> Loader Class Initialized
DEBUG - 2011-04-06 01:28:10 --> Controller Class Initialized
ERROR - 2011-04-06 01:28:10 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-06 01:28:10 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-06 01:28:10 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-06 01:28:10 --> Model Class Initialized
DEBUG - 2011-04-06 01:28:10 --> Model Class Initialized
DEBUG - 2011-04-06 01:28:10 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-06 01:28:10 --> Database Driver Class Initialized
DEBUG - 2011-04-06 01:28:10 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-06 01:28:10 --> Helper loaded: url_helper
DEBUG - 2011-04-06 01:28:10 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-06 01:28:10 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-06 01:28:10 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-06 01:28:10 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-06 01:28:10 --> Final output sent to browser
DEBUG - 2011-04-06 01:28:10 --> Total execution time: 0.0331
DEBUG - 2011-04-06 01:28:11 --> Config Class Initialized
DEBUG - 2011-04-06 01:28:11 --> Hooks Class Initialized
DEBUG - 2011-04-06 01:28:11 --> Utf8 Class Initialized
DEBUG - 2011-04-06 01:28:11 --> UTF-8 Support Enabled
DEBUG - 2011-04-06 01:28:11 --> URI Class Initialized
DEBUG - 2011-04-06 01:28:11 --> Router Class Initialized
DEBUG - 2011-04-06 01:28:11 --> Output Class Initialized
DEBUG - 2011-04-06 01:28:11 --> Input Class Initialized
DEBUG - 2011-04-06 01:28:11 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-06 01:28:11 --> Language Class Initialized
DEBUG - 2011-04-06 01:28:11 --> Loader Class Initialized
DEBUG - 2011-04-06 01:28:11 --> Controller Class Initialized
DEBUG - 2011-04-06 01:28:11 --> Model Class Initialized
DEBUG - 2011-04-06 01:28:11 --> Model Class Initialized
DEBUG - 2011-04-06 01:28:11 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-06 01:28:11 --> Database Driver Class Initialized
DEBUG - 2011-04-06 01:28:12 --> Final output sent to browser
DEBUG - 2011-04-06 01:28:12 --> Total execution time: 0.6239
DEBUG - 2011-04-06 01:28:30 --> Config Class Initialized
DEBUG - 2011-04-06 01:28:30 --> Hooks Class Initialized
DEBUG - 2011-04-06 01:28:30 --> Utf8 Class Initialized
DEBUG - 2011-04-06 01:28:30 --> UTF-8 Support Enabled
DEBUG - 2011-04-06 01:28:30 --> URI Class Initialized
DEBUG - 2011-04-06 01:28:30 --> Router Class Initialized
DEBUG - 2011-04-06 01:28:30 --> Output Class Initialized
DEBUG - 2011-04-06 01:28:30 --> Input Class Initialized
DEBUG - 2011-04-06 01:28:30 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-06 01:28:30 --> Language Class Initialized
DEBUG - 2011-04-06 01:28:30 --> Loader Class Initialized
DEBUG - 2011-04-06 01:28:30 --> Controller Class Initialized
ERROR - 2011-04-06 01:28:30 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-06 01:28:30 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-06 01:28:30 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-06 01:28:30 --> Model Class Initialized
DEBUG - 2011-04-06 01:28:30 --> Model Class Initialized
DEBUG - 2011-04-06 01:28:30 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-06 01:28:30 --> Database Driver Class Initialized
DEBUG - 2011-04-06 01:28:30 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-06 01:28:30 --> Helper loaded: url_helper
DEBUG - 2011-04-06 01:28:30 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-06 01:28:30 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-06 01:28:30 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-06 01:28:30 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-06 01:28:30 --> Final output sent to browser
DEBUG - 2011-04-06 01:28:30 --> Total execution time: 0.0451
DEBUG - 2011-04-06 01:28:31 --> Config Class Initialized
DEBUG - 2011-04-06 01:28:31 --> Hooks Class Initialized
DEBUG - 2011-04-06 01:28:31 --> Utf8 Class Initialized
DEBUG - 2011-04-06 01:28:31 --> UTF-8 Support Enabled
DEBUG - 2011-04-06 01:28:31 --> URI Class Initialized
DEBUG - 2011-04-06 01:28:31 --> Router Class Initialized
DEBUG - 2011-04-06 01:28:31 --> Output Class Initialized
DEBUG - 2011-04-06 01:28:31 --> Input Class Initialized
DEBUG - 2011-04-06 01:28:31 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-06 01:28:31 --> Language Class Initialized
DEBUG - 2011-04-06 01:28:31 --> Loader Class Initialized
DEBUG - 2011-04-06 01:28:31 --> Controller Class Initialized
DEBUG - 2011-04-06 01:28:31 --> Model Class Initialized
DEBUG - 2011-04-06 01:28:31 --> Model Class Initialized
DEBUG - 2011-04-06 01:28:31 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-06 01:28:31 --> Database Driver Class Initialized
DEBUG - 2011-04-06 01:28:32 --> Final output sent to browser
DEBUG - 2011-04-06 01:28:32 --> Total execution time: 1.0287
DEBUG - 2011-04-06 01:28:40 --> Config Class Initialized
DEBUG - 2011-04-06 01:28:40 --> Hooks Class Initialized
DEBUG - 2011-04-06 01:28:40 --> Utf8 Class Initialized
DEBUG - 2011-04-06 01:28:40 --> UTF-8 Support Enabled
DEBUG - 2011-04-06 01:28:40 --> URI Class Initialized
DEBUG - 2011-04-06 01:28:40 --> Router Class Initialized
DEBUG - 2011-04-06 01:28:40 --> Output Class Initialized
DEBUG - 2011-04-06 01:28:40 --> Input Class Initialized
DEBUG - 2011-04-06 01:28:40 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-06 01:28:40 --> Language Class Initialized
DEBUG - 2011-04-06 01:28:40 --> Loader Class Initialized
DEBUG - 2011-04-06 01:28:40 --> Controller Class Initialized
ERROR - 2011-04-06 01:28:40 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-06 01:28:40 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-06 01:28:40 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-06 01:28:40 --> Model Class Initialized
DEBUG - 2011-04-06 01:28:40 --> Model Class Initialized
DEBUG - 2011-04-06 01:28:40 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-06 01:28:40 --> Database Driver Class Initialized
DEBUG - 2011-04-06 01:28:40 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-06 01:28:40 --> Helper loaded: url_helper
DEBUG - 2011-04-06 01:28:40 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-06 01:28:40 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-06 01:28:40 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-06 01:28:40 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-06 01:28:40 --> Final output sent to browser
DEBUG - 2011-04-06 01:28:40 --> Total execution time: 0.0582
DEBUG - 2011-04-06 01:28:41 --> Config Class Initialized
DEBUG - 2011-04-06 01:28:41 --> Hooks Class Initialized
DEBUG - 2011-04-06 01:28:41 --> Utf8 Class Initialized
DEBUG - 2011-04-06 01:28:41 --> UTF-8 Support Enabled
DEBUG - 2011-04-06 01:28:41 --> URI Class Initialized
DEBUG - 2011-04-06 01:28:41 --> Router Class Initialized
DEBUG - 2011-04-06 01:28:41 --> Output Class Initialized
DEBUG - 2011-04-06 01:28:41 --> Input Class Initialized
DEBUG - 2011-04-06 01:28:41 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-06 01:28:41 --> Language Class Initialized
DEBUG - 2011-04-06 01:28:41 --> Loader Class Initialized
DEBUG - 2011-04-06 01:28:41 --> Controller Class Initialized
DEBUG - 2011-04-06 01:28:41 --> Model Class Initialized
DEBUG - 2011-04-06 01:28:41 --> Model Class Initialized
DEBUG - 2011-04-06 01:28:41 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-06 01:28:41 --> Database Driver Class Initialized
DEBUG - 2011-04-06 01:28:41 --> Final output sent to browser
DEBUG - 2011-04-06 01:28:41 --> Total execution time: 0.6412
DEBUG - 2011-04-06 01:28:56 --> Config Class Initialized
DEBUG - 2011-04-06 01:28:56 --> Hooks Class Initialized
DEBUG - 2011-04-06 01:28:56 --> Utf8 Class Initialized
DEBUG - 2011-04-06 01:28:56 --> UTF-8 Support Enabled
DEBUG - 2011-04-06 01:28:56 --> URI Class Initialized
DEBUG - 2011-04-06 01:28:56 --> Router Class Initialized
DEBUG - 2011-04-06 01:28:56 --> Output Class Initialized
DEBUG - 2011-04-06 01:28:56 --> Input Class Initialized
DEBUG - 2011-04-06 01:28:56 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-06 01:28:56 --> Language Class Initialized
DEBUG - 2011-04-06 01:28:56 --> Loader Class Initialized
DEBUG - 2011-04-06 01:28:56 --> Controller Class Initialized
ERROR - 2011-04-06 01:28:56 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-06 01:28:56 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-06 01:28:56 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-06 01:28:56 --> Model Class Initialized
DEBUG - 2011-04-06 01:28:56 --> Model Class Initialized
DEBUG - 2011-04-06 01:28:56 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-06 01:28:56 --> Database Driver Class Initialized
DEBUG - 2011-04-06 01:28:56 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-06 01:28:56 --> Helper loaded: url_helper
DEBUG - 2011-04-06 01:28:56 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-06 01:28:56 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-06 01:28:56 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-06 01:28:56 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-06 01:28:56 --> Final output sent to browser
DEBUG - 2011-04-06 01:28:56 --> Total execution time: 0.0303
DEBUG - 2011-04-06 01:28:56 --> Config Class Initialized
DEBUG - 2011-04-06 01:28:56 --> Hooks Class Initialized
DEBUG - 2011-04-06 01:28:56 --> Utf8 Class Initialized
DEBUG - 2011-04-06 01:28:56 --> UTF-8 Support Enabled
DEBUG - 2011-04-06 01:28:56 --> URI Class Initialized
DEBUG - 2011-04-06 01:28:56 --> Router Class Initialized
DEBUG - 2011-04-06 01:28:56 --> Output Class Initialized
DEBUG - 2011-04-06 01:28:56 --> Input Class Initialized
DEBUG - 2011-04-06 01:28:56 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-06 01:28:56 --> Language Class Initialized
DEBUG - 2011-04-06 01:28:56 --> Loader Class Initialized
DEBUG - 2011-04-06 01:28:56 --> Controller Class Initialized
DEBUG - 2011-04-06 01:28:56 --> Model Class Initialized
DEBUG - 2011-04-06 01:28:56 --> Model Class Initialized
DEBUG - 2011-04-06 01:28:56 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-06 01:28:56 --> Database Driver Class Initialized
DEBUG - 2011-04-06 01:28:57 --> Final output sent to browser
DEBUG - 2011-04-06 01:28:57 --> Total execution time: 0.6991
DEBUG - 2011-04-06 01:29:03 --> Config Class Initialized
DEBUG - 2011-04-06 01:29:03 --> Hooks Class Initialized
DEBUG - 2011-04-06 01:29:03 --> Utf8 Class Initialized
DEBUG - 2011-04-06 01:29:03 --> UTF-8 Support Enabled
DEBUG - 2011-04-06 01:29:03 --> URI Class Initialized
DEBUG - 2011-04-06 01:29:03 --> Router Class Initialized
DEBUG - 2011-04-06 01:29:03 --> Output Class Initialized
DEBUG - 2011-04-06 01:29:03 --> Input Class Initialized
DEBUG - 2011-04-06 01:29:03 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-06 01:29:03 --> Language Class Initialized
DEBUG - 2011-04-06 01:29:03 --> Loader Class Initialized
DEBUG - 2011-04-06 01:29:03 --> Controller Class Initialized
ERROR - 2011-04-06 01:29:03 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-06 01:29:03 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-06 01:29:03 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-06 01:29:03 --> Model Class Initialized
DEBUG - 2011-04-06 01:29:03 --> Model Class Initialized
DEBUG - 2011-04-06 01:29:03 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-06 01:29:03 --> Database Driver Class Initialized
DEBUG - 2011-04-06 01:29:03 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-06 01:29:03 --> Helper loaded: url_helper
DEBUG - 2011-04-06 01:29:03 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-06 01:29:03 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-06 01:29:03 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-06 01:29:03 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-06 01:29:03 --> Final output sent to browser
DEBUG - 2011-04-06 01:29:03 --> Total execution time: 0.0285
DEBUG - 2011-04-06 01:29:04 --> Config Class Initialized
DEBUG - 2011-04-06 01:29:04 --> Hooks Class Initialized
DEBUG - 2011-04-06 01:29:04 --> Utf8 Class Initialized
DEBUG - 2011-04-06 01:29:04 --> UTF-8 Support Enabled
DEBUG - 2011-04-06 01:29:04 --> URI Class Initialized
DEBUG - 2011-04-06 01:29:04 --> Router Class Initialized
DEBUG - 2011-04-06 01:29:04 --> Output Class Initialized
DEBUG - 2011-04-06 01:29:04 --> Input Class Initialized
DEBUG - 2011-04-06 01:29:04 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-06 01:29:04 --> Language Class Initialized
DEBUG - 2011-04-06 01:29:04 --> Loader Class Initialized
DEBUG - 2011-04-06 01:29:04 --> Controller Class Initialized
DEBUG - 2011-04-06 01:29:04 --> Model Class Initialized
DEBUG - 2011-04-06 01:29:04 --> Model Class Initialized
DEBUG - 2011-04-06 01:29:04 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-06 01:29:04 --> Database Driver Class Initialized
DEBUG - 2011-04-06 01:29:04 --> Final output sent to browser
DEBUG - 2011-04-06 01:29:04 --> Total execution time: 0.6899
DEBUG - 2011-04-06 01:29:10 --> Config Class Initialized
DEBUG - 2011-04-06 01:29:10 --> Hooks Class Initialized
DEBUG - 2011-04-06 01:29:10 --> Utf8 Class Initialized
DEBUG - 2011-04-06 01:29:10 --> UTF-8 Support Enabled
DEBUG - 2011-04-06 01:29:10 --> URI Class Initialized
DEBUG - 2011-04-06 01:29:10 --> Router Class Initialized
DEBUG - 2011-04-06 01:29:10 --> Output Class Initialized
DEBUG - 2011-04-06 01:29:10 --> Input Class Initialized
DEBUG - 2011-04-06 01:29:10 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-06 01:29:10 --> Language Class Initialized
DEBUG - 2011-04-06 01:29:10 --> Loader Class Initialized
DEBUG - 2011-04-06 01:29:10 --> Controller Class Initialized
ERROR - 2011-04-06 01:29:10 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-06 01:29:10 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-06 01:29:10 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-06 01:29:10 --> Model Class Initialized
DEBUG - 2011-04-06 01:29:10 --> Model Class Initialized
DEBUG - 2011-04-06 01:29:10 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-06 01:29:10 --> Database Driver Class Initialized
DEBUG - 2011-04-06 01:29:10 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-06 01:29:10 --> Helper loaded: url_helper
DEBUG - 2011-04-06 01:29:10 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-06 01:29:10 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-06 01:29:10 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-06 01:29:10 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-06 01:29:10 --> Final output sent to browser
DEBUG - 2011-04-06 01:29:10 --> Total execution time: 0.0714
DEBUG - 2011-04-06 01:29:11 --> Config Class Initialized
DEBUG - 2011-04-06 01:29:11 --> Hooks Class Initialized
DEBUG - 2011-04-06 01:29:11 --> Utf8 Class Initialized
DEBUG - 2011-04-06 01:29:11 --> UTF-8 Support Enabled
DEBUG - 2011-04-06 01:29:11 --> URI Class Initialized
DEBUG - 2011-04-06 01:29:11 --> Router Class Initialized
DEBUG - 2011-04-06 01:29:11 --> Output Class Initialized
DEBUG - 2011-04-06 01:29:11 --> Input Class Initialized
DEBUG - 2011-04-06 01:29:11 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-06 01:29:11 --> Language Class Initialized
DEBUG - 2011-04-06 01:29:11 --> Loader Class Initialized
DEBUG - 2011-04-06 01:29:11 --> Controller Class Initialized
DEBUG - 2011-04-06 01:29:11 --> Model Class Initialized
DEBUG - 2011-04-06 01:29:11 --> Model Class Initialized
DEBUG - 2011-04-06 01:29:11 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-06 01:29:11 --> Database Driver Class Initialized
DEBUG - 2011-04-06 01:29:12 --> Final output sent to browser
DEBUG - 2011-04-06 01:29:12 --> Total execution time: 0.7086
DEBUG - 2011-04-06 01:29:16 --> Config Class Initialized
DEBUG - 2011-04-06 01:29:16 --> Hooks Class Initialized
DEBUG - 2011-04-06 01:29:16 --> Utf8 Class Initialized
DEBUG - 2011-04-06 01:29:16 --> UTF-8 Support Enabled
DEBUG - 2011-04-06 01:29:16 --> URI Class Initialized
DEBUG - 2011-04-06 01:29:16 --> Router Class Initialized
DEBUG - 2011-04-06 01:29:16 --> Output Class Initialized
DEBUG - 2011-04-06 01:29:16 --> Input Class Initialized
DEBUG - 2011-04-06 01:29:16 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-06 01:29:16 --> Language Class Initialized
DEBUG - 2011-04-06 01:29:16 --> Loader Class Initialized
DEBUG - 2011-04-06 01:29:16 --> Controller Class Initialized
ERROR - 2011-04-06 01:29:16 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-06 01:29:16 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-06 01:29:16 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-06 01:29:16 --> Model Class Initialized
DEBUG - 2011-04-06 01:29:16 --> Model Class Initialized
DEBUG - 2011-04-06 01:29:16 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-06 01:29:16 --> Database Driver Class Initialized
DEBUG - 2011-04-06 01:29:16 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-06 01:29:16 --> Helper loaded: url_helper
DEBUG - 2011-04-06 01:29:16 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-06 01:29:16 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-06 01:29:16 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-06 01:29:16 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-06 01:29:16 --> Final output sent to browser
DEBUG - 2011-04-06 01:29:16 --> Total execution time: 0.0289
DEBUG - 2011-04-06 01:29:17 --> Config Class Initialized
DEBUG - 2011-04-06 01:29:17 --> Hooks Class Initialized
DEBUG - 2011-04-06 01:29:17 --> Utf8 Class Initialized
DEBUG - 2011-04-06 01:29:17 --> UTF-8 Support Enabled
DEBUG - 2011-04-06 01:29:17 --> URI Class Initialized
DEBUG - 2011-04-06 01:29:17 --> Router Class Initialized
DEBUG - 2011-04-06 01:29:17 --> Output Class Initialized
DEBUG - 2011-04-06 01:29:17 --> Input Class Initialized
DEBUG - 2011-04-06 01:29:17 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-06 01:29:17 --> Language Class Initialized
DEBUG - 2011-04-06 01:29:17 --> Loader Class Initialized
DEBUG - 2011-04-06 01:29:17 --> Controller Class Initialized
DEBUG - 2011-04-06 01:29:17 --> Model Class Initialized
DEBUG - 2011-04-06 01:29:17 --> Model Class Initialized
DEBUG - 2011-04-06 01:29:17 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-06 01:29:17 --> Database Driver Class Initialized
DEBUG - 2011-04-06 01:29:18 --> Final output sent to browser
DEBUG - 2011-04-06 01:29:18 --> Total execution time: 1.4435
DEBUG - 2011-04-06 01:29:23 --> Config Class Initialized
DEBUG - 2011-04-06 01:29:23 --> Hooks Class Initialized
DEBUG - 2011-04-06 01:29:23 --> Utf8 Class Initialized
DEBUG - 2011-04-06 01:29:23 --> UTF-8 Support Enabled
DEBUG - 2011-04-06 01:29:23 --> URI Class Initialized
DEBUG - 2011-04-06 01:29:23 --> Router Class Initialized
DEBUG - 2011-04-06 01:29:23 --> Output Class Initialized
DEBUG - 2011-04-06 01:29:23 --> Input Class Initialized
DEBUG - 2011-04-06 01:29:23 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-06 01:29:23 --> Language Class Initialized
DEBUG - 2011-04-06 01:29:23 --> Loader Class Initialized
DEBUG - 2011-04-06 01:29:23 --> Controller Class Initialized
DEBUG - 2011-04-06 01:29:23 --> Model Class Initialized
DEBUG - 2011-04-06 01:29:23 --> Model Class Initialized
DEBUG - 2011-04-06 01:29:23 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-06 01:29:23 --> Database Driver Class Initialized
DEBUG - 2011-04-06 01:29:24 --> Final output sent to browser
DEBUG - 2011-04-06 01:29:24 --> Total execution time: 0.6551
DEBUG - 2011-04-06 01:29:25 --> Config Class Initialized
DEBUG - 2011-04-06 01:29:25 --> Hooks Class Initialized
DEBUG - 2011-04-06 01:29:25 --> Utf8 Class Initialized
DEBUG - 2011-04-06 01:29:25 --> UTF-8 Support Enabled
DEBUG - 2011-04-06 01:29:25 --> URI Class Initialized
DEBUG - 2011-04-06 01:29:25 --> Router Class Initialized
DEBUG - 2011-04-06 01:29:25 --> Output Class Initialized
DEBUG - 2011-04-06 01:29:25 --> Input Class Initialized
DEBUG - 2011-04-06 01:29:25 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-06 01:29:25 --> Language Class Initialized
DEBUG - 2011-04-06 01:29:25 --> Loader Class Initialized
DEBUG - 2011-04-06 01:29:25 --> Controller Class Initialized
ERROR - 2011-04-06 01:29:25 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-06 01:29:25 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-06 01:29:25 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-06 01:29:25 --> Model Class Initialized
DEBUG - 2011-04-06 01:29:25 --> Model Class Initialized
DEBUG - 2011-04-06 01:29:25 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-06 01:29:25 --> Database Driver Class Initialized
DEBUG - 2011-04-06 01:29:25 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-06 01:29:25 --> Helper loaded: url_helper
DEBUG - 2011-04-06 01:29:25 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-06 01:29:25 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-06 01:29:25 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-06 01:29:25 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-06 01:29:25 --> Final output sent to browser
DEBUG - 2011-04-06 01:29:25 --> Total execution time: 0.0318
DEBUG - 2011-04-06 01:29:25 --> Config Class Initialized
DEBUG - 2011-04-06 01:29:25 --> Hooks Class Initialized
DEBUG - 2011-04-06 01:29:25 --> Utf8 Class Initialized
DEBUG - 2011-04-06 01:29:25 --> UTF-8 Support Enabled
DEBUG - 2011-04-06 01:29:25 --> URI Class Initialized
DEBUG - 2011-04-06 01:29:25 --> Router Class Initialized
DEBUG - 2011-04-06 01:29:25 --> Output Class Initialized
DEBUG - 2011-04-06 01:29:25 --> Input Class Initialized
DEBUG - 2011-04-06 01:29:25 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-06 01:29:25 --> Language Class Initialized
DEBUG - 2011-04-06 01:29:25 --> Loader Class Initialized
DEBUG - 2011-04-06 01:29:25 --> Controller Class Initialized
DEBUG - 2011-04-06 01:29:25 --> Model Class Initialized
DEBUG - 2011-04-06 01:29:25 --> Model Class Initialized
DEBUG - 2011-04-06 01:29:25 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-06 01:29:25 --> Database Driver Class Initialized
DEBUG - 2011-04-06 01:29:26 --> Final output sent to browser
DEBUG - 2011-04-06 01:29:26 --> Total execution time: 0.5635
DEBUG - 2011-04-06 01:29:32 --> Config Class Initialized
DEBUG - 2011-04-06 01:29:32 --> Hooks Class Initialized
DEBUG - 2011-04-06 01:29:32 --> Utf8 Class Initialized
DEBUG - 2011-04-06 01:29:32 --> UTF-8 Support Enabled
DEBUG - 2011-04-06 01:29:32 --> URI Class Initialized
DEBUG - 2011-04-06 01:29:32 --> Router Class Initialized
DEBUG - 2011-04-06 01:29:32 --> Output Class Initialized
DEBUG - 2011-04-06 01:29:32 --> Input Class Initialized
DEBUG - 2011-04-06 01:29:32 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-06 01:29:32 --> Language Class Initialized
DEBUG - 2011-04-06 01:29:32 --> Loader Class Initialized
DEBUG - 2011-04-06 01:29:32 --> Controller Class Initialized
ERROR - 2011-04-06 01:29:32 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-06 01:29:32 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-06 01:29:32 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-06 01:29:32 --> Model Class Initialized
DEBUG - 2011-04-06 01:29:32 --> Model Class Initialized
DEBUG - 2011-04-06 01:29:32 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-06 01:29:32 --> Database Driver Class Initialized
DEBUG - 2011-04-06 01:29:32 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-06 01:29:32 --> Helper loaded: url_helper
DEBUG - 2011-04-06 01:29:32 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-06 01:29:32 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-06 01:29:32 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-06 01:29:32 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-06 01:29:32 --> Final output sent to browser
DEBUG - 2011-04-06 01:29:32 --> Total execution time: 0.0309
DEBUG - 2011-04-06 01:29:33 --> Config Class Initialized
DEBUG - 2011-04-06 01:29:33 --> Hooks Class Initialized
DEBUG - 2011-04-06 01:29:33 --> Utf8 Class Initialized
DEBUG - 2011-04-06 01:29:33 --> UTF-8 Support Enabled
DEBUG - 2011-04-06 01:29:33 --> URI Class Initialized
DEBUG - 2011-04-06 01:29:33 --> Router Class Initialized
DEBUG - 2011-04-06 01:29:33 --> Output Class Initialized
DEBUG - 2011-04-06 01:29:33 --> Input Class Initialized
DEBUG - 2011-04-06 01:29:33 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-06 01:29:33 --> Language Class Initialized
DEBUG - 2011-04-06 01:29:33 --> Loader Class Initialized
DEBUG - 2011-04-06 01:29:33 --> Controller Class Initialized
DEBUG - 2011-04-06 01:29:33 --> Model Class Initialized
DEBUG - 2011-04-06 01:29:33 --> Model Class Initialized
DEBUG - 2011-04-06 01:29:33 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-06 01:29:33 --> Database Driver Class Initialized
DEBUG - 2011-04-06 01:29:34 --> Final output sent to browser
DEBUG - 2011-04-06 01:29:34 --> Total execution time: 0.5784
DEBUG - 2011-04-06 01:29:47 --> Config Class Initialized
DEBUG - 2011-04-06 01:29:47 --> Hooks Class Initialized
DEBUG - 2011-04-06 01:29:47 --> Utf8 Class Initialized
DEBUG - 2011-04-06 01:29:47 --> UTF-8 Support Enabled
DEBUG - 2011-04-06 01:29:47 --> URI Class Initialized
DEBUG - 2011-04-06 01:29:47 --> Router Class Initialized
DEBUG - 2011-04-06 01:29:47 --> Output Class Initialized
DEBUG - 2011-04-06 01:29:47 --> Input Class Initialized
DEBUG - 2011-04-06 01:29:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-06 01:29:47 --> Language Class Initialized
DEBUG - 2011-04-06 01:29:47 --> Loader Class Initialized
DEBUG - 2011-04-06 01:29:47 --> Controller Class Initialized
ERROR - 2011-04-06 01:29:47 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-06 01:29:47 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-06 01:29:47 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-06 01:29:47 --> Model Class Initialized
DEBUG - 2011-04-06 01:29:47 --> Model Class Initialized
DEBUG - 2011-04-06 01:29:47 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-06 01:29:47 --> Database Driver Class Initialized
DEBUG - 2011-04-06 01:29:47 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-06 01:29:47 --> Helper loaded: url_helper
DEBUG - 2011-04-06 01:29:47 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-06 01:29:47 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-06 01:29:47 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-06 01:29:47 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-06 01:29:47 --> Final output sent to browser
DEBUG - 2011-04-06 01:29:47 --> Total execution time: 0.0275
DEBUG - 2011-04-06 01:29:47 --> Config Class Initialized
DEBUG - 2011-04-06 01:29:47 --> Hooks Class Initialized
DEBUG - 2011-04-06 01:29:47 --> Utf8 Class Initialized
DEBUG - 2011-04-06 01:29:47 --> UTF-8 Support Enabled
DEBUG - 2011-04-06 01:29:47 --> URI Class Initialized
DEBUG - 2011-04-06 01:29:47 --> Router Class Initialized
DEBUG - 2011-04-06 01:29:47 --> Output Class Initialized
DEBUG - 2011-04-06 01:29:47 --> Input Class Initialized
DEBUG - 2011-04-06 01:29:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-06 01:29:47 --> Language Class Initialized
DEBUG - 2011-04-06 01:29:47 --> Loader Class Initialized
DEBUG - 2011-04-06 01:29:47 --> Controller Class Initialized
DEBUG - 2011-04-06 01:29:47 --> Model Class Initialized
DEBUG - 2011-04-06 01:29:47 --> Model Class Initialized
DEBUG - 2011-04-06 01:29:47 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-06 01:29:47 --> Database Driver Class Initialized
DEBUG - 2011-04-06 01:29:48 --> Config Class Initialized
DEBUG - 2011-04-06 01:29:48 --> Hooks Class Initialized
DEBUG - 2011-04-06 01:29:48 --> Utf8 Class Initialized
DEBUG - 2011-04-06 01:29:48 --> UTF-8 Support Enabled
DEBUG - 2011-04-06 01:29:48 --> URI Class Initialized
DEBUG - 2011-04-06 01:29:48 --> Router Class Initialized
DEBUG - 2011-04-06 01:29:48 --> Output Class Initialized
DEBUG - 2011-04-06 01:29:48 --> Input Class Initialized
DEBUG - 2011-04-06 01:29:48 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-06 01:29:48 --> Language Class Initialized
DEBUG - 2011-04-06 01:29:48 --> Loader Class Initialized
DEBUG - 2011-04-06 01:29:48 --> Controller Class Initialized
ERROR - 2011-04-06 01:29:48 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-06 01:29:48 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-06 01:29:48 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-06 01:29:48 --> Model Class Initialized
DEBUG - 2011-04-06 01:29:48 --> Model Class Initialized
DEBUG - 2011-04-06 01:29:48 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-06 01:29:48 --> Database Driver Class Initialized
DEBUG - 2011-04-06 01:29:48 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-06 01:29:48 --> Helper loaded: url_helper
DEBUG - 2011-04-06 01:29:48 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-06 01:29:48 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-06 01:29:48 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-06 01:29:48 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-06 01:29:48 --> Final output sent to browser
DEBUG - 2011-04-06 01:29:48 --> Final output sent to browser
DEBUG - 2011-04-06 01:29:48 --> Total execution time: 0.6154
DEBUG - 2011-04-06 01:29:48 --> Total execution time: 0.0286
DEBUG - 2011-04-06 01:29:53 --> Config Class Initialized
DEBUG - 2011-04-06 01:29:53 --> Hooks Class Initialized
DEBUG - 2011-04-06 01:29:53 --> Utf8 Class Initialized
DEBUG - 2011-04-06 01:29:53 --> UTF-8 Support Enabled
DEBUG - 2011-04-06 01:29:53 --> URI Class Initialized
DEBUG - 2011-04-06 01:29:53 --> Router Class Initialized
DEBUG - 2011-04-06 01:29:53 --> Output Class Initialized
DEBUG - 2011-04-06 01:29:53 --> Input Class Initialized
DEBUG - 2011-04-06 01:29:53 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-06 01:29:53 --> Language Class Initialized
DEBUG - 2011-04-06 01:29:53 --> Loader Class Initialized
DEBUG - 2011-04-06 01:29:53 --> Controller Class Initialized
ERROR - 2011-04-06 01:29:53 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-06 01:29:53 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-06 01:29:53 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-06 01:29:53 --> Model Class Initialized
DEBUG - 2011-04-06 01:29:53 --> Model Class Initialized
DEBUG - 2011-04-06 01:29:53 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-06 01:29:53 --> Database Driver Class Initialized
DEBUG - 2011-04-06 01:29:53 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-06 01:29:53 --> Helper loaded: url_helper
DEBUG - 2011-04-06 01:29:53 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-06 01:29:53 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-06 01:29:53 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-06 01:29:53 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-06 01:29:53 --> Final output sent to browser
DEBUG - 2011-04-06 01:29:53 --> Total execution time: 0.0272
DEBUG - 2011-04-06 01:29:53 --> Config Class Initialized
DEBUG - 2011-04-06 01:29:53 --> Hooks Class Initialized
DEBUG - 2011-04-06 01:29:53 --> Utf8 Class Initialized
DEBUG - 2011-04-06 01:29:53 --> UTF-8 Support Enabled
DEBUG - 2011-04-06 01:29:53 --> URI Class Initialized
DEBUG - 2011-04-06 01:29:53 --> Router Class Initialized
DEBUG - 2011-04-06 01:29:53 --> Output Class Initialized
DEBUG - 2011-04-06 01:29:53 --> Input Class Initialized
DEBUG - 2011-04-06 01:29:53 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-06 01:29:53 --> Language Class Initialized
DEBUG - 2011-04-06 01:29:53 --> Loader Class Initialized
DEBUG - 2011-04-06 01:29:53 --> Controller Class Initialized
DEBUG - 2011-04-06 01:29:53 --> Model Class Initialized
DEBUG - 2011-04-06 01:29:53 --> Model Class Initialized
DEBUG - 2011-04-06 01:29:53 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-06 01:29:53 --> Database Driver Class Initialized
DEBUG - 2011-04-06 01:29:54 --> Config Class Initialized
DEBUG - 2011-04-06 01:29:54 --> Hooks Class Initialized
DEBUG - 2011-04-06 01:29:54 --> Utf8 Class Initialized
DEBUG - 2011-04-06 01:29:54 --> UTF-8 Support Enabled
DEBUG - 2011-04-06 01:29:54 --> URI Class Initialized
DEBUG - 2011-04-06 01:29:54 --> Router Class Initialized
DEBUG - 2011-04-06 01:29:54 --> Output Class Initialized
DEBUG - 2011-04-06 01:29:54 --> Input Class Initialized
DEBUG - 2011-04-06 01:29:54 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-06 01:29:54 --> Language Class Initialized
DEBUG - 2011-04-06 01:29:54 --> Loader Class Initialized
DEBUG - 2011-04-06 01:29:54 --> Controller Class Initialized
ERROR - 2011-04-06 01:29:54 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-06 01:29:54 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-06 01:29:54 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-06 01:29:54 --> Model Class Initialized
DEBUG - 2011-04-06 01:29:54 --> Model Class Initialized
DEBUG - 2011-04-06 01:29:54 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-06 01:29:54 --> Database Driver Class Initialized
DEBUG - 2011-04-06 01:29:54 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-06 01:29:54 --> Helper loaded: url_helper
DEBUG - 2011-04-06 01:29:54 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-06 01:29:54 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-06 01:29:54 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-06 01:29:54 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-06 01:29:54 --> Final output sent to browser
DEBUG - 2011-04-06 01:29:54 --> Total execution time: 0.0290
DEBUG - 2011-04-06 01:29:54 --> Final output sent to browser
DEBUG - 2011-04-06 01:29:54 --> Total execution time: 0.6402
DEBUG - 2011-04-06 01:37:21 --> Config Class Initialized
DEBUG - 2011-04-06 01:37:21 --> Hooks Class Initialized
DEBUG - 2011-04-06 01:37:21 --> Utf8 Class Initialized
DEBUG - 2011-04-06 01:37:21 --> UTF-8 Support Enabled
DEBUG - 2011-04-06 01:37:21 --> URI Class Initialized
DEBUG - 2011-04-06 01:37:21 --> Router Class Initialized
DEBUG - 2011-04-06 01:37:21 --> Output Class Initialized
DEBUG - 2011-04-06 01:37:21 --> Input Class Initialized
DEBUG - 2011-04-06 01:37:21 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-06 01:37:21 --> Language Class Initialized
DEBUG - 2011-04-06 01:37:21 --> Loader Class Initialized
DEBUG - 2011-04-06 01:37:21 --> Controller Class Initialized
DEBUG - 2011-04-06 01:37:21 --> Model Class Initialized
DEBUG - 2011-04-06 01:37:21 --> Model Class Initialized
DEBUG - 2011-04-06 01:37:21 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-06 01:37:21 --> Database Driver Class Initialized
DEBUG - 2011-04-06 01:37:21 --> Final output sent to browser
DEBUG - 2011-04-06 01:37:21 --> Total execution time: 0.7253
DEBUG - 2011-04-06 02:00:13 --> Config Class Initialized
DEBUG - 2011-04-06 02:00:13 --> Hooks Class Initialized
DEBUG - 2011-04-06 02:00:13 --> Utf8 Class Initialized
DEBUG - 2011-04-06 02:00:13 --> UTF-8 Support Enabled
DEBUG - 2011-04-06 02:00:13 --> URI Class Initialized
DEBUG - 2011-04-06 02:00:13 --> Router Class Initialized
DEBUG - 2011-04-06 02:00:13 --> No URI present. Default controller set.
DEBUG - 2011-04-06 02:00:13 --> Output Class Initialized
DEBUG - 2011-04-06 02:00:13 --> Input Class Initialized
DEBUG - 2011-04-06 02:00:13 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-06 02:00:13 --> Language Class Initialized
DEBUG - 2011-04-06 02:00:13 --> Loader Class Initialized
DEBUG - 2011-04-06 02:00:13 --> Controller Class Initialized
DEBUG - 2011-04-06 02:00:13 --> File loaded: application/views/splash/main.php
DEBUG - 2011-04-06 02:00:14 --> Helper loaded: url_helper
DEBUG - 2011-04-06 02:00:14 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-06 02:00:14 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-06 02:00:14 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-06 02:00:14 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-06 02:00:14 --> Final output sent to browser
DEBUG - 2011-04-06 02:00:14 --> Total execution time: 0.4342
DEBUG - 2011-04-06 03:20:55 --> Config Class Initialized
DEBUG - 2011-04-06 03:20:55 --> Hooks Class Initialized
DEBUG - 2011-04-06 03:20:55 --> Utf8 Class Initialized
DEBUG - 2011-04-06 03:20:55 --> UTF-8 Support Enabled
DEBUG - 2011-04-06 03:20:55 --> URI Class Initialized
DEBUG - 2011-04-06 03:20:55 --> Router Class Initialized
DEBUG - 2011-04-06 03:20:55 --> No URI present. Default controller set.
DEBUG - 2011-04-06 03:20:55 --> Output Class Initialized
DEBUG - 2011-04-06 03:20:55 --> Input Class Initialized
DEBUG - 2011-04-06 03:20:55 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-06 03:20:55 --> Language Class Initialized
DEBUG - 2011-04-06 03:20:55 --> Loader Class Initialized
DEBUG - 2011-04-06 03:20:55 --> Controller Class Initialized
DEBUG - 2011-04-06 03:20:55 --> File loaded: application/views/splash/main.php
DEBUG - 2011-04-06 03:20:55 --> Helper loaded: url_helper
DEBUG - 2011-04-06 03:20:55 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-06 03:20:55 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-06 03:20:55 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-06 03:20:55 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-06 03:20:55 --> Final output sent to browser
DEBUG - 2011-04-06 03:20:55 --> Total execution time: 0.3145
DEBUG - 2011-04-06 03:20:56 --> Config Class Initialized
DEBUG - 2011-04-06 03:20:56 --> Hooks Class Initialized
DEBUG - 2011-04-06 03:20:56 --> Utf8 Class Initialized
DEBUG - 2011-04-06 03:20:56 --> UTF-8 Support Enabled
DEBUG - 2011-04-06 03:20:56 --> URI Class Initialized
DEBUG - 2011-04-06 03:20:56 --> Router Class Initialized
ERROR - 2011-04-06 03:20:56 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-06 03:20:56 --> Config Class Initialized
DEBUG - 2011-04-06 03:20:56 --> Hooks Class Initialized
DEBUG - 2011-04-06 03:20:56 --> Utf8 Class Initialized
DEBUG - 2011-04-06 03:20:56 --> UTF-8 Support Enabled
DEBUG - 2011-04-06 03:20:56 --> URI Class Initialized
DEBUG - 2011-04-06 03:20:56 --> Router Class Initialized
ERROR - 2011-04-06 03:20:56 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-06 03:22:13 --> Config Class Initialized
DEBUG - 2011-04-06 03:22:13 --> Hooks Class Initialized
DEBUG - 2011-04-06 03:22:13 --> Utf8 Class Initialized
DEBUG - 2011-04-06 03:22:13 --> UTF-8 Support Enabled
DEBUG - 2011-04-06 03:22:13 --> URI Class Initialized
DEBUG - 2011-04-06 03:22:13 --> Router Class Initialized
DEBUG - 2011-04-06 03:22:15 --> Output Class Initialized
DEBUG - 2011-04-06 03:22:15 --> Input Class Initialized
DEBUG - 2011-04-06 03:22:15 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-06 03:22:15 --> Language Class Initialized
DEBUG - 2011-04-06 03:22:15 --> Loader Class Initialized
DEBUG - 2011-04-06 03:22:15 --> Controller Class Initialized
ERROR - 2011-04-06 03:22:16 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-06 03:22:16 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-06 03:22:16 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-06 03:22:17 --> Model Class Initialized
DEBUG - 2011-04-06 03:22:17 --> Model Class Initialized
DEBUG - 2011-04-06 03:22:17 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-06 03:22:17 --> Database Driver Class Initialized
DEBUG - 2011-04-06 03:22:18 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-06 03:22:18 --> Helper loaded: url_helper
DEBUG - 2011-04-06 03:22:18 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-06 03:22:18 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-06 03:22:18 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-06 03:22:18 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-06 03:22:18 --> Final output sent to browser
DEBUG - 2011-04-06 03:22:18 --> Total execution time: 4.9127
DEBUG - 2011-04-06 03:22:19 --> Config Class Initialized
DEBUG - 2011-04-06 03:22:19 --> Hooks Class Initialized
DEBUG - 2011-04-06 03:22:19 --> Utf8 Class Initialized
DEBUG - 2011-04-06 03:22:19 --> UTF-8 Support Enabled
DEBUG - 2011-04-06 03:22:19 --> URI Class Initialized
DEBUG - 2011-04-06 03:22:19 --> Router Class Initialized
DEBUG - 2011-04-06 03:22:19 --> Output Class Initialized
DEBUG - 2011-04-06 03:22:19 --> Input Class Initialized
DEBUG - 2011-04-06 03:22:19 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-06 03:22:19 --> Language Class Initialized
DEBUG - 2011-04-06 03:22:19 --> Loader Class Initialized
DEBUG - 2011-04-06 03:22:19 --> Controller Class Initialized
DEBUG - 2011-04-06 03:22:19 --> Model Class Initialized
DEBUG - 2011-04-06 03:22:19 --> Model Class Initialized
DEBUG - 2011-04-06 03:22:19 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-06 03:22:19 --> Database Driver Class Initialized
DEBUG - 2011-04-06 03:22:25 --> Final output sent to browser
DEBUG - 2011-04-06 03:22:25 --> Total execution time: 6.5271
DEBUG - 2011-04-06 03:22:38 --> Config Class Initialized
DEBUG - 2011-04-06 03:22:38 --> Hooks Class Initialized
DEBUG - 2011-04-06 03:22:38 --> Utf8 Class Initialized
DEBUG - 2011-04-06 03:22:38 --> UTF-8 Support Enabled
DEBUG - 2011-04-06 03:22:38 --> URI Class Initialized
DEBUG - 2011-04-06 03:22:38 --> Router Class Initialized
DEBUG - 2011-04-06 03:22:38 --> Output Class Initialized
DEBUG - 2011-04-06 03:22:38 --> Input Class Initialized
DEBUG - 2011-04-06 03:22:38 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-06 03:22:38 --> Language Class Initialized
DEBUG - 2011-04-06 03:22:38 --> Loader Class Initialized
DEBUG - 2011-04-06 03:22:38 --> Controller Class Initialized
ERROR - 2011-04-06 03:22:38 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-06 03:22:38 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-06 03:22:38 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-06 03:22:38 --> Model Class Initialized
DEBUG - 2011-04-06 03:22:38 --> Model Class Initialized
DEBUG - 2011-04-06 03:22:38 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-06 03:22:38 --> Database Driver Class Initialized
DEBUG - 2011-04-06 03:22:38 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-06 03:22:38 --> Helper loaded: url_helper
DEBUG - 2011-04-06 03:22:38 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-06 03:22:38 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-06 03:22:38 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-06 03:22:38 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-06 03:22:38 --> Final output sent to browser
DEBUG - 2011-04-06 03:22:38 --> Total execution time: 0.0289
DEBUG - 2011-04-06 03:22:39 --> Config Class Initialized
DEBUG - 2011-04-06 03:22:39 --> Hooks Class Initialized
DEBUG - 2011-04-06 03:22:39 --> Utf8 Class Initialized
DEBUG - 2011-04-06 03:22:39 --> UTF-8 Support Enabled
DEBUG - 2011-04-06 03:22:39 --> URI Class Initialized
DEBUG - 2011-04-06 03:22:39 --> Router Class Initialized
DEBUG - 2011-04-06 03:22:39 --> Output Class Initialized
DEBUG - 2011-04-06 03:22:39 --> Input Class Initialized
DEBUG - 2011-04-06 03:22:39 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-06 03:22:39 --> Language Class Initialized
DEBUG - 2011-04-06 03:22:39 --> Loader Class Initialized
DEBUG - 2011-04-06 03:22:39 --> Controller Class Initialized
DEBUG - 2011-04-06 03:22:39 --> Model Class Initialized
DEBUG - 2011-04-06 03:22:39 --> Model Class Initialized
DEBUG - 2011-04-06 03:22:39 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-06 03:22:39 --> Database Driver Class Initialized
DEBUG - 2011-04-06 03:22:43 --> Final output sent to browser
DEBUG - 2011-04-06 03:22:43 --> Total execution time: 4.0416
DEBUG - 2011-04-06 03:25:00 --> Config Class Initialized
DEBUG - 2011-04-06 03:25:00 --> Hooks Class Initialized
DEBUG - 2011-04-06 03:25:00 --> Utf8 Class Initialized
DEBUG - 2011-04-06 03:25:00 --> UTF-8 Support Enabled
DEBUG - 2011-04-06 03:25:00 --> URI Class Initialized
DEBUG - 2011-04-06 03:25:00 --> Router Class Initialized
DEBUG - 2011-04-06 03:25:00 --> Output Class Initialized
DEBUG - 2011-04-06 03:25:00 --> Input Class Initialized
DEBUG - 2011-04-06 03:25:00 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-06 03:25:00 --> Language Class Initialized
DEBUG - 2011-04-06 03:25:00 --> Loader Class Initialized
DEBUG - 2011-04-06 03:25:00 --> Controller Class Initialized
ERROR - 2011-04-06 03:25:00 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-06 03:25:00 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-06 03:25:00 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-06 03:25:00 --> Model Class Initialized
DEBUG - 2011-04-06 03:25:00 --> Model Class Initialized
DEBUG - 2011-04-06 03:25:00 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-06 03:25:00 --> Database Driver Class Initialized
DEBUG - 2011-04-06 03:25:00 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-06 03:25:00 --> Helper loaded: url_helper
DEBUG - 2011-04-06 03:25:00 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-06 03:25:00 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-06 03:25:00 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-06 03:25:00 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-06 03:25:00 --> Final output sent to browser
DEBUG - 2011-04-06 03:25:00 --> Total execution time: 0.0575
DEBUG - 2011-04-06 03:25:01 --> Config Class Initialized
DEBUG - 2011-04-06 03:25:01 --> Hooks Class Initialized
DEBUG - 2011-04-06 03:25:01 --> Utf8 Class Initialized
DEBUG - 2011-04-06 03:25:01 --> UTF-8 Support Enabled
DEBUG - 2011-04-06 03:25:01 --> URI Class Initialized
DEBUG - 2011-04-06 03:25:01 --> Router Class Initialized
DEBUG - 2011-04-06 03:25:01 --> Output Class Initialized
DEBUG - 2011-04-06 03:25:01 --> Input Class Initialized
DEBUG - 2011-04-06 03:25:01 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-06 03:25:01 --> Language Class Initialized
DEBUG - 2011-04-06 03:25:01 --> Loader Class Initialized
DEBUG - 2011-04-06 03:25:01 --> Controller Class Initialized
DEBUG - 2011-04-06 03:25:01 --> Model Class Initialized
DEBUG - 2011-04-06 03:25:01 --> Model Class Initialized
DEBUG - 2011-04-06 03:25:01 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-06 03:25:01 --> Database Driver Class Initialized
DEBUG - 2011-04-06 03:25:05 --> Final output sent to browser
DEBUG - 2011-04-06 03:25:05 --> Total execution time: 3.9019
DEBUG - 2011-04-06 04:17:34 --> Config Class Initialized
DEBUG - 2011-04-06 04:17:34 --> Hooks Class Initialized
DEBUG - 2011-04-06 04:17:34 --> Utf8 Class Initialized
DEBUG - 2011-04-06 04:17:34 --> UTF-8 Support Enabled
DEBUG - 2011-04-06 04:17:34 --> URI Class Initialized
DEBUG - 2011-04-06 04:17:34 --> Router Class Initialized
DEBUG - 2011-04-06 04:17:34 --> No URI present. Default controller set.
DEBUG - 2011-04-06 04:17:34 --> Output Class Initialized
DEBUG - 2011-04-06 04:17:34 --> Input Class Initialized
DEBUG - 2011-04-06 04:17:34 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-06 04:17:34 --> Language Class Initialized
DEBUG - 2011-04-06 04:17:34 --> Loader Class Initialized
DEBUG - 2011-04-06 04:17:34 --> Controller Class Initialized
DEBUG - 2011-04-06 04:17:34 --> File loaded: application/views/splash/main.php
DEBUG - 2011-04-06 04:17:34 --> Helper loaded: url_helper
DEBUG - 2011-04-06 04:17:34 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-06 04:17:34 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-06 04:17:34 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-06 04:17:34 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-06 04:17:34 --> Final output sent to browser
DEBUG - 2011-04-06 04:17:34 --> Total execution time: 0.2749
DEBUG - 2011-04-06 04:26:26 --> Config Class Initialized
DEBUG - 2011-04-06 04:26:26 --> Hooks Class Initialized
DEBUG - 2011-04-06 04:26:26 --> Utf8 Class Initialized
DEBUG - 2011-04-06 04:26:26 --> UTF-8 Support Enabled
DEBUG - 2011-04-06 04:26:26 --> URI Class Initialized
DEBUG - 2011-04-06 04:26:26 --> Router Class Initialized
DEBUG - 2011-04-06 04:26:26 --> Output Class Initialized
DEBUG - 2011-04-06 04:26:26 --> Input Class Initialized
DEBUG - 2011-04-06 04:26:26 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-06 04:26:26 --> Language Class Initialized
DEBUG - 2011-04-06 04:26:27 --> Loader Class Initialized
DEBUG - 2011-04-06 04:26:27 --> Controller Class Initialized
DEBUG - 2011-04-06 04:26:27 --> Model Class Initialized
DEBUG - 2011-04-06 04:26:27 --> Model Class Initialized
DEBUG - 2011-04-06 04:26:27 --> Model Class Initialized
DEBUG - 2011-04-06 04:26:27 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-06 04:26:28 --> Database Driver Class Initialized
DEBUG - 2011-04-06 04:26:40 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-06 04:26:40 --> Helper loaded: url_helper
DEBUG - 2011-04-06 04:26:40 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-06 04:26:40 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-06 04:26:40 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-06 04:26:40 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-06 04:26:40 --> Final output sent to browser
DEBUG - 2011-04-06 04:26:40 --> Total execution time: 14.4252
DEBUG - 2011-04-06 04:27:19 --> Config Class Initialized
DEBUG - 2011-04-06 04:27:19 --> Hooks Class Initialized
DEBUG - 2011-04-06 04:27:19 --> Utf8 Class Initialized
DEBUG - 2011-04-06 04:27:19 --> UTF-8 Support Enabled
DEBUG - 2011-04-06 04:27:19 --> URI Class Initialized
DEBUG - 2011-04-06 04:27:19 --> Router Class Initialized
DEBUG - 2011-04-06 04:27:19 --> Output Class Initialized
DEBUG - 2011-04-06 04:27:19 --> Input Class Initialized
DEBUG - 2011-04-06 04:27:19 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-06 04:27:19 --> Language Class Initialized
DEBUG - 2011-04-06 04:27:19 --> Loader Class Initialized
DEBUG - 2011-04-06 04:27:19 --> Controller Class Initialized
DEBUG - 2011-04-06 04:27:19 --> Model Class Initialized
DEBUG - 2011-04-06 04:27:19 --> Model Class Initialized
DEBUG - 2011-04-06 04:27:19 --> Model Class Initialized
DEBUG - 2011-04-06 04:27:19 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-06 04:27:19 --> Database Driver Class Initialized
DEBUG - 2011-04-06 04:27:19 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-06 04:27:19 --> Helper loaded: url_helper
DEBUG - 2011-04-06 04:27:19 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-06 04:27:19 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-06 04:27:19 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-06 04:27:19 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-06 04:27:19 --> Final output sent to browser
DEBUG - 2011-04-06 04:27:19 --> Total execution time: 0.3704
DEBUG - 2011-04-06 04:27:21 --> Config Class Initialized
DEBUG - 2011-04-06 04:27:21 --> Hooks Class Initialized
DEBUG - 2011-04-06 04:27:21 --> Utf8 Class Initialized
DEBUG - 2011-04-06 04:27:21 --> UTF-8 Support Enabled
DEBUG - 2011-04-06 04:27:21 --> URI Class Initialized
DEBUG - 2011-04-06 04:27:21 --> Router Class Initialized
DEBUG - 2011-04-06 04:27:21 --> Output Class Initialized
DEBUG - 2011-04-06 04:27:21 --> Input Class Initialized
DEBUG - 2011-04-06 04:27:21 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-06 04:27:21 --> Language Class Initialized
DEBUG - 2011-04-06 04:27:21 --> Loader Class Initialized
DEBUG - 2011-04-06 04:27:21 --> Controller Class Initialized
DEBUG - 2011-04-06 04:27:21 --> Model Class Initialized
DEBUG - 2011-04-06 04:27:21 --> Model Class Initialized
DEBUG - 2011-04-06 04:27:21 --> Model Class Initialized
DEBUG - 2011-04-06 04:27:21 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-06 04:27:21 --> Database Driver Class Initialized
DEBUG - 2011-04-06 04:27:21 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-06 04:27:21 --> Helper loaded: url_helper
DEBUG - 2011-04-06 04:27:21 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-06 04:27:21 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-06 04:27:21 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-06 04:27:21 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-06 04:27:21 --> Final output sent to browser
DEBUG - 2011-04-06 04:27:21 --> Total execution time: 0.0456
DEBUG - 2011-04-06 04:27:34 --> Config Class Initialized
DEBUG - 2011-04-06 04:27:34 --> Hooks Class Initialized
DEBUG - 2011-04-06 04:27:34 --> Utf8 Class Initialized
DEBUG - 2011-04-06 04:27:34 --> UTF-8 Support Enabled
DEBUG - 2011-04-06 04:27:34 --> URI Class Initialized
DEBUG - 2011-04-06 04:27:34 --> Router Class Initialized
DEBUG - 2011-04-06 04:27:34 --> Output Class Initialized
DEBUG - 2011-04-06 04:27:34 --> Input Class Initialized
DEBUG - 2011-04-06 04:27:34 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-06 04:27:34 --> Language Class Initialized
DEBUG - 2011-04-06 04:27:34 --> Loader Class Initialized
DEBUG - 2011-04-06 04:27:34 --> Controller Class Initialized
DEBUG - 2011-04-06 04:27:34 --> Model Class Initialized
DEBUG - 2011-04-06 04:27:34 --> Model Class Initialized
DEBUG - 2011-04-06 04:27:34 --> Model Class Initialized
DEBUG - 2011-04-06 04:27:34 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-06 04:27:34 --> Database Driver Class Initialized
DEBUG - 2011-04-06 04:27:36 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-06 04:27:36 --> Helper loaded: url_helper
DEBUG - 2011-04-06 04:27:36 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-06 04:27:36 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-06 04:27:36 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-06 04:27:36 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-06 04:27:36 --> Final output sent to browser
DEBUG - 2011-04-06 04:27:36 --> Total execution time: 1.8391
DEBUG - 2011-04-06 04:27:38 --> Config Class Initialized
DEBUG - 2011-04-06 04:27:38 --> Hooks Class Initialized
DEBUG - 2011-04-06 04:27:38 --> Utf8 Class Initialized
DEBUG - 2011-04-06 04:27:38 --> UTF-8 Support Enabled
DEBUG - 2011-04-06 04:27:38 --> URI Class Initialized
DEBUG - 2011-04-06 04:27:38 --> Router Class Initialized
DEBUG - 2011-04-06 04:27:38 --> Output Class Initialized
DEBUG - 2011-04-06 04:27:38 --> Input Class Initialized
DEBUG - 2011-04-06 04:27:38 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-06 04:27:38 --> Language Class Initialized
DEBUG - 2011-04-06 04:27:38 --> Loader Class Initialized
DEBUG - 2011-04-06 04:27:38 --> Controller Class Initialized
DEBUG - 2011-04-06 04:27:38 --> Model Class Initialized
DEBUG - 2011-04-06 04:27:38 --> Model Class Initialized
DEBUG - 2011-04-06 04:27:38 --> Model Class Initialized
DEBUG - 2011-04-06 04:27:38 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-06 04:27:38 --> Database Driver Class Initialized
DEBUG - 2011-04-06 04:27:38 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-06 04:27:38 --> Helper loaded: url_helper
DEBUG - 2011-04-06 04:27:38 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-06 04:27:38 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-06 04:27:38 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-06 04:27:38 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-06 04:27:38 --> Final output sent to browser
DEBUG - 2011-04-06 04:27:38 --> Total execution time: 0.0502
DEBUG - 2011-04-06 04:55:43 --> Config Class Initialized
DEBUG - 2011-04-06 04:55:43 --> Hooks Class Initialized
DEBUG - 2011-04-06 04:55:43 --> Utf8 Class Initialized
DEBUG - 2011-04-06 04:55:43 --> UTF-8 Support Enabled
DEBUG - 2011-04-06 04:55:43 --> URI Class Initialized
DEBUG - 2011-04-06 04:55:43 --> Router Class Initialized
DEBUG - 2011-04-06 04:55:44 --> Output Class Initialized
DEBUG - 2011-04-06 04:55:44 --> Input Class Initialized
DEBUG - 2011-04-06 04:55:44 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-06 04:55:44 --> Language Class Initialized
DEBUG - 2011-04-06 04:55:44 --> Loader Class Initialized
DEBUG - 2011-04-06 04:55:44 --> Controller Class Initialized
ERROR - 2011-04-06 04:55:44 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-06 04:55:44 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-06 04:55:44 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-06 04:55:44 --> Model Class Initialized
DEBUG - 2011-04-06 04:55:44 --> Model Class Initialized
DEBUG - 2011-04-06 04:55:44 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-06 04:55:44 --> Database Driver Class Initialized
DEBUG - 2011-04-06 04:55:44 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-06 04:55:44 --> Helper loaded: url_helper
DEBUG - 2011-04-06 04:55:44 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-06 04:55:44 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-06 04:55:44 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-06 04:55:44 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-06 04:55:44 --> Final output sent to browser
DEBUG - 2011-04-06 04:55:44 --> Total execution time: 1.1817
DEBUG - 2011-04-06 04:55:46 --> Config Class Initialized
DEBUG - 2011-04-06 04:55:46 --> Hooks Class Initialized
DEBUG - 2011-04-06 04:55:46 --> Utf8 Class Initialized
DEBUG - 2011-04-06 04:55:46 --> UTF-8 Support Enabled
DEBUG - 2011-04-06 04:55:46 --> URI Class Initialized
DEBUG - 2011-04-06 04:55:46 --> Router Class Initialized
DEBUG - 2011-04-06 04:55:46 --> Output Class Initialized
DEBUG - 2011-04-06 04:55:46 --> Input Class Initialized
DEBUG - 2011-04-06 04:55:46 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-06 04:55:46 --> Language Class Initialized
DEBUG - 2011-04-06 04:55:46 --> Loader Class Initialized
DEBUG - 2011-04-06 04:55:46 --> Controller Class Initialized
DEBUG - 2011-04-06 04:55:46 --> Model Class Initialized
DEBUG - 2011-04-06 04:55:46 --> Model Class Initialized
DEBUG - 2011-04-06 04:55:46 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-06 04:55:46 --> Database Driver Class Initialized
DEBUG - 2011-04-06 04:55:47 --> Final output sent to browser
DEBUG - 2011-04-06 04:55:47 --> Total execution time: 1.0053
DEBUG - 2011-04-06 04:55:48 --> Config Class Initialized
DEBUG - 2011-04-06 04:55:48 --> Hooks Class Initialized
DEBUG - 2011-04-06 04:55:48 --> Utf8 Class Initialized
DEBUG - 2011-04-06 04:55:48 --> UTF-8 Support Enabled
DEBUG - 2011-04-06 04:55:48 --> URI Class Initialized
DEBUG - 2011-04-06 04:55:48 --> Router Class Initialized
ERROR - 2011-04-06 04:55:48 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-06 04:56:33 --> Config Class Initialized
DEBUG - 2011-04-06 04:56:33 --> Hooks Class Initialized
DEBUG - 2011-04-06 04:56:33 --> Utf8 Class Initialized
DEBUG - 2011-04-06 04:56:33 --> UTF-8 Support Enabled
DEBUG - 2011-04-06 04:56:33 --> URI Class Initialized
DEBUG - 2011-04-06 04:56:33 --> Router Class Initialized
DEBUG - 2011-04-06 04:56:33 --> Output Class Initialized
DEBUG - 2011-04-06 04:56:33 --> Input Class Initialized
DEBUG - 2011-04-06 04:56:33 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-06 04:56:33 --> Language Class Initialized
DEBUG - 2011-04-06 04:56:33 --> Loader Class Initialized
DEBUG - 2011-04-06 04:56:33 --> Controller Class Initialized
ERROR - 2011-04-06 04:56:33 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-06 04:56:33 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-06 04:56:33 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-06 04:56:33 --> Model Class Initialized
DEBUG - 2011-04-06 04:56:33 --> Model Class Initialized
DEBUG - 2011-04-06 04:56:33 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-06 04:56:33 --> Database Driver Class Initialized
DEBUG - 2011-04-06 04:56:33 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-06 04:56:33 --> Helper loaded: url_helper
DEBUG - 2011-04-06 04:56:33 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-06 04:56:33 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-06 04:56:33 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-06 04:56:33 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-06 04:56:33 --> Final output sent to browser
DEBUG - 2011-04-06 04:56:33 --> Total execution time: 0.0386
DEBUG - 2011-04-06 04:56:34 --> Config Class Initialized
DEBUG - 2011-04-06 04:56:34 --> Hooks Class Initialized
DEBUG - 2011-04-06 04:56:34 --> Utf8 Class Initialized
DEBUG - 2011-04-06 04:56:34 --> UTF-8 Support Enabled
DEBUG - 2011-04-06 04:56:34 --> URI Class Initialized
DEBUG - 2011-04-06 04:56:34 --> Router Class Initialized
DEBUG - 2011-04-06 04:56:34 --> Output Class Initialized
DEBUG - 2011-04-06 04:56:34 --> Input Class Initialized
DEBUG - 2011-04-06 04:56:34 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-06 04:56:34 --> Language Class Initialized
DEBUG - 2011-04-06 04:56:34 --> Loader Class Initialized
DEBUG - 2011-04-06 04:56:34 --> Controller Class Initialized
DEBUG - 2011-04-06 04:56:34 --> Model Class Initialized
DEBUG - 2011-04-06 04:56:34 --> Model Class Initialized
DEBUG - 2011-04-06 04:56:34 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-06 04:56:34 --> Database Driver Class Initialized
DEBUG - 2011-04-06 04:56:41 --> Final output sent to browser
DEBUG - 2011-04-06 04:56:41 --> Total execution time: 6.6645
DEBUG - 2011-04-06 05:48:52 --> Config Class Initialized
DEBUG - 2011-04-06 05:48:52 --> Hooks Class Initialized
DEBUG - 2011-04-06 05:48:52 --> Utf8 Class Initialized
DEBUG - 2011-04-06 05:48:52 --> UTF-8 Support Enabled
DEBUG - 2011-04-06 05:48:52 --> URI Class Initialized
DEBUG - 2011-04-06 05:48:52 --> Router Class Initialized
DEBUG - 2011-04-06 05:48:52 --> No URI present. Default controller set.
DEBUG - 2011-04-06 05:48:52 --> Output Class Initialized
DEBUG - 2011-04-06 05:48:52 --> Input Class Initialized
DEBUG - 2011-04-06 05:48:52 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-06 05:48:52 --> Language Class Initialized
DEBUG - 2011-04-06 05:48:52 --> Loader Class Initialized
DEBUG - 2011-04-06 05:48:52 --> Controller Class Initialized
DEBUG - 2011-04-06 05:48:52 --> File loaded: application/views/splash/main.php
DEBUG - 2011-04-06 05:48:53 --> Helper loaded: url_helper
DEBUG - 2011-04-06 05:48:53 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-06 05:48:53 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-06 05:48:53 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-06 05:48:53 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-06 05:48:53 --> Final output sent to browser
DEBUG - 2011-04-06 05:48:53 --> Total execution time: 0.3227
DEBUG - 2011-04-06 05:48:59 --> Config Class Initialized
DEBUG - 2011-04-06 05:48:59 --> Hooks Class Initialized
DEBUG - 2011-04-06 05:48:59 --> Utf8 Class Initialized
DEBUG - 2011-04-06 05:48:59 --> UTF-8 Support Enabled
DEBUG - 2011-04-06 05:48:59 --> URI Class Initialized
DEBUG - 2011-04-06 05:48:59 --> Router Class Initialized
ERROR - 2011-04-06 05:48:59 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-06 05:49:00 --> Config Class Initialized
DEBUG - 2011-04-06 05:49:00 --> Hooks Class Initialized
DEBUG - 2011-04-06 05:49:00 --> Utf8 Class Initialized
DEBUG - 2011-04-06 05:49:00 --> UTF-8 Support Enabled
DEBUG - 2011-04-06 05:49:00 --> URI Class Initialized
DEBUG - 2011-04-06 05:49:00 --> Router Class Initialized
ERROR - 2011-04-06 05:49:00 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-06 05:59:24 --> Config Class Initialized
DEBUG - 2011-04-06 05:59:24 --> Hooks Class Initialized
DEBUG - 2011-04-06 05:59:24 --> Utf8 Class Initialized
DEBUG - 2011-04-06 05:59:24 --> UTF-8 Support Enabled
DEBUG - 2011-04-06 05:59:24 --> URI Class Initialized
DEBUG - 2011-04-06 05:59:24 --> Router Class Initialized
DEBUG - 2011-04-06 05:59:24 --> Output Class Initialized
DEBUG - 2011-04-06 05:59:24 --> Input Class Initialized
DEBUG - 2011-04-06 05:59:24 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-06 05:59:24 --> Language Class Initialized
DEBUG - 2011-04-06 05:59:24 --> Loader Class Initialized
DEBUG - 2011-04-06 05:59:24 --> Controller Class Initialized
ERROR - 2011-04-06 05:59:24 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-06 05:59:24 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-06 05:59:24 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-06 05:59:24 --> Config Class Initialized
DEBUG - 2011-04-06 05:59:24 --> Hooks Class Initialized
DEBUG - 2011-04-06 05:59:24 --> Model Class Initialized
DEBUG - 2011-04-06 05:59:24 --> Utf8 Class Initialized
DEBUG - 2011-04-06 05:59:24 --> UTF-8 Support Enabled
DEBUG - 2011-04-06 05:59:24 --> Config Class Initialized
DEBUG - 2011-04-06 05:59:24 --> Hooks Class Initialized
DEBUG - 2011-04-06 05:59:24 --> Utf8 Class Initialized
DEBUG - 2011-04-06 05:59:24 --> UTF-8 Support Enabled
DEBUG - 2011-04-06 05:59:24 --> URI Class Initialized
DEBUG - 2011-04-06 05:59:24 --> URI Class Initialized
DEBUG - 2011-04-06 05:59:24 --> Router Class Initialized
DEBUG - 2011-04-06 05:59:24 --> No URI present. Default controller set.
DEBUG - 2011-04-06 05:59:24 --> Router Class Initialized
DEBUG - 2011-04-06 05:59:24 --> Model Class Initialized
DEBUG - 2011-04-06 05:59:24 --> Output Class Initialized
DEBUG - 2011-04-06 05:59:24 --> Input Class Initialized
DEBUG - 2011-04-06 05:59:24 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-06 05:59:24 --> Language Class Initialized
DEBUG - 2011-04-06 05:59:24 --> Output Class Initialized
DEBUG - 2011-04-06 05:59:24 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-06 05:59:24 --> Input Class Initialized
DEBUG - 2011-04-06 05:59:24 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-06 05:59:24 --> Language Class Initialized
DEBUG - 2011-04-06 05:59:24 --> Loader Class Initialized
DEBUG - 2011-04-06 05:59:24 --> Controller Class Initialized
DEBUG - 2011-04-06 05:59:24 --> Loader Class Initialized
DEBUG - 2011-04-06 05:59:24 --> Controller Class Initialized
DEBUG - 2011-04-06 05:59:24 --> Model Class Initialized
DEBUG - 2011-04-06 05:59:24 --> Database Driver Class Initialized
DEBUG - 2011-04-06 05:59:24 --> File loaded: application/views/splash/main.php
DEBUG - 2011-04-06 05:59:24 --> Model Class Initialized
DEBUG - 2011-04-06 05:59:24 --> Model Class Initialized
DEBUG - 2011-04-06 05:59:24 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-06 05:59:24 --> Database Driver Class Initialized
DEBUG - 2011-04-06 05:59:24 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-06 05:59:24 --> Helper loaded: url_helper
DEBUG - 2011-04-06 05:59:24 --> Helper loaded: url_helper
DEBUG - 2011-04-06 05:59:24 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-06 05:59:24 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-06 05:59:24 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-06 05:59:24 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-06 05:59:24 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-06 05:59:24 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-06 05:59:24 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-06 05:59:24 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-06 05:59:24 --> Final output sent to browser
DEBUG - 2011-04-06 05:59:24 --> Total execution time: 0.1649
DEBUG - 2011-04-06 05:59:24 --> Final output sent to browser
DEBUG - 2011-04-06 05:59:24 --> Total execution time: 0.3725
DEBUG - 2011-04-06 05:59:25 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-06 05:59:25 --> Helper loaded: url_helper
DEBUG - 2011-04-06 05:59:25 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-06 05:59:25 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-06 05:59:25 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-06 05:59:25 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-06 05:59:25 --> Final output sent to browser
DEBUG - 2011-04-06 05:59:25 --> Total execution time: 0.8085
DEBUG - 2011-04-06 05:59:37 --> Config Class Initialized
DEBUG - 2011-04-06 05:59:37 --> Hooks Class Initialized
DEBUG - 2011-04-06 05:59:37 --> Utf8 Class Initialized
DEBUG - 2011-04-06 05:59:37 --> UTF-8 Support Enabled
DEBUG - 2011-04-06 05:59:37 --> URI Class Initialized
DEBUG - 2011-04-06 05:59:37 --> Router Class Initialized
ERROR - 2011-04-06 05:59:37 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-04-06 06:29:41 --> Config Class Initialized
DEBUG - 2011-04-06 06:29:41 --> Hooks Class Initialized
DEBUG - 2011-04-06 06:29:41 --> Utf8 Class Initialized
DEBUG - 2011-04-06 06:29:41 --> UTF-8 Support Enabled
DEBUG - 2011-04-06 06:29:41 --> URI Class Initialized
DEBUG - 2011-04-06 06:29:41 --> Router Class Initialized
DEBUG - 2011-04-06 06:29:41 --> Output Class Initialized
DEBUG - 2011-04-06 06:29:41 --> Input Class Initialized
DEBUG - 2011-04-06 06:29:41 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-06 06:29:41 --> Language Class Initialized
DEBUG - 2011-04-06 06:29:41 --> Loader Class Initialized
DEBUG - 2011-04-06 06:29:41 --> Controller Class Initialized
DEBUG - 2011-04-06 06:29:41 --> Model Class Initialized
DEBUG - 2011-04-06 06:29:41 --> Model Class Initialized
DEBUG - 2011-04-06 06:29:41 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-06 06:29:41 --> Database Driver Class Initialized
DEBUG - 2011-04-06 06:29:42 --> Final output sent to browser
DEBUG - 2011-04-06 06:29:42 --> Total execution time: 1.2173
DEBUG - 2011-04-06 06:37:53 --> Config Class Initialized
DEBUG - 2011-04-06 06:37:53 --> Hooks Class Initialized
DEBUG - 2011-04-06 06:37:53 --> Utf8 Class Initialized
DEBUG - 2011-04-06 06:37:53 --> UTF-8 Support Enabled
DEBUG - 2011-04-06 06:37:53 --> URI Class Initialized
DEBUG - 2011-04-06 06:37:53 --> Router Class Initialized
DEBUG - 2011-04-06 06:37:53 --> Output Class Initialized
DEBUG - 2011-04-06 06:37:53 --> Input Class Initialized
DEBUG - 2011-04-06 06:37:53 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-06 06:37:53 --> Language Class Initialized
DEBUG - 2011-04-06 06:37:54 --> Loader Class Initialized
DEBUG - 2011-04-06 06:37:54 --> Controller Class Initialized
DEBUG - 2011-04-06 06:37:54 --> Model Class Initialized
DEBUG - 2011-04-06 06:37:54 --> Model Class Initialized
DEBUG - 2011-04-06 06:37:54 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-06 06:37:54 --> Database Driver Class Initialized
DEBUG - 2011-04-06 06:37:54 --> Final output sent to browser
DEBUG - 2011-04-06 06:37:54 --> Total execution time: 0.8451
DEBUG - 2011-04-06 07:17:06 --> Config Class Initialized
DEBUG - 2011-04-06 07:17:06 --> Hooks Class Initialized
DEBUG - 2011-04-06 07:17:06 --> Utf8 Class Initialized
DEBUG - 2011-04-06 07:17:06 --> UTF-8 Support Enabled
DEBUG - 2011-04-06 07:17:06 --> URI Class Initialized
DEBUG - 2011-04-06 07:17:07 --> Router Class Initialized
DEBUG - 2011-04-06 07:17:07 --> No URI present. Default controller set.
DEBUG - 2011-04-06 07:17:07 --> Output Class Initialized
DEBUG - 2011-04-06 07:17:07 --> Input Class Initialized
DEBUG - 2011-04-06 07:17:07 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-06 07:17:07 --> Language Class Initialized
DEBUG - 2011-04-06 07:17:07 --> Loader Class Initialized
DEBUG - 2011-04-06 07:17:07 --> Controller Class Initialized
DEBUG - 2011-04-06 07:17:07 --> File loaded: application/views/splash/main.php
DEBUG - 2011-04-06 07:17:07 --> Helper loaded: url_helper
DEBUG - 2011-04-06 07:17:07 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-06 07:17:07 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-06 07:17:07 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-06 07:17:07 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-06 07:17:07 --> Final output sent to browser
DEBUG - 2011-04-06 07:17:07 --> Total execution time: 0.2762
DEBUG - 2011-04-06 08:03:53 --> Config Class Initialized
DEBUG - 2011-04-06 08:03:53 --> Hooks Class Initialized
DEBUG - 2011-04-06 08:03:53 --> Utf8 Class Initialized
DEBUG - 2011-04-06 08:03:53 --> UTF-8 Support Enabled
DEBUG - 2011-04-06 08:03:53 --> URI Class Initialized
DEBUG - 2011-04-06 08:03:53 --> Router Class Initialized
DEBUG - 2011-04-06 08:03:53 --> Output Class Initialized
DEBUG - 2011-04-06 08:03:53 --> Input Class Initialized
DEBUG - 2011-04-06 08:03:53 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-06 08:03:53 --> Language Class Initialized
DEBUG - 2011-04-06 08:03:53 --> Loader Class Initialized
DEBUG - 2011-04-06 08:03:53 --> Controller Class Initialized
ERROR - 2011-04-06 08:03:53 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-06 08:03:53 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-06 08:03:53 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-06 08:03:53 --> Model Class Initialized
DEBUG - 2011-04-06 08:03:53 --> Model Class Initialized
DEBUG - 2011-04-06 08:03:53 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-06 08:03:53 --> Database Driver Class Initialized
DEBUG - 2011-04-06 08:03:53 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-06 08:03:53 --> Helper loaded: url_helper
DEBUG - 2011-04-06 08:03:53 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-06 08:03:53 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-06 08:03:53 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-06 08:03:53 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-06 08:03:53 --> Final output sent to browser
DEBUG - 2011-04-06 08:03:53 --> Total execution time: 0.3841
DEBUG - 2011-04-06 08:03:58 --> Config Class Initialized
DEBUG - 2011-04-06 08:03:58 --> Hooks Class Initialized
DEBUG - 2011-04-06 08:03:58 --> Utf8 Class Initialized
DEBUG - 2011-04-06 08:03:58 --> UTF-8 Support Enabled
DEBUG - 2011-04-06 08:03:58 --> URI Class Initialized
DEBUG - 2011-04-06 08:03:58 --> Router Class Initialized
DEBUG - 2011-04-06 08:03:58 --> Output Class Initialized
DEBUG - 2011-04-06 08:03:58 --> Input Class Initialized
DEBUG - 2011-04-06 08:03:58 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-06 08:03:58 --> Language Class Initialized
DEBUG - 2011-04-06 08:03:58 --> Loader Class Initialized
DEBUG - 2011-04-06 08:03:58 --> Controller Class Initialized
DEBUG - 2011-04-06 08:03:58 --> Model Class Initialized
DEBUG - 2011-04-06 08:03:59 --> Model Class Initialized
DEBUG - 2011-04-06 08:03:59 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-06 08:03:59 --> Database Driver Class Initialized
DEBUG - 2011-04-06 08:04:00 --> Final output sent to browser
DEBUG - 2011-04-06 08:04:00 --> Total execution time: 1.9447
DEBUG - 2011-04-06 08:04:11 --> Config Class Initialized
DEBUG - 2011-04-06 08:04:11 --> Hooks Class Initialized
DEBUG - 2011-04-06 08:04:11 --> Utf8 Class Initialized
DEBUG - 2011-04-06 08:04:11 --> UTF-8 Support Enabled
DEBUG - 2011-04-06 08:04:11 --> URI Class Initialized
DEBUG - 2011-04-06 08:04:11 --> Router Class Initialized
DEBUG - 2011-04-06 08:04:11 --> Output Class Initialized
DEBUG - 2011-04-06 08:04:11 --> Input Class Initialized
DEBUG - 2011-04-06 08:04:11 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-06 08:04:11 --> Language Class Initialized
DEBUG - 2011-04-06 08:04:11 --> Loader Class Initialized
DEBUG - 2011-04-06 08:04:11 --> Controller Class Initialized
ERROR - 2011-04-06 08:04:11 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-06 08:04:11 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-06 08:04:11 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-06 08:04:11 --> Model Class Initialized
DEBUG - 2011-04-06 08:04:11 --> Model Class Initialized
DEBUG - 2011-04-06 08:04:11 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-06 08:04:11 --> Database Driver Class Initialized
DEBUG - 2011-04-06 08:04:11 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-06 08:04:11 --> Helper loaded: url_helper
DEBUG - 2011-04-06 08:04:11 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-06 08:04:11 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-06 08:04:11 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-06 08:04:11 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-06 08:04:11 --> Final output sent to browser
DEBUG - 2011-04-06 08:04:11 --> Total execution time: 0.0321
DEBUG - 2011-04-06 08:04:14 --> Config Class Initialized
DEBUG - 2011-04-06 08:04:14 --> Hooks Class Initialized
DEBUG - 2011-04-06 08:04:14 --> Utf8 Class Initialized
DEBUG - 2011-04-06 08:04:14 --> UTF-8 Support Enabled
DEBUG - 2011-04-06 08:04:14 --> URI Class Initialized
DEBUG - 2011-04-06 08:04:14 --> Router Class Initialized
DEBUG - 2011-04-06 08:04:14 --> Output Class Initialized
DEBUG - 2011-04-06 08:04:14 --> Input Class Initialized
DEBUG - 2011-04-06 08:04:14 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-06 08:04:14 --> Language Class Initialized
DEBUG - 2011-04-06 08:04:14 --> Loader Class Initialized
DEBUG - 2011-04-06 08:04:14 --> Controller Class Initialized
DEBUG - 2011-04-06 08:04:14 --> Model Class Initialized
DEBUG - 2011-04-06 08:04:14 --> Model Class Initialized
DEBUG - 2011-04-06 08:04:14 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-06 08:04:14 --> Database Driver Class Initialized
DEBUG - 2011-04-06 08:04:15 --> Final output sent to browser
DEBUG - 2011-04-06 08:04:15 --> Total execution time: 0.9226
DEBUG - 2011-04-06 08:04:25 --> Config Class Initialized
DEBUG - 2011-04-06 08:04:25 --> Hooks Class Initialized
DEBUG - 2011-04-06 08:04:25 --> Utf8 Class Initialized
DEBUG - 2011-04-06 08:04:25 --> UTF-8 Support Enabled
DEBUG - 2011-04-06 08:04:25 --> URI Class Initialized
DEBUG - 2011-04-06 08:04:25 --> Router Class Initialized
DEBUG - 2011-04-06 08:04:25 --> Output Class Initialized
DEBUG - 2011-04-06 08:04:25 --> Input Class Initialized
DEBUG - 2011-04-06 08:04:25 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-06 08:04:25 --> Language Class Initialized
DEBUG - 2011-04-06 08:04:25 --> Loader Class Initialized
DEBUG - 2011-04-06 08:04:25 --> Controller Class Initialized
ERROR - 2011-04-06 08:04:25 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-06 08:04:25 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-06 08:04:25 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-06 08:04:25 --> Model Class Initialized
DEBUG - 2011-04-06 08:04:25 --> Model Class Initialized
DEBUG - 2011-04-06 08:04:25 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-06 08:04:25 --> Database Driver Class Initialized
DEBUG - 2011-04-06 08:04:25 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-06 08:04:25 --> Helper loaded: url_helper
DEBUG - 2011-04-06 08:04:25 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-06 08:04:25 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-06 08:04:25 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-06 08:04:25 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-06 08:04:25 --> Final output sent to browser
DEBUG - 2011-04-06 08:04:25 --> Total execution time: 0.0946
DEBUG - 2011-04-06 08:04:29 --> Config Class Initialized
DEBUG - 2011-04-06 08:04:29 --> Hooks Class Initialized
DEBUG - 2011-04-06 08:04:29 --> Utf8 Class Initialized
DEBUG - 2011-04-06 08:04:29 --> UTF-8 Support Enabled
DEBUG - 2011-04-06 08:04:29 --> URI Class Initialized
DEBUG - 2011-04-06 08:04:29 --> Router Class Initialized
DEBUG - 2011-04-06 08:04:29 --> Output Class Initialized
DEBUG - 2011-04-06 08:04:29 --> Input Class Initialized
DEBUG - 2011-04-06 08:04:29 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-06 08:04:29 --> Language Class Initialized
DEBUG - 2011-04-06 08:04:29 --> Loader Class Initialized
DEBUG - 2011-04-06 08:04:29 --> Controller Class Initialized
DEBUG - 2011-04-06 08:04:29 --> Model Class Initialized
DEBUG - 2011-04-06 08:04:29 --> Model Class Initialized
DEBUG - 2011-04-06 08:04:29 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-06 08:04:29 --> Database Driver Class Initialized
DEBUG - 2011-04-06 08:04:30 --> Final output sent to browser
DEBUG - 2011-04-06 08:04:30 --> Total execution time: 0.8289
DEBUG - 2011-04-06 08:05:33 --> Config Class Initialized
DEBUG - 2011-04-06 08:05:33 --> Hooks Class Initialized
DEBUG - 2011-04-06 08:05:33 --> Utf8 Class Initialized
DEBUG - 2011-04-06 08:05:33 --> UTF-8 Support Enabled
DEBUG - 2011-04-06 08:05:33 --> URI Class Initialized
DEBUG - 2011-04-06 08:05:33 --> Router Class Initialized
DEBUG - 2011-04-06 08:05:33 --> No URI present. Default controller set.
DEBUG - 2011-04-06 08:05:33 --> Output Class Initialized
DEBUG - 2011-04-06 08:05:33 --> Input Class Initialized
DEBUG - 2011-04-06 08:05:33 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-06 08:05:33 --> Language Class Initialized
DEBUG - 2011-04-06 08:05:33 --> Loader Class Initialized
DEBUG - 2011-04-06 08:05:33 --> Controller Class Initialized
DEBUG - 2011-04-06 08:05:33 --> File loaded: application/views/splash/main.php
DEBUG - 2011-04-06 08:05:33 --> Helper loaded: url_helper
DEBUG - 2011-04-06 08:05:33 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-06 08:05:33 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-06 08:05:33 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-06 08:05:33 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-06 08:05:33 --> Final output sent to browser
DEBUG - 2011-04-06 08:05:33 --> Total execution time: 0.0603
DEBUG - 2011-04-06 08:10:37 --> Config Class Initialized
DEBUG - 2011-04-06 08:10:37 --> Hooks Class Initialized
DEBUG - 2011-04-06 08:10:37 --> Utf8 Class Initialized
DEBUG - 2011-04-06 08:10:37 --> UTF-8 Support Enabled
DEBUG - 2011-04-06 08:10:37 --> URI Class Initialized
DEBUG - 2011-04-06 08:10:37 --> Router Class Initialized
DEBUG - 2011-04-06 08:10:37 --> No URI present. Default controller set.
DEBUG - 2011-04-06 08:10:37 --> Output Class Initialized
DEBUG - 2011-04-06 08:10:37 --> Input Class Initialized
DEBUG - 2011-04-06 08:10:37 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-06 08:10:37 --> Language Class Initialized
DEBUG - 2011-04-06 08:10:37 --> Loader Class Initialized
DEBUG - 2011-04-06 08:10:37 --> Controller Class Initialized
DEBUG - 2011-04-06 08:10:37 --> File loaded: application/views/splash/main.php
DEBUG - 2011-04-06 08:10:37 --> Helper loaded: url_helper
DEBUG - 2011-04-06 08:10:37 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-06 08:10:37 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-06 08:10:37 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-06 08:10:37 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-06 08:10:37 --> Final output sent to browser
DEBUG - 2011-04-06 08:10:37 --> Total execution time: 0.0134
DEBUG - 2011-04-06 08:10:39 --> Config Class Initialized
DEBUG - 2011-04-06 08:10:39 --> Hooks Class Initialized
DEBUG - 2011-04-06 08:10:39 --> Utf8 Class Initialized
DEBUG - 2011-04-06 08:10:39 --> UTF-8 Support Enabled
DEBUG - 2011-04-06 08:10:39 --> URI Class Initialized
DEBUG - 2011-04-06 08:10:39 --> Router Class Initialized
ERROR - 2011-04-06 08:10:39 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-06 08:10:42 --> Config Class Initialized
DEBUG - 2011-04-06 08:10:42 --> Hooks Class Initialized
DEBUG - 2011-04-06 08:10:42 --> Utf8 Class Initialized
DEBUG - 2011-04-06 08:10:42 --> UTF-8 Support Enabled
DEBUG - 2011-04-06 08:10:42 --> URI Class Initialized
DEBUG - 2011-04-06 08:10:42 --> Router Class Initialized
DEBUG - 2011-04-06 08:10:42 --> Output Class Initialized
DEBUG - 2011-04-06 08:10:42 --> Input Class Initialized
DEBUG - 2011-04-06 08:10:42 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-06 08:10:42 --> Language Class Initialized
DEBUG - 2011-04-06 08:10:42 --> Loader Class Initialized
DEBUG - 2011-04-06 08:10:42 --> Controller Class Initialized
DEBUG - 2011-04-06 08:10:42 --> Model Class Initialized
DEBUG - 2011-04-06 08:10:43 --> Model Class Initialized
DEBUG - 2011-04-06 08:10:43 --> Model Class Initialized
DEBUG - 2011-04-06 08:10:43 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-06 08:10:43 --> Database Driver Class Initialized
DEBUG - 2011-04-06 08:10:44 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-06 08:10:44 --> Helper loaded: url_helper
DEBUG - 2011-04-06 08:10:44 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-06 08:10:44 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-06 08:10:44 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-06 08:10:44 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-06 08:10:44 --> Final output sent to browser
DEBUG - 2011-04-06 08:10:44 --> Total execution time: 1.5052
DEBUG - 2011-04-06 08:10:45 --> Config Class Initialized
DEBUG - 2011-04-06 08:10:45 --> Hooks Class Initialized
DEBUG - 2011-04-06 08:10:45 --> Utf8 Class Initialized
DEBUG - 2011-04-06 08:10:45 --> UTF-8 Support Enabled
DEBUG - 2011-04-06 08:10:45 --> URI Class Initialized
DEBUG - 2011-04-06 08:10:45 --> Router Class Initialized
ERROR - 2011-04-06 08:10:45 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-06 08:11:03 --> Config Class Initialized
DEBUG - 2011-04-06 08:11:03 --> Hooks Class Initialized
DEBUG - 2011-04-06 08:11:03 --> Utf8 Class Initialized
DEBUG - 2011-04-06 08:11:03 --> UTF-8 Support Enabled
DEBUG - 2011-04-06 08:11:03 --> URI Class Initialized
DEBUG - 2011-04-06 08:11:03 --> Router Class Initialized
DEBUG - 2011-04-06 08:11:03 --> Output Class Initialized
DEBUG - 2011-04-06 08:11:03 --> Input Class Initialized
DEBUG - 2011-04-06 08:11:03 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-06 08:11:03 --> Language Class Initialized
DEBUG - 2011-04-06 08:11:03 --> Loader Class Initialized
DEBUG - 2011-04-06 08:11:03 --> Controller Class Initialized
DEBUG - 2011-04-06 08:11:03 --> Model Class Initialized
DEBUG - 2011-04-06 08:11:03 --> Model Class Initialized
DEBUG - 2011-04-06 08:11:03 --> Model Class Initialized
DEBUG - 2011-04-06 08:11:03 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-06 08:11:03 --> Database Driver Class Initialized
DEBUG - 2011-04-06 08:11:03 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-06 08:11:03 --> Helper loaded: url_helper
DEBUG - 2011-04-06 08:11:03 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-06 08:11:03 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-06 08:11:03 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-06 08:11:03 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-06 08:11:03 --> Final output sent to browser
DEBUG - 2011-04-06 08:11:03 --> Total execution time: 0.5049
DEBUG - 2011-04-06 08:11:04 --> Config Class Initialized
DEBUG - 2011-04-06 08:11:04 --> Hooks Class Initialized
DEBUG - 2011-04-06 08:11:04 --> Utf8 Class Initialized
DEBUG - 2011-04-06 08:11:04 --> UTF-8 Support Enabled
DEBUG - 2011-04-06 08:11:04 --> URI Class Initialized
DEBUG - 2011-04-06 08:11:04 --> Router Class Initialized
DEBUG - 2011-04-06 08:11:04 --> Output Class Initialized
DEBUG - 2011-04-06 08:11:04 --> Input Class Initialized
DEBUG - 2011-04-06 08:11:04 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-06 08:11:04 --> Language Class Initialized
DEBUG - 2011-04-06 08:11:04 --> Loader Class Initialized
DEBUG - 2011-04-06 08:11:04 --> Controller Class Initialized
DEBUG - 2011-04-06 08:11:04 --> Model Class Initialized
DEBUG - 2011-04-06 08:11:04 --> Model Class Initialized
DEBUG - 2011-04-06 08:11:04 --> Model Class Initialized
DEBUG - 2011-04-06 08:11:04 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-06 08:11:04 --> Database Driver Class Initialized
DEBUG - 2011-04-06 08:11:04 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-06 08:11:04 --> Helper loaded: url_helper
DEBUG - 2011-04-06 08:11:04 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-06 08:11:04 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-06 08:11:04 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-06 08:11:04 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-06 08:11:04 --> Final output sent to browser
DEBUG - 2011-04-06 08:11:04 --> Total execution time: 0.0424
DEBUG - 2011-04-06 08:11:05 --> Config Class Initialized
DEBUG - 2011-04-06 08:11:05 --> Hooks Class Initialized
DEBUG - 2011-04-06 08:11:05 --> Utf8 Class Initialized
DEBUG - 2011-04-06 08:11:05 --> UTF-8 Support Enabled
DEBUG - 2011-04-06 08:11:05 --> URI Class Initialized
DEBUG - 2011-04-06 08:11:05 --> Router Class Initialized
ERROR - 2011-04-06 08:11:05 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-06 08:11:22 --> Config Class Initialized
DEBUG - 2011-04-06 08:11:22 --> Hooks Class Initialized
DEBUG - 2011-04-06 08:11:22 --> Utf8 Class Initialized
DEBUG - 2011-04-06 08:11:22 --> UTF-8 Support Enabled
DEBUG - 2011-04-06 08:11:22 --> URI Class Initialized
DEBUG - 2011-04-06 08:11:22 --> Router Class Initialized
DEBUG - 2011-04-06 08:11:22 --> Output Class Initialized
DEBUG - 2011-04-06 08:11:22 --> Input Class Initialized
DEBUG - 2011-04-06 08:11:22 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-06 08:11:22 --> Language Class Initialized
DEBUG - 2011-04-06 08:11:22 --> Loader Class Initialized
DEBUG - 2011-04-06 08:11:22 --> Controller Class Initialized
DEBUG - 2011-04-06 08:11:22 --> Model Class Initialized
DEBUG - 2011-04-06 08:11:22 --> Model Class Initialized
DEBUG - 2011-04-06 08:11:22 --> Model Class Initialized
DEBUG - 2011-04-06 08:11:22 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-06 08:11:22 --> Database Driver Class Initialized
DEBUG - 2011-04-06 08:11:23 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-06 08:11:23 --> Helper loaded: url_helper
DEBUG - 2011-04-06 08:11:23 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-06 08:11:23 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-06 08:11:23 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-06 08:11:23 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-06 08:11:23 --> Final output sent to browser
DEBUG - 2011-04-06 08:11:23 --> Total execution time: 0.9547
DEBUG - 2011-04-06 08:11:24 --> Config Class Initialized
DEBUG - 2011-04-06 08:11:24 --> Hooks Class Initialized
DEBUG - 2011-04-06 08:11:24 --> Utf8 Class Initialized
DEBUG - 2011-04-06 08:11:24 --> UTF-8 Support Enabled
DEBUG - 2011-04-06 08:11:24 --> URI Class Initialized
DEBUG - 2011-04-06 08:11:24 --> Router Class Initialized
ERROR - 2011-04-06 08:11:24 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-06 08:11:26 --> Config Class Initialized
DEBUG - 2011-04-06 08:11:26 --> Hooks Class Initialized
DEBUG - 2011-04-06 08:11:26 --> Utf8 Class Initialized
DEBUG - 2011-04-06 08:11:26 --> UTF-8 Support Enabled
DEBUG - 2011-04-06 08:11:26 --> URI Class Initialized
DEBUG - 2011-04-06 08:11:26 --> Router Class Initialized
DEBUG - 2011-04-06 08:11:26 --> Output Class Initialized
DEBUG - 2011-04-06 08:11:26 --> Input Class Initialized
DEBUG - 2011-04-06 08:11:26 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-06 08:11:26 --> Language Class Initialized
DEBUG - 2011-04-06 08:11:26 --> Loader Class Initialized
DEBUG - 2011-04-06 08:11:26 --> Controller Class Initialized
DEBUG - 2011-04-06 08:11:26 --> Model Class Initialized
DEBUG - 2011-04-06 08:11:26 --> Model Class Initialized
DEBUG - 2011-04-06 08:11:26 --> Model Class Initialized
DEBUG - 2011-04-06 08:11:26 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-06 08:11:26 --> Database Driver Class Initialized
DEBUG - 2011-04-06 08:11:26 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-06 08:11:26 --> Helper loaded: url_helper
DEBUG - 2011-04-06 08:11:26 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-06 08:11:26 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-06 08:11:26 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-06 08:11:26 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-06 08:11:26 --> Final output sent to browser
DEBUG - 2011-04-06 08:11:26 --> Total execution time: 0.0443
DEBUG - 2011-04-06 08:49:07 --> Config Class Initialized
DEBUG - 2011-04-06 08:49:07 --> Hooks Class Initialized
DEBUG - 2011-04-06 08:49:07 --> Utf8 Class Initialized
DEBUG - 2011-04-06 08:49:07 --> UTF-8 Support Enabled
DEBUG - 2011-04-06 08:49:07 --> URI Class Initialized
DEBUG - 2011-04-06 08:49:07 --> Router Class Initialized
DEBUG - 2011-04-06 08:49:07 --> No URI present. Default controller set.
DEBUG - 2011-04-06 08:49:07 --> Output Class Initialized
DEBUG - 2011-04-06 08:49:07 --> Input Class Initialized
DEBUG - 2011-04-06 08:49:07 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-06 08:49:07 --> Language Class Initialized
DEBUG - 2011-04-06 08:49:07 --> Loader Class Initialized
DEBUG - 2011-04-06 08:49:07 --> Controller Class Initialized
DEBUG - 2011-04-06 08:49:07 --> File loaded: application/views/splash/main.php
DEBUG - 2011-04-06 08:49:07 --> Helper loaded: url_helper
DEBUG - 2011-04-06 08:49:07 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-06 08:49:07 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-06 08:49:07 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-06 08:49:07 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-06 08:49:07 --> Final output sent to browser
DEBUG - 2011-04-06 08:49:07 --> Total execution time: 0.1951
DEBUG - 2011-04-06 08:49:08 --> Config Class Initialized
DEBUG - 2011-04-06 08:49:08 --> Hooks Class Initialized
DEBUG - 2011-04-06 08:49:08 --> Utf8 Class Initialized
DEBUG - 2011-04-06 08:49:08 --> UTF-8 Support Enabled
DEBUG - 2011-04-06 08:49:08 --> URI Class Initialized
DEBUG - 2011-04-06 08:49:08 --> Router Class Initialized
ERROR - 2011-04-06 08:49:08 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-06 08:50:41 --> Config Class Initialized
DEBUG - 2011-04-06 08:50:41 --> Hooks Class Initialized
DEBUG - 2011-04-06 08:50:41 --> Utf8 Class Initialized
DEBUG - 2011-04-06 08:50:41 --> UTF-8 Support Enabled
DEBUG - 2011-04-06 08:50:41 --> URI Class Initialized
DEBUG - 2011-04-06 08:50:41 --> Router Class Initialized
DEBUG - 2011-04-06 08:50:41 --> No URI present. Default controller set.
DEBUG - 2011-04-06 08:50:41 --> Output Class Initialized
DEBUG - 2011-04-06 08:50:41 --> Input Class Initialized
DEBUG - 2011-04-06 08:50:41 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-06 08:50:41 --> Language Class Initialized
DEBUG - 2011-04-06 08:50:41 --> Loader Class Initialized
DEBUG - 2011-04-06 08:50:41 --> Controller Class Initialized
DEBUG - 2011-04-06 08:50:41 --> File loaded: application/views/splash/main.php
DEBUG - 2011-04-06 08:50:41 --> Helper loaded: url_helper
DEBUG - 2011-04-06 08:50:41 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-06 08:50:41 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-06 08:50:41 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-06 08:50:41 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-06 08:50:41 --> Final output sent to browser
DEBUG - 2011-04-06 08:50:41 --> Total execution time: 0.0656
DEBUG - 2011-04-06 08:50:46 --> Config Class Initialized
DEBUG - 2011-04-06 08:50:46 --> Hooks Class Initialized
DEBUG - 2011-04-06 08:50:46 --> Utf8 Class Initialized
DEBUG - 2011-04-06 08:50:46 --> UTF-8 Support Enabled
DEBUG - 2011-04-06 08:50:46 --> URI Class Initialized
DEBUG - 2011-04-06 08:50:46 --> Router Class Initialized
ERROR - 2011-04-06 08:50:46 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-06 08:50:52 --> Config Class Initialized
DEBUG - 2011-04-06 08:50:52 --> Hooks Class Initialized
DEBUG - 2011-04-06 08:50:52 --> Utf8 Class Initialized
DEBUG - 2011-04-06 08:50:52 --> UTF-8 Support Enabled
DEBUG - 2011-04-06 08:50:52 --> URI Class Initialized
DEBUG - 2011-04-06 08:50:52 --> Router Class Initialized
DEBUG - 2011-04-06 08:50:52 --> Output Class Initialized
DEBUG - 2011-04-06 08:50:52 --> Input Class Initialized
DEBUG - 2011-04-06 08:50:52 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-06 08:50:52 --> Language Class Initialized
DEBUG - 2011-04-06 08:50:52 --> Loader Class Initialized
DEBUG - 2011-04-06 08:50:52 --> Controller Class Initialized
ERROR - 2011-04-06 08:50:52 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-06 08:50:52 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-06 08:50:52 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-06 08:50:52 --> Model Class Initialized
DEBUG - 2011-04-06 08:50:52 --> Model Class Initialized
DEBUG - 2011-04-06 08:50:52 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-06 08:50:52 --> Database Driver Class Initialized
DEBUG - 2011-04-06 08:50:52 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-06 08:50:52 --> Helper loaded: url_helper
DEBUG - 2011-04-06 08:50:52 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-06 08:50:52 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-06 08:50:52 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-06 08:50:52 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-06 08:50:52 --> Final output sent to browser
DEBUG - 2011-04-06 08:50:52 --> Total execution time: 0.2951
DEBUG - 2011-04-06 08:50:53 --> Config Class Initialized
DEBUG - 2011-04-06 08:50:53 --> Hooks Class Initialized
DEBUG - 2011-04-06 08:50:53 --> Utf8 Class Initialized
DEBUG - 2011-04-06 08:50:53 --> UTF-8 Support Enabled
DEBUG - 2011-04-06 08:50:53 --> URI Class Initialized
DEBUG - 2011-04-06 08:50:53 --> Router Class Initialized
DEBUG - 2011-04-06 08:50:53 --> Output Class Initialized
DEBUG - 2011-04-06 08:50:53 --> Input Class Initialized
DEBUG - 2011-04-06 08:50:53 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-06 08:50:53 --> Language Class Initialized
DEBUG - 2011-04-06 08:50:53 --> Loader Class Initialized
DEBUG - 2011-04-06 08:50:53 --> Controller Class Initialized
DEBUG - 2011-04-06 08:50:53 --> Model Class Initialized
DEBUG - 2011-04-06 08:50:53 --> Model Class Initialized
DEBUG - 2011-04-06 08:50:53 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-06 08:50:53 --> Database Driver Class Initialized
DEBUG - 2011-04-06 08:50:55 --> Final output sent to browser
DEBUG - 2011-04-06 08:50:55 --> Total execution time: 1.3302
DEBUG - 2011-04-06 08:51:01 --> Config Class Initialized
DEBUG - 2011-04-06 08:51:01 --> Hooks Class Initialized
DEBUG - 2011-04-06 08:51:01 --> Utf8 Class Initialized
DEBUG - 2011-04-06 08:51:01 --> UTF-8 Support Enabled
DEBUG - 2011-04-06 08:51:01 --> URI Class Initialized
DEBUG - 2011-04-06 08:51:01 --> Router Class Initialized
DEBUG - 2011-04-06 08:51:01 --> Output Class Initialized
DEBUG - 2011-04-06 08:51:01 --> Input Class Initialized
DEBUG - 2011-04-06 08:51:01 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-06 08:51:01 --> Language Class Initialized
DEBUG - 2011-04-06 08:51:01 --> Loader Class Initialized
DEBUG - 2011-04-06 08:51:01 --> Controller Class Initialized
ERROR - 2011-04-06 08:51:01 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-06 08:51:01 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-06 08:51:01 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-06 08:51:01 --> Model Class Initialized
DEBUG - 2011-04-06 08:51:01 --> Model Class Initialized
DEBUG - 2011-04-06 08:51:01 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-06 08:51:01 --> Database Driver Class Initialized
DEBUG - 2011-04-06 08:51:01 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-06 08:51:01 --> Helper loaded: url_helper
DEBUG - 2011-04-06 08:51:01 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-06 08:51:01 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-06 08:51:01 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-06 08:51:01 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-06 08:51:01 --> Final output sent to browser
DEBUG - 2011-04-06 08:51:01 --> Total execution time: 0.1559
DEBUG - 2011-04-06 08:51:03 --> Config Class Initialized
DEBUG - 2011-04-06 08:51:03 --> Hooks Class Initialized
DEBUG - 2011-04-06 08:51:03 --> Utf8 Class Initialized
DEBUG - 2011-04-06 08:51:03 --> UTF-8 Support Enabled
DEBUG - 2011-04-06 08:51:03 --> URI Class Initialized
DEBUG - 2011-04-06 08:51:03 --> Router Class Initialized
DEBUG - 2011-04-06 08:51:03 --> Output Class Initialized
DEBUG - 2011-04-06 08:51:03 --> Input Class Initialized
DEBUG - 2011-04-06 08:51:03 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-06 08:51:03 --> Language Class Initialized
DEBUG - 2011-04-06 08:51:03 --> Loader Class Initialized
DEBUG - 2011-04-06 08:51:03 --> Controller Class Initialized
DEBUG - 2011-04-06 08:51:03 --> Model Class Initialized
DEBUG - 2011-04-06 08:51:03 --> Model Class Initialized
DEBUG - 2011-04-06 08:51:03 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-06 08:51:03 --> Database Driver Class Initialized
DEBUG - 2011-04-06 08:51:04 --> Final output sent to browser
DEBUG - 2011-04-06 08:51:04 --> Total execution time: 0.9476
DEBUG - 2011-04-06 08:51:14 --> Config Class Initialized
DEBUG - 2011-04-06 08:51:14 --> Hooks Class Initialized
DEBUG - 2011-04-06 08:51:14 --> Utf8 Class Initialized
DEBUG - 2011-04-06 08:51:14 --> UTF-8 Support Enabled
DEBUG - 2011-04-06 08:51:14 --> URI Class Initialized
DEBUG - 2011-04-06 08:51:14 --> Router Class Initialized
DEBUG - 2011-04-06 08:51:14 --> Output Class Initialized
DEBUG - 2011-04-06 08:51:14 --> Input Class Initialized
DEBUG - 2011-04-06 08:51:14 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-06 08:51:14 --> Language Class Initialized
DEBUG - 2011-04-06 08:51:14 --> Loader Class Initialized
DEBUG - 2011-04-06 08:51:14 --> Controller Class Initialized
ERROR - 2011-04-06 08:51:14 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-06 08:51:14 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-06 08:51:14 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-06 08:51:14 --> Model Class Initialized
DEBUG - 2011-04-06 08:51:14 --> Model Class Initialized
DEBUG - 2011-04-06 08:51:14 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-06 08:51:14 --> Database Driver Class Initialized
DEBUG - 2011-04-06 08:51:14 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-06 08:51:14 --> Helper loaded: url_helper
DEBUG - 2011-04-06 08:51:14 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-06 08:51:14 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-06 08:51:14 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-06 08:51:14 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-06 08:51:14 --> Final output sent to browser
DEBUG - 2011-04-06 08:51:14 --> Total execution time: 0.0384
DEBUG - 2011-04-06 08:51:15 --> Config Class Initialized
DEBUG - 2011-04-06 08:51:15 --> Hooks Class Initialized
DEBUG - 2011-04-06 08:51:15 --> Utf8 Class Initialized
DEBUG - 2011-04-06 08:51:15 --> UTF-8 Support Enabled
DEBUG - 2011-04-06 08:51:15 --> URI Class Initialized
DEBUG - 2011-04-06 08:51:15 --> Router Class Initialized
DEBUG - 2011-04-06 08:51:15 --> No URI present. Default controller set.
DEBUG - 2011-04-06 08:51:15 --> Output Class Initialized
DEBUG - 2011-04-06 08:51:15 --> Input Class Initialized
DEBUG - 2011-04-06 08:51:15 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-06 08:51:15 --> Language Class Initialized
DEBUG - 2011-04-06 08:51:15 --> Loader Class Initialized
DEBUG - 2011-04-06 08:51:15 --> Controller Class Initialized
DEBUG - 2011-04-06 08:51:15 --> File loaded: application/views/splash/main.php
DEBUG - 2011-04-06 08:51:15 --> Helper loaded: url_helper
DEBUG - 2011-04-06 08:51:15 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-06 08:51:15 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-06 08:51:15 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-06 08:51:15 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-06 08:51:15 --> Final output sent to browser
DEBUG - 2011-04-06 08:51:15 --> Total execution time: 0.0145
DEBUG - 2011-04-06 08:55:00 --> Config Class Initialized
DEBUG - 2011-04-06 08:55:00 --> Hooks Class Initialized
DEBUG - 2011-04-06 08:55:00 --> Utf8 Class Initialized
DEBUG - 2011-04-06 08:55:00 --> UTF-8 Support Enabled
DEBUG - 2011-04-06 08:55:00 --> URI Class Initialized
DEBUG - 2011-04-06 08:55:00 --> Router Class Initialized
ERROR - 2011-04-06 08:55:00 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-04-06 08:55:02 --> Config Class Initialized
DEBUG - 2011-04-06 08:55:02 --> Hooks Class Initialized
DEBUG - 2011-04-06 08:55:02 --> Utf8 Class Initialized
DEBUG - 2011-04-06 08:55:02 --> UTF-8 Support Enabled
DEBUG - 2011-04-06 08:55:02 --> URI Class Initialized
DEBUG - 2011-04-06 08:55:02 --> Router Class Initialized
DEBUG - 2011-04-06 08:55:02 --> Output Class Initialized
DEBUG - 2011-04-06 08:55:02 --> Input Class Initialized
DEBUG - 2011-04-06 08:55:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-06 08:55:02 --> Language Class Initialized
DEBUG - 2011-04-06 08:55:02 --> Loader Class Initialized
DEBUG - 2011-04-06 08:55:02 --> Controller Class Initialized
DEBUG - 2011-04-06 08:55:02 --> Model Class Initialized
DEBUG - 2011-04-06 08:55:02 --> Model Class Initialized
DEBUG - 2011-04-06 08:55:02 --> Model Class Initialized
DEBUG - 2011-04-06 08:55:02 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-06 08:55:02 --> Database Driver Class Initialized
DEBUG - 2011-04-06 08:55:03 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-06 08:55:03 --> Helper loaded: url_helper
DEBUG - 2011-04-06 08:55:03 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-06 08:55:03 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-06 08:55:03 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-06 08:55:03 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-06 08:55:03 --> Final output sent to browser
DEBUG - 2011-04-06 08:55:03 --> Total execution time: 1.3491
DEBUG - 2011-04-06 09:02:35 --> Config Class Initialized
DEBUG - 2011-04-06 09:02:35 --> Hooks Class Initialized
DEBUG - 2011-04-06 09:02:35 --> Utf8 Class Initialized
DEBUG - 2011-04-06 09:02:35 --> UTF-8 Support Enabled
DEBUG - 2011-04-06 09:02:35 --> URI Class Initialized
DEBUG - 2011-04-06 09:02:35 --> Router Class Initialized
DEBUG - 2011-04-06 09:02:35 --> No URI present. Default controller set.
DEBUG - 2011-04-06 09:02:35 --> Output Class Initialized
DEBUG - 2011-04-06 09:02:35 --> Input Class Initialized
DEBUG - 2011-04-06 09:02:35 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-06 09:02:35 --> Language Class Initialized
DEBUG - 2011-04-06 09:02:35 --> Loader Class Initialized
DEBUG - 2011-04-06 09:02:35 --> Controller Class Initialized
DEBUG - 2011-04-06 09:02:35 --> File loaded: application/views/splash/main.php
DEBUG - 2011-04-06 09:02:35 --> Helper loaded: url_helper
DEBUG - 2011-04-06 09:02:35 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-06 09:02:35 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-06 09:02:35 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-06 09:02:35 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-06 09:02:35 --> Final output sent to browser
DEBUG - 2011-04-06 09:02:35 --> Total execution time: 0.1805
DEBUG - 2011-04-06 10:39:57 --> Config Class Initialized
DEBUG - 2011-04-06 10:39:57 --> Hooks Class Initialized
DEBUG - 2011-04-06 10:39:57 --> Utf8 Class Initialized
DEBUG - 2011-04-06 10:39:57 --> UTF-8 Support Enabled
DEBUG - 2011-04-06 10:39:57 --> URI Class Initialized
DEBUG - 2011-04-06 10:39:57 --> Router Class Initialized
DEBUG - 2011-04-06 10:39:57 --> Output Class Initialized
DEBUG - 2011-04-06 10:39:57 --> Input Class Initialized
DEBUG - 2011-04-06 10:39:57 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-06 10:39:57 --> Language Class Initialized
DEBUG - 2011-04-06 10:39:57 --> Loader Class Initialized
DEBUG - 2011-04-06 10:39:58 --> Controller Class Initialized
ERROR - 2011-04-06 10:39:58 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-06 10:39:58 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-06 10:39:58 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-06 10:39:58 --> Model Class Initialized
DEBUG - 2011-04-06 10:39:58 --> Model Class Initialized
DEBUG - 2011-04-06 10:39:58 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-06 10:39:58 --> Database Driver Class Initialized
DEBUG - 2011-04-06 10:39:58 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-06 10:39:58 --> Helper loaded: url_helper
DEBUG - 2011-04-06 10:39:58 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-06 10:39:58 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-06 10:39:58 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-06 10:39:58 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-06 10:39:58 --> Final output sent to browser
DEBUG - 2011-04-06 10:39:58 --> Total execution time: 0.4865
DEBUG - 2011-04-06 10:39:59 --> Config Class Initialized
DEBUG - 2011-04-06 10:39:59 --> Hooks Class Initialized
DEBUG - 2011-04-06 10:39:59 --> Utf8 Class Initialized
DEBUG - 2011-04-06 10:39:59 --> UTF-8 Support Enabled
DEBUG - 2011-04-06 10:39:59 --> URI Class Initialized
DEBUG - 2011-04-06 10:39:59 --> Router Class Initialized
DEBUG - 2011-04-06 10:39:59 --> Output Class Initialized
DEBUG - 2011-04-06 10:39:59 --> Input Class Initialized
DEBUG - 2011-04-06 10:39:59 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-06 10:39:59 --> Language Class Initialized
DEBUG - 2011-04-06 10:39:59 --> Loader Class Initialized
DEBUG - 2011-04-06 10:39:59 --> Controller Class Initialized
DEBUG - 2011-04-06 10:39:59 --> Model Class Initialized
DEBUG - 2011-04-06 10:39:59 --> Model Class Initialized
DEBUG - 2011-04-06 10:39:59 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-06 10:39:59 --> Database Driver Class Initialized
DEBUG - 2011-04-06 10:40:00 --> Final output sent to browser
DEBUG - 2011-04-06 10:40:00 --> Total execution time: 0.8491
DEBUG - 2011-04-06 10:45:09 --> Config Class Initialized
DEBUG - 2011-04-06 10:45:09 --> Hooks Class Initialized
DEBUG - 2011-04-06 10:45:09 --> Utf8 Class Initialized
DEBUG - 2011-04-06 10:45:09 --> UTF-8 Support Enabled
DEBUG - 2011-04-06 10:45:09 --> URI Class Initialized
DEBUG - 2011-04-06 10:45:09 --> Router Class Initialized
DEBUG - 2011-04-06 10:45:09 --> No URI present. Default controller set.
DEBUG - 2011-04-06 10:45:09 --> Output Class Initialized
DEBUG - 2011-04-06 10:45:09 --> Input Class Initialized
DEBUG - 2011-04-06 10:45:09 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-06 10:45:09 --> Language Class Initialized
DEBUG - 2011-04-06 10:45:09 --> Loader Class Initialized
DEBUG - 2011-04-06 10:45:09 --> Controller Class Initialized
DEBUG - 2011-04-06 10:45:11 --> File loaded: application/views/splash/main.php
DEBUG - 2011-04-06 10:45:12 --> Helper loaded: url_helper
DEBUG - 2011-04-06 10:45:12 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-06 10:45:12 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-06 10:45:12 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-06 10:45:12 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-06 10:45:12 --> Final output sent to browser
DEBUG - 2011-04-06 10:45:12 --> Total execution time: 3.7645
DEBUG - 2011-04-06 10:45:16 --> Config Class Initialized
DEBUG - 2011-04-06 10:45:16 --> Hooks Class Initialized
DEBUG - 2011-04-06 10:45:16 --> Utf8 Class Initialized
DEBUG - 2011-04-06 10:45:16 --> UTF-8 Support Enabled
DEBUG - 2011-04-06 10:45:16 --> URI Class Initialized
DEBUG - 2011-04-06 10:45:16 --> Router Class Initialized
ERROR - 2011-04-06 10:45:16 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-06 10:45:21 --> Config Class Initialized
DEBUG - 2011-04-06 10:45:21 --> Hooks Class Initialized
DEBUG - 2011-04-06 10:45:21 --> Utf8 Class Initialized
DEBUG - 2011-04-06 10:45:21 --> UTF-8 Support Enabled
DEBUG - 2011-04-06 10:45:21 --> URI Class Initialized
DEBUG - 2011-04-06 10:45:21 --> Router Class Initialized
DEBUG - 2011-04-06 10:45:21 --> Output Class Initialized
DEBUG - 2011-04-06 10:45:21 --> Input Class Initialized
DEBUG - 2011-04-06 10:45:21 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-06 10:45:21 --> Language Class Initialized
DEBUG - 2011-04-06 10:45:21 --> Loader Class Initialized
DEBUG - 2011-04-06 10:45:21 --> Controller Class Initialized
ERROR - 2011-04-06 10:45:21 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-06 10:45:21 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-06 10:45:21 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-06 10:45:21 --> Model Class Initialized
DEBUG - 2011-04-06 10:45:21 --> Model Class Initialized
DEBUG - 2011-04-06 10:45:21 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-06 10:45:21 --> Database Driver Class Initialized
DEBUG - 2011-04-06 10:45:21 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-06 10:45:21 --> Helper loaded: url_helper
DEBUG - 2011-04-06 10:45:21 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-06 10:45:21 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-06 10:45:21 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-06 10:45:21 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-06 10:45:21 --> Final output sent to browser
DEBUG - 2011-04-06 10:45:21 --> Total execution time: 0.3938
DEBUG - 2011-04-06 10:45:22 --> Config Class Initialized
DEBUG - 2011-04-06 10:45:22 --> Hooks Class Initialized
DEBUG - 2011-04-06 10:45:22 --> Utf8 Class Initialized
DEBUG - 2011-04-06 10:45:22 --> UTF-8 Support Enabled
DEBUG - 2011-04-06 10:45:22 --> URI Class Initialized
DEBUG - 2011-04-06 10:45:22 --> Router Class Initialized
DEBUG - 2011-04-06 10:45:22 --> Output Class Initialized
DEBUG - 2011-04-06 10:45:22 --> Input Class Initialized
DEBUG - 2011-04-06 10:45:22 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-06 10:45:22 --> Language Class Initialized
DEBUG - 2011-04-06 10:45:22 --> Loader Class Initialized
DEBUG - 2011-04-06 10:45:22 --> Controller Class Initialized
DEBUG - 2011-04-06 10:45:22 --> Model Class Initialized
DEBUG - 2011-04-06 10:45:22 --> Model Class Initialized
DEBUG - 2011-04-06 10:45:22 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-06 10:45:22 --> Database Driver Class Initialized
DEBUG - 2011-04-06 10:45:23 --> Final output sent to browser
DEBUG - 2011-04-06 10:45:23 --> Total execution time: 0.7954
DEBUG - 2011-04-06 10:45:50 --> Config Class Initialized
DEBUG - 2011-04-06 10:45:50 --> Hooks Class Initialized
DEBUG - 2011-04-06 10:45:50 --> Utf8 Class Initialized
DEBUG - 2011-04-06 10:45:50 --> UTF-8 Support Enabled
DEBUG - 2011-04-06 10:45:50 --> URI Class Initialized
DEBUG - 2011-04-06 10:45:50 --> Router Class Initialized
DEBUG - 2011-04-06 10:45:50 --> Output Class Initialized
DEBUG - 2011-04-06 10:45:50 --> Input Class Initialized
DEBUG - 2011-04-06 10:45:50 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-06 10:45:50 --> Language Class Initialized
DEBUG - 2011-04-06 10:45:50 --> Loader Class Initialized
DEBUG - 2011-04-06 10:45:50 --> Controller Class Initialized
ERROR - 2011-04-06 10:45:50 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-06 10:45:50 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-06 10:45:50 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-06 10:45:50 --> Model Class Initialized
DEBUG - 2011-04-06 10:45:50 --> Model Class Initialized
DEBUG - 2011-04-06 10:45:50 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-06 10:45:50 --> Database Driver Class Initialized
DEBUG - 2011-04-06 10:45:50 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-06 10:45:50 --> Helper loaded: url_helper
DEBUG - 2011-04-06 10:45:50 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-06 10:45:50 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-06 10:45:50 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-06 10:45:50 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-06 10:45:50 --> Final output sent to browser
DEBUG - 2011-04-06 10:45:50 --> Total execution time: 0.0323
DEBUG - 2011-04-06 10:45:51 --> Config Class Initialized
DEBUG - 2011-04-06 10:45:51 --> Hooks Class Initialized
DEBUG - 2011-04-06 10:45:51 --> Utf8 Class Initialized
DEBUG - 2011-04-06 10:45:51 --> UTF-8 Support Enabled
DEBUG - 2011-04-06 10:45:51 --> URI Class Initialized
DEBUG - 2011-04-06 10:45:51 --> Router Class Initialized
DEBUG - 2011-04-06 10:45:51 --> Output Class Initialized
DEBUG - 2011-04-06 10:45:51 --> Input Class Initialized
DEBUG - 2011-04-06 10:45:51 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-06 10:45:51 --> Language Class Initialized
DEBUG - 2011-04-06 10:45:51 --> Loader Class Initialized
DEBUG - 2011-04-06 10:45:51 --> Controller Class Initialized
DEBUG - 2011-04-06 10:45:51 --> Model Class Initialized
DEBUG - 2011-04-06 10:45:51 --> Model Class Initialized
DEBUG - 2011-04-06 10:45:51 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-06 10:45:51 --> Database Driver Class Initialized
DEBUG - 2011-04-06 10:45:57 --> Final output sent to browser
DEBUG - 2011-04-06 10:45:57 --> Total execution time: 5.7217
DEBUG - 2011-04-06 10:46:04 --> Config Class Initialized
DEBUG - 2011-04-06 10:46:04 --> Hooks Class Initialized
DEBUG - 2011-04-06 10:46:04 --> Utf8 Class Initialized
DEBUG - 2011-04-06 10:46:04 --> UTF-8 Support Enabled
DEBUG - 2011-04-06 10:46:04 --> URI Class Initialized
DEBUG - 2011-04-06 10:46:04 --> Router Class Initialized
DEBUG - 2011-04-06 10:46:04 --> Output Class Initialized
DEBUG - 2011-04-06 10:46:04 --> Input Class Initialized
DEBUG - 2011-04-06 10:46:04 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-06 10:46:04 --> Language Class Initialized
DEBUG - 2011-04-06 10:46:04 --> Loader Class Initialized
DEBUG - 2011-04-06 10:46:04 --> Controller Class Initialized
ERROR - 2011-04-06 10:46:04 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-06 10:46:04 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-06 10:46:04 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-06 10:46:04 --> Model Class Initialized
DEBUG - 2011-04-06 10:46:04 --> Model Class Initialized
DEBUG - 2011-04-06 10:46:04 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-06 10:46:04 --> Database Driver Class Initialized
DEBUG - 2011-04-06 10:46:04 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-06 10:46:04 --> Helper loaded: url_helper
DEBUG - 2011-04-06 10:46:04 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-06 10:46:04 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-06 10:46:04 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-06 10:46:04 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-06 10:46:04 --> Final output sent to browser
DEBUG - 2011-04-06 10:46:04 --> Total execution time: 0.0401
DEBUG - 2011-04-06 10:46:05 --> Config Class Initialized
DEBUG - 2011-04-06 10:46:05 --> Hooks Class Initialized
DEBUG - 2011-04-06 10:46:05 --> Utf8 Class Initialized
DEBUG - 2011-04-06 10:46:05 --> UTF-8 Support Enabled
DEBUG - 2011-04-06 10:46:05 --> URI Class Initialized
DEBUG - 2011-04-06 10:46:05 --> Router Class Initialized
DEBUG - 2011-04-06 10:46:05 --> Output Class Initialized
DEBUG - 2011-04-06 10:46:05 --> Input Class Initialized
DEBUG - 2011-04-06 10:46:05 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-06 10:46:05 --> Language Class Initialized
DEBUG - 2011-04-06 10:46:05 --> Loader Class Initialized
DEBUG - 2011-04-06 10:46:05 --> Controller Class Initialized
DEBUG - 2011-04-06 10:46:05 --> Model Class Initialized
DEBUG - 2011-04-06 10:46:05 --> Model Class Initialized
DEBUG - 2011-04-06 10:46:05 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-06 10:46:05 --> Database Driver Class Initialized
DEBUG - 2011-04-06 10:46:05 --> Final output sent to browser
DEBUG - 2011-04-06 10:46:05 --> Total execution time: 0.5974
DEBUG - 2011-04-06 10:46:13 --> Config Class Initialized
DEBUG - 2011-04-06 10:46:13 --> Hooks Class Initialized
DEBUG - 2011-04-06 10:46:13 --> Utf8 Class Initialized
DEBUG - 2011-04-06 10:46:13 --> UTF-8 Support Enabled
DEBUG - 2011-04-06 10:46:13 --> URI Class Initialized
DEBUG - 2011-04-06 10:46:13 --> Router Class Initialized
DEBUG - 2011-04-06 10:46:13 --> Output Class Initialized
DEBUG - 2011-04-06 10:46:13 --> Input Class Initialized
DEBUG - 2011-04-06 10:46:13 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-06 10:46:13 --> Language Class Initialized
DEBUG - 2011-04-06 10:46:13 --> Loader Class Initialized
DEBUG - 2011-04-06 10:46:13 --> Controller Class Initialized
ERROR - 2011-04-06 10:46:13 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-06 10:46:13 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-06 10:46:13 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-06 10:46:13 --> Model Class Initialized
DEBUG - 2011-04-06 10:46:13 --> Model Class Initialized
DEBUG - 2011-04-06 10:46:13 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-06 10:46:13 --> Database Driver Class Initialized
DEBUG - 2011-04-06 10:46:13 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-06 10:46:13 --> Helper loaded: url_helper
DEBUG - 2011-04-06 10:46:13 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-06 10:46:13 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-06 10:46:13 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-06 10:46:13 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-06 10:46:13 --> Final output sent to browser
DEBUG - 2011-04-06 10:46:13 --> Total execution time: 0.1676
DEBUG - 2011-04-06 10:46:14 --> Config Class Initialized
DEBUG - 2011-04-06 10:46:14 --> Hooks Class Initialized
DEBUG - 2011-04-06 10:46:14 --> Utf8 Class Initialized
DEBUG - 2011-04-06 10:46:14 --> UTF-8 Support Enabled
DEBUG - 2011-04-06 10:46:14 --> URI Class Initialized
DEBUG - 2011-04-06 10:46:14 --> Router Class Initialized
DEBUG - 2011-04-06 10:46:14 --> Output Class Initialized
DEBUG - 2011-04-06 10:46:14 --> Input Class Initialized
DEBUG - 2011-04-06 10:46:14 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-06 10:46:14 --> Language Class Initialized
DEBUG - 2011-04-06 10:46:14 --> Loader Class Initialized
DEBUG - 2011-04-06 10:46:14 --> Controller Class Initialized
DEBUG - 2011-04-06 10:46:14 --> Model Class Initialized
DEBUG - 2011-04-06 10:46:14 --> Model Class Initialized
DEBUG - 2011-04-06 10:46:14 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-06 10:46:14 --> Database Driver Class Initialized
DEBUG - 2011-04-06 10:46:14 --> Final output sent to browser
DEBUG - 2011-04-06 10:46:14 --> Total execution time: 0.7779
DEBUG - 2011-04-06 10:46:24 --> Config Class Initialized
DEBUG - 2011-04-06 10:46:24 --> Hooks Class Initialized
DEBUG - 2011-04-06 10:46:24 --> Utf8 Class Initialized
DEBUG - 2011-04-06 10:46:24 --> UTF-8 Support Enabled
DEBUG - 2011-04-06 10:46:24 --> URI Class Initialized
DEBUG - 2011-04-06 10:46:24 --> Router Class Initialized
DEBUG - 2011-04-06 10:46:24 --> Output Class Initialized
DEBUG - 2011-04-06 10:46:24 --> Input Class Initialized
DEBUG - 2011-04-06 10:46:24 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-06 10:46:24 --> Language Class Initialized
DEBUG - 2011-04-06 10:46:24 --> Loader Class Initialized
DEBUG - 2011-04-06 10:46:24 --> Controller Class Initialized
ERROR - 2011-04-06 10:46:24 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-06 10:46:24 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-06 10:46:24 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-06 10:46:24 --> Model Class Initialized
DEBUG - 2011-04-06 10:46:24 --> Model Class Initialized
DEBUG - 2011-04-06 10:46:24 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-06 10:46:24 --> Database Driver Class Initialized
DEBUG - 2011-04-06 10:46:24 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-06 10:46:24 --> Helper loaded: url_helper
DEBUG - 2011-04-06 10:46:24 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-06 10:46:24 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-06 10:46:24 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-06 10:46:24 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-06 10:46:24 --> Final output sent to browser
DEBUG - 2011-04-06 10:46:24 --> Total execution time: 0.0297
DEBUG - 2011-04-06 10:46:25 --> Config Class Initialized
DEBUG - 2011-04-06 10:46:25 --> Hooks Class Initialized
DEBUG - 2011-04-06 10:46:25 --> Utf8 Class Initialized
DEBUG - 2011-04-06 10:46:25 --> UTF-8 Support Enabled
DEBUG - 2011-04-06 10:46:25 --> URI Class Initialized
DEBUG - 2011-04-06 10:46:25 --> Router Class Initialized
DEBUG - 2011-04-06 10:46:25 --> Output Class Initialized
DEBUG - 2011-04-06 10:46:25 --> Input Class Initialized
DEBUG - 2011-04-06 10:46:25 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-06 10:46:25 --> Language Class Initialized
DEBUG - 2011-04-06 10:46:25 --> Loader Class Initialized
DEBUG - 2011-04-06 10:46:25 --> Controller Class Initialized
DEBUG - 2011-04-06 10:46:25 --> Model Class Initialized
DEBUG - 2011-04-06 10:46:25 --> Model Class Initialized
DEBUG - 2011-04-06 10:46:25 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-06 10:46:25 --> Database Driver Class Initialized
DEBUG - 2011-04-06 10:46:26 --> Final output sent to browser
DEBUG - 2011-04-06 10:46:26 --> Total execution time: 1.4450
DEBUG - 2011-04-06 10:46:28 --> Config Class Initialized
DEBUG - 2011-04-06 10:46:28 --> Hooks Class Initialized
DEBUG - 2011-04-06 10:46:28 --> Utf8 Class Initialized
DEBUG - 2011-04-06 10:46:28 --> UTF-8 Support Enabled
DEBUG - 2011-04-06 10:46:28 --> URI Class Initialized
DEBUG - 2011-04-06 10:46:28 --> Router Class Initialized
ERROR - 2011-04-06 10:46:28 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-04-06 10:46:28 --> Config Class Initialized
DEBUG - 2011-04-06 10:46:28 --> Hooks Class Initialized
DEBUG - 2011-04-06 10:46:28 --> Utf8 Class Initialized
DEBUG - 2011-04-06 10:46:28 --> UTF-8 Support Enabled
DEBUG - 2011-04-06 10:46:28 --> URI Class Initialized
DEBUG - 2011-04-06 10:46:28 --> Router Class Initialized
DEBUG - 2011-04-06 10:46:28 --> Output Class Initialized
DEBUG - 2011-04-06 10:46:28 --> Input Class Initialized
DEBUG - 2011-04-06 10:46:28 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-06 10:46:28 --> Language Class Initialized
DEBUG - 2011-04-06 10:46:28 --> Loader Class Initialized
DEBUG - 2011-04-06 10:46:28 --> Controller Class Initialized
ERROR - 2011-04-06 10:46:28 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-06 10:46:28 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-06 10:46:28 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-06 10:46:28 --> Model Class Initialized
DEBUG - 2011-04-06 10:46:28 --> Model Class Initialized
DEBUG - 2011-04-06 10:46:28 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-06 10:46:28 --> Database Driver Class Initialized
DEBUG - 2011-04-06 10:46:28 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-06 10:46:28 --> Helper loaded: url_helper
DEBUG - 2011-04-06 10:46:28 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-06 10:46:28 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-06 10:46:28 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-06 10:46:28 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-06 10:46:28 --> Final output sent to browser
DEBUG - 2011-04-06 10:46:28 --> Total execution time: 0.0317
DEBUG - 2011-04-06 10:46:39 --> Config Class Initialized
DEBUG - 2011-04-06 10:46:39 --> Hooks Class Initialized
DEBUG - 2011-04-06 10:46:39 --> Utf8 Class Initialized
DEBUG - 2011-04-06 10:46:39 --> UTF-8 Support Enabled
DEBUG - 2011-04-06 10:46:39 --> URI Class Initialized
DEBUG - 2011-04-06 10:46:39 --> Router Class Initialized
DEBUG - 2011-04-06 10:46:39 --> Output Class Initialized
DEBUG - 2011-04-06 10:46:39 --> Input Class Initialized
DEBUG - 2011-04-06 10:46:39 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-06 10:46:39 --> Language Class Initialized
DEBUG - 2011-04-06 10:46:39 --> Loader Class Initialized
DEBUG - 2011-04-06 10:46:39 --> Controller Class Initialized
ERROR - 2011-04-06 10:46:39 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-06 10:46:39 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-06 10:46:39 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-06 10:46:39 --> Model Class Initialized
DEBUG - 2011-04-06 10:46:39 --> Model Class Initialized
DEBUG - 2011-04-06 10:46:39 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-06 10:46:39 --> Database Driver Class Initialized
DEBUG - 2011-04-06 10:46:39 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-06 10:46:39 --> Helper loaded: url_helper
DEBUG - 2011-04-06 10:46:39 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-06 10:46:39 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-06 10:46:39 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-06 10:46:39 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-06 10:46:39 --> Final output sent to browser
DEBUG - 2011-04-06 10:46:39 --> Total execution time: 0.1356
DEBUG - 2011-04-06 10:46:40 --> Config Class Initialized
DEBUG - 2011-04-06 10:46:40 --> Hooks Class Initialized
DEBUG - 2011-04-06 10:46:40 --> Utf8 Class Initialized
DEBUG - 2011-04-06 10:46:40 --> UTF-8 Support Enabled
DEBUG - 2011-04-06 10:46:40 --> URI Class Initialized
DEBUG - 2011-04-06 10:46:40 --> Router Class Initialized
DEBUG - 2011-04-06 10:46:40 --> Output Class Initialized
DEBUG - 2011-04-06 10:46:40 --> Input Class Initialized
DEBUG - 2011-04-06 10:46:40 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-06 10:46:40 --> Language Class Initialized
DEBUG - 2011-04-06 10:46:40 --> Loader Class Initialized
DEBUG - 2011-04-06 10:46:40 --> Controller Class Initialized
DEBUG - 2011-04-06 10:46:40 --> Model Class Initialized
DEBUG - 2011-04-06 10:46:40 --> Model Class Initialized
DEBUG - 2011-04-06 10:46:40 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-06 10:46:40 --> Database Driver Class Initialized
DEBUG - 2011-04-06 10:46:41 --> Final output sent to browser
DEBUG - 2011-04-06 10:46:41 --> Total execution time: 1.0574
DEBUG - 2011-04-06 10:46:48 --> Config Class Initialized
DEBUG - 2011-04-06 10:46:48 --> Hooks Class Initialized
DEBUG - 2011-04-06 10:46:48 --> Utf8 Class Initialized
DEBUG - 2011-04-06 10:46:48 --> UTF-8 Support Enabled
DEBUG - 2011-04-06 10:46:48 --> URI Class Initialized
DEBUG - 2011-04-06 10:46:48 --> Router Class Initialized
DEBUG - 2011-04-06 10:46:48 --> Output Class Initialized
DEBUG - 2011-04-06 10:46:48 --> Input Class Initialized
DEBUG - 2011-04-06 10:46:48 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-06 10:46:48 --> Language Class Initialized
DEBUG - 2011-04-06 10:46:48 --> Loader Class Initialized
DEBUG - 2011-04-06 10:46:48 --> Controller Class Initialized
ERROR - 2011-04-06 10:46:48 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-06 10:46:48 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-06 10:46:48 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-06 10:46:48 --> Model Class Initialized
DEBUG - 2011-04-06 10:46:48 --> Model Class Initialized
DEBUG - 2011-04-06 10:46:48 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-06 10:46:48 --> Database Driver Class Initialized
DEBUG - 2011-04-06 10:46:48 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-06 10:46:48 --> Helper loaded: url_helper
DEBUG - 2011-04-06 10:46:48 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-06 10:46:48 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-06 10:46:48 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-06 10:46:48 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-06 10:46:48 --> Final output sent to browser
DEBUG - 2011-04-06 10:46:48 --> Total execution time: 0.0392
DEBUG - 2011-04-06 10:46:48 --> Config Class Initialized
DEBUG - 2011-04-06 10:46:48 --> Hooks Class Initialized
DEBUG - 2011-04-06 10:46:48 --> Utf8 Class Initialized
DEBUG - 2011-04-06 10:46:48 --> UTF-8 Support Enabled
DEBUG - 2011-04-06 10:46:48 --> URI Class Initialized
DEBUG - 2011-04-06 10:46:48 --> Router Class Initialized
DEBUG - 2011-04-06 10:46:48 --> Output Class Initialized
DEBUG - 2011-04-06 10:46:48 --> Input Class Initialized
DEBUG - 2011-04-06 10:46:48 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-06 10:46:48 --> Language Class Initialized
DEBUG - 2011-04-06 10:46:48 --> Loader Class Initialized
DEBUG - 2011-04-06 10:46:48 --> Controller Class Initialized
DEBUG - 2011-04-06 10:46:48 --> Model Class Initialized
DEBUG - 2011-04-06 10:46:48 --> Model Class Initialized
DEBUG - 2011-04-06 10:46:48 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-06 10:46:48 --> Database Driver Class Initialized
DEBUG - 2011-04-06 10:46:49 --> Final output sent to browser
DEBUG - 2011-04-06 10:46:49 --> Total execution time: 0.6224
DEBUG - 2011-04-06 10:46:55 --> Config Class Initialized
DEBUG - 2011-04-06 10:46:55 --> Hooks Class Initialized
DEBUG - 2011-04-06 10:46:55 --> Utf8 Class Initialized
DEBUG - 2011-04-06 10:46:55 --> UTF-8 Support Enabled
DEBUG - 2011-04-06 10:46:55 --> URI Class Initialized
DEBUG - 2011-04-06 10:46:55 --> Router Class Initialized
DEBUG - 2011-04-06 10:46:55 --> Output Class Initialized
DEBUG - 2011-04-06 10:46:55 --> Input Class Initialized
DEBUG - 2011-04-06 10:46:55 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-06 10:46:55 --> Language Class Initialized
DEBUG - 2011-04-06 10:46:55 --> Loader Class Initialized
DEBUG - 2011-04-06 10:46:55 --> Controller Class Initialized
ERROR - 2011-04-06 10:46:55 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-06 10:46:55 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-06 10:46:55 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-06 10:46:55 --> Model Class Initialized
DEBUG - 2011-04-06 10:46:55 --> Model Class Initialized
DEBUG - 2011-04-06 10:46:55 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-06 10:46:55 --> Database Driver Class Initialized
DEBUG - 2011-04-06 10:46:55 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-06 10:46:55 --> Helper loaded: url_helper
DEBUG - 2011-04-06 10:46:55 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-06 10:46:55 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-06 10:46:55 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-06 10:46:55 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-06 10:46:55 --> Final output sent to browser
DEBUG - 2011-04-06 10:46:55 --> Total execution time: 0.0615
DEBUG - 2011-04-06 10:46:55 --> Config Class Initialized
DEBUG - 2011-04-06 10:46:55 --> Hooks Class Initialized
DEBUG - 2011-04-06 10:46:55 --> Utf8 Class Initialized
DEBUG - 2011-04-06 10:46:55 --> UTF-8 Support Enabled
DEBUG - 2011-04-06 10:46:55 --> URI Class Initialized
DEBUG - 2011-04-06 10:46:55 --> Router Class Initialized
DEBUG - 2011-04-06 10:46:55 --> Output Class Initialized
DEBUG - 2011-04-06 10:46:55 --> Input Class Initialized
DEBUG - 2011-04-06 10:46:55 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-06 10:46:55 --> Language Class Initialized
DEBUG - 2011-04-06 10:46:55 --> Loader Class Initialized
DEBUG - 2011-04-06 10:46:55 --> Controller Class Initialized
DEBUG - 2011-04-06 10:46:55 --> Model Class Initialized
DEBUG - 2011-04-06 10:46:55 --> Model Class Initialized
DEBUG - 2011-04-06 10:46:55 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-06 10:46:55 --> Database Driver Class Initialized
DEBUG - 2011-04-06 10:46:56 --> Final output sent to browser
DEBUG - 2011-04-06 10:46:56 --> Total execution time: 1.1543
DEBUG - 2011-04-06 10:46:58 --> Config Class Initialized
DEBUG - 2011-04-06 10:46:58 --> Hooks Class Initialized
DEBUG - 2011-04-06 10:46:58 --> Utf8 Class Initialized
DEBUG - 2011-04-06 10:46:58 --> UTF-8 Support Enabled
DEBUG - 2011-04-06 10:46:58 --> URI Class Initialized
DEBUG - 2011-04-06 10:46:58 --> Router Class Initialized
DEBUG - 2011-04-06 10:46:58 --> Output Class Initialized
DEBUG - 2011-04-06 10:46:58 --> Input Class Initialized
DEBUG - 2011-04-06 10:46:58 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-06 10:46:58 --> Language Class Initialized
DEBUG - 2011-04-06 10:46:58 --> Loader Class Initialized
DEBUG - 2011-04-06 10:46:58 --> Controller Class Initialized
DEBUG - 2011-04-06 10:46:58 --> Model Class Initialized
DEBUG - 2011-04-06 10:46:58 --> Model Class Initialized
DEBUG - 2011-04-06 10:46:58 --> Model Class Initialized
DEBUG - 2011-04-06 10:46:58 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-06 10:46:58 --> Database Driver Class Initialized
DEBUG - 2011-04-06 10:46:59 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-06 10:46:59 --> Helper loaded: url_helper
DEBUG - 2011-04-06 10:46:59 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-06 10:46:59 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-06 10:46:59 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-06 10:46:59 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-06 10:46:59 --> Final output sent to browser
DEBUG - 2011-04-06 10:46:59 --> Total execution time: 0.7623
DEBUG - 2011-04-06 10:47:02 --> Config Class Initialized
DEBUG - 2011-04-06 10:47:02 --> Hooks Class Initialized
DEBUG - 2011-04-06 10:47:02 --> Utf8 Class Initialized
DEBUG - 2011-04-06 10:47:02 --> UTF-8 Support Enabled
DEBUG - 2011-04-06 10:47:02 --> URI Class Initialized
DEBUG - 2011-04-06 10:47:02 --> Router Class Initialized
DEBUG - 2011-04-06 10:47:02 --> Output Class Initialized
DEBUG - 2011-04-06 10:47:02 --> Input Class Initialized
DEBUG - 2011-04-06 10:47:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-06 10:47:02 --> Language Class Initialized
DEBUG - 2011-04-06 10:47:02 --> Loader Class Initialized
DEBUG - 2011-04-06 10:47:02 --> Controller Class Initialized
ERROR - 2011-04-06 10:47:02 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-06 10:47:02 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-06 10:47:02 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-06 10:47:02 --> Model Class Initialized
DEBUG - 2011-04-06 10:47:02 --> Model Class Initialized
DEBUG - 2011-04-06 10:47:02 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-06 10:47:02 --> Database Driver Class Initialized
DEBUG - 2011-04-06 10:47:02 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-06 10:47:02 --> Helper loaded: url_helper
DEBUG - 2011-04-06 10:47:02 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-06 10:47:02 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-06 10:47:02 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-06 10:47:02 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-06 10:47:02 --> Final output sent to browser
DEBUG - 2011-04-06 10:47:02 --> Total execution time: 0.3286
DEBUG - 2011-04-06 10:47:03 --> Config Class Initialized
DEBUG - 2011-04-06 10:47:03 --> Hooks Class Initialized
DEBUG - 2011-04-06 10:47:03 --> Utf8 Class Initialized
DEBUG - 2011-04-06 10:47:03 --> UTF-8 Support Enabled
DEBUG - 2011-04-06 10:47:03 --> URI Class Initialized
DEBUG - 2011-04-06 10:47:03 --> Router Class Initialized
DEBUG - 2011-04-06 10:47:03 --> Output Class Initialized
DEBUG - 2011-04-06 10:47:03 --> Input Class Initialized
DEBUG - 2011-04-06 10:47:03 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-06 10:47:03 --> Language Class Initialized
DEBUG - 2011-04-06 10:47:03 --> Loader Class Initialized
DEBUG - 2011-04-06 10:47:03 --> Controller Class Initialized
DEBUG - 2011-04-06 10:47:03 --> Model Class Initialized
DEBUG - 2011-04-06 10:47:03 --> Model Class Initialized
DEBUG - 2011-04-06 10:47:03 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-06 10:47:03 --> Database Driver Class Initialized
DEBUG - 2011-04-06 10:47:04 --> Final output sent to browser
DEBUG - 2011-04-06 10:47:04 --> Total execution time: 0.9854
DEBUG - 2011-04-06 10:47:27 --> Config Class Initialized
DEBUG - 2011-04-06 10:47:27 --> Hooks Class Initialized
DEBUG - 2011-04-06 10:47:27 --> Utf8 Class Initialized
DEBUG - 2011-04-06 10:47:27 --> UTF-8 Support Enabled
DEBUG - 2011-04-06 10:47:27 --> URI Class Initialized
DEBUG - 2011-04-06 10:47:27 --> Router Class Initialized
DEBUG - 2011-04-06 10:47:27 --> Output Class Initialized
DEBUG - 2011-04-06 10:47:27 --> Input Class Initialized
DEBUG - 2011-04-06 10:47:27 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-06 10:47:27 --> Language Class Initialized
DEBUG - 2011-04-06 10:47:27 --> Loader Class Initialized
DEBUG - 2011-04-06 10:47:27 --> Controller Class Initialized
ERROR - 2011-04-06 10:47:27 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-06 10:47:27 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-06 10:47:27 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-06 10:47:27 --> Model Class Initialized
DEBUG - 2011-04-06 10:47:27 --> Model Class Initialized
DEBUG - 2011-04-06 10:47:27 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-06 10:47:28 --> Database Driver Class Initialized
DEBUG - 2011-04-06 10:47:28 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-06 10:47:28 --> Helper loaded: url_helper
DEBUG - 2011-04-06 10:47:28 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-06 10:47:28 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-06 10:47:28 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-06 10:47:28 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-06 10:47:28 --> Final output sent to browser
DEBUG - 2011-04-06 10:47:28 --> Total execution time: 0.2169
DEBUG - 2011-04-06 10:47:28 --> Config Class Initialized
DEBUG - 2011-04-06 10:47:28 --> Hooks Class Initialized
DEBUG - 2011-04-06 10:47:28 --> Utf8 Class Initialized
DEBUG - 2011-04-06 10:47:28 --> UTF-8 Support Enabled
DEBUG - 2011-04-06 10:47:28 --> URI Class Initialized
DEBUG - 2011-04-06 10:47:28 --> Router Class Initialized
DEBUG - 2011-04-06 10:47:28 --> Output Class Initialized
DEBUG - 2011-04-06 10:47:28 --> Input Class Initialized
DEBUG - 2011-04-06 10:47:28 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-06 10:47:28 --> Language Class Initialized
DEBUG - 2011-04-06 10:47:28 --> Loader Class Initialized
DEBUG - 2011-04-06 10:47:28 --> Controller Class Initialized
DEBUG - 2011-04-06 10:47:28 --> Model Class Initialized
DEBUG - 2011-04-06 10:47:28 --> Model Class Initialized
DEBUG - 2011-04-06 10:47:28 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-06 10:47:28 --> Database Driver Class Initialized
DEBUG - 2011-04-06 10:47:29 --> Final output sent to browser
DEBUG - 2011-04-06 10:47:29 --> Total execution time: 0.9089
DEBUG - 2011-04-06 10:48:31 --> Config Class Initialized
DEBUG - 2011-04-06 10:48:31 --> Hooks Class Initialized
DEBUG - 2011-04-06 10:48:31 --> Utf8 Class Initialized
DEBUG - 2011-04-06 10:48:31 --> UTF-8 Support Enabled
DEBUG - 2011-04-06 10:48:31 --> URI Class Initialized
DEBUG - 2011-04-06 10:48:31 --> Router Class Initialized
DEBUG - 2011-04-06 10:48:31 --> No URI present. Default controller set.
DEBUG - 2011-04-06 10:48:31 --> Output Class Initialized
DEBUG - 2011-04-06 10:48:31 --> Input Class Initialized
DEBUG - 2011-04-06 10:48:31 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-06 10:48:31 --> Language Class Initialized
DEBUG - 2011-04-06 10:48:31 --> Loader Class Initialized
DEBUG - 2011-04-06 10:48:31 --> Controller Class Initialized
DEBUG - 2011-04-06 10:48:31 --> File loaded: application/views/splash/main.php
DEBUG - 2011-04-06 10:48:31 --> Helper loaded: url_helper
DEBUG - 2011-04-06 10:48:31 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-06 10:48:31 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-06 10:48:31 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-06 10:48:31 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-06 10:48:31 --> Final output sent to browser
DEBUG - 2011-04-06 10:48:31 --> Total execution time: 0.0137
DEBUG - 2011-04-06 11:39:24 --> Config Class Initialized
DEBUG - 2011-04-06 11:39:24 --> Hooks Class Initialized
DEBUG - 2011-04-06 11:39:25 --> Utf8 Class Initialized
DEBUG - 2011-04-06 11:39:25 --> UTF-8 Support Enabled
DEBUG - 2011-04-06 11:39:25 --> URI Class Initialized
DEBUG - 2011-04-06 11:39:25 --> Router Class Initialized
DEBUG - 2011-04-06 11:39:25 --> No URI present. Default controller set.
DEBUG - 2011-04-06 11:39:25 --> Output Class Initialized
DEBUG - 2011-04-06 11:39:25 --> Input Class Initialized
DEBUG - 2011-04-06 11:39:25 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-06 11:39:25 --> Language Class Initialized
DEBUG - 2011-04-06 11:39:25 --> Loader Class Initialized
DEBUG - 2011-04-06 11:39:25 --> Controller Class Initialized
DEBUG - 2011-04-06 11:39:25 --> File loaded: application/views/splash/main.php
DEBUG - 2011-04-06 11:39:25 --> Helper loaded: url_helper
DEBUG - 2011-04-06 11:39:25 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-06 11:39:25 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-06 11:39:25 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-06 11:39:25 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-06 11:39:25 --> Final output sent to browser
DEBUG - 2011-04-06 11:39:25 --> Total execution time: 0.4204
DEBUG - 2011-04-06 11:39:44 --> Config Class Initialized
DEBUG - 2011-04-06 11:39:44 --> Hooks Class Initialized
DEBUG - 2011-04-06 11:39:44 --> Utf8 Class Initialized
DEBUG - 2011-04-06 11:39:44 --> UTF-8 Support Enabled
DEBUG - 2011-04-06 11:39:44 --> URI Class Initialized
DEBUG - 2011-04-06 11:39:44 --> Router Class Initialized
DEBUG - 2011-04-06 11:39:44 --> Output Class Initialized
DEBUG - 2011-04-06 11:39:44 --> Input Class Initialized
DEBUG - 2011-04-06 11:39:44 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-06 11:39:44 --> Language Class Initialized
DEBUG - 2011-04-06 11:39:44 --> Loader Class Initialized
DEBUG - 2011-04-06 11:39:44 --> Controller Class Initialized
DEBUG - 2011-04-06 11:39:44 --> Model Class Initialized
DEBUG - 2011-04-06 11:39:44 --> Model Class Initialized
DEBUG - 2011-04-06 11:39:44 --> Model Class Initialized
DEBUG - 2011-04-06 11:39:44 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-06 11:39:44 --> Database Driver Class Initialized
DEBUG - 2011-04-06 11:39:45 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-06 11:39:45 --> Helper loaded: url_helper
DEBUG - 2011-04-06 11:39:45 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-06 11:39:45 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-06 11:39:45 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-06 11:39:45 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-06 11:39:45 --> Final output sent to browser
DEBUG - 2011-04-06 11:39:45 --> Total execution time: 0.7694
DEBUG - 2011-04-06 11:40:24 --> Config Class Initialized
DEBUG - 2011-04-06 11:40:24 --> Hooks Class Initialized
DEBUG - 2011-04-06 11:40:24 --> Utf8 Class Initialized
DEBUG - 2011-04-06 11:40:24 --> UTF-8 Support Enabled
DEBUG - 2011-04-06 11:40:24 --> URI Class Initialized
DEBUG - 2011-04-06 11:40:24 --> Router Class Initialized
DEBUG - 2011-04-06 11:40:24 --> Output Class Initialized
DEBUG - 2011-04-06 11:40:24 --> Input Class Initialized
DEBUG - 2011-04-06 11:40:24 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-06 11:40:24 --> Language Class Initialized
DEBUG - 2011-04-06 11:40:24 --> Loader Class Initialized
DEBUG - 2011-04-06 11:40:24 --> Controller Class Initialized
DEBUG - 2011-04-06 11:40:24 --> Model Class Initialized
DEBUG - 2011-04-06 11:40:24 --> Model Class Initialized
DEBUG - 2011-04-06 11:40:24 --> Model Class Initialized
DEBUG - 2011-04-06 11:40:24 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-06 11:40:25 --> Database Driver Class Initialized
DEBUG - 2011-04-06 11:40:25 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-06 11:40:25 --> Helper loaded: url_helper
DEBUG - 2011-04-06 11:40:25 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-06 11:40:25 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-06 11:40:25 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-06 11:40:25 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-06 11:40:25 --> Final output sent to browser
DEBUG - 2011-04-06 11:40:25 --> Total execution time: 0.8741
DEBUG - 2011-04-06 11:40:31 --> Config Class Initialized
DEBUG - 2011-04-06 11:40:31 --> Hooks Class Initialized
DEBUG - 2011-04-06 11:40:31 --> Utf8 Class Initialized
DEBUG - 2011-04-06 11:40:31 --> UTF-8 Support Enabled
DEBUG - 2011-04-06 11:40:31 --> URI Class Initialized
DEBUG - 2011-04-06 11:40:31 --> Router Class Initialized
DEBUG - 2011-04-06 11:40:31 --> Output Class Initialized
DEBUG - 2011-04-06 11:40:31 --> Input Class Initialized
DEBUG - 2011-04-06 11:40:31 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-06 11:40:31 --> Language Class Initialized
DEBUG - 2011-04-06 11:40:31 --> Loader Class Initialized
DEBUG - 2011-04-06 11:40:31 --> Controller Class Initialized
DEBUG - 2011-04-06 11:40:31 --> Model Class Initialized
DEBUG - 2011-04-06 11:40:31 --> Model Class Initialized
DEBUG - 2011-04-06 11:40:31 --> Model Class Initialized
DEBUG - 2011-04-06 11:40:31 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-06 11:40:31 --> Database Driver Class Initialized
DEBUG - 2011-04-06 11:40:31 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-06 11:40:31 --> Helper loaded: url_helper
DEBUG - 2011-04-06 11:40:31 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-06 11:40:31 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-06 11:40:31 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-06 11:40:31 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-06 11:40:31 --> Final output sent to browser
DEBUG - 2011-04-06 11:40:31 --> Total execution time: 0.1400
DEBUG - 2011-04-06 11:40:49 --> Config Class Initialized
DEBUG - 2011-04-06 11:40:49 --> Hooks Class Initialized
DEBUG - 2011-04-06 11:40:49 --> Utf8 Class Initialized
DEBUG - 2011-04-06 11:40:49 --> UTF-8 Support Enabled
DEBUG - 2011-04-06 11:40:49 --> URI Class Initialized
DEBUG - 2011-04-06 11:40:49 --> Router Class Initialized
DEBUG - 2011-04-06 11:40:49 --> Output Class Initialized
DEBUG - 2011-04-06 11:40:49 --> Input Class Initialized
DEBUG - 2011-04-06 11:40:49 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-06 11:40:49 --> Language Class Initialized
DEBUG - 2011-04-06 11:40:49 --> Loader Class Initialized
DEBUG - 2011-04-06 11:40:49 --> Controller Class Initialized
DEBUG - 2011-04-06 11:40:49 --> Model Class Initialized
DEBUG - 2011-04-06 11:40:49 --> Model Class Initialized
DEBUG - 2011-04-06 11:40:49 --> Model Class Initialized
DEBUG - 2011-04-06 11:40:49 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-06 11:40:49 --> Database Driver Class Initialized
DEBUG - 2011-04-06 11:40:50 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-06 11:40:50 --> Helper loaded: url_helper
DEBUG - 2011-04-06 11:40:50 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-06 11:40:50 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-06 11:40:50 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-06 11:40:50 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-06 11:40:50 --> Final output sent to browser
DEBUG - 2011-04-06 11:40:50 --> Total execution time: 0.8892
DEBUG - 2011-04-06 11:40:52 --> Config Class Initialized
DEBUG - 2011-04-06 11:40:52 --> Hooks Class Initialized
DEBUG - 2011-04-06 11:40:52 --> Utf8 Class Initialized
DEBUG - 2011-04-06 11:40:52 --> UTF-8 Support Enabled
DEBUG - 2011-04-06 11:40:52 --> URI Class Initialized
DEBUG - 2011-04-06 11:40:52 --> Router Class Initialized
DEBUG - 2011-04-06 11:40:52 --> Output Class Initialized
DEBUG - 2011-04-06 11:40:52 --> Input Class Initialized
DEBUG - 2011-04-06 11:40:52 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-06 11:40:52 --> Language Class Initialized
DEBUG - 2011-04-06 11:40:52 --> Loader Class Initialized
DEBUG - 2011-04-06 11:40:52 --> Controller Class Initialized
DEBUG - 2011-04-06 11:40:52 --> Model Class Initialized
DEBUG - 2011-04-06 11:40:52 --> Model Class Initialized
DEBUG - 2011-04-06 11:40:52 --> Model Class Initialized
DEBUG - 2011-04-06 11:40:52 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-06 11:40:52 --> Database Driver Class Initialized
DEBUG - 2011-04-06 11:40:52 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-06 11:40:52 --> Helper loaded: url_helper
DEBUG - 2011-04-06 11:40:52 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-06 11:40:52 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-06 11:40:52 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-06 11:40:52 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-06 11:40:52 --> Final output sent to browser
DEBUG - 2011-04-06 11:40:52 --> Total execution time: 0.2507
DEBUG - 2011-04-06 11:54:29 --> Config Class Initialized
DEBUG - 2011-04-06 11:54:29 --> Hooks Class Initialized
DEBUG - 2011-04-06 11:54:29 --> Utf8 Class Initialized
DEBUG - 2011-04-06 11:54:29 --> UTF-8 Support Enabled
DEBUG - 2011-04-06 11:54:29 --> URI Class Initialized
DEBUG - 2011-04-06 11:54:29 --> Router Class Initialized
DEBUG - 2011-04-06 11:54:29 --> No URI present. Default controller set.
DEBUG - 2011-04-06 11:54:29 --> Output Class Initialized
DEBUG - 2011-04-06 11:54:29 --> Input Class Initialized
DEBUG - 2011-04-06 11:54:29 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-06 11:54:29 --> Language Class Initialized
DEBUG - 2011-04-06 11:54:29 --> Loader Class Initialized
DEBUG - 2011-04-06 11:54:29 --> Controller Class Initialized
DEBUG - 2011-04-06 11:54:29 --> File loaded: application/views/splash/main.php
DEBUG - 2011-04-06 11:54:29 --> Helper loaded: url_helper
DEBUG - 2011-04-06 11:54:29 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-06 11:54:29 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-06 11:54:29 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-06 11:54:29 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-06 11:54:29 --> Final output sent to browser
DEBUG - 2011-04-06 11:54:29 --> Total execution time: 0.2911
DEBUG - 2011-04-06 11:54:31 --> Config Class Initialized
DEBUG - 2011-04-06 11:54:31 --> Hooks Class Initialized
DEBUG - 2011-04-06 11:54:31 --> Utf8 Class Initialized
DEBUG - 2011-04-06 11:54:31 --> UTF-8 Support Enabled
DEBUG - 2011-04-06 11:54:31 --> URI Class Initialized
DEBUG - 2011-04-06 11:54:31 --> Router Class Initialized
ERROR - 2011-04-06 11:54:31 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-06 11:54:31 --> Config Class Initialized
DEBUG - 2011-04-06 11:54:31 --> Hooks Class Initialized
DEBUG - 2011-04-06 11:54:31 --> Utf8 Class Initialized
DEBUG - 2011-04-06 11:54:31 --> UTF-8 Support Enabled
DEBUG - 2011-04-06 11:54:31 --> URI Class Initialized
DEBUG - 2011-04-06 11:54:31 --> Router Class Initialized
DEBUG - 2011-04-06 11:54:31 --> No URI present. Default controller set.
DEBUG - 2011-04-06 11:54:31 --> Output Class Initialized
DEBUG - 2011-04-06 11:54:31 --> Input Class Initialized
DEBUG - 2011-04-06 11:54:31 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-06 11:54:31 --> Language Class Initialized
DEBUG - 2011-04-06 11:54:31 --> Config Class Initialized
DEBUG - 2011-04-06 11:54:31 --> Hooks Class Initialized
DEBUG - 2011-04-06 11:54:31 --> Loader Class Initialized
DEBUG - 2011-04-06 11:54:31 --> Utf8 Class Initialized
DEBUG - 2011-04-06 11:54:31 --> UTF-8 Support Enabled
DEBUG - 2011-04-06 11:54:31 --> Controller Class Initialized
DEBUG - 2011-04-06 11:54:31 --> File loaded: application/views/splash/main.php
DEBUG - 2011-04-06 11:54:31 --> URI Class Initialized
DEBUG - 2011-04-06 11:54:31 --> Helper loaded: url_helper
DEBUG - 2011-04-06 11:54:31 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-06 11:54:31 --> Router Class Initialized
DEBUG - 2011-04-06 11:54:31 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-06 11:54:31 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-06 11:54:31 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-06 11:54:31 --> No URI present. Default controller set.
DEBUG - 2011-04-06 11:54:31 --> Final output sent to browser
DEBUG - 2011-04-06 11:54:31 --> Total execution time: 0.0215
DEBUG - 2011-04-06 11:54:31 --> Output Class Initialized
DEBUG - 2011-04-06 11:54:31 --> Input Class Initialized
DEBUG - 2011-04-06 11:54:31 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-06 11:54:31 --> Language Class Initialized
DEBUG - 2011-04-06 11:54:31 --> Loader Class Initialized
DEBUG - 2011-04-06 11:54:31 --> Controller Class Initialized
DEBUG - 2011-04-06 11:54:31 --> File loaded: application/views/splash/main.php
DEBUG - 2011-04-06 11:54:31 --> Helper loaded: url_helper
DEBUG - 2011-04-06 11:54:31 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-06 11:54:31 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-06 11:54:31 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-06 11:54:31 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-06 11:54:31 --> Final output sent to browser
DEBUG - 2011-04-06 11:54:31 --> Total execution time: 0.0217
DEBUG - 2011-04-06 11:54:31 --> Config Class Initialized
DEBUG - 2011-04-06 11:54:31 --> Hooks Class Initialized
DEBUG - 2011-04-06 11:54:31 --> Utf8 Class Initialized
DEBUG - 2011-04-06 11:54:31 --> UTF-8 Support Enabled
DEBUG - 2011-04-06 11:54:31 --> URI Class Initialized
DEBUG - 2011-04-06 11:54:31 --> Router Class Initialized
DEBUG - 2011-04-06 11:54:31 --> No URI present. Default controller set.
DEBUG - 2011-04-06 11:54:31 --> Output Class Initialized
DEBUG - 2011-04-06 11:54:31 --> Input Class Initialized
DEBUG - 2011-04-06 11:54:31 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-06 11:54:31 --> Language Class Initialized
DEBUG - 2011-04-06 11:54:31 --> Loader Class Initialized
DEBUG - 2011-04-06 11:54:31 --> Controller Class Initialized
DEBUG - 2011-04-06 11:54:31 --> File loaded: application/views/splash/main.php
DEBUG - 2011-04-06 11:54:31 --> Helper loaded: url_helper
DEBUG - 2011-04-06 11:54:31 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-06 11:54:31 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-06 11:54:31 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-06 11:54:31 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-06 11:54:31 --> Final output sent to browser
DEBUG - 2011-04-06 11:54:31 --> Total execution time: 0.0126
DEBUG - 2011-04-06 11:54:33 --> Config Class Initialized
DEBUG - 2011-04-06 11:54:33 --> Hooks Class Initialized
DEBUG - 2011-04-06 11:54:33 --> Utf8 Class Initialized
DEBUG - 2011-04-06 11:54:33 --> UTF-8 Support Enabled
DEBUG - 2011-04-06 11:54:33 --> URI Class Initialized
DEBUG - 2011-04-06 11:54:33 --> Router Class Initialized
DEBUG - 2011-04-06 11:54:33 --> Output Class Initialized
DEBUG - 2011-04-06 11:54:33 --> Input Class Initialized
DEBUG - 2011-04-06 11:54:33 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-06 11:54:33 --> Language Class Initialized
DEBUG - 2011-04-06 11:54:33 --> Loader Class Initialized
DEBUG - 2011-04-06 11:54:33 --> Controller Class Initialized
DEBUG - 2011-04-06 11:54:33 --> Model Class Initialized
DEBUG - 2011-04-06 11:54:33 --> Model Class Initialized
DEBUG - 2011-04-06 11:54:33 --> Model Class Initialized
DEBUG - 2011-04-06 11:54:33 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-06 11:54:33 --> Database Driver Class Initialized
DEBUG - 2011-04-06 11:54:33 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-06 11:54:33 --> Helper loaded: url_helper
DEBUG - 2011-04-06 11:54:33 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-06 11:54:33 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-06 11:54:33 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-06 11:54:33 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-06 11:54:33 --> Final output sent to browser
DEBUG - 2011-04-06 11:54:33 --> Total execution time: 0.5366
DEBUG - 2011-04-06 11:54:35 --> Config Class Initialized
DEBUG - 2011-04-06 11:54:35 --> Hooks Class Initialized
DEBUG - 2011-04-06 11:54:35 --> Utf8 Class Initialized
DEBUG - 2011-04-06 11:54:35 --> UTF-8 Support Enabled
DEBUG - 2011-04-06 11:54:35 --> URI Class Initialized
DEBUG - 2011-04-06 11:54:35 --> Router Class Initialized
DEBUG - 2011-04-06 11:54:35 --> Config Class Initialized
DEBUG - 2011-04-06 11:54:35 --> Hooks Class Initialized
DEBUG - 2011-04-06 11:54:35 --> Utf8 Class Initialized
DEBUG - 2011-04-06 11:54:35 --> UTF-8 Support Enabled
DEBUG - 2011-04-06 11:54:35 --> Output Class Initialized
DEBUG - 2011-04-06 11:54:35 --> URI Class Initialized
DEBUG - 2011-04-06 11:54:35 --> Router Class Initialized
DEBUG - 2011-04-06 11:54:35 --> Input Class Initialized
DEBUG - 2011-04-06 11:54:35 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-06 11:54:35 --> Language Class Initialized
DEBUG - 2011-04-06 11:54:35 --> Output Class Initialized
DEBUG - 2011-04-06 11:54:35 --> Input Class Initialized
DEBUG - 2011-04-06 11:54:35 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-06 11:54:35 --> Language Class Initialized
DEBUG - 2011-04-06 11:54:35 --> Loader Class Initialized
DEBUG - 2011-04-06 11:54:35 --> Controller Class Initialized
DEBUG - 2011-04-06 11:54:35 --> Model Class Initialized
DEBUG - 2011-04-06 11:54:35 --> Loader Class Initialized
DEBUG - 2011-04-06 11:54:35 --> Controller Class Initialized
DEBUG - 2011-04-06 11:54:35 --> Model Class Initialized
DEBUG - 2011-04-06 11:54:35 --> Model Class Initialized
DEBUG - 2011-04-06 11:54:35 --> Model Class Initialized
DEBUG - 2011-04-06 11:54:35 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-06 11:54:35 --> Model Class Initialized
DEBUG - 2011-04-06 11:54:35 --> Model Class Initialized
DEBUG - 2011-04-06 11:54:35 --> Database Driver Class Initialized
DEBUG - 2011-04-06 11:54:35 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-06 11:54:35 --> Database Driver Class Initialized
DEBUG - 2011-04-06 11:54:35 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-06 11:54:35 --> Helper loaded: url_helper
DEBUG - 2011-04-06 11:54:35 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-06 11:54:35 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-06 11:54:35 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-06 11:54:35 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-06 11:54:35 --> Final output sent to browser
DEBUG - 2011-04-06 11:54:35 --> Total execution time: 0.0621
DEBUG - 2011-04-06 11:54:35 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-06 11:54:35 --> Helper loaded: url_helper
DEBUG - 2011-04-06 11:54:35 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-06 11:54:35 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-06 11:54:35 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-06 11:54:35 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-06 11:54:35 --> Final output sent to browser
DEBUG - 2011-04-06 11:54:35 --> Total execution time: 0.0801
DEBUG - 2011-04-06 11:54:35 --> Config Class Initialized
DEBUG - 2011-04-06 11:54:35 --> Hooks Class Initialized
DEBUG - 2011-04-06 11:54:35 --> Utf8 Class Initialized
DEBUG - 2011-04-06 11:54:35 --> UTF-8 Support Enabled
DEBUG - 2011-04-06 11:54:35 --> URI Class Initialized
DEBUG - 2011-04-06 11:54:35 --> Router Class Initialized
DEBUG - 2011-04-06 11:54:35 --> Output Class Initialized
DEBUG - 2011-04-06 11:54:35 --> Input Class Initialized
DEBUG - 2011-04-06 11:54:35 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-06 11:54:35 --> Language Class Initialized
DEBUG - 2011-04-06 11:54:35 --> Loader Class Initialized
DEBUG - 2011-04-06 11:54:35 --> Controller Class Initialized
DEBUG - 2011-04-06 11:54:35 --> Model Class Initialized
DEBUG - 2011-04-06 11:54:35 --> Model Class Initialized
DEBUG - 2011-04-06 11:54:35 --> Model Class Initialized
DEBUG - 2011-04-06 11:54:35 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-06 11:54:35 --> Database Driver Class Initialized
DEBUG - 2011-04-06 11:54:35 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-06 11:54:35 --> Helper loaded: url_helper
DEBUG - 2011-04-06 11:54:35 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-06 11:54:35 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-06 11:54:35 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-06 11:54:35 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-06 11:54:35 --> Final output sent to browser
DEBUG - 2011-04-06 11:54:35 --> Total execution time: 0.0437
DEBUG - 2011-04-06 11:54:44 --> Config Class Initialized
DEBUG - 2011-04-06 11:54:44 --> Hooks Class Initialized
DEBUG - 2011-04-06 11:54:44 --> Utf8 Class Initialized
DEBUG - 2011-04-06 11:54:44 --> UTF-8 Support Enabled
DEBUG - 2011-04-06 11:54:44 --> URI Class Initialized
DEBUG - 2011-04-06 11:54:44 --> Router Class Initialized
DEBUG - 2011-04-06 11:54:44 --> Output Class Initialized
DEBUG - 2011-04-06 11:54:44 --> Input Class Initialized
DEBUG - 2011-04-06 11:54:44 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-06 11:54:44 --> Language Class Initialized
DEBUG - 2011-04-06 11:54:44 --> Loader Class Initialized
DEBUG - 2011-04-06 11:54:44 --> Controller Class Initialized
DEBUG - 2011-04-06 11:54:44 --> Model Class Initialized
DEBUG - 2011-04-06 11:54:44 --> Model Class Initialized
DEBUG - 2011-04-06 11:54:44 --> Model Class Initialized
DEBUG - 2011-04-06 11:54:44 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-06 11:54:44 --> Database Driver Class Initialized
DEBUG - 2011-04-06 11:54:44 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-06 11:54:44 --> Helper loaded: url_helper
DEBUG - 2011-04-06 11:54:44 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-06 11:54:44 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-06 11:54:44 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-06 11:54:44 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-06 11:54:44 --> Final output sent to browser
DEBUG - 2011-04-06 11:54:44 --> Total execution time: 0.2940
DEBUG - 2011-04-06 11:54:45 --> Config Class Initialized
DEBUG - 2011-04-06 11:54:45 --> Hooks Class Initialized
DEBUG - 2011-04-06 11:54:45 --> Utf8 Class Initialized
DEBUG - 2011-04-06 11:54:45 --> UTF-8 Support Enabled
DEBUG - 2011-04-06 11:54:45 --> URI Class Initialized
DEBUG - 2011-04-06 11:54:45 --> Router Class Initialized
DEBUG - 2011-04-06 11:54:45 --> Output Class Initialized
DEBUG - 2011-04-06 11:54:45 --> Input Class Initialized
DEBUG - 2011-04-06 11:54:45 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-06 11:54:45 --> Language Class Initialized
DEBUG - 2011-04-06 11:54:45 --> Loader Class Initialized
DEBUG - 2011-04-06 11:54:45 --> Controller Class Initialized
DEBUG - 2011-04-06 11:54:45 --> Model Class Initialized
DEBUG - 2011-04-06 11:54:45 --> Model Class Initialized
DEBUG - 2011-04-06 11:54:45 --> Model Class Initialized
DEBUG - 2011-04-06 11:54:45 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-06 11:54:45 --> Database Driver Class Initialized
DEBUG - 2011-04-06 11:54:45 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-06 11:54:45 --> Helper loaded: url_helper
DEBUG - 2011-04-06 11:54:45 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-06 11:54:45 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-06 11:54:45 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-06 11:54:45 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-06 11:54:45 --> Final output sent to browser
DEBUG - 2011-04-06 11:54:45 --> Total execution time: 0.0740
DEBUG - 2011-04-06 11:54:46 --> Config Class Initialized
DEBUG - 2011-04-06 11:54:46 --> Hooks Class Initialized
DEBUG - 2011-04-06 11:54:46 --> Utf8 Class Initialized
DEBUG - 2011-04-06 11:54:46 --> UTF-8 Support Enabled
DEBUG - 2011-04-06 11:54:46 --> URI Class Initialized
DEBUG - 2011-04-06 11:54:46 --> Router Class Initialized
DEBUG - 2011-04-06 11:54:46 --> Output Class Initialized
DEBUG - 2011-04-06 11:54:46 --> Input Class Initialized
DEBUG - 2011-04-06 11:54:46 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-06 11:54:46 --> Language Class Initialized
DEBUG - 2011-04-06 11:54:46 --> Loader Class Initialized
DEBUG - 2011-04-06 11:54:46 --> Controller Class Initialized
DEBUG - 2011-04-06 11:54:46 --> Model Class Initialized
DEBUG - 2011-04-06 11:54:46 --> Model Class Initialized
DEBUG - 2011-04-06 11:54:46 --> Model Class Initialized
DEBUG - 2011-04-06 11:54:46 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-06 11:54:46 --> Database Driver Class Initialized
DEBUG - 2011-04-06 11:54:46 --> Config Class Initialized
DEBUG - 2011-04-06 11:54:46 --> Hooks Class Initialized
DEBUG - 2011-04-06 11:54:46 --> Utf8 Class Initialized
DEBUG - 2011-04-06 11:54:46 --> UTF-8 Support Enabled
DEBUG - 2011-04-06 11:54:46 --> URI Class Initialized
DEBUG - 2011-04-06 11:54:46 --> Router Class Initialized
DEBUG - 2011-04-06 11:54:46 --> Output Class Initialized
DEBUG - 2011-04-06 11:54:46 --> Input Class Initialized
DEBUG - 2011-04-06 11:54:46 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-06 11:54:46 --> Language Class Initialized
DEBUG - 2011-04-06 11:54:46 --> Loader Class Initialized
DEBUG - 2011-04-06 11:54:46 --> Controller Class Initialized
DEBUG - 2011-04-06 11:54:46 --> Model Class Initialized
DEBUG - 2011-04-06 11:54:46 --> Model Class Initialized
DEBUG - 2011-04-06 11:54:46 --> Model Class Initialized
DEBUG - 2011-04-06 11:54:46 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-06 11:54:46 --> Database Driver Class Initialized
DEBUG - 2011-04-06 11:54:46 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-06 11:54:46 --> Helper loaded: url_helper
DEBUG - 2011-04-06 11:54:46 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-06 11:54:46 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-06 11:54:46 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-06 11:54:46 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-06 11:54:46 --> Final output sent to browser
DEBUG - 2011-04-06 11:54:46 --> Total execution time: 0.0813
DEBUG - 2011-04-06 11:54:46 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-06 11:54:46 --> Helper loaded: url_helper
DEBUG - 2011-04-06 11:54:46 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-06 11:54:46 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-06 11:54:46 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-06 11:54:46 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-06 11:54:46 --> Final output sent to browser
DEBUG - 2011-04-06 11:54:46 --> Total execution time: 0.0867
DEBUG - 2011-04-06 11:54:47 --> Config Class Initialized
DEBUG - 2011-04-06 11:54:47 --> Hooks Class Initialized
DEBUG - 2011-04-06 11:54:47 --> Utf8 Class Initialized
DEBUG - 2011-04-06 11:54:47 --> UTF-8 Support Enabled
DEBUG - 2011-04-06 11:54:47 --> URI Class Initialized
DEBUG - 2011-04-06 11:54:47 --> Router Class Initialized
DEBUG - 2011-04-06 11:54:47 --> Output Class Initialized
DEBUG - 2011-04-06 11:54:47 --> Input Class Initialized
DEBUG - 2011-04-06 11:54:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-06 11:54:47 --> Language Class Initialized
DEBUG - 2011-04-06 11:54:47 --> Loader Class Initialized
DEBUG - 2011-04-06 11:54:47 --> Controller Class Initialized
DEBUG - 2011-04-06 11:54:47 --> Model Class Initialized
DEBUG - 2011-04-06 11:54:47 --> Model Class Initialized
DEBUG - 2011-04-06 11:54:47 --> Model Class Initialized
DEBUG - 2011-04-06 11:54:47 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-06 11:54:47 --> Database Driver Class Initialized
DEBUG - 2011-04-06 11:54:47 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-06 11:54:47 --> Helper loaded: url_helper
DEBUG - 2011-04-06 11:54:47 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-06 11:54:47 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-06 11:54:47 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-06 11:54:47 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-06 11:54:47 --> Final output sent to browser
DEBUG - 2011-04-06 11:54:47 --> Total execution time: 0.0865
DEBUG - 2011-04-06 11:55:21 --> Config Class Initialized
DEBUG - 2011-04-06 11:55:21 --> Hooks Class Initialized
DEBUG - 2011-04-06 11:55:21 --> Utf8 Class Initialized
DEBUG - 2011-04-06 11:55:21 --> UTF-8 Support Enabled
DEBUG - 2011-04-06 11:55:21 --> URI Class Initialized
DEBUG - 2011-04-06 11:55:21 --> Router Class Initialized
DEBUG - 2011-04-06 11:55:21 --> Output Class Initialized
DEBUG - 2011-04-06 11:55:21 --> Input Class Initialized
DEBUG - 2011-04-06 11:55:21 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-06 11:55:21 --> Language Class Initialized
DEBUG - 2011-04-06 11:55:21 --> Loader Class Initialized
DEBUG - 2011-04-06 11:55:21 --> Controller Class Initialized
DEBUG - 2011-04-06 11:55:21 --> Model Class Initialized
DEBUG - 2011-04-06 11:55:21 --> Model Class Initialized
DEBUG - 2011-04-06 11:55:21 --> Model Class Initialized
DEBUG - 2011-04-06 11:55:21 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-06 11:55:21 --> Database Driver Class Initialized
DEBUG - 2011-04-06 11:55:22 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-06 11:55:22 --> Helper loaded: url_helper
DEBUG - 2011-04-06 11:55:22 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-06 11:55:22 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-06 11:55:22 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-06 11:55:22 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-06 11:55:22 --> Final output sent to browser
DEBUG - 2011-04-06 11:55:22 --> Total execution time: 0.5459
DEBUG - 2011-04-06 11:55:24 --> Config Class Initialized
DEBUG - 2011-04-06 11:55:24 --> Hooks Class Initialized
DEBUG - 2011-04-06 11:55:24 --> Utf8 Class Initialized
DEBUG - 2011-04-06 11:55:24 --> UTF-8 Support Enabled
DEBUG - 2011-04-06 11:55:24 --> URI Class Initialized
DEBUG - 2011-04-06 11:55:24 --> Router Class Initialized
DEBUG - 2011-04-06 11:55:24 --> Output Class Initialized
DEBUG - 2011-04-06 11:55:24 --> Input Class Initialized
DEBUG - 2011-04-06 11:55:24 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-06 11:55:24 --> Language Class Initialized
DEBUG - 2011-04-06 11:55:24 --> Loader Class Initialized
DEBUG - 2011-04-06 11:55:24 --> Controller Class Initialized
DEBUG - 2011-04-06 11:55:24 --> Model Class Initialized
DEBUG - 2011-04-06 11:55:24 --> Model Class Initialized
DEBUG - 2011-04-06 11:55:24 --> Model Class Initialized
DEBUG - 2011-04-06 11:55:24 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-06 11:55:24 --> Database Driver Class Initialized
DEBUG - 2011-04-06 11:55:24 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-06 11:55:24 --> Helper loaded: url_helper
DEBUG - 2011-04-06 11:55:24 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-06 11:55:24 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-06 11:55:24 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-06 11:55:24 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-06 11:55:24 --> Final output sent to browser
DEBUG - 2011-04-06 11:55:24 --> Total execution time: 0.1172
DEBUG - 2011-04-06 11:55:24 --> Config Class Initialized
DEBUG - 2011-04-06 11:55:24 --> Hooks Class Initialized
DEBUG - 2011-04-06 11:55:24 --> Utf8 Class Initialized
DEBUG - 2011-04-06 11:55:24 --> UTF-8 Support Enabled
DEBUG - 2011-04-06 11:55:24 --> URI Class Initialized
DEBUG - 2011-04-06 11:55:24 --> Router Class Initialized
DEBUG - 2011-04-06 11:55:24 --> Output Class Initialized
DEBUG - 2011-04-06 11:55:24 --> Input Class Initialized
DEBUG - 2011-04-06 11:55:24 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-06 11:55:24 --> Language Class Initialized
DEBUG - 2011-04-06 11:55:24 --> Loader Class Initialized
DEBUG - 2011-04-06 11:55:24 --> Controller Class Initialized
DEBUG - 2011-04-06 11:55:24 --> Model Class Initialized
DEBUG - 2011-04-06 11:55:24 --> Model Class Initialized
DEBUG - 2011-04-06 11:55:24 --> Model Class Initialized
DEBUG - 2011-04-06 11:55:24 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-06 11:55:24 --> Database Driver Class Initialized
DEBUG - 2011-04-06 11:55:24 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-06 11:55:24 --> Config Class Initialized
DEBUG - 2011-04-06 11:55:24 --> Hooks Class Initialized
DEBUG - 2011-04-06 11:55:24 --> Utf8 Class Initialized
DEBUG - 2011-04-06 11:55:24 --> UTF-8 Support Enabled
DEBUG - 2011-04-06 11:55:24 --> URI Class Initialized
DEBUG - 2011-04-06 11:55:24 --> Helper loaded: url_helper
DEBUG - 2011-04-06 11:55:24 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-06 11:55:24 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-06 11:55:24 --> Router Class Initialized
DEBUG - 2011-04-06 11:55:24 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-06 11:55:24 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-06 11:55:24 --> Final output sent to browser
DEBUG - 2011-04-06 11:55:24 --> Total execution time: 0.0967
DEBUG - 2011-04-06 11:55:24 --> Output Class Initialized
DEBUG - 2011-04-06 11:55:24 --> Input Class Initialized
DEBUG - 2011-04-06 11:55:24 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-06 11:55:24 --> Language Class Initialized
DEBUG - 2011-04-06 11:55:24 --> Loader Class Initialized
DEBUG - 2011-04-06 11:55:24 --> Controller Class Initialized
DEBUG - 2011-04-06 11:55:24 --> Model Class Initialized
DEBUG - 2011-04-06 11:55:24 --> Model Class Initialized
DEBUG - 2011-04-06 11:55:24 --> Model Class Initialized
DEBUG - 2011-04-06 11:55:24 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-06 11:55:24 --> Database Driver Class Initialized
DEBUG - 2011-04-06 11:55:24 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-06 11:55:24 --> Helper loaded: url_helper
DEBUG - 2011-04-06 11:55:24 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-06 11:55:24 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-06 11:55:24 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-06 11:55:24 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-06 11:55:24 --> Final output sent to browser
DEBUG - 2011-04-06 11:55:24 --> Total execution time: 0.1015
DEBUG - 2011-04-06 11:55:41 --> Config Class Initialized
DEBUG - 2011-04-06 11:55:41 --> Hooks Class Initialized
DEBUG - 2011-04-06 11:55:41 --> Utf8 Class Initialized
DEBUG - 2011-04-06 11:55:41 --> UTF-8 Support Enabled
DEBUG - 2011-04-06 11:55:41 --> URI Class Initialized
DEBUG - 2011-04-06 11:55:41 --> Router Class Initialized
DEBUG - 2011-04-06 11:55:41 --> Output Class Initialized
DEBUG - 2011-04-06 11:55:41 --> Input Class Initialized
DEBUG - 2011-04-06 11:55:41 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-06 11:55:41 --> Language Class Initialized
DEBUG - 2011-04-06 11:55:41 --> Loader Class Initialized
DEBUG - 2011-04-06 11:55:41 --> Controller Class Initialized
DEBUG - 2011-04-06 11:55:41 --> Model Class Initialized
DEBUG - 2011-04-06 11:55:41 --> Model Class Initialized
DEBUG - 2011-04-06 11:55:41 --> Model Class Initialized
DEBUG - 2011-04-06 11:55:41 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-06 11:55:41 --> Database Driver Class Initialized
DEBUG - 2011-04-06 11:55:41 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-06 11:55:41 --> Helper loaded: url_helper
DEBUG - 2011-04-06 11:55:41 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-06 11:55:41 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-06 11:55:41 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-06 11:55:41 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-06 11:55:41 --> Final output sent to browser
DEBUG - 2011-04-06 11:55:41 --> Total execution time: 0.1365
DEBUG - 2011-04-06 11:55:42 --> Config Class Initialized
DEBUG - 2011-04-06 11:55:42 --> Hooks Class Initialized
DEBUG - 2011-04-06 11:55:42 --> Utf8 Class Initialized
DEBUG - 2011-04-06 11:55:42 --> UTF-8 Support Enabled
DEBUG - 2011-04-06 11:55:42 --> URI Class Initialized
DEBUG - 2011-04-06 11:55:42 --> Router Class Initialized
DEBUG - 2011-04-06 11:55:42 --> Output Class Initialized
DEBUG - 2011-04-06 11:55:42 --> Config Class Initialized
DEBUG - 2011-04-06 11:55:42 --> Hooks Class Initialized
DEBUG - 2011-04-06 11:55:42 --> Utf8 Class Initialized
DEBUG - 2011-04-06 11:55:42 --> UTF-8 Support Enabled
DEBUG - 2011-04-06 11:55:42 --> Input Class Initialized
DEBUG - 2011-04-06 11:55:42 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-06 11:55:42 --> Language Class Initialized
DEBUG - 2011-04-06 11:55:42 --> URI Class Initialized
DEBUG - 2011-04-06 11:55:42 --> Router Class Initialized
DEBUG - 2011-04-06 11:55:42 --> Loader Class Initialized
DEBUG - 2011-04-06 11:55:42 --> Output Class Initialized
DEBUG - 2011-04-06 11:55:42 --> Controller Class Initialized
DEBUG - 2011-04-06 11:55:42 --> Model Class Initialized
DEBUG - 2011-04-06 11:55:42 --> Model Class Initialized
DEBUG - 2011-04-06 11:55:42 --> Input Class Initialized
DEBUG - 2011-04-06 11:55:42 --> Model Class Initialized
DEBUG - 2011-04-06 11:55:42 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-06 11:55:42 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-06 11:55:42 --> Language Class Initialized
DEBUG - 2011-04-06 11:55:42 --> Loader Class Initialized
DEBUG - 2011-04-06 11:55:42 --> Controller Class Initialized
DEBUG - 2011-04-06 11:55:42 --> Model Class Initialized
DEBUG - 2011-04-06 11:55:42 --> Model Class Initialized
DEBUG - 2011-04-06 11:55:42 --> Model Class Initialized
DEBUG - 2011-04-06 11:55:42 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-06 11:55:42 --> Database Driver Class Initialized
DEBUG - 2011-04-06 11:55:42 --> Database Driver Class Initialized
DEBUG - 2011-04-06 11:55:42 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-06 11:55:42 --> Helper loaded: url_helper
DEBUG - 2011-04-06 11:55:42 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-06 11:55:42 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-06 11:55:42 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-06 11:55:42 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-06 11:55:42 --> Final output sent to browser
DEBUG - 2011-04-06 11:55:42 --> Total execution time: 0.0729
DEBUG - 2011-04-06 11:55:42 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-06 11:55:42 --> Helper loaded: url_helper
DEBUG - 2011-04-06 11:55:42 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-06 11:55:42 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-06 11:55:42 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-06 11:55:42 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-06 11:55:42 --> Final output sent to browser
DEBUG - 2011-04-06 11:55:42 --> Total execution time: 0.0763
DEBUG - 2011-04-06 11:55:50 --> Config Class Initialized
DEBUG - 2011-04-06 11:55:50 --> Hooks Class Initialized
DEBUG - 2011-04-06 11:55:50 --> Utf8 Class Initialized
DEBUG - 2011-04-06 11:55:50 --> UTF-8 Support Enabled
DEBUG - 2011-04-06 11:55:50 --> URI Class Initialized
DEBUG - 2011-04-06 11:55:50 --> Router Class Initialized
DEBUG - 2011-04-06 11:55:50 --> Output Class Initialized
DEBUG - 2011-04-06 11:55:50 --> Input Class Initialized
DEBUG - 2011-04-06 11:55:50 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-06 11:55:50 --> Language Class Initialized
DEBUG - 2011-04-06 11:55:50 --> Loader Class Initialized
DEBUG - 2011-04-06 11:55:50 --> Controller Class Initialized
DEBUG - 2011-04-06 11:55:50 --> Model Class Initialized
DEBUG - 2011-04-06 11:55:50 --> Model Class Initialized
DEBUG - 2011-04-06 11:55:50 --> Model Class Initialized
DEBUG - 2011-04-06 11:55:50 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-06 11:55:50 --> Database Driver Class Initialized
DEBUG - 2011-04-06 11:55:50 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-06 11:55:50 --> Helper loaded: url_helper
DEBUG - 2011-04-06 11:55:50 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-06 11:55:50 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-06 11:55:50 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-06 11:55:50 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-06 11:55:50 --> Final output sent to browser
DEBUG - 2011-04-06 11:55:50 --> Total execution time: 0.3463
DEBUG - 2011-04-06 11:55:51 --> Config Class Initialized
DEBUG - 2011-04-06 11:55:51 --> Hooks Class Initialized
DEBUG - 2011-04-06 11:55:51 --> Utf8 Class Initialized
DEBUG - 2011-04-06 11:55:51 --> UTF-8 Support Enabled
DEBUG - 2011-04-06 11:55:51 --> URI Class Initialized
DEBUG - 2011-04-06 11:55:51 --> Router Class Initialized
DEBUG - 2011-04-06 11:55:51 --> Output Class Initialized
DEBUG - 2011-04-06 11:55:52 --> Input Class Initialized
DEBUG - 2011-04-06 11:55:52 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-06 11:55:52 --> Language Class Initialized
DEBUG - 2011-04-06 11:55:52 --> Loader Class Initialized
DEBUG - 2011-04-06 11:55:52 --> Controller Class Initialized
DEBUG - 2011-04-06 11:55:52 --> Model Class Initialized
DEBUG - 2011-04-06 11:55:52 --> Model Class Initialized
DEBUG - 2011-04-06 11:55:52 --> Model Class Initialized
DEBUG - 2011-04-06 11:55:52 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-06 11:55:52 --> Database Driver Class Initialized
DEBUG - 2011-04-06 11:55:52 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-06 11:55:52 --> Helper loaded: url_helper
DEBUG - 2011-04-06 11:55:52 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-06 11:55:52 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-06 11:55:52 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-06 11:55:52 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-06 11:55:52 --> Final output sent to browser
DEBUG - 2011-04-06 11:55:52 --> Total execution time: 0.1037
DEBUG - 2011-04-06 11:55:52 --> Config Class Initialized
DEBUG - 2011-04-06 11:55:52 --> Hooks Class Initialized
DEBUG - 2011-04-06 11:55:52 --> Utf8 Class Initialized
DEBUG - 2011-04-06 11:55:52 --> UTF-8 Support Enabled
DEBUG - 2011-04-06 11:55:52 --> URI Class Initialized
DEBUG - 2011-04-06 11:55:52 --> Router Class Initialized
DEBUG - 2011-04-06 11:55:52 --> Output Class Initialized
DEBUG - 2011-04-06 11:55:52 --> Input Class Initialized
DEBUG - 2011-04-06 11:55:52 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-06 11:55:52 --> Language Class Initialized
DEBUG - 2011-04-06 11:55:52 --> Loader Class Initialized
DEBUG - 2011-04-06 11:55:52 --> Controller Class Initialized
DEBUG - 2011-04-06 11:55:52 --> Model Class Initialized
DEBUG - 2011-04-06 11:55:52 --> Model Class Initialized
DEBUG - 2011-04-06 11:55:52 --> Model Class Initialized
DEBUG - 2011-04-06 11:55:52 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-06 11:55:52 --> Database Driver Class Initialized
DEBUG - 2011-04-06 11:55:52 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-06 11:55:52 --> Helper loaded: url_helper
DEBUG - 2011-04-06 11:55:52 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-06 11:55:52 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-06 11:55:52 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-06 11:55:52 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-06 11:55:52 --> Final output sent to browser
DEBUG - 2011-04-06 11:55:52 --> Total execution time: 0.0887
DEBUG - 2011-04-06 11:55:52 --> Config Class Initialized
DEBUG - 2011-04-06 11:55:52 --> Hooks Class Initialized
DEBUG - 2011-04-06 11:55:52 --> Utf8 Class Initialized
DEBUG - 2011-04-06 11:55:52 --> UTF-8 Support Enabled
DEBUG - 2011-04-06 11:55:52 --> URI Class Initialized
DEBUG - 2011-04-06 11:55:52 --> Router Class Initialized
DEBUG - 2011-04-06 11:55:52 --> Output Class Initialized
DEBUG - 2011-04-06 11:55:52 --> Input Class Initialized
DEBUG - 2011-04-06 11:55:52 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-06 11:55:52 --> Language Class Initialized
DEBUG - 2011-04-06 11:55:52 --> Loader Class Initialized
DEBUG - 2011-04-06 11:55:52 --> Controller Class Initialized
DEBUG - 2011-04-06 11:55:52 --> Model Class Initialized
DEBUG - 2011-04-06 11:55:52 --> Model Class Initialized
DEBUG - 2011-04-06 11:55:52 --> Model Class Initialized
DEBUG - 2011-04-06 11:55:52 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-06 11:55:52 --> Database Driver Class Initialized
DEBUG - 2011-04-06 11:55:52 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-06 11:55:52 --> Helper loaded: url_helper
DEBUG - 2011-04-06 11:55:52 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-06 11:55:52 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-06 11:55:52 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-06 11:55:52 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-06 11:55:52 --> Final output sent to browser
DEBUG - 2011-04-06 11:55:52 --> Total execution time: 0.1670
DEBUG - 2011-04-06 11:56:14 --> Config Class Initialized
DEBUG - 2011-04-06 11:56:14 --> Hooks Class Initialized
DEBUG - 2011-04-06 11:56:14 --> Utf8 Class Initialized
DEBUG - 2011-04-06 11:56:14 --> UTF-8 Support Enabled
DEBUG - 2011-04-06 11:56:14 --> URI Class Initialized
DEBUG - 2011-04-06 11:56:14 --> Router Class Initialized
DEBUG - 2011-04-06 11:56:14 --> Output Class Initialized
DEBUG - 2011-04-06 11:56:14 --> Input Class Initialized
DEBUG - 2011-04-06 11:56:14 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-06 11:56:14 --> Language Class Initialized
DEBUG - 2011-04-06 11:56:14 --> Loader Class Initialized
DEBUG - 2011-04-06 11:56:14 --> Controller Class Initialized
DEBUG - 2011-04-06 11:56:14 --> Model Class Initialized
DEBUG - 2011-04-06 11:56:14 --> Model Class Initialized
DEBUG - 2011-04-06 11:56:14 --> Model Class Initialized
DEBUG - 2011-04-06 11:56:14 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-06 11:56:14 --> Database Driver Class Initialized
DEBUG - 2011-04-06 11:56:15 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-06 11:56:15 --> Helper loaded: url_helper
DEBUG - 2011-04-06 11:56:15 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-06 11:56:15 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-06 11:56:15 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-06 11:56:15 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-06 11:56:15 --> Final output sent to browser
DEBUG - 2011-04-06 11:56:15 --> Total execution time: 0.7419
DEBUG - 2011-04-06 11:56:17 --> Config Class Initialized
DEBUG - 2011-04-06 11:56:17 --> Hooks Class Initialized
DEBUG - 2011-04-06 11:56:17 --> Utf8 Class Initialized
DEBUG - 2011-04-06 11:56:17 --> UTF-8 Support Enabled
DEBUG - 2011-04-06 11:56:17 --> URI Class Initialized
DEBUG - 2011-04-06 11:56:17 --> Router Class Initialized
DEBUG - 2011-04-06 11:56:17 --> Output Class Initialized
DEBUG - 2011-04-06 11:56:17 --> Input Class Initialized
DEBUG - 2011-04-06 11:56:17 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-06 11:56:17 --> Language Class Initialized
DEBUG - 2011-04-06 11:56:17 --> Loader Class Initialized
DEBUG - 2011-04-06 11:56:17 --> Controller Class Initialized
DEBUG - 2011-04-06 11:56:17 --> Model Class Initialized
DEBUG - 2011-04-06 11:56:17 --> Config Class Initialized
DEBUG - 2011-04-06 11:56:17 --> Hooks Class Initialized
DEBUG - 2011-04-06 11:56:17 --> Utf8 Class Initialized
DEBUG - 2011-04-06 11:56:17 --> UTF-8 Support Enabled
DEBUG - 2011-04-06 11:56:17 --> Model Class Initialized
DEBUG - 2011-04-06 11:56:17 --> Model Class Initialized
DEBUG - 2011-04-06 11:56:17 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-06 11:56:17 --> URI Class Initialized
DEBUG - 2011-04-06 11:56:17 --> Router Class Initialized
DEBUG - 2011-04-06 11:56:17 --> Output Class Initialized
DEBUG - 2011-04-06 11:56:17 --> Input Class Initialized
DEBUG - 2011-04-06 11:56:17 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-06 11:56:17 --> Language Class Initialized
DEBUG - 2011-04-06 11:56:17 --> Database Driver Class Initialized
DEBUG - 2011-04-06 11:56:17 --> Loader Class Initialized
DEBUG - 2011-04-06 11:56:17 --> Controller Class Initialized
DEBUG - 2011-04-06 11:56:17 --> Model Class Initialized
DEBUG - 2011-04-06 11:56:17 --> Model Class Initialized
DEBUG - 2011-04-06 11:56:17 --> Model Class Initialized
DEBUG - 2011-04-06 11:56:17 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-06 11:56:17 --> Database Driver Class Initialized
DEBUG - 2011-04-06 11:56:18 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-06 11:56:18 --> Helper loaded: url_helper
DEBUG - 2011-04-06 11:56:18 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-06 11:56:18 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-06 11:56:18 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-06 11:56:18 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-06 11:56:18 --> Helper loaded: url_helper
DEBUG - 2011-04-06 11:56:18 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-06 11:56:18 --> Final output sent to browser
DEBUG - 2011-04-06 11:56:18 --> Total execution time: 1.4848
DEBUG - 2011-04-06 11:56:18 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-06 11:56:18 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-06 11:56:18 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-06 11:56:18 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-06 11:56:18 --> Final output sent to browser
DEBUG - 2011-04-06 11:56:18 --> Total execution time: 1.4761
DEBUG - 2011-04-06 11:56:19 --> Config Class Initialized
DEBUG - 2011-04-06 11:56:19 --> Hooks Class Initialized
DEBUG - 2011-04-06 11:56:19 --> Utf8 Class Initialized
DEBUG - 2011-04-06 11:56:19 --> UTF-8 Support Enabled
DEBUG - 2011-04-06 11:56:19 --> URI Class Initialized
DEBUG - 2011-04-06 11:56:19 --> Router Class Initialized
DEBUG - 2011-04-06 11:56:19 --> Output Class Initialized
DEBUG - 2011-04-06 11:56:19 --> Input Class Initialized
DEBUG - 2011-04-06 11:56:19 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-06 11:56:19 --> Language Class Initialized
DEBUG - 2011-04-06 11:56:19 --> Loader Class Initialized
DEBUG - 2011-04-06 11:56:20 --> Controller Class Initialized
DEBUG - 2011-04-06 11:56:20 --> Model Class Initialized
DEBUG - 2011-04-06 11:56:20 --> Model Class Initialized
DEBUG - 2011-04-06 11:56:20 --> Model Class Initialized
DEBUG - 2011-04-06 11:56:20 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-06 11:56:20 --> Database Driver Class Initialized
DEBUG - 2011-04-06 11:56:20 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-06 11:56:20 --> Helper loaded: url_helper
DEBUG - 2011-04-06 11:56:20 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-06 11:56:20 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-06 11:56:20 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-06 11:56:20 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-06 11:56:20 --> Final output sent to browser
DEBUG - 2011-04-06 11:56:20 --> Total execution time: 0.2516
DEBUG - 2011-04-06 11:56:40 --> Config Class Initialized
DEBUG - 2011-04-06 11:56:40 --> Hooks Class Initialized
DEBUG - 2011-04-06 11:56:40 --> Utf8 Class Initialized
DEBUG - 2011-04-06 11:56:40 --> UTF-8 Support Enabled
DEBUG - 2011-04-06 11:56:40 --> URI Class Initialized
DEBUG - 2011-04-06 11:56:40 --> Router Class Initialized
DEBUG - 2011-04-06 11:56:40 --> Output Class Initialized
DEBUG - 2011-04-06 11:56:40 --> Input Class Initialized
DEBUG - 2011-04-06 11:56:40 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-06 11:56:40 --> Language Class Initialized
DEBUG - 2011-04-06 11:56:40 --> Loader Class Initialized
DEBUG - 2011-04-06 11:56:40 --> Controller Class Initialized
DEBUG - 2011-04-06 11:56:40 --> Model Class Initialized
DEBUG - 2011-04-06 11:56:40 --> Model Class Initialized
DEBUG - 2011-04-06 11:56:40 --> Model Class Initialized
DEBUG - 2011-04-06 11:56:40 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-06 11:56:40 --> Database Driver Class Initialized
DEBUG - 2011-04-06 11:56:40 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-06 11:56:40 --> Helper loaded: url_helper
DEBUG - 2011-04-06 11:56:40 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-06 11:56:40 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-06 11:56:40 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-06 11:56:40 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-06 11:56:40 --> Final output sent to browser
DEBUG - 2011-04-06 11:56:40 --> Total execution time: 0.0460
DEBUG - 2011-04-06 11:56:42 --> Config Class Initialized
DEBUG - 2011-04-06 11:56:42 --> Hooks Class Initialized
DEBUG - 2011-04-06 11:56:42 --> Utf8 Class Initialized
DEBUG - 2011-04-06 11:56:42 --> UTF-8 Support Enabled
DEBUG - 2011-04-06 11:56:42 --> Config Class Initialized
DEBUG - 2011-04-06 11:56:42 --> Hooks Class Initialized
DEBUG - 2011-04-06 11:56:42 --> Utf8 Class Initialized
DEBUG - 2011-04-06 11:56:42 --> UTF-8 Support Enabled
DEBUG - 2011-04-06 11:56:42 --> URI Class Initialized
DEBUG - 2011-04-06 11:56:42 --> Router Class Initialized
DEBUG - 2011-04-06 11:56:42 --> URI Class Initialized
DEBUG - 2011-04-06 11:56:42 --> Router Class Initialized
DEBUG - 2011-04-06 11:56:42 --> Output Class Initialized
DEBUG - 2011-04-06 11:56:42 --> Output Class Initialized
DEBUG - 2011-04-06 11:56:42 --> Input Class Initialized
DEBUG - 2011-04-06 11:56:42 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-06 11:56:42 --> Language Class Initialized
DEBUG - 2011-04-06 11:56:42 --> Loader Class Initialized
DEBUG - 2011-04-06 11:56:42 --> Controller Class Initialized
DEBUG - 2011-04-06 11:56:42 --> Model Class Initialized
DEBUG - 2011-04-06 11:56:42 --> Input Class Initialized
DEBUG - 2011-04-06 11:56:42 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-06 11:56:42 --> Language Class Initialized
DEBUG - 2011-04-06 11:56:42 --> Loader Class Initialized
DEBUG - 2011-04-06 11:56:42 --> Controller Class Initialized
DEBUG - 2011-04-06 11:56:42 --> Model Class Initialized
DEBUG - 2011-04-06 11:56:42 --> Model Class Initialized
DEBUG - 2011-04-06 11:56:42 --> Model Class Initialized
DEBUG - 2011-04-06 11:56:42 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-06 11:56:42 --> Model Class Initialized
DEBUG - 2011-04-06 11:56:42 --> Model Class Initialized
DEBUG - 2011-04-06 11:56:42 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-06 11:56:42 --> Database Driver Class Initialized
DEBUG - 2011-04-06 11:56:42 --> Database Driver Class Initialized
DEBUG - 2011-04-06 11:56:42 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-06 11:56:42 --> Helper loaded: url_helper
DEBUG - 2011-04-06 11:56:42 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-06 11:56:42 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-06 11:56:42 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-06 11:56:42 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-06 11:56:42 --> Final output sent to browser
DEBUG - 2011-04-06 11:56:42 --> Total execution time: 0.4260
DEBUG - 2011-04-06 11:56:42 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-06 11:56:42 --> Helper loaded: url_helper
DEBUG - 2011-04-06 11:56:42 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-06 11:56:42 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-06 11:56:42 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-06 11:56:42 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-06 11:56:42 --> Final output sent to browser
DEBUG - 2011-04-06 11:56:42 --> Total execution time: 0.4821
DEBUG - 2011-04-06 11:56:42 --> Config Class Initialized
DEBUG - 2011-04-06 11:56:42 --> Hooks Class Initialized
DEBUG - 2011-04-06 11:56:42 --> Utf8 Class Initialized
DEBUG - 2011-04-06 11:56:42 --> UTF-8 Support Enabled
DEBUG - 2011-04-06 11:56:42 --> URI Class Initialized
DEBUG - 2011-04-06 11:56:42 --> Router Class Initialized
DEBUG - 2011-04-06 11:56:42 --> Output Class Initialized
DEBUG - 2011-04-06 11:56:42 --> Input Class Initialized
DEBUG - 2011-04-06 11:56:42 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-06 11:56:42 --> Language Class Initialized
DEBUG - 2011-04-06 11:56:43 --> Loader Class Initialized
DEBUG - 2011-04-06 11:56:43 --> Controller Class Initialized
DEBUG - 2011-04-06 11:56:43 --> Model Class Initialized
DEBUG - 2011-04-06 11:56:43 --> Model Class Initialized
DEBUG - 2011-04-06 11:56:43 --> Model Class Initialized
DEBUG - 2011-04-06 11:56:43 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-06 11:56:43 --> Database Driver Class Initialized
DEBUG - 2011-04-06 11:56:43 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-06 11:56:43 --> Helper loaded: url_helper
DEBUG - 2011-04-06 11:56:43 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-06 11:56:43 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-06 11:56:43 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-06 11:56:43 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-06 11:56:43 --> Final output sent to browser
DEBUG - 2011-04-06 11:56:43 --> Total execution time: 0.7886
DEBUG - 2011-04-06 11:56:44 --> Config Class Initialized
DEBUG - 2011-04-06 11:56:44 --> Hooks Class Initialized
DEBUG - 2011-04-06 11:56:44 --> Utf8 Class Initialized
DEBUG - 2011-04-06 11:56:44 --> UTF-8 Support Enabled
DEBUG - 2011-04-06 11:56:44 --> URI Class Initialized
DEBUG - 2011-04-06 11:56:44 --> Router Class Initialized
DEBUG - 2011-04-06 11:56:44 --> Output Class Initialized
DEBUG - 2011-04-06 11:56:44 --> Input Class Initialized
DEBUG - 2011-04-06 11:56:44 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-06 11:56:44 --> Language Class Initialized
DEBUG - 2011-04-06 11:56:44 --> Loader Class Initialized
DEBUG - 2011-04-06 11:56:44 --> Controller Class Initialized
DEBUG - 2011-04-06 11:56:44 --> Model Class Initialized
DEBUG - 2011-04-06 11:56:44 --> Model Class Initialized
DEBUG - 2011-04-06 11:56:44 --> Model Class Initialized
DEBUG - 2011-04-06 11:56:44 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-06 11:56:44 --> Database Driver Class Initialized
DEBUG - 2011-04-06 11:56:45 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-06 11:56:45 --> Helper loaded: url_helper
DEBUG - 2011-04-06 11:56:45 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-06 11:56:45 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-06 11:56:45 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-06 11:56:45 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-06 11:56:45 --> Final output sent to browser
DEBUG - 2011-04-06 11:56:45 --> Total execution time: 0.5368
DEBUG - 2011-04-06 11:56:46 --> Config Class Initialized
DEBUG - 2011-04-06 11:56:46 --> Hooks Class Initialized
DEBUG - 2011-04-06 11:56:46 --> Utf8 Class Initialized
DEBUG - 2011-04-06 11:56:46 --> UTF-8 Support Enabled
DEBUG - 2011-04-06 11:56:46 --> URI Class Initialized
DEBUG - 2011-04-06 11:56:46 --> Router Class Initialized
DEBUG - 2011-04-06 11:56:46 --> Output Class Initialized
DEBUG - 2011-04-06 11:56:46 --> Config Class Initialized
DEBUG - 2011-04-06 11:56:46 --> Hooks Class Initialized
DEBUG - 2011-04-06 11:56:46 --> Utf8 Class Initialized
DEBUG - 2011-04-06 11:56:46 --> UTF-8 Support Enabled
DEBUG - 2011-04-06 11:56:46 --> URI Class Initialized
DEBUG - 2011-04-06 11:56:46 --> Router Class Initialized
DEBUG - 2011-04-06 11:56:46 --> Output Class Initialized
DEBUG - 2011-04-06 11:56:46 --> Input Class Initialized
DEBUG - 2011-04-06 11:56:46 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-06 11:56:46 --> Language Class Initialized
DEBUG - 2011-04-06 11:56:46 --> Input Class Initialized
DEBUG - 2011-04-06 11:56:46 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-06 11:56:46 --> Language Class Initialized
DEBUG - 2011-04-06 11:56:46 --> Loader Class Initialized
DEBUG - 2011-04-06 11:56:46 --> Controller Class Initialized
DEBUG - 2011-04-06 11:56:46 --> Model Class Initialized
DEBUG - 2011-04-06 11:56:46 --> Model Class Initialized
DEBUG - 2011-04-06 11:56:46 --> Model Class Initialized
DEBUG - 2011-04-06 11:56:46 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-06 11:56:46 --> Loader Class Initialized
DEBUG - 2011-04-06 11:56:46 --> Controller Class Initialized
DEBUG - 2011-04-06 11:56:46 --> Model Class Initialized
DEBUG - 2011-04-06 11:56:46 --> Model Class Initialized
DEBUG - 2011-04-06 11:56:46 --> Model Class Initialized
DEBUG - 2011-04-06 11:56:46 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-06 11:56:46 --> Database Driver Class Initialized
DEBUG - 2011-04-06 11:56:46 --> Database Driver Class Initialized
DEBUG - 2011-04-06 11:56:47 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-06 11:56:47 --> Helper loaded: url_helper
DEBUG - 2011-04-06 11:56:47 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-06 11:56:47 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-06 11:56:47 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-06 11:56:47 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-06 11:56:47 --> Final output sent to browser
DEBUG - 2011-04-06 11:56:47 --> Total execution time: 0.5980
DEBUG - 2011-04-06 11:56:47 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-06 11:56:47 --> Helper loaded: url_helper
DEBUG - 2011-04-06 11:56:47 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-06 11:56:47 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-06 11:56:47 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-06 11:56:47 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-06 11:56:47 --> Final output sent to browser
DEBUG - 2011-04-06 11:56:47 --> Total execution time: 0.5886
DEBUG - 2011-04-06 11:56:49 --> Config Class Initialized
DEBUG - 2011-04-06 11:56:49 --> Hooks Class Initialized
DEBUG - 2011-04-06 11:56:49 --> Utf8 Class Initialized
DEBUG - 2011-04-06 11:56:49 --> UTF-8 Support Enabled
DEBUG - 2011-04-06 11:56:49 --> URI Class Initialized
DEBUG - 2011-04-06 11:56:49 --> Router Class Initialized
DEBUG - 2011-04-06 11:56:49 --> Output Class Initialized
DEBUG - 2011-04-06 11:56:49 --> Input Class Initialized
DEBUG - 2011-04-06 11:56:49 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-06 11:56:49 --> Language Class Initialized
DEBUG - 2011-04-06 11:56:49 --> Loader Class Initialized
DEBUG - 2011-04-06 11:56:49 --> Controller Class Initialized
DEBUG - 2011-04-06 11:56:49 --> Model Class Initialized
DEBUG - 2011-04-06 11:56:49 --> Model Class Initialized
DEBUG - 2011-04-06 11:56:49 --> Model Class Initialized
DEBUG - 2011-04-06 11:56:49 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-06 11:56:49 --> Database Driver Class Initialized
DEBUG - 2011-04-06 11:56:49 --> Config Class Initialized
DEBUG - 2011-04-06 11:56:49 --> Hooks Class Initialized
DEBUG - 2011-04-06 11:56:49 --> Utf8 Class Initialized
DEBUG - 2011-04-06 11:56:49 --> UTF-8 Support Enabled
DEBUG - 2011-04-06 11:56:49 --> URI Class Initialized
DEBUG - 2011-04-06 11:56:49 --> Router Class Initialized
DEBUG - 2011-04-06 11:56:49 --> Output Class Initialized
DEBUG - 2011-04-06 11:56:49 --> Input Class Initialized
DEBUG - 2011-04-06 11:56:49 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-06 11:56:49 --> Language Class Initialized
DEBUG - 2011-04-06 11:56:49 --> Loader Class Initialized
DEBUG - 2011-04-06 11:56:49 --> Controller Class Initialized
DEBUG - 2011-04-06 11:56:49 --> Model Class Initialized
DEBUG - 2011-04-06 11:56:49 --> Model Class Initialized
DEBUG - 2011-04-06 11:56:49 --> Model Class Initialized
DEBUG - 2011-04-06 11:56:49 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-06 11:56:49 --> Database Driver Class Initialized
DEBUG - 2011-04-06 11:56:49 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-06 11:56:49 --> Helper loaded: url_helper
DEBUG - 2011-04-06 11:56:49 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-06 11:56:49 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-06 11:56:49 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-06 11:56:49 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-06 11:56:49 --> Final output sent to browser
DEBUG - 2011-04-06 11:56:49 --> Total execution time: 0.1613
DEBUG - 2011-04-06 11:56:49 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-06 11:56:49 --> Helper loaded: url_helper
DEBUG - 2011-04-06 11:56:49 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-06 11:56:49 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-06 11:56:49 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-06 11:56:49 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-06 11:56:49 --> Final output sent to browser
DEBUG - 2011-04-06 11:56:49 --> Total execution time: 0.6438
DEBUG - 2011-04-06 11:56:51 --> Config Class Initialized
DEBUG - 2011-04-06 11:56:51 --> Hooks Class Initialized
DEBUG - 2011-04-06 11:56:51 --> Utf8 Class Initialized
DEBUG - 2011-04-06 11:56:51 --> UTF-8 Support Enabled
DEBUG - 2011-04-06 11:56:51 --> URI Class Initialized
DEBUG - 2011-04-06 11:56:51 --> Router Class Initialized
DEBUG - 2011-04-06 11:56:51 --> Output Class Initialized
DEBUG - 2011-04-06 11:56:51 --> Input Class Initialized
DEBUG - 2011-04-06 11:56:51 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-06 11:56:51 --> Language Class Initialized
DEBUG - 2011-04-06 11:56:51 --> Loader Class Initialized
DEBUG - 2011-04-06 11:56:51 --> Controller Class Initialized
DEBUG - 2011-04-06 11:56:51 --> Model Class Initialized
DEBUG - 2011-04-06 11:56:51 --> Model Class Initialized
DEBUG - 2011-04-06 11:56:51 --> Model Class Initialized
DEBUG - 2011-04-06 11:56:51 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-06 11:56:51 --> Database Driver Class Initialized
DEBUG - 2011-04-06 11:56:51 --> Config Class Initialized
DEBUG - 2011-04-06 11:56:51 --> Hooks Class Initialized
DEBUG - 2011-04-06 11:56:51 --> Utf8 Class Initialized
DEBUG - 2011-04-06 11:56:51 --> UTF-8 Support Enabled
DEBUG - 2011-04-06 11:56:51 --> URI Class Initialized
DEBUG - 2011-04-06 11:56:51 --> Router Class Initialized
DEBUG - 2011-04-06 11:56:51 --> Output Class Initialized
DEBUG - 2011-04-06 11:56:51 --> Input Class Initialized
DEBUG - 2011-04-06 11:56:51 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-06 11:56:51 --> Language Class Initialized
DEBUG - 2011-04-06 11:56:51 --> Loader Class Initialized
DEBUG - 2011-04-06 11:56:51 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-06 11:56:51 --> Helper loaded: url_helper
DEBUG - 2011-04-06 11:56:51 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-06 11:56:51 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-06 11:56:51 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-06 11:56:51 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-06 11:56:51 --> Final output sent to browser
DEBUG - 2011-04-06 11:56:51 --> Total execution time: 0.2944
DEBUG - 2011-04-06 11:56:51 --> Controller Class Initialized
DEBUG - 2011-04-06 11:56:51 --> Model Class Initialized
DEBUG - 2011-04-06 11:56:51 --> Model Class Initialized
DEBUG - 2011-04-06 11:56:51 --> Model Class Initialized
DEBUG - 2011-04-06 11:56:51 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-06 11:56:51 --> Database Driver Class Initialized
DEBUG - 2011-04-06 11:56:51 --> Config Class Initialized
DEBUG - 2011-04-06 11:56:51 --> Hooks Class Initialized
DEBUG - 2011-04-06 11:56:51 --> Utf8 Class Initialized
DEBUG - 2011-04-06 11:56:51 --> UTF-8 Support Enabled
DEBUG - 2011-04-06 11:56:51 --> URI Class Initialized
DEBUG - 2011-04-06 11:56:51 --> Router Class Initialized
DEBUG - 2011-04-06 11:56:51 --> Output Class Initialized
DEBUG - 2011-04-06 11:56:51 --> Input Class Initialized
DEBUG - 2011-04-06 11:56:51 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-06 11:56:51 --> Language Class Initialized
DEBUG - 2011-04-06 11:56:51 --> Loader Class Initialized
DEBUG - 2011-04-06 11:56:51 --> Controller Class Initialized
DEBUG - 2011-04-06 11:56:51 --> Model Class Initialized
DEBUG - 2011-04-06 11:56:51 --> Model Class Initialized
DEBUG - 2011-04-06 11:56:51 --> Model Class Initialized
DEBUG - 2011-04-06 11:56:51 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-06 11:56:51 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-06 11:56:51 --> Helper loaded: url_helper
DEBUG - 2011-04-06 11:56:51 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-06 11:56:51 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-06 11:56:51 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-06 11:56:51 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-06 11:56:51 --> Final output sent to browser
DEBUG - 2011-04-06 11:56:51 --> Total execution time: 0.6291
DEBUG - 2011-04-06 11:56:52 --> Database Driver Class Initialized
DEBUG - 2011-04-06 11:56:52 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-06 11:56:52 --> Helper loaded: url_helper
DEBUG - 2011-04-06 11:56:52 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-06 11:56:52 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-06 11:56:52 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-06 11:56:52 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-06 11:56:52 --> Final output sent to browser
DEBUG - 2011-04-06 11:56:52 --> Total execution time: 0.4286
DEBUG - 2011-04-06 11:56:53 --> Config Class Initialized
DEBUG - 2011-04-06 11:56:53 --> Hooks Class Initialized
DEBUG - 2011-04-06 11:56:53 --> Utf8 Class Initialized
DEBUG - 2011-04-06 11:56:53 --> UTF-8 Support Enabled
DEBUG - 2011-04-06 11:56:53 --> URI Class Initialized
DEBUG - 2011-04-06 11:56:53 --> Router Class Initialized
DEBUG - 2011-04-06 11:56:53 --> Output Class Initialized
DEBUG - 2011-04-06 11:56:53 --> Input Class Initialized
DEBUG - 2011-04-06 11:56:53 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-06 11:56:53 --> Language Class Initialized
DEBUG - 2011-04-06 11:56:53 --> Loader Class Initialized
DEBUG - 2011-04-06 11:56:53 --> Controller Class Initialized
DEBUG - 2011-04-06 11:56:53 --> Model Class Initialized
DEBUG - 2011-04-06 11:56:53 --> Model Class Initialized
DEBUG - 2011-04-06 11:56:53 --> Model Class Initialized
DEBUG - 2011-04-06 11:56:53 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-06 11:56:53 --> Config Class Initialized
DEBUG - 2011-04-06 11:56:53 --> Hooks Class Initialized
DEBUG - 2011-04-06 11:56:53 --> Utf8 Class Initialized
DEBUG - 2011-04-06 11:56:53 --> UTF-8 Support Enabled
DEBUG - 2011-04-06 11:56:53 --> Database Driver Class Initialized
DEBUG - 2011-04-06 11:56:53 --> URI Class Initialized
DEBUG - 2011-04-06 11:56:53 --> Router Class Initialized
DEBUG - 2011-04-06 11:56:53 --> Output Class Initialized
DEBUG - 2011-04-06 11:56:53 --> Input Class Initialized
DEBUG - 2011-04-06 11:56:53 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-06 11:56:53 --> Language Class Initialized
DEBUG - 2011-04-06 11:56:53 --> Loader Class Initialized
DEBUG - 2011-04-06 11:56:53 --> Controller Class Initialized
DEBUG - 2011-04-06 11:56:53 --> Model Class Initialized
DEBUG - 2011-04-06 11:56:53 --> Model Class Initialized
DEBUG - 2011-04-06 11:56:53 --> Model Class Initialized
DEBUG - 2011-04-06 11:56:53 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-06 11:56:53 --> Database Driver Class Initialized
DEBUG - 2011-04-06 11:56:53 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-06 11:56:53 --> Helper loaded: url_helper
DEBUG - 2011-04-06 11:56:53 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-06 11:56:53 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-06 11:56:53 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-06 11:56:53 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-06 11:56:53 --> Final output sent to browser
DEBUG - 2011-04-06 11:56:53 --> Total execution time: 0.3035
DEBUG - 2011-04-06 11:56:53 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-06 11:56:53 --> Helper loaded: url_helper
DEBUG - 2011-04-06 11:56:53 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-06 11:56:53 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-06 11:56:53 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-06 11:56:53 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-06 11:56:53 --> Final output sent to browser
DEBUG - 2011-04-06 11:56:53 --> Total execution time: 0.2797
DEBUG - 2011-04-06 11:56:55 --> Config Class Initialized
DEBUG - 2011-04-06 11:56:55 --> Hooks Class Initialized
DEBUG - 2011-04-06 11:56:55 --> Utf8 Class Initialized
DEBUG - 2011-04-06 11:56:55 --> UTF-8 Support Enabled
DEBUG - 2011-04-06 11:56:55 --> URI Class Initialized
DEBUG - 2011-04-06 11:56:55 --> Router Class Initialized
DEBUG - 2011-04-06 11:56:55 --> No URI present. Default controller set.
DEBUG - 2011-04-06 11:56:55 --> Output Class Initialized
DEBUG - 2011-04-06 11:56:55 --> Input Class Initialized
DEBUG - 2011-04-06 11:56:55 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-06 11:56:55 --> Language Class Initialized
DEBUG - 2011-04-06 11:56:55 --> Loader Class Initialized
DEBUG - 2011-04-06 11:56:55 --> Controller Class Initialized
DEBUG - 2011-04-06 11:56:55 --> File loaded: application/views/splash/main.php
DEBUG - 2011-04-06 11:56:55 --> Helper loaded: url_helper
DEBUG - 2011-04-06 11:56:55 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-06 11:56:55 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-06 11:56:55 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-06 11:56:55 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-06 11:56:55 --> Final output sent to browser
DEBUG - 2011-04-06 11:56:55 --> Total execution time: 0.0369
DEBUG - 2011-04-06 11:56:55 --> Config Class Initialized
DEBUG - 2011-04-06 11:56:55 --> Hooks Class Initialized
DEBUG - 2011-04-06 11:56:55 --> Utf8 Class Initialized
DEBUG - 2011-04-06 11:56:55 --> UTF-8 Support Enabled
DEBUG - 2011-04-06 11:56:55 --> URI Class Initialized
DEBUG - 2011-04-06 11:56:55 --> Router Class Initialized
DEBUG - 2011-04-06 11:56:55 --> No URI present. Default controller set.
DEBUG - 2011-04-06 11:56:55 --> Output Class Initialized
DEBUG - 2011-04-06 11:56:55 --> Input Class Initialized
DEBUG - 2011-04-06 11:56:55 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-06 11:56:55 --> Language Class Initialized
DEBUG - 2011-04-06 11:56:55 --> Loader Class Initialized
DEBUG - 2011-04-06 11:56:55 --> Controller Class Initialized
DEBUG - 2011-04-06 11:56:55 --> Config Class Initialized
DEBUG - 2011-04-06 11:56:55 --> File loaded: application/views/splash/main.php
DEBUG - 2011-04-06 11:56:55 --> Hooks Class Initialized
DEBUG - 2011-04-06 11:56:55 --> Utf8 Class Initialized
DEBUG - 2011-04-06 11:56:55 --> UTF-8 Support Enabled
DEBUG - 2011-04-06 11:56:55 --> URI Class Initialized
DEBUG - 2011-04-06 11:56:55 --> Helper loaded: url_helper
DEBUG - 2011-04-06 11:56:55 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-06 11:56:55 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-06 11:56:55 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-06 11:56:55 --> Router Class Initialized
DEBUG - 2011-04-06 11:56:55 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-06 11:56:55 --> No URI present. Default controller set.
DEBUG - 2011-04-06 11:56:55 --> Final output sent to browser
DEBUG - 2011-04-06 11:56:55 --> Total execution time: 0.0145
DEBUG - 2011-04-06 11:56:55 --> Output Class Initialized
DEBUG - 2011-04-06 11:56:55 --> Input Class Initialized
DEBUG - 2011-04-06 11:56:55 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-06 11:56:55 --> Language Class Initialized
DEBUG - 2011-04-06 11:56:55 --> Loader Class Initialized
DEBUG - 2011-04-06 11:56:55 --> Controller Class Initialized
DEBUG - 2011-04-06 11:56:55 --> File loaded: application/views/splash/main.php
DEBUG - 2011-04-06 11:56:55 --> Helper loaded: url_helper
DEBUG - 2011-04-06 11:56:55 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-06 11:56:55 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-06 11:56:55 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-06 11:56:55 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-06 11:56:55 --> Final output sent to browser
DEBUG - 2011-04-06 11:56:55 --> Total execution time: 0.0132
DEBUG - 2011-04-06 12:02:13 --> Config Class Initialized
DEBUG - 2011-04-06 12:02:13 --> Hooks Class Initialized
DEBUG - 2011-04-06 12:02:13 --> Utf8 Class Initialized
DEBUG - 2011-04-06 12:02:13 --> UTF-8 Support Enabled
DEBUG - 2011-04-06 12:02:13 --> URI Class Initialized
DEBUG - 2011-04-06 12:02:13 --> Router Class Initialized
DEBUG - 2011-04-06 12:02:13 --> Output Class Initialized
DEBUG - 2011-04-06 12:02:13 --> Input Class Initialized
DEBUG - 2011-04-06 12:02:13 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-06 12:02:13 --> Language Class Initialized
DEBUG - 2011-04-06 12:02:13 --> Loader Class Initialized
DEBUG - 2011-04-06 12:02:13 --> Controller Class Initialized
ERROR - 2011-04-06 12:02:13 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-06 12:02:13 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-06 12:02:13 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-06 12:02:13 --> Model Class Initialized
DEBUG - 2011-04-06 12:02:13 --> Model Class Initialized
DEBUG - 2011-04-06 12:02:13 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-06 12:02:13 --> Database Driver Class Initialized
DEBUG - 2011-04-06 12:02:13 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-06 12:02:13 --> Helper loaded: url_helper
DEBUG - 2011-04-06 12:02:13 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-06 12:02:13 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-06 12:02:13 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-06 12:02:13 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-06 12:02:13 --> Final output sent to browser
DEBUG - 2011-04-06 12:02:13 --> Total execution time: 0.1297
DEBUG - 2011-04-06 12:02:14 --> Config Class Initialized
DEBUG - 2011-04-06 12:02:14 --> Hooks Class Initialized
DEBUG - 2011-04-06 12:02:14 --> Utf8 Class Initialized
DEBUG - 2011-04-06 12:02:14 --> UTF-8 Support Enabled
DEBUG - 2011-04-06 12:02:14 --> URI Class Initialized
DEBUG - 2011-04-06 12:02:14 --> Router Class Initialized
DEBUG - 2011-04-06 12:02:14 --> Output Class Initialized
DEBUG - 2011-04-06 12:02:14 --> Input Class Initialized
DEBUG - 2011-04-06 12:02:14 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-06 12:02:14 --> Language Class Initialized
DEBUG - 2011-04-06 12:02:14 --> Loader Class Initialized
DEBUG - 2011-04-06 12:02:14 --> Controller Class Initialized
DEBUG - 2011-04-06 12:02:14 --> Model Class Initialized
DEBUG - 2011-04-06 12:02:14 --> Model Class Initialized
DEBUG - 2011-04-06 12:02:14 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-06 12:02:14 --> Database Driver Class Initialized
DEBUG - 2011-04-06 12:02:15 --> Final output sent to browser
DEBUG - 2011-04-06 12:02:15 --> Total execution time: 0.9842
DEBUG - 2011-04-06 12:02:15 --> Config Class Initialized
DEBUG - 2011-04-06 12:02:15 --> Hooks Class Initialized
DEBUG - 2011-04-06 12:02:15 --> Utf8 Class Initialized
DEBUG - 2011-04-06 12:02:15 --> UTF-8 Support Enabled
DEBUG - 2011-04-06 12:02:15 --> URI Class Initialized
DEBUG - 2011-04-06 12:02:15 --> Router Class Initialized
ERROR - 2011-04-06 12:02:15 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-06 12:02:26 --> Config Class Initialized
DEBUG - 2011-04-06 12:02:26 --> Hooks Class Initialized
DEBUG - 2011-04-06 12:02:26 --> Utf8 Class Initialized
DEBUG - 2011-04-06 12:02:26 --> UTF-8 Support Enabled
DEBUG - 2011-04-06 12:02:26 --> URI Class Initialized
DEBUG - 2011-04-06 12:02:26 --> Router Class Initialized
DEBUG - 2011-04-06 12:02:26 --> Output Class Initialized
DEBUG - 2011-04-06 12:02:26 --> Input Class Initialized
DEBUG - 2011-04-06 12:02:26 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-06 12:02:26 --> Language Class Initialized
DEBUG - 2011-04-06 12:02:26 --> Loader Class Initialized
DEBUG - 2011-04-06 12:02:26 --> Controller Class Initialized
ERROR - 2011-04-06 12:02:26 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-06 12:02:26 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-06 12:02:26 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-06 12:02:26 --> Model Class Initialized
DEBUG - 2011-04-06 12:02:26 --> Model Class Initialized
DEBUG - 2011-04-06 12:02:26 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-06 12:02:26 --> Database Driver Class Initialized
DEBUG - 2011-04-06 12:02:26 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-06 12:02:26 --> Helper loaded: url_helper
DEBUG - 2011-04-06 12:02:26 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-06 12:02:26 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-06 12:02:26 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-06 12:02:26 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-06 12:02:26 --> Final output sent to browser
DEBUG - 2011-04-06 12:02:26 --> Total execution time: 0.0538
DEBUG - 2011-04-06 12:02:27 --> Config Class Initialized
DEBUG - 2011-04-06 12:02:27 --> Hooks Class Initialized
DEBUG - 2011-04-06 12:02:27 --> Utf8 Class Initialized
DEBUG - 2011-04-06 12:02:27 --> UTF-8 Support Enabled
DEBUG - 2011-04-06 12:02:27 --> URI Class Initialized
DEBUG - 2011-04-06 12:02:27 --> Router Class Initialized
DEBUG - 2011-04-06 12:02:27 --> Output Class Initialized
DEBUG - 2011-04-06 12:02:27 --> Input Class Initialized
DEBUG - 2011-04-06 12:02:27 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-06 12:02:27 --> Language Class Initialized
DEBUG - 2011-04-06 12:02:27 --> Loader Class Initialized
DEBUG - 2011-04-06 12:02:27 --> Controller Class Initialized
DEBUG - 2011-04-06 12:02:27 --> Model Class Initialized
DEBUG - 2011-04-06 12:02:27 --> Model Class Initialized
DEBUG - 2011-04-06 12:02:27 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-06 12:02:27 --> Database Driver Class Initialized
DEBUG - 2011-04-06 12:02:28 --> Final output sent to browser
DEBUG - 2011-04-06 12:02:28 --> Total execution time: 0.8052
DEBUG - 2011-04-06 12:02:28 --> Config Class Initialized
DEBUG - 2011-04-06 12:02:28 --> Hooks Class Initialized
DEBUG - 2011-04-06 12:02:28 --> Utf8 Class Initialized
DEBUG - 2011-04-06 12:02:28 --> UTF-8 Support Enabled
DEBUG - 2011-04-06 12:02:28 --> URI Class Initialized
DEBUG - 2011-04-06 12:02:28 --> Router Class Initialized
ERROR - 2011-04-06 12:02:28 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-06 12:02:35 --> Config Class Initialized
DEBUG - 2011-04-06 12:02:35 --> Hooks Class Initialized
DEBUG - 2011-04-06 12:02:35 --> Utf8 Class Initialized
DEBUG - 2011-04-06 12:02:35 --> UTF-8 Support Enabled
DEBUG - 2011-04-06 12:02:35 --> URI Class Initialized
DEBUG - 2011-04-06 12:02:35 --> Router Class Initialized
DEBUG - 2011-04-06 12:02:35 --> Output Class Initialized
DEBUG - 2011-04-06 12:02:35 --> Input Class Initialized
DEBUG - 2011-04-06 12:02:35 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-06 12:02:35 --> Language Class Initialized
DEBUG - 2011-04-06 12:02:35 --> Loader Class Initialized
DEBUG - 2011-04-06 12:02:35 --> Controller Class Initialized
ERROR - 2011-04-06 12:02:35 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-06 12:02:35 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-06 12:02:35 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-06 12:02:35 --> Model Class Initialized
DEBUG - 2011-04-06 12:02:35 --> Model Class Initialized
DEBUG - 2011-04-06 12:02:35 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-06 12:02:35 --> Database Driver Class Initialized
DEBUG - 2011-04-06 12:02:35 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-06 12:02:35 --> Helper loaded: url_helper
DEBUG - 2011-04-06 12:02:35 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-06 12:02:35 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-06 12:02:35 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-06 12:02:35 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-06 12:02:35 --> Final output sent to browser
DEBUG - 2011-04-06 12:02:35 --> Total execution time: 0.0323
DEBUG - 2011-04-06 12:02:36 --> Config Class Initialized
DEBUG - 2011-04-06 12:02:36 --> Hooks Class Initialized
DEBUG - 2011-04-06 12:02:36 --> Utf8 Class Initialized
DEBUG - 2011-04-06 12:02:36 --> UTF-8 Support Enabled
DEBUG - 2011-04-06 12:02:36 --> URI Class Initialized
DEBUG - 2011-04-06 12:02:36 --> Router Class Initialized
DEBUG - 2011-04-06 12:02:36 --> Output Class Initialized
DEBUG - 2011-04-06 12:02:36 --> Input Class Initialized
DEBUG - 2011-04-06 12:02:36 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-06 12:02:36 --> Language Class Initialized
DEBUG - 2011-04-06 12:02:36 --> Loader Class Initialized
DEBUG - 2011-04-06 12:02:36 --> Controller Class Initialized
DEBUG - 2011-04-06 12:02:36 --> Model Class Initialized
DEBUG - 2011-04-06 12:02:36 --> Model Class Initialized
DEBUG - 2011-04-06 12:02:36 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-06 12:02:36 --> Database Driver Class Initialized
DEBUG - 2011-04-06 12:02:36 --> Final output sent to browser
DEBUG - 2011-04-06 12:02:36 --> Total execution time: 0.6823
DEBUG - 2011-04-06 12:02:37 --> Config Class Initialized
DEBUG - 2011-04-06 12:02:37 --> Hooks Class Initialized
DEBUG - 2011-04-06 12:02:37 --> Utf8 Class Initialized
DEBUG - 2011-04-06 12:02:37 --> UTF-8 Support Enabled
DEBUG - 2011-04-06 12:02:37 --> URI Class Initialized
DEBUG - 2011-04-06 12:02:37 --> Router Class Initialized
ERROR - 2011-04-06 12:02:37 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-06 12:02:50 --> Config Class Initialized
DEBUG - 2011-04-06 12:02:50 --> Hooks Class Initialized
DEBUG - 2011-04-06 12:02:50 --> Utf8 Class Initialized
DEBUG - 2011-04-06 12:02:50 --> UTF-8 Support Enabled
DEBUG - 2011-04-06 12:02:50 --> URI Class Initialized
DEBUG - 2011-04-06 12:02:50 --> Router Class Initialized
ERROR - 2011-04-06 12:02:50 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-06 12:02:52 --> Config Class Initialized
DEBUG - 2011-04-06 12:02:52 --> Hooks Class Initialized
DEBUG - 2011-04-06 12:02:52 --> Utf8 Class Initialized
DEBUG - 2011-04-06 12:02:52 --> UTF-8 Support Enabled
DEBUG - 2011-04-06 12:02:52 --> URI Class Initialized
DEBUG - 2011-04-06 12:02:52 --> Router Class Initialized
ERROR - 2011-04-06 12:02:52 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-06 12:18:31 --> Config Class Initialized
DEBUG - 2011-04-06 12:18:31 --> Hooks Class Initialized
DEBUG - 2011-04-06 12:18:31 --> Utf8 Class Initialized
DEBUG - 2011-04-06 12:18:31 --> UTF-8 Support Enabled
DEBUG - 2011-04-06 12:18:31 --> URI Class Initialized
DEBUG - 2011-04-06 12:18:31 --> Router Class Initialized
DEBUG - 2011-04-06 12:18:31 --> Output Class Initialized
DEBUG - 2011-04-06 12:18:31 --> Input Class Initialized
DEBUG - 2011-04-06 12:18:31 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-06 12:18:31 --> Language Class Initialized
DEBUG - 2011-04-06 12:18:31 --> Loader Class Initialized
DEBUG - 2011-04-06 12:18:31 --> Controller Class Initialized
DEBUG - 2011-04-06 12:18:31 --> Model Class Initialized
DEBUG - 2011-04-06 12:18:31 --> Model Class Initialized
DEBUG - 2011-04-06 12:18:31 --> Model Class Initialized
DEBUG - 2011-04-06 12:18:31 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-06 12:18:31 --> Database Driver Class Initialized
DEBUG - 2011-04-06 12:18:32 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-06 12:18:32 --> Helper loaded: url_helper
DEBUG - 2011-04-06 12:18:32 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-06 12:18:32 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-06 12:18:32 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-06 12:18:32 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-06 12:18:32 --> Final output sent to browser
DEBUG - 2011-04-06 12:18:32 --> Total execution time: 1.1264
DEBUG - 2011-04-06 12:35:29 --> Config Class Initialized
DEBUG - 2011-04-06 12:35:29 --> Hooks Class Initialized
DEBUG - 2011-04-06 12:35:30 --> Utf8 Class Initialized
DEBUG - 2011-04-06 12:35:30 --> UTF-8 Support Enabled
DEBUG - 2011-04-06 12:35:30 --> URI Class Initialized
DEBUG - 2011-04-06 12:35:30 --> Router Class Initialized
DEBUG - 2011-04-06 12:35:34 --> Output Class Initialized
DEBUG - 2011-04-06 12:35:34 --> Input Class Initialized
DEBUG - 2011-04-06 12:35:34 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-06 12:35:35 --> Language Class Initialized
DEBUG - 2011-04-06 12:35:36 --> Loader Class Initialized
DEBUG - 2011-04-06 12:35:36 --> Controller Class Initialized
ERROR - 2011-04-06 12:35:37 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-06 12:35:37 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-06 12:35:37 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-06 12:35:37 --> Model Class Initialized
DEBUG - 2011-04-06 12:35:37 --> Model Class Initialized
DEBUG - 2011-04-06 12:35:37 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-06 12:35:37 --> Database Driver Class Initialized
DEBUG - 2011-04-06 12:35:37 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-06 12:35:38 --> Helper loaded: url_helper
DEBUG - 2011-04-06 12:35:38 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-06 12:35:38 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-06 12:35:38 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-06 12:35:38 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-06 12:35:38 --> Final output sent to browser
DEBUG - 2011-04-06 12:35:38 --> Total execution time: 8.8615
DEBUG - 2011-04-06 12:35:40 --> Config Class Initialized
DEBUG - 2011-04-06 12:35:40 --> Hooks Class Initialized
DEBUG - 2011-04-06 12:35:40 --> Utf8 Class Initialized
DEBUG - 2011-04-06 12:35:40 --> UTF-8 Support Enabled
DEBUG - 2011-04-06 12:35:40 --> URI Class Initialized
DEBUG - 2011-04-06 12:35:40 --> Router Class Initialized
DEBUG - 2011-04-06 12:35:40 --> Output Class Initialized
DEBUG - 2011-04-06 12:35:40 --> Input Class Initialized
DEBUG - 2011-04-06 12:35:40 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-06 12:35:40 --> Language Class Initialized
DEBUG - 2011-04-06 12:35:40 --> Loader Class Initialized
DEBUG - 2011-04-06 12:35:40 --> Controller Class Initialized
DEBUG - 2011-04-06 12:35:40 --> Model Class Initialized
DEBUG - 2011-04-06 12:35:40 --> Model Class Initialized
DEBUG - 2011-04-06 12:35:40 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-06 12:35:40 --> Database Driver Class Initialized
DEBUG - 2011-04-06 12:35:41 --> Final output sent to browser
DEBUG - 2011-04-06 12:35:41 --> Total execution time: 1.3906
DEBUG - 2011-04-06 12:35:42 --> Config Class Initialized
DEBUG - 2011-04-06 12:35:42 --> Hooks Class Initialized
DEBUG - 2011-04-06 12:35:42 --> Utf8 Class Initialized
DEBUG - 2011-04-06 12:35:42 --> UTF-8 Support Enabled
DEBUG - 2011-04-06 12:35:42 --> URI Class Initialized
DEBUG - 2011-04-06 12:35:42 --> Router Class Initialized
ERROR - 2011-04-06 12:35:42 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-06 12:38:37 --> Config Class Initialized
DEBUG - 2011-04-06 12:38:37 --> Hooks Class Initialized
DEBUG - 2011-04-06 12:38:37 --> Utf8 Class Initialized
DEBUG - 2011-04-06 12:38:37 --> UTF-8 Support Enabled
DEBUG - 2011-04-06 12:38:37 --> URI Class Initialized
DEBUG - 2011-04-06 12:38:37 --> Router Class Initialized
ERROR - 2011-04-06 12:38:37 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-04-06 12:49:54 --> Config Class Initialized
DEBUG - 2011-04-06 12:49:54 --> Hooks Class Initialized
DEBUG - 2011-04-06 12:49:54 --> Utf8 Class Initialized
DEBUG - 2011-04-06 12:49:54 --> UTF-8 Support Enabled
DEBUG - 2011-04-06 12:49:54 --> URI Class Initialized
DEBUG - 2011-04-06 12:49:54 --> Router Class Initialized
DEBUG - 2011-04-06 12:49:54 --> Output Class Initialized
DEBUG - 2011-04-06 12:49:54 --> Input Class Initialized
DEBUG - 2011-04-06 12:49:54 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-06 12:49:54 --> Language Class Initialized
DEBUG - 2011-04-06 12:49:54 --> Loader Class Initialized
DEBUG - 2011-04-06 12:49:54 --> Controller Class Initialized
DEBUG - 2011-04-06 12:49:54 --> Model Class Initialized
DEBUG - 2011-04-06 12:49:54 --> Model Class Initialized
DEBUG - 2011-04-06 12:49:54 --> Model Class Initialized
DEBUG - 2011-04-06 12:49:54 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-06 12:49:54 --> Database Driver Class Initialized
DEBUG - 2011-04-06 12:49:55 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-06 12:49:55 --> Helper loaded: url_helper
DEBUG - 2011-04-06 12:49:55 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-06 12:49:55 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-06 12:49:55 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-06 12:49:55 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-06 12:49:55 --> Final output sent to browser
DEBUG - 2011-04-06 12:49:55 --> Total execution time: 0.3755
DEBUG - 2011-04-06 12:49:58 --> Config Class Initialized
DEBUG - 2011-04-06 12:49:58 --> Hooks Class Initialized
DEBUG - 2011-04-06 12:49:58 --> Utf8 Class Initialized
DEBUG - 2011-04-06 12:49:58 --> UTF-8 Support Enabled
DEBUG - 2011-04-06 12:49:58 --> URI Class Initialized
DEBUG - 2011-04-06 12:49:58 --> Router Class Initialized
ERROR - 2011-04-06 12:49:58 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-06 12:50:01 --> Config Class Initialized
DEBUG - 2011-04-06 12:50:01 --> Hooks Class Initialized
DEBUG - 2011-04-06 12:50:01 --> Utf8 Class Initialized
DEBUG - 2011-04-06 12:50:01 --> UTF-8 Support Enabled
DEBUG - 2011-04-06 12:50:01 --> URI Class Initialized
DEBUG - 2011-04-06 12:50:01 --> Router Class Initialized
ERROR - 2011-04-06 12:50:01 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-06 12:50:13 --> Config Class Initialized
DEBUG - 2011-04-06 12:50:13 --> Hooks Class Initialized
DEBUG - 2011-04-06 12:50:13 --> Utf8 Class Initialized
DEBUG - 2011-04-06 12:50:13 --> UTF-8 Support Enabled
DEBUG - 2011-04-06 12:50:13 --> URI Class Initialized
DEBUG - 2011-04-06 12:50:13 --> Router Class Initialized
DEBUG - 2011-04-06 12:50:13 --> Output Class Initialized
DEBUG - 2011-04-06 12:50:13 --> Input Class Initialized
DEBUG - 2011-04-06 12:50:13 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-06 12:50:13 --> Language Class Initialized
DEBUG - 2011-04-06 12:50:13 --> Loader Class Initialized
DEBUG - 2011-04-06 12:50:13 --> Controller Class Initialized
DEBUG - 2011-04-06 12:50:13 --> Model Class Initialized
DEBUG - 2011-04-06 12:50:13 --> Model Class Initialized
DEBUG - 2011-04-06 12:50:13 --> Model Class Initialized
DEBUG - 2011-04-06 12:50:13 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-06 12:50:13 --> Database Driver Class Initialized
DEBUG - 2011-04-06 12:50:13 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-06 12:50:13 --> Helper loaded: url_helper
DEBUG - 2011-04-06 12:50:13 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-06 12:50:13 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-06 12:50:13 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-06 12:50:13 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-06 12:50:13 --> Final output sent to browser
DEBUG - 2011-04-06 12:50:13 --> Total execution time: 0.5396
DEBUG - 2011-04-06 12:50:35 --> Config Class Initialized
DEBUG - 2011-04-06 12:50:35 --> Hooks Class Initialized
DEBUG - 2011-04-06 12:50:35 --> Utf8 Class Initialized
DEBUG - 2011-04-06 12:50:35 --> UTF-8 Support Enabled
DEBUG - 2011-04-06 12:50:35 --> URI Class Initialized
DEBUG - 2011-04-06 12:50:35 --> Router Class Initialized
DEBUG - 2011-04-06 12:50:35 --> Output Class Initialized
DEBUG - 2011-04-06 12:50:35 --> Input Class Initialized
DEBUG - 2011-04-06 12:50:35 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-06 12:50:35 --> Language Class Initialized
DEBUG - 2011-04-06 12:50:35 --> Loader Class Initialized
DEBUG - 2011-04-06 12:50:35 --> Controller Class Initialized
DEBUG - 2011-04-06 12:50:35 --> Model Class Initialized
DEBUG - 2011-04-06 12:50:35 --> Model Class Initialized
DEBUG - 2011-04-06 12:50:35 --> Model Class Initialized
DEBUG - 2011-04-06 12:50:35 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-06 12:50:35 --> Database Driver Class Initialized
DEBUG - 2011-04-06 12:50:35 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-06 12:50:35 --> Helper loaded: url_helper
DEBUG - 2011-04-06 12:50:35 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-06 12:50:35 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-06 12:50:35 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-06 12:50:35 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-06 12:50:35 --> Final output sent to browser
DEBUG - 2011-04-06 12:50:35 --> Total execution time: 0.2903
DEBUG - 2011-04-06 12:50:49 --> Config Class Initialized
DEBUG - 2011-04-06 12:50:49 --> Hooks Class Initialized
DEBUG - 2011-04-06 12:50:49 --> Utf8 Class Initialized
DEBUG - 2011-04-06 12:50:49 --> UTF-8 Support Enabled
DEBUG - 2011-04-06 12:50:49 --> URI Class Initialized
DEBUG - 2011-04-06 12:50:49 --> Router Class Initialized
DEBUG - 2011-04-06 12:50:49 --> Output Class Initialized
DEBUG - 2011-04-06 12:50:49 --> Input Class Initialized
DEBUG - 2011-04-06 12:50:49 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-06 12:50:49 --> Language Class Initialized
DEBUG - 2011-04-06 12:50:49 --> Loader Class Initialized
DEBUG - 2011-04-06 12:50:49 --> Controller Class Initialized
DEBUG - 2011-04-06 12:50:49 --> Model Class Initialized
DEBUG - 2011-04-06 12:50:49 --> Model Class Initialized
DEBUG - 2011-04-06 12:50:49 --> Model Class Initialized
DEBUG - 2011-04-06 12:50:49 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-06 12:50:49 --> Database Driver Class Initialized
DEBUG - 2011-04-06 12:50:50 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-06 12:50:50 --> Helper loaded: url_helper
DEBUG - 2011-04-06 12:50:50 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-06 12:50:50 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-06 12:50:50 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-06 12:50:50 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-06 12:50:50 --> Final output sent to browser
DEBUG - 2011-04-06 12:50:50 --> Total execution time: 0.2724
DEBUG - 2011-04-06 12:51:14 --> Config Class Initialized
DEBUG - 2011-04-06 12:51:14 --> Hooks Class Initialized
DEBUG - 2011-04-06 12:51:14 --> Utf8 Class Initialized
DEBUG - 2011-04-06 12:51:14 --> UTF-8 Support Enabled
DEBUG - 2011-04-06 12:51:14 --> URI Class Initialized
DEBUG - 2011-04-06 12:51:14 --> Router Class Initialized
DEBUG - 2011-04-06 12:51:14 --> Output Class Initialized
DEBUG - 2011-04-06 12:51:14 --> Input Class Initialized
DEBUG - 2011-04-06 12:51:14 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-06 12:51:14 --> Language Class Initialized
DEBUG - 2011-04-06 12:51:14 --> Loader Class Initialized
DEBUG - 2011-04-06 12:51:14 --> Controller Class Initialized
DEBUG - 2011-04-06 12:51:14 --> Model Class Initialized
DEBUG - 2011-04-06 12:51:14 --> Model Class Initialized
DEBUG - 2011-04-06 12:51:14 --> Model Class Initialized
DEBUG - 2011-04-06 12:51:14 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-06 12:51:14 --> Database Driver Class Initialized
DEBUG - 2011-04-06 12:51:14 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-06 12:51:14 --> Helper loaded: url_helper
DEBUG - 2011-04-06 12:51:14 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-06 12:51:14 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-06 12:51:14 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-06 12:51:14 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-06 12:51:14 --> Final output sent to browser
DEBUG - 2011-04-06 12:51:14 --> Total execution time: 0.2598
DEBUG - 2011-04-06 12:52:02 --> Config Class Initialized
DEBUG - 2011-04-06 12:52:02 --> Hooks Class Initialized
DEBUG - 2011-04-06 12:52:02 --> Utf8 Class Initialized
DEBUG - 2011-04-06 12:52:02 --> UTF-8 Support Enabled
DEBUG - 2011-04-06 12:52:02 --> URI Class Initialized
DEBUG - 2011-04-06 12:52:02 --> Router Class Initialized
DEBUG - 2011-04-06 12:52:02 --> Output Class Initialized
DEBUG - 2011-04-06 12:52:02 --> Input Class Initialized
DEBUG - 2011-04-06 12:52:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-06 12:52:02 --> Language Class Initialized
DEBUG - 2011-04-06 12:52:02 --> Loader Class Initialized
DEBUG - 2011-04-06 12:52:02 --> Controller Class Initialized
ERROR - 2011-04-06 12:52:02 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-06 12:52:02 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-06 12:52:02 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-06 12:52:02 --> Model Class Initialized
DEBUG - 2011-04-06 12:52:02 --> Model Class Initialized
DEBUG - 2011-04-06 12:52:02 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-06 12:52:02 --> Database Driver Class Initialized
DEBUG - 2011-04-06 12:52:02 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-06 12:52:02 --> Helper loaded: url_helper
DEBUG - 2011-04-06 12:52:02 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-06 12:52:02 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-06 12:52:02 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-06 12:52:02 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-06 12:52:02 --> Final output sent to browser
DEBUG - 2011-04-06 12:52:02 --> Total execution time: 0.0294
DEBUG - 2011-04-06 12:52:03 --> Config Class Initialized
DEBUG - 2011-04-06 12:52:03 --> Hooks Class Initialized
DEBUG - 2011-04-06 12:52:03 --> Utf8 Class Initialized
DEBUG - 2011-04-06 12:52:03 --> UTF-8 Support Enabled
DEBUG - 2011-04-06 12:52:03 --> URI Class Initialized
DEBUG - 2011-04-06 12:52:03 --> Router Class Initialized
DEBUG - 2011-04-06 12:52:03 --> Output Class Initialized
DEBUG - 2011-04-06 12:52:03 --> Input Class Initialized
DEBUG - 2011-04-06 12:52:03 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-06 12:52:03 --> Language Class Initialized
DEBUG - 2011-04-06 12:52:03 --> Loader Class Initialized
DEBUG - 2011-04-06 12:52:03 --> Controller Class Initialized
DEBUG - 2011-04-06 12:52:03 --> Model Class Initialized
DEBUG - 2011-04-06 12:52:03 --> Model Class Initialized
DEBUG - 2011-04-06 12:52:03 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-06 12:52:03 --> Database Driver Class Initialized
DEBUG - 2011-04-06 12:52:04 --> Final output sent to browser
DEBUG - 2011-04-06 12:52:04 --> Total execution time: 1.4155
DEBUG - 2011-04-06 13:07:44 --> Config Class Initialized
DEBUG - 2011-04-06 13:07:44 --> Hooks Class Initialized
DEBUG - 2011-04-06 13:07:44 --> Utf8 Class Initialized
DEBUG - 2011-04-06 13:07:44 --> UTF-8 Support Enabled
DEBUG - 2011-04-06 13:07:44 --> URI Class Initialized
DEBUG - 2011-04-06 13:07:44 --> Router Class Initialized
DEBUG - 2011-04-06 13:07:44 --> Output Class Initialized
DEBUG - 2011-04-06 13:07:44 --> Input Class Initialized
DEBUG - 2011-04-06 13:07:44 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-06 13:07:44 --> Language Class Initialized
DEBUG - 2011-04-06 13:07:44 --> Loader Class Initialized
DEBUG - 2011-04-06 13:07:44 --> Controller Class Initialized
DEBUG - 2011-04-06 13:07:44 --> Model Class Initialized
DEBUG - 2011-04-06 13:07:44 --> Model Class Initialized
DEBUG - 2011-04-06 13:07:44 --> Model Class Initialized
DEBUG - 2011-04-06 13:07:44 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-06 13:07:44 --> Database Driver Class Initialized
DEBUG - 2011-04-06 13:07:45 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-06 13:07:45 --> Helper loaded: url_helper
DEBUG - 2011-04-06 13:07:45 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-06 13:07:45 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-06 13:07:45 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-06 13:07:45 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-06 13:07:45 --> Final output sent to browser
DEBUG - 2011-04-06 13:07:45 --> Total execution time: 0.6562
DEBUG - 2011-04-06 13:28:49 --> Config Class Initialized
DEBUG - 2011-04-06 13:28:49 --> Hooks Class Initialized
DEBUG - 2011-04-06 13:28:49 --> Utf8 Class Initialized
DEBUG - 2011-04-06 13:28:49 --> UTF-8 Support Enabled
DEBUG - 2011-04-06 13:28:49 --> URI Class Initialized
DEBUG - 2011-04-06 13:28:49 --> Router Class Initialized
DEBUG - 2011-04-06 13:28:49 --> Output Class Initialized
DEBUG - 2011-04-06 13:28:49 --> Input Class Initialized
DEBUG - 2011-04-06 13:28:49 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-06 13:28:49 --> Language Class Initialized
DEBUG - 2011-04-06 13:28:49 --> Loader Class Initialized
DEBUG - 2011-04-06 13:28:49 --> Controller Class Initialized
DEBUG - 2011-04-06 13:28:49 --> Model Class Initialized
DEBUG - 2011-04-06 13:28:49 --> Model Class Initialized
DEBUG - 2011-04-06 13:28:49 --> Model Class Initialized
DEBUG - 2011-04-06 13:28:49 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-06 13:28:49 --> Database Driver Class Initialized
DEBUG - 2011-04-06 13:28:50 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-06 13:28:50 --> Helper loaded: url_helper
DEBUG - 2011-04-06 13:28:50 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-06 13:28:50 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-06 13:28:50 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-06 13:28:50 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-06 13:28:50 --> Final output sent to browser
DEBUG - 2011-04-06 13:28:50 --> Total execution time: 0.3601
DEBUG - 2011-04-06 13:28:52 --> Config Class Initialized
DEBUG - 2011-04-06 13:28:52 --> Hooks Class Initialized
DEBUG - 2011-04-06 13:28:52 --> Utf8 Class Initialized
DEBUG - 2011-04-06 13:28:52 --> UTF-8 Support Enabled
DEBUG - 2011-04-06 13:28:52 --> URI Class Initialized
DEBUG - 2011-04-06 13:28:52 --> Router Class Initialized
ERROR - 2011-04-06 13:28:52 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-06 13:41:46 --> Config Class Initialized
DEBUG - 2011-04-06 13:41:46 --> Hooks Class Initialized
DEBUG - 2011-04-06 13:41:46 --> Utf8 Class Initialized
DEBUG - 2011-04-06 13:41:46 --> UTF-8 Support Enabled
DEBUG - 2011-04-06 13:41:46 --> URI Class Initialized
DEBUG - 2011-04-06 13:41:46 --> Router Class Initialized
DEBUG - 2011-04-06 13:41:46 --> Output Class Initialized
DEBUG - 2011-04-06 13:41:46 --> Input Class Initialized
DEBUG - 2011-04-06 13:41:46 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-06 13:41:47 --> Language Class Initialized
DEBUG - 2011-04-06 13:41:47 --> Loader Class Initialized
DEBUG - 2011-04-06 13:41:47 --> Controller Class Initialized
ERROR - 2011-04-06 13:41:47 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-06 13:41:47 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-06 13:41:47 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-06 13:41:47 --> Model Class Initialized
DEBUG - 2011-04-06 13:41:47 --> Model Class Initialized
DEBUG - 2011-04-06 13:41:47 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-06 13:41:47 --> Database Driver Class Initialized
DEBUG - 2011-04-06 13:41:47 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-06 13:41:47 --> Helper loaded: url_helper
DEBUG - 2011-04-06 13:41:47 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-06 13:41:47 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-06 13:41:47 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-06 13:41:47 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-06 13:41:47 --> Final output sent to browser
DEBUG - 2011-04-06 13:41:47 --> Total execution time: 0.3150
DEBUG - 2011-04-06 13:41:49 --> Config Class Initialized
DEBUG - 2011-04-06 13:41:49 --> Hooks Class Initialized
DEBUG - 2011-04-06 13:41:49 --> Utf8 Class Initialized
DEBUG - 2011-04-06 13:41:49 --> UTF-8 Support Enabled
DEBUG - 2011-04-06 13:41:49 --> URI Class Initialized
DEBUG - 2011-04-06 13:41:49 --> Router Class Initialized
DEBUG - 2011-04-06 13:41:49 --> Output Class Initialized
DEBUG - 2011-04-06 13:41:49 --> Input Class Initialized
DEBUG - 2011-04-06 13:41:49 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-06 13:41:49 --> Language Class Initialized
DEBUG - 2011-04-06 13:41:49 --> Loader Class Initialized
DEBUG - 2011-04-06 13:41:49 --> Controller Class Initialized
DEBUG - 2011-04-06 13:41:49 --> Model Class Initialized
DEBUG - 2011-04-06 13:41:49 --> Model Class Initialized
DEBUG - 2011-04-06 13:41:49 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-06 13:41:49 --> Database Driver Class Initialized
DEBUG - 2011-04-06 13:41:49 --> Final output sent to browser
DEBUG - 2011-04-06 13:41:49 --> Total execution time: 0.7378
DEBUG - 2011-04-06 14:38:57 --> Config Class Initialized
DEBUG - 2011-04-06 14:38:57 --> Hooks Class Initialized
DEBUG - 2011-04-06 14:38:57 --> Utf8 Class Initialized
DEBUG - 2011-04-06 14:38:57 --> UTF-8 Support Enabled
DEBUG - 2011-04-06 14:38:57 --> URI Class Initialized
DEBUG - 2011-04-06 14:38:57 --> Router Class Initialized
DEBUG - 2011-04-06 14:38:57 --> Output Class Initialized
DEBUG - 2011-04-06 14:38:57 --> Input Class Initialized
DEBUG - 2011-04-06 14:38:57 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-06 14:38:57 --> Language Class Initialized
DEBUG - 2011-04-06 14:38:57 --> Loader Class Initialized
DEBUG - 2011-04-06 14:38:57 --> Controller Class Initialized
ERROR - 2011-04-06 14:38:57 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-06 14:38:57 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-06 14:38:57 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-06 14:38:57 --> Model Class Initialized
DEBUG - 2011-04-06 14:38:57 --> Model Class Initialized
DEBUG - 2011-04-06 14:38:57 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-06 14:38:57 --> Database Driver Class Initialized
DEBUG - 2011-04-06 14:38:57 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-06 14:38:57 --> Helper loaded: url_helper
DEBUG - 2011-04-06 14:38:57 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-06 14:38:57 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-06 14:38:57 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-06 14:38:57 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-06 14:38:57 --> Final output sent to browser
DEBUG - 2011-04-06 14:38:57 --> Total execution time: 0.8087
DEBUG - 2011-04-06 14:38:59 --> Config Class Initialized
DEBUG - 2011-04-06 14:38:59 --> Hooks Class Initialized
DEBUG - 2011-04-06 14:38:59 --> Utf8 Class Initialized
DEBUG - 2011-04-06 14:38:59 --> UTF-8 Support Enabled
DEBUG - 2011-04-06 14:38:59 --> URI Class Initialized
DEBUG - 2011-04-06 14:38:59 --> Router Class Initialized
DEBUG - 2011-04-06 14:38:59 --> Output Class Initialized
DEBUG - 2011-04-06 14:38:59 --> Input Class Initialized
DEBUG - 2011-04-06 14:38:59 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-06 14:38:59 --> Language Class Initialized
DEBUG - 2011-04-06 14:38:59 --> Loader Class Initialized
DEBUG - 2011-04-06 14:38:59 --> Controller Class Initialized
DEBUG - 2011-04-06 14:38:59 --> Model Class Initialized
DEBUG - 2011-04-06 14:38:59 --> Model Class Initialized
DEBUG - 2011-04-06 14:38:59 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-06 14:38:59 --> Database Driver Class Initialized
DEBUG - 2011-04-06 14:39:00 --> Final output sent to browser
DEBUG - 2011-04-06 14:39:00 --> Total execution time: 0.9099
DEBUG - 2011-04-06 14:39:00 --> Config Class Initialized
DEBUG - 2011-04-06 14:39:00 --> Hooks Class Initialized
DEBUG - 2011-04-06 14:39:00 --> Utf8 Class Initialized
DEBUG - 2011-04-06 14:39:00 --> UTF-8 Support Enabled
DEBUG - 2011-04-06 14:39:00 --> URI Class Initialized
DEBUG - 2011-04-06 14:39:00 --> Router Class Initialized
ERROR - 2011-04-06 14:39:00 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-06 14:39:01 --> Config Class Initialized
DEBUG - 2011-04-06 14:39:01 --> Hooks Class Initialized
DEBUG - 2011-04-06 14:39:01 --> Utf8 Class Initialized
DEBUG - 2011-04-06 14:39:01 --> UTF-8 Support Enabled
DEBUG - 2011-04-06 14:39:01 --> URI Class Initialized
DEBUG - 2011-04-06 14:39:01 --> Router Class Initialized
ERROR - 2011-04-06 14:39:01 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-06 14:39:01 --> Config Class Initialized
DEBUG - 2011-04-06 14:39:01 --> Hooks Class Initialized
DEBUG - 2011-04-06 14:39:01 --> Utf8 Class Initialized
DEBUG - 2011-04-06 14:39:01 --> UTF-8 Support Enabled
DEBUG - 2011-04-06 14:39:01 --> URI Class Initialized
DEBUG - 2011-04-06 14:39:01 --> Router Class Initialized
ERROR - 2011-04-06 14:39:01 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-06 14:42:44 --> Config Class Initialized
DEBUG - 2011-04-06 14:42:44 --> Hooks Class Initialized
DEBUG - 2011-04-06 14:42:44 --> Utf8 Class Initialized
DEBUG - 2011-04-06 14:42:44 --> UTF-8 Support Enabled
DEBUG - 2011-04-06 14:42:44 --> URI Class Initialized
DEBUG - 2011-04-06 14:42:44 --> Router Class Initialized
DEBUG - 2011-04-06 14:42:44 --> Output Class Initialized
DEBUG - 2011-04-06 14:42:44 --> Input Class Initialized
DEBUG - 2011-04-06 14:42:44 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-06 14:42:44 --> Language Class Initialized
DEBUG - 2011-04-06 14:42:44 --> Loader Class Initialized
DEBUG - 2011-04-06 14:42:44 --> Controller Class Initialized
ERROR - 2011-04-06 14:42:44 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-06 14:42:44 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-06 14:42:44 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-06 14:42:44 --> Model Class Initialized
DEBUG - 2011-04-06 14:42:44 --> Model Class Initialized
DEBUG - 2011-04-06 14:42:44 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-06 14:42:44 --> Database Driver Class Initialized
DEBUG - 2011-04-06 14:42:44 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-06 14:42:44 --> Helper loaded: url_helper
DEBUG - 2011-04-06 14:42:44 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-06 14:42:44 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-06 14:42:44 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-06 14:42:44 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-06 14:42:44 --> Final output sent to browser
DEBUG - 2011-04-06 14:42:44 --> Total execution time: 0.0287
DEBUG - 2011-04-06 14:42:44 --> Config Class Initialized
DEBUG - 2011-04-06 14:42:44 --> Hooks Class Initialized
DEBUG - 2011-04-06 14:42:44 --> Utf8 Class Initialized
DEBUG - 2011-04-06 14:42:44 --> UTF-8 Support Enabled
DEBUG - 2011-04-06 14:42:44 --> URI Class Initialized
DEBUG - 2011-04-06 14:42:44 --> Router Class Initialized
DEBUG - 2011-04-06 14:42:44 --> Output Class Initialized
DEBUG - 2011-04-06 14:42:44 --> Input Class Initialized
DEBUG - 2011-04-06 14:42:44 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-06 14:42:44 --> Language Class Initialized
DEBUG - 2011-04-06 14:42:44 --> Loader Class Initialized
DEBUG - 2011-04-06 14:42:44 --> Controller Class Initialized
DEBUG - 2011-04-06 14:42:44 --> Model Class Initialized
DEBUG - 2011-04-06 14:42:44 --> Model Class Initialized
DEBUG - 2011-04-06 14:42:44 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-06 14:42:44 --> Database Driver Class Initialized
DEBUG - 2011-04-06 14:42:45 --> Final output sent to browser
DEBUG - 2011-04-06 14:42:45 --> Total execution time: 0.8003
DEBUG - 2011-04-06 15:04:35 --> Config Class Initialized
DEBUG - 2011-04-06 15:04:35 --> Hooks Class Initialized
DEBUG - 2011-04-06 15:04:35 --> Utf8 Class Initialized
DEBUG - 2011-04-06 15:04:35 --> UTF-8 Support Enabled
DEBUG - 2011-04-06 15:04:35 --> URI Class Initialized
DEBUG - 2011-04-06 15:04:35 --> Router Class Initialized
DEBUG - 2011-04-06 15:04:35 --> No URI present. Default controller set.
DEBUG - 2011-04-06 15:04:35 --> Output Class Initialized
DEBUG - 2011-04-06 15:04:35 --> Input Class Initialized
DEBUG - 2011-04-06 15:04:35 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-06 15:04:35 --> Language Class Initialized
DEBUG - 2011-04-06 15:04:35 --> Loader Class Initialized
DEBUG - 2011-04-06 15:04:35 --> Controller Class Initialized
DEBUG - 2011-04-06 15:04:35 --> File loaded: application/views/splash/main.php
DEBUG - 2011-04-06 15:04:35 --> Helper loaded: url_helper
DEBUG - 2011-04-06 15:04:35 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-06 15:04:35 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-06 15:04:35 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-06 15:04:35 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-06 15:04:35 --> Final output sent to browser
DEBUG - 2011-04-06 15:04:35 --> Total execution time: 0.1200
DEBUG - 2011-04-06 15:04:38 --> Config Class Initialized
DEBUG - 2011-04-06 15:04:38 --> Hooks Class Initialized
DEBUG - 2011-04-06 15:04:38 --> Utf8 Class Initialized
DEBUG - 2011-04-06 15:04:38 --> UTF-8 Support Enabled
DEBUG - 2011-04-06 15:04:38 --> URI Class Initialized
DEBUG - 2011-04-06 15:04:38 --> Router Class Initialized
ERROR - 2011-04-06 15:04:38 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-06 15:04:40 --> Config Class Initialized
DEBUG - 2011-04-06 15:04:40 --> Hooks Class Initialized
DEBUG - 2011-04-06 15:04:40 --> Utf8 Class Initialized
DEBUG - 2011-04-06 15:04:40 --> UTF-8 Support Enabled
DEBUG - 2011-04-06 15:04:40 --> URI Class Initialized
DEBUG - 2011-04-06 15:04:40 --> Router Class Initialized
ERROR - 2011-04-06 15:04:40 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-06 15:05:42 --> Config Class Initialized
DEBUG - 2011-04-06 15:05:42 --> Hooks Class Initialized
DEBUG - 2011-04-06 15:05:42 --> Utf8 Class Initialized
DEBUG - 2011-04-06 15:05:42 --> UTF-8 Support Enabled
DEBUG - 2011-04-06 15:05:42 --> URI Class Initialized
DEBUG - 2011-04-06 15:05:42 --> Router Class Initialized
DEBUG - 2011-04-06 15:05:42 --> Output Class Initialized
DEBUG - 2011-04-06 15:05:42 --> Input Class Initialized
DEBUG - 2011-04-06 15:05:42 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-06 15:05:42 --> Language Class Initialized
DEBUG - 2011-04-06 15:05:42 --> Loader Class Initialized
DEBUG - 2011-04-06 15:05:42 --> Controller Class Initialized
DEBUG - 2011-04-06 15:05:42 --> Model Class Initialized
DEBUG - 2011-04-06 15:05:42 --> Model Class Initialized
DEBUG - 2011-04-06 15:05:42 --> Model Class Initialized
DEBUG - 2011-04-06 15:05:42 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-06 15:05:42 --> Database Driver Class Initialized
DEBUG - 2011-04-06 15:05:42 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-06 15:05:42 --> Helper loaded: url_helper
DEBUG - 2011-04-06 15:05:42 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-06 15:05:42 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-06 15:05:42 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-06 15:05:42 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-06 15:05:42 --> Final output sent to browser
DEBUG - 2011-04-06 15:05:42 --> Total execution time: 0.3031
DEBUG - 2011-04-06 15:06:08 --> Config Class Initialized
DEBUG - 2011-04-06 15:06:08 --> Hooks Class Initialized
DEBUG - 2011-04-06 15:06:08 --> Utf8 Class Initialized
DEBUG - 2011-04-06 15:06:08 --> UTF-8 Support Enabled
DEBUG - 2011-04-06 15:06:08 --> URI Class Initialized
DEBUG - 2011-04-06 15:06:08 --> Router Class Initialized
DEBUG - 2011-04-06 15:06:08 --> Output Class Initialized
DEBUG - 2011-04-06 15:06:08 --> Input Class Initialized
DEBUG - 2011-04-06 15:06:08 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-06 15:06:08 --> Language Class Initialized
DEBUG - 2011-04-06 15:06:08 --> Loader Class Initialized
DEBUG - 2011-04-06 15:06:08 --> Controller Class Initialized
DEBUG - 2011-04-06 15:06:08 --> Model Class Initialized
DEBUG - 2011-04-06 15:06:08 --> Model Class Initialized
DEBUG - 2011-04-06 15:06:08 --> Model Class Initialized
DEBUG - 2011-04-06 15:06:08 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-06 15:06:08 --> Database Driver Class Initialized
DEBUG - 2011-04-06 15:06:08 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-06 15:06:08 --> Helper loaded: url_helper
DEBUG - 2011-04-06 15:06:08 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-06 15:06:08 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-06 15:06:08 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-06 15:06:08 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-06 15:06:08 --> Final output sent to browser
DEBUG - 2011-04-06 15:06:08 --> Total execution time: 0.1712
DEBUG - 2011-04-06 15:06:10 --> Config Class Initialized
DEBUG - 2011-04-06 15:06:10 --> Hooks Class Initialized
DEBUG - 2011-04-06 15:06:10 --> Utf8 Class Initialized
DEBUG - 2011-04-06 15:06:10 --> UTF-8 Support Enabled
DEBUG - 2011-04-06 15:06:10 --> URI Class Initialized
DEBUG - 2011-04-06 15:06:10 --> Router Class Initialized
ERROR - 2011-04-06 15:06:10 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-04-06 15:06:11 --> Config Class Initialized
DEBUG - 2011-04-06 15:06:11 --> Hooks Class Initialized
DEBUG - 2011-04-06 15:06:11 --> Utf8 Class Initialized
DEBUG - 2011-04-06 15:06:11 --> UTF-8 Support Enabled
DEBUG - 2011-04-06 15:06:11 --> URI Class Initialized
DEBUG - 2011-04-06 15:06:11 --> Router Class Initialized
DEBUG - 2011-04-06 15:06:11 --> Output Class Initialized
DEBUG - 2011-04-06 15:06:11 --> Input Class Initialized
DEBUG - 2011-04-06 15:06:11 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-06 15:06:11 --> Language Class Initialized
DEBUG - 2011-04-06 15:06:11 --> Loader Class Initialized
DEBUG - 2011-04-06 15:06:11 --> Controller Class Initialized
DEBUG - 2011-04-06 15:06:11 --> Model Class Initialized
DEBUG - 2011-04-06 15:06:11 --> Model Class Initialized
DEBUG - 2011-04-06 15:06:11 --> Model Class Initialized
DEBUG - 2011-04-06 15:06:11 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-06 15:06:11 --> Database Driver Class Initialized
DEBUG - 2011-04-06 15:06:11 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-06 15:06:11 --> Helper loaded: url_helper
DEBUG - 2011-04-06 15:06:11 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-06 15:06:11 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-06 15:06:11 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-06 15:06:11 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-06 15:06:11 --> Final output sent to browser
DEBUG - 2011-04-06 15:06:11 --> Total execution time: 0.0574
DEBUG - 2011-04-06 15:06:21 --> Config Class Initialized
DEBUG - 2011-04-06 15:06:21 --> Hooks Class Initialized
DEBUG - 2011-04-06 15:06:21 --> Utf8 Class Initialized
DEBUG - 2011-04-06 15:06:21 --> UTF-8 Support Enabled
DEBUG - 2011-04-06 15:06:21 --> URI Class Initialized
DEBUG - 2011-04-06 15:06:21 --> Router Class Initialized
DEBUG - 2011-04-06 15:06:22 --> Output Class Initialized
DEBUG - 2011-04-06 15:06:22 --> Input Class Initialized
DEBUG - 2011-04-06 15:06:22 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-06 15:06:22 --> Language Class Initialized
DEBUG - 2011-04-06 15:06:22 --> Loader Class Initialized
DEBUG - 2011-04-06 15:06:22 --> Controller Class Initialized
DEBUG - 2011-04-06 15:06:22 --> Model Class Initialized
DEBUG - 2011-04-06 15:06:22 --> Model Class Initialized
DEBUG - 2011-04-06 15:06:22 --> Model Class Initialized
DEBUG - 2011-04-06 15:06:22 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-06 15:06:22 --> Database Driver Class Initialized
DEBUG - 2011-04-06 15:06:23 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-06 15:06:23 --> Helper loaded: url_helper
DEBUG - 2011-04-06 15:06:23 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-06 15:06:23 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-06 15:06:23 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-06 15:06:23 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-06 15:06:23 --> Final output sent to browser
DEBUG - 2011-04-06 15:06:23 --> Total execution time: 1.9877
DEBUG - 2011-04-06 15:06:25 --> Config Class Initialized
DEBUG - 2011-04-06 15:06:25 --> Hooks Class Initialized
DEBUG - 2011-04-06 15:06:25 --> Utf8 Class Initialized
DEBUG - 2011-04-06 15:06:25 --> UTF-8 Support Enabled
DEBUG - 2011-04-06 15:06:25 --> URI Class Initialized
DEBUG - 2011-04-06 15:06:25 --> Router Class Initialized
DEBUG - 2011-04-06 15:06:25 --> Output Class Initialized
DEBUG - 2011-04-06 15:06:25 --> Input Class Initialized
DEBUG - 2011-04-06 15:06:25 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-06 15:06:25 --> Language Class Initialized
DEBUG - 2011-04-06 15:06:25 --> Loader Class Initialized
DEBUG - 2011-04-06 15:06:25 --> Controller Class Initialized
DEBUG - 2011-04-06 15:06:25 --> Model Class Initialized
DEBUG - 2011-04-06 15:06:25 --> Model Class Initialized
DEBUG - 2011-04-06 15:06:25 --> Model Class Initialized
DEBUG - 2011-04-06 15:06:25 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-06 15:06:25 --> Database Driver Class Initialized
DEBUG - 2011-04-06 15:06:25 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-06 15:06:25 --> Helper loaded: url_helper
DEBUG - 2011-04-06 15:06:25 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-06 15:06:25 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-06 15:06:25 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-06 15:06:25 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-06 15:06:25 --> Final output sent to browser
DEBUG - 2011-04-06 15:06:25 --> Total execution time: 0.0458
DEBUG - 2011-04-06 15:06:53 --> Config Class Initialized
DEBUG - 2011-04-06 15:06:53 --> Hooks Class Initialized
DEBUG - 2011-04-06 15:06:53 --> Utf8 Class Initialized
DEBUG - 2011-04-06 15:06:53 --> UTF-8 Support Enabled
DEBUG - 2011-04-06 15:06:53 --> URI Class Initialized
DEBUG - 2011-04-06 15:06:53 --> Router Class Initialized
DEBUG - 2011-04-06 15:06:53 --> Output Class Initialized
DEBUG - 2011-04-06 15:06:53 --> Input Class Initialized
DEBUG - 2011-04-06 15:06:53 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-06 15:06:53 --> Language Class Initialized
DEBUG - 2011-04-06 15:06:53 --> Loader Class Initialized
DEBUG - 2011-04-06 15:06:53 --> Controller Class Initialized
DEBUG - 2011-04-06 15:06:53 --> Model Class Initialized
DEBUG - 2011-04-06 15:06:54 --> Model Class Initialized
DEBUG - 2011-04-06 15:06:54 --> Model Class Initialized
DEBUG - 2011-04-06 15:06:54 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-06 15:06:54 --> Database Driver Class Initialized
DEBUG - 2011-04-06 15:06:54 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-06 15:06:54 --> Helper loaded: url_helper
DEBUG - 2011-04-06 15:06:54 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-06 15:06:54 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-06 15:06:54 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-06 15:06:54 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-06 15:06:54 --> Final output sent to browser
DEBUG - 2011-04-06 15:06:54 --> Total execution time: 0.2152
DEBUG - 2011-04-06 15:07:06 --> Config Class Initialized
DEBUG - 2011-04-06 15:07:06 --> Hooks Class Initialized
DEBUG - 2011-04-06 15:07:06 --> Utf8 Class Initialized
DEBUG - 2011-04-06 15:07:06 --> UTF-8 Support Enabled
DEBUG - 2011-04-06 15:07:06 --> URI Class Initialized
DEBUG - 2011-04-06 15:07:06 --> Router Class Initialized
DEBUG - 2011-04-06 15:07:06 --> Output Class Initialized
DEBUG - 2011-04-06 15:07:06 --> Input Class Initialized
DEBUG - 2011-04-06 15:07:06 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-06 15:07:06 --> Language Class Initialized
DEBUG - 2011-04-06 15:07:06 --> Loader Class Initialized
DEBUG - 2011-04-06 15:07:06 --> Controller Class Initialized
DEBUG - 2011-04-06 15:07:06 --> Model Class Initialized
DEBUG - 2011-04-06 15:07:06 --> Model Class Initialized
DEBUG - 2011-04-06 15:07:06 --> Model Class Initialized
DEBUG - 2011-04-06 15:07:06 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-06 15:07:06 --> Database Driver Class Initialized
DEBUG - 2011-04-06 15:07:06 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-06 15:07:06 --> Helper loaded: url_helper
DEBUG - 2011-04-06 15:07:06 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-06 15:07:06 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-06 15:07:06 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-06 15:07:06 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-06 15:07:06 --> Final output sent to browser
DEBUG - 2011-04-06 15:07:06 --> Total execution time: 0.0446
DEBUG - 2011-04-06 15:18:11 --> Config Class Initialized
DEBUG - 2011-04-06 15:18:11 --> Hooks Class Initialized
DEBUG - 2011-04-06 15:18:11 --> Utf8 Class Initialized
DEBUG - 2011-04-06 15:18:11 --> UTF-8 Support Enabled
DEBUG - 2011-04-06 15:18:11 --> URI Class Initialized
DEBUG - 2011-04-06 15:18:11 --> Router Class Initialized
DEBUG - 2011-04-06 15:18:11 --> Output Class Initialized
DEBUG - 2011-04-06 15:18:11 --> Input Class Initialized
DEBUG - 2011-04-06 15:18:11 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-06 15:18:11 --> Language Class Initialized
DEBUG - 2011-04-06 15:18:11 --> Loader Class Initialized
DEBUG - 2011-04-06 15:18:11 --> Controller Class Initialized
ERROR - 2011-04-06 15:18:11 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-06 15:18:11 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-06 15:18:11 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-06 15:18:11 --> Model Class Initialized
DEBUG - 2011-04-06 15:18:11 --> Model Class Initialized
DEBUG - 2011-04-06 15:18:11 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-06 15:18:11 --> Database Driver Class Initialized
DEBUG - 2011-04-06 15:18:11 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-06 15:18:11 --> Helper loaded: url_helper
DEBUG - 2011-04-06 15:18:11 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-06 15:18:11 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-06 15:18:11 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-06 15:18:11 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-06 15:18:11 --> Final output sent to browser
DEBUG - 2011-04-06 15:18:11 --> Total execution time: 0.1522
DEBUG - 2011-04-06 15:18:11 --> Config Class Initialized
DEBUG - 2011-04-06 15:18:11 --> Hooks Class Initialized
DEBUG - 2011-04-06 15:18:11 --> Utf8 Class Initialized
DEBUG - 2011-04-06 15:18:11 --> UTF-8 Support Enabled
DEBUG - 2011-04-06 15:18:11 --> URI Class Initialized
DEBUG - 2011-04-06 15:18:11 --> Router Class Initialized
DEBUG - 2011-04-06 15:18:11 --> Output Class Initialized
DEBUG - 2011-04-06 15:18:11 --> Input Class Initialized
DEBUG - 2011-04-06 15:18:11 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-06 15:18:11 --> Language Class Initialized
DEBUG - 2011-04-06 15:18:11 --> Loader Class Initialized
DEBUG - 2011-04-06 15:18:11 --> Controller Class Initialized
DEBUG - 2011-04-06 15:18:11 --> Model Class Initialized
DEBUG - 2011-04-06 15:18:11 --> Model Class Initialized
DEBUG - 2011-04-06 15:18:11 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-06 15:18:11 --> Database Driver Class Initialized
DEBUG - 2011-04-06 15:18:12 --> Final output sent to browser
DEBUG - 2011-04-06 15:18:12 --> Total execution time: 0.8705
DEBUG - 2011-04-06 15:18:13 --> Config Class Initialized
DEBUG - 2011-04-06 15:18:13 --> Hooks Class Initialized
DEBUG - 2011-04-06 15:18:13 --> Utf8 Class Initialized
DEBUG - 2011-04-06 15:18:13 --> UTF-8 Support Enabled
DEBUG - 2011-04-06 15:18:13 --> URI Class Initialized
DEBUG - 2011-04-06 15:18:13 --> Router Class Initialized
ERROR - 2011-04-06 15:18:13 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-06 15:26:02 --> Config Class Initialized
DEBUG - 2011-04-06 15:26:02 --> Hooks Class Initialized
DEBUG - 2011-04-06 15:26:02 --> Utf8 Class Initialized
DEBUG - 2011-04-06 15:26:02 --> UTF-8 Support Enabled
DEBUG - 2011-04-06 15:26:02 --> URI Class Initialized
DEBUG - 2011-04-06 15:26:02 --> Router Class Initialized
DEBUG - 2011-04-06 15:26:02 --> Output Class Initialized
DEBUG - 2011-04-06 15:26:02 --> Input Class Initialized
DEBUG - 2011-04-06 15:26:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-06 15:26:02 --> Language Class Initialized
DEBUG - 2011-04-06 15:26:02 --> Loader Class Initialized
DEBUG - 2011-04-06 15:26:02 --> Controller Class Initialized
ERROR - 2011-04-06 15:26:02 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-06 15:26:02 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-06 15:26:02 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-06 15:26:02 --> Model Class Initialized
DEBUG - 2011-04-06 15:26:02 --> Model Class Initialized
DEBUG - 2011-04-06 15:26:02 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-06 15:26:02 --> Database Driver Class Initialized
DEBUG - 2011-04-06 15:26:02 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-06 15:26:02 --> Helper loaded: url_helper
DEBUG - 2011-04-06 15:26:02 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-06 15:26:02 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-06 15:26:02 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-06 15:26:02 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-06 15:26:02 --> Final output sent to browser
DEBUG - 2011-04-06 15:26:02 --> Total execution time: 0.1914
DEBUG - 2011-04-06 15:26:03 --> Config Class Initialized
DEBUG - 2011-04-06 15:26:03 --> Hooks Class Initialized
DEBUG - 2011-04-06 15:26:03 --> Utf8 Class Initialized
DEBUG - 2011-04-06 15:26:03 --> UTF-8 Support Enabled
DEBUG - 2011-04-06 15:26:03 --> URI Class Initialized
DEBUG - 2011-04-06 15:26:03 --> Router Class Initialized
DEBUG - 2011-04-06 15:26:03 --> Output Class Initialized
DEBUG - 2011-04-06 15:26:03 --> Input Class Initialized
DEBUG - 2011-04-06 15:26:03 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-06 15:26:03 --> Language Class Initialized
DEBUG - 2011-04-06 15:26:03 --> Loader Class Initialized
DEBUG - 2011-04-06 15:26:03 --> Controller Class Initialized
DEBUG - 2011-04-06 15:26:03 --> Model Class Initialized
DEBUG - 2011-04-06 15:26:03 --> Model Class Initialized
DEBUG - 2011-04-06 15:26:03 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-06 15:26:03 --> Database Driver Class Initialized
DEBUG - 2011-04-06 15:26:05 --> Final output sent to browser
DEBUG - 2011-04-06 15:26:05 --> Total execution time: 2.0684
DEBUG - 2011-04-06 15:26:06 --> Config Class Initialized
DEBUG - 2011-04-06 15:26:06 --> Hooks Class Initialized
DEBUG - 2011-04-06 15:26:06 --> Utf8 Class Initialized
DEBUG - 2011-04-06 15:26:06 --> UTF-8 Support Enabled
DEBUG - 2011-04-06 15:26:06 --> URI Class Initialized
DEBUG - 2011-04-06 15:26:06 --> Router Class Initialized
ERROR - 2011-04-06 15:26:06 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-06 15:26:07 --> Config Class Initialized
DEBUG - 2011-04-06 15:26:07 --> Hooks Class Initialized
DEBUG - 2011-04-06 15:26:07 --> Utf8 Class Initialized
DEBUG - 2011-04-06 15:26:07 --> UTF-8 Support Enabled
DEBUG - 2011-04-06 15:26:07 --> URI Class Initialized
DEBUG - 2011-04-06 15:26:07 --> Router Class Initialized
ERROR - 2011-04-06 15:26:07 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-06 17:20:16 --> Config Class Initialized
DEBUG - 2011-04-06 17:20:16 --> Hooks Class Initialized
DEBUG - 2011-04-06 17:20:16 --> Utf8 Class Initialized
DEBUG - 2011-04-06 17:20:16 --> UTF-8 Support Enabled
DEBUG - 2011-04-06 17:20:16 --> URI Class Initialized
DEBUG - 2011-04-06 17:20:16 --> Router Class Initialized
DEBUG - 2011-04-06 17:20:16 --> No URI present. Default controller set.
DEBUG - 2011-04-06 17:20:16 --> Output Class Initialized
DEBUG - 2011-04-06 17:20:16 --> Input Class Initialized
DEBUG - 2011-04-06 17:20:16 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-06 17:20:16 --> Language Class Initialized
DEBUG - 2011-04-06 17:20:16 --> Loader Class Initialized
DEBUG - 2011-04-06 17:20:16 --> Controller Class Initialized
DEBUG - 2011-04-06 17:20:16 --> File loaded: application/views/splash/main.php
DEBUG - 2011-04-06 17:20:16 --> Helper loaded: url_helper
DEBUG - 2011-04-06 17:20:16 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-06 17:20:16 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-06 17:20:16 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-06 17:20:16 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-06 17:20:16 --> Final output sent to browser
DEBUG - 2011-04-06 17:20:16 --> Total execution time: 0.2521
DEBUG - 2011-04-06 18:10:03 --> Config Class Initialized
DEBUG - 2011-04-06 18:10:03 --> Hooks Class Initialized
DEBUG - 2011-04-06 18:10:03 --> Utf8 Class Initialized
DEBUG - 2011-04-06 18:10:03 --> UTF-8 Support Enabled
DEBUG - 2011-04-06 18:10:03 --> URI Class Initialized
DEBUG - 2011-04-06 18:10:03 --> Router Class Initialized
DEBUG - 2011-04-06 18:10:03 --> Output Class Initialized
DEBUG - 2011-04-06 18:10:03 --> Input Class Initialized
DEBUG - 2011-04-06 18:10:03 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-06 18:10:03 --> Language Class Initialized
DEBUG - 2011-04-06 18:10:03 --> Loader Class Initialized
DEBUG - 2011-04-06 18:10:03 --> Controller Class Initialized
ERROR - 2011-04-06 18:10:03 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-06 18:10:03 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-06 18:10:03 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-06 18:10:03 --> Model Class Initialized
DEBUG - 2011-04-06 18:10:03 --> Model Class Initialized
DEBUG - 2011-04-06 18:10:03 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-06 18:10:03 --> Database Driver Class Initialized
DEBUG - 2011-04-06 18:10:03 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-06 18:10:03 --> Helper loaded: url_helper
DEBUG - 2011-04-06 18:10:03 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-06 18:10:03 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-06 18:10:03 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-06 18:10:03 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-06 18:10:03 --> Final output sent to browser
DEBUG - 2011-04-06 18:10:03 --> Total execution time: 0.2986
DEBUG - 2011-04-06 18:10:04 --> Config Class Initialized
DEBUG - 2011-04-06 18:10:04 --> Hooks Class Initialized
DEBUG - 2011-04-06 18:10:04 --> Utf8 Class Initialized
DEBUG - 2011-04-06 18:10:04 --> UTF-8 Support Enabled
DEBUG - 2011-04-06 18:10:04 --> URI Class Initialized
DEBUG - 2011-04-06 18:10:04 --> Router Class Initialized
DEBUG - 2011-04-06 18:10:04 --> Output Class Initialized
DEBUG - 2011-04-06 18:10:04 --> Input Class Initialized
DEBUG - 2011-04-06 18:10:04 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-06 18:10:04 --> Language Class Initialized
DEBUG - 2011-04-06 18:10:04 --> Loader Class Initialized
DEBUG - 2011-04-06 18:10:04 --> Controller Class Initialized
DEBUG - 2011-04-06 18:10:04 --> Model Class Initialized
DEBUG - 2011-04-06 18:10:04 --> Model Class Initialized
DEBUG - 2011-04-06 18:10:04 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-06 18:10:04 --> Database Driver Class Initialized
DEBUG - 2011-04-06 18:10:05 --> Final output sent to browser
DEBUG - 2011-04-06 18:10:05 --> Total execution time: 0.7067
DEBUG - 2011-04-06 18:10:05 --> Config Class Initialized
DEBUG - 2011-04-06 18:10:05 --> Hooks Class Initialized
DEBUG - 2011-04-06 18:10:05 --> Utf8 Class Initialized
DEBUG - 2011-04-06 18:10:05 --> UTF-8 Support Enabled
DEBUG - 2011-04-06 18:10:05 --> URI Class Initialized
DEBUG - 2011-04-06 18:10:05 --> Router Class Initialized
ERROR - 2011-04-06 18:10:05 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-06 19:38:08 --> Config Class Initialized
DEBUG - 2011-04-06 19:38:08 --> Hooks Class Initialized
DEBUG - 2011-04-06 19:38:08 --> Utf8 Class Initialized
DEBUG - 2011-04-06 19:38:08 --> UTF-8 Support Enabled
DEBUG - 2011-04-06 19:38:08 --> URI Class Initialized
DEBUG - 2011-04-06 19:38:08 --> Router Class Initialized
DEBUG - 2011-04-06 19:38:08 --> Output Class Initialized
DEBUG - 2011-04-06 19:38:08 --> Input Class Initialized
DEBUG - 2011-04-06 19:38:08 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-06 19:38:08 --> Language Class Initialized
DEBUG - 2011-04-06 19:38:08 --> Loader Class Initialized
DEBUG - 2011-04-06 19:38:08 --> Controller Class Initialized
ERROR - 2011-04-06 19:38:08 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-06 19:38:08 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-06 19:38:08 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-06 19:38:08 --> Model Class Initialized
DEBUG - 2011-04-06 19:38:08 --> Model Class Initialized
DEBUG - 2011-04-06 19:38:08 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-06 19:38:08 --> Database Driver Class Initialized
DEBUG - 2011-04-06 19:38:08 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-06 19:38:08 --> Helper loaded: url_helper
DEBUG - 2011-04-06 19:38:08 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-06 19:38:08 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-06 19:38:08 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-06 19:38:08 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-06 19:38:08 --> Final output sent to browser
DEBUG - 2011-04-06 19:38:08 --> Total execution time: 0.3281
DEBUG - 2011-04-06 20:00:22 --> Config Class Initialized
DEBUG - 2011-04-06 20:00:22 --> Hooks Class Initialized
DEBUG - 2011-04-06 20:00:22 --> Utf8 Class Initialized
DEBUG - 2011-04-06 20:00:22 --> UTF-8 Support Enabled
DEBUG - 2011-04-06 20:00:22 --> URI Class Initialized
DEBUG - 2011-04-06 20:00:22 --> Router Class Initialized
DEBUG - 2011-04-06 20:00:22 --> Output Class Initialized
DEBUG - 2011-04-06 20:00:22 --> Input Class Initialized
DEBUG - 2011-04-06 20:00:22 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-06 20:00:22 --> Language Class Initialized
DEBUG - 2011-04-06 20:00:22 --> Loader Class Initialized
DEBUG - 2011-04-06 20:00:22 --> Controller Class Initialized
ERROR - 2011-04-06 20:00:22 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-06 20:00:22 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-06 20:00:22 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-06 20:00:22 --> Model Class Initialized
DEBUG - 2011-04-06 20:00:22 --> Model Class Initialized
DEBUG - 2011-04-06 20:00:22 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-06 20:00:22 --> Database Driver Class Initialized
DEBUG - 2011-04-06 20:00:22 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-06 20:00:22 --> Helper loaded: url_helper
DEBUG - 2011-04-06 20:00:22 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-06 20:00:22 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-06 20:00:22 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-06 20:00:22 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-06 20:00:22 --> Final output sent to browser
DEBUG - 2011-04-06 20:00:22 --> Total execution time: 0.1671
DEBUG - 2011-04-06 21:45:49 --> Config Class Initialized
DEBUG - 2011-04-06 21:45:49 --> Hooks Class Initialized
DEBUG - 2011-04-06 21:45:49 --> Utf8 Class Initialized
DEBUG - 2011-04-06 21:45:49 --> UTF-8 Support Enabled
DEBUG - 2011-04-06 21:45:49 --> URI Class Initialized
DEBUG - 2011-04-06 21:45:49 --> Router Class Initialized
DEBUG - 2011-04-06 21:45:49 --> Output Class Initialized
DEBUG - 2011-04-06 21:45:49 --> Input Class Initialized
DEBUG - 2011-04-06 21:45:49 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-06 21:45:49 --> Language Class Initialized
DEBUG - 2011-04-06 21:45:49 --> Loader Class Initialized
DEBUG - 2011-04-06 21:45:49 --> Controller Class Initialized
ERROR - 2011-04-06 21:45:49 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-06 21:45:49 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-06 21:45:49 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-06 21:45:49 --> Model Class Initialized
DEBUG - 2011-04-06 21:45:49 --> Model Class Initialized
DEBUG - 2011-04-06 21:45:49 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-06 21:45:49 --> Database Driver Class Initialized
DEBUG - 2011-04-06 21:45:49 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-06 21:45:49 --> Helper loaded: url_helper
DEBUG - 2011-04-06 21:45:49 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-06 21:45:49 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-06 21:45:49 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-06 21:45:49 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-06 21:45:49 --> Final output sent to browser
DEBUG - 2011-04-06 21:45:49 --> Total execution time: 0.3414
DEBUG - 2011-04-06 21:45:49 --> Config Class Initialized
DEBUG - 2011-04-06 21:45:49 --> Hooks Class Initialized
DEBUG - 2011-04-06 21:45:49 --> Utf8 Class Initialized
DEBUG - 2011-04-06 21:45:49 --> UTF-8 Support Enabled
DEBUG - 2011-04-06 21:45:49 --> URI Class Initialized
DEBUG - 2011-04-06 21:45:49 --> Router Class Initialized
DEBUG - 2011-04-06 21:45:49 --> Output Class Initialized
DEBUG - 2011-04-06 21:45:49 --> Input Class Initialized
DEBUG - 2011-04-06 21:45:49 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-06 21:45:49 --> Language Class Initialized
DEBUG - 2011-04-06 21:45:49 --> Loader Class Initialized
DEBUG - 2011-04-06 21:45:49 --> Controller Class Initialized
DEBUG - 2011-04-06 21:45:49 --> Model Class Initialized
DEBUG - 2011-04-06 21:45:49 --> Model Class Initialized
DEBUG - 2011-04-06 21:45:49 --> Model Class Initialized
DEBUG - 2011-04-06 21:45:49 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-06 21:45:49 --> Database Driver Class Initialized
DEBUG - 2011-04-06 21:45:50 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-06 21:45:50 --> Helper loaded: url_helper
DEBUG - 2011-04-06 21:45:50 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-06 21:45:50 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-06 21:45:50 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-06 21:45:50 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-06 21:45:50 --> Final output sent to browser
DEBUG - 2011-04-06 21:45:50 --> Total execution time: 0.2641
DEBUG - 2011-04-06 21:45:51 --> Config Class Initialized
DEBUG - 2011-04-06 21:45:51 --> Hooks Class Initialized
DEBUG - 2011-04-06 21:45:51 --> Utf8 Class Initialized
DEBUG - 2011-04-06 21:45:51 --> UTF-8 Support Enabled
DEBUG - 2011-04-06 21:45:51 --> URI Class Initialized
DEBUG - 2011-04-06 21:45:51 --> Config Class Initialized
DEBUG - 2011-04-06 21:45:51 --> Hooks Class Initialized
DEBUG - 2011-04-06 21:45:51 --> Utf8 Class Initialized
DEBUG - 2011-04-06 21:45:51 --> UTF-8 Support Enabled
DEBUG - 2011-04-06 21:45:51 --> Router Class Initialized
ERROR - 2011-04-06 21:45:51 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-06 21:45:51 --> URI Class Initialized
DEBUG - 2011-04-06 21:45:51 --> Router Class Initialized
DEBUG - 2011-04-06 21:45:51 --> Output Class Initialized
DEBUG - 2011-04-06 21:45:51 --> Input Class Initialized
DEBUG - 2011-04-06 21:45:51 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-06 21:45:51 --> Language Class Initialized
DEBUG - 2011-04-06 21:45:51 --> Loader Class Initialized
DEBUG - 2011-04-06 21:45:51 --> Controller Class Initialized
DEBUG - 2011-04-06 21:45:51 --> Model Class Initialized
DEBUG - 2011-04-06 21:45:51 --> Model Class Initialized
DEBUG - 2011-04-06 21:45:51 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-06 21:45:51 --> Database Driver Class Initialized
DEBUG - 2011-04-06 21:45:51 --> Config Class Initialized
DEBUG - 2011-04-06 21:45:51 --> Hooks Class Initialized
DEBUG - 2011-04-06 21:45:51 --> Utf8 Class Initialized
DEBUG - 2011-04-06 21:45:51 --> UTF-8 Support Enabled
DEBUG - 2011-04-06 21:45:51 --> URI Class Initialized
DEBUG - 2011-04-06 21:45:51 --> Router Class Initialized
ERROR - 2011-04-06 21:45:51 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-06 21:45:52 --> Config Class Initialized
DEBUG - 2011-04-06 21:45:52 --> Hooks Class Initialized
DEBUG - 2011-04-06 21:45:52 --> Utf8 Class Initialized
DEBUG - 2011-04-06 21:45:52 --> UTF-8 Support Enabled
DEBUG - 2011-04-06 21:45:52 --> URI Class Initialized
DEBUG - 2011-04-06 21:45:52 --> Router Class Initialized
ERROR - 2011-04-06 21:45:52 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-06 21:45:53 --> Final output sent to browser
DEBUG - 2011-04-06 21:45:53 --> Total execution time: 2.6918
DEBUG - 2011-04-06 21:45:54 --> Config Class Initialized
DEBUG - 2011-04-06 21:45:54 --> Hooks Class Initialized
DEBUG - 2011-04-06 21:45:54 --> Utf8 Class Initialized
DEBUG - 2011-04-06 21:45:54 --> UTF-8 Support Enabled
DEBUG - 2011-04-06 21:45:54 --> URI Class Initialized
DEBUG - 2011-04-06 21:45:54 --> Router Class Initialized
ERROR - 2011-04-06 21:45:54 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-06 21:45:55 --> Config Class Initialized
DEBUG - 2011-04-06 21:45:55 --> Hooks Class Initialized
DEBUG - 2011-04-06 21:45:55 --> Utf8 Class Initialized
DEBUG - 2011-04-06 21:45:55 --> UTF-8 Support Enabled
DEBUG - 2011-04-06 21:45:55 --> URI Class Initialized
DEBUG - 2011-04-06 21:45:55 --> Router Class Initialized
ERROR - 2011-04-06 21:45:55 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-06 21:46:15 --> Config Class Initialized
DEBUG - 2011-04-06 21:46:15 --> Hooks Class Initialized
DEBUG - 2011-04-06 21:46:15 --> Utf8 Class Initialized
DEBUG - 2011-04-06 21:46:15 --> UTF-8 Support Enabled
DEBUG - 2011-04-06 21:46:15 --> URI Class Initialized
DEBUG - 2011-04-06 21:46:15 --> Router Class Initialized
DEBUG - 2011-04-06 21:46:15 --> No URI present. Default controller set.
DEBUG - 2011-04-06 21:46:15 --> Output Class Initialized
DEBUG - 2011-04-06 21:46:15 --> Input Class Initialized
DEBUG - 2011-04-06 21:46:15 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-06 21:46:15 --> Language Class Initialized
DEBUG - 2011-04-06 21:46:15 --> Loader Class Initialized
DEBUG - 2011-04-06 21:46:15 --> Controller Class Initialized
DEBUG - 2011-04-06 21:46:16 --> File loaded: application/views/splash/main.php
DEBUG - 2011-04-06 21:46:16 --> Helper loaded: url_helper
DEBUG - 2011-04-06 21:46:16 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-06 21:46:16 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-06 21:46:16 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-06 21:46:16 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-06 21:46:16 --> Final output sent to browser
DEBUG - 2011-04-06 21:46:16 --> Total execution time: 0.1852
DEBUG - 2011-04-06 21:46:18 --> Config Class Initialized
DEBUG - 2011-04-06 21:46:18 --> Hooks Class Initialized
DEBUG - 2011-04-06 21:46:18 --> Utf8 Class Initialized
DEBUG - 2011-04-06 21:46:18 --> UTF-8 Support Enabled
DEBUG - 2011-04-06 21:46:18 --> URI Class Initialized
DEBUG - 2011-04-06 21:46:18 --> Router Class Initialized
ERROR - 2011-04-06 21:46:18 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-06 21:48:01 --> Config Class Initialized
DEBUG - 2011-04-06 21:48:01 --> Hooks Class Initialized
DEBUG - 2011-04-06 21:48:01 --> Utf8 Class Initialized
DEBUG - 2011-04-06 21:48:01 --> UTF-8 Support Enabled
DEBUG - 2011-04-06 21:48:01 --> URI Class Initialized
DEBUG - 2011-04-06 21:48:01 --> Router Class Initialized
DEBUG - 2011-04-06 21:48:01 --> Output Class Initialized
DEBUG - 2011-04-06 21:48:01 --> Input Class Initialized
DEBUG - 2011-04-06 21:48:01 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-06 21:48:01 --> Language Class Initialized
DEBUG - 2011-04-06 21:48:01 --> Loader Class Initialized
DEBUG - 2011-04-06 21:48:01 --> Controller Class Initialized
DEBUG - 2011-04-06 21:48:01 --> Model Class Initialized
DEBUG - 2011-04-06 21:48:01 --> Model Class Initialized
DEBUG - 2011-04-06 21:48:01 --> Model Class Initialized
DEBUG - 2011-04-06 21:48:01 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-06 21:48:01 --> Database Driver Class Initialized
DEBUG - 2011-04-06 21:48:01 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-06 21:48:01 --> Helper loaded: url_helper
DEBUG - 2011-04-06 21:48:01 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-06 21:48:01 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-06 21:48:01 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-06 21:48:01 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-06 21:48:01 --> Final output sent to browser
DEBUG - 2011-04-06 21:48:01 --> Total execution time: 0.2125
DEBUG - 2011-04-06 21:48:04 --> Config Class Initialized
DEBUG - 2011-04-06 21:48:04 --> Hooks Class Initialized
DEBUG - 2011-04-06 21:48:04 --> Utf8 Class Initialized
DEBUG - 2011-04-06 21:48:04 --> UTF-8 Support Enabled
DEBUG - 2011-04-06 21:48:04 --> URI Class Initialized
DEBUG - 2011-04-06 21:48:04 --> Router Class Initialized
ERROR - 2011-04-06 21:48:04 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-06 21:51:37 --> Config Class Initialized
DEBUG - 2011-04-06 21:51:37 --> Hooks Class Initialized
DEBUG - 2011-04-06 21:51:37 --> Utf8 Class Initialized
DEBUG - 2011-04-06 21:51:37 --> UTF-8 Support Enabled
DEBUG - 2011-04-06 21:51:37 --> URI Class Initialized
DEBUG - 2011-04-06 21:51:37 --> Router Class Initialized
DEBUG - 2011-04-06 21:51:37 --> Output Class Initialized
DEBUG - 2011-04-06 21:51:37 --> Input Class Initialized
DEBUG - 2011-04-06 21:51:37 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-06 21:51:37 --> Language Class Initialized
DEBUG - 2011-04-06 21:51:37 --> Loader Class Initialized
DEBUG - 2011-04-06 21:51:37 --> Controller Class Initialized
DEBUG - 2011-04-06 21:51:37 --> Model Class Initialized
DEBUG - 2011-04-06 21:51:37 --> Model Class Initialized
DEBUG - 2011-04-06 21:51:37 --> Model Class Initialized
DEBUG - 2011-04-06 21:51:37 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-06 21:51:37 --> Database Driver Class Initialized
DEBUG - 2011-04-06 21:51:37 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-06 21:51:37 --> Helper loaded: url_helper
DEBUG - 2011-04-06 21:51:37 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-06 21:51:37 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-06 21:51:37 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-06 21:51:37 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-06 21:51:37 --> Final output sent to browser
DEBUG - 2011-04-06 21:51:37 --> Total execution time: 0.0428
DEBUG - 2011-04-06 21:56:33 --> Config Class Initialized
DEBUG - 2011-04-06 21:56:33 --> Hooks Class Initialized
DEBUG - 2011-04-06 21:56:33 --> Utf8 Class Initialized
DEBUG - 2011-04-06 21:56:33 --> UTF-8 Support Enabled
DEBUG - 2011-04-06 21:56:33 --> URI Class Initialized
DEBUG - 2011-04-06 21:56:33 --> Router Class Initialized
DEBUG - 2011-04-06 21:56:33 --> Output Class Initialized
DEBUG - 2011-04-06 21:56:33 --> Input Class Initialized
DEBUG - 2011-04-06 21:56:33 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-06 21:56:33 --> Language Class Initialized
DEBUG - 2011-04-06 21:56:33 --> Loader Class Initialized
DEBUG - 2011-04-06 21:56:33 --> Controller Class Initialized
ERROR - 2011-04-06 21:56:33 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-06 21:56:33 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-06 21:56:33 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-06 21:56:33 --> Model Class Initialized
DEBUG - 2011-04-06 21:56:33 --> Model Class Initialized
DEBUG - 2011-04-06 21:56:33 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-06 21:56:33 --> Database Driver Class Initialized
DEBUG - 2011-04-06 21:56:33 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-06 21:56:33 --> Helper loaded: url_helper
DEBUG - 2011-04-06 21:56:33 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-06 21:56:33 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-06 21:56:33 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-06 21:56:33 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-06 21:56:33 --> Final output sent to browser
DEBUG - 2011-04-06 21:56:33 --> Total execution time: 0.0274
DEBUG - 2011-04-06 22:36:36 --> Config Class Initialized
DEBUG - 2011-04-06 22:36:36 --> Hooks Class Initialized
DEBUG - 2011-04-06 22:36:36 --> Utf8 Class Initialized
DEBUG - 2011-04-06 22:36:36 --> UTF-8 Support Enabled
DEBUG - 2011-04-06 22:36:36 --> URI Class Initialized
DEBUG - 2011-04-06 22:36:36 --> Router Class Initialized
DEBUG - 2011-04-06 22:36:36 --> Output Class Initialized
DEBUG - 2011-04-06 22:36:36 --> Input Class Initialized
DEBUG - 2011-04-06 22:36:36 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-06 22:36:37 --> Language Class Initialized
DEBUG - 2011-04-06 22:36:37 --> Loader Class Initialized
DEBUG - 2011-04-06 22:36:37 --> Controller Class Initialized
ERROR - 2011-04-06 22:36:37 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-06 22:36:37 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-06 22:36:37 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-06 22:36:37 --> Model Class Initialized
DEBUG - 2011-04-06 22:36:37 --> Model Class Initialized
DEBUG - 2011-04-06 22:36:37 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-06 22:36:37 --> Database Driver Class Initialized
DEBUG - 2011-04-06 22:36:37 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-06 22:36:38 --> Helper loaded: url_helper
DEBUG - 2011-04-06 22:36:38 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-06 22:36:38 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-06 22:36:38 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-06 22:36:38 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-06 22:36:38 --> Final output sent to browser
DEBUG - 2011-04-06 22:36:38 --> Total execution time: 1.6776
DEBUG - 2011-04-06 23:15:30 --> Config Class Initialized
DEBUG - 2011-04-06 23:15:30 --> Hooks Class Initialized
DEBUG - 2011-04-06 23:15:30 --> Utf8 Class Initialized
DEBUG - 2011-04-06 23:15:30 --> UTF-8 Support Enabled
DEBUG - 2011-04-06 23:15:30 --> URI Class Initialized
DEBUG - 2011-04-06 23:15:30 --> Router Class Initialized
DEBUG - 2011-04-06 23:15:30 --> No URI present. Default controller set.
DEBUG - 2011-04-06 23:15:30 --> Output Class Initialized
DEBUG - 2011-04-06 23:15:30 --> Input Class Initialized
DEBUG - 2011-04-06 23:15:30 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-06 23:15:30 --> Language Class Initialized
DEBUG - 2011-04-06 23:15:30 --> Loader Class Initialized
DEBUG - 2011-04-06 23:15:30 --> Controller Class Initialized
DEBUG - 2011-04-06 23:15:30 --> File loaded: application/views/splash/main.php
DEBUG - 2011-04-06 23:15:30 --> Helper loaded: url_helper
DEBUG - 2011-04-06 23:15:30 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-06 23:15:30 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-06 23:15:30 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-06 23:15:30 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-06 23:15:30 --> Final output sent to browser
DEBUG - 2011-04-06 23:15:30 --> Total execution time: 0.1921
DEBUG - 2011-04-06 23:15:34 --> Config Class Initialized
DEBUG - 2011-04-06 23:15:34 --> Hooks Class Initialized
DEBUG - 2011-04-06 23:15:34 --> Utf8 Class Initialized
DEBUG - 2011-04-06 23:15:34 --> UTF-8 Support Enabled
DEBUG - 2011-04-06 23:15:34 --> URI Class Initialized
DEBUG - 2011-04-06 23:15:34 --> Router Class Initialized
ERROR - 2011-04-06 23:15:34 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-06 23:15:34 --> Config Class Initialized
DEBUG - 2011-04-06 23:15:34 --> Hooks Class Initialized
DEBUG - 2011-04-06 23:15:34 --> Utf8 Class Initialized
DEBUG - 2011-04-06 23:15:34 --> UTF-8 Support Enabled
DEBUG - 2011-04-06 23:15:34 --> URI Class Initialized
DEBUG - 2011-04-06 23:15:34 --> Router Class Initialized
ERROR - 2011-04-06 23:15:34 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-06 23:15:46 --> Config Class Initialized
DEBUG - 2011-04-06 23:15:46 --> Hooks Class Initialized
DEBUG - 2011-04-06 23:15:46 --> Utf8 Class Initialized
DEBUG - 2011-04-06 23:15:46 --> UTF-8 Support Enabled
DEBUG - 2011-04-06 23:15:46 --> URI Class Initialized
DEBUG - 2011-04-06 23:15:46 --> Router Class Initialized
DEBUG - 2011-04-06 23:15:46 --> Output Class Initialized
DEBUG - 2011-04-06 23:15:46 --> Input Class Initialized
DEBUG - 2011-04-06 23:15:46 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-06 23:15:46 --> Language Class Initialized
DEBUG - 2011-04-06 23:15:46 --> Loader Class Initialized
DEBUG - 2011-04-06 23:15:46 --> Controller Class Initialized
ERROR - 2011-04-06 23:15:46 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-06 23:15:46 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-06 23:15:46 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-06 23:15:46 --> Model Class Initialized
DEBUG - 2011-04-06 23:15:46 --> Model Class Initialized
DEBUG - 2011-04-06 23:15:46 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-06 23:15:46 --> Database Driver Class Initialized
DEBUG - 2011-04-06 23:15:46 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-06 23:15:46 --> Helper loaded: url_helper
DEBUG - 2011-04-06 23:15:46 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-06 23:15:46 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-06 23:15:46 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-06 23:15:46 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-06 23:15:46 --> Final output sent to browser
DEBUG - 2011-04-06 23:15:46 --> Total execution time: 0.1449
DEBUG - 2011-04-06 23:15:47 --> Config Class Initialized
DEBUG - 2011-04-06 23:15:47 --> Hooks Class Initialized
DEBUG - 2011-04-06 23:15:47 --> Utf8 Class Initialized
DEBUG - 2011-04-06 23:15:47 --> UTF-8 Support Enabled
DEBUG - 2011-04-06 23:15:47 --> URI Class Initialized
DEBUG - 2011-04-06 23:15:47 --> Router Class Initialized
DEBUG - 2011-04-06 23:15:47 --> Output Class Initialized
DEBUG - 2011-04-06 23:15:47 --> Input Class Initialized
DEBUG - 2011-04-06 23:15:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-06 23:15:47 --> Language Class Initialized
DEBUG - 2011-04-06 23:15:47 --> Loader Class Initialized
DEBUG - 2011-04-06 23:15:47 --> Controller Class Initialized
DEBUG - 2011-04-06 23:15:47 --> Model Class Initialized
DEBUG - 2011-04-06 23:15:47 --> Model Class Initialized
DEBUG - 2011-04-06 23:15:47 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-06 23:15:47 --> Database Driver Class Initialized
DEBUG - 2011-04-06 23:15:48 --> Final output sent to browser
DEBUG - 2011-04-06 23:15:48 --> Total execution time: 0.8825
DEBUG - 2011-04-06 23:15:50 --> Config Class Initialized
DEBUG - 2011-04-06 23:15:50 --> Hooks Class Initialized
DEBUG - 2011-04-06 23:15:50 --> Utf8 Class Initialized
DEBUG - 2011-04-06 23:15:50 --> UTF-8 Support Enabled
DEBUG - 2011-04-06 23:15:50 --> URI Class Initialized
DEBUG - 2011-04-06 23:15:50 --> Router Class Initialized
ERROR - 2011-04-06 23:15:50 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-06 23:15:51 --> Config Class Initialized
DEBUG - 2011-04-06 23:15:51 --> Hooks Class Initialized
DEBUG - 2011-04-06 23:15:51 --> Utf8 Class Initialized
DEBUG - 2011-04-06 23:15:51 --> UTF-8 Support Enabled
DEBUG - 2011-04-06 23:15:51 --> URI Class Initialized
DEBUG - 2011-04-06 23:15:51 --> Router Class Initialized
DEBUG - 2011-04-06 23:15:51 --> Output Class Initialized
DEBUG - 2011-04-06 23:15:51 --> Input Class Initialized
DEBUG - 2011-04-06 23:15:51 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-06 23:15:51 --> Language Class Initialized
DEBUG - 2011-04-06 23:15:51 --> Loader Class Initialized
DEBUG - 2011-04-06 23:15:51 --> Controller Class Initialized
ERROR - 2011-04-06 23:15:51 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-06 23:15:51 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-06 23:15:51 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-06 23:15:51 --> Model Class Initialized
DEBUG - 2011-04-06 23:15:51 --> Model Class Initialized
DEBUG - 2011-04-06 23:15:51 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-06 23:15:51 --> Database Driver Class Initialized
DEBUG - 2011-04-06 23:15:51 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-06 23:15:51 --> Helper loaded: url_helper
DEBUG - 2011-04-06 23:15:51 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-06 23:15:51 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-06 23:15:51 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-06 23:15:51 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-06 23:15:51 --> Final output sent to browser
DEBUG - 2011-04-06 23:15:51 --> Total execution time: 0.0296
DEBUG - 2011-04-06 23:15:52 --> Config Class Initialized
DEBUG - 2011-04-06 23:15:52 --> Hooks Class Initialized
DEBUG - 2011-04-06 23:15:52 --> Utf8 Class Initialized
DEBUG - 2011-04-06 23:15:52 --> UTF-8 Support Enabled
DEBUG - 2011-04-06 23:15:52 --> URI Class Initialized
DEBUG - 2011-04-06 23:15:52 --> Router Class Initialized
DEBUG - 2011-04-06 23:15:52 --> Output Class Initialized
DEBUG - 2011-04-06 23:15:52 --> Input Class Initialized
DEBUG - 2011-04-06 23:15:52 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-06 23:15:52 --> Language Class Initialized
DEBUG - 2011-04-06 23:15:52 --> Loader Class Initialized
DEBUG - 2011-04-06 23:15:52 --> Controller Class Initialized
DEBUG - 2011-04-06 23:15:52 --> Model Class Initialized
DEBUG - 2011-04-06 23:15:52 --> Model Class Initialized
DEBUG - 2011-04-06 23:15:52 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-06 23:15:52 --> Database Driver Class Initialized
DEBUG - 2011-04-06 23:15:53 --> Final output sent to browser
DEBUG - 2011-04-06 23:15:53 --> Total execution time: 1.1152
DEBUG - 2011-04-06 23:15:55 --> Config Class Initialized
DEBUG - 2011-04-06 23:15:55 --> Hooks Class Initialized
DEBUG - 2011-04-06 23:15:55 --> Utf8 Class Initialized
DEBUG - 2011-04-06 23:15:55 --> UTF-8 Support Enabled
DEBUG - 2011-04-06 23:15:55 --> URI Class Initialized
DEBUG - 2011-04-06 23:15:55 --> Router Class Initialized
ERROR - 2011-04-06 23:15:55 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-06 23:16:02 --> Config Class Initialized
DEBUG - 2011-04-06 23:16:02 --> Hooks Class Initialized
DEBUG - 2011-04-06 23:16:02 --> Utf8 Class Initialized
DEBUG - 2011-04-06 23:16:02 --> UTF-8 Support Enabled
DEBUG - 2011-04-06 23:16:02 --> URI Class Initialized
DEBUG - 2011-04-06 23:16:02 --> Router Class Initialized
DEBUG - 2011-04-06 23:16:02 --> Output Class Initialized
DEBUG - 2011-04-06 23:16:02 --> Input Class Initialized
DEBUG - 2011-04-06 23:16:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-06 23:16:02 --> Language Class Initialized
DEBUG - 2011-04-06 23:16:02 --> Loader Class Initialized
DEBUG - 2011-04-06 23:16:02 --> Controller Class Initialized
ERROR - 2011-04-06 23:16:02 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-06 23:16:02 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-06 23:16:02 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-06 23:16:02 --> Model Class Initialized
DEBUG - 2011-04-06 23:16:02 --> Model Class Initialized
DEBUG - 2011-04-06 23:16:02 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-06 23:16:02 --> Database Driver Class Initialized
DEBUG - 2011-04-06 23:16:02 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-06 23:16:02 --> Helper loaded: url_helper
DEBUG - 2011-04-06 23:16:02 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-06 23:16:02 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-06 23:16:02 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-06 23:16:02 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-06 23:16:02 --> Final output sent to browser
DEBUG - 2011-04-06 23:16:02 --> Total execution time: 0.0375
DEBUG - 2011-04-06 23:16:03 --> Config Class Initialized
DEBUG - 2011-04-06 23:16:03 --> Hooks Class Initialized
DEBUG - 2011-04-06 23:16:03 --> Utf8 Class Initialized
DEBUG - 2011-04-06 23:16:03 --> UTF-8 Support Enabled
DEBUG - 2011-04-06 23:16:03 --> URI Class Initialized
DEBUG - 2011-04-06 23:16:03 --> Router Class Initialized
DEBUG - 2011-04-06 23:16:03 --> Output Class Initialized
DEBUG - 2011-04-06 23:16:03 --> Input Class Initialized
DEBUG - 2011-04-06 23:16:03 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-06 23:16:03 --> Language Class Initialized
DEBUG - 2011-04-06 23:16:03 --> Loader Class Initialized
DEBUG - 2011-04-06 23:16:03 --> Controller Class Initialized
DEBUG - 2011-04-06 23:16:03 --> Model Class Initialized
DEBUG - 2011-04-06 23:16:03 --> Model Class Initialized
DEBUG - 2011-04-06 23:16:03 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-06 23:16:03 --> Database Driver Class Initialized
DEBUG - 2011-04-06 23:16:04 --> Final output sent to browser
DEBUG - 2011-04-06 23:16:04 --> Total execution time: 0.7838
DEBUG - 2011-04-06 23:16:06 --> Config Class Initialized
DEBUG - 2011-04-06 23:16:06 --> Hooks Class Initialized
DEBUG - 2011-04-06 23:16:06 --> Utf8 Class Initialized
DEBUG - 2011-04-06 23:16:06 --> UTF-8 Support Enabled
DEBUG - 2011-04-06 23:16:06 --> URI Class Initialized
DEBUG - 2011-04-06 23:16:06 --> Router Class Initialized
ERROR - 2011-04-06 23:16:06 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-06 23:16:22 --> Config Class Initialized
DEBUG - 2011-04-06 23:16:22 --> Hooks Class Initialized
DEBUG - 2011-04-06 23:16:22 --> Utf8 Class Initialized
DEBUG - 2011-04-06 23:16:22 --> UTF-8 Support Enabled
DEBUG - 2011-04-06 23:16:22 --> URI Class Initialized
DEBUG - 2011-04-06 23:16:22 --> Router Class Initialized
DEBUG - 2011-04-06 23:16:22 --> Output Class Initialized
DEBUG - 2011-04-06 23:16:22 --> Input Class Initialized
DEBUG - 2011-04-06 23:16:22 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-06 23:16:22 --> Language Class Initialized
DEBUG - 2011-04-06 23:16:22 --> Loader Class Initialized
DEBUG - 2011-04-06 23:16:22 --> Controller Class Initialized
ERROR - 2011-04-06 23:16:22 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-06 23:16:22 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-06 23:16:22 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-06 23:16:22 --> Model Class Initialized
DEBUG - 2011-04-06 23:16:22 --> Model Class Initialized
DEBUG - 2011-04-06 23:16:22 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-06 23:16:22 --> Database Driver Class Initialized
DEBUG - 2011-04-06 23:16:22 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-06 23:16:22 --> Helper loaded: url_helper
DEBUG - 2011-04-06 23:16:22 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-06 23:16:22 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-06 23:16:22 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-06 23:16:22 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-06 23:16:22 --> Final output sent to browser
DEBUG - 2011-04-06 23:16:22 --> Total execution time: 0.0278
DEBUG - 2011-04-06 23:16:23 --> Config Class Initialized
DEBUG - 2011-04-06 23:16:23 --> Hooks Class Initialized
DEBUG - 2011-04-06 23:16:23 --> Utf8 Class Initialized
DEBUG - 2011-04-06 23:16:23 --> UTF-8 Support Enabled
DEBUG - 2011-04-06 23:16:23 --> URI Class Initialized
DEBUG - 2011-04-06 23:16:23 --> Router Class Initialized
DEBUG - 2011-04-06 23:16:23 --> Output Class Initialized
DEBUG - 2011-04-06 23:16:23 --> Input Class Initialized
DEBUG - 2011-04-06 23:16:23 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-06 23:16:23 --> Language Class Initialized
DEBUG - 2011-04-06 23:16:23 --> Loader Class Initialized
DEBUG - 2011-04-06 23:16:23 --> Controller Class Initialized
DEBUG - 2011-04-06 23:16:23 --> Model Class Initialized
DEBUG - 2011-04-06 23:16:23 --> Model Class Initialized
DEBUG - 2011-04-06 23:16:23 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-06 23:16:23 --> Database Driver Class Initialized
DEBUG - 2011-04-06 23:16:24 --> Final output sent to browser
DEBUG - 2011-04-06 23:16:24 --> Total execution time: 0.8807
DEBUG - 2011-04-06 23:16:24 --> Config Class Initialized
DEBUG - 2011-04-06 23:16:24 --> Hooks Class Initialized
DEBUG - 2011-04-06 23:16:24 --> Utf8 Class Initialized
DEBUG - 2011-04-06 23:16:24 --> UTF-8 Support Enabled
DEBUG - 2011-04-06 23:16:24 --> URI Class Initialized
DEBUG - 2011-04-06 23:16:24 --> Router Class Initialized
DEBUG - 2011-04-06 23:16:24 --> Output Class Initialized
DEBUG - 2011-04-06 23:16:24 --> Input Class Initialized
DEBUG - 2011-04-06 23:16:24 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-06 23:16:24 --> Language Class Initialized
DEBUG - 2011-04-06 23:16:24 --> Loader Class Initialized
DEBUG - 2011-04-06 23:16:24 --> Controller Class Initialized
ERROR - 2011-04-06 23:16:24 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-06 23:16:24 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-06 23:16:24 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-06 23:16:24 --> Model Class Initialized
DEBUG - 2011-04-06 23:16:24 --> Model Class Initialized
DEBUG - 2011-04-06 23:16:24 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-06 23:16:24 --> Database Driver Class Initialized
DEBUG - 2011-04-06 23:16:24 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-06 23:16:24 --> Helper loaded: url_helper
DEBUG - 2011-04-06 23:16:24 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-06 23:16:24 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-06 23:16:24 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-06 23:16:24 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-06 23:16:24 --> Final output sent to browser
DEBUG - 2011-04-06 23:16:24 --> Total execution time: 0.0292
DEBUG - 2011-04-06 23:16:25 --> Config Class Initialized
DEBUG - 2011-04-06 23:16:25 --> Hooks Class Initialized
DEBUG - 2011-04-06 23:16:25 --> Utf8 Class Initialized
DEBUG - 2011-04-06 23:16:25 --> UTF-8 Support Enabled
DEBUG - 2011-04-06 23:16:25 --> URI Class Initialized
DEBUG - 2011-04-06 23:16:25 --> Router Class Initialized
ERROR - 2011-04-06 23:16:25 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-06 23:16:33 --> Config Class Initialized
DEBUG - 2011-04-06 23:16:33 --> Hooks Class Initialized
DEBUG - 2011-04-06 23:16:33 --> Utf8 Class Initialized
DEBUG - 2011-04-06 23:16:33 --> UTF-8 Support Enabled
DEBUG - 2011-04-06 23:16:33 --> URI Class Initialized
DEBUG - 2011-04-06 23:16:33 --> Router Class Initialized
ERROR - 2011-04-06 23:16:33 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-06 23:16:42 --> Config Class Initialized
DEBUG - 2011-04-06 23:16:42 --> Hooks Class Initialized
DEBUG - 2011-04-06 23:16:42 --> Utf8 Class Initialized
DEBUG - 2011-04-06 23:16:42 --> UTF-8 Support Enabled
DEBUG - 2011-04-06 23:16:42 --> URI Class Initialized
DEBUG - 2011-04-06 23:16:42 --> Router Class Initialized
DEBUG - 2011-04-06 23:16:42 --> Output Class Initialized
DEBUG - 2011-04-06 23:16:42 --> Input Class Initialized
DEBUG - 2011-04-06 23:16:42 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-06 23:16:42 --> Language Class Initialized
DEBUG - 2011-04-06 23:16:42 --> Loader Class Initialized
DEBUG - 2011-04-06 23:16:42 --> Controller Class Initialized
ERROR - 2011-04-06 23:16:42 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-06 23:16:42 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-06 23:16:42 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-06 23:16:42 --> Model Class Initialized
DEBUG - 2011-04-06 23:16:42 --> Model Class Initialized
DEBUG - 2011-04-06 23:16:42 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-06 23:16:42 --> Database Driver Class Initialized
DEBUG - 2011-04-06 23:16:42 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-06 23:16:42 --> Helper loaded: url_helper
DEBUG - 2011-04-06 23:16:42 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-06 23:16:42 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-06 23:16:42 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-06 23:16:42 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-06 23:16:42 --> Final output sent to browser
DEBUG - 2011-04-06 23:16:42 --> Total execution time: 0.0281
DEBUG - 2011-04-06 23:16:44 --> Config Class Initialized
DEBUG - 2011-04-06 23:16:44 --> Hooks Class Initialized
DEBUG - 2011-04-06 23:16:44 --> Utf8 Class Initialized
DEBUG - 2011-04-06 23:16:44 --> UTF-8 Support Enabled
DEBUG - 2011-04-06 23:16:44 --> URI Class Initialized
DEBUG - 2011-04-06 23:16:44 --> Router Class Initialized
DEBUG - 2011-04-06 23:16:44 --> Output Class Initialized
DEBUG - 2011-04-06 23:16:44 --> Input Class Initialized
DEBUG - 2011-04-06 23:16:44 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-06 23:16:44 --> Language Class Initialized
DEBUG - 2011-04-06 23:16:44 --> Loader Class Initialized
DEBUG - 2011-04-06 23:16:44 --> Controller Class Initialized
DEBUG - 2011-04-06 23:16:44 --> Model Class Initialized
DEBUG - 2011-04-06 23:16:44 --> Model Class Initialized
DEBUG - 2011-04-06 23:16:44 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-06 23:16:44 --> Database Driver Class Initialized
DEBUG - 2011-04-06 23:16:44 --> Final output sent to browser
DEBUG - 2011-04-06 23:16:44 --> Total execution time: 0.6744
DEBUG - 2011-04-06 23:16:46 --> Config Class Initialized
DEBUG - 2011-04-06 23:16:46 --> Hooks Class Initialized
DEBUG - 2011-04-06 23:16:46 --> Utf8 Class Initialized
DEBUG - 2011-04-06 23:16:46 --> UTF-8 Support Enabled
DEBUG - 2011-04-06 23:16:46 --> URI Class Initialized
DEBUG - 2011-04-06 23:16:46 --> Router Class Initialized
ERROR - 2011-04-06 23:16:46 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-06 23:38:59 --> Config Class Initialized
DEBUG - 2011-04-06 23:38:59 --> Hooks Class Initialized
DEBUG - 2011-04-06 23:38:59 --> Utf8 Class Initialized
DEBUG - 2011-04-06 23:38:59 --> UTF-8 Support Enabled
DEBUG - 2011-04-06 23:38:59 --> URI Class Initialized
DEBUG - 2011-04-06 23:38:59 --> Router Class Initialized
DEBUG - 2011-04-06 23:38:59 --> Output Class Initialized
DEBUG - 2011-04-06 23:38:59 --> Input Class Initialized
DEBUG - 2011-04-06 23:38:59 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-06 23:38:59 --> Language Class Initialized
DEBUG - 2011-04-06 23:38:59 --> Loader Class Initialized
DEBUG - 2011-04-06 23:38:59 --> Controller Class Initialized
ERROR - 2011-04-06 23:38:59 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-06 23:38:59 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-06 23:38:59 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-06 23:38:59 --> Model Class Initialized
DEBUG - 2011-04-06 23:38:59 --> Model Class Initialized
DEBUG - 2011-04-06 23:38:59 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-06 23:38:59 --> Database Driver Class Initialized
DEBUG - 2011-04-06 23:38:59 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-06 23:38:59 --> Helper loaded: url_helper
DEBUG - 2011-04-06 23:38:59 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-06 23:38:59 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-06 23:38:59 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-06 23:38:59 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-06 23:38:59 --> Final output sent to browser
DEBUG - 2011-04-06 23:38:59 --> Total execution time: 0.0713
DEBUG - 2011-04-06 23:38:59 --> Config Class Initialized
DEBUG - 2011-04-06 23:38:59 --> Hooks Class Initialized
DEBUG - 2011-04-06 23:38:59 --> Utf8 Class Initialized
DEBUG - 2011-04-06 23:38:59 --> UTF-8 Support Enabled
DEBUG - 2011-04-06 23:38:59 --> URI Class Initialized
DEBUG - 2011-04-06 23:38:59 --> Router Class Initialized
DEBUG - 2011-04-06 23:38:59 --> Output Class Initialized
DEBUG - 2011-04-06 23:38:59 --> Input Class Initialized
DEBUG - 2011-04-06 23:38:59 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-06 23:38:59 --> Language Class Initialized
DEBUG - 2011-04-06 23:38:59 --> Loader Class Initialized
DEBUG - 2011-04-06 23:38:59 --> Controller Class Initialized
DEBUG - 2011-04-06 23:38:59 --> Model Class Initialized
DEBUG - 2011-04-06 23:38:59 --> Model Class Initialized
DEBUG - 2011-04-06 23:38:59 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-06 23:38:59 --> Database Driver Class Initialized
DEBUG - 2011-04-06 23:39:00 --> Final output sent to browser
DEBUG - 2011-04-06 23:39:00 --> Total execution time: 0.6919
DEBUG - 2011-04-06 23:39:02 --> Config Class Initialized
DEBUG - 2011-04-06 23:39:02 --> Hooks Class Initialized
DEBUG - 2011-04-06 23:39:02 --> Utf8 Class Initialized
DEBUG - 2011-04-06 23:39:02 --> UTF-8 Support Enabled
DEBUG - 2011-04-06 23:39:02 --> URI Class Initialized
DEBUG - 2011-04-06 23:39:02 --> Router Class Initialized
ERROR - 2011-04-06 23:39:02 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-06 23:39:02 --> Config Class Initialized
DEBUG - 2011-04-06 23:39:02 --> Hooks Class Initialized
DEBUG - 2011-04-06 23:39:02 --> Utf8 Class Initialized
DEBUG - 2011-04-06 23:39:02 --> UTF-8 Support Enabled
DEBUG - 2011-04-06 23:39:02 --> URI Class Initialized
DEBUG - 2011-04-06 23:39:02 --> Router Class Initialized
ERROR - 2011-04-06 23:39:02 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-06 23:40:08 --> Config Class Initialized
DEBUG - 2011-04-06 23:40:08 --> Hooks Class Initialized
DEBUG - 2011-04-06 23:40:08 --> Utf8 Class Initialized
DEBUG - 2011-04-06 23:40:08 --> UTF-8 Support Enabled
DEBUG - 2011-04-06 23:40:08 --> URI Class Initialized
DEBUG - 2011-04-06 23:40:08 --> Router Class Initialized
DEBUG - 2011-04-06 23:40:08 --> Output Class Initialized
DEBUG - 2011-04-06 23:40:08 --> Input Class Initialized
DEBUG - 2011-04-06 23:40:08 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-06 23:40:08 --> Language Class Initialized
DEBUG - 2011-04-06 23:40:08 --> Loader Class Initialized
DEBUG - 2011-04-06 23:40:08 --> Controller Class Initialized
ERROR - 2011-04-06 23:40:08 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-06 23:40:08 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-06 23:40:08 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-06 23:40:08 --> Model Class Initialized
DEBUG - 2011-04-06 23:40:08 --> Model Class Initialized
DEBUG - 2011-04-06 23:40:08 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-06 23:40:08 --> Database Driver Class Initialized
DEBUG - 2011-04-06 23:40:08 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-06 23:40:08 --> Helper loaded: url_helper
DEBUG - 2011-04-06 23:40:08 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-06 23:40:08 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-06 23:40:08 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-06 23:40:08 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-06 23:40:08 --> Final output sent to browser
DEBUG - 2011-04-06 23:40:08 --> Total execution time: 0.0507
DEBUG - 2011-04-06 23:40:09 --> Config Class Initialized
DEBUG - 2011-04-06 23:40:09 --> Hooks Class Initialized
DEBUG - 2011-04-06 23:40:09 --> Utf8 Class Initialized
DEBUG - 2011-04-06 23:40:09 --> UTF-8 Support Enabled
DEBUG - 2011-04-06 23:40:09 --> URI Class Initialized
DEBUG - 2011-04-06 23:40:09 --> Router Class Initialized
DEBUG - 2011-04-06 23:40:09 --> Output Class Initialized
DEBUG - 2011-04-06 23:40:09 --> Input Class Initialized
DEBUG - 2011-04-06 23:40:09 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-06 23:40:09 --> Language Class Initialized
DEBUG - 2011-04-06 23:40:09 --> Loader Class Initialized
DEBUG - 2011-04-06 23:40:09 --> Controller Class Initialized
DEBUG - 2011-04-06 23:40:09 --> Model Class Initialized
DEBUG - 2011-04-06 23:40:09 --> Model Class Initialized
DEBUG - 2011-04-06 23:40:09 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-06 23:40:09 --> Database Driver Class Initialized
DEBUG - 2011-04-06 23:40:10 --> Final output sent to browser
DEBUG - 2011-04-06 23:40:10 --> Total execution time: 0.6991
DEBUG - 2011-04-06 23:40:37 --> Config Class Initialized
DEBUG - 2011-04-06 23:40:37 --> Hooks Class Initialized
DEBUG - 2011-04-06 23:40:37 --> Utf8 Class Initialized
DEBUG - 2011-04-06 23:40:37 --> UTF-8 Support Enabled
DEBUG - 2011-04-06 23:40:37 --> URI Class Initialized
DEBUG - 2011-04-06 23:40:37 --> Router Class Initialized
DEBUG - 2011-04-06 23:40:37 --> Output Class Initialized
DEBUG - 2011-04-06 23:40:37 --> Input Class Initialized
DEBUG - 2011-04-06 23:40:37 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-06 23:40:37 --> Language Class Initialized
DEBUG - 2011-04-06 23:40:37 --> Loader Class Initialized
DEBUG - 2011-04-06 23:40:37 --> Controller Class Initialized
ERROR - 2011-04-06 23:40:37 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-06 23:40:37 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-06 23:40:37 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-06 23:40:37 --> Model Class Initialized
DEBUG - 2011-04-06 23:40:37 --> Model Class Initialized
DEBUG - 2011-04-06 23:40:37 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-06 23:40:37 --> Database Driver Class Initialized
DEBUG - 2011-04-06 23:40:37 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-06 23:40:37 --> Helper loaded: url_helper
DEBUG - 2011-04-06 23:40:37 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-06 23:40:37 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-06 23:40:37 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-06 23:40:37 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-06 23:40:37 --> Final output sent to browser
DEBUG - 2011-04-06 23:40:37 --> Total execution time: 0.0555
DEBUG - 2011-04-06 23:40:37 --> Config Class Initialized
DEBUG - 2011-04-06 23:40:37 --> Hooks Class Initialized
DEBUG - 2011-04-06 23:40:37 --> Utf8 Class Initialized
DEBUG - 2011-04-06 23:40:37 --> UTF-8 Support Enabled
DEBUG - 2011-04-06 23:40:37 --> URI Class Initialized
DEBUG - 2011-04-06 23:40:37 --> Router Class Initialized
DEBUG - 2011-04-06 23:40:37 --> Output Class Initialized
DEBUG - 2011-04-06 23:40:37 --> Input Class Initialized
DEBUG - 2011-04-06 23:40:37 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-06 23:40:37 --> Language Class Initialized
DEBUG - 2011-04-06 23:40:37 --> Loader Class Initialized
DEBUG - 2011-04-06 23:40:37 --> Controller Class Initialized
DEBUG - 2011-04-06 23:40:37 --> Model Class Initialized
DEBUG - 2011-04-06 23:40:37 --> Model Class Initialized
DEBUG - 2011-04-06 23:40:37 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-06 23:40:37 --> Database Driver Class Initialized
DEBUG - 2011-04-06 23:40:38 --> Final output sent to browser
DEBUG - 2011-04-06 23:40:38 --> Total execution time: 0.7449
DEBUG - 2011-04-06 23:40:46 --> Config Class Initialized
DEBUG - 2011-04-06 23:40:46 --> Hooks Class Initialized
DEBUG - 2011-04-06 23:40:46 --> Utf8 Class Initialized
DEBUG - 2011-04-06 23:40:46 --> UTF-8 Support Enabled
DEBUG - 2011-04-06 23:40:46 --> URI Class Initialized
DEBUG - 2011-04-06 23:40:46 --> Router Class Initialized
DEBUG - 2011-04-06 23:40:46 --> Output Class Initialized
DEBUG - 2011-04-06 23:40:46 --> Input Class Initialized
DEBUG - 2011-04-06 23:40:46 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-06 23:40:46 --> Language Class Initialized
DEBUG - 2011-04-06 23:40:46 --> Loader Class Initialized
DEBUG - 2011-04-06 23:40:46 --> Controller Class Initialized
ERROR - 2011-04-06 23:40:46 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-06 23:40:46 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-06 23:40:46 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-06 23:40:46 --> Model Class Initialized
DEBUG - 2011-04-06 23:40:46 --> Model Class Initialized
DEBUG - 2011-04-06 23:40:46 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-06 23:40:46 --> Database Driver Class Initialized
DEBUG - 2011-04-06 23:40:46 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-06 23:40:46 --> Helper loaded: url_helper
DEBUG - 2011-04-06 23:40:46 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-06 23:40:46 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-06 23:40:46 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-06 23:40:46 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-06 23:40:46 --> Final output sent to browser
DEBUG - 2011-04-06 23:40:46 --> Total execution time: 0.0304
DEBUG - 2011-04-06 23:40:47 --> Config Class Initialized
DEBUG - 2011-04-06 23:40:47 --> Hooks Class Initialized
DEBUG - 2011-04-06 23:40:47 --> Utf8 Class Initialized
DEBUG - 2011-04-06 23:40:47 --> UTF-8 Support Enabled
DEBUG - 2011-04-06 23:40:47 --> URI Class Initialized
DEBUG - 2011-04-06 23:40:47 --> Router Class Initialized
DEBUG - 2011-04-06 23:40:47 --> Output Class Initialized
DEBUG - 2011-04-06 23:40:47 --> Input Class Initialized
DEBUG - 2011-04-06 23:40:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-06 23:40:47 --> Language Class Initialized
DEBUG - 2011-04-06 23:40:47 --> Loader Class Initialized
DEBUG - 2011-04-06 23:40:47 --> Controller Class Initialized
DEBUG - 2011-04-06 23:40:47 --> Model Class Initialized
DEBUG - 2011-04-06 23:40:47 --> Model Class Initialized
DEBUG - 2011-04-06 23:40:47 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-06 23:40:47 --> Database Driver Class Initialized
DEBUG - 2011-04-06 23:40:47 --> Final output sent to browser
DEBUG - 2011-04-06 23:40:47 --> Total execution time: 0.5955

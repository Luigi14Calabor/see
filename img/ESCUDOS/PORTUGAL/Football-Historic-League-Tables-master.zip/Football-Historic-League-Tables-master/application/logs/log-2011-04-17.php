<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2011-04-17 00:26:12 --> Config Class Initialized
DEBUG - 2011-04-17 00:26:12 --> Hooks Class Initialized
DEBUG - 2011-04-17 00:26:12 --> Utf8 Class Initialized
DEBUG - 2011-04-17 00:26:12 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 00:26:12 --> URI Class Initialized
DEBUG - 2011-04-17 00:26:12 --> Router Class Initialized
DEBUG - 2011-04-17 00:26:12 --> Output Class Initialized
DEBUG - 2011-04-17 00:26:12 --> Input Class Initialized
DEBUG - 2011-04-17 00:26:12 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-17 00:26:12 --> Language Class Initialized
DEBUG - 2011-04-17 00:26:12 --> Loader Class Initialized
DEBUG - 2011-04-17 00:26:12 --> Controller Class Initialized
DEBUG - 2011-04-17 00:26:12 --> Model Class Initialized
DEBUG - 2011-04-17 00:26:12 --> Model Class Initialized
DEBUG - 2011-04-17 00:26:12 --> Model Class Initialized
DEBUG - 2011-04-17 00:26:12 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-17 00:26:12 --> Database Driver Class Initialized
DEBUG - 2011-04-17 00:26:12 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-17 00:26:12 --> Helper loaded: url_helper
DEBUG - 2011-04-17 00:26:12 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-17 00:26:12 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-17 00:26:12 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-17 00:26:12 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-17 00:26:12 --> Final output sent to browser
DEBUG - 2011-04-17 00:26:12 --> Total execution time: 0.2362
DEBUG - 2011-04-17 00:26:16 --> Config Class Initialized
DEBUG - 2011-04-17 00:26:16 --> Hooks Class Initialized
DEBUG - 2011-04-17 00:26:16 --> Utf8 Class Initialized
DEBUG - 2011-04-17 00:26:16 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 00:26:16 --> URI Class Initialized
DEBUG - 2011-04-17 00:26:16 --> Router Class Initialized
ERROR - 2011-04-17 00:26:16 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-17 00:26:18 --> Config Class Initialized
DEBUG - 2011-04-17 00:26:18 --> Hooks Class Initialized
DEBUG - 2011-04-17 00:26:18 --> Utf8 Class Initialized
DEBUG - 2011-04-17 00:26:18 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 00:26:18 --> URI Class Initialized
DEBUG - 2011-04-17 00:26:18 --> Router Class Initialized
ERROR - 2011-04-17 00:26:18 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-17 01:57:20 --> Config Class Initialized
DEBUG - 2011-04-17 01:57:21 --> Hooks Class Initialized
DEBUG - 2011-04-17 01:57:21 --> Utf8 Class Initialized
DEBUG - 2011-04-17 01:57:21 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 01:57:21 --> URI Class Initialized
DEBUG - 2011-04-17 01:57:21 --> Router Class Initialized
DEBUG - 2011-04-17 01:57:22 --> Output Class Initialized
DEBUG - 2011-04-17 01:57:22 --> Input Class Initialized
DEBUG - 2011-04-17 01:57:22 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-17 01:57:23 --> Language Class Initialized
DEBUG - 2011-04-17 01:57:23 --> Loader Class Initialized
DEBUG - 2011-04-17 01:57:23 --> Controller Class Initialized
DEBUG - 2011-04-17 01:57:23 --> Model Class Initialized
DEBUG - 2011-04-17 01:57:23 --> Model Class Initialized
DEBUG - 2011-04-17 01:57:23 --> Model Class Initialized
DEBUG - 2011-04-17 01:57:23 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-17 01:57:23 --> Database Driver Class Initialized
DEBUG - 2011-04-17 01:57:35 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-17 01:57:35 --> Helper loaded: url_helper
DEBUG - 2011-04-17 01:57:35 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-17 01:57:35 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-17 01:57:35 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-17 01:57:35 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-17 01:57:35 --> Final output sent to browser
DEBUG - 2011-04-17 01:57:35 --> Total execution time: 17.2607
DEBUG - 2011-04-17 01:57:36 --> Config Class Initialized
DEBUG - 2011-04-17 01:57:36 --> Hooks Class Initialized
DEBUG - 2011-04-17 01:57:36 --> Utf8 Class Initialized
DEBUG - 2011-04-17 01:57:36 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 01:57:36 --> URI Class Initialized
DEBUG - 2011-04-17 01:57:36 --> Router Class Initialized
DEBUG - 2011-04-17 01:57:36 --> Output Class Initialized
DEBUG - 2011-04-17 01:57:36 --> Input Class Initialized
DEBUG - 2011-04-17 01:57:36 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-17 01:57:36 --> Language Class Initialized
DEBUG - 2011-04-17 01:57:36 --> Loader Class Initialized
DEBUG - 2011-04-17 01:57:36 --> Controller Class Initialized
ERROR - 2011-04-17 01:57:36 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-17 01:57:36 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-17 01:57:36 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-17 01:57:36 --> Model Class Initialized
DEBUG - 2011-04-17 01:57:36 --> Model Class Initialized
DEBUG - 2011-04-17 01:57:36 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-17 01:57:36 --> Database Driver Class Initialized
DEBUG - 2011-04-17 01:57:36 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-17 01:57:36 --> Helper loaded: url_helper
DEBUG - 2011-04-17 01:57:36 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-17 01:57:36 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-17 01:57:36 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-17 01:57:36 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-17 01:57:36 --> Final output sent to browser
DEBUG - 2011-04-17 01:57:36 --> Total execution time: 0.0997
DEBUG - 2011-04-17 02:26:28 --> Config Class Initialized
DEBUG - 2011-04-17 02:26:28 --> Hooks Class Initialized
DEBUG - 2011-04-17 02:26:28 --> Utf8 Class Initialized
DEBUG - 2011-04-17 02:26:28 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 02:26:28 --> URI Class Initialized
DEBUG - 2011-04-17 02:26:28 --> Router Class Initialized
DEBUG - 2011-04-17 02:26:28 --> Output Class Initialized
DEBUG - 2011-04-17 02:26:28 --> Input Class Initialized
DEBUG - 2011-04-17 02:26:28 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-17 02:26:28 --> Language Class Initialized
DEBUG - 2011-04-17 02:26:28 --> Loader Class Initialized
DEBUG - 2011-04-17 02:26:28 --> Controller Class Initialized
DEBUG - 2011-04-17 02:26:28 --> Model Class Initialized
DEBUG - 2011-04-17 02:26:28 --> Model Class Initialized
DEBUG - 2011-04-17 02:26:28 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-17 02:26:28 --> Database Driver Class Initialized
DEBUG - 2011-04-17 02:26:30 --> Final output sent to browser
DEBUG - 2011-04-17 02:26:30 --> Total execution time: 2.0450
DEBUG - 2011-04-17 03:10:52 --> Config Class Initialized
DEBUG - 2011-04-17 03:10:52 --> Hooks Class Initialized
DEBUG - 2011-04-17 03:10:52 --> Utf8 Class Initialized
DEBUG - 2011-04-17 03:10:52 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 03:10:52 --> URI Class Initialized
DEBUG - 2011-04-17 03:10:52 --> Router Class Initialized
DEBUG - 2011-04-17 03:10:52 --> No URI present. Default controller set.
DEBUG - 2011-04-17 03:10:52 --> Output Class Initialized
DEBUG - 2011-04-17 03:10:52 --> Input Class Initialized
DEBUG - 2011-04-17 03:10:52 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-17 03:10:52 --> Language Class Initialized
DEBUG - 2011-04-17 03:10:52 --> Loader Class Initialized
DEBUG - 2011-04-17 03:10:52 --> Controller Class Initialized
DEBUG - 2011-04-17 03:10:52 --> File loaded: application/views/splash/main.php
DEBUG - 2011-04-17 03:10:52 --> Helper loaded: url_helper
DEBUG - 2011-04-17 03:10:52 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-17 03:10:52 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-17 03:10:52 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-17 03:10:52 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-17 03:10:52 --> Final output sent to browser
DEBUG - 2011-04-17 03:10:52 --> Total execution time: 0.3313
DEBUG - 2011-04-17 03:11:02 --> Config Class Initialized
DEBUG - 2011-04-17 03:11:02 --> Hooks Class Initialized
DEBUG - 2011-04-17 03:11:02 --> Utf8 Class Initialized
DEBUG - 2011-04-17 03:11:02 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 03:11:02 --> URI Class Initialized
DEBUG - 2011-04-17 03:11:02 --> Router Class Initialized
DEBUG - 2011-04-17 03:11:02 --> Output Class Initialized
DEBUG - 2011-04-17 03:11:02 --> Input Class Initialized
DEBUG - 2011-04-17 03:11:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-17 03:11:02 --> Language Class Initialized
DEBUG - 2011-04-17 03:11:02 --> Loader Class Initialized
DEBUG - 2011-04-17 03:11:02 --> Controller Class Initialized
DEBUG - 2011-04-17 03:11:02 --> Model Class Initialized
DEBUG - 2011-04-17 03:11:02 --> Model Class Initialized
DEBUG - 2011-04-17 03:11:02 --> Model Class Initialized
DEBUG - 2011-04-17 03:11:02 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-17 03:11:02 --> Database Driver Class Initialized
DEBUG - 2011-04-17 03:11:04 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-17 03:11:04 --> Helper loaded: url_helper
DEBUG - 2011-04-17 03:11:04 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-17 03:11:04 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-17 03:11:04 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-17 03:11:04 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-17 03:11:04 --> Final output sent to browser
DEBUG - 2011-04-17 03:11:04 --> Total execution time: 1.7841
DEBUG - 2011-04-17 03:11:44 --> Config Class Initialized
DEBUG - 2011-04-17 03:11:44 --> Hooks Class Initialized
DEBUG - 2011-04-17 03:11:44 --> Utf8 Class Initialized
DEBUG - 2011-04-17 03:11:44 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 03:11:44 --> URI Class Initialized
DEBUG - 2011-04-17 03:11:44 --> Router Class Initialized
DEBUG - 2011-04-17 03:11:44 --> Output Class Initialized
DEBUG - 2011-04-17 03:11:44 --> Input Class Initialized
DEBUG - 2011-04-17 03:11:44 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-17 03:11:44 --> Language Class Initialized
DEBUG - 2011-04-17 03:11:44 --> Loader Class Initialized
DEBUG - 2011-04-17 03:11:44 --> Controller Class Initialized
DEBUG - 2011-04-17 03:11:44 --> Model Class Initialized
DEBUG - 2011-04-17 03:11:44 --> Model Class Initialized
DEBUG - 2011-04-17 03:11:44 --> Model Class Initialized
DEBUG - 2011-04-17 03:11:44 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-17 03:11:44 --> Database Driver Class Initialized
DEBUG - 2011-04-17 03:11:44 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-17 03:11:44 --> Helper loaded: url_helper
DEBUG - 2011-04-17 03:11:44 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-17 03:11:44 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-17 03:11:44 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-17 03:11:44 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-17 03:11:44 --> Final output sent to browser
DEBUG - 2011-04-17 03:11:44 --> Total execution time: 0.4204
DEBUG - 2011-04-17 03:11:47 --> Config Class Initialized
DEBUG - 2011-04-17 03:11:47 --> Hooks Class Initialized
DEBUG - 2011-04-17 03:11:47 --> Utf8 Class Initialized
DEBUG - 2011-04-17 03:11:47 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 03:11:47 --> URI Class Initialized
DEBUG - 2011-04-17 03:11:47 --> Router Class Initialized
DEBUG - 2011-04-17 03:11:47 --> Output Class Initialized
DEBUG - 2011-04-17 03:11:47 --> Input Class Initialized
DEBUG - 2011-04-17 03:11:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-17 03:11:47 --> Language Class Initialized
DEBUG - 2011-04-17 03:11:47 --> Loader Class Initialized
DEBUG - 2011-04-17 03:11:47 --> Controller Class Initialized
DEBUG - 2011-04-17 03:11:47 --> Model Class Initialized
DEBUG - 2011-04-17 03:11:47 --> Model Class Initialized
DEBUG - 2011-04-17 03:11:47 --> Model Class Initialized
DEBUG - 2011-04-17 03:11:47 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-17 03:11:47 --> Database Driver Class Initialized
DEBUG - 2011-04-17 03:11:47 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-17 03:11:47 --> Helper loaded: url_helper
DEBUG - 2011-04-17 03:11:47 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-17 03:11:47 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-17 03:11:47 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-17 03:11:47 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-17 03:11:47 --> Final output sent to browser
DEBUG - 2011-04-17 03:11:47 --> Total execution time: 0.0537
DEBUG - 2011-04-17 03:12:18 --> Config Class Initialized
DEBUG - 2011-04-17 03:12:18 --> Hooks Class Initialized
DEBUG - 2011-04-17 03:12:18 --> Utf8 Class Initialized
DEBUG - 2011-04-17 03:12:18 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 03:12:18 --> URI Class Initialized
DEBUG - 2011-04-17 03:12:18 --> Router Class Initialized
DEBUG - 2011-04-17 03:12:18 --> Output Class Initialized
DEBUG - 2011-04-17 03:12:18 --> Input Class Initialized
DEBUG - 2011-04-17 03:12:18 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-17 03:12:18 --> Language Class Initialized
DEBUG - 2011-04-17 03:12:18 --> Loader Class Initialized
DEBUG - 2011-04-17 03:12:18 --> Controller Class Initialized
DEBUG - 2011-04-17 03:12:18 --> Model Class Initialized
DEBUG - 2011-04-17 03:12:18 --> Model Class Initialized
DEBUG - 2011-04-17 03:12:18 --> Model Class Initialized
DEBUG - 2011-04-17 03:12:18 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-17 03:12:18 --> Database Driver Class Initialized
DEBUG - 2011-04-17 03:12:18 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-17 03:12:18 --> Helper loaded: url_helper
DEBUG - 2011-04-17 03:12:18 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-17 03:12:18 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-17 03:12:18 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-17 03:12:18 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-17 03:12:18 --> Final output sent to browser
DEBUG - 2011-04-17 03:12:18 --> Total execution time: 0.0525
DEBUG - 2011-04-17 03:12:38 --> Config Class Initialized
DEBUG - 2011-04-17 03:12:38 --> Hooks Class Initialized
DEBUG - 2011-04-17 03:12:38 --> Utf8 Class Initialized
DEBUG - 2011-04-17 03:12:38 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 03:12:38 --> URI Class Initialized
DEBUG - 2011-04-17 03:12:38 --> Router Class Initialized
DEBUG - 2011-04-17 03:12:38 --> Output Class Initialized
DEBUG - 2011-04-17 03:12:38 --> Input Class Initialized
DEBUG - 2011-04-17 03:12:38 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-17 03:12:38 --> Language Class Initialized
DEBUG - 2011-04-17 03:12:38 --> Loader Class Initialized
DEBUG - 2011-04-17 03:12:38 --> Controller Class Initialized
DEBUG - 2011-04-17 03:12:38 --> Model Class Initialized
DEBUG - 2011-04-17 03:12:38 --> Model Class Initialized
DEBUG - 2011-04-17 03:12:38 --> Model Class Initialized
DEBUG - 2011-04-17 03:12:38 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-17 03:12:38 --> Database Driver Class Initialized
DEBUG - 2011-04-17 03:12:41 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-17 03:12:41 --> Helper loaded: url_helper
DEBUG - 2011-04-17 03:12:41 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-17 03:12:41 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-17 03:12:41 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-17 03:12:41 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-17 03:12:41 --> Final output sent to browser
DEBUG - 2011-04-17 03:12:41 --> Total execution time: 3.4374
DEBUG - 2011-04-17 03:12:44 --> Config Class Initialized
DEBUG - 2011-04-17 03:12:44 --> Hooks Class Initialized
DEBUG - 2011-04-17 03:12:44 --> Utf8 Class Initialized
DEBUG - 2011-04-17 03:12:44 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 03:12:44 --> URI Class Initialized
DEBUG - 2011-04-17 03:12:44 --> Router Class Initialized
DEBUG - 2011-04-17 03:12:44 --> Output Class Initialized
DEBUG - 2011-04-17 03:12:44 --> Input Class Initialized
DEBUG - 2011-04-17 03:12:44 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-17 03:12:44 --> Language Class Initialized
DEBUG - 2011-04-17 03:12:44 --> Loader Class Initialized
DEBUG - 2011-04-17 03:12:44 --> Controller Class Initialized
DEBUG - 2011-04-17 03:12:44 --> Model Class Initialized
DEBUG - 2011-04-17 03:12:44 --> Model Class Initialized
DEBUG - 2011-04-17 03:12:44 --> Model Class Initialized
DEBUG - 2011-04-17 03:12:44 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-17 03:12:44 --> Database Driver Class Initialized
DEBUG - 2011-04-17 03:12:44 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-17 03:12:44 --> Helper loaded: url_helper
DEBUG - 2011-04-17 03:12:44 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-17 03:12:44 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-17 03:12:44 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-17 03:12:44 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-17 03:12:44 --> Final output sent to browser
DEBUG - 2011-04-17 03:12:44 --> Total execution time: 0.2638
DEBUG - 2011-04-17 03:13:31 --> Config Class Initialized
DEBUG - 2011-04-17 03:13:31 --> Hooks Class Initialized
DEBUG - 2011-04-17 03:13:31 --> Utf8 Class Initialized
DEBUG - 2011-04-17 03:13:31 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 03:13:31 --> URI Class Initialized
DEBUG - 2011-04-17 03:13:31 --> Router Class Initialized
DEBUG - 2011-04-17 03:13:31 --> Output Class Initialized
DEBUG - 2011-04-17 03:13:31 --> Input Class Initialized
DEBUG - 2011-04-17 03:13:31 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-17 03:13:31 --> Language Class Initialized
DEBUG - 2011-04-17 03:13:31 --> Loader Class Initialized
DEBUG - 2011-04-17 03:13:31 --> Controller Class Initialized
DEBUG - 2011-04-17 03:13:31 --> Model Class Initialized
DEBUG - 2011-04-17 03:13:31 --> Model Class Initialized
DEBUG - 2011-04-17 03:13:31 --> Model Class Initialized
DEBUG - 2011-04-17 03:13:31 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-17 03:13:31 --> Database Driver Class Initialized
DEBUG - 2011-04-17 03:13:35 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-17 03:13:35 --> Helper loaded: url_helper
DEBUG - 2011-04-17 03:13:35 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-17 03:13:35 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-17 03:13:35 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-17 03:13:35 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-17 03:13:35 --> Final output sent to browser
DEBUG - 2011-04-17 03:13:35 --> Total execution time: 3.9966
DEBUG - 2011-04-17 03:14:00 --> Config Class Initialized
DEBUG - 2011-04-17 03:14:00 --> Hooks Class Initialized
DEBUG - 2011-04-17 03:14:00 --> Utf8 Class Initialized
DEBUG - 2011-04-17 03:14:00 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 03:14:00 --> URI Class Initialized
DEBUG - 2011-04-17 03:14:00 --> Router Class Initialized
DEBUG - 2011-04-17 03:14:00 --> Output Class Initialized
DEBUG - 2011-04-17 03:14:00 --> Input Class Initialized
DEBUG - 2011-04-17 03:14:00 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-17 03:14:00 --> Language Class Initialized
DEBUG - 2011-04-17 03:14:00 --> Loader Class Initialized
DEBUG - 2011-04-17 03:14:00 --> Controller Class Initialized
DEBUG - 2011-04-17 03:14:00 --> Model Class Initialized
DEBUG - 2011-04-17 03:14:00 --> Model Class Initialized
DEBUG - 2011-04-17 03:14:00 --> Model Class Initialized
DEBUG - 2011-04-17 03:14:00 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-17 03:14:00 --> Database Driver Class Initialized
DEBUG - 2011-04-17 03:14:00 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-17 03:14:00 --> Helper loaded: url_helper
DEBUG - 2011-04-17 03:14:00 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-17 03:14:00 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-17 03:14:00 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-17 03:14:00 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-17 03:14:00 --> Final output sent to browser
DEBUG - 2011-04-17 03:14:00 --> Total execution time: 0.0465
DEBUG - 2011-04-17 03:14:12 --> Config Class Initialized
DEBUG - 2011-04-17 03:14:12 --> Hooks Class Initialized
DEBUG - 2011-04-17 03:14:12 --> Utf8 Class Initialized
DEBUG - 2011-04-17 03:14:12 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 03:14:12 --> URI Class Initialized
DEBUG - 2011-04-17 03:14:12 --> Router Class Initialized
DEBUG - 2011-04-17 03:14:12 --> Output Class Initialized
DEBUG - 2011-04-17 03:14:12 --> Input Class Initialized
DEBUG - 2011-04-17 03:14:12 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-17 03:14:12 --> Language Class Initialized
DEBUG - 2011-04-17 03:14:12 --> Loader Class Initialized
DEBUG - 2011-04-17 03:14:12 --> Controller Class Initialized
DEBUG - 2011-04-17 03:14:12 --> Model Class Initialized
DEBUG - 2011-04-17 03:14:12 --> Model Class Initialized
DEBUG - 2011-04-17 03:14:12 --> Model Class Initialized
DEBUG - 2011-04-17 03:14:12 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-17 03:14:12 --> Database Driver Class Initialized
DEBUG - 2011-04-17 03:14:14 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-17 03:14:14 --> Helper loaded: url_helper
DEBUG - 2011-04-17 03:14:14 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-17 03:14:14 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-17 03:14:14 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-17 03:14:14 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-17 03:14:14 --> Final output sent to browser
DEBUG - 2011-04-17 03:14:14 --> Total execution time: 2.1318
DEBUG - 2011-04-17 03:14:50 --> Config Class Initialized
DEBUG - 2011-04-17 03:14:50 --> Hooks Class Initialized
DEBUG - 2011-04-17 03:14:50 --> Utf8 Class Initialized
DEBUG - 2011-04-17 03:14:50 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 03:14:50 --> URI Class Initialized
DEBUG - 2011-04-17 03:14:50 --> Router Class Initialized
DEBUG - 2011-04-17 03:14:50 --> Output Class Initialized
DEBUG - 2011-04-17 03:14:50 --> Input Class Initialized
DEBUG - 2011-04-17 03:14:50 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-17 03:14:50 --> Language Class Initialized
DEBUG - 2011-04-17 03:14:50 --> Loader Class Initialized
DEBUG - 2011-04-17 03:14:50 --> Controller Class Initialized
DEBUG - 2011-04-17 03:14:50 --> Model Class Initialized
DEBUG - 2011-04-17 03:14:50 --> Model Class Initialized
DEBUG - 2011-04-17 03:14:50 --> Model Class Initialized
DEBUG - 2011-04-17 03:14:50 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-17 03:14:50 --> Database Driver Class Initialized
DEBUG - 2011-04-17 03:14:50 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-17 03:14:50 --> Helper loaded: url_helper
DEBUG - 2011-04-17 03:14:50 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-17 03:14:50 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-17 03:14:50 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-17 03:14:50 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-17 03:14:50 --> Final output sent to browser
DEBUG - 2011-04-17 03:14:50 --> Total execution time: 0.6022
DEBUG - 2011-04-17 03:15:23 --> Config Class Initialized
DEBUG - 2011-04-17 03:15:23 --> Hooks Class Initialized
DEBUG - 2011-04-17 03:15:23 --> Utf8 Class Initialized
DEBUG - 2011-04-17 03:15:23 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 03:15:23 --> URI Class Initialized
DEBUG - 2011-04-17 03:15:23 --> Router Class Initialized
DEBUG - 2011-04-17 03:15:23 --> Output Class Initialized
DEBUG - 2011-04-17 03:15:23 --> Input Class Initialized
DEBUG - 2011-04-17 03:15:23 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-17 03:15:23 --> Language Class Initialized
DEBUG - 2011-04-17 03:15:23 --> Loader Class Initialized
DEBUG - 2011-04-17 03:15:23 --> Controller Class Initialized
DEBUG - 2011-04-17 03:15:23 --> Model Class Initialized
DEBUG - 2011-04-17 03:15:23 --> Model Class Initialized
DEBUG - 2011-04-17 03:15:23 --> Model Class Initialized
DEBUG - 2011-04-17 03:15:23 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-17 03:15:23 --> Database Driver Class Initialized
DEBUG - 2011-04-17 03:15:25 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-17 03:15:25 --> Helper loaded: url_helper
DEBUG - 2011-04-17 03:15:25 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-17 03:15:25 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-17 03:15:25 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-17 03:15:25 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-17 03:15:25 --> Final output sent to browser
DEBUG - 2011-04-17 03:15:25 --> Total execution time: 1.4893
DEBUG - 2011-04-17 03:16:06 --> Config Class Initialized
DEBUG - 2011-04-17 03:16:06 --> Hooks Class Initialized
DEBUG - 2011-04-17 03:16:06 --> Utf8 Class Initialized
DEBUG - 2011-04-17 03:16:06 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 03:16:06 --> URI Class Initialized
DEBUG - 2011-04-17 03:16:06 --> Router Class Initialized
DEBUG - 2011-04-17 03:16:06 --> Output Class Initialized
DEBUG - 2011-04-17 03:16:06 --> Input Class Initialized
DEBUG - 2011-04-17 03:16:06 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-17 03:16:06 --> Language Class Initialized
DEBUG - 2011-04-17 03:16:06 --> Loader Class Initialized
DEBUG - 2011-04-17 03:16:06 --> Controller Class Initialized
DEBUG - 2011-04-17 03:16:06 --> Model Class Initialized
DEBUG - 2011-04-17 03:16:06 --> Model Class Initialized
DEBUG - 2011-04-17 03:16:06 --> Model Class Initialized
DEBUG - 2011-04-17 03:16:06 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-17 03:16:06 --> Database Driver Class Initialized
DEBUG - 2011-04-17 03:16:06 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-17 03:16:06 --> Helper loaded: url_helper
DEBUG - 2011-04-17 03:16:06 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-17 03:16:06 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-17 03:16:06 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-17 03:16:06 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-17 03:16:06 --> Final output sent to browser
DEBUG - 2011-04-17 03:16:06 --> Total execution time: 0.2525
DEBUG - 2011-04-17 03:16:34 --> Config Class Initialized
DEBUG - 2011-04-17 03:16:34 --> Hooks Class Initialized
DEBUG - 2011-04-17 03:16:34 --> Utf8 Class Initialized
DEBUG - 2011-04-17 03:16:34 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 03:16:34 --> URI Class Initialized
DEBUG - 2011-04-17 03:16:34 --> Router Class Initialized
DEBUG - 2011-04-17 03:16:34 --> Output Class Initialized
DEBUG - 2011-04-17 03:16:34 --> Input Class Initialized
DEBUG - 2011-04-17 03:16:34 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-17 03:16:34 --> Language Class Initialized
DEBUG - 2011-04-17 03:16:34 --> Loader Class Initialized
DEBUG - 2011-04-17 03:16:34 --> Controller Class Initialized
DEBUG - 2011-04-17 03:16:34 --> Model Class Initialized
DEBUG - 2011-04-17 03:16:34 --> Model Class Initialized
DEBUG - 2011-04-17 03:16:34 --> Model Class Initialized
DEBUG - 2011-04-17 03:16:34 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-17 03:16:34 --> Database Driver Class Initialized
DEBUG - 2011-04-17 03:16:37 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-17 03:16:37 --> Helper loaded: url_helper
DEBUG - 2011-04-17 03:16:37 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-17 03:16:37 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-17 03:16:37 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-17 03:16:37 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-17 03:16:37 --> Final output sent to browser
DEBUG - 2011-04-17 03:16:37 --> Total execution time: 2.8033
DEBUG - 2011-04-17 03:17:16 --> Config Class Initialized
DEBUG - 2011-04-17 03:17:16 --> Hooks Class Initialized
DEBUG - 2011-04-17 03:17:16 --> Utf8 Class Initialized
DEBUG - 2011-04-17 03:17:16 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 03:17:16 --> URI Class Initialized
DEBUG - 2011-04-17 03:17:16 --> Router Class Initialized
DEBUG - 2011-04-17 03:17:16 --> Output Class Initialized
DEBUG - 2011-04-17 03:17:16 --> Input Class Initialized
DEBUG - 2011-04-17 03:17:16 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-17 03:17:16 --> Language Class Initialized
DEBUG - 2011-04-17 03:17:16 --> Loader Class Initialized
DEBUG - 2011-04-17 03:17:16 --> Controller Class Initialized
DEBUG - 2011-04-17 03:17:16 --> Model Class Initialized
DEBUG - 2011-04-17 03:17:16 --> Model Class Initialized
DEBUG - 2011-04-17 03:17:16 --> Model Class Initialized
DEBUG - 2011-04-17 03:17:16 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-17 03:17:16 --> Database Driver Class Initialized
DEBUG - 2011-04-17 03:17:16 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-17 03:17:16 --> Helper loaded: url_helper
DEBUG - 2011-04-17 03:17:16 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-17 03:17:16 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-17 03:17:16 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-17 03:17:16 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-17 03:17:16 --> Final output sent to browser
DEBUG - 2011-04-17 03:17:16 --> Total execution time: 0.0525
DEBUG - 2011-04-17 03:17:20 --> Config Class Initialized
DEBUG - 2011-04-17 03:17:20 --> Hooks Class Initialized
DEBUG - 2011-04-17 03:17:20 --> Utf8 Class Initialized
DEBUG - 2011-04-17 03:17:20 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 03:17:20 --> URI Class Initialized
DEBUG - 2011-04-17 03:17:20 --> Router Class Initialized
DEBUG - 2011-04-17 03:17:20 --> Output Class Initialized
DEBUG - 2011-04-17 03:17:20 --> Input Class Initialized
DEBUG - 2011-04-17 03:17:20 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-17 03:17:20 --> Language Class Initialized
DEBUG - 2011-04-17 03:17:20 --> Loader Class Initialized
DEBUG - 2011-04-17 03:17:20 --> Controller Class Initialized
DEBUG - 2011-04-17 03:17:20 --> Model Class Initialized
DEBUG - 2011-04-17 03:17:20 --> Model Class Initialized
DEBUG - 2011-04-17 03:17:20 --> Model Class Initialized
DEBUG - 2011-04-17 03:17:20 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-17 03:17:20 --> Database Driver Class Initialized
DEBUG - 2011-04-17 03:17:20 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-17 03:17:20 --> Helper loaded: url_helper
DEBUG - 2011-04-17 03:17:20 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-17 03:17:20 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-17 03:17:20 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-17 03:17:20 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-17 03:17:20 --> Final output sent to browser
DEBUG - 2011-04-17 03:17:20 --> Total execution time: 0.0874
DEBUG - 2011-04-17 03:17:23 --> Config Class Initialized
DEBUG - 2011-04-17 03:17:23 --> Hooks Class Initialized
DEBUG - 2011-04-17 03:17:23 --> Utf8 Class Initialized
DEBUG - 2011-04-17 03:17:23 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 03:17:23 --> URI Class Initialized
DEBUG - 2011-04-17 03:17:23 --> Router Class Initialized
DEBUG - 2011-04-17 03:17:23 --> Output Class Initialized
DEBUG - 2011-04-17 03:17:23 --> Input Class Initialized
DEBUG - 2011-04-17 03:17:23 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-17 03:17:23 --> Language Class Initialized
DEBUG - 2011-04-17 03:17:23 --> Loader Class Initialized
DEBUG - 2011-04-17 03:17:23 --> Controller Class Initialized
DEBUG - 2011-04-17 03:17:23 --> Model Class Initialized
DEBUG - 2011-04-17 03:17:23 --> Model Class Initialized
DEBUG - 2011-04-17 03:17:23 --> Model Class Initialized
DEBUG - 2011-04-17 03:17:23 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-17 03:17:23 --> Database Driver Class Initialized
DEBUG - 2011-04-17 03:17:23 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-17 03:17:23 --> Helper loaded: url_helper
DEBUG - 2011-04-17 03:17:23 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-17 03:17:23 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-17 03:17:23 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-17 03:17:23 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-17 03:17:23 --> Final output sent to browser
DEBUG - 2011-04-17 03:17:23 --> Total execution time: 0.0469
DEBUG - 2011-04-17 03:17:26 --> Config Class Initialized
DEBUG - 2011-04-17 03:17:26 --> Hooks Class Initialized
DEBUG - 2011-04-17 03:17:26 --> Utf8 Class Initialized
DEBUG - 2011-04-17 03:17:26 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 03:17:26 --> URI Class Initialized
DEBUG - 2011-04-17 03:17:26 --> Router Class Initialized
DEBUG - 2011-04-17 03:17:26 --> Output Class Initialized
DEBUG - 2011-04-17 03:17:26 --> Input Class Initialized
DEBUG - 2011-04-17 03:17:26 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-17 03:17:26 --> Language Class Initialized
DEBUG - 2011-04-17 03:17:26 --> Loader Class Initialized
DEBUG - 2011-04-17 03:17:26 --> Controller Class Initialized
DEBUG - 2011-04-17 03:17:26 --> Model Class Initialized
DEBUG - 2011-04-17 03:17:26 --> Model Class Initialized
DEBUG - 2011-04-17 03:17:26 --> Model Class Initialized
DEBUG - 2011-04-17 03:17:26 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-17 03:17:26 --> Database Driver Class Initialized
DEBUG - 2011-04-17 03:17:26 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-17 03:17:26 --> Helper loaded: url_helper
DEBUG - 2011-04-17 03:17:26 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-17 03:17:26 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-17 03:17:26 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-17 03:17:26 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-17 03:17:26 --> Final output sent to browser
DEBUG - 2011-04-17 03:17:26 --> Total execution time: 0.0566
DEBUG - 2011-04-17 03:17:29 --> Config Class Initialized
DEBUG - 2011-04-17 03:17:29 --> Hooks Class Initialized
DEBUG - 2011-04-17 03:17:29 --> Utf8 Class Initialized
DEBUG - 2011-04-17 03:17:29 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 03:17:29 --> URI Class Initialized
DEBUG - 2011-04-17 03:17:29 --> Router Class Initialized
DEBUG - 2011-04-17 03:17:29 --> Output Class Initialized
DEBUG - 2011-04-17 03:17:29 --> Input Class Initialized
DEBUG - 2011-04-17 03:17:29 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-17 03:17:29 --> Language Class Initialized
DEBUG - 2011-04-17 03:17:29 --> Loader Class Initialized
DEBUG - 2011-04-17 03:17:29 --> Controller Class Initialized
DEBUG - 2011-04-17 03:17:29 --> Model Class Initialized
DEBUG - 2011-04-17 03:17:29 --> Model Class Initialized
DEBUG - 2011-04-17 03:17:29 --> Model Class Initialized
DEBUG - 2011-04-17 03:17:29 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-17 03:17:29 --> Database Driver Class Initialized
DEBUG - 2011-04-17 03:17:29 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-17 03:17:29 --> Helper loaded: url_helper
DEBUG - 2011-04-17 03:17:29 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-17 03:17:29 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-17 03:17:29 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-17 03:17:29 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-17 03:17:29 --> Final output sent to browser
DEBUG - 2011-04-17 03:17:29 --> Total execution time: 0.0459
DEBUG - 2011-04-17 03:17:51 --> Config Class Initialized
DEBUG - 2011-04-17 03:17:51 --> Hooks Class Initialized
DEBUG - 2011-04-17 03:17:51 --> Utf8 Class Initialized
DEBUG - 2011-04-17 03:17:51 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 03:17:51 --> URI Class Initialized
DEBUG - 2011-04-17 03:17:51 --> Router Class Initialized
DEBUG - 2011-04-17 03:17:51 --> Output Class Initialized
DEBUG - 2011-04-17 03:17:51 --> Input Class Initialized
DEBUG - 2011-04-17 03:17:51 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-17 03:17:51 --> Language Class Initialized
DEBUG - 2011-04-17 03:17:51 --> Loader Class Initialized
DEBUG - 2011-04-17 03:17:51 --> Controller Class Initialized
DEBUG - 2011-04-17 03:17:51 --> Model Class Initialized
DEBUG - 2011-04-17 03:17:51 --> Model Class Initialized
DEBUG - 2011-04-17 03:17:51 --> Model Class Initialized
DEBUG - 2011-04-17 03:17:51 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-17 03:17:51 --> Database Driver Class Initialized
DEBUG - 2011-04-17 03:17:51 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-17 03:17:51 --> Helper loaded: url_helper
DEBUG - 2011-04-17 03:17:51 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-17 03:17:51 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-17 03:17:51 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-17 03:17:51 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-17 03:17:51 --> Final output sent to browser
DEBUG - 2011-04-17 03:17:51 --> Total execution time: 0.3598
DEBUG - 2011-04-17 03:17:54 --> Config Class Initialized
DEBUG - 2011-04-17 03:17:54 --> Hooks Class Initialized
DEBUG - 2011-04-17 03:17:54 --> Utf8 Class Initialized
DEBUG - 2011-04-17 03:17:54 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 03:17:54 --> URI Class Initialized
DEBUG - 2011-04-17 03:17:54 --> Router Class Initialized
DEBUG - 2011-04-17 03:17:54 --> Output Class Initialized
DEBUG - 2011-04-17 03:17:54 --> Input Class Initialized
DEBUG - 2011-04-17 03:17:54 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-17 03:17:54 --> Language Class Initialized
DEBUG - 2011-04-17 03:17:54 --> Loader Class Initialized
DEBUG - 2011-04-17 03:17:54 --> Controller Class Initialized
DEBUG - 2011-04-17 03:17:54 --> Model Class Initialized
DEBUG - 2011-04-17 03:17:54 --> Model Class Initialized
DEBUG - 2011-04-17 03:17:54 --> Model Class Initialized
DEBUG - 2011-04-17 03:17:54 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-17 03:17:54 --> Database Driver Class Initialized
DEBUG - 2011-04-17 03:17:54 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-17 03:17:54 --> Helper loaded: url_helper
DEBUG - 2011-04-17 03:17:54 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-17 03:17:54 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-17 03:17:54 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-17 03:17:54 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-17 03:17:54 --> Final output sent to browser
DEBUG - 2011-04-17 03:17:54 --> Total execution time: 0.1523
DEBUG - 2011-04-17 03:18:20 --> Config Class Initialized
DEBUG - 2011-04-17 03:18:20 --> Hooks Class Initialized
DEBUG - 2011-04-17 03:18:20 --> Utf8 Class Initialized
DEBUG - 2011-04-17 03:18:20 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 03:18:20 --> URI Class Initialized
DEBUG - 2011-04-17 03:18:20 --> Router Class Initialized
DEBUG - 2011-04-17 03:18:20 --> Output Class Initialized
DEBUG - 2011-04-17 03:18:20 --> Input Class Initialized
DEBUG - 2011-04-17 03:18:20 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-17 03:18:20 --> Language Class Initialized
DEBUG - 2011-04-17 03:18:20 --> Loader Class Initialized
DEBUG - 2011-04-17 03:18:20 --> Controller Class Initialized
DEBUG - 2011-04-17 03:18:20 --> Model Class Initialized
DEBUG - 2011-04-17 03:18:20 --> Model Class Initialized
DEBUG - 2011-04-17 03:18:20 --> Model Class Initialized
DEBUG - 2011-04-17 03:18:20 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-17 03:18:20 --> Database Driver Class Initialized
DEBUG - 2011-04-17 03:18:22 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-17 03:18:22 --> Helper loaded: url_helper
DEBUG - 2011-04-17 03:18:22 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-17 03:18:22 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-17 03:18:22 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-17 03:18:22 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-17 03:18:22 --> Final output sent to browser
DEBUG - 2011-04-17 03:18:22 --> Total execution time: 1.3406
DEBUG - 2011-04-17 03:18:54 --> Config Class Initialized
DEBUG - 2011-04-17 03:18:54 --> Hooks Class Initialized
DEBUG - 2011-04-17 03:18:54 --> Utf8 Class Initialized
DEBUG - 2011-04-17 03:18:54 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 03:18:54 --> URI Class Initialized
DEBUG - 2011-04-17 03:18:54 --> Router Class Initialized
DEBUG - 2011-04-17 03:18:54 --> Output Class Initialized
DEBUG - 2011-04-17 03:18:54 --> Input Class Initialized
DEBUG - 2011-04-17 03:18:54 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-17 03:18:54 --> Language Class Initialized
DEBUG - 2011-04-17 03:18:54 --> Loader Class Initialized
DEBUG - 2011-04-17 03:18:54 --> Controller Class Initialized
DEBUG - 2011-04-17 03:18:54 --> Model Class Initialized
DEBUG - 2011-04-17 03:18:54 --> Model Class Initialized
DEBUG - 2011-04-17 03:18:54 --> Model Class Initialized
DEBUG - 2011-04-17 03:18:54 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-17 03:18:54 --> Database Driver Class Initialized
DEBUG - 2011-04-17 03:18:54 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-17 03:18:54 --> Helper loaded: url_helper
DEBUG - 2011-04-17 03:18:54 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-17 03:18:54 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-17 03:18:54 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-17 03:18:54 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-17 03:18:54 --> Final output sent to browser
DEBUG - 2011-04-17 03:18:54 --> Total execution time: 0.0539
DEBUG - 2011-04-17 03:19:03 --> Config Class Initialized
DEBUG - 2011-04-17 03:19:03 --> Hooks Class Initialized
DEBUG - 2011-04-17 03:19:03 --> Utf8 Class Initialized
DEBUG - 2011-04-17 03:19:03 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 03:19:03 --> URI Class Initialized
DEBUG - 2011-04-17 03:19:03 --> Router Class Initialized
DEBUG - 2011-04-17 03:19:03 --> Output Class Initialized
DEBUG - 2011-04-17 03:19:03 --> Input Class Initialized
DEBUG - 2011-04-17 03:19:03 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-17 03:19:03 --> Language Class Initialized
DEBUG - 2011-04-17 03:19:03 --> Loader Class Initialized
DEBUG - 2011-04-17 03:19:03 --> Controller Class Initialized
DEBUG - 2011-04-17 03:19:03 --> Model Class Initialized
DEBUG - 2011-04-17 03:19:03 --> Model Class Initialized
DEBUG - 2011-04-17 03:19:03 --> Model Class Initialized
DEBUG - 2011-04-17 03:19:03 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-17 03:19:03 --> Database Driver Class Initialized
DEBUG - 2011-04-17 03:19:03 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-17 03:19:03 --> Helper loaded: url_helper
DEBUG - 2011-04-17 03:19:03 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-17 03:19:03 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-17 03:19:03 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-17 03:19:03 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-17 03:19:03 --> Final output sent to browser
DEBUG - 2011-04-17 03:19:03 --> Total execution time: 0.3704
DEBUG - 2011-04-17 03:19:11 --> Config Class Initialized
DEBUG - 2011-04-17 03:19:11 --> Hooks Class Initialized
DEBUG - 2011-04-17 03:19:11 --> Utf8 Class Initialized
DEBUG - 2011-04-17 03:19:11 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 03:19:11 --> URI Class Initialized
DEBUG - 2011-04-17 03:19:11 --> Router Class Initialized
DEBUG - 2011-04-17 03:19:11 --> Output Class Initialized
DEBUG - 2011-04-17 03:19:11 --> Input Class Initialized
DEBUG - 2011-04-17 03:19:11 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-17 03:19:11 --> Language Class Initialized
DEBUG - 2011-04-17 03:19:11 --> Loader Class Initialized
DEBUG - 2011-04-17 03:19:11 --> Controller Class Initialized
DEBUG - 2011-04-17 03:19:11 --> Model Class Initialized
DEBUG - 2011-04-17 03:19:11 --> Model Class Initialized
DEBUG - 2011-04-17 03:19:11 --> Model Class Initialized
DEBUG - 2011-04-17 03:19:11 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-17 03:19:11 --> Database Driver Class Initialized
DEBUG - 2011-04-17 03:19:11 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-17 03:19:11 --> Helper loaded: url_helper
DEBUG - 2011-04-17 03:19:11 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-17 03:19:11 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-17 03:19:11 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-17 03:19:11 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-17 03:19:11 --> Final output sent to browser
DEBUG - 2011-04-17 03:19:11 --> Total execution time: 0.0427
DEBUG - 2011-04-17 03:20:07 --> Config Class Initialized
DEBUG - 2011-04-17 03:20:07 --> Hooks Class Initialized
DEBUG - 2011-04-17 03:20:07 --> Utf8 Class Initialized
DEBUG - 2011-04-17 03:20:07 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 03:20:07 --> URI Class Initialized
DEBUG - 2011-04-17 03:20:07 --> Router Class Initialized
DEBUG - 2011-04-17 03:20:07 --> Output Class Initialized
DEBUG - 2011-04-17 03:20:07 --> Input Class Initialized
DEBUG - 2011-04-17 03:20:07 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-17 03:20:07 --> Language Class Initialized
DEBUG - 2011-04-17 03:20:07 --> Loader Class Initialized
DEBUG - 2011-04-17 03:20:07 --> Controller Class Initialized
DEBUG - 2011-04-17 03:20:07 --> Model Class Initialized
DEBUG - 2011-04-17 03:20:07 --> Model Class Initialized
DEBUG - 2011-04-17 03:20:07 --> Model Class Initialized
DEBUG - 2011-04-17 03:20:07 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-17 03:20:07 --> Database Driver Class Initialized
DEBUG - 2011-04-17 03:20:08 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-17 03:20:08 --> Helper loaded: url_helper
DEBUG - 2011-04-17 03:20:08 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-17 03:20:08 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-17 03:20:08 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-17 03:20:08 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-17 03:20:08 --> Final output sent to browser
DEBUG - 2011-04-17 03:20:08 --> Total execution time: 0.8361
DEBUG - 2011-04-17 03:20:15 --> Config Class Initialized
DEBUG - 2011-04-17 03:20:15 --> Hooks Class Initialized
DEBUG - 2011-04-17 03:20:15 --> Utf8 Class Initialized
DEBUG - 2011-04-17 03:20:15 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 03:20:15 --> URI Class Initialized
DEBUG - 2011-04-17 03:20:15 --> Router Class Initialized
DEBUG - 2011-04-17 03:20:15 --> Output Class Initialized
DEBUG - 2011-04-17 03:20:15 --> Input Class Initialized
DEBUG - 2011-04-17 03:20:15 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-17 03:20:15 --> Language Class Initialized
DEBUG - 2011-04-17 03:20:15 --> Loader Class Initialized
DEBUG - 2011-04-17 03:20:15 --> Controller Class Initialized
DEBUG - 2011-04-17 03:20:15 --> Model Class Initialized
DEBUG - 2011-04-17 03:20:15 --> Model Class Initialized
DEBUG - 2011-04-17 03:20:15 --> Model Class Initialized
DEBUG - 2011-04-17 03:20:15 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-17 03:20:15 --> Database Driver Class Initialized
DEBUG - 2011-04-17 03:20:15 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-17 03:20:15 --> Helper loaded: url_helper
DEBUG - 2011-04-17 03:20:15 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-17 03:20:15 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-17 03:20:15 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-17 03:20:15 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-17 03:20:15 --> Final output sent to browser
DEBUG - 2011-04-17 03:20:15 --> Total execution time: 0.0504
DEBUG - 2011-04-17 03:20:44 --> Config Class Initialized
DEBUG - 2011-04-17 03:20:44 --> Hooks Class Initialized
DEBUG - 2011-04-17 03:20:44 --> Utf8 Class Initialized
DEBUG - 2011-04-17 03:20:44 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 03:20:44 --> URI Class Initialized
DEBUG - 2011-04-17 03:20:44 --> Router Class Initialized
DEBUG - 2011-04-17 03:20:44 --> Output Class Initialized
DEBUG - 2011-04-17 03:20:44 --> Input Class Initialized
DEBUG - 2011-04-17 03:20:44 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-17 03:20:44 --> Language Class Initialized
DEBUG - 2011-04-17 03:20:44 --> Loader Class Initialized
DEBUG - 2011-04-17 03:20:44 --> Controller Class Initialized
DEBUG - 2011-04-17 03:20:44 --> Model Class Initialized
DEBUG - 2011-04-17 03:20:44 --> Model Class Initialized
DEBUG - 2011-04-17 03:20:44 --> Model Class Initialized
DEBUG - 2011-04-17 03:20:44 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-17 03:20:44 --> Database Driver Class Initialized
DEBUG - 2011-04-17 03:20:46 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-17 03:20:46 --> Helper loaded: url_helper
DEBUG - 2011-04-17 03:20:46 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-17 03:20:46 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-17 03:20:46 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-17 03:20:46 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-17 03:20:46 --> Final output sent to browser
DEBUG - 2011-04-17 03:20:46 --> Total execution time: 1.7005
DEBUG - 2011-04-17 03:20:53 --> Config Class Initialized
DEBUG - 2011-04-17 03:20:53 --> Hooks Class Initialized
DEBUG - 2011-04-17 03:20:53 --> Utf8 Class Initialized
DEBUG - 2011-04-17 03:20:53 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 03:20:53 --> URI Class Initialized
DEBUG - 2011-04-17 03:20:53 --> Router Class Initialized
DEBUG - 2011-04-17 03:20:53 --> Output Class Initialized
DEBUG - 2011-04-17 03:20:53 --> Input Class Initialized
DEBUG - 2011-04-17 03:20:53 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-17 03:20:53 --> Language Class Initialized
DEBUG - 2011-04-17 03:20:53 --> Loader Class Initialized
DEBUG - 2011-04-17 03:20:53 --> Controller Class Initialized
DEBUG - 2011-04-17 03:20:53 --> Model Class Initialized
DEBUG - 2011-04-17 03:20:53 --> Model Class Initialized
DEBUG - 2011-04-17 03:20:53 --> Model Class Initialized
DEBUG - 2011-04-17 03:20:53 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-17 03:20:53 --> Database Driver Class Initialized
DEBUG - 2011-04-17 03:20:53 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-17 03:20:53 --> Helper loaded: url_helper
DEBUG - 2011-04-17 03:20:53 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-17 03:20:53 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-17 03:20:53 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-17 03:20:53 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-17 03:20:53 --> Final output sent to browser
DEBUG - 2011-04-17 03:20:53 --> Total execution time: 0.0631
DEBUG - 2011-04-17 03:20:57 --> Config Class Initialized
DEBUG - 2011-04-17 03:20:57 --> Hooks Class Initialized
DEBUG - 2011-04-17 03:20:57 --> Utf8 Class Initialized
DEBUG - 2011-04-17 03:20:57 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 03:20:57 --> URI Class Initialized
DEBUG - 2011-04-17 03:20:57 --> Router Class Initialized
DEBUG - 2011-04-17 03:20:57 --> Output Class Initialized
DEBUG - 2011-04-17 03:20:57 --> Input Class Initialized
DEBUG - 2011-04-17 03:20:57 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-17 03:20:57 --> Language Class Initialized
DEBUG - 2011-04-17 03:20:57 --> Loader Class Initialized
DEBUG - 2011-04-17 03:20:57 --> Controller Class Initialized
DEBUG - 2011-04-17 03:20:57 --> Model Class Initialized
DEBUG - 2011-04-17 03:20:57 --> Model Class Initialized
DEBUG - 2011-04-17 03:20:57 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-17 03:20:57 --> Database Driver Class Initialized
DEBUG - 2011-04-17 03:21:00 --> Final output sent to browser
DEBUG - 2011-04-17 03:21:00 --> Total execution time: 2.6988
DEBUG - 2011-04-17 03:21:31 --> Config Class Initialized
DEBUG - 2011-04-17 03:21:31 --> Hooks Class Initialized
DEBUG - 2011-04-17 03:21:31 --> Utf8 Class Initialized
DEBUG - 2011-04-17 03:21:31 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 03:21:31 --> URI Class Initialized
DEBUG - 2011-04-17 03:21:31 --> Router Class Initialized
DEBUG - 2011-04-17 03:21:31 --> Output Class Initialized
DEBUG - 2011-04-17 03:21:31 --> Input Class Initialized
DEBUG - 2011-04-17 03:21:31 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-17 03:21:31 --> Language Class Initialized
DEBUG - 2011-04-17 03:21:31 --> Loader Class Initialized
DEBUG - 2011-04-17 03:21:31 --> Controller Class Initialized
DEBUG - 2011-04-17 03:21:31 --> Model Class Initialized
DEBUG - 2011-04-17 03:21:31 --> Model Class Initialized
DEBUG - 2011-04-17 03:21:31 --> Model Class Initialized
DEBUG - 2011-04-17 03:21:31 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-17 03:21:31 --> Database Driver Class Initialized
DEBUG - 2011-04-17 03:21:32 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-17 03:21:32 --> Helper loaded: url_helper
DEBUG - 2011-04-17 03:21:32 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-17 03:21:32 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-17 03:21:32 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-17 03:21:32 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-17 03:21:32 --> Final output sent to browser
DEBUG - 2011-04-17 03:21:32 --> Total execution time: 1.2172
DEBUG - 2011-04-17 03:21:40 --> Config Class Initialized
DEBUG - 2011-04-17 03:21:40 --> Hooks Class Initialized
DEBUG - 2011-04-17 03:21:40 --> Utf8 Class Initialized
DEBUG - 2011-04-17 03:21:40 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 03:21:40 --> URI Class Initialized
DEBUG - 2011-04-17 03:21:40 --> Router Class Initialized
DEBUG - 2011-04-17 03:21:40 --> Output Class Initialized
DEBUG - 2011-04-17 03:21:40 --> Input Class Initialized
DEBUG - 2011-04-17 03:21:40 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-17 03:21:40 --> Language Class Initialized
DEBUG - 2011-04-17 03:21:40 --> Loader Class Initialized
DEBUG - 2011-04-17 03:21:40 --> Controller Class Initialized
DEBUG - 2011-04-17 03:21:40 --> Model Class Initialized
DEBUG - 2011-04-17 03:21:40 --> Model Class Initialized
DEBUG - 2011-04-17 03:21:40 --> Model Class Initialized
DEBUG - 2011-04-17 03:21:40 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-17 03:21:40 --> Database Driver Class Initialized
DEBUG - 2011-04-17 03:21:40 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-17 03:21:40 --> Helper loaded: url_helper
DEBUG - 2011-04-17 03:21:40 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-17 03:21:40 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-17 03:21:40 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-17 03:21:40 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-17 03:21:40 --> Final output sent to browser
DEBUG - 2011-04-17 03:21:40 --> Total execution time: 0.0445
DEBUG - 2011-04-17 03:22:07 --> Config Class Initialized
DEBUG - 2011-04-17 03:22:07 --> Hooks Class Initialized
DEBUG - 2011-04-17 03:22:07 --> Utf8 Class Initialized
DEBUG - 2011-04-17 03:22:07 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 03:22:07 --> URI Class Initialized
DEBUG - 2011-04-17 03:22:07 --> Router Class Initialized
DEBUG - 2011-04-17 03:22:07 --> Output Class Initialized
DEBUG - 2011-04-17 03:22:07 --> Input Class Initialized
DEBUG - 2011-04-17 03:22:07 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-17 03:22:07 --> Language Class Initialized
DEBUG - 2011-04-17 03:22:07 --> Loader Class Initialized
DEBUG - 2011-04-17 03:22:07 --> Controller Class Initialized
DEBUG - 2011-04-17 03:22:07 --> Model Class Initialized
DEBUG - 2011-04-17 03:22:07 --> Model Class Initialized
DEBUG - 2011-04-17 03:22:07 --> Model Class Initialized
DEBUG - 2011-04-17 03:22:07 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-17 03:22:07 --> Database Driver Class Initialized
DEBUG - 2011-04-17 03:22:08 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-17 03:22:08 --> Helper loaded: url_helper
DEBUG - 2011-04-17 03:22:08 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-17 03:22:08 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-17 03:22:08 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-17 03:22:08 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-17 03:22:08 --> Final output sent to browser
DEBUG - 2011-04-17 03:22:08 --> Total execution time: 0.2347
DEBUG - 2011-04-17 03:22:11 --> Config Class Initialized
DEBUG - 2011-04-17 03:22:11 --> Hooks Class Initialized
DEBUG - 2011-04-17 03:22:11 --> Utf8 Class Initialized
DEBUG - 2011-04-17 03:22:11 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 03:22:11 --> URI Class Initialized
DEBUG - 2011-04-17 03:22:11 --> Router Class Initialized
DEBUG - 2011-04-17 03:22:11 --> Output Class Initialized
DEBUG - 2011-04-17 03:22:11 --> Input Class Initialized
DEBUG - 2011-04-17 03:22:11 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-17 03:22:11 --> Language Class Initialized
DEBUG - 2011-04-17 03:22:11 --> Loader Class Initialized
DEBUG - 2011-04-17 03:22:11 --> Controller Class Initialized
DEBUG - 2011-04-17 03:22:11 --> Model Class Initialized
DEBUG - 2011-04-17 03:22:11 --> Model Class Initialized
DEBUG - 2011-04-17 03:22:11 --> Model Class Initialized
DEBUG - 2011-04-17 03:22:11 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-17 03:22:11 --> Database Driver Class Initialized
DEBUG - 2011-04-17 03:22:11 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-17 03:22:11 --> Helper loaded: url_helper
DEBUG - 2011-04-17 03:22:11 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-17 03:22:11 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-17 03:22:11 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-17 03:22:11 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-17 03:22:11 --> Final output sent to browser
DEBUG - 2011-04-17 03:22:11 --> Total execution time: 0.0518
DEBUG - 2011-04-17 03:22:29 --> Config Class Initialized
DEBUG - 2011-04-17 03:22:29 --> Hooks Class Initialized
DEBUG - 2011-04-17 03:22:29 --> Utf8 Class Initialized
DEBUG - 2011-04-17 03:22:29 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 03:22:29 --> URI Class Initialized
DEBUG - 2011-04-17 03:22:29 --> Router Class Initialized
DEBUG - 2011-04-17 03:22:29 --> Output Class Initialized
DEBUG - 2011-04-17 03:22:29 --> Input Class Initialized
DEBUG - 2011-04-17 03:22:29 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-17 03:22:29 --> Language Class Initialized
DEBUG - 2011-04-17 03:22:29 --> Loader Class Initialized
DEBUG - 2011-04-17 03:22:29 --> Controller Class Initialized
DEBUG - 2011-04-17 03:22:29 --> Model Class Initialized
DEBUG - 2011-04-17 03:22:29 --> Model Class Initialized
DEBUG - 2011-04-17 03:22:29 --> Model Class Initialized
DEBUG - 2011-04-17 03:22:29 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-17 03:22:29 --> Database Driver Class Initialized
DEBUG - 2011-04-17 03:22:29 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-17 03:22:29 --> Helper loaded: url_helper
DEBUG - 2011-04-17 03:22:29 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-17 03:22:29 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-17 03:22:29 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-17 03:22:29 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-17 03:22:29 --> Final output sent to browser
DEBUG - 2011-04-17 03:22:29 --> Total execution time: 0.3243
DEBUG - 2011-04-17 03:22:33 --> Config Class Initialized
DEBUG - 2011-04-17 03:22:33 --> Hooks Class Initialized
DEBUG - 2011-04-17 03:22:33 --> Utf8 Class Initialized
DEBUG - 2011-04-17 03:22:33 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 03:22:33 --> URI Class Initialized
DEBUG - 2011-04-17 03:22:33 --> Router Class Initialized
DEBUG - 2011-04-17 03:22:33 --> Output Class Initialized
DEBUG - 2011-04-17 03:22:33 --> Input Class Initialized
DEBUG - 2011-04-17 03:22:33 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-17 03:22:33 --> Language Class Initialized
DEBUG - 2011-04-17 03:22:33 --> Loader Class Initialized
DEBUG - 2011-04-17 03:22:33 --> Controller Class Initialized
DEBUG - 2011-04-17 03:22:33 --> Model Class Initialized
DEBUG - 2011-04-17 03:22:33 --> Model Class Initialized
DEBUG - 2011-04-17 03:22:33 --> Model Class Initialized
DEBUG - 2011-04-17 03:22:33 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-17 03:22:33 --> Database Driver Class Initialized
DEBUG - 2011-04-17 03:22:33 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-17 03:22:33 --> Helper loaded: url_helper
DEBUG - 2011-04-17 03:22:33 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-17 03:22:33 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-17 03:22:33 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-17 03:22:33 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-17 03:22:33 --> Final output sent to browser
DEBUG - 2011-04-17 03:22:33 --> Total execution time: 0.1135
DEBUG - 2011-04-17 03:22:48 --> Config Class Initialized
DEBUG - 2011-04-17 03:22:48 --> Hooks Class Initialized
DEBUG - 2011-04-17 03:22:48 --> Utf8 Class Initialized
DEBUG - 2011-04-17 03:22:48 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 03:22:48 --> URI Class Initialized
DEBUG - 2011-04-17 03:22:48 --> Router Class Initialized
DEBUG - 2011-04-17 03:22:48 --> Output Class Initialized
DEBUG - 2011-04-17 03:22:48 --> Input Class Initialized
DEBUG - 2011-04-17 03:22:48 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-17 03:22:48 --> Language Class Initialized
DEBUG - 2011-04-17 03:22:48 --> Loader Class Initialized
DEBUG - 2011-04-17 03:22:48 --> Controller Class Initialized
DEBUG - 2011-04-17 03:22:48 --> Model Class Initialized
DEBUG - 2011-04-17 03:22:48 --> Model Class Initialized
DEBUG - 2011-04-17 03:22:48 --> Model Class Initialized
DEBUG - 2011-04-17 03:22:48 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-17 03:22:48 --> Database Driver Class Initialized
DEBUG - 2011-04-17 03:22:48 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-17 03:22:48 --> Helper loaded: url_helper
DEBUG - 2011-04-17 03:22:48 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-17 03:22:48 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-17 03:22:48 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-17 03:22:48 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-17 03:22:48 --> Final output sent to browser
DEBUG - 2011-04-17 03:22:48 --> Total execution time: 0.2705
DEBUG - 2011-04-17 03:22:51 --> Config Class Initialized
DEBUG - 2011-04-17 03:22:51 --> Hooks Class Initialized
DEBUG - 2011-04-17 03:22:51 --> Utf8 Class Initialized
DEBUG - 2011-04-17 03:22:51 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 03:22:51 --> URI Class Initialized
DEBUG - 2011-04-17 03:22:51 --> Router Class Initialized
DEBUG - 2011-04-17 03:22:51 --> Output Class Initialized
DEBUG - 2011-04-17 03:22:51 --> Input Class Initialized
DEBUG - 2011-04-17 03:22:51 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-17 03:22:51 --> Language Class Initialized
DEBUG - 2011-04-17 03:22:51 --> Loader Class Initialized
DEBUG - 2011-04-17 03:22:51 --> Controller Class Initialized
DEBUG - 2011-04-17 03:22:51 --> Model Class Initialized
DEBUG - 2011-04-17 03:22:51 --> Model Class Initialized
DEBUG - 2011-04-17 03:22:51 --> Model Class Initialized
DEBUG - 2011-04-17 03:22:51 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-17 03:22:51 --> Database Driver Class Initialized
DEBUG - 2011-04-17 03:22:51 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-17 03:22:51 --> Helper loaded: url_helper
DEBUG - 2011-04-17 03:22:51 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-17 03:22:51 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-17 03:22:51 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-17 03:22:51 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-17 03:22:51 --> Final output sent to browser
DEBUG - 2011-04-17 03:22:51 --> Total execution time: 0.0519
DEBUG - 2011-04-17 03:23:32 --> Config Class Initialized
DEBUG - 2011-04-17 03:23:32 --> Hooks Class Initialized
DEBUG - 2011-04-17 03:23:32 --> Utf8 Class Initialized
DEBUG - 2011-04-17 03:23:32 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 03:23:32 --> URI Class Initialized
DEBUG - 2011-04-17 03:23:32 --> Router Class Initialized
DEBUG - 2011-04-17 03:23:32 --> Output Class Initialized
DEBUG - 2011-04-17 03:23:32 --> Input Class Initialized
DEBUG - 2011-04-17 03:23:32 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-17 03:23:32 --> Language Class Initialized
DEBUG - 2011-04-17 03:23:32 --> Loader Class Initialized
DEBUG - 2011-04-17 03:23:32 --> Controller Class Initialized
DEBUG - 2011-04-17 03:23:32 --> Model Class Initialized
DEBUG - 2011-04-17 03:23:32 --> Model Class Initialized
DEBUG - 2011-04-17 03:23:32 --> Model Class Initialized
DEBUG - 2011-04-17 03:23:32 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-17 03:23:32 --> Database Driver Class Initialized
DEBUG - 2011-04-17 03:23:37 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-17 03:23:37 --> Helper loaded: url_helper
DEBUG - 2011-04-17 03:23:37 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-17 03:23:37 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-17 03:23:37 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-17 03:23:37 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-17 03:23:37 --> Final output sent to browser
DEBUG - 2011-04-17 03:23:37 --> Total execution time: 4.6520
DEBUG - 2011-04-17 03:23:41 --> Config Class Initialized
DEBUG - 2011-04-17 03:23:41 --> Hooks Class Initialized
DEBUG - 2011-04-17 03:23:41 --> Utf8 Class Initialized
DEBUG - 2011-04-17 03:23:41 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 03:23:41 --> URI Class Initialized
DEBUG - 2011-04-17 03:23:41 --> Router Class Initialized
DEBUG - 2011-04-17 03:23:41 --> Output Class Initialized
DEBUG - 2011-04-17 03:23:41 --> Input Class Initialized
DEBUG - 2011-04-17 03:23:41 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-17 03:23:41 --> Language Class Initialized
DEBUG - 2011-04-17 03:23:41 --> Loader Class Initialized
DEBUG - 2011-04-17 03:23:41 --> Controller Class Initialized
DEBUG - 2011-04-17 03:23:41 --> Model Class Initialized
DEBUG - 2011-04-17 03:23:41 --> Model Class Initialized
DEBUG - 2011-04-17 03:23:41 --> Model Class Initialized
DEBUG - 2011-04-17 03:23:41 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-17 03:23:41 --> Database Driver Class Initialized
DEBUG - 2011-04-17 03:23:41 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-17 03:23:41 --> Helper loaded: url_helper
DEBUG - 2011-04-17 03:23:41 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-17 03:23:41 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-17 03:23:41 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-17 03:23:41 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-17 03:23:41 --> Final output sent to browser
DEBUG - 2011-04-17 03:23:41 --> Total execution time: 0.0611
DEBUG - 2011-04-17 03:23:53 --> Config Class Initialized
DEBUG - 2011-04-17 03:23:53 --> Hooks Class Initialized
DEBUG - 2011-04-17 03:23:53 --> Utf8 Class Initialized
DEBUG - 2011-04-17 03:23:53 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 03:23:53 --> URI Class Initialized
DEBUG - 2011-04-17 03:23:53 --> Router Class Initialized
DEBUG - 2011-04-17 03:23:53 --> Output Class Initialized
DEBUG - 2011-04-17 03:23:53 --> Input Class Initialized
DEBUG - 2011-04-17 03:23:53 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-17 03:23:53 --> Language Class Initialized
DEBUG - 2011-04-17 03:23:53 --> Loader Class Initialized
DEBUG - 2011-04-17 03:23:53 --> Controller Class Initialized
DEBUG - 2011-04-17 03:23:53 --> Model Class Initialized
DEBUG - 2011-04-17 03:23:53 --> Model Class Initialized
DEBUG - 2011-04-17 03:23:53 --> Model Class Initialized
DEBUG - 2011-04-17 03:23:53 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-17 03:23:53 --> Database Driver Class Initialized
DEBUG - 2011-04-17 03:23:53 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-17 03:23:53 --> Helper loaded: url_helper
DEBUG - 2011-04-17 03:23:53 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-17 03:23:53 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-17 03:23:53 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-17 03:23:53 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-17 03:23:53 --> Final output sent to browser
DEBUG - 2011-04-17 03:23:53 --> Total execution time: 0.1198
DEBUG - 2011-04-17 03:24:34 --> Config Class Initialized
DEBUG - 2011-04-17 03:24:34 --> Hooks Class Initialized
DEBUG - 2011-04-17 03:24:34 --> Utf8 Class Initialized
DEBUG - 2011-04-17 03:24:34 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 03:24:34 --> URI Class Initialized
DEBUG - 2011-04-17 03:24:34 --> Router Class Initialized
DEBUG - 2011-04-17 03:24:34 --> Output Class Initialized
DEBUG - 2011-04-17 03:24:34 --> Input Class Initialized
DEBUG - 2011-04-17 03:24:34 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-17 03:24:34 --> Language Class Initialized
DEBUG - 2011-04-17 03:24:34 --> Loader Class Initialized
DEBUG - 2011-04-17 03:24:34 --> Controller Class Initialized
DEBUG - 2011-04-17 03:24:34 --> Model Class Initialized
DEBUG - 2011-04-17 03:24:34 --> Model Class Initialized
DEBUG - 2011-04-17 03:24:34 --> Model Class Initialized
DEBUG - 2011-04-17 03:24:34 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-17 03:24:34 --> Database Driver Class Initialized
DEBUG - 2011-04-17 03:24:34 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-17 03:24:34 --> Helper loaded: url_helper
DEBUG - 2011-04-17 03:24:34 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-17 03:24:34 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-17 03:24:34 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-17 03:24:34 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-17 03:24:34 --> Final output sent to browser
DEBUG - 2011-04-17 03:24:34 --> Total execution time: 0.0513
DEBUG - 2011-04-17 03:25:25 --> Config Class Initialized
DEBUG - 2011-04-17 03:25:25 --> Hooks Class Initialized
DEBUG - 2011-04-17 03:25:25 --> Utf8 Class Initialized
DEBUG - 2011-04-17 03:25:25 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 03:25:25 --> URI Class Initialized
DEBUG - 2011-04-17 03:25:25 --> Router Class Initialized
DEBUG - 2011-04-17 03:25:25 --> Output Class Initialized
DEBUG - 2011-04-17 03:25:25 --> Input Class Initialized
DEBUG - 2011-04-17 03:25:25 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-17 03:25:25 --> Language Class Initialized
DEBUG - 2011-04-17 03:25:25 --> Loader Class Initialized
DEBUG - 2011-04-17 03:25:25 --> Controller Class Initialized
DEBUG - 2011-04-17 03:25:25 --> Model Class Initialized
DEBUG - 2011-04-17 03:25:25 --> Model Class Initialized
DEBUG - 2011-04-17 03:25:25 --> Model Class Initialized
DEBUG - 2011-04-17 03:25:25 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-17 03:25:25 --> Database Driver Class Initialized
DEBUG - 2011-04-17 03:25:25 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-17 03:25:25 --> Helper loaded: url_helper
DEBUG - 2011-04-17 03:25:25 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-17 03:25:25 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-17 03:25:25 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-17 03:25:25 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-17 03:25:25 --> Final output sent to browser
DEBUG - 2011-04-17 03:25:25 --> Total execution time: 0.4825
DEBUG - 2011-04-17 03:25:28 --> Config Class Initialized
DEBUG - 2011-04-17 03:25:28 --> Hooks Class Initialized
DEBUG - 2011-04-17 03:25:28 --> Utf8 Class Initialized
DEBUG - 2011-04-17 03:25:28 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 03:25:28 --> URI Class Initialized
DEBUG - 2011-04-17 03:25:28 --> Router Class Initialized
DEBUG - 2011-04-17 03:25:28 --> Output Class Initialized
DEBUG - 2011-04-17 03:25:28 --> Input Class Initialized
DEBUG - 2011-04-17 03:25:28 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-17 03:25:28 --> Language Class Initialized
DEBUG - 2011-04-17 03:25:28 --> Loader Class Initialized
DEBUG - 2011-04-17 03:25:28 --> Controller Class Initialized
DEBUG - 2011-04-17 03:25:28 --> Model Class Initialized
DEBUG - 2011-04-17 03:25:28 --> Model Class Initialized
DEBUG - 2011-04-17 03:25:28 --> Model Class Initialized
DEBUG - 2011-04-17 03:25:28 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-17 03:25:28 --> Database Driver Class Initialized
DEBUG - 2011-04-17 03:25:28 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-17 03:25:28 --> Helper loaded: url_helper
DEBUG - 2011-04-17 03:25:28 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-17 03:25:28 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-17 03:25:28 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-17 03:25:28 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-17 03:25:28 --> Final output sent to browser
DEBUG - 2011-04-17 03:25:28 --> Total execution time: 0.2340
DEBUG - 2011-04-17 03:25:29 --> Config Class Initialized
DEBUG - 2011-04-17 03:25:29 --> Hooks Class Initialized
DEBUG - 2011-04-17 03:25:29 --> Utf8 Class Initialized
DEBUG - 2011-04-17 03:25:29 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 03:25:29 --> URI Class Initialized
DEBUG - 2011-04-17 03:25:29 --> Router Class Initialized
DEBUG - 2011-04-17 03:25:29 --> Output Class Initialized
DEBUG - 2011-04-17 03:25:29 --> Input Class Initialized
DEBUG - 2011-04-17 03:25:29 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-17 03:25:29 --> Language Class Initialized
DEBUG - 2011-04-17 03:25:29 --> Loader Class Initialized
DEBUG - 2011-04-17 03:25:29 --> Controller Class Initialized
DEBUG - 2011-04-17 03:25:29 --> Model Class Initialized
DEBUG - 2011-04-17 03:25:29 --> Model Class Initialized
DEBUG - 2011-04-17 03:25:29 --> Model Class Initialized
DEBUG - 2011-04-17 03:25:29 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-17 03:25:29 --> Database Driver Class Initialized
DEBUG - 2011-04-17 03:25:29 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-17 03:25:29 --> Helper loaded: url_helper
DEBUG - 2011-04-17 03:25:29 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-17 03:25:29 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-17 03:25:29 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-17 03:25:29 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-17 03:25:29 --> Final output sent to browser
DEBUG - 2011-04-17 03:25:29 --> Total execution time: 0.2811
DEBUG - 2011-04-17 04:36:02 --> Config Class Initialized
DEBUG - 2011-04-17 04:36:02 --> Hooks Class Initialized
DEBUG - 2011-04-17 04:36:02 --> Utf8 Class Initialized
DEBUG - 2011-04-17 04:36:02 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 04:36:02 --> URI Class Initialized
DEBUG - 2011-04-17 04:36:02 --> Router Class Initialized
DEBUG - 2011-04-17 04:36:02 --> No URI present. Default controller set.
DEBUG - 2011-04-17 04:36:02 --> Output Class Initialized
DEBUG - 2011-04-17 04:36:02 --> Input Class Initialized
DEBUG - 2011-04-17 04:36:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-17 04:36:02 --> Language Class Initialized
DEBUG - 2011-04-17 04:36:02 --> Loader Class Initialized
DEBUG - 2011-04-17 04:36:02 --> Controller Class Initialized
DEBUG - 2011-04-17 04:36:02 --> File loaded: application/views/splash/main.php
DEBUG - 2011-04-17 04:36:02 --> Helper loaded: url_helper
DEBUG - 2011-04-17 04:36:02 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-17 04:36:02 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-17 04:36:02 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-17 04:36:02 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-17 04:36:02 --> Final output sent to browser
DEBUG - 2011-04-17 04:36:02 --> Total execution time: 0.4509
DEBUG - 2011-04-17 04:56:47 --> Config Class Initialized
DEBUG - 2011-04-17 04:56:47 --> Hooks Class Initialized
DEBUG - 2011-04-17 04:56:47 --> Utf8 Class Initialized
DEBUG - 2011-04-17 04:56:47 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 04:56:47 --> URI Class Initialized
DEBUG - 2011-04-17 04:56:47 --> Router Class Initialized
DEBUG - 2011-04-17 04:56:47 --> Output Class Initialized
DEBUG - 2011-04-17 04:56:47 --> Input Class Initialized
DEBUG - 2011-04-17 04:56:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-17 04:56:47 --> Language Class Initialized
DEBUG - 2011-04-17 04:56:47 --> Loader Class Initialized
DEBUG - 2011-04-17 04:56:47 --> Controller Class Initialized
DEBUG - 2011-04-17 04:56:47 --> Model Class Initialized
DEBUG - 2011-04-17 04:56:47 --> Model Class Initialized
DEBUG - 2011-04-17 04:56:47 --> Model Class Initialized
DEBUG - 2011-04-17 04:56:47 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-17 04:56:47 --> Database Driver Class Initialized
DEBUG - 2011-04-17 04:56:48 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-17 04:56:48 --> Helper loaded: url_helper
DEBUG - 2011-04-17 04:56:48 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-17 04:56:48 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-17 04:56:48 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-17 04:56:48 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-17 04:56:48 --> Final output sent to browser
DEBUG - 2011-04-17 04:56:48 --> Total execution time: 1.4067
DEBUG - 2011-04-17 04:56:50 --> Config Class Initialized
DEBUG - 2011-04-17 04:56:50 --> Hooks Class Initialized
DEBUG - 2011-04-17 04:56:50 --> Utf8 Class Initialized
DEBUG - 2011-04-17 04:56:50 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 04:56:50 --> URI Class Initialized
DEBUG - 2011-04-17 04:56:50 --> Router Class Initialized
DEBUG - 2011-04-17 04:56:50 --> Output Class Initialized
DEBUG - 2011-04-17 04:56:50 --> Input Class Initialized
DEBUG - 2011-04-17 04:56:50 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-17 04:56:50 --> Language Class Initialized
DEBUG - 2011-04-17 04:56:50 --> Loader Class Initialized
DEBUG - 2011-04-17 04:56:50 --> Controller Class Initialized
ERROR - 2011-04-17 04:56:51 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-17 04:56:51 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-17 04:56:51 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-17 04:56:51 --> Model Class Initialized
DEBUG - 2011-04-17 04:56:51 --> Model Class Initialized
DEBUG - 2011-04-17 04:56:51 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-17 04:56:51 --> Database Driver Class Initialized
DEBUG - 2011-04-17 04:56:51 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-17 04:56:51 --> Helper loaded: url_helper
DEBUG - 2011-04-17 04:56:51 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-17 04:56:51 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-17 04:56:51 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-17 04:56:51 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-17 04:56:51 --> Final output sent to browser
DEBUG - 2011-04-17 04:56:51 --> Total execution time: 0.1606
DEBUG - 2011-04-17 05:50:20 --> Config Class Initialized
DEBUG - 2011-04-17 05:50:20 --> Hooks Class Initialized
DEBUG - 2011-04-17 05:50:20 --> Utf8 Class Initialized
DEBUG - 2011-04-17 05:50:20 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 05:50:20 --> URI Class Initialized
DEBUG - 2011-04-17 05:50:20 --> Router Class Initialized
DEBUG - 2011-04-17 05:50:21 --> Output Class Initialized
DEBUG - 2011-04-17 05:50:22 --> Input Class Initialized
DEBUG - 2011-04-17 05:50:22 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-17 05:50:22 --> Language Class Initialized
DEBUG - 2011-04-17 05:50:22 --> Loader Class Initialized
DEBUG - 2011-04-17 05:50:22 --> Controller Class Initialized
DEBUG - 2011-04-17 05:50:22 --> Model Class Initialized
DEBUG - 2011-04-17 05:50:23 --> Model Class Initialized
DEBUG - 2011-04-17 05:50:24 --> Model Class Initialized
DEBUG - 2011-04-17 05:50:24 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-17 05:50:24 --> Database Driver Class Initialized
DEBUG - 2011-04-17 05:50:25 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-17 05:50:25 --> Helper loaded: url_helper
DEBUG - 2011-04-17 05:50:25 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-17 05:50:25 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-17 05:50:25 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-17 05:50:25 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-17 05:50:25 --> Final output sent to browser
DEBUG - 2011-04-17 05:50:25 --> Total execution time: 7.5901
DEBUG - 2011-04-17 05:56:29 --> Config Class Initialized
DEBUG - 2011-04-17 05:56:29 --> Hooks Class Initialized
DEBUG - 2011-04-17 05:56:29 --> Utf8 Class Initialized
DEBUG - 2011-04-17 05:56:29 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 05:56:29 --> URI Class Initialized
DEBUG - 2011-04-17 05:56:29 --> Router Class Initialized
DEBUG - 2011-04-17 05:56:29 --> Output Class Initialized
DEBUG - 2011-04-17 05:56:29 --> Input Class Initialized
DEBUG - 2011-04-17 05:56:29 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-17 05:56:29 --> Language Class Initialized
DEBUG - 2011-04-17 05:56:29 --> Loader Class Initialized
DEBUG - 2011-04-17 05:56:29 --> Controller Class Initialized
ERROR - 2011-04-17 05:56:29 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-17 05:56:29 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-17 05:56:29 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-17 05:56:29 --> Model Class Initialized
DEBUG - 2011-04-17 05:56:29 --> Model Class Initialized
DEBUG - 2011-04-17 05:56:29 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-17 05:56:29 --> Database Driver Class Initialized
DEBUG - 2011-04-17 05:56:29 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-17 05:56:29 --> Helper loaded: url_helper
DEBUG - 2011-04-17 05:56:29 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-17 05:56:29 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-17 05:56:29 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-17 05:56:29 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-17 05:56:29 --> Final output sent to browser
DEBUG - 2011-04-17 05:56:29 --> Total execution time: 0.3184
DEBUG - 2011-04-17 05:56:30 --> Config Class Initialized
DEBUG - 2011-04-17 05:56:30 --> Hooks Class Initialized
DEBUG - 2011-04-17 05:56:30 --> Utf8 Class Initialized
DEBUG - 2011-04-17 05:56:30 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 05:56:30 --> URI Class Initialized
DEBUG - 2011-04-17 05:56:30 --> Router Class Initialized
DEBUG - 2011-04-17 05:56:30 --> Output Class Initialized
DEBUG - 2011-04-17 05:56:30 --> Input Class Initialized
DEBUG - 2011-04-17 05:56:30 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-17 05:56:30 --> Language Class Initialized
DEBUG - 2011-04-17 05:56:30 --> Loader Class Initialized
DEBUG - 2011-04-17 05:56:30 --> Controller Class Initialized
DEBUG - 2011-04-17 05:56:30 --> Model Class Initialized
DEBUG - 2011-04-17 05:56:30 --> Model Class Initialized
DEBUG - 2011-04-17 05:56:30 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-17 05:56:30 --> Database Driver Class Initialized
DEBUG - 2011-04-17 05:56:31 --> Final output sent to browser
DEBUG - 2011-04-17 05:56:31 --> Total execution time: 0.9142
DEBUG - 2011-04-17 05:56:32 --> Config Class Initialized
DEBUG - 2011-04-17 05:56:32 --> Hooks Class Initialized
DEBUG - 2011-04-17 05:56:32 --> Utf8 Class Initialized
DEBUG - 2011-04-17 05:56:32 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 05:56:32 --> URI Class Initialized
DEBUG - 2011-04-17 05:56:32 --> Router Class Initialized
ERROR - 2011-04-17 05:56:32 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-17 05:56:33 --> Config Class Initialized
DEBUG - 2011-04-17 05:56:33 --> Hooks Class Initialized
DEBUG - 2011-04-17 05:56:33 --> Utf8 Class Initialized
DEBUG - 2011-04-17 05:56:33 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 05:56:33 --> URI Class Initialized
DEBUG - 2011-04-17 05:56:33 --> Router Class Initialized
ERROR - 2011-04-17 05:56:33 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-17 05:56:46 --> Config Class Initialized
DEBUG - 2011-04-17 05:56:46 --> Hooks Class Initialized
DEBUG - 2011-04-17 05:56:46 --> Utf8 Class Initialized
DEBUG - 2011-04-17 05:56:46 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 05:56:46 --> URI Class Initialized
DEBUG - 2011-04-17 05:56:46 --> Router Class Initialized
DEBUG - 2011-04-17 05:56:46 --> Output Class Initialized
DEBUG - 2011-04-17 05:56:46 --> Input Class Initialized
DEBUG - 2011-04-17 05:56:46 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-17 05:56:46 --> Language Class Initialized
DEBUG - 2011-04-17 05:56:46 --> Loader Class Initialized
DEBUG - 2011-04-17 05:56:46 --> Controller Class Initialized
ERROR - 2011-04-17 05:56:46 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-17 05:56:46 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-17 05:56:46 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-17 05:56:46 --> Model Class Initialized
DEBUG - 2011-04-17 05:56:46 --> Model Class Initialized
DEBUG - 2011-04-17 05:56:46 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-17 05:56:46 --> Database Driver Class Initialized
DEBUG - 2011-04-17 05:56:46 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-17 05:56:46 --> Helper loaded: url_helper
DEBUG - 2011-04-17 05:56:46 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-17 05:56:46 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-17 05:56:46 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-17 05:56:46 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-17 05:56:46 --> Final output sent to browser
DEBUG - 2011-04-17 05:56:46 --> Total execution time: 0.0321
DEBUG - 2011-04-17 05:56:47 --> Config Class Initialized
DEBUG - 2011-04-17 05:56:47 --> Hooks Class Initialized
DEBUG - 2011-04-17 05:56:47 --> Utf8 Class Initialized
DEBUG - 2011-04-17 05:56:47 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 05:56:47 --> URI Class Initialized
DEBUG - 2011-04-17 05:56:47 --> Router Class Initialized
DEBUG - 2011-04-17 05:56:47 --> Output Class Initialized
DEBUG - 2011-04-17 05:56:47 --> Input Class Initialized
DEBUG - 2011-04-17 05:56:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-17 05:56:47 --> Language Class Initialized
DEBUG - 2011-04-17 05:56:47 --> Loader Class Initialized
DEBUG - 2011-04-17 05:56:47 --> Controller Class Initialized
DEBUG - 2011-04-17 05:56:47 --> Model Class Initialized
DEBUG - 2011-04-17 05:56:47 --> Model Class Initialized
DEBUG - 2011-04-17 05:56:47 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-17 05:56:47 --> Database Driver Class Initialized
DEBUG - 2011-04-17 05:56:48 --> Final output sent to browser
DEBUG - 2011-04-17 05:56:48 --> Total execution time: 0.9198
DEBUG - 2011-04-17 05:57:01 --> Config Class Initialized
DEBUG - 2011-04-17 05:57:01 --> Hooks Class Initialized
DEBUG - 2011-04-17 05:57:01 --> Utf8 Class Initialized
DEBUG - 2011-04-17 05:57:01 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 05:57:01 --> URI Class Initialized
DEBUG - 2011-04-17 05:57:01 --> Router Class Initialized
DEBUG - 2011-04-17 05:57:01 --> Output Class Initialized
DEBUG - 2011-04-17 05:57:01 --> Input Class Initialized
DEBUG - 2011-04-17 05:57:01 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-17 05:57:01 --> Language Class Initialized
DEBUG - 2011-04-17 05:57:01 --> Loader Class Initialized
DEBUG - 2011-04-17 05:57:01 --> Controller Class Initialized
ERROR - 2011-04-17 05:57:01 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-17 05:57:01 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-17 05:57:01 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-17 05:57:01 --> Model Class Initialized
DEBUG - 2011-04-17 05:57:01 --> Model Class Initialized
DEBUG - 2011-04-17 05:57:01 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-17 05:57:01 --> Database Driver Class Initialized
DEBUG - 2011-04-17 05:57:01 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-17 05:57:01 --> Helper loaded: url_helper
DEBUG - 2011-04-17 05:57:01 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-17 05:57:01 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-17 05:57:01 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-17 05:57:01 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-17 05:57:01 --> Final output sent to browser
DEBUG - 2011-04-17 05:57:01 --> Total execution time: 0.0709
DEBUG - 2011-04-17 05:57:02 --> Config Class Initialized
DEBUG - 2011-04-17 05:57:02 --> Hooks Class Initialized
DEBUG - 2011-04-17 05:57:02 --> Utf8 Class Initialized
DEBUG - 2011-04-17 05:57:02 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 05:57:02 --> URI Class Initialized
DEBUG - 2011-04-17 05:57:02 --> Router Class Initialized
DEBUG - 2011-04-17 05:57:02 --> Output Class Initialized
DEBUG - 2011-04-17 05:57:02 --> Input Class Initialized
DEBUG - 2011-04-17 05:57:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-17 05:57:02 --> Language Class Initialized
DEBUG - 2011-04-17 05:57:02 --> Loader Class Initialized
DEBUG - 2011-04-17 05:57:02 --> Controller Class Initialized
DEBUG - 2011-04-17 05:57:02 --> Model Class Initialized
DEBUG - 2011-04-17 05:57:02 --> Model Class Initialized
DEBUG - 2011-04-17 05:57:02 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-17 05:57:02 --> Database Driver Class Initialized
DEBUG - 2011-04-17 05:57:02 --> Final output sent to browser
DEBUG - 2011-04-17 05:57:02 --> Total execution time: 0.6017
DEBUG - 2011-04-17 05:57:19 --> Config Class Initialized
DEBUG - 2011-04-17 05:57:19 --> Hooks Class Initialized
DEBUG - 2011-04-17 05:57:19 --> Utf8 Class Initialized
DEBUG - 2011-04-17 05:57:19 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 05:57:19 --> URI Class Initialized
DEBUG - 2011-04-17 05:57:19 --> Router Class Initialized
DEBUG - 2011-04-17 05:57:19 --> Output Class Initialized
DEBUG - 2011-04-17 05:57:19 --> Input Class Initialized
DEBUG - 2011-04-17 05:57:19 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-17 05:57:19 --> Language Class Initialized
DEBUG - 2011-04-17 05:57:19 --> Loader Class Initialized
DEBUG - 2011-04-17 05:57:19 --> Controller Class Initialized
ERROR - 2011-04-17 05:57:19 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-17 05:57:19 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-17 05:57:19 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-17 05:57:19 --> Model Class Initialized
DEBUG - 2011-04-17 05:57:19 --> Model Class Initialized
DEBUG - 2011-04-17 05:57:19 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-17 05:57:19 --> Database Driver Class Initialized
DEBUG - 2011-04-17 05:57:19 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-17 05:57:19 --> Helper loaded: url_helper
DEBUG - 2011-04-17 05:57:19 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-17 05:57:19 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-17 05:57:19 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-17 05:57:19 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-17 05:57:19 --> Final output sent to browser
DEBUG - 2011-04-17 05:57:19 --> Total execution time: 0.0301
DEBUG - 2011-04-17 05:57:19 --> Config Class Initialized
DEBUG - 2011-04-17 05:57:19 --> Hooks Class Initialized
DEBUG - 2011-04-17 05:57:19 --> Utf8 Class Initialized
DEBUG - 2011-04-17 05:57:19 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 05:57:19 --> URI Class Initialized
DEBUG - 2011-04-17 05:57:19 --> Router Class Initialized
DEBUG - 2011-04-17 05:57:19 --> Output Class Initialized
DEBUG - 2011-04-17 05:57:19 --> Input Class Initialized
DEBUG - 2011-04-17 05:57:19 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-17 05:57:19 --> Language Class Initialized
DEBUG - 2011-04-17 05:57:19 --> Loader Class Initialized
DEBUG - 2011-04-17 05:57:19 --> Controller Class Initialized
DEBUG - 2011-04-17 05:57:19 --> Model Class Initialized
DEBUG - 2011-04-17 05:57:19 --> Model Class Initialized
DEBUG - 2011-04-17 05:57:19 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-17 05:57:19 --> Database Driver Class Initialized
DEBUG - 2011-04-17 05:57:20 --> Final output sent to browser
DEBUG - 2011-04-17 05:57:20 --> Total execution time: 0.6874
DEBUG - 2011-04-17 05:57:28 --> Config Class Initialized
DEBUG - 2011-04-17 05:57:28 --> Hooks Class Initialized
DEBUG - 2011-04-17 05:57:28 --> Utf8 Class Initialized
DEBUG - 2011-04-17 05:57:28 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 05:57:28 --> URI Class Initialized
DEBUG - 2011-04-17 05:57:28 --> Router Class Initialized
DEBUG - 2011-04-17 05:57:28 --> Output Class Initialized
DEBUG - 2011-04-17 05:57:28 --> Input Class Initialized
DEBUG - 2011-04-17 05:57:28 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-17 05:57:28 --> Language Class Initialized
DEBUG - 2011-04-17 05:57:28 --> Loader Class Initialized
DEBUG - 2011-04-17 05:57:28 --> Controller Class Initialized
ERROR - 2011-04-17 05:57:28 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-17 05:57:28 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-17 05:57:28 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-17 05:57:28 --> Model Class Initialized
DEBUG - 2011-04-17 05:57:28 --> Model Class Initialized
DEBUG - 2011-04-17 05:57:28 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-17 05:57:28 --> Database Driver Class Initialized
DEBUG - 2011-04-17 05:57:28 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-17 05:57:28 --> Helper loaded: url_helper
DEBUG - 2011-04-17 05:57:28 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-17 05:57:28 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-17 05:57:28 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-17 05:57:28 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-17 05:57:28 --> Final output sent to browser
DEBUG - 2011-04-17 05:57:28 --> Total execution time: 0.0402
DEBUG - 2011-04-17 05:57:28 --> Config Class Initialized
DEBUG - 2011-04-17 05:57:28 --> Hooks Class Initialized
DEBUG - 2011-04-17 05:57:28 --> Utf8 Class Initialized
DEBUG - 2011-04-17 05:57:28 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 05:57:28 --> URI Class Initialized
DEBUG - 2011-04-17 05:57:28 --> Router Class Initialized
DEBUG - 2011-04-17 05:57:28 --> Output Class Initialized
DEBUG - 2011-04-17 05:57:28 --> Input Class Initialized
DEBUG - 2011-04-17 05:57:28 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-17 05:57:28 --> Language Class Initialized
DEBUG - 2011-04-17 05:57:28 --> Loader Class Initialized
DEBUG - 2011-04-17 05:57:28 --> Controller Class Initialized
DEBUG - 2011-04-17 05:57:28 --> Model Class Initialized
DEBUG - 2011-04-17 05:57:28 --> Model Class Initialized
DEBUG - 2011-04-17 05:57:28 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-17 05:57:28 --> Database Driver Class Initialized
DEBUG - 2011-04-17 05:57:29 --> Final output sent to browser
DEBUG - 2011-04-17 05:57:29 --> Total execution time: 0.6185
DEBUG - 2011-04-17 05:57:35 --> Config Class Initialized
DEBUG - 2011-04-17 05:57:35 --> Hooks Class Initialized
DEBUG - 2011-04-17 05:57:35 --> Utf8 Class Initialized
DEBUG - 2011-04-17 05:57:35 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 05:57:35 --> URI Class Initialized
DEBUG - 2011-04-17 05:57:35 --> Router Class Initialized
DEBUG - 2011-04-17 05:57:35 --> Output Class Initialized
DEBUG - 2011-04-17 05:57:35 --> Input Class Initialized
DEBUG - 2011-04-17 05:57:35 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-17 05:57:35 --> Language Class Initialized
DEBUG - 2011-04-17 05:57:35 --> Loader Class Initialized
DEBUG - 2011-04-17 05:57:35 --> Controller Class Initialized
ERROR - 2011-04-17 05:57:35 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-17 05:57:35 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-17 05:57:35 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-17 05:57:35 --> Model Class Initialized
DEBUG - 2011-04-17 05:57:35 --> Model Class Initialized
DEBUG - 2011-04-17 05:57:35 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-17 05:57:35 --> Database Driver Class Initialized
DEBUG - 2011-04-17 05:57:35 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-17 05:57:35 --> Helper loaded: url_helper
DEBUG - 2011-04-17 05:57:35 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-17 05:57:35 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-17 05:57:35 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-17 05:57:35 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-17 05:57:35 --> Final output sent to browser
DEBUG - 2011-04-17 05:57:35 --> Total execution time: 0.0365
DEBUG - 2011-04-17 05:57:36 --> Config Class Initialized
DEBUG - 2011-04-17 05:57:36 --> Hooks Class Initialized
DEBUG - 2011-04-17 05:57:36 --> Utf8 Class Initialized
DEBUG - 2011-04-17 05:57:36 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 05:57:36 --> URI Class Initialized
DEBUG - 2011-04-17 05:57:36 --> Router Class Initialized
DEBUG - 2011-04-17 05:57:36 --> Output Class Initialized
DEBUG - 2011-04-17 05:57:36 --> Input Class Initialized
DEBUG - 2011-04-17 05:57:36 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-17 05:57:36 --> Language Class Initialized
DEBUG - 2011-04-17 05:57:36 --> Loader Class Initialized
DEBUG - 2011-04-17 05:57:36 --> Controller Class Initialized
DEBUG - 2011-04-17 05:57:36 --> Model Class Initialized
DEBUG - 2011-04-17 05:57:36 --> Model Class Initialized
DEBUG - 2011-04-17 05:57:36 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-17 05:57:36 --> Database Driver Class Initialized
DEBUG - 2011-04-17 05:57:37 --> Final output sent to browser
DEBUG - 2011-04-17 05:57:37 --> Total execution time: 0.5492
DEBUG - 2011-04-17 05:58:31 --> Config Class Initialized
DEBUG - 2011-04-17 05:58:31 --> Hooks Class Initialized
DEBUG - 2011-04-17 05:58:31 --> Utf8 Class Initialized
DEBUG - 2011-04-17 05:58:31 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 05:58:31 --> URI Class Initialized
DEBUG - 2011-04-17 05:58:31 --> Router Class Initialized
DEBUG - 2011-04-17 05:58:31 --> Output Class Initialized
DEBUG - 2011-04-17 05:58:31 --> Input Class Initialized
DEBUG - 2011-04-17 05:58:31 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-17 05:58:31 --> Language Class Initialized
DEBUG - 2011-04-17 05:58:31 --> Loader Class Initialized
DEBUG - 2011-04-17 05:58:31 --> Controller Class Initialized
DEBUG - 2011-04-17 05:58:31 --> Model Class Initialized
DEBUG - 2011-04-17 05:58:31 --> Model Class Initialized
DEBUG - 2011-04-17 05:58:31 --> Model Class Initialized
DEBUG - 2011-04-17 05:58:31 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-17 05:58:31 --> Database Driver Class Initialized
DEBUG - 2011-04-17 05:58:31 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-17 05:58:31 --> Helper loaded: url_helper
DEBUG - 2011-04-17 05:58:31 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-17 05:58:31 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-17 05:58:31 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-17 05:58:31 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-17 05:58:31 --> Final output sent to browser
DEBUG - 2011-04-17 05:58:31 --> Total execution time: 0.4960
DEBUG - 2011-04-17 05:58:49 --> Config Class Initialized
DEBUG - 2011-04-17 05:58:49 --> Hooks Class Initialized
DEBUG - 2011-04-17 05:58:49 --> Utf8 Class Initialized
DEBUG - 2011-04-17 05:58:49 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 05:58:49 --> URI Class Initialized
DEBUG - 2011-04-17 05:58:49 --> Router Class Initialized
DEBUG - 2011-04-17 05:58:49 --> Output Class Initialized
DEBUG - 2011-04-17 05:58:49 --> Input Class Initialized
DEBUG - 2011-04-17 05:58:49 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-17 05:58:49 --> Language Class Initialized
DEBUG - 2011-04-17 05:58:49 --> Loader Class Initialized
DEBUG - 2011-04-17 05:58:49 --> Controller Class Initialized
DEBUG - 2011-04-17 05:58:49 --> Model Class Initialized
DEBUG - 2011-04-17 05:58:49 --> Model Class Initialized
DEBUG - 2011-04-17 05:58:49 --> Model Class Initialized
DEBUG - 2011-04-17 05:58:49 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-17 05:58:49 --> Database Driver Class Initialized
DEBUG - 2011-04-17 05:58:49 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-17 05:58:50 --> Helper loaded: url_helper
DEBUG - 2011-04-17 05:58:50 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-17 05:58:50 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-17 05:58:50 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-17 05:58:50 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-17 05:58:50 --> Final output sent to browser
DEBUG - 2011-04-17 05:58:50 --> Total execution time: 0.3607
DEBUG - 2011-04-17 05:59:04 --> Config Class Initialized
DEBUG - 2011-04-17 05:59:04 --> Hooks Class Initialized
DEBUG - 2011-04-17 05:59:04 --> Utf8 Class Initialized
DEBUG - 2011-04-17 05:59:04 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 05:59:04 --> URI Class Initialized
DEBUG - 2011-04-17 05:59:04 --> Router Class Initialized
DEBUG - 2011-04-17 05:59:04 --> Output Class Initialized
DEBUG - 2011-04-17 05:59:04 --> Input Class Initialized
DEBUG - 2011-04-17 05:59:04 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-17 05:59:04 --> Language Class Initialized
DEBUG - 2011-04-17 05:59:04 --> Loader Class Initialized
DEBUG - 2011-04-17 05:59:04 --> Controller Class Initialized
DEBUG - 2011-04-17 05:59:04 --> Model Class Initialized
DEBUG - 2011-04-17 05:59:04 --> Model Class Initialized
DEBUG - 2011-04-17 05:59:04 --> Model Class Initialized
DEBUG - 2011-04-17 05:59:04 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-17 05:59:04 --> Database Driver Class Initialized
DEBUG - 2011-04-17 05:59:04 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-17 05:59:04 --> Helper loaded: url_helper
DEBUG - 2011-04-17 05:59:04 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-17 05:59:04 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-17 05:59:04 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-17 05:59:04 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-17 05:59:04 --> Final output sent to browser
DEBUG - 2011-04-17 05:59:04 --> Total execution time: 0.2012
DEBUG - 2011-04-17 05:59:17 --> Config Class Initialized
DEBUG - 2011-04-17 05:59:17 --> Hooks Class Initialized
DEBUG - 2011-04-17 05:59:17 --> Utf8 Class Initialized
DEBUG - 2011-04-17 05:59:17 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 05:59:17 --> URI Class Initialized
DEBUG - 2011-04-17 05:59:17 --> Router Class Initialized
DEBUG - 2011-04-17 05:59:17 --> Output Class Initialized
DEBUG - 2011-04-17 05:59:17 --> Input Class Initialized
DEBUG - 2011-04-17 05:59:17 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-17 05:59:17 --> Language Class Initialized
DEBUG - 2011-04-17 05:59:17 --> Loader Class Initialized
DEBUG - 2011-04-17 05:59:17 --> Controller Class Initialized
DEBUG - 2011-04-17 05:59:17 --> Model Class Initialized
DEBUG - 2011-04-17 05:59:17 --> Model Class Initialized
DEBUG - 2011-04-17 05:59:17 --> Model Class Initialized
DEBUG - 2011-04-17 05:59:17 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-17 05:59:17 --> Database Driver Class Initialized
DEBUG - 2011-04-17 05:59:18 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-17 05:59:18 --> Helper loaded: url_helper
DEBUG - 2011-04-17 05:59:18 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-17 05:59:18 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-17 05:59:18 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-17 05:59:18 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-17 05:59:18 --> Final output sent to browser
DEBUG - 2011-04-17 05:59:18 --> Total execution time: 0.2128
DEBUG - 2011-04-17 06:14:44 --> Config Class Initialized
DEBUG - 2011-04-17 06:14:44 --> Hooks Class Initialized
DEBUG - 2011-04-17 06:14:44 --> Utf8 Class Initialized
DEBUG - 2011-04-17 06:14:44 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 06:14:44 --> URI Class Initialized
DEBUG - 2011-04-17 06:14:44 --> Router Class Initialized
DEBUG - 2011-04-17 06:14:44 --> Output Class Initialized
DEBUG - 2011-04-17 06:14:44 --> Input Class Initialized
DEBUG - 2011-04-17 06:14:44 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-17 06:14:44 --> Language Class Initialized
DEBUG - 2011-04-17 06:14:44 --> Loader Class Initialized
DEBUG - 2011-04-17 06:14:44 --> Controller Class Initialized
DEBUG - 2011-04-17 06:14:44 --> Model Class Initialized
DEBUG - 2011-04-17 06:14:44 --> Model Class Initialized
DEBUG - 2011-04-17 06:14:44 --> Model Class Initialized
DEBUG - 2011-04-17 06:14:44 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-17 06:14:44 --> Database Driver Class Initialized
DEBUG - 2011-04-17 06:14:45 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-17 06:14:45 --> Helper loaded: url_helper
DEBUG - 2011-04-17 06:14:45 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-17 06:14:45 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-17 06:14:45 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-17 06:14:45 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-17 06:14:45 --> Final output sent to browser
DEBUG - 2011-04-17 06:14:45 --> Total execution time: 0.9063
DEBUG - 2011-04-17 06:14:46 --> Config Class Initialized
DEBUG - 2011-04-17 06:14:46 --> Hooks Class Initialized
DEBUG - 2011-04-17 06:14:46 --> Utf8 Class Initialized
DEBUG - 2011-04-17 06:14:46 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 06:14:46 --> URI Class Initialized
DEBUG - 2011-04-17 06:14:46 --> Router Class Initialized
DEBUG - 2011-04-17 06:14:46 --> Output Class Initialized
DEBUG - 2011-04-17 06:14:46 --> Input Class Initialized
DEBUG - 2011-04-17 06:14:46 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-17 06:14:46 --> Language Class Initialized
DEBUG - 2011-04-17 06:14:46 --> Loader Class Initialized
DEBUG - 2011-04-17 06:14:46 --> Controller Class Initialized
ERROR - 2011-04-17 06:14:46 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-17 06:14:46 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-17 06:14:46 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-17 06:14:46 --> Model Class Initialized
DEBUG - 2011-04-17 06:14:46 --> Model Class Initialized
DEBUG - 2011-04-17 06:14:46 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-17 06:14:46 --> Database Driver Class Initialized
DEBUG - 2011-04-17 06:14:46 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-17 06:14:46 --> Helper loaded: url_helper
DEBUG - 2011-04-17 06:14:46 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-17 06:14:46 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-17 06:14:46 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-17 06:14:46 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-17 06:14:46 --> Final output sent to browser
DEBUG - 2011-04-17 06:14:46 --> Total execution time: 0.1109
DEBUG - 2011-04-17 07:19:37 --> Config Class Initialized
DEBUG - 2011-04-17 07:19:37 --> Hooks Class Initialized
DEBUG - 2011-04-17 07:19:37 --> Utf8 Class Initialized
DEBUG - 2011-04-17 07:19:37 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 07:19:37 --> URI Class Initialized
DEBUG - 2011-04-17 07:19:37 --> Router Class Initialized
DEBUG - 2011-04-17 07:19:37 --> Output Class Initialized
DEBUG - 2011-04-17 07:19:37 --> Input Class Initialized
DEBUG - 2011-04-17 07:19:37 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-17 07:19:37 --> Language Class Initialized
DEBUG - 2011-04-17 07:19:37 --> Loader Class Initialized
DEBUG - 2011-04-17 07:19:37 --> Controller Class Initialized
ERROR - 2011-04-17 07:19:37 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-17 07:19:37 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-17 07:19:37 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-17 07:19:37 --> Model Class Initialized
DEBUG - 2011-04-17 07:19:37 --> Model Class Initialized
DEBUG - 2011-04-17 07:19:37 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-17 07:19:37 --> Database Driver Class Initialized
DEBUG - 2011-04-17 07:19:37 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-17 07:19:37 --> Helper loaded: url_helper
DEBUG - 2011-04-17 07:19:37 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-17 07:19:37 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-17 07:19:37 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-17 07:19:37 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-17 07:19:37 --> Final output sent to browser
DEBUG - 2011-04-17 07:19:37 --> Total execution time: 0.2925
DEBUG - 2011-04-17 07:19:43 --> Config Class Initialized
DEBUG - 2011-04-17 07:19:43 --> Hooks Class Initialized
DEBUG - 2011-04-17 07:19:43 --> Utf8 Class Initialized
DEBUG - 2011-04-17 07:19:43 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 07:19:43 --> URI Class Initialized
DEBUG - 2011-04-17 07:19:43 --> Router Class Initialized
DEBUG - 2011-04-17 07:19:43 --> Output Class Initialized
DEBUG - 2011-04-17 07:19:43 --> Input Class Initialized
DEBUG - 2011-04-17 07:19:43 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-17 07:19:43 --> Language Class Initialized
DEBUG - 2011-04-17 07:19:43 --> Loader Class Initialized
DEBUG - 2011-04-17 07:19:43 --> Controller Class Initialized
DEBUG - 2011-04-17 07:19:43 --> Model Class Initialized
DEBUG - 2011-04-17 07:19:43 --> Model Class Initialized
DEBUG - 2011-04-17 07:19:43 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-17 07:19:43 --> Database Driver Class Initialized
DEBUG - 2011-04-17 07:19:44 --> Final output sent to browser
DEBUG - 2011-04-17 07:19:44 --> Total execution time: 0.6555
DEBUG - 2011-04-17 07:19:46 --> Config Class Initialized
DEBUG - 2011-04-17 07:19:46 --> Hooks Class Initialized
DEBUG - 2011-04-17 07:19:46 --> Utf8 Class Initialized
DEBUG - 2011-04-17 07:19:46 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 07:19:46 --> URI Class Initialized
DEBUG - 2011-04-17 07:19:46 --> Router Class Initialized
ERROR - 2011-04-17 07:19:46 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-17 07:21:05 --> Config Class Initialized
DEBUG - 2011-04-17 07:21:05 --> Hooks Class Initialized
DEBUG - 2011-04-17 07:21:05 --> Utf8 Class Initialized
DEBUG - 2011-04-17 07:21:05 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 07:21:05 --> URI Class Initialized
DEBUG - 2011-04-17 07:21:05 --> Router Class Initialized
DEBUG - 2011-04-17 07:21:05 --> Output Class Initialized
DEBUG - 2011-04-17 07:21:05 --> Input Class Initialized
DEBUG - 2011-04-17 07:21:05 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-17 07:21:05 --> Language Class Initialized
DEBUG - 2011-04-17 07:21:05 --> Loader Class Initialized
DEBUG - 2011-04-17 07:21:05 --> Controller Class Initialized
ERROR - 2011-04-17 07:21:05 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-17 07:21:05 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-17 07:21:05 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-17 07:21:05 --> Model Class Initialized
DEBUG - 2011-04-17 07:21:05 --> Model Class Initialized
DEBUG - 2011-04-17 07:21:05 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-17 07:21:05 --> Database Driver Class Initialized
DEBUG - 2011-04-17 07:21:05 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-17 07:21:05 --> Helper loaded: url_helper
DEBUG - 2011-04-17 07:21:05 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-17 07:21:05 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-17 07:21:05 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-17 07:21:05 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-17 07:21:05 --> Final output sent to browser
DEBUG - 2011-04-17 07:21:05 --> Total execution time: 0.0350
DEBUG - 2011-04-17 07:21:07 --> Config Class Initialized
DEBUG - 2011-04-17 07:21:07 --> Hooks Class Initialized
DEBUG - 2011-04-17 07:21:07 --> Utf8 Class Initialized
DEBUG - 2011-04-17 07:21:07 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 07:21:07 --> URI Class Initialized
DEBUG - 2011-04-17 07:21:07 --> Router Class Initialized
DEBUG - 2011-04-17 07:21:07 --> Output Class Initialized
DEBUG - 2011-04-17 07:21:07 --> Input Class Initialized
DEBUG - 2011-04-17 07:21:07 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-17 07:21:07 --> Language Class Initialized
DEBUG - 2011-04-17 07:21:07 --> Loader Class Initialized
DEBUG - 2011-04-17 07:21:07 --> Controller Class Initialized
DEBUG - 2011-04-17 07:21:07 --> Model Class Initialized
DEBUG - 2011-04-17 07:21:07 --> Model Class Initialized
DEBUG - 2011-04-17 07:21:07 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-17 07:21:07 --> Database Driver Class Initialized
DEBUG - 2011-04-17 07:21:07 --> Final output sent to browser
DEBUG - 2011-04-17 07:21:07 --> Total execution time: 0.5578
DEBUG - 2011-04-17 07:21:36 --> Config Class Initialized
DEBUG - 2011-04-17 07:21:36 --> Hooks Class Initialized
DEBUG - 2011-04-17 07:21:36 --> Utf8 Class Initialized
DEBUG - 2011-04-17 07:21:36 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 07:21:36 --> URI Class Initialized
DEBUG - 2011-04-17 07:21:36 --> Router Class Initialized
DEBUG - 2011-04-17 07:21:36 --> Output Class Initialized
DEBUG - 2011-04-17 07:21:36 --> Input Class Initialized
DEBUG - 2011-04-17 07:21:36 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-17 07:21:36 --> Language Class Initialized
DEBUG - 2011-04-17 07:21:36 --> Loader Class Initialized
DEBUG - 2011-04-17 07:21:36 --> Controller Class Initialized
ERROR - 2011-04-17 07:21:36 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-17 07:21:36 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-17 07:21:36 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-17 07:21:36 --> Model Class Initialized
DEBUG - 2011-04-17 07:21:36 --> Model Class Initialized
DEBUG - 2011-04-17 07:21:36 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-17 07:21:36 --> Database Driver Class Initialized
DEBUG - 2011-04-17 07:21:36 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-17 07:21:36 --> Helper loaded: url_helper
DEBUG - 2011-04-17 07:21:36 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-17 07:21:36 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-17 07:21:36 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-17 07:21:36 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-17 07:21:36 --> Final output sent to browser
DEBUG - 2011-04-17 07:21:36 --> Total execution time: 0.0301
DEBUG - 2011-04-17 07:21:38 --> Config Class Initialized
DEBUG - 2011-04-17 07:21:38 --> Hooks Class Initialized
DEBUG - 2011-04-17 07:21:38 --> Utf8 Class Initialized
DEBUG - 2011-04-17 07:21:38 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 07:21:38 --> URI Class Initialized
DEBUG - 2011-04-17 07:21:38 --> Router Class Initialized
DEBUG - 2011-04-17 07:21:38 --> Output Class Initialized
DEBUG - 2011-04-17 07:21:38 --> Input Class Initialized
DEBUG - 2011-04-17 07:21:38 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-17 07:21:38 --> Language Class Initialized
DEBUG - 2011-04-17 07:21:38 --> Loader Class Initialized
DEBUG - 2011-04-17 07:21:38 --> Controller Class Initialized
DEBUG - 2011-04-17 07:21:38 --> Model Class Initialized
DEBUG - 2011-04-17 07:21:38 --> Model Class Initialized
DEBUG - 2011-04-17 07:21:38 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-17 07:21:38 --> Database Driver Class Initialized
DEBUG - 2011-04-17 07:21:39 --> Final output sent to browser
DEBUG - 2011-04-17 07:21:39 --> Total execution time: 0.5034
DEBUG - 2011-04-17 07:21:57 --> Config Class Initialized
DEBUG - 2011-04-17 07:21:57 --> Hooks Class Initialized
DEBUG - 2011-04-17 07:21:57 --> Utf8 Class Initialized
DEBUG - 2011-04-17 07:21:57 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 07:21:57 --> URI Class Initialized
DEBUG - 2011-04-17 07:21:57 --> Router Class Initialized
DEBUG - 2011-04-17 07:21:57 --> Output Class Initialized
DEBUG - 2011-04-17 07:21:57 --> Input Class Initialized
DEBUG - 2011-04-17 07:21:57 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-17 07:21:57 --> Language Class Initialized
DEBUG - 2011-04-17 07:21:57 --> Loader Class Initialized
DEBUG - 2011-04-17 07:21:57 --> Controller Class Initialized
ERROR - 2011-04-17 07:21:57 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-17 07:21:57 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-17 07:21:57 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-17 07:21:57 --> Model Class Initialized
DEBUG - 2011-04-17 07:21:57 --> Model Class Initialized
DEBUG - 2011-04-17 07:21:57 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-17 07:21:57 --> Database Driver Class Initialized
DEBUG - 2011-04-17 07:21:57 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-17 07:21:57 --> Helper loaded: url_helper
DEBUG - 2011-04-17 07:21:57 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-17 07:21:57 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-17 07:21:57 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-17 07:21:57 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-17 07:21:57 --> Final output sent to browser
DEBUG - 2011-04-17 07:21:57 --> Total execution time: 0.0342
DEBUG - 2011-04-17 07:21:59 --> Config Class Initialized
DEBUG - 2011-04-17 07:21:59 --> Hooks Class Initialized
DEBUG - 2011-04-17 07:21:59 --> Utf8 Class Initialized
DEBUG - 2011-04-17 07:21:59 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 07:21:59 --> URI Class Initialized
DEBUG - 2011-04-17 07:21:59 --> Router Class Initialized
DEBUG - 2011-04-17 07:21:59 --> Output Class Initialized
DEBUG - 2011-04-17 07:21:59 --> Input Class Initialized
DEBUG - 2011-04-17 07:21:59 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-17 07:21:59 --> Language Class Initialized
DEBUG - 2011-04-17 07:21:59 --> Loader Class Initialized
DEBUG - 2011-04-17 07:21:59 --> Controller Class Initialized
DEBUG - 2011-04-17 07:21:59 --> Model Class Initialized
DEBUG - 2011-04-17 07:21:59 --> Model Class Initialized
DEBUG - 2011-04-17 07:21:59 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-17 07:21:59 --> Database Driver Class Initialized
DEBUG - 2011-04-17 07:21:59 --> Final output sent to browser
DEBUG - 2011-04-17 07:21:59 --> Total execution time: 0.5666
DEBUG - 2011-04-17 07:22:03 --> Config Class Initialized
DEBUG - 2011-04-17 07:22:03 --> Hooks Class Initialized
DEBUG - 2011-04-17 07:22:03 --> Utf8 Class Initialized
DEBUG - 2011-04-17 07:22:03 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 07:22:03 --> URI Class Initialized
DEBUG - 2011-04-17 07:22:03 --> Router Class Initialized
ERROR - 2011-04-17 07:22:03 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-17 07:22:33 --> Config Class Initialized
DEBUG - 2011-04-17 07:22:33 --> Hooks Class Initialized
DEBUG - 2011-04-17 07:22:33 --> Utf8 Class Initialized
DEBUG - 2011-04-17 07:22:33 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 07:22:33 --> URI Class Initialized
DEBUG - 2011-04-17 07:22:33 --> Router Class Initialized
DEBUG - 2011-04-17 07:22:33 --> Output Class Initialized
DEBUG - 2011-04-17 07:22:33 --> Input Class Initialized
DEBUG - 2011-04-17 07:22:33 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-17 07:22:33 --> Language Class Initialized
DEBUG - 2011-04-17 07:22:33 --> Loader Class Initialized
DEBUG - 2011-04-17 07:22:33 --> Controller Class Initialized
ERROR - 2011-04-17 07:22:33 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-17 07:22:33 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-17 07:22:33 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-17 07:22:33 --> Model Class Initialized
DEBUG - 2011-04-17 07:22:33 --> Model Class Initialized
DEBUG - 2011-04-17 07:22:33 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-17 07:22:33 --> Database Driver Class Initialized
DEBUG - 2011-04-17 07:22:33 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-17 07:22:33 --> Helper loaded: url_helper
DEBUG - 2011-04-17 07:22:33 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-17 07:22:33 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-17 07:22:33 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-17 07:22:33 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-17 07:22:33 --> Final output sent to browser
DEBUG - 2011-04-17 07:22:33 --> Total execution time: 0.0345
DEBUG - 2011-04-17 07:22:35 --> Config Class Initialized
DEBUG - 2011-04-17 07:22:35 --> Hooks Class Initialized
DEBUG - 2011-04-17 07:22:35 --> Utf8 Class Initialized
DEBUG - 2011-04-17 07:22:35 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 07:22:35 --> URI Class Initialized
DEBUG - 2011-04-17 07:22:35 --> Router Class Initialized
DEBUG - 2011-04-17 07:22:35 --> Output Class Initialized
DEBUG - 2011-04-17 07:22:35 --> Input Class Initialized
DEBUG - 2011-04-17 07:22:35 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-17 07:22:35 --> Language Class Initialized
DEBUG - 2011-04-17 07:22:35 --> Loader Class Initialized
DEBUG - 2011-04-17 07:22:35 --> Controller Class Initialized
DEBUG - 2011-04-17 07:22:35 --> Model Class Initialized
DEBUG - 2011-04-17 07:22:35 --> Model Class Initialized
DEBUG - 2011-04-17 07:22:35 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-17 07:22:35 --> Database Driver Class Initialized
DEBUG - 2011-04-17 07:22:36 --> Final output sent to browser
DEBUG - 2011-04-17 07:22:36 --> Total execution time: 0.6255
DEBUG - 2011-04-17 07:23:05 --> Config Class Initialized
DEBUG - 2011-04-17 07:23:05 --> Hooks Class Initialized
DEBUG - 2011-04-17 07:23:05 --> Utf8 Class Initialized
DEBUG - 2011-04-17 07:23:05 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 07:23:05 --> URI Class Initialized
DEBUG - 2011-04-17 07:23:05 --> Router Class Initialized
DEBUG - 2011-04-17 07:23:05 --> Output Class Initialized
DEBUG - 2011-04-17 07:23:05 --> Input Class Initialized
DEBUG - 2011-04-17 07:23:05 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-17 07:23:05 --> Language Class Initialized
DEBUG - 2011-04-17 07:23:05 --> Loader Class Initialized
DEBUG - 2011-04-17 07:23:05 --> Controller Class Initialized
ERROR - 2011-04-17 07:23:05 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-17 07:23:05 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-17 07:23:05 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-17 07:23:05 --> Model Class Initialized
DEBUG - 2011-04-17 07:23:05 --> Model Class Initialized
DEBUG - 2011-04-17 07:23:05 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-17 07:23:05 --> Database Driver Class Initialized
DEBUG - 2011-04-17 07:23:05 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-17 07:23:05 --> Helper loaded: url_helper
DEBUG - 2011-04-17 07:23:05 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-17 07:23:05 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-17 07:23:05 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-17 07:23:05 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-17 07:23:05 --> Final output sent to browser
DEBUG - 2011-04-17 07:23:05 --> Total execution time: 0.1525
DEBUG - 2011-04-17 07:23:09 --> Config Class Initialized
DEBUG - 2011-04-17 07:23:09 --> Hooks Class Initialized
DEBUG - 2011-04-17 07:23:09 --> Utf8 Class Initialized
DEBUG - 2011-04-17 07:23:09 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 07:23:09 --> URI Class Initialized
DEBUG - 2011-04-17 07:23:09 --> Router Class Initialized
DEBUG - 2011-04-17 07:23:09 --> Output Class Initialized
DEBUG - 2011-04-17 07:23:09 --> Input Class Initialized
DEBUG - 2011-04-17 07:23:09 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-17 07:23:09 --> Language Class Initialized
DEBUG - 2011-04-17 07:23:09 --> Loader Class Initialized
DEBUG - 2011-04-17 07:23:09 --> Controller Class Initialized
DEBUG - 2011-04-17 07:23:09 --> Model Class Initialized
DEBUG - 2011-04-17 07:23:09 --> Model Class Initialized
DEBUG - 2011-04-17 07:23:09 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-17 07:23:09 --> Database Driver Class Initialized
DEBUG - 2011-04-17 07:23:10 --> Final output sent to browser
DEBUG - 2011-04-17 07:23:10 --> Total execution time: 0.9883
DEBUG - 2011-04-17 08:04:09 --> Config Class Initialized
DEBUG - 2011-04-17 08:04:09 --> Hooks Class Initialized
DEBUG - 2011-04-17 08:04:09 --> Utf8 Class Initialized
DEBUG - 2011-04-17 08:04:09 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 08:04:09 --> URI Class Initialized
DEBUG - 2011-04-17 08:04:09 --> Router Class Initialized
DEBUG - 2011-04-17 08:04:09 --> Output Class Initialized
DEBUG - 2011-04-17 08:04:09 --> Input Class Initialized
DEBUG - 2011-04-17 08:04:09 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-17 08:04:09 --> Language Class Initialized
DEBUG - 2011-04-17 08:04:09 --> Loader Class Initialized
DEBUG - 2011-04-17 08:04:09 --> Controller Class Initialized
ERROR - 2011-04-17 08:04:09 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-17 08:04:09 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-17 08:04:09 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-17 08:04:09 --> Model Class Initialized
DEBUG - 2011-04-17 08:04:09 --> Model Class Initialized
DEBUG - 2011-04-17 08:04:09 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-17 08:04:10 --> Database Driver Class Initialized
DEBUG - 2011-04-17 08:04:10 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-17 08:04:10 --> Helper loaded: url_helper
DEBUG - 2011-04-17 08:04:10 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-17 08:04:10 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-17 08:04:10 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-17 08:04:10 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-17 08:04:10 --> Final output sent to browser
DEBUG - 2011-04-17 08:04:10 --> Total execution time: 0.5599
DEBUG - 2011-04-17 08:04:49 --> Config Class Initialized
DEBUG - 2011-04-17 08:04:49 --> Hooks Class Initialized
DEBUG - 2011-04-17 08:04:49 --> Utf8 Class Initialized
DEBUG - 2011-04-17 08:04:49 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 08:04:49 --> URI Class Initialized
DEBUG - 2011-04-17 08:04:49 --> Router Class Initialized
DEBUG - 2011-04-17 08:04:49 --> Output Class Initialized
DEBUG - 2011-04-17 08:04:49 --> Input Class Initialized
DEBUG - 2011-04-17 08:04:49 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-17 08:04:49 --> Language Class Initialized
DEBUG - 2011-04-17 08:04:49 --> Loader Class Initialized
DEBUG - 2011-04-17 08:04:49 --> Controller Class Initialized
DEBUG - 2011-04-17 08:04:49 --> Model Class Initialized
DEBUG - 2011-04-17 08:04:49 --> Model Class Initialized
DEBUG - 2011-04-17 08:04:49 --> Model Class Initialized
DEBUG - 2011-04-17 08:04:49 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-17 08:04:49 --> Database Driver Class Initialized
DEBUG - 2011-04-17 08:04:49 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-17 08:04:49 --> Helper loaded: url_helper
DEBUG - 2011-04-17 08:04:49 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-17 08:04:49 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-17 08:04:49 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-17 08:04:49 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-17 08:04:49 --> Final output sent to browser
DEBUG - 2011-04-17 08:04:49 --> Total execution time: 0.3013
DEBUG - 2011-04-17 08:17:39 --> Config Class Initialized
DEBUG - 2011-04-17 08:17:39 --> Hooks Class Initialized
DEBUG - 2011-04-17 08:17:39 --> Utf8 Class Initialized
DEBUG - 2011-04-17 08:17:39 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 08:17:39 --> URI Class Initialized
DEBUG - 2011-04-17 08:17:39 --> Router Class Initialized
DEBUG - 2011-04-17 08:17:39 --> Output Class Initialized
DEBUG - 2011-04-17 08:17:39 --> Input Class Initialized
DEBUG - 2011-04-17 08:17:39 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-17 08:17:39 --> Language Class Initialized
DEBUG - 2011-04-17 08:17:39 --> Loader Class Initialized
DEBUG - 2011-04-17 08:17:39 --> Controller Class Initialized
ERROR - 2011-04-17 08:17:39 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-17 08:17:39 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-17 08:17:39 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-17 08:17:39 --> Model Class Initialized
DEBUG - 2011-04-17 08:17:39 --> Model Class Initialized
DEBUG - 2011-04-17 08:17:39 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-17 08:17:39 --> Database Driver Class Initialized
DEBUG - 2011-04-17 08:17:39 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-17 08:17:39 --> Helper loaded: url_helper
DEBUG - 2011-04-17 08:17:39 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-17 08:17:39 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-17 08:17:39 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-17 08:17:39 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-17 08:17:39 --> Final output sent to browser
DEBUG - 2011-04-17 08:17:39 --> Total execution time: 0.3617
DEBUG - 2011-04-17 08:17:53 --> Config Class Initialized
DEBUG - 2011-04-17 08:17:53 --> Hooks Class Initialized
DEBUG - 2011-04-17 08:17:53 --> Utf8 Class Initialized
DEBUG - 2011-04-17 08:17:53 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 08:17:53 --> URI Class Initialized
DEBUG - 2011-04-17 08:17:53 --> Router Class Initialized
DEBUG - 2011-04-17 08:17:53 --> Output Class Initialized
DEBUG - 2011-04-17 08:17:53 --> Input Class Initialized
DEBUG - 2011-04-17 08:17:53 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-17 08:17:53 --> Language Class Initialized
DEBUG - 2011-04-17 08:17:53 --> Loader Class Initialized
DEBUG - 2011-04-17 08:17:53 --> Controller Class Initialized
DEBUG - 2011-04-17 08:17:53 --> Model Class Initialized
DEBUG - 2011-04-17 08:17:53 --> Model Class Initialized
DEBUG - 2011-04-17 08:17:53 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-17 08:17:53 --> Database Driver Class Initialized
DEBUG - 2011-04-17 08:17:53 --> Config Class Initialized
DEBUG - 2011-04-17 08:17:53 --> Hooks Class Initialized
DEBUG - 2011-04-17 08:17:53 --> Utf8 Class Initialized
DEBUG - 2011-04-17 08:17:53 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 08:17:53 --> URI Class Initialized
DEBUG - 2011-04-17 08:17:53 --> Router Class Initialized
DEBUG - 2011-04-17 08:17:53 --> Output Class Initialized
DEBUG - 2011-04-17 08:17:53 --> Input Class Initialized
DEBUG - 2011-04-17 08:17:53 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-17 08:17:53 --> Language Class Initialized
DEBUG - 2011-04-17 08:17:53 --> Loader Class Initialized
DEBUG - 2011-04-17 08:17:53 --> Controller Class Initialized
DEBUG - 2011-04-17 08:17:53 --> Model Class Initialized
DEBUG - 2011-04-17 08:17:53 --> Model Class Initialized
DEBUG - 2011-04-17 08:17:53 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-17 08:17:53 --> Database Driver Class Initialized
DEBUG - 2011-04-17 08:17:53 --> Final output sent to browser
DEBUG - 2011-04-17 08:17:53 --> Total execution time: 0.7637
DEBUG - 2011-04-17 08:17:54 --> Final output sent to browser
DEBUG - 2011-04-17 08:17:54 --> Total execution time: 0.7499
DEBUG - 2011-04-17 08:17:56 --> Config Class Initialized
DEBUG - 2011-04-17 08:17:56 --> Hooks Class Initialized
DEBUG - 2011-04-17 08:17:56 --> Utf8 Class Initialized
DEBUG - 2011-04-17 08:17:56 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 08:17:56 --> URI Class Initialized
DEBUG - 2011-04-17 08:17:56 --> Router Class Initialized
DEBUG - 2011-04-17 08:17:56 --> Output Class Initialized
DEBUG - 2011-04-17 08:17:56 --> Input Class Initialized
DEBUG - 2011-04-17 08:17:56 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-17 08:17:56 --> Language Class Initialized
DEBUG - 2011-04-17 08:17:56 --> Loader Class Initialized
DEBUG - 2011-04-17 08:17:56 --> Controller Class Initialized
ERROR - 2011-04-17 08:17:56 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-17 08:17:56 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-17 08:17:56 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-17 08:17:56 --> Model Class Initialized
DEBUG - 2011-04-17 08:17:56 --> Model Class Initialized
DEBUG - 2011-04-17 08:17:56 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-17 08:17:56 --> Database Driver Class Initialized
DEBUG - 2011-04-17 08:17:56 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-17 08:17:56 --> Helper loaded: url_helper
DEBUG - 2011-04-17 08:17:56 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-17 08:17:56 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-17 08:17:56 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-17 08:17:56 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-17 08:17:56 --> Final output sent to browser
DEBUG - 2011-04-17 08:17:56 --> Total execution time: 0.0316
DEBUG - 2011-04-17 08:18:31 --> Config Class Initialized
DEBUG - 2011-04-17 08:18:31 --> Hooks Class Initialized
DEBUG - 2011-04-17 08:18:31 --> Utf8 Class Initialized
DEBUG - 2011-04-17 08:18:31 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 08:18:31 --> URI Class Initialized
DEBUG - 2011-04-17 08:18:31 --> Router Class Initialized
DEBUG - 2011-04-17 08:18:31 --> Output Class Initialized
DEBUG - 2011-04-17 08:18:31 --> Input Class Initialized
DEBUG - 2011-04-17 08:18:31 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-17 08:18:31 --> Language Class Initialized
DEBUG - 2011-04-17 08:18:31 --> Loader Class Initialized
DEBUG - 2011-04-17 08:18:31 --> Controller Class Initialized
ERROR - 2011-04-17 08:18:31 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-17 08:18:31 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-17 08:18:31 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-17 08:18:31 --> Model Class Initialized
DEBUG - 2011-04-17 08:18:31 --> Model Class Initialized
DEBUG - 2011-04-17 08:18:31 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-17 08:18:31 --> Database Driver Class Initialized
DEBUG - 2011-04-17 08:18:31 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-17 08:18:31 --> Helper loaded: url_helper
DEBUG - 2011-04-17 08:18:31 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-17 08:18:31 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-17 08:18:31 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-17 08:18:31 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-17 08:18:31 --> Final output sent to browser
DEBUG - 2011-04-17 08:18:31 --> Total execution time: 0.0287
DEBUG - 2011-04-17 08:18:31 --> Config Class Initialized
DEBUG - 2011-04-17 08:18:31 --> Hooks Class Initialized
DEBUG - 2011-04-17 08:18:31 --> Utf8 Class Initialized
DEBUG - 2011-04-17 08:18:31 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 08:18:31 --> URI Class Initialized
DEBUG - 2011-04-17 08:18:31 --> Router Class Initialized
DEBUG - 2011-04-17 08:18:31 --> Output Class Initialized
DEBUG - 2011-04-17 08:18:31 --> Input Class Initialized
DEBUG - 2011-04-17 08:18:31 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-17 08:18:31 --> Language Class Initialized
DEBUG - 2011-04-17 08:18:31 --> Loader Class Initialized
DEBUG - 2011-04-17 08:18:31 --> Controller Class Initialized
DEBUG - 2011-04-17 08:18:31 --> Model Class Initialized
DEBUG - 2011-04-17 08:18:31 --> Model Class Initialized
DEBUG - 2011-04-17 08:18:31 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-17 08:18:31 --> Database Driver Class Initialized
DEBUG - 2011-04-17 08:18:32 --> Final output sent to browser
DEBUG - 2011-04-17 08:18:32 --> Total execution time: 0.6528
DEBUG - 2011-04-17 08:19:08 --> Config Class Initialized
DEBUG - 2011-04-17 08:19:08 --> Hooks Class Initialized
DEBUG - 2011-04-17 08:19:08 --> Utf8 Class Initialized
DEBUG - 2011-04-17 08:19:08 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 08:19:08 --> URI Class Initialized
DEBUG - 2011-04-17 08:19:08 --> Router Class Initialized
DEBUG - 2011-04-17 08:19:08 --> Output Class Initialized
DEBUG - 2011-04-17 08:19:08 --> Input Class Initialized
DEBUG - 2011-04-17 08:19:08 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-17 08:19:08 --> Language Class Initialized
DEBUG - 2011-04-17 08:19:08 --> Loader Class Initialized
DEBUG - 2011-04-17 08:19:08 --> Controller Class Initialized
ERROR - 2011-04-17 08:19:08 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-17 08:19:08 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-17 08:19:08 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-17 08:19:08 --> Model Class Initialized
DEBUG - 2011-04-17 08:19:08 --> Model Class Initialized
DEBUG - 2011-04-17 08:19:08 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-17 08:19:08 --> Database Driver Class Initialized
DEBUG - 2011-04-17 08:19:08 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-17 08:19:08 --> Helper loaded: url_helper
DEBUG - 2011-04-17 08:19:08 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-17 08:19:08 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-17 08:19:08 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-17 08:19:08 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-17 08:19:08 --> Final output sent to browser
DEBUG - 2011-04-17 08:19:08 --> Total execution time: 0.1052
DEBUG - 2011-04-17 08:19:09 --> Config Class Initialized
DEBUG - 2011-04-17 08:19:09 --> Hooks Class Initialized
DEBUG - 2011-04-17 08:19:09 --> Utf8 Class Initialized
DEBUG - 2011-04-17 08:19:09 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 08:19:09 --> URI Class Initialized
DEBUG - 2011-04-17 08:19:09 --> Router Class Initialized
DEBUG - 2011-04-17 08:19:09 --> Output Class Initialized
DEBUG - 2011-04-17 08:19:09 --> Input Class Initialized
DEBUG - 2011-04-17 08:19:09 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-17 08:19:09 --> Language Class Initialized
DEBUG - 2011-04-17 08:19:09 --> Loader Class Initialized
DEBUG - 2011-04-17 08:19:09 --> Controller Class Initialized
DEBUG - 2011-04-17 08:19:09 --> Model Class Initialized
DEBUG - 2011-04-17 08:19:09 --> Model Class Initialized
DEBUG - 2011-04-17 08:19:09 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-17 08:19:09 --> Database Driver Class Initialized
DEBUG - 2011-04-17 08:19:10 --> Final output sent to browser
DEBUG - 2011-04-17 08:19:10 --> Total execution time: 0.8274
DEBUG - 2011-04-17 08:22:50 --> Config Class Initialized
DEBUG - 2011-04-17 08:22:50 --> Hooks Class Initialized
DEBUG - 2011-04-17 08:22:50 --> Utf8 Class Initialized
DEBUG - 2011-04-17 08:22:50 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 08:22:50 --> URI Class Initialized
DEBUG - 2011-04-17 08:22:50 --> Router Class Initialized
DEBUG - 2011-04-17 08:22:50 --> Output Class Initialized
DEBUG - 2011-04-17 08:22:50 --> Input Class Initialized
DEBUG - 2011-04-17 08:22:50 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-17 08:22:50 --> Language Class Initialized
DEBUG - 2011-04-17 08:22:50 --> Loader Class Initialized
DEBUG - 2011-04-17 08:22:50 --> Controller Class Initialized
ERROR - 2011-04-17 08:22:50 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-17 08:22:50 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-17 08:22:50 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-17 08:22:50 --> Model Class Initialized
DEBUG - 2011-04-17 08:22:50 --> Model Class Initialized
DEBUG - 2011-04-17 08:22:50 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-17 08:22:50 --> Database Driver Class Initialized
DEBUG - 2011-04-17 08:22:50 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-17 08:22:50 --> Helper loaded: url_helper
DEBUG - 2011-04-17 08:22:50 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-17 08:22:50 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-17 08:22:50 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-17 08:22:50 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-17 08:22:50 --> Final output sent to browser
DEBUG - 2011-04-17 08:22:50 --> Total execution time: 0.0294
DEBUG - 2011-04-17 08:23:55 --> Config Class Initialized
DEBUG - 2011-04-17 08:23:55 --> Hooks Class Initialized
DEBUG - 2011-04-17 08:23:55 --> Utf8 Class Initialized
DEBUG - 2011-04-17 08:23:55 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 08:23:55 --> URI Class Initialized
DEBUG - 2011-04-17 08:23:55 --> Router Class Initialized
DEBUG - 2011-04-17 08:23:55 --> Output Class Initialized
DEBUG - 2011-04-17 08:23:55 --> Input Class Initialized
DEBUG - 2011-04-17 08:23:55 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-17 08:23:55 --> Language Class Initialized
DEBUG - 2011-04-17 08:23:55 --> Loader Class Initialized
DEBUG - 2011-04-17 08:23:55 --> Controller Class Initialized
ERROR - 2011-04-17 08:23:55 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-17 08:23:55 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-17 08:23:55 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-17 08:23:55 --> Model Class Initialized
DEBUG - 2011-04-17 08:23:55 --> Model Class Initialized
DEBUG - 2011-04-17 08:23:55 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-17 08:23:55 --> Database Driver Class Initialized
DEBUG - 2011-04-17 08:23:55 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-17 08:23:55 --> Helper loaded: url_helper
DEBUG - 2011-04-17 08:23:55 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-17 08:23:55 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-17 08:23:55 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-17 08:23:55 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-17 08:23:55 --> Final output sent to browser
DEBUG - 2011-04-17 08:23:55 --> Total execution time: 0.0320
DEBUG - 2011-04-17 08:23:56 --> Config Class Initialized
DEBUG - 2011-04-17 08:23:56 --> Hooks Class Initialized
DEBUG - 2011-04-17 08:23:56 --> Utf8 Class Initialized
DEBUG - 2011-04-17 08:23:56 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 08:23:56 --> URI Class Initialized
DEBUG - 2011-04-17 08:23:56 --> Router Class Initialized
DEBUG - 2011-04-17 08:23:56 --> Output Class Initialized
DEBUG - 2011-04-17 08:23:56 --> Input Class Initialized
DEBUG - 2011-04-17 08:23:56 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-17 08:23:56 --> Language Class Initialized
DEBUG - 2011-04-17 08:23:56 --> Loader Class Initialized
DEBUG - 2011-04-17 08:23:56 --> Controller Class Initialized
DEBUG - 2011-04-17 08:23:56 --> Model Class Initialized
DEBUG - 2011-04-17 08:23:56 --> Model Class Initialized
DEBUG - 2011-04-17 08:23:56 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-17 08:23:56 --> Database Driver Class Initialized
DEBUG - 2011-04-17 08:23:57 --> Final output sent to browser
DEBUG - 2011-04-17 08:23:57 --> Total execution time: 0.5543
DEBUG - 2011-04-17 08:23:59 --> Config Class Initialized
DEBUG - 2011-04-17 08:23:59 --> Hooks Class Initialized
DEBUG - 2011-04-17 08:23:59 --> Utf8 Class Initialized
DEBUG - 2011-04-17 08:23:59 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 08:23:59 --> URI Class Initialized
DEBUG - 2011-04-17 08:23:59 --> Router Class Initialized
DEBUG - 2011-04-17 08:23:59 --> Output Class Initialized
DEBUG - 2011-04-17 08:23:59 --> Input Class Initialized
DEBUG - 2011-04-17 08:23:59 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-17 08:23:59 --> Language Class Initialized
DEBUG - 2011-04-17 08:23:59 --> Loader Class Initialized
DEBUG - 2011-04-17 08:23:59 --> Controller Class Initialized
DEBUG - 2011-04-17 08:23:59 --> Model Class Initialized
DEBUG - 2011-04-17 08:23:59 --> Model Class Initialized
DEBUG - 2011-04-17 08:23:59 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-17 08:23:59 --> Database Driver Class Initialized
DEBUG - 2011-04-17 08:24:00 --> Final output sent to browser
DEBUG - 2011-04-17 08:24:00 --> Total execution time: 0.8040
DEBUG - 2011-04-17 08:24:10 --> Config Class Initialized
DEBUG - 2011-04-17 08:24:10 --> Hooks Class Initialized
DEBUG - 2011-04-17 08:24:10 --> Utf8 Class Initialized
DEBUG - 2011-04-17 08:24:10 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 08:24:10 --> URI Class Initialized
DEBUG - 2011-04-17 08:24:10 --> Router Class Initialized
DEBUG - 2011-04-17 08:24:10 --> Output Class Initialized
DEBUG - 2011-04-17 08:24:10 --> Input Class Initialized
DEBUG - 2011-04-17 08:24:10 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-17 08:24:10 --> Language Class Initialized
DEBUG - 2011-04-17 08:24:10 --> Loader Class Initialized
DEBUG - 2011-04-17 08:24:10 --> Controller Class Initialized
ERROR - 2011-04-17 08:24:10 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-17 08:24:10 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-17 08:24:10 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-17 08:24:10 --> Model Class Initialized
DEBUG - 2011-04-17 08:24:10 --> Model Class Initialized
DEBUG - 2011-04-17 08:24:10 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-17 08:24:10 --> Database Driver Class Initialized
DEBUG - 2011-04-17 08:24:10 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-17 08:24:10 --> Helper loaded: url_helper
DEBUG - 2011-04-17 08:24:10 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-17 08:24:10 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-17 08:24:10 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-17 08:24:10 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-17 08:24:10 --> Final output sent to browser
DEBUG - 2011-04-17 08:24:10 --> Total execution time: 0.0894
DEBUG - 2011-04-17 08:24:10 --> Config Class Initialized
DEBUG - 2011-04-17 08:24:10 --> Hooks Class Initialized
DEBUG - 2011-04-17 08:24:10 --> Utf8 Class Initialized
DEBUG - 2011-04-17 08:24:10 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 08:24:10 --> URI Class Initialized
DEBUG - 2011-04-17 08:24:10 --> Router Class Initialized
DEBUG - 2011-04-17 08:24:10 --> Output Class Initialized
DEBUG - 2011-04-17 08:24:10 --> Input Class Initialized
DEBUG - 2011-04-17 08:24:10 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-17 08:24:10 --> Language Class Initialized
DEBUG - 2011-04-17 08:24:10 --> Loader Class Initialized
DEBUG - 2011-04-17 08:24:10 --> Controller Class Initialized
DEBUG - 2011-04-17 08:24:10 --> Model Class Initialized
DEBUG - 2011-04-17 08:24:10 --> Model Class Initialized
DEBUG - 2011-04-17 08:24:10 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-17 08:24:10 --> Database Driver Class Initialized
DEBUG - 2011-04-17 08:24:11 --> Final output sent to browser
DEBUG - 2011-04-17 08:24:11 --> Total execution time: 0.7177
DEBUG - 2011-04-17 08:24:27 --> Config Class Initialized
DEBUG - 2011-04-17 08:24:27 --> Hooks Class Initialized
DEBUG - 2011-04-17 08:24:27 --> Utf8 Class Initialized
DEBUG - 2011-04-17 08:24:27 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 08:24:27 --> URI Class Initialized
DEBUG - 2011-04-17 08:24:27 --> Router Class Initialized
DEBUG - 2011-04-17 08:24:27 --> Output Class Initialized
DEBUG - 2011-04-17 08:24:27 --> Input Class Initialized
DEBUG - 2011-04-17 08:24:27 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-17 08:24:27 --> Language Class Initialized
DEBUG - 2011-04-17 08:24:27 --> Loader Class Initialized
DEBUG - 2011-04-17 08:24:27 --> Controller Class Initialized
ERROR - 2011-04-17 08:24:27 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-17 08:24:27 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-17 08:24:27 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-17 08:24:27 --> Model Class Initialized
DEBUG - 2011-04-17 08:24:27 --> Model Class Initialized
DEBUG - 2011-04-17 08:24:27 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-17 08:24:27 --> Database Driver Class Initialized
DEBUG - 2011-04-17 08:24:27 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-17 08:24:27 --> Helper loaded: url_helper
DEBUG - 2011-04-17 08:24:27 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-17 08:24:27 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-17 08:24:27 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-17 08:24:27 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-17 08:24:27 --> Final output sent to browser
DEBUG - 2011-04-17 08:24:27 --> Total execution time: 0.0332
DEBUG - 2011-04-17 08:24:28 --> Config Class Initialized
DEBUG - 2011-04-17 08:24:28 --> Hooks Class Initialized
DEBUG - 2011-04-17 08:24:28 --> Utf8 Class Initialized
DEBUG - 2011-04-17 08:24:28 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 08:24:28 --> URI Class Initialized
DEBUG - 2011-04-17 08:24:28 --> Router Class Initialized
DEBUG - 2011-04-17 08:24:28 --> Output Class Initialized
DEBUG - 2011-04-17 08:24:28 --> Input Class Initialized
DEBUG - 2011-04-17 08:24:28 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-17 08:24:28 --> Language Class Initialized
DEBUG - 2011-04-17 08:24:28 --> Loader Class Initialized
DEBUG - 2011-04-17 08:24:28 --> Controller Class Initialized
DEBUG - 2011-04-17 08:24:28 --> Model Class Initialized
DEBUG - 2011-04-17 08:24:28 --> Model Class Initialized
DEBUG - 2011-04-17 08:24:28 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-17 08:24:28 --> Database Driver Class Initialized
DEBUG - 2011-04-17 08:24:28 --> Final output sent to browser
DEBUG - 2011-04-17 08:24:28 --> Total execution time: 0.5224
DEBUG - 2011-04-17 08:25:05 --> Config Class Initialized
DEBUG - 2011-04-17 08:25:05 --> Hooks Class Initialized
DEBUG - 2011-04-17 08:25:05 --> Utf8 Class Initialized
DEBUG - 2011-04-17 08:25:05 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 08:25:05 --> URI Class Initialized
DEBUG - 2011-04-17 08:25:05 --> Router Class Initialized
DEBUG - 2011-04-17 08:25:05 --> Output Class Initialized
DEBUG - 2011-04-17 08:25:05 --> Input Class Initialized
DEBUG - 2011-04-17 08:25:05 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-17 08:25:05 --> Language Class Initialized
DEBUG - 2011-04-17 08:25:05 --> Loader Class Initialized
DEBUG - 2011-04-17 08:25:05 --> Controller Class Initialized
ERROR - 2011-04-17 08:25:05 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-17 08:25:05 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-17 08:25:05 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-17 08:25:05 --> Model Class Initialized
DEBUG - 2011-04-17 08:25:05 --> Model Class Initialized
DEBUG - 2011-04-17 08:25:05 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-17 08:25:05 --> Database Driver Class Initialized
DEBUG - 2011-04-17 08:25:05 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-17 08:25:05 --> Helper loaded: url_helper
DEBUG - 2011-04-17 08:25:05 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-17 08:25:06 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-17 08:25:06 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-17 08:25:06 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-17 08:25:06 --> Final output sent to browser
DEBUG - 2011-04-17 08:25:06 --> Total execution time: 0.1572
DEBUG - 2011-04-17 08:25:06 --> Config Class Initialized
DEBUG - 2011-04-17 08:25:06 --> Hooks Class Initialized
DEBUG - 2011-04-17 08:25:06 --> Utf8 Class Initialized
DEBUG - 2011-04-17 08:25:06 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 08:25:06 --> URI Class Initialized
DEBUG - 2011-04-17 08:25:06 --> Router Class Initialized
ERROR - 2011-04-17 08:25:06 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-04-17 08:25:37 --> Config Class Initialized
DEBUG - 2011-04-17 08:25:37 --> Hooks Class Initialized
DEBUG - 2011-04-17 08:25:37 --> Utf8 Class Initialized
DEBUG - 2011-04-17 08:25:37 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 08:25:37 --> URI Class Initialized
DEBUG - 2011-04-17 08:25:37 --> Router Class Initialized
DEBUG - 2011-04-17 08:25:37 --> Output Class Initialized
DEBUG - 2011-04-17 08:25:37 --> Input Class Initialized
DEBUG - 2011-04-17 08:25:37 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-17 08:25:37 --> Language Class Initialized
DEBUG - 2011-04-17 08:25:37 --> Loader Class Initialized
DEBUG - 2011-04-17 08:25:37 --> Controller Class Initialized
ERROR - 2011-04-17 08:25:37 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-17 08:25:37 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-17 08:25:37 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-17 08:25:37 --> Model Class Initialized
DEBUG - 2011-04-17 08:25:37 --> Model Class Initialized
DEBUG - 2011-04-17 08:25:37 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-17 08:25:37 --> Database Driver Class Initialized
DEBUG - 2011-04-17 08:25:37 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-17 08:25:37 --> Helper loaded: url_helper
DEBUG - 2011-04-17 08:25:37 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-17 08:25:37 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-17 08:25:37 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-17 08:25:37 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-17 08:25:37 --> Final output sent to browser
DEBUG - 2011-04-17 08:25:37 --> Total execution time: 0.0345
DEBUG - 2011-04-17 08:25:38 --> Config Class Initialized
DEBUG - 2011-04-17 08:25:38 --> Hooks Class Initialized
DEBUG - 2011-04-17 08:25:38 --> Utf8 Class Initialized
DEBUG - 2011-04-17 08:25:38 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 08:25:38 --> URI Class Initialized
DEBUG - 2011-04-17 08:25:38 --> Router Class Initialized
DEBUG - 2011-04-17 08:25:38 --> Output Class Initialized
DEBUG - 2011-04-17 08:25:38 --> Input Class Initialized
DEBUG - 2011-04-17 08:25:38 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-17 08:25:38 --> Language Class Initialized
DEBUG - 2011-04-17 08:25:38 --> Loader Class Initialized
DEBUG - 2011-04-17 08:25:38 --> Controller Class Initialized
DEBUG - 2011-04-17 08:25:38 --> Model Class Initialized
DEBUG - 2011-04-17 08:25:38 --> Model Class Initialized
DEBUG - 2011-04-17 08:25:38 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-17 08:25:38 --> Database Driver Class Initialized
DEBUG - 2011-04-17 08:25:38 --> Final output sent to browser
DEBUG - 2011-04-17 08:25:38 --> Total execution time: 0.7571
DEBUG - 2011-04-17 08:27:21 --> Config Class Initialized
DEBUG - 2011-04-17 08:27:21 --> Hooks Class Initialized
DEBUG - 2011-04-17 08:27:21 --> Utf8 Class Initialized
DEBUG - 2011-04-17 08:27:21 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 08:27:21 --> URI Class Initialized
DEBUG - 2011-04-17 08:27:21 --> Router Class Initialized
DEBUG - 2011-04-17 08:27:21 --> Output Class Initialized
DEBUG - 2011-04-17 08:27:21 --> Input Class Initialized
DEBUG - 2011-04-17 08:27:21 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-17 08:27:21 --> Language Class Initialized
DEBUG - 2011-04-17 08:27:21 --> Loader Class Initialized
DEBUG - 2011-04-17 08:27:21 --> Controller Class Initialized
DEBUG - 2011-04-17 08:27:21 --> Model Class Initialized
DEBUG - 2011-04-17 08:27:21 --> Model Class Initialized
DEBUG - 2011-04-17 08:27:21 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-17 08:27:21 --> Database Driver Class Initialized
DEBUG - 2011-04-17 08:27:22 --> Final output sent to browser
DEBUG - 2011-04-17 08:27:22 --> Total execution time: 0.5952
DEBUG - 2011-04-17 08:28:09 --> Config Class Initialized
DEBUG - 2011-04-17 08:28:09 --> Hooks Class Initialized
DEBUG - 2011-04-17 08:28:09 --> Utf8 Class Initialized
DEBUG - 2011-04-17 08:28:09 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 08:28:09 --> URI Class Initialized
DEBUG - 2011-04-17 08:28:09 --> Router Class Initialized
DEBUG - 2011-04-17 08:28:09 --> Output Class Initialized
DEBUG - 2011-04-17 08:28:09 --> Input Class Initialized
DEBUG - 2011-04-17 08:28:09 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-17 08:28:09 --> Language Class Initialized
DEBUG - 2011-04-17 08:28:09 --> Loader Class Initialized
DEBUG - 2011-04-17 08:28:09 --> Controller Class Initialized
DEBUG - 2011-04-17 08:28:09 --> Model Class Initialized
DEBUG - 2011-04-17 08:28:09 --> Model Class Initialized
DEBUG - 2011-04-17 08:28:09 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-17 08:28:09 --> Database Driver Class Initialized
DEBUG - 2011-04-17 08:28:09 --> Final output sent to browser
DEBUG - 2011-04-17 08:28:09 --> Total execution time: 0.5647
DEBUG - 2011-04-17 08:28:11 --> Config Class Initialized
DEBUG - 2011-04-17 08:28:11 --> Hooks Class Initialized
DEBUG - 2011-04-17 08:28:11 --> Utf8 Class Initialized
DEBUG - 2011-04-17 08:28:11 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 08:28:11 --> URI Class Initialized
DEBUG - 2011-04-17 08:28:11 --> Router Class Initialized
ERROR - 2011-04-17 08:28:11 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-04-17 08:28:28 --> Config Class Initialized
DEBUG - 2011-04-17 08:28:28 --> Hooks Class Initialized
DEBUG - 2011-04-17 08:28:28 --> Utf8 Class Initialized
DEBUG - 2011-04-17 08:28:28 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 08:28:28 --> URI Class Initialized
DEBUG - 2011-04-17 08:28:28 --> Router Class Initialized
ERROR - 2011-04-17 08:28:28 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-04-17 08:29:41 --> Config Class Initialized
DEBUG - 2011-04-17 08:29:41 --> Hooks Class Initialized
DEBUG - 2011-04-17 08:29:41 --> Utf8 Class Initialized
DEBUG - 2011-04-17 08:29:41 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 08:29:41 --> URI Class Initialized
DEBUG - 2011-04-17 08:29:41 --> Router Class Initialized
DEBUG - 2011-04-17 08:29:41 --> Output Class Initialized
DEBUG - 2011-04-17 08:29:41 --> Input Class Initialized
DEBUG - 2011-04-17 08:29:41 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-17 08:29:41 --> Language Class Initialized
DEBUG - 2011-04-17 08:29:41 --> Loader Class Initialized
DEBUG - 2011-04-17 08:29:41 --> Controller Class Initialized
ERROR - 2011-04-17 08:29:41 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-17 08:29:41 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-17 08:29:41 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-17 08:29:41 --> Model Class Initialized
DEBUG - 2011-04-17 08:29:41 --> Model Class Initialized
DEBUG - 2011-04-17 08:29:41 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-17 08:29:41 --> Database Driver Class Initialized
DEBUG - 2011-04-17 08:29:41 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-17 08:29:41 --> Helper loaded: url_helper
DEBUG - 2011-04-17 08:29:41 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-17 08:29:41 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-17 08:29:41 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-17 08:29:41 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-17 08:29:41 --> Final output sent to browser
DEBUG - 2011-04-17 08:29:41 --> Total execution time: 0.0361
DEBUG - 2011-04-17 08:29:42 --> Config Class Initialized
DEBUG - 2011-04-17 08:29:42 --> Hooks Class Initialized
DEBUG - 2011-04-17 08:29:42 --> Utf8 Class Initialized
DEBUG - 2011-04-17 08:29:42 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 08:29:42 --> URI Class Initialized
DEBUG - 2011-04-17 08:29:42 --> Router Class Initialized
ERROR - 2011-04-17 08:29:42 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-04-17 08:30:06 --> Config Class Initialized
DEBUG - 2011-04-17 08:30:06 --> Hooks Class Initialized
DEBUG - 2011-04-17 08:30:06 --> Utf8 Class Initialized
DEBUG - 2011-04-17 08:30:06 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 08:30:06 --> URI Class Initialized
DEBUG - 2011-04-17 08:30:06 --> Router Class Initialized
DEBUG - 2011-04-17 08:30:06 --> Output Class Initialized
DEBUG - 2011-04-17 08:30:06 --> Input Class Initialized
DEBUG - 2011-04-17 08:30:06 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-17 08:30:06 --> Language Class Initialized
DEBUG - 2011-04-17 08:30:06 --> Loader Class Initialized
DEBUG - 2011-04-17 08:30:06 --> Controller Class Initialized
ERROR - 2011-04-17 08:30:06 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-17 08:30:06 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-17 08:30:06 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-17 08:30:06 --> Model Class Initialized
DEBUG - 2011-04-17 08:30:06 --> Model Class Initialized
DEBUG - 2011-04-17 08:30:06 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-17 08:30:06 --> Database Driver Class Initialized
DEBUG - 2011-04-17 08:30:07 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-17 08:30:07 --> Helper loaded: url_helper
DEBUG - 2011-04-17 08:30:07 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-17 08:30:07 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-17 08:30:07 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-17 08:30:07 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-17 08:30:07 --> Final output sent to browser
DEBUG - 2011-04-17 08:30:07 --> Total execution time: 0.5619
DEBUG - 2011-04-17 08:30:07 --> Config Class Initialized
DEBUG - 2011-04-17 08:30:07 --> Hooks Class Initialized
DEBUG - 2011-04-17 08:30:07 --> Utf8 Class Initialized
DEBUG - 2011-04-17 08:30:07 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 08:30:07 --> URI Class Initialized
DEBUG - 2011-04-17 08:30:07 --> Router Class Initialized
DEBUG - 2011-04-17 08:30:07 --> Output Class Initialized
DEBUG - 2011-04-17 08:30:07 --> Input Class Initialized
DEBUG - 2011-04-17 08:30:07 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-17 08:30:07 --> Language Class Initialized
DEBUG - 2011-04-17 08:30:07 --> Loader Class Initialized
DEBUG - 2011-04-17 08:30:07 --> Controller Class Initialized
DEBUG - 2011-04-17 08:30:07 --> Model Class Initialized
DEBUG - 2011-04-17 08:30:07 --> Model Class Initialized
DEBUG - 2011-04-17 08:30:07 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-17 08:30:07 --> Database Driver Class Initialized
DEBUG - 2011-04-17 08:30:08 --> Final output sent to browser
DEBUG - 2011-04-17 08:30:08 --> Total execution time: 0.8267
DEBUG - 2011-04-17 08:31:28 --> Config Class Initialized
DEBUG - 2011-04-17 08:31:28 --> Hooks Class Initialized
DEBUG - 2011-04-17 08:31:28 --> Utf8 Class Initialized
DEBUG - 2011-04-17 08:31:28 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 08:31:28 --> URI Class Initialized
DEBUG - 2011-04-17 08:31:28 --> Router Class Initialized
ERROR - 2011-04-17 08:31:28 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-04-17 08:31:28 --> Config Class Initialized
DEBUG - 2011-04-17 08:31:28 --> Hooks Class Initialized
DEBUG - 2011-04-17 08:31:28 --> Utf8 Class Initialized
DEBUG - 2011-04-17 08:31:28 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 08:31:28 --> URI Class Initialized
DEBUG - 2011-04-17 08:31:28 --> Router Class Initialized
DEBUG - 2011-04-17 08:31:28 --> Output Class Initialized
DEBUG - 2011-04-17 08:31:28 --> Input Class Initialized
DEBUG - 2011-04-17 08:31:28 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-17 08:31:28 --> Language Class Initialized
DEBUG - 2011-04-17 08:31:28 --> Loader Class Initialized
DEBUG - 2011-04-17 08:31:28 --> Controller Class Initialized
ERROR - 2011-04-17 08:31:28 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-17 08:31:28 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-17 08:31:28 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-17 08:31:28 --> Model Class Initialized
DEBUG - 2011-04-17 08:31:28 --> Model Class Initialized
DEBUG - 2011-04-17 08:31:28 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-17 08:31:28 --> Database Driver Class Initialized
DEBUG - 2011-04-17 08:31:28 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-17 08:31:28 --> Helper loaded: url_helper
DEBUG - 2011-04-17 08:31:28 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-17 08:31:28 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-17 08:31:28 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-17 08:31:28 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-17 08:31:28 --> Final output sent to browser
DEBUG - 2011-04-17 08:31:28 --> Total execution time: 0.0489
DEBUG - 2011-04-17 08:31:33 --> Config Class Initialized
DEBUG - 2011-04-17 08:31:33 --> Hooks Class Initialized
DEBUG - 2011-04-17 08:31:33 --> Utf8 Class Initialized
DEBUG - 2011-04-17 08:31:33 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 08:31:33 --> URI Class Initialized
DEBUG - 2011-04-17 08:31:33 --> Router Class Initialized
DEBUG - 2011-04-17 08:31:33 --> Output Class Initialized
DEBUG - 2011-04-17 08:31:33 --> Input Class Initialized
DEBUG - 2011-04-17 08:31:33 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-17 08:31:33 --> Language Class Initialized
DEBUG - 2011-04-17 08:31:33 --> Loader Class Initialized
DEBUG - 2011-04-17 08:31:33 --> Controller Class Initialized
DEBUG - 2011-04-17 08:31:33 --> Model Class Initialized
DEBUG - 2011-04-17 08:31:33 --> Model Class Initialized
DEBUG - 2011-04-17 08:31:33 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-17 08:31:33 --> Database Driver Class Initialized
DEBUG - 2011-04-17 08:31:34 --> Final output sent to browser
DEBUG - 2011-04-17 08:31:34 --> Total execution time: 0.6172
DEBUG - 2011-04-17 08:32:29 --> Config Class Initialized
DEBUG - 2011-04-17 08:32:29 --> Hooks Class Initialized
DEBUG - 2011-04-17 08:32:29 --> Utf8 Class Initialized
DEBUG - 2011-04-17 08:32:29 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 08:32:29 --> URI Class Initialized
DEBUG - 2011-04-17 08:32:29 --> Router Class Initialized
DEBUG - 2011-04-17 08:32:29 --> Output Class Initialized
DEBUG - 2011-04-17 08:32:29 --> Input Class Initialized
DEBUG - 2011-04-17 08:32:29 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-17 08:32:29 --> Language Class Initialized
DEBUG - 2011-04-17 08:32:29 --> Loader Class Initialized
DEBUG - 2011-04-17 08:32:29 --> Controller Class Initialized
ERROR - 2011-04-17 08:32:29 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-17 08:32:29 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-17 08:32:29 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-17 08:32:29 --> Model Class Initialized
DEBUG - 2011-04-17 08:32:29 --> Model Class Initialized
DEBUG - 2011-04-17 08:32:29 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-17 08:32:29 --> Database Driver Class Initialized
DEBUG - 2011-04-17 08:32:29 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-17 08:32:29 --> Helper loaded: url_helper
DEBUG - 2011-04-17 08:32:29 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-17 08:32:29 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-17 08:32:29 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-17 08:32:29 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-17 08:32:29 --> Final output sent to browser
DEBUG - 2011-04-17 08:32:29 --> Total execution time: 0.0313
DEBUG - 2011-04-17 08:33:00 --> Config Class Initialized
DEBUG - 2011-04-17 08:33:00 --> Hooks Class Initialized
DEBUG - 2011-04-17 08:33:00 --> Utf8 Class Initialized
DEBUG - 2011-04-17 08:33:00 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 08:33:00 --> URI Class Initialized
DEBUG - 2011-04-17 08:33:00 --> Router Class Initialized
DEBUG - 2011-04-17 08:33:00 --> Output Class Initialized
DEBUG - 2011-04-17 08:33:00 --> Input Class Initialized
DEBUG - 2011-04-17 08:33:00 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-17 08:33:00 --> Language Class Initialized
DEBUG - 2011-04-17 08:33:00 --> Loader Class Initialized
DEBUG - 2011-04-17 08:33:00 --> Controller Class Initialized
ERROR - 2011-04-17 08:33:00 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-17 08:33:00 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-17 08:33:00 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-17 08:33:00 --> Model Class Initialized
DEBUG - 2011-04-17 08:33:00 --> Model Class Initialized
DEBUG - 2011-04-17 08:33:00 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-17 08:33:00 --> Database Driver Class Initialized
DEBUG - 2011-04-17 08:33:01 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-17 08:33:01 --> Helper loaded: url_helper
DEBUG - 2011-04-17 08:33:01 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-17 08:33:01 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-17 08:33:01 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-17 08:33:01 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-17 08:33:01 --> Final output sent to browser
DEBUG - 2011-04-17 08:33:01 --> Total execution time: 0.1911
DEBUG - 2011-04-17 08:34:33 --> Config Class Initialized
DEBUG - 2011-04-17 08:34:33 --> Hooks Class Initialized
DEBUG - 2011-04-17 08:34:33 --> Utf8 Class Initialized
DEBUG - 2011-04-17 08:34:33 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 08:34:33 --> URI Class Initialized
DEBUG - 2011-04-17 08:34:33 --> Router Class Initialized
DEBUG - 2011-04-17 08:34:33 --> Output Class Initialized
DEBUG - 2011-04-17 08:34:33 --> Input Class Initialized
DEBUG - 2011-04-17 08:34:33 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-17 08:34:33 --> Language Class Initialized
DEBUG - 2011-04-17 08:34:33 --> Loader Class Initialized
DEBUG - 2011-04-17 08:34:33 --> Controller Class Initialized
ERROR - 2011-04-17 08:34:33 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-17 08:34:33 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-17 08:34:33 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-17 08:34:33 --> Model Class Initialized
DEBUG - 2011-04-17 08:34:33 --> Model Class Initialized
DEBUG - 2011-04-17 08:34:33 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-17 08:34:33 --> Database Driver Class Initialized
DEBUG - 2011-04-17 08:34:33 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-17 08:34:33 --> Helper loaded: url_helper
DEBUG - 2011-04-17 08:34:33 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-17 08:34:33 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-17 08:34:33 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-17 08:34:33 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-17 08:34:33 --> Final output sent to browser
DEBUG - 2011-04-17 08:34:33 --> Total execution time: 0.0299
DEBUG - 2011-04-17 08:35:14 --> Config Class Initialized
DEBUG - 2011-04-17 08:35:14 --> Hooks Class Initialized
DEBUG - 2011-04-17 08:35:14 --> Utf8 Class Initialized
DEBUG - 2011-04-17 08:35:14 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 08:35:14 --> URI Class Initialized
DEBUG - 2011-04-17 08:35:14 --> Router Class Initialized
DEBUG - 2011-04-17 08:35:14 --> Output Class Initialized
DEBUG - 2011-04-17 08:35:14 --> Input Class Initialized
DEBUG - 2011-04-17 08:35:14 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-17 08:35:14 --> Language Class Initialized
DEBUG - 2011-04-17 08:35:14 --> Loader Class Initialized
DEBUG - 2011-04-17 08:35:14 --> Controller Class Initialized
ERROR - 2011-04-17 08:35:14 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-17 08:35:14 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-17 08:35:14 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-17 08:35:14 --> Model Class Initialized
DEBUG - 2011-04-17 08:35:14 --> Model Class Initialized
DEBUG - 2011-04-17 08:35:14 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-17 08:35:14 --> Database Driver Class Initialized
DEBUG - 2011-04-17 08:35:14 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-17 08:35:14 --> Helper loaded: url_helper
DEBUG - 2011-04-17 08:35:14 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-17 08:35:14 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-17 08:35:14 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-17 08:35:14 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-17 08:35:14 --> Final output sent to browser
DEBUG - 2011-04-17 08:35:14 --> Total execution time: 0.0309
DEBUG - 2011-04-17 08:37:05 --> Config Class Initialized
DEBUG - 2011-04-17 08:37:05 --> Hooks Class Initialized
DEBUG - 2011-04-17 08:37:05 --> Utf8 Class Initialized
DEBUG - 2011-04-17 08:37:05 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 08:37:05 --> URI Class Initialized
DEBUG - 2011-04-17 08:37:05 --> Router Class Initialized
DEBUG - 2011-04-17 08:37:05 --> Output Class Initialized
DEBUG - 2011-04-17 08:37:05 --> Input Class Initialized
DEBUG - 2011-04-17 08:37:05 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-17 08:37:05 --> Language Class Initialized
DEBUG - 2011-04-17 08:37:05 --> Loader Class Initialized
DEBUG - 2011-04-17 08:37:05 --> Controller Class Initialized
ERROR - 2011-04-17 08:37:05 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-17 08:37:05 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-17 08:37:05 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-17 08:37:05 --> Model Class Initialized
DEBUG - 2011-04-17 08:37:05 --> Model Class Initialized
DEBUG - 2011-04-17 08:37:05 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-17 08:37:05 --> Database Driver Class Initialized
DEBUG - 2011-04-17 08:37:05 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-17 08:37:05 --> Helper loaded: url_helper
DEBUG - 2011-04-17 08:37:05 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-17 08:37:05 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-17 08:37:05 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-17 08:37:05 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-17 08:37:05 --> Final output sent to browser
DEBUG - 2011-04-17 08:37:05 --> Total execution time: 0.0761
DEBUG - 2011-04-17 08:37:05 --> Config Class Initialized
DEBUG - 2011-04-17 08:37:05 --> Hooks Class Initialized
DEBUG - 2011-04-17 08:37:05 --> Utf8 Class Initialized
DEBUG - 2011-04-17 08:37:05 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 08:37:05 --> URI Class Initialized
DEBUG - 2011-04-17 08:37:05 --> Router Class Initialized
DEBUG - 2011-04-17 08:37:05 --> Output Class Initialized
DEBUG - 2011-04-17 08:37:05 --> Input Class Initialized
DEBUG - 2011-04-17 08:37:05 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-17 08:37:05 --> Language Class Initialized
DEBUG - 2011-04-17 08:37:05 --> Loader Class Initialized
DEBUG - 2011-04-17 08:37:05 --> Controller Class Initialized
DEBUG - 2011-04-17 08:37:05 --> Model Class Initialized
DEBUG - 2011-04-17 08:37:05 --> Model Class Initialized
DEBUG - 2011-04-17 08:37:05 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-17 08:37:05 --> Database Driver Class Initialized
DEBUG - 2011-04-17 08:37:06 --> Final output sent to browser
DEBUG - 2011-04-17 08:37:06 --> Total execution time: 0.8277
DEBUG - 2011-04-17 08:37:08 --> Config Class Initialized
DEBUG - 2011-04-17 08:37:08 --> Hooks Class Initialized
DEBUG - 2011-04-17 08:37:08 --> Utf8 Class Initialized
DEBUG - 2011-04-17 08:37:08 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 08:37:08 --> URI Class Initialized
DEBUG - 2011-04-17 08:37:08 --> Router Class Initialized
ERROR - 2011-04-17 08:37:08 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-17 08:37:08 --> Config Class Initialized
DEBUG - 2011-04-17 08:37:08 --> Hooks Class Initialized
DEBUG - 2011-04-17 08:37:08 --> Utf8 Class Initialized
DEBUG - 2011-04-17 08:37:08 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 08:37:08 --> URI Class Initialized
DEBUG - 2011-04-17 08:37:08 --> Router Class Initialized
ERROR - 2011-04-17 08:37:08 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-17 09:54:22 --> Config Class Initialized
DEBUG - 2011-04-17 09:54:22 --> Hooks Class Initialized
DEBUG - 2011-04-17 09:54:22 --> Utf8 Class Initialized
DEBUG - 2011-04-17 09:54:22 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 09:54:22 --> URI Class Initialized
DEBUG - 2011-04-17 09:54:22 --> Router Class Initialized
DEBUG - 2011-04-17 09:54:22 --> Output Class Initialized
DEBUG - 2011-04-17 09:54:22 --> Input Class Initialized
DEBUG - 2011-04-17 09:54:22 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-17 09:54:22 --> Language Class Initialized
DEBUG - 2011-04-17 09:54:22 --> Loader Class Initialized
DEBUG - 2011-04-17 09:54:22 --> Controller Class Initialized
ERROR - 2011-04-17 09:54:22 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-17 09:54:22 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-17 09:54:22 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-17 09:54:22 --> Model Class Initialized
DEBUG - 2011-04-17 09:54:22 --> Model Class Initialized
DEBUG - 2011-04-17 09:54:22 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-17 09:54:22 --> Database Driver Class Initialized
DEBUG - 2011-04-17 09:54:22 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-17 09:54:22 --> Helper loaded: url_helper
DEBUG - 2011-04-17 09:54:22 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-17 09:54:22 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-17 09:54:22 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-17 09:54:22 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-17 09:54:22 --> Final output sent to browser
DEBUG - 2011-04-17 09:54:22 --> Total execution time: 0.6047
DEBUG - 2011-04-17 09:54:24 --> Config Class Initialized
DEBUG - 2011-04-17 09:54:24 --> Hooks Class Initialized
DEBUG - 2011-04-17 09:54:24 --> Utf8 Class Initialized
DEBUG - 2011-04-17 09:54:24 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 09:54:24 --> URI Class Initialized
DEBUG - 2011-04-17 09:54:24 --> Router Class Initialized
DEBUG - 2011-04-17 09:54:24 --> Output Class Initialized
DEBUG - 2011-04-17 09:54:24 --> Input Class Initialized
DEBUG - 2011-04-17 09:54:24 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-17 09:54:24 --> Language Class Initialized
DEBUG - 2011-04-17 09:54:24 --> Loader Class Initialized
DEBUG - 2011-04-17 09:54:24 --> Controller Class Initialized
DEBUG - 2011-04-17 09:54:24 --> Model Class Initialized
DEBUG - 2011-04-17 09:54:24 --> Model Class Initialized
DEBUG - 2011-04-17 09:54:24 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-17 09:54:24 --> Database Driver Class Initialized
DEBUG - 2011-04-17 09:54:24 --> Final output sent to browser
DEBUG - 2011-04-17 09:54:24 --> Total execution time: 0.7047
DEBUG - 2011-04-17 09:54:27 --> Config Class Initialized
DEBUG - 2011-04-17 09:54:27 --> Hooks Class Initialized
DEBUG - 2011-04-17 09:54:27 --> Utf8 Class Initialized
DEBUG - 2011-04-17 09:54:27 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 09:54:27 --> URI Class Initialized
DEBUG - 2011-04-17 09:54:27 --> Router Class Initialized
ERROR - 2011-04-17 09:54:27 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-17 09:54:27 --> Config Class Initialized
DEBUG - 2011-04-17 09:54:27 --> Hooks Class Initialized
DEBUG - 2011-04-17 09:54:27 --> Utf8 Class Initialized
DEBUG - 2011-04-17 09:54:27 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 09:54:27 --> URI Class Initialized
DEBUG - 2011-04-17 09:54:27 --> Router Class Initialized
ERROR - 2011-04-17 09:54:27 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-17 09:54:28 --> Config Class Initialized
DEBUG - 2011-04-17 09:54:28 --> Hooks Class Initialized
DEBUG - 2011-04-17 09:54:28 --> Utf8 Class Initialized
DEBUG - 2011-04-17 09:54:28 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 09:54:28 --> URI Class Initialized
DEBUG - 2011-04-17 09:54:28 --> Router Class Initialized
ERROR - 2011-04-17 09:54:28 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-17 10:42:42 --> Config Class Initialized
DEBUG - 2011-04-17 10:42:42 --> Hooks Class Initialized
DEBUG - 2011-04-17 10:42:42 --> Utf8 Class Initialized
DEBUG - 2011-04-17 10:42:42 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 10:42:42 --> URI Class Initialized
DEBUG - 2011-04-17 10:42:42 --> Router Class Initialized
ERROR - 2011-04-17 10:42:42 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-04-17 10:42:42 --> Config Class Initialized
DEBUG - 2011-04-17 10:42:42 --> Hooks Class Initialized
DEBUG - 2011-04-17 10:42:42 --> Utf8 Class Initialized
DEBUG - 2011-04-17 10:42:42 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 10:42:42 --> URI Class Initialized
DEBUG - 2011-04-17 10:42:42 --> Router Class Initialized
DEBUG - 2011-04-17 10:42:42 --> Output Class Initialized
DEBUG - 2011-04-17 10:42:42 --> Input Class Initialized
DEBUG - 2011-04-17 10:42:42 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-17 10:42:42 --> Language Class Initialized
DEBUG - 2011-04-17 10:42:42 --> Loader Class Initialized
DEBUG - 2011-04-17 10:42:42 --> Controller Class Initialized
DEBUG - 2011-04-17 10:42:42 --> Model Class Initialized
DEBUG - 2011-04-17 10:42:42 --> Model Class Initialized
DEBUG - 2011-04-17 10:42:42 --> Model Class Initialized
DEBUG - 2011-04-17 10:42:42 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-17 10:42:42 --> Database Driver Class Initialized
DEBUG - 2011-04-17 10:42:43 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-17 10:42:43 --> Helper loaded: url_helper
DEBUG - 2011-04-17 10:42:43 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-17 10:42:43 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-17 10:42:43 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-17 10:42:43 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-17 10:42:44 --> Config Class Initialized
DEBUG - 2011-04-17 10:42:44 --> Hooks Class Initialized
DEBUG - 2011-04-17 10:42:44 --> Utf8 Class Initialized
DEBUG - 2011-04-17 10:42:44 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 10:42:44 --> URI Class Initialized
DEBUG - 2011-04-17 10:42:44 --> Router Class Initialized
ERROR - 2011-04-17 10:42:44 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-04-17 10:42:44 --> Config Class Initialized
DEBUG - 2011-04-17 10:42:44 --> Hooks Class Initialized
DEBUG - 2011-04-17 10:42:44 --> Utf8 Class Initialized
DEBUG - 2011-04-17 10:42:44 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 10:42:44 --> URI Class Initialized
DEBUG - 2011-04-17 10:42:44 --> Router Class Initialized
DEBUG - 2011-04-17 10:42:44 --> Output Class Initialized
DEBUG - 2011-04-17 10:42:44 --> Input Class Initialized
DEBUG - 2011-04-17 10:42:44 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-17 10:42:44 --> Language Class Initialized
DEBUG - 2011-04-17 10:42:44 --> Loader Class Initialized
DEBUG - 2011-04-17 10:42:44 --> Controller Class Initialized
ERROR - 2011-04-17 10:42:44 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-17 10:42:44 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-17 10:42:44 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-17 10:42:44 --> Model Class Initialized
DEBUG - 2011-04-17 10:42:44 --> Model Class Initialized
DEBUG - 2011-04-17 10:42:44 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-17 10:42:44 --> Database Driver Class Initialized
DEBUG - 2011-04-17 10:42:44 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-17 10:42:44 --> Helper loaded: url_helper
DEBUG - 2011-04-17 10:42:44 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-17 10:42:44 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-17 10:42:44 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-17 10:42:44 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-17 10:42:45 --> Config Class Initialized
DEBUG - 2011-04-17 10:42:45 --> Hooks Class Initialized
DEBUG - 2011-04-17 10:42:45 --> Utf8 Class Initialized
DEBUG - 2011-04-17 10:42:45 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 10:42:45 --> URI Class Initialized
DEBUG - 2011-04-17 10:42:45 --> Router Class Initialized
DEBUG - 2011-04-17 10:42:45 --> Output Class Initialized
DEBUG - 2011-04-17 10:42:45 --> Input Class Initialized
DEBUG - 2011-04-17 10:42:45 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-17 10:42:45 --> Language Class Initialized
DEBUG - 2011-04-17 10:42:45 --> Loader Class Initialized
DEBUG - 2011-04-17 10:42:45 --> Controller Class Initialized
DEBUG - 2011-04-17 10:42:45 --> Model Class Initialized
DEBUG - 2011-04-17 10:42:45 --> Model Class Initialized
DEBUG - 2011-04-17 10:42:45 --> Model Class Initialized
DEBUG - 2011-04-17 10:42:45 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-17 10:42:45 --> Database Driver Class Initialized
DEBUG - 2011-04-17 10:42:45 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-17 10:42:45 --> Helper loaded: url_helper
DEBUG - 2011-04-17 10:42:45 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-17 10:42:45 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-17 10:42:45 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-17 10:42:45 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-17 10:42:45 --> Final output sent to browser
DEBUG - 2011-04-17 10:42:45 --> Total execution time: 0.0734
DEBUG - 2011-04-17 10:51:02 --> Config Class Initialized
DEBUG - 2011-04-17 10:51:02 --> Hooks Class Initialized
DEBUG - 2011-04-17 10:51:02 --> Utf8 Class Initialized
DEBUG - 2011-04-17 10:51:02 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 10:51:02 --> URI Class Initialized
DEBUG - 2011-04-17 10:51:02 --> Router Class Initialized
ERROR - 2011-04-17 10:51:02 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-04-17 10:51:02 --> Config Class Initialized
DEBUG - 2011-04-17 10:51:02 --> Hooks Class Initialized
DEBUG - 2011-04-17 10:51:02 --> Utf8 Class Initialized
DEBUG - 2011-04-17 10:51:02 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 10:51:02 --> URI Class Initialized
DEBUG - 2011-04-17 10:51:02 --> Router Class Initialized
DEBUG - 2011-04-17 10:51:02 --> Output Class Initialized
DEBUG - 2011-04-17 10:51:02 --> Input Class Initialized
DEBUG - 2011-04-17 10:51:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-17 10:51:02 --> Language Class Initialized
DEBUG - 2011-04-17 10:51:02 --> Loader Class Initialized
DEBUG - 2011-04-17 10:51:02 --> Controller Class Initialized
DEBUG - 2011-04-17 10:51:02 --> Model Class Initialized
DEBUG - 2011-04-17 10:51:02 --> Model Class Initialized
DEBUG - 2011-04-17 10:51:02 --> Model Class Initialized
DEBUG - 2011-04-17 10:51:02 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-17 10:51:02 --> Database Driver Class Initialized
DEBUG - 2011-04-17 10:51:02 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-17 10:51:02 --> Helper loaded: url_helper
DEBUG - 2011-04-17 10:51:02 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-17 10:51:02 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-17 10:51:02 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-17 10:51:02 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-17 10:51:02 --> Final output sent to browser
DEBUG - 2011-04-17 10:51:02 --> Total execution time: 0.0511
DEBUG - 2011-04-17 10:51:33 --> Config Class Initialized
DEBUG - 2011-04-17 10:51:33 --> Hooks Class Initialized
DEBUG - 2011-04-17 10:51:33 --> Utf8 Class Initialized
DEBUG - 2011-04-17 10:51:33 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 10:51:33 --> URI Class Initialized
DEBUG - 2011-04-17 10:51:33 --> Router Class Initialized
DEBUG - 2011-04-17 10:51:33 --> Output Class Initialized
DEBUG - 2011-04-17 10:51:33 --> Input Class Initialized
DEBUG - 2011-04-17 10:51:33 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-17 10:51:33 --> Language Class Initialized
DEBUG - 2011-04-17 10:51:33 --> Loader Class Initialized
DEBUG - 2011-04-17 10:51:33 --> Controller Class Initialized
ERROR - 2011-04-17 10:51:33 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-17 10:51:33 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-17 10:51:33 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-17 10:51:33 --> Model Class Initialized
DEBUG - 2011-04-17 10:51:33 --> Model Class Initialized
DEBUG - 2011-04-17 10:51:33 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-17 10:51:33 --> Database Driver Class Initialized
DEBUG - 2011-04-17 10:51:33 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-17 10:51:33 --> Helper loaded: url_helper
DEBUG - 2011-04-17 10:51:33 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-17 10:51:33 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-17 10:51:33 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-17 10:51:33 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-17 10:51:33 --> Final output sent to browser
DEBUG - 2011-04-17 10:51:33 --> Total execution time: 0.0426
DEBUG - 2011-04-17 11:05:21 --> Config Class Initialized
DEBUG - 2011-04-17 11:05:21 --> Hooks Class Initialized
DEBUG - 2011-04-17 11:05:22 --> Utf8 Class Initialized
DEBUG - 2011-04-17 11:05:22 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 11:05:22 --> URI Class Initialized
DEBUG - 2011-04-17 11:05:22 --> Router Class Initialized
DEBUG - 2011-04-17 11:05:23 --> Output Class Initialized
DEBUG - 2011-04-17 11:05:23 --> Input Class Initialized
DEBUG - 2011-04-17 11:05:23 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-17 11:05:24 --> Language Class Initialized
DEBUG - 2011-04-17 11:05:24 --> Loader Class Initialized
DEBUG - 2011-04-17 11:05:24 --> Controller Class Initialized
ERROR - 2011-04-17 11:05:25 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-17 11:05:25 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-17 11:05:25 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-17 11:05:25 --> Model Class Initialized
DEBUG - 2011-04-17 11:05:25 --> Model Class Initialized
DEBUG - 2011-04-17 11:05:25 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-17 11:05:25 --> Database Driver Class Initialized
DEBUG - 2011-04-17 11:05:25 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-17 11:05:25 --> Helper loaded: url_helper
DEBUG - 2011-04-17 11:05:25 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-17 11:05:25 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-17 11:05:25 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-17 11:05:25 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-17 11:05:25 --> Final output sent to browser
DEBUG - 2011-04-17 11:05:25 --> Total execution time: 4.5732
DEBUG - 2011-04-17 11:05:27 --> Config Class Initialized
DEBUG - 2011-04-17 11:05:27 --> Hooks Class Initialized
DEBUG - 2011-04-17 11:05:27 --> Utf8 Class Initialized
DEBUG - 2011-04-17 11:05:27 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 11:05:27 --> URI Class Initialized
DEBUG - 2011-04-17 11:05:27 --> Router Class Initialized
DEBUG - 2011-04-17 11:05:27 --> Output Class Initialized
DEBUG - 2011-04-17 11:05:27 --> Input Class Initialized
DEBUG - 2011-04-17 11:05:27 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-17 11:05:27 --> Language Class Initialized
DEBUG - 2011-04-17 11:05:27 --> Loader Class Initialized
DEBUG - 2011-04-17 11:05:27 --> Controller Class Initialized
DEBUG - 2011-04-17 11:05:27 --> Model Class Initialized
DEBUG - 2011-04-17 11:05:27 --> Model Class Initialized
DEBUG - 2011-04-17 11:05:27 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-17 11:05:27 --> Database Driver Class Initialized
DEBUG - 2011-04-17 11:05:27 --> Final output sent to browser
DEBUG - 2011-04-17 11:05:27 --> Total execution time: 0.7062
DEBUG - 2011-04-17 11:05:29 --> Config Class Initialized
DEBUG - 2011-04-17 11:05:29 --> Hooks Class Initialized
DEBUG - 2011-04-17 11:05:29 --> Utf8 Class Initialized
DEBUG - 2011-04-17 11:05:29 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 11:05:29 --> URI Class Initialized
DEBUG - 2011-04-17 11:05:29 --> Router Class Initialized
ERROR - 2011-04-17 11:05:29 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-17 11:05:30 --> Config Class Initialized
DEBUG - 2011-04-17 11:05:30 --> Hooks Class Initialized
DEBUG - 2011-04-17 11:05:30 --> Utf8 Class Initialized
DEBUG - 2011-04-17 11:05:30 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 11:05:30 --> URI Class Initialized
DEBUG - 2011-04-17 11:05:30 --> Router Class Initialized
ERROR - 2011-04-17 11:05:30 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-17 11:11:26 --> Config Class Initialized
DEBUG - 2011-04-17 11:11:26 --> Hooks Class Initialized
DEBUG - 2011-04-17 11:11:26 --> Utf8 Class Initialized
DEBUG - 2011-04-17 11:11:26 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 11:11:26 --> URI Class Initialized
DEBUG - 2011-04-17 11:11:26 --> Router Class Initialized
DEBUG - 2011-04-17 11:11:26 --> Output Class Initialized
DEBUG - 2011-04-17 11:11:26 --> Input Class Initialized
DEBUG - 2011-04-17 11:11:26 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-17 11:11:26 --> Language Class Initialized
DEBUG - 2011-04-17 11:11:26 --> Loader Class Initialized
DEBUG - 2011-04-17 11:11:26 --> Controller Class Initialized
DEBUG - 2011-04-17 11:11:26 --> Model Class Initialized
DEBUG - 2011-04-17 11:11:26 --> Model Class Initialized
DEBUG - 2011-04-17 11:11:26 --> Model Class Initialized
DEBUG - 2011-04-17 11:11:26 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-17 11:11:26 --> Database Driver Class Initialized
DEBUG - 2011-04-17 11:11:27 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-17 11:11:27 --> Helper loaded: url_helper
DEBUG - 2011-04-17 11:11:27 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-17 11:11:27 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-17 11:11:27 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-17 11:11:27 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-17 11:11:27 --> Final output sent to browser
DEBUG - 2011-04-17 11:11:27 --> Total execution time: 0.5189
DEBUG - 2011-04-17 11:11:28 --> Config Class Initialized
DEBUG - 2011-04-17 11:11:28 --> Hooks Class Initialized
DEBUG - 2011-04-17 11:11:28 --> Utf8 Class Initialized
DEBUG - 2011-04-17 11:11:28 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 11:11:28 --> URI Class Initialized
DEBUG - 2011-04-17 11:11:28 --> Router Class Initialized
ERROR - 2011-04-17 11:11:28 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-17 11:12:50 --> Config Class Initialized
DEBUG - 2011-04-17 11:12:50 --> Hooks Class Initialized
DEBUG - 2011-04-17 11:12:50 --> Utf8 Class Initialized
DEBUG - 2011-04-17 11:12:50 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 11:12:50 --> URI Class Initialized
DEBUG - 2011-04-17 11:12:50 --> Router Class Initialized
DEBUG - 2011-04-17 11:12:50 --> Output Class Initialized
DEBUG - 2011-04-17 11:12:50 --> Input Class Initialized
DEBUG - 2011-04-17 11:12:50 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-17 11:12:50 --> Language Class Initialized
DEBUG - 2011-04-17 11:12:50 --> Loader Class Initialized
DEBUG - 2011-04-17 11:12:50 --> Controller Class Initialized
ERROR - 2011-04-17 11:12:50 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-17 11:12:50 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-17 11:12:50 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-17 11:12:50 --> Model Class Initialized
DEBUG - 2011-04-17 11:12:50 --> Model Class Initialized
DEBUG - 2011-04-17 11:12:50 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-17 11:12:50 --> Database Driver Class Initialized
DEBUG - 2011-04-17 11:12:50 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-17 11:12:50 --> Helper loaded: url_helper
DEBUG - 2011-04-17 11:12:50 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-17 11:12:50 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-17 11:12:50 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-17 11:12:50 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-17 11:12:50 --> Final output sent to browser
DEBUG - 2011-04-17 11:12:50 --> Total execution time: 0.0563
DEBUG - 2011-04-17 11:12:52 --> Config Class Initialized
DEBUG - 2011-04-17 11:12:52 --> Hooks Class Initialized
DEBUG - 2011-04-17 11:12:52 --> Utf8 Class Initialized
DEBUG - 2011-04-17 11:12:52 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 11:12:52 --> URI Class Initialized
DEBUG - 2011-04-17 11:12:52 --> Router Class Initialized
DEBUG - 2011-04-17 11:12:52 --> Output Class Initialized
DEBUG - 2011-04-17 11:12:52 --> Input Class Initialized
DEBUG - 2011-04-17 11:12:52 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-17 11:12:52 --> Language Class Initialized
DEBUG - 2011-04-17 11:12:52 --> Loader Class Initialized
DEBUG - 2011-04-17 11:12:52 --> Controller Class Initialized
DEBUG - 2011-04-17 11:12:52 --> Model Class Initialized
DEBUG - 2011-04-17 11:12:52 --> Model Class Initialized
DEBUG - 2011-04-17 11:12:52 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-17 11:12:52 --> Database Driver Class Initialized
DEBUG - 2011-04-17 11:12:53 --> Final output sent to browser
DEBUG - 2011-04-17 11:12:53 --> Total execution time: 0.9440
DEBUG - 2011-04-17 11:13:43 --> Config Class Initialized
DEBUG - 2011-04-17 11:13:43 --> Hooks Class Initialized
DEBUG - 2011-04-17 11:13:43 --> Utf8 Class Initialized
DEBUG - 2011-04-17 11:13:43 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 11:13:43 --> URI Class Initialized
DEBUG - 2011-04-17 11:13:43 --> Router Class Initialized
DEBUG - 2011-04-17 11:13:43 --> Output Class Initialized
DEBUG - 2011-04-17 11:13:43 --> Input Class Initialized
DEBUG - 2011-04-17 11:13:43 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-17 11:13:43 --> Language Class Initialized
DEBUG - 2011-04-17 11:13:43 --> Loader Class Initialized
DEBUG - 2011-04-17 11:13:43 --> Controller Class Initialized
DEBUG - 2011-04-17 11:13:43 --> Model Class Initialized
DEBUG - 2011-04-17 11:13:43 --> Model Class Initialized
DEBUG - 2011-04-17 11:13:43 --> Model Class Initialized
DEBUG - 2011-04-17 11:13:43 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-17 11:13:43 --> Database Driver Class Initialized
DEBUG - 2011-04-17 11:13:43 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-17 11:13:43 --> Helper loaded: url_helper
DEBUG - 2011-04-17 11:13:43 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-17 11:13:43 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-17 11:13:43 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-17 11:13:43 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-17 11:13:43 --> Final output sent to browser
DEBUG - 2011-04-17 11:13:43 --> Total execution time: 0.0480
DEBUG - 2011-04-17 11:15:25 --> Config Class Initialized
DEBUG - 2011-04-17 11:15:25 --> Hooks Class Initialized
DEBUG - 2011-04-17 11:15:25 --> Utf8 Class Initialized
DEBUG - 2011-04-17 11:15:25 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 11:15:25 --> URI Class Initialized
DEBUG - 2011-04-17 11:15:25 --> Router Class Initialized
DEBUG - 2011-04-17 11:15:25 --> Output Class Initialized
DEBUG - 2011-04-17 11:15:25 --> Input Class Initialized
DEBUG - 2011-04-17 11:15:25 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-17 11:15:25 --> Language Class Initialized
DEBUG - 2011-04-17 11:15:25 --> Loader Class Initialized
DEBUG - 2011-04-17 11:15:25 --> Controller Class Initialized
DEBUG - 2011-04-17 11:15:25 --> Model Class Initialized
DEBUG - 2011-04-17 11:15:25 --> Model Class Initialized
DEBUG - 2011-04-17 11:15:25 --> Model Class Initialized
DEBUG - 2011-04-17 11:15:25 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-17 11:15:25 --> Database Driver Class Initialized
DEBUG - 2011-04-17 11:15:25 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-17 11:15:25 --> Helper loaded: url_helper
DEBUG - 2011-04-17 11:15:25 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-17 11:15:25 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-17 11:15:25 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-17 11:15:25 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-17 11:15:25 --> Final output sent to browser
DEBUG - 2011-04-17 11:15:25 --> Total execution time: 0.0952
DEBUG - 2011-04-17 11:17:01 --> Config Class Initialized
DEBUG - 2011-04-17 11:17:01 --> Hooks Class Initialized
DEBUG - 2011-04-17 11:17:01 --> Utf8 Class Initialized
DEBUG - 2011-04-17 11:17:01 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 11:17:01 --> URI Class Initialized
DEBUG - 2011-04-17 11:17:01 --> Router Class Initialized
DEBUG - 2011-04-17 11:17:01 --> No URI present. Default controller set.
DEBUG - 2011-04-17 11:17:01 --> Output Class Initialized
DEBUG - 2011-04-17 11:17:01 --> Input Class Initialized
DEBUG - 2011-04-17 11:17:01 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-17 11:17:01 --> Language Class Initialized
DEBUG - 2011-04-17 11:17:01 --> Loader Class Initialized
DEBUG - 2011-04-17 11:17:01 --> Controller Class Initialized
DEBUG - 2011-04-17 11:17:01 --> File loaded: application/views/splash/main.php
DEBUG - 2011-04-17 11:17:01 --> Helper loaded: url_helper
DEBUG - 2011-04-17 11:17:01 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-17 11:17:01 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-17 11:17:01 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-17 11:17:01 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-17 11:17:01 --> Final output sent to browser
DEBUG - 2011-04-17 11:17:01 --> Total execution time: 0.0709
DEBUG - 2011-04-17 11:24:26 --> Config Class Initialized
DEBUG - 2011-04-17 11:24:26 --> Hooks Class Initialized
DEBUG - 2011-04-17 11:24:26 --> Utf8 Class Initialized
DEBUG - 2011-04-17 11:24:26 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 11:24:26 --> URI Class Initialized
DEBUG - 2011-04-17 11:24:26 --> Router Class Initialized
DEBUG - 2011-04-17 11:24:26 --> Output Class Initialized
DEBUG - 2011-04-17 11:24:26 --> Input Class Initialized
DEBUG - 2011-04-17 11:24:26 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-17 11:24:26 --> Language Class Initialized
DEBUG - 2011-04-17 11:24:26 --> Loader Class Initialized
DEBUG - 2011-04-17 11:24:26 --> Controller Class Initialized
DEBUG - 2011-04-17 11:24:26 --> Model Class Initialized
DEBUG - 2011-04-17 11:24:26 --> Model Class Initialized
DEBUG - 2011-04-17 11:24:26 --> Model Class Initialized
DEBUG - 2011-04-17 11:24:26 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-17 11:24:26 --> Database Driver Class Initialized
DEBUG - 2011-04-17 11:24:26 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-17 11:24:26 --> Helper loaded: url_helper
DEBUG - 2011-04-17 11:24:26 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-17 11:24:26 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-17 11:24:26 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-17 11:24:26 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-17 11:24:26 --> Final output sent to browser
DEBUG - 2011-04-17 11:24:26 --> Total execution time: 0.2815
DEBUG - 2011-04-17 11:24:30 --> Config Class Initialized
DEBUG - 2011-04-17 11:24:30 --> Hooks Class Initialized
DEBUG - 2011-04-17 11:24:30 --> Utf8 Class Initialized
DEBUG - 2011-04-17 11:24:30 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 11:24:30 --> URI Class Initialized
DEBUG - 2011-04-17 11:24:30 --> Router Class Initialized
ERROR - 2011-04-17 11:24:30 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-17 11:24:30 --> Config Class Initialized
DEBUG - 2011-04-17 11:24:30 --> Hooks Class Initialized
DEBUG - 2011-04-17 11:24:30 --> Utf8 Class Initialized
DEBUG - 2011-04-17 11:24:30 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 11:24:30 --> URI Class Initialized
DEBUG - 2011-04-17 11:24:30 --> Router Class Initialized
ERROR - 2011-04-17 11:24:30 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-17 11:24:31 --> Config Class Initialized
DEBUG - 2011-04-17 11:24:31 --> Hooks Class Initialized
DEBUG - 2011-04-17 11:24:31 --> Utf8 Class Initialized
DEBUG - 2011-04-17 11:24:31 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 11:24:31 --> URI Class Initialized
DEBUG - 2011-04-17 11:24:31 --> Router Class Initialized
ERROR - 2011-04-17 11:24:31 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-17 11:26:28 --> Config Class Initialized
DEBUG - 2011-04-17 11:26:28 --> Hooks Class Initialized
DEBUG - 2011-04-17 11:26:28 --> Utf8 Class Initialized
DEBUG - 2011-04-17 11:26:28 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 11:26:28 --> URI Class Initialized
DEBUG - 2011-04-17 11:26:28 --> Router Class Initialized
DEBUG - 2011-04-17 11:26:28 --> Output Class Initialized
DEBUG - 2011-04-17 11:26:28 --> Input Class Initialized
DEBUG - 2011-04-17 11:26:28 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-17 11:26:28 --> Language Class Initialized
DEBUG - 2011-04-17 11:26:28 --> Loader Class Initialized
DEBUG - 2011-04-17 11:26:28 --> Controller Class Initialized
ERROR - 2011-04-17 11:26:28 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-17 11:26:28 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-17 11:26:28 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-17 11:26:28 --> Model Class Initialized
DEBUG - 2011-04-17 11:26:28 --> Model Class Initialized
DEBUG - 2011-04-17 11:26:28 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-17 11:26:28 --> Database Driver Class Initialized
DEBUG - 2011-04-17 11:26:28 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-17 11:26:28 --> Helper loaded: url_helper
DEBUG - 2011-04-17 11:26:28 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-17 11:26:28 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-17 11:26:28 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-17 11:26:28 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-17 11:26:28 --> Final output sent to browser
DEBUG - 2011-04-17 11:26:28 --> Total execution time: 0.1003
DEBUG - 2011-04-17 11:26:30 --> Config Class Initialized
DEBUG - 2011-04-17 11:26:30 --> Hooks Class Initialized
DEBUG - 2011-04-17 11:26:30 --> Utf8 Class Initialized
DEBUG - 2011-04-17 11:26:30 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 11:26:30 --> URI Class Initialized
DEBUG - 2011-04-17 11:26:30 --> Router Class Initialized
DEBUG - 2011-04-17 11:26:30 --> Output Class Initialized
DEBUG - 2011-04-17 11:26:30 --> Input Class Initialized
DEBUG - 2011-04-17 11:26:30 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-17 11:26:30 --> Language Class Initialized
DEBUG - 2011-04-17 11:26:30 --> Loader Class Initialized
DEBUG - 2011-04-17 11:26:30 --> Controller Class Initialized
DEBUG - 2011-04-17 11:26:30 --> Model Class Initialized
DEBUG - 2011-04-17 11:26:30 --> Model Class Initialized
DEBUG - 2011-04-17 11:26:30 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-17 11:26:30 --> Database Driver Class Initialized
DEBUG - 2011-04-17 11:26:31 --> Final output sent to browser
DEBUG - 2011-04-17 11:26:31 --> Total execution time: 1.4174
DEBUG - 2011-04-17 11:26:39 --> Config Class Initialized
DEBUG - 2011-04-17 11:26:39 --> Hooks Class Initialized
DEBUG - 2011-04-17 11:26:39 --> Utf8 Class Initialized
DEBUG - 2011-04-17 11:26:39 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 11:26:39 --> URI Class Initialized
DEBUG - 2011-04-17 11:26:39 --> Router Class Initialized
ERROR - 2011-04-17 11:26:39 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-17 11:26:39 --> Config Class Initialized
DEBUG - 2011-04-17 11:26:39 --> Hooks Class Initialized
DEBUG - 2011-04-17 11:26:39 --> Utf8 Class Initialized
DEBUG - 2011-04-17 11:26:39 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 11:26:39 --> URI Class Initialized
DEBUG - 2011-04-17 11:26:39 --> Router Class Initialized
ERROR - 2011-04-17 11:26:39 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-17 11:26:57 --> Config Class Initialized
DEBUG - 2011-04-17 11:26:57 --> Hooks Class Initialized
DEBUG - 2011-04-17 11:26:57 --> Utf8 Class Initialized
DEBUG - 2011-04-17 11:26:57 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 11:26:57 --> URI Class Initialized
DEBUG - 2011-04-17 11:26:57 --> Router Class Initialized
DEBUG - 2011-04-17 11:26:57 --> Output Class Initialized
DEBUG - 2011-04-17 11:26:57 --> Input Class Initialized
DEBUG - 2011-04-17 11:26:57 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-17 11:26:57 --> Language Class Initialized
DEBUG - 2011-04-17 11:26:57 --> Loader Class Initialized
DEBUG - 2011-04-17 11:26:57 --> Controller Class Initialized
ERROR - 2011-04-17 11:26:57 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-17 11:26:57 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-17 11:26:57 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-17 11:26:57 --> Model Class Initialized
DEBUG - 2011-04-17 11:26:57 --> Model Class Initialized
DEBUG - 2011-04-17 11:26:57 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-17 11:26:57 --> Database Driver Class Initialized
DEBUG - 2011-04-17 11:26:57 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-17 11:26:57 --> Helper loaded: url_helper
DEBUG - 2011-04-17 11:26:57 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-17 11:26:57 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-17 11:26:57 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-17 11:26:57 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-17 11:26:57 --> Final output sent to browser
DEBUG - 2011-04-17 11:26:57 --> Total execution time: 0.1081
DEBUG - 2011-04-17 11:27:00 --> Config Class Initialized
DEBUG - 2011-04-17 11:27:00 --> Hooks Class Initialized
DEBUG - 2011-04-17 11:27:00 --> Utf8 Class Initialized
DEBUG - 2011-04-17 11:27:00 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 11:27:00 --> URI Class Initialized
DEBUG - 2011-04-17 11:27:00 --> Router Class Initialized
DEBUG - 2011-04-17 11:27:00 --> Output Class Initialized
DEBUG - 2011-04-17 11:27:00 --> Input Class Initialized
DEBUG - 2011-04-17 11:27:00 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-17 11:27:00 --> Language Class Initialized
DEBUG - 2011-04-17 11:27:00 --> Loader Class Initialized
DEBUG - 2011-04-17 11:27:00 --> Controller Class Initialized
DEBUG - 2011-04-17 11:27:00 --> Model Class Initialized
DEBUG - 2011-04-17 11:27:00 --> Model Class Initialized
DEBUG - 2011-04-17 11:27:00 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-17 11:27:00 --> Database Driver Class Initialized
DEBUG - 2011-04-17 11:27:01 --> Final output sent to browser
DEBUG - 2011-04-17 11:27:01 --> Total execution time: 0.6387
DEBUG - 2011-04-17 11:27:08 --> Config Class Initialized
DEBUG - 2011-04-17 11:27:08 --> Hooks Class Initialized
DEBUG - 2011-04-17 11:27:08 --> Utf8 Class Initialized
DEBUG - 2011-04-17 11:27:08 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 11:27:08 --> URI Class Initialized
DEBUG - 2011-04-17 11:27:08 --> Router Class Initialized
ERROR - 2011-04-17 11:27:08 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-17 11:27:10 --> Config Class Initialized
DEBUG - 2011-04-17 11:27:10 --> Hooks Class Initialized
DEBUG - 2011-04-17 11:27:10 --> Utf8 Class Initialized
DEBUG - 2011-04-17 11:27:10 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 11:27:10 --> URI Class Initialized
DEBUG - 2011-04-17 11:27:10 --> Router Class Initialized
ERROR - 2011-04-17 11:27:10 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-17 11:27:14 --> Config Class Initialized
DEBUG - 2011-04-17 11:27:14 --> Hooks Class Initialized
DEBUG - 2011-04-17 11:27:14 --> Utf8 Class Initialized
DEBUG - 2011-04-17 11:27:14 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 11:27:14 --> URI Class Initialized
DEBUG - 2011-04-17 11:27:14 --> Router Class Initialized
DEBUG - 2011-04-17 11:27:14 --> Output Class Initialized
DEBUG - 2011-04-17 11:27:14 --> Input Class Initialized
DEBUG - 2011-04-17 11:27:14 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-17 11:27:14 --> Language Class Initialized
DEBUG - 2011-04-17 11:27:14 --> Loader Class Initialized
DEBUG - 2011-04-17 11:27:14 --> Controller Class Initialized
ERROR - 2011-04-17 11:27:14 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-17 11:27:14 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-17 11:27:14 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-17 11:27:14 --> Model Class Initialized
DEBUG - 2011-04-17 11:27:14 --> Model Class Initialized
DEBUG - 2011-04-17 11:27:14 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-17 11:27:14 --> Database Driver Class Initialized
DEBUG - 2011-04-17 11:27:14 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-17 11:27:14 --> Helper loaded: url_helper
DEBUG - 2011-04-17 11:27:14 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-17 11:27:14 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-17 11:27:14 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-17 11:27:14 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-17 11:27:14 --> Final output sent to browser
DEBUG - 2011-04-17 11:27:14 --> Total execution time: 0.0340
DEBUG - 2011-04-17 11:27:16 --> Config Class Initialized
DEBUG - 2011-04-17 11:27:16 --> Hooks Class Initialized
DEBUG - 2011-04-17 11:27:16 --> Utf8 Class Initialized
DEBUG - 2011-04-17 11:27:16 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 11:27:16 --> URI Class Initialized
DEBUG - 2011-04-17 11:27:16 --> Router Class Initialized
DEBUG - 2011-04-17 11:27:16 --> Output Class Initialized
DEBUG - 2011-04-17 11:27:16 --> Input Class Initialized
DEBUG - 2011-04-17 11:27:16 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-17 11:27:16 --> Language Class Initialized
DEBUG - 2011-04-17 11:27:16 --> Loader Class Initialized
DEBUG - 2011-04-17 11:27:16 --> Controller Class Initialized
DEBUG - 2011-04-17 11:27:16 --> Model Class Initialized
DEBUG - 2011-04-17 11:27:16 --> Model Class Initialized
DEBUG - 2011-04-17 11:27:16 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-17 11:27:16 --> Database Driver Class Initialized
DEBUG - 2011-04-17 11:27:17 --> Final output sent to browser
DEBUG - 2011-04-17 11:27:17 --> Total execution time: 0.5157
DEBUG - 2011-04-17 11:27:25 --> Config Class Initialized
DEBUG - 2011-04-17 11:27:25 --> Hooks Class Initialized
DEBUG - 2011-04-17 11:27:25 --> Utf8 Class Initialized
DEBUG - 2011-04-17 11:27:25 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 11:27:25 --> URI Class Initialized
DEBUG - 2011-04-17 11:27:25 --> Router Class Initialized
ERROR - 2011-04-17 11:27:25 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-17 11:27:26 --> Config Class Initialized
DEBUG - 2011-04-17 11:27:26 --> Hooks Class Initialized
DEBUG - 2011-04-17 11:27:26 --> Utf8 Class Initialized
DEBUG - 2011-04-17 11:27:26 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 11:27:26 --> URI Class Initialized
DEBUG - 2011-04-17 11:27:26 --> Router Class Initialized
ERROR - 2011-04-17 11:27:26 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-17 11:27:46 --> Config Class Initialized
DEBUG - 2011-04-17 11:27:46 --> Hooks Class Initialized
DEBUG - 2011-04-17 11:27:46 --> Utf8 Class Initialized
DEBUG - 2011-04-17 11:27:46 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 11:27:46 --> URI Class Initialized
DEBUG - 2011-04-17 11:27:46 --> Router Class Initialized
DEBUG - 2011-04-17 11:27:46 --> Output Class Initialized
DEBUG - 2011-04-17 11:27:46 --> Input Class Initialized
DEBUG - 2011-04-17 11:27:46 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-17 11:27:46 --> Language Class Initialized
DEBUG - 2011-04-17 11:27:46 --> Loader Class Initialized
DEBUG - 2011-04-17 11:27:46 --> Controller Class Initialized
ERROR - 2011-04-17 11:27:46 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-17 11:27:46 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-17 11:27:46 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-17 11:27:46 --> Model Class Initialized
DEBUG - 2011-04-17 11:27:46 --> Model Class Initialized
DEBUG - 2011-04-17 11:27:46 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-17 11:27:46 --> Database Driver Class Initialized
DEBUG - 2011-04-17 11:27:46 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-17 11:27:46 --> Helper loaded: url_helper
DEBUG - 2011-04-17 11:27:46 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-17 11:27:46 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-17 11:27:46 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-17 11:27:46 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-17 11:27:46 --> Final output sent to browser
DEBUG - 2011-04-17 11:27:46 --> Total execution time: 0.0282
DEBUG - 2011-04-17 11:27:48 --> Config Class Initialized
DEBUG - 2011-04-17 11:27:48 --> Hooks Class Initialized
DEBUG - 2011-04-17 11:27:48 --> Utf8 Class Initialized
DEBUG - 2011-04-17 11:27:48 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 11:27:48 --> URI Class Initialized
DEBUG - 2011-04-17 11:27:48 --> Router Class Initialized
DEBUG - 2011-04-17 11:27:48 --> Output Class Initialized
DEBUG - 2011-04-17 11:27:48 --> Input Class Initialized
DEBUG - 2011-04-17 11:27:48 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-17 11:27:48 --> Language Class Initialized
DEBUG - 2011-04-17 11:27:48 --> Loader Class Initialized
DEBUG - 2011-04-17 11:27:48 --> Controller Class Initialized
DEBUG - 2011-04-17 11:27:48 --> Model Class Initialized
DEBUG - 2011-04-17 11:27:48 --> Model Class Initialized
DEBUG - 2011-04-17 11:27:48 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-17 11:27:48 --> Database Driver Class Initialized
DEBUG - 2011-04-17 11:27:50 --> Final output sent to browser
DEBUG - 2011-04-17 11:27:50 --> Total execution time: 1.9486
DEBUG - 2011-04-17 11:27:58 --> Config Class Initialized
DEBUG - 2011-04-17 11:27:58 --> Hooks Class Initialized
DEBUG - 2011-04-17 11:27:58 --> Utf8 Class Initialized
DEBUG - 2011-04-17 11:27:58 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 11:27:58 --> URI Class Initialized
DEBUG - 2011-04-17 11:27:58 --> Router Class Initialized
ERROR - 2011-04-17 11:27:58 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-17 11:27:58 --> Config Class Initialized
DEBUG - 2011-04-17 11:27:58 --> Hooks Class Initialized
DEBUG - 2011-04-17 11:27:58 --> Utf8 Class Initialized
DEBUG - 2011-04-17 11:27:58 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 11:27:58 --> URI Class Initialized
DEBUG - 2011-04-17 11:27:58 --> Router Class Initialized
ERROR - 2011-04-17 11:27:58 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-17 11:28:09 --> Config Class Initialized
DEBUG - 2011-04-17 11:28:09 --> Hooks Class Initialized
DEBUG - 2011-04-17 11:28:09 --> Utf8 Class Initialized
DEBUG - 2011-04-17 11:28:09 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 11:28:09 --> URI Class Initialized
DEBUG - 2011-04-17 11:28:09 --> Router Class Initialized
DEBUG - 2011-04-17 11:28:09 --> Output Class Initialized
DEBUG - 2011-04-17 11:28:09 --> Input Class Initialized
DEBUG - 2011-04-17 11:28:09 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-17 11:28:09 --> Language Class Initialized
DEBUG - 2011-04-17 11:28:09 --> Loader Class Initialized
DEBUG - 2011-04-17 11:28:09 --> Controller Class Initialized
ERROR - 2011-04-17 11:28:09 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-17 11:28:09 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-17 11:28:09 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-17 11:28:09 --> Model Class Initialized
DEBUG - 2011-04-17 11:28:09 --> Model Class Initialized
DEBUG - 2011-04-17 11:28:09 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-17 11:28:09 --> Database Driver Class Initialized
DEBUG - 2011-04-17 11:28:09 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-17 11:28:09 --> Helper loaded: url_helper
DEBUG - 2011-04-17 11:28:09 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-17 11:28:09 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-17 11:28:09 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-17 11:28:09 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-17 11:28:09 --> Final output sent to browser
DEBUG - 2011-04-17 11:28:09 --> Total execution time: 0.0306
DEBUG - 2011-04-17 11:28:13 --> Config Class Initialized
DEBUG - 2011-04-17 11:28:13 --> Hooks Class Initialized
DEBUG - 2011-04-17 11:28:13 --> Utf8 Class Initialized
DEBUG - 2011-04-17 11:28:13 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 11:28:13 --> URI Class Initialized
DEBUG - 2011-04-17 11:28:13 --> Router Class Initialized
DEBUG - 2011-04-17 11:28:13 --> Output Class Initialized
DEBUG - 2011-04-17 11:28:13 --> Input Class Initialized
DEBUG - 2011-04-17 11:28:13 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-17 11:28:13 --> Language Class Initialized
DEBUG - 2011-04-17 11:28:13 --> Loader Class Initialized
DEBUG - 2011-04-17 11:28:13 --> Controller Class Initialized
DEBUG - 2011-04-17 11:28:13 --> Model Class Initialized
DEBUG - 2011-04-17 11:28:13 --> Model Class Initialized
DEBUG - 2011-04-17 11:28:13 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-17 11:28:13 --> Database Driver Class Initialized
DEBUG - 2011-04-17 11:28:15 --> Final output sent to browser
DEBUG - 2011-04-17 11:28:15 --> Total execution time: 1.5513
DEBUG - 2011-04-17 11:28:16 --> Config Class Initialized
DEBUG - 2011-04-17 11:28:16 --> Hooks Class Initialized
DEBUG - 2011-04-17 11:28:16 --> Utf8 Class Initialized
DEBUG - 2011-04-17 11:28:16 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 11:28:16 --> URI Class Initialized
DEBUG - 2011-04-17 11:28:16 --> Router Class Initialized
DEBUG - 2011-04-17 11:28:16 --> Output Class Initialized
DEBUG - 2011-04-17 11:28:16 --> Input Class Initialized
DEBUG - 2011-04-17 11:28:16 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-17 11:28:16 --> Language Class Initialized
DEBUG - 2011-04-17 11:28:16 --> Loader Class Initialized
DEBUG - 2011-04-17 11:28:16 --> Controller Class Initialized
DEBUG - 2011-04-17 11:28:16 --> Model Class Initialized
DEBUG - 2011-04-17 11:28:16 --> Model Class Initialized
DEBUG - 2011-04-17 11:28:16 --> Model Class Initialized
DEBUG - 2011-04-17 11:28:16 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-17 11:28:16 --> Database Driver Class Initialized
DEBUG - 2011-04-17 11:28:16 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-17 11:28:16 --> Helper loaded: url_helper
DEBUG - 2011-04-17 11:28:16 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-17 11:28:16 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-17 11:28:16 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-17 11:28:16 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-17 11:28:16 --> Final output sent to browser
DEBUG - 2011-04-17 11:28:16 --> Total execution time: 0.0869
DEBUG - 2011-04-17 11:28:17 --> Config Class Initialized
DEBUG - 2011-04-17 11:28:17 --> Hooks Class Initialized
DEBUG - 2011-04-17 11:28:17 --> Utf8 Class Initialized
DEBUG - 2011-04-17 11:28:17 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 11:28:17 --> URI Class Initialized
DEBUG - 2011-04-17 11:28:17 --> Router Class Initialized
DEBUG - 2011-04-17 11:28:17 --> Output Class Initialized
DEBUG - 2011-04-17 11:28:17 --> Input Class Initialized
DEBUG - 2011-04-17 11:28:17 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-17 11:28:17 --> Language Class Initialized
DEBUG - 2011-04-17 11:28:17 --> Loader Class Initialized
DEBUG - 2011-04-17 11:28:17 --> Controller Class Initialized
ERROR - 2011-04-17 11:28:17 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-17 11:28:17 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-17 11:28:17 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-17 11:28:17 --> Model Class Initialized
DEBUG - 2011-04-17 11:28:17 --> Model Class Initialized
DEBUG - 2011-04-17 11:28:17 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-17 11:28:18 --> Database Driver Class Initialized
DEBUG - 2011-04-17 11:28:18 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-17 11:28:18 --> Helper loaded: url_helper
DEBUG - 2011-04-17 11:28:18 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-17 11:28:18 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-17 11:28:18 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-17 11:28:18 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-17 11:28:18 --> Final output sent to browser
DEBUG - 2011-04-17 11:28:18 --> Total execution time: 0.0640
DEBUG - 2011-04-17 11:28:19 --> Config Class Initialized
DEBUG - 2011-04-17 11:28:19 --> Hooks Class Initialized
DEBUG - 2011-04-17 11:28:19 --> Utf8 Class Initialized
DEBUG - 2011-04-17 11:28:19 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 11:28:19 --> URI Class Initialized
DEBUG - 2011-04-17 11:28:19 --> Router Class Initialized
DEBUG - 2011-04-17 11:28:19 --> Output Class Initialized
DEBUG - 2011-04-17 11:28:19 --> Input Class Initialized
DEBUG - 2011-04-17 11:28:19 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-17 11:28:19 --> Language Class Initialized
DEBUG - 2011-04-17 11:28:19 --> Loader Class Initialized
DEBUG - 2011-04-17 11:28:19 --> Controller Class Initialized
DEBUG - 2011-04-17 11:28:19 --> Model Class Initialized
DEBUG - 2011-04-17 11:28:19 --> Model Class Initialized
DEBUG - 2011-04-17 11:28:19 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-17 11:28:19 --> Database Driver Class Initialized
DEBUG - 2011-04-17 11:28:20 --> Final output sent to browser
DEBUG - 2011-04-17 11:28:20 --> Total execution time: 0.5236
DEBUG - 2011-04-17 11:28:20 --> Config Class Initialized
DEBUG - 2011-04-17 11:28:20 --> Hooks Class Initialized
DEBUG - 2011-04-17 11:28:20 --> Utf8 Class Initialized
DEBUG - 2011-04-17 11:28:20 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 11:28:20 --> URI Class Initialized
DEBUG - 2011-04-17 11:28:20 --> Router Class Initialized
ERROR - 2011-04-17 11:28:20 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-17 11:28:21 --> Config Class Initialized
DEBUG - 2011-04-17 11:28:21 --> Hooks Class Initialized
DEBUG - 2011-04-17 11:28:21 --> Utf8 Class Initialized
DEBUG - 2011-04-17 11:28:21 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 11:28:21 --> URI Class Initialized
DEBUG - 2011-04-17 11:28:21 --> Router Class Initialized
ERROR - 2011-04-17 11:28:21 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-17 11:28:28 --> Config Class Initialized
DEBUG - 2011-04-17 11:28:28 --> Hooks Class Initialized
DEBUG - 2011-04-17 11:28:28 --> Utf8 Class Initialized
DEBUG - 2011-04-17 11:28:28 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 11:28:28 --> URI Class Initialized
DEBUG - 2011-04-17 11:28:28 --> Router Class Initialized
ERROR - 2011-04-17 11:28:28 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-17 11:28:29 --> Config Class Initialized
DEBUG - 2011-04-17 11:28:29 --> Hooks Class Initialized
DEBUG - 2011-04-17 11:28:29 --> Utf8 Class Initialized
DEBUG - 2011-04-17 11:28:29 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 11:28:29 --> URI Class Initialized
DEBUG - 2011-04-17 11:28:29 --> Router Class Initialized
ERROR - 2011-04-17 11:28:29 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-17 11:30:10 --> Config Class Initialized
DEBUG - 2011-04-17 11:30:10 --> Hooks Class Initialized
DEBUG - 2011-04-17 11:30:10 --> Utf8 Class Initialized
DEBUG - 2011-04-17 11:30:10 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 11:30:10 --> URI Class Initialized
DEBUG - 2011-04-17 11:30:10 --> Router Class Initialized
DEBUG - 2011-04-17 11:30:10 --> Output Class Initialized
DEBUG - 2011-04-17 11:30:10 --> Input Class Initialized
DEBUG - 2011-04-17 11:30:10 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-17 11:30:10 --> Language Class Initialized
DEBUG - 2011-04-17 11:30:10 --> Loader Class Initialized
DEBUG - 2011-04-17 11:30:10 --> Controller Class Initialized
ERROR - 2011-04-17 11:30:10 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-17 11:30:10 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-17 11:30:10 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-17 11:30:10 --> Model Class Initialized
DEBUG - 2011-04-17 11:30:10 --> Model Class Initialized
DEBUG - 2011-04-17 11:30:10 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-17 11:30:10 --> Database Driver Class Initialized
DEBUG - 2011-04-17 11:30:10 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-17 11:30:10 --> Helper loaded: url_helper
DEBUG - 2011-04-17 11:30:10 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-17 11:30:10 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-17 11:30:10 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-17 11:30:10 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-17 11:30:10 --> Final output sent to browser
DEBUG - 2011-04-17 11:30:10 --> Total execution time: 0.1372
DEBUG - 2011-04-17 11:30:11 --> Config Class Initialized
DEBUG - 2011-04-17 11:30:11 --> Hooks Class Initialized
DEBUG - 2011-04-17 11:30:11 --> Utf8 Class Initialized
DEBUG - 2011-04-17 11:30:11 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 11:30:11 --> URI Class Initialized
DEBUG - 2011-04-17 11:30:11 --> Router Class Initialized
DEBUG - 2011-04-17 11:30:11 --> Output Class Initialized
DEBUG - 2011-04-17 11:30:11 --> Input Class Initialized
DEBUG - 2011-04-17 11:30:11 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-17 11:30:11 --> Language Class Initialized
DEBUG - 2011-04-17 11:30:11 --> Loader Class Initialized
DEBUG - 2011-04-17 11:30:11 --> Controller Class Initialized
DEBUG - 2011-04-17 11:30:11 --> Model Class Initialized
DEBUG - 2011-04-17 11:30:11 --> Model Class Initialized
DEBUG - 2011-04-17 11:30:11 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-17 11:30:11 --> Database Driver Class Initialized
DEBUG - 2011-04-17 11:30:11 --> Final output sent to browser
DEBUG - 2011-04-17 11:30:11 --> Total execution time: 0.6269
DEBUG - 2011-04-17 11:30:12 --> Config Class Initialized
DEBUG - 2011-04-17 11:30:12 --> Hooks Class Initialized
DEBUG - 2011-04-17 11:30:12 --> Utf8 Class Initialized
DEBUG - 2011-04-17 11:30:12 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 11:30:12 --> URI Class Initialized
DEBUG - 2011-04-17 11:30:12 --> Router Class Initialized
ERROR - 2011-04-17 11:30:12 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-17 11:30:29 --> Config Class Initialized
DEBUG - 2011-04-17 11:30:29 --> Hooks Class Initialized
DEBUG - 2011-04-17 11:30:29 --> Utf8 Class Initialized
DEBUG - 2011-04-17 11:30:29 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 11:30:29 --> URI Class Initialized
DEBUG - 2011-04-17 11:30:29 --> Router Class Initialized
DEBUG - 2011-04-17 11:30:29 --> Output Class Initialized
DEBUG - 2011-04-17 11:30:29 --> Input Class Initialized
DEBUG - 2011-04-17 11:30:29 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-17 11:30:29 --> Language Class Initialized
DEBUG - 2011-04-17 11:30:29 --> Loader Class Initialized
DEBUG - 2011-04-17 11:30:29 --> Controller Class Initialized
ERROR - 2011-04-17 11:30:29 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-17 11:30:29 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-17 11:30:29 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-17 11:30:29 --> Model Class Initialized
DEBUG - 2011-04-17 11:30:29 --> Model Class Initialized
DEBUG - 2011-04-17 11:30:29 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-17 11:30:29 --> Database Driver Class Initialized
DEBUG - 2011-04-17 11:30:29 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-17 11:30:29 --> Helper loaded: url_helper
DEBUG - 2011-04-17 11:30:29 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-17 11:30:29 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-17 11:30:29 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-17 11:30:29 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-17 11:30:29 --> Final output sent to browser
DEBUG - 2011-04-17 11:30:29 --> Total execution time: 0.0636
DEBUG - 2011-04-17 11:30:29 --> Config Class Initialized
DEBUG - 2011-04-17 11:30:29 --> Hooks Class Initialized
DEBUG - 2011-04-17 11:30:29 --> Utf8 Class Initialized
DEBUG - 2011-04-17 11:30:29 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 11:30:29 --> URI Class Initialized
DEBUG - 2011-04-17 11:30:29 --> Router Class Initialized
DEBUG - 2011-04-17 11:30:29 --> Output Class Initialized
DEBUG - 2011-04-17 11:30:29 --> Input Class Initialized
DEBUG - 2011-04-17 11:30:29 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-17 11:30:29 --> Language Class Initialized
DEBUG - 2011-04-17 11:30:29 --> Loader Class Initialized
DEBUG - 2011-04-17 11:30:29 --> Controller Class Initialized
DEBUG - 2011-04-17 11:30:29 --> Model Class Initialized
DEBUG - 2011-04-17 11:30:29 --> Model Class Initialized
DEBUG - 2011-04-17 11:30:29 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-17 11:30:29 --> Database Driver Class Initialized
DEBUG - 2011-04-17 11:30:30 --> Final output sent to browser
DEBUG - 2011-04-17 11:30:30 --> Total execution time: 0.6026
DEBUG - 2011-04-17 11:30:31 --> Config Class Initialized
DEBUG - 2011-04-17 11:30:31 --> Hooks Class Initialized
DEBUG - 2011-04-17 11:30:31 --> Utf8 Class Initialized
DEBUG - 2011-04-17 11:30:31 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 11:30:31 --> URI Class Initialized
DEBUG - 2011-04-17 11:30:31 --> Router Class Initialized
ERROR - 2011-04-17 11:30:31 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-17 11:30:35 --> Config Class Initialized
DEBUG - 2011-04-17 11:30:35 --> Hooks Class Initialized
DEBUG - 2011-04-17 11:30:35 --> Utf8 Class Initialized
DEBUG - 2011-04-17 11:30:35 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 11:30:35 --> URI Class Initialized
DEBUG - 2011-04-17 11:30:35 --> Router Class Initialized
DEBUG - 2011-04-17 11:30:35 --> Output Class Initialized
DEBUG - 2011-04-17 11:30:35 --> Input Class Initialized
DEBUG - 2011-04-17 11:30:35 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-17 11:30:35 --> Language Class Initialized
DEBUG - 2011-04-17 11:30:35 --> Loader Class Initialized
DEBUG - 2011-04-17 11:30:35 --> Controller Class Initialized
ERROR - 2011-04-17 11:30:35 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-17 11:30:35 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-17 11:30:35 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-17 11:30:35 --> Model Class Initialized
DEBUG - 2011-04-17 11:30:35 --> Model Class Initialized
DEBUG - 2011-04-17 11:30:35 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-17 11:30:35 --> Database Driver Class Initialized
DEBUG - 2011-04-17 11:30:36 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-17 11:30:36 --> Helper loaded: url_helper
DEBUG - 2011-04-17 11:30:36 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-17 11:30:36 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-17 11:30:36 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-17 11:30:36 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-17 11:30:36 --> Final output sent to browser
DEBUG - 2011-04-17 11:30:36 --> Total execution time: 0.1270
DEBUG - 2011-04-17 11:30:36 --> Config Class Initialized
DEBUG - 2011-04-17 11:30:36 --> Hooks Class Initialized
DEBUG - 2011-04-17 11:30:36 --> Utf8 Class Initialized
DEBUG - 2011-04-17 11:30:36 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 11:30:36 --> URI Class Initialized
DEBUG - 2011-04-17 11:30:36 --> Router Class Initialized
DEBUG - 2011-04-17 11:30:36 --> Output Class Initialized
DEBUG - 2011-04-17 11:30:36 --> Input Class Initialized
DEBUG - 2011-04-17 11:30:36 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-17 11:30:36 --> Language Class Initialized
DEBUG - 2011-04-17 11:30:36 --> Loader Class Initialized
DEBUG - 2011-04-17 11:30:36 --> Controller Class Initialized
DEBUG - 2011-04-17 11:30:36 --> Model Class Initialized
DEBUG - 2011-04-17 11:30:36 --> Model Class Initialized
DEBUG - 2011-04-17 11:30:36 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-17 11:30:36 --> Database Driver Class Initialized
DEBUG - 2011-04-17 11:30:37 --> Final output sent to browser
DEBUG - 2011-04-17 11:30:37 --> Total execution time: 0.6403
DEBUG - 2011-04-17 11:30:38 --> Config Class Initialized
DEBUG - 2011-04-17 11:30:38 --> Hooks Class Initialized
DEBUG - 2011-04-17 11:30:38 --> Utf8 Class Initialized
DEBUG - 2011-04-17 11:30:38 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 11:30:38 --> URI Class Initialized
DEBUG - 2011-04-17 11:30:38 --> Router Class Initialized
ERROR - 2011-04-17 11:30:38 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-17 11:30:41 --> Config Class Initialized
DEBUG - 2011-04-17 11:30:41 --> Hooks Class Initialized
DEBUG - 2011-04-17 11:30:41 --> Utf8 Class Initialized
DEBUG - 2011-04-17 11:30:41 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 11:30:41 --> URI Class Initialized
DEBUG - 2011-04-17 11:30:41 --> Router Class Initialized
DEBUG - 2011-04-17 11:30:41 --> Output Class Initialized
DEBUG - 2011-04-17 11:30:41 --> Input Class Initialized
DEBUG - 2011-04-17 11:30:41 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-17 11:30:41 --> Language Class Initialized
DEBUG - 2011-04-17 11:30:41 --> Loader Class Initialized
DEBUG - 2011-04-17 11:30:41 --> Controller Class Initialized
ERROR - 2011-04-17 11:30:41 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-17 11:30:41 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-17 11:30:41 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-17 11:30:41 --> Model Class Initialized
DEBUG - 2011-04-17 11:30:41 --> Model Class Initialized
DEBUG - 2011-04-17 11:30:41 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-17 11:30:41 --> Database Driver Class Initialized
DEBUG - 2011-04-17 11:30:41 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-17 11:30:41 --> Helper loaded: url_helper
DEBUG - 2011-04-17 11:30:41 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-17 11:30:41 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-17 11:30:41 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-17 11:30:41 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-17 11:30:41 --> Final output sent to browser
DEBUG - 2011-04-17 11:30:41 --> Total execution time: 0.2086
DEBUG - 2011-04-17 11:30:42 --> Config Class Initialized
DEBUG - 2011-04-17 11:30:42 --> Hooks Class Initialized
DEBUG - 2011-04-17 11:30:42 --> Utf8 Class Initialized
DEBUG - 2011-04-17 11:30:42 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 11:30:42 --> URI Class Initialized
DEBUG - 2011-04-17 11:30:42 --> Router Class Initialized
DEBUG - 2011-04-17 11:30:42 --> Output Class Initialized
DEBUG - 2011-04-17 11:30:42 --> Input Class Initialized
DEBUG - 2011-04-17 11:30:42 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-17 11:30:42 --> Language Class Initialized
DEBUG - 2011-04-17 11:30:42 --> Loader Class Initialized
DEBUG - 2011-04-17 11:30:42 --> Controller Class Initialized
DEBUG - 2011-04-17 11:30:42 --> Model Class Initialized
DEBUG - 2011-04-17 11:30:42 --> Model Class Initialized
DEBUG - 2011-04-17 11:30:42 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-17 11:30:42 --> Database Driver Class Initialized
DEBUG - 2011-04-17 11:30:43 --> Final output sent to browser
DEBUG - 2011-04-17 11:30:43 --> Total execution time: 0.5072
DEBUG - 2011-04-17 11:30:45 --> Config Class Initialized
DEBUG - 2011-04-17 11:30:45 --> Hooks Class Initialized
DEBUG - 2011-04-17 11:30:45 --> Utf8 Class Initialized
DEBUG - 2011-04-17 11:30:45 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 11:30:45 --> URI Class Initialized
DEBUG - 2011-04-17 11:30:45 --> Router Class Initialized
ERROR - 2011-04-17 11:30:45 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-17 11:30:50 --> Config Class Initialized
DEBUG - 2011-04-17 11:30:50 --> Hooks Class Initialized
DEBUG - 2011-04-17 11:30:50 --> Utf8 Class Initialized
DEBUG - 2011-04-17 11:30:50 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 11:30:50 --> URI Class Initialized
DEBUG - 2011-04-17 11:30:50 --> Router Class Initialized
DEBUG - 2011-04-17 11:30:50 --> Output Class Initialized
DEBUG - 2011-04-17 11:30:50 --> Input Class Initialized
DEBUG - 2011-04-17 11:30:50 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-17 11:30:50 --> Language Class Initialized
DEBUG - 2011-04-17 11:30:50 --> Loader Class Initialized
DEBUG - 2011-04-17 11:30:50 --> Controller Class Initialized
ERROR - 2011-04-17 11:30:50 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-17 11:30:50 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-17 11:30:50 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-17 11:30:50 --> Model Class Initialized
DEBUG - 2011-04-17 11:30:50 --> Model Class Initialized
DEBUG - 2011-04-17 11:30:50 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-17 11:30:50 --> Database Driver Class Initialized
DEBUG - 2011-04-17 11:30:50 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-17 11:30:50 --> Helper loaded: url_helper
DEBUG - 2011-04-17 11:30:50 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-17 11:30:50 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-17 11:30:50 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-17 11:30:50 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-17 11:30:50 --> Final output sent to browser
DEBUG - 2011-04-17 11:30:50 --> Total execution time: 0.0320
DEBUG - 2011-04-17 11:30:51 --> Config Class Initialized
DEBUG - 2011-04-17 11:30:51 --> Hooks Class Initialized
DEBUG - 2011-04-17 11:30:51 --> Utf8 Class Initialized
DEBUG - 2011-04-17 11:30:51 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 11:30:51 --> URI Class Initialized
DEBUG - 2011-04-17 11:30:51 --> Router Class Initialized
DEBUG - 2011-04-17 11:30:51 --> Output Class Initialized
DEBUG - 2011-04-17 11:30:51 --> Input Class Initialized
DEBUG - 2011-04-17 11:30:51 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-17 11:30:51 --> Language Class Initialized
DEBUG - 2011-04-17 11:30:51 --> Loader Class Initialized
DEBUG - 2011-04-17 11:30:51 --> Controller Class Initialized
DEBUG - 2011-04-17 11:30:51 --> Model Class Initialized
DEBUG - 2011-04-17 11:30:51 --> Model Class Initialized
DEBUG - 2011-04-17 11:30:51 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-17 11:30:51 --> Database Driver Class Initialized
DEBUG - 2011-04-17 11:30:51 --> Final output sent to browser
DEBUG - 2011-04-17 11:30:51 --> Total execution time: 0.5536
DEBUG - 2011-04-17 11:30:52 --> Config Class Initialized
DEBUG - 2011-04-17 11:30:52 --> Hooks Class Initialized
DEBUG - 2011-04-17 11:30:52 --> Utf8 Class Initialized
DEBUG - 2011-04-17 11:30:52 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 11:30:52 --> URI Class Initialized
DEBUG - 2011-04-17 11:30:52 --> Router Class Initialized
ERROR - 2011-04-17 11:30:52 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-17 11:30:55 --> Config Class Initialized
DEBUG - 2011-04-17 11:30:55 --> Hooks Class Initialized
DEBUG - 2011-04-17 11:30:55 --> Utf8 Class Initialized
DEBUG - 2011-04-17 11:30:55 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 11:30:55 --> URI Class Initialized
DEBUG - 2011-04-17 11:30:55 --> Router Class Initialized
DEBUG - 2011-04-17 11:30:55 --> Output Class Initialized
DEBUG - 2011-04-17 11:30:55 --> Input Class Initialized
DEBUG - 2011-04-17 11:30:55 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-17 11:30:55 --> Language Class Initialized
DEBUG - 2011-04-17 11:30:55 --> Loader Class Initialized
DEBUG - 2011-04-17 11:30:55 --> Controller Class Initialized
ERROR - 2011-04-17 11:30:55 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-17 11:30:55 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-17 11:30:55 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-17 11:30:55 --> Model Class Initialized
DEBUG - 2011-04-17 11:30:55 --> Model Class Initialized
DEBUG - 2011-04-17 11:30:55 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-17 11:30:55 --> Database Driver Class Initialized
DEBUG - 2011-04-17 11:30:55 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-17 11:30:55 --> Helper loaded: url_helper
DEBUG - 2011-04-17 11:30:55 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-17 11:30:55 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-17 11:30:55 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-17 11:30:55 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-17 11:30:55 --> Final output sent to browser
DEBUG - 2011-04-17 11:30:55 --> Total execution time: 0.0636
DEBUG - 2011-04-17 11:30:55 --> Config Class Initialized
DEBUG - 2011-04-17 11:30:55 --> Hooks Class Initialized
DEBUG - 2011-04-17 11:30:55 --> Utf8 Class Initialized
DEBUG - 2011-04-17 11:30:55 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 11:30:55 --> URI Class Initialized
DEBUG - 2011-04-17 11:30:55 --> Router Class Initialized
DEBUG - 2011-04-17 11:30:55 --> Output Class Initialized
DEBUG - 2011-04-17 11:30:55 --> Input Class Initialized
DEBUG - 2011-04-17 11:30:55 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-17 11:30:55 --> Language Class Initialized
DEBUG - 2011-04-17 11:30:55 --> Loader Class Initialized
DEBUG - 2011-04-17 11:30:55 --> Controller Class Initialized
DEBUG - 2011-04-17 11:30:55 --> Model Class Initialized
DEBUG - 2011-04-17 11:30:55 --> Model Class Initialized
DEBUG - 2011-04-17 11:30:55 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-17 11:30:55 --> Database Driver Class Initialized
DEBUG - 2011-04-17 11:30:56 --> Final output sent to browser
DEBUG - 2011-04-17 11:30:56 --> Total execution time: 0.6014
DEBUG - 2011-04-17 11:30:57 --> Config Class Initialized
DEBUG - 2011-04-17 11:30:57 --> Hooks Class Initialized
DEBUG - 2011-04-17 11:30:57 --> Utf8 Class Initialized
DEBUG - 2011-04-17 11:30:57 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 11:30:57 --> URI Class Initialized
DEBUG - 2011-04-17 11:30:57 --> Router Class Initialized
ERROR - 2011-04-17 11:30:57 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-17 11:31:01 --> Config Class Initialized
DEBUG - 2011-04-17 11:31:01 --> Hooks Class Initialized
DEBUG - 2011-04-17 11:31:01 --> Utf8 Class Initialized
DEBUG - 2011-04-17 11:31:01 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 11:31:01 --> URI Class Initialized
DEBUG - 2011-04-17 11:31:01 --> Router Class Initialized
DEBUG - 2011-04-17 11:31:01 --> Output Class Initialized
DEBUG - 2011-04-17 11:31:01 --> Input Class Initialized
DEBUG - 2011-04-17 11:31:01 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-17 11:31:01 --> Language Class Initialized
DEBUG - 2011-04-17 11:31:01 --> Loader Class Initialized
DEBUG - 2011-04-17 11:31:01 --> Controller Class Initialized
ERROR - 2011-04-17 11:31:01 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-17 11:31:01 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-17 11:31:01 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-17 11:31:01 --> Model Class Initialized
DEBUG - 2011-04-17 11:31:01 --> Model Class Initialized
DEBUG - 2011-04-17 11:31:01 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-17 11:31:01 --> Database Driver Class Initialized
DEBUG - 2011-04-17 11:31:01 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-17 11:31:01 --> Helper loaded: url_helper
DEBUG - 2011-04-17 11:31:01 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-17 11:31:01 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-17 11:31:01 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-17 11:31:01 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-17 11:31:01 --> Final output sent to browser
DEBUG - 2011-04-17 11:31:01 --> Total execution time: 0.1730
DEBUG - 2011-04-17 11:31:03 --> Config Class Initialized
DEBUG - 2011-04-17 11:31:03 --> Hooks Class Initialized
DEBUG - 2011-04-17 11:31:03 --> Utf8 Class Initialized
DEBUG - 2011-04-17 11:31:03 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 11:31:03 --> URI Class Initialized
DEBUG - 2011-04-17 11:31:03 --> Router Class Initialized
DEBUG - 2011-04-17 11:31:03 --> Output Class Initialized
DEBUG - 2011-04-17 11:31:03 --> Input Class Initialized
DEBUG - 2011-04-17 11:31:03 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-17 11:31:03 --> Language Class Initialized
DEBUG - 2011-04-17 11:31:03 --> Loader Class Initialized
DEBUG - 2011-04-17 11:31:03 --> Controller Class Initialized
DEBUG - 2011-04-17 11:31:03 --> Model Class Initialized
DEBUG - 2011-04-17 11:31:03 --> Model Class Initialized
DEBUG - 2011-04-17 11:31:03 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-17 11:31:03 --> Database Driver Class Initialized
DEBUG - 2011-04-17 11:31:04 --> Final output sent to browser
DEBUG - 2011-04-17 11:31:04 --> Total execution time: 0.7634
DEBUG - 2011-04-17 11:31:06 --> Config Class Initialized
DEBUG - 2011-04-17 11:31:06 --> Hooks Class Initialized
DEBUG - 2011-04-17 11:31:06 --> Utf8 Class Initialized
DEBUG - 2011-04-17 11:31:06 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 11:31:06 --> URI Class Initialized
DEBUG - 2011-04-17 11:31:06 --> Router Class Initialized
ERROR - 2011-04-17 11:31:06 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-17 11:31:08 --> Config Class Initialized
DEBUG - 2011-04-17 11:31:08 --> Hooks Class Initialized
DEBUG - 2011-04-17 11:31:08 --> Utf8 Class Initialized
DEBUG - 2011-04-17 11:31:08 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 11:31:08 --> URI Class Initialized
DEBUG - 2011-04-17 11:31:08 --> Router Class Initialized
DEBUG - 2011-04-17 11:31:08 --> Output Class Initialized
DEBUG - 2011-04-17 11:31:08 --> Input Class Initialized
DEBUG - 2011-04-17 11:31:08 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-17 11:31:08 --> Language Class Initialized
DEBUG - 2011-04-17 11:31:08 --> Loader Class Initialized
DEBUG - 2011-04-17 11:31:08 --> Controller Class Initialized
ERROR - 2011-04-17 11:31:08 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-17 11:31:08 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-17 11:31:08 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-17 11:31:08 --> Model Class Initialized
DEBUG - 2011-04-17 11:31:08 --> Model Class Initialized
DEBUG - 2011-04-17 11:31:08 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-17 11:31:08 --> Database Driver Class Initialized
DEBUG - 2011-04-17 11:31:08 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-17 11:31:08 --> Helper loaded: url_helper
DEBUG - 2011-04-17 11:31:08 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-17 11:31:08 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-17 11:31:08 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-17 11:31:08 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-17 11:31:08 --> Final output sent to browser
DEBUG - 2011-04-17 11:31:08 --> Total execution time: 0.0893
DEBUG - 2011-04-17 11:31:09 --> Config Class Initialized
DEBUG - 2011-04-17 11:31:09 --> Hooks Class Initialized
DEBUG - 2011-04-17 11:31:09 --> Utf8 Class Initialized
DEBUG - 2011-04-17 11:31:09 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 11:31:09 --> URI Class Initialized
DEBUG - 2011-04-17 11:31:09 --> Router Class Initialized
DEBUG - 2011-04-17 11:31:09 --> Output Class Initialized
DEBUG - 2011-04-17 11:31:09 --> Input Class Initialized
DEBUG - 2011-04-17 11:31:09 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-17 11:31:09 --> Language Class Initialized
DEBUG - 2011-04-17 11:31:09 --> Loader Class Initialized
DEBUG - 2011-04-17 11:31:09 --> Controller Class Initialized
DEBUG - 2011-04-17 11:31:09 --> Model Class Initialized
DEBUG - 2011-04-17 11:31:09 --> Model Class Initialized
DEBUG - 2011-04-17 11:31:09 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-17 11:31:09 --> Database Driver Class Initialized
DEBUG - 2011-04-17 11:31:09 --> Final output sent to browser
DEBUG - 2011-04-17 11:31:09 --> Total execution time: 0.5011
DEBUG - 2011-04-17 11:31:10 --> Config Class Initialized
DEBUG - 2011-04-17 11:31:10 --> Hooks Class Initialized
DEBUG - 2011-04-17 11:31:10 --> Utf8 Class Initialized
DEBUG - 2011-04-17 11:31:10 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 11:31:10 --> URI Class Initialized
DEBUG - 2011-04-17 11:31:10 --> Router Class Initialized
ERROR - 2011-04-17 11:31:10 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-17 11:31:14 --> Config Class Initialized
DEBUG - 2011-04-17 11:31:14 --> Hooks Class Initialized
DEBUG - 2011-04-17 11:31:14 --> Utf8 Class Initialized
DEBUG - 2011-04-17 11:31:14 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 11:31:14 --> URI Class Initialized
DEBUG - 2011-04-17 11:31:14 --> Router Class Initialized
DEBUG - 2011-04-17 11:31:14 --> Output Class Initialized
DEBUG - 2011-04-17 11:31:14 --> Input Class Initialized
DEBUG - 2011-04-17 11:31:14 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-17 11:31:14 --> Language Class Initialized
DEBUG - 2011-04-17 11:31:14 --> Loader Class Initialized
DEBUG - 2011-04-17 11:31:14 --> Controller Class Initialized
ERROR - 2011-04-17 11:31:14 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-17 11:31:14 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-17 11:31:14 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-17 11:31:14 --> Model Class Initialized
DEBUG - 2011-04-17 11:31:14 --> Model Class Initialized
DEBUG - 2011-04-17 11:31:14 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-17 11:31:14 --> Database Driver Class Initialized
DEBUG - 2011-04-17 11:31:14 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-17 11:31:14 --> Helper loaded: url_helper
DEBUG - 2011-04-17 11:31:14 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-17 11:31:14 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-17 11:31:14 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-17 11:31:14 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-17 11:31:14 --> Final output sent to browser
DEBUG - 2011-04-17 11:31:14 --> Total execution time: 0.0301
DEBUG - 2011-04-17 11:31:15 --> Config Class Initialized
DEBUG - 2011-04-17 11:31:15 --> Hooks Class Initialized
DEBUG - 2011-04-17 11:31:15 --> Utf8 Class Initialized
DEBUG - 2011-04-17 11:31:15 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 11:31:15 --> URI Class Initialized
DEBUG - 2011-04-17 11:31:15 --> Router Class Initialized
DEBUG - 2011-04-17 11:31:15 --> Output Class Initialized
DEBUG - 2011-04-17 11:31:15 --> Input Class Initialized
DEBUG - 2011-04-17 11:31:15 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-17 11:31:15 --> Language Class Initialized
DEBUG - 2011-04-17 11:31:15 --> Loader Class Initialized
DEBUG - 2011-04-17 11:31:15 --> Controller Class Initialized
DEBUG - 2011-04-17 11:31:15 --> Model Class Initialized
DEBUG - 2011-04-17 11:31:15 --> Model Class Initialized
DEBUG - 2011-04-17 11:31:15 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-17 11:31:15 --> Database Driver Class Initialized
DEBUG - 2011-04-17 11:31:15 --> Final output sent to browser
DEBUG - 2011-04-17 11:31:15 --> Total execution time: 0.6085
DEBUG - 2011-04-17 11:31:16 --> Config Class Initialized
DEBUG - 2011-04-17 11:31:16 --> Hooks Class Initialized
DEBUG - 2011-04-17 11:31:16 --> Utf8 Class Initialized
DEBUG - 2011-04-17 11:31:16 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 11:31:16 --> URI Class Initialized
DEBUG - 2011-04-17 11:31:16 --> Router Class Initialized
ERROR - 2011-04-17 11:31:16 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-17 11:31:19 --> Config Class Initialized
DEBUG - 2011-04-17 11:31:19 --> Hooks Class Initialized
DEBUG - 2011-04-17 11:31:19 --> Utf8 Class Initialized
DEBUG - 2011-04-17 11:31:19 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 11:31:19 --> URI Class Initialized
DEBUG - 2011-04-17 11:31:19 --> Router Class Initialized
DEBUG - 2011-04-17 11:31:19 --> Output Class Initialized
DEBUG - 2011-04-17 11:31:19 --> Input Class Initialized
DEBUG - 2011-04-17 11:31:19 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-17 11:31:19 --> Language Class Initialized
DEBUG - 2011-04-17 11:31:19 --> Loader Class Initialized
DEBUG - 2011-04-17 11:31:19 --> Controller Class Initialized
ERROR - 2011-04-17 11:31:19 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-17 11:31:19 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-17 11:31:19 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-17 11:31:19 --> Model Class Initialized
DEBUG - 2011-04-17 11:31:19 --> Model Class Initialized
DEBUG - 2011-04-17 11:31:19 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-17 11:31:19 --> Database Driver Class Initialized
DEBUG - 2011-04-17 11:31:19 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-17 11:31:19 --> Helper loaded: url_helper
DEBUG - 2011-04-17 11:31:19 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-17 11:31:19 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-17 11:31:19 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-17 11:31:19 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-17 11:31:19 --> Final output sent to browser
DEBUG - 2011-04-17 11:31:19 --> Total execution time: 0.1665
DEBUG - 2011-04-17 11:31:20 --> Config Class Initialized
DEBUG - 2011-04-17 11:31:20 --> Hooks Class Initialized
DEBUG - 2011-04-17 11:31:20 --> Utf8 Class Initialized
DEBUG - 2011-04-17 11:31:20 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 11:31:20 --> URI Class Initialized
DEBUG - 2011-04-17 11:31:20 --> Router Class Initialized
DEBUG - 2011-04-17 11:31:20 --> Output Class Initialized
DEBUG - 2011-04-17 11:31:20 --> Input Class Initialized
DEBUG - 2011-04-17 11:31:20 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-17 11:31:20 --> Language Class Initialized
DEBUG - 2011-04-17 11:31:20 --> Loader Class Initialized
DEBUG - 2011-04-17 11:31:20 --> Controller Class Initialized
DEBUG - 2011-04-17 11:31:20 --> Model Class Initialized
DEBUG - 2011-04-17 11:31:20 --> Model Class Initialized
DEBUG - 2011-04-17 11:31:20 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-17 11:31:20 --> Database Driver Class Initialized
DEBUG - 2011-04-17 11:31:20 --> Final output sent to browser
DEBUG - 2011-04-17 11:31:20 --> Total execution time: 0.4897
DEBUG - 2011-04-17 11:31:22 --> Config Class Initialized
DEBUG - 2011-04-17 11:31:22 --> Hooks Class Initialized
DEBUG - 2011-04-17 11:31:22 --> Utf8 Class Initialized
DEBUG - 2011-04-17 11:31:22 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 11:31:22 --> URI Class Initialized
DEBUG - 2011-04-17 11:31:22 --> Router Class Initialized
ERROR - 2011-04-17 11:31:22 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-17 11:31:27 --> Config Class Initialized
DEBUG - 2011-04-17 11:31:27 --> Hooks Class Initialized
DEBUG - 2011-04-17 11:31:27 --> Utf8 Class Initialized
DEBUG - 2011-04-17 11:31:27 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 11:31:27 --> URI Class Initialized
DEBUG - 2011-04-17 11:31:27 --> Router Class Initialized
DEBUG - 2011-04-17 11:31:27 --> Output Class Initialized
DEBUG - 2011-04-17 11:31:27 --> Input Class Initialized
DEBUG - 2011-04-17 11:31:27 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-17 11:31:27 --> Language Class Initialized
DEBUG - 2011-04-17 11:31:27 --> Loader Class Initialized
DEBUG - 2011-04-17 11:31:27 --> Controller Class Initialized
ERROR - 2011-04-17 11:31:27 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-17 11:31:27 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-17 11:31:27 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-17 11:31:27 --> Model Class Initialized
DEBUG - 2011-04-17 11:31:27 --> Model Class Initialized
DEBUG - 2011-04-17 11:31:27 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-17 11:31:27 --> Database Driver Class Initialized
DEBUG - 2011-04-17 11:31:27 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-17 11:31:27 --> Helper loaded: url_helper
DEBUG - 2011-04-17 11:31:27 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-17 11:31:27 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-17 11:31:27 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-17 11:31:27 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-17 11:31:27 --> Final output sent to browser
DEBUG - 2011-04-17 11:31:27 --> Total execution time: 0.0331
DEBUG - 2011-04-17 11:31:28 --> Config Class Initialized
DEBUG - 2011-04-17 11:31:28 --> Hooks Class Initialized
DEBUG - 2011-04-17 11:31:28 --> Utf8 Class Initialized
DEBUG - 2011-04-17 11:31:28 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 11:31:28 --> URI Class Initialized
DEBUG - 2011-04-17 11:31:28 --> Router Class Initialized
DEBUG - 2011-04-17 11:31:28 --> Output Class Initialized
DEBUG - 2011-04-17 11:31:28 --> Input Class Initialized
DEBUG - 2011-04-17 11:31:28 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-17 11:31:28 --> Language Class Initialized
DEBUG - 2011-04-17 11:31:28 --> Loader Class Initialized
DEBUG - 2011-04-17 11:31:28 --> Controller Class Initialized
DEBUG - 2011-04-17 11:31:28 --> Model Class Initialized
DEBUG - 2011-04-17 11:31:28 --> Model Class Initialized
DEBUG - 2011-04-17 11:31:28 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-17 11:31:28 --> Database Driver Class Initialized
DEBUG - 2011-04-17 11:31:28 --> Final output sent to browser
DEBUG - 2011-04-17 11:31:28 --> Total execution time: 0.6068
DEBUG - 2011-04-17 11:31:29 --> Config Class Initialized
DEBUG - 2011-04-17 11:31:29 --> Hooks Class Initialized
DEBUG - 2011-04-17 11:31:29 --> Utf8 Class Initialized
DEBUG - 2011-04-17 11:31:29 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 11:31:29 --> URI Class Initialized
DEBUG - 2011-04-17 11:31:29 --> Router Class Initialized
ERROR - 2011-04-17 11:31:29 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-17 11:31:31 --> Config Class Initialized
DEBUG - 2011-04-17 11:31:31 --> Hooks Class Initialized
DEBUG - 2011-04-17 11:31:31 --> Utf8 Class Initialized
DEBUG - 2011-04-17 11:31:31 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 11:31:31 --> URI Class Initialized
DEBUG - 2011-04-17 11:31:31 --> Router Class Initialized
DEBUG - 2011-04-17 11:31:31 --> Output Class Initialized
DEBUG - 2011-04-17 11:31:31 --> Input Class Initialized
DEBUG - 2011-04-17 11:31:31 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-17 11:31:31 --> Language Class Initialized
DEBUG - 2011-04-17 11:31:31 --> Loader Class Initialized
DEBUG - 2011-04-17 11:31:31 --> Controller Class Initialized
ERROR - 2011-04-17 11:31:31 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-17 11:31:31 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-17 11:31:31 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-17 11:31:31 --> Model Class Initialized
DEBUG - 2011-04-17 11:31:31 --> Model Class Initialized
DEBUG - 2011-04-17 11:31:31 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-17 11:31:31 --> Database Driver Class Initialized
DEBUG - 2011-04-17 11:31:31 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-17 11:31:31 --> Helper loaded: url_helper
DEBUG - 2011-04-17 11:31:31 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-17 11:31:31 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-17 11:31:31 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-17 11:31:31 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-17 11:31:31 --> Final output sent to browser
DEBUG - 2011-04-17 11:31:31 --> Total execution time: 0.0808
DEBUG - 2011-04-17 11:31:31 --> Config Class Initialized
DEBUG - 2011-04-17 11:31:31 --> Hooks Class Initialized
DEBUG - 2011-04-17 11:31:31 --> Utf8 Class Initialized
DEBUG - 2011-04-17 11:31:31 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 11:31:31 --> URI Class Initialized
DEBUG - 2011-04-17 11:31:31 --> Router Class Initialized
DEBUG - 2011-04-17 11:31:31 --> Output Class Initialized
DEBUG - 2011-04-17 11:31:31 --> Input Class Initialized
DEBUG - 2011-04-17 11:31:31 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-17 11:31:31 --> Language Class Initialized
DEBUG - 2011-04-17 11:31:31 --> Loader Class Initialized
DEBUG - 2011-04-17 11:31:31 --> Controller Class Initialized
DEBUG - 2011-04-17 11:31:31 --> Model Class Initialized
DEBUG - 2011-04-17 11:31:32 --> Model Class Initialized
DEBUG - 2011-04-17 11:31:32 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-17 11:31:32 --> Database Driver Class Initialized
DEBUG - 2011-04-17 11:31:32 --> Config Class Initialized
DEBUG - 2011-04-17 11:31:32 --> Hooks Class Initialized
DEBUG - 2011-04-17 11:31:32 --> Utf8 Class Initialized
DEBUG - 2011-04-17 11:31:32 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 11:31:32 --> URI Class Initialized
DEBUG - 2011-04-17 11:31:32 --> Router Class Initialized
DEBUG - 2011-04-17 11:31:32 --> Output Class Initialized
DEBUG - 2011-04-17 11:31:32 --> Input Class Initialized
DEBUG - 2011-04-17 11:31:32 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-17 11:31:32 --> Language Class Initialized
DEBUG - 2011-04-17 11:31:32 --> Loader Class Initialized
DEBUG - 2011-04-17 11:31:32 --> Controller Class Initialized
ERROR - 2011-04-17 11:31:32 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-17 11:31:32 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-17 11:31:32 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-17 11:31:32 --> Model Class Initialized
DEBUG - 2011-04-17 11:31:32 --> Model Class Initialized
DEBUG - 2011-04-17 11:31:32 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-17 11:31:32 --> Database Driver Class Initialized
DEBUG - 2011-04-17 11:31:32 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-17 11:31:32 --> Helper loaded: url_helper
DEBUG - 2011-04-17 11:31:32 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-17 11:31:32 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-17 11:31:32 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-17 11:31:32 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-17 11:31:32 --> Final output sent to browser
DEBUG - 2011-04-17 11:31:32 --> Total execution time: 0.0576
DEBUG - 2011-04-17 11:31:33 --> Final output sent to browser
DEBUG - 2011-04-17 11:31:33 --> Total execution time: 1.0883
DEBUG - 2011-04-17 11:31:34 --> Config Class Initialized
DEBUG - 2011-04-17 11:31:34 --> Hooks Class Initialized
DEBUG - 2011-04-17 11:31:34 --> Utf8 Class Initialized
DEBUG - 2011-04-17 11:31:34 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 11:31:34 --> URI Class Initialized
DEBUG - 2011-04-17 11:31:34 --> Router Class Initialized
ERROR - 2011-04-17 11:31:34 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-17 11:31:35 --> Config Class Initialized
DEBUG - 2011-04-17 11:31:35 --> Hooks Class Initialized
DEBUG - 2011-04-17 11:31:35 --> Utf8 Class Initialized
DEBUG - 2011-04-17 11:31:35 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 11:31:35 --> URI Class Initialized
DEBUG - 2011-04-17 11:31:35 --> Router Class Initialized
DEBUG - 2011-04-17 11:31:35 --> Output Class Initialized
DEBUG - 2011-04-17 11:31:35 --> Input Class Initialized
DEBUG - 2011-04-17 11:31:35 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-17 11:31:35 --> Language Class Initialized
DEBUG - 2011-04-17 11:31:35 --> Loader Class Initialized
DEBUG - 2011-04-17 11:31:35 --> Controller Class Initialized
ERROR - 2011-04-17 11:31:35 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-17 11:31:35 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-17 11:31:35 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-17 11:31:35 --> Model Class Initialized
DEBUG - 2011-04-17 11:31:35 --> Model Class Initialized
DEBUG - 2011-04-17 11:31:35 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-17 11:31:35 --> Database Driver Class Initialized
DEBUG - 2011-04-17 11:31:35 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-17 11:31:35 --> Helper loaded: url_helper
DEBUG - 2011-04-17 11:31:35 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-17 11:31:35 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-17 11:31:35 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-17 11:31:35 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-17 11:31:35 --> Final output sent to browser
DEBUG - 2011-04-17 11:31:35 --> Total execution time: 0.0366
DEBUG - 2011-04-17 11:31:36 --> Config Class Initialized
DEBUG - 2011-04-17 11:31:36 --> Hooks Class Initialized
DEBUG - 2011-04-17 11:31:36 --> Utf8 Class Initialized
DEBUG - 2011-04-17 11:31:36 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 11:31:36 --> URI Class Initialized
DEBUG - 2011-04-17 11:31:36 --> Router Class Initialized
DEBUG - 2011-04-17 11:31:36 --> Output Class Initialized
DEBUG - 2011-04-17 11:31:36 --> Input Class Initialized
DEBUG - 2011-04-17 11:31:36 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-17 11:31:36 --> Language Class Initialized
DEBUG - 2011-04-17 11:31:36 --> Loader Class Initialized
DEBUG - 2011-04-17 11:31:36 --> Controller Class Initialized
DEBUG - 2011-04-17 11:31:36 --> Model Class Initialized
DEBUG - 2011-04-17 11:31:36 --> Model Class Initialized
DEBUG - 2011-04-17 11:31:36 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-17 11:31:36 --> Database Driver Class Initialized
DEBUG - 2011-04-17 11:31:36 --> Final output sent to browser
DEBUG - 2011-04-17 11:31:36 --> Total execution time: 0.5692
DEBUG - 2011-04-17 11:31:37 --> Config Class Initialized
DEBUG - 2011-04-17 11:31:37 --> Hooks Class Initialized
DEBUG - 2011-04-17 11:31:37 --> Utf8 Class Initialized
DEBUG - 2011-04-17 11:31:37 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 11:31:37 --> URI Class Initialized
DEBUG - 2011-04-17 11:31:37 --> Router Class Initialized
DEBUG - 2011-04-17 11:31:37 --> Output Class Initialized
DEBUG - 2011-04-17 11:31:37 --> Input Class Initialized
DEBUG - 2011-04-17 11:31:37 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-17 11:31:37 --> Language Class Initialized
DEBUG - 2011-04-17 11:31:37 --> Loader Class Initialized
DEBUG - 2011-04-17 11:31:37 --> Controller Class Initialized
ERROR - 2011-04-17 11:31:37 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-17 11:31:37 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-17 11:31:37 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-17 11:31:37 --> Model Class Initialized
DEBUG - 2011-04-17 11:31:37 --> Model Class Initialized
DEBUG - 2011-04-17 11:31:37 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-17 11:31:37 --> Database Driver Class Initialized
DEBUG - 2011-04-17 11:31:37 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-17 11:31:37 --> Helper loaded: url_helper
DEBUG - 2011-04-17 11:31:37 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-17 11:31:37 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-17 11:31:37 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-17 11:31:37 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-17 11:31:37 --> Final output sent to browser
DEBUG - 2011-04-17 11:31:37 --> Total execution time: 0.0277
DEBUG - 2011-04-17 11:31:37 --> Config Class Initialized
DEBUG - 2011-04-17 11:31:37 --> Hooks Class Initialized
DEBUG - 2011-04-17 11:31:37 --> Utf8 Class Initialized
DEBUG - 2011-04-17 11:31:37 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 11:31:37 --> URI Class Initialized
DEBUG - 2011-04-17 11:31:37 --> Router Class Initialized
ERROR - 2011-04-17 11:31:37 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-17 11:31:41 --> Config Class Initialized
DEBUG - 2011-04-17 11:31:41 --> Hooks Class Initialized
DEBUG - 2011-04-17 11:31:41 --> Utf8 Class Initialized
DEBUG - 2011-04-17 11:31:41 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 11:31:41 --> URI Class Initialized
DEBUG - 2011-04-17 11:31:41 --> Router Class Initialized
DEBUG - 2011-04-17 11:31:41 --> Output Class Initialized
DEBUG - 2011-04-17 11:31:41 --> Input Class Initialized
DEBUG - 2011-04-17 11:31:41 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-17 11:31:41 --> Language Class Initialized
DEBUG - 2011-04-17 11:31:41 --> Loader Class Initialized
DEBUG - 2011-04-17 11:31:41 --> Controller Class Initialized
ERROR - 2011-04-17 11:31:41 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-17 11:31:41 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-17 11:31:41 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-17 11:31:41 --> Model Class Initialized
DEBUG - 2011-04-17 11:31:41 --> Model Class Initialized
DEBUG - 2011-04-17 11:31:41 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-17 11:31:41 --> Database Driver Class Initialized
DEBUG - 2011-04-17 11:31:41 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-17 11:31:41 --> Helper loaded: url_helper
DEBUG - 2011-04-17 11:31:41 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-17 11:31:41 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-17 11:31:41 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-17 11:31:41 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-17 11:31:41 --> Final output sent to browser
DEBUG - 2011-04-17 11:31:41 --> Total execution time: 0.0331
DEBUG - 2011-04-17 11:31:41 --> Config Class Initialized
DEBUG - 2011-04-17 11:31:41 --> Hooks Class Initialized
DEBUG - 2011-04-17 11:31:41 --> Utf8 Class Initialized
DEBUG - 2011-04-17 11:31:41 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 11:31:41 --> URI Class Initialized
DEBUG - 2011-04-17 11:31:41 --> Router Class Initialized
DEBUG - 2011-04-17 11:31:41 --> Output Class Initialized
DEBUG - 2011-04-17 11:31:41 --> Input Class Initialized
DEBUG - 2011-04-17 11:31:41 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-17 11:31:41 --> Language Class Initialized
DEBUG - 2011-04-17 11:31:41 --> Loader Class Initialized
DEBUG - 2011-04-17 11:31:41 --> Controller Class Initialized
DEBUG - 2011-04-17 11:31:41 --> Model Class Initialized
DEBUG - 2011-04-17 11:31:41 --> Model Class Initialized
DEBUG - 2011-04-17 11:31:41 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-17 11:31:41 --> Database Driver Class Initialized
DEBUG - 2011-04-17 11:31:41 --> Config Class Initialized
DEBUG - 2011-04-17 11:31:41 --> Hooks Class Initialized
DEBUG - 2011-04-17 11:31:41 --> Utf8 Class Initialized
DEBUG - 2011-04-17 11:31:41 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 11:31:41 --> URI Class Initialized
DEBUG - 2011-04-17 11:31:41 --> Router Class Initialized
DEBUG - 2011-04-17 11:31:41 --> Output Class Initialized
DEBUG - 2011-04-17 11:31:41 --> Input Class Initialized
DEBUG - 2011-04-17 11:31:41 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-17 11:31:41 --> Language Class Initialized
DEBUG - 2011-04-17 11:31:41 --> Loader Class Initialized
DEBUG - 2011-04-17 11:31:41 --> Controller Class Initialized
ERROR - 2011-04-17 11:31:41 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-17 11:31:41 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-17 11:31:41 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-17 11:31:41 --> Model Class Initialized
DEBUG - 2011-04-17 11:31:41 --> Model Class Initialized
DEBUG - 2011-04-17 11:31:41 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-17 11:31:41 --> Database Driver Class Initialized
DEBUG - 2011-04-17 11:31:41 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-17 11:31:41 --> Helper loaded: url_helper
DEBUG - 2011-04-17 11:31:41 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-17 11:31:41 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-17 11:31:41 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-17 11:31:41 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-17 11:31:41 --> Final output sent to browser
DEBUG - 2011-04-17 11:31:41 --> Total execution time: 0.0316
DEBUG - 2011-04-17 11:31:42 --> Final output sent to browser
DEBUG - 2011-04-17 11:31:42 --> Total execution time: 0.6535
DEBUG - 2011-04-17 11:31:42 --> Config Class Initialized
DEBUG - 2011-04-17 11:31:42 --> Hooks Class Initialized
DEBUG - 2011-04-17 11:31:42 --> Utf8 Class Initialized
DEBUG - 2011-04-17 11:31:42 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 11:31:42 --> URI Class Initialized
DEBUG - 2011-04-17 11:31:42 --> Router Class Initialized
ERROR - 2011-04-17 11:31:42 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-17 11:31:52 --> Config Class Initialized
DEBUG - 2011-04-17 11:31:52 --> Hooks Class Initialized
DEBUG - 2011-04-17 11:31:52 --> Utf8 Class Initialized
DEBUG - 2011-04-17 11:31:52 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 11:31:52 --> URI Class Initialized
DEBUG - 2011-04-17 11:31:52 --> Router Class Initialized
DEBUG - 2011-04-17 11:31:52 --> Output Class Initialized
DEBUG - 2011-04-17 11:31:52 --> Input Class Initialized
DEBUG - 2011-04-17 11:31:52 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-17 11:31:52 --> Language Class Initialized
DEBUG - 2011-04-17 11:31:52 --> Loader Class Initialized
DEBUG - 2011-04-17 11:31:52 --> Controller Class Initialized
DEBUG - 2011-04-17 11:31:52 --> Model Class Initialized
DEBUG - 2011-04-17 11:31:52 --> Model Class Initialized
DEBUG - 2011-04-17 11:31:52 --> Model Class Initialized
DEBUG - 2011-04-17 11:31:52 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-17 11:31:52 --> Database Driver Class Initialized
DEBUG - 2011-04-17 11:31:52 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-17 11:31:52 --> Helper loaded: url_helper
DEBUG - 2011-04-17 11:31:52 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-17 11:31:52 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-17 11:31:52 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-17 11:31:52 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-17 11:31:52 --> Final output sent to browser
DEBUG - 2011-04-17 11:31:52 --> Total execution time: 0.2114
DEBUG - 2011-04-17 11:31:53 --> Config Class Initialized
DEBUG - 2011-04-17 11:31:53 --> Hooks Class Initialized
DEBUG - 2011-04-17 11:31:53 --> Utf8 Class Initialized
DEBUG - 2011-04-17 11:31:53 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 11:31:53 --> URI Class Initialized
DEBUG - 2011-04-17 11:31:53 --> Router Class Initialized
ERROR - 2011-04-17 11:31:53 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-17 11:34:37 --> Config Class Initialized
DEBUG - 2011-04-17 11:34:37 --> Hooks Class Initialized
DEBUG - 2011-04-17 11:34:37 --> Utf8 Class Initialized
DEBUG - 2011-04-17 11:34:37 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 11:34:37 --> URI Class Initialized
DEBUG - 2011-04-17 11:34:37 --> Router Class Initialized
DEBUG - 2011-04-17 11:34:37 --> Output Class Initialized
DEBUG - 2011-04-17 11:34:37 --> Input Class Initialized
DEBUG - 2011-04-17 11:34:37 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-17 11:34:37 --> Language Class Initialized
DEBUG - 2011-04-17 11:34:37 --> Loader Class Initialized
DEBUG - 2011-04-17 11:34:37 --> Controller Class Initialized
DEBUG - 2011-04-17 11:34:37 --> Model Class Initialized
DEBUG - 2011-04-17 11:34:37 --> Model Class Initialized
DEBUG - 2011-04-17 11:34:37 --> Model Class Initialized
DEBUG - 2011-04-17 11:34:37 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-17 11:34:37 --> Database Driver Class Initialized
DEBUG - 2011-04-17 11:34:37 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-17 11:34:37 --> Helper loaded: url_helper
DEBUG - 2011-04-17 11:34:37 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-17 11:34:37 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-17 11:34:37 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-17 11:34:37 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-17 11:34:37 --> Final output sent to browser
DEBUG - 2011-04-17 11:34:37 --> Total execution time: 0.0653
DEBUG - 2011-04-17 11:35:52 --> Config Class Initialized
DEBUG - 2011-04-17 11:35:52 --> Hooks Class Initialized
DEBUG - 2011-04-17 11:35:52 --> Utf8 Class Initialized
DEBUG - 2011-04-17 11:35:52 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 11:35:52 --> URI Class Initialized
DEBUG - 2011-04-17 11:35:52 --> Router Class Initialized
DEBUG - 2011-04-17 11:35:52 --> Output Class Initialized
DEBUG - 2011-04-17 11:35:52 --> Input Class Initialized
DEBUG - 2011-04-17 11:35:52 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-17 11:35:52 --> Language Class Initialized
DEBUG - 2011-04-17 11:35:52 --> Loader Class Initialized
DEBUG - 2011-04-17 11:35:52 --> Controller Class Initialized
ERROR - 2011-04-17 11:35:52 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-17 11:35:52 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-17 11:35:52 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-17 11:35:52 --> Model Class Initialized
DEBUG - 2011-04-17 11:35:52 --> Model Class Initialized
DEBUG - 2011-04-17 11:35:52 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-17 11:35:52 --> Database Driver Class Initialized
DEBUG - 2011-04-17 11:35:52 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-17 11:35:52 --> Helper loaded: url_helper
DEBUG - 2011-04-17 11:35:52 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-17 11:35:52 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-17 11:35:52 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-17 11:35:52 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-17 11:35:52 --> Final output sent to browser
DEBUG - 2011-04-17 11:35:52 --> Total execution time: 0.0505
DEBUG - 2011-04-17 11:35:53 --> Config Class Initialized
DEBUG - 2011-04-17 11:35:53 --> Hooks Class Initialized
DEBUG - 2011-04-17 11:35:53 --> Utf8 Class Initialized
DEBUG - 2011-04-17 11:35:53 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 11:35:53 --> URI Class Initialized
DEBUG - 2011-04-17 11:35:53 --> Router Class Initialized
DEBUG - 2011-04-17 11:35:53 --> Output Class Initialized
DEBUG - 2011-04-17 11:35:53 --> Input Class Initialized
DEBUG - 2011-04-17 11:35:53 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-17 11:35:53 --> Language Class Initialized
DEBUG - 2011-04-17 11:35:53 --> Loader Class Initialized
DEBUG - 2011-04-17 11:35:53 --> Controller Class Initialized
DEBUG - 2011-04-17 11:35:53 --> Model Class Initialized
DEBUG - 2011-04-17 11:35:53 --> Model Class Initialized
DEBUG - 2011-04-17 11:35:53 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-17 11:35:53 --> Database Driver Class Initialized
DEBUG - 2011-04-17 11:35:54 --> Final output sent to browser
DEBUG - 2011-04-17 11:35:54 --> Total execution time: 0.8922
DEBUG - 2011-04-17 11:35:57 --> Config Class Initialized
DEBUG - 2011-04-17 11:35:57 --> Hooks Class Initialized
DEBUG - 2011-04-17 11:35:57 --> Utf8 Class Initialized
DEBUG - 2011-04-17 11:35:57 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 11:35:57 --> URI Class Initialized
DEBUG - 2011-04-17 11:35:57 --> Router Class Initialized
DEBUG - 2011-04-17 11:35:57 --> Output Class Initialized
DEBUG - 2011-04-17 11:35:57 --> Input Class Initialized
DEBUG - 2011-04-17 11:35:57 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-17 11:35:57 --> Language Class Initialized
DEBUG - 2011-04-17 11:35:57 --> Loader Class Initialized
DEBUG - 2011-04-17 11:35:57 --> Controller Class Initialized
ERROR - 2011-04-17 11:35:57 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-17 11:35:57 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-17 11:35:57 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-17 11:35:57 --> Model Class Initialized
DEBUG - 2011-04-17 11:35:57 --> Model Class Initialized
DEBUG - 2011-04-17 11:35:57 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-17 11:35:57 --> Database Driver Class Initialized
DEBUG - 2011-04-17 11:35:57 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-17 11:35:57 --> Helper loaded: url_helper
DEBUG - 2011-04-17 11:35:57 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-17 11:35:57 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-17 11:35:57 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-17 11:35:57 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-17 11:35:57 --> Final output sent to browser
DEBUG - 2011-04-17 11:35:57 --> Total execution time: 0.0292
DEBUG - 2011-04-17 11:35:58 --> Config Class Initialized
DEBUG - 2011-04-17 11:35:58 --> Hooks Class Initialized
DEBUG - 2011-04-17 11:35:58 --> Utf8 Class Initialized
DEBUG - 2011-04-17 11:35:58 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 11:35:58 --> URI Class Initialized
DEBUG - 2011-04-17 11:35:58 --> Router Class Initialized
DEBUG - 2011-04-17 11:35:58 --> Output Class Initialized
DEBUG - 2011-04-17 11:35:58 --> Input Class Initialized
DEBUG - 2011-04-17 11:35:58 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-17 11:35:58 --> Language Class Initialized
DEBUG - 2011-04-17 11:35:58 --> Loader Class Initialized
DEBUG - 2011-04-17 11:35:58 --> Controller Class Initialized
DEBUG - 2011-04-17 11:35:58 --> Model Class Initialized
DEBUG - 2011-04-17 11:35:58 --> Model Class Initialized
DEBUG - 2011-04-17 11:35:58 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-17 11:35:58 --> Database Driver Class Initialized
DEBUG - 2011-04-17 11:35:58 --> Final output sent to browser
DEBUG - 2011-04-17 11:35:58 --> Total execution time: 0.5596
DEBUG - 2011-04-17 11:36:00 --> Config Class Initialized
DEBUG - 2011-04-17 11:36:00 --> Hooks Class Initialized
DEBUG - 2011-04-17 11:36:00 --> Utf8 Class Initialized
DEBUG - 2011-04-17 11:36:00 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 11:36:00 --> URI Class Initialized
DEBUG - 2011-04-17 11:36:00 --> Router Class Initialized
ERROR - 2011-04-17 11:36:00 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-17 11:36:17 --> Config Class Initialized
DEBUG - 2011-04-17 11:36:17 --> Hooks Class Initialized
DEBUG - 2011-04-17 11:36:17 --> Utf8 Class Initialized
DEBUG - 2011-04-17 11:36:17 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 11:36:17 --> URI Class Initialized
DEBUG - 2011-04-17 11:36:17 --> Router Class Initialized
DEBUG - 2011-04-17 11:36:17 --> No URI present. Default controller set.
DEBUG - 2011-04-17 11:36:17 --> Output Class Initialized
DEBUG - 2011-04-17 11:36:17 --> Input Class Initialized
DEBUG - 2011-04-17 11:36:17 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-17 11:36:17 --> Language Class Initialized
DEBUG - 2011-04-17 11:36:17 --> Loader Class Initialized
DEBUG - 2011-04-17 11:36:17 --> Controller Class Initialized
DEBUG - 2011-04-17 11:36:17 --> File loaded: application/views/splash/main.php
DEBUG - 2011-04-17 11:36:17 --> Helper loaded: url_helper
DEBUG - 2011-04-17 11:36:17 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-17 11:36:17 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-17 11:36:17 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-17 11:36:17 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-17 11:36:17 --> Final output sent to browser
DEBUG - 2011-04-17 11:36:17 --> Total execution time: 0.1258
DEBUG - 2011-04-17 11:36:18 --> Config Class Initialized
DEBUG - 2011-04-17 11:36:18 --> Hooks Class Initialized
DEBUG - 2011-04-17 11:36:18 --> Utf8 Class Initialized
DEBUG - 2011-04-17 11:36:18 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 11:36:18 --> URI Class Initialized
DEBUG - 2011-04-17 11:36:18 --> Router Class Initialized
ERROR - 2011-04-17 11:36:18 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-17 11:36:18 --> Config Class Initialized
DEBUG - 2011-04-17 11:36:18 --> Hooks Class Initialized
DEBUG - 2011-04-17 11:36:18 --> Utf8 Class Initialized
DEBUG - 2011-04-17 11:36:18 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 11:36:18 --> URI Class Initialized
DEBUG - 2011-04-17 11:36:18 --> Router Class Initialized
ERROR - 2011-04-17 11:36:18 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-17 11:36:19 --> Config Class Initialized
DEBUG - 2011-04-17 11:36:19 --> Hooks Class Initialized
DEBUG - 2011-04-17 11:36:19 --> Utf8 Class Initialized
DEBUG - 2011-04-17 11:36:19 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 11:36:19 --> URI Class Initialized
DEBUG - 2011-04-17 11:36:19 --> Router Class Initialized
ERROR - 2011-04-17 11:36:19 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-17 11:36:21 --> Config Class Initialized
DEBUG - 2011-04-17 11:36:21 --> Hooks Class Initialized
DEBUG - 2011-04-17 11:36:21 --> Utf8 Class Initialized
DEBUG - 2011-04-17 11:36:21 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 11:36:21 --> URI Class Initialized
DEBUG - 2011-04-17 11:36:21 --> Router Class Initialized
DEBUG - 2011-04-17 11:36:21 --> Output Class Initialized
DEBUG - 2011-04-17 11:36:21 --> Input Class Initialized
DEBUG - 2011-04-17 11:36:21 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-17 11:36:21 --> Language Class Initialized
DEBUG - 2011-04-17 11:36:21 --> Loader Class Initialized
DEBUG - 2011-04-17 11:36:21 --> Controller Class Initialized
ERROR - 2011-04-17 11:36:21 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-17 11:36:21 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-17 11:36:21 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-17 11:36:21 --> Model Class Initialized
DEBUG - 2011-04-17 11:36:21 --> Model Class Initialized
DEBUG - 2011-04-17 11:36:21 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-17 11:36:21 --> Database Driver Class Initialized
DEBUG - 2011-04-17 11:36:21 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-17 11:36:21 --> Helper loaded: url_helper
DEBUG - 2011-04-17 11:36:21 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-17 11:36:21 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-17 11:36:21 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-17 11:36:21 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-17 11:36:21 --> Final output sent to browser
DEBUG - 2011-04-17 11:36:21 --> Total execution time: 0.0590
DEBUG - 2011-04-17 11:36:22 --> Config Class Initialized
DEBUG - 2011-04-17 11:36:22 --> Hooks Class Initialized
DEBUG - 2011-04-17 11:36:22 --> Utf8 Class Initialized
DEBUG - 2011-04-17 11:36:22 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 11:36:22 --> URI Class Initialized
DEBUG - 2011-04-17 11:36:22 --> Router Class Initialized
DEBUG - 2011-04-17 11:36:22 --> Output Class Initialized
DEBUG - 2011-04-17 11:36:22 --> Input Class Initialized
DEBUG - 2011-04-17 11:36:22 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-17 11:36:22 --> Language Class Initialized
DEBUG - 2011-04-17 11:36:22 --> Loader Class Initialized
DEBUG - 2011-04-17 11:36:22 --> Controller Class Initialized
DEBUG - 2011-04-17 11:36:22 --> Model Class Initialized
DEBUG - 2011-04-17 11:36:22 --> Model Class Initialized
DEBUG - 2011-04-17 11:36:22 --> Model Class Initialized
DEBUG - 2011-04-17 11:36:22 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-17 11:36:22 --> Config Class Initialized
DEBUG - 2011-04-17 11:36:22 --> Hooks Class Initialized
DEBUG - 2011-04-17 11:36:22 --> Utf8 Class Initialized
DEBUG - 2011-04-17 11:36:22 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 11:36:22 --> URI Class Initialized
DEBUG - 2011-04-17 11:36:22 --> Router Class Initialized
DEBUG - 2011-04-17 11:36:22 --> Output Class Initialized
DEBUG - 2011-04-17 11:36:22 --> Input Class Initialized
DEBUG - 2011-04-17 11:36:22 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-17 11:36:22 --> Language Class Initialized
DEBUG - 2011-04-17 11:36:22 --> Loader Class Initialized
DEBUG - 2011-04-17 11:36:22 --> Controller Class Initialized
DEBUG - 2011-04-17 11:36:22 --> Model Class Initialized
DEBUG - 2011-04-17 11:36:22 --> Model Class Initialized
DEBUG - 2011-04-17 11:36:22 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-17 11:36:22 --> Database Driver Class Initialized
DEBUG - 2011-04-17 11:36:22 --> Database Driver Class Initialized
DEBUG - 2011-04-17 11:36:22 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-17 11:36:22 --> Helper loaded: url_helper
DEBUG - 2011-04-17 11:36:22 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-17 11:36:22 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-17 11:36:22 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-17 11:36:22 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-17 11:36:22 --> Final output sent to browser
DEBUG - 2011-04-17 11:36:22 --> Total execution time: 0.1017
DEBUG - 2011-04-17 11:36:23 --> Final output sent to browser
DEBUG - 2011-04-17 11:36:23 --> Total execution time: 0.6614
DEBUG - 2011-04-17 11:36:26 --> Config Class Initialized
DEBUG - 2011-04-17 11:36:26 --> Hooks Class Initialized
DEBUG - 2011-04-17 11:36:26 --> Utf8 Class Initialized
DEBUG - 2011-04-17 11:36:26 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 11:36:26 --> URI Class Initialized
DEBUG - 2011-04-17 11:36:26 --> Router Class Initialized
DEBUG - 2011-04-17 11:36:26 --> Output Class Initialized
DEBUG - 2011-04-17 11:36:26 --> Input Class Initialized
DEBUG - 2011-04-17 11:36:26 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-17 11:36:26 --> Language Class Initialized
DEBUG - 2011-04-17 11:36:26 --> Loader Class Initialized
DEBUG - 2011-04-17 11:36:26 --> Controller Class Initialized
ERROR - 2011-04-17 11:36:26 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-17 11:36:26 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-17 11:36:26 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-17 11:36:26 --> Model Class Initialized
DEBUG - 2011-04-17 11:36:26 --> Model Class Initialized
DEBUG - 2011-04-17 11:36:26 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-17 11:36:26 --> Database Driver Class Initialized
DEBUG - 2011-04-17 11:36:26 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-17 11:36:26 --> Helper loaded: url_helper
DEBUG - 2011-04-17 11:36:26 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-17 11:36:26 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-17 11:36:26 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-17 11:36:26 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-17 11:36:26 --> Final output sent to browser
DEBUG - 2011-04-17 11:36:26 --> Total execution time: 0.0475
DEBUG - 2011-04-17 11:36:29 --> Config Class Initialized
DEBUG - 2011-04-17 11:36:29 --> Hooks Class Initialized
DEBUG - 2011-04-17 11:36:29 --> Utf8 Class Initialized
DEBUG - 2011-04-17 11:36:29 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 11:36:29 --> URI Class Initialized
DEBUG - 2011-04-17 11:36:29 --> Router Class Initialized
DEBUG - 2011-04-17 11:36:29 --> Output Class Initialized
DEBUG - 2011-04-17 11:36:29 --> Input Class Initialized
DEBUG - 2011-04-17 11:36:29 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-17 11:36:29 --> Language Class Initialized
DEBUG - 2011-04-17 11:36:29 --> Loader Class Initialized
DEBUG - 2011-04-17 11:36:29 --> Controller Class Initialized
ERROR - 2011-04-17 11:36:29 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-17 11:36:29 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-17 11:36:29 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-17 11:36:29 --> Model Class Initialized
DEBUG - 2011-04-17 11:36:29 --> Model Class Initialized
DEBUG - 2011-04-17 11:36:29 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-17 11:36:29 --> Database Driver Class Initialized
DEBUG - 2011-04-17 11:36:29 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-17 11:36:29 --> Helper loaded: url_helper
DEBUG - 2011-04-17 11:36:29 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-17 11:36:29 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-17 11:36:29 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-17 11:36:29 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-17 11:36:29 --> Final output sent to browser
DEBUG - 2011-04-17 11:36:29 --> Total execution time: 0.0676
DEBUG - 2011-04-17 11:36:34 --> Config Class Initialized
DEBUG - 2011-04-17 11:36:34 --> Hooks Class Initialized
DEBUG - 2011-04-17 11:36:34 --> Utf8 Class Initialized
DEBUG - 2011-04-17 11:36:34 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 11:36:34 --> URI Class Initialized
DEBUG - 2011-04-17 11:36:34 --> Router Class Initialized
DEBUG - 2011-04-17 11:36:34 --> Output Class Initialized
DEBUG - 2011-04-17 11:36:34 --> Input Class Initialized
DEBUG - 2011-04-17 11:36:34 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-17 11:36:34 --> Language Class Initialized
DEBUG - 2011-04-17 11:36:34 --> Loader Class Initialized
DEBUG - 2011-04-17 11:36:34 --> Controller Class Initialized
DEBUG - 2011-04-17 11:36:34 --> Model Class Initialized
DEBUG - 2011-04-17 11:36:34 --> Model Class Initialized
DEBUG - 2011-04-17 11:36:34 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-17 11:36:34 --> Database Driver Class Initialized
DEBUG - 2011-04-17 11:36:34 --> Config Class Initialized
DEBUG - 2011-04-17 11:36:34 --> Hooks Class Initialized
DEBUG - 2011-04-17 11:36:34 --> Utf8 Class Initialized
DEBUG - 2011-04-17 11:36:34 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 11:36:34 --> URI Class Initialized
DEBUG - 2011-04-17 11:36:34 --> Router Class Initialized
DEBUG - 2011-04-17 11:36:34 --> No URI present. Default controller set.
DEBUG - 2011-04-17 11:36:34 --> Output Class Initialized
DEBUG - 2011-04-17 11:36:34 --> Input Class Initialized
DEBUG - 2011-04-17 11:36:34 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-17 11:36:34 --> Language Class Initialized
DEBUG - 2011-04-17 11:36:34 --> Loader Class Initialized
DEBUG - 2011-04-17 11:36:34 --> Controller Class Initialized
DEBUG - 2011-04-17 11:36:34 --> File loaded: application/views/splash/main.php
DEBUG - 2011-04-17 11:36:34 --> Helper loaded: url_helper
DEBUG - 2011-04-17 11:36:34 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-17 11:36:34 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-17 11:36:34 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-17 11:36:34 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-17 11:36:34 --> Final output sent to browser
DEBUG - 2011-04-17 11:36:34 --> Total execution time: 0.0264
DEBUG - 2011-04-17 11:36:35 --> Final output sent to browser
DEBUG - 2011-04-17 11:36:35 --> Total execution time: 0.7415
DEBUG - 2011-04-17 11:36:36 --> Config Class Initialized
DEBUG - 2011-04-17 11:36:36 --> Hooks Class Initialized
DEBUG - 2011-04-17 11:36:36 --> Utf8 Class Initialized
DEBUG - 2011-04-17 11:36:36 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 11:36:36 --> URI Class Initialized
DEBUG - 2011-04-17 11:36:36 --> Router Class Initialized
ERROR - 2011-04-17 11:36:36 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-17 11:36:37 --> Config Class Initialized
DEBUG - 2011-04-17 11:36:37 --> Hooks Class Initialized
DEBUG - 2011-04-17 11:36:37 --> Utf8 Class Initialized
DEBUG - 2011-04-17 11:36:37 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 11:36:37 --> URI Class Initialized
DEBUG - 2011-04-17 11:36:37 --> Router Class Initialized
ERROR - 2011-04-17 11:36:37 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-17 11:36:45 --> Config Class Initialized
DEBUG - 2011-04-17 11:36:45 --> Hooks Class Initialized
DEBUG - 2011-04-17 11:36:45 --> Utf8 Class Initialized
DEBUG - 2011-04-17 11:36:45 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 11:36:45 --> URI Class Initialized
DEBUG - 2011-04-17 11:36:45 --> Router Class Initialized
DEBUG - 2011-04-17 11:36:45 --> Output Class Initialized
DEBUG - 2011-04-17 11:36:45 --> Input Class Initialized
DEBUG - 2011-04-17 11:36:45 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-17 11:36:45 --> Language Class Initialized
DEBUG - 2011-04-17 11:36:45 --> Loader Class Initialized
DEBUG - 2011-04-17 11:36:45 --> Controller Class Initialized
DEBUG - 2011-04-17 11:36:45 --> Model Class Initialized
DEBUG - 2011-04-17 11:36:45 --> Model Class Initialized
DEBUG - 2011-04-17 11:36:45 --> Model Class Initialized
DEBUG - 2011-04-17 11:36:45 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-17 11:36:45 --> Database Driver Class Initialized
DEBUG - 2011-04-17 11:36:45 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-17 11:36:45 --> Helper loaded: url_helper
DEBUG - 2011-04-17 11:36:45 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-17 11:36:45 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-17 11:36:45 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-17 11:36:45 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-17 11:36:45 --> Final output sent to browser
DEBUG - 2011-04-17 11:36:45 --> Total execution time: 0.4017
DEBUG - 2011-04-17 11:37:04 --> Config Class Initialized
DEBUG - 2011-04-17 11:37:04 --> Hooks Class Initialized
DEBUG - 2011-04-17 11:37:04 --> Utf8 Class Initialized
DEBUG - 2011-04-17 11:37:04 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 11:37:04 --> URI Class Initialized
DEBUG - 2011-04-17 11:37:04 --> Router Class Initialized
DEBUG - 2011-04-17 11:37:04 --> Output Class Initialized
DEBUG - 2011-04-17 11:37:04 --> Input Class Initialized
DEBUG - 2011-04-17 11:37:04 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-17 11:37:04 --> Language Class Initialized
DEBUG - 2011-04-17 11:37:04 --> Loader Class Initialized
DEBUG - 2011-04-17 11:37:04 --> Controller Class Initialized
DEBUG - 2011-04-17 11:37:04 --> Model Class Initialized
DEBUG - 2011-04-17 11:37:04 --> Model Class Initialized
DEBUG - 2011-04-17 11:37:04 --> Model Class Initialized
DEBUG - 2011-04-17 11:37:04 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-17 11:37:04 --> Database Driver Class Initialized
DEBUG - 2011-04-17 11:37:04 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-17 11:37:04 --> Helper loaded: url_helper
DEBUG - 2011-04-17 11:37:04 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-17 11:37:04 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-17 11:37:04 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-17 11:37:04 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-17 11:37:04 --> Final output sent to browser
DEBUG - 2011-04-17 11:37:04 --> Total execution time: 0.4827
DEBUG - 2011-04-17 11:37:13 --> Config Class Initialized
DEBUG - 2011-04-17 11:37:13 --> Hooks Class Initialized
DEBUG - 2011-04-17 11:37:13 --> Utf8 Class Initialized
DEBUG - 2011-04-17 11:37:13 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 11:37:13 --> URI Class Initialized
DEBUG - 2011-04-17 11:37:13 --> Router Class Initialized
DEBUG - 2011-04-17 11:37:13 --> Output Class Initialized
DEBUG - 2011-04-17 11:37:13 --> Input Class Initialized
DEBUG - 2011-04-17 11:37:13 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-17 11:37:13 --> Language Class Initialized
DEBUG - 2011-04-17 11:37:13 --> Loader Class Initialized
DEBUG - 2011-04-17 11:37:13 --> Controller Class Initialized
DEBUG - 2011-04-17 11:37:13 --> Model Class Initialized
DEBUG - 2011-04-17 11:37:13 --> Model Class Initialized
DEBUG - 2011-04-17 11:37:13 --> Model Class Initialized
DEBUG - 2011-04-17 11:37:13 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-17 11:37:13 --> Database Driver Class Initialized
DEBUG - 2011-04-17 11:37:13 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-17 11:37:13 --> Helper loaded: url_helper
DEBUG - 2011-04-17 11:37:13 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-17 11:37:13 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-17 11:37:13 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-17 11:37:13 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-17 11:37:13 --> Final output sent to browser
DEBUG - 2011-04-17 11:37:13 --> Total execution time: 0.3112
DEBUG - 2011-04-17 11:37:30 --> Config Class Initialized
DEBUG - 2011-04-17 11:37:30 --> Hooks Class Initialized
DEBUG - 2011-04-17 11:37:30 --> Utf8 Class Initialized
DEBUG - 2011-04-17 11:37:30 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 11:37:30 --> URI Class Initialized
DEBUG - 2011-04-17 11:37:30 --> Router Class Initialized
DEBUG - 2011-04-17 11:37:30 --> Output Class Initialized
DEBUG - 2011-04-17 11:37:30 --> Input Class Initialized
DEBUG - 2011-04-17 11:37:30 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-17 11:37:30 --> Language Class Initialized
DEBUG - 2011-04-17 11:37:30 --> Loader Class Initialized
DEBUG - 2011-04-17 11:37:30 --> Controller Class Initialized
DEBUG - 2011-04-17 11:37:30 --> Model Class Initialized
DEBUG - 2011-04-17 11:37:30 --> Model Class Initialized
DEBUG - 2011-04-17 11:37:30 --> Model Class Initialized
DEBUG - 2011-04-17 11:37:30 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-17 11:37:30 --> Database Driver Class Initialized
DEBUG - 2011-04-17 11:37:30 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-17 11:37:30 --> Helper loaded: url_helper
DEBUG - 2011-04-17 11:37:30 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-17 11:37:30 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-17 11:37:30 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-17 11:37:30 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-17 11:37:30 --> Final output sent to browser
DEBUG - 2011-04-17 11:37:30 --> Total execution time: 0.1937
DEBUG - 2011-04-17 11:39:16 --> Config Class Initialized
DEBUG - 2011-04-17 11:39:16 --> Hooks Class Initialized
DEBUG - 2011-04-17 11:39:16 --> Utf8 Class Initialized
DEBUG - 2011-04-17 11:39:16 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 11:39:16 --> URI Class Initialized
DEBUG - 2011-04-17 11:39:16 --> Router Class Initialized
DEBUG - 2011-04-17 11:39:16 --> No URI present. Default controller set.
DEBUG - 2011-04-17 11:39:16 --> Output Class Initialized
DEBUG - 2011-04-17 11:39:16 --> Input Class Initialized
DEBUG - 2011-04-17 11:39:16 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-17 11:39:16 --> Language Class Initialized
DEBUG - 2011-04-17 11:39:16 --> Loader Class Initialized
DEBUG - 2011-04-17 11:39:16 --> Controller Class Initialized
DEBUG - 2011-04-17 11:39:16 --> File loaded: application/views/splash/main.php
DEBUG - 2011-04-17 11:39:16 --> Helper loaded: url_helper
DEBUG - 2011-04-17 11:39:16 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-17 11:39:16 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-17 11:39:16 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-17 11:39:16 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-17 11:39:16 --> Final output sent to browser
DEBUG - 2011-04-17 11:39:16 --> Total execution time: 0.0171
DEBUG - 2011-04-17 11:39:18 --> Config Class Initialized
DEBUG - 2011-04-17 11:39:18 --> Hooks Class Initialized
DEBUG - 2011-04-17 11:39:18 --> Utf8 Class Initialized
DEBUG - 2011-04-17 11:39:18 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 11:39:18 --> URI Class Initialized
DEBUG - 2011-04-17 11:39:18 --> Router Class Initialized
ERROR - 2011-04-17 11:39:18 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-17 11:39:24 --> Config Class Initialized
DEBUG - 2011-04-17 11:39:24 --> Hooks Class Initialized
DEBUG - 2011-04-17 11:39:24 --> Utf8 Class Initialized
DEBUG - 2011-04-17 11:39:24 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 11:39:24 --> URI Class Initialized
DEBUG - 2011-04-17 11:39:24 --> Router Class Initialized
DEBUG - 2011-04-17 11:39:24 --> Output Class Initialized
DEBUG - 2011-04-17 11:39:24 --> Input Class Initialized
DEBUG - 2011-04-17 11:39:24 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-17 11:39:24 --> Language Class Initialized
DEBUG - 2011-04-17 11:39:24 --> Loader Class Initialized
DEBUG - 2011-04-17 11:39:24 --> Controller Class Initialized
DEBUG - 2011-04-17 11:39:24 --> Model Class Initialized
DEBUG - 2011-04-17 11:39:24 --> Model Class Initialized
DEBUG - 2011-04-17 11:39:24 --> Model Class Initialized
DEBUG - 2011-04-17 11:39:24 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-17 11:39:24 --> Database Driver Class Initialized
DEBUG - 2011-04-17 11:39:24 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-17 11:39:24 --> Helper loaded: url_helper
DEBUG - 2011-04-17 11:39:24 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-17 11:39:24 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-17 11:39:24 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-17 11:39:24 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-17 11:39:24 --> Final output sent to browser
DEBUG - 2011-04-17 11:39:24 --> Total execution time: 0.0525
DEBUG - 2011-04-17 11:39:26 --> Config Class Initialized
DEBUG - 2011-04-17 11:39:26 --> Hooks Class Initialized
DEBUG - 2011-04-17 11:39:26 --> Utf8 Class Initialized
DEBUG - 2011-04-17 11:39:26 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 11:39:26 --> URI Class Initialized
DEBUG - 2011-04-17 11:39:26 --> Router Class Initialized
ERROR - 2011-04-17 11:39:26 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-17 11:39:43 --> Config Class Initialized
DEBUG - 2011-04-17 11:39:43 --> Hooks Class Initialized
DEBUG - 2011-04-17 11:39:43 --> Utf8 Class Initialized
DEBUG - 2011-04-17 11:39:43 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 11:39:43 --> URI Class Initialized
DEBUG - 2011-04-17 11:39:43 --> Router Class Initialized
DEBUG - 2011-04-17 11:39:43 --> Output Class Initialized
DEBUG - 2011-04-17 11:39:43 --> Input Class Initialized
DEBUG - 2011-04-17 11:39:43 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-17 11:39:43 --> Language Class Initialized
DEBUG - 2011-04-17 11:39:43 --> Loader Class Initialized
DEBUG - 2011-04-17 11:39:43 --> Controller Class Initialized
DEBUG - 2011-04-17 11:39:43 --> Model Class Initialized
DEBUG - 2011-04-17 11:39:43 --> Model Class Initialized
DEBUG - 2011-04-17 11:39:43 --> Model Class Initialized
DEBUG - 2011-04-17 11:39:43 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-17 11:39:43 --> Database Driver Class Initialized
DEBUG - 2011-04-17 11:39:44 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-17 11:39:44 --> Helper loaded: url_helper
DEBUG - 2011-04-17 11:39:44 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-17 11:39:44 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-17 11:39:44 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-17 11:39:44 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-17 11:39:44 --> Final output sent to browser
DEBUG - 2011-04-17 11:39:44 --> Total execution time: 0.8890
DEBUG - 2011-04-17 11:39:48 --> Config Class Initialized
DEBUG - 2011-04-17 11:39:48 --> Hooks Class Initialized
DEBUG - 2011-04-17 11:39:48 --> Utf8 Class Initialized
DEBUG - 2011-04-17 11:39:48 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 11:39:48 --> URI Class Initialized
DEBUG - 2011-04-17 11:39:48 --> Router Class Initialized
ERROR - 2011-04-17 11:39:48 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-17 11:40:03 --> Config Class Initialized
DEBUG - 2011-04-17 11:40:03 --> Hooks Class Initialized
DEBUG - 2011-04-17 11:40:03 --> Utf8 Class Initialized
DEBUG - 2011-04-17 11:40:03 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 11:40:03 --> URI Class Initialized
DEBUG - 2011-04-17 11:40:03 --> Router Class Initialized
DEBUG - 2011-04-17 11:40:03 --> Output Class Initialized
DEBUG - 2011-04-17 11:40:03 --> Input Class Initialized
DEBUG - 2011-04-17 11:40:03 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-17 11:40:03 --> Language Class Initialized
DEBUG - 2011-04-17 11:40:03 --> Loader Class Initialized
DEBUG - 2011-04-17 11:40:03 --> Controller Class Initialized
DEBUG - 2011-04-17 11:40:03 --> Model Class Initialized
DEBUG - 2011-04-17 11:40:03 --> Model Class Initialized
DEBUG - 2011-04-17 11:40:03 --> Model Class Initialized
DEBUG - 2011-04-17 11:40:03 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-17 11:40:03 --> Database Driver Class Initialized
DEBUG - 2011-04-17 11:40:04 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-17 11:40:04 --> Helper loaded: url_helper
DEBUG - 2011-04-17 11:40:04 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-17 11:40:04 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-17 11:40:04 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-17 11:40:04 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-17 11:40:04 --> Final output sent to browser
DEBUG - 2011-04-17 11:40:04 --> Total execution time: 0.8182
DEBUG - 2011-04-17 11:40:09 --> Config Class Initialized
DEBUG - 2011-04-17 11:40:09 --> Hooks Class Initialized
DEBUG - 2011-04-17 11:40:09 --> Utf8 Class Initialized
DEBUG - 2011-04-17 11:40:09 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 11:40:09 --> URI Class Initialized
DEBUG - 2011-04-17 11:40:09 --> Router Class Initialized
ERROR - 2011-04-17 11:40:09 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-17 11:40:45 --> Config Class Initialized
DEBUG - 2011-04-17 11:40:45 --> Hooks Class Initialized
DEBUG - 2011-04-17 11:40:45 --> Utf8 Class Initialized
DEBUG - 2011-04-17 11:40:45 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 11:40:45 --> URI Class Initialized
DEBUG - 2011-04-17 11:40:45 --> Router Class Initialized
DEBUG - 2011-04-17 11:40:45 --> Output Class Initialized
DEBUG - 2011-04-17 11:40:45 --> Input Class Initialized
DEBUG - 2011-04-17 11:40:45 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-17 11:40:45 --> Language Class Initialized
DEBUG - 2011-04-17 11:40:45 --> Loader Class Initialized
DEBUG - 2011-04-17 11:40:45 --> Controller Class Initialized
DEBUG - 2011-04-17 11:40:45 --> Model Class Initialized
DEBUG - 2011-04-17 11:40:45 --> Model Class Initialized
DEBUG - 2011-04-17 11:40:45 --> Model Class Initialized
DEBUG - 2011-04-17 11:40:45 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-17 11:40:45 --> Database Driver Class Initialized
DEBUG - 2011-04-17 11:40:45 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-17 11:40:45 --> Helper loaded: url_helper
DEBUG - 2011-04-17 11:40:45 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-17 11:40:45 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-17 11:40:45 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-17 11:40:45 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-17 11:40:45 --> Final output sent to browser
DEBUG - 2011-04-17 11:40:45 --> Total execution time: 0.2108
DEBUG - 2011-04-17 11:40:48 --> Config Class Initialized
DEBUG - 2011-04-17 11:40:48 --> Hooks Class Initialized
DEBUG - 2011-04-17 11:40:48 --> Utf8 Class Initialized
DEBUG - 2011-04-17 11:40:48 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 11:40:48 --> URI Class Initialized
DEBUG - 2011-04-17 11:40:48 --> Router Class Initialized
DEBUG - 2011-04-17 11:40:48 --> Output Class Initialized
DEBUG - 2011-04-17 11:40:48 --> Input Class Initialized
DEBUG - 2011-04-17 11:40:48 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-17 11:40:48 --> Language Class Initialized
DEBUG - 2011-04-17 11:40:48 --> Loader Class Initialized
DEBUG - 2011-04-17 11:40:48 --> Controller Class Initialized
DEBUG - 2011-04-17 11:40:48 --> Model Class Initialized
DEBUG - 2011-04-17 11:40:48 --> Model Class Initialized
DEBUG - 2011-04-17 11:40:48 --> Model Class Initialized
DEBUG - 2011-04-17 11:40:48 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-17 11:40:48 --> Database Driver Class Initialized
DEBUG - 2011-04-17 11:40:48 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-17 11:40:48 --> Helper loaded: url_helper
DEBUG - 2011-04-17 11:40:48 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-17 11:40:48 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-17 11:40:48 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-17 11:40:48 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-17 11:40:48 --> Final output sent to browser
DEBUG - 2011-04-17 11:40:48 --> Total execution time: 0.0504
DEBUG - 2011-04-17 11:40:48 --> Config Class Initialized
DEBUG - 2011-04-17 11:40:48 --> Hooks Class Initialized
DEBUG - 2011-04-17 11:40:48 --> Utf8 Class Initialized
DEBUG - 2011-04-17 11:40:48 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 11:40:48 --> URI Class Initialized
DEBUG - 2011-04-17 11:40:48 --> Router Class Initialized
ERROR - 2011-04-17 11:40:48 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-17 11:41:17 --> Config Class Initialized
DEBUG - 2011-04-17 11:41:17 --> Hooks Class Initialized
DEBUG - 2011-04-17 11:41:17 --> Utf8 Class Initialized
DEBUG - 2011-04-17 11:41:17 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 11:41:17 --> URI Class Initialized
DEBUG - 2011-04-17 11:41:17 --> Router Class Initialized
DEBUG - 2011-04-17 11:41:17 --> Output Class Initialized
DEBUG - 2011-04-17 11:41:17 --> Input Class Initialized
DEBUG - 2011-04-17 11:41:17 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-17 11:41:17 --> Language Class Initialized
DEBUG - 2011-04-17 11:41:17 --> Loader Class Initialized
DEBUG - 2011-04-17 11:41:17 --> Controller Class Initialized
DEBUG - 2011-04-17 11:41:17 --> Model Class Initialized
DEBUG - 2011-04-17 11:41:17 --> Model Class Initialized
DEBUG - 2011-04-17 11:41:17 --> Model Class Initialized
DEBUG - 2011-04-17 11:41:17 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-17 11:41:17 --> Database Driver Class Initialized
DEBUG - 2011-04-17 11:41:17 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-17 11:41:17 --> Helper loaded: url_helper
DEBUG - 2011-04-17 11:41:17 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-17 11:41:17 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-17 11:41:17 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-17 11:41:17 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-17 11:41:17 --> Final output sent to browser
DEBUG - 2011-04-17 11:41:17 --> Total execution time: 0.4626
DEBUG - 2011-04-17 11:41:20 --> Config Class Initialized
DEBUG - 2011-04-17 11:41:20 --> Hooks Class Initialized
DEBUG - 2011-04-17 11:41:20 --> Utf8 Class Initialized
DEBUG - 2011-04-17 11:41:20 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 11:41:20 --> URI Class Initialized
DEBUG - 2011-04-17 11:41:20 --> Router Class Initialized
DEBUG - 2011-04-17 11:41:20 --> Output Class Initialized
DEBUG - 2011-04-17 11:41:20 --> Input Class Initialized
DEBUG - 2011-04-17 11:41:20 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-17 11:41:20 --> Language Class Initialized
DEBUG - 2011-04-17 11:41:20 --> Loader Class Initialized
DEBUG - 2011-04-17 11:41:20 --> Controller Class Initialized
DEBUG - 2011-04-17 11:41:20 --> Model Class Initialized
DEBUG - 2011-04-17 11:41:20 --> Model Class Initialized
DEBUG - 2011-04-17 11:41:20 --> Model Class Initialized
DEBUG - 2011-04-17 11:41:20 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-17 11:41:20 --> Database Driver Class Initialized
DEBUG - 2011-04-17 11:41:20 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-17 11:41:20 --> Helper loaded: url_helper
DEBUG - 2011-04-17 11:41:20 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-17 11:41:20 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-17 11:41:20 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-17 11:41:20 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-17 11:41:20 --> Final output sent to browser
DEBUG - 2011-04-17 11:41:20 --> Total execution time: 0.1316
DEBUG - 2011-04-17 11:41:20 --> Config Class Initialized
DEBUG - 2011-04-17 11:41:20 --> Hooks Class Initialized
DEBUG - 2011-04-17 11:41:20 --> Utf8 Class Initialized
DEBUG - 2011-04-17 11:41:20 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 11:41:20 --> URI Class Initialized
DEBUG - 2011-04-17 11:41:20 --> Router Class Initialized
ERROR - 2011-04-17 11:41:20 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-17 11:42:01 --> Config Class Initialized
DEBUG - 2011-04-17 11:42:01 --> Hooks Class Initialized
DEBUG - 2011-04-17 11:42:01 --> Utf8 Class Initialized
DEBUG - 2011-04-17 11:42:01 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 11:42:01 --> URI Class Initialized
DEBUG - 2011-04-17 11:42:01 --> Router Class Initialized
DEBUG - 2011-04-17 11:42:01 --> Output Class Initialized
DEBUG - 2011-04-17 11:42:01 --> Input Class Initialized
DEBUG - 2011-04-17 11:42:01 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-17 11:42:01 --> Language Class Initialized
DEBUG - 2011-04-17 11:42:01 --> Loader Class Initialized
DEBUG - 2011-04-17 11:42:01 --> Controller Class Initialized
DEBUG - 2011-04-17 11:42:01 --> Model Class Initialized
DEBUG - 2011-04-17 11:42:01 --> Model Class Initialized
DEBUG - 2011-04-17 11:42:01 --> Model Class Initialized
DEBUG - 2011-04-17 11:42:01 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-17 11:42:01 --> Database Driver Class Initialized
DEBUG - 2011-04-17 11:42:02 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-17 11:42:02 --> Helper loaded: url_helper
DEBUG - 2011-04-17 11:42:02 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-17 11:42:02 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-17 11:42:02 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-17 11:42:02 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-17 11:42:02 --> Final output sent to browser
DEBUG - 2011-04-17 11:42:02 --> Total execution time: 0.5851
DEBUG - 2011-04-17 11:42:03 --> Config Class Initialized
DEBUG - 2011-04-17 11:42:03 --> Hooks Class Initialized
DEBUG - 2011-04-17 11:42:03 --> Utf8 Class Initialized
DEBUG - 2011-04-17 11:42:03 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 11:42:03 --> URI Class Initialized
DEBUG - 2011-04-17 11:42:03 --> Router Class Initialized
DEBUG - 2011-04-17 11:42:03 --> Output Class Initialized
DEBUG - 2011-04-17 11:42:03 --> Input Class Initialized
DEBUG - 2011-04-17 11:42:03 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-17 11:42:03 --> Language Class Initialized
DEBUG - 2011-04-17 11:42:03 --> Loader Class Initialized
DEBUG - 2011-04-17 11:42:03 --> Controller Class Initialized
DEBUG - 2011-04-17 11:42:03 --> Model Class Initialized
DEBUG - 2011-04-17 11:42:03 --> Model Class Initialized
DEBUG - 2011-04-17 11:42:03 --> Model Class Initialized
DEBUG - 2011-04-17 11:42:03 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-17 11:42:03 --> Database Driver Class Initialized
DEBUG - 2011-04-17 11:42:03 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-17 11:42:03 --> Helper loaded: url_helper
DEBUG - 2011-04-17 11:42:03 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-17 11:42:03 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-17 11:42:03 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-17 11:42:03 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-17 11:42:03 --> Final output sent to browser
DEBUG - 2011-04-17 11:42:03 --> Total execution time: 0.0591
DEBUG - 2011-04-17 11:42:04 --> Config Class Initialized
DEBUG - 2011-04-17 11:42:04 --> Hooks Class Initialized
DEBUG - 2011-04-17 11:42:04 --> Utf8 Class Initialized
DEBUG - 2011-04-17 11:42:04 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 11:42:04 --> URI Class Initialized
DEBUG - 2011-04-17 11:42:04 --> Router Class Initialized
ERROR - 2011-04-17 11:42:04 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-17 11:42:36 --> Config Class Initialized
DEBUG - 2011-04-17 11:42:36 --> Hooks Class Initialized
DEBUG - 2011-04-17 11:42:36 --> Utf8 Class Initialized
DEBUG - 2011-04-17 11:42:36 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 11:42:36 --> URI Class Initialized
DEBUG - 2011-04-17 11:42:36 --> Router Class Initialized
DEBUG - 2011-04-17 11:42:36 --> Output Class Initialized
DEBUG - 2011-04-17 11:42:36 --> Input Class Initialized
DEBUG - 2011-04-17 11:42:36 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-17 11:42:36 --> Language Class Initialized
DEBUG - 2011-04-17 11:42:36 --> Loader Class Initialized
DEBUG - 2011-04-17 11:42:36 --> Controller Class Initialized
DEBUG - 2011-04-17 11:42:36 --> Model Class Initialized
DEBUG - 2011-04-17 11:42:36 --> Model Class Initialized
DEBUG - 2011-04-17 11:42:36 --> Model Class Initialized
DEBUG - 2011-04-17 11:42:36 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-17 11:42:36 --> Database Driver Class Initialized
DEBUG - 2011-04-17 11:42:37 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-17 11:42:37 --> Helper loaded: url_helper
DEBUG - 2011-04-17 11:42:37 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-17 11:42:37 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-17 11:42:37 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-17 11:42:37 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-17 11:42:37 --> Final output sent to browser
DEBUG - 2011-04-17 11:42:37 --> Total execution time: 0.5769
DEBUG - 2011-04-17 11:42:38 --> Config Class Initialized
DEBUG - 2011-04-17 11:42:38 --> Hooks Class Initialized
DEBUG - 2011-04-17 11:42:38 --> Utf8 Class Initialized
DEBUG - 2011-04-17 11:42:38 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 11:42:38 --> URI Class Initialized
DEBUG - 2011-04-17 11:42:38 --> Router Class Initialized
DEBUG - 2011-04-17 11:42:38 --> Output Class Initialized
DEBUG - 2011-04-17 11:42:38 --> Input Class Initialized
DEBUG - 2011-04-17 11:42:38 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-17 11:42:38 --> Language Class Initialized
DEBUG - 2011-04-17 11:42:38 --> Loader Class Initialized
DEBUG - 2011-04-17 11:42:38 --> Controller Class Initialized
DEBUG - 2011-04-17 11:42:38 --> Model Class Initialized
DEBUG - 2011-04-17 11:42:38 --> Model Class Initialized
DEBUG - 2011-04-17 11:42:38 --> Model Class Initialized
DEBUG - 2011-04-17 11:42:38 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-17 11:42:38 --> Database Driver Class Initialized
DEBUG - 2011-04-17 11:42:38 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-17 11:42:38 --> Helper loaded: url_helper
DEBUG - 2011-04-17 11:42:38 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-17 11:42:38 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-17 11:42:38 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-17 11:42:38 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-17 11:42:38 --> Final output sent to browser
DEBUG - 2011-04-17 11:42:38 --> Total execution time: 0.0441
DEBUG - 2011-04-17 11:42:38 --> Config Class Initialized
DEBUG - 2011-04-17 11:42:38 --> Hooks Class Initialized
DEBUG - 2011-04-17 11:42:38 --> Utf8 Class Initialized
DEBUG - 2011-04-17 11:42:38 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 11:42:38 --> URI Class Initialized
DEBUG - 2011-04-17 11:42:38 --> Router Class Initialized
ERROR - 2011-04-17 11:42:38 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-17 11:43:13 --> Config Class Initialized
DEBUG - 2011-04-17 11:43:13 --> Hooks Class Initialized
DEBUG - 2011-04-17 11:43:13 --> Utf8 Class Initialized
DEBUG - 2011-04-17 11:43:13 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 11:43:13 --> URI Class Initialized
DEBUG - 2011-04-17 11:43:13 --> Router Class Initialized
DEBUG - 2011-04-17 11:43:13 --> Output Class Initialized
DEBUG - 2011-04-17 11:43:13 --> Input Class Initialized
DEBUG - 2011-04-17 11:43:13 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-17 11:43:13 --> Language Class Initialized
DEBUG - 2011-04-17 11:43:13 --> Loader Class Initialized
DEBUG - 2011-04-17 11:43:13 --> Controller Class Initialized
DEBUG - 2011-04-17 11:43:13 --> Model Class Initialized
DEBUG - 2011-04-17 11:43:13 --> Model Class Initialized
DEBUG - 2011-04-17 11:43:13 --> Model Class Initialized
DEBUG - 2011-04-17 11:43:13 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-17 11:43:13 --> Database Driver Class Initialized
DEBUG - 2011-04-17 11:43:13 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-17 11:43:13 --> Helper loaded: url_helper
DEBUG - 2011-04-17 11:43:13 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-17 11:43:13 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-17 11:43:13 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-17 11:43:13 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-17 11:43:13 --> Final output sent to browser
DEBUG - 2011-04-17 11:43:13 --> Total execution time: 0.4067
DEBUG - 2011-04-17 11:43:15 --> Config Class Initialized
DEBUG - 2011-04-17 11:43:15 --> Hooks Class Initialized
DEBUG - 2011-04-17 11:43:15 --> Utf8 Class Initialized
DEBUG - 2011-04-17 11:43:15 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 11:43:15 --> URI Class Initialized
DEBUG - 2011-04-17 11:43:15 --> Router Class Initialized
DEBUG - 2011-04-17 11:43:15 --> Output Class Initialized
DEBUG - 2011-04-17 11:43:15 --> Input Class Initialized
DEBUG - 2011-04-17 11:43:15 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-17 11:43:15 --> Language Class Initialized
DEBUG - 2011-04-17 11:43:15 --> Loader Class Initialized
DEBUG - 2011-04-17 11:43:15 --> Controller Class Initialized
DEBUG - 2011-04-17 11:43:15 --> Model Class Initialized
DEBUG - 2011-04-17 11:43:15 --> Model Class Initialized
DEBUG - 2011-04-17 11:43:15 --> Model Class Initialized
DEBUG - 2011-04-17 11:43:15 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-17 11:43:15 --> Database Driver Class Initialized
DEBUG - 2011-04-17 11:43:15 --> Config Class Initialized
DEBUG - 2011-04-17 11:43:15 --> Hooks Class Initialized
DEBUG - 2011-04-17 11:43:15 --> Utf8 Class Initialized
DEBUG - 2011-04-17 11:43:15 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 11:43:15 --> URI Class Initialized
DEBUG - 2011-04-17 11:43:15 --> Router Class Initialized
ERROR - 2011-04-17 11:43:15 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-17 11:43:15 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-17 11:43:15 --> Helper loaded: url_helper
DEBUG - 2011-04-17 11:43:15 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-17 11:43:15 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-17 11:43:15 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-17 11:43:15 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-17 11:43:15 --> Final output sent to browser
DEBUG - 2011-04-17 11:43:15 --> Total execution time: 0.2228
DEBUG - 2011-04-17 11:43:42 --> Config Class Initialized
DEBUG - 2011-04-17 11:43:42 --> Hooks Class Initialized
DEBUG - 2011-04-17 11:43:42 --> Utf8 Class Initialized
DEBUG - 2011-04-17 11:43:42 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 11:43:42 --> URI Class Initialized
DEBUG - 2011-04-17 11:43:42 --> Router Class Initialized
DEBUG - 2011-04-17 11:43:42 --> Output Class Initialized
DEBUG - 2011-04-17 11:43:42 --> Input Class Initialized
DEBUG - 2011-04-17 11:43:42 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-17 11:43:42 --> Language Class Initialized
DEBUG - 2011-04-17 11:43:42 --> Loader Class Initialized
DEBUG - 2011-04-17 11:43:42 --> Controller Class Initialized
DEBUG - 2011-04-17 11:43:42 --> Model Class Initialized
DEBUG - 2011-04-17 11:43:42 --> Model Class Initialized
DEBUG - 2011-04-17 11:43:42 --> Model Class Initialized
DEBUG - 2011-04-17 11:43:42 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-17 11:43:42 --> Database Driver Class Initialized
DEBUG - 2011-04-17 11:43:42 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-17 11:43:42 --> Helper loaded: url_helper
DEBUG - 2011-04-17 11:43:42 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-17 11:43:42 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-17 11:43:42 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-17 11:43:42 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-17 11:43:42 --> Final output sent to browser
DEBUG - 2011-04-17 11:43:42 --> Total execution time: 0.3470
DEBUG - 2011-04-17 11:43:45 --> Config Class Initialized
DEBUG - 2011-04-17 11:43:45 --> Hooks Class Initialized
DEBUG - 2011-04-17 11:43:45 --> Utf8 Class Initialized
DEBUG - 2011-04-17 11:43:45 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 11:43:45 --> URI Class Initialized
DEBUG - 2011-04-17 11:43:45 --> Router Class Initialized
DEBUG - 2011-04-17 11:43:45 --> Output Class Initialized
DEBUG - 2011-04-17 11:43:45 --> Input Class Initialized
DEBUG - 2011-04-17 11:43:45 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-17 11:43:45 --> Language Class Initialized
DEBUG - 2011-04-17 11:43:45 --> Loader Class Initialized
DEBUG - 2011-04-17 11:43:45 --> Controller Class Initialized
DEBUG - 2011-04-17 11:43:45 --> Model Class Initialized
DEBUG - 2011-04-17 11:43:45 --> Model Class Initialized
DEBUG - 2011-04-17 11:43:45 --> Model Class Initialized
DEBUG - 2011-04-17 11:43:45 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-17 11:43:45 --> Database Driver Class Initialized
DEBUG - 2011-04-17 11:43:45 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-17 11:43:45 --> Helper loaded: url_helper
DEBUG - 2011-04-17 11:43:45 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-17 11:43:45 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-17 11:43:45 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-17 11:43:45 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-17 11:43:45 --> Final output sent to browser
DEBUG - 2011-04-17 11:43:45 --> Total execution time: 0.0918
DEBUG - 2011-04-17 11:43:45 --> Config Class Initialized
DEBUG - 2011-04-17 11:43:45 --> Hooks Class Initialized
DEBUG - 2011-04-17 11:43:45 --> Utf8 Class Initialized
DEBUG - 2011-04-17 11:43:45 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 11:43:45 --> URI Class Initialized
DEBUG - 2011-04-17 11:43:45 --> Router Class Initialized
ERROR - 2011-04-17 11:43:45 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-17 11:44:22 --> Config Class Initialized
DEBUG - 2011-04-17 11:44:22 --> Hooks Class Initialized
DEBUG - 2011-04-17 11:44:22 --> Utf8 Class Initialized
DEBUG - 2011-04-17 11:44:22 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 11:44:22 --> URI Class Initialized
DEBUG - 2011-04-17 11:44:22 --> Router Class Initialized
DEBUG - 2011-04-17 11:44:22 --> Output Class Initialized
DEBUG - 2011-04-17 11:44:22 --> Input Class Initialized
DEBUG - 2011-04-17 11:44:22 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-17 11:44:22 --> Language Class Initialized
DEBUG - 2011-04-17 11:44:22 --> Loader Class Initialized
DEBUG - 2011-04-17 11:44:22 --> Controller Class Initialized
DEBUG - 2011-04-17 11:44:22 --> Model Class Initialized
DEBUG - 2011-04-17 11:44:22 --> Model Class Initialized
DEBUG - 2011-04-17 11:44:22 --> Model Class Initialized
DEBUG - 2011-04-17 11:44:22 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-17 11:44:22 --> Database Driver Class Initialized
DEBUG - 2011-04-17 11:44:22 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-17 11:44:22 --> Helper loaded: url_helper
DEBUG - 2011-04-17 11:44:22 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-17 11:44:22 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-17 11:44:22 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-17 11:44:22 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-17 11:44:22 --> Final output sent to browser
DEBUG - 2011-04-17 11:44:22 --> Total execution time: 0.4455
DEBUG - 2011-04-17 11:44:25 --> Config Class Initialized
DEBUG - 2011-04-17 11:44:25 --> Hooks Class Initialized
DEBUG - 2011-04-17 11:44:25 --> Utf8 Class Initialized
DEBUG - 2011-04-17 11:44:25 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 11:44:25 --> URI Class Initialized
DEBUG - 2011-04-17 11:44:25 --> Router Class Initialized
DEBUG - 2011-04-17 11:44:25 --> Output Class Initialized
DEBUG - 2011-04-17 11:44:25 --> Input Class Initialized
DEBUG - 2011-04-17 11:44:25 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-17 11:44:25 --> Language Class Initialized
DEBUG - 2011-04-17 11:44:25 --> Loader Class Initialized
DEBUG - 2011-04-17 11:44:25 --> Controller Class Initialized
DEBUG - 2011-04-17 11:44:25 --> Model Class Initialized
DEBUG - 2011-04-17 11:44:25 --> Model Class Initialized
DEBUG - 2011-04-17 11:44:25 --> Model Class Initialized
DEBUG - 2011-04-17 11:44:25 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-17 11:44:25 --> Database Driver Class Initialized
DEBUG - 2011-04-17 11:44:25 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-17 11:44:25 --> Helper loaded: url_helper
DEBUG - 2011-04-17 11:44:25 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-17 11:44:25 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-17 11:44:25 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-17 11:44:25 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-17 11:44:25 --> Final output sent to browser
DEBUG - 2011-04-17 11:44:25 --> Total execution time: 0.1832
DEBUG - 2011-04-17 11:44:25 --> Config Class Initialized
DEBUG - 2011-04-17 11:44:25 --> Hooks Class Initialized
DEBUG - 2011-04-17 11:44:25 --> Utf8 Class Initialized
DEBUG - 2011-04-17 11:44:25 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 11:44:25 --> URI Class Initialized
DEBUG - 2011-04-17 11:44:25 --> Router Class Initialized
DEBUG - 2011-04-17 11:44:25 --> Output Class Initialized
DEBUG - 2011-04-17 11:44:25 --> Input Class Initialized
DEBUG - 2011-04-17 11:44:25 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-17 11:44:25 --> Language Class Initialized
DEBUG - 2011-04-17 11:44:25 --> Loader Class Initialized
DEBUG - 2011-04-17 11:44:25 --> Controller Class Initialized
DEBUG - 2011-04-17 11:44:25 --> Model Class Initialized
DEBUG - 2011-04-17 11:44:25 --> Model Class Initialized
DEBUG - 2011-04-17 11:44:25 --> Model Class Initialized
DEBUG - 2011-04-17 11:44:25 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-17 11:44:25 --> Database Driver Class Initialized
DEBUG - 2011-04-17 11:44:25 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-17 11:44:25 --> Helper loaded: url_helper
DEBUG - 2011-04-17 11:44:25 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-17 11:44:25 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-17 11:44:25 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-17 11:44:25 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-17 11:44:25 --> Final output sent to browser
DEBUG - 2011-04-17 11:44:25 --> Total execution time: 0.1017
DEBUG - 2011-04-17 11:44:25 --> Config Class Initialized
DEBUG - 2011-04-17 11:44:25 --> Hooks Class Initialized
DEBUG - 2011-04-17 11:44:25 --> Utf8 Class Initialized
DEBUG - 2011-04-17 11:44:25 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 11:44:25 --> URI Class Initialized
DEBUG - 2011-04-17 11:44:25 --> Router Class Initialized
ERROR - 2011-04-17 11:44:25 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-17 11:44:47 --> Config Class Initialized
DEBUG - 2011-04-17 11:44:47 --> Hooks Class Initialized
DEBUG - 2011-04-17 11:44:47 --> Utf8 Class Initialized
DEBUG - 2011-04-17 11:44:47 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 11:44:47 --> URI Class Initialized
DEBUG - 2011-04-17 11:44:47 --> Router Class Initialized
DEBUG - 2011-04-17 11:44:47 --> Output Class Initialized
DEBUG - 2011-04-17 11:44:47 --> Input Class Initialized
DEBUG - 2011-04-17 11:44:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-17 11:44:47 --> Language Class Initialized
DEBUG - 2011-04-17 11:44:47 --> Loader Class Initialized
DEBUG - 2011-04-17 11:44:47 --> Controller Class Initialized
DEBUG - 2011-04-17 11:44:47 --> Model Class Initialized
DEBUG - 2011-04-17 11:44:47 --> Model Class Initialized
DEBUG - 2011-04-17 11:44:47 --> Model Class Initialized
DEBUG - 2011-04-17 11:44:47 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-17 11:44:47 --> Database Driver Class Initialized
DEBUG - 2011-04-17 11:44:47 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-17 11:44:47 --> Helper loaded: url_helper
DEBUG - 2011-04-17 11:44:47 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-17 11:44:47 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-17 11:44:47 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-17 11:44:47 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-17 11:44:47 --> Final output sent to browser
DEBUG - 2011-04-17 11:44:47 --> Total execution time: 0.2198
DEBUG - 2011-04-17 11:44:49 --> Config Class Initialized
DEBUG - 2011-04-17 11:44:49 --> Hooks Class Initialized
DEBUG - 2011-04-17 11:44:49 --> Utf8 Class Initialized
DEBUG - 2011-04-17 11:44:49 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 11:44:49 --> URI Class Initialized
DEBUG - 2011-04-17 11:44:49 --> Router Class Initialized
DEBUG - 2011-04-17 11:44:49 --> Output Class Initialized
DEBUG - 2011-04-17 11:44:49 --> Input Class Initialized
DEBUG - 2011-04-17 11:44:49 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-17 11:44:49 --> Language Class Initialized
DEBUG - 2011-04-17 11:44:49 --> Loader Class Initialized
DEBUG - 2011-04-17 11:44:49 --> Controller Class Initialized
DEBUG - 2011-04-17 11:44:49 --> Model Class Initialized
DEBUG - 2011-04-17 11:44:49 --> Model Class Initialized
DEBUG - 2011-04-17 11:44:49 --> Model Class Initialized
DEBUG - 2011-04-17 11:44:49 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-17 11:44:49 --> Database Driver Class Initialized
DEBUG - 2011-04-17 11:44:50 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-17 11:44:50 --> Helper loaded: url_helper
DEBUG - 2011-04-17 11:44:50 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-17 11:44:50 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-17 11:44:50 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-17 11:44:50 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-17 11:44:50 --> Final output sent to browser
DEBUG - 2011-04-17 11:44:50 --> Total execution time: 0.1092
DEBUG - 2011-04-17 11:44:50 --> Config Class Initialized
DEBUG - 2011-04-17 11:44:50 --> Hooks Class Initialized
DEBUG - 2011-04-17 11:44:50 --> Utf8 Class Initialized
DEBUG - 2011-04-17 11:44:50 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 11:44:50 --> URI Class Initialized
DEBUG - 2011-04-17 11:44:50 --> Router Class Initialized
DEBUG - 2011-04-17 11:44:50 --> Output Class Initialized
DEBUG - 2011-04-17 11:44:50 --> Input Class Initialized
DEBUG - 2011-04-17 11:44:50 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-17 11:44:50 --> Language Class Initialized
DEBUG - 2011-04-17 11:44:50 --> Loader Class Initialized
DEBUG - 2011-04-17 11:44:50 --> Controller Class Initialized
DEBUG - 2011-04-17 11:44:50 --> Model Class Initialized
DEBUG - 2011-04-17 11:44:50 --> Model Class Initialized
DEBUG - 2011-04-17 11:44:50 --> Model Class Initialized
DEBUG - 2011-04-17 11:44:50 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-17 11:44:50 --> Database Driver Class Initialized
DEBUG - 2011-04-17 11:44:50 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-17 11:44:50 --> Helper loaded: url_helper
DEBUG - 2011-04-17 11:44:50 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-17 11:44:50 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-17 11:44:50 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-17 11:44:50 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-17 11:44:50 --> Final output sent to browser
DEBUG - 2011-04-17 11:44:50 --> Total execution time: 0.0458
DEBUG - 2011-04-17 11:44:50 --> Config Class Initialized
DEBUG - 2011-04-17 11:44:50 --> Hooks Class Initialized
DEBUG - 2011-04-17 11:44:50 --> Utf8 Class Initialized
DEBUG - 2011-04-17 11:44:50 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 11:44:50 --> URI Class Initialized
DEBUG - 2011-04-17 11:44:50 --> Router Class Initialized
ERROR - 2011-04-17 11:44:50 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-17 11:45:09 --> Config Class Initialized
DEBUG - 2011-04-17 11:45:09 --> Hooks Class Initialized
DEBUG - 2011-04-17 11:45:09 --> Utf8 Class Initialized
DEBUG - 2011-04-17 11:45:09 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 11:45:09 --> URI Class Initialized
DEBUG - 2011-04-17 11:45:09 --> Router Class Initialized
DEBUG - 2011-04-17 11:45:09 --> Output Class Initialized
DEBUG - 2011-04-17 11:45:09 --> Input Class Initialized
DEBUG - 2011-04-17 11:45:09 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-17 11:45:09 --> Language Class Initialized
DEBUG - 2011-04-17 11:45:09 --> Loader Class Initialized
DEBUG - 2011-04-17 11:45:09 --> Controller Class Initialized
DEBUG - 2011-04-17 11:45:09 --> Model Class Initialized
DEBUG - 2011-04-17 11:45:09 --> Model Class Initialized
DEBUG - 2011-04-17 11:45:09 --> Model Class Initialized
DEBUG - 2011-04-17 11:45:09 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-17 11:45:09 --> Database Driver Class Initialized
DEBUG - 2011-04-17 11:45:11 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-17 11:45:11 --> Helper loaded: url_helper
DEBUG - 2011-04-17 11:45:11 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-17 11:45:11 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-17 11:45:11 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-17 11:45:11 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-17 11:45:11 --> Final output sent to browser
DEBUG - 2011-04-17 11:45:11 --> Total execution time: 1.5742
DEBUG - 2011-04-17 11:45:13 --> Config Class Initialized
DEBUG - 2011-04-17 11:45:13 --> Hooks Class Initialized
DEBUG - 2011-04-17 11:45:13 --> Utf8 Class Initialized
DEBUG - 2011-04-17 11:45:13 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 11:45:13 --> URI Class Initialized
DEBUG - 2011-04-17 11:45:13 --> Router Class Initialized
DEBUG - 2011-04-17 11:45:13 --> Output Class Initialized
DEBUG - 2011-04-17 11:45:13 --> Input Class Initialized
DEBUG - 2011-04-17 11:45:13 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-17 11:45:13 --> Language Class Initialized
DEBUG - 2011-04-17 11:45:13 --> Loader Class Initialized
DEBUG - 2011-04-17 11:45:13 --> Controller Class Initialized
DEBUG - 2011-04-17 11:45:13 --> Model Class Initialized
DEBUG - 2011-04-17 11:45:13 --> Model Class Initialized
DEBUG - 2011-04-17 11:45:13 --> Model Class Initialized
DEBUG - 2011-04-17 11:45:13 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-17 11:45:13 --> Database Driver Class Initialized
DEBUG - 2011-04-17 11:45:13 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-17 11:45:13 --> Helper loaded: url_helper
DEBUG - 2011-04-17 11:45:13 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-17 11:45:13 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-17 11:45:13 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-17 11:45:13 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-17 11:45:13 --> Final output sent to browser
DEBUG - 2011-04-17 11:45:13 --> Total execution time: 0.0720
DEBUG - 2011-04-17 11:45:14 --> Config Class Initialized
DEBUG - 2011-04-17 11:45:14 --> Hooks Class Initialized
DEBUG - 2011-04-17 11:45:14 --> Utf8 Class Initialized
DEBUG - 2011-04-17 11:45:14 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 11:45:14 --> URI Class Initialized
DEBUG - 2011-04-17 11:45:14 --> Router Class Initialized
ERROR - 2011-04-17 11:45:14 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-17 11:45:27 --> Config Class Initialized
DEBUG - 2011-04-17 11:45:27 --> Hooks Class Initialized
DEBUG - 2011-04-17 11:45:27 --> Utf8 Class Initialized
DEBUG - 2011-04-17 11:45:27 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 11:45:27 --> URI Class Initialized
DEBUG - 2011-04-17 11:45:27 --> Router Class Initialized
DEBUG - 2011-04-17 11:45:27 --> Output Class Initialized
DEBUG - 2011-04-17 11:45:27 --> Input Class Initialized
DEBUG - 2011-04-17 11:45:27 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-17 11:45:27 --> Language Class Initialized
DEBUG - 2011-04-17 11:45:27 --> Loader Class Initialized
DEBUG - 2011-04-17 11:45:27 --> Controller Class Initialized
DEBUG - 2011-04-17 11:45:27 --> Model Class Initialized
DEBUG - 2011-04-17 11:45:27 --> Model Class Initialized
DEBUG - 2011-04-17 11:45:27 --> Model Class Initialized
DEBUG - 2011-04-17 11:45:27 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-17 11:45:27 --> Database Driver Class Initialized
DEBUG - 2011-04-17 11:45:28 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-17 11:45:28 --> Helper loaded: url_helper
DEBUG - 2011-04-17 11:45:28 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-17 11:45:28 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-17 11:45:28 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-17 11:45:28 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-17 11:45:28 --> Final output sent to browser
DEBUG - 2011-04-17 11:45:28 --> Total execution time: 0.7108
DEBUG - 2011-04-17 11:45:30 --> Config Class Initialized
DEBUG - 2011-04-17 11:45:30 --> Hooks Class Initialized
DEBUG - 2011-04-17 11:45:30 --> Utf8 Class Initialized
DEBUG - 2011-04-17 11:45:30 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 11:45:30 --> URI Class Initialized
DEBUG - 2011-04-17 11:45:30 --> Router Class Initialized
ERROR - 2011-04-17 11:45:30 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-17 11:45:31 --> Config Class Initialized
DEBUG - 2011-04-17 11:45:31 --> Hooks Class Initialized
DEBUG - 2011-04-17 11:45:31 --> Utf8 Class Initialized
DEBUG - 2011-04-17 11:45:31 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 11:45:31 --> URI Class Initialized
DEBUG - 2011-04-17 11:45:31 --> Router Class Initialized
DEBUG - 2011-04-17 11:45:31 --> Output Class Initialized
DEBUG - 2011-04-17 11:45:31 --> Input Class Initialized
DEBUG - 2011-04-17 11:45:31 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-17 11:45:31 --> Language Class Initialized
DEBUG - 2011-04-17 11:45:31 --> Loader Class Initialized
DEBUG - 2011-04-17 11:45:31 --> Controller Class Initialized
DEBUG - 2011-04-17 11:45:31 --> Model Class Initialized
DEBUG - 2011-04-17 11:45:31 --> Model Class Initialized
DEBUG - 2011-04-17 11:45:31 --> Model Class Initialized
DEBUG - 2011-04-17 11:45:31 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-17 11:45:31 --> Database Driver Class Initialized
DEBUG - 2011-04-17 11:45:32 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-17 11:45:32 --> Helper loaded: url_helper
DEBUG - 2011-04-17 11:45:32 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-17 11:45:32 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-17 11:45:32 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-17 11:45:32 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-17 11:45:32 --> Final output sent to browser
DEBUG - 2011-04-17 11:45:32 --> Total execution time: 1.0261
DEBUG - 2011-04-17 11:45:43 --> Config Class Initialized
DEBUG - 2011-04-17 11:45:43 --> Hooks Class Initialized
DEBUG - 2011-04-17 11:45:43 --> Utf8 Class Initialized
DEBUG - 2011-04-17 11:45:43 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 11:45:43 --> URI Class Initialized
DEBUG - 2011-04-17 11:45:43 --> Router Class Initialized
DEBUG - 2011-04-17 11:45:43 --> Output Class Initialized
DEBUG - 2011-04-17 11:45:43 --> Input Class Initialized
DEBUG - 2011-04-17 11:45:43 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-17 11:45:43 --> Language Class Initialized
DEBUG - 2011-04-17 11:45:43 --> Loader Class Initialized
DEBUG - 2011-04-17 11:45:43 --> Controller Class Initialized
DEBUG - 2011-04-17 11:45:43 --> Model Class Initialized
DEBUG - 2011-04-17 11:45:43 --> Model Class Initialized
DEBUG - 2011-04-17 11:45:43 --> Model Class Initialized
DEBUG - 2011-04-17 11:45:43 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-17 11:45:43 --> Database Driver Class Initialized
DEBUG - 2011-04-17 11:45:43 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-17 11:45:43 --> Helper loaded: url_helper
DEBUG - 2011-04-17 11:45:43 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-17 11:45:43 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-17 11:45:43 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-17 11:45:43 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-17 11:45:43 --> Final output sent to browser
DEBUG - 2011-04-17 11:45:43 --> Total execution time: 0.5036
DEBUG - 2011-04-17 11:45:46 --> Config Class Initialized
DEBUG - 2011-04-17 11:45:46 --> Hooks Class Initialized
DEBUG - 2011-04-17 11:45:46 --> Utf8 Class Initialized
DEBUG - 2011-04-17 11:45:46 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 11:45:46 --> URI Class Initialized
DEBUG - 2011-04-17 11:45:46 --> Router Class Initialized
DEBUG - 2011-04-17 11:45:46 --> Output Class Initialized
DEBUG - 2011-04-17 11:45:46 --> Input Class Initialized
DEBUG - 2011-04-17 11:45:46 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-17 11:45:46 --> Language Class Initialized
DEBUG - 2011-04-17 11:45:46 --> Loader Class Initialized
DEBUG - 2011-04-17 11:45:46 --> Controller Class Initialized
DEBUG - 2011-04-17 11:45:46 --> Model Class Initialized
DEBUG - 2011-04-17 11:45:46 --> Model Class Initialized
DEBUG - 2011-04-17 11:45:46 --> Model Class Initialized
DEBUG - 2011-04-17 11:45:46 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-17 11:45:46 --> Database Driver Class Initialized
DEBUG - 2011-04-17 11:45:46 --> Config Class Initialized
DEBUG - 2011-04-17 11:45:46 --> Hooks Class Initialized
DEBUG - 2011-04-17 11:45:46 --> Utf8 Class Initialized
DEBUG - 2011-04-17 11:45:46 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 11:45:46 --> URI Class Initialized
DEBUG - 2011-04-17 11:45:46 --> Router Class Initialized
ERROR - 2011-04-17 11:45:46 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-17 11:45:46 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-17 11:45:46 --> Helper loaded: url_helper
DEBUG - 2011-04-17 11:45:46 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-17 11:45:46 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-17 11:45:46 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-17 11:45:46 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-17 11:45:46 --> Final output sent to browser
DEBUG - 2011-04-17 11:45:46 --> Total execution time: 0.3118
DEBUG - 2011-04-17 11:45:58 --> Config Class Initialized
DEBUG - 2011-04-17 11:45:58 --> Hooks Class Initialized
DEBUG - 2011-04-17 11:45:58 --> Utf8 Class Initialized
DEBUG - 2011-04-17 11:45:58 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 11:45:58 --> URI Class Initialized
DEBUG - 2011-04-17 11:45:58 --> Router Class Initialized
DEBUG - 2011-04-17 11:45:58 --> Output Class Initialized
DEBUG - 2011-04-17 11:45:58 --> Input Class Initialized
DEBUG - 2011-04-17 11:45:58 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-17 11:45:58 --> Language Class Initialized
DEBUG - 2011-04-17 11:45:58 --> Loader Class Initialized
DEBUG - 2011-04-17 11:45:58 --> Controller Class Initialized
DEBUG - 2011-04-17 11:45:58 --> Model Class Initialized
DEBUG - 2011-04-17 11:45:58 --> Model Class Initialized
DEBUG - 2011-04-17 11:45:58 --> Model Class Initialized
DEBUG - 2011-04-17 11:45:58 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-17 11:45:58 --> Database Driver Class Initialized
DEBUG - 2011-04-17 11:45:58 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-17 11:45:58 --> Helper loaded: url_helper
DEBUG - 2011-04-17 11:45:58 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-17 11:45:58 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-17 11:45:58 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-17 11:45:58 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-17 11:45:58 --> Final output sent to browser
DEBUG - 2011-04-17 11:45:58 --> Total execution time: 0.5598
DEBUG - 2011-04-17 11:46:00 --> Config Class Initialized
DEBUG - 2011-04-17 11:46:00 --> Hooks Class Initialized
DEBUG - 2011-04-17 11:46:00 --> Utf8 Class Initialized
DEBUG - 2011-04-17 11:46:00 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 11:46:00 --> URI Class Initialized
DEBUG - 2011-04-17 11:46:00 --> Router Class Initialized
DEBUG - 2011-04-17 11:46:00 --> Output Class Initialized
DEBUG - 2011-04-17 11:46:00 --> Input Class Initialized
DEBUG - 2011-04-17 11:46:00 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-17 11:46:00 --> Language Class Initialized
DEBUG - 2011-04-17 11:46:00 --> Loader Class Initialized
DEBUG - 2011-04-17 11:46:00 --> Controller Class Initialized
DEBUG - 2011-04-17 11:46:00 --> Model Class Initialized
DEBUG - 2011-04-17 11:46:00 --> Model Class Initialized
DEBUG - 2011-04-17 11:46:00 --> Model Class Initialized
DEBUG - 2011-04-17 11:46:00 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-17 11:46:00 --> Database Driver Class Initialized
DEBUG - 2011-04-17 11:46:01 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-17 11:46:01 --> Helper loaded: url_helper
DEBUG - 2011-04-17 11:46:01 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-17 11:46:01 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-17 11:46:01 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-17 11:46:01 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-17 11:46:01 --> Final output sent to browser
DEBUG - 2011-04-17 11:46:01 --> Total execution time: 0.5109
DEBUG - 2011-04-17 11:46:02 --> Config Class Initialized
DEBUG - 2011-04-17 11:46:02 --> Hooks Class Initialized
DEBUG - 2011-04-17 11:46:02 --> Utf8 Class Initialized
DEBUG - 2011-04-17 11:46:02 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 11:46:02 --> URI Class Initialized
DEBUG - 2011-04-17 11:46:02 --> Router Class Initialized
ERROR - 2011-04-17 11:46:02 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-17 11:46:13 --> Config Class Initialized
DEBUG - 2011-04-17 11:46:13 --> Hooks Class Initialized
DEBUG - 2011-04-17 11:46:13 --> Utf8 Class Initialized
DEBUG - 2011-04-17 11:46:13 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 11:46:13 --> URI Class Initialized
DEBUG - 2011-04-17 11:46:13 --> Router Class Initialized
DEBUG - 2011-04-17 11:46:13 --> Output Class Initialized
DEBUG - 2011-04-17 11:46:13 --> Input Class Initialized
DEBUG - 2011-04-17 11:46:13 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-17 11:46:13 --> Language Class Initialized
DEBUG - 2011-04-17 11:46:13 --> Loader Class Initialized
DEBUG - 2011-04-17 11:46:13 --> Controller Class Initialized
DEBUG - 2011-04-17 11:46:13 --> Model Class Initialized
DEBUG - 2011-04-17 11:46:13 --> Model Class Initialized
DEBUG - 2011-04-17 11:46:13 --> Model Class Initialized
DEBUG - 2011-04-17 11:46:13 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-17 11:46:13 --> Database Driver Class Initialized
DEBUG - 2011-04-17 11:46:13 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-17 11:46:13 --> Helper loaded: url_helper
DEBUG - 2011-04-17 11:46:13 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-17 11:46:13 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-17 11:46:13 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-17 11:46:13 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-17 11:46:13 --> Final output sent to browser
DEBUG - 2011-04-17 11:46:13 --> Total execution time: 0.4217
DEBUG - 2011-04-17 11:46:16 --> Config Class Initialized
DEBUG - 2011-04-17 11:46:16 --> Hooks Class Initialized
DEBUG - 2011-04-17 11:46:16 --> Utf8 Class Initialized
DEBUG - 2011-04-17 11:46:16 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 11:46:16 --> Config Class Initialized
DEBUG - 2011-04-17 11:46:16 --> Hooks Class Initialized
DEBUG - 2011-04-17 11:46:16 --> Utf8 Class Initialized
DEBUG - 2011-04-17 11:46:16 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 11:46:16 --> URI Class Initialized
DEBUG - 2011-04-17 11:46:16 --> Router Class Initialized
DEBUG - 2011-04-17 11:46:16 --> Output Class Initialized
DEBUG - 2011-04-17 11:46:16 --> Input Class Initialized
DEBUG - 2011-04-17 11:46:16 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-17 11:46:16 --> Language Class Initialized
DEBUG - 2011-04-17 11:46:16 --> URI Class Initialized
DEBUG - 2011-04-17 11:46:16 --> Router Class Initialized
ERROR - 2011-04-17 11:46:16 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-17 11:46:16 --> Loader Class Initialized
DEBUG - 2011-04-17 11:46:16 --> Controller Class Initialized
DEBUG - 2011-04-17 11:46:16 --> Model Class Initialized
DEBUG - 2011-04-17 11:46:16 --> Model Class Initialized
DEBUG - 2011-04-17 11:46:16 --> Model Class Initialized
DEBUG - 2011-04-17 11:46:16 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-17 11:46:16 --> Database Driver Class Initialized
DEBUG - 2011-04-17 11:46:17 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-17 11:46:17 --> Helper loaded: url_helper
DEBUG - 2011-04-17 11:46:17 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-17 11:46:17 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-17 11:46:17 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-17 11:46:17 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-17 11:46:17 --> Final output sent to browser
DEBUG - 2011-04-17 11:46:17 --> Total execution time: 0.6974
DEBUG - 2011-04-17 11:46:21 --> Config Class Initialized
DEBUG - 2011-04-17 11:46:21 --> Hooks Class Initialized
DEBUG - 2011-04-17 11:46:21 --> Utf8 Class Initialized
DEBUG - 2011-04-17 11:46:21 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 11:46:21 --> URI Class Initialized
DEBUG - 2011-04-17 11:46:21 --> Router Class Initialized
DEBUG - 2011-04-17 11:46:21 --> Output Class Initialized
DEBUG - 2011-04-17 11:46:21 --> Input Class Initialized
DEBUG - 2011-04-17 11:46:21 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-17 11:46:21 --> Language Class Initialized
DEBUG - 2011-04-17 11:46:21 --> Loader Class Initialized
DEBUG - 2011-04-17 11:46:21 --> Controller Class Initialized
DEBUG - 2011-04-17 11:46:21 --> Model Class Initialized
DEBUG - 2011-04-17 11:46:21 --> Model Class Initialized
DEBUG - 2011-04-17 11:46:21 --> Model Class Initialized
DEBUG - 2011-04-17 11:46:21 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-17 11:46:21 --> Database Driver Class Initialized
DEBUG - 2011-04-17 11:46:22 --> Config Class Initialized
DEBUG - 2011-04-17 11:46:22 --> Hooks Class Initialized
DEBUG - 2011-04-17 11:46:22 --> Utf8 Class Initialized
DEBUG - 2011-04-17 11:46:22 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 11:46:22 --> URI Class Initialized
DEBUG - 2011-04-17 11:46:22 --> Router Class Initialized
DEBUG - 2011-04-17 11:46:22 --> Output Class Initialized
DEBUG - 2011-04-17 11:46:22 --> Input Class Initialized
DEBUG - 2011-04-17 11:46:22 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-17 11:46:22 --> Language Class Initialized
DEBUG - 2011-04-17 11:46:22 --> Loader Class Initialized
DEBUG - 2011-04-17 11:46:22 --> Controller Class Initialized
DEBUG - 2011-04-17 11:46:22 --> Model Class Initialized
DEBUG - 2011-04-17 11:46:22 --> Model Class Initialized
DEBUG - 2011-04-17 11:46:22 --> Model Class Initialized
DEBUG - 2011-04-17 11:46:22 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-17 11:46:22 --> Database Driver Class Initialized
DEBUG - 2011-04-17 11:46:22 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-17 11:46:22 --> Helper loaded: url_helper
DEBUG - 2011-04-17 11:46:22 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-17 11:46:22 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-17 11:46:22 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-17 11:46:22 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-17 11:46:22 --> Final output sent to browser
DEBUG - 2011-04-17 11:46:22 --> Total execution time: 0.1162
DEBUG - 2011-04-17 11:46:22 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-17 11:46:22 --> Helper loaded: url_helper
DEBUG - 2011-04-17 11:46:22 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-17 11:46:22 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-17 11:46:22 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-17 11:46:22 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-17 11:46:22 --> Final output sent to browser
DEBUG - 2011-04-17 11:46:22 --> Total execution time: 0.7062
DEBUG - 2011-04-17 11:46:25 --> Config Class Initialized
DEBUG - 2011-04-17 11:46:25 --> Hooks Class Initialized
DEBUG - 2011-04-17 11:46:25 --> Utf8 Class Initialized
DEBUG - 2011-04-17 11:46:25 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 11:46:25 --> URI Class Initialized
DEBUG - 2011-04-17 11:46:25 --> Router Class Initialized
ERROR - 2011-04-17 11:46:25 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-17 11:46:26 --> Config Class Initialized
DEBUG - 2011-04-17 11:46:26 --> Hooks Class Initialized
DEBUG - 2011-04-17 11:46:26 --> Utf8 Class Initialized
DEBUG - 2011-04-17 11:46:26 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 11:46:26 --> URI Class Initialized
DEBUG - 2011-04-17 11:46:26 --> Router Class Initialized
DEBUG - 2011-04-17 11:46:26 --> Output Class Initialized
DEBUG - 2011-04-17 11:46:27 --> Input Class Initialized
DEBUG - 2011-04-17 11:46:27 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-17 11:46:27 --> Language Class Initialized
DEBUG - 2011-04-17 11:46:27 --> Loader Class Initialized
DEBUG - 2011-04-17 11:46:27 --> Controller Class Initialized
DEBUG - 2011-04-17 11:46:27 --> Model Class Initialized
DEBUG - 2011-04-17 11:46:27 --> Model Class Initialized
DEBUG - 2011-04-17 11:46:27 --> Model Class Initialized
DEBUG - 2011-04-17 11:46:27 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-17 11:46:27 --> Database Driver Class Initialized
DEBUG - 2011-04-17 11:46:27 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-17 11:46:27 --> Helper loaded: url_helper
DEBUG - 2011-04-17 11:46:27 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-17 11:46:27 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-17 11:46:27 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-17 11:46:27 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-17 11:46:27 --> Final output sent to browser
DEBUG - 2011-04-17 11:46:27 --> Total execution time: 0.3258
DEBUG - 2011-04-17 11:46:45 --> Config Class Initialized
DEBUG - 2011-04-17 11:46:45 --> Hooks Class Initialized
DEBUG - 2011-04-17 11:46:45 --> Utf8 Class Initialized
DEBUG - 2011-04-17 11:46:45 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 11:46:45 --> URI Class Initialized
DEBUG - 2011-04-17 11:46:45 --> Router Class Initialized
DEBUG - 2011-04-17 11:46:45 --> No URI present. Default controller set.
DEBUG - 2011-04-17 11:46:45 --> Output Class Initialized
DEBUG - 2011-04-17 11:46:45 --> Input Class Initialized
DEBUG - 2011-04-17 11:46:45 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-17 11:46:45 --> Language Class Initialized
DEBUG - 2011-04-17 11:46:45 --> Loader Class Initialized
DEBUG - 2011-04-17 11:46:45 --> Controller Class Initialized
DEBUG - 2011-04-17 11:46:45 --> File loaded: application/views/splash/main.php
DEBUG - 2011-04-17 11:46:45 --> Helper loaded: url_helper
DEBUG - 2011-04-17 11:46:45 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-17 11:46:45 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-17 11:46:45 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-17 11:46:45 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-17 11:46:45 --> Final output sent to browser
DEBUG - 2011-04-17 11:46:45 --> Total execution time: 0.0130
DEBUG - 2011-04-17 11:46:48 --> Config Class Initialized
DEBUG - 2011-04-17 11:46:48 --> Hooks Class Initialized
DEBUG - 2011-04-17 11:46:48 --> Utf8 Class Initialized
DEBUG - 2011-04-17 11:46:48 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 11:46:48 --> URI Class Initialized
DEBUG - 2011-04-17 11:46:48 --> Router Class Initialized
ERROR - 2011-04-17 11:46:48 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-17 11:46:51 --> Config Class Initialized
DEBUG - 2011-04-17 11:46:51 --> Hooks Class Initialized
DEBUG - 2011-04-17 11:46:51 --> Utf8 Class Initialized
DEBUG - 2011-04-17 11:46:51 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 11:46:51 --> URI Class Initialized
DEBUG - 2011-04-17 11:46:51 --> Router Class Initialized
ERROR - 2011-04-17 11:46:51 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-17 11:50:52 --> Config Class Initialized
DEBUG - 2011-04-17 11:50:52 --> Hooks Class Initialized
DEBUG - 2011-04-17 11:50:52 --> Utf8 Class Initialized
DEBUG - 2011-04-17 11:50:52 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 11:50:52 --> URI Class Initialized
DEBUG - 2011-04-17 11:50:52 --> Router Class Initialized
DEBUG - 2011-04-17 11:50:52 --> No URI present. Default controller set.
DEBUG - 2011-04-17 11:50:52 --> Output Class Initialized
DEBUG - 2011-04-17 11:50:52 --> Input Class Initialized
DEBUG - 2011-04-17 11:50:52 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-17 11:50:52 --> Language Class Initialized
DEBUG - 2011-04-17 11:50:52 --> Loader Class Initialized
DEBUG - 2011-04-17 11:50:52 --> Controller Class Initialized
DEBUG - 2011-04-17 11:50:52 --> File loaded: application/views/splash/main.php
DEBUG - 2011-04-17 11:50:52 --> Helper loaded: url_helper
DEBUG - 2011-04-17 11:50:52 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-17 11:50:52 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-17 11:50:52 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-17 11:50:52 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-17 11:50:52 --> Final output sent to browser
DEBUG - 2011-04-17 11:50:52 --> Total execution time: 0.0231
DEBUG - 2011-04-17 11:50:55 --> Config Class Initialized
DEBUG - 2011-04-17 11:50:55 --> Hooks Class Initialized
DEBUG - 2011-04-17 11:50:55 --> Utf8 Class Initialized
DEBUG - 2011-04-17 11:50:55 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 11:50:55 --> URI Class Initialized
DEBUG - 2011-04-17 11:50:55 --> Router Class Initialized
ERROR - 2011-04-17 11:50:55 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-17 11:50:57 --> Config Class Initialized
DEBUG - 2011-04-17 11:50:57 --> Hooks Class Initialized
DEBUG - 2011-04-17 11:50:57 --> Utf8 Class Initialized
DEBUG - 2011-04-17 11:50:57 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 11:50:57 --> URI Class Initialized
DEBUG - 2011-04-17 11:50:57 --> Router Class Initialized
ERROR - 2011-04-17 11:50:57 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-17 11:51:02 --> Config Class Initialized
DEBUG - 2011-04-17 11:51:02 --> Hooks Class Initialized
DEBUG - 2011-04-17 11:51:02 --> Utf8 Class Initialized
DEBUG - 2011-04-17 11:51:02 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 11:51:02 --> URI Class Initialized
DEBUG - 2011-04-17 11:51:02 --> Router Class Initialized
DEBUG - 2011-04-17 11:51:02 --> Output Class Initialized
DEBUG - 2011-04-17 11:51:02 --> Input Class Initialized
DEBUG - 2011-04-17 11:51:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-17 11:51:02 --> Language Class Initialized
DEBUG - 2011-04-17 11:51:02 --> Loader Class Initialized
DEBUG - 2011-04-17 11:51:02 --> Controller Class Initialized
DEBUG - 2011-04-17 11:51:02 --> Model Class Initialized
DEBUG - 2011-04-17 11:51:02 --> Model Class Initialized
DEBUG - 2011-04-17 11:51:02 --> Model Class Initialized
DEBUG - 2011-04-17 11:51:02 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-17 11:51:02 --> Database Driver Class Initialized
DEBUG - 2011-04-17 11:51:02 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-17 11:51:02 --> Helper loaded: url_helper
DEBUG - 2011-04-17 11:51:02 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-17 11:51:02 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-17 11:51:02 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-17 11:51:02 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-17 11:51:02 --> Final output sent to browser
DEBUG - 2011-04-17 11:51:02 --> Total execution time: 0.0741
DEBUG - 2011-04-17 11:51:04 --> Config Class Initialized
DEBUG - 2011-04-17 11:51:04 --> Hooks Class Initialized
DEBUG - 2011-04-17 11:51:04 --> Utf8 Class Initialized
DEBUG - 2011-04-17 11:51:04 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 11:51:04 --> URI Class Initialized
DEBUG - 2011-04-17 11:51:04 --> Router Class Initialized
DEBUG - 2011-04-17 11:51:04 --> Output Class Initialized
DEBUG - 2011-04-17 11:51:04 --> Input Class Initialized
DEBUG - 2011-04-17 11:51:04 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-17 11:51:04 --> Language Class Initialized
DEBUG - 2011-04-17 11:51:04 --> Loader Class Initialized
DEBUG - 2011-04-17 11:51:04 --> Controller Class Initialized
ERROR - 2011-04-17 11:51:04 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-17 11:51:04 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-17 11:51:04 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-17 11:51:04 --> Model Class Initialized
DEBUG - 2011-04-17 11:51:04 --> Model Class Initialized
DEBUG - 2011-04-17 11:51:04 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-17 11:51:04 --> Database Driver Class Initialized
DEBUG - 2011-04-17 11:51:04 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-17 11:51:04 --> Helper loaded: url_helper
DEBUG - 2011-04-17 11:51:04 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-17 11:51:04 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-17 11:51:04 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-17 11:51:04 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-17 11:51:04 --> Final output sent to browser
DEBUG - 2011-04-17 11:51:04 --> Total execution time: 0.1051
DEBUG - 2011-04-17 11:51:05 --> Config Class Initialized
DEBUG - 2011-04-17 11:51:05 --> Hooks Class Initialized
DEBUG - 2011-04-17 11:51:05 --> Utf8 Class Initialized
DEBUG - 2011-04-17 11:51:05 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 11:51:05 --> URI Class Initialized
DEBUG - 2011-04-17 11:51:05 --> Router Class Initialized
DEBUG - 2011-04-17 11:51:05 --> Output Class Initialized
DEBUG - 2011-04-17 11:51:05 --> Input Class Initialized
DEBUG - 2011-04-17 11:51:05 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-17 11:51:05 --> Language Class Initialized
DEBUG - 2011-04-17 11:51:05 --> Loader Class Initialized
DEBUG - 2011-04-17 11:51:05 --> Controller Class Initialized
DEBUG - 2011-04-17 11:51:05 --> Model Class Initialized
DEBUG - 2011-04-17 11:51:05 --> Model Class Initialized
DEBUG - 2011-04-17 11:51:05 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-17 11:51:05 --> Database Driver Class Initialized
DEBUG - 2011-04-17 11:51:06 --> Final output sent to browser
DEBUG - 2011-04-17 11:51:06 --> Total execution time: 1.4881
DEBUG - 2011-04-17 11:53:33 --> Config Class Initialized
DEBUG - 2011-04-17 11:53:33 --> Hooks Class Initialized
DEBUG - 2011-04-17 11:53:33 --> Utf8 Class Initialized
DEBUG - 2011-04-17 11:53:33 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 11:53:33 --> URI Class Initialized
DEBUG - 2011-04-17 11:53:33 --> Router Class Initialized
DEBUG - 2011-04-17 11:53:33 --> Output Class Initialized
DEBUG - 2011-04-17 11:53:33 --> Input Class Initialized
DEBUG - 2011-04-17 11:53:33 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-17 11:53:33 --> Language Class Initialized
DEBUG - 2011-04-17 11:53:33 --> Loader Class Initialized
DEBUG - 2011-04-17 11:53:33 --> Controller Class Initialized
ERROR - 2011-04-17 11:53:33 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-17 11:53:33 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-17 11:53:33 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-17 11:53:33 --> Model Class Initialized
DEBUG - 2011-04-17 11:53:33 --> Model Class Initialized
DEBUG - 2011-04-17 11:53:33 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-17 11:53:33 --> Database Driver Class Initialized
DEBUG - 2011-04-17 11:53:33 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-17 11:53:33 --> Helper loaded: url_helper
DEBUG - 2011-04-17 11:53:33 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-17 11:53:33 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-17 11:53:33 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-17 11:53:33 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-17 11:53:33 --> Final output sent to browser
DEBUG - 2011-04-17 11:53:33 --> Total execution time: 0.0309
DEBUG - 2011-04-17 11:53:34 --> Config Class Initialized
DEBUG - 2011-04-17 11:53:34 --> Hooks Class Initialized
DEBUG - 2011-04-17 11:53:34 --> Utf8 Class Initialized
DEBUG - 2011-04-17 11:53:34 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 11:53:34 --> URI Class Initialized
DEBUG - 2011-04-17 11:53:34 --> Router Class Initialized
DEBUG - 2011-04-17 11:53:34 --> Output Class Initialized
DEBUG - 2011-04-17 11:53:34 --> Input Class Initialized
DEBUG - 2011-04-17 11:53:34 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-17 11:53:34 --> Language Class Initialized
DEBUG - 2011-04-17 11:53:34 --> Loader Class Initialized
DEBUG - 2011-04-17 11:53:34 --> Controller Class Initialized
DEBUG - 2011-04-17 11:53:34 --> Model Class Initialized
DEBUG - 2011-04-17 11:53:34 --> Model Class Initialized
DEBUG - 2011-04-17 11:53:34 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-17 11:53:34 --> Database Driver Class Initialized
DEBUG - 2011-04-17 11:53:35 --> Final output sent to browser
DEBUG - 2011-04-17 11:53:35 --> Total execution time: 0.7746
DEBUG - 2011-04-17 11:53:36 --> Config Class Initialized
DEBUG - 2011-04-17 11:53:36 --> Hooks Class Initialized
DEBUG - 2011-04-17 11:53:36 --> Utf8 Class Initialized
DEBUG - 2011-04-17 11:53:36 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 11:53:36 --> URI Class Initialized
DEBUG - 2011-04-17 11:53:36 --> Router Class Initialized
ERROR - 2011-04-17 11:53:36 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-17 12:03:50 --> Config Class Initialized
DEBUG - 2011-04-17 12:03:50 --> Hooks Class Initialized
DEBUG - 2011-04-17 12:03:50 --> Utf8 Class Initialized
DEBUG - 2011-04-17 12:03:50 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 12:03:50 --> URI Class Initialized
DEBUG - 2011-04-17 12:03:50 --> Router Class Initialized
DEBUG - 2011-04-17 12:03:50 --> Output Class Initialized
DEBUG - 2011-04-17 12:03:50 --> Input Class Initialized
DEBUG - 2011-04-17 12:03:50 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-17 12:03:50 --> Language Class Initialized
DEBUG - 2011-04-17 12:03:50 --> Loader Class Initialized
DEBUG - 2011-04-17 12:03:50 --> Controller Class Initialized
DEBUG - 2011-04-17 12:03:50 --> Model Class Initialized
DEBUG - 2011-04-17 12:03:50 --> Model Class Initialized
DEBUG - 2011-04-17 12:03:50 --> Model Class Initialized
DEBUG - 2011-04-17 12:03:50 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-17 12:03:50 --> Database Driver Class Initialized
DEBUG - 2011-04-17 12:03:50 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-17 12:03:50 --> Helper loaded: url_helper
DEBUG - 2011-04-17 12:03:50 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-17 12:03:50 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-17 12:03:50 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-17 12:03:50 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-17 12:03:50 --> Final output sent to browser
DEBUG - 2011-04-17 12:03:50 --> Total execution time: 0.0905
DEBUG - 2011-04-17 12:03:50 --> Config Class Initialized
DEBUG - 2011-04-17 12:03:50 --> Hooks Class Initialized
DEBUG - 2011-04-17 12:03:50 --> Utf8 Class Initialized
DEBUG - 2011-04-17 12:03:50 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 12:03:50 --> URI Class Initialized
DEBUG - 2011-04-17 12:03:50 --> Router Class Initialized
DEBUG - 2011-04-17 12:03:50 --> Output Class Initialized
DEBUG - 2011-04-17 12:03:50 --> Input Class Initialized
DEBUG - 2011-04-17 12:03:50 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-17 12:03:50 --> Language Class Initialized
DEBUG - 2011-04-17 12:03:50 --> Loader Class Initialized
DEBUG - 2011-04-17 12:03:50 --> Controller Class Initialized
ERROR - 2011-04-17 12:03:50 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-17 12:03:50 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-17 12:03:50 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-17 12:03:50 --> Model Class Initialized
DEBUG - 2011-04-17 12:03:50 --> Model Class Initialized
DEBUG - 2011-04-17 12:03:50 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-17 12:03:50 --> Database Driver Class Initialized
DEBUG - 2011-04-17 12:03:50 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-17 12:03:50 --> Helper loaded: url_helper
DEBUG - 2011-04-17 12:03:50 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-17 12:03:50 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-17 12:03:50 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-17 12:03:50 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-17 12:03:50 --> Final output sent to browser
DEBUG - 2011-04-17 12:03:50 --> Total execution time: 0.0301
DEBUG - 2011-04-17 12:03:52 --> Config Class Initialized
DEBUG - 2011-04-17 12:03:52 --> Hooks Class Initialized
DEBUG - 2011-04-17 12:03:52 --> Utf8 Class Initialized
DEBUG - 2011-04-17 12:03:52 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 12:03:52 --> URI Class Initialized
DEBUG - 2011-04-17 12:03:52 --> Router Class Initialized
DEBUG - 2011-04-17 12:03:52 --> Output Class Initialized
DEBUG - 2011-04-17 12:03:52 --> Input Class Initialized
DEBUG - 2011-04-17 12:03:52 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-17 12:03:52 --> Language Class Initialized
DEBUG - 2011-04-17 12:03:52 --> Loader Class Initialized
DEBUG - 2011-04-17 12:03:52 --> Controller Class Initialized
DEBUG - 2011-04-17 12:03:52 --> Model Class Initialized
DEBUG - 2011-04-17 12:03:52 --> Model Class Initialized
DEBUG - 2011-04-17 12:03:52 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-17 12:03:52 --> Database Driver Class Initialized
DEBUG - 2011-04-17 12:03:53 --> Final output sent to browser
DEBUG - 2011-04-17 12:03:53 --> Total execution time: 0.5933
DEBUG - 2011-04-17 12:03:54 --> Config Class Initialized
DEBUG - 2011-04-17 12:03:54 --> Hooks Class Initialized
DEBUG - 2011-04-17 12:03:54 --> Utf8 Class Initialized
DEBUG - 2011-04-17 12:03:54 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 12:03:54 --> URI Class Initialized
DEBUG - 2011-04-17 12:03:54 --> Router Class Initialized
ERROR - 2011-04-17 12:03:54 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-17 12:03:55 --> Config Class Initialized
DEBUG - 2011-04-17 12:03:55 --> Hooks Class Initialized
DEBUG - 2011-04-17 12:03:55 --> Utf8 Class Initialized
DEBUG - 2011-04-17 12:03:55 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 12:03:55 --> URI Class Initialized
DEBUG - 2011-04-17 12:03:55 --> Router Class Initialized
ERROR - 2011-04-17 12:03:55 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-17 12:03:56 --> Config Class Initialized
DEBUG - 2011-04-17 12:03:56 --> Hooks Class Initialized
DEBUG - 2011-04-17 12:03:56 --> Utf8 Class Initialized
DEBUG - 2011-04-17 12:03:56 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 12:03:56 --> URI Class Initialized
DEBUG - 2011-04-17 12:03:56 --> Router Class Initialized
ERROR - 2011-04-17 12:03:56 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-17 12:03:59 --> Config Class Initialized
DEBUG - 2011-04-17 12:03:59 --> Hooks Class Initialized
DEBUG - 2011-04-17 12:03:59 --> Utf8 Class Initialized
DEBUG - 2011-04-17 12:03:59 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 12:03:59 --> URI Class Initialized
DEBUG - 2011-04-17 12:03:59 --> Router Class Initialized
DEBUG - 2011-04-17 12:03:59 --> Output Class Initialized
DEBUG - 2011-04-17 12:03:59 --> Input Class Initialized
DEBUG - 2011-04-17 12:03:59 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-17 12:03:59 --> Language Class Initialized
DEBUG - 2011-04-17 12:03:59 --> Loader Class Initialized
DEBUG - 2011-04-17 12:03:59 --> Controller Class Initialized
DEBUG - 2011-04-17 12:03:59 --> Model Class Initialized
DEBUG - 2011-04-17 12:03:59 --> Model Class Initialized
DEBUG - 2011-04-17 12:03:59 --> Model Class Initialized
DEBUG - 2011-04-17 12:03:59 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-17 12:03:59 --> Database Driver Class Initialized
DEBUG - 2011-04-17 12:03:59 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-17 12:03:59 --> Helper loaded: url_helper
DEBUG - 2011-04-17 12:03:59 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-17 12:03:59 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-17 12:03:59 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-17 12:03:59 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-17 12:03:59 --> Final output sent to browser
DEBUG - 2011-04-17 12:03:59 --> Total execution time: 0.0642
DEBUG - 2011-04-17 12:04:03 --> Config Class Initialized
DEBUG - 2011-04-17 12:04:03 --> Hooks Class Initialized
DEBUG - 2011-04-17 12:04:03 --> Utf8 Class Initialized
DEBUG - 2011-04-17 12:04:03 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 12:04:03 --> URI Class Initialized
DEBUG - 2011-04-17 12:04:03 --> Router Class Initialized
DEBUG - 2011-04-17 12:04:03 --> Output Class Initialized
DEBUG - 2011-04-17 12:04:03 --> Input Class Initialized
DEBUG - 2011-04-17 12:04:03 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-17 12:04:03 --> Language Class Initialized
DEBUG - 2011-04-17 12:04:03 --> Loader Class Initialized
DEBUG - 2011-04-17 12:04:03 --> Controller Class Initialized
DEBUG - 2011-04-17 12:04:03 --> Model Class Initialized
DEBUG - 2011-04-17 12:04:03 --> Model Class Initialized
DEBUG - 2011-04-17 12:04:03 --> Model Class Initialized
DEBUG - 2011-04-17 12:04:03 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-17 12:04:03 --> Database Driver Class Initialized
DEBUG - 2011-04-17 12:04:03 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-17 12:04:03 --> Helper loaded: url_helper
DEBUG - 2011-04-17 12:04:03 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-17 12:04:03 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-17 12:04:03 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-17 12:04:03 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-17 12:04:03 --> Final output sent to browser
DEBUG - 2011-04-17 12:04:03 --> Total execution time: 0.2086
DEBUG - 2011-04-17 12:14:37 --> Config Class Initialized
DEBUG - 2011-04-17 12:14:37 --> Hooks Class Initialized
DEBUG - 2011-04-17 12:14:37 --> Utf8 Class Initialized
DEBUG - 2011-04-17 12:14:37 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 12:14:37 --> URI Class Initialized
DEBUG - 2011-04-17 12:14:37 --> Router Class Initialized
DEBUG - 2011-04-17 12:14:37 --> Output Class Initialized
DEBUG - 2011-04-17 12:14:37 --> Input Class Initialized
DEBUG - 2011-04-17 12:14:37 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-17 12:14:37 --> Language Class Initialized
DEBUG - 2011-04-17 12:14:37 --> Loader Class Initialized
DEBUG - 2011-04-17 12:14:37 --> Controller Class Initialized
DEBUG - 2011-04-17 12:14:37 --> Model Class Initialized
DEBUG - 2011-04-17 12:14:37 --> Model Class Initialized
DEBUG - 2011-04-17 12:14:37 --> Model Class Initialized
DEBUG - 2011-04-17 12:14:37 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-17 12:14:37 --> Database Driver Class Initialized
DEBUG - 2011-04-17 12:14:37 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-17 12:14:37 --> Helper loaded: url_helper
DEBUG - 2011-04-17 12:14:37 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-17 12:14:37 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-17 12:14:37 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-17 12:14:37 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-17 12:14:37 --> Final output sent to browser
DEBUG - 2011-04-17 12:14:37 --> Total execution time: 0.2273
DEBUG - 2011-04-17 12:14:39 --> Config Class Initialized
DEBUG - 2011-04-17 12:14:39 --> Hooks Class Initialized
DEBUG - 2011-04-17 12:14:39 --> Utf8 Class Initialized
DEBUG - 2011-04-17 12:14:39 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 12:14:39 --> URI Class Initialized
DEBUG - 2011-04-17 12:14:39 --> Router Class Initialized
ERROR - 2011-04-17 12:14:39 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-17 12:14:40 --> Config Class Initialized
DEBUG - 2011-04-17 12:14:40 --> Hooks Class Initialized
DEBUG - 2011-04-17 12:14:40 --> Utf8 Class Initialized
DEBUG - 2011-04-17 12:14:40 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 12:14:40 --> URI Class Initialized
DEBUG - 2011-04-17 12:14:40 --> Router Class Initialized
ERROR - 2011-04-17 12:14:40 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-17 12:15:11 --> Config Class Initialized
DEBUG - 2011-04-17 12:15:11 --> Hooks Class Initialized
DEBUG - 2011-04-17 12:15:11 --> Utf8 Class Initialized
DEBUG - 2011-04-17 12:15:11 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 12:15:11 --> URI Class Initialized
DEBUG - 2011-04-17 12:15:12 --> Router Class Initialized
DEBUG - 2011-04-17 12:15:12 --> Output Class Initialized
DEBUG - 2011-04-17 12:15:12 --> Input Class Initialized
DEBUG - 2011-04-17 12:15:12 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-17 12:15:12 --> Language Class Initialized
DEBUG - 2011-04-17 12:15:12 --> Loader Class Initialized
DEBUG - 2011-04-17 12:15:12 --> Controller Class Initialized
ERROR - 2011-04-17 12:15:13 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-17 12:15:13 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-17 12:15:13 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-17 12:15:13 --> Model Class Initialized
DEBUG - 2011-04-17 12:15:13 --> Model Class Initialized
DEBUG - 2011-04-17 12:15:13 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-17 12:15:13 --> Database Driver Class Initialized
DEBUG - 2011-04-17 12:15:13 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-17 12:15:13 --> Helper loaded: url_helper
DEBUG - 2011-04-17 12:15:13 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-17 12:15:13 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-17 12:15:13 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-17 12:15:13 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-17 12:15:13 --> Final output sent to browser
DEBUG - 2011-04-17 12:15:13 --> Total execution time: 1.7016
DEBUG - 2011-04-17 12:15:15 --> Config Class Initialized
DEBUG - 2011-04-17 12:15:15 --> Hooks Class Initialized
DEBUG - 2011-04-17 12:15:15 --> Utf8 Class Initialized
DEBUG - 2011-04-17 12:15:15 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 12:15:15 --> URI Class Initialized
DEBUG - 2011-04-17 12:15:15 --> Router Class Initialized
DEBUG - 2011-04-17 12:15:15 --> Output Class Initialized
DEBUG - 2011-04-17 12:15:15 --> Input Class Initialized
DEBUG - 2011-04-17 12:15:15 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-17 12:15:15 --> Language Class Initialized
DEBUG - 2011-04-17 12:15:15 --> Loader Class Initialized
DEBUG - 2011-04-17 12:15:15 --> Controller Class Initialized
DEBUG - 2011-04-17 12:15:15 --> Model Class Initialized
DEBUG - 2011-04-17 12:15:15 --> Model Class Initialized
DEBUG - 2011-04-17 12:15:15 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-17 12:15:15 --> Database Driver Class Initialized
DEBUG - 2011-04-17 12:15:16 --> Final output sent to browser
DEBUG - 2011-04-17 12:15:16 --> Total execution time: 1.3104
DEBUG - 2011-04-17 12:15:19 --> Config Class Initialized
DEBUG - 2011-04-17 12:15:19 --> Hooks Class Initialized
DEBUG - 2011-04-17 12:15:19 --> Utf8 Class Initialized
DEBUG - 2011-04-17 12:15:19 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 12:15:19 --> URI Class Initialized
DEBUG - 2011-04-17 12:15:19 --> Router Class Initialized
ERROR - 2011-04-17 12:15:19 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-17 12:15:22 --> Config Class Initialized
DEBUG - 2011-04-17 12:15:22 --> Hooks Class Initialized
DEBUG - 2011-04-17 12:15:22 --> Utf8 Class Initialized
DEBUG - 2011-04-17 12:15:22 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 12:15:22 --> URI Class Initialized
DEBUG - 2011-04-17 12:15:22 --> Router Class Initialized
ERROR - 2011-04-17 12:15:22 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-17 12:15:23 --> Config Class Initialized
DEBUG - 2011-04-17 12:15:23 --> Hooks Class Initialized
DEBUG - 2011-04-17 12:15:23 --> Utf8 Class Initialized
DEBUG - 2011-04-17 12:15:23 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 12:15:23 --> URI Class Initialized
DEBUG - 2011-04-17 12:15:23 --> Router Class Initialized
DEBUG - 2011-04-17 12:15:23 --> Output Class Initialized
DEBUG - 2011-04-17 12:15:23 --> Input Class Initialized
DEBUG - 2011-04-17 12:15:23 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-17 12:15:23 --> Language Class Initialized
DEBUG - 2011-04-17 12:15:23 --> Loader Class Initialized
DEBUG - 2011-04-17 12:15:23 --> Controller Class Initialized
ERROR - 2011-04-17 12:15:23 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-17 12:15:23 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-17 12:15:23 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-17 12:15:23 --> Model Class Initialized
DEBUG - 2011-04-17 12:15:23 --> Model Class Initialized
DEBUG - 2011-04-17 12:15:23 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-17 12:15:23 --> Database Driver Class Initialized
DEBUG - 2011-04-17 12:15:23 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-17 12:15:23 --> Helper loaded: url_helper
DEBUG - 2011-04-17 12:15:23 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-17 12:15:23 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-17 12:15:23 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-17 12:15:23 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-17 12:15:23 --> Final output sent to browser
DEBUG - 2011-04-17 12:15:23 --> Total execution time: 0.2754
DEBUG - 2011-04-17 12:29:24 --> Config Class Initialized
DEBUG - 2011-04-17 12:29:24 --> Hooks Class Initialized
DEBUG - 2011-04-17 12:29:24 --> Utf8 Class Initialized
DEBUG - 2011-04-17 12:29:24 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 12:29:24 --> URI Class Initialized
DEBUG - 2011-04-17 12:29:24 --> Router Class Initialized
DEBUG - 2011-04-17 12:29:24 --> Output Class Initialized
DEBUG - 2011-04-17 12:29:24 --> Input Class Initialized
DEBUG - 2011-04-17 12:29:24 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-17 12:29:24 --> Language Class Initialized
DEBUG - 2011-04-17 12:29:24 --> Loader Class Initialized
DEBUG - 2011-04-17 12:29:24 --> Controller Class Initialized
ERROR - 2011-04-17 12:29:24 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-17 12:29:24 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-17 12:29:24 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-17 12:29:24 --> Model Class Initialized
DEBUG - 2011-04-17 12:29:24 --> Model Class Initialized
DEBUG - 2011-04-17 12:29:24 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-17 12:29:24 --> Database Driver Class Initialized
DEBUG - 2011-04-17 12:29:24 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-17 12:29:24 --> Helper loaded: url_helper
DEBUG - 2011-04-17 12:29:24 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-17 12:29:24 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-17 12:29:24 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-17 12:29:24 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-17 12:29:24 --> Final output sent to browser
DEBUG - 2011-04-17 12:29:24 --> Total execution time: 0.1924
DEBUG - 2011-04-17 12:29:26 --> Config Class Initialized
DEBUG - 2011-04-17 12:29:26 --> Hooks Class Initialized
DEBUG - 2011-04-17 12:29:26 --> Utf8 Class Initialized
DEBUG - 2011-04-17 12:29:26 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 12:29:26 --> URI Class Initialized
DEBUG - 2011-04-17 12:29:26 --> Router Class Initialized
DEBUG - 2011-04-17 12:29:26 --> Output Class Initialized
DEBUG - 2011-04-17 12:29:26 --> Input Class Initialized
DEBUG - 2011-04-17 12:29:26 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-17 12:29:26 --> Language Class Initialized
DEBUG - 2011-04-17 12:29:26 --> Loader Class Initialized
DEBUG - 2011-04-17 12:29:26 --> Controller Class Initialized
DEBUG - 2011-04-17 12:29:26 --> Model Class Initialized
DEBUG - 2011-04-17 12:29:26 --> Model Class Initialized
DEBUG - 2011-04-17 12:29:26 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-17 12:29:26 --> Database Driver Class Initialized
DEBUG - 2011-04-17 12:29:27 --> Final output sent to browser
DEBUG - 2011-04-17 12:29:27 --> Total execution time: 0.7958
DEBUG - 2011-04-17 12:29:28 --> Config Class Initialized
DEBUG - 2011-04-17 12:29:28 --> Hooks Class Initialized
DEBUG - 2011-04-17 12:29:28 --> Utf8 Class Initialized
DEBUG - 2011-04-17 12:29:28 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 12:29:28 --> URI Class Initialized
DEBUG - 2011-04-17 12:29:28 --> Router Class Initialized
ERROR - 2011-04-17 12:29:28 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-17 12:29:38 --> Config Class Initialized
DEBUG - 2011-04-17 12:29:38 --> Hooks Class Initialized
DEBUG - 2011-04-17 12:29:38 --> Utf8 Class Initialized
DEBUG - 2011-04-17 12:29:38 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 12:29:38 --> URI Class Initialized
DEBUG - 2011-04-17 12:29:38 --> Router Class Initialized
DEBUG - 2011-04-17 12:29:38 --> Output Class Initialized
DEBUG - 2011-04-17 12:29:38 --> Input Class Initialized
DEBUG - 2011-04-17 12:29:38 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-17 12:29:38 --> Language Class Initialized
DEBUG - 2011-04-17 12:29:38 --> Loader Class Initialized
DEBUG - 2011-04-17 12:29:38 --> Controller Class Initialized
ERROR - 2011-04-17 12:29:38 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-17 12:29:38 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-17 12:29:38 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-17 12:29:38 --> Model Class Initialized
DEBUG - 2011-04-17 12:29:38 --> Model Class Initialized
DEBUG - 2011-04-17 12:29:38 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-17 12:29:38 --> Database Driver Class Initialized
DEBUG - 2011-04-17 12:29:38 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-17 12:29:38 --> Helper loaded: url_helper
DEBUG - 2011-04-17 12:29:38 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-17 12:29:38 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-17 12:29:38 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-17 12:29:38 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-17 12:29:38 --> Final output sent to browser
DEBUG - 2011-04-17 12:29:38 --> Total execution time: 0.0282
DEBUG - 2011-04-17 12:29:38 --> Config Class Initialized
DEBUG - 2011-04-17 12:29:38 --> Hooks Class Initialized
DEBUG - 2011-04-17 12:29:38 --> Utf8 Class Initialized
DEBUG - 2011-04-17 12:29:38 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 12:29:38 --> URI Class Initialized
DEBUG - 2011-04-17 12:29:38 --> Router Class Initialized
DEBUG - 2011-04-17 12:29:38 --> Output Class Initialized
DEBUG - 2011-04-17 12:29:38 --> Input Class Initialized
DEBUG - 2011-04-17 12:29:38 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-17 12:29:38 --> Language Class Initialized
DEBUG - 2011-04-17 12:29:38 --> Loader Class Initialized
DEBUG - 2011-04-17 12:29:38 --> Controller Class Initialized
DEBUG - 2011-04-17 12:29:38 --> Model Class Initialized
DEBUG - 2011-04-17 12:29:38 --> Model Class Initialized
DEBUG - 2011-04-17 12:29:38 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-17 12:29:38 --> Database Driver Class Initialized
DEBUG - 2011-04-17 12:29:39 --> Final output sent to browser
DEBUG - 2011-04-17 12:29:39 --> Total execution time: 0.6404
DEBUG - 2011-04-17 12:29:40 --> Config Class Initialized
DEBUG - 2011-04-17 12:29:40 --> Hooks Class Initialized
DEBUG - 2011-04-17 12:29:40 --> Utf8 Class Initialized
DEBUG - 2011-04-17 12:29:40 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 12:29:40 --> URI Class Initialized
DEBUG - 2011-04-17 12:29:40 --> Router Class Initialized
ERROR - 2011-04-17 12:29:40 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-17 12:31:13 --> Config Class Initialized
DEBUG - 2011-04-17 12:31:13 --> Hooks Class Initialized
DEBUG - 2011-04-17 12:31:13 --> Utf8 Class Initialized
DEBUG - 2011-04-17 12:31:13 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 12:31:13 --> URI Class Initialized
DEBUG - 2011-04-17 12:31:13 --> Router Class Initialized
ERROR - 2011-04-17 12:31:13 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-17 12:31:16 --> Config Class Initialized
DEBUG - 2011-04-17 12:31:16 --> Hooks Class Initialized
DEBUG - 2011-04-17 12:31:16 --> Utf8 Class Initialized
DEBUG - 2011-04-17 12:31:16 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 12:31:16 --> URI Class Initialized
DEBUG - 2011-04-17 12:31:16 --> Router Class Initialized
DEBUG - 2011-04-17 12:31:16 --> Output Class Initialized
DEBUG - 2011-04-17 12:31:16 --> Input Class Initialized
DEBUG - 2011-04-17 12:31:16 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-17 12:31:16 --> Language Class Initialized
DEBUG - 2011-04-17 12:31:16 --> Loader Class Initialized
DEBUG - 2011-04-17 12:31:16 --> Controller Class Initialized
DEBUG - 2011-04-17 12:31:16 --> Model Class Initialized
DEBUG - 2011-04-17 12:31:17 --> Model Class Initialized
DEBUG - 2011-04-17 12:31:17 --> Model Class Initialized
DEBUG - 2011-04-17 12:31:17 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-17 12:31:17 --> Database Driver Class Initialized
DEBUG - 2011-04-17 12:31:17 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-17 12:31:17 --> Helper loaded: url_helper
DEBUG - 2011-04-17 12:31:17 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-17 12:31:17 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-17 12:31:17 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-17 12:31:17 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-17 12:31:17 --> Final output sent to browser
DEBUG - 2011-04-17 12:31:17 --> Total execution time: 0.4342
DEBUG - 2011-04-17 12:31:19 --> Config Class Initialized
DEBUG - 2011-04-17 12:31:19 --> Hooks Class Initialized
DEBUG - 2011-04-17 12:31:19 --> Utf8 Class Initialized
DEBUG - 2011-04-17 12:31:19 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 12:31:19 --> URI Class Initialized
DEBUG - 2011-04-17 12:31:19 --> Router Class Initialized
ERROR - 2011-04-17 12:31:19 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-17 12:32:40 --> Config Class Initialized
DEBUG - 2011-04-17 12:32:40 --> Hooks Class Initialized
DEBUG - 2011-04-17 12:32:40 --> Utf8 Class Initialized
DEBUG - 2011-04-17 12:32:40 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 12:32:40 --> URI Class Initialized
DEBUG - 2011-04-17 12:32:40 --> Router Class Initialized
DEBUG - 2011-04-17 12:32:40 --> Output Class Initialized
DEBUG - 2011-04-17 12:32:40 --> Input Class Initialized
DEBUG - 2011-04-17 12:32:40 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-17 12:32:40 --> Language Class Initialized
DEBUG - 2011-04-17 12:32:40 --> Loader Class Initialized
DEBUG - 2011-04-17 12:32:40 --> Controller Class Initialized
ERROR - 2011-04-17 12:32:40 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-17 12:32:40 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-17 12:32:40 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-17 12:32:40 --> Model Class Initialized
DEBUG - 2011-04-17 12:32:40 --> Model Class Initialized
DEBUG - 2011-04-17 12:32:40 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-17 12:32:40 --> Database Driver Class Initialized
DEBUG - 2011-04-17 12:32:40 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-17 12:32:40 --> Helper loaded: url_helper
DEBUG - 2011-04-17 12:32:40 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-17 12:32:40 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-17 12:32:40 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-17 12:32:40 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-17 12:32:40 --> Final output sent to browser
DEBUG - 2011-04-17 12:32:40 --> Total execution time: 0.0292
DEBUG - 2011-04-17 12:32:40 --> Config Class Initialized
DEBUG - 2011-04-17 12:32:40 --> Hooks Class Initialized
DEBUG - 2011-04-17 12:32:40 --> Utf8 Class Initialized
DEBUG - 2011-04-17 12:32:40 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 12:32:40 --> URI Class Initialized
DEBUG - 2011-04-17 12:32:40 --> Router Class Initialized
DEBUG - 2011-04-17 12:32:40 --> Output Class Initialized
DEBUG - 2011-04-17 12:32:40 --> Input Class Initialized
DEBUG - 2011-04-17 12:32:40 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-17 12:32:40 --> Language Class Initialized
DEBUG - 2011-04-17 12:32:40 --> Loader Class Initialized
DEBUG - 2011-04-17 12:32:40 --> Controller Class Initialized
DEBUG - 2011-04-17 12:32:40 --> Model Class Initialized
DEBUG - 2011-04-17 12:32:40 --> Model Class Initialized
DEBUG - 2011-04-17 12:32:40 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-17 12:32:40 --> Database Driver Class Initialized
DEBUG - 2011-04-17 12:32:41 --> Final output sent to browser
DEBUG - 2011-04-17 12:32:41 --> Total execution time: 0.8350
DEBUG - 2011-04-17 12:32:42 --> Config Class Initialized
DEBUG - 2011-04-17 12:32:42 --> Hooks Class Initialized
DEBUG - 2011-04-17 12:32:42 --> Utf8 Class Initialized
DEBUG - 2011-04-17 12:32:42 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 12:32:42 --> URI Class Initialized
DEBUG - 2011-04-17 12:32:42 --> Router Class Initialized
ERROR - 2011-04-17 12:32:42 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-17 12:32:42 --> Config Class Initialized
DEBUG - 2011-04-17 12:32:42 --> Hooks Class Initialized
DEBUG - 2011-04-17 12:32:42 --> Utf8 Class Initialized
DEBUG - 2011-04-17 12:32:42 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 12:32:42 --> URI Class Initialized
DEBUG - 2011-04-17 12:32:42 --> Router Class Initialized
ERROR - 2011-04-17 12:32:42 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-17 12:32:44 --> Config Class Initialized
DEBUG - 2011-04-17 12:32:44 --> Hooks Class Initialized
DEBUG - 2011-04-17 12:32:44 --> Utf8 Class Initialized
DEBUG - 2011-04-17 12:32:44 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 12:32:44 --> URI Class Initialized
DEBUG - 2011-04-17 12:32:44 --> Router Class Initialized
ERROR - 2011-04-17 12:32:44 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-17 12:33:13 --> Config Class Initialized
DEBUG - 2011-04-17 12:33:13 --> Hooks Class Initialized
DEBUG - 2011-04-17 12:33:13 --> Utf8 Class Initialized
DEBUG - 2011-04-17 12:33:13 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 12:33:13 --> URI Class Initialized
DEBUG - 2011-04-17 12:33:13 --> Router Class Initialized
DEBUG - 2011-04-17 12:33:13 --> Output Class Initialized
DEBUG - 2011-04-17 12:33:13 --> Input Class Initialized
DEBUG - 2011-04-17 12:33:13 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-17 12:33:13 --> Language Class Initialized
DEBUG - 2011-04-17 12:33:13 --> Loader Class Initialized
DEBUG - 2011-04-17 12:33:13 --> Controller Class Initialized
ERROR - 2011-04-17 12:33:13 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-17 12:33:13 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-17 12:33:13 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-17 12:33:13 --> Model Class Initialized
DEBUG - 2011-04-17 12:33:13 --> Model Class Initialized
DEBUG - 2011-04-17 12:33:13 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-17 12:33:13 --> Database Driver Class Initialized
DEBUG - 2011-04-17 12:33:13 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-17 12:33:13 --> Helper loaded: url_helper
DEBUG - 2011-04-17 12:33:13 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-17 12:33:13 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-17 12:33:13 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-17 12:33:13 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-17 12:33:13 --> Final output sent to browser
DEBUG - 2011-04-17 12:33:13 --> Total execution time: 0.0309
DEBUG - 2011-04-17 12:33:14 --> Config Class Initialized
DEBUG - 2011-04-17 12:33:14 --> Hooks Class Initialized
DEBUG - 2011-04-17 12:33:14 --> Utf8 Class Initialized
DEBUG - 2011-04-17 12:33:14 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 12:33:14 --> URI Class Initialized
DEBUG - 2011-04-17 12:33:14 --> Router Class Initialized
DEBUG - 2011-04-17 12:33:14 --> Output Class Initialized
DEBUG - 2011-04-17 12:33:14 --> Input Class Initialized
DEBUG - 2011-04-17 12:33:14 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-17 12:33:14 --> Language Class Initialized
DEBUG - 2011-04-17 12:33:14 --> Loader Class Initialized
DEBUG - 2011-04-17 12:33:14 --> Controller Class Initialized
DEBUG - 2011-04-17 12:33:14 --> Model Class Initialized
DEBUG - 2011-04-17 12:33:14 --> Model Class Initialized
DEBUG - 2011-04-17 12:33:14 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-17 12:33:14 --> Database Driver Class Initialized
DEBUG - 2011-04-17 12:33:14 --> Final output sent to browser
DEBUG - 2011-04-17 12:33:14 --> Total execution time: 0.7167
DEBUG - 2011-04-17 12:33:19 --> Config Class Initialized
DEBUG - 2011-04-17 12:33:19 --> Hooks Class Initialized
DEBUG - 2011-04-17 12:33:19 --> Utf8 Class Initialized
DEBUG - 2011-04-17 12:33:19 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 12:33:19 --> URI Class Initialized
DEBUG - 2011-04-17 12:33:19 --> Router Class Initialized
DEBUG - 2011-04-17 12:33:19 --> Output Class Initialized
DEBUG - 2011-04-17 12:33:19 --> Input Class Initialized
DEBUG - 2011-04-17 12:33:19 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-17 12:33:19 --> Language Class Initialized
DEBUG - 2011-04-17 12:33:19 --> Loader Class Initialized
DEBUG - 2011-04-17 12:33:19 --> Controller Class Initialized
ERROR - 2011-04-17 12:33:19 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-17 12:33:19 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-17 12:33:19 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-17 12:33:19 --> Model Class Initialized
DEBUG - 2011-04-17 12:33:19 --> Model Class Initialized
DEBUG - 2011-04-17 12:33:19 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-17 12:33:19 --> Database Driver Class Initialized
DEBUG - 2011-04-17 12:33:19 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-17 12:33:19 --> Helper loaded: url_helper
DEBUG - 2011-04-17 12:33:19 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-17 12:33:19 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-17 12:33:19 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-17 12:33:19 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-17 12:33:19 --> Final output sent to browser
DEBUG - 2011-04-17 12:33:19 --> Total execution time: 0.0971
DEBUG - 2011-04-17 12:33:19 --> Config Class Initialized
DEBUG - 2011-04-17 12:33:19 --> Hooks Class Initialized
DEBUG - 2011-04-17 12:33:19 --> Utf8 Class Initialized
DEBUG - 2011-04-17 12:33:19 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 12:33:19 --> URI Class Initialized
DEBUG - 2011-04-17 12:33:19 --> Router Class Initialized
DEBUG - 2011-04-17 12:33:19 --> Output Class Initialized
DEBUG - 2011-04-17 12:33:19 --> Input Class Initialized
DEBUG - 2011-04-17 12:33:19 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-17 12:33:19 --> Language Class Initialized
DEBUG - 2011-04-17 12:33:19 --> Loader Class Initialized
DEBUG - 2011-04-17 12:33:19 --> Controller Class Initialized
DEBUG - 2011-04-17 12:33:19 --> Model Class Initialized
DEBUG - 2011-04-17 12:33:19 --> Model Class Initialized
DEBUG - 2011-04-17 12:33:19 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-17 12:33:19 --> Database Driver Class Initialized
DEBUG - 2011-04-17 12:33:20 --> Final output sent to browser
DEBUG - 2011-04-17 12:33:20 --> Total execution time: 0.6542
DEBUG - 2011-04-17 12:33:31 --> Config Class Initialized
DEBUG - 2011-04-17 12:33:31 --> Hooks Class Initialized
DEBUG - 2011-04-17 12:33:31 --> Utf8 Class Initialized
DEBUG - 2011-04-17 12:33:31 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 12:33:31 --> URI Class Initialized
DEBUG - 2011-04-17 12:33:31 --> Router Class Initialized
DEBUG - 2011-04-17 12:33:31 --> Output Class Initialized
DEBUG - 2011-04-17 12:33:31 --> Input Class Initialized
DEBUG - 2011-04-17 12:33:31 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-17 12:33:31 --> Language Class Initialized
DEBUG - 2011-04-17 12:33:31 --> Loader Class Initialized
DEBUG - 2011-04-17 12:33:31 --> Controller Class Initialized
ERROR - 2011-04-17 12:33:31 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-17 12:33:31 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-17 12:33:31 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-17 12:33:31 --> Model Class Initialized
DEBUG - 2011-04-17 12:33:31 --> Model Class Initialized
DEBUG - 2011-04-17 12:33:31 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-17 12:33:31 --> Database Driver Class Initialized
DEBUG - 2011-04-17 12:33:31 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-17 12:33:31 --> Helper loaded: url_helper
DEBUG - 2011-04-17 12:33:31 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-17 12:33:31 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-17 12:33:31 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-17 12:33:31 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-17 12:33:31 --> Final output sent to browser
DEBUG - 2011-04-17 12:33:31 --> Total execution time: 0.0542
DEBUG - 2011-04-17 12:33:32 --> Config Class Initialized
DEBUG - 2011-04-17 12:33:32 --> Hooks Class Initialized
DEBUG - 2011-04-17 12:33:32 --> Utf8 Class Initialized
DEBUG - 2011-04-17 12:33:32 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 12:33:32 --> URI Class Initialized
DEBUG - 2011-04-17 12:33:32 --> Router Class Initialized
DEBUG - 2011-04-17 12:33:32 --> Output Class Initialized
DEBUG - 2011-04-17 12:33:32 --> Input Class Initialized
DEBUG - 2011-04-17 12:33:32 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-17 12:33:32 --> Language Class Initialized
DEBUG - 2011-04-17 12:33:32 --> Loader Class Initialized
DEBUG - 2011-04-17 12:33:32 --> Controller Class Initialized
DEBUG - 2011-04-17 12:33:32 --> Model Class Initialized
DEBUG - 2011-04-17 12:33:32 --> Model Class Initialized
DEBUG - 2011-04-17 12:33:32 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-17 12:33:32 --> Database Driver Class Initialized
DEBUG - 2011-04-17 12:33:33 --> Final output sent to browser
DEBUG - 2011-04-17 12:33:33 --> Total execution time: 0.5716
DEBUG - 2011-04-17 12:36:10 --> Config Class Initialized
DEBUG - 2011-04-17 12:36:10 --> Hooks Class Initialized
DEBUG - 2011-04-17 12:36:10 --> Utf8 Class Initialized
DEBUG - 2011-04-17 12:36:10 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 12:36:10 --> URI Class Initialized
DEBUG - 2011-04-17 12:36:10 --> Router Class Initialized
DEBUG - 2011-04-17 12:36:10 --> Output Class Initialized
DEBUG - 2011-04-17 12:36:10 --> Input Class Initialized
DEBUG - 2011-04-17 12:36:10 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-17 12:36:10 --> Language Class Initialized
DEBUG - 2011-04-17 12:36:10 --> Loader Class Initialized
DEBUG - 2011-04-17 12:36:10 --> Controller Class Initialized
DEBUG - 2011-04-17 12:36:10 --> Model Class Initialized
DEBUG - 2011-04-17 12:36:10 --> Model Class Initialized
DEBUG - 2011-04-17 12:36:10 --> Model Class Initialized
DEBUG - 2011-04-17 12:36:10 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-17 12:36:10 --> Database Driver Class Initialized
DEBUG - 2011-04-17 12:36:10 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-17 12:36:10 --> Helper loaded: url_helper
DEBUG - 2011-04-17 12:36:10 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-17 12:36:10 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-17 12:36:10 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-17 12:36:10 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-17 12:36:10 --> Final output sent to browser
DEBUG - 2011-04-17 12:36:10 --> Total execution time: 0.0881
DEBUG - 2011-04-17 12:36:16 --> Config Class Initialized
DEBUG - 2011-04-17 12:36:16 --> Hooks Class Initialized
DEBUG - 2011-04-17 12:36:16 --> Utf8 Class Initialized
DEBUG - 2011-04-17 12:36:16 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 12:36:16 --> URI Class Initialized
DEBUG - 2011-04-17 12:36:16 --> Router Class Initialized
ERROR - 2011-04-17 12:36:16 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-17 12:36:16 --> Config Class Initialized
DEBUG - 2011-04-17 12:36:16 --> Hooks Class Initialized
DEBUG - 2011-04-17 12:36:16 --> Utf8 Class Initialized
DEBUG - 2011-04-17 12:36:16 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 12:36:16 --> URI Class Initialized
DEBUG - 2011-04-17 12:36:16 --> Router Class Initialized
ERROR - 2011-04-17 12:36:16 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-17 12:36:19 --> Config Class Initialized
DEBUG - 2011-04-17 12:36:19 --> Hooks Class Initialized
DEBUG - 2011-04-17 12:36:19 --> Utf8 Class Initialized
DEBUG - 2011-04-17 12:36:19 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 12:36:19 --> URI Class Initialized
DEBUG - 2011-04-17 12:36:20 --> Router Class Initialized
DEBUG - 2011-04-17 12:36:20 --> Output Class Initialized
DEBUG - 2011-04-17 12:36:20 --> Input Class Initialized
DEBUG - 2011-04-17 12:36:20 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-17 12:36:20 --> Language Class Initialized
DEBUG - 2011-04-17 12:36:20 --> Loader Class Initialized
DEBUG - 2011-04-17 12:36:20 --> Controller Class Initialized
DEBUG - 2011-04-17 12:36:20 --> Model Class Initialized
DEBUG - 2011-04-17 12:36:20 --> Model Class Initialized
DEBUG - 2011-04-17 12:36:20 --> Model Class Initialized
DEBUG - 2011-04-17 12:36:20 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-17 12:36:20 --> Database Driver Class Initialized
DEBUG - 2011-04-17 12:36:20 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-17 12:36:20 --> Helper loaded: url_helper
DEBUG - 2011-04-17 12:36:20 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-17 12:36:20 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-17 12:36:20 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-17 12:36:20 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-17 12:36:20 --> Final output sent to browser
DEBUG - 2011-04-17 12:36:20 --> Total execution time: 0.1818
DEBUG - 2011-04-17 12:36:49 --> Config Class Initialized
DEBUG - 2011-04-17 12:36:49 --> Hooks Class Initialized
DEBUG - 2011-04-17 12:36:49 --> Utf8 Class Initialized
DEBUG - 2011-04-17 12:36:49 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 12:36:49 --> URI Class Initialized
DEBUG - 2011-04-17 12:36:49 --> Router Class Initialized
DEBUG - 2011-04-17 12:36:49 --> Output Class Initialized
DEBUG - 2011-04-17 12:36:49 --> Input Class Initialized
DEBUG - 2011-04-17 12:36:49 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-17 12:36:49 --> Language Class Initialized
DEBUG - 2011-04-17 12:36:49 --> Loader Class Initialized
DEBUG - 2011-04-17 12:36:49 --> Controller Class Initialized
DEBUG - 2011-04-17 12:36:49 --> Model Class Initialized
DEBUG - 2011-04-17 12:36:49 --> Model Class Initialized
DEBUG - 2011-04-17 12:36:49 --> Model Class Initialized
DEBUG - 2011-04-17 12:36:49 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-17 12:36:49 --> Database Driver Class Initialized
DEBUG - 2011-04-17 12:36:49 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-17 12:36:49 --> Helper loaded: url_helper
DEBUG - 2011-04-17 12:36:49 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-17 12:36:49 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-17 12:36:49 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-17 12:36:49 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-17 12:36:49 --> Final output sent to browser
DEBUG - 2011-04-17 12:36:49 --> Total execution time: 0.2987
DEBUG - 2011-04-17 12:36:52 --> Config Class Initialized
DEBUG - 2011-04-17 12:36:52 --> Hooks Class Initialized
DEBUG - 2011-04-17 12:36:52 --> Utf8 Class Initialized
DEBUG - 2011-04-17 12:36:52 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 12:36:52 --> URI Class Initialized
DEBUG - 2011-04-17 12:36:52 --> Router Class Initialized
DEBUG - 2011-04-17 12:36:52 --> Output Class Initialized
DEBUG - 2011-04-17 12:36:52 --> Input Class Initialized
DEBUG - 2011-04-17 12:36:52 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-17 12:36:52 --> Language Class Initialized
DEBUG - 2011-04-17 12:36:52 --> Loader Class Initialized
DEBUG - 2011-04-17 12:36:52 --> Controller Class Initialized
DEBUG - 2011-04-17 12:36:52 --> Model Class Initialized
DEBUG - 2011-04-17 12:36:52 --> Model Class Initialized
DEBUG - 2011-04-17 12:36:52 --> Model Class Initialized
DEBUG - 2011-04-17 12:36:52 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-17 12:36:52 --> Database Driver Class Initialized
DEBUG - 2011-04-17 12:36:52 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-17 12:36:52 --> Helper loaded: url_helper
DEBUG - 2011-04-17 12:36:52 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-17 12:36:52 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-17 12:36:52 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-17 12:36:52 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-17 12:36:52 --> Final output sent to browser
DEBUG - 2011-04-17 12:36:52 --> Total execution time: 0.0439
DEBUG - 2011-04-17 12:55:06 --> Config Class Initialized
DEBUG - 2011-04-17 12:55:06 --> Hooks Class Initialized
DEBUG - 2011-04-17 12:55:06 --> Utf8 Class Initialized
DEBUG - 2011-04-17 12:55:06 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 12:55:06 --> URI Class Initialized
DEBUG - 2011-04-17 12:55:06 --> Router Class Initialized
DEBUG - 2011-04-17 12:55:06 --> Output Class Initialized
DEBUG - 2011-04-17 12:55:06 --> Input Class Initialized
DEBUG - 2011-04-17 12:55:06 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-17 12:55:06 --> Language Class Initialized
DEBUG - 2011-04-17 12:55:06 --> Loader Class Initialized
DEBUG - 2011-04-17 12:55:06 --> Controller Class Initialized
ERROR - 2011-04-17 12:55:06 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-17 12:55:06 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-17 12:55:06 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-17 12:55:06 --> Model Class Initialized
DEBUG - 2011-04-17 12:55:06 --> Model Class Initialized
DEBUG - 2011-04-17 12:55:06 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-17 12:55:06 --> Database Driver Class Initialized
DEBUG - 2011-04-17 12:55:06 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-17 12:55:06 --> Helper loaded: url_helper
DEBUG - 2011-04-17 12:55:06 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-17 12:55:06 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-17 12:55:06 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-17 12:55:06 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-17 12:55:06 --> Final output sent to browser
DEBUG - 2011-04-17 12:55:06 --> Total execution time: 0.0468
DEBUG - 2011-04-17 12:55:08 --> Config Class Initialized
DEBUG - 2011-04-17 12:55:08 --> Hooks Class Initialized
DEBUG - 2011-04-17 12:55:08 --> Utf8 Class Initialized
DEBUG - 2011-04-17 12:55:08 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 12:55:08 --> URI Class Initialized
DEBUG - 2011-04-17 12:55:08 --> Router Class Initialized
DEBUG - 2011-04-17 12:55:08 --> Output Class Initialized
DEBUG - 2011-04-17 12:55:08 --> Input Class Initialized
DEBUG - 2011-04-17 12:55:08 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-17 12:55:08 --> Language Class Initialized
DEBUG - 2011-04-17 12:55:08 --> Loader Class Initialized
DEBUG - 2011-04-17 12:55:08 --> Controller Class Initialized
DEBUG - 2011-04-17 12:55:08 --> Model Class Initialized
DEBUG - 2011-04-17 12:55:08 --> Model Class Initialized
DEBUG - 2011-04-17 12:55:08 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-17 12:55:08 --> Database Driver Class Initialized
DEBUG - 2011-04-17 12:55:08 --> Final output sent to browser
DEBUG - 2011-04-17 12:55:08 --> Total execution time: 0.7468
DEBUG - 2011-04-17 12:55:10 --> Config Class Initialized
DEBUG - 2011-04-17 12:55:10 --> Hooks Class Initialized
DEBUG - 2011-04-17 12:55:10 --> Utf8 Class Initialized
DEBUG - 2011-04-17 12:55:10 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 12:55:10 --> URI Class Initialized
DEBUG - 2011-04-17 12:55:10 --> Router Class Initialized
ERROR - 2011-04-17 12:55:10 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-17 12:55:11 --> Config Class Initialized
DEBUG - 2011-04-17 12:55:11 --> Hooks Class Initialized
DEBUG - 2011-04-17 12:55:11 --> Utf8 Class Initialized
DEBUG - 2011-04-17 12:55:11 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 12:55:11 --> URI Class Initialized
DEBUG - 2011-04-17 12:55:11 --> Router Class Initialized
ERROR - 2011-04-17 12:55:11 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-17 13:06:08 --> Config Class Initialized
DEBUG - 2011-04-17 13:06:08 --> Hooks Class Initialized
DEBUG - 2011-04-17 13:06:08 --> Utf8 Class Initialized
DEBUG - 2011-04-17 13:06:08 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 13:06:08 --> URI Class Initialized
DEBUG - 2011-04-17 13:06:08 --> Router Class Initialized
DEBUG - 2011-04-17 13:06:08 --> Output Class Initialized
DEBUG - 2011-04-17 13:06:08 --> Input Class Initialized
DEBUG - 2011-04-17 13:06:08 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-17 13:06:08 --> Language Class Initialized
DEBUG - 2011-04-17 13:06:08 --> Loader Class Initialized
DEBUG - 2011-04-17 13:06:08 --> Controller Class Initialized
ERROR - 2011-04-17 13:06:08 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-17 13:06:08 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-17 13:06:08 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-17 13:06:08 --> Model Class Initialized
DEBUG - 2011-04-17 13:06:08 --> Model Class Initialized
DEBUG - 2011-04-17 13:06:08 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-17 13:06:08 --> Database Driver Class Initialized
DEBUG - 2011-04-17 13:06:09 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-17 13:06:09 --> Helper loaded: url_helper
DEBUG - 2011-04-17 13:06:09 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-17 13:06:09 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-17 13:06:09 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-17 13:06:09 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-17 13:06:09 --> Final output sent to browser
DEBUG - 2011-04-17 13:06:09 --> Total execution time: 0.8627
DEBUG - 2011-04-17 13:06:13 --> Config Class Initialized
DEBUG - 2011-04-17 13:06:13 --> Hooks Class Initialized
DEBUG - 2011-04-17 13:06:13 --> Utf8 Class Initialized
DEBUG - 2011-04-17 13:06:13 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 13:06:13 --> URI Class Initialized
DEBUG - 2011-04-17 13:06:13 --> Router Class Initialized
DEBUG - 2011-04-17 13:06:13 --> Output Class Initialized
DEBUG - 2011-04-17 13:06:13 --> Input Class Initialized
DEBUG - 2011-04-17 13:06:13 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-17 13:06:13 --> Language Class Initialized
DEBUG - 2011-04-17 13:06:13 --> Loader Class Initialized
DEBUG - 2011-04-17 13:06:13 --> Controller Class Initialized
DEBUG - 2011-04-17 13:06:13 --> Model Class Initialized
DEBUG - 2011-04-17 13:06:13 --> Model Class Initialized
DEBUG - 2011-04-17 13:06:13 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-17 13:06:13 --> Database Driver Class Initialized
DEBUG - 2011-04-17 13:18:11 --> Config Class Initialized
DEBUG - 2011-04-17 13:18:11 --> Hooks Class Initialized
DEBUG - 2011-04-17 13:18:11 --> Utf8 Class Initialized
DEBUG - 2011-04-17 13:18:11 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 13:18:11 --> URI Class Initialized
DEBUG - 2011-04-17 13:18:11 --> Router Class Initialized
DEBUG - 2011-04-17 13:18:11 --> Output Class Initialized
DEBUG - 2011-04-17 13:18:11 --> Input Class Initialized
DEBUG - 2011-04-17 13:18:11 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-17 13:18:11 --> Language Class Initialized
DEBUG - 2011-04-17 13:18:11 --> Loader Class Initialized
DEBUG - 2011-04-17 13:18:11 --> Controller Class Initialized
DEBUG - 2011-04-17 13:18:11 --> Model Class Initialized
DEBUG - 2011-04-17 13:18:11 --> Model Class Initialized
DEBUG - 2011-04-17 13:18:11 --> Model Class Initialized
DEBUG - 2011-04-17 13:18:11 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-17 13:18:11 --> Database Driver Class Initialized
DEBUG - 2011-04-17 13:18:12 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-17 13:18:12 --> Helper loaded: url_helper
DEBUG - 2011-04-17 13:18:12 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-17 13:18:12 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-17 13:18:12 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-17 13:18:12 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-17 13:18:12 --> Final output sent to browser
DEBUG - 2011-04-17 13:18:12 --> Total execution time: 0.3013
DEBUG - 2011-04-17 13:18:15 --> Config Class Initialized
DEBUG - 2011-04-17 13:18:15 --> Hooks Class Initialized
DEBUG - 2011-04-17 13:18:15 --> Utf8 Class Initialized
DEBUG - 2011-04-17 13:18:15 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 13:18:15 --> URI Class Initialized
DEBUG - 2011-04-17 13:18:15 --> Router Class Initialized
ERROR - 2011-04-17 13:18:15 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-17 13:18:15 --> Config Class Initialized
DEBUG - 2011-04-17 13:18:15 --> Hooks Class Initialized
DEBUG - 2011-04-17 13:18:15 --> Utf8 Class Initialized
DEBUG - 2011-04-17 13:18:15 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 13:18:15 --> URI Class Initialized
DEBUG - 2011-04-17 13:18:15 --> Router Class Initialized
ERROR - 2011-04-17 13:18:15 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-17 13:18:16 --> Config Class Initialized
DEBUG - 2011-04-17 13:18:16 --> Hooks Class Initialized
DEBUG - 2011-04-17 13:18:16 --> Utf8 Class Initialized
DEBUG - 2011-04-17 13:18:16 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 13:18:16 --> URI Class Initialized
DEBUG - 2011-04-17 13:18:16 --> Router Class Initialized
ERROR - 2011-04-17 13:18:16 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-17 13:29:47 --> Config Class Initialized
DEBUG - 2011-04-17 13:29:47 --> Hooks Class Initialized
DEBUG - 2011-04-17 13:29:47 --> Utf8 Class Initialized
DEBUG - 2011-04-17 13:29:47 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 13:29:47 --> URI Class Initialized
DEBUG - 2011-04-17 13:29:47 --> Router Class Initialized
DEBUG - 2011-04-17 13:29:47 --> No URI present. Default controller set.
DEBUG - 2011-04-17 13:29:47 --> Output Class Initialized
DEBUG - 2011-04-17 13:29:47 --> Input Class Initialized
DEBUG - 2011-04-17 13:29:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-17 13:29:47 --> Language Class Initialized
DEBUG - 2011-04-17 13:29:47 --> Loader Class Initialized
DEBUG - 2011-04-17 13:29:47 --> Controller Class Initialized
DEBUG - 2011-04-17 13:29:47 --> File loaded: application/views/splash/main.php
DEBUG - 2011-04-17 13:29:47 --> Helper loaded: url_helper
DEBUG - 2011-04-17 13:29:47 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-17 13:29:47 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-17 13:29:47 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-17 13:29:47 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-17 13:29:47 --> Final output sent to browser
DEBUG - 2011-04-17 13:29:47 --> Total execution time: 0.0908
DEBUG - 2011-04-17 13:36:00 --> Config Class Initialized
DEBUG - 2011-04-17 13:36:00 --> Hooks Class Initialized
DEBUG - 2011-04-17 13:36:00 --> Utf8 Class Initialized
DEBUG - 2011-04-17 13:36:00 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 13:36:00 --> URI Class Initialized
DEBUG - 2011-04-17 13:36:00 --> Router Class Initialized
DEBUG - 2011-04-17 13:36:00 --> No URI present. Default controller set.
DEBUG - 2011-04-17 13:36:00 --> Output Class Initialized
DEBUG - 2011-04-17 13:36:00 --> Input Class Initialized
DEBUG - 2011-04-17 13:36:00 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-17 13:36:00 --> Language Class Initialized
DEBUG - 2011-04-17 13:36:00 --> Loader Class Initialized
DEBUG - 2011-04-17 13:36:00 --> Controller Class Initialized
DEBUG - 2011-04-17 13:36:00 --> File loaded: application/views/splash/main.php
DEBUG - 2011-04-17 13:36:00 --> Helper loaded: url_helper
DEBUG - 2011-04-17 13:36:00 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-17 13:36:00 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-17 13:36:00 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-17 13:36:00 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-17 13:36:00 --> Final output sent to browser
DEBUG - 2011-04-17 13:36:00 --> Total execution time: 0.0405
DEBUG - 2011-04-17 13:36:03 --> Config Class Initialized
DEBUG - 2011-04-17 13:36:03 --> Hooks Class Initialized
DEBUG - 2011-04-17 13:36:03 --> Utf8 Class Initialized
DEBUG - 2011-04-17 13:36:03 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 13:36:03 --> URI Class Initialized
DEBUG - 2011-04-17 13:36:03 --> Router Class Initialized
ERROR - 2011-04-17 13:36:03 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-17 13:36:05 --> Config Class Initialized
DEBUG - 2011-04-17 13:36:05 --> Hooks Class Initialized
DEBUG - 2011-04-17 13:36:05 --> Utf8 Class Initialized
DEBUG - 2011-04-17 13:36:05 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 13:36:05 --> URI Class Initialized
DEBUG - 2011-04-17 13:36:05 --> Router Class Initialized
DEBUG - 2011-04-17 13:36:05 --> Output Class Initialized
DEBUG - 2011-04-17 13:36:05 --> Input Class Initialized
DEBUG - 2011-04-17 13:36:05 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-17 13:36:05 --> Language Class Initialized
DEBUG - 2011-04-17 13:36:05 --> Loader Class Initialized
DEBUG - 2011-04-17 13:36:05 --> Controller Class Initialized
DEBUG - 2011-04-17 13:36:05 --> Model Class Initialized
DEBUG - 2011-04-17 13:36:05 --> Model Class Initialized
DEBUG - 2011-04-17 13:36:05 --> Model Class Initialized
DEBUG - 2011-04-17 13:36:05 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-17 13:36:05 --> Database Driver Class Initialized
DEBUG - 2011-04-17 13:36:05 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-17 13:36:05 --> Helper loaded: url_helper
DEBUG - 2011-04-17 13:36:05 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-17 13:36:05 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-17 13:36:05 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-17 13:36:05 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-17 13:36:05 --> Final output sent to browser
DEBUG - 2011-04-17 13:36:05 --> Total execution time: 0.2269
DEBUG - 2011-04-17 13:36:15 --> Config Class Initialized
DEBUG - 2011-04-17 13:36:15 --> Hooks Class Initialized
DEBUG - 2011-04-17 13:36:15 --> Utf8 Class Initialized
DEBUG - 2011-04-17 13:36:15 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 13:36:15 --> URI Class Initialized
DEBUG - 2011-04-17 13:36:15 --> Router Class Initialized
DEBUG - 2011-04-17 13:36:15 --> Output Class Initialized
DEBUG - 2011-04-17 13:36:15 --> Input Class Initialized
DEBUG - 2011-04-17 13:36:15 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-17 13:36:15 --> Language Class Initialized
DEBUG - 2011-04-17 13:36:15 --> Loader Class Initialized
DEBUG - 2011-04-17 13:36:15 --> Controller Class Initialized
DEBUG - 2011-04-17 13:36:15 --> Model Class Initialized
DEBUG - 2011-04-17 13:36:15 --> Model Class Initialized
DEBUG - 2011-04-17 13:36:15 --> Model Class Initialized
DEBUG - 2011-04-17 13:36:15 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-17 13:36:15 --> Database Driver Class Initialized
DEBUG - 2011-04-17 13:36:15 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-17 13:36:15 --> Helper loaded: url_helper
DEBUG - 2011-04-17 13:36:15 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-17 13:36:15 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-17 13:36:15 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-17 13:36:15 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-17 13:36:15 --> Final output sent to browser
DEBUG - 2011-04-17 13:36:15 --> Total execution time: 0.2055
DEBUG - 2011-04-17 13:36:19 --> Config Class Initialized
DEBUG - 2011-04-17 13:36:19 --> Hooks Class Initialized
DEBUG - 2011-04-17 13:36:19 --> Utf8 Class Initialized
DEBUG - 2011-04-17 13:36:19 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 13:36:19 --> URI Class Initialized
DEBUG - 2011-04-17 13:36:19 --> Router Class Initialized
DEBUG - 2011-04-17 13:36:19 --> Output Class Initialized
DEBUG - 2011-04-17 13:36:19 --> Input Class Initialized
DEBUG - 2011-04-17 13:36:19 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-17 13:36:19 --> Language Class Initialized
DEBUG - 2011-04-17 13:36:19 --> Loader Class Initialized
DEBUG - 2011-04-17 13:36:19 --> Controller Class Initialized
DEBUG - 2011-04-17 13:36:19 --> Model Class Initialized
DEBUG - 2011-04-17 13:36:19 --> Model Class Initialized
DEBUG - 2011-04-17 13:36:19 --> Model Class Initialized
DEBUG - 2011-04-17 13:36:19 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-17 13:36:19 --> Database Driver Class Initialized
DEBUG - 2011-04-17 13:36:19 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-17 13:36:19 --> Helper loaded: url_helper
DEBUG - 2011-04-17 13:36:19 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-17 13:36:19 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-17 13:36:19 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-17 13:36:19 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-17 13:36:19 --> Final output sent to browser
DEBUG - 2011-04-17 13:36:19 --> Total execution time: 0.0444
DEBUG - 2011-04-17 13:36:34 --> Config Class Initialized
DEBUG - 2011-04-17 13:36:34 --> Hooks Class Initialized
DEBUG - 2011-04-17 13:36:34 --> Utf8 Class Initialized
DEBUG - 2011-04-17 13:36:34 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 13:36:34 --> URI Class Initialized
DEBUG - 2011-04-17 13:36:34 --> Router Class Initialized
DEBUG - 2011-04-17 13:36:34 --> Output Class Initialized
DEBUG - 2011-04-17 13:36:34 --> Input Class Initialized
DEBUG - 2011-04-17 13:36:34 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-17 13:36:34 --> Language Class Initialized
DEBUG - 2011-04-17 13:36:34 --> Loader Class Initialized
DEBUG - 2011-04-17 13:36:34 --> Controller Class Initialized
DEBUG - 2011-04-17 13:36:34 --> Model Class Initialized
DEBUG - 2011-04-17 13:36:34 --> Model Class Initialized
DEBUG - 2011-04-17 13:36:34 --> Model Class Initialized
DEBUG - 2011-04-17 13:36:34 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-17 13:36:34 --> Database Driver Class Initialized
DEBUG - 2011-04-17 13:36:34 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-17 13:36:34 --> Helper loaded: url_helper
DEBUG - 2011-04-17 13:36:34 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-17 13:36:34 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-17 13:36:34 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-17 13:36:34 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-17 13:36:34 --> Final output sent to browser
DEBUG - 2011-04-17 13:36:34 --> Total execution time: 0.1908
DEBUG - 2011-04-17 13:52:28 --> Config Class Initialized
DEBUG - 2011-04-17 13:52:28 --> Hooks Class Initialized
DEBUG - 2011-04-17 13:52:28 --> Utf8 Class Initialized
DEBUG - 2011-04-17 13:52:28 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 13:52:28 --> URI Class Initialized
DEBUG - 2011-04-17 13:52:28 --> Router Class Initialized
DEBUG - 2011-04-17 13:52:28 --> Output Class Initialized
DEBUG - 2011-04-17 13:52:28 --> Input Class Initialized
DEBUG - 2011-04-17 13:52:28 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-17 13:52:28 --> Language Class Initialized
DEBUG - 2011-04-17 13:52:28 --> Loader Class Initialized
DEBUG - 2011-04-17 13:52:28 --> Controller Class Initialized
DEBUG - 2011-04-17 13:52:28 --> Model Class Initialized
DEBUG - 2011-04-17 13:52:28 --> Model Class Initialized
DEBUG - 2011-04-17 13:52:28 --> Model Class Initialized
DEBUG - 2011-04-17 13:52:28 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-17 13:52:28 --> Database Driver Class Initialized
DEBUG - 2011-04-17 13:52:28 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-17 13:52:28 --> Helper loaded: url_helper
DEBUG - 2011-04-17 13:52:28 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-17 13:52:28 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-17 13:52:28 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-17 13:52:28 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-17 13:52:28 --> Final output sent to browser
DEBUG - 2011-04-17 13:52:28 --> Total execution time: 0.3571
DEBUG - 2011-04-17 13:52:33 --> Config Class Initialized
DEBUG - 2011-04-17 13:52:33 --> Hooks Class Initialized
DEBUG - 2011-04-17 13:52:33 --> Utf8 Class Initialized
DEBUG - 2011-04-17 13:52:33 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 13:52:33 --> URI Class Initialized
DEBUG - 2011-04-17 13:52:33 --> Router Class Initialized
ERROR - 2011-04-17 13:52:33 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-17 13:52:33 --> Config Class Initialized
DEBUG - 2011-04-17 13:52:33 --> Hooks Class Initialized
DEBUG - 2011-04-17 13:52:33 --> Utf8 Class Initialized
DEBUG - 2011-04-17 13:52:33 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 13:52:33 --> URI Class Initialized
DEBUG - 2011-04-17 13:52:33 --> Router Class Initialized
ERROR - 2011-04-17 13:52:33 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-17 13:52:34 --> Config Class Initialized
DEBUG - 2011-04-17 13:52:34 --> Hooks Class Initialized
DEBUG - 2011-04-17 13:52:34 --> Utf8 Class Initialized
DEBUG - 2011-04-17 13:52:34 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 13:52:34 --> URI Class Initialized
DEBUG - 2011-04-17 13:52:34 --> Router Class Initialized
ERROR - 2011-04-17 13:52:34 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-17 13:53:22 --> Config Class Initialized
DEBUG - 2011-04-17 13:53:22 --> Hooks Class Initialized
DEBUG - 2011-04-17 13:53:22 --> Utf8 Class Initialized
DEBUG - 2011-04-17 13:53:22 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 13:53:22 --> URI Class Initialized
DEBUG - 2011-04-17 13:53:22 --> Router Class Initialized
DEBUG - 2011-04-17 13:53:22 --> Output Class Initialized
DEBUG - 2011-04-17 13:53:22 --> Input Class Initialized
DEBUG - 2011-04-17 13:53:22 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-17 13:53:22 --> Language Class Initialized
DEBUG - 2011-04-17 13:53:22 --> Loader Class Initialized
DEBUG - 2011-04-17 13:53:22 --> Controller Class Initialized
ERROR - 2011-04-17 13:53:22 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-17 13:53:22 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-17 13:53:22 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-17 13:53:22 --> Model Class Initialized
DEBUG - 2011-04-17 13:53:22 --> Model Class Initialized
DEBUG - 2011-04-17 13:53:22 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-17 13:53:22 --> Database Driver Class Initialized
DEBUG - 2011-04-17 13:53:22 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-17 13:53:22 --> Helper loaded: url_helper
DEBUG - 2011-04-17 13:53:22 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-17 13:53:22 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-17 13:53:22 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-17 13:53:22 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-17 13:53:22 --> Final output sent to browser
DEBUG - 2011-04-17 13:53:22 --> Total execution time: 0.1191
DEBUG - 2011-04-17 13:56:41 --> Config Class Initialized
DEBUG - 2011-04-17 13:56:41 --> Hooks Class Initialized
DEBUG - 2011-04-17 13:56:41 --> Utf8 Class Initialized
DEBUG - 2011-04-17 13:56:41 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 13:56:41 --> URI Class Initialized
DEBUG - 2011-04-17 13:56:41 --> Router Class Initialized
DEBUG - 2011-04-17 13:56:41 --> Output Class Initialized
DEBUG - 2011-04-17 13:56:41 --> Input Class Initialized
DEBUG - 2011-04-17 13:56:41 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-17 13:56:41 --> Language Class Initialized
DEBUG - 2011-04-17 13:56:41 --> Loader Class Initialized
DEBUG - 2011-04-17 13:56:41 --> Controller Class Initialized
DEBUG - 2011-04-17 13:56:41 --> Model Class Initialized
DEBUG - 2011-04-17 13:56:41 --> Model Class Initialized
DEBUG - 2011-04-17 13:56:41 --> Model Class Initialized
DEBUG - 2011-04-17 13:56:41 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-17 13:56:41 --> Database Driver Class Initialized
DEBUG - 2011-04-17 13:56:41 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-17 13:56:41 --> Helper loaded: url_helper
DEBUG - 2011-04-17 13:56:41 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-17 13:56:41 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-17 13:56:41 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-17 13:56:41 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-17 13:56:41 --> Final output sent to browser
DEBUG - 2011-04-17 13:56:41 --> Total execution time: 0.1130
DEBUG - 2011-04-17 13:56:48 --> Config Class Initialized
DEBUG - 2011-04-17 13:56:48 --> Hooks Class Initialized
DEBUG - 2011-04-17 13:56:48 --> Utf8 Class Initialized
DEBUG - 2011-04-17 13:56:48 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 13:56:48 --> URI Class Initialized
DEBUG - 2011-04-17 13:56:48 --> Router Class Initialized
ERROR - 2011-04-17 13:56:48 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-17 13:56:48 --> Config Class Initialized
DEBUG - 2011-04-17 13:56:48 --> Hooks Class Initialized
DEBUG - 2011-04-17 13:56:48 --> Utf8 Class Initialized
DEBUG - 2011-04-17 13:56:48 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 13:56:48 --> URI Class Initialized
DEBUG - 2011-04-17 13:56:48 --> Router Class Initialized
ERROR - 2011-04-17 13:56:48 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-17 13:56:54 --> Config Class Initialized
DEBUG - 2011-04-17 13:56:54 --> Hooks Class Initialized
DEBUG - 2011-04-17 13:56:54 --> Utf8 Class Initialized
DEBUG - 2011-04-17 13:56:54 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 13:56:54 --> URI Class Initialized
DEBUG - 2011-04-17 13:56:54 --> Router Class Initialized
DEBUG - 2011-04-17 13:56:54 --> Output Class Initialized
DEBUG - 2011-04-17 13:56:54 --> Input Class Initialized
DEBUG - 2011-04-17 13:56:54 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-17 13:56:54 --> Language Class Initialized
DEBUG - 2011-04-17 13:56:54 --> Loader Class Initialized
DEBUG - 2011-04-17 13:56:54 --> Controller Class Initialized
DEBUG - 2011-04-17 13:56:54 --> Model Class Initialized
DEBUG - 2011-04-17 13:56:54 --> Model Class Initialized
DEBUG - 2011-04-17 13:56:54 --> Model Class Initialized
DEBUG - 2011-04-17 13:56:54 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-17 13:56:54 --> Database Driver Class Initialized
DEBUG - 2011-04-17 13:56:55 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-17 13:56:55 --> Helper loaded: url_helper
DEBUG - 2011-04-17 13:56:55 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-17 13:56:55 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-17 13:56:55 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-17 13:56:55 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-17 13:56:55 --> Final output sent to browser
DEBUG - 2011-04-17 13:56:55 --> Total execution time: 0.4070
DEBUG - 2011-04-17 13:56:59 --> Config Class Initialized
DEBUG - 2011-04-17 13:56:59 --> Hooks Class Initialized
DEBUG - 2011-04-17 13:56:59 --> Utf8 Class Initialized
DEBUG - 2011-04-17 13:56:59 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 13:56:59 --> URI Class Initialized
DEBUG - 2011-04-17 13:56:59 --> Router Class Initialized
DEBUG - 2011-04-17 13:56:59 --> Output Class Initialized
DEBUG - 2011-04-17 13:56:59 --> Input Class Initialized
DEBUG - 2011-04-17 13:56:59 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-17 13:56:59 --> Language Class Initialized
DEBUG - 2011-04-17 13:56:59 --> Loader Class Initialized
DEBUG - 2011-04-17 13:56:59 --> Controller Class Initialized
DEBUG - 2011-04-17 13:56:59 --> Model Class Initialized
DEBUG - 2011-04-17 13:56:59 --> Model Class Initialized
DEBUG - 2011-04-17 13:56:59 --> Model Class Initialized
DEBUG - 2011-04-17 13:56:59 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-17 13:56:59 --> Database Driver Class Initialized
DEBUG - 2011-04-17 13:56:59 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-17 13:56:59 --> Helper loaded: url_helper
DEBUG - 2011-04-17 13:56:59 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-17 13:56:59 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-17 13:56:59 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-17 13:56:59 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-17 13:56:59 --> Final output sent to browser
DEBUG - 2011-04-17 13:56:59 --> Total execution time: 0.0956
DEBUG - 2011-04-17 13:56:59 --> Config Class Initialized
DEBUG - 2011-04-17 13:56:59 --> Hooks Class Initialized
DEBUG - 2011-04-17 13:56:59 --> Utf8 Class Initialized
DEBUG - 2011-04-17 13:56:59 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 13:56:59 --> URI Class Initialized
DEBUG - 2011-04-17 13:56:59 --> Router Class Initialized
DEBUG - 2011-04-17 13:56:59 --> Output Class Initialized
DEBUG - 2011-04-17 13:56:59 --> Input Class Initialized
DEBUG - 2011-04-17 13:56:59 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-17 13:56:59 --> Language Class Initialized
DEBUG - 2011-04-17 13:56:59 --> Loader Class Initialized
DEBUG - 2011-04-17 13:56:59 --> Controller Class Initialized
DEBUG - 2011-04-17 13:56:59 --> Model Class Initialized
DEBUG - 2011-04-17 13:56:59 --> Model Class Initialized
DEBUG - 2011-04-17 13:56:59 --> Model Class Initialized
DEBUG - 2011-04-17 13:56:59 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-17 13:56:59 --> Database Driver Class Initialized
DEBUG - 2011-04-17 13:56:59 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-17 13:56:59 --> Helper loaded: url_helper
DEBUG - 2011-04-17 13:56:59 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-17 13:56:59 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-17 13:56:59 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-17 13:56:59 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-17 13:57:00 --> Final output sent to browser
DEBUG - 2011-04-17 13:57:00 --> Total execution time: 0.1033
DEBUG - 2011-04-17 13:57:11 --> Config Class Initialized
DEBUG - 2011-04-17 13:57:11 --> Hooks Class Initialized
DEBUG - 2011-04-17 13:57:11 --> Utf8 Class Initialized
DEBUG - 2011-04-17 13:57:11 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 13:57:11 --> URI Class Initialized
DEBUG - 2011-04-17 13:57:11 --> Router Class Initialized
DEBUG - 2011-04-17 13:57:11 --> Output Class Initialized
DEBUG - 2011-04-17 13:57:11 --> Input Class Initialized
DEBUG - 2011-04-17 13:57:11 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-17 13:57:11 --> Language Class Initialized
DEBUG - 2011-04-17 13:57:11 --> Loader Class Initialized
DEBUG - 2011-04-17 13:57:11 --> Controller Class Initialized
DEBUG - 2011-04-17 13:57:11 --> Model Class Initialized
DEBUG - 2011-04-17 13:57:11 --> Model Class Initialized
DEBUG - 2011-04-17 13:57:11 --> Model Class Initialized
DEBUG - 2011-04-17 13:57:11 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-17 13:57:11 --> Database Driver Class Initialized
DEBUG - 2011-04-17 13:57:11 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-17 13:57:11 --> Helper loaded: url_helper
DEBUG - 2011-04-17 13:57:11 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-17 13:57:11 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-17 13:57:11 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-17 13:57:11 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-17 13:57:11 --> Final output sent to browser
DEBUG - 2011-04-17 13:57:11 --> Total execution time: 0.3045
DEBUG - 2011-04-17 13:57:15 --> Config Class Initialized
DEBUG - 2011-04-17 13:57:15 --> Hooks Class Initialized
DEBUG - 2011-04-17 13:57:15 --> Utf8 Class Initialized
DEBUG - 2011-04-17 13:57:15 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 13:57:15 --> URI Class Initialized
DEBUG - 2011-04-17 13:57:15 --> Router Class Initialized
DEBUG - 2011-04-17 13:57:15 --> Output Class Initialized
DEBUG - 2011-04-17 13:57:15 --> Input Class Initialized
DEBUG - 2011-04-17 13:57:15 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-17 13:57:15 --> Language Class Initialized
DEBUG - 2011-04-17 13:57:15 --> Loader Class Initialized
DEBUG - 2011-04-17 13:57:15 --> Controller Class Initialized
DEBUG - 2011-04-17 13:57:15 --> Model Class Initialized
DEBUG - 2011-04-17 13:57:15 --> Model Class Initialized
DEBUG - 2011-04-17 13:57:15 --> Model Class Initialized
DEBUG - 2011-04-17 13:57:15 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-17 13:57:15 --> Database Driver Class Initialized
DEBUG - 2011-04-17 13:57:15 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-17 13:57:15 --> Helper loaded: url_helper
DEBUG - 2011-04-17 13:57:15 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-17 13:57:15 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-17 13:57:15 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-17 13:57:15 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-17 13:57:15 --> Final output sent to browser
DEBUG - 2011-04-17 13:57:15 --> Total execution time: 0.0501
DEBUG - 2011-04-17 13:57:30 --> Config Class Initialized
DEBUG - 2011-04-17 13:57:30 --> Hooks Class Initialized
DEBUG - 2011-04-17 13:57:30 --> Utf8 Class Initialized
DEBUG - 2011-04-17 13:57:30 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 13:57:30 --> URI Class Initialized
DEBUG - 2011-04-17 13:57:30 --> Router Class Initialized
DEBUG - 2011-04-17 13:57:30 --> Output Class Initialized
DEBUG - 2011-04-17 13:57:30 --> Input Class Initialized
DEBUG - 2011-04-17 13:57:30 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-17 13:57:30 --> Language Class Initialized
DEBUG - 2011-04-17 13:57:30 --> Loader Class Initialized
DEBUG - 2011-04-17 13:57:30 --> Controller Class Initialized
DEBUG - 2011-04-17 13:57:30 --> Model Class Initialized
DEBUG - 2011-04-17 13:57:30 --> Model Class Initialized
DEBUG - 2011-04-17 13:57:30 --> Model Class Initialized
DEBUG - 2011-04-17 13:57:30 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-17 13:57:30 --> Database Driver Class Initialized
DEBUG - 2011-04-17 13:57:31 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-17 13:57:31 --> Helper loaded: url_helper
DEBUG - 2011-04-17 13:57:31 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-17 13:57:31 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-17 13:57:31 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-17 13:57:31 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-17 13:57:31 --> Final output sent to browser
DEBUG - 2011-04-17 13:57:31 --> Total execution time: 0.8155
DEBUG - 2011-04-17 13:57:34 --> Config Class Initialized
DEBUG - 2011-04-17 13:57:34 --> Hooks Class Initialized
DEBUG - 2011-04-17 13:57:34 --> Utf8 Class Initialized
DEBUG - 2011-04-17 13:57:34 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 13:57:34 --> URI Class Initialized
DEBUG - 2011-04-17 13:57:34 --> Router Class Initialized
DEBUG - 2011-04-17 13:57:34 --> Output Class Initialized
DEBUG - 2011-04-17 13:57:34 --> Input Class Initialized
DEBUG - 2011-04-17 13:57:34 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-17 13:57:34 --> Language Class Initialized
DEBUG - 2011-04-17 13:57:34 --> Loader Class Initialized
DEBUG - 2011-04-17 13:57:34 --> Controller Class Initialized
DEBUG - 2011-04-17 13:57:34 --> Model Class Initialized
DEBUG - 2011-04-17 13:57:34 --> Model Class Initialized
DEBUG - 2011-04-17 13:57:34 --> Model Class Initialized
DEBUG - 2011-04-17 13:57:34 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-17 13:57:34 --> Database Driver Class Initialized
DEBUG - 2011-04-17 13:57:34 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-17 13:57:34 --> Helper loaded: url_helper
DEBUG - 2011-04-17 13:57:34 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-17 13:57:34 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-17 13:57:34 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-17 13:57:34 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-17 13:57:34 --> Final output sent to browser
DEBUG - 2011-04-17 13:57:34 --> Total execution time: 0.1352
DEBUG - 2011-04-17 13:57:47 --> Config Class Initialized
DEBUG - 2011-04-17 13:57:47 --> Hooks Class Initialized
DEBUG - 2011-04-17 13:57:47 --> Utf8 Class Initialized
DEBUG - 2011-04-17 13:57:47 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 13:57:47 --> URI Class Initialized
DEBUG - 2011-04-17 13:57:47 --> Router Class Initialized
DEBUG - 2011-04-17 13:57:47 --> Output Class Initialized
DEBUG - 2011-04-17 13:57:47 --> Input Class Initialized
DEBUG - 2011-04-17 13:57:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-17 13:57:47 --> Language Class Initialized
DEBUG - 2011-04-17 13:57:47 --> Loader Class Initialized
DEBUG - 2011-04-17 13:57:47 --> Controller Class Initialized
DEBUG - 2011-04-17 13:57:47 --> Model Class Initialized
DEBUG - 2011-04-17 13:57:47 --> Model Class Initialized
DEBUG - 2011-04-17 13:57:47 --> Model Class Initialized
DEBUG - 2011-04-17 13:57:47 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-17 13:57:47 --> Database Driver Class Initialized
DEBUG - 2011-04-17 13:57:47 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-17 13:57:47 --> Helper loaded: url_helper
DEBUG - 2011-04-17 13:57:47 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-17 13:57:47 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-17 13:57:47 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-17 13:57:47 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-17 13:57:47 --> Final output sent to browser
DEBUG - 2011-04-17 13:57:47 --> Total execution time: 0.2448
DEBUG - 2011-04-17 13:58:15 --> Config Class Initialized
DEBUG - 2011-04-17 13:58:15 --> Hooks Class Initialized
DEBUG - 2011-04-17 13:58:15 --> Utf8 Class Initialized
DEBUG - 2011-04-17 13:58:15 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 13:58:15 --> URI Class Initialized
DEBUG - 2011-04-17 13:58:15 --> Router Class Initialized
DEBUG - 2011-04-17 13:58:15 --> Output Class Initialized
DEBUG - 2011-04-17 13:58:15 --> Input Class Initialized
DEBUG - 2011-04-17 13:58:15 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-17 13:58:15 --> Language Class Initialized
DEBUG - 2011-04-17 13:58:15 --> Loader Class Initialized
DEBUG - 2011-04-17 13:58:15 --> Controller Class Initialized
DEBUG - 2011-04-17 13:58:15 --> Model Class Initialized
DEBUG - 2011-04-17 13:58:15 --> Model Class Initialized
DEBUG - 2011-04-17 13:58:15 --> Model Class Initialized
DEBUG - 2011-04-17 13:58:15 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-17 13:58:16 --> Database Driver Class Initialized
DEBUG - 2011-04-17 13:58:16 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-17 13:58:16 --> Helper loaded: url_helper
DEBUG - 2011-04-17 13:58:16 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-17 13:58:16 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-17 13:58:16 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-17 13:58:16 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-17 13:58:16 --> Final output sent to browser
DEBUG - 2011-04-17 13:58:16 --> Total execution time: 1.3920
DEBUG - 2011-04-17 13:58:36 --> Config Class Initialized
DEBUG - 2011-04-17 13:58:36 --> Hooks Class Initialized
DEBUG - 2011-04-17 13:58:36 --> Utf8 Class Initialized
DEBUG - 2011-04-17 13:58:36 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 13:58:36 --> URI Class Initialized
DEBUG - 2011-04-17 13:58:36 --> Router Class Initialized
DEBUG - 2011-04-17 13:58:36 --> Output Class Initialized
DEBUG - 2011-04-17 13:58:36 --> Input Class Initialized
DEBUG - 2011-04-17 13:58:36 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-17 13:58:36 --> Language Class Initialized
DEBUG - 2011-04-17 13:58:36 --> Loader Class Initialized
DEBUG - 2011-04-17 13:58:36 --> Controller Class Initialized
DEBUG - 2011-04-17 13:58:36 --> Model Class Initialized
DEBUG - 2011-04-17 13:58:36 --> Model Class Initialized
DEBUG - 2011-04-17 13:58:36 --> Model Class Initialized
DEBUG - 2011-04-17 13:58:36 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-17 13:58:36 --> Database Driver Class Initialized
DEBUG - 2011-04-17 13:58:36 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-17 13:58:36 --> Helper loaded: url_helper
DEBUG - 2011-04-17 13:58:36 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-17 13:58:36 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-17 13:58:36 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-17 13:58:36 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-17 13:58:36 --> Final output sent to browser
DEBUG - 2011-04-17 13:58:36 --> Total execution time: 0.4886
DEBUG - 2011-04-17 13:58:57 --> Config Class Initialized
DEBUG - 2011-04-17 13:58:57 --> Hooks Class Initialized
DEBUG - 2011-04-17 13:58:57 --> Utf8 Class Initialized
DEBUG - 2011-04-17 13:58:57 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 13:58:57 --> URI Class Initialized
DEBUG - 2011-04-17 13:58:57 --> Router Class Initialized
DEBUG - 2011-04-17 13:58:57 --> Output Class Initialized
DEBUG - 2011-04-17 13:58:57 --> Input Class Initialized
DEBUG - 2011-04-17 13:58:57 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-17 13:58:57 --> Language Class Initialized
DEBUG - 2011-04-17 13:58:57 --> Loader Class Initialized
DEBUG - 2011-04-17 13:58:57 --> Controller Class Initialized
DEBUG - 2011-04-17 13:58:57 --> Model Class Initialized
DEBUG - 2011-04-17 13:58:57 --> Model Class Initialized
DEBUG - 2011-04-17 13:58:57 --> Model Class Initialized
DEBUG - 2011-04-17 13:58:57 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-17 13:58:57 --> Database Driver Class Initialized
DEBUG - 2011-04-17 13:58:57 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-17 13:58:57 --> Helper loaded: url_helper
DEBUG - 2011-04-17 13:58:57 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-17 13:58:57 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-17 13:58:57 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-17 13:58:57 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-17 13:58:57 --> Final output sent to browser
DEBUG - 2011-04-17 13:58:57 --> Total execution time: 0.2364
DEBUG - 2011-04-17 13:59:17 --> Config Class Initialized
DEBUG - 2011-04-17 13:59:17 --> Hooks Class Initialized
DEBUG - 2011-04-17 13:59:17 --> Utf8 Class Initialized
DEBUG - 2011-04-17 13:59:17 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 13:59:17 --> URI Class Initialized
DEBUG - 2011-04-17 13:59:17 --> Router Class Initialized
DEBUG - 2011-04-17 13:59:17 --> Output Class Initialized
DEBUG - 2011-04-17 13:59:17 --> Input Class Initialized
DEBUG - 2011-04-17 13:59:17 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-17 13:59:17 --> Language Class Initialized
DEBUG - 2011-04-17 13:59:18 --> Loader Class Initialized
DEBUG - 2011-04-17 13:59:18 --> Controller Class Initialized
DEBUG - 2011-04-17 13:59:18 --> Model Class Initialized
DEBUG - 2011-04-17 13:59:18 --> Model Class Initialized
DEBUG - 2011-04-17 13:59:18 --> Model Class Initialized
DEBUG - 2011-04-17 13:59:18 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-17 13:59:18 --> Database Driver Class Initialized
DEBUG - 2011-04-17 13:59:18 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-17 13:59:18 --> Helper loaded: url_helper
DEBUG - 2011-04-17 13:59:18 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-17 13:59:18 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-17 13:59:18 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-17 13:59:18 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-17 13:59:18 --> Final output sent to browser
DEBUG - 2011-04-17 13:59:18 --> Total execution time: 0.2591
DEBUG - 2011-04-17 14:03:18 --> Config Class Initialized
DEBUG - 2011-04-17 14:03:18 --> Hooks Class Initialized
DEBUG - 2011-04-17 14:03:18 --> Utf8 Class Initialized
DEBUG - 2011-04-17 14:03:18 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 14:03:18 --> URI Class Initialized
DEBUG - 2011-04-17 14:03:18 --> Router Class Initialized
DEBUG - 2011-04-17 14:03:18 --> Output Class Initialized
DEBUG - 2011-04-17 14:03:18 --> Input Class Initialized
DEBUG - 2011-04-17 14:03:18 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-17 14:03:18 --> Language Class Initialized
DEBUG - 2011-04-17 14:03:18 --> Loader Class Initialized
DEBUG - 2011-04-17 14:03:18 --> Controller Class Initialized
DEBUG - 2011-04-17 14:03:18 --> Model Class Initialized
DEBUG - 2011-04-17 14:03:18 --> Model Class Initialized
DEBUG - 2011-04-17 14:03:18 --> Model Class Initialized
DEBUG - 2011-04-17 14:03:18 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-17 14:03:18 --> Database Driver Class Initialized
DEBUG - 2011-04-17 14:03:18 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-17 14:03:18 --> Helper loaded: url_helper
DEBUG - 2011-04-17 14:03:18 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-17 14:03:18 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-17 14:03:18 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-17 14:03:18 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-17 14:03:18 --> Final output sent to browser
DEBUG - 2011-04-17 14:03:18 --> Total execution time: 0.2080
DEBUG - 2011-04-17 14:03:20 --> Config Class Initialized
DEBUG - 2011-04-17 14:03:20 --> Hooks Class Initialized
DEBUG - 2011-04-17 14:03:20 --> Utf8 Class Initialized
DEBUG - 2011-04-17 14:03:20 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 14:03:20 --> URI Class Initialized
DEBUG - 2011-04-17 14:03:20 --> Router Class Initialized
ERROR - 2011-04-17 14:03:20 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-17 14:03:22 --> Config Class Initialized
DEBUG - 2011-04-17 14:03:22 --> Hooks Class Initialized
DEBUG - 2011-04-17 14:03:22 --> Utf8 Class Initialized
DEBUG - 2011-04-17 14:03:22 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 14:03:22 --> URI Class Initialized
DEBUG - 2011-04-17 14:03:22 --> Router Class Initialized
ERROR - 2011-04-17 14:03:22 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-17 14:09:37 --> Config Class Initialized
DEBUG - 2011-04-17 14:09:37 --> Hooks Class Initialized
DEBUG - 2011-04-17 14:09:37 --> Utf8 Class Initialized
DEBUG - 2011-04-17 14:09:37 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 14:09:37 --> URI Class Initialized
DEBUG - 2011-04-17 14:09:37 --> Router Class Initialized
DEBUG - 2011-04-17 14:09:37 --> Output Class Initialized
DEBUG - 2011-04-17 14:09:37 --> Input Class Initialized
DEBUG - 2011-04-17 14:09:37 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-17 14:09:37 --> Language Class Initialized
DEBUG - 2011-04-17 14:09:37 --> Loader Class Initialized
DEBUG - 2011-04-17 14:09:37 --> Controller Class Initialized
DEBUG - 2011-04-17 14:09:37 --> Model Class Initialized
DEBUG - 2011-04-17 14:09:37 --> Model Class Initialized
DEBUG - 2011-04-17 14:09:37 --> Model Class Initialized
DEBUG - 2011-04-17 14:09:37 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-17 14:09:37 --> Database Driver Class Initialized
DEBUG - 2011-04-17 14:09:37 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-17 14:09:37 --> Helper loaded: url_helper
DEBUG - 2011-04-17 14:09:37 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-17 14:09:37 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-17 14:09:37 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-17 14:09:37 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-17 14:09:37 --> Final output sent to browser
DEBUG - 2011-04-17 14:09:37 --> Total execution time: 0.0500
DEBUG - 2011-04-17 14:09:55 --> Config Class Initialized
DEBUG - 2011-04-17 14:09:55 --> Hooks Class Initialized
DEBUG - 2011-04-17 14:09:55 --> Utf8 Class Initialized
DEBUG - 2011-04-17 14:09:55 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 14:09:55 --> URI Class Initialized
DEBUG - 2011-04-17 14:09:55 --> Router Class Initialized
DEBUG - 2011-04-17 14:09:55 --> Output Class Initialized
DEBUG - 2011-04-17 14:09:55 --> Input Class Initialized
DEBUG - 2011-04-17 14:09:55 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-17 14:09:55 --> Language Class Initialized
DEBUG - 2011-04-17 14:09:55 --> Loader Class Initialized
DEBUG - 2011-04-17 14:09:55 --> Controller Class Initialized
ERROR - 2011-04-17 14:09:55 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-17 14:09:55 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-17 14:09:55 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-17 14:09:55 --> Model Class Initialized
DEBUG - 2011-04-17 14:09:55 --> Model Class Initialized
DEBUG - 2011-04-17 14:09:55 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-17 14:09:55 --> Database Driver Class Initialized
DEBUG - 2011-04-17 14:09:55 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-17 14:09:55 --> Helper loaded: url_helper
DEBUG - 2011-04-17 14:09:55 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-17 14:09:55 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-17 14:09:55 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-17 14:09:55 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-17 14:09:55 --> Final output sent to browser
DEBUG - 2011-04-17 14:09:55 --> Total execution time: 0.1323
DEBUG - 2011-04-17 14:09:56 --> Config Class Initialized
DEBUG - 2011-04-17 14:09:56 --> Hooks Class Initialized
DEBUG - 2011-04-17 14:09:56 --> Utf8 Class Initialized
DEBUG - 2011-04-17 14:09:56 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 14:09:56 --> URI Class Initialized
DEBUG - 2011-04-17 14:09:56 --> Router Class Initialized
DEBUG - 2011-04-17 14:09:56 --> Output Class Initialized
DEBUG - 2011-04-17 14:09:56 --> Input Class Initialized
DEBUG - 2011-04-17 14:09:56 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-17 14:09:56 --> Language Class Initialized
DEBUG - 2011-04-17 14:09:56 --> Loader Class Initialized
DEBUG - 2011-04-17 14:09:56 --> Controller Class Initialized
DEBUG - 2011-04-17 14:09:56 --> Model Class Initialized
DEBUG - 2011-04-17 14:09:56 --> Model Class Initialized
DEBUG - 2011-04-17 14:09:56 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-17 14:09:56 --> Database Driver Class Initialized
DEBUG - 2011-04-17 14:09:57 --> Final output sent to browser
DEBUG - 2011-04-17 14:09:57 --> Total execution time: 0.8314
DEBUG - 2011-04-17 14:10:53 --> Config Class Initialized
DEBUG - 2011-04-17 14:10:53 --> Hooks Class Initialized
DEBUG - 2011-04-17 14:10:53 --> Utf8 Class Initialized
DEBUG - 2011-04-17 14:10:53 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 14:10:53 --> URI Class Initialized
DEBUG - 2011-04-17 14:10:53 --> Router Class Initialized
DEBUG - 2011-04-17 14:10:53 --> Output Class Initialized
DEBUG - 2011-04-17 14:10:53 --> Input Class Initialized
DEBUG - 2011-04-17 14:10:53 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-17 14:10:53 --> Language Class Initialized
DEBUG - 2011-04-17 14:10:53 --> Loader Class Initialized
DEBUG - 2011-04-17 14:10:53 --> Controller Class Initialized
ERROR - 2011-04-17 14:10:53 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-17 14:10:53 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-17 14:10:53 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-17 14:10:53 --> Model Class Initialized
DEBUG - 2011-04-17 14:10:53 --> Model Class Initialized
DEBUG - 2011-04-17 14:10:53 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-17 14:10:53 --> Database Driver Class Initialized
DEBUG - 2011-04-17 14:10:53 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-17 14:10:53 --> Helper loaded: url_helper
DEBUG - 2011-04-17 14:10:53 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-17 14:10:53 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-17 14:10:53 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-17 14:10:53 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-17 14:10:53 --> Final output sent to browser
DEBUG - 2011-04-17 14:10:53 --> Total execution time: 0.0644
DEBUG - 2011-04-17 14:10:54 --> Config Class Initialized
DEBUG - 2011-04-17 14:10:54 --> Hooks Class Initialized
DEBUG - 2011-04-17 14:10:54 --> Utf8 Class Initialized
DEBUG - 2011-04-17 14:10:54 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 14:10:54 --> URI Class Initialized
DEBUG - 2011-04-17 14:10:54 --> Router Class Initialized
DEBUG - 2011-04-17 14:10:54 --> Output Class Initialized
DEBUG - 2011-04-17 14:10:54 --> Input Class Initialized
DEBUG - 2011-04-17 14:10:54 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-17 14:10:54 --> Language Class Initialized
DEBUG - 2011-04-17 14:10:54 --> Loader Class Initialized
DEBUG - 2011-04-17 14:10:54 --> Controller Class Initialized
DEBUG - 2011-04-17 14:10:54 --> Model Class Initialized
DEBUG - 2011-04-17 14:10:54 --> Model Class Initialized
DEBUG - 2011-04-17 14:10:54 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-17 14:10:54 --> Database Driver Class Initialized
DEBUG - 2011-04-17 14:10:54 --> Final output sent to browser
DEBUG - 2011-04-17 14:10:54 --> Total execution time: 0.6406
DEBUG - 2011-04-17 14:11:01 --> Config Class Initialized
DEBUG - 2011-04-17 14:11:01 --> Hooks Class Initialized
DEBUG - 2011-04-17 14:11:01 --> Utf8 Class Initialized
DEBUG - 2011-04-17 14:11:01 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 14:11:01 --> URI Class Initialized
DEBUG - 2011-04-17 14:11:01 --> Router Class Initialized
DEBUG - 2011-04-17 14:11:01 --> Output Class Initialized
DEBUG - 2011-04-17 14:11:01 --> Input Class Initialized
DEBUG - 2011-04-17 14:11:01 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-17 14:11:01 --> Language Class Initialized
DEBUG - 2011-04-17 14:11:01 --> Loader Class Initialized
DEBUG - 2011-04-17 14:11:01 --> Controller Class Initialized
ERROR - 2011-04-17 14:11:01 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-17 14:11:01 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-17 14:11:01 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-17 14:11:01 --> Model Class Initialized
DEBUG - 2011-04-17 14:11:01 --> Model Class Initialized
DEBUG - 2011-04-17 14:11:01 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-17 14:11:01 --> Database Driver Class Initialized
DEBUG - 2011-04-17 14:11:01 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-17 14:11:01 --> Helper loaded: url_helper
DEBUG - 2011-04-17 14:11:01 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-17 14:11:01 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-17 14:11:01 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-17 14:11:01 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-17 14:11:01 --> Final output sent to browser
DEBUG - 2011-04-17 14:11:01 --> Total execution time: 0.1299
DEBUG - 2011-04-17 14:11:02 --> Config Class Initialized
DEBUG - 2011-04-17 14:11:02 --> Hooks Class Initialized
DEBUG - 2011-04-17 14:11:02 --> Utf8 Class Initialized
DEBUG - 2011-04-17 14:11:02 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 14:11:02 --> URI Class Initialized
DEBUG - 2011-04-17 14:11:02 --> Router Class Initialized
DEBUG - 2011-04-17 14:11:02 --> Output Class Initialized
DEBUG - 2011-04-17 14:11:02 --> Input Class Initialized
DEBUG - 2011-04-17 14:11:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-17 14:11:02 --> Language Class Initialized
DEBUG - 2011-04-17 14:11:02 --> Loader Class Initialized
DEBUG - 2011-04-17 14:11:02 --> Controller Class Initialized
DEBUG - 2011-04-17 14:11:02 --> Model Class Initialized
DEBUG - 2011-04-17 14:11:02 --> Model Class Initialized
DEBUG - 2011-04-17 14:11:02 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-17 14:11:02 --> Database Driver Class Initialized
DEBUG - 2011-04-17 14:11:03 --> Final output sent to browser
DEBUG - 2011-04-17 14:11:03 --> Total execution time: 0.9384
DEBUG - 2011-04-17 14:11:19 --> Config Class Initialized
DEBUG - 2011-04-17 14:11:19 --> Hooks Class Initialized
DEBUG - 2011-04-17 14:11:19 --> Utf8 Class Initialized
DEBUG - 2011-04-17 14:11:19 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 14:11:19 --> URI Class Initialized
DEBUG - 2011-04-17 14:11:19 --> Router Class Initialized
DEBUG - 2011-04-17 14:11:19 --> Output Class Initialized
DEBUG - 2011-04-17 14:11:19 --> Input Class Initialized
DEBUG - 2011-04-17 14:11:19 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-17 14:11:19 --> Language Class Initialized
DEBUG - 2011-04-17 14:11:19 --> Loader Class Initialized
DEBUG - 2011-04-17 14:11:19 --> Controller Class Initialized
ERROR - 2011-04-17 14:11:19 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-17 14:11:19 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-17 14:11:19 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-17 14:11:19 --> Model Class Initialized
DEBUG - 2011-04-17 14:11:19 --> Model Class Initialized
DEBUG - 2011-04-17 14:11:19 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-17 14:11:19 --> Database Driver Class Initialized
DEBUG - 2011-04-17 14:11:19 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-17 14:11:19 --> Helper loaded: url_helper
DEBUG - 2011-04-17 14:11:19 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-17 14:11:19 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-17 14:11:19 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-17 14:11:19 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-17 14:11:19 --> Final output sent to browser
DEBUG - 2011-04-17 14:11:19 --> Total execution time: 0.0309
DEBUG - 2011-04-17 14:11:19 --> Config Class Initialized
DEBUG - 2011-04-17 14:11:19 --> Hooks Class Initialized
DEBUG - 2011-04-17 14:11:19 --> Utf8 Class Initialized
DEBUG - 2011-04-17 14:11:19 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 14:11:19 --> URI Class Initialized
DEBUG - 2011-04-17 14:11:19 --> Router Class Initialized
DEBUG - 2011-04-17 14:11:19 --> Output Class Initialized
DEBUG - 2011-04-17 14:11:19 --> Input Class Initialized
DEBUG - 2011-04-17 14:11:19 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-17 14:11:19 --> Language Class Initialized
DEBUG - 2011-04-17 14:11:19 --> Loader Class Initialized
DEBUG - 2011-04-17 14:11:19 --> Controller Class Initialized
DEBUG - 2011-04-17 14:11:19 --> Model Class Initialized
DEBUG - 2011-04-17 14:11:19 --> Model Class Initialized
DEBUG - 2011-04-17 14:11:19 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-17 14:11:19 --> Database Driver Class Initialized
DEBUG - 2011-04-17 14:11:20 --> Final output sent to browser
DEBUG - 2011-04-17 14:11:20 --> Total execution time: 0.5098
DEBUG - 2011-04-17 14:11:33 --> Config Class Initialized
DEBUG - 2011-04-17 14:11:33 --> Hooks Class Initialized
DEBUG - 2011-04-17 14:11:33 --> Utf8 Class Initialized
DEBUG - 2011-04-17 14:11:33 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 14:11:33 --> URI Class Initialized
DEBUG - 2011-04-17 14:11:33 --> Router Class Initialized
DEBUG - 2011-04-17 14:11:33 --> Output Class Initialized
DEBUG - 2011-04-17 14:11:33 --> Input Class Initialized
DEBUG - 2011-04-17 14:11:33 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-17 14:11:33 --> Language Class Initialized
DEBUG - 2011-04-17 14:11:33 --> Loader Class Initialized
DEBUG - 2011-04-17 14:11:33 --> Controller Class Initialized
ERROR - 2011-04-17 14:11:33 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-17 14:11:33 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-17 14:11:33 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-17 14:11:33 --> Model Class Initialized
DEBUG - 2011-04-17 14:11:33 --> Model Class Initialized
DEBUG - 2011-04-17 14:11:33 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-17 14:11:33 --> Database Driver Class Initialized
DEBUG - 2011-04-17 14:11:33 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-17 14:11:33 --> Helper loaded: url_helper
DEBUG - 2011-04-17 14:11:33 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-17 14:11:33 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-17 14:11:33 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-17 14:11:33 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-17 14:11:33 --> Final output sent to browser
DEBUG - 2011-04-17 14:11:33 --> Total execution time: 0.0529
DEBUG - 2011-04-17 14:11:34 --> Config Class Initialized
DEBUG - 2011-04-17 14:11:34 --> Hooks Class Initialized
DEBUG - 2011-04-17 14:11:34 --> Utf8 Class Initialized
DEBUG - 2011-04-17 14:11:34 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 14:11:34 --> URI Class Initialized
DEBUG - 2011-04-17 14:11:34 --> Router Class Initialized
DEBUG - 2011-04-17 14:11:34 --> Output Class Initialized
DEBUG - 2011-04-17 14:11:34 --> Input Class Initialized
DEBUG - 2011-04-17 14:11:34 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-17 14:11:34 --> Language Class Initialized
DEBUG - 2011-04-17 14:11:34 --> Loader Class Initialized
DEBUG - 2011-04-17 14:11:34 --> Controller Class Initialized
DEBUG - 2011-04-17 14:11:34 --> Model Class Initialized
DEBUG - 2011-04-17 14:11:34 --> Model Class Initialized
DEBUG - 2011-04-17 14:11:34 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-17 14:11:34 --> Database Driver Class Initialized
DEBUG - 2011-04-17 14:11:35 --> Final output sent to browser
DEBUG - 2011-04-17 14:11:35 --> Total execution time: 0.5649
DEBUG - 2011-04-17 14:11:43 --> Config Class Initialized
DEBUG - 2011-04-17 14:11:43 --> Hooks Class Initialized
DEBUG - 2011-04-17 14:11:43 --> Utf8 Class Initialized
DEBUG - 2011-04-17 14:11:43 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 14:11:43 --> URI Class Initialized
DEBUG - 2011-04-17 14:11:43 --> Router Class Initialized
DEBUG - 2011-04-17 14:11:43 --> Output Class Initialized
DEBUG - 2011-04-17 14:11:43 --> Input Class Initialized
DEBUG - 2011-04-17 14:11:43 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-17 14:11:43 --> Language Class Initialized
DEBUG - 2011-04-17 14:11:43 --> Loader Class Initialized
DEBUG - 2011-04-17 14:11:43 --> Controller Class Initialized
ERROR - 2011-04-17 14:11:43 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-17 14:11:43 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-17 14:11:43 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-17 14:11:43 --> Model Class Initialized
DEBUG - 2011-04-17 14:11:43 --> Model Class Initialized
DEBUG - 2011-04-17 14:11:43 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-17 14:11:43 --> Database Driver Class Initialized
DEBUG - 2011-04-17 14:11:43 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-17 14:11:44 --> Helper loaded: url_helper
DEBUG - 2011-04-17 14:11:44 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-17 14:11:44 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-17 14:11:44 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-17 14:11:44 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-17 14:11:44 --> Final output sent to browser
DEBUG - 2011-04-17 14:11:44 --> Total execution time: 0.0320
DEBUG - 2011-04-17 14:11:44 --> Config Class Initialized
DEBUG - 2011-04-17 14:11:44 --> Hooks Class Initialized
DEBUG - 2011-04-17 14:11:44 --> Utf8 Class Initialized
DEBUG - 2011-04-17 14:11:44 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 14:11:44 --> URI Class Initialized
DEBUG - 2011-04-17 14:11:44 --> Router Class Initialized
DEBUG - 2011-04-17 14:11:44 --> Output Class Initialized
DEBUG - 2011-04-17 14:11:44 --> Input Class Initialized
DEBUG - 2011-04-17 14:11:44 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-17 14:11:44 --> Language Class Initialized
DEBUG - 2011-04-17 14:11:44 --> Loader Class Initialized
DEBUG - 2011-04-17 14:11:44 --> Controller Class Initialized
DEBUG - 2011-04-17 14:11:44 --> Model Class Initialized
DEBUG - 2011-04-17 14:11:44 --> Model Class Initialized
DEBUG - 2011-04-17 14:11:44 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-17 14:11:44 --> Database Driver Class Initialized
DEBUG - 2011-04-17 14:11:45 --> Final output sent to browser
DEBUG - 2011-04-17 14:11:45 --> Total execution time: 0.6204
DEBUG - 2011-04-17 14:12:21 --> Config Class Initialized
DEBUG - 2011-04-17 14:12:21 --> Hooks Class Initialized
DEBUG - 2011-04-17 14:12:21 --> Utf8 Class Initialized
DEBUG - 2011-04-17 14:12:21 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 14:12:21 --> URI Class Initialized
DEBUG - 2011-04-17 14:12:21 --> Router Class Initialized
DEBUG - 2011-04-17 14:12:21 --> Output Class Initialized
DEBUG - 2011-04-17 14:12:21 --> Input Class Initialized
DEBUG - 2011-04-17 14:12:21 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-17 14:12:21 --> Language Class Initialized
DEBUG - 2011-04-17 14:12:21 --> Loader Class Initialized
DEBUG - 2011-04-17 14:12:21 --> Controller Class Initialized
ERROR - 2011-04-17 14:12:21 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-17 14:12:21 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-17 14:12:21 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-17 14:12:21 --> Model Class Initialized
DEBUG - 2011-04-17 14:12:21 --> Model Class Initialized
DEBUG - 2011-04-17 14:12:21 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-17 14:12:21 --> Database Driver Class Initialized
DEBUG - 2011-04-17 14:12:21 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-17 14:12:21 --> Helper loaded: url_helper
DEBUG - 2011-04-17 14:12:21 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-17 14:12:21 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-17 14:12:21 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-17 14:12:21 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-17 14:12:21 --> Final output sent to browser
DEBUG - 2011-04-17 14:12:21 --> Total execution time: 0.1780
DEBUG - 2011-04-17 14:12:22 --> Config Class Initialized
DEBUG - 2011-04-17 14:12:22 --> Hooks Class Initialized
DEBUG - 2011-04-17 14:12:23 --> Utf8 Class Initialized
DEBUG - 2011-04-17 14:12:23 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 14:12:23 --> URI Class Initialized
DEBUG - 2011-04-17 14:12:23 --> Router Class Initialized
DEBUG - 2011-04-17 14:12:23 --> Output Class Initialized
DEBUG - 2011-04-17 14:12:23 --> Input Class Initialized
DEBUG - 2011-04-17 14:12:23 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-17 14:12:23 --> Language Class Initialized
DEBUG - 2011-04-17 14:12:23 --> Loader Class Initialized
DEBUG - 2011-04-17 14:12:23 --> Controller Class Initialized
DEBUG - 2011-04-17 14:12:23 --> Model Class Initialized
DEBUG - 2011-04-17 14:12:23 --> Model Class Initialized
DEBUG - 2011-04-17 14:12:23 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-17 14:12:23 --> Database Driver Class Initialized
DEBUG - 2011-04-17 14:12:24 --> Final output sent to browser
DEBUG - 2011-04-17 14:12:24 --> Total execution time: 1.1553
DEBUG - 2011-04-17 14:12:47 --> Config Class Initialized
DEBUG - 2011-04-17 14:12:47 --> Hooks Class Initialized
DEBUG - 2011-04-17 14:12:47 --> Utf8 Class Initialized
DEBUG - 2011-04-17 14:12:47 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 14:12:47 --> URI Class Initialized
DEBUG - 2011-04-17 14:12:47 --> Router Class Initialized
DEBUG - 2011-04-17 14:12:47 --> Output Class Initialized
DEBUG - 2011-04-17 14:12:47 --> Input Class Initialized
DEBUG - 2011-04-17 14:12:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-17 14:12:47 --> Language Class Initialized
DEBUG - 2011-04-17 14:12:47 --> Loader Class Initialized
DEBUG - 2011-04-17 14:12:47 --> Controller Class Initialized
ERROR - 2011-04-17 14:12:47 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-17 14:12:47 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-17 14:12:47 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-17 14:12:47 --> Model Class Initialized
DEBUG - 2011-04-17 14:12:47 --> Model Class Initialized
DEBUG - 2011-04-17 14:12:47 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-17 14:12:47 --> Database Driver Class Initialized
DEBUG - 2011-04-17 14:12:47 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-17 14:12:47 --> Helper loaded: url_helper
DEBUG - 2011-04-17 14:12:47 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-17 14:12:48 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-17 14:12:48 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-17 14:12:48 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-17 14:12:48 --> Final output sent to browser
DEBUG - 2011-04-17 14:12:48 --> Total execution time: 0.0356
DEBUG - 2011-04-17 14:12:49 --> Config Class Initialized
DEBUG - 2011-04-17 14:12:49 --> Hooks Class Initialized
DEBUG - 2011-04-17 14:12:49 --> Utf8 Class Initialized
DEBUG - 2011-04-17 14:12:49 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 14:12:49 --> URI Class Initialized
DEBUG - 2011-04-17 14:12:49 --> Router Class Initialized
DEBUG - 2011-04-17 14:12:49 --> Output Class Initialized
DEBUG - 2011-04-17 14:12:49 --> Input Class Initialized
DEBUG - 2011-04-17 14:12:49 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-17 14:12:49 --> Language Class Initialized
DEBUG - 2011-04-17 14:12:49 --> Loader Class Initialized
DEBUG - 2011-04-17 14:12:49 --> Controller Class Initialized
DEBUG - 2011-04-17 14:12:49 --> Model Class Initialized
DEBUG - 2011-04-17 14:12:49 --> Model Class Initialized
DEBUG - 2011-04-17 14:12:49 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-17 14:12:49 --> Database Driver Class Initialized
DEBUG - 2011-04-17 14:12:49 --> Final output sent to browser
DEBUG - 2011-04-17 14:12:49 --> Total execution time: 0.6451
DEBUG - 2011-04-17 14:13:23 --> Config Class Initialized
DEBUG - 2011-04-17 14:13:23 --> Hooks Class Initialized
DEBUG - 2011-04-17 14:13:23 --> Utf8 Class Initialized
DEBUG - 2011-04-17 14:13:23 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 14:13:23 --> URI Class Initialized
DEBUG - 2011-04-17 14:13:23 --> Router Class Initialized
DEBUG - 2011-04-17 14:13:23 --> Output Class Initialized
DEBUG - 2011-04-17 14:13:23 --> Input Class Initialized
DEBUG - 2011-04-17 14:13:23 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-17 14:13:23 --> Language Class Initialized
DEBUG - 2011-04-17 14:13:23 --> Loader Class Initialized
DEBUG - 2011-04-17 14:13:23 --> Controller Class Initialized
ERROR - 2011-04-17 14:13:23 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-17 14:13:23 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-17 14:13:23 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-17 14:13:23 --> Model Class Initialized
DEBUG - 2011-04-17 14:13:23 --> Model Class Initialized
DEBUG - 2011-04-17 14:13:23 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-17 14:13:23 --> Database Driver Class Initialized
DEBUG - 2011-04-17 14:13:23 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-17 14:13:23 --> Helper loaded: url_helper
DEBUG - 2011-04-17 14:13:23 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-17 14:13:23 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-17 14:13:23 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-17 14:13:23 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-17 14:13:23 --> Final output sent to browser
DEBUG - 2011-04-17 14:13:23 --> Total execution time: 0.0687
DEBUG - 2011-04-17 14:13:25 --> Config Class Initialized
DEBUG - 2011-04-17 14:13:25 --> Hooks Class Initialized
DEBUG - 2011-04-17 14:13:25 --> Utf8 Class Initialized
DEBUG - 2011-04-17 14:13:25 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 14:13:25 --> URI Class Initialized
DEBUG - 2011-04-17 14:13:25 --> Router Class Initialized
DEBUG - 2011-04-17 14:13:25 --> Output Class Initialized
DEBUG - 2011-04-17 14:13:25 --> Input Class Initialized
DEBUG - 2011-04-17 14:13:25 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-17 14:13:25 --> Language Class Initialized
DEBUG - 2011-04-17 14:13:25 --> Loader Class Initialized
DEBUG - 2011-04-17 14:13:25 --> Controller Class Initialized
DEBUG - 2011-04-17 14:13:25 --> Model Class Initialized
DEBUG - 2011-04-17 14:13:25 --> Model Class Initialized
DEBUG - 2011-04-17 14:13:25 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-17 14:13:25 --> Database Driver Class Initialized
DEBUG - 2011-04-17 14:13:25 --> Final output sent to browser
DEBUG - 2011-04-17 14:13:25 --> Total execution time: 0.6936
DEBUG - 2011-04-17 14:13:36 --> Config Class Initialized
DEBUG - 2011-04-17 14:13:36 --> Hooks Class Initialized
DEBUG - 2011-04-17 14:13:36 --> Utf8 Class Initialized
DEBUG - 2011-04-17 14:13:36 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 14:13:36 --> URI Class Initialized
DEBUG - 2011-04-17 14:13:36 --> Router Class Initialized
DEBUG - 2011-04-17 14:13:36 --> Output Class Initialized
DEBUG - 2011-04-17 14:13:36 --> Input Class Initialized
DEBUG - 2011-04-17 14:13:36 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-17 14:13:36 --> Language Class Initialized
DEBUG - 2011-04-17 14:13:36 --> Loader Class Initialized
DEBUG - 2011-04-17 14:13:36 --> Controller Class Initialized
ERROR - 2011-04-17 14:13:36 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-17 14:13:36 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-17 14:13:36 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-17 14:13:36 --> Model Class Initialized
DEBUG - 2011-04-17 14:13:36 --> Model Class Initialized
DEBUG - 2011-04-17 14:13:36 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-17 14:13:36 --> Database Driver Class Initialized
DEBUG - 2011-04-17 14:13:36 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-17 14:13:36 --> Helper loaded: url_helper
DEBUG - 2011-04-17 14:13:36 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-17 14:13:36 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-17 14:13:36 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-17 14:13:36 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-17 14:13:36 --> Final output sent to browser
DEBUG - 2011-04-17 14:13:36 --> Total execution time: 0.0311
DEBUG - 2011-04-17 14:13:37 --> Config Class Initialized
DEBUG - 2011-04-17 14:13:37 --> Hooks Class Initialized
DEBUG - 2011-04-17 14:13:37 --> Utf8 Class Initialized
DEBUG - 2011-04-17 14:13:37 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 14:13:37 --> URI Class Initialized
DEBUG - 2011-04-17 14:13:37 --> Router Class Initialized
DEBUG - 2011-04-17 14:13:37 --> Output Class Initialized
DEBUG - 2011-04-17 14:13:37 --> Input Class Initialized
DEBUG - 2011-04-17 14:13:37 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-17 14:13:37 --> Language Class Initialized
DEBUG - 2011-04-17 14:13:37 --> Loader Class Initialized
DEBUG - 2011-04-17 14:13:37 --> Controller Class Initialized
DEBUG - 2011-04-17 14:13:37 --> Model Class Initialized
DEBUG - 2011-04-17 14:13:37 --> Model Class Initialized
DEBUG - 2011-04-17 14:13:37 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-17 14:13:37 --> Database Driver Class Initialized
DEBUG - 2011-04-17 14:13:38 --> Final output sent to browser
DEBUG - 2011-04-17 14:13:38 --> Total execution time: 0.7418
DEBUG - 2011-04-17 14:13:44 --> Config Class Initialized
DEBUG - 2011-04-17 14:13:44 --> Hooks Class Initialized
DEBUG - 2011-04-17 14:13:44 --> Utf8 Class Initialized
DEBUG - 2011-04-17 14:13:44 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 14:13:44 --> URI Class Initialized
DEBUG - 2011-04-17 14:13:44 --> Router Class Initialized
DEBUG - 2011-04-17 14:13:44 --> Output Class Initialized
DEBUG - 2011-04-17 14:13:44 --> Input Class Initialized
DEBUG - 2011-04-17 14:13:44 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-17 14:13:44 --> Language Class Initialized
DEBUG - 2011-04-17 14:13:44 --> Loader Class Initialized
DEBUG - 2011-04-17 14:13:44 --> Controller Class Initialized
ERROR - 2011-04-17 14:13:44 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-17 14:13:44 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-17 14:13:44 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-17 14:13:44 --> Model Class Initialized
DEBUG - 2011-04-17 14:13:44 --> Model Class Initialized
DEBUG - 2011-04-17 14:13:44 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-17 14:13:44 --> Database Driver Class Initialized
DEBUG - 2011-04-17 14:13:44 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-17 14:13:44 --> Helper loaded: url_helper
DEBUG - 2011-04-17 14:13:44 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-17 14:13:44 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-17 14:13:44 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-17 14:13:44 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-17 14:13:44 --> Final output sent to browser
DEBUG - 2011-04-17 14:13:44 --> Total execution time: 0.3790
DEBUG - 2011-04-17 14:13:45 --> Config Class Initialized
DEBUG - 2011-04-17 14:13:45 --> Hooks Class Initialized
DEBUG - 2011-04-17 14:13:45 --> Utf8 Class Initialized
DEBUG - 2011-04-17 14:13:45 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 14:13:45 --> URI Class Initialized
DEBUG - 2011-04-17 14:13:45 --> Router Class Initialized
DEBUG - 2011-04-17 14:13:45 --> Output Class Initialized
DEBUG - 2011-04-17 14:13:45 --> Input Class Initialized
DEBUG - 2011-04-17 14:13:45 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-17 14:13:45 --> Language Class Initialized
DEBUG - 2011-04-17 14:13:45 --> Loader Class Initialized
DEBUG - 2011-04-17 14:13:45 --> Controller Class Initialized
DEBUG - 2011-04-17 14:13:45 --> Model Class Initialized
DEBUG - 2011-04-17 14:13:45 --> Model Class Initialized
DEBUG - 2011-04-17 14:13:45 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-17 14:13:45 --> Database Driver Class Initialized
DEBUG - 2011-04-17 14:13:46 --> Final output sent to browser
DEBUG - 2011-04-17 14:13:46 --> Total execution time: 1.3325
DEBUG - 2011-04-17 14:14:29 --> Config Class Initialized
DEBUG - 2011-04-17 14:14:29 --> Hooks Class Initialized
DEBUG - 2011-04-17 14:14:29 --> Utf8 Class Initialized
DEBUG - 2011-04-17 14:14:29 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 14:14:29 --> URI Class Initialized
DEBUG - 2011-04-17 14:14:29 --> Router Class Initialized
DEBUG - 2011-04-17 14:14:29 --> Output Class Initialized
DEBUG - 2011-04-17 14:14:29 --> Input Class Initialized
DEBUG - 2011-04-17 14:14:29 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-17 14:14:29 --> Language Class Initialized
DEBUG - 2011-04-17 14:14:29 --> Loader Class Initialized
DEBUG - 2011-04-17 14:14:29 --> Controller Class Initialized
ERROR - 2011-04-17 14:14:29 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-17 14:14:29 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-17 14:14:29 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-17 14:14:29 --> Model Class Initialized
DEBUG - 2011-04-17 14:14:29 --> Model Class Initialized
DEBUG - 2011-04-17 14:14:29 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-17 14:14:29 --> Database Driver Class Initialized
DEBUG - 2011-04-17 14:14:29 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-17 14:14:29 --> Helper loaded: url_helper
DEBUG - 2011-04-17 14:14:29 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-17 14:14:29 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-17 14:14:29 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-17 14:14:29 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-17 14:14:29 --> Final output sent to browser
DEBUG - 2011-04-17 14:14:29 --> Total execution time: 0.0938
DEBUG - 2011-04-17 14:14:30 --> Config Class Initialized
DEBUG - 2011-04-17 14:14:30 --> Hooks Class Initialized
DEBUG - 2011-04-17 14:14:30 --> Utf8 Class Initialized
DEBUG - 2011-04-17 14:14:30 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 14:14:30 --> URI Class Initialized
DEBUG - 2011-04-17 14:14:30 --> Router Class Initialized
DEBUG - 2011-04-17 14:14:30 --> Output Class Initialized
DEBUG - 2011-04-17 14:14:30 --> Input Class Initialized
DEBUG - 2011-04-17 14:14:30 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-17 14:14:30 --> Language Class Initialized
DEBUG - 2011-04-17 14:14:30 --> Loader Class Initialized
DEBUG - 2011-04-17 14:14:30 --> Controller Class Initialized
DEBUG - 2011-04-17 14:14:30 --> Model Class Initialized
DEBUG - 2011-04-17 14:14:30 --> Model Class Initialized
DEBUG - 2011-04-17 14:14:30 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-17 14:14:30 --> Database Driver Class Initialized
DEBUG - 2011-04-17 14:14:30 --> Final output sent to browser
DEBUG - 2011-04-17 14:14:30 --> Total execution time: 0.7314
DEBUG - 2011-04-17 14:27:49 --> Config Class Initialized
DEBUG - 2011-04-17 14:27:49 --> Hooks Class Initialized
DEBUG - 2011-04-17 14:27:49 --> Utf8 Class Initialized
DEBUG - 2011-04-17 14:27:49 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 14:27:49 --> URI Class Initialized
DEBUG - 2011-04-17 14:27:49 --> Router Class Initialized
DEBUG - 2011-04-17 14:27:49 --> Output Class Initialized
DEBUG - 2011-04-17 14:27:49 --> Input Class Initialized
DEBUG - 2011-04-17 14:27:49 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-17 14:27:49 --> Language Class Initialized
DEBUG - 2011-04-17 14:27:49 --> Loader Class Initialized
DEBUG - 2011-04-17 14:27:49 --> Controller Class Initialized
DEBUG - 2011-04-17 14:27:49 --> Model Class Initialized
DEBUG - 2011-04-17 14:27:49 --> Model Class Initialized
DEBUG - 2011-04-17 14:27:49 --> Model Class Initialized
DEBUG - 2011-04-17 14:27:49 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-17 14:27:49 --> Database Driver Class Initialized
DEBUG - 2011-04-17 14:27:49 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-17 14:27:49 --> Helper loaded: url_helper
DEBUG - 2011-04-17 14:27:49 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-17 14:27:49 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-17 14:27:49 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-17 14:27:49 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-17 14:27:49 --> Final output sent to browser
DEBUG - 2011-04-17 14:27:49 --> Total execution time: 0.1425
DEBUG - 2011-04-17 14:27:56 --> Config Class Initialized
DEBUG - 2011-04-17 14:27:56 --> Hooks Class Initialized
DEBUG - 2011-04-17 14:27:56 --> Utf8 Class Initialized
DEBUG - 2011-04-17 14:27:56 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 14:27:56 --> URI Class Initialized
DEBUG - 2011-04-17 14:27:56 --> Router Class Initialized
ERROR - 2011-04-17 14:27:56 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-17 14:27:57 --> Config Class Initialized
DEBUG - 2011-04-17 14:27:57 --> Hooks Class Initialized
DEBUG - 2011-04-17 14:27:57 --> Utf8 Class Initialized
DEBUG - 2011-04-17 14:27:57 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 14:27:57 --> URI Class Initialized
DEBUG - 2011-04-17 14:27:57 --> Router Class Initialized
ERROR - 2011-04-17 14:27:57 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-17 14:28:36 --> Config Class Initialized
DEBUG - 2011-04-17 14:28:36 --> Hooks Class Initialized
DEBUG - 2011-04-17 14:28:36 --> Utf8 Class Initialized
DEBUG - 2011-04-17 14:28:36 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 14:28:36 --> URI Class Initialized
DEBUG - 2011-04-17 14:28:36 --> Router Class Initialized
DEBUG - 2011-04-17 14:28:36 --> Output Class Initialized
DEBUG - 2011-04-17 14:28:36 --> Input Class Initialized
DEBUG - 2011-04-17 14:28:36 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-17 14:28:36 --> Language Class Initialized
DEBUG - 2011-04-17 14:28:36 --> Loader Class Initialized
DEBUG - 2011-04-17 14:28:36 --> Controller Class Initialized
DEBUG - 2011-04-17 14:28:36 --> Model Class Initialized
DEBUG - 2011-04-17 14:28:36 --> Model Class Initialized
DEBUG - 2011-04-17 14:28:36 --> Model Class Initialized
DEBUG - 2011-04-17 14:28:36 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-17 14:28:36 --> Database Driver Class Initialized
DEBUG - 2011-04-17 14:28:36 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-17 14:28:36 --> Helper loaded: url_helper
DEBUG - 2011-04-17 14:28:36 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-17 14:28:36 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-17 14:28:36 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-17 14:28:36 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-17 14:28:36 --> Final output sent to browser
DEBUG - 2011-04-17 14:28:36 --> Total execution time: 0.4557
DEBUG - 2011-04-17 14:28:41 --> Config Class Initialized
DEBUG - 2011-04-17 14:28:41 --> Hooks Class Initialized
DEBUG - 2011-04-17 14:28:41 --> Utf8 Class Initialized
DEBUG - 2011-04-17 14:28:41 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 14:28:41 --> URI Class Initialized
DEBUG - 2011-04-17 14:28:41 --> Router Class Initialized
DEBUG - 2011-04-17 14:28:41 --> Output Class Initialized
DEBUG - 2011-04-17 14:28:41 --> Input Class Initialized
DEBUG - 2011-04-17 14:28:41 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-17 14:28:41 --> Language Class Initialized
DEBUG - 2011-04-17 14:28:41 --> Loader Class Initialized
DEBUG - 2011-04-17 14:28:41 --> Controller Class Initialized
DEBUG - 2011-04-17 14:28:41 --> Model Class Initialized
DEBUG - 2011-04-17 14:28:41 --> Model Class Initialized
DEBUG - 2011-04-17 14:28:41 --> Model Class Initialized
DEBUG - 2011-04-17 14:28:41 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-17 14:28:41 --> Database Driver Class Initialized
DEBUG - 2011-04-17 14:28:41 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-17 14:28:41 --> Helper loaded: url_helper
DEBUG - 2011-04-17 14:28:41 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-17 14:28:41 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-17 14:28:41 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-17 14:28:41 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-17 14:28:41 --> Final output sent to browser
DEBUG - 2011-04-17 14:28:41 --> Total execution time: 0.0842
DEBUG - 2011-04-17 14:29:00 --> Config Class Initialized
DEBUG - 2011-04-17 14:29:00 --> Hooks Class Initialized
DEBUG - 2011-04-17 14:29:00 --> Utf8 Class Initialized
DEBUG - 2011-04-17 14:29:00 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 14:29:00 --> URI Class Initialized
DEBUG - 2011-04-17 14:29:00 --> Router Class Initialized
DEBUG - 2011-04-17 14:29:00 --> Output Class Initialized
DEBUG - 2011-04-17 14:29:00 --> Input Class Initialized
DEBUG - 2011-04-17 14:29:00 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-17 14:29:00 --> Language Class Initialized
DEBUG - 2011-04-17 14:29:00 --> Loader Class Initialized
DEBUG - 2011-04-17 14:29:00 --> Controller Class Initialized
DEBUG - 2011-04-17 14:29:00 --> Model Class Initialized
DEBUG - 2011-04-17 14:29:00 --> Model Class Initialized
DEBUG - 2011-04-17 14:29:00 --> Model Class Initialized
DEBUG - 2011-04-17 14:29:00 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-17 14:29:00 --> Database Driver Class Initialized
DEBUG - 2011-04-17 14:29:01 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-17 14:29:01 --> Helper loaded: url_helper
DEBUG - 2011-04-17 14:29:01 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-17 14:29:01 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-17 14:29:01 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-17 14:29:01 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-17 14:29:01 --> Final output sent to browser
DEBUG - 2011-04-17 14:29:01 --> Total execution time: 0.5718
DEBUG - 2011-04-17 14:29:07 --> Config Class Initialized
DEBUG - 2011-04-17 14:29:07 --> Hooks Class Initialized
DEBUG - 2011-04-17 14:29:07 --> Utf8 Class Initialized
DEBUG - 2011-04-17 14:29:07 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 14:29:07 --> URI Class Initialized
DEBUG - 2011-04-17 14:29:07 --> Router Class Initialized
DEBUG - 2011-04-17 14:29:07 --> Output Class Initialized
DEBUG - 2011-04-17 14:29:07 --> Input Class Initialized
DEBUG - 2011-04-17 14:29:07 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-17 14:29:07 --> Language Class Initialized
DEBUG - 2011-04-17 14:29:07 --> Loader Class Initialized
DEBUG - 2011-04-17 14:29:07 --> Controller Class Initialized
DEBUG - 2011-04-17 14:29:07 --> Model Class Initialized
DEBUG - 2011-04-17 14:29:07 --> Model Class Initialized
DEBUG - 2011-04-17 14:29:07 --> Model Class Initialized
DEBUG - 2011-04-17 14:29:07 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-17 14:29:07 --> Database Driver Class Initialized
DEBUG - 2011-04-17 14:29:07 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-17 14:29:07 --> Helper loaded: url_helper
DEBUG - 2011-04-17 14:29:07 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-17 14:29:07 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-17 14:29:07 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-17 14:29:07 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-17 14:29:07 --> Final output sent to browser
DEBUG - 2011-04-17 14:29:07 --> Total execution time: 0.0888
DEBUG - 2011-04-17 14:29:29 --> Config Class Initialized
DEBUG - 2011-04-17 14:29:29 --> Hooks Class Initialized
DEBUG - 2011-04-17 14:29:29 --> Utf8 Class Initialized
DEBUG - 2011-04-17 14:29:29 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 14:29:29 --> URI Class Initialized
DEBUG - 2011-04-17 14:29:29 --> Router Class Initialized
DEBUG - 2011-04-17 14:29:29 --> Output Class Initialized
DEBUG - 2011-04-17 14:29:29 --> Input Class Initialized
DEBUG - 2011-04-17 14:29:29 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-17 14:29:29 --> Language Class Initialized
DEBUG - 2011-04-17 14:29:29 --> Loader Class Initialized
DEBUG - 2011-04-17 14:29:29 --> Controller Class Initialized
DEBUG - 2011-04-17 14:29:29 --> Model Class Initialized
DEBUG - 2011-04-17 14:29:29 --> Model Class Initialized
DEBUG - 2011-04-17 14:29:29 --> Model Class Initialized
DEBUG - 2011-04-17 14:29:29 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-17 14:29:29 --> Database Driver Class Initialized
DEBUG - 2011-04-17 14:29:29 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-17 14:29:29 --> Helper loaded: url_helper
DEBUG - 2011-04-17 14:29:29 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-17 14:29:29 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-17 14:29:29 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-17 14:29:29 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-17 14:29:29 --> Final output sent to browser
DEBUG - 2011-04-17 14:29:29 --> Total execution time: 0.8421
DEBUG - 2011-04-17 14:29:31 --> Config Class Initialized
DEBUG - 2011-04-17 14:29:31 --> Hooks Class Initialized
DEBUG - 2011-04-17 14:29:31 --> Utf8 Class Initialized
DEBUG - 2011-04-17 14:29:31 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 14:29:31 --> URI Class Initialized
DEBUG - 2011-04-17 14:29:31 --> Router Class Initialized
DEBUG - 2011-04-17 14:29:31 --> Output Class Initialized
DEBUG - 2011-04-17 14:29:31 --> Input Class Initialized
DEBUG - 2011-04-17 14:29:31 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-17 14:29:31 --> Language Class Initialized
DEBUG - 2011-04-17 14:29:31 --> Loader Class Initialized
DEBUG - 2011-04-17 14:29:31 --> Controller Class Initialized
DEBUG - 2011-04-17 14:29:31 --> Model Class Initialized
DEBUG - 2011-04-17 14:29:31 --> Model Class Initialized
DEBUG - 2011-04-17 14:29:31 --> Model Class Initialized
DEBUG - 2011-04-17 14:29:31 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-17 14:29:31 --> Database Driver Class Initialized
DEBUG - 2011-04-17 14:29:31 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-17 14:29:31 --> Helper loaded: url_helper
DEBUG - 2011-04-17 14:29:31 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-17 14:29:31 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-17 14:29:31 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-17 14:29:31 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-17 14:29:31 --> Final output sent to browser
DEBUG - 2011-04-17 14:29:31 --> Total execution time: 0.0490
DEBUG - 2011-04-17 14:29:43 --> Config Class Initialized
DEBUG - 2011-04-17 14:29:43 --> Hooks Class Initialized
DEBUG - 2011-04-17 14:29:43 --> Utf8 Class Initialized
DEBUG - 2011-04-17 14:29:43 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 14:29:43 --> URI Class Initialized
DEBUG - 2011-04-17 14:29:43 --> Router Class Initialized
DEBUG - 2011-04-17 14:29:43 --> Output Class Initialized
DEBUG - 2011-04-17 14:29:43 --> Input Class Initialized
DEBUG - 2011-04-17 14:29:43 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-17 14:29:43 --> Language Class Initialized
DEBUG - 2011-04-17 14:29:43 --> Loader Class Initialized
DEBUG - 2011-04-17 14:29:43 --> Controller Class Initialized
DEBUG - 2011-04-17 14:29:43 --> Model Class Initialized
DEBUG - 2011-04-17 14:29:43 --> Model Class Initialized
DEBUG - 2011-04-17 14:29:43 --> Model Class Initialized
DEBUG - 2011-04-17 14:29:43 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-17 14:29:43 --> Database Driver Class Initialized
DEBUG - 2011-04-17 14:29:43 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-17 14:29:43 --> Helper loaded: url_helper
DEBUG - 2011-04-17 14:29:43 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-17 14:29:43 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-17 14:29:43 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-17 14:29:43 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-17 14:29:43 --> Final output sent to browser
DEBUG - 2011-04-17 14:29:43 --> Total execution time: 0.2192
DEBUG - 2011-04-17 14:29:56 --> Config Class Initialized
DEBUG - 2011-04-17 14:29:56 --> Hooks Class Initialized
DEBUG - 2011-04-17 14:29:56 --> Utf8 Class Initialized
DEBUG - 2011-04-17 14:29:56 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 14:29:56 --> URI Class Initialized
DEBUG - 2011-04-17 14:29:56 --> Router Class Initialized
DEBUG - 2011-04-17 14:29:56 --> Output Class Initialized
DEBUG - 2011-04-17 14:29:56 --> Input Class Initialized
DEBUG - 2011-04-17 14:29:56 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-17 14:29:56 --> Language Class Initialized
DEBUG - 2011-04-17 14:29:56 --> Loader Class Initialized
DEBUG - 2011-04-17 14:29:56 --> Controller Class Initialized
DEBUG - 2011-04-17 14:29:56 --> Model Class Initialized
DEBUG - 2011-04-17 14:29:56 --> Model Class Initialized
DEBUG - 2011-04-17 14:29:56 --> Model Class Initialized
DEBUG - 2011-04-17 14:29:56 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-17 14:29:56 --> Database Driver Class Initialized
DEBUG - 2011-04-17 14:29:57 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-17 14:29:57 --> Helper loaded: url_helper
DEBUG - 2011-04-17 14:29:57 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-17 14:29:57 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-17 14:29:57 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-17 14:29:57 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-17 14:29:57 --> Final output sent to browser
DEBUG - 2011-04-17 14:29:57 --> Total execution time: 0.2670
DEBUG - 2011-04-17 14:30:38 --> Config Class Initialized
DEBUG - 2011-04-17 14:30:38 --> Hooks Class Initialized
DEBUG - 2011-04-17 14:30:38 --> Utf8 Class Initialized
DEBUG - 2011-04-17 14:30:38 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 14:30:38 --> URI Class Initialized
DEBUG - 2011-04-17 14:30:38 --> Router Class Initialized
DEBUG - 2011-04-17 14:30:38 --> Output Class Initialized
DEBUG - 2011-04-17 14:30:38 --> Input Class Initialized
DEBUG - 2011-04-17 14:30:38 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-17 14:30:38 --> Language Class Initialized
DEBUG - 2011-04-17 14:30:38 --> Loader Class Initialized
DEBUG - 2011-04-17 14:30:38 --> Controller Class Initialized
DEBUG - 2011-04-17 14:30:38 --> Model Class Initialized
DEBUG - 2011-04-17 14:30:38 --> Model Class Initialized
DEBUG - 2011-04-17 14:30:38 --> Model Class Initialized
DEBUG - 2011-04-17 14:30:38 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-17 14:30:38 --> Database Driver Class Initialized
DEBUG - 2011-04-17 14:30:39 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-17 14:30:39 --> Helper loaded: url_helper
DEBUG - 2011-04-17 14:30:39 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-17 14:30:39 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-17 14:30:39 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-17 14:30:39 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-17 14:30:39 --> Final output sent to browser
DEBUG - 2011-04-17 14:30:39 --> Total execution time: 0.8043
DEBUG - 2011-04-17 14:31:00 --> Config Class Initialized
DEBUG - 2011-04-17 14:31:00 --> Hooks Class Initialized
DEBUG - 2011-04-17 14:31:00 --> Utf8 Class Initialized
DEBUG - 2011-04-17 14:31:00 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 14:31:00 --> URI Class Initialized
DEBUG - 2011-04-17 14:31:00 --> Router Class Initialized
DEBUG - 2011-04-17 14:31:00 --> Output Class Initialized
DEBUG - 2011-04-17 14:31:00 --> Input Class Initialized
DEBUG - 2011-04-17 14:31:00 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-17 14:31:00 --> Language Class Initialized
DEBUG - 2011-04-17 14:31:00 --> Loader Class Initialized
DEBUG - 2011-04-17 14:31:00 --> Controller Class Initialized
DEBUG - 2011-04-17 14:31:00 --> Model Class Initialized
DEBUG - 2011-04-17 14:31:00 --> Model Class Initialized
DEBUG - 2011-04-17 14:31:00 --> Model Class Initialized
DEBUG - 2011-04-17 14:31:00 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-17 14:31:00 --> Database Driver Class Initialized
DEBUG - 2011-04-17 14:31:01 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-17 14:31:01 --> Helper loaded: url_helper
DEBUG - 2011-04-17 14:31:01 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-17 14:31:01 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-17 14:31:01 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-17 14:31:01 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-17 14:31:01 --> Final output sent to browser
DEBUG - 2011-04-17 14:31:01 --> Total execution time: 0.7345
DEBUG - 2011-04-17 14:31:02 --> Config Class Initialized
DEBUG - 2011-04-17 14:31:02 --> Hooks Class Initialized
DEBUG - 2011-04-17 14:31:02 --> Utf8 Class Initialized
DEBUG - 2011-04-17 14:31:02 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 14:31:02 --> URI Class Initialized
DEBUG - 2011-04-17 14:31:02 --> Router Class Initialized
DEBUG - 2011-04-17 14:31:02 --> Output Class Initialized
DEBUG - 2011-04-17 14:31:02 --> Input Class Initialized
DEBUG - 2011-04-17 14:31:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-17 14:31:02 --> Language Class Initialized
DEBUG - 2011-04-17 14:31:02 --> Loader Class Initialized
DEBUG - 2011-04-17 14:31:02 --> Controller Class Initialized
DEBUG - 2011-04-17 14:31:02 --> Model Class Initialized
DEBUG - 2011-04-17 14:31:02 --> Model Class Initialized
DEBUG - 2011-04-17 14:31:02 --> Model Class Initialized
DEBUG - 2011-04-17 14:31:02 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-17 14:31:02 --> Database Driver Class Initialized
DEBUG - 2011-04-17 14:31:02 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-17 14:31:02 --> Helper loaded: url_helper
DEBUG - 2011-04-17 14:31:02 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-17 14:31:02 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-17 14:31:02 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-17 14:31:02 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-17 14:31:02 --> Final output sent to browser
DEBUG - 2011-04-17 14:31:02 --> Total execution time: 0.0543
DEBUG - 2011-04-17 14:31:33 --> Config Class Initialized
DEBUG - 2011-04-17 14:31:33 --> Hooks Class Initialized
DEBUG - 2011-04-17 14:31:33 --> Utf8 Class Initialized
DEBUG - 2011-04-17 14:31:33 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 14:31:33 --> URI Class Initialized
DEBUG - 2011-04-17 14:31:33 --> Router Class Initialized
DEBUG - 2011-04-17 14:31:33 --> Output Class Initialized
DEBUG - 2011-04-17 14:31:33 --> Input Class Initialized
DEBUG - 2011-04-17 14:31:33 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-17 14:31:33 --> Language Class Initialized
DEBUG - 2011-04-17 14:31:33 --> Loader Class Initialized
DEBUG - 2011-04-17 14:31:33 --> Controller Class Initialized
DEBUG - 2011-04-17 14:31:33 --> Model Class Initialized
DEBUG - 2011-04-17 14:31:33 --> Model Class Initialized
DEBUG - 2011-04-17 14:31:33 --> Model Class Initialized
DEBUG - 2011-04-17 14:31:33 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-17 14:31:33 --> Database Driver Class Initialized
DEBUG - 2011-04-17 14:31:33 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-17 14:31:33 --> Helper loaded: url_helper
DEBUG - 2011-04-17 14:31:33 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-17 14:31:33 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-17 14:31:33 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-17 14:31:33 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-17 14:31:33 --> Final output sent to browser
DEBUG - 2011-04-17 14:31:33 --> Total execution time: 0.3034
DEBUG - 2011-04-17 14:31:48 --> Config Class Initialized
DEBUG - 2011-04-17 14:31:48 --> Hooks Class Initialized
DEBUG - 2011-04-17 14:31:48 --> Utf8 Class Initialized
DEBUG - 2011-04-17 14:31:48 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 14:31:48 --> URI Class Initialized
DEBUG - 2011-04-17 14:31:48 --> Router Class Initialized
DEBUG - 2011-04-17 14:31:48 --> Output Class Initialized
DEBUG - 2011-04-17 14:31:49 --> Input Class Initialized
DEBUG - 2011-04-17 14:31:49 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-17 14:31:49 --> Language Class Initialized
DEBUG - 2011-04-17 14:31:49 --> Loader Class Initialized
DEBUG - 2011-04-17 14:31:49 --> Controller Class Initialized
DEBUG - 2011-04-17 14:31:49 --> Model Class Initialized
DEBUG - 2011-04-17 14:31:49 --> Model Class Initialized
DEBUG - 2011-04-17 14:31:49 --> Model Class Initialized
DEBUG - 2011-04-17 14:31:49 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-17 14:31:49 --> Database Driver Class Initialized
DEBUG - 2011-04-17 14:31:49 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-17 14:31:49 --> Helper loaded: url_helper
DEBUG - 2011-04-17 14:31:49 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-17 14:31:49 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-17 14:31:49 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-17 14:31:49 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-17 14:31:49 --> Final output sent to browser
DEBUG - 2011-04-17 14:31:49 --> Total execution time: 0.5416
DEBUG - 2011-04-17 14:32:00 --> Config Class Initialized
DEBUG - 2011-04-17 14:32:00 --> Hooks Class Initialized
DEBUG - 2011-04-17 14:32:00 --> Utf8 Class Initialized
DEBUG - 2011-04-17 14:32:00 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 14:32:00 --> URI Class Initialized
DEBUG - 2011-04-17 14:32:00 --> Router Class Initialized
DEBUG - 2011-04-17 14:32:00 --> Output Class Initialized
DEBUG - 2011-04-17 14:32:00 --> Input Class Initialized
DEBUG - 2011-04-17 14:32:00 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-17 14:32:00 --> Language Class Initialized
DEBUG - 2011-04-17 14:32:00 --> Loader Class Initialized
DEBUG - 2011-04-17 14:32:00 --> Controller Class Initialized
DEBUG - 2011-04-17 14:32:00 --> Model Class Initialized
DEBUG - 2011-04-17 14:32:00 --> Model Class Initialized
DEBUG - 2011-04-17 14:32:00 --> Model Class Initialized
DEBUG - 2011-04-17 14:32:00 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-17 14:32:00 --> Database Driver Class Initialized
DEBUG - 2011-04-17 14:32:00 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-17 14:32:00 --> Helper loaded: url_helper
DEBUG - 2011-04-17 14:32:00 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-17 14:32:00 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-17 14:32:00 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-17 14:32:00 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-17 14:32:00 --> Final output sent to browser
DEBUG - 2011-04-17 14:32:00 --> Total execution time: 0.0506
DEBUG - 2011-04-17 14:32:11 --> Config Class Initialized
DEBUG - 2011-04-17 14:32:11 --> Hooks Class Initialized
DEBUG - 2011-04-17 14:32:11 --> Utf8 Class Initialized
DEBUG - 2011-04-17 14:32:11 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 14:32:11 --> URI Class Initialized
DEBUG - 2011-04-17 14:32:11 --> Router Class Initialized
DEBUG - 2011-04-17 14:32:11 --> Output Class Initialized
DEBUG - 2011-04-17 14:32:11 --> Input Class Initialized
DEBUG - 2011-04-17 14:32:11 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-17 14:32:11 --> Language Class Initialized
DEBUG - 2011-04-17 14:32:11 --> Loader Class Initialized
DEBUG - 2011-04-17 14:32:11 --> Controller Class Initialized
DEBUG - 2011-04-17 14:32:11 --> Model Class Initialized
DEBUG - 2011-04-17 14:32:11 --> Model Class Initialized
DEBUG - 2011-04-17 14:32:11 --> Model Class Initialized
DEBUG - 2011-04-17 14:32:11 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-17 14:32:11 --> Database Driver Class Initialized
DEBUG - 2011-04-17 14:32:12 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-17 14:32:12 --> Helper loaded: url_helper
DEBUG - 2011-04-17 14:32:12 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-17 14:32:12 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-17 14:32:12 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-17 14:32:12 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-17 14:32:12 --> Final output sent to browser
DEBUG - 2011-04-17 14:32:12 --> Total execution time: 0.4077
DEBUG - 2011-04-17 14:32:22 --> Config Class Initialized
DEBUG - 2011-04-17 14:32:22 --> Hooks Class Initialized
DEBUG - 2011-04-17 14:32:22 --> Utf8 Class Initialized
DEBUG - 2011-04-17 14:32:22 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 14:32:22 --> URI Class Initialized
DEBUG - 2011-04-17 14:32:22 --> Router Class Initialized
DEBUG - 2011-04-17 14:32:22 --> Output Class Initialized
DEBUG - 2011-04-17 14:32:22 --> Input Class Initialized
DEBUG - 2011-04-17 14:32:22 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-17 14:32:22 --> Language Class Initialized
DEBUG - 2011-04-17 14:32:22 --> Loader Class Initialized
DEBUG - 2011-04-17 14:32:22 --> Controller Class Initialized
DEBUG - 2011-04-17 14:32:22 --> Model Class Initialized
DEBUG - 2011-04-17 14:32:22 --> Model Class Initialized
DEBUG - 2011-04-17 14:32:22 --> Model Class Initialized
DEBUG - 2011-04-17 14:32:22 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-17 14:32:22 --> Database Driver Class Initialized
DEBUG - 2011-04-17 14:32:23 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-17 14:32:23 --> Helper loaded: url_helper
DEBUG - 2011-04-17 14:32:23 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-17 14:32:23 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-17 14:32:23 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-17 14:32:23 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-17 14:32:23 --> Final output sent to browser
DEBUG - 2011-04-17 14:32:23 --> Total execution time: 0.6024
DEBUG - 2011-04-17 14:32:38 --> Config Class Initialized
DEBUG - 2011-04-17 14:32:38 --> Hooks Class Initialized
DEBUG - 2011-04-17 14:32:38 --> Utf8 Class Initialized
DEBUG - 2011-04-17 14:32:38 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 14:32:38 --> URI Class Initialized
DEBUG - 2011-04-17 14:32:38 --> Router Class Initialized
DEBUG - 2011-04-17 14:32:38 --> Output Class Initialized
DEBUG - 2011-04-17 14:32:38 --> Input Class Initialized
DEBUG - 2011-04-17 14:32:38 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-17 14:32:38 --> Language Class Initialized
DEBUG - 2011-04-17 14:32:38 --> Loader Class Initialized
DEBUG - 2011-04-17 14:32:38 --> Controller Class Initialized
DEBUG - 2011-04-17 14:32:38 --> Model Class Initialized
DEBUG - 2011-04-17 14:32:38 --> Model Class Initialized
DEBUG - 2011-04-17 14:32:38 --> Model Class Initialized
DEBUG - 2011-04-17 14:32:38 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-17 14:32:38 --> Database Driver Class Initialized
DEBUG - 2011-04-17 14:32:38 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-17 14:32:38 --> Helper loaded: url_helper
DEBUG - 2011-04-17 14:32:38 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-17 14:32:38 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-17 14:32:38 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-17 14:32:38 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-17 14:32:38 --> Final output sent to browser
DEBUG - 2011-04-17 14:32:38 --> Total execution time: 0.3815
DEBUG - 2011-04-17 14:32:52 --> Config Class Initialized
DEBUG - 2011-04-17 14:32:52 --> Hooks Class Initialized
DEBUG - 2011-04-17 14:32:52 --> Utf8 Class Initialized
DEBUG - 2011-04-17 14:32:52 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 14:32:52 --> URI Class Initialized
DEBUG - 2011-04-17 14:32:52 --> Router Class Initialized
DEBUG - 2011-04-17 14:32:52 --> Output Class Initialized
DEBUG - 2011-04-17 14:32:52 --> Input Class Initialized
DEBUG - 2011-04-17 14:32:52 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-17 14:32:52 --> Language Class Initialized
DEBUG - 2011-04-17 14:32:52 --> Loader Class Initialized
DEBUG - 2011-04-17 14:32:52 --> Controller Class Initialized
DEBUG - 2011-04-17 14:32:52 --> Model Class Initialized
DEBUG - 2011-04-17 14:32:52 --> Model Class Initialized
DEBUG - 2011-04-17 14:32:52 --> Model Class Initialized
DEBUG - 2011-04-17 14:32:52 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-17 14:32:52 --> Database Driver Class Initialized
DEBUG - 2011-04-17 14:32:52 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-17 14:32:52 --> Helper loaded: url_helper
DEBUG - 2011-04-17 14:32:52 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-17 14:32:52 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-17 14:32:52 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-17 14:32:52 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-17 14:32:52 --> Final output sent to browser
DEBUG - 2011-04-17 14:32:52 --> Total execution time: 0.0759
DEBUG - 2011-04-17 14:33:02 --> Config Class Initialized
DEBUG - 2011-04-17 14:33:02 --> Hooks Class Initialized
DEBUG - 2011-04-17 14:33:02 --> Utf8 Class Initialized
DEBUG - 2011-04-17 14:33:02 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 14:33:02 --> URI Class Initialized
DEBUG - 2011-04-17 14:33:02 --> Router Class Initialized
DEBUG - 2011-04-17 14:33:02 --> Output Class Initialized
DEBUG - 2011-04-17 14:33:02 --> Input Class Initialized
DEBUG - 2011-04-17 14:33:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-17 14:33:02 --> Language Class Initialized
DEBUG - 2011-04-17 14:33:02 --> Loader Class Initialized
DEBUG - 2011-04-17 14:33:02 --> Controller Class Initialized
DEBUG - 2011-04-17 14:33:02 --> Model Class Initialized
DEBUG - 2011-04-17 14:33:02 --> Model Class Initialized
DEBUG - 2011-04-17 14:33:02 --> Model Class Initialized
DEBUG - 2011-04-17 14:33:02 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-17 14:33:02 --> Database Driver Class Initialized
DEBUG - 2011-04-17 14:33:02 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-17 14:33:02 --> Helper loaded: url_helper
DEBUG - 2011-04-17 14:33:02 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-17 14:33:02 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-17 14:33:02 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-17 14:33:02 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-17 14:33:02 --> Final output sent to browser
DEBUG - 2011-04-17 14:33:02 --> Total execution time: 0.4374
DEBUG - 2011-04-17 14:33:04 --> Config Class Initialized
DEBUG - 2011-04-17 14:33:04 --> Hooks Class Initialized
DEBUG - 2011-04-17 14:33:04 --> Utf8 Class Initialized
DEBUG - 2011-04-17 14:33:04 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 14:33:04 --> URI Class Initialized
DEBUG - 2011-04-17 14:33:04 --> Router Class Initialized
DEBUG - 2011-04-17 14:33:04 --> Output Class Initialized
DEBUG - 2011-04-17 14:33:04 --> Input Class Initialized
DEBUG - 2011-04-17 14:33:04 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-17 14:33:04 --> Language Class Initialized
DEBUG - 2011-04-17 14:33:04 --> Loader Class Initialized
DEBUG - 2011-04-17 14:33:04 --> Controller Class Initialized
DEBUG - 2011-04-17 14:33:04 --> Model Class Initialized
DEBUG - 2011-04-17 14:33:04 --> Model Class Initialized
DEBUG - 2011-04-17 14:33:04 --> Model Class Initialized
DEBUG - 2011-04-17 14:33:04 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-17 14:33:04 --> Database Driver Class Initialized
DEBUG - 2011-04-17 14:33:04 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-17 14:33:04 --> Helper loaded: url_helper
DEBUG - 2011-04-17 14:33:04 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-17 14:33:04 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-17 14:33:04 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-17 14:33:04 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-17 14:33:04 --> Final output sent to browser
DEBUG - 2011-04-17 14:33:04 --> Total execution time: 0.1594
DEBUG - 2011-04-17 15:26:42 --> Config Class Initialized
DEBUG - 2011-04-17 15:26:42 --> Hooks Class Initialized
DEBUG - 2011-04-17 15:26:42 --> Utf8 Class Initialized
DEBUG - 2011-04-17 15:26:42 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 15:26:42 --> URI Class Initialized
DEBUG - 2011-04-17 15:26:42 --> Router Class Initialized
DEBUG - 2011-04-17 15:26:42 --> Output Class Initialized
DEBUG - 2011-04-17 15:26:42 --> Input Class Initialized
DEBUG - 2011-04-17 15:26:42 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-17 15:26:42 --> Language Class Initialized
DEBUG - 2011-04-17 15:26:42 --> Loader Class Initialized
DEBUG - 2011-04-17 15:26:42 --> Controller Class Initialized
DEBUG - 2011-04-17 15:26:42 --> Model Class Initialized
DEBUG - 2011-04-17 15:26:42 --> Model Class Initialized
DEBUG - 2011-04-17 15:26:42 --> Model Class Initialized
DEBUG - 2011-04-17 15:26:42 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-17 15:26:42 --> Database Driver Class Initialized
DEBUG - 2011-04-17 15:26:43 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-17 15:26:43 --> Helper loaded: url_helper
DEBUG - 2011-04-17 15:26:43 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-17 15:26:43 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-17 15:26:43 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-17 15:26:43 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-17 15:26:43 --> Final output sent to browser
DEBUG - 2011-04-17 15:26:43 --> Total execution time: 0.7503
DEBUG - 2011-04-17 15:26:45 --> Config Class Initialized
DEBUG - 2011-04-17 15:26:45 --> Hooks Class Initialized
DEBUG - 2011-04-17 15:26:45 --> Utf8 Class Initialized
DEBUG - 2011-04-17 15:26:45 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 15:26:45 --> URI Class Initialized
DEBUG - 2011-04-17 15:26:45 --> Router Class Initialized
ERROR - 2011-04-17 15:26:45 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-17 15:39:44 --> Config Class Initialized
DEBUG - 2011-04-17 15:39:44 --> Hooks Class Initialized
DEBUG - 2011-04-17 15:39:44 --> Utf8 Class Initialized
DEBUG - 2011-04-17 15:39:44 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 15:39:45 --> URI Class Initialized
DEBUG - 2011-04-17 15:39:45 --> Router Class Initialized
DEBUG - 2011-04-17 15:39:45 --> No URI present. Default controller set.
DEBUG - 2011-04-17 15:39:45 --> Output Class Initialized
DEBUG - 2011-04-17 15:39:45 --> Input Class Initialized
DEBUG - 2011-04-17 15:39:45 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-17 15:39:45 --> Language Class Initialized
DEBUG - 2011-04-17 15:39:45 --> Loader Class Initialized
DEBUG - 2011-04-17 15:39:45 --> Controller Class Initialized
DEBUG - 2011-04-17 15:39:45 --> File loaded: application/views/splash/main.php
DEBUG - 2011-04-17 15:39:45 --> Helper loaded: url_helper
DEBUG - 2011-04-17 15:39:45 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-17 15:39:45 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-17 15:39:45 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-17 15:39:45 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-17 15:39:45 --> Final output sent to browser
DEBUG - 2011-04-17 15:39:45 --> Total execution time: 1.0487
DEBUG - 2011-04-17 15:39:53 --> Config Class Initialized
DEBUG - 2011-04-17 15:39:53 --> Hooks Class Initialized
DEBUG - 2011-04-17 15:39:53 --> Utf8 Class Initialized
DEBUG - 2011-04-17 15:39:53 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 15:39:53 --> URI Class Initialized
DEBUG - 2011-04-17 15:39:53 --> Router Class Initialized
ERROR - 2011-04-17 15:39:54 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-17 15:40:01 --> Config Class Initialized
DEBUG - 2011-04-17 15:40:01 --> Hooks Class Initialized
DEBUG - 2011-04-17 15:40:01 --> Utf8 Class Initialized
DEBUG - 2011-04-17 15:40:01 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 15:40:01 --> URI Class Initialized
DEBUG - 2011-04-17 15:40:01 --> Router Class Initialized
DEBUG - 2011-04-17 15:40:01 --> Output Class Initialized
DEBUG - 2011-04-17 15:40:01 --> Input Class Initialized
DEBUG - 2011-04-17 15:40:01 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-17 15:40:01 --> Language Class Initialized
DEBUG - 2011-04-17 15:40:02 --> Loader Class Initialized
DEBUG - 2011-04-17 15:40:02 --> Controller Class Initialized
DEBUG - 2011-04-17 15:40:02 --> Model Class Initialized
DEBUG - 2011-04-17 15:40:02 --> Model Class Initialized
DEBUG - 2011-04-17 15:40:02 --> Model Class Initialized
DEBUG - 2011-04-17 15:40:02 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-17 15:40:02 --> Database Driver Class Initialized
DEBUG - 2011-04-17 15:40:03 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-17 15:40:03 --> Helper loaded: url_helper
DEBUG - 2011-04-17 15:40:03 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-17 15:40:03 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-17 15:40:03 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-17 15:40:03 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-17 15:40:03 --> Final output sent to browser
DEBUG - 2011-04-17 15:40:03 --> Total execution time: 1.3225
DEBUG - 2011-04-17 15:40:04 --> Config Class Initialized
DEBUG - 2011-04-17 15:40:04 --> Hooks Class Initialized
DEBUG - 2011-04-17 15:40:04 --> Utf8 Class Initialized
DEBUG - 2011-04-17 15:40:04 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 15:40:04 --> URI Class Initialized
DEBUG - 2011-04-17 15:40:04 --> Router Class Initialized
ERROR - 2011-04-17 15:40:04 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-17 15:40:24 --> Config Class Initialized
DEBUG - 2011-04-17 15:40:24 --> Hooks Class Initialized
DEBUG - 2011-04-17 15:40:24 --> Utf8 Class Initialized
DEBUG - 2011-04-17 15:40:24 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 15:40:24 --> URI Class Initialized
DEBUG - 2011-04-17 15:40:24 --> Router Class Initialized
DEBUG - 2011-04-17 15:40:24 --> Output Class Initialized
DEBUG - 2011-04-17 15:40:24 --> Input Class Initialized
DEBUG - 2011-04-17 15:40:24 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-17 15:40:24 --> Language Class Initialized
DEBUG - 2011-04-17 15:40:24 --> Loader Class Initialized
DEBUG - 2011-04-17 15:40:24 --> Controller Class Initialized
DEBUG - 2011-04-17 15:40:24 --> Model Class Initialized
DEBUG - 2011-04-17 15:40:24 --> Model Class Initialized
DEBUG - 2011-04-17 15:40:24 --> Model Class Initialized
DEBUG - 2011-04-17 15:40:24 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-17 15:40:24 --> Database Driver Class Initialized
DEBUG - 2011-04-17 15:40:24 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-17 15:40:24 --> Helper loaded: url_helper
DEBUG - 2011-04-17 15:40:24 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-17 15:40:24 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-17 15:40:24 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-17 15:40:24 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-17 15:40:24 --> Final output sent to browser
DEBUG - 2011-04-17 15:40:24 --> Total execution time: 0.6654
DEBUG - 2011-04-17 15:40:27 --> Config Class Initialized
DEBUG - 2011-04-17 15:40:27 --> Hooks Class Initialized
DEBUG - 2011-04-17 15:40:27 --> Utf8 Class Initialized
DEBUG - 2011-04-17 15:40:27 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 15:40:27 --> URI Class Initialized
DEBUG - 2011-04-17 15:40:27 --> Router Class Initialized
DEBUG - 2011-04-17 15:40:27 --> Output Class Initialized
DEBUG - 2011-04-17 15:40:27 --> Input Class Initialized
DEBUG - 2011-04-17 15:40:27 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-17 15:40:27 --> Language Class Initialized
DEBUG - 2011-04-17 15:40:27 --> Loader Class Initialized
DEBUG - 2011-04-17 15:40:27 --> Controller Class Initialized
DEBUG - 2011-04-17 15:40:27 --> Model Class Initialized
DEBUG - 2011-04-17 15:40:27 --> Model Class Initialized
DEBUG - 2011-04-17 15:40:27 --> Model Class Initialized
DEBUG - 2011-04-17 15:40:27 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-17 15:40:27 --> Database Driver Class Initialized
DEBUG - 2011-04-17 15:40:27 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-17 15:40:27 --> Helper loaded: url_helper
DEBUG - 2011-04-17 15:40:27 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-17 15:40:27 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-17 15:40:27 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-17 15:40:27 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-17 15:40:27 --> Final output sent to browser
DEBUG - 2011-04-17 15:40:27 --> Total execution time: 0.1476
DEBUG - 2011-04-17 15:42:48 --> Config Class Initialized
DEBUG - 2011-04-17 15:42:48 --> Hooks Class Initialized
DEBUG - 2011-04-17 15:42:48 --> Utf8 Class Initialized
DEBUG - 2011-04-17 15:42:48 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 15:42:48 --> URI Class Initialized
DEBUG - 2011-04-17 15:42:48 --> Router Class Initialized
DEBUG - 2011-04-17 15:42:48 --> Output Class Initialized
DEBUG - 2011-04-17 15:42:48 --> Input Class Initialized
DEBUG - 2011-04-17 15:42:48 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-17 15:42:48 --> Language Class Initialized
DEBUG - 2011-04-17 15:42:48 --> Loader Class Initialized
DEBUG - 2011-04-17 15:42:48 --> Controller Class Initialized
DEBUG - 2011-04-17 15:42:48 --> Model Class Initialized
DEBUG - 2011-04-17 15:42:48 --> Model Class Initialized
DEBUG - 2011-04-17 15:42:48 --> Model Class Initialized
DEBUG - 2011-04-17 15:42:48 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-17 15:42:48 --> Database Driver Class Initialized
DEBUG - 2011-04-17 15:42:48 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-17 15:42:48 --> Helper loaded: url_helper
DEBUG - 2011-04-17 15:42:48 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-17 15:42:48 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-17 15:42:48 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-17 15:42:48 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-17 15:42:48 --> Final output sent to browser
DEBUG - 2011-04-17 15:42:48 --> Total execution time: 0.0540
DEBUG - 2011-04-17 15:42:50 --> Config Class Initialized
DEBUG - 2011-04-17 15:42:50 --> Hooks Class Initialized
DEBUG - 2011-04-17 15:42:50 --> Utf8 Class Initialized
DEBUG - 2011-04-17 15:42:50 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 15:42:50 --> URI Class Initialized
DEBUG - 2011-04-17 15:42:50 --> Router Class Initialized
ERROR - 2011-04-17 15:42:50 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-17 15:46:59 --> Config Class Initialized
DEBUG - 2011-04-17 15:46:59 --> Hooks Class Initialized
DEBUG - 2011-04-17 15:46:59 --> Utf8 Class Initialized
DEBUG - 2011-04-17 15:46:59 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 15:46:59 --> URI Class Initialized
DEBUG - 2011-04-17 15:46:59 --> Router Class Initialized
DEBUG - 2011-04-17 15:46:59 --> No URI present. Default controller set.
DEBUG - 2011-04-17 15:46:59 --> Output Class Initialized
DEBUG - 2011-04-17 15:46:59 --> Input Class Initialized
DEBUG - 2011-04-17 15:46:59 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-17 15:46:59 --> Language Class Initialized
DEBUG - 2011-04-17 15:46:59 --> Loader Class Initialized
DEBUG - 2011-04-17 15:46:59 --> Controller Class Initialized
DEBUG - 2011-04-17 15:46:59 --> File loaded: application/views/splash/main.php
DEBUG - 2011-04-17 15:46:59 --> Helper loaded: url_helper
DEBUG - 2011-04-17 15:46:59 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-17 15:46:59 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-17 15:46:59 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-17 15:46:59 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-17 15:46:59 --> Final output sent to browser
DEBUG - 2011-04-17 15:46:59 --> Total execution time: 0.0579
DEBUG - 2011-04-17 15:47:02 --> Config Class Initialized
DEBUG - 2011-04-17 15:47:02 --> Hooks Class Initialized
DEBUG - 2011-04-17 15:47:02 --> Utf8 Class Initialized
DEBUG - 2011-04-17 15:47:02 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 15:47:02 --> URI Class Initialized
DEBUG - 2011-04-17 15:47:02 --> Router Class Initialized
ERROR - 2011-04-17 15:47:02 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-17 15:47:04 --> Config Class Initialized
DEBUG - 2011-04-17 15:47:04 --> Hooks Class Initialized
DEBUG - 2011-04-17 15:47:04 --> Utf8 Class Initialized
DEBUG - 2011-04-17 15:47:04 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 15:47:04 --> URI Class Initialized
DEBUG - 2011-04-17 15:47:04 --> Router Class Initialized
ERROR - 2011-04-17 15:47:04 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-17 15:56:13 --> Config Class Initialized
DEBUG - 2011-04-17 15:56:13 --> Hooks Class Initialized
DEBUG - 2011-04-17 15:56:13 --> Utf8 Class Initialized
DEBUG - 2011-04-17 15:56:13 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 15:56:13 --> URI Class Initialized
DEBUG - 2011-04-17 15:56:13 --> Router Class Initialized
DEBUG - 2011-04-17 15:56:13 --> Output Class Initialized
DEBUG - 2011-04-17 15:56:13 --> Input Class Initialized
DEBUG - 2011-04-17 15:56:13 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-17 15:56:13 --> Language Class Initialized
DEBUG - 2011-04-17 15:56:13 --> Loader Class Initialized
DEBUG - 2011-04-17 15:56:13 --> Controller Class Initialized
ERROR - 2011-04-17 15:56:14 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-17 15:56:14 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-17 15:56:14 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-17 15:56:14 --> Model Class Initialized
DEBUG - 2011-04-17 15:56:14 --> Model Class Initialized
DEBUG - 2011-04-17 15:56:14 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-17 15:56:14 --> Database Driver Class Initialized
DEBUG - 2011-04-17 15:56:14 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-17 15:56:14 --> Helper loaded: url_helper
DEBUG - 2011-04-17 15:56:14 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-17 15:56:14 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-17 15:56:14 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-17 15:56:14 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-17 15:56:14 --> Final output sent to browser
DEBUG - 2011-04-17 15:56:14 --> Total execution time: 1.4904
DEBUG - 2011-04-17 16:05:25 --> Config Class Initialized
DEBUG - 2011-04-17 16:05:25 --> Hooks Class Initialized
DEBUG - 2011-04-17 16:05:25 --> Utf8 Class Initialized
DEBUG - 2011-04-17 16:05:25 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 16:05:25 --> URI Class Initialized
DEBUG - 2011-04-17 16:05:25 --> Router Class Initialized
DEBUG - 2011-04-17 16:05:25 --> Output Class Initialized
DEBUG - 2011-04-17 16:05:25 --> Input Class Initialized
DEBUG - 2011-04-17 16:05:25 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-17 16:05:25 --> Language Class Initialized
DEBUG - 2011-04-17 16:05:25 --> Loader Class Initialized
DEBUG - 2011-04-17 16:05:25 --> Controller Class Initialized
DEBUG - 2011-04-17 16:05:25 --> Model Class Initialized
DEBUG - 2011-04-17 16:05:25 --> Model Class Initialized
DEBUG - 2011-04-17 16:05:25 --> Model Class Initialized
DEBUG - 2011-04-17 16:05:25 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-17 16:05:25 --> Database Driver Class Initialized
DEBUG - 2011-04-17 16:05:26 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-17 16:05:26 --> Helper loaded: url_helper
DEBUG - 2011-04-17 16:05:26 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-17 16:05:26 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-17 16:05:26 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-17 16:05:26 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-17 16:05:26 --> Final output sent to browser
DEBUG - 2011-04-17 16:05:26 --> Total execution time: 1.0577
DEBUG - 2011-04-17 16:05:29 --> Config Class Initialized
DEBUG - 2011-04-17 16:05:29 --> Hooks Class Initialized
DEBUG - 2011-04-17 16:05:29 --> Utf8 Class Initialized
DEBUG - 2011-04-17 16:05:29 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 16:05:29 --> URI Class Initialized
DEBUG - 2011-04-17 16:05:29 --> Router Class Initialized
ERROR - 2011-04-17 16:05:29 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-17 16:05:47 --> Config Class Initialized
DEBUG - 2011-04-17 16:05:47 --> Hooks Class Initialized
DEBUG - 2011-04-17 16:05:47 --> Utf8 Class Initialized
DEBUG - 2011-04-17 16:05:47 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 16:05:47 --> URI Class Initialized
DEBUG - 2011-04-17 16:05:47 --> Router Class Initialized
DEBUG - 2011-04-17 16:05:47 --> Output Class Initialized
DEBUG - 2011-04-17 16:05:47 --> Input Class Initialized
DEBUG - 2011-04-17 16:05:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-17 16:05:47 --> Language Class Initialized
DEBUG - 2011-04-17 16:05:47 --> Loader Class Initialized
DEBUG - 2011-04-17 16:05:47 --> Controller Class Initialized
DEBUG - 2011-04-17 16:05:47 --> Model Class Initialized
DEBUG - 2011-04-17 16:05:47 --> Model Class Initialized
DEBUG - 2011-04-17 16:05:47 --> Model Class Initialized
DEBUG - 2011-04-17 16:05:47 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-17 16:05:47 --> Database Driver Class Initialized
DEBUG - 2011-04-17 16:05:47 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-17 16:05:47 --> Helper loaded: url_helper
DEBUG - 2011-04-17 16:05:47 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-17 16:05:47 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-17 16:05:47 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-17 16:05:47 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-17 16:05:47 --> Final output sent to browser
DEBUG - 2011-04-17 16:05:47 --> Total execution time: 0.2486
DEBUG - 2011-04-17 16:06:14 --> Config Class Initialized
DEBUG - 2011-04-17 16:06:14 --> Hooks Class Initialized
DEBUG - 2011-04-17 16:06:14 --> Utf8 Class Initialized
DEBUG - 2011-04-17 16:06:14 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 16:06:14 --> URI Class Initialized
DEBUG - 2011-04-17 16:06:14 --> Router Class Initialized
DEBUG - 2011-04-17 16:06:14 --> Output Class Initialized
DEBUG - 2011-04-17 16:06:14 --> Input Class Initialized
DEBUG - 2011-04-17 16:06:14 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-17 16:06:14 --> Language Class Initialized
DEBUG - 2011-04-17 16:06:14 --> Loader Class Initialized
DEBUG - 2011-04-17 16:06:14 --> Controller Class Initialized
DEBUG - 2011-04-17 16:06:14 --> Model Class Initialized
DEBUG - 2011-04-17 16:06:14 --> Model Class Initialized
DEBUG - 2011-04-17 16:06:14 --> Model Class Initialized
DEBUG - 2011-04-17 16:06:14 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-17 16:06:14 --> Database Driver Class Initialized
DEBUG - 2011-04-17 16:06:14 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-17 16:06:14 --> Helper loaded: url_helper
DEBUG - 2011-04-17 16:06:14 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-17 16:06:14 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-17 16:06:14 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-17 16:06:14 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-17 16:06:14 --> Final output sent to browser
DEBUG - 2011-04-17 16:06:14 --> Total execution time: 0.2585
DEBUG - 2011-04-17 16:06:38 --> Config Class Initialized
DEBUG - 2011-04-17 16:06:38 --> Hooks Class Initialized
DEBUG - 2011-04-17 16:06:38 --> Utf8 Class Initialized
DEBUG - 2011-04-17 16:06:38 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 16:06:38 --> URI Class Initialized
DEBUG - 2011-04-17 16:06:38 --> Router Class Initialized
DEBUG - 2011-04-17 16:06:38 --> Output Class Initialized
DEBUG - 2011-04-17 16:06:38 --> Input Class Initialized
DEBUG - 2011-04-17 16:06:38 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-17 16:06:38 --> Language Class Initialized
DEBUG - 2011-04-17 16:06:38 --> Loader Class Initialized
DEBUG - 2011-04-17 16:06:38 --> Controller Class Initialized
DEBUG - 2011-04-17 16:06:38 --> Model Class Initialized
DEBUG - 2011-04-17 16:06:38 --> Model Class Initialized
DEBUG - 2011-04-17 16:06:38 --> Model Class Initialized
DEBUG - 2011-04-17 16:06:38 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-17 16:06:38 --> Database Driver Class Initialized
DEBUG - 2011-04-17 16:06:38 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-17 16:06:38 --> Helper loaded: url_helper
DEBUG - 2011-04-17 16:06:38 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-17 16:06:38 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-17 16:06:38 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-17 16:06:38 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-17 16:06:38 --> Final output sent to browser
DEBUG - 2011-04-17 16:06:38 --> Total execution time: 0.3055
DEBUG - 2011-04-17 16:07:08 --> Config Class Initialized
DEBUG - 2011-04-17 16:07:08 --> Hooks Class Initialized
DEBUG - 2011-04-17 16:07:08 --> Utf8 Class Initialized
DEBUG - 2011-04-17 16:07:08 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 16:07:08 --> URI Class Initialized
DEBUG - 2011-04-17 16:07:08 --> Router Class Initialized
DEBUG - 2011-04-17 16:07:08 --> Output Class Initialized
DEBUG - 2011-04-17 16:07:08 --> Input Class Initialized
DEBUG - 2011-04-17 16:07:08 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-17 16:07:08 --> Language Class Initialized
DEBUG - 2011-04-17 16:07:08 --> Loader Class Initialized
DEBUG - 2011-04-17 16:07:08 --> Controller Class Initialized
DEBUG - 2011-04-17 16:07:08 --> Model Class Initialized
DEBUG - 2011-04-17 16:07:08 --> Model Class Initialized
DEBUG - 2011-04-17 16:07:08 --> Model Class Initialized
DEBUG - 2011-04-17 16:07:08 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-17 16:07:08 --> Database Driver Class Initialized
DEBUG - 2011-04-17 16:07:08 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-17 16:07:08 --> Helper loaded: url_helper
DEBUG - 2011-04-17 16:07:08 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-17 16:07:08 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-17 16:07:08 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-17 16:07:08 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-17 16:07:08 --> Final output sent to browser
DEBUG - 2011-04-17 16:07:08 --> Total execution time: 0.2348
DEBUG - 2011-04-17 16:07:10 --> Config Class Initialized
DEBUG - 2011-04-17 16:07:10 --> Hooks Class Initialized
DEBUG - 2011-04-17 16:07:10 --> Utf8 Class Initialized
DEBUG - 2011-04-17 16:07:10 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 16:07:10 --> URI Class Initialized
DEBUG - 2011-04-17 16:07:10 --> Router Class Initialized
DEBUG - 2011-04-17 16:07:10 --> Output Class Initialized
DEBUG - 2011-04-17 16:07:10 --> Input Class Initialized
DEBUG - 2011-04-17 16:07:10 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-17 16:07:10 --> Language Class Initialized
DEBUG - 2011-04-17 16:07:10 --> Loader Class Initialized
DEBUG - 2011-04-17 16:07:10 --> Controller Class Initialized
DEBUG - 2011-04-17 16:07:10 --> Model Class Initialized
DEBUG - 2011-04-17 16:07:10 --> Model Class Initialized
DEBUG - 2011-04-17 16:07:10 --> Model Class Initialized
DEBUG - 2011-04-17 16:07:10 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-17 16:07:10 --> Database Driver Class Initialized
DEBUG - 2011-04-17 16:07:10 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-17 16:07:10 --> Helper loaded: url_helper
DEBUG - 2011-04-17 16:07:10 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-17 16:07:10 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-17 16:07:10 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-17 16:07:10 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-17 16:07:10 --> Final output sent to browser
DEBUG - 2011-04-17 16:07:10 --> Total execution time: 0.0693
DEBUG - 2011-04-17 16:32:14 --> Config Class Initialized
DEBUG - 2011-04-17 16:32:14 --> Hooks Class Initialized
DEBUG - 2011-04-17 16:32:14 --> Utf8 Class Initialized
DEBUG - 2011-04-17 16:32:14 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 16:32:14 --> URI Class Initialized
DEBUG - 2011-04-17 16:32:14 --> Router Class Initialized
DEBUG - 2011-04-17 16:32:14 --> Output Class Initialized
DEBUG - 2011-04-17 16:32:14 --> Input Class Initialized
DEBUG - 2011-04-17 16:32:14 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-17 16:32:14 --> Language Class Initialized
DEBUG - 2011-04-17 16:32:14 --> Loader Class Initialized
DEBUG - 2011-04-17 16:32:14 --> Controller Class Initialized
ERROR - 2011-04-17 16:32:14 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-17 16:32:14 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-17 16:32:14 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-17 16:32:14 --> Model Class Initialized
DEBUG - 2011-04-17 16:32:14 --> Model Class Initialized
DEBUG - 2011-04-17 16:32:14 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-17 16:32:15 --> Database Driver Class Initialized
DEBUG - 2011-04-17 16:32:15 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-17 16:32:15 --> Helper loaded: url_helper
DEBUG - 2011-04-17 16:32:15 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-17 16:32:15 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-17 16:32:15 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-17 16:32:15 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-17 16:32:15 --> Final output sent to browser
DEBUG - 2011-04-17 16:32:15 --> Total execution time: 0.8742
DEBUG - 2011-04-17 16:32:16 --> Config Class Initialized
DEBUG - 2011-04-17 16:32:16 --> Hooks Class Initialized
DEBUG - 2011-04-17 16:32:16 --> Utf8 Class Initialized
DEBUG - 2011-04-17 16:32:16 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 16:32:16 --> URI Class Initialized
DEBUG - 2011-04-17 16:32:16 --> Router Class Initialized
DEBUG - 2011-04-17 16:32:16 --> Output Class Initialized
DEBUG - 2011-04-17 16:32:16 --> Input Class Initialized
DEBUG - 2011-04-17 16:32:16 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-17 16:32:16 --> Language Class Initialized
DEBUG - 2011-04-17 16:32:16 --> Loader Class Initialized
DEBUG - 2011-04-17 16:32:16 --> Controller Class Initialized
DEBUG - 2011-04-17 16:32:17 --> Model Class Initialized
DEBUG - 2011-04-17 16:32:17 --> Model Class Initialized
DEBUG - 2011-04-17 16:32:17 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-17 16:32:17 --> Database Driver Class Initialized
DEBUG - 2011-04-17 16:32:17 --> Final output sent to browser
DEBUG - 2011-04-17 16:32:17 --> Total execution time: 0.8639
DEBUG - 2011-04-17 16:32:18 --> Config Class Initialized
DEBUG - 2011-04-17 16:32:18 --> Hooks Class Initialized
DEBUG - 2011-04-17 16:32:18 --> Utf8 Class Initialized
DEBUG - 2011-04-17 16:32:18 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 16:32:18 --> URI Class Initialized
DEBUG - 2011-04-17 16:32:18 --> Router Class Initialized
DEBUG - 2011-04-17 16:32:18 --> Output Class Initialized
DEBUG - 2011-04-17 16:32:18 --> Input Class Initialized
DEBUG - 2011-04-17 16:32:18 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-17 16:32:18 --> Language Class Initialized
DEBUG - 2011-04-17 16:32:18 --> Loader Class Initialized
DEBUG - 2011-04-17 16:32:18 --> Controller Class Initialized
ERROR - 2011-04-17 16:32:18 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-17 16:32:18 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-17 16:32:18 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-17 16:32:18 --> Model Class Initialized
DEBUG - 2011-04-17 16:32:18 --> Model Class Initialized
DEBUG - 2011-04-17 16:32:18 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-17 16:32:18 --> Database Driver Class Initialized
DEBUG - 2011-04-17 16:32:18 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-17 16:32:18 --> Helper loaded: url_helper
DEBUG - 2011-04-17 16:32:18 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-17 16:32:18 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-17 16:32:18 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-17 16:32:18 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-17 16:32:18 --> Final output sent to browser
DEBUG - 2011-04-17 16:32:18 --> Total execution time: 0.0305
DEBUG - 2011-04-17 16:32:18 --> Config Class Initialized
DEBUG - 2011-04-17 16:32:18 --> Hooks Class Initialized
DEBUG - 2011-04-17 16:32:18 --> Utf8 Class Initialized
DEBUG - 2011-04-17 16:32:18 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 16:32:18 --> URI Class Initialized
DEBUG - 2011-04-17 16:32:18 --> Router Class Initialized
ERROR - 2011-04-17 16:32:18 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-17 16:45:40 --> Config Class Initialized
DEBUG - 2011-04-17 16:45:40 --> Hooks Class Initialized
DEBUG - 2011-04-17 16:45:40 --> Utf8 Class Initialized
DEBUG - 2011-04-17 16:45:40 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 16:45:40 --> URI Class Initialized
DEBUG - 2011-04-17 16:45:40 --> Router Class Initialized
DEBUG - 2011-04-17 16:45:40 --> Output Class Initialized
DEBUG - 2011-04-17 16:45:40 --> Input Class Initialized
DEBUG - 2011-04-17 16:45:40 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-17 16:45:40 --> Language Class Initialized
DEBUG - 2011-04-17 16:45:41 --> Loader Class Initialized
DEBUG - 2011-04-17 16:45:41 --> Controller Class Initialized
ERROR - 2011-04-17 16:45:41 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-17 16:45:41 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-17 16:45:41 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-17 16:45:41 --> Model Class Initialized
DEBUG - 2011-04-17 16:45:41 --> Model Class Initialized
DEBUG - 2011-04-17 16:45:41 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-17 16:45:41 --> Database Driver Class Initialized
DEBUG - 2011-04-17 16:45:41 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-17 16:45:42 --> Helper loaded: url_helper
DEBUG - 2011-04-17 16:45:42 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-17 16:45:42 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-17 16:45:42 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-17 16:45:42 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-17 16:45:42 --> Final output sent to browser
DEBUG - 2011-04-17 16:45:42 --> Total execution time: 1.9740
DEBUG - 2011-04-17 17:44:31 --> Config Class Initialized
DEBUG - 2011-04-17 17:44:31 --> Hooks Class Initialized
DEBUG - 2011-04-17 17:44:31 --> Utf8 Class Initialized
DEBUG - 2011-04-17 17:44:31 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 17:44:31 --> URI Class Initialized
DEBUG - 2011-04-17 17:44:31 --> Router Class Initialized
DEBUG - 2011-04-17 17:44:31 --> No URI present. Default controller set.
DEBUG - 2011-04-17 17:44:31 --> Output Class Initialized
DEBUG - 2011-04-17 17:44:31 --> Input Class Initialized
DEBUG - 2011-04-17 17:44:31 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-17 17:44:31 --> Language Class Initialized
DEBUG - 2011-04-17 17:44:31 --> Loader Class Initialized
DEBUG - 2011-04-17 17:44:31 --> Controller Class Initialized
DEBUG - 2011-04-17 17:44:31 --> File loaded: application/views/splash/main.php
DEBUG - 2011-04-17 17:44:31 --> Helper loaded: url_helper
DEBUG - 2011-04-17 17:44:31 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-17 17:44:31 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-17 17:44:31 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-17 17:44:31 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-17 17:44:31 --> Final output sent to browser
DEBUG - 2011-04-17 17:44:31 --> Total execution time: 0.3491
DEBUG - 2011-04-17 17:44:34 --> Config Class Initialized
DEBUG - 2011-04-17 17:44:34 --> Hooks Class Initialized
DEBUG - 2011-04-17 17:44:34 --> Utf8 Class Initialized
DEBUG - 2011-04-17 17:44:34 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 17:44:34 --> URI Class Initialized
DEBUG - 2011-04-17 17:44:34 --> Router Class Initialized
DEBUG - 2011-04-17 17:44:34 --> Output Class Initialized
DEBUG - 2011-04-17 17:44:34 --> Input Class Initialized
DEBUG - 2011-04-17 17:44:34 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-17 17:44:34 --> Language Class Initialized
DEBUG - 2011-04-17 17:44:34 --> Loader Class Initialized
DEBUG - 2011-04-17 17:44:34 --> Controller Class Initialized
DEBUG - 2011-04-17 17:44:34 --> Model Class Initialized
DEBUG - 2011-04-17 17:44:34 --> Model Class Initialized
DEBUG - 2011-04-17 17:44:34 --> Model Class Initialized
DEBUG - 2011-04-17 17:44:34 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-17 17:44:34 --> Database Driver Class Initialized
DEBUG - 2011-04-17 17:44:34 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-17 17:44:34 --> Helper loaded: url_helper
DEBUG - 2011-04-17 17:44:34 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-17 17:44:34 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-17 17:44:34 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-17 17:44:34 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-17 17:44:34 --> Final output sent to browser
DEBUG - 2011-04-17 17:44:34 --> Total execution time: 0.7759
DEBUG - 2011-04-17 17:44:38 --> Config Class Initialized
DEBUG - 2011-04-17 17:44:38 --> Hooks Class Initialized
DEBUG - 2011-04-17 17:44:38 --> Utf8 Class Initialized
DEBUG - 2011-04-17 17:44:38 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 17:44:38 --> URI Class Initialized
DEBUG - 2011-04-17 17:44:38 --> Router Class Initialized
ERROR - 2011-04-17 17:44:38 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-17 17:45:38 --> Config Class Initialized
DEBUG - 2011-04-17 17:45:38 --> Hooks Class Initialized
DEBUG - 2011-04-17 17:45:38 --> Utf8 Class Initialized
DEBUG - 2011-04-17 17:45:38 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 17:45:38 --> URI Class Initialized
DEBUG - 2011-04-17 17:45:38 --> Router Class Initialized
DEBUG - 2011-04-17 17:45:38 --> Output Class Initialized
DEBUG - 2011-04-17 17:45:38 --> Input Class Initialized
DEBUG - 2011-04-17 17:45:38 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-17 17:45:38 --> Language Class Initialized
DEBUG - 2011-04-17 17:45:38 --> Loader Class Initialized
DEBUG - 2011-04-17 17:45:38 --> Controller Class Initialized
DEBUG - 2011-04-17 17:45:38 --> Model Class Initialized
DEBUG - 2011-04-17 17:45:38 --> Model Class Initialized
DEBUG - 2011-04-17 17:45:38 --> Model Class Initialized
DEBUG - 2011-04-17 17:45:38 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-17 17:45:38 --> Database Driver Class Initialized
DEBUG - 2011-04-17 17:45:38 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-17 17:45:38 --> Helper loaded: url_helper
DEBUG - 2011-04-17 17:45:38 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-17 17:45:38 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-17 17:45:38 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-17 17:45:38 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-17 17:45:38 --> Final output sent to browser
DEBUG - 2011-04-17 17:45:38 --> Total execution time: 0.1296
DEBUG - 2011-04-17 17:45:42 --> Config Class Initialized
DEBUG - 2011-04-17 17:45:42 --> Hooks Class Initialized
DEBUG - 2011-04-17 17:45:42 --> Utf8 Class Initialized
DEBUG - 2011-04-17 17:45:42 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 17:45:42 --> URI Class Initialized
DEBUG - 2011-04-17 17:45:42 --> Router Class Initialized
ERROR - 2011-04-17 17:45:43 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-17 17:45:43 --> Config Class Initialized
DEBUG - 2011-04-17 17:45:43 --> Hooks Class Initialized
DEBUG - 2011-04-17 17:45:43 --> Utf8 Class Initialized
DEBUG - 2011-04-17 17:45:43 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 17:45:43 --> URI Class Initialized
DEBUG - 2011-04-17 17:45:43 --> Router Class Initialized
ERROR - 2011-04-17 17:45:43 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-17 17:45:43 --> Config Class Initialized
DEBUG - 2011-04-17 17:45:43 --> Hooks Class Initialized
DEBUG - 2011-04-17 17:45:43 --> Utf8 Class Initialized
DEBUG - 2011-04-17 17:45:43 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 17:45:43 --> URI Class Initialized
DEBUG - 2011-04-17 17:45:43 --> Router Class Initialized
ERROR - 2011-04-17 17:45:43 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-17 17:46:12 --> Config Class Initialized
DEBUG - 2011-04-17 17:46:12 --> Hooks Class Initialized
DEBUG - 2011-04-17 17:46:12 --> Utf8 Class Initialized
DEBUG - 2011-04-17 17:46:12 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 17:46:12 --> URI Class Initialized
DEBUG - 2011-04-17 17:46:12 --> Router Class Initialized
DEBUG - 2011-04-17 17:46:12 --> Output Class Initialized
DEBUG - 2011-04-17 17:46:12 --> Input Class Initialized
DEBUG - 2011-04-17 17:46:12 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-17 17:46:12 --> Language Class Initialized
DEBUG - 2011-04-17 17:46:12 --> Loader Class Initialized
DEBUG - 2011-04-17 17:46:12 --> Controller Class Initialized
ERROR - 2011-04-17 17:46:13 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-17 17:46:13 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-17 17:46:13 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-17 17:46:13 --> Model Class Initialized
DEBUG - 2011-04-17 17:46:13 --> Model Class Initialized
DEBUG - 2011-04-17 17:46:13 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-17 17:46:13 --> Database Driver Class Initialized
DEBUG - 2011-04-17 17:46:13 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-17 17:46:13 --> Helper loaded: url_helper
DEBUG - 2011-04-17 17:46:13 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-17 17:46:13 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-17 17:46:13 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-17 17:46:13 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-17 17:46:13 --> Final output sent to browser
DEBUG - 2011-04-17 17:46:13 --> Total execution time: 0.7675
DEBUG - 2011-04-17 17:46:14 --> Config Class Initialized
DEBUG - 2011-04-17 17:46:14 --> Hooks Class Initialized
DEBUG - 2011-04-17 17:46:14 --> Utf8 Class Initialized
DEBUG - 2011-04-17 17:46:14 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 17:46:14 --> URI Class Initialized
DEBUG - 2011-04-17 17:46:14 --> Router Class Initialized
DEBUG - 2011-04-17 17:46:14 --> Output Class Initialized
DEBUG - 2011-04-17 17:46:14 --> Input Class Initialized
DEBUG - 2011-04-17 17:46:14 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-17 17:46:14 --> Language Class Initialized
DEBUG - 2011-04-17 17:46:14 --> Loader Class Initialized
DEBUG - 2011-04-17 17:46:14 --> Controller Class Initialized
DEBUG - 2011-04-17 17:46:14 --> Model Class Initialized
DEBUG - 2011-04-17 17:46:14 --> Model Class Initialized
DEBUG - 2011-04-17 17:46:14 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-17 17:46:14 --> Database Driver Class Initialized
DEBUG - 2011-04-17 17:46:15 --> Final output sent to browser
DEBUG - 2011-04-17 17:46:15 --> Total execution time: 1.0573
DEBUG - 2011-04-17 17:46:25 --> Config Class Initialized
DEBUG - 2011-04-17 17:46:25 --> Hooks Class Initialized
DEBUG - 2011-04-17 17:46:25 --> Utf8 Class Initialized
DEBUG - 2011-04-17 17:46:25 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 17:46:25 --> URI Class Initialized
DEBUG - 2011-04-17 17:46:25 --> Router Class Initialized
DEBUG - 2011-04-17 17:46:25 --> Output Class Initialized
DEBUG - 2011-04-17 17:46:25 --> Input Class Initialized
DEBUG - 2011-04-17 17:46:25 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-17 17:46:25 --> Language Class Initialized
DEBUG - 2011-04-17 17:46:25 --> Loader Class Initialized
DEBUG - 2011-04-17 17:46:25 --> Controller Class Initialized
ERROR - 2011-04-17 17:46:25 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-17 17:46:25 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-17 17:46:25 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-17 17:46:25 --> Model Class Initialized
DEBUG - 2011-04-17 17:46:25 --> Model Class Initialized
DEBUG - 2011-04-17 17:46:25 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-17 17:46:25 --> Database Driver Class Initialized
DEBUG - 2011-04-17 17:46:25 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-17 17:46:25 --> Helper loaded: url_helper
DEBUG - 2011-04-17 17:46:25 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-17 17:46:25 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-17 17:46:25 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-17 17:46:25 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-17 17:46:25 --> Final output sent to browser
DEBUG - 2011-04-17 17:46:25 --> Total execution time: 0.0631
DEBUG - 2011-04-17 17:46:26 --> Config Class Initialized
DEBUG - 2011-04-17 17:46:26 --> Hooks Class Initialized
DEBUG - 2011-04-17 17:46:26 --> Utf8 Class Initialized
DEBUG - 2011-04-17 17:46:26 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 17:46:26 --> URI Class Initialized
DEBUG - 2011-04-17 17:46:26 --> Router Class Initialized
DEBUG - 2011-04-17 17:46:26 --> Output Class Initialized
DEBUG - 2011-04-17 17:46:26 --> Input Class Initialized
DEBUG - 2011-04-17 17:46:26 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-17 17:46:26 --> Language Class Initialized
DEBUG - 2011-04-17 17:46:26 --> Loader Class Initialized
DEBUG - 2011-04-17 17:46:26 --> Controller Class Initialized
DEBUG - 2011-04-17 17:46:26 --> Model Class Initialized
DEBUG - 2011-04-17 17:46:26 --> Model Class Initialized
DEBUG - 2011-04-17 17:46:26 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-17 17:46:26 --> Database Driver Class Initialized
DEBUG - 2011-04-17 17:46:26 --> Final output sent to browser
DEBUG - 2011-04-17 17:46:26 --> Total execution time: 0.6146
DEBUG - 2011-04-17 17:46:33 --> Config Class Initialized
DEBUG - 2011-04-17 17:46:33 --> Hooks Class Initialized
DEBUG - 2011-04-17 17:46:33 --> Utf8 Class Initialized
DEBUG - 2011-04-17 17:46:33 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 17:46:33 --> URI Class Initialized
DEBUG - 2011-04-17 17:46:33 --> Router Class Initialized
DEBUG - 2011-04-17 17:46:33 --> Output Class Initialized
DEBUG - 2011-04-17 17:46:33 --> Input Class Initialized
DEBUG - 2011-04-17 17:46:33 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-17 17:46:33 --> Language Class Initialized
DEBUG - 2011-04-17 17:46:33 --> Loader Class Initialized
DEBUG - 2011-04-17 17:46:33 --> Controller Class Initialized
ERROR - 2011-04-17 17:46:33 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-17 17:46:33 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-17 17:46:33 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-17 17:46:33 --> Model Class Initialized
DEBUG - 2011-04-17 17:46:33 --> Model Class Initialized
DEBUG - 2011-04-17 17:46:33 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-17 17:46:33 --> Database Driver Class Initialized
DEBUG - 2011-04-17 17:46:33 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-17 17:46:33 --> Helper loaded: url_helper
DEBUG - 2011-04-17 17:46:33 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-17 17:46:33 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-17 17:46:33 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-17 17:46:33 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-17 17:46:33 --> Final output sent to browser
DEBUG - 2011-04-17 17:46:33 --> Total execution time: 0.0666
DEBUG - 2011-04-17 17:46:33 --> Config Class Initialized
DEBUG - 2011-04-17 17:46:33 --> Hooks Class Initialized
DEBUG - 2011-04-17 17:46:33 --> Utf8 Class Initialized
DEBUG - 2011-04-17 17:46:33 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 17:46:33 --> URI Class Initialized
DEBUG - 2011-04-17 17:46:33 --> Router Class Initialized
DEBUG - 2011-04-17 17:46:33 --> Output Class Initialized
DEBUG - 2011-04-17 17:46:33 --> Input Class Initialized
DEBUG - 2011-04-17 17:46:33 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-17 17:46:33 --> Language Class Initialized
DEBUG - 2011-04-17 17:46:33 --> Loader Class Initialized
DEBUG - 2011-04-17 17:46:33 --> Controller Class Initialized
DEBUG - 2011-04-17 17:46:33 --> Model Class Initialized
DEBUG - 2011-04-17 17:46:33 --> Model Class Initialized
DEBUG - 2011-04-17 17:46:33 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-17 17:46:34 --> Database Driver Class Initialized
DEBUG - 2011-04-17 17:46:34 --> Final output sent to browser
DEBUG - 2011-04-17 17:46:34 --> Total execution time: 0.6379
DEBUG - 2011-04-17 17:46:42 --> Config Class Initialized
DEBUG - 2011-04-17 17:46:42 --> Hooks Class Initialized
DEBUG - 2011-04-17 17:46:42 --> Utf8 Class Initialized
DEBUG - 2011-04-17 17:46:42 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 17:46:42 --> URI Class Initialized
DEBUG - 2011-04-17 17:46:42 --> Router Class Initialized
DEBUG - 2011-04-17 17:46:42 --> Output Class Initialized
DEBUG - 2011-04-17 17:46:42 --> Input Class Initialized
DEBUG - 2011-04-17 17:46:42 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-17 17:46:42 --> Language Class Initialized
DEBUG - 2011-04-17 17:46:42 --> Loader Class Initialized
DEBUG - 2011-04-17 17:46:42 --> Controller Class Initialized
ERROR - 2011-04-17 17:46:42 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-17 17:46:42 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-17 17:46:42 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-17 17:46:42 --> Model Class Initialized
DEBUG - 2011-04-17 17:46:42 --> Model Class Initialized
DEBUG - 2011-04-17 17:46:42 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-17 17:46:42 --> Database Driver Class Initialized
DEBUG - 2011-04-17 17:46:42 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-17 17:46:42 --> Helper loaded: url_helper
DEBUG - 2011-04-17 17:46:42 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-17 17:46:42 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-17 17:46:42 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-17 17:46:42 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-17 17:46:42 --> Final output sent to browser
DEBUG - 2011-04-17 17:46:42 --> Total execution time: 0.0393
DEBUG - 2011-04-17 17:46:43 --> Config Class Initialized
DEBUG - 2011-04-17 17:46:43 --> Hooks Class Initialized
DEBUG - 2011-04-17 17:46:43 --> Utf8 Class Initialized
DEBUG - 2011-04-17 17:46:43 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 17:46:43 --> URI Class Initialized
DEBUG - 2011-04-17 17:46:43 --> Router Class Initialized
DEBUG - 2011-04-17 17:46:43 --> Output Class Initialized
DEBUG - 2011-04-17 17:46:43 --> Input Class Initialized
DEBUG - 2011-04-17 17:46:43 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-17 17:46:43 --> Language Class Initialized
DEBUG - 2011-04-17 17:46:43 --> Loader Class Initialized
DEBUG - 2011-04-17 17:46:43 --> Controller Class Initialized
DEBUG - 2011-04-17 17:46:43 --> Model Class Initialized
DEBUG - 2011-04-17 17:46:43 --> Model Class Initialized
DEBUG - 2011-04-17 17:46:43 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-17 17:46:43 --> Database Driver Class Initialized
DEBUG - 2011-04-17 17:46:44 --> Final output sent to browser
DEBUG - 2011-04-17 17:46:44 --> Total execution time: 0.5479
DEBUG - 2011-04-17 17:46:51 --> Config Class Initialized
DEBUG - 2011-04-17 17:46:51 --> Hooks Class Initialized
DEBUG - 2011-04-17 17:46:51 --> Utf8 Class Initialized
DEBUG - 2011-04-17 17:46:51 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 17:46:51 --> URI Class Initialized
DEBUG - 2011-04-17 17:46:51 --> Router Class Initialized
DEBUG - 2011-04-17 17:46:51 --> Output Class Initialized
DEBUG - 2011-04-17 17:46:51 --> Input Class Initialized
DEBUG - 2011-04-17 17:46:51 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-17 17:46:51 --> Language Class Initialized
DEBUG - 2011-04-17 17:46:51 --> Loader Class Initialized
DEBUG - 2011-04-17 17:46:51 --> Controller Class Initialized
ERROR - 2011-04-17 17:46:51 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-17 17:46:51 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-17 17:46:51 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-17 17:46:51 --> Model Class Initialized
DEBUG - 2011-04-17 17:46:51 --> Model Class Initialized
DEBUG - 2011-04-17 17:46:51 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-17 17:46:51 --> Database Driver Class Initialized
DEBUG - 2011-04-17 17:46:51 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-17 17:46:51 --> Helper loaded: url_helper
DEBUG - 2011-04-17 17:46:51 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-17 17:46:51 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-17 17:46:51 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-17 17:46:51 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-17 17:46:51 --> Final output sent to browser
DEBUG - 2011-04-17 17:46:51 --> Total execution time: 0.1069
DEBUG - 2011-04-17 17:46:52 --> Config Class Initialized
DEBUG - 2011-04-17 17:46:52 --> Hooks Class Initialized
DEBUG - 2011-04-17 17:46:52 --> Utf8 Class Initialized
DEBUG - 2011-04-17 17:46:52 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 17:46:52 --> URI Class Initialized
DEBUG - 2011-04-17 17:46:52 --> Router Class Initialized
DEBUG - 2011-04-17 17:46:52 --> Output Class Initialized
DEBUG - 2011-04-17 17:46:52 --> Input Class Initialized
DEBUG - 2011-04-17 17:46:52 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-17 17:46:52 --> Language Class Initialized
DEBUG - 2011-04-17 17:46:52 --> Loader Class Initialized
DEBUG - 2011-04-17 17:46:52 --> Controller Class Initialized
DEBUG - 2011-04-17 17:46:52 --> Model Class Initialized
DEBUG - 2011-04-17 17:46:52 --> Model Class Initialized
DEBUG - 2011-04-17 17:46:52 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-17 17:46:52 --> Database Driver Class Initialized
DEBUG - 2011-04-17 17:46:52 --> Final output sent to browser
DEBUG - 2011-04-17 17:46:52 --> Total execution time: 0.7171
DEBUG - 2011-04-17 17:47:08 --> Config Class Initialized
DEBUG - 2011-04-17 17:47:08 --> Hooks Class Initialized
DEBUG - 2011-04-17 17:47:08 --> Utf8 Class Initialized
DEBUG - 2011-04-17 17:47:08 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 17:47:08 --> URI Class Initialized
DEBUG - 2011-04-17 17:47:08 --> Router Class Initialized
DEBUG - 2011-04-17 17:47:08 --> Output Class Initialized
DEBUG - 2011-04-17 17:47:08 --> Input Class Initialized
DEBUG - 2011-04-17 17:47:08 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-17 17:47:08 --> Language Class Initialized
DEBUG - 2011-04-17 17:47:08 --> Loader Class Initialized
DEBUG - 2011-04-17 17:47:08 --> Controller Class Initialized
ERROR - 2011-04-17 17:47:08 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-17 17:47:08 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-17 17:47:08 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-17 17:47:08 --> Model Class Initialized
DEBUG - 2011-04-17 17:47:08 --> Model Class Initialized
DEBUG - 2011-04-17 17:47:08 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-17 17:47:08 --> Database Driver Class Initialized
DEBUG - 2011-04-17 17:47:08 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-17 17:47:08 --> Helper loaded: url_helper
DEBUG - 2011-04-17 17:47:08 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-17 17:47:08 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-17 17:47:08 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-17 17:47:08 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-17 17:47:08 --> Final output sent to browser
DEBUG - 2011-04-17 17:47:08 --> Total execution time: 0.1136
DEBUG - 2011-04-17 17:47:09 --> Config Class Initialized
DEBUG - 2011-04-17 17:47:09 --> Hooks Class Initialized
DEBUG - 2011-04-17 17:47:09 --> Utf8 Class Initialized
DEBUG - 2011-04-17 17:47:09 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 17:47:09 --> URI Class Initialized
DEBUG - 2011-04-17 17:47:09 --> Router Class Initialized
DEBUG - 2011-04-17 17:47:09 --> Output Class Initialized
DEBUG - 2011-04-17 17:47:09 --> Input Class Initialized
DEBUG - 2011-04-17 17:47:09 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-17 17:47:09 --> Language Class Initialized
DEBUG - 2011-04-17 17:47:09 --> Loader Class Initialized
DEBUG - 2011-04-17 17:47:09 --> Controller Class Initialized
DEBUG - 2011-04-17 17:47:09 --> Model Class Initialized
DEBUG - 2011-04-17 17:47:09 --> Model Class Initialized
DEBUG - 2011-04-17 17:47:09 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-17 17:47:09 --> Database Driver Class Initialized
DEBUG - 2011-04-17 17:47:10 --> Final output sent to browser
DEBUG - 2011-04-17 17:47:10 --> Total execution time: 1.1044
DEBUG - 2011-04-17 17:47:14 --> Config Class Initialized
DEBUG - 2011-04-17 17:47:14 --> Hooks Class Initialized
DEBUG - 2011-04-17 17:47:14 --> Utf8 Class Initialized
DEBUG - 2011-04-17 17:47:14 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 17:47:14 --> URI Class Initialized
DEBUG - 2011-04-17 17:47:14 --> Router Class Initialized
DEBUG - 2011-04-17 17:47:14 --> Output Class Initialized
DEBUG - 2011-04-17 17:47:14 --> Input Class Initialized
DEBUG - 2011-04-17 17:47:14 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-17 17:47:14 --> Language Class Initialized
DEBUG - 2011-04-17 17:47:14 --> Loader Class Initialized
DEBUG - 2011-04-17 17:47:14 --> Controller Class Initialized
ERROR - 2011-04-17 17:47:14 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-17 17:47:14 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-17 17:47:14 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-17 17:47:14 --> Model Class Initialized
DEBUG - 2011-04-17 17:47:14 --> Model Class Initialized
DEBUG - 2011-04-17 17:47:14 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-17 17:47:14 --> Database Driver Class Initialized
DEBUG - 2011-04-17 17:47:14 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-17 17:47:14 --> Helper loaded: url_helper
DEBUG - 2011-04-17 17:47:14 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-17 17:47:14 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-17 17:47:14 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-17 17:47:14 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-17 17:47:14 --> Final output sent to browser
DEBUG - 2011-04-17 17:47:14 --> Total execution time: 0.0451
DEBUG - 2011-04-17 17:47:15 --> Config Class Initialized
DEBUG - 2011-04-17 17:47:15 --> Hooks Class Initialized
DEBUG - 2011-04-17 17:47:15 --> Utf8 Class Initialized
DEBUG - 2011-04-17 17:47:15 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 17:47:15 --> URI Class Initialized
DEBUG - 2011-04-17 17:47:15 --> Router Class Initialized
DEBUG - 2011-04-17 17:47:15 --> Output Class Initialized
DEBUG - 2011-04-17 17:47:15 --> Input Class Initialized
DEBUG - 2011-04-17 17:47:15 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-17 17:47:15 --> Language Class Initialized
DEBUG - 2011-04-17 17:47:15 --> Loader Class Initialized
DEBUG - 2011-04-17 17:47:15 --> Controller Class Initialized
DEBUG - 2011-04-17 17:47:15 --> Model Class Initialized
DEBUG - 2011-04-17 17:47:15 --> Model Class Initialized
DEBUG - 2011-04-17 17:47:15 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-17 17:47:15 --> Database Driver Class Initialized
DEBUG - 2011-04-17 17:47:16 --> Final output sent to browser
DEBUG - 2011-04-17 17:47:16 --> Total execution time: 0.9800
DEBUG - 2011-04-17 17:47:20 --> Config Class Initialized
DEBUG - 2011-04-17 17:47:20 --> Hooks Class Initialized
DEBUG - 2011-04-17 17:47:20 --> Utf8 Class Initialized
DEBUG - 2011-04-17 17:47:20 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 17:47:20 --> URI Class Initialized
DEBUG - 2011-04-17 17:47:20 --> Router Class Initialized
DEBUG - 2011-04-17 17:47:20 --> Output Class Initialized
DEBUG - 2011-04-17 17:47:20 --> Input Class Initialized
DEBUG - 2011-04-17 17:47:20 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-17 17:47:20 --> Language Class Initialized
DEBUG - 2011-04-17 17:47:20 --> Loader Class Initialized
DEBUG - 2011-04-17 17:47:20 --> Controller Class Initialized
ERROR - 2011-04-17 17:47:20 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-17 17:47:20 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-17 17:47:20 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-17 17:47:20 --> Model Class Initialized
DEBUG - 2011-04-17 17:47:20 --> Model Class Initialized
DEBUG - 2011-04-17 17:47:20 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-17 17:47:20 --> Database Driver Class Initialized
DEBUG - 2011-04-17 17:47:20 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-17 17:47:20 --> Helper loaded: url_helper
DEBUG - 2011-04-17 17:47:20 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-17 17:47:20 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-17 17:47:20 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-17 17:47:20 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-17 17:47:20 --> Final output sent to browser
DEBUG - 2011-04-17 17:47:20 --> Total execution time: 0.0717
DEBUG - 2011-04-17 17:47:21 --> Config Class Initialized
DEBUG - 2011-04-17 17:47:21 --> Hooks Class Initialized
DEBUG - 2011-04-17 17:47:21 --> Utf8 Class Initialized
DEBUG - 2011-04-17 17:47:21 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 17:47:21 --> URI Class Initialized
DEBUG - 2011-04-17 17:47:21 --> Router Class Initialized
DEBUG - 2011-04-17 17:47:21 --> Output Class Initialized
DEBUG - 2011-04-17 17:47:21 --> Input Class Initialized
DEBUG - 2011-04-17 17:47:21 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-17 17:47:21 --> Language Class Initialized
DEBUG - 2011-04-17 17:47:21 --> Loader Class Initialized
DEBUG - 2011-04-17 17:47:21 --> Controller Class Initialized
DEBUG - 2011-04-17 17:47:21 --> Model Class Initialized
DEBUG - 2011-04-17 17:47:21 --> Model Class Initialized
DEBUG - 2011-04-17 17:47:21 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-17 17:47:21 --> Database Driver Class Initialized
DEBUG - 2011-04-17 17:47:22 --> Final output sent to browser
DEBUG - 2011-04-17 17:47:22 --> Total execution time: 1.2828
DEBUG - 2011-04-17 17:47:26 --> Config Class Initialized
DEBUG - 2011-04-17 17:47:26 --> Hooks Class Initialized
DEBUG - 2011-04-17 17:47:26 --> Utf8 Class Initialized
DEBUG - 2011-04-17 17:47:26 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 17:47:26 --> URI Class Initialized
DEBUG - 2011-04-17 17:47:26 --> Router Class Initialized
DEBUG - 2011-04-17 17:47:26 --> Output Class Initialized
DEBUG - 2011-04-17 17:47:26 --> Input Class Initialized
DEBUG - 2011-04-17 17:47:26 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-17 17:47:26 --> Language Class Initialized
DEBUG - 2011-04-17 17:47:26 --> Loader Class Initialized
DEBUG - 2011-04-17 17:47:26 --> Controller Class Initialized
ERROR - 2011-04-17 17:47:26 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-17 17:47:26 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-17 17:47:26 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-17 17:47:26 --> Model Class Initialized
DEBUG - 2011-04-17 17:47:26 --> Model Class Initialized
DEBUG - 2011-04-17 17:47:26 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-17 17:47:26 --> Database Driver Class Initialized
DEBUG - 2011-04-17 17:47:26 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-17 17:47:26 --> Helper loaded: url_helper
DEBUG - 2011-04-17 17:47:26 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-17 17:47:26 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-17 17:47:26 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-17 17:47:26 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-17 17:47:26 --> Final output sent to browser
DEBUG - 2011-04-17 17:47:26 --> Total execution time: 0.0665
DEBUG - 2011-04-17 17:47:27 --> Config Class Initialized
DEBUG - 2011-04-17 17:47:27 --> Hooks Class Initialized
DEBUG - 2011-04-17 17:47:27 --> Utf8 Class Initialized
DEBUG - 2011-04-17 17:47:27 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 17:47:27 --> URI Class Initialized
DEBUG - 2011-04-17 17:47:27 --> Router Class Initialized
DEBUG - 2011-04-17 17:47:27 --> Output Class Initialized
DEBUG - 2011-04-17 17:47:27 --> Input Class Initialized
DEBUG - 2011-04-17 17:47:27 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-17 17:47:27 --> Language Class Initialized
DEBUG - 2011-04-17 17:47:27 --> Loader Class Initialized
DEBUG - 2011-04-17 17:47:27 --> Controller Class Initialized
DEBUG - 2011-04-17 17:47:27 --> Model Class Initialized
DEBUG - 2011-04-17 17:47:27 --> Model Class Initialized
DEBUG - 2011-04-17 17:47:27 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-17 17:47:27 --> Database Driver Class Initialized
DEBUG - 2011-04-17 17:47:27 --> Final output sent to browser
DEBUG - 2011-04-17 17:47:27 --> Total execution time: 0.5601
DEBUG - 2011-04-17 17:47:33 --> Config Class Initialized
DEBUG - 2011-04-17 17:47:33 --> Hooks Class Initialized
DEBUG - 2011-04-17 17:47:33 --> Utf8 Class Initialized
DEBUG - 2011-04-17 17:47:33 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 17:47:33 --> URI Class Initialized
DEBUG - 2011-04-17 17:47:33 --> Router Class Initialized
DEBUG - 2011-04-17 17:47:33 --> Output Class Initialized
DEBUG - 2011-04-17 17:47:33 --> Input Class Initialized
DEBUG - 2011-04-17 17:47:33 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-17 17:47:33 --> Language Class Initialized
DEBUG - 2011-04-17 17:47:33 --> Loader Class Initialized
DEBUG - 2011-04-17 17:47:33 --> Controller Class Initialized
ERROR - 2011-04-17 17:47:33 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-17 17:47:33 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-17 17:47:33 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-17 17:47:33 --> Model Class Initialized
DEBUG - 2011-04-17 17:47:33 --> Model Class Initialized
DEBUG - 2011-04-17 17:47:33 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-17 17:47:33 --> Database Driver Class Initialized
DEBUG - 2011-04-17 17:47:33 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-17 17:47:33 --> Helper loaded: url_helper
DEBUG - 2011-04-17 17:47:33 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-17 17:47:33 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-17 17:47:33 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-17 17:47:33 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-17 17:47:33 --> Final output sent to browser
DEBUG - 2011-04-17 17:47:33 --> Total execution time: 0.1014
DEBUG - 2011-04-17 17:47:34 --> Config Class Initialized
DEBUG - 2011-04-17 17:47:34 --> Hooks Class Initialized
DEBUG - 2011-04-17 17:47:34 --> Utf8 Class Initialized
DEBUG - 2011-04-17 17:47:34 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 17:47:34 --> URI Class Initialized
DEBUG - 2011-04-17 17:47:34 --> Router Class Initialized
DEBUG - 2011-04-17 17:47:34 --> Output Class Initialized
DEBUG - 2011-04-17 17:47:34 --> Input Class Initialized
DEBUG - 2011-04-17 17:47:34 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-17 17:47:34 --> Language Class Initialized
DEBUG - 2011-04-17 17:47:34 --> Loader Class Initialized
DEBUG - 2011-04-17 17:47:34 --> Controller Class Initialized
DEBUG - 2011-04-17 17:47:34 --> Model Class Initialized
DEBUG - 2011-04-17 17:47:34 --> Model Class Initialized
DEBUG - 2011-04-17 17:47:34 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-17 17:47:34 --> Database Driver Class Initialized
DEBUG - 2011-04-17 17:47:35 --> Final output sent to browser
DEBUG - 2011-04-17 17:47:35 --> Total execution time: 0.4761
DEBUG - 2011-04-17 17:47:44 --> Config Class Initialized
DEBUG - 2011-04-17 17:47:44 --> Hooks Class Initialized
DEBUG - 2011-04-17 17:47:44 --> Utf8 Class Initialized
DEBUG - 2011-04-17 17:47:44 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 17:47:44 --> URI Class Initialized
DEBUG - 2011-04-17 17:47:44 --> Router Class Initialized
DEBUG - 2011-04-17 17:47:44 --> Output Class Initialized
DEBUG - 2011-04-17 17:47:44 --> Input Class Initialized
DEBUG - 2011-04-17 17:47:44 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-17 17:47:44 --> Language Class Initialized
DEBUG - 2011-04-17 17:47:44 --> Loader Class Initialized
DEBUG - 2011-04-17 17:47:44 --> Controller Class Initialized
ERROR - 2011-04-17 17:47:44 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-17 17:47:44 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-17 17:47:44 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-17 17:47:44 --> Model Class Initialized
DEBUG - 2011-04-17 17:47:44 --> Model Class Initialized
DEBUG - 2011-04-17 17:47:44 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-17 17:47:44 --> Database Driver Class Initialized
DEBUG - 2011-04-17 17:47:44 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-17 17:47:44 --> Helper loaded: url_helper
DEBUG - 2011-04-17 17:47:44 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-17 17:47:44 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-17 17:47:44 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-17 17:47:44 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-17 17:47:44 --> Final output sent to browser
DEBUG - 2011-04-17 17:47:44 --> Total execution time: 0.0465
DEBUG - 2011-04-17 17:47:45 --> Config Class Initialized
DEBUG - 2011-04-17 17:47:45 --> Hooks Class Initialized
DEBUG - 2011-04-17 17:47:45 --> Utf8 Class Initialized
DEBUG - 2011-04-17 17:47:45 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 17:47:45 --> URI Class Initialized
DEBUG - 2011-04-17 17:47:45 --> Router Class Initialized
DEBUG - 2011-04-17 17:47:45 --> Output Class Initialized
DEBUG - 2011-04-17 17:47:45 --> Input Class Initialized
DEBUG - 2011-04-17 17:47:45 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-17 17:47:45 --> Language Class Initialized
DEBUG - 2011-04-17 17:47:45 --> Loader Class Initialized
DEBUG - 2011-04-17 17:47:45 --> Controller Class Initialized
DEBUG - 2011-04-17 17:47:45 --> Model Class Initialized
DEBUG - 2011-04-17 17:47:45 --> Model Class Initialized
DEBUG - 2011-04-17 17:47:45 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-17 17:47:45 --> Database Driver Class Initialized
DEBUG - 2011-04-17 17:47:46 --> Final output sent to browser
DEBUG - 2011-04-17 17:47:46 --> Total execution time: 0.6215
DEBUG - 2011-04-17 18:01:42 --> Config Class Initialized
DEBUG - 2011-04-17 18:01:42 --> Hooks Class Initialized
DEBUG - 2011-04-17 18:01:42 --> Config Class Initialized
DEBUG - 2011-04-17 18:01:42 --> Hooks Class Initialized
DEBUG - 2011-04-17 18:01:42 --> Utf8 Class Initialized
DEBUG - 2011-04-17 18:01:42 --> Utf8 Class Initialized
DEBUG - 2011-04-17 18:01:42 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 18:01:42 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 18:01:42 --> URI Class Initialized
DEBUG - 2011-04-17 18:01:42 --> URI Class Initialized
DEBUG - 2011-04-17 18:01:43 --> Router Class Initialized
DEBUG - 2011-04-17 18:01:43 --> Router Class Initialized
DEBUG - 2011-04-17 18:01:43 --> Output Class Initialized
DEBUG - 2011-04-17 18:01:43 --> Output Class Initialized
DEBUG - 2011-04-17 18:01:43 --> Input Class Initialized
DEBUG - 2011-04-17 18:01:43 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-17 18:01:43 --> Input Class Initialized
DEBUG - 2011-04-17 18:01:43 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-17 18:01:43 --> Language Class Initialized
DEBUG - 2011-04-17 18:01:43 --> Language Class Initialized
DEBUG - 2011-04-17 18:01:43 --> Loader Class Initialized
DEBUG - 2011-04-17 18:01:43 --> Loader Class Initialized
DEBUG - 2011-04-17 18:01:43 --> Controller Class Initialized
DEBUG - 2011-04-17 18:01:43 --> Controller Class Initialized
DEBUG - 2011-04-17 18:01:43 --> Model Class Initialized
DEBUG - 2011-04-17 18:01:43 --> Model Class Initialized
DEBUG - 2011-04-17 18:01:43 --> Model Class Initialized
ERROR - 2011-04-17 18:01:43 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-17 18:01:43 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-17 18:01:43 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-17 18:01:43 --> Model Class Initialized
DEBUG - 2011-04-17 18:01:43 --> Model Class Initialized
DEBUG - 2011-04-17 18:01:43 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-17 18:01:43 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-17 18:01:44 --> Database Driver Class Initialized
DEBUG - 2011-04-17 18:01:44 --> Database Driver Class Initialized
DEBUG - 2011-04-17 18:01:44 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-17 18:01:44 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-17 18:01:44 --> Helper loaded: url_helper
DEBUG - 2011-04-17 18:01:44 --> Helper loaded: url_helper
DEBUG - 2011-04-17 18:01:44 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-17 18:01:44 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-17 18:01:44 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-17 18:01:44 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-17 18:01:44 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-17 18:01:44 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-17 18:01:44 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-17 18:01:44 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-17 18:01:44 --> Final output sent to browser
DEBUG - 2011-04-17 18:01:44 --> Total execution time: 1.8930
DEBUG - 2011-04-17 18:01:44 --> Final output sent to browser
DEBUG - 2011-04-17 18:01:44 --> Total execution time: 1.9426
DEBUG - 2011-04-17 18:01:45 --> Config Class Initialized
DEBUG - 2011-04-17 18:01:45 --> Hooks Class Initialized
DEBUG - 2011-04-17 18:01:45 --> Utf8 Class Initialized
DEBUG - 2011-04-17 18:01:45 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 18:01:45 --> URI Class Initialized
DEBUG - 2011-04-17 18:01:45 --> Router Class Initialized
DEBUG - 2011-04-17 18:01:45 --> Output Class Initialized
DEBUG - 2011-04-17 18:01:45 --> Input Class Initialized
DEBUG - 2011-04-17 18:01:45 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-17 18:01:45 --> Language Class Initialized
DEBUG - 2011-04-17 18:01:45 --> Loader Class Initialized
DEBUG - 2011-04-17 18:01:45 --> Controller Class Initialized
DEBUG - 2011-04-17 18:01:45 --> Model Class Initialized
DEBUG - 2011-04-17 18:01:45 --> Model Class Initialized
DEBUG - 2011-04-17 18:01:45 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-17 18:01:45 --> Database Driver Class Initialized
DEBUG - 2011-04-17 18:01:46 --> Final output sent to browser
DEBUG - 2011-04-17 18:01:46 --> Total execution time: 0.6700
DEBUG - 2011-04-17 18:01:47 --> Config Class Initialized
DEBUG - 2011-04-17 18:01:47 --> Hooks Class Initialized
DEBUG - 2011-04-17 18:01:47 --> Utf8 Class Initialized
DEBUG - 2011-04-17 18:01:47 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 18:01:47 --> URI Class Initialized
DEBUG - 2011-04-17 18:01:47 --> Router Class Initialized
ERROR - 2011-04-17 18:01:47 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-17 18:01:47 --> Config Class Initialized
DEBUG - 2011-04-17 18:01:47 --> Hooks Class Initialized
DEBUG - 2011-04-17 18:01:47 --> Utf8 Class Initialized
DEBUG - 2011-04-17 18:01:47 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 18:01:47 --> URI Class Initialized
DEBUG - 2011-04-17 18:01:47 --> Router Class Initialized
ERROR - 2011-04-17 18:01:47 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-17 18:31:43 --> Config Class Initialized
DEBUG - 2011-04-17 18:31:43 --> Hooks Class Initialized
DEBUG - 2011-04-17 18:31:43 --> Utf8 Class Initialized
DEBUG - 2011-04-17 18:31:43 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 18:31:43 --> URI Class Initialized
DEBUG - 2011-04-17 18:31:43 --> Router Class Initialized
DEBUG - 2011-04-17 18:31:43 --> Output Class Initialized
DEBUG - 2011-04-17 18:31:43 --> Input Class Initialized
DEBUG - 2011-04-17 18:31:43 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-17 18:31:43 --> Language Class Initialized
DEBUG - 2011-04-17 18:31:43 --> Loader Class Initialized
DEBUG - 2011-04-17 18:31:43 --> Controller Class Initialized
ERROR - 2011-04-17 18:31:44 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-17 18:31:44 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-17 18:31:44 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-17 18:31:44 --> Model Class Initialized
DEBUG - 2011-04-17 18:31:44 --> Model Class Initialized
DEBUG - 2011-04-17 18:31:44 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-17 18:31:44 --> Database Driver Class Initialized
DEBUG - 2011-04-17 18:31:44 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-17 18:31:44 --> Helper loaded: url_helper
DEBUG - 2011-04-17 18:31:44 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-17 18:31:44 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-17 18:31:44 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-17 18:31:44 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-17 18:31:44 --> Final output sent to browser
DEBUG - 2011-04-17 18:31:44 --> Total execution time: 0.6400
DEBUG - 2011-04-17 18:31:46 --> Config Class Initialized
DEBUG - 2011-04-17 18:31:46 --> Hooks Class Initialized
DEBUG - 2011-04-17 18:31:46 --> Utf8 Class Initialized
DEBUG - 2011-04-17 18:31:46 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 18:31:46 --> URI Class Initialized
DEBUG - 2011-04-17 18:31:46 --> Router Class Initialized
DEBUG - 2011-04-17 18:31:46 --> Output Class Initialized
DEBUG - 2011-04-17 18:31:46 --> Input Class Initialized
DEBUG - 2011-04-17 18:31:46 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-17 18:31:46 --> Language Class Initialized
DEBUG - 2011-04-17 18:31:46 --> Loader Class Initialized
DEBUG - 2011-04-17 18:31:46 --> Controller Class Initialized
DEBUG - 2011-04-17 18:31:46 --> Model Class Initialized
DEBUG - 2011-04-17 18:31:47 --> Model Class Initialized
DEBUG - 2011-04-17 18:31:47 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-17 18:31:47 --> Database Driver Class Initialized
DEBUG - 2011-04-17 18:31:47 --> Final output sent to browser
DEBUG - 2011-04-17 18:31:47 --> Total execution time: 1.0313
DEBUG - 2011-04-17 18:32:00 --> Config Class Initialized
DEBUG - 2011-04-17 18:32:00 --> Hooks Class Initialized
DEBUG - 2011-04-17 18:32:00 --> Utf8 Class Initialized
DEBUG - 2011-04-17 18:32:00 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 18:32:00 --> URI Class Initialized
DEBUG - 2011-04-17 18:32:00 --> Router Class Initialized
DEBUG - 2011-04-17 18:32:00 --> No URI present. Default controller set.
DEBUG - 2011-04-17 18:32:00 --> Output Class Initialized
DEBUG - 2011-04-17 18:32:00 --> Input Class Initialized
DEBUG - 2011-04-17 18:32:00 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-17 18:32:00 --> Language Class Initialized
DEBUG - 2011-04-17 18:32:00 --> Loader Class Initialized
DEBUG - 2011-04-17 18:32:00 --> Controller Class Initialized
DEBUG - 2011-04-17 18:32:00 --> File loaded: application/views/splash/main.php
DEBUG - 2011-04-17 18:32:00 --> Helper loaded: url_helper
DEBUG - 2011-04-17 18:32:00 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-17 18:32:00 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-17 18:32:00 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-17 18:32:00 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-17 18:32:00 --> Final output sent to browser
DEBUG - 2011-04-17 18:32:00 --> Total execution time: 0.0805
DEBUG - 2011-04-17 18:32:01 --> Config Class Initialized
DEBUG - 2011-04-17 18:32:01 --> Hooks Class Initialized
DEBUG - 2011-04-17 18:32:01 --> Utf8 Class Initialized
DEBUG - 2011-04-17 18:32:01 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 18:32:01 --> URI Class Initialized
DEBUG - 2011-04-17 18:32:01 --> Router Class Initialized
ERROR - 2011-04-17 18:32:01 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-17 18:32:02 --> Config Class Initialized
DEBUG - 2011-04-17 18:32:02 --> Hooks Class Initialized
DEBUG - 2011-04-17 18:32:02 --> Utf8 Class Initialized
DEBUG - 2011-04-17 18:32:02 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 18:32:02 --> URI Class Initialized
DEBUG - 2011-04-17 18:32:02 --> Router Class Initialized
ERROR - 2011-04-17 18:32:02 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-17 18:32:10 --> Config Class Initialized
DEBUG - 2011-04-17 18:32:10 --> Hooks Class Initialized
DEBUG - 2011-04-17 18:32:10 --> Utf8 Class Initialized
DEBUG - 2011-04-17 18:32:10 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 18:32:10 --> URI Class Initialized
DEBUG - 2011-04-17 18:32:10 --> Router Class Initialized
DEBUG - 2011-04-17 18:32:10 --> Output Class Initialized
DEBUG - 2011-04-17 18:32:10 --> Input Class Initialized
DEBUG - 2011-04-17 18:32:10 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-17 18:32:10 --> Language Class Initialized
DEBUG - 2011-04-17 18:32:10 --> Loader Class Initialized
DEBUG - 2011-04-17 18:32:10 --> Controller Class Initialized
DEBUG - 2011-04-17 18:32:10 --> Model Class Initialized
DEBUG - 2011-04-17 18:32:10 --> Model Class Initialized
DEBUG - 2011-04-17 18:32:10 --> Model Class Initialized
DEBUG - 2011-04-17 18:32:10 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-17 18:32:10 --> Database Driver Class Initialized
DEBUG - 2011-04-17 18:32:10 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-17 18:32:10 --> Helper loaded: url_helper
DEBUG - 2011-04-17 18:32:10 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-17 18:32:10 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-17 18:32:10 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-17 18:32:10 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-17 18:32:10 --> Final output sent to browser
DEBUG - 2011-04-17 18:32:10 --> Total execution time: 0.3193
DEBUG - 2011-04-17 18:32:13 --> Config Class Initialized
DEBUG - 2011-04-17 18:32:13 --> Hooks Class Initialized
DEBUG - 2011-04-17 18:32:13 --> Utf8 Class Initialized
DEBUG - 2011-04-17 18:32:13 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 18:32:13 --> URI Class Initialized
DEBUG - 2011-04-17 18:32:13 --> Router Class Initialized
ERROR - 2011-04-17 18:32:13 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-17 18:32:22 --> Config Class Initialized
DEBUG - 2011-04-17 18:32:22 --> Hooks Class Initialized
DEBUG - 2011-04-17 18:32:22 --> Utf8 Class Initialized
DEBUG - 2011-04-17 18:32:22 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 18:32:22 --> URI Class Initialized
DEBUG - 2011-04-17 18:32:22 --> Router Class Initialized
DEBUG - 2011-04-17 18:32:22 --> Output Class Initialized
DEBUG - 2011-04-17 18:32:22 --> Input Class Initialized
DEBUG - 2011-04-17 18:32:22 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-17 18:32:22 --> Language Class Initialized
DEBUG - 2011-04-17 18:32:22 --> Loader Class Initialized
DEBUG - 2011-04-17 18:32:22 --> Controller Class Initialized
DEBUG - 2011-04-17 18:32:22 --> Model Class Initialized
DEBUG - 2011-04-17 18:32:22 --> Model Class Initialized
DEBUG - 2011-04-17 18:32:22 --> Model Class Initialized
DEBUG - 2011-04-17 18:32:22 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-17 18:32:22 --> Database Driver Class Initialized
DEBUG - 2011-04-17 18:32:23 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-17 18:32:23 --> Helper loaded: url_helper
DEBUG - 2011-04-17 18:32:23 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-17 18:32:23 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-17 18:32:23 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-17 18:32:23 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-17 18:32:23 --> Final output sent to browser
DEBUG - 2011-04-17 18:32:23 --> Total execution time: 0.6290
DEBUG - 2011-04-17 18:32:26 --> Config Class Initialized
DEBUG - 2011-04-17 18:32:26 --> Hooks Class Initialized
DEBUG - 2011-04-17 18:32:26 --> Utf8 Class Initialized
DEBUG - 2011-04-17 18:32:26 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 18:32:26 --> URI Class Initialized
DEBUG - 2011-04-17 18:32:26 --> Router Class Initialized
ERROR - 2011-04-17 18:32:26 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-17 18:32:38 --> Config Class Initialized
DEBUG - 2011-04-17 18:32:38 --> Hooks Class Initialized
DEBUG - 2011-04-17 18:32:38 --> Utf8 Class Initialized
DEBUG - 2011-04-17 18:32:38 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 18:32:38 --> URI Class Initialized
DEBUG - 2011-04-17 18:32:38 --> Router Class Initialized
DEBUG - 2011-04-17 18:32:38 --> Output Class Initialized
DEBUG - 2011-04-17 18:32:38 --> Input Class Initialized
DEBUG - 2011-04-17 18:32:38 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-17 18:32:38 --> Language Class Initialized
DEBUG - 2011-04-17 18:32:38 --> Loader Class Initialized
DEBUG - 2011-04-17 18:32:38 --> Controller Class Initialized
DEBUG - 2011-04-17 18:32:38 --> Model Class Initialized
DEBUG - 2011-04-17 18:32:38 --> Model Class Initialized
DEBUG - 2011-04-17 18:32:38 --> Model Class Initialized
DEBUG - 2011-04-17 18:32:38 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-17 18:32:38 --> Database Driver Class Initialized
DEBUG - 2011-04-17 18:32:38 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-17 18:32:38 --> Helper loaded: url_helper
DEBUG - 2011-04-17 18:32:38 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-17 18:32:38 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-17 18:32:38 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-17 18:32:38 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-17 18:32:38 --> Final output sent to browser
DEBUG - 2011-04-17 18:32:38 --> Total execution time: 0.2998
DEBUG - 2011-04-17 18:32:39 --> Config Class Initialized
DEBUG - 2011-04-17 18:32:39 --> Hooks Class Initialized
DEBUG - 2011-04-17 18:32:39 --> Utf8 Class Initialized
DEBUG - 2011-04-17 18:32:39 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 18:32:39 --> URI Class Initialized
DEBUG - 2011-04-17 18:32:39 --> Router Class Initialized
DEBUG - 2011-04-17 18:32:39 --> Output Class Initialized
DEBUG - 2011-04-17 18:32:39 --> Input Class Initialized
DEBUG - 2011-04-17 18:32:39 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-17 18:32:39 --> Language Class Initialized
DEBUG - 2011-04-17 18:32:39 --> Loader Class Initialized
DEBUG - 2011-04-17 18:32:39 --> Controller Class Initialized
DEBUG - 2011-04-17 18:32:39 --> Model Class Initialized
DEBUG - 2011-04-17 18:32:39 --> Model Class Initialized
DEBUG - 2011-04-17 18:32:39 --> Model Class Initialized
DEBUG - 2011-04-17 18:32:39 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-17 18:32:39 --> Database Driver Class Initialized
DEBUG - 2011-04-17 18:32:39 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-17 18:32:39 --> Helper loaded: url_helper
DEBUG - 2011-04-17 18:32:39 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-17 18:32:39 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-17 18:32:39 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-17 18:32:39 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-17 18:32:39 --> Final output sent to browser
DEBUG - 2011-04-17 18:32:39 --> Total execution time: 0.1448
DEBUG - 2011-04-17 18:32:41 --> Config Class Initialized
DEBUG - 2011-04-17 18:32:41 --> Hooks Class Initialized
DEBUG - 2011-04-17 18:32:41 --> Utf8 Class Initialized
DEBUG - 2011-04-17 18:32:41 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 18:32:41 --> URI Class Initialized
DEBUG - 2011-04-17 18:32:41 --> Router Class Initialized
ERROR - 2011-04-17 18:32:41 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-17 18:32:51 --> Config Class Initialized
DEBUG - 2011-04-17 18:32:51 --> Hooks Class Initialized
DEBUG - 2011-04-17 18:32:51 --> Utf8 Class Initialized
DEBUG - 2011-04-17 18:32:51 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 18:32:51 --> URI Class Initialized
DEBUG - 2011-04-17 18:32:51 --> Router Class Initialized
DEBUG - 2011-04-17 18:32:51 --> Output Class Initialized
DEBUG - 2011-04-17 18:32:51 --> Input Class Initialized
DEBUG - 2011-04-17 18:32:51 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-17 18:32:51 --> Language Class Initialized
DEBUG - 2011-04-17 18:32:51 --> Loader Class Initialized
DEBUG - 2011-04-17 18:32:51 --> Controller Class Initialized
DEBUG - 2011-04-17 18:32:51 --> Model Class Initialized
DEBUG - 2011-04-17 18:32:51 --> Model Class Initialized
DEBUG - 2011-04-17 18:32:51 --> Model Class Initialized
DEBUG - 2011-04-17 18:32:51 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-17 18:32:51 --> Database Driver Class Initialized
DEBUG - 2011-04-17 18:32:51 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-17 18:32:51 --> Helper loaded: url_helper
DEBUG - 2011-04-17 18:32:51 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-17 18:32:51 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-17 18:32:51 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-17 18:32:51 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-17 18:32:51 --> Final output sent to browser
DEBUG - 2011-04-17 18:32:51 --> Total execution time: 0.2807
DEBUG - 2011-04-17 18:32:52 --> Config Class Initialized
DEBUG - 2011-04-17 18:32:52 --> Hooks Class Initialized
DEBUG - 2011-04-17 18:32:52 --> Utf8 Class Initialized
DEBUG - 2011-04-17 18:32:52 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 18:32:52 --> URI Class Initialized
DEBUG - 2011-04-17 18:32:52 --> Router Class Initialized
DEBUG - 2011-04-17 18:32:52 --> Output Class Initialized
DEBUG - 2011-04-17 18:32:52 --> Input Class Initialized
DEBUG - 2011-04-17 18:32:52 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-17 18:32:52 --> Language Class Initialized
DEBUG - 2011-04-17 18:32:52 --> Loader Class Initialized
DEBUG - 2011-04-17 18:32:52 --> Controller Class Initialized
DEBUG - 2011-04-17 18:32:52 --> Model Class Initialized
DEBUG - 2011-04-17 18:32:52 --> Model Class Initialized
DEBUG - 2011-04-17 18:32:52 --> Model Class Initialized
DEBUG - 2011-04-17 18:32:52 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-17 18:32:52 --> Database Driver Class Initialized
DEBUG - 2011-04-17 18:32:52 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-17 18:32:52 --> Helper loaded: url_helper
DEBUG - 2011-04-17 18:32:52 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-17 18:32:52 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-17 18:32:52 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-17 18:32:52 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-17 18:32:52 --> Final output sent to browser
DEBUG - 2011-04-17 18:32:52 --> Total execution time: 0.1006
DEBUG - 2011-04-17 18:32:53 --> Config Class Initialized
DEBUG - 2011-04-17 18:32:53 --> Hooks Class Initialized
DEBUG - 2011-04-17 18:32:53 --> Utf8 Class Initialized
DEBUG - 2011-04-17 18:32:53 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 18:32:53 --> URI Class Initialized
DEBUG - 2011-04-17 18:32:53 --> Router Class Initialized
DEBUG - 2011-04-17 18:32:53 --> Output Class Initialized
DEBUG - 2011-04-17 18:32:53 --> Input Class Initialized
DEBUG - 2011-04-17 18:32:53 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-17 18:32:53 --> Language Class Initialized
DEBUG - 2011-04-17 18:32:53 --> Loader Class Initialized
DEBUG - 2011-04-17 18:32:53 --> Controller Class Initialized
DEBUG - 2011-04-17 18:32:53 --> Model Class Initialized
DEBUG - 2011-04-17 18:32:53 --> Model Class Initialized
DEBUG - 2011-04-17 18:32:53 --> Model Class Initialized
DEBUG - 2011-04-17 18:32:53 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-17 18:32:53 --> Database Driver Class Initialized
DEBUG - 2011-04-17 18:32:53 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-17 18:32:53 --> Helper loaded: url_helper
DEBUG - 2011-04-17 18:32:53 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-17 18:32:53 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-17 18:32:53 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-17 18:32:53 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-17 18:32:53 --> Final output sent to browser
DEBUG - 2011-04-17 18:32:53 --> Total execution time: 0.1116
DEBUG - 2011-04-17 18:32:53 --> Config Class Initialized
DEBUG - 2011-04-17 18:32:53 --> Hooks Class Initialized
DEBUG - 2011-04-17 18:32:53 --> Utf8 Class Initialized
DEBUG - 2011-04-17 18:32:53 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 18:32:53 --> URI Class Initialized
DEBUG - 2011-04-17 18:32:53 --> Router Class Initialized
DEBUG - 2011-04-17 18:32:53 --> Output Class Initialized
DEBUG - 2011-04-17 18:32:53 --> Input Class Initialized
DEBUG - 2011-04-17 18:32:53 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-17 18:32:53 --> Language Class Initialized
DEBUG - 2011-04-17 18:32:53 --> Loader Class Initialized
DEBUG - 2011-04-17 18:32:53 --> Controller Class Initialized
DEBUG - 2011-04-17 18:32:53 --> Model Class Initialized
DEBUG - 2011-04-17 18:32:53 --> Model Class Initialized
DEBUG - 2011-04-17 18:32:53 --> Model Class Initialized
DEBUG - 2011-04-17 18:32:53 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-17 18:32:53 --> Database Driver Class Initialized
DEBUG - 2011-04-17 18:32:53 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-17 18:32:53 --> Helper loaded: url_helper
DEBUG - 2011-04-17 18:32:53 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-17 18:32:53 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-17 18:32:53 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-17 18:32:53 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-17 18:32:53 --> Final output sent to browser
DEBUG - 2011-04-17 18:32:53 --> Total execution time: 0.0900
DEBUG - 2011-04-17 18:32:53 --> Config Class Initialized
DEBUG - 2011-04-17 18:32:53 --> Hooks Class Initialized
DEBUG - 2011-04-17 18:32:53 --> Utf8 Class Initialized
DEBUG - 2011-04-17 18:32:53 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 18:32:53 --> URI Class Initialized
DEBUG - 2011-04-17 18:32:53 --> Router Class Initialized
ERROR - 2011-04-17 18:32:53 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-17 18:32:59 --> Config Class Initialized
DEBUG - 2011-04-17 18:32:59 --> Hooks Class Initialized
DEBUG - 2011-04-17 18:32:59 --> Utf8 Class Initialized
DEBUG - 2011-04-17 18:32:59 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 18:32:59 --> URI Class Initialized
DEBUG - 2011-04-17 18:32:59 --> Router Class Initialized
DEBUG - 2011-04-17 18:32:59 --> Output Class Initialized
DEBUG - 2011-04-17 18:32:59 --> Input Class Initialized
DEBUG - 2011-04-17 18:32:59 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-17 18:32:59 --> Language Class Initialized
DEBUG - 2011-04-17 18:32:59 --> Loader Class Initialized
DEBUG - 2011-04-17 18:32:59 --> Controller Class Initialized
DEBUG - 2011-04-17 18:32:59 --> Model Class Initialized
DEBUG - 2011-04-17 18:32:59 --> Model Class Initialized
DEBUG - 2011-04-17 18:32:59 --> Model Class Initialized
DEBUG - 2011-04-17 18:32:59 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-17 18:32:59 --> Database Driver Class Initialized
DEBUG - 2011-04-17 18:33:00 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-17 18:33:00 --> Helper loaded: url_helper
DEBUG - 2011-04-17 18:33:00 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-17 18:33:00 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-17 18:33:00 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-17 18:33:00 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-17 18:33:00 --> Final output sent to browser
DEBUG - 2011-04-17 18:33:00 --> Total execution time: 0.5171
DEBUG - 2011-04-17 18:33:01 --> Config Class Initialized
DEBUG - 2011-04-17 18:33:01 --> Hooks Class Initialized
DEBUG - 2011-04-17 18:33:01 --> Utf8 Class Initialized
DEBUG - 2011-04-17 18:33:01 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 18:33:01 --> URI Class Initialized
DEBUG - 2011-04-17 18:33:01 --> Router Class Initialized
DEBUG - 2011-04-17 18:33:01 --> Output Class Initialized
DEBUG - 2011-04-17 18:33:01 --> Input Class Initialized
DEBUG - 2011-04-17 18:33:01 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-17 18:33:01 --> Language Class Initialized
DEBUG - 2011-04-17 18:33:01 --> Loader Class Initialized
DEBUG - 2011-04-17 18:33:01 --> Controller Class Initialized
DEBUG - 2011-04-17 18:33:01 --> Model Class Initialized
DEBUG - 2011-04-17 18:33:01 --> Model Class Initialized
DEBUG - 2011-04-17 18:33:01 --> Model Class Initialized
DEBUG - 2011-04-17 18:33:01 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-17 18:33:01 --> Database Driver Class Initialized
DEBUG - 2011-04-17 18:33:01 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-17 18:33:01 --> Helper loaded: url_helper
DEBUG - 2011-04-17 18:33:01 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-17 18:33:01 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-17 18:33:01 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-17 18:33:01 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-17 18:33:01 --> Final output sent to browser
DEBUG - 2011-04-17 18:33:01 --> Total execution time: 0.0552
DEBUG - 2011-04-17 18:33:03 --> Config Class Initialized
DEBUG - 2011-04-17 18:33:03 --> Hooks Class Initialized
DEBUG - 2011-04-17 18:33:03 --> Utf8 Class Initialized
DEBUG - 2011-04-17 18:33:03 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 18:33:03 --> URI Class Initialized
DEBUG - 2011-04-17 18:33:03 --> Router Class Initialized
ERROR - 2011-04-17 18:33:03 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-17 20:03:57 --> Config Class Initialized
DEBUG - 2011-04-17 20:03:57 --> Config Class Initialized
DEBUG - 2011-04-17 20:03:58 --> Hooks Class Initialized
DEBUG - 2011-04-17 20:03:58 --> Hooks Class Initialized
DEBUG - 2011-04-17 20:03:59 --> Utf8 Class Initialized
DEBUG - 2011-04-17 20:03:59 --> Utf8 Class Initialized
DEBUG - 2011-04-17 20:03:59 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 20:03:59 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 20:04:00 --> URI Class Initialized
DEBUG - 2011-04-17 20:04:00 --> URI Class Initialized
DEBUG - 2011-04-17 20:04:01 --> Router Class Initialized
DEBUG - 2011-04-17 20:04:01 --> Router Class Initialized
DEBUG - 2011-04-17 20:04:03 --> Output Class Initialized
DEBUG - 2011-04-17 20:04:03 --> Output Class Initialized
DEBUG - 2011-04-17 20:04:04 --> Input Class Initialized
DEBUG - 2011-04-17 20:04:04 --> Input Class Initialized
DEBUG - 2011-04-17 20:04:04 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-17 20:04:04 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-17 20:04:04 --> Language Class Initialized
DEBUG - 2011-04-17 20:04:04 --> Language Class Initialized
DEBUG - 2011-04-17 20:04:06 --> Loader Class Initialized
DEBUG - 2011-04-17 20:04:06 --> Loader Class Initialized
DEBUG - 2011-04-17 20:04:06 --> Controller Class Initialized
DEBUG - 2011-04-17 20:04:06 --> Controller Class Initialized
DEBUG - 2011-04-17 20:04:08 --> Model Class Initialized
DEBUG - 2011-04-17 20:04:08 --> Model Class Initialized
ERROR - 2011-04-17 20:04:09 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-17 20:04:09 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-17 20:04:09 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-17 20:04:09 --> Model Class Initialized
DEBUG - 2011-04-17 20:04:09 --> Model Class Initialized
DEBUG - 2011-04-17 20:04:09 --> Model Class Initialized
DEBUG - 2011-04-17 20:04:09 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-17 20:04:09 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-17 20:04:11 --> Database Driver Class Initialized
DEBUG - 2011-04-17 20:04:11 --> Database Driver Class Initialized
ERROR - 2011-04-17 20:04:11 --> Severity: Warning  --> mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: Can't connect to local MySQL server through socket '/var/lib/mysql/mysql.sock' (11) /home1/raptorsr/public_html/arsenaliststats/system/database/drivers/mysql/mysql_driver.php 88
ERROR - 2011-04-17 20:04:11 --> Unable to connect to the database
ERROR - 2011-04-17 20:04:11 --> Severity: Warning  --> mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: Can't connect to local MySQL server through socket '/var/lib/mysql/mysql.sock' (11) /home1/raptorsr/public_html/arsenaliststats/system/database/drivers/mysql/mysql_driver.php 88
ERROR - 2011-04-17 20:04:12 --> Unable to connect to the database
DEBUG - 2011-04-17 20:04:13 --> Language file loaded: language/english/db_lang.php
DEBUG - 2011-04-17 20:04:13 --> Language file loaded: language/english/db_lang.php
DEBUG - 2011-04-17 20:20:26 --> Config Class Initialized
DEBUG - 2011-04-17 20:20:26 --> Hooks Class Initialized
DEBUG - 2011-04-17 20:20:26 --> Utf8 Class Initialized
DEBUG - 2011-04-17 20:20:26 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 20:20:26 --> URI Class Initialized
DEBUG - 2011-04-17 20:20:26 --> Router Class Initialized
DEBUG - 2011-04-17 20:20:26 --> Output Class Initialized
DEBUG - 2011-04-17 20:20:26 --> Input Class Initialized
DEBUG - 2011-04-17 20:20:26 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-17 20:20:26 --> Language Class Initialized
DEBUG - 2011-04-17 20:20:26 --> Loader Class Initialized
DEBUG - 2011-04-17 20:20:26 --> Controller Class Initialized
DEBUG - 2011-04-17 20:20:26 --> Model Class Initialized
DEBUG - 2011-04-17 20:20:26 --> Model Class Initialized
DEBUG - 2011-04-17 20:20:26 --> Model Class Initialized
DEBUG - 2011-04-17 20:20:26 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-17 20:20:26 --> Database Driver Class Initialized
DEBUG - 2011-04-17 20:20:29 --> Config Class Initialized
DEBUG - 2011-04-17 20:20:29 --> Hooks Class Initialized
DEBUG - 2011-04-17 20:20:29 --> Utf8 Class Initialized
DEBUG - 2011-04-17 20:20:29 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 20:20:29 --> URI Class Initialized
DEBUG - 2011-04-17 20:20:29 --> Router Class Initialized
DEBUG - 2011-04-17 20:20:29 --> Output Class Initialized
DEBUG - 2011-04-17 20:20:29 --> Input Class Initialized
DEBUG - 2011-04-17 20:20:29 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-17 20:20:29 --> Language Class Initialized
DEBUG - 2011-04-17 20:20:29 --> Loader Class Initialized
DEBUG - 2011-04-17 20:20:29 --> Controller Class Initialized
ERROR - 2011-04-17 20:20:29 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-17 20:20:29 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-17 20:20:29 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-17 20:20:29 --> Model Class Initialized
DEBUG - 2011-04-17 20:20:29 --> Model Class Initialized
DEBUG - 2011-04-17 20:20:29 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-17 20:20:29 --> Database Driver Class Initialized
DEBUG - 2011-04-17 20:20:29 --> Config Class Initialized
DEBUG - 2011-04-17 20:20:29 --> Hooks Class Initialized
DEBUG - 2011-04-17 20:20:29 --> Utf8 Class Initialized
DEBUG - 2011-04-17 20:20:29 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 20:20:29 --> URI Class Initialized
DEBUG - 2011-04-17 20:20:29 --> Router Class Initialized
DEBUG - 2011-04-17 20:20:29 --> Output Class Initialized
DEBUG - 2011-04-17 20:20:29 --> Input Class Initialized
DEBUG - 2011-04-17 20:20:29 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-17 20:20:29 --> Language Class Initialized
DEBUG - 2011-04-17 20:20:29 --> Loader Class Initialized
DEBUG - 2011-04-17 20:20:29 --> Controller Class Initialized
ERROR - 2011-04-17 20:20:29 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-17 20:20:29 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-17 20:20:29 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-17 20:20:29 --> Model Class Initialized
DEBUG - 2011-04-17 20:20:29 --> Model Class Initialized
DEBUG - 2011-04-17 20:20:29 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-17 20:20:29 --> Database Driver Class Initialized
DEBUG - 2011-04-17 20:20:31 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-17 20:20:31 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-17 20:20:31 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-17 20:20:31 --> Helper loaded: url_helper
DEBUG - 2011-04-17 20:20:31 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-17 20:20:31 --> Helper loaded: url_helper
DEBUG - 2011-04-17 20:20:31 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-17 20:20:31 --> Helper loaded: url_helper
DEBUG - 2011-04-17 20:20:31 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-17 20:20:31 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-17 20:20:31 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-17 20:20:31 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-17 20:20:31 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-17 20:20:31 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-17 20:20:31 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-17 20:20:31 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-17 20:20:31 --> Final output sent to browser
DEBUG - 2011-04-17 20:20:31 --> Total execution time: 2.2481
DEBUG - 2011-04-17 20:20:31 --> Final output sent to browser
DEBUG - 2011-04-17 20:20:31 --> Total execution time: 5.2339
DEBUG - 2011-04-17 20:20:31 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-17 20:20:31 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-17 20:20:31 --> Final output sent to browser
DEBUG - 2011-04-17 20:20:31 --> Total execution time: 1.7713
DEBUG - 2011-04-17 20:20:37 --> Config Class Initialized
DEBUG - 2011-04-17 20:20:37 --> Hooks Class Initialized
DEBUG - 2011-04-17 20:20:37 --> Utf8 Class Initialized
DEBUG - 2011-04-17 20:20:37 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 20:20:37 --> URI Class Initialized
DEBUG - 2011-04-17 20:20:37 --> Router Class Initialized
DEBUG - 2011-04-17 20:20:37 --> Output Class Initialized
DEBUG - 2011-04-17 20:20:37 --> Input Class Initialized
DEBUG - 2011-04-17 20:20:37 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-17 20:20:37 --> Language Class Initialized
DEBUG - 2011-04-17 20:20:37 --> Loader Class Initialized
DEBUG - 2011-04-17 20:20:37 --> Controller Class Initialized
DEBUG - 2011-04-17 20:20:37 --> Model Class Initialized
DEBUG - 2011-04-17 20:20:37 --> Model Class Initialized
DEBUG - 2011-04-17 20:20:37 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-17 20:20:37 --> Database Driver Class Initialized
DEBUG - 2011-04-17 20:20:38 --> Final output sent to browser
DEBUG - 2011-04-17 20:20:38 --> Total execution time: 0.6786
DEBUG - 2011-04-17 20:21:07 --> Config Class Initialized
DEBUG - 2011-04-17 20:21:07 --> Hooks Class Initialized
DEBUG - 2011-04-17 20:21:07 --> Utf8 Class Initialized
DEBUG - 2011-04-17 20:21:07 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 20:21:07 --> URI Class Initialized
DEBUG - 2011-04-17 20:21:07 --> Router Class Initialized
DEBUG - 2011-04-17 20:21:07 --> Output Class Initialized
DEBUG - 2011-04-17 20:21:07 --> Input Class Initialized
DEBUG - 2011-04-17 20:21:07 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-17 20:21:07 --> Language Class Initialized
DEBUG - 2011-04-17 20:21:07 --> Loader Class Initialized
DEBUG - 2011-04-17 20:21:07 --> Controller Class Initialized
ERROR - 2011-04-17 20:21:07 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-17 20:21:07 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-17 20:21:07 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-17 20:21:07 --> Model Class Initialized
DEBUG - 2011-04-17 20:21:07 --> Model Class Initialized
DEBUG - 2011-04-17 20:21:07 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-17 20:21:07 --> Database Driver Class Initialized
DEBUG - 2011-04-17 20:21:07 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-17 20:21:07 --> Helper loaded: url_helper
DEBUG - 2011-04-17 20:21:07 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-17 20:21:07 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-17 20:21:07 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-17 20:21:07 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-17 20:21:07 --> Final output sent to browser
DEBUG - 2011-04-17 20:21:07 --> Total execution time: 0.0280
DEBUG - 2011-04-17 20:21:09 --> Config Class Initialized
DEBUG - 2011-04-17 20:21:09 --> Hooks Class Initialized
DEBUG - 2011-04-17 20:21:09 --> Utf8 Class Initialized
DEBUG - 2011-04-17 20:21:09 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 20:21:09 --> URI Class Initialized
DEBUG - 2011-04-17 20:21:09 --> Router Class Initialized
DEBUG - 2011-04-17 20:21:09 --> Output Class Initialized
DEBUG - 2011-04-17 20:21:09 --> Input Class Initialized
DEBUG - 2011-04-17 20:21:09 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-17 20:21:09 --> Language Class Initialized
DEBUG - 2011-04-17 20:21:09 --> Loader Class Initialized
DEBUG - 2011-04-17 20:21:09 --> Controller Class Initialized
DEBUG - 2011-04-17 20:21:09 --> Model Class Initialized
DEBUG - 2011-04-17 20:21:09 --> Model Class Initialized
DEBUG - 2011-04-17 20:21:09 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-17 20:21:09 --> Database Driver Class Initialized
DEBUG - 2011-04-17 20:21:10 --> Final output sent to browser
DEBUG - 2011-04-17 20:21:10 --> Total execution time: 1.6552
DEBUG - 2011-04-17 20:21:39 --> Config Class Initialized
DEBUG - 2011-04-17 20:21:39 --> Hooks Class Initialized
DEBUG - 2011-04-17 20:21:39 --> Utf8 Class Initialized
DEBUG - 2011-04-17 20:21:39 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 20:21:39 --> URI Class Initialized
DEBUG - 2011-04-17 20:21:39 --> Router Class Initialized
DEBUG - 2011-04-17 20:21:39 --> Output Class Initialized
DEBUG - 2011-04-17 20:21:39 --> Input Class Initialized
DEBUG - 2011-04-17 20:21:39 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-17 20:21:39 --> Language Class Initialized
DEBUG - 2011-04-17 20:21:39 --> Loader Class Initialized
DEBUG - 2011-04-17 20:21:39 --> Controller Class Initialized
ERROR - 2011-04-17 20:21:39 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-17 20:21:39 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-17 20:21:39 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-17 20:21:39 --> Model Class Initialized
DEBUG - 2011-04-17 20:21:39 --> Model Class Initialized
DEBUG - 2011-04-17 20:21:39 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-17 20:21:39 --> Database Driver Class Initialized
DEBUG - 2011-04-17 20:21:39 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-17 20:21:39 --> Helper loaded: url_helper
DEBUG - 2011-04-17 20:21:39 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-17 20:21:39 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-17 20:21:39 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-17 20:21:39 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-17 20:21:39 --> Final output sent to browser
DEBUG - 2011-04-17 20:21:39 --> Total execution time: 0.0281
DEBUG - 2011-04-17 20:21:40 --> Config Class Initialized
DEBUG - 2011-04-17 20:21:40 --> Hooks Class Initialized
DEBUG - 2011-04-17 20:21:40 --> Utf8 Class Initialized
DEBUG - 2011-04-17 20:21:40 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 20:21:40 --> URI Class Initialized
DEBUG - 2011-04-17 20:21:40 --> Router Class Initialized
DEBUG - 2011-04-17 20:21:40 --> Output Class Initialized
DEBUG - 2011-04-17 20:21:40 --> Input Class Initialized
DEBUG - 2011-04-17 20:21:40 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-17 20:21:40 --> Language Class Initialized
DEBUG - 2011-04-17 20:21:40 --> Loader Class Initialized
DEBUG - 2011-04-17 20:21:40 --> Controller Class Initialized
DEBUG - 2011-04-17 20:21:40 --> Model Class Initialized
DEBUG - 2011-04-17 20:21:40 --> Model Class Initialized
DEBUG - 2011-04-17 20:21:40 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-17 20:21:40 --> Database Driver Class Initialized
DEBUG - 2011-04-17 20:21:41 --> Final output sent to browser
DEBUG - 2011-04-17 20:21:41 --> Total execution time: 0.5968
DEBUG - 2011-04-17 20:35:41 --> Config Class Initialized
DEBUG - 2011-04-17 20:35:41 --> Hooks Class Initialized
DEBUG - 2011-04-17 20:35:41 --> Utf8 Class Initialized
DEBUG - 2011-04-17 20:35:41 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 20:35:41 --> URI Class Initialized
DEBUG - 2011-04-17 20:35:41 --> Router Class Initialized
DEBUG - 2011-04-17 20:35:42 --> Output Class Initialized
DEBUG - 2011-04-17 20:35:42 --> Input Class Initialized
DEBUG - 2011-04-17 20:35:42 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-17 20:35:42 --> Language Class Initialized
DEBUG - 2011-04-17 20:35:42 --> Loader Class Initialized
DEBUG - 2011-04-17 20:35:42 --> Controller Class Initialized
ERROR - 2011-04-17 20:35:42 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-17 20:35:42 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-17 20:35:42 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-17 20:35:42 --> Model Class Initialized
DEBUG - 2011-04-17 20:35:42 --> Model Class Initialized
DEBUG - 2011-04-17 20:35:42 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-17 20:35:42 --> Database Driver Class Initialized
DEBUG - 2011-04-17 20:35:42 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-17 20:35:42 --> Helper loaded: url_helper
DEBUG - 2011-04-17 20:35:42 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-17 20:35:42 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-17 20:35:42 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-17 20:35:42 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-17 20:35:42 --> Final output sent to browser
DEBUG - 2011-04-17 20:35:42 --> Total execution time: 0.2059
DEBUG - 2011-04-17 20:35:47 --> Config Class Initialized
DEBUG - 2011-04-17 20:35:47 --> Hooks Class Initialized
DEBUG - 2011-04-17 20:35:47 --> Utf8 Class Initialized
DEBUG - 2011-04-17 20:35:47 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 20:35:47 --> URI Class Initialized
DEBUG - 2011-04-17 20:35:47 --> Router Class Initialized
DEBUG - 2011-04-17 20:35:47 --> Output Class Initialized
DEBUG - 2011-04-17 20:35:47 --> Input Class Initialized
DEBUG - 2011-04-17 20:35:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-17 20:35:47 --> Language Class Initialized
DEBUG - 2011-04-17 20:35:47 --> Loader Class Initialized
DEBUG - 2011-04-17 20:35:47 --> Controller Class Initialized
DEBUG - 2011-04-17 20:35:47 --> Model Class Initialized
DEBUG - 2011-04-17 20:35:47 --> Model Class Initialized
DEBUG - 2011-04-17 20:35:47 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-17 20:35:47 --> Database Driver Class Initialized
DEBUG - 2011-04-17 20:35:51 --> Final output sent to browser
DEBUG - 2011-04-17 20:35:51 --> Total execution time: 3.6805
DEBUG - 2011-04-17 20:36:00 --> Config Class Initialized
DEBUG - 2011-04-17 20:36:00 --> Hooks Class Initialized
DEBUG - 2011-04-17 20:36:00 --> Utf8 Class Initialized
DEBUG - 2011-04-17 20:36:00 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 20:36:00 --> URI Class Initialized
DEBUG - 2011-04-17 20:36:00 --> Router Class Initialized
ERROR - 2011-04-17 20:36:00 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-17 20:36:01 --> Config Class Initialized
DEBUG - 2011-04-17 20:36:01 --> Hooks Class Initialized
DEBUG - 2011-04-17 20:36:01 --> Utf8 Class Initialized
DEBUG - 2011-04-17 20:36:01 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 20:36:01 --> URI Class Initialized
DEBUG - 2011-04-17 20:36:01 --> Router Class Initialized
ERROR - 2011-04-17 20:36:01 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-17 20:36:02 --> Config Class Initialized
DEBUG - 2011-04-17 20:36:02 --> Hooks Class Initialized
DEBUG - 2011-04-17 20:36:02 --> Utf8 Class Initialized
DEBUG - 2011-04-17 20:36:02 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 20:36:02 --> URI Class Initialized
DEBUG - 2011-04-17 20:36:02 --> Router Class Initialized
ERROR - 2011-04-17 20:36:02 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-17 20:36:04 --> Config Class Initialized
DEBUG - 2011-04-17 20:36:04 --> Hooks Class Initialized
DEBUG - 2011-04-17 20:36:04 --> Utf8 Class Initialized
DEBUG - 2011-04-17 20:36:04 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 20:36:04 --> URI Class Initialized
DEBUG - 2011-04-17 20:36:04 --> Router Class Initialized
DEBUG - 2011-04-17 20:36:04 --> Output Class Initialized
DEBUG - 2011-04-17 20:36:04 --> Input Class Initialized
DEBUG - 2011-04-17 20:36:04 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-17 20:36:04 --> Language Class Initialized
DEBUG - 2011-04-17 20:36:04 --> Loader Class Initialized
DEBUG - 2011-04-17 20:36:04 --> Controller Class Initialized
ERROR - 2011-04-17 20:36:04 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-17 20:36:04 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-17 20:36:04 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-17 20:36:04 --> Model Class Initialized
DEBUG - 2011-04-17 20:36:04 --> Model Class Initialized
DEBUG - 2011-04-17 20:36:04 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-17 20:36:04 --> Database Driver Class Initialized
DEBUG - 2011-04-17 20:36:04 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-17 20:36:04 --> Helper loaded: url_helper
DEBUG - 2011-04-17 20:36:04 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-17 20:36:04 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-17 20:36:04 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-17 20:36:04 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-17 20:36:04 --> Final output sent to browser
DEBUG - 2011-04-17 20:36:04 --> Total execution time: 0.0660
DEBUG - 2011-04-17 20:57:55 --> Config Class Initialized
DEBUG - 2011-04-17 20:57:55 --> Hooks Class Initialized
DEBUG - 2011-04-17 20:57:55 --> Utf8 Class Initialized
DEBUG - 2011-04-17 20:57:55 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 20:57:55 --> URI Class Initialized
DEBUG - 2011-04-17 20:57:55 --> Router Class Initialized
DEBUG - 2011-04-17 20:57:55 --> Output Class Initialized
DEBUG - 2011-04-17 20:57:55 --> Input Class Initialized
DEBUG - 2011-04-17 20:57:55 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-17 20:57:55 --> Language Class Initialized
DEBUG - 2011-04-17 20:57:55 --> Loader Class Initialized
DEBUG - 2011-04-17 20:57:55 --> Controller Class Initialized
ERROR - 2011-04-17 20:57:55 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-17 20:57:55 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-17 20:57:55 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-17 20:57:55 --> Model Class Initialized
DEBUG - 2011-04-17 20:57:55 --> Model Class Initialized
DEBUG - 2011-04-17 20:57:55 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-17 20:57:55 --> Database Driver Class Initialized
DEBUG - 2011-04-17 20:57:55 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-17 20:57:55 --> Helper loaded: url_helper
DEBUG - 2011-04-17 20:57:55 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-17 20:57:55 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-17 20:57:55 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-17 20:57:55 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-17 20:57:55 --> Final output sent to browser
DEBUG - 2011-04-17 20:57:55 --> Total execution time: 0.2820
DEBUG - 2011-04-17 20:57:58 --> Config Class Initialized
DEBUG - 2011-04-17 20:57:58 --> Hooks Class Initialized
DEBUG - 2011-04-17 20:57:58 --> Utf8 Class Initialized
DEBUG - 2011-04-17 20:57:58 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 20:57:58 --> URI Class Initialized
DEBUG - 2011-04-17 20:57:58 --> Router Class Initialized
DEBUG - 2011-04-17 20:57:58 --> Output Class Initialized
DEBUG - 2011-04-17 20:57:58 --> Input Class Initialized
DEBUG - 2011-04-17 20:57:58 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-17 20:57:58 --> Language Class Initialized
DEBUG - 2011-04-17 20:57:58 --> Loader Class Initialized
DEBUG - 2011-04-17 20:57:58 --> Controller Class Initialized
DEBUG - 2011-04-17 20:57:58 --> Model Class Initialized
DEBUG - 2011-04-17 20:57:58 --> Model Class Initialized
DEBUG - 2011-04-17 20:57:58 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-17 20:57:58 --> Database Driver Class Initialized
DEBUG - 2011-04-17 20:57:59 --> Final output sent to browser
DEBUG - 2011-04-17 20:57:59 --> Total execution time: 0.8283
DEBUG - 2011-04-17 20:58:01 --> Config Class Initialized
DEBUG - 2011-04-17 20:58:01 --> Hooks Class Initialized
DEBUG - 2011-04-17 20:58:01 --> Utf8 Class Initialized
DEBUG - 2011-04-17 20:58:01 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 20:58:01 --> URI Class Initialized
DEBUG - 2011-04-17 20:58:01 --> Router Class Initialized
ERROR - 2011-04-17 20:58:01 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-17 21:36:28 --> Config Class Initialized
DEBUG - 2011-04-17 21:36:28 --> Hooks Class Initialized
DEBUG - 2011-04-17 21:36:28 --> Utf8 Class Initialized
DEBUG - 2011-04-17 21:36:28 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 21:36:28 --> URI Class Initialized
DEBUG - 2011-04-17 21:36:28 --> Router Class Initialized
ERROR - 2011-04-17 21:36:28 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-04-17 21:36:29 --> Config Class Initialized
DEBUG - 2011-04-17 21:36:29 --> Hooks Class Initialized
DEBUG - 2011-04-17 21:36:29 --> Utf8 Class Initialized
DEBUG - 2011-04-17 21:36:29 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 21:36:29 --> URI Class Initialized
DEBUG - 2011-04-17 21:36:29 --> Router Class Initialized
DEBUG - 2011-04-17 21:36:29 --> Output Class Initialized
DEBUG - 2011-04-17 21:36:29 --> Input Class Initialized
DEBUG - 2011-04-17 21:36:29 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-17 21:36:29 --> Language Class Initialized
DEBUG - 2011-04-17 21:36:29 --> Loader Class Initialized
DEBUG - 2011-04-17 21:36:29 --> Controller Class Initialized
DEBUG - 2011-04-17 21:36:29 --> Model Class Initialized
DEBUG - 2011-04-17 21:36:29 --> Model Class Initialized
DEBUG - 2011-04-17 21:36:29 --> Model Class Initialized
DEBUG - 2011-04-17 21:36:29 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-17 21:36:29 --> Database Driver Class Initialized
DEBUG - 2011-04-17 21:36:29 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-17 21:36:29 --> Helper loaded: url_helper
DEBUG - 2011-04-17 21:36:29 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-17 21:36:29 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-17 21:36:29 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-17 21:36:29 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-17 21:36:29 --> Final output sent to browser
DEBUG - 2011-04-17 21:36:29 --> Total execution time: 0.4712
DEBUG - 2011-04-17 21:58:01 --> Config Class Initialized
DEBUG - 2011-04-17 21:58:01 --> Hooks Class Initialized
DEBUG - 2011-04-17 21:58:01 --> Utf8 Class Initialized
DEBUG - 2011-04-17 21:58:01 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 21:58:01 --> URI Class Initialized
DEBUG - 2011-04-17 21:58:01 --> Router Class Initialized
DEBUG - 2011-04-17 21:58:01 --> Output Class Initialized
DEBUG - 2011-04-17 21:58:01 --> Input Class Initialized
DEBUG - 2011-04-17 21:58:01 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-17 21:58:01 --> Language Class Initialized
DEBUG - 2011-04-17 21:58:01 --> Loader Class Initialized
DEBUG - 2011-04-17 21:58:01 --> Controller Class Initialized
DEBUG - 2011-04-17 21:58:01 --> Model Class Initialized
DEBUG - 2011-04-17 21:58:01 --> Model Class Initialized
DEBUG - 2011-04-17 21:58:01 --> Model Class Initialized
DEBUG - 2011-04-17 21:58:01 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-17 21:58:01 --> Database Driver Class Initialized
DEBUG - 2011-04-17 21:58:01 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-17 21:58:01 --> Helper loaded: url_helper
DEBUG - 2011-04-17 21:58:01 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-17 21:58:01 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-17 21:58:01 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-17 21:58:01 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-17 21:58:01 --> Final output sent to browser
DEBUG - 2011-04-17 21:58:01 --> Total execution time: 0.2826
DEBUG - 2011-04-17 21:58:05 --> Config Class Initialized
DEBUG - 2011-04-17 21:58:05 --> Hooks Class Initialized
DEBUG - 2011-04-17 21:58:05 --> Utf8 Class Initialized
DEBUG - 2011-04-17 21:58:05 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 21:58:05 --> URI Class Initialized
DEBUG - 2011-04-17 21:58:05 --> Router Class Initialized
ERROR - 2011-04-17 21:58:05 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-17 22:33:48 --> Config Class Initialized
DEBUG - 2011-04-17 22:33:48 --> Hooks Class Initialized
DEBUG - 2011-04-17 22:33:48 --> Utf8 Class Initialized
DEBUG - 2011-04-17 22:33:48 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 22:33:48 --> URI Class Initialized
DEBUG - 2011-04-17 22:33:48 --> Router Class Initialized
DEBUG - 2011-04-17 22:33:48 --> Output Class Initialized
DEBUG - 2011-04-17 22:33:48 --> Input Class Initialized
DEBUG - 2011-04-17 22:33:48 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-17 22:33:48 --> Language Class Initialized
DEBUG - 2011-04-17 22:33:48 --> Loader Class Initialized
DEBUG - 2011-04-17 22:33:48 --> Controller Class Initialized
DEBUG - 2011-04-17 22:33:48 --> Model Class Initialized
DEBUG - 2011-04-17 22:33:48 --> Model Class Initialized
DEBUG - 2011-04-17 22:33:48 --> Model Class Initialized
DEBUG - 2011-04-17 22:33:48 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-17 22:33:48 --> Database Driver Class Initialized
DEBUG - 2011-04-17 22:33:48 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-17 22:33:48 --> Helper loaded: url_helper
DEBUG - 2011-04-17 22:33:48 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-17 22:33:48 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-17 22:33:48 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-17 22:33:48 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-17 22:33:48 --> Final output sent to browser
DEBUG - 2011-04-17 22:33:48 --> Total execution time: 0.6731
DEBUG - 2011-04-17 22:33:55 --> Config Class Initialized
DEBUG - 2011-04-17 22:33:55 --> Hooks Class Initialized
DEBUG - 2011-04-17 22:33:55 --> Utf8 Class Initialized
DEBUG - 2011-04-17 22:33:55 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 22:33:55 --> URI Class Initialized
DEBUG - 2011-04-17 22:33:55 --> Router Class Initialized
ERROR - 2011-04-17 22:33:55 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-17 23:12:26 --> Config Class Initialized
DEBUG - 2011-04-17 23:12:26 --> Hooks Class Initialized
DEBUG - 2011-04-17 23:12:26 --> Utf8 Class Initialized
DEBUG - 2011-04-17 23:12:26 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 23:12:26 --> URI Class Initialized
DEBUG - 2011-04-17 23:12:26 --> Router Class Initialized
DEBUG - 2011-04-17 23:12:26 --> Output Class Initialized
DEBUG - 2011-04-17 23:12:26 --> Input Class Initialized
DEBUG - 2011-04-17 23:12:26 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-17 23:12:26 --> Language Class Initialized
DEBUG - 2011-04-17 23:12:26 --> Loader Class Initialized
DEBUG - 2011-04-17 23:12:26 --> Controller Class Initialized
DEBUG - 2011-04-17 23:12:26 --> Model Class Initialized
DEBUG - 2011-04-17 23:12:26 --> Model Class Initialized
DEBUG - 2011-04-17 23:12:26 --> Model Class Initialized
DEBUG - 2011-04-17 23:12:26 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-17 23:12:26 --> Database Driver Class Initialized
DEBUG - 2011-04-17 23:12:26 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-17 23:12:26 --> Helper loaded: url_helper
DEBUG - 2011-04-17 23:12:26 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-17 23:12:26 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-17 23:12:26 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-17 23:12:26 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-17 23:12:26 --> Final output sent to browser
DEBUG - 2011-04-17 23:12:26 --> Total execution time: 0.5246
DEBUG - 2011-04-17 23:12:35 --> Config Class Initialized
DEBUG - 2011-04-17 23:12:35 --> Hooks Class Initialized
DEBUG - 2011-04-17 23:12:35 --> Utf8 Class Initialized
DEBUG - 2011-04-17 23:12:35 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 23:12:35 --> URI Class Initialized
DEBUG - 2011-04-17 23:12:35 --> Router Class Initialized
DEBUG - 2011-04-17 23:12:35 --> Output Class Initialized
DEBUG - 2011-04-17 23:12:35 --> Input Class Initialized
DEBUG - 2011-04-17 23:12:35 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-17 23:12:35 --> Language Class Initialized
DEBUG - 2011-04-17 23:12:35 --> Loader Class Initialized
DEBUG - 2011-04-17 23:12:35 --> Controller Class Initialized
ERROR - 2011-04-17 23:12:35 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-17 23:12:35 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-17 23:12:35 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-17 23:12:35 --> Model Class Initialized
DEBUG - 2011-04-17 23:12:35 --> Model Class Initialized
DEBUG - 2011-04-17 23:12:35 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-17 23:12:35 --> Database Driver Class Initialized
DEBUG - 2011-04-17 23:12:35 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-17 23:12:35 --> Helper loaded: url_helper
DEBUG - 2011-04-17 23:12:35 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-17 23:12:35 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-17 23:12:35 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-17 23:12:35 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-17 23:12:35 --> Final output sent to browser
DEBUG - 2011-04-17 23:12:35 --> Total execution time: 0.1151
DEBUG - 2011-04-17 23:34:40 --> Config Class Initialized
DEBUG - 2011-04-17 23:34:40 --> Hooks Class Initialized
DEBUG - 2011-04-17 23:34:40 --> Utf8 Class Initialized
DEBUG - 2011-04-17 23:34:40 --> UTF-8 Support Enabled
DEBUG - 2011-04-17 23:34:40 --> URI Class Initialized
DEBUG - 2011-04-17 23:34:40 --> Router Class Initialized
ERROR - 2011-04-17 23:34:40 --> 404 Page Not Found --> robots.txt

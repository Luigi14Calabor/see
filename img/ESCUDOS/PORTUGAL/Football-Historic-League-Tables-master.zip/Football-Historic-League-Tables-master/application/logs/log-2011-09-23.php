<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2011-09-23 00:01:00 --> Config Class Initialized
DEBUG - 2011-09-23 00:01:00 --> Hooks Class Initialized
DEBUG - 2011-09-23 00:01:00 --> Utf8 Class Initialized
DEBUG - 2011-09-23 00:01:00 --> UTF-8 Support Enabled
DEBUG - 2011-09-23 00:01:00 --> URI Class Initialized
DEBUG - 2011-09-23 00:01:00 --> Router Class Initialized
DEBUG - 2011-09-23 00:01:00 --> Output Class Initialized
DEBUG - 2011-09-23 00:01:00 --> Input Class Initialized
DEBUG - 2011-09-23 00:01:00 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-23 00:01:00 --> Language Class Initialized
DEBUG - 2011-09-23 00:01:00 --> Loader Class Initialized
DEBUG - 2011-09-23 00:01:00 --> Controller Class Initialized
ERROR - 2011-09-23 00:01:00 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-23 00:01:00 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-23 00:01:00 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-23 00:01:00 --> Model Class Initialized
DEBUG - 2011-09-23 00:01:00 --> Model Class Initialized
DEBUG - 2011-09-23 00:01:00 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-23 00:01:00 --> Database Driver Class Initialized
DEBUG - 2011-09-23 00:01:00 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-23 00:01:00 --> Helper loaded: url_helper
DEBUG - 2011-09-23 00:01:00 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-23 00:01:00 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-23 00:01:00 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-23 00:01:00 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-23 00:01:00 --> Final output sent to browser
DEBUG - 2011-09-23 00:01:00 --> Total execution time: 0.6916
DEBUG - 2011-09-23 00:01:09 --> Config Class Initialized
DEBUG - 2011-09-23 00:01:09 --> Hooks Class Initialized
DEBUG - 2011-09-23 00:01:09 --> Utf8 Class Initialized
DEBUG - 2011-09-23 00:01:09 --> UTF-8 Support Enabled
DEBUG - 2011-09-23 00:01:09 --> URI Class Initialized
DEBUG - 2011-09-23 00:01:09 --> Router Class Initialized
DEBUG - 2011-09-23 00:01:09 --> Output Class Initialized
DEBUG - 2011-09-23 00:01:09 --> Input Class Initialized
DEBUG - 2011-09-23 00:01:09 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-23 00:01:09 --> Language Class Initialized
DEBUG - 2011-09-23 00:01:09 --> Loader Class Initialized
DEBUG - 2011-09-23 00:01:09 --> Controller Class Initialized
DEBUG - 2011-09-23 00:01:09 --> Model Class Initialized
DEBUG - 2011-09-23 00:01:09 --> Model Class Initialized
DEBUG - 2011-09-23 00:01:09 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-23 00:01:09 --> Database Driver Class Initialized
DEBUG - 2011-09-23 00:01:10 --> Final output sent to browser
DEBUG - 2011-09-23 00:01:10 --> Total execution time: 1.1015
DEBUG - 2011-09-23 00:01:18 --> Config Class Initialized
DEBUG - 2011-09-23 00:01:18 --> Hooks Class Initialized
DEBUG - 2011-09-23 00:01:18 --> Utf8 Class Initialized
DEBUG - 2011-09-23 00:01:18 --> UTF-8 Support Enabled
DEBUG - 2011-09-23 00:01:18 --> URI Class Initialized
DEBUG - 2011-09-23 00:01:18 --> Router Class Initialized
DEBUG - 2011-09-23 00:01:18 --> Output Class Initialized
DEBUG - 2011-09-23 00:01:18 --> Input Class Initialized
DEBUG - 2011-09-23 00:01:18 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-23 00:01:18 --> Language Class Initialized
DEBUG - 2011-09-23 00:01:18 --> Loader Class Initialized
DEBUG - 2011-09-23 00:01:18 --> Controller Class Initialized
ERROR - 2011-09-23 00:01:18 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-23 00:01:18 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-23 00:01:18 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-23 00:01:18 --> Model Class Initialized
DEBUG - 2011-09-23 00:01:18 --> Model Class Initialized
DEBUG - 2011-09-23 00:01:18 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-23 00:01:18 --> Database Driver Class Initialized
DEBUG - 2011-09-23 00:01:18 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-23 00:01:18 --> Helper loaded: url_helper
DEBUG - 2011-09-23 00:01:18 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-23 00:01:18 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-23 00:01:18 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-23 00:01:18 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-23 00:01:18 --> Final output sent to browser
DEBUG - 2011-09-23 00:01:18 --> Total execution time: 0.0784
DEBUG - 2011-09-23 00:01:18 --> Config Class Initialized
DEBUG - 2011-09-23 00:01:18 --> Hooks Class Initialized
DEBUG - 2011-09-23 00:01:18 --> Utf8 Class Initialized
DEBUG - 2011-09-23 00:01:18 --> UTF-8 Support Enabled
DEBUG - 2011-09-23 00:01:18 --> URI Class Initialized
DEBUG - 2011-09-23 00:01:18 --> Router Class Initialized
ERROR - 2011-09-23 00:01:18 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-23 00:01:19 --> Config Class Initialized
DEBUG - 2011-09-23 00:01:19 --> Hooks Class Initialized
DEBUG - 2011-09-23 00:01:19 --> Utf8 Class Initialized
DEBUG - 2011-09-23 00:01:19 --> UTF-8 Support Enabled
DEBUG - 2011-09-23 00:01:19 --> URI Class Initialized
DEBUG - 2011-09-23 00:01:19 --> Router Class Initialized
DEBUG - 2011-09-23 00:01:19 --> Output Class Initialized
DEBUG - 2011-09-23 00:01:19 --> Input Class Initialized
DEBUG - 2011-09-23 00:01:19 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-23 00:01:19 --> Language Class Initialized
DEBUG - 2011-09-23 00:01:19 --> Loader Class Initialized
DEBUG - 2011-09-23 00:01:19 --> Controller Class Initialized
DEBUG - 2011-09-23 00:01:19 --> Model Class Initialized
DEBUG - 2011-09-23 00:01:19 --> Model Class Initialized
DEBUG - 2011-09-23 00:01:19 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-23 00:01:19 --> Database Driver Class Initialized
DEBUG - 2011-09-23 00:01:20 --> Final output sent to browser
DEBUG - 2011-09-23 00:01:20 --> Total execution time: 0.8721
DEBUG - 2011-09-23 00:01:31 --> Config Class Initialized
DEBUG - 2011-09-23 00:01:31 --> Hooks Class Initialized
DEBUG - 2011-09-23 00:01:31 --> Utf8 Class Initialized
DEBUG - 2011-09-23 00:01:31 --> UTF-8 Support Enabled
DEBUG - 2011-09-23 00:01:31 --> URI Class Initialized
DEBUG - 2011-09-23 00:01:31 --> Router Class Initialized
DEBUG - 2011-09-23 00:01:31 --> Output Class Initialized
DEBUG - 2011-09-23 00:01:31 --> Input Class Initialized
DEBUG - 2011-09-23 00:01:31 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-23 00:01:31 --> Language Class Initialized
DEBUG - 2011-09-23 00:01:31 --> Loader Class Initialized
DEBUG - 2011-09-23 00:01:31 --> Controller Class Initialized
ERROR - 2011-09-23 00:01:31 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-23 00:01:31 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-23 00:01:31 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-23 00:01:31 --> Model Class Initialized
DEBUG - 2011-09-23 00:01:31 --> Model Class Initialized
DEBUG - 2011-09-23 00:01:31 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-23 00:01:31 --> Database Driver Class Initialized
DEBUG - 2011-09-23 00:01:31 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-23 00:01:31 --> Helper loaded: url_helper
DEBUG - 2011-09-23 00:01:31 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-23 00:01:31 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-23 00:01:31 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-23 00:01:31 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-23 00:01:31 --> Final output sent to browser
DEBUG - 2011-09-23 00:01:31 --> Total execution time: 0.0405
DEBUG - 2011-09-23 00:01:34 --> Config Class Initialized
DEBUG - 2011-09-23 00:01:34 --> Hooks Class Initialized
DEBUG - 2011-09-23 00:01:34 --> Utf8 Class Initialized
DEBUG - 2011-09-23 00:01:34 --> UTF-8 Support Enabled
DEBUG - 2011-09-23 00:01:34 --> URI Class Initialized
DEBUG - 2011-09-23 00:01:34 --> Router Class Initialized
ERROR - 2011-09-23 00:01:34 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-23 00:01:34 --> Config Class Initialized
DEBUG - 2011-09-23 00:01:34 --> Hooks Class Initialized
DEBUG - 2011-09-23 00:01:34 --> Utf8 Class Initialized
DEBUG - 2011-09-23 00:01:34 --> UTF-8 Support Enabled
DEBUG - 2011-09-23 00:01:34 --> URI Class Initialized
DEBUG - 2011-09-23 00:01:34 --> Router Class Initialized
DEBUG - 2011-09-23 00:01:34 --> Output Class Initialized
DEBUG - 2011-09-23 00:01:34 --> Input Class Initialized
DEBUG - 2011-09-23 00:01:34 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-23 00:01:34 --> Language Class Initialized
DEBUG - 2011-09-23 00:01:34 --> Loader Class Initialized
DEBUG - 2011-09-23 00:01:34 --> Controller Class Initialized
ERROR - 2011-09-23 00:01:34 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-23 00:01:34 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-23 00:01:34 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-23 00:01:34 --> Model Class Initialized
DEBUG - 2011-09-23 00:01:34 --> Model Class Initialized
DEBUG - 2011-09-23 00:01:34 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-23 00:01:34 --> Database Driver Class Initialized
DEBUG - 2011-09-23 00:01:34 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-23 00:01:34 --> Helper loaded: url_helper
DEBUG - 2011-09-23 00:01:34 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-23 00:01:34 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-23 00:01:34 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-23 00:01:34 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-23 00:01:34 --> Final output sent to browser
DEBUG - 2011-09-23 00:01:34 --> Total execution time: 0.1429
DEBUG - 2011-09-23 00:01:35 --> Config Class Initialized
DEBUG - 2011-09-23 00:01:35 --> Hooks Class Initialized
DEBUG - 2011-09-23 00:01:35 --> Utf8 Class Initialized
DEBUG - 2011-09-23 00:01:35 --> UTF-8 Support Enabled
DEBUG - 2011-09-23 00:01:35 --> URI Class Initialized
DEBUG - 2011-09-23 00:01:35 --> Router Class Initialized
DEBUG - 2011-09-23 00:01:35 --> Output Class Initialized
DEBUG - 2011-09-23 00:01:35 --> Input Class Initialized
DEBUG - 2011-09-23 00:01:35 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-23 00:01:35 --> Language Class Initialized
DEBUG - 2011-09-23 00:01:35 --> Loader Class Initialized
DEBUG - 2011-09-23 00:01:35 --> Controller Class Initialized
DEBUG - 2011-09-23 00:01:35 --> Model Class Initialized
DEBUG - 2011-09-23 00:01:35 --> Model Class Initialized
DEBUG - 2011-09-23 00:01:35 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-23 00:01:35 --> Database Driver Class Initialized
DEBUG - 2011-09-23 00:01:36 --> Final output sent to browser
DEBUG - 2011-09-23 00:01:36 --> Total execution time: 0.7143
DEBUG - 2011-09-23 00:01:56 --> Config Class Initialized
DEBUG - 2011-09-23 00:01:56 --> Hooks Class Initialized
DEBUG - 2011-09-23 00:01:56 --> Utf8 Class Initialized
DEBUG - 2011-09-23 00:01:56 --> UTF-8 Support Enabled
DEBUG - 2011-09-23 00:01:56 --> URI Class Initialized
DEBUG - 2011-09-23 00:01:56 --> Router Class Initialized
ERROR - 2011-09-23 00:01:56 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-09-23 00:01:56 --> Config Class Initialized
DEBUG - 2011-09-23 00:01:56 --> Hooks Class Initialized
DEBUG - 2011-09-23 00:01:56 --> Utf8 Class Initialized
DEBUG - 2011-09-23 00:01:56 --> UTF-8 Support Enabled
DEBUG - 2011-09-23 00:01:56 --> URI Class Initialized
DEBUG - 2011-09-23 00:01:56 --> Router Class Initialized
DEBUG - 2011-09-23 00:01:56 --> Output Class Initialized
DEBUG - 2011-09-23 00:01:56 --> Input Class Initialized
DEBUG - 2011-09-23 00:01:56 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-23 00:01:56 --> Language Class Initialized
DEBUG - 2011-09-23 00:01:56 --> Loader Class Initialized
DEBUG - 2011-09-23 00:01:56 --> Controller Class Initialized
ERROR - 2011-09-23 00:01:56 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-23 00:01:56 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-23 00:01:56 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-23 00:01:56 --> Model Class Initialized
DEBUG - 2011-09-23 00:01:56 --> Model Class Initialized
DEBUG - 2011-09-23 00:01:56 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-23 00:01:56 --> Database Driver Class Initialized
DEBUG - 2011-09-23 00:01:56 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-23 00:01:56 --> Helper loaded: url_helper
DEBUG - 2011-09-23 00:01:56 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-23 00:01:56 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-23 00:01:56 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-23 00:01:56 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-23 00:01:56 --> Final output sent to browser
DEBUG - 2011-09-23 00:01:56 --> Total execution time: 0.0421
DEBUG - 2011-09-23 00:02:34 --> Config Class Initialized
DEBUG - 2011-09-23 00:02:34 --> Hooks Class Initialized
DEBUG - 2011-09-23 00:02:34 --> Utf8 Class Initialized
DEBUG - 2011-09-23 00:02:34 --> UTF-8 Support Enabled
DEBUG - 2011-09-23 00:02:34 --> URI Class Initialized
DEBUG - 2011-09-23 00:02:34 --> Router Class Initialized
ERROR - 2011-09-23 00:02:34 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-23 00:02:37 --> Config Class Initialized
DEBUG - 2011-09-23 00:02:37 --> Hooks Class Initialized
DEBUG - 2011-09-23 00:02:37 --> Utf8 Class Initialized
DEBUG - 2011-09-23 00:02:37 --> UTF-8 Support Enabled
DEBUG - 2011-09-23 00:02:37 --> URI Class Initialized
DEBUG - 2011-09-23 00:02:37 --> Router Class Initialized
ERROR - 2011-09-23 00:02:37 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-23 00:13:14 --> Config Class Initialized
DEBUG - 2011-09-23 00:13:14 --> Hooks Class Initialized
DEBUG - 2011-09-23 00:13:14 --> Utf8 Class Initialized
DEBUG - 2011-09-23 00:13:14 --> UTF-8 Support Enabled
DEBUG - 2011-09-23 00:13:14 --> URI Class Initialized
DEBUG - 2011-09-23 00:13:14 --> Router Class Initialized
DEBUG - 2011-09-23 00:13:14 --> No URI present. Default controller set.
DEBUG - 2011-09-23 00:13:14 --> Output Class Initialized
DEBUG - 2011-09-23 00:13:14 --> Input Class Initialized
DEBUG - 2011-09-23 00:13:14 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-23 00:13:14 --> Language Class Initialized
DEBUG - 2011-09-23 00:13:14 --> Loader Class Initialized
DEBUG - 2011-09-23 00:13:14 --> Controller Class Initialized
DEBUG - 2011-09-23 00:13:14 --> File loaded: application/views/splash/main.php
DEBUG - 2011-09-23 00:13:14 --> Helper loaded: url_helper
DEBUG - 2011-09-23 00:13:14 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-23 00:13:14 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-23 00:13:14 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-23 00:13:14 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-23 00:13:14 --> Final output sent to browser
DEBUG - 2011-09-23 00:13:14 --> Total execution time: 0.1064
DEBUG - 2011-09-23 01:47:24 --> Config Class Initialized
DEBUG - 2011-09-23 01:47:24 --> Hooks Class Initialized
DEBUG - 2011-09-23 01:47:24 --> Utf8 Class Initialized
DEBUG - 2011-09-23 01:47:24 --> UTF-8 Support Enabled
DEBUG - 2011-09-23 01:47:24 --> URI Class Initialized
DEBUG - 2011-09-23 01:47:24 --> Router Class Initialized
DEBUG - 2011-09-23 01:47:24 --> Output Class Initialized
DEBUG - 2011-09-23 01:47:24 --> Input Class Initialized
DEBUG - 2011-09-23 01:47:24 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-23 01:47:24 --> Language Class Initialized
DEBUG - 2011-09-23 01:47:24 --> Loader Class Initialized
DEBUG - 2011-09-23 01:47:24 --> Controller Class Initialized
DEBUG - 2011-09-23 01:47:24 --> Model Class Initialized
DEBUG - 2011-09-23 01:47:24 --> Model Class Initialized
DEBUG - 2011-09-23 01:47:24 --> Model Class Initialized
DEBUG - 2011-09-23 01:47:24 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-23 01:47:24 --> Database Driver Class Initialized
DEBUG - 2011-09-23 01:47:26 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-23 01:47:26 --> Helper loaded: url_helper
DEBUG - 2011-09-23 01:47:26 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-23 01:47:26 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-23 01:47:26 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-23 01:47:26 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-23 01:47:26 --> Final output sent to browser
DEBUG - 2011-09-23 01:47:26 --> Total execution time: 2.0061
DEBUG - 2011-09-23 01:47:27 --> Config Class Initialized
DEBUG - 2011-09-23 01:47:27 --> Hooks Class Initialized
DEBUG - 2011-09-23 01:47:27 --> Utf8 Class Initialized
DEBUG - 2011-09-23 01:47:27 --> UTF-8 Support Enabled
DEBUG - 2011-09-23 01:47:27 --> URI Class Initialized
DEBUG - 2011-09-23 01:47:27 --> Router Class Initialized
DEBUG - 2011-09-23 01:47:27 --> Output Class Initialized
DEBUG - 2011-09-23 01:47:27 --> Input Class Initialized
DEBUG - 2011-09-23 01:47:27 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-23 01:47:27 --> Language Class Initialized
DEBUG - 2011-09-23 01:47:27 --> Loader Class Initialized
DEBUG - 2011-09-23 01:47:27 --> Controller Class Initialized
ERROR - 2011-09-23 01:47:27 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-23 01:47:27 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-23 01:47:27 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-23 01:47:27 --> Model Class Initialized
DEBUG - 2011-09-23 01:47:27 --> Model Class Initialized
DEBUG - 2011-09-23 01:47:27 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-23 01:47:27 --> Database Driver Class Initialized
DEBUG - 2011-09-23 01:47:27 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-23 01:47:27 --> Helper loaded: url_helper
DEBUG - 2011-09-23 01:47:27 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-23 01:47:27 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-23 01:47:27 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-23 01:47:27 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-23 01:47:27 --> Final output sent to browser
DEBUG - 2011-09-23 01:47:27 --> Total execution time: 0.0776
DEBUG - 2011-09-23 02:13:54 --> Config Class Initialized
DEBUG - 2011-09-23 02:13:54 --> Hooks Class Initialized
DEBUG - 2011-09-23 02:13:54 --> Utf8 Class Initialized
DEBUG - 2011-09-23 02:13:54 --> UTF-8 Support Enabled
DEBUG - 2011-09-23 02:13:54 --> URI Class Initialized
DEBUG - 2011-09-23 02:13:54 --> Router Class Initialized
DEBUG - 2011-09-23 02:13:54 --> Output Class Initialized
DEBUG - 2011-09-23 02:13:54 --> Input Class Initialized
DEBUG - 2011-09-23 02:13:54 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-23 02:13:54 --> Language Class Initialized
DEBUG - 2011-09-23 02:13:54 --> Loader Class Initialized
DEBUG - 2011-09-23 02:13:54 --> Controller Class Initialized
DEBUG - 2011-09-23 02:13:54 --> Model Class Initialized
DEBUG - 2011-09-23 02:13:54 --> Model Class Initialized
DEBUG - 2011-09-23 02:13:54 --> Model Class Initialized
DEBUG - 2011-09-23 02:13:54 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-23 02:13:54 --> Database Driver Class Initialized
DEBUG - 2011-09-23 02:13:56 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-23 02:13:56 --> Helper loaded: url_helper
DEBUG - 2011-09-23 02:13:56 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-23 02:13:56 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-23 02:13:56 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-23 02:13:56 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-23 02:13:56 --> Final output sent to browser
DEBUG - 2011-09-23 02:13:56 --> Total execution time: 1.9132
DEBUG - 2011-09-23 02:13:59 --> Config Class Initialized
DEBUG - 2011-09-23 02:13:59 --> Hooks Class Initialized
DEBUG - 2011-09-23 02:13:59 --> Utf8 Class Initialized
DEBUG - 2011-09-23 02:13:59 --> UTF-8 Support Enabled
DEBUG - 2011-09-23 02:14:00 --> URI Class Initialized
DEBUG - 2011-09-23 02:14:00 --> Router Class Initialized
ERROR - 2011-09-23 02:14:00 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-23 02:14:00 --> Config Class Initialized
DEBUG - 2011-09-23 02:14:00 --> Hooks Class Initialized
DEBUG - 2011-09-23 02:14:00 --> Utf8 Class Initialized
DEBUG - 2011-09-23 02:14:00 --> UTF-8 Support Enabled
DEBUG - 2011-09-23 02:14:00 --> URI Class Initialized
DEBUG - 2011-09-23 02:14:00 --> Router Class Initialized
ERROR - 2011-09-23 02:14:00 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-23 02:14:15 --> Config Class Initialized
DEBUG - 2011-09-23 02:14:15 --> Hooks Class Initialized
DEBUG - 2011-09-23 02:14:15 --> Utf8 Class Initialized
DEBUG - 2011-09-23 02:14:15 --> UTF-8 Support Enabled
DEBUG - 2011-09-23 02:14:15 --> URI Class Initialized
DEBUG - 2011-09-23 02:14:15 --> Router Class Initialized
DEBUG - 2011-09-23 02:14:15 --> Output Class Initialized
DEBUG - 2011-09-23 02:14:15 --> Input Class Initialized
DEBUG - 2011-09-23 02:14:15 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-23 02:14:15 --> Language Class Initialized
DEBUG - 2011-09-23 02:14:15 --> Loader Class Initialized
DEBUG - 2011-09-23 02:14:15 --> Controller Class Initialized
ERROR - 2011-09-23 02:14:15 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-23 02:14:15 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-23 02:14:15 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-23 02:14:15 --> Model Class Initialized
DEBUG - 2011-09-23 02:14:15 --> Model Class Initialized
DEBUG - 2011-09-23 02:14:15 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-23 02:14:15 --> Database Driver Class Initialized
DEBUG - 2011-09-23 02:14:15 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-23 02:14:15 --> Helper loaded: url_helper
DEBUG - 2011-09-23 02:14:15 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-23 02:14:15 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-23 02:14:15 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-23 02:14:15 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-23 02:14:15 --> Final output sent to browser
DEBUG - 2011-09-23 02:14:15 --> Total execution time: 0.1245
DEBUG - 2011-09-23 02:14:16 --> Config Class Initialized
DEBUG - 2011-09-23 02:14:16 --> Hooks Class Initialized
DEBUG - 2011-09-23 02:14:16 --> Utf8 Class Initialized
DEBUG - 2011-09-23 02:14:16 --> UTF-8 Support Enabled
DEBUG - 2011-09-23 02:14:16 --> URI Class Initialized
DEBUG - 2011-09-23 02:14:16 --> Router Class Initialized
DEBUG - 2011-09-23 02:14:16 --> Output Class Initialized
DEBUG - 2011-09-23 02:14:16 --> Input Class Initialized
DEBUG - 2011-09-23 02:14:16 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-23 02:14:16 --> Language Class Initialized
DEBUG - 2011-09-23 02:14:16 --> Loader Class Initialized
DEBUG - 2011-09-23 02:14:16 --> Controller Class Initialized
DEBUG - 2011-09-23 02:14:16 --> Model Class Initialized
DEBUG - 2011-09-23 02:14:16 --> Model Class Initialized
DEBUG - 2011-09-23 02:14:16 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-23 02:14:16 --> Database Driver Class Initialized
DEBUG - 2011-09-23 02:14:17 --> Final output sent to browser
DEBUG - 2011-09-23 02:14:17 --> Total execution time: 0.7161
DEBUG - 2011-09-23 02:14:30 --> Config Class Initialized
DEBUG - 2011-09-23 02:14:30 --> Hooks Class Initialized
DEBUG - 2011-09-23 02:14:30 --> Utf8 Class Initialized
DEBUG - 2011-09-23 02:14:30 --> UTF-8 Support Enabled
DEBUG - 2011-09-23 02:14:30 --> URI Class Initialized
DEBUG - 2011-09-23 02:14:30 --> Router Class Initialized
DEBUG - 2011-09-23 02:14:30 --> Output Class Initialized
DEBUG - 2011-09-23 02:14:30 --> Input Class Initialized
DEBUG - 2011-09-23 02:14:30 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-23 02:14:30 --> Language Class Initialized
DEBUG - 2011-09-23 02:14:30 --> Loader Class Initialized
DEBUG - 2011-09-23 02:14:30 --> Controller Class Initialized
ERROR - 2011-09-23 02:14:30 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-23 02:14:30 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-23 02:14:30 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-23 02:14:30 --> Model Class Initialized
DEBUG - 2011-09-23 02:14:30 --> Model Class Initialized
DEBUG - 2011-09-23 02:14:30 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-23 02:14:30 --> Database Driver Class Initialized
DEBUG - 2011-09-23 02:14:30 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-23 02:14:30 --> Helper loaded: url_helper
DEBUG - 2011-09-23 02:14:30 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-23 02:14:30 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-23 02:14:30 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-23 02:14:30 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-23 02:14:30 --> Final output sent to browser
DEBUG - 2011-09-23 02:14:30 --> Total execution time: 0.0502
DEBUG - 2011-09-23 02:14:31 --> Config Class Initialized
DEBUG - 2011-09-23 02:14:31 --> Hooks Class Initialized
DEBUG - 2011-09-23 02:14:31 --> Utf8 Class Initialized
DEBUG - 2011-09-23 02:14:31 --> UTF-8 Support Enabled
DEBUG - 2011-09-23 02:14:31 --> URI Class Initialized
DEBUG - 2011-09-23 02:14:31 --> Router Class Initialized
DEBUG - 2011-09-23 02:14:31 --> Output Class Initialized
DEBUG - 2011-09-23 02:14:31 --> Input Class Initialized
DEBUG - 2011-09-23 02:14:31 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-23 02:14:31 --> Language Class Initialized
DEBUG - 2011-09-23 02:14:31 --> Loader Class Initialized
DEBUG - 2011-09-23 02:14:31 --> Controller Class Initialized
DEBUG - 2011-09-23 02:14:31 --> Model Class Initialized
DEBUG - 2011-09-23 02:14:31 --> Model Class Initialized
DEBUG - 2011-09-23 02:14:31 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-23 02:14:31 --> Database Driver Class Initialized
DEBUG - 2011-09-23 02:14:32 --> Final output sent to browser
DEBUG - 2011-09-23 02:14:32 --> Total execution time: 0.9352
DEBUG - 2011-09-23 03:03:10 --> Config Class Initialized
DEBUG - 2011-09-23 03:03:10 --> Hooks Class Initialized
DEBUG - 2011-09-23 03:03:10 --> Utf8 Class Initialized
DEBUG - 2011-09-23 03:03:10 --> UTF-8 Support Enabled
DEBUG - 2011-09-23 03:03:10 --> URI Class Initialized
DEBUG - 2011-09-23 03:03:10 --> Router Class Initialized
DEBUG - 2011-09-23 03:03:10 --> Output Class Initialized
DEBUG - 2011-09-23 03:03:10 --> Input Class Initialized
DEBUG - 2011-09-23 03:03:10 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-23 03:03:10 --> Language Class Initialized
DEBUG - 2011-09-23 03:03:10 --> Loader Class Initialized
DEBUG - 2011-09-23 03:03:10 --> Controller Class Initialized
DEBUG - 2011-09-23 03:03:10 --> Model Class Initialized
DEBUG - 2011-09-23 03:03:10 --> Model Class Initialized
DEBUG - 2011-09-23 03:03:10 --> Model Class Initialized
DEBUG - 2011-09-23 03:03:10 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-23 03:03:10 --> Database Driver Class Initialized
DEBUG - 2011-09-23 03:03:11 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-23 03:03:11 --> Helper loaded: url_helper
DEBUG - 2011-09-23 03:03:11 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-23 03:03:11 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-23 03:03:11 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-23 03:03:11 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-23 03:03:11 --> Final output sent to browser
DEBUG - 2011-09-23 03:03:11 --> Total execution time: 1.2381
DEBUG - 2011-09-23 03:03:14 --> Config Class Initialized
DEBUG - 2011-09-23 03:03:14 --> Hooks Class Initialized
DEBUG - 2011-09-23 03:03:14 --> Utf8 Class Initialized
DEBUG - 2011-09-23 03:03:14 --> UTF-8 Support Enabled
DEBUG - 2011-09-23 03:03:14 --> URI Class Initialized
DEBUG - 2011-09-23 03:03:14 --> Router Class Initialized
ERROR - 2011-09-23 03:03:14 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-23 03:04:04 --> Config Class Initialized
DEBUG - 2011-09-23 03:04:04 --> Hooks Class Initialized
DEBUG - 2011-09-23 03:04:04 --> Utf8 Class Initialized
DEBUG - 2011-09-23 03:04:04 --> UTF-8 Support Enabled
DEBUG - 2011-09-23 03:04:04 --> URI Class Initialized
DEBUG - 2011-09-23 03:04:04 --> Router Class Initialized
DEBUG - 2011-09-23 03:04:04 --> Output Class Initialized
DEBUG - 2011-09-23 03:04:04 --> Input Class Initialized
DEBUG - 2011-09-23 03:04:04 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-23 03:04:04 --> Language Class Initialized
DEBUG - 2011-09-23 03:04:04 --> Loader Class Initialized
DEBUG - 2011-09-23 03:04:04 --> Controller Class Initialized
DEBUG - 2011-09-23 03:04:04 --> Model Class Initialized
DEBUG - 2011-09-23 03:04:04 --> Model Class Initialized
DEBUG - 2011-09-23 03:04:04 --> Model Class Initialized
DEBUG - 2011-09-23 03:04:04 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-23 03:04:04 --> Database Driver Class Initialized
DEBUG - 2011-09-23 03:04:05 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-23 03:04:05 --> Helper loaded: url_helper
DEBUG - 2011-09-23 03:04:05 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-23 03:04:05 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-23 03:04:05 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-23 03:04:05 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-23 03:04:05 --> Final output sent to browser
DEBUG - 2011-09-23 03:04:05 --> Total execution time: 1.4466
DEBUG - 2011-09-23 03:04:06 --> Config Class Initialized
DEBUG - 2011-09-23 03:04:06 --> Hooks Class Initialized
DEBUG - 2011-09-23 03:04:06 --> Utf8 Class Initialized
DEBUG - 2011-09-23 03:04:06 --> UTF-8 Support Enabled
DEBUG - 2011-09-23 03:04:06 --> URI Class Initialized
DEBUG - 2011-09-23 03:04:06 --> Router Class Initialized
ERROR - 2011-09-23 03:04:06 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-23 03:04:30 --> Config Class Initialized
DEBUG - 2011-09-23 03:04:30 --> Hooks Class Initialized
DEBUG - 2011-09-23 03:04:30 --> Utf8 Class Initialized
DEBUG - 2011-09-23 03:04:30 --> UTF-8 Support Enabled
DEBUG - 2011-09-23 03:04:30 --> URI Class Initialized
DEBUG - 2011-09-23 03:04:30 --> Router Class Initialized
DEBUG - 2011-09-23 03:04:30 --> Output Class Initialized
DEBUG - 2011-09-23 03:04:30 --> Input Class Initialized
DEBUG - 2011-09-23 03:04:30 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-23 03:04:30 --> Language Class Initialized
DEBUG - 2011-09-23 03:04:30 --> Loader Class Initialized
DEBUG - 2011-09-23 03:04:30 --> Controller Class Initialized
DEBUG - 2011-09-23 03:04:30 --> Model Class Initialized
DEBUG - 2011-09-23 03:04:30 --> Model Class Initialized
DEBUG - 2011-09-23 03:04:30 --> Model Class Initialized
DEBUG - 2011-09-23 03:04:30 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-23 03:04:30 --> Database Driver Class Initialized
DEBUG - 2011-09-23 03:04:33 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-23 03:04:33 --> Helper loaded: url_helper
DEBUG - 2011-09-23 03:04:33 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-23 03:04:33 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-23 03:04:33 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-23 03:04:33 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-23 03:04:33 --> Final output sent to browser
DEBUG - 2011-09-23 03:04:33 --> Total execution time: 2.6416
DEBUG - 2011-09-23 03:04:34 --> Config Class Initialized
DEBUG - 2011-09-23 03:04:34 --> Hooks Class Initialized
DEBUG - 2011-09-23 03:04:34 --> Utf8 Class Initialized
DEBUG - 2011-09-23 03:04:34 --> UTF-8 Support Enabled
DEBUG - 2011-09-23 03:04:34 --> URI Class Initialized
DEBUG - 2011-09-23 03:04:34 --> Router Class Initialized
ERROR - 2011-09-23 03:04:34 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-23 03:05:04 --> Config Class Initialized
DEBUG - 2011-09-23 03:05:04 --> Hooks Class Initialized
DEBUG - 2011-09-23 03:05:04 --> Utf8 Class Initialized
DEBUG - 2011-09-23 03:05:04 --> UTF-8 Support Enabled
DEBUG - 2011-09-23 03:05:04 --> URI Class Initialized
DEBUG - 2011-09-23 03:05:04 --> Router Class Initialized
DEBUG - 2011-09-23 03:05:04 --> Output Class Initialized
DEBUG - 2011-09-23 03:05:04 --> Input Class Initialized
DEBUG - 2011-09-23 03:05:04 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-23 03:05:04 --> Language Class Initialized
DEBUG - 2011-09-23 03:05:04 --> Loader Class Initialized
DEBUG - 2011-09-23 03:05:04 --> Controller Class Initialized
DEBUG - 2011-09-23 03:05:04 --> Model Class Initialized
DEBUG - 2011-09-23 03:05:04 --> Model Class Initialized
DEBUG - 2011-09-23 03:05:04 --> Model Class Initialized
DEBUG - 2011-09-23 03:05:04 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-23 03:05:05 --> Database Driver Class Initialized
DEBUG - 2011-09-23 03:05:05 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-23 03:05:05 --> Helper loaded: url_helper
DEBUG - 2011-09-23 03:05:05 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-23 03:05:05 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-23 03:05:05 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-23 03:05:05 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-23 03:05:05 --> Final output sent to browser
DEBUG - 2011-09-23 03:05:05 --> Total execution time: 0.6806
DEBUG - 2011-09-23 03:05:07 --> Config Class Initialized
DEBUG - 2011-09-23 03:05:07 --> Hooks Class Initialized
DEBUG - 2011-09-23 03:05:07 --> Utf8 Class Initialized
DEBUG - 2011-09-23 03:05:07 --> UTF-8 Support Enabled
DEBUG - 2011-09-23 03:05:07 --> URI Class Initialized
DEBUG - 2011-09-23 03:05:07 --> Router Class Initialized
ERROR - 2011-09-23 03:05:07 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-23 03:05:15 --> Config Class Initialized
DEBUG - 2011-09-23 03:05:15 --> Hooks Class Initialized
DEBUG - 2011-09-23 03:05:15 --> Utf8 Class Initialized
DEBUG - 2011-09-23 03:05:15 --> UTF-8 Support Enabled
DEBUG - 2011-09-23 03:05:15 --> URI Class Initialized
DEBUG - 2011-09-23 03:05:15 --> Router Class Initialized
DEBUG - 2011-09-23 03:05:15 --> Output Class Initialized
DEBUG - 2011-09-23 03:05:15 --> Input Class Initialized
DEBUG - 2011-09-23 03:05:15 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-23 03:05:15 --> Language Class Initialized
DEBUG - 2011-09-23 03:05:15 --> Loader Class Initialized
DEBUG - 2011-09-23 03:05:15 --> Controller Class Initialized
DEBUG - 2011-09-23 03:05:15 --> Model Class Initialized
DEBUG - 2011-09-23 03:05:15 --> Model Class Initialized
DEBUG - 2011-09-23 03:05:15 --> Model Class Initialized
DEBUG - 2011-09-23 03:05:15 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-23 03:05:15 --> Database Driver Class Initialized
DEBUG - 2011-09-23 03:05:15 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-23 03:05:15 --> Helper loaded: url_helper
DEBUG - 2011-09-23 03:05:15 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-23 03:05:15 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-23 03:05:15 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-23 03:05:15 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-23 03:05:15 --> Final output sent to browser
DEBUG - 2011-09-23 03:05:15 --> Total execution time: 0.1837
DEBUG - 2011-09-23 03:05:23 --> Config Class Initialized
DEBUG - 2011-09-23 03:05:23 --> Hooks Class Initialized
DEBUG - 2011-09-23 03:05:23 --> Utf8 Class Initialized
DEBUG - 2011-09-23 03:05:23 --> UTF-8 Support Enabled
DEBUG - 2011-09-23 03:05:23 --> URI Class Initialized
DEBUG - 2011-09-23 03:05:23 --> Router Class Initialized
DEBUG - 2011-09-23 03:05:23 --> Output Class Initialized
DEBUG - 2011-09-23 03:05:23 --> Input Class Initialized
DEBUG - 2011-09-23 03:05:23 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-23 03:05:23 --> Language Class Initialized
DEBUG - 2011-09-23 03:05:23 --> Loader Class Initialized
DEBUG - 2011-09-23 03:05:23 --> Controller Class Initialized
DEBUG - 2011-09-23 03:05:23 --> Model Class Initialized
DEBUG - 2011-09-23 03:05:23 --> Model Class Initialized
DEBUG - 2011-09-23 03:05:23 --> Model Class Initialized
DEBUG - 2011-09-23 03:05:23 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-23 03:05:23 --> Database Driver Class Initialized
DEBUG - 2011-09-23 03:05:23 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-23 03:05:23 --> Helper loaded: url_helper
DEBUG - 2011-09-23 03:05:23 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-23 03:05:23 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-23 03:05:23 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-23 03:05:23 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-23 03:05:23 --> Final output sent to browser
DEBUG - 2011-09-23 03:05:23 --> Total execution time: 0.0637
DEBUG - 2011-09-23 03:05:27 --> Config Class Initialized
DEBUG - 2011-09-23 03:05:27 --> Hooks Class Initialized
DEBUG - 2011-09-23 03:05:27 --> Utf8 Class Initialized
DEBUG - 2011-09-23 03:05:27 --> UTF-8 Support Enabled
DEBUG - 2011-09-23 03:05:27 --> URI Class Initialized
DEBUG - 2011-09-23 03:05:27 --> Router Class Initialized
DEBUG - 2011-09-23 03:05:27 --> Output Class Initialized
DEBUG - 2011-09-23 03:05:27 --> Input Class Initialized
DEBUG - 2011-09-23 03:05:27 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-23 03:05:27 --> Language Class Initialized
DEBUG - 2011-09-23 03:05:27 --> Loader Class Initialized
DEBUG - 2011-09-23 03:05:27 --> Controller Class Initialized
DEBUG - 2011-09-23 03:05:27 --> Model Class Initialized
DEBUG - 2011-09-23 03:05:27 --> Model Class Initialized
DEBUG - 2011-09-23 03:05:27 --> Model Class Initialized
DEBUG - 2011-09-23 03:05:27 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-23 03:05:27 --> Database Driver Class Initialized
DEBUG - 2011-09-23 03:05:27 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-23 03:05:27 --> Helper loaded: url_helper
DEBUG - 2011-09-23 03:05:27 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-23 03:05:27 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-23 03:05:27 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-23 03:05:27 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-23 03:05:27 --> Final output sent to browser
DEBUG - 2011-09-23 03:05:27 --> Total execution time: 0.0529
DEBUG - 2011-09-23 03:05:31 --> Config Class Initialized
DEBUG - 2011-09-23 03:05:31 --> Hooks Class Initialized
DEBUG - 2011-09-23 03:05:31 --> Utf8 Class Initialized
DEBUG - 2011-09-23 03:05:31 --> UTF-8 Support Enabled
DEBUG - 2011-09-23 03:05:31 --> URI Class Initialized
DEBUG - 2011-09-23 03:05:31 --> Router Class Initialized
DEBUG - 2011-09-23 03:05:31 --> Output Class Initialized
DEBUG - 2011-09-23 03:05:31 --> Input Class Initialized
DEBUG - 2011-09-23 03:05:31 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-23 03:05:31 --> Language Class Initialized
DEBUG - 2011-09-23 03:05:31 --> Loader Class Initialized
DEBUG - 2011-09-23 03:05:31 --> Controller Class Initialized
DEBUG - 2011-09-23 03:05:31 --> Model Class Initialized
DEBUG - 2011-09-23 03:05:31 --> Model Class Initialized
DEBUG - 2011-09-23 03:05:31 --> Model Class Initialized
DEBUG - 2011-09-23 03:05:31 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-23 03:05:31 --> Database Driver Class Initialized
DEBUG - 2011-09-23 03:05:32 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-23 03:05:32 --> Helper loaded: url_helper
DEBUG - 2011-09-23 03:05:32 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-23 03:05:32 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-23 03:05:32 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-23 03:05:32 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-23 03:05:32 --> Final output sent to browser
DEBUG - 2011-09-23 03:05:32 --> Total execution time: 0.7403
DEBUG - 2011-09-23 03:05:33 --> Config Class Initialized
DEBUG - 2011-09-23 03:05:33 --> Hooks Class Initialized
DEBUG - 2011-09-23 03:05:33 --> Utf8 Class Initialized
DEBUG - 2011-09-23 03:05:33 --> UTF-8 Support Enabled
DEBUG - 2011-09-23 03:05:33 --> URI Class Initialized
DEBUG - 2011-09-23 03:05:33 --> Router Class Initialized
ERROR - 2011-09-23 03:05:33 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-23 03:05:34 --> Config Class Initialized
DEBUG - 2011-09-23 03:05:34 --> Hooks Class Initialized
DEBUG - 2011-09-23 03:05:34 --> Utf8 Class Initialized
DEBUG - 2011-09-23 03:05:34 --> UTF-8 Support Enabled
DEBUG - 2011-09-23 03:05:34 --> URI Class Initialized
DEBUG - 2011-09-23 03:05:34 --> Router Class Initialized
DEBUG - 2011-09-23 03:05:34 --> Output Class Initialized
DEBUG - 2011-09-23 03:05:34 --> Input Class Initialized
DEBUG - 2011-09-23 03:05:34 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-23 03:05:34 --> Language Class Initialized
DEBUG - 2011-09-23 03:05:34 --> Loader Class Initialized
DEBUG - 2011-09-23 03:05:34 --> Controller Class Initialized
DEBUG - 2011-09-23 03:05:34 --> Model Class Initialized
DEBUG - 2011-09-23 03:05:34 --> Model Class Initialized
DEBUG - 2011-09-23 03:05:34 --> Model Class Initialized
DEBUG - 2011-09-23 03:05:34 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-23 03:05:34 --> Database Driver Class Initialized
DEBUG - 2011-09-23 03:05:34 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-23 03:05:34 --> Helper loaded: url_helper
DEBUG - 2011-09-23 03:05:34 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-23 03:05:34 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-23 03:05:34 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-23 03:05:34 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-23 03:05:34 --> Final output sent to browser
DEBUG - 2011-09-23 03:05:34 --> Total execution time: 0.0463
DEBUG - 2011-09-23 03:05:59 --> Config Class Initialized
DEBUG - 2011-09-23 03:05:59 --> Hooks Class Initialized
DEBUG - 2011-09-23 03:05:59 --> Utf8 Class Initialized
DEBUG - 2011-09-23 03:05:59 --> UTF-8 Support Enabled
DEBUG - 2011-09-23 03:05:59 --> URI Class Initialized
DEBUG - 2011-09-23 03:05:59 --> Router Class Initialized
DEBUG - 2011-09-23 03:05:59 --> Output Class Initialized
DEBUG - 2011-09-23 03:05:59 --> Input Class Initialized
DEBUG - 2011-09-23 03:05:59 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-23 03:05:59 --> Language Class Initialized
DEBUG - 2011-09-23 03:05:59 --> Loader Class Initialized
DEBUG - 2011-09-23 03:05:59 --> Controller Class Initialized
DEBUG - 2011-09-23 03:05:59 --> Model Class Initialized
DEBUG - 2011-09-23 03:05:59 --> Model Class Initialized
DEBUG - 2011-09-23 03:05:59 --> Model Class Initialized
DEBUG - 2011-09-23 03:05:59 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-23 03:05:59 --> Database Driver Class Initialized
DEBUG - 2011-09-23 03:06:00 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-23 03:06:00 --> Helper loaded: url_helper
DEBUG - 2011-09-23 03:06:00 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-23 03:06:00 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-23 03:06:00 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-23 03:06:00 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-23 03:06:00 --> Final output sent to browser
DEBUG - 2011-09-23 03:06:00 --> Total execution time: 1.4884
DEBUG - 2011-09-23 03:06:02 --> Config Class Initialized
DEBUG - 2011-09-23 03:06:02 --> Hooks Class Initialized
DEBUG - 2011-09-23 03:06:02 --> Utf8 Class Initialized
DEBUG - 2011-09-23 03:06:02 --> UTF-8 Support Enabled
DEBUG - 2011-09-23 03:06:02 --> URI Class Initialized
DEBUG - 2011-09-23 03:06:02 --> Router Class Initialized
ERROR - 2011-09-23 03:06:02 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-23 03:06:46 --> Config Class Initialized
DEBUG - 2011-09-23 03:06:46 --> Hooks Class Initialized
DEBUG - 2011-09-23 03:06:46 --> Utf8 Class Initialized
DEBUG - 2011-09-23 03:06:46 --> UTF-8 Support Enabled
DEBUG - 2011-09-23 03:06:46 --> URI Class Initialized
DEBUG - 2011-09-23 03:06:46 --> Router Class Initialized
DEBUG - 2011-09-23 03:06:46 --> Output Class Initialized
DEBUG - 2011-09-23 03:06:46 --> Input Class Initialized
DEBUG - 2011-09-23 03:06:46 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-23 03:06:46 --> Language Class Initialized
DEBUG - 2011-09-23 03:06:46 --> Loader Class Initialized
DEBUG - 2011-09-23 03:06:46 --> Controller Class Initialized
DEBUG - 2011-09-23 03:06:46 --> Model Class Initialized
DEBUG - 2011-09-23 03:06:46 --> Model Class Initialized
DEBUG - 2011-09-23 03:06:46 --> Model Class Initialized
DEBUG - 2011-09-23 03:06:46 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-23 03:06:46 --> Database Driver Class Initialized
DEBUG - 2011-09-23 03:06:48 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-23 03:06:48 --> Helper loaded: url_helper
DEBUG - 2011-09-23 03:06:48 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-23 03:06:48 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-23 03:06:48 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-23 03:06:48 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-23 03:06:48 --> Final output sent to browser
DEBUG - 2011-09-23 03:06:48 --> Total execution time: 2.1093
DEBUG - 2011-09-23 03:06:49 --> Config Class Initialized
DEBUG - 2011-09-23 03:06:49 --> Hooks Class Initialized
DEBUG - 2011-09-23 03:06:49 --> Utf8 Class Initialized
DEBUG - 2011-09-23 03:06:49 --> UTF-8 Support Enabled
DEBUG - 2011-09-23 03:06:49 --> URI Class Initialized
DEBUG - 2011-09-23 03:06:49 --> Router Class Initialized
ERROR - 2011-09-23 03:06:49 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-23 03:07:15 --> Config Class Initialized
DEBUG - 2011-09-23 03:07:15 --> Hooks Class Initialized
DEBUG - 2011-09-23 03:07:15 --> Utf8 Class Initialized
DEBUG - 2011-09-23 03:07:15 --> UTF-8 Support Enabled
DEBUG - 2011-09-23 03:07:15 --> URI Class Initialized
DEBUG - 2011-09-23 03:07:15 --> Router Class Initialized
DEBUG - 2011-09-23 03:07:15 --> Output Class Initialized
DEBUG - 2011-09-23 03:07:15 --> Input Class Initialized
DEBUG - 2011-09-23 03:07:15 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-23 03:07:15 --> Language Class Initialized
DEBUG - 2011-09-23 03:07:15 --> Loader Class Initialized
DEBUG - 2011-09-23 03:07:15 --> Controller Class Initialized
DEBUG - 2011-09-23 03:07:15 --> Model Class Initialized
DEBUG - 2011-09-23 03:07:15 --> Model Class Initialized
DEBUG - 2011-09-23 03:07:15 --> Model Class Initialized
DEBUG - 2011-09-23 03:07:15 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-23 03:07:15 --> Database Driver Class Initialized
DEBUG - 2011-09-23 03:07:16 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-23 03:07:16 --> Helper loaded: url_helper
DEBUG - 2011-09-23 03:07:16 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-23 03:07:16 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-23 03:07:16 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-23 03:07:16 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-23 03:07:16 --> Final output sent to browser
DEBUG - 2011-09-23 03:07:16 --> Total execution time: 0.3390
DEBUG - 2011-09-23 03:07:17 --> Config Class Initialized
DEBUG - 2011-09-23 03:07:17 --> Hooks Class Initialized
DEBUG - 2011-09-23 03:07:17 --> Utf8 Class Initialized
DEBUG - 2011-09-23 03:07:17 --> UTF-8 Support Enabled
DEBUG - 2011-09-23 03:07:17 --> URI Class Initialized
DEBUG - 2011-09-23 03:07:17 --> Router Class Initialized
ERROR - 2011-09-23 03:07:17 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-23 03:07:39 --> Config Class Initialized
DEBUG - 2011-09-23 03:07:39 --> Hooks Class Initialized
DEBUG - 2011-09-23 03:07:39 --> Utf8 Class Initialized
DEBUG - 2011-09-23 03:07:39 --> UTF-8 Support Enabled
DEBUG - 2011-09-23 03:07:39 --> URI Class Initialized
DEBUG - 2011-09-23 03:07:39 --> Router Class Initialized
DEBUG - 2011-09-23 03:07:39 --> Output Class Initialized
DEBUG - 2011-09-23 03:07:39 --> Input Class Initialized
DEBUG - 2011-09-23 03:07:39 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-23 03:07:39 --> Language Class Initialized
DEBUG - 2011-09-23 03:07:39 --> Loader Class Initialized
DEBUG - 2011-09-23 03:07:39 --> Controller Class Initialized
DEBUG - 2011-09-23 03:07:39 --> Model Class Initialized
DEBUG - 2011-09-23 03:07:39 --> Model Class Initialized
DEBUG - 2011-09-23 03:07:39 --> Model Class Initialized
DEBUG - 2011-09-23 03:07:39 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-23 03:07:39 --> Database Driver Class Initialized
DEBUG - 2011-09-23 03:07:39 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-23 03:07:39 --> Helper loaded: url_helper
DEBUG - 2011-09-23 03:07:39 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-23 03:07:39 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-23 03:07:39 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-23 03:07:39 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-23 03:07:39 --> Final output sent to browser
DEBUG - 2011-09-23 03:07:39 --> Total execution time: 0.1645
DEBUG - 2011-09-23 03:07:41 --> Config Class Initialized
DEBUG - 2011-09-23 03:07:41 --> Hooks Class Initialized
DEBUG - 2011-09-23 03:07:41 --> Utf8 Class Initialized
DEBUG - 2011-09-23 03:07:41 --> UTF-8 Support Enabled
DEBUG - 2011-09-23 03:07:41 --> URI Class Initialized
DEBUG - 2011-09-23 03:07:41 --> Router Class Initialized
ERROR - 2011-09-23 03:07:41 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-23 03:07:55 --> Config Class Initialized
DEBUG - 2011-09-23 03:07:55 --> Hooks Class Initialized
DEBUG - 2011-09-23 03:07:55 --> Utf8 Class Initialized
DEBUG - 2011-09-23 03:07:55 --> UTF-8 Support Enabled
DEBUG - 2011-09-23 03:07:55 --> URI Class Initialized
DEBUG - 2011-09-23 03:07:55 --> Router Class Initialized
DEBUG - 2011-09-23 03:07:55 --> Output Class Initialized
DEBUG - 2011-09-23 03:07:55 --> Input Class Initialized
DEBUG - 2011-09-23 03:07:55 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-23 03:07:55 --> Language Class Initialized
DEBUG - 2011-09-23 03:07:55 --> Loader Class Initialized
DEBUG - 2011-09-23 03:07:55 --> Controller Class Initialized
DEBUG - 2011-09-23 03:07:55 --> Model Class Initialized
DEBUG - 2011-09-23 03:07:55 --> Model Class Initialized
DEBUG - 2011-09-23 03:07:55 --> Model Class Initialized
DEBUG - 2011-09-23 03:07:55 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-23 03:07:55 --> Database Driver Class Initialized
DEBUG - 2011-09-23 03:07:55 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-23 03:07:55 --> Helper loaded: url_helper
DEBUG - 2011-09-23 03:07:55 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-23 03:07:55 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-23 03:07:55 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-23 03:07:55 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-23 03:07:55 --> Final output sent to browser
DEBUG - 2011-09-23 03:07:55 --> Total execution time: 0.3871
DEBUG - 2011-09-23 03:07:57 --> Config Class Initialized
DEBUG - 2011-09-23 03:07:57 --> Hooks Class Initialized
DEBUG - 2011-09-23 03:07:57 --> Utf8 Class Initialized
DEBUG - 2011-09-23 03:07:57 --> UTF-8 Support Enabled
DEBUG - 2011-09-23 03:07:57 --> URI Class Initialized
DEBUG - 2011-09-23 03:07:57 --> Router Class Initialized
ERROR - 2011-09-23 03:07:57 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-23 03:08:12 --> Config Class Initialized
DEBUG - 2011-09-23 03:08:12 --> Hooks Class Initialized
DEBUG - 2011-09-23 03:08:12 --> Utf8 Class Initialized
DEBUG - 2011-09-23 03:08:12 --> UTF-8 Support Enabled
DEBUG - 2011-09-23 03:08:12 --> URI Class Initialized
DEBUG - 2011-09-23 03:08:12 --> Router Class Initialized
DEBUG - 2011-09-23 03:08:12 --> Output Class Initialized
DEBUG - 2011-09-23 03:08:12 --> Input Class Initialized
DEBUG - 2011-09-23 03:08:12 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-23 03:08:12 --> Language Class Initialized
DEBUG - 2011-09-23 03:08:12 --> Loader Class Initialized
DEBUG - 2011-09-23 03:08:12 --> Controller Class Initialized
DEBUG - 2011-09-23 03:08:12 --> Model Class Initialized
DEBUG - 2011-09-23 03:08:12 --> Model Class Initialized
DEBUG - 2011-09-23 03:08:12 --> Model Class Initialized
DEBUG - 2011-09-23 03:08:12 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-23 03:08:12 --> Database Driver Class Initialized
DEBUG - 2011-09-23 03:08:13 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-23 03:08:13 --> Helper loaded: url_helper
DEBUG - 2011-09-23 03:08:13 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-23 03:08:13 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-23 03:08:13 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-23 03:08:13 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-23 03:08:13 --> Final output sent to browser
DEBUG - 2011-09-23 03:08:13 --> Total execution time: 0.9766
DEBUG - 2011-09-23 03:08:15 --> Config Class Initialized
DEBUG - 2011-09-23 03:08:15 --> Hooks Class Initialized
DEBUG - 2011-09-23 03:08:15 --> Utf8 Class Initialized
DEBUG - 2011-09-23 03:08:15 --> UTF-8 Support Enabled
DEBUG - 2011-09-23 03:08:15 --> URI Class Initialized
DEBUG - 2011-09-23 03:08:15 --> Router Class Initialized
ERROR - 2011-09-23 03:08:15 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-23 03:09:00 --> Config Class Initialized
DEBUG - 2011-09-23 03:09:00 --> Hooks Class Initialized
DEBUG - 2011-09-23 03:09:00 --> Utf8 Class Initialized
DEBUG - 2011-09-23 03:09:00 --> UTF-8 Support Enabled
DEBUG - 2011-09-23 03:09:00 --> URI Class Initialized
DEBUG - 2011-09-23 03:09:00 --> Router Class Initialized
DEBUG - 2011-09-23 03:09:00 --> Output Class Initialized
DEBUG - 2011-09-23 03:09:00 --> Input Class Initialized
DEBUG - 2011-09-23 03:09:00 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-23 03:09:00 --> Language Class Initialized
DEBUG - 2011-09-23 03:09:00 --> Loader Class Initialized
DEBUG - 2011-09-23 03:09:00 --> Controller Class Initialized
DEBUG - 2011-09-23 03:09:00 --> Model Class Initialized
DEBUG - 2011-09-23 03:09:00 --> Model Class Initialized
DEBUG - 2011-09-23 03:09:00 --> Model Class Initialized
DEBUG - 2011-09-23 03:09:00 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-23 03:09:00 --> Database Driver Class Initialized
DEBUG - 2011-09-23 03:09:00 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-23 03:09:00 --> Helper loaded: url_helper
DEBUG - 2011-09-23 03:09:00 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-23 03:09:00 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-23 03:09:00 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-23 03:09:00 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-23 03:09:00 --> Final output sent to browser
DEBUG - 2011-09-23 03:09:00 --> Total execution time: 0.4252
DEBUG - 2011-09-23 03:09:02 --> Config Class Initialized
DEBUG - 2011-09-23 03:09:02 --> Hooks Class Initialized
DEBUG - 2011-09-23 03:09:02 --> Utf8 Class Initialized
DEBUG - 2011-09-23 03:09:02 --> UTF-8 Support Enabled
DEBUG - 2011-09-23 03:09:02 --> URI Class Initialized
DEBUG - 2011-09-23 03:09:02 --> Router Class Initialized
ERROR - 2011-09-23 03:09:02 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-23 03:09:33 --> Config Class Initialized
DEBUG - 2011-09-23 03:09:33 --> Hooks Class Initialized
DEBUG - 2011-09-23 03:09:33 --> Utf8 Class Initialized
DEBUG - 2011-09-23 03:09:33 --> UTF-8 Support Enabled
DEBUG - 2011-09-23 03:09:33 --> URI Class Initialized
DEBUG - 2011-09-23 03:09:33 --> Router Class Initialized
DEBUG - 2011-09-23 03:09:33 --> Output Class Initialized
DEBUG - 2011-09-23 03:09:33 --> Input Class Initialized
DEBUG - 2011-09-23 03:09:33 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-23 03:09:33 --> Language Class Initialized
DEBUG - 2011-09-23 03:09:33 --> Loader Class Initialized
DEBUG - 2011-09-23 03:09:33 --> Controller Class Initialized
DEBUG - 2011-09-23 03:09:33 --> Model Class Initialized
DEBUG - 2011-09-23 03:09:33 --> Model Class Initialized
DEBUG - 2011-09-23 03:09:33 --> Model Class Initialized
DEBUG - 2011-09-23 03:09:33 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-23 03:09:33 --> Database Driver Class Initialized
DEBUG - 2011-09-23 03:09:34 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-23 03:09:34 --> Helper loaded: url_helper
DEBUG - 2011-09-23 03:09:34 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-23 03:09:34 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-23 03:09:34 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-23 03:09:34 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-23 03:09:34 --> Final output sent to browser
DEBUG - 2011-09-23 03:09:34 --> Total execution time: 0.7261
DEBUG - 2011-09-23 03:09:35 --> Config Class Initialized
DEBUG - 2011-09-23 03:09:35 --> Hooks Class Initialized
DEBUG - 2011-09-23 03:09:35 --> Utf8 Class Initialized
DEBUG - 2011-09-23 03:09:35 --> UTF-8 Support Enabled
DEBUG - 2011-09-23 03:09:35 --> URI Class Initialized
DEBUG - 2011-09-23 03:09:35 --> Router Class Initialized
ERROR - 2011-09-23 03:09:35 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-23 03:10:04 --> Config Class Initialized
DEBUG - 2011-09-23 03:10:04 --> Hooks Class Initialized
DEBUG - 2011-09-23 03:10:04 --> Utf8 Class Initialized
DEBUG - 2011-09-23 03:10:04 --> UTF-8 Support Enabled
DEBUG - 2011-09-23 03:10:04 --> URI Class Initialized
DEBUG - 2011-09-23 03:10:04 --> Router Class Initialized
DEBUG - 2011-09-23 03:10:04 --> Output Class Initialized
DEBUG - 2011-09-23 03:10:04 --> Input Class Initialized
DEBUG - 2011-09-23 03:10:04 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-23 03:10:04 --> Language Class Initialized
DEBUG - 2011-09-23 03:10:04 --> Loader Class Initialized
DEBUG - 2011-09-23 03:10:04 --> Controller Class Initialized
DEBUG - 2011-09-23 03:10:04 --> Model Class Initialized
DEBUG - 2011-09-23 03:10:04 --> Model Class Initialized
DEBUG - 2011-09-23 03:10:04 --> Model Class Initialized
DEBUG - 2011-09-23 03:10:04 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-23 03:10:04 --> Database Driver Class Initialized
DEBUG - 2011-09-23 03:10:04 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-23 03:10:04 --> Helper loaded: url_helper
DEBUG - 2011-09-23 03:10:04 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-23 03:10:04 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-23 03:10:04 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-23 03:10:04 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-23 03:10:04 --> Final output sent to browser
DEBUG - 2011-09-23 03:10:04 --> Total execution time: 0.4364
DEBUG - 2011-09-23 03:10:06 --> Config Class Initialized
DEBUG - 2011-09-23 03:10:06 --> Hooks Class Initialized
DEBUG - 2011-09-23 03:10:06 --> Utf8 Class Initialized
DEBUG - 2011-09-23 03:10:06 --> UTF-8 Support Enabled
DEBUG - 2011-09-23 03:10:06 --> URI Class Initialized
DEBUG - 2011-09-23 03:10:06 --> Router Class Initialized
ERROR - 2011-09-23 03:10:06 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-23 03:10:36 --> Config Class Initialized
DEBUG - 2011-09-23 03:10:36 --> Hooks Class Initialized
DEBUG - 2011-09-23 03:10:36 --> Utf8 Class Initialized
DEBUG - 2011-09-23 03:10:36 --> UTF-8 Support Enabled
DEBUG - 2011-09-23 03:10:36 --> URI Class Initialized
DEBUG - 2011-09-23 03:10:36 --> Router Class Initialized
DEBUG - 2011-09-23 03:10:36 --> Output Class Initialized
DEBUG - 2011-09-23 03:10:36 --> Input Class Initialized
DEBUG - 2011-09-23 03:10:36 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-23 03:10:36 --> Language Class Initialized
DEBUG - 2011-09-23 03:10:36 --> Loader Class Initialized
DEBUG - 2011-09-23 03:10:36 --> Controller Class Initialized
DEBUG - 2011-09-23 03:10:36 --> Model Class Initialized
DEBUG - 2011-09-23 03:10:36 --> Model Class Initialized
DEBUG - 2011-09-23 03:10:36 --> Model Class Initialized
DEBUG - 2011-09-23 03:10:36 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-23 03:10:36 --> Database Driver Class Initialized
DEBUG - 2011-09-23 03:10:37 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-23 03:10:37 --> Helper loaded: url_helper
DEBUG - 2011-09-23 03:10:37 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-23 03:10:37 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-23 03:10:37 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-23 03:10:37 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-23 03:10:37 --> Final output sent to browser
DEBUG - 2011-09-23 03:10:37 --> Total execution time: 0.8396
DEBUG - 2011-09-23 03:10:38 --> Config Class Initialized
DEBUG - 2011-09-23 03:10:38 --> Hooks Class Initialized
DEBUG - 2011-09-23 03:10:38 --> Utf8 Class Initialized
DEBUG - 2011-09-23 03:10:38 --> UTF-8 Support Enabled
DEBUG - 2011-09-23 03:10:38 --> URI Class Initialized
DEBUG - 2011-09-23 03:10:38 --> Router Class Initialized
ERROR - 2011-09-23 03:10:38 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-23 03:10:59 --> Config Class Initialized
DEBUG - 2011-09-23 03:10:59 --> Hooks Class Initialized
DEBUG - 2011-09-23 03:10:59 --> Utf8 Class Initialized
DEBUG - 2011-09-23 03:10:59 --> UTF-8 Support Enabled
DEBUG - 2011-09-23 03:10:59 --> URI Class Initialized
DEBUG - 2011-09-23 03:10:59 --> Router Class Initialized
DEBUG - 2011-09-23 03:10:59 --> Output Class Initialized
DEBUG - 2011-09-23 03:10:59 --> Input Class Initialized
DEBUG - 2011-09-23 03:10:59 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-23 03:10:59 --> Language Class Initialized
DEBUG - 2011-09-23 03:10:59 --> Loader Class Initialized
DEBUG - 2011-09-23 03:10:59 --> Controller Class Initialized
DEBUG - 2011-09-23 03:10:59 --> Model Class Initialized
DEBUG - 2011-09-23 03:10:59 --> Model Class Initialized
DEBUG - 2011-09-23 03:10:59 --> Model Class Initialized
DEBUG - 2011-09-23 03:10:59 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-23 03:10:59 --> Database Driver Class Initialized
DEBUG - 2011-09-23 03:10:59 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-23 03:10:59 --> Helper loaded: url_helper
DEBUG - 2011-09-23 03:10:59 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-23 03:10:59 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-23 03:10:59 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-23 03:10:59 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-23 03:10:59 --> Final output sent to browser
DEBUG - 2011-09-23 03:10:59 --> Total execution time: 0.2969
DEBUG - 2011-09-23 03:11:00 --> Config Class Initialized
DEBUG - 2011-09-23 03:11:00 --> Hooks Class Initialized
DEBUG - 2011-09-23 03:11:00 --> Utf8 Class Initialized
DEBUG - 2011-09-23 03:11:00 --> UTF-8 Support Enabled
DEBUG - 2011-09-23 03:11:00 --> URI Class Initialized
DEBUG - 2011-09-23 03:11:00 --> Router Class Initialized
ERROR - 2011-09-23 03:11:00 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-23 03:11:17 --> Config Class Initialized
DEBUG - 2011-09-23 03:11:17 --> Hooks Class Initialized
DEBUG - 2011-09-23 03:11:17 --> Utf8 Class Initialized
DEBUG - 2011-09-23 03:11:17 --> UTF-8 Support Enabled
DEBUG - 2011-09-23 03:11:17 --> URI Class Initialized
DEBUG - 2011-09-23 03:11:17 --> Router Class Initialized
DEBUG - 2011-09-23 03:11:17 --> Output Class Initialized
DEBUG - 2011-09-23 03:11:17 --> Input Class Initialized
DEBUG - 2011-09-23 03:11:17 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-23 03:11:17 --> Language Class Initialized
DEBUG - 2011-09-23 03:11:17 --> Loader Class Initialized
DEBUG - 2011-09-23 03:11:17 --> Controller Class Initialized
DEBUG - 2011-09-23 03:11:17 --> Model Class Initialized
DEBUG - 2011-09-23 03:11:17 --> Model Class Initialized
DEBUG - 2011-09-23 03:11:17 --> Model Class Initialized
DEBUG - 2011-09-23 03:11:17 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-23 03:11:17 --> Database Driver Class Initialized
DEBUG - 2011-09-23 03:11:21 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-23 03:11:21 --> Helper loaded: url_helper
DEBUG - 2011-09-23 03:11:21 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-23 03:11:21 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-23 03:11:21 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-23 03:11:21 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-23 03:11:21 --> Final output sent to browser
DEBUG - 2011-09-23 03:11:21 --> Total execution time: 4.1144
DEBUG - 2011-09-23 03:11:22 --> Config Class Initialized
DEBUG - 2011-09-23 03:11:22 --> Hooks Class Initialized
DEBUG - 2011-09-23 03:11:22 --> Utf8 Class Initialized
DEBUG - 2011-09-23 03:11:22 --> UTF-8 Support Enabled
DEBUG - 2011-09-23 03:11:22 --> URI Class Initialized
DEBUG - 2011-09-23 03:11:22 --> Router Class Initialized
ERROR - 2011-09-23 03:11:22 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-23 03:11:39 --> Config Class Initialized
DEBUG - 2011-09-23 03:11:39 --> Hooks Class Initialized
DEBUG - 2011-09-23 03:11:39 --> Utf8 Class Initialized
DEBUG - 2011-09-23 03:11:39 --> UTF-8 Support Enabled
DEBUG - 2011-09-23 03:11:39 --> URI Class Initialized
DEBUG - 2011-09-23 03:11:39 --> Router Class Initialized
DEBUG - 2011-09-23 03:11:39 --> Output Class Initialized
DEBUG - 2011-09-23 03:11:39 --> Input Class Initialized
DEBUG - 2011-09-23 03:11:39 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-23 03:11:39 --> Language Class Initialized
DEBUG - 2011-09-23 03:11:39 --> Loader Class Initialized
DEBUG - 2011-09-23 03:11:39 --> Controller Class Initialized
DEBUG - 2011-09-23 03:11:39 --> Model Class Initialized
DEBUG - 2011-09-23 03:11:39 --> Model Class Initialized
DEBUG - 2011-09-23 03:11:39 --> Model Class Initialized
DEBUG - 2011-09-23 03:11:39 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-23 03:11:39 --> Database Driver Class Initialized
DEBUG - 2011-09-23 03:11:40 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-23 03:11:40 --> Helper loaded: url_helper
DEBUG - 2011-09-23 03:11:40 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-23 03:11:40 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-23 03:11:40 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-23 03:11:40 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-23 03:11:40 --> Final output sent to browser
DEBUG - 2011-09-23 03:11:40 --> Total execution time: 1.7211
DEBUG - 2011-09-23 03:11:42 --> Config Class Initialized
DEBUG - 2011-09-23 03:11:42 --> Hooks Class Initialized
DEBUG - 2011-09-23 03:11:42 --> Utf8 Class Initialized
DEBUG - 2011-09-23 03:11:42 --> UTF-8 Support Enabled
DEBUG - 2011-09-23 03:11:42 --> URI Class Initialized
DEBUG - 2011-09-23 03:11:42 --> Router Class Initialized
ERROR - 2011-09-23 03:11:42 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-23 03:34:03 --> Config Class Initialized
DEBUG - 2011-09-23 03:34:03 --> Hooks Class Initialized
DEBUG - 2011-09-23 03:34:03 --> Utf8 Class Initialized
DEBUG - 2011-09-23 03:34:03 --> UTF-8 Support Enabled
DEBUG - 2011-09-23 03:34:03 --> URI Class Initialized
DEBUG - 2011-09-23 03:34:03 --> Router Class Initialized
DEBUG - 2011-09-23 03:34:03 --> No URI present. Default controller set.
DEBUG - 2011-09-23 03:34:03 --> Output Class Initialized
DEBUG - 2011-09-23 03:34:03 --> Input Class Initialized
DEBUG - 2011-09-23 03:34:03 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-23 03:34:03 --> Language Class Initialized
DEBUG - 2011-09-23 03:34:03 --> Loader Class Initialized
DEBUG - 2011-09-23 03:34:03 --> Controller Class Initialized
DEBUG - 2011-09-23 03:34:03 --> File loaded: application/views/splash/main.php
DEBUG - 2011-09-23 03:34:03 --> Helper loaded: url_helper
DEBUG - 2011-09-23 03:34:03 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-23 03:34:03 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-23 03:34:03 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-23 03:34:03 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-23 03:34:03 --> Final output sent to browser
DEBUG - 2011-09-23 03:34:03 --> Total execution time: 0.2113
DEBUG - 2011-09-23 03:40:19 --> Config Class Initialized
DEBUG - 2011-09-23 03:40:19 --> Hooks Class Initialized
DEBUG - 2011-09-23 03:40:19 --> Utf8 Class Initialized
DEBUG - 2011-09-23 03:40:19 --> UTF-8 Support Enabled
DEBUG - 2011-09-23 03:40:19 --> URI Class Initialized
DEBUG - 2011-09-23 03:40:19 --> Router Class Initialized
DEBUG - 2011-09-23 03:40:19 --> Output Class Initialized
DEBUG - 2011-09-23 03:40:19 --> Input Class Initialized
DEBUG - 2011-09-23 03:40:19 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-23 03:40:19 --> Language Class Initialized
DEBUG - 2011-09-23 03:40:19 --> Loader Class Initialized
DEBUG - 2011-09-23 03:40:19 --> Controller Class Initialized
DEBUG - 2011-09-23 03:40:19 --> Model Class Initialized
DEBUG - 2011-09-23 03:40:19 --> Model Class Initialized
DEBUG - 2011-09-23 03:40:19 --> Model Class Initialized
DEBUG - 2011-09-23 03:40:19 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-23 03:40:20 --> Database Driver Class Initialized
DEBUG - 2011-09-23 03:40:22 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-23 03:40:22 --> Helper loaded: url_helper
DEBUG - 2011-09-23 03:40:22 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-23 03:40:22 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-23 03:40:22 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-23 03:40:22 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-23 03:40:22 --> Final output sent to browser
DEBUG - 2011-09-23 03:40:22 --> Total execution time: 2.2052
DEBUG - 2011-09-23 03:40:22 --> Config Class Initialized
DEBUG - 2011-09-23 03:40:22 --> Hooks Class Initialized
DEBUG - 2011-09-23 03:40:22 --> Utf8 Class Initialized
DEBUG - 2011-09-23 03:40:22 --> UTF-8 Support Enabled
DEBUG - 2011-09-23 03:40:22 --> URI Class Initialized
DEBUG - 2011-09-23 03:40:22 --> Router Class Initialized
ERROR - 2011-09-23 03:40:22 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-23 03:40:43 --> Config Class Initialized
DEBUG - 2011-09-23 03:40:43 --> Hooks Class Initialized
DEBUG - 2011-09-23 03:40:43 --> Utf8 Class Initialized
DEBUG - 2011-09-23 03:40:43 --> UTF-8 Support Enabled
DEBUG - 2011-09-23 03:40:43 --> URI Class Initialized
DEBUG - 2011-09-23 03:40:43 --> Router Class Initialized
DEBUG - 2011-09-23 03:40:43 --> Output Class Initialized
DEBUG - 2011-09-23 03:40:43 --> Input Class Initialized
DEBUG - 2011-09-23 03:40:43 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-23 03:40:43 --> Language Class Initialized
DEBUG - 2011-09-23 03:40:43 --> Loader Class Initialized
DEBUG - 2011-09-23 03:40:43 --> Controller Class Initialized
ERROR - 2011-09-23 03:40:43 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-23 03:40:43 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-23 03:40:43 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-23 03:40:43 --> Model Class Initialized
DEBUG - 2011-09-23 03:40:43 --> Model Class Initialized
DEBUG - 2011-09-23 03:40:43 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-23 03:40:43 --> Database Driver Class Initialized
DEBUG - 2011-09-23 03:40:43 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-23 03:40:43 --> Helper loaded: url_helper
DEBUG - 2011-09-23 03:40:43 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-23 03:40:43 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-23 03:40:43 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-23 03:40:43 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-23 03:40:43 --> Final output sent to browser
DEBUG - 2011-09-23 03:40:43 --> Total execution time: 0.0721
DEBUG - 2011-09-23 03:40:44 --> Config Class Initialized
DEBUG - 2011-09-23 03:40:44 --> Hooks Class Initialized
DEBUG - 2011-09-23 03:40:44 --> Utf8 Class Initialized
DEBUG - 2011-09-23 03:40:44 --> UTF-8 Support Enabled
DEBUG - 2011-09-23 03:40:44 --> URI Class Initialized
DEBUG - 2011-09-23 03:40:44 --> Router Class Initialized
DEBUG - 2011-09-23 03:40:44 --> Output Class Initialized
DEBUG - 2011-09-23 03:40:44 --> Input Class Initialized
DEBUG - 2011-09-23 03:40:44 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-23 03:40:44 --> Language Class Initialized
DEBUG - 2011-09-23 03:40:44 --> Loader Class Initialized
DEBUG - 2011-09-23 03:40:44 --> Controller Class Initialized
DEBUG - 2011-09-23 03:40:44 --> Model Class Initialized
DEBUG - 2011-09-23 03:40:44 --> Model Class Initialized
DEBUG - 2011-09-23 03:40:44 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-23 03:40:44 --> Database Driver Class Initialized
DEBUG - 2011-09-23 03:40:44 --> Final output sent to browser
DEBUG - 2011-09-23 03:40:44 --> Total execution time: 0.9009
DEBUG - 2011-09-23 04:50:40 --> Config Class Initialized
DEBUG - 2011-09-23 04:50:40 --> Hooks Class Initialized
DEBUG - 2011-09-23 04:50:40 --> Utf8 Class Initialized
DEBUG - 2011-09-23 04:50:40 --> UTF-8 Support Enabled
DEBUG - 2011-09-23 04:50:40 --> URI Class Initialized
DEBUG - 2011-09-23 04:50:40 --> Router Class Initialized
DEBUG - 2011-09-23 04:50:40 --> Output Class Initialized
DEBUG - 2011-09-23 04:50:40 --> Input Class Initialized
DEBUG - 2011-09-23 04:50:40 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-23 04:50:40 --> Language Class Initialized
DEBUG - 2011-09-23 04:50:40 --> Loader Class Initialized
DEBUG - 2011-09-23 04:50:40 --> Controller Class Initialized
DEBUG - 2011-09-23 04:50:40 --> Model Class Initialized
DEBUG - 2011-09-23 04:50:40 --> Model Class Initialized
DEBUG - 2011-09-23 04:50:40 --> Model Class Initialized
DEBUG - 2011-09-23 04:50:40 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-23 04:50:40 --> Database Driver Class Initialized
DEBUG - 2011-09-23 04:50:55 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-23 04:50:55 --> Helper loaded: url_helper
DEBUG - 2011-09-23 04:50:55 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-23 04:50:55 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-23 04:50:55 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-23 04:50:55 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-23 04:50:55 --> Final output sent to browser
DEBUG - 2011-09-23 04:50:55 --> Total execution time: 15.2752
DEBUG - 2011-09-23 04:50:57 --> Config Class Initialized
DEBUG - 2011-09-23 04:50:57 --> Hooks Class Initialized
DEBUG - 2011-09-23 04:50:57 --> Utf8 Class Initialized
DEBUG - 2011-09-23 04:50:57 --> UTF-8 Support Enabled
DEBUG - 2011-09-23 04:50:57 --> URI Class Initialized
DEBUG - 2011-09-23 04:50:57 --> Router Class Initialized
DEBUG - 2011-09-23 04:50:57 --> Output Class Initialized
DEBUG - 2011-09-23 04:50:57 --> Input Class Initialized
DEBUG - 2011-09-23 04:50:57 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-23 04:50:57 --> Language Class Initialized
DEBUG - 2011-09-23 04:50:57 --> Loader Class Initialized
DEBUG - 2011-09-23 04:50:57 --> Controller Class Initialized
ERROR - 2011-09-23 04:50:57 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-23 04:50:57 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-23 04:50:57 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-23 04:50:57 --> Model Class Initialized
DEBUG - 2011-09-23 04:50:57 --> Model Class Initialized
DEBUG - 2011-09-23 04:50:57 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-23 04:50:57 --> Database Driver Class Initialized
DEBUG - 2011-09-23 04:50:57 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-23 04:50:57 --> Helper loaded: url_helper
DEBUG - 2011-09-23 04:50:57 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-23 04:50:57 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-23 04:50:57 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-23 04:50:57 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-23 04:50:57 --> Final output sent to browser
DEBUG - 2011-09-23 04:50:57 --> Total execution time: 0.4026
DEBUG - 2011-09-23 05:38:43 --> Config Class Initialized
DEBUG - 2011-09-23 05:38:43 --> Hooks Class Initialized
DEBUG - 2011-09-23 05:38:43 --> Utf8 Class Initialized
DEBUG - 2011-09-23 05:38:43 --> UTF-8 Support Enabled
DEBUG - 2011-09-23 05:38:43 --> URI Class Initialized
DEBUG - 2011-09-23 05:38:43 --> Router Class Initialized
DEBUG - 2011-09-23 05:38:43 --> Output Class Initialized
DEBUG - 2011-09-23 05:38:43 --> Input Class Initialized
DEBUG - 2011-09-23 05:38:43 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-23 05:38:43 --> Language Class Initialized
DEBUG - 2011-09-23 05:38:43 --> Loader Class Initialized
DEBUG - 2011-09-23 05:38:43 --> Controller Class Initialized
ERROR - 2011-09-23 05:38:43 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-23 05:38:43 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-23 05:38:43 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-23 05:38:43 --> Model Class Initialized
DEBUG - 2011-09-23 05:38:43 --> Model Class Initialized
DEBUG - 2011-09-23 05:38:43 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-23 05:38:43 --> Database Driver Class Initialized
DEBUG - 2011-09-23 05:38:44 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-23 05:38:44 --> Helper loaded: url_helper
DEBUG - 2011-09-23 05:38:44 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-23 05:38:44 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-23 05:38:44 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-23 05:38:44 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-23 05:38:44 --> Final output sent to browser
DEBUG - 2011-09-23 05:38:44 --> Total execution time: 0.8359
DEBUG - 2011-09-23 05:38:47 --> Config Class Initialized
DEBUG - 2011-09-23 05:38:47 --> Hooks Class Initialized
DEBUG - 2011-09-23 05:38:47 --> Utf8 Class Initialized
DEBUG - 2011-09-23 05:38:47 --> UTF-8 Support Enabled
DEBUG - 2011-09-23 05:38:47 --> URI Class Initialized
DEBUG - 2011-09-23 05:38:47 --> Router Class Initialized
DEBUG - 2011-09-23 05:38:47 --> Output Class Initialized
DEBUG - 2011-09-23 05:38:47 --> Input Class Initialized
DEBUG - 2011-09-23 05:38:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-23 05:38:47 --> Language Class Initialized
DEBUG - 2011-09-23 05:38:47 --> Loader Class Initialized
DEBUG - 2011-09-23 05:38:47 --> Controller Class Initialized
DEBUG - 2011-09-23 05:38:47 --> Model Class Initialized
DEBUG - 2011-09-23 05:38:47 --> Model Class Initialized
DEBUG - 2011-09-23 05:38:47 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-23 05:38:47 --> Database Driver Class Initialized
DEBUG - 2011-09-23 05:38:48 --> Final output sent to browser
DEBUG - 2011-09-23 05:38:48 --> Total execution time: 1.3897
DEBUG - 2011-09-23 05:38:49 --> Config Class Initialized
DEBUG - 2011-09-23 05:38:49 --> Hooks Class Initialized
DEBUG - 2011-09-23 05:38:49 --> Utf8 Class Initialized
DEBUG - 2011-09-23 05:38:49 --> UTF-8 Support Enabled
DEBUG - 2011-09-23 05:38:49 --> URI Class Initialized
DEBUG - 2011-09-23 05:38:49 --> Router Class Initialized
ERROR - 2011-09-23 05:38:49 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-23 05:38:52 --> Config Class Initialized
DEBUG - 2011-09-23 05:38:52 --> Hooks Class Initialized
DEBUG - 2011-09-23 05:38:52 --> Utf8 Class Initialized
DEBUG - 2011-09-23 05:38:52 --> UTF-8 Support Enabled
DEBUG - 2011-09-23 05:38:52 --> URI Class Initialized
DEBUG - 2011-09-23 05:38:52 --> Router Class Initialized
DEBUG - 2011-09-23 05:38:52 --> Output Class Initialized
DEBUG - 2011-09-23 05:38:52 --> Input Class Initialized
DEBUG - 2011-09-23 05:38:52 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-23 05:38:52 --> Language Class Initialized
DEBUG - 2011-09-23 05:38:52 --> Loader Class Initialized
DEBUG - 2011-09-23 05:38:52 --> Controller Class Initialized
ERROR - 2011-09-23 05:38:52 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-23 05:38:52 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-23 05:38:52 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-23 05:38:52 --> Model Class Initialized
DEBUG - 2011-09-23 05:38:52 --> Model Class Initialized
DEBUG - 2011-09-23 05:38:52 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-23 05:38:52 --> Database Driver Class Initialized
DEBUG - 2011-09-23 05:38:52 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-23 05:38:52 --> Helper loaded: url_helper
DEBUG - 2011-09-23 05:38:52 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-23 05:38:52 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-23 05:38:52 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-23 05:38:52 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-23 05:38:52 --> Final output sent to browser
DEBUG - 2011-09-23 05:38:52 --> Total execution time: 0.0344
DEBUG - 2011-09-23 05:38:53 --> Config Class Initialized
DEBUG - 2011-09-23 05:38:53 --> Hooks Class Initialized
DEBUG - 2011-09-23 05:38:53 --> Utf8 Class Initialized
DEBUG - 2011-09-23 05:38:53 --> UTF-8 Support Enabled
DEBUG - 2011-09-23 05:38:53 --> URI Class Initialized
DEBUG - 2011-09-23 05:38:53 --> Router Class Initialized
DEBUG - 2011-09-23 05:38:53 --> Output Class Initialized
DEBUG - 2011-09-23 05:38:53 --> Input Class Initialized
DEBUG - 2011-09-23 05:38:53 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-23 05:38:53 --> Language Class Initialized
DEBUG - 2011-09-23 05:38:53 --> Loader Class Initialized
DEBUG - 2011-09-23 05:38:53 --> Controller Class Initialized
DEBUG - 2011-09-23 05:38:53 --> Model Class Initialized
DEBUG - 2011-09-23 05:38:53 --> Model Class Initialized
DEBUG - 2011-09-23 05:38:53 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-23 05:38:53 --> Database Driver Class Initialized
DEBUG - 2011-09-23 05:38:54 --> Final output sent to browser
DEBUG - 2011-09-23 05:38:54 --> Total execution time: 0.9256
DEBUG - 2011-09-23 05:38:57 --> Config Class Initialized
DEBUG - 2011-09-23 05:38:57 --> Hooks Class Initialized
DEBUG - 2011-09-23 05:38:57 --> Utf8 Class Initialized
DEBUG - 2011-09-23 05:38:57 --> UTF-8 Support Enabled
DEBUG - 2011-09-23 05:38:57 --> URI Class Initialized
DEBUG - 2011-09-23 05:38:57 --> Router Class Initialized
ERROR - 2011-09-23 05:38:57 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-23 06:04:59 --> Config Class Initialized
DEBUG - 2011-09-23 06:04:59 --> Hooks Class Initialized
DEBUG - 2011-09-23 06:05:00 --> Utf8 Class Initialized
DEBUG - 2011-09-23 06:05:00 --> UTF-8 Support Enabled
DEBUG - 2011-09-23 06:05:00 --> URI Class Initialized
DEBUG - 2011-09-23 06:05:00 --> Router Class Initialized
ERROR - 2011-09-23 06:05:00 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-23 06:05:00 --> Config Class Initialized
DEBUG - 2011-09-23 06:05:00 --> Hooks Class Initialized
DEBUG - 2011-09-23 06:05:00 --> Utf8 Class Initialized
DEBUG - 2011-09-23 06:05:00 --> UTF-8 Support Enabled
DEBUG - 2011-09-23 06:05:00 --> URI Class Initialized
DEBUG - 2011-09-23 06:05:00 --> Router Class Initialized
ERROR - 2011-09-23 06:05:00 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-23 06:05:06 --> Config Class Initialized
DEBUG - 2011-09-23 06:05:06 --> Hooks Class Initialized
DEBUG - 2011-09-23 06:05:06 --> Utf8 Class Initialized
DEBUG - 2011-09-23 06:05:06 --> UTF-8 Support Enabled
DEBUG - 2011-09-23 06:05:06 --> URI Class Initialized
DEBUG - 2011-09-23 06:05:06 --> Router Class Initialized
DEBUG - 2011-09-23 06:05:06 --> Output Class Initialized
DEBUG - 2011-09-23 06:05:06 --> Input Class Initialized
DEBUG - 2011-09-23 06:05:06 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-23 06:05:06 --> Language Class Initialized
DEBUG - 2011-09-23 06:05:06 --> Loader Class Initialized
DEBUG - 2011-09-23 06:05:06 --> Controller Class Initialized
DEBUG - 2011-09-23 06:05:06 --> Model Class Initialized
DEBUG - 2011-09-23 06:05:06 --> Model Class Initialized
DEBUG - 2011-09-23 06:05:06 --> Model Class Initialized
DEBUG - 2011-09-23 06:05:06 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-23 06:05:06 --> Database Driver Class Initialized
DEBUG - 2011-09-23 06:05:08 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-23 06:05:08 --> Helper loaded: url_helper
DEBUG - 2011-09-23 06:05:08 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-23 06:05:08 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-23 06:05:08 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-23 06:05:08 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-23 06:05:08 --> Final output sent to browser
DEBUG - 2011-09-23 06:05:08 --> Total execution time: 2.6305
DEBUG - 2011-09-23 06:05:09 --> Config Class Initialized
DEBUG - 2011-09-23 06:05:09 --> Hooks Class Initialized
DEBUG - 2011-09-23 06:05:09 --> Utf8 Class Initialized
DEBUG - 2011-09-23 06:05:09 --> UTF-8 Support Enabled
DEBUG - 2011-09-23 06:05:09 --> URI Class Initialized
DEBUG - 2011-09-23 06:05:09 --> Router Class Initialized
DEBUG - 2011-09-23 06:05:09 --> Output Class Initialized
DEBUG - 2011-09-23 06:05:09 --> Input Class Initialized
DEBUG - 2011-09-23 06:05:09 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-23 06:05:09 --> Language Class Initialized
DEBUG - 2011-09-23 06:05:09 --> Loader Class Initialized
DEBUG - 2011-09-23 06:05:09 --> Controller Class Initialized
DEBUG - 2011-09-23 06:05:09 --> Model Class Initialized
DEBUG - 2011-09-23 06:05:09 --> Model Class Initialized
DEBUG - 2011-09-23 06:05:09 --> Model Class Initialized
DEBUG - 2011-09-23 06:05:09 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-23 06:05:09 --> Database Driver Class Initialized
DEBUG - 2011-09-23 06:05:09 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-23 06:05:09 --> Helper loaded: url_helper
DEBUG - 2011-09-23 06:05:09 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-23 06:05:09 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-23 06:05:09 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-23 06:05:09 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-23 06:05:09 --> Final output sent to browser
DEBUG - 2011-09-23 06:05:09 --> Total execution time: 0.4724
DEBUG - 2011-09-23 06:05:11 --> Config Class Initialized
DEBUG - 2011-09-23 06:05:11 --> Hooks Class Initialized
DEBUG - 2011-09-23 06:05:11 --> Utf8 Class Initialized
DEBUG - 2011-09-23 06:05:11 --> UTF-8 Support Enabled
DEBUG - 2011-09-23 06:05:11 --> URI Class Initialized
DEBUG - 2011-09-23 06:05:11 --> Router Class Initialized
ERROR - 2011-09-23 06:05:11 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-23 06:24:47 --> Config Class Initialized
DEBUG - 2011-09-23 06:24:47 --> Hooks Class Initialized
DEBUG - 2011-09-23 06:24:47 --> Utf8 Class Initialized
DEBUG - 2011-09-23 06:24:47 --> UTF-8 Support Enabled
DEBUG - 2011-09-23 06:24:47 --> URI Class Initialized
DEBUG - 2011-09-23 06:24:47 --> Router Class Initialized
DEBUG - 2011-09-23 06:24:47 --> Output Class Initialized
DEBUG - 2011-09-23 06:24:47 --> Input Class Initialized
DEBUG - 2011-09-23 06:24:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-23 06:24:47 --> Language Class Initialized
DEBUG - 2011-09-23 06:24:47 --> Loader Class Initialized
DEBUG - 2011-09-23 06:24:47 --> Controller Class Initialized
ERROR - 2011-09-23 06:24:47 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-23 06:24:47 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-23 06:24:47 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-23 06:24:47 --> Model Class Initialized
DEBUG - 2011-09-23 06:24:47 --> Model Class Initialized
DEBUG - 2011-09-23 06:24:47 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-23 06:24:47 --> Database Driver Class Initialized
DEBUG - 2011-09-23 06:24:47 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-23 06:24:48 --> Helper loaded: url_helper
DEBUG - 2011-09-23 06:24:48 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-23 06:24:48 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-23 06:24:48 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-23 06:24:48 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-23 06:24:48 --> Final output sent to browser
DEBUG - 2011-09-23 06:24:48 --> Total execution time: 0.1373
DEBUG - 2011-09-23 06:24:50 --> Config Class Initialized
DEBUG - 2011-09-23 06:24:50 --> Hooks Class Initialized
DEBUG - 2011-09-23 06:24:50 --> Utf8 Class Initialized
DEBUG - 2011-09-23 06:24:50 --> UTF-8 Support Enabled
DEBUG - 2011-09-23 06:24:50 --> URI Class Initialized
DEBUG - 2011-09-23 06:24:50 --> Router Class Initialized
DEBUG - 2011-09-23 06:24:50 --> Output Class Initialized
DEBUG - 2011-09-23 06:24:50 --> Input Class Initialized
DEBUG - 2011-09-23 06:24:50 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-23 06:24:50 --> Language Class Initialized
DEBUG - 2011-09-23 06:24:50 --> Loader Class Initialized
DEBUG - 2011-09-23 06:24:50 --> Controller Class Initialized
DEBUG - 2011-09-23 06:24:50 --> Model Class Initialized
DEBUG - 2011-09-23 06:24:50 --> Model Class Initialized
DEBUG - 2011-09-23 06:24:50 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-23 06:24:50 --> Database Driver Class Initialized
DEBUG - 2011-09-23 06:24:51 --> Final output sent to browser
DEBUG - 2011-09-23 06:24:51 --> Total execution time: 0.8376
DEBUG - 2011-09-23 06:24:54 --> Config Class Initialized
DEBUG - 2011-09-23 06:24:54 --> Hooks Class Initialized
DEBUG - 2011-09-23 06:24:54 --> Utf8 Class Initialized
DEBUG - 2011-09-23 06:24:54 --> UTF-8 Support Enabled
DEBUG - 2011-09-23 06:24:54 --> URI Class Initialized
DEBUG - 2011-09-23 06:24:54 --> Router Class Initialized
ERROR - 2011-09-23 06:24:54 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-23 06:25:15 --> Config Class Initialized
DEBUG - 2011-09-23 06:25:15 --> Hooks Class Initialized
DEBUG - 2011-09-23 06:25:15 --> Utf8 Class Initialized
DEBUG - 2011-09-23 06:25:15 --> UTF-8 Support Enabled
DEBUG - 2011-09-23 06:25:15 --> URI Class Initialized
DEBUG - 2011-09-23 06:25:15 --> Router Class Initialized
DEBUG - 2011-09-23 06:25:15 --> Output Class Initialized
DEBUG - 2011-09-23 06:25:15 --> Input Class Initialized
DEBUG - 2011-09-23 06:25:15 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-23 06:25:15 --> Language Class Initialized
DEBUG - 2011-09-23 06:25:15 --> Loader Class Initialized
DEBUG - 2011-09-23 06:25:15 --> Controller Class Initialized
ERROR - 2011-09-23 06:25:15 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-23 06:25:15 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-23 06:25:15 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-23 06:25:15 --> Model Class Initialized
DEBUG - 2011-09-23 06:25:15 --> Model Class Initialized
DEBUG - 2011-09-23 06:25:15 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-23 06:25:15 --> Database Driver Class Initialized
DEBUG - 2011-09-23 06:25:15 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-23 06:25:15 --> Helper loaded: url_helper
DEBUG - 2011-09-23 06:25:15 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-23 06:25:15 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-23 06:25:15 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-23 06:25:15 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-23 06:25:15 --> Final output sent to browser
DEBUG - 2011-09-23 06:25:15 --> Total execution time: 0.0413
DEBUG - 2011-09-23 06:25:16 --> Config Class Initialized
DEBUG - 2011-09-23 06:25:16 --> Hooks Class Initialized
DEBUG - 2011-09-23 06:25:16 --> Utf8 Class Initialized
DEBUG - 2011-09-23 06:25:16 --> UTF-8 Support Enabled
DEBUG - 2011-09-23 06:25:16 --> URI Class Initialized
DEBUG - 2011-09-23 06:25:16 --> Router Class Initialized
DEBUG - 2011-09-23 06:25:16 --> Output Class Initialized
DEBUG - 2011-09-23 06:25:16 --> Input Class Initialized
DEBUG - 2011-09-23 06:25:16 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-23 06:25:16 --> Language Class Initialized
DEBUG - 2011-09-23 06:25:16 --> Loader Class Initialized
DEBUG - 2011-09-23 06:25:16 --> Controller Class Initialized
DEBUG - 2011-09-23 06:25:16 --> Model Class Initialized
DEBUG - 2011-09-23 06:25:16 --> Model Class Initialized
DEBUG - 2011-09-23 06:25:16 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-23 06:25:16 --> Database Driver Class Initialized
DEBUG - 2011-09-23 06:25:17 --> Final output sent to browser
DEBUG - 2011-09-23 06:25:17 --> Total execution time: 0.6857
DEBUG - 2011-09-23 06:25:19 --> Config Class Initialized
DEBUG - 2011-09-23 06:25:19 --> Hooks Class Initialized
DEBUG - 2011-09-23 06:25:19 --> Utf8 Class Initialized
DEBUG - 2011-09-23 06:25:19 --> UTF-8 Support Enabled
DEBUG - 2011-09-23 06:25:19 --> URI Class Initialized
DEBUG - 2011-09-23 06:25:19 --> Router Class Initialized
ERROR - 2011-09-23 06:25:19 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-23 06:26:10 --> Config Class Initialized
DEBUG - 2011-09-23 06:26:10 --> Hooks Class Initialized
DEBUG - 2011-09-23 06:26:10 --> Utf8 Class Initialized
DEBUG - 2011-09-23 06:26:10 --> UTF-8 Support Enabled
DEBUG - 2011-09-23 06:26:10 --> URI Class Initialized
DEBUG - 2011-09-23 06:26:10 --> Router Class Initialized
DEBUG - 2011-09-23 06:26:10 --> Output Class Initialized
DEBUG - 2011-09-23 06:26:10 --> Input Class Initialized
DEBUG - 2011-09-23 06:26:10 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-23 06:26:10 --> Language Class Initialized
DEBUG - 2011-09-23 06:26:10 --> Loader Class Initialized
DEBUG - 2011-09-23 06:26:10 --> Controller Class Initialized
ERROR - 2011-09-23 06:26:10 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-23 06:26:10 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-23 06:26:10 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-23 06:26:10 --> Model Class Initialized
DEBUG - 2011-09-23 06:26:10 --> Model Class Initialized
DEBUG - 2011-09-23 06:26:10 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-23 06:26:10 --> Database Driver Class Initialized
DEBUG - 2011-09-23 06:26:10 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-23 06:26:10 --> Helper loaded: url_helper
DEBUG - 2011-09-23 06:26:10 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-23 06:26:10 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-23 06:26:10 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-23 06:26:10 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-23 06:26:10 --> Final output sent to browser
DEBUG - 2011-09-23 06:26:10 --> Total execution time: 0.0349
DEBUG - 2011-09-23 06:26:13 --> Config Class Initialized
DEBUG - 2011-09-23 06:26:13 --> Hooks Class Initialized
DEBUG - 2011-09-23 06:26:13 --> Utf8 Class Initialized
DEBUG - 2011-09-23 06:26:13 --> UTF-8 Support Enabled
DEBUG - 2011-09-23 06:26:13 --> URI Class Initialized
DEBUG - 2011-09-23 06:26:13 --> Router Class Initialized
ERROR - 2011-09-23 06:26:13 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-23 06:29:20 --> Config Class Initialized
DEBUG - 2011-09-23 06:29:20 --> Hooks Class Initialized
DEBUG - 2011-09-23 06:29:20 --> Utf8 Class Initialized
DEBUG - 2011-09-23 06:29:20 --> UTF-8 Support Enabled
DEBUG - 2011-09-23 06:29:20 --> URI Class Initialized
DEBUG - 2011-09-23 06:29:20 --> Router Class Initialized
DEBUG - 2011-09-23 06:29:20 --> Output Class Initialized
DEBUG - 2011-09-23 06:29:20 --> Input Class Initialized
DEBUG - 2011-09-23 06:29:20 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-23 06:29:20 --> Language Class Initialized
DEBUG - 2011-09-23 06:29:20 --> Loader Class Initialized
DEBUG - 2011-09-23 06:29:20 --> Controller Class Initialized
DEBUG - 2011-09-23 06:29:20 --> Model Class Initialized
DEBUG - 2011-09-23 06:29:20 --> Model Class Initialized
DEBUG - 2011-09-23 06:29:20 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-23 06:29:20 --> Database Driver Class Initialized
DEBUG - 2011-09-23 06:29:21 --> Final output sent to browser
DEBUG - 2011-09-23 06:29:21 --> Total execution time: 0.5509
DEBUG - 2011-09-23 06:33:19 --> Config Class Initialized
DEBUG - 2011-09-23 06:33:19 --> Hooks Class Initialized
DEBUG - 2011-09-23 06:33:19 --> Utf8 Class Initialized
DEBUG - 2011-09-23 06:33:19 --> UTF-8 Support Enabled
DEBUG - 2011-09-23 06:33:19 --> URI Class Initialized
DEBUG - 2011-09-23 06:33:19 --> Router Class Initialized
DEBUG - 2011-09-23 06:33:19 --> Output Class Initialized
DEBUG - 2011-09-23 06:33:19 --> Input Class Initialized
DEBUG - 2011-09-23 06:33:19 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-23 06:33:19 --> Language Class Initialized
DEBUG - 2011-09-23 06:33:19 --> Loader Class Initialized
DEBUG - 2011-09-23 06:33:19 --> Controller Class Initialized
DEBUG - 2011-09-23 06:33:19 --> Model Class Initialized
DEBUG - 2011-09-23 06:33:19 --> Model Class Initialized
DEBUG - 2011-09-23 06:33:19 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-23 06:33:19 --> Database Driver Class Initialized
DEBUG - 2011-09-23 06:33:20 --> Final output sent to browser
DEBUG - 2011-09-23 06:33:20 --> Total execution time: 0.6761
DEBUG - 2011-09-23 07:11:53 --> Config Class Initialized
DEBUG - 2011-09-23 07:11:54 --> Hooks Class Initialized
DEBUG - 2011-09-23 07:11:54 --> Utf8 Class Initialized
DEBUG - 2011-09-23 07:11:54 --> UTF-8 Support Enabled
DEBUG - 2011-09-23 07:11:54 --> URI Class Initialized
DEBUG - 2011-09-23 07:11:54 --> Router Class Initialized
DEBUG - 2011-09-23 07:11:54 --> Output Class Initialized
DEBUG - 2011-09-23 07:11:54 --> Input Class Initialized
DEBUG - 2011-09-23 07:11:54 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-23 07:11:54 --> Language Class Initialized
DEBUG - 2011-09-23 07:11:54 --> Loader Class Initialized
DEBUG - 2011-09-23 07:11:54 --> Controller Class Initialized
DEBUG - 2011-09-23 07:11:54 --> Model Class Initialized
DEBUG - 2011-09-23 07:11:54 --> Model Class Initialized
DEBUG - 2011-09-23 07:11:54 --> Model Class Initialized
DEBUG - 2011-09-23 07:11:54 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-23 07:11:54 --> Database Driver Class Initialized
DEBUG - 2011-09-23 07:11:55 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-23 07:11:55 --> Helper loaded: url_helper
DEBUG - 2011-09-23 07:11:55 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-23 07:11:55 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-23 07:11:55 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-23 07:11:55 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-23 07:11:55 --> Final output sent to browser
DEBUG - 2011-09-23 07:11:55 --> Total execution time: 1.2492
DEBUG - 2011-09-23 07:11:57 --> Config Class Initialized
DEBUG - 2011-09-23 07:11:57 --> Hooks Class Initialized
DEBUG - 2011-09-23 07:11:57 --> Utf8 Class Initialized
DEBUG - 2011-09-23 07:11:57 --> UTF-8 Support Enabled
DEBUG - 2011-09-23 07:11:57 --> URI Class Initialized
DEBUG - 2011-09-23 07:11:57 --> Router Class Initialized
ERROR - 2011-09-23 07:11:57 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-23 07:11:57 --> Config Class Initialized
DEBUG - 2011-09-23 07:11:57 --> Hooks Class Initialized
DEBUG - 2011-09-23 07:11:57 --> Utf8 Class Initialized
DEBUG - 2011-09-23 07:11:57 --> UTF-8 Support Enabled
DEBUG - 2011-09-23 07:11:57 --> URI Class Initialized
DEBUG - 2011-09-23 07:11:57 --> Router Class Initialized
ERROR - 2011-09-23 07:11:57 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-23 07:19:42 --> Config Class Initialized
DEBUG - 2011-09-23 07:19:42 --> Hooks Class Initialized
DEBUG - 2011-09-23 07:19:42 --> Utf8 Class Initialized
DEBUG - 2011-09-23 07:19:42 --> UTF-8 Support Enabled
DEBUG - 2011-09-23 07:19:42 --> URI Class Initialized
DEBUG - 2011-09-23 07:19:42 --> Router Class Initialized
DEBUG - 2011-09-23 07:19:42 --> No URI present. Default controller set.
DEBUG - 2011-09-23 07:19:42 --> Output Class Initialized
DEBUG - 2011-09-23 07:19:42 --> Input Class Initialized
DEBUG - 2011-09-23 07:19:42 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-23 07:19:42 --> Language Class Initialized
DEBUG - 2011-09-23 07:19:42 --> Loader Class Initialized
DEBUG - 2011-09-23 07:19:42 --> Controller Class Initialized
DEBUG - 2011-09-23 07:19:42 --> File loaded: application/views/splash/main.php
DEBUG - 2011-09-23 07:19:42 --> Helper loaded: url_helper
DEBUG - 2011-09-23 07:19:42 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-23 07:19:42 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-23 07:19:42 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-23 07:19:42 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-23 07:19:42 --> Final output sent to browser
DEBUG - 2011-09-23 07:19:42 --> Total execution time: 0.0833
DEBUG - 2011-09-23 07:27:51 --> Config Class Initialized
DEBUG - 2011-09-23 07:27:51 --> Hooks Class Initialized
DEBUG - 2011-09-23 07:27:51 --> Utf8 Class Initialized
DEBUG - 2011-09-23 07:27:51 --> UTF-8 Support Enabled
DEBUG - 2011-09-23 07:27:51 --> URI Class Initialized
DEBUG - 2011-09-23 07:27:51 --> Router Class Initialized
ERROR - 2011-09-23 07:27:51 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-09-23 07:27:51 --> Config Class Initialized
DEBUG - 2011-09-23 07:27:51 --> Hooks Class Initialized
DEBUG - 2011-09-23 07:27:51 --> Utf8 Class Initialized
DEBUG - 2011-09-23 07:27:51 --> UTF-8 Support Enabled
DEBUG - 2011-09-23 07:27:51 --> URI Class Initialized
DEBUG - 2011-09-23 07:27:51 --> Router Class Initialized
DEBUG - 2011-09-23 07:27:51 --> Output Class Initialized
DEBUG - 2011-09-23 07:27:51 --> Input Class Initialized
DEBUG - 2011-09-23 07:27:51 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-23 07:27:51 --> Language Class Initialized
DEBUG - 2011-09-23 07:27:51 --> Loader Class Initialized
DEBUG - 2011-09-23 07:27:51 --> Controller Class Initialized
DEBUG - 2011-09-23 07:27:51 --> Model Class Initialized
DEBUG - 2011-09-23 07:27:51 --> Model Class Initialized
DEBUG - 2011-09-23 07:27:51 --> Model Class Initialized
DEBUG - 2011-09-23 07:27:51 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-23 07:27:51 --> Database Driver Class Initialized
DEBUG - 2011-09-23 07:27:52 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-23 07:27:52 --> Helper loaded: url_helper
DEBUG - 2011-09-23 07:27:52 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-23 07:27:52 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-23 07:27:52 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-23 07:27:52 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-23 07:27:52 --> Final output sent to browser
DEBUG - 2011-09-23 07:27:52 --> Total execution time: 0.0792
DEBUG - 2011-09-23 07:45:25 --> Config Class Initialized
DEBUG - 2011-09-23 07:45:25 --> Hooks Class Initialized
DEBUG - 2011-09-23 07:45:25 --> Utf8 Class Initialized
DEBUG - 2011-09-23 07:45:25 --> UTF-8 Support Enabled
DEBUG - 2011-09-23 07:45:25 --> URI Class Initialized
DEBUG - 2011-09-23 07:45:25 --> Router Class Initialized
DEBUG - 2011-09-23 07:45:25 --> Output Class Initialized
DEBUG - 2011-09-23 07:45:25 --> Input Class Initialized
DEBUG - 2011-09-23 07:45:25 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-23 07:45:25 --> Language Class Initialized
DEBUG - 2011-09-23 07:45:25 --> Loader Class Initialized
DEBUG - 2011-09-23 07:45:25 --> Controller Class Initialized
DEBUG - 2011-09-23 07:45:25 --> Model Class Initialized
DEBUG - 2011-09-23 07:45:25 --> Model Class Initialized
DEBUG - 2011-09-23 07:45:25 --> Model Class Initialized
DEBUG - 2011-09-23 07:45:25 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-23 07:45:25 --> Database Driver Class Initialized
DEBUG - 2011-09-23 07:45:26 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-23 07:45:26 --> Helper loaded: url_helper
DEBUG - 2011-09-23 07:45:26 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-23 07:45:26 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-23 07:45:26 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-23 07:45:26 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-23 07:45:26 --> Final output sent to browser
DEBUG - 2011-09-23 07:45:26 --> Total execution time: 1.0696
DEBUG - 2011-09-23 07:45:28 --> Config Class Initialized
DEBUG - 2011-09-23 07:45:28 --> Hooks Class Initialized
DEBUG - 2011-09-23 07:45:28 --> Utf8 Class Initialized
DEBUG - 2011-09-23 07:45:28 --> UTF-8 Support Enabled
DEBUG - 2011-09-23 07:45:28 --> URI Class Initialized
DEBUG - 2011-09-23 07:45:28 --> Router Class Initialized
DEBUG - 2011-09-23 07:45:28 --> Output Class Initialized
DEBUG - 2011-09-23 07:45:28 --> Input Class Initialized
DEBUG - 2011-09-23 07:45:28 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-23 07:45:28 --> Language Class Initialized
DEBUG - 2011-09-23 07:45:28 --> Loader Class Initialized
DEBUG - 2011-09-23 07:45:28 --> Controller Class Initialized
ERROR - 2011-09-23 07:45:28 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-23 07:45:28 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-23 07:45:28 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-23 07:45:28 --> Model Class Initialized
DEBUG - 2011-09-23 07:45:28 --> Model Class Initialized
DEBUG - 2011-09-23 07:45:28 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-23 07:45:29 --> Database Driver Class Initialized
DEBUG - 2011-09-23 07:45:29 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-23 07:45:29 --> Helper loaded: url_helper
DEBUG - 2011-09-23 07:45:29 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-23 07:45:29 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-23 07:45:29 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-23 07:45:29 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-23 07:45:29 --> Final output sent to browser
DEBUG - 2011-09-23 07:45:29 --> Total execution time: 0.0936
DEBUG - 2011-09-23 07:45:29 --> Config Class Initialized
DEBUG - 2011-09-23 07:45:29 --> Hooks Class Initialized
DEBUG - 2011-09-23 07:45:29 --> Utf8 Class Initialized
DEBUG - 2011-09-23 07:45:29 --> UTF-8 Support Enabled
DEBUG - 2011-09-23 07:45:29 --> URI Class Initialized
DEBUG - 2011-09-23 07:45:29 --> Router Class Initialized
DEBUG - 2011-09-23 07:45:29 --> Output Class Initialized
DEBUG - 2011-09-23 07:45:29 --> Input Class Initialized
DEBUG - 2011-09-23 07:45:29 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-23 07:45:29 --> Language Class Initialized
DEBUG - 2011-09-23 07:45:29 --> Loader Class Initialized
DEBUG - 2011-09-23 07:45:29 --> Controller Class Initialized
DEBUG - 2011-09-23 07:45:30 --> Model Class Initialized
DEBUG - 2011-09-23 07:45:30 --> Model Class Initialized
DEBUG - 2011-09-23 07:45:30 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-23 07:45:30 --> Database Driver Class Initialized
DEBUG - 2011-09-23 07:45:30 --> Final output sent to browser
DEBUG - 2011-09-23 07:45:30 --> Total execution time: 0.9077
DEBUG - 2011-09-23 07:45:35 --> Config Class Initialized
DEBUG - 2011-09-23 07:45:35 --> Hooks Class Initialized
DEBUG - 2011-09-23 07:45:35 --> Utf8 Class Initialized
DEBUG - 2011-09-23 07:45:35 --> UTF-8 Support Enabled
DEBUG - 2011-09-23 07:45:35 --> URI Class Initialized
DEBUG - 2011-09-23 07:45:35 --> Router Class Initialized
ERROR - 2011-09-23 07:45:35 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-23 07:45:35 --> Config Class Initialized
DEBUG - 2011-09-23 07:45:35 --> Hooks Class Initialized
DEBUG - 2011-09-23 07:45:35 --> Utf8 Class Initialized
DEBUG - 2011-09-23 07:45:35 --> UTF-8 Support Enabled
DEBUG - 2011-09-23 07:45:35 --> URI Class Initialized
DEBUG - 2011-09-23 07:45:35 --> Router Class Initialized
ERROR - 2011-09-23 07:45:35 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-23 07:46:04 --> Config Class Initialized
DEBUG - 2011-09-23 07:46:04 --> Hooks Class Initialized
DEBUG - 2011-09-23 07:46:04 --> Utf8 Class Initialized
DEBUG - 2011-09-23 07:46:04 --> UTF-8 Support Enabled
DEBUG - 2011-09-23 07:46:04 --> URI Class Initialized
DEBUG - 2011-09-23 07:46:04 --> Router Class Initialized
DEBUG - 2011-09-23 07:46:04 --> Output Class Initialized
DEBUG - 2011-09-23 07:46:04 --> Input Class Initialized
DEBUG - 2011-09-23 07:46:04 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-23 07:46:04 --> Language Class Initialized
DEBUG - 2011-09-23 07:46:04 --> Loader Class Initialized
DEBUG - 2011-09-23 07:46:04 --> Controller Class Initialized
DEBUG - 2011-09-23 07:46:04 --> Model Class Initialized
DEBUG - 2011-09-23 07:46:04 --> Model Class Initialized
DEBUG - 2011-09-23 07:46:04 --> Model Class Initialized
DEBUG - 2011-09-23 07:46:04 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-23 07:46:04 --> Database Driver Class Initialized
DEBUG - 2011-09-23 07:46:05 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-23 07:46:05 --> Helper loaded: url_helper
DEBUG - 2011-09-23 07:46:05 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-23 07:46:05 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-23 07:46:05 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-23 07:46:05 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-23 07:46:05 --> Final output sent to browser
DEBUG - 2011-09-23 07:46:05 --> Total execution time: 1.3564
DEBUG - 2011-09-23 07:46:38 --> Config Class Initialized
DEBUG - 2011-09-23 07:46:38 --> Hooks Class Initialized
DEBUG - 2011-09-23 07:46:38 --> Utf8 Class Initialized
DEBUG - 2011-09-23 07:46:38 --> UTF-8 Support Enabled
DEBUG - 2011-09-23 07:46:38 --> URI Class Initialized
DEBUG - 2011-09-23 07:46:38 --> Router Class Initialized
DEBUG - 2011-09-23 07:46:38 --> Output Class Initialized
DEBUG - 2011-09-23 07:46:38 --> Input Class Initialized
DEBUG - 2011-09-23 07:46:38 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-23 07:46:38 --> Language Class Initialized
DEBUG - 2011-09-23 07:46:38 --> Loader Class Initialized
DEBUG - 2011-09-23 07:46:38 --> Controller Class Initialized
ERROR - 2011-09-23 07:46:38 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-23 07:46:38 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-23 07:46:38 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-23 07:46:38 --> Model Class Initialized
DEBUG - 2011-09-23 07:46:38 --> Model Class Initialized
DEBUG - 2011-09-23 07:46:38 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-23 07:46:38 --> Database Driver Class Initialized
DEBUG - 2011-09-23 07:46:38 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-23 07:46:38 --> Helper loaded: url_helper
DEBUG - 2011-09-23 07:46:38 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-23 07:46:38 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-23 07:46:38 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-23 07:46:38 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-23 07:46:38 --> Final output sent to browser
DEBUG - 2011-09-23 07:46:38 --> Total execution time: 0.0300
DEBUG - 2011-09-23 07:46:40 --> Config Class Initialized
DEBUG - 2011-09-23 07:46:40 --> Hooks Class Initialized
DEBUG - 2011-09-23 07:46:40 --> Utf8 Class Initialized
DEBUG - 2011-09-23 07:46:40 --> UTF-8 Support Enabled
DEBUG - 2011-09-23 07:46:40 --> URI Class Initialized
DEBUG - 2011-09-23 07:46:40 --> Router Class Initialized
DEBUG - 2011-09-23 07:46:40 --> Output Class Initialized
DEBUG - 2011-09-23 07:46:40 --> Input Class Initialized
DEBUG - 2011-09-23 07:46:40 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-23 07:46:40 --> Language Class Initialized
DEBUG - 2011-09-23 07:46:40 --> Loader Class Initialized
DEBUG - 2011-09-23 07:46:40 --> Controller Class Initialized
DEBUG - 2011-09-23 07:46:40 --> Model Class Initialized
DEBUG - 2011-09-23 07:46:40 --> Model Class Initialized
DEBUG - 2011-09-23 07:46:40 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-23 07:46:40 --> Database Driver Class Initialized
DEBUG - 2011-09-23 07:46:40 --> Final output sent to browser
DEBUG - 2011-09-23 07:46:40 --> Total execution time: 0.5835
DEBUG - 2011-09-23 07:46:46 --> Config Class Initialized
DEBUG - 2011-09-23 07:46:46 --> Hooks Class Initialized
DEBUG - 2011-09-23 07:46:46 --> Utf8 Class Initialized
DEBUG - 2011-09-23 07:46:46 --> UTF-8 Support Enabled
DEBUG - 2011-09-23 07:46:46 --> URI Class Initialized
DEBUG - 2011-09-23 07:46:46 --> Router Class Initialized
DEBUG - 2011-09-23 07:46:46 --> Output Class Initialized
DEBUG - 2011-09-23 07:46:46 --> Input Class Initialized
DEBUG - 2011-09-23 07:46:46 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-23 07:46:46 --> Language Class Initialized
DEBUG - 2011-09-23 07:46:46 --> Loader Class Initialized
DEBUG - 2011-09-23 07:46:46 --> Controller Class Initialized
ERROR - 2011-09-23 07:46:46 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-23 07:46:46 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-23 07:46:46 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-23 07:46:46 --> Model Class Initialized
DEBUG - 2011-09-23 07:46:46 --> Model Class Initialized
DEBUG - 2011-09-23 07:46:46 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-23 07:46:46 --> Database Driver Class Initialized
DEBUG - 2011-09-23 07:46:46 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-23 07:46:46 --> Helper loaded: url_helper
DEBUG - 2011-09-23 07:46:46 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-23 07:46:46 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-23 07:46:46 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-23 07:46:46 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-23 07:46:46 --> Final output sent to browser
DEBUG - 2011-09-23 07:46:46 --> Total execution time: 0.0299
DEBUG - 2011-09-23 07:46:49 --> Config Class Initialized
DEBUG - 2011-09-23 07:46:49 --> Hooks Class Initialized
DEBUG - 2011-09-23 07:46:49 --> Utf8 Class Initialized
DEBUG - 2011-09-23 07:46:49 --> UTF-8 Support Enabled
DEBUG - 2011-09-23 07:46:49 --> URI Class Initialized
DEBUG - 2011-09-23 07:46:49 --> Router Class Initialized
DEBUG - 2011-09-23 07:46:49 --> Output Class Initialized
DEBUG - 2011-09-23 07:46:49 --> Input Class Initialized
DEBUG - 2011-09-23 07:46:49 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-23 07:46:49 --> Language Class Initialized
DEBUG - 2011-09-23 07:46:49 --> Loader Class Initialized
DEBUG - 2011-09-23 07:46:49 --> Controller Class Initialized
DEBUG - 2011-09-23 07:46:49 --> Model Class Initialized
DEBUG - 2011-09-23 07:46:49 --> Model Class Initialized
DEBUG - 2011-09-23 07:46:49 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-23 07:46:49 --> Database Driver Class Initialized
DEBUG - 2011-09-23 07:46:49 --> Final output sent to browser
DEBUG - 2011-09-23 07:46:49 --> Total execution time: 0.6352
DEBUG - 2011-09-23 09:53:04 --> Config Class Initialized
DEBUG - 2011-09-23 09:53:04 --> Hooks Class Initialized
DEBUG - 2011-09-23 09:53:04 --> Utf8 Class Initialized
DEBUG - 2011-09-23 09:53:04 --> UTF-8 Support Enabled
DEBUG - 2011-09-23 09:53:04 --> URI Class Initialized
DEBUG - 2011-09-23 09:53:04 --> Router Class Initialized
DEBUG - 2011-09-23 09:53:04 --> Output Class Initialized
DEBUG - 2011-09-23 09:53:04 --> Input Class Initialized
DEBUG - 2011-09-23 09:53:04 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-23 09:53:04 --> Language Class Initialized
DEBUG - 2011-09-23 09:53:04 --> Loader Class Initialized
DEBUG - 2011-09-23 09:53:04 --> Controller Class Initialized
ERROR - 2011-09-23 09:53:05 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-23 09:53:05 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-23 09:53:05 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-23 09:53:05 --> Model Class Initialized
DEBUG - 2011-09-23 09:53:05 --> Model Class Initialized
DEBUG - 2011-09-23 09:53:05 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-23 09:53:05 --> Database Driver Class Initialized
DEBUG - 2011-09-23 09:53:05 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-23 09:53:05 --> Helper loaded: url_helper
DEBUG - 2011-09-23 09:53:05 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-23 09:53:05 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-23 09:53:05 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-23 09:53:05 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-23 09:53:05 --> Final output sent to browser
DEBUG - 2011-09-23 09:53:05 --> Total execution time: 0.6474
DEBUG - 2011-09-23 09:53:21 --> Config Class Initialized
DEBUG - 2011-09-23 09:53:21 --> Hooks Class Initialized
DEBUG - 2011-09-23 09:53:21 --> Utf8 Class Initialized
DEBUG - 2011-09-23 09:53:21 --> UTF-8 Support Enabled
DEBUG - 2011-09-23 09:53:21 --> URI Class Initialized
DEBUG - 2011-09-23 09:53:21 --> Router Class Initialized
DEBUG - 2011-09-23 09:53:21 --> Output Class Initialized
DEBUG - 2011-09-23 09:53:21 --> Input Class Initialized
DEBUG - 2011-09-23 09:53:21 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-23 09:53:21 --> Language Class Initialized
DEBUG - 2011-09-23 09:53:21 --> Loader Class Initialized
DEBUG - 2011-09-23 09:53:21 --> Controller Class Initialized
DEBUG - 2011-09-23 09:53:21 --> Model Class Initialized
DEBUG - 2011-09-23 09:53:21 --> Model Class Initialized
DEBUG - 2011-09-23 09:53:21 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-23 09:53:21 --> Database Driver Class Initialized
DEBUG - 2011-09-23 09:53:22 --> Final output sent to browser
DEBUG - 2011-09-23 09:53:22 --> Total execution time: 0.9728
DEBUG - 2011-09-23 09:53:35 --> Config Class Initialized
DEBUG - 2011-09-23 09:53:35 --> Hooks Class Initialized
DEBUG - 2011-09-23 09:53:35 --> Utf8 Class Initialized
DEBUG - 2011-09-23 09:53:35 --> UTF-8 Support Enabled
DEBUG - 2011-09-23 09:53:35 --> URI Class Initialized
DEBUG - 2011-09-23 09:53:35 --> Router Class Initialized
ERROR - 2011-09-23 09:53:35 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-23 09:53:35 --> Config Class Initialized
DEBUG - 2011-09-23 09:53:35 --> Hooks Class Initialized
DEBUG - 2011-09-23 09:53:35 --> Utf8 Class Initialized
DEBUG - 2011-09-23 09:53:35 --> UTF-8 Support Enabled
DEBUG - 2011-09-23 09:53:35 --> URI Class Initialized
DEBUG - 2011-09-23 09:53:35 --> Router Class Initialized
ERROR - 2011-09-23 09:53:35 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-23 10:58:10 --> Config Class Initialized
DEBUG - 2011-09-23 10:58:10 --> Hooks Class Initialized
DEBUG - 2011-09-23 10:58:10 --> Utf8 Class Initialized
DEBUG - 2011-09-23 10:58:10 --> UTF-8 Support Enabled
DEBUG - 2011-09-23 10:58:10 --> URI Class Initialized
DEBUG - 2011-09-23 10:58:10 --> Router Class Initialized
DEBUG - 2011-09-23 10:58:10 --> Output Class Initialized
DEBUG - 2011-09-23 10:58:10 --> Input Class Initialized
DEBUG - 2011-09-23 10:58:10 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-23 10:58:10 --> Language Class Initialized
DEBUG - 2011-09-23 10:58:10 --> Loader Class Initialized
DEBUG - 2011-09-23 10:58:10 --> Controller Class Initialized
ERROR - 2011-09-23 10:58:10 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-23 10:58:10 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-23 10:58:10 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-23 10:58:10 --> Model Class Initialized
DEBUG - 2011-09-23 10:58:10 --> Model Class Initialized
DEBUG - 2011-09-23 10:58:10 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-23 10:58:10 --> Database Driver Class Initialized
DEBUG - 2011-09-23 10:58:11 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-23 10:58:11 --> Helper loaded: url_helper
DEBUG - 2011-09-23 10:58:11 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-23 10:58:11 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-23 10:58:11 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-23 10:58:11 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-23 10:58:11 --> Final output sent to browser
DEBUG - 2011-09-23 10:58:11 --> Total execution time: 0.4101
DEBUG - 2011-09-23 10:58:12 --> Config Class Initialized
DEBUG - 2011-09-23 10:58:12 --> Hooks Class Initialized
DEBUG - 2011-09-23 10:58:12 --> Utf8 Class Initialized
DEBUG - 2011-09-23 10:58:12 --> UTF-8 Support Enabled
DEBUG - 2011-09-23 10:58:12 --> URI Class Initialized
DEBUG - 2011-09-23 10:58:12 --> Router Class Initialized
DEBUG - 2011-09-23 10:58:12 --> Output Class Initialized
DEBUG - 2011-09-23 10:58:12 --> Input Class Initialized
DEBUG - 2011-09-23 10:58:12 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-23 10:58:12 --> Language Class Initialized
DEBUG - 2011-09-23 10:58:12 --> Loader Class Initialized
DEBUG - 2011-09-23 10:58:12 --> Controller Class Initialized
DEBUG - 2011-09-23 10:58:12 --> Model Class Initialized
DEBUG - 2011-09-23 10:58:12 --> Model Class Initialized
DEBUG - 2011-09-23 10:58:12 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-23 10:58:12 --> Database Driver Class Initialized
DEBUG - 2011-09-23 10:58:13 --> Final output sent to browser
DEBUG - 2011-09-23 10:58:13 --> Total execution time: 0.7722
DEBUG - 2011-09-23 10:58:15 --> Config Class Initialized
DEBUG - 2011-09-23 10:58:15 --> Hooks Class Initialized
DEBUG - 2011-09-23 10:58:15 --> Utf8 Class Initialized
DEBUG - 2011-09-23 10:58:15 --> UTF-8 Support Enabled
DEBUG - 2011-09-23 10:58:15 --> URI Class Initialized
DEBUG - 2011-09-23 10:58:15 --> Router Class Initialized
ERROR - 2011-09-23 10:58:15 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-23 10:58:46 --> Config Class Initialized
DEBUG - 2011-09-23 10:58:46 --> Hooks Class Initialized
DEBUG - 2011-09-23 10:58:46 --> Utf8 Class Initialized
DEBUG - 2011-09-23 10:58:46 --> UTF-8 Support Enabled
DEBUG - 2011-09-23 10:58:46 --> URI Class Initialized
DEBUG - 2011-09-23 10:58:46 --> Router Class Initialized
DEBUG - 2011-09-23 10:58:46 --> Output Class Initialized
DEBUG - 2011-09-23 10:58:46 --> Input Class Initialized
DEBUG - 2011-09-23 10:58:46 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-23 10:58:46 --> Language Class Initialized
DEBUG - 2011-09-23 10:58:46 --> Loader Class Initialized
DEBUG - 2011-09-23 10:58:46 --> Controller Class Initialized
ERROR - 2011-09-23 10:58:46 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-23 10:58:46 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-23 10:58:46 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-23 10:58:46 --> Model Class Initialized
DEBUG - 2011-09-23 10:58:46 --> Model Class Initialized
DEBUG - 2011-09-23 10:58:46 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-23 10:58:46 --> Database Driver Class Initialized
DEBUG - 2011-09-23 10:58:46 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-23 10:58:46 --> Helper loaded: url_helper
DEBUG - 2011-09-23 10:58:46 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-23 10:58:46 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-23 10:58:46 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-23 10:58:46 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-23 10:58:46 --> Final output sent to browser
DEBUG - 2011-09-23 10:58:46 --> Total execution time: 0.0380
DEBUG - 2011-09-23 10:58:48 --> Config Class Initialized
DEBUG - 2011-09-23 10:58:48 --> Hooks Class Initialized
DEBUG - 2011-09-23 10:58:48 --> Utf8 Class Initialized
DEBUG - 2011-09-23 10:58:48 --> UTF-8 Support Enabled
DEBUG - 2011-09-23 10:58:48 --> URI Class Initialized
DEBUG - 2011-09-23 10:58:48 --> Router Class Initialized
DEBUG - 2011-09-23 10:58:48 --> Output Class Initialized
DEBUG - 2011-09-23 10:58:48 --> Input Class Initialized
DEBUG - 2011-09-23 10:58:48 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-23 10:58:48 --> Language Class Initialized
DEBUG - 2011-09-23 10:58:48 --> Loader Class Initialized
DEBUG - 2011-09-23 10:58:48 --> Controller Class Initialized
DEBUG - 2011-09-23 10:58:48 --> Model Class Initialized
DEBUG - 2011-09-23 10:58:48 --> Model Class Initialized
DEBUG - 2011-09-23 10:58:48 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-23 10:58:48 --> Database Driver Class Initialized
DEBUG - 2011-09-23 10:58:48 --> Final output sent to browser
DEBUG - 2011-09-23 10:58:48 --> Total execution time: 0.5883
DEBUG - 2011-09-23 10:58:50 --> Config Class Initialized
DEBUG - 2011-09-23 10:58:50 --> Hooks Class Initialized
DEBUG - 2011-09-23 10:58:50 --> Utf8 Class Initialized
DEBUG - 2011-09-23 10:58:50 --> UTF-8 Support Enabled
DEBUG - 2011-09-23 10:58:50 --> URI Class Initialized
DEBUG - 2011-09-23 10:58:50 --> Router Class Initialized
ERROR - 2011-09-23 10:58:50 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-23 10:58:59 --> Config Class Initialized
DEBUG - 2011-09-23 10:58:59 --> Hooks Class Initialized
DEBUG - 2011-09-23 10:58:59 --> Utf8 Class Initialized
DEBUG - 2011-09-23 10:58:59 --> UTF-8 Support Enabled
DEBUG - 2011-09-23 10:58:59 --> URI Class Initialized
DEBUG - 2011-09-23 10:58:59 --> Router Class Initialized
DEBUG - 2011-09-23 10:58:59 --> Output Class Initialized
DEBUG - 2011-09-23 10:58:59 --> Input Class Initialized
DEBUG - 2011-09-23 10:58:59 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-23 10:58:59 --> Language Class Initialized
DEBUG - 2011-09-23 10:58:59 --> Loader Class Initialized
DEBUG - 2011-09-23 10:58:59 --> Controller Class Initialized
ERROR - 2011-09-23 10:58:59 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-23 10:58:59 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-23 10:58:59 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-23 10:58:59 --> Model Class Initialized
DEBUG - 2011-09-23 10:58:59 --> Model Class Initialized
DEBUG - 2011-09-23 10:58:59 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-23 10:58:59 --> Database Driver Class Initialized
DEBUG - 2011-09-23 10:58:59 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-23 10:58:59 --> Helper loaded: url_helper
DEBUG - 2011-09-23 10:58:59 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-23 10:58:59 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-23 10:58:59 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-23 10:58:59 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-23 10:58:59 --> Final output sent to browser
DEBUG - 2011-09-23 10:58:59 --> Total execution time: 0.0611
DEBUG - 2011-09-23 10:59:00 --> Config Class Initialized
DEBUG - 2011-09-23 10:59:00 --> Hooks Class Initialized
DEBUG - 2011-09-23 10:59:00 --> Utf8 Class Initialized
DEBUG - 2011-09-23 10:59:00 --> UTF-8 Support Enabled
DEBUG - 2011-09-23 10:59:00 --> URI Class Initialized
DEBUG - 2011-09-23 10:59:00 --> Router Class Initialized
DEBUG - 2011-09-23 10:59:00 --> Output Class Initialized
DEBUG - 2011-09-23 10:59:00 --> Input Class Initialized
DEBUG - 2011-09-23 10:59:00 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-23 10:59:00 --> Language Class Initialized
DEBUG - 2011-09-23 10:59:00 --> Loader Class Initialized
DEBUG - 2011-09-23 10:59:00 --> Controller Class Initialized
DEBUG - 2011-09-23 10:59:00 --> Model Class Initialized
DEBUG - 2011-09-23 10:59:00 --> Model Class Initialized
DEBUG - 2011-09-23 10:59:00 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-23 10:59:00 --> Database Driver Class Initialized
DEBUG - 2011-09-23 10:59:01 --> Final output sent to browser
DEBUG - 2011-09-23 10:59:01 --> Total execution time: 0.6157
DEBUG - 2011-09-23 10:59:02 --> Config Class Initialized
DEBUG - 2011-09-23 10:59:02 --> Hooks Class Initialized
DEBUG - 2011-09-23 10:59:02 --> Utf8 Class Initialized
DEBUG - 2011-09-23 10:59:02 --> UTF-8 Support Enabled
DEBUG - 2011-09-23 10:59:02 --> URI Class Initialized
DEBUG - 2011-09-23 10:59:02 --> Router Class Initialized
ERROR - 2011-09-23 10:59:02 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-23 10:59:27 --> Config Class Initialized
DEBUG - 2011-09-23 10:59:27 --> Hooks Class Initialized
DEBUG - 2011-09-23 10:59:27 --> Utf8 Class Initialized
DEBUG - 2011-09-23 10:59:27 --> UTF-8 Support Enabled
DEBUG - 2011-09-23 10:59:27 --> URI Class Initialized
DEBUG - 2011-09-23 10:59:27 --> Router Class Initialized
DEBUG - 2011-09-23 10:59:27 --> Output Class Initialized
DEBUG - 2011-09-23 10:59:27 --> Input Class Initialized
DEBUG - 2011-09-23 10:59:27 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-23 10:59:27 --> Language Class Initialized
DEBUG - 2011-09-23 10:59:27 --> Loader Class Initialized
DEBUG - 2011-09-23 10:59:27 --> Controller Class Initialized
ERROR - 2011-09-23 10:59:27 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-23 10:59:27 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-23 10:59:27 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-23 10:59:27 --> Model Class Initialized
DEBUG - 2011-09-23 10:59:27 --> Model Class Initialized
DEBUG - 2011-09-23 10:59:27 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-23 10:59:27 --> Database Driver Class Initialized
DEBUG - 2011-09-23 10:59:27 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-23 10:59:27 --> Helper loaded: url_helper
DEBUG - 2011-09-23 10:59:27 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-23 10:59:27 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-23 10:59:27 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-23 10:59:27 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-23 10:59:27 --> Final output sent to browser
DEBUG - 2011-09-23 10:59:27 --> Total execution time: 0.0654
DEBUG - 2011-09-23 10:59:28 --> Config Class Initialized
DEBUG - 2011-09-23 10:59:28 --> Hooks Class Initialized
DEBUG - 2011-09-23 10:59:28 --> Utf8 Class Initialized
DEBUG - 2011-09-23 10:59:28 --> UTF-8 Support Enabled
DEBUG - 2011-09-23 10:59:28 --> URI Class Initialized
DEBUG - 2011-09-23 10:59:28 --> Router Class Initialized
DEBUG - 2011-09-23 10:59:28 --> Output Class Initialized
DEBUG - 2011-09-23 10:59:28 --> Input Class Initialized
DEBUG - 2011-09-23 10:59:28 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-23 10:59:28 --> Language Class Initialized
DEBUG - 2011-09-23 10:59:28 --> Loader Class Initialized
DEBUG - 2011-09-23 10:59:28 --> Controller Class Initialized
DEBUG - 2011-09-23 10:59:28 --> Model Class Initialized
DEBUG - 2011-09-23 10:59:28 --> Model Class Initialized
DEBUG - 2011-09-23 10:59:28 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-23 10:59:28 --> Database Driver Class Initialized
DEBUG - 2011-09-23 10:59:29 --> Final output sent to browser
DEBUG - 2011-09-23 10:59:29 --> Total execution time: 0.8444
DEBUG - 2011-09-23 10:59:31 --> Config Class Initialized
DEBUG - 2011-09-23 10:59:31 --> Hooks Class Initialized
DEBUG - 2011-09-23 10:59:31 --> Utf8 Class Initialized
DEBUG - 2011-09-23 10:59:31 --> UTF-8 Support Enabled
DEBUG - 2011-09-23 10:59:31 --> URI Class Initialized
DEBUG - 2011-09-23 10:59:31 --> Router Class Initialized
ERROR - 2011-09-23 10:59:31 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-23 10:59:49 --> Config Class Initialized
DEBUG - 2011-09-23 10:59:49 --> Hooks Class Initialized
DEBUG - 2011-09-23 10:59:49 --> Utf8 Class Initialized
DEBUG - 2011-09-23 10:59:49 --> UTF-8 Support Enabled
DEBUG - 2011-09-23 10:59:49 --> URI Class Initialized
DEBUG - 2011-09-23 10:59:49 --> Router Class Initialized
DEBUG - 2011-09-23 10:59:49 --> Output Class Initialized
DEBUG - 2011-09-23 10:59:49 --> Input Class Initialized
DEBUG - 2011-09-23 10:59:49 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-23 10:59:49 --> Language Class Initialized
DEBUG - 2011-09-23 10:59:49 --> Loader Class Initialized
DEBUG - 2011-09-23 10:59:49 --> Controller Class Initialized
ERROR - 2011-09-23 10:59:49 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-23 10:59:49 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-23 10:59:49 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-23 10:59:49 --> Model Class Initialized
DEBUG - 2011-09-23 10:59:49 --> Model Class Initialized
DEBUG - 2011-09-23 10:59:49 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-23 10:59:49 --> Database Driver Class Initialized
DEBUG - 2011-09-23 10:59:49 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-23 10:59:49 --> Helper loaded: url_helper
DEBUG - 2011-09-23 10:59:49 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-23 10:59:49 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-23 10:59:49 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-23 10:59:49 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-23 10:59:49 --> Final output sent to browser
DEBUG - 2011-09-23 10:59:49 --> Total execution time: 0.0338
DEBUG - 2011-09-23 10:59:50 --> Config Class Initialized
DEBUG - 2011-09-23 10:59:50 --> Hooks Class Initialized
DEBUG - 2011-09-23 10:59:50 --> Utf8 Class Initialized
DEBUG - 2011-09-23 10:59:50 --> UTF-8 Support Enabled
DEBUG - 2011-09-23 10:59:50 --> URI Class Initialized
DEBUG - 2011-09-23 10:59:50 --> Router Class Initialized
DEBUG - 2011-09-23 10:59:50 --> Output Class Initialized
DEBUG - 2011-09-23 10:59:50 --> Input Class Initialized
DEBUG - 2011-09-23 10:59:50 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-23 10:59:50 --> Language Class Initialized
DEBUG - 2011-09-23 10:59:50 --> Loader Class Initialized
DEBUG - 2011-09-23 10:59:50 --> Controller Class Initialized
DEBUG - 2011-09-23 10:59:50 --> Model Class Initialized
DEBUG - 2011-09-23 10:59:50 --> Model Class Initialized
DEBUG - 2011-09-23 10:59:50 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-23 10:59:50 --> Database Driver Class Initialized
DEBUG - 2011-09-23 10:59:51 --> Final output sent to browser
DEBUG - 2011-09-23 10:59:51 --> Total execution time: 0.5607
DEBUG - 2011-09-23 10:59:52 --> Config Class Initialized
DEBUG - 2011-09-23 10:59:52 --> Hooks Class Initialized
DEBUG - 2011-09-23 10:59:52 --> Utf8 Class Initialized
DEBUG - 2011-09-23 10:59:52 --> UTF-8 Support Enabled
DEBUG - 2011-09-23 10:59:52 --> URI Class Initialized
DEBUG - 2011-09-23 10:59:52 --> Router Class Initialized
ERROR - 2011-09-23 10:59:52 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-23 11:00:02 --> Config Class Initialized
DEBUG - 2011-09-23 11:00:02 --> Hooks Class Initialized
DEBUG - 2011-09-23 11:00:02 --> Utf8 Class Initialized
DEBUG - 2011-09-23 11:00:02 --> UTF-8 Support Enabled
DEBUG - 2011-09-23 11:00:02 --> URI Class Initialized
DEBUG - 2011-09-23 11:00:02 --> Router Class Initialized
DEBUG - 2011-09-23 11:00:02 --> Output Class Initialized
DEBUG - 2011-09-23 11:00:02 --> Input Class Initialized
DEBUG - 2011-09-23 11:00:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-23 11:00:02 --> Language Class Initialized
DEBUG - 2011-09-23 11:00:02 --> Loader Class Initialized
DEBUG - 2011-09-23 11:00:02 --> Controller Class Initialized
ERROR - 2011-09-23 11:00:02 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-23 11:00:02 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-23 11:00:02 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-23 11:00:02 --> Model Class Initialized
DEBUG - 2011-09-23 11:00:02 --> Model Class Initialized
DEBUG - 2011-09-23 11:00:02 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-23 11:00:02 --> Database Driver Class Initialized
DEBUG - 2011-09-23 11:00:02 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-23 11:00:02 --> Helper loaded: url_helper
DEBUG - 2011-09-23 11:00:02 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-23 11:00:02 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-23 11:00:02 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-23 11:00:02 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-23 11:00:02 --> Final output sent to browser
DEBUG - 2011-09-23 11:00:02 --> Total execution time: 0.2147
DEBUG - 2011-09-23 11:00:04 --> Config Class Initialized
DEBUG - 2011-09-23 11:00:04 --> Hooks Class Initialized
DEBUG - 2011-09-23 11:00:04 --> Utf8 Class Initialized
DEBUG - 2011-09-23 11:00:04 --> UTF-8 Support Enabled
DEBUG - 2011-09-23 11:00:04 --> URI Class Initialized
DEBUG - 2011-09-23 11:00:04 --> Router Class Initialized
DEBUG - 2011-09-23 11:00:04 --> Output Class Initialized
DEBUG - 2011-09-23 11:00:04 --> Input Class Initialized
DEBUG - 2011-09-23 11:00:04 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-23 11:00:04 --> Language Class Initialized
DEBUG - 2011-09-23 11:00:04 --> Loader Class Initialized
DEBUG - 2011-09-23 11:00:04 --> Controller Class Initialized
DEBUG - 2011-09-23 11:00:04 --> Model Class Initialized
DEBUG - 2011-09-23 11:00:04 --> Model Class Initialized
DEBUG - 2011-09-23 11:00:04 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-23 11:00:04 --> Database Driver Class Initialized
DEBUG - 2011-09-23 11:00:05 --> Final output sent to browser
DEBUG - 2011-09-23 11:00:05 --> Total execution time: 0.9701
DEBUG - 2011-09-23 11:00:07 --> Config Class Initialized
DEBUG - 2011-09-23 11:00:07 --> Hooks Class Initialized
DEBUG - 2011-09-23 11:00:07 --> Utf8 Class Initialized
DEBUG - 2011-09-23 11:00:07 --> UTF-8 Support Enabled
DEBUG - 2011-09-23 11:00:07 --> URI Class Initialized
DEBUG - 2011-09-23 11:00:07 --> Router Class Initialized
ERROR - 2011-09-23 11:00:07 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-23 11:00:16 --> Config Class Initialized
DEBUG - 2011-09-23 11:00:16 --> Hooks Class Initialized
DEBUG - 2011-09-23 11:00:16 --> Utf8 Class Initialized
DEBUG - 2011-09-23 11:00:16 --> UTF-8 Support Enabled
DEBUG - 2011-09-23 11:00:16 --> URI Class Initialized
DEBUG - 2011-09-23 11:00:16 --> Router Class Initialized
DEBUG - 2011-09-23 11:00:16 --> Output Class Initialized
DEBUG - 2011-09-23 11:00:16 --> Input Class Initialized
DEBUG - 2011-09-23 11:00:16 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-23 11:00:16 --> Language Class Initialized
DEBUG - 2011-09-23 11:00:16 --> Loader Class Initialized
DEBUG - 2011-09-23 11:00:16 --> Controller Class Initialized
ERROR - 2011-09-23 11:00:16 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-23 11:00:16 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-23 11:00:16 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-23 11:00:16 --> Model Class Initialized
DEBUG - 2011-09-23 11:00:16 --> Model Class Initialized
DEBUG - 2011-09-23 11:00:16 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-23 11:00:16 --> Database Driver Class Initialized
DEBUG - 2011-09-23 11:00:16 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-23 11:00:16 --> Helper loaded: url_helper
DEBUG - 2011-09-23 11:00:16 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-23 11:00:16 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-23 11:00:16 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-23 11:00:16 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-23 11:00:16 --> Final output sent to browser
DEBUG - 2011-09-23 11:00:16 --> Total execution time: 0.1200
DEBUG - 2011-09-23 11:00:17 --> Config Class Initialized
DEBUG - 2011-09-23 11:00:17 --> Hooks Class Initialized
DEBUG - 2011-09-23 11:00:17 --> Utf8 Class Initialized
DEBUG - 2011-09-23 11:00:17 --> UTF-8 Support Enabled
DEBUG - 2011-09-23 11:00:17 --> URI Class Initialized
DEBUG - 2011-09-23 11:00:17 --> Router Class Initialized
DEBUG - 2011-09-23 11:00:17 --> Output Class Initialized
DEBUG - 2011-09-23 11:00:17 --> Input Class Initialized
DEBUG - 2011-09-23 11:00:17 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-23 11:00:17 --> Language Class Initialized
DEBUG - 2011-09-23 11:00:17 --> Loader Class Initialized
DEBUG - 2011-09-23 11:00:17 --> Controller Class Initialized
DEBUG - 2011-09-23 11:00:17 --> Model Class Initialized
DEBUG - 2011-09-23 11:00:17 --> Model Class Initialized
DEBUG - 2011-09-23 11:00:17 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-23 11:00:17 --> Database Driver Class Initialized
DEBUG - 2011-09-23 11:00:18 --> Final output sent to browser
DEBUG - 2011-09-23 11:00:18 --> Total execution time: 0.6026
DEBUG - 2011-09-23 11:00:19 --> Config Class Initialized
DEBUG - 2011-09-23 11:00:19 --> Hooks Class Initialized
DEBUG - 2011-09-23 11:00:19 --> Utf8 Class Initialized
DEBUG - 2011-09-23 11:00:19 --> UTF-8 Support Enabled
DEBUG - 2011-09-23 11:00:19 --> URI Class Initialized
DEBUG - 2011-09-23 11:00:19 --> Router Class Initialized
ERROR - 2011-09-23 11:00:19 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-23 11:00:23 --> Config Class Initialized
DEBUG - 2011-09-23 11:00:23 --> Hooks Class Initialized
DEBUG - 2011-09-23 11:00:23 --> Utf8 Class Initialized
DEBUG - 2011-09-23 11:00:23 --> UTF-8 Support Enabled
DEBUG - 2011-09-23 11:00:23 --> URI Class Initialized
DEBUG - 2011-09-23 11:00:23 --> Router Class Initialized
DEBUG - 2011-09-23 11:00:23 --> Output Class Initialized
DEBUG - 2011-09-23 11:00:23 --> Input Class Initialized
DEBUG - 2011-09-23 11:00:23 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-23 11:00:23 --> Language Class Initialized
DEBUG - 2011-09-23 11:00:23 --> Loader Class Initialized
DEBUG - 2011-09-23 11:00:23 --> Controller Class Initialized
ERROR - 2011-09-23 11:00:23 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-23 11:00:23 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-23 11:00:23 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-23 11:00:23 --> Model Class Initialized
DEBUG - 2011-09-23 11:00:23 --> Model Class Initialized
DEBUG - 2011-09-23 11:00:23 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-23 11:00:23 --> Database Driver Class Initialized
DEBUG - 2011-09-23 11:00:23 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-23 11:00:23 --> Helper loaded: url_helper
DEBUG - 2011-09-23 11:00:23 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-23 11:00:23 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-23 11:00:23 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-23 11:00:23 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-23 11:00:23 --> Final output sent to browser
DEBUG - 2011-09-23 11:00:23 --> Total execution time: 0.0313
DEBUG - 2011-09-23 11:00:24 --> Config Class Initialized
DEBUG - 2011-09-23 11:00:24 --> Hooks Class Initialized
DEBUG - 2011-09-23 11:00:24 --> Utf8 Class Initialized
DEBUG - 2011-09-23 11:00:24 --> UTF-8 Support Enabled
DEBUG - 2011-09-23 11:00:24 --> URI Class Initialized
DEBUG - 2011-09-23 11:00:24 --> Router Class Initialized
DEBUG - 2011-09-23 11:00:24 --> Output Class Initialized
DEBUG - 2011-09-23 11:00:24 --> Input Class Initialized
DEBUG - 2011-09-23 11:00:24 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-23 11:00:24 --> Language Class Initialized
DEBUG - 2011-09-23 11:00:24 --> Loader Class Initialized
DEBUG - 2011-09-23 11:00:24 --> Controller Class Initialized
DEBUG - 2011-09-23 11:00:24 --> Model Class Initialized
DEBUG - 2011-09-23 11:00:24 --> Model Class Initialized
DEBUG - 2011-09-23 11:00:24 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-23 11:00:24 --> Database Driver Class Initialized
DEBUG - 2011-09-23 11:00:25 --> Final output sent to browser
DEBUG - 2011-09-23 11:00:25 --> Total execution time: 0.7036
DEBUG - 2011-09-23 11:00:26 --> Config Class Initialized
DEBUG - 2011-09-23 11:00:26 --> Hooks Class Initialized
DEBUG - 2011-09-23 11:00:26 --> Utf8 Class Initialized
DEBUG - 2011-09-23 11:00:26 --> UTF-8 Support Enabled
DEBUG - 2011-09-23 11:00:26 --> URI Class Initialized
DEBUG - 2011-09-23 11:00:26 --> Router Class Initialized
ERROR - 2011-09-23 11:00:26 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-23 11:00:33 --> Config Class Initialized
DEBUG - 2011-09-23 11:00:33 --> Hooks Class Initialized
DEBUG - 2011-09-23 11:00:33 --> Utf8 Class Initialized
DEBUG - 2011-09-23 11:00:33 --> UTF-8 Support Enabled
DEBUG - 2011-09-23 11:00:33 --> URI Class Initialized
DEBUG - 2011-09-23 11:00:33 --> Router Class Initialized
DEBUG - 2011-09-23 11:00:33 --> Output Class Initialized
DEBUG - 2011-09-23 11:00:33 --> Input Class Initialized
DEBUG - 2011-09-23 11:00:33 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-23 11:00:33 --> Language Class Initialized
DEBUG - 2011-09-23 11:00:33 --> Loader Class Initialized
DEBUG - 2011-09-23 11:00:33 --> Controller Class Initialized
ERROR - 2011-09-23 11:00:33 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-23 11:00:33 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-23 11:00:33 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-23 11:00:33 --> Model Class Initialized
DEBUG - 2011-09-23 11:00:33 --> Model Class Initialized
DEBUG - 2011-09-23 11:00:33 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-23 11:00:33 --> Database Driver Class Initialized
DEBUG - 2011-09-23 11:00:33 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-23 11:00:33 --> Helper loaded: url_helper
DEBUG - 2011-09-23 11:00:33 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-23 11:00:33 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-23 11:00:33 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-23 11:00:33 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-23 11:00:33 --> Final output sent to browser
DEBUG - 2011-09-23 11:00:33 --> Total execution time: 0.0313
DEBUG - 2011-09-23 11:00:34 --> Config Class Initialized
DEBUG - 2011-09-23 11:00:34 --> Hooks Class Initialized
DEBUG - 2011-09-23 11:00:34 --> Utf8 Class Initialized
DEBUG - 2011-09-23 11:00:34 --> UTF-8 Support Enabled
DEBUG - 2011-09-23 11:00:34 --> URI Class Initialized
DEBUG - 2011-09-23 11:00:34 --> Router Class Initialized
DEBUG - 2011-09-23 11:00:34 --> Output Class Initialized
DEBUG - 2011-09-23 11:00:34 --> Input Class Initialized
DEBUG - 2011-09-23 11:00:34 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-23 11:00:34 --> Language Class Initialized
DEBUG - 2011-09-23 11:00:34 --> Loader Class Initialized
DEBUG - 2011-09-23 11:00:34 --> Controller Class Initialized
DEBUG - 2011-09-23 11:00:34 --> Model Class Initialized
DEBUG - 2011-09-23 11:00:34 --> Model Class Initialized
DEBUG - 2011-09-23 11:00:34 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-23 11:00:34 --> Database Driver Class Initialized
DEBUG - 2011-09-23 11:00:34 --> Final output sent to browser
DEBUG - 2011-09-23 11:00:34 --> Total execution time: 0.6451
DEBUG - 2011-09-23 11:00:36 --> Config Class Initialized
DEBUG - 2011-09-23 11:00:36 --> Hooks Class Initialized
DEBUG - 2011-09-23 11:00:36 --> Utf8 Class Initialized
DEBUG - 2011-09-23 11:00:36 --> UTF-8 Support Enabled
DEBUG - 2011-09-23 11:00:36 --> URI Class Initialized
DEBUG - 2011-09-23 11:00:36 --> Router Class Initialized
ERROR - 2011-09-23 11:00:36 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-23 11:00:40 --> Config Class Initialized
DEBUG - 2011-09-23 11:00:40 --> Hooks Class Initialized
DEBUG - 2011-09-23 11:00:40 --> Utf8 Class Initialized
DEBUG - 2011-09-23 11:00:40 --> UTF-8 Support Enabled
DEBUG - 2011-09-23 11:00:40 --> URI Class Initialized
DEBUG - 2011-09-23 11:00:40 --> Router Class Initialized
DEBUG - 2011-09-23 11:00:40 --> Output Class Initialized
DEBUG - 2011-09-23 11:00:40 --> Input Class Initialized
DEBUG - 2011-09-23 11:00:40 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-23 11:00:40 --> Language Class Initialized
DEBUG - 2011-09-23 11:00:40 --> Loader Class Initialized
DEBUG - 2011-09-23 11:00:40 --> Controller Class Initialized
ERROR - 2011-09-23 11:00:40 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-23 11:00:40 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-23 11:00:40 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-23 11:00:40 --> Model Class Initialized
DEBUG - 2011-09-23 11:00:40 --> Model Class Initialized
DEBUG - 2011-09-23 11:00:40 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-23 11:00:40 --> Database Driver Class Initialized
DEBUG - 2011-09-23 11:00:40 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-23 11:00:40 --> Helper loaded: url_helper
DEBUG - 2011-09-23 11:00:40 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-23 11:00:40 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-23 11:00:40 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-23 11:00:40 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-23 11:00:40 --> Final output sent to browser
DEBUG - 2011-09-23 11:00:40 --> Total execution time: 0.0373
DEBUG - 2011-09-23 11:00:41 --> Config Class Initialized
DEBUG - 2011-09-23 11:00:41 --> Hooks Class Initialized
DEBUG - 2011-09-23 11:00:41 --> Utf8 Class Initialized
DEBUG - 2011-09-23 11:00:41 --> UTF-8 Support Enabled
DEBUG - 2011-09-23 11:00:41 --> URI Class Initialized
DEBUG - 2011-09-23 11:00:41 --> Router Class Initialized
DEBUG - 2011-09-23 11:00:41 --> Output Class Initialized
DEBUG - 2011-09-23 11:00:41 --> Input Class Initialized
DEBUG - 2011-09-23 11:00:41 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-23 11:00:41 --> Language Class Initialized
DEBUG - 2011-09-23 11:00:41 --> Loader Class Initialized
DEBUG - 2011-09-23 11:00:41 --> Controller Class Initialized
DEBUG - 2011-09-23 11:00:41 --> Model Class Initialized
DEBUG - 2011-09-23 11:00:41 --> Model Class Initialized
DEBUG - 2011-09-23 11:00:41 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-23 11:00:41 --> Database Driver Class Initialized
DEBUG - 2011-09-23 11:00:42 --> Final output sent to browser
DEBUG - 2011-09-23 11:00:42 --> Total execution time: 0.9032
DEBUG - 2011-09-23 11:00:44 --> Config Class Initialized
DEBUG - 2011-09-23 11:00:44 --> Hooks Class Initialized
DEBUG - 2011-09-23 11:00:44 --> Utf8 Class Initialized
DEBUG - 2011-09-23 11:00:44 --> UTF-8 Support Enabled
DEBUG - 2011-09-23 11:00:44 --> URI Class Initialized
DEBUG - 2011-09-23 11:00:44 --> Router Class Initialized
ERROR - 2011-09-23 11:00:44 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-23 11:35:18 --> Config Class Initialized
DEBUG - 2011-09-23 11:35:18 --> Hooks Class Initialized
DEBUG - 2011-09-23 11:35:18 --> Utf8 Class Initialized
DEBUG - 2011-09-23 11:35:18 --> UTF-8 Support Enabled
DEBUG - 2011-09-23 11:35:18 --> URI Class Initialized
DEBUG - 2011-09-23 11:35:18 --> Router Class Initialized
DEBUG - 2011-09-23 11:35:18 --> No URI present. Default controller set.
DEBUG - 2011-09-23 11:35:18 --> Output Class Initialized
DEBUG - 2011-09-23 11:35:18 --> Input Class Initialized
DEBUG - 2011-09-23 11:35:18 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-23 11:35:18 --> Language Class Initialized
DEBUG - 2011-09-23 11:35:18 --> Loader Class Initialized
DEBUG - 2011-09-23 11:35:18 --> Controller Class Initialized
DEBUG - 2011-09-23 11:35:18 --> File loaded: application/views/splash/main.php
DEBUG - 2011-09-23 11:35:18 --> Helper loaded: url_helper
DEBUG - 2011-09-23 11:35:18 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-23 11:35:18 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-23 11:35:18 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-23 11:35:18 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-23 11:35:18 --> Final output sent to browser
DEBUG - 2011-09-23 11:35:18 --> Total execution time: 0.1187
DEBUG - 2011-09-23 11:35:18 --> Config Class Initialized
DEBUG - 2011-09-23 11:35:18 --> Hooks Class Initialized
DEBUG - 2011-09-23 11:35:18 --> Utf8 Class Initialized
DEBUG - 2011-09-23 11:35:18 --> UTF-8 Support Enabled
DEBUG - 2011-09-23 11:35:18 --> URI Class Initialized
DEBUG - 2011-09-23 11:35:18 --> Router Class Initialized
ERROR - 2011-09-23 11:35:18 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-23 11:46:09 --> Config Class Initialized
DEBUG - 2011-09-23 11:46:09 --> Hooks Class Initialized
DEBUG - 2011-09-23 11:46:09 --> Utf8 Class Initialized
DEBUG - 2011-09-23 11:46:09 --> UTF-8 Support Enabled
DEBUG - 2011-09-23 11:46:09 --> URI Class Initialized
DEBUG - 2011-09-23 11:46:09 --> Router Class Initialized
DEBUG - 2011-09-23 11:46:09 --> Output Class Initialized
DEBUG - 2011-09-23 11:46:09 --> Input Class Initialized
DEBUG - 2011-09-23 11:46:09 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-23 11:46:09 --> Language Class Initialized
DEBUG - 2011-09-23 11:46:09 --> Loader Class Initialized
DEBUG - 2011-09-23 11:46:09 --> Controller Class Initialized
DEBUG - 2011-09-23 11:46:09 --> Model Class Initialized
DEBUG - 2011-09-23 11:46:09 --> Model Class Initialized
DEBUG - 2011-09-23 11:46:09 --> Model Class Initialized
DEBUG - 2011-09-23 11:46:09 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-23 11:46:09 --> Database Driver Class Initialized
DEBUG - 2011-09-23 11:46:11 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-23 11:46:11 --> Helper loaded: url_helper
DEBUG - 2011-09-23 11:46:11 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-23 11:46:11 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-23 11:46:11 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-23 11:46:11 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-23 11:46:11 --> Final output sent to browser
DEBUG - 2011-09-23 11:46:11 --> Total execution time: 2.3573
DEBUG - 2011-09-23 11:46:12 --> Config Class Initialized
DEBUG - 2011-09-23 11:46:12 --> Hooks Class Initialized
DEBUG - 2011-09-23 11:46:12 --> Utf8 Class Initialized
DEBUG - 2011-09-23 11:46:12 --> UTF-8 Support Enabled
DEBUG - 2011-09-23 11:46:12 --> URI Class Initialized
DEBUG - 2011-09-23 11:46:12 --> Router Class Initialized
DEBUG - 2011-09-23 11:46:12 --> Output Class Initialized
DEBUG - 2011-09-23 11:46:12 --> Input Class Initialized
DEBUG - 2011-09-23 11:46:12 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-23 11:46:12 --> Language Class Initialized
DEBUG - 2011-09-23 11:46:12 --> Loader Class Initialized
DEBUG - 2011-09-23 11:46:12 --> Controller Class Initialized
ERROR - 2011-09-23 11:46:12 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-23 11:46:12 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-23 11:46:12 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-23 11:46:12 --> Model Class Initialized
DEBUG - 2011-09-23 11:46:12 --> Model Class Initialized
DEBUG - 2011-09-23 11:46:12 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-23 11:46:12 --> Database Driver Class Initialized
DEBUG - 2011-09-23 11:46:12 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-23 11:46:12 --> Helper loaded: url_helper
DEBUG - 2011-09-23 11:46:12 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-23 11:46:12 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-23 11:46:12 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-23 11:46:12 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-23 11:46:12 --> Final output sent to browser
DEBUG - 2011-09-23 11:46:12 --> Total execution time: 0.1422
DEBUG - 2011-09-23 11:57:22 --> Config Class Initialized
DEBUG - 2011-09-23 11:57:22 --> Hooks Class Initialized
DEBUG - 2011-09-23 11:57:22 --> Utf8 Class Initialized
DEBUG - 2011-09-23 11:57:22 --> UTF-8 Support Enabled
DEBUG - 2011-09-23 11:57:22 --> URI Class Initialized
DEBUG - 2011-09-23 11:57:22 --> Router Class Initialized
ERROR - 2011-09-23 11:57:22 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-09-23 11:58:05 --> Config Class Initialized
DEBUG - 2011-09-23 11:58:05 --> Hooks Class Initialized
DEBUG - 2011-09-23 11:58:05 --> Utf8 Class Initialized
DEBUG - 2011-09-23 11:58:05 --> UTF-8 Support Enabled
DEBUG - 2011-09-23 11:58:05 --> URI Class Initialized
DEBUG - 2011-09-23 11:58:05 --> Router Class Initialized
DEBUG - 2011-09-23 11:58:05 --> Output Class Initialized
DEBUG - 2011-09-23 11:58:05 --> Input Class Initialized
DEBUG - 2011-09-23 11:58:05 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-23 11:58:05 --> Language Class Initialized
DEBUG - 2011-09-23 11:58:05 --> Loader Class Initialized
DEBUG - 2011-09-23 11:58:05 --> Controller Class Initialized
ERROR - 2011-09-23 11:58:05 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-23 11:58:05 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-23 11:58:05 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-23 11:58:05 --> Model Class Initialized
DEBUG - 2011-09-23 11:58:05 --> Model Class Initialized
DEBUG - 2011-09-23 11:58:05 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-23 11:58:05 --> Database Driver Class Initialized
DEBUG - 2011-09-23 11:58:05 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-23 11:58:05 --> Helper loaded: url_helper
DEBUG - 2011-09-23 11:58:05 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-23 11:58:05 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-23 11:58:05 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-23 11:58:05 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-23 11:58:05 --> Final output sent to browser
DEBUG - 2011-09-23 11:58:05 --> Total execution time: 0.0387
DEBUG - 2011-09-23 11:59:42 --> Config Class Initialized
DEBUG - 2011-09-23 11:59:42 --> Hooks Class Initialized
DEBUG - 2011-09-23 11:59:42 --> Utf8 Class Initialized
DEBUG - 2011-09-23 11:59:42 --> UTF-8 Support Enabled
DEBUG - 2011-09-23 11:59:42 --> URI Class Initialized
DEBUG - 2011-09-23 11:59:42 --> Router Class Initialized
ERROR - 2011-09-23 11:59:42 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-09-23 12:24:56 --> Config Class Initialized
DEBUG - 2011-09-23 12:24:56 --> Hooks Class Initialized
DEBUG - 2011-09-23 12:24:56 --> Utf8 Class Initialized
DEBUG - 2011-09-23 12:24:56 --> UTF-8 Support Enabled
DEBUG - 2011-09-23 12:24:56 --> URI Class Initialized
DEBUG - 2011-09-23 12:24:56 --> Router Class Initialized
DEBUG - 2011-09-23 12:24:56 --> Output Class Initialized
DEBUG - 2011-09-23 12:24:56 --> Input Class Initialized
DEBUG - 2011-09-23 12:24:56 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-23 12:24:56 --> Language Class Initialized
DEBUG - 2011-09-23 12:24:56 --> Loader Class Initialized
DEBUG - 2011-09-23 12:24:56 --> Controller Class Initialized
ERROR - 2011-09-23 12:24:56 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-23 12:24:56 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-23 12:24:56 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-23 12:24:56 --> Model Class Initialized
DEBUG - 2011-09-23 12:24:56 --> Model Class Initialized
DEBUG - 2011-09-23 12:24:56 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-23 12:24:56 --> Database Driver Class Initialized
DEBUG - 2011-09-23 12:24:56 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-23 12:24:56 --> Helper loaded: url_helper
DEBUG - 2011-09-23 12:24:56 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-23 12:24:56 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-23 12:24:56 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-23 12:24:56 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-23 12:24:56 --> Final output sent to browser
DEBUG - 2011-09-23 12:24:56 --> Total execution time: 0.2060
DEBUG - 2011-09-23 12:24:58 --> Config Class Initialized
DEBUG - 2011-09-23 12:24:58 --> Hooks Class Initialized
DEBUG - 2011-09-23 12:24:58 --> Utf8 Class Initialized
DEBUG - 2011-09-23 12:24:58 --> UTF-8 Support Enabled
DEBUG - 2011-09-23 12:24:58 --> URI Class Initialized
DEBUG - 2011-09-23 12:24:58 --> Router Class Initialized
DEBUG - 2011-09-23 12:24:58 --> Output Class Initialized
DEBUG - 2011-09-23 12:24:58 --> Input Class Initialized
DEBUG - 2011-09-23 12:24:58 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-23 12:24:58 --> Language Class Initialized
DEBUG - 2011-09-23 12:24:58 --> Loader Class Initialized
DEBUG - 2011-09-23 12:24:58 --> Controller Class Initialized
DEBUG - 2011-09-23 12:24:58 --> Model Class Initialized
DEBUG - 2011-09-23 12:24:58 --> Model Class Initialized
DEBUG - 2011-09-23 12:24:58 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-23 12:24:58 --> Database Driver Class Initialized
DEBUG - 2011-09-23 12:24:59 --> Final output sent to browser
DEBUG - 2011-09-23 12:24:59 --> Total execution time: 1.1567
DEBUG - 2011-09-23 12:25:01 --> Config Class Initialized
DEBUG - 2011-09-23 12:25:01 --> Hooks Class Initialized
DEBUG - 2011-09-23 12:25:01 --> Utf8 Class Initialized
DEBUG - 2011-09-23 12:25:01 --> UTF-8 Support Enabled
DEBUG - 2011-09-23 12:25:01 --> URI Class Initialized
DEBUG - 2011-09-23 12:25:01 --> Router Class Initialized
ERROR - 2011-09-23 12:25:01 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-23 12:25:18 --> Config Class Initialized
DEBUG - 2011-09-23 12:25:18 --> Hooks Class Initialized
DEBUG - 2011-09-23 12:25:18 --> Utf8 Class Initialized
DEBUG - 2011-09-23 12:25:18 --> UTF-8 Support Enabled
DEBUG - 2011-09-23 12:25:18 --> URI Class Initialized
DEBUG - 2011-09-23 12:25:18 --> Router Class Initialized
DEBUG - 2011-09-23 12:25:18 --> Output Class Initialized
DEBUG - 2011-09-23 12:25:18 --> Input Class Initialized
DEBUG - 2011-09-23 12:25:18 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-23 12:25:18 --> Language Class Initialized
DEBUG - 2011-09-23 12:25:18 --> Loader Class Initialized
DEBUG - 2011-09-23 12:25:18 --> Controller Class Initialized
ERROR - 2011-09-23 12:25:18 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-23 12:25:18 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-23 12:25:18 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-23 12:25:18 --> Model Class Initialized
DEBUG - 2011-09-23 12:25:18 --> Model Class Initialized
DEBUG - 2011-09-23 12:25:18 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-23 12:25:18 --> Database Driver Class Initialized
DEBUG - 2011-09-23 12:25:18 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-23 12:25:18 --> Helper loaded: url_helper
DEBUG - 2011-09-23 12:25:18 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-23 12:25:18 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-23 12:25:18 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-23 12:25:18 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-23 12:25:18 --> Final output sent to browser
DEBUG - 2011-09-23 12:25:18 --> Total execution time: 0.0336
DEBUG - 2011-09-23 12:25:19 --> Config Class Initialized
DEBUG - 2011-09-23 12:25:19 --> Hooks Class Initialized
DEBUG - 2011-09-23 12:25:19 --> Utf8 Class Initialized
DEBUG - 2011-09-23 12:25:19 --> UTF-8 Support Enabled
DEBUG - 2011-09-23 12:25:19 --> URI Class Initialized
DEBUG - 2011-09-23 12:25:19 --> Router Class Initialized
DEBUG - 2011-09-23 12:25:19 --> Output Class Initialized
DEBUG - 2011-09-23 12:25:19 --> Input Class Initialized
DEBUG - 2011-09-23 12:25:19 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-23 12:25:19 --> Language Class Initialized
DEBUG - 2011-09-23 12:25:19 --> Loader Class Initialized
DEBUG - 2011-09-23 12:25:19 --> Controller Class Initialized
DEBUG - 2011-09-23 12:25:19 --> Model Class Initialized
DEBUG - 2011-09-23 12:25:19 --> Model Class Initialized
DEBUG - 2011-09-23 12:25:19 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-23 12:25:19 --> Database Driver Class Initialized
DEBUG - 2011-09-23 12:25:20 --> Final output sent to browser
DEBUG - 2011-09-23 12:25:20 --> Total execution time: 0.5667
DEBUG - 2011-09-23 12:25:24 --> Config Class Initialized
DEBUG - 2011-09-23 12:25:24 --> Hooks Class Initialized
DEBUG - 2011-09-23 12:25:24 --> Utf8 Class Initialized
DEBUG - 2011-09-23 12:25:24 --> UTF-8 Support Enabled
DEBUG - 2011-09-23 12:25:24 --> URI Class Initialized
DEBUG - 2011-09-23 12:25:24 --> Router Class Initialized
ERROR - 2011-09-23 12:25:24 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-23 12:25:39 --> Config Class Initialized
DEBUG - 2011-09-23 12:25:39 --> Hooks Class Initialized
DEBUG - 2011-09-23 12:25:39 --> Utf8 Class Initialized
DEBUG - 2011-09-23 12:25:39 --> UTF-8 Support Enabled
DEBUG - 2011-09-23 12:25:39 --> URI Class Initialized
DEBUG - 2011-09-23 12:25:39 --> Router Class Initialized
DEBUG - 2011-09-23 12:25:39 --> Output Class Initialized
DEBUG - 2011-09-23 12:25:39 --> Input Class Initialized
DEBUG - 2011-09-23 12:25:39 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-23 12:25:39 --> Language Class Initialized
DEBUG - 2011-09-23 12:25:39 --> Loader Class Initialized
DEBUG - 2011-09-23 12:25:39 --> Controller Class Initialized
ERROR - 2011-09-23 12:25:39 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-23 12:25:39 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-23 12:25:39 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-23 12:25:39 --> Model Class Initialized
DEBUG - 2011-09-23 12:25:39 --> Model Class Initialized
DEBUG - 2011-09-23 12:25:39 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-23 12:25:39 --> Database Driver Class Initialized
DEBUG - 2011-09-23 12:25:39 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-23 12:25:39 --> Helper loaded: url_helper
DEBUG - 2011-09-23 12:25:39 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-23 12:25:39 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-23 12:25:39 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-23 12:25:39 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-23 12:25:39 --> Final output sent to browser
DEBUG - 2011-09-23 12:25:39 --> Total execution time: 0.0316
DEBUG - 2011-09-23 12:25:40 --> Config Class Initialized
DEBUG - 2011-09-23 12:25:40 --> Hooks Class Initialized
DEBUG - 2011-09-23 12:25:40 --> Utf8 Class Initialized
DEBUG - 2011-09-23 12:25:40 --> UTF-8 Support Enabled
DEBUG - 2011-09-23 12:25:40 --> URI Class Initialized
DEBUG - 2011-09-23 12:25:40 --> Router Class Initialized
DEBUG - 2011-09-23 12:25:40 --> Output Class Initialized
DEBUG - 2011-09-23 12:25:40 --> Input Class Initialized
DEBUG - 2011-09-23 12:25:40 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-23 12:25:40 --> Language Class Initialized
DEBUG - 2011-09-23 12:25:40 --> Loader Class Initialized
DEBUG - 2011-09-23 12:25:40 --> Controller Class Initialized
DEBUG - 2011-09-23 12:25:40 --> Model Class Initialized
DEBUG - 2011-09-23 12:25:40 --> Model Class Initialized
DEBUG - 2011-09-23 12:25:40 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-23 12:25:40 --> Database Driver Class Initialized
DEBUG - 2011-09-23 12:25:41 --> Final output sent to browser
DEBUG - 2011-09-23 12:25:41 --> Total execution time: 0.7498
DEBUG - 2011-09-23 12:25:42 --> Config Class Initialized
DEBUG - 2011-09-23 12:25:42 --> Hooks Class Initialized
DEBUG - 2011-09-23 12:25:42 --> Utf8 Class Initialized
DEBUG - 2011-09-23 12:25:42 --> UTF-8 Support Enabled
DEBUG - 2011-09-23 12:25:42 --> URI Class Initialized
DEBUG - 2011-09-23 12:25:42 --> Router Class Initialized
ERROR - 2011-09-23 12:25:43 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-23 12:25:55 --> Config Class Initialized
DEBUG - 2011-09-23 12:25:55 --> Hooks Class Initialized
DEBUG - 2011-09-23 12:25:55 --> Utf8 Class Initialized
DEBUG - 2011-09-23 12:25:55 --> UTF-8 Support Enabled
DEBUG - 2011-09-23 12:25:55 --> URI Class Initialized
DEBUG - 2011-09-23 12:25:55 --> Router Class Initialized
DEBUG - 2011-09-23 12:25:55 --> Output Class Initialized
DEBUG - 2011-09-23 12:25:55 --> Input Class Initialized
DEBUG - 2011-09-23 12:25:55 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-23 12:25:55 --> Language Class Initialized
DEBUG - 2011-09-23 12:25:55 --> Loader Class Initialized
DEBUG - 2011-09-23 12:25:55 --> Controller Class Initialized
ERROR - 2011-09-23 12:25:55 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-23 12:25:55 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-23 12:25:55 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-23 12:25:55 --> Model Class Initialized
DEBUG - 2011-09-23 12:25:55 --> Model Class Initialized
DEBUG - 2011-09-23 12:25:55 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-23 12:25:55 --> Database Driver Class Initialized
DEBUG - 2011-09-23 12:25:55 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-23 12:25:55 --> Helper loaded: url_helper
DEBUG - 2011-09-23 12:25:55 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-23 12:25:55 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-23 12:25:55 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-23 12:25:55 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-23 12:25:55 --> Final output sent to browser
DEBUG - 2011-09-23 12:25:55 --> Total execution time: 0.0327
DEBUG - 2011-09-23 12:25:56 --> Config Class Initialized
DEBUG - 2011-09-23 12:25:56 --> Hooks Class Initialized
DEBUG - 2011-09-23 12:25:56 --> Utf8 Class Initialized
DEBUG - 2011-09-23 12:25:56 --> UTF-8 Support Enabled
DEBUG - 2011-09-23 12:25:56 --> URI Class Initialized
DEBUG - 2011-09-23 12:25:56 --> Router Class Initialized
DEBUG - 2011-09-23 12:25:56 --> Output Class Initialized
DEBUG - 2011-09-23 12:25:56 --> Input Class Initialized
DEBUG - 2011-09-23 12:25:56 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-23 12:25:56 --> Language Class Initialized
DEBUG - 2011-09-23 12:25:56 --> Loader Class Initialized
DEBUG - 2011-09-23 12:25:56 --> Controller Class Initialized
ERROR - 2011-09-23 12:25:56 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-23 12:25:56 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-23 12:25:56 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-23 12:25:56 --> Model Class Initialized
DEBUG - 2011-09-23 12:25:56 --> Model Class Initialized
DEBUG - 2011-09-23 12:25:56 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-23 12:25:56 --> Database Driver Class Initialized
DEBUG - 2011-09-23 12:25:56 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-23 12:25:56 --> Helper loaded: url_helper
DEBUG - 2011-09-23 12:25:56 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-23 12:25:56 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-23 12:25:56 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-23 12:25:56 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-23 12:25:56 --> Final output sent to browser
DEBUG - 2011-09-23 12:25:56 --> Total execution time: 0.0810
DEBUG - 2011-09-23 12:25:56 --> Config Class Initialized
DEBUG - 2011-09-23 12:25:56 --> Hooks Class Initialized
DEBUG - 2011-09-23 12:25:56 --> Utf8 Class Initialized
DEBUG - 2011-09-23 12:25:56 --> UTF-8 Support Enabled
DEBUG - 2011-09-23 12:25:56 --> URI Class Initialized
DEBUG - 2011-09-23 12:25:56 --> Router Class Initialized
DEBUG - 2011-09-23 12:25:56 --> Output Class Initialized
DEBUG - 2011-09-23 12:25:56 --> Input Class Initialized
DEBUG - 2011-09-23 12:25:56 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-23 12:25:56 --> Language Class Initialized
DEBUG - 2011-09-23 12:25:56 --> Loader Class Initialized
DEBUG - 2011-09-23 12:25:56 --> Controller Class Initialized
DEBUG - 2011-09-23 12:25:56 --> Model Class Initialized
DEBUG - 2011-09-23 12:25:56 --> Model Class Initialized
DEBUG - 2011-09-23 12:25:56 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-23 12:25:56 --> Database Driver Class Initialized
DEBUG - 2011-09-23 12:25:57 --> Final output sent to browser
DEBUG - 2011-09-23 12:25:57 --> Total execution time: 0.6109
DEBUG - 2011-09-23 12:25:57 --> Config Class Initialized
DEBUG - 2011-09-23 12:25:57 --> Hooks Class Initialized
DEBUG - 2011-09-23 12:25:57 --> Utf8 Class Initialized
DEBUG - 2011-09-23 12:25:57 --> UTF-8 Support Enabled
DEBUG - 2011-09-23 12:25:57 --> URI Class Initialized
DEBUG - 2011-09-23 12:25:57 --> Router Class Initialized
DEBUG - 2011-09-23 12:25:57 --> Output Class Initialized
DEBUG - 2011-09-23 12:25:57 --> Input Class Initialized
DEBUG - 2011-09-23 12:25:57 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-23 12:25:57 --> Language Class Initialized
DEBUG - 2011-09-23 12:25:57 --> Loader Class Initialized
DEBUG - 2011-09-23 12:25:57 --> Controller Class Initialized
DEBUG - 2011-09-23 12:25:57 --> Model Class Initialized
DEBUG - 2011-09-23 12:25:57 --> Model Class Initialized
DEBUG - 2011-09-23 12:25:57 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-23 12:25:57 --> Database Driver Class Initialized
DEBUG - 2011-09-23 12:25:58 --> Final output sent to browser
DEBUG - 2011-09-23 12:25:58 --> Total execution time: 0.6596
DEBUG - 2011-09-23 12:25:58 --> Config Class Initialized
DEBUG - 2011-09-23 12:25:58 --> Hooks Class Initialized
DEBUG - 2011-09-23 12:25:58 --> Utf8 Class Initialized
DEBUG - 2011-09-23 12:25:58 --> UTF-8 Support Enabled
DEBUG - 2011-09-23 12:25:58 --> URI Class Initialized
DEBUG - 2011-09-23 12:25:58 --> Router Class Initialized
ERROR - 2011-09-23 12:25:58 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-23 12:26:00 --> Config Class Initialized
DEBUG - 2011-09-23 12:26:00 --> Hooks Class Initialized
DEBUG - 2011-09-23 12:26:00 --> Utf8 Class Initialized
DEBUG - 2011-09-23 12:26:00 --> UTF-8 Support Enabled
DEBUG - 2011-09-23 12:26:00 --> URI Class Initialized
DEBUG - 2011-09-23 12:26:00 --> Router Class Initialized
ERROR - 2011-09-23 12:26:00 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-23 12:26:07 --> Config Class Initialized
DEBUG - 2011-09-23 12:26:07 --> Hooks Class Initialized
DEBUG - 2011-09-23 12:26:07 --> Utf8 Class Initialized
DEBUG - 2011-09-23 12:26:07 --> UTF-8 Support Enabled
DEBUG - 2011-09-23 12:26:07 --> URI Class Initialized
DEBUG - 2011-09-23 12:26:07 --> Router Class Initialized
DEBUG - 2011-09-23 12:26:07 --> Output Class Initialized
DEBUG - 2011-09-23 12:26:07 --> Input Class Initialized
DEBUG - 2011-09-23 12:26:07 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-23 12:26:07 --> Language Class Initialized
DEBUG - 2011-09-23 12:26:07 --> Loader Class Initialized
DEBUG - 2011-09-23 12:26:07 --> Controller Class Initialized
ERROR - 2011-09-23 12:26:07 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-23 12:26:07 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-23 12:26:07 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-23 12:26:07 --> Model Class Initialized
DEBUG - 2011-09-23 12:26:07 --> Model Class Initialized
DEBUG - 2011-09-23 12:26:07 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-23 12:26:08 --> Database Driver Class Initialized
DEBUG - 2011-09-23 12:26:08 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-23 12:26:08 --> Helper loaded: url_helper
DEBUG - 2011-09-23 12:26:08 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-23 12:26:08 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-23 12:26:08 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-23 12:26:08 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-23 12:26:08 --> Final output sent to browser
DEBUG - 2011-09-23 12:26:08 --> Total execution time: 0.0411
DEBUG - 2011-09-23 12:26:08 --> Config Class Initialized
DEBUG - 2011-09-23 12:26:08 --> Hooks Class Initialized
DEBUG - 2011-09-23 12:26:08 --> Utf8 Class Initialized
DEBUG - 2011-09-23 12:26:08 --> UTF-8 Support Enabled
DEBUG - 2011-09-23 12:26:08 --> URI Class Initialized
DEBUG - 2011-09-23 12:26:08 --> Router Class Initialized
DEBUG - 2011-09-23 12:26:08 --> Output Class Initialized
DEBUG - 2011-09-23 12:26:08 --> Input Class Initialized
DEBUG - 2011-09-23 12:26:08 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-23 12:26:08 --> Language Class Initialized
DEBUG - 2011-09-23 12:26:08 --> Loader Class Initialized
DEBUG - 2011-09-23 12:26:08 --> Controller Class Initialized
DEBUG - 2011-09-23 12:26:08 --> Model Class Initialized
DEBUG - 2011-09-23 12:26:08 --> Model Class Initialized
DEBUG - 2011-09-23 12:26:08 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-23 12:26:08 --> Database Driver Class Initialized
DEBUG - 2011-09-23 12:26:09 --> Final output sent to browser
DEBUG - 2011-09-23 12:26:09 --> Total execution time: 0.5186
DEBUG - 2011-09-23 12:26:10 --> Config Class Initialized
DEBUG - 2011-09-23 12:26:10 --> Hooks Class Initialized
DEBUG - 2011-09-23 12:26:10 --> Utf8 Class Initialized
DEBUG - 2011-09-23 12:26:10 --> UTF-8 Support Enabled
DEBUG - 2011-09-23 12:26:10 --> URI Class Initialized
DEBUG - 2011-09-23 12:26:10 --> Router Class Initialized
ERROR - 2011-09-23 12:26:10 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-23 12:26:13 --> Config Class Initialized
DEBUG - 2011-09-23 12:26:13 --> Hooks Class Initialized
DEBUG - 2011-09-23 12:26:13 --> Utf8 Class Initialized
DEBUG - 2011-09-23 12:26:13 --> UTF-8 Support Enabled
DEBUG - 2011-09-23 12:26:13 --> URI Class Initialized
DEBUG - 2011-09-23 12:26:13 --> Router Class Initialized
DEBUG - 2011-09-23 12:26:13 --> Output Class Initialized
DEBUG - 2011-09-23 12:26:13 --> Input Class Initialized
DEBUG - 2011-09-23 12:26:13 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-23 12:26:13 --> Language Class Initialized
DEBUG - 2011-09-23 12:26:13 --> Loader Class Initialized
DEBUG - 2011-09-23 12:26:13 --> Controller Class Initialized
ERROR - 2011-09-23 12:26:13 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-23 12:26:13 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-23 12:26:13 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-23 12:26:13 --> Model Class Initialized
DEBUG - 2011-09-23 12:26:13 --> Model Class Initialized
DEBUG - 2011-09-23 12:26:13 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-23 12:26:13 --> Database Driver Class Initialized
DEBUG - 2011-09-23 12:26:13 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-23 12:26:13 --> Helper loaded: url_helper
DEBUG - 2011-09-23 12:26:13 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-23 12:26:13 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-23 12:26:13 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-23 12:26:13 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-23 12:26:13 --> Final output sent to browser
DEBUG - 2011-09-23 12:26:13 --> Total execution time: 0.0330
DEBUG - 2011-09-23 12:26:14 --> Config Class Initialized
DEBUG - 2011-09-23 12:26:14 --> Hooks Class Initialized
DEBUG - 2011-09-23 12:26:14 --> Utf8 Class Initialized
DEBUG - 2011-09-23 12:26:14 --> UTF-8 Support Enabled
DEBUG - 2011-09-23 12:26:14 --> URI Class Initialized
DEBUG - 2011-09-23 12:26:14 --> Router Class Initialized
DEBUG - 2011-09-23 12:26:14 --> Output Class Initialized
DEBUG - 2011-09-23 12:26:14 --> Input Class Initialized
DEBUG - 2011-09-23 12:26:14 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-23 12:26:14 --> Language Class Initialized
DEBUG - 2011-09-23 12:26:14 --> Loader Class Initialized
DEBUG - 2011-09-23 12:26:14 --> Controller Class Initialized
DEBUG - 2011-09-23 12:26:14 --> Model Class Initialized
DEBUG - 2011-09-23 12:26:14 --> Model Class Initialized
DEBUG - 2011-09-23 12:26:14 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-23 12:26:14 --> Database Driver Class Initialized
DEBUG - 2011-09-23 12:26:14 --> Final output sent to browser
DEBUG - 2011-09-23 12:26:14 --> Total execution time: 0.5949
DEBUG - 2011-09-23 12:26:16 --> Config Class Initialized
DEBUG - 2011-09-23 12:26:16 --> Hooks Class Initialized
DEBUG - 2011-09-23 12:26:16 --> Utf8 Class Initialized
DEBUG - 2011-09-23 12:26:16 --> UTF-8 Support Enabled
DEBUG - 2011-09-23 12:26:16 --> URI Class Initialized
DEBUG - 2011-09-23 12:26:16 --> Router Class Initialized
ERROR - 2011-09-23 12:26:16 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-23 12:26:52 --> Config Class Initialized
DEBUG - 2011-09-23 12:26:52 --> Hooks Class Initialized
DEBUG - 2011-09-23 12:26:52 --> Utf8 Class Initialized
DEBUG - 2011-09-23 12:26:52 --> UTF-8 Support Enabled
DEBUG - 2011-09-23 12:26:52 --> URI Class Initialized
DEBUG - 2011-09-23 12:26:52 --> Router Class Initialized
DEBUG - 2011-09-23 12:26:52 --> Output Class Initialized
DEBUG - 2011-09-23 12:26:52 --> Input Class Initialized
DEBUG - 2011-09-23 12:26:52 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-23 12:26:52 --> Language Class Initialized
DEBUG - 2011-09-23 12:26:52 --> Loader Class Initialized
DEBUG - 2011-09-23 12:26:52 --> Controller Class Initialized
ERROR - 2011-09-23 12:26:52 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-23 12:26:52 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-23 12:26:52 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-23 12:26:52 --> Model Class Initialized
DEBUG - 2011-09-23 12:26:52 --> Model Class Initialized
DEBUG - 2011-09-23 12:26:52 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-23 12:26:52 --> Database Driver Class Initialized
DEBUG - 2011-09-23 12:26:52 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-23 12:26:52 --> Helper loaded: url_helper
DEBUG - 2011-09-23 12:26:52 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-23 12:26:52 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-23 12:26:52 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-23 12:26:52 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-23 12:26:52 --> Final output sent to browser
DEBUG - 2011-09-23 12:26:52 --> Total execution time: 0.0363
DEBUG - 2011-09-23 12:26:54 --> Config Class Initialized
DEBUG - 2011-09-23 12:26:54 --> Hooks Class Initialized
DEBUG - 2011-09-23 12:26:54 --> Utf8 Class Initialized
DEBUG - 2011-09-23 12:26:54 --> UTF-8 Support Enabled
DEBUG - 2011-09-23 12:26:54 --> URI Class Initialized
DEBUG - 2011-09-23 12:26:54 --> Router Class Initialized
DEBUG - 2011-09-23 12:26:54 --> Output Class Initialized
DEBUG - 2011-09-23 12:26:54 --> Input Class Initialized
DEBUG - 2011-09-23 12:26:54 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-23 12:26:54 --> Language Class Initialized
DEBUG - 2011-09-23 12:26:54 --> Loader Class Initialized
DEBUG - 2011-09-23 12:26:54 --> Controller Class Initialized
DEBUG - 2011-09-23 12:26:54 --> Model Class Initialized
DEBUG - 2011-09-23 12:26:54 --> Model Class Initialized
DEBUG - 2011-09-23 12:26:54 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-23 12:26:54 --> Database Driver Class Initialized
DEBUG - 2011-09-23 12:26:54 --> Final output sent to browser
DEBUG - 2011-09-23 12:26:54 --> Total execution time: 0.6559
DEBUG - 2011-09-23 12:26:56 --> Config Class Initialized
DEBUG - 2011-09-23 12:26:56 --> Hooks Class Initialized
DEBUG - 2011-09-23 12:26:56 --> Utf8 Class Initialized
DEBUG - 2011-09-23 12:26:56 --> UTF-8 Support Enabled
DEBUG - 2011-09-23 12:26:56 --> URI Class Initialized
DEBUG - 2011-09-23 12:26:56 --> Router Class Initialized
ERROR - 2011-09-23 12:26:56 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-23 12:27:28 --> Config Class Initialized
DEBUG - 2011-09-23 12:27:28 --> Hooks Class Initialized
DEBUG - 2011-09-23 12:27:28 --> Utf8 Class Initialized
DEBUG - 2011-09-23 12:27:28 --> UTF-8 Support Enabled
DEBUG - 2011-09-23 12:27:28 --> URI Class Initialized
DEBUG - 2011-09-23 12:27:28 --> Router Class Initialized
DEBUG - 2011-09-23 12:27:28 --> Output Class Initialized
DEBUG - 2011-09-23 12:27:28 --> Input Class Initialized
DEBUG - 2011-09-23 12:27:28 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-23 12:27:28 --> Language Class Initialized
DEBUG - 2011-09-23 12:27:28 --> Loader Class Initialized
DEBUG - 2011-09-23 12:27:28 --> Controller Class Initialized
ERROR - 2011-09-23 12:27:28 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-23 12:27:28 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-23 12:27:28 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-23 12:27:28 --> Model Class Initialized
DEBUG - 2011-09-23 12:27:28 --> Model Class Initialized
DEBUG - 2011-09-23 12:27:28 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-23 12:27:28 --> Database Driver Class Initialized
DEBUG - 2011-09-23 12:27:28 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-23 12:27:28 --> Helper loaded: url_helper
DEBUG - 2011-09-23 12:27:28 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-23 12:27:28 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-23 12:27:28 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-23 12:27:28 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-23 12:27:28 --> Final output sent to browser
DEBUG - 2011-09-23 12:27:28 --> Total execution time: 0.0315
DEBUG - 2011-09-23 12:27:28 --> Config Class Initialized
DEBUG - 2011-09-23 12:27:28 --> Hooks Class Initialized
DEBUG - 2011-09-23 12:27:28 --> Utf8 Class Initialized
DEBUG - 2011-09-23 12:27:28 --> UTF-8 Support Enabled
DEBUG - 2011-09-23 12:27:28 --> URI Class Initialized
DEBUG - 2011-09-23 12:27:28 --> Router Class Initialized
DEBUG - 2011-09-23 12:27:28 --> Output Class Initialized
DEBUG - 2011-09-23 12:27:28 --> Input Class Initialized
DEBUG - 2011-09-23 12:27:28 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-23 12:27:28 --> Language Class Initialized
DEBUG - 2011-09-23 12:27:28 --> Loader Class Initialized
DEBUG - 2011-09-23 12:27:28 --> Controller Class Initialized
DEBUG - 2011-09-23 12:27:28 --> Model Class Initialized
DEBUG - 2011-09-23 12:27:28 --> Model Class Initialized
DEBUG - 2011-09-23 12:27:28 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-23 12:27:28 --> Database Driver Class Initialized
DEBUG - 2011-09-23 12:27:29 --> Final output sent to browser
DEBUG - 2011-09-23 12:27:29 --> Total execution time: 0.4951
DEBUG - 2011-09-23 12:27:31 --> Config Class Initialized
DEBUG - 2011-09-23 12:27:31 --> Hooks Class Initialized
DEBUG - 2011-09-23 12:27:31 --> Utf8 Class Initialized
DEBUG - 2011-09-23 12:27:31 --> UTF-8 Support Enabled
DEBUG - 2011-09-23 12:27:31 --> URI Class Initialized
DEBUG - 2011-09-23 12:27:31 --> Router Class Initialized
ERROR - 2011-09-23 12:27:31 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-23 12:27:47 --> Config Class Initialized
DEBUG - 2011-09-23 12:27:47 --> Hooks Class Initialized
DEBUG - 2011-09-23 12:27:47 --> Utf8 Class Initialized
DEBUG - 2011-09-23 12:27:47 --> UTF-8 Support Enabled
DEBUG - 2011-09-23 12:27:47 --> URI Class Initialized
DEBUG - 2011-09-23 12:27:47 --> Router Class Initialized
DEBUG - 2011-09-23 12:27:47 --> Output Class Initialized
DEBUG - 2011-09-23 12:27:47 --> Input Class Initialized
DEBUG - 2011-09-23 12:27:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-23 12:27:47 --> Language Class Initialized
DEBUG - 2011-09-23 12:27:47 --> Loader Class Initialized
DEBUG - 2011-09-23 12:27:47 --> Controller Class Initialized
ERROR - 2011-09-23 12:27:47 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-23 12:27:47 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-23 12:27:47 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-23 12:27:47 --> Model Class Initialized
DEBUG - 2011-09-23 12:27:47 --> Model Class Initialized
DEBUG - 2011-09-23 12:27:47 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-23 12:27:47 --> Database Driver Class Initialized
DEBUG - 2011-09-23 12:27:47 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-23 12:27:47 --> Helper loaded: url_helper
DEBUG - 2011-09-23 12:27:47 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-23 12:27:47 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-23 12:27:47 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-23 12:27:47 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-23 12:27:47 --> Final output sent to browser
DEBUG - 2011-09-23 12:27:47 --> Total execution time: 0.0533
DEBUG - 2011-09-23 12:27:48 --> Config Class Initialized
DEBUG - 2011-09-23 12:27:48 --> Hooks Class Initialized
DEBUG - 2011-09-23 12:27:48 --> Utf8 Class Initialized
DEBUG - 2011-09-23 12:27:48 --> UTF-8 Support Enabled
DEBUG - 2011-09-23 12:27:48 --> URI Class Initialized
DEBUG - 2011-09-23 12:27:48 --> Router Class Initialized
DEBUG - 2011-09-23 12:27:48 --> Output Class Initialized
DEBUG - 2011-09-23 12:27:48 --> Input Class Initialized
DEBUG - 2011-09-23 12:27:48 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-23 12:27:48 --> Language Class Initialized
DEBUG - 2011-09-23 12:27:48 --> Loader Class Initialized
DEBUG - 2011-09-23 12:27:48 --> Controller Class Initialized
DEBUG - 2011-09-23 12:27:48 --> Model Class Initialized
DEBUG - 2011-09-23 12:27:48 --> Model Class Initialized
DEBUG - 2011-09-23 12:27:48 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-23 12:27:48 --> Database Driver Class Initialized
DEBUG - 2011-09-23 12:27:48 --> Final output sent to browser
DEBUG - 2011-09-23 12:27:48 --> Total execution time: 0.4967
DEBUG - 2011-09-23 12:27:51 --> Config Class Initialized
DEBUG - 2011-09-23 12:27:51 --> Hooks Class Initialized
DEBUG - 2011-09-23 12:27:51 --> Utf8 Class Initialized
DEBUG - 2011-09-23 12:27:51 --> UTF-8 Support Enabled
DEBUG - 2011-09-23 12:27:51 --> URI Class Initialized
DEBUG - 2011-09-23 12:27:51 --> Router Class Initialized
ERROR - 2011-09-23 12:27:51 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-23 12:27:54 --> Config Class Initialized
DEBUG - 2011-09-23 12:27:54 --> Hooks Class Initialized
DEBUG - 2011-09-23 12:27:54 --> Utf8 Class Initialized
DEBUG - 2011-09-23 12:27:54 --> UTF-8 Support Enabled
DEBUG - 2011-09-23 12:27:54 --> URI Class Initialized
DEBUG - 2011-09-23 12:27:54 --> Router Class Initialized
DEBUG - 2011-09-23 12:27:54 --> Output Class Initialized
DEBUG - 2011-09-23 12:27:54 --> Input Class Initialized
DEBUG - 2011-09-23 12:27:54 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-23 12:27:54 --> Language Class Initialized
DEBUG - 2011-09-23 12:27:54 --> Loader Class Initialized
DEBUG - 2011-09-23 12:27:54 --> Controller Class Initialized
ERROR - 2011-09-23 12:27:54 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-23 12:27:54 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-23 12:27:54 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-23 12:27:54 --> Model Class Initialized
DEBUG - 2011-09-23 12:27:54 --> Model Class Initialized
DEBUG - 2011-09-23 12:27:54 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-23 12:27:54 --> Database Driver Class Initialized
DEBUG - 2011-09-23 12:27:54 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-23 12:27:54 --> Helper loaded: url_helper
DEBUG - 2011-09-23 12:27:54 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-23 12:27:54 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-23 12:27:54 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-23 12:27:54 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-23 12:27:54 --> Final output sent to browser
DEBUG - 2011-09-23 12:27:54 --> Total execution time: 0.0317
DEBUG - 2011-09-23 12:27:55 --> Config Class Initialized
DEBUG - 2011-09-23 12:27:55 --> Hooks Class Initialized
DEBUG - 2011-09-23 12:27:55 --> Utf8 Class Initialized
DEBUG - 2011-09-23 12:27:55 --> UTF-8 Support Enabled
DEBUG - 2011-09-23 12:27:55 --> URI Class Initialized
DEBUG - 2011-09-23 12:27:55 --> Router Class Initialized
DEBUG - 2011-09-23 12:27:55 --> Output Class Initialized
DEBUG - 2011-09-23 12:27:55 --> Input Class Initialized
DEBUG - 2011-09-23 12:27:55 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-23 12:27:55 --> Language Class Initialized
DEBUG - 2011-09-23 12:27:55 --> Loader Class Initialized
DEBUG - 2011-09-23 12:27:55 --> Controller Class Initialized
DEBUG - 2011-09-23 12:27:55 --> Model Class Initialized
DEBUG - 2011-09-23 12:27:55 --> Model Class Initialized
DEBUG - 2011-09-23 12:27:55 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-23 12:27:55 --> Database Driver Class Initialized
DEBUG - 2011-09-23 12:27:55 --> Final output sent to browser
DEBUG - 2011-09-23 12:27:55 --> Total execution time: 0.5587
DEBUG - 2011-09-23 12:27:57 --> Config Class Initialized
DEBUG - 2011-09-23 12:27:57 --> Hooks Class Initialized
DEBUG - 2011-09-23 12:27:57 --> Utf8 Class Initialized
DEBUG - 2011-09-23 12:27:57 --> UTF-8 Support Enabled
DEBUG - 2011-09-23 12:27:57 --> URI Class Initialized
DEBUG - 2011-09-23 12:27:57 --> Router Class Initialized
ERROR - 2011-09-23 12:27:57 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-23 12:30:52 --> Config Class Initialized
DEBUG - 2011-09-23 12:30:52 --> Hooks Class Initialized
DEBUG - 2011-09-23 12:30:52 --> Utf8 Class Initialized
DEBUG - 2011-09-23 12:30:52 --> UTF-8 Support Enabled
DEBUG - 2011-09-23 12:30:52 --> URI Class Initialized
DEBUG - 2011-09-23 12:30:52 --> Router Class Initialized
DEBUG - 2011-09-23 12:30:52 --> Output Class Initialized
DEBUG - 2011-09-23 12:30:52 --> Input Class Initialized
DEBUG - 2011-09-23 12:30:52 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-23 12:30:52 --> Language Class Initialized
DEBUG - 2011-09-23 12:30:52 --> Loader Class Initialized
DEBUG - 2011-09-23 12:30:52 --> Controller Class Initialized
DEBUG - 2011-09-23 12:30:52 --> Model Class Initialized
DEBUG - 2011-09-23 12:30:52 --> Model Class Initialized
DEBUG - 2011-09-23 12:30:52 --> Model Class Initialized
DEBUG - 2011-09-23 12:30:52 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-23 12:30:52 --> Database Driver Class Initialized
DEBUG - 2011-09-23 12:30:53 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-23 12:30:53 --> Helper loaded: url_helper
DEBUG - 2011-09-23 12:30:53 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-23 12:30:53 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-23 12:30:53 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-23 12:30:53 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-23 12:30:53 --> Final output sent to browser
DEBUG - 2011-09-23 12:30:53 --> Total execution time: 0.6071
DEBUG - 2011-09-23 12:30:55 --> Config Class Initialized
DEBUG - 2011-09-23 12:30:55 --> Hooks Class Initialized
DEBUG - 2011-09-23 12:30:55 --> Utf8 Class Initialized
DEBUG - 2011-09-23 12:30:55 --> UTF-8 Support Enabled
DEBUG - 2011-09-23 12:30:55 --> URI Class Initialized
DEBUG - 2011-09-23 12:30:55 --> Router Class Initialized
DEBUG - 2011-09-23 12:30:55 --> Output Class Initialized
DEBUG - 2011-09-23 12:30:55 --> Input Class Initialized
DEBUG - 2011-09-23 12:30:55 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-23 12:30:55 --> Language Class Initialized
DEBUG - 2011-09-23 12:30:55 --> Loader Class Initialized
DEBUG - 2011-09-23 12:30:55 --> Controller Class Initialized
ERROR - 2011-09-23 12:30:55 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-23 12:30:55 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-23 12:30:55 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-23 12:30:55 --> Model Class Initialized
DEBUG - 2011-09-23 12:30:55 --> Model Class Initialized
DEBUG - 2011-09-23 12:30:55 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-23 12:30:55 --> Database Driver Class Initialized
DEBUG - 2011-09-23 12:30:55 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-23 12:30:55 --> Helper loaded: url_helper
DEBUG - 2011-09-23 12:30:55 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-23 12:30:55 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-23 12:30:55 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-23 12:30:55 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-23 12:30:55 --> Final output sent to browser
DEBUG - 2011-09-23 12:30:55 --> Total execution time: 0.0406
DEBUG - 2011-09-23 13:59:29 --> Config Class Initialized
DEBUG - 2011-09-23 13:59:29 --> Hooks Class Initialized
DEBUG - 2011-09-23 13:59:29 --> Utf8 Class Initialized
DEBUG - 2011-09-23 13:59:29 --> UTF-8 Support Enabled
DEBUG - 2011-09-23 13:59:29 --> URI Class Initialized
DEBUG - 2011-09-23 13:59:29 --> Router Class Initialized
DEBUG - 2011-09-23 13:59:29 --> Output Class Initialized
DEBUG - 2011-09-23 13:59:29 --> Input Class Initialized
DEBUG - 2011-09-23 13:59:29 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-23 13:59:29 --> Language Class Initialized
DEBUG - 2011-09-23 13:59:29 --> Loader Class Initialized
DEBUG - 2011-09-23 13:59:29 --> Controller Class Initialized
ERROR - 2011-09-23 13:59:29 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-23 13:59:29 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-23 13:59:29 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-23 13:59:29 --> Model Class Initialized
DEBUG - 2011-09-23 13:59:29 --> Model Class Initialized
DEBUG - 2011-09-23 13:59:29 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-23 13:59:29 --> Database Driver Class Initialized
DEBUG - 2011-09-23 13:59:30 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-23 13:59:30 --> Helper loaded: url_helper
DEBUG - 2011-09-23 13:59:30 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-23 13:59:30 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-23 13:59:30 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-23 13:59:30 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-23 13:59:30 --> Final output sent to browser
DEBUG - 2011-09-23 13:59:30 --> Total execution time: 0.5787
DEBUG - 2011-09-23 13:59:31 --> Config Class Initialized
DEBUG - 2011-09-23 13:59:31 --> Hooks Class Initialized
DEBUG - 2011-09-23 13:59:31 --> Utf8 Class Initialized
DEBUG - 2011-09-23 13:59:31 --> UTF-8 Support Enabled
DEBUG - 2011-09-23 13:59:31 --> URI Class Initialized
DEBUG - 2011-09-23 13:59:31 --> Router Class Initialized
DEBUG - 2011-09-23 13:59:31 --> Output Class Initialized
DEBUG - 2011-09-23 13:59:31 --> Input Class Initialized
DEBUG - 2011-09-23 13:59:31 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-23 13:59:31 --> Language Class Initialized
DEBUG - 2011-09-23 13:59:31 --> Loader Class Initialized
DEBUG - 2011-09-23 13:59:31 --> Controller Class Initialized
DEBUG - 2011-09-23 13:59:31 --> Model Class Initialized
DEBUG - 2011-09-23 13:59:31 --> Model Class Initialized
DEBUG - 2011-09-23 13:59:31 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-23 13:59:31 --> Database Driver Class Initialized
DEBUG - 2011-09-23 13:59:32 --> Final output sent to browser
DEBUG - 2011-09-23 13:59:32 --> Total execution time: 0.6937
DEBUG - 2011-09-23 13:59:34 --> Config Class Initialized
DEBUG - 2011-09-23 13:59:34 --> Hooks Class Initialized
DEBUG - 2011-09-23 13:59:34 --> Utf8 Class Initialized
DEBUG - 2011-09-23 13:59:34 --> UTF-8 Support Enabled
DEBUG - 2011-09-23 13:59:34 --> URI Class Initialized
DEBUG - 2011-09-23 13:59:34 --> Router Class Initialized
ERROR - 2011-09-23 13:59:34 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-23 13:59:35 --> Config Class Initialized
DEBUG - 2011-09-23 13:59:35 --> Hooks Class Initialized
DEBUG - 2011-09-23 13:59:35 --> Utf8 Class Initialized
DEBUG - 2011-09-23 13:59:35 --> UTF-8 Support Enabled
DEBUG - 2011-09-23 13:59:35 --> URI Class Initialized
DEBUG - 2011-09-23 13:59:35 --> Router Class Initialized
ERROR - 2011-09-23 13:59:35 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-23 14:24:35 --> Config Class Initialized
DEBUG - 2011-09-23 14:24:35 --> Hooks Class Initialized
DEBUG - 2011-09-23 14:24:35 --> Utf8 Class Initialized
DEBUG - 2011-09-23 14:24:35 --> UTF-8 Support Enabled
DEBUG - 2011-09-23 14:24:35 --> URI Class Initialized
DEBUG - 2011-09-23 14:24:35 --> Router Class Initialized
DEBUG - 2011-09-23 14:24:35 --> No URI present. Default controller set.
DEBUG - 2011-09-23 14:24:35 --> Output Class Initialized
DEBUG - 2011-09-23 14:24:35 --> Input Class Initialized
DEBUG - 2011-09-23 14:24:35 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-23 14:24:35 --> Language Class Initialized
DEBUG - 2011-09-23 14:24:35 --> Loader Class Initialized
DEBUG - 2011-09-23 14:24:35 --> Controller Class Initialized
DEBUG - 2011-09-23 14:24:35 --> File loaded: application/views/splash/main.php
DEBUG - 2011-09-23 14:24:35 --> Helper loaded: url_helper
DEBUG - 2011-09-23 14:24:35 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-23 14:24:35 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-23 14:24:35 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-23 14:24:35 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-23 14:24:35 --> Final output sent to browser
DEBUG - 2011-09-23 14:24:35 --> Total execution time: 0.0725
DEBUG - 2011-09-23 14:41:37 --> Config Class Initialized
DEBUG - 2011-09-23 14:41:37 --> Hooks Class Initialized
DEBUG - 2011-09-23 14:41:37 --> Utf8 Class Initialized
DEBUG - 2011-09-23 14:41:37 --> UTF-8 Support Enabled
DEBUG - 2011-09-23 14:41:37 --> URI Class Initialized
DEBUG - 2011-09-23 14:41:37 --> Router Class Initialized
DEBUG - 2011-09-23 14:41:37 --> Output Class Initialized
DEBUG - 2011-09-23 14:41:37 --> Input Class Initialized
DEBUG - 2011-09-23 14:41:37 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-23 14:41:37 --> Language Class Initialized
DEBUG - 2011-09-23 14:41:37 --> Loader Class Initialized
DEBUG - 2011-09-23 14:41:37 --> Controller Class Initialized
DEBUG - 2011-09-23 14:41:37 --> Model Class Initialized
DEBUG - 2011-09-23 14:41:37 --> Model Class Initialized
DEBUG - 2011-09-23 14:41:37 --> Model Class Initialized
DEBUG - 2011-09-23 14:41:37 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-23 14:41:37 --> Database Driver Class Initialized
DEBUG - 2011-09-23 14:41:40 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-23 14:41:40 --> Helper loaded: url_helper
DEBUG - 2011-09-23 14:41:40 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-23 14:41:40 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-23 14:41:40 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-23 14:41:40 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-23 14:41:40 --> Final output sent to browser
DEBUG - 2011-09-23 14:41:40 --> Total execution time: 3.2909
DEBUG - 2011-09-23 15:00:40 --> Config Class Initialized
DEBUG - 2011-09-23 15:00:40 --> Hooks Class Initialized
DEBUG - 2011-09-23 15:00:40 --> Utf8 Class Initialized
DEBUG - 2011-09-23 15:00:40 --> UTF-8 Support Enabled
DEBUG - 2011-09-23 15:00:40 --> URI Class Initialized
DEBUG - 2011-09-23 15:00:40 --> Router Class Initialized
DEBUG - 2011-09-23 15:00:40 --> Output Class Initialized
DEBUG - 2011-09-23 15:00:40 --> Input Class Initialized
DEBUG - 2011-09-23 15:00:40 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-23 15:00:40 --> Language Class Initialized
DEBUG - 2011-09-23 15:00:40 --> Loader Class Initialized
DEBUG - 2011-09-23 15:00:40 --> Controller Class Initialized
ERROR - 2011-09-23 15:00:40 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-23 15:00:40 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-23 15:00:40 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-23 15:00:40 --> Model Class Initialized
DEBUG - 2011-09-23 15:00:40 --> Model Class Initialized
DEBUG - 2011-09-23 15:00:40 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-23 15:00:40 --> Database Driver Class Initialized
DEBUG - 2011-09-23 15:00:40 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-23 15:00:40 --> Helper loaded: url_helper
DEBUG - 2011-09-23 15:00:40 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-23 15:00:40 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-23 15:00:40 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-23 15:00:40 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-23 15:00:40 --> Final output sent to browser
DEBUG - 2011-09-23 15:00:40 --> Total execution time: 0.1094
DEBUG - 2011-09-23 15:00:41 --> Config Class Initialized
DEBUG - 2011-09-23 15:00:41 --> Hooks Class Initialized
DEBUG - 2011-09-23 15:00:41 --> Utf8 Class Initialized
DEBUG - 2011-09-23 15:00:41 --> UTF-8 Support Enabled
DEBUG - 2011-09-23 15:00:41 --> URI Class Initialized
DEBUG - 2011-09-23 15:00:41 --> Router Class Initialized
DEBUG - 2011-09-23 15:00:41 --> Output Class Initialized
DEBUG - 2011-09-23 15:00:41 --> Input Class Initialized
DEBUG - 2011-09-23 15:00:41 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-23 15:00:41 --> Language Class Initialized
DEBUG - 2011-09-23 15:00:41 --> Loader Class Initialized
DEBUG - 2011-09-23 15:00:41 --> Controller Class Initialized
DEBUG - 2011-09-23 15:00:41 --> Model Class Initialized
DEBUG - 2011-09-23 15:00:41 --> Model Class Initialized
DEBUG - 2011-09-23 15:00:41 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-23 15:00:41 --> Database Driver Class Initialized
DEBUG - 2011-09-23 15:00:41 --> Final output sent to browser
DEBUG - 2011-09-23 15:00:41 --> Total execution time: 0.6366
DEBUG - 2011-09-23 15:00:43 --> Config Class Initialized
DEBUG - 2011-09-23 15:00:43 --> Hooks Class Initialized
DEBUG - 2011-09-23 15:00:43 --> Utf8 Class Initialized
DEBUG - 2011-09-23 15:00:43 --> UTF-8 Support Enabled
DEBUG - 2011-09-23 15:00:43 --> URI Class Initialized
DEBUG - 2011-09-23 15:00:43 --> Router Class Initialized
ERROR - 2011-09-23 15:00:43 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-23 15:00:44 --> Config Class Initialized
DEBUG - 2011-09-23 15:00:44 --> Hooks Class Initialized
DEBUG - 2011-09-23 15:00:44 --> Utf8 Class Initialized
DEBUG - 2011-09-23 15:00:44 --> UTF-8 Support Enabled
DEBUG - 2011-09-23 15:00:44 --> URI Class Initialized
DEBUG - 2011-09-23 15:00:44 --> Router Class Initialized
ERROR - 2011-09-23 15:00:44 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-23 15:00:44 --> Config Class Initialized
DEBUG - 2011-09-23 15:00:44 --> Hooks Class Initialized
DEBUG - 2011-09-23 15:00:44 --> Utf8 Class Initialized
DEBUG - 2011-09-23 15:00:44 --> UTF-8 Support Enabled
DEBUG - 2011-09-23 15:00:44 --> URI Class Initialized
DEBUG - 2011-09-23 15:00:44 --> Router Class Initialized
ERROR - 2011-09-23 15:00:44 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-23 15:36:45 --> Config Class Initialized
DEBUG - 2011-09-23 15:36:45 --> Hooks Class Initialized
DEBUG - 2011-09-23 15:36:45 --> Utf8 Class Initialized
DEBUG - 2011-09-23 15:36:45 --> UTF-8 Support Enabled
DEBUG - 2011-09-23 15:36:45 --> URI Class Initialized
DEBUG - 2011-09-23 15:36:45 --> Router Class Initialized
DEBUG - 2011-09-23 15:36:45 --> Output Class Initialized
DEBUG - 2011-09-23 15:36:45 --> Input Class Initialized
DEBUG - 2011-09-23 15:36:45 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-23 15:36:45 --> Language Class Initialized
DEBUG - 2011-09-23 15:36:46 --> Loader Class Initialized
DEBUG - 2011-09-23 15:36:46 --> Controller Class Initialized
DEBUG - 2011-09-23 15:36:46 --> Model Class Initialized
DEBUG - 2011-09-23 15:36:46 --> Model Class Initialized
DEBUG - 2011-09-23 15:36:46 --> Model Class Initialized
DEBUG - 2011-09-23 15:36:46 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-23 15:36:46 --> Database Driver Class Initialized
DEBUG - 2011-09-23 15:36:48 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-23 15:36:48 --> Helper loaded: url_helper
DEBUG - 2011-09-23 15:36:48 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-23 15:36:48 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-23 15:36:48 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-23 15:36:48 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-23 15:36:48 --> Final output sent to browser
DEBUG - 2011-09-23 15:36:48 --> Total execution time: 3.4727
DEBUG - 2011-09-23 15:36:50 --> Config Class Initialized
DEBUG - 2011-09-23 15:36:50 --> Hooks Class Initialized
DEBUG - 2011-09-23 15:36:50 --> Utf8 Class Initialized
DEBUG - 2011-09-23 15:36:50 --> UTF-8 Support Enabled
DEBUG - 2011-09-23 15:36:50 --> URI Class Initialized
DEBUG - 2011-09-23 15:36:50 --> Router Class Initialized
DEBUG - 2011-09-23 15:36:50 --> Output Class Initialized
DEBUG - 2011-09-23 15:36:50 --> Input Class Initialized
DEBUG - 2011-09-23 15:36:50 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-23 15:36:50 --> Language Class Initialized
DEBUG - 2011-09-23 15:36:50 --> Loader Class Initialized
DEBUG - 2011-09-23 15:36:50 --> Controller Class Initialized
ERROR - 2011-09-23 15:36:50 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-23 15:36:50 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-23 15:36:50 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-23 15:36:50 --> Model Class Initialized
DEBUG - 2011-09-23 15:36:50 --> Model Class Initialized
DEBUG - 2011-09-23 15:36:50 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-23 15:36:50 --> Database Driver Class Initialized
DEBUG - 2011-09-23 15:36:50 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-23 15:36:50 --> Helper loaded: url_helper
DEBUG - 2011-09-23 15:36:50 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-23 15:36:50 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-23 15:36:50 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-23 15:36:50 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-23 15:36:50 --> Final output sent to browser
DEBUG - 2011-09-23 15:36:50 --> Total execution time: 0.0327
DEBUG - 2011-09-23 18:04:07 --> Config Class Initialized
DEBUG - 2011-09-23 18:04:07 --> Hooks Class Initialized
DEBUG - 2011-09-23 18:04:07 --> Utf8 Class Initialized
DEBUG - 2011-09-23 18:04:07 --> UTF-8 Support Enabled
DEBUG - 2011-09-23 18:04:07 --> URI Class Initialized
DEBUG - 2011-09-23 18:04:07 --> Router Class Initialized
DEBUG - 2011-09-23 18:04:07 --> Output Class Initialized
DEBUG - 2011-09-23 18:04:07 --> Input Class Initialized
DEBUG - 2011-09-23 18:04:07 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-23 18:04:07 --> Language Class Initialized
DEBUG - 2011-09-23 18:04:07 --> Loader Class Initialized
DEBUG - 2011-09-23 18:04:07 --> Controller Class Initialized
ERROR - 2011-09-23 18:04:07 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-23 18:04:07 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-23 18:04:07 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-23 18:04:07 --> Model Class Initialized
DEBUG - 2011-09-23 18:04:07 --> Model Class Initialized
DEBUG - 2011-09-23 18:04:07 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-23 18:04:07 --> Database Driver Class Initialized
DEBUG - 2011-09-23 18:04:07 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-23 18:04:07 --> Helper loaded: url_helper
DEBUG - 2011-09-23 18:04:07 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-23 18:04:07 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-23 18:04:07 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-23 18:04:07 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-23 18:04:07 --> Final output sent to browser
DEBUG - 2011-09-23 18:04:07 --> Total execution time: 0.4694
DEBUG - 2011-09-23 18:04:10 --> Config Class Initialized
DEBUG - 2011-09-23 18:04:10 --> Hooks Class Initialized
DEBUG - 2011-09-23 18:04:10 --> Utf8 Class Initialized
DEBUG - 2011-09-23 18:04:10 --> UTF-8 Support Enabled
DEBUG - 2011-09-23 18:04:10 --> URI Class Initialized
DEBUG - 2011-09-23 18:04:10 --> Router Class Initialized
DEBUG - 2011-09-23 18:04:10 --> Output Class Initialized
DEBUG - 2011-09-23 18:04:10 --> Input Class Initialized
DEBUG - 2011-09-23 18:04:10 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-23 18:04:10 --> Language Class Initialized
DEBUG - 2011-09-23 18:04:10 --> Loader Class Initialized
DEBUG - 2011-09-23 18:04:10 --> Controller Class Initialized
DEBUG - 2011-09-23 18:04:10 --> Model Class Initialized
DEBUG - 2011-09-23 18:04:10 --> Model Class Initialized
DEBUG - 2011-09-23 18:04:10 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-23 18:04:10 --> Database Driver Class Initialized
DEBUG - 2011-09-23 18:04:11 --> Final output sent to browser
DEBUG - 2011-09-23 18:04:11 --> Total execution time: 0.8166
DEBUG - 2011-09-23 18:27:16 --> Config Class Initialized
DEBUG - 2011-09-23 18:27:16 --> Hooks Class Initialized
DEBUG - 2011-09-23 18:27:16 --> Utf8 Class Initialized
DEBUG - 2011-09-23 18:27:16 --> UTF-8 Support Enabled
DEBUG - 2011-09-23 18:27:16 --> URI Class Initialized
DEBUG - 2011-09-23 18:27:16 --> Router Class Initialized
DEBUG - 2011-09-23 18:27:16 --> Output Class Initialized
DEBUG - 2011-09-23 18:27:16 --> Input Class Initialized
DEBUG - 2011-09-23 18:27:16 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-23 18:27:16 --> Language Class Initialized
DEBUG - 2011-09-23 18:27:16 --> Loader Class Initialized
DEBUG - 2011-09-23 18:27:16 --> Controller Class Initialized
ERROR - 2011-09-23 18:27:16 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-23 18:27:16 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-23 18:27:16 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-23 18:27:16 --> Model Class Initialized
DEBUG - 2011-09-23 18:27:16 --> Model Class Initialized
DEBUG - 2011-09-23 18:27:16 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-23 18:27:16 --> Database Driver Class Initialized
DEBUG - 2011-09-23 18:27:16 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-23 18:27:16 --> Helper loaded: url_helper
DEBUG - 2011-09-23 18:27:16 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-23 18:27:16 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-23 18:27:16 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-23 18:27:16 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-23 18:27:16 --> Final output sent to browser
DEBUG - 2011-09-23 18:27:16 --> Total execution time: 0.0718
DEBUG - 2011-09-23 18:27:20 --> Config Class Initialized
DEBUG - 2011-09-23 18:27:20 --> Hooks Class Initialized
DEBUG - 2011-09-23 18:27:20 --> Utf8 Class Initialized
DEBUG - 2011-09-23 18:27:20 --> UTF-8 Support Enabled
DEBUG - 2011-09-23 18:27:20 --> URI Class Initialized
DEBUG - 2011-09-23 18:27:20 --> Router Class Initialized
DEBUG - 2011-09-23 18:27:20 --> Output Class Initialized
DEBUG - 2011-09-23 18:27:20 --> Input Class Initialized
DEBUG - 2011-09-23 18:27:20 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-23 18:27:20 --> Language Class Initialized
DEBUG - 2011-09-23 18:27:20 --> Loader Class Initialized
DEBUG - 2011-09-23 18:27:20 --> Controller Class Initialized
DEBUG - 2011-09-23 18:27:20 --> Model Class Initialized
DEBUG - 2011-09-23 18:27:20 --> Model Class Initialized
DEBUG - 2011-09-23 18:27:20 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-23 18:27:20 --> Database Driver Class Initialized
DEBUG - 2011-09-23 18:27:20 --> Final output sent to browser
DEBUG - 2011-09-23 18:27:20 --> Total execution time: 0.6153
DEBUG - 2011-09-23 18:27:23 --> Config Class Initialized
DEBUG - 2011-09-23 18:27:23 --> Hooks Class Initialized
DEBUG - 2011-09-23 18:27:23 --> Utf8 Class Initialized
DEBUG - 2011-09-23 18:27:23 --> UTF-8 Support Enabled
DEBUG - 2011-09-23 18:27:23 --> URI Class Initialized
DEBUG - 2011-09-23 18:27:23 --> Router Class Initialized
ERROR - 2011-09-23 18:27:23 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-23 18:28:37 --> Config Class Initialized
DEBUG - 2011-09-23 18:28:37 --> Hooks Class Initialized
DEBUG - 2011-09-23 18:28:37 --> Utf8 Class Initialized
DEBUG - 2011-09-23 18:28:37 --> UTF-8 Support Enabled
DEBUG - 2011-09-23 18:28:37 --> URI Class Initialized
DEBUG - 2011-09-23 18:28:37 --> Router Class Initialized
DEBUG - 2011-09-23 18:28:37 --> Output Class Initialized
DEBUG - 2011-09-23 18:28:37 --> Input Class Initialized
DEBUG - 2011-09-23 18:28:37 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-23 18:28:37 --> Language Class Initialized
DEBUG - 2011-09-23 18:28:37 --> Loader Class Initialized
DEBUG - 2011-09-23 18:28:37 --> Controller Class Initialized
ERROR - 2011-09-23 18:28:37 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-23 18:28:37 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-23 18:28:37 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-23 18:28:37 --> Model Class Initialized
DEBUG - 2011-09-23 18:28:37 --> Model Class Initialized
DEBUG - 2011-09-23 18:28:37 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-23 18:28:37 --> Database Driver Class Initialized
DEBUG - 2011-09-23 18:28:38 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-23 18:28:38 --> Helper loaded: url_helper
DEBUG - 2011-09-23 18:28:38 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-23 18:28:38 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-23 18:28:38 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-23 18:28:38 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-23 18:28:38 --> Final output sent to browser
DEBUG - 2011-09-23 18:28:38 --> Total execution time: 0.0363
DEBUG - 2011-09-23 18:28:39 --> Config Class Initialized
DEBUG - 2011-09-23 18:28:39 --> Hooks Class Initialized
DEBUG - 2011-09-23 18:28:39 --> Utf8 Class Initialized
DEBUG - 2011-09-23 18:28:39 --> UTF-8 Support Enabled
DEBUG - 2011-09-23 18:28:39 --> URI Class Initialized
DEBUG - 2011-09-23 18:28:39 --> Router Class Initialized
DEBUG - 2011-09-23 18:28:39 --> Output Class Initialized
DEBUG - 2011-09-23 18:28:39 --> Input Class Initialized
DEBUG - 2011-09-23 18:28:39 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-23 18:28:39 --> Language Class Initialized
DEBUG - 2011-09-23 18:28:39 --> Loader Class Initialized
DEBUG - 2011-09-23 18:28:39 --> Controller Class Initialized
DEBUG - 2011-09-23 18:28:39 --> Model Class Initialized
DEBUG - 2011-09-23 18:28:39 --> Model Class Initialized
DEBUG - 2011-09-23 18:28:39 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-23 18:28:39 --> Database Driver Class Initialized
DEBUG - 2011-09-23 18:28:39 --> Final output sent to browser
DEBUG - 2011-09-23 18:28:39 --> Total execution time: 0.6029
DEBUG - 2011-09-23 18:28:41 --> Config Class Initialized
DEBUG - 2011-09-23 18:28:41 --> Hooks Class Initialized
DEBUG - 2011-09-23 18:28:41 --> Utf8 Class Initialized
DEBUG - 2011-09-23 18:28:41 --> UTF-8 Support Enabled
DEBUG - 2011-09-23 18:28:41 --> URI Class Initialized
DEBUG - 2011-09-23 18:28:41 --> Router Class Initialized
ERROR - 2011-09-23 18:28:41 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-23 18:28:49 --> Config Class Initialized
DEBUG - 2011-09-23 18:28:49 --> Hooks Class Initialized
DEBUG - 2011-09-23 18:28:49 --> Utf8 Class Initialized
DEBUG - 2011-09-23 18:28:49 --> UTF-8 Support Enabled
DEBUG - 2011-09-23 18:28:49 --> URI Class Initialized
DEBUG - 2011-09-23 18:28:49 --> Router Class Initialized
DEBUG - 2011-09-23 18:28:49 --> Output Class Initialized
DEBUG - 2011-09-23 18:28:49 --> Input Class Initialized
DEBUG - 2011-09-23 18:28:49 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-23 18:28:49 --> Language Class Initialized
DEBUG - 2011-09-23 18:28:49 --> Loader Class Initialized
DEBUG - 2011-09-23 18:28:49 --> Controller Class Initialized
ERROR - 2011-09-23 18:28:49 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-23 18:28:49 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-23 18:28:49 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-23 18:28:49 --> Model Class Initialized
DEBUG - 2011-09-23 18:28:49 --> Model Class Initialized
DEBUG - 2011-09-23 18:28:49 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-23 18:28:49 --> Database Driver Class Initialized
DEBUG - 2011-09-23 18:28:49 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-23 18:28:49 --> Helper loaded: url_helper
DEBUG - 2011-09-23 18:28:49 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-23 18:28:49 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-23 18:28:49 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-23 18:28:49 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-23 18:28:49 --> Final output sent to browser
DEBUG - 2011-09-23 18:28:49 --> Total execution time: 0.1495
DEBUG - 2011-09-23 18:28:50 --> Config Class Initialized
DEBUG - 2011-09-23 18:28:50 --> Hooks Class Initialized
DEBUG - 2011-09-23 18:28:50 --> Utf8 Class Initialized
DEBUG - 2011-09-23 18:28:50 --> UTF-8 Support Enabled
DEBUG - 2011-09-23 18:28:50 --> URI Class Initialized
DEBUG - 2011-09-23 18:28:50 --> Router Class Initialized
DEBUG - 2011-09-23 18:28:50 --> Output Class Initialized
DEBUG - 2011-09-23 18:28:50 --> Input Class Initialized
DEBUG - 2011-09-23 18:28:50 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-23 18:28:50 --> Language Class Initialized
DEBUG - 2011-09-23 18:28:50 --> Loader Class Initialized
DEBUG - 2011-09-23 18:28:50 --> Controller Class Initialized
DEBUG - 2011-09-23 18:28:50 --> Model Class Initialized
DEBUG - 2011-09-23 18:28:50 --> Model Class Initialized
DEBUG - 2011-09-23 18:28:50 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-23 18:28:50 --> Database Driver Class Initialized
DEBUG - 2011-09-23 18:28:50 --> Final output sent to browser
DEBUG - 2011-09-23 18:28:50 --> Total execution time: 0.6436
DEBUG - 2011-09-23 18:28:52 --> Config Class Initialized
DEBUG - 2011-09-23 18:28:52 --> Hooks Class Initialized
DEBUG - 2011-09-23 18:28:52 --> Utf8 Class Initialized
DEBUG - 2011-09-23 18:28:52 --> UTF-8 Support Enabled
DEBUG - 2011-09-23 18:28:52 --> URI Class Initialized
DEBUG - 2011-09-23 18:28:52 --> Router Class Initialized
ERROR - 2011-09-23 18:28:52 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-23 18:29:09 --> Config Class Initialized
DEBUG - 2011-09-23 18:29:09 --> Hooks Class Initialized
DEBUG - 2011-09-23 18:29:09 --> Utf8 Class Initialized
DEBUG - 2011-09-23 18:29:09 --> UTF-8 Support Enabled
DEBUG - 2011-09-23 18:29:09 --> URI Class Initialized
DEBUG - 2011-09-23 18:29:09 --> Router Class Initialized
DEBUG - 2011-09-23 18:29:09 --> Output Class Initialized
DEBUG - 2011-09-23 18:29:09 --> Input Class Initialized
DEBUG - 2011-09-23 18:29:09 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-23 18:29:09 --> Language Class Initialized
DEBUG - 2011-09-23 18:29:09 --> Loader Class Initialized
DEBUG - 2011-09-23 18:29:09 --> Controller Class Initialized
ERROR - 2011-09-23 18:29:09 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-23 18:29:09 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-23 18:29:09 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-23 18:29:09 --> Model Class Initialized
DEBUG - 2011-09-23 18:29:09 --> Model Class Initialized
DEBUG - 2011-09-23 18:29:09 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-23 18:29:09 --> Database Driver Class Initialized
DEBUG - 2011-09-23 18:29:09 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-23 18:29:09 --> Helper loaded: url_helper
DEBUG - 2011-09-23 18:29:09 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-23 18:29:09 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-23 18:29:09 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-23 18:29:09 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-23 18:29:09 --> Final output sent to browser
DEBUG - 2011-09-23 18:29:09 --> Total execution time: 0.0360
DEBUG - 2011-09-23 18:29:10 --> Config Class Initialized
DEBUG - 2011-09-23 18:29:10 --> Hooks Class Initialized
DEBUG - 2011-09-23 18:29:10 --> Utf8 Class Initialized
DEBUG - 2011-09-23 18:29:10 --> UTF-8 Support Enabled
DEBUG - 2011-09-23 18:29:10 --> URI Class Initialized
DEBUG - 2011-09-23 18:29:10 --> Router Class Initialized
DEBUG - 2011-09-23 18:29:10 --> Output Class Initialized
DEBUG - 2011-09-23 18:29:10 --> Input Class Initialized
DEBUG - 2011-09-23 18:29:10 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-23 18:29:10 --> Language Class Initialized
DEBUG - 2011-09-23 18:29:10 --> Loader Class Initialized
DEBUG - 2011-09-23 18:29:10 --> Controller Class Initialized
DEBUG - 2011-09-23 18:29:10 --> Model Class Initialized
DEBUG - 2011-09-23 18:29:10 --> Model Class Initialized
DEBUG - 2011-09-23 18:29:10 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-23 18:29:10 --> Database Driver Class Initialized
DEBUG - 2011-09-23 18:29:11 --> Final output sent to browser
DEBUG - 2011-09-23 18:29:11 --> Total execution time: 0.6535
DEBUG - 2011-09-23 18:29:12 --> Config Class Initialized
DEBUG - 2011-09-23 18:29:12 --> Hooks Class Initialized
DEBUG - 2011-09-23 18:29:12 --> Utf8 Class Initialized
DEBUG - 2011-09-23 18:29:12 --> UTF-8 Support Enabled
DEBUG - 2011-09-23 18:29:12 --> URI Class Initialized
DEBUG - 2011-09-23 18:29:12 --> Router Class Initialized
ERROR - 2011-09-23 18:29:12 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-23 19:15:23 --> Config Class Initialized
DEBUG - 2011-09-23 19:15:24 --> Hooks Class Initialized
DEBUG - 2011-09-23 19:15:24 --> Utf8 Class Initialized
DEBUG - 2011-09-23 19:15:24 --> UTF-8 Support Enabled
DEBUG - 2011-09-23 19:15:24 --> URI Class Initialized
DEBUG - 2011-09-23 19:15:24 --> Router Class Initialized
DEBUG - 2011-09-23 19:15:24 --> Output Class Initialized
DEBUG - 2011-09-23 19:15:24 --> Input Class Initialized
DEBUG - 2011-09-23 19:15:24 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-23 19:15:24 --> Language Class Initialized
DEBUG - 2011-09-23 19:15:24 --> Loader Class Initialized
DEBUG - 2011-09-23 19:15:24 --> Controller Class Initialized
DEBUG - 2011-09-23 19:15:24 --> Model Class Initialized
DEBUG - 2011-09-23 19:15:24 --> Model Class Initialized
DEBUG - 2011-09-23 19:15:24 --> Model Class Initialized
DEBUG - 2011-09-23 19:15:24 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-23 19:15:24 --> Database Driver Class Initialized
DEBUG - 2011-09-23 19:15:25 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-23 19:15:25 --> Helper loaded: url_helper
DEBUG - 2011-09-23 19:15:25 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-23 19:15:25 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-23 19:15:25 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-23 19:15:25 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-23 19:15:25 --> Final output sent to browser
DEBUG - 2011-09-23 19:15:25 --> Total execution time: 1.1986
DEBUG - 2011-09-23 19:15:28 --> Config Class Initialized
DEBUG - 2011-09-23 19:15:28 --> Hooks Class Initialized
DEBUG - 2011-09-23 19:15:28 --> Utf8 Class Initialized
DEBUG - 2011-09-23 19:15:28 --> UTF-8 Support Enabled
DEBUG - 2011-09-23 19:15:28 --> URI Class Initialized
DEBUG - 2011-09-23 19:15:28 --> Router Class Initialized
ERROR - 2011-09-23 19:15:28 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-23 19:15:44 --> Config Class Initialized
DEBUG - 2011-09-23 19:15:44 --> Hooks Class Initialized
DEBUG - 2011-09-23 19:15:44 --> Utf8 Class Initialized
DEBUG - 2011-09-23 19:15:44 --> UTF-8 Support Enabled
DEBUG - 2011-09-23 19:15:44 --> URI Class Initialized
DEBUG - 2011-09-23 19:15:44 --> Router Class Initialized
DEBUG - 2011-09-23 19:15:44 --> Output Class Initialized
DEBUG - 2011-09-23 19:15:44 --> Input Class Initialized
DEBUG - 2011-09-23 19:15:44 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-23 19:15:44 --> Language Class Initialized
DEBUG - 2011-09-23 19:15:44 --> Loader Class Initialized
DEBUG - 2011-09-23 19:15:44 --> Controller Class Initialized
DEBUG - 2011-09-23 19:15:44 --> Model Class Initialized
DEBUG - 2011-09-23 19:15:44 --> Model Class Initialized
DEBUG - 2011-09-23 19:15:44 --> Model Class Initialized
DEBUG - 2011-09-23 19:15:44 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-23 19:15:44 --> Database Driver Class Initialized
DEBUG - 2011-09-23 19:15:45 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-23 19:15:45 --> Helper loaded: url_helper
DEBUG - 2011-09-23 19:15:45 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-23 19:15:45 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-23 19:15:45 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-23 19:15:45 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-23 19:15:45 --> Final output sent to browser
DEBUG - 2011-09-23 19:15:45 --> Total execution time: 0.7452
DEBUG - 2011-09-23 19:18:14 --> Config Class Initialized
DEBUG - 2011-09-23 19:18:14 --> Hooks Class Initialized
DEBUG - 2011-09-23 19:18:14 --> Utf8 Class Initialized
DEBUG - 2011-09-23 19:18:14 --> UTF-8 Support Enabled
DEBUG - 2011-09-23 19:18:14 --> URI Class Initialized
DEBUG - 2011-09-23 19:18:14 --> Router Class Initialized
DEBUG - 2011-09-23 19:18:14 --> Output Class Initialized
DEBUG - 2011-09-23 19:18:14 --> Input Class Initialized
DEBUG - 2011-09-23 19:18:14 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-23 19:18:14 --> Language Class Initialized
DEBUG - 2011-09-23 19:18:14 --> Loader Class Initialized
DEBUG - 2011-09-23 19:18:14 --> Controller Class Initialized
DEBUG - 2011-09-23 19:18:14 --> Model Class Initialized
DEBUG - 2011-09-23 19:18:14 --> Model Class Initialized
DEBUG - 2011-09-23 19:18:14 --> Model Class Initialized
DEBUG - 2011-09-23 19:18:14 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-23 19:18:14 --> Database Driver Class Initialized
DEBUG - 2011-09-23 19:18:15 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-23 19:18:15 --> Helper loaded: url_helper
DEBUG - 2011-09-23 19:18:15 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-23 19:18:15 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-23 19:18:15 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-23 19:18:15 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-23 19:18:15 --> Final output sent to browser
DEBUG - 2011-09-23 19:18:15 --> Total execution time: 0.2745
DEBUG - 2011-09-23 19:19:17 --> Config Class Initialized
DEBUG - 2011-09-23 19:19:17 --> Hooks Class Initialized
DEBUG - 2011-09-23 19:19:17 --> Utf8 Class Initialized
DEBUG - 2011-09-23 19:19:17 --> UTF-8 Support Enabled
DEBUG - 2011-09-23 19:19:17 --> URI Class Initialized
DEBUG - 2011-09-23 19:19:17 --> Router Class Initialized
DEBUG - 2011-09-23 19:19:17 --> Output Class Initialized
DEBUG - 2011-09-23 19:19:17 --> Input Class Initialized
DEBUG - 2011-09-23 19:19:17 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-23 19:19:17 --> Language Class Initialized
DEBUG - 2011-09-23 19:19:17 --> Loader Class Initialized
DEBUG - 2011-09-23 19:19:17 --> Controller Class Initialized
DEBUG - 2011-09-23 19:19:17 --> Model Class Initialized
DEBUG - 2011-09-23 19:19:17 --> Model Class Initialized
DEBUG - 2011-09-23 19:19:17 --> Model Class Initialized
DEBUG - 2011-09-23 19:19:17 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-23 19:19:17 --> Database Driver Class Initialized
DEBUG - 2011-09-23 19:19:17 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-23 19:19:17 --> Helper loaded: url_helper
DEBUG - 2011-09-23 19:19:17 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-23 19:19:17 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-23 19:19:17 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-23 19:19:17 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-23 19:19:17 --> Final output sent to browser
DEBUG - 2011-09-23 19:19:17 --> Total execution time: 0.3528
DEBUG - 2011-09-23 19:19:39 --> Config Class Initialized
DEBUG - 2011-09-23 19:19:39 --> Hooks Class Initialized
DEBUG - 2011-09-23 19:19:39 --> Utf8 Class Initialized
DEBUG - 2011-09-23 19:19:39 --> UTF-8 Support Enabled
DEBUG - 2011-09-23 19:19:39 --> URI Class Initialized
DEBUG - 2011-09-23 19:19:39 --> Router Class Initialized
DEBUG - 2011-09-23 19:19:39 --> Output Class Initialized
DEBUG - 2011-09-23 19:19:39 --> Input Class Initialized
DEBUG - 2011-09-23 19:19:39 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-23 19:19:39 --> Language Class Initialized
DEBUG - 2011-09-23 19:19:39 --> Loader Class Initialized
DEBUG - 2011-09-23 19:19:39 --> Controller Class Initialized
DEBUG - 2011-09-23 19:19:39 --> Model Class Initialized
DEBUG - 2011-09-23 19:19:39 --> Model Class Initialized
DEBUG - 2011-09-23 19:19:39 --> Model Class Initialized
DEBUG - 2011-09-23 19:19:39 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-23 19:19:39 --> Database Driver Class Initialized
DEBUG - 2011-09-23 19:19:39 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-23 19:19:39 --> Helper loaded: url_helper
DEBUG - 2011-09-23 19:19:39 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-23 19:19:39 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-23 19:19:39 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-23 19:19:39 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-23 19:19:39 --> Final output sent to browser
DEBUG - 2011-09-23 19:19:39 --> Total execution time: 0.3413
DEBUG - 2011-09-23 19:20:57 --> Config Class Initialized
DEBUG - 2011-09-23 19:20:57 --> Hooks Class Initialized
DEBUG - 2011-09-23 19:20:57 --> Utf8 Class Initialized
DEBUG - 2011-09-23 19:20:57 --> UTF-8 Support Enabled
DEBUG - 2011-09-23 19:20:57 --> URI Class Initialized
DEBUG - 2011-09-23 19:20:57 --> Router Class Initialized
DEBUG - 2011-09-23 19:20:57 --> Output Class Initialized
DEBUG - 2011-09-23 19:20:57 --> Input Class Initialized
DEBUG - 2011-09-23 19:20:57 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-23 19:20:57 --> Language Class Initialized
DEBUG - 2011-09-23 19:20:57 --> Loader Class Initialized
DEBUG - 2011-09-23 19:20:57 --> Controller Class Initialized
DEBUG - 2011-09-23 19:20:57 --> Model Class Initialized
DEBUG - 2011-09-23 19:20:57 --> Model Class Initialized
DEBUG - 2011-09-23 19:20:57 --> Model Class Initialized
DEBUG - 2011-09-23 19:20:57 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-23 19:20:57 --> Database Driver Class Initialized
DEBUG - 2011-09-23 19:20:57 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-23 19:20:57 --> Helper loaded: url_helper
DEBUG - 2011-09-23 19:20:57 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-23 19:20:57 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-23 19:20:57 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-23 19:20:57 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-23 19:20:57 --> Final output sent to browser
DEBUG - 2011-09-23 19:20:57 --> Total execution time: 0.2377
DEBUG - 2011-09-23 19:21:11 --> Config Class Initialized
DEBUG - 2011-09-23 19:21:11 --> Hooks Class Initialized
DEBUG - 2011-09-23 19:21:11 --> Utf8 Class Initialized
DEBUG - 2011-09-23 19:21:11 --> UTF-8 Support Enabled
DEBUG - 2011-09-23 19:21:11 --> URI Class Initialized
DEBUG - 2011-09-23 19:21:11 --> Router Class Initialized
DEBUG - 2011-09-23 19:21:11 --> Output Class Initialized
DEBUG - 2011-09-23 19:21:11 --> Input Class Initialized
DEBUG - 2011-09-23 19:21:11 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-23 19:21:11 --> Language Class Initialized
DEBUG - 2011-09-23 19:21:11 --> Loader Class Initialized
DEBUG - 2011-09-23 19:21:11 --> Controller Class Initialized
DEBUG - 2011-09-23 19:21:11 --> Model Class Initialized
DEBUG - 2011-09-23 19:21:11 --> Model Class Initialized
DEBUG - 2011-09-23 19:21:11 --> Model Class Initialized
DEBUG - 2011-09-23 19:21:11 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-23 19:21:11 --> Database Driver Class Initialized
DEBUG - 2011-09-23 19:21:12 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-23 19:21:12 --> Helper loaded: url_helper
DEBUG - 2011-09-23 19:21:12 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-23 19:21:12 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-23 19:21:12 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-23 19:21:12 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-23 19:21:12 --> Final output sent to browser
DEBUG - 2011-09-23 19:21:12 --> Total execution time: 0.2825
DEBUG - 2011-09-23 19:21:31 --> Config Class Initialized
DEBUG - 2011-09-23 19:21:31 --> Hooks Class Initialized
DEBUG - 2011-09-23 19:21:31 --> Utf8 Class Initialized
DEBUG - 2011-09-23 19:21:31 --> UTF-8 Support Enabled
DEBUG - 2011-09-23 19:21:31 --> URI Class Initialized
DEBUG - 2011-09-23 19:21:31 --> Router Class Initialized
DEBUG - 2011-09-23 19:21:31 --> Output Class Initialized
DEBUG - 2011-09-23 19:21:31 --> Input Class Initialized
DEBUG - 2011-09-23 19:21:31 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-23 19:21:31 --> Language Class Initialized
DEBUG - 2011-09-23 19:21:31 --> Loader Class Initialized
DEBUG - 2011-09-23 19:21:31 --> Controller Class Initialized
DEBUG - 2011-09-23 19:21:31 --> Model Class Initialized
DEBUG - 2011-09-23 19:21:31 --> Model Class Initialized
DEBUG - 2011-09-23 19:21:31 --> Model Class Initialized
DEBUG - 2011-09-23 19:21:31 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-23 19:21:31 --> Database Driver Class Initialized
DEBUG - 2011-09-23 19:21:31 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-23 19:21:31 --> Helper loaded: url_helper
DEBUG - 2011-09-23 19:21:31 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-23 19:21:31 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-23 19:21:31 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-23 19:21:31 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-23 19:21:31 --> Final output sent to browser
DEBUG - 2011-09-23 19:21:31 --> Total execution time: 0.3156
DEBUG - 2011-09-23 19:21:45 --> Config Class Initialized
DEBUG - 2011-09-23 19:21:45 --> Hooks Class Initialized
DEBUG - 2011-09-23 19:21:45 --> Utf8 Class Initialized
DEBUG - 2011-09-23 19:21:45 --> UTF-8 Support Enabled
DEBUG - 2011-09-23 19:21:45 --> URI Class Initialized
DEBUG - 2011-09-23 19:21:45 --> Router Class Initialized
DEBUG - 2011-09-23 19:21:45 --> Output Class Initialized
DEBUG - 2011-09-23 19:21:45 --> Input Class Initialized
DEBUG - 2011-09-23 19:21:45 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-23 19:21:45 --> Language Class Initialized
DEBUG - 2011-09-23 19:21:45 --> Loader Class Initialized
DEBUG - 2011-09-23 19:21:45 --> Controller Class Initialized
DEBUG - 2011-09-23 19:21:45 --> Model Class Initialized
DEBUG - 2011-09-23 19:21:45 --> Model Class Initialized
DEBUG - 2011-09-23 19:21:45 --> Model Class Initialized
DEBUG - 2011-09-23 19:21:45 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-23 19:21:45 --> Database Driver Class Initialized
DEBUG - 2011-09-23 19:21:45 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-23 19:21:45 --> Helper loaded: url_helper
DEBUG - 2011-09-23 19:21:45 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-23 19:21:45 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-23 19:21:45 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-23 19:21:45 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-23 19:21:45 --> Final output sent to browser
DEBUG - 2011-09-23 19:21:45 --> Total execution time: 0.1999
DEBUG - 2011-09-23 19:22:28 --> Config Class Initialized
DEBUG - 2011-09-23 19:22:28 --> Hooks Class Initialized
DEBUG - 2011-09-23 19:22:28 --> Utf8 Class Initialized
DEBUG - 2011-09-23 19:22:28 --> UTF-8 Support Enabled
DEBUG - 2011-09-23 19:22:28 --> URI Class Initialized
DEBUG - 2011-09-23 19:22:28 --> Router Class Initialized
DEBUG - 2011-09-23 19:22:28 --> Output Class Initialized
DEBUG - 2011-09-23 19:22:28 --> Input Class Initialized
DEBUG - 2011-09-23 19:22:28 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-23 19:22:28 --> Language Class Initialized
DEBUG - 2011-09-23 19:22:28 --> Loader Class Initialized
DEBUG - 2011-09-23 19:22:28 --> Controller Class Initialized
DEBUG - 2011-09-23 19:22:28 --> Model Class Initialized
DEBUG - 2011-09-23 19:22:28 --> Model Class Initialized
DEBUG - 2011-09-23 19:22:28 --> Model Class Initialized
DEBUG - 2011-09-23 19:22:28 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-23 19:22:28 --> Database Driver Class Initialized
DEBUG - 2011-09-23 19:22:28 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-23 19:22:28 --> Helper loaded: url_helper
DEBUG - 2011-09-23 19:22:28 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-23 19:22:28 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-23 19:22:28 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-23 19:22:28 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-23 19:22:28 --> Final output sent to browser
DEBUG - 2011-09-23 19:22:28 --> Total execution time: 0.3114
DEBUG - 2011-09-23 19:22:48 --> Config Class Initialized
DEBUG - 2011-09-23 19:22:48 --> Hooks Class Initialized
DEBUG - 2011-09-23 19:22:48 --> Utf8 Class Initialized
DEBUG - 2011-09-23 19:22:48 --> UTF-8 Support Enabled
DEBUG - 2011-09-23 19:22:48 --> URI Class Initialized
DEBUG - 2011-09-23 19:22:48 --> Router Class Initialized
DEBUG - 2011-09-23 19:22:48 --> Output Class Initialized
DEBUG - 2011-09-23 19:22:48 --> Input Class Initialized
DEBUG - 2011-09-23 19:22:48 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-23 19:22:48 --> Language Class Initialized
DEBUG - 2011-09-23 19:22:48 --> Loader Class Initialized
DEBUG - 2011-09-23 19:22:48 --> Controller Class Initialized
DEBUG - 2011-09-23 19:22:48 --> Model Class Initialized
DEBUG - 2011-09-23 19:22:48 --> Model Class Initialized
DEBUG - 2011-09-23 19:22:48 --> Model Class Initialized
DEBUG - 2011-09-23 19:22:48 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-23 19:22:48 --> Database Driver Class Initialized
DEBUG - 2011-09-23 19:22:49 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-23 19:22:49 --> Helper loaded: url_helper
DEBUG - 2011-09-23 19:22:49 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-23 19:22:49 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-23 19:22:49 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-23 19:22:49 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-23 19:22:49 --> Final output sent to browser
DEBUG - 2011-09-23 19:22:49 --> Total execution time: 0.7276
DEBUG - 2011-09-23 19:56:31 --> Config Class Initialized
DEBUG - 2011-09-23 19:56:31 --> Hooks Class Initialized
DEBUG - 2011-09-23 19:56:31 --> Utf8 Class Initialized
DEBUG - 2011-09-23 19:56:31 --> UTF-8 Support Enabled
DEBUG - 2011-09-23 19:56:31 --> URI Class Initialized
DEBUG - 2011-09-23 19:56:31 --> Router Class Initialized
DEBUG - 2011-09-23 19:56:31 --> No URI present. Default controller set.
DEBUG - 2011-09-23 19:56:31 --> Output Class Initialized
DEBUG - 2011-09-23 19:56:31 --> Input Class Initialized
DEBUG - 2011-09-23 19:56:31 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-23 19:56:31 --> Language Class Initialized
DEBUG - 2011-09-23 19:56:32 --> Loader Class Initialized
DEBUG - 2011-09-23 19:56:32 --> Controller Class Initialized
DEBUG - 2011-09-23 19:56:32 --> File loaded: application/views/splash/main.php
DEBUG - 2011-09-23 19:56:32 --> Helper loaded: url_helper
DEBUG - 2011-09-23 19:56:32 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-23 19:56:32 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-23 19:56:32 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-23 19:56:32 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-23 19:56:32 --> Final output sent to browser
DEBUG - 2011-09-23 19:56:32 --> Total execution time: 0.5746
DEBUG - 2011-09-23 20:02:51 --> Config Class Initialized
DEBUG - 2011-09-23 20:02:51 --> Hooks Class Initialized
DEBUG - 2011-09-23 20:02:51 --> Utf8 Class Initialized
DEBUG - 2011-09-23 20:02:51 --> UTF-8 Support Enabled
DEBUG - 2011-09-23 20:02:51 --> URI Class Initialized
DEBUG - 2011-09-23 20:02:51 --> Router Class Initialized
DEBUG - 2011-09-23 20:02:51 --> Output Class Initialized
DEBUG - 2011-09-23 20:02:51 --> Input Class Initialized
DEBUG - 2011-09-23 20:02:51 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-23 20:02:51 --> Language Class Initialized
DEBUG - 2011-09-23 20:02:51 --> Loader Class Initialized
DEBUG - 2011-09-23 20:02:51 --> Controller Class Initialized
DEBUG - 2011-09-23 20:02:51 --> Model Class Initialized
DEBUG - 2011-09-23 20:02:51 --> Model Class Initialized
DEBUG - 2011-09-23 20:02:51 --> Model Class Initialized
DEBUG - 2011-09-23 20:02:51 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-23 20:02:51 --> Database Driver Class Initialized
DEBUG - 2011-09-23 20:02:52 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-23 20:02:52 --> Helper loaded: url_helper
DEBUG - 2011-09-23 20:02:52 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-23 20:02:52 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-23 20:02:52 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-23 20:02:52 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-23 20:02:52 --> Final output sent to browser
DEBUG - 2011-09-23 20:02:52 --> Total execution time: 1.0289
DEBUG - 2011-09-23 21:23:13 --> Config Class Initialized
DEBUG - 2011-09-23 21:23:13 --> Hooks Class Initialized
DEBUG - 2011-09-23 21:23:13 --> Utf8 Class Initialized
DEBUG - 2011-09-23 21:23:13 --> UTF-8 Support Enabled
DEBUG - 2011-09-23 21:23:13 --> URI Class Initialized
DEBUG - 2011-09-23 21:23:13 --> Router Class Initialized
DEBUG - 2011-09-23 21:23:13 --> Output Class Initialized
DEBUG - 2011-09-23 21:23:13 --> Input Class Initialized
DEBUG - 2011-09-23 21:23:13 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-23 21:23:13 --> Language Class Initialized
DEBUG - 2011-09-23 21:23:13 --> Loader Class Initialized
DEBUG - 2011-09-23 21:23:13 --> Controller Class Initialized
ERROR - 2011-09-23 21:23:13 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-23 21:23:13 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-23 21:23:13 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-23 21:23:13 --> Model Class Initialized
DEBUG - 2011-09-23 21:23:13 --> Model Class Initialized
DEBUG - 2011-09-23 21:23:13 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-23 21:23:13 --> Database Driver Class Initialized
DEBUG - 2011-09-23 21:23:14 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-23 21:23:14 --> Helper loaded: url_helper
DEBUG - 2011-09-23 21:23:14 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-23 21:23:14 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-23 21:23:14 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-23 21:23:14 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-23 21:23:14 --> Final output sent to browser
DEBUG - 2011-09-23 21:23:14 --> Total execution time: 1.2231
DEBUG - 2011-09-23 21:23:16 --> Config Class Initialized
DEBUG - 2011-09-23 21:23:16 --> Hooks Class Initialized
DEBUG - 2011-09-23 21:23:16 --> Utf8 Class Initialized
DEBUG - 2011-09-23 21:23:16 --> UTF-8 Support Enabled
DEBUG - 2011-09-23 21:23:16 --> URI Class Initialized
DEBUG - 2011-09-23 21:23:16 --> Router Class Initialized
DEBUG - 2011-09-23 21:23:16 --> Output Class Initialized
DEBUG - 2011-09-23 21:23:16 --> Input Class Initialized
DEBUG - 2011-09-23 21:23:16 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-23 21:23:16 --> Language Class Initialized
DEBUG - 2011-09-23 21:23:16 --> Loader Class Initialized
DEBUG - 2011-09-23 21:23:16 --> Controller Class Initialized
DEBUG - 2011-09-23 21:23:16 --> Model Class Initialized
DEBUG - 2011-09-23 21:23:16 --> Model Class Initialized
DEBUG - 2011-09-23 21:23:16 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-23 21:23:16 --> Database Driver Class Initialized
DEBUG - 2011-09-23 21:23:16 --> Final output sent to browser
DEBUG - 2011-09-23 21:23:16 --> Total execution time: 0.8621
DEBUG - 2011-09-23 21:34:07 --> Config Class Initialized
DEBUG - 2011-09-23 21:34:07 --> Hooks Class Initialized
DEBUG - 2011-09-23 21:34:07 --> Utf8 Class Initialized
DEBUG - 2011-09-23 21:34:07 --> UTF-8 Support Enabled
DEBUG - 2011-09-23 21:34:07 --> URI Class Initialized
DEBUG - 2011-09-23 21:34:07 --> Router Class Initialized
DEBUG - 2011-09-23 21:34:07 --> No URI present. Default controller set.
DEBUG - 2011-09-23 21:34:07 --> Output Class Initialized
DEBUG - 2011-09-23 21:34:07 --> Input Class Initialized
DEBUG - 2011-09-23 21:34:07 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-23 21:34:07 --> Language Class Initialized
DEBUG - 2011-09-23 21:34:07 --> Loader Class Initialized
DEBUG - 2011-09-23 21:34:07 --> Controller Class Initialized
DEBUG - 2011-09-23 21:34:07 --> File loaded: application/views/splash/main.php
DEBUG - 2011-09-23 21:34:07 --> Helper loaded: url_helper
DEBUG - 2011-09-23 21:34:07 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-23 21:34:07 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-23 21:34:07 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-23 21:34:07 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-23 21:34:07 --> Final output sent to browser
DEBUG - 2011-09-23 21:34:07 --> Total execution time: 0.1167
DEBUG - 2011-09-23 22:18:23 --> Config Class Initialized
DEBUG - 2011-09-23 22:18:23 --> Hooks Class Initialized
DEBUG - 2011-09-23 22:18:23 --> Utf8 Class Initialized
DEBUG - 2011-09-23 22:18:23 --> UTF-8 Support Enabled
DEBUG - 2011-09-23 22:18:23 --> URI Class Initialized
DEBUG - 2011-09-23 22:18:23 --> Router Class Initialized
DEBUG - 2011-09-23 22:18:23 --> Output Class Initialized
DEBUG - 2011-09-23 22:18:23 --> Input Class Initialized
DEBUG - 2011-09-23 22:18:23 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-23 22:18:23 --> Language Class Initialized
DEBUG - 2011-09-23 22:18:23 --> Loader Class Initialized
DEBUG - 2011-09-23 22:18:23 --> Controller Class Initialized
DEBUG - 2011-09-23 22:18:23 --> Model Class Initialized
DEBUG - 2011-09-23 22:18:23 --> Model Class Initialized
DEBUG - 2011-09-23 22:18:23 --> Model Class Initialized
DEBUG - 2011-09-23 22:18:23 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-23 22:18:23 --> Database Driver Class Initialized
DEBUG - 2011-09-23 22:18:24 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-23 22:18:24 --> Helper loaded: url_helper
DEBUG - 2011-09-23 22:18:24 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-23 22:18:24 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-23 22:18:24 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-23 22:18:24 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-23 22:18:24 --> Final output sent to browser
DEBUG - 2011-09-23 22:18:24 --> Total execution time: 1.1136
DEBUG - 2011-09-23 22:18:24 --> Config Class Initialized
DEBUG - 2011-09-23 22:18:24 --> Hooks Class Initialized
DEBUG - 2011-09-23 22:18:24 --> Utf8 Class Initialized
DEBUG - 2011-09-23 22:18:24 --> UTF-8 Support Enabled
DEBUG - 2011-09-23 22:18:24 --> URI Class Initialized
DEBUG - 2011-09-23 22:18:24 --> Router Class Initialized
DEBUG - 2011-09-23 22:18:24 --> Output Class Initialized
DEBUG - 2011-09-23 22:18:24 --> Input Class Initialized
DEBUG - 2011-09-23 22:18:24 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-23 22:18:24 --> Language Class Initialized
DEBUG - 2011-09-23 22:18:24 --> Loader Class Initialized
DEBUG - 2011-09-23 22:18:24 --> Controller Class Initialized
DEBUG - 2011-09-23 22:18:24 --> Model Class Initialized
DEBUG - 2011-09-23 22:18:24 --> Model Class Initialized
DEBUG - 2011-09-23 22:18:24 --> Model Class Initialized
DEBUG - 2011-09-23 22:18:24 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-23 22:18:24 --> Database Driver Class Initialized
DEBUG - 2011-09-23 22:18:24 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-23 22:18:24 --> Helper loaded: url_helper
DEBUG - 2011-09-23 22:18:24 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-23 22:18:24 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-23 22:18:24 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-23 22:18:24 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-23 22:18:24 --> Final output sent to browser
DEBUG - 2011-09-23 22:18:24 --> Total execution time: 0.0516
DEBUG - 2011-09-23 22:18:26 --> Config Class Initialized
DEBUG - 2011-09-23 22:18:26 --> Hooks Class Initialized
DEBUG - 2011-09-23 22:18:26 --> Utf8 Class Initialized
DEBUG - 2011-09-23 22:18:26 --> UTF-8 Support Enabled
DEBUG - 2011-09-23 22:18:26 --> URI Class Initialized
DEBUG - 2011-09-23 22:18:26 --> Router Class Initialized
ERROR - 2011-09-23 22:18:26 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-23 22:18:26 --> Config Class Initialized
DEBUG - 2011-09-23 22:18:26 --> Hooks Class Initialized
DEBUG - 2011-09-23 22:18:26 --> Utf8 Class Initialized
DEBUG - 2011-09-23 22:18:26 --> UTF-8 Support Enabled
DEBUG - 2011-09-23 22:18:26 --> URI Class Initialized
DEBUG - 2011-09-23 22:18:26 --> Router Class Initialized
ERROR - 2011-09-23 22:18:26 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-23 22:18:48 --> Config Class Initialized
DEBUG - 2011-09-23 22:18:48 --> Hooks Class Initialized
DEBUG - 2011-09-23 22:18:48 --> Utf8 Class Initialized
DEBUG - 2011-09-23 22:18:48 --> UTF-8 Support Enabled
DEBUG - 2011-09-23 22:18:48 --> URI Class Initialized
DEBUG - 2011-09-23 22:18:48 --> Router Class Initialized
DEBUG - 2011-09-23 22:18:48 --> Output Class Initialized
DEBUG - 2011-09-23 22:18:48 --> Input Class Initialized
DEBUG - 2011-09-23 22:18:48 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-23 22:18:48 --> Language Class Initialized
DEBUG - 2011-09-23 22:18:48 --> Loader Class Initialized
DEBUG - 2011-09-23 22:18:48 --> Controller Class Initialized
DEBUG - 2011-09-23 22:18:48 --> Model Class Initialized
DEBUG - 2011-09-23 22:18:48 --> Model Class Initialized
DEBUG - 2011-09-23 22:18:48 --> Model Class Initialized
DEBUG - 2011-09-23 22:18:48 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-23 22:18:48 --> Database Driver Class Initialized
DEBUG - 2011-09-23 22:18:48 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-23 22:18:48 --> Helper loaded: url_helper
DEBUG - 2011-09-23 22:18:48 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-23 22:18:48 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-23 22:18:48 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-23 22:18:48 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-23 22:18:48 --> Final output sent to browser
DEBUG - 2011-09-23 22:18:48 --> Total execution time: 0.6012
DEBUG - 2011-09-23 22:19:00 --> Config Class Initialized
DEBUG - 2011-09-23 22:19:00 --> Hooks Class Initialized
DEBUG - 2011-09-23 22:19:00 --> Utf8 Class Initialized
DEBUG - 2011-09-23 22:19:00 --> UTF-8 Support Enabled
DEBUG - 2011-09-23 22:19:00 --> URI Class Initialized
DEBUG - 2011-09-23 22:19:00 --> Router Class Initialized
DEBUG - 2011-09-23 22:19:00 --> Output Class Initialized
DEBUG - 2011-09-23 22:19:00 --> Input Class Initialized
DEBUG - 2011-09-23 22:19:00 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-23 22:19:00 --> Language Class Initialized
DEBUG - 2011-09-23 22:19:00 --> Loader Class Initialized
DEBUG - 2011-09-23 22:19:00 --> Controller Class Initialized
DEBUG - 2011-09-23 22:19:00 --> Model Class Initialized
DEBUG - 2011-09-23 22:19:00 --> Model Class Initialized
DEBUG - 2011-09-23 22:19:00 --> Model Class Initialized
DEBUG - 2011-09-23 22:19:00 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-23 22:19:00 --> Database Driver Class Initialized
DEBUG - 2011-09-23 22:19:00 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-23 22:19:00 --> Helper loaded: url_helper
DEBUG - 2011-09-23 22:19:00 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-23 22:19:00 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-23 22:19:00 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-23 22:19:00 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-23 22:19:00 --> Final output sent to browser
DEBUG - 2011-09-23 22:19:00 --> Total execution time: 0.3985
DEBUG - 2011-09-23 22:19:16 --> Config Class Initialized
DEBUG - 2011-09-23 22:19:16 --> Hooks Class Initialized
DEBUG - 2011-09-23 22:19:16 --> Utf8 Class Initialized
DEBUG - 2011-09-23 22:19:16 --> UTF-8 Support Enabled
DEBUG - 2011-09-23 22:19:16 --> URI Class Initialized
DEBUG - 2011-09-23 22:19:16 --> Router Class Initialized
DEBUG - 2011-09-23 22:19:16 --> Output Class Initialized
DEBUG - 2011-09-23 22:19:16 --> Input Class Initialized
DEBUG - 2011-09-23 22:19:16 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-23 22:19:16 --> Language Class Initialized
DEBUG - 2011-09-23 22:19:16 --> Loader Class Initialized
DEBUG - 2011-09-23 22:19:16 --> Controller Class Initialized
DEBUG - 2011-09-23 22:19:16 --> Model Class Initialized
DEBUG - 2011-09-23 22:19:16 --> Model Class Initialized
DEBUG - 2011-09-23 22:19:16 --> Model Class Initialized
DEBUG - 2011-09-23 22:19:16 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-23 22:19:16 --> Database Driver Class Initialized
DEBUG - 2011-09-23 22:19:16 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-23 22:19:16 --> Helper loaded: url_helper
DEBUG - 2011-09-23 22:19:16 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-23 22:19:16 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-23 22:19:16 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-23 22:19:16 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-23 22:19:16 --> Final output sent to browser
DEBUG - 2011-09-23 22:19:16 --> Total execution time: 0.3098
DEBUG - 2011-09-23 22:19:46 --> Config Class Initialized
DEBUG - 2011-09-23 22:19:46 --> Hooks Class Initialized
DEBUG - 2011-09-23 22:19:46 --> Utf8 Class Initialized
DEBUG - 2011-09-23 22:19:46 --> UTF-8 Support Enabled
DEBUG - 2011-09-23 22:19:46 --> URI Class Initialized
DEBUG - 2011-09-23 22:19:46 --> Router Class Initialized
DEBUG - 2011-09-23 22:19:46 --> Output Class Initialized
DEBUG - 2011-09-23 22:19:46 --> Input Class Initialized
DEBUG - 2011-09-23 22:19:46 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-23 22:19:46 --> Language Class Initialized
DEBUG - 2011-09-23 22:19:46 --> Loader Class Initialized
DEBUG - 2011-09-23 22:19:46 --> Controller Class Initialized
DEBUG - 2011-09-23 22:19:46 --> Model Class Initialized
DEBUG - 2011-09-23 22:19:46 --> Model Class Initialized
DEBUG - 2011-09-23 22:19:46 --> Model Class Initialized
DEBUG - 2011-09-23 22:19:46 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-23 22:19:46 --> Database Driver Class Initialized
DEBUG - 2011-09-23 22:19:46 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-23 22:19:46 --> Helper loaded: url_helper
DEBUG - 2011-09-23 22:19:46 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-23 22:19:46 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-23 22:19:46 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-23 22:19:46 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-23 22:19:46 --> Final output sent to browser
DEBUG - 2011-09-23 22:19:46 --> Total execution time: 0.0994
DEBUG - 2011-09-23 22:19:58 --> Config Class Initialized
DEBUG - 2011-09-23 22:19:58 --> Hooks Class Initialized
DEBUG - 2011-09-23 22:19:58 --> Utf8 Class Initialized
DEBUG - 2011-09-23 22:19:58 --> UTF-8 Support Enabled
DEBUG - 2011-09-23 22:19:58 --> URI Class Initialized
DEBUG - 2011-09-23 22:19:58 --> Router Class Initialized
DEBUG - 2011-09-23 22:19:58 --> Output Class Initialized
DEBUG - 2011-09-23 22:19:58 --> Input Class Initialized
DEBUG - 2011-09-23 22:19:58 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-23 22:19:58 --> Language Class Initialized
DEBUG - 2011-09-23 22:19:58 --> Loader Class Initialized
DEBUG - 2011-09-23 22:19:58 --> Controller Class Initialized
DEBUG - 2011-09-23 22:19:58 --> Model Class Initialized
DEBUG - 2011-09-23 22:19:58 --> Model Class Initialized
DEBUG - 2011-09-23 22:19:58 --> Model Class Initialized
DEBUG - 2011-09-23 22:19:58 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-23 22:19:58 --> Database Driver Class Initialized
DEBUG - 2011-09-23 22:19:59 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-23 22:19:59 --> Helper loaded: url_helper
DEBUG - 2011-09-23 22:19:59 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-23 22:19:59 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-23 22:19:59 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-23 22:19:59 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-23 22:19:59 --> Final output sent to browser
DEBUG - 2011-09-23 22:19:59 --> Total execution time: 0.3564
DEBUG - 2011-09-23 22:20:08 --> Config Class Initialized
DEBUG - 2011-09-23 22:20:08 --> Hooks Class Initialized
DEBUG - 2011-09-23 22:20:08 --> Utf8 Class Initialized
DEBUG - 2011-09-23 22:20:08 --> UTF-8 Support Enabled
DEBUG - 2011-09-23 22:20:08 --> URI Class Initialized
DEBUG - 2011-09-23 22:20:08 --> Router Class Initialized
DEBUG - 2011-09-23 22:20:08 --> Output Class Initialized
DEBUG - 2011-09-23 22:20:08 --> Input Class Initialized
DEBUG - 2011-09-23 22:20:08 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-23 22:20:08 --> Language Class Initialized
DEBUG - 2011-09-23 22:20:08 --> Loader Class Initialized
DEBUG - 2011-09-23 22:20:08 --> Controller Class Initialized
DEBUG - 2011-09-23 22:20:08 --> Model Class Initialized
DEBUG - 2011-09-23 22:20:08 --> Model Class Initialized
DEBUG - 2011-09-23 22:20:08 --> Model Class Initialized
DEBUG - 2011-09-23 22:20:08 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-23 22:20:08 --> Database Driver Class Initialized
DEBUG - 2011-09-23 22:20:09 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-23 22:20:09 --> Helper loaded: url_helper
DEBUG - 2011-09-23 22:20:09 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-23 22:20:09 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-23 22:20:09 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-23 22:20:09 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-23 22:20:09 --> Final output sent to browser
DEBUG - 2011-09-23 22:20:09 --> Total execution time: 0.7689
DEBUG - 2011-09-23 22:20:15 --> Config Class Initialized
DEBUG - 2011-09-23 22:20:15 --> Hooks Class Initialized
DEBUG - 2011-09-23 22:20:15 --> Utf8 Class Initialized
DEBUG - 2011-09-23 22:20:15 --> UTF-8 Support Enabled
DEBUG - 2011-09-23 22:20:15 --> URI Class Initialized
DEBUG - 2011-09-23 22:20:15 --> Router Class Initialized
DEBUG - 2011-09-23 22:20:15 --> Output Class Initialized
DEBUG - 2011-09-23 22:20:15 --> Input Class Initialized
DEBUG - 2011-09-23 22:20:15 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-23 22:20:15 --> Language Class Initialized
DEBUG - 2011-09-23 22:20:15 --> Loader Class Initialized
DEBUG - 2011-09-23 22:20:15 --> Controller Class Initialized
DEBUG - 2011-09-23 22:20:15 --> Model Class Initialized
DEBUG - 2011-09-23 22:20:15 --> Model Class Initialized
DEBUG - 2011-09-23 22:20:15 --> Model Class Initialized
DEBUG - 2011-09-23 22:20:15 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-23 22:20:15 --> Database Driver Class Initialized
DEBUG - 2011-09-23 22:20:16 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-23 22:20:16 --> Helper loaded: url_helper
DEBUG - 2011-09-23 22:20:16 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-23 22:20:16 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-23 22:20:16 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-23 22:20:16 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-23 22:20:16 --> Final output sent to browser
DEBUG - 2011-09-23 22:20:16 --> Total execution time: 0.4764
DEBUG - 2011-09-23 22:20:23 --> Config Class Initialized
DEBUG - 2011-09-23 22:20:23 --> Hooks Class Initialized
DEBUG - 2011-09-23 22:20:23 --> Utf8 Class Initialized
DEBUG - 2011-09-23 22:20:23 --> UTF-8 Support Enabled
DEBUG - 2011-09-23 22:20:23 --> URI Class Initialized
DEBUG - 2011-09-23 22:20:23 --> Router Class Initialized
DEBUG - 2011-09-23 22:20:23 --> Output Class Initialized
DEBUG - 2011-09-23 22:20:23 --> Input Class Initialized
DEBUG - 2011-09-23 22:20:23 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-23 22:20:23 --> Language Class Initialized
DEBUG - 2011-09-23 22:20:23 --> Loader Class Initialized
DEBUG - 2011-09-23 22:20:23 --> Controller Class Initialized
DEBUG - 2011-09-23 22:20:23 --> Model Class Initialized
DEBUG - 2011-09-23 22:20:23 --> Model Class Initialized
DEBUG - 2011-09-23 22:20:23 --> Model Class Initialized
DEBUG - 2011-09-23 22:20:23 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-23 22:20:23 --> Database Driver Class Initialized
DEBUG - 2011-09-23 22:20:24 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-23 22:20:24 --> Helper loaded: url_helper
DEBUG - 2011-09-23 22:20:24 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-23 22:20:24 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-23 22:20:24 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-23 22:20:24 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-23 22:20:24 --> Final output sent to browser
DEBUG - 2011-09-23 22:20:24 --> Total execution time: 0.8042
DEBUG - 2011-09-23 22:20:37 --> Config Class Initialized
DEBUG - 2011-09-23 22:20:37 --> Hooks Class Initialized
DEBUG - 2011-09-23 22:20:37 --> Utf8 Class Initialized
DEBUG - 2011-09-23 22:20:37 --> UTF-8 Support Enabled
DEBUG - 2011-09-23 22:20:37 --> URI Class Initialized
DEBUG - 2011-09-23 22:20:37 --> Router Class Initialized
DEBUG - 2011-09-23 22:20:37 --> Output Class Initialized
DEBUG - 2011-09-23 22:20:37 --> Input Class Initialized
DEBUG - 2011-09-23 22:20:37 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-23 22:20:37 --> Language Class Initialized
DEBUG - 2011-09-23 22:20:37 --> Loader Class Initialized
DEBUG - 2011-09-23 22:20:37 --> Controller Class Initialized
DEBUG - 2011-09-23 22:20:37 --> Model Class Initialized
DEBUG - 2011-09-23 22:20:37 --> Model Class Initialized
DEBUG - 2011-09-23 22:20:37 --> Model Class Initialized
DEBUG - 2011-09-23 22:20:37 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-23 22:20:37 --> Database Driver Class Initialized
DEBUG - 2011-09-23 22:20:37 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-23 22:20:37 --> Helper loaded: url_helper
DEBUG - 2011-09-23 22:20:37 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-23 22:20:37 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-23 22:20:37 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-23 22:20:37 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-23 22:20:37 --> Final output sent to browser
DEBUG - 2011-09-23 22:20:37 --> Total execution time: 0.4320
DEBUG - 2011-09-23 22:24:09 --> Config Class Initialized
DEBUG - 2011-09-23 22:24:09 --> Hooks Class Initialized
DEBUG - 2011-09-23 22:24:09 --> Utf8 Class Initialized
DEBUG - 2011-09-23 22:24:09 --> UTF-8 Support Enabled
DEBUG - 2011-09-23 22:24:09 --> URI Class Initialized
DEBUG - 2011-09-23 22:24:09 --> Router Class Initialized
ERROR - 2011-09-23 22:24:09 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-09-23 22:24:10 --> Config Class Initialized
DEBUG - 2011-09-23 22:24:10 --> Hooks Class Initialized
DEBUG - 2011-09-23 22:24:10 --> Utf8 Class Initialized
DEBUG - 2011-09-23 22:24:10 --> UTF-8 Support Enabled
DEBUG - 2011-09-23 22:24:10 --> URI Class Initialized
DEBUG - 2011-09-23 22:24:10 --> Router Class Initialized
DEBUG - 2011-09-23 22:24:10 --> Output Class Initialized
DEBUG - 2011-09-23 22:24:10 --> Input Class Initialized
DEBUG - 2011-09-23 22:24:10 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-23 22:24:10 --> Language Class Initialized
DEBUG - 2011-09-23 22:24:10 --> Loader Class Initialized
DEBUG - 2011-09-23 22:24:10 --> Controller Class Initialized
DEBUG - 2011-09-23 22:24:10 --> Model Class Initialized
DEBUG - 2011-09-23 22:24:10 --> Model Class Initialized
DEBUG - 2011-09-23 22:24:10 --> Model Class Initialized
DEBUG - 2011-09-23 22:24:10 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-23 22:24:10 --> Database Driver Class Initialized
DEBUG - 2011-09-23 22:24:10 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-23 22:24:10 --> Helper loaded: url_helper
DEBUG - 2011-09-23 22:24:10 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-23 22:24:10 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-23 22:24:10 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-23 22:24:10 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-23 22:24:10 --> Final output sent to browser
DEBUG - 2011-09-23 22:24:10 --> Total execution time: 0.1181
DEBUG - 2011-09-23 22:33:00 --> Config Class Initialized
DEBUG - 2011-09-23 22:33:00 --> Hooks Class Initialized
DEBUG - 2011-09-23 22:33:00 --> Utf8 Class Initialized
DEBUG - 2011-09-23 22:33:00 --> UTF-8 Support Enabled
DEBUG - 2011-09-23 22:33:00 --> URI Class Initialized
DEBUG - 2011-09-23 22:33:00 --> Router Class Initialized
DEBUG - 2011-09-23 22:33:00 --> Output Class Initialized
DEBUG - 2011-09-23 22:33:00 --> Input Class Initialized
DEBUG - 2011-09-23 22:33:00 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-23 22:33:00 --> Language Class Initialized
DEBUG - 2011-09-23 22:33:00 --> Loader Class Initialized
DEBUG - 2011-09-23 22:33:00 --> Controller Class Initialized
ERROR - 2011-09-23 22:33:00 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-23 22:33:00 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-23 22:33:00 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-23 22:33:00 --> Model Class Initialized
DEBUG - 2011-09-23 22:33:00 --> Model Class Initialized
DEBUG - 2011-09-23 22:33:00 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-23 22:33:00 --> Database Driver Class Initialized
DEBUG - 2011-09-23 22:33:00 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-23 22:33:00 --> Helper loaded: url_helper
DEBUG - 2011-09-23 22:33:00 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-23 22:33:00 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-23 22:33:00 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-23 22:33:00 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-23 22:33:00 --> Final output sent to browser
DEBUG - 2011-09-23 22:33:00 --> Total execution time: 0.0856
DEBUG - 2011-09-23 22:33:03 --> Config Class Initialized
DEBUG - 2011-09-23 22:33:03 --> Hooks Class Initialized
DEBUG - 2011-09-23 22:33:03 --> Utf8 Class Initialized
DEBUG - 2011-09-23 22:33:03 --> UTF-8 Support Enabled
DEBUG - 2011-09-23 22:33:03 --> URI Class Initialized
DEBUG - 2011-09-23 22:33:03 --> Router Class Initialized
DEBUG - 2011-09-23 22:33:03 --> Output Class Initialized
DEBUG - 2011-09-23 22:33:03 --> Input Class Initialized
DEBUG - 2011-09-23 22:33:03 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-23 22:33:03 --> Language Class Initialized
DEBUG - 2011-09-23 22:33:03 --> Loader Class Initialized
DEBUG - 2011-09-23 22:33:03 --> Controller Class Initialized
DEBUG - 2011-09-23 22:33:03 --> Model Class Initialized
DEBUG - 2011-09-23 22:33:03 --> Model Class Initialized
DEBUG - 2011-09-23 22:33:03 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-23 22:33:03 --> Database Driver Class Initialized
DEBUG - 2011-09-23 22:33:03 --> Final output sent to browser
DEBUG - 2011-09-23 22:33:03 --> Total execution time: 0.8070
DEBUG - 2011-09-23 22:33:04 --> Config Class Initialized
DEBUG - 2011-09-23 22:33:04 --> Hooks Class Initialized
DEBUG - 2011-09-23 22:33:04 --> Utf8 Class Initialized
DEBUG - 2011-09-23 22:33:04 --> UTF-8 Support Enabled
DEBUG - 2011-09-23 22:33:04 --> URI Class Initialized
DEBUG - 2011-09-23 22:33:04 --> Router Class Initialized
ERROR - 2011-09-23 22:33:04 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-23 23:27:52 --> Config Class Initialized
DEBUG - 2011-09-23 23:27:52 --> Hooks Class Initialized
DEBUG - 2011-09-23 23:27:52 --> Utf8 Class Initialized
DEBUG - 2011-09-23 23:27:52 --> UTF-8 Support Enabled
DEBUG - 2011-09-23 23:27:52 --> URI Class Initialized
DEBUG - 2011-09-23 23:27:52 --> Router Class Initialized
DEBUG - 2011-09-23 23:27:52 --> Output Class Initialized
DEBUG - 2011-09-23 23:27:52 --> Input Class Initialized
DEBUG - 2011-09-23 23:27:52 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-23 23:27:52 --> Language Class Initialized
DEBUG - 2011-09-23 23:27:52 --> Loader Class Initialized
DEBUG - 2011-09-23 23:27:52 --> Controller Class Initialized
DEBUG - 2011-09-23 23:27:52 --> Model Class Initialized
DEBUG - 2011-09-23 23:27:52 --> Model Class Initialized
DEBUG - 2011-09-23 23:27:52 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-23 23:27:52 --> Database Driver Class Initialized
DEBUG - 2011-09-23 23:27:53 --> Final output sent to browser
DEBUG - 2011-09-23 23:27:53 --> Total execution time: 0.7715
DEBUG - 2011-09-23 23:48:41 --> Config Class Initialized
DEBUG - 2011-09-23 23:48:41 --> Hooks Class Initialized
DEBUG - 2011-09-23 23:48:41 --> Utf8 Class Initialized
DEBUG - 2011-09-23 23:48:41 --> UTF-8 Support Enabled
DEBUG - 2011-09-23 23:48:41 --> URI Class Initialized
DEBUG - 2011-09-23 23:48:41 --> Router Class Initialized
ERROR - 2011-09-23 23:48:41 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-09-23 23:48:41 --> Config Class Initialized
DEBUG - 2011-09-23 23:48:41 --> Hooks Class Initialized
DEBUG - 2011-09-23 23:48:41 --> Utf8 Class Initialized
DEBUG - 2011-09-23 23:48:41 --> UTF-8 Support Enabled
DEBUG - 2011-09-23 23:48:41 --> URI Class Initialized
DEBUG - 2011-09-23 23:48:41 --> Router Class Initialized
DEBUG - 2011-09-23 23:48:41 --> Output Class Initialized
DEBUG - 2011-09-23 23:48:41 --> Input Class Initialized
DEBUG - 2011-09-23 23:48:41 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-23 23:48:41 --> Language Class Initialized
DEBUG - 2011-09-23 23:48:41 --> Loader Class Initialized
DEBUG - 2011-09-23 23:48:41 --> Controller Class Initialized
ERROR - 2011-09-23 23:48:41 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-23 23:48:41 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-23 23:48:41 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-23 23:48:41 --> Model Class Initialized
DEBUG - 2011-09-23 23:48:41 --> Model Class Initialized
DEBUG - 2011-09-23 23:48:41 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-23 23:48:41 --> Database Driver Class Initialized
DEBUG - 2011-09-23 23:48:41 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-23 23:48:41 --> Helper loaded: url_helper
DEBUG - 2011-09-23 23:48:41 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-23 23:48:41 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-23 23:48:41 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-23 23:48:41 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-23 23:48:41 --> Final output sent to browser
DEBUG - 2011-09-23 23:48:41 --> Total execution time: 0.5290
DEBUG - 2011-09-23 23:50:46 --> Config Class Initialized
DEBUG - 2011-09-23 23:50:46 --> Hooks Class Initialized
DEBUG - 2011-09-23 23:50:46 --> Utf8 Class Initialized
DEBUG - 2011-09-23 23:50:46 --> UTF-8 Support Enabled
DEBUG - 2011-09-23 23:50:46 --> URI Class Initialized
DEBUG - 2011-09-23 23:50:46 --> Router Class Initialized
DEBUG - 2011-09-23 23:50:46 --> Output Class Initialized
DEBUG - 2011-09-23 23:50:46 --> Input Class Initialized
DEBUG - 2011-09-23 23:50:46 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-23 23:50:46 --> Language Class Initialized
DEBUG - 2011-09-23 23:50:46 --> Loader Class Initialized
DEBUG - 2011-09-23 23:50:46 --> Controller Class Initialized
DEBUG - 2011-09-23 23:50:46 --> Model Class Initialized
DEBUG - 2011-09-23 23:50:46 --> Model Class Initialized
DEBUG - 2011-09-23 23:50:46 --> Model Class Initialized
DEBUG - 2011-09-23 23:50:46 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-23 23:50:46 --> Database Driver Class Initialized
DEBUG - 2011-09-23 23:50:47 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-23 23:50:47 --> Helper loaded: url_helper
DEBUG - 2011-09-23 23:50:47 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-23 23:50:47 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-23 23:50:47 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-23 23:50:47 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-23 23:50:47 --> Final output sent to browser
DEBUG - 2011-09-23 23:50:47 --> Total execution time: 1.5253
DEBUG - 2011-09-23 23:50:58 --> Config Class Initialized
DEBUG - 2011-09-23 23:50:58 --> Hooks Class Initialized
DEBUG - 2011-09-23 23:50:58 --> Utf8 Class Initialized
DEBUG - 2011-09-23 23:50:58 --> UTF-8 Support Enabled
DEBUG - 2011-09-23 23:50:58 --> URI Class Initialized
DEBUG - 2011-09-23 23:50:58 --> Router Class Initialized
ERROR - 2011-09-23 23:50:58 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-23 23:50:59 --> Config Class Initialized
DEBUG - 2011-09-23 23:50:59 --> Hooks Class Initialized
DEBUG - 2011-09-23 23:50:59 --> Utf8 Class Initialized
DEBUG - 2011-09-23 23:50:59 --> UTF-8 Support Enabled
DEBUG - 2011-09-23 23:50:59 --> URI Class Initialized
DEBUG - 2011-09-23 23:50:59 --> Router Class Initialized
ERROR - 2011-09-23 23:50:59 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-23 23:51:00 --> Config Class Initialized
DEBUG - 2011-09-23 23:51:00 --> Hooks Class Initialized
DEBUG - 2011-09-23 23:51:00 --> Utf8 Class Initialized
DEBUG - 2011-09-23 23:51:00 --> UTF-8 Support Enabled
DEBUG - 2011-09-23 23:51:00 --> URI Class Initialized
DEBUG - 2011-09-23 23:51:00 --> Router Class Initialized
ERROR - 2011-09-23 23:51:00 --> 404 Page Not Found --> favicon.ico

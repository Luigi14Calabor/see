<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2011-08-17 00:50:51 --> Config Class Initialized
DEBUG - 2011-08-17 00:50:51 --> Hooks Class Initialized
DEBUG - 2011-08-17 00:50:51 --> Utf8 Class Initialized
DEBUG - 2011-08-17 00:50:51 --> UTF-8 Support Enabled
DEBUG - 2011-08-17 00:50:51 --> URI Class Initialized
DEBUG - 2011-08-17 00:50:51 --> Router Class Initialized
DEBUG - 2011-08-17 00:50:51 --> Output Class Initialized
DEBUG - 2011-08-17 00:50:51 --> Input Class Initialized
DEBUG - 2011-08-17 00:50:51 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-17 00:50:51 --> Language Class Initialized
DEBUG - 2011-08-17 00:50:51 --> Loader Class Initialized
DEBUG - 2011-08-17 00:50:51 --> Controller Class Initialized
ERROR - 2011-08-17 00:50:51 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-17 00:50:51 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-17 00:50:51 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-17 00:50:51 --> Model Class Initialized
DEBUG - 2011-08-17 00:50:51 --> Model Class Initialized
DEBUG - 2011-08-17 00:50:51 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-17 00:50:51 --> Database Driver Class Initialized
DEBUG - 2011-08-17 00:50:51 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-17 00:50:51 --> Helper loaded: url_helper
DEBUG - 2011-08-17 00:50:51 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-17 00:50:51 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-17 00:50:51 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-17 00:50:51 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-17 00:50:51 --> Final output sent to browser
DEBUG - 2011-08-17 00:50:51 --> Total execution time: 0.1695
DEBUG - 2011-08-17 01:09:32 --> Config Class Initialized
DEBUG - 2011-08-17 01:09:32 --> Hooks Class Initialized
DEBUG - 2011-08-17 01:09:32 --> Utf8 Class Initialized
DEBUG - 2011-08-17 01:09:32 --> UTF-8 Support Enabled
DEBUG - 2011-08-17 01:09:32 --> URI Class Initialized
DEBUG - 2011-08-17 01:09:32 --> Router Class Initialized
DEBUG - 2011-08-17 01:09:32 --> No URI present. Default controller set.
DEBUG - 2011-08-17 01:09:32 --> Output Class Initialized
DEBUG - 2011-08-17 01:09:32 --> Input Class Initialized
DEBUG - 2011-08-17 01:09:32 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-17 01:09:32 --> Language Class Initialized
DEBUG - 2011-08-17 01:09:32 --> Loader Class Initialized
DEBUG - 2011-08-17 01:09:32 --> Controller Class Initialized
DEBUG - 2011-08-17 01:09:32 --> File loaded: application/views/splash/main.php
DEBUG - 2011-08-17 01:09:32 --> Helper loaded: url_helper
DEBUG - 2011-08-17 01:09:32 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-17 01:09:32 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-17 01:09:32 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-17 01:09:32 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-17 01:09:32 --> Final output sent to browser
DEBUG - 2011-08-17 01:09:32 --> Total execution time: 0.0317
DEBUG - 2011-08-17 01:36:44 --> Config Class Initialized
DEBUG - 2011-08-17 01:36:44 --> Hooks Class Initialized
DEBUG - 2011-08-17 01:36:44 --> Utf8 Class Initialized
DEBUG - 2011-08-17 01:36:44 --> UTF-8 Support Enabled
DEBUG - 2011-08-17 01:36:44 --> URI Class Initialized
DEBUG - 2011-08-17 01:36:44 --> Router Class Initialized
DEBUG - 2011-08-17 01:36:44 --> Output Class Initialized
DEBUG - 2011-08-17 01:36:44 --> Input Class Initialized
DEBUG - 2011-08-17 01:36:44 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-17 01:36:44 --> Language Class Initialized
DEBUG - 2011-08-17 01:36:44 --> Loader Class Initialized
DEBUG - 2011-08-17 01:36:44 --> Controller Class Initialized
DEBUG - 2011-08-17 01:36:44 --> Model Class Initialized
DEBUG - 2011-08-17 01:36:44 --> Model Class Initialized
DEBUG - 2011-08-17 01:36:44 --> Model Class Initialized
DEBUG - 2011-08-17 01:36:44 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-17 01:36:44 --> Database Driver Class Initialized
DEBUG - 2011-08-17 01:36:45 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-17 01:36:45 --> Helper loaded: url_helper
DEBUG - 2011-08-17 01:36:45 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-17 01:36:45 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-17 01:36:45 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-17 01:36:45 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-17 01:36:45 --> Final output sent to browser
DEBUG - 2011-08-17 01:36:45 --> Total execution time: 0.4309
DEBUG - 2011-08-17 01:36:47 --> Config Class Initialized
DEBUG - 2011-08-17 01:36:47 --> Hooks Class Initialized
DEBUG - 2011-08-17 01:36:47 --> Utf8 Class Initialized
DEBUG - 2011-08-17 01:36:47 --> UTF-8 Support Enabled
DEBUG - 2011-08-17 01:36:47 --> URI Class Initialized
DEBUG - 2011-08-17 01:36:47 --> Router Class Initialized
ERROR - 2011-08-17 01:36:47 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-17 01:57:45 --> Config Class Initialized
DEBUG - 2011-08-17 01:57:45 --> Hooks Class Initialized
DEBUG - 2011-08-17 01:57:45 --> Utf8 Class Initialized
DEBUG - 2011-08-17 01:57:45 --> UTF-8 Support Enabled
DEBUG - 2011-08-17 01:57:45 --> URI Class Initialized
DEBUG - 2011-08-17 01:57:45 --> Router Class Initialized
ERROR - 2011-08-17 01:57:45 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-08-17 01:57:45 --> Config Class Initialized
DEBUG - 2011-08-17 01:57:45 --> Hooks Class Initialized
DEBUG - 2011-08-17 01:57:45 --> Utf8 Class Initialized
DEBUG - 2011-08-17 01:57:45 --> UTF-8 Support Enabled
DEBUG - 2011-08-17 01:57:45 --> URI Class Initialized
DEBUG - 2011-08-17 01:57:45 --> Router Class Initialized
DEBUG - 2011-08-17 01:57:45 --> No URI present. Default controller set.
DEBUG - 2011-08-17 01:57:45 --> Output Class Initialized
DEBUG - 2011-08-17 01:57:45 --> Input Class Initialized
DEBUG - 2011-08-17 01:57:45 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-17 01:57:45 --> Language Class Initialized
DEBUG - 2011-08-17 01:57:45 --> Loader Class Initialized
DEBUG - 2011-08-17 01:57:45 --> Controller Class Initialized
DEBUG - 2011-08-17 01:57:45 --> File loaded: application/views/splash/main.php
DEBUG - 2011-08-17 01:57:45 --> Helper loaded: url_helper
DEBUG - 2011-08-17 01:57:45 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-17 01:57:45 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-17 01:57:45 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-17 01:57:45 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-17 01:57:45 --> Final output sent to browser
DEBUG - 2011-08-17 01:57:45 --> Total execution time: 0.0256
DEBUG - 2011-08-17 02:08:20 --> Config Class Initialized
DEBUG - 2011-08-17 02:08:20 --> Hooks Class Initialized
DEBUG - 2011-08-17 02:08:20 --> Utf8 Class Initialized
DEBUG - 2011-08-17 02:08:20 --> UTF-8 Support Enabled
DEBUG - 2011-08-17 02:08:20 --> URI Class Initialized
DEBUG - 2011-08-17 02:08:20 --> Router Class Initialized
DEBUG - 2011-08-17 02:08:20 --> Output Class Initialized
DEBUG - 2011-08-17 02:08:20 --> Input Class Initialized
DEBUG - 2011-08-17 02:08:20 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-17 02:08:20 --> Language Class Initialized
DEBUG - 2011-08-17 02:08:20 --> Loader Class Initialized
DEBUG - 2011-08-17 02:08:20 --> Controller Class Initialized
ERROR - 2011-08-17 02:08:20 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-17 02:08:20 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-17 02:08:20 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-17 02:08:20 --> Model Class Initialized
DEBUG - 2011-08-17 02:08:20 --> Model Class Initialized
DEBUG - 2011-08-17 02:08:20 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-17 02:08:20 --> Database Driver Class Initialized
DEBUG - 2011-08-17 02:08:20 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-17 02:08:20 --> Helper loaded: url_helper
DEBUG - 2011-08-17 02:08:20 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-17 02:08:20 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-17 02:08:20 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-17 02:08:20 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-17 02:08:20 --> Final output sent to browser
DEBUG - 2011-08-17 02:08:20 --> Total execution time: 0.0511
DEBUG - 2011-08-17 04:15:15 --> Config Class Initialized
DEBUG - 2011-08-17 04:15:15 --> Hooks Class Initialized
DEBUG - 2011-08-17 04:15:15 --> Utf8 Class Initialized
DEBUG - 2011-08-17 04:15:15 --> UTF-8 Support Enabled
DEBUG - 2011-08-17 04:15:15 --> URI Class Initialized
DEBUG - 2011-08-17 04:15:15 --> Router Class Initialized
DEBUG - 2011-08-17 04:15:15 --> Output Class Initialized
DEBUG - 2011-08-17 04:15:15 --> Input Class Initialized
DEBUG - 2011-08-17 04:15:15 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-17 04:15:15 --> Language Class Initialized
DEBUG - 2011-08-17 04:15:15 --> Loader Class Initialized
DEBUG - 2011-08-17 04:15:15 --> Controller Class Initialized
ERROR - 2011-08-17 04:15:15 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-17 04:15:15 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-17 04:15:15 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-17 04:15:15 --> Model Class Initialized
DEBUG - 2011-08-17 04:15:15 --> Model Class Initialized
DEBUG - 2011-08-17 04:15:15 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-17 04:15:15 --> Database Driver Class Initialized
DEBUG - 2011-08-17 04:15:15 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-17 04:15:15 --> Helper loaded: url_helper
DEBUG - 2011-08-17 04:15:15 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-17 04:15:15 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-17 04:15:15 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-17 04:15:15 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-17 04:15:15 --> Final output sent to browser
DEBUG - 2011-08-17 04:15:15 --> Total execution time: 0.1141
DEBUG - 2011-08-17 04:15:17 --> Config Class Initialized
DEBUG - 2011-08-17 04:15:17 --> Hooks Class Initialized
DEBUG - 2011-08-17 04:15:17 --> Utf8 Class Initialized
DEBUG - 2011-08-17 04:15:17 --> UTF-8 Support Enabled
DEBUG - 2011-08-17 04:15:17 --> URI Class Initialized
DEBUG - 2011-08-17 04:15:17 --> Router Class Initialized
DEBUG - 2011-08-17 04:15:17 --> Output Class Initialized
DEBUG - 2011-08-17 04:15:17 --> Input Class Initialized
DEBUG - 2011-08-17 04:15:17 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-17 04:15:17 --> Language Class Initialized
DEBUG - 2011-08-17 04:15:17 --> Loader Class Initialized
DEBUG - 2011-08-17 04:15:17 --> Controller Class Initialized
DEBUG - 2011-08-17 04:15:17 --> Model Class Initialized
DEBUG - 2011-08-17 04:15:17 --> Model Class Initialized
DEBUG - 2011-08-17 04:15:17 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-17 04:15:17 --> Database Driver Class Initialized
DEBUG - 2011-08-17 04:15:18 --> Final output sent to browser
DEBUG - 2011-08-17 04:15:18 --> Total execution time: 0.7486
DEBUG - 2011-08-17 04:16:08 --> Config Class Initialized
DEBUG - 2011-08-17 04:16:08 --> Hooks Class Initialized
DEBUG - 2011-08-17 04:16:08 --> Utf8 Class Initialized
DEBUG - 2011-08-17 04:16:08 --> UTF-8 Support Enabled
DEBUG - 2011-08-17 04:16:08 --> URI Class Initialized
DEBUG - 2011-08-17 04:16:08 --> Router Class Initialized
ERROR - 2011-08-17 04:16:08 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-17 04:16:08 --> Config Class Initialized
DEBUG - 2011-08-17 04:16:08 --> Hooks Class Initialized
DEBUG - 2011-08-17 04:16:08 --> Utf8 Class Initialized
DEBUG - 2011-08-17 04:16:08 --> UTF-8 Support Enabled
DEBUG - 2011-08-17 04:16:08 --> URI Class Initialized
DEBUG - 2011-08-17 04:16:08 --> Router Class Initialized
ERROR - 2011-08-17 04:16:08 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-17 05:14:04 --> Config Class Initialized
DEBUG - 2011-08-17 05:14:04 --> Hooks Class Initialized
DEBUG - 2011-08-17 05:14:04 --> Utf8 Class Initialized
DEBUG - 2011-08-17 05:14:04 --> UTF-8 Support Enabled
DEBUG - 2011-08-17 05:14:04 --> URI Class Initialized
DEBUG - 2011-08-17 05:14:04 --> Router Class Initialized
DEBUG - 2011-08-17 05:14:04 --> Output Class Initialized
DEBUG - 2011-08-17 05:14:04 --> Input Class Initialized
DEBUG - 2011-08-17 05:14:04 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-17 05:14:04 --> Language Class Initialized
DEBUG - 2011-08-17 05:14:04 --> Loader Class Initialized
DEBUG - 2011-08-17 05:14:04 --> Controller Class Initialized
ERROR - 2011-08-17 05:14:04 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-17 05:14:04 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-17 05:14:04 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-17 05:14:04 --> Model Class Initialized
DEBUG - 2011-08-17 05:14:04 --> Model Class Initialized
DEBUG - 2011-08-17 05:14:04 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-17 05:14:04 --> Database Driver Class Initialized
DEBUG - 2011-08-17 05:14:04 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-17 05:14:04 --> Helper loaded: url_helper
DEBUG - 2011-08-17 05:14:04 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-17 05:14:04 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-17 05:14:04 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-17 05:14:04 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-17 05:14:04 --> Final output sent to browser
DEBUG - 2011-08-17 05:14:04 --> Total execution time: 0.0479
DEBUG - 2011-08-17 08:02:12 --> Config Class Initialized
DEBUG - 2011-08-17 08:02:12 --> Hooks Class Initialized
DEBUG - 2011-08-17 08:02:12 --> Utf8 Class Initialized
DEBUG - 2011-08-17 08:02:12 --> UTF-8 Support Enabled
DEBUG - 2011-08-17 08:02:12 --> URI Class Initialized
DEBUG - 2011-08-17 08:02:12 --> Router Class Initialized
DEBUG - 2011-08-17 08:02:12 --> No URI present. Default controller set.
DEBUG - 2011-08-17 08:02:12 --> Output Class Initialized
DEBUG - 2011-08-17 08:02:12 --> Input Class Initialized
DEBUG - 2011-08-17 08:02:12 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-17 08:02:12 --> Language Class Initialized
DEBUG - 2011-08-17 08:02:12 --> Loader Class Initialized
DEBUG - 2011-08-17 08:02:12 --> Controller Class Initialized
DEBUG - 2011-08-17 08:02:12 --> File loaded: application/views/splash/main.php
DEBUG - 2011-08-17 08:02:12 --> Helper loaded: url_helper
DEBUG - 2011-08-17 08:02:12 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-17 08:02:12 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-17 08:02:12 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-17 08:02:12 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-17 08:02:12 --> Final output sent to browser
DEBUG - 2011-08-17 08:02:12 --> Total execution time: 0.1307
DEBUG - 2011-08-17 09:40:10 --> Config Class Initialized
DEBUG - 2011-08-17 09:40:10 --> Hooks Class Initialized
DEBUG - 2011-08-17 09:40:10 --> Utf8 Class Initialized
DEBUG - 2011-08-17 09:40:10 --> UTF-8 Support Enabled
DEBUG - 2011-08-17 09:40:10 --> URI Class Initialized
DEBUG - 2011-08-17 09:40:10 --> Router Class Initialized
DEBUG - 2011-08-17 09:40:10 --> Output Class Initialized
DEBUG - 2011-08-17 09:40:10 --> Input Class Initialized
DEBUG - 2011-08-17 09:40:10 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-17 09:40:10 --> Language Class Initialized
DEBUG - 2011-08-17 09:40:10 --> Loader Class Initialized
DEBUG - 2011-08-17 09:40:10 --> Controller Class Initialized
DEBUG - 2011-08-17 09:40:10 --> Model Class Initialized
DEBUG - 2011-08-17 09:40:10 --> Model Class Initialized
DEBUG - 2011-08-17 09:40:10 --> Model Class Initialized
DEBUG - 2011-08-17 09:40:10 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-17 09:40:10 --> Database Driver Class Initialized
DEBUG - 2011-08-17 09:40:11 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-17 09:40:11 --> Helper loaded: url_helper
DEBUG - 2011-08-17 09:40:11 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-17 09:40:11 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-17 09:40:11 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-17 09:40:11 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-17 09:40:11 --> Final output sent to browser
DEBUG - 2011-08-17 09:40:11 --> Total execution time: 0.8335
DEBUG - 2011-08-17 09:40:14 --> Config Class Initialized
DEBUG - 2011-08-17 09:40:14 --> Hooks Class Initialized
DEBUG - 2011-08-17 09:40:14 --> Utf8 Class Initialized
DEBUG - 2011-08-17 09:40:14 --> UTF-8 Support Enabled
DEBUG - 2011-08-17 09:40:14 --> URI Class Initialized
DEBUG - 2011-08-17 09:40:14 --> Router Class Initialized
ERROR - 2011-08-17 09:40:14 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-17 09:40:14 --> Config Class Initialized
DEBUG - 2011-08-17 09:40:14 --> Hooks Class Initialized
DEBUG - 2011-08-17 09:40:14 --> Utf8 Class Initialized
DEBUG - 2011-08-17 09:40:14 --> UTF-8 Support Enabled
DEBUG - 2011-08-17 09:40:14 --> URI Class Initialized
DEBUG - 2011-08-17 09:40:14 --> Router Class Initialized
ERROR - 2011-08-17 09:40:14 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-17 09:40:15 --> Config Class Initialized
DEBUG - 2011-08-17 09:40:15 --> Hooks Class Initialized
DEBUG - 2011-08-17 09:40:15 --> Utf8 Class Initialized
DEBUG - 2011-08-17 09:40:15 --> UTF-8 Support Enabled
DEBUG - 2011-08-17 09:40:15 --> URI Class Initialized
DEBUG - 2011-08-17 09:40:15 --> Router Class Initialized
ERROR - 2011-08-17 09:40:15 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-17 09:56:49 --> Config Class Initialized
DEBUG - 2011-08-17 09:56:49 --> Hooks Class Initialized
DEBUG - 2011-08-17 09:56:49 --> Utf8 Class Initialized
DEBUG - 2011-08-17 09:56:49 --> UTF-8 Support Enabled
DEBUG - 2011-08-17 09:56:49 --> URI Class Initialized
DEBUG - 2011-08-17 09:56:49 --> Router Class Initialized
DEBUG - 2011-08-17 09:56:49 --> Output Class Initialized
DEBUG - 2011-08-17 09:56:49 --> Input Class Initialized
DEBUG - 2011-08-17 09:56:49 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-17 09:56:49 --> Language Class Initialized
DEBUG - 2011-08-17 09:56:49 --> Loader Class Initialized
DEBUG - 2011-08-17 09:56:49 --> Controller Class Initialized
ERROR - 2011-08-17 09:56:49 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-17 09:56:49 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-17 09:56:49 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-17 09:56:49 --> Model Class Initialized
DEBUG - 2011-08-17 09:56:49 --> Model Class Initialized
DEBUG - 2011-08-17 09:56:49 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-17 09:56:49 --> Database Driver Class Initialized
DEBUG - 2011-08-17 09:56:49 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-17 09:56:49 --> Helper loaded: url_helper
DEBUG - 2011-08-17 09:56:49 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-17 09:56:49 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-17 09:56:49 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-17 09:56:49 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-17 09:56:49 --> Final output sent to browser
DEBUG - 2011-08-17 09:56:49 --> Total execution time: 0.2234
DEBUG - 2011-08-17 09:56:51 --> Config Class Initialized
DEBUG - 2011-08-17 09:56:51 --> Hooks Class Initialized
DEBUG - 2011-08-17 09:56:51 --> Utf8 Class Initialized
DEBUG - 2011-08-17 09:56:51 --> UTF-8 Support Enabled
DEBUG - 2011-08-17 09:56:51 --> URI Class Initialized
DEBUG - 2011-08-17 09:56:51 --> Router Class Initialized
ERROR - 2011-08-17 09:56:51 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-17 09:56:52 --> Config Class Initialized
DEBUG - 2011-08-17 09:56:52 --> Hooks Class Initialized
DEBUG - 2011-08-17 09:56:52 --> Utf8 Class Initialized
DEBUG - 2011-08-17 09:56:52 --> UTF-8 Support Enabled
DEBUG - 2011-08-17 09:56:52 --> URI Class Initialized
DEBUG - 2011-08-17 09:56:52 --> Router Class Initialized
DEBUG - 2011-08-17 09:56:52 --> Output Class Initialized
DEBUG - 2011-08-17 09:56:52 --> Input Class Initialized
DEBUG - 2011-08-17 09:56:52 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-17 09:56:52 --> Language Class Initialized
DEBUG - 2011-08-17 09:56:52 --> Loader Class Initialized
DEBUG - 2011-08-17 09:56:52 --> Controller Class Initialized
DEBUG - 2011-08-17 09:56:52 --> Model Class Initialized
DEBUG - 2011-08-17 09:56:52 --> Model Class Initialized
DEBUG - 2011-08-17 09:56:52 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-17 09:56:52 --> Database Driver Class Initialized
DEBUG - 2011-08-17 09:56:53 --> Final output sent to browser
DEBUG - 2011-08-17 09:56:53 --> Total execution time: 0.7015
DEBUG - 2011-08-17 09:57:06 --> Config Class Initialized
DEBUG - 2011-08-17 09:57:06 --> Hooks Class Initialized
DEBUG - 2011-08-17 09:57:06 --> Utf8 Class Initialized
DEBUG - 2011-08-17 09:57:06 --> UTF-8 Support Enabled
DEBUG - 2011-08-17 09:57:06 --> URI Class Initialized
DEBUG - 2011-08-17 09:57:06 --> Router Class Initialized
DEBUG - 2011-08-17 09:57:06 --> Output Class Initialized
DEBUG - 2011-08-17 09:57:06 --> Input Class Initialized
DEBUG - 2011-08-17 09:57:06 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-17 09:57:06 --> Language Class Initialized
DEBUG - 2011-08-17 09:57:06 --> Loader Class Initialized
DEBUG - 2011-08-17 09:57:06 --> Controller Class Initialized
ERROR - 2011-08-17 09:57:06 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-17 09:57:06 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-17 09:57:06 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-17 09:57:06 --> Model Class Initialized
DEBUG - 2011-08-17 09:57:06 --> Model Class Initialized
DEBUG - 2011-08-17 09:57:06 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-17 09:57:06 --> Database Driver Class Initialized
DEBUG - 2011-08-17 09:57:06 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-17 09:57:06 --> Helper loaded: url_helper
DEBUG - 2011-08-17 09:57:06 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-17 09:57:06 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-17 09:57:06 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-17 09:57:06 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-17 09:57:06 --> Final output sent to browser
DEBUG - 2011-08-17 09:57:06 --> Total execution time: 0.1855
DEBUG - 2011-08-17 09:57:07 --> Config Class Initialized
DEBUG - 2011-08-17 09:57:07 --> Hooks Class Initialized
DEBUG - 2011-08-17 09:57:07 --> Utf8 Class Initialized
DEBUG - 2011-08-17 09:57:07 --> UTF-8 Support Enabled
DEBUG - 2011-08-17 09:57:07 --> URI Class Initialized
DEBUG - 2011-08-17 09:57:07 --> Router Class Initialized
DEBUG - 2011-08-17 09:57:07 --> Output Class Initialized
DEBUG - 2011-08-17 09:57:07 --> Input Class Initialized
DEBUG - 2011-08-17 09:57:07 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-17 09:57:07 --> Language Class Initialized
DEBUG - 2011-08-17 09:57:07 --> Loader Class Initialized
DEBUG - 2011-08-17 09:57:07 --> Controller Class Initialized
DEBUG - 2011-08-17 09:57:07 --> Model Class Initialized
DEBUG - 2011-08-17 09:57:07 --> Model Class Initialized
DEBUG - 2011-08-17 09:57:07 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-17 09:57:07 --> Database Driver Class Initialized
DEBUG - 2011-08-17 09:57:08 --> Final output sent to browser
DEBUG - 2011-08-17 09:57:08 --> Total execution time: 0.7919
DEBUG - 2011-08-17 09:57:39 --> Config Class Initialized
DEBUG - 2011-08-17 09:57:39 --> Hooks Class Initialized
DEBUG - 2011-08-17 09:57:39 --> Utf8 Class Initialized
DEBUG - 2011-08-17 09:57:39 --> UTF-8 Support Enabled
DEBUG - 2011-08-17 09:57:39 --> URI Class Initialized
DEBUG - 2011-08-17 09:57:39 --> Router Class Initialized
DEBUG - 2011-08-17 09:57:39 --> Output Class Initialized
DEBUG - 2011-08-17 09:57:39 --> Input Class Initialized
DEBUG - 2011-08-17 09:57:39 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-17 09:57:39 --> Language Class Initialized
DEBUG - 2011-08-17 09:57:39 --> Loader Class Initialized
DEBUG - 2011-08-17 09:57:39 --> Controller Class Initialized
ERROR - 2011-08-17 09:57:39 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-17 09:57:39 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-17 09:57:39 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-17 09:57:39 --> Model Class Initialized
DEBUG - 2011-08-17 09:57:39 --> Model Class Initialized
DEBUG - 2011-08-17 09:57:39 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-17 09:57:39 --> Database Driver Class Initialized
DEBUG - 2011-08-17 09:57:39 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-17 09:57:39 --> Helper loaded: url_helper
DEBUG - 2011-08-17 09:57:39 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-17 09:57:39 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-17 09:57:39 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-17 09:57:39 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-17 09:57:39 --> Final output sent to browser
DEBUG - 2011-08-17 09:57:39 --> Total execution time: 0.1471
DEBUG - 2011-08-17 09:57:40 --> Config Class Initialized
DEBUG - 2011-08-17 09:57:40 --> Hooks Class Initialized
DEBUG - 2011-08-17 09:57:40 --> Utf8 Class Initialized
DEBUG - 2011-08-17 09:57:40 --> UTF-8 Support Enabled
DEBUG - 2011-08-17 09:57:40 --> URI Class Initialized
DEBUG - 2011-08-17 09:57:40 --> Router Class Initialized
DEBUG - 2011-08-17 09:57:40 --> Output Class Initialized
DEBUG - 2011-08-17 09:57:40 --> Input Class Initialized
DEBUG - 2011-08-17 09:57:40 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-17 09:57:40 --> Language Class Initialized
DEBUG - 2011-08-17 09:57:40 --> Loader Class Initialized
DEBUG - 2011-08-17 09:57:40 --> Controller Class Initialized
DEBUG - 2011-08-17 09:57:40 --> Model Class Initialized
DEBUG - 2011-08-17 09:57:40 --> Model Class Initialized
DEBUG - 2011-08-17 09:57:40 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-17 09:57:40 --> Database Driver Class Initialized
DEBUG - 2011-08-17 09:57:41 --> Final output sent to browser
DEBUG - 2011-08-17 09:57:41 --> Total execution time: 0.7719
DEBUG - 2011-08-17 12:42:34 --> Config Class Initialized
DEBUG - 2011-08-17 12:42:34 --> Hooks Class Initialized
DEBUG - 2011-08-17 12:42:34 --> Utf8 Class Initialized
DEBUG - 2011-08-17 12:42:34 --> UTF-8 Support Enabled
DEBUG - 2011-08-17 12:42:34 --> URI Class Initialized
DEBUG - 2011-08-17 12:42:34 --> Router Class Initialized
DEBUG - 2011-08-17 12:42:34 --> Output Class Initialized
DEBUG - 2011-08-17 12:42:34 --> Input Class Initialized
DEBUG - 2011-08-17 12:42:34 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-17 12:42:34 --> Language Class Initialized
DEBUG - 2011-08-17 12:42:34 --> Loader Class Initialized
DEBUG - 2011-08-17 12:42:34 --> Controller Class Initialized
DEBUG - 2011-08-17 12:42:34 --> Model Class Initialized
DEBUG - 2011-08-17 12:42:34 --> Model Class Initialized
DEBUG - 2011-08-17 12:42:34 --> Model Class Initialized
DEBUG - 2011-08-17 12:42:34 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-17 12:42:34 --> Database Driver Class Initialized
DEBUG - 2011-08-17 12:42:35 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-17 12:42:35 --> Helper loaded: url_helper
DEBUG - 2011-08-17 12:42:35 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-17 12:42:35 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-17 12:42:35 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-17 12:42:35 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-17 12:42:35 --> Final output sent to browser
DEBUG - 2011-08-17 12:42:35 --> Total execution time: 1.1010
DEBUG - 2011-08-17 12:42:37 --> Config Class Initialized
DEBUG - 2011-08-17 12:42:37 --> Hooks Class Initialized
DEBUG - 2011-08-17 12:42:37 --> Utf8 Class Initialized
DEBUG - 2011-08-17 12:42:37 --> UTF-8 Support Enabled
DEBUG - 2011-08-17 12:42:37 --> URI Class Initialized
DEBUG - 2011-08-17 12:42:37 --> Router Class Initialized
ERROR - 2011-08-17 12:42:37 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-17 12:58:37 --> Config Class Initialized
DEBUG - 2011-08-17 12:58:37 --> Hooks Class Initialized
DEBUG - 2011-08-17 12:58:37 --> Utf8 Class Initialized
DEBUG - 2011-08-17 12:58:37 --> UTF-8 Support Enabled
DEBUG - 2011-08-17 12:58:37 --> URI Class Initialized
DEBUG - 2011-08-17 12:58:37 --> Router Class Initialized
DEBUG - 2011-08-17 12:58:37 --> Output Class Initialized
DEBUG - 2011-08-17 12:58:37 --> Input Class Initialized
DEBUG - 2011-08-17 12:58:37 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-17 12:58:37 --> Language Class Initialized
DEBUG - 2011-08-17 12:58:37 --> Loader Class Initialized
DEBUG - 2011-08-17 12:58:37 --> Controller Class Initialized
ERROR - 2011-08-17 12:58:37 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-17 12:58:37 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-17 12:58:37 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-17 12:58:37 --> Model Class Initialized
DEBUG - 2011-08-17 12:58:37 --> Model Class Initialized
DEBUG - 2011-08-17 12:58:37 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-17 12:58:37 --> Database Driver Class Initialized
DEBUG - 2011-08-17 12:58:37 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-17 12:58:37 --> Helper loaded: url_helper
DEBUG - 2011-08-17 12:58:37 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-17 12:58:37 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-17 12:58:37 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-17 12:58:37 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-17 12:58:37 --> Final output sent to browser
DEBUG - 2011-08-17 12:58:37 --> Total execution time: 0.1576
DEBUG - 2011-08-17 12:58:38 --> Config Class Initialized
DEBUG - 2011-08-17 12:58:38 --> Hooks Class Initialized
DEBUG - 2011-08-17 12:58:38 --> Utf8 Class Initialized
DEBUG - 2011-08-17 12:58:38 --> UTF-8 Support Enabled
DEBUG - 2011-08-17 12:58:38 --> URI Class Initialized
DEBUG - 2011-08-17 12:58:38 --> Router Class Initialized
DEBUG - 2011-08-17 12:58:38 --> Output Class Initialized
DEBUG - 2011-08-17 12:58:38 --> Input Class Initialized
DEBUG - 2011-08-17 12:58:38 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-17 12:58:38 --> Language Class Initialized
DEBUG - 2011-08-17 12:58:38 --> Loader Class Initialized
DEBUG - 2011-08-17 12:58:38 --> Controller Class Initialized
DEBUG - 2011-08-17 12:58:38 --> Model Class Initialized
DEBUG - 2011-08-17 12:58:38 --> Model Class Initialized
DEBUG - 2011-08-17 12:58:38 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-17 12:58:38 --> Database Driver Class Initialized
DEBUG - 2011-08-17 12:58:39 --> Final output sent to browser
DEBUG - 2011-08-17 12:58:39 --> Total execution time: 0.8261
DEBUG - 2011-08-17 12:58:43 --> Config Class Initialized
DEBUG - 2011-08-17 12:58:43 --> Hooks Class Initialized
DEBUG - 2011-08-17 12:58:43 --> Utf8 Class Initialized
DEBUG - 2011-08-17 12:58:43 --> UTF-8 Support Enabled
DEBUG - 2011-08-17 12:58:43 --> URI Class Initialized
DEBUG - 2011-08-17 12:58:43 --> Router Class Initialized
ERROR - 2011-08-17 12:58:43 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-17 12:58:46 --> Config Class Initialized
DEBUG - 2011-08-17 12:58:46 --> Hooks Class Initialized
DEBUG - 2011-08-17 12:58:46 --> Utf8 Class Initialized
DEBUG - 2011-08-17 12:58:46 --> UTF-8 Support Enabled
DEBUG - 2011-08-17 12:58:46 --> URI Class Initialized
DEBUG - 2011-08-17 12:58:46 --> Router Class Initialized
ERROR - 2011-08-17 12:58:46 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-17 12:58:53 --> Config Class Initialized
DEBUG - 2011-08-17 12:58:53 --> Hooks Class Initialized
DEBUG - 2011-08-17 12:58:53 --> Utf8 Class Initialized
DEBUG - 2011-08-17 12:58:53 --> UTF-8 Support Enabled
DEBUG - 2011-08-17 12:58:53 --> URI Class Initialized
DEBUG - 2011-08-17 12:58:53 --> Router Class Initialized
DEBUG - 2011-08-17 12:58:53 --> Output Class Initialized
DEBUG - 2011-08-17 12:58:53 --> Input Class Initialized
DEBUG - 2011-08-17 12:58:53 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-17 12:58:53 --> Language Class Initialized
DEBUG - 2011-08-17 12:58:53 --> Loader Class Initialized
DEBUG - 2011-08-17 12:58:53 --> Controller Class Initialized
ERROR - 2011-08-17 12:58:53 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-17 12:58:53 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-17 12:58:53 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-17 12:58:53 --> Model Class Initialized
DEBUG - 2011-08-17 12:58:53 --> Model Class Initialized
DEBUG - 2011-08-17 12:58:53 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-17 12:58:53 --> Database Driver Class Initialized
DEBUG - 2011-08-17 12:58:53 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-17 12:58:53 --> Helper loaded: url_helper
DEBUG - 2011-08-17 12:58:53 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-17 12:58:53 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-17 12:58:53 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-17 12:58:53 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-17 12:58:53 --> Final output sent to browser
DEBUG - 2011-08-17 12:58:53 --> Total execution time: 0.0934
DEBUG - 2011-08-17 12:58:54 --> Config Class Initialized
DEBUG - 2011-08-17 12:58:54 --> Hooks Class Initialized
DEBUG - 2011-08-17 12:58:54 --> Utf8 Class Initialized
DEBUG - 2011-08-17 12:58:54 --> UTF-8 Support Enabled
DEBUG - 2011-08-17 12:58:54 --> URI Class Initialized
DEBUG - 2011-08-17 12:58:54 --> Router Class Initialized
DEBUG - 2011-08-17 12:58:54 --> Output Class Initialized
DEBUG - 2011-08-17 12:58:54 --> Input Class Initialized
DEBUG - 2011-08-17 12:58:54 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-17 12:58:54 --> Language Class Initialized
DEBUG - 2011-08-17 12:58:54 --> Loader Class Initialized
DEBUG - 2011-08-17 12:58:54 --> Controller Class Initialized
DEBUG - 2011-08-17 12:58:54 --> Model Class Initialized
DEBUG - 2011-08-17 12:58:54 --> Model Class Initialized
DEBUG - 2011-08-17 12:58:54 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-17 12:58:54 --> Database Driver Class Initialized
DEBUG - 2011-08-17 12:58:55 --> Final output sent to browser
DEBUG - 2011-08-17 12:58:55 --> Total execution time: 0.6980
DEBUG - 2011-08-17 12:59:04 --> Config Class Initialized
DEBUG - 2011-08-17 12:59:04 --> Hooks Class Initialized
DEBUG - 2011-08-17 12:59:04 --> Utf8 Class Initialized
DEBUG - 2011-08-17 12:59:04 --> UTF-8 Support Enabled
DEBUG - 2011-08-17 12:59:04 --> URI Class Initialized
DEBUG - 2011-08-17 12:59:04 --> Router Class Initialized
DEBUG - 2011-08-17 12:59:04 --> Output Class Initialized
DEBUG - 2011-08-17 12:59:04 --> Input Class Initialized
DEBUG - 2011-08-17 12:59:04 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-17 12:59:04 --> Language Class Initialized
DEBUG - 2011-08-17 12:59:04 --> Loader Class Initialized
DEBUG - 2011-08-17 12:59:04 --> Controller Class Initialized
ERROR - 2011-08-17 12:59:04 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-17 12:59:04 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-17 12:59:04 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-17 12:59:04 --> Model Class Initialized
DEBUG - 2011-08-17 12:59:04 --> Model Class Initialized
DEBUG - 2011-08-17 12:59:04 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-17 12:59:04 --> Database Driver Class Initialized
DEBUG - 2011-08-17 12:59:05 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-17 12:59:05 --> Helper loaded: url_helper
DEBUG - 2011-08-17 12:59:05 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-17 12:59:05 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-17 12:59:05 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-17 12:59:05 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-17 12:59:05 --> Final output sent to browser
DEBUG - 2011-08-17 12:59:05 --> Total execution time: 0.1324
DEBUG - 2011-08-17 12:59:05 --> Config Class Initialized
DEBUG - 2011-08-17 12:59:05 --> Hooks Class Initialized
DEBUG - 2011-08-17 12:59:05 --> Utf8 Class Initialized
DEBUG - 2011-08-17 12:59:05 --> UTF-8 Support Enabled
DEBUG - 2011-08-17 12:59:05 --> URI Class Initialized
DEBUG - 2011-08-17 12:59:05 --> Router Class Initialized
DEBUG - 2011-08-17 12:59:05 --> Output Class Initialized
DEBUG - 2011-08-17 12:59:05 --> Input Class Initialized
DEBUG - 2011-08-17 12:59:05 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-17 12:59:05 --> Language Class Initialized
DEBUG - 2011-08-17 12:59:05 --> Loader Class Initialized
DEBUG - 2011-08-17 12:59:05 --> Controller Class Initialized
DEBUG - 2011-08-17 12:59:05 --> Model Class Initialized
DEBUG - 2011-08-17 12:59:05 --> Model Class Initialized
DEBUG - 2011-08-17 12:59:05 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-17 12:59:05 --> Database Driver Class Initialized
DEBUG - 2011-08-17 12:59:06 --> Final output sent to browser
DEBUG - 2011-08-17 12:59:06 --> Total execution time: 0.9957
DEBUG - 2011-08-17 12:59:22 --> Config Class Initialized
DEBUG - 2011-08-17 12:59:22 --> Hooks Class Initialized
DEBUG - 2011-08-17 12:59:22 --> Utf8 Class Initialized
DEBUG - 2011-08-17 12:59:22 --> UTF-8 Support Enabled
DEBUG - 2011-08-17 12:59:22 --> URI Class Initialized
DEBUG - 2011-08-17 12:59:22 --> Router Class Initialized
DEBUG - 2011-08-17 12:59:22 --> Output Class Initialized
DEBUG - 2011-08-17 12:59:22 --> Input Class Initialized
DEBUG - 2011-08-17 12:59:22 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-17 12:59:22 --> Language Class Initialized
DEBUG - 2011-08-17 12:59:22 --> Loader Class Initialized
DEBUG - 2011-08-17 12:59:22 --> Controller Class Initialized
ERROR - 2011-08-17 12:59:22 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-17 12:59:22 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-17 12:59:22 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-17 12:59:22 --> Model Class Initialized
DEBUG - 2011-08-17 12:59:22 --> Model Class Initialized
DEBUG - 2011-08-17 12:59:22 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-17 12:59:22 --> Database Driver Class Initialized
DEBUG - 2011-08-17 12:59:22 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-17 12:59:22 --> Helper loaded: url_helper
DEBUG - 2011-08-17 12:59:22 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-17 12:59:22 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-17 12:59:22 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-17 12:59:22 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-17 12:59:22 --> Final output sent to browser
DEBUG - 2011-08-17 12:59:22 --> Total execution time: 0.0315
DEBUG - 2011-08-17 12:59:23 --> Config Class Initialized
DEBUG - 2011-08-17 12:59:23 --> Hooks Class Initialized
DEBUG - 2011-08-17 12:59:23 --> Utf8 Class Initialized
DEBUG - 2011-08-17 12:59:23 --> UTF-8 Support Enabled
DEBUG - 2011-08-17 12:59:23 --> URI Class Initialized
DEBUG - 2011-08-17 12:59:23 --> Router Class Initialized
DEBUG - 2011-08-17 12:59:23 --> Output Class Initialized
DEBUG - 2011-08-17 12:59:23 --> Input Class Initialized
DEBUG - 2011-08-17 12:59:23 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-17 12:59:23 --> Language Class Initialized
DEBUG - 2011-08-17 12:59:23 --> Loader Class Initialized
DEBUG - 2011-08-17 12:59:23 --> Controller Class Initialized
DEBUG - 2011-08-17 12:59:23 --> Model Class Initialized
DEBUG - 2011-08-17 12:59:23 --> Model Class Initialized
DEBUG - 2011-08-17 12:59:23 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-17 12:59:23 --> Database Driver Class Initialized
DEBUG - 2011-08-17 12:59:23 --> Final output sent to browser
DEBUG - 2011-08-17 12:59:23 --> Total execution time: 0.5575
DEBUG - 2011-08-17 13:05:38 --> Config Class Initialized
DEBUG - 2011-08-17 13:05:38 --> Hooks Class Initialized
DEBUG - 2011-08-17 13:05:38 --> Utf8 Class Initialized
DEBUG - 2011-08-17 13:05:38 --> UTF-8 Support Enabled
DEBUG - 2011-08-17 13:05:38 --> URI Class Initialized
DEBUG - 2011-08-17 13:05:38 --> Router Class Initialized
DEBUG - 2011-08-17 13:05:38 --> Output Class Initialized
DEBUG - 2011-08-17 13:05:38 --> Input Class Initialized
DEBUG - 2011-08-17 13:05:38 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-17 13:05:38 --> Language Class Initialized
DEBUG - 2011-08-17 13:05:38 --> Loader Class Initialized
DEBUG - 2011-08-17 13:05:38 --> Controller Class Initialized
DEBUG - 2011-08-17 13:05:38 --> Model Class Initialized
DEBUG - 2011-08-17 13:05:38 --> Model Class Initialized
DEBUG - 2011-08-17 13:05:38 --> Model Class Initialized
DEBUG - 2011-08-17 13:05:38 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-17 13:05:38 --> Database Driver Class Initialized
DEBUG - 2011-08-17 13:05:39 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-17 13:05:39 --> Helper loaded: url_helper
DEBUG - 2011-08-17 13:05:39 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-17 13:05:39 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-17 13:05:39 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-17 13:05:39 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-17 13:05:39 --> Final output sent to browser
DEBUG - 2011-08-17 13:05:39 --> Total execution time: 0.3128
DEBUG - 2011-08-17 13:05:40 --> Config Class Initialized
DEBUG - 2011-08-17 13:05:40 --> Hooks Class Initialized
DEBUG - 2011-08-17 13:05:40 --> Utf8 Class Initialized
DEBUG - 2011-08-17 13:05:40 --> UTF-8 Support Enabled
DEBUG - 2011-08-17 13:05:40 --> URI Class Initialized
DEBUG - 2011-08-17 13:05:40 --> Router Class Initialized
ERROR - 2011-08-17 13:05:40 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-17 13:30:09 --> Config Class Initialized
DEBUG - 2011-08-17 13:30:09 --> Hooks Class Initialized
DEBUG - 2011-08-17 13:30:09 --> Utf8 Class Initialized
DEBUG - 2011-08-17 13:30:09 --> UTF-8 Support Enabled
DEBUG - 2011-08-17 13:30:09 --> URI Class Initialized
DEBUG - 2011-08-17 13:30:09 --> Router Class Initialized
DEBUG - 2011-08-17 13:30:09 --> Output Class Initialized
DEBUG - 2011-08-17 13:30:09 --> Input Class Initialized
DEBUG - 2011-08-17 13:30:09 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-17 13:30:09 --> Language Class Initialized
DEBUG - 2011-08-17 13:30:09 --> Loader Class Initialized
DEBUG - 2011-08-17 13:30:09 --> Controller Class Initialized
ERROR - 2011-08-17 13:30:09 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-17 13:30:09 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-17 13:30:09 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-17 13:30:09 --> Model Class Initialized
DEBUG - 2011-08-17 13:30:09 --> Model Class Initialized
DEBUG - 2011-08-17 13:30:09 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-17 13:30:09 --> Database Driver Class Initialized
DEBUG - 2011-08-17 13:30:09 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-17 13:30:09 --> Helper loaded: url_helper
DEBUG - 2011-08-17 13:30:09 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-17 13:30:09 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-17 13:30:09 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-17 13:30:09 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-17 13:30:09 --> Final output sent to browser
DEBUG - 2011-08-17 13:30:09 --> Total execution time: 0.0782
DEBUG - 2011-08-17 13:30:12 --> Config Class Initialized
DEBUG - 2011-08-17 13:30:12 --> Hooks Class Initialized
DEBUG - 2011-08-17 13:30:12 --> Utf8 Class Initialized
DEBUG - 2011-08-17 13:30:12 --> UTF-8 Support Enabled
DEBUG - 2011-08-17 13:30:12 --> URI Class Initialized
DEBUG - 2011-08-17 13:30:12 --> Router Class Initialized
DEBUG - 2011-08-17 13:30:12 --> Output Class Initialized
DEBUG - 2011-08-17 13:30:12 --> Input Class Initialized
DEBUG - 2011-08-17 13:30:12 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-17 13:30:12 --> Language Class Initialized
DEBUG - 2011-08-17 13:30:12 --> Loader Class Initialized
DEBUG - 2011-08-17 13:30:12 --> Controller Class Initialized
DEBUG - 2011-08-17 13:30:12 --> Model Class Initialized
DEBUG - 2011-08-17 13:30:12 --> Model Class Initialized
DEBUG - 2011-08-17 13:30:12 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-17 13:30:12 --> Database Driver Class Initialized
DEBUG - 2011-08-17 13:30:14 --> Final output sent to browser
DEBUG - 2011-08-17 13:30:14 --> Total execution time: 2.0180
DEBUG - 2011-08-17 13:30:17 --> Config Class Initialized
DEBUG - 2011-08-17 13:30:17 --> Hooks Class Initialized
DEBUG - 2011-08-17 13:30:17 --> Utf8 Class Initialized
DEBUG - 2011-08-17 13:30:17 --> UTF-8 Support Enabled
DEBUG - 2011-08-17 13:30:17 --> URI Class Initialized
DEBUG - 2011-08-17 13:30:17 --> Router Class Initialized
ERROR - 2011-08-17 13:30:17 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-17 13:30:18 --> Config Class Initialized
DEBUG - 2011-08-17 13:30:18 --> Hooks Class Initialized
DEBUG - 2011-08-17 13:30:18 --> Utf8 Class Initialized
DEBUG - 2011-08-17 13:30:18 --> UTF-8 Support Enabled
DEBUG - 2011-08-17 13:30:18 --> URI Class Initialized
DEBUG - 2011-08-17 13:30:18 --> Router Class Initialized
ERROR - 2011-08-17 13:30:18 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-17 14:34:17 --> Config Class Initialized
DEBUG - 2011-08-17 14:34:17 --> Hooks Class Initialized
DEBUG - 2011-08-17 14:34:17 --> Utf8 Class Initialized
DEBUG - 2011-08-17 14:34:17 --> UTF-8 Support Enabled
DEBUG - 2011-08-17 14:34:17 --> URI Class Initialized
DEBUG - 2011-08-17 14:34:17 --> Router Class Initialized
DEBUG - 2011-08-17 14:34:17 --> Output Class Initialized
DEBUG - 2011-08-17 14:34:17 --> Input Class Initialized
DEBUG - 2011-08-17 14:34:17 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-17 14:34:17 --> Language Class Initialized
DEBUG - 2011-08-17 14:34:17 --> Loader Class Initialized
DEBUG - 2011-08-17 14:34:17 --> Controller Class Initialized
DEBUG - 2011-08-17 14:34:17 --> Model Class Initialized
DEBUG - 2011-08-17 14:34:17 --> Model Class Initialized
DEBUG - 2011-08-17 14:34:17 --> Model Class Initialized
DEBUG - 2011-08-17 14:34:17 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-17 14:34:17 --> Database Driver Class Initialized
DEBUG - 2011-08-17 14:34:17 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-17 14:34:17 --> Helper loaded: url_helper
DEBUG - 2011-08-17 14:34:17 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-17 14:34:17 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-17 14:34:17 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-17 14:34:17 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-17 14:34:17 --> Final output sent to browser
DEBUG - 2011-08-17 14:34:17 --> Total execution time: 0.2479
DEBUG - 2011-08-17 14:34:24 --> Config Class Initialized
DEBUG - 2011-08-17 14:34:24 --> Hooks Class Initialized
DEBUG - 2011-08-17 14:34:24 --> Utf8 Class Initialized
DEBUG - 2011-08-17 14:34:24 --> UTF-8 Support Enabled
DEBUG - 2011-08-17 14:34:24 --> URI Class Initialized
DEBUG - 2011-08-17 14:34:24 --> Router Class Initialized
ERROR - 2011-08-17 14:34:24 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-17 14:34:33 --> Config Class Initialized
DEBUG - 2011-08-17 14:34:33 --> Hooks Class Initialized
DEBUG - 2011-08-17 14:34:33 --> Utf8 Class Initialized
DEBUG - 2011-08-17 14:34:33 --> UTF-8 Support Enabled
DEBUG - 2011-08-17 14:34:33 --> URI Class Initialized
DEBUG - 2011-08-17 14:34:33 --> Router Class Initialized
DEBUG - 2011-08-17 14:34:33 --> Output Class Initialized
DEBUG - 2011-08-17 14:34:33 --> Input Class Initialized
DEBUG - 2011-08-17 14:34:33 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-17 14:34:33 --> Language Class Initialized
DEBUG - 2011-08-17 14:34:33 --> Loader Class Initialized
DEBUG - 2011-08-17 14:34:33 --> Controller Class Initialized
DEBUG - 2011-08-17 14:34:33 --> Model Class Initialized
DEBUG - 2011-08-17 14:34:33 --> Model Class Initialized
DEBUG - 2011-08-17 14:34:33 --> Model Class Initialized
DEBUG - 2011-08-17 14:34:33 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-17 14:34:33 --> Database Driver Class Initialized
DEBUG - 2011-08-17 14:34:34 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-17 14:34:34 --> Helper loaded: url_helper
DEBUG - 2011-08-17 14:34:34 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-17 14:34:34 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-17 14:34:34 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-17 14:34:34 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-17 14:34:34 --> Final output sent to browser
DEBUG - 2011-08-17 14:34:34 --> Total execution time: 0.5403
DEBUG - 2011-08-17 14:34:45 --> Config Class Initialized
DEBUG - 2011-08-17 14:34:45 --> Hooks Class Initialized
DEBUG - 2011-08-17 14:34:45 --> Utf8 Class Initialized
DEBUG - 2011-08-17 14:34:45 --> UTF-8 Support Enabled
DEBUG - 2011-08-17 14:34:45 --> URI Class Initialized
DEBUG - 2011-08-17 14:34:45 --> Router Class Initialized
ERROR - 2011-08-17 14:34:45 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-08-17 14:34:45 --> Config Class Initialized
DEBUG - 2011-08-17 14:34:45 --> Hooks Class Initialized
DEBUG - 2011-08-17 14:34:45 --> Utf8 Class Initialized
DEBUG - 2011-08-17 14:34:45 --> UTF-8 Support Enabled
DEBUG - 2011-08-17 14:34:45 --> URI Class Initialized
DEBUG - 2011-08-17 14:34:45 --> Router Class Initialized
DEBUG - 2011-08-17 14:34:45 --> Output Class Initialized
DEBUG - 2011-08-17 14:34:45 --> Input Class Initialized
DEBUG - 2011-08-17 14:34:45 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-17 14:34:45 --> Language Class Initialized
DEBUG - 2011-08-17 14:34:45 --> Loader Class Initialized
DEBUG - 2011-08-17 14:34:45 --> Controller Class Initialized
DEBUG - 2011-08-17 14:34:45 --> Model Class Initialized
DEBUG - 2011-08-17 14:34:45 --> Model Class Initialized
DEBUG - 2011-08-17 14:34:45 --> Model Class Initialized
DEBUG - 2011-08-17 14:34:45 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-17 14:34:45 --> Database Driver Class Initialized
DEBUG - 2011-08-17 14:34:45 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-17 14:34:45 --> Helper loaded: url_helper
DEBUG - 2011-08-17 14:34:45 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-17 14:34:45 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-17 14:34:45 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-17 14:34:45 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-17 14:34:45 --> Final output sent to browser
DEBUG - 2011-08-17 14:34:45 --> Total execution time: 0.0484
DEBUG - 2011-08-17 14:34:55 --> Config Class Initialized
DEBUG - 2011-08-17 14:34:55 --> Hooks Class Initialized
DEBUG - 2011-08-17 14:34:55 --> Utf8 Class Initialized
DEBUG - 2011-08-17 14:34:55 --> UTF-8 Support Enabled
DEBUG - 2011-08-17 14:34:55 --> URI Class Initialized
DEBUG - 2011-08-17 14:34:55 --> Router Class Initialized
DEBUG - 2011-08-17 14:34:55 --> Output Class Initialized
DEBUG - 2011-08-17 14:34:55 --> Input Class Initialized
DEBUG - 2011-08-17 14:34:55 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-17 14:34:55 --> Language Class Initialized
DEBUG - 2011-08-17 14:34:55 --> Loader Class Initialized
DEBUG - 2011-08-17 14:34:55 --> Controller Class Initialized
DEBUG - 2011-08-17 14:34:55 --> Model Class Initialized
DEBUG - 2011-08-17 14:34:55 --> Model Class Initialized
DEBUG - 2011-08-17 14:34:55 --> Model Class Initialized
DEBUG - 2011-08-17 14:34:55 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-17 14:34:55 --> Database Driver Class Initialized
DEBUG - 2011-08-17 14:34:55 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-17 14:34:55 --> Helper loaded: url_helper
DEBUG - 2011-08-17 14:34:55 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-17 14:34:55 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-17 14:34:55 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-17 14:34:55 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-17 14:34:55 --> Final output sent to browser
DEBUG - 2011-08-17 14:34:55 --> Total execution time: 0.5349
DEBUG - 2011-08-17 14:35:03 --> Config Class Initialized
DEBUG - 2011-08-17 14:35:03 --> Hooks Class Initialized
DEBUG - 2011-08-17 14:35:03 --> Utf8 Class Initialized
DEBUG - 2011-08-17 14:35:03 --> UTF-8 Support Enabled
DEBUG - 2011-08-17 14:35:03 --> URI Class Initialized
DEBUG - 2011-08-17 14:35:03 --> Router Class Initialized
DEBUG - 2011-08-17 14:35:03 --> Output Class Initialized
DEBUG - 2011-08-17 14:35:03 --> Input Class Initialized
DEBUG - 2011-08-17 14:35:03 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-17 14:35:03 --> Language Class Initialized
DEBUG - 2011-08-17 14:35:03 --> Loader Class Initialized
DEBUG - 2011-08-17 14:35:03 --> Controller Class Initialized
DEBUG - 2011-08-17 14:35:03 --> Model Class Initialized
DEBUG - 2011-08-17 14:35:03 --> Model Class Initialized
DEBUG - 2011-08-17 14:35:03 --> Model Class Initialized
DEBUG - 2011-08-17 14:35:03 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-17 14:35:03 --> Database Driver Class Initialized
DEBUG - 2011-08-17 14:35:03 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-17 14:35:03 --> Helper loaded: url_helper
DEBUG - 2011-08-17 14:35:03 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-17 14:35:03 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-17 14:35:03 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-17 14:35:03 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-17 14:35:03 --> Final output sent to browser
DEBUG - 2011-08-17 14:35:03 --> Total execution time: 0.1158
DEBUG - 2011-08-17 14:35:07 --> Config Class Initialized
DEBUG - 2011-08-17 14:35:07 --> Hooks Class Initialized
DEBUG - 2011-08-17 14:35:07 --> Utf8 Class Initialized
DEBUG - 2011-08-17 14:35:07 --> UTF-8 Support Enabled
DEBUG - 2011-08-17 14:35:07 --> URI Class Initialized
DEBUG - 2011-08-17 14:35:07 --> Router Class Initialized
DEBUG - 2011-08-17 14:35:07 --> Output Class Initialized
DEBUG - 2011-08-17 14:35:07 --> Input Class Initialized
DEBUG - 2011-08-17 14:35:07 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-17 14:35:07 --> Language Class Initialized
DEBUG - 2011-08-17 14:35:07 --> Loader Class Initialized
DEBUG - 2011-08-17 14:35:07 --> Controller Class Initialized
DEBUG - 2011-08-17 14:35:07 --> Model Class Initialized
DEBUG - 2011-08-17 14:35:07 --> Model Class Initialized
DEBUG - 2011-08-17 14:35:07 --> Model Class Initialized
DEBUG - 2011-08-17 14:35:07 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-17 14:35:07 --> Database Driver Class Initialized
DEBUG - 2011-08-17 14:35:07 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-17 14:35:07 --> Helper loaded: url_helper
DEBUG - 2011-08-17 14:35:07 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-17 14:35:07 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-17 14:35:07 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-17 14:35:07 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-17 14:35:07 --> Final output sent to browser
DEBUG - 2011-08-17 14:35:07 --> Total execution time: 0.2674
DEBUG - 2011-08-17 14:35:11 --> Config Class Initialized
DEBUG - 2011-08-17 14:35:11 --> Hooks Class Initialized
DEBUG - 2011-08-17 14:35:11 --> Utf8 Class Initialized
DEBUG - 2011-08-17 14:35:11 --> UTF-8 Support Enabled
DEBUG - 2011-08-17 14:35:11 --> URI Class Initialized
DEBUG - 2011-08-17 14:35:11 --> Router Class Initialized
DEBUG - 2011-08-17 14:35:11 --> Output Class Initialized
DEBUG - 2011-08-17 14:35:11 --> Input Class Initialized
DEBUG - 2011-08-17 14:35:11 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-17 14:35:11 --> Language Class Initialized
DEBUG - 2011-08-17 14:35:11 --> Loader Class Initialized
DEBUG - 2011-08-17 14:35:11 --> Controller Class Initialized
DEBUG - 2011-08-17 14:35:11 --> Model Class Initialized
DEBUG - 2011-08-17 14:35:11 --> Model Class Initialized
DEBUG - 2011-08-17 14:35:11 --> Model Class Initialized
DEBUG - 2011-08-17 14:35:11 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-17 14:35:11 --> Database Driver Class Initialized
DEBUG - 2011-08-17 14:35:11 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-17 14:35:11 --> Helper loaded: url_helper
DEBUG - 2011-08-17 14:35:11 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-17 14:35:11 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-17 14:35:11 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-17 14:35:11 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-17 14:35:11 --> Final output sent to browser
DEBUG - 2011-08-17 14:35:11 --> Total execution time: 0.0502
DEBUG - 2011-08-17 14:35:24 --> Config Class Initialized
DEBUG - 2011-08-17 14:35:24 --> Hooks Class Initialized
DEBUG - 2011-08-17 14:35:24 --> Utf8 Class Initialized
DEBUG - 2011-08-17 14:35:24 --> UTF-8 Support Enabled
DEBUG - 2011-08-17 14:35:24 --> URI Class Initialized
DEBUG - 2011-08-17 14:35:24 --> Router Class Initialized
DEBUG - 2011-08-17 14:35:24 --> Output Class Initialized
DEBUG - 2011-08-17 14:35:24 --> Input Class Initialized
DEBUG - 2011-08-17 14:35:24 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-17 14:35:24 --> Language Class Initialized
DEBUG - 2011-08-17 14:35:24 --> Loader Class Initialized
DEBUG - 2011-08-17 14:35:24 --> Controller Class Initialized
DEBUG - 2011-08-17 14:35:24 --> Model Class Initialized
DEBUG - 2011-08-17 14:35:24 --> Model Class Initialized
DEBUG - 2011-08-17 14:35:24 --> Model Class Initialized
DEBUG - 2011-08-17 14:35:24 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-17 14:35:24 --> Database Driver Class Initialized
DEBUG - 2011-08-17 14:35:25 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-17 14:35:25 --> Helper loaded: url_helper
DEBUG - 2011-08-17 14:35:25 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-17 14:35:25 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-17 14:35:25 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-17 14:35:25 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-17 14:35:25 --> Final output sent to browser
DEBUG - 2011-08-17 14:35:25 --> Total execution time: 0.6686
DEBUG - 2011-08-17 14:35:27 --> Config Class Initialized
DEBUG - 2011-08-17 14:35:27 --> Hooks Class Initialized
DEBUG - 2011-08-17 14:35:27 --> Utf8 Class Initialized
DEBUG - 2011-08-17 14:35:27 --> UTF-8 Support Enabled
DEBUG - 2011-08-17 14:35:27 --> URI Class Initialized
DEBUG - 2011-08-17 14:35:27 --> Router Class Initialized
DEBUG - 2011-08-17 14:35:27 --> Output Class Initialized
DEBUG - 2011-08-17 14:35:27 --> Input Class Initialized
DEBUG - 2011-08-17 14:35:27 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-17 14:35:27 --> Language Class Initialized
DEBUG - 2011-08-17 14:35:27 --> Loader Class Initialized
DEBUG - 2011-08-17 14:35:27 --> Controller Class Initialized
DEBUG - 2011-08-17 14:35:27 --> Model Class Initialized
DEBUG - 2011-08-17 14:35:27 --> Model Class Initialized
DEBUG - 2011-08-17 14:35:27 --> Model Class Initialized
DEBUG - 2011-08-17 14:35:27 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-17 14:35:27 --> Database Driver Class Initialized
DEBUG - 2011-08-17 14:35:27 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-17 14:35:27 --> Helper loaded: url_helper
DEBUG - 2011-08-17 14:35:27 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-17 14:35:27 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-17 14:35:27 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-17 14:35:27 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-17 14:35:27 --> Final output sent to browser
DEBUG - 2011-08-17 14:35:27 --> Total execution time: 0.1720
DEBUG - 2011-08-17 14:35:36 --> Config Class Initialized
DEBUG - 2011-08-17 14:35:36 --> Hooks Class Initialized
DEBUG - 2011-08-17 14:35:36 --> Utf8 Class Initialized
DEBUG - 2011-08-17 14:35:36 --> UTF-8 Support Enabled
DEBUG - 2011-08-17 14:35:36 --> URI Class Initialized
DEBUG - 2011-08-17 14:35:36 --> Router Class Initialized
DEBUG - 2011-08-17 14:35:36 --> Output Class Initialized
DEBUG - 2011-08-17 14:35:36 --> Input Class Initialized
DEBUG - 2011-08-17 14:35:36 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-17 14:35:36 --> Language Class Initialized
DEBUG - 2011-08-17 14:35:36 --> Loader Class Initialized
DEBUG - 2011-08-17 14:35:36 --> Controller Class Initialized
DEBUG - 2011-08-17 14:35:36 --> Model Class Initialized
DEBUG - 2011-08-17 14:35:36 --> Model Class Initialized
DEBUG - 2011-08-17 14:35:36 --> Model Class Initialized
DEBUG - 2011-08-17 14:35:36 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-17 14:35:36 --> Database Driver Class Initialized
DEBUG - 2011-08-17 14:35:36 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-17 14:35:36 --> Helper loaded: url_helper
DEBUG - 2011-08-17 14:35:36 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-17 14:35:36 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-17 14:35:36 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-17 14:35:36 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-17 14:35:36 --> Final output sent to browser
DEBUG - 2011-08-17 14:35:36 --> Total execution time: 0.2051
DEBUG - 2011-08-17 14:35:39 --> Config Class Initialized
DEBUG - 2011-08-17 14:35:39 --> Hooks Class Initialized
DEBUG - 2011-08-17 14:35:39 --> Utf8 Class Initialized
DEBUG - 2011-08-17 14:35:39 --> UTF-8 Support Enabled
DEBUG - 2011-08-17 14:35:39 --> URI Class Initialized
DEBUG - 2011-08-17 14:35:39 --> Router Class Initialized
DEBUG - 2011-08-17 14:35:39 --> Output Class Initialized
DEBUG - 2011-08-17 14:35:39 --> Input Class Initialized
DEBUG - 2011-08-17 14:35:39 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-17 14:35:39 --> Language Class Initialized
DEBUG - 2011-08-17 14:35:39 --> Loader Class Initialized
DEBUG - 2011-08-17 14:35:39 --> Controller Class Initialized
DEBUG - 2011-08-17 14:35:39 --> Model Class Initialized
DEBUG - 2011-08-17 14:35:39 --> Model Class Initialized
DEBUG - 2011-08-17 14:35:39 --> Model Class Initialized
DEBUG - 2011-08-17 14:35:39 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-17 14:35:39 --> Database Driver Class Initialized
DEBUG - 2011-08-17 14:35:39 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-17 14:35:39 --> Helper loaded: url_helper
DEBUG - 2011-08-17 14:35:39 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-17 14:35:39 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-17 14:35:39 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-17 14:35:39 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-17 14:35:39 --> Final output sent to browser
DEBUG - 2011-08-17 14:35:39 --> Total execution time: 0.0444
DEBUG - 2011-08-17 14:35:57 --> Config Class Initialized
DEBUG - 2011-08-17 14:35:57 --> Hooks Class Initialized
DEBUG - 2011-08-17 14:35:57 --> Utf8 Class Initialized
DEBUG - 2011-08-17 14:35:57 --> UTF-8 Support Enabled
DEBUG - 2011-08-17 14:35:57 --> URI Class Initialized
DEBUG - 2011-08-17 14:35:57 --> Router Class Initialized
DEBUG - 2011-08-17 14:35:57 --> Output Class Initialized
DEBUG - 2011-08-17 14:35:57 --> Input Class Initialized
DEBUG - 2011-08-17 14:35:57 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-17 14:35:57 --> Language Class Initialized
DEBUG - 2011-08-17 14:35:57 --> Loader Class Initialized
DEBUG - 2011-08-17 14:35:57 --> Controller Class Initialized
DEBUG - 2011-08-17 14:35:57 --> Model Class Initialized
DEBUG - 2011-08-17 14:35:57 --> Model Class Initialized
DEBUG - 2011-08-17 14:35:57 --> Model Class Initialized
DEBUG - 2011-08-17 14:35:57 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-17 14:35:57 --> Database Driver Class Initialized
DEBUG - 2011-08-17 14:35:57 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-17 14:35:57 --> Helper loaded: url_helper
DEBUG - 2011-08-17 14:35:57 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-17 14:35:57 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-17 14:35:57 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-17 14:35:57 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-17 14:35:57 --> Final output sent to browser
DEBUG - 2011-08-17 14:35:57 --> Total execution time: 0.2682
DEBUG - 2011-08-17 14:36:06 --> Config Class Initialized
DEBUG - 2011-08-17 14:36:06 --> Hooks Class Initialized
DEBUG - 2011-08-17 14:36:06 --> Utf8 Class Initialized
DEBUG - 2011-08-17 14:36:06 --> UTF-8 Support Enabled
DEBUG - 2011-08-17 14:36:06 --> URI Class Initialized
DEBUG - 2011-08-17 14:36:06 --> Router Class Initialized
DEBUG - 2011-08-17 14:36:06 --> Output Class Initialized
DEBUG - 2011-08-17 14:36:06 --> Input Class Initialized
DEBUG - 2011-08-17 14:36:06 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-17 14:36:06 --> Language Class Initialized
DEBUG - 2011-08-17 14:36:06 --> Loader Class Initialized
DEBUG - 2011-08-17 14:36:06 --> Controller Class Initialized
DEBUG - 2011-08-17 14:36:06 --> Model Class Initialized
DEBUG - 2011-08-17 14:36:06 --> Model Class Initialized
DEBUG - 2011-08-17 14:36:06 --> Model Class Initialized
DEBUG - 2011-08-17 14:36:06 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-17 14:36:06 --> Database Driver Class Initialized
DEBUG - 2011-08-17 14:36:06 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-17 14:36:06 --> Helper loaded: url_helper
DEBUG - 2011-08-17 14:36:06 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-17 14:36:06 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-17 14:36:06 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-17 14:36:06 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-17 14:36:06 --> Final output sent to browser
DEBUG - 2011-08-17 14:36:06 --> Total execution time: 0.1622
DEBUG - 2011-08-17 14:56:58 --> Config Class Initialized
DEBUG - 2011-08-17 14:56:58 --> Hooks Class Initialized
DEBUG - 2011-08-17 14:56:58 --> Utf8 Class Initialized
DEBUG - 2011-08-17 14:56:58 --> UTF-8 Support Enabled
DEBUG - 2011-08-17 14:56:58 --> URI Class Initialized
DEBUG - 2011-08-17 14:56:58 --> Router Class Initialized
DEBUG - 2011-08-17 14:56:58 --> No URI present. Default controller set.
DEBUG - 2011-08-17 14:56:58 --> Output Class Initialized
DEBUG - 2011-08-17 14:56:58 --> Input Class Initialized
DEBUG - 2011-08-17 14:56:58 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-17 14:56:58 --> Language Class Initialized
DEBUG - 2011-08-17 14:56:58 --> Loader Class Initialized
DEBUG - 2011-08-17 14:56:58 --> Controller Class Initialized
DEBUG - 2011-08-17 14:56:58 --> File loaded: application/views/splash/main.php
DEBUG - 2011-08-17 14:56:58 --> Helper loaded: url_helper
DEBUG - 2011-08-17 14:56:58 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-17 14:56:58 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-17 14:56:58 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-17 14:56:58 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-17 14:56:58 --> Final output sent to browser
DEBUG - 2011-08-17 14:56:58 --> Total execution time: 0.0661
DEBUG - 2011-08-17 17:39:56 --> Config Class Initialized
DEBUG - 2011-08-17 17:39:56 --> Hooks Class Initialized
DEBUG - 2011-08-17 17:39:56 --> Utf8 Class Initialized
DEBUG - 2011-08-17 17:39:56 --> UTF-8 Support Enabled
DEBUG - 2011-08-17 17:39:56 --> URI Class Initialized
DEBUG - 2011-08-17 17:39:56 --> Router Class Initialized
ERROR - 2011-08-17 17:39:56 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-08-17 17:39:57 --> Config Class Initialized
DEBUG - 2011-08-17 17:39:57 --> Hooks Class Initialized
DEBUG - 2011-08-17 17:39:57 --> Utf8 Class Initialized
DEBUG - 2011-08-17 17:39:57 --> UTF-8 Support Enabled
DEBUG - 2011-08-17 17:39:57 --> URI Class Initialized
DEBUG - 2011-08-17 17:39:57 --> Router Class Initialized
DEBUG - 2011-08-17 17:39:57 --> Output Class Initialized
DEBUG - 2011-08-17 17:39:57 --> Input Class Initialized
DEBUG - 2011-08-17 17:39:57 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-17 17:39:57 --> Language Class Initialized
DEBUG - 2011-08-17 17:39:57 --> Loader Class Initialized
DEBUG - 2011-08-17 17:39:57 --> Controller Class Initialized
DEBUG - 2011-08-17 17:39:57 --> Model Class Initialized
DEBUG - 2011-08-17 17:39:57 --> Model Class Initialized
DEBUG - 2011-08-17 17:39:57 --> Model Class Initialized
DEBUG - 2011-08-17 17:39:57 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-17 17:39:57 --> Database Driver Class Initialized
DEBUG - 2011-08-17 17:39:58 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-17 17:39:58 --> Helper loaded: url_helper
DEBUG - 2011-08-17 17:39:58 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-17 17:39:58 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-17 17:39:58 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-17 17:39:58 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-17 17:39:58 --> Final output sent to browser
DEBUG - 2011-08-17 17:39:58 --> Total execution time: 1.5705
DEBUG - 2011-08-17 18:11:24 --> Config Class Initialized
DEBUG - 2011-08-17 18:11:24 --> Hooks Class Initialized
DEBUG - 2011-08-17 18:11:24 --> Utf8 Class Initialized
DEBUG - 2011-08-17 18:11:24 --> UTF-8 Support Enabled
DEBUG - 2011-08-17 18:11:24 --> URI Class Initialized
DEBUG - 2011-08-17 18:11:24 --> Router Class Initialized
DEBUG - 2011-08-17 18:11:24 --> Output Class Initialized
DEBUG - 2011-08-17 18:11:24 --> Input Class Initialized
DEBUG - 2011-08-17 18:11:24 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-17 18:11:24 --> Language Class Initialized
DEBUG - 2011-08-17 18:11:24 --> Loader Class Initialized
DEBUG - 2011-08-17 18:11:24 --> Controller Class Initialized
ERROR - 2011-08-17 18:11:24 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-17 18:11:24 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-17 18:11:24 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-17 18:11:24 --> Model Class Initialized
DEBUG - 2011-08-17 18:11:24 --> Model Class Initialized
DEBUG - 2011-08-17 18:11:24 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-17 18:11:24 --> Database Driver Class Initialized
DEBUG - 2011-08-17 18:11:24 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-17 18:11:24 --> Helper loaded: url_helper
DEBUG - 2011-08-17 18:11:24 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-17 18:11:24 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-17 18:11:24 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-17 18:11:24 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-17 18:11:24 --> Final output sent to browser
DEBUG - 2011-08-17 18:11:24 --> Total execution time: 0.5320
DEBUG - 2011-08-17 18:11:25 --> Config Class Initialized
DEBUG - 2011-08-17 18:11:25 --> Hooks Class Initialized
DEBUG - 2011-08-17 18:11:25 --> Utf8 Class Initialized
DEBUG - 2011-08-17 18:11:25 --> UTF-8 Support Enabled
DEBUG - 2011-08-17 18:11:25 --> URI Class Initialized
DEBUG - 2011-08-17 18:11:25 --> Router Class Initialized
DEBUG - 2011-08-17 18:11:25 --> Output Class Initialized
DEBUG - 2011-08-17 18:11:25 --> Input Class Initialized
DEBUG - 2011-08-17 18:11:25 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-17 18:11:25 --> Language Class Initialized
DEBUG - 2011-08-17 18:11:25 --> Loader Class Initialized
DEBUG - 2011-08-17 18:11:25 --> Controller Class Initialized
DEBUG - 2011-08-17 18:11:25 --> Model Class Initialized
DEBUG - 2011-08-17 18:11:25 --> Model Class Initialized
DEBUG - 2011-08-17 18:11:25 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-17 18:11:25 --> Database Driver Class Initialized
DEBUG - 2011-08-17 18:11:26 --> Final output sent to browser
DEBUG - 2011-08-17 18:11:26 --> Total execution time: 0.7616
DEBUG - 2011-08-17 18:11:27 --> Config Class Initialized
DEBUG - 2011-08-17 18:11:27 --> Hooks Class Initialized
DEBUG - 2011-08-17 18:11:27 --> Utf8 Class Initialized
DEBUG - 2011-08-17 18:11:27 --> UTF-8 Support Enabled
DEBUG - 2011-08-17 18:11:27 --> URI Class Initialized
DEBUG - 2011-08-17 18:11:27 --> Router Class Initialized
ERROR - 2011-08-17 18:11:27 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-17 19:34:28 --> Config Class Initialized
DEBUG - 2011-08-17 19:34:28 --> Hooks Class Initialized
DEBUG - 2011-08-17 19:34:28 --> Utf8 Class Initialized
DEBUG - 2011-08-17 19:34:28 --> UTF-8 Support Enabled
DEBUG - 2011-08-17 19:34:28 --> URI Class Initialized
DEBUG - 2011-08-17 19:34:28 --> Router Class Initialized
DEBUG - 2011-08-17 19:34:28 --> Output Class Initialized
DEBUG - 2011-08-17 19:34:28 --> Input Class Initialized
DEBUG - 2011-08-17 19:34:28 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-17 19:34:28 --> Language Class Initialized
DEBUG - 2011-08-17 19:34:28 --> Loader Class Initialized
DEBUG - 2011-08-17 19:34:28 --> Controller Class Initialized
ERROR - 2011-08-17 19:34:28 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-17 19:34:28 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-17 19:34:28 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-17 19:34:28 --> Model Class Initialized
DEBUG - 2011-08-17 19:34:28 --> Model Class Initialized
DEBUG - 2011-08-17 19:34:28 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-17 19:34:28 --> Database Driver Class Initialized
DEBUG - 2011-08-17 19:34:28 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-17 19:34:28 --> Helper loaded: url_helper
DEBUG - 2011-08-17 19:34:28 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-17 19:34:28 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-17 19:34:28 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-17 19:34:28 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-17 19:34:28 --> Final output sent to browser
DEBUG - 2011-08-17 19:34:28 --> Total execution time: 0.6641
DEBUG - 2011-08-17 19:34:29 --> Config Class Initialized
DEBUG - 2011-08-17 19:34:29 --> Hooks Class Initialized
DEBUG - 2011-08-17 19:34:29 --> Utf8 Class Initialized
DEBUG - 2011-08-17 19:34:29 --> UTF-8 Support Enabled
DEBUG - 2011-08-17 19:34:29 --> URI Class Initialized
DEBUG - 2011-08-17 19:34:29 --> Router Class Initialized
DEBUG - 2011-08-17 19:34:29 --> Output Class Initialized
DEBUG - 2011-08-17 19:34:29 --> Input Class Initialized
DEBUG - 2011-08-17 19:34:29 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-17 19:34:29 --> Language Class Initialized
DEBUG - 2011-08-17 19:34:29 --> Loader Class Initialized
DEBUG - 2011-08-17 19:34:29 --> Controller Class Initialized
DEBUG - 2011-08-17 19:34:29 --> Model Class Initialized
DEBUG - 2011-08-17 19:34:29 --> Model Class Initialized
DEBUG - 2011-08-17 19:34:29 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-17 19:34:29 --> Database Driver Class Initialized
DEBUG - 2011-08-17 19:34:30 --> Final output sent to browser
DEBUG - 2011-08-17 19:34:30 --> Total execution time: 0.6204
DEBUG - 2011-08-17 19:34:31 --> Config Class Initialized
DEBUG - 2011-08-17 19:34:31 --> Hooks Class Initialized
DEBUG - 2011-08-17 19:34:31 --> Utf8 Class Initialized
DEBUG - 2011-08-17 19:34:31 --> UTF-8 Support Enabled
DEBUG - 2011-08-17 19:34:31 --> URI Class Initialized
DEBUG - 2011-08-17 19:34:31 --> Router Class Initialized
ERROR - 2011-08-17 19:34:31 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-17 19:38:08 --> Config Class Initialized
DEBUG - 2011-08-17 19:38:08 --> Hooks Class Initialized
DEBUG - 2011-08-17 19:38:08 --> Utf8 Class Initialized
DEBUG - 2011-08-17 19:38:08 --> UTF-8 Support Enabled
DEBUG - 2011-08-17 19:38:08 --> URI Class Initialized
DEBUG - 2011-08-17 19:38:08 --> Router Class Initialized
DEBUG - 2011-08-17 19:38:08 --> Output Class Initialized
DEBUG - 2011-08-17 19:38:08 --> Input Class Initialized
DEBUG - 2011-08-17 19:38:08 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-17 19:38:08 --> Language Class Initialized
DEBUG - 2011-08-17 19:38:08 --> Loader Class Initialized
DEBUG - 2011-08-17 19:38:08 --> Controller Class Initialized
ERROR - 2011-08-17 19:38:08 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-17 19:38:08 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-17 19:38:08 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-17 19:38:08 --> Model Class Initialized
DEBUG - 2011-08-17 19:38:08 --> Model Class Initialized
DEBUG - 2011-08-17 19:38:08 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-17 19:38:08 --> Database Driver Class Initialized
DEBUG - 2011-08-17 19:38:08 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-17 19:38:08 --> Helper loaded: url_helper
DEBUG - 2011-08-17 19:38:08 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-17 19:38:08 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-17 19:38:08 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-17 19:38:08 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-17 19:38:08 --> Final output sent to browser
DEBUG - 2011-08-17 19:38:08 --> Total execution time: 0.0619
DEBUG - 2011-08-17 19:38:10 --> Config Class Initialized
DEBUG - 2011-08-17 19:38:10 --> Hooks Class Initialized
DEBUG - 2011-08-17 19:38:10 --> Utf8 Class Initialized
DEBUG - 2011-08-17 19:38:10 --> UTF-8 Support Enabled
DEBUG - 2011-08-17 19:38:10 --> URI Class Initialized
DEBUG - 2011-08-17 19:38:10 --> Router Class Initialized
DEBUG - 2011-08-17 19:38:10 --> Output Class Initialized
DEBUG - 2011-08-17 19:38:10 --> Input Class Initialized
DEBUG - 2011-08-17 19:38:10 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-17 19:38:10 --> Language Class Initialized
DEBUG - 2011-08-17 19:38:10 --> Loader Class Initialized
DEBUG - 2011-08-17 19:38:10 --> Controller Class Initialized
DEBUG - 2011-08-17 19:38:10 --> Model Class Initialized
DEBUG - 2011-08-17 19:38:10 --> Model Class Initialized
DEBUG - 2011-08-17 19:38:10 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-17 19:38:10 --> Database Driver Class Initialized
DEBUG - 2011-08-17 19:38:11 --> Final output sent to browser
DEBUG - 2011-08-17 19:38:11 --> Total execution time: 0.5742
DEBUG - 2011-08-17 19:38:19 --> Config Class Initialized
DEBUG - 2011-08-17 19:38:19 --> Hooks Class Initialized
DEBUG - 2011-08-17 19:38:19 --> Utf8 Class Initialized
DEBUG - 2011-08-17 19:38:19 --> UTF-8 Support Enabled
DEBUG - 2011-08-17 19:38:19 --> URI Class Initialized
DEBUG - 2011-08-17 19:38:19 --> Router Class Initialized
ERROR - 2011-08-17 19:38:19 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-17 19:38:19 --> Config Class Initialized
DEBUG - 2011-08-17 19:38:19 --> Hooks Class Initialized
DEBUG - 2011-08-17 19:38:19 --> Utf8 Class Initialized
DEBUG - 2011-08-17 19:38:19 --> UTF-8 Support Enabled
DEBUG - 2011-08-17 19:38:19 --> URI Class Initialized
DEBUG - 2011-08-17 19:38:19 --> Router Class Initialized
ERROR - 2011-08-17 19:38:19 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-17 19:38:20 --> Config Class Initialized
DEBUG - 2011-08-17 19:38:20 --> Hooks Class Initialized
DEBUG - 2011-08-17 19:38:20 --> Utf8 Class Initialized
DEBUG - 2011-08-17 19:38:20 --> UTF-8 Support Enabled
DEBUG - 2011-08-17 19:38:20 --> URI Class Initialized
DEBUG - 2011-08-17 19:38:20 --> Router Class Initialized
ERROR - 2011-08-17 19:38:20 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-17 19:39:04 --> Config Class Initialized
DEBUG - 2011-08-17 19:39:04 --> Hooks Class Initialized
DEBUG - 2011-08-17 19:39:04 --> Utf8 Class Initialized
DEBUG - 2011-08-17 19:39:04 --> UTF-8 Support Enabled
DEBUG - 2011-08-17 19:39:04 --> URI Class Initialized
DEBUG - 2011-08-17 19:39:04 --> Router Class Initialized
DEBUG - 2011-08-17 19:39:04 --> Output Class Initialized
DEBUG - 2011-08-17 19:39:04 --> Input Class Initialized
DEBUG - 2011-08-17 19:39:04 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-17 19:39:04 --> Language Class Initialized
DEBUG - 2011-08-17 19:39:04 --> Loader Class Initialized
DEBUG - 2011-08-17 19:39:04 --> Controller Class Initialized
DEBUG - 2011-08-17 19:39:04 --> Model Class Initialized
DEBUG - 2011-08-17 19:39:04 --> Model Class Initialized
DEBUG - 2011-08-17 19:39:04 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-17 19:39:04 --> Database Driver Class Initialized
DEBUG - 2011-08-17 19:39:04 --> Final output sent to browser
DEBUG - 2011-08-17 19:39:04 --> Total execution time: 0.5714
DEBUG - 2011-08-17 19:39:18 --> Config Class Initialized
DEBUG - 2011-08-17 19:39:18 --> Hooks Class Initialized
DEBUG - 2011-08-17 19:39:18 --> Utf8 Class Initialized
DEBUG - 2011-08-17 19:39:18 --> UTF-8 Support Enabled
DEBUG - 2011-08-17 19:39:18 --> URI Class Initialized
DEBUG - 2011-08-17 19:39:18 --> Router Class Initialized
DEBUG - 2011-08-17 19:39:18 --> Output Class Initialized
DEBUG - 2011-08-17 19:39:18 --> Input Class Initialized
DEBUG - 2011-08-17 19:39:18 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-17 19:39:18 --> Language Class Initialized
DEBUG - 2011-08-17 19:39:18 --> Loader Class Initialized
DEBUG - 2011-08-17 19:39:18 --> Controller Class Initialized
ERROR - 2011-08-17 19:39:18 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-17 19:39:18 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-17 19:39:18 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-17 19:39:18 --> Model Class Initialized
DEBUG - 2011-08-17 19:39:18 --> Model Class Initialized
DEBUG - 2011-08-17 19:39:18 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-17 19:39:18 --> Database Driver Class Initialized
DEBUG - 2011-08-17 19:39:18 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-17 19:39:18 --> Helper loaded: url_helper
DEBUG - 2011-08-17 19:39:18 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-17 19:39:18 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-17 19:39:18 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-17 19:39:18 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-17 19:39:18 --> Final output sent to browser
DEBUG - 2011-08-17 19:39:18 --> Total execution time: 0.0466
DEBUG - 2011-08-17 19:39:23 --> Config Class Initialized
DEBUG - 2011-08-17 19:39:23 --> Hooks Class Initialized
DEBUG - 2011-08-17 19:39:23 --> Utf8 Class Initialized
DEBUG - 2011-08-17 19:39:23 --> UTF-8 Support Enabled
DEBUG - 2011-08-17 19:39:23 --> URI Class Initialized
DEBUG - 2011-08-17 19:39:23 --> Router Class Initialized
DEBUG - 2011-08-17 19:39:23 --> Output Class Initialized
DEBUG - 2011-08-17 19:39:23 --> Input Class Initialized
DEBUG - 2011-08-17 19:39:23 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-17 19:39:23 --> Language Class Initialized
DEBUG - 2011-08-17 19:39:23 --> Loader Class Initialized
DEBUG - 2011-08-17 19:39:23 --> Controller Class Initialized
DEBUG - 2011-08-17 19:39:23 --> Model Class Initialized
DEBUG - 2011-08-17 19:39:23 --> Model Class Initialized
DEBUG - 2011-08-17 19:39:23 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-17 19:39:23 --> Database Driver Class Initialized
DEBUG - 2011-08-17 19:39:24 --> Final output sent to browser
DEBUG - 2011-08-17 19:39:24 --> Total execution time: 0.5254
DEBUG - 2011-08-17 19:44:16 --> Config Class Initialized
DEBUG - 2011-08-17 19:44:16 --> Hooks Class Initialized
DEBUG - 2011-08-17 19:44:16 --> Utf8 Class Initialized
DEBUG - 2011-08-17 19:44:16 --> UTF-8 Support Enabled
DEBUG - 2011-08-17 19:44:16 --> URI Class Initialized
DEBUG - 2011-08-17 19:44:16 --> Router Class Initialized
DEBUG - 2011-08-17 19:44:16 --> Output Class Initialized
DEBUG - 2011-08-17 19:44:16 --> Input Class Initialized
DEBUG - 2011-08-17 19:44:16 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-17 19:44:16 --> Language Class Initialized
DEBUG - 2011-08-17 19:44:16 --> Loader Class Initialized
DEBUG - 2011-08-17 19:44:16 --> Controller Class Initialized
DEBUG - 2011-08-17 19:44:16 --> Model Class Initialized
DEBUG - 2011-08-17 19:44:16 --> Model Class Initialized
DEBUG - 2011-08-17 19:44:16 --> Model Class Initialized
DEBUG - 2011-08-17 19:44:16 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-17 19:44:16 --> Database Driver Class Initialized
DEBUG - 2011-08-17 19:44:17 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-17 19:44:17 --> Helper loaded: url_helper
DEBUG - 2011-08-17 19:44:17 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-17 19:44:17 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-17 19:44:17 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-17 19:44:17 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-17 19:44:17 --> Final output sent to browser
DEBUG - 2011-08-17 19:44:17 --> Total execution time: 0.7229
DEBUG - 2011-08-17 19:44:34 --> Config Class Initialized
DEBUG - 2011-08-17 19:44:34 --> Hooks Class Initialized
DEBUG - 2011-08-17 19:44:34 --> Utf8 Class Initialized
DEBUG - 2011-08-17 19:44:34 --> UTF-8 Support Enabled
DEBUG - 2011-08-17 19:44:34 --> URI Class Initialized
DEBUG - 2011-08-17 19:44:34 --> Router Class Initialized
ERROR - 2011-08-17 19:44:34 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-17 19:44:35 --> Config Class Initialized
DEBUG - 2011-08-17 19:44:35 --> Hooks Class Initialized
DEBUG - 2011-08-17 19:44:35 --> Utf8 Class Initialized
DEBUG - 2011-08-17 19:44:35 --> UTF-8 Support Enabled
DEBUG - 2011-08-17 19:44:35 --> URI Class Initialized
DEBUG - 2011-08-17 19:44:35 --> Router Class Initialized
ERROR - 2011-08-17 19:44:35 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-17 19:45:27 --> Config Class Initialized
DEBUG - 2011-08-17 19:45:27 --> Hooks Class Initialized
DEBUG - 2011-08-17 19:45:27 --> Utf8 Class Initialized
DEBUG - 2011-08-17 19:45:27 --> UTF-8 Support Enabled
DEBUG - 2011-08-17 19:45:27 --> URI Class Initialized
DEBUG - 2011-08-17 19:45:27 --> Router Class Initialized
DEBUG - 2011-08-17 19:45:27 --> Output Class Initialized
DEBUG - 2011-08-17 19:45:27 --> Input Class Initialized
DEBUG - 2011-08-17 19:45:27 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-17 19:45:27 --> Language Class Initialized
DEBUG - 2011-08-17 19:45:27 --> Loader Class Initialized
DEBUG - 2011-08-17 19:45:27 --> Controller Class Initialized
DEBUG - 2011-08-17 19:45:27 --> Model Class Initialized
DEBUG - 2011-08-17 19:45:27 --> Model Class Initialized
DEBUG - 2011-08-17 19:45:27 --> Model Class Initialized
DEBUG - 2011-08-17 19:45:27 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-17 19:45:27 --> Database Driver Class Initialized
DEBUG - 2011-08-17 19:45:27 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-17 19:45:27 --> Helper loaded: url_helper
DEBUG - 2011-08-17 19:45:27 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-17 19:45:27 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-17 19:45:27 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-17 19:45:27 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-17 19:45:27 --> Final output sent to browser
DEBUG - 2011-08-17 19:45:27 --> Total execution time: 0.5215
DEBUG - 2011-08-17 19:45:31 --> Config Class Initialized
DEBUG - 2011-08-17 19:45:31 --> Hooks Class Initialized
DEBUG - 2011-08-17 19:45:31 --> Utf8 Class Initialized
DEBUG - 2011-08-17 19:45:31 --> UTF-8 Support Enabled
DEBUG - 2011-08-17 19:45:31 --> URI Class Initialized
DEBUG - 2011-08-17 19:45:31 --> Router Class Initialized
ERROR - 2011-08-17 19:45:31 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-17 19:45:53 --> Config Class Initialized
DEBUG - 2011-08-17 19:45:53 --> Hooks Class Initialized
DEBUG - 2011-08-17 19:45:53 --> Utf8 Class Initialized
DEBUG - 2011-08-17 19:45:53 --> UTF-8 Support Enabled
DEBUG - 2011-08-17 19:45:53 --> URI Class Initialized
DEBUG - 2011-08-17 19:45:53 --> Router Class Initialized
DEBUG - 2011-08-17 19:45:53 --> Output Class Initialized
DEBUG - 2011-08-17 19:45:53 --> Input Class Initialized
DEBUG - 2011-08-17 19:45:53 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-17 19:45:53 --> Language Class Initialized
DEBUG - 2011-08-17 19:45:53 --> Loader Class Initialized
DEBUG - 2011-08-17 19:45:53 --> Controller Class Initialized
DEBUG - 2011-08-17 19:45:53 --> Model Class Initialized
DEBUG - 2011-08-17 19:45:53 --> Model Class Initialized
DEBUG - 2011-08-17 19:45:53 --> Model Class Initialized
DEBUG - 2011-08-17 19:45:53 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-17 19:45:53 --> Database Driver Class Initialized
DEBUG - 2011-08-17 19:45:54 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-17 19:45:54 --> Helper loaded: url_helper
DEBUG - 2011-08-17 19:45:54 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-17 19:45:54 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-17 19:45:54 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-17 19:45:54 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-17 19:45:54 --> Final output sent to browser
DEBUG - 2011-08-17 19:45:54 --> Total execution time: 1.0356
DEBUG - 2011-08-17 19:45:59 --> Config Class Initialized
DEBUG - 2011-08-17 19:45:59 --> Hooks Class Initialized
DEBUG - 2011-08-17 19:45:59 --> Utf8 Class Initialized
DEBUG - 2011-08-17 19:45:59 --> UTF-8 Support Enabled
DEBUG - 2011-08-17 19:45:59 --> URI Class Initialized
DEBUG - 2011-08-17 19:45:59 --> Router Class Initialized
ERROR - 2011-08-17 19:45:59 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-17 19:46:22 --> Config Class Initialized
DEBUG - 2011-08-17 19:46:22 --> Hooks Class Initialized
DEBUG - 2011-08-17 19:46:22 --> Utf8 Class Initialized
DEBUG - 2011-08-17 19:46:22 --> UTF-8 Support Enabled
DEBUG - 2011-08-17 19:46:22 --> URI Class Initialized
DEBUG - 2011-08-17 19:46:22 --> Router Class Initialized
DEBUG - 2011-08-17 19:46:22 --> Output Class Initialized
DEBUG - 2011-08-17 19:46:22 --> Input Class Initialized
DEBUG - 2011-08-17 19:46:22 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-17 19:46:22 --> Language Class Initialized
DEBUG - 2011-08-17 19:46:22 --> Loader Class Initialized
DEBUG - 2011-08-17 19:46:22 --> Controller Class Initialized
DEBUG - 2011-08-17 19:46:22 --> Model Class Initialized
DEBUG - 2011-08-17 19:46:22 --> Model Class Initialized
DEBUG - 2011-08-17 19:46:22 --> Model Class Initialized
DEBUG - 2011-08-17 19:46:22 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-17 19:46:22 --> Database Driver Class Initialized
DEBUG - 2011-08-17 19:46:26 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-17 19:46:26 --> Helper loaded: url_helper
DEBUG - 2011-08-17 19:46:26 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-17 19:46:26 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-17 19:46:26 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-17 19:46:26 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-17 19:46:26 --> Final output sent to browser
DEBUG - 2011-08-17 19:46:26 --> Total execution time: 3.5013
DEBUG - 2011-08-17 19:46:29 --> Config Class Initialized
DEBUG - 2011-08-17 19:46:29 --> Hooks Class Initialized
DEBUG - 2011-08-17 19:46:29 --> Utf8 Class Initialized
DEBUG - 2011-08-17 19:46:29 --> UTF-8 Support Enabled
DEBUG - 2011-08-17 19:46:29 --> URI Class Initialized
DEBUG - 2011-08-17 19:46:29 --> Router Class Initialized
ERROR - 2011-08-17 19:46:29 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-17 19:46:55 --> Config Class Initialized
DEBUG - 2011-08-17 19:46:55 --> Hooks Class Initialized
DEBUG - 2011-08-17 19:46:55 --> Utf8 Class Initialized
DEBUG - 2011-08-17 19:46:55 --> UTF-8 Support Enabled
DEBUG - 2011-08-17 19:46:55 --> URI Class Initialized
DEBUG - 2011-08-17 19:46:55 --> Router Class Initialized
DEBUG - 2011-08-17 19:46:55 --> Output Class Initialized
DEBUG - 2011-08-17 19:46:55 --> Input Class Initialized
DEBUG - 2011-08-17 19:46:55 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-17 19:46:55 --> Language Class Initialized
DEBUG - 2011-08-17 19:46:55 --> Loader Class Initialized
DEBUG - 2011-08-17 19:46:55 --> Controller Class Initialized
DEBUG - 2011-08-17 19:46:55 --> Model Class Initialized
DEBUG - 2011-08-17 19:46:55 --> Model Class Initialized
DEBUG - 2011-08-17 19:46:55 --> Model Class Initialized
DEBUG - 2011-08-17 19:46:55 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-17 19:46:55 --> Database Driver Class Initialized
DEBUG - 2011-08-17 19:46:55 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-17 19:46:55 --> Helper loaded: url_helper
DEBUG - 2011-08-17 19:46:55 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-17 19:46:55 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-17 19:46:55 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-17 19:46:55 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-17 19:46:55 --> Final output sent to browser
DEBUG - 2011-08-17 19:46:55 --> Total execution time: 0.5619
DEBUG - 2011-08-17 19:46:59 --> Config Class Initialized
DEBUG - 2011-08-17 19:46:59 --> Hooks Class Initialized
DEBUG - 2011-08-17 19:46:59 --> Utf8 Class Initialized
DEBUG - 2011-08-17 19:46:59 --> UTF-8 Support Enabled
DEBUG - 2011-08-17 19:46:59 --> URI Class Initialized
DEBUG - 2011-08-17 19:46:59 --> Router Class Initialized
ERROR - 2011-08-17 19:46:59 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-17 19:47:17 --> Config Class Initialized
DEBUG - 2011-08-17 19:47:17 --> Hooks Class Initialized
DEBUG - 2011-08-17 19:47:17 --> Utf8 Class Initialized
DEBUG - 2011-08-17 19:47:17 --> UTF-8 Support Enabled
DEBUG - 2011-08-17 19:47:17 --> URI Class Initialized
DEBUG - 2011-08-17 19:47:17 --> Router Class Initialized
DEBUG - 2011-08-17 19:47:17 --> Output Class Initialized
DEBUG - 2011-08-17 19:47:17 --> Input Class Initialized
DEBUG - 2011-08-17 19:47:17 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-17 19:47:17 --> Language Class Initialized
DEBUG - 2011-08-17 19:47:17 --> Loader Class Initialized
DEBUG - 2011-08-17 19:47:17 --> Controller Class Initialized
DEBUG - 2011-08-17 19:47:17 --> Model Class Initialized
DEBUG - 2011-08-17 19:47:17 --> Model Class Initialized
DEBUG - 2011-08-17 19:47:17 --> Model Class Initialized
DEBUG - 2011-08-17 19:47:17 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-17 19:47:17 --> Database Driver Class Initialized
DEBUG - 2011-08-17 19:47:17 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-17 19:47:17 --> Helper loaded: url_helper
DEBUG - 2011-08-17 19:47:17 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-17 19:47:17 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-17 19:47:17 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-17 19:47:17 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-17 19:47:17 --> Final output sent to browser
DEBUG - 2011-08-17 19:47:17 --> Total execution time: 0.5911
DEBUG - 2011-08-17 19:47:25 --> Config Class Initialized
DEBUG - 2011-08-17 19:47:25 --> Hooks Class Initialized
DEBUG - 2011-08-17 19:47:25 --> Utf8 Class Initialized
DEBUG - 2011-08-17 19:47:25 --> UTF-8 Support Enabled
DEBUG - 2011-08-17 19:47:25 --> URI Class Initialized
DEBUG - 2011-08-17 19:47:25 --> Router Class Initialized
ERROR - 2011-08-17 19:47:25 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-17 19:48:02 --> Config Class Initialized
DEBUG - 2011-08-17 19:48:02 --> Hooks Class Initialized
DEBUG - 2011-08-17 19:48:02 --> Utf8 Class Initialized
DEBUG - 2011-08-17 19:48:02 --> UTF-8 Support Enabled
DEBUG - 2011-08-17 19:48:02 --> URI Class Initialized
DEBUG - 2011-08-17 19:48:02 --> Router Class Initialized
DEBUG - 2011-08-17 19:48:02 --> Output Class Initialized
DEBUG - 2011-08-17 19:48:02 --> Input Class Initialized
DEBUG - 2011-08-17 19:48:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-17 19:48:02 --> Language Class Initialized
DEBUG - 2011-08-17 19:48:02 --> Loader Class Initialized
DEBUG - 2011-08-17 19:48:02 --> Controller Class Initialized
DEBUG - 2011-08-17 19:48:02 --> Model Class Initialized
DEBUG - 2011-08-17 19:48:02 --> Model Class Initialized
DEBUG - 2011-08-17 19:48:02 --> Model Class Initialized
DEBUG - 2011-08-17 19:48:02 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-17 19:48:02 --> Database Driver Class Initialized
DEBUG - 2011-08-17 19:48:03 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-17 19:48:03 --> Helper loaded: url_helper
DEBUG - 2011-08-17 19:48:03 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-17 19:48:03 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-17 19:48:03 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-17 19:48:03 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-17 19:48:03 --> Final output sent to browser
DEBUG - 2011-08-17 19:48:03 --> Total execution time: 0.5824
DEBUG - 2011-08-17 19:48:08 --> Config Class Initialized
DEBUG - 2011-08-17 19:48:08 --> Hooks Class Initialized
DEBUG - 2011-08-17 19:48:08 --> Utf8 Class Initialized
DEBUG - 2011-08-17 19:48:08 --> UTF-8 Support Enabled
DEBUG - 2011-08-17 19:48:08 --> URI Class Initialized
DEBUG - 2011-08-17 19:48:08 --> Router Class Initialized
ERROR - 2011-08-17 19:48:08 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-17 19:48:21 --> Config Class Initialized
DEBUG - 2011-08-17 19:48:21 --> Hooks Class Initialized
DEBUG - 2011-08-17 19:48:21 --> Utf8 Class Initialized
DEBUG - 2011-08-17 19:48:21 --> UTF-8 Support Enabled
DEBUG - 2011-08-17 19:48:21 --> URI Class Initialized
DEBUG - 2011-08-17 19:48:21 --> Router Class Initialized
DEBUG - 2011-08-17 19:48:21 --> Output Class Initialized
DEBUG - 2011-08-17 19:48:21 --> Input Class Initialized
DEBUG - 2011-08-17 19:48:21 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-17 19:48:21 --> Language Class Initialized
DEBUG - 2011-08-17 19:48:21 --> Loader Class Initialized
DEBUG - 2011-08-17 19:48:21 --> Controller Class Initialized
DEBUG - 2011-08-17 19:48:21 --> Model Class Initialized
DEBUG - 2011-08-17 19:48:21 --> Model Class Initialized
DEBUG - 2011-08-17 19:48:21 --> Model Class Initialized
DEBUG - 2011-08-17 19:48:21 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-17 19:48:21 --> Database Driver Class Initialized
DEBUG - 2011-08-17 19:48:22 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-17 19:48:22 --> Helper loaded: url_helper
DEBUG - 2011-08-17 19:48:22 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-17 19:48:22 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-17 19:48:22 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-17 19:48:22 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-17 19:48:22 --> Final output sent to browser
DEBUG - 2011-08-17 19:48:22 --> Total execution time: 0.9286
DEBUG - 2011-08-17 19:48:26 --> Config Class Initialized
DEBUG - 2011-08-17 19:48:26 --> Hooks Class Initialized
DEBUG - 2011-08-17 19:48:26 --> Utf8 Class Initialized
DEBUG - 2011-08-17 19:48:26 --> UTF-8 Support Enabled
DEBUG - 2011-08-17 19:48:26 --> URI Class Initialized
DEBUG - 2011-08-17 19:48:26 --> Router Class Initialized
ERROR - 2011-08-17 19:48:26 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-17 19:48:38 --> Config Class Initialized
DEBUG - 2011-08-17 19:48:38 --> Hooks Class Initialized
DEBUG - 2011-08-17 19:48:38 --> Utf8 Class Initialized
DEBUG - 2011-08-17 19:48:38 --> UTF-8 Support Enabled
DEBUG - 2011-08-17 19:48:38 --> URI Class Initialized
DEBUG - 2011-08-17 19:48:38 --> Router Class Initialized
DEBUG - 2011-08-17 19:48:38 --> Output Class Initialized
DEBUG - 2011-08-17 19:48:38 --> Input Class Initialized
DEBUG - 2011-08-17 19:48:38 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-17 19:48:38 --> Language Class Initialized
DEBUG - 2011-08-17 19:48:38 --> Loader Class Initialized
DEBUG - 2011-08-17 19:48:38 --> Controller Class Initialized
DEBUG - 2011-08-17 19:48:38 --> Model Class Initialized
DEBUG - 2011-08-17 19:48:38 --> Model Class Initialized
DEBUG - 2011-08-17 19:48:38 --> Model Class Initialized
DEBUG - 2011-08-17 19:48:38 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-17 19:48:38 --> Database Driver Class Initialized
DEBUG - 2011-08-17 19:48:38 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-17 19:48:38 --> Helper loaded: url_helper
DEBUG - 2011-08-17 19:48:38 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-17 19:48:38 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-17 19:48:38 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-17 19:48:38 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-17 19:48:38 --> Final output sent to browser
DEBUG - 2011-08-17 19:48:38 --> Total execution time: 0.2005
DEBUG - 2011-08-17 19:48:41 --> Config Class Initialized
DEBUG - 2011-08-17 19:48:41 --> Hooks Class Initialized
DEBUG - 2011-08-17 19:48:41 --> Utf8 Class Initialized
DEBUG - 2011-08-17 19:48:41 --> UTF-8 Support Enabled
DEBUG - 2011-08-17 19:48:41 --> URI Class Initialized
DEBUG - 2011-08-17 19:48:41 --> Router Class Initialized
ERROR - 2011-08-17 19:48:41 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-17 19:49:15 --> Config Class Initialized
DEBUG - 2011-08-17 19:49:15 --> Hooks Class Initialized
DEBUG - 2011-08-17 19:49:15 --> Utf8 Class Initialized
DEBUG - 2011-08-17 19:49:15 --> UTF-8 Support Enabled
DEBUG - 2011-08-17 19:49:15 --> URI Class Initialized
DEBUG - 2011-08-17 19:49:15 --> Router Class Initialized
DEBUG - 2011-08-17 19:49:15 --> Output Class Initialized
DEBUG - 2011-08-17 19:49:15 --> Input Class Initialized
DEBUG - 2011-08-17 19:49:15 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-17 19:49:15 --> Language Class Initialized
DEBUG - 2011-08-17 19:49:15 --> Loader Class Initialized
DEBUG - 2011-08-17 19:49:15 --> Controller Class Initialized
DEBUG - 2011-08-17 19:49:15 --> Model Class Initialized
DEBUG - 2011-08-17 19:49:15 --> Model Class Initialized
DEBUG - 2011-08-17 19:49:15 --> Model Class Initialized
DEBUG - 2011-08-17 19:49:15 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-17 19:49:15 --> Database Driver Class Initialized
DEBUG - 2011-08-17 19:49:16 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-17 19:49:16 --> Helper loaded: url_helper
DEBUG - 2011-08-17 19:49:16 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-17 19:49:16 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-17 19:49:16 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-17 19:49:16 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-17 19:49:16 --> Final output sent to browser
DEBUG - 2011-08-17 19:49:16 --> Total execution time: 0.1347
DEBUG - 2011-08-17 19:49:21 --> Config Class Initialized
DEBUG - 2011-08-17 19:49:21 --> Hooks Class Initialized
DEBUG - 2011-08-17 19:49:21 --> Utf8 Class Initialized
DEBUG - 2011-08-17 19:49:21 --> UTF-8 Support Enabled
DEBUG - 2011-08-17 19:49:21 --> URI Class Initialized
DEBUG - 2011-08-17 19:49:21 --> Router Class Initialized
ERROR - 2011-08-17 19:49:21 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-17 19:49:29 --> Config Class Initialized
DEBUG - 2011-08-17 19:49:29 --> Hooks Class Initialized
DEBUG - 2011-08-17 19:49:29 --> Utf8 Class Initialized
DEBUG - 2011-08-17 19:49:29 --> UTF-8 Support Enabled
DEBUG - 2011-08-17 19:49:29 --> URI Class Initialized
DEBUG - 2011-08-17 19:49:29 --> Router Class Initialized
DEBUG - 2011-08-17 19:49:29 --> Output Class Initialized
DEBUG - 2011-08-17 19:49:29 --> Input Class Initialized
DEBUG - 2011-08-17 19:49:29 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-17 19:49:29 --> Language Class Initialized
DEBUG - 2011-08-17 19:49:29 --> Loader Class Initialized
DEBUG - 2011-08-17 19:49:29 --> Controller Class Initialized
DEBUG - 2011-08-17 19:49:29 --> Model Class Initialized
DEBUG - 2011-08-17 19:49:29 --> Model Class Initialized
DEBUG - 2011-08-17 19:49:29 --> Model Class Initialized
DEBUG - 2011-08-17 19:49:29 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-17 19:49:29 --> Database Driver Class Initialized
DEBUG - 2011-08-17 19:49:29 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-17 19:49:29 --> Helper loaded: url_helper
DEBUG - 2011-08-17 19:49:29 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-17 19:49:29 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-17 19:49:29 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-17 19:49:29 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-17 19:49:29 --> Final output sent to browser
DEBUG - 2011-08-17 19:49:29 --> Total execution time: 0.0959
DEBUG - 2011-08-17 19:49:32 --> Config Class Initialized
DEBUG - 2011-08-17 19:49:32 --> Hooks Class Initialized
DEBUG - 2011-08-17 19:49:32 --> Utf8 Class Initialized
DEBUG - 2011-08-17 19:49:32 --> UTF-8 Support Enabled
DEBUG - 2011-08-17 19:49:32 --> URI Class Initialized
DEBUG - 2011-08-17 19:49:32 --> Router Class Initialized
ERROR - 2011-08-17 19:49:32 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-17 19:49:47 --> Config Class Initialized
DEBUG - 2011-08-17 19:49:47 --> Hooks Class Initialized
DEBUG - 2011-08-17 19:49:47 --> Utf8 Class Initialized
DEBUG - 2011-08-17 19:49:47 --> UTF-8 Support Enabled
DEBUG - 2011-08-17 19:49:47 --> URI Class Initialized
DEBUG - 2011-08-17 19:49:47 --> Router Class Initialized
DEBUG - 2011-08-17 19:49:47 --> Output Class Initialized
DEBUG - 2011-08-17 19:49:47 --> Input Class Initialized
DEBUG - 2011-08-17 19:49:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-17 19:49:47 --> Language Class Initialized
DEBUG - 2011-08-17 19:49:47 --> Loader Class Initialized
DEBUG - 2011-08-17 19:49:47 --> Controller Class Initialized
DEBUG - 2011-08-17 19:49:47 --> Model Class Initialized
DEBUG - 2011-08-17 19:49:47 --> Model Class Initialized
DEBUG - 2011-08-17 19:49:47 --> Model Class Initialized
DEBUG - 2011-08-17 19:49:47 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-17 19:49:47 --> Database Driver Class Initialized
DEBUG - 2011-08-17 19:49:48 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-17 19:49:48 --> Helper loaded: url_helper
DEBUG - 2011-08-17 19:49:48 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-17 19:49:48 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-17 19:49:48 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-17 19:49:48 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-17 19:49:48 --> Final output sent to browser
DEBUG - 2011-08-17 19:49:48 --> Total execution time: 0.2644
DEBUG - 2011-08-17 19:49:50 --> Config Class Initialized
DEBUG - 2011-08-17 19:49:50 --> Hooks Class Initialized
DEBUG - 2011-08-17 19:49:50 --> Utf8 Class Initialized
DEBUG - 2011-08-17 19:49:50 --> UTF-8 Support Enabled
DEBUG - 2011-08-17 19:49:50 --> URI Class Initialized
DEBUG - 2011-08-17 19:49:50 --> Router Class Initialized
ERROR - 2011-08-17 19:49:50 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-17 19:50:11 --> Config Class Initialized
DEBUG - 2011-08-17 19:50:11 --> Hooks Class Initialized
DEBUG - 2011-08-17 19:50:11 --> Utf8 Class Initialized
DEBUG - 2011-08-17 19:50:11 --> UTF-8 Support Enabled
DEBUG - 2011-08-17 19:50:11 --> URI Class Initialized
DEBUG - 2011-08-17 19:50:11 --> Router Class Initialized
DEBUG - 2011-08-17 19:50:11 --> Output Class Initialized
DEBUG - 2011-08-17 19:50:11 --> Input Class Initialized
DEBUG - 2011-08-17 19:50:11 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-17 19:50:11 --> Language Class Initialized
DEBUG - 2011-08-17 19:50:11 --> Loader Class Initialized
DEBUG - 2011-08-17 19:50:11 --> Controller Class Initialized
DEBUG - 2011-08-17 19:50:11 --> Model Class Initialized
DEBUG - 2011-08-17 19:50:11 --> Model Class Initialized
DEBUG - 2011-08-17 19:50:11 --> Model Class Initialized
DEBUG - 2011-08-17 19:50:11 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-17 19:50:11 --> Database Driver Class Initialized
DEBUG - 2011-08-17 19:50:11 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-17 19:50:11 --> Helper loaded: url_helper
DEBUG - 2011-08-17 19:50:11 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-17 19:50:11 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-17 19:50:11 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-17 19:50:11 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-17 19:50:11 --> Final output sent to browser
DEBUG - 2011-08-17 19:50:11 --> Total execution time: 0.5598
DEBUG - 2011-08-17 19:50:15 --> Config Class Initialized
DEBUG - 2011-08-17 19:50:15 --> Hooks Class Initialized
DEBUG - 2011-08-17 19:50:15 --> Utf8 Class Initialized
DEBUG - 2011-08-17 19:50:15 --> UTF-8 Support Enabled
DEBUG - 2011-08-17 19:50:15 --> URI Class Initialized
DEBUG - 2011-08-17 19:50:15 --> Router Class Initialized
ERROR - 2011-08-17 19:50:15 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-17 19:50:34 --> Config Class Initialized
DEBUG - 2011-08-17 19:50:34 --> Hooks Class Initialized
DEBUG - 2011-08-17 19:50:34 --> Utf8 Class Initialized
DEBUG - 2011-08-17 19:50:34 --> UTF-8 Support Enabled
DEBUG - 2011-08-17 19:50:34 --> URI Class Initialized
DEBUG - 2011-08-17 19:50:34 --> Router Class Initialized
DEBUG - 2011-08-17 19:50:34 --> Output Class Initialized
DEBUG - 2011-08-17 19:50:34 --> Input Class Initialized
DEBUG - 2011-08-17 19:50:34 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-17 19:50:34 --> Language Class Initialized
DEBUG - 2011-08-17 19:50:34 --> Loader Class Initialized
DEBUG - 2011-08-17 19:50:34 --> Controller Class Initialized
DEBUG - 2011-08-17 19:50:34 --> Model Class Initialized
DEBUG - 2011-08-17 19:50:34 --> Model Class Initialized
DEBUG - 2011-08-17 19:50:34 --> Model Class Initialized
DEBUG - 2011-08-17 19:50:34 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-17 19:50:34 --> Database Driver Class Initialized
DEBUG - 2011-08-17 19:50:34 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-17 19:50:34 --> Helper loaded: url_helper
DEBUG - 2011-08-17 19:50:34 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-17 19:50:34 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-17 19:50:34 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-17 19:50:34 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-17 19:50:34 --> Final output sent to browser
DEBUG - 2011-08-17 19:50:34 --> Total execution time: 0.1181
DEBUG - 2011-08-17 19:50:37 --> Config Class Initialized
DEBUG - 2011-08-17 19:50:37 --> Hooks Class Initialized
DEBUG - 2011-08-17 19:50:37 --> Utf8 Class Initialized
DEBUG - 2011-08-17 19:50:37 --> UTF-8 Support Enabled
DEBUG - 2011-08-17 19:50:37 --> URI Class Initialized
DEBUG - 2011-08-17 19:50:37 --> Router Class Initialized
ERROR - 2011-08-17 19:50:37 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-17 19:50:51 --> Config Class Initialized
DEBUG - 2011-08-17 19:50:51 --> Hooks Class Initialized
DEBUG - 2011-08-17 19:50:51 --> Utf8 Class Initialized
DEBUG - 2011-08-17 19:50:51 --> UTF-8 Support Enabled
DEBUG - 2011-08-17 19:50:51 --> URI Class Initialized
DEBUG - 2011-08-17 19:50:51 --> Router Class Initialized
DEBUG - 2011-08-17 19:50:51 --> Output Class Initialized
DEBUG - 2011-08-17 19:50:51 --> Input Class Initialized
DEBUG - 2011-08-17 19:50:51 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-17 19:50:51 --> Language Class Initialized
DEBUG - 2011-08-17 19:50:51 --> Loader Class Initialized
DEBUG - 2011-08-17 19:50:51 --> Controller Class Initialized
DEBUG - 2011-08-17 19:50:51 --> Model Class Initialized
DEBUG - 2011-08-17 19:50:51 --> Model Class Initialized
DEBUG - 2011-08-17 19:50:51 --> Model Class Initialized
DEBUG - 2011-08-17 19:50:51 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-17 19:50:51 --> Database Driver Class Initialized
DEBUG - 2011-08-17 19:50:51 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-17 19:50:51 --> Helper loaded: url_helper
DEBUG - 2011-08-17 19:50:51 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-17 19:50:51 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-17 19:50:51 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-17 19:50:51 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-17 19:50:51 --> Final output sent to browser
DEBUG - 2011-08-17 19:50:51 --> Total execution time: 0.3709
DEBUG - 2011-08-17 19:50:56 --> Config Class Initialized
DEBUG - 2011-08-17 19:50:56 --> Hooks Class Initialized
DEBUG - 2011-08-17 19:50:56 --> Utf8 Class Initialized
DEBUG - 2011-08-17 19:50:56 --> UTF-8 Support Enabled
DEBUG - 2011-08-17 19:50:56 --> URI Class Initialized
DEBUG - 2011-08-17 19:50:56 --> Router Class Initialized
ERROR - 2011-08-17 19:50:56 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-17 19:51:07 --> Config Class Initialized
DEBUG - 2011-08-17 19:51:07 --> Hooks Class Initialized
DEBUG - 2011-08-17 19:51:07 --> Utf8 Class Initialized
DEBUG - 2011-08-17 19:51:07 --> UTF-8 Support Enabled
DEBUG - 2011-08-17 19:51:07 --> URI Class Initialized
DEBUG - 2011-08-17 19:51:07 --> Router Class Initialized
DEBUG - 2011-08-17 19:51:07 --> Output Class Initialized
DEBUG - 2011-08-17 19:51:07 --> Input Class Initialized
DEBUG - 2011-08-17 19:51:07 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-17 19:51:07 --> Language Class Initialized
DEBUG - 2011-08-17 19:51:07 --> Loader Class Initialized
DEBUG - 2011-08-17 19:51:07 --> Controller Class Initialized
DEBUG - 2011-08-17 19:51:07 --> Model Class Initialized
DEBUG - 2011-08-17 19:51:07 --> Model Class Initialized
DEBUG - 2011-08-17 19:51:07 --> Model Class Initialized
DEBUG - 2011-08-17 19:51:07 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-17 19:51:07 --> Database Driver Class Initialized
DEBUG - 2011-08-17 19:51:08 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-17 19:51:08 --> Helper loaded: url_helper
DEBUG - 2011-08-17 19:51:08 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-17 19:51:08 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-17 19:51:08 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-17 19:51:08 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-17 19:51:08 --> Final output sent to browser
DEBUG - 2011-08-17 19:51:08 --> Total execution time: 0.2031
DEBUG - 2011-08-17 19:51:16 --> Config Class Initialized
DEBUG - 2011-08-17 19:51:16 --> Hooks Class Initialized
DEBUG - 2011-08-17 19:51:16 --> Utf8 Class Initialized
DEBUG - 2011-08-17 19:51:16 --> UTF-8 Support Enabled
DEBUG - 2011-08-17 19:51:16 --> URI Class Initialized
DEBUG - 2011-08-17 19:51:16 --> Router Class Initialized
ERROR - 2011-08-17 19:51:16 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-17 19:51:22 --> Config Class Initialized
DEBUG - 2011-08-17 19:51:22 --> Hooks Class Initialized
DEBUG - 2011-08-17 19:51:22 --> Utf8 Class Initialized
DEBUG - 2011-08-17 19:51:22 --> UTF-8 Support Enabled
DEBUG - 2011-08-17 19:51:22 --> URI Class Initialized
DEBUG - 2011-08-17 19:51:22 --> Router Class Initialized
DEBUG - 2011-08-17 19:51:22 --> Output Class Initialized
DEBUG - 2011-08-17 19:51:22 --> Input Class Initialized
DEBUG - 2011-08-17 19:51:22 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-17 19:51:22 --> Language Class Initialized
DEBUG - 2011-08-17 19:51:22 --> Loader Class Initialized
DEBUG - 2011-08-17 19:51:22 --> Controller Class Initialized
DEBUG - 2011-08-17 19:51:22 --> Model Class Initialized
DEBUG - 2011-08-17 19:51:22 --> Model Class Initialized
DEBUG - 2011-08-17 19:51:22 --> Model Class Initialized
DEBUG - 2011-08-17 19:51:22 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-17 19:51:22 --> Database Driver Class Initialized
DEBUG - 2011-08-17 19:51:23 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-17 19:51:23 --> Helper loaded: url_helper
DEBUG - 2011-08-17 19:51:23 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-17 19:51:23 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-17 19:51:23 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-17 19:51:23 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-17 19:51:23 --> Final output sent to browser
DEBUG - 2011-08-17 19:51:23 --> Total execution time: 0.3463
DEBUG - 2011-08-17 19:51:26 --> Config Class Initialized
DEBUG - 2011-08-17 19:51:26 --> Hooks Class Initialized
DEBUG - 2011-08-17 19:51:26 --> Utf8 Class Initialized
DEBUG - 2011-08-17 19:51:26 --> UTF-8 Support Enabled
DEBUG - 2011-08-17 19:51:26 --> URI Class Initialized
DEBUG - 2011-08-17 19:51:26 --> Router Class Initialized
ERROR - 2011-08-17 19:51:26 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-17 20:46:50 --> Config Class Initialized
DEBUG - 2011-08-17 20:46:50 --> Hooks Class Initialized
DEBUG - 2011-08-17 20:46:50 --> Utf8 Class Initialized
DEBUG - 2011-08-17 20:46:50 --> UTF-8 Support Enabled
DEBUG - 2011-08-17 20:46:50 --> URI Class Initialized
DEBUG - 2011-08-17 20:46:50 --> Router Class Initialized
DEBUG - 2011-08-17 20:46:50 --> Output Class Initialized
DEBUG - 2011-08-17 20:46:50 --> Input Class Initialized
DEBUG - 2011-08-17 20:46:50 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-17 20:46:50 --> Language Class Initialized
DEBUG - 2011-08-17 20:46:50 --> Loader Class Initialized
DEBUG - 2011-08-17 20:46:50 --> Controller Class Initialized
ERROR - 2011-08-17 20:46:50 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-17 20:46:50 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-17 20:46:50 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-17 20:46:50 --> Model Class Initialized
DEBUG - 2011-08-17 20:46:50 --> Model Class Initialized
DEBUG - 2011-08-17 20:46:50 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-17 20:46:50 --> Database Driver Class Initialized
DEBUG - 2011-08-17 20:46:50 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-17 20:46:50 --> Helper loaded: url_helper
DEBUG - 2011-08-17 20:46:50 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-17 20:46:50 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-17 20:46:50 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-17 20:46:50 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-17 20:46:50 --> Final output sent to browser
DEBUG - 2011-08-17 20:46:50 --> Total execution time: 0.3183
DEBUG - 2011-08-17 20:46:52 --> Config Class Initialized
DEBUG - 2011-08-17 20:46:52 --> Hooks Class Initialized
DEBUG - 2011-08-17 20:46:52 --> Utf8 Class Initialized
DEBUG - 2011-08-17 20:46:52 --> UTF-8 Support Enabled
DEBUG - 2011-08-17 20:46:52 --> URI Class Initialized
DEBUG - 2011-08-17 20:46:52 --> Router Class Initialized
DEBUG - 2011-08-17 20:46:52 --> Output Class Initialized
DEBUG - 2011-08-17 20:46:52 --> Input Class Initialized
DEBUG - 2011-08-17 20:46:52 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-17 20:46:52 --> Language Class Initialized
DEBUG - 2011-08-17 20:46:52 --> Loader Class Initialized
DEBUG - 2011-08-17 20:46:52 --> Controller Class Initialized
DEBUG - 2011-08-17 20:46:52 --> Model Class Initialized
DEBUG - 2011-08-17 20:46:52 --> Model Class Initialized
DEBUG - 2011-08-17 20:46:52 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-17 20:46:52 --> Database Driver Class Initialized
DEBUG - 2011-08-17 20:46:52 --> Final output sent to browser
DEBUG - 2011-08-17 20:46:52 --> Total execution time: 0.6653
DEBUG - 2011-08-17 20:46:58 --> Config Class Initialized
DEBUG - 2011-08-17 20:46:58 --> Hooks Class Initialized
DEBUG - 2011-08-17 20:46:58 --> Utf8 Class Initialized
DEBUG - 2011-08-17 20:46:58 --> UTF-8 Support Enabled
DEBUG - 2011-08-17 20:46:58 --> URI Class Initialized
DEBUG - 2011-08-17 20:46:58 --> Router Class Initialized
ERROR - 2011-08-17 20:46:58 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-17 20:46:58 --> Config Class Initialized
DEBUG - 2011-08-17 20:46:58 --> Hooks Class Initialized
DEBUG - 2011-08-17 20:46:58 --> Utf8 Class Initialized
DEBUG - 2011-08-17 20:46:58 --> UTF-8 Support Enabled
DEBUG - 2011-08-17 20:46:58 --> URI Class Initialized
DEBUG - 2011-08-17 20:46:58 --> Router Class Initialized
ERROR - 2011-08-17 20:46:58 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-17 21:03:07 --> Config Class Initialized
DEBUG - 2011-08-17 21:03:07 --> Hooks Class Initialized
DEBUG - 2011-08-17 21:03:07 --> Utf8 Class Initialized
DEBUG - 2011-08-17 21:03:07 --> UTF-8 Support Enabled
DEBUG - 2011-08-17 21:03:07 --> URI Class Initialized
DEBUG - 2011-08-17 21:03:07 --> Router Class Initialized
DEBUG - 2011-08-17 21:03:07 --> Output Class Initialized
DEBUG - 2011-08-17 21:03:07 --> Input Class Initialized
DEBUG - 2011-08-17 21:03:07 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-17 21:03:07 --> Language Class Initialized
DEBUG - 2011-08-17 21:03:07 --> Loader Class Initialized
DEBUG - 2011-08-17 21:03:07 --> Controller Class Initialized
ERROR - 2011-08-17 21:03:07 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-17 21:03:07 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-17 21:03:07 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-17 21:03:07 --> Model Class Initialized
DEBUG - 2011-08-17 21:03:07 --> Model Class Initialized
DEBUG - 2011-08-17 21:03:07 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-17 21:03:07 --> Database Driver Class Initialized
DEBUG - 2011-08-17 21:03:07 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-17 21:03:08 --> Helper loaded: url_helper
DEBUG - 2011-08-17 21:03:08 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-17 21:03:08 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-17 21:03:08 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-17 21:03:08 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-17 21:03:08 --> Final output sent to browser
DEBUG - 2011-08-17 21:03:08 --> Total execution time: 0.0543
DEBUG - 2011-08-17 21:03:08 --> Config Class Initialized
DEBUG - 2011-08-17 21:03:08 --> Hooks Class Initialized
DEBUG - 2011-08-17 21:03:08 --> Utf8 Class Initialized
DEBUG - 2011-08-17 21:03:08 --> UTF-8 Support Enabled
DEBUG - 2011-08-17 21:03:08 --> URI Class Initialized
DEBUG - 2011-08-17 21:03:08 --> Router Class Initialized
DEBUG - 2011-08-17 21:03:08 --> Output Class Initialized
DEBUG - 2011-08-17 21:03:08 --> Input Class Initialized
DEBUG - 2011-08-17 21:03:08 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-17 21:03:08 --> Language Class Initialized
DEBUG - 2011-08-17 21:03:08 --> Loader Class Initialized
DEBUG - 2011-08-17 21:03:08 --> Controller Class Initialized
DEBUG - 2011-08-17 21:03:08 --> Model Class Initialized
DEBUG - 2011-08-17 21:03:08 --> Model Class Initialized
DEBUG - 2011-08-17 21:03:08 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-17 21:03:08 --> Database Driver Class Initialized
DEBUG - 2011-08-17 21:03:09 --> Final output sent to browser
DEBUG - 2011-08-17 21:03:09 --> Total execution time: 0.6801
DEBUG - 2011-08-17 21:03:10 --> Config Class Initialized
DEBUG - 2011-08-17 21:03:10 --> Hooks Class Initialized
DEBUG - 2011-08-17 21:03:10 --> Utf8 Class Initialized
DEBUG - 2011-08-17 21:03:10 --> UTF-8 Support Enabled
DEBUG - 2011-08-17 21:03:10 --> URI Class Initialized
DEBUG - 2011-08-17 21:03:10 --> Router Class Initialized
ERROR - 2011-08-17 21:03:10 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-17 22:06:45 --> Config Class Initialized
DEBUG - 2011-08-17 22:06:45 --> Hooks Class Initialized
DEBUG - 2011-08-17 22:06:45 --> Utf8 Class Initialized
DEBUG - 2011-08-17 22:06:45 --> UTF-8 Support Enabled
DEBUG - 2011-08-17 22:06:45 --> URI Class Initialized
DEBUG - 2011-08-17 22:06:45 --> Router Class Initialized
DEBUG - 2011-08-17 22:06:45 --> No URI present. Default controller set.
DEBUG - 2011-08-17 22:06:45 --> Output Class Initialized
DEBUG - 2011-08-17 22:06:45 --> Input Class Initialized
DEBUG - 2011-08-17 22:06:45 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-17 22:06:45 --> Language Class Initialized
DEBUG - 2011-08-17 22:06:45 --> Loader Class Initialized
DEBUG - 2011-08-17 22:06:45 --> Controller Class Initialized
DEBUG - 2011-08-17 22:06:45 --> File loaded: application/views/splash/main.php
DEBUG - 2011-08-17 22:06:45 --> Helper loaded: url_helper
DEBUG - 2011-08-17 22:06:45 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-17 22:06:45 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-17 22:06:45 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-17 22:06:45 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-17 22:06:45 --> Final output sent to browser
DEBUG - 2011-08-17 22:06:45 --> Total execution time: 0.2840
DEBUG - 2011-08-17 22:09:03 --> Config Class Initialized
DEBUG - 2011-08-17 22:09:03 --> Hooks Class Initialized
DEBUG - 2011-08-17 22:09:03 --> Utf8 Class Initialized
DEBUG - 2011-08-17 22:09:03 --> UTF-8 Support Enabled
DEBUG - 2011-08-17 22:09:03 --> URI Class Initialized
DEBUG - 2011-08-17 22:09:03 --> Router Class Initialized
DEBUG - 2011-08-17 22:09:03 --> Output Class Initialized
DEBUG - 2011-08-17 22:09:03 --> Input Class Initialized
DEBUG - 2011-08-17 22:09:03 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-17 22:09:03 --> Language Class Initialized
DEBUG - 2011-08-17 22:09:03 --> Loader Class Initialized
DEBUG - 2011-08-17 22:09:03 --> Controller Class Initialized
ERROR - 2011-08-17 22:09:03 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-17 22:09:03 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-17 22:09:03 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-17 22:09:03 --> Model Class Initialized
DEBUG - 2011-08-17 22:09:03 --> Model Class Initialized
DEBUG - 2011-08-17 22:09:03 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-17 22:09:03 --> Database Driver Class Initialized
DEBUG - 2011-08-17 22:09:03 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-17 22:09:03 --> Helper loaded: url_helper
DEBUG - 2011-08-17 22:09:03 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-17 22:09:03 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-17 22:09:03 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-17 22:09:03 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-17 22:09:03 --> Final output sent to browser
DEBUG - 2011-08-17 22:09:03 --> Total execution time: 0.2207
DEBUG - 2011-08-17 22:09:03 --> Config Class Initialized
DEBUG - 2011-08-17 22:09:03 --> Hooks Class Initialized
DEBUG - 2011-08-17 22:09:03 --> Utf8 Class Initialized
DEBUG - 2011-08-17 22:09:03 --> UTF-8 Support Enabled
DEBUG - 2011-08-17 22:09:03 --> URI Class Initialized
DEBUG - 2011-08-17 22:09:03 --> Router Class Initialized
DEBUG - 2011-08-17 22:09:03 --> Output Class Initialized
DEBUG - 2011-08-17 22:09:03 --> Input Class Initialized
DEBUG - 2011-08-17 22:09:03 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-17 22:09:03 --> Language Class Initialized
DEBUG - 2011-08-17 22:09:03 --> Loader Class Initialized
DEBUG - 2011-08-17 22:09:03 --> Controller Class Initialized
DEBUG - 2011-08-17 22:09:03 --> Model Class Initialized
DEBUG - 2011-08-17 22:09:03 --> Model Class Initialized
DEBUG - 2011-08-17 22:09:03 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-17 22:09:03 --> Database Driver Class Initialized
DEBUG - 2011-08-17 22:09:04 --> Final output sent to browser
DEBUG - 2011-08-17 22:09:04 --> Total execution time: 0.5872
DEBUG - 2011-08-17 22:09:06 --> Config Class Initialized
DEBUG - 2011-08-17 22:09:06 --> Hooks Class Initialized
DEBUG - 2011-08-17 22:09:06 --> Utf8 Class Initialized
DEBUG - 2011-08-17 22:09:06 --> UTF-8 Support Enabled
DEBUG - 2011-08-17 22:09:06 --> URI Class Initialized
DEBUG - 2011-08-17 22:09:06 --> Router Class Initialized
ERROR - 2011-08-17 22:09:06 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-17 22:09:06 --> Config Class Initialized
DEBUG - 2011-08-17 22:09:06 --> Hooks Class Initialized
DEBUG - 2011-08-17 22:09:06 --> Utf8 Class Initialized
DEBUG - 2011-08-17 22:09:06 --> UTF-8 Support Enabled
DEBUG - 2011-08-17 22:09:06 --> URI Class Initialized
DEBUG - 2011-08-17 22:09:06 --> Router Class Initialized
ERROR - 2011-08-17 22:09:06 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-17 22:09:07 --> Config Class Initialized
DEBUG - 2011-08-17 22:09:07 --> Hooks Class Initialized
DEBUG - 2011-08-17 22:09:07 --> Utf8 Class Initialized
DEBUG - 2011-08-17 22:09:07 --> UTF-8 Support Enabled
DEBUG - 2011-08-17 22:09:07 --> URI Class Initialized
DEBUG - 2011-08-17 22:09:07 --> Router Class Initialized
ERROR - 2011-08-17 22:09:07 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-17 22:15:14 --> Config Class Initialized
DEBUG - 2011-08-17 22:15:14 --> Hooks Class Initialized
DEBUG - 2011-08-17 22:15:14 --> Utf8 Class Initialized
DEBUG - 2011-08-17 22:15:14 --> UTF-8 Support Enabled
DEBUG - 2011-08-17 22:15:14 --> URI Class Initialized
DEBUG - 2011-08-17 22:15:14 --> Router Class Initialized
DEBUG - 2011-08-17 22:15:14 --> Output Class Initialized
DEBUG - 2011-08-17 22:15:14 --> Input Class Initialized
DEBUG - 2011-08-17 22:15:14 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-17 22:15:14 --> Language Class Initialized
DEBUG - 2011-08-17 22:15:14 --> Loader Class Initialized
DEBUG - 2011-08-17 22:15:14 --> Controller Class Initialized
DEBUG - 2011-08-17 22:15:14 --> Model Class Initialized
DEBUG - 2011-08-17 22:15:14 --> Model Class Initialized
DEBUG - 2011-08-17 22:15:14 --> Model Class Initialized
DEBUG - 2011-08-17 22:15:14 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-17 22:15:14 --> Database Driver Class Initialized
DEBUG - 2011-08-17 22:15:14 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-17 22:15:14 --> Helper loaded: url_helper
DEBUG - 2011-08-17 22:15:14 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-17 22:15:14 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-17 22:15:14 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-17 22:15:14 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-17 22:15:14 --> Final output sent to browser
DEBUG - 2011-08-17 22:15:14 --> Total execution time: 0.3474
DEBUG - 2011-08-17 22:16:30 --> Config Class Initialized
DEBUG - 2011-08-17 22:16:30 --> Hooks Class Initialized
DEBUG - 2011-08-17 22:16:30 --> Utf8 Class Initialized
DEBUG - 2011-08-17 22:16:30 --> UTF-8 Support Enabled
DEBUG - 2011-08-17 22:16:30 --> URI Class Initialized
DEBUG - 2011-08-17 22:16:30 --> Router Class Initialized
DEBUG - 2011-08-17 22:16:30 --> No URI present. Default controller set.
DEBUG - 2011-08-17 22:16:30 --> Output Class Initialized
DEBUG - 2011-08-17 22:16:30 --> Input Class Initialized
DEBUG - 2011-08-17 22:16:30 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-17 22:16:30 --> Language Class Initialized
DEBUG - 2011-08-17 22:16:30 --> Loader Class Initialized
DEBUG - 2011-08-17 22:16:30 --> Controller Class Initialized
DEBUG - 2011-08-17 22:16:30 --> File loaded: application/views/splash/main.php
DEBUG - 2011-08-17 22:16:30 --> Helper loaded: url_helper
DEBUG - 2011-08-17 22:16:30 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-17 22:16:30 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-17 22:16:30 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-17 22:16:30 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-17 22:16:30 --> Final output sent to browser
DEBUG - 2011-08-17 22:16:30 --> Total execution time: 0.0772
DEBUG - 2011-08-17 22:55:47 --> Config Class Initialized
DEBUG - 2011-08-17 22:55:47 --> Hooks Class Initialized
DEBUG - 2011-08-17 22:55:47 --> Utf8 Class Initialized
DEBUG - 2011-08-17 22:55:47 --> UTF-8 Support Enabled
DEBUG - 2011-08-17 22:55:47 --> URI Class Initialized
DEBUG - 2011-08-17 22:55:47 --> Router Class Initialized
ERROR - 2011-08-17 22:55:47 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-08-17 22:55:47 --> Config Class Initialized
DEBUG - 2011-08-17 22:55:47 --> Hooks Class Initialized
DEBUG - 2011-08-17 22:55:47 --> Utf8 Class Initialized
DEBUG - 2011-08-17 22:55:47 --> UTF-8 Support Enabled
DEBUG - 2011-08-17 22:55:47 --> URI Class Initialized
DEBUG - 2011-08-17 22:55:47 --> Router Class Initialized
DEBUG - 2011-08-17 22:55:48 --> Output Class Initialized
DEBUG - 2011-08-17 22:55:48 --> Input Class Initialized
DEBUG - 2011-08-17 22:55:48 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-17 22:55:48 --> Language Class Initialized
DEBUG - 2011-08-17 22:55:48 --> Loader Class Initialized
DEBUG - 2011-08-17 22:55:48 --> Controller Class Initialized
ERROR - 2011-08-17 22:55:48 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-17 22:55:48 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-17 22:55:48 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-17 22:55:48 --> Model Class Initialized
DEBUG - 2011-08-17 22:55:48 --> Model Class Initialized
DEBUG - 2011-08-17 22:55:48 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-17 22:55:48 --> Database Driver Class Initialized
DEBUG - 2011-08-17 22:55:48 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-17 22:55:48 --> Helper loaded: url_helper
DEBUG - 2011-08-17 22:55:48 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-17 22:55:48 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-17 22:55:48 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-17 22:55:48 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-17 22:55:48 --> Final output sent to browser
DEBUG - 2011-08-17 22:55:48 --> Total execution time: 0.2738
DEBUG - 2011-08-17 23:05:30 --> Config Class Initialized
DEBUG - 2011-08-17 23:05:30 --> Hooks Class Initialized
DEBUG - 2011-08-17 23:05:30 --> Utf8 Class Initialized
DEBUG - 2011-08-17 23:05:30 --> UTF-8 Support Enabled
DEBUG - 2011-08-17 23:05:30 --> URI Class Initialized
DEBUG - 2011-08-17 23:05:30 --> Router Class Initialized
DEBUG - 2011-08-17 23:05:30 --> Output Class Initialized
DEBUG - 2011-08-17 23:05:30 --> Input Class Initialized
DEBUG - 2011-08-17 23:05:30 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-17 23:05:30 --> Language Class Initialized
DEBUG - 2011-08-17 23:05:30 --> Loader Class Initialized
DEBUG - 2011-08-17 23:05:30 --> Controller Class Initialized
DEBUG - 2011-08-17 23:05:30 --> Model Class Initialized
DEBUG - 2011-08-17 23:05:30 --> Model Class Initialized
DEBUG - 2011-08-17 23:05:30 --> Model Class Initialized
DEBUG - 2011-08-17 23:05:30 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-17 23:05:30 --> Database Driver Class Initialized
DEBUG - 2011-08-17 23:05:30 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-17 23:05:30 --> Helper loaded: url_helper
DEBUG - 2011-08-17 23:05:30 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-17 23:05:30 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-17 23:05:30 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-17 23:05:30 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-17 23:05:30 --> Final output sent to browser
DEBUG - 2011-08-17 23:05:30 --> Total execution time: 0.3684
DEBUG - 2011-08-17 23:05:32 --> Config Class Initialized
DEBUG - 2011-08-17 23:05:32 --> Hooks Class Initialized
DEBUG - 2011-08-17 23:05:32 --> Utf8 Class Initialized
DEBUG - 2011-08-17 23:05:32 --> UTF-8 Support Enabled
DEBUG - 2011-08-17 23:05:32 --> URI Class Initialized
DEBUG - 2011-08-17 23:05:32 --> Router Class Initialized
DEBUG - 2011-08-17 23:05:32 --> Output Class Initialized
DEBUG - 2011-08-17 23:05:32 --> Input Class Initialized
DEBUG - 2011-08-17 23:05:32 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-17 23:05:32 --> Language Class Initialized
DEBUG - 2011-08-17 23:05:32 --> Loader Class Initialized
DEBUG - 2011-08-17 23:05:32 --> Controller Class Initialized
ERROR - 2011-08-17 23:05:32 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-17 23:05:32 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-17 23:05:32 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-17 23:05:32 --> Model Class Initialized
DEBUG - 2011-08-17 23:05:32 --> Model Class Initialized
DEBUG - 2011-08-17 23:05:32 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-17 23:05:32 --> Database Driver Class Initialized
DEBUG - 2011-08-17 23:05:32 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-17 23:05:32 --> Helper loaded: url_helper
DEBUG - 2011-08-17 23:05:32 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-17 23:05:32 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-17 23:05:32 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-17 23:05:32 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-17 23:05:32 --> Final output sent to browser
DEBUG - 2011-08-17 23:05:32 --> Total execution time: 0.0275

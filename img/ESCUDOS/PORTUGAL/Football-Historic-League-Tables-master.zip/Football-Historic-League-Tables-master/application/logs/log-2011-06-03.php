<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2011-06-03 00:34:09 --> Config Class Initialized
DEBUG - 2011-06-03 00:34:09 --> Hooks Class Initialized
DEBUG - 2011-06-03 00:34:09 --> Utf8 Class Initialized
DEBUG - 2011-06-03 00:34:09 --> UTF-8 Support Enabled
DEBUG - 2011-06-03 00:34:09 --> URI Class Initialized
DEBUG - 2011-06-03 00:34:09 --> Router Class Initialized
DEBUG - 2011-06-03 00:34:09 --> Output Class Initialized
DEBUG - 2011-06-03 00:34:09 --> Input Class Initialized
DEBUG - 2011-06-03 00:34:09 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-03 00:34:09 --> Language Class Initialized
DEBUG - 2011-06-03 00:34:09 --> Loader Class Initialized
DEBUG - 2011-06-03 00:34:09 --> Controller Class Initialized
ERROR - 2011-06-03 00:34:09 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-03 00:34:09 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-03 00:34:09 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-03 00:34:09 --> Model Class Initialized
DEBUG - 2011-06-03 00:34:09 --> Model Class Initialized
DEBUG - 2011-06-03 00:34:09 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-03 00:34:09 --> Database Driver Class Initialized
DEBUG - 2011-06-03 00:34:09 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-03 00:34:09 --> Helper loaded: url_helper
DEBUG - 2011-06-03 00:34:09 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-03 00:34:09 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-03 00:34:09 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-03 00:34:09 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-03 00:34:09 --> Final output sent to browser
DEBUG - 2011-06-03 00:34:09 --> Total execution time: 0.2990
DEBUG - 2011-06-03 01:13:05 --> Config Class Initialized
DEBUG - 2011-06-03 01:13:05 --> Hooks Class Initialized
DEBUG - 2011-06-03 01:13:05 --> Utf8 Class Initialized
DEBUG - 2011-06-03 01:13:05 --> UTF-8 Support Enabled
DEBUG - 2011-06-03 01:13:05 --> URI Class Initialized
DEBUG - 2011-06-03 01:13:05 --> Router Class Initialized
ERROR - 2011-06-03 01:13:05 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-06-03 01:13:06 --> Config Class Initialized
DEBUG - 2011-06-03 01:13:06 --> Hooks Class Initialized
DEBUG - 2011-06-03 01:13:06 --> Utf8 Class Initialized
DEBUG - 2011-06-03 01:13:06 --> UTF-8 Support Enabled
DEBUG - 2011-06-03 01:13:06 --> URI Class Initialized
DEBUG - 2011-06-03 01:13:06 --> Router Class Initialized
DEBUG - 2011-06-03 01:13:06 --> Output Class Initialized
DEBUG - 2011-06-03 01:13:06 --> Input Class Initialized
DEBUG - 2011-06-03 01:13:06 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-03 01:13:06 --> Language Class Initialized
DEBUG - 2011-06-03 01:13:06 --> Loader Class Initialized
DEBUG - 2011-06-03 01:13:06 --> Controller Class Initialized
DEBUG - 2011-06-03 01:13:06 --> Model Class Initialized
DEBUG - 2011-06-03 01:13:06 --> Model Class Initialized
DEBUG - 2011-06-03 01:13:06 --> Model Class Initialized
DEBUG - 2011-06-03 01:13:06 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-03 01:13:06 --> Database Driver Class Initialized
DEBUG - 2011-06-03 01:13:07 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-03 01:13:07 --> Helper loaded: url_helper
DEBUG - 2011-06-03 01:13:07 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-03 01:13:07 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-03 01:13:07 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-03 01:13:07 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-03 01:13:07 --> Final output sent to browser
DEBUG - 2011-06-03 01:13:07 --> Total execution time: 0.9470
DEBUG - 2011-06-03 01:13:37 --> Config Class Initialized
DEBUG - 2011-06-03 01:13:37 --> Hooks Class Initialized
DEBUG - 2011-06-03 01:13:37 --> Utf8 Class Initialized
DEBUG - 2011-06-03 01:13:37 --> UTF-8 Support Enabled
DEBUG - 2011-06-03 01:13:37 --> URI Class Initialized
DEBUG - 2011-06-03 01:13:37 --> Router Class Initialized
DEBUG - 2011-06-03 01:13:37 --> Output Class Initialized
DEBUG - 2011-06-03 01:13:37 --> Input Class Initialized
DEBUG - 2011-06-03 01:13:37 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-03 01:13:37 --> Language Class Initialized
DEBUG - 2011-06-03 01:13:37 --> Loader Class Initialized
DEBUG - 2011-06-03 01:13:37 --> Controller Class Initialized
ERROR - 2011-06-03 01:13:38 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-03 01:13:38 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-03 01:13:38 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-03 01:13:38 --> Model Class Initialized
DEBUG - 2011-06-03 01:13:38 --> Model Class Initialized
DEBUG - 2011-06-03 01:13:38 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-03 01:13:38 --> Database Driver Class Initialized
DEBUG - 2011-06-03 01:13:38 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-03 01:13:38 --> Helper loaded: url_helper
DEBUG - 2011-06-03 01:13:38 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-03 01:13:38 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-03 01:13:38 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-03 01:13:38 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-03 01:13:38 --> Final output sent to browser
DEBUG - 2011-06-03 01:13:38 --> Total execution time: 0.7257
DEBUG - 2011-06-03 01:54:59 --> Config Class Initialized
DEBUG - 2011-06-03 01:54:59 --> Hooks Class Initialized
DEBUG - 2011-06-03 01:54:59 --> Utf8 Class Initialized
DEBUG - 2011-06-03 01:54:59 --> UTF-8 Support Enabled
DEBUG - 2011-06-03 01:54:59 --> URI Class Initialized
DEBUG - 2011-06-03 01:54:59 --> Router Class Initialized
DEBUG - 2011-06-03 01:54:59 --> Output Class Initialized
DEBUG - 2011-06-03 01:54:59 --> Input Class Initialized
DEBUG - 2011-06-03 01:54:59 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-03 01:54:59 --> Language Class Initialized
DEBUG - 2011-06-03 01:54:59 --> Loader Class Initialized
DEBUG - 2011-06-03 01:54:59 --> Controller Class Initialized
DEBUG - 2011-06-03 01:54:59 --> Model Class Initialized
DEBUG - 2011-06-03 01:54:59 --> Model Class Initialized
DEBUG - 2011-06-03 01:54:59 --> Model Class Initialized
DEBUG - 2011-06-03 01:54:59 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-03 01:54:59 --> Database Driver Class Initialized
DEBUG - 2011-06-03 01:55:01 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-03 01:55:02 --> Helper loaded: url_helper
DEBUG - 2011-06-03 01:55:02 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-03 01:55:02 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-03 01:55:02 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-03 01:55:02 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-03 01:55:02 --> Final output sent to browser
DEBUG - 2011-06-03 01:55:02 --> Total execution time: 2.2883
DEBUG - 2011-06-03 02:21:23 --> Config Class Initialized
DEBUG - 2011-06-03 02:21:23 --> Hooks Class Initialized
DEBUG - 2011-06-03 02:21:23 --> Utf8 Class Initialized
DEBUG - 2011-06-03 02:21:23 --> UTF-8 Support Enabled
DEBUG - 2011-06-03 02:21:23 --> URI Class Initialized
DEBUG - 2011-06-03 02:21:23 --> Router Class Initialized
DEBUG - 2011-06-03 02:21:23 --> Output Class Initialized
DEBUG - 2011-06-03 02:21:23 --> Input Class Initialized
DEBUG - 2011-06-03 02:21:23 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-03 02:21:23 --> Language Class Initialized
DEBUG - 2011-06-03 02:21:23 --> Loader Class Initialized
DEBUG - 2011-06-03 02:21:23 --> Controller Class Initialized
ERROR - 2011-06-03 02:21:23 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-03 02:21:23 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-03 02:21:23 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-03 02:21:23 --> Model Class Initialized
DEBUG - 2011-06-03 02:21:23 --> Model Class Initialized
DEBUG - 2011-06-03 02:21:23 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-03 02:21:23 --> Database Driver Class Initialized
DEBUG - 2011-06-03 02:21:23 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-03 02:21:24 --> Helper loaded: url_helper
DEBUG - 2011-06-03 02:21:24 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-03 02:21:24 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-03 02:21:24 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-03 02:21:24 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-03 02:21:24 --> Final output sent to browser
DEBUG - 2011-06-03 02:21:24 --> Total execution time: 0.6254
DEBUG - 2011-06-03 02:31:55 --> Config Class Initialized
DEBUG - 2011-06-03 02:31:55 --> Hooks Class Initialized
DEBUG - 2011-06-03 02:31:55 --> Utf8 Class Initialized
DEBUG - 2011-06-03 02:31:55 --> UTF-8 Support Enabled
DEBUG - 2011-06-03 02:31:55 --> URI Class Initialized
DEBUG - 2011-06-03 02:31:55 --> Router Class Initialized
DEBUG - 2011-06-03 02:31:55 --> Output Class Initialized
DEBUG - 2011-06-03 02:31:55 --> Input Class Initialized
DEBUG - 2011-06-03 02:31:55 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-03 02:31:55 --> Language Class Initialized
DEBUG - 2011-06-03 02:31:55 --> Loader Class Initialized
DEBUG - 2011-06-03 02:31:55 --> Controller Class Initialized
ERROR - 2011-06-03 02:31:55 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-03 02:31:55 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-03 02:31:55 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-03 02:31:55 --> Model Class Initialized
DEBUG - 2011-06-03 02:31:55 --> Model Class Initialized
DEBUG - 2011-06-03 02:31:55 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-03 02:31:55 --> Database Driver Class Initialized
DEBUG - 2011-06-03 02:31:55 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-03 02:31:55 --> Helper loaded: url_helper
DEBUG - 2011-06-03 02:31:55 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-03 02:31:55 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-03 02:31:55 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-03 02:31:55 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-03 02:31:55 --> Final output sent to browser
DEBUG - 2011-06-03 02:31:55 --> Total execution time: 0.4416
DEBUG - 2011-06-03 02:31:58 --> Config Class Initialized
DEBUG - 2011-06-03 02:31:58 --> Hooks Class Initialized
DEBUG - 2011-06-03 02:31:58 --> Utf8 Class Initialized
DEBUG - 2011-06-03 02:31:58 --> UTF-8 Support Enabled
DEBUG - 2011-06-03 02:31:58 --> URI Class Initialized
DEBUG - 2011-06-03 02:31:58 --> Router Class Initialized
DEBUG - 2011-06-03 02:31:58 --> Output Class Initialized
DEBUG - 2011-06-03 02:31:58 --> Input Class Initialized
DEBUG - 2011-06-03 02:31:58 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-03 02:31:58 --> Language Class Initialized
DEBUG - 2011-06-03 02:31:58 --> Loader Class Initialized
DEBUG - 2011-06-03 02:31:58 --> Controller Class Initialized
DEBUG - 2011-06-03 02:31:58 --> Model Class Initialized
DEBUG - 2011-06-03 02:31:58 --> Model Class Initialized
DEBUG - 2011-06-03 02:31:58 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-03 02:31:58 --> Database Driver Class Initialized
DEBUG - 2011-06-03 02:31:59 --> Final output sent to browser
DEBUG - 2011-06-03 02:31:59 --> Total execution time: 0.9190
DEBUG - 2011-06-03 02:32:04 --> Config Class Initialized
DEBUG - 2011-06-03 02:32:04 --> Hooks Class Initialized
DEBUG - 2011-06-03 02:32:04 --> Utf8 Class Initialized
DEBUG - 2011-06-03 02:32:04 --> UTF-8 Support Enabled
DEBUG - 2011-06-03 02:32:04 --> URI Class Initialized
DEBUG - 2011-06-03 02:32:04 --> Router Class Initialized
ERROR - 2011-06-03 02:32:04 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-03 02:32:36 --> Config Class Initialized
DEBUG - 2011-06-03 02:32:36 --> Hooks Class Initialized
DEBUG - 2011-06-03 02:32:36 --> Utf8 Class Initialized
DEBUG - 2011-06-03 02:32:36 --> UTF-8 Support Enabled
DEBUG - 2011-06-03 02:32:36 --> URI Class Initialized
DEBUG - 2011-06-03 02:32:36 --> Router Class Initialized
DEBUG - 2011-06-03 02:32:36 --> Output Class Initialized
DEBUG - 2011-06-03 02:32:36 --> Input Class Initialized
DEBUG - 2011-06-03 02:32:36 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-03 02:32:36 --> Language Class Initialized
DEBUG - 2011-06-03 02:32:36 --> Loader Class Initialized
DEBUG - 2011-06-03 02:32:36 --> Controller Class Initialized
ERROR - 2011-06-03 02:32:36 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-03 02:32:36 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-03 02:32:36 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-03 02:32:36 --> Model Class Initialized
DEBUG - 2011-06-03 02:32:36 --> Model Class Initialized
DEBUG - 2011-06-03 02:32:36 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-03 02:32:36 --> Database Driver Class Initialized
DEBUG - 2011-06-03 02:32:36 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-03 02:32:36 --> Helper loaded: url_helper
DEBUG - 2011-06-03 02:32:36 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-03 02:32:36 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-03 02:32:36 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-03 02:32:36 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-03 02:32:36 --> Final output sent to browser
DEBUG - 2011-06-03 02:32:36 --> Total execution time: 0.0511
DEBUG - 2011-06-03 02:32:40 --> Config Class Initialized
DEBUG - 2011-06-03 02:32:40 --> Hooks Class Initialized
DEBUG - 2011-06-03 02:32:40 --> Utf8 Class Initialized
DEBUG - 2011-06-03 02:32:40 --> UTF-8 Support Enabled
DEBUG - 2011-06-03 02:32:40 --> URI Class Initialized
DEBUG - 2011-06-03 02:32:40 --> Router Class Initialized
DEBUG - 2011-06-03 02:32:40 --> Output Class Initialized
DEBUG - 2011-06-03 02:32:40 --> Input Class Initialized
DEBUG - 2011-06-03 02:32:40 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-03 02:32:40 --> Language Class Initialized
DEBUG - 2011-06-03 02:32:40 --> Loader Class Initialized
DEBUG - 2011-06-03 02:32:40 --> Controller Class Initialized
DEBUG - 2011-06-03 02:32:40 --> Model Class Initialized
DEBUG - 2011-06-03 02:32:40 --> Model Class Initialized
DEBUG - 2011-06-03 02:32:40 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-03 02:32:40 --> Database Driver Class Initialized
DEBUG - 2011-06-03 02:32:41 --> Final output sent to browser
DEBUG - 2011-06-03 02:32:41 --> Total execution time: 0.7691
DEBUG - 2011-06-03 02:32:50 --> Config Class Initialized
DEBUG - 2011-06-03 02:32:50 --> Hooks Class Initialized
DEBUG - 2011-06-03 02:32:50 --> Utf8 Class Initialized
DEBUG - 2011-06-03 02:32:50 --> UTF-8 Support Enabled
DEBUG - 2011-06-03 02:32:50 --> URI Class Initialized
DEBUG - 2011-06-03 02:32:50 --> Router Class Initialized
ERROR - 2011-06-03 02:32:50 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-03 02:33:19 --> Config Class Initialized
DEBUG - 2011-06-03 02:33:19 --> Hooks Class Initialized
DEBUG - 2011-06-03 02:33:19 --> Utf8 Class Initialized
DEBUG - 2011-06-03 02:33:19 --> UTF-8 Support Enabled
DEBUG - 2011-06-03 02:33:19 --> URI Class Initialized
DEBUG - 2011-06-03 02:33:19 --> Router Class Initialized
DEBUG - 2011-06-03 02:33:19 --> Output Class Initialized
DEBUG - 2011-06-03 02:33:19 --> Input Class Initialized
DEBUG - 2011-06-03 02:33:19 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-03 02:33:19 --> Language Class Initialized
DEBUG - 2011-06-03 02:33:19 --> Loader Class Initialized
DEBUG - 2011-06-03 02:33:19 --> Controller Class Initialized
ERROR - 2011-06-03 02:33:19 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-03 02:33:19 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-03 02:33:19 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-03 02:33:19 --> Model Class Initialized
DEBUG - 2011-06-03 02:33:19 --> Model Class Initialized
DEBUG - 2011-06-03 02:33:19 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-03 02:33:19 --> Database Driver Class Initialized
DEBUG - 2011-06-03 02:33:19 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-03 02:33:19 --> Helper loaded: url_helper
DEBUG - 2011-06-03 02:33:19 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-03 02:33:19 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-03 02:33:19 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-03 02:33:19 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-03 02:33:19 --> Final output sent to browser
DEBUG - 2011-06-03 02:33:19 --> Total execution time: 0.0332
DEBUG - 2011-06-03 02:33:21 --> Config Class Initialized
DEBUG - 2011-06-03 02:33:21 --> Hooks Class Initialized
DEBUG - 2011-06-03 02:33:21 --> Utf8 Class Initialized
DEBUG - 2011-06-03 02:33:21 --> UTF-8 Support Enabled
DEBUG - 2011-06-03 02:33:21 --> URI Class Initialized
DEBUG - 2011-06-03 02:33:21 --> Router Class Initialized
DEBUG - 2011-06-03 02:33:21 --> Output Class Initialized
DEBUG - 2011-06-03 02:33:21 --> Input Class Initialized
DEBUG - 2011-06-03 02:33:21 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-03 02:33:21 --> Language Class Initialized
DEBUG - 2011-06-03 02:33:21 --> Loader Class Initialized
DEBUG - 2011-06-03 02:33:21 --> Controller Class Initialized
DEBUG - 2011-06-03 02:33:21 --> Model Class Initialized
DEBUG - 2011-06-03 02:33:21 --> Model Class Initialized
DEBUG - 2011-06-03 02:33:21 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-03 02:33:21 --> Database Driver Class Initialized
DEBUG - 2011-06-03 02:33:22 --> Final output sent to browser
DEBUG - 2011-06-03 02:33:22 --> Total execution time: 0.9661
DEBUG - 2011-06-03 02:33:26 --> Config Class Initialized
DEBUG - 2011-06-03 02:33:26 --> Hooks Class Initialized
DEBUG - 2011-06-03 02:33:26 --> Utf8 Class Initialized
DEBUG - 2011-06-03 02:33:26 --> UTF-8 Support Enabled
DEBUG - 2011-06-03 02:33:26 --> URI Class Initialized
DEBUG - 2011-06-03 02:33:26 --> Router Class Initialized
ERROR - 2011-06-03 02:33:26 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-03 02:33:40 --> Config Class Initialized
DEBUG - 2011-06-03 02:33:40 --> Hooks Class Initialized
DEBUG - 2011-06-03 02:33:40 --> Utf8 Class Initialized
DEBUG - 2011-06-03 02:33:40 --> UTF-8 Support Enabled
DEBUG - 2011-06-03 02:33:40 --> URI Class Initialized
DEBUG - 2011-06-03 02:33:40 --> Router Class Initialized
DEBUG - 2011-06-03 02:33:40 --> Output Class Initialized
DEBUG - 2011-06-03 02:33:40 --> Input Class Initialized
DEBUG - 2011-06-03 02:33:40 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-03 02:33:40 --> Language Class Initialized
DEBUG - 2011-06-03 02:33:40 --> Loader Class Initialized
DEBUG - 2011-06-03 02:33:40 --> Controller Class Initialized
ERROR - 2011-06-03 02:33:40 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-03 02:33:40 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-03 02:33:40 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-03 02:33:40 --> Model Class Initialized
DEBUG - 2011-06-03 02:33:40 --> Model Class Initialized
DEBUG - 2011-06-03 02:33:40 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-03 02:33:40 --> Database Driver Class Initialized
DEBUG - 2011-06-03 02:33:40 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-03 02:33:40 --> Helper loaded: url_helper
DEBUG - 2011-06-03 02:33:40 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-03 02:33:40 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-03 02:33:40 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-03 02:33:40 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-03 02:33:40 --> Final output sent to browser
DEBUG - 2011-06-03 02:33:40 --> Total execution time: 0.0329
DEBUG - 2011-06-03 02:33:42 --> Config Class Initialized
DEBUG - 2011-06-03 02:33:42 --> Hooks Class Initialized
DEBUG - 2011-06-03 02:33:42 --> Utf8 Class Initialized
DEBUG - 2011-06-03 02:33:42 --> UTF-8 Support Enabled
DEBUG - 2011-06-03 02:33:42 --> URI Class Initialized
DEBUG - 2011-06-03 02:33:42 --> Router Class Initialized
DEBUG - 2011-06-03 02:33:42 --> Output Class Initialized
DEBUG - 2011-06-03 02:33:42 --> Input Class Initialized
DEBUG - 2011-06-03 02:33:42 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-03 02:33:42 --> Language Class Initialized
DEBUG - 2011-06-03 02:33:42 --> Loader Class Initialized
DEBUG - 2011-06-03 02:33:42 --> Controller Class Initialized
DEBUG - 2011-06-03 02:33:42 --> Model Class Initialized
DEBUG - 2011-06-03 02:33:42 --> Model Class Initialized
DEBUG - 2011-06-03 02:33:42 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-03 02:33:42 --> Database Driver Class Initialized
DEBUG - 2011-06-03 02:33:43 --> Config Class Initialized
DEBUG - 2011-06-03 02:33:43 --> Hooks Class Initialized
DEBUG - 2011-06-03 02:33:43 --> Utf8 Class Initialized
DEBUG - 2011-06-03 02:33:43 --> UTF-8 Support Enabled
DEBUG - 2011-06-03 02:33:43 --> URI Class Initialized
DEBUG - 2011-06-03 02:33:43 --> Router Class Initialized
DEBUG - 2011-06-03 02:33:43 --> Output Class Initialized
DEBUG - 2011-06-03 02:33:43 --> Input Class Initialized
DEBUG - 2011-06-03 02:33:43 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-03 02:33:43 --> Language Class Initialized
DEBUG - 2011-06-03 02:33:43 --> Loader Class Initialized
DEBUG - 2011-06-03 02:33:43 --> Controller Class Initialized
ERROR - 2011-06-03 02:33:43 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-03 02:33:43 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-03 02:33:43 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-03 02:33:43 --> Model Class Initialized
DEBUG - 2011-06-03 02:33:43 --> Model Class Initialized
DEBUG - 2011-06-03 02:33:43 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-03 02:33:43 --> Database Driver Class Initialized
DEBUG - 2011-06-03 02:33:43 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-03 02:33:43 --> Helper loaded: url_helper
DEBUG - 2011-06-03 02:33:43 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-03 02:33:43 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-03 02:33:43 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-03 02:33:43 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-03 02:33:43 --> Final output sent to browser
DEBUG - 2011-06-03 02:33:43 --> Total execution time: 0.1089
DEBUG - 2011-06-03 02:33:43 --> Final output sent to browser
DEBUG - 2011-06-03 02:33:43 --> Total execution time: 0.8684
DEBUG - 2011-06-03 02:33:48 --> Config Class Initialized
DEBUG - 2011-06-03 02:33:48 --> Hooks Class Initialized
DEBUG - 2011-06-03 02:33:48 --> Utf8 Class Initialized
DEBUG - 2011-06-03 02:33:48 --> UTF-8 Support Enabled
DEBUG - 2011-06-03 02:33:48 --> URI Class Initialized
DEBUG - 2011-06-03 02:33:48 --> Router Class Initialized
ERROR - 2011-06-03 02:33:48 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-03 02:34:09 --> Config Class Initialized
DEBUG - 2011-06-03 02:34:09 --> Hooks Class Initialized
DEBUG - 2011-06-03 02:34:09 --> Utf8 Class Initialized
DEBUG - 2011-06-03 02:34:09 --> UTF-8 Support Enabled
DEBUG - 2011-06-03 02:34:09 --> URI Class Initialized
DEBUG - 2011-06-03 02:34:09 --> Router Class Initialized
DEBUG - 2011-06-03 02:34:09 --> Output Class Initialized
DEBUG - 2011-06-03 02:34:09 --> Input Class Initialized
DEBUG - 2011-06-03 02:34:09 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-03 02:34:09 --> Language Class Initialized
DEBUG - 2011-06-03 02:34:09 --> Loader Class Initialized
DEBUG - 2011-06-03 02:34:09 --> Controller Class Initialized
ERROR - 2011-06-03 02:34:09 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-03 02:34:09 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-03 02:34:09 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-03 02:34:09 --> Model Class Initialized
DEBUG - 2011-06-03 02:34:09 --> Model Class Initialized
DEBUG - 2011-06-03 02:34:09 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-03 02:34:09 --> Database Driver Class Initialized
DEBUG - 2011-06-03 02:34:09 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-03 02:34:09 --> Helper loaded: url_helper
DEBUG - 2011-06-03 02:34:09 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-03 02:34:09 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-03 02:34:09 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-03 02:34:09 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-03 02:34:09 --> Final output sent to browser
DEBUG - 2011-06-03 02:34:09 --> Total execution time: 0.0453
DEBUG - 2011-06-03 02:34:11 --> Config Class Initialized
DEBUG - 2011-06-03 02:34:11 --> Hooks Class Initialized
DEBUG - 2011-06-03 02:34:11 --> Utf8 Class Initialized
DEBUG - 2011-06-03 02:34:11 --> UTF-8 Support Enabled
DEBUG - 2011-06-03 02:34:11 --> URI Class Initialized
DEBUG - 2011-06-03 02:34:11 --> Router Class Initialized
DEBUG - 2011-06-03 02:34:11 --> Output Class Initialized
DEBUG - 2011-06-03 02:34:11 --> Input Class Initialized
DEBUG - 2011-06-03 02:34:11 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-03 02:34:11 --> Language Class Initialized
DEBUG - 2011-06-03 02:34:11 --> Loader Class Initialized
DEBUG - 2011-06-03 02:34:11 --> Controller Class Initialized
DEBUG - 2011-06-03 02:34:11 --> Model Class Initialized
DEBUG - 2011-06-03 02:34:11 --> Model Class Initialized
DEBUG - 2011-06-03 02:34:11 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-03 02:34:11 --> Database Driver Class Initialized
DEBUG - 2011-06-03 02:34:13 --> Final output sent to browser
DEBUG - 2011-06-03 02:34:13 --> Total execution time: 1.5580
DEBUG - 2011-06-03 02:34:16 --> Config Class Initialized
DEBUG - 2011-06-03 02:34:16 --> Hooks Class Initialized
DEBUG - 2011-06-03 02:34:16 --> Utf8 Class Initialized
DEBUG - 2011-06-03 02:34:16 --> UTF-8 Support Enabled
DEBUG - 2011-06-03 02:34:16 --> URI Class Initialized
DEBUG - 2011-06-03 02:34:16 --> Router Class Initialized
ERROR - 2011-06-03 02:34:16 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-03 02:34:31 --> Config Class Initialized
DEBUG - 2011-06-03 02:34:31 --> Hooks Class Initialized
DEBUG - 2011-06-03 02:34:31 --> Utf8 Class Initialized
DEBUG - 2011-06-03 02:34:31 --> UTF-8 Support Enabled
DEBUG - 2011-06-03 02:34:31 --> URI Class Initialized
DEBUG - 2011-06-03 02:34:31 --> Router Class Initialized
DEBUG - 2011-06-03 02:34:31 --> Output Class Initialized
DEBUG - 2011-06-03 02:34:31 --> Input Class Initialized
DEBUG - 2011-06-03 02:34:31 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-03 02:34:31 --> Language Class Initialized
DEBUG - 2011-06-03 02:34:31 --> Loader Class Initialized
DEBUG - 2011-06-03 02:34:31 --> Controller Class Initialized
ERROR - 2011-06-03 02:34:31 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-03 02:34:31 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-03 02:34:31 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-03 02:34:31 --> Model Class Initialized
DEBUG - 2011-06-03 02:34:31 --> Model Class Initialized
DEBUG - 2011-06-03 02:34:31 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-03 02:34:31 --> Database Driver Class Initialized
DEBUG - 2011-06-03 02:34:31 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-03 02:34:31 --> Helper loaded: url_helper
DEBUG - 2011-06-03 02:34:31 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-03 02:34:31 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-03 02:34:31 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-03 02:34:31 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-03 02:34:31 --> Final output sent to browser
DEBUG - 2011-06-03 02:34:31 --> Total execution time: 0.0321
DEBUG - 2011-06-03 02:34:33 --> Config Class Initialized
DEBUG - 2011-06-03 02:34:33 --> Hooks Class Initialized
DEBUG - 2011-06-03 02:34:33 --> Utf8 Class Initialized
DEBUG - 2011-06-03 02:34:33 --> UTF-8 Support Enabled
DEBUG - 2011-06-03 02:34:33 --> URI Class Initialized
DEBUG - 2011-06-03 02:34:33 --> Router Class Initialized
DEBUG - 2011-06-03 02:34:33 --> Output Class Initialized
DEBUG - 2011-06-03 02:34:33 --> Input Class Initialized
DEBUG - 2011-06-03 02:34:33 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-03 02:34:33 --> Language Class Initialized
DEBUG - 2011-06-03 02:34:33 --> Loader Class Initialized
DEBUG - 2011-06-03 02:34:33 --> Controller Class Initialized
DEBUG - 2011-06-03 02:34:33 --> Model Class Initialized
DEBUG - 2011-06-03 02:34:33 --> Model Class Initialized
DEBUG - 2011-06-03 02:34:33 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-03 02:34:33 --> Database Driver Class Initialized
DEBUG - 2011-06-03 02:34:38 --> Final output sent to browser
DEBUG - 2011-06-03 02:34:38 --> Total execution time: 4.8252
DEBUG - 2011-06-03 02:34:41 --> Config Class Initialized
DEBUG - 2011-06-03 02:34:41 --> Hooks Class Initialized
DEBUG - 2011-06-03 02:34:41 --> Utf8 Class Initialized
DEBUG - 2011-06-03 02:34:41 --> UTF-8 Support Enabled
DEBUG - 2011-06-03 02:34:41 --> URI Class Initialized
DEBUG - 2011-06-03 02:34:41 --> Router Class Initialized
ERROR - 2011-06-03 02:34:41 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-03 02:35:14 --> Config Class Initialized
DEBUG - 2011-06-03 02:35:14 --> Hooks Class Initialized
DEBUG - 2011-06-03 02:35:14 --> Utf8 Class Initialized
DEBUG - 2011-06-03 02:35:14 --> UTF-8 Support Enabled
DEBUG - 2011-06-03 02:35:14 --> URI Class Initialized
DEBUG - 2011-06-03 02:35:14 --> Router Class Initialized
DEBUG - 2011-06-03 02:35:14 --> Output Class Initialized
DEBUG - 2011-06-03 02:35:14 --> Input Class Initialized
DEBUG - 2011-06-03 02:35:14 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-03 02:35:14 --> Language Class Initialized
DEBUG - 2011-06-03 02:35:14 --> Loader Class Initialized
DEBUG - 2011-06-03 02:35:14 --> Controller Class Initialized
ERROR - 2011-06-03 02:35:14 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-03 02:35:14 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-03 02:35:14 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-03 02:35:14 --> Model Class Initialized
DEBUG - 2011-06-03 02:35:14 --> Model Class Initialized
DEBUG - 2011-06-03 02:35:14 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-03 02:35:14 --> Database Driver Class Initialized
DEBUG - 2011-06-03 02:35:14 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-03 02:35:14 --> Helper loaded: url_helper
DEBUG - 2011-06-03 02:35:14 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-03 02:35:14 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-03 02:35:14 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-03 02:35:14 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-03 02:35:14 --> Final output sent to browser
DEBUG - 2011-06-03 02:35:14 --> Total execution time: 0.0263
DEBUG - 2011-06-03 02:35:16 --> Config Class Initialized
DEBUG - 2011-06-03 02:35:16 --> Hooks Class Initialized
DEBUG - 2011-06-03 02:35:16 --> Utf8 Class Initialized
DEBUG - 2011-06-03 02:35:16 --> UTF-8 Support Enabled
DEBUG - 2011-06-03 02:35:16 --> URI Class Initialized
DEBUG - 2011-06-03 02:35:16 --> Router Class Initialized
DEBUG - 2011-06-03 02:35:16 --> Output Class Initialized
DEBUG - 2011-06-03 02:35:16 --> Input Class Initialized
DEBUG - 2011-06-03 02:35:16 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-03 02:35:16 --> Language Class Initialized
DEBUG - 2011-06-03 02:35:16 --> Loader Class Initialized
DEBUG - 2011-06-03 02:35:16 --> Controller Class Initialized
DEBUG - 2011-06-03 02:35:16 --> Model Class Initialized
DEBUG - 2011-06-03 02:35:16 --> Model Class Initialized
DEBUG - 2011-06-03 02:35:16 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-03 02:35:16 --> Database Driver Class Initialized
DEBUG - 2011-06-03 02:35:16 --> Config Class Initialized
DEBUG - 2011-06-03 02:35:16 --> Hooks Class Initialized
DEBUG - 2011-06-03 02:35:16 --> Utf8 Class Initialized
DEBUG - 2011-06-03 02:35:16 --> UTF-8 Support Enabled
DEBUG - 2011-06-03 02:35:16 --> URI Class Initialized
DEBUG - 2011-06-03 02:35:16 --> Router Class Initialized
DEBUG - 2011-06-03 02:35:16 --> Output Class Initialized
DEBUG - 2011-06-03 02:35:16 --> Input Class Initialized
DEBUG - 2011-06-03 02:35:16 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-03 02:35:16 --> Language Class Initialized
DEBUG - 2011-06-03 02:35:16 --> Loader Class Initialized
DEBUG - 2011-06-03 02:35:16 --> Controller Class Initialized
ERROR - 2011-06-03 02:35:16 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-03 02:35:16 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-03 02:35:16 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-03 02:35:16 --> Model Class Initialized
DEBUG - 2011-06-03 02:35:16 --> Model Class Initialized
DEBUG - 2011-06-03 02:35:16 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-03 02:35:16 --> Database Driver Class Initialized
DEBUG - 2011-06-03 02:35:16 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-03 02:35:16 --> Helper loaded: url_helper
DEBUG - 2011-06-03 02:35:16 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-03 02:35:16 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-03 02:35:16 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-03 02:35:16 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-03 02:35:16 --> Final output sent to browser
DEBUG - 2011-06-03 02:35:16 --> Total execution time: 0.0284
DEBUG - 2011-06-03 02:35:19 --> Final output sent to browser
DEBUG - 2011-06-03 02:35:19 --> Total execution time: 2.8292
DEBUG - 2011-06-03 02:35:21 --> Config Class Initialized
DEBUG - 2011-06-03 02:35:21 --> Hooks Class Initialized
DEBUG - 2011-06-03 02:35:21 --> Utf8 Class Initialized
DEBUG - 2011-06-03 02:35:21 --> UTF-8 Support Enabled
DEBUG - 2011-06-03 02:35:21 --> URI Class Initialized
DEBUG - 2011-06-03 02:35:21 --> Router Class Initialized
ERROR - 2011-06-03 02:35:21 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-03 02:35:40 --> Config Class Initialized
DEBUG - 2011-06-03 02:35:40 --> Hooks Class Initialized
DEBUG - 2011-06-03 02:35:40 --> Utf8 Class Initialized
DEBUG - 2011-06-03 02:35:40 --> UTF-8 Support Enabled
DEBUG - 2011-06-03 02:35:40 --> URI Class Initialized
DEBUG - 2011-06-03 02:35:40 --> Router Class Initialized
DEBUG - 2011-06-03 02:35:40 --> Output Class Initialized
DEBUG - 2011-06-03 02:35:40 --> Input Class Initialized
DEBUG - 2011-06-03 02:35:40 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-03 02:35:40 --> Language Class Initialized
DEBUG - 2011-06-03 02:35:40 --> Loader Class Initialized
DEBUG - 2011-06-03 02:35:40 --> Controller Class Initialized
ERROR - 2011-06-03 02:35:40 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-03 02:35:40 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-03 02:35:40 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-03 02:35:40 --> Model Class Initialized
DEBUG - 2011-06-03 02:35:40 --> Model Class Initialized
DEBUG - 2011-06-03 02:35:40 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-03 02:35:40 --> Database Driver Class Initialized
DEBUG - 2011-06-03 02:35:40 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-03 02:35:40 --> Helper loaded: url_helper
DEBUG - 2011-06-03 02:35:40 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-03 02:35:40 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-03 02:35:40 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-03 02:35:40 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-03 02:35:40 --> Final output sent to browser
DEBUG - 2011-06-03 02:35:40 --> Total execution time: 0.0465
DEBUG - 2011-06-03 02:35:43 --> Config Class Initialized
DEBUG - 2011-06-03 02:35:43 --> Hooks Class Initialized
DEBUG - 2011-06-03 02:35:43 --> Utf8 Class Initialized
DEBUG - 2011-06-03 02:35:43 --> UTF-8 Support Enabled
DEBUG - 2011-06-03 02:35:43 --> URI Class Initialized
DEBUG - 2011-06-03 02:35:43 --> Router Class Initialized
DEBUG - 2011-06-03 02:35:43 --> Output Class Initialized
DEBUG - 2011-06-03 02:35:43 --> Input Class Initialized
DEBUG - 2011-06-03 02:35:43 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-03 02:35:43 --> Language Class Initialized
DEBUG - 2011-06-03 02:35:43 --> Loader Class Initialized
DEBUG - 2011-06-03 02:35:43 --> Controller Class Initialized
DEBUG - 2011-06-03 02:35:43 --> Model Class Initialized
DEBUG - 2011-06-03 02:35:43 --> Model Class Initialized
DEBUG - 2011-06-03 02:35:43 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-03 02:35:43 --> Database Driver Class Initialized
DEBUG - 2011-06-03 02:35:43 --> Config Class Initialized
DEBUG - 2011-06-03 02:35:43 --> Hooks Class Initialized
DEBUG - 2011-06-03 02:35:43 --> Utf8 Class Initialized
DEBUG - 2011-06-03 02:35:43 --> UTF-8 Support Enabled
DEBUG - 2011-06-03 02:35:43 --> URI Class Initialized
DEBUG - 2011-06-03 02:35:43 --> Router Class Initialized
DEBUG - 2011-06-03 02:35:43 --> Output Class Initialized
DEBUG - 2011-06-03 02:35:43 --> Input Class Initialized
DEBUG - 2011-06-03 02:35:43 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-03 02:35:43 --> Language Class Initialized
DEBUG - 2011-06-03 02:35:43 --> Loader Class Initialized
DEBUG - 2011-06-03 02:35:43 --> Controller Class Initialized
ERROR - 2011-06-03 02:35:43 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-03 02:35:43 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-03 02:35:43 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-03 02:35:43 --> Model Class Initialized
DEBUG - 2011-06-03 02:35:43 --> Model Class Initialized
DEBUG - 2011-06-03 02:35:43 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-03 02:35:43 --> Database Driver Class Initialized
DEBUG - 2011-06-03 02:35:43 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-03 02:35:43 --> Helper loaded: url_helper
DEBUG - 2011-06-03 02:35:43 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-03 02:35:43 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-03 02:35:43 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-03 02:35:43 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-03 02:35:43 --> Final output sent to browser
DEBUG - 2011-06-03 02:35:43 --> Total execution time: 0.0265
DEBUG - 2011-06-03 02:35:46 --> Final output sent to browser
DEBUG - 2011-06-03 02:35:46 --> Total execution time: 3.3593
DEBUG - 2011-06-03 02:35:48 --> Config Class Initialized
DEBUG - 2011-06-03 02:35:48 --> Hooks Class Initialized
DEBUG - 2011-06-03 02:35:48 --> Utf8 Class Initialized
DEBUG - 2011-06-03 02:35:48 --> UTF-8 Support Enabled
DEBUG - 2011-06-03 02:35:48 --> URI Class Initialized
DEBUG - 2011-06-03 02:35:48 --> Router Class Initialized
ERROR - 2011-06-03 02:35:48 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-03 02:36:14 --> Config Class Initialized
DEBUG - 2011-06-03 02:36:14 --> Hooks Class Initialized
DEBUG - 2011-06-03 02:36:14 --> Utf8 Class Initialized
DEBUG - 2011-06-03 02:36:14 --> UTF-8 Support Enabled
DEBUG - 2011-06-03 02:36:14 --> URI Class Initialized
DEBUG - 2011-06-03 02:36:14 --> Router Class Initialized
DEBUG - 2011-06-03 02:36:14 --> Output Class Initialized
DEBUG - 2011-06-03 02:36:14 --> Input Class Initialized
DEBUG - 2011-06-03 02:36:14 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-03 02:36:14 --> Language Class Initialized
DEBUG - 2011-06-03 02:36:14 --> Loader Class Initialized
DEBUG - 2011-06-03 02:36:14 --> Controller Class Initialized
ERROR - 2011-06-03 02:36:14 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-03 02:36:14 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-03 02:36:14 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-03 02:36:14 --> Model Class Initialized
DEBUG - 2011-06-03 02:36:14 --> Model Class Initialized
DEBUG - 2011-06-03 02:36:14 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-03 02:36:14 --> Database Driver Class Initialized
DEBUG - 2011-06-03 02:36:14 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-03 02:36:14 --> Helper loaded: url_helper
DEBUG - 2011-06-03 02:36:14 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-03 02:36:14 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-03 02:36:14 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-03 02:36:14 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-03 02:36:14 --> Final output sent to browser
DEBUG - 2011-06-03 02:36:14 --> Total execution time: 0.0309
DEBUG - 2011-06-03 02:36:16 --> Config Class Initialized
DEBUG - 2011-06-03 02:36:16 --> Hooks Class Initialized
DEBUG - 2011-06-03 02:36:16 --> Utf8 Class Initialized
DEBUG - 2011-06-03 02:36:16 --> UTF-8 Support Enabled
DEBUG - 2011-06-03 02:36:16 --> URI Class Initialized
DEBUG - 2011-06-03 02:36:16 --> Router Class Initialized
DEBUG - 2011-06-03 02:36:16 --> Output Class Initialized
DEBUG - 2011-06-03 02:36:16 --> Input Class Initialized
DEBUG - 2011-06-03 02:36:16 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-03 02:36:16 --> Language Class Initialized
DEBUG - 2011-06-03 02:36:16 --> Loader Class Initialized
DEBUG - 2011-06-03 02:36:16 --> Controller Class Initialized
DEBUG - 2011-06-03 02:36:16 --> Model Class Initialized
DEBUG - 2011-06-03 02:36:16 --> Model Class Initialized
DEBUG - 2011-06-03 02:36:16 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-03 02:36:16 --> Database Driver Class Initialized
DEBUG - 2011-06-03 02:36:20 --> Final output sent to browser
DEBUG - 2011-06-03 02:36:20 --> Total execution time: 3.5521
DEBUG - 2011-06-03 02:36:25 --> Config Class Initialized
DEBUG - 2011-06-03 02:36:25 --> Hooks Class Initialized
DEBUG - 2011-06-03 02:36:25 --> Utf8 Class Initialized
DEBUG - 2011-06-03 02:36:25 --> UTF-8 Support Enabled
DEBUG - 2011-06-03 02:36:25 --> URI Class Initialized
DEBUG - 2011-06-03 02:36:25 --> Router Class Initialized
ERROR - 2011-06-03 02:36:25 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-03 02:36:44 --> Config Class Initialized
DEBUG - 2011-06-03 02:36:44 --> Hooks Class Initialized
DEBUG - 2011-06-03 02:36:44 --> Utf8 Class Initialized
DEBUG - 2011-06-03 02:36:44 --> UTF-8 Support Enabled
DEBUG - 2011-06-03 02:36:44 --> URI Class Initialized
DEBUG - 2011-06-03 02:36:44 --> Router Class Initialized
DEBUG - 2011-06-03 02:36:44 --> Output Class Initialized
DEBUG - 2011-06-03 02:36:44 --> Input Class Initialized
DEBUG - 2011-06-03 02:36:44 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-03 02:36:44 --> Language Class Initialized
DEBUG - 2011-06-03 02:36:44 --> Loader Class Initialized
DEBUG - 2011-06-03 02:36:44 --> Controller Class Initialized
ERROR - 2011-06-03 02:36:44 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-03 02:36:44 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-03 02:36:44 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-03 02:36:44 --> Model Class Initialized
DEBUG - 2011-06-03 02:36:44 --> Model Class Initialized
DEBUG - 2011-06-03 02:36:44 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-03 02:36:45 --> Database Driver Class Initialized
DEBUG - 2011-06-03 02:36:45 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-03 02:36:45 --> Helper loaded: url_helper
DEBUG - 2011-06-03 02:36:45 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-03 02:36:45 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-03 02:36:45 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-03 02:36:45 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-03 02:36:45 --> Final output sent to browser
DEBUG - 2011-06-03 02:36:45 --> Total execution time: 0.0281
DEBUG - 2011-06-03 02:36:47 --> Config Class Initialized
DEBUG - 2011-06-03 02:36:47 --> Hooks Class Initialized
DEBUG - 2011-06-03 02:36:47 --> Utf8 Class Initialized
DEBUG - 2011-06-03 02:36:47 --> UTF-8 Support Enabled
DEBUG - 2011-06-03 02:36:47 --> URI Class Initialized
DEBUG - 2011-06-03 02:36:47 --> Router Class Initialized
DEBUG - 2011-06-03 02:36:47 --> Output Class Initialized
DEBUG - 2011-06-03 02:36:47 --> Input Class Initialized
DEBUG - 2011-06-03 02:36:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-03 02:36:47 --> Language Class Initialized
DEBUG - 2011-06-03 02:36:47 --> Loader Class Initialized
DEBUG - 2011-06-03 02:36:47 --> Controller Class Initialized
DEBUG - 2011-06-03 02:36:47 --> Model Class Initialized
DEBUG - 2011-06-03 02:36:47 --> Model Class Initialized
DEBUG - 2011-06-03 02:36:47 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-03 02:36:47 --> Database Driver Class Initialized
DEBUG - 2011-06-03 02:36:47 --> Config Class Initialized
DEBUG - 2011-06-03 02:36:47 --> Hooks Class Initialized
DEBUG - 2011-06-03 02:36:47 --> Utf8 Class Initialized
DEBUG - 2011-06-03 02:36:47 --> UTF-8 Support Enabled
DEBUG - 2011-06-03 02:36:47 --> URI Class Initialized
DEBUG - 2011-06-03 02:36:47 --> Router Class Initialized
DEBUG - 2011-06-03 02:36:47 --> Output Class Initialized
DEBUG - 2011-06-03 02:36:47 --> Input Class Initialized
DEBUG - 2011-06-03 02:36:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-03 02:36:47 --> Language Class Initialized
DEBUG - 2011-06-03 02:36:47 --> Loader Class Initialized
DEBUG - 2011-06-03 02:36:47 --> Controller Class Initialized
ERROR - 2011-06-03 02:36:47 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-03 02:36:47 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-03 02:36:47 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-03 02:36:47 --> Model Class Initialized
DEBUG - 2011-06-03 02:36:47 --> Model Class Initialized
DEBUG - 2011-06-03 02:36:47 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-03 02:36:47 --> Database Driver Class Initialized
DEBUG - 2011-06-03 02:36:47 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-03 02:36:47 --> Helper loaded: url_helper
DEBUG - 2011-06-03 02:36:47 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-03 02:36:47 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-03 02:36:47 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-03 02:36:47 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-03 02:36:47 --> Final output sent to browser
DEBUG - 2011-06-03 02:36:47 --> Total execution time: 0.0320
DEBUG - 2011-06-03 02:36:48 --> Final output sent to browser
DEBUG - 2011-06-03 02:36:48 --> Total execution time: 0.9171
DEBUG - 2011-06-03 02:36:50 --> Config Class Initialized
DEBUG - 2011-06-03 02:36:50 --> Hooks Class Initialized
DEBUG - 2011-06-03 02:36:50 --> Utf8 Class Initialized
DEBUG - 2011-06-03 02:36:50 --> UTF-8 Support Enabled
DEBUG - 2011-06-03 02:36:50 --> URI Class Initialized
DEBUG - 2011-06-03 02:36:50 --> Router Class Initialized
DEBUG - 2011-06-03 02:36:50 --> Output Class Initialized
DEBUG - 2011-06-03 02:36:50 --> Input Class Initialized
DEBUG - 2011-06-03 02:36:50 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-03 02:36:50 --> Language Class Initialized
DEBUG - 2011-06-03 02:36:50 --> Loader Class Initialized
DEBUG - 2011-06-03 02:36:50 --> Controller Class Initialized
ERROR - 2011-06-03 02:36:50 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-03 02:36:50 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-03 02:36:50 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-03 02:36:50 --> Model Class Initialized
DEBUG - 2011-06-03 02:36:50 --> Model Class Initialized
DEBUG - 2011-06-03 02:36:50 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-03 02:36:50 --> Database Driver Class Initialized
DEBUG - 2011-06-03 02:36:50 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-03 02:36:50 --> Helper loaded: url_helper
DEBUG - 2011-06-03 02:36:50 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-03 02:36:50 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-03 02:36:50 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-03 02:36:50 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-03 02:36:50 --> Final output sent to browser
DEBUG - 2011-06-03 02:36:50 --> Total execution time: 0.0339
DEBUG - 2011-06-03 02:36:51 --> Config Class Initialized
DEBUG - 2011-06-03 02:36:51 --> Hooks Class Initialized
DEBUG - 2011-06-03 02:36:51 --> Utf8 Class Initialized
DEBUG - 2011-06-03 02:36:51 --> UTF-8 Support Enabled
DEBUG - 2011-06-03 02:36:51 --> URI Class Initialized
DEBUG - 2011-06-03 02:36:51 --> Router Class Initialized
ERROR - 2011-06-03 02:36:51 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-03 02:36:55 --> Config Class Initialized
DEBUG - 2011-06-03 02:36:55 --> Hooks Class Initialized
DEBUG - 2011-06-03 02:36:55 --> Utf8 Class Initialized
DEBUG - 2011-06-03 02:36:55 --> UTF-8 Support Enabled
DEBUG - 2011-06-03 02:36:55 --> URI Class Initialized
DEBUG - 2011-06-03 02:36:55 --> Router Class Initialized
DEBUG - 2011-06-03 02:36:55 --> Output Class Initialized
DEBUG - 2011-06-03 02:36:55 --> Input Class Initialized
DEBUG - 2011-06-03 02:36:55 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-03 02:36:55 --> Language Class Initialized
DEBUG - 2011-06-03 02:36:55 --> Loader Class Initialized
DEBUG - 2011-06-03 02:36:55 --> Controller Class Initialized
ERROR - 2011-06-03 02:36:55 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-03 02:36:55 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-03 02:36:55 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-03 02:36:55 --> Model Class Initialized
DEBUG - 2011-06-03 02:36:55 --> Model Class Initialized
DEBUG - 2011-06-03 02:36:55 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-03 02:36:55 --> Database Driver Class Initialized
DEBUG - 2011-06-03 02:36:55 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-03 02:36:55 --> Helper loaded: url_helper
DEBUG - 2011-06-03 02:36:55 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-03 02:36:55 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-03 02:36:55 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-03 02:36:55 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-03 02:36:55 --> Final output sent to browser
DEBUG - 2011-06-03 02:36:55 --> Total execution time: 0.0296
DEBUG - 2011-06-03 02:36:57 --> Config Class Initialized
DEBUG - 2011-06-03 02:36:57 --> Hooks Class Initialized
DEBUG - 2011-06-03 02:36:57 --> Utf8 Class Initialized
DEBUG - 2011-06-03 02:36:57 --> UTF-8 Support Enabled
DEBUG - 2011-06-03 02:36:57 --> URI Class Initialized
DEBUG - 2011-06-03 02:36:57 --> Router Class Initialized
DEBUG - 2011-06-03 02:36:57 --> Output Class Initialized
DEBUG - 2011-06-03 02:36:57 --> Input Class Initialized
DEBUG - 2011-06-03 02:36:57 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-03 02:36:57 --> Language Class Initialized
DEBUG - 2011-06-03 02:36:57 --> Loader Class Initialized
DEBUG - 2011-06-03 02:36:57 --> Controller Class Initialized
DEBUG - 2011-06-03 02:36:57 --> Model Class Initialized
DEBUG - 2011-06-03 02:36:57 --> Model Class Initialized
DEBUG - 2011-06-03 02:36:57 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-03 02:36:57 --> Database Driver Class Initialized
DEBUG - 2011-06-03 02:36:59 --> Final output sent to browser
DEBUG - 2011-06-03 02:36:59 --> Total execution time: 2.0350
DEBUG - 2011-06-03 02:37:02 --> Config Class Initialized
DEBUG - 2011-06-03 02:37:02 --> Hooks Class Initialized
DEBUG - 2011-06-03 02:37:02 --> Utf8 Class Initialized
DEBUG - 2011-06-03 02:37:02 --> UTF-8 Support Enabled
DEBUG - 2011-06-03 02:37:02 --> URI Class Initialized
DEBUG - 2011-06-03 02:37:02 --> Router Class Initialized
ERROR - 2011-06-03 02:37:02 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-03 02:37:03 --> Config Class Initialized
DEBUG - 2011-06-03 02:37:03 --> Hooks Class Initialized
DEBUG - 2011-06-03 02:37:03 --> Utf8 Class Initialized
DEBUG - 2011-06-03 02:37:03 --> UTF-8 Support Enabled
DEBUG - 2011-06-03 02:37:03 --> URI Class Initialized
DEBUG - 2011-06-03 02:37:03 --> Router Class Initialized
DEBUG - 2011-06-03 02:37:03 --> Output Class Initialized
DEBUG - 2011-06-03 02:37:03 --> Input Class Initialized
DEBUG - 2011-06-03 02:37:03 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-03 02:37:03 --> Language Class Initialized
DEBUG - 2011-06-03 02:37:03 --> Loader Class Initialized
DEBUG - 2011-06-03 02:37:03 --> Controller Class Initialized
ERROR - 2011-06-03 02:37:03 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-03 02:37:03 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-03 02:37:03 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-03 02:37:03 --> Model Class Initialized
DEBUG - 2011-06-03 02:37:03 --> Model Class Initialized
DEBUG - 2011-06-03 02:37:03 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-03 02:37:03 --> Database Driver Class Initialized
DEBUG - 2011-06-03 02:37:03 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-03 02:37:03 --> Helper loaded: url_helper
DEBUG - 2011-06-03 02:37:03 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-03 02:37:03 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-03 02:37:03 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-03 02:37:03 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-03 02:37:03 --> Final output sent to browser
DEBUG - 2011-06-03 02:37:03 --> Total execution time: 0.0370
DEBUG - 2011-06-03 03:09:08 --> Config Class Initialized
DEBUG - 2011-06-03 03:09:08 --> Hooks Class Initialized
DEBUG - 2011-06-03 03:09:08 --> Utf8 Class Initialized
DEBUG - 2011-06-03 03:09:08 --> UTF-8 Support Enabled
DEBUG - 2011-06-03 03:09:08 --> URI Class Initialized
DEBUG - 2011-06-03 03:09:08 --> Router Class Initialized
DEBUG - 2011-06-03 03:09:08 --> No URI present. Default controller set.
DEBUG - 2011-06-03 03:09:08 --> Output Class Initialized
DEBUG - 2011-06-03 03:09:08 --> Input Class Initialized
DEBUG - 2011-06-03 03:09:08 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-03 03:09:08 --> Language Class Initialized
DEBUG - 2011-06-03 03:09:08 --> Loader Class Initialized
DEBUG - 2011-06-03 03:09:08 --> Controller Class Initialized
DEBUG - 2011-06-03 03:09:09 --> File loaded: application/views/splash/main.php
DEBUG - 2011-06-03 03:09:09 --> Helper loaded: url_helper
DEBUG - 2011-06-03 03:09:09 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-03 03:09:09 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-03 03:09:09 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-03 03:09:09 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-03 03:09:09 --> Final output sent to browser
DEBUG - 2011-06-03 03:09:09 --> Total execution time: 0.7017
DEBUG - 2011-06-03 05:03:52 --> Config Class Initialized
DEBUG - 2011-06-03 05:03:52 --> Hooks Class Initialized
DEBUG - 2011-06-03 05:03:52 --> Utf8 Class Initialized
DEBUG - 2011-06-03 05:03:52 --> UTF-8 Support Enabled
DEBUG - 2011-06-03 05:03:52 --> URI Class Initialized
DEBUG - 2011-06-03 05:03:52 --> Router Class Initialized
DEBUG - 2011-06-03 05:03:52 --> Output Class Initialized
DEBUG - 2011-06-03 05:03:52 --> Input Class Initialized
DEBUG - 2011-06-03 05:03:52 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-03 05:03:52 --> Language Class Initialized
DEBUG - 2011-06-03 05:03:52 --> Loader Class Initialized
DEBUG - 2011-06-03 05:03:52 --> Controller Class Initialized
DEBUG - 2011-06-03 05:03:52 --> Model Class Initialized
DEBUG - 2011-06-03 05:03:52 --> Model Class Initialized
DEBUG - 2011-06-03 05:03:52 --> Model Class Initialized
DEBUG - 2011-06-03 05:03:52 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-03 05:03:53 --> Database Driver Class Initialized
DEBUG - 2011-06-03 05:03:56 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-03 05:03:56 --> Helper loaded: url_helper
DEBUG - 2011-06-03 05:03:56 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-03 05:03:56 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-03 05:03:56 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-03 05:03:56 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-03 05:03:56 --> Final output sent to browser
DEBUG - 2011-06-03 05:03:56 --> Total execution time: 3.2760
DEBUG - 2011-06-03 05:03:58 --> Config Class Initialized
DEBUG - 2011-06-03 05:03:58 --> Hooks Class Initialized
DEBUG - 2011-06-03 05:03:58 --> Utf8 Class Initialized
DEBUG - 2011-06-03 05:03:58 --> UTF-8 Support Enabled
DEBUG - 2011-06-03 05:03:58 --> URI Class Initialized
DEBUG - 2011-06-03 05:03:58 --> Router Class Initialized
DEBUG - 2011-06-03 05:03:58 --> Output Class Initialized
DEBUG - 2011-06-03 05:03:58 --> Input Class Initialized
DEBUG - 2011-06-03 05:03:58 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-03 05:03:58 --> Language Class Initialized
DEBUG - 2011-06-03 05:03:58 --> Loader Class Initialized
DEBUG - 2011-06-03 05:03:58 --> Controller Class Initialized
ERROR - 2011-06-03 05:03:58 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-03 05:03:58 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-03 05:03:58 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-03 05:03:58 --> Model Class Initialized
DEBUG - 2011-06-03 05:03:58 --> Model Class Initialized
DEBUG - 2011-06-03 05:03:58 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-03 05:03:58 --> Database Driver Class Initialized
DEBUG - 2011-06-03 05:03:58 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-03 05:03:58 --> Helper loaded: url_helper
DEBUG - 2011-06-03 05:03:58 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-03 05:03:58 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-03 05:03:58 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-03 05:03:58 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-03 05:03:58 --> Final output sent to browser
DEBUG - 2011-06-03 05:03:58 --> Total execution time: 0.0892
DEBUG - 2011-06-03 05:53:31 --> Config Class Initialized
DEBUG - 2011-06-03 05:53:31 --> Hooks Class Initialized
DEBUG - 2011-06-03 05:53:32 --> Utf8 Class Initialized
DEBUG - 2011-06-03 05:53:32 --> UTF-8 Support Enabled
DEBUG - 2011-06-03 05:53:33 --> URI Class Initialized
DEBUG - 2011-06-03 05:53:33 --> Router Class Initialized
DEBUG - 2011-06-03 05:53:35 --> Output Class Initialized
DEBUG - 2011-06-03 05:53:35 --> Input Class Initialized
DEBUG - 2011-06-03 05:53:35 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-03 05:53:35 --> Language Class Initialized
DEBUG - 2011-06-03 05:53:35 --> Loader Class Initialized
DEBUG - 2011-06-03 05:53:35 --> Controller Class Initialized
DEBUG - 2011-06-03 05:53:35 --> Model Class Initialized
DEBUG - 2011-06-03 05:53:35 --> Model Class Initialized
DEBUG - 2011-06-03 05:53:36 --> Model Class Initialized
DEBUG - 2011-06-03 05:53:36 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-03 05:53:36 --> Database Driver Class Initialized
DEBUG - 2011-06-03 05:53:49 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-03 05:53:49 --> Helper loaded: url_helper
DEBUG - 2011-06-03 05:53:49 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-03 05:53:49 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-03 05:53:49 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-03 05:53:49 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-03 05:53:49 --> Final output sent to browser
DEBUG - 2011-06-03 05:53:49 --> Total execution time: 17.5945
DEBUG - 2011-06-03 05:53:50 --> Config Class Initialized
DEBUG - 2011-06-03 05:53:50 --> Hooks Class Initialized
DEBUG - 2011-06-03 05:53:50 --> Utf8 Class Initialized
DEBUG - 2011-06-03 05:53:50 --> UTF-8 Support Enabled
DEBUG - 2011-06-03 05:53:50 --> URI Class Initialized
DEBUG - 2011-06-03 05:53:50 --> Router Class Initialized
ERROR - 2011-06-03 05:53:50 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-03 05:53:52 --> Config Class Initialized
DEBUG - 2011-06-03 05:53:52 --> Hooks Class Initialized
DEBUG - 2011-06-03 05:53:52 --> Utf8 Class Initialized
DEBUG - 2011-06-03 05:53:52 --> UTF-8 Support Enabled
DEBUG - 2011-06-03 05:53:52 --> URI Class Initialized
DEBUG - 2011-06-03 05:53:52 --> Router Class Initialized
ERROR - 2011-06-03 05:53:52 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-03 05:53:53 --> Config Class Initialized
DEBUG - 2011-06-03 05:53:53 --> Hooks Class Initialized
DEBUG - 2011-06-03 05:53:53 --> Utf8 Class Initialized
DEBUG - 2011-06-03 05:53:53 --> UTF-8 Support Enabled
DEBUG - 2011-06-03 05:53:53 --> URI Class Initialized
DEBUG - 2011-06-03 05:53:53 --> Router Class Initialized
ERROR - 2011-06-03 05:53:53 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-03 06:25:26 --> Config Class Initialized
DEBUG - 2011-06-03 06:25:26 --> Hooks Class Initialized
DEBUG - 2011-06-03 06:25:26 --> Utf8 Class Initialized
DEBUG - 2011-06-03 06:25:26 --> UTF-8 Support Enabled
DEBUG - 2011-06-03 06:25:26 --> URI Class Initialized
DEBUG - 2011-06-03 06:25:26 --> Router Class Initialized
DEBUG - 2011-06-03 06:25:26 --> No URI present. Default controller set.
DEBUG - 2011-06-03 06:25:26 --> Output Class Initialized
DEBUG - 2011-06-03 06:25:26 --> Input Class Initialized
DEBUG - 2011-06-03 06:25:26 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-03 06:25:26 --> Language Class Initialized
DEBUG - 2011-06-03 06:25:26 --> Loader Class Initialized
DEBUG - 2011-06-03 06:25:26 --> Controller Class Initialized
DEBUG - 2011-06-03 06:25:26 --> File loaded: application/views/splash/main.php
DEBUG - 2011-06-03 06:25:26 --> Helper loaded: url_helper
DEBUG - 2011-06-03 06:25:26 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-03 06:25:26 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-03 06:25:26 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-03 06:25:26 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-03 06:25:26 --> Final output sent to browser
DEBUG - 2011-06-03 06:25:26 --> Total execution time: 0.7934
DEBUG - 2011-06-03 07:54:30 --> Config Class Initialized
DEBUG - 2011-06-03 07:54:30 --> Hooks Class Initialized
DEBUG - 2011-06-03 07:54:30 --> Utf8 Class Initialized
DEBUG - 2011-06-03 07:54:30 --> UTF-8 Support Enabled
DEBUG - 2011-06-03 07:54:30 --> URI Class Initialized
DEBUG - 2011-06-03 07:54:30 --> Router Class Initialized
DEBUG - 2011-06-03 07:54:30 --> Output Class Initialized
DEBUG - 2011-06-03 07:54:30 --> Input Class Initialized
DEBUG - 2011-06-03 07:54:30 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-03 07:54:30 --> Language Class Initialized
DEBUG - 2011-06-03 07:54:30 --> Loader Class Initialized
DEBUG - 2011-06-03 07:54:30 --> Controller Class Initialized
DEBUG - 2011-06-03 07:54:30 --> Model Class Initialized
DEBUG - 2011-06-03 07:54:30 --> Model Class Initialized
DEBUG - 2011-06-03 07:54:30 --> Model Class Initialized
DEBUG - 2011-06-03 07:54:30 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-03 07:54:30 --> Database Driver Class Initialized
DEBUG - 2011-06-03 07:54:31 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-03 07:54:31 --> Helper loaded: url_helper
DEBUG - 2011-06-03 07:54:31 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-03 07:54:31 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-03 07:54:31 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-03 07:54:31 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-03 07:54:31 --> Final output sent to browser
DEBUG - 2011-06-03 07:54:31 --> Total execution time: 1.1785
DEBUG - 2011-06-03 07:54:37 --> Config Class Initialized
DEBUG - 2011-06-03 07:54:37 --> Hooks Class Initialized
DEBUG - 2011-06-03 07:54:37 --> Utf8 Class Initialized
DEBUG - 2011-06-03 07:54:37 --> UTF-8 Support Enabled
DEBUG - 2011-06-03 07:54:37 --> URI Class Initialized
DEBUG - 2011-06-03 07:54:37 --> Router Class Initialized
ERROR - 2011-06-03 07:54:37 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-03 07:54:38 --> Config Class Initialized
DEBUG - 2011-06-03 07:54:38 --> Hooks Class Initialized
DEBUG - 2011-06-03 07:54:38 --> Utf8 Class Initialized
DEBUG - 2011-06-03 07:54:38 --> UTF-8 Support Enabled
DEBUG - 2011-06-03 07:54:38 --> URI Class Initialized
DEBUG - 2011-06-03 07:54:38 --> Router Class Initialized
ERROR - 2011-06-03 07:54:38 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-03 07:54:39 --> Config Class Initialized
DEBUG - 2011-06-03 07:54:39 --> Hooks Class Initialized
DEBUG - 2011-06-03 07:54:39 --> Utf8 Class Initialized
DEBUG - 2011-06-03 07:54:39 --> UTF-8 Support Enabled
DEBUG - 2011-06-03 07:54:39 --> URI Class Initialized
DEBUG - 2011-06-03 07:54:39 --> Router Class Initialized
ERROR - 2011-06-03 07:54:39 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-03 10:39:56 --> Config Class Initialized
DEBUG - 2011-06-03 10:39:56 --> Hooks Class Initialized
DEBUG - 2011-06-03 10:39:56 --> Utf8 Class Initialized
DEBUG - 2011-06-03 10:39:56 --> UTF-8 Support Enabled
DEBUG - 2011-06-03 10:39:56 --> URI Class Initialized
DEBUG - 2011-06-03 10:39:56 --> Router Class Initialized
DEBUG - 2011-06-03 10:39:57 --> Output Class Initialized
DEBUG - 2011-06-03 10:39:57 --> Input Class Initialized
DEBUG - 2011-06-03 10:39:57 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-03 10:39:57 --> Language Class Initialized
DEBUG - 2011-06-03 10:39:57 --> Loader Class Initialized
DEBUG - 2011-06-03 10:39:57 --> Controller Class Initialized
DEBUG - 2011-06-03 10:39:57 --> Model Class Initialized
DEBUG - 2011-06-03 10:39:57 --> Model Class Initialized
DEBUG - 2011-06-03 10:39:57 --> Model Class Initialized
DEBUG - 2011-06-03 10:39:57 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-03 10:39:57 --> Database Driver Class Initialized
DEBUG - 2011-06-03 10:39:57 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-03 10:39:57 --> Helper loaded: url_helper
DEBUG - 2011-06-03 10:39:57 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-03 10:39:57 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-03 10:39:57 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-03 10:39:57 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-03 10:39:57 --> Final output sent to browser
DEBUG - 2011-06-03 10:39:57 --> Total execution time: 1.0461
DEBUG - 2011-06-03 10:40:02 --> Config Class Initialized
DEBUG - 2011-06-03 10:40:02 --> Hooks Class Initialized
DEBUG - 2011-06-03 10:40:02 --> Utf8 Class Initialized
DEBUG - 2011-06-03 10:40:02 --> UTF-8 Support Enabled
DEBUG - 2011-06-03 10:40:02 --> URI Class Initialized
DEBUG - 2011-06-03 10:40:02 --> Router Class Initialized
DEBUG - 2011-06-03 10:40:02 --> Output Class Initialized
DEBUG - 2011-06-03 10:40:02 --> Input Class Initialized
DEBUG - 2011-06-03 10:40:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-03 10:40:02 --> Language Class Initialized
DEBUG - 2011-06-03 10:40:02 --> Loader Class Initialized
DEBUG - 2011-06-03 10:40:02 --> Controller Class Initialized
ERROR - 2011-06-03 10:40:02 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-03 10:40:02 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-03 10:40:02 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-03 10:40:02 --> Model Class Initialized
DEBUG - 2011-06-03 10:40:02 --> Model Class Initialized
DEBUG - 2011-06-03 10:40:02 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-03 10:40:02 --> Database Driver Class Initialized
DEBUG - 2011-06-03 10:40:02 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-03 10:40:02 --> Helper loaded: url_helper
DEBUG - 2011-06-03 10:40:02 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-03 10:40:02 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-03 10:40:02 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-03 10:40:02 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-03 10:40:02 --> Final output sent to browser
DEBUG - 2011-06-03 10:40:02 --> Total execution time: 0.1985
DEBUG - 2011-06-03 11:59:43 --> Config Class Initialized
DEBUG - 2011-06-03 11:59:43 --> Hooks Class Initialized
DEBUG - 2011-06-03 11:59:43 --> Utf8 Class Initialized
DEBUG - 2011-06-03 11:59:43 --> UTF-8 Support Enabled
DEBUG - 2011-06-03 11:59:43 --> URI Class Initialized
DEBUG - 2011-06-03 11:59:43 --> Router Class Initialized
ERROR - 2011-06-03 11:59:43 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-06-03 11:59:43 --> Config Class Initialized
DEBUG - 2011-06-03 11:59:43 --> Hooks Class Initialized
DEBUG - 2011-06-03 11:59:43 --> Utf8 Class Initialized
DEBUG - 2011-06-03 11:59:43 --> UTF-8 Support Enabled
DEBUG - 2011-06-03 11:59:43 --> URI Class Initialized
DEBUG - 2011-06-03 11:59:43 --> Router Class Initialized
DEBUG - 2011-06-03 11:59:43 --> Output Class Initialized
DEBUG - 2011-06-03 11:59:43 --> Input Class Initialized
DEBUG - 2011-06-03 11:59:43 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-03 11:59:43 --> Language Class Initialized
DEBUG - 2011-06-03 11:59:43 --> Loader Class Initialized
DEBUG - 2011-06-03 11:59:43 --> Controller Class Initialized
DEBUG - 2011-06-03 11:59:43 --> Model Class Initialized
DEBUG - 2011-06-03 11:59:43 --> Model Class Initialized
DEBUG - 2011-06-03 11:59:43 --> Model Class Initialized
DEBUG - 2011-06-03 11:59:43 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-03 11:59:43 --> Database Driver Class Initialized
DEBUG - 2011-06-03 11:59:44 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-03 11:59:44 --> Helper loaded: url_helper
DEBUG - 2011-06-03 11:59:44 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-03 11:59:44 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-03 11:59:44 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-03 11:59:44 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-03 11:59:44 --> Final output sent to browser
DEBUG - 2011-06-03 11:59:44 --> Total execution time: 0.4938
DEBUG - 2011-06-03 12:00:14 --> Config Class Initialized
DEBUG - 2011-06-03 12:00:14 --> Hooks Class Initialized
DEBUG - 2011-06-03 12:00:14 --> Utf8 Class Initialized
DEBUG - 2011-06-03 12:00:14 --> UTF-8 Support Enabled
DEBUG - 2011-06-03 12:00:14 --> URI Class Initialized
DEBUG - 2011-06-03 12:00:14 --> Router Class Initialized
DEBUG - 2011-06-03 12:00:14 --> Output Class Initialized
DEBUG - 2011-06-03 12:00:14 --> Input Class Initialized
DEBUG - 2011-06-03 12:00:14 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-03 12:00:14 --> Language Class Initialized
DEBUG - 2011-06-03 12:00:15 --> Loader Class Initialized
DEBUG - 2011-06-03 12:00:15 --> Controller Class Initialized
ERROR - 2011-06-03 12:00:15 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-03 12:00:15 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-03 12:00:15 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-03 12:00:15 --> Model Class Initialized
DEBUG - 2011-06-03 12:00:15 --> Model Class Initialized
DEBUG - 2011-06-03 12:00:15 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-03 12:00:15 --> Database Driver Class Initialized
DEBUG - 2011-06-03 12:00:15 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-03 12:00:15 --> Helper loaded: url_helper
DEBUG - 2011-06-03 12:00:15 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-03 12:00:15 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-03 12:00:15 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-03 12:00:15 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-03 12:00:15 --> Final output sent to browser
DEBUG - 2011-06-03 12:00:15 --> Total execution time: 0.9097
DEBUG - 2011-06-03 12:35:49 --> Config Class Initialized
DEBUG - 2011-06-03 12:35:49 --> Hooks Class Initialized
DEBUG - 2011-06-03 12:35:49 --> Utf8 Class Initialized
DEBUG - 2011-06-03 12:35:49 --> UTF-8 Support Enabled
DEBUG - 2011-06-03 12:35:49 --> URI Class Initialized
DEBUG - 2011-06-03 12:35:49 --> Router Class Initialized
DEBUG - 2011-06-03 12:35:49 --> Output Class Initialized
DEBUG - 2011-06-03 12:35:49 --> Input Class Initialized
DEBUG - 2011-06-03 12:35:49 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-03 12:35:49 --> Language Class Initialized
DEBUG - 2011-06-03 12:35:49 --> Loader Class Initialized
DEBUG - 2011-06-03 12:35:49 --> Controller Class Initialized
ERROR - 2011-06-03 12:35:49 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-03 12:35:49 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-03 12:35:49 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-03 12:35:49 --> Model Class Initialized
DEBUG - 2011-06-03 12:35:49 --> Model Class Initialized
DEBUG - 2011-06-03 12:35:49 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-03 12:35:49 --> Database Driver Class Initialized
DEBUG - 2011-06-03 12:35:49 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-03 12:35:49 --> Helper loaded: url_helper
DEBUG - 2011-06-03 12:35:49 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-03 12:35:49 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-03 12:35:49 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-03 12:35:49 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-03 12:35:49 --> Final output sent to browser
DEBUG - 2011-06-03 12:35:49 --> Total execution time: 0.3950
DEBUG - 2011-06-03 12:35:50 --> Config Class Initialized
DEBUG - 2011-06-03 12:35:50 --> Hooks Class Initialized
DEBUG - 2011-06-03 12:35:50 --> Utf8 Class Initialized
DEBUG - 2011-06-03 12:35:50 --> UTF-8 Support Enabled
DEBUG - 2011-06-03 12:35:50 --> URI Class Initialized
DEBUG - 2011-06-03 12:35:50 --> Router Class Initialized
DEBUG - 2011-06-03 12:35:50 --> Output Class Initialized
DEBUG - 2011-06-03 12:35:50 --> Input Class Initialized
DEBUG - 2011-06-03 12:35:50 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-03 12:35:50 --> Language Class Initialized
DEBUG - 2011-06-03 12:35:50 --> Loader Class Initialized
DEBUG - 2011-06-03 12:35:50 --> Controller Class Initialized
DEBUG - 2011-06-03 12:35:50 --> Model Class Initialized
DEBUG - 2011-06-03 12:35:50 --> Model Class Initialized
DEBUG - 2011-06-03 12:35:50 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-03 12:35:50 --> Database Driver Class Initialized
DEBUG - 2011-06-03 12:35:50 --> Final output sent to browser
DEBUG - 2011-06-03 12:35:50 --> Total execution time: 0.7230
DEBUG - 2011-06-03 12:35:52 --> Config Class Initialized
DEBUG - 2011-06-03 12:35:52 --> Hooks Class Initialized
DEBUG - 2011-06-03 12:35:52 --> Utf8 Class Initialized
DEBUG - 2011-06-03 12:35:52 --> UTF-8 Support Enabled
DEBUG - 2011-06-03 12:35:52 --> URI Class Initialized
DEBUG - 2011-06-03 12:35:52 --> Router Class Initialized
ERROR - 2011-06-03 12:35:52 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-03 12:35:52 --> Config Class Initialized
DEBUG - 2011-06-03 12:35:52 --> Hooks Class Initialized
DEBUG - 2011-06-03 12:35:52 --> Utf8 Class Initialized
DEBUG - 2011-06-03 12:35:52 --> UTF-8 Support Enabled
DEBUG - 2011-06-03 12:35:52 --> URI Class Initialized
DEBUG - 2011-06-03 12:35:52 --> Router Class Initialized
ERROR - 2011-06-03 12:35:52 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-03 12:35:57 --> Config Class Initialized
DEBUG - 2011-06-03 12:35:57 --> Hooks Class Initialized
DEBUG - 2011-06-03 12:35:57 --> Utf8 Class Initialized
DEBUG - 2011-06-03 12:35:57 --> UTF-8 Support Enabled
DEBUG - 2011-06-03 12:35:57 --> URI Class Initialized
DEBUG - 2011-06-03 12:35:57 --> Router Class Initialized
DEBUG - 2011-06-03 12:35:57 --> Output Class Initialized
DEBUG - 2011-06-03 12:35:57 --> Input Class Initialized
DEBUG - 2011-06-03 12:35:57 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-03 12:35:57 --> Language Class Initialized
DEBUG - 2011-06-03 12:35:57 --> Loader Class Initialized
DEBUG - 2011-06-03 12:35:57 --> Controller Class Initialized
ERROR - 2011-06-03 12:35:57 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-03 12:35:57 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-03 12:35:57 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-03 12:35:57 --> Model Class Initialized
DEBUG - 2011-06-03 12:35:57 --> Model Class Initialized
DEBUG - 2011-06-03 12:35:57 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-03 12:35:57 --> Database Driver Class Initialized
DEBUG - 2011-06-03 12:35:57 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-03 12:35:57 --> Helper loaded: url_helper
DEBUG - 2011-06-03 12:35:57 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-03 12:35:57 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-03 12:35:57 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-03 12:35:57 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-03 12:35:57 --> Final output sent to browser
DEBUG - 2011-06-03 12:35:57 --> Total execution time: 0.0697
DEBUG - 2011-06-03 12:35:58 --> Config Class Initialized
DEBUG - 2011-06-03 12:35:58 --> Hooks Class Initialized
DEBUG - 2011-06-03 12:35:58 --> Utf8 Class Initialized
DEBUG - 2011-06-03 12:35:58 --> UTF-8 Support Enabled
DEBUG - 2011-06-03 12:35:58 --> URI Class Initialized
DEBUG - 2011-06-03 12:35:58 --> Router Class Initialized
DEBUG - 2011-06-03 12:35:58 --> Output Class Initialized
DEBUG - 2011-06-03 12:35:58 --> Input Class Initialized
DEBUG - 2011-06-03 12:35:58 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-03 12:35:58 --> Language Class Initialized
DEBUG - 2011-06-03 12:35:58 --> Loader Class Initialized
DEBUG - 2011-06-03 12:35:58 --> Controller Class Initialized
DEBUG - 2011-06-03 12:35:58 --> Model Class Initialized
DEBUG - 2011-06-03 12:35:58 --> Model Class Initialized
DEBUG - 2011-06-03 12:35:58 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-03 12:35:58 --> Database Driver Class Initialized
DEBUG - 2011-06-03 12:35:59 --> Final output sent to browser
DEBUG - 2011-06-03 12:35:59 --> Total execution time: 0.8493
DEBUG - 2011-06-03 12:36:14 --> Config Class Initialized
DEBUG - 2011-06-03 12:36:14 --> Hooks Class Initialized
DEBUG - 2011-06-03 12:36:14 --> Utf8 Class Initialized
DEBUG - 2011-06-03 12:36:14 --> UTF-8 Support Enabled
DEBUG - 2011-06-03 12:36:14 --> URI Class Initialized
DEBUG - 2011-06-03 12:36:14 --> Router Class Initialized
DEBUG - 2011-06-03 12:36:14 --> Output Class Initialized
DEBUG - 2011-06-03 12:36:14 --> Input Class Initialized
DEBUG - 2011-06-03 12:36:14 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-03 12:36:14 --> Language Class Initialized
DEBUG - 2011-06-03 12:36:14 --> Loader Class Initialized
DEBUG - 2011-06-03 12:36:14 --> Controller Class Initialized
ERROR - 2011-06-03 12:36:14 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-03 12:36:14 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-03 12:36:14 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-03 12:36:14 --> Model Class Initialized
DEBUG - 2011-06-03 12:36:14 --> Model Class Initialized
DEBUG - 2011-06-03 12:36:14 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-03 12:36:14 --> Database Driver Class Initialized
DEBUG - 2011-06-03 12:36:14 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-03 12:36:14 --> Helper loaded: url_helper
DEBUG - 2011-06-03 12:36:14 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-03 12:36:14 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-03 12:36:14 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-03 12:36:14 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-03 12:36:14 --> Final output sent to browser
DEBUG - 2011-06-03 12:36:14 --> Total execution time: 0.0768
DEBUG - 2011-06-03 12:36:15 --> Config Class Initialized
DEBUG - 2011-06-03 12:36:15 --> Hooks Class Initialized
DEBUG - 2011-06-03 12:36:15 --> Utf8 Class Initialized
DEBUG - 2011-06-03 12:36:15 --> UTF-8 Support Enabled
DEBUG - 2011-06-03 12:36:15 --> URI Class Initialized
DEBUG - 2011-06-03 12:36:15 --> Router Class Initialized
DEBUG - 2011-06-03 12:36:15 --> Output Class Initialized
DEBUG - 2011-06-03 12:36:15 --> Input Class Initialized
DEBUG - 2011-06-03 12:36:15 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-03 12:36:15 --> Language Class Initialized
DEBUG - 2011-06-03 12:36:15 --> Loader Class Initialized
DEBUG - 2011-06-03 12:36:15 --> Controller Class Initialized
DEBUG - 2011-06-03 12:36:15 --> Model Class Initialized
DEBUG - 2011-06-03 12:36:15 --> Model Class Initialized
DEBUG - 2011-06-03 12:36:15 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-03 12:36:15 --> Database Driver Class Initialized
DEBUG - 2011-06-03 12:36:16 --> Config Class Initialized
DEBUG - 2011-06-03 12:36:16 --> Hooks Class Initialized
DEBUG - 2011-06-03 12:36:16 --> Utf8 Class Initialized
DEBUG - 2011-06-03 12:36:16 --> UTF-8 Support Enabled
DEBUG - 2011-06-03 12:36:16 --> URI Class Initialized
DEBUG - 2011-06-03 12:36:16 --> Router Class Initialized
ERROR - 2011-06-03 12:36:16 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-06-03 12:36:16 --> Config Class Initialized
DEBUG - 2011-06-03 12:36:16 --> Hooks Class Initialized
DEBUG - 2011-06-03 12:36:16 --> Utf8 Class Initialized
DEBUG - 2011-06-03 12:36:16 --> UTF-8 Support Enabled
DEBUG - 2011-06-03 12:36:16 --> URI Class Initialized
DEBUG - 2011-06-03 12:36:16 --> Router Class Initialized
DEBUG - 2011-06-03 12:36:16 --> Output Class Initialized
DEBUG - 2011-06-03 12:36:16 --> Input Class Initialized
DEBUG - 2011-06-03 12:36:16 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-03 12:36:16 --> Language Class Initialized
DEBUG - 2011-06-03 12:36:16 --> Loader Class Initialized
DEBUG - 2011-06-03 12:36:16 --> Controller Class Initialized
ERROR - 2011-06-03 12:36:16 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-03 12:36:16 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-03 12:36:16 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-03 12:36:16 --> Model Class Initialized
DEBUG - 2011-06-03 12:36:16 --> Model Class Initialized
DEBUG - 2011-06-03 12:36:16 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-03 12:36:16 --> Database Driver Class Initialized
DEBUG - 2011-06-03 12:36:16 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-03 12:36:16 --> Helper loaded: url_helper
DEBUG - 2011-06-03 12:36:16 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-03 12:36:16 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-03 12:36:16 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-03 12:36:16 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-03 12:36:16 --> Final output sent to browser
DEBUG - 2011-06-03 12:36:16 --> Total execution time: 0.0410
DEBUG - 2011-06-03 12:36:17 --> Final output sent to browser
DEBUG - 2011-06-03 12:36:17 --> Total execution time: 1.8971
DEBUG - 2011-06-03 12:36:25 --> Config Class Initialized
DEBUG - 2011-06-03 12:36:25 --> Hooks Class Initialized
DEBUG - 2011-06-03 12:36:25 --> Utf8 Class Initialized
DEBUG - 2011-06-03 12:36:25 --> UTF-8 Support Enabled
DEBUG - 2011-06-03 12:36:25 --> URI Class Initialized
DEBUG - 2011-06-03 12:36:25 --> Router Class Initialized
DEBUG - 2011-06-03 12:36:25 --> Output Class Initialized
DEBUG - 2011-06-03 12:36:25 --> Input Class Initialized
DEBUG - 2011-06-03 12:36:25 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-03 12:36:25 --> Language Class Initialized
DEBUG - 2011-06-03 12:36:25 --> Loader Class Initialized
DEBUG - 2011-06-03 12:36:25 --> Controller Class Initialized
ERROR - 2011-06-03 12:36:25 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-03 12:36:25 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-03 12:36:25 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-03 12:36:25 --> Model Class Initialized
DEBUG - 2011-06-03 12:36:25 --> Model Class Initialized
DEBUG - 2011-06-03 12:36:25 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-03 12:36:25 --> Database Driver Class Initialized
DEBUG - 2011-06-03 12:36:25 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-03 12:36:25 --> Helper loaded: url_helper
DEBUG - 2011-06-03 12:36:25 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-03 12:36:25 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-03 12:36:25 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-03 12:36:25 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-03 12:36:25 --> Final output sent to browser
DEBUG - 2011-06-03 12:36:25 --> Total execution time: 0.0407
DEBUG - 2011-06-03 12:36:26 --> Config Class Initialized
DEBUG - 2011-06-03 12:36:26 --> Hooks Class Initialized
DEBUG - 2011-06-03 12:36:26 --> Utf8 Class Initialized
DEBUG - 2011-06-03 12:36:26 --> UTF-8 Support Enabled
DEBUG - 2011-06-03 12:36:26 --> URI Class Initialized
DEBUG - 2011-06-03 12:36:26 --> Router Class Initialized
DEBUG - 2011-06-03 12:36:26 --> Output Class Initialized
DEBUG - 2011-06-03 12:36:26 --> Input Class Initialized
DEBUG - 2011-06-03 12:36:26 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-03 12:36:26 --> Language Class Initialized
DEBUG - 2011-06-03 12:36:26 --> Loader Class Initialized
DEBUG - 2011-06-03 12:36:26 --> Controller Class Initialized
DEBUG - 2011-06-03 12:36:26 --> Model Class Initialized
DEBUG - 2011-06-03 12:36:26 --> Model Class Initialized
DEBUG - 2011-06-03 12:36:26 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-03 12:36:26 --> Database Driver Class Initialized
DEBUG - 2011-06-03 12:36:27 --> Final output sent to browser
DEBUG - 2011-06-03 12:36:27 --> Total execution time: 0.8291
DEBUG - 2011-06-03 12:36:27 --> Config Class Initialized
DEBUG - 2011-06-03 12:36:27 --> Hooks Class Initialized
DEBUG - 2011-06-03 12:36:27 --> Utf8 Class Initialized
DEBUG - 2011-06-03 12:36:27 --> UTF-8 Support Enabled
DEBUG - 2011-06-03 12:36:27 --> URI Class Initialized
DEBUG - 2011-06-03 12:36:27 --> Router Class Initialized
DEBUG - 2011-06-03 12:36:27 --> Output Class Initialized
DEBUG - 2011-06-03 12:36:27 --> Input Class Initialized
DEBUG - 2011-06-03 12:36:27 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-03 12:36:27 --> Language Class Initialized
DEBUG - 2011-06-03 12:36:27 --> Loader Class Initialized
DEBUG - 2011-06-03 12:36:27 --> Controller Class Initialized
ERROR - 2011-06-03 12:36:27 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-03 12:36:27 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-03 12:36:27 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-03 12:36:27 --> Model Class Initialized
DEBUG - 2011-06-03 12:36:27 --> Model Class Initialized
DEBUG - 2011-06-03 12:36:27 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-03 12:36:27 --> Database Driver Class Initialized
DEBUG - 2011-06-03 12:36:27 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-03 12:36:27 --> Helper loaded: url_helper
DEBUG - 2011-06-03 12:36:27 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-03 12:36:27 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-03 12:36:27 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-03 12:36:27 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-03 12:36:27 --> Final output sent to browser
DEBUG - 2011-06-03 12:36:27 --> Total execution time: 0.0380
DEBUG - 2011-06-03 12:36:27 --> Config Class Initialized
DEBUG - 2011-06-03 12:36:27 --> Hooks Class Initialized
DEBUG - 2011-06-03 12:36:27 --> Utf8 Class Initialized
DEBUG - 2011-06-03 12:36:27 --> UTF-8 Support Enabled
DEBUG - 2011-06-03 12:36:27 --> URI Class Initialized
DEBUG - 2011-06-03 12:36:27 --> Router Class Initialized
DEBUG - 2011-06-03 12:36:27 --> Output Class Initialized
DEBUG - 2011-06-03 12:36:27 --> Input Class Initialized
DEBUG - 2011-06-03 12:36:27 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-03 12:36:27 --> Language Class Initialized
DEBUG - 2011-06-03 12:36:27 --> Loader Class Initialized
DEBUG - 2011-06-03 12:36:27 --> Controller Class Initialized
ERROR - 2011-06-03 12:36:27 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-03 12:36:27 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-03 12:36:27 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-03 12:36:27 --> Model Class Initialized
DEBUG - 2011-06-03 12:36:27 --> Model Class Initialized
DEBUG - 2011-06-03 12:36:27 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-03 12:36:27 --> Database Driver Class Initialized
DEBUG - 2011-06-03 12:36:27 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-03 12:36:27 --> Helper loaded: url_helper
DEBUG - 2011-06-03 12:36:27 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-03 12:36:27 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-03 12:36:27 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-03 12:36:27 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-03 12:36:27 --> Final output sent to browser
DEBUG - 2011-06-03 12:36:27 --> Total execution time: 0.0517
DEBUG - 2011-06-03 12:36:35 --> Config Class Initialized
DEBUG - 2011-06-03 12:36:35 --> Hooks Class Initialized
DEBUG - 2011-06-03 12:36:35 --> Utf8 Class Initialized
DEBUG - 2011-06-03 12:36:35 --> UTF-8 Support Enabled
DEBUG - 2011-06-03 12:36:35 --> URI Class Initialized
DEBUG - 2011-06-03 12:36:35 --> Router Class Initialized
DEBUG - 2011-06-03 12:36:35 --> Output Class Initialized
DEBUG - 2011-06-03 12:36:35 --> Input Class Initialized
DEBUG - 2011-06-03 12:36:35 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-03 12:36:35 --> Language Class Initialized
DEBUG - 2011-06-03 12:36:35 --> Loader Class Initialized
DEBUG - 2011-06-03 12:36:35 --> Controller Class Initialized
ERROR - 2011-06-03 12:36:35 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-03 12:36:35 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-03 12:36:35 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-03 12:36:35 --> Model Class Initialized
DEBUG - 2011-06-03 12:36:35 --> Model Class Initialized
DEBUG - 2011-06-03 12:36:35 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-03 12:36:35 --> Database Driver Class Initialized
DEBUG - 2011-06-03 12:36:35 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-03 12:36:35 --> Helper loaded: url_helper
DEBUG - 2011-06-03 12:36:35 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-03 12:36:35 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-03 12:36:35 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-03 12:36:35 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-03 12:36:35 --> Final output sent to browser
DEBUG - 2011-06-03 12:36:35 --> Total execution time: 0.0293
DEBUG - 2011-06-03 12:36:35 --> Config Class Initialized
DEBUG - 2011-06-03 12:36:35 --> Hooks Class Initialized
DEBUG - 2011-06-03 12:36:35 --> Utf8 Class Initialized
DEBUG - 2011-06-03 12:36:35 --> UTF-8 Support Enabled
DEBUG - 2011-06-03 12:36:35 --> URI Class Initialized
DEBUG - 2011-06-03 12:36:35 --> Router Class Initialized
DEBUG - 2011-06-03 12:36:35 --> Output Class Initialized
DEBUG - 2011-06-03 12:36:35 --> Input Class Initialized
DEBUG - 2011-06-03 12:36:35 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-03 12:36:35 --> Language Class Initialized
DEBUG - 2011-06-03 12:36:35 --> Loader Class Initialized
DEBUG - 2011-06-03 12:36:35 --> Controller Class Initialized
DEBUG - 2011-06-03 12:36:35 --> Model Class Initialized
DEBUG - 2011-06-03 12:36:35 --> Model Class Initialized
DEBUG - 2011-06-03 12:36:35 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-03 12:36:35 --> Database Driver Class Initialized
DEBUG - 2011-06-03 12:36:36 --> Config Class Initialized
DEBUG - 2011-06-03 12:36:36 --> Hooks Class Initialized
DEBUG - 2011-06-03 12:36:36 --> Utf8 Class Initialized
DEBUG - 2011-06-03 12:36:36 --> UTF-8 Support Enabled
DEBUG - 2011-06-03 12:36:36 --> URI Class Initialized
DEBUG - 2011-06-03 12:36:36 --> Router Class Initialized
DEBUG - 2011-06-03 12:36:36 --> Output Class Initialized
DEBUG - 2011-06-03 12:36:36 --> Input Class Initialized
DEBUG - 2011-06-03 12:36:36 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-03 12:36:36 --> Language Class Initialized
DEBUG - 2011-06-03 12:36:36 --> Loader Class Initialized
DEBUG - 2011-06-03 12:36:36 --> Controller Class Initialized
ERROR - 2011-06-03 12:36:36 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-03 12:36:36 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-03 12:36:36 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-03 12:36:36 --> Model Class Initialized
DEBUG - 2011-06-03 12:36:36 --> Model Class Initialized
DEBUG - 2011-06-03 12:36:36 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-03 12:36:36 --> Database Driver Class Initialized
DEBUG - 2011-06-03 12:36:36 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-03 12:36:36 --> Helper loaded: url_helper
DEBUG - 2011-06-03 12:36:36 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-03 12:36:36 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-03 12:36:36 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-03 12:36:36 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-03 12:36:36 --> Final output sent to browser
DEBUG - 2011-06-03 12:36:36 --> Total execution time: 0.0275
DEBUG - 2011-06-03 12:36:36 --> Final output sent to browser
DEBUG - 2011-06-03 12:36:36 --> Total execution time: 0.5599
DEBUG - 2011-06-03 12:36:36 --> Config Class Initialized
DEBUG - 2011-06-03 12:36:36 --> Hooks Class Initialized
DEBUG - 2011-06-03 12:36:36 --> Utf8 Class Initialized
DEBUG - 2011-06-03 12:36:36 --> UTF-8 Support Enabled
DEBUG - 2011-06-03 12:36:36 --> URI Class Initialized
DEBUG - 2011-06-03 12:36:36 --> Router Class Initialized
DEBUG - 2011-06-03 12:36:36 --> Output Class Initialized
DEBUG - 2011-06-03 12:36:36 --> Input Class Initialized
DEBUG - 2011-06-03 12:36:36 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-03 12:36:36 --> Language Class Initialized
DEBUG - 2011-06-03 12:36:36 --> Loader Class Initialized
DEBUG - 2011-06-03 12:36:36 --> Controller Class Initialized
ERROR - 2011-06-03 12:36:36 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-03 12:36:36 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-03 12:36:36 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-03 12:36:36 --> Model Class Initialized
DEBUG - 2011-06-03 12:36:36 --> Model Class Initialized
DEBUG - 2011-06-03 12:36:36 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-03 12:36:36 --> Database Driver Class Initialized
DEBUG - 2011-06-03 12:36:36 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-03 12:36:36 --> Helper loaded: url_helper
DEBUG - 2011-06-03 12:36:36 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-03 12:36:36 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-03 12:36:36 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-03 12:36:36 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-03 12:36:36 --> Final output sent to browser
DEBUG - 2011-06-03 12:36:36 --> Total execution time: 0.0283
DEBUG - 2011-06-03 12:36:39 --> Config Class Initialized
DEBUG - 2011-06-03 12:36:39 --> Hooks Class Initialized
DEBUG - 2011-06-03 12:36:39 --> Utf8 Class Initialized
DEBUG - 2011-06-03 12:36:39 --> UTF-8 Support Enabled
DEBUG - 2011-06-03 12:36:39 --> URI Class Initialized
DEBUG - 2011-06-03 12:36:39 --> Router Class Initialized
DEBUG - 2011-06-03 12:36:39 --> Output Class Initialized
DEBUG - 2011-06-03 12:36:39 --> Input Class Initialized
DEBUG - 2011-06-03 12:36:39 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-03 12:36:39 --> Language Class Initialized
DEBUG - 2011-06-03 12:36:39 --> Loader Class Initialized
DEBUG - 2011-06-03 12:36:39 --> Controller Class Initialized
ERROR - 2011-06-03 12:36:39 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-03 12:36:39 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-03 12:36:39 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-03 12:36:39 --> Model Class Initialized
DEBUG - 2011-06-03 12:36:39 --> Model Class Initialized
DEBUG - 2011-06-03 12:36:39 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-03 12:36:39 --> Database Driver Class Initialized
DEBUG - 2011-06-03 12:36:39 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-03 12:36:39 --> Helper loaded: url_helper
DEBUG - 2011-06-03 12:36:39 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-03 12:36:39 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-03 12:36:39 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-03 12:36:39 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-03 12:36:39 --> Final output sent to browser
DEBUG - 2011-06-03 12:36:39 --> Total execution time: 0.0707
DEBUG - 2011-06-03 12:36:40 --> Config Class Initialized
DEBUG - 2011-06-03 12:36:40 --> Hooks Class Initialized
DEBUG - 2011-06-03 12:36:40 --> Utf8 Class Initialized
DEBUG - 2011-06-03 12:36:40 --> UTF-8 Support Enabled
DEBUG - 2011-06-03 12:36:40 --> URI Class Initialized
DEBUG - 2011-06-03 12:36:40 --> Router Class Initialized
DEBUG - 2011-06-03 12:36:40 --> Output Class Initialized
DEBUG - 2011-06-03 12:36:40 --> Input Class Initialized
DEBUG - 2011-06-03 12:36:40 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-03 12:36:40 --> Language Class Initialized
DEBUG - 2011-06-03 12:36:40 --> Loader Class Initialized
DEBUG - 2011-06-03 12:36:40 --> Controller Class Initialized
DEBUG - 2011-06-03 12:36:40 --> Model Class Initialized
DEBUG - 2011-06-03 12:36:40 --> Model Class Initialized
DEBUG - 2011-06-03 12:36:40 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-03 12:36:40 --> Database Driver Class Initialized
DEBUG - 2011-06-03 12:36:40 --> Config Class Initialized
DEBUG - 2011-06-03 12:36:40 --> Hooks Class Initialized
DEBUG - 2011-06-03 12:36:40 --> Utf8 Class Initialized
DEBUG - 2011-06-03 12:36:40 --> UTF-8 Support Enabled
DEBUG - 2011-06-03 12:36:40 --> URI Class Initialized
DEBUG - 2011-06-03 12:36:40 --> Router Class Initialized
DEBUG - 2011-06-03 12:36:40 --> Output Class Initialized
DEBUG - 2011-06-03 12:36:40 --> Input Class Initialized
DEBUG - 2011-06-03 12:36:40 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-03 12:36:40 --> Language Class Initialized
DEBUG - 2011-06-03 12:36:40 --> Loader Class Initialized
DEBUG - 2011-06-03 12:36:40 --> Controller Class Initialized
ERROR - 2011-06-03 12:36:40 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-03 12:36:40 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-03 12:36:40 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-03 12:36:40 --> Model Class Initialized
DEBUG - 2011-06-03 12:36:40 --> Model Class Initialized
DEBUG - 2011-06-03 12:36:40 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-03 12:36:40 --> Database Driver Class Initialized
DEBUG - 2011-06-03 12:36:40 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-03 12:36:40 --> Helper loaded: url_helper
DEBUG - 2011-06-03 12:36:40 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-03 12:36:40 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-03 12:36:40 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-03 12:36:40 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-03 12:36:40 --> Final output sent to browser
DEBUG - 2011-06-03 12:36:40 --> Total execution time: 0.0313
DEBUG - 2011-06-03 12:36:40 --> Final output sent to browser
DEBUG - 2011-06-03 12:36:40 --> Total execution time: 0.5770
DEBUG - 2011-06-03 12:36:40 --> Config Class Initialized
DEBUG - 2011-06-03 12:36:40 --> Hooks Class Initialized
DEBUG - 2011-06-03 12:36:40 --> Utf8 Class Initialized
DEBUG - 2011-06-03 12:36:40 --> UTF-8 Support Enabled
DEBUG - 2011-06-03 12:36:40 --> URI Class Initialized
DEBUG - 2011-06-03 12:36:40 --> Router Class Initialized
DEBUG - 2011-06-03 12:36:40 --> Output Class Initialized
DEBUG - 2011-06-03 12:36:40 --> Input Class Initialized
DEBUG - 2011-06-03 12:36:40 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-03 12:36:40 --> Language Class Initialized
DEBUG - 2011-06-03 12:36:40 --> Loader Class Initialized
DEBUG - 2011-06-03 12:36:40 --> Controller Class Initialized
ERROR - 2011-06-03 12:36:40 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-03 12:36:40 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-03 12:36:40 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-03 12:36:40 --> Model Class Initialized
DEBUG - 2011-06-03 12:36:40 --> Model Class Initialized
DEBUG - 2011-06-03 12:36:40 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-03 12:36:40 --> Database Driver Class Initialized
DEBUG - 2011-06-03 12:36:40 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-03 12:36:40 --> Helper loaded: url_helper
DEBUG - 2011-06-03 12:36:40 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-03 12:36:40 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-03 12:36:40 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-03 12:36:40 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-03 12:36:40 --> Final output sent to browser
DEBUG - 2011-06-03 12:36:40 --> Total execution time: 0.0387
DEBUG - 2011-06-03 12:36:41 --> Config Class Initialized
DEBUG - 2011-06-03 12:36:41 --> Hooks Class Initialized
DEBUG - 2011-06-03 12:36:41 --> Utf8 Class Initialized
DEBUG - 2011-06-03 12:36:41 --> UTF-8 Support Enabled
DEBUG - 2011-06-03 12:36:41 --> URI Class Initialized
DEBUG - 2011-06-03 12:36:41 --> Router Class Initialized
DEBUG - 2011-06-03 12:36:41 --> Output Class Initialized
DEBUG - 2011-06-03 12:36:41 --> Input Class Initialized
DEBUG - 2011-06-03 12:36:41 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-03 12:36:41 --> Language Class Initialized
DEBUG - 2011-06-03 12:36:41 --> Loader Class Initialized
DEBUG - 2011-06-03 12:36:41 --> Controller Class Initialized
ERROR - 2011-06-03 12:36:41 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-03 12:36:41 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-03 12:36:41 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-03 12:36:41 --> Model Class Initialized
DEBUG - 2011-06-03 12:36:41 --> Model Class Initialized
DEBUG - 2011-06-03 12:36:41 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-03 12:36:41 --> Database Driver Class Initialized
DEBUG - 2011-06-03 12:36:41 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-03 12:36:41 --> Helper loaded: url_helper
DEBUG - 2011-06-03 12:36:41 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-03 12:36:41 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-03 12:36:41 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-03 12:36:41 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-03 12:36:41 --> Final output sent to browser
DEBUG - 2011-06-03 12:36:41 --> Total execution time: 0.0749
DEBUG - 2011-06-03 12:36:48 --> Config Class Initialized
DEBUG - 2011-06-03 12:36:48 --> Hooks Class Initialized
DEBUG - 2011-06-03 12:36:48 --> Utf8 Class Initialized
DEBUG - 2011-06-03 12:36:48 --> UTF-8 Support Enabled
DEBUG - 2011-06-03 12:36:48 --> URI Class Initialized
DEBUG - 2011-06-03 12:36:48 --> Router Class Initialized
DEBUG - 2011-06-03 12:36:48 --> Output Class Initialized
DEBUG - 2011-06-03 12:36:48 --> Input Class Initialized
DEBUG - 2011-06-03 12:36:48 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-03 12:36:48 --> Language Class Initialized
DEBUG - 2011-06-03 12:36:48 --> Loader Class Initialized
DEBUG - 2011-06-03 12:36:48 --> Controller Class Initialized
ERROR - 2011-06-03 12:36:48 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-03 12:36:48 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-03 12:36:48 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-03 12:36:48 --> Model Class Initialized
DEBUG - 2011-06-03 12:36:48 --> Model Class Initialized
DEBUG - 2011-06-03 12:36:48 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-03 12:36:48 --> Database Driver Class Initialized
DEBUG - 2011-06-03 12:36:48 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-03 12:36:48 --> Helper loaded: url_helper
DEBUG - 2011-06-03 12:36:48 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-03 12:36:48 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-03 12:36:48 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-03 12:36:48 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-03 12:36:48 --> Final output sent to browser
DEBUG - 2011-06-03 12:36:48 --> Total execution time: 0.0463
DEBUG - 2011-06-03 12:36:48 --> Config Class Initialized
DEBUG - 2011-06-03 12:36:48 --> Hooks Class Initialized
DEBUG - 2011-06-03 12:36:48 --> Utf8 Class Initialized
DEBUG - 2011-06-03 12:36:48 --> UTF-8 Support Enabled
DEBUG - 2011-06-03 12:36:48 --> URI Class Initialized
DEBUG - 2011-06-03 12:36:48 --> Router Class Initialized
DEBUG - 2011-06-03 12:36:48 --> Output Class Initialized
DEBUG - 2011-06-03 12:36:48 --> Input Class Initialized
DEBUG - 2011-06-03 12:36:48 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-03 12:36:48 --> Language Class Initialized
DEBUG - 2011-06-03 12:36:48 --> Loader Class Initialized
DEBUG - 2011-06-03 12:36:48 --> Controller Class Initialized
DEBUG - 2011-06-03 12:36:48 --> Model Class Initialized
DEBUG - 2011-06-03 12:36:48 --> Model Class Initialized
DEBUG - 2011-06-03 12:36:48 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-03 12:36:48 --> Database Driver Class Initialized
DEBUG - 2011-06-03 12:36:49 --> Final output sent to browser
DEBUG - 2011-06-03 12:36:49 --> Total execution time: 0.6671
DEBUG - 2011-06-03 13:52:55 --> Config Class Initialized
DEBUG - 2011-06-03 13:52:55 --> Hooks Class Initialized
DEBUG - 2011-06-03 13:52:55 --> Utf8 Class Initialized
DEBUG - 2011-06-03 13:52:55 --> UTF-8 Support Enabled
DEBUG - 2011-06-03 13:52:55 --> URI Class Initialized
DEBUG - 2011-06-03 13:52:55 --> Router Class Initialized
DEBUG - 2011-06-03 13:52:55 --> No URI present. Default controller set.
DEBUG - 2011-06-03 13:52:55 --> Output Class Initialized
DEBUG - 2011-06-03 13:52:55 --> Input Class Initialized
DEBUG - 2011-06-03 13:52:55 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-03 13:52:55 --> Language Class Initialized
DEBUG - 2011-06-03 13:52:55 --> Loader Class Initialized
DEBUG - 2011-06-03 13:52:55 --> Controller Class Initialized
DEBUG - 2011-06-03 13:52:55 --> File loaded: application/views/splash/main.php
DEBUG - 2011-06-03 13:52:55 --> Helper loaded: url_helper
DEBUG - 2011-06-03 13:52:55 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-03 13:52:55 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-03 13:52:55 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-03 13:52:55 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-03 13:52:55 --> Final output sent to browser
DEBUG - 2011-06-03 13:52:55 --> Total execution time: 0.3735
DEBUG - 2011-06-03 15:17:49 --> Config Class Initialized
DEBUG - 2011-06-03 15:17:49 --> Hooks Class Initialized
DEBUG - 2011-06-03 15:17:49 --> Utf8 Class Initialized
DEBUG - 2011-06-03 15:17:49 --> UTF-8 Support Enabled
DEBUG - 2011-06-03 15:17:49 --> URI Class Initialized
DEBUG - 2011-06-03 15:17:49 --> Router Class Initialized
DEBUG - 2011-06-03 15:17:49 --> Output Class Initialized
DEBUG - 2011-06-03 15:17:49 --> Input Class Initialized
DEBUG - 2011-06-03 15:17:49 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-03 15:17:49 --> Language Class Initialized
DEBUG - 2011-06-03 15:17:49 --> Loader Class Initialized
DEBUG - 2011-06-03 15:17:49 --> Controller Class Initialized
DEBUG - 2011-06-03 15:17:49 --> Model Class Initialized
DEBUG - 2011-06-03 15:17:49 --> Model Class Initialized
DEBUG - 2011-06-03 15:17:49 --> Model Class Initialized
DEBUG - 2011-06-03 15:17:49 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-03 15:17:49 --> Database Driver Class Initialized
DEBUG - 2011-06-03 15:17:50 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-03 15:17:50 --> Helper loaded: url_helper
DEBUG - 2011-06-03 15:17:50 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-03 15:17:50 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-03 15:17:50 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-03 15:17:50 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-03 15:17:50 --> Final output sent to browser
DEBUG - 2011-06-03 15:17:50 --> Total execution time: 0.5410
DEBUG - 2011-06-03 15:17:51 --> Config Class Initialized
DEBUG - 2011-06-03 15:17:51 --> Hooks Class Initialized
DEBUG - 2011-06-03 15:17:51 --> Utf8 Class Initialized
DEBUG - 2011-06-03 15:17:51 --> UTF-8 Support Enabled
DEBUG - 2011-06-03 15:17:51 --> URI Class Initialized
DEBUG - 2011-06-03 15:17:51 --> Router Class Initialized
DEBUG - 2011-06-03 15:17:51 --> Output Class Initialized
DEBUG - 2011-06-03 15:17:51 --> Input Class Initialized
DEBUG - 2011-06-03 15:17:51 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-03 15:17:51 --> Language Class Initialized
DEBUG - 2011-06-03 15:17:51 --> Loader Class Initialized
DEBUG - 2011-06-03 15:17:51 --> Controller Class Initialized
ERROR - 2011-06-03 15:17:51 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-03 15:17:51 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-03 15:17:51 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-03 15:17:51 --> Model Class Initialized
DEBUG - 2011-06-03 15:17:51 --> Model Class Initialized
DEBUG - 2011-06-03 15:17:51 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-03 15:17:51 --> Database Driver Class Initialized
DEBUG - 2011-06-03 15:17:51 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-03 15:17:51 --> Helper loaded: url_helper
DEBUG - 2011-06-03 15:17:51 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-03 15:17:51 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-03 15:17:51 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-03 15:17:51 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-03 15:17:51 --> Final output sent to browser
DEBUG - 2011-06-03 15:17:51 --> Total execution time: 0.0758
DEBUG - 2011-06-03 16:49:14 --> Config Class Initialized
DEBUG - 2011-06-03 16:49:14 --> Hooks Class Initialized
DEBUG - 2011-06-03 16:49:14 --> Utf8 Class Initialized
DEBUG - 2011-06-03 16:49:14 --> UTF-8 Support Enabled
DEBUG - 2011-06-03 16:49:14 --> URI Class Initialized
DEBUG - 2011-06-03 16:49:14 --> Router Class Initialized
DEBUG - 2011-06-03 16:49:14 --> Output Class Initialized
DEBUG - 2011-06-03 16:49:14 --> Input Class Initialized
DEBUG - 2011-06-03 16:49:14 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-03 16:49:14 --> Language Class Initialized
DEBUG - 2011-06-03 16:49:14 --> Loader Class Initialized
DEBUG - 2011-06-03 16:49:14 --> Controller Class Initialized
ERROR - 2011-06-03 16:49:14 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-03 16:49:14 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-03 16:49:14 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-03 16:49:14 --> Model Class Initialized
DEBUG - 2011-06-03 16:49:14 --> Model Class Initialized
DEBUG - 2011-06-03 16:49:14 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-03 16:49:14 --> Database Driver Class Initialized
DEBUG - 2011-06-03 16:49:14 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-03 16:49:14 --> Helper loaded: url_helper
DEBUG - 2011-06-03 16:49:14 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-03 16:49:14 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-03 16:49:14 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-03 16:49:14 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-03 16:49:14 --> Final output sent to browser
DEBUG - 2011-06-03 16:49:14 --> Total execution time: 0.3746
DEBUG - 2011-06-03 16:49:15 --> Config Class Initialized
DEBUG - 2011-06-03 16:49:15 --> Hooks Class Initialized
DEBUG - 2011-06-03 16:49:15 --> Utf8 Class Initialized
DEBUG - 2011-06-03 16:49:15 --> UTF-8 Support Enabled
DEBUG - 2011-06-03 16:49:15 --> URI Class Initialized
DEBUG - 2011-06-03 16:49:15 --> Router Class Initialized
DEBUG - 2011-06-03 16:49:15 --> Output Class Initialized
DEBUG - 2011-06-03 16:49:15 --> Input Class Initialized
DEBUG - 2011-06-03 16:49:15 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-03 16:49:15 --> Language Class Initialized
DEBUG - 2011-06-03 16:49:15 --> Loader Class Initialized
DEBUG - 2011-06-03 16:49:15 --> Controller Class Initialized
DEBUG - 2011-06-03 16:49:15 --> Model Class Initialized
DEBUG - 2011-06-03 16:49:15 --> Model Class Initialized
DEBUG - 2011-06-03 16:49:15 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-03 16:49:15 --> Database Driver Class Initialized
DEBUG - 2011-06-03 16:49:16 --> Final output sent to browser
DEBUG - 2011-06-03 16:49:16 --> Total execution time: 0.7519
DEBUG - 2011-06-03 16:49:18 --> Config Class Initialized
DEBUG - 2011-06-03 16:49:18 --> Hooks Class Initialized
DEBUG - 2011-06-03 16:49:18 --> Utf8 Class Initialized
DEBUG - 2011-06-03 16:49:18 --> UTF-8 Support Enabled
DEBUG - 2011-06-03 16:49:18 --> URI Class Initialized
DEBUG - 2011-06-03 16:49:18 --> Router Class Initialized
ERROR - 2011-06-03 16:49:18 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-03 16:49:34 --> Config Class Initialized
DEBUG - 2011-06-03 16:49:34 --> Hooks Class Initialized
DEBUG - 2011-06-03 16:49:34 --> Utf8 Class Initialized
DEBUG - 2011-06-03 16:49:34 --> UTF-8 Support Enabled
DEBUG - 2011-06-03 16:49:34 --> URI Class Initialized
DEBUG - 2011-06-03 16:49:34 --> Router Class Initialized
DEBUG - 2011-06-03 16:49:34 --> Output Class Initialized
DEBUG - 2011-06-03 16:49:34 --> Input Class Initialized
DEBUG - 2011-06-03 16:49:34 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-03 16:49:34 --> Language Class Initialized
DEBUG - 2011-06-03 16:49:34 --> Loader Class Initialized
DEBUG - 2011-06-03 16:49:34 --> Controller Class Initialized
ERROR - 2011-06-03 16:49:34 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-03 16:49:34 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-03 16:49:34 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-03 16:49:34 --> Model Class Initialized
DEBUG - 2011-06-03 16:49:34 --> Model Class Initialized
DEBUG - 2011-06-03 16:49:34 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-03 16:49:34 --> Database Driver Class Initialized
DEBUG - 2011-06-03 16:49:34 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-03 16:49:34 --> Helper loaded: url_helper
DEBUG - 2011-06-03 16:49:34 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-03 16:49:34 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-03 16:49:34 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-03 16:49:34 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-03 16:49:34 --> Final output sent to browser
DEBUG - 2011-06-03 16:49:34 --> Total execution time: 0.0348
DEBUG - 2011-06-03 16:49:34 --> Config Class Initialized
DEBUG - 2011-06-03 16:49:34 --> Hooks Class Initialized
DEBUG - 2011-06-03 16:49:34 --> Utf8 Class Initialized
DEBUG - 2011-06-03 16:49:34 --> UTF-8 Support Enabled
DEBUG - 2011-06-03 16:49:34 --> URI Class Initialized
DEBUG - 2011-06-03 16:49:35 --> Router Class Initialized
DEBUG - 2011-06-03 16:49:35 --> Output Class Initialized
DEBUG - 2011-06-03 16:49:35 --> Input Class Initialized
DEBUG - 2011-06-03 16:49:35 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-03 16:49:35 --> Language Class Initialized
DEBUG - 2011-06-03 16:49:35 --> Loader Class Initialized
DEBUG - 2011-06-03 16:49:35 --> Controller Class Initialized
DEBUG - 2011-06-03 16:49:35 --> Model Class Initialized
DEBUG - 2011-06-03 16:49:35 --> Model Class Initialized
DEBUG - 2011-06-03 16:49:35 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-03 16:49:35 --> Database Driver Class Initialized
DEBUG - 2011-06-03 16:49:35 --> Final output sent to browser
DEBUG - 2011-06-03 16:49:35 --> Total execution time: 0.7232
DEBUG - 2011-06-03 16:49:38 --> Config Class Initialized
DEBUG - 2011-06-03 16:49:38 --> Hooks Class Initialized
DEBUG - 2011-06-03 16:49:38 --> Utf8 Class Initialized
DEBUG - 2011-06-03 16:49:38 --> UTF-8 Support Enabled
DEBUG - 2011-06-03 16:49:38 --> URI Class Initialized
DEBUG - 2011-06-03 16:49:38 --> Router Class Initialized
ERROR - 2011-06-03 16:49:38 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-03 16:58:48 --> Config Class Initialized
DEBUG - 2011-06-03 16:58:48 --> Hooks Class Initialized
DEBUG - 2011-06-03 16:58:48 --> Utf8 Class Initialized
DEBUG - 2011-06-03 16:58:48 --> UTF-8 Support Enabled
DEBUG - 2011-06-03 16:58:48 --> URI Class Initialized
DEBUG - 2011-06-03 16:58:48 --> Router Class Initialized
DEBUG - 2011-06-03 16:58:48 --> Output Class Initialized
DEBUG - 2011-06-03 16:58:48 --> Input Class Initialized
DEBUG - 2011-06-03 16:58:48 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-03 16:58:48 --> Language Class Initialized
DEBUG - 2011-06-03 16:58:48 --> Loader Class Initialized
DEBUG - 2011-06-03 16:58:48 --> Controller Class Initialized
ERROR - 2011-06-03 16:58:48 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-03 16:58:48 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-03 16:58:48 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-03 16:58:48 --> Model Class Initialized
DEBUG - 2011-06-03 16:58:48 --> Model Class Initialized
DEBUG - 2011-06-03 16:58:48 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-03 16:58:48 --> Database Driver Class Initialized
DEBUG - 2011-06-03 16:58:48 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-03 16:58:48 --> Helper loaded: url_helper
DEBUG - 2011-06-03 16:58:48 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-03 16:58:48 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-03 16:58:48 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-03 16:58:48 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-03 16:58:48 --> Final output sent to browser
DEBUG - 2011-06-03 16:58:48 --> Total execution time: 0.0290
DEBUG - 2011-06-03 16:58:48 --> Config Class Initialized
DEBUG - 2011-06-03 16:58:48 --> Hooks Class Initialized
DEBUG - 2011-06-03 16:58:48 --> Utf8 Class Initialized
DEBUG - 2011-06-03 16:58:48 --> UTF-8 Support Enabled
DEBUG - 2011-06-03 16:58:48 --> URI Class Initialized
DEBUG - 2011-06-03 16:58:48 --> Router Class Initialized
DEBUG - 2011-06-03 16:58:48 --> Output Class Initialized
DEBUG - 2011-06-03 16:58:48 --> Input Class Initialized
DEBUG - 2011-06-03 16:58:48 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-03 16:58:48 --> Language Class Initialized
DEBUG - 2011-06-03 16:58:48 --> Loader Class Initialized
DEBUG - 2011-06-03 16:58:48 --> Controller Class Initialized
DEBUG - 2011-06-03 16:58:48 --> Model Class Initialized
DEBUG - 2011-06-03 16:58:48 --> Model Class Initialized
DEBUG - 2011-06-03 16:58:48 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-03 16:58:48 --> Database Driver Class Initialized
DEBUG - 2011-06-03 16:58:49 --> Final output sent to browser
DEBUG - 2011-06-03 16:58:49 --> Total execution time: 0.5331
DEBUG - 2011-06-03 16:58:51 --> Config Class Initialized
DEBUG - 2011-06-03 16:58:51 --> Hooks Class Initialized
DEBUG - 2011-06-03 16:58:51 --> Utf8 Class Initialized
DEBUG - 2011-06-03 16:58:51 --> UTF-8 Support Enabled
DEBUG - 2011-06-03 16:58:51 --> URI Class Initialized
DEBUG - 2011-06-03 16:58:51 --> Router Class Initialized
ERROR - 2011-06-03 16:58:51 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-03 17:07:58 --> Config Class Initialized
DEBUG - 2011-06-03 17:07:58 --> Hooks Class Initialized
DEBUG - 2011-06-03 17:07:58 --> Utf8 Class Initialized
DEBUG - 2011-06-03 17:07:58 --> UTF-8 Support Enabled
DEBUG - 2011-06-03 17:07:58 --> URI Class Initialized
DEBUG - 2011-06-03 17:07:58 --> Router Class Initialized
ERROR - 2011-06-03 17:07:58 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-06-03 17:08:00 --> Config Class Initialized
DEBUG - 2011-06-03 17:08:00 --> Hooks Class Initialized
DEBUG - 2011-06-03 17:08:00 --> Utf8 Class Initialized
DEBUG - 2011-06-03 17:08:00 --> UTF-8 Support Enabled
DEBUG - 2011-06-03 17:08:00 --> URI Class Initialized
DEBUG - 2011-06-03 17:08:00 --> Router Class Initialized
DEBUG - 2011-06-03 17:08:00 --> Output Class Initialized
DEBUG - 2011-06-03 17:08:00 --> Input Class Initialized
DEBUG - 2011-06-03 17:08:00 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-03 17:08:00 --> Language Class Initialized
DEBUG - 2011-06-03 17:08:00 --> Loader Class Initialized
DEBUG - 2011-06-03 17:08:00 --> Controller Class Initialized
ERROR - 2011-06-03 17:08:00 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-03 17:08:00 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-03 17:08:00 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-03 17:08:00 --> Model Class Initialized
DEBUG - 2011-06-03 17:08:00 --> Model Class Initialized
DEBUG - 2011-06-03 17:08:00 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-03 17:08:00 --> Database Driver Class Initialized
DEBUG - 2011-06-03 17:08:00 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-03 17:08:00 --> Helper loaded: url_helper
DEBUG - 2011-06-03 17:08:00 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-03 17:08:00 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-03 17:08:00 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-03 17:08:00 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-03 17:08:00 --> Final output sent to browser
DEBUG - 2011-06-03 17:08:00 --> Total execution time: 0.0299
DEBUG - 2011-06-03 17:15:02 --> Config Class Initialized
DEBUG - 2011-06-03 17:15:02 --> Hooks Class Initialized
DEBUG - 2011-06-03 17:15:02 --> Utf8 Class Initialized
DEBUG - 2011-06-03 17:15:02 --> UTF-8 Support Enabled
DEBUG - 2011-06-03 17:15:02 --> URI Class Initialized
DEBUG - 2011-06-03 17:15:02 --> Router Class Initialized
DEBUG - 2011-06-03 17:15:02 --> Output Class Initialized
DEBUG - 2011-06-03 17:15:02 --> Input Class Initialized
DEBUG - 2011-06-03 17:15:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-03 17:15:02 --> Language Class Initialized
DEBUG - 2011-06-03 17:15:02 --> Loader Class Initialized
DEBUG - 2011-06-03 17:15:02 --> Controller Class Initialized
DEBUG - 2011-06-03 17:15:02 --> Model Class Initialized
DEBUG - 2011-06-03 17:15:02 --> Model Class Initialized
DEBUG - 2011-06-03 17:15:02 --> Model Class Initialized
DEBUG - 2011-06-03 17:15:02 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-03 17:15:02 --> Database Driver Class Initialized
DEBUG - 2011-06-03 17:15:03 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-03 17:15:03 --> Helper loaded: url_helper
DEBUG - 2011-06-03 17:15:03 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-03 17:15:03 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-03 17:15:03 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-03 17:15:03 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-03 17:15:03 --> Final output sent to browser
DEBUG - 2011-06-03 17:15:03 --> Total execution time: 1.3643
DEBUG - 2011-06-03 17:15:07 --> Config Class Initialized
DEBUG - 2011-06-03 17:15:07 --> Hooks Class Initialized
DEBUG - 2011-06-03 17:15:07 --> Utf8 Class Initialized
DEBUG - 2011-06-03 17:15:07 --> UTF-8 Support Enabled
DEBUG - 2011-06-03 17:15:07 --> URI Class Initialized
DEBUG - 2011-06-03 17:15:07 --> Router Class Initialized
DEBUG - 2011-06-03 17:15:07 --> Output Class Initialized
DEBUG - 2011-06-03 17:15:07 --> Input Class Initialized
DEBUG - 2011-06-03 17:15:07 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-03 17:15:07 --> Language Class Initialized
DEBUG - 2011-06-03 17:15:07 --> Loader Class Initialized
DEBUG - 2011-06-03 17:15:07 --> Controller Class Initialized
ERROR - 2011-06-03 17:15:07 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-03 17:15:07 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-03 17:15:07 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-03 17:15:07 --> Model Class Initialized
DEBUG - 2011-06-03 17:15:07 --> Model Class Initialized
DEBUG - 2011-06-03 17:15:07 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-03 17:15:07 --> Database Driver Class Initialized
DEBUG - 2011-06-03 17:15:07 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-03 17:15:07 --> Helper loaded: url_helper
DEBUG - 2011-06-03 17:15:07 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-03 17:15:07 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-03 17:15:07 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-03 17:15:07 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-03 17:15:07 --> Final output sent to browser
DEBUG - 2011-06-03 17:15:07 --> Total execution time: 0.0274
DEBUG - 2011-06-03 17:37:53 --> Config Class Initialized
DEBUG - 2011-06-03 17:37:53 --> Hooks Class Initialized
DEBUG - 2011-06-03 17:37:53 --> Utf8 Class Initialized
DEBUG - 2011-06-03 17:37:53 --> UTF-8 Support Enabled
DEBUG - 2011-06-03 17:37:53 --> URI Class Initialized
DEBUG - 2011-06-03 17:37:53 --> Router Class Initialized
ERROR - 2011-06-03 17:37:53 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-06-03 17:37:54 --> Config Class Initialized
DEBUG - 2011-06-03 17:37:54 --> Hooks Class Initialized
DEBUG - 2011-06-03 17:37:54 --> Utf8 Class Initialized
DEBUG - 2011-06-03 17:37:54 --> UTF-8 Support Enabled
DEBUG - 2011-06-03 17:37:54 --> URI Class Initialized
DEBUG - 2011-06-03 17:37:54 --> Router Class Initialized
DEBUG - 2011-06-03 17:37:54 --> No URI present. Default controller set.
DEBUG - 2011-06-03 17:37:54 --> Output Class Initialized
DEBUG - 2011-06-03 17:37:54 --> Input Class Initialized
DEBUG - 2011-06-03 17:37:54 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-03 17:37:54 --> Language Class Initialized
DEBUG - 2011-06-03 17:37:54 --> Loader Class Initialized
DEBUG - 2011-06-03 17:37:54 --> Controller Class Initialized
DEBUG - 2011-06-03 17:37:54 --> File loaded: application/views/splash/main.php
DEBUG - 2011-06-03 17:37:54 --> Helper loaded: url_helper
DEBUG - 2011-06-03 17:37:54 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-03 17:37:54 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-03 17:37:54 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-03 17:37:54 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-03 17:37:54 --> Final output sent to browser
DEBUG - 2011-06-03 17:37:54 --> Total execution time: 0.0686
DEBUG - 2011-06-03 17:46:34 --> Config Class Initialized
DEBUG - 2011-06-03 17:46:34 --> Hooks Class Initialized
DEBUG - 2011-06-03 17:46:34 --> Utf8 Class Initialized
DEBUG - 2011-06-03 17:46:34 --> UTF-8 Support Enabled
DEBUG - 2011-06-03 17:46:34 --> URI Class Initialized
DEBUG - 2011-06-03 17:46:34 --> Router Class Initialized
ERROR - 2011-06-03 17:46:34 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-06-03 17:46:37 --> Config Class Initialized
DEBUG - 2011-06-03 17:46:37 --> Hooks Class Initialized
DEBUG - 2011-06-03 17:46:37 --> Utf8 Class Initialized
DEBUG - 2011-06-03 17:46:37 --> UTF-8 Support Enabled
DEBUG - 2011-06-03 17:46:37 --> URI Class Initialized
DEBUG - 2011-06-03 17:46:37 --> Router Class Initialized
DEBUG - 2011-06-03 17:46:37 --> Output Class Initialized
DEBUG - 2011-06-03 17:46:37 --> Input Class Initialized
DEBUG - 2011-06-03 17:46:37 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-03 17:46:37 --> Language Class Initialized
DEBUG - 2011-06-03 17:46:37 --> Loader Class Initialized
DEBUG - 2011-06-03 17:46:37 --> Controller Class Initialized
ERROR - 2011-06-03 17:46:37 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-03 17:46:37 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-03 17:46:37 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-03 17:46:37 --> Model Class Initialized
DEBUG - 2011-06-03 17:46:37 --> Model Class Initialized
DEBUG - 2011-06-03 17:46:37 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-03 17:46:37 --> Database Driver Class Initialized
DEBUG - 2011-06-03 17:46:37 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-03 17:46:37 --> Helper loaded: url_helper
DEBUG - 2011-06-03 17:46:37 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-03 17:46:37 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-03 17:46:37 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-03 17:46:37 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-03 17:46:37 --> Final output sent to browser
DEBUG - 2011-06-03 17:46:37 --> Total execution time: 0.0525
DEBUG - 2011-06-03 17:48:44 --> Config Class Initialized
DEBUG - 2011-06-03 17:48:44 --> Hooks Class Initialized
DEBUG - 2011-06-03 17:48:44 --> Utf8 Class Initialized
DEBUG - 2011-06-03 17:48:44 --> UTF-8 Support Enabled
DEBUG - 2011-06-03 17:48:44 --> URI Class Initialized
DEBUG - 2011-06-03 17:48:44 --> Router Class Initialized
DEBUG - 2011-06-03 17:48:44 --> Output Class Initialized
DEBUG - 2011-06-03 17:48:44 --> Input Class Initialized
DEBUG - 2011-06-03 17:48:44 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-03 17:48:44 --> Language Class Initialized
DEBUG - 2011-06-03 17:48:44 --> Loader Class Initialized
DEBUG - 2011-06-03 17:48:44 --> Controller Class Initialized
DEBUG - 2011-06-03 17:48:44 --> Model Class Initialized
DEBUG - 2011-06-03 17:48:44 --> Model Class Initialized
DEBUG - 2011-06-03 17:48:44 --> Model Class Initialized
DEBUG - 2011-06-03 17:48:44 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-03 17:48:44 --> Database Driver Class Initialized
DEBUG - 2011-06-03 17:48:44 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-03 17:48:44 --> Helper loaded: url_helper
DEBUG - 2011-06-03 17:48:44 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-03 17:48:44 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-03 17:48:44 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-03 17:48:44 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-03 17:48:44 --> Final output sent to browser
DEBUG - 2011-06-03 17:48:44 --> Total execution time: 0.2634
DEBUG - 2011-06-03 19:02:01 --> Config Class Initialized
DEBUG - 2011-06-03 19:02:01 --> Hooks Class Initialized
DEBUG - 2011-06-03 19:02:01 --> Utf8 Class Initialized
DEBUG - 2011-06-03 19:02:01 --> UTF-8 Support Enabled
DEBUG - 2011-06-03 19:02:01 --> URI Class Initialized
DEBUG - 2011-06-03 19:02:01 --> Router Class Initialized
DEBUG - 2011-06-03 19:02:01 --> Output Class Initialized
DEBUG - 2011-06-03 19:02:01 --> Input Class Initialized
DEBUG - 2011-06-03 19:02:01 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-03 19:02:01 --> Language Class Initialized
DEBUG - 2011-06-03 19:02:01 --> Loader Class Initialized
DEBUG - 2011-06-03 19:02:01 --> Controller Class Initialized
DEBUG - 2011-06-03 19:02:01 --> Model Class Initialized
DEBUG - 2011-06-03 19:02:01 --> Model Class Initialized
DEBUG - 2011-06-03 19:02:01 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-03 19:02:01 --> Database Driver Class Initialized
DEBUG - 2011-06-03 19:02:02 --> Final output sent to browser
DEBUG - 2011-06-03 19:02:02 --> Total execution time: 0.8106
DEBUG - 2011-06-03 22:18:38 --> Config Class Initialized
DEBUG - 2011-06-03 22:18:38 --> Hooks Class Initialized
DEBUG - 2011-06-03 22:18:38 --> Utf8 Class Initialized
DEBUG - 2011-06-03 22:18:38 --> UTF-8 Support Enabled
DEBUG - 2011-06-03 22:18:38 --> URI Class Initialized
DEBUG - 2011-06-03 22:18:38 --> Router Class Initialized
DEBUG - 2011-06-03 22:18:38 --> No URI present. Default controller set.
DEBUG - 2011-06-03 22:18:38 --> Output Class Initialized
DEBUG - 2011-06-03 22:18:38 --> Input Class Initialized
DEBUG - 2011-06-03 22:18:38 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-03 22:18:38 --> Language Class Initialized
DEBUG - 2011-06-03 22:18:38 --> Loader Class Initialized
DEBUG - 2011-06-03 22:18:38 --> Controller Class Initialized
DEBUG - 2011-06-03 22:18:38 --> File loaded: application/views/splash/main.php
DEBUG - 2011-06-03 22:18:39 --> Helper loaded: url_helper
DEBUG - 2011-06-03 22:18:39 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-03 22:18:39 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-03 22:18:39 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-03 22:18:39 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-03 22:18:39 --> Final output sent to browser
DEBUG - 2011-06-03 22:18:39 --> Total execution time: 0.2594

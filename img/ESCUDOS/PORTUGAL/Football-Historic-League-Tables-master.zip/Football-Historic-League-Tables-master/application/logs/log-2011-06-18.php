<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2011-06-18 00:39:08 --> Config Class Initialized
DEBUG - 2011-06-18 00:39:08 --> Hooks Class Initialized
DEBUG - 2011-06-18 00:39:08 --> Utf8 Class Initialized
DEBUG - 2011-06-18 00:39:08 --> UTF-8 Support Enabled
DEBUG - 2011-06-18 00:39:08 --> URI Class Initialized
DEBUG - 2011-06-18 00:39:08 --> Router Class Initialized
DEBUG - 2011-06-18 00:39:08 --> Output Class Initialized
DEBUG - 2011-06-18 00:39:08 --> Input Class Initialized
DEBUG - 2011-06-18 00:39:08 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-18 00:39:08 --> Language Class Initialized
DEBUG - 2011-06-18 00:39:08 --> Loader Class Initialized
DEBUG - 2011-06-18 00:39:08 --> Controller Class Initialized
DEBUG - 2011-06-18 00:39:08 --> Model Class Initialized
DEBUG - 2011-06-18 00:39:08 --> Model Class Initialized
DEBUG - 2011-06-18 00:39:08 --> Model Class Initialized
DEBUG - 2011-06-18 00:39:08 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-18 00:39:08 --> Database Driver Class Initialized
DEBUG - 2011-06-18 00:39:08 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-18 00:39:09 --> Helper loaded: url_helper
DEBUG - 2011-06-18 00:39:09 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-18 00:39:09 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-18 00:39:09 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-18 00:39:09 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-18 00:39:09 --> Final output sent to browser
DEBUG - 2011-06-18 00:39:09 --> Total execution time: 0.5033
DEBUG - 2011-06-18 00:39:10 --> Config Class Initialized
DEBUG - 2011-06-18 00:39:10 --> Hooks Class Initialized
DEBUG - 2011-06-18 00:39:10 --> Utf8 Class Initialized
DEBUG - 2011-06-18 00:39:10 --> UTF-8 Support Enabled
DEBUG - 2011-06-18 00:39:10 --> URI Class Initialized
DEBUG - 2011-06-18 00:39:10 --> Router Class Initialized
DEBUG - 2011-06-18 00:39:10 --> Output Class Initialized
DEBUG - 2011-06-18 00:39:10 --> Input Class Initialized
DEBUG - 2011-06-18 00:39:10 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-18 00:39:10 --> Language Class Initialized
DEBUG - 2011-06-18 00:39:10 --> Loader Class Initialized
DEBUG - 2011-06-18 00:39:10 --> Controller Class Initialized
ERROR - 2011-06-18 00:39:10 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-18 00:39:10 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-18 00:39:10 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-18 00:39:10 --> Model Class Initialized
DEBUG - 2011-06-18 00:39:10 --> Model Class Initialized
DEBUG - 2011-06-18 00:39:10 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-18 00:39:10 --> Database Driver Class Initialized
DEBUG - 2011-06-18 00:39:10 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-18 00:39:10 --> Helper loaded: url_helper
DEBUG - 2011-06-18 00:39:10 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-18 00:39:10 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-18 00:39:10 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-18 00:39:10 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-18 00:39:10 --> Final output sent to browser
DEBUG - 2011-06-18 00:39:10 --> Total execution time: 0.0987
DEBUG - 2011-06-18 00:44:32 --> Config Class Initialized
DEBUG - 2011-06-18 00:44:32 --> Hooks Class Initialized
DEBUG - 2011-06-18 00:44:32 --> Utf8 Class Initialized
DEBUG - 2011-06-18 00:44:32 --> UTF-8 Support Enabled
DEBUG - 2011-06-18 00:44:32 --> URI Class Initialized
DEBUG - 2011-06-18 00:44:32 --> Router Class Initialized
DEBUG - 2011-06-18 00:44:32 --> Output Class Initialized
DEBUG - 2011-06-18 00:44:32 --> Input Class Initialized
DEBUG - 2011-06-18 00:44:32 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-18 00:44:32 --> Language Class Initialized
DEBUG - 2011-06-18 00:44:32 --> Loader Class Initialized
DEBUG - 2011-06-18 00:44:32 --> Controller Class Initialized
DEBUG - 2011-06-18 00:44:32 --> Model Class Initialized
DEBUG - 2011-06-18 00:44:32 --> Model Class Initialized
DEBUG - 2011-06-18 00:44:32 --> Model Class Initialized
DEBUG - 2011-06-18 00:44:32 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-18 00:44:32 --> Database Driver Class Initialized
DEBUG - 2011-06-18 00:44:32 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-18 00:44:32 --> Helper loaded: url_helper
DEBUG - 2011-06-18 00:44:32 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-18 00:44:32 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-18 00:44:32 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-18 00:44:32 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-18 00:44:32 --> Final output sent to browser
DEBUG - 2011-06-18 00:44:32 --> Total execution time: 0.0440
DEBUG - 2011-06-18 00:44:37 --> Config Class Initialized
DEBUG - 2011-06-18 00:44:37 --> Hooks Class Initialized
DEBUG - 2011-06-18 00:44:37 --> Utf8 Class Initialized
DEBUG - 2011-06-18 00:44:37 --> UTF-8 Support Enabled
DEBUG - 2011-06-18 00:44:37 --> URI Class Initialized
DEBUG - 2011-06-18 00:44:37 --> Router Class Initialized
ERROR - 2011-06-18 00:44:37 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-18 00:44:37 --> Config Class Initialized
DEBUG - 2011-06-18 00:44:37 --> Hooks Class Initialized
DEBUG - 2011-06-18 00:44:37 --> Utf8 Class Initialized
DEBUG - 2011-06-18 00:44:37 --> UTF-8 Support Enabled
DEBUG - 2011-06-18 00:44:37 --> URI Class Initialized
DEBUG - 2011-06-18 00:44:37 --> Router Class Initialized
ERROR - 2011-06-18 00:44:37 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-18 00:44:39 --> Config Class Initialized
DEBUG - 2011-06-18 00:44:39 --> Hooks Class Initialized
DEBUG - 2011-06-18 00:44:39 --> Utf8 Class Initialized
DEBUG - 2011-06-18 00:44:39 --> UTF-8 Support Enabled
DEBUG - 2011-06-18 00:44:39 --> URI Class Initialized
DEBUG - 2011-06-18 00:44:39 --> Router Class Initialized
ERROR - 2011-06-18 00:44:39 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-18 00:44:39 --> Config Class Initialized
DEBUG - 2011-06-18 00:44:39 --> Hooks Class Initialized
DEBUG - 2011-06-18 00:44:39 --> Utf8 Class Initialized
DEBUG - 2011-06-18 00:44:39 --> UTF-8 Support Enabled
DEBUG - 2011-06-18 00:44:39 --> URI Class Initialized
DEBUG - 2011-06-18 00:44:39 --> Router Class Initialized
DEBUG - 2011-06-18 00:44:39 --> Output Class Initialized
DEBUG - 2011-06-18 00:44:39 --> Input Class Initialized
DEBUG - 2011-06-18 00:44:39 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-18 00:44:39 --> Language Class Initialized
DEBUG - 2011-06-18 00:44:39 --> Loader Class Initialized
DEBUG - 2011-06-18 00:44:39 --> Controller Class Initialized
DEBUG - 2011-06-18 00:44:39 --> Model Class Initialized
DEBUG - 2011-06-18 00:44:39 --> Model Class Initialized
DEBUG - 2011-06-18 00:44:39 --> Model Class Initialized
DEBUG - 2011-06-18 00:44:39 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-18 00:44:39 --> Database Driver Class Initialized
DEBUG - 2011-06-18 00:44:39 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-18 00:44:39 --> Helper loaded: url_helper
DEBUG - 2011-06-18 00:44:39 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-18 00:44:39 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-18 00:44:39 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-18 00:44:39 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-18 00:44:39 --> Final output sent to browser
DEBUG - 2011-06-18 00:44:39 --> Total execution time: 0.0475
DEBUG - 2011-06-18 00:44:43 --> Config Class Initialized
DEBUG - 2011-06-18 00:44:43 --> Hooks Class Initialized
DEBUG - 2011-06-18 00:44:43 --> Utf8 Class Initialized
DEBUG - 2011-06-18 00:44:43 --> UTF-8 Support Enabled
DEBUG - 2011-06-18 00:44:43 --> URI Class Initialized
DEBUG - 2011-06-18 00:44:43 --> Router Class Initialized
ERROR - 2011-06-18 00:44:43 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-18 00:51:39 --> Config Class Initialized
DEBUG - 2011-06-18 00:51:39 --> Hooks Class Initialized
DEBUG - 2011-06-18 00:51:39 --> Utf8 Class Initialized
DEBUG - 2011-06-18 00:51:39 --> UTF-8 Support Enabled
DEBUG - 2011-06-18 00:51:39 --> URI Class Initialized
DEBUG - 2011-06-18 00:51:39 --> Router Class Initialized
ERROR - 2011-06-18 00:51:39 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-06-18 00:51:51 --> Config Class Initialized
DEBUG - 2011-06-18 00:51:51 --> Hooks Class Initialized
DEBUG - 2011-06-18 00:51:51 --> Utf8 Class Initialized
DEBUG - 2011-06-18 00:51:51 --> UTF-8 Support Enabled
DEBUG - 2011-06-18 00:51:51 --> URI Class Initialized
DEBUG - 2011-06-18 00:51:51 --> Router Class Initialized
DEBUG - 2011-06-18 00:51:51 --> Output Class Initialized
DEBUG - 2011-06-18 00:51:51 --> Input Class Initialized
DEBUG - 2011-06-18 00:51:51 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-18 00:51:51 --> Language Class Initialized
DEBUG - 2011-06-18 00:51:51 --> Loader Class Initialized
DEBUG - 2011-06-18 00:51:51 --> Controller Class Initialized
ERROR - 2011-06-18 00:51:51 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-18 00:51:51 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-18 00:51:51 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-18 00:51:51 --> Model Class Initialized
DEBUG - 2011-06-18 00:51:51 --> Model Class Initialized
DEBUG - 2011-06-18 00:51:51 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-18 00:51:51 --> Database Driver Class Initialized
DEBUG - 2011-06-18 00:51:51 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-18 00:51:51 --> Helper loaded: url_helper
DEBUG - 2011-06-18 00:51:51 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-18 00:51:51 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-18 00:51:51 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-18 00:51:51 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-18 00:51:51 --> Final output sent to browser
DEBUG - 2011-06-18 00:51:51 --> Total execution time: 0.2668
DEBUG - 2011-06-18 00:51:54 --> Config Class Initialized
DEBUG - 2011-06-18 00:51:54 --> Hooks Class Initialized
DEBUG - 2011-06-18 00:51:54 --> Utf8 Class Initialized
DEBUG - 2011-06-18 00:51:54 --> UTF-8 Support Enabled
DEBUG - 2011-06-18 00:51:54 --> URI Class Initialized
DEBUG - 2011-06-18 00:51:54 --> Router Class Initialized
DEBUG - 2011-06-18 00:51:54 --> Output Class Initialized
DEBUG - 2011-06-18 00:51:54 --> Input Class Initialized
DEBUG - 2011-06-18 00:51:54 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-18 00:51:54 --> Language Class Initialized
DEBUG - 2011-06-18 00:51:54 --> Loader Class Initialized
DEBUG - 2011-06-18 00:51:54 --> Controller Class Initialized
DEBUG - 2011-06-18 00:51:54 --> Model Class Initialized
DEBUG - 2011-06-18 00:51:54 --> Model Class Initialized
DEBUG - 2011-06-18 00:51:54 --> Model Class Initialized
DEBUG - 2011-06-18 00:51:54 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-18 00:51:54 --> Database Driver Class Initialized
DEBUG - 2011-06-18 00:51:54 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-18 00:51:54 --> Helper loaded: url_helper
DEBUG - 2011-06-18 00:51:54 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-18 00:51:54 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-18 00:51:54 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-18 00:51:54 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-18 00:51:54 --> Final output sent to browser
DEBUG - 2011-06-18 00:51:54 --> Total execution time: 0.1150
DEBUG - 2011-06-18 01:35:51 --> Config Class Initialized
DEBUG - 2011-06-18 01:35:51 --> Hooks Class Initialized
DEBUG - 2011-06-18 01:35:51 --> Utf8 Class Initialized
DEBUG - 2011-06-18 01:35:51 --> UTF-8 Support Enabled
DEBUG - 2011-06-18 01:35:51 --> URI Class Initialized
DEBUG - 2011-06-18 01:35:51 --> Router Class Initialized
DEBUG - 2011-06-18 01:35:51 --> Output Class Initialized
DEBUG - 2011-06-18 01:35:51 --> Input Class Initialized
DEBUG - 2011-06-18 01:35:51 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-18 01:35:51 --> Language Class Initialized
DEBUG - 2011-06-18 01:35:51 --> Loader Class Initialized
DEBUG - 2011-06-18 01:35:51 --> Controller Class Initialized
DEBUG - 2011-06-18 01:35:51 --> Model Class Initialized
DEBUG - 2011-06-18 01:35:51 --> Model Class Initialized
DEBUG - 2011-06-18 01:35:51 --> Model Class Initialized
DEBUG - 2011-06-18 01:35:51 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-18 01:35:51 --> Database Driver Class Initialized
DEBUG - 2011-06-18 01:35:52 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-18 01:35:52 --> Helper loaded: url_helper
DEBUG - 2011-06-18 01:35:52 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-18 01:35:52 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-18 01:35:52 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-18 01:35:52 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-18 01:35:52 --> Final output sent to browser
DEBUG - 2011-06-18 01:35:52 --> Total execution time: 1.0160
DEBUG - 2011-06-18 01:35:53 --> Config Class Initialized
DEBUG - 2011-06-18 01:35:53 --> Hooks Class Initialized
DEBUG - 2011-06-18 01:35:53 --> Utf8 Class Initialized
DEBUG - 2011-06-18 01:35:53 --> UTF-8 Support Enabled
DEBUG - 2011-06-18 01:35:53 --> URI Class Initialized
DEBUG - 2011-06-18 01:35:53 --> Router Class Initialized
DEBUG - 2011-06-18 01:35:53 --> Output Class Initialized
DEBUG - 2011-06-18 01:35:53 --> Input Class Initialized
DEBUG - 2011-06-18 01:35:53 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-18 01:35:53 --> Language Class Initialized
DEBUG - 2011-06-18 01:35:53 --> Loader Class Initialized
DEBUG - 2011-06-18 01:35:53 --> Controller Class Initialized
ERROR - 2011-06-18 01:35:53 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-18 01:35:53 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-18 01:35:53 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-18 01:35:53 --> Model Class Initialized
DEBUG - 2011-06-18 01:35:53 --> Model Class Initialized
DEBUG - 2011-06-18 01:35:53 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-18 01:35:53 --> Database Driver Class Initialized
DEBUG - 2011-06-18 01:35:53 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-18 01:35:53 --> Helper loaded: url_helper
DEBUG - 2011-06-18 01:35:53 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-18 01:35:53 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-18 01:35:53 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-18 01:35:53 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-18 01:35:53 --> Final output sent to browser
DEBUG - 2011-06-18 01:35:53 --> Total execution time: 0.1010
DEBUG - 2011-06-18 02:05:50 --> Config Class Initialized
DEBUG - 2011-06-18 02:05:50 --> Hooks Class Initialized
DEBUG - 2011-06-18 02:05:50 --> Utf8 Class Initialized
DEBUG - 2011-06-18 02:05:50 --> UTF-8 Support Enabled
DEBUG - 2011-06-18 02:05:50 --> URI Class Initialized
DEBUG - 2011-06-18 02:05:50 --> Router Class Initialized
DEBUG - 2011-06-18 02:05:50 --> Output Class Initialized
DEBUG - 2011-06-18 02:05:50 --> Input Class Initialized
DEBUG - 2011-06-18 02:05:50 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-18 02:05:50 --> Language Class Initialized
DEBUG - 2011-06-18 02:05:50 --> Loader Class Initialized
DEBUG - 2011-06-18 02:05:50 --> Controller Class Initialized
ERROR - 2011-06-18 02:05:50 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-18 02:05:50 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-18 02:05:50 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-18 02:05:50 --> Model Class Initialized
DEBUG - 2011-06-18 02:05:50 --> Model Class Initialized
DEBUG - 2011-06-18 02:05:50 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-18 02:05:51 --> Database Driver Class Initialized
DEBUG - 2011-06-18 02:05:51 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-18 02:05:51 --> Helper loaded: url_helper
DEBUG - 2011-06-18 02:05:51 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-18 02:05:51 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-18 02:05:51 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-18 02:05:51 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-18 02:05:51 --> Final output sent to browser
DEBUG - 2011-06-18 02:05:51 --> Total execution time: 0.3952
DEBUG - 2011-06-18 02:05:52 --> Config Class Initialized
DEBUG - 2011-06-18 02:05:52 --> Hooks Class Initialized
DEBUG - 2011-06-18 02:05:52 --> Utf8 Class Initialized
DEBUG - 2011-06-18 02:05:52 --> UTF-8 Support Enabled
DEBUG - 2011-06-18 02:05:52 --> URI Class Initialized
DEBUG - 2011-06-18 02:05:52 --> Router Class Initialized
DEBUG - 2011-06-18 02:05:52 --> Output Class Initialized
DEBUG - 2011-06-18 02:05:52 --> Input Class Initialized
DEBUG - 2011-06-18 02:05:52 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-18 02:05:52 --> Language Class Initialized
DEBUG - 2011-06-18 02:05:52 --> Loader Class Initialized
DEBUG - 2011-06-18 02:05:52 --> Controller Class Initialized
DEBUG - 2011-06-18 02:05:52 --> Model Class Initialized
DEBUG - 2011-06-18 02:05:52 --> Model Class Initialized
DEBUG - 2011-06-18 02:05:52 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-18 02:05:52 --> Database Driver Class Initialized
DEBUG - 2011-06-18 02:05:55 --> Final output sent to browser
DEBUG - 2011-06-18 02:05:55 --> Total execution time: 2.8687
DEBUG - 2011-06-18 02:06:25 --> Config Class Initialized
DEBUG - 2011-06-18 02:06:25 --> Hooks Class Initialized
DEBUG - 2011-06-18 02:06:25 --> Utf8 Class Initialized
DEBUG - 2011-06-18 02:06:25 --> UTF-8 Support Enabled
DEBUG - 2011-06-18 02:06:25 --> URI Class Initialized
DEBUG - 2011-06-18 02:06:25 --> Router Class Initialized
ERROR - 2011-06-18 02:06:25 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-18 02:06:25 --> Config Class Initialized
DEBUG - 2011-06-18 02:06:25 --> Hooks Class Initialized
DEBUG - 2011-06-18 02:06:25 --> Utf8 Class Initialized
DEBUG - 2011-06-18 02:06:25 --> UTF-8 Support Enabled
DEBUG - 2011-06-18 02:06:25 --> URI Class Initialized
DEBUG - 2011-06-18 02:06:25 --> Router Class Initialized
ERROR - 2011-06-18 02:06:25 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-18 02:06:26 --> Config Class Initialized
DEBUG - 2011-06-18 02:06:26 --> Hooks Class Initialized
DEBUG - 2011-06-18 02:06:26 --> Utf8 Class Initialized
DEBUG - 2011-06-18 02:06:26 --> UTF-8 Support Enabled
DEBUG - 2011-06-18 02:06:26 --> URI Class Initialized
DEBUG - 2011-06-18 02:06:26 --> Router Class Initialized
ERROR - 2011-06-18 02:06:26 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-18 02:09:28 --> Config Class Initialized
DEBUG - 2011-06-18 02:09:28 --> Hooks Class Initialized
DEBUG - 2011-06-18 02:09:28 --> Utf8 Class Initialized
DEBUG - 2011-06-18 02:09:28 --> UTF-8 Support Enabled
DEBUG - 2011-06-18 02:09:28 --> URI Class Initialized
DEBUG - 2011-06-18 02:09:28 --> Router Class Initialized
DEBUG - 2011-06-18 02:09:28 --> Output Class Initialized
DEBUG - 2011-06-18 02:09:28 --> Input Class Initialized
DEBUG - 2011-06-18 02:09:28 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-18 02:09:28 --> Language Class Initialized
DEBUG - 2011-06-18 02:09:28 --> Loader Class Initialized
DEBUG - 2011-06-18 02:09:28 --> Controller Class Initialized
DEBUG - 2011-06-18 02:09:28 --> Model Class Initialized
DEBUG - 2011-06-18 02:09:28 --> Model Class Initialized
DEBUG - 2011-06-18 02:09:28 --> Model Class Initialized
DEBUG - 2011-06-18 02:09:28 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-18 02:09:28 --> Database Driver Class Initialized
DEBUG - 2011-06-18 02:09:28 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-18 02:09:28 --> Helper loaded: url_helper
DEBUG - 2011-06-18 02:09:28 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-18 02:09:28 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-18 02:09:28 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-18 02:09:28 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-18 02:09:28 --> Final output sent to browser
DEBUG - 2011-06-18 02:09:28 --> Total execution time: 0.0883
DEBUG - 2011-06-18 02:09:29 --> Config Class Initialized
DEBUG - 2011-06-18 02:09:29 --> Hooks Class Initialized
DEBUG - 2011-06-18 02:09:29 --> Utf8 Class Initialized
DEBUG - 2011-06-18 02:09:29 --> UTF-8 Support Enabled
DEBUG - 2011-06-18 02:09:29 --> URI Class Initialized
DEBUG - 2011-06-18 02:09:29 --> Router Class Initialized
DEBUG - 2011-06-18 02:09:29 --> Output Class Initialized
DEBUG - 2011-06-18 02:09:29 --> Input Class Initialized
DEBUG - 2011-06-18 02:09:29 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-18 02:09:29 --> Language Class Initialized
DEBUG - 2011-06-18 02:09:29 --> Loader Class Initialized
DEBUG - 2011-06-18 02:09:29 --> Controller Class Initialized
ERROR - 2011-06-18 02:09:29 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-18 02:09:29 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-18 02:09:29 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-18 02:09:29 --> Model Class Initialized
DEBUG - 2011-06-18 02:09:29 --> Model Class Initialized
DEBUG - 2011-06-18 02:09:29 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-18 02:09:29 --> Database Driver Class Initialized
DEBUG - 2011-06-18 02:09:29 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-18 02:09:29 --> Helper loaded: url_helper
DEBUG - 2011-06-18 02:09:29 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-18 02:09:29 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-18 02:09:29 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-18 02:09:29 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-18 02:09:29 --> Final output sent to browser
DEBUG - 2011-06-18 02:09:29 --> Total execution time: 0.0264
DEBUG - 2011-06-18 03:44:21 --> Config Class Initialized
DEBUG - 2011-06-18 03:44:21 --> Hooks Class Initialized
DEBUG - 2011-06-18 03:44:21 --> Utf8 Class Initialized
DEBUG - 2011-06-18 03:44:21 --> UTF-8 Support Enabled
DEBUG - 2011-06-18 03:44:21 --> URI Class Initialized
DEBUG - 2011-06-18 03:44:21 --> Router Class Initialized
ERROR - 2011-06-18 03:44:21 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-06-18 03:44:39 --> Config Class Initialized
DEBUG - 2011-06-18 03:44:39 --> Hooks Class Initialized
DEBUG - 2011-06-18 03:44:39 --> Utf8 Class Initialized
DEBUG - 2011-06-18 03:44:39 --> UTF-8 Support Enabled
DEBUG - 2011-06-18 03:44:39 --> URI Class Initialized
DEBUG - 2011-06-18 03:44:39 --> Router Class Initialized
DEBUG - 2011-06-18 03:44:39 --> Output Class Initialized
DEBUG - 2011-06-18 03:44:39 --> Input Class Initialized
DEBUG - 2011-06-18 03:44:39 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-18 03:44:39 --> Language Class Initialized
DEBUG - 2011-06-18 03:44:39 --> Loader Class Initialized
DEBUG - 2011-06-18 03:44:39 --> Controller Class Initialized
DEBUG - 2011-06-18 03:44:39 --> Model Class Initialized
DEBUG - 2011-06-18 03:44:39 --> Model Class Initialized
DEBUG - 2011-06-18 03:44:39 --> Model Class Initialized
DEBUG - 2011-06-18 03:44:39 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-18 03:44:39 --> Database Driver Class Initialized
DEBUG - 2011-06-18 03:44:43 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-18 03:44:43 --> Helper loaded: url_helper
DEBUG - 2011-06-18 03:44:43 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-18 03:44:43 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-18 03:44:43 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-18 03:44:43 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-18 03:44:43 --> Final output sent to browser
DEBUG - 2011-06-18 03:44:43 --> Total execution time: 3.8709
DEBUG - 2011-06-18 03:44:44 --> Config Class Initialized
DEBUG - 2011-06-18 03:44:44 --> Hooks Class Initialized
DEBUG - 2011-06-18 03:44:44 --> Utf8 Class Initialized
DEBUG - 2011-06-18 03:44:44 --> UTF-8 Support Enabled
DEBUG - 2011-06-18 03:44:44 --> URI Class Initialized
DEBUG - 2011-06-18 03:44:44 --> Router Class Initialized
DEBUG - 2011-06-18 03:44:44 --> Output Class Initialized
DEBUG - 2011-06-18 03:44:44 --> Input Class Initialized
DEBUG - 2011-06-18 03:44:44 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-18 03:44:44 --> Language Class Initialized
DEBUG - 2011-06-18 03:44:44 --> Loader Class Initialized
DEBUG - 2011-06-18 03:44:44 --> Controller Class Initialized
ERROR - 2011-06-18 03:44:44 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-18 03:44:44 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-18 03:44:44 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-18 03:44:44 --> Model Class Initialized
DEBUG - 2011-06-18 03:44:44 --> Model Class Initialized
DEBUG - 2011-06-18 03:44:44 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-18 03:44:44 --> Database Driver Class Initialized
DEBUG - 2011-06-18 03:44:44 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-18 03:44:44 --> Helper loaded: url_helper
DEBUG - 2011-06-18 03:44:44 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-18 03:44:44 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-18 03:44:44 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-18 03:44:44 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-18 03:44:44 --> Final output sent to browser
DEBUG - 2011-06-18 03:44:44 --> Total execution time: 0.1401
DEBUG - 2011-06-18 04:14:16 --> Config Class Initialized
DEBUG - 2011-06-18 04:14:16 --> Hooks Class Initialized
DEBUG - 2011-06-18 04:14:16 --> Utf8 Class Initialized
DEBUG - 2011-06-18 04:14:16 --> UTF-8 Support Enabled
DEBUG - 2011-06-18 04:14:16 --> URI Class Initialized
DEBUG - 2011-06-18 04:14:16 --> Router Class Initialized
DEBUG - 2011-06-18 04:14:16 --> Output Class Initialized
DEBUG - 2011-06-18 04:14:16 --> Input Class Initialized
DEBUG - 2011-06-18 04:14:16 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-18 04:14:16 --> Language Class Initialized
DEBUG - 2011-06-18 04:14:16 --> Loader Class Initialized
DEBUG - 2011-06-18 04:14:16 --> Controller Class Initialized
DEBUG - 2011-06-18 04:14:16 --> Model Class Initialized
DEBUG - 2011-06-18 04:14:16 --> Model Class Initialized
DEBUG - 2011-06-18 04:14:16 --> Model Class Initialized
DEBUG - 2011-06-18 04:14:16 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-18 04:14:16 --> Database Driver Class Initialized
DEBUG - 2011-06-18 04:14:16 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-18 04:14:17 --> Helper loaded: url_helper
DEBUG - 2011-06-18 04:14:17 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-18 04:14:17 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-18 04:14:17 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-18 04:14:17 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-18 04:14:17 --> Final output sent to browser
DEBUG - 2011-06-18 04:14:17 --> Total execution time: 1.1316
DEBUG - 2011-06-18 04:14:17 --> Config Class Initialized
DEBUG - 2011-06-18 04:14:17 --> Hooks Class Initialized
DEBUG - 2011-06-18 04:14:17 --> Utf8 Class Initialized
DEBUG - 2011-06-18 04:14:17 --> UTF-8 Support Enabled
DEBUG - 2011-06-18 04:14:17 --> URI Class Initialized
DEBUG - 2011-06-18 04:14:17 --> Router Class Initialized
DEBUG - 2011-06-18 04:14:17 --> Output Class Initialized
DEBUG - 2011-06-18 04:14:17 --> Input Class Initialized
DEBUG - 2011-06-18 04:14:17 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-18 04:14:17 --> Language Class Initialized
DEBUG - 2011-06-18 04:14:17 --> Loader Class Initialized
DEBUG - 2011-06-18 04:14:17 --> Controller Class Initialized
ERROR - 2011-06-18 04:14:18 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-18 04:14:18 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-18 04:14:18 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-18 04:14:18 --> Model Class Initialized
DEBUG - 2011-06-18 04:14:18 --> Model Class Initialized
DEBUG - 2011-06-18 04:14:18 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-18 04:14:18 --> Database Driver Class Initialized
DEBUG - 2011-06-18 04:14:18 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-18 04:14:18 --> Helper loaded: url_helper
DEBUG - 2011-06-18 04:14:18 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-18 04:14:18 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-18 04:14:18 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-18 04:14:18 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-18 04:14:18 --> Final output sent to browser
DEBUG - 2011-06-18 04:14:18 --> Total execution time: 0.2957
DEBUG - 2011-06-18 05:10:39 --> Config Class Initialized
DEBUG - 2011-06-18 05:10:39 --> Hooks Class Initialized
DEBUG - 2011-06-18 05:10:39 --> Utf8 Class Initialized
DEBUG - 2011-06-18 05:10:39 --> UTF-8 Support Enabled
DEBUG - 2011-06-18 05:10:39 --> URI Class Initialized
DEBUG - 2011-06-18 05:10:39 --> Router Class Initialized
DEBUG - 2011-06-18 05:10:39 --> Output Class Initialized
DEBUG - 2011-06-18 05:10:39 --> Input Class Initialized
DEBUG - 2011-06-18 05:10:39 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-18 05:10:39 --> Language Class Initialized
DEBUG - 2011-06-18 05:10:39 --> Loader Class Initialized
DEBUG - 2011-06-18 05:10:39 --> Controller Class Initialized
ERROR - 2011-06-18 05:10:39 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-18 05:10:39 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-18 05:10:39 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-18 05:10:39 --> Model Class Initialized
DEBUG - 2011-06-18 05:10:39 --> Model Class Initialized
DEBUG - 2011-06-18 05:10:39 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-18 05:10:39 --> Database Driver Class Initialized
DEBUG - 2011-06-18 05:10:40 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-18 05:10:40 --> Helper loaded: url_helper
DEBUG - 2011-06-18 05:10:40 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-18 05:10:40 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-18 05:10:40 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-18 05:10:40 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-18 05:10:40 --> Final output sent to browser
DEBUG - 2011-06-18 05:10:40 --> Total execution time: 0.9073
DEBUG - 2011-06-18 05:10:41 --> Config Class Initialized
DEBUG - 2011-06-18 05:10:41 --> Hooks Class Initialized
DEBUG - 2011-06-18 05:10:41 --> Utf8 Class Initialized
DEBUG - 2011-06-18 05:10:41 --> UTF-8 Support Enabled
DEBUG - 2011-06-18 05:10:41 --> URI Class Initialized
DEBUG - 2011-06-18 05:10:41 --> Router Class Initialized
DEBUG - 2011-06-18 05:10:41 --> Output Class Initialized
DEBUG - 2011-06-18 05:10:41 --> Input Class Initialized
DEBUG - 2011-06-18 05:10:41 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-18 05:10:41 --> Language Class Initialized
DEBUG - 2011-06-18 05:10:41 --> Loader Class Initialized
DEBUG - 2011-06-18 05:10:41 --> Controller Class Initialized
DEBUG - 2011-06-18 05:10:41 --> Model Class Initialized
DEBUG - 2011-06-18 05:10:41 --> Model Class Initialized
DEBUG - 2011-06-18 05:10:41 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-18 05:10:41 --> Database Driver Class Initialized
DEBUG - 2011-06-18 05:10:42 --> Final output sent to browser
DEBUG - 2011-06-18 05:10:42 --> Total execution time: 0.7939
DEBUG - 2011-06-18 06:33:57 --> Config Class Initialized
DEBUG - 2011-06-18 06:33:57 --> Hooks Class Initialized
DEBUG - 2011-06-18 06:33:57 --> Utf8 Class Initialized
DEBUG - 2011-06-18 06:33:57 --> UTF-8 Support Enabled
DEBUG - 2011-06-18 06:33:57 --> URI Class Initialized
DEBUG - 2011-06-18 06:33:57 --> Router Class Initialized
DEBUG - 2011-06-18 06:33:57 --> Output Class Initialized
DEBUG - 2011-06-18 06:33:57 --> Input Class Initialized
DEBUG - 2011-06-18 06:33:57 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-18 06:33:57 --> Language Class Initialized
DEBUG - 2011-06-18 06:33:57 --> Loader Class Initialized
DEBUG - 2011-06-18 06:33:57 --> Controller Class Initialized
ERROR - 2011-06-18 06:33:57 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-18 06:33:57 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-18 06:33:57 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-18 06:33:57 --> Model Class Initialized
DEBUG - 2011-06-18 06:33:57 --> Model Class Initialized
DEBUG - 2011-06-18 06:33:58 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-18 06:33:58 --> Database Driver Class Initialized
DEBUG - 2011-06-18 06:33:58 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-18 06:33:58 --> Helper loaded: url_helper
DEBUG - 2011-06-18 06:33:58 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-18 06:33:58 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-18 06:33:58 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-18 06:33:58 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-18 06:33:58 --> Final output sent to browser
DEBUG - 2011-06-18 06:33:58 --> Total execution time: 0.3997
DEBUG - 2011-06-18 06:33:59 --> Config Class Initialized
DEBUG - 2011-06-18 06:33:59 --> Hooks Class Initialized
DEBUG - 2011-06-18 06:33:59 --> Utf8 Class Initialized
DEBUG - 2011-06-18 06:33:59 --> UTF-8 Support Enabled
DEBUG - 2011-06-18 06:33:59 --> URI Class Initialized
DEBUG - 2011-06-18 06:33:59 --> Router Class Initialized
ERROR - 2011-06-18 06:33:59 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-18 06:33:59 --> Config Class Initialized
DEBUG - 2011-06-18 06:33:59 --> Hooks Class Initialized
DEBUG - 2011-06-18 06:33:59 --> Utf8 Class Initialized
DEBUG - 2011-06-18 06:33:59 --> UTF-8 Support Enabled
DEBUG - 2011-06-18 06:33:59 --> URI Class Initialized
DEBUG - 2011-06-18 06:33:59 --> Router Class Initialized
DEBUG - 2011-06-18 06:33:59 --> Output Class Initialized
DEBUG - 2011-06-18 06:33:59 --> Input Class Initialized
DEBUG - 2011-06-18 06:33:59 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-18 06:33:59 --> Language Class Initialized
DEBUG - 2011-06-18 06:33:59 --> Loader Class Initialized
DEBUG - 2011-06-18 06:33:59 --> Controller Class Initialized
DEBUG - 2011-06-18 06:33:59 --> Model Class Initialized
DEBUG - 2011-06-18 06:33:59 --> Model Class Initialized
DEBUG - 2011-06-18 06:33:59 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-18 06:34:00 --> Database Driver Class Initialized
DEBUG - 2011-06-18 06:34:00 --> Final output sent to browser
DEBUG - 2011-06-18 06:34:00 --> Total execution time: 1.1990
DEBUG - 2011-06-18 06:37:42 --> Config Class Initialized
DEBUG - 2011-06-18 06:37:42 --> Hooks Class Initialized
DEBUG - 2011-06-18 06:37:42 --> Utf8 Class Initialized
DEBUG - 2011-06-18 06:37:42 --> UTF-8 Support Enabled
DEBUG - 2011-06-18 06:37:42 --> URI Class Initialized
DEBUG - 2011-06-18 06:37:42 --> Router Class Initialized
DEBUG - 2011-06-18 06:37:42 --> Output Class Initialized
DEBUG - 2011-06-18 06:37:42 --> Input Class Initialized
DEBUG - 2011-06-18 06:37:42 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-18 06:37:42 --> Language Class Initialized
DEBUG - 2011-06-18 06:37:42 --> Loader Class Initialized
DEBUG - 2011-06-18 06:37:42 --> Controller Class Initialized
DEBUG - 2011-06-18 06:37:42 --> Model Class Initialized
DEBUG - 2011-06-18 06:37:42 --> Model Class Initialized
DEBUG - 2011-06-18 06:37:42 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-18 06:37:42 --> Database Driver Class Initialized
DEBUG - 2011-06-18 06:37:43 --> Final output sent to browser
DEBUG - 2011-06-18 06:37:43 --> Total execution time: 0.6862
DEBUG - 2011-06-18 06:49:04 --> Config Class Initialized
DEBUG - 2011-06-18 06:49:04 --> Hooks Class Initialized
DEBUG - 2011-06-18 06:49:04 --> Utf8 Class Initialized
DEBUG - 2011-06-18 06:49:04 --> UTF-8 Support Enabled
DEBUG - 2011-06-18 06:49:04 --> URI Class Initialized
DEBUG - 2011-06-18 06:49:04 --> Router Class Initialized
DEBUG - 2011-06-18 06:49:05 --> Output Class Initialized
DEBUG - 2011-06-18 06:49:05 --> Input Class Initialized
DEBUG - 2011-06-18 06:49:05 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-18 06:49:05 --> Language Class Initialized
DEBUG - 2011-06-18 06:49:05 --> Loader Class Initialized
DEBUG - 2011-06-18 06:49:05 --> Controller Class Initialized
DEBUG - 2011-06-18 06:49:05 --> Model Class Initialized
DEBUG - 2011-06-18 06:49:05 --> Model Class Initialized
DEBUG - 2011-06-18 06:49:05 --> Model Class Initialized
DEBUG - 2011-06-18 06:49:05 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-18 06:49:05 --> Database Driver Class Initialized
DEBUG - 2011-06-18 06:49:05 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-18 06:49:05 --> Helper loaded: url_helper
DEBUG - 2011-06-18 06:49:05 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-18 06:49:05 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-18 06:49:05 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-18 06:49:05 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-18 06:49:05 --> Final output sent to browser
DEBUG - 2011-06-18 06:49:05 --> Total execution time: 0.8108
DEBUG - 2011-06-18 06:49:06 --> Config Class Initialized
DEBUG - 2011-06-18 06:49:06 --> Hooks Class Initialized
DEBUG - 2011-06-18 06:49:06 --> Utf8 Class Initialized
DEBUG - 2011-06-18 06:49:06 --> UTF-8 Support Enabled
DEBUG - 2011-06-18 06:49:06 --> URI Class Initialized
DEBUG - 2011-06-18 06:49:06 --> Router Class Initialized
DEBUG - 2011-06-18 06:49:06 --> Output Class Initialized
DEBUG - 2011-06-18 06:49:06 --> Input Class Initialized
DEBUG - 2011-06-18 06:49:06 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-18 06:49:06 --> Language Class Initialized
DEBUG - 2011-06-18 06:49:06 --> Loader Class Initialized
DEBUG - 2011-06-18 06:49:06 --> Controller Class Initialized
ERROR - 2011-06-18 06:49:06 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-18 06:49:06 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-18 06:49:06 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-18 06:49:06 --> Model Class Initialized
DEBUG - 2011-06-18 06:49:06 --> Model Class Initialized
DEBUG - 2011-06-18 06:49:06 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-18 06:49:06 --> Database Driver Class Initialized
DEBUG - 2011-06-18 06:49:06 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-18 06:49:06 --> Helper loaded: url_helper
DEBUG - 2011-06-18 06:49:06 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-18 06:49:06 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-18 06:49:06 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-18 06:49:06 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-18 06:49:06 --> Final output sent to browser
DEBUG - 2011-06-18 06:49:06 --> Total execution time: 0.0658
DEBUG - 2011-06-18 07:30:30 --> Config Class Initialized
DEBUG - 2011-06-18 07:30:30 --> Hooks Class Initialized
DEBUG - 2011-06-18 07:30:30 --> Utf8 Class Initialized
DEBUG - 2011-06-18 07:30:30 --> UTF-8 Support Enabled
DEBUG - 2011-06-18 07:30:30 --> URI Class Initialized
DEBUG - 2011-06-18 07:30:30 --> Router Class Initialized
ERROR - 2011-06-18 07:30:30 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-06-18 08:04:19 --> Config Class Initialized
DEBUG - 2011-06-18 08:04:19 --> Hooks Class Initialized
DEBUG - 2011-06-18 08:04:19 --> Utf8 Class Initialized
DEBUG - 2011-06-18 08:04:19 --> UTF-8 Support Enabled
DEBUG - 2011-06-18 08:04:19 --> URI Class Initialized
DEBUG - 2011-06-18 08:04:19 --> Router Class Initialized
DEBUG - 2011-06-18 08:04:19 --> Output Class Initialized
DEBUG - 2011-06-18 08:04:19 --> Input Class Initialized
DEBUG - 2011-06-18 08:04:19 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-18 08:04:19 --> Language Class Initialized
DEBUG - 2011-06-18 08:04:19 --> Loader Class Initialized
DEBUG - 2011-06-18 08:04:19 --> Controller Class Initialized
ERROR - 2011-06-18 08:04:19 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-18 08:04:19 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-18 08:04:19 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-18 08:04:19 --> Model Class Initialized
DEBUG - 2011-06-18 08:04:19 --> Model Class Initialized
DEBUG - 2011-06-18 08:04:19 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-18 08:04:19 --> Database Driver Class Initialized
DEBUG - 2011-06-18 08:04:19 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-18 08:04:20 --> Helper loaded: url_helper
DEBUG - 2011-06-18 08:04:20 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-18 08:04:20 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-18 08:04:20 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-18 08:04:20 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-18 08:04:20 --> Final output sent to browser
DEBUG - 2011-06-18 08:04:20 --> Total execution time: 0.4176
DEBUG - 2011-06-18 09:26:29 --> Config Class Initialized
DEBUG - 2011-06-18 09:26:29 --> Hooks Class Initialized
DEBUG - 2011-06-18 09:26:29 --> Utf8 Class Initialized
DEBUG - 2011-06-18 09:26:29 --> UTF-8 Support Enabled
DEBUG - 2011-06-18 09:26:29 --> URI Class Initialized
DEBUG - 2011-06-18 09:26:29 --> Router Class Initialized
DEBUG - 2011-06-18 09:26:29 --> Output Class Initialized
DEBUG - 2011-06-18 09:26:29 --> Input Class Initialized
DEBUG - 2011-06-18 09:26:29 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-18 09:26:29 --> Language Class Initialized
DEBUG - 2011-06-18 09:26:30 --> Loader Class Initialized
DEBUG - 2011-06-18 09:26:30 --> Controller Class Initialized
DEBUG - 2011-06-18 09:26:30 --> Model Class Initialized
DEBUG - 2011-06-18 09:26:30 --> Model Class Initialized
DEBUG - 2011-06-18 09:26:30 --> Model Class Initialized
DEBUG - 2011-06-18 09:26:30 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-18 09:26:30 --> Database Driver Class Initialized
DEBUG - 2011-06-18 09:26:30 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-18 09:26:30 --> Helper loaded: url_helper
DEBUG - 2011-06-18 09:26:30 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-18 09:26:30 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-18 09:26:30 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-18 09:26:30 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-18 09:26:30 --> Final output sent to browser
DEBUG - 2011-06-18 09:26:30 --> Total execution time: 0.7146
DEBUG - 2011-06-18 09:26:31 --> Config Class Initialized
DEBUG - 2011-06-18 09:26:31 --> Hooks Class Initialized
DEBUG - 2011-06-18 09:26:31 --> Utf8 Class Initialized
DEBUG - 2011-06-18 09:26:31 --> UTF-8 Support Enabled
DEBUG - 2011-06-18 09:26:31 --> URI Class Initialized
DEBUG - 2011-06-18 09:26:31 --> Router Class Initialized
DEBUG - 2011-06-18 09:26:31 --> Output Class Initialized
DEBUG - 2011-06-18 09:26:31 --> Input Class Initialized
DEBUG - 2011-06-18 09:26:31 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-18 09:26:31 --> Language Class Initialized
DEBUG - 2011-06-18 09:26:31 --> Loader Class Initialized
DEBUG - 2011-06-18 09:26:31 --> Controller Class Initialized
ERROR - 2011-06-18 09:26:31 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-18 09:26:31 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-18 09:26:31 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-18 09:26:31 --> Model Class Initialized
DEBUG - 2011-06-18 09:26:31 --> Model Class Initialized
DEBUG - 2011-06-18 09:26:31 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-18 09:26:31 --> Database Driver Class Initialized
DEBUG - 2011-06-18 09:26:31 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-18 09:26:31 --> Helper loaded: url_helper
DEBUG - 2011-06-18 09:26:31 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-18 09:26:31 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-18 09:26:31 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-18 09:26:31 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-18 09:26:31 --> Final output sent to browser
DEBUG - 2011-06-18 09:26:31 --> Total execution time: 0.0924
DEBUG - 2011-06-18 11:34:05 --> Config Class Initialized
DEBUG - 2011-06-18 11:34:05 --> Hooks Class Initialized
DEBUG - 2011-06-18 11:34:05 --> Utf8 Class Initialized
DEBUG - 2011-06-18 11:34:05 --> UTF-8 Support Enabled
DEBUG - 2011-06-18 11:34:05 --> URI Class Initialized
DEBUG - 2011-06-18 11:34:05 --> Router Class Initialized
ERROR - 2011-06-18 11:34:06 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-06-18 11:34:06 --> Config Class Initialized
DEBUG - 2011-06-18 11:34:06 --> Hooks Class Initialized
DEBUG - 2011-06-18 11:34:06 --> Utf8 Class Initialized
DEBUG - 2011-06-18 11:34:06 --> UTF-8 Support Enabled
DEBUG - 2011-06-18 11:34:06 --> URI Class Initialized
DEBUG - 2011-06-18 11:34:06 --> Router Class Initialized
DEBUG - 2011-06-18 11:34:06 --> Output Class Initialized
DEBUG - 2011-06-18 11:34:06 --> Input Class Initialized
DEBUG - 2011-06-18 11:34:06 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-18 11:34:06 --> Language Class Initialized
DEBUG - 2011-06-18 11:34:06 --> Loader Class Initialized
DEBUG - 2011-06-18 11:34:06 --> Controller Class Initialized
DEBUG - 2011-06-18 11:34:06 --> Model Class Initialized
DEBUG - 2011-06-18 11:34:06 --> Model Class Initialized
DEBUG - 2011-06-18 11:34:06 --> Model Class Initialized
DEBUG - 2011-06-18 11:34:06 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-18 11:34:06 --> Database Driver Class Initialized
DEBUG - 2011-06-18 11:34:06 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-18 11:34:06 --> Helper loaded: url_helper
DEBUG - 2011-06-18 11:34:06 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-18 11:34:06 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-18 11:34:06 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-18 11:34:06 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-18 11:34:06 --> Final output sent to browser
DEBUG - 2011-06-18 11:34:06 --> Total execution time: 0.5272
DEBUG - 2011-06-18 12:08:35 --> Config Class Initialized
DEBUG - 2011-06-18 12:08:35 --> Hooks Class Initialized
DEBUG - 2011-06-18 12:08:35 --> Utf8 Class Initialized
DEBUG - 2011-06-18 12:08:35 --> UTF-8 Support Enabled
DEBUG - 2011-06-18 12:08:35 --> URI Class Initialized
DEBUG - 2011-06-18 12:08:35 --> Router Class Initialized
DEBUG - 2011-06-18 12:08:35 --> Output Class Initialized
DEBUG - 2011-06-18 12:08:35 --> Input Class Initialized
DEBUG - 2011-06-18 12:08:35 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-18 12:08:35 --> Language Class Initialized
DEBUG - 2011-06-18 12:08:35 --> Loader Class Initialized
DEBUG - 2011-06-18 12:08:35 --> Controller Class Initialized
DEBUG - 2011-06-18 12:08:35 --> Model Class Initialized
DEBUG - 2011-06-18 12:08:35 --> Model Class Initialized
DEBUG - 2011-06-18 12:08:35 --> Model Class Initialized
DEBUG - 2011-06-18 12:08:35 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-18 12:08:35 --> Database Driver Class Initialized
DEBUG - 2011-06-18 12:08:36 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-18 12:08:36 --> Helper loaded: url_helper
DEBUG - 2011-06-18 12:08:36 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-18 12:08:36 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-18 12:08:36 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-18 12:08:36 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-18 12:08:36 --> Final output sent to browser
DEBUG - 2011-06-18 12:08:36 --> Total execution time: 1.0528
DEBUG - 2011-06-18 12:08:37 --> Config Class Initialized
DEBUG - 2011-06-18 12:08:37 --> Hooks Class Initialized
DEBUG - 2011-06-18 12:08:37 --> Utf8 Class Initialized
DEBUG - 2011-06-18 12:08:37 --> UTF-8 Support Enabled
DEBUG - 2011-06-18 12:08:37 --> URI Class Initialized
DEBUG - 2011-06-18 12:08:37 --> Router Class Initialized
DEBUG - 2011-06-18 12:08:37 --> Output Class Initialized
DEBUG - 2011-06-18 12:08:37 --> Input Class Initialized
DEBUG - 2011-06-18 12:08:37 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-18 12:08:37 --> Language Class Initialized
DEBUG - 2011-06-18 12:08:37 --> Loader Class Initialized
DEBUG - 2011-06-18 12:08:37 --> Controller Class Initialized
ERROR - 2011-06-18 12:08:37 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-18 12:08:37 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-18 12:08:37 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-18 12:08:37 --> Model Class Initialized
DEBUG - 2011-06-18 12:08:37 --> Model Class Initialized
DEBUG - 2011-06-18 12:08:37 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-18 12:08:37 --> Database Driver Class Initialized
DEBUG - 2011-06-18 12:08:37 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-18 12:08:37 --> Helper loaded: url_helper
DEBUG - 2011-06-18 12:08:37 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-18 12:08:37 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-18 12:08:37 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-18 12:08:37 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-18 12:08:37 --> Final output sent to browser
DEBUG - 2011-06-18 12:08:37 --> Total execution time: 0.1326
DEBUG - 2011-06-18 13:03:20 --> Config Class Initialized
DEBUG - 2011-06-18 13:03:20 --> Hooks Class Initialized
DEBUG - 2011-06-18 13:03:20 --> Utf8 Class Initialized
DEBUG - 2011-06-18 13:03:20 --> UTF-8 Support Enabled
DEBUG - 2011-06-18 13:03:20 --> URI Class Initialized
DEBUG - 2011-06-18 13:03:20 --> Router Class Initialized
DEBUG - 2011-06-18 13:03:20 --> No URI present. Default controller set.
DEBUG - 2011-06-18 13:03:20 --> Output Class Initialized
DEBUG - 2011-06-18 13:03:20 --> Input Class Initialized
DEBUG - 2011-06-18 13:03:20 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-18 13:03:20 --> Language Class Initialized
DEBUG - 2011-06-18 13:03:20 --> Loader Class Initialized
DEBUG - 2011-06-18 13:03:20 --> Controller Class Initialized
DEBUG - 2011-06-18 13:03:20 --> File loaded: application/views/splash/main.php
DEBUG - 2011-06-18 13:03:20 --> Helper loaded: url_helper
DEBUG - 2011-06-18 13:03:20 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-18 13:03:20 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-18 13:03:20 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-18 13:03:20 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-18 13:03:20 --> Final output sent to browser
DEBUG - 2011-06-18 13:03:20 --> Total execution time: 0.2572
DEBUG - 2011-06-18 14:45:38 --> Config Class Initialized
DEBUG - 2011-06-18 14:45:38 --> Hooks Class Initialized
DEBUG - 2011-06-18 14:45:38 --> Utf8 Class Initialized
DEBUG - 2011-06-18 14:45:38 --> UTF-8 Support Enabled
DEBUG - 2011-06-18 14:45:38 --> URI Class Initialized
DEBUG - 2011-06-18 14:45:38 --> Router Class Initialized
DEBUG - 2011-06-18 14:45:38 --> Output Class Initialized
DEBUG - 2011-06-18 14:45:38 --> Input Class Initialized
DEBUG - 2011-06-18 14:45:38 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-18 14:45:38 --> Language Class Initialized
DEBUG - 2011-06-18 14:45:38 --> Loader Class Initialized
DEBUG - 2011-06-18 14:45:38 --> Controller Class Initialized
DEBUG - 2011-06-18 14:45:38 --> Model Class Initialized
DEBUG - 2011-06-18 14:45:38 --> Model Class Initialized
DEBUG - 2011-06-18 14:45:38 --> Model Class Initialized
DEBUG - 2011-06-18 14:45:38 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-18 14:45:38 --> Database Driver Class Initialized
DEBUG - 2011-06-18 14:45:39 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-18 14:45:39 --> Helper loaded: url_helper
DEBUG - 2011-06-18 14:45:39 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-18 14:45:39 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-18 14:45:39 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-18 14:45:39 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-18 14:45:39 --> Final output sent to browser
DEBUG - 2011-06-18 14:45:39 --> Total execution time: 0.6328
DEBUG - 2011-06-18 14:45:40 --> Config Class Initialized
DEBUG - 2011-06-18 14:45:40 --> Hooks Class Initialized
DEBUG - 2011-06-18 14:45:40 --> Utf8 Class Initialized
DEBUG - 2011-06-18 14:45:40 --> UTF-8 Support Enabled
DEBUG - 2011-06-18 14:45:40 --> URI Class Initialized
DEBUG - 2011-06-18 14:45:40 --> Router Class Initialized
DEBUG - 2011-06-18 14:45:40 --> Output Class Initialized
DEBUG - 2011-06-18 14:45:40 --> Input Class Initialized
DEBUG - 2011-06-18 14:45:40 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-18 14:45:40 --> Language Class Initialized
DEBUG - 2011-06-18 14:45:40 --> Loader Class Initialized
DEBUG - 2011-06-18 14:45:40 --> Controller Class Initialized
ERROR - 2011-06-18 14:45:40 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-18 14:45:40 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-18 14:45:40 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-18 14:45:40 --> Model Class Initialized
DEBUG - 2011-06-18 14:45:40 --> Model Class Initialized
DEBUG - 2011-06-18 14:45:40 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-18 14:45:40 --> Database Driver Class Initialized
DEBUG - 2011-06-18 14:45:40 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-18 14:45:40 --> Helper loaded: url_helper
DEBUG - 2011-06-18 14:45:40 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-18 14:45:40 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-18 14:45:40 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-18 14:45:40 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-18 14:45:40 --> Final output sent to browser
DEBUG - 2011-06-18 14:45:40 --> Total execution time: 0.0859
DEBUG - 2011-06-18 15:11:05 --> Config Class Initialized
DEBUG - 2011-06-18 15:11:05 --> Hooks Class Initialized
DEBUG - 2011-06-18 15:11:05 --> Utf8 Class Initialized
DEBUG - 2011-06-18 15:11:05 --> UTF-8 Support Enabled
DEBUG - 2011-06-18 15:11:05 --> URI Class Initialized
DEBUG - 2011-06-18 15:11:05 --> Router Class Initialized
DEBUG - 2011-06-18 15:11:05 --> Output Class Initialized
DEBUG - 2011-06-18 15:11:05 --> Input Class Initialized
DEBUG - 2011-06-18 15:11:05 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-18 15:11:05 --> Language Class Initialized
DEBUG - 2011-06-18 15:11:05 --> Loader Class Initialized
DEBUG - 2011-06-18 15:11:05 --> Controller Class Initialized
ERROR - 2011-06-18 15:11:05 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-18 15:11:05 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-18 15:11:05 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-18 15:11:05 --> Model Class Initialized
DEBUG - 2011-06-18 15:11:05 --> Model Class Initialized
DEBUG - 2011-06-18 15:11:05 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-18 15:11:05 --> Database Driver Class Initialized
DEBUG - 2011-06-18 15:11:05 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-18 15:11:05 --> Helper loaded: url_helper
DEBUG - 2011-06-18 15:11:05 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-18 15:11:05 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-18 15:11:05 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-18 15:11:05 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-18 15:11:05 --> Final output sent to browser
DEBUG - 2011-06-18 15:11:05 --> Total execution time: 0.0431
DEBUG - 2011-06-18 15:11:05 --> Config Class Initialized
DEBUG - 2011-06-18 15:11:05 --> Hooks Class Initialized
DEBUG - 2011-06-18 15:11:05 --> Utf8 Class Initialized
DEBUG - 2011-06-18 15:11:05 --> UTF-8 Support Enabled
DEBUG - 2011-06-18 15:11:05 --> URI Class Initialized
DEBUG - 2011-06-18 15:11:05 --> Router Class Initialized
DEBUG - 2011-06-18 15:11:05 --> Output Class Initialized
DEBUG - 2011-06-18 15:11:05 --> Input Class Initialized
DEBUG - 2011-06-18 15:11:05 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-18 15:11:05 --> Language Class Initialized
DEBUG - 2011-06-18 15:11:05 --> Loader Class Initialized
DEBUG - 2011-06-18 15:11:05 --> Controller Class Initialized
DEBUG - 2011-06-18 15:11:05 --> Model Class Initialized
DEBUG - 2011-06-18 15:11:05 --> Model Class Initialized
DEBUG - 2011-06-18 15:11:05 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-18 15:11:05 --> Database Driver Class Initialized
DEBUG - 2011-06-18 15:11:06 --> Final output sent to browser
DEBUG - 2011-06-18 15:11:06 --> Total execution time: 0.6668
DEBUG - 2011-06-18 15:11:08 --> Config Class Initialized
DEBUG - 2011-06-18 15:11:08 --> Hooks Class Initialized
DEBUG - 2011-06-18 15:11:08 --> Utf8 Class Initialized
DEBUG - 2011-06-18 15:11:08 --> UTF-8 Support Enabled
DEBUG - 2011-06-18 15:11:08 --> URI Class Initialized
DEBUG - 2011-06-18 15:11:08 --> Router Class Initialized
ERROR - 2011-06-18 15:11:08 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-18 15:11:08 --> Config Class Initialized
DEBUG - 2011-06-18 15:11:08 --> Hooks Class Initialized
DEBUG - 2011-06-18 15:11:08 --> Utf8 Class Initialized
DEBUG - 2011-06-18 15:11:08 --> UTF-8 Support Enabled
DEBUG - 2011-06-18 15:11:08 --> URI Class Initialized
DEBUG - 2011-06-18 15:11:08 --> Router Class Initialized
ERROR - 2011-06-18 15:11:08 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-18 15:11:09 --> Config Class Initialized
DEBUG - 2011-06-18 15:11:09 --> Hooks Class Initialized
DEBUG - 2011-06-18 15:11:09 --> Utf8 Class Initialized
DEBUG - 2011-06-18 15:11:09 --> UTF-8 Support Enabled
DEBUG - 2011-06-18 15:11:09 --> URI Class Initialized
DEBUG - 2011-06-18 15:11:09 --> Router Class Initialized
ERROR - 2011-06-18 15:11:09 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-18 15:26:11 --> Config Class Initialized
DEBUG - 2011-06-18 15:26:11 --> Hooks Class Initialized
DEBUG - 2011-06-18 15:26:11 --> Utf8 Class Initialized
DEBUG - 2011-06-18 15:26:11 --> UTF-8 Support Enabled
DEBUG - 2011-06-18 15:26:11 --> URI Class Initialized
DEBUG - 2011-06-18 15:26:11 --> Router Class Initialized
DEBUG - 2011-06-18 15:26:11 --> Output Class Initialized
DEBUG - 2011-06-18 15:26:11 --> Input Class Initialized
DEBUG - 2011-06-18 15:26:11 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-18 15:26:11 --> Language Class Initialized
DEBUG - 2011-06-18 15:26:11 --> Loader Class Initialized
DEBUG - 2011-06-18 15:26:11 --> Controller Class Initialized
DEBUG - 2011-06-18 15:26:11 --> Model Class Initialized
DEBUG - 2011-06-18 15:26:11 --> Model Class Initialized
DEBUG - 2011-06-18 15:26:11 --> Model Class Initialized
DEBUG - 2011-06-18 15:26:11 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-18 15:26:11 --> Database Driver Class Initialized
DEBUG - 2011-06-18 15:26:11 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-18 15:26:11 --> Helper loaded: url_helper
DEBUG - 2011-06-18 15:26:11 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-18 15:26:11 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-18 15:26:11 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-18 15:26:11 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-18 15:26:11 --> Final output sent to browser
DEBUG - 2011-06-18 15:26:11 --> Total execution time: 0.3364
DEBUG - 2011-06-18 15:26:13 --> Config Class Initialized
DEBUG - 2011-06-18 15:26:13 --> Hooks Class Initialized
DEBUG - 2011-06-18 15:26:13 --> Utf8 Class Initialized
DEBUG - 2011-06-18 15:26:13 --> UTF-8 Support Enabled
DEBUG - 2011-06-18 15:26:13 --> URI Class Initialized
DEBUG - 2011-06-18 15:26:13 --> Router Class Initialized
ERROR - 2011-06-18 15:26:13 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-18 15:41:07 --> Config Class Initialized
DEBUG - 2011-06-18 15:41:07 --> Hooks Class Initialized
DEBUG - 2011-06-18 15:41:07 --> Utf8 Class Initialized
DEBUG - 2011-06-18 15:41:07 --> UTF-8 Support Enabled
DEBUG - 2011-06-18 15:41:07 --> URI Class Initialized
DEBUG - 2011-06-18 15:41:07 --> Router Class Initialized
DEBUG - 2011-06-18 15:41:07 --> Output Class Initialized
DEBUG - 2011-06-18 15:41:07 --> Input Class Initialized
DEBUG - 2011-06-18 15:41:07 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-18 15:41:07 --> Language Class Initialized
DEBUG - 2011-06-18 15:41:07 --> Loader Class Initialized
DEBUG - 2011-06-18 15:41:07 --> Controller Class Initialized
DEBUG - 2011-06-18 15:41:07 --> Model Class Initialized
DEBUG - 2011-06-18 15:41:07 --> Model Class Initialized
DEBUG - 2011-06-18 15:41:07 --> Model Class Initialized
DEBUG - 2011-06-18 15:41:07 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-18 15:41:07 --> Database Driver Class Initialized
DEBUG - 2011-06-18 15:41:07 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-18 15:41:07 --> Helper loaded: url_helper
DEBUG - 2011-06-18 15:41:07 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-18 15:41:07 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-18 15:41:07 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-18 15:41:07 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-18 15:41:07 --> Final output sent to browser
DEBUG - 2011-06-18 15:41:07 --> Total execution time: 0.1587
DEBUG - 2011-06-18 15:41:09 --> Config Class Initialized
DEBUG - 2011-06-18 15:41:09 --> Hooks Class Initialized
DEBUG - 2011-06-18 15:41:09 --> Utf8 Class Initialized
DEBUG - 2011-06-18 15:41:09 --> UTF-8 Support Enabled
DEBUG - 2011-06-18 15:41:09 --> URI Class Initialized
DEBUG - 2011-06-18 15:41:09 --> Router Class Initialized
ERROR - 2011-06-18 15:41:09 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-18 15:41:17 --> Config Class Initialized
DEBUG - 2011-06-18 15:41:17 --> Hooks Class Initialized
DEBUG - 2011-06-18 15:41:17 --> Utf8 Class Initialized
DEBUG - 2011-06-18 15:41:17 --> UTF-8 Support Enabled
DEBUG - 2011-06-18 15:41:17 --> URI Class Initialized
DEBUG - 2011-06-18 15:41:17 --> Router Class Initialized
DEBUG - 2011-06-18 15:41:17 --> Output Class Initialized
DEBUG - 2011-06-18 15:41:17 --> Input Class Initialized
DEBUG - 2011-06-18 15:41:17 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-18 15:41:17 --> Language Class Initialized
DEBUG - 2011-06-18 15:41:17 --> Loader Class Initialized
DEBUG - 2011-06-18 15:41:17 --> Controller Class Initialized
DEBUG - 2011-06-18 15:41:17 --> Model Class Initialized
DEBUG - 2011-06-18 15:41:17 --> Model Class Initialized
DEBUG - 2011-06-18 15:41:17 --> Model Class Initialized
DEBUG - 2011-06-18 15:41:17 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-18 15:41:17 --> Database Driver Class Initialized
DEBUG - 2011-06-18 15:41:18 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-18 15:41:18 --> Helper loaded: url_helper
DEBUG - 2011-06-18 15:41:18 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-18 15:41:18 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-18 15:41:18 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-18 15:41:18 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-18 15:41:18 --> Final output sent to browser
DEBUG - 2011-06-18 15:41:18 --> Total execution time: 1.0147
DEBUG - 2011-06-18 15:41:20 --> Config Class Initialized
DEBUG - 2011-06-18 15:41:20 --> Hooks Class Initialized
DEBUG - 2011-06-18 15:41:20 --> Utf8 Class Initialized
DEBUG - 2011-06-18 15:41:20 --> UTF-8 Support Enabled
DEBUG - 2011-06-18 15:41:20 --> URI Class Initialized
DEBUG - 2011-06-18 15:41:20 --> Router Class Initialized
ERROR - 2011-06-18 15:41:20 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-18 15:41:25 --> Config Class Initialized
DEBUG - 2011-06-18 15:41:25 --> Hooks Class Initialized
DEBUG - 2011-06-18 15:41:25 --> Utf8 Class Initialized
DEBUG - 2011-06-18 15:41:25 --> UTF-8 Support Enabled
DEBUG - 2011-06-18 15:41:25 --> URI Class Initialized
DEBUG - 2011-06-18 15:41:25 --> Router Class Initialized
DEBUG - 2011-06-18 15:41:26 --> Output Class Initialized
DEBUG - 2011-06-18 15:41:26 --> Input Class Initialized
DEBUG - 2011-06-18 15:41:26 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-18 15:41:26 --> Language Class Initialized
DEBUG - 2011-06-18 15:41:26 --> Loader Class Initialized
DEBUG - 2011-06-18 15:41:26 --> Controller Class Initialized
DEBUG - 2011-06-18 15:41:26 --> Model Class Initialized
DEBUG - 2011-06-18 15:41:26 --> Model Class Initialized
DEBUG - 2011-06-18 15:41:26 --> Model Class Initialized
DEBUG - 2011-06-18 15:41:26 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-18 15:41:26 --> Database Driver Class Initialized
DEBUG - 2011-06-18 15:41:26 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-18 15:41:26 --> Helper loaded: url_helper
DEBUG - 2011-06-18 15:41:26 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-18 15:41:26 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-18 15:41:26 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-18 15:41:26 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-18 15:41:26 --> Final output sent to browser
DEBUG - 2011-06-18 15:41:26 --> Total execution time: 0.0443
DEBUG - 2011-06-18 17:32:49 --> Config Class Initialized
DEBUG - 2011-06-18 17:32:49 --> Hooks Class Initialized
DEBUG - 2011-06-18 17:32:49 --> Utf8 Class Initialized
DEBUG - 2011-06-18 17:32:49 --> UTF-8 Support Enabled
DEBUG - 2011-06-18 17:32:49 --> URI Class Initialized
DEBUG - 2011-06-18 17:32:49 --> Router Class Initialized
DEBUG - 2011-06-18 17:32:49 --> Output Class Initialized
DEBUG - 2011-06-18 17:32:49 --> Input Class Initialized
DEBUG - 2011-06-18 17:32:49 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-18 17:32:49 --> Language Class Initialized
DEBUG - 2011-06-18 17:32:49 --> Loader Class Initialized
DEBUG - 2011-06-18 17:32:49 --> Controller Class Initialized
DEBUG - 2011-06-18 17:32:49 --> Model Class Initialized
DEBUG - 2011-06-18 17:32:49 --> Model Class Initialized
DEBUG - 2011-06-18 17:32:49 --> Model Class Initialized
DEBUG - 2011-06-18 17:32:49 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-18 17:32:49 --> Database Driver Class Initialized
DEBUG - 2011-06-18 17:32:49 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-18 17:32:50 --> Helper loaded: url_helper
DEBUG - 2011-06-18 17:32:50 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-18 17:32:50 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-18 17:32:50 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-18 17:32:50 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-18 17:32:50 --> Final output sent to browser
DEBUG - 2011-06-18 17:32:50 --> Total execution time: 0.5615
DEBUG - 2011-06-18 17:32:52 --> Config Class Initialized
DEBUG - 2011-06-18 17:32:52 --> Hooks Class Initialized
DEBUG - 2011-06-18 17:32:52 --> Utf8 Class Initialized
DEBUG - 2011-06-18 17:32:52 --> UTF-8 Support Enabled
DEBUG - 2011-06-18 17:32:52 --> URI Class Initialized
DEBUG - 2011-06-18 17:32:52 --> Router Class Initialized
DEBUG - 2011-06-18 17:32:52 --> Output Class Initialized
DEBUG - 2011-06-18 17:32:52 --> Input Class Initialized
DEBUG - 2011-06-18 17:32:52 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-18 17:32:52 --> Language Class Initialized
DEBUG - 2011-06-18 17:32:52 --> Loader Class Initialized
DEBUG - 2011-06-18 17:32:52 --> Controller Class Initialized
ERROR - 2011-06-18 17:32:52 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-18 17:32:52 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-18 17:32:52 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-18 17:32:52 --> Model Class Initialized
DEBUG - 2011-06-18 17:32:52 --> Model Class Initialized
DEBUG - 2011-06-18 17:32:52 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-18 17:32:52 --> Database Driver Class Initialized
DEBUG - 2011-06-18 17:32:52 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-18 17:32:52 --> Helper loaded: url_helper
DEBUG - 2011-06-18 17:32:52 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-18 17:32:52 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-18 17:32:52 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-18 17:32:52 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-18 17:32:52 --> Final output sent to browser
DEBUG - 2011-06-18 17:32:52 --> Total execution time: 0.0929
DEBUG - 2011-06-18 19:46:58 --> Config Class Initialized
DEBUG - 2011-06-18 19:46:58 --> Hooks Class Initialized
DEBUG - 2011-06-18 19:46:58 --> Utf8 Class Initialized
DEBUG - 2011-06-18 19:46:58 --> UTF-8 Support Enabled
DEBUG - 2011-06-18 19:46:58 --> URI Class Initialized
DEBUG - 2011-06-18 19:46:58 --> Router Class Initialized
ERROR - 2011-06-18 19:46:58 --> 404 Page Not Found --> robots.txt

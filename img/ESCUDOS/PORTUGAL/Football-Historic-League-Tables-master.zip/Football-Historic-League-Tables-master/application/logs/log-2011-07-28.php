<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2011-07-28 02:40:20 --> Config Class Initialized
DEBUG - 2011-07-28 02:40:20 --> Hooks Class Initialized
DEBUG - 2011-07-28 02:40:20 --> Utf8 Class Initialized
DEBUG - 2011-07-28 02:40:20 --> UTF-8 Support Enabled
DEBUG - 2011-07-28 02:40:20 --> URI Class Initialized
DEBUG - 2011-07-28 02:40:20 --> Router Class Initialized
ERROR - 2011-07-28 02:40:20 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-07-28 02:42:06 --> Config Class Initialized
DEBUG - 2011-07-28 02:42:06 --> Hooks Class Initialized
DEBUG - 2011-07-28 02:42:06 --> Utf8 Class Initialized
DEBUG - 2011-07-28 02:42:06 --> UTF-8 Support Enabled
DEBUG - 2011-07-28 02:42:06 --> URI Class Initialized
DEBUG - 2011-07-28 02:42:06 --> Router Class Initialized
DEBUG - 2011-07-28 02:42:06 --> No URI present. Default controller set.
DEBUG - 2011-07-28 02:42:06 --> Output Class Initialized
DEBUG - 2011-07-28 02:42:06 --> Input Class Initialized
DEBUG - 2011-07-28 02:42:06 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-28 02:42:06 --> Language Class Initialized
DEBUG - 2011-07-28 02:42:06 --> Loader Class Initialized
DEBUG - 2011-07-28 02:42:06 --> Controller Class Initialized
DEBUG - 2011-07-28 02:42:07 --> File loaded: application/views/splash/main.php
DEBUG - 2011-07-28 02:42:07 --> Helper loaded: url_helper
DEBUG - 2011-07-28 02:42:07 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-28 02:42:07 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-28 02:42:07 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-28 02:42:07 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-28 02:42:07 --> Final output sent to browser
DEBUG - 2011-07-28 02:42:07 --> Total execution time: 0.2700
DEBUG - 2011-07-28 02:50:08 --> Config Class Initialized
DEBUG - 2011-07-28 02:50:08 --> Hooks Class Initialized
DEBUG - 2011-07-28 02:50:08 --> Utf8 Class Initialized
DEBUG - 2011-07-28 02:50:08 --> UTF-8 Support Enabled
DEBUG - 2011-07-28 02:50:08 --> URI Class Initialized
DEBUG - 2011-07-28 02:50:08 --> Router Class Initialized
DEBUG - 2011-07-28 02:50:08 --> Output Class Initialized
DEBUG - 2011-07-28 02:50:08 --> Input Class Initialized
DEBUG - 2011-07-28 02:50:08 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-28 02:50:08 --> Language Class Initialized
DEBUG - 2011-07-28 02:50:09 --> Loader Class Initialized
DEBUG - 2011-07-28 02:50:09 --> Controller Class Initialized
ERROR - 2011-07-28 02:50:09 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-28 02:50:09 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-28 02:50:09 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-28 02:50:09 --> Model Class Initialized
DEBUG - 2011-07-28 02:50:09 --> Model Class Initialized
DEBUG - 2011-07-28 02:50:09 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-28 02:50:10 --> Database Driver Class Initialized
DEBUG - 2011-07-28 02:50:14 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-28 02:50:14 --> Helper loaded: url_helper
DEBUG - 2011-07-28 02:50:14 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-28 02:50:14 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-28 02:50:14 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-28 02:50:14 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-28 02:50:14 --> Final output sent to browser
DEBUG - 2011-07-28 02:50:14 --> Total execution time: 5.3814
DEBUG - 2011-07-28 02:51:16 --> Config Class Initialized
DEBUG - 2011-07-28 02:51:16 --> Hooks Class Initialized
DEBUG - 2011-07-28 02:51:16 --> Utf8 Class Initialized
DEBUG - 2011-07-28 02:51:16 --> UTF-8 Support Enabled
DEBUG - 2011-07-28 02:51:16 --> URI Class Initialized
DEBUG - 2011-07-28 02:51:16 --> Router Class Initialized
DEBUG - 2011-07-28 02:51:16 --> Output Class Initialized
DEBUG - 2011-07-28 02:51:16 --> Input Class Initialized
DEBUG - 2011-07-28 02:51:16 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-28 02:51:16 --> Language Class Initialized
DEBUG - 2011-07-28 02:51:16 --> Loader Class Initialized
DEBUG - 2011-07-28 02:51:16 --> Controller Class Initialized
DEBUG - 2011-07-28 02:51:16 --> Model Class Initialized
DEBUG - 2011-07-28 02:51:16 --> Model Class Initialized
DEBUG - 2011-07-28 02:51:16 --> Model Class Initialized
DEBUG - 2011-07-28 02:51:16 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-28 02:51:16 --> Database Driver Class Initialized
DEBUG - 2011-07-28 02:51:16 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-28 02:51:16 --> Helper loaded: url_helper
DEBUG - 2011-07-28 02:51:16 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-28 02:51:16 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-28 02:51:16 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-28 02:51:16 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-28 02:51:16 --> Final output sent to browser
DEBUG - 2011-07-28 02:51:16 --> Total execution time: 0.5592
DEBUG - 2011-07-28 03:51:30 --> Config Class Initialized
DEBUG - 2011-07-28 03:51:30 --> Hooks Class Initialized
DEBUG - 2011-07-28 03:51:30 --> Utf8 Class Initialized
DEBUG - 2011-07-28 03:51:30 --> UTF-8 Support Enabled
DEBUG - 2011-07-28 03:51:30 --> URI Class Initialized
DEBUG - 2011-07-28 03:51:30 --> Router Class Initialized
DEBUG - 2011-07-28 03:51:30 --> Output Class Initialized
DEBUG - 2011-07-28 03:51:30 --> Input Class Initialized
DEBUG - 2011-07-28 03:51:30 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-28 03:51:30 --> Language Class Initialized
DEBUG - 2011-07-28 03:51:30 --> Loader Class Initialized
DEBUG - 2011-07-28 03:51:30 --> Controller Class Initialized
DEBUG - 2011-07-28 03:51:30 --> Model Class Initialized
DEBUG - 2011-07-28 03:51:30 --> Model Class Initialized
DEBUG - 2011-07-28 03:51:31 --> Model Class Initialized
DEBUG - 2011-07-28 03:51:31 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-28 03:51:31 --> Database Driver Class Initialized
DEBUG - 2011-07-28 03:51:33 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-28 03:51:33 --> Helper loaded: url_helper
DEBUG - 2011-07-28 03:51:33 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-28 03:51:33 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-28 03:51:33 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-28 03:51:33 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-28 03:51:33 --> Final output sent to browser
DEBUG - 2011-07-28 03:51:33 --> Total execution time: 3.1666
DEBUG - 2011-07-28 03:51:37 --> Config Class Initialized
DEBUG - 2011-07-28 03:51:37 --> Hooks Class Initialized
DEBUG - 2011-07-28 03:51:37 --> Utf8 Class Initialized
DEBUG - 2011-07-28 03:51:37 --> UTF-8 Support Enabled
DEBUG - 2011-07-28 03:51:37 --> URI Class Initialized
DEBUG - 2011-07-28 03:51:37 --> Router Class Initialized
DEBUG - 2011-07-28 03:51:37 --> Output Class Initialized
DEBUG - 2011-07-28 03:51:37 --> Input Class Initialized
DEBUG - 2011-07-28 03:51:37 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-28 03:51:37 --> Language Class Initialized
DEBUG - 2011-07-28 03:51:37 --> Loader Class Initialized
DEBUG - 2011-07-28 03:51:37 --> Controller Class Initialized
ERROR - 2011-07-28 03:51:37 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-28 03:51:37 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-28 03:51:37 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-28 03:51:37 --> Model Class Initialized
DEBUG - 2011-07-28 03:51:37 --> Model Class Initialized
DEBUG - 2011-07-28 03:51:37 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-28 03:51:37 --> Database Driver Class Initialized
DEBUG - 2011-07-28 03:51:37 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-28 03:51:37 --> Helper loaded: url_helper
DEBUG - 2011-07-28 03:51:37 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-28 03:51:37 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-28 03:51:37 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-28 03:51:37 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-28 03:51:37 --> Final output sent to browser
DEBUG - 2011-07-28 03:51:37 --> Total execution time: 0.1082
DEBUG - 2011-07-28 04:59:03 --> Config Class Initialized
DEBUG - 2011-07-28 04:59:03 --> Hooks Class Initialized
DEBUG - 2011-07-28 04:59:03 --> Utf8 Class Initialized
DEBUG - 2011-07-28 04:59:03 --> UTF-8 Support Enabled
DEBUG - 2011-07-28 04:59:03 --> URI Class Initialized
DEBUG - 2011-07-28 04:59:03 --> Router Class Initialized
DEBUG - 2011-07-28 04:59:03 --> Output Class Initialized
DEBUG - 2011-07-28 04:59:03 --> Input Class Initialized
DEBUG - 2011-07-28 04:59:03 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-28 04:59:03 --> Language Class Initialized
DEBUG - 2011-07-28 04:59:03 --> Loader Class Initialized
DEBUG - 2011-07-28 04:59:03 --> Controller Class Initialized
DEBUG - 2011-07-28 04:59:03 --> Model Class Initialized
DEBUG - 2011-07-28 04:59:03 --> Model Class Initialized
DEBUG - 2011-07-28 04:59:03 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-28 04:59:03 --> Database Driver Class Initialized
DEBUG - 2011-07-28 04:59:04 --> Final output sent to browser
DEBUG - 2011-07-28 04:59:04 --> Total execution time: 1.0038
DEBUG - 2011-07-28 09:06:48 --> Config Class Initialized
DEBUG - 2011-07-28 09:06:48 --> Hooks Class Initialized
DEBUG - 2011-07-28 09:06:48 --> Utf8 Class Initialized
DEBUG - 2011-07-28 09:06:48 --> UTF-8 Support Enabled
DEBUG - 2011-07-28 09:06:48 --> URI Class Initialized
DEBUG - 2011-07-28 09:06:48 --> Router Class Initialized
DEBUG - 2011-07-28 09:06:48 --> No URI present. Default controller set.
DEBUG - 2011-07-28 09:06:48 --> Output Class Initialized
DEBUG - 2011-07-28 09:06:48 --> Input Class Initialized
DEBUG - 2011-07-28 09:06:48 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-28 09:06:48 --> Language Class Initialized
DEBUG - 2011-07-28 09:06:48 --> Loader Class Initialized
DEBUG - 2011-07-28 09:06:48 --> Controller Class Initialized
DEBUG - 2011-07-28 09:06:48 --> File loaded: application/views/splash/main.php
DEBUG - 2011-07-28 09:06:48 --> Helper loaded: url_helper
DEBUG - 2011-07-28 09:06:48 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-28 09:06:48 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-28 09:06:48 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-28 09:06:48 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-28 09:06:48 --> Final output sent to browser
DEBUG - 2011-07-28 09:06:48 --> Total execution time: 0.2066
DEBUG - 2011-07-28 09:06:50 --> Config Class Initialized
DEBUG - 2011-07-28 09:06:50 --> Hooks Class Initialized
DEBUG - 2011-07-28 09:06:50 --> Utf8 Class Initialized
DEBUG - 2011-07-28 09:06:50 --> UTF-8 Support Enabled
DEBUG - 2011-07-28 09:06:50 --> URI Class Initialized
DEBUG - 2011-07-28 09:06:50 --> Router Class Initialized
ERROR - 2011-07-28 09:06:50 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-28 09:06:52 --> Config Class Initialized
DEBUG - 2011-07-28 09:06:52 --> Hooks Class Initialized
DEBUG - 2011-07-28 09:06:52 --> Utf8 Class Initialized
DEBUG - 2011-07-28 09:06:52 --> UTF-8 Support Enabled
DEBUG - 2011-07-28 09:06:52 --> URI Class Initialized
DEBUG - 2011-07-28 09:06:52 --> Router Class Initialized
ERROR - 2011-07-28 09:06:52 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-28 09:07:18 --> Config Class Initialized
DEBUG - 2011-07-28 09:07:18 --> Hooks Class Initialized
DEBUG - 2011-07-28 09:07:18 --> Utf8 Class Initialized
DEBUG - 2011-07-28 09:07:18 --> UTF-8 Support Enabled
DEBUG - 2011-07-28 09:07:18 --> URI Class Initialized
DEBUG - 2011-07-28 09:07:18 --> Router Class Initialized
DEBUG - 2011-07-28 09:07:18 --> No URI present. Default controller set.
DEBUG - 2011-07-28 09:07:18 --> Output Class Initialized
DEBUG - 2011-07-28 09:07:18 --> Input Class Initialized
DEBUG - 2011-07-28 09:07:18 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-28 09:07:18 --> Language Class Initialized
DEBUG - 2011-07-28 09:07:18 --> Loader Class Initialized
DEBUG - 2011-07-28 09:07:18 --> Controller Class Initialized
DEBUG - 2011-07-28 09:07:18 --> File loaded: application/views/splash/main.php
DEBUG - 2011-07-28 09:07:18 --> Helper loaded: url_helper
DEBUG - 2011-07-28 09:07:18 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-28 09:07:18 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-28 09:07:18 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-28 09:07:18 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-28 09:07:18 --> Final output sent to browser
DEBUG - 2011-07-28 09:07:18 --> Total execution time: 0.0147
DEBUG - 2011-07-28 09:08:58 --> Config Class Initialized
DEBUG - 2011-07-28 09:08:58 --> Hooks Class Initialized
DEBUG - 2011-07-28 09:08:58 --> Utf8 Class Initialized
DEBUG - 2011-07-28 09:08:58 --> UTF-8 Support Enabled
DEBUG - 2011-07-28 09:08:58 --> URI Class Initialized
DEBUG - 2011-07-28 09:08:58 --> Router Class Initialized
DEBUG - 2011-07-28 09:08:58 --> Output Class Initialized
DEBUG - 2011-07-28 09:08:58 --> Input Class Initialized
DEBUG - 2011-07-28 09:08:58 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-28 09:08:58 --> Language Class Initialized
DEBUG - 2011-07-28 09:08:58 --> Loader Class Initialized
DEBUG - 2011-07-28 09:08:58 --> Controller Class Initialized
DEBUG - 2011-07-28 09:08:58 --> Model Class Initialized
DEBUG - 2011-07-28 09:08:58 --> Model Class Initialized
DEBUG - 2011-07-28 09:08:58 --> Model Class Initialized
DEBUG - 2011-07-28 09:08:58 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-28 09:08:58 --> Database Driver Class Initialized
DEBUG - 2011-07-28 09:08:59 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-28 09:08:59 --> Helper loaded: url_helper
DEBUG - 2011-07-28 09:08:59 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-28 09:08:59 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-28 09:08:59 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-28 09:08:59 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-28 09:08:59 --> Final output sent to browser
DEBUG - 2011-07-28 09:08:59 --> Total execution time: 1.1458
DEBUG - 2011-07-28 09:09:30 --> Config Class Initialized
DEBUG - 2011-07-28 09:09:30 --> Hooks Class Initialized
DEBUG - 2011-07-28 09:09:30 --> Utf8 Class Initialized
DEBUG - 2011-07-28 09:09:30 --> UTF-8 Support Enabled
DEBUG - 2011-07-28 09:09:30 --> URI Class Initialized
DEBUG - 2011-07-28 09:09:30 --> Router Class Initialized
ERROR - 2011-07-28 09:09:30 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-07-28 09:09:31 --> Config Class Initialized
DEBUG - 2011-07-28 09:09:31 --> Hooks Class Initialized
DEBUG - 2011-07-28 09:09:31 --> Utf8 Class Initialized
DEBUG - 2011-07-28 09:09:31 --> UTF-8 Support Enabled
DEBUG - 2011-07-28 09:09:31 --> URI Class Initialized
DEBUG - 2011-07-28 09:09:31 --> Router Class Initialized
DEBUG - 2011-07-28 09:09:31 --> Output Class Initialized
DEBUG - 2011-07-28 09:09:31 --> Input Class Initialized
DEBUG - 2011-07-28 09:09:31 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-28 09:09:31 --> Language Class Initialized
DEBUG - 2011-07-28 09:09:31 --> Loader Class Initialized
DEBUG - 2011-07-28 09:09:31 --> Controller Class Initialized
DEBUG - 2011-07-28 09:09:31 --> Model Class Initialized
DEBUG - 2011-07-28 09:09:31 --> Model Class Initialized
DEBUG - 2011-07-28 09:09:31 --> Model Class Initialized
DEBUG - 2011-07-28 09:09:31 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-28 09:09:31 --> Database Driver Class Initialized
DEBUG - 2011-07-28 09:09:31 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-28 09:09:31 --> Helper loaded: url_helper
DEBUG - 2011-07-28 09:09:31 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-28 09:09:31 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-28 09:09:31 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-28 09:09:31 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-28 09:09:31 --> Final output sent to browser
DEBUG - 2011-07-28 09:09:31 --> Total execution time: 0.1260
DEBUG - 2011-07-28 09:09:49 --> Config Class Initialized
DEBUG - 2011-07-28 09:09:49 --> Hooks Class Initialized
DEBUG - 2011-07-28 09:09:49 --> Utf8 Class Initialized
DEBUG - 2011-07-28 09:09:49 --> UTF-8 Support Enabled
DEBUG - 2011-07-28 09:09:49 --> URI Class Initialized
DEBUG - 2011-07-28 09:09:49 --> Router Class Initialized
DEBUG - 2011-07-28 09:09:49 --> Output Class Initialized
DEBUG - 2011-07-28 09:09:49 --> Input Class Initialized
DEBUG - 2011-07-28 09:09:49 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-28 09:09:49 --> Language Class Initialized
DEBUG - 2011-07-28 09:09:49 --> Loader Class Initialized
DEBUG - 2011-07-28 09:09:49 --> Controller Class Initialized
DEBUG - 2011-07-28 09:09:49 --> Model Class Initialized
DEBUG - 2011-07-28 09:09:49 --> Model Class Initialized
DEBUG - 2011-07-28 09:09:49 --> Model Class Initialized
DEBUG - 2011-07-28 09:09:49 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-28 09:09:49 --> Database Driver Class Initialized
DEBUG - 2011-07-28 09:09:50 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-28 09:09:50 --> Helper loaded: url_helper
DEBUG - 2011-07-28 09:09:50 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-28 09:09:50 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-28 09:09:50 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-28 09:09:50 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-28 09:09:50 --> Final output sent to browser
DEBUG - 2011-07-28 09:09:50 --> Total execution time: 1.5933
DEBUG - 2011-07-28 09:10:06 --> Config Class Initialized
DEBUG - 2011-07-28 09:10:06 --> Hooks Class Initialized
DEBUG - 2011-07-28 09:10:06 --> Utf8 Class Initialized
DEBUG - 2011-07-28 09:10:06 --> UTF-8 Support Enabled
DEBUG - 2011-07-28 09:10:06 --> URI Class Initialized
DEBUG - 2011-07-28 09:10:06 --> Router Class Initialized
ERROR - 2011-07-28 09:10:06 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-07-28 09:10:06 --> Config Class Initialized
DEBUG - 2011-07-28 09:10:06 --> Hooks Class Initialized
DEBUG - 2011-07-28 09:10:06 --> Utf8 Class Initialized
DEBUG - 2011-07-28 09:10:06 --> UTF-8 Support Enabled
DEBUG - 2011-07-28 09:10:06 --> URI Class Initialized
DEBUG - 2011-07-28 09:10:06 --> Router Class Initialized
DEBUG - 2011-07-28 09:10:06 --> Output Class Initialized
DEBUG - 2011-07-28 09:10:06 --> Input Class Initialized
DEBUG - 2011-07-28 09:10:06 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-28 09:10:06 --> Language Class Initialized
DEBUG - 2011-07-28 09:10:06 --> Loader Class Initialized
DEBUG - 2011-07-28 09:10:06 --> Controller Class Initialized
DEBUG - 2011-07-28 09:10:06 --> Model Class Initialized
DEBUG - 2011-07-28 09:10:06 --> Model Class Initialized
DEBUG - 2011-07-28 09:10:06 --> Model Class Initialized
DEBUG - 2011-07-28 09:10:06 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-28 09:10:06 --> Database Driver Class Initialized
DEBUG - 2011-07-28 09:10:06 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-28 09:10:06 --> Helper loaded: url_helper
DEBUG - 2011-07-28 09:10:06 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-28 09:10:06 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-28 09:10:06 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-28 09:10:06 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-28 09:10:06 --> Final output sent to browser
DEBUG - 2011-07-28 09:10:06 --> Total execution time: 0.0377
DEBUG - 2011-07-28 09:10:22 --> Config Class Initialized
DEBUG - 2011-07-28 09:10:22 --> Hooks Class Initialized
DEBUG - 2011-07-28 09:10:22 --> Utf8 Class Initialized
DEBUG - 2011-07-28 09:10:22 --> UTF-8 Support Enabled
DEBUG - 2011-07-28 09:10:22 --> URI Class Initialized
DEBUG - 2011-07-28 09:10:22 --> Router Class Initialized
DEBUG - 2011-07-28 09:10:22 --> Output Class Initialized
DEBUG - 2011-07-28 09:10:22 --> Input Class Initialized
DEBUG - 2011-07-28 09:10:22 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-28 09:10:22 --> Language Class Initialized
DEBUG - 2011-07-28 09:10:22 --> Loader Class Initialized
DEBUG - 2011-07-28 09:10:22 --> Controller Class Initialized
DEBUG - 2011-07-28 09:10:22 --> Model Class Initialized
DEBUG - 2011-07-28 09:10:22 --> Model Class Initialized
DEBUG - 2011-07-28 09:10:22 --> Model Class Initialized
DEBUG - 2011-07-28 09:10:22 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-28 09:10:22 --> Database Driver Class Initialized
DEBUG - 2011-07-28 09:10:23 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-28 09:10:23 --> Helper loaded: url_helper
DEBUG - 2011-07-28 09:10:23 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-28 09:10:23 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-28 09:10:23 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-28 09:10:23 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-28 09:10:23 --> Final output sent to browser
DEBUG - 2011-07-28 09:10:23 --> Total execution time: 0.4857
DEBUG - 2011-07-28 09:10:24 --> Config Class Initialized
DEBUG - 2011-07-28 09:10:24 --> Hooks Class Initialized
DEBUG - 2011-07-28 09:10:24 --> Utf8 Class Initialized
DEBUG - 2011-07-28 09:10:24 --> UTF-8 Support Enabled
DEBUG - 2011-07-28 09:10:24 --> URI Class Initialized
DEBUG - 2011-07-28 09:10:24 --> Router Class Initialized
DEBUG - 2011-07-28 09:10:24 --> Output Class Initialized
DEBUG - 2011-07-28 09:10:24 --> Input Class Initialized
DEBUG - 2011-07-28 09:10:24 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-28 09:10:24 --> Language Class Initialized
DEBUG - 2011-07-28 09:10:24 --> Loader Class Initialized
DEBUG - 2011-07-28 09:10:24 --> Controller Class Initialized
DEBUG - 2011-07-28 09:10:24 --> Model Class Initialized
DEBUG - 2011-07-28 09:10:24 --> Model Class Initialized
DEBUG - 2011-07-28 09:10:24 --> Model Class Initialized
DEBUG - 2011-07-28 09:10:24 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-28 09:10:24 --> Database Driver Class Initialized
DEBUG - 2011-07-28 09:10:24 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-28 09:10:24 --> Helper loaded: url_helper
DEBUG - 2011-07-28 09:10:24 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-28 09:10:24 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-28 09:10:24 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-28 09:10:24 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-28 09:10:24 --> Final output sent to browser
DEBUG - 2011-07-28 09:10:24 --> Total execution time: 0.0825
DEBUG - 2011-07-28 09:19:11 --> Config Class Initialized
DEBUG - 2011-07-28 09:19:11 --> Hooks Class Initialized
DEBUG - 2011-07-28 09:19:11 --> Utf8 Class Initialized
DEBUG - 2011-07-28 09:19:11 --> UTF-8 Support Enabled
DEBUG - 2011-07-28 09:19:11 --> URI Class Initialized
DEBUG - 2011-07-28 09:19:11 --> Router Class Initialized
DEBUG - 2011-07-28 09:19:11 --> Output Class Initialized
DEBUG - 2011-07-28 09:19:11 --> Input Class Initialized
DEBUG - 2011-07-28 09:19:11 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-28 09:19:11 --> Language Class Initialized
DEBUG - 2011-07-28 09:19:11 --> Loader Class Initialized
DEBUG - 2011-07-28 09:19:11 --> Controller Class Initialized
ERROR - 2011-07-28 09:19:11 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-28 09:19:11 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-28 09:19:11 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-28 09:19:11 --> Model Class Initialized
DEBUG - 2011-07-28 09:19:11 --> Model Class Initialized
DEBUG - 2011-07-28 09:19:11 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-28 09:19:11 --> Database Driver Class Initialized
DEBUG - 2011-07-28 09:19:11 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-28 09:19:11 --> Helper loaded: url_helper
DEBUG - 2011-07-28 09:19:11 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-28 09:19:11 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-28 09:19:11 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-28 09:19:11 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-28 09:19:11 --> Final output sent to browser
DEBUG - 2011-07-28 09:19:11 --> Total execution time: 0.1287
DEBUG - 2011-07-28 09:19:12 --> Config Class Initialized
DEBUG - 2011-07-28 09:19:12 --> Hooks Class Initialized
DEBUG - 2011-07-28 09:19:12 --> Utf8 Class Initialized
DEBUG - 2011-07-28 09:19:12 --> UTF-8 Support Enabled
DEBUG - 2011-07-28 09:19:12 --> URI Class Initialized
DEBUG - 2011-07-28 09:19:12 --> Router Class Initialized
DEBUG - 2011-07-28 09:19:12 --> Output Class Initialized
DEBUG - 2011-07-28 09:19:12 --> Input Class Initialized
DEBUG - 2011-07-28 09:19:12 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-28 09:19:12 --> Language Class Initialized
DEBUG - 2011-07-28 09:19:12 --> Loader Class Initialized
DEBUG - 2011-07-28 09:19:12 --> Controller Class Initialized
DEBUG - 2011-07-28 09:19:12 --> Model Class Initialized
DEBUG - 2011-07-28 09:19:12 --> Model Class Initialized
DEBUG - 2011-07-28 09:19:12 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-28 09:19:12 --> Database Driver Class Initialized
DEBUG - 2011-07-28 09:19:13 --> Final output sent to browser
DEBUG - 2011-07-28 09:19:13 --> Total execution time: 0.8589
DEBUG - 2011-07-28 10:16:57 --> Config Class Initialized
DEBUG - 2011-07-28 10:16:57 --> Hooks Class Initialized
DEBUG - 2011-07-28 10:16:57 --> Utf8 Class Initialized
DEBUG - 2011-07-28 10:16:57 --> UTF-8 Support Enabled
DEBUG - 2011-07-28 10:16:57 --> URI Class Initialized
DEBUG - 2011-07-28 10:16:57 --> Router Class Initialized
ERROR - 2011-07-28 10:16:57 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-07-28 10:16:58 --> Config Class Initialized
DEBUG - 2011-07-28 10:16:58 --> Hooks Class Initialized
DEBUG - 2011-07-28 10:16:58 --> Utf8 Class Initialized
DEBUG - 2011-07-28 10:16:58 --> UTF-8 Support Enabled
DEBUG - 2011-07-28 10:16:58 --> URI Class Initialized
DEBUG - 2011-07-28 10:16:58 --> Router Class Initialized
DEBUG - 2011-07-28 10:16:58 --> Output Class Initialized
DEBUG - 2011-07-28 10:16:58 --> Input Class Initialized
DEBUG - 2011-07-28 10:16:58 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-28 10:16:58 --> Language Class Initialized
DEBUG - 2011-07-28 10:16:58 --> Loader Class Initialized
DEBUG - 2011-07-28 10:16:58 --> Controller Class Initialized
DEBUG - 2011-07-28 10:16:58 --> Model Class Initialized
DEBUG - 2011-07-28 10:16:58 --> Model Class Initialized
DEBUG - 2011-07-28 10:16:58 --> Model Class Initialized
DEBUG - 2011-07-28 10:16:58 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-28 10:16:58 --> Database Driver Class Initialized
DEBUG - 2011-07-28 10:16:58 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-28 10:16:58 --> Helper loaded: url_helper
DEBUG - 2011-07-28 10:16:58 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-28 10:16:58 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-28 10:16:58 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-28 10:16:58 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-28 10:16:58 --> Final output sent to browser
DEBUG - 2011-07-28 10:16:58 --> Total execution time: 0.5179
DEBUG - 2011-07-28 10:20:22 --> Config Class Initialized
DEBUG - 2011-07-28 10:20:22 --> Hooks Class Initialized
DEBUG - 2011-07-28 10:20:22 --> Utf8 Class Initialized
DEBUG - 2011-07-28 10:20:22 --> UTF-8 Support Enabled
DEBUG - 2011-07-28 10:20:22 --> URI Class Initialized
DEBUG - 2011-07-28 10:20:22 --> Router Class Initialized
ERROR - 2011-07-28 10:20:22 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-07-28 10:21:28 --> Config Class Initialized
DEBUG - 2011-07-28 10:21:28 --> Hooks Class Initialized
DEBUG - 2011-07-28 10:21:28 --> Utf8 Class Initialized
DEBUG - 2011-07-28 10:21:28 --> UTF-8 Support Enabled
DEBUG - 2011-07-28 10:21:28 --> URI Class Initialized
DEBUG - 2011-07-28 10:21:28 --> Router Class Initialized
DEBUG - 2011-07-28 10:21:28 --> Output Class Initialized
DEBUG - 2011-07-28 10:21:28 --> Input Class Initialized
DEBUG - 2011-07-28 10:21:28 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-28 10:21:28 --> Language Class Initialized
DEBUG - 2011-07-28 10:21:28 --> Loader Class Initialized
DEBUG - 2011-07-28 10:21:28 --> Controller Class Initialized
DEBUG - 2011-07-28 10:21:28 --> Model Class Initialized
DEBUG - 2011-07-28 10:21:28 --> Model Class Initialized
DEBUG - 2011-07-28 10:21:28 --> Model Class Initialized
DEBUG - 2011-07-28 10:21:28 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-28 10:21:28 --> Database Driver Class Initialized
DEBUG - 2011-07-28 10:21:28 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-28 10:21:28 --> Helper loaded: url_helper
DEBUG - 2011-07-28 10:21:28 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-28 10:21:28 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-28 10:21:28 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-28 10:21:28 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-28 10:21:28 --> Final output sent to browser
DEBUG - 2011-07-28 10:21:28 --> Total execution time: 0.1343
DEBUG - 2011-07-28 12:08:44 --> Config Class Initialized
DEBUG - 2011-07-28 12:08:44 --> Hooks Class Initialized
DEBUG - 2011-07-28 12:08:44 --> Utf8 Class Initialized
DEBUG - 2011-07-28 12:08:44 --> UTF-8 Support Enabled
DEBUG - 2011-07-28 12:08:44 --> URI Class Initialized
DEBUG - 2011-07-28 12:08:44 --> Router Class Initialized
ERROR - 2011-07-28 12:08:44 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-07-28 12:10:19 --> Config Class Initialized
DEBUG - 2011-07-28 12:10:19 --> Hooks Class Initialized
DEBUG - 2011-07-28 12:10:19 --> Utf8 Class Initialized
DEBUG - 2011-07-28 12:10:19 --> UTF-8 Support Enabled
DEBUG - 2011-07-28 12:10:19 --> URI Class Initialized
DEBUG - 2011-07-28 12:10:19 --> Router Class Initialized
DEBUG - 2011-07-28 12:10:19 --> Output Class Initialized
DEBUG - 2011-07-28 12:10:19 --> Input Class Initialized
DEBUG - 2011-07-28 12:10:19 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-28 12:10:19 --> Language Class Initialized
DEBUG - 2011-07-28 12:10:19 --> Loader Class Initialized
DEBUG - 2011-07-28 12:10:19 --> Controller Class Initialized
DEBUG - 2011-07-28 12:10:19 --> Model Class Initialized
DEBUG - 2011-07-28 12:10:19 --> Model Class Initialized
DEBUG - 2011-07-28 12:10:19 --> Model Class Initialized
DEBUG - 2011-07-28 12:10:20 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-28 12:10:20 --> Database Driver Class Initialized
DEBUG - 2011-07-28 12:10:20 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-28 12:10:20 --> Helper loaded: url_helper
DEBUG - 2011-07-28 12:10:20 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-28 12:10:20 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-28 12:10:20 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-28 12:10:20 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-28 12:10:20 --> Final output sent to browser
DEBUG - 2011-07-28 12:10:20 --> Total execution time: 0.7526
DEBUG - 2011-07-28 12:10:27 --> Config Class Initialized
DEBUG - 2011-07-28 12:10:27 --> Hooks Class Initialized
DEBUG - 2011-07-28 12:10:27 --> Utf8 Class Initialized
DEBUG - 2011-07-28 12:10:27 --> UTF-8 Support Enabled
DEBUG - 2011-07-28 12:10:27 --> URI Class Initialized
DEBUG - 2011-07-28 12:10:27 --> Router Class Initialized
DEBUG - 2011-07-28 12:10:27 --> Output Class Initialized
DEBUG - 2011-07-28 12:10:27 --> Input Class Initialized
DEBUG - 2011-07-28 12:10:27 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-28 12:10:27 --> Language Class Initialized
DEBUG - 2011-07-28 12:10:27 --> Loader Class Initialized
DEBUG - 2011-07-28 12:10:27 --> Controller Class Initialized
ERROR - 2011-07-28 12:10:27 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-28 12:10:27 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-28 12:10:27 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-28 12:10:27 --> Model Class Initialized
DEBUG - 2011-07-28 12:10:27 --> Model Class Initialized
DEBUG - 2011-07-28 12:10:27 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-28 12:10:27 --> Database Driver Class Initialized
DEBUG - 2011-07-28 12:10:27 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-28 12:10:27 --> Helper loaded: url_helper
DEBUG - 2011-07-28 12:10:27 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-28 12:10:27 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-28 12:10:27 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-28 12:10:27 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-28 12:10:27 --> Final output sent to browser
DEBUG - 2011-07-28 12:10:27 --> Total execution time: 0.0841
DEBUG - 2011-07-28 16:20:30 --> Config Class Initialized
DEBUG - 2011-07-28 16:20:30 --> Hooks Class Initialized
DEBUG - 2011-07-28 16:20:30 --> Utf8 Class Initialized
DEBUG - 2011-07-28 16:20:30 --> UTF-8 Support Enabled
DEBUG - 2011-07-28 16:20:30 --> URI Class Initialized
DEBUG - 2011-07-28 16:20:30 --> Router Class Initialized
DEBUG - 2011-07-28 16:20:30 --> Output Class Initialized
DEBUG - 2011-07-28 16:20:30 --> Input Class Initialized
DEBUG - 2011-07-28 16:20:30 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-28 16:20:30 --> Language Class Initialized
DEBUG - 2011-07-28 16:20:30 --> Loader Class Initialized
DEBUG - 2011-07-28 16:20:30 --> Controller Class Initialized
DEBUG - 2011-07-28 16:20:30 --> Model Class Initialized
DEBUG - 2011-07-28 16:20:30 --> Model Class Initialized
DEBUG - 2011-07-28 16:20:30 --> Model Class Initialized
DEBUG - 2011-07-28 16:20:30 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-28 16:20:30 --> Database Driver Class Initialized
DEBUG - 2011-07-28 16:20:31 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-28 16:20:31 --> Helper loaded: url_helper
DEBUG - 2011-07-28 16:20:31 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-28 16:20:31 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-28 16:20:31 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-28 16:20:31 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-28 16:20:31 --> Final output sent to browser
DEBUG - 2011-07-28 16:20:31 --> Total execution time: 1.0647
DEBUG - 2011-07-28 16:20:31 --> Config Class Initialized
DEBUG - 2011-07-28 16:20:31 --> Hooks Class Initialized
DEBUG - 2011-07-28 16:20:31 --> Utf8 Class Initialized
DEBUG - 2011-07-28 16:20:31 --> UTF-8 Support Enabled
DEBUG - 2011-07-28 16:20:31 --> URI Class Initialized
DEBUG - 2011-07-28 16:20:31 --> Router Class Initialized
DEBUG - 2011-07-28 16:20:31 --> Config Class Initialized
DEBUG - 2011-07-28 16:20:31 --> Hooks Class Initialized
DEBUG - 2011-07-28 16:20:31 --> Utf8 Class Initialized
DEBUG - 2011-07-28 16:20:31 --> UTF-8 Support Enabled
DEBUG - 2011-07-28 16:20:31 --> URI Class Initialized
DEBUG - 2011-07-28 16:20:31 --> Output Class Initialized
DEBUG - 2011-07-28 16:20:31 --> Router Class Initialized
DEBUG - 2011-07-28 16:20:31 --> Input Class Initialized
DEBUG - 2011-07-28 16:20:31 --> Global POST and COOKIE data sanitized
ERROR - 2011-07-28 16:20:31 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-28 16:20:31 --> Language Class Initialized
DEBUG - 2011-07-28 16:20:31 --> Loader Class Initialized
DEBUG - 2011-07-28 16:20:31 --> Controller Class Initialized
ERROR - 2011-07-28 16:20:31 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-28 16:20:31 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-28 16:20:31 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-28 16:20:31 --> Model Class Initialized
DEBUG - 2011-07-28 16:20:31 --> Model Class Initialized
DEBUG - 2011-07-28 16:20:31 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-28 16:20:31 --> Database Driver Class Initialized
DEBUG - 2011-07-28 16:20:31 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-28 16:20:31 --> Helper loaded: url_helper
DEBUG - 2011-07-28 16:20:31 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-28 16:20:31 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-28 16:20:31 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-28 16:20:31 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-28 16:20:31 --> Final output sent to browser
DEBUG - 2011-07-28 16:20:31 --> Total execution time: 0.0759
DEBUG - 2011-07-28 16:20:32 --> Config Class Initialized
DEBUG - 2011-07-28 16:20:32 --> Hooks Class Initialized
DEBUG - 2011-07-28 16:20:32 --> Utf8 Class Initialized
DEBUG - 2011-07-28 16:20:32 --> UTF-8 Support Enabled
DEBUG - 2011-07-28 16:20:32 --> URI Class Initialized
DEBUG - 2011-07-28 16:20:32 --> Router Class Initialized
DEBUG - 2011-07-28 16:20:32 --> Output Class Initialized
DEBUG - 2011-07-28 16:20:32 --> Input Class Initialized
DEBUG - 2011-07-28 16:20:32 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-28 16:20:32 --> Language Class Initialized
DEBUG - 2011-07-28 16:20:32 --> Loader Class Initialized
DEBUG - 2011-07-28 16:20:32 --> Controller Class Initialized
DEBUG - 2011-07-28 16:20:32 --> Model Class Initialized
DEBUG - 2011-07-28 16:20:32 --> Model Class Initialized
DEBUG - 2011-07-28 16:20:32 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-28 16:20:32 --> Database Driver Class Initialized
DEBUG - 2011-07-28 16:20:33 --> Final output sent to browser
DEBUG - 2011-07-28 16:20:33 --> Total execution time: 1.0259
DEBUG - 2011-07-28 16:20:34 --> Config Class Initialized
DEBUG - 2011-07-28 16:20:34 --> Hooks Class Initialized
DEBUG - 2011-07-28 16:20:34 --> Utf8 Class Initialized
DEBUG - 2011-07-28 16:20:34 --> UTF-8 Support Enabled
DEBUG - 2011-07-28 16:20:34 --> URI Class Initialized
DEBUG - 2011-07-28 16:20:34 --> Router Class Initialized
ERROR - 2011-07-28 16:20:34 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-28 16:20:34 --> Config Class Initialized
DEBUG - 2011-07-28 16:20:34 --> Hooks Class Initialized
DEBUG - 2011-07-28 16:20:34 --> Utf8 Class Initialized
DEBUG - 2011-07-28 16:20:34 --> UTF-8 Support Enabled
DEBUG - 2011-07-28 16:20:34 --> URI Class Initialized
DEBUG - 2011-07-28 16:20:34 --> Router Class Initialized
ERROR - 2011-07-28 16:20:34 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-28 16:20:34 --> Config Class Initialized
DEBUG - 2011-07-28 16:20:34 --> Hooks Class Initialized
DEBUG - 2011-07-28 16:20:34 --> Utf8 Class Initialized
DEBUG - 2011-07-28 16:20:34 --> UTF-8 Support Enabled
DEBUG - 2011-07-28 16:20:34 --> URI Class Initialized
DEBUG - 2011-07-28 16:20:34 --> Router Class Initialized
ERROR - 2011-07-28 16:20:34 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-28 16:21:03 --> Config Class Initialized
DEBUG - 2011-07-28 16:21:03 --> Hooks Class Initialized
DEBUG - 2011-07-28 16:21:03 --> Utf8 Class Initialized
DEBUG - 2011-07-28 16:21:03 --> UTF-8 Support Enabled
DEBUG - 2011-07-28 16:21:03 --> URI Class Initialized
DEBUG - 2011-07-28 16:21:03 --> Router Class Initialized
DEBUG - 2011-07-28 16:21:03 --> Output Class Initialized
DEBUG - 2011-07-28 16:21:03 --> Input Class Initialized
DEBUG - 2011-07-28 16:21:03 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-28 16:21:03 --> Language Class Initialized
DEBUG - 2011-07-28 16:21:03 --> Loader Class Initialized
DEBUG - 2011-07-28 16:21:03 --> Controller Class Initialized
ERROR - 2011-07-28 16:21:03 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-28 16:21:03 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-28 16:21:03 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-28 16:21:03 --> Model Class Initialized
DEBUG - 2011-07-28 16:21:03 --> Model Class Initialized
DEBUG - 2011-07-28 16:21:03 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-28 16:21:03 --> Database Driver Class Initialized
DEBUG - 2011-07-28 16:21:03 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-28 16:21:03 --> Helper loaded: url_helper
DEBUG - 2011-07-28 16:21:03 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-28 16:21:03 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-28 16:21:03 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-28 16:21:03 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-28 16:21:03 --> Final output sent to browser
DEBUG - 2011-07-28 16:21:03 --> Total execution time: 0.0361
DEBUG - 2011-07-28 16:21:04 --> Config Class Initialized
DEBUG - 2011-07-28 16:21:04 --> Hooks Class Initialized
DEBUG - 2011-07-28 16:21:04 --> Utf8 Class Initialized
DEBUG - 2011-07-28 16:21:04 --> UTF-8 Support Enabled
DEBUG - 2011-07-28 16:21:04 --> URI Class Initialized
DEBUG - 2011-07-28 16:21:04 --> Router Class Initialized
DEBUG - 2011-07-28 16:21:04 --> Output Class Initialized
DEBUG - 2011-07-28 16:21:04 --> Input Class Initialized
DEBUG - 2011-07-28 16:21:04 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-28 16:21:04 --> Language Class Initialized
DEBUG - 2011-07-28 16:21:04 --> Loader Class Initialized
DEBUG - 2011-07-28 16:21:04 --> Controller Class Initialized
DEBUG - 2011-07-28 16:21:04 --> Model Class Initialized
DEBUG - 2011-07-28 16:21:04 --> Model Class Initialized
DEBUG - 2011-07-28 16:21:04 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-28 16:21:04 --> Database Driver Class Initialized
DEBUG - 2011-07-28 16:21:04 --> Final output sent to browser
DEBUG - 2011-07-28 16:21:04 --> Total execution time: 0.7197
DEBUG - 2011-07-28 16:21:14 --> Config Class Initialized
DEBUG - 2011-07-28 16:21:14 --> Hooks Class Initialized
DEBUG - 2011-07-28 16:21:14 --> Utf8 Class Initialized
DEBUG - 2011-07-28 16:21:14 --> UTF-8 Support Enabled
DEBUG - 2011-07-28 16:21:14 --> URI Class Initialized
DEBUG - 2011-07-28 16:21:14 --> Router Class Initialized
DEBUG - 2011-07-28 16:21:14 --> Output Class Initialized
DEBUG - 2011-07-28 16:21:14 --> Input Class Initialized
DEBUG - 2011-07-28 16:21:14 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-28 16:21:14 --> Language Class Initialized
DEBUG - 2011-07-28 16:21:14 --> Loader Class Initialized
DEBUG - 2011-07-28 16:21:14 --> Controller Class Initialized
ERROR - 2011-07-28 16:21:14 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-28 16:21:14 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-28 16:21:14 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-28 16:21:14 --> Model Class Initialized
DEBUG - 2011-07-28 16:21:14 --> Model Class Initialized
DEBUG - 2011-07-28 16:21:14 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-28 16:21:14 --> Database Driver Class Initialized
DEBUG - 2011-07-28 16:21:14 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-28 16:21:14 --> Helper loaded: url_helper
DEBUG - 2011-07-28 16:21:14 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-28 16:21:14 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-28 16:21:14 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-28 16:21:14 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-28 16:21:14 --> Final output sent to browser
DEBUG - 2011-07-28 16:21:14 --> Total execution time: 0.0621
DEBUG - 2011-07-28 16:21:14 --> Config Class Initialized
DEBUG - 2011-07-28 16:21:14 --> Hooks Class Initialized
DEBUG - 2011-07-28 16:21:14 --> Utf8 Class Initialized
DEBUG - 2011-07-28 16:21:14 --> UTF-8 Support Enabled
DEBUG - 2011-07-28 16:21:14 --> URI Class Initialized
DEBUG - 2011-07-28 16:21:14 --> Router Class Initialized
DEBUG - 2011-07-28 16:21:14 --> Output Class Initialized
DEBUG - 2011-07-28 16:21:14 --> Input Class Initialized
DEBUG - 2011-07-28 16:21:14 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-28 16:21:14 --> Language Class Initialized
DEBUG - 2011-07-28 16:21:14 --> Loader Class Initialized
DEBUG - 2011-07-28 16:21:14 --> Controller Class Initialized
DEBUG - 2011-07-28 16:21:14 --> Model Class Initialized
DEBUG - 2011-07-28 16:21:14 --> Model Class Initialized
DEBUG - 2011-07-28 16:21:14 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-28 16:21:14 --> Database Driver Class Initialized
DEBUG - 2011-07-28 16:21:15 --> Final output sent to browser
DEBUG - 2011-07-28 16:21:15 --> Total execution time: 0.5477
DEBUG - 2011-07-28 16:21:21 --> Config Class Initialized
DEBUG - 2011-07-28 16:21:21 --> Hooks Class Initialized
DEBUG - 2011-07-28 16:21:21 --> Utf8 Class Initialized
DEBUG - 2011-07-28 16:21:21 --> UTF-8 Support Enabled
DEBUG - 2011-07-28 16:21:21 --> URI Class Initialized
DEBUG - 2011-07-28 16:21:21 --> Router Class Initialized
DEBUG - 2011-07-28 16:21:21 --> Output Class Initialized
DEBUG - 2011-07-28 16:21:21 --> Input Class Initialized
DEBUG - 2011-07-28 16:21:21 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-28 16:21:21 --> Language Class Initialized
DEBUG - 2011-07-28 16:21:21 --> Loader Class Initialized
DEBUG - 2011-07-28 16:21:21 --> Controller Class Initialized
ERROR - 2011-07-28 16:21:21 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-28 16:21:21 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-28 16:21:21 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-28 16:21:21 --> Model Class Initialized
DEBUG - 2011-07-28 16:21:21 --> Model Class Initialized
DEBUG - 2011-07-28 16:21:21 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-28 16:21:21 --> Database Driver Class Initialized
DEBUG - 2011-07-28 16:21:21 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-28 16:21:21 --> Helper loaded: url_helper
DEBUG - 2011-07-28 16:21:21 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-28 16:21:21 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-28 16:21:21 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-28 16:21:21 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-28 16:21:21 --> Final output sent to browser
DEBUG - 2011-07-28 16:21:21 --> Total execution time: 0.0489
DEBUG - 2011-07-28 16:21:22 --> Config Class Initialized
DEBUG - 2011-07-28 16:21:22 --> Hooks Class Initialized
DEBUG - 2011-07-28 16:21:22 --> Utf8 Class Initialized
DEBUG - 2011-07-28 16:21:22 --> UTF-8 Support Enabled
DEBUG - 2011-07-28 16:21:22 --> URI Class Initialized
DEBUG - 2011-07-28 16:21:22 --> Router Class Initialized
DEBUG - 2011-07-28 16:21:22 --> Output Class Initialized
DEBUG - 2011-07-28 16:21:22 --> Input Class Initialized
DEBUG - 2011-07-28 16:21:22 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-28 16:21:22 --> Language Class Initialized
DEBUG - 2011-07-28 16:21:22 --> Loader Class Initialized
DEBUG - 2011-07-28 16:21:22 --> Controller Class Initialized
DEBUG - 2011-07-28 16:21:22 --> Model Class Initialized
DEBUG - 2011-07-28 16:21:22 --> Model Class Initialized
DEBUG - 2011-07-28 16:21:22 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-28 16:21:22 --> Database Driver Class Initialized
DEBUG - 2011-07-28 16:21:22 --> Final output sent to browser
DEBUG - 2011-07-28 16:21:22 --> Total execution time: 0.5923
DEBUG - 2011-07-28 16:21:32 --> Config Class Initialized
DEBUG - 2011-07-28 16:21:32 --> Hooks Class Initialized
DEBUG - 2011-07-28 16:21:32 --> Utf8 Class Initialized
DEBUG - 2011-07-28 16:21:32 --> UTF-8 Support Enabled
DEBUG - 2011-07-28 16:21:32 --> URI Class Initialized
DEBUG - 2011-07-28 16:21:32 --> Router Class Initialized
DEBUG - 2011-07-28 16:21:32 --> Output Class Initialized
DEBUG - 2011-07-28 16:21:32 --> Input Class Initialized
DEBUG - 2011-07-28 16:21:32 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-28 16:21:32 --> Language Class Initialized
DEBUG - 2011-07-28 16:21:32 --> Loader Class Initialized
DEBUG - 2011-07-28 16:21:32 --> Controller Class Initialized
ERROR - 2011-07-28 16:21:32 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-28 16:21:32 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-28 16:21:32 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-28 16:21:32 --> Model Class Initialized
DEBUG - 2011-07-28 16:21:32 --> Model Class Initialized
DEBUG - 2011-07-28 16:21:32 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-28 16:21:32 --> Database Driver Class Initialized
DEBUG - 2011-07-28 16:21:32 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-28 16:21:32 --> Helper loaded: url_helper
DEBUG - 2011-07-28 16:21:32 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-28 16:21:32 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-28 16:21:32 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-28 16:21:32 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-28 16:21:32 --> Final output sent to browser
DEBUG - 2011-07-28 16:21:32 --> Total execution time: 0.0555
DEBUG - 2011-07-28 16:21:32 --> Config Class Initialized
DEBUG - 2011-07-28 16:21:32 --> Hooks Class Initialized
DEBUG - 2011-07-28 16:21:32 --> Utf8 Class Initialized
DEBUG - 2011-07-28 16:21:32 --> UTF-8 Support Enabled
DEBUG - 2011-07-28 16:21:32 --> URI Class Initialized
DEBUG - 2011-07-28 16:21:32 --> Router Class Initialized
DEBUG - 2011-07-28 16:21:32 --> Output Class Initialized
DEBUG - 2011-07-28 16:21:32 --> Input Class Initialized
DEBUG - 2011-07-28 16:21:32 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-28 16:21:32 --> Language Class Initialized
DEBUG - 2011-07-28 16:21:32 --> Loader Class Initialized
DEBUG - 2011-07-28 16:21:32 --> Controller Class Initialized
DEBUG - 2011-07-28 16:21:32 --> Model Class Initialized
DEBUG - 2011-07-28 16:21:32 --> Model Class Initialized
DEBUG - 2011-07-28 16:21:32 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-28 16:21:32 --> Database Driver Class Initialized
DEBUG - 2011-07-28 16:21:33 --> Final output sent to browser
DEBUG - 2011-07-28 16:21:33 --> Total execution time: 0.6250
DEBUG - 2011-07-28 16:21:44 --> Config Class Initialized
DEBUG - 2011-07-28 16:21:44 --> Hooks Class Initialized
DEBUG - 2011-07-28 16:21:44 --> Utf8 Class Initialized
DEBUG - 2011-07-28 16:21:44 --> UTF-8 Support Enabled
DEBUG - 2011-07-28 16:21:44 --> URI Class Initialized
DEBUG - 2011-07-28 16:21:44 --> Router Class Initialized
DEBUG - 2011-07-28 16:21:44 --> Output Class Initialized
DEBUG - 2011-07-28 16:21:44 --> Input Class Initialized
DEBUG - 2011-07-28 16:21:44 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-28 16:21:44 --> Language Class Initialized
DEBUG - 2011-07-28 16:21:44 --> Loader Class Initialized
DEBUG - 2011-07-28 16:21:44 --> Controller Class Initialized
ERROR - 2011-07-28 16:21:44 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-28 16:21:44 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-28 16:21:44 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-28 16:21:44 --> Model Class Initialized
DEBUG - 2011-07-28 16:21:44 --> Model Class Initialized
DEBUG - 2011-07-28 16:21:44 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-28 16:21:44 --> Database Driver Class Initialized
DEBUG - 2011-07-28 16:21:44 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-28 16:21:44 --> Helper loaded: url_helper
DEBUG - 2011-07-28 16:21:44 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-28 16:21:44 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-28 16:21:44 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-28 16:21:44 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-28 16:21:44 --> Final output sent to browser
DEBUG - 2011-07-28 16:21:44 --> Total execution time: 0.0562
DEBUG - 2011-07-28 16:21:45 --> Config Class Initialized
DEBUG - 2011-07-28 16:21:45 --> Hooks Class Initialized
DEBUG - 2011-07-28 16:21:45 --> Utf8 Class Initialized
DEBUG - 2011-07-28 16:21:45 --> UTF-8 Support Enabled
DEBUG - 2011-07-28 16:21:45 --> URI Class Initialized
DEBUG - 2011-07-28 16:21:45 --> Router Class Initialized
DEBUG - 2011-07-28 16:21:45 --> Output Class Initialized
DEBUG - 2011-07-28 16:21:45 --> Input Class Initialized
DEBUG - 2011-07-28 16:21:45 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-28 16:21:45 --> Language Class Initialized
DEBUG - 2011-07-28 16:21:45 --> Loader Class Initialized
DEBUG - 2011-07-28 16:21:45 --> Controller Class Initialized
DEBUG - 2011-07-28 16:21:45 --> Model Class Initialized
DEBUG - 2011-07-28 16:21:45 --> Model Class Initialized
DEBUG - 2011-07-28 16:21:45 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-28 16:21:45 --> Database Driver Class Initialized
DEBUG - 2011-07-28 16:21:45 --> Final output sent to browser
DEBUG - 2011-07-28 16:21:45 --> Total execution time: 0.5662
DEBUG - 2011-07-28 16:21:58 --> Config Class Initialized
DEBUG - 2011-07-28 16:21:58 --> Hooks Class Initialized
DEBUG - 2011-07-28 16:21:58 --> Utf8 Class Initialized
DEBUG - 2011-07-28 16:21:58 --> UTF-8 Support Enabled
DEBUG - 2011-07-28 16:21:58 --> URI Class Initialized
DEBUG - 2011-07-28 16:21:58 --> Router Class Initialized
DEBUG - 2011-07-28 16:21:58 --> Output Class Initialized
DEBUG - 2011-07-28 16:21:58 --> Input Class Initialized
DEBUG - 2011-07-28 16:21:58 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-28 16:21:58 --> Language Class Initialized
DEBUG - 2011-07-28 16:21:58 --> Loader Class Initialized
DEBUG - 2011-07-28 16:21:58 --> Controller Class Initialized
ERROR - 2011-07-28 16:21:58 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-28 16:21:58 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-28 16:21:58 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-28 16:21:58 --> Model Class Initialized
DEBUG - 2011-07-28 16:21:58 --> Model Class Initialized
DEBUG - 2011-07-28 16:21:58 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-28 16:21:58 --> Database Driver Class Initialized
DEBUG - 2011-07-28 16:21:58 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-28 16:21:58 --> Helper loaded: url_helper
DEBUG - 2011-07-28 16:21:58 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-28 16:21:58 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-28 16:21:58 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-28 16:21:58 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-28 16:21:58 --> Final output sent to browser
DEBUG - 2011-07-28 16:21:58 --> Total execution time: 0.0341
DEBUG - 2011-07-28 16:21:58 --> Config Class Initialized
DEBUG - 2011-07-28 16:21:58 --> Hooks Class Initialized
DEBUG - 2011-07-28 16:21:58 --> Utf8 Class Initialized
DEBUG - 2011-07-28 16:21:58 --> UTF-8 Support Enabled
DEBUG - 2011-07-28 16:21:58 --> URI Class Initialized
DEBUG - 2011-07-28 16:21:58 --> Router Class Initialized
DEBUG - 2011-07-28 16:21:58 --> Output Class Initialized
DEBUG - 2011-07-28 16:21:58 --> Input Class Initialized
DEBUG - 2011-07-28 16:21:58 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-28 16:21:58 --> Language Class Initialized
DEBUG - 2011-07-28 16:21:58 --> Loader Class Initialized
DEBUG - 2011-07-28 16:21:58 --> Controller Class Initialized
DEBUG - 2011-07-28 16:21:58 --> Model Class Initialized
DEBUG - 2011-07-28 16:21:58 --> Model Class Initialized
DEBUG - 2011-07-28 16:21:58 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-28 16:21:58 --> Database Driver Class Initialized
DEBUG - 2011-07-28 16:21:59 --> Final output sent to browser
DEBUG - 2011-07-28 16:21:59 --> Total execution time: 0.6336
DEBUG - 2011-07-28 16:26:05 --> Config Class Initialized
DEBUG - 2011-07-28 16:26:05 --> Hooks Class Initialized
DEBUG - 2011-07-28 16:26:05 --> Utf8 Class Initialized
DEBUG - 2011-07-28 16:26:05 --> UTF-8 Support Enabled
DEBUG - 2011-07-28 16:26:05 --> URI Class Initialized
DEBUG - 2011-07-28 16:26:05 --> Router Class Initialized
DEBUG - 2011-07-28 16:26:05 --> Output Class Initialized
DEBUG - 2011-07-28 16:26:05 --> Input Class Initialized
DEBUG - 2011-07-28 16:26:05 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-28 16:26:05 --> Language Class Initialized
DEBUG - 2011-07-28 16:26:05 --> Loader Class Initialized
DEBUG - 2011-07-28 16:26:05 --> Controller Class Initialized
ERROR - 2011-07-28 16:26:05 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-28 16:26:05 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-28 16:26:05 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-28 16:26:05 --> Model Class Initialized
DEBUG - 2011-07-28 16:26:05 --> Model Class Initialized
DEBUG - 2011-07-28 16:26:05 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-28 16:26:05 --> Database Driver Class Initialized
DEBUG - 2011-07-28 16:26:05 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-28 16:26:05 --> Helper loaded: url_helper
DEBUG - 2011-07-28 16:26:05 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-28 16:26:05 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-28 16:26:05 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-28 16:26:05 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-28 16:26:05 --> Final output sent to browser
DEBUG - 2011-07-28 16:26:05 --> Total execution time: 0.0418
DEBUG - 2011-07-28 16:26:06 --> Config Class Initialized
DEBUG - 2011-07-28 16:26:06 --> Hooks Class Initialized
DEBUG - 2011-07-28 16:26:06 --> Utf8 Class Initialized
DEBUG - 2011-07-28 16:26:06 --> UTF-8 Support Enabled
DEBUG - 2011-07-28 16:26:06 --> URI Class Initialized
DEBUG - 2011-07-28 16:26:06 --> Router Class Initialized
DEBUG - 2011-07-28 16:26:06 --> Output Class Initialized
DEBUG - 2011-07-28 16:26:06 --> Input Class Initialized
DEBUG - 2011-07-28 16:26:06 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-28 16:26:06 --> Language Class Initialized
DEBUG - 2011-07-28 16:26:06 --> Loader Class Initialized
DEBUG - 2011-07-28 16:26:06 --> Controller Class Initialized
DEBUG - 2011-07-28 16:26:06 --> Model Class Initialized
DEBUG - 2011-07-28 16:26:06 --> Model Class Initialized
DEBUG - 2011-07-28 16:26:06 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-28 16:26:06 --> Database Driver Class Initialized
DEBUG - 2011-07-28 16:26:06 --> Final output sent to browser
DEBUG - 2011-07-28 16:26:06 --> Total execution time: 0.4584
DEBUG - 2011-07-28 16:26:07 --> Config Class Initialized
DEBUG - 2011-07-28 16:26:07 --> Hooks Class Initialized
DEBUG - 2011-07-28 16:26:07 --> Utf8 Class Initialized
DEBUG - 2011-07-28 16:26:07 --> UTF-8 Support Enabled
DEBUG - 2011-07-28 16:26:07 --> URI Class Initialized
DEBUG - 2011-07-28 16:26:07 --> Router Class Initialized
ERROR - 2011-07-28 16:26:07 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-28 17:11:42 --> Config Class Initialized
DEBUG - 2011-07-28 17:11:42 --> Hooks Class Initialized
DEBUG - 2011-07-28 17:11:42 --> Utf8 Class Initialized
DEBUG - 2011-07-28 17:11:42 --> UTF-8 Support Enabled
DEBUG - 2011-07-28 17:11:42 --> URI Class Initialized
DEBUG - 2011-07-28 17:11:42 --> Router Class Initialized
ERROR - 2011-07-28 17:11:42 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-07-28 17:11:42 --> Config Class Initialized
DEBUG - 2011-07-28 17:11:42 --> Hooks Class Initialized
DEBUG - 2011-07-28 17:11:42 --> Utf8 Class Initialized
DEBUG - 2011-07-28 17:11:42 --> UTF-8 Support Enabled
DEBUG - 2011-07-28 17:11:42 --> URI Class Initialized
DEBUG - 2011-07-28 17:11:42 --> Router Class Initialized
DEBUG - 2011-07-28 17:11:42 --> No URI present. Default controller set.
DEBUG - 2011-07-28 17:11:42 --> Output Class Initialized
DEBUG - 2011-07-28 17:11:42 --> Input Class Initialized
DEBUG - 2011-07-28 17:11:42 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-28 17:11:42 --> Language Class Initialized
DEBUG - 2011-07-28 17:11:42 --> Loader Class Initialized
DEBUG - 2011-07-28 17:11:42 --> Controller Class Initialized
DEBUG - 2011-07-28 17:11:42 --> File loaded: application/views/splash/main.php
DEBUG - 2011-07-28 17:11:42 --> Helper loaded: url_helper
DEBUG - 2011-07-28 17:11:42 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-28 17:11:42 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-28 17:11:42 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-28 17:11:42 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-28 17:11:42 --> Final output sent to browser
DEBUG - 2011-07-28 17:11:42 --> Total execution time: 0.1373
DEBUG - 2011-07-28 20:01:01 --> Config Class Initialized
DEBUG - 2011-07-28 20:01:01 --> Hooks Class Initialized
DEBUG - 2011-07-28 20:01:01 --> Utf8 Class Initialized
DEBUG - 2011-07-28 20:01:01 --> UTF-8 Support Enabled
DEBUG - 2011-07-28 20:01:01 --> URI Class Initialized
DEBUG - 2011-07-28 20:01:01 --> Router Class Initialized
DEBUG - 2011-07-28 20:01:01 --> No URI present. Default controller set.
DEBUG - 2011-07-28 20:01:01 --> Output Class Initialized
DEBUG - 2011-07-28 20:01:01 --> Input Class Initialized
DEBUG - 2011-07-28 20:01:01 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-28 20:01:01 --> Language Class Initialized
DEBUG - 2011-07-28 20:01:01 --> Loader Class Initialized
DEBUG - 2011-07-28 20:01:01 --> Controller Class Initialized
DEBUG - 2011-07-28 20:01:01 --> File loaded: application/views/splash/main.php
DEBUG - 2011-07-28 20:01:01 --> Helper loaded: url_helper
DEBUG - 2011-07-28 20:01:01 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-28 20:01:01 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-28 20:01:01 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-28 20:01:01 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-28 20:01:01 --> Final output sent to browser
DEBUG - 2011-07-28 20:01:01 --> Total execution time: 0.0667
DEBUG - 2011-07-28 20:18:51 --> Config Class Initialized
DEBUG - 2011-07-28 20:18:51 --> Hooks Class Initialized
DEBUG - 2011-07-28 20:18:51 --> Utf8 Class Initialized
DEBUG - 2011-07-28 20:18:51 --> UTF-8 Support Enabled
DEBUG - 2011-07-28 20:18:51 --> URI Class Initialized
DEBUG - 2011-07-28 20:18:51 --> Router Class Initialized
DEBUG - 2011-07-28 20:18:51 --> Output Class Initialized
DEBUG - 2011-07-28 20:18:51 --> Input Class Initialized
DEBUG - 2011-07-28 20:18:51 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-28 20:18:51 --> Language Class Initialized
DEBUG - 2011-07-28 20:18:51 --> Loader Class Initialized
DEBUG - 2011-07-28 20:18:51 --> Controller Class Initialized
ERROR - 2011-07-28 20:18:51 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-28 20:18:51 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-28 20:18:51 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-28 20:18:51 --> Model Class Initialized
DEBUG - 2011-07-28 20:18:51 --> Model Class Initialized
DEBUG - 2011-07-28 20:18:51 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-28 20:18:51 --> Database Driver Class Initialized
DEBUG - 2011-07-28 20:18:51 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-28 20:18:51 --> Helper loaded: url_helper
DEBUG - 2011-07-28 20:18:51 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-28 20:18:51 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-28 20:18:51 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-28 20:18:51 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-28 20:18:51 --> Final output sent to browser
DEBUG - 2011-07-28 20:18:51 --> Total execution time: 0.0673
DEBUG - 2011-07-28 21:35:27 --> Config Class Initialized
DEBUG - 2011-07-28 21:35:27 --> Hooks Class Initialized
DEBUG - 2011-07-28 21:35:27 --> Utf8 Class Initialized
DEBUG - 2011-07-28 21:35:27 --> UTF-8 Support Enabled
DEBUG - 2011-07-28 21:35:27 --> URI Class Initialized
DEBUG - 2011-07-28 21:35:27 --> Router Class Initialized
DEBUG - 2011-07-28 21:35:27 --> Output Class Initialized
DEBUG - 2011-07-28 21:35:27 --> Input Class Initialized
DEBUG - 2011-07-28 21:35:27 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-28 21:35:27 --> Language Class Initialized
DEBUG - 2011-07-28 21:35:27 --> Loader Class Initialized
DEBUG - 2011-07-28 21:35:27 --> Controller Class Initialized
ERROR - 2011-07-28 21:35:27 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-28 21:35:27 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-28 21:35:27 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-28 21:35:27 --> Model Class Initialized
DEBUG - 2011-07-28 21:35:27 --> Model Class Initialized
DEBUG - 2011-07-28 21:35:27 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-28 21:35:27 --> Database Driver Class Initialized
DEBUG - 2011-07-28 21:35:27 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-28 21:35:27 --> Helper loaded: url_helper
DEBUG - 2011-07-28 21:35:27 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-28 21:35:27 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-28 21:35:27 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-28 21:35:27 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-28 21:35:27 --> Final output sent to browser
DEBUG - 2011-07-28 21:35:27 --> Total execution time: 0.0524
DEBUG - 2011-07-28 21:35:28 --> Config Class Initialized
DEBUG - 2011-07-28 21:35:28 --> Hooks Class Initialized
DEBUG - 2011-07-28 21:35:28 --> Utf8 Class Initialized
DEBUG - 2011-07-28 21:35:28 --> UTF-8 Support Enabled
DEBUG - 2011-07-28 21:35:28 --> URI Class Initialized
DEBUG - 2011-07-28 21:35:28 --> Router Class Initialized
DEBUG - 2011-07-28 21:35:28 --> Output Class Initialized
DEBUG - 2011-07-28 21:35:28 --> Input Class Initialized
DEBUG - 2011-07-28 21:35:28 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-28 21:35:28 --> Language Class Initialized
DEBUG - 2011-07-28 21:35:28 --> Loader Class Initialized
DEBUG - 2011-07-28 21:35:28 --> Controller Class Initialized
DEBUG - 2011-07-28 21:35:28 --> Model Class Initialized
DEBUG - 2011-07-28 21:35:28 --> Model Class Initialized
DEBUG - 2011-07-28 21:35:28 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-28 21:35:28 --> Database Driver Class Initialized
DEBUG - 2011-07-28 21:35:28 --> Final output sent to browser
DEBUG - 2011-07-28 21:35:28 --> Total execution time: 0.6224
DEBUG - 2011-07-28 21:35:29 --> Config Class Initialized
DEBUG - 2011-07-28 21:35:29 --> Hooks Class Initialized
DEBUG - 2011-07-28 21:35:29 --> Utf8 Class Initialized
DEBUG - 2011-07-28 21:35:29 --> UTF-8 Support Enabled
DEBUG - 2011-07-28 21:35:29 --> URI Class Initialized
DEBUG - 2011-07-28 21:35:29 --> Router Class Initialized
ERROR - 2011-07-28 21:35:29 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-28 21:35:30 --> Config Class Initialized
DEBUG - 2011-07-28 21:35:30 --> Hooks Class Initialized
DEBUG - 2011-07-28 21:35:30 --> Utf8 Class Initialized
DEBUG - 2011-07-28 21:35:30 --> UTF-8 Support Enabled
DEBUG - 2011-07-28 21:35:30 --> URI Class Initialized
DEBUG - 2011-07-28 21:35:30 --> Router Class Initialized
ERROR - 2011-07-28 21:35:30 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-28 21:35:42 --> Config Class Initialized
DEBUG - 2011-07-28 21:35:42 --> Hooks Class Initialized
DEBUG - 2011-07-28 21:35:42 --> Utf8 Class Initialized
DEBUG - 2011-07-28 21:35:42 --> UTF-8 Support Enabled
DEBUG - 2011-07-28 21:35:42 --> URI Class Initialized
DEBUG - 2011-07-28 21:35:42 --> Router Class Initialized
DEBUG - 2011-07-28 21:35:42 --> Output Class Initialized
DEBUG - 2011-07-28 21:35:42 --> Input Class Initialized
DEBUG - 2011-07-28 21:35:42 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-28 21:35:42 --> Language Class Initialized
DEBUG - 2011-07-28 21:35:42 --> Loader Class Initialized
DEBUG - 2011-07-28 21:35:42 --> Controller Class Initialized
ERROR - 2011-07-28 21:35:42 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-28 21:35:42 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-28 21:35:42 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-28 21:35:42 --> Model Class Initialized
DEBUG - 2011-07-28 21:35:42 --> Model Class Initialized
DEBUG - 2011-07-28 21:35:42 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-28 21:35:42 --> Database Driver Class Initialized
DEBUG - 2011-07-28 21:35:43 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-28 21:35:43 --> Helper loaded: url_helper
DEBUG - 2011-07-28 21:35:43 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-28 21:35:43 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-28 21:35:43 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-28 21:35:43 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-28 21:35:43 --> Final output sent to browser
DEBUG - 2011-07-28 21:35:43 --> Total execution time: 0.0344
DEBUG - 2011-07-28 21:35:43 --> Config Class Initialized
DEBUG - 2011-07-28 21:35:43 --> Hooks Class Initialized
DEBUG - 2011-07-28 21:35:43 --> Utf8 Class Initialized
DEBUG - 2011-07-28 21:35:43 --> UTF-8 Support Enabled
DEBUG - 2011-07-28 21:35:43 --> URI Class Initialized
DEBUG - 2011-07-28 21:35:43 --> Router Class Initialized
DEBUG - 2011-07-28 21:35:43 --> Output Class Initialized
DEBUG - 2011-07-28 21:35:43 --> Input Class Initialized
DEBUG - 2011-07-28 21:35:43 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-28 21:35:43 --> Language Class Initialized
DEBUG - 2011-07-28 21:35:43 --> Loader Class Initialized
DEBUG - 2011-07-28 21:35:43 --> Controller Class Initialized
DEBUG - 2011-07-28 21:35:43 --> Model Class Initialized
DEBUG - 2011-07-28 21:35:43 --> Model Class Initialized
DEBUG - 2011-07-28 21:35:43 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-28 21:35:43 --> Database Driver Class Initialized
DEBUG - 2011-07-28 21:35:43 --> Config Class Initialized
DEBUG - 2011-07-28 21:35:43 --> Hooks Class Initialized
DEBUG - 2011-07-28 21:35:43 --> Utf8 Class Initialized
DEBUG - 2011-07-28 21:35:43 --> UTF-8 Support Enabled
DEBUG - 2011-07-28 21:35:43 --> URI Class Initialized
DEBUG - 2011-07-28 21:35:43 --> Router Class Initialized
ERROR - 2011-07-28 21:35:43 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-07-28 21:35:43 --> Config Class Initialized
DEBUG - 2011-07-28 21:35:43 --> Hooks Class Initialized
DEBUG - 2011-07-28 21:35:43 --> Utf8 Class Initialized
DEBUG - 2011-07-28 21:35:43 --> UTF-8 Support Enabled
DEBUG - 2011-07-28 21:35:43 --> URI Class Initialized
DEBUG - 2011-07-28 21:35:43 --> Router Class Initialized
DEBUG - 2011-07-28 21:35:43 --> Output Class Initialized
DEBUG - 2011-07-28 21:35:43 --> Input Class Initialized
DEBUG - 2011-07-28 21:35:43 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-28 21:35:43 --> Language Class Initialized
DEBUG - 2011-07-28 21:35:43 --> Loader Class Initialized
DEBUG - 2011-07-28 21:35:43 --> Controller Class Initialized
ERROR - 2011-07-28 21:35:43 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-28 21:35:43 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-28 21:35:43 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-28 21:35:43 --> Model Class Initialized
DEBUG - 2011-07-28 21:35:43 --> Model Class Initialized
DEBUG - 2011-07-28 21:35:43 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-28 21:35:43 --> Database Driver Class Initialized
DEBUG - 2011-07-28 21:35:43 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-28 21:35:43 --> Helper loaded: url_helper
DEBUG - 2011-07-28 21:35:43 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-28 21:35:43 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-28 21:35:43 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-28 21:35:43 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-28 21:35:43 --> Final output sent to browser
DEBUG - 2011-07-28 21:35:43 --> Total execution time: 0.0296
DEBUG - 2011-07-28 21:35:43 --> Final output sent to browser
DEBUG - 2011-07-28 21:35:43 --> Total execution time: 0.5987
DEBUG - 2011-07-28 21:35:48 --> Config Class Initialized
DEBUG - 2011-07-28 21:35:48 --> Hooks Class Initialized
DEBUG - 2011-07-28 21:35:48 --> Utf8 Class Initialized
DEBUG - 2011-07-28 21:35:48 --> UTF-8 Support Enabled
DEBUG - 2011-07-28 21:35:48 --> URI Class Initialized
DEBUG - 2011-07-28 21:35:48 --> Router Class Initialized
DEBUG - 2011-07-28 21:35:48 --> Output Class Initialized
DEBUG - 2011-07-28 21:35:48 --> Input Class Initialized
DEBUG - 2011-07-28 21:35:48 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-28 21:35:48 --> Language Class Initialized
DEBUG - 2011-07-28 21:35:48 --> Loader Class Initialized
DEBUG - 2011-07-28 21:35:48 --> Controller Class Initialized
ERROR - 2011-07-28 21:35:48 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-28 21:35:48 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-28 21:35:48 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-28 21:35:48 --> Model Class Initialized
DEBUG - 2011-07-28 21:35:48 --> Model Class Initialized
DEBUG - 2011-07-28 21:35:48 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-28 21:35:48 --> Database Driver Class Initialized
DEBUG - 2011-07-28 21:35:48 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-28 21:35:48 --> Helper loaded: url_helper
DEBUG - 2011-07-28 21:35:48 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-28 21:35:48 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-28 21:35:48 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-28 21:35:48 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-28 21:35:48 --> Final output sent to browser
DEBUG - 2011-07-28 21:35:48 --> Total execution time: 0.0327
DEBUG - 2011-07-28 21:35:48 --> Config Class Initialized
DEBUG - 2011-07-28 21:35:48 --> Hooks Class Initialized
DEBUG - 2011-07-28 21:35:48 --> Utf8 Class Initialized
DEBUG - 2011-07-28 21:35:48 --> UTF-8 Support Enabled
DEBUG - 2011-07-28 21:35:48 --> URI Class Initialized
DEBUG - 2011-07-28 21:35:48 --> Router Class Initialized
DEBUG - 2011-07-28 21:35:48 --> Output Class Initialized
DEBUG - 2011-07-28 21:35:48 --> Input Class Initialized
DEBUG - 2011-07-28 21:35:48 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-28 21:35:48 --> Language Class Initialized
DEBUG - 2011-07-28 21:35:48 --> Loader Class Initialized
DEBUG - 2011-07-28 21:35:48 --> Controller Class Initialized
DEBUG - 2011-07-28 21:35:48 --> Model Class Initialized
DEBUG - 2011-07-28 21:35:48 --> Model Class Initialized
DEBUG - 2011-07-28 21:35:48 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-28 21:35:48 --> Database Driver Class Initialized
DEBUG - 2011-07-28 21:35:49 --> Final output sent to browser
DEBUG - 2011-07-28 21:35:49 --> Total execution time: 0.5842
DEBUG - 2011-07-28 21:35:49 --> Config Class Initialized
DEBUG - 2011-07-28 21:35:49 --> Hooks Class Initialized
DEBUG - 2011-07-28 21:35:49 --> Utf8 Class Initialized
DEBUG - 2011-07-28 21:35:49 --> UTF-8 Support Enabled
DEBUG - 2011-07-28 21:35:49 --> URI Class Initialized
DEBUG - 2011-07-28 21:35:49 --> Router Class Initialized
DEBUG - 2011-07-28 21:35:49 --> Output Class Initialized
DEBUG - 2011-07-28 21:35:49 --> Input Class Initialized
DEBUG - 2011-07-28 21:35:49 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-28 21:35:49 --> Language Class Initialized
DEBUG - 2011-07-28 21:35:49 --> Loader Class Initialized
DEBUG - 2011-07-28 21:35:49 --> Controller Class Initialized
ERROR - 2011-07-28 21:35:49 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-28 21:35:49 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-28 21:35:49 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-28 21:35:49 --> Model Class Initialized
DEBUG - 2011-07-28 21:35:49 --> Model Class Initialized
DEBUG - 2011-07-28 21:35:49 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-28 21:35:49 --> Database Driver Class Initialized
DEBUG - 2011-07-28 21:35:49 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-28 21:35:49 --> Helper loaded: url_helper
DEBUG - 2011-07-28 21:35:49 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-28 21:35:49 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-28 21:35:49 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-28 21:35:49 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-28 21:35:49 --> Final output sent to browser
DEBUG - 2011-07-28 21:35:49 --> Total execution time: 0.0290
DEBUG - 2011-07-28 21:35:54 --> Config Class Initialized
DEBUG - 2011-07-28 21:35:54 --> Hooks Class Initialized
DEBUG - 2011-07-28 21:35:54 --> Utf8 Class Initialized
DEBUG - 2011-07-28 21:35:54 --> UTF-8 Support Enabled
DEBUG - 2011-07-28 21:35:54 --> URI Class Initialized
DEBUG - 2011-07-28 21:35:54 --> Router Class Initialized
DEBUG - 2011-07-28 21:35:54 --> Output Class Initialized
DEBUG - 2011-07-28 21:35:54 --> Input Class Initialized
DEBUG - 2011-07-28 21:35:54 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-28 21:35:54 --> Language Class Initialized
DEBUG - 2011-07-28 21:35:54 --> Loader Class Initialized
DEBUG - 2011-07-28 21:35:54 --> Controller Class Initialized
ERROR - 2011-07-28 21:35:54 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-28 21:35:54 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-28 21:35:54 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-28 21:35:54 --> Model Class Initialized
DEBUG - 2011-07-28 21:35:54 --> Model Class Initialized
DEBUG - 2011-07-28 21:35:54 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-28 21:35:54 --> Database Driver Class Initialized
DEBUG - 2011-07-28 21:35:54 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-28 21:35:54 --> Helper loaded: url_helper
DEBUG - 2011-07-28 21:35:54 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-28 21:35:54 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-28 21:35:54 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-28 21:35:54 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-28 21:35:54 --> Final output sent to browser
DEBUG - 2011-07-28 21:35:54 --> Total execution time: 0.0905
DEBUG - 2011-07-28 21:35:55 --> Config Class Initialized
DEBUG - 2011-07-28 21:35:55 --> Hooks Class Initialized
DEBUG - 2011-07-28 21:35:55 --> Utf8 Class Initialized
DEBUG - 2011-07-28 21:35:55 --> UTF-8 Support Enabled
DEBUG - 2011-07-28 21:35:55 --> URI Class Initialized
DEBUG - 2011-07-28 21:35:55 --> Router Class Initialized
DEBUG - 2011-07-28 21:35:55 --> Output Class Initialized
DEBUG - 2011-07-28 21:35:55 --> Input Class Initialized
DEBUG - 2011-07-28 21:35:55 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-28 21:35:55 --> Language Class Initialized
DEBUG - 2011-07-28 21:35:55 --> Loader Class Initialized
DEBUG - 2011-07-28 21:35:55 --> Controller Class Initialized
DEBUG - 2011-07-28 21:35:55 --> Model Class Initialized
DEBUG - 2011-07-28 21:35:55 --> Model Class Initialized
DEBUG - 2011-07-28 21:35:55 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-28 21:35:55 --> Database Driver Class Initialized
DEBUG - 2011-07-28 21:35:55 --> Config Class Initialized
DEBUG - 2011-07-28 21:35:55 --> Hooks Class Initialized
DEBUG - 2011-07-28 21:35:55 --> Utf8 Class Initialized
DEBUG - 2011-07-28 21:35:55 --> UTF-8 Support Enabled
DEBUG - 2011-07-28 21:35:55 --> URI Class Initialized
DEBUG - 2011-07-28 21:35:55 --> Router Class Initialized
DEBUG - 2011-07-28 21:35:55 --> Output Class Initialized
DEBUG - 2011-07-28 21:35:55 --> Input Class Initialized
DEBUG - 2011-07-28 21:35:55 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-28 21:35:55 --> Language Class Initialized
DEBUG - 2011-07-28 21:35:55 --> Loader Class Initialized
DEBUG - 2011-07-28 21:35:55 --> Controller Class Initialized
ERROR - 2011-07-28 21:35:55 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-28 21:35:55 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-28 21:35:55 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-28 21:35:55 --> Model Class Initialized
DEBUG - 2011-07-28 21:35:55 --> Model Class Initialized
DEBUG - 2011-07-28 21:35:55 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-28 21:35:55 --> Database Driver Class Initialized
DEBUG - 2011-07-28 21:35:55 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-28 21:35:55 --> Helper loaded: url_helper
DEBUG - 2011-07-28 21:35:55 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-28 21:35:55 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-28 21:35:55 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-28 21:35:55 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-28 21:35:55 --> Final output sent to browser
DEBUG - 2011-07-28 21:35:55 --> Total execution time: 0.0902
DEBUG - 2011-07-28 21:35:56 --> Final output sent to browser
DEBUG - 2011-07-28 21:35:56 --> Total execution time: 0.7602
DEBUG - 2011-07-28 21:36:01 --> Config Class Initialized
DEBUG - 2011-07-28 21:36:01 --> Hooks Class Initialized
DEBUG - 2011-07-28 21:36:01 --> Utf8 Class Initialized
DEBUG - 2011-07-28 21:36:01 --> UTF-8 Support Enabled
DEBUG - 2011-07-28 21:36:01 --> URI Class Initialized
DEBUG - 2011-07-28 21:36:01 --> Router Class Initialized
DEBUG - 2011-07-28 21:36:01 --> Output Class Initialized
DEBUG - 2011-07-28 21:36:01 --> Input Class Initialized
DEBUG - 2011-07-28 21:36:01 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-28 21:36:01 --> Language Class Initialized
DEBUG - 2011-07-28 21:36:01 --> Loader Class Initialized
DEBUG - 2011-07-28 21:36:01 --> Controller Class Initialized
ERROR - 2011-07-28 21:36:01 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-28 21:36:01 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-28 21:36:01 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-28 21:36:01 --> Model Class Initialized
DEBUG - 2011-07-28 21:36:01 --> Model Class Initialized
DEBUG - 2011-07-28 21:36:01 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-28 21:36:01 --> Database Driver Class Initialized
DEBUG - 2011-07-28 21:36:01 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-28 21:36:01 --> Helper loaded: url_helper
DEBUG - 2011-07-28 21:36:01 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-28 21:36:01 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-28 21:36:01 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-28 21:36:01 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-28 21:36:01 --> Final output sent to browser
DEBUG - 2011-07-28 21:36:01 --> Total execution time: 0.0306
DEBUG - 2011-07-28 21:36:01 --> Config Class Initialized
DEBUG - 2011-07-28 21:36:01 --> Hooks Class Initialized
DEBUG - 2011-07-28 21:36:01 --> Utf8 Class Initialized
DEBUG - 2011-07-28 21:36:01 --> UTF-8 Support Enabled
DEBUG - 2011-07-28 21:36:01 --> URI Class Initialized
DEBUG - 2011-07-28 21:36:01 --> Router Class Initialized
DEBUG - 2011-07-28 21:36:01 --> Output Class Initialized
DEBUG - 2011-07-28 21:36:01 --> Input Class Initialized
DEBUG - 2011-07-28 21:36:01 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-28 21:36:01 --> Language Class Initialized
DEBUG - 2011-07-28 21:36:01 --> Loader Class Initialized
DEBUG - 2011-07-28 21:36:01 --> Controller Class Initialized
DEBUG - 2011-07-28 21:36:01 --> Model Class Initialized
DEBUG - 2011-07-28 21:36:01 --> Model Class Initialized
DEBUG - 2011-07-28 21:36:01 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-28 21:36:01 --> Database Driver Class Initialized
DEBUG - 2011-07-28 21:36:02 --> Config Class Initialized
DEBUG - 2011-07-28 21:36:02 --> Hooks Class Initialized
DEBUG - 2011-07-28 21:36:02 --> Utf8 Class Initialized
DEBUG - 2011-07-28 21:36:02 --> UTF-8 Support Enabled
DEBUG - 2011-07-28 21:36:02 --> URI Class Initialized
DEBUG - 2011-07-28 21:36:02 --> Router Class Initialized
DEBUG - 2011-07-28 21:36:02 --> Output Class Initialized
DEBUG - 2011-07-28 21:36:02 --> Input Class Initialized
DEBUG - 2011-07-28 21:36:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-28 21:36:02 --> Language Class Initialized
DEBUG - 2011-07-28 21:36:02 --> Loader Class Initialized
DEBUG - 2011-07-28 21:36:02 --> Controller Class Initialized
ERROR - 2011-07-28 21:36:02 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-28 21:36:02 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-28 21:36:02 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-28 21:36:02 --> Model Class Initialized
DEBUG - 2011-07-28 21:36:02 --> Model Class Initialized
DEBUG - 2011-07-28 21:36:02 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-28 21:36:02 --> Database Driver Class Initialized
DEBUG - 2011-07-28 21:36:02 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-28 21:36:02 --> Helper loaded: url_helper
DEBUG - 2011-07-28 21:36:02 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-28 21:36:02 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-28 21:36:02 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-28 21:36:02 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-28 21:36:02 --> Final output sent to browser
DEBUG - 2011-07-28 21:36:02 --> Total execution time: 0.0322
DEBUG - 2011-07-28 21:36:02 --> Final output sent to browser
DEBUG - 2011-07-28 21:36:02 --> Total execution time: 0.6523
DEBUG - 2011-07-28 21:36:26 --> Config Class Initialized
DEBUG - 2011-07-28 21:36:26 --> Hooks Class Initialized
DEBUG - 2011-07-28 21:36:26 --> Utf8 Class Initialized
DEBUG - 2011-07-28 21:36:26 --> UTF-8 Support Enabled
DEBUG - 2011-07-28 21:36:26 --> URI Class Initialized
DEBUG - 2011-07-28 21:36:26 --> Router Class Initialized
DEBUG - 2011-07-28 21:36:26 --> Output Class Initialized
DEBUG - 2011-07-28 21:36:26 --> Input Class Initialized
DEBUG - 2011-07-28 21:36:26 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-28 21:36:26 --> Language Class Initialized
DEBUG - 2011-07-28 21:36:26 --> Loader Class Initialized
DEBUG - 2011-07-28 21:36:26 --> Controller Class Initialized
ERROR - 2011-07-28 21:36:26 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-28 21:36:26 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-28 21:36:26 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-28 21:36:26 --> Model Class Initialized
DEBUG - 2011-07-28 21:36:26 --> Model Class Initialized
DEBUG - 2011-07-28 21:36:26 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-28 21:36:27 --> Database Driver Class Initialized
DEBUG - 2011-07-28 21:36:27 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-28 21:36:27 --> Helper loaded: url_helper
DEBUG - 2011-07-28 21:36:27 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-28 21:36:27 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-28 21:36:27 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-28 21:36:27 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-28 21:36:27 --> Final output sent to browser
DEBUG - 2011-07-28 21:36:27 --> Total execution time: 0.0302
DEBUG - 2011-07-28 21:36:27 --> Config Class Initialized
DEBUG - 2011-07-28 21:36:27 --> Hooks Class Initialized
DEBUG - 2011-07-28 21:36:27 --> Utf8 Class Initialized
DEBUG - 2011-07-28 21:36:27 --> UTF-8 Support Enabled
DEBUG - 2011-07-28 21:36:27 --> URI Class Initialized
DEBUG - 2011-07-28 21:36:27 --> Router Class Initialized
DEBUG - 2011-07-28 21:36:27 --> Output Class Initialized
DEBUG - 2011-07-28 21:36:27 --> Input Class Initialized
DEBUG - 2011-07-28 21:36:27 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-28 21:36:27 --> Language Class Initialized
DEBUG - 2011-07-28 21:36:27 --> Loader Class Initialized
DEBUG - 2011-07-28 21:36:27 --> Controller Class Initialized
DEBUG - 2011-07-28 21:36:27 --> Model Class Initialized
DEBUG - 2011-07-28 21:36:27 --> Model Class Initialized
DEBUG - 2011-07-28 21:36:27 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-28 21:36:27 --> Database Driver Class Initialized
DEBUG - 2011-07-28 21:36:27 --> Final output sent to browser
DEBUG - 2011-07-28 21:36:27 --> Total execution time: 0.5204
DEBUG - 2011-07-28 21:36:28 --> Config Class Initialized
DEBUG - 2011-07-28 21:36:28 --> Hooks Class Initialized
DEBUG - 2011-07-28 21:36:28 --> Utf8 Class Initialized
DEBUG - 2011-07-28 21:36:28 --> UTF-8 Support Enabled
DEBUG - 2011-07-28 21:36:28 --> URI Class Initialized
DEBUG - 2011-07-28 21:36:28 --> Router Class Initialized
DEBUG - 2011-07-28 21:36:28 --> Output Class Initialized
DEBUG - 2011-07-28 21:36:28 --> Input Class Initialized
DEBUG - 2011-07-28 21:36:28 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-28 21:36:28 --> Language Class Initialized
DEBUG - 2011-07-28 21:36:28 --> Loader Class Initialized
DEBUG - 2011-07-28 21:36:28 --> Controller Class Initialized
ERROR - 2011-07-28 21:36:28 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-28 21:36:28 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-28 21:36:28 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-28 21:36:28 --> Model Class Initialized
DEBUG - 2011-07-28 21:36:28 --> Model Class Initialized
DEBUG - 2011-07-28 21:36:28 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-28 21:36:28 --> Database Driver Class Initialized
DEBUG - 2011-07-28 21:36:28 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-28 21:36:28 --> Helper loaded: url_helper
DEBUG - 2011-07-28 21:36:28 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-28 21:36:28 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-28 21:36:28 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-28 21:36:28 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-28 21:36:28 --> Final output sent to browser
DEBUG - 2011-07-28 21:36:28 --> Total execution time: 0.0572
DEBUG - 2011-07-28 21:36:33 --> Config Class Initialized
DEBUG - 2011-07-28 21:36:33 --> Hooks Class Initialized
DEBUG - 2011-07-28 21:36:33 --> Utf8 Class Initialized
DEBUG - 2011-07-28 21:36:33 --> UTF-8 Support Enabled
DEBUG - 2011-07-28 21:36:33 --> URI Class Initialized
DEBUG - 2011-07-28 21:36:33 --> Router Class Initialized
DEBUG - 2011-07-28 21:36:33 --> Output Class Initialized
DEBUG - 2011-07-28 21:36:33 --> Input Class Initialized
DEBUG - 2011-07-28 21:36:33 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-28 21:36:33 --> Language Class Initialized
DEBUG - 2011-07-28 21:36:33 --> Loader Class Initialized
DEBUG - 2011-07-28 21:36:33 --> Controller Class Initialized
ERROR - 2011-07-28 21:36:33 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-28 21:36:33 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-28 21:36:33 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-28 21:36:33 --> Model Class Initialized
DEBUG - 2011-07-28 21:36:33 --> Model Class Initialized
DEBUG - 2011-07-28 21:36:33 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-28 21:36:33 --> Database Driver Class Initialized
DEBUG - 2011-07-28 21:36:33 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-28 21:36:33 --> Helper loaded: url_helper
DEBUG - 2011-07-28 21:36:33 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-28 21:36:33 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-28 21:36:33 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-28 21:36:33 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-28 21:36:33 --> Final output sent to browser
DEBUG - 2011-07-28 21:36:33 --> Total execution time: 0.0611
DEBUG - 2011-07-28 21:36:33 --> Config Class Initialized
DEBUG - 2011-07-28 21:36:33 --> Hooks Class Initialized
DEBUG - 2011-07-28 21:36:33 --> Utf8 Class Initialized
DEBUG - 2011-07-28 21:36:33 --> UTF-8 Support Enabled
DEBUG - 2011-07-28 21:36:33 --> URI Class Initialized
DEBUG - 2011-07-28 21:36:33 --> Router Class Initialized
DEBUG - 2011-07-28 21:36:33 --> Output Class Initialized
DEBUG - 2011-07-28 21:36:33 --> Input Class Initialized
DEBUG - 2011-07-28 21:36:33 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-28 21:36:33 --> Language Class Initialized
DEBUG - 2011-07-28 21:36:33 --> Loader Class Initialized
DEBUG - 2011-07-28 21:36:33 --> Controller Class Initialized
DEBUG - 2011-07-28 21:36:33 --> Model Class Initialized
DEBUG - 2011-07-28 21:36:33 --> Model Class Initialized
DEBUG - 2011-07-28 21:36:33 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-28 21:36:33 --> Database Driver Class Initialized
DEBUG - 2011-07-28 21:36:33 --> Final output sent to browser
DEBUG - 2011-07-28 21:36:33 --> Total execution time: 0.5680
DEBUG - 2011-07-28 21:36:34 --> Config Class Initialized
DEBUG - 2011-07-28 21:36:34 --> Hooks Class Initialized
DEBUG - 2011-07-28 21:36:34 --> Utf8 Class Initialized
DEBUG - 2011-07-28 21:36:34 --> UTF-8 Support Enabled
DEBUG - 2011-07-28 21:36:34 --> URI Class Initialized
DEBUG - 2011-07-28 21:36:34 --> Router Class Initialized
DEBUG - 2011-07-28 21:36:34 --> Output Class Initialized
DEBUG - 2011-07-28 21:36:34 --> Input Class Initialized
DEBUG - 2011-07-28 21:36:34 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-28 21:36:34 --> Language Class Initialized
DEBUG - 2011-07-28 21:36:34 --> Loader Class Initialized
DEBUG - 2011-07-28 21:36:34 --> Controller Class Initialized
ERROR - 2011-07-28 21:36:34 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-28 21:36:34 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-28 21:36:34 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-28 21:36:34 --> Model Class Initialized
DEBUG - 2011-07-28 21:36:34 --> Model Class Initialized
DEBUG - 2011-07-28 21:36:34 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-28 21:36:34 --> Database Driver Class Initialized
DEBUG - 2011-07-28 21:36:34 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-28 21:36:34 --> Helper loaded: url_helper
DEBUG - 2011-07-28 21:36:34 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-28 21:36:34 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-28 21:36:34 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-28 21:36:34 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-28 21:36:34 --> Final output sent to browser
DEBUG - 2011-07-28 21:36:34 --> Total execution time: 0.0276
DEBUG - 2011-07-28 21:36:41 --> Config Class Initialized
DEBUG - 2011-07-28 21:36:41 --> Hooks Class Initialized
DEBUG - 2011-07-28 21:36:41 --> Utf8 Class Initialized
DEBUG - 2011-07-28 21:36:41 --> UTF-8 Support Enabled
DEBUG - 2011-07-28 21:36:41 --> URI Class Initialized
DEBUG - 2011-07-28 21:36:41 --> Router Class Initialized
DEBUG - 2011-07-28 21:36:41 --> Output Class Initialized
DEBUG - 2011-07-28 21:36:41 --> Input Class Initialized
DEBUG - 2011-07-28 21:36:41 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-28 21:36:41 --> Language Class Initialized
DEBUG - 2011-07-28 21:36:41 --> Loader Class Initialized
DEBUG - 2011-07-28 21:36:41 --> Controller Class Initialized
ERROR - 2011-07-28 21:36:41 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-28 21:36:41 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-28 21:36:41 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-28 21:36:41 --> Model Class Initialized
DEBUG - 2011-07-28 21:36:41 --> Model Class Initialized
DEBUG - 2011-07-28 21:36:41 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-28 21:36:41 --> Database Driver Class Initialized
DEBUG - 2011-07-28 21:36:41 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-28 21:36:41 --> Helper loaded: url_helper
DEBUG - 2011-07-28 21:36:41 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-28 21:36:41 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-28 21:36:41 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-28 21:36:41 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-28 21:36:41 --> Final output sent to browser
DEBUG - 2011-07-28 21:36:41 --> Total execution time: 0.1117
DEBUG - 2011-07-28 21:36:42 --> Config Class Initialized
DEBUG - 2011-07-28 21:36:42 --> Hooks Class Initialized
DEBUG - 2011-07-28 21:36:42 --> Utf8 Class Initialized
DEBUG - 2011-07-28 21:36:42 --> UTF-8 Support Enabled
DEBUG - 2011-07-28 21:36:42 --> URI Class Initialized
DEBUG - 2011-07-28 21:36:42 --> Router Class Initialized
DEBUG - 2011-07-28 21:36:42 --> Output Class Initialized
DEBUG - 2011-07-28 21:36:42 --> Input Class Initialized
DEBUG - 2011-07-28 21:36:42 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-28 21:36:42 --> Language Class Initialized
DEBUG - 2011-07-28 21:36:42 --> Loader Class Initialized
DEBUG - 2011-07-28 21:36:42 --> Controller Class Initialized
DEBUG - 2011-07-28 21:36:42 --> Model Class Initialized
DEBUG - 2011-07-28 21:36:42 --> Model Class Initialized
DEBUG - 2011-07-28 21:36:42 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-28 21:36:42 --> Database Driver Class Initialized
DEBUG - 2011-07-28 21:36:42 --> Config Class Initialized
DEBUG - 2011-07-28 21:36:42 --> Hooks Class Initialized
DEBUG - 2011-07-28 21:36:42 --> Utf8 Class Initialized
DEBUG - 2011-07-28 21:36:42 --> UTF-8 Support Enabled
DEBUG - 2011-07-28 21:36:42 --> URI Class Initialized
DEBUG - 2011-07-28 21:36:42 --> Router Class Initialized
DEBUG - 2011-07-28 21:36:42 --> Output Class Initialized
DEBUG - 2011-07-28 21:36:42 --> Input Class Initialized
DEBUG - 2011-07-28 21:36:42 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-28 21:36:42 --> Language Class Initialized
DEBUG - 2011-07-28 21:36:42 --> Loader Class Initialized
DEBUG - 2011-07-28 21:36:42 --> Controller Class Initialized
ERROR - 2011-07-28 21:36:42 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-28 21:36:42 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-28 21:36:42 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-28 21:36:42 --> Model Class Initialized
DEBUG - 2011-07-28 21:36:42 --> Model Class Initialized
DEBUG - 2011-07-28 21:36:42 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-28 21:36:42 --> Database Driver Class Initialized
DEBUG - 2011-07-28 21:36:42 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-28 21:36:42 --> Helper loaded: url_helper
DEBUG - 2011-07-28 21:36:42 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-28 21:36:42 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-28 21:36:42 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-28 21:36:42 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-28 21:36:42 --> Final output sent to browser
DEBUG - 2011-07-28 21:36:42 --> Total execution time: 0.0689
DEBUG - 2011-07-28 21:36:43 --> Config Class Initialized
DEBUG - 2011-07-28 21:36:43 --> Hooks Class Initialized
DEBUG - 2011-07-28 21:36:43 --> Utf8 Class Initialized
DEBUG - 2011-07-28 21:36:43 --> UTF-8 Support Enabled
DEBUG - 2011-07-28 21:36:43 --> URI Class Initialized
DEBUG - 2011-07-28 21:36:43 --> Router Class Initialized
DEBUG - 2011-07-28 21:36:43 --> Output Class Initialized
DEBUG - 2011-07-28 21:36:43 --> Input Class Initialized
DEBUG - 2011-07-28 21:36:43 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-28 21:36:43 --> Language Class Initialized
DEBUG - 2011-07-28 21:36:43 --> Loader Class Initialized
DEBUG - 2011-07-28 21:36:43 --> Controller Class Initialized
ERROR - 2011-07-28 21:36:43 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-28 21:36:43 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-28 21:36:43 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-28 21:36:43 --> Model Class Initialized
DEBUG - 2011-07-28 21:36:43 --> Model Class Initialized
DEBUG - 2011-07-28 21:36:43 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-28 21:36:43 --> Database Driver Class Initialized
DEBUG - 2011-07-28 21:36:43 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-28 21:36:43 --> Helper loaded: url_helper
DEBUG - 2011-07-28 21:36:43 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-28 21:36:43 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-28 21:36:43 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-28 21:36:43 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-28 21:36:43 --> Final output sent to browser
DEBUG - 2011-07-28 21:36:43 --> Total execution time: 0.0657
DEBUG - 2011-07-28 21:36:43 --> Final output sent to browser
DEBUG - 2011-07-28 21:36:43 --> Total execution time: 0.7553
DEBUG - 2011-07-28 21:36:46 --> Config Class Initialized
DEBUG - 2011-07-28 21:36:46 --> Hooks Class Initialized
DEBUG - 2011-07-28 21:36:46 --> Utf8 Class Initialized
DEBUG - 2011-07-28 21:36:46 --> UTF-8 Support Enabled
DEBUG - 2011-07-28 21:36:46 --> URI Class Initialized
DEBUG - 2011-07-28 21:36:46 --> Router Class Initialized
DEBUG - 2011-07-28 21:36:46 --> Output Class Initialized
DEBUG - 2011-07-28 21:36:46 --> Input Class Initialized
DEBUG - 2011-07-28 21:36:46 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-28 21:36:46 --> Language Class Initialized
DEBUG - 2011-07-28 21:36:46 --> Loader Class Initialized
DEBUG - 2011-07-28 21:36:46 --> Controller Class Initialized
ERROR - 2011-07-28 21:36:46 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-28 21:36:46 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-28 21:36:46 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-28 21:36:46 --> Model Class Initialized
DEBUG - 2011-07-28 21:36:46 --> Model Class Initialized
DEBUG - 2011-07-28 21:36:46 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-28 21:36:46 --> Database Driver Class Initialized
DEBUG - 2011-07-28 21:36:46 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-28 21:36:46 --> Helper loaded: url_helper
DEBUG - 2011-07-28 21:36:46 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-28 21:36:46 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-28 21:36:46 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-28 21:36:46 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-28 21:36:46 --> Final output sent to browser
DEBUG - 2011-07-28 21:36:46 --> Total execution time: 0.0718
DEBUG - 2011-07-28 21:36:47 --> Config Class Initialized
DEBUG - 2011-07-28 21:36:47 --> Hooks Class Initialized
DEBUG - 2011-07-28 21:36:47 --> Utf8 Class Initialized
DEBUG - 2011-07-28 21:36:47 --> UTF-8 Support Enabled
DEBUG - 2011-07-28 21:36:47 --> URI Class Initialized
DEBUG - 2011-07-28 21:36:47 --> Router Class Initialized
DEBUG - 2011-07-28 21:36:47 --> Output Class Initialized
DEBUG - 2011-07-28 21:36:47 --> Input Class Initialized
DEBUG - 2011-07-28 21:36:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-28 21:36:47 --> Language Class Initialized
DEBUG - 2011-07-28 21:36:47 --> Loader Class Initialized
DEBUG - 2011-07-28 21:36:47 --> Controller Class Initialized
DEBUG - 2011-07-28 21:36:47 --> Model Class Initialized
DEBUG - 2011-07-28 21:36:47 --> Model Class Initialized
DEBUG - 2011-07-28 21:36:47 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-28 21:36:47 --> Database Driver Class Initialized
DEBUG - 2011-07-28 21:36:47 --> Config Class Initialized
DEBUG - 2011-07-28 21:36:47 --> Hooks Class Initialized
DEBUG - 2011-07-28 21:36:47 --> Utf8 Class Initialized
DEBUG - 2011-07-28 21:36:47 --> UTF-8 Support Enabled
DEBUG - 2011-07-28 21:36:47 --> URI Class Initialized
DEBUG - 2011-07-28 21:36:47 --> Router Class Initialized
DEBUG - 2011-07-28 21:36:47 --> Output Class Initialized
DEBUG - 2011-07-28 21:36:47 --> Input Class Initialized
DEBUG - 2011-07-28 21:36:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-28 21:36:47 --> Language Class Initialized
DEBUG - 2011-07-28 21:36:47 --> Loader Class Initialized
DEBUG - 2011-07-28 21:36:47 --> Controller Class Initialized
ERROR - 2011-07-28 21:36:47 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-28 21:36:47 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-28 21:36:47 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-28 21:36:47 --> Model Class Initialized
DEBUG - 2011-07-28 21:36:47 --> Model Class Initialized
DEBUG - 2011-07-28 21:36:47 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-28 21:36:47 --> Database Driver Class Initialized
DEBUG - 2011-07-28 21:36:47 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-28 21:36:47 --> Helper loaded: url_helper
DEBUG - 2011-07-28 21:36:47 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-28 21:36:47 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-28 21:36:47 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-28 21:36:47 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-28 21:36:47 --> Final output sent to browser
DEBUG - 2011-07-28 21:36:47 --> Total execution time: 0.0852
DEBUG - 2011-07-28 21:36:47 --> Config Class Initialized
DEBUG - 2011-07-28 21:36:47 --> Hooks Class Initialized
DEBUG - 2011-07-28 21:36:47 --> Utf8 Class Initialized
DEBUG - 2011-07-28 21:36:47 --> UTF-8 Support Enabled
DEBUG - 2011-07-28 21:36:47 --> URI Class Initialized
DEBUG - 2011-07-28 21:36:47 --> Router Class Initialized
DEBUG - 2011-07-28 21:36:47 --> Output Class Initialized
DEBUG - 2011-07-28 21:36:47 --> Input Class Initialized
DEBUG - 2011-07-28 21:36:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-28 21:36:47 --> Language Class Initialized
DEBUG - 2011-07-28 21:36:47 --> Loader Class Initialized
DEBUG - 2011-07-28 21:36:47 --> Controller Class Initialized
ERROR - 2011-07-28 21:36:47 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-28 21:36:47 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-28 21:36:47 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-28 21:36:47 --> Model Class Initialized
DEBUG - 2011-07-28 21:36:47 --> Model Class Initialized
DEBUG - 2011-07-28 21:36:47 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-28 21:36:47 --> Final output sent to browser
DEBUG - 2011-07-28 21:36:47 --> Total execution time: 0.6233
DEBUG - 2011-07-28 21:36:47 --> Database Driver Class Initialized
DEBUG - 2011-07-28 21:36:47 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-28 21:36:47 --> Helper loaded: url_helper
DEBUG - 2011-07-28 21:36:47 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-28 21:36:47 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-28 21:36:47 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-28 21:36:47 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-28 21:36:47 --> Final output sent to browser
DEBUG - 2011-07-28 21:36:47 --> Total execution time: 0.1155
DEBUG - 2011-07-28 21:36:52 --> Config Class Initialized
DEBUG - 2011-07-28 21:36:52 --> Hooks Class Initialized
DEBUG - 2011-07-28 21:36:52 --> Utf8 Class Initialized
DEBUG - 2011-07-28 21:36:52 --> UTF-8 Support Enabled
DEBUG - 2011-07-28 21:36:52 --> URI Class Initialized
DEBUG - 2011-07-28 21:36:52 --> Router Class Initialized
DEBUG - 2011-07-28 21:36:52 --> Output Class Initialized
DEBUG - 2011-07-28 21:36:52 --> Input Class Initialized
DEBUG - 2011-07-28 21:36:52 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-28 21:36:52 --> Language Class Initialized
DEBUG - 2011-07-28 21:36:52 --> Loader Class Initialized
DEBUG - 2011-07-28 21:36:52 --> Controller Class Initialized
ERROR - 2011-07-28 21:36:52 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-28 21:36:52 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-28 21:36:52 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-28 21:36:52 --> Model Class Initialized
DEBUG - 2011-07-28 21:36:52 --> Model Class Initialized
DEBUG - 2011-07-28 21:36:52 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-28 21:36:52 --> Database Driver Class Initialized
DEBUG - 2011-07-28 21:36:52 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-28 21:36:52 --> Helper loaded: url_helper
DEBUG - 2011-07-28 21:36:52 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-28 21:36:52 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-28 21:36:52 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-28 21:36:52 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-28 21:36:52 --> Final output sent to browser
DEBUG - 2011-07-28 21:36:52 --> Total execution time: 0.0500
DEBUG - 2011-07-28 21:36:52 --> Config Class Initialized
DEBUG - 2011-07-28 21:36:52 --> Hooks Class Initialized
DEBUG - 2011-07-28 21:36:52 --> Utf8 Class Initialized
DEBUG - 2011-07-28 21:36:52 --> UTF-8 Support Enabled
DEBUG - 2011-07-28 21:36:52 --> URI Class Initialized
DEBUG - 2011-07-28 21:36:52 --> Router Class Initialized
DEBUG - 2011-07-28 21:36:52 --> Output Class Initialized
DEBUG - 2011-07-28 21:36:52 --> Input Class Initialized
DEBUG - 2011-07-28 21:36:52 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-28 21:36:52 --> Language Class Initialized
DEBUG - 2011-07-28 21:36:52 --> Loader Class Initialized
DEBUG - 2011-07-28 21:36:52 --> Controller Class Initialized
DEBUG - 2011-07-28 21:36:52 --> Model Class Initialized
DEBUG - 2011-07-28 21:36:52 --> Model Class Initialized
DEBUG - 2011-07-28 21:36:52 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-28 21:36:52 --> Database Driver Class Initialized
DEBUG - 2011-07-28 21:36:52 --> Config Class Initialized
DEBUG - 2011-07-28 21:36:52 --> Hooks Class Initialized
DEBUG - 2011-07-28 21:36:52 --> Utf8 Class Initialized
DEBUG - 2011-07-28 21:36:52 --> UTF-8 Support Enabled
DEBUG - 2011-07-28 21:36:52 --> URI Class Initialized
DEBUG - 2011-07-28 21:36:52 --> Router Class Initialized
DEBUG - 2011-07-28 21:36:52 --> Output Class Initialized
DEBUG - 2011-07-28 21:36:52 --> Input Class Initialized
DEBUG - 2011-07-28 21:36:52 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-28 21:36:52 --> Language Class Initialized
DEBUG - 2011-07-28 21:36:52 --> Loader Class Initialized
DEBUG - 2011-07-28 21:36:52 --> Controller Class Initialized
ERROR - 2011-07-28 21:36:52 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-28 21:36:52 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-28 21:36:52 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-28 21:36:52 --> Model Class Initialized
DEBUG - 2011-07-28 21:36:52 --> Model Class Initialized
DEBUG - 2011-07-28 21:36:52 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-28 21:36:52 --> Database Driver Class Initialized
DEBUG - 2011-07-28 21:36:52 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-28 21:36:52 --> Helper loaded: url_helper
DEBUG - 2011-07-28 21:36:52 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-28 21:36:52 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-28 21:36:52 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-28 21:36:52 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-28 21:36:52 --> Final output sent to browser
DEBUG - 2011-07-28 21:36:52 --> Total execution time: 0.0845
DEBUG - 2011-07-28 21:36:53 --> Final output sent to browser
DEBUG - 2011-07-28 21:36:53 --> Total execution time: 0.8064
DEBUG - 2011-07-28 21:37:04 --> Config Class Initialized
DEBUG - 2011-07-28 21:37:04 --> Hooks Class Initialized
DEBUG - 2011-07-28 21:37:04 --> Utf8 Class Initialized
DEBUG - 2011-07-28 21:37:04 --> UTF-8 Support Enabled
DEBUG - 2011-07-28 21:37:04 --> URI Class Initialized
DEBUG - 2011-07-28 21:37:04 --> Router Class Initialized
DEBUG - 2011-07-28 21:37:04 --> Output Class Initialized
DEBUG - 2011-07-28 21:37:04 --> Input Class Initialized
DEBUG - 2011-07-28 21:37:04 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-28 21:37:04 --> Language Class Initialized
DEBUG - 2011-07-28 21:37:04 --> Loader Class Initialized
DEBUG - 2011-07-28 21:37:04 --> Controller Class Initialized
ERROR - 2011-07-28 21:37:04 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-28 21:37:04 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-28 21:37:04 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-28 21:37:04 --> Model Class Initialized
DEBUG - 2011-07-28 21:37:04 --> Model Class Initialized
DEBUG - 2011-07-28 21:37:04 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-28 21:37:04 --> Database Driver Class Initialized
DEBUG - 2011-07-28 21:37:04 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-28 21:37:04 --> Helper loaded: url_helper
DEBUG - 2011-07-28 21:37:04 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-28 21:37:04 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-28 21:37:04 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-28 21:37:04 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-28 21:37:04 --> Final output sent to browser
DEBUG - 2011-07-28 21:37:04 --> Total execution time: 0.1313
DEBUG - 2011-07-28 21:37:05 --> Config Class Initialized
DEBUG - 2011-07-28 21:37:05 --> Hooks Class Initialized
DEBUG - 2011-07-28 21:37:05 --> Utf8 Class Initialized
DEBUG - 2011-07-28 21:37:05 --> UTF-8 Support Enabled
DEBUG - 2011-07-28 21:37:05 --> URI Class Initialized
DEBUG - 2011-07-28 21:37:05 --> Router Class Initialized
DEBUG - 2011-07-28 21:37:05 --> Output Class Initialized
DEBUG - 2011-07-28 21:37:05 --> Input Class Initialized
DEBUG - 2011-07-28 21:37:05 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-28 21:37:05 --> Language Class Initialized
DEBUG - 2011-07-28 21:37:05 --> Loader Class Initialized
DEBUG - 2011-07-28 21:37:05 --> Controller Class Initialized
DEBUG - 2011-07-28 21:37:05 --> Model Class Initialized
DEBUG - 2011-07-28 21:37:05 --> Model Class Initialized
DEBUG - 2011-07-28 21:37:05 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-28 21:37:05 --> Database Driver Class Initialized
DEBUG - 2011-07-28 21:37:06 --> Final output sent to browser
DEBUG - 2011-07-28 21:37:06 --> Total execution time: 0.8121
DEBUG - 2011-07-28 21:37:12 --> Config Class Initialized
DEBUG - 2011-07-28 21:37:12 --> Hooks Class Initialized
DEBUG - 2011-07-28 21:37:12 --> Utf8 Class Initialized
DEBUG - 2011-07-28 21:37:12 --> UTF-8 Support Enabled
DEBUG - 2011-07-28 21:37:12 --> URI Class Initialized
DEBUG - 2011-07-28 21:37:12 --> Router Class Initialized
DEBUG - 2011-07-28 21:37:12 --> Output Class Initialized
DEBUG - 2011-07-28 21:37:12 --> Input Class Initialized
DEBUG - 2011-07-28 21:37:12 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-28 21:37:12 --> Language Class Initialized
DEBUG - 2011-07-28 21:37:12 --> Loader Class Initialized
DEBUG - 2011-07-28 21:37:12 --> Controller Class Initialized
ERROR - 2011-07-28 21:37:12 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-28 21:37:12 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-28 21:37:12 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-28 21:37:12 --> Model Class Initialized
DEBUG - 2011-07-28 21:37:12 --> Model Class Initialized
DEBUG - 2011-07-28 21:37:12 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-28 21:37:12 --> Database Driver Class Initialized
DEBUG - 2011-07-28 21:37:12 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-28 21:37:12 --> Helper loaded: url_helper
DEBUG - 2011-07-28 21:37:12 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-28 21:37:12 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-28 21:37:12 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-28 21:37:12 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-28 21:37:12 --> Final output sent to browser
DEBUG - 2011-07-28 21:37:12 --> Total execution time: 0.0296
DEBUG - 2011-07-28 21:37:13 --> Config Class Initialized
DEBUG - 2011-07-28 21:37:13 --> Hooks Class Initialized
DEBUG - 2011-07-28 21:37:13 --> Utf8 Class Initialized
DEBUG - 2011-07-28 21:37:13 --> UTF-8 Support Enabled
DEBUG - 2011-07-28 21:37:13 --> URI Class Initialized
DEBUG - 2011-07-28 21:37:13 --> Router Class Initialized
DEBUG - 2011-07-28 21:37:13 --> Output Class Initialized
DEBUG - 2011-07-28 21:37:13 --> Input Class Initialized
DEBUG - 2011-07-28 21:37:13 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-28 21:37:13 --> Language Class Initialized
DEBUG - 2011-07-28 21:37:13 --> Loader Class Initialized
DEBUG - 2011-07-28 21:37:13 --> Controller Class Initialized
DEBUG - 2011-07-28 21:37:13 --> Model Class Initialized
DEBUG - 2011-07-28 21:37:13 --> Model Class Initialized
DEBUG - 2011-07-28 21:37:13 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-28 21:37:13 --> Database Driver Class Initialized
DEBUG - 2011-07-28 21:37:13 --> Final output sent to browser
DEBUG - 2011-07-28 21:37:13 --> Total execution time: 0.5360
DEBUG - 2011-07-28 21:37:13 --> Config Class Initialized
DEBUG - 2011-07-28 21:37:13 --> Hooks Class Initialized
DEBUG - 2011-07-28 21:37:13 --> Utf8 Class Initialized
DEBUG - 2011-07-28 21:37:13 --> UTF-8 Support Enabled
DEBUG - 2011-07-28 21:37:13 --> URI Class Initialized
DEBUG - 2011-07-28 21:37:13 --> Router Class Initialized
DEBUG - 2011-07-28 21:37:13 --> Output Class Initialized
DEBUG - 2011-07-28 21:37:13 --> Input Class Initialized
DEBUG - 2011-07-28 21:37:13 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-28 21:37:13 --> Language Class Initialized
DEBUG - 2011-07-28 21:37:13 --> Loader Class Initialized
DEBUG - 2011-07-28 21:37:13 --> Controller Class Initialized
ERROR - 2011-07-28 21:37:13 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-28 21:37:13 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-28 21:37:13 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-28 21:37:13 --> Model Class Initialized
DEBUG - 2011-07-28 21:37:13 --> Model Class Initialized
DEBUG - 2011-07-28 21:37:13 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-28 21:37:13 --> Database Driver Class Initialized
DEBUG - 2011-07-28 21:37:13 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-28 21:37:13 --> Helper loaded: url_helper
DEBUG - 2011-07-28 21:37:13 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-28 21:37:13 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-28 21:37:13 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-28 21:37:13 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-28 21:37:13 --> Final output sent to browser
DEBUG - 2011-07-28 21:37:13 --> Total execution time: 0.0284
DEBUG - 2011-07-28 21:37:21 --> Config Class Initialized
DEBUG - 2011-07-28 21:37:21 --> Hooks Class Initialized
DEBUG - 2011-07-28 21:37:21 --> Utf8 Class Initialized
DEBUG - 2011-07-28 21:37:21 --> UTF-8 Support Enabled
DEBUG - 2011-07-28 21:37:21 --> URI Class Initialized
DEBUG - 2011-07-28 21:37:21 --> Router Class Initialized
DEBUG - 2011-07-28 21:37:21 --> Output Class Initialized
DEBUG - 2011-07-28 21:37:21 --> Input Class Initialized
DEBUG - 2011-07-28 21:37:21 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-28 21:37:21 --> Language Class Initialized
DEBUG - 2011-07-28 21:37:21 --> Loader Class Initialized
DEBUG - 2011-07-28 21:37:21 --> Controller Class Initialized
ERROR - 2011-07-28 21:37:21 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-28 21:37:21 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-28 21:37:21 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-28 21:37:21 --> Model Class Initialized
DEBUG - 2011-07-28 21:37:21 --> Model Class Initialized
DEBUG - 2011-07-28 21:37:21 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-28 21:37:21 --> Database Driver Class Initialized
DEBUG - 2011-07-28 21:37:21 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-28 21:37:21 --> Helper loaded: url_helper
DEBUG - 2011-07-28 21:37:21 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-28 21:37:21 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-28 21:37:21 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-28 21:37:21 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-28 21:37:21 --> Final output sent to browser
DEBUG - 2011-07-28 21:37:21 --> Total execution time: 0.0307
DEBUG - 2011-07-28 21:37:21 --> Config Class Initialized
DEBUG - 2011-07-28 21:37:21 --> Hooks Class Initialized
DEBUG - 2011-07-28 21:37:21 --> Utf8 Class Initialized
DEBUG - 2011-07-28 21:37:21 --> UTF-8 Support Enabled
DEBUG - 2011-07-28 21:37:21 --> URI Class Initialized
DEBUG - 2011-07-28 21:37:21 --> Router Class Initialized
DEBUG - 2011-07-28 21:37:21 --> Output Class Initialized
DEBUG - 2011-07-28 21:37:21 --> Input Class Initialized
DEBUG - 2011-07-28 21:37:21 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-28 21:37:21 --> Language Class Initialized
DEBUG - 2011-07-28 21:37:21 --> Loader Class Initialized
DEBUG - 2011-07-28 21:37:21 --> Controller Class Initialized
DEBUG - 2011-07-28 21:37:21 --> Model Class Initialized
DEBUG - 2011-07-28 21:37:21 --> Model Class Initialized
DEBUG - 2011-07-28 21:37:21 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-28 21:37:21 --> Database Driver Class Initialized
DEBUG - 2011-07-28 21:37:21 --> Final output sent to browser
DEBUG - 2011-07-28 21:37:21 --> Total execution time: 0.5937
DEBUG - 2011-07-28 21:37:28 --> Config Class Initialized
DEBUG - 2011-07-28 21:37:28 --> Hooks Class Initialized
DEBUG - 2011-07-28 21:37:28 --> Utf8 Class Initialized
DEBUG - 2011-07-28 21:37:28 --> UTF-8 Support Enabled
DEBUG - 2011-07-28 21:37:28 --> URI Class Initialized
DEBUG - 2011-07-28 21:37:28 --> Router Class Initialized
DEBUG - 2011-07-28 21:37:28 --> Output Class Initialized
DEBUG - 2011-07-28 21:37:28 --> Input Class Initialized
DEBUG - 2011-07-28 21:37:28 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-28 21:37:28 --> Language Class Initialized
DEBUG - 2011-07-28 21:37:28 --> Loader Class Initialized
DEBUG - 2011-07-28 21:37:28 --> Controller Class Initialized
ERROR - 2011-07-28 21:37:28 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-28 21:37:28 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-28 21:37:28 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-28 21:37:28 --> Model Class Initialized
DEBUG - 2011-07-28 21:37:28 --> Model Class Initialized
DEBUG - 2011-07-28 21:37:28 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-28 21:37:28 --> Database Driver Class Initialized
DEBUG - 2011-07-28 21:37:28 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-28 21:37:28 --> Helper loaded: url_helper
DEBUG - 2011-07-28 21:37:28 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-28 21:37:28 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-28 21:37:28 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-28 21:37:28 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-28 21:37:28 --> Final output sent to browser
DEBUG - 2011-07-28 21:37:28 --> Total execution time: 0.0298
DEBUG - 2011-07-28 21:37:28 --> Config Class Initialized
DEBUG - 2011-07-28 21:37:28 --> Hooks Class Initialized
DEBUG - 2011-07-28 21:37:28 --> Utf8 Class Initialized
DEBUG - 2011-07-28 21:37:28 --> UTF-8 Support Enabled
DEBUG - 2011-07-28 21:37:28 --> URI Class Initialized
DEBUG - 2011-07-28 21:37:28 --> Router Class Initialized
DEBUG - 2011-07-28 21:37:28 --> Output Class Initialized
DEBUG - 2011-07-28 21:37:28 --> Input Class Initialized
DEBUG - 2011-07-28 21:37:28 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-28 21:37:28 --> Language Class Initialized
DEBUG - 2011-07-28 21:37:28 --> Loader Class Initialized
DEBUG - 2011-07-28 21:37:28 --> Controller Class Initialized
DEBUG - 2011-07-28 21:37:28 --> Model Class Initialized
DEBUG - 2011-07-28 21:37:28 --> Model Class Initialized
DEBUG - 2011-07-28 21:37:28 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-28 21:37:28 --> Database Driver Class Initialized
DEBUG - 2011-07-28 21:37:28 --> Final output sent to browser
DEBUG - 2011-07-28 21:37:28 --> Total execution time: 0.5674
DEBUG - 2011-07-28 21:37:38 --> Config Class Initialized
DEBUG - 2011-07-28 21:37:38 --> Hooks Class Initialized
DEBUG - 2011-07-28 21:37:38 --> Utf8 Class Initialized
DEBUG - 2011-07-28 21:37:38 --> UTF-8 Support Enabled
DEBUG - 2011-07-28 21:37:38 --> URI Class Initialized
DEBUG - 2011-07-28 21:37:38 --> Router Class Initialized
DEBUG - 2011-07-28 21:37:38 --> Output Class Initialized
DEBUG - 2011-07-28 21:37:38 --> Input Class Initialized
DEBUG - 2011-07-28 21:37:38 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-28 21:37:38 --> Language Class Initialized
DEBUG - 2011-07-28 21:37:38 --> Loader Class Initialized
DEBUG - 2011-07-28 21:37:38 --> Controller Class Initialized
ERROR - 2011-07-28 21:37:38 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-28 21:37:38 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-28 21:37:38 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-28 21:37:38 --> Model Class Initialized
DEBUG - 2011-07-28 21:37:38 --> Model Class Initialized
DEBUG - 2011-07-28 21:37:38 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-28 21:37:38 --> Database Driver Class Initialized
DEBUG - 2011-07-28 21:37:38 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-28 21:37:38 --> Helper loaded: url_helper
DEBUG - 2011-07-28 21:37:38 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-28 21:37:38 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-28 21:37:38 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-28 21:37:39 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-28 21:37:39 --> Final output sent to browser
DEBUG - 2011-07-28 21:37:39 --> Total execution time: 0.0402
DEBUG - 2011-07-28 21:37:39 --> Config Class Initialized
DEBUG - 2011-07-28 21:37:39 --> Hooks Class Initialized
DEBUG - 2011-07-28 21:37:39 --> Utf8 Class Initialized
DEBUG - 2011-07-28 21:37:39 --> UTF-8 Support Enabled
DEBUG - 2011-07-28 21:37:39 --> URI Class Initialized
DEBUG - 2011-07-28 21:37:39 --> Router Class Initialized
DEBUG - 2011-07-28 21:37:39 --> Output Class Initialized
DEBUG - 2011-07-28 21:37:39 --> Input Class Initialized
DEBUG - 2011-07-28 21:37:39 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-28 21:37:39 --> Language Class Initialized
DEBUG - 2011-07-28 21:37:39 --> Loader Class Initialized
DEBUG - 2011-07-28 21:37:39 --> Controller Class Initialized
DEBUG - 2011-07-28 21:37:39 --> Model Class Initialized
DEBUG - 2011-07-28 21:37:39 --> Model Class Initialized
DEBUG - 2011-07-28 21:37:39 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-28 21:37:39 --> Database Driver Class Initialized
DEBUG - 2011-07-28 21:37:40 --> Final output sent to browser
DEBUG - 2011-07-28 21:37:40 --> Total execution time: 0.6429
DEBUG - 2011-07-28 21:37:44 --> Config Class Initialized
DEBUG - 2011-07-28 21:37:44 --> Hooks Class Initialized
DEBUG - 2011-07-28 21:37:44 --> Utf8 Class Initialized
DEBUG - 2011-07-28 21:37:44 --> UTF-8 Support Enabled
DEBUG - 2011-07-28 21:37:44 --> URI Class Initialized
DEBUG - 2011-07-28 21:37:44 --> Router Class Initialized
DEBUG - 2011-07-28 21:37:44 --> Output Class Initialized
DEBUG - 2011-07-28 21:37:44 --> Input Class Initialized
DEBUG - 2011-07-28 21:37:44 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-28 21:37:44 --> Language Class Initialized
DEBUG - 2011-07-28 21:37:44 --> Loader Class Initialized
DEBUG - 2011-07-28 21:37:44 --> Controller Class Initialized
ERROR - 2011-07-28 21:37:44 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-28 21:37:44 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-28 21:37:44 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-28 21:37:44 --> Model Class Initialized
DEBUG - 2011-07-28 21:37:44 --> Model Class Initialized
DEBUG - 2011-07-28 21:37:44 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-28 21:37:44 --> Database Driver Class Initialized
DEBUG - 2011-07-28 21:37:44 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-28 21:37:44 --> Helper loaded: url_helper
DEBUG - 2011-07-28 21:37:44 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-28 21:37:44 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-28 21:37:44 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-28 21:37:44 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-28 21:37:44 --> Final output sent to browser
DEBUG - 2011-07-28 21:37:44 --> Total execution time: 0.0290
DEBUG - 2011-07-28 21:37:45 --> Config Class Initialized
DEBUG - 2011-07-28 21:37:45 --> Hooks Class Initialized
DEBUG - 2011-07-28 21:37:45 --> Utf8 Class Initialized
DEBUG - 2011-07-28 21:37:45 --> UTF-8 Support Enabled
DEBUG - 2011-07-28 21:37:45 --> URI Class Initialized
DEBUG - 2011-07-28 21:37:45 --> Router Class Initialized
DEBUG - 2011-07-28 21:37:45 --> Output Class Initialized
DEBUG - 2011-07-28 21:37:45 --> Input Class Initialized
DEBUG - 2011-07-28 21:37:45 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-28 21:37:45 --> Language Class Initialized
DEBUG - 2011-07-28 21:37:45 --> Loader Class Initialized
DEBUG - 2011-07-28 21:37:45 --> Controller Class Initialized
DEBUG - 2011-07-28 21:37:45 --> Model Class Initialized
DEBUG - 2011-07-28 21:37:45 --> Model Class Initialized
DEBUG - 2011-07-28 21:37:45 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-28 21:37:45 --> Database Driver Class Initialized
DEBUG - 2011-07-28 21:37:45 --> Final output sent to browser
DEBUG - 2011-07-28 21:37:45 --> Total execution time: 0.6004
DEBUG - 2011-07-28 21:37:50 --> Config Class Initialized
DEBUG - 2011-07-28 21:37:50 --> Hooks Class Initialized
DEBUG - 2011-07-28 21:37:50 --> Utf8 Class Initialized
DEBUG - 2011-07-28 21:37:50 --> UTF-8 Support Enabled
DEBUG - 2011-07-28 21:37:50 --> URI Class Initialized
DEBUG - 2011-07-28 21:37:50 --> Router Class Initialized
DEBUG - 2011-07-28 21:37:50 --> Output Class Initialized
DEBUG - 2011-07-28 21:37:50 --> Input Class Initialized
DEBUG - 2011-07-28 21:37:50 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-28 21:37:50 --> Language Class Initialized
DEBUG - 2011-07-28 21:37:50 --> Loader Class Initialized
DEBUG - 2011-07-28 21:37:50 --> Controller Class Initialized
ERROR - 2011-07-28 21:37:50 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-28 21:37:50 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-28 21:37:50 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-28 21:37:50 --> Model Class Initialized
DEBUG - 2011-07-28 21:37:50 --> Model Class Initialized
DEBUG - 2011-07-28 21:37:50 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-28 21:37:50 --> Database Driver Class Initialized
DEBUG - 2011-07-28 21:37:50 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-28 21:37:50 --> Helper loaded: url_helper
DEBUG - 2011-07-28 21:37:50 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-28 21:37:50 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-28 21:37:50 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-28 21:37:50 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-28 21:37:50 --> Final output sent to browser
DEBUG - 2011-07-28 21:37:50 --> Total execution time: 0.1163
DEBUG - 2011-07-28 21:37:51 --> Config Class Initialized
DEBUG - 2011-07-28 21:37:51 --> Hooks Class Initialized
DEBUG - 2011-07-28 21:37:51 --> Utf8 Class Initialized
DEBUG - 2011-07-28 21:37:51 --> UTF-8 Support Enabled
DEBUG - 2011-07-28 21:37:51 --> URI Class Initialized
DEBUG - 2011-07-28 21:37:51 --> Router Class Initialized
DEBUG - 2011-07-28 21:37:51 --> Output Class Initialized
DEBUG - 2011-07-28 21:37:51 --> Input Class Initialized
DEBUG - 2011-07-28 21:37:51 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-28 21:37:51 --> Language Class Initialized
DEBUG - 2011-07-28 21:37:51 --> Loader Class Initialized
DEBUG - 2011-07-28 21:37:51 --> Controller Class Initialized
DEBUG - 2011-07-28 21:37:51 --> Model Class Initialized
DEBUG - 2011-07-28 21:37:51 --> Model Class Initialized
DEBUG - 2011-07-28 21:37:51 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-28 21:37:51 --> Database Driver Class Initialized
DEBUG - 2011-07-28 21:37:52 --> Final output sent to browser
DEBUG - 2011-07-28 21:37:52 --> Total execution time: 0.7494
DEBUG - 2011-07-28 22:02:21 --> Config Class Initialized
DEBUG - 2011-07-28 22:02:21 --> Hooks Class Initialized
DEBUG - 2011-07-28 22:02:21 --> Utf8 Class Initialized
DEBUG - 2011-07-28 22:02:21 --> UTF-8 Support Enabled
DEBUG - 2011-07-28 22:02:21 --> URI Class Initialized
DEBUG - 2011-07-28 22:02:21 --> Router Class Initialized
DEBUG - 2011-07-28 22:02:21 --> Output Class Initialized
DEBUG - 2011-07-28 22:02:21 --> Input Class Initialized
DEBUG - 2011-07-28 22:02:21 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-28 22:02:21 --> Language Class Initialized
DEBUG - 2011-07-28 22:02:21 --> Loader Class Initialized
DEBUG - 2011-07-28 22:02:21 --> Controller Class Initialized
ERROR - 2011-07-28 22:02:21 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-28 22:02:21 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-28 22:02:21 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-28 22:02:21 --> Model Class Initialized
DEBUG - 2011-07-28 22:02:21 --> Model Class Initialized
DEBUG - 2011-07-28 22:02:21 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-28 22:02:21 --> Database Driver Class Initialized
DEBUG - 2011-07-28 22:02:21 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-28 22:02:21 --> Helper loaded: url_helper
DEBUG - 2011-07-28 22:02:21 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-28 22:02:21 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-28 22:02:21 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-28 22:02:21 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-28 22:02:21 --> Final output sent to browser
DEBUG - 2011-07-28 22:02:21 --> Total execution time: 0.0662
DEBUG - 2011-07-28 22:02:25 --> Config Class Initialized
DEBUG - 2011-07-28 22:02:25 --> Hooks Class Initialized
DEBUG - 2011-07-28 22:02:25 --> Utf8 Class Initialized
DEBUG - 2011-07-28 22:02:25 --> UTF-8 Support Enabled
DEBUG - 2011-07-28 22:02:25 --> URI Class Initialized
DEBUG - 2011-07-28 22:02:25 --> Router Class Initialized
DEBUG - 2011-07-28 22:02:25 --> Output Class Initialized
DEBUG - 2011-07-28 22:02:25 --> Input Class Initialized
DEBUG - 2011-07-28 22:02:25 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-28 22:02:25 --> Language Class Initialized
DEBUG - 2011-07-28 22:02:25 --> Loader Class Initialized
DEBUG - 2011-07-28 22:02:25 --> Controller Class Initialized
DEBUG - 2011-07-28 22:02:25 --> Model Class Initialized
DEBUG - 2011-07-28 22:02:25 --> Model Class Initialized
DEBUG - 2011-07-28 22:02:25 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-28 22:02:25 --> Database Driver Class Initialized
DEBUG - 2011-07-28 22:02:25 --> Final output sent to browser
DEBUG - 2011-07-28 22:02:25 --> Total execution time: 0.5625
DEBUG - 2011-07-28 22:02:28 --> Config Class Initialized
DEBUG - 2011-07-28 22:02:28 --> Hooks Class Initialized
DEBUG - 2011-07-28 22:02:28 --> Utf8 Class Initialized
DEBUG - 2011-07-28 22:02:28 --> UTF-8 Support Enabled
DEBUG - 2011-07-28 22:02:28 --> URI Class Initialized
DEBUG - 2011-07-28 22:02:28 --> Router Class Initialized
ERROR - 2011-07-28 22:02:28 --> 404 Page Not Found --> favicon.ico

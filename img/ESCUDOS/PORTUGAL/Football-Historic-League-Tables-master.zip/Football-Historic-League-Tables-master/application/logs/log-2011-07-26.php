<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2011-07-26 03:55:38 --> Config Class Initialized
DEBUG - 2011-07-26 03:55:38 --> Hooks Class Initialized
DEBUG - 2011-07-26 03:55:38 --> Utf8 Class Initialized
DEBUG - 2011-07-26 03:55:38 --> UTF-8 Support Enabled
DEBUG - 2011-07-26 03:55:38 --> URI Class Initialized
DEBUG - 2011-07-26 03:55:38 --> Router Class Initialized
ERROR - 2011-07-26 03:55:38 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-07-26 03:55:38 --> Config Class Initialized
DEBUG - 2011-07-26 03:55:38 --> Hooks Class Initialized
DEBUG - 2011-07-26 03:55:38 --> Utf8 Class Initialized
DEBUG - 2011-07-26 03:55:38 --> UTF-8 Support Enabled
DEBUG - 2011-07-26 03:55:38 --> URI Class Initialized
DEBUG - 2011-07-26 03:55:38 --> Router Class Initialized
DEBUG - 2011-07-26 03:55:39 --> Output Class Initialized
DEBUG - 2011-07-26 03:55:39 --> Input Class Initialized
DEBUG - 2011-07-26 03:55:39 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-26 03:55:39 --> Language Class Initialized
DEBUG - 2011-07-26 03:55:39 --> Loader Class Initialized
DEBUG - 2011-07-26 03:55:39 --> Controller Class Initialized
DEBUG - 2011-07-26 03:55:39 --> Model Class Initialized
DEBUG - 2011-07-26 03:55:39 --> Model Class Initialized
DEBUG - 2011-07-26 03:55:39 --> Model Class Initialized
DEBUG - 2011-07-26 03:55:40 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-26 03:55:40 --> Database Driver Class Initialized
DEBUG - 2011-07-26 03:55:47 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-26 03:55:48 --> Helper loaded: url_helper
DEBUG - 2011-07-26 03:55:48 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-26 03:55:48 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-26 03:55:48 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-26 03:55:48 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-26 03:55:48 --> Final output sent to browser
DEBUG - 2011-07-26 03:55:48 --> Total execution time: 9.5195
DEBUG - 2011-07-26 03:56:16 --> Config Class Initialized
DEBUG - 2011-07-26 03:56:16 --> Hooks Class Initialized
DEBUG - 2011-07-26 03:56:16 --> Utf8 Class Initialized
DEBUG - 2011-07-26 03:56:16 --> UTF-8 Support Enabled
DEBUG - 2011-07-26 03:56:16 --> URI Class Initialized
DEBUG - 2011-07-26 03:56:16 --> Router Class Initialized
DEBUG - 2011-07-26 03:56:16 --> No URI present. Default controller set.
DEBUG - 2011-07-26 03:56:16 --> Output Class Initialized
DEBUG - 2011-07-26 03:56:16 --> Input Class Initialized
DEBUG - 2011-07-26 03:56:16 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-26 03:56:16 --> Language Class Initialized
DEBUG - 2011-07-26 03:56:16 --> Loader Class Initialized
DEBUG - 2011-07-26 03:56:16 --> Controller Class Initialized
DEBUG - 2011-07-26 03:56:16 --> File loaded: application/views/splash/main.php
DEBUG - 2011-07-26 03:56:16 --> Helper loaded: url_helper
DEBUG - 2011-07-26 03:56:16 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-26 03:56:16 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-26 03:56:16 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-26 03:56:16 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-26 03:56:16 --> Final output sent to browser
DEBUG - 2011-07-26 03:56:16 --> Total execution time: 0.0733
DEBUG - 2011-07-26 04:33:22 --> Config Class Initialized
DEBUG - 2011-07-26 04:33:22 --> Hooks Class Initialized
DEBUG - 2011-07-26 04:33:22 --> Utf8 Class Initialized
DEBUG - 2011-07-26 04:33:22 --> UTF-8 Support Enabled
DEBUG - 2011-07-26 04:33:22 --> URI Class Initialized
DEBUG - 2011-07-26 04:33:22 --> Router Class Initialized
ERROR - 2011-07-26 04:33:22 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-07-26 04:33:22 --> Config Class Initialized
DEBUG - 2011-07-26 04:33:22 --> Hooks Class Initialized
DEBUG - 2011-07-26 04:33:22 --> Utf8 Class Initialized
DEBUG - 2011-07-26 04:33:22 --> UTF-8 Support Enabled
DEBUG - 2011-07-26 04:33:22 --> URI Class Initialized
DEBUG - 2011-07-26 04:33:22 --> Router Class Initialized
DEBUG - 2011-07-26 04:33:23 --> Output Class Initialized
DEBUG - 2011-07-26 04:33:23 --> Input Class Initialized
DEBUG - 2011-07-26 04:33:23 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-26 04:33:23 --> Language Class Initialized
DEBUG - 2011-07-26 04:33:23 --> Loader Class Initialized
DEBUG - 2011-07-26 04:33:23 --> Controller Class Initialized
ERROR - 2011-07-26 04:33:23 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-26 04:33:23 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-26 04:33:23 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-26 04:33:23 --> Model Class Initialized
DEBUG - 2011-07-26 04:33:23 --> Model Class Initialized
DEBUG - 2011-07-26 04:33:23 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-26 04:33:23 --> Database Driver Class Initialized
DEBUG - 2011-07-26 04:33:23 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-26 04:33:23 --> Helper loaded: url_helper
DEBUG - 2011-07-26 04:33:23 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-26 04:33:23 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-26 04:33:23 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-26 04:33:23 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-26 04:33:23 --> Final output sent to browser
DEBUG - 2011-07-26 04:33:23 --> Total execution time: 0.2867
DEBUG - 2011-07-26 07:05:34 --> Config Class Initialized
DEBUG - 2011-07-26 07:05:34 --> Hooks Class Initialized
DEBUG - 2011-07-26 07:05:34 --> Utf8 Class Initialized
DEBUG - 2011-07-26 07:05:34 --> UTF-8 Support Enabled
DEBUG - 2011-07-26 07:05:34 --> URI Class Initialized
DEBUG - 2011-07-26 07:05:34 --> Router Class Initialized
ERROR - 2011-07-26 07:05:34 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-07-26 07:07:29 --> Config Class Initialized
DEBUG - 2011-07-26 07:07:29 --> Hooks Class Initialized
DEBUG - 2011-07-26 07:07:29 --> Utf8 Class Initialized
DEBUG - 2011-07-26 07:07:29 --> UTF-8 Support Enabled
DEBUG - 2011-07-26 07:07:29 --> URI Class Initialized
DEBUG - 2011-07-26 07:07:29 --> Router Class Initialized
ERROR - 2011-07-26 07:07:29 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-07-26 07:07:29 --> Config Class Initialized
DEBUG - 2011-07-26 07:07:29 --> Hooks Class Initialized
DEBUG - 2011-07-26 07:07:29 --> Utf8 Class Initialized
DEBUG - 2011-07-26 07:07:29 --> UTF-8 Support Enabled
DEBUG - 2011-07-26 07:07:29 --> URI Class Initialized
DEBUG - 2011-07-26 07:07:29 --> Router Class Initialized
DEBUG - 2011-07-26 07:07:29 --> Output Class Initialized
DEBUG - 2011-07-26 07:07:29 --> Input Class Initialized
DEBUG - 2011-07-26 07:07:29 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-26 07:07:29 --> Language Class Initialized
DEBUG - 2011-07-26 07:07:29 --> Loader Class Initialized
DEBUG - 2011-07-26 07:07:29 --> Controller Class Initialized
ERROR - 2011-07-26 07:07:29 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-26 07:07:29 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-26 07:07:29 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-26 07:07:29 --> Model Class Initialized
DEBUG - 2011-07-26 07:07:29 --> Model Class Initialized
DEBUG - 2011-07-26 07:07:29 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-26 07:07:29 --> Database Driver Class Initialized
DEBUG - 2011-07-26 07:07:30 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-26 07:07:30 --> Helper loaded: url_helper
DEBUG - 2011-07-26 07:07:30 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-26 07:07:30 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-26 07:07:30 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-26 07:07:30 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-26 07:07:30 --> Final output sent to browser
DEBUG - 2011-07-26 07:07:30 --> Total execution time: 0.8491
DEBUG - 2011-07-26 07:07:34 --> Config Class Initialized
DEBUG - 2011-07-26 07:07:34 --> Hooks Class Initialized
DEBUG - 2011-07-26 07:07:34 --> Utf8 Class Initialized
DEBUG - 2011-07-26 07:07:34 --> UTF-8 Support Enabled
DEBUG - 2011-07-26 07:07:34 --> URI Class Initialized
DEBUG - 2011-07-26 07:07:34 --> Router Class Initialized
DEBUG - 2011-07-26 07:07:34 --> Output Class Initialized
DEBUG - 2011-07-26 07:07:34 --> Input Class Initialized
DEBUG - 2011-07-26 07:07:34 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-26 07:07:34 --> Language Class Initialized
DEBUG - 2011-07-26 07:07:34 --> Loader Class Initialized
DEBUG - 2011-07-26 07:07:34 --> Controller Class Initialized
DEBUG - 2011-07-26 07:07:34 --> Model Class Initialized
DEBUG - 2011-07-26 07:07:34 --> Model Class Initialized
DEBUG - 2011-07-26 07:07:34 --> Model Class Initialized
DEBUG - 2011-07-26 07:07:34 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-26 07:07:34 --> Database Driver Class Initialized
DEBUG - 2011-07-26 07:07:34 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-26 07:07:34 --> Helper loaded: url_helper
DEBUG - 2011-07-26 07:07:34 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-26 07:07:34 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-26 07:07:34 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-26 07:07:34 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-26 07:07:34 --> Final output sent to browser
DEBUG - 2011-07-26 07:07:34 --> Total execution time: 0.6666
DEBUG - 2011-07-26 08:01:57 --> Config Class Initialized
DEBUG - 2011-07-26 08:01:57 --> Hooks Class Initialized
DEBUG - 2011-07-26 08:01:57 --> Utf8 Class Initialized
DEBUG - 2011-07-26 08:01:57 --> UTF-8 Support Enabled
DEBUG - 2011-07-26 08:01:57 --> URI Class Initialized
DEBUG - 2011-07-26 08:01:57 --> Router Class Initialized
DEBUG - 2011-07-26 08:01:57 --> Output Class Initialized
DEBUG - 2011-07-26 08:01:57 --> Input Class Initialized
DEBUG - 2011-07-26 08:01:57 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-26 08:01:57 --> Language Class Initialized
DEBUG - 2011-07-26 08:01:57 --> Loader Class Initialized
DEBUG - 2011-07-26 08:01:57 --> Controller Class Initialized
ERROR - 2011-07-26 08:01:57 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-26 08:01:57 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-26 08:01:57 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-26 08:01:57 --> Model Class Initialized
DEBUG - 2011-07-26 08:01:57 --> Model Class Initialized
DEBUG - 2011-07-26 08:01:57 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-26 08:01:57 --> Database Driver Class Initialized
DEBUG - 2011-07-26 08:01:57 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-26 08:01:57 --> Helper loaded: url_helper
DEBUG - 2011-07-26 08:01:57 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-26 08:01:57 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-26 08:01:57 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-26 08:01:57 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-26 08:01:57 --> Final output sent to browser
DEBUG - 2011-07-26 08:01:57 --> Total execution time: 0.0454
DEBUG - 2011-07-26 08:01:58 --> Config Class Initialized
DEBUG - 2011-07-26 08:01:58 --> Hooks Class Initialized
DEBUG - 2011-07-26 08:01:58 --> Utf8 Class Initialized
DEBUG - 2011-07-26 08:01:58 --> UTF-8 Support Enabled
DEBUG - 2011-07-26 08:01:58 --> URI Class Initialized
DEBUG - 2011-07-26 08:01:58 --> Router Class Initialized
DEBUG - 2011-07-26 08:01:58 --> Output Class Initialized
DEBUG - 2011-07-26 08:01:58 --> Input Class Initialized
DEBUG - 2011-07-26 08:01:58 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-26 08:01:58 --> Language Class Initialized
DEBUG - 2011-07-26 08:01:58 --> Loader Class Initialized
DEBUG - 2011-07-26 08:01:58 --> Controller Class Initialized
DEBUG - 2011-07-26 08:01:58 --> Model Class Initialized
DEBUG - 2011-07-26 08:01:58 --> Model Class Initialized
DEBUG - 2011-07-26 08:01:58 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-26 08:01:58 --> Database Driver Class Initialized
DEBUG - 2011-07-26 08:01:58 --> Final output sent to browser
DEBUG - 2011-07-26 08:01:58 --> Total execution time: 0.6466
DEBUG - 2011-07-26 08:02:00 --> Config Class Initialized
DEBUG - 2011-07-26 08:02:00 --> Hooks Class Initialized
DEBUG - 2011-07-26 08:02:00 --> Utf8 Class Initialized
DEBUG - 2011-07-26 08:02:00 --> UTF-8 Support Enabled
DEBUG - 2011-07-26 08:02:00 --> URI Class Initialized
DEBUG - 2011-07-26 08:02:00 --> Router Class Initialized
ERROR - 2011-07-26 08:02:00 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-26 08:02:03 --> Config Class Initialized
DEBUG - 2011-07-26 08:02:03 --> Hooks Class Initialized
DEBUG - 2011-07-26 08:02:03 --> Utf8 Class Initialized
DEBUG - 2011-07-26 08:02:03 --> UTF-8 Support Enabled
DEBUG - 2011-07-26 08:02:03 --> URI Class Initialized
DEBUG - 2011-07-26 08:02:03 --> Router Class Initialized
ERROR - 2011-07-26 08:02:03 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-26 08:14:06 --> Config Class Initialized
DEBUG - 2011-07-26 08:14:06 --> Hooks Class Initialized
DEBUG - 2011-07-26 08:14:06 --> Utf8 Class Initialized
DEBUG - 2011-07-26 08:14:06 --> UTF-8 Support Enabled
DEBUG - 2011-07-26 08:14:06 --> URI Class Initialized
DEBUG - 2011-07-26 08:14:06 --> Router Class Initialized
DEBUG - 2011-07-26 08:14:06 --> Output Class Initialized
DEBUG - 2011-07-26 08:14:06 --> Input Class Initialized
DEBUG - 2011-07-26 08:14:06 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-26 08:14:06 --> Language Class Initialized
DEBUG - 2011-07-26 08:14:06 --> Loader Class Initialized
DEBUG - 2011-07-26 08:14:06 --> Controller Class Initialized
DEBUG - 2011-07-26 08:14:06 --> Model Class Initialized
DEBUG - 2011-07-26 08:14:06 --> Model Class Initialized
DEBUG - 2011-07-26 08:14:06 --> Model Class Initialized
DEBUG - 2011-07-26 08:14:06 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-26 08:14:06 --> Database Driver Class Initialized
DEBUG - 2011-07-26 08:14:06 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-26 08:14:06 --> Helper loaded: url_helper
DEBUG - 2011-07-26 08:14:06 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-26 08:14:06 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-26 08:14:06 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-26 08:14:06 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-26 08:14:06 --> Final output sent to browser
DEBUG - 2011-07-26 08:14:06 --> Total execution time: 0.3203
DEBUG - 2011-07-26 08:14:11 --> Config Class Initialized
DEBUG - 2011-07-26 08:14:11 --> Hooks Class Initialized
DEBUG - 2011-07-26 08:14:11 --> Utf8 Class Initialized
DEBUG - 2011-07-26 08:14:11 --> UTF-8 Support Enabled
DEBUG - 2011-07-26 08:14:11 --> URI Class Initialized
DEBUG - 2011-07-26 08:14:11 --> Router Class Initialized
ERROR - 2011-07-26 08:14:11 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-26 08:15:03 --> Config Class Initialized
DEBUG - 2011-07-26 08:15:03 --> Hooks Class Initialized
DEBUG - 2011-07-26 08:15:03 --> Utf8 Class Initialized
DEBUG - 2011-07-26 08:15:03 --> UTF-8 Support Enabled
DEBUG - 2011-07-26 08:15:03 --> URI Class Initialized
DEBUG - 2011-07-26 08:15:03 --> Router Class Initialized
DEBUG - 2011-07-26 08:15:03 --> Output Class Initialized
DEBUG - 2011-07-26 08:15:03 --> Input Class Initialized
DEBUG - 2011-07-26 08:15:03 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-26 08:15:03 --> Language Class Initialized
DEBUG - 2011-07-26 08:15:03 --> Loader Class Initialized
DEBUG - 2011-07-26 08:15:03 --> Controller Class Initialized
DEBUG - 2011-07-26 08:15:03 --> Model Class Initialized
DEBUG - 2011-07-26 08:15:03 --> Model Class Initialized
DEBUG - 2011-07-26 08:15:03 --> Model Class Initialized
DEBUG - 2011-07-26 08:15:03 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-26 08:15:03 --> Database Driver Class Initialized
DEBUG - 2011-07-26 08:15:05 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-26 08:15:05 --> Helper loaded: url_helper
DEBUG - 2011-07-26 08:15:05 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-26 08:15:05 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-26 08:15:05 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-26 08:15:05 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-26 08:15:05 --> Final output sent to browser
DEBUG - 2011-07-26 08:15:05 --> Total execution time: 2.3019
DEBUG - 2011-07-26 08:15:07 --> Config Class Initialized
DEBUG - 2011-07-26 08:15:07 --> Hooks Class Initialized
DEBUG - 2011-07-26 08:15:07 --> Utf8 Class Initialized
DEBUG - 2011-07-26 08:15:07 --> UTF-8 Support Enabled
DEBUG - 2011-07-26 08:15:07 --> URI Class Initialized
DEBUG - 2011-07-26 08:15:07 --> Router Class Initialized
ERROR - 2011-07-26 08:15:07 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-26 08:15:08 --> Config Class Initialized
DEBUG - 2011-07-26 08:15:08 --> Hooks Class Initialized
DEBUG - 2011-07-26 08:15:08 --> Utf8 Class Initialized
DEBUG - 2011-07-26 08:15:08 --> UTF-8 Support Enabled
DEBUG - 2011-07-26 08:15:08 --> URI Class Initialized
DEBUG - 2011-07-26 08:15:08 --> Router Class Initialized
DEBUG - 2011-07-26 08:15:08 --> Output Class Initialized
DEBUG - 2011-07-26 08:15:08 --> Input Class Initialized
DEBUG - 2011-07-26 08:15:08 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-26 08:15:08 --> Language Class Initialized
DEBUG - 2011-07-26 08:15:08 --> Loader Class Initialized
DEBUG - 2011-07-26 08:15:08 --> Controller Class Initialized
DEBUG - 2011-07-26 08:15:08 --> Model Class Initialized
DEBUG - 2011-07-26 08:15:08 --> Model Class Initialized
DEBUG - 2011-07-26 08:15:08 --> Model Class Initialized
DEBUG - 2011-07-26 08:15:08 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-26 08:15:08 --> Database Driver Class Initialized
DEBUG - 2011-07-26 08:15:08 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-26 08:15:08 --> Helper loaded: url_helper
DEBUG - 2011-07-26 08:15:08 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-26 08:15:08 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-26 08:15:08 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-26 08:15:08 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-26 08:15:08 --> Final output sent to browser
DEBUG - 2011-07-26 08:15:08 --> Total execution time: 0.1195
DEBUG - 2011-07-26 08:15:27 --> Config Class Initialized
DEBUG - 2011-07-26 08:15:27 --> Hooks Class Initialized
DEBUG - 2011-07-26 08:15:27 --> Utf8 Class Initialized
DEBUG - 2011-07-26 08:15:27 --> UTF-8 Support Enabled
DEBUG - 2011-07-26 08:15:27 --> URI Class Initialized
DEBUG - 2011-07-26 08:15:27 --> Router Class Initialized
DEBUG - 2011-07-26 08:15:27 --> Output Class Initialized
DEBUG - 2011-07-26 08:15:27 --> Input Class Initialized
DEBUG - 2011-07-26 08:15:27 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-26 08:15:27 --> Language Class Initialized
DEBUG - 2011-07-26 08:15:27 --> Loader Class Initialized
DEBUG - 2011-07-26 08:15:27 --> Controller Class Initialized
DEBUG - 2011-07-26 08:15:27 --> Model Class Initialized
DEBUG - 2011-07-26 08:15:27 --> Model Class Initialized
DEBUG - 2011-07-26 08:15:27 --> Model Class Initialized
DEBUG - 2011-07-26 08:15:27 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-26 08:15:27 --> Database Driver Class Initialized
DEBUG - 2011-07-26 08:15:29 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-26 08:15:29 --> Helper loaded: url_helper
DEBUG - 2011-07-26 08:15:29 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-26 08:15:29 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-26 08:15:29 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-26 08:15:29 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-26 08:15:29 --> Final output sent to browser
DEBUG - 2011-07-26 08:15:29 --> Total execution time: 1.7071
DEBUG - 2011-07-26 08:15:31 --> Config Class Initialized
DEBUG - 2011-07-26 08:15:31 --> Hooks Class Initialized
DEBUG - 2011-07-26 08:15:31 --> Utf8 Class Initialized
DEBUG - 2011-07-26 08:15:31 --> UTF-8 Support Enabled
DEBUG - 2011-07-26 08:15:31 --> URI Class Initialized
DEBUG - 2011-07-26 08:15:31 --> Router Class Initialized
DEBUG - 2011-07-26 08:15:31 --> Output Class Initialized
DEBUG - 2011-07-26 08:15:31 --> Input Class Initialized
DEBUG - 2011-07-26 08:15:31 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-26 08:15:31 --> Language Class Initialized
DEBUG - 2011-07-26 08:15:31 --> Loader Class Initialized
DEBUG - 2011-07-26 08:15:31 --> Controller Class Initialized
DEBUG - 2011-07-26 08:15:31 --> Model Class Initialized
DEBUG - 2011-07-26 08:15:31 --> Model Class Initialized
DEBUG - 2011-07-26 08:15:31 --> Model Class Initialized
DEBUG - 2011-07-26 08:15:31 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-26 08:15:31 --> Database Driver Class Initialized
DEBUG - 2011-07-26 08:15:31 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-26 08:15:31 --> Helper loaded: url_helper
DEBUG - 2011-07-26 08:15:31 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-26 08:15:31 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-26 08:15:31 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-26 08:15:31 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-26 08:15:31 --> Final output sent to browser
DEBUG - 2011-07-26 08:15:31 --> Total execution time: 0.0513
DEBUG - 2011-07-26 08:15:31 --> Config Class Initialized
DEBUG - 2011-07-26 08:15:31 --> Hooks Class Initialized
DEBUG - 2011-07-26 08:15:31 --> Utf8 Class Initialized
DEBUG - 2011-07-26 08:15:31 --> UTF-8 Support Enabled
DEBUG - 2011-07-26 08:15:31 --> URI Class Initialized
DEBUG - 2011-07-26 08:15:31 --> Router Class Initialized
ERROR - 2011-07-26 08:15:31 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-26 08:15:43 --> Config Class Initialized
DEBUG - 2011-07-26 08:15:43 --> Hooks Class Initialized
DEBUG - 2011-07-26 08:15:43 --> Utf8 Class Initialized
DEBUG - 2011-07-26 08:15:43 --> UTF-8 Support Enabled
DEBUG - 2011-07-26 08:15:43 --> URI Class Initialized
DEBUG - 2011-07-26 08:15:43 --> Router Class Initialized
DEBUG - 2011-07-26 08:15:43 --> Output Class Initialized
DEBUG - 2011-07-26 08:15:43 --> Input Class Initialized
DEBUG - 2011-07-26 08:15:43 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-26 08:15:43 --> Language Class Initialized
DEBUG - 2011-07-26 08:15:43 --> Loader Class Initialized
DEBUG - 2011-07-26 08:15:43 --> Controller Class Initialized
DEBUG - 2011-07-26 08:15:43 --> Model Class Initialized
DEBUG - 2011-07-26 08:15:43 --> Model Class Initialized
DEBUG - 2011-07-26 08:15:43 --> Model Class Initialized
DEBUG - 2011-07-26 08:15:43 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-26 08:15:43 --> Database Driver Class Initialized
DEBUG - 2011-07-26 08:15:43 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-26 08:15:43 --> Helper loaded: url_helper
DEBUG - 2011-07-26 08:15:44 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-26 08:15:44 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-26 08:15:44 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-26 08:15:44 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-26 08:15:44 --> Final output sent to browser
DEBUG - 2011-07-26 08:15:44 --> Total execution time: 0.4909
DEBUG - 2011-07-26 08:15:45 --> Config Class Initialized
DEBUG - 2011-07-26 08:15:45 --> Hooks Class Initialized
DEBUG - 2011-07-26 08:15:45 --> Utf8 Class Initialized
DEBUG - 2011-07-26 08:15:45 --> UTF-8 Support Enabled
DEBUG - 2011-07-26 08:15:45 --> URI Class Initialized
DEBUG - 2011-07-26 08:15:45 --> Router Class Initialized
DEBUG - 2011-07-26 08:15:45 --> Output Class Initialized
DEBUG - 2011-07-26 08:15:45 --> Input Class Initialized
DEBUG - 2011-07-26 08:15:45 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-26 08:15:45 --> Language Class Initialized
DEBUG - 2011-07-26 08:15:45 --> Loader Class Initialized
DEBUG - 2011-07-26 08:15:45 --> Controller Class Initialized
DEBUG - 2011-07-26 08:15:45 --> Model Class Initialized
DEBUG - 2011-07-26 08:15:45 --> Model Class Initialized
DEBUG - 2011-07-26 08:15:45 --> Model Class Initialized
DEBUG - 2011-07-26 08:15:45 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-26 08:15:45 --> Database Driver Class Initialized
DEBUG - 2011-07-26 08:15:45 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-26 08:15:45 --> Helper loaded: url_helper
DEBUG - 2011-07-26 08:15:45 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-26 08:15:45 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-26 08:15:45 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-26 08:15:45 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-26 08:15:45 --> Final output sent to browser
DEBUG - 2011-07-26 08:15:45 --> Total execution time: 0.0458
DEBUG - 2011-07-26 08:15:45 --> Config Class Initialized
DEBUG - 2011-07-26 08:15:45 --> Hooks Class Initialized
DEBUG - 2011-07-26 08:15:45 --> Utf8 Class Initialized
DEBUG - 2011-07-26 08:15:45 --> UTF-8 Support Enabled
DEBUG - 2011-07-26 08:15:45 --> URI Class Initialized
DEBUG - 2011-07-26 08:15:45 --> Router Class Initialized
ERROR - 2011-07-26 08:15:45 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-26 08:15:59 --> Config Class Initialized
DEBUG - 2011-07-26 08:15:59 --> Hooks Class Initialized
DEBUG - 2011-07-26 08:15:59 --> Utf8 Class Initialized
DEBUG - 2011-07-26 08:15:59 --> UTF-8 Support Enabled
DEBUG - 2011-07-26 08:15:59 --> URI Class Initialized
DEBUG - 2011-07-26 08:15:59 --> Router Class Initialized
DEBUG - 2011-07-26 08:15:59 --> Output Class Initialized
DEBUG - 2011-07-26 08:15:59 --> Input Class Initialized
DEBUG - 2011-07-26 08:15:59 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-26 08:15:59 --> Language Class Initialized
DEBUG - 2011-07-26 08:15:59 --> Loader Class Initialized
DEBUG - 2011-07-26 08:15:59 --> Controller Class Initialized
DEBUG - 2011-07-26 08:15:59 --> Model Class Initialized
DEBUG - 2011-07-26 08:15:59 --> Model Class Initialized
DEBUG - 2011-07-26 08:15:59 --> Model Class Initialized
DEBUG - 2011-07-26 08:15:59 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-26 08:15:59 --> Database Driver Class Initialized
DEBUG - 2011-07-26 08:16:00 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-26 08:16:00 --> Helper loaded: url_helper
DEBUG - 2011-07-26 08:16:00 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-26 08:16:00 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-26 08:16:00 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-26 08:16:00 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-26 08:16:00 --> Final output sent to browser
DEBUG - 2011-07-26 08:16:00 --> Total execution time: 0.2322
DEBUG - 2011-07-26 08:16:02 --> Config Class Initialized
DEBUG - 2011-07-26 08:16:02 --> Hooks Class Initialized
DEBUG - 2011-07-26 08:16:02 --> Utf8 Class Initialized
DEBUG - 2011-07-26 08:16:02 --> UTF-8 Support Enabled
DEBUG - 2011-07-26 08:16:02 --> URI Class Initialized
DEBUG - 2011-07-26 08:16:02 --> Router Class Initialized
ERROR - 2011-07-26 08:16:02 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-26 08:16:10 --> Config Class Initialized
DEBUG - 2011-07-26 08:16:10 --> Hooks Class Initialized
DEBUG - 2011-07-26 08:16:10 --> Utf8 Class Initialized
DEBUG - 2011-07-26 08:16:10 --> UTF-8 Support Enabled
DEBUG - 2011-07-26 08:16:10 --> URI Class Initialized
DEBUG - 2011-07-26 08:16:10 --> Router Class Initialized
DEBUG - 2011-07-26 08:16:10 --> Output Class Initialized
DEBUG - 2011-07-26 08:16:10 --> Input Class Initialized
DEBUG - 2011-07-26 08:16:10 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-26 08:16:10 --> Language Class Initialized
DEBUG - 2011-07-26 08:16:10 --> Loader Class Initialized
DEBUG - 2011-07-26 08:16:10 --> Controller Class Initialized
DEBUG - 2011-07-26 08:16:10 --> Model Class Initialized
DEBUG - 2011-07-26 08:16:10 --> Model Class Initialized
DEBUG - 2011-07-26 08:16:10 --> Model Class Initialized
DEBUG - 2011-07-26 08:16:10 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-26 08:16:10 --> Database Driver Class Initialized
DEBUG - 2011-07-26 08:16:10 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-26 08:16:10 --> Helper loaded: url_helper
DEBUG - 2011-07-26 08:16:10 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-26 08:16:10 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-26 08:16:10 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-26 08:16:10 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-26 08:16:10 --> Final output sent to browser
DEBUG - 2011-07-26 08:16:10 --> Total execution time: 0.0689
DEBUG - 2011-07-26 08:16:28 --> Config Class Initialized
DEBUG - 2011-07-26 08:16:28 --> Hooks Class Initialized
DEBUG - 2011-07-26 08:16:28 --> Utf8 Class Initialized
DEBUG - 2011-07-26 08:16:28 --> UTF-8 Support Enabled
DEBUG - 2011-07-26 08:16:28 --> URI Class Initialized
DEBUG - 2011-07-26 08:16:28 --> Router Class Initialized
DEBUG - 2011-07-26 08:16:28 --> Output Class Initialized
DEBUG - 2011-07-26 08:16:28 --> Input Class Initialized
DEBUG - 2011-07-26 08:16:28 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-26 08:16:28 --> Language Class Initialized
DEBUG - 2011-07-26 08:16:28 --> Loader Class Initialized
DEBUG - 2011-07-26 08:16:28 --> Controller Class Initialized
DEBUG - 2011-07-26 08:16:28 --> Model Class Initialized
DEBUG - 2011-07-26 08:16:28 --> Model Class Initialized
DEBUG - 2011-07-26 08:16:28 --> Model Class Initialized
DEBUG - 2011-07-26 08:16:28 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-26 08:16:28 --> Database Driver Class Initialized
DEBUG - 2011-07-26 08:16:29 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-26 08:16:29 --> Helper loaded: url_helper
DEBUG - 2011-07-26 08:16:29 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-26 08:16:29 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-26 08:16:29 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-26 08:16:29 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-26 08:16:29 --> Final output sent to browser
DEBUG - 2011-07-26 08:16:29 --> Total execution time: 0.5560
DEBUG - 2011-07-26 08:16:30 --> Config Class Initialized
DEBUG - 2011-07-26 08:16:30 --> Hooks Class Initialized
DEBUG - 2011-07-26 08:16:30 --> Utf8 Class Initialized
DEBUG - 2011-07-26 08:16:30 --> UTF-8 Support Enabled
DEBUG - 2011-07-26 08:16:30 --> URI Class Initialized
DEBUG - 2011-07-26 08:16:30 --> Router Class Initialized
DEBUG - 2011-07-26 08:16:30 --> Output Class Initialized
DEBUG - 2011-07-26 08:16:30 --> Input Class Initialized
DEBUG - 2011-07-26 08:16:30 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-26 08:16:30 --> Language Class Initialized
DEBUG - 2011-07-26 08:16:30 --> Loader Class Initialized
DEBUG - 2011-07-26 08:16:30 --> Controller Class Initialized
DEBUG - 2011-07-26 08:16:30 --> Model Class Initialized
DEBUG - 2011-07-26 08:16:30 --> Model Class Initialized
DEBUG - 2011-07-26 08:16:30 --> Model Class Initialized
DEBUG - 2011-07-26 08:16:30 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-26 08:16:30 --> Database Driver Class Initialized
DEBUG - 2011-07-26 08:16:30 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-26 08:16:30 --> Helper loaded: url_helper
DEBUG - 2011-07-26 08:16:30 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-26 08:16:30 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-26 08:16:30 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-26 08:16:30 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-26 08:16:30 --> Final output sent to browser
DEBUG - 2011-07-26 08:16:30 --> Total execution time: 0.0604
DEBUG - 2011-07-26 08:16:30 --> Config Class Initialized
DEBUG - 2011-07-26 08:16:30 --> Hooks Class Initialized
DEBUG - 2011-07-26 08:16:30 --> Utf8 Class Initialized
DEBUG - 2011-07-26 08:16:30 --> UTF-8 Support Enabled
DEBUG - 2011-07-26 08:16:30 --> URI Class Initialized
DEBUG - 2011-07-26 08:16:30 --> Router Class Initialized
ERROR - 2011-07-26 08:16:30 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-26 08:17:04 --> Config Class Initialized
DEBUG - 2011-07-26 08:17:04 --> Hooks Class Initialized
DEBUG - 2011-07-26 08:17:04 --> Utf8 Class Initialized
DEBUG - 2011-07-26 08:17:04 --> UTF-8 Support Enabled
DEBUG - 2011-07-26 08:17:04 --> URI Class Initialized
DEBUG - 2011-07-26 08:17:04 --> Router Class Initialized
DEBUG - 2011-07-26 08:17:04 --> Output Class Initialized
DEBUG - 2011-07-26 08:17:04 --> Input Class Initialized
DEBUG - 2011-07-26 08:17:04 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-26 08:17:04 --> Language Class Initialized
DEBUG - 2011-07-26 08:17:04 --> Loader Class Initialized
DEBUG - 2011-07-26 08:17:04 --> Controller Class Initialized
DEBUG - 2011-07-26 08:17:04 --> Model Class Initialized
DEBUG - 2011-07-26 08:17:04 --> Model Class Initialized
DEBUG - 2011-07-26 08:17:04 --> Model Class Initialized
DEBUG - 2011-07-26 08:17:04 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-26 08:17:04 --> Database Driver Class Initialized
DEBUG - 2011-07-26 08:17:05 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-26 08:17:05 --> Helper loaded: url_helper
DEBUG - 2011-07-26 08:17:05 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-26 08:17:05 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-26 08:17:05 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-26 08:17:05 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-26 08:17:05 --> Final output sent to browser
DEBUG - 2011-07-26 08:17:05 --> Total execution time: 0.8488
DEBUG - 2011-07-26 08:17:07 --> Config Class Initialized
DEBUG - 2011-07-26 08:17:07 --> Hooks Class Initialized
DEBUG - 2011-07-26 08:17:07 --> Utf8 Class Initialized
DEBUG - 2011-07-26 08:17:07 --> UTF-8 Support Enabled
DEBUG - 2011-07-26 08:17:07 --> URI Class Initialized
DEBUG - 2011-07-26 08:17:07 --> Router Class Initialized
ERROR - 2011-07-26 08:17:07 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-26 08:17:13 --> Config Class Initialized
DEBUG - 2011-07-26 08:17:13 --> Hooks Class Initialized
DEBUG - 2011-07-26 08:17:13 --> Utf8 Class Initialized
DEBUG - 2011-07-26 08:17:13 --> UTF-8 Support Enabled
DEBUG - 2011-07-26 08:17:13 --> URI Class Initialized
DEBUG - 2011-07-26 08:17:13 --> Router Class Initialized
DEBUG - 2011-07-26 08:17:13 --> Output Class Initialized
DEBUG - 2011-07-26 08:17:13 --> Input Class Initialized
DEBUG - 2011-07-26 08:17:13 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-26 08:17:13 --> Language Class Initialized
DEBUG - 2011-07-26 08:17:13 --> Loader Class Initialized
DEBUG - 2011-07-26 08:17:13 --> Controller Class Initialized
DEBUG - 2011-07-26 08:17:13 --> Model Class Initialized
DEBUG - 2011-07-26 08:17:13 --> Model Class Initialized
DEBUG - 2011-07-26 08:17:13 --> Model Class Initialized
DEBUG - 2011-07-26 08:17:13 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-26 08:17:13 --> Database Driver Class Initialized
DEBUG - 2011-07-26 08:17:13 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-26 08:17:13 --> Helper loaded: url_helper
DEBUG - 2011-07-26 08:17:13 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-26 08:17:13 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-26 08:17:13 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-26 08:17:13 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-26 08:17:13 --> Final output sent to browser
DEBUG - 2011-07-26 08:17:13 --> Total execution time: 0.0449
DEBUG - 2011-07-26 08:17:32 --> Config Class Initialized
DEBUG - 2011-07-26 08:17:32 --> Hooks Class Initialized
DEBUG - 2011-07-26 08:17:32 --> Utf8 Class Initialized
DEBUG - 2011-07-26 08:17:32 --> UTF-8 Support Enabled
DEBUG - 2011-07-26 08:17:32 --> URI Class Initialized
DEBUG - 2011-07-26 08:17:32 --> Router Class Initialized
DEBUG - 2011-07-26 08:17:32 --> Output Class Initialized
DEBUG - 2011-07-26 08:17:32 --> Input Class Initialized
DEBUG - 2011-07-26 08:17:32 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-26 08:17:32 --> Language Class Initialized
DEBUG - 2011-07-26 08:17:32 --> Loader Class Initialized
DEBUG - 2011-07-26 08:17:32 --> Controller Class Initialized
DEBUG - 2011-07-26 08:17:32 --> Model Class Initialized
DEBUG - 2011-07-26 08:17:32 --> Model Class Initialized
DEBUG - 2011-07-26 08:17:32 --> Model Class Initialized
DEBUG - 2011-07-26 08:17:32 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-26 08:17:32 --> Database Driver Class Initialized
DEBUG - 2011-07-26 08:17:32 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-26 08:17:32 --> Helper loaded: url_helper
DEBUG - 2011-07-26 08:17:32 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-26 08:17:32 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-26 08:17:32 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-26 08:17:32 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-26 08:17:32 --> Final output sent to browser
DEBUG - 2011-07-26 08:17:32 --> Total execution time: 0.2851
DEBUG - 2011-07-26 08:17:34 --> Config Class Initialized
DEBUG - 2011-07-26 08:17:34 --> Hooks Class Initialized
DEBUG - 2011-07-26 08:17:34 --> Utf8 Class Initialized
DEBUG - 2011-07-26 08:17:34 --> UTF-8 Support Enabled
DEBUG - 2011-07-26 08:17:34 --> URI Class Initialized
DEBUG - 2011-07-26 08:17:34 --> Router Class Initialized
ERROR - 2011-07-26 08:17:34 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-26 08:17:34 --> Config Class Initialized
DEBUG - 2011-07-26 08:17:34 --> Hooks Class Initialized
DEBUG - 2011-07-26 08:17:34 --> Utf8 Class Initialized
DEBUG - 2011-07-26 08:17:34 --> UTF-8 Support Enabled
DEBUG - 2011-07-26 08:17:34 --> URI Class Initialized
DEBUG - 2011-07-26 08:17:34 --> Router Class Initialized
DEBUG - 2011-07-26 08:17:34 --> Output Class Initialized
DEBUG - 2011-07-26 08:17:34 --> Input Class Initialized
DEBUG - 2011-07-26 08:17:34 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-26 08:17:34 --> Language Class Initialized
DEBUG - 2011-07-26 08:17:34 --> Loader Class Initialized
DEBUG - 2011-07-26 08:17:34 --> Controller Class Initialized
DEBUG - 2011-07-26 08:17:34 --> Model Class Initialized
DEBUG - 2011-07-26 08:17:34 --> Model Class Initialized
DEBUG - 2011-07-26 08:17:34 --> Model Class Initialized
DEBUG - 2011-07-26 08:17:34 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-26 08:17:34 --> Database Driver Class Initialized
DEBUG - 2011-07-26 08:17:34 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-26 08:17:34 --> Helper loaded: url_helper
DEBUG - 2011-07-26 08:17:34 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-26 08:17:34 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-26 08:17:34 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-26 08:17:34 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-26 08:17:34 --> Final output sent to browser
DEBUG - 2011-07-26 08:17:34 --> Total execution time: 0.0880
DEBUG - 2011-07-26 08:17:47 --> Config Class Initialized
DEBUG - 2011-07-26 08:17:47 --> Hooks Class Initialized
DEBUG - 2011-07-26 08:17:47 --> Utf8 Class Initialized
DEBUG - 2011-07-26 08:17:47 --> UTF-8 Support Enabled
DEBUG - 2011-07-26 08:17:47 --> URI Class Initialized
DEBUG - 2011-07-26 08:17:47 --> Router Class Initialized
DEBUG - 2011-07-26 08:17:47 --> Output Class Initialized
DEBUG - 2011-07-26 08:17:47 --> Input Class Initialized
DEBUG - 2011-07-26 08:17:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-26 08:17:47 --> Language Class Initialized
DEBUG - 2011-07-26 08:17:47 --> Loader Class Initialized
DEBUG - 2011-07-26 08:17:47 --> Controller Class Initialized
DEBUG - 2011-07-26 08:17:47 --> Model Class Initialized
DEBUG - 2011-07-26 08:17:47 --> Model Class Initialized
DEBUG - 2011-07-26 08:17:47 --> Model Class Initialized
DEBUG - 2011-07-26 08:17:47 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-26 08:17:47 --> Database Driver Class Initialized
DEBUG - 2011-07-26 08:17:48 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-26 08:17:48 --> Helper loaded: url_helper
DEBUG - 2011-07-26 08:17:48 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-26 08:17:48 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-26 08:17:48 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-26 08:17:48 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-26 08:17:48 --> Final output sent to browser
DEBUG - 2011-07-26 08:17:48 --> Total execution time: 1.3987
DEBUG - 2011-07-26 08:17:50 --> Config Class Initialized
DEBUG - 2011-07-26 08:17:50 --> Hooks Class Initialized
DEBUG - 2011-07-26 08:17:50 --> Utf8 Class Initialized
DEBUG - 2011-07-26 08:17:50 --> UTF-8 Support Enabled
DEBUG - 2011-07-26 08:17:50 --> URI Class Initialized
DEBUG - 2011-07-26 08:17:50 --> Router Class Initialized
DEBUG - 2011-07-26 08:17:50 --> Output Class Initialized
DEBUG - 2011-07-26 08:17:50 --> Input Class Initialized
DEBUG - 2011-07-26 08:17:50 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-26 08:17:50 --> Language Class Initialized
DEBUG - 2011-07-26 08:17:50 --> Loader Class Initialized
DEBUG - 2011-07-26 08:17:50 --> Controller Class Initialized
DEBUG - 2011-07-26 08:17:50 --> Model Class Initialized
DEBUG - 2011-07-26 08:17:50 --> Model Class Initialized
DEBUG - 2011-07-26 08:17:50 --> Model Class Initialized
DEBUG - 2011-07-26 08:17:50 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-26 08:17:50 --> Database Driver Class Initialized
DEBUG - 2011-07-26 08:17:50 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-26 08:17:50 --> Helper loaded: url_helper
DEBUG - 2011-07-26 08:17:50 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-26 08:17:50 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-26 08:17:50 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-26 08:17:50 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-26 08:17:50 --> Final output sent to browser
DEBUG - 2011-07-26 08:17:50 --> Total execution time: 0.1261
DEBUG - 2011-07-26 08:17:50 --> Config Class Initialized
DEBUG - 2011-07-26 08:17:50 --> Hooks Class Initialized
DEBUG - 2011-07-26 08:17:50 --> Utf8 Class Initialized
DEBUG - 2011-07-26 08:17:50 --> UTF-8 Support Enabled
DEBUG - 2011-07-26 08:17:50 --> URI Class Initialized
DEBUG - 2011-07-26 08:17:50 --> Router Class Initialized
ERROR - 2011-07-26 08:17:50 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-26 08:18:03 --> Config Class Initialized
DEBUG - 2011-07-26 08:18:03 --> Hooks Class Initialized
DEBUG - 2011-07-26 08:18:03 --> Utf8 Class Initialized
DEBUG - 2011-07-26 08:18:03 --> UTF-8 Support Enabled
DEBUG - 2011-07-26 08:18:03 --> URI Class Initialized
DEBUG - 2011-07-26 08:18:03 --> Router Class Initialized
DEBUG - 2011-07-26 08:18:03 --> Output Class Initialized
DEBUG - 2011-07-26 08:18:03 --> Input Class Initialized
DEBUG - 2011-07-26 08:18:03 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-26 08:18:03 --> Language Class Initialized
DEBUG - 2011-07-26 08:18:03 --> Loader Class Initialized
DEBUG - 2011-07-26 08:18:03 --> Controller Class Initialized
DEBUG - 2011-07-26 08:18:03 --> Model Class Initialized
DEBUG - 2011-07-26 08:18:03 --> Model Class Initialized
DEBUG - 2011-07-26 08:18:03 --> Model Class Initialized
DEBUG - 2011-07-26 08:18:03 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-26 08:18:03 --> Database Driver Class Initialized
DEBUG - 2011-07-26 08:18:03 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-26 08:18:03 --> Helper loaded: url_helper
DEBUG - 2011-07-26 08:18:03 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-26 08:18:03 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-26 08:18:03 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-26 08:18:03 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-26 08:18:03 --> Final output sent to browser
DEBUG - 2011-07-26 08:18:03 --> Total execution time: 0.1932
DEBUG - 2011-07-26 08:18:05 --> Config Class Initialized
DEBUG - 2011-07-26 08:18:05 --> Hooks Class Initialized
DEBUG - 2011-07-26 08:18:05 --> Utf8 Class Initialized
DEBUG - 2011-07-26 08:18:05 --> UTF-8 Support Enabled
DEBUG - 2011-07-26 08:18:05 --> URI Class Initialized
DEBUG - 2011-07-26 08:18:05 --> Router Class Initialized
ERROR - 2011-07-26 08:18:05 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-26 08:18:11 --> Config Class Initialized
DEBUG - 2011-07-26 08:18:11 --> Hooks Class Initialized
DEBUG - 2011-07-26 08:18:11 --> Utf8 Class Initialized
DEBUG - 2011-07-26 08:18:11 --> UTF-8 Support Enabled
DEBUG - 2011-07-26 08:18:11 --> URI Class Initialized
DEBUG - 2011-07-26 08:18:11 --> Router Class Initialized
DEBUG - 2011-07-26 08:18:11 --> Output Class Initialized
DEBUG - 2011-07-26 08:18:11 --> Input Class Initialized
DEBUG - 2011-07-26 08:18:11 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-26 08:18:11 --> Language Class Initialized
DEBUG - 2011-07-26 08:18:11 --> Loader Class Initialized
DEBUG - 2011-07-26 08:18:11 --> Controller Class Initialized
DEBUG - 2011-07-26 08:18:11 --> Model Class Initialized
DEBUG - 2011-07-26 08:18:11 --> Model Class Initialized
DEBUG - 2011-07-26 08:18:11 --> Model Class Initialized
DEBUG - 2011-07-26 08:18:11 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-26 08:18:11 --> Database Driver Class Initialized
DEBUG - 2011-07-26 08:18:11 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-26 08:18:11 --> Helper loaded: url_helper
DEBUG - 2011-07-26 08:18:11 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-26 08:18:11 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-26 08:18:11 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-26 08:18:11 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-26 08:18:11 --> Final output sent to browser
DEBUG - 2011-07-26 08:18:11 --> Total execution time: 0.0676
DEBUG - 2011-07-26 08:18:23 --> Config Class Initialized
DEBUG - 2011-07-26 08:18:23 --> Hooks Class Initialized
DEBUG - 2011-07-26 08:18:23 --> Utf8 Class Initialized
DEBUG - 2011-07-26 08:18:23 --> UTF-8 Support Enabled
DEBUG - 2011-07-26 08:18:23 --> URI Class Initialized
DEBUG - 2011-07-26 08:18:23 --> Router Class Initialized
DEBUG - 2011-07-26 08:18:23 --> Output Class Initialized
DEBUG - 2011-07-26 08:18:23 --> Input Class Initialized
DEBUG - 2011-07-26 08:18:23 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-26 08:18:23 --> Language Class Initialized
DEBUG - 2011-07-26 08:18:23 --> Loader Class Initialized
DEBUG - 2011-07-26 08:18:23 --> Controller Class Initialized
DEBUG - 2011-07-26 08:18:23 --> Model Class Initialized
DEBUG - 2011-07-26 08:18:23 --> Model Class Initialized
DEBUG - 2011-07-26 08:18:23 --> Model Class Initialized
DEBUG - 2011-07-26 08:18:23 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-26 08:18:23 --> Database Driver Class Initialized
DEBUG - 2011-07-26 08:18:24 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-26 08:18:24 --> Helper loaded: url_helper
DEBUG - 2011-07-26 08:18:24 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-26 08:18:24 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-26 08:18:24 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-26 08:18:24 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-26 08:18:24 --> Final output sent to browser
DEBUG - 2011-07-26 08:18:24 --> Total execution time: 1.0399
DEBUG - 2011-07-26 08:18:26 --> Config Class Initialized
DEBUG - 2011-07-26 08:18:26 --> Hooks Class Initialized
DEBUG - 2011-07-26 08:18:26 --> Utf8 Class Initialized
DEBUG - 2011-07-26 08:18:26 --> UTF-8 Support Enabled
DEBUG - 2011-07-26 08:18:26 --> URI Class Initialized
DEBUG - 2011-07-26 08:18:26 --> Router Class Initialized
ERROR - 2011-07-26 08:18:26 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-26 08:18:42 --> Config Class Initialized
DEBUG - 2011-07-26 08:18:42 --> Hooks Class Initialized
DEBUG - 2011-07-26 08:18:42 --> Utf8 Class Initialized
DEBUG - 2011-07-26 08:18:42 --> UTF-8 Support Enabled
DEBUG - 2011-07-26 08:18:42 --> URI Class Initialized
DEBUG - 2011-07-26 08:18:42 --> Router Class Initialized
DEBUG - 2011-07-26 08:18:42 --> Output Class Initialized
DEBUG - 2011-07-26 08:18:42 --> Input Class Initialized
DEBUG - 2011-07-26 08:18:42 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-26 08:18:42 --> Language Class Initialized
DEBUG - 2011-07-26 08:18:42 --> Loader Class Initialized
DEBUG - 2011-07-26 08:18:42 --> Controller Class Initialized
DEBUG - 2011-07-26 08:18:42 --> Model Class Initialized
DEBUG - 2011-07-26 08:18:42 --> Model Class Initialized
DEBUG - 2011-07-26 08:18:42 --> Model Class Initialized
DEBUG - 2011-07-26 08:18:42 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-26 08:18:42 --> Database Driver Class Initialized
DEBUG - 2011-07-26 08:18:42 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-26 08:18:42 --> Helper loaded: url_helper
DEBUG - 2011-07-26 08:18:42 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-26 08:18:42 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-26 08:18:42 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-26 08:18:42 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-26 08:18:42 --> Final output sent to browser
DEBUG - 2011-07-26 08:18:42 --> Total execution time: 0.3469
DEBUG - 2011-07-26 08:18:44 --> Config Class Initialized
DEBUG - 2011-07-26 08:18:44 --> Hooks Class Initialized
DEBUG - 2011-07-26 08:18:44 --> Utf8 Class Initialized
DEBUG - 2011-07-26 08:18:44 --> UTF-8 Support Enabled
DEBUG - 2011-07-26 08:18:44 --> URI Class Initialized
DEBUG - 2011-07-26 08:18:44 --> Router Class Initialized
ERROR - 2011-07-26 08:18:44 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-26 08:18:56 --> Config Class Initialized
DEBUG - 2011-07-26 08:18:56 --> Hooks Class Initialized
DEBUG - 2011-07-26 08:18:56 --> Utf8 Class Initialized
DEBUG - 2011-07-26 08:18:56 --> UTF-8 Support Enabled
DEBUG - 2011-07-26 08:18:56 --> URI Class Initialized
DEBUG - 2011-07-26 08:18:56 --> Router Class Initialized
DEBUG - 2011-07-26 08:18:56 --> Output Class Initialized
DEBUG - 2011-07-26 08:18:56 --> Input Class Initialized
DEBUG - 2011-07-26 08:18:56 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-26 08:18:56 --> Language Class Initialized
DEBUG - 2011-07-26 08:18:56 --> Loader Class Initialized
DEBUG - 2011-07-26 08:18:56 --> Controller Class Initialized
DEBUG - 2011-07-26 08:18:56 --> Model Class Initialized
DEBUG - 2011-07-26 08:18:56 --> Model Class Initialized
DEBUG - 2011-07-26 08:18:56 --> Model Class Initialized
DEBUG - 2011-07-26 08:18:56 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-26 08:18:56 --> Database Driver Class Initialized
DEBUG - 2011-07-26 08:18:56 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-26 08:18:56 --> Helper loaded: url_helper
DEBUG - 2011-07-26 08:18:56 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-26 08:18:56 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-26 08:18:56 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-26 08:18:56 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-26 08:18:56 --> Final output sent to browser
DEBUG - 2011-07-26 08:18:56 --> Total execution time: 0.0476
DEBUG - 2011-07-26 08:19:08 --> Config Class Initialized
DEBUG - 2011-07-26 08:19:08 --> Hooks Class Initialized
DEBUG - 2011-07-26 08:19:08 --> Utf8 Class Initialized
DEBUG - 2011-07-26 08:19:08 --> UTF-8 Support Enabled
DEBUG - 2011-07-26 08:19:08 --> URI Class Initialized
DEBUG - 2011-07-26 08:19:08 --> Router Class Initialized
DEBUG - 2011-07-26 08:19:08 --> Output Class Initialized
DEBUG - 2011-07-26 08:19:08 --> Input Class Initialized
DEBUG - 2011-07-26 08:19:08 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-26 08:19:08 --> Language Class Initialized
DEBUG - 2011-07-26 08:19:08 --> Loader Class Initialized
DEBUG - 2011-07-26 08:19:08 --> Controller Class Initialized
DEBUG - 2011-07-26 08:19:08 --> Model Class Initialized
DEBUG - 2011-07-26 08:19:08 --> Model Class Initialized
DEBUG - 2011-07-26 08:19:08 --> Model Class Initialized
DEBUG - 2011-07-26 08:19:08 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-26 08:19:08 --> Database Driver Class Initialized
DEBUG - 2011-07-26 08:19:09 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-26 08:19:09 --> Helper loaded: url_helper
DEBUG - 2011-07-26 08:19:09 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-26 08:19:09 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-26 08:19:09 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-26 08:19:09 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-26 08:19:09 --> Final output sent to browser
DEBUG - 2011-07-26 08:19:09 --> Total execution time: 1.1246
DEBUG - 2011-07-26 08:19:11 --> Config Class Initialized
DEBUG - 2011-07-26 08:19:11 --> Hooks Class Initialized
DEBUG - 2011-07-26 08:19:11 --> Utf8 Class Initialized
DEBUG - 2011-07-26 08:19:11 --> UTF-8 Support Enabled
DEBUG - 2011-07-26 08:19:11 --> URI Class Initialized
DEBUG - 2011-07-26 08:19:11 --> Router Class Initialized
ERROR - 2011-07-26 08:19:11 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-26 08:19:28 --> Config Class Initialized
DEBUG - 2011-07-26 08:19:28 --> Hooks Class Initialized
DEBUG - 2011-07-26 08:19:28 --> Utf8 Class Initialized
DEBUG - 2011-07-26 08:19:28 --> UTF-8 Support Enabled
DEBUG - 2011-07-26 08:19:28 --> URI Class Initialized
DEBUG - 2011-07-26 08:19:28 --> Router Class Initialized
DEBUG - 2011-07-26 08:19:28 --> Output Class Initialized
DEBUG - 2011-07-26 08:19:28 --> Input Class Initialized
DEBUG - 2011-07-26 08:19:28 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-26 08:19:28 --> Language Class Initialized
DEBUG - 2011-07-26 08:19:28 --> Loader Class Initialized
DEBUG - 2011-07-26 08:19:28 --> Controller Class Initialized
DEBUG - 2011-07-26 08:19:28 --> Model Class Initialized
DEBUG - 2011-07-26 08:19:28 --> Model Class Initialized
DEBUG - 2011-07-26 08:19:28 --> Model Class Initialized
DEBUG - 2011-07-26 08:19:28 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-26 08:19:28 --> Database Driver Class Initialized
DEBUG - 2011-07-26 08:19:28 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-26 08:19:28 --> Helper loaded: url_helper
DEBUG - 2011-07-26 08:19:28 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-26 08:19:28 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-26 08:19:28 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-26 08:19:28 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-26 08:19:28 --> Final output sent to browser
DEBUG - 2011-07-26 08:19:28 --> Total execution time: 0.6440
DEBUG - 2011-07-26 08:19:31 --> Config Class Initialized
DEBUG - 2011-07-26 08:19:31 --> Hooks Class Initialized
DEBUG - 2011-07-26 08:19:31 --> Utf8 Class Initialized
DEBUG - 2011-07-26 08:19:31 --> UTF-8 Support Enabled
DEBUG - 2011-07-26 08:19:31 --> URI Class Initialized
DEBUG - 2011-07-26 08:19:31 --> Router Class Initialized
ERROR - 2011-07-26 08:19:31 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-26 08:19:34 --> Config Class Initialized
DEBUG - 2011-07-26 08:19:34 --> Hooks Class Initialized
DEBUG - 2011-07-26 08:19:34 --> Utf8 Class Initialized
DEBUG - 2011-07-26 08:19:34 --> UTF-8 Support Enabled
DEBUG - 2011-07-26 08:19:34 --> URI Class Initialized
DEBUG - 2011-07-26 08:19:34 --> Router Class Initialized
DEBUG - 2011-07-26 08:19:34 --> Output Class Initialized
DEBUG - 2011-07-26 08:19:34 --> Input Class Initialized
DEBUG - 2011-07-26 08:19:34 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-26 08:19:34 --> Language Class Initialized
DEBUG - 2011-07-26 08:19:34 --> Loader Class Initialized
DEBUG - 2011-07-26 08:19:34 --> Controller Class Initialized
DEBUG - 2011-07-26 08:19:34 --> Model Class Initialized
DEBUG - 2011-07-26 08:19:34 --> Model Class Initialized
DEBUG - 2011-07-26 08:19:34 --> Model Class Initialized
DEBUG - 2011-07-26 08:19:34 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-26 08:19:34 --> Database Driver Class Initialized
DEBUG - 2011-07-26 08:19:34 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-26 08:19:34 --> Helper loaded: url_helper
DEBUG - 2011-07-26 08:19:34 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-26 08:19:34 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-26 08:19:34 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-26 08:19:34 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-26 08:19:34 --> Final output sent to browser
DEBUG - 2011-07-26 08:19:34 --> Total execution time: 0.0564
DEBUG - 2011-07-26 08:19:49 --> Config Class Initialized
DEBUG - 2011-07-26 08:19:49 --> Hooks Class Initialized
DEBUG - 2011-07-26 08:19:49 --> Utf8 Class Initialized
DEBUG - 2011-07-26 08:19:49 --> UTF-8 Support Enabled
DEBUG - 2011-07-26 08:19:49 --> URI Class Initialized
DEBUG - 2011-07-26 08:19:49 --> Router Class Initialized
DEBUG - 2011-07-26 08:19:49 --> Output Class Initialized
DEBUG - 2011-07-26 08:19:49 --> Input Class Initialized
DEBUG - 2011-07-26 08:19:49 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-26 08:19:49 --> Language Class Initialized
DEBUG - 2011-07-26 08:19:49 --> Loader Class Initialized
DEBUG - 2011-07-26 08:19:49 --> Controller Class Initialized
DEBUG - 2011-07-26 08:19:49 --> Model Class Initialized
DEBUG - 2011-07-26 08:19:49 --> Model Class Initialized
DEBUG - 2011-07-26 08:19:49 --> Model Class Initialized
DEBUG - 2011-07-26 08:19:49 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-26 08:19:49 --> Database Driver Class Initialized
DEBUG - 2011-07-26 08:19:50 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-26 08:19:50 --> Helper loaded: url_helper
DEBUG - 2011-07-26 08:19:50 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-26 08:19:50 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-26 08:19:50 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-26 08:19:50 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-26 08:19:50 --> Final output sent to browser
DEBUG - 2011-07-26 08:19:50 --> Total execution time: 0.2034
DEBUG - 2011-07-26 08:19:50 --> Config Class Initialized
DEBUG - 2011-07-26 08:19:50 --> Hooks Class Initialized
DEBUG - 2011-07-26 08:19:50 --> Utf8 Class Initialized
DEBUG - 2011-07-26 08:19:50 --> UTF-8 Support Enabled
DEBUG - 2011-07-26 08:19:50 --> URI Class Initialized
DEBUG - 2011-07-26 08:19:50 --> Router Class Initialized
DEBUG - 2011-07-26 08:19:50 --> Output Class Initialized
DEBUG - 2011-07-26 08:19:50 --> Input Class Initialized
DEBUG - 2011-07-26 08:19:50 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-26 08:19:50 --> Language Class Initialized
DEBUG - 2011-07-26 08:19:50 --> Loader Class Initialized
DEBUG - 2011-07-26 08:19:50 --> Controller Class Initialized
DEBUG - 2011-07-26 08:19:50 --> Model Class Initialized
DEBUG - 2011-07-26 08:19:50 --> Model Class Initialized
DEBUG - 2011-07-26 08:19:50 --> Model Class Initialized
DEBUG - 2011-07-26 08:19:50 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-26 08:19:50 --> Database Driver Class Initialized
DEBUG - 2011-07-26 08:19:51 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-26 08:19:51 --> Helper loaded: url_helper
DEBUG - 2011-07-26 08:19:51 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-26 08:19:51 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-26 08:19:51 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-26 08:19:51 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-26 08:19:51 --> Final output sent to browser
DEBUG - 2011-07-26 08:19:51 --> Total execution time: 1.3475
DEBUG - 2011-07-26 08:19:53 --> Config Class Initialized
DEBUG - 2011-07-26 08:19:53 --> Hooks Class Initialized
DEBUG - 2011-07-26 08:19:53 --> Utf8 Class Initialized
DEBUG - 2011-07-26 08:19:53 --> UTF-8 Support Enabled
DEBUG - 2011-07-26 08:19:53 --> URI Class Initialized
DEBUG - 2011-07-26 08:19:53 --> Router Class Initialized
ERROR - 2011-07-26 08:19:53 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-26 08:19:58 --> Config Class Initialized
DEBUG - 2011-07-26 08:19:58 --> Hooks Class Initialized
DEBUG - 2011-07-26 08:19:58 --> Utf8 Class Initialized
DEBUG - 2011-07-26 08:19:58 --> UTF-8 Support Enabled
DEBUG - 2011-07-26 08:19:58 --> URI Class Initialized
DEBUG - 2011-07-26 08:19:58 --> Router Class Initialized
DEBUG - 2011-07-26 08:19:58 --> Output Class Initialized
DEBUG - 2011-07-26 08:19:58 --> Input Class Initialized
DEBUG - 2011-07-26 08:19:58 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-26 08:19:58 --> Language Class Initialized
DEBUG - 2011-07-26 08:19:58 --> Loader Class Initialized
DEBUG - 2011-07-26 08:19:58 --> Controller Class Initialized
DEBUG - 2011-07-26 08:19:58 --> Model Class Initialized
DEBUG - 2011-07-26 08:19:58 --> Model Class Initialized
DEBUG - 2011-07-26 08:19:58 --> Model Class Initialized
DEBUG - 2011-07-26 08:19:58 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-26 08:19:58 --> Database Driver Class Initialized
DEBUG - 2011-07-26 08:19:58 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-26 08:19:58 --> Helper loaded: url_helper
DEBUG - 2011-07-26 08:19:58 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-26 08:19:58 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-26 08:19:58 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-26 08:19:58 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-26 08:19:58 --> Final output sent to browser
DEBUG - 2011-07-26 08:19:58 --> Total execution time: 0.0872
DEBUG - 2011-07-26 08:20:10 --> Config Class Initialized
DEBUG - 2011-07-26 08:20:10 --> Hooks Class Initialized
DEBUG - 2011-07-26 08:20:10 --> Utf8 Class Initialized
DEBUG - 2011-07-26 08:20:10 --> UTF-8 Support Enabled
DEBUG - 2011-07-26 08:20:10 --> URI Class Initialized
DEBUG - 2011-07-26 08:20:10 --> Router Class Initialized
DEBUG - 2011-07-26 08:20:10 --> Output Class Initialized
DEBUG - 2011-07-26 08:20:10 --> Input Class Initialized
DEBUG - 2011-07-26 08:20:10 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-26 08:20:10 --> Language Class Initialized
DEBUG - 2011-07-26 08:20:10 --> Loader Class Initialized
DEBUG - 2011-07-26 08:20:10 --> Controller Class Initialized
DEBUG - 2011-07-26 08:20:10 --> Model Class Initialized
DEBUG - 2011-07-26 08:20:10 --> Model Class Initialized
DEBUG - 2011-07-26 08:20:10 --> Model Class Initialized
DEBUG - 2011-07-26 08:20:10 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-26 08:20:10 --> Database Driver Class Initialized
DEBUG - 2011-07-26 08:20:10 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-26 08:20:10 --> Helper loaded: url_helper
DEBUG - 2011-07-26 08:20:10 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-26 08:20:10 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-26 08:20:10 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-26 08:20:10 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-26 08:20:10 --> Final output sent to browser
DEBUG - 2011-07-26 08:20:10 --> Total execution time: 0.2472
DEBUG - 2011-07-26 08:20:12 --> Config Class Initialized
DEBUG - 2011-07-26 08:20:12 --> Hooks Class Initialized
DEBUG - 2011-07-26 08:20:12 --> Utf8 Class Initialized
DEBUG - 2011-07-26 08:20:12 --> UTF-8 Support Enabled
DEBUG - 2011-07-26 08:20:12 --> URI Class Initialized
DEBUG - 2011-07-26 08:20:12 --> Router Class Initialized
DEBUG - 2011-07-26 08:20:12 --> Output Class Initialized
DEBUG - 2011-07-26 08:20:12 --> Input Class Initialized
DEBUG - 2011-07-26 08:20:12 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-26 08:20:12 --> Language Class Initialized
DEBUG - 2011-07-26 08:20:12 --> Loader Class Initialized
DEBUG - 2011-07-26 08:20:12 --> Controller Class Initialized
DEBUG - 2011-07-26 08:20:12 --> Model Class Initialized
DEBUG - 2011-07-26 08:20:12 --> Model Class Initialized
DEBUG - 2011-07-26 08:20:12 --> Model Class Initialized
DEBUG - 2011-07-26 08:20:12 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-26 08:20:12 --> Database Driver Class Initialized
DEBUG - 2011-07-26 08:20:12 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-26 08:20:12 --> Helper loaded: url_helper
DEBUG - 2011-07-26 08:20:12 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-26 08:20:12 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-26 08:20:12 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-26 08:20:12 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-26 08:20:12 --> Final output sent to browser
DEBUG - 2011-07-26 08:20:12 --> Total execution time: 0.0484
DEBUG - 2011-07-26 08:20:12 --> Config Class Initialized
DEBUG - 2011-07-26 08:20:12 --> Hooks Class Initialized
DEBUG - 2011-07-26 08:20:12 --> Utf8 Class Initialized
DEBUG - 2011-07-26 08:20:12 --> UTF-8 Support Enabled
DEBUG - 2011-07-26 08:20:12 --> URI Class Initialized
DEBUG - 2011-07-26 08:20:12 --> Router Class Initialized
ERROR - 2011-07-26 08:20:12 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-26 08:20:22 --> Config Class Initialized
DEBUG - 2011-07-26 08:20:22 --> Hooks Class Initialized
DEBUG - 2011-07-26 08:20:22 --> Utf8 Class Initialized
DEBUG - 2011-07-26 08:20:22 --> UTF-8 Support Enabled
DEBUG - 2011-07-26 08:20:22 --> URI Class Initialized
DEBUG - 2011-07-26 08:20:22 --> Router Class Initialized
DEBUG - 2011-07-26 08:20:22 --> Output Class Initialized
DEBUG - 2011-07-26 08:20:22 --> Input Class Initialized
DEBUG - 2011-07-26 08:20:22 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-26 08:20:22 --> Language Class Initialized
DEBUG - 2011-07-26 08:20:22 --> Loader Class Initialized
DEBUG - 2011-07-26 08:20:22 --> Controller Class Initialized
DEBUG - 2011-07-26 08:20:22 --> Model Class Initialized
DEBUG - 2011-07-26 08:20:22 --> Model Class Initialized
DEBUG - 2011-07-26 08:20:22 --> Model Class Initialized
DEBUG - 2011-07-26 08:20:22 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-26 08:20:22 --> Database Driver Class Initialized
DEBUG - 2011-07-26 08:20:22 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-26 08:20:22 --> Helper loaded: url_helper
DEBUG - 2011-07-26 08:20:22 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-26 08:20:22 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-26 08:20:22 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-26 08:20:22 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-26 08:20:22 --> Final output sent to browser
DEBUG - 2011-07-26 08:20:22 --> Total execution time: 0.0802
DEBUG - 2011-07-26 08:20:29 --> Config Class Initialized
DEBUG - 2011-07-26 08:20:29 --> Hooks Class Initialized
DEBUG - 2011-07-26 08:20:29 --> Utf8 Class Initialized
DEBUG - 2011-07-26 08:20:29 --> UTF-8 Support Enabled
DEBUG - 2011-07-26 08:20:29 --> URI Class Initialized
DEBUG - 2011-07-26 08:20:29 --> Router Class Initialized
DEBUG - 2011-07-26 08:20:29 --> Output Class Initialized
DEBUG - 2011-07-26 08:20:29 --> Input Class Initialized
DEBUG - 2011-07-26 08:20:29 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-26 08:20:29 --> Language Class Initialized
DEBUG - 2011-07-26 08:20:29 --> Loader Class Initialized
DEBUG - 2011-07-26 08:20:29 --> Controller Class Initialized
DEBUG - 2011-07-26 08:20:29 --> Model Class Initialized
DEBUG - 2011-07-26 08:20:29 --> Model Class Initialized
DEBUG - 2011-07-26 08:20:29 --> Model Class Initialized
DEBUG - 2011-07-26 08:20:29 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-26 08:20:29 --> Database Driver Class Initialized
DEBUG - 2011-07-26 08:20:29 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-26 08:20:29 --> Helper loaded: url_helper
DEBUG - 2011-07-26 08:20:29 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-26 08:20:29 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-26 08:20:29 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-26 08:20:29 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-26 08:20:29 --> Final output sent to browser
DEBUG - 2011-07-26 08:20:29 --> Total execution time: 0.0470
DEBUG - 2011-07-26 08:20:31 --> Config Class Initialized
DEBUG - 2011-07-26 08:20:31 --> Hooks Class Initialized
DEBUG - 2011-07-26 08:20:31 --> Utf8 Class Initialized
DEBUG - 2011-07-26 08:20:31 --> UTF-8 Support Enabled
DEBUG - 2011-07-26 08:20:31 --> URI Class Initialized
DEBUG - 2011-07-26 08:20:31 --> Router Class Initialized
ERROR - 2011-07-26 08:20:31 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-26 08:20:40 --> Config Class Initialized
DEBUG - 2011-07-26 08:20:40 --> Hooks Class Initialized
DEBUG - 2011-07-26 08:20:40 --> Utf8 Class Initialized
DEBUG - 2011-07-26 08:20:40 --> UTF-8 Support Enabled
DEBUG - 2011-07-26 08:20:40 --> URI Class Initialized
DEBUG - 2011-07-26 08:20:40 --> Router Class Initialized
DEBUG - 2011-07-26 08:20:40 --> Output Class Initialized
DEBUG - 2011-07-26 08:20:40 --> Input Class Initialized
DEBUG - 2011-07-26 08:20:40 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-26 08:20:40 --> Language Class Initialized
DEBUG - 2011-07-26 08:20:40 --> Loader Class Initialized
DEBUG - 2011-07-26 08:20:40 --> Controller Class Initialized
DEBUG - 2011-07-26 08:20:40 --> Model Class Initialized
DEBUG - 2011-07-26 08:20:40 --> Model Class Initialized
DEBUG - 2011-07-26 08:20:40 --> Model Class Initialized
DEBUG - 2011-07-26 08:20:40 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-26 08:20:40 --> Database Driver Class Initialized
DEBUG - 2011-07-26 08:20:40 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-26 08:20:40 --> Helper loaded: url_helper
DEBUG - 2011-07-26 08:20:40 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-26 08:20:40 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-26 08:20:40 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-26 08:20:40 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-26 08:20:40 --> Final output sent to browser
DEBUG - 2011-07-26 08:20:40 --> Total execution time: 0.0709
DEBUG - 2011-07-26 08:20:42 --> Config Class Initialized
DEBUG - 2011-07-26 08:20:42 --> Hooks Class Initialized
DEBUG - 2011-07-26 08:20:42 --> Utf8 Class Initialized
DEBUG - 2011-07-26 08:20:42 --> UTF-8 Support Enabled
DEBUG - 2011-07-26 08:20:42 --> URI Class Initialized
DEBUG - 2011-07-26 08:20:42 --> Router Class Initialized
ERROR - 2011-07-26 08:20:42 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-26 08:20:48 --> Config Class Initialized
DEBUG - 2011-07-26 08:20:48 --> Hooks Class Initialized
DEBUG - 2011-07-26 08:20:48 --> Utf8 Class Initialized
DEBUG - 2011-07-26 08:20:48 --> UTF-8 Support Enabled
DEBUG - 2011-07-26 08:20:48 --> URI Class Initialized
DEBUG - 2011-07-26 08:20:48 --> Router Class Initialized
DEBUG - 2011-07-26 08:20:48 --> Output Class Initialized
DEBUG - 2011-07-26 08:20:48 --> Input Class Initialized
DEBUG - 2011-07-26 08:20:48 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-26 08:20:48 --> Language Class Initialized
DEBUG - 2011-07-26 08:20:48 --> Loader Class Initialized
DEBUG - 2011-07-26 08:20:48 --> Controller Class Initialized
DEBUG - 2011-07-26 08:20:48 --> Model Class Initialized
DEBUG - 2011-07-26 08:20:48 --> Model Class Initialized
DEBUG - 2011-07-26 08:20:48 --> Model Class Initialized
DEBUG - 2011-07-26 08:20:48 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-26 08:20:48 --> Database Driver Class Initialized
DEBUG - 2011-07-26 08:20:48 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-26 08:20:48 --> Helper loaded: url_helper
DEBUG - 2011-07-26 08:20:48 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-26 08:20:48 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-26 08:20:48 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-26 08:20:48 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-26 08:20:48 --> Final output sent to browser
DEBUG - 2011-07-26 08:20:48 --> Total execution time: 0.0480
DEBUG - 2011-07-26 08:20:49 --> Config Class Initialized
DEBUG - 2011-07-26 08:20:49 --> Hooks Class Initialized
DEBUG - 2011-07-26 08:20:49 --> Utf8 Class Initialized
DEBUG - 2011-07-26 08:20:49 --> UTF-8 Support Enabled
DEBUG - 2011-07-26 08:20:49 --> URI Class Initialized
DEBUG - 2011-07-26 08:20:49 --> Router Class Initialized
ERROR - 2011-07-26 08:20:49 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-26 08:44:00 --> Config Class Initialized
DEBUG - 2011-07-26 08:44:00 --> Hooks Class Initialized
DEBUG - 2011-07-26 08:44:00 --> Utf8 Class Initialized
DEBUG - 2011-07-26 08:44:00 --> UTF-8 Support Enabled
DEBUG - 2011-07-26 08:44:00 --> URI Class Initialized
DEBUG - 2011-07-26 08:44:00 --> Router Class Initialized
DEBUG - 2011-07-26 08:44:00 --> Output Class Initialized
DEBUG - 2011-07-26 08:44:00 --> Input Class Initialized
DEBUG - 2011-07-26 08:44:00 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-26 08:44:00 --> Language Class Initialized
DEBUG - 2011-07-26 08:44:00 --> Loader Class Initialized
DEBUG - 2011-07-26 08:44:00 --> Controller Class Initialized
ERROR - 2011-07-26 08:44:00 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-26 08:44:00 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-26 08:44:00 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-26 08:44:00 --> Model Class Initialized
DEBUG - 2011-07-26 08:44:00 --> Model Class Initialized
DEBUG - 2011-07-26 08:44:00 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-26 08:44:00 --> Database Driver Class Initialized
DEBUG - 2011-07-26 08:44:00 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-26 08:44:00 --> Helper loaded: url_helper
DEBUG - 2011-07-26 08:44:00 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-26 08:44:00 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-26 08:44:00 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-26 08:44:00 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-26 08:44:00 --> Final output sent to browser
DEBUG - 2011-07-26 08:44:00 --> Total execution time: 0.0359
DEBUG - 2011-07-26 08:44:02 --> Config Class Initialized
DEBUG - 2011-07-26 08:44:02 --> Hooks Class Initialized
DEBUG - 2011-07-26 08:44:02 --> Utf8 Class Initialized
DEBUG - 2011-07-26 08:44:02 --> UTF-8 Support Enabled
DEBUG - 2011-07-26 08:44:02 --> URI Class Initialized
DEBUG - 2011-07-26 08:44:02 --> Router Class Initialized
DEBUG - 2011-07-26 08:44:02 --> Output Class Initialized
DEBUG - 2011-07-26 08:44:02 --> Input Class Initialized
DEBUG - 2011-07-26 08:44:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-26 08:44:02 --> Language Class Initialized
DEBUG - 2011-07-26 08:44:02 --> Loader Class Initialized
DEBUG - 2011-07-26 08:44:02 --> Controller Class Initialized
DEBUG - 2011-07-26 08:44:02 --> Model Class Initialized
DEBUG - 2011-07-26 08:44:02 --> Model Class Initialized
DEBUG - 2011-07-26 08:44:02 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-26 08:44:02 --> Database Driver Class Initialized
DEBUG - 2011-07-26 08:44:03 --> Final output sent to browser
DEBUG - 2011-07-26 08:44:03 --> Total execution time: 1.0548
DEBUG - 2011-07-26 08:44:27 --> Config Class Initialized
DEBUG - 2011-07-26 08:44:27 --> Hooks Class Initialized
DEBUG - 2011-07-26 08:44:27 --> Utf8 Class Initialized
DEBUG - 2011-07-26 08:44:27 --> UTF-8 Support Enabled
DEBUG - 2011-07-26 08:44:27 --> URI Class Initialized
DEBUG - 2011-07-26 08:44:27 --> Router Class Initialized
DEBUG - 2011-07-26 08:44:27 --> Output Class Initialized
DEBUG - 2011-07-26 08:44:27 --> Input Class Initialized
DEBUG - 2011-07-26 08:44:27 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-26 08:44:27 --> Language Class Initialized
DEBUG - 2011-07-26 08:44:27 --> Loader Class Initialized
DEBUG - 2011-07-26 08:44:27 --> Controller Class Initialized
ERROR - 2011-07-26 08:44:27 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-26 08:44:27 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-26 08:44:27 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-26 08:44:27 --> Model Class Initialized
DEBUG - 2011-07-26 08:44:27 --> Model Class Initialized
DEBUG - 2011-07-26 08:44:27 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-26 08:44:27 --> Database Driver Class Initialized
DEBUG - 2011-07-26 08:44:27 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-26 08:44:27 --> Helper loaded: url_helper
DEBUG - 2011-07-26 08:44:27 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-26 08:44:27 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-26 08:44:27 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-26 08:44:27 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-26 08:44:27 --> Final output sent to browser
DEBUG - 2011-07-26 08:44:27 --> Total execution time: 0.0294
DEBUG - 2011-07-26 08:44:28 --> Config Class Initialized
DEBUG - 2011-07-26 08:44:28 --> Hooks Class Initialized
DEBUG - 2011-07-26 08:44:28 --> Utf8 Class Initialized
DEBUG - 2011-07-26 08:44:28 --> UTF-8 Support Enabled
DEBUG - 2011-07-26 08:44:28 --> URI Class Initialized
DEBUG - 2011-07-26 08:44:28 --> Router Class Initialized
DEBUG - 2011-07-26 08:44:28 --> Output Class Initialized
DEBUG - 2011-07-26 08:44:28 --> Input Class Initialized
DEBUG - 2011-07-26 08:44:28 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-26 08:44:28 --> Language Class Initialized
DEBUG - 2011-07-26 08:44:28 --> Loader Class Initialized
DEBUG - 2011-07-26 08:44:28 --> Controller Class Initialized
DEBUG - 2011-07-26 08:44:28 --> Model Class Initialized
DEBUG - 2011-07-26 08:44:28 --> Model Class Initialized
DEBUG - 2011-07-26 08:44:28 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-26 08:44:28 --> Database Driver Class Initialized
DEBUG - 2011-07-26 08:44:29 --> Final output sent to browser
DEBUG - 2011-07-26 08:44:29 --> Total execution time: 0.6263
DEBUG - 2011-07-26 08:44:37 --> Config Class Initialized
DEBUG - 2011-07-26 08:44:37 --> Hooks Class Initialized
DEBUG - 2011-07-26 08:44:37 --> Utf8 Class Initialized
DEBUG - 2011-07-26 08:44:37 --> UTF-8 Support Enabled
DEBUG - 2011-07-26 08:44:37 --> URI Class Initialized
DEBUG - 2011-07-26 08:44:37 --> Router Class Initialized
DEBUG - 2011-07-26 08:44:37 --> Output Class Initialized
DEBUG - 2011-07-26 08:44:37 --> Input Class Initialized
DEBUG - 2011-07-26 08:44:37 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-26 08:44:37 --> Language Class Initialized
DEBUG - 2011-07-26 08:44:37 --> Loader Class Initialized
DEBUG - 2011-07-26 08:44:37 --> Controller Class Initialized
ERROR - 2011-07-26 08:44:37 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-26 08:44:37 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-26 08:44:37 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-26 08:44:37 --> Model Class Initialized
DEBUG - 2011-07-26 08:44:37 --> Model Class Initialized
DEBUG - 2011-07-26 08:44:37 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-26 08:44:37 --> Database Driver Class Initialized
DEBUG - 2011-07-26 08:44:37 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-26 08:44:37 --> Helper loaded: url_helper
DEBUG - 2011-07-26 08:44:37 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-26 08:44:37 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-26 08:44:37 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-26 08:44:37 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-26 08:44:37 --> Final output sent to browser
DEBUG - 2011-07-26 08:44:37 --> Total execution time: 0.0271
DEBUG - 2011-07-26 08:44:38 --> Config Class Initialized
DEBUG - 2011-07-26 08:44:38 --> Hooks Class Initialized
DEBUG - 2011-07-26 08:44:38 --> Utf8 Class Initialized
DEBUG - 2011-07-26 08:44:38 --> UTF-8 Support Enabled
DEBUG - 2011-07-26 08:44:38 --> URI Class Initialized
DEBUG - 2011-07-26 08:44:38 --> Router Class Initialized
DEBUG - 2011-07-26 08:44:38 --> Output Class Initialized
DEBUG - 2011-07-26 08:44:38 --> Input Class Initialized
DEBUG - 2011-07-26 08:44:38 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-26 08:44:38 --> Language Class Initialized
DEBUG - 2011-07-26 08:44:38 --> Loader Class Initialized
DEBUG - 2011-07-26 08:44:38 --> Controller Class Initialized
DEBUG - 2011-07-26 08:44:38 --> Model Class Initialized
DEBUG - 2011-07-26 08:44:38 --> Model Class Initialized
DEBUG - 2011-07-26 08:44:38 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-26 08:44:38 --> Database Driver Class Initialized
DEBUG - 2011-07-26 08:44:38 --> Final output sent to browser
DEBUG - 2011-07-26 08:44:38 --> Total execution time: 0.5506
DEBUG - 2011-07-26 08:45:00 --> Config Class Initialized
DEBUG - 2011-07-26 08:45:00 --> Hooks Class Initialized
DEBUG - 2011-07-26 08:45:00 --> Utf8 Class Initialized
DEBUG - 2011-07-26 08:45:00 --> UTF-8 Support Enabled
DEBUG - 2011-07-26 08:45:00 --> URI Class Initialized
DEBUG - 2011-07-26 08:45:00 --> Router Class Initialized
DEBUG - 2011-07-26 08:45:00 --> Output Class Initialized
DEBUG - 2011-07-26 08:45:00 --> Input Class Initialized
DEBUG - 2011-07-26 08:45:00 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-26 08:45:00 --> Language Class Initialized
DEBUG - 2011-07-26 08:45:00 --> Loader Class Initialized
DEBUG - 2011-07-26 08:45:00 --> Controller Class Initialized
ERROR - 2011-07-26 08:45:00 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-26 08:45:00 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-26 08:45:00 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-26 08:45:00 --> Model Class Initialized
DEBUG - 2011-07-26 08:45:00 --> Model Class Initialized
DEBUG - 2011-07-26 08:45:00 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-26 08:45:00 --> Database Driver Class Initialized
DEBUG - 2011-07-26 08:45:00 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-26 08:45:00 --> Helper loaded: url_helper
DEBUG - 2011-07-26 08:45:00 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-26 08:45:00 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-26 08:45:00 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-26 08:45:00 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-26 08:45:00 --> Final output sent to browser
DEBUG - 2011-07-26 08:45:00 --> Total execution time: 0.0292
DEBUG - 2011-07-26 08:45:01 --> Config Class Initialized
DEBUG - 2011-07-26 08:45:01 --> Hooks Class Initialized
DEBUG - 2011-07-26 08:45:01 --> Utf8 Class Initialized
DEBUG - 2011-07-26 08:45:01 --> UTF-8 Support Enabled
DEBUG - 2011-07-26 08:45:01 --> URI Class Initialized
DEBUG - 2011-07-26 08:45:01 --> Router Class Initialized
DEBUG - 2011-07-26 08:45:01 --> Output Class Initialized
DEBUG - 2011-07-26 08:45:01 --> Input Class Initialized
DEBUG - 2011-07-26 08:45:01 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-26 08:45:01 --> Language Class Initialized
DEBUG - 2011-07-26 08:45:01 --> Loader Class Initialized
DEBUG - 2011-07-26 08:45:01 --> Controller Class Initialized
DEBUG - 2011-07-26 08:45:01 --> Model Class Initialized
DEBUG - 2011-07-26 08:45:01 --> Model Class Initialized
DEBUG - 2011-07-26 08:45:01 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-26 08:45:01 --> Database Driver Class Initialized
DEBUG - 2011-07-26 08:45:01 --> Final output sent to browser
DEBUG - 2011-07-26 08:45:01 --> Total execution time: 0.5875
DEBUG - 2011-07-26 08:55:49 --> Config Class Initialized
DEBUG - 2011-07-26 08:55:49 --> Hooks Class Initialized
DEBUG - 2011-07-26 08:55:49 --> Utf8 Class Initialized
DEBUG - 2011-07-26 08:55:49 --> UTF-8 Support Enabled
DEBUG - 2011-07-26 08:55:49 --> URI Class Initialized
DEBUG - 2011-07-26 08:55:49 --> Router Class Initialized
DEBUG - 2011-07-26 08:55:49 --> Output Class Initialized
DEBUG - 2011-07-26 08:55:49 --> Input Class Initialized
DEBUG - 2011-07-26 08:55:49 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-26 08:55:49 --> Language Class Initialized
DEBUG - 2011-07-26 08:55:49 --> Loader Class Initialized
DEBUG - 2011-07-26 08:55:49 --> Controller Class Initialized
DEBUG - 2011-07-26 08:55:49 --> Model Class Initialized
DEBUG - 2011-07-26 08:55:49 --> Model Class Initialized
DEBUG - 2011-07-26 08:55:49 --> Model Class Initialized
DEBUG - 2011-07-26 08:55:49 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-26 08:55:49 --> Database Driver Class Initialized
DEBUG - 2011-07-26 08:55:49 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-26 08:55:49 --> Helper loaded: url_helper
DEBUG - 2011-07-26 08:55:49 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-26 08:55:49 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-26 08:55:49 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-26 08:55:49 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-26 08:55:49 --> Final output sent to browser
DEBUG - 2011-07-26 08:55:49 --> Total execution time: 0.5820
DEBUG - 2011-07-26 08:55:51 --> Config Class Initialized
DEBUG - 2011-07-26 08:55:51 --> Hooks Class Initialized
DEBUG - 2011-07-26 08:55:51 --> Utf8 Class Initialized
DEBUG - 2011-07-26 08:55:51 --> UTF-8 Support Enabled
DEBUG - 2011-07-26 08:55:51 --> URI Class Initialized
DEBUG - 2011-07-26 08:55:51 --> Router Class Initialized
ERROR - 2011-07-26 08:55:51 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-26 10:05:16 --> Config Class Initialized
DEBUG - 2011-07-26 10:05:16 --> Hooks Class Initialized
DEBUG - 2011-07-26 10:05:16 --> Utf8 Class Initialized
DEBUG - 2011-07-26 10:05:16 --> UTF-8 Support Enabled
DEBUG - 2011-07-26 10:05:16 --> URI Class Initialized
DEBUG - 2011-07-26 10:05:16 --> Router Class Initialized
DEBUG - 2011-07-26 10:05:16 --> Output Class Initialized
DEBUG - 2011-07-26 10:05:16 --> Input Class Initialized
DEBUG - 2011-07-26 10:05:16 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-26 10:05:16 --> Language Class Initialized
DEBUG - 2011-07-26 10:05:16 --> Loader Class Initialized
DEBUG - 2011-07-26 10:05:16 --> Controller Class Initialized
ERROR - 2011-07-26 10:05:16 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-26 10:05:16 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-26 10:05:16 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-26 10:05:16 --> Model Class Initialized
DEBUG - 2011-07-26 10:05:16 --> Model Class Initialized
DEBUG - 2011-07-26 10:05:16 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-26 10:05:16 --> Database Driver Class Initialized
DEBUG - 2011-07-26 10:05:16 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-26 10:05:16 --> Helper loaded: url_helper
DEBUG - 2011-07-26 10:05:16 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-26 10:05:16 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-26 10:05:16 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-26 10:05:16 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-26 10:05:16 --> Final output sent to browser
DEBUG - 2011-07-26 10:05:16 --> Total execution time: 0.0333
DEBUG - 2011-07-26 10:05:16 --> Config Class Initialized
DEBUG - 2011-07-26 10:05:16 --> Hooks Class Initialized
DEBUG - 2011-07-26 10:05:16 --> Utf8 Class Initialized
DEBUG - 2011-07-26 10:05:16 --> UTF-8 Support Enabled
DEBUG - 2011-07-26 10:05:16 --> URI Class Initialized
DEBUG - 2011-07-26 10:05:16 --> Router Class Initialized
DEBUG - 2011-07-26 10:05:16 --> Output Class Initialized
DEBUG - 2011-07-26 10:05:16 --> Input Class Initialized
DEBUG - 2011-07-26 10:05:16 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-26 10:05:16 --> Language Class Initialized
DEBUG - 2011-07-26 10:05:16 --> Loader Class Initialized
DEBUG - 2011-07-26 10:05:16 --> Controller Class Initialized
DEBUG - 2011-07-26 10:05:16 --> Model Class Initialized
DEBUG - 2011-07-26 10:05:16 --> Model Class Initialized
DEBUG - 2011-07-26 10:05:16 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-26 10:05:16 --> Database Driver Class Initialized
DEBUG - 2011-07-26 10:05:17 --> Final output sent to browser
DEBUG - 2011-07-26 10:05:17 --> Total execution time: 0.6105
DEBUG - 2011-07-26 10:05:17 --> Config Class Initialized
DEBUG - 2011-07-26 10:05:17 --> Hooks Class Initialized
DEBUG - 2011-07-26 10:05:17 --> Utf8 Class Initialized
DEBUG - 2011-07-26 10:05:17 --> UTF-8 Support Enabled
DEBUG - 2011-07-26 10:05:17 --> URI Class Initialized
DEBUG - 2011-07-26 10:05:17 --> Router Class Initialized
ERROR - 2011-07-26 10:05:17 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-26 10:05:17 --> Config Class Initialized
DEBUG - 2011-07-26 10:05:17 --> Hooks Class Initialized
DEBUG - 2011-07-26 10:05:17 --> Utf8 Class Initialized
DEBUG - 2011-07-26 10:05:17 --> UTF-8 Support Enabled
DEBUG - 2011-07-26 10:05:17 --> URI Class Initialized
DEBUG - 2011-07-26 10:05:17 --> Router Class Initialized
ERROR - 2011-07-26 10:05:17 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-26 10:05:18 --> Config Class Initialized
DEBUG - 2011-07-26 10:05:18 --> Hooks Class Initialized
DEBUG - 2011-07-26 10:05:18 --> Utf8 Class Initialized
DEBUG - 2011-07-26 10:05:18 --> UTF-8 Support Enabled
DEBUG - 2011-07-26 10:05:18 --> URI Class Initialized
DEBUG - 2011-07-26 10:05:18 --> Router Class Initialized
ERROR - 2011-07-26 10:05:18 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-26 12:00:22 --> Config Class Initialized
DEBUG - 2011-07-26 12:00:22 --> Hooks Class Initialized
DEBUG - 2011-07-26 12:00:22 --> Utf8 Class Initialized
DEBUG - 2011-07-26 12:00:22 --> UTF-8 Support Enabled
DEBUG - 2011-07-26 12:00:22 --> URI Class Initialized
DEBUG - 2011-07-26 12:00:22 --> Router Class Initialized
DEBUG - 2011-07-26 12:00:22 --> Output Class Initialized
DEBUG - 2011-07-26 12:00:22 --> Input Class Initialized
DEBUG - 2011-07-26 12:00:22 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-26 12:00:22 --> Language Class Initialized
DEBUG - 2011-07-26 12:00:22 --> Loader Class Initialized
DEBUG - 2011-07-26 12:00:22 --> Controller Class Initialized
ERROR - 2011-07-26 12:00:22 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-26 12:00:22 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-26 12:00:22 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-26 12:00:22 --> Model Class Initialized
DEBUG - 2011-07-26 12:00:22 --> Model Class Initialized
DEBUG - 2011-07-26 12:00:22 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-26 12:00:22 --> Database Driver Class Initialized
DEBUG - 2011-07-26 12:00:22 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-26 12:00:22 --> Helper loaded: url_helper
DEBUG - 2011-07-26 12:00:22 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-26 12:00:22 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-26 12:00:22 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-26 12:00:22 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-26 12:00:22 --> Final output sent to browser
DEBUG - 2011-07-26 12:00:22 --> Total execution time: 0.1687
DEBUG - 2011-07-26 12:00:23 --> Config Class Initialized
DEBUG - 2011-07-26 12:00:23 --> Hooks Class Initialized
DEBUG - 2011-07-26 12:00:23 --> Utf8 Class Initialized
DEBUG - 2011-07-26 12:00:23 --> UTF-8 Support Enabled
DEBUG - 2011-07-26 12:00:23 --> URI Class Initialized
DEBUG - 2011-07-26 12:00:23 --> Router Class Initialized
DEBUG - 2011-07-26 12:00:23 --> Output Class Initialized
DEBUG - 2011-07-26 12:00:23 --> Input Class Initialized
DEBUG - 2011-07-26 12:00:23 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-26 12:00:23 --> Language Class Initialized
DEBUG - 2011-07-26 12:00:23 --> Loader Class Initialized
DEBUG - 2011-07-26 12:00:23 --> Controller Class Initialized
DEBUG - 2011-07-26 12:00:23 --> Model Class Initialized
DEBUG - 2011-07-26 12:00:23 --> Model Class Initialized
DEBUG - 2011-07-26 12:00:23 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-26 12:00:23 --> Database Driver Class Initialized
DEBUG - 2011-07-26 12:00:24 --> Final output sent to browser
DEBUG - 2011-07-26 12:00:24 --> Total execution time: 0.7818
DEBUG - 2011-07-26 12:00:29 --> Config Class Initialized
DEBUG - 2011-07-26 12:00:29 --> Hooks Class Initialized
DEBUG - 2011-07-26 12:00:29 --> Utf8 Class Initialized
DEBUG - 2011-07-26 12:00:29 --> UTF-8 Support Enabled
DEBUG - 2011-07-26 12:00:29 --> URI Class Initialized
DEBUG - 2011-07-26 12:00:29 --> Router Class Initialized
ERROR - 2011-07-26 12:00:29 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-26 12:52:37 --> Config Class Initialized
DEBUG - 2011-07-26 12:52:37 --> Hooks Class Initialized
DEBUG - 2011-07-26 12:52:37 --> Utf8 Class Initialized
DEBUG - 2011-07-26 12:52:37 --> UTF-8 Support Enabled
DEBUG - 2011-07-26 12:52:37 --> URI Class Initialized
DEBUG - 2011-07-26 12:52:37 --> Router Class Initialized
DEBUG - 2011-07-26 12:52:37 --> Output Class Initialized
DEBUG - 2011-07-26 12:52:37 --> Input Class Initialized
DEBUG - 2011-07-26 12:52:37 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-26 12:52:37 --> Language Class Initialized
DEBUG - 2011-07-26 12:52:37 --> Loader Class Initialized
DEBUG - 2011-07-26 12:52:37 --> Controller Class Initialized
DEBUG - 2011-07-26 12:52:37 --> Model Class Initialized
DEBUG - 2011-07-26 12:52:37 --> Model Class Initialized
DEBUG - 2011-07-26 12:52:37 --> Model Class Initialized
DEBUG - 2011-07-26 12:52:37 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-26 12:52:38 --> Database Driver Class Initialized
DEBUG - 2011-07-26 12:52:39 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-26 12:52:39 --> Helper loaded: url_helper
DEBUG - 2011-07-26 12:52:39 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-26 12:52:39 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-26 12:52:39 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-26 12:52:39 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-26 12:52:39 --> Final output sent to browser
DEBUG - 2011-07-26 12:52:39 --> Total execution time: 1.7719
DEBUG - 2011-07-26 12:52:44 --> Config Class Initialized
DEBUG - 2011-07-26 12:52:44 --> Hooks Class Initialized
DEBUG - 2011-07-26 12:52:44 --> Utf8 Class Initialized
DEBUG - 2011-07-26 12:52:44 --> UTF-8 Support Enabled
DEBUG - 2011-07-26 12:52:44 --> URI Class Initialized
DEBUG - 2011-07-26 12:52:44 --> Router Class Initialized
ERROR - 2011-07-26 12:52:44 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-26 12:53:14 --> Config Class Initialized
DEBUG - 2011-07-26 12:53:14 --> Hooks Class Initialized
DEBUG - 2011-07-26 12:53:14 --> Utf8 Class Initialized
DEBUG - 2011-07-26 12:53:14 --> UTF-8 Support Enabled
DEBUG - 2011-07-26 12:53:14 --> URI Class Initialized
DEBUG - 2011-07-26 12:53:14 --> Router Class Initialized
DEBUG - 2011-07-26 12:53:14 --> Output Class Initialized
DEBUG - 2011-07-26 12:53:14 --> Input Class Initialized
DEBUG - 2011-07-26 12:53:14 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-26 12:53:14 --> Language Class Initialized
DEBUG - 2011-07-26 12:53:14 --> Loader Class Initialized
DEBUG - 2011-07-26 12:53:14 --> Controller Class Initialized
DEBUG - 2011-07-26 12:53:14 --> Model Class Initialized
DEBUG - 2011-07-26 12:53:14 --> Model Class Initialized
DEBUG - 2011-07-26 12:53:14 --> Model Class Initialized
DEBUG - 2011-07-26 12:53:14 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-26 12:53:14 --> Database Driver Class Initialized
DEBUG - 2011-07-26 12:53:15 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-26 12:53:15 --> Helper loaded: url_helper
DEBUG - 2011-07-26 12:53:15 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-26 12:53:15 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-26 12:53:15 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-26 12:53:15 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-26 12:53:15 --> Final output sent to browser
DEBUG - 2011-07-26 12:53:15 --> Total execution time: 1.5031
DEBUG - 2011-07-26 12:53:25 --> Config Class Initialized
DEBUG - 2011-07-26 12:53:25 --> Hooks Class Initialized
DEBUG - 2011-07-26 12:53:25 --> Utf8 Class Initialized
DEBUG - 2011-07-26 12:53:25 --> UTF-8 Support Enabled
DEBUG - 2011-07-26 12:53:25 --> URI Class Initialized
DEBUG - 2011-07-26 12:53:25 --> Router Class Initialized
DEBUG - 2011-07-26 12:53:25 --> Output Class Initialized
DEBUG - 2011-07-26 12:53:25 --> Input Class Initialized
DEBUG - 2011-07-26 12:53:25 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-26 12:53:25 --> Language Class Initialized
DEBUG - 2011-07-26 12:53:25 --> Loader Class Initialized
DEBUG - 2011-07-26 12:53:25 --> Controller Class Initialized
DEBUG - 2011-07-26 12:53:25 --> Model Class Initialized
DEBUG - 2011-07-26 12:53:25 --> Model Class Initialized
DEBUG - 2011-07-26 12:53:25 --> Model Class Initialized
DEBUG - 2011-07-26 12:53:25 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-26 12:53:25 --> Database Driver Class Initialized
DEBUG - 2011-07-26 12:53:26 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-26 12:53:26 --> Helper loaded: url_helper
DEBUG - 2011-07-26 12:53:26 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-26 12:53:26 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-26 12:53:26 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-26 12:53:26 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-26 12:53:26 --> Final output sent to browser
DEBUG - 2011-07-26 12:53:26 --> Total execution time: 0.2847
DEBUG - 2011-07-26 12:53:34 --> Config Class Initialized
DEBUG - 2011-07-26 12:53:34 --> Hooks Class Initialized
DEBUG - 2011-07-26 12:53:34 --> Utf8 Class Initialized
DEBUG - 2011-07-26 12:53:34 --> UTF-8 Support Enabled
DEBUG - 2011-07-26 12:53:34 --> URI Class Initialized
DEBUG - 2011-07-26 12:53:34 --> Router Class Initialized
DEBUG - 2011-07-26 12:53:34 --> Output Class Initialized
DEBUG - 2011-07-26 12:53:34 --> Input Class Initialized
DEBUG - 2011-07-26 12:53:34 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-26 12:53:34 --> Language Class Initialized
DEBUG - 2011-07-26 12:53:34 --> Loader Class Initialized
DEBUG - 2011-07-26 12:53:34 --> Controller Class Initialized
DEBUG - 2011-07-26 12:53:34 --> Model Class Initialized
DEBUG - 2011-07-26 12:53:34 --> Model Class Initialized
DEBUG - 2011-07-26 12:53:34 --> Model Class Initialized
DEBUG - 2011-07-26 12:53:34 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-26 12:53:34 --> Database Driver Class Initialized
DEBUG - 2011-07-26 12:53:34 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-26 12:53:34 --> Helper loaded: url_helper
DEBUG - 2011-07-26 12:53:34 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-26 12:53:34 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-26 12:53:34 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-26 12:53:34 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-26 12:53:34 --> Final output sent to browser
DEBUG - 2011-07-26 12:53:34 --> Total execution time: 0.2992
DEBUG - 2011-07-26 12:53:40 --> Config Class Initialized
DEBUG - 2011-07-26 12:53:40 --> Hooks Class Initialized
DEBUG - 2011-07-26 12:53:40 --> Utf8 Class Initialized
DEBUG - 2011-07-26 12:53:40 --> UTF-8 Support Enabled
DEBUG - 2011-07-26 12:53:40 --> URI Class Initialized
DEBUG - 2011-07-26 12:53:40 --> Router Class Initialized
DEBUG - 2011-07-26 12:53:40 --> Output Class Initialized
DEBUG - 2011-07-26 12:53:40 --> Input Class Initialized
DEBUG - 2011-07-26 12:53:40 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-26 12:53:40 --> Language Class Initialized
DEBUG - 2011-07-26 12:53:40 --> Loader Class Initialized
DEBUG - 2011-07-26 12:53:40 --> Controller Class Initialized
DEBUG - 2011-07-26 12:53:40 --> Model Class Initialized
DEBUG - 2011-07-26 12:53:40 --> Model Class Initialized
DEBUG - 2011-07-26 12:53:40 --> Model Class Initialized
DEBUG - 2011-07-26 12:53:40 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-26 12:53:40 --> Database Driver Class Initialized
DEBUG - 2011-07-26 12:53:41 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-26 12:53:41 --> Helper loaded: url_helper
DEBUG - 2011-07-26 12:53:41 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-26 12:53:41 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-26 12:53:41 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-26 12:53:41 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-26 12:53:41 --> Final output sent to browser
DEBUG - 2011-07-26 12:53:41 --> Total execution time: 0.8064
DEBUG - 2011-07-26 12:53:46 --> Config Class Initialized
DEBUG - 2011-07-26 12:53:46 --> Hooks Class Initialized
DEBUG - 2011-07-26 12:53:46 --> Utf8 Class Initialized
DEBUG - 2011-07-26 12:53:46 --> UTF-8 Support Enabled
DEBUG - 2011-07-26 12:53:46 --> URI Class Initialized
DEBUG - 2011-07-26 12:53:46 --> Router Class Initialized
DEBUG - 2011-07-26 12:53:46 --> Output Class Initialized
DEBUG - 2011-07-26 12:53:46 --> Input Class Initialized
DEBUG - 2011-07-26 12:53:46 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-26 12:53:46 --> Language Class Initialized
DEBUG - 2011-07-26 12:53:46 --> Loader Class Initialized
DEBUG - 2011-07-26 12:53:46 --> Controller Class Initialized
DEBUG - 2011-07-26 12:53:46 --> Model Class Initialized
DEBUG - 2011-07-26 12:53:46 --> Model Class Initialized
DEBUG - 2011-07-26 12:53:46 --> Model Class Initialized
DEBUG - 2011-07-26 12:53:46 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-26 12:53:46 --> Database Driver Class Initialized
DEBUG - 2011-07-26 12:53:46 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-26 12:53:46 --> Helper loaded: url_helper
DEBUG - 2011-07-26 12:53:46 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-26 12:53:46 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-26 12:53:46 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-26 12:53:46 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-26 12:53:46 --> Final output sent to browser
DEBUG - 2011-07-26 12:53:46 --> Total execution time: 0.2344
DEBUG - 2011-07-26 12:53:55 --> Config Class Initialized
DEBUG - 2011-07-26 12:53:55 --> Hooks Class Initialized
DEBUG - 2011-07-26 12:53:55 --> Utf8 Class Initialized
DEBUG - 2011-07-26 12:53:55 --> UTF-8 Support Enabled
DEBUG - 2011-07-26 12:53:55 --> URI Class Initialized
DEBUG - 2011-07-26 12:53:55 --> Router Class Initialized
DEBUG - 2011-07-26 12:53:55 --> Output Class Initialized
DEBUG - 2011-07-26 12:53:55 --> Input Class Initialized
DEBUG - 2011-07-26 12:53:55 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-26 12:53:55 --> Language Class Initialized
DEBUG - 2011-07-26 12:53:55 --> Loader Class Initialized
DEBUG - 2011-07-26 12:53:55 --> Controller Class Initialized
DEBUG - 2011-07-26 12:53:55 --> Model Class Initialized
DEBUG - 2011-07-26 12:53:55 --> Model Class Initialized
DEBUG - 2011-07-26 12:53:55 --> Model Class Initialized
DEBUG - 2011-07-26 12:53:55 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-26 12:53:55 --> Database Driver Class Initialized
DEBUG - 2011-07-26 12:53:55 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-26 12:53:55 --> Helper loaded: url_helper
DEBUG - 2011-07-26 12:53:55 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-26 12:53:55 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-26 12:53:55 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-26 12:53:55 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-26 12:53:55 --> Final output sent to browser
DEBUG - 2011-07-26 12:53:55 --> Total execution time: 0.4591
DEBUG - 2011-07-26 12:54:00 --> Config Class Initialized
DEBUG - 2011-07-26 12:54:00 --> Hooks Class Initialized
DEBUG - 2011-07-26 12:54:00 --> Utf8 Class Initialized
DEBUG - 2011-07-26 12:54:00 --> UTF-8 Support Enabled
DEBUG - 2011-07-26 12:54:00 --> URI Class Initialized
DEBUG - 2011-07-26 12:54:00 --> Router Class Initialized
DEBUG - 2011-07-26 12:54:00 --> Output Class Initialized
DEBUG - 2011-07-26 12:54:00 --> Input Class Initialized
DEBUG - 2011-07-26 12:54:00 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-26 12:54:00 --> Language Class Initialized
DEBUG - 2011-07-26 12:54:00 --> Loader Class Initialized
DEBUG - 2011-07-26 12:54:00 --> Controller Class Initialized
DEBUG - 2011-07-26 12:54:00 --> Model Class Initialized
DEBUG - 2011-07-26 12:54:00 --> Model Class Initialized
DEBUG - 2011-07-26 12:54:00 --> Model Class Initialized
DEBUG - 2011-07-26 12:54:00 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-26 12:54:00 --> Database Driver Class Initialized
DEBUG - 2011-07-26 12:54:00 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-26 12:54:00 --> Helper loaded: url_helper
DEBUG - 2011-07-26 12:54:00 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-26 12:54:00 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-26 12:54:00 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-26 12:54:00 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-26 12:54:00 --> Final output sent to browser
DEBUG - 2011-07-26 12:54:00 --> Total execution time: 0.0814
DEBUG - 2011-07-26 12:54:05 --> Config Class Initialized
DEBUG - 2011-07-26 12:54:05 --> Hooks Class Initialized
DEBUG - 2011-07-26 12:54:05 --> Utf8 Class Initialized
DEBUG - 2011-07-26 12:54:05 --> UTF-8 Support Enabled
DEBUG - 2011-07-26 12:54:05 --> URI Class Initialized
DEBUG - 2011-07-26 12:54:05 --> Router Class Initialized
DEBUG - 2011-07-26 12:54:05 --> Output Class Initialized
DEBUG - 2011-07-26 12:54:05 --> Input Class Initialized
DEBUG - 2011-07-26 12:54:05 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-26 12:54:05 --> Language Class Initialized
DEBUG - 2011-07-26 12:54:05 --> Loader Class Initialized
DEBUG - 2011-07-26 12:54:05 --> Controller Class Initialized
DEBUG - 2011-07-26 12:54:05 --> Model Class Initialized
DEBUG - 2011-07-26 12:54:05 --> Model Class Initialized
DEBUG - 2011-07-26 12:54:05 --> Model Class Initialized
DEBUG - 2011-07-26 12:54:05 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-26 12:54:05 --> Database Driver Class Initialized
DEBUG - 2011-07-26 12:54:05 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-26 12:54:05 --> Helper loaded: url_helper
DEBUG - 2011-07-26 12:54:05 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-26 12:54:05 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-26 12:54:05 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-26 12:54:05 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-26 12:54:05 --> Final output sent to browser
DEBUG - 2011-07-26 12:54:05 --> Total execution time: 0.0452
DEBUG - 2011-07-26 14:35:05 --> Config Class Initialized
DEBUG - 2011-07-26 14:35:05 --> Hooks Class Initialized
DEBUG - 2011-07-26 14:35:05 --> Utf8 Class Initialized
DEBUG - 2011-07-26 14:35:05 --> UTF-8 Support Enabled
DEBUG - 2011-07-26 14:35:05 --> URI Class Initialized
DEBUG - 2011-07-26 14:35:05 --> Router Class Initialized
DEBUG - 2011-07-26 14:35:05 --> Output Class Initialized
DEBUG - 2011-07-26 14:35:05 --> Input Class Initialized
DEBUG - 2011-07-26 14:35:05 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-26 14:35:05 --> Language Class Initialized
DEBUG - 2011-07-26 14:35:05 --> Loader Class Initialized
DEBUG - 2011-07-26 14:35:05 --> Controller Class Initialized
ERROR - 2011-07-26 14:35:05 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-26 14:35:05 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-26 14:35:05 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-26 14:35:05 --> Model Class Initialized
DEBUG - 2011-07-26 14:35:05 --> Config Class Initialized
DEBUG - 2011-07-26 14:35:05 --> Hooks Class Initialized
DEBUG - 2011-07-26 14:35:05 --> Utf8 Class Initialized
DEBUG - 2011-07-26 14:35:05 --> UTF-8 Support Enabled
DEBUG - 2011-07-26 14:35:05 --> URI Class Initialized
DEBUG - 2011-07-26 14:35:05 --> Model Class Initialized
DEBUG - 2011-07-26 14:35:05 --> Router Class Initialized
DEBUG - 2011-07-26 14:35:05 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-26 14:35:05 --> Output Class Initialized
DEBUG - 2011-07-26 14:35:05 --> Input Class Initialized
DEBUG - 2011-07-26 14:35:05 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-26 14:35:05 --> Language Class Initialized
DEBUG - 2011-07-26 14:35:05 --> Loader Class Initialized
DEBUG - 2011-07-26 14:35:05 --> Controller Class Initialized
DEBUG - 2011-07-26 14:35:05 --> Model Class Initialized
DEBUG - 2011-07-26 14:35:05 --> Model Class Initialized
DEBUG - 2011-07-26 14:35:05 --> Model Class Initialized
DEBUG - 2011-07-26 14:35:05 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-26 14:35:05 --> Database Driver Class Initialized
DEBUG - 2011-07-26 14:35:05 --> Database Driver Class Initialized
DEBUG - 2011-07-26 14:35:05 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-26 14:35:05 --> Helper loaded: url_helper
DEBUG - 2011-07-26 14:35:05 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-26 14:35:05 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-26 14:35:05 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-26 14:35:05 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-26 14:35:05 --> Final output sent to browser
DEBUG - 2011-07-26 14:35:05 --> Total execution time: 0.3720
DEBUG - 2011-07-26 14:35:06 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-26 14:35:06 --> Helper loaded: url_helper
DEBUG - 2011-07-26 14:35:06 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-26 14:35:06 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-26 14:35:06 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-26 14:35:06 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-26 14:35:06 --> Final output sent to browser
DEBUG - 2011-07-26 14:35:06 --> Total execution time: 0.6757
DEBUG - 2011-07-26 14:35:08 --> Config Class Initialized
DEBUG - 2011-07-26 14:35:08 --> Hooks Class Initialized
DEBUG - 2011-07-26 14:35:08 --> Utf8 Class Initialized
DEBUG - 2011-07-26 14:35:08 --> UTF-8 Support Enabled
DEBUG - 2011-07-26 14:35:08 --> URI Class Initialized
DEBUG - 2011-07-26 14:35:08 --> Router Class Initialized
DEBUG - 2011-07-26 14:35:08 --> Output Class Initialized
DEBUG - 2011-07-26 14:35:08 --> Input Class Initialized
DEBUG - 2011-07-26 14:35:08 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-26 14:35:08 --> Language Class Initialized
DEBUG - 2011-07-26 14:35:08 --> Loader Class Initialized
DEBUG - 2011-07-26 14:35:08 --> Controller Class Initialized
DEBUG - 2011-07-26 14:35:08 --> Model Class Initialized
DEBUG - 2011-07-26 14:35:08 --> Model Class Initialized
DEBUG - 2011-07-26 14:35:08 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-26 14:35:08 --> Database Driver Class Initialized
DEBUG - 2011-07-26 14:35:08 --> Final output sent to browser
DEBUG - 2011-07-26 14:35:08 --> Total execution time: 0.8941
DEBUG - 2011-07-26 14:36:17 --> Config Class Initialized
DEBUG - 2011-07-26 14:36:17 --> Hooks Class Initialized
DEBUG - 2011-07-26 14:36:17 --> Utf8 Class Initialized
DEBUG - 2011-07-26 14:36:17 --> UTF-8 Support Enabled
DEBUG - 2011-07-26 14:36:17 --> URI Class Initialized
DEBUG - 2011-07-26 14:36:17 --> Router Class Initialized
DEBUG - 2011-07-26 14:36:17 --> Output Class Initialized
DEBUG - 2011-07-26 14:36:17 --> Input Class Initialized
DEBUG - 2011-07-26 14:36:17 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-26 14:36:17 --> Language Class Initialized
DEBUG - 2011-07-26 14:36:17 --> Loader Class Initialized
DEBUG - 2011-07-26 14:36:17 --> Controller Class Initialized
DEBUG - 2011-07-26 14:36:17 --> Model Class Initialized
DEBUG - 2011-07-26 14:36:17 --> Model Class Initialized
DEBUG - 2011-07-26 14:36:17 --> Model Class Initialized
DEBUG - 2011-07-26 14:36:17 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-26 14:36:17 --> Database Driver Class Initialized
DEBUG - 2011-07-26 14:36:17 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-26 14:36:17 --> Helper loaded: url_helper
DEBUG - 2011-07-26 14:36:17 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-26 14:36:17 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-26 14:36:17 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-26 14:36:17 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-26 14:36:17 --> Final output sent to browser
DEBUG - 2011-07-26 14:36:17 --> Total execution time: 0.4798
DEBUG - 2011-07-26 14:36:51 --> Config Class Initialized
DEBUG - 2011-07-26 14:36:51 --> Hooks Class Initialized
DEBUG - 2011-07-26 14:36:51 --> Utf8 Class Initialized
DEBUG - 2011-07-26 14:36:51 --> UTF-8 Support Enabled
DEBUG - 2011-07-26 14:36:51 --> URI Class Initialized
DEBUG - 2011-07-26 14:36:51 --> Router Class Initialized
DEBUG - 2011-07-26 14:36:51 --> Output Class Initialized
DEBUG - 2011-07-26 14:36:51 --> Input Class Initialized
DEBUG - 2011-07-26 14:36:51 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-26 14:36:51 --> Language Class Initialized
DEBUG - 2011-07-26 14:36:51 --> Loader Class Initialized
DEBUG - 2011-07-26 14:36:51 --> Controller Class Initialized
DEBUG - 2011-07-26 14:36:51 --> Model Class Initialized
DEBUG - 2011-07-26 14:36:51 --> Model Class Initialized
DEBUG - 2011-07-26 14:36:51 --> Model Class Initialized
DEBUG - 2011-07-26 14:36:51 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-26 14:36:51 --> Database Driver Class Initialized
DEBUG - 2011-07-26 14:36:51 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-26 14:36:52 --> Helper loaded: url_helper
DEBUG - 2011-07-26 14:36:52 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-26 14:36:52 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-26 14:36:52 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-26 14:36:52 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-26 14:36:52 --> Final output sent to browser
DEBUG - 2011-07-26 14:36:52 --> Total execution time: 0.5994
DEBUG - 2011-07-26 14:37:04 --> Config Class Initialized
DEBUG - 2011-07-26 14:37:04 --> Hooks Class Initialized
DEBUG - 2011-07-26 14:37:04 --> Utf8 Class Initialized
DEBUG - 2011-07-26 14:37:04 --> UTF-8 Support Enabled
DEBUG - 2011-07-26 14:37:04 --> URI Class Initialized
DEBUG - 2011-07-26 14:37:04 --> Router Class Initialized
DEBUG - 2011-07-26 14:37:04 --> Output Class Initialized
DEBUG - 2011-07-26 14:37:04 --> Input Class Initialized
DEBUG - 2011-07-26 14:37:04 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-26 14:37:04 --> Language Class Initialized
DEBUG - 2011-07-26 14:37:04 --> Loader Class Initialized
DEBUG - 2011-07-26 14:37:04 --> Controller Class Initialized
DEBUG - 2011-07-26 14:37:04 --> Model Class Initialized
DEBUG - 2011-07-26 14:37:04 --> Model Class Initialized
DEBUG - 2011-07-26 14:37:04 --> Model Class Initialized
DEBUG - 2011-07-26 14:37:04 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-26 14:37:04 --> Database Driver Class Initialized
DEBUG - 2011-07-26 14:37:04 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-26 14:37:04 --> Helper loaded: url_helper
DEBUG - 2011-07-26 14:37:04 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-26 14:37:04 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-26 14:37:04 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-26 14:37:04 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-26 14:37:04 --> Final output sent to browser
DEBUG - 2011-07-26 14:37:04 --> Total execution time: 0.2248
DEBUG - 2011-07-26 14:37:16 --> Config Class Initialized
DEBUG - 2011-07-26 14:37:16 --> Hooks Class Initialized
DEBUG - 2011-07-26 14:37:16 --> Utf8 Class Initialized
DEBUG - 2011-07-26 14:37:16 --> UTF-8 Support Enabled
DEBUG - 2011-07-26 14:37:16 --> URI Class Initialized
DEBUG - 2011-07-26 14:37:16 --> Router Class Initialized
DEBUG - 2011-07-26 14:37:16 --> Output Class Initialized
DEBUG - 2011-07-26 14:37:16 --> Input Class Initialized
DEBUG - 2011-07-26 14:37:16 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-26 14:37:16 --> Language Class Initialized
DEBUG - 2011-07-26 14:37:16 --> Loader Class Initialized
DEBUG - 2011-07-26 14:37:16 --> Controller Class Initialized
DEBUG - 2011-07-26 14:37:16 --> Model Class Initialized
DEBUG - 2011-07-26 14:37:16 --> Model Class Initialized
DEBUG - 2011-07-26 14:37:16 --> Model Class Initialized
DEBUG - 2011-07-26 14:37:16 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-26 14:37:16 --> Database Driver Class Initialized
DEBUG - 2011-07-26 14:37:16 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-26 14:37:16 --> Helper loaded: url_helper
DEBUG - 2011-07-26 14:37:16 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-26 14:37:16 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-26 14:37:16 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-26 14:37:16 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-26 14:37:16 --> Final output sent to browser
DEBUG - 2011-07-26 14:37:16 --> Total execution time: 0.0504
DEBUG - 2011-07-26 14:37:20 --> Config Class Initialized
DEBUG - 2011-07-26 14:37:20 --> Hooks Class Initialized
DEBUG - 2011-07-26 14:37:20 --> Utf8 Class Initialized
DEBUG - 2011-07-26 14:37:20 --> UTF-8 Support Enabled
DEBUG - 2011-07-26 14:37:20 --> URI Class Initialized
DEBUG - 2011-07-26 14:37:20 --> Router Class Initialized
DEBUG - 2011-07-26 14:37:20 --> Output Class Initialized
DEBUG - 2011-07-26 14:37:20 --> Input Class Initialized
DEBUG - 2011-07-26 14:37:20 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-26 14:37:20 --> Language Class Initialized
DEBUG - 2011-07-26 14:37:20 --> Loader Class Initialized
DEBUG - 2011-07-26 14:37:20 --> Controller Class Initialized
DEBUG - 2011-07-26 14:37:20 --> Model Class Initialized
DEBUG - 2011-07-26 14:37:20 --> Model Class Initialized
DEBUG - 2011-07-26 14:37:20 --> Model Class Initialized
DEBUG - 2011-07-26 14:37:21 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-26 14:37:21 --> Database Driver Class Initialized
DEBUG - 2011-07-26 14:37:21 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-26 14:37:21 --> Helper loaded: url_helper
DEBUG - 2011-07-26 14:37:21 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-26 14:37:21 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-26 14:37:21 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-26 14:37:21 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-26 14:37:21 --> Final output sent to browser
DEBUG - 2011-07-26 14:37:21 --> Total execution time: 0.0467
DEBUG - 2011-07-26 14:37:23 --> Config Class Initialized
DEBUG - 2011-07-26 14:37:23 --> Hooks Class Initialized
DEBUG - 2011-07-26 14:37:23 --> Utf8 Class Initialized
DEBUG - 2011-07-26 14:37:23 --> UTF-8 Support Enabled
DEBUG - 2011-07-26 14:37:23 --> URI Class Initialized
DEBUG - 2011-07-26 14:37:23 --> Router Class Initialized
DEBUG - 2011-07-26 14:37:23 --> Output Class Initialized
DEBUG - 2011-07-26 14:37:23 --> Input Class Initialized
DEBUG - 2011-07-26 14:37:23 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-26 14:37:23 --> Language Class Initialized
DEBUG - 2011-07-26 14:37:23 --> Loader Class Initialized
DEBUG - 2011-07-26 14:37:23 --> Controller Class Initialized
DEBUG - 2011-07-26 14:37:23 --> Model Class Initialized
DEBUG - 2011-07-26 14:37:23 --> Model Class Initialized
DEBUG - 2011-07-26 14:37:23 --> Model Class Initialized
DEBUG - 2011-07-26 14:37:23 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-26 14:37:23 --> Database Driver Class Initialized
DEBUG - 2011-07-26 14:37:23 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-26 14:37:23 --> Helper loaded: url_helper
DEBUG - 2011-07-26 14:37:23 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-26 14:37:23 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-26 14:37:23 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-26 14:37:23 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-26 14:37:23 --> Final output sent to browser
DEBUG - 2011-07-26 14:37:23 --> Total execution time: 0.2130
DEBUG - 2011-07-26 14:37:45 --> Config Class Initialized
DEBUG - 2011-07-26 14:37:45 --> Hooks Class Initialized
DEBUG - 2011-07-26 14:37:45 --> Utf8 Class Initialized
DEBUG - 2011-07-26 14:37:45 --> UTF-8 Support Enabled
DEBUG - 2011-07-26 14:37:45 --> URI Class Initialized
DEBUG - 2011-07-26 14:37:45 --> Router Class Initialized
DEBUG - 2011-07-26 14:37:45 --> Output Class Initialized
DEBUG - 2011-07-26 14:37:45 --> Input Class Initialized
DEBUG - 2011-07-26 14:37:45 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-26 14:37:45 --> Language Class Initialized
DEBUG - 2011-07-26 14:37:45 --> Loader Class Initialized
DEBUG - 2011-07-26 14:37:45 --> Controller Class Initialized
DEBUG - 2011-07-26 14:37:45 --> Model Class Initialized
DEBUG - 2011-07-26 14:37:45 --> Model Class Initialized
DEBUG - 2011-07-26 14:37:45 --> Model Class Initialized
DEBUG - 2011-07-26 14:37:45 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-26 14:37:45 --> Database Driver Class Initialized
DEBUG - 2011-07-26 14:37:45 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-26 14:37:45 --> Helper loaded: url_helper
DEBUG - 2011-07-26 14:37:45 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-26 14:37:45 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-26 14:37:45 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-26 14:37:45 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-26 14:37:45 --> Final output sent to browser
DEBUG - 2011-07-26 14:37:45 --> Total execution time: 0.4163
DEBUG - 2011-07-26 14:37:47 --> Config Class Initialized
DEBUG - 2011-07-26 14:37:47 --> Hooks Class Initialized
DEBUG - 2011-07-26 14:37:47 --> Utf8 Class Initialized
DEBUG - 2011-07-26 14:37:47 --> UTF-8 Support Enabled
DEBUG - 2011-07-26 14:37:47 --> URI Class Initialized
DEBUG - 2011-07-26 14:37:47 --> Router Class Initialized
DEBUG - 2011-07-26 14:37:47 --> Output Class Initialized
DEBUG - 2011-07-26 14:37:47 --> Input Class Initialized
DEBUG - 2011-07-26 14:37:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-26 14:37:47 --> Language Class Initialized
DEBUG - 2011-07-26 14:37:47 --> Loader Class Initialized
DEBUG - 2011-07-26 14:37:47 --> Controller Class Initialized
DEBUG - 2011-07-26 14:37:47 --> Model Class Initialized
DEBUG - 2011-07-26 14:37:47 --> Model Class Initialized
DEBUG - 2011-07-26 14:37:47 --> Model Class Initialized
DEBUG - 2011-07-26 14:37:47 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-26 14:37:47 --> Database Driver Class Initialized
DEBUG - 2011-07-26 14:37:47 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-26 14:37:47 --> Helper loaded: url_helper
DEBUG - 2011-07-26 14:37:47 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-26 14:37:47 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-26 14:37:47 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-26 14:37:47 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-26 14:37:47 --> Final output sent to browser
DEBUG - 2011-07-26 14:37:47 --> Total execution time: 0.0544
DEBUG - 2011-07-26 14:37:55 --> Config Class Initialized
DEBUG - 2011-07-26 14:37:55 --> Hooks Class Initialized
DEBUG - 2011-07-26 14:37:55 --> Utf8 Class Initialized
DEBUG - 2011-07-26 14:37:55 --> UTF-8 Support Enabled
DEBUG - 2011-07-26 14:37:55 --> URI Class Initialized
DEBUG - 2011-07-26 14:37:55 --> Router Class Initialized
DEBUG - 2011-07-26 14:37:55 --> Output Class Initialized
DEBUG - 2011-07-26 14:37:55 --> Input Class Initialized
DEBUG - 2011-07-26 14:37:55 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-26 14:37:55 --> Language Class Initialized
DEBUG - 2011-07-26 14:37:55 --> Loader Class Initialized
DEBUG - 2011-07-26 14:37:55 --> Controller Class Initialized
DEBUG - 2011-07-26 14:37:55 --> Model Class Initialized
DEBUG - 2011-07-26 14:37:55 --> Model Class Initialized
DEBUG - 2011-07-26 14:37:55 --> Model Class Initialized
DEBUG - 2011-07-26 14:37:55 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-26 14:37:55 --> Database Driver Class Initialized
DEBUG - 2011-07-26 14:37:56 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-26 14:37:56 --> Helper loaded: url_helper
DEBUG - 2011-07-26 14:37:56 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-26 14:37:56 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-26 14:37:56 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-26 14:37:56 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-26 14:37:56 --> Final output sent to browser
DEBUG - 2011-07-26 14:37:56 --> Total execution time: 0.7649
DEBUG - 2011-07-26 14:38:16 --> Config Class Initialized
DEBUG - 2011-07-26 14:38:16 --> Hooks Class Initialized
DEBUG - 2011-07-26 14:38:16 --> Utf8 Class Initialized
DEBUG - 2011-07-26 14:38:16 --> UTF-8 Support Enabled
DEBUG - 2011-07-26 14:38:16 --> URI Class Initialized
DEBUG - 2011-07-26 14:38:16 --> Router Class Initialized
DEBUG - 2011-07-26 14:38:16 --> Output Class Initialized
DEBUG - 2011-07-26 14:38:16 --> Input Class Initialized
DEBUG - 2011-07-26 14:38:16 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-26 14:38:16 --> Language Class Initialized
DEBUG - 2011-07-26 14:38:16 --> Loader Class Initialized
DEBUG - 2011-07-26 14:38:16 --> Controller Class Initialized
DEBUG - 2011-07-26 14:38:16 --> Model Class Initialized
DEBUG - 2011-07-26 14:38:16 --> Model Class Initialized
DEBUG - 2011-07-26 14:38:16 --> Model Class Initialized
DEBUG - 2011-07-26 14:38:16 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-26 14:38:16 --> Database Driver Class Initialized
DEBUG - 2011-07-26 14:38:17 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-26 14:38:17 --> Helper loaded: url_helper
DEBUG - 2011-07-26 14:38:17 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-26 14:38:17 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-26 14:38:17 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-26 14:38:17 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-26 14:38:17 --> Final output sent to browser
DEBUG - 2011-07-26 14:38:17 --> Total execution time: 0.8130
DEBUG - 2011-07-26 14:38:32 --> Config Class Initialized
DEBUG - 2011-07-26 14:38:32 --> Hooks Class Initialized
DEBUG - 2011-07-26 14:38:32 --> Utf8 Class Initialized
DEBUG - 2011-07-26 14:38:32 --> UTF-8 Support Enabled
DEBUG - 2011-07-26 14:38:32 --> URI Class Initialized
DEBUG - 2011-07-26 14:38:32 --> Router Class Initialized
DEBUG - 2011-07-26 14:38:32 --> Output Class Initialized
DEBUG - 2011-07-26 14:38:32 --> Input Class Initialized
DEBUG - 2011-07-26 14:38:32 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-26 14:38:32 --> Language Class Initialized
DEBUG - 2011-07-26 14:38:32 --> Loader Class Initialized
DEBUG - 2011-07-26 14:38:32 --> Controller Class Initialized
DEBUG - 2011-07-26 14:38:32 --> Model Class Initialized
DEBUG - 2011-07-26 14:38:32 --> Model Class Initialized
DEBUG - 2011-07-26 14:38:32 --> Model Class Initialized
DEBUG - 2011-07-26 14:38:32 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-26 14:38:32 --> Database Driver Class Initialized
DEBUG - 2011-07-26 14:38:33 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-26 14:38:33 --> Helper loaded: url_helper
DEBUG - 2011-07-26 14:38:33 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-26 14:38:33 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-26 14:38:33 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-26 14:38:33 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-26 14:38:33 --> Final output sent to browser
DEBUG - 2011-07-26 14:38:33 --> Total execution time: 1.2152
DEBUG - 2011-07-26 14:38:37 --> Config Class Initialized
DEBUG - 2011-07-26 14:38:37 --> Hooks Class Initialized
DEBUG - 2011-07-26 14:38:37 --> Utf8 Class Initialized
DEBUG - 2011-07-26 14:38:37 --> UTF-8 Support Enabled
DEBUG - 2011-07-26 14:38:37 --> URI Class Initialized
DEBUG - 2011-07-26 14:38:37 --> Router Class Initialized
DEBUG - 2011-07-26 14:38:37 --> Output Class Initialized
DEBUG - 2011-07-26 14:38:37 --> Input Class Initialized
DEBUG - 2011-07-26 14:38:37 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-26 14:38:37 --> Language Class Initialized
DEBUG - 2011-07-26 14:38:37 --> Loader Class Initialized
DEBUG - 2011-07-26 14:38:37 --> Controller Class Initialized
DEBUG - 2011-07-26 14:38:37 --> Model Class Initialized
DEBUG - 2011-07-26 14:38:37 --> Model Class Initialized
DEBUG - 2011-07-26 14:38:37 --> Model Class Initialized
DEBUG - 2011-07-26 14:38:37 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-26 14:38:37 --> Database Driver Class Initialized
DEBUG - 2011-07-26 14:38:37 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-26 14:38:37 --> Helper loaded: url_helper
DEBUG - 2011-07-26 14:38:37 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-26 14:38:37 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-26 14:38:37 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-26 14:38:37 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-26 14:38:37 --> Final output sent to browser
DEBUG - 2011-07-26 14:38:37 --> Total execution time: 0.2494
DEBUG - 2011-07-26 14:38:42 --> Config Class Initialized
DEBUG - 2011-07-26 14:38:42 --> Hooks Class Initialized
DEBUG - 2011-07-26 14:38:42 --> Utf8 Class Initialized
DEBUG - 2011-07-26 14:38:42 --> UTF-8 Support Enabled
DEBUG - 2011-07-26 14:38:42 --> URI Class Initialized
DEBUG - 2011-07-26 14:38:42 --> Router Class Initialized
DEBUG - 2011-07-26 14:38:42 --> Output Class Initialized
DEBUG - 2011-07-26 14:38:42 --> Input Class Initialized
DEBUG - 2011-07-26 14:38:42 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-26 14:38:42 --> Language Class Initialized
DEBUG - 2011-07-26 14:38:42 --> Loader Class Initialized
DEBUG - 2011-07-26 14:38:42 --> Controller Class Initialized
DEBUG - 2011-07-26 14:38:42 --> Model Class Initialized
DEBUG - 2011-07-26 14:38:42 --> Model Class Initialized
DEBUG - 2011-07-26 14:38:42 --> Model Class Initialized
DEBUG - 2011-07-26 14:38:42 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-26 14:38:42 --> Database Driver Class Initialized
DEBUG - 2011-07-26 14:38:43 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-26 14:38:43 --> Helper loaded: url_helper
DEBUG - 2011-07-26 14:38:43 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-26 14:38:43 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-26 14:38:43 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-26 14:38:43 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-26 14:38:43 --> Final output sent to browser
DEBUG - 2011-07-26 14:38:43 --> Total execution time: 0.8696
DEBUG - 2011-07-26 15:10:39 --> Config Class Initialized
DEBUG - 2011-07-26 15:10:39 --> Hooks Class Initialized
DEBUG - 2011-07-26 15:10:39 --> Utf8 Class Initialized
DEBUG - 2011-07-26 15:10:39 --> UTF-8 Support Enabled
DEBUG - 2011-07-26 15:10:39 --> URI Class Initialized
DEBUG - 2011-07-26 15:10:39 --> Router Class Initialized
DEBUG - 2011-07-26 15:10:39 --> Output Class Initialized
DEBUG - 2011-07-26 15:10:39 --> Input Class Initialized
DEBUG - 2011-07-26 15:10:39 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-26 15:10:39 --> Language Class Initialized
DEBUG - 2011-07-26 15:10:39 --> Loader Class Initialized
DEBUG - 2011-07-26 15:10:39 --> Controller Class Initialized
ERROR - 2011-07-26 15:10:39 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-26 15:10:39 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-26 15:10:39 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-26 15:10:39 --> Model Class Initialized
DEBUG - 2011-07-26 15:10:39 --> Model Class Initialized
DEBUG - 2011-07-26 15:10:39 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-26 15:10:39 --> Database Driver Class Initialized
DEBUG - 2011-07-26 15:10:39 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-26 15:10:39 --> Helper loaded: url_helper
DEBUG - 2011-07-26 15:10:39 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-26 15:10:39 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-26 15:10:39 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-26 15:10:39 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-26 15:10:39 --> Final output sent to browser
DEBUG - 2011-07-26 15:10:39 --> Total execution time: 0.0903
DEBUG - 2011-07-26 15:10:41 --> Config Class Initialized
DEBUG - 2011-07-26 15:10:41 --> Hooks Class Initialized
DEBUG - 2011-07-26 15:10:41 --> Utf8 Class Initialized
DEBUG - 2011-07-26 15:10:41 --> UTF-8 Support Enabled
DEBUG - 2011-07-26 15:10:41 --> URI Class Initialized
DEBUG - 2011-07-26 15:10:41 --> Router Class Initialized
DEBUG - 2011-07-26 15:10:41 --> Output Class Initialized
DEBUG - 2011-07-26 15:10:41 --> Input Class Initialized
DEBUG - 2011-07-26 15:10:41 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-26 15:10:41 --> Language Class Initialized
DEBUG - 2011-07-26 15:10:41 --> Loader Class Initialized
DEBUG - 2011-07-26 15:10:41 --> Controller Class Initialized
DEBUG - 2011-07-26 15:10:41 --> Model Class Initialized
DEBUG - 2011-07-26 15:10:41 --> Model Class Initialized
DEBUG - 2011-07-26 15:10:41 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-26 15:10:41 --> Database Driver Class Initialized
DEBUG - 2011-07-26 15:10:42 --> Final output sent to browser
DEBUG - 2011-07-26 15:10:42 --> Total execution time: 0.9119
DEBUG - 2011-07-26 15:10:45 --> Config Class Initialized
DEBUG - 2011-07-26 15:10:45 --> Hooks Class Initialized
DEBUG - 2011-07-26 15:10:45 --> Utf8 Class Initialized
DEBUG - 2011-07-26 15:10:45 --> UTF-8 Support Enabled
DEBUG - 2011-07-26 15:10:45 --> URI Class Initialized
DEBUG - 2011-07-26 15:10:45 --> Router Class Initialized
ERROR - 2011-07-26 15:10:45 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-26 15:11:08 --> Config Class Initialized
DEBUG - 2011-07-26 15:11:08 --> Hooks Class Initialized
DEBUG - 2011-07-26 15:11:08 --> Utf8 Class Initialized
DEBUG - 2011-07-26 15:11:08 --> UTF-8 Support Enabled
DEBUG - 2011-07-26 15:11:08 --> URI Class Initialized
DEBUG - 2011-07-26 15:11:08 --> Router Class Initialized
DEBUG - 2011-07-26 15:11:08 --> Output Class Initialized
DEBUG - 2011-07-26 15:11:08 --> Input Class Initialized
DEBUG - 2011-07-26 15:11:08 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-26 15:11:08 --> Language Class Initialized
DEBUG - 2011-07-26 15:11:08 --> Loader Class Initialized
DEBUG - 2011-07-26 15:11:08 --> Controller Class Initialized
DEBUG - 2011-07-26 15:11:08 --> Model Class Initialized
DEBUG - 2011-07-26 15:11:08 --> Model Class Initialized
DEBUG - 2011-07-26 15:11:08 --> Model Class Initialized
DEBUG - 2011-07-26 15:11:08 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-26 15:11:08 --> Database Driver Class Initialized
DEBUG - 2011-07-26 15:11:08 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-26 15:11:08 --> Helper loaded: url_helper
DEBUG - 2011-07-26 15:11:08 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-26 15:11:08 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-26 15:11:08 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-26 15:11:08 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-26 15:11:08 --> Final output sent to browser
DEBUG - 2011-07-26 15:11:08 --> Total execution time: 0.2094
DEBUG - 2011-07-26 15:11:11 --> Config Class Initialized
DEBUG - 2011-07-26 15:11:11 --> Hooks Class Initialized
DEBUG - 2011-07-26 15:11:11 --> Utf8 Class Initialized
DEBUG - 2011-07-26 15:11:11 --> UTF-8 Support Enabled
DEBUG - 2011-07-26 15:11:11 --> URI Class Initialized
DEBUG - 2011-07-26 15:11:11 --> Router Class Initialized
ERROR - 2011-07-26 15:11:11 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-26 16:07:10 --> Config Class Initialized
DEBUG - 2011-07-26 16:07:10 --> Hooks Class Initialized
DEBUG - 2011-07-26 16:07:10 --> Utf8 Class Initialized
DEBUG - 2011-07-26 16:07:10 --> UTF-8 Support Enabled
DEBUG - 2011-07-26 16:07:10 --> URI Class Initialized
DEBUG - 2011-07-26 16:07:10 --> Router Class Initialized
DEBUG - 2011-07-26 16:07:10 --> Output Class Initialized
DEBUG - 2011-07-26 16:07:10 --> Input Class Initialized
DEBUG - 2011-07-26 16:07:10 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-26 16:07:10 --> Language Class Initialized
DEBUG - 2011-07-26 16:07:10 --> Loader Class Initialized
DEBUG - 2011-07-26 16:07:10 --> Controller Class Initialized
ERROR - 2011-07-26 16:07:10 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-26 16:07:10 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-26 16:07:10 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-26 16:07:10 --> Model Class Initialized
DEBUG - 2011-07-26 16:07:10 --> Model Class Initialized
DEBUG - 2011-07-26 16:07:10 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-26 16:07:10 --> Database Driver Class Initialized
DEBUG - 2011-07-26 16:07:10 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-26 16:07:10 --> Helper loaded: url_helper
DEBUG - 2011-07-26 16:07:10 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-26 16:07:10 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-26 16:07:10 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-26 16:07:10 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-26 16:07:10 --> Final output sent to browser
DEBUG - 2011-07-26 16:07:10 --> Total execution time: 0.0305
DEBUG - 2011-07-26 16:07:10 --> Config Class Initialized
DEBUG - 2011-07-26 16:07:10 --> Hooks Class Initialized
DEBUG - 2011-07-26 16:07:10 --> Utf8 Class Initialized
DEBUG - 2011-07-26 16:07:10 --> UTF-8 Support Enabled
DEBUG - 2011-07-26 16:07:10 --> URI Class Initialized
DEBUG - 2011-07-26 16:07:10 --> Router Class Initialized
DEBUG - 2011-07-26 16:07:10 --> Output Class Initialized
DEBUG - 2011-07-26 16:07:10 --> Input Class Initialized
DEBUG - 2011-07-26 16:07:10 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-26 16:07:10 --> Language Class Initialized
DEBUG - 2011-07-26 16:07:10 --> Loader Class Initialized
DEBUG - 2011-07-26 16:07:10 --> Controller Class Initialized
DEBUG - 2011-07-26 16:07:10 --> Model Class Initialized
DEBUG - 2011-07-26 16:07:10 --> Model Class Initialized
DEBUG - 2011-07-26 16:07:10 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-26 16:07:10 --> Database Driver Class Initialized
DEBUG - 2011-07-26 16:07:11 --> Final output sent to browser
DEBUG - 2011-07-26 16:07:11 --> Total execution time: 0.6695
DEBUG - 2011-07-26 16:07:12 --> Config Class Initialized
DEBUG - 2011-07-26 16:07:12 --> Hooks Class Initialized
DEBUG - 2011-07-26 16:07:12 --> Utf8 Class Initialized
DEBUG - 2011-07-26 16:07:12 --> UTF-8 Support Enabled
DEBUG - 2011-07-26 16:07:12 --> URI Class Initialized
DEBUG - 2011-07-26 16:07:12 --> Router Class Initialized
ERROR - 2011-07-26 16:07:12 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-26 16:18:37 --> Config Class Initialized
DEBUG - 2011-07-26 16:18:37 --> Hooks Class Initialized
DEBUG - 2011-07-26 16:18:37 --> Utf8 Class Initialized
DEBUG - 2011-07-26 16:18:37 --> UTF-8 Support Enabled
DEBUG - 2011-07-26 16:18:37 --> URI Class Initialized
DEBUG - 2011-07-26 16:18:37 --> Router Class Initialized
DEBUG - 2011-07-26 16:18:37 --> Output Class Initialized
DEBUG - 2011-07-26 16:18:37 --> Input Class Initialized
DEBUG - 2011-07-26 16:18:37 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-26 16:18:37 --> Language Class Initialized
DEBUG - 2011-07-26 16:18:37 --> Loader Class Initialized
DEBUG - 2011-07-26 16:18:37 --> Controller Class Initialized
ERROR - 2011-07-26 16:18:37 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-26 16:18:37 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-26 16:18:37 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-26 16:18:37 --> Model Class Initialized
DEBUG - 2011-07-26 16:18:37 --> Model Class Initialized
DEBUG - 2011-07-26 16:18:37 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-26 16:18:37 --> Database Driver Class Initialized
DEBUG - 2011-07-26 16:18:37 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-26 16:18:37 --> Helper loaded: url_helper
DEBUG - 2011-07-26 16:18:37 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-26 16:18:37 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-26 16:18:37 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-26 16:18:37 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-26 16:18:37 --> Final output sent to browser
DEBUG - 2011-07-26 16:18:37 --> Total execution time: 0.0298
DEBUG - 2011-07-26 16:18:39 --> Config Class Initialized
DEBUG - 2011-07-26 16:18:39 --> Hooks Class Initialized
DEBUG - 2011-07-26 16:18:39 --> Utf8 Class Initialized
DEBUG - 2011-07-26 16:18:39 --> UTF-8 Support Enabled
DEBUG - 2011-07-26 16:18:39 --> URI Class Initialized
DEBUG - 2011-07-26 16:18:39 --> Router Class Initialized
DEBUG - 2011-07-26 16:18:39 --> Output Class Initialized
DEBUG - 2011-07-26 16:18:39 --> Input Class Initialized
DEBUG - 2011-07-26 16:18:39 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-26 16:18:39 --> Language Class Initialized
DEBUG - 2011-07-26 16:18:39 --> Loader Class Initialized
DEBUG - 2011-07-26 16:18:39 --> Controller Class Initialized
DEBUG - 2011-07-26 16:18:39 --> Model Class Initialized
DEBUG - 2011-07-26 16:18:39 --> Model Class Initialized
DEBUG - 2011-07-26 16:18:39 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-26 16:18:39 --> Database Driver Class Initialized
DEBUG - 2011-07-26 16:18:39 --> Final output sent to browser
DEBUG - 2011-07-26 16:18:39 --> Total execution time: 0.6996
DEBUG - 2011-07-26 16:18:41 --> Config Class Initialized
DEBUG - 2011-07-26 16:18:41 --> Hooks Class Initialized
DEBUG - 2011-07-26 16:18:41 --> Utf8 Class Initialized
DEBUG - 2011-07-26 16:18:41 --> UTF-8 Support Enabled
DEBUG - 2011-07-26 16:18:41 --> URI Class Initialized
DEBUG - 2011-07-26 16:18:41 --> Router Class Initialized
ERROR - 2011-07-26 16:18:41 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-26 16:19:26 --> Config Class Initialized
DEBUG - 2011-07-26 16:19:26 --> Hooks Class Initialized
DEBUG - 2011-07-26 16:19:26 --> Utf8 Class Initialized
DEBUG - 2011-07-26 16:19:26 --> UTF-8 Support Enabled
DEBUG - 2011-07-26 16:19:26 --> URI Class Initialized
DEBUG - 2011-07-26 16:19:26 --> Router Class Initialized
DEBUG - 2011-07-26 16:19:26 --> Output Class Initialized
DEBUG - 2011-07-26 16:19:26 --> Input Class Initialized
DEBUG - 2011-07-26 16:19:26 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-26 16:19:26 --> Language Class Initialized
DEBUG - 2011-07-26 16:19:26 --> Loader Class Initialized
DEBUG - 2011-07-26 16:19:26 --> Controller Class Initialized
ERROR - 2011-07-26 16:19:26 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-26 16:19:26 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-26 16:19:26 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-26 16:19:26 --> Model Class Initialized
DEBUG - 2011-07-26 16:19:26 --> Model Class Initialized
DEBUG - 2011-07-26 16:19:26 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-26 16:19:26 --> Database Driver Class Initialized
DEBUG - 2011-07-26 16:19:26 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-26 16:19:26 --> Helper loaded: url_helper
DEBUG - 2011-07-26 16:19:26 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-26 16:19:26 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-26 16:19:26 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-26 16:19:26 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-26 16:19:26 --> Final output sent to browser
DEBUG - 2011-07-26 16:19:26 --> Total execution time: 0.0434
DEBUG - 2011-07-26 16:19:28 --> Config Class Initialized
DEBUG - 2011-07-26 16:19:28 --> Hooks Class Initialized
DEBUG - 2011-07-26 16:19:28 --> Utf8 Class Initialized
DEBUG - 2011-07-26 16:19:28 --> UTF-8 Support Enabled
DEBUG - 2011-07-26 16:19:28 --> URI Class Initialized
DEBUG - 2011-07-26 16:19:28 --> Router Class Initialized
DEBUG - 2011-07-26 16:19:28 --> Output Class Initialized
DEBUG - 2011-07-26 16:19:28 --> Input Class Initialized
DEBUG - 2011-07-26 16:19:28 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-26 16:19:28 --> Language Class Initialized
DEBUG - 2011-07-26 16:19:28 --> Loader Class Initialized
DEBUG - 2011-07-26 16:19:28 --> Controller Class Initialized
DEBUG - 2011-07-26 16:19:28 --> Model Class Initialized
DEBUG - 2011-07-26 16:19:28 --> Model Class Initialized
DEBUG - 2011-07-26 16:19:28 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-26 16:19:28 --> Database Driver Class Initialized
DEBUG - 2011-07-26 16:19:28 --> Final output sent to browser
DEBUG - 2011-07-26 16:19:28 --> Total execution time: 0.7138
DEBUG - 2011-07-26 16:19:30 --> Config Class Initialized
DEBUG - 2011-07-26 16:19:30 --> Hooks Class Initialized
DEBUG - 2011-07-26 16:19:30 --> Utf8 Class Initialized
DEBUG - 2011-07-26 16:19:30 --> UTF-8 Support Enabled
DEBUG - 2011-07-26 16:19:30 --> URI Class Initialized
DEBUG - 2011-07-26 16:19:30 --> Router Class Initialized
ERROR - 2011-07-26 16:19:30 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-26 16:19:34 --> Config Class Initialized
DEBUG - 2011-07-26 16:19:34 --> Hooks Class Initialized
DEBUG - 2011-07-26 16:19:34 --> Utf8 Class Initialized
DEBUG - 2011-07-26 16:19:34 --> UTF-8 Support Enabled
DEBUG - 2011-07-26 16:19:34 --> URI Class Initialized
DEBUG - 2011-07-26 16:19:34 --> Router Class Initialized
DEBUG - 2011-07-26 16:19:34 --> Output Class Initialized
DEBUG - 2011-07-26 16:19:34 --> Input Class Initialized
DEBUG - 2011-07-26 16:19:34 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-26 16:19:34 --> Language Class Initialized
DEBUG - 2011-07-26 16:19:34 --> Loader Class Initialized
DEBUG - 2011-07-26 16:19:34 --> Controller Class Initialized
ERROR - 2011-07-26 16:19:34 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-26 16:19:34 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-26 16:19:34 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-26 16:19:34 --> Model Class Initialized
DEBUG - 2011-07-26 16:19:34 --> Model Class Initialized
DEBUG - 2011-07-26 16:19:34 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-26 16:19:34 --> Database Driver Class Initialized
DEBUG - 2011-07-26 16:19:34 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-26 16:19:34 --> Helper loaded: url_helper
DEBUG - 2011-07-26 16:19:34 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-26 16:19:34 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-26 16:19:34 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-26 16:19:34 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-26 16:19:34 --> Final output sent to browser
DEBUG - 2011-07-26 16:19:34 --> Total execution time: 0.0865
DEBUG - 2011-07-26 16:19:34 --> Config Class Initialized
DEBUG - 2011-07-26 16:19:34 --> Hooks Class Initialized
DEBUG - 2011-07-26 16:19:34 --> Utf8 Class Initialized
DEBUG - 2011-07-26 16:19:34 --> UTF-8 Support Enabled
DEBUG - 2011-07-26 16:19:34 --> URI Class Initialized
DEBUG - 2011-07-26 16:19:34 --> Router Class Initialized
DEBUG - 2011-07-26 16:19:34 --> Output Class Initialized
DEBUG - 2011-07-26 16:19:34 --> Input Class Initialized
DEBUG - 2011-07-26 16:19:34 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-26 16:19:34 --> Language Class Initialized
DEBUG - 2011-07-26 16:19:34 --> Loader Class Initialized
DEBUG - 2011-07-26 16:19:34 --> Controller Class Initialized
DEBUG - 2011-07-26 16:19:34 --> Model Class Initialized
DEBUG - 2011-07-26 16:19:34 --> Model Class Initialized
DEBUG - 2011-07-26 16:19:34 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-26 16:19:34 --> Database Driver Class Initialized
DEBUG - 2011-07-26 16:19:35 --> Config Class Initialized
DEBUG - 2011-07-26 16:19:35 --> Hooks Class Initialized
DEBUG - 2011-07-26 16:19:35 --> Utf8 Class Initialized
DEBUG - 2011-07-26 16:19:35 --> UTF-8 Support Enabled
DEBUG - 2011-07-26 16:19:35 --> URI Class Initialized
DEBUG - 2011-07-26 16:19:35 --> Router Class Initialized
DEBUG - 2011-07-26 16:19:35 --> Output Class Initialized
DEBUG - 2011-07-26 16:19:35 --> Input Class Initialized
DEBUG - 2011-07-26 16:19:35 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-26 16:19:35 --> Language Class Initialized
DEBUG - 2011-07-26 16:19:35 --> Loader Class Initialized
DEBUG - 2011-07-26 16:19:35 --> Controller Class Initialized
ERROR - 2011-07-26 16:19:35 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-26 16:19:35 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-26 16:19:35 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-26 16:19:35 --> Model Class Initialized
DEBUG - 2011-07-26 16:19:35 --> Model Class Initialized
DEBUG - 2011-07-26 16:19:35 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-26 16:19:35 --> Database Driver Class Initialized
DEBUG - 2011-07-26 16:19:35 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-26 16:19:35 --> Helper loaded: url_helper
DEBUG - 2011-07-26 16:19:35 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-26 16:19:35 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-26 16:19:35 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-26 16:19:35 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-26 16:19:35 --> Final output sent to browser
DEBUG - 2011-07-26 16:19:35 --> Total execution time: 0.0329
DEBUG - 2011-07-26 16:19:35 --> Final output sent to browser
DEBUG - 2011-07-26 16:19:35 --> Total execution time: 0.6388
DEBUG - 2011-07-26 16:19:37 --> Config Class Initialized
DEBUG - 2011-07-26 16:19:37 --> Hooks Class Initialized
DEBUG - 2011-07-26 16:19:37 --> Utf8 Class Initialized
DEBUG - 2011-07-26 16:19:37 --> UTF-8 Support Enabled
DEBUG - 2011-07-26 16:19:37 --> URI Class Initialized
DEBUG - 2011-07-26 16:19:37 --> Router Class Initialized
ERROR - 2011-07-26 16:19:37 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-26 16:19:42 --> Config Class Initialized
DEBUG - 2011-07-26 16:19:42 --> Hooks Class Initialized
DEBUG - 2011-07-26 16:19:42 --> Utf8 Class Initialized
DEBUG - 2011-07-26 16:19:42 --> UTF-8 Support Enabled
DEBUG - 2011-07-26 16:19:42 --> URI Class Initialized
DEBUG - 2011-07-26 16:19:42 --> Router Class Initialized
DEBUG - 2011-07-26 16:19:42 --> Output Class Initialized
DEBUG - 2011-07-26 16:19:42 --> Input Class Initialized
DEBUG - 2011-07-26 16:19:42 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-26 16:19:42 --> Language Class Initialized
DEBUG - 2011-07-26 16:19:42 --> Loader Class Initialized
DEBUG - 2011-07-26 16:19:42 --> Controller Class Initialized
ERROR - 2011-07-26 16:19:42 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-26 16:19:42 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-26 16:19:42 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-26 16:19:42 --> Model Class Initialized
DEBUG - 2011-07-26 16:19:42 --> Model Class Initialized
DEBUG - 2011-07-26 16:19:42 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-26 16:19:42 --> Database Driver Class Initialized
DEBUG - 2011-07-26 16:19:42 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-26 16:19:42 --> Helper loaded: url_helper
DEBUG - 2011-07-26 16:19:42 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-26 16:19:42 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-26 16:19:42 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-26 16:19:42 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-26 16:19:42 --> Final output sent to browser
DEBUG - 2011-07-26 16:19:42 --> Total execution time: 0.0852
DEBUG - 2011-07-26 16:19:43 --> Config Class Initialized
DEBUG - 2011-07-26 16:19:43 --> Hooks Class Initialized
DEBUG - 2011-07-26 16:19:43 --> Utf8 Class Initialized
DEBUG - 2011-07-26 16:19:43 --> UTF-8 Support Enabled
DEBUG - 2011-07-26 16:19:43 --> URI Class Initialized
DEBUG - 2011-07-26 16:19:43 --> Router Class Initialized
DEBUG - 2011-07-26 16:19:43 --> Output Class Initialized
DEBUG - 2011-07-26 16:19:43 --> Input Class Initialized
DEBUG - 2011-07-26 16:19:43 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-26 16:19:43 --> Language Class Initialized
DEBUG - 2011-07-26 16:19:43 --> Loader Class Initialized
DEBUG - 2011-07-26 16:19:43 --> Controller Class Initialized
DEBUG - 2011-07-26 16:19:43 --> Model Class Initialized
DEBUG - 2011-07-26 16:19:43 --> Model Class Initialized
DEBUG - 2011-07-26 16:19:43 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-26 16:19:43 --> Database Driver Class Initialized
DEBUG - 2011-07-26 16:19:43 --> Config Class Initialized
DEBUG - 2011-07-26 16:19:43 --> Hooks Class Initialized
DEBUG - 2011-07-26 16:19:43 --> Utf8 Class Initialized
DEBUG - 2011-07-26 16:19:43 --> UTF-8 Support Enabled
DEBUG - 2011-07-26 16:19:43 --> URI Class Initialized
DEBUG - 2011-07-26 16:19:43 --> Router Class Initialized
DEBUG - 2011-07-26 16:19:43 --> Output Class Initialized
DEBUG - 2011-07-26 16:19:43 --> Input Class Initialized
DEBUG - 2011-07-26 16:19:43 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-26 16:19:43 --> Language Class Initialized
DEBUG - 2011-07-26 16:19:43 --> Loader Class Initialized
DEBUG - 2011-07-26 16:19:43 --> Controller Class Initialized
ERROR - 2011-07-26 16:19:43 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-26 16:19:43 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-26 16:19:43 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-26 16:19:43 --> Model Class Initialized
DEBUG - 2011-07-26 16:19:43 --> Model Class Initialized
DEBUG - 2011-07-26 16:19:43 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-26 16:19:43 --> Database Driver Class Initialized
DEBUG - 2011-07-26 16:19:43 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-26 16:19:43 --> Helper loaded: url_helper
DEBUG - 2011-07-26 16:19:43 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-26 16:19:43 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-26 16:19:43 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-26 16:19:43 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-26 16:19:43 --> Final output sent to browser
DEBUG - 2011-07-26 16:19:43 --> Total execution time: 0.0276
DEBUG - 2011-07-26 16:19:43 --> Final output sent to browser
DEBUG - 2011-07-26 16:19:43 --> Total execution time: 0.6432
DEBUG - 2011-07-26 16:19:45 --> Config Class Initialized
DEBUG - 2011-07-26 16:19:45 --> Hooks Class Initialized
DEBUG - 2011-07-26 16:19:45 --> Utf8 Class Initialized
DEBUG - 2011-07-26 16:19:45 --> UTF-8 Support Enabled
DEBUG - 2011-07-26 16:19:45 --> URI Class Initialized
DEBUG - 2011-07-26 16:19:45 --> Router Class Initialized
ERROR - 2011-07-26 16:19:45 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-26 16:19:58 --> Config Class Initialized
DEBUG - 2011-07-26 16:19:58 --> Hooks Class Initialized
DEBUG - 2011-07-26 16:19:58 --> Utf8 Class Initialized
DEBUG - 2011-07-26 16:19:58 --> UTF-8 Support Enabled
DEBUG - 2011-07-26 16:19:58 --> URI Class Initialized
DEBUG - 2011-07-26 16:19:58 --> Router Class Initialized
DEBUG - 2011-07-26 16:19:58 --> Output Class Initialized
DEBUG - 2011-07-26 16:19:58 --> Input Class Initialized
DEBUG - 2011-07-26 16:19:58 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-26 16:19:58 --> Language Class Initialized
DEBUG - 2011-07-26 16:19:58 --> Loader Class Initialized
DEBUG - 2011-07-26 16:19:58 --> Controller Class Initialized
ERROR - 2011-07-26 16:19:58 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-26 16:19:58 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-26 16:19:58 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-26 16:19:58 --> Model Class Initialized
DEBUG - 2011-07-26 16:19:58 --> Model Class Initialized
DEBUG - 2011-07-26 16:19:58 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-26 16:19:58 --> Database Driver Class Initialized
DEBUG - 2011-07-26 16:19:58 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-26 16:19:58 --> Helper loaded: url_helper
DEBUG - 2011-07-26 16:19:58 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-26 16:19:58 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-26 16:19:58 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-26 16:19:58 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-26 16:19:58 --> Final output sent to browser
DEBUG - 2011-07-26 16:19:58 --> Total execution time: 0.0278
DEBUG - 2011-07-26 16:19:59 --> Config Class Initialized
DEBUG - 2011-07-26 16:19:59 --> Hooks Class Initialized
DEBUG - 2011-07-26 16:19:59 --> Utf8 Class Initialized
DEBUG - 2011-07-26 16:19:59 --> UTF-8 Support Enabled
DEBUG - 2011-07-26 16:19:59 --> URI Class Initialized
DEBUG - 2011-07-26 16:19:59 --> Router Class Initialized
DEBUG - 2011-07-26 16:19:59 --> Output Class Initialized
DEBUG - 2011-07-26 16:19:59 --> Input Class Initialized
DEBUG - 2011-07-26 16:19:59 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-26 16:19:59 --> Language Class Initialized
DEBUG - 2011-07-26 16:19:59 --> Loader Class Initialized
DEBUG - 2011-07-26 16:19:59 --> Controller Class Initialized
DEBUG - 2011-07-26 16:19:59 --> Model Class Initialized
DEBUG - 2011-07-26 16:19:59 --> Model Class Initialized
DEBUG - 2011-07-26 16:19:59 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-26 16:19:59 --> Database Driver Class Initialized
DEBUG - 2011-07-26 16:20:00 --> Final output sent to browser
DEBUG - 2011-07-26 16:20:00 --> Total execution time: 0.5506
DEBUG - 2011-07-26 16:20:03 --> Config Class Initialized
DEBUG - 2011-07-26 16:20:03 --> Hooks Class Initialized
DEBUG - 2011-07-26 16:20:03 --> Utf8 Class Initialized
DEBUG - 2011-07-26 16:20:03 --> UTF-8 Support Enabled
DEBUG - 2011-07-26 16:20:03 --> URI Class Initialized
DEBUG - 2011-07-26 16:20:03 --> Router Class Initialized
ERROR - 2011-07-26 16:20:03 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-26 16:20:11 --> Config Class Initialized
DEBUG - 2011-07-26 16:20:11 --> Hooks Class Initialized
DEBUG - 2011-07-26 16:20:11 --> Utf8 Class Initialized
DEBUG - 2011-07-26 16:20:11 --> UTF-8 Support Enabled
DEBUG - 2011-07-26 16:20:11 --> URI Class Initialized
DEBUG - 2011-07-26 16:20:11 --> Router Class Initialized
DEBUG - 2011-07-26 16:20:11 --> Output Class Initialized
DEBUG - 2011-07-26 16:20:11 --> Input Class Initialized
DEBUG - 2011-07-26 16:20:11 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-26 16:20:11 --> Language Class Initialized
DEBUG - 2011-07-26 16:20:11 --> Loader Class Initialized
DEBUG - 2011-07-26 16:20:11 --> Controller Class Initialized
ERROR - 2011-07-26 16:20:11 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-26 16:20:11 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-26 16:20:11 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-26 16:20:11 --> Model Class Initialized
DEBUG - 2011-07-26 16:20:11 --> Model Class Initialized
DEBUG - 2011-07-26 16:20:11 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-26 16:20:11 --> Database Driver Class Initialized
DEBUG - 2011-07-26 16:20:11 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-26 16:20:11 --> Helper loaded: url_helper
DEBUG - 2011-07-26 16:20:11 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-26 16:20:11 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-26 16:20:11 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-26 16:20:11 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-26 16:20:11 --> Final output sent to browser
DEBUG - 2011-07-26 16:20:11 --> Total execution time: 0.0515
DEBUG - 2011-07-26 16:20:12 --> Config Class Initialized
DEBUG - 2011-07-26 16:20:12 --> Hooks Class Initialized
DEBUG - 2011-07-26 16:20:12 --> Utf8 Class Initialized
DEBUG - 2011-07-26 16:20:12 --> UTF-8 Support Enabled
DEBUG - 2011-07-26 16:20:12 --> URI Class Initialized
DEBUG - 2011-07-26 16:20:12 --> Router Class Initialized
DEBUG - 2011-07-26 16:20:12 --> Output Class Initialized
DEBUG - 2011-07-26 16:20:12 --> Input Class Initialized
DEBUG - 2011-07-26 16:20:12 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-26 16:20:12 --> Language Class Initialized
DEBUG - 2011-07-26 16:20:12 --> Loader Class Initialized
DEBUG - 2011-07-26 16:20:12 --> Controller Class Initialized
DEBUG - 2011-07-26 16:20:12 --> Model Class Initialized
DEBUG - 2011-07-26 16:20:12 --> Model Class Initialized
DEBUG - 2011-07-26 16:20:12 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-26 16:20:12 --> Database Driver Class Initialized
DEBUG - 2011-07-26 16:20:13 --> Final output sent to browser
DEBUG - 2011-07-26 16:20:13 --> Total execution time: 0.5142
DEBUG - 2011-07-26 16:20:15 --> Config Class Initialized
DEBUG - 2011-07-26 16:20:15 --> Hooks Class Initialized
DEBUG - 2011-07-26 16:20:15 --> Utf8 Class Initialized
DEBUG - 2011-07-26 16:20:15 --> UTF-8 Support Enabled
DEBUG - 2011-07-26 16:20:15 --> URI Class Initialized
DEBUG - 2011-07-26 16:20:15 --> Router Class Initialized
ERROR - 2011-07-26 16:20:15 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-26 16:20:26 --> Config Class Initialized
DEBUG - 2011-07-26 16:20:26 --> Hooks Class Initialized
DEBUG - 2011-07-26 16:20:26 --> Utf8 Class Initialized
DEBUG - 2011-07-26 16:20:26 --> UTF-8 Support Enabled
DEBUG - 2011-07-26 16:20:26 --> URI Class Initialized
DEBUG - 2011-07-26 16:20:26 --> Router Class Initialized
DEBUG - 2011-07-26 16:20:26 --> Output Class Initialized
DEBUG - 2011-07-26 16:20:26 --> Input Class Initialized
DEBUG - 2011-07-26 16:20:26 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-26 16:20:26 --> Language Class Initialized
DEBUG - 2011-07-26 16:20:26 --> Loader Class Initialized
DEBUG - 2011-07-26 16:20:26 --> Controller Class Initialized
ERROR - 2011-07-26 16:20:26 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-26 16:20:26 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-26 16:20:26 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-26 16:20:26 --> Model Class Initialized
DEBUG - 2011-07-26 16:20:26 --> Model Class Initialized
DEBUG - 2011-07-26 16:20:26 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-26 16:20:26 --> Database Driver Class Initialized
DEBUG - 2011-07-26 16:20:26 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-26 16:20:26 --> Helper loaded: url_helper
DEBUG - 2011-07-26 16:20:26 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-26 16:20:26 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-26 16:20:26 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-26 16:20:26 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-26 16:20:26 --> Final output sent to browser
DEBUG - 2011-07-26 16:20:26 --> Total execution time: 0.0339
DEBUG - 2011-07-26 16:20:27 --> Config Class Initialized
DEBUG - 2011-07-26 16:20:27 --> Hooks Class Initialized
DEBUG - 2011-07-26 16:20:27 --> Utf8 Class Initialized
DEBUG - 2011-07-26 16:20:27 --> UTF-8 Support Enabled
DEBUG - 2011-07-26 16:20:27 --> URI Class Initialized
DEBUG - 2011-07-26 16:20:27 --> Router Class Initialized
DEBUG - 2011-07-26 16:20:27 --> Output Class Initialized
DEBUG - 2011-07-26 16:20:27 --> Input Class Initialized
DEBUG - 2011-07-26 16:20:27 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-26 16:20:27 --> Language Class Initialized
DEBUG - 2011-07-26 16:20:27 --> Loader Class Initialized
DEBUG - 2011-07-26 16:20:27 --> Controller Class Initialized
DEBUG - 2011-07-26 16:20:27 --> Model Class Initialized
DEBUG - 2011-07-26 16:20:27 --> Model Class Initialized
DEBUG - 2011-07-26 16:20:27 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-26 16:20:27 --> Database Driver Class Initialized
DEBUG - 2011-07-26 16:20:28 --> Final output sent to browser
DEBUG - 2011-07-26 16:20:28 --> Total execution time: 0.5761
DEBUG - 2011-07-26 16:20:29 --> Config Class Initialized
DEBUG - 2011-07-26 16:20:29 --> Hooks Class Initialized
DEBUG - 2011-07-26 16:20:29 --> Utf8 Class Initialized
DEBUG - 2011-07-26 16:20:29 --> UTF-8 Support Enabled
DEBUG - 2011-07-26 16:20:29 --> URI Class Initialized
DEBUG - 2011-07-26 16:20:29 --> Router Class Initialized
ERROR - 2011-07-26 16:20:29 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-26 16:20:41 --> Config Class Initialized
DEBUG - 2011-07-26 16:20:41 --> Hooks Class Initialized
DEBUG - 2011-07-26 16:20:41 --> Utf8 Class Initialized
DEBUG - 2011-07-26 16:20:41 --> UTF-8 Support Enabled
DEBUG - 2011-07-26 16:20:41 --> URI Class Initialized
DEBUG - 2011-07-26 16:20:41 --> Router Class Initialized
DEBUG - 2011-07-26 16:20:41 --> Output Class Initialized
DEBUG - 2011-07-26 16:20:41 --> Input Class Initialized
DEBUG - 2011-07-26 16:20:41 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-26 16:20:41 --> Language Class Initialized
DEBUG - 2011-07-26 16:20:41 --> Loader Class Initialized
DEBUG - 2011-07-26 16:20:41 --> Controller Class Initialized
ERROR - 2011-07-26 16:20:41 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-26 16:20:41 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-26 16:20:41 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-26 16:20:41 --> Model Class Initialized
DEBUG - 2011-07-26 16:20:41 --> Model Class Initialized
DEBUG - 2011-07-26 16:20:41 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-26 16:20:41 --> Database Driver Class Initialized
DEBUG - 2011-07-26 16:20:41 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-26 16:20:41 --> Helper loaded: url_helper
DEBUG - 2011-07-26 16:20:41 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-26 16:20:41 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-26 16:20:41 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-26 16:20:41 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-26 16:20:41 --> Final output sent to browser
DEBUG - 2011-07-26 16:20:41 --> Total execution time: 0.0418
DEBUG - 2011-07-26 16:20:42 --> Config Class Initialized
DEBUG - 2011-07-26 16:20:42 --> Hooks Class Initialized
DEBUG - 2011-07-26 16:20:42 --> Utf8 Class Initialized
DEBUG - 2011-07-26 16:20:42 --> UTF-8 Support Enabled
DEBUG - 2011-07-26 16:20:42 --> URI Class Initialized
DEBUG - 2011-07-26 16:20:42 --> Router Class Initialized
DEBUG - 2011-07-26 16:20:42 --> Output Class Initialized
DEBUG - 2011-07-26 16:20:42 --> Input Class Initialized
DEBUG - 2011-07-26 16:20:42 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-26 16:20:42 --> Language Class Initialized
DEBUG - 2011-07-26 16:20:42 --> Loader Class Initialized
DEBUG - 2011-07-26 16:20:42 --> Controller Class Initialized
DEBUG - 2011-07-26 16:20:42 --> Model Class Initialized
DEBUG - 2011-07-26 16:20:42 --> Model Class Initialized
DEBUG - 2011-07-26 16:20:42 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-26 16:20:42 --> Database Driver Class Initialized
DEBUG - 2011-07-26 16:20:43 --> Final output sent to browser
DEBUG - 2011-07-26 16:20:43 --> Total execution time: 0.5957
DEBUG - 2011-07-26 16:20:44 --> Config Class Initialized
DEBUG - 2011-07-26 16:20:44 --> Hooks Class Initialized
DEBUG - 2011-07-26 16:20:44 --> Utf8 Class Initialized
DEBUG - 2011-07-26 16:20:44 --> UTF-8 Support Enabled
DEBUG - 2011-07-26 16:20:44 --> URI Class Initialized
DEBUG - 2011-07-26 16:20:44 --> Router Class Initialized
ERROR - 2011-07-26 16:20:44 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-26 16:20:56 --> Config Class Initialized
DEBUG - 2011-07-26 16:20:56 --> Hooks Class Initialized
DEBUG - 2011-07-26 16:20:56 --> Utf8 Class Initialized
DEBUG - 2011-07-26 16:20:56 --> UTF-8 Support Enabled
DEBUG - 2011-07-26 16:20:56 --> URI Class Initialized
DEBUG - 2011-07-26 16:20:56 --> Router Class Initialized
DEBUG - 2011-07-26 16:20:56 --> Output Class Initialized
DEBUG - 2011-07-26 16:20:56 --> Input Class Initialized
DEBUG - 2011-07-26 16:20:56 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-26 16:20:56 --> Language Class Initialized
DEBUG - 2011-07-26 16:20:56 --> Loader Class Initialized
DEBUG - 2011-07-26 16:20:56 --> Controller Class Initialized
ERROR - 2011-07-26 16:20:56 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-26 16:20:56 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-26 16:20:56 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-26 16:20:56 --> Model Class Initialized
DEBUG - 2011-07-26 16:20:56 --> Model Class Initialized
DEBUG - 2011-07-26 16:20:56 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-26 16:20:56 --> Database Driver Class Initialized
DEBUG - 2011-07-26 16:20:56 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-26 16:20:56 --> Helper loaded: url_helper
DEBUG - 2011-07-26 16:20:56 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-26 16:20:56 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-26 16:20:56 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-26 16:20:56 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-26 16:20:56 --> Final output sent to browser
DEBUG - 2011-07-26 16:20:56 --> Total execution time: 0.0322
DEBUG - 2011-07-26 16:20:58 --> Config Class Initialized
DEBUG - 2011-07-26 16:20:58 --> Hooks Class Initialized
DEBUG - 2011-07-26 16:20:58 --> Utf8 Class Initialized
DEBUG - 2011-07-26 16:20:58 --> UTF-8 Support Enabled
DEBUG - 2011-07-26 16:20:58 --> URI Class Initialized
DEBUG - 2011-07-26 16:20:58 --> Router Class Initialized
DEBUG - 2011-07-26 16:20:58 --> Output Class Initialized
DEBUG - 2011-07-26 16:20:58 --> Input Class Initialized
DEBUG - 2011-07-26 16:20:58 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-26 16:20:58 --> Language Class Initialized
DEBUG - 2011-07-26 16:20:58 --> Loader Class Initialized
DEBUG - 2011-07-26 16:20:58 --> Controller Class Initialized
DEBUG - 2011-07-26 16:20:58 --> Model Class Initialized
DEBUG - 2011-07-26 16:20:58 --> Model Class Initialized
DEBUG - 2011-07-26 16:20:58 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-26 16:20:58 --> Database Driver Class Initialized
DEBUG - 2011-07-26 16:20:59 --> Final output sent to browser
DEBUG - 2011-07-26 16:20:59 --> Total execution time: 0.9067
DEBUG - 2011-07-26 16:21:00 --> Config Class Initialized
DEBUG - 2011-07-26 16:21:00 --> Hooks Class Initialized
DEBUG - 2011-07-26 16:21:00 --> Utf8 Class Initialized
DEBUG - 2011-07-26 16:21:00 --> UTF-8 Support Enabled
DEBUG - 2011-07-26 16:21:00 --> URI Class Initialized
DEBUG - 2011-07-26 16:21:00 --> Router Class Initialized
ERROR - 2011-07-26 16:21:00 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-26 19:07:07 --> Config Class Initialized
DEBUG - 2011-07-26 19:07:07 --> Hooks Class Initialized
DEBUG - 2011-07-26 19:07:07 --> Utf8 Class Initialized
DEBUG - 2011-07-26 19:07:07 --> UTF-8 Support Enabled
DEBUG - 2011-07-26 19:07:07 --> URI Class Initialized
DEBUG - 2011-07-26 19:07:07 --> Router Class Initialized
ERROR - 2011-07-26 19:07:07 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-07-26 19:07:08 --> Config Class Initialized
DEBUG - 2011-07-26 19:07:08 --> Hooks Class Initialized
DEBUG - 2011-07-26 19:07:08 --> Utf8 Class Initialized
DEBUG - 2011-07-26 19:07:08 --> UTF-8 Support Enabled
DEBUG - 2011-07-26 19:07:08 --> URI Class Initialized
DEBUG - 2011-07-26 19:07:08 --> Router Class Initialized
DEBUG - 2011-07-26 19:07:08 --> No URI present. Default controller set.
DEBUG - 2011-07-26 19:07:08 --> Output Class Initialized
DEBUG - 2011-07-26 19:07:08 --> Input Class Initialized
DEBUG - 2011-07-26 19:07:08 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-26 19:07:08 --> Language Class Initialized
DEBUG - 2011-07-26 19:07:08 --> Loader Class Initialized
DEBUG - 2011-07-26 19:07:08 --> Controller Class Initialized
DEBUG - 2011-07-26 19:07:08 --> File loaded: application/views/splash/main.php
DEBUG - 2011-07-26 19:07:08 --> Helper loaded: url_helper
DEBUG - 2011-07-26 19:07:08 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-26 19:07:08 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-26 19:07:08 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-26 19:07:08 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-26 19:07:08 --> Final output sent to browser
DEBUG - 2011-07-26 19:07:08 --> Total execution time: 0.0636
DEBUG - 2011-07-26 19:07:15 --> Config Class Initialized
DEBUG - 2011-07-26 19:07:15 --> Hooks Class Initialized
DEBUG - 2011-07-26 19:07:15 --> Utf8 Class Initialized
DEBUG - 2011-07-26 19:07:15 --> UTF-8 Support Enabled
DEBUG - 2011-07-26 19:07:15 --> URI Class Initialized
DEBUG - 2011-07-26 19:07:15 --> Router Class Initialized
DEBUG - 2011-07-26 19:07:15 --> Output Class Initialized
DEBUG - 2011-07-26 19:07:15 --> Input Class Initialized
DEBUG - 2011-07-26 19:07:15 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-26 19:07:15 --> Language Class Initialized
DEBUG - 2011-07-26 19:07:15 --> Loader Class Initialized
DEBUG - 2011-07-26 19:07:15 --> Controller Class Initialized
DEBUG - 2011-07-26 19:07:15 --> Model Class Initialized
DEBUG - 2011-07-26 19:07:15 --> Model Class Initialized
DEBUG - 2011-07-26 19:07:15 --> Model Class Initialized
DEBUG - 2011-07-26 19:07:15 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-26 19:07:15 --> Database Driver Class Initialized
DEBUG - 2011-07-26 19:07:15 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-26 19:07:15 --> Helper loaded: url_helper
DEBUG - 2011-07-26 19:07:15 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-26 19:07:15 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-26 19:07:15 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-26 19:07:15 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-26 19:07:15 --> Final output sent to browser
DEBUG - 2011-07-26 19:07:15 --> Total execution time: 0.3395
DEBUG - 2011-07-26 19:09:39 --> Config Class Initialized
DEBUG - 2011-07-26 19:09:39 --> Hooks Class Initialized
DEBUG - 2011-07-26 19:09:39 --> Utf8 Class Initialized
DEBUG - 2011-07-26 19:09:39 --> UTF-8 Support Enabled
DEBUG - 2011-07-26 19:09:39 --> URI Class Initialized
DEBUG - 2011-07-26 19:09:39 --> Router Class Initialized
DEBUG - 2011-07-26 19:09:39 --> Output Class Initialized
DEBUG - 2011-07-26 19:09:39 --> Input Class Initialized
DEBUG - 2011-07-26 19:09:39 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-26 19:09:39 --> Language Class Initialized
DEBUG - 2011-07-26 19:09:39 --> Loader Class Initialized
DEBUG - 2011-07-26 19:09:39 --> Controller Class Initialized
DEBUG - 2011-07-26 19:09:39 --> Model Class Initialized
DEBUG - 2011-07-26 19:09:39 --> Model Class Initialized
DEBUG - 2011-07-26 19:09:39 --> Model Class Initialized
DEBUG - 2011-07-26 19:09:39 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-26 19:09:39 --> Database Driver Class Initialized
DEBUG - 2011-07-26 19:09:39 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-26 19:09:39 --> Helper loaded: url_helper
DEBUG - 2011-07-26 19:09:39 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-26 19:09:39 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-26 19:09:39 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-26 19:09:39 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-26 19:09:39 --> Final output sent to browser
DEBUG - 2011-07-26 19:09:39 --> Total execution time: 0.1409
DEBUG - 2011-07-26 19:09:40 --> Config Class Initialized
DEBUG - 2011-07-26 19:09:40 --> Hooks Class Initialized
DEBUG - 2011-07-26 19:09:40 --> Utf8 Class Initialized
DEBUG - 2011-07-26 19:09:40 --> UTF-8 Support Enabled
DEBUG - 2011-07-26 19:09:40 --> URI Class Initialized
DEBUG - 2011-07-26 19:09:40 --> Router Class Initialized
DEBUG - 2011-07-26 19:09:40 --> Output Class Initialized
DEBUG - 2011-07-26 19:09:40 --> Input Class Initialized
DEBUG - 2011-07-26 19:09:40 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-26 19:09:40 --> Language Class Initialized
DEBUG - 2011-07-26 19:09:40 --> Loader Class Initialized
DEBUG - 2011-07-26 19:09:40 --> Controller Class Initialized
ERROR - 2011-07-26 19:09:40 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-26 19:09:40 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-26 19:09:40 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-26 19:09:40 --> Model Class Initialized
DEBUG - 2011-07-26 19:09:40 --> Model Class Initialized
DEBUG - 2011-07-26 19:09:40 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-26 19:09:40 --> Database Driver Class Initialized
DEBUG - 2011-07-26 19:09:40 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-26 19:09:40 --> Helper loaded: url_helper
DEBUG - 2011-07-26 19:09:40 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-26 19:09:40 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-26 19:09:40 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-26 19:09:40 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-26 19:09:40 --> Final output sent to browser
DEBUG - 2011-07-26 19:09:40 --> Total execution time: 0.0919
DEBUG - 2011-07-26 19:10:16 --> Config Class Initialized
DEBUG - 2011-07-26 19:10:16 --> Hooks Class Initialized
DEBUG - 2011-07-26 19:10:16 --> Utf8 Class Initialized
DEBUG - 2011-07-26 19:10:16 --> UTF-8 Support Enabled
DEBUG - 2011-07-26 19:10:16 --> URI Class Initialized
DEBUG - 2011-07-26 19:10:16 --> Router Class Initialized
DEBUG - 2011-07-26 19:10:16 --> Output Class Initialized
DEBUG - 2011-07-26 19:10:16 --> Input Class Initialized
DEBUG - 2011-07-26 19:10:16 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-26 19:10:16 --> Language Class Initialized
DEBUG - 2011-07-26 19:10:16 --> Loader Class Initialized
DEBUG - 2011-07-26 19:10:16 --> Controller Class Initialized
DEBUG - 2011-07-26 19:10:16 --> Model Class Initialized
DEBUG - 2011-07-26 19:10:16 --> Model Class Initialized
DEBUG - 2011-07-26 19:10:16 --> Model Class Initialized
DEBUG - 2011-07-26 19:10:16 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-26 19:10:16 --> Database Driver Class Initialized
DEBUG - 2011-07-26 19:10:16 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-26 19:10:16 --> Helper loaded: url_helper
DEBUG - 2011-07-26 19:10:16 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-26 19:10:16 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-26 19:10:16 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-26 19:10:16 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-26 19:10:16 --> Final output sent to browser
DEBUG - 2011-07-26 19:10:16 --> Total execution time: 0.0460
DEBUG - 2011-07-26 19:10:17 --> Config Class Initialized
DEBUG - 2011-07-26 19:10:17 --> Hooks Class Initialized
DEBUG - 2011-07-26 19:10:17 --> Utf8 Class Initialized
DEBUG - 2011-07-26 19:10:17 --> UTF-8 Support Enabled
DEBUG - 2011-07-26 19:10:17 --> URI Class Initialized
DEBUG - 2011-07-26 19:10:17 --> Router Class Initialized
DEBUG - 2011-07-26 19:10:17 --> Output Class Initialized
DEBUG - 2011-07-26 19:10:17 --> Input Class Initialized
DEBUG - 2011-07-26 19:10:17 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-26 19:10:17 --> Language Class Initialized
DEBUG - 2011-07-26 19:10:17 --> Loader Class Initialized
DEBUG - 2011-07-26 19:10:17 --> Controller Class Initialized
ERROR - 2011-07-26 19:10:17 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-26 19:10:17 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-26 19:10:17 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-26 19:10:17 --> Model Class Initialized
DEBUG - 2011-07-26 19:10:17 --> Model Class Initialized
DEBUG - 2011-07-26 19:10:17 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-26 19:10:17 --> Database Driver Class Initialized
DEBUG - 2011-07-26 19:10:17 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-26 19:10:17 --> Helper loaded: url_helper
DEBUG - 2011-07-26 19:10:17 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-26 19:10:17 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-26 19:10:17 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-26 19:10:17 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-26 19:10:17 --> Final output sent to browser
DEBUG - 2011-07-26 19:10:17 --> Total execution time: 0.0297
DEBUG - 2011-07-26 20:03:15 --> Config Class Initialized
DEBUG - 2011-07-26 20:03:15 --> Hooks Class Initialized
DEBUG - 2011-07-26 20:03:15 --> Utf8 Class Initialized
DEBUG - 2011-07-26 20:03:15 --> UTF-8 Support Enabled
DEBUG - 2011-07-26 20:03:15 --> URI Class Initialized
DEBUG - 2011-07-26 20:03:15 --> Router Class Initialized
DEBUG - 2011-07-26 20:03:15 --> Output Class Initialized
DEBUG - 2011-07-26 20:03:15 --> Input Class Initialized
DEBUG - 2011-07-26 20:03:15 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-26 20:03:15 --> Language Class Initialized
DEBUG - 2011-07-26 20:03:15 --> Loader Class Initialized
DEBUG - 2011-07-26 20:03:15 --> Controller Class Initialized
ERROR - 2011-07-26 20:03:15 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-26 20:03:15 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-26 20:03:15 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-26 20:03:15 --> Model Class Initialized
DEBUG - 2011-07-26 20:03:15 --> Model Class Initialized
DEBUG - 2011-07-26 20:03:15 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-26 20:03:15 --> Database Driver Class Initialized
DEBUG - 2011-07-26 20:03:15 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-26 20:03:15 --> Helper loaded: url_helper
DEBUG - 2011-07-26 20:03:15 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-26 20:03:15 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-26 20:03:15 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-26 20:03:15 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-26 20:03:15 --> Final output sent to browser
DEBUG - 2011-07-26 20:03:15 --> Total execution time: 0.0731
DEBUG - 2011-07-26 20:03:16 --> Config Class Initialized
DEBUG - 2011-07-26 20:03:16 --> Hooks Class Initialized
DEBUG - 2011-07-26 20:03:16 --> Utf8 Class Initialized
DEBUG - 2011-07-26 20:03:16 --> UTF-8 Support Enabled
DEBUG - 2011-07-26 20:03:16 --> URI Class Initialized
DEBUG - 2011-07-26 20:03:16 --> Router Class Initialized
DEBUG - 2011-07-26 20:03:16 --> Output Class Initialized
DEBUG - 2011-07-26 20:03:16 --> Input Class Initialized
DEBUG - 2011-07-26 20:03:16 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-26 20:03:16 --> Language Class Initialized
DEBUG - 2011-07-26 20:03:16 --> Loader Class Initialized
DEBUG - 2011-07-26 20:03:16 --> Controller Class Initialized
DEBUG - 2011-07-26 20:03:16 --> Model Class Initialized
DEBUG - 2011-07-26 20:03:16 --> Model Class Initialized
DEBUG - 2011-07-26 20:03:16 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-26 20:03:16 --> Database Driver Class Initialized
DEBUG - 2011-07-26 20:03:17 --> Final output sent to browser
DEBUG - 2011-07-26 20:03:17 --> Total execution time: 0.8281
DEBUG - 2011-07-26 20:03:18 --> Config Class Initialized
DEBUG - 2011-07-26 20:03:18 --> Hooks Class Initialized
DEBUG - 2011-07-26 20:03:18 --> Utf8 Class Initialized
DEBUG - 2011-07-26 20:03:18 --> UTF-8 Support Enabled
DEBUG - 2011-07-26 20:03:18 --> URI Class Initialized
DEBUG - 2011-07-26 20:03:18 --> Router Class Initialized
ERROR - 2011-07-26 20:03:18 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-26 20:03:18 --> Config Class Initialized
DEBUG - 2011-07-26 20:03:18 --> Hooks Class Initialized
DEBUG - 2011-07-26 20:03:18 --> Utf8 Class Initialized
DEBUG - 2011-07-26 20:03:18 --> UTF-8 Support Enabled
DEBUG - 2011-07-26 20:03:18 --> URI Class Initialized
DEBUG - 2011-07-26 20:03:18 --> Router Class Initialized
ERROR - 2011-07-26 20:03:18 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-26 20:03:19 --> Config Class Initialized
DEBUG - 2011-07-26 20:03:19 --> Hooks Class Initialized
DEBUG - 2011-07-26 20:03:19 --> Utf8 Class Initialized
DEBUG - 2011-07-26 20:03:19 --> UTF-8 Support Enabled
DEBUG - 2011-07-26 20:03:19 --> URI Class Initialized
DEBUG - 2011-07-26 20:03:19 --> Router Class Initialized
ERROR - 2011-07-26 20:03:19 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-26 20:04:04 --> Config Class Initialized
DEBUG - 2011-07-26 20:04:04 --> Hooks Class Initialized
DEBUG - 2011-07-26 20:04:04 --> Utf8 Class Initialized
DEBUG - 2011-07-26 20:04:04 --> UTF-8 Support Enabled
DEBUG - 2011-07-26 20:04:04 --> URI Class Initialized
DEBUG - 2011-07-26 20:04:04 --> Router Class Initialized
DEBUG - 2011-07-26 20:04:04 --> Output Class Initialized
DEBUG - 2011-07-26 20:04:04 --> Input Class Initialized
DEBUG - 2011-07-26 20:04:04 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-26 20:04:04 --> Language Class Initialized
DEBUG - 2011-07-26 20:04:04 --> Loader Class Initialized
DEBUG - 2011-07-26 20:04:04 --> Controller Class Initialized
ERROR - 2011-07-26 20:04:04 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-26 20:04:04 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-26 20:04:04 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-26 20:04:04 --> Model Class Initialized
DEBUG - 2011-07-26 20:04:04 --> Model Class Initialized
DEBUG - 2011-07-26 20:04:04 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-26 20:04:04 --> Database Driver Class Initialized
DEBUG - 2011-07-26 20:04:04 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-26 20:04:04 --> Helper loaded: url_helper
DEBUG - 2011-07-26 20:04:04 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-26 20:04:04 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-26 20:04:04 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-26 20:04:04 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-26 20:04:04 --> Final output sent to browser
DEBUG - 2011-07-26 20:04:04 --> Total execution time: 0.0278
DEBUG - 2011-07-26 20:04:05 --> Config Class Initialized
DEBUG - 2011-07-26 20:04:05 --> Hooks Class Initialized
DEBUG - 2011-07-26 20:04:05 --> Utf8 Class Initialized
DEBUG - 2011-07-26 20:04:05 --> UTF-8 Support Enabled
DEBUG - 2011-07-26 20:04:05 --> URI Class Initialized
DEBUG - 2011-07-26 20:04:05 --> Router Class Initialized
DEBUG - 2011-07-26 20:04:05 --> Output Class Initialized
DEBUG - 2011-07-26 20:04:05 --> Input Class Initialized
DEBUG - 2011-07-26 20:04:05 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-26 20:04:05 --> Language Class Initialized
DEBUG - 2011-07-26 20:04:05 --> Loader Class Initialized
DEBUG - 2011-07-26 20:04:05 --> Controller Class Initialized
DEBUG - 2011-07-26 20:04:05 --> Model Class Initialized
DEBUG - 2011-07-26 20:04:05 --> Model Class Initialized
DEBUG - 2011-07-26 20:04:05 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-26 20:04:05 --> Database Driver Class Initialized
DEBUG - 2011-07-26 20:04:06 --> Final output sent to browser
DEBUG - 2011-07-26 20:04:06 --> Total execution time: 0.6432
DEBUG - 2011-07-26 20:04:18 --> Config Class Initialized
DEBUG - 2011-07-26 20:04:18 --> Hooks Class Initialized
DEBUG - 2011-07-26 20:04:18 --> Utf8 Class Initialized
DEBUG - 2011-07-26 20:04:18 --> UTF-8 Support Enabled
DEBUG - 2011-07-26 20:04:18 --> URI Class Initialized
DEBUG - 2011-07-26 20:04:18 --> Router Class Initialized
DEBUG - 2011-07-26 20:04:18 --> Output Class Initialized
DEBUG - 2011-07-26 20:04:18 --> Input Class Initialized
DEBUG - 2011-07-26 20:04:18 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-26 20:04:18 --> Language Class Initialized
DEBUG - 2011-07-26 20:04:18 --> Loader Class Initialized
DEBUG - 2011-07-26 20:04:18 --> Controller Class Initialized
ERROR - 2011-07-26 20:04:18 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-26 20:04:18 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-26 20:04:18 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-26 20:04:18 --> Model Class Initialized
DEBUG - 2011-07-26 20:04:18 --> Model Class Initialized
DEBUG - 2011-07-26 20:04:18 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-26 20:04:18 --> Database Driver Class Initialized
DEBUG - 2011-07-26 20:04:18 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-26 20:04:18 --> Helper loaded: url_helper
DEBUG - 2011-07-26 20:04:18 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-26 20:04:18 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-26 20:04:18 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-26 20:04:18 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-26 20:04:18 --> Final output sent to browser
DEBUG - 2011-07-26 20:04:18 --> Total execution time: 0.0316
DEBUG - 2011-07-26 20:04:18 --> Config Class Initialized
DEBUG - 2011-07-26 20:04:18 --> Hooks Class Initialized
DEBUG - 2011-07-26 20:04:18 --> Utf8 Class Initialized
DEBUG - 2011-07-26 20:04:18 --> UTF-8 Support Enabled
DEBUG - 2011-07-26 20:04:18 --> URI Class Initialized
DEBUG - 2011-07-26 20:04:18 --> Router Class Initialized
DEBUG - 2011-07-26 20:04:18 --> Output Class Initialized
DEBUG - 2011-07-26 20:04:18 --> Input Class Initialized
DEBUG - 2011-07-26 20:04:18 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-26 20:04:18 --> Language Class Initialized
DEBUG - 2011-07-26 20:04:18 --> Loader Class Initialized
DEBUG - 2011-07-26 20:04:18 --> Controller Class Initialized
DEBUG - 2011-07-26 20:04:18 --> Model Class Initialized
DEBUG - 2011-07-26 20:04:18 --> Model Class Initialized
DEBUG - 2011-07-26 20:04:18 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-26 20:04:18 --> Database Driver Class Initialized
DEBUG - 2011-07-26 20:04:19 --> Final output sent to browser
DEBUG - 2011-07-26 20:04:19 --> Total execution time: 0.4950
DEBUG - 2011-07-26 20:05:14 --> Config Class Initialized
DEBUG - 2011-07-26 20:05:14 --> Hooks Class Initialized
DEBUG - 2011-07-26 20:05:14 --> Utf8 Class Initialized
DEBUG - 2011-07-26 20:05:14 --> UTF-8 Support Enabled
DEBUG - 2011-07-26 20:05:14 --> URI Class Initialized
DEBUG - 2011-07-26 20:05:14 --> Router Class Initialized
ERROR - 2011-07-26 20:05:14 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-07-26 20:05:14 --> Config Class Initialized
DEBUG - 2011-07-26 20:05:14 --> Hooks Class Initialized
DEBUG - 2011-07-26 20:05:14 --> Utf8 Class Initialized
DEBUG - 2011-07-26 20:05:14 --> UTF-8 Support Enabled
DEBUG - 2011-07-26 20:05:14 --> URI Class Initialized
DEBUG - 2011-07-26 20:05:14 --> Router Class Initialized
DEBUG - 2011-07-26 20:05:14 --> Output Class Initialized
DEBUG - 2011-07-26 20:05:14 --> Input Class Initialized
DEBUG - 2011-07-26 20:05:14 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-26 20:05:14 --> Language Class Initialized
DEBUG - 2011-07-26 20:05:14 --> Loader Class Initialized
DEBUG - 2011-07-26 20:05:14 --> Controller Class Initialized
ERROR - 2011-07-26 20:05:14 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-26 20:05:14 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-26 20:05:14 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-26 20:05:14 --> Model Class Initialized
DEBUG - 2011-07-26 20:05:14 --> Model Class Initialized
DEBUG - 2011-07-26 20:05:14 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-26 20:05:14 --> Database Driver Class Initialized
DEBUG - 2011-07-26 20:05:14 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-26 20:05:14 --> Helper loaded: url_helper
DEBUG - 2011-07-26 20:05:14 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-26 20:05:14 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-26 20:05:14 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-26 20:05:14 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-26 20:05:14 --> Final output sent to browser
DEBUG - 2011-07-26 20:05:14 --> Total execution time: 0.0313
DEBUG - 2011-07-26 22:09:33 --> Config Class Initialized
DEBUG - 2011-07-26 22:09:33 --> Hooks Class Initialized
DEBUG - 2011-07-26 22:09:33 --> Utf8 Class Initialized
DEBUG - 2011-07-26 22:09:33 --> UTF-8 Support Enabled
DEBUG - 2011-07-26 22:09:33 --> URI Class Initialized
DEBUG - 2011-07-26 22:09:33 --> Router Class Initialized
DEBUG - 2011-07-26 22:09:33 --> Output Class Initialized
DEBUG - 2011-07-26 22:09:33 --> Input Class Initialized
DEBUG - 2011-07-26 22:09:33 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-26 22:09:33 --> Language Class Initialized
DEBUG - 2011-07-26 22:09:33 --> Loader Class Initialized
DEBUG - 2011-07-26 22:09:33 --> Controller Class Initialized
ERROR - 2011-07-26 22:09:33 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-26 22:09:33 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-26 22:09:33 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-26 22:09:33 --> Model Class Initialized
DEBUG - 2011-07-26 22:09:33 --> Model Class Initialized
DEBUG - 2011-07-26 22:09:33 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-26 22:09:33 --> Database Driver Class Initialized
DEBUG - 2011-07-26 22:09:33 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-26 22:09:33 --> Helper loaded: url_helper
DEBUG - 2011-07-26 22:09:33 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-26 22:09:33 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-26 22:09:33 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-26 22:09:33 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-26 22:09:33 --> Final output sent to browser
DEBUG - 2011-07-26 22:09:33 --> Total execution time: 0.0468
DEBUG - 2011-07-26 23:49:23 --> Config Class Initialized
DEBUG - 2011-07-26 23:49:23 --> Hooks Class Initialized
DEBUG - 2011-07-26 23:49:23 --> Utf8 Class Initialized
DEBUG - 2011-07-26 23:49:23 --> UTF-8 Support Enabled
DEBUG - 2011-07-26 23:49:23 --> URI Class Initialized
DEBUG - 2011-07-26 23:49:23 --> Router Class Initialized
DEBUG - 2011-07-26 23:49:23 --> Output Class Initialized
DEBUG - 2011-07-26 23:49:23 --> Input Class Initialized
DEBUG - 2011-07-26 23:49:23 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-26 23:49:23 --> Language Class Initialized
DEBUG - 2011-07-26 23:49:23 --> Loader Class Initialized
DEBUG - 2011-07-26 23:49:23 --> Controller Class Initialized
DEBUG - 2011-07-26 23:49:23 --> Model Class Initialized
DEBUG - 2011-07-26 23:49:23 --> Model Class Initialized
DEBUG - 2011-07-26 23:49:23 --> Model Class Initialized
DEBUG - 2011-07-26 23:49:23 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-26 23:49:23 --> Database Driver Class Initialized
DEBUG - 2011-07-26 23:49:25 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-26 23:49:25 --> Helper loaded: url_helper
DEBUG - 2011-07-26 23:49:25 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-26 23:49:25 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-26 23:49:25 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-26 23:49:25 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-26 23:49:25 --> Final output sent to browser
DEBUG - 2011-07-26 23:49:25 --> Total execution time: 1.4303
DEBUG - 2011-07-26 23:50:14 --> Config Class Initialized
DEBUG - 2011-07-26 23:50:14 --> Hooks Class Initialized
DEBUG - 2011-07-26 23:50:14 --> Utf8 Class Initialized
DEBUG - 2011-07-26 23:50:14 --> UTF-8 Support Enabled
DEBUG - 2011-07-26 23:50:14 --> URI Class Initialized
DEBUG - 2011-07-26 23:50:14 --> Router Class Initialized
DEBUG - 2011-07-26 23:50:14 --> Output Class Initialized
DEBUG - 2011-07-26 23:50:14 --> Input Class Initialized
DEBUG - 2011-07-26 23:50:14 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-26 23:50:14 --> Language Class Initialized
DEBUG - 2011-07-26 23:50:14 --> Loader Class Initialized
DEBUG - 2011-07-26 23:50:14 --> Controller Class Initialized
DEBUG - 2011-07-26 23:50:14 --> Model Class Initialized
DEBUG - 2011-07-26 23:50:14 --> Model Class Initialized
DEBUG - 2011-07-26 23:50:14 --> Model Class Initialized
DEBUG - 2011-07-26 23:50:14 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-26 23:50:14 --> Database Driver Class Initialized
DEBUG - 2011-07-26 23:50:15 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-26 23:50:15 --> Helper loaded: url_helper
DEBUG - 2011-07-26 23:50:15 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-26 23:50:15 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-26 23:50:15 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-26 23:50:15 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-26 23:50:15 --> Final output sent to browser
DEBUG - 2011-07-26 23:50:15 --> Total execution time: 0.3410
DEBUG - 2011-07-26 23:50:25 --> Config Class Initialized
DEBUG - 2011-07-26 23:50:25 --> Hooks Class Initialized
DEBUG - 2011-07-26 23:50:25 --> Utf8 Class Initialized
DEBUG - 2011-07-26 23:50:25 --> UTF-8 Support Enabled
DEBUG - 2011-07-26 23:50:25 --> URI Class Initialized
DEBUG - 2011-07-26 23:50:25 --> Router Class Initialized
DEBUG - 2011-07-26 23:50:25 --> Output Class Initialized
DEBUG - 2011-07-26 23:50:25 --> Input Class Initialized
DEBUG - 2011-07-26 23:50:25 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-26 23:50:25 --> Language Class Initialized
DEBUG - 2011-07-26 23:50:25 --> Loader Class Initialized
DEBUG - 2011-07-26 23:50:25 --> Controller Class Initialized
DEBUG - 2011-07-26 23:50:25 --> Model Class Initialized
DEBUG - 2011-07-26 23:50:25 --> Model Class Initialized
DEBUG - 2011-07-26 23:50:25 --> Model Class Initialized
DEBUG - 2011-07-26 23:50:25 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-26 23:50:25 --> Database Driver Class Initialized
DEBUG - 2011-07-26 23:50:25 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-26 23:50:25 --> Helper loaded: url_helper
DEBUG - 2011-07-26 23:50:25 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-26 23:50:25 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-26 23:50:25 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-26 23:50:25 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-26 23:50:25 --> Final output sent to browser
DEBUG - 2011-07-26 23:50:25 --> Total execution time: 0.0455
DEBUG - 2011-07-26 23:50:41 --> Config Class Initialized
DEBUG - 2011-07-26 23:50:41 --> Hooks Class Initialized
DEBUG - 2011-07-26 23:50:41 --> Utf8 Class Initialized
DEBUG - 2011-07-26 23:50:41 --> UTF-8 Support Enabled
DEBUG - 2011-07-26 23:50:41 --> URI Class Initialized
DEBUG - 2011-07-26 23:50:41 --> Router Class Initialized
DEBUG - 2011-07-26 23:50:41 --> Output Class Initialized
DEBUG - 2011-07-26 23:50:41 --> Input Class Initialized
DEBUG - 2011-07-26 23:50:41 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-26 23:50:41 --> Language Class Initialized
DEBUG - 2011-07-26 23:50:41 --> Loader Class Initialized
DEBUG - 2011-07-26 23:50:41 --> Controller Class Initialized
ERROR - 2011-07-26 23:50:41 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-26 23:50:41 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-26 23:50:41 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-26 23:50:41 --> Model Class Initialized
DEBUG - 2011-07-26 23:50:41 --> Model Class Initialized
DEBUG - 2011-07-26 23:50:41 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-26 23:50:41 --> Database Driver Class Initialized
DEBUG - 2011-07-26 23:50:41 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-26 23:50:41 --> Helper loaded: url_helper
DEBUG - 2011-07-26 23:50:41 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-26 23:50:41 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-26 23:50:41 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-26 23:50:41 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-26 23:50:41 --> Final output sent to browser
DEBUG - 2011-07-26 23:50:41 --> Total execution time: 0.0408
DEBUG - 2011-07-26 23:50:41 --> Config Class Initialized
DEBUG - 2011-07-26 23:50:41 --> Hooks Class Initialized
DEBUG - 2011-07-26 23:50:41 --> Utf8 Class Initialized
DEBUG - 2011-07-26 23:50:41 --> UTF-8 Support Enabled
DEBUG - 2011-07-26 23:50:41 --> URI Class Initialized
DEBUG - 2011-07-26 23:50:41 --> Router Class Initialized
DEBUG - 2011-07-26 23:50:41 --> Output Class Initialized
DEBUG - 2011-07-26 23:50:41 --> Input Class Initialized
DEBUG - 2011-07-26 23:50:41 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-26 23:50:41 --> Language Class Initialized
DEBUG - 2011-07-26 23:50:41 --> Loader Class Initialized
DEBUG - 2011-07-26 23:50:41 --> Controller Class Initialized
DEBUG - 2011-07-26 23:50:41 --> Model Class Initialized
DEBUG - 2011-07-26 23:50:41 --> Model Class Initialized
DEBUG - 2011-07-26 23:50:41 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-26 23:50:41 --> Database Driver Class Initialized
DEBUG - 2011-07-26 23:50:42 --> Final output sent to browser
DEBUG - 2011-07-26 23:50:42 --> Total execution time: 0.5416

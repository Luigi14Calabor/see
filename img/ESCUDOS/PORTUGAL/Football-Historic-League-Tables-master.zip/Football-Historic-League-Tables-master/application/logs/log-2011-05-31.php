<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2011-05-31 00:08:33 --> Config Class Initialized
DEBUG - 2011-05-31 00:08:33 --> Hooks Class Initialized
DEBUG - 2011-05-31 00:08:33 --> Utf8 Class Initialized
DEBUG - 2011-05-31 00:08:33 --> UTF-8 Support Enabled
DEBUG - 2011-05-31 00:08:33 --> URI Class Initialized
DEBUG - 2011-05-31 00:08:33 --> Router Class Initialized
DEBUG - 2011-05-31 00:08:33 --> Output Class Initialized
DEBUG - 2011-05-31 00:08:34 --> Input Class Initialized
DEBUG - 2011-05-31 00:08:34 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-31 00:08:34 --> Language Class Initialized
DEBUG - 2011-05-31 00:08:34 --> Loader Class Initialized
DEBUG - 2011-05-31 00:08:34 --> Controller Class Initialized
ERROR - 2011-05-31 00:08:35 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-31 00:08:35 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-31 00:08:35 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-31 00:08:35 --> Model Class Initialized
DEBUG - 2011-05-31 00:08:35 --> Model Class Initialized
DEBUG - 2011-05-31 00:08:35 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-31 00:08:36 --> Database Driver Class Initialized
DEBUG - 2011-05-31 00:08:37 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-31 00:08:37 --> Helper loaded: url_helper
DEBUG - 2011-05-31 00:08:37 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-31 00:08:37 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-31 00:08:37 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-31 00:08:37 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-31 00:08:37 --> Final output sent to browser
DEBUG - 2011-05-31 00:08:37 --> Total execution time: 4.5591
DEBUG - 2011-05-31 01:25:01 --> Config Class Initialized
DEBUG - 2011-05-31 01:25:01 --> Hooks Class Initialized
DEBUG - 2011-05-31 01:25:01 --> Utf8 Class Initialized
DEBUG - 2011-05-31 01:25:01 --> UTF-8 Support Enabled
DEBUG - 2011-05-31 01:25:01 --> URI Class Initialized
DEBUG - 2011-05-31 01:25:01 --> Router Class Initialized
ERROR - 2011-05-31 01:25:01 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-05-31 01:25:02 --> Config Class Initialized
DEBUG - 2011-05-31 01:25:02 --> Hooks Class Initialized
DEBUG - 2011-05-31 01:25:02 --> Utf8 Class Initialized
DEBUG - 2011-05-31 01:25:02 --> UTF-8 Support Enabled
DEBUG - 2011-05-31 01:25:02 --> URI Class Initialized
DEBUG - 2011-05-31 01:25:02 --> Router Class Initialized
DEBUG - 2011-05-31 01:25:02 --> Output Class Initialized
DEBUG - 2011-05-31 01:25:02 --> Input Class Initialized
DEBUG - 2011-05-31 01:25:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-31 01:25:02 --> Language Class Initialized
DEBUG - 2011-05-31 01:25:02 --> Loader Class Initialized
DEBUG - 2011-05-31 01:25:02 --> Controller Class Initialized
DEBUG - 2011-05-31 01:25:02 --> Model Class Initialized
DEBUG - 2011-05-31 01:25:02 --> Model Class Initialized
DEBUG - 2011-05-31 01:25:02 --> Model Class Initialized
DEBUG - 2011-05-31 01:25:02 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-31 01:25:03 --> Database Driver Class Initialized
DEBUG - 2011-05-31 01:25:04 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-31 01:25:04 --> Helper loaded: url_helper
DEBUG - 2011-05-31 01:25:04 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-31 01:25:04 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-31 01:25:04 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-31 01:25:04 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-31 01:25:04 --> Final output sent to browser
DEBUG - 2011-05-31 01:25:04 --> Total execution time: 1.7271
DEBUG - 2011-05-31 01:25:34 --> Config Class Initialized
DEBUG - 2011-05-31 01:25:34 --> Hooks Class Initialized
DEBUG - 2011-05-31 01:25:34 --> Utf8 Class Initialized
DEBUG - 2011-05-31 01:25:34 --> UTF-8 Support Enabled
DEBUG - 2011-05-31 01:25:34 --> URI Class Initialized
DEBUG - 2011-05-31 01:25:34 --> Router Class Initialized
DEBUG - 2011-05-31 01:25:34 --> Output Class Initialized
DEBUG - 2011-05-31 01:25:34 --> Input Class Initialized
DEBUG - 2011-05-31 01:25:34 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-31 01:25:34 --> Language Class Initialized
DEBUG - 2011-05-31 01:25:34 --> Loader Class Initialized
DEBUG - 2011-05-31 01:25:34 --> Controller Class Initialized
ERROR - 2011-05-31 01:25:34 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-31 01:25:34 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-31 01:25:34 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-31 01:25:34 --> Model Class Initialized
DEBUG - 2011-05-31 01:25:34 --> Model Class Initialized
DEBUG - 2011-05-31 01:25:34 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-31 01:25:34 --> Database Driver Class Initialized
DEBUG - 2011-05-31 01:25:34 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-31 01:25:34 --> Helper loaded: url_helper
DEBUG - 2011-05-31 01:25:34 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-31 01:25:34 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-31 01:25:34 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-31 01:25:34 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-31 01:25:34 --> Final output sent to browser
DEBUG - 2011-05-31 01:25:34 --> Total execution time: 0.0896
DEBUG - 2011-05-31 03:21:30 --> Config Class Initialized
DEBUG - 2011-05-31 03:21:30 --> Hooks Class Initialized
DEBUG - 2011-05-31 03:21:30 --> Utf8 Class Initialized
DEBUG - 2011-05-31 03:21:30 --> UTF-8 Support Enabled
DEBUG - 2011-05-31 03:21:30 --> URI Class Initialized
DEBUG - 2011-05-31 03:21:30 --> Router Class Initialized
DEBUG - 2011-05-31 03:21:30 --> No URI present. Default controller set.
DEBUG - 2011-05-31 03:21:30 --> Output Class Initialized
DEBUG - 2011-05-31 03:21:30 --> Input Class Initialized
DEBUG - 2011-05-31 03:21:30 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-31 03:21:30 --> Language Class Initialized
DEBUG - 2011-05-31 03:21:30 --> Loader Class Initialized
DEBUG - 2011-05-31 03:21:30 --> Controller Class Initialized
DEBUG - 2011-05-31 03:21:30 --> File loaded: application/views/splash/main.php
DEBUG - 2011-05-31 03:21:30 --> Helper loaded: url_helper
DEBUG - 2011-05-31 03:21:30 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-31 03:21:30 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-31 03:21:30 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-31 03:21:30 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-31 03:21:30 --> Final output sent to browser
DEBUG - 2011-05-31 03:21:30 --> Total execution time: 0.3070
DEBUG - 2011-05-31 03:24:05 --> Config Class Initialized
DEBUG - 2011-05-31 03:24:05 --> Hooks Class Initialized
DEBUG - 2011-05-31 03:24:05 --> Utf8 Class Initialized
DEBUG - 2011-05-31 03:24:05 --> UTF-8 Support Enabled
DEBUG - 2011-05-31 03:24:05 --> URI Class Initialized
DEBUG - 2011-05-31 03:24:05 --> Router Class Initialized
DEBUG - 2011-05-31 03:24:05 --> Output Class Initialized
DEBUG - 2011-05-31 03:24:05 --> Input Class Initialized
DEBUG - 2011-05-31 03:24:05 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-31 03:24:05 --> Language Class Initialized
DEBUG - 2011-05-31 03:24:05 --> Loader Class Initialized
DEBUG - 2011-05-31 03:24:05 --> Controller Class Initialized
DEBUG - 2011-05-31 03:24:05 --> Model Class Initialized
DEBUG - 2011-05-31 03:24:05 --> Model Class Initialized
DEBUG - 2011-05-31 03:24:05 --> Model Class Initialized
DEBUG - 2011-05-31 03:24:05 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-31 03:24:05 --> Database Driver Class Initialized
DEBUG - 2011-05-31 03:24:10 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-31 03:24:10 --> Helper loaded: url_helper
DEBUG - 2011-05-31 03:24:10 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-31 03:24:10 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-31 03:24:10 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-31 03:24:10 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-31 03:24:10 --> Final output sent to browser
DEBUG - 2011-05-31 03:24:10 --> Total execution time: 4.9153
DEBUG - 2011-05-31 03:24:14 --> Config Class Initialized
DEBUG - 2011-05-31 03:24:14 --> Hooks Class Initialized
DEBUG - 2011-05-31 03:24:14 --> Utf8 Class Initialized
DEBUG - 2011-05-31 03:24:14 --> UTF-8 Support Enabled
DEBUG - 2011-05-31 03:24:14 --> URI Class Initialized
DEBUG - 2011-05-31 03:24:14 --> Router Class Initialized
ERROR - 2011-05-31 03:24:14 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-31 03:24:15 --> Config Class Initialized
DEBUG - 2011-05-31 03:24:15 --> Hooks Class Initialized
DEBUG - 2011-05-31 03:24:15 --> Utf8 Class Initialized
DEBUG - 2011-05-31 03:24:15 --> UTF-8 Support Enabled
DEBUG - 2011-05-31 03:24:15 --> URI Class Initialized
DEBUG - 2011-05-31 03:24:15 --> Router Class Initialized
ERROR - 2011-05-31 03:24:15 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-31 03:24:16 --> Config Class Initialized
DEBUG - 2011-05-31 03:24:16 --> Hooks Class Initialized
DEBUG - 2011-05-31 03:24:16 --> Utf8 Class Initialized
DEBUG - 2011-05-31 03:24:16 --> UTF-8 Support Enabled
DEBUG - 2011-05-31 03:24:16 --> URI Class Initialized
DEBUG - 2011-05-31 03:24:16 --> Router Class Initialized
ERROR - 2011-05-31 03:24:16 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-31 05:42:07 --> Config Class Initialized
DEBUG - 2011-05-31 05:42:08 --> Hooks Class Initialized
DEBUG - 2011-05-31 05:42:08 --> Utf8 Class Initialized
DEBUG - 2011-05-31 05:42:08 --> UTF-8 Support Enabled
DEBUG - 2011-05-31 05:42:08 --> URI Class Initialized
DEBUG - 2011-05-31 05:42:08 --> Router Class Initialized
DEBUG - 2011-05-31 05:42:08 --> Output Class Initialized
DEBUG - 2011-05-31 05:42:08 --> Input Class Initialized
DEBUG - 2011-05-31 05:42:08 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-31 05:42:08 --> Language Class Initialized
DEBUG - 2011-05-31 05:42:08 --> Loader Class Initialized
DEBUG - 2011-05-31 05:42:08 --> Controller Class Initialized
DEBUG - 2011-05-31 05:42:08 --> Model Class Initialized
DEBUG - 2011-05-31 05:42:08 --> Model Class Initialized
DEBUG - 2011-05-31 05:42:08 --> Model Class Initialized
DEBUG - 2011-05-31 05:42:08 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-31 05:42:08 --> Database Driver Class Initialized
DEBUG - 2011-05-31 05:42:10 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-31 05:42:10 --> Helper loaded: url_helper
DEBUG - 2011-05-31 05:42:10 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-31 05:42:10 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-31 05:42:10 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-31 05:42:10 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-31 05:42:10 --> Final output sent to browser
DEBUG - 2011-05-31 05:42:10 --> Total execution time: 2.2031
DEBUG - 2011-05-31 05:42:18 --> Config Class Initialized
DEBUG - 2011-05-31 05:42:18 --> Hooks Class Initialized
DEBUG - 2011-05-31 05:42:18 --> Utf8 Class Initialized
DEBUG - 2011-05-31 05:42:18 --> UTF-8 Support Enabled
DEBUG - 2011-05-31 05:42:18 --> URI Class Initialized
DEBUG - 2011-05-31 05:42:18 --> Router Class Initialized
DEBUG - 2011-05-31 05:42:18 --> Output Class Initialized
DEBUG - 2011-05-31 05:42:18 --> Input Class Initialized
DEBUG - 2011-05-31 05:42:18 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-31 05:42:18 --> Language Class Initialized
DEBUG - 2011-05-31 05:42:18 --> Loader Class Initialized
DEBUG - 2011-05-31 05:42:18 --> Controller Class Initialized
DEBUG - 2011-05-31 05:42:18 --> Model Class Initialized
DEBUG - 2011-05-31 05:42:18 --> Model Class Initialized
DEBUG - 2011-05-31 05:42:18 --> Model Class Initialized
DEBUG - 2011-05-31 05:42:18 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-31 05:42:18 --> Database Driver Class Initialized
DEBUG - 2011-05-31 05:42:19 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-31 05:42:19 --> Helper loaded: url_helper
DEBUG - 2011-05-31 05:42:19 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-31 05:42:19 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-31 05:42:19 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-31 05:42:19 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-31 05:42:19 --> Final output sent to browser
DEBUG - 2011-05-31 05:42:19 --> Total execution time: 0.7444
DEBUG - 2011-05-31 05:42:33 --> Config Class Initialized
DEBUG - 2011-05-31 05:42:33 --> Hooks Class Initialized
DEBUG - 2011-05-31 05:42:33 --> Utf8 Class Initialized
DEBUG - 2011-05-31 05:42:33 --> UTF-8 Support Enabled
DEBUG - 2011-05-31 05:42:33 --> URI Class Initialized
DEBUG - 2011-05-31 05:42:33 --> Router Class Initialized
DEBUG - 2011-05-31 05:42:33 --> Output Class Initialized
DEBUG - 2011-05-31 05:42:33 --> Input Class Initialized
DEBUG - 2011-05-31 05:42:33 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-31 05:42:33 --> Language Class Initialized
DEBUG - 2011-05-31 05:42:33 --> Loader Class Initialized
DEBUG - 2011-05-31 05:42:33 --> Controller Class Initialized
DEBUG - 2011-05-31 05:42:33 --> Model Class Initialized
DEBUG - 2011-05-31 05:42:33 --> Model Class Initialized
DEBUG - 2011-05-31 05:42:33 --> Model Class Initialized
DEBUG - 2011-05-31 05:42:33 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-31 05:42:33 --> Database Driver Class Initialized
DEBUG - 2011-05-31 05:42:36 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-31 05:42:36 --> Helper loaded: url_helper
DEBUG - 2011-05-31 05:42:36 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-31 05:42:36 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-31 05:42:36 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-31 05:42:36 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-31 05:42:36 --> Final output sent to browser
DEBUG - 2011-05-31 05:42:36 --> Total execution time: 2.4863
DEBUG - 2011-05-31 05:42:56 --> Config Class Initialized
DEBUG - 2011-05-31 05:42:56 --> Hooks Class Initialized
DEBUG - 2011-05-31 05:42:56 --> Utf8 Class Initialized
DEBUG - 2011-05-31 05:42:56 --> UTF-8 Support Enabled
DEBUG - 2011-05-31 05:42:56 --> URI Class Initialized
DEBUG - 2011-05-31 05:42:56 --> Router Class Initialized
DEBUG - 2011-05-31 05:42:56 --> Output Class Initialized
DEBUG - 2011-05-31 05:42:56 --> Input Class Initialized
DEBUG - 2011-05-31 05:42:56 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-31 05:42:56 --> Language Class Initialized
DEBUG - 2011-05-31 05:42:56 --> Loader Class Initialized
DEBUG - 2011-05-31 05:42:56 --> Controller Class Initialized
DEBUG - 2011-05-31 05:42:56 --> Model Class Initialized
DEBUG - 2011-05-31 05:42:56 --> Model Class Initialized
DEBUG - 2011-05-31 05:42:56 --> Model Class Initialized
DEBUG - 2011-05-31 05:42:56 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-31 05:42:56 --> Database Driver Class Initialized
DEBUG - 2011-05-31 05:42:57 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-31 05:42:57 --> Helper loaded: url_helper
DEBUG - 2011-05-31 05:42:57 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-31 05:42:57 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-31 05:42:57 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-31 05:42:57 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-31 05:42:57 --> Final output sent to browser
DEBUG - 2011-05-31 05:42:57 --> Total execution time: 0.3969
DEBUG - 2011-05-31 05:44:28 --> Config Class Initialized
DEBUG - 2011-05-31 05:44:28 --> Hooks Class Initialized
DEBUG - 2011-05-31 05:44:28 --> Utf8 Class Initialized
DEBUG - 2011-05-31 05:44:28 --> UTF-8 Support Enabled
DEBUG - 2011-05-31 05:44:28 --> URI Class Initialized
DEBUG - 2011-05-31 05:44:28 --> Router Class Initialized
ERROR - 2011-05-31 05:44:28 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-05-31 05:44:28 --> Config Class Initialized
DEBUG - 2011-05-31 05:44:28 --> Hooks Class Initialized
DEBUG - 2011-05-31 05:44:28 --> Utf8 Class Initialized
DEBUG - 2011-05-31 05:44:28 --> UTF-8 Support Enabled
DEBUG - 2011-05-31 05:44:28 --> URI Class Initialized
DEBUG - 2011-05-31 05:44:28 --> Router Class Initialized
DEBUG - 2011-05-31 05:44:28 --> Output Class Initialized
DEBUG - 2011-05-31 05:44:28 --> Input Class Initialized
DEBUG - 2011-05-31 05:44:28 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-31 05:44:28 --> Language Class Initialized
DEBUG - 2011-05-31 05:44:28 --> Loader Class Initialized
DEBUG - 2011-05-31 05:44:28 --> Controller Class Initialized
DEBUG - 2011-05-31 05:44:28 --> Model Class Initialized
DEBUG - 2011-05-31 05:44:28 --> Model Class Initialized
DEBUG - 2011-05-31 05:44:28 --> Model Class Initialized
DEBUG - 2011-05-31 05:44:28 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-31 05:44:28 --> Database Driver Class Initialized
DEBUG - 2011-05-31 05:44:28 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-31 05:44:28 --> Helper loaded: url_helper
DEBUG - 2011-05-31 05:44:28 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-31 05:44:28 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-31 05:44:28 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-31 05:44:28 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-31 05:44:28 --> Final output sent to browser
DEBUG - 2011-05-31 05:44:28 --> Total execution time: 0.0550
DEBUG - 2011-05-31 05:44:29 --> Config Class Initialized
DEBUG - 2011-05-31 05:44:29 --> Hooks Class Initialized
DEBUG - 2011-05-31 05:44:29 --> Utf8 Class Initialized
DEBUG - 2011-05-31 05:44:29 --> UTF-8 Support Enabled
DEBUG - 2011-05-31 05:44:29 --> URI Class Initialized
DEBUG - 2011-05-31 05:44:29 --> Router Class Initialized
DEBUG - 2011-05-31 05:44:29 --> Output Class Initialized
DEBUG - 2011-05-31 05:44:29 --> Input Class Initialized
DEBUG - 2011-05-31 05:44:29 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-31 05:44:29 --> Language Class Initialized
DEBUG - 2011-05-31 05:44:29 --> Loader Class Initialized
DEBUG - 2011-05-31 05:44:29 --> Controller Class Initialized
DEBUG - 2011-05-31 05:44:29 --> Model Class Initialized
DEBUG - 2011-05-31 05:44:29 --> Model Class Initialized
DEBUG - 2011-05-31 05:44:29 --> Model Class Initialized
DEBUG - 2011-05-31 05:44:29 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-31 05:44:29 --> Database Driver Class Initialized
DEBUG - 2011-05-31 05:44:29 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-31 05:44:29 --> Helper loaded: url_helper
DEBUG - 2011-05-31 05:44:29 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-31 05:44:29 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-31 05:44:29 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-31 05:44:29 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-31 05:44:29 --> Final output sent to browser
DEBUG - 2011-05-31 05:44:29 --> Total execution time: 0.0471
DEBUG - 2011-05-31 05:44:30 --> Config Class Initialized
DEBUG - 2011-05-31 05:44:30 --> Hooks Class Initialized
DEBUG - 2011-05-31 05:44:30 --> Utf8 Class Initialized
DEBUG - 2011-05-31 05:44:30 --> UTF-8 Support Enabled
DEBUG - 2011-05-31 05:44:30 --> URI Class Initialized
DEBUG - 2011-05-31 05:44:30 --> Router Class Initialized
DEBUG - 2011-05-31 05:44:30 --> Output Class Initialized
DEBUG - 2011-05-31 05:44:30 --> Input Class Initialized
DEBUG - 2011-05-31 05:44:30 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-31 05:44:30 --> Language Class Initialized
DEBUG - 2011-05-31 05:44:30 --> Loader Class Initialized
DEBUG - 2011-05-31 05:44:30 --> Controller Class Initialized
DEBUG - 2011-05-31 05:44:30 --> Model Class Initialized
DEBUG - 2011-05-31 05:44:30 --> Model Class Initialized
DEBUG - 2011-05-31 05:44:30 --> Model Class Initialized
DEBUG - 2011-05-31 05:44:30 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-31 05:44:30 --> Database Driver Class Initialized
DEBUG - 2011-05-31 05:44:30 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-31 05:44:30 --> Helper loaded: url_helper
DEBUG - 2011-05-31 05:44:30 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-31 05:44:30 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-31 05:44:30 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-31 05:44:30 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-31 05:44:30 --> Final output sent to browser
DEBUG - 2011-05-31 05:44:30 --> Total execution time: 0.0493
DEBUG - 2011-05-31 05:45:02 --> Config Class Initialized
DEBUG - 2011-05-31 05:45:02 --> Hooks Class Initialized
DEBUG - 2011-05-31 05:45:02 --> Utf8 Class Initialized
DEBUG - 2011-05-31 05:45:02 --> UTF-8 Support Enabled
DEBUG - 2011-05-31 05:45:02 --> URI Class Initialized
DEBUG - 2011-05-31 05:45:02 --> Router Class Initialized
DEBUG - 2011-05-31 05:45:02 --> Output Class Initialized
DEBUG - 2011-05-31 05:45:02 --> Input Class Initialized
DEBUG - 2011-05-31 05:45:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-31 05:45:02 --> Language Class Initialized
DEBUG - 2011-05-31 05:45:02 --> Loader Class Initialized
DEBUG - 2011-05-31 05:45:02 --> Controller Class Initialized
DEBUG - 2011-05-31 05:45:02 --> Model Class Initialized
DEBUG - 2011-05-31 05:45:02 --> Model Class Initialized
DEBUG - 2011-05-31 05:45:02 --> Model Class Initialized
DEBUG - 2011-05-31 05:45:02 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-31 05:45:02 --> Database Driver Class Initialized
DEBUG - 2011-05-31 05:45:03 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-31 05:45:03 --> Helper loaded: url_helper
DEBUG - 2011-05-31 05:45:03 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-31 05:45:03 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-31 05:45:03 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-31 05:45:03 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-31 05:45:03 --> Final output sent to browser
DEBUG - 2011-05-31 05:45:03 --> Total execution time: 1.3439
DEBUG - 2011-05-31 05:45:08 --> Config Class Initialized
DEBUG - 2011-05-31 05:45:08 --> Hooks Class Initialized
DEBUG - 2011-05-31 05:45:08 --> Utf8 Class Initialized
DEBUG - 2011-05-31 05:45:08 --> UTF-8 Support Enabled
DEBUG - 2011-05-31 05:45:08 --> URI Class Initialized
DEBUG - 2011-05-31 05:45:08 --> Router Class Initialized
DEBUG - 2011-05-31 05:45:08 --> Output Class Initialized
DEBUG - 2011-05-31 05:45:08 --> Input Class Initialized
DEBUG - 2011-05-31 05:45:08 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-31 05:45:08 --> Language Class Initialized
DEBUG - 2011-05-31 05:45:08 --> Loader Class Initialized
DEBUG - 2011-05-31 05:45:08 --> Controller Class Initialized
DEBUG - 2011-05-31 05:45:08 --> Model Class Initialized
DEBUG - 2011-05-31 05:45:08 --> Model Class Initialized
DEBUG - 2011-05-31 05:45:08 --> Model Class Initialized
DEBUG - 2011-05-31 05:45:08 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-31 05:45:08 --> Database Driver Class Initialized
DEBUG - 2011-05-31 05:45:08 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-31 05:45:08 --> Helper loaded: url_helper
DEBUG - 2011-05-31 05:45:08 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-31 05:45:08 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-31 05:45:08 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-31 05:45:08 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-31 05:45:08 --> Final output sent to browser
DEBUG - 2011-05-31 05:45:08 --> Total execution time: 0.1420
DEBUG - 2011-05-31 05:45:40 --> Config Class Initialized
DEBUG - 2011-05-31 05:45:40 --> Hooks Class Initialized
DEBUG - 2011-05-31 05:45:40 --> Utf8 Class Initialized
DEBUG - 2011-05-31 05:45:40 --> UTF-8 Support Enabled
DEBUG - 2011-05-31 05:45:40 --> URI Class Initialized
DEBUG - 2011-05-31 05:45:40 --> Router Class Initialized
DEBUG - 2011-05-31 05:45:40 --> Output Class Initialized
DEBUG - 2011-05-31 05:45:40 --> Input Class Initialized
DEBUG - 2011-05-31 05:45:40 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-31 05:45:40 --> Language Class Initialized
DEBUG - 2011-05-31 05:45:40 --> Loader Class Initialized
DEBUG - 2011-05-31 05:45:40 --> Controller Class Initialized
DEBUG - 2011-05-31 05:45:40 --> Model Class Initialized
DEBUG - 2011-05-31 05:45:40 --> Model Class Initialized
DEBUG - 2011-05-31 05:45:40 --> Model Class Initialized
DEBUG - 2011-05-31 05:45:40 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-31 05:45:40 --> Database Driver Class Initialized
DEBUG - 2011-05-31 05:45:41 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-31 05:45:41 --> Helper loaded: url_helper
DEBUG - 2011-05-31 05:45:41 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-31 05:45:41 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-31 05:45:41 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-31 05:45:41 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-31 05:45:41 --> Final output sent to browser
DEBUG - 2011-05-31 05:45:41 --> Total execution time: 0.3689
DEBUG - 2011-05-31 05:45:44 --> Config Class Initialized
DEBUG - 2011-05-31 05:45:44 --> Hooks Class Initialized
DEBUG - 2011-05-31 05:45:44 --> Utf8 Class Initialized
DEBUG - 2011-05-31 05:45:44 --> UTF-8 Support Enabled
DEBUG - 2011-05-31 05:45:44 --> URI Class Initialized
DEBUG - 2011-05-31 05:45:44 --> Router Class Initialized
DEBUG - 2011-05-31 05:45:44 --> Output Class Initialized
DEBUG - 2011-05-31 05:45:44 --> Input Class Initialized
DEBUG - 2011-05-31 05:45:44 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-31 05:45:44 --> Language Class Initialized
DEBUG - 2011-05-31 05:45:44 --> Loader Class Initialized
DEBUG - 2011-05-31 05:45:44 --> Controller Class Initialized
DEBUG - 2011-05-31 05:45:44 --> Model Class Initialized
DEBUG - 2011-05-31 05:45:44 --> Model Class Initialized
DEBUG - 2011-05-31 05:45:44 --> Model Class Initialized
DEBUG - 2011-05-31 05:45:44 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-31 05:45:44 --> Database Driver Class Initialized
DEBUG - 2011-05-31 05:45:44 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-31 05:45:44 --> Helper loaded: url_helper
DEBUG - 2011-05-31 05:45:44 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-31 05:45:44 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-31 05:45:44 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-31 05:45:44 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-31 05:45:44 --> Final output sent to browser
DEBUG - 2011-05-31 05:45:44 --> Total execution time: 0.0583
DEBUG - 2011-05-31 05:45:46 --> Config Class Initialized
DEBUG - 2011-05-31 05:45:46 --> Hooks Class Initialized
DEBUG - 2011-05-31 05:45:46 --> Utf8 Class Initialized
DEBUG - 2011-05-31 05:45:46 --> UTF-8 Support Enabled
DEBUG - 2011-05-31 05:45:46 --> URI Class Initialized
DEBUG - 2011-05-31 05:45:46 --> Router Class Initialized
DEBUG - 2011-05-31 05:45:46 --> Output Class Initialized
DEBUG - 2011-05-31 05:45:46 --> Input Class Initialized
DEBUG - 2011-05-31 05:45:46 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-31 05:45:46 --> Language Class Initialized
DEBUG - 2011-05-31 05:45:46 --> Loader Class Initialized
DEBUG - 2011-05-31 05:45:46 --> Controller Class Initialized
DEBUG - 2011-05-31 05:45:46 --> Model Class Initialized
DEBUG - 2011-05-31 05:45:46 --> Model Class Initialized
DEBUG - 2011-05-31 05:45:46 --> Model Class Initialized
DEBUG - 2011-05-31 05:45:46 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-31 05:45:46 --> Database Driver Class Initialized
DEBUG - 2011-05-31 05:45:46 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-31 05:45:46 --> Helper loaded: url_helper
DEBUG - 2011-05-31 05:45:46 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-31 05:45:46 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-31 05:45:46 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-31 05:45:46 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-31 05:45:46 --> Final output sent to browser
DEBUG - 2011-05-31 05:45:46 --> Total execution time: 0.2134
DEBUG - 2011-05-31 05:45:49 --> Config Class Initialized
DEBUG - 2011-05-31 05:45:49 --> Hooks Class Initialized
DEBUG - 2011-05-31 05:45:49 --> Utf8 Class Initialized
DEBUG - 2011-05-31 05:45:49 --> UTF-8 Support Enabled
DEBUG - 2011-05-31 05:45:49 --> URI Class Initialized
DEBUG - 2011-05-31 05:45:49 --> Router Class Initialized
DEBUG - 2011-05-31 05:45:49 --> Output Class Initialized
DEBUG - 2011-05-31 05:45:49 --> Input Class Initialized
DEBUG - 2011-05-31 05:45:49 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-31 05:45:49 --> Language Class Initialized
DEBUG - 2011-05-31 05:45:49 --> Loader Class Initialized
DEBUG - 2011-05-31 05:45:49 --> Controller Class Initialized
DEBUG - 2011-05-31 05:45:49 --> Model Class Initialized
DEBUG - 2011-05-31 05:45:49 --> Model Class Initialized
DEBUG - 2011-05-31 05:45:49 --> Model Class Initialized
DEBUG - 2011-05-31 05:45:49 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-31 05:45:49 --> Database Driver Class Initialized
DEBUG - 2011-05-31 05:45:49 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-31 05:45:49 --> Helper loaded: url_helper
DEBUG - 2011-05-31 05:45:49 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-31 05:45:49 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-31 05:45:49 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-31 05:45:49 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-31 05:45:49 --> Final output sent to browser
DEBUG - 2011-05-31 05:45:49 --> Total execution time: 0.0500
DEBUG - 2011-05-31 05:45:58 --> Config Class Initialized
DEBUG - 2011-05-31 05:45:58 --> Hooks Class Initialized
DEBUG - 2011-05-31 05:45:58 --> Utf8 Class Initialized
DEBUG - 2011-05-31 05:45:58 --> UTF-8 Support Enabled
DEBUG - 2011-05-31 05:45:58 --> URI Class Initialized
DEBUG - 2011-05-31 05:45:58 --> Router Class Initialized
DEBUG - 2011-05-31 05:45:58 --> Output Class Initialized
DEBUG - 2011-05-31 05:45:58 --> Input Class Initialized
DEBUG - 2011-05-31 05:45:58 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-31 05:45:58 --> Language Class Initialized
DEBUG - 2011-05-31 05:45:58 --> Loader Class Initialized
DEBUG - 2011-05-31 05:45:58 --> Controller Class Initialized
DEBUG - 2011-05-31 05:45:58 --> Model Class Initialized
DEBUG - 2011-05-31 05:45:58 --> Model Class Initialized
DEBUG - 2011-05-31 05:45:58 --> Model Class Initialized
DEBUG - 2011-05-31 05:45:58 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-31 05:45:58 --> Database Driver Class Initialized
DEBUG - 2011-05-31 05:46:00 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-31 05:46:00 --> Helper loaded: url_helper
DEBUG - 2011-05-31 05:46:00 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-31 05:46:00 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-31 05:46:00 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-31 05:46:00 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-31 05:46:00 --> Final output sent to browser
DEBUG - 2011-05-31 05:46:00 --> Total execution time: 1.5792
DEBUG - 2011-05-31 05:46:01 --> Config Class Initialized
DEBUG - 2011-05-31 05:46:01 --> Hooks Class Initialized
DEBUG - 2011-05-31 05:46:01 --> Utf8 Class Initialized
DEBUG - 2011-05-31 05:46:01 --> UTF-8 Support Enabled
DEBUG - 2011-05-31 05:46:01 --> URI Class Initialized
DEBUG - 2011-05-31 05:46:01 --> Router Class Initialized
DEBUG - 2011-05-31 05:46:01 --> Output Class Initialized
DEBUG - 2011-05-31 05:46:01 --> Input Class Initialized
DEBUG - 2011-05-31 05:46:01 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-31 05:46:01 --> Language Class Initialized
DEBUG - 2011-05-31 05:46:01 --> Loader Class Initialized
DEBUG - 2011-05-31 05:46:01 --> Controller Class Initialized
DEBUG - 2011-05-31 05:46:01 --> Model Class Initialized
DEBUG - 2011-05-31 05:46:01 --> Model Class Initialized
DEBUG - 2011-05-31 05:46:01 --> Model Class Initialized
DEBUG - 2011-05-31 05:46:01 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-31 05:46:01 --> Database Driver Class Initialized
DEBUG - 2011-05-31 05:46:01 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-31 05:46:01 --> Helper loaded: url_helper
DEBUG - 2011-05-31 05:46:01 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-31 05:46:01 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-31 05:46:01 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-31 05:46:01 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-31 05:46:01 --> Final output sent to browser
DEBUG - 2011-05-31 05:46:01 --> Total execution time: 0.0972
DEBUG - 2011-05-31 05:46:10 --> Config Class Initialized
DEBUG - 2011-05-31 05:46:10 --> Hooks Class Initialized
DEBUG - 2011-05-31 05:46:10 --> Utf8 Class Initialized
DEBUG - 2011-05-31 05:46:10 --> UTF-8 Support Enabled
DEBUG - 2011-05-31 05:46:10 --> URI Class Initialized
DEBUG - 2011-05-31 05:46:10 --> Router Class Initialized
DEBUG - 2011-05-31 05:46:10 --> Output Class Initialized
DEBUG - 2011-05-31 05:46:10 --> Input Class Initialized
DEBUG - 2011-05-31 05:46:10 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-31 05:46:10 --> Language Class Initialized
DEBUG - 2011-05-31 05:46:10 --> Loader Class Initialized
DEBUG - 2011-05-31 05:46:10 --> Controller Class Initialized
DEBUG - 2011-05-31 05:46:10 --> Model Class Initialized
DEBUG - 2011-05-31 05:46:10 --> Model Class Initialized
DEBUG - 2011-05-31 05:46:10 --> Model Class Initialized
DEBUG - 2011-05-31 05:46:10 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-31 05:46:10 --> Database Driver Class Initialized
DEBUG - 2011-05-31 05:46:15 --> Config Class Initialized
DEBUG - 2011-05-31 05:46:15 --> Hooks Class Initialized
DEBUG - 2011-05-31 05:46:15 --> Utf8 Class Initialized
DEBUG - 2011-05-31 05:46:15 --> UTF-8 Support Enabled
DEBUG - 2011-05-31 05:46:15 --> URI Class Initialized
DEBUG - 2011-05-31 05:46:15 --> Router Class Initialized
DEBUG - 2011-05-31 05:46:15 --> Output Class Initialized
DEBUG - 2011-05-31 05:46:15 --> Input Class Initialized
DEBUG - 2011-05-31 05:46:15 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-31 05:46:15 --> Language Class Initialized
DEBUG - 2011-05-31 05:46:15 --> Loader Class Initialized
DEBUG - 2011-05-31 05:46:15 --> Controller Class Initialized
DEBUG - 2011-05-31 05:46:15 --> Model Class Initialized
DEBUG - 2011-05-31 05:46:15 --> Model Class Initialized
DEBUG - 2011-05-31 05:46:15 --> Model Class Initialized
DEBUG - 2011-05-31 05:46:15 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-31 05:46:15 --> Database Driver Class Initialized
DEBUG - 2011-05-31 05:46:15 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-31 05:46:15 --> Helper loaded: url_helper
DEBUG - 2011-05-31 05:46:15 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-31 05:46:15 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-31 05:46:15 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-31 05:46:15 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-31 05:46:15 --> Final output sent to browser
DEBUG - 2011-05-31 05:46:15 --> Total execution time: 0.0836
DEBUG - 2011-05-31 05:46:15 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-31 05:46:15 --> Helper loaded: url_helper
DEBUG - 2011-05-31 05:46:15 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-31 05:46:15 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-31 05:46:15 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-31 05:46:15 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-31 05:46:15 --> Final output sent to browser
DEBUG - 2011-05-31 05:46:15 --> Total execution time: 5.4001
DEBUG - 2011-05-31 05:46:19 --> Config Class Initialized
DEBUG - 2011-05-31 05:46:19 --> Hooks Class Initialized
DEBUG - 2011-05-31 05:46:19 --> Utf8 Class Initialized
DEBUG - 2011-05-31 05:46:19 --> UTF-8 Support Enabled
DEBUG - 2011-05-31 05:46:19 --> URI Class Initialized
DEBUG - 2011-05-31 05:46:19 --> Router Class Initialized
DEBUG - 2011-05-31 05:46:19 --> Output Class Initialized
DEBUG - 2011-05-31 05:46:19 --> Input Class Initialized
DEBUG - 2011-05-31 05:46:19 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-31 05:46:19 --> Language Class Initialized
DEBUG - 2011-05-31 05:46:19 --> Loader Class Initialized
DEBUG - 2011-05-31 05:46:19 --> Controller Class Initialized
DEBUG - 2011-05-31 05:46:19 --> Model Class Initialized
DEBUG - 2011-05-31 05:46:19 --> Model Class Initialized
DEBUG - 2011-05-31 05:46:19 --> Model Class Initialized
DEBUG - 2011-05-31 05:46:19 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-31 05:46:19 --> Database Driver Class Initialized
DEBUG - 2011-05-31 05:46:19 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-31 05:46:19 --> Helper loaded: url_helper
DEBUG - 2011-05-31 05:46:19 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-31 05:46:19 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-31 05:46:19 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-31 05:46:19 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-31 05:46:19 --> Final output sent to browser
DEBUG - 2011-05-31 05:46:19 --> Total execution time: 0.1521
DEBUG - 2011-05-31 05:46:27 --> Config Class Initialized
DEBUG - 2011-05-31 05:46:27 --> Hooks Class Initialized
DEBUG - 2011-05-31 05:46:27 --> Utf8 Class Initialized
DEBUG - 2011-05-31 05:46:27 --> UTF-8 Support Enabled
DEBUG - 2011-05-31 05:46:27 --> URI Class Initialized
DEBUG - 2011-05-31 05:46:27 --> Router Class Initialized
DEBUG - 2011-05-31 05:46:27 --> Output Class Initialized
DEBUG - 2011-05-31 05:46:27 --> Input Class Initialized
DEBUG - 2011-05-31 05:46:27 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-31 05:46:27 --> Language Class Initialized
DEBUG - 2011-05-31 05:46:27 --> Loader Class Initialized
DEBUG - 2011-05-31 05:46:27 --> Controller Class Initialized
DEBUG - 2011-05-31 05:46:27 --> Model Class Initialized
DEBUG - 2011-05-31 05:46:27 --> Model Class Initialized
DEBUG - 2011-05-31 05:46:27 --> Model Class Initialized
DEBUG - 2011-05-31 05:46:27 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-31 05:46:27 --> Database Driver Class Initialized
DEBUG - 2011-05-31 05:46:27 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-31 05:46:27 --> Helper loaded: url_helper
DEBUG - 2011-05-31 05:46:27 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-31 05:46:27 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-31 05:46:27 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-31 05:46:27 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-31 05:46:27 --> Final output sent to browser
DEBUG - 2011-05-31 05:46:27 --> Total execution time: 0.0466
DEBUG - 2011-05-31 05:47:20 --> Config Class Initialized
DEBUG - 2011-05-31 05:47:20 --> Hooks Class Initialized
DEBUG - 2011-05-31 05:47:20 --> Utf8 Class Initialized
DEBUG - 2011-05-31 05:47:20 --> UTF-8 Support Enabled
DEBUG - 2011-05-31 05:47:20 --> URI Class Initialized
DEBUG - 2011-05-31 05:47:20 --> Router Class Initialized
DEBUG - 2011-05-31 05:47:20 --> Output Class Initialized
DEBUG - 2011-05-31 05:47:20 --> Input Class Initialized
DEBUG - 2011-05-31 05:47:20 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-31 05:47:20 --> Language Class Initialized
DEBUG - 2011-05-31 05:47:20 --> Loader Class Initialized
DEBUG - 2011-05-31 05:47:20 --> Controller Class Initialized
DEBUG - 2011-05-31 05:47:20 --> Model Class Initialized
DEBUG - 2011-05-31 05:47:20 --> Model Class Initialized
DEBUG - 2011-05-31 05:47:20 --> Model Class Initialized
DEBUG - 2011-05-31 05:47:20 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-31 05:47:20 --> Database Driver Class Initialized
DEBUG - 2011-05-31 05:47:20 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-31 05:47:20 --> Helper loaded: url_helper
DEBUG - 2011-05-31 05:47:20 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-31 05:47:20 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-31 05:47:20 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-31 05:47:20 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-31 05:47:20 --> Final output sent to browser
DEBUG - 2011-05-31 05:47:20 --> Total execution time: 0.1976
DEBUG - 2011-05-31 05:47:31 --> Config Class Initialized
DEBUG - 2011-05-31 05:47:31 --> Hooks Class Initialized
DEBUG - 2011-05-31 05:47:31 --> Utf8 Class Initialized
DEBUG - 2011-05-31 05:47:31 --> UTF-8 Support Enabled
DEBUG - 2011-05-31 05:47:31 --> URI Class Initialized
DEBUG - 2011-05-31 05:47:31 --> Router Class Initialized
DEBUG - 2011-05-31 05:47:31 --> Output Class Initialized
DEBUG - 2011-05-31 05:47:31 --> Input Class Initialized
DEBUG - 2011-05-31 05:47:31 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-31 05:47:31 --> Language Class Initialized
DEBUG - 2011-05-31 05:47:31 --> Loader Class Initialized
DEBUG - 2011-05-31 05:47:31 --> Controller Class Initialized
DEBUG - 2011-05-31 05:47:31 --> Model Class Initialized
DEBUG - 2011-05-31 05:47:31 --> Model Class Initialized
DEBUG - 2011-05-31 05:47:31 --> Model Class Initialized
DEBUG - 2011-05-31 05:47:31 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-31 05:47:31 --> Database Driver Class Initialized
DEBUG - 2011-05-31 05:47:32 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-31 05:47:32 --> Helper loaded: url_helper
DEBUG - 2011-05-31 05:47:32 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-31 05:47:32 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-31 05:47:32 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-31 05:47:32 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-31 05:47:32 --> Final output sent to browser
DEBUG - 2011-05-31 05:47:32 --> Total execution time: 0.2621
DEBUG - 2011-05-31 05:47:38 --> Config Class Initialized
DEBUG - 2011-05-31 05:47:38 --> Hooks Class Initialized
DEBUG - 2011-05-31 05:47:38 --> Utf8 Class Initialized
DEBUG - 2011-05-31 05:47:38 --> UTF-8 Support Enabled
DEBUG - 2011-05-31 05:47:38 --> URI Class Initialized
DEBUG - 2011-05-31 05:47:38 --> Router Class Initialized
DEBUG - 2011-05-31 05:47:38 --> Output Class Initialized
DEBUG - 2011-05-31 05:47:38 --> Input Class Initialized
DEBUG - 2011-05-31 05:47:38 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-31 05:47:38 --> Language Class Initialized
DEBUG - 2011-05-31 05:47:38 --> Loader Class Initialized
DEBUG - 2011-05-31 05:47:38 --> Controller Class Initialized
DEBUG - 2011-05-31 05:47:38 --> Model Class Initialized
DEBUG - 2011-05-31 05:47:38 --> Model Class Initialized
DEBUG - 2011-05-31 05:47:38 --> Model Class Initialized
DEBUG - 2011-05-31 05:47:38 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-31 05:47:38 --> Database Driver Class Initialized
DEBUG - 2011-05-31 05:47:38 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-31 05:47:38 --> Helper loaded: url_helper
DEBUG - 2011-05-31 05:47:38 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-31 05:47:38 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-31 05:47:38 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-31 05:47:38 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-31 05:47:38 --> Final output sent to browser
DEBUG - 2011-05-31 05:47:38 --> Total execution time: 0.0526
DEBUG - 2011-05-31 05:47:41 --> Config Class Initialized
DEBUG - 2011-05-31 05:47:41 --> Hooks Class Initialized
DEBUG - 2011-05-31 05:47:41 --> Utf8 Class Initialized
DEBUG - 2011-05-31 05:47:41 --> UTF-8 Support Enabled
DEBUG - 2011-05-31 05:47:41 --> URI Class Initialized
DEBUG - 2011-05-31 05:47:41 --> Router Class Initialized
DEBUG - 2011-05-31 05:47:41 --> Output Class Initialized
DEBUG - 2011-05-31 05:47:41 --> Input Class Initialized
DEBUG - 2011-05-31 05:47:41 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-31 05:47:41 --> Language Class Initialized
DEBUG - 2011-05-31 05:47:41 --> Loader Class Initialized
DEBUG - 2011-05-31 05:47:41 --> Controller Class Initialized
DEBUG - 2011-05-31 05:47:41 --> Model Class Initialized
DEBUG - 2011-05-31 05:47:41 --> Model Class Initialized
DEBUG - 2011-05-31 05:47:41 --> Model Class Initialized
DEBUG - 2011-05-31 05:47:41 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-31 05:47:41 --> Database Driver Class Initialized
DEBUG - 2011-05-31 05:47:41 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-31 05:47:41 --> Helper loaded: url_helper
DEBUG - 2011-05-31 05:47:41 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-31 05:47:41 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-31 05:47:41 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-31 05:47:41 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-31 05:47:41 --> Final output sent to browser
DEBUG - 2011-05-31 05:47:41 --> Total execution time: 0.2119
DEBUG - 2011-05-31 05:47:47 --> Config Class Initialized
DEBUG - 2011-05-31 05:47:47 --> Hooks Class Initialized
DEBUG - 2011-05-31 05:47:47 --> Utf8 Class Initialized
DEBUG - 2011-05-31 05:47:47 --> UTF-8 Support Enabled
DEBUG - 2011-05-31 05:47:47 --> URI Class Initialized
DEBUG - 2011-05-31 05:47:47 --> Router Class Initialized
DEBUG - 2011-05-31 05:47:47 --> Output Class Initialized
DEBUG - 2011-05-31 05:47:47 --> Input Class Initialized
DEBUG - 2011-05-31 05:47:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-31 05:47:47 --> Language Class Initialized
DEBUG - 2011-05-31 05:47:47 --> Loader Class Initialized
DEBUG - 2011-05-31 05:47:47 --> Controller Class Initialized
DEBUG - 2011-05-31 05:47:47 --> Model Class Initialized
DEBUG - 2011-05-31 05:47:47 --> Model Class Initialized
DEBUG - 2011-05-31 05:47:47 --> Model Class Initialized
DEBUG - 2011-05-31 05:47:47 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-31 05:47:47 --> Database Driver Class Initialized
DEBUG - 2011-05-31 05:47:47 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-31 05:47:47 --> Helper loaded: url_helper
DEBUG - 2011-05-31 05:47:47 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-31 05:47:47 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-31 05:47:47 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-31 05:47:47 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-31 05:47:47 --> Final output sent to browser
DEBUG - 2011-05-31 05:47:47 --> Total execution time: 0.2223
DEBUG - 2011-05-31 05:47:56 --> Config Class Initialized
DEBUG - 2011-05-31 05:47:56 --> Hooks Class Initialized
DEBUG - 2011-05-31 05:47:56 --> Utf8 Class Initialized
DEBUG - 2011-05-31 05:47:56 --> UTF-8 Support Enabled
DEBUG - 2011-05-31 05:47:56 --> URI Class Initialized
DEBUG - 2011-05-31 05:47:56 --> Router Class Initialized
DEBUG - 2011-05-31 05:47:56 --> Output Class Initialized
DEBUG - 2011-05-31 05:47:56 --> Input Class Initialized
DEBUG - 2011-05-31 05:47:56 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-31 05:47:56 --> Language Class Initialized
DEBUG - 2011-05-31 05:47:56 --> Loader Class Initialized
DEBUG - 2011-05-31 05:47:56 --> Controller Class Initialized
DEBUG - 2011-05-31 05:47:56 --> Model Class Initialized
DEBUG - 2011-05-31 05:47:56 --> Model Class Initialized
DEBUG - 2011-05-31 05:47:56 --> Model Class Initialized
DEBUG - 2011-05-31 05:47:56 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-31 05:47:56 --> Database Driver Class Initialized
DEBUG - 2011-05-31 05:47:56 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-31 05:47:56 --> Helper loaded: url_helper
DEBUG - 2011-05-31 05:47:56 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-31 05:47:56 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-31 05:47:56 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-31 05:47:56 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-31 05:47:56 --> Final output sent to browser
DEBUG - 2011-05-31 05:47:56 --> Total execution time: 0.0502
DEBUG - 2011-05-31 05:47:58 --> Config Class Initialized
DEBUG - 2011-05-31 05:47:58 --> Hooks Class Initialized
DEBUG - 2011-05-31 05:47:58 --> Utf8 Class Initialized
DEBUG - 2011-05-31 05:47:58 --> UTF-8 Support Enabled
DEBUG - 2011-05-31 05:47:58 --> URI Class Initialized
DEBUG - 2011-05-31 05:47:58 --> Router Class Initialized
DEBUG - 2011-05-31 05:47:58 --> Output Class Initialized
DEBUG - 2011-05-31 05:47:58 --> Input Class Initialized
DEBUG - 2011-05-31 05:47:58 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-31 05:47:58 --> Language Class Initialized
DEBUG - 2011-05-31 05:47:58 --> Loader Class Initialized
DEBUG - 2011-05-31 05:47:58 --> Controller Class Initialized
DEBUG - 2011-05-31 05:47:58 --> Model Class Initialized
DEBUG - 2011-05-31 05:47:58 --> Model Class Initialized
DEBUG - 2011-05-31 05:47:58 --> Model Class Initialized
DEBUG - 2011-05-31 05:47:58 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-31 05:47:58 --> Database Driver Class Initialized
DEBUG - 2011-05-31 05:47:58 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-31 05:47:58 --> Helper loaded: url_helper
DEBUG - 2011-05-31 05:47:58 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-31 05:47:58 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-31 05:47:58 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-31 05:47:58 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-31 05:47:58 --> Final output sent to browser
DEBUG - 2011-05-31 05:47:58 --> Total execution time: 0.0487
DEBUG - 2011-05-31 07:53:00 --> Config Class Initialized
DEBUG - 2011-05-31 07:53:00 --> Hooks Class Initialized
DEBUG - 2011-05-31 07:53:00 --> Utf8 Class Initialized
DEBUG - 2011-05-31 07:53:00 --> UTF-8 Support Enabled
DEBUG - 2011-05-31 07:53:00 --> URI Class Initialized
DEBUG - 2011-05-31 07:53:00 --> Router Class Initialized
DEBUG - 2011-05-31 07:53:00 --> Output Class Initialized
DEBUG - 2011-05-31 07:53:00 --> Input Class Initialized
DEBUG - 2011-05-31 07:53:00 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-31 07:53:00 --> Language Class Initialized
DEBUG - 2011-05-31 07:53:00 --> Loader Class Initialized
DEBUG - 2011-05-31 07:53:00 --> Controller Class Initialized
ERROR - 2011-05-31 07:53:00 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-31 07:53:00 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-31 07:53:00 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-31 07:53:00 --> Model Class Initialized
DEBUG - 2011-05-31 07:53:00 --> Model Class Initialized
DEBUG - 2011-05-31 07:53:00 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-31 07:53:01 --> Database Driver Class Initialized
DEBUG - 2011-05-31 07:53:01 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-31 07:53:01 --> Helper loaded: url_helper
DEBUG - 2011-05-31 07:53:01 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-31 07:53:01 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-31 07:53:01 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-31 07:53:01 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-31 07:53:01 --> Final output sent to browser
DEBUG - 2011-05-31 07:53:01 --> Total execution time: 1.7193
DEBUG - 2011-05-31 07:53:03 --> Config Class Initialized
DEBUG - 2011-05-31 07:53:03 --> Hooks Class Initialized
DEBUG - 2011-05-31 07:53:03 --> Utf8 Class Initialized
DEBUG - 2011-05-31 07:53:03 --> UTF-8 Support Enabled
DEBUG - 2011-05-31 07:53:03 --> URI Class Initialized
DEBUG - 2011-05-31 07:53:03 --> Router Class Initialized
DEBUG - 2011-05-31 07:53:03 --> Output Class Initialized
DEBUG - 2011-05-31 07:53:03 --> Input Class Initialized
DEBUG - 2011-05-31 07:53:03 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-31 07:53:03 --> Language Class Initialized
DEBUG - 2011-05-31 07:53:03 --> Loader Class Initialized
DEBUG - 2011-05-31 07:53:03 --> Controller Class Initialized
DEBUG - 2011-05-31 07:53:03 --> Model Class Initialized
DEBUG - 2011-05-31 07:53:03 --> Model Class Initialized
DEBUG - 2011-05-31 07:53:03 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-31 07:53:03 --> Database Driver Class Initialized
DEBUG - 2011-05-31 07:53:03 --> Final output sent to browser
DEBUG - 2011-05-31 07:53:03 --> Total execution time: 0.8502
DEBUG - 2011-05-31 07:53:05 --> Config Class Initialized
DEBUG - 2011-05-31 07:53:05 --> Hooks Class Initialized
DEBUG - 2011-05-31 07:53:05 --> Utf8 Class Initialized
DEBUG - 2011-05-31 07:53:05 --> UTF-8 Support Enabled
DEBUG - 2011-05-31 07:53:05 --> URI Class Initialized
DEBUG - 2011-05-31 07:53:05 --> Router Class Initialized
ERROR - 2011-05-31 07:53:05 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-31 09:51:49 --> Config Class Initialized
DEBUG - 2011-05-31 09:51:49 --> Hooks Class Initialized
DEBUG - 2011-05-31 09:51:49 --> Utf8 Class Initialized
DEBUG - 2011-05-31 09:51:49 --> UTF-8 Support Enabled
DEBUG - 2011-05-31 09:51:49 --> URI Class Initialized
DEBUG - 2011-05-31 09:51:49 --> Router Class Initialized
DEBUG - 2011-05-31 09:51:49 --> Output Class Initialized
DEBUG - 2011-05-31 09:51:49 --> Input Class Initialized
DEBUG - 2011-05-31 09:51:49 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-31 09:51:49 --> Language Class Initialized
DEBUG - 2011-05-31 09:51:49 --> Loader Class Initialized
DEBUG - 2011-05-31 09:51:49 --> Controller Class Initialized
ERROR - 2011-05-31 09:51:49 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-31 09:51:49 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-31 09:51:49 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-31 09:51:49 --> Model Class Initialized
DEBUG - 2011-05-31 09:51:49 --> Model Class Initialized
DEBUG - 2011-05-31 09:51:49 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-31 09:51:49 --> Database Driver Class Initialized
DEBUG - 2011-05-31 09:51:49 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-31 09:51:50 --> Helper loaded: url_helper
DEBUG - 2011-05-31 09:51:50 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-31 09:51:50 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-31 09:51:50 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-31 09:51:50 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-31 09:51:50 --> Final output sent to browser
DEBUG - 2011-05-31 09:51:50 --> Total execution time: 0.4150
DEBUG - 2011-05-31 09:51:50 --> Config Class Initialized
DEBUG - 2011-05-31 09:51:50 --> Hooks Class Initialized
DEBUG - 2011-05-31 09:51:50 --> Utf8 Class Initialized
DEBUG - 2011-05-31 09:51:50 --> UTF-8 Support Enabled
DEBUG - 2011-05-31 09:51:50 --> URI Class Initialized
DEBUG - 2011-05-31 09:51:50 --> Router Class Initialized
DEBUG - 2011-05-31 09:51:50 --> Output Class Initialized
DEBUG - 2011-05-31 09:51:50 --> Input Class Initialized
DEBUG - 2011-05-31 09:51:50 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-31 09:51:50 --> Language Class Initialized
DEBUG - 2011-05-31 09:51:50 --> Loader Class Initialized
DEBUG - 2011-05-31 09:51:50 --> Controller Class Initialized
DEBUG - 2011-05-31 09:51:50 --> Model Class Initialized
DEBUG - 2011-05-31 09:51:50 --> Model Class Initialized
DEBUG - 2011-05-31 09:51:50 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-31 09:51:50 --> Database Driver Class Initialized
DEBUG - 2011-05-31 09:51:51 --> Final output sent to browser
DEBUG - 2011-05-31 09:51:51 --> Total execution time: 0.7480
DEBUG - 2011-05-31 09:51:52 --> Config Class Initialized
DEBUG - 2011-05-31 09:51:52 --> Hooks Class Initialized
DEBUG - 2011-05-31 09:51:52 --> Utf8 Class Initialized
DEBUG - 2011-05-31 09:51:52 --> UTF-8 Support Enabled
DEBUG - 2011-05-31 09:51:52 --> URI Class Initialized
DEBUG - 2011-05-31 09:51:52 --> Router Class Initialized
ERROR - 2011-05-31 09:51:52 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-31 09:52:15 --> Config Class Initialized
DEBUG - 2011-05-31 09:52:15 --> Hooks Class Initialized
DEBUG - 2011-05-31 09:52:15 --> Utf8 Class Initialized
DEBUG - 2011-05-31 09:52:15 --> UTF-8 Support Enabled
DEBUG - 2011-05-31 09:52:15 --> URI Class Initialized
DEBUG - 2011-05-31 09:52:15 --> Router Class Initialized
DEBUG - 2011-05-31 09:52:15 --> Output Class Initialized
DEBUG - 2011-05-31 09:52:15 --> Input Class Initialized
DEBUG - 2011-05-31 09:52:15 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-31 09:52:15 --> Language Class Initialized
DEBUG - 2011-05-31 09:52:15 --> Loader Class Initialized
DEBUG - 2011-05-31 09:52:15 --> Controller Class Initialized
DEBUG - 2011-05-31 09:52:15 --> Model Class Initialized
DEBUG - 2011-05-31 09:52:15 --> Model Class Initialized
DEBUG - 2011-05-31 09:52:15 --> Model Class Initialized
DEBUG - 2011-05-31 09:52:15 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-31 09:52:15 --> Database Driver Class Initialized
DEBUG - 2011-05-31 09:52:18 --> Config Class Initialized
DEBUG - 2011-05-31 09:52:18 --> Hooks Class Initialized
DEBUG - 2011-05-31 09:52:18 --> Utf8 Class Initialized
DEBUG - 2011-05-31 09:52:18 --> UTF-8 Support Enabled
DEBUG - 2011-05-31 09:52:18 --> URI Class Initialized
DEBUG - 2011-05-31 09:52:18 --> Router Class Initialized
DEBUG - 2011-05-31 09:52:18 --> Output Class Initialized
DEBUG - 2011-05-31 09:52:18 --> Input Class Initialized
DEBUG - 2011-05-31 09:52:18 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-31 09:52:18 --> Language Class Initialized
DEBUG - 2011-05-31 09:52:18 --> Loader Class Initialized
DEBUG - 2011-05-31 09:52:18 --> Controller Class Initialized
DEBUG - 2011-05-31 09:52:18 --> Model Class Initialized
DEBUG - 2011-05-31 09:52:18 --> Model Class Initialized
DEBUG - 2011-05-31 09:52:18 --> Model Class Initialized
DEBUG - 2011-05-31 09:52:18 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-31 09:52:18 --> Database Driver Class Initialized
DEBUG - 2011-05-31 09:52:19 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-31 09:52:19 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-31 09:52:19 --> Helper loaded: url_helper
DEBUG - 2011-05-31 09:52:19 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-31 09:52:19 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-31 09:52:19 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-31 09:52:19 --> Helper loaded: url_helper
DEBUG - 2011-05-31 09:52:19 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-31 09:52:19 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-31 09:52:19 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-31 09:52:19 --> Final output sent to browser
DEBUG - 2011-05-31 09:52:19 --> Total execution time: 0.2238
DEBUG - 2011-05-31 09:52:19 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-31 09:52:19 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-31 09:52:19 --> Final output sent to browser
DEBUG - 2011-05-31 09:52:19 --> Total execution time: 3.8432
DEBUG - 2011-05-31 09:52:20 --> Config Class Initialized
DEBUG - 2011-05-31 09:52:20 --> Hooks Class Initialized
DEBUG - 2011-05-31 09:52:20 --> Utf8 Class Initialized
DEBUG - 2011-05-31 09:52:20 --> UTF-8 Support Enabled
DEBUG - 2011-05-31 09:52:20 --> URI Class Initialized
DEBUG - 2011-05-31 09:52:20 --> Router Class Initialized
ERROR - 2011-05-31 09:52:20 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-31 09:52:44 --> Config Class Initialized
DEBUG - 2011-05-31 09:52:44 --> Hooks Class Initialized
DEBUG - 2011-05-31 09:52:44 --> Utf8 Class Initialized
DEBUG - 2011-05-31 09:52:44 --> UTF-8 Support Enabled
DEBUG - 2011-05-31 09:52:44 --> URI Class Initialized
DEBUG - 2011-05-31 09:52:44 --> Router Class Initialized
DEBUG - 2011-05-31 09:52:44 --> Output Class Initialized
DEBUG - 2011-05-31 09:52:44 --> Input Class Initialized
DEBUG - 2011-05-31 09:52:44 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-31 09:52:44 --> Language Class Initialized
DEBUG - 2011-05-31 09:52:44 --> Loader Class Initialized
DEBUG - 2011-05-31 09:52:44 --> Controller Class Initialized
DEBUG - 2011-05-31 09:52:44 --> Model Class Initialized
DEBUG - 2011-05-31 09:52:44 --> Model Class Initialized
DEBUG - 2011-05-31 09:52:44 --> Model Class Initialized
DEBUG - 2011-05-31 09:52:44 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-31 09:52:44 --> Database Driver Class Initialized
DEBUG - 2011-05-31 09:52:44 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-31 09:52:44 --> Helper loaded: url_helper
DEBUG - 2011-05-31 09:52:44 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-31 09:52:44 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-31 09:52:44 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-31 09:52:44 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-31 09:52:44 --> Final output sent to browser
DEBUG - 2011-05-31 09:52:44 --> Total execution time: 0.1858
DEBUG - 2011-05-31 09:52:45 --> Config Class Initialized
DEBUG - 2011-05-31 09:52:45 --> Hooks Class Initialized
DEBUG - 2011-05-31 09:52:45 --> Utf8 Class Initialized
DEBUG - 2011-05-31 09:52:45 --> UTF-8 Support Enabled
DEBUG - 2011-05-31 09:52:45 --> URI Class Initialized
DEBUG - 2011-05-31 09:52:45 --> Router Class Initialized
ERROR - 2011-05-31 09:52:45 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-31 12:47:42 --> Config Class Initialized
DEBUG - 2011-05-31 12:47:42 --> Hooks Class Initialized
DEBUG - 2011-05-31 12:47:42 --> Utf8 Class Initialized
DEBUG - 2011-05-31 12:47:42 --> UTF-8 Support Enabled
DEBUG - 2011-05-31 12:47:42 --> URI Class Initialized
DEBUG - 2011-05-31 12:47:42 --> Router Class Initialized
DEBUG - 2011-05-31 12:47:42 --> Output Class Initialized
DEBUG - 2011-05-31 12:47:42 --> Input Class Initialized
DEBUG - 2011-05-31 12:47:42 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-31 12:47:42 --> Language Class Initialized
DEBUG - 2011-05-31 12:47:43 --> Loader Class Initialized
DEBUG - 2011-05-31 12:47:43 --> Controller Class Initialized
DEBUG - 2011-05-31 12:47:43 --> Model Class Initialized
DEBUG - 2011-05-31 12:47:43 --> Model Class Initialized
DEBUG - 2011-05-31 12:47:43 --> Model Class Initialized
DEBUG - 2011-05-31 12:47:43 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-31 12:47:44 --> Database Driver Class Initialized
DEBUG - 2011-05-31 12:47:44 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-31 12:47:45 --> Helper loaded: url_helper
DEBUG - 2011-05-31 12:47:45 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-31 12:47:45 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-31 12:47:45 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-31 12:47:45 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-31 12:47:45 --> Final output sent to browser
DEBUG - 2011-05-31 12:47:45 --> Total execution time: 3.2263
DEBUG - 2011-05-31 12:47:51 --> Config Class Initialized
DEBUG - 2011-05-31 12:47:51 --> Hooks Class Initialized
DEBUG - 2011-05-31 12:47:51 --> Utf8 Class Initialized
DEBUG - 2011-05-31 12:47:51 --> UTF-8 Support Enabled
DEBUG - 2011-05-31 12:47:51 --> URI Class Initialized
DEBUG - 2011-05-31 12:47:51 --> Router Class Initialized
DEBUG - 2011-05-31 12:47:51 --> Output Class Initialized
DEBUG - 2011-05-31 12:47:51 --> Input Class Initialized
DEBUG - 2011-05-31 12:47:51 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-31 12:47:51 --> Language Class Initialized
DEBUG - 2011-05-31 12:47:51 --> Loader Class Initialized
DEBUG - 2011-05-31 12:47:51 --> Controller Class Initialized
ERROR - 2011-05-31 12:47:51 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-31 12:47:51 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-31 12:47:51 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-31 12:47:51 --> Model Class Initialized
DEBUG - 2011-05-31 12:47:51 --> Model Class Initialized
DEBUG - 2011-05-31 12:47:51 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-31 12:47:51 --> Database Driver Class Initialized
DEBUG - 2011-05-31 12:47:51 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-31 12:47:51 --> Helper loaded: url_helper
DEBUG - 2011-05-31 12:47:51 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-31 12:47:51 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-31 12:47:51 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-31 12:47:51 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-31 12:47:51 --> Final output sent to browser
DEBUG - 2011-05-31 12:47:51 --> Total execution time: 0.0946
DEBUG - 2011-05-31 12:52:43 --> Config Class Initialized
DEBUG - 2011-05-31 12:52:43 --> Hooks Class Initialized
DEBUG - 2011-05-31 12:52:43 --> Utf8 Class Initialized
DEBUG - 2011-05-31 12:52:43 --> UTF-8 Support Enabled
DEBUG - 2011-05-31 12:52:43 --> URI Class Initialized
DEBUG - 2011-05-31 12:52:43 --> Router Class Initialized
DEBUG - 2011-05-31 12:52:43 --> Output Class Initialized
DEBUG - 2011-05-31 12:52:43 --> Input Class Initialized
DEBUG - 2011-05-31 12:52:43 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-31 12:52:43 --> Language Class Initialized
DEBUG - 2011-05-31 12:52:43 --> Loader Class Initialized
DEBUG - 2011-05-31 12:52:43 --> Controller Class Initialized
ERROR - 2011-05-31 12:52:43 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-31 12:52:43 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-31 12:52:43 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-31 12:52:43 --> Model Class Initialized
DEBUG - 2011-05-31 12:52:43 --> Model Class Initialized
DEBUG - 2011-05-31 12:52:43 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-31 12:52:43 --> Database Driver Class Initialized
DEBUG - 2011-05-31 12:52:43 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-31 12:52:43 --> Helper loaded: url_helper
DEBUG - 2011-05-31 12:52:43 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-31 12:52:43 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-31 12:52:43 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-31 12:52:43 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-31 12:52:43 --> Final output sent to browser
DEBUG - 2011-05-31 12:52:43 --> Total execution time: 0.0373
DEBUG - 2011-05-31 14:00:55 --> Config Class Initialized
DEBUG - 2011-05-31 14:00:55 --> Hooks Class Initialized
DEBUG - 2011-05-31 14:00:55 --> Utf8 Class Initialized
DEBUG - 2011-05-31 14:00:55 --> UTF-8 Support Enabled
DEBUG - 2011-05-31 14:00:55 --> URI Class Initialized
DEBUG - 2011-05-31 14:00:55 --> Router Class Initialized
DEBUG - 2011-05-31 14:00:55 --> Output Class Initialized
DEBUG - 2011-05-31 14:00:55 --> Input Class Initialized
DEBUG - 2011-05-31 14:00:55 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-31 14:00:55 --> Language Class Initialized
DEBUG - 2011-05-31 14:00:55 --> Loader Class Initialized
DEBUG - 2011-05-31 14:00:55 --> Controller Class Initialized
DEBUG - 2011-05-31 14:00:55 --> Model Class Initialized
DEBUG - 2011-05-31 14:00:55 --> Model Class Initialized
DEBUG - 2011-05-31 14:00:55 --> Model Class Initialized
DEBUG - 2011-05-31 14:00:55 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-31 14:00:55 --> Database Driver Class Initialized
DEBUG - 2011-05-31 14:00:55 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-31 14:00:55 --> Helper loaded: url_helper
DEBUG - 2011-05-31 14:00:55 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-31 14:00:55 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-31 14:00:55 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-31 14:00:55 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-31 14:00:55 --> Final output sent to browser
DEBUG - 2011-05-31 14:00:55 --> Total execution time: 0.5991
DEBUG - 2011-05-31 14:00:57 --> Config Class Initialized
DEBUG - 2011-05-31 14:00:57 --> Hooks Class Initialized
DEBUG - 2011-05-31 14:00:57 --> Utf8 Class Initialized
DEBUG - 2011-05-31 14:00:57 --> UTF-8 Support Enabled
DEBUG - 2011-05-31 14:00:57 --> URI Class Initialized
DEBUG - 2011-05-31 14:00:57 --> Router Class Initialized
ERROR - 2011-05-31 14:00:57 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-31 14:00:58 --> Config Class Initialized
DEBUG - 2011-05-31 14:00:58 --> Hooks Class Initialized
DEBUG - 2011-05-31 14:00:58 --> Utf8 Class Initialized
DEBUG - 2011-05-31 14:00:58 --> UTF-8 Support Enabled
DEBUG - 2011-05-31 14:00:58 --> URI Class Initialized
DEBUG - 2011-05-31 14:00:58 --> Router Class Initialized
ERROR - 2011-05-31 14:00:58 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-31 14:01:24 --> Config Class Initialized
DEBUG - 2011-05-31 14:01:24 --> Hooks Class Initialized
DEBUG - 2011-05-31 14:01:24 --> Utf8 Class Initialized
DEBUG - 2011-05-31 14:01:24 --> UTF-8 Support Enabled
DEBUG - 2011-05-31 14:01:24 --> URI Class Initialized
DEBUG - 2011-05-31 14:01:24 --> Router Class Initialized
DEBUG - 2011-05-31 14:01:24 --> Output Class Initialized
DEBUG - 2011-05-31 14:01:24 --> Input Class Initialized
DEBUG - 2011-05-31 14:01:24 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-31 14:01:24 --> Language Class Initialized
DEBUG - 2011-05-31 14:01:24 --> Loader Class Initialized
DEBUG - 2011-05-31 14:01:24 --> Controller Class Initialized
DEBUG - 2011-05-31 14:01:24 --> Model Class Initialized
DEBUG - 2011-05-31 14:01:24 --> Model Class Initialized
DEBUG - 2011-05-31 14:01:24 --> Model Class Initialized
DEBUG - 2011-05-31 14:01:24 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-31 14:01:24 --> Database Driver Class Initialized
DEBUG - 2011-05-31 14:01:24 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-31 14:01:24 --> Helper loaded: url_helper
DEBUG - 2011-05-31 14:01:24 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-31 14:01:24 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-31 14:01:24 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-31 14:01:24 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-31 14:01:24 --> Final output sent to browser
DEBUG - 2011-05-31 14:01:24 --> Total execution time: 0.3755
DEBUG - 2011-05-31 14:01:26 --> Config Class Initialized
DEBUG - 2011-05-31 14:01:26 --> Hooks Class Initialized
DEBUG - 2011-05-31 14:01:26 --> Utf8 Class Initialized
DEBUG - 2011-05-31 14:01:26 --> UTF-8 Support Enabled
DEBUG - 2011-05-31 14:01:26 --> URI Class Initialized
DEBUG - 2011-05-31 14:01:26 --> Router Class Initialized
ERROR - 2011-05-31 14:01:26 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-31 14:01:28 --> Config Class Initialized
DEBUG - 2011-05-31 14:01:28 --> Hooks Class Initialized
DEBUG - 2011-05-31 14:01:28 --> Utf8 Class Initialized
DEBUG - 2011-05-31 14:01:28 --> UTF-8 Support Enabled
DEBUG - 2011-05-31 14:01:28 --> URI Class Initialized
DEBUG - 2011-05-31 14:01:28 --> Router Class Initialized
DEBUG - 2011-05-31 14:01:28 --> Output Class Initialized
DEBUG - 2011-05-31 14:01:28 --> Input Class Initialized
DEBUG - 2011-05-31 14:01:28 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-31 14:01:28 --> Language Class Initialized
DEBUG - 2011-05-31 14:01:28 --> Loader Class Initialized
DEBUG - 2011-05-31 14:01:28 --> Controller Class Initialized
DEBUG - 2011-05-31 14:01:28 --> Model Class Initialized
DEBUG - 2011-05-31 14:01:28 --> Model Class Initialized
DEBUG - 2011-05-31 14:01:28 --> Model Class Initialized
DEBUG - 2011-05-31 14:01:28 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-31 14:01:28 --> Database Driver Class Initialized
DEBUG - 2011-05-31 14:01:28 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-31 14:01:28 --> Helper loaded: url_helper
DEBUG - 2011-05-31 14:01:28 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-31 14:01:28 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-31 14:01:28 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-31 14:01:28 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-31 14:01:28 --> Final output sent to browser
DEBUG - 2011-05-31 14:01:28 --> Total execution time: 0.0446
DEBUG - 2011-05-31 14:01:44 --> Config Class Initialized
DEBUG - 2011-05-31 14:01:44 --> Hooks Class Initialized
DEBUG - 2011-05-31 14:01:44 --> Utf8 Class Initialized
DEBUG - 2011-05-31 14:01:44 --> UTF-8 Support Enabled
DEBUG - 2011-05-31 14:01:44 --> URI Class Initialized
DEBUG - 2011-05-31 14:01:44 --> Router Class Initialized
DEBUG - 2011-05-31 14:01:44 --> Output Class Initialized
DEBUG - 2011-05-31 14:01:44 --> Input Class Initialized
DEBUG - 2011-05-31 14:01:44 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-31 14:01:44 --> Language Class Initialized
DEBUG - 2011-05-31 14:01:44 --> Loader Class Initialized
DEBUG - 2011-05-31 14:01:44 --> Controller Class Initialized
DEBUG - 2011-05-31 14:01:44 --> Model Class Initialized
DEBUG - 2011-05-31 14:01:44 --> Model Class Initialized
DEBUG - 2011-05-31 14:01:44 --> Model Class Initialized
DEBUG - 2011-05-31 14:01:44 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-31 14:01:44 --> Database Driver Class Initialized
DEBUG - 2011-05-31 14:01:44 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-31 14:01:44 --> Helper loaded: url_helper
DEBUG - 2011-05-31 14:01:44 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-31 14:01:44 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-31 14:01:44 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-31 14:01:44 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-31 14:01:44 --> Final output sent to browser
DEBUG - 2011-05-31 14:01:44 --> Total execution time: 0.3110
DEBUG - 2011-05-31 14:01:46 --> Config Class Initialized
DEBUG - 2011-05-31 14:01:46 --> Hooks Class Initialized
DEBUG - 2011-05-31 14:01:46 --> Utf8 Class Initialized
DEBUG - 2011-05-31 14:01:46 --> UTF-8 Support Enabled
DEBUG - 2011-05-31 14:01:46 --> URI Class Initialized
DEBUG - 2011-05-31 14:01:46 --> Router Class Initialized
ERROR - 2011-05-31 14:01:46 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-31 14:01:58 --> Config Class Initialized
DEBUG - 2011-05-31 14:01:58 --> Hooks Class Initialized
DEBUG - 2011-05-31 14:01:58 --> Utf8 Class Initialized
DEBUG - 2011-05-31 14:01:58 --> UTF-8 Support Enabled
DEBUG - 2011-05-31 14:01:58 --> URI Class Initialized
DEBUG - 2011-05-31 14:01:58 --> Router Class Initialized
DEBUG - 2011-05-31 14:01:58 --> Output Class Initialized
DEBUG - 2011-05-31 14:01:58 --> Input Class Initialized
DEBUG - 2011-05-31 14:01:58 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-31 14:01:58 --> Language Class Initialized
DEBUG - 2011-05-31 14:01:58 --> Loader Class Initialized
DEBUG - 2011-05-31 14:01:58 --> Controller Class Initialized
DEBUG - 2011-05-31 14:01:58 --> Model Class Initialized
DEBUG - 2011-05-31 14:01:58 --> Model Class Initialized
DEBUG - 2011-05-31 14:01:58 --> Model Class Initialized
DEBUG - 2011-05-31 14:01:58 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-31 14:01:58 --> Database Driver Class Initialized
DEBUG - 2011-05-31 14:01:59 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-31 14:01:59 --> Helper loaded: url_helper
DEBUG - 2011-05-31 14:01:59 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-31 14:01:59 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-31 14:01:59 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-31 14:01:59 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-31 14:01:59 --> Final output sent to browser
DEBUG - 2011-05-31 14:01:59 --> Total execution time: 0.3285
DEBUG - 2011-05-31 14:02:00 --> Config Class Initialized
DEBUG - 2011-05-31 14:02:00 --> Hooks Class Initialized
DEBUG - 2011-05-31 14:02:00 --> Utf8 Class Initialized
DEBUG - 2011-05-31 14:02:00 --> UTF-8 Support Enabled
DEBUG - 2011-05-31 14:02:00 --> URI Class Initialized
DEBUG - 2011-05-31 14:02:00 --> Router Class Initialized
ERROR - 2011-05-31 14:02:00 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-31 14:10:59 --> Config Class Initialized
DEBUG - 2011-05-31 14:10:59 --> Hooks Class Initialized
DEBUG - 2011-05-31 14:10:59 --> Utf8 Class Initialized
DEBUG - 2011-05-31 14:10:59 --> UTF-8 Support Enabled
DEBUG - 2011-05-31 14:10:59 --> URI Class Initialized
DEBUG - 2011-05-31 14:10:59 --> Router Class Initialized
DEBUG - 2011-05-31 14:10:59 --> Output Class Initialized
DEBUG - 2011-05-31 14:10:59 --> Input Class Initialized
DEBUG - 2011-05-31 14:10:59 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-31 14:10:59 --> Language Class Initialized
DEBUG - 2011-05-31 14:10:59 --> Loader Class Initialized
DEBUG - 2011-05-31 14:10:59 --> Controller Class Initialized
DEBUG - 2011-05-31 14:10:59 --> Model Class Initialized
DEBUG - 2011-05-31 14:10:59 --> Model Class Initialized
DEBUG - 2011-05-31 14:10:59 --> Model Class Initialized
DEBUG - 2011-05-31 14:10:59 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-31 14:10:59 --> Database Driver Class Initialized
DEBUG - 2011-05-31 14:10:59 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-31 14:10:59 --> Helper loaded: url_helper
DEBUG - 2011-05-31 14:10:59 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-31 14:10:59 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-31 14:10:59 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-31 14:10:59 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-31 14:10:59 --> Final output sent to browser
DEBUG - 2011-05-31 14:10:59 --> Total execution time: 0.0659
DEBUG - 2011-05-31 14:11:01 --> Config Class Initialized
DEBUG - 2011-05-31 14:11:01 --> Hooks Class Initialized
DEBUG - 2011-05-31 14:11:01 --> Utf8 Class Initialized
DEBUG - 2011-05-31 14:11:01 --> UTF-8 Support Enabled
DEBUG - 2011-05-31 14:11:01 --> URI Class Initialized
DEBUG - 2011-05-31 14:11:01 --> Router Class Initialized
ERROR - 2011-05-31 14:11:01 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-31 14:11:02 --> Config Class Initialized
DEBUG - 2011-05-31 14:11:02 --> Hooks Class Initialized
DEBUG - 2011-05-31 14:11:02 --> Utf8 Class Initialized
DEBUG - 2011-05-31 14:11:02 --> UTF-8 Support Enabled
DEBUG - 2011-05-31 14:11:02 --> URI Class Initialized
DEBUG - 2011-05-31 14:11:02 --> Router Class Initialized
ERROR - 2011-05-31 14:11:02 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-31 14:11:02 --> Config Class Initialized
DEBUG - 2011-05-31 14:11:02 --> Hooks Class Initialized
DEBUG - 2011-05-31 14:11:02 --> Utf8 Class Initialized
DEBUG - 2011-05-31 14:11:02 --> UTF-8 Support Enabled
DEBUG - 2011-05-31 14:11:02 --> URI Class Initialized
DEBUG - 2011-05-31 14:11:02 --> Router Class Initialized
ERROR - 2011-05-31 14:11:02 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-31 14:11:32 --> Config Class Initialized
DEBUG - 2011-05-31 14:11:32 --> Hooks Class Initialized
DEBUG - 2011-05-31 14:11:32 --> Utf8 Class Initialized
DEBUG - 2011-05-31 14:11:32 --> UTF-8 Support Enabled
DEBUG - 2011-05-31 14:11:32 --> URI Class Initialized
DEBUG - 2011-05-31 14:11:32 --> Router Class Initialized
DEBUG - 2011-05-31 14:11:32 --> Output Class Initialized
DEBUG - 2011-05-31 14:11:32 --> Input Class Initialized
DEBUG - 2011-05-31 14:11:32 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-31 14:11:32 --> Language Class Initialized
DEBUG - 2011-05-31 14:11:32 --> Loader Class Initialized
DEBUG - 2011-05-31 14:11:32 --> Controller Class Initialized
DEBUG - 2011-05-31 14:11:32 --> Model Class Initialized
DEBUG - 2011-05-31 14:11:32 --> Model Class Initialized
DEBUG - 2011-05-31 14:11:32 --> Model Class Initialized
DEBUG - 2011-05-31 14:11:32 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-31 14:11:32 --> Database Driver Class Initialized
DEBUG - 2011-05-31 14:11:34 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-31 14:11:34 --> Helper loaded: url_helper
DEBUG - 2011-05-31 14:11:34 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-31 14:11:34 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-31 14:11:34 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-31 14:11:34 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-31 14:11:34 --> Final output sent to browser
DEBUG - 2011-05-31 14:11:34 --> Total execution time: 1.8871
DEBUG - 2011-05-31 14:12:03 --> Config Class Initialized
DEBUG - 2011-05-31 14:12:03 --> Hooks Class Initialized
DEBUG - 2011-05-31 14:12:03 --> Utf8 Class Initialized
DEBUG - 2011-05-31 14:12:03 --> UTF-8 Support Enabled
DEBUG - 2011-05-31 14:12:03 --> URI Class Initialized
DEBUG - 2011-05-31 14:12:03 --> Router Class Initialized
DEBUG - 2011-05-31 14:12:03 --> Output Class Initialized
DEBUG - 2011-05-31 14:12:03 --> Input Class Initialized
DEBUG - 2011-05-31 14:12:03 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-31 14:12:03 --> Language Class Initialized
DEBUG - 2011-05-31 14:12:03 --> Loader Class Initialized
DEBUG - 2011-05-31 14:12:03 --> Controller Class Initialized
DEBUG - 2011-05-31 14:12:03 --> Model Class Initialized
DEBUG - 2011-05-31 14:12:03 --> Model Class Initialized
DEBUG - 2011-05-31 14:12:03 --> Model Class Initialized
DEBUG - 2011-05-31 14:12:03 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-31 14:12:03 --> Database Driver Class Initialized
DEBUG - 2011-05-31 14:12:04 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-31 14:12:04 --> Helper loaded: url_helper
DEBUG - 2011-05-31 14:12:04 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-31 14:12:04 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-31 14:12:04 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-31 14:12:04 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-31 14:12:04 --> Final output sent to browser
DEBUG - 2011-05-31 14:12:04 --> Total execution time: 0.6883
DEBUG - 2011-05-31 14:12:15 --> Config Class Initialized
DEBUG - 2011-05-31 14:12:15 --> Hooks Class Initialized
DEBUG - 2011-05-31 14:12:15 --> Utf8 Class Initialized
DEBUG - 2011-05-31 14:12:15 --> UTF-8 Support Enabled
DEBUG - 2011-05-31 14:12:15 --> URI Class Initialized
DEBUG - 2011-05-31 14:12:15 --> Router Class Initialized
DEBUG - 2011-05-31 14:12:15 --> Output Class Initialized
DEBUG - 2011-05-31 14:12:15 --> Input Class Initialized
DEBUG - 2011-05-31 14:12:15 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-31 14:12:15 --> Language Class Initialized
DEBUG - 2011-05-31 14:12:15 --> Loader Class Initialized
DEBUG - 2011-05-31 14:12:15 --> Controller Class Initialized
DEBUG - 2011-05-31 14:12:15 --> Model Class Initialized
DEBUG - 2011-05-31 14:12:15 --> Model Class Initialized
DEBUG - 2011-05-31 14:12:15 --> Model Class Initialized
DEBUG - 2011-05-31 14:12:15 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-31 14:12:15 --> Database Driver Class Initialized
DEBUG - 2011-05-31 14:12:15 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-31 14:12:15 --> Helper loaded: url_helper
DEBUG - 2011-05-31 14:12:15 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-31 14:12:15 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-31 14:12:15 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-31 14:12:15 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-31 14:12:15 --> Final output sent to browser
DEBUG - 2011-05-31 14:12:15 --> Total execution time: 0.2694
DEBUG - 2011-05-31 14:12:23 --> Config Class Initialized
DEBUG - 2011-05-31 14:12:23 --> Hooks Class Initialized
DEBUG - 2011-05-31 14:12:23 --> Utf8 Class Initialized
DEBUG - 2011-05-31 14:12:23 --> UTF-8 Support Enabled
DEBUG - 2011-05-31 14:12:23 --> URI Class Initialized
DEBUG - 2011-05-31 14:12:23 --> Router Class Initialized
DEBUG - 2011-05-31 14:12:23 --> Output Class Initialized
DEBUG - 2011-05-31 14:12:23 --> Input Class Initialized
DEBUG - 2011-05-31 14:12:23 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-31 14:12:23 --> Language Class Initialized
DEBUG - 2011-05-31 14:12:23 --> Loader Class Initialized
DEBUG - 2011-05-31 14:12:23 --> Controller Class Initialized
DEBUG - 2011-05-31 14:12:23 --> Model Class Initialized
DEBUG - 2011-05-31 14:12:23 --> Model Class Initialized
DEBUG - 2011-05-31 14:12:23 --> Model Class Initialized
DEBUG - 2011-05-31 14:12:23 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-31 14:12:23 --> Database Driver Class Initialized
DEBUG - 2011-05-31 14:12:23 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-31 14:12:23 --> Helper loaded: url_helper
DEBUG - 2011-05-31 14:12:23 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-31 14:12:23 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-31 14:12:23 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-31 14:12:23 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-31 14:12:23 --> Final output sent to browser
DEBUG - 2011-05-31 14:12:23 --> Total execution time: 0.3389
DEBUG - 2011-05-31 14:12:58 --> Config Class Initialized
DEBUG - 2011-05-31 14:12:58 --> Hooks Class Initialized
DEBUG - 2011-05-31 14:12:58 --> Utf8 Class Initialized
DEBUG - 2011-05-31 14:12:58 --> UTF-8 Support Enabled
DEBUG - 2011-05-31 14:12:58 --> URI Class Initialized
DEBUG - 2011-05-31 14:12:58 --> Router Class Initialized
DEBUG - 2011-05-31 14:12:58 --> Output Class Initialized
DEBUG - 2011-05-31 14:12:58 --> Input Class Initialized
DEBUG - 2011-05-31 14:12:58 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-31 14:12:58 --> Language Class Initialized
DEBUG - 2011-05-31 14:12:58 --> Loader Class Initialized
DEBUG - 2011-05-31 14:12:58 --> Controller Class Initialized
DEBUG - 2011-05-31 14:12:58 --> Model Class Initialized
DEBUG - 2011-05-31 14:12:58 --> Model Class Initialized
DEBUG - 2011-05-31 14:12:58 --> Model Class Initialized
DEBUG - 2011-05-31 14:12:58 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-31 14:12:58 --> Database Driver Class Initialized
DEBUG - 2011-05-31 14:12:58 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-31 14:12:58 --> Helper loaded: url_helper
DEBUG - 2011-05-31 14:12:58 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-31 14:12:58 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-31 14:12:58 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-31 14:12:58 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-31 14:12:58 --> Final output sent to browser
DEBUG - 2011-05-31 14:12:58 --> Total execution time: 0.0975
DEBUG - 2011-05-31 14:13:10 --> Config Class Initialized
DEBUG - 2011-05-31 14:13:10 --> Hooks Class Initialized
DEBUG - 2011-05-31 14:13:10 --> Utf8 Class Initialized
DEBUG - 2011-05-31 14:13:10 --> UTF-8 Support Enabled
DEBUG - 2011-05-31 14:13:10 --> URI Class Initialized
DEBUG - 2011-05-31 14:13:10 --> Router Class Initialized
DEBUG - 2011-05-31 14:13:10 --> Output Class Initialized
DEBUG - 2011-05-31 14:13:10 --> Input Class Initialized
DEBUG - 2011-05-31 14:13:10 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-31 14:13:10 --> Language Class Initialized
DEBUG - 2011-05-31 14:13:10 --> Loader Class Initialized
DEBUG - 2011-05-31 14:13:10 --> Controller Class Initialized
DEBUG - 2011-05-31 14:13:10 --> Model Class Initialized
DEBUG - 2011-05-31 14:13:10 --> Model Class Initialized
DEBUG - 2011-05-31 14:13:10 --> Model Class Initialized
DEBUG - 2011-05-31 14:13:10 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-31 14:13:10 --> Database Driver Class Initialized
DEBUG - 2011-05-31 14:13:10 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-31 14:13:10 --> Helper loaded: url_helper
DEBUG - 2011-05-31 14:13:10 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-31 14:13:10 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-31 14:13:10 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-31 14:13:10 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-31 14:13:10 --> Final output sent to browser
DEBUG - 2011-05-31 14:13:10 --> Total execution time: 0.4851
DEBUG - 2011-05-31 14:13:17 --> Config Class Initialized
DEBUG - 2011-05-31 14:13:17 --> Hooks Class Initialized
DEBUG - 2011-05-31 14:13:17 --> Utf8 Class Initialized
DEBUG - 2011-05-31 14:13:17 --> UTF-8 Support Enabled
DEBUG - 2011-05-31 14:13:17 --> URI Class Initialized
DEBUG - 2011-05-31 14:13:17 --> Router Class Initialized
DEBUG - 2011-05-31 14:13:17 --> Output Class Initialized
DEBUG - 2011-05-31 14:13:17 --> Input Class Initialized
DEBUG - 2011-05-31 14:13:17 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-31 14:13:17 --> Language Class Initialized
DEBUG - 2011-05-31 14:13:17 --> Loader Class Initialized
DEBUG - 2011-05-31 14:13:17 --> Controller Class Initialized
DEBUG - 2011-05-31 14:13:17 --> Model Class Initialized
DEBUG - 2011-05-31 14:13:17 --> Model Class Initialized
DEBUG - 2011-05-31 14:13:17 --> Model Class Initialized
DEBUG - 2011-05-31 14:13:17 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-31 14:13:17 --> Database Driver Class Initialized
DEBUG - 2011-05-31 14:13:18 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-31 14:13:18 --> Helper loaded: url_helper
DEBUG - 2011-05-31 14:13:18 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-31 14:13:18 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-31 14:13:18 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-31 14:13:18 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-31 14:13:18 --> Final output sent to browser
DEBUG - 2011-05-31 14:13:18 --> Total execution time: 0.3264
DEBUG - 2011-05-31 14:13:29 --> Config Class Initialized
DEBUG - 2011-05-31 14:13:29 --> Hooks Class Initialized
DEBUG - 2011-05-31 14:13:29 --> Utf8 Class Initialized
DEBUG - 2011-05-31 14:13:29 --> UTF-8 Support Enabled
DEBUG - 2011-05-31 14:13:29 --> URI Class Initialized
DEBUG - 2011-05-31 14:13:29 --> Router Class Initialized
DEBUG - 2011-05-31 14:13:29 --> Output Class Initialized
DEBUG - 2011-05-31 14:13:29 --> Input Class Initialized
DEBUG - 2011-05-31 14:13:29 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-31 14:13:29 --> Language Class Initialized
DEBUG - 2011-05-31 14:13:29 --> Loader Class Initialized
DEBUG - 2011-05-31 14:13:29 --> Controller Class Initialized
DEBUG - 2011-05-31 14:13:29 --> Model Class Initialized
DEBUG - 2011-05-31 14:13:29 --> Model Class Initialized
DEBUG - 2011-05-31 14:13:29 --> Model Class Initialized
DEBUG - 2011-05-31 14:13:29 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-31 14:13:29 --> Database Driver Class Initialized
DEBUG - 2011-05-31 14:13:29 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-31 14:13:29 --> Helper loaded: url_helper
DEBUG - 2011-05-31 14:13:29 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-31 14:13:29 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-31 14:13:29 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-31 14:13:29 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-31 14:13:29 --> Final output sent to browser
DEBUG - 2011-05-31 14:13:29 --> Total execution time: 0.0894
DEBUG - 2011-05-31 14:13:35 --> Config Class Initialized
DEBUG - 2011-05-31 14:13:35 --> Hooks Class Initialized
DEBUG - 2011-05-31 14:13:35 --> Utf8 Class Initialized
DEBUG - 2011-05-31 14:13:35 --> UTF-8 Support Enabled
DEBUG - 2011-05-31 14:13:35 --> URI Class Initialized
DEBUG - 2011-05-31 14:13:35 --> Router Class Initialized
DEBUG - 2011-05-31 14:13:35 --> Output Class Initialized
DEBUG - 2011-05-31 14:13:35 --> Input Class Initialized
DEBUG - 2011-05-31 14:13:35 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-31 14:13:35 --> Language Class Initialized
DEBUG - 2011-05-31 14:13:35 --> Loader Class Initialized
DEBUG - 2011-05-31 14:13:35 --> Controller Class Initialized
DEBUG - 2011-05-31 14:13:35 --> Model Class Initialized
DEBUG - 2011-05-31 14:13:35 --> Model Class Initialized
DEBUG - 2011-05-31 14:13:35 --> Model Class Initialized
DEBUG - 2011-05-31 14:13:35 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-31 14:13:35 --> Database Driver Class Initialized
DEBUG - 2011-05-31 14:13:35 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-31 14:13:35 --> Helper loaded: url_helper
DEBUG - 2011-05-31 14:13:35 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-31 14:13:35 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-31 14:13:35 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-31 14:13:35 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-31 14:13:35 --> Final output sent to browser
DEBUG - 2011-05-31 14:13:35 --> Total execution time: 0.2273
DEBUG - 2011-05-31 14:13:50 --> Config Class Initialized
DEBUG - 2011-05-31 14:13:50 --> Hooks Class Initialized
DEBUG - 2011-05-31 14:13:50 --> Utf8 Class Initialized
DEBUG - 2011-05-31 14:13:50 --> UTF-8 Support Enabled
DEBUG - 2011-05-31 14:13:50 --> URI Class Initialized
DEBUG - 2011-05-31 14:13:50 --> Router Class Initialized
DEBUG - 2011-05-31 14:13:50 --> Output Class Initialized
DEBUG - 2011-05-31 14:13:50 --> Input Class Initialized
DEBUG - 2011-05-31 14:13:50 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-31 14:13:50 --> Language Class Initialized
DEBUG - 2011-05-31 14:13:50 --> Loader Class Initialized
DEBUG - 2011-05-31 14:13:50 --> Controller Class Initialized
DEBUG - 2011-05-31 14:13:50 --> Model Class Initialized
DEBUG - 2011-05-31 14:13:50 --> Model Class Initialized
DEBUG - 2011-05-31 14:13:50 --> Model Class Initialized
DEBUG - 2011-05-31 14:13:50 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-31 14:13:50 --> Database Driver Class Initialized
DEBUG - 2011-05-31 14:13:50 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-31 14:13:50 --> Helper loaded: url_helper
DEBUG - 2011-05-31 14:13:50 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-31 14:13:50 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-31 14:13:50 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-31 14:13:50 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-31 14:13:50 --> Final output sent to browser
DEBUG - 2011-05-31 14:13:50 --> Total execution time: 0.2524
DEBUG - 2011-05-31 14:14:03 --> Config Class Initialized
DEBUG - 2011-05-31 14:14:03 --> Hooks Class Initialized
DEBUG - 2011-05-31 14:14:03 --> Utf8 Class Initialized
DEBUG - 2011-05-31 14:14:03 --> UTF-8 Support Enabled
DEBUG - 2011-05-31 14:14:03 --> URI Class Initialized
DEBUG - 2011-05-31 14:14:03 --> Router Class Initialized
DEBUG - 2011-05-31 14:14:03 --> Output Class Initialized
DEBUG - 2011-05-31 14:14:03 --> Input Class Initialized
DEBUG - 2011-05-31 14:14:03 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-31 14:14:03 --> Language Class Initialized
DEBUG - 2011-05-31 14:14:03 --> Loader Class Initialized
DEBUG - 2011-05-31 14:14:03 --> Controller Class Initialized
DEBUG - 2011-05-31 14:14:03 --> Model Class Initialized
DEBUG - 2011-05-31 14:14:03 --> Model Class Initialized
DEBUG - 2011-05-31 14:14:03 --> Model Class Initialized
DEBUG - 2011-05-31 14:14:03 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-31 14:14:03 --> Database Driver Class Initialized
DEBUG - 2011-05-31 14:14:04 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-31 14:14:04 --> Helper loaded: url_helper
DEBUG - 2011-05-31 14:14:04 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-31 14:14:04 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-31 14:14:04 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-31 14:14:04 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-31 14:14:04 --> Final output sent to browser
DEBUG - 2011-05-31 14:14:04 --> Total execution time: 0.6160
DEBUG - 2011-05-31 14:14:22 --> Config Class Initialized
DEBUG - 2011-05-31 14:14:22 --> Hooks Class Initialized
DEBUG - 2011-05-31 14:14:22 --> Utf8 Class Initialized
DEBUG - 2011-05-31 14:14:22 --> UTF-8 Support Enabled
DEBUG - 2011-05-31 14:14:22 --> URI Class Initialized
DEBUG - 2011-05-31 14:14:22 --> Router Class Initialized
DEBUG - 2011-05-31 14:14:22 --> Output Class Initialized
DEBUG - 2011-05-31 14:14:22 --> Input Class Initialized
DEBUG - 2011-05-31 14:14:22 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-31 14:14:22 --> Language Class Initialized
DEBUG - 2011-05-31 14:14:22 --> Loader Class Initialized
DEBUG - 2011-05-31 14:14:22 --> Controller Class Initialized
DEBUG - 2011-05-31 14:14:22 --> Model Class Initialized
DEBUG - 2011-05-31 14:14:22 --> Model Class Initialized
DEBUG - 2011-05-31 14:14:22 --> Model Class Initialized
DEBUG - 2011-05-31 14:14:22 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-31 14:14:22 --> Database Driver Class Initialized
DEBUG - 2011-05-31 14:14:22 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-31 14:14:22 --> Helper loaded: url_helper
DEBUG - 2011-05-31 14:14:22 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-31 14:14:22 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-31 14:14:22 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-31 14:14:22 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-31 14:14:22 --> Final output sent to browser
DEBUG - 2011-05-31 14:14:22 --> Total execution time: 0.2634
DEBUG - 2011-05-31 14:40:10 --> Config Class Initialized
DEBUG - 2011-05-31 14:40:10 --> Hooks Class Initialized
DEBUG - 2011-05-31 14:40:10 --> Utf8 Class Initialized
DEBUG - 2011-05-31 14:40:10 --> UTF-8 Support Enabled
DEBUG - 2011-05-31 14:40:10 --> URI Class Initialized
DEBUG - 2011-05-31 14:40:10 --> Router Class Initialized
ERROR - 2011-05-31 14:40:10 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-05-31 14:41:01 --> Config Class Initialized
DEBUG - 2011-05-31 14:41:01 --> Hooks Class Initialized
DEBUG - 2011-05-31 14:41:01 --> Utf8 Class Initialized
DEBUG - 2011-05-31 14:41:01 --> UTF-8 Support Enabled
DEBUG - 2011-05-31 14:41:01 --> URI Class Initialized
DEBUG - 2011-05-31 14:41:01 --> Router Class Initialized
DEBUG - 2011-05-31 14:41:01 --> Output Class Initialized
DEBUG - 2011-05-31 14:41:01 --> Input Class Initialized
DEBUG - 2011-05-31 14:41:01 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-31 14:41:01 --> Language Class Initialized
DEBUG - 2011-05-31 14:41:01 --> Loader Class Initialized
DEBUG - 2011-05-31 14:41:01 --> Controller Class Initialized
DEBUG - 2011-05-31 14:41:01 --> Model Class Initialized
DEBUG - 2011-05-31 14:41:01 --> Model Class Initialized
DEBUG - 2011-05-31 14:41:01 --> Model Class Initialized
DEBUG - 2011-05-31 14:41:01 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-31 14:41:01 --> Database Driver Class Initialized
DEBUG - 2011-05-31 14:41:02 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-31 14:41:02 --> Helper loaded: url_helper
DEBUG - 2011-05-31 14:41:02 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-31 14:41:02 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-31 14:41:02 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-31 14:41:02 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-31 14:41:02 --> Final output sent to browser
DEBUG - 2011-05-31 14:41:02 --> Total execution time: 0.7869
DEBUG - 2011-05-31 15:33:57 --> Config Class Initialized
DEBUG - 2011-05-31 15:33:57 --> Hooks Class Initialized
DEBUG - 2011-05-31 15:33:57 --> Utf8 Class Initialized
DEBUG - 2011-05-31 15:33:57 --> UTF-8 Support Enabled
DEBUG - 2011-05-31 15:33:57 --> URI Class Initialized
DEBUG - 2011-05-31 15:33:57 --> Router Class Initialized
DEBUG - 2011-05-31 15:33:57 --> No URI present. Default controller set.
DEBUG - 2011-05-31 15:33:57 --> Output Class Initialized
DEBUG - 2011-05-31 15:33:57 --> Input Class Initialized
DEBUG - 2011-05-31 15:33:57 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-31 15:33:57 --> Language Class Initialized
DEBUG - 2011-05-31 15:33:57 --> Loader Class Initialized
DEBUG - 2011-05-31 15:33:57 --> Controller Class Initialized
DEBUG - 2011-05-31 15:33:57 --> File loaded: application/views/splash/main.php
DEBUG - 2011-05-31 15:33:57 --> Helper loaded: url_helper
DEBUG - 2011-05-31 15:33:57 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-31 15:33:57 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-31 15:33:57 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-31 15:33:57 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-31 15:33:57 --> Final output sent to browser
DEBUG - 2011-05-31 15:33:57 --> Total execution time: 0.1905
DEBUG - 2011-05-31 15:34:00 --> Config Class Initialized
DEBUG - 2011-05-31 15:34:00 --> Hooks Class Initialized
DEBUG - 2011-05-31 15:34:00 --> Utf8 Class Initialized
DEBUG - 2011-05-31 15:34:00 --> UTF-8 Support Enabled
DEBUG - 2011-05-31 15:34:00 --> URI Class Initialized
DEBUG - 2011-05-31 15:34:00 --> Router Class Initialized
DEBUG - 2011-05-31 15:34:00 --> No URI present. Default controller set.
DEBUG - 2011-05-31 15:34:00 --> Output Class Initialized
DEBUG - 2011-05-31 15:34:00 --> Input Class Initialized
DEBUG - 2011-05-31 15:34:00 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-31 15:34:00 --> Language Class Initialized
DEBUG - 2011-05-31 15:34:00 --> Loader Class Initialized
DEBUG - 2011-05-31 15:34:00 --> Controller Class Initialized
DEBUG - 2011-05-31 15:34:00 --> File loaded: application/views/splash/main.php
DEBUG - 2011-05-31 15:34:00 --> Helper loaded: url_helper
DEBUG - 2011-05-31 15:34:00 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-31 15:34:00 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-31 15:34:00 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-31 15:34:00 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-31 15:34:00 --> Final output sent to browser
DEBUG - 2011-05-31 15:34:00 --> Total execution time: 0.0189
DEBUG - 2011-05-31 15:34:05 --> Config Class Initialized
DEBUG - 2011-05-31 15:34:05 --> Hooks Class Initialized
DEBUG - 2011-05-31 15:34:05 --> Utf8 Class Initialized
DEBUG - 2011-05-31 15:34:05 --> UTF-8 Support Enabled
DEBUG - 2011-05-31 15:34:05 --> URI Class Initialized
DEBUG - 2011-05-31 15:34:05 --> Router Class Initialized
DEBUG - 2011-05-31 15:34:05 --> Output Class Initialized
DEBUG - 2011-05-31 15:34:05 --> Input Class Initialized
DEBUG - 2011-05-31 15:34:05 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-31 15:34:05 --> Language Class Initialized
DEBUG - 2011-05-31 15:34:05 --> Loader Class Initialized
DEBUG - 2011-05-31 15:34:05 --> Controller Class Initialized
ERROR - 2011-05-31 15:34:05 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-31 15:34:05 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-31 15:34:05 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-31 15:34:05 --> Model Class Initialized
DEBUG - 2011-05-31 15:34:05 --> Model Class Initialized
DEBUG - 2011-05-31 15:34:05 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-31 15:34:05 --> Database Driver Class Initialized
DEBUG - 2011-05-31 15:34:05 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-31 15:34:05 --> Helper loaded: url_helper
DEBUG - 2011-05-31 15:34:05 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-31 15:34:05 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-31 15:34:05 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-31 15:34:05 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-31 15:34:05 --> Final output sent to browser
DEBUG - 2011-05-31 15:34:05 --> Total execution time: 0.1145
DEBUG - 2011-05-31 15:34:07 --> Config Class Initialized
DEBUG - 2011-05-31 15:34:07 --> Hooks Class Initialized
DEBUG - 2011-05-31 15:34:07 --> Utf8 Class Initialized
DEBUG - 2011-05-31 15:34:07 --> UTF-8 Support Enabled
DEBUG - 2011-05-31 15:34:07 --> URI Class Initialized
DEBUG - 2011-05-31 15:34:07 --> Router Class Initialized
DEBUG - 2011-05-31 15:34:07 --> Output Class Initialized
DEBUG - 2011-05-31 15:34:07 --> Input Class Initialized
DEBUG - 2011-05-31 15:34:07 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-31 15:34:07 --> Language Class Initialized
DEBUG - 2011-05-31 15:34:07 --> Loader Class Initialized
DEBUG - 2011-05-31 15:34:07 --> Controller Class Initialized
DEBUG - 2011-05-31 15:34:07 --> Model Class Initialized
DEBUG - 2011-05-31 15:34:07 --> Model Class Initialized
DEBUG - 2011-05-31 15:34:07 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-31 15:34:07 --> Database Driver Class Initialized
DEBUG - 2011-05-31 15:34:07 --> Final output sent to browser
DEBUG - 2011-05-31 15:34:07 --> Total execution time: 0.6895
DEBUG - 2011-05-31 15:35:09 --> Config Class Initialized
DEBUG - 2011-05-31 15:35:09 --> Hooks Class Initialized
DEBUG - 2011-05-31 15:35:09 --> Utf8 Class Initialized
DEBUG - 2011-05-31 15:35:09 --> UTF-8 Support Enabled
DEBUG - 2011-05-31 15:35:09 --> URI Class Initialized
DEBUG - 2011-05-31 15:35:09 --> Router Class Initialized
DEBUG - 2011-05-31 15:35:09 --> Output Class Initialized
DEBUG - 2011-05-31 15:35:09 --> Input Class Initialized
DEBUG - 2011-05-31 15:35:09 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-31 15:35:09 --> Language Class Initialized
DEBUG - 2011-05-31 15:35:09 --> Loader Class Initialized
DEBUG - 2011-05-31 15:35:09 --> Controller Class Initialized
ERROR - 2011-05-31 15:35:09 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-31 15:35:09 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-31 15:35:09 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-31 15:35:09 --> Model Class Initialized
DEBUG - 2011-05-31 15:35:09 --> Model Class Initialized
DEBUG - 2011-05-31 15:35:09 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-31 15:35:09 --> Database Driver Class Initialized
DEBUG - 2011-05-31 15:35:09 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-31 15:35:09 --> Helper loaded: url_helper
DEBUG - 2011-05-31 15:35:09 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-31 15:35:09 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-31 15:35:09 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-31 15:35:09 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-31 15:35:09 --> Final output sent to browser
DEBUG - 2011-05-31 15:35:09 --> Total execution time: 0.0663
DEBUG - 2011-05-31 15:35:10 --> Config Class Initialized
DEBUG - 2011-05-31 15:35:10 --> Hooks Class Initialized
DEBUG - 2011-05-31 15:35:10 --> Utf8 Class Initialized
DEBUG - 2011-05-31 15:35:10 --> UTF-8 Support Enabled
DEBUG - 2011-05-31 15:35:10 --> URI Class Initialized
DEBUG - 2011-05-31 15:35:10 --> Router Class Initialized
DEBUG - 2011-05-31 15:35:10 --> Output Class Initialized
DEBUG - 2011-05-31 15:35:10 --> Input Class Initialized
DEBUG - 2011-05-31 15:35:10 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-31 15:35:10 --> Language Class Initialized
DEBUG - 2011-05-31 15:35:10 --> Loader Class Initialized
DEBUG - 2011-05-31 15:35:10 --> Controller Class Initialized
DEBUG - 2011-05-31 15:35:10 --> Model Class Initialized
DEBUG - 2011-05-31 15:35:10 --> Model Class Initialized
DEBUG - 2011-05-31 15:35:10 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-31 15:35:10 --> Database Driver Class Initialized
DEBUG - 2011-05-31 15:35:11 --> Final output sent to browser
DEBUG - 2011-05-31 15:35:11 --> Total execution time: 0.6641
DEBUG - 2011-05-31 15:35:14 --> Config Class Initialized
DEBUG - 2011-05-31 15:35:14 --> Hooks Class Initialized
DEBUG - 2011-05-31 15:35:14 --> Utf8 Class Initialized
DEBUG - 2011-05-31 15:35:14 --> UTF-8 Support Enabled
DEBUG - 2011-05-31 15:35:14 --> URI Class Initialized
DEBUG - 2011-05-31 15:35:14 --> Router Class Initialized
DEBUG - 2011-05-31 15:35:14 --> Output Class Initialized
DEBUG - 2011-05-31 15:35:14 --> Input Class Initialized
DEBUG - 2011-05-31 15:35:14 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-31 15:35:14 --> Language Class Initialized
DEBUG - 2011-05-31 15:35:14 --> Loader Class Initialized
DEBUG - 2011-05-31 15:35:14 --> Controller Class Initialized
ERROR - 2011-05-31 15:35:14 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-31 15:35:14 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-31 15:35:14 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-31 15:35:14 --> Model Class Initialized
DEBUG - 2011-05-31 15:35:14 --> Model Class Initialized
DEBUG - 2011-05-31 15:35:14 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-31 15:35:14 --> Database Driver Class Initialized
DEBUG - 2011-05-31 15:35:14 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-31 15:35:14 --> Helper loaded: url_helper
DEBUG - 2011-05-31 15:35:14 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-31 15:35:14 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-31 15:35:14 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-31 15:35:14 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-31 15:35:14 --> Final output sent to browser
DEBUG - 2011-05-31 15:35:14 --> Total execution time: 0.0286
DEBUG - 2011-05-31 15:35:31 --> Config Class Initialized
DEBUG - 2011-05-31 15:35:31 --> Hooks Class Initialized
DEBUG - 2011-05-31 15:35:31 --> Utf8 Class Initialized
DEBUG - 2011-05-31 15:35:31 --> UTF-8 Support Enabled
DEBUG - 2011-05-31 15:35:31 --> URI Class Initialized
DEBUG - 2011-05-31 15:35:31 --> Router Class Initialized
DEBUG - 2011-05-31 15:35:31 --> Output Class Initialized
DEBUG - 2011-05-31 15:35:31 --> Input Class Initialized
DEBUG - 2011-05-31 15:35:31 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-31 15:35:31 --> Language Class Initialized
DEBUG - 2011-05-31 15:35:31 --> Loader Class Initialized
DEBUG - 2011-05-31 15:35:31 --> Controller Class Initialized
ERROR - 2011-05-31 15:35:31 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-31 15:35:31 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-31 15:35:31 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-31 15:35:31 --> Model Class Initialized
DEBUG - 2011-05-31 15:35:31 --> Model Class Initialized
DEBUG - 2011-05-31 15:35:31 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-31 15:35:31 --> Database Driver Class Initialized
DEBUG - 2011-05-31 15:35:31 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-31 15:35:31 --> Helper loaded: url_helper
DEBUG - 2011-05-31 15:35:31 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-31 15:35:31 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-31 15:35:31 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-31 15:35:31 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-31 15:35:31 --> Final output sent to browser
DEBUG - 2011-05-31 15:35:31 --> Total execution time: 0.0313
DEBUG - 2011-05-31 15:35:33 --> Config Class Initialized
DEBUG - 2011-05-31 15:35:33 --> Hooks Class Initialized
DEBUG - 2011-05-31 15:35:33 --> Utf8 Class Initialized
DEBUG - 2011-05-31 15:35:33 --> UTF-8 Support Enabled
DEBUG - 2011-05-31 15:35:33 --> URI Class Initialized
DEBUG - 2011-05-31 15:35:33 --> Router Class Initialized
DEBUG - 2011-05-31 15:35:33 --> Output Class Initialized
DEBUG - 2011-05-31 15:35:33 --> Input Class Initialized
DEBUG - 2011-05-31 15:35:33 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-31 15:35:33 --> Language Class Initialized
DEBUG - 2011-05-31 15:35:33 --> Loader Class Initialized
DEBUG - 2011-05-31 15:35:33 --> Controller Class Initialized
DEBUG - 2011-05-31 15:35:33 --> Model Class Initialized
DEBUG - 2011-05-31 15:35:33 --> Model Class Initialized
DEBUG - 2011-05-31 15:35:33 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-31 15:35:33 --> Database Driver Class Initialized
DEBUG - 2011-05-31 15:35:33 --> Final output sent to browser
DEBUG - 2011-05-31 15:35:33 --> Total execution time: 0.5339
DEBUG - 2011-05-31 15:35:44 --> Config Class Initialized
DEBUG - 2011-05-31 15:35:44 --> Hooks Class Initialized
DEBUG - 2011-05-31 15:35:44 --> Utf8 Class Initialized
DEBUG - 2011-05-31 15:35:44 --> UTF-8 Support Enabled
DEBUG - 2011-05-31 15:35:44 --> URI Class Initialized
DEBUG - 2011-05-31 15:35:44 --> Router Class Initialized
DEBUG - 2011-05-31 15:35:44 --> Output Class Initialized
DEBUG - 2011-05-31 15:35:44 --> Input Class Initialized
DEBUG - 2011-05-31 15:35:44 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-31 15:35:44 --> Language Class Initialized
DEBUG - 2011-05-31 15:35:44 --> Loader Class Initialized
DEBUG - 2011-05-31 15:35:44 --> Controller Class Initialized
ERROR - 2011-05-31 15:35:44 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-31 15:35:44 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-31 15:35:44 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-31 15:35:44 --> Model Class Initialized
DEBUG - 2011-05-31 15:35:44 --> Model Class Initialized
DEBUG - 2011-05-31 15:35:44 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-31 15:35:44 --> Database Driver Class Initialized
DEBUG - 2011-05-31 15:35:44 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-31 15:35:44 --> Helper loaded: url_helper
DEBUG - 2011-05-31 15:35:44 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-31 15:35:44 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-31 15:35:44 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-31 15:35:44 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-31 15:35:44 --> Final output sent to browser
DEBUG - 2011-05-31 15:35:44 --> Total execution time: 0.0672
DEBUG - 2011-05-31 15:35:45 --> Config Class Initialized
DEBUG - 2011-05-31 15:35:45 --> Hooks Class Initialized
DEBUG - 2011-05-31 15:35:45 --> Utf8 Class Initialized
DEBUG - 2011-05-31 15:35:45 --> UTF-8 Support Enabled
DEBUG - 2011-05-31 15:35:45 --> URI Class Initialized
DEBUG - 2011-05-31 15:35:45 --> Router Class Initialized
DEBUG - 2011-05-31 15:35:45 --> Output Class Initialized
DEBUG - 2011-05-31 15:35:45 --> Input Class Initialized
DEBUG - 2011-05-31 15:35:45 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-31 15:35:45 --> Language Class Initialized
DEBUG - 2011-05-31 15:35:45 --> Loader Class Initialized
DEBUG - 2011-05-31 15:35:45 --> Controller Class Initialized
DEBUG - 2011-05-31 15:35:45 --> Model Class Initialized
DEBUG - 2011-05-31 15:35:45 --> Model Class Initialized
DEBUG - 2011-05-31 15:35:45 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-31 15:35:45 --> Database Driver Class Initialized
DEBUG - 2011-05-31 15:35:45 --> Final output sent to browser
DEBUG - 2011-05-31 15:35:45 --> Total execution time: 0.6267
DEBUG - 2011-05-31 15:36:07 --> Config Class Initialized
DEBUG - 2011-05-31 15:36:07 --> Hooks Class Initialized
DEBUG - 2011-05-31 15:36:07 --> Utf8 Class Initialized
DEBUG - 2011-05-31 15:36:07 --> UTF-8 Support Enabled
DEBUG - 2011-05-31 15:36:07 --> URI Class Initialized
DEBUG - 2011-05-31 15:36:07 --> Router Class Initialized
DEBUG - 2011-05-31 15:36:07 --> Output Class Initialized
DEBUG - 2011-05-31 15:36:07 --> Input Class Initialized
DEBUG - 2011-05-31 15:36:07 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-31 15:36:07 --> Language Class Initialized
DEBUG - 2011-05-31 15:36:07 --> Loader Class Initialized
DEBUG - 2011-05-31 15:36:07 --> Controller Class Initialized
ERROR - 2011-05-31 15:36:07 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-31 15:36:07 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-31 15:36:07 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-31 15:36:07 --> Model Class Initialized
DEBUG - 2011-05-31 15:36:07 --> Model Class Initialized
DEBUG - 2011-05-31 15:36:07 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-31 15:36:07 --> Database Driver Class Initialized
DEBUG - 2011-05-31 15:36:07 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-31 15:36:07 --> Helper loaded: url_helper
DEBUG - 2011-05-31 15:36:07 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-31 15:36:07 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-31 15:36:07 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-31 15:36:07 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-31 15:36:07 --> Final output sent to browser
DEBUG - 2011-05-31 15:36:07 --> Total execution time: 0.0337
DEBUG - 2011-05-31 15:36:10 --> Config Class Initialized
DEBUG - 2011-05-31 15:36:10 --> Hooks Class Initialized
DEBUG - 2011-05-31 15:36:10 --> Utf8 Class Initialized
DEBUG - 2011-05-31 15:36:10 --> UTF-8 Support Enabled
DEBUG - 2011-05-31 15:36:10 --> URI Class Initialized
DEBUG - 2011-05-31 15:36:10 --> Router Class Initialized
DEBUG - 2011-05-31 15:36:10 --> Output Class Initialized
DEBUG - 2011-05-31 15:36:10 --> Input Class Initialized
DEBUG - 2011-05-31 15:36:10 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-31 15:36:10 --> Language Class Initialized
DEBUG - 2011-05-31 15:36:10 --> Loader Class Initialized
DEBUG - 2011-05-31 15:36:10 --> Controller Class Initialized
DEBUG - 2011-05-31 15:36:10 --> Model Class Initialized
DEBUG - 2011-05-31 15:36:10 --> Model Class Initialized
DEBUG - 2011-05-31 15:36:10 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-31 15:36:10 --> Database Driver Class Initialized
DEBUG - 2011-05-31 15:36:10 --> Final output sent to browser
DEBUG - 2011-05-31 15:36:10 --> Total execution time: 0.7465
DEBUG - 2011-05-31 15:36:46 --> Config Class Initialized
DEBUG - 2011-05-31 15:36:46 --> Hooks Class Initialized
DEBUG - 2011-05-31 15:36:46 --> Utf8 Class Initialized
DEBUG - 2011-05-31 15:36:46 --> UTF-8 Support Enabled
DEBUG - 2011-05-31 15:36:46 --> URI Class Initialized
DEBUG - 2011-05-31 15:36:46 --> Router Class Initialized
DEBUG - 2011-05-31 15:36:46 --> Output Class Initialized
DEBUG - 2011-05-31 15:36:46 --> Input Class Initialized
DEBUG - 2011-05-31 15:36:46 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-31 15:36:46 --> Language Class Initialized
DEBUG - 2011-05-31 15:36:46 --> Loader Class Initialized
DEBUG - 2011-05-31 15:36:46 --> Controller Class Initialized
ERROR - 2011-05-31 15:36:46 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-31 15:36:46 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-31 15:36:46 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-31 15:36:46 --> Model Class Initialized
DEBUG - 2011-05-31 15:36:46 --> Model Class Initialized
DEBUG - 2011-05-31 15:36:46 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-31 15:36:46 --> Database Driver Class Initialized
DEBUG - 2011-05-31 15:36:46 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-31 15:36:46 --> Helper loaded: url_helper
DEBUG - 2011-05-31 15:36:46 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-31 15:36:46 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-31 15:36:46 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-31 15:36:46 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-31 15:36:46 --> Final output sent to browser
DEBUG - 2011-05-31 15:36:46 --> Total execution time: 0.0274
DEBUG - 2011-05-31 15:36:47 --> Config Class Initialized
DEBUG - 2011-05-31 15:36:47 --> Hooks Class Initialized
DEBUG - 2011-05-31 15:36:47 --> Utf8 Class Initialized
DEBUG - 2011-05-31 15:36:47 --> UTF-8 Support Enabled
DEBUG - 2011-05-31 15:36:47 --> URI Class Initialized
DEBUG - 2011-05-31 15:36:47 --> Router Class Initialized
DEBUG - 2011-05-31 15:36:47 --> Output Class Initialized
DEBUG - 2011-05-31 15:36:47 --> Input Class Initialized
DEBUG - 2011-05-31 15:36:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-31 15:36:47 --> Language Class Initialized
DEBUG - 2011-05-31 15:36:47 --> Loader Class Initialized
DEBUG - 2011-05-31 15:36:47 --> Controller Class Initialized
ERROR - 2011-05-31 15:36:47 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-31 15:36:47 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-31 15:36:47 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-31 15:36:47 --> Model Class Initialized
DEBUG - 2011-05-31 15:36:47 --> Model Class Initialized
DEBUG - 2011-05-31 15:36:47 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-31 15:36:47 --> Database Driver Class Initialized
DEBUG - 2011-05-31 15:36:47 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-31 15:36:47 --> Helper loaded: url_helper
DEBUG - 2011-05-31 15:36:47 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-31 15:36:47 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-31 15:36:47 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-31 15:36:47 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-31 15:36:47 --> Final output sent to browser
DEBUG - 2011-05-31 15:36:47 --> Total execution time: 0.0297
DEBUG - 2011-05-31 15:36:47 --> Config Class Initialized
DEBUG - 2011-05-31 15:36:47 --> Hooks Class Initialized
DEBUG - 2011-05-31 15:36:47 --> Utf8 Class Initialized
DEBUG - 2011-05-31 15:36:47 --> UTF-8 Support Enabled
DEBUG - 2011-05-31 15:36:47 --> URI Class Initialized
DEBUG - 2011-05-31 15:36:47 --> Router Class Initialized
DEBUG - 2011-05-31 15:36:47 --> Output Class Initialized
DEBUG - 2011-05-31 15:36:47 --> Input Class Initialized
DEBUG - 2011-05-31 15:36:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-31 15:36:47 --> Language Class Initialized
DEBUG - 2011-05-31 15:36:47 --> Loader Class Initialized
DEBUG - 2011-05-31 15:36:47 --> Controller Class Initialized
DEBUG - 2011-05-31 15:36:47 --> Model Class Initialized
DEBUG - 2011-05-31 15:36:47 --> Model Class Initialized
DEBUG - 2011-05-31 15:36:47 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-31 15:36:47 --> Database Driver Class Initialized
DEBUG - 2011-05-31 15:36:49 --> Final output sent to browser
DEBUG - 2011-05-31 15:36:49 --> Total execution time: 1.2618
DEBUG - 2011-05-31 15:37:04 --> Config Class Initialized
DEBUG - 2011-05-31 15:37:04 --> Hooks Class Initialized
DEBUG - 2011-05-31 15:37:04 --> Utf8 Class Initialized
DEBUG - 2011-05-31 15:37:04 --> UTF-8 Support Enabled
DEBUG - 2011-05-31 15:37:04 --> URI Class Initialized
DEBUG - 2011-05-31 15:37:04 --> Router Class Initialized
DEBUG - 2011-05-31 15:37:04 --> Output Class Initialized
DEBUG - 2011-05-31 15:37:04 --> Input Class Initialized
DEBUG - 2011-05-31 15:37:04 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-31 15:37:04 --> Language Class Initialized
DEBUG - 2011-05-31 15:37:04 --> Loader Class Initialized
DEBUG - 2011-05-31 15:37:04 --> Controller Class Initialized
ERROR - 2011-05-31 15:37:04 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-31 15:37:04 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-31 15:37:04 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-31 15:37:04 --> Model Class Initialized
DEBUG - 2011-05-31 15:37:04 --> Model Class Initialized
DEBUG - 2011-05-31 15:37:04 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-31 15:37:04 --> Database Driver Class Initialized
DEBUG - 2011-05-31 15:37:04 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-31 15:37:04 --> Helper loaded: url_helper
DEBUG - 2011-05-31 15:37:04 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-31 15:37:04 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-31 15:37:04 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-31 15:37:04 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-31 15:37:04 --> Final output sent to browser
DEBUG - 2011-05-31 15:37:04 --> Total execution time: 0.0614
DEBUG - 2011-05-31 15:37:05 --> Config Class Initialized
DEBUG - 2011-05-31 15:37:05 --> Hooks Class Initialized
DEBUG - 2011-05-31 15:37:05 --> Utf8 Class Initialized
DEBUG - 2011-05-31 15:37:05 --> UTF-8 Support Enabled
DEBUG - 2011-05-31 15:37:05 --> URI Class Initialized
DEBUG - 2011-05-31 15:37:05 --> Router Class Initialized
DEBUG - 2011-05-31 15:37:05 --> Output Class Initialized
DEBUG - 2011-05-31 15:37:05 --> Input Class Initialized
DEBUG - 2011-05-31 15:37:05 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-31 15:37:05 --> Language Class Initialized
DEBUG - 2011-05-31 15:37:05 --> Loader Class Initialized
DEBUG - 2011-05-31 15:37:05 --> Controller Class Initialized
DEBUG - 2011-05-31 15:37:05 --> Model Class Initialized
DEBUG - 2011-05-31 15:37:05 --> Model Class Initialized
DEBUG - 2011-05-31 15:37:05 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-31 15:37:05 --> Database Driver Class Initialized
DEBUG - 2011-05-31 15:37:06 --> Final output sent to browser
DEBUG - 2011-05-31 15:37:06 --> Total execution time: 0.5177
DEBUG - 2011-05-31 15:37:26 --> Config Class Initialized
DEBUG - 2011-05-31 15:37:26 --> Hooks Class Initialized
DEBUG - 2011-05-31 15:37:26 --> Utf8 Class Initialized
DEBUG - 2011-05-31 15:37:26 --> UTF-8 Support Enabled
DEBUG - 2011-05-31 15:37:26 --> URI Class Initialized
DEBUG - 2011-05-31 15:37:26 --> Router Class Initialized
DEBUG - 2011-05-31 15:37:26 --> Output Class Initialized
DEBUG - 2011-05-31 15:37:26 --> Input Class Initialized
DEBUG - 2011-05-31 15:37:26 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-31 15:37:26 --> Language Class Initialized
DEBUG - 2011-05-31 15:37:26 --> Loader Class Initialized
DEBUG - 2011-05-31 15:37:26 --> Controller Class Initialized
ERROR - 2011-05-31 15:37:26 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-31 15:37:26 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-31 15:37:26 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-31 15:37:26 --> Model Class Initialized
DEBUG - 2011-05-31 15:37:26 --> Model Class Initialized
DEBUG - 2011-05-31 15:37:26 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-31 15:37:26 --> Database Driver Class Initialized
DEBUG - 2011-05-31 15:37:26 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-31 15:37:26 --> Helper loaded: url_helper
DEBUG - 2011-05-31 15:37:26 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-31 15:37:26 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-31 15:37:26 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-31 15:37:26 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-31 15:37:26 --> Final output sent to browser
DEBUG - 2011-05-31 15:37:26 --> Total execution time: 0.0601
DEBUG - 2011-05-31 15:37:28 --> Config Class Initialized
DEBUG - 2011-05-31 15:37:28 --> Hooks Class Initialized
DEBUG - 2011-05-31 15:37:28 --> Utf8 Class Initialized
DEBUG - 2011-05-31 15:37:28 --> UTF-8 Support Enabled
DEBUG - 2011-05-31 15:37:28 --> URI Class Initialized
DEBUG - 2011-05-31 15:37:28 --> Router Class Initialized
DEBUG - 2011-05-31 15:37:28 --> Output Class Initialized
DEBUG - 2011-05-31 15:37:28 --> Input Class Initialized
DEBUG - 2011-05-31 15:37:28 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-31 15:37:28 --> Language Class Initialized
DEBUG - 2011-05-31 15:37:28 --> Loader Class Initialized
DEBUG - 2011-05-31 15:37:28 --> Controller Class Initialized
DEBUG - 2011-05-31 15:37:28 --> Model Class Initialized
DEBUG - 2011-05-31 15:37:28 --> Model Class Initialized
DEBUG - 2011-05-31 15:37:28 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-31 15:37:28 --> Database Driver Class Initialized
DEBUG - 2011-05-31 15:37:28 --> Final output sent to browser
DEBUG - 2011-05-31 15:37:28 --> Total execution time: 0.6167
DEBUG - 2011-05-31 15:37:43 --> Config Class Initialized
DEBUG - 2011-05-31 15:37:43 --> Hooks Class Initialized
DEBUG - 2011-05-31 15:37:43 --> Utf8 Class Initialized
DEBUG - 2011-05-31 15:37:43 --> UTF-8 Support Enabled
DEBUG - 2011-05-31 15:37:43 --> URI Class Initialized
DEBUG - 2011-05-31 15:37:43 --> Router Class Initialized
DEBUG - 2011-05-31 15:37:43 --> Output Class Initialized
DEBUG - 2011-05-31 15:37:43 --> Input Class Initialized
DEBUG - 2011-05-31 15:37:43 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-31 15:37:43 --> Language Class Initialized
DEBUG - 2011-05-31 15:37:43 --> Loader Class Initialized
DEBUG - 2011-05-31 15:37:43 --> Controller Class Initialized
ERROR - 2011-05-31 15:37:43 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-31 15:37:43 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-31 15:37:43 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-31 15:37:43 --> Model Class Initialized
DEBUG - 2011-05-31 15:37:43 --> Model Class Initialized
DEBUG - 2011-05-31 15:37:43 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-31 15:37:43 --> Database Driver Class Initialized
DEBUG - 2011-05-31 15:37:43 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-31 15:37:43 --> Helper loaded: url_helper
DEBUG - 2011-05-31 15:37:43 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-31 15:37:43 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-31 15:37:43 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-31 15:37:43 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-31 15:37:43 --> Final output sent to browser
DEBUG - 2011-05-31 15:37:43 --> Total execution time: 0.1398
DEBUG - 2011-05-31 15:37:45 --> Config Class Initialized
DEBUG - 2011-05-31 15:37:45 --> Hooks Class Initialized
DEBUG - 2011-05-31 15:37:45 --> Utf8 Class Initialized
DEBUG - 2011-05-31 15:37:45 --> UTF-8 Support Enabled
DEBUG - 2011-05-31 15:37:45 --> URI Class Initialized
DEBUG - 2011-05-31 15:37:45 --> Router Class Initialized
DEBUG - 2011-05-31 15:37:45 --> Output Class Initialized
DEBUG - 2011-05-31 15:37:45 --> Input Class Initialized
DEBUG - 2011-05-31 15:37:45 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-31 15:37:45 --> Language Class Initialized
DEBUG - 2011-05-31 15:37:45 --> Loader Class Initialized
DEBUG - 2011-05-31 15:37:45 --> Controller Class Initialized
DEBUG - 2011-05-31 15:37:45 --> Model Class Initialized
DEBUG - 2011-05-31 15:37:45 --> Model Class Initialized
DEBUG - 2011-05-31 15:37:45 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-31 15:37:45 --> Database Driver Class Initialized
DEBUG - 2011-05-31 15:37:45 --> Final output sent to browser
DEBUG - 2011-05-31 15:37:45 --> Total execution time: 0.6764
DEBUG - 2011-05-31 15:37:45 --> Config Class Initialized
DEBUG - 2011-05-31 15:37:45 --> Hooks Class Initialized
DEBUG - 2011-05-31 15:37:45 --> Utf8 Class Initialized
DEBUG - 2011-05-31 15:37:45 --> UTF-8 Support Enabled
DEBUG - 2011-05-31 15:37:45 --> URI Class Initialized
DEBUG - 2011-05-31 15:37:45 --> Router Class Initialized
DEBUG - 2011-05-31 15:37:45 --> Output Class Initialized
DEBUG - 2011-05-31 15:37:45 --> Input Class Initialized
DEBUG - 2011-05-31 15:37:45 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-31 15:37:45 --> Language Class Initialized
DEBUG - 2011-05-31 15:37:45 --> Loader Class Initialized
DEBUG - 2011-05-31 15:37:45 --> Controller Class Initialized
ERROR - 2011-05-31 15:37:45 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-31 15:37:45 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-31 15:37:45 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-31 15:37:45 --> Model Class Initialized
DEBUG - 2011-05-31 15:37:45 --> Model Class Initialized
DEBUG - 2011-05-31 15:37:45 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-31 15:37:45 --> Database Driver Class Initialized
DEBUG - 2011-05-31 15:37:45 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-31 15:37:45 --> Helper loaded: url_helper
DEBUG - 2011-05-31 15:37:45 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-31 15:37:45 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-31 15:37:45 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-31 15:37:45 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-31 15:37:45 --> Final output sent to browser
DEBUG - 2011-05-31 15:37:45 --> Total execution time: 0.0349
DEBUG - 2011-05-31 15:37:54 --> Config Class Initialized
DEBUG - 2011-05-31 15:37:54 --> Hooks Class Initialized
DEBUG - 2011-05-31 15:37:54 --> Utf8 Class Initialized
DEBUG - 2011-05-31 15:37:54 --> UTF-8 Support Enabled
DEBUG - 2011-05-31 15:37:54 --> URI Class Initialized
DEBUG - 2011-05-31 15:37:54 --> Router Class Initialized
DEBUG - 2011-05-31 15:37:54 --> Output Class Initialized
DEBUG - 2011-05-31 15:37:54 --> Input Class Initialized
DEBUG - 2011-05-31 15:37:54 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-31 15:37:54 --> Language Class Initialized
DEBUG - 2011-05-31 15:37:54 --> Loader Class Initialized
DEBUG - 2011-05-31 15:37:54 --> Controller Class Initialized
ERROR - 2011-05-31 15:37:54 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-31 15:37:54 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-31 15:37:54 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-31 15:37:54 --> Model Class Initialized
DEBUG - 2011-05-31 15:37:54 --> Model Class Initialized
DEBUG - 2011-05-31 15:37:54 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-31 15:37:54 --> Database Driver Class Initialized
DEBUG - 2011-05-31 15:37:54 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-31 15:37:54 --> Helper loaded: url_helper
DEBUG - 2011-05-31 15:37:54 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-31 15:37:54 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-31 15:37:54 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-31 15:37:54 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-31 15:37:54 --> Final output sent to browser
DEBUG - 2011-05-31 15:37:54 --> Total execution time: 0.0348
DEBUG - 2011-05-31 15:37:56 --> Config Class Initialized
DEBUG - 2011-05-31 15:37:56 --> Hooks Class Initialized
DEBUG - 2011-05-31 15:37:56 --> Utf8 Class Initialized
DEBUG - 2011-05-31 15:37:56 --> UTF-8 Support Enabled
DEBUG - 2011-05-31 15:37:56 --> URI Class Initialized
DEBUG - 2011-05-31 15:37:56 --> Router Class Initialized
DEBUG - 2011-05-31 15:37:56 --> Config Class Initialized
DEBUG - 2011-05-31 15:37:56 --> Hooks Class Initialized
DEBUG - 2011-05-31 15:37:56 --> Utf8 Class Initialized
DEBUG - 2011-05-31 15:37:56 --> UTF-8 Support Enabled
DEBUG - 2011-05-31 15:37:56 --> URI Class Initialized
DEBUG - 2011-05-31 15:37:56 --> Router Class Initialized
DEBUG - 2011-05-31 15:37:56 --> Output Class Initialized
DEBUG - 2011-05-31 15:37:56 --> Input Class Initialized
DEBUG - 2011-05-31 15:37:56 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-31 15:37:56 --> Output Class Initialized
DEBUG - 2011-05-31 15:37:56 --> Input Class Initialized
DEBUG - 2011-05-31 15:37:56 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-31 15:37:56 --> Language Class Initialized
DEBUG - 2011-05-31 15:37:56 --> Loader Class Initialized
DEBUG - 2011-05-31 15:37:56 --> Controller Class Initialized
DEBUG - 2011-05-31 15:37:56 --> Language Class Initialized
DEBUG - 2011-05-31 15:37:56 --> Loader Class Initialized
DEBUG - 2011-05-31 15:37:56 --> Controller Class Initialized
DEBUG - 2011-05-31 15:37:56 --> Model Class Initialized
DEBUG - 2011-05-31 15:37:56 --> Model Class Initialized
ERROR - 2011-05-31 15:37:56 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-31 15:37:56 --> Database config for development environment is not found. Trying global config.
ERROR - 2011-05-31 15:37:56 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-31 15:37:56 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-31 15:37:56 --> Model Class Initialized
DEBUG - 2011-05-31 15:37:56 --> Model Class Initialized
DEBUG - 2011-05-31 15:37:56 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-31 15:37:56 --> Database Driver Class Initialized
DEBUG - 2011-05-31 15:37:56 --> Database Driver Class Initialized
DEBUG - 2011-05-31 15:37:56 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-31 15:37:56 --> Helper loaded: url_helper
DEBUG - 2011-05-31 15:37:56 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-31 15:37:56 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-31 15:37:56 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-31 15:37:56 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-31 15:37:56 --> Final output sent to browser
DEBUG - 2011-05-31 15:37:56 --> Total execution time: 0.1173
DEBUG - 2011-05-31 15:37:57 --> Final output sent to browser
DEBUG - 2011-05-31 15:37:57 --> Total execution time: 0.7660
DEBUG - 2011-05-31 15:38:06 --> Config Class Initialized
DEBUG - 2011-05-31 15:38:06 --> Hooks Class Initialized
DEBUG - 2011-05-31 15:38:06 --> Utf8 Class Initialized
DEBUG - 2011-05-31 15:38:06 --> UTF-8 Support Enabled
DEBUG - 2011-05-31 15:38:06 --> URI Class Initialized
DEBUG - 2011-05-31 15:38:06 --> Router Class Initialized
DEBUG - 2011-05-31 15:38:06 --> Output Class Initialized
DEBUG - 2011-05-31 15:38:06 --> Input Class Initialized
DEBUG - 2011-05-31 15:38:06 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-31 15:38:06 --> Language Class Initialized
DEBUG - 2011-05-31 15:38:06 --> Loader Class Initialized
DEBUG - 2011-05-31 15:38:06 --> Controller Class Initialized
ERROR - 2011-05-31 15:38:06 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-31 15:38:06 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-31 15:38:06 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-31 15:38:06 --> Model Class Initialized
DEBUG - 2011-05-31 15:38:06 --> Model Class Initialized
DEBUG - 2011-05-31 15:38:06 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-31 15:38:06 --> Database Driver Class Initialized
DEBUG - 2011-05-31 15:38:06 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-31 15:38:06 --> Helper loaded: url_helper
DEBUG - 2011-05-31 15:38:06 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-31 15:38:06 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-31 15:38:06 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-31 15:38:06 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-31 15:38:06 --> Final output sent to browser
DEBUG - 2011-05-31 15:38:06 --> Total execution time: 0.0472
DEBUG - 2011-05-31 15:38:07 --> Config Class Initialized
DEBUG - 2011-05-31 15:38:07 --> Hooks Class Initialized
DEBUG - 2011-05-31 15:38:07 --> Utf8 Class Initialized
DEBUG - 2011-05-31 15:38:07 --> UTF-8 Support Enabled
DEBUG - 2011-05-31 15:38:07 --> URI Class Initialized
DEBUG - 2011-05-31 15:38:07 --> Router Class Initialized
DEBUG - 2011-05-31 15:38:07 --> Output Class Initialized
DEBUG - 2011-05-31 15:38:07 --> Input Class Initialized
DEBUG - 2011-05-31 15:38:07 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-31 15:38:07 --> Language Class Initialized
DEBUG - 2011-05-31 15:38:07 --> Loader Class Initialized
DEBUG - 2011-05-31 15:38:07 --> Controller Class Initialized
DEBUG - 2011-05-31 15:38:07 --> Model Class Initialized
DEBUG - 2011-05-31 15:38:07 --> Model Class Initialized
DEBUG - 2011-05-31 15:38:07 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-31 15:38:07 --> Database Driver Class Initialized
DEBUG - 2011-05-31 15:38:07 --> Final output sent to browser
DEBUG - 2011-05-31 15:38:07 --> Total execution time: 0.5854
DEBUG - 2011-05-31 15:38:09 --> Config Class Initialized
DEBUG - 2011-05-31 15:38:09 --> Hooks Class Initialized
DEBUG - 2011-05-31 15:38:09 --> Utf8 Class Initialized
DEBUG - 2011-05-31 15:38:09 --> UTF-8 Support Enabled
DEBUG - 2011-05-31 15:38:09 --> URI Class Initialized
DEBUG - 2011-05-31 15:38:09 --> Router Class Initialized
DEBUG - 2011-05-31 15:38:09 --> Output Class Initialized
DEBUG - 2011-05-31 15:38:09 --> Input Class Initialized
DEBUG - 2011-05-31 15:38:09 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-31 15:38:09 --> Language Class Initialized
DEBUG - 2011-05-31 15:38:09 --> Loader Class Initialized
DEBUG - 2011-05-31 15:38:09 --> Controller Class Initialized
ERROR - 2011-05-31 15:38:09 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-31 15:38:09 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-31 15:38:09 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-31 15:38:09 --> Model Class Initialized
DEBUG - 2011-05-31 15:38:09 --> Model Class Initialized
DEBUG - 2011-05-31 15:38:09 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-31 15:38:09 --> Database Driver Class Initialized
DEBUG - 2011-05-31 15:38:09 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-31 15:38:09 --> Helper loaded: url_helper
DEBUG - 2011-05-31 15:38:09 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-31 15:38:09 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-31 15:38:09 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-31 15:38:09 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-31 15:38:09 --> Final output sent to browser
DEBUG - 2011-05-31 15:38:09 --> Total execution time: 0.0404
DEBUG - 2011-05-31 17:00:58 --> Config Class Initialized
DEBUG - 2011-05-31 17:00:58 --> Hooks Class Initialized
DEBUG - 2011-05-31 17:00:58 --> Utf8 Class Initialized
DEBUG - 2011-05-31 17:00:58 --> UTF-8 Support Enabled
DEBUG - 2011-05-31 17:00:58 --> URI Class Initialized
DEBUG - 2011-05-31 17:00:58 --> Router Class Initialized
DEBUG - 2011-05-31 17:00:58 --> Output Class Initialized
DEBUG - 2011-05-31 17:00:58 --> Input Class Initialized
DEBUG - 2011-05-31 17:00:58 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-31 17:00:58 --> Language Class Initialized
DEBUG - 2011-05-31 17:00:59 --> Loader Class Initialized
DEBUG - 2011-05-31 17:00:59 --> Controller Class Initialized
DEBUG - 2011-05-31 17:00:59 --> Model Class Initialized
DEBUG - 2011-05-31 17:00:59 --> Model Class Initialized
DEBUG - 2011-05-31 17:00:59 --> Model Class Initialized
DEBUG - 2011-05-31 17:00:59 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-31 17:00:59 --> Database Driver Class Initialized
DEBUG - 2011-05-31 17:00:59 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-31 17:00:59 --> Helper loaded: url_helper
DEBUG - 2011-05-31 17:00:59 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-31 17:00:59 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-31 17:00:59 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-31 17:00:59 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-31 17:00:59 --> Final output sent to browser
DEBUG - 2011-05-31 17:00:59 --> Total execution time: 0.7185
DEBUG - 2011-05-31 17:01:01 --> Config Class Initialized
DEBUG - 2011-05-31 17:01:01 --> Hooks Class Initialized
DEBUG - 2011-05-31 17:01:01 --> Utf8 Class Initialized
DEBUG - 2011-05-31 17:01:01 --> UTF-8 Support Enabled
DEBUG - 2011-05-31 17:01:01 --> URI Class Initialized
DEBUG - 2011-05-31 17:01:01 --> Router Class Initialized
ERROR - 2011-05-31 17:01:01 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-31 17:03:36 --> Config Class Initialized
DEBUG - 2011-05-31 17:03:36 --> Hooks Class Initialized
DEBUG - 2011-05-31 17:03:36 --> Utf8 Class Initialized
DEBUG - 2011-05-31 17:03:36 --> UTF-8 Support Enabled
DEBUG - 2011-05-31 17:03:36 --> URI Class Initialized
DEBUG - 2011-05-31 17:03:36 --> Router Class Initialized
DEBUG - 2011-05-31 17:03:36 --> No URI present. Default controller set.
DEBUG - 2011-05-31 17:03:36 --> Output Class Initialized
DEBUG - 2011-05-31 17:03:36 --> Input Class Initialized
DEBUG - 2011-05-31 17:03:36 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-31 17:03:36 --> Language Class Initialized
DEBUG - 2011-05-31 17:03:36 --> Loader Class Initialized
DEBUG - 2011-05-31 17:03:36 --> Controller Class Initialized
DEBUG - 2011-05-31 17:03:36 --> File loaded: application/views/splash/main.php
DEBUG - 2011-05-31 17:03:36 --> Helper loaded: url_helper
DEBUG - 2011-05-31 17:03:36 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-31 17:03:36 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-31 17:03:36 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-31 17:03:36 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-31 17:03:36 --> Final output sent to browser
DEBUG - 2011-05-31 17:03:36 --> Total execution time: 0.0867
DEBUG - 2011-05-31 17:03:37 --> Config Class Initialized
DEBUG - 2011-05-31 17:03:37 --> Hooks Class Initialized
DEBUG - 2011-05-31 17:03:37 --> Utf8 Class Initialized
DEBUG - 2011-05-31 17:03:37 --> UTF-8 Support Enabled
DEBUG - 2011-05-31 17:03:37 --> URI Class Initialized
DEBUG - 2011-05-31 17:03:37 --> Router Class Initialized
ERROR - 2011-05-31 17:03:37 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-31 17:03:37 --> Config Class Initialized
DEBUG - 2011-05-31 17:03:37 --> Hooks Class Initialized
DEBUG - 2011-05-31 17:03:37 --> Utf8 Class Initialized
DEBUG - 2011-05-31 17:03:37 --> UTF-8 Support Enabled
DEBUG - 2011-05-31 17:03:37 --> URI Class Initialized
DEBUG - 2011-05-31 17:03:37 --> Router Class Initialized
ERROR - 2011-05-31 17:03:37 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-31 17:03:46 --> Config Class Initialized
DEBUG - 2011-05-31 17:03:46 --> Hooks Class Initialized
DEBUG - 2011-05-31 17:03:46 --> Utf8 Class Initialized
DEBUG - 2011-05-31 17:03:46 --> UTF-8 Support Enabled
DEBUG - 2011-05-31 17:03:46 --> URI Class Initialized
DEBUG - 2011-05-31 17:03:46 --> Router Class Initialized
DEBUG - 2011-05-31 17:03:46 --> Output Class Initialized
DEBUG - 2011-05-31 17:03:46 --> Input Class Initialized
DEBUG - 2011-05-31 17:03:46 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-31 17:03:46 --> Language Class Initialized
DEBUG - 2011-05-31 17:03:46 --> Loader Class Initialized
DEBUG - 2011-05-31 17:03:46 --> Controller Class Initialized
DEBUG - 2011-05-31 17:03:46 --> Model Class Initialized
DEBUG - 2011-05-31 17:03:46 --> Model Class Initialized
DEBUG - 2011-05-31 17:03:46 --> Model Class Initialized
DEBUG - 2011-05-31 17:03:46 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-31 17:03:46 --> Database Driver Class Initialized
DEBUG - 2011-05-31 17:03:46 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-31 17:03:46 --> Helper loaded: url_helper
DEBUG - 2011-05-31 17:03:46 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-31 17:03:46 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-31 17:03:46 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-31 17:03:46 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-31 17:03:46 --> Final output sent to browser
DEBUG - 2011-05-31 17:03:46 --> Total execution time: 0.0526
DEBUG - 2011-05-31 17:03:47 --> Config Class Initialized
DEBUG - 2011-05-31 17:03:47 --> Hooks Class Initialized
DEBUG - 2011-05-31 17:03:47 --> Utf8 Class Initialized
DEBUG - 2011-05-31 17:03:47 --> UTF-8 Support Enabled
DEBUG - 2011-05-31 17:03:47 --> URI Class Initialized
DEBUG - 2011-05-31 17:03:47 --> Router Class Initialized
ERROR - 2011-05-31 17:03:47 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-31 17:03:55 --> Config Class Initialized
DEBUG - 2011-05-31 17:03:55 --> Hooks Class Initialized
DEBUG - 2011-05-31 17:03:55 --> Utf8 Class Initialized
DEBUG - 2011-05-31 17:03:55 --> UTF-8 Support Enabled
DEBUG - 2011-05-31 17:03:55 --> URI Class Initialized
DEBUG - 2011-05-31 17:03:55 --> Router Class Initialized
DEBUG - 2011-05-31 17:03:55 --> Output Class Initialized
DEBUG - 2011-05-31 17:03:55 --> Input Class Initialized
DEBUG - 2011-05-31 17:03:55 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-31 17:03:55 --> Language Class Initialized
DEBUG - 2011-05-31 17:03:55 --> Loader Class Initialized
DEBUG - 2011-05-31 17:03:55 --> Controller Class Initialized
DEBUG - 2011-05-31 17:03:55 --> Model Class Initialized
DEBUG - 2011-05-31 17:03:55 --> Model Class Initialized
DEBUG - 2011-05-31 17:03:55 --> Model Class Initialized
DEBUG - 2011-05-31 17:03:55 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-31 17:03:55 --> Database Driver Class Initialized
DEBUG - 2011-05-31 17:03:55 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-31 17:03:55 --> Helper loaded: url_helper
DEBUG - 2011-05-31 17:03:55 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-31 17:03:55 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-31 17:03:55 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-31 17:03:55 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-31 17:03:55 --> Final output sent to browser
DEBUG - 2011-05-31 17:03:55 --> Total execution time: 0.2087
DEBUG - 2011-05-31 17:03:56 --> Config Class Initialized
DEBUG - 2011-05-31 17:03:56 --> Hooks Class Initialized
DEBUG - 2011-05-31 17:03:56 --> Utf8 Class Initialized
DEBUG - 2011-05-31 17:03:56 --> UTF-8 Support Enabled
DEBUG - 2011-05-31 17:03:56 --> URI Class Initialized
DEBUG - 2011-05-31 17:03:56 --> Router Class Initialized
ERROR - 2011-05-31 17:03:56 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-31 17:03:57 --> Config Class Initialized
DEBUG - 2011-05-31 17:03:57 --> Hooks Class Initialized
DEBUG - 2011-05-31 17:03:57 --> Utf8 Class Initialized
DEBUG - 2011-05-31 17:03:57 --> UTF-8 Support Enabled
DEBUG - 2011-05-31 17:03:57 --> URI Class Initialized
DEBUG - 2011-05-31 17:03:57 --> Router Class Initialized
DEBUG - 2011-05-31 17:03:57 --> Output Class Initialized
DEBUG - 2011-05-31 17:03:57 --> Input Class Initialized
DEBUG - 2011-05-31 17:03:57 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-31 17:03:57 --> Language Class Initialized
DEBUG - 2011-05-31 17:03:57 --> Loader Class Initialized
DEBUG - 2011-05-31 17:03:57 --> Controller Class Initialized
DEBUG - 2011-05-31 17:03:57 --> Model Class Initialized
DEBUG - 2011-05-31 17:03:57 --> Model Class Initialized
DEBUG - 2011-05-31 17:03:57 --> Model Class Initialized
DEBUG - 2011-05-31 17:03:57 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-31 17:03:57 --> Database Driver Class Initialized
DEBUG - 2011-05-31 17:03:57 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-31 17:03:57 --> Helper loaded: url_helper
DEBUG - 2011-05-31 17:03:57 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-31 17:03:57 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-31 17:03:57 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-31 17:03:57 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-31 17:03:57 --> Final output sent to browser
DEBUG - 2011-05-31 17:03:57 --> Total execution time: 0.0693
DEBUG - 2011-05-31 17:03:58 --> Config Class Initialized
DEBUG - 2011-05-31 17:03:58 --> Hooks Class Initialized
DEBUG - 2011-05-31 17:03:58 --> Utf8 Class Initialized
DEBUG - 2011-05-31 17:03:58 --> UTF-8 Support Enabled
DEBUG - 2011-05-31 17:03:58 --> URI Class Initialized
DEBUG - 2011-05-31 17:03:58 --> Router Class Initialized
ERROR - 2011-05-31 17:03:58 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-31 17:04:07 --> Config Class Initialized
DEBUG - 2011-05-31 17:04:07 --> Hooks Class Initialized
DEBUG - 2011-05-31 17:04:07 --> Utf8 Class Initialized
DEBUG - 2011-05-31 17:04:07 --> UTF-8 Support Enabled
DEBUG - 2011-05-31 17:04:07 --> URI Class Initialized
DEBUG - 2011-05-31 17:04:07 --> Router Class Initialized
DEBUG - 2011-05-31 17:04:07 --> Output Class Initialized
DEBUG - 2011-05-31 17:04:07 --> Input Class Initialized
DEBUG - 2011-05-31 17:04:07 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-31 17:04:07 --> Language Class Initialized
DEBUG - 2011-05-31 17:04:07 --> Loader Class Initialized
DEBUG - 2011-05-31 17:04:07 --> Controller Class Initialized
DEBUG - 2011-05-31 17:04:07 --> Model Class Initialized
DEBUG - 2011-05-31 17:04:07 --> Model Class Initialized
DEBUG - 2011-05-31 17:04:07 --> Model Class Initialized
DEBUG - 2011-05-31 17:04:07 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-31 17:04:07 --> Database Driver Class Initialized
DEBUG - 2011-05-31 17:04:08 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-31 17:04:08 --> Helper loaded: url_helper
DEBUG - 2011-05-31 17:04:08 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-31 17:04:08 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-31 17:04:08 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-31 17:04:08 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-31 17:04:08 --> Final output sent to browser
DEBUG - 2011-05-31 17:04:08 --> Total execution time: 0.9062
DEBUG - 2011-05-31 17:04:09 --> Config Class Initialized
DEBUG - 2011-05-31 17:04:09 --> Hooks Class Initialized
DEBUG - 2011-05-31 17:04:09 --> Utf8 Class Initialized
DEBUG - 2011-05-31 17:04:09 --> UTF-8 Support Enabled
DEBUG - 2011-05-31 17:04:09 --> URI Class Initialized
DEBUG - 2011-05-31 17:04:09 --> Router Class Initialized
ERROR - 2011-05-31 17:04:09 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-31 17:04:21 --> Config Class Initialized
DEBUG - 2011-05-31 17:04:21 --> Hooks Class Initialized
DEBUG - 2011-05-31 17:04:21 --> Utf8 Class Initialized
DEBUG - 2011-05-31 17:04:21 --> UTF-8 Support Enabled
DEBUG - 2011-05-31 17:04:21 --> URI Class Initialized
DEBUG - 2011-05-31 17:04:21 --> Router Class Initialized
DEBUG - 2011-05-31 17:04:21 --> Output Class Initialized
DEBUG - 2011-05-31 17:04:21 --> Input Class Initialized
DEBUG - 2011-05-31 17:04:21 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-31 17:04:21 --> Language Class Initialized
DEBUG - 2011-05-31 17:04:21 --> Loader Class Initialized
DEBUG - 2011-05-31 17:04:21 --> Controller Class Initialized
DEBUG - 2011-05-31 17:04:21 --> Model Class Initialized
DEBUG - 2011-05-31 17:04:21 --> Model Class Initialized
DEBUG - 2011-05-31 17:04:21 --> Model Class Initialized
DEBUG - 2011-05-31 17:04:21 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-31 17:04:21 --> Database Driver Class Initialized
DEBUG - 2011-05-31 17:04:21 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-31 17:04:21 --> Helper loaded: url_helper
DEBUG - 2011-05-31 17:04:21 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-31 17:04:21 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-31 17:04:21 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-31 17:04:21 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-31 17:04:21 --> Final output sent to browser
DEBUG - 2011-05-31 17:04:21 --> Total execution time: 0.4379
DEBUG - 2011-05-31 17:04:22 --> Config Class Initialized
DEBUG - 2011-05-31 17:04:22 --> Hooks Class Initialized
DEBUG - 2011-05-31 17:04:22 --> Utf8 Class Initialized
DEBUG - 2011-05-31 17:04:22 --> UTF-8 Support Enabled
DEBUG - 2011-05-31 17:04:22 --> URI Class Initialized
DEBUG - 2011-05-31 17:04:22 --> Router Class Initialized
ERROR - 2011-05-31 17:04:22 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-31 17:04:29 --> Config Class Initialized
DEBUG - 2011-05-31 17:04:29 --> Hooks Class Initialized
DEBUG - 2011-05-31 17:04:29 --> Utf8 Class Initialized
DEBUG - 2011-05-31 17:04:29 --> UTF-8 Support Enabled
DEBUG - 2011-05-31 17:04:29 --> URI Class Initialized
DEBUG - 2011-05-31 17:04:29 --> Router Class Initialized
DEBUG - 2011-05-31 17:04:29 --> Output Class Initialized
DEBUG - 2011-05-31 17:04:29 --> Input Class Initialized
DEBUG - 2011-05-31 17:04:29 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-31 17:04:29 --> Language Class Initialized
DEBUG - 2011-05-31 17:04:29 --> Loader Class Initialized
DEBUG - 2011-05-31 17:04:29 --> Controller Class Initialized
DEBUG - 2011-05-31 17:04:29 --> Model Class Initialized
DEBUG - 2011-05-31 17:04:29 --> Model Class Initialized
DEBUG - 2011-05-31 17:04:29 --> Model Class Initialized
DEBUG - 2011-05-31 17:04:29 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-31 17:04:29 --> Database Driver Class Initialized
DEBUG - 2011-05-31 17:04:29 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-31 17:04:29 --> Helper loaded: url_helper
DEBUG - 2011-05-31 17:04:29 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-31 17:04:29 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-31 17:04:29 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-31 17:04:29 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-31 17:04:29 --> Final output sent to browser
DEBUG - 2011-05-31 17:04:29 --> Total execution time: 0.3607
DEBUG - 2011-05-31 17:04:31 --> Config Class Initialized
DEBUG - 2011-05-31 17:04:31 --> Hooks Class Initialized
DEBUG - 2011-05-31 17:04:31 --> Utf8 Class Initialized
DEBUG - 2011-05-31 17:04:31 --> UTF-8 Support Enabled
DEBUG - 2011-05-31 17:04:31 --> URI Class Initialized
DEBUG - 2011-05-31 17:04:31 --> Router Class Initialized
ERROR - 2011-05-31 17:04:31 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-31 17:04:32 --> Config Class Initialized
DEBUG - 2011-05-31 17:04:32 --> Hooks Class Initialized
DEBUG - 2011-05-31 17:04:32 --> Utf8 Class Initialized
DEBUG - 2011-05-31 17:04:32 --> UTF-8 Support Enabled
DEBUG - 2011-05-31 17:04:32 --> URI Class Initialized
DEBUG - 2011-05-31 17:04:32 --> Router Class Initialized
DEBUG - 2011-05-31 17:04:32 --> Output Class Initialized
DEBUG - 2011-05-31 17:04:32 --> Input Class Initialized
DEBUG - 2011-05-31 17:04:32 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-31 17:04:32 --> Language Class Initialized
DEBUG - 2011-05-31 17:04:32 --> Loader Class Initialized
DEBUG - 2011-05-31 17:04:32 --> Controller Class Initialized
DEBUG - 2011-05-31 17:04:32 --> Model Class Initialized
DEBUG - 2011-05-31 17:04:32 --> Model Class Initialized
DEBUG - 2011-05-31 17:04:32 --> Model Class Initialized
DEBUG - 2011-05-31 17:04:32 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-31 17:04:32 --> Database Driver Class Initialized
DEBUG - 2011-05-31 17:04:32 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-31 17:04:32 --> Helper loaded: url_helper
DEBUG - 2011-05-31 17:04:32 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-31 17:04:32 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-31 17:04:32 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-31 17:04:32 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-31 17:04:32 --> Final output sent to browser
DEBUG - 2011-05-31 17:04:32 --> Total execution time: 0.0435
DEBUG - 2011-05-31 17:04:38 --> Config Class Initialized
DEBUG - 2011-05-31 17:04:38 --> Hooks Class Initialized
DEBUG - 2011-05-31 17:04:38 --> Utf8 Class Initialized
DEBUG - 2011-05-31 17:04:38 --> UTF-8 Support Enabled
DEBUG - 2011-05-31 17:04:38 --> URI Class Initialized
DEBUG - 2011-05-31 17:04:38 --> Router Class Initialized
DEBUG - 2011-05-31 17:04:38 --> Output Class Initialized
DEBUG - 2011-05-31 17:04:38 --> Input Class Initialized
DEBUG - 2011-05-31 17:04:38 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-31 17:04:38 --> Language Class Initialized
DEBUG - 2011-05-31 17:04:38 --> Loader Class Initialized
DEBUG - 2011-05-31 17:04:38 --> Controller Class Initialized
DEBUG - 2011-05-31 17:04:38 --> Model Class Initialized
DEBUG - 2011-05-31 17:04:38 --> Model Class Initialized
DEBUG - 2011-05-31 17:04:38 --> Model Class Initialized
DEBUG - 2011-05-31 17:04:38 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-31 17:04:38 --> Database Driver Class Initialized
DEBUG - 2011-05-31 17:04:38 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-31 17:04:38 --> Helper loaded: url_helper
DEBUG - 2011-05-31 17:04:38 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-31 17:04:38 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-31 17:04:38 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-31 17:04:38 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-31 17:04:38 --> Final output sent to browser
DEBUG - 2011-05-31 17:04:38 --> Total execution time: 0.3269
DEBUG - 2011-05-31 17:04:39 --> Config Class Initialized
DEBUG - 2011-05-31 17:04:39 --> Hooks Class Initialized
DEBUG - 2011-05-31 17:04:39 --> Utf8 Class Initialized
DEBUG - 2011-05-31 17:04:39 --> UTF-8 Support Enabled
DEBUG - 2011-05-31 17:04:39 --> URI Class Initialized
DEBUG - 2011-05-31 17:04:39 --> Router Class Initialized
ERROR - 2011-05-31 17:04:39 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-31 17:04:48 --> Config Class Initialized
DEBUG - 2011-05-31 17:04:48 --> Hooks Class Initialized
DEBUG - 2011-05-31 17:04:48 --> Utf8 Class Initialized
DEBUG - 2011-05-31 17:04:48 --> UTF-8 Support Enabled
DEBUG - 2011-05-31 17:04:48 --> URI Class Initialized
DEBUG - 2011-05-31 17:04:48 --> Router Class Initialized
DEBUG - 2011-05-31 17:04:48 --> Output Class Initialized
DEBUG - 2011-05-31 17:04:48 --> Input Class Initialized
DEBUG - 2011-05-31 17:04:48 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-31 17:04:48 --> Language Class Initialized
DEBUG - 2011-05-31 17:04:48 --> Loader Class Initialized
DEBUG - 2011-05-31 17:04:48 --> Controller Class Initialized
DEBUG - 2011-05-31 17:04:48 --> Model Class Initialized
DEBUG - 2011-05-31 17:04:48 --> Model Class Initialized
DEBUG - 2011-05-31 17:04:48 --> Model Class Initialized
DEBUG - 2011-05-31 17:04:48 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-31 17:04:48 --> Database Driver Class Initialized
DEBUG - 2011-05-31 17:04:48 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-31 17:04:48 --> Helper loaded: url_helper
DEBUG - 2011-05-31 17:04:48 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-31 17:04:48 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-31 17:04:48 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-31 17:04:48 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-31 17:04:48 --> Final output sent to browser
DEBUG - 2011-05-31 17:04:48 --> Total execution time: 0.2649
DEBUG - 2011-05-31 17:04:48 --> Config Class Initialized
DEBUG - 2011-05-31 17:04:48 --> Hooks Class Initialized
DEBUG - 2011-05-31 17:04:48 --> Utf8 Class Initialized
DEBUG - 2011-05-31 17:04:48 --> UTF-8 Support Enabled
DEBUG - 2011-05-31 17:04:48 --> URI Class Initialized
DEBUG - 2011-05-31 17:04:48 --> Router Class Initialized
DEBUG - 2011-05-31 17:04:48 --> Output Class Initialized
DEBUG - 2011-05-31 17:04:48 --> Input Class Initialized
DEBUG - 2011-05-31 17:04:48 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-31 17:04:48 --> Language Class Initialized
DEBUG - 2011-05-31 17:04:48 --> Loader Class Initialized
DEBUG - 2011-05-31 17:04:48 --> Controller Class Initialized
DEBUG - 2011-05-31 17:04:48 --> Model Class Initialized
DEBUG - 2011-05-31 17:04:48 --> Model Class Initialized
DEBUG - 2011-05-31 17:04:48 --> Model Class Initialized
DEBUG - 2011-05-31 17:04:48 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-31 17:04:48 --> Database Driver Class Initialized
DEBUG - 2011-05-31 17:04:48 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-31 17:04:48 --> Helper loaded: url_helper
DEBUG - 2011-05-31 17:04:48 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-31 17:04:48 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-31 17:04:48 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-31 17:04:48 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-31 17:04:48 --> Final output sent to browser
DEBUG - 2011-05-31 17:04:48 --> Total execution time: 0.0462
DEBUG - 2011-05-31 17:04:49 --> Config Class Initialized
DEBUG - 2011-05-31 17:04:49 --> Hooks Class Initialized
DEBUG - 2011-05-31 17:04:49 --> Utf8 Class Initialized
DEBUG - 2011-05-31 17:04:49 --> UTF-8 Support Enabled
DEBUG - 2011-05-31 17:04:49 --> URI Class Initialized
DEBUG - 2011-05-31 17:04:49 --> Config Class Initialized
DEBUG - 2011-05-31 17:04:49 --> Hooks Class Initialized
DEBUG - 2011-05-31 17:04:49 --> Utf8 Class Initialized
DEBUG - 2011-05-31 17:04:49 --> UTF-8 Support Enabled
DEBUG - 2011-05-31 17:04:49 --> Router Class Initialized
ERROR - 2011-05-31 17:04:49 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-31 17:04:49 --> URI Class Initialized
DEBUG - 2011-05-31 17:04:49 --> Router Class Initialized
DEBUG - 2011-05-31 17:04:49 --> Output Class Initialized
DEBUG - 2011-05-31 17:04:49 --> Input Class Initialized
DEBUG - 2011-05-31 17:04:49 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-31 17:04:49 --> Language Class Initialized
DEBUG - 2011-05-31 17:04:49 --> Loader Class Initialized
DEBUG - 2011-05-31 17:04:49 --> Controller Class Initialized
DEBUG - 2011-05-31 17:04:49 --> Model Class Initialized
DEBUG - 2011-05-31 17:04:49 --> Model Class Initialized
DEBUG - 2011-05-31 17:04:49 --> Model Class Initialized
DEBUG - 2011-05-31 17:04:49 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-31 17:04:49 --> Database Driver Class Initialized
DEBUG - 2011-05-31 17:04:49 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-31 17:04:49 --> Helper loaded: url_helper
DEBUG - 2011-05-31 17:04:49 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-31 17:04:49 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-31 17:04:49 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-31 17:04:49 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-31 17:04:49 --> Final output sent to browser
DEBUG - 2011-05-31 17:04:49 --> Total execution time: 0.0477
DEBUG - 2011-05-31 17:04:52 --> Config Class Initialized
DEBUG - 2011-05-31 17:04:52 --> Hooks Class Initialized
DEBUG - 2011-05-31 17:04:52 --> Utf8 Class Initialized
DEBUG - 2011-05-31 17:04:52 --> UTF-8 Support Enabled
DEBUG - 2011-05-31 17:04:52 --> URI Class Initialized
DEBUG - 2011-05-31 17:04:52 --> Router Class Initialized
DEBUG - 2011-05-31 17:04:52 --> Output Class Initialized
DEBUG - 2011-05-31 17:04:52 --> Input Class Initialized
DEBUG - 2011-05-31 17:04:52 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-31 17:04:52 --> Language Class Initialized
DEBUG - 2011-05-31 17:04:52 --> Loader Class Initialized
DEBUG - 2011-05-31 17:04:52 --> Controller Class Initialized
DEBUG - 2011-05-31 17:04:52 --> Model Class Initialized
DEBUG - 2011-05-31 17:04:52 --> Model Class Initialized
DEBUG - 2011-05-31 17:04:52 --> Model Class Initialized
DEBUG - 2011-05-31 17:04:52 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-31 17:04:52 --> Database Driver Class Initialized
DEBUG - 2011-05-31 17:04:52 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-31 17:04:52 --> Helper loaded: url_helper
DEBUG - 2011-05-31 17:04:52 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-31 17:04:52 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-31 17:04:52 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-31 17:04:52 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-31 17:04:52 --> Final output sent to browser
DEBUG - 2011-05-31 17:04:52 --> Total execution time: 0.4584
DEBUG - 2011-05-31 17:04:53 --> Config Class Initialized
DEBUG - 2011-05-31 17:04:53 --> Hooks Class Initialized
DEBUG - 2011-05-31 17:04:53 --> Utf8 Class Initialized
DEBUG - 2011-05-31 17:04:53 --> UTF-8 Support Enabled
DEBUG - 2011-05-31 17:04:53 --> URI Class Initialized
DEBUG - 2011-05-31 17:04:53 --> Router Class Initialized
DEBUG - 2011-05-31 17:04:53 --> Output Class Initialized
DEBUG - 2011-05-31 17:04:53 --> Input Class Initialized
DEBUG - 2011-05-31 17:04:53 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-31 17:04:53 --> Language Class Initialized
DEBUG - 2011-05-31 17:04:53 --> Loader Class Initialized
DEBUG - 2011-05-31 17:04:53 --> Controller Class Initialized
DEBUG - 2011-05-31 17:04:53 --> Model Class Initialized
DEBUG - 2011-05-31 17:04:53 --> Model Class Initialized
DEBUG - 2011-05-31 17:04:53 --> Model Class Initialized
DEBUG - 2011-05-31 17:04:53 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-31 17:04:53 --> Database Driver Class Initialized
DEBUG - 2011-05-31 17:04:53 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-31 17:04:53 --> Helper loaded: url_helper
DEBUG - 2011-05-31 17:04:53 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-31 17:04:53 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-31 17:04:53 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-31 17:04:53 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-31 17:04:53 --> Final output sent to browser
DEBUG - 2011-05-31 17:04:53 --> Total execution time: 0.0802
DEBUG - 2011-05-31 17:04:53 --> Config Class Initialized
DEBUG - 2011-05-31 17:04:53 --> Hooks Class Initialized
DEBUG - 2011-05-31 17:04:53 --> Utf8 Class Initialized
DEBUG - 2011-05-31 17:04:53 --> UTF-8 Support Enabled
DEBUG - 2011-05-31 17:04:53 --> URI Class Initialized
DEBUG - 2011-05-31 17:04:53 --> Router Class Initialized
DEBUG - 2011-05-31 17:04:53 --> Output Class Initialized
DEBUG - 2011-05-31 17:04:53 --> Input Class Initialized
DEBUG - 2011-05-31 17:04:53 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-31 17:04:53 --> Language Class Initialized
DEBUG - 2011-05-31 17:04:53 --> Loader Class Initialized
DEBUG - 2011-05-31 17:04:53 --> Controller Class Initialized
DEBUG - 2011-05-31 17:04:53 --> Model Class Initialized
DEBUG - 2011-05-31 17:04:53 --> Model Class Initialized
DEBUG - 2011-05-31 17:04:53 --> Model Class Initialized
DEBUG - 2011-05-31 17:04:53 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-31 17:04:53 --> Database Driver Class Initialized
DEBUG - 2011-05-31 17:04:53 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-31 17:04:53 --> Helper loaded: url_helper
DEBUG - 2011-05-31 17:04:53 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-31 17:04:53 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-31 17:04:53 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-31 17:04:53 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-31 17:04:53 --> Final output sent to browser
DEBUG - 2011-05-31 17:04:53 --> Total execution time: 0.0485
DEBUG - 2011-05-31 17:04:53 --> Config Class Initialized
DEBUG - 2011-05-31 17:04:53 --> Hooks Class Initialized
DEBUG - 2011-05-31 17:04:53 --> Utf8 Class Initialized
DEBUG - 2011-05-31 17:04:53 --> UTF-8 Support Enabled
DEBUG - 2011-05-31 17:04:53 --> URI Class Initialized
DEBUG - 2011-05-31 17:04:53 --> Router Class Initialized
ERROR - 2011-05-31 17:04:53 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-31 17:08:10 --> Config Class Initialized
DEBUG - 2011-05-31 17:08:10 --> Hooks Class Initialized
DEBUG - 2011-05-31 17:08:10 --> Utf8 Class Initialized
DEBUG - 2011-05-31 17:08:10 --> UTF-8 Support Enabled
DEBUG - 2011-05-31 17:08:10 --> URI Class Initialized
DEBUG - 2011-05-31 17:08:10 --> Router Class Initialized
DEBUG - 2011-05-31 17:08:10 --> Output Class Initialized
DEBUG - 2011-05-31 17:08:10 --> Input Class Initialized
DEBUG - 2011-05-31 17:08:10 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-31 17:08:10 --> Language Class Initialized
DEBUG - 2011-05-31 17:08:10 --> Loader Class Initialized
DEBUG - 2011-05-31 17:08:10 --> Controller Class Initialized
DEBUG - 2011-05-31 17:08:10 --> Model Class Initialized
DEBUG - 2011-05-31 17:08:10 --> Model Class Initialized
DEBUG - 2011-05-31 17:08:10 --> Model Class Initialized
DEBUG - 2011-05-31 17:08:10 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-31 17:08:10 --> Database Driver Class Initialized
DEBUG - 2011-05-31 17:08:11 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-31 17:08:11 --> Helper loaded: url_helper
DEBUG - 2011-05-31 17:08:11 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-31 17:08:11 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-31 17:08:11 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-31 17:08:11 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-31 17:08:11 --> Final output sent to browser
DEBUG - 2011-05-31 17:08:11 --> Total execution time: 0.0823
DEBUG - 2011-05-31 17:08:15 --> Config Class Initialized
DEBUG - 2011-05-31 17:08:15 --> Hooks Class Initialized
DEBUG - 2011-05-31 17:08:15 --> Utf8 Class Initialized
DEBUG - 2011-05-31 17:08:15 --> UTF-8 Support Enabled
DEBUG - 2011-05-31 17:08:15 --> URI Class Initialized
DEBUG - 2011-05-31 17:08:15 --> Router Class Initialized
DEBUG - 2011-05-31 17:08:15 --> Output Class Initialized
DEBUG - 2011-05-31 17:08:15 --> Input Class Initialized
DEBUG - 2011-05-31 17:08:15 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-31 17:08:15 --> Language Class Initialized
DEBUG - 2011-05-31 17:08:15 --> Loader Class Initialized
DEBUG - 2011-05-31 17:08:15 --> Controller Class Initialized
ERROR - 2011-05-31 17:08:15 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-31 17:08:15 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-31 17:08:15 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-31 17:08:15 --> Model Class Initialized
DEBUG - 2011-05-31 17:08:15 --> Model Class Initialized
DEBUG - 2011-05-31 17:08:15 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-31 17:08:15 --> Database Driver Class Initialized
DEBUG - 2011-05-31 17:08:15 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-31 17:08:15 --> Helper loaded: url_helper
DEBUG - 2011-05-31 17:08:15 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-31 17:08:15 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-31 17:08:15 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-31 17:08:15 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-31 17:08:15 --> Final output sent to browser
DEBUG - 2011-05-31 17:08:15 --> Total execution time: 0.4657
DEBUG - 2011-05-31 22:23:02 --> Config Class Initialized
DEBUG - 2011-05-31 22:23:02 --> Hooks Class Initialized
DEBUG - 2011-05-31 22:23:02 --> Utf8 Class Initialized
DEBUG - 2011-05-31 22:23:02 --> UTF-8 Support Enabled
DEBUG - 2011-05-31 22:23:02 --> URI Class Initialized
DEBUG - 2011-05-31 22:23:02 --> Router Class Initialized
DEBUG - 2011-05-31 22:23:02 --> No URI present. Default controller set.
DEBUG - 2011-05-31 22:23:02 --> Output Class Initialized
DEBUG - 2011-05-31 22:23:02 --> Input Class Initialized
DEBUG - 2011-05-31 22:23:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-31 22:23:02 --> Language Class Initialized
DEBUG - 2011-05-31 22:23:02 --> Loader Class Initialized
DEBUG - 2011-05-31 22:23:02 --> Controller Class Initialized
DEBUG - 2011-05-31 22:23:02 --> File loaded: application/views/splash/main.php
DEBUG - 2011-05-31 22:23:02 --> Helper loaded: url_helper
DEBUG - 2011-05-31 22:23:02 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-31 22:23:02 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-31 22:23:02 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-31 22:23:02 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-31 22:23:02 --> Final output sent to browser
DEBUG - 2011-05-31 22:23:02 --> Total execution time: 0.3078

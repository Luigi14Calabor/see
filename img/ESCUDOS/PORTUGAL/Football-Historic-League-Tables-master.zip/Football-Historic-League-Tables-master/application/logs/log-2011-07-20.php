<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2011-07-20 03:35:16 --> Config Class Initialized
DEBUG - 2011-07-20 03:35:16 --> Hooks Class Initialized
DEBUG - 2011-07-20 03:35:16 --> Utf8 Class Initialized
DEBUG - 2011-07-20 03:35:16 --> UTF-8 Support Enabled
DEBUG - 2011-07-20 03:35:16 --> URI Class Initialized
DEBUG - 2011-07-20 03:35:16 --> Router Class Initialized
DEBUG - 2011-07-20 03:35:16 --> Output Class Initialized
DEBUG - 2011-07-20 03:35:16 --> Input Class Initialized
DEBUG - 2011-07-20 03:35:16 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-20 03:35:16 --> Language Class Initialized
DEBUG - 2011-07-20 03:35:16 --> Loader Class Initialized
DEBUG - 2011-07-20 03:35:16 --> Controller Class Initialized
DEBUG - 2011-07-20 03:35:16 --> Model Class Initialized
DEBUG - 2011-07-20 03:35:16 --> Model Class Initialized
DEBUG - 2011-07-20 03:35:16 --> Model Class Initialized
DEBUG - 2011-07-20 03:35:16 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-20 03:35:16 --> Database Driver Class Initialized
DEBUG - 2011-07-20 03:35:16 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-20 03:35:16 --> Helper loaded: url_helper
DEBUG - 2011-07-20 03:35:16 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-20 03:35:16 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-20 03:35:16 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-20 03:35:16 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-20 03:35:16 --> Final output sent to browser
DEBUG - 2011-07-20 03:35:16 --> Total execution time: 0.4954
DEBUG - 2011-07-20 04:34:06 --> Config Class Initialized
DEBUG - 2011-07-20 04:34:06 --> Hooks Class Initialized
DEBUG - 2011-07-20 04:34:06 --> Utf8 Class Initialized
DEBUG - 2011-07-20 04:34:06 --> UTF-8 Support Enabled
DEBUG - 2011-07-20 04:34:06 --> URI Class Initialized
DEBUG - 2011-07-20 04:34:06 --> Router Class Initialized
ERROR - 2011-07-20 04:34:06 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-07-20 04:34:07 --> Config Class Initialized
DEBUG - 2011-07-20 04:34:07 --> Hooks Class Initialized
DEBUG - 2011-07-20 04:34:07 --> Utf8 Class Initialized
DEBUG - 2011-07-20 04:34:07 --> UTF-8 Support Enabled
DEBUG - 2011-07-20 04:34:07 --> URI Class Initialized
DEBUG - 2011-07-20 04:34:07 --> Router Class Initialized
DEBUG - 2011-07-20 04:34:07 --> Output Class Initialized
DEBUG - 2011-07-20 04:34:07 --> Input Class Initialized
DEBUG - 2011-07-20 04:34:07 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-20 04:34:07 --> Language Class Initialized
DEBUG - 2011-07-20 04:34:07 --> Loader Class Initialized
DEBUG - 2011-07-20 04:34:07 --> Controller Class Initialized
DEBUG - 2011-07-20 04:34:07 --> Model Class Initialized
DEBUG - 2011-07-20 04:34:07 --> Model Class Initialized
DEBUG - 2011-07-20 04:34:07 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-20 04:34:07 --> Database Driver Class Initialized
DEBUG - 2011-07-20 04:34:07 --> Final output sent to browser
DEBUG - 2011-07-20 04:34:07 --> Total execution time: 0.7750
DEBUG - 2011-07-20 05:22:52 --> Config Class Initialized
DEBUG - 2011-07-20 05:22:52 --> Hooks Class Initialized
DEBUG - 2011-07-20 05:22:52 --> Utf8 Class Initialized
DEBUG - 2011-07-20 05:22:52 --> UTF-8 Support Enabled
DEBUG - 2011-07-20 05:22:52 --> URI Class Initialized
DEBUG - 2011-07-20 05:22:52 --> Router Class Initialized
DEBUG - 2011-07-20 05:22:53 --> Output Class Initialized
DEBUG - 2011-07-20 05:22:53 --> Input Class Initialized
DEBUG - 2011-07-20 05:22:53 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-20 05:22:53 --> Language Class Initialized
DEBUG - 2011-07-20 05:22:53 --> Loader Class Initialized
DEBUG - 2011-07-20 05:22:53 --> Controller Class Initialized
DEBUG - 2011-07-20 05:22:53 --> Model Class Initialized
DEBUG - 2011-07-20 05:22:54 --> Model Class Initialized
DEBUG - 2011-07-20 05:22:54 --> Model Class Initialized
DEBUG - 2011-07-20 05:22:54 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-20 05:22:55 --> Database Driver Class Initialized
DEBUG - 2011-07-20 05:22:56 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-20 05:22:56 --> Helper loaded: url_helper
DEBUG - 2011-07-20 05:22:56 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-20 05:22:56 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-20 05:22:57 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-20 05:22:57 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-20 05:22:57 --> Final output sent to browser
DEBUG - 2011-07-20 05:22:57 --> Total execution time: 5.7774
DEBUG - 2011-07-20 05:23:04 --> Config Class Initialized
DEBUG - 2011-07-20 05:23:04 --> Hooks Class Initialized
DEBUG - 2011-07-20 05:23:04 --> Utf8 Class Initialized
DEBUG - 2011-07-20 05:23:04 --> UTF-8 Support Enabled
DEBUG - 2011-07-20 05:23:04 --> URI Class Initialized
DEBUG - 2011-07-20 05:23:04 --> Router Class Initialized
ERROR - 2011-07-20 05:23:04 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-20 05:23:20 --> Config Class Initialized
DEBUG - 2011-07-20 05:23:20 --> Hooks Class Initialized
DEBUG - 2011-07-20 05:23:20 --> Utf8 Class Initialized
DEBUG - 2011-07-20 05:23:20 --> UTF-8 Support Enabled
DEBUG - 2011-07-20 05:23:20 --> URI Class Initialized
DEBUG - 2011-07-20 05:23:20 --> Router Class Initialized
DEBUG - 2011-07-20 05:23:20 --> Output Class Initialized
DEBUG - 2011-07-20 05:23:20 --> Input Class Initialized
DEBUG - 2011-07-20 05:23:20 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-20 05:23:20 --> Language Class Initialized
DEBUG - 2011-07-20 05:23:20 --> Loader Class Initialized
DEBUG - 2011-07-20 05:23:20 --> Controller Class Initialized
DEBUG - 2011-07-20 05:23:20 --> Model Class Initialized
DEBUG - 2011-07-20 05:23:20 --> Model Class Initialized
DEBUG - 2011-07-20 05:23:20 --> Model Class Initialized
DEBUG - 2011-07-20 05:23:20 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-20 05:23:20 --> Database Driver Class Initialized
DEBUG - 2011-07-20 05:23:20 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-20 05:23:20 --> Helper loaded: url_helper
DEBUG - 2011-07-20 05:23:20 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-20 05:23:20 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-20 05:23:20 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-20 05:23:20 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-20 05:23:20 --> Final output sent to browser
DEBUG - 2011-07-20 05:23:20 --> Total execution time: 0.0483
DEBUG - 2011-07-20 06:09:22 --> Config Class Initialized
DEBUG - 2011-07-20 06:09:22 --> Hooks Class Initialized
DEBUG - 2011-07-20 06:09:22 --> Utf8 Class Initialized
DEBUG - 2011-07-20 06:09:22 --> UTF-8 Support Enabled
DEBUG - 2011-07-20 06:09:22 --> URI Class Initialized
DEBUG - 2011-07-20 06:09:22 --> Router Class Initialized
ERROR - 2011-07-20 06:09:22 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-07-20 06:09:34 --> Config Class Initialized
DEBUG - 2011-07-20 06:09:34 --> Hooks Class Initialized
DEBUG - 2011-07-20 06:09:34 --> Utf8 Class Initialized
DEBUG - 2011-07-20 06:09:34 --> UTF-8 Support Enabled
DEBUG - 2011-07-20 06:09:34 --> URI Class Initialized
DEBUG - 2011-07-20 06:09:34 --> Router Class Initialized
DEBUG - 2011-07-20 06:09:34 --> No URI present. Default controller set.
DEBUG - 2011-07-20 06:09:34 --> Output Class Initialized
DEBUG - 2011-07-20 06:09:34 --> Input Class Initialized
DEBUG - 2011-07-20 06:09:34 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-20 06:09:34 --> Language Class Initialized
DEBUG - 2011-07-20 06:09:34 --> Loader Class Initialized
DEBUG - 2011-07-20 06:09:34 --> Controller Class Initialized
DEBUG - 2011-07-20 06:09:34 --> File loaded: application/views/splash/main.php
DEBUG - 2011-07-20 06:09:34 --> Helper loaded: url_helper
DEBUG - 2011-07-20 06:09:34 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-20 06:09:34 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-20 06:09:34 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-20 06:09:34 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-20 06:09:34 --> Final output sent to browser
DEBUG - 2011-07-20 06:09:34 --> Total execution time: 0.1504
DEBUG - 2011-07-20 09:00:00 --> Config Class Initialized
DEBUG - 2011-07-20 09:00:00 --> Hooks Class Initialized
DEBUG - 2011-07-20 09:00:00 --> Utf8 Class Initialized
DEBUG - 2011-07-20 09:00:00 --> UTF-8 Support Enabled
DEBUG - 2011-07-20 09:00:00 --> URI Class Initialized
DEBUG - 2011-07-20 09:00:00 --> Router Class Initialized
ERROR - 2011-07-20 09:00:00 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-07-20 09:00:03 --> Config Class Initialized
DEBUG - 2011-07-20 09:00:03 --> Hooks Class Initialized
DEBUG - 2011-07-20 09:00:03 --> Utf8 Class Initialized
DEBUG - 2011-07-20 09:00:03 --> UTF-8 Support Enabled
DEBUG - 2011-07-20 09:00:03 --> URI Class Initialized
DEBUG - 2011-07-20 09:00:03 --> Router Class Initialized
DEBUG - 2011-07-20 09:00:03 --> Output Class Initialized
DEBUG - 2011-07-20 09:00:03 --> Input Class Initialized
DEBUG - 2011-07-20 09:00:03 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-20 09:00:03 --> Language Class Initialized
DEBUG - 2011-07-20 09:00:03 --> Loader Class Initialized
DEBUG - 2011-07-20 09:00:03 --> Controller Class Initialized
ERROR - 2011-07-20 09:00:03 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-20 09:00:03 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-20 09:00:03 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-20 09:00:03 --> Model Class Initialized
DEBUG - 2011-07-20 09:00:03 --> Model Class Initialized
DEBUG - 2011-07-20 09:00:03 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-20 09:00:03 --> Database Driver Class Initialized
DEBUG - 2011-07-20 09:00:03 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-20 09:00:03 --> Helper loaded: url_helper
DEBUG - 2011-07-20 09:00:03 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-20 09:00:03 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-20 09:00:03 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-20 09:00:03 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-20 09:00:03 --> Final output sent to browser
DEBUG - 2011-07-20 09:00:03 --> Total execution time: 0.7641
DEBUG - 2011-07-20 09:27:20 --> Config Class Initialized
DEBUG - 2011-07-20 09:27:20 --> Hooks Class Initialized
DEBUG - 2011-07-20 09:27:20 --> Utf8 Class Initialized
DEBUG - 2011-07-20 09:27:20 --> UTF-8 Support Enabled
DEBUG - 2011-07-20 09:27:20 --> URI Class Initialized
DEBUG - 2011-07-20 09:27:20 --> Router Class Initialized
ERROR - 2011-07-20 09:27:20 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-07-20 09:38:47 --> Config Class Initialized
DEBUG - 2011-07-20 09:38:47 --> Hooks Class Initialized
DEBUG - 2011-07-20 09:38:47 --> Utf8 Class Initialized
DEBUG - 2011-07-20 09:38:47 --> UTF-8 Support Enabled
DEBUG - 2011-07-20 09:38:47 --> URI Class Initialized
DEBUG - 2011-07-20 09:38:47 --> Router Class Initialized
DEBUG - 2011-07-20 09:38:47 --> Output Class Initialized
DEBUG - 2011-07-20 09:38:47 --> Input Class Initialized
DEBUG - 2011-07-20 09:38:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-20 09:38:47 --> Language Class Initialized
DEBUG - 2011-07-20 09:38:47 --> Loader Class Initialized
DEBUG - 2011-07-20 09:38:47 --> Controller Class Initialized
ERROR - 2011-07-20 09:38:47 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-20 09:38:47 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-20 09:38:48 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-20 09:38:48 --> Model Class Initialized
DEBUG - 2011-07-20 09:38:48 --> Model Class Initialized
DEBUG - 2011-07-20 09:38:48 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-20 09:38:48 --> Database Driver Class Initialized
DEBUG - 2011-07-20 09:38:48 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-20 09:38:48 --> Helper loaded: url_helper
DEBUG - 2011-07-20 09:38:48 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-20 09:38:48 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-20 09:38:48 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-20 09:38:48 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-20 09:38:48 --> Final output sent to browser
DEBUG - 2011-07-20 09:38:48 --> Total execution time: 1.2582
DEBUG - 2011-07-20 09:38:48 --> Config Class Initialized
DEBUG - 2011-07-20 09:38:48 --> Hooks Class Initialized
DEBUG - 2011-07-20 09:38:48 --> Utf8 Class Initialized
DEBUG - 2011-07-20 09:38:48 --> UTF-8 Support Enabled
DEBUG - 2011-07-20 09:38:48 --> URI Class Initialized
DEBUG - 2011-07-20 09:38:48 --> Router Class Initialized
DEBUG - 2011-07-20 09:38:48 --> Output Class Initialized
DEBUG - 2011-07-20 09:38:48 --> Input Class Initialized
DEBUG - 2011-07-20 09:38:48 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-20 09:38:48 --> Language Class Initialized
DEBUG - 2011-07-20 09:38:48 --> Loader Class Initialized
DEBUG - 2011-07-20 09:38:48 --> Controller Class Initialized
DEBUG - 2011-07-20 09:38:48 --> Model Class Initialized
DEBUG - 2011-07-20 09:38:48 --> Model Class Initialized
DEBUG - 2011-07-20 09:38:48 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-20 09:38:48 --> Database Driver Class Initialized
DEBUG - 2011-07-20 09:38:51 --> Config Class Initialized
DEBUG - 2011-07-20 09:38:51 --> Hooks Class Initialized
DEBUG - 2011-07-20 09:38:51 --> Utf8 Class Initialized
DEBUG - 2011-07-20 09:38:51 --> UTF-8 Support Enabled
DEBUG - 2011-07-20 09:38:51 --> URI Class Initialized
DEBUG - 2011-07-20 09:38:51 --> Router Class Initialized
DEBUG - 2011-07-20 09:38:51 --> Output Class Initialized
DEBUG - 2011-07-20 09:38:51 --> Input Class Initialized
DEBUG - 2011-07-20 09:38:51 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-20 09:38:51 --> Language Class Initialized
DEBUG - 2011-07-20 09:38:51 --> Loader Class Initialized
DEBUG - 2011-07-20 09:38:51 --> Controller Class Initialized
ERROR - 2011-07-20 09:38:51 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-20 09:38:51 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-20 09:38:51 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-20 09:38:51 --> Model Class Initialized
DEBUG - 2011-07-20 09:38:51 --> Model Class Initialized
DEBUG - 2011-07-20 09:38:51 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-20 09:38:51 --> Database Driver Class Initialized
DEBUG - 2011-07-20 09:38:51 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-20 09:38:51 --> Helper loaded: url_helper
DEBUG - 2011-07-20 09:38:51 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-20 09:38:51 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-20 09:38:51 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-20 09:38:51 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-20 09:38:51 --> Final output sent to browser
DEBUG - 2011-07-20 09:38:51 --> Total execution time: 0.1434
DEBUG - 2011-07-20 09:38:52 --> Final output sent to browser
DEBUG - 2011-07-20 09:38:52 --> Total execution time: 4.0091
DEBUG - 2011-07-20 09:38:52 --> Config Class Initialized
DEBUG - 2011-07-20 09:38:52 --> Hooks Class Initialized
DEBUG - 2011-07-20 09:38:53 --> Utf8 Class Initialized
DEBUG - 2011-07-20 09:38:53 --> UTF-8 Support Enabled
DEBUG - 2011-07-20 09:38:53 --> URI Class Initialized
DEBUG - 2011-07-20 09:38:53 --> Router Class Initialized
ERROR - 2011-07-20 09:38:53 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-20 09:38:53 --> Config Class Initialized
DEBUG - 2011-07-20 09:38:53 --> Hooks Class Initialized
DEBUG - 2011-07-20 09:38:53 --> Utf8 Class Initialized
DEBUG - 2011-07-20 09:38:53 --> UTF-8 Support Enabled
DEBUG - 2011-07-20 09:38:53 --> URI Class Initialized
DEBUG - 2011-07-20 09:38:53 --> Router Class Initialized
ERROR - 2011-07-20 09:38:53 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-20 09:38:53 --> Config Class Initialized
DEBUG - 2011-07-20 09:38:53 --> Hooks Class Initialized
DEBUG - 2011-07-20 09:38:53 --> Utf8 Class Initialized
DEBUG - 2011-07-20 09:38:53 --> UTF-8 Support Enabled
DEBUG - 2011-07-20 09:38:53 --> URI Class Initialized
DEBUG - 2011-07-20 09:38:53 --> Router Class Initialized
ERROR - 2011-07-20 09:38:53 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-20 09:41:32 --> Config Class Initialized
DEBUG - 2011-07-20 09:41:32 --> Hooks Class Initialized
DEBUG - 2011-07-20 09:41:32 --> Utf8 Class Initialized
DEBUG - 2011-07-20 09:41:32 --> UTF-8 Support Enabled
DEBUG - 2011-07-20 09:41:32 --> URI Class Initialized
DEBUG - 2011-07-20 09:41:32 --> Router Class Initialized
DEBUG - 2011-07-20 09:41:32 --> Output Class Initialized
DEBUG - 2011-07-20 09:41:32 --> Input Class Initialized
DEBUG - 2011-07-20 09:41:32 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-20 09:41:32 --> Language Class Initialized
DEBUG - 2011-07-20 09:41:32 --> Loader Class Initialized
DEBUG - 2011-07-20 09:41:32 --> Controller Class Initialized
DEBUG - 2011-07-20 09:41:32 --> Model Class Initialized
DEBUG - 2011-07-20 09:41:32 --> Model Class Initialized
DEBUG - 2011-07-20 09:41:32 --> Model Class Initialized
DEBUG - 2011-07-20 09:41:32 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-20 09:41:32 --> Database Driver Class Initialized
DEBUG - 2011-07-20 09:41:34 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-20 09:41:34 --> Helper loaded: url_helper
DEBUG - 2011-07-20 09:41:34 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-20 09:41:34 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-20 09:41:34 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-20 09:41:34 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-20 09:41:34 --> Final output sent to browser
DEBUG - 2011-07-20 09:41:34 --> Total execution time: 2.1343
DEBUG - 2011-07-20 09:41:36 --> Config Class Initialized
DEBUG - 2011-07-20 09:41:36 --> Hooks Class Initialized
DEBUG - 2011-07-20 09:41:36 --> Utf8 Class Initialized
DEBUG - 2011-07-20 09:41:36 --> UTF-8 Support Enabled
DEBUG - 2011-07-20 09:41:36 --> URI Class Initialized
DEBUG - 2011-07-20 09:41:36 --> Router Class Initialized
ERROR - 2011-07-20 09:41:36 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-20 09:59:52 --> Config Class Initialized
DEBUG - 2011-07-20 09:59:52 --> Hooks Class Initialized
DEBUG - 2011-07-20 09:59:52 --> Utf8 Class Initialized
DEBUG - 2011-07-20 09:59:52 --> UTF-8 Support Enabled
DEBUG - 2011-07-20 09:59:52 --> URI Class Initialized
DEBUG - 2011-07-20 09:59:52 --> Router Class Initialized
ERROR - 2011-07-20 09:59:52 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-07-20 09:59:59 --> Config Class Initialized
DEBUG - 2011-07-20 09:59:59 --> Hooks Class Initialized
DEBUG - 2011-07-20 09:59:59 --> Utf8 Class Initialized
DEBUG - 2011-07-20 09:59:59 --> UTF-8 Support Enabled
DEBUG - 2011-07-20 09:59:59 --> URI Class Initialized
DEBUG - 2011-07-20 09:59:59 --> Router Class Initialized
DEBUG - 2011-07-20 09:59:59 --> Output Class Initialized
DEBUG - 2011-07-20 09:59:59 --> Input Class Initialized
DEBUG - 2011-07-20 09:59:59 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-20 09:59:59 --> Language Class Initialized
DEBUG - 2011-07-20 09:59:59 --> Loader Class Initialized
DEBUG - 2011-07-20 09:59:59 --> Controller Class Initialized
ERROR - 2011-07-20 09:59:59 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-20 09:59:59 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-20 09:59:59 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-20 09:59:59 --> Model Class Initialized
DEBUG - 2011-07-20 09:59:59 --> Model Class Initialized
DEBUG - 2011-07-20 09:59:59 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-20 09:59:59 --> Database Driver Class Initialized
DEBUG - 2011-07-20 09:59:59 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-20 09:59:59 --> Helper loaded: url_helper
DEBUG - 2011-07-20 09:59:59 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-20 09:59:59 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-20 09:59:59 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-20 09:59:59 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-20 09:59:59 --> Final output sent to browser
DEBUG - 2011-07-20 09:59:59 --> Total execution time: 0.2857
DEBUG - 2011-07-20 12:51:08 --> Config Class Initialized
DEBUG - 2011-07-20 12:51:08 --> Hooks Class Initialized
DEBUG - 2011-07-20 12:51:08 --> Utf8 Class Initialized
DEBUG - 2011-07-20 12:51:08 --> UTF-8 Support Enabled
DEBUG - 2011-07-20 12:51:08 --> URI Class Initialized
DEBUG - 2011-07-20 12:51:08 --> Router Class Initialized
DEBUG - 2011-07-20 12:51:08 --> Output Class Initialized
DEBUG - 2011-07-20 12:51:08 --> Input Class Initialized
DEBUG - 2011-07-20 12:51:08 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-20 12:51:08 --> Language Class Initialized
DEBUG - 2011-07-20 12:51:08 --> Loader Class Initialized
DEBUG - 2011-07-20 12:51:08 --> Controller Class Initialized
ERROR - 2011-07-20 12:51:08 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-20 12:51:08 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-20 12:51:08 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-20 12:51:08 --> Model Class Initialized
DEBUG - 2011-07-20 12:51:08 --> Model Class Initialized
DEBUG - 2011-07-20 12:51:08 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-20 12:51:09 --> Database Driver Class Initialized
DEBUG - 2011-07-20 12:51:09 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-20 12:51:09 --> Helper loaded: url_helper
DEBUG - 2011-07-20 12:51:09 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-20 12:51:09 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-20 12:51:09 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-20 12:51:09 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-20 12:51:09 --> Final output sent to browser
DEBUG - 2011-07-20 12:51:09 --> Total execution time: 0.8848
DEBUG - 2011-07-20 12:51:11 --> Config Class Initialized
DEBUG - 2011-07-20 12:51:11 --> Hooks Class Initialized
DEBUG - 2011-07-20 12:51:11 --> Utf8 Class Initialized
DEBUG - 2011-07-20 12:51:11 --> UTF-8 Support Enabled
DEBUG - 2011-07-20 12:51:11 --> URI Class Initialized
DEBUG - 2011-07-20 12:51:11 --> Router Class Initialized
DEBUG - 2011-07-20 12:51:11 --> Output Class Initialized
DEBUG - 2011-07-20 12:51:11 --> Input Class Initialized
DEBUG - 2011-07-20 12:51:11 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-20 12:51:11 --> Language Class Initialized
DEBUG - 2011-07-20 12:51:11 --> Loader Class Initialized
DEBUG - 2011-07-20 12:51:11 --> Controller Class Initialized
DEBUG - 2011-07-20 12:51:11 --> Model Class Initialized
DEBUG - 2011-07-20 12:51:11 --> Model Class Initialized
DEBUG - 2011-07-20 12:51:11 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-20 12:51:11 --> Database Driver Class Initialized
DEBUG - 2011-07-20 12:51:13 --> Final output sent to browser
DEBUG - 2011-07-20 12:51:13 --> Total execution time: 1.4851
DEBUG - 2011-07-20 12:51:14 --> Config Class Initialized
DEBUG - 2011-07-20 12:51:14 --> Hooks Class Initialized
DEBUG - 2011-07-20 12:51:14 --> Utf8 Class Initialized
DEBUG - 2011-07-20 12:51:14 --> UTF-8 Support Enabled
DEBUG - 2011-07-20 12:51:14 --> URI Class Initialized
DEBUG - 2011-07-20 12:51:14 --> Router Class Initialized
ERROR - 2011-07-20 12:51:14 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-20 13:33:46 --> Config Class Initialized
DEBUG - 2011-07-20 13:33:46 --> Hooks Class Initialized
DEBUG - 2011-07-20 13:33:46 --> Utf8 Class Initialized
DEBUG - 2011-07-20 13:33:46 --> UTF-8 Support Enabled
DEBUG - 2011-07-20 13:33:46 --> URI Class Initialized
DEBUG - 2011-07-20 13:33:46 --> Router Class Initialized
DEBUG - 2011-07-20 13:33:46 --> Output Class Initialized
DEBUG - 2011-07-20 13:33:46 --> Input Class Initialized
DEBUG - 2011-07-20 13:33:46 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-20 13:33:46 --> Language Class Initialized
DEBUG - 2011-07-20 13:33:46 --> Loader Class Initialized
DEBUG - 2011-07-20 13:33:46 --> Controller Class Initialized
ERROR - 2011-07-20 13:33:46 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-20 13:33:46 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-20 13:33:46 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-20 13:33:46 --> Model Class Initialized
DEBUG - 2011-07-20 13:33:46 --> Model Class Initialized
DEBUG - 2011-07-20 13:33:46 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-20 13:33:46 --> Database Driver Class Initialized
DEBUG - 2011-07-20 13:33:46 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-20 13:33:46 --> Helper loaded: url_helper
DEBUG - 2011-07-20 13:33:46 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-20 13:33:46 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-20 13:33:46 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-20 13:33:46 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-20 13:33:46 --> Final output sent to browser
DEBUG - 2011-07-20 13:33:46 --> Total execution time: 0.4616
DEBUG - 2011-07-20 13:33:49 --> Config Class Initialized
DEBUG - 2011-07-20 13:33:49 --> Hooks Class Initialized
DEBUG - 2011-07-20 13:33:49 --> Utf8 Class Initialized
DEBUG - 2011-07-20 13:33:49 --> UTF-8 Support Enabled
DEBUG - 2011-07-20 13:33:49 --> URI Class Initialized
DEBUG - 2011-07-20 13:33:49 --> Router Class Initialized
DEBUG - 2011-07-20 13:33:49 --> Output Class Initialized
DEBUG - 2011-07-20 13:33:49 --> Input Class Initialized
DEBUG - 2011-07-20 13:33:49 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-20 13:33:49 --> Language Class Initialized
DEBUG - 2011-07-20 13:33:49 --> Loader Class Initialized
DEBUG - 2011-07-20 13:33:49 --> Controller Class Initialized
DEBUG - 2011-07-20 13:33:49 --> Model Class Initialized
DEBUG - 2011-07-20 13:33:49 --> Model Class Initialized
DEBUG - 2011-07-20 13:33:49 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-20 13:33:49 --> Database Driver Class Initialized
DEBUG - 2011-07-20 13:33:51 --> Final output sent to browser
DEBUG - 2011-07-20 13:33:51 --> Total execution time: 1.5923
DEBUG - 2011-07-20 15:17:14 --> Config Class Initialized
DEBUG - 2011-07-20 15:17:14 --> Hooks Class Initialized
DEBUG - 2011-07-20 15:17:14 --> Utf8 Class Initialized
DEBUG - 2011-07-20 15:17:14 --> UTF-8 Support Enabled
DEBUG - 2011-07-20 15:17:14 --> URI Class Initialized
DEBUG - 2011-07-20 15:17:14 --> Router Class Initialized
DEBUG - 2011-07-20 15:17:14 --> Output Class Initialized
DEBUG - 2011-07-20 15:17:14 --> Input Class Initialized
DEBUG - 2011-07-20 15:17:14 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-20 15:17:14 --> Language Class Initialized
DEBUG - 2011-07-20 15:17:14 --> Loader Class Initialized
DEBUG - 2011-07-20 15:17:14 --> Controller Class Initialized
DEBUG - 2011-07-20 15:17:14 --> Model Class Initialized
DEBUG - 2011-07-20 15:17:14 --> Model Class Initialized
DEBUG - 2011-07-20 15:17:14 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-20 15:17:14 --> Database Driver Class Initialized
DEBUG - 2011-07-20 15:17:14 --> Final output sent to browser
DEBUG - 2011-07-20 15:17:14 --> Total execution time: 0.9451
DEBUG - 2011-07-20 15:37:45 --> Config Class Initialized
DEBUG - 2011-07-20 15:37:45 --> Hooks Class Initialized
DEBUG - 2011-07-20 15:37:45 --> Utf8 Class Initialized
DEBUG - 2011-07-20 15:37:45 --> UTF-8 Support Enabled
DEBUG - 2011-07-20 15:37:45 --> URI Class Initialized
DEBUG - 2011-07-20 15:37:45 --> Router Class Initialized
DEBUG - 2011-07-20 15:37:45 --> Output Class Initialized
DEBUG - 2011-07-20 15:37:45 --> Input Class Initialized
DEBUG - 2011-07-20 15:37:45 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-20 15:37:45 --> Language Class Initialized
DEBUG - 2011-07-20 15:37:45 --> Loader Class Initialized
DEBUG - 2011-07-20 15:37:45 --> Controller Class Initialized
ERROR - 2011-07-20 15:37:45 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-20 15:37:45 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-20 15:37:45 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-20 15:37:45 --> Model Class Initialized
DEBUG - 2011-07-20 15:37:45 --> Model Class Initialized
DEBUG - 2011-07-20 15:37:45 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-20 15:37:46 --> Database Driver Class Initialized
DEBUG - 2011-07-20 15:37:46 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-20 15:37:46 --> Helper loaded: url_helper
DEBUG - 2011-07-20 15:37:46 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-20 15:37:46 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-20 15:37:46 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-20 15:37:46 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-20 15:37:46 --> Final output sent to browser
DEBUG - 2011-07-20 15:37:46 --> Total execution time: 1.4763
DEBUG - 2011-07-20 15:37:48 --> Config Class Initialized
DEBUG - 2011-07-20 15:37:48 --> Hooks Class Initialized
DEBUG - 2011-07-20 15:37:48 --> Utf8 Class Initialized
DEBUG - 2011-07-20 15:37:48 --> UTF-8 Support Enabled
DEBUG - 2011-07-20 15:37:48 --> URI Class Initialized
DEBUG - 2011-07-20 15:37:48 --> Router Class Initialized
DEBUG - 2011-07-20 15:37:48 --> Output Class Initialized
DEBUG - 2011-07-20 15:37:48 --> Input Class Initialized
DEBUG - 2011-07-20 15:37:48 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-20 15:37:48 --> Language Class Initialized
DEBUG - 2011-07-20 15:37:48 --> Loader Class Initialized
DEBUG - 2011-07-20 15:37:48 --> Controller Class Initialized
DEBUG - 2011-07-20 15:37:48 --> Model Class Initialized
DEBUG - 2011-07-20 15:37:48 --> Model Class Initialized
DEBUG - 2011-07-20 15:37:48 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-20 15:37:49 --> Database Driver Class Initialized
DEBUG - 2011-07-20 15:37:49 --> Config Class Initialized
DEBUG - 2011-07-20 15:37:49 --> Hooks Class Initialized
DEBUG - 2011-07-20 15:37:49 --> Utf8 Class Initialized
DEBUG - 2011-07-20 15:37:49 --> UTF-8 Support Enabled
DEBUG - 2011-07-20 15:37:49 --> URI Class Initialized
DEBUG - 2011-07-20 15:37:49 --> Router Class Initialized
DEBUG - 2011-07-20 15:37:49 --> No URI present. Default controller set.
DEBUG - 2011-07-20 15:37:49 --> Output Class Initialized
DEBUG - 2011-07-20 15:37:49 --> Input Class Initialized
DEBUG - 2011-07-20 15:37:49 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-20 15:37:49 --> Language Class Initialized
DEBUG - 2011-07-20 15:37:49 --> Loader Class Initialized
DEBUG - 2011-07-20 15:37:49 --> Controller Class Initialized
DEBUG - 2011-07-20 15:37:49 --> File loaded: application/views/splash/main.php
DEBUG - 2011-07-20 15:37:49 --> Helper loaded: url_helper
DEBUG - 2011-07-20 15:37:49 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-20 15:37:49 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-20 15:37:49 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-20 15:37:49 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-20 15:37:49 --> Final output sent to browser
DEBUG - 2011-07-20 15:37:49 --> Total execution time: 0.4526
DEBUG - 2011-07-20 15:37:50 --> Final output sent to browser
DEBUG - 2011-07-20 15:37:50 --> Total execution time: 1.6620
DEBUG - 2011-07-20 15:37:57 --> Config Class Initialized
DEBUG - 2011-07-20 15:37:57 --> Hooks Class Initialized
DEBUG - 2011-07-20 15:37:57 --> Utf8 Class Initialized
DEBUG - 2011-07-20 15:37:57 --> UTF-8 Support Enabled
DEBUG - 2011-07-20 15:37:57 --> URI Class Initialized
DEBUG - 2011-07-20 15:37:57 --> Router Class Initialized
DEBUG - 2011-07-20 15:37:57 --> No URI present. Default controller set.
DEBUG - 2011-07-20 15:37:57 --> Output Class Initialized
DEBUG - 2011-07-20 15:37:57 --> Input Class Initialized
DEBUG - 2011-07-20 15:37:57 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-20 15:37:57 --> Language Class Initialized
DEBUG - 2011-07-20 15:37:57 --> Loader Class Initialized
DEBUG - 2011-07-20 15:37:57 --> Controller Class Initialized
DEBUG - 2011-07-20 15:37:57 --> File loaded: application/views/splash/main.php
DEBUG - 2011-07-20 15:37:57 --> Helper loaded: url_helper
DEBUG - 2011-07-20 15:37:57 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-20 15:37:57 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-20 15:37:57 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-20 15:37:57 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-20 15:37:57 --> Final output sent to browser
DEBUG - 2011-07-20 15:37:57 --> Total execution time: 0.0136
DEBUG - 2011-07-20 15:39:28 --> Config Class Initialized
DEBUG - 2011-07-20 15:39:28 --> Hooks Class Initialized
DEBUG - 2011-07-20 15:39:28 --> Utf8 Class Initialized
DEBUG - 2011-07-20 15:39:28 --> UTF-8 Support Enabled
DEBUG - 2011-07-20 15:39:28 --> URI Class Initialized
DEBUG - 2011-07-20 15:39:28 --> Router Class Initialized
DEBUG - 2011-07-20 15:39:28 --> Output Class Initialized
DEBUG - 2011-07-20 15:39:28 --> Input Class Initialized
DEBUG - 2011-07-20 15:39:28 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-20 15:39:28 --> Language Class Initialized
DEBUG - 2011-07-20 15:39:28 --> Loader Class Initialized
DEBUG - 2011-07-20 15:39:28 --> Controller Class Initialized
ERROR - 2011-07-20 15:39:28 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-20 15:39:28 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-20 15:39:28 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-20 15:39:28 --> Model Class Initialized
DEBUG - 2011-07-20 15:39:28 --> Model Class Initialized
DEBUG - 2011-07-20 15:39:28 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-20 15:39:28 --> Database Driver Class Initialized
DEBUG - 2011-07-20 15:39:28 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-20 15:39:28 --> Helper loaded: url_helper
DEBUG - 2011-07-20 15:39:28 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-20 15:39:28 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-20 15:39:28 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-20 15:39:28 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-20 15:39:28 --> Final output sent to browser
DEBUG - 2011-07-20 15:39:28 --> Total execution time: 0.0420
DEBUG - 2011-07-20 15:39:28 --> Config Class Initialized
DEBUG - 2011-07-20 15:39:28 --> Hooks Class Initialized
DEBUG - 2011-07-20 15:39:28 --> Utf8 Class Initialized
DEBUG - 2011-07-20 15:39:28 --> UTF-8 Support Enabled
DEBUG - 2011-07-20 15:39:28 --> URI Class Initialized
DEBUG - 2011-07-20 15:39:28 --> Router Class Initialized
DEBUG - 2011-07-20 15:39:28 --> Output Class Initialized
DEBUG - 2011-07-20 15:39:28 --> Input Class Initialized
DEBUG - 2011-07-20 15:39:28 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-20 15:39:28 --> Language Class Initialized
DEBUG - 2011-07-20 15:39:28 --> Loader Class Initialized
DEBUG - 2011-07-20 15:39:28 --> Controller Class Initialized
DEBUG - 2011-07-20 15:39:28 --> Model Class Initialized
DEBUG - 2011-07-20 15:39:28 --> Model Class Initialized
DEBUG - 2011-07-20 15:39:28 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-20 15:39:28 --> Database Driver Class Initialized
DEBUG - 2011-07-20 15:39:28 --> Config Class Initialized
DEBUG - 2011-07-20 15:39:28 --> Hooks Class Initialized
DEBUG - 2011-07-20 15:39:28 --> Utf8 Class Initialized
DEBUG - 2011-07-20 15:39:28 --> UTF-8 Support Enabled
DEBUG - 2011-07-20 15:39:28 --> URI Class Initialized
DEBUG - 2011-07-20 15:39:28 --> Router Class Initialized
DEBUG - 2011-07-20 15:39:28 --> Output Class Initialized
DEBUG - 2011-07-20 15:39:28 --> Input Class Initialized
DEBUG - 2011-07-20 15:39:28 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-20 15:39:28 --> Language Class Initialized
DEBUG - 2011-07-20 15:39:28 --> Loader Class Initialized
DEBUG - 2011-07-20 15:39:28 --> Controller Class Initialized
ERROR - 2011-07-20 15:39:28 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-20 15:39:28 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-20 15:39:28 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-20 15:39:28 --> Model Class Initialized
DEBUG - 2011-07-20 15:39:28 --> Model Class Initialized
DEBUG - 2011-07-20 15:39:28 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-20 15:39:28 --> Database Driver Class Initialized
DEBUG - 2011-07-20 15:39:28 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-20 15:39:28 --> Helper loaded: url_helper
DEBUG - 2011-07-20 15:39:28 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-20 15:39:28 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-20 15:39:28 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-20 15:39:28 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-20 15:39:28 --> Final output sent to browser
DEBUG - 2011-07-20 15:39:28 --> Total execution time: 0.0279
DEBUG - 2011-07-20 15:39:29 --> Config Class Initialized
DEBUG - 2011-07-20 15:39:29 --> Hooks Class Initialized
DEBUG - 2011-07-20 15:39:29 --> Utf8 Class Initialized
DEBUG - 2011-07-20 15:39:29 --> UTF-8 Support Enabled
DEBUG - 2011-07-20 15:39:29 --> URI Class Initialized
DEBUG - 2011-07-20 15:39:29 --> Router Class Initialized
DEBUG - 2011-07-20 15:39:29 --> Output Class Initialized
DEBUG - 2011-07-20 15:39:29 --> Input Class Initialized
DEBUG - 2011-07-20 15:39:29 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-20 15:39:29 --> Language Class Initialized
DEBUG - 2011-07-20 15:39:29 --> Loader Class Initialized
DEBUG - 2011-07-20 15:39:29 --> Controller Class Initialized
ERROR - 2011-07-20 15:39:29 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-20 15:39:29 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-20 15:39:29 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-20 15:39:29 --> Model Class Initialized
DEBUG - 2011-07-20 15:39:29 --> Model Class Initialized
DEBUG - 2011-07-20 15:39:29 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-20 15:39:29 --> Database Driver Class Initialized
DEBUG - 2011-07-20 15:39:29 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-20 15:39:29 --> Helper loaded: url_helper
DEBUG - 2011-07-20 15:39:29 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-20 15:39:29 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-20 15:39:29 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-20 15:39:29 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-20 15:39:29 --> Final output sent to browser
DEBUG - 2011-07-20 15:39:29 --> Total execution time: 0.0457
DEBUG - 2011-07-20 15:39:29 --> Final output sent to browser
DEBUG - 2011-07-20 15:39:29 --> Total execution time: 0.7414
DEBUG - 2011-07-20 15:39:41 --> Config Class Initialized
DEBUG - 2011-07-20 15:39:41 --> Hooks Class Initialized
DEBUG - 2011-07-20 15:39:41 --> Utf8 Class Initialized
DEBUG - 2011-07-20 15:39:41 --> UTF-8 Support Enabled
DEBUG - 2011-07-20 15:39:41 --> URI Class Initialized
DEBUG - 2011-07-20 15:39:41 --> Router Class Initialized
DEBUG - 2011-07-20 15:39:41 --> Output Class Initialized
DEBUG - 2011-07-20 15:39:41 --> Input Class Initialized
DEBUG - 2011-07-20 15:39:41 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-20 15:39:41 --> Language Class Initialized
DEBUG - 2011-07-20 15:39:41 --> Loader Class Initialized
DEBUG - 2011-07-20 15:39:41 --> Controller Class Initialized
ERROR - 2011-07-20 15:39:41 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-20 15:39:41 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-20 15:39:41 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-20 15:39:41 --> Model Class Initialized
DEBUG - 2011-07-20 15:39:41 --> Model Class Initialized
DEBUG - 2011-07-20 15:39:41 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-20 15:39:41 --> Database Driver Class Initialized
DEBUG - 2011-07-20 15:39:42 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-20 15:39:42 --> Helper loaded: url_helper
DEBUG - 2011-07-20 15:39:42 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-20 15:39:42 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-20 15:39:42 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-20 15:39:42 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-20 15:39:42 --> Final output sent to browser
DEBUG - 2011-07-20 15:39:42 --> Total execution time: 0.0906
DEBUG - 2011-07-20 15:39:42 --> Config Class Initialized
DEBUG - 2011-07-20 15:39:42 --> Hooks Class Initialized
DEBUG - 2011-07-20 15:39:42 --> Utf8 Class Initialized
DEBUG - 2011-07-20 15:39:42 --> UTF-8 Support Enabled
DEBUG - 2011-07-20 15:39:42 --> URI Class Initialized
DEBUG - 2011-07-20 15:39:42 --> Router Class Initialized
DEBUG - 2011-07-20 15:39:42 --> Output Class Initialized
DEBUG - 2011-07-20 15:39:42 --> Input Class Initialized
DEBUG - 2011-07-20 15:39:42 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-20 15:39:42 --> Language Class Initialized
DEBUG - 2011-07-20 15:39:42 --> Loader Class Initialized
DEBUG - 2011-07-20 15:39:42 --> Controller Class Initialized
DEBUG - 2011-07-20 15:39:42 --> Model Class Initialized
DEBUG - 2011-07-20 15:39:42 --> Model Class Initialized
DEBUG - 2011-07-20 15:39:42 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-20 15:39:42 --> Database Driver Class Initialized
DEBUG - 2011-07-20 15:39:42 --> Final output sent to browser
DEBUG - 2011-07-20 15:39:42 --> Total execution time: 0.6336
DEBUG - 2011-07-20 15:39:47 --> Config Class Initialized
DEBUG - 2011-07-20 15:39:47 --> Hooks Class Initialized
DEBUG - 2011-07-20 15:39:47 --> Utf8 Class Initialized
DEBUG - 2011-07-20 15:39:47 --> UTF-8 Support Enabled
DEBUG - 2011-07-20 15:39:47 --> URI Class Initialized
DEBUG - 2011-07-20 15:39:47 --> Router Class Initialized
DEBUG - 2011-07-20 15:39:47 --> Output Class Initialized
DEBUG - 2011-07-20 15:39:47 --> Input Class Initialized
DEBUG - 2011-07-20 15:39:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-20 15:39:47 --> Language Class Initialized
DEBUG - 2011-07-20 15:39:47 --> Loader Class Initialized
DEBUG - 2011-07-20 15:39:47 --> Controller Class Initialized
ERROR - 2011-07-20 15:39:47 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-20 15:39:47 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-20 15:39:47 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-20 15:39:47 --> Model Class Initialized
DEBUG - 2011-07-20 15:39:47 --> Model Class Initialized
DEBUG - 2011-07-20 15:39:47 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-20 15:39:47 --> Database Driver Class Initialized
DEBUG - 2011-07-20 15:39:47 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-20 15:39:47 --> Helper loaded: url_helper
DEBUG - 2011-07-20 15:39:47 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-20 15:39:47 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-20 15:39:47 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-20 15:39:47 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-20 15:39:47 --> Final output sent to browser
DEBUG - 2011-07-20 15:39:47 --> Total execution time: 0.0308
DEBUG - 2011-07-20 15:39:52 --> Config Class Initialized
DEBUG - 2011-07-20 15:39:52 --> Hooks Class Initialized
DEBUG - 2011-07-20 15:39:52 --> Utf8 Class Initialized
DEBUG - 2011-07-20 15:39:52 --> UTF-8 Support Enabled
DEBUG - 2011-07-20 15:39:52 --> URI Class Initialized
DEBUG - 2011-07-20 15:39:52 --> Router Class Initialized
DEBUG - 2011-07-20 15:39:52 --> Output Class Initialized
DEBUG - 2011-07-20 15:39:52 --> Input Class Initialized
DEBUG - 2011-07-20 15:39:52 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-20 15:39:52 --> Language Class Initialized
DEBUG - 2011-07-20 15:39:52 --> Loader Class Initialized
DEBUG - 2011-07-20 15:39:52 --> Controller Class Initialized
ERROR - 2011-07-20 15:39:52 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-20 15:39:52 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-20 15:39:52 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-20 15:39:52 --> Model Class Initialized
DEBUG - 2011-07-20 15:39:52 --> Model Class Initialized
DEBUG - 2011-07-20 15:39:52 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-20 15:39:52 --> Database Driver Class Initialized
DEBUG - 2011-07-20 15:39:52 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-20 15:39:52 --> Helper loaded: url_helper
DEBUG - 2011-07-20 15:39:52 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-20 15:39:52 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-20 15:39:52 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-20 15:39:52 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-20 15:39:52 --> Final output sent to browser
DEBUG - 2011-07-20 15:39:52 --> Total execution time: 0.0465
DEBUG - 2011-07-20 15:39:52 --> Config Class Initialized
DEBUG - 2011-07-20 15:39:52 --> Hooks Class Initialized
DEBUG - 2011-07-20 15:39:52 --> Utf8 Class Initialized
DEBUG - 2011-07-20 15:39:52 --> UTF-8 Support Enabled
DEBUG - 2011-07-20 15:39:52 --> URI Class Initialized
DEBUG - 2011-07-20 15:39:52 --> Router Class Initialized
DEBUG - 2011-07-20 15:39:52 --> Output Class Initialized
DEBUG - 2011-07-20 15:39:52 --> Input Class Initialized
DEBUG - 2011-07-20 15:39:52 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-20 15:39:52 --> Language Class Initialized
DEBUG - 2011-07-20 15:39:52 --> Loader Class Initialized
DEBUG - 2011-07-20 15:39:52 --> Controller Class Initialized
DEBUG - 2011-07-20 15:39:52 --> Model Class Initialized
DEBUG - 2011-07-20 15:39:52 --> Model Class Initialized
DEBUG - 2011-07-20 15:39:52 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-20 15:39:52 --> Database Driver Class Initialized
DEBUG - 2011-07-20 15:39:52 --> Final output sent to browser
DEBUG - 2011-07-20 15:39:52 --> Total execution time: 0.5202
DEBUG - 2011-07-20 15:39:57 --> Config Class Initialized
DEBUG - 2011-07-20 15:39:57 --> Hooks Class Initialized
DEBUG - 2011-07-20 15:39:57 --> Utf8 Class Initialized
DEBUG - 2011-07-20 15:39:57 --> UTF-8 Support Enabled
DEBUG - 2011-07-20 15:39:57 --> URI Class Initialized
DEBUG - 2011-07-20 15:39:57 --> Router Class Initialized
DEBUG - 2011-07-20 15:39:57 --> Output Class Initialized
DEBUG - 2011-07-20 15:39:57 --> Input Class Initialized
DEBUG - 2011-07-20 15:39:57 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-20 15:39:57 --> Language Class Initialized
DEBUG - 2011-07-20 15:39:57 --> Loader Class Initialized
DEBUG - 2011-07-20 15:39:57 --> Controller Class Initialized
ERROR - 2011-07-20 15:39:57 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-20 15:39:57 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-20 15:39:57 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-20 15:39:57 --> Model Class Initialized
DEBUG - 2011-07-20 15:39:57 --> Model Class Initialized
DEBUG - 2011-07-20 15:39:57 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-20 15:39:57 --> Database Driver Class Initialized
DEBUG - 2011-07-20 15:39:57 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-20 15:39:57 --> Helper loaded: url_helper
DEBUG - 2011-07-20 15:39:57 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-20 15:39:57 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-20 15:39:57 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-20 15:39:57 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-20 15:39:57 --> Final output sent to browser
DEBUG - 2011-07-20 15:39:57 --> Total execution time: 0.0287
DEBUG - 2011-07-20 15:39:57 --> Config Class Initialized
DEBUG - 2011-07-20 15:39:57 --> Hooks Class Initialized
DEBUG - 2011-07-20 15:39:57 --> Utf8 Class Initialized
DEBUG - 2011-07-20 15:39:57 --> UTF-8 Support Enabled
DEBUG - 2011-07-20 15:39:57 --> URI Class Initialized
DEBUG - 2011-07-20 15:39:57 --> Router Class Initialized
DEBUG - 2011-07-20 15:39:57 --> Output Class Initialized
DEBUG - 2011-07-20 15:39:57 --> Input Class Initialized
DEBUG - 2011-07-20 15:39:57 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-20 15:39:57 --> Language Class Initialized
DEBUG - 2011-07-20 15:39:57 --> Loader Class Initialized
DEBUG - 2011-07-20 15:39:57 --> Controller Class Initialized
DEBUG - 2011-07-20 15:39:57 --> Model Class Initialized
DEBUG - 2011-07-20 15:39:57 --> Model Class Initialized
DEBUG - 2011-07-20 15:39:57 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-20 15:39:57 --> Database Driver Class Initialized
DEBUG - 2011-07-20 15:39:58 --> Final output sent to browser
DEBUG - 2011-07-20 15:39:58 --> Total execution time: 0.6471
DEBUG - 2011-07-20 15:40:02 --> Config Class Initialized
DEBUG - 2011-07-20 15:40:02 --> Hooks Class Initialized
DEBUG - 2011-07-20 15:40:02 --> Utf8 Class Initialized
DEBUG - 2011-07-20 15:40:02 --> UTF-8 Support Enabled
DEBUG - 2011-07-20 15:40:02 --> URI Class Initialized
DEBUG - 2011-07-20 15:40:02 --> Router Class Initialized
DEBUG - 2011-07-20 15:40:02 --> Output Class Initialized
DEBUG - 2011-07-20 15:40:02 --> Input Class Initialized
DEBUG - 2011-07-20 15:40:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-20 15:40:02 --> Language Class Initialized
DEBUG - 2011-07-20 15:40:02 --> Loader Class Initialized
DEBUG - 2011-07-20 15:40:02 --> Controller Class Initialized
ERROR - 2011-07-20 15:40:02 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-20 15:40:02 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-20 15:40:02 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-20 15:40:02 --> Model Class Initialized
DEBUG - 2011-07-20 15:40:02 --> Model Class Initialized
DEBUG - 2011-07-20 15:40:02 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-20 15:40:02 --> Database Driver Class Initialized
DEBUG - 2011-07-20 15:40:02 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-20 15:40:02 --> Helper loaded: url_helper
DEBUG - 2011-07-20 15:40:02 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-20 15:40:02 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-20 15:40:02 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-20 15:40:02 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-20 15:40:02 --> Final output sent to browser
DEBUG - 2011-07-20 15:40:02 --> Total execution time: 0.1456
DEBUG - 2011-07-20 15:40:03 --> Config Class Initialized
DEBUG - 2011-07-20 15:40:03 --> Hooks Class Initialized
DEBUG - 2011-07-20 15:40:03 --> Utf8 Class Initialized
DEBUG - 2011-07-20 15:40:03 --> UTF-8 Support Enabled
DEBUG - 2011-07-20 15:40:03 --> URI Class Initialized
DEBUG - 2011-07-20 15:40:03 --> Router Class Initialized
DEBUG - 2011-07-20 15:40:03 --> Output Class Initialized
DEBUG - 2011-07-20 15:40:03 --> Input Class Initialized
DEBUG - 2011-07-20 15:40:03 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-20 15:40:03 --> Language Class Initialized
DEBUG - 2011-07-20 15:40:03 --> Loader Class Initialized
DEBUG - 2011-07-20 15:40:03 --> Controller Class Initialized
ERROR - 2011-07-20 15:40:03 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-20 15:40:03 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-20 15:40:03 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-20 15:40:03 --> Model Class Initialized
DEBUG - 2011-07-20 15:40:03 --> Model Class Initialized
DEBUG - 2011-07-20 15:40:03 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-20 15:40:03 --> Database Driver Class Initialized
DEBUG - 2011-07-20 15:40:03 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-20 15:40:03 --> Helper loaded: url_helper
DEBUG - 2011-07-20 15:40:03 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-20 15:40:03 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-20 15:40:03 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-20 15:40:03 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-20 15:40:03 --> Final output sent to browser
DEBUG - 2011-07-20 15:40:03 --> Total execution time: 0.1907
DEBUG - 2011-07-20 15:40:04 --> Config Class Initialized
DEBUG - 2011-07-20 15:40:04 --> Hooks Class Initialized
DEBUG - 2011-07-20 15:40:04 --> Utf8 Class Initialized
DEBUG - 2011-07-20 15:40:04 --> UTF-8 Support Enabled
DEBUG - 2011-07-20 15:40:04 --> URI Class Initialized
DEBUG - 2011-07-20 15:40:04 --> Router Class Initialized
DEBUG - 2011-07-20 15:40:04 --> Output Class Initialized
DEBUG - 2011-07-20 15:40:04 --> Input Class Initialized
DEBUG - 2011-07-20 15:40:04 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-20 15:40:04 --> Language Class Initialized
DEBUG - 2011-07-20 15:40:04 --> Loader Class Initialized
DEBUG - 2011-07-20 15:40:04 --> Controller Class Initialized
DEBUG - 2011-07-20 15:40:04 --> Model Class Initialized
DEBUG - 2011-07-20 15:40:04 --> Model Class Initialized
DEBUG - 2011-07-20 15:40:04 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-20 15:40:04 --> Database Driver Class Initialized
DEBUG - 2011-07-20 15:40:05 --> Final output sent to browser
DEBUG - 2011-07-20 15:40:05 --> Total execution time: 1.1168
DEBUG - 2011-07-20 15:40:09 --> Config Class Initialized
DEBUG - 2011-07-20 15:40:09 --> Hooks Class Initialized
DEBUG - 2011-07-20 15:40:09 --> Utf8 Class Initialized
DEBUG - 2011-07-20 15:40:09 --> UTF-8 Support Enabled
DEBUG - 2011-07-20 15:40:09 --> URI Class Initialized
DEBUG - 2011-07-20 15:40:09 --> Router Class Initialized
DEBUG - 2011-07-20 15:40:09 --> Output Class Initialized
DEBUG - 2011-07-20 15:40:09 --> Input Class Initialized
DEBUG - 2011-07-20 15:40:09 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-20 15:40:09 --> Language Class Initialized
DEBUG - 2011-07-20 15:40:09 --> Loader Class Initialized
DEBUG - 2011-07-20 15:40:09 --> Controller Class Initialized
ERROR - 2011-07-20 15:40:09 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-20 15:40:09 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-20 15:40:09 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-20 15:40:09 --> Model Class Initialized
DEBUG - 2011-07-20 15:40:09 --> Model Class Initialized
DEBUG - 2011-07-20 15:40:09 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-20 15:40:09 --> Database Driver Class Initialized
DEBUG - 2011-07-20 15:40:09 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-20 15:40:09 --> Helper loaded: url_helper
DEBUG - 2011-07-20 15:40:09 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-20 15:40:09 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-20 15:40:09 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-20 15:40:09 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-20 15:40:09 --> Final output sent to browser
DEBUG - 2011-07-20 15:40:09 --> Total execution time: 0.0395
DEBUG - 2011-07-20 15:40:09 --> Config Class Initialized
DEBUG - 2011-07-20 15:40:09 --> Hooks Class Initialized
DEBUG - 2011-07-20 15:40:09 --> Utf8 Class Initialized
DEBUG - 2011-07-20 15:40:09 --> UTF-8 Support Enabled
DEBUG - 2011-07-20 15:40:09 --> URI Class Initialized
DEBUG - 2011-07-20 15:40:09 --> Router Class Initialized
DEBUG - 2011-07-20 15:40:09 --> Output Class Initialized
DEBUG - 2011-07-20 15:40:09 --> Input Class Initialized
DEBUG - 2011-07-20 15:40:09 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-20 15:40:09 --> Language Class Initialized
DEBUG - 2011-07-20 15:40:09 --> Loader Class Initialized
DEBUG - 2011-07-20 15:40:09 --> Controller Class Initialized
ERROR - 2011-07-20 15:40:09 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-20 15:40:09 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-20 15:40:09 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-20 15:40:09 --> Model Class Initialized
DEBUG - 2011-07-20 15:40:09 --> Model Class Initialized
DEBUG - 2011-07-20 15:40:09 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-20 15:40:09 --> Database Driver Class Initialized
DEBUG - 2011-07-20 15:40:09 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-20 15:40:09 --> Helper loaded: url_helper
DEBUG - 2011-07-20 15:40:09 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-20 15:40:09 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-20 15:40:09 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-20 15:40:09 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-20 15:40:09 --> Final output sent to browser
DEBUG - 2011-07-20 15:40:09 --> Total execution time: 0.0287
DEBUG - 2011-07-20 15:40:11 --> Config Class Initialized
DEBUG - 2011-07-20 15:40:11 --> Hooks Class Initialized
DEBUG - 2011-07-20 15:40:11 --> Utf8 Class Initialized
DEBUG - 2011-07-20 15:40:11 --> UTF-8 Support Enabled
DEBUG - 2011-07-20 15:40:11 --> URI Class Initialized
DEBUG - 2011-07-20 15:40:11 --> Router Class Initialized
DEBUG - 2011-07-20 15:40:11 --> Output Class Initialized
DEBUG - 2011-07-20 15:40:11 --> Input Class Initialized
DEBUG - 2011-07-20 15:40:11 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-20 15:40:11 --> Language Class Initialized
DEBUG - 2011-07-20 15:40:11 --> Loader Class Initialized
DEBUG - 2011-07-20 15:40:11 --> Controller Class Initialized
ERROR - 2011-07-20 15:40:11 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-20 15:40:11 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-20 15:40:11 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-20 15:40:11 --> Model Class Initialized
DEBUG - 2011-07-20 15:40:11 --> Model Class Initialized
DEBUG - 2011-07-20 15:40:11 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-20 15:40:11 --> Database Driver Class Initialized
DEBUG - 2011-07-20 15:40:11 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-20 15:40:11 --> Helper loaded: url_helper
DEBUG - 2011-07-20 15:40:11 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-20 15:40:11 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-20 15:40:11 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-20 15:40:11 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-20 15:40:11 --> Final output sent to browser
DEBUG - 2011-07-20 15:40:11 --> Total execution time: 0.0287
DEBUG - 2011-07-20 17:47:21 --> Config Class Initialized
DEBUG - 2011-07-20 17:47:21 --> Hooks Class Initialized
DEBUG - 2011-07-20 17:47:21 --> Utf8 Class Initialized
DEBUG - 2011-07-20 17:47:21 --> UTF-8 Support Enabled
DEBUG - 2011-07-20 17:47:21 --> URI Class Initialized
DEBUG - 2011-07-20 17:47:21 --> Router Class Initialized
DEBUG - 2011-07-20 17:47:21 --> Output Class Initialized
DEBUG - 2011-07-20 17:47:21 --> Input Class Initialized
DEBUG - 2011-07-20 17:47:21 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-20 17:47:21 --> Language Class Initialized
DEBUG - 2011-07-20 17:47:21 --> Loader Class Initialized
DEBUG - 2011-07-20 17:47:21 --> Controller Class Initialized
ERROR - 2011-07-20 17:47:21 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-20 17:47:21 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-20 17:47:21 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-20 17:47:21 --> Model Class Initialized
DEBUG - 2011-07-20 17:47:21 --> Model Class Initialized
DEBUG - 2011-07-20 17:47:22 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-20 17:47:22 --> Database Driver Class Initialized
DEBUG - 2011-07-20 17:47:23 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-20 17:47:24 --> Helper loaded: url_helper
DEBUG - 2011-07-20 17:47:24 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-20 17:47:24 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-20 17:47:24 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-20 17:47:24 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-20 17:47:24 --> Final output sent to browser
DEBUG - 2011-07-20 17:47:24 --> Total execution time: 2.7120
DEBUG - 2011-07-20 17:47:24 --> Config Class Initialized
DEBUG - 2011-07-20 17:47:24 --> Hooks Class Initialized
DEBUG - 2011-07-20 17:47:24 --> Utf8 Class Initialized
DEBUG - 2011-07-20 17:47:24 --> UTF-8 Support Enabled
DEBUG - 2011-07-20 17:47:24 --> URI Class Initialized
DEBUG - 2011-07-20 17:47:24 --> Router Class Initialized
DEBUG - 2011-07-20 17:47:24 --> Output Class Initialized
DEBUG - 2011-07-20 17:47:24 --> Input Class Initialized
DEBUG - 2011-07-20 17:47:24 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-20 17:47:24 --> Language Class Initialized
DEBUG - 2011-07-20 17:47:24 --> Loader Class Initialized
DEBUG - 2011-07-20 17:47:24 --> Controller Class Initialized
DEBUG - 2011-07-20 17:47:24 --> Model Class Initialized
DEBUG - 2011-07-20 17:47:24 --> Model Class Initialized
DEBUG - 2011-07-20 17:47:24 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-20 17:47:24 --> Database Driver Class Initialized
DEBUG - 2011-07-20 17:47:25 --> Final output sent to browser
DEBUG - 2011-07-20 17:47:25 --> Total execution time: 1.2120
DEBUG - 2011-07-20 17:47:26 --> Config Class Initialized
DEBUG - 2011-07-20 17:47:26 --> Hooks Class Initialized
DEBUG - 2011-07-20 17:47:26 --> Utf8 Class Initialized
DEBUG - 2011-07-20 17:47:26 --> UTF-8 Support Enabled
DEBUG - 2011-07-20 17:47:26 --> URI Class Initialized
DEBUG - 2011-07-20 17:47:26 --> Router Class Initialized
ERROR - 2011-07-20 17:47:26 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-20 17:47:27 --> Config Class Initialized
DEBUG - 2011-07-20 17:47:27 --> Hooks Class Initialized
DEBUG - 2011-07-20 17:47:27 --> Utf8 Class Initialized
DEBUG - 2011-07-20 17:47:27 --> UTF-8 Support Enabled
DEBUG - 2011-07-20 17:47:27 --> URI Class Initialized
DEBUG - 2011-07-20 17:47:27 --> Router Class Initialized
ERROR - 2011-07-20 17:47:27 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-20 17:47:30 --> Config Class Initialized
DEBUG - 2011-07-20 17:47:30 --> Hooks Class Initialized
DEBUG - 2011-07-20 17:47:30 --> Utf8 Class Initialized
DEBUG - 2011-07-20 17:47:30 --> UTF-8 Support Enabled
DEBUG - 2011-07-20 17:47:30 --> URI Class Initialized
DEBUG - 2011-07-20 17:47:30 --> Router Class Initialized
DEBUG - 2011-07-20 17:47:30 --> Output Class Initialized
DEBUG - 2011-07-20 17:47:30 --> Input Class Initialized
DEBUG - 2011-07-20 17:47:30 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-20 17:47:30 --> Language Class Initialized
DEBUG - 2011-07-20 17:47:30 --> Loader Class Initialized
DEBUG - 2011-07-20 17:47:30 --> Controller Class Initialized
ERROR - 2011-07-20 17:47:30 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-20 17:47:30 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-20 17:47:30 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-20 17:47:30 --> Model Class Initialized
DEBUG - 2011-07-20 17:47:30 --> Model Class Initialized
DEBUG - 2011-07-20 17:47:30 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-20 17:47:30 --> Database Driver Class Initialized
DEBUG - 2011-07-20 17:47:30 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-20 17:47:30 --> Helper loaded: url_helper
DEBUG - 2011-07-20 17:47:30 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-20 17:47:30 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-20 17:47:30 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-20 17:47:30 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-20 17:47:30 --> Final output sent to browser
DEBUG - 2011-07-20 17:47:30 --> Total execution time: 0.1371
DEBUG - 2011-07-20 17:47:30 --> Config Class Initialized
DEBUG - 2011-07-20 17:47:30 --> Hooks Class Initialized
DEBUG - 2011-07-20 17:47:30 --> Utf8 Class Initialized
DEBUG - 2011-07-20 17:47:30 --> UTF-8 Support Enabled
DEBUG - 2011-07-20 17:47:30 --> URI Class Initialized
DEBUG - 2011-07-20 17:47:30 --> Router Class Initialized
DEBUG - 2011-07-20 17:47:30 --> Output Class Initialized
DEBUG - 2011-07-20 17:47:30 --> Input Class Initialized
DEBUG - 2011-07-20 17:47:30 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-20 17:47:30 --> Language Class Initialized
DEBUG - 2011-07-20 17:47:30 --> Loader Class Initialized
DEBUG - 2011-07-20 17:47:30 --> Controller Class Initialized
DEBUG - 2011-07-20 17:47:30 --> Model Class Initialized
DEBUG - 2011-07-20 17:47:30 --> Model Class Initialized
DEBUG - 2011-07-20 17:47:30 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-20 17:47:30 --> Database Driver Class Initialized
DEBUG - 2011-07-20 17:47:31 --> Config Class Initialized
DEBUG - 2011-07-20 17:47:31 --> Hooks Class Initialized
DEBUG - 2011-07-20 17:47:31 --> Utf8 Class Initialized
DEBUG - 2011-07-20 17:47:31 --> UTF-8 Support Enabled
DEBUG - 2011-07-20 17:47:31 --> URI Class Initialized
DEBUG - 2011-07-20 17:47:31 --> Router Class Initialized
ERROR - 2011-07-20 17:47:31 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-07-20 17:47:31 --> Config Class Initialized
DEBUG - 2011-07-20 17:47:31 --> Hooks Class Initialized
DEBUG - 2011-07-20 17:47:31 --> Utf8 Class Initialized
DEBUG - 2011-07-20 17:47:31 --> UTF-8 Support Enabled
DEBUG - 2011-07-20 17:47:31 --> URI Class Initialized
DEBUG - 2011-07-20 17:47:31 --> Router Class Initialized
ERROR - 2011-07-20 17:47:31 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-07-20 17:47:31 --> Final output sent to browser
DEBUG - 2011-07-20 17:47:31 --> Total execution time: 0.8823
DEBUG - 2011-07-20 17:47:31 --> Config Class Initialized
DEBUG - 2011-07-20 17:47:31 --> Hooks Class Initialized
DEBUG - 2011-07-20 17:47:31 --> Utf8 Class Initialized
DEBUG - 2011-07-20 17:47:31 --> UTF-8 Support Enabled
DEBUG - 2011-07-20 17:47:31 --> URI Class Initialized
DEBUG - 2011-07-20 17:47:31 --> Router Class Initialized
DEBUG - 2011-07-20 17:47:31 --> Output Class Initialized
DEBUG - 2011-07-20 17:47:31 --> Input Class Initialized
DEBUG - 2011-07-20 17:47:31 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-20 17:47:31 --> Language Class Initialized
DEBUG - 2011-07-20 17:47:31 --> Loader Class Initialized
DEBUG - 2011-07-20 17:47:31 --> Controller Class Initialized
ERROR - 2011-07-20 17:47:31 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-20 17:47:31 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-20 17:47:31 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-20 17:47:31 --> Model Class Initialized
DEBUG - 2011-07-20 17:47:31 --> Model Class Initialized
DEBUG - 2011-07-20 17:47:31 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-20 17:47:31 --> Database Driver Class Initialized
DEBUG - 2011-07-20 17:47:31 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-20 17:47:31 --> Helper loaded: url_helper
DEBUG - 2011-07-20 17:47:31 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-20 17:47:31 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-20 17:47:31 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-20 17:47:31 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-20 17:47:31 --> Final output sent to browser
DEBUG - 2011-07-20 17:47:31 --> Total execution time: 0.0340
DEBUG - 2011-07-20 17:47:49 --> Config Class Initialized
DEBUG - 2011-07-20 17:47:49 --> Hooks Class Initialized
DEBUG - 2011-07-20 17:47:49 --> Utf8 Class Initialized
DEBUG - 2011-07-20 17:47:49 --> UTF-8 Support Enabled
DEBUG - 2011-07-20 17:47:49 --> URI Class Initialized
DEBUG - 2011-07-20 17:47:49 --> Router Class Initialized
DEBUG - 2011-07-20 17:47:49 --> Output Class Initialized
DEBUG - 2011-07-20 17:47:49 --> Input Class Initialized
DEBUG - 2011-07-20 17:47:49 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-20 17:47:49 --> Language Class Initialized
DEBUG - 2011-07-20 17:47:49 --> Loader Class Initialized
DEBUG - 2011-07-20 17:47:49 --> Controller Class Initialized
ERROR - 2011-07-20 17:47:49 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-20 17:47:49 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-20 17:47:49 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-20 17:47:49 --> Model Class Initialized
DEBUG - 2011-07-20 17:47:49 --> Model Class Initialized
DEBUG - 2011-07-20 17:47:49 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-20 17:47:49 --> Database Driver Class Initialized
DEBUG - 2011-07-20 17:47:49 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-20 17:47:49 --> Helper loaded: url_helper
DEBUG - 2011-07-20 17:47:49 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-20 17:47:49 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-20 17:47:49 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-20 17:47:49 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-20 17:47:49 --> Final output sent to browser
DEBUG - 2011-07-20 17:47:49 --> Total execution time: 0.0374
DEBUG - 2011-07-20 17:47:49 --> Config Class Initialized
DEBUG - 2011-07-20 17:47:49 --> Hooks Class Initialized
DEBUG - 2011-07-20 17:47:49 --> Utf8 Class Initialized
DEBUG - 2011-07-20 17:47:49 --> UTF-8 Support Enabled
DEBUG - 2011-07-20 17:47:49 --> URI Class Initialized
DEBUG - 2011-07-20 17:47:49 --> Router Class Initialized
DEBUG - 2011-07-20 17:47:49 --> Output Class Initialized
DEBUG - 2011-07-20 17:47:49 --> Input Class Initialized
DEBUG - 2011-07-20 17:47:49 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-20 17:47:49 --> Language Class Initialized
DEBUG - 2011-07-20 17:47:49 --> Loader Class Initialized
DEBUG - 2011-07-20 17:47:49 --> Controller Class Initialized
DEBUG - 2011-07-20 17:47:49 --> Model Class Initialized
DEBUG - 2011-07-20 17:47:49 --> Model Class Initialized
DEBUG - 2011-07-20 17:47:49 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-20 17:47:49 --> Database Driver Class Initialized
DEBUG - 2011-07-20 17:47:50 --> Final output sent to browser
DEBUG - 2011-07-20 17:47:50 --> Total execution time: 0.8199
DEBUG - 2011-07-20 17:47:51 --> Config Class Initialized
DEBUG - 2011-07-20 17:47:51 --> Hooks Class Initialized
DEBUG - 2011-07-20 17:47:51 --> Utf8 Class Initialized
DEBUG - 2011-07-20 17:47:51 --> UTF-8 Support Enabled
DEBUG - 2011-07-20 17:47:51 --> URI Class Initialized
DEBUG - 2011-07-20 17:47:51 --> Router Class Initialized
DEBUG - 2011-07-20 17:47:51 --> Output Class Initialized
DEBUG - 2011-07-20 17:47:51 --> Input Class Initialized
DEBUG - 2011-07-20 17:47:51 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-20 17:47:51 --> Language Class Initialized
DEBUG - 2011-07-20 17:47:51 --> Loader Class Initialized
DEBUG - 2011-07-20 17:47:51 --> Controller Class Initialized
ERROR - 2011-07-20 17:47:51 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-20 17:47:51 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-20 17:47:51 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-20 17:47:51 --> Model Class Initialized
DEBUG - 2011-07-20 17:47:51 --> Model Class Initialized
DEBUG - 2011-07-20 17:47:51 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-20 17:47:51 --> Database Driver Class Initialized
DEBUG - 2011-07-20 17:47:51 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-20 17:47:51 --> Helper loaded: url_helper
DEBUG - 2011-07-20 17:47:51 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-20 17:47:51 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-20 17:47:51 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-20 17:47:51 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-20 17:47:51 --> Final output sent to browser
DEBUG - 2011-07-20 17:47:51 --> Total execution time: 0.0398
DEBUG - 2011-07-20 17:48:33 --> Config Class Initialized
DEBUG - 2011-07-20 17:48:33 --> Hooks Class Initialized
DEBUG - 2011-07-20 17:48:33 --> Utf8 Class Initialized
DEBUG - 2011-07-20 17:48:33 --> UTF-8 Support Enabled
DEBUG - 2011-07-20 17:48:33 --> URI Class Initialized
DEBUG - 2011-07-20 17:48:33 --> Router Class Initialized
DEBUG - 2011-07-20 17:48:33 --> Output Class Initialized
DEBUG - 2011-07-20 17:48:33 --> Input Class Initialized
DEBUG - 2011-07-20 17:48:33 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-20 17:48:33 --> Language Class Initialized
DEBUG - 2011-07-20 17:48:33 --> Loader Class Initialized
DEBUG - 2011-07-20 17:48:33 --> Controller Class Initialized
ERROR - 2011-07-20 17:48:33 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-20 17:48:33 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-20 17:48:33 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-20 17:48:33 --> Model Class Initialized
DEBUG - 2011-07-20 17:48:33 --> Model Class Initialized
DEBUG - 2011-07-20 17:48:33 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-20 17:48:33 --> Database Driver Class Initialized
DEBUG - 2011-07-20 17:48:33 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-20 17:48:33 --> Helper loaded: url_helper
DEBUG - 2011-07-20 17:48:33 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-20 17:48:33 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-20 17:48:33 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-20 17:48:33 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-20 17:48:33 --> Final output sent to browser
DEBUG - 2011-07-20 17:48:33 --> Total execution time: 0.0340
DEBUG - 2011-07-20 17:48:33 --> Config Class Initialized
DEBUG - 2011-07-20 17:48:33 --> Hooks Class Initialized
DEBUG - 2011-07-20 17:48:33 --> Utf8 Class Initialized
DEBUG - 2011-07-20 17:48:33 --> UTF-8 Support Enabled
DEBUG - 2011-07-20 17:48:33 --> URI Class Initialized
DEBUG - 2011-07-20 17:48:33 --> Router Class Initialized
DEBUG - 2011-07-20 17:48:33 --> Output Class Initialized
DEBUG - 2011-07-20 17:48:33 --> Input Class Initialized
DEBUG - 2011-07-20 17:48:33 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-20 17:48:33 --> Language Class Initialized
DEBUG - 2011-07-20 17:48:33 --> Loader Class Initialized
DEBUG - 2011-07-20 17:48:33 --> Controller Class Initialized
DEBUG - 2011-07-20 17:48:33 --> Model Class Initialized
DEBUG - 2011-07-20 17:48:33 --> Model Class Initialized
DEBUG - 2011-07-20 17:48:33 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-20 17:48:33 --> Database Driver Class Initialized
DEBUG - 2011-07-20 17:48:34 --> Config Class Initialized
DEBUG - 2011-07-20 17:48:34 --> Hooks Class Initialized
DEBUG - 2011-07-20 17:48:34 --> Utf8 Class Initialized
DEBUG - 2011-07-20 17:48:34 --> UTF-8 Support Enabled
DEBUG - 2011-07-20 17:48:34 --> URI Class Initialized
DEBUG - 2011-07-20 17:48:34 --> Router Class Initialized
DEBUG - 2011-07-20 17:48:34 --> Output Class Initialized
DEBUG - 2011-07-20 17:48:34 --> Input Class Initialized
DEBUG - 2011-07-20 17:48:34 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-20 17:48:34 --> Language Class Initialized
DEBUG - 2011-07-20 17:48:34 --> Loader Class Initialized
DEBUG - 2011-07-20 17:48:34 --> Controller Class Initialized
ERROR - 2011-07-20 17:48:34 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-20 17:48:34 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-20 17:48:34 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-20 17:48:34 --> Model Class Initialized
DEBUG - 2011-07-20 17:48:34 --> Model Class Initialized
DEBUG - 2011-07-20 17:48:34 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-20 17:48:34 --> Database Driver Class Initialized
DEBUG - 2011-07-20 17:48:34 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-20 17:48:34 --> Helper loaded: url_helper
DEBUG - 2011-07-20 17:48:34 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-20 17:48:34 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-20 17:48:34 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-20 17:48:34 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-20 17:48:34 --> Final output sent to browser
DEBUG - 2011-07-20 17:48:34 --> Total execution time: 0.0683
DEBUG - 2011-07-20 17:48:34 --> Final output sent to browser
DEBUG - 2011-07-20 17:48:34 --> Total execution time: 1.0282
DEBUG - 2011-07-20 17:48:40 --> Config Class Initialized
DEBUG - 2011-07-20 17:48:40 --> Hooks Class Initialized
DEBUG - 2011-07-20 17:48:40 --> Utf8 Class Initialized
DEBUG - 2011-07-20 17:48:40 --> UTF-8 Support Enabled
DEBUG - 2011-07-20 17:48:40 --> URI Class Initialized
DEBUG - 2011-07-20 17:48:40 --> Router Class Initialized
DEBUG - 2011-07-20 17:48:40 --> Output Class Initialized
DEBUG - 2011-07-20 17:48:40 --> Input Class Initialized
DEBUG - 2011-07-20 17:48:40 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-20 17:48:40 --> Language Class Initialized
DEBUG - 2011-07-20 17:48:40 --> Loader Class Initialized
DEBUG - 2011-07-20 17:48:40 --> Controller Class Initialized
ERROR - 2011-07-20 17:48:40 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-20 17:48:40 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-20 17:48:40 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-20 17:48:40 --> Model Class Initialized
DEBUG - 2011-07-20 17:48:40 --> Model Class Initialized
DEBUG - 2011-07-20 17:48:40 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-20 17:48:40 --> Database Driver Class Initialized
DEBUG - 2011-07-20 17:48:40 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-20 17:48:40 --> Helper loaded: url_helper
DEBUG - 2011-07-20 17:48:40 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-20 17:48:40 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-20 17:48:40 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-20 17:48:40 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-20 17:48:40 --> Final output sent to browser
DEBUG - 2011-07-20 17:48:40 --> Total execution time: 0.0524
DEBUG - 2011-07-20 17:48:40 --> Config Class Initialized
DEBUG - 2011-07-20 17:48:40 --> Hooks Class Initialized
DEBUG - 2011-07-20 17:48:40 --> Utf8 Class Initialized
DEBUG - 2011-07-20 17:48:40 --> UTF-8 Support Enabled
DEBUG - 2011-07-20 17:48:40 --> URI Class Initialized
DEBUG - 2011-07-20 17:48:40 --> Router Class Initialized
DEBUG - 2011-07-20 17:48:40 --> Output Class Initialized
DEBUG - 2011-07-20 17:48:40 --> Input Class Initialized
DEBUG - 2011-07-20 17:48:40 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-20 17:48:40 --> Language Class Initialized
DEBUG - 2011-07-20 17:48:40 --> Loader Class Initialized
DEBUG - 2011-07-20 17:48:40 --> Controller Class Initialized
DEBUG - 2011-07-20 17:48:40 --> Model Class Initialized
DEBUG - 2011-07-20 17:48:40 --> Model Class Initialized
DEBUG - 2011-07-20 17:48:40 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-20 17:48:40 --> Database Driver Class Initialized
DEBUG - 2011-07-20 17:48:40 --> Config Class Initialized
DEBUG - 2011-07-20 17:48:40 --> Hooks Class Initialized
DEBUG - 2011-07-20 17:48:40 --> Utf8 Class Initialized
DEBUG - 2011-07-20 17:48:40 --> UTF-8 Support Enabled
DEBUG - 2011-07-20 17:48:40 --> URI Class Initialized
DEBUG - 2011-07-20 17:48:40 --> Router Class Initialized
DEBUG - 2011-07-20 17:48:40 --> Output Class Initialized
DEBUG - 2011-07-20 17:48:40 --> Input Class Initialized
DEBUG - 2011-07-20 17:48:40 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-20 17:48:40 --> Language Class Initialized
DEBUG - 2011-07-20 17:48:40 --> Loader Class Initialized
DEBUG - 2011-07-20 17:48:40 --> Controller Class Initialized
ERROR - 2011-07-20 17:48:40 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-20 17:48:40 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-20 17:48:40 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-20 17:48:40 --> Model Class Initialized
DEBUG - 2011-07-20 17:48:40 --> Model Class Initialized
DEBUG - 2011-07-20 17:48:40 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-20 17:48:40 --> Database Driver Class Initialized
DEBUG - 2011-07-20 17:48:41 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-20 17:48:41 --> Helper loaded: url_helper
DEBUG - 2011-07-20 17:48:41 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-20 17:48:41 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-20 17:48:41 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-20 17:48:41 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-20 17:48:41 --> Final output sent to browser
DEBUG - 2011-07-20 17:48:41 --> Total execution time: 0.0325
DEBUG - 2011-07-20 17:48:41 --> Final output sent to browser
DEBUG - 2011-07-20 17:48:41 --> Total execution time: 0.5751
DEBUG - 2011-07-20 17:48:46 --> Config Class Initialized
DEBUG - 2011-07-20 17:48:46 --> Hooks Class Initialized
DEBUG - 2011-07-20 17:48:46 --> Utf8 Class Initialized
DEBUG - 2011-07-20 17:48:46 --> UTF-8 Support Enabled
DEBUG - 2011-07-20 17:48:46 --> URI Class Initialized
DEBUG - 2011-07-20 17:48:46 --> Router Class Initialized
DEBUG - 2011-07-20 17:48:46 --> Output Class Initialized
DEBUG - 2011-07-20 17:48:46 --> Input Class Initialized
DEBUG - 2011-07-20 17:48:46 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-20 17:48:46 --> Language Class Initialized
DEBUG - 2011-07-20 17:48:46 --> Loader Class Initialized
DEBUG - 2011-07-20 17:48:46 --> Controller Class Initialized
ERROR - 2011-07-20 17:48:46 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-20 17:48:46 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-20 17:48:46 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-20 17:48:46 --> Model Class Initialized
DEBUG - 2011-07-20 17:48:46 --> Model Class Initialized
DEBUG - 2011-07-20 17:48:46 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-20 17:48:46 --> Database Driver Class Initialized
DEBUG - 2011-07-20 17:48:46 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-20 17:48:46 --> Helper loaded: url_helper
DEBUG - 2011-07-20 17:48:46 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-20 17:48:46 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-20 17:48:46 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-20 17:48:46 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-20 17:48:46 --> Final output sent to browser
DEBUG - 2011-07-20 17:48:46 --> Total execution time: 0.0347
DEBUG - 2011-07-20 17:48:46 --> Config Class Initialized
DEBUG - 2011-07-20 17:48:46 --> Hooks Class Initialized
DEBUG - 2011-07-20 17:48:46 --> Utf8 Class Initialized
DEBUG - 2011-07-20 17:48:46 --> UTF-8 Support Enabled
DEBUG - 2011-07-20 17:48:46 --> URI Class Initialized
DEBUG - 2011-07-20 17:48:46 --> Router Class Initialized
DEBUG - 2011-07-20 17:48:46 --> Output Class Initialized
DEBUG - 2011-07-20 17:48:46 --> Input Class Initialized
DEBUG - 2011-07-20 17:48:46 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-20 17:48:46 --> Language Class Initialized
DEBUG - 2011-07-20 17:48:46 --> Loader Class Initialized
DEBUG - 2011-07-20 17:48:46 --> Controller Class Initialized
DEBUG - 2011-07-20 17:48:46 --> Model Class Initialized
DEBUG - 2011-07-20 17:48:46 --> Model Class Initialized
DEBUG - 2011-07-20 17:48:46 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-20 17:48:46 --> Database Driver Class Initialized
DEBUG - 2011-07-20 17:48:47 --> Final output sent to browser
DEBUG - 2011-07-20 17:48:47 --> Total execution time: 0.5837
DEBUG - 2011-07-20 17:48:49 --> Config Class Initialized
DEBUG - 2011-07-20 17:48:49 --> Hooks Class Initialized
DEBUG - 2011-07-20 17:48:49 --> Utf8 Class Initialized
DEBUG - 2011-07-20 17:48:49 --> UTF-8 Support Enabled
DEBUG - 2011-07-20 17:48:49 --> URI Class Initialized
DEBUG - 2011-07-20 17:48:49 --> Router Class Initialized
DEBUG - 2011-07-20 17:48:49 --> Output Class Initialized
DEBUG - 2011-07-20 17:48:49 --> Input Class Initialized
DEBUG - 2011-07-20 17:48:49 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-20 17:48:49 --> Language Class Initialized
DEBUG - 2011-07-20 17:48:49 --> Loader Class Initialized
DEBUG - 2011-07-20 17:48:49 --> Controller Class Initialized
ERROR - 2011-07-20 17:48:49 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-20 17:48:49 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-20 17:48:49 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-20 17:48:49 --> Model Class Initialized
DEBUG - 2011-07-20 17:48:49 --> Model Class Initialized
DEBUG - 2011-07-20 17:48:49 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-20 17:48:49 --> Database Driver Class Initialized
DEBUG - 2011-07-20 17:48:49 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-20 17:48:49 --> Helper loaded: url_helper
DEBUG - 2011-07-20 17:48:49 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-20 17:48:49 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-20 17:48:49 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-20 17:48:49 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-20 17:48:49 --> Final output sent to browser
DEBUG - 2011-07-20 17:48:49 --> Total execution time: 0.0326
DEBUG - 2011-07-20 17:48:52 --> Config Class Initialized
DEBUG - 2011-07-20 17:48:52 --> Hooks Class Initialized
DEBUG - 2011-07-20 17:48:52 --> Utf8 Class Initialized
DEBUG - 2011-07-20 17:48:52 --> UTF-8 Support Enabled
DEBUG - 2011-07-20 17:48:52 --> URI Class Initialized
DEBUG - 2011-07-20 17:48:52 --> Router Class Initialized
DEBUG - 2011-07-20 17:48:52 --> Output Class Initialized
DEBUG - 2011-07-20 17:48:52 --> Input Class Initialized
DEBUG - 2011-07-20 17:48:52 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-20 17:48:52 --> Language Class Initialized
DEBUG - 2011-07-20 17:48:52 --> Loader Class Initialized
DEBUG - 2011-07-20 17:48:52 --> Controller Class Initialized
ERROR - 2011-07-20 17:48:52 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-20 17:48:52 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-20 17:48:52 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-20 17:48:52 --> Model Class Initialized
DEBUG - 2011-07-20 17:48:52 --> Model Class Initialized
DEBUG - 2011-07-20 17:48:52 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-20 17:48:52 --> Database Driver Class Initialized
DEBUG - 2011-07-20 17:48:52 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-20 17:48:52 --> Helper loaded: url_helper
DEBUG - 2011-07-20 17:48:52 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-20 17:48:52 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-20 17:48:52 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-20 17:48:52 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-20 17:48:52 --> Final output sent to browser
DEBUG - 2011-07-20 17:48:52 --> Total execution time: 0.0474
DEBUG - 2011-07-20 17:48:53 --> Config Class Initialized
DEBUG - 2011-07-20 17:48:53 --> Hooks Class Initialized
DEBUG - 2011-07-20 17:48:53 --> Utf8 Class Initialized
DEBUG - 2011-07-20 17:48:53 --> UTF-8 Support Enabled
DEBUG - 2011-07-20 17:48:53 --> URI Class Initialized
DEBUG - 2011-07-20 17:48:53 --> Router Class Initialized
DEBUG - 2011-07-20 17:48:53 --> Output Class Initialized
DEBUG - 2011-07-20 17:48:53 --> Input Class Initialized
DEBUG - 2011-07-20 17:48:53 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-20 17:48:53 --> Language Class Initialized
DEBUG - 2011-07-20 17:48:53 --> Loader Class Initialized
DEBUG - 2011-07-20 17:48:53 --> Controller Class Initialized
DEBUG - 2011-07-20 17:48:53 --> Model Class Initialized
DEBUG - 2011-07-20 17:48:53 --> Model Class Initialized
DEBUG - 2011-07-20 17:48:53 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-20 17:48:53 --> Database Driver Class Initialized
DEBUG - 2011-07-20 17:48:53 --> Config Class Initialized
DEBUG - 2011-07-20 17:48:53 --> Hooks Class Initialized
DEBUG - 2011-07-20 17:48:53 --> Utf8 Class Initialized
DEBUG - 2011-07-20 17:48:53 --> UTF-8 Support Enabled
DEBUG - 2011-07-20 17:48:53 --> URI Class Initialized
DEBUG - 2011-07-20 17:48:53 --> Router Class Initialized
DEBUG - 2011-07-20 17:48:53 --> Output Class Initialized
DEBUG - 2011-07-20 17:48:53 --> Input Class Initialized
DEBUG - 2011-07-20 17:48:53 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-20 17:48:53 --> Language Class Initialized
DEBUG - 2011-07-20 17:48:53 --> Loader Class Initialized
DEBUG - 2011-07-20 17:48:53 --> Controller Class Initialized
ERROR - 2011-07-20 17:48:53 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-20 17:48:53 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-20 17:48:53 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-20 17:48:53 --> Model Class Initialized
DEBUG - 2011-07-20 17:48:53 --> Model Class Initialized
DEBUG - 2011-07-20 17:48:53 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-20 17:48:53 --> Database Driver Class Initialized
DEBUG - 2011-07-20 17:48:53 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-20 17:48:53 --> Helper loaded: url_helper
DEBUG - 2011-07-20 17:48:53 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-20 17:48:53 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-20 17:48:53 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-20 17:48:53 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-20 17:48:53 --> Final output sent to browser
DEBUG - 2011-07-20 17:48:53 --> Total execution time: 0.1224
DEBUG - 2011-07-20 17:48:53 --> Final output sent to browser
DEBUG - 2011-07-20 17:48:53 --> Total execution time: 0.7560
DEBUG - 2011-07-20 20:44:11 --> Config Class Initialized
DEBUG - 2011-07-20 20:44:11 --> Hooks Class Initialized
DEBUG - 2011-07-20 20:44:11 --> Utf8 Class Initialized
DEBUG - 2011-07-20 20:44:11 --> UTF-8 Support Enabled
DEBUG - 2011-07-20 20:44:11 --> URI Class Initialized
DEBUG - 2011-07-20 20:44:11 --> Router Class Initialized
DEBUG - 2011-07-20 20:44:11 --> Output Class Initialized
DEBUG - 2011-07-20 20:44:11 --> Input Class Initialized
DEBUG - 2011-07-20 20:44:11 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-20 20:44:11 --> Language Class Initialized
DEBUG - 2011-07-20 20:44:11 --> Loader Class Initialized
DEBUG - 2011-07-20 20:44:11 --> Controller Class Initialized
ERROR - 2011-07-20 20:44:11 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-20 20:44:11 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-20 20:44:11 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-20 20:44:11 --> Model Class Initialized
DEBUG - 2011-07-20 20:44:11 --> Model Class Initialized
DEBUG - 2011-07-20 20:44:11 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-20 20:44:11 --> Database Driver Class Initialized
DEBUG - 2011-07-20 20:44:11 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-20 20:44:11 --> Helper loaded: url_helper
DEBUG - 2011-07-20 20:44:11 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-20 20:44:11 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-20 20:44:11 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-20 20:44:11 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-20 20:44:11 --> Final output sent to browser
DEBUG - 2011-07-20 20:44:11 --> Total execution time: 0.7334
DEBUG - 2011-07-20 23:31:58 --> Config Class Initialized
DEBUG - 2011-07-20 23:31:58 --> Hooks Class Initialized
DEBUG - 2011-07-20 23:31:58 --> Utf8 Class Initialized
DEBUG - 2011-07-20 23:31:58 --> UTF-8 Support Enabled
DEBUG - 2011-07-20 23:31:58 --> URI Class Initialized
DEBUG - 2011-07-20 23:31:58 --> Router Class Initialized
DEBUG - 2011-07-20 23:31:58 --> No URI present. Default controller set.
DEBUG - 2011-07-20 23:31:58 --> Output Class Initialized
DEBUG - 2011-07-20 23:31:58 --> Input Class Initialized
DEBUG - 2011-07-20 23:31:58 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-20 23:31:58 --> Language Class Initialized
DEBUG - 2011-07-20 23:31:58 --> Loader Class Initialized
DEBUG - 2011-07-20 23:31:58 --> Controller Class Initialized
DEBUG - 2011-07-20 23:31:58 --> File loaded: application/views/splash/main.php
DEBUG - 2011-07-20 23:31:59 --> Helper loaded: url_helper
DEBUG - 2011-07-20 23:31:59 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-20 23:31:59 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-20 23:31:59 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-20 23:31:59 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-20 23:31:59 --> Final output sent to browser
DEBUG - 2011-07-20 23:31:59 --> Total execution time: 0.2845

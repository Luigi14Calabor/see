<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2011-08-04 00:04:17 --> Config Class Initialized
DEBUG - 2011-08-04 00:04:17 --> Hooks Class Initialized
DEBUG - 2011-08-04 00:04:17 --> Utf8 Class Initialized
DEBUG - 2011-08-04 00:04:17 --> UTF-8 Support Enabled
DEBUG - 2011-08-04 00:04:17 --> URI Class Initialized
DEBUG - 2011-08-04 00:04:17 --> Router Class Initialized
ERROR - 2011-08-04 00:04:17 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-08-04 00:04:17 --> Config Class Initialized
DEBUG - 2011-08-04 00:04:17 --> Hooks Class Initialized
DEBUG - 2011-08-04 00:04:17 --> Utf8 Class Initialized
DEBUG - 2011-08-04 00:04:17 --> UTF-8 Support Enabled
DEBUG - 2011-08-04 00:04:17 --> URI Class Initialized
DEBUG - 2011-08-04 00:04:17 --> Router Class Initialized
DEBUG - 2011-08-04 00:04:17 --> Output Class Initialized
DEBUG - 2011-08-04 00:04:17 --> Input Class Initialized
DEBUG - 2011-08-04 00:04:17 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-04 00:04:17 --> Language Class Initialized
DEBUG - 2011-08-04 00:04:17 --> Loader Class Initialized
DEBUG - 2011-08-04 00:04:17 --> Controller Class Initialized
DEBUG - 2011-08-04 00:04:17 --> Model Class Initialized
DEBUG - 2011-08-04 00:04:17 --> Model Class Initialized
DEBUG - 2011-08-04 00:04:17 --> Model Class Initialized
DEBUG - 2011-08-04 00:04:17 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-04 00:04:17 --> Database Driver Class Initialized
DEBUG - 2011-08-04 00:04:17 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-04 00:04:17 --> Helper loaded: url_helper
DEBUG - 2011-08-04 00:04:17 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-04 00:04:17 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-04 00:04:17 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-04 00:04:17 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-04 00:04:17 --> Final output sent to browser
DEBUG - 2011-08-04 00:04:17 --> Total execution time: 0.5291
DEBUG - 2011-08-04 00:11:31 --> Config Class Initialized
DEBUG - 2011-08-04 00:11:31 --> Hooks Class Initialized
DEBUG - 2011-08-04 00:11:31 --> Utf8 Class Initialized
DEBUG - 2011-08-04 00:11:31 --> UTF-8 Support Enabled
DEBUG - 2011-08-04 00:11:31 --> URI Class Initialized
DEBUG - 2011-08-04 00:11:31 --> Router Class Initialized
DEBUG - 2011-08-04 00:11:31 --> Output Class Initialized
DEBUG - 2011-08-04 00:11:31 --> Input Class Initialized
DEBUG - 2011-08-04 00:11:31 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-04 00:11:31 --> Language Class Initialized
DEBUG - 2011-08-04 00:11:31 --> Loader Class Initialized
DEBUG - 2011-08-04 00:11:31 --> Controller Class Initialized
ERROR - 2011-08-04 00:11:31 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-04 00:11:31 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-04 00:11:31 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-04 00:11:31 --> Model Class Initialized
DEBUG - 2011-08-04 00:11:31 --> Model Class Initialized
DEBUG - 2011-08-04 00:11:31 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-04 00:11:31 --> Database Driver Class Initialized
DEBUG - 2011-08-04 00:11:31 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-04 00:11:31 --> Helper loaded: url_helper
DEBUG - 2011-08-04 00:11:31 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-04 00:11:31 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-04 00:11:31 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-04 00:11:31 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-04 00:11:31 --> Final output sent to browser
DEBUG - 2011-08-04 00:11:31 --> Total execution time: 0.0903
DEBUG - 2011-08-04 00:11:33 --> Config Class Initialized
DEBUG - 2011-08-04 00:11:33 --> Hooks Class Initialized
DEBUG - 2011-08-04 00:11:33 --> Utf8 Class Initialized
DEBUG - 2011-08-04 00:11:33 --> UTF-8 Support Enabled
DEBUG - 2011-08-04 00:11:33 --> URI Class Initialized
DEBUG - 2011-08-04 00:11:33 --> Router Class Initialized
DEBUG - 2011-08-04 00:11:33 --> Output Class Initialized
DEBUG - 2011-08-04 00:11:33 --> Input Class Initialized
DEBUG - 2011-08-04 00:11:33 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-04 00:11:33 --> Language Class Initialized
DEBUG - 2011-08-04 00:11:33 --> Loader Class Initialized
DEBUG - 2011-08-04 00:11:33 --> Controller Class Initialized
DEBUG - 2011-08-04 00:11:33 --> Model Class Initialized
DEBUG - 2011-08-04 00:11:33 --> Model Class Initialized
DEBUG - 2011-08-04 00:11:33 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-04 00:11:33 --> Database Driver Class Initialized
DEBUG - 2011-08-04 00:11:34 --> Final output sent to browser
DEBUG - 2011-08-04 00:11:34 --> Total execution time: 0.7495
DEBUG - 2011-08-04 00:11:46 --> Config Class Initialized
DEBUG - 2011-08-04 00:11:46 --> Hooks Class Initialized
DEBUG - 2011-08-04 00:11:46 --> Utf8 Class Initialized
DEBUG - 2011-08-04 00:11:46 --> UTF-8 Support Enabled
DEBUG - 2011-08-04 00:11:46 --> URI Class Initialized
DEBUG - 2011-08-04 00:11:46 --> Router Class Initialized
ERROR - 2011-08-04 00:11:46 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-04 00:11:50 --> Config Class Initialized
DEBUG - 2011-08-04 00:11:50 --> Hooks Class Initialized
DEBUG - 2011-08-04 00:11:50 --> Utf8 Class Initialized
DEBUG - 2011-08-04 00:11:50 --> UTF-8 Support Enabled
DEBUG - 2011-08-04 00:11:50 --> URI Class Initialized
DEBUG - 2011-08-04 00:11:50 --> Router Class Initialized
DEBUG - 2011-08-04 00:11:50 --> Output Class Initialized
DEBUG - 2011-08-04 00:11:50 --> Input Class Initialized
DEBUG - 2011-08-04 00:11:50 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-04 00:11:50 --> Language Class Initialized
DEBUG - 2011-08-04 00:11:50 --> Loader Class Initialized
DEBUG - 2011-08-04 00:11:50 --> Controller Class Initialized
ERROR - 2011-08-04 00:11:50 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-04 00:11:50 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-04 00:11:50 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-04 00:11:50 --> Model Class Initialized
DEBUG - 2011-08-04 00:11:50 --> Model Class Initialized
DEBUG - 2011-08-04 00:11:50 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-04 00:11:50 --> Database Driver Class Initialized
DEBUG - 2011-08-04 00:11:50 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-04 00:11:50 --> Helper loaded: url_helper
DEBUG - 2011-08-04 00:11:50 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-04 00:11:50 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-04 00:11:50 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-04 00:11:50 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-04 00:11:50 --> Final output sent to browser
DEBUG - 2011-08-04 00:11:50 --> Total execution time: 0.0296
DEBUG - 2011-08-04 00:13:13 --> Config Class Initialized
DEBUG - 2011-08-04 00:13:13 --> Hooks Class Initialized
DEBUG - 2011-08-04 00:13:13 --> Utf8 Class Initialized
DEBUG - 2011-08-04 00:13:13 --> UTF-8 Support Enabled
DEBUG - 2011-08-04 00:13:13 --> URI Class Initialized
DEBUG - 2011-08-04 00:13:13 --> Router Class Initialized
DEBUG - 2011-08-04 00:13:13 --> Output Class Initialized
DEBUG - 2011-08-04 00:13:13 --> Input Class Initialized
DEBUG - 2011-08-04 00:13:13 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-04 00:13:13 --> Language Class Initialized
DEBUG - 2011-08-04 00:13:13 --> Loader Class Initialized
DEBUG - 2011-08-04 00:13:13 --> Controller Class Initialized
ERROR - 2011-08-04 00:13:13 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-04 00:13:13 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-04 00:13:13 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-04 00:13:13 --> Model Class Initialized
DEBUG - 2011-08-04 00:13:13 --> Model Class Initialized
DEBUG - 2011-08-04 00:13:13 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-04 00:13:13 --> Database Driver Class Initialized
DEBUG - 2011-08-04 00:13:13 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-04 00:13:13 --> Helper loaded: url_helper
DEBUG - 2011-08-04 00:13:13 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-04 00:13:13 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-04 00:13:13 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-04 00:13:13 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-04 00:13:13 --> Final output sent to browser
DEBUG - 2011-08-04 00:13:13 --> Total execution time: 0.0285
DEBUG - 2011-08-04 00:13:16 --> Config Class Initialized
DEBUG - 2011-08-04 00:13:16 --> Hooks Class Initialized
DEBUG - 2011-08-04 00:13:16 --> Utf8 Class Initialized
DEBUG - 2011-08-04 00:13:16 --> UTF-8 Support Enabled
DEBUG - 2011-08-04 00:13:16 --> URI Class Initialized
DEBUG - 2011-08-04 00:13:16 --> Router Class Initialized
DEBUG - 2011-08-04 00:13:16 --> Output Class Initialized
DEBUG - 2011-08-04 00:13:16 --> Input Class Initialized
DEBUG - 2011-08-04 00:13:16 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-04 00:13:16 --> Language Class Initialized
DEBUG - 2011-08-04 00:13:16 --> Loader Class Initialized
DEBUG - 2011-08-04 00:13:16 --> Controller Class Initialized
ERROR - 2011-08-04 00:13:16 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-04 00:13:16 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-04 00:13:16 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-04 00:13:16 --> Model Class Initialized
DEBUG - 2011-08-04 00:13:16 --> Model Class Initialized
DEBUG - 2011-08-04 00:13:16 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-04 00:13:16 --> Database Driver Class Initialized
DEBUG - 2011-08-04 00:13:16 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-04 00:13:16 --> Helper loaded: url_helper
DEBUG - 2011-08-04 00:13:16 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-04 00:13:16 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-04 00:13:16 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-04 00:13:16 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-04 00:13:16 --> Final output sent to browser
DEBUG - 2011-08-04 00:13:16 --> Total execution time: 0.0284
DEBUG - 2011-08-04 00:13:18 --> Config Class Initialized
DEBUG - 2011-08-04 00:13:18 --> Hooks Class Initialized
DEBUG - 2011-08-04 00:13:18 --> Utf8 Class Initialized
DEBUG - 2011-08-04 00:13:18 --> UTF-8 Support Enabled
DEBUG - 2011-08-04 00:13:18 --> URI Class Initialized
DEBUG - 2011-08-04 00:13:18 --> Router Class Initialized
DEBUG - 2011-08-04 00:13:18 --> Output Class Initialized
DEBUG - 2011-08-04 00:13:18 --> Input Class Initialized
DEBUG - 2011-08-04 00:13:18 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-04 00:13:18 --> Language Class Initialized
DEBUG - 2011-08-04 00:13:18 --> Loader Class Initialized
DEBUG - 2011-08-04 00:13:18 --> Controller Class Initialized
DEBUG - 2011-08-04 00:13:18 --> Model Class Initialized
DEBUG - 2011-08-04 00:13:18 --> Model Class Initialized
DEBUG - 2011-08-04 00:13:18 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-04 00:13:18 --> Database Driver Class Initialized
DEBUG - 2011-08-04 00:13:19 --> Final output sent to browser
DEBUG - 2011-08-04 00:13:19 --> Total execution time: 0.5739
DEBUG - 2011-08-04 00:13:26 --> Config Class Initialized
DEBUG - 2011-08-04 00:13:26 --> Hooks Class Initialized
DEBUG - 2011-08-04 00:13:26 --> Utf8 Class Initialized
DEBUG - 2011-08-04 00:13:26 --> UTF-8 Support Enabled
DEBUG - 2011-08-04 00:13:26 --> URI Class Initialized
DEBUG - 2011-08-04 00:13:26 --> Router Class Initialized
ERROR - 2011-08-04 00:13:26 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-04 00:13:42 --> Config Class Initialized
DEBUG - 2011-08-04 00:13:42 --> Hooks Class Initialized
DEBUG - 2011-08-04 00:13:42 --> Utf8 Class Initialized
DEBUG - 2011-08-04 00:13:42 --> UTF-8 Support Enabled
DEBUG - 2011-08-04 00:13:42 --> URI Class Initialized
DEBUG - 2011-08-04 00:13:42 --> Router Class Initialized
DEBUG - 2011-08-04 00:13:42 --> Output Class Initialized
DEBUG - 2011-08-04 00:13:42 --> Input Class Initialized
DEBUG - 2011-08-04 00:13:42 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-04 00:13:42 --> Language Class Initialized
DEBUG - 2011-08-04 00:13:42 --> Loader Class Initialized
DEBUG - 2011-08-04 00:13:42 --> Controller Class Initialized
ERROR - 2011-08-04 00:13:42 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-04 00:13:42 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-04 00:13:42 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-04 00:13:42 --> Model Class Initialized
DEBUG - 2011-08-04 00:13:42 --> Model Class Initialized
DEBUG - 2011-08-04 00:13:42 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-04 00:13:42 --> Database Driver Class Initialized
DEBUG - 2011-08-04 00:13:42 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-04 00:13:42 --> Helper loaded: url_helper
DEBUG - 2011-08-04 00:13:42 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-04 00:13:42 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-04 00:13:42 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-04 00:13:42 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-04 00:13:42 --> Final output sent to browser
DEBUG - 2011-08-04 00:13:42 --> Total execution time: 0.0272
DEBUG - 2011-08-04 01:53:42 --> Config Class Initialized
DEBUG - 2011-08-04 01:53:42 --> Hooks Class Initialized
DEBUG - 2011-08-04 01:53:42 --> Utf8 Class Initialized
DEBUG - 2011-08-04 01:53:42 --> UTF-8 Support Enabled
DEBUG - 2011-08-04 01:53:42 --> URI Class Initialized
DEBUG - 2011-08-04 01:53:42 --> Router Class Initialized
DEBUG - 2011-08-04 01:53:42 --> Output Class Initialized
DEBUG - 2011-08-04 01:53:42 --> Input Class Initialized
DEBUG - 2011-08-04 01:53:42 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-04 01:53:42 --> Language Class Initialized
DEBUG - 2011-08-04 01:53:42 --> Loader Class Initialized
DEBUG - 2011-08-04 01:53:42 --> Controller Class Initialized
ERROR - 2011-08-04 01:53:42 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-04 01:53:42 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-04 01:53:42 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-04 01:53:42 --> Model Class Initialized
DEBUG - 2011-08-04 01:53:42 --> Model Class Initialized
DEBUG - 2011-08-04 01:53:42 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-04 01:53:42 --> Database Driver Class Initialized
DEBUG - 2011-08-04 01:53:42 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-04 01:53:43 --> Helper loaded: url_helper
DEBUG - 2011-08-04 01:53:43 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-04 01:53:43 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-04 01:53:43 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-04 01:53:43 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-04 01:53:43 --> Final output sent to browser
DEBUG - 2011-08-04 01:53:43 --> Total execution time: 0.9024
DEBUG - 2011-08-04 01:53:44 --> Config Class Initialized
DEBUG - 2011-08-04 01:53:44 --> Hooks Class Initialized
DEBUG - 2011-08-04 01:53:44 --> Utf8 Class Initialized
DEBUG - 2011-08-04 01:53:44 --> UTF-8 Support Enabled
DEBUG - 2011-08-04 01:53:44 --> URI Class Initialized
DEBUG - 2011-08-04 01:53:44 --> Router Class Initialized
DEBUG - 2011-08-04 01:53:44 --> Output Class Initialized
DEBUG - 2011-08-04 01:53:44 --> Input Class Initialized
DEBUG - 2011-08-04 01:53:44 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-04 01:53:44 --> Language Class Initialized
DEBUG - 2011-08-04 01:53:44 --> Loader Class Initialized
DEBUG - 2011-08-04 01:53:44 --> Controller Class Initialized
DEBUG - 2011-08-04 01:53:44 --> Model Class Initialized
DEBUG - 2011-08-04 01:53:44 --> Model Class Initialized
DEBUG - 2011-08-04 01:53:44 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-04 01:53:44 --> Database Driver Class Initialized
DEBUG - 2011-08-04 01:53:45 --> Final output sent to browser
DEBUG - 2011-08-04 01:53:45 --> Total execution time: 1.1717
DEBUG - 2011-08-04 02:13:23 --> Config Class Initialized
DEBUG - 2011-08-04 02:13:23 --> Hooks Class Initialized
DEBUG - 2011-08-04 02:13:24 --> Utf8 Class Initialized
DEBUG - 2011-08-04 02:13:24 --> UTF-8 Support Enabled
DEBUG - 2011-08-04 02:13:24 --> URI Class Initialized
DEBUG - 2011-08-04 02:13:24 --> Router Class Initialized
ERROR - 2011-08-04 02:13:24 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-08-04 03:05:00 --> Config Class Initialized
DEBUG - 2011-08-04 03:05:00 --> Hooks Class Initialized
DEBUG - 2011-08-04 03:05:00 --> Utf8 Class Initialized
DEBUG - 2011-08-04 03:05:00 --> UTF-8 Support Enabled
DEBUG - 2011-08-04 03:05:00 --> URI Class Initialized
DEBUG - 2011-08-04 03:05:00 --> Router Class Initialized
DEBUG - 2011-08-04 03:05:00 --> Output Class Initialized
DEBUG - 2011-08-04 03:05:00 --> Input Class Initialized
DEBUG - 2011-08-04 03:05:00 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-04 03:05:00 --> Language Class Initialized
DEBUG - 2011-08-04 03:05:00 --> Loader Class Initialized
DEBUG - 2011-08-04 03:05:00 --> Controller Class Initialized
DEBUG - 2011-08-04 03:05:00 --> Model Class Initialized
DEBUG - 2011-08-04 03:05:00 --> Model Class Initialized
DEBUG - 2011-08-04 03:05:00 --> Model Class Initialized
DEBUG - 2011-08-04 03:05:00 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-04 03:05:00 --> Database Driver Class Initialized
DEBUG - 2011-08-04 03:05:05 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-04 03:05:05 --> Helper loaded: url_helper
DEBUG - 2011-08-04 03:05:05 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-04 03:05:05 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-04 03:05:05 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-04 03:05:05 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-04 03:05:05 --> Final output sent to browser
DEBUG - 2011-08-04 03:05:05 --> Total execution time: 4.9980
DEBUG - 2011-08-04 04:23:48 --> Config Class Initialized
DEBUG - 2011-08-04 04:23:48 --> Hooks Class Initialized
DEBUG - 2011-08-04 04:23:48 --> Utf8 Class Initialized
DEBUG - 2011-08-04 04:23:48 --> UTF-8 Support Enabled
DEBUG - 2011-08-04 04:23:48 --> URI Class Initialized
DEBUG - 2011-08-04 04:23:48 --> Router Class Initialized
DEBUG - 2011-08-04 04:23:48 --> No URI present. Default controller set.
DEBUG - 2011-08-04 04:23:48 --> Output Class Initialized
DEBUG - 2011-08-04 04:23:48 --> Input Class Initialized
DEBUG - 2011-08-04 04:23:48 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-04 04:23:48 --> Language Class Initialized
DEBUG - 2011-08-04 04:23:48 --> Loader Class Initialized
DEBUG - 2011-08-04 04:23:48 --> Controller Class Initialized
DEBUG - 2011-08-04 04:23:48 --> File loaded: application/views/splash/main.php
DEBUG - 2011-08-04 04:23:48 --> Helper loaded: url_helper
DEBUG - 2011-08-04 04:23:48 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-04 04:23:48 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-04 04:23:48 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-04 04:23:48 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-04 04:23:48 --> Final output sent to browser
DEBUG - 2011-08-04 04:23:48 --> Total execution time: 0.1995
DEBUG - 2011-08-04 04:23:52 --> Config Class Initialized
DEBUG - 2011-08-04 04:23:52 --> Hooks Class Initialized
DEBUG - 2011-08-04 04:23:52 --> Utf8 Class Initialized
DEBUG - 2011-08-04 04:23:52 --> UTF-8 Support Enabled
DEBUG - 2011-08-04 04:23:52 --> URI Class Initialized
DEBUG - 2011-08-04 04:23:52 --> Router Class Initialized
DEBUG - 2011-08-04 04:23:52 --> No URI present. Default controller set.
DEBUG - 2011-08-04 04:23:52 --> Output Class Initialized
DEBUG - 2011-08-04 04:23:52 --> Input Class Initialized
DEBUG - 2011-08-04 04:23:52 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-04 04:23:52 --> Language Class Initialized
DEBUG - 2011-08-04 04:23:52 --> Loader Class Initialized
DEBUG - 2011-08-04 04:23:52 --> Controller Class Initialized
DEBUG - 2011-08-04 04:23:52 --> File loaded: application/views/splash/main.php
DEBUG - 2011-08-04 04:23:52 --> Helper loaded: url_helper
DEBUG - 2011-08-04 04:23:52 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-04 04:23:52 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-04 04:23:52 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-04 04:23:52 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-04 04:23:52 --> Final output sent to browser
DEBUG - 2011-08-04 04:23:52 --> Total execution time: 0.0231
DEBUG - 2011-08-04 04:23:55 --> Config Class Initialized
DEBUG - 2011-08-04 04:23:55 --> Hooks Class Initialized
DEBUG - 2011-08-04 04:23:55 --> Utf8 Class Initialized
DEBUG - 2011-08-04 04:23:55 --> UTF-8 Support Enabled
DEBUG - 2011-08-04 04:23:55 --> URI Class Initialized
DEBUG - 2011-08-04 04:23:55 --> Router Class Initialized
DEBUG - 2011-08-04 04:23:55 --> Output Class Initialized
DEBUG - 2011-08-04 04:23:55 --> Input Class Initialized
DEBUG - 2011-08-04 04:23:55 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-04 04:23:55 --> Language Class Initialized
DEBUG - 2011-08-04 04:23:55 --> Loader Class Initialized
DEBUG - 2011-08-04 04:23:55 --> Controller Class Initialized
DEBUG - 2011-08-04 04:23:55 --> Model Class Initialized
DEBUG - 2011-08-04 04:23:55 --> Model Class Initialized
DEBUG - 2011-08-04 04:23:55 --> Model Class Initialized
DEBUG - 2011-08-04 04:23:55 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-04 04:23:55 --> Database Driver Class Initialized
DEBUG - 2011-08-04 04:23:55 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-04 04:23:55 --> Helper loaded: url_helper
DEBUG - 2011-08-04 04:23:55 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-04 04:23:55 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-04 04:23:55 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-04 04:23:55 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-04 04:23:55 --> Final output sent to browser
DEBUG - 2011-08-04 04:23:55 --> Total execution time: 0.9416
DEBUG - 2011-08-04 04:24:10 --> Config Class Initialized
DEBUG - 2011-08-04 04:24:10 --> Hooks Class Initialized
DEBUG - 2011-08-04 04:24:10 --> Utf8 Class Initialized
DEBUG - 2011-08-04 04:24:10 --> UTF-8 Support Enabled
DEBUG - 2011-08-04 04:24:10 --> URI Class Initialized
DEBUG - 2011-08-04 04:24:10 --> Router Class Initialized
DEBUG - 2011-08-04 04:24:10 --> Output Class Initialized
DEBUG - 2011-08-04 04:24:10 --> Input Class Initialized
DEBUG - 2011-08-04 04:24:10 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-04 04:24:10 --> Language Class Initialized
DEBUG - 2011-08-04 04:24:10 --> Loader Class Initialized
DEBUG - 2011-08-04 04:24:10 --> Controller Class Initialized
DEBUG - 2011-08-04 04:24:10 --> Model Class Initialized
DEBUG - 2011-08-04 04:24:10 --> Model Class Initialized
DEBUG - 2011-08-04 04:24:10 --> Model Class Initialized
DEBUG - 2011-08-04 04:24:10 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-04 04:24:10 --> Database Driver Class Initialized
DEBUG - 2011-08-04 04:24:11 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-04 04:24:11 --> Helper loaded: url_helper
DEBUG - 2011-08-04 04:24:11 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-04 04:24:11 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-04 04:24:11 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-04 04:24:11 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-04 04:24:11 --> Final output sent to browser
DEBUG - 2011-08-04 04:24:11 --> Total execution time: 0.2169
DEBUG - 2011-08-04 04:24:12 --> Config Class Initialized
DEBUG - 2011-08-04 04:24:12 --> Hooks Class Initialized
DEBUG - 2011-08-04 04:24:12 --> Utf8 Class Initialized
DEBUG - 2011-08-04 04:24:12 --> UTF-8 Support Enabled
DEBUG - 2011-08-04 04:24:12 --> URI Class Initialized
DEBUG - 2011-08-04 04:24:12 --> Router Class Initialized
DEBUG - 2011-08-04 04:24:12 --> Output Class Initialized
DEBUG - 2011-08-04 04:24:12 --> Input Class Initialized
DEBUG - 2011-08-04 04:24:12 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-04 04:24:12 --> Language Class Initialized
DEBUG - 2011-08-04 04:24:12 --> Loader Class Initialized
DEBUG - 2011-08-04 04:24:12 --> Controller Class Initialized
DEBUG - 2011-08-04 04:24:12 --> Model Class Initialized
DEBUG - 2011-08-04 04:24:12 --> Model Class Initialized
DEBUG - 2011-08-04 04:24:12 --> Model Class Initialized
DEBUG - 2011-08-04 04:24:12 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-04 04:24:12 --> Database Driver Class Initialized
DEBUG - 2011-08-04 04:24:12 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-04 04:24:12 --> Helper loaded: url_helper
DEBUG - 2011-08-04 04:24:12 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-04 04:24:12 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-04 04:24:12 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-04 04:24:12 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-04 04:24:12 --> Final output sent to browser
DEBUG - 2011-08-04 04:24:12 --> Total execution time: 0.0434
DEBUG - 2011-08-04 04:25:18 --> Config Class Initialized
DEBUG - 2011-08-04 04:25:18 --> Hooks Class Initialized
DEBUG - 2011-08-04 04:25:18 --> Utf8 Class Initialized
DEBUG - 2011-08-04 04:25:18 --> UTF-8 Support Enabled
DEBUG - 2011-08-04 04:25:18 --> URI Class Initialized
DEBUG - 2011-08-04 04:25:18 --> Router Class Initialized
DEBUG - 2011-08-04 04:25:18 --> Output Class Initialized
DEBUG - 2011-08-04 04:25:18 --> Input Class Initialized
DEBUG - 2011-08-04 04:25:18 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-04 04:25:18 --> Language Class Initialized
DEBUG - 2011-08-04 04:25:18 --> Loader Class Initialized
DEBUG - 2011-08-04 04:25:18 --> Controller Class Initialized
DEBUG - 2011-08-04 04:25:18 --> Model Class Initialized
DEBUG - 2011-08-04 04:25:18 --> Model Class Initialized
DEBUG - 2011-08-04 04:25:18 --> Model Class Initialized
DEBUG - 2011-08-04 04:25:18 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-04 04:25:18 --> Database Driver Class Initialized
DEBUG - 2011-08-04 04:25:18 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-04 04:25:18 --> Helper loaded: url_helper
DEBUG - 2011-08-04 04:25:18 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-04 04:25:18 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-04 04:25:18 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-04 04:25:18 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-04 04:25:18 --> Final output sent to browser
DEBUG - 2011-08-04 04:25:18 --> Total execution time: 0.0457
DEBUG - 2011-08-04 04:25:35 --> Config Class Initialized
DEBUG - 2011-08-04 04:25:35 --> Hooks Class Initialized
DEBUG - 2011-08-04 04:25:35 --> Utf8 Class Initialized
DEBUG - 2011-08-04 04:25:35 --> UTF-8 Support Enabled
DEBUG - 2011-08-04 04:25:35 --> URI Class Initialized
DEBUG - 2011-08-04 04:25:35 --> Router Class Initialized
DEBUG - 2011-08-04 04:25:35 --> Output Class Initialized
DEBUG - 2011-08-04 04:25:35 --> Input Class Initialized
DEBUG - 2011-08-04 04:25:35 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-04 04:25:35 --> Language Class Initialized
DEBUG - 2011-08-04 04:25:35 --> Loader Class Initialized
DEBUG - 2011-08-04 04:25:35 --> Controller Class Initialized
DEBUG - 2011-08-04 04:25:35 --> Model Class Initialized
DEBUG - 2011-08-04 04:25:35 --> Model Class Initialized
DEBUG - 2011-08-04 04:25:35 --> Model Class Initialized
DEBUG - 2011-08-04 04:25:35 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-04 04:25:35 --> Database Driver Class Initialized
DEBUG - 2011-08-04 04:25:35 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-04 04:25:35 --> Helper loaded: url_helper
DEBUG - 2011-08-04 04:25:35 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-04 04:25:35 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-04 04:25:35 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-04 04:25:35 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-04 04:25:35 --> Final output sent to browser
DEBUG - 2011-08-04 04:25:35 --> Total execution time: 0.4605
DEBUG - 2011-08-04 04:25:37 --> Config Class Initialized
DEBUG - 2011-08-04 04:25:37 --> Hooks Class Initialized
DEBUG - 2011-08-04 04:25:37 --> Utf8 Class Initialized
DEBUG - 2011-08-04 04:25:37 --> UTF-8 Support Enabled
DEBUG - 2011-08-04 04:25:37 --> URI Class Initialized
DEBUG - 2011-08-04 04:25:37 --> Router Class Initialized
DEBUG - 2011-08-04 04:25:37 --> Output Class Initialized
DEBUG - 2011-08-04 04:25:37 --> Input Class Initialized
DEBUG - 2011-08-04 04:25:37 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-04 04:25:37 --> Language Class Initialized
DEBUG - 2011-08-04 04:25:37 --> Loader Class Initialized
DEBUG - 2011-08-04 04:25:37 --> Controller Class Initialized
DEBUG - 2011-08-04 04:25:37 --> Model Class Initialized
DEBUG - 2011-08-04 04:25:37 --> Model Class Initialized
DEBUG - 2011-08-04 04:25:37 --> Model Class Initialized
DEBUG - 2011-08-04 04:25:37 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-04 04:25:37 --> Database Driver Class Initialized
DEBUG - 2011-08-04 04:25:37 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-04 04:25:37 --> Helper loaded: url_helper
DEBUG - 2011-08-04 04:25:37 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-04 04:25:37 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-04 04:25:37 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-04 04:25:37 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-04 04:25:37 --> Final output sent to browser
DEBUG - 2011-08-04 04:25:37 --> Total execution time: 0.0458
DEBUG - 2011-08-04 04:26:20 --> Config Class Initialized
DEBUG - 2011-08-04 04:26:20 --> Hooks Class Initialized
DEBUG - 2011-08-04 04:26:20 --> Utf8 Class Initialized
DEBUG - 2011-08-04 04:26:20 --> UTF-8 Support Enabled
DEBUG - 2011-08-04 04:26:20 --> URI Class Initialized
DEBUG - 2011-08-04 04:26:20 --> Router Class Initialized
DEBUG - 2011-08-04 04:26:20 --> Output Class Initialized
DEBUG - 2011-08-04 04:26:20 --> Input Class Initialized
DEBUG - 2011-08-04 04:26:20 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-04 04:26:20 --> Language Class Initialized
DEBUG - 2011-08-04 04:26:20 --> Loader Class Initialized
DEBUG - 2011-08-04 04:26:20 --> Controller Class Initialized
DEBUG - 2011-08-04 04:26:20 --> Model Class Initialized
DEBUG - 2011-08-04 04:26:20 --> Model Class Initialized
DEBUG - 2011-08-04 04:26:20 --> Model Class Initialized
DEBUG - 2011-08-04 04:26:20 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-04 04:26:20 --> Database Driver Class Initialized
DEBUG - 2011-08-04 04:26:20 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-04 04:26:20 --> Helper loaded: url_helper
DEBUG - 2011-08-04 04:26:20 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-04 04:26:20 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-04 04:26:20 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-04 04:26:20 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-04 04:26:20 --> Final output sent to browser
DEBUG - 2011-08-04 04:26:20 --> Total execution time: 0.2055
DEBUG - 2011-08-04 04:26:22 --> Config Class Initialized
DEBUG - 2011-08-04 04:26:22 --> Hooks Class Initialized
DEBUG - 2011-08-04 04:26:22 --> Utf8 Class Initialized
DEBUG - 2011-08-04 04:26:22 --> UTF-8 Support Enabled
DEBUG - 2011-08-04 04:26:22 --> URI Class Initialized
DEBUG - 2011-08-04 04:26:22 --> Router Class Initialized
DEBUG - 2011-08-04 04:26:22 --> Output Class Initialized
DEBUG - 2011-08-04 04:26:22 --> Input Class Initialized
DEBUG - 2011-08-04 04:26:22 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-04 04:26:22 --> Language Class Initialized
DEBUG - 2011-08-04 04:26:22 --> Loader Class Initialized
DEBUG - 2011-08-04 04:26:22 --> Controller Class Initialized
DEBUG - 2011-08-04 04:26:22 --> Model Class Initialized
DEBUG - 2011-08-04 04:26:22 --> Model Class Initialized
DEBUG - 2011-08-04 04:26:22 --> Model Class Initialized
DEBUG - 2011-08-04 04:26:22 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-04 04:26:22 --> Database Driver Class Initialized
DEBUG - 2011-08-04 04:26:22 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-04 04:26:22 --> Helper loaded: url_helper
DEBUG - 2011-08-04 04:26:22 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-04 04:26:22 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-04 04:26:22 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-04 04:26:22 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-04 04:26:22 --> Final output sent to browser
DEBUG - 2011-08-04 04:26:22 --> Total execution time: 0.0496
DEBUG - 2011-08-04 04:27:03 --> Config Class Initialized
DEBUG - 2011-08-04 04:27:03 --> Hooks Class Initialized
DEBUG - 2011-08-04 04:27:03 --> Utf8 Class Initialized
DEBUG - 2011-08-04 04:27:03 --> UTF-8 Support Enabled
DEBUG - 2011-08-04 04:27:03 --> URI Class Initialized
DEBUG - 2011-08-04 04:27:03 --> Router Class Initialized
DEBUG - 2011-08-04 04:27:03 --> Output Class Initialized
DEBUG - 2011-08-04 04:27:03 --> Input Class Initialized
DEBUG - 2011-08-04 04:27:03 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-04 04:27:03 --> Language Class Initialized
DEBUG - 2011-08-04 04:27:03 --> Loader Class Initialized
DEBUG - 2011-08-04 04:27:03 --> Controller Class Initialized
DEBUG - 2011-08-04 04:27:03 --> Model Class Initialized
DEBUG - 2011-08-04 04:27:03 --> Model Class Initialized
DEBUG - 2011-08-04 04:27:03 --> Model Class Initialized
DEBUG - 2011-08-04 04:27:03 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-04 04:27:03 --> Database Driver Class Initialized
DEBUG - 2011-08-04 04:27:03 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-04 04:27:03 --> Helper loaded: url_helper
DEBUG - 2011-08-04 04:27:03 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-04 04:27:03 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-04 04:27:03 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-04 04:27:03 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-04 04:27:03 --> Final output sent to browser
DEBUG - 2011-08-04 04:27:03 --> Total execution time: 0.0476
DEBUG - 2011-08-04 04:27:05 --> Config Class Initialized
DEBUG - 2011-08-04 04:27:05 --> Hooks Class Initialized
DEBUG - 2011-08-04 04:27:05 --> Utf8 Class Initialized
DEBUG - 2011-08-04 04:27:05 --> UTF-8 Support Enabled
DEBUG - 2011-08-04 04:27:05 --> URI Class Initialized
DEBUG - 2011-08-04 04:27:05 --> Router Class Initialized
ERROR - 2011-08-04 04:27:05 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-04 04:27:22 --> Config Class Initialized
DEBUG - 2011-08-04 04:27:22 --> Hooks Class Initialized
DEBUG - 2011-08-04 04:27:22 --> Utf8 Class Initialized
DEBUG - 2011-08-04 04:27:22 --> UTF-8 Support Enabled
DEBUG - 2011-08-04 04:27:22 --> URI Class Initialized
DEBUG - 2011-08-04 04:27:22 --> Router Class Initialized
DEBUG - 2011-08-04 04:27:22 --> Output Class Initialized
DEBUG - 2011-08-04 04:27:22 --> Input Class Initialized
DEBUG - 2011-08-04 04:27:22 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-04 04:27:22 --> Language Class Initialized
DEBUG - 2011-08-04 04:27:22 --> Loader Class Initialized
DEBUG - 2011-08-04 04:27:22 --> Controller Class Initialized
DEBUG - 2011-08-04 04:27:22 --> Model Class Initialized
DEBUG - 2011-08-04 04:27:22 --> Model Class Initialized
DEBUG - 2011-08-04 04:27:22 --> Model Class Initialized
DEBUG - 2011-08-04 04:27:22 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-04 04:27:22 --> Database Driver Class Initialized
DEBUG - 2011-08-04 04:27:22 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-04 04:27:22 --> Helper loaded: url_helper
DEBUG - 2011-08-04 04:27:22 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-04 04:27:22 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-04 04:27:22 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-04 04:27:22 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-04 04:27:22 --> Final output sent to browser
DEBUG - 2011-08-04 04:27:22 --> Total execution time: 0.0509
DEBUG - 2011-08-04 04:27:22 --> Config Class Initialized
DEBUG - 2011-08-04 04:27:22 --> Hooks Class Initialized
DEBUG - 2011-08-04 04:27:22 --> Utf8 Class Initialized
DEBUG - 2011-08-04 04:27:22 --> UTF-8 Support Enabled
DEBUG - 2011-08-04 04:27:22 --> URI Class Initialized
DEBUG - 2011-08-04 04:27:22 --> Router Class Initialized
DEBUG - 2011-08-04 04:27:22 --> Output Class Initialized
DEBUG - 2011-08-04 04:27:22 --> Input Class Initialized
DEBUG - 2011-08-04 04:27:22 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-04 04:27:22 --> Language Class Initialized
DEBUG - 2011-08-04 04:27:22 --> Loader Class Initialized
DEBUG - 2011-08-04 04:27:22 --> Controller Class Initialized
DEBUG - 2011-08-04 04:27:22 --> Model Class Initialized
DEBUG - 2011-08-04 04:27:22 --> Model Class Initialized
DEBUG - 2011-08-04 04:27:22 --> Model Class Initialized
DEBUG - 2011-08-04 04:27:22 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-04 04:27:22 --> Database Driver Class Initialized
DEBUG - 2011-08-04 04:27:23 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-04 04:27:23 --> Helper loaded: url_helper
DEBUG - 2011-08-04 04:27:23 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-04 04:27:23 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-04 04:27:23 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-04 04:27:23 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-04 04:27:23 --> Final output sent to browser
DEBUG - 2011-08-04 04:27:23 --> Total execution time: 0.2215
DEBUG - 2011-08-04 04:27:52 --> Config Class Initialized
DEBUG - 2011-08-04 04:27:52 --> Hooks Class Initialized
DEBUG - 2011-08-04 04:27:52 --> Utf8 Class Initialized
DEBUG - 2011-08-04 04:27:52 --> UTF-8 Support Enabled
DEBUG - 2011-08-04 04:27:52 --> URI Class Initialized
DEBUG - 2011-08-04 04:27:52 --> Router Class Initialized
DEBUG - 2011-08-04 04:27:52 --> Output Class Initialized
DEBUG - 2011-08-04 04:27:52 --> Input Class Initialized
DEBUG - 2011-08-04 04:27:52 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-04 04:27:52 --> Language Class Initialized
DEBUG - 2011-08-04 04:27:52 --> Loader Class Initialized
DEBUG - 2011-08-04 04:27:52 --> Controller Class Initialized
DEBUG - 2011-08-04 04:27:52 --> Model Class Initialized
DEBUG - 2011-08-04 04:27:52 --> Model Class Initialized
DEBUG - 2011-08-04 04:27:52 --> Model Class Initialized
DEBUG - 2011-08-04 04:27:52 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-04 04:27:52 --> Database Driver Class Initialized
DEBUG - 2011-08-04 04:27:52 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-04 04:27:52 --> Helper loaded: url_helper
DEBUG - 2011-08-04 04:27:52 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-04 04:27:52 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-04 04:27:52 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-04 04:27:52 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-04 04:27:52 --> Final output sent to browser
DEBUG - 2011-08-04 04:27:52 --> Total execution time: 0.0454
DEBUG - 2011-08-04 04:28:03 --> Config Class Initialized
DEBUG - 2011-08-04 04:28:03 --> Hooks Class Initialized
DEBUG - 2011-08-04 04:28:03 --> Utf8 Class Initialized
DEBUG - 2011-08-04 04:28:03 --> UTF-8 Support Enabled
DEBUG - 2011-08-04 04:28:03 --> URI Class Initialized
DEBUG - 2011-08-04 04:28:03 --> Router Class Initialized
DEBUG - 2011-08-04 04:28:03 --> Output Class Initialized
DEBUG - 2011-08-04 04:28:03 --> Input Class Initialized
DEBUG - 2011-08-04 04:28:03 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-04 04:28:03 --> Language Class Initialized
DEBUG - 2011-08-04 04:28:03 --> Loader Class Initialized
DEBUG - 2011-08-04 04:28:03 --> Controller Class Initialized
DEBUG - 2011-08-04 04:28:03 --> Model Class Initialized
DEBUG - 2011-08-04 04:28:03 --> Model Class Initialized
DEBUG - 2011-08-04 04:28:03 --> Model Class Initialized
DEBUG - 2011-08-04 04:28:03 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-04 04:28:03 --> Database Driver Class Initialized
DEBUG - 2011-08-04 04:28:03 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-04 04:28:03 --> Helper loaded: url_helper
DEBUG - 2011-08-04 04:28:03 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-04 04:28:03 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-04 04:28:03 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-04 04:28:03 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-04 04:28:03 --> Final output sent to browser
DEBUG - 2011-08-04 04:28:03 --> Total execution time: 0.0518
DEBUG - 2011-08-04 04:28:19 --> Config Class Initialized
DEBUG - 2011-08-04 04:28:19 --> Hooks Class Initialized
DEBUG - 2011-08-04 04:28:19 --> Utf8 Class Initialized
DEBUG - 2011-08-04 04:28:19 --> UTF-8 Support Enabled
DEBUG - 2011-08-04 04:28:19 --> URI Class Initialized
DEBUG - 2011-08-04 04:28:19 --> Router Class Initialized
DEBUG - 2011-08-04 04:28:19 --> Output Class Initialized
DEBUG - 2011-08-04 04:28:19 --> Input Class Initialized
DEBUG - 2011-08-04 04:28:19 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-04 04:28:19 --> Language Class Initialized
DEBUG - 2011-08-04 04:28:19 --> Loader Class Initialized
DEBUG - 2011-08-04 04:28:19 --> Controller Class Initialized
DEBUG - 2011-08-04 04:28:19 --> Model Class Initialized
DEBUG - 2011-08-04 04:28:19 --> Model Class Initialized
DEBUG - 2011-08-04 04:28:19 --> Model Class Initialized
DEBUG - 2011-08-04 04:28:19 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-04 04:28:19 --> Database Driver Class Initialized
DEBUG - 2011-08-04 04:28:19 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-04 04:28:19 --> Helper loaded: url_helper
DEBUG - 2011-08-04 04:28:19 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-04 04:28:19 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-04 04:28:19 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-04 04:28:19 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-04 04:28:19 --> Final output sent to browser
DEBUG - 2011-08-04 04:28:19 --> Total execution time: 0.2244
DEBUG - 2011-08-04 04:28:28 --> Config Class Initialized
DEBUG - 2011-08-04 04:28:28 --> Hooks Class Initialized
DEBUG - 2011-08-04 04:28:28 --> Utf8 Class Initialized
DEBUG - 2011-08-04 04:28:28 --> UTF-8 Support Enabled
DEBUG - 2011-08-04 04:28:28 --> URI Class Initialized
DEBUG - 2011-08-04 04:28:28 --> Router Class Initialized
DEBUG - 2011-08-04 04:28:28 --> Output Class Initialized
DEBUG - 2011-08-04 04:28:28 --> Input Class Initialized
DEBUG - 2011-08-04 04:28:28 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-04 04:28:28 --> Language Class Initialized
DEBUG - 2011-08-04 04:28:28 --> Loader Class Initialized
DEBUG - 2011-08-04 04:28:28 --> Controller Class Initialized
DEBUG - 2011-08-04 04:28:28 --> Model Class Initialized
DEBUG - 2011-08-04 04:28:28 --> Model Class Initialized
DEBUG - 2011-08-04 04:28:28 --> Model Class Initialized
DEBUG - 2011-08-04 04:28:28 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-04 04:28:28 --> Database Driver Class Initialized
DEBUG - 2011-08-04 04:28:28 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-04 04:28:28 --> Helper loaded: url_helper
DEBUG - 2011-08-04 04:28:28 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-04 04:28:28 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-04 04:28:28 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-04 04:28:28 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-04 04:28:28 --> Final output sent to browser
DEBUG - 2011-08-04 04:28:28 --> Total execution time: 0.3015
DEBUG - 2011-08-04 04:28:37 --> Config Class Initialized
DEBUG - 2011-08-04 04:28:37 --> Hooks Class Initialized
DEBUG - 2011-08-04 04:28:37 --> Utf8 Class Initialized
DEBUG - 2011-08-04 04:28:37 --> UTF-8 Support Enabled
DEBUG - 2011-08-04 04:28:37 --> URI Class Initialized
DEBUG - 2011-08-04 04:28:37 --> Router Class Initialized
DEBUG - 2011-08-04 04:28:37 --> Output Class Initialized
DEBUG - 2011-08-04 04:28:37 --> Input Class Initialized
DEBUG - 2011-08-04 04:28:37 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-04 04:28:37 --> Language Class Initialized
DEBUG - 2011-08-04 04:28:37 --> Loader Class Initialized
DEBUG - 2011-08-04 04:28:37 --> Controller Class Initialized
DEBUG - 2011-08-04 04:28:37 --> Model Class Initialized
DEBUG - 2011-08-04 04:28:37 --> Model Class Initialized
DEBUG - 2011-08-04 04:28:37 --> Model Class Initialized
DEBUG - 2011-08-04 04:28:37 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-04 04:28:37 --> Database Driver Class Initialized
DEBUG - 2011-08-04 04:28:37 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-04 04:28:37 --> Helper loaded: url_helper
DEBUG - 2011-08-04 04:28:37 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-04 04:28:37 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-04 04:28:37 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-04 04:28:37 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-04 04:28:37 --> Final output sent to browser
DEBUG - 2011-08-04 04:28:37 --> Total execution time: 0.0462
DEBUG - 2011-08-04 04:28:46 --> Config Class Initialized
DEBUG - 2011-08-04 04:28:46 --> Hooks Class Initialized
DEBUG - 2011-08-04 04:28:46 --> Utf8 Class Initialized
DEBUG - 2011-08-04 04:28:46 --> UTF-8 Support Enabled
DEBUG - 2011-08-04 04:28:46 --> URI Class Initialized
DEBUG - 2011-08-04 04:28:46 --> Router Class Initialized
DEBUG - 2011-08-04 04:28:46 --> Output Class Initialized
DEBUG - 2011-08-04 04:28:46 --> Input Class Initialized
DEBUG - 2011-08-04 04:28:46 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-04 04:28:46 --> Language Class Initialized
DEBUG - 2011-08-04 04:28:46 --> Loader Class Initialized
DEBUG - 2011-08-04 04:28:46 --> Controller Class Initialized
DEBUG - 2011-08-04 04:28:46 --> Model Class Initialized
DEBUG - 2011-08-04 04:28:46 --> Model Class Initialized
DEBUG - 2011-08-04 04:28:46 --> Model Class Initialized
DEBUG - 2011-08-04 04:28:46 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-04 04:28:46 --> Database Driver Class Initialized
DEBUG - 2011-08-04 04:28:46 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-04 04:28:46 --> Helper loaded: url_helper
DEBUG - 2011-08-04 04:28:46 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-04 04:28:46 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-04 04:28:46 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-04 04:28:46 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-04 04:28:46 --> Final output sent to browser
DEBUG - 2011-08-04 04:28:46 --> Total execution time: 0.2931
DEBUG - 2011-08-04 04:28:56 --> Config Class Initialized
DEBUG - 2011-08-04 04:28:56 --> Hooks Class Initialized
DEBUG - 2011-08-04 04:28:56 --> Utf8 Class Initialized
DEBUG - 2011-08-04 04:28:56 --> UTF-8 Support Enabled
DEBUG - 2011-08-04 04:28:56 --> URI Class Initialized
DEBUG - 2011-08-04 04:28:56 --> Router Class Initialized
DEBUG - 2011-08-04 04:28:56 --> Output Class Initialized
DEBUG - 2011-08-04 04:28:56 --> Input Class Initialized
DEBUG - 2011-08-04 04:28:56 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-04 04:28:56 --> Language Class Initialized
DEBUG - 2011-08-04 04:28:56 --> Loader Class Initialized
DEBUG - 2011-08-04 04:28:56 --> Controller Class Initialized
DEBUG - 2011-08-04 04:28:56 --> Model Class Initialized
DEBUG - 2011-08-04 04:28:56 --> Model Class Initialized
DEBUG - 2011-08-04 04:28:56 --> Model Class Initialized
DEBUG - 2011-08-04 04:28:56 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-04 04:28:56 --> Database Driver Class Initialized
DEBUG - 2011-08-04 04:28:56 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-04 04:28:56 --> Helper loaded: url_helper
DEBUG - 2011-08-04 04:28:56 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-04 04:28:56 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-04 04:28:56 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-04 04:28:56 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-04 04:28:56 --> Final output sent to browser
DEBUG - 2011-08-04 04:28:56 --> Total execution time: 0.2377
DEBUG - 2011-08-04 04:29:03 --> Config Class Initialized
DEBUG - 2011-08-04 04:29:03 --> Hooks Class Initialized
DEBUG - 2011-08-04 04:29:03 --> Utf8 Class Initialized
DEBUG - 2011-08-04 04:29:03 --> UTF-8 Support Enabled
DEBUG - 2011-08-04 04:29:03 --> URI Class Initialized
DEBUG - 2011-08-04 04:29:03 --> Router Class Initialized
DEBUG - 2011-08-04 04:29:03 --> Output Class Initialized
DEBUG - 2011-08-04 04:29:03 --> Input Class Initialized
DEBUG - 2011-08-04 04:29:03 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-04 04:29:03 --> Language Class Initialized
DEBUG - 2011-08-04 04:29:03 --> Loader Class Initialized
DEBUG - 2011-08-04 04:29:03 --> Controller Class Initialized
DEBUG - 2011-08-04 04:29:03 --> Model Class Initialized
DEBUG - 2011-08-04 04:29:03 --> Model Class Initialized
DEBUG - 2011-08-04 04:29:03 --> Model Class Initialized
DEBUG - 2011-08-04 04:29:03 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-04 04:29:03 --> Database Driver Class Initialized
DEBUG - 2011-08-04 04:29:04 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-04 04:29:04 --> Helper loaded: url_helper
DEBUG - 2011-08-04 04:29:04 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-04 04:29:04 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-04 04:29:04 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-04 04:29:04 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-04 04:29:04 --> Final output sent to browser
DEBUG - 2011-08-04 04:29:04 --> Total execution time: 1.5813
DEBUG - 2011-08-04 04:29:13 --> Config Class Initialized
DEBUG - 2011-08-04 04:29:13 --> Hooks Class Initialized
DEBUG - 2011-08-04 04:29:13 --> Utf8 Class Initialized
DEBUG - 2011-08-04 04:29:13 --> UTF-8 Support Enabled
DEBUG - 2011-08-04 04:29:13 --> URI Class Initialized
DEBUG - 2011-08-04 04:29:13 --> Router Class Initialized
DEBUG - 2011-08-04 04:29:13 --> Output Class Initialized
DEBUG - 2011-08-04 04:29:13 --> Input Class Initialized
DEBUG - 2011-08-04 04:29:13 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-04 04:29:13 --> Language Class Initialized
DEBUG - 2011-08-04 04:29:13 --> Loader Class Initialized
DEBUG - 2011-08-04 04:29:13 --> Controller Class Initialized
DEBUG - 2011-08-04 04:29:13 --> Model Class Initialized
DEBUG - 2011-08-04 04:29:13 --> Model Class Initialized
DEBUG - 2011-08-04 04:29:13 --> Model Class Initialized
DEBUG - 2011-08-04 04:29:13 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-04 04:29:13 --> Database Driver Class Initialized
DEBUG - 2011-08-04 04:29:14 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-04 04:29:14 --> Helper loaded: url_helper
DEBUG - 2011-08-04 04:29:14 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-04 04:29:14 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-04 04:29:14 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-04 04:29:14 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-04 04:29:14 --> Final output sent to browser
DEBUG - 2011-08-04 04:29:14 --> Total execution time: 0.8083
DEBUG - 2011-08-04 04:29:25 --> Config Class Initialized
DEBUG - 2011-08-04 04:29:25 --> Hooks Class Initialized
DEBUG - 2011-08-04 04:29:25 --> Utf8 Class Initialized
DEBUG - 2011-08-04 04:29:25 --> UTF-8 Support Enabled
DEBUG - 2011-08-04 04:29:25 --> URI Class Initialized
DEBUG - 2011-08-04 04:29:25 --> Router Class Initialized
DEBUG - 2011-08-04 04:29:25 --> Output Class Initialized
DEBUG - 2011-08-04 04:29:25 --> Input Class Initialized
DEBUG - 2011-08-04 04:29:25 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-04 04:29:25 --> Language Class Initialized
DEBUG - 2011-08-04 04:29:25 --> Loader Class Initialized
DEBUG - 2011-08-04 04:29:25 --> Controller Class Initialized
DEBUG - 2011-08-04 04:29:25 --> Model Class Initialized
DEBUG - 2011-08-04 04:29:25 --> Model Class Initialized
DEBUG - 2011-08-04 04:29:25 --> Model Class Initialized
DEBUG - 2011-08-04 04:29:25 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-04 04:29:25 --> Database Driver Class Initialized
DEBUG - 2011-08-04 04:29:25 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-04 04:29:25 --> Helper loaded: url_helper
DEBUG - 2011-08-04 04:29:25 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-04 04:29:25 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-04 04:29:25 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-04 04:29:25 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-04 04:29:25 --> Final output sent to browser
DEBUG - 2011-08-04 04:29:25 --> Total execution time: 0.2165
DEBUG - 2011-08-04 04:29:31 --> Config Class Initialized
DEBUG - 2011-08-04 04:29:31 --> Hooks Class Initialized
DEBUG - 2011-08-04 04:29:31 --> Utf8 Class Initialized
DEBUG - 2011-08-04 04:29:31 --> UTF-8 Support Enabled
DEBUG - 2011-08-04 04:29:31 --> URI Class Initialized
DEBUG - 2011-08-04 04:29:31 --> Router Class Initialized
DEBUG - 2011-08-04 04:29:31 --> Output Class Initialized
DEBUG - 2011-08-04 04:29:31 --> Input Class Initialized
DEBUG - 2011-08-04 04:29:31 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-04 04:29:31 --> Language Class Initialized
DEBUG - 2011-08-04 04:29:31 --> Loader Class Initialized
DEBUG - 2011-08-04 04:29:31 --> Controller Class Initialized
DEBUG - 2011-08-04 04:29:31 --> Model Class Initialized
DEBUG - 2011-08-04 04:29:31 --> Model Class Initialized
DEBUG - 2011-08-04 04:29:31 --> Model Class Initialized
DEBUG - 2011-08-04 04:29:31 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-04 04:29:31 --> Database Driver Class Initialized
DEBUG - 2011-08-04 04:29:31 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-04 04:29:31 --> Helper loaded: url_helper
DEBUG - 2011-08-04 04:29:31 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-04 04:29:31 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-04 04:29:31 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-04 04:29:31 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-04 04:29:31 --> Final output sent to browser
DEBUG - 2011-08-04 04:29:31 --> Total execution time: 0.2541
DEBUG - 2011-08-04 04:31:06 --> Config Class Initialized
DEBUG - 2011-08-04 04:31:06 --> Hooks Class Initialized
DEBUG - 2011-08-04 04:31:06 --> Utf8 Class Initialized
DEBUG - 2011-08-04 04:31:06 --> UTF-8 Support Enabled
DEBUG - 2011-08-04 04:31:06 --> URI Class Initialized
DEBUG - 2011-08-04 04:31:06 --> Router Class Initialized
DEBUG - 2011-08-04 04:31:06 --> Output Class Initialized
DEBUG - 2011-08-04 04:31:06 --> Input Class Initialized
DEBUG - 2011-08-04 04:31:06 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-04 04:31:06 --> Language Class Initialized
DEBUG - 2011-08-04 04:31:06 --> Loader Class Initialized
DEBUG - 2011-08-04 04:31:06 --> Controller Class Initialized
DEBUG - 2011-08-04 04:31:06 --> Model Class Initialized
DEBUG - 2011-08-04 04:31:06 --> Model Class Initialized
DEBUG - 2011-08-04 04:31:06 --> Model Class Initialized
DEBUG - 2011-08-04 04:31:06 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-04 04:31:06 --> Database Driver Class Initialized
DEBUG - 2011-08-04 04:31:06 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-04 04:31:06 --> Helper loaded: url_helper
DEBUG - 2011-08-04 04:31:06 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-04 04:31:06 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-04 04:31:06 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-04 04:31:06 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-04 04:31:06 --> Final output sent to browser
DEBUG - 2011-08-04 04:31:06 --> Total execution time: 0.0452
DEBUG - 2011-08-04 04:31:24 --> Config Class Initialized
DEBUG - 2011-08-04 04:31:24 --> Hooks Class Initialized
DEBUG - 2011-08-04 04:31:24 --> Utf8 Class Initialized
DEBUG - 2011-08-04 04:31:24 --> UTF-8 Support Enabled
DEBUG - 2011-08-04 04:31:24 --> URI Class Initialized
DEBUG - 2011-08-04 04:31:24 --> Router Class Initialized
DEBUG - 2011-08-04 04:31:24 --> Output Class Initialized
DEBUG - 2011-08-04 04:31:24 --> Input Class Initialized
DEBUG - 2011-08-04 04:31:24 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-04 04:31:24 --> Language Class Initialized
DEBUG - 2011-08-04 04:31:24 --> Loader Class Initialized
DEBUG - 2011-08-04 04:31:24 --> Controller Class Initialized
DEBUG - 2011-08-04 04:31:24 --> Model Class Initialized
DEBUG - 2011-08-04 04:31:24 --> Model Class Initialized
DEBUG - 2011-08-04 04:31:24 --> Model Class Initialized
DEBUG - 2011-08-04 04:31:24 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-04 04:31:24 --> Database Driver Class Initialized
DEBUG - 2011-08-04 04:31:25 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-04 04:31:25 --> Helper loaded: url_helper
DEBUG - 2011-08-04 04:31:25 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-04 04:31:25 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-04 04:31:25 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-04 04:31:25 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-04 04:31:25 --> Final output sent to browser
DEBUG - 2011-08-04 04:31:25 --> Total execution time: 0.2824
DEBUG - 2011-08-04 04:31:41 --> Config Class Initialized
DEBUG - 2011-08-04 04:31:41 --> Hooks Class Initialized
DEBUG - 2011-08-04 04:31:41 --> Utf8 Class Initialized
DEBUG - 2011-08-04 04:31:41 --> UTF-8 Support Enabled
DEBUG - 2011-08-04 04:31:41 --> URI Class Initialized
DEBUG - 2011-08-04 04:31:41 --> Router Class Initialized
DEBUG - 2011-08-04 04:31:41 --> Output Class Initialized
DEBUG - 2011-08-04 04:31:41 --> Input Class Initialized
DEBUG - 2011-08-04 04:31:41 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-04 04:31:41 --> Language Class Initialized
DEBUG - 2011-08-04 04:31:41 --> Loader Class Initialized
DEBUG - 2011-08-04 04:31:41 --> Controller Class Initialized
DEBUG - 2011-08-04 04:31:41 --> Model Class Initialized
DEBUG - 2011-08-04 04:31:41 --> Model Class Initialized
DEBUG - 2011-08-04 04:31:41 --> Model Class Initialized
DEBUG - 2011-08-04 04:31:41 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-04 04:31:41 --> Database Driver Class Initialized
DEBUG - 2011-08-04 04:31:41 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-04 04:31:41 --> Helper loaded: url_helper
DEBUG - 2011-08-04 04:31:41 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-04 04:31:41 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-04 04:31:41 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-04 04:31:41 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-04 04:31:41 --> Final output sent to browser
DEBUG - 2011-08-04 04:31:41 --> Total execution time: 0.0470
DEBUG - 2011-08-04 04:32:36 --> Config Class Initialized
DEBUG - 2011-08-04 04:32:36 --> Hooks Class Initialized
DEBUG - 2011-08-04 04:32:36 --> Utf8 Class Initialized
DEBUG - 2011-08-04 04:32:36 --> UTF-8 Support Enabled
DEBUG - 2011-08-04 04:32:36 --> URI Class Initialized
DEBUG - 2011-08-04 04:32:36 --> Router Class Initialized
DEBUG - 2011-08-04 04:32:36 --> Output Class Initialized
DEBUG - 2011-08-04 04:32:36 --> Input Class Initialized
DEBUG - 2011-08-04 04:32:36 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-04 04:32:36 --> Language Class Initialized
DEBUG - 2011-08-04 04:32:36 --> Loader Class Initialized
DEBUG - 2011-08-04 04:32:36 --> Controller Class Initialized
DEBUG - 2011-08-04 04:32:36 --> Model Class Initialized
DEBUG - 2011-08-04 04:32:36 --> Model Class Initialized
DEBUG - 2011-08-04 04:32:36 --> Model Class Initialized
DEBUG - 2011-08-04 04:32:36 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-04 04:32:36 --> Database Driver Class Initialized
DEBUG - 2011-08-04 04:32:36 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-04 04:32:36 --> Helper loaded: url_helper
DEBUG - 2011-08-04 04:32:36 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-04 04:32:36 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-04 04:32:36 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-04 04:32:36 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-04 04:32:36 --> Final output sent to browser
DEBUG - 2011-08-04 04:32:36 --> Total execution time: 0.0531
DEBUG - 2011-08-04 04:32:49 --> Config Class Initialized
DEBUG - 2011-08-04 04:32:49 --> Hooks Class Initialized
DEBUG - 2011-08-04 04:32:49 --> Utf8 Class Initialized
DEBUG - 2011-08-04 04:32:49 --> UTF-8 Support Enabled
DEBUG - 2011-08-04 04:32:49 --> URI Class Initialized
DEBUG - 2011-08-04 04:32:49 --> Router Class Initialized
DEBUG - 2011-08-04 04:32:49 --> Output Class Initialized
DEBUG - 2011-08-04 04:32:49 --> Input Class Initialized
DEBUG - 2011-08-04 04:32:49 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-04 04:32:49 --> Language Class Initialized
DEBUG - 2011-08-04 04:32:49 --> Loader Class Initialized
DEBUG - 2011-08-04 04:32:49 --> Controller Class Initialized
DEBUG - 2011-08-04 04:32:49 --> Model Class Initialized
DEBUG - 2011-08-04 04:32:49 --> Model Class Initialized
DEBUG - 2011-08-04 04:32:49 --> Model Class Initialized
DEBUG - 2011-08-04 04:32:49 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-04 04:32:49 --> Database Driver Class Initialized
DEBUG - 2011-08-04 04:32:49 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-04 04:32:49 --> Helper loaded: url_helper
DEBUG - 2011-08-04 04:32:49 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-04 04:32:49 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-04 04:32:49 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-04 04:32:49 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-04 04:32:49 --> Final output sent to browser
DEBUG - 2011-08-04 04:32:49 --> Total execution time: 0.2247
DEBUG - 2011-08-04 04:33:04 --> Config Class Initialized
DEBUG - 2011-08-04 04:33:04 --> Hooks Class Initialized
DEBUG - 2011-08-04 04:33:04 --> Utf8 Class Initialized
DEBUG - 2011-08-04 04:33:04 --> UTF-8 Support Enabled
DEBUG - 2011-08-04 04:33:04 --> URI Class Initialized
DEBUG - 2011-08-04 04:33:04 --> Router Class Initialized
DEBUG - 2011-08-04 04:33:04 --> Output Class Initialized
DEBUG - 2011-08-04 04:33:04 --> Input Class Initialized
DEBUG - 2011-08-04 04:33:04 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-04 04:33:04 --> Language Class Initialized
DEBUG - 2011-08-04 04:33:04 --> Loader Class Initialized
DEBUG - 2011-08-04 04:33:04 --> Controller Class Initialized
DEBUG - 2011-08-04 04:33:04 --> Model Class Initialized
DEBUG - 2011-08-04 04:33:04 --> Model Class Initialized
DEBUG - 2011-08-04 04:33:04 --> Model Class Initialized
DEBUG - 2011-08-04 04:33:04 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-04 04:33:04 --> Database Driver Class Initialized
DEBUG - 2011-08-04 04:33:04 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-04 04:33:04 --> Helper loaded: url_helper
DEBUG - 2011-08-04 04:33:04 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-04 04:33:04 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-04 04:33:04 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-04 04:33:04 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-04 04:33:04 --> Final output sent to browser
DEBUG - 2011-08-04 04:33:04 --> Total execution time: 0.0779
DEBUG - 2011-08-04 04:33:04 --> Config Class Initialized
DEBUG - 2011-08-04 04:33:04 --> Hooks Class Initialized
DEBUG - 2011-08-04 04:33:04 --> Utf8 Class Initialized
DEBUG - 2011-08-04 04:33:04 --> UTF-8 Support Enabled
DEBUG - 2011-08-04 04:33:04 --> URI Class Initialized
DEBUG - 2011-08-04 04:33:04 --> Router Class Initialized
DEBUG - 2011-08-04 04:33:04 --> Output Class Initialized
DEBUG - 2011-08-04 04:33:04 --> Input Class Initialized
DEBUG - 2011-08-04 04:33:04 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-04 04:33:04 --> Language Class Initialized
DEBUG - 2011-08-04 04:33:04 --> Loader Class Initialized
DEBUG - 2011-08-04 04:33:04 --> Controller Class Initialized
DEBUG - 2011-08-04 04:33:04 --> Model Class Initialized
DEBUG - 2011-08-04 04:33:04 --> Model Class Initialized
DEBUG - 2011-08-04 04:33:04 --> Model Class Initialized
DEBUG - 2011-08-04 04:33:04 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-04 04:33:04 --> Database Driver Class Initialized
DEBUG - 2011-08-04 04:33:04 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-04 04:33:04 --> Helper loaded: url_helper
DEBUG - 2011-08-04 04:33:04 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-04 04:33:04 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-04 04:33:04 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-04 04:33:04 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-04 04:33:04 --> Final output sent to browser
DEBUG - 2011-08-04 04:33:04 --> Total execution time: 0.3346
DEBUG - 2011-08-04 04:33:07 --> Config Class Initialized
DEBUG - 2011-08-04 04:33:07 --> Hooks Class Initialized
DEBUG - 2011-08-04 04:33:07 --> Utf8 Class Initialized
DEBUG - 2011-08-04 04:33:07 --> UTF-8 Support Enabled
DEBUG - 2011-08-04 04:33:07 --> URI Class Initialized
DEBUG - 2011-08-04 04:33:07 --> Router Class Initialized
DEBUG - 2011-08-04 04:33:07 --> Output Class Initialized
DEBUG - 2011-08-04 04:33:07 --> Input Class Initialized
DEBUG - 2011-08-04 04:33:07 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-04 04:33:07 --> Language Class Initialized
DEBUG - 2011-08-04 04:33:07 --> Loader Class Initialized
DEBUG - 2011-08-04 04:33:07 --> Controller Class Initialized
DEBUG - 2011-08-04 04:33:07 --> Model Class Initialized
DEBUG - 2011-08-04 04:33:07 --> Model Class Initialized
DEBUG - 2011-08-04 04:33:07 --> Model Class Initialized
DEBUG - 2011-08-04 04:33:07 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-04 04:33:07 --> Database Driver Class Initialized
DEBUG - 2011-08-04 04:33:07 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-04 04:33:07 --> Helper loaded: url_helper
DEBUG - 2011-08-04 04:33:07 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-04 04:33:07 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-04 04:33:07 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-04 04:33:07 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-04 04:33:07 --> Final output sent to browser
DEBUG - 2011-08-04 04:33:07 --> Total execution time: 0.0438
DEBUG - 2011-08-04 04:33:15 --> Config Class Initialized
DEBUG - 2011-08-04 04:33:15 --> Hooks Class Initialized
DEBUG - 2011-08-04 04:33:15 --> Utf8 Class Initialized
DEBUG - 2011-08-04 04:33:15 --> UTF-8 Support Enabled
DEBUG - 2011-08-04 04:33:15 --> URI Class Initialized
DEBUG - 2011-08-04 04:33:15 --> Router Class Initialized
DEBUG - 2011-08-04 04:33:15 --> Output Class Initialized
DEBUG - 2011-08-04 04:33:15 --> Input Class Initialized
DEBUG - 2011-08-04 04:33:15 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-04 04:33:15 --> Language Class Initialized
DEBUG - 2011-08-04 04:33:15 --> Loader Class Initialized
DEBUG - 2011-08-04 04:33:15 --> Controller Class Initialized
DEBUG - 2011-08-04 04:33:15 --> Model Class Initialized
DEBUG - 2011-08-04 04:33:15 --> Model Class Initialized
DEBUG - 2011-08-04 04:33:15 --> Model Class Initialized
DEBUG - 2011-08-04 04:33:15 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-04 04:33:15 --> Database Driver Class Initialized
DEBUG - 2011-08-04 04:33:15 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-04 04:33:15 --> Helper loaded: url_helper
DEBUG - 2011-08-04 04:33:15 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-04 04:33:15 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-04 04:33:15 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-04 04:33:15 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-04 04:33:15 --> Final output sent to browser
DEBUG - 2011-08-04 04:33:15 --> Total execution time: 0.0502
DEBUG - 2011-08-04 04:33:41 --> Config Class Initialized
DEBUG - 2011-08-04 04:33:41 --> Hooks Class Initialized
DEBUG - 2011-08-04 04:33:41 --> Utf8 Class Initialized
DEBUG - 2011-08-04 04:33:41 --> UTF-8 Support Enabled
DEBUG - 2011-08-04 04:33:41 --> URI Class Initialized
DEBUG - 2011-08-04 04:33:41 --> Router Class Initialized
DEBUG - 2011-08-04 04:33:41 --> Output Class Initialized
DEBUG - 2011-08-04 04:33:41 --> Input Class Initialized
DEBUG - 2011-08-04 04:33:41 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-04 04:33:41 --> Language Class Initialized
DEBUG - 2011-08-04 04:33:41 --> Loader Class Initialized
DEBUG - 2011-08-04 04:33:41 --> Controller Class Initialized
DEBUG - 2011-08-04 04:33:41 --> Model Class Initialized
DEBUG - 2011-08-04 04:33:41 --> Model Class Initialized
DEBUG - 2011-08-04 04:33:41 --> Model Class Initialized
DEBUG - 2011-08-04 04:33:41 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-04 04:33:41 --> Database Driver Class Initialized
DEBUG - 2011-08-04 04:33:42 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-04 04:33:42 --> Helper loaded: url_helper
DEBUG - 2011-08-04 04:33:42 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-04 04:33:42 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-04 04:33:42 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-04 04:33:42 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-04 04:33:42 --> Final output sent to browser
DEBUG - 2011-08-04 04:33:42 --> Total execution time: 0.7086
DEBUG - 2011-08-04 04:33:53 --> Config Class Initialized
DEBUG - 2011-08-04 04:33:53 --> Hooks Class Initialized
DEBUG - 2011-08-04 04:33:53 --> Utf8 Class Initialized
DEBUG - 2011-08-04 04:33:53 --> UTF-8 Support Enabled
DEBUG - 2011-08-04 04:33:53 --> URI Class Initialized
DEBUG - 2011-08-04 04:33:53 --> Router Class Initialized
DEBUG - 2011-08-04 04:33:53 --> Output Class Initialized
DEBUG - 2011-08-04 04:33:53 --> Input Class Initialized
DEBUG - 2011-08-04 04:33:53 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-04 04:33:53 --> Language Class Initialized
DEBUG - 2011-08-04 04:33:53 --> Loader Class Initialized
DEBUG - 2011-08-04 04:33:53 --> Controller Class Initialized
DEBUG - 2011-08-04 04:33:53 --> Model Class Initialized
DEBUG - 2011-08-04 04:33:53 --> Model Class Initialized
DEBUG - 2011-08-04 04:33:53 --> Model Class Initialized
DEBUG - 2011-08-04 04:33:53 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-04 04:33:53 --> Database Driver Class Initialized
DEBUG - 2011-08-04 04:33:53 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-04 04:33:53 --> Helper loaded: url_helper
DEBUG - 2011-08-04 04:33:53 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-04 04:33:53 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-04 04:33:53 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-04 04:33:53 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-04 04:33:53 --> Final output sent to browser
DEBUG - 2011-08-04 04:33:53 --> Total execution time: 0.0475
DEBUG - 2011-08-04 04:33:56 --> Config Class Initialized
DEBUG - 2011-08-04 04:33:56 --> Hooks Class Initialized
DEBUG - 2011-08-04 04:33:56 --> Utf8 Class Initialized
DEBUG - 2011-08-04 04:33:56 --> UTF-8 Support Enabled
DEBUG - 2011-08-04 04:33:56 --> URI Class Initialized
DEBUG - 2011-08-04 04:33:56 --> Router Class Initialized
DEBUG - 2011-08-04 04:33:56 --> Output Class Initialized
DEBUG - 2011-08-04 04:33:56 --> Input Class Initialized
DEBUG - 2011-08-04 04:33:56 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-04 04:33:56 --> Language Class Initialized
DEBUG - 2011-08-04 04:33:56 --> Loader Class Initialized
DEBUG - 2011-08-04 04:33:56 --> Controller Class Initialized
DEBUG - 2011-08-04 04:33:56 --> Model Class Initialized
DEBUG - 2011-08-04 04:33:56 --> Model Class Initialized
DEBUG - 2011-08-04 04:33:56 --> Model Class Initialized
DEBUG - 2011-08-04 04:33:56 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-04 04:33:56 --> Database Driver Class Initialized
DEBUG - 2011-08-04 04:33:57 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-04 04:33:57 --> Helper loaded: url_helper
DEBUG - 2011-08-04 04:33:57 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-04 04:33:57 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-04 04:33:57 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-04 04:33:57 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-04 04:33:57 --> Final output sent to browser
DEBUG - 2011-08-04 04:33:57 --> Total execution time: 0.2911
DEBUG - 2011-08-04 04:34:20 --> Config Class Initialized
DEBUG - 2011-08-04 04:34:20 --> Hooks Class Initialized
DEBUG - 2011-08-04 04:34:20 --> Utf8 Class Initialized
DEBUG - 2011-08-04 04:34:20 --> UTF-8 Support Enabled
DEBUG - 2011-08-04 04:34:20 --> URI Class Initialized
DEBUG - 2011-08-04 04:34:20 --> Router Class Initialized
DEBUG - 2011-08-04 04:34:20 --> Output Class Initialized
DEBUG - 2011-08-04 04:34:20 --> Input Class Initialized
DEBUG - 2011-08-04 04:34:20 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-04 04:34:20 --> Language Class Initialized
DEBUG - 2011-08-04 04:34:20 --> Loader Class Initialized
DEBUG - 2011-08-04 04:34:20 --> Controller Class Initialized
DEBUG - 2011-08-04 04:34:20 --> Model Class Initialized
DEBUG - 2011-08-04 04:34:20 --> Model Class Initialized
DEBUG - 2011-08-04 04:34:20 --> Model Class Initialized
DEBUG - 2011-08-04 04:34:20 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-04 04:34:20 --> Database Driver Class Initialized
DEBUG - 2011-08-04 04:34:21 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-04 04:34:21 --> Helper loaded: url_helper
DEBUG - 2011-08-04 04:34:21 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-04 04:34:21 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-04 04:34:21 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-04 04:34:21 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-04 04:34:21 --> Final output sent to browser
DEBUG - 2011-08-04 04:34:21 --> Total execution time: 0.2406
DEBUG - 2011-08-04 04:34:22 --> Config Class Initialized
DEBUG - 2011-08-04 04:34:22 --> Hooks Class Initialized
DEBUG - 2011-08-04 04:34:22 --> Utf8 Class Initialized
DEBUG - 2011-08-04 04:34:22 --> UTF-8 Support Enabled
DEBUG - 2011-08-04 04:34:22 --> URI Class Initialized
DEBUG - 2011-08-04 04:34:22 --> Router Class Initialized
DEBUG - 2011-08-04 04:34:22 --> Output Class Initialized
DEBUG - 2011-08-04 04:34:22 --> Input Class Initialized
DEBUG - 2011-08-04 04:34:22 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-04 04:34:22 --> Language Class Initialized
DEBUG - 2011-08-04 04:34:22 --> Loader Class Initialized
DEBUG - 2011-08-04 04:34:22 --> Controller Class Initialized
DEBUG - 2011-08-04 04:34:22 --> Model Class Initialized
DEBUG - 2011-08-04 04:34:22 --> Model Class Initialized
DEBUG - 2011-08-04 04:34:22 --> Model Class Initialized
DEBUG - 2011-08-04 04:34:22 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-04 04:34:22 --> Database Driver Class Initialized
DEBUG - 2011-08-04 04:34:22 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-04 04:34:22 --> Helper loaded: url_helper
DEBUG - 2011-08-04 04:34:22 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-04 04:34:22 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-04 04:34:22 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-04 04:34:22 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-04 04:34:22 --> Final output sent to browser
DEBUG - 2011-08-04 04:34:22 --> Total execution time: 0.0824
DEBUG - 2011-08-04 04:34:33 --> Config Class Initialized
DEBUG - 2011-08-04 04:34:33 --> Hooks Class Initialized
DEBUG - 2011-08-04 04:34:33 --> Utf8 Class Initialized
DEBUG - 2011-08-04 04:34:33 --> UTF-8 Support Enabled
DEBUG - 2011-08-04 04:34:33 --> URI Class Initialized
DEBUG - 2011-08-04 04:34:33 --> Router Class Initialized
DEBUG - 2011-08-04 04:34:33 --> Output Class Initialized
DEBUG - 2011-08-04 04:34:33 --> Input Class Initialized
DEBUG - 2011-08-04 04:34:33 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-04 04:34:33 --> Language Class Initialized
DEBUG - 2011-08-04 04:34:33 --> Loader Class Initialized
DEBUG - 2011-08-04 04:34:33 --> Controller Class Initialized
DEBUG - 2011-08-04 04:34:33 --> Model Class Initialized
DEBUG - 2011-08-04 04:34:33 --> Model Class Initialized
DEBUG - 2011-08-04 04:34:33 --> Model Class Initialized
DEBUG - 2011-08-04 04:34:33 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-04 04:34:33 --> Database Driver Class Initialized
DEBUG - 2011-08-04 04:34:33 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-04 04:34:33 --> Helper loaded: url_helper
DEBUG - 2011-08-04 04:34:33 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-04 04:34:33 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-04 04:34:33 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-04 04:34:33 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-04 04:34:33 --> Final output sent to browser
DEBUG - 2011-08-04 04:34:33 --> Total execution time: 0.0786
DEBUG - 2011-08-04 04:34:38 --> Config Class Initialized
DEBUG - 2011-08-04 04:34:38 --> Hooks Class Initialized
DEBUG - 2011-08-04 04:34:38 --> Utf8 Class Initialized
DEBUG - 2011-08-04 04:34:38 --> UTF-8 Support Enabled
DEBUG - 2011-08-04 04:34:38 --> URI Class Initialized
DEBUG - 2011-08-04 04:34:38 --> Router Class Initialized
DEBUG - 2011-08-04 04:34:38 --> Output Class Initialized
DEBUG - 2011-08-04 04:34:38 --> Input Class Initialized
DEBUG - 2011-08-04 04:34:38 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-04 04:34:38 --> Language Class Initialized
DEBUG - 2011-08-04 04:34:38 --> Loader Class Initialized
DEBUG - 2011-08-04 04:34:38 --> Controller Class Initialized
DEBUG - 2011-08-04 04:34:38 --> Model Class Initialized
DEBUG - 2011-08-04 04:34:38 --> Model Class Initialized
DEBUG - 2011-08-04 04:34:38 --> Model Class Initialized
DEBUG - 2011-08-04 04:34:38 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-04 04:34:38 --> Database Driver Class Initialized
DEBUG - 2011-08-04 04:34:38 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-04 04:34:38 --> Helper loaded: url_helper
DEBUG - 2011-08-04 04:34:38 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-04 04:34:38 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-04 04:34:38 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-04 04:34:38 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-04 04:34:38 --> Final output sent to browser
DEBUG - 2011-08-04 04:34:38 --> Total execution time: 0.2142
DEBUG - 2011-08-04 04:34:45 --> Config Class Initialized
DEBUG - 2011-08-04 04:34:45 --> Hooks Class Initialized
DEBUG - 2011-08-04 04:34:45 --> Utf8 Class Initialized
DEBUG - 2011-08-04 04:34:45 --> UTF-8 Support Enabled
DEBUG - 2011-08-04 04:34:45 --> URI Class Initialized
DEBUG - 2011-08-04 04:34:45 --> Router Class Initialized
DEBUG - 2011-08-04 04:34:45 --> Output Class Initialized
DEBUG - 2011-08-04 04:34:45 --> Input Class Initialized
DEBUG - 2011-08-04 04:34:45 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-04 04:34:45 --> Language Class Initialized
DEBUG - 2011-08-04 04:34:45 --> Loader Class Initialized
DEBUG - 2011-08-04 04:34:45 --> Controller Class Initialized
DEBUG - 2011-08-04 04:34:45 --> Model Class Initialized
DEBUG - 2011-08-04 04:34:45 --> Model Class Initialized
DEBUG - 2011-08-04 04:34:45 --> Model Class Initialized
DEBUG - 2011-08-04 04:34:45 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-04 04:34:45 --> Database Driver Class Initialized
DEBUG - 2011-08-04 04:34:46 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-04 04:34:46 --> Helper loaded: url_helper
DEBUG - 2011-08-04 04:34:46 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-04 04:34:46 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-04 04:34:46 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-04 04:34:46 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-04 04:34:46 --> Final output sent to browser
DEBUG - 2011-08-04 04:34:46 --> Total execution time: 0.0456
DEBUG - 2011-08-04 04:35:06 --> Config Class Initialized
DEBUG - 2011-08-04 04:35:06 --> Hooks Class Initialized
DEBUG - 2011-08-04 04:35:06 --> Utf8 Class Initialized
DEBUG - 2011-08-04 04:35:06 --> UTF-8 Support Enabled
DEBUG - 2011-08-04 04:35:06 --> URI Class Initialized
DEBUG - 2011-08-04 04:35:06 --> Router Class Initialized
DEBUG - 2011-08-04 04:35:06 --> Output Class Initialized
DEBUG - 2011-08-04 04:35:06 --> Input Class Initialized
DEBUG - 2011-08-04 04:35:06 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-04 04:35:06 --> Language Class Initialized
DEBUG - 2011-08-04 04:35:06 --> Loader Class Initialized
DEBUG - 2011-08-04 04:35:06 --> Controller Class Initialized
DEBUG - 2011-08-04 04:35:06 --> Model Class Initialized
DEBUG - 2011-08-04 04:35:06 --> Model Class Initialized
DEBUG - 2011-08-04 04:35:06 --> Model Class Initialized
DEBUG - 2011-08-04 04:35:06 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-04 04:35:06 --> Database Driver Class Initialized
DEBUG - 2011-08-04 04:35:06 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-04 04:35:06 --> Helper loaded: url_helper
DEBUG - 2011-08-04 04:35:06 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-04 04:35:06 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-04 04:35:06 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-04 04:35:06 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-04 04:35:06 --> Final output sent to browser
DEBUG - 2011-08-04 04:35:06 --> Total execution time: 0.3005
DEBUG - 2011-08-04 04:35:16 --> Config Class Initialized
DEBUG - 2011-08-04 04:35:16 --> Hooks Class Initialized
DEBUG - 2011-08-04 04:35:16 --> Utf8 Class Initialized
DEBUG - 2011-08-04 04:35:16 --> UTF-8 Support Enabled
DEBUG - 2011-08-04 04:35:16 --> URI Class Initialized
DEBUG - 2011-08-04 04:35:16 --> Router Class Initialized
DEBUG - 2011-08-04 04:35:16 --> Output Class Initialized
DEBUG - 2011-08-04 04:35:16 --> Input Class Initialized
DEBUG - 2011-08-04 04:35:16 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-04 04:35:16 --> Language Class Initialized
DEBUG - 2011-08-04 04:35:16 --> Loader Class Initialized
DEBUG - 2011-08-04 04:35:16 --> Controller Class Initialized
DEBUG - 2011-08-04 04:35:16 --> Model Class Initialized
DEBUG - 2011-08-04 04:35:16 --> Model Class Initialized
DEBUG - 2011-08-04 04:35:16 --> Model Class Initialized
DEBUG - 2011-08-04 04:35:16 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-04 04:35:16 --> Database Driver Class Initialized
DEBUG - 2011-08-04 04:35:16 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-04 04:35:16 --> Helper loaded: url_helper
DEBUG - 2011-08-04 04:35:16 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-04 04:35:16 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-04 04:35:16 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-04 04:35:16 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-04 04:35:16 --> Final output sent to browser
DEBUG - 2011-08-04 04:35:16 --> Total execution time: 0.2187
DEBUG - 2011-08-04 04:35:28 --> Config Class Initialized
DEBUG - 2011-08-04 04:35:28 --> Hooks Class Initialized
DEBUG - 2011-08-04 04:35:28 --> Utf8 Class Initialized
DEBUG - 2011-08-04 04:35:28 --> UTF-8 Support Enabled
DEBUG - 2011-08-04 04:35:28 --> URI Class Initialized
DEBUG - 2011-08-04 04:35:28 --> Router Class Initialized
DEBUG - 2011-08-04 04:35:28 --> Output Class Initialized
DEBUG - 2011-08-04 04:35:28 --> Input Class Initialized
DEBUG - 2011-08-04 04:35:28 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-04 04:35:28 --> Language Class Initialized
DEBUG - 2011-08-04 04:35:28 --> Loader Class Initialized
DEBUG - 2011-08-04 04:35:28 --> Controller Class Initialized
DEBUG - 2011-08-04 04:35:28 --> Model Class Initialized
DEBUG - 2011-08-04 04:35:28 --> Model Class Initialized
DEBUG - 2011-08-04 04:35:28 --> Model Class Initialized
DEBUG - 2011-08-04 04:35:28 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-04 04:35:28 --> Database Driver Class Initialized
DEBUG - 2011-08-04 04:35:28 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-04 04:35:28 --> Helper loaded: url_helper
DEBUG - 2011-08-04 04:35:28 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-04 04:35:28 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-04 04:35:28 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-04 04:35:28 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-04 04:35:28 --> Final output sent to browser
DEBUG - 2011-08-04 04:35:28 --> Total execution time: 0.0463
DEBUG - 2011-08-04 04:35:41 --> Config Class Initialized
DEBUG - 2011-08-04 04:35:41 --> Hooks Class Initialized
DEBUG - 2011-08-04 04:35:41 --> Utf8 Class Initialized
DEBUG - 2011-08-04 04:35:41 --> UTF-8 Support Enabled
DEBUG - 2011-08-04 04:35:41 --> URI Class Initialized
DEBUG - 2011-08-04 04:35:41 --> Router Class Initialized
DEBUG - 2011-08-04 04:35:41 --> Output Class Initialized
DEBUG - 2011-08-04 04:35:41 --> Input Class Initialized
DEBUG - 2011-08-04 04:35:41 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-04 04:35:41 --> Language Class Initialized
DEBUG - 2011-08-04 04:35:41 --> Loader Class Initialized
DEBUG - 2011-08-04 04:35:41 --> Controller Class Initialized
DEBUG - 2011-08-04 04:35:41 --> Model Class Initialized
DEBUG - 2011-08-04 04:35:41 --> Model Class Initialized
DEBUG - 2011-08-04 04:35:41 --> Model Class Initialized
DEBUG - 2011-08-04 04:35:41 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-04 04:35:41 --> Database Driver Class Initialized
DEBUG - 2011-08-04 04:35:41 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-04 04:35:41 --> Helper loaded: url_helper
DEBUG - 2011-08-04 04:35:41 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-04 04:35:41 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-04 04:35:41 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-04 04:35:41 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-04 04:35:41 --> Final output sent to browser
DEBUG - 2011-08-04 04:35:41 --> Total execution time: 0.2218
DEBUG - 2011-08-04 04:35:46 --> Config Class Initialized
DEBUG - 2011-08-04 04:35:46 --> Hooks Class Initialized
DEBUG - 2011-08-04 04:35:46 --> Utf8 Class Initialized
DEBUG - 2011-08-04 04:35:46 --> UTF-8 Support Enabled
DEBUG - 2011-08-04 04:35:46 --> URI Class Initialized
DEBUG - 2011-08-04 04:35:46 --> Router Class Initialized
DEBUG - 2011-08-04 04:35:46 --> Output Class Initialized
DEBUG - 2011-08-04 04:35:46 --> Input Class Initialized
DEBUG - 2011-08-04 04:35:46 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-04 04:35:46 --> Language Class Initialized
DEBUG - 2011-08-04 04:35:46 --> Loader Class Initialized
DEBUG - 2011-08-04 04:35:46 --> Controller Class Initialized
DEBUG - 2011-08-04 04:35:46 --> Model Class Initialized
DEBUG - 2011-08-04 04:35:46 --> Model Class Initialized
DEBUG - 2011-08-04 04:35:46 --> Model Class Initialized
DEBUG - 2011-08-04 04:35:46 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-04 04:35:46 --> Database Driver Class Initialized
DEBUG - 2011-08-04 04:35:46 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-04 04:35:46 --> Helper loaded: url_helper
DEBUG - 2011-08-04 04:35:46 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-04 04:35:46 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-04 04:35:46 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-04 04:35:46 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-04 04:35:46 --> Final output sent to browser
DEBUG - 2011-08-04 04:35:46 --> Total execution time: 0.0557
DEBUG - 2011-08-04 04:35:47 --> Config Class Initialized
DEBUG - 2011-08-04 04:35:47 --> Hooks Class Initialized
DEBUG - 2011-08-04 04:35:47 --> Utf8 Class Initialized
DEBUG - 2011-08-04 04:35:47 --> UTF-8 Support Enabled
DEBUG - 2011-08-04 04:35:47 --> URI Class Initialized
DEBUG - 2011-08-04 04:35:47 --> Router Class Initialized
DEBUG - 2011-08-04 04:35:47 --> Output Class Initialized
DEBUG - 2011-08-04 04:35:47 --> Input Class Initialized
DEBUG - 2011-08-04 04:35:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-04 04:35:47 --> Language Class Initialized
DEBUG - 2011-08-04 04:35:47 --> Loader Class Initialized
DEBUG - 2011-08-04 04:35:47 --> Controller Class Initialized
DEBUG - 2011-08-04 04:35:47 --> Model Class Initialized
DEBUG - 2011-08-04 04:35:47 --> Model Class Initialized
DEBUG - 2011-08-04 04:35:47 --> Model Class Initialized
DEBUG - 2011-08-04 04:35:47 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-04 04:35:47 --> Database Driver Class Initialized
DEBUG - 2011-08-04 04:35:47 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-04 04:35:47 --> Helper loaded: url_helper
DEBUG - 2011-08-04 04:35:47 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-04 04:35:47 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-04 04:35:47 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-04 04:35:47 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-04 04:35:47 --> Final output sent to browser
DEBUG - 2011-08-04 04:35:47 --> Total execution time: 0.0539
DEBUG - 2011-08-04 04:35:51 --> Config Class Initialized
DEBUG - 2011-08-04 04:35:51 --> Hooks Class Initialized
DEBUG - 2011-08-04 04:35:51 --> Utf8 Class Initialized
DEBUG - 2011-08-04 04:35:51 --> UTF-8 Support Enabled
DEBUG - 2011-08-04 04:35:51 --> URI Class Initialized
DEBUG - 2011-08-04 04:35:51 --> Router Class Initialized
DEBUG - 2011-08-04 04:35:51 --> Output Class Initialized
DEBUG - 2011-08-04 04:35:51 --> Input Class Initialized
DEBUG - 2011-08-04 04:35:51 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-04 04:35:51 --> Language Class Initialized
DEBUG - 2011-08-04 04:35:51 --> Loader Class Initialized
DEBUG - 2011-08-04 04:35:51 --> Controller Class Initialized
DEBUG - 2011-08-04 04:35:51 --> Model Class Initialized
DEBUG - 2011-08-04 04:35:51 --> Model Class Initialized
DEBUG - 2011-08-04 04:35:51 --> Model Class Initialized
DEBUG - 2011-08-04 04:35:51 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-04 04:35:51 --> Database Driver Class Initialized
DEBUG - 2011-08-04 04:35:53 --> Config Class Initialized
DEBUG - 2011-08-04 04:35:53 --> Hooks Class Initialized
DEBUG - 2011-08-04 04:35:53 --> Utf8 Class Initialized
DEBUG - 2011-08-04 04:35:53 --> UTF-8 Support Enabled
DEBUG - 2011-08-04 04:35:53 --> URI Class Initialized
DEBUG - 2011-08-04 04:35:53 --> Router Class Initialized
DEBUG - 2011-08-04 04:35:53 --> Output Class Initialized
DEBUG - 2011-08-04 04:35:53 --> Input Class Initialized
DEBUG - 2011-08-04 04:35:53 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-04 04:35:53 --> Language Class Initialized
DEBUG - 2011-08-04 04:35:53 --> Loader Class Initialized
DEBUG - 2011-08-04 04:35:53 --> Controller Class Initialized
DEBUG - 2011-08-04 04:35:53 --> Model Class Initialized
DEBUG - 2011-08-04 04:35:53 --> Model Class Initialized
DEBUG - 2011-08-04 04:35:53 --> Model Class Initialized
DEBUG - 2011-08-04 04:35:53 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-04 04:35:53 --> Database Driver Class Initialized
DEBUG - 2011-08-04 04:35:53 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-04 04:35:53 --> Helper loaded: url_helper
DEBUG - 2011-08-04 04:35:53 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-04 04:35:53 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-04 04:35:53 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-04 04:35:53 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-04 04:35:53 --> Final output sent to browser
DEBUG - 2011-08-04 04:35:53 --> Total execution time: 0.1420
DEBUG - 2011-08-04 04:35:53 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-04 04:35:53 --> Helper loaded: url_helper
DEBUG - 2011-08-04 04:35:53 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-04 04:35:53 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-04 04:35:53 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-04 04:35:53 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-04 04:35:53 --> Final output sent to browser
DEBUG - 2011-08-04 04:35:53 --> Total execution time: 1.6885
DEBUG - 2011-08-04 04:35:56 --> Config Class Initialized
DEBUG - 2011-08-04 04:35:56 --> Hooks Class Initialized
DEBUG - 2011-08-04 04:35:56 --> Utf8 Class Initialized
DEBUG - 2011-08-04 04:35:56 --> UTF-8 Support Enabled
DEBUG - 2011-08-04 04:35:56 --> URI Class Initialized
DEBUG - 2011-08-04 04:35:56 --> Router Class Initialized
DEBUG - 2011-08-04 04:35:56 --> Output Class Initialized
DEBUG - 2011-08-04 04:35:56 --> Input Class Initialized
DEBUG - 2011-08-04 04:35:56 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-04 04:35:56 --> Language Class Initialized
DEBUG - 2011-08-04 04:35:56 --> Loader Class Initialized
DEBUG - 2011-08-04 04:35:56 --> Controller Class Initialized
DEBUG - 2011-08-04 04:35:56 --> Model Class Initialized
DEBUG - 2011-08-04 04:35:56 --> Model Class Initialized
DEBUG - 2011-08-04 04:35:56 --> Model Class Initialized
DEBUG - 2011-08-04 04:35:56 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-04 04:35:56 --> Database Driver Class Initialized
DEBUG - 2011-08-04 04:35:56 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-04 04:35:56 --> Helper loaded: url_helper
DEBUG - 2011-08-04 04:35:56 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-04 04:35:56 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-04 04:35:56 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-04 04:35:56 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-04 04:35:56 --> Final output sent to browser
DEBUG - 2011-08-04 04:35:56 --> Total execution time: 0.0416
DEBUG - 2011-08-04 04:36:05 --> Config Class Initialized
DEBUG - 2011-08-04 04:36:05 --> Hooks Class Initialized
DEBUG - 2011-08-04 04:36:05 --> Utf8 Class Initialized
DEBUG - 2011-08-04 04:36:05 --> UTF-8 Support Enabled
DEBUG - 2011-08-04 04:36:05 --> URI Class Initialized
DEBUG - 2011-08-04 04:36:05 --> Router Class Initialized
DEBUG - 2011-08-04 04:36:05 --> Output Class Initialized
DEBUG - 2011-08-04 04:36:05 --> Input Class Initialized
DEBUG - 2011-08-04 04:36:05 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-04 04:36:05 --> Language Class Initialized
DEBUG - 2011-08-04 04:36:05 --> Loader Class Initialized
DEBUG - 2011-08-04 04:36:05 --> Controller Class Initialized
DEBUG - 2011-08-04 04:36:05 --> Model Class Initialized
DEBUG - 2011-08-04 04:36:05 --> Model Class Initialized
DEBUG - 2011-08-04 04:36:05 --> Model Class Initialized
DEBUG - 2011-08-04 04:36:05 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-04 04:36:05 --> Database Driver Class Initialized
DEBUG - 2011-08-04 04:36:05 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-04 04:36:05 --> Helper loaded: url_helper
DEBUG - 2011-08-04 04:36:05 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-04 04:36:05 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-04 04:36:05 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-04 04:36:05 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-04 04:36:05 --> Final output sent to browser
DEBUG - 2011-08-04 04:36:05 --> Total execution time: 0.2010
DEBUG - 2011-08-04 04:36:07 --> Config Class Initialized
DEBUG - 2011-08-04 04:36:07 --> Hooks Class Initialized
DEBUG - 2011-08-04 04:36:07 --> Utf8 Class Initialized
DEBUG - 2011-08-04 04:36:07 --> UTF-8 Support Enabled
DEBUG - 2011-08-04 04:36:07 --> URI Class Initialized
DEBUG - 2011-08-04 04:36:07 --> Router Class Initialized
DEBUG - 2011-08-04 04:36:07 --> Output Class Initialized
DEBUG - 2011-08-04 04:36:07 --> Input Class Initialized
DEBUG - 2011-08-04 04:36:07 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-04 04:36:07 --> Language Class Initialized
DEBUG - 2011-08-04 04:36:07 --> Loader Class Initialized
DEBUG - 2011-08-04 04:36:07 --> Controller Class Initialized
DEBUG - 2011-08-04 04:36:07 --> Model Class Initialized
DEBUG - 2011-08-04 04:36:07 --> Model Class Initialized
DEBUG - 2011-08-04 04:36:07 --> Model Class Initialized
DEBUG - 2011-08-04 04:36:07 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-04 04:36:07 --> Database Driver Class Initialized
DEBUG - 2011-08-04 04:36:07 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-04 04:36:07 --> Helper loaded: url_helper
DEBUG - 2011-08-04 04:36:07 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-04 04:36:07 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-04 04:36:07 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-04 04:36:07 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-04 04:36:07 --> Final output sent to browser
DEBUG - 2011-08-04 04:36:07 --> Total execution time: 0.0441
DEBUG - 2011-08-04 04:37:38 --> Config Class Initialized
DEBUG - 2011-08-04 04:37:38 --> Hooks Class Initialized
DEBUG - 2011-08-04 04:37:38 --> Utf8 Class Initialized
DEBUG - 2011-08-04 04:37:38 --> UTF-8 Support Enabled
DEBUG - 2011-08-04 04:37:38 --> URI Class Initialized
DEBUG - 2011-08-04 04:37:38 --> Router Class Initialized
DEBUG - 2011-08-04 04:37:38 --> Output Class Initialized
DEBUG - 2011-08-04 04:37:38 --> Input Class Initialized
DEBUG - 2011-08-04 04:37:38 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-04 04:37:38 --> Language Class Initialized
DEBUG - 2011-08-04 04:37:38 --> Loader Class Initialized
DEBUG - 2011-08-04 04:37:38 --> Controller Class Initialized
DEBUG - 2011-08-04 04:37:38 --> Model Class Initialized
DEBUG - 2011-08-04 04:37:38 --> Model Class Initialized
DEBUG - 2011-08-04 04:37:38 --> Model Class Initialized
DEBUG - 2011-08-04 04:37:38 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-04 04:37:38 --> Database Driver Class Initialized
DEBUG - 2011-08-04 04:37:38 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-04 04:37:38 --> Helper loaded: url_helper
DEBUG - 2011-08-04 04:37:38 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-04 04:37:38 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-04 04:37:38 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-04 04:37:38 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-04 04:37:38 --> Final output sent to browser
DEBUG - 2011-08-04 04:37:38 --> Total execution time: 0.0426
DEBUG - 2011-08-04 04:38:10 --> Config Class Initialized
DEBUG - 2011-08-04 04:38:10 --> Hooks Class Initialized
DEBUG - 2011-08-04 04:38:10 --> Utf8 Class Initialized
DEBUG - 2011-08-04 04:38:10 --> UTF-8 Support Enabled
DEBUG - 2011-08-04 04:38:10 --> URI Class Initialized
DEBUG - 2011-08-04 04:38:10 --> Router Class Initialized
DEBUG - 2011-08-04 04:38:10 --> Output Class Initialized
DEBUG - 2011-08-04 04:38:10 --> Input Class Initialized
DEBUG - 2011-08-04 04:38:10 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-04 04:38:10 --> Language Class Initialized
DEBUG - 2011-08-04 04:38:10 --> Loader Class Initialized
DEBUG - 2011-08-04 04:38:10 --> Controller Class Initialized
DEBUG - 2011-08-04 04:38:10 --> Model Class Initialized
DEBUG - 2011-08-04 04:38:10 --> Model Class Initialized
DEBUG - 2011-08-04 04:38:10 --> Model Class Initialized
DEBUG - 2011-08-04 04:38:10 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-04 04:38:10 --> Database Driver Class Initialized
DEBUG - 2011-08-04 04:38:10 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-04 04:38:10 --> Helper loaded: url_helper
DEBUG - 2011-08-04 04:38:10 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-04 04:38:10 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-04 04:38:10 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-04 04:38:10 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-04 04:38:10 --> Final output sent to browser
DEBUG - 2011-08-04 04:38:10 --> Total execution time: 0.0446
DEBUG - 2011-08-04 04:38:22 --> Config Class Initialized
DEBUG - 2011-08-04 04:38:22 --> Hooks Class Initialized
DEBUG - 2011-08-04 04:38:22 --> Utf8 Class Initialized
DEBUG - 2011-08-04 04:38:22 --> UTF-8 Support Enabled
DEBUG - 2011-08-04 04:38:22 --> URI Class Initialized
DEBUG - 2011-08-04 04:38:22 --> Router Class Initialized
DEBUG - 2011-08-04 04:38:22 --> Output Class Initialized
DEBUG - 2011-08-04 04:38:22 --> Input Class Initialized
DEBUG - 2011-08-04 04:38:22 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-04 04:38:22 --> Language Class Initialized
DEBUG - 2011-08-04 04:38:22 --> Loader Class Initialized
DEBUG - 2011-08-04 04:38:22 --> Controller Class Initialized
DEBUG - 2011-08-04 04:38:22 --> Model Class Initialized
DEBUG - 2011-08-04 04:38:22 --> Model Class Initialized
DEBUG - 2011-08-04 04:38:22 --> Model Class Initialized
DEBUG - 2011-08-04 04:38:22 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-04 04:38:22 --> Database Driver Class Initialized
DEBUG - 2011-08-04 04:38:22 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-04 04:38:22 --> Helper loaded: url_helper
DEBUG - 2011-08-04 04:38:22 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-04 04:38:22 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-04 04:38:22 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-04 04:38:22 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-04 04:38:22 --> Final output sent to browser
DEBUG - 2011-08-04 04:38:22 --> Total execution time: 0.0434
DEBUG - 2011-08-04 04:38:33 --> Config Class Initialized
DEBUG - 2011-08-04 04:38:33 --> Hooks Class Initialized
DEBUG - 2011-08-04 04:38:33 --> Utf8 Class Initialized
DEBUG - 2011-08-04 04:38:33 --> UTF-8 Support Enabled
DEBUG - 2011-08-04 04:38:33 --> URI Class Initialized
DEBUG - 2011-08-04 04:38:33 --> Router Class Initialized
DEBUG - 2011-08-04 04:38:33 --> Output Class Initialized
DEBUG - 2011-08-04 04:38:33 --> Input Class Initialized
DEBUG - 2011-08-04 04:38:33 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-04 04:38:33 --> Language Class Initialized
DEBUG - 2011-08-04 04:38:33 --> Loader Class Initialized
DEBUG - 2011-08-04 04:38:33 --> Controller Class Initialized
DEBUG - 2011-08-04 04:38:33 --> Model Class Initialized
DEBUG - 2011-08-04 04:38:33 --> Model Class Initialized
DEBUG - 2011-08-04 04:38:33 --> Model Class Initialized
DEBUG - 2011-08-04 04:38:33 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-04 04:38:33 --> Database Driver Class Initialized
DEBUG - 2011-08-04 04:38:33 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-04 04:38:33 --> Helper loaded: url_helper
DEBUG - 2011-08-04 04:38:33 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-04 04:38:33 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-04 04:38:33 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-04 04:38:33 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-04 04:38:33 --> Final output sent to browser
DEBUG - 2011-08-04 04:38:33 --> Total execution time: 0.2322
DEBUG - 2011-08-04 04:51:48 --> Config Class Initialized
DEBUG - 2011-08-04 04:51:48 --> Hooks Class Initialized
DEBUG - 2011-08-04 04:51:48 --> Utf8 Class Initialized
DEBUG - 2011-08-04 04:51:48 --> UTF-8 Support Enabled
DEBUG - 2011-08-04 04:51:48 --> URI Class Initialized
DEBUG - 2011-08-04 04:51:48 --> Router Class Initialized
DEBUG - 2011-08-04 04:51:48 --> Output Class Initialized
DEBUG - 2011-08-04 04:51:48 --> Input Class Initialized
DEBUG - 2011-08-04 04:51:48 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-04 04:51:48 --> Language Class Initialized
DEBUG - 2011-08-04 04:51:48 --> Loader Class Initialized
DEBUG - 2011-08-04 04:51:48 --> Controller Class Initialized
DEBUG - 2011-08-04 04:51:48 --> Model Class Initialized
DEBUG - 2011-08-04 04:51:48 --> Model Class Initialized
DEBUG - 2011-08-04 04:51:48 --> Model Class Initialized
DEBUG - 2011-08-04 04:51:48 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-04 04:51:48 --> Database Driver Class Initialized
DEBUG - 2011-08-04 04:51:49 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-04 04:51:49 --> Helper loaded: url_helper
DEBUG - 2011-08-04 04:51:49 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-04 04:51:49 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-04 04:51:49 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-04 04:51:49 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-04 04:51:49 --> Final output sent to browser
DEBUG - 2011-08-04 04:51:49 --> Total execution time: 0.2231
DEBUG - 2011-08-04 04:51:51 --> Config Class Initialized
DEBUG - 2011-08-04 04:51:51 --> Hooks Class Initialized
DEBUG - 2011-08-04 04:51:51 --> Utf8 Class Initialized
DEBUG - 2011-08-04 04:51:51 --> UTF-8 Support Enabled
DEBUG - 2011-08-04 04:51:51 --> URI Class Initialized
DEBUG - 2011-08-04 04:51:51 --> Router Class Initialized
ERROR - 2011-08-04 04:51:51 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-08-04 04:51:51 --> Config Class Initialized
DEBUG - 2011-08-04 04:51:51 --> Hooks Class Initialized
DEBUG - 2011-08-04 04:51:51 --> Utf8 Class Initialized
DEBUG - 2011-08-04 04:51:51 --> UTF-8 Support Enabled
DEBUG - 2011-08-04 04:51:51 --> URI Class Initialized
DEBUG - 2011-08-04 04:51:51 --> Router Class Initialized
DEBUG - 2011-08-04 04:51:51 --> Output Class Initialized
DEBUG - 2011-08-04 04:51:51 --> Input Class Initialized
DEBUG - 2011-08-04 04:51:51 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-04 04:51:51 --> Language Class Initialized
DEBUG - 2011-08-04 04:51:51 --> Loader Class Initialized
DEBUG - 2011-08-04 04:51:51 --> Controller Class Initialized
DEBUG - 2011-08-04 04:51:51 --> Model Class Initialized
DEBUG - 2011-08-04 04:51:51 --> Model Class Initialized
DEBUG - 2011-08-04 04:51:51 --> Model Class Initialized
DEBUG - 2011-08-04 04:51:51 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-04 04:51:51 --> Database Driver Class Initialized
DEBUG - 2011-08-04 04:51:51 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-04 04:51:51 --> Helper loaded: url_helper
DEBUG - 2011-08-04 04:51:51 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-04 04:51:51 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-04 04:51:51 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-04 04:51:51 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-04 04:51:51 --> Final output sent to browser
DEBUG - 2011-08-04 04:51:51 --> Total execution time: 0.0730
DEBUG - 2011-08-04 04:52:05 --> Config Class Initialized
DEBUG - 2011-08-04 04:52:05 --> Hooks Class Initialized
DEBUG - 2011-08-04 04:52:05 --> Utf8 Class Initialized
DEBUG - 2011-08-04 04:52:05 --> UTF-8 Support Enabled
DEBUG - 2011-08-04 04:52:05 --> URI Class Initialized
DEBUG - 2011-08-04 04:52:05 --> Router Class Initialized
DEBUG - 2011-08-04 04:52:05 --> Output Class Initialized
DEBUG - 2011-08-04 04:52:05 --> Input Class Initialized
DEBUG - 2011-08-04 04:52:05 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-04 04:52:05 --> Language Class Initialized
DEBUG - 2011-08-04 04:52:05 --> Loader Class Initialized
DEBUG - 2011-08-04 04:52:05 --> Controller Class Initialized
DEBUG - 2011-08-04 04:52:05 --> Model Class Initialized
DEBUG - 2011-08-04 04:52:05 --> Model Class Initialized
DEBUG - 2011-08-04 04:52:05 --> Model Class Initialized
DEBUG - 2011-08-04 04:52:05 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-04 04:52:05 --> Database Driver Class Initialized
DEBUG - 2011-08-04 04:52:06 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-04 04:52:06 --> Helper loaded: url_helper
DEBUG - 2011-08-04 04:52:06 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-04 04:52:06 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-04 04:52:06 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-04 04:52:06 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-04 04:52:06 --> Final output sent to browser
DEBUG - 2011-08-04 04:52:06 --> Total execution time: 0.0502
DEBUG - 2011-08-04 04:57:35 --> Config Class Initialized
DEBUG - 2011-08-04 04:57:35 --> Hooks Class Initialized
DEBUG - 2011-08-04 04:57:35 --> Utf8 Class Initialized
DEBUG - 2011-08-04 04:57:35 --> UTF-8 Support Enabled
DEBUG - 2011-08-04 04:57:35 --> URI Class Initialized
DEBUG - 2011-08-04 04:57:35 --> Router Class Initialized
DEBUG - 2011-08-04 04:57:35 --> Output Class Initialized
DEBUG - 2011-08-04 04:57:35 --> Input Class Initialized
DEBUG - 2011-08-04 04:57:35 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-04 04:57:35 --> Language Class Initialized
DEBUG - 2011-08-04 04:57:35 --> Loader Class Initialized
DEBUG - 2011-08-04 04:57:35 --> Controller Class Initialized
DEBUG - 2011-08-04 04:57:35 --> Model Class Initialized
DEBUG - 2011-08-04 04:57:35 --> Model Class Initialized
DEBUG - 2011-08-04 04:57:35 --> Model Class Initialized
DEBUG - 2011-08-04 04:57:35 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-04 04:57:35 --> Database Driver Class Initialized
DEBUG - 2011-08-04 04:57:36 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-04 04:57:36 --> Helper loaded: url_helper
DEBUG - 2011-08-04 04:57:36 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-04 04:57:36 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-04 04:57:36 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-04 04:57:36 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-04 04:57:36 --> Final output sent to browser
DEBUG - 2011-08-04 04:57:36 --> Total execution time: 0.2165
DEBUG - 2011-08-04 04:57:39 --> Config Class Initialized
DEBUG - 2011-08-04 04:57:39 --> Hooks Class Initialized
DEBUG - 2011-08-04 04:57:39 --> Utf8 Class Initialized
DEBUG - 2011-08-04 04:57:39 --> UTF-8 Support Enabled
DEBUG - 2011-08-04 04:57:39 --> URI Class Initialized
DEBUG - 2011-08-04 04:57:39 --> Router Class Initialized
ERROR - 2011-08-04 04:57:39 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-04 04:58:42 --> Config Class Initialized
DEBUG - 2011-08-04 04:58:42 --> Hooks Class Initialized
DEBUG - 2011-08-04 04:58:42 --> Utf8 Class Initialized
DEBUG - 2011-08-04 04:58:42 --> UTF-8 Support Enabled
DEBUG - 2011-08-04 04:58:42 --> URI Class Initialized
DEBUG - 2011-08-04 04:58:42 --> Router Class Initialized
DEBUG - 2011-08-04 04:58:42 --> Output Class Initialized
DEBUG - 2011-08-04 04:58:42 --> Input Class Initialized
DEBUG - 2011-08-04 04:58:42 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-04 04:58:42 --> Language Class Initialized
DEBUG - 2011-08-04 04:58:42 --> Loader Class Initialized
DEBUG - 2011-08-04 04:58:42 --> Controller Class Initialized
ERROR - 2011-08-04 04:58:42 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-04 04:58:42 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-04 04:58:42 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-04 04:58:42 --> Model Class Initialized
DEBUG - 2011-08-04 04:58:42 --> Model Class Initialized
DEBUG - 2011-08-04 04:58:42 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-04 04:58:42 --> Database Driver Class Initialized
DEBUG - 2011-08-04 04:58:42 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-04 04:58:42 --> Helper loaded: url_helper
DEBUG - 2011-08-04 04:58:42 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-04 04:58:42 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-04 04:58:42 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-04 04:58:42 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-04 04:58:42 --> Final output sent to browser
DEBUG - 2011-08-04 04:58:42 --> Total execution time: 0.0855
DEBUG - 2011-08-04 04:58:43 --> Config Class Initialized
DEBUG - 2011-08-04 04:58:43 --> Hooks Class Initialized
DEBUG - 2011-08-04 04:58:43 --> Utf8 Class Initialized
DEBUG - 2011-08-04 04:58:43 --> UTF-8 Support Enabled
DEBUG - 2011-08-04 04:58:43 --> URI Class Initialized
DEBUG - 2011-08-04 04:58:43 --> Router Class Initialized
DEBUG - 2011-08-04 04:58:43 --> Output Class Initialized
DEBUG - 2011-08-04 04:58:43 --> Input Class Initialized
DEBUG - 2011-08-04 04:58:43 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-04 04:58:43 --> Language Class Initialized
DEBUG - 2011-08-04 04:58:43 --> Loader Class Initialized
DEBUG - 2011-08-04 04:58:43 --> Controller Class Initialized
DEBUG - 2011-08-04 04:58:43 --> Model Class Initialized
DEBUG - 2011-08-04 04:58:43 --> Model Class Initialized
DEBUG - 2011-08-04 04:58:43 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-04 04:58:43 --> Database Driver Class Initialized
DEBUG - 2011-08-04 04:58:44 --> Final output sent to browser
DEBUG - 2011-08-04 04:58:44 --> Total execution time: 0.6137
DEBUG - 2011-08-04 04:58:46 --> Config Class Initialized
DEBUG - 2011-08-04 04:58:46 --> Hooks Class Initialized
DEBUG - 2011-08-04 04:58:46 --> Utf8 Class Initialized
DEBUG - 2011-08-04 04:58:46 --> UTF-8 Support Enabled
DEBUG - 2011-08-04 04:58:46 --> URI Class Initialized
DEBUG - 2011-08-04 04:58:46 --> Router Class Initialized
ERROR - 2011-08-04 04:58:46 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-04 06:18:13 --> Config Class Initialized
DEBUG - 2011-08-04 06:18:13 --> Hooks Class Initialized
DEBUG - 2011-08-04 06:18:13 --> Utf8 Class Initialized
DEBUG - 2011-08-04 06:18:13 --> UTF-8 Support Enabled
DEBUG - 2011-08-04 06:18:13 --> URI Class Initialized
DEBUG - 2011-08-04 06:18:13 --> Router Class Initialized
DEBUG - 2011-08-04 06:18:13 --> Output Class Initialized
DEBUG - 2011-08-04 06:18:13 --> Input Class Initialized
DEBUG - 2011-08-04 06:18:13 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-04 06:18:13 --> Language Class Initialized
DEBUG - 2011-08-04 06:18:13 --> Loader Class Initialized
DEBUG - 2011-08-04 06:18:13 --> Controller Class Initialized
ERROR - 2011-08-04 06:18:13 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-04 06:18:13 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-04 06:18:13 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-04 06:18:13 --> Model Class Initialized
DEBUG - 2011-08-04 06:18:13 --> Model Class Initialized
DEBUG - 2011-08-04 06:18:13 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-04 06:18:13 --> Database Driver Class Initialized
DEBUG - 2011-08-04 06:18:13 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-04 06:18:13 --> Helper loaded: url_helper
DEBUG - 2011-08-04 06:18:13 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-04 06:18:13 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-04 06:18:13 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-04 06:18:13 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-04 06:18:13 --> Final output sent to browser
DEBUG - 2011-08-04 06:18:13 --> Total execution time: 0.3533
DEBUG - 2011-08-04 06:18:14 --> Config Class Initialized
DEBUG - 2011-08-04 06:18:14 --> Hooks Class Initialized
DEBUG - 2011-08-04 06:18:14 --> Utf8 Class Initialized
DEBUG - 2011-08-04 06:18:14 --> UTF-8 Support Enabled
DEBUG - 2011-08-04 06:18:14 --> URI Class Initialized
DEBUG - 2011-08-04 06:18:14 --> Router Class Initialized
DEBUG - 2011-08-04 06:18:14 --> Output Class Initialized
DEBUG - 2011-08-04 06:18:14 --> Input Class Initialized
DEBUG - 2011-08-04 06:18:14 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-04 06:18:14 --> Language Class Initialized
DEBUG - 2011-08-04 06:18:14 --> Loader Class Initialized
DEBUG - 2011-08-04 06:18:14 --> Controller Class Initialized
DEBUG - 2011-08-04 06:18:14 --> Model Class Initialized
DEBUG - 2011-08-04 06:18:14 --> Model Class Initialized
DEBUG - 2011-08-04 06:18:14 --> Model Class Initialized
DEBUG - 2011-08-04 06:18:14 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-04 06:18:14 --> Database Driver Class Initialized
DEBUG - 2011-08-04 06:18:14 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-04 06:18:14 --> Helper loaded: url_helper
DEBUG - 2011-08-04 06:18:14 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-04 06:18:14 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-04 06:18:14 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-04 06:18:14 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-04 06:18:14 --> Final output sent to browser
DEBUG - 2011-08-04 06:18:14 --> Total execution time: 0.3484
DEBUG - 2011-08-04 06:18:15 --> Config Class Initialized
DEBUG - 2011-08-04 06:18:15 --> Hooks Class Initialized
DEBUG - 2011-08-04 06:18:15 --> Utf8 Class Initialized
DEBUG - 2011-08-04 06:18:15 --> UTF-8 Support Enabled
DEBUG - 2011-08-04 06:18:15 --> URI Class Initialized
DEBUG - 2011-08-04 06:18:15 --> Router Class Initialized
DEBUG - 2011-08-04 06:18:15 --> Output Class Initialized
DEBUG - 2011-08-04 06:18:15 --> Input Class Initialized
DEBUG - 2011-08-04 06:18:15 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-04 06:18:15 --> Language Class Initialized
DEBUG - 2011-08-04 06:18:15 --> Loader Class Initialized
DEBUG - 2011-08-04 06:18:15 --> Controller Class Initialized
DEBUG - 2011-08-04 06:18:15 --> Model Class Initialized
DEBUG - 2011-08-04 06:18:15 --> Model Class Initialized
DEBUG - 2011-08-04 06:18:15 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-04 06:18:15 --> Database Driver Class Initialized
DEBUG - 2011-08-04 06:18:16 --> Final output sent to browser
DEBUG - 2011-08-04 06:18:16 --> Total execution time: 0.9115
DEBUG - 2011-08-04 06:18:18 --> Config Class Initialized
DEBUG - 2011-08-04 06:18:18 --> Hooks Class Initialized
DEBUG - 2011-08-04 06:18:18 --> Utf8 Class Initialized
DEBUG - 2011-08-04 06:18:18 --> UTF-8 Support Enabled
DEBUG - 2011-08-04 06:18:18 --> URI Class Initialized
DEBUG - 2011-08-04 06:18:18 --> Router Class Initialized
ERROR - 2011-08-04 06:18:18 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-04 06:18:19 --> Config Class Initialized
DEBUG - 2011-08-04 06:18:19 --> Hooks Class Initialized
DEBUG - 2011-08-04 06:18:19 --> Utf8 Class Initialized
DEBUG - 2011-08-04 06:18:19 --> UTF-8 Support Enabled
DEBUG - 2011-08-04 06:18:19 --> URI Class Initialized
DEBUG - 2011-08-04 06:18:19 --> Router Class Initialized
ERROR - 2011-08-04 06:18:19 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-04 06:18:23 --> Config Class Initialized
DEBUG - 2011-08-04 06:18:23 --> Hooks Class Initialized
DEBUG - 2011-08-04 06:18:23 --> Utf8 Class Initialized
DEBUG - 2011-08-04 06:18:23 --> UTF-8 Support Enabled
DEBUG - 2011-08-04 06:18:23 --> URI Class Initialized
DEBUG - 2011-08-04 06:18:23 --> Router Class Initialized
DEBUG - 2011-08-04 06:18:23 --> Output Class Initialized
DEBUG - 2011-08-04 06:18:23 --> Input Class Initialized
DEBUG - 2011-08-04 06:18:23 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-04 06:18:23 --> Language Class Initialized
DEBUG - 2011-08-04 06:18:23 --> Loader Class Initialized
DEBUG - 2011-08-04 06:18:23 --> Controller Class Initialized
ERROR - 2011-08-04 06:18:23 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-04 06:18:23 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-04 06:18:23 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-04 06:18:23 --> Model Class Initialized
DEBUG - 2011-08-04 06:18:23 --> Model Class Initialized
DEBUG - 2011-08-04 06:18:23 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-04 06:18:23 --> Database Driver Class Initialized
DEBUG - 2011-08-04 06:18:23 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-04 06:18:23 --> Helper loaded: url_helper
DEBUG - 2011-08-04 06:18:23 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-04 06:18:23 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-04 06:18:23 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-04 06:18:23 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-04 06:18:23 --> Final output sent to browser
DEBUG - 2011-08-04 06:18:23 --> Total execution time: 0.0347
DEBUG - 2011-08-04 06:18:26 --> Config Class Initialized
DEBUG - 2011-08-04 06:18:26 --> Hooks Class Initialized
DEBUG - 2011-08-04 06:18:26 --> Utf8 Class Initialized
DEBUG - 2011-08-04 06:18:26 --> UTF-8 Support Enabled
DEBUG - 2011-08-04 06:18:26 --> URI Class Initialized
DEBUG - 2011-08-04 06:18:26 --> Router Class Initialized
DEBUG - 2011-08-04 06:18:26 --> Output Class Initialized
DEBUG - 2011-08-04 06:18:26 --> Input Class Initialized
DEBUG - 2011-08-04 06:18:26 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-04 06:18:26 --> Language Class Initialized
DEBUG - 2011-08-04 06:18:26 --> Loader Class Initialized
DEBUG - 2011-08-04 06:18:26 --> Controller Class Initialized
DEBUG - 2011-08-04 06:18:26 --> Model Class Initialized
DEBUG - 2011-08-04 06:18:26 --> Model Class Initialized
DEBUG - 2011-08-04 06:18:26 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-04 06:18:26 --> Database Driver Class Initialized
DEBUG - 2011-08-04 06:18:26 --> Final output sent to browser
DEBUG - 2011-08-04 06:18:26 --> Total execution time: 0.6117
DEBUG - 2011-08-04 06:18:29 --> Config Class Initialized
DEBUG - 2011-08-04 06:18:29 --> Hooks Class Initialized
DEBUG - 2011-08-04 06:18:29 --> Utf8 Class Initialized
DEBUG - 2011-08-04 06:18:29 --> UTF-8 Support Enabled
DEBUG - 2011-08-04 06:18:29 --> URI Class Initialized
DEBUG - 2011-08-04 06:18:29 --> Router Class Initialized
ERROR - 2011-08-04 06:18:29 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-04 06:18:59 --> Config Class Initialized
DEBUG - 2011-08-04 06:18:59 --> Hooks Class Initialized
DEBUG - 2011-08-04 06:18:59 --> Utf8 Class Initialized
DEBUG - 2011-08-04 06:18:59 --> UTF-8 Support Enabled
DEBUG - 2011-08-04 06:18:59 --> URI Class Initialized
DEBUG - 2011-08-04 06:18:59 --> Router Class Initialized
DEBUG - 2011-08-04 06:18:59 --> Output Class Initialized
DEBUG - 2011-08-04 06:18:59 --> Input Class Initialized
DEBUG - 2011-08-04 06:18:59 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-04 06:18:59 --> Language Class Initialized
DEBUG - 2011-08-04 06:18:59 --> Loader Class Initialized
DEBUG - 2011-08-04 06:18:59 --> Controller Class Initialized
DEBUG - 2011-08-04 06:18:59 --> Model Class Initialized
DEBUG - 2011-08-04 06:18:59 --> Model Class Initialized
DEBUG - 2011-08-04 06:18:59 --> Model Class Initialized
DEBUG - 2011-08-04 06:18:59 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-04 06:18:59 --> Database Driver Class Initialized
DEBUG - 2011-08-04 06:18:59 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-04 06:18:59 --> Helper loaded: url_helper
DEBUG - 2011-08-04 06:18:59 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-04 06:18:59 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-04 06:18:59 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-04 06:18:59 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-04 06:18:59 --> Final output sent to browser
DEBUG - 2011-08-04 06:18:59 --> Total execution time: 0.1895
DEBUG - 2011-08-04 06:19:02 --> Config Class Initialized
DEBUG - 2011-08-04 06:19:02 --> Hooks Class Initialized
DEBUG - 2011-08-04 06:19:02 --> Utf8 Class Initialized
DEBUG - 2011-08-04 06:19:02 --> UTF-8 Support Enabled
DEBUG - 2011-08-04 06:19:02 --> URI Class Initialized
DEBUG - 2011-08-04 06:19:02 --> Router Class Initialized
ERROR - 2011-08-04 06:19:02 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-04 06:19:05 --> Config Class Initialized
DEBUG - 2011-08-04 06:19:05 --> Hooks Class Initialized
DEBUG - 2011-08-04 06:19:05 --> Utf8 Class Initialized
DEBUG - 2011-08-04 06:19:05 --> UTF-8 Support Enabled
DEBUG - 2011-08-04 06:19:05 --> URI Class Initialized
DEBUG - 2011-08-04 06:19:05 --> Router Class Initialized
DEBUG - 2011-08-04 06:19:05 --> Output Class Initialized
DEBUG - 2011-08-04 06:19:05 --> Input Class Initialized
DEBUG - 2011-08-04 06:19:05 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-04 06:19:05 --> Language Class Initialized
DEBUG - 2011-08-04 06:19:05 --> Loader Class Initialized
DEBUG - 2011-08-04 06:19:05 --> Controller Class Initialized
DEBUG - 2011-08-04 06:19:05 --> Model Class Initialized
DEBUG - 2011-08-04 06:19:05 --> Model Class Initialized
DEBUG - 2011-08-04 06:19:05 --> Model Class Initialized
DEBUG - 2011-08-04 06:19:05 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-04 06:19:05 --> Database Driver Class Initialized
DEBUG - 2011-08-04 06:19:05 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-04 06:19:05 --> Helper loaded: url_helper
DEBUG - 2011-08-04 06:19:05 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-04 06:19:05 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-04 06:19:05 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-04 06:19:05 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-04 06:19:05 --> Final output sent to browser
DEBUG - 2011-08-04 06:19:05 --> Total execution time: 0.0493
DEBUG - 2011-08-04 06:57:39 --> Config Class Initialized
DEBUG - 2011-08-04 06:57:39 --> Hooks Class Initialized
DEBUG - 2011-08-04 06:57:39 --> Utf8 Class Initialized
DEBUG - 2011-08-04 06:57:39 --> UTF-8 Support Enabled
DEBUG - 2011-08-04 06:57:39 --> URI Class Initialized
DEBUG - 2011-08-04 06:57:39 --> Router Class Initialized
ERROR - 2011-08-04 06:57:39 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-08-04 08:40:17 --> Config Class Initialized
DEBUG - 2011-08-04 08:40:17 --> Hooks Class Initialized
DEBUG - 2011-08-04 08:40:17 --> Utf8 Class Initialized
DEBUG - 2011-08-04 08:40:17 --> UTF-8 Support Enabled
DEBUG - 2011-08-04 08:40:17 --> URI Class Initialized
DEBUG - 2011-08-04 08:40:17 --> Router Class Initialized
DEBUG - 2011-08-04 08:40:17 --> No URI present. Default controller set.
DEBUG - 2011-08-04 08:40:17 --> Output Class Initialized
DEBUG - 2011-08-04 08:40:17 --> Input Class Initialized
DEBUG - 2011-08-04 08:40:17 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-04 08:40:17 --> Language Class Initialized
DEBUG - 2011-08-04 08:40:17 --> Loader Class Initialized
DEBUG - 2011-08-04 08:40:17 --> Controller Class Initialized
DEBUG - 2011-08-04 08:40:17 --> File loaded: application/views/splash/main.php
DEBUG - 2011-08-04 08:40:17 --> Helper loaded: url_helper
DEBUG - 2011-08-04 08:40:17 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-04 08:40:17 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-04 08:40:17 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-04 08:40:17 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-04 08:40:17 --> Final output sent to browser
DEBUG - 2011-08-04 08:40:17 --> Total execution time: 0.2487
DEBUG - 2011-08-04 09:02:06 --> Config Class Initialized
DEBUG - 2011-08-04 09:02:06 --> Hooks Class Initialized
DEBUG - 2011-08-04 09:02:06 --> Utf8 Class Initialized
DEBUG - 2011-08-04 09:02:06 --> UTF-8 Support Enabled
DEBUG - 2011-08-04 09:02:06 --> URI Class Initialized
DEBUG - 2011-08-04 09:02:06 --> Router Class Initialized
DEBUG - 2011-08-04 09:02:06 --> Output Class Initialized
DEBUG - 2011-08-04 09:02:06 --> Input Class Initialized
DEBUG - 2011-08-04 09:02:06 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-04 09:02:06 --> Language Class Initialized
DEBUG - 2011-08-04 09:02:06 --> Loader Class Initialized
DEBUG - 2011-08-04 09:02:06 --> Controller Class Initialized
DEBUG - 2011-08-04 09:02:06 --> Model Class Initialized
DEBUG - 2011-08-04 09:02:06 --> Model Class Initialized
DEBUG - 2011-08-04 09:02:06 --> Model Class Initialized
DEBUG - 2011-08-04 09:02:06 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-04 09:02:06 --> Database Driver Class Initialized
DEBUG - 2011-08-04 09:02:07 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-04 09:02:07 --> Helper loaded: url_helper
DEBUG - 2011-08-04 09:02:07 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-04 09:02:07 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-04 09:02:07 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-04 09:02:07 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-04 09:02:07 --> Final output sent to browser
DEBUG - 2011-08-04 09:02:07 --> Total execution time: 0.6015
DEBUG - 2011-08-04 09:02:13 --> Config Class Initialized
DEBUG - 2011-08-04 09:02:13 --> Hooks Class Initialized
DEBUG - 2011-08-04 09:02:13 --> Utf8 Class Initialized
DEBUG - 2011-08-04 09:02:13 --> UTF-8 Support Enabled
DEBUG - 2011-08-04 09:02:13 --> URI Class Initialized
DEBUG - 2011-08-04 09:02:13 --> Router Class Initialized
ERROR - 2011-08-04 09:02:13 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-04 09:03:16 --> Config Class Initialized
DEBUG - 2011-08-04 09:03:16 --> Hooks Class Initialized
DEBUG - 2011-08-04 09:03:16 --> Utf8 Class Initialized
DEBUG - 2011-08-04 09:03:16 --> UTF-8 Support Enabled
DEBUG - 2011-08-04 09:03:16 --> URI Class Initialized
DEBUG - 2011-08-04 09:03:16 --> Router Class Initialized
DEBUG - 2011-08-04 09:03:16 --> Output Class Initialized
DEBUG - 2011-08-04 09:03:16 --> Input Class Initialized
DEBUG - 2011-08-04 09:03:16 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-04 09:03:16 --> Language Class Initialized
DEBUG - 2011-08-04 09:03:16 --> Loader Class Initialized
DEBUG - 2011-08-04 09:03:16 --> Controller Class Initialized
DEBUG - 2011-08-04 09:03:16 --> Model Class Initialized
DEBUG - 2011-08-04 09:03:16 --> Model Class Initialized
DEBUG - 2011-08-04 09:03:16 --> Model Class Initialized
DEBUG - 2011-08-04 09:03:16 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-04 09:03:16 --> Database Driver Class Initialized
DEBUG - 2011-08-04 09:03:16 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-04 09:03:16 --> Helper loaded: url_helper
DEBUG - 2011-08-04 09:03:16 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-04 09:03:16 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-04 09:03:16 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-04 09:03:16 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-04 09:03:16 --> Final output sent to browser
DEBUG - 2011-08-04 09:03:16 --> Total execution time: 0.2991
DEBUG - 2011-08-04 09:03:19 --> Config Class Initialized
DEBUG - 2011-08-04 09:03:19 --> Hooks Class Initialized
DEBUG - 2011-08-04 09:03:19 --> Utf8 Class Initialized
DEBUG - 2011-08-04 09:03:19 --> UTF-8 Support Enabled
DEBUG - 2011-08-04 09:03:19 --> URI Class Initialized
DEBUG - 2011-08-04 09:03:19 --> Router Class Initialized
DEBUG - 2011-08-04 09:03:19 --> Output Class Initialized
DEBUG - 2011-08-04 09:03:19 --> Input Class Initialized
DEBUG - 2011-08-04 09:03:19 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-04 09:03:19 --> Language Class Initialized
DEBUG - 2011-08-04 09:03:19 --> Loader Class Initialized
DEBUG - 2011-08-04 09:03:19 --> Controller Class Initialized
DEBUG - 2011-08-04 09:03:19 --> Model Class Initialized
DEBUG - 2011-08-04 09:03:19 --> Model Class Initialized
DEBUG - 2011-08-04 09:03:19 --> Model Class Initialized
DEBUG - 2011-08-04 09:03:19 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-04 09:03:19 --> Database Driver Class Initialized
DEBUG - 2011-08-04 09:03:19 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-04 09:03:19 --> Helper loaded: url_helper
DEBUG - 2011-08-04 09:03:19 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-04 09:03:19 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-04 09:03:19 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-04 09:03:19 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-04 09:03:19 --> Final output sent to browser
DEBUG - 2011-08-04 09:03:19 --> Total execution time: 0.0826
DEBUG - 2011-08-04 09:03:19 --> Config Class Initialized
DEBUG - 2011-08-04 09:03:19 --> Hooks Class Initialized
DEBUG - 2011-08-04 09:03:19 --> Utf8 Class Initialized
DEBUG - 2011-08-04 09:03:19 --> UTF-8 Support Enabled
DEBUG - 2011-08-04 09:03:19 --> URI Class Initialized
DEBUG - 2011-08-04 09:03:19 --> Router Class Initialized
ERROR - 2011-08-04 09:03:19 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-04 09:03:50 --> Config Class Initialized
DEBUG - 2011-08-04 09:03:50 --> Hooks Class Initialized
DEBUG - 2011-08-04 09:03:50 --> Utf8 Class Initialized
DEBUG - 2011-08-04 09:03:50 --> UTF-8 Support Enabled
DEBUG - 2011-08-04 09:03:50 --> URI Class Initialized
DEBUG - 2011-08-04 09:03:50 --> Router Class Initialized
DEBUG - 2011-08-04 09:03:50 --> Output Class Initialized
DEBUG - 2011-08-04 09:03:50 --> Input Class Initialized
DEBUG - 2011-08-04 09:03:50 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-04 09:03:50 --> Language Class Initialized
DEBUG - 2011-08-04 09:03:50 --> Loader Class Initialized
DEBUG - 2011-08-04 09:03:50 --> Controller Class Initialized
DEBUG - 2011-08-04 09:03:50 --> Model Class Initialized
DEBUG - 2011-08-04 09:03:50 --> Model Class Initialized
DEBUG - 2011-08-04 09:03:50 --> Model Class Initialized
DEBUG - 2011-08-04 09:03:50 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-04 09:03:50 --> Database Driver Class Initialized
DEBUG - 2011-08-04 09:03:50 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-04 09:03:50 --> Helper loaded: url_helper
DEBUG - 2011-08-04 09:03:50 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-04 09:03:50 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-04 09:03:50 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-04 09:03:50 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-04 09:03:50 --> Final output sent to browser
DEBUG - 2011-08-04 09:03:50 --> Total execution time: 0.2158
DEBUG - 2011-08-04 09:03:52 --> Config Class Initialized
DEBUG - 2011-08-04 09:03:52 --> Hooks Class Initialized
DEBUG - 2011-08-04 09:03:52 --> Utf8 Class Initialized
DEBUG - 2011-08-04 09:03:52 --> UTF-8 Support Enabled
DEBUG - 2011-08-04 09:03:52 --> URI Class Initialized
DEBUG - 2011-08-04 09:03:52 --> Router Class Initialized
DEBUG - 2011-08-04 09:03:52 --> Output Class Initialized
DEBUG - 2011-08-04 09:03:52 --> Input Class Initialized
DEBUG - 2011-08-04 09:03:52 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-04 09:03:52 --> Language Class Initialized
DEBUG - 2011-08-04 09:03:52 --> Loader Class Initialized
DEBUG - 2011-08-04 09:03:52 --> Controller Class Initialized
DEBUG - 2011-08-04 09:03:52 --> Model Class Initialized
DEBUG - 2011-08-04 09:03:52 --> Model Class Initialized
DEBUG - 2011-08-04 09:03:52 --> Model Class Initialized
DEBUG - 2011-08-04 09:03:52 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-04 09:03:52 --> Database Driver Class Initialized
DEBUG - 2011-08-04 09:03:52 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-04 09:03:52 --> Helper loaded: url_helper
DEBUG - 2011-08-04 09:03:52 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-04 09:03:52 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-04 09:03:52 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-04 09:03:52 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-04 09:03:52 --> Final output sent to browser
DEBUG - 2011-08-04 09:03:52 --> Total execution time: 0.0446
DEBUG - 2011-08-04 09:03:53 --> Config Class Initialized
DEBUG - 2011-08-04 09:03:53 --> Hooks Class Initialized
DEBUG - 2011-08-04 09:03:53 --> Utf8 Class Initialized
DEBUG - 2011-08-04 09:03:53 --> UTF-8 Support Enabled
DEBUG - 2011-08-04 09:03:53 --> URI Class Initialized
DEBUG - 2011-08-04 09:03:53 --> Router Class Initialized
ERROR - 2011-08-04 09:03:53 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-04 09:04:04 --> Config Class Initialized
DEBUG - 2011-08-04 09:04:04 --> Hooks Class Initialized
DEBUG - 2011-08-04 09:04:04 --> Utf8 Class Initialized
DEBUG - 2011-08-04 09:04:04 --> UTF-8 Support Enabled
DEBUG - 2011-08-04 09:04:04 --> URI Class Initialized
DEBUG - 2011-08-04 09:04:04 --> Router Class Initialized
DEBUG - 2011-08-04 09:04:04 --> Output Class Initialized
DEBUG - 2011-08-04 09:04:04 --> Input Class Initialized
DEBUG - 2011-08-04 09:04:04 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-04 09:04:04 --> Language Class Initialized
DEBUG - 2011-08-04 09:04:04 --> Loader Class Initialized
DEBUG - 2011-08-04 09:04:04 --> Controller Class Initialized
DEBUG - 2011-08-04 09:04:04 --> Model Class Initialized
DEBUG - 2011-08-04 09:04:04 --> Model Class Initialized
DEBUG - 2011-08-04 09:04:04 --> Model Class Initialized
DEBUG - 2011-08-04 09:04:04 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-04 09:04:04 --> Database Driver Class Initialized
DEBUG - 2011-08-04 09:04:05 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-04 09:04:05 --> Helper loaded: url_helper
DEBUG - 2011-08-04 09:04:05 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-04 09:04:05 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-04 09:04:05 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-04 09:04:05 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-04 09:04:05 --> Final output sent to browser
DEBUG - 2011-08-04 09:04:05 --> Total execution time: 0.5064
DEBUG - 2011-08-04 09:04:08 --> Config Class Initialized
DEBUG - 2011-08-04 09:04:08 --> Hooks Class Initialized
DEBUG - 2011-08-04 09:04:08 --> Utf8 Class Initialized
DEBUG - 2011-08-04 09:04:08 --> UTF-8 Support Enabled
DEBUG - 2011-08-04 09:04:08 --> URI Class Initialized
DEBUG - 2011-08-04 09:04:08 --> Router Class Initialized
ERROR - 2011-08-04 09:04:08 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-04 09:04:09 --> Config Class Initialized
DEBUG - 2011-08-04 09:04:09 --> Hooks Class Initialized
DEBUG - 2011-08-04 09:04:09 --> Utf8 Class Initialized
DEBUG - 2011-08-04 09:04:09 --> UTF-8 Support Enabled
DEBUG - 2011-08-04 09:04:09 --> URI Class Initialized
DEBUG - 2011-08-04 09:04:09 --> Router Class Initialized
DEBUG - 2011-08-04 09:04:09 --> Output Class Initialized
DEBUG - 2011-08-04 09:04:09 --> Input Class Initialized
DEBUG - 2011-08-04 09:04:09 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-04 09:04:09 --> Language Class Initialized
DEBUG - 2011-08-04 09:04:09 --> Loader Class Initialized
DEBUG - 2011-08-04 09:04:09 --> Controller Class Initialized
DEBUG - 2011-08-04 09:04:09 --> Model Class Initialized
DEBUG - 2011-08-04 09:04:09 --> Model Class Initialized
DEBUG - 2011-08-04 09:04:09 --> Model Class Initialized
DEBUG - 2011-08-04 09:04:09 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-04 09:04:09 --> Database Driver Class Initialized
DEBUG - 2011-08-04 09:04:09 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-04 09:04:09 --> Helper loaded: url_helper
DEBUG - 2011-08-04 09:04:09 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-04 09:04:09 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-04 09:04:09 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-04 09:04:09 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-04 09:04:09 --> Final output sent to browser
DEBUG - 2011-08-04 09:04:09 --> Total execution time: 0.1262
DEBUG - 2011-08-04 09:04:18 --> Config Class Initialized
DEBUG - 2011-08-04 09:04:18 --> Hooks Class Initialized
DEBUG - 2011-08-04 09:04:18 --> Utf8 Class Initialized
DEBUG - 2011-08-04 09:04:18 --> UTF-8 Support Enabled
DEBUG - 2011-08-04 09:04:18 --> URI Class Initialized
DEBUG - 2011-08-04 09:04:18 --> Router Class Initialized
DEBUG - 2011-08-04 09:04:18 --> Output Class Initialized
DEBUG - 2011-08-04 09:04:18 --> Input Class Initialized
DEBUG - 2011-08-04 09:04:18 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-04 09:04:18 --> Language Class Initialized
DEBUG - 2011-08-04 09:04:18 --> Loader Class Initialized
DEBUG - 2011-08-04 09:04:18 --> Controller Class Initialized
DEBUG - 2011-08-04 09:04:18 --> Model Class Initialized
DEBUG - 2011-08-04 09:04:18 --> Model Class Initialized
DEBUG - 2011-08-04 09:04:18 --> Model Class Initialized
DEBUG - 2011-08-04 09:04:18 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-04 09:04:18 --> Database Driver Class Initialized
DEBUG - 2011-08-04 09:04:19 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-04 09:04:19 --> Helper loaded: url_helper
DEBUG - 2011-08-04 09:04:19 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-04 09:04:19 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-04 09:04:19 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-04 09:04:19 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-04 09:04:19 --> Final output sent to browser
DEBUG - 2011-08-04 09:04:19 --> Total execution time: 0.7392
DEBUG - 2011-08-04 09:04:23 --> Config Class Initialized
DEBUG - 2011-08-04 09:04:23 --> Hooks Class Initialized
DEBUG - 2011-08-04 09:04:23 --> Utf8 Class Initialized
DEBUG - 2011-08-04 09:04:23 --> UTF-8 Support Enabled
DEBUG - 2011-08-04 09:04:23 --> URI Class Initialized
DEBUG - 2011-08-04 09:04:23 --> Router Class Initialized
DEBUG - 2011-08-04 09:04:23 --> Output Class Initialized
DEBUG - 2011-08-04 09:04:23 --> Input Class Initialized
DEBUG - 2011-08-04 09:04:23 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-04 09:04:23 --> Language Class Initialized
DEBUG - 2011-08-04 09:04:23 --> Loader Class Initialized
DEBUG - 2011-08-04 09:04:23 --> Controller Class Initialized
DEBUG - 2011-08-04 09:04:23 --> Model Class Initialized
DEBUG - 2011-08-04 09:04:23 --> Model Class Initialized
DEBUG - 2011-08-04 09:04:23 --> Model Class Initialized
DEBUG - 2011-08-04 09:04:23 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-04 09:04:23 --> Database Driver Class Initialized
DEBUG - 2011-08-04 09:04:23 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-04 09:04:23 --> Helper loaded: url_helper
DEBUG - 2011-08-04 09:04:23 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-04 09:04:23 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-04 09:04:23 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-04 09:04:23 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-04 09:04:23 --> Final output sent to browser
DEBUG - 2011-08-04 09:04:23 --> Total execution time: 0.1146
DEBUG - 2011-08-04 09:04:25 --> Config Class Initialized
DEBUG - 2011-08-04 09:04:25 --> Hooks Class Initialized
DEBUG - 2011-08-04 09:04:25 --> Utf8 Class Initialized
DEBUG - 2011-08-04 09:04:25 --> UTF-8 Support Enabled
DEBUG - 2011-08-04 09:04:25 --> URI Class Initialized
DEBUG - 2011-08-04 09:04:25 --> Router Class Initialized
ERROR - 2011-08-04 09:04:25 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-04 09:04:34 --> Config Class Initialized
DEBUG - 2011-08-04 09:04:34 --> Hooks Class Initialized
DEBUG - 2011-08-04 09:04:34 --> Utf8 Class Initialized
DEBUG - 2011-08-04 09:04:34 --> UTF-8 Support Enabled
DEBUG - 2011-08-04 09:04:34 --> URI Class Initialized
DEBUG - 2011-08-04 09:04:34 --> Router Class Initialized
DEBUG - 2011-08-04 09:04:34 --> Output Class Initialized
DEBUG - 2011-08-04 09:04:34 --> Input Class Initialized
DEBUG - 2011-08-04 09:04:34 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-04 09:04:34 --> Language Class Initialized
DEBUG - 2011-08-04 09:04:34 --> Loader Class Initialized
DEBUG - 2011-08-04 09:04:34 --> Controller Class Initialized
DEBUG - 2011-08-04 09:04:34 --> Model Class Initialized
DEBUG - 2011-08-04 09:04:34 --> Model Class Initialized
DEBUG - 2011-08-04 09:04:34 --> Model Class Initialized
DEBUG - 2011-08-04 09:04:34 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-04 09:04:34 --> Database Driver Class Initialized
DEBUG - 2011-08-04 09:04:35 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-04 09:04:35 --> Helper loaded: url_helper
DEBUG - 2011-08-04 09:04:35 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-04 09:04:35 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-04 09:04:35 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-04 09:04:35 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-04 09:04:35 --> Final output sent to browser
DEBUG - 2011-08-04 09:04:35 --> Total execution time: 0.4827
DEBUG - 2011-08-04 09:04:37 --> Config Class Initialized
DEBUG - 2011-08-04 09:04:37 --> Hooks Class Initialized
DEBUG - 2011-08-04 09:04:37 --> Utf8 Class Initialized
DEBUG - 2011-08-04 09:04:37 --> UTF-8 Support Enabled
DEBUG - 2011-08-04 09:04:37 --> URI Class Initialized
DEBUG - 2011-08-04 09:04:37 --> Router Class Initialized
DEBUG - 2011-08-04 09:04:37 --> Output Class Initialized
DEBUG - 2011-08-04 09:04:37 --> Input Class Initialized
DEBUG - 2011-08-04 09:04:37 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-04 09:04:37 --> Language Class Initialized
DEBUG - 2011-08-04 09:04:37 --> Loader Class Initialized
DEBUG - 2011-08-04 09:04:37 --> Controller Class Initialized
DEBUG - 2011-08-04 09:04:37 --> Model Class Initialized
DEBUG - 2011-08-04 09:04:37 --> Model Class Initialized
DEBUG - 2011-08-04 09:04:37 --> Model Class Initialized
DEBUG - 2011-08-04 09:04:37 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-04 09:04:37 --> Database Driver Class Initialized
DEBUG - 2011-08-04 09:04:37 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-04 09:04:37 --> Helper loaded: url_helper
DEBUG - 2011-08-04 09:04:37 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-04 09:04:37 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-04 09:04:37 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-04 09:04:37 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-04 09:04:37 --> Final output sent to browser
DEBUG - 2011-08-04 09:04:37 --> Total execution time: 0.0902
DEBUG - 2011-08-04 09:04:38 --> Config Class Initialized
DEBUG - 2011-08-04 09:04:38 --> Hooks Class Initialized
DEBUG - 2011-08-04 09:04:38 --> Utf8 Class Initialized
DEBUG - 2011-08-04 09:04:38 --> UTF-8 Support Enabled
DEBUG - 2011-08-04 09:04:38 --> URI Class Initialized
DEBUG - 2011-08-04 09:04:38 --> Router Class Initialized
ERROR - 2011-08-04 09:04:38 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-04 09:04:45 --> Config Class Initialized
DEBUG - 2011-08-04 09:04:45 --> Hooks Class Initialized
DEBUG - 2011-08-04 09:04:45 --> Utf8 Class Initialized
DEBUG - 2011-08-04 09:04:45 --> UTF-8 Support Enabled
DEBUG - 2011-08-04 09:04:45 --> URI Class Initialized
DEBUG - 2011-08-04 09:04:45 --> Router Class Initialized
DEBUG - 2011-08-04 09:04:45 --> Output Class Initialized
DEBUG - 2011-08-04 09:04:45 --> Input Class Initialized
DEBUG - 2011-08-04 09:04:45 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-04 09:04:45 --> Language Class Initialized
DEBUG - 2011-08-04 09:04:45 --> Loader Class Initialized
DEBUG - 2011-08-04 09:04:45 --> Controller Class Initialized
DEBUG - 2011-08-04 09:04:45 --> Model Class Initialized
DEBUG - 2011-08-04 09:04:45 --> Model Class Initialized
DEBUG - 2011-08-04 09:04:45 --> Model Class Initialized
DEBUG - 2011-08-04 09:04:45 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-04 09:04:45 --> Database Driver Class Initialized
DEBUG - 2011-08-04 09:04:46 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-04 09:04:46 --> Helper loaded: url_helper
DEBUG - 2011-08-04 09:04:46 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-04 09:04:46 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-04 09:04:46 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-04 09:04:46 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-04 09:04:46 --> Final output sent to browser
DEBUG - 2011-08-04 09:04:46 --> Total execution time: 0.8621
DEBUG - 2011-08-04 09:04:49 --> Config Class Initialized
DEBUG - 2011-08-04 09:04:49 --> Hooks Class Initialized
DEBUG - 2011-08-04 09:04:49 --> Utf8 Class Initialized
DEBUG - 2011-08-04 09:04:49 --> UTF-8 Support Enabled
DEBUG - 2011-08-04 09:04:49 --> URI Class Initialized
DEBUG - 2011-08-04 09:04:49 --> Router Class Initialized
DEBUG - 2011-08-04 09:04:49 --> Output Class Initialized
DEBUG - 2011-08-04 09:04:49 --> Input Class Initialized
DEBUG - 2011-08-04 09:04:49 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-04 09:04:49 --> Language Class Initialized
DEBUG - 2011-08-04 09:04:49 --> Loader Class Initialized
DEBUG - 2011-08-04 09:04:49 --> Controller Class Initialized
DEBUG - 2011-08-04 09:04:49 --> Model Class Initialized
DEBUG - 2011-08-04 09:04:49 --> Model Class Initialized
DEBUG - 2011-08-04 09:04:49 --> Model Class Initialized
DEBUG - 2011-08-04 09:04:49 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-04 09:04:49 --> Database Driver Class Initialized
DEBUG - 2011-08-04 09:04:49 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-04 09:04:49 --> Helper loaded: url_helper
DEBUG - 2011-08-04 09:04:49 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-04 09:04:49 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-04 09:04:49 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-04 09:04:49 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-04 09:04:49 --> Final output sent to browser
DEBUG - 2011-08-04 09:04:49 --> Total execution time: 0.1209
DEBUG - 2011-08-04 09:04:49 --> Config Class Initialized
DEBUG - 2011-08-04 09:04:49 --> Hooks Class Initialized
DEBUG - 2011-08-04 09:04:49 --> Utf8 Class Initialized
DEBUG - 2011-08-04 09:04:49 --> UTF-8 Support Enabled
DEBUG - 2011-08-04 09:04:49 --> URI Class Initialized
DEBUG - 2011-08-04 09:04:49 --> Router Class Initialized
ERROR - 2011-08-04 09:04:49 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-04 09:04:57 --> Config Class Initialized
DEBUG - 2011-08-04 09:04:57 --> Hooks Class Initialized
DEBUG - 2011-08-04 09:04:57 --> Utf8 Class Initialized
DEBUG - 2011-08-04 09:04:57 --> UTF-8 Support Enabled
DEBUG - 2011-08-04 09:04:57 --> URI Class Initialized
DEBUG - 2011-08-04 09:04:57 --> Router Class Initialized
DEBUG - 2011-08-04 09:04:57 --> Output Class Initialized
DEBUG - 2011-08-04 09:04:57 --> Input Class Initialized
DEBUG - 2011-08-04 09:04:57 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-04 09:04:57 --> Language Class Initialized
DEBUG - 2011-08-04 09:04:57 --> Loader Class Initialized
DEBUG - 2011-08-04 09:04:57 --> Controller Class Initialized
DEBUG - 2011-08-04 09:04:57 --> Model Class Initialized
DEBUG - 2011-08-04 09:04:57 --> Model Class Initialized
DEBUG - 2011-08-04 09:04:57 --> Model Class Initialized
DEBUG - 2011-08-04 09:04:57 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-04 09:04:57 --> Database Driver Class Initialized
DEBUG - 2011-08-04 09:04:58 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-04 09:04:58 --> Helper loaded: url_helper
DEBUG - 2011-08-04 09:04:58 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-04 09:04:58 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-04 09:04:58 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-04 09:04:58 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-04 09:04:58 --> Final output sent to browser
DEBUG - 2011-08-04 09:04:58 --> Total execution time: 0.4742
DEBUG - 2011-08-04 09:05:02 --> Config Class Initialized
DEBUG - 2011-08-04 09:05:02 --> Hooks Class Initialized
DEBUG - 2011-08-04 09:05:02 --> Utf8 Class Initialized
DEBUG - 2011-08-04 09:05:02 --> UTF-8 Support Enabled
DEBUG - 2011-08-04 09:05:02 --> URI Class Initialized
DEBUG - 2011-08-04 09:05:02 --> Router Class Initialized
ERROR - 2011-08-04 09:05:02 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-04 09:05:32 --> Config Class Initialized
DEBUG - 2011-08-04 09:05:32 --> Hooks Class Initialized
DEBUG - 2011-08-04 09:05:32 --> Utf8 Class Initialized
DEBUG - 2011-08-04 09:05:32 --> UTF-8 Support Enabled
DEBUG - 2011-08-04 09:05:32 --> URI Class Initialized
DEBUG - 2011-08-04 09:05:32 --> Router Class Initialized
DEBUG - 2011-08-04 09:05:32 --> Output Class Initialized
DEBUG - 2011-08-04 09:05:32 --> Input Class Initialized
DEBUG - 2011-08-04 09:05:32 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-04 09:05:32 --> Language Class Initialized
DEBUG - 2011-08-04 09:05:32 --> Loader Class Initialized
DEBUG - 2011-08-04 09:05:32 --> Controller Class Initialized
DEBUG - 2011-08-04 09:05:32 --> Model Class Initialized
DEBUG - 2011-08-04 09:05:32 --> Model Class Initialized
DEBUG - 2011-08-04 09:05:32 --> Model Class Initialized
DEBUG - 2011-08-04 09:05:32 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-04 09:05:32 --> Database Driver Class Initialized
DEBUG - 2011-08-04 09:05:33 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-04 09:05:33 --> Helper loaded: url_helper
DEBUG - 2011-08-04 09:05:33 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-04 09:05:33 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-04 09:05:33 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-04 09:05:33 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-04 09:05:33 --> Final output sent to browser
DEBUG - 2011-08-04 09:05:33 --> Total execution time: 0.3893
DEBUG - 2011-08-04 09:05:36 --> Config Class Initialized
DEBUG - 2011-08-04 09:05:36 --> Hooks Class Initialized
DEBUG - 2011-08-04 09:05:36 --> Utf8 Class Initialized
DEBUG - 2011-08-04 09:05:36 --> UTF-8 Support Enabled
DEBUG - 2011-08-04 09:05:36 --> URI Class Initialized
DEBUG - 2011-08-04 09:05:36 --> Router Class Initialized
ERROR - 2011-08-04 09:05:36 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-04 09:05:41 --> Config Class Initialized
DEBUG - 2011-08-04 09:05:41 --> Hooks Class Initialized
DEBUG - 2011-08-04 09:05:41 --> Utf8 Class Initialized
DEBUG - 2011-08-04 09:05:41 --> UTF-8 Support Enabled
DEBUG - 2011-08-04 09:05:41 --> URI Class Initialized
DEBUG - 2011-08-04 09:05:41 --> Router Class Initialized
DEBUG - 2011-08-04 09:05:41 --> Output Class Initialized
DEBUG - 2011-08-04 09:05:41 --> Input Class Initialized
DEBUG - 2011-08-04 09:05:41 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-04 09:05:41 --> Language Class Initialized
DEBUG - 2011-08-04 09:05:41 --> Loader Class Initialized
DEBUG - 2011-08-04 09:05:41 --> Controller Class Initialized
DEBUG - 2011-08-04 09:05:41 --> Model Class Initialized
DEBUG - 2011-08-04 09:05:41 --> Model Class Initialized
DEBUG - 2011-08-04 09:05:41 --> Model Class Initialized
DEBUG - 2011-08-04 09:05:41 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-04 09:05:41 --> Database Driver Class Initialized
DEBUG - 2011-08-04 09:05:41 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-04 09:05:41 --> Helper loaded: url_helper
DEBUG - 2011-08-04 09:05:41 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-04 09:05:41 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-04 09:05:41 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-04 09:05:41 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-04 09:05:41 --> Final output sent to browser
DEBUG - 2011-08-04 09:05:41 --> Total execution time: 0.0770
DEBUG - 2011-08-04 09:05:42 --> Config Class Initialized
DEBUG - 2011-08-04 09:05:42 --> Hooks Class Initialized
DEBUG - 2011-08-04 09:05:42 --> Utf8 Class Initialized
DEBUG - 2011-08-04 09:05:42 --> UTF-8 Support Enabled
DEBUG - 2011-08-04 09:05:42 --> URI Class Initialized
DEBUG - 2011-08-04 09:05:42 --> Router Class Initialized
DEBUG - 2011-08-04 09:05:42 --> Output Class Initialized
DEBUG - 2011-08-04 09:05:42 --> Input Class Initialized
DEBUG - 2011-08-04 09:05:42 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-04 09:05:42 --> Language Class Initialized
DEBUG - 2011-08-04 09:05:42 --> Loader Class Initialized
DEBUG - 2011-08-04 09:05:42 --> Controller Class Initialized
DEBUG - 2011-08-04 09:05:42 --> Model Class Initialized
DEBUG - 2011-08-04 09:05:42 --> Model Class Initialized
DEBUG - 2011-08-04 09:05:42 --> Model Class Initialized
DEBUG - 2011-08-04 09:05:42 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-04 09:05:42 --> Database Driver Class Initialized
DEBUG - 2011-08-04 09:05:43 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-04 09:05:43 --> Helper loaded: url_helper
DEBUG - 2011-08-04 09:05:43 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-04 09:05:43 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-04 09:05:43 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-04 09:05:43 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-04 09:05:43 --> Final output sent to browser
DEBUG - 2011-08-04 09:05:43 --> Total execution time: 0.2900
DEBUG - 2011-08-04 09:05:45 --> Config Class Initialized
DEBUG - 2011-08-04 09:05:45 --> Hooks Class Initialized
DEBUG - 2011-08-04 09:05:45 --> Utf8 Class Initialized
DEBUG - 2011-08-04 09:05:45 --> UTF-8 Support Enabled
DEBUG - 2011-08-04 09:05:45 --> URI Class Initialized
DEBUG - 2011-08-04 09:05:45 --> Router Class Initialized
ERROR - 2011-08-04 09:05:45 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-04 09:05:46 --> Config Class Initialized
DEBUG - 2011-08-04 09:05:46 --> Hooks Class Initialized
DEBUG - 2011-08-04 09:05:46 --> Utf8 Class Initialized
DEBUG - 2011-08-04 09:05:46 --> UTF-8 Support Enabled
DEBUG - 2011-08-04 09:05:46 --> URI Class Initialized
DEBUG - 2011-08-04 09:05:46 --> Router Class Initialized
DEBUG - 2011-08-04 09:05:46 --> Output Class Initialized
DEBUG - 2011-08-04 09:05:46 --> Input Class Initialized
DEBUG - 2011-08-04 09:05:46 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-04 09:05:46 --> Language Class Initialized
DEBUG - 2011-08-04 09:05:46 --> Loader Class Initialized
DEBUG - 2011-08-04 09:05:46 --> Controller Class Initialized
DEBUG - 2011-08-04 09:05:46 --> Model Class Initialized
DEBUG - 2011-08-04 09:05:46 --> Model Class Initialized
DEBUG - 2011-08-04 09:05:46 --> Model Class Initialized
DEBUG - 2011-08-04 09:05:46 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-04 09:05:46 --> Database Driver Class Initialized
DEBUG - 2011-08-04 09:05:46 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-04 09:05:46 --> Helper loaded: url_helper
DEBUG - 2011-08-04 09:05:46 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-04 09:05:46 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-04 09:05:46 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-04 09:05:46 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-04 09:05:46 --> Final output sent to browser
DEBUG - 2011-08-04 09:05:46 --> Total execution time: 0.0743
DEBUG - 2011-08-04 09:05:53 --> Config Class Initialized
DEBUG - 2011-08-04 09:05:53 --> Hooks Class Initialized
DEBUG - 2011-08-04 09:05:53 --> Utf8 Class Initialized
DEBUG - 2011-08-04 09:05:53 --> UTF-8 Support Enabled
DEBUG - 2011-08-04 09:05:53 --> URI Class Initialized
DEBUG - 2011-08-04 09:05:53 --> Router Class Initialized
DEBUG - 2011-08-04 09:05:53 --> Output Class Initialized
DEBUG - 2011-08-04 09:05:53 --> Input Class Initialized
DEBUG - 2011-08-04 09:05:53 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-04 09:05:53 --> Language Class Initialized
DEBUG - 2011-08-04 09:05:53 --> Loader Class Initialized
DEBUG - 2011-08-04 09:05:53 --> Controller Class Initialized
DEBUG - 2011-08-04 09:05:53 --> Model Class Initialized
DEBUG - 2011-08-04 09:05:53 --> Model Class Initialized
DEBUG - 2011-08-04 09:05:53 --> Model Class Initialized
DEBUG - 2011-08-04 09:05:53 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-04 09:05:53 --> Database Driver Class Initialized
DEBUG - 2011-08-04 09:05:53 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-04 09:05:53 --> Helper loaded: url_helper
DEBUG - 2011-08-04 09:05:53 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-04 09:05:53 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-04 09:05:53 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-04 09:05:53 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-04 09:05:53 --> Final output sent to browser
DEBUG - 2011-08-04 09:05:53 --> Total execution time: 0.2562
DEBUG - 2011-08-04 09:05:56 --> Config Class Initialized
DEBUG - 2011-08-04 09:05:56 --> Hooks Class Initialized
DEBUG - 2011-08-04 09:05:56 --> Utf8 Class Initialized
DEBUG - 2011-08-04 09:05:56 --> UTF-8 Support Enabled
DEBUG - 2011-08-04 09:05:56 --> URI Class Initialized
DEBUG - 2011-08-04 09:05:56 --> Router Class Initialized
DEBUG - 2011-08-04 09:05:56 --> Output Class Initialized
DEBUG - 2011-08-04 09:05:56 --> Input Class Initialized
DEBUG - 2011-08-04 09:05:56 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-04 09:05:56 --> Language Class Initialized
DEBUG - 2011-08-04 09:05:56 --> Loader Class Initialized
DEBUG - 2011-08-04 09:05:56 --> Controller Class Initialized
DEBUG - 2011-08-04 09:05:56 --> Model Class Initialized
DEBUG - 2011-08-04 09:05:56 --> Model Class Initialized
DEBUG - 2011-08-04 09:05:56 --> Model Class Initialized
DEBUG - 2011-08-04 09:05:56 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-04 09:05:56 --> Database Driver Class Initialized
DEBUG - 2011-08-04 09:05:56 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-04 09:05:56 --> Helper loaded: url_helper
DEBUG - 2011-08-04 09:05:56 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-04 09:05:56 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-04 09:05:56 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-04 09:05:56 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-04 09:05:56 --> Final output sent to browser
DEBUG - 2011-08-04 09:05:56 --> Total execution time: 0.0459
DEBUG - 2011-08-04 09:05:57 --> Config Class Initialized
DEBUG - 2011-08-04 09:05:57 --> Hooks Class Initialized
DEBUG - 2011-08-04 09:05:57 --> Utf8 Class Initialized
DEBUG - 2011-08-04 09:05:57 --> UTF-8 Support Enabled
DEBUG - 2011-08-04 09:05:57 --> URI Class Initialized
DEBUG - 2011-08-04 09:05:57 --> Router Class Initialized
ERROR - 2011-08-04 09:05:57 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-04 09:06:02 --> Config Class Initialized
DEBUG - 2011-08-04 09:06:02 --> Hooks Class Initialized
DEBUG - 2011-08-04 09:06:02 --> Utf8 Class Initialized
DEBUG - 2011-08-04 09:06:02 --> UTF-8 Support Enabled
DEBUG - 2011-08-04 09:06:02 --> URI Class Initialized
DEBUG - 2011-08-04 09:06:02 --> Router Class Initialized
DEBUG - 2011-08-04 09:06:02 --> Output Class Initialized
DEBUG - 2011-08-04 09:06:02 --> Input Class Initialized
DEBUG - 2011-08-04 09:06:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-04 09:06:02 --> Language Class Initialized
DEBUG - 2011-08-04 09:06:02 --> Loader Class Initialized
DEBUG - 2011-08-04 09:06:02 --> Controller Class Initialized
DEBUG - 2011-08-04 09:06:02 --> Model Class Initialized
DEBUG - 2011-08-04 09:06:02 --> Model Class Initialized
DEBUG - 2011-08-04 09:06:02 --> Model Class Initialized
DEBUG - 2011-08-04 09:06:02 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-04 09:06:02 --> Database Driver Class Initialized
DEBUG - 2011-08-04 09:06:02 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-04 09:06:02 --> Helper loaded: url_helper
DEBUG - 2011-08-04 09:06:02 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-04 09:06:02 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-04 09:06:02 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-04 09:06:02 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-04 09:06:02 --> Final output sent to browser
DEBUG - 2011-08-04 09:06:02 --> Total execution time: 0.5946
DEBUG - 2011-08-04 09:06:05 --> Config Class Initialized
DEBUG - 2011-08-04 09:06:05 --> Hooks Class Initialized
DEBUG - 2011-08-04 09:06:05 --> Utf8 Class Initialized
DEBUG - 2011-08-04 09:06:05 --> UTF-8 Support Enabled
DEBUG - 2011-08-04 09:06:05 --> URI Class Initialized
DEBUG - 2011-08-04 09:06:05 --> Router Class Initialized
DEBUG - 2011-08-04 09:06:05 --> Output Class Initialized
DEBUG - 2011-08-04 09:06:05 --> Input Class Initialized
DEBUG - 2011-08-04 09:06:05 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-04 09:06:05 --> Language Class Initialized
DEBUG - 2011-08-04 09:06:05 --> Loader Class Initialized
DEBUG - 2011-08-04 09:06:05 --> Controller Class Initialized
DEBUG - 2011-08-04 09:06:05 --> Model Class Initialized
DEBUG - 2011-08-04 09:06:05 --> Model Class Initialized
DEBUG - 2011-08-04 09:06:05 --> Model Class Initialized
DEBUG - 2011-08-04 09:06:05 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-04 09:06:05 --> Database Driver Class Initialized
DEBUG - 2011-08-04 09:06:05 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-04 09:06:05 --> Helper loaded: url_helper
DEBUG - 2011-08-04 09:06:05 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-04 09:06:05 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-04 09:06:05 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-04 09:06:05 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-04 09:06:05 --> Final output sent to browser
DEBUG - 2011-08-04 09:06:05 --> Total execution time: 0.0467
DEBUG - 2011-08-04 09:06:06 --> Config Class Initialized
DEBUG - 2011-08-04 09:06:06 --> Hooks Class Initialized
DEBUG - 2011-08-04 09:06:06 --> Utf8 Class Initialized
DEBUG - 2011-08-04 09:06:06 --> UTF-8 Support Enabled
DEBUG - 2011-08-04 09:06:06 --> URI Class Initialized
DEBUG - 2011-08-04 09:06:06 --> Router Class Initialized
ERROR - 2011-08-04 09:06:06 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-04 09:09:19 --> Config Class Initialized
DEBUG - 2011-08-04 09:09:19 --> Hooks Class Initialized
DEBUG - 2011-08-04 09:09:19 --> Utf8 Class Initialized
DEBUG - 2011-08-04 09:09:19 --> UTF-8 Support Enabled
DEBUG - 2011-08-04 09:09:19 --> URI Class Initialized
DEBUG - 2011-08-04 09:09:19 --> Router Class Initialized
DEBUG - 2011-08-04 09:09:19 --> No URI present. Default controller set.
DEBUG - 2011-08-04 09:09:19 --> Output Class Initialized
DEBUG - 2011-08-04 09:09:19 --> Input Class Initialized
DEBUG - 2011-08-04 09:09:19 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-04 09:09:19 --> Language Class Initialized
DEBUG - 2011-08-04 09:09:19 --> Loader Class Initialized
DEBUG - 2011-08-04 09:09:19 --> Controller Class Initialized
DEBUG - 2011-08-04 09:09:19 --> File loaded: application/views/splash/main.php
DEBUG - 2011-08-04 09:09:19 --> Helper loaded: url_helper
DEBUG - 2011-08-04 09:09:19 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-04 09:09:19 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-04 09:09:19 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-04 09:09:19 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-04 09:09:19 --> Final output sent to browser
DEBUG - 2011-08-04 09:09:19 --> Total execution time: 0.0137
DEBUG - 2011-08-04 09:09:24 --> Config Class Initialized
DEBUG - 2011-08-04 09:09:24 --> Hooks Class Initialized
DEBUG - 2011-08-04 09:09:24 --> Utf8 Class Initialized
DEBUG - 2011-08-04 09:09:24 --> UTF-8 Support Enabled
DEBUG - 2011-08-04 09:09:24 --> URI Class Initialized
DEBUG - 2011-08-04 09:09:24 --> Router Class Initialized
DEBUG - 2011-08-04 09:09:24 --> Output Class Initialized
DEBUG - 2011-08-04 09:09:24 --> Input Class Initialized
DEBUG - 2011-08-04 09:09:24 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-04 09:09:24 --> Language Class Initialized
DEBUG - 2011-08-04 09:09:24 --> Loader Class Initialized
DEBUG - 2011-08-04 09:09:24 --> Controller Class Initialized
DEBUG - 2011-08-04 09:09:24 --> Model Class Initialized
DEBUG - 2011-08-04 09:09:24 --> Model Class Initialized
DEBUG - 2011-08-04 09:09:24 --> Model Class Initialized
DEBUG - 2011-08-04 09:09:24 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-04 09:09:24 --> Database Driver Class Initialized
DEBUG - 2011-08-04 09:09:24 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-04 09:09:24 --> Helper loaded: url_helper
DEBUG - 2011-08-04 09:09:24 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-04 09:09:24 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-04 09:09:24 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-04 09:09:24 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-04 09:09:24 --> Final output sent to browser
DEBUG - 2011-08-04 09:09:24 --> Total execution time: 0.0468
DEBUG - 2011-08-04 09:09:53 --> Config Class Initialized
DEBUG - 2011-08-04 09:09:53 --> Hooks Class Initialized
DEBUG - 2011-08-04 09:09:53 --> Utf8 Class Initialized
DEBUG - 2011-08-04 09:09:53 --> UTF-8 Support Enabled
DEBUG - 2011-08-04 09:09:53 --> URI Class Initialized
DEBUG - 2011-08-04 09:09:53 --> Router Class Initialized
DEBUG - 2011-08-04 09:09:53 --> Output Class Initialized
DEBUG - 2011-08-04 09:09:53 --> Input Class Initialized
DEBUG - 2011-08-04 09:09:53 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-04 09:09:53 --> Language Class Initialized
DEBUG - 2011-08-04 09:09:53 --> Loader Class Initialized
DEBUG - 2011-08-04 09:09:53 --> Controller Class Initialized
DEBUG - 2011-08-04 09:09:53 --> Model Class Initialized
DEBUG - 2011-08-04 09:09:53 --> Model Class Initialized
DEBUG - 2011-08-04 09:09:53 --> Model Class Initialized
DEBUG - 2011-08-04 09:09:53 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-04 09:09:53 --> Database Driver Class Initialized
DEBUG - 2011-08-04 09:09:53 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-04 09:09:53 --> Helper loaded: url_helper
DEBUG - 2011-08-04 09:09:53 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-04 09:09:53 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-04 09:09:53 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-04 09:09:53 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-04 09:09:53 --> Final output sent to browser
DEBUG - 2011-08-04 09:09:53 --> Total execution time: 0.0718
DEBUG - 2011-08-04 09:10:02 --> Config Class Initialized
DEBUG - 2011-08-04 09:10:02 --> Hooks Class Initialized
DEBUG - 2011-08-04 09:10:02 --> Utf8 Class Initialized
DEBUG - 2011-08-04 09:10:02 --> UTF-8 Support Enabled
DEBUG - 2011-08-04 09:10:02 --> URI Class Initialized
DEBUG - 2011-08-04 09:10:02 --> Router Class Initialized
DEBUG - 2011-08-04 09:10:02 --> Output Class Initialized
DEBUG - 2011-08-04 09:10:02 --> Input Class Initialized
DEBUG - 2011-08-04 09:10:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-04 09:10:02 --> Language Class Initialized
DEBUG - 2011-08-04 09:10:02 --> Loader Class Initialized
DEBUG - 2011-08-04 09:10:02 --> Controller Class Initialized
DEBUG - 2011-08-04 09:10:02 --> Model Class Initialized
DEBUG - 2011-08-04 09:10:02 --> Model Class Initialized
DEBUG - 2011-08-04 09:10:02 --> Model Class Initialized
DEBUG - 2011-08-04 09:10:02 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-04 09:10:02 --> Database Driver Class Initialized
DEBUG - 2011-08-04 09:10:03 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-04 09:10:03 --> Helper loaded: url_helper
DEBUG - 2011-08-04 09:10:03 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-04 09:10:03 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-04 09:10:03 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-04 09:10:03 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-04 09:10:03 --> Final output sent to browser
DEBUG - 2011-08-04 09:10:03 --> Total execution time: 0.0728
DEBUG - 2011-08-04 09:10:10 --> Config Class Initialized
DEBUG - 2011-08-04 09:10:10 --> Hooks Class Initialized
DEBUG - 2011-08-04 09:10:10 --> Utf8 Class Initialized
DEBUG - 2011-08-04 09:10:10 --> UTF-8 Support Enabled
DEBUG - 2011-08-04 09:10:10 --> URI Class Initialized
DEBUG - 2011-08-04 09:10:10 --> Router Class Initialized
DEBUG - 2011-08-04 09:10:10 --> Output Class Initialized
DEBUG - 2011-08-04 09:10:10 --> Input Class Initialized
DEBUG - 2011-08-04 09:10:10 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-04 09:10:10 --> Language Class Initialized
DEBUG - 2011-08-04 09:10:10 --> Loader Class Initialized
DEBUG - 2011-08-04 09:10:10 --> Controller Class Initialized
DEBUG - 2011-08-04 09:10:10 --> Model Class Initialized
DEBUG - 2011-08-04 09:10:10 --> Model Class Initialized
DEBUG - 2011-08-04 09:10:10 --> Model Class Initialized
DEBUG - 2011-08-04 09:10:10 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-04 09:10:10 --> Database Driver Class Initialized
DEBUG - 2011-08-04 09:10:10 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-04 09:10:10 --> Helper loaded: url_helper
DEBUG - 2011-08-04 09:10:10 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-04 09:10:10 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-04 09:10:10 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-04 09:10:10 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-04 09:10:10 --> Final output sent to browser
DEBUG - 2011-08-04 09:10:10 --> Total execution time: 0.0458
DEBUG - 2011-08-04 09:10:20 --> Config Class Initialized
DEBUG - 2011-08-04 09:10:20 --> Hooks Class Initialized
DEBUG - 2011-08-04 09:10:20 --> Utf8 Class Initialized
DEBUG - 2011-08-04 09:10:20 --> UTF-8 Support Enabled
DEBUG - 2011-08-04 09:10:20 --> URI Class Initialized
DEBUG - 2011-08-04 09:10:20 --> Router Class Initialized
DEBUG - 2011-08-04 09:10:20 --> Output Class Initialized
DEBUG - 2011-08-04 09:10:20 --> Input Class Initialized
DEBUG - 2011-08-04 09:10:20 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-04 09:10:20 --> Language Class Initialized
DEBUG - 2011-08-04 09:10:20 --> Loader Class Initialized
DEBUG - 2011-08-04 09:10:20 --> Controller Class Initialized
DEBUG - 2011-08-04 09:10:20 --> Model Class Initialized
DEBUG - 2011-08-04 09:10:20 --> Model Class Initialized
DEBUG - 2011-08-04 09:10:20 --> Model Class Initialized
DEBUG - 2011-08-04 09:10:20 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-04 09:10:20 --> Database Driver Class Initialized
DEBUG - 2011-08-04 09:10:20 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-04 09:10:20 --> Helper loaded: url_helper
DEBUG - 2011-08-04 09:10:20 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-04 09:10:20 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-04 09:10:20 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-04 09:10:20 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-04 09:10:20 --> Final output sent to browser
DEBUG - 2011-08-04 09:10:20 --> Total execution time: 0.0473
DEBUG - 2011-08-04 09:10:30 --> Config Class Initialized
DEBUG - 2011-08-04 09:10:30 --> Hooks Class Initialized
DEBUG - 2011-08-04 09:10:30 --> Utf8 Class Initialized
DEBUG - 2011-08-04 09:10:30 --> UTF-8 Support Enabled
DEBUG - 2011-08-04 09:10:30 --> URI Class Initialized
DEBUG - 2011-08-04 09:10:30 --> Router Class Initialized
DEBUG - 2011-08-04 09:10:30 --> Output Class Initialized
DEBUG - 2011-08-04 09:10:30 --> Input Class Initialized
DEBUG - 2011-08-04 09:10:30 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-04 09:10:30 --> Language Class Initialized
DEBUG - 2011-08-04 09:10:30 --> Loader Class Initialized
DEBUG - 2011-08-04 09:10:30 --> Controller Class Initialized
DEBUG - 2011-08-04 09:10:30 --> Model Class Initialized
DEBUG - 2011-08-04 09:10:30 --> Model Class Initialized
DEBUG - 2011-08-04 09:10:30 --> Model Class Initialized
DEBUG - 2011-08-04 09:10:30 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-04 09:10:30 --> Database Driver Class Initialized
DEBUG - 2011-08-04 09:10:30 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-04 09:10:30 --> Helper loaded: url_helper
DEBUG - 2011-08-04 09:10:30 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-04 09:10:30 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-04 09:10:30 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-04 09:10:30 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-04 09:10:30 --> Final output sent to browser
DEBUG - 2011-08-04 09:10:30 --> Total execution time: 0.0422
DEBUG - 2011-08-04 09:10:37 --> Config Class Initialized
DEBUG - 2011-08-04 09:10:37 --> Hooks Class Initialized
DEBUG - 2011-08-04 09:10:37 --> Utf8 Class Initialized
DEBUG - 2011-08-04 09:10:37 --> UTF-8 Support Enabled
DEBUG - 2011-08-04 09:10:37 --> URI Class Initialized
DEBUG - 2011-08-04 09:10:37 --> Router Class Initialized
DEBUG - 2011-08-04 09:10:37 --> Output Class Initialized
DEBUG - 2011-08-04 09:10:37 --> Input Class Initialized
DEBUG - 2011-08-04 09:10:37 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-04 09:10:37 --> Language Class Initialized
DEBUG - 2011-08-04 09:10:37 --> Loader Class Initialized
DEBUG - 2011-08-04 09:10:37 --> Controller Class Initialized
DEBUG - 2011-08-04 09:10:37 --> Model Class Initialized
DEBUG - 2011-08-04 09:10:37 --> Model Class Initialized
DEBUG - 2011-08-04 09:10:37 --> Model Class Initialized
DEBUG - 2011-08-04 09:10:37 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-04 09:10:37 --> Database Driver Class Initialized
DEBUG - 2011-08-04 09:10:37 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-04 09:10:37 --> Helper loaded: url_helper
DEBUG - 2011-08-04 09:10:37 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-04 09:10:37 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-04 09:10:37 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-04 09:10:37 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-04 09:10:37 --> Final output sent to browser
DEBUG - 2011-08-04 09:10:37 --> Total execution time: 0.0703
DEBUG - 2011-08-04 09:10:44 --> Config Class Initialized
DEBUG - 2011-08-04 09:10:44 --> Hooks Class Initialized
DEBUG - 2011-08-04 09:10:44 --> Utf8 Class Initialized
DEBUG - 2011-08-04 09:10:44 --> UTF-8 Support Enabled
DEBUG - 2011-08-04 09:10:44 --> URI Class Initialized
DEBUG - 2011-08-04 09:10:44 --> Router Class Initialized
DEBUG - 2011-08-04 09:10:44 --> Output Class Initialized
DEBUG - 2011-08-04 09:10:44 --> Input Class Initialized
DEBUG - 2011-08-04 09:10:44 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-04 09:10:44 --> Language Class Initialized
DEBUG - 2011-08-04 09:10:44 --> Loader Class Initialized
DEBUG - 2011-08-04 09:10:44 --> Controller Class Initialized
DEBUG - 2011-08-04 09:10:44 --> Model Class Initialized
DEBUG - 2011-08-04 09:10:44 --> Model Class Initialized
DEBUG - 2011-08-04 09:10:44 --> Model Class Initialized
DEBUG - 2011-08-04 09:10:44 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-04 09:10:44 --> Database Driver Class Initialized
DEBUG - 2011-08-04 09:10:44 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-04 09:10:44 --> Helper loaded: url_helper
DEBUG - 2011-08-04 09:10:44 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-04 09:10:44 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-04 09:10:44 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-04 09:10:44 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-04 09:10:44 --> Final output sent to browser
DEBUG - 2011-08-04 09:10:44 --> Total execution time: 0.0901
DEBUG - 2011-08-04 09:15:44 --> Config Class Initialized
DEBUG - 2011-08-04 09:15:44 --> Hooks Class Initialized
DEBUG - 2011-08-04 09:15:44 --> Utf8 Class Initialized
DEBUG - 2011-08-04 09:15:44 --> UTF-8 Support Enabled
DEBUG - 2011-08-04 09:15:44 --> URI Class Initialized
DEBUG - 2011-08-04 09:15:44 --> Router Class Initialized
DEBUG - 2011-08-04 09:15:44 --> Output Class Initialized
DEBUG - 2011-08-04 09:15:44 --> Input Class Initialized
DEBUG - 2011-08-04 09:15:44 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-04 09:15:44 --> Language Class Initialized
DEBUG - 2011-08-04 09:15:44 --> Loader Class Initialized
DEBUG - 2011-08-04 09:15:44 --> Controller Class Initialized
ERROR - 2011-08-04 09:15:45 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-04 09:15:45 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-04 09:15:45 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-04 09:15:45 --> Model Class Initialized
DEBUG - 2011-08-04 09:15:45 --> Model Class Initialized
DEBUG - 2011-08-04 09:15:45 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-04 09:15:45 --> Database Driver Class Initialized
DEBUG - 2011-08-04 09:15:45 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-04 09:15:45 --> Helper loaded: url_helper
DEBUG - 2011-08-04 09:15:45 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-04 09:15:45 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-04 09:15:45 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-04 09:15:45 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-04 09:15:45 --> Final output sent to browser
DEBUG - 2011-08-04 09:15:45 --> Total execution time: 0.6524
DEBUG - 2011-08-04 09:15:49 --> Config Class Initialized
DEBUG - 2011-08-04 09:15:49 --> Hooks Class Initialized
DEBUG - 2011-08-04 09:15:49 --> Utf8 Class Initialized
DEBUG - 2011-08-04 09:15:49 --> UTF-8 Support Enabled
DEBUG - 2011-08-04 09:15:49 --> URI Class Initialized
DEBUG - 2011-08-04 09:15:49 --> Router Class Initialized
DEBUG - 2011-08-04 09:15:49 --> Output Class Initialized
DEBUG - 2011-08-04 09:15:49 --> Input Class Initialized
DEBUG - 2011-08-04 09:15:49 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-04 09:15:49 --> Language Class Initialized
DEBUG - 2011-08-04 09:15:49 --> Loader Class Initialized
DEBUG - 2011-08-04 09:15:49 --> Controller Class Initialized
DEBUG - 2011-08-04 09:15:49 --> Model Class Initialized
DEBUG - 2011-08-04 09:15:50 --> Model Class Initialized
DEBUG - 2011-08-04 09:15:50 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-04 09:15:50 --> Database Driver Class Initialized
DEBUG - 2011-08-04 09:15:51 --> Final output sent to browser
DEBUG - 2011-08-04 09:15:51 --> Total execution time: 1.9302
DEBUG - 2011-08-04 09:15:54 --> Config Class Initialized
DEBUG - 2011-08-04 09:15:54 --> Hooks Class Initialized
DEBUG - 2011-08-04 09:15:54 --> Utf8 Class Initialized
DEBUG - 2011-08-04 09:15:54 --> UTF-8 Support Enabled
DEBUG - 2011-08-04 09:15:54 --> URI Class Initialized
DEBUG - 2011-08-04 09:15:54 --> Router Class Initialized
ERROR - 2011-08-04 09:15:54 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-04 09:24:35 --> Config Class Initialized
DEBUG - 2011-08-04 09:24:35 --> Hooks Class Initialized
DEBUG - 2011-08-04 09:24:35 --> Utf8 Class Initialized
DEBUG - 2011-08-04 09:24:35 --> UTF-8 Support Enabled
DEBUG - 2011-08-04 09:24:35 --> URI Class Initialized
DEBUG - 2011-08-04 09:24:35 --> Router Class Initialized
DEBUG - 2011-08-04 09:24:35 --> No URI present. Default controller set.
DEBUG - 2011-08-04 09:24:35 --> Output Class Initialized
DEBUG - 2011-08-04 09:24:35 --> Input Class Initialized
DEBUG - 2011-08-04 09:24:35 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-04 09:24:35 --> Language Class Initialized
DEBUG - 2011-08-04 09:24:35 --> Loader Class Initialized
DEBUG - 2011-08-04 09:24:35 --> Controller Class Initialized
DEBUG - 2011-08-04 09:24:35 --> File loaded: application/views/splash/main.php
DEBUG - 2011-08-04 09:24:35 --> Helper loaded: url_helper
DEBUG - 2011-08-04 09:24:35 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-04 09:24:35 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-04 09:24:35 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-04 09:24:35 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-04 09:24:35 --> Final output sent to browser
DEBUG - 2011-08-04 09:24:35 --> Total execution time: 0.0129
DEBUG - 2011-08-04 09:28:40 --> Config Class Initialized
DEBUG - 2011-08-04 09:28:40 --> Hooks Class Initialized
DEBUG - 2011-08-04 09:28:40 --> Utf8 Class Initialized
DEBUG - 2011-08-04 09:28:40 --> UTF-8 Support Enabled
DEBUG - 2011-08-04 09:28:40 --> URI Class Initialized
DEBUG - 2011-08-04 09:28:40 --> Router Class Initialized
ERROR - 2011-08-04 09:28:40 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-04 09:28:57 --> Config Class Initialized
DEBUG - 2011-08-04 09:28:57 --> Hooks Class Initialized
DEBUG - 2011-08-04 09:28:57 --> Utf8 Class Initialized
DEBUG - 2011-08-04 09:28:57 --> UTF-8 Support Enabled
DEBUG - 2011-08-04 09:28:57 --> URI Class Initialized
DEBUG - 2011-08-04 09:28:57 --> Router Class Initialized
DEBUG - 2011-08-04 09:28:57 --> Output Class Initialized
DEBUG - 2011-08-04 09:28:57 --> Input Class Initialized
DEBUG - 2011-08-04 09:28:57 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-04 09:28:57 --> Language Class Initialized
DEBUG - 2011-08-04 09:28:57 --> Loader Class Initialized
DEBUG - 2011-08-04 09:28:57 --> Controller Class Initialized
DEBUG - 2011-08-04 09:28:57 --> Model Class Initialized
DEBUG - 2011-08-04 09:28:57 --> Model Class Initialized
DEBUG - 2011-08-04 09:28:57 --> Model Class Initialized
DEBUG - 2011-08-04 09:28:57 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-04 09:28:57 --> Database Driver Class Initialized
DEBUG - 2011-08-04 09:28:57 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-04 09:28:57 --> Helper loaded: url_helper
DEBUG - 2011-08-04 09:28:57 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-04 09:28:57 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-04 09:28:57 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-04 09:28:57 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-04 09:28:57 --> Final output sent to browser
DEBUG - 2011-08-04 09:28:57 --> Total execution time: 0.0468
DEBUG - 2011-08-04 09:32:15 --> Config Class Initialized
DEBUG - 2011-08-04 09:32:15 --> Hooks Class Initialized
DEBUG - 2011-08-04 09:32:15 --> Utf8 Class Initialized
DEBUG - 2011-08-04 09:32:15 --> UTF-8 Support Enabled
DEBUG - 2011-08-04 09:32:15 --> URI Class Initialized
DEBUG - 2011-08-04 09:32:15 --> Router Class Initialized
DEBUG - 2011-08-04 09:32:15 --> Config Class Initialized
ERROR - 2011-08-04 09:32:15 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-04 09:32:15 --> Hooks Class Initialized
DEBUG - 2011-08-04 09:32:15 --> Utf8 Class Initialized
DEBUG - 2011-08-04 09:32:15 --> UTF-8 Support Enabled
DEBUG - 2011-08-04 09:32:15 --> URI Class Initialized
DEBUG - 2011-08-04 09:32:15 --> Router Class Initialized
DEBUG - 2011-08-04 09:32:15 --> Output Class Initialized
DEBUG - 2011-08-04 09:32:15 --> Input Class Initialized
DEBUG - 2011-08-04 09:32:15 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-04 09:32:15 --> Language Class Initialized
DEBUG - 2011-08-04 09:32:15 --> Loader Class Initialized
DEBUG - 2011-08-04 09:32:15 --> Controller Class Initialized
DEBUG - 2011-08-04 09:32:15 --> Model Class Initialized
DEBUG - 2011-08-04 09:32:15 --> Model Class Initialized
DEBUG - 2011-08-04 09:32:15 --> Model Class Initialized
DEBUG - 2011-08-04 09:32:15 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-04 09:32:15 --> Database Driver Class Initialized
DEBUG - 2011-08-04 09:32:16 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-04 09:32:16 --> Helper loaded: url_helper
DEBUG - 2011-08-04 09:32:16 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-04 09:32:16 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-04 09:32:16 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-04 09:32:16 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-04 09:32:16 --> Final output sent to browser
DEBUG - 2011-08-04 09:32:16 --> Total execution time: 0.5761
DEBUG - 2011-08-04 09:34:26 --> Config Class Initialized
DEBUG - 2011-08-04 09:34:26 --> Hooks Class Initialized
DEBUG - 2011-08-04 09:34:26 --> Utf8 Class Initialized
DEBUG - 2011-08-04 09:34:26 --> UTF-8 Support Enabled
DEBUG - 2011-08-04 09:34:26 --> Config Class Initialized
DEBUG - 2011-08-04 09:34:26 --> Hooks Class Initialized
DEBUG - 2011-08-04 09:34:26 --> Utf8 Class Initialized
DEBUG - 2011-08-04 09:34:26 --> UTF-8 Support Enabled
DEBUG - 2011-08-04 09:34:26 --> URI Class Initialized
DEBUG - 2011-08-04 09:34:26 --> Router Class Initialized
ERROR - 2011-08-04 09:34:26 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-04 09:34:26 --> URI Class Initialized
DEBUG - 2011-08-04 09:34:26 --> Router Class Initialized
DEBUG - 2011-08-04 09:34:26 --> Output Class Initialized
DEBUG - 2011-08-04 09:34:26 --> Input Class Initialized
DEBUG - 2011-08-04 09:34:26 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-04 09:34:26 --> Language Class Initialized
DEBUG - 2011-08-04 09:34:26 --> Loader Class Initialized
DEBUG - 2011-08-04 09:34:26 --> Controller Class Initialized
DEBUG - 2011-08-04 09:34:26 --> Model Class Initialized
DEBUG - 2011-08-04 09:34:26 --> Model Class Initialized
DEBUG - 2011-08-04 09:34:26 --> Model Class Initialized
DEBUG - 2011-08-04 09:34:26 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-04 09:34:26 --> Database Driver Class Initialized
DEBUG - 2011-08-04 09:34:27 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-04 09:34:27 --> Helper loaded: url_helper
DEBUG - 2011-08-04 09:34:27 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-04 09:34:27 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-04 09:34:27 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-04 09:34:27 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-04 09:34:27 --> Final output sent to browser
DEBUG - 2011-08-04 09:34:27 --> Total execution time: 1.1882
DEBUG - 2011-08-04 11:19:44 --> Config Class Initialized
DEBUG - 2011-08-04 11:19:44 --> Hooks Class Initialized
DEBUG - 2011-08-04 11:19:44 --> Utf8 Class Initialized
DEBUG - 2011-08-04 11:19:44 --> UTF-8 Support Enabled
DEBUG - 2011-08-04 11:19:44 --> URI Class Initialized
DEBUG - 2011-08-04 11:19:44 --> Router Class Initialized
ERROR - 2011-08-04 11:19:44 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-08-04 12:02:10 --> Config Class Initialized
DEBUG - 2011-08-04 12:02:10 --> Hooks Class Initialized
DEBUG - 2011-08-04 12:02:10 --> Utf8 Class Initialized
DEBUG - 2011-08-04 12:02:10 --> UTF-8 Support Enabled
DEBUG - 2011-08-04 12:02:10 --> URI Class Initialized
DEBUG - 2011-08-04 12:02:10 --> Router Class Initialized
DEBUG - 2011-08-04 12:02:10 --> Output Class Initialized
DEBUG - 2011-08-04 12:02:10 --> Input Class Initialized
DEBUG - 2011-08-04 12:02:10 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-04 12:02:10 --> Language Class Initialized
DEBUG - 2011-08-04 12:02:10 --> Loader Class Initialized
DEBUG - 2011-08-04 12:02:10 --> Controller Class Initialized
ERROR - 2011-08-04 12:02:10 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-04 12:02:10 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-04 12:02:10 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-04 12:02:10 --> Model Class Initialized
DEBUG - 2011-08-04 12:02:10 --> Model Class Initialized
DEBUG - 2011-08-04 12:02:10 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-04 12:02:10 --> Database Driver Class Initialized
DEBUG - 2011-08-04 12:02:10 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-04 12:02:10 --> Helper loaded: url_helper
DEBUG - 2011-08-04 12:02:10 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-04 12:02:10 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-04 12:02:10 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-04 12:02:10 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-04 12:02:10 --> Final output sent to browser
DEBUG - 2011-08-04 12:02:10 --> Total execution time: 0.2798
DEBUG - 2011-08-04 12:02:11 --> Config Class Initialized
DEBUG - 2011-08-04 12:02:11 --> Hooks Class Initialized
DEBUG - 2011-08-04 12:02:11 --> Utf8 Class Initialized
DEBUG - 2011-08-04 12:02:11 --> UTF-8 Support Enabled
DEBUG - 2011-08-04 12:02:11 --> URI Class Initialized
DEBUG - 2011-08-04 12:02:11 --> Router Class Initialized
DEBUG - 2011-08-04 12:02:11 --> Output Class Initialized
DEBUG - 2011-08-04 12:02:11 --> Input Class Initialized
DEBUG - 2011-08-04 12:02:11 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-04 12:02:11 --> Language Class Initialized
DEBUG - 2011-08-04 12:02:11 --> Loader Class Initialized
DEBUG - 2011-08-04 12:02:11 --> Controller Class Initialized
DEBUG - 2011-08-04 12:02:11 --> Model Class Initialized
DEBUG - 2011-08-04 12:02:11 --> Model Class Initialized
DEBUG - 2011-08-04 12:02:11 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-04 12:02:11 --> Database Driver Class Initialized
DEBUG - 2011-08-04 12:02:12 --> Final output sent to browser
DEBUG - 2011-08-04 12:02:12 --> Total execution time: 0.7176
DEBUG - 2011-08-04 12:02:12 --> Config Class Initialized
DEBUG - 2011-08-04 12:02:12 --> Hooks Class Initialized
DEBUG - 2011-08-04 12:02:12 --> Utf8 Class Initialized
DEBUG - 2011-08-04 12:02:12 --> UTF-8 Support Enabled
DEBUG - 2011-08-04 12:02:12 --> URI Class Initialized
DEBUG - 2011-08-04 12:02:12 --> Router Class Initialized
ERROR - 2011-08-04 12:02:12 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-04 12:02:13 --> Config Class Initialized
DEBUG - 2011-08-04 12:02:13 --> Hooks Class Initialized
DEBUG - 2011-08-04 12:02:13 --> Utf8 Class Initialized
DEBUG - 2011-08-04 12:02:13 --> UTF-8 Support Enabled
DEBUG - 2011-08-04 12:02:13 --> URI Class Initialized
DEBUG - 2011-08-04 12:02:13 --> Router Class Initialized
ERROR - 2011-08-04 12:02:13 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-04 12:02:50 --> Config Class Initialized
DEBUG - 2011-08-04 12:02:50 --> Hooks Class Initialized
DEBUG - 2011-08-04 12:02:50 --> Utf8 Class Initialized
DEBUG - 2011-08-04 12:02:50 --> UTF-8 Support Enabled
DEBUG - 2011-08-04 12:02:50 --> URI Class Initialized
DEBUG - 2011-08-04 12:02:50 --> Router Class Initialized
DEBUG - 2011-08-04 12:02:50 --> Output Class Initialized
DEBUG - 2011-08-04 12:02:50 --> Input Class Initialized
DEBUG - 2011-08-04 12:02:50 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-04 12:02:50 --> Language Class Initialized
DEBUG - 2011-08-04 12:02:50 --> Loader Class Initialized
DEBUG - 2011-08-04 12:02:50 --> Controller Class Initialized
ERROR - 2011-08-04 12:02:50 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-04 12:02:50 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-04 12:02:50 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-04 12:02:50 --> Model Class Initialized
DEBUG - 2011-08-04 12:02:50 --> Model Class Initialized
DEBUG - 2011-08-04 12:02:50 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-04 12:02:50 --> Database Driver Class Initialized
DEBUG - 2011-08-04 12:02:50 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-04 12:02:50 --> Helper loaded: url_helper
DEBUG - 2011-08-04 12:02:50 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-04 12:02:50 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-04 12:02:50 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-04 12:02:50 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-04 12:02:50 --> Final output sent to browser
DEBUG - 2011-08-04 12:02:50 --> Total execution time: 0.0285
DEBUG - 2011-08-04 12:02:51 --> Config Class Initialized
DEBUG - 2011-08-04 12:02:51 --> Hooks Class Initialized
DEBUG - 2011-08-04 12:02:51 --> Utf8 Class Initialized
DEBUG - 2011-08-04 12:02:51 --> UTF-8 Support Enabled
DEBUG - 2011-08-04 12:02:51 --> URI Class Initialized
DEBUG - 2011-08-04 12:02:51 --> Router Class Initialized
DEBUG - 2011-08-04 12:02:51 --> Output Class Initialized
DEBUG - 2011-08-04 12:02:51 --> Input Class Initialized
DEBUG - 2011-08-04 12:02:51 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-04 12:02:51 --> Language Class Initialized
DEBUG - 2011-08-04 12:02:51 --> Loader Class Initialized
DEBUG - 2011-08-04 12:02:51 --> Controller Class Initialized
DEBUG - 2011-08-04 12:02:51 --> Model Class Initialized
DEBUG - 2011-08-04 12:02:51 --> Model Class Initialized
DEBUG - 2011-08-04 12:02:51 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-04 12:02:51 --> Database Driver Class Initialized
DEBUG - 2011-08-04 12:02:52 --> Final output sent to browser
DEBUG - 2011-08-04 12:02:52 --> Total execution time: 1.2304
DEBUG - 2011-08-04 12:02:52 --> Config Class Initialized
DEBUG - 2011-08-04 12:02:52 --> Hooks Class Initialized
DEBUG - 2011-08-04 12:02:52 --> Utf8 Class Initialized
DEBUG - 2011-08-04 12:02:52 --> UTF-8 Support Enabled
DEBUG - 2011-08-04 12:02:52 --> URI Class Initialized
DEBUG - 2011-08-04 12:02:52 --> Router Class Initialized
ERROR - 2011-08-04 12:02:52 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-04 14:11:10 --> Config Class Initialized
DEBUG - 2011-08-04 14:11:10 --> Hooks Class Initialized
DEBUG - 2011-08-04 14:11:10 --> Utf8 Class Initialized
DEBUG - 2011-08-04 14:11:10 --> UTF-8 Support Enabled
DEBUG - 2011-08-04 14:11:10 --> URI Class Initialized
DEBUG - 2011-08-04 14:11:10 --> Router Class Initialized
ERROR - 2011-08-04 14:11:10 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-08-04 14:18:56 --> Config Class Initialized
DEBUG - 2011-08-04 14:18:56 --> Hooks Class Initialized
DEBUG - 2011-08-04 14:18:56 --> Utf8 Class Initialized
DEBUG - 2011-08-04 14:18:56 --> UTF-8 Support Enabled
DEBUG - 2011-08-04 14:18:56 --> URI Class Initialized
DEBUG - 2011-08-04 14:18:56 --> Router Class Initialized
ERROR - 2011-08-04 14:18:56 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-08-04 14:39:58 --> Config Class Initialized
DEBUG - 2011-08-04 14:39:58 --> Hooks Class Initialized
DEBUG - 2011-08-04 14:39:58 --> Utf8 Class Initialized
DEBUG - 2011-08-04 14:39:58 --> UTF-8 Support Enabled
DEBUG - 2011-08-04 14:39:58 --> URI Class Initialized
DEBUG - 2011-08-04 14:39:58 --> Router Class Initialized
DEBUG - 2011-08-04 14:39:58 --> Output Class Initialized
DEBUG - 2011-08-04 14:39:58 --> Input Class Initialized
DEBUG - 2011-08-04 14:39:58 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-04 14:39:58 --> Language Class Initialized
DEBUG - 2011-08-04 14:39:58 --> Loader Class Initialized
DEBUG - 2011-08-04 14:39:58 --> Controller Class Initialized
ERROR - 2011-08-04 14:39:58 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-04 14:39:58 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-04 14:39:58 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-04 14:39:58 --> Model Class Initialized
DEBUG - 2011-08-04 14:39:58 --> Model Class Initialized
DEBUG - 2011-08-04 14:39:58 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-04 14:39:58 --> Database Driver Class Initialized
DEBUG - 2011-08-04 14:39:58 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-04 14:39:58 --> Helper loaded: url_helper
DEBUG - 2011-08-04 14:39:58 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-04 14:39:58 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-04 14:39:58 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-04 14:39:58 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-04 14:39:58 --> Final output sent to browser
DEBUG - 2011-08-04 14:39:58 --> Total execution time: 0.0773
DEBUG - 2011-08-04 14:39:59 --> Config Class Initialized
DEBUG - 2011-08-04 14:39:59 --> Hooks Class Initialized
DEBUG - 2011-08-04 14:39:59 --> Utf8 Class Initialized
DEBUG - 2011-08-04 14:39:59 --> UTF-8 Support Enabled
DEBUG - 2011-08-04 14:39:59 --> URI Class Initialized
DEBUG - 2011-08-04 14:39:59 --> Router Class Initialized
DEBUG - 2011-08-04 14:39:59 --> Output Class Initialized
DEBUG - 2011-08-04 14:39:59 --> Input Class Initialized
DEBUG - 2011-08-04 14:39:59 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-04 14:39:59 --> Language Class Initialized
DEBUG - 2011-08-04 14:39:59 --> Loader Class Initialized
DEBUG - 2011-08-04 14:39:59 --> Controller Class Initialized
DEBUG - 2011-08-04 14:39:59 --> Model Class Initialized
DEBUG - 2011-08-04 14:39:59 --> Model Class Initialized
DEBUG - 2011-08-04 14:39:59 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-04 14:39:59 --> Database Driver Class Initialized
DEBUG - 2011-08-04 14:39:59 --> Final output sent to browser
DEBUG - 2011-08-04 14:39:59 --> Total execution time: 0.7591
DEBUG - 2011-08-04 14:40:00 --> Config Class Initialized
DEBUG - 2011-08-04 14:40:00 --> Hooks Class Initialized
DEBUG - 2011-08-04 14:40:00 --> Utf8 Class Initialized
DEBUG - 2011-08-04 14:40:00 --> UTF-8 Support Enabled
DEBUG - 2011-08-04 14:40:00 --> URI Class Initialized
DEBUG - 2011-08-04 14:40:00 --> Router Class Initialized
ERROR - 2011-08-04 14:40:00 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-04 14:40:00 --> Config Class Initialized
DEBUG - 2011-08-04 14:40:00 --> Hooks Class Initialized
DEBUG - 2011-08-04 14:40:00 --> Utf8 Class Initialized
DEBUG - 2011-08-04 14:40:00 --> UTF-8 Support Enabled
DEBUG - 2011-08-04 14:40:00 --> URI Class Initialized
DEBUG - 2011-08-04 14:40:00 --> Router Class Initialized
ERROR - 2011-08-04 14:40:00 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-04 14:40:20 --> Config Class Initialized
DEBUG - 2011-08-04 14:40:20 --> Hooks Class Initialized
DEBUG - 2011-08-04 14:40:20 --> Utf8 Class Initialized
DEBUG - 2011-08-04 14:40:20 --> UTF-8 Support Enabled
DEBUG - 2011-08-04 14:40:20 --> URI Class Initialized
DEBUG - 2011-08-04 14:40:20 --> Router Class Initialized
DEBUG - 2011-08-04 14:40:20 --> Output Class Initialized
DEBUG - 2011-08-04 14:40:20 --> Input Class Initialized
DEBUG - 2011-08-04 14:40:20 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-04 14:40:20 --> Language Class Initialized
DEBUG - 2011-08-04 14:40:20 --> Loader Class Initialized
DEBUG - 2011-08-04 14:40:20 --> Controller Class Initialized
ERROR - 2011-08-04 14:40:20 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-04 14:40:20 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-04 14:40:20 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-04 14:40:20 --> Model Class Initialized
DEBUG - 2011-08-04 14:40:20 --> Model Class Initialized
DEBUG - 2011-08-04 14:40:20 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-04 14:40:20 --> Database Driver Class Initialized
DEBUG - 2011-08-04 14:40:20 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-04 14:40:20 --> Helper loaded: url_helper
DEBUG - 2011-08-04 14:40:20 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-04 14:40:20 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-04 14:40:20 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-04 14:40:20 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-04 14:40:20 --> Final output sent to browser
DEBUG - 2011-08-04 14:40:20 --> Total execution time: 0.0511
DEBUG - 2011-08-04 14:40:20 --> Config Class Initialized
DEBUG - 2011-08-04 14:40:20 --> Hooks Class Initialized
DEBUG - 2011-08-04 14:40:20 --> Utf8 Class Initialized
DEBUG - 2011-08-04 14:40:20 --> UTF-8 Support Enabled
DEBUG - 2011-08-04 14:40:20 --> URI Class Initialized
DEBUG - 2011-08-04 14:40:20 --> Router Class Initialized
DEBUG - 2011-08-04 14:40:20 --> Output Class Initialized
DEBUG - 2011-08-04 14:40:20 --> Input Class Initialized
DEBUG - 2011-08-04 14:40:20 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-04 14:40:20 --> Language Class Initialized
DEBUG - 2011-08-04 14:40:20 --> Loader Class Initialized
DEBUG - 2011-08-04 14:40:20 --> Controller Class Initialized
DEBUG - 2011-08-04 14:40:20 --> Model Class Initialized
DEBUG - 2011-08-04 14:40:20 --> Model Class Initialized
DEBUG - 2011-08-04 14:40:20 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-04 14:40:20 --> Database Driver Class Initialized
DEBUG - 2011-08-04 14:40:21 --> Final output sent to browser
DEBUG - 2011-08-04 14:40:21 --> Total execution time: 0.7991
DEBUG - 2011-08-04 14:40:22 --> Config Class Initialized
DEBUG - 2011-08-04 14:40:22 --> Hooks Class Initialized
DEBUG - 2011-08-04 14:40:22 --> Utf8 Class Initialized
DEBUG - 2011-08-04 14:40:22 --> UTF-8 Support Enabled
DEBUG - 2011-08-04 14:40:22 --> URI Class Initialized
DEBUG - 2011-08-04 14:40:22 --> Router Class Initialized
DEBUG - 2011-08-04 14:40:22 --> Output Class Initialized
DEBUG - 2011-08-04 14:40:22 --> Input Class Initialized
DEBUG - 2011-08-04 14:40:22 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-04 14:40:22 --> Language Class Initialized
DEBUG - 2011-08-04 14:40:22 --> Loader Class Initialized
DEBUG - 2011-08-04 14:40:22 --> Controller Class Initialized
ERROR - 2011-08-04 14:40:22 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-04 14:40:22 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-04 14:40:22 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-04 14:40:22 --> Model Class Initialized
DEBUG - 2011-08-04 14:40:22 --> Model Class Initialized
DEBUG - 2011-08-04 14:40:22 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-04 14:40:22 --> Database Driver Class Initialized
DEBUG - 2011-08-04 14:40:22 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-04 14:40:22 --> Helper loaded: url_helper
DEBUG - 2011-08-04 14:40:22 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-04 14:40:22 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-04 14:40:22 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-04 14:40:22 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-04 14:40:22 --> Final output sent to browser
DEBUG - 2011-08-04 14:40:22 --> Total execution time: 0.0306
DEBUG - 2011-08-04 14:40:28 --> Config Class Initialized
DEBUG - 2011-08-04 14:40:28 --> Hooks Class Initialized
DEBUG - 2011-08-04 14:40:28 --> Utf8 Class Initialized
DEBUG - 2011-08-04 14:40:28 --> UTF-8 Support Enabled
DEBUG - 2011-08-04 14:40:28 --> URI Class Initialized
DEBUG - 2011-08-04 14:40:28 --> Router Class Initialized
DEBUG - 2011-08-04 14:40:28 --> Output Class Initialized
DEBUG - 2011-08-04 14:40:28 --> Input Class Initialized
DEBUG - 2011-08-04 14:40:28 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-04 14:40:28 --> Language Class Initialized
DEBUG - 2011-08-04 14:40:28 --> Loader Class Initialized
DEBUG - 2011-08-04 14:40:28 --> Controller Class Initialized
ERROR - 2011-08-04 14:40:28 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-04 14:40:28 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-04 14:40:28 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-04 14:40:28 --> Model Class Initialized
DEBUG - 2011-08-04 14:40:28 --> Model Class Initialized
DEBUG - 2011-08-04 14:40:28 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-04 14:40:28 --> Database Driver Class Initialized
DEBUG - 2011-08-04 14:40:28 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-04 14:40:28 --> Helper loaded: url_helper
DEBUG - 2011-08-04 14:40:28 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-04 14:40:28 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-04 14:40:28 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-04 14:40:28 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-04 14:40:28 --> Final output sent to browser
DEBUG - 2011-08-04 14:40:28 --> Total execution time: 0.0299
DEBUG - 2011-08-04 14:40:28 --> Config Class Initialized
DEBUG - 2011-08-04 14:40:28 --> Hooks Class Initialized
DEBUG - 2011-08-04 14:40:28 --> Utf8 Class Initialized
DEBUG - 2011-08-04 14:40:28 --> UTF-8 Support Enabled
DEBUG - 2011-08-04 14:40:28 --> URI Class Initialized
DEBUG - 2011-08-04 14:40:28 --> Router Class Initialized
DEBUG - 2011-08-04 14:40:28 --> Output Class Initialized
DEBUG - 2011-08-04 14:40:28 --> Input Class Initialized
DEBUG - 2011-08-04 14:40:28 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-04 14:40:28 --> Language Class Initialized
DEBUG - 2011-08-04 14:40:28 --> Loader Class Initialized
DEBUG - 2011-08-04 14:40:28 --> Controller Class Initialized
DEBUG - 2011-08-04 14:40:28 --> Model Class Initialized
DEBUG - 2011-08-04 14:40:28 --> Model Class Initialized
DEBUG - 2011-08-04 14:40:28 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-04 14:40:28 --> Database Driver Class Initialized
DEBUG - 2011-08-04 14:40:29 --> Final output sent to browser
DEBUG - 2011-08-04 14:40:29 --> Total execution time: 0.5636
DEBUG - 2011-08-04 14:40:30 --> Config Class Initialized
DEBUG - 2011-08-04 14:40:30 --> Hooks Class Initialized
DEBUG - 2011-08-04 14:40:30 --> Utf8 Class Initialized
DEBUG - 2011-08-04 14:40:30 --> UTF-8 Support Enabled
DEBUG - 2011-08-04 14:40:30 --> URI Class Initialized
DEBUG - 2011-08-04 14:40:30 --> Router Class Initialized
DEBUG - 2011-08-04 14:40:30 --> Output Class Initialized
DEBUG - 2011-08-04 14:40:30 --> Input Class Initialized
DEBUG - 2011-08-04 14:40:30 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-04 14:40:30 --> Language Class Initialized
DEBUG - 2011-08-04 14:40:30 --> Loader Class Initialized
DEBUG - 2011-08-04 14:40:30 --> Controller Class Initialized
ERROR - 2011-08-04 14:40:30 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-04 14:40:30 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-04 14:40:30 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-04 14:40:30 --> Model Class Initialized
DEBUG - 2011-08-04 14:40:30 --> Model Class Initialized
DEBUG - 2011-08-04 14:40:30 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-04 14:40:30 --> Database Driver Class Initialized
DEBUG - 2011-08-04 14:40:30 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-04 14:40:30 --> Helper loaded: url_helper
DEBUG - 2011-08-04 14:40:30 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-04 14:40:30 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-04 14:40:30 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-04 14:40:30 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-04 14:40:30 --> Final output sent to browser
DEBUG - 2011-08-04 14:40:30 --> Total execution time: 0.1289
DEBUG - 2011-08-04 14:40:35 --> Config Class Initialized
DEBUG - 2011-08-04 14:40:35 --> Hooks Class Initialized
DEBUG - 2011-08-04 14:40:35 --> Utf8 Class Initialized
DEBUG - 2011-08-04 14:40:35 --> UTF-8 Support Enabled
DEBUG - 2011-08-04 14:40:35 --> URI Class Initialized
DEBUG - 2011-08-04 14:40:35 --> Router Class Initialized
DEBUG - 2011-08-04 14:40:35 --> Output Class Initialized
DEBUG - 2011-08-04 14:40:35 --> Input Class Initialized
DEBUG - 2011-08-04 14:40:35 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-04 14:40:35 --> Language Class Initialized
DEBUG - 2011-08-04 14:40:35 --> Loader Class Initialized
DEBUG - 2011-08-04 14:40:35 --> Controller Class Initialized
ERROR - 2011-08-04 14:40:35 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-04 14:40:35 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-04 14:40:35 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-04 14:40:35 --> Model Class Initialized
DEBUG - 2011-08-04 14:40:35 --> Model Class Initialized
DEBUG - 2011-08-04 14:40:35 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-04 14:40:35 --> Database Driver Class Initialized
DEBUG - 2011-08-04 14:40:35 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-04 14:40:35 --> Helper loaded: url_helper
DEBUG - 2011-08-04 14:40:35 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-04 14:40:35 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-04 14:40:35 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-04 14:40:35 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-04 14:40:35 --> Final output sent to browser
DEBUG - 2011-08-04 14:40:35 --> Total execution time: 0.0304
DEBUG - 2011-08-04 14:40:36 --> Config Class Initialized
DEBUG - 2011-08-04 14:40:36 --> Hooks Class Initialized
DEBUG - 2011-08-04 14:40:36 --> Utf8 Class Initialized
DEBUG - 2011-08-04 14:40:36 --> UTF-8 Support Enabled
DEBUG - 2011-08-04 14:40:36 --> URI Class Initialized
DEBUG - 2011-08-04 14:40:36 --> Router Class Initialized
DEBUG - 2011-08-04 14:40:36 --> Output Class Initialized
DEBUG - 2011-08-04 14:40:36 --> Input Class Initialized
DEBUG - 2011-08-04 14:40:36 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-04 14:40:36 --> Language Class Initialized
DEBUG - 2011-08-04 14:40:36 --> Loader Class Initialized
DEBUG - 2011-08-04 14:40:36 --> Controller Class Initialized
DEBUG - 2011-08-04 14:40:36 --> Model Class Initialized
DEBUG - 2011-08-04 14:40:36 --> Model Class Initialized
DEBUG - 2011-08-04 14:40:36 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-04 14:40:36 --> Database Driver Class Initialized
DEBUG - 2011-08-04 14:40:36 --> Final output sent to browser
DEBUG - 2011-08-04 14:40:36 --> Total execution time: 0.5636
DEBUG - 2011-08-04 15:11:04 --> Config Class Initialized
DEBUG - 2011-08-04 15:11:04 --> Hooks Class Initialized
DEBUG - 2011-08-04 15:11:04 --> Utf8 Class Initialized
DEBUG - 2011-08-04 15:11:04 --> UTF-8 Support Enabled
DEBUG - 2011-08-04 15:11:04 --> URI Class Initialized
DEBUG - 2011-08-04 15:11:04 --> Router Class Initialized
DEBUG - 2011-08-04 15:11:04 --> Output Class Initialized
DEBUG - 2011-08-04 15:11:04 --> Input Class Initialized
DEBUG - 2011-08-04 15:11:04 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-04 15:11:04 --> Language Class Initialized
DEBUG - 2011-08-04 15:11:04 --> Loader Class Initialized
DEBUG - 2011-08-04 15:11:04 --> Controller Class Initialized
ERROR - 2011-08-04 15:11:04 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-04 15:11:04 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-04 15:11:04 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-04 15:11:04 --> Model Class Initialized
DEBUG - 2011-08-04 15:11:04 --> Model Class Initialized
DEBUG - 2011-08-04 15:11:04 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-04 15:11:04 --> Database Driver Class Initialized
DEBUG - 2011-08-04 15:11:04 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-04 15:11:04 --> Helper loaded: url_helper
DEBUG - 2011-08-04 15:11:04 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-04 15:11:04 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-04 15:11:04 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-04 15:11:04 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-04 15:11:04 --> Final output sent to browser
DEBUG - 2011-08-04 15:11:04 --> Total execution time: 0.0294
DEBUG - 2011-08-04 15:11:05 --> Config Class Initialized
DEBUG - 2011-08-04 15:11:05 --> Hooks Class Initialized
DEBUG - 2011-08-04 15:11:05 --> Utf8 Class Initialized
DEBUG - 2011-08-04 15:11:05 --> UTF-8 Support Enabled
DEBUG - 2011-08-04 15:11:05 --> URI Class Initialized
DEBUG - 2011-08-04 15:11:05 --> Router Class Initialized
DEBUG - 2011-08-04 15:11:05 --> Output Class Initialized
DEBUG - 2011-08-04 15:11:05 --> Input Class Initialized
DEBUG - 2011-08-04 15:11:05 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-04 15:11:05 --> Language Class Initialized
DEBUG - 2011-08-04 15:11:05 --> Loader Class Initialized
DEBUG - 2011-08-04 15:11:05 --> Controller Class Initialized
DEBUG - 2011-08-04 15:11:05 --> Model Class Initialized
DEBUG - 2011-08-04 15:11:05 --> Model Class Initialized
DEBUG - 2011-08-04 15:11:05 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-04 15:11:05 --> Database Driver Class Initialized
DEBUG - 2011-08-04 15:11:06 --> Final output sent to browser
DEBUG - 2011-08-04 15:11:06 --> Total execution time: 0.5529
DEBUG - 2011-08-04 15:11:07 --> Config Class Initialized
DEBUG - 2011-08-04 15:11:07 --> Hooks Class Initialized
DEBUG - 2011-08-04 15:11:07 --> Utf8 Class Initialized
DEBUG - 2011-08-04 15:11:07 --> UTF-8 Support Enabled
DEBUG - 2011-08-04 15:11:07 --> URI Class Initialized
DEBUG - 2011-08-04 15:11:07 --> Router Class Initialized
ERROR - 2011-08-04 15:11:07 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-04 15:18:00 --> Config Class Initialized
DEBUG - 2011-08-04 15:18:00 --> Hooks Class Initialized
DEBUG - 2011-08-04 15:18:00 --> Utf8 Class Initialized
DEBUG - 2011-08-04 15:18:00 --> UTF-8 Support Enabled
DEBUG - 2011-08-04 15:18:00 --> URI Class Initialized
DEBUG - 2011-08-04 15:18:00 --> Router Class Initialized
DEBUG - 2011-08-04 15:18:00 --> Output Class Initialized
DEBUG - 2011-08-04 15:18:00 --> Input Class Initialized
DEBUG - 2011-08-04 15:18:00 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-04 15:18:00 --> Language Class Initialized
DEBUG - 2011-08-04 15:18:00 --> Loader Class Initialized
DEBUG - 2011-08-04 15:18:00 --> Controller Class Initialized
ERROR - 2011-08-04 15:18:00 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-04 15:18:00 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-04 15:18:00 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-04 15:18:00 --> Model Class Initialized
DEBUG - 2011-08-04 15:18:00 --> Model Class Initialized
DEBUG - 2011-08-04 15:18:00 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-04 15:18:00 --> Database Driver Class Initialized
DEBUG - 2011-08-04 15:18:00 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-04 15:18:00 --> Helper loaded: url_helper
DEBUG - 2011-08-04 15:18:00 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-04 15:18:00 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-04 15:18:00 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-04 15:18:00 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-04 15:18:00 --> Final output sent to browser
DEBUG - 2011-08-04 15:18:00 --> Total execution time: 0.0297
DEBUG - 2011-08-04 15:18:01 --> Config Class Initialized
DEBUG - 2011-08-04 15:18:01 --> Hooks Class Initialized
DEBUG - 2011-08-04 15:18:01 --> Utf8 Class Initialized
DEBUG - 2011-08-04 15:18:01 --> UTF-8 Support Enabled
DEBUG - 2011-08-04 15:18:01 --> URI Class Initialized
DEBUG - 2011-08-04 15:18:01 --> Router Class Initialized
DEBUG - 2011-08-04 15:18:01 --> Output Class Initialized
DEBUG - 2011-08-04 15:18:01 --> Input Class Initialized
DEBUG - 2011-08-04 15:18:01 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-04 15:18:01 --> Language Class Initialized
DEBUG - 2011-08-04 15:18:01 --> Loader Class Initialized
DEBUG - 2011-08-04 15:18:01 --> Controller Class Initialized
DEBUG - 2011-08-04 15:18:01 --> Model Class Initialized
DEBUG - 2011-08-04 15:18:01 --> Model Class Initialized
DEBUG - 2011-08-04 15:18:01 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-04 15:18:01 --> Database Driver Class Initialized
DEBUG - 2011-08-04 15:18:02 --> Final output sent to browser
DEBUG - 2011-08-04 15:18:02 --> Total execution time: 0.5507
DEBUG - 2011-08-04 15:18:03 --> Config Class Initialized
DEBUG - 2011-08-04 15:18:03 --> Hooks Class Initialized
DEBUG - 2011-08-04 15:18:03 --> Utf8 Class Initialized
DEBUG - 2011-08-04 15:18:03 --> UTF-8 Support Enabled
DEBUG - 2011-08-04 15:18:03 --> URI Class Initialized
DEBUG - 2011-08-04 15:18:03 --> Router Class Initialized
ERROR - 2011-08-04 15:18:03 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-04 15:18:20 --> Config Class Initialized
DEBUG - 2011-08-04 15:18:20 --> Hooks Class Initialized
DEBUG - 2011-08-04 15:18:20 --> Utf8 Class Initialized
DEBUG - 2011-08-04 15:18:20 --> UTF-8 Support Enabled
DEBUG - 2011-08-04 15:18:20 --> URI Class Initialized
DEBUG - 2011-08-04 15:18:20 --> Router Class Initialized
DEBUG - 2011-08-04 15:18:20 --> Output Class Initialized
DEBUG - 2011-08-04 15:18:20 --> Input Class Initialized
DEBUG - 2011-08-04 15:18:20 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-04 15:18:20 --> Language Class Initialized
DEBUG - 2011-08-04 15:18:20 --> Loader Class Initialized
DEBUG - 2011-08-04 15:18:20 --> Controller Class Initialized
ERROR - 2011-08-04 15:18:20 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-04 15:18:20 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-04 15:18:20 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-04 15:18:20 --> Model Class Initialized
DEBUG - 2011-08-04 15:18:20 --> Model Class Initialized
DEBUG - 2011-08-04 15:18:20 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-04 15:18:20 --> Database Driver Class Initialized
DEBUG - 2011-08-04 15:18:20 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-04 15:18:20 --> Helper loaded: url_helper
DEBUG - 2011-08-04 15:18:20 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-04 15:18:20 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-04 15:18:20 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-04 15:18:20 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-04 15:18:20 --> Final output sent to browser
DEBUG - 2011-08-04 15:18:20 --> Total execution time: 0.0600
DEBUG - 2011-08-04 15:18:20 --> Config Class Initialized
DEBUG - 2011-08-04 15:18:20 --> Hooks Class Initialized
DEBUG - 2011-08-04 15:18:20 --> Utf8 Class Initialized
DEBUG - 2011-08-04 15:18:20 --> UTF-8 Support Enabled
DEBUG - 2011-08-04 15:18:20 --> URI Class Initialized
DEBUG - 2011-08-04 15:18:20 --> Router Class Initialized
DEBUG - 2011-08-04 15:18:20 --> Output Class Initialized
DEBUG - 2011-08-04 15:18:20 --> Input Class Initialized
DEBUG - 2011-08-04 15:18:20 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-04 15:18:20 --> Language Class Initialized
DEBUG - 2011-08-04 15:18:20 --> Loader Class Initialized
DEBUG - 2011-08-04 15:18:20 --> Controller Class Initialized
DEBUG - 2011-08-04 15:18:20 --> Model Class Initialized
DEBUG - 2011-08-04 15:18:20 --> Model Class Initialized
DEBUG - 2011-08-04 15:18:20 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-04 15:18:20 --> Database Driver Class Initialized
DEBUG - 2011-08-04 15:18:21 --> Config Class Initialized
DEBUG - 2011-08-04 15:18:21 --> Hooks Class Initialized
DEBUG - 2011-08-04 15:18:21 --> Utf8 Class Initialized
DEBUG - 2011-08-04 15:18:21 --> UTF-8 Support Enabled
DEBUG - 2011-08-04 15:18:21 --> URI Class Initialized
DEBUG - 2011-08-04 15:18:21 --> Router Class Initialized
DEBUG - 2011-08-04 15:18:21 --> Output Class Initialized
DEBUG - 2011-08-04 15:18:21 --> Input Class Initialized
DEBUG - 2011-08-04 15:18:21 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-04 15:18:21 --> Language Class Initialized
DEBUG - 2011-08-04 15:18:21 --> Loader Class Initialized
DEBUG - 2011-08-04 15:18:21 --> Controller Class Initialized
ERROR - 2011-08-04 15:18:21 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-04 15:18:21 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-04 15:18:21 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-04 15:18:21 --> Model Class Initialized
DEBUG - 2011-08-04 15:18:21 --> Model Class Initialized
DEBUG - 2011-08-04 15:18:21 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-04 15:18:21 --> Database Driver Class Initialized
DEBUG - 2011-08-04 15:18:21 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-04 15:18:21 --> Helper loaded: url_helper
DEBUG - 2011-08-04 15:18:21 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-04 15:18:21 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-04 15:18:21 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-04 15:18:21 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-04 15:18:21 --> Final output sent to browser
DEBUG - 2011-08-04 15:18:21 --> Total execution time: 0.0333
DEBUG - 2011-08-04 15:18:21 --> Final output sent to browser
DEBUG - 2011-08-04 15:18:21 --> Total execution time: 0.5550
DEBUG - 2011-08-04 15:18:22 --> Config Class Initialized
DEBUG - 2011-08-04 15:18:22 --> Hooks Class Initialized
DEBUG - 2011-08-04 15:18:22 --> Utf8 Class Initialized
DEBUG - 2011-08-04 15:18:22 --> UTF-8 Support Enabled
DEBUG - 2011-08-04 15:18:22 --> URI Class Initialized
DEBUG - 2011-08-04 15:18:22 --> Router Class Initialized
ERROR - 2011-08-04 15:18:22 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-04 15:18:36 --> Config Class Initialized
DEBUG - 2011-08-04 15:18:36 --> Hooks Class Initialized
DEBUG - 2011-08-04 15:18:36 --> Utf8 Class Initialized
DEBUG - 2011-08-04 15:18:36 --> UTF-8 Support Enabled
DEBUG - 2011-08-04 15:18:36 --> URI Class Initialized
DEBUG - 2011-08-04 15:18:36 --> Router Class Initialized
DEBUG - 2011-08-04 15:18:36 --> Output Class Initialized
DEBUG - 2011-08-04 15:18:36 --> Input Class Initialized
DEBUG - 2011-08-04 15:18:36 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-04 15:18:36 --> Language Class Initialized
DEBUG - 2011-08-04 15:18:36 --> Loader Class Initialized
DEBUG - 2011-08-04 15:18:36 --> Controller Class Initialized
ERROR - 2011-08-04 15:18:36 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-04 15:18:36 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-04 15:18:36 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-04 15:18:36 --> Model Class Initialized
DEBUG - 2011-08-04 15:18:36 --> Model Class Initialized
DEBUG - 2011-08-04 15:18:36 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-04 15:18:36 --> Database Driver Class Initialized
DEBUG - 2011-08-04 15:18:36 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-04 15:18:36 --> Helper loaded: url_helper
DEBUG - 2011-08-04 15:18:36 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-04 15:18:36 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-04 15:18:36 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-04 15:18:36 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-04 15:18:36 --> Final output sent to browser
DEBUG - 2011-08-04 15:18:36 --> Total execution time: 0.0365
DEBUG - 2011-08-04 15:18:37 --> Config Class Initialized
DEBUG - 2011-08-04 15:18:37 --> Hooks Class Initialized
DEBUG - 2011-08-04 15:18:37 --> Utf8 Class Initialized
DEBUG - 2011-08-04 15:18:37 --> UTF-8 Support Enabled
DEBUG - 2011-08-04 15:18:37 --> URI Class Initialized
DEBUG - 2011-08-04 15:18:37 --> Router Class Initialized
DEBUG - 2011-08-04 15:18:37 --> Output Class Initialized
DEBUG - 2011-08-04 15:18:37 --> Input Class Initialized
DEBUG - 2011-08-04 15:18:37 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-04 15:18:37 --> Language Class Initialized
DEBUG - 2011-08-04 15:18:37 --> Loader Class Initialized
DEBUG - 2011-08-04 15:18:37 --> Controller Class Initialized
DEBUG - 2011-08-04 15:18:37 --> Model Class Initialized
DEBUG - 2011-08-04 15:18:37 --> Model Class Initialized
DEBUG - 2011-08-04 15:18:37 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-04 15:18:37 --> Database Driver Class Initialized
DEBUG - 2011-08-04 15:18:38 --> Config Class Initialized
DEBUG - 2011-08-04 15:18:38 --> Hooks Class Initialized
DEBUG - 2011-08-04 15:18:38 --> Utf8 Class Initialized
DEBUG - 2011-08-04 15:18:38 --> UTF-8 Support Enabled
DEBUG - 2011-08-04 15:18:38 --> URI Class Initialized
DEBUG - 2011-08-04 15:18:38 --> Router Class Initialized
DEBUG - 2011-08-04 15:18:38 --> Output Class Initialized
DEBUG - 2011-08-04 15:18:38 --> Input Class Initialized
DEBUG - 2011-08-04 15:18:38 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-04 15:18:38 --> Language Class Initialized
DEBUG - 2011-08-04 15:18:38 --> Loader Class Initialized
DEBUG - 2011-08-04 15:18:38 --> Controller Class Initialized
ERROR - 2011-08-04 15:18:38 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-04 15:18:38 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-04 15:18:38 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-04 15:18:38 --> Model Class Initialized
DEBUG - 2011-08-04 15:18:38 --> Model Class Initialized
DEBUG - 2011-08-04 15:18:38 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-04 15:18:38 --> Database Driver Class Initialized
DEBUG - 2011-08-04 15:18:38 --> Final output sent to browser
DEBUG - 2011-08-04 15:18:38 --> Total execution time: 0.5506
DEBUG - 2011-08-04 15:18:38 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-04 15:18:38 --> Helper loaded: url_helper
DEBUG - 2011-08-04 15:18:38 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-04 15:18:38 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-04 15:18:38 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-04 15:18:38 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-04 15:18:38 --> Final output sent to browser
DEBUG - 2011-08-04 15:18:38 --> Total execution time: 0.0279
DEBUG - 2011-08-04 15:18:39 --> Config Class Initialized
DEBUG - 2011-08-04 15:18:39 --> Hooks Class Initialized
DEBUG - 2011-08-04 15:18:39 --> Utf8 Class Initialized
DEBUG - 2011-08-04 15:18:39 --> UTF-8 Support Enabled
DEBUG - 2011-08-04 15:18:39 --> URI Class Initialized
DEBUG - 2011-08-04 15:18:39 --> Router Class Initialized
ERROR - 2011-08-04 15:18:39 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-04 15:18:50 --> Config Class Initialized
DEBUG - 2011-08-04 15:18:50 --> Hooks Class Initialized
DEBUG - 2011-08-04 15:18:50 --> Utf8 Class Initialized
DEBUG - 2011-08-04 15:18:50 --> UTF-8 Support Enabled
DEBUG - 2011-08-04 15:18:50 --> URI Class Initialized
DEBUG - 2011-08-04 15:18:50 --> Router Class Initialized
DEBUG - 2011-08-04 15:18:50 --> Output Class Initialized
DEBUG - 2011-08-04 15:18:50 --> Input Class Initialized
DEBUG - 2011-08-04 15:18:50 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-04 15:18:50 --> Language Class Initialized
DEBUG - 2011-08-04 15:18:50 --> Loader Class Initialized
DEBUG - 2011-08-04 15:18:50 --> Controller Class Initialized
ERROR - 2011-08-04 15:18:50 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-04 15:18:50 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-04 15:18:50 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-04 15:18:50 --> Model Class Initialized
DEBUG - 2011-08-04 15:18:50 --> Model Class Initialized
DEBUG - 2011-08-04 15:18:50 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-04 15:18:50 --> Database Driver Class Initialized
DEBUG - 2011-08-04 15:18:50 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-04 15:18:50 --> Helper loaded: url_helper
DEBUG - 2011-08-04 15:18:50 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-04 15:18:50 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-04 15:18:50 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-04 15:18:50 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-04 15:18:50 --> Final output sent to browser
DEBUG - 2011-08-04 15:18:50 --> Total execution time: 0.0330
DEBUG - 2011-08-04 15:18:50 --> Config Class Initialized
DEBUG - 2011-08-04 15:18:50 --> Hooks Class Initialized
DEBUG - 2011-08-04 15:18:50 --> Utf8 Class Initialized
DEBUG - 2011-08-04 15:18:50 --> UTF-8 Support Enabled
DEBUG - 2011-08-04 15:18:50 --> URI Class Initialized
DEBUG - 2011-08-04 15:18:50 --> Router Class Initialized
DEBUG - 2011-08-04 15:18:50 --> Output Class Initialized
DEBUG - 2011-08-04 15:18:50 --> Input Class Initialized
DEBUG - 2011-08-04 15:18:50 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-04 15:18:50 --> Language Class Initialized
DEBUG - 2011-08-04 15:18:50 --> Loader Class Initialized
DEBUG - 2011-08-04 15:18:50 --> Controller Class Initialized
DEBUG - 2011-08-04 15:18:50 --> Model Class Initialized
DEBUG - 2011-08-04 15:18:50 --> Model Class Initialized
DEBUG - 2011-08-04 15:18:50 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-04 15:18:50 --> Database Driver Class Initialized
DEBUG - 2011-08-04 15:18:51 --> Final output sent to browser
DEBUG - 2011-08-04 15:18:51 --> Total execution time: 0.5803
DEBUG - 2011-08-04 15:18:52 --> Config Class Initialized
DEBUG - 2011-08-04 15:18:52 --> Hooks Class Initialized
DEBUG - 2011-08-04 15:18:52 --> Utf8 Class Initialized
DEBUG - 2011-08-04 15:18:52 --> UTF-8 Support Enabled
DEBUG - 2011-08-04 15:18:52 --> URI Class Initialized
DEBUG - 2011-08-04 15:18:52 --> Router Class Initialized
DEBUG - 2011-08-04 15:18:52 --> Output Class Initialized
DEBUG - 2011-08-04 15:18:52 --> Input Class Initialized
DEBUG - 2011-08-04 15:18:52 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-04 15:18:52 --> Language Class Initialized
DEBUG - 2011-08-04 15:18:52 --> Loader Class Initialized
DEBUG - 2011-08-04 15:18:52 --> Controller Class Initialized
ERROR - 2011-08-04 15:18:52 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-04 15:18:52 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-04 15:18:52 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-04 15:18:52 --> Model Class Initialized
DEBUG - 2011-08-04 15:18:52 --> Model Class Initialized
DEBUG - 2011-08-04 15:18:52 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-04 15:18:52 --> Database Driver Class Initialized
DEBUG - 2011-08-04 15:18:52 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-04 15:18:52 --> Helper loaded: url_helper
DEBUG - 2011-08-04 15:18:52 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-04 15:18:52 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-04 15:18:52 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-04 15:18:52 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-04 15:18:52 --> Final output sent to browser
DEBUG - 2011-08-04 15:18:52 --> Total execution time: 0.0526
DEBUG - 2011-08-04 15:18:52 --> Config Class Initialized
DEBUG - 2011-08-04 15:18:52 --> Hooks Class Initialized
DEBUG - 2011-08-04 15:18:52 --> Utf8 Class Initialized
DEBUG - 2011-08-04 15:18:52 --> UTF-8 Support Enabled
DEBUG - 2011-08-04 15:18:52 --> URI Class Initialized
DEBUG - 2011-08-04 15:18:52 --> Router Class Initialized
ERROR - 2011-08-04 15:18:52 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-04 15:33:25 --> Config Class Initialized
DEBUG - 2011-08-04 15:33:25 --> Hooks Class Initialized
DEBUG - 2011-08-04 15:33:25 --> Utf8 Class Initialized
DEBUG - 2011-08-04 15:33:25 --> UTF-8 Support Enabled
DEBUG - 2011-08-04 15:33:25 --> URI Class Initialized
DEBUG - 2011-08-04 15:33:25 --> Router Class Initialized
DEBUG - 2011-08-04 15:33:25 --> Output Class Initialized
DEBUG - 2011-08-04 15:33:25 --> Input Class Initialized
DEBUG - 2011-08-04 15:33:25 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-04 15:33:25 --> Language Class Initialized
DEBUG - 2011-08-04 15:33:25 --> Loader Class Initialized
DEBUG - 2011-08-04 15:33:25 --> Controller Class Initialized
ERROR - 2011-08-04 15:33:25 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-04 15:33:25 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-04 15:33:25 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-04 15:33:25 --> Model Class Initialized
DEBUG - 2011-08-04 15:33:25 --> Model Class Initialized
DEBUG - 2011-08-04 15:33:25 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-04 15:33:25 --> Database Driver Class Initialized
DEBUG - 2011-08-04 15:33:25 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-04 15:33:25 --> Helper loaded: url_helper
DEBUG - 2011-08-04 15:33:25 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-04 15:33:25 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-04 15:33:25 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-04 15:33:25 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-04 15:33:25 --> Config Class Initialized
DEBUG - 2011-08-04 15:33:25 --> Hooks Class Initialized
DEBUG - 2011-08-04 15:33:25 --> Utf8 Class Initialized
DEBUG - 2011-08-04 15:33:25 --> UTF-8 Support Enabled
DEBUG - 2011-08-04 15:33:25 --> URI Class Initialized
DEBUG - 2011-08-04 15:33:25 --> Router Class Initialized
DEBUG - 2011-08-04 15:33:25 --> Output Class Initialized
DEBUG - 2011-08-04 15:33:25 --> Input Class Initialized
DEBUG - 2011-08-04 15:33:25 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-04 15:33:25 --> Language Class Initialized
DEBUG - 2011-08-04 15:33:25 --> Loader Class Initialized
DEBUG - 2011-08-04 15:33:25 --> Controller Class Initialized
ERROR - 2011-08-04 15:33:25 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-04 15:33:25 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-04 15:33:25 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-04 15:33:25 --> Model Class Initialized
DEBUG - 2011-08-04 15:33:25 --> Model Class Initialized
DEBUG - 2011-08-04 15:33:25 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-04 15:33:25 --> Database Driver Class Initialized
DEBUG - 2011-08-04 15:33:25 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-04 15:33:25 --> Helper loaded: url_helper
DEBUG - 2011-08-04 15:33:25 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-04 15:33:25 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-04 15:33:25 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-04 15:33:25 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-04 15:33:25 --> Final output sent to browser
DEBUG - 2011-08-04 15:33:25 --> Total execution time: 0.0264
DEBUG - 2011-08-04 15:33:29 --> Config Class Initialized
DEBUG - 2011-08-04 15:33:29 --> Hooks Class Initialized
DEBUG - 2011-08-04 15:33:29 --> Utf8 Class Initialized
DEBUG - 2011-08-04 15:33:29 --> UTF-8 Support Enabled
DEBUG - 2011-08-04 15:33:29 --> URI Class Initialized
DEBUG - 2011-08-04 15:33:29 --> Router Class Initialized
DEBUG - 2011-08-04 15:33:29 --> Output Class Initialized
DEBUG - 2011-08-04 15:33:29 --> Input Class Initialized
DEBUG - 2011-08-04 15:33:29 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-04 15:33:29 --> Language Class Initialized
DEBUG - 2011-08-04 15:33:29 --> Loader Class Initialized
DEBUG - 2011-08-04 15:33:29 --> Controller Class Initialized
ERROR - 2011-08-04 15:33:29 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-04 15:33:29 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-04 15:33:29 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-04 15:33:29 --> Model Class Initialized
DEBUG - 2011-08-04 15:33:29 --> Model Class Initialized
DEBUG - 2011-08-04 15:33:29 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-04 15:33:29 --> Database Driver Class Initialized
DEBUG - 2011-08-04 15:33:29 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-04 15:33:29 --> Helper loaded: url_helper
DEBUG - 2011-08-04 15:33:29 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-04 15:33:29 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-04 15:33:29 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-04 15:33:29 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-04 15:40:39 --> Config Class Initialized
DEBUG - 2011-08-04 15:40:39 --> Hooks Class Initialized
DEBUG - 2011-08-04 15:40:39 --> Utf8 Class Initialized
DEBUG - 2011-08-04 15:40:39 --> UTF-8 Support Enabled
DEBUG - 2011-08-04 15:40:39 --> URI Class Initialized
DEBUG - 2011-08-04 15:40:39 --> Router Class Initialized
DEBUG - 2011-08-04 15:40:39 --> Output Class Initialized
DEBUG - 2011-08-04 15:40:39 --> Input Class Initialized
DEBUG - 2011-08-04 15:40:39 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-04 15:40:39 --> Language Class Initialized
DEBUG - 2011-08-04 15:40:39 --> Loader Class Initialized
DEBUG - 2011-08-04 15:40:39 --> Controller Class Initialized
ERROR - 2011-08-04 15:40:39 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-04 15:40:39 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-04 15:40:39 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-04 15:40:39 --> Model Class Initialized
DEBUG - 2011-08-04 15:40:39 --> Model Class Initialized
DEBUG - 2011-08-04 15:40:39 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-04 15:40:39 --> Database Driver Class Initialized
DEBUG - 2011-08-04 15:40:39 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-04 15:40:39 --> Helper loaded: url_helper
DEBUG - 2011-08-04 15:40:39 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-04 15:40:39 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-04 15:40:39 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-04 15:40:39 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-04 15:40:39 --> Final output sent to browser
DEBUG - 2011-08-04 15:40:39 --> Total execution time: 0.0294
DEBUG - 2011-08-04 15:40:40 --> Config Class Initialized
DEBUG - 2011-08-04 15:40:40 --> Hooks Class Initialized
DEBUG - 2011-08-04 15:40:40 --> Utf8 Class Initialized
DEBUG - 2011-08-04 15:40:40 --> UTF-8 Support Enabled
DEBUG - 2011-08-04 15:40:40 --> URI Class Initialized
DEBUG - 2011-08-04 15:40:40 --> Router Class Initialized
DEBUG - 2011-08-04 15:40:40 --> Output Class Initialized
DEBUG - 2011-08-04 15:40:40 --> Input Class Initialized
DEBUG - 2011-08-04 15:40:40 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-04 15:40:40 --> Language Class Initialized
DEBUG - 2011-08-04 15:40:40 --> Loader Class Initialized
DEBUG - 2011-08-04 15:40:40 --> Controller Class Initialized
DEBUG - 2011-08-04 15:40:40 --> Model Class Initialized
DEBUG - 2011-08-04 15:40:40 --> Model Class Initialized
DEBUG - 2011-08-04 15:40:40 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-04 15:40:40 --> Database Driver Class Initialized
DEBUG - 2011-08-04 15:40:40 --> Final output sent to browser
DEBUG - 2011-08-04 15:40:40 --> Total execution time: 0.5444
DEBUG - 2011-08-04 16:28:42 --> Config Class Initialized
DEBUG - 2011-08-04 16:28:42 --> Hooks Class Initialized
DEBUG - 2011-08-04 16:28:42 --> Utf8 Class Initialized
DEBUG - 2011-08-04 16:28:42 --> UTF-8 Support Enabled
DEBUG - 2011-08-04 16:28:42 --> URI Class Initialized
DEBUG - 2011-08-04 16:28:42 --> Router Class Initialized
DEBUG - 2011-08-04 16:28:42 --> Output Class Initialized
DEBUG - 2011-08-04 16:28:42 --> Input Class Initialized
DEBUG - 2011-08-04 16:28:42 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-04 16:28:42 --> Language Class Initialized
DEBUG - 2011-08-04 16:28:42 --> Loader Class Initialized
DEBUG - 2011-08-04 16:28:42 --> Controller Class Initialized
ERROR - 2011-08-04 16:28:42 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-04 16:28:42 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-04 16:28:42 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-04 16:28:42 --> Model Class Initialized
DEBUG - 2011-08-04 16:28:42 --> Model Class Initialized
DEBUG - 2011-08-04 16:28:42 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-04 16:28:42 --> Database Driver Class Initialized
DEBUG - 2011-08-04 16:28:42 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-04 16:28:42 --> Helper loaded: url_helper
DEBUG - 2011-08-04 16:28:42 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-04 16:28:42 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-04 16:28:42 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-04 16:28:42 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-04 16:28:42 --> Final output sent to browser
DEBUG - 2011-08-04 16:28:42 --> Total execution time: 0.0319
DEBUG - 2011-08-04 16:28:43 --> Config Class Initialized
DEBUG - 2011-08-04 16:28:43 --> Hooks Class Initialized
DEBUG - 2011-08-04 16:28:43 --> Utf8 Class Initialized
DEBUG - 2011-08-04 16:28:43 --> UTF-8 Support Enabled
DEBUG - 2011-08-04 16:28:43 --> URI Class Initialized
DEBUG - 2011-08-04 16:28:43 --> Router Class Initialized
DEBUG - 2011-08-04 16:28:43 --> Output Class Initialized
DEBUG - 2011-08-04 16:28:43 --> Input Class Initialized
DEBUG - 2011-08-04 16:28:43 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-04 16:28:43 --> Language Class Initialized
DEBUG - 2011-08-04 16:28:43 --> Loader Class Initialized
DEBUG - 2011-08-04 16:28:43 --> Controller Class Initialized
DEBUG - 2011-08-04 16:28:43 --> Model Class Initialized
DEBUG - 2011-08-04 16:28:43 --> Model Class Initialized
DEBUG - 2011-08-04 16:28:43 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-04 16:28:44 --> Database Driver Class Initialized
DEBUG - 2011-08-04 16:28:44 --> Final output sent to browser
DEBUG - 2011-08-04 16:28:44 --> Total execution time: 0.7498
DEBUG - 2011-08-04 16:28:47 --> Config Class Initialized
DEBUG - 2011-08-04 16:28:47 --> Hooks Class Initialized
DEBUG - 2011-08-04 16:28:47 --> Utf8 Class Initialized
DEBUG - 2011-08-04 16:28:47 --> UTF-8 Support Enabled
DEBUG - 2011-08-04 16:28:47 --> URI Class Initialized
DEBUG - 2011-08-04 16:28:47 --> Router Class Initialized
ERROR - 2011-08-04 16:28:47 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-04 16:52:26 --> Config Class Initialized
DEBUG - 2011-08-04 16:52:26 --> Hooks Class Initialized
DEBUG - 2011-08-04 16:52:26 --> Utf8 Class Initialized
DEBUG - 2011-08-04 16:52:26 --> UTF-8 Support Enabled
DEBUG - 2011-08-04 16:52:26 --> URI Class Initialized
DEBUG - 2011-08-04 16:52:26 --> Router Class Initialized
DEBUG - 2011-08-04 16:52:26 --> No URI present. Default controller set.
DEBUG - 2011-08-04 16:52:26 --> Output Class Initialized
DEBUG - 2011-08-04 16:52:26 --> Input Class Initialized
DEBUG - 2011-08-04 16:52:26 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-04 16:52:26 --> Language Class Initialized
DEBUG - 2011-08-04 16:52:26 --> Loader Class Initialized
DEBUG - 2011-08-04 16:52:26 --> Controller Class Initialized
DEBUG - 2011-08-04 16:52:26 --> File loaded: application/views/splash/main.php
DEBUG - 2011-08-04 16:52:26 --> Helper loaded: url_helper
DEBUG - 2011-08-04 16:52:26 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-04 16:52:26 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-04 16:52:26 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-04 16:52:26 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-04 16:52:26 --> Final output sent to browser
DEBUG - 2011-08-04 16:52:26 --> Total execution time: 0.0638
DEBUG - 2011-08-04 16:58:19 --> Config Class Initialized
DEBUG - 2011-08-04 16:58:19 --> Hooks Class Initialized
DEBUG - 2011-08-04 16:58:19 --> Utf8 Class Initialized
DEBUG - 2011-08-04 16:58:19 --> UTF-8 Support Enabled
DEBUG - 2011-08-04 16:58:19 --> URI Class Initialized
DEBUG - 2011-08-04 16:58:19 --> Router Class Initialized
DEBUG - 2011-08-04 16:58:19 --> Output Class Initialized
DEBUG - 2011-08-04 16:58:19 --> Input Class Initialized
DEBUG - 2011-08-04 16:58:19 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-04 16:58:19 --> Language Class Initialized
DEBUG - 2011-08-04 16:58:19 --> Loader Class Initialized
DEBUG - 2011-08-04 16:58:19 --> Controller Class Initialized
ERROR - 2011-08-04 16:58:19 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-04 16:58:19 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-04 16:58:19 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-04 16:58:19 --> Model Class Initialized
DEBUG - 2011-08-04 16:58:19 --> Model Class Initialized
DEBUG - 2011-08-04 16:58:19 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-04 16:58:19 --> Database Driver Class Initialized
DEBUG - 2011-08-04 16:58:19 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-04 16:58:19 --> Helper loaded: url_helper
DEBUG - 2011-08-04 16:58:19 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-04 16:58:19 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-04 16:58:19 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-04 16:58:19 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-04 16:58:19 --> Final output sent to browser
DEBUG - 2011-08-04 16:58:19 --> Total execution time: 0.0321
DEBUG - 2011-08-04 16:58:19 --> Config Class Initialized
DEBUG - 2011-08-04 16:58:19 --> Hooks Class Initialized
DEBUG - 2011-08-04 16:58:19 --> Utf8 Class Initialized
DEBUG - 2011-08-04 16:58:19 --> UTF-8 Support Enabled
DEBUG - 2011-08-04 16:58:19 --> URI Class Initialized
DEBUG - 2011-08-04 16:58:19 --> Router Class Initialized
DEBUG - 2011-08-04 16:58:19 --> Output Class Initialized
DEBUG - 2011-08-04 16:58:19 --> Input Class Initialized
DEBUG - 2011-08-04 16:58:19 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-04 16:58:19 --> Language Class Initialized
DEBUG - 2011-08-04 16:58:19 --> Loader Class Initialized
DEBUG - 2011-08-04 16:58:19 --> Controller Class Initialized
DEBUG - 2011-08-04 16:58:19 --> Model Class Initialized
DEBUG - 2011-08-04 16:58:19 --> Model Class Initialized
DEBUG - 2011-08-04 16:58:19 --> Model Class Initialized
DEBUG - 2011-08-04 16:58:19 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-04 16:58:19 --> Database Driver Class Initialized
DEBUG - 2011-08-04 16:58:20 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-04 16:58:20 --> Helper loaded: url_helper
DEBUG - 2011-08-04 16:58:20 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-04 16:58:20 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-04 16:58:20 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-04 16:58:20 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-04 16:58:20 --> Final output sent to browser
DEBUG - 2011-08-04 16:58:20 --> Total execution time: 0.6215
DEBUG - 2011-08-04 17:11:58 --> Config Class Initialized
DEBUG - 2011-08-04 17:11:58 --> Hooks Class Initialized
DEBUG - 2011-08-04 17:11:58 --> Utf8 Class Initialized
DEBUG - 2011-08-04 17:11:58 --> UTF-8 Support Enabled
DEBUG - 2011-08-04 17:11:58 --> URI Class Initialized
DEBUG - 2011-08-04 17:11:58 --> Router Class Initialized
DEBUG - 2011-08-04 17:11:58 --> Output Class Initialized
DEBUG - 2011-08-04 17:11:58 --> Input Class Initialized
DEBUG - 2011-08-04 17:11:58 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-04 17:11:58 --> Language Class Initialized
DEBUG - 2011-08-04 17:11:58 --> Loader Class Initialized
DEBUG - 2011-08-04 17:11:58 --> Controller Class Initialized
ERROR - 2011-08-04 17:11:58 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-04 17:11:58 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-04 17:11:58 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-04 17:11:58 --> Model Class Initialized
DEBUG - 2011-08-04 17:11:58 --> Model Class Initialized
DEBUG - 2011-08-04 17:11:58 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-04 17:11:58 --> Database Driver Class Initialized
DEBUG - 2011-08-04 17:11:58 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-04 17:11:58 --> Helper loaded: url_helper
DEBUG - 2011-08-04 17:11:58 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-04 17:11:58 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-04 17:11:58 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-04 17:11:58 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-04 17:11:58 --> Final output sent to browser
DEBUG - 2011-08-04 17:11:58 --> Total execution time: 0.0681
DEBUG - 2011-08-04 19:22:29 --> Config Class Initialized
DEBUG - 2011-08-04 19:22:29 --> Hooks Class Initialized
DEBUG - 2011-08-04 19:22:29 --> Utf8 Class Initialized
DEBUG - 2011-08-04 19:22:29 --> UTF-8 Support Enabled
DEBUG - 2011-08-04 19:22:29 --> URI Class Initialized
DEBUG - 2011-08-04 19:22:29 --> Router Class Initialized
DEBUG - 2011-08-04 19:22:29 --> Output Class Initialized
DEBUG - 2011-08-04 19:22:29 --> Input Class Initialized
DEBUG - 2011-08-04 19:22:29 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-04 19:22:29 --> Language Class Initialized
DEBUG - 2011-08-04 19:22:29 --> Loader Class Initialized
DEBUG - 2011-08-04 19:22:29 --> Controller Class Initialized
DEBUG - 2011-08-04 19:22:29 --> Model Class Initialized
DEBUG - 2011-08-04 19:22:29 --> Model Class Initialized
DEBUG - 2011-08-04 19:22:29 --> Model Class Initialized
DEBUG - 2011-08-04 19:22:29 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-04 19:22:29 --> Database Driver Class Initialized
DEBUG - 2011-08-04 19:22:30 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-04 19:22:30 --> Helper loaded: url_helper
DEBUG - 2011-08-04 19:22:30 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-04 19:22:30 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-04 19:22:30 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-04 19:22:30 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-04 19:22:30 --> Final output sent to browser
DEBUG - 2011-08-04 19:22:30 --> Total execution time: 0.3393
DEBUG - 2011-08-04 20:04:47 --> Config Class Initialized
DEBUG - 2011-08-04 20:04:47 --> Hooks Class Initialized
DEBUG - 2011-08-04 20:04:47 --> Utf8 Class Initialized
DEBUG - 2011-08-04 20:04:47 --> UTF-8 Support Enabled
DEBUG - 2011-08-04 20:04:47 --> URI Class Initialized
DEBUG - 2011-08-04 20:04:47 --> Router Class Initialized
DEBUG - 2011-08-04 20:04:47 --> Output Class Initialized
DEBUG - 2011-08-04 20:04:47 --> Input Class Initialized
DEBUG - 2011-08-04 20:04:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-04 20:04:47 --> Language Class Initialized
DEBUG - 2011-08-04 20:04:47 --> Loader Class Initialized
DEBUG - 2011-08-04 20:04:47 --> Controller Class Initialized
ERROR - 2011-08-04 20:04:47 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-04 20:04:47 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-04 20:04:47 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-04 20:04:47 --> Model Class Initialized
DEBUG - 2011-08-04 20:04:47 --> Model Class Initialized
DEBUG - 2011-08-04 20:04:47 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-04 20:04:47 --> Database Driver Class Initialized
DEBUG - 2011-08-04 20:04:47 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-04 20:04:47 --> Helper loaded: url_helper
DEBUG - 2011-08-04 20:04:47 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-04 20:04:47 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-04 20:04:47 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-04 20:04:47 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-04 20:04:47 --> Final output sent to browser
DEBUG - 2011-08-04 20:04:47 --> Total execution time: 0.0672
DEBUG - 2011-08-04 20:11:49 --> Config Class Initialized
DEBUG - 2011-08-04 20:11:49 --> Hooks Class Initialized
DEBUG - 2011-08-04 20:11:49 --> Utf8 Class Initialized
DEBUG - 2011-08-04 20:11:49 --> UTF-8 Support Enabled
DEBUG - 2011-08-04 20:11:49 --> URI Class Initialized
DEBUG - 2011-08-04 20:11:49 --> Router Class Initialized
DEBUG - 2011-08-04 20:11:49 --> Output Class Initialized
DEBUG - 2011-08-04 20:11:49 --> Input Class Initialized
DEBUG - 2011-08-04 20:11:49 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-04 20:11:49 --> Language Class Initialized
DEBUG - 2011-08-04 20:11:49 --> Loader Class Initialized
DEBUG - 2011-08-04 20:11:49 --> Controller Class Initialized
DEBUG - 2011-08-04 20:11:49 --> Model Class Initialized
DEBUG - 2011-08-04 20:11:49 --> Model Class Initialized
DEBUG - 2011-08-04 20:11:49 --> Model Class Initialized
DEBUG - 2011-08-04 20:11:49 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-04 20:11:49 --> Database Driver Class Initialized
DEBUG - 2011-08-04 20:11:50 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-04 20:11:50 --> Helper loaded: url_helper
DEBUG - 2011-08-04 20:11:50 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-04 20:11:50 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-04 20:11:50 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-04 20:11:50 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-04 20:11:50 --> Final output sent to browser
DEBUG - 2011-08-04 20:11:50 --> Total execution time: 0.5311
DEBUG - 2011-08-04 20:12:05 --> Config Class Initialized
DEBUG - 2011-08-04 20:12:05 --> Hooks Class Initialized
DEBUG - 2011-08-04 20:12:05 --> Utf8 Class Initialized
DEBUG - 2011-08-04 20:12:05 --> UTF-8 Support Enabled
DEBUG - 2011-08-04 20:12:05 --> URI Class Initialized
DEBUG - 2011-08-04 20:12:05 --> Router Class Initialized
DEBUG - 2011-08-04 20:12:05 --> Output Class Initialized
DEBUG - 2011-08-04 20:12:05 --> Input Class Initialized
DEBUG - 2011-08-04 20:12:05 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-04 20:12:05 --> Language Class Initialized
DEBUG - 2011-08-04 20:12:05 --> Loader Class Initialized
DEBUG - 2011-08-04 20:12:05 --> Controller Class Initialized
DEBUG - 2011-08-04 20:12:05 --> Model Class Initialized
DEBUG - 2011-08-04 20:12:05 --> Model Class Initialized
DEBUG - 2011-08-04 20:12:05 --> Model Class Initialized
DEBUG - 2011-08-04 20:12:05 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-04 20:12:05 --> Database Driver Class Initialized
DEBUG - 2011-08-04 20:12:06 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-04 20:12:06 --> Helper loaded: url_helper
DEBUG - 2011-08-04 20:12:06 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-04 20:12:06 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-04 20:12:06 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-04 20:12:06 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-04 20:12:06 --> Final output sent to browser
DEBUG - 2011-08-04 20:12:06 --> Total execution time: 1.0398
DEBUG - 2011-08-04 20:12:11 --> Config Class Initialized
DEBUG - 2011-08-04 20:12:11 --> Hooks Class Initialized
DEBUG - 2011-08-04 20:12:11 --> Utf8 Class Initialized
DEBUG - 2011-08-04 20:12:11 --> UTF-8 Support Enabled
DEBUG - 2011-08-04 20:12:11 --> URI Class Initialized
DEBUG - 2011-08-04 20:12:11 --> Router Class Initialized
ERROR - 2011-08-04 20:12:11 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-04 20:12:15 --> Config Class Initialized
DEBUG - 2011-08-04 20:12:15 --> Hooks Class Initialized
DEBUG - 2011-08-04 20:12:15 --> Utf8 Class Initialized
DEBUG - 2011-08-04 20:12:15 --> UTF-8 Support Enabled
DEBUG - 2011-08-04 20:12:15 --> URI Class Initialized
DEBUG - 2011-08-04 20:12:15 --> Router Class Initialized
DEBUG - 2011-08-04 20:12:15 --> Output Class Initialized
DEBUG - 2011-08-04 20:12:15 --> Input Class Initialized
DEBUG - 2011-08-04 20:12:15 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-04 20:12:15 --> Language Class Initialized
DEBUG - 2011-08-04 20:12:15 --> Loader Class Initialized
DEBUG - 2011-08-04 20:12:15 --> Controller Class Initialized
DEBUG - 2011-08-04 20:12:15 --> Model Class Initialized
DEBUG - 2011-08-04 20:12:15 --> Model Class Initialized
DEBUG - 2011-08-04 20:12:15 --> Model Class Initialized
DEBUG - 2011-08-04 20:12:15 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-04 20:12:15 --> Database Driver Class Initialized
DEBUG - 2011-08-04 20:12:15 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-04 20:12:15 --> Helper loaded: url_helper
DEBUG - 2011-08-04 20:12:15 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-04 20:12:15 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-04 20:12:15 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-04 20:12:15 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-04 20:12:15 --> Final output sent to browser
DEBUG - 2011-08-04 20:12:15 --> Total execution time: 0.2786
DEBUG - 2011-08-04 20:12:16 --> Config Class Initialized
DEBUG - 2011-08-04 20:12:16 --> Hooks Class Initialized
DEBUG - 2011-08-04 20:12:16 --> Utf8 Class Initialized
DEBUG - 2011-08-04 20:12:16 --> UTF-8 Support Enabled
DEBUG - 2011-08-04 20:12:16 --> URI Class Initialized
DEBUG - 2011-08-04 20:12:16 --> Router Class Initialized
ERROR - 2011-08-04 20:12:16 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-04 20:12:21 --> Config Class Initialized
DEBUG - 2011-08-04 20:12:21 --> Hooks Class Initialized
DEBUG - 2011-08-04 20:12:21 --> Utf8 Class Initialized
DEBUG - 2011-08-04 20:12:21 --> UTF-8 Support Enabled
DEBUG - 2011-08-04 20:12:21 --> URI Class Initialized
DEBUG - 2011-08-04 20:12:21 --> Router Class Initialized
ERROR - 2011-08-04 20:12:21 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-08-04 20:12:21 --> Config Class Initialized
DEBUG - 2011-08-04 20:12:21 --> Hooks Class Initialized
DEBUG - 2011-08-04 20:12:21 --> Utf8 Class Initialized
DEBUG - 2011-08-04 20:12:21 --> UTF-8 Support Enabled
DEBUG - 2011-08-04 20:12:21 --> URI Class Initialized
DEBUG - 2011-08-04 20:12:21 --> Router Class Initialized
DEBUG - 2011-08-04 20:12:21 --> Output Class Initialized
DEBUG - 2011-08-04 20:12:21 --> Input Class Initialized
DEBUG - 2011-08-04 20:12:21 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-04 20:12:21 --> Language Class Initialized
DEBUG - 2011-08-04 20:12:21 --> Loader Class Initialized
DEBUG - 2011-08-04 20:12:21 --> Controller Class Initialized
DEBUG - 2011-08-04 20:12:21 --> Model Class Initialized
DEBUG - 2011-08-04 20:12:21 --> Model Class Initialized
DEBUG - 2011-08-04 20:12:21 --> Model Class Initialized
DEBUG - 2011-08-04 20:12:21 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-04 20:12:21 --> Database Driver Class Initialized
DEBUG - 2011-08-04 20:12:21 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-04 20:12:21 --> Helper loaded: url_helper
DEBUG - 2011-08-04 20:12:21 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-04 20:12:21 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-04 20:12:21 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-04 20:12:21 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-04 20:12:21 --> Final output sent to browser
DEBUG - 2011-08-04 20:12:21 --> Total execution time: 0.0525
DEBUG - 2011-08-04 20:12:22 --> Config Class Initialized
DEBUG - 2011-08-04 20:12:22 --> Hooks Class Initialized
DEBUG - 2011-08-04 20:12:22 --> Utf8 Class Initialized
DEBUG - 2011-08-04 20:12:22 --> UTF-8 Support Enabled
DEBUG - 2011-08-04 20:12:22 --> URI Class Initialized
DEBUG - 2011-08-04 20:12:22 --> Router Class Initialized
DEBUG - 2011-08-04 20:12:22 --> Output Class Initialized
DEBUG - 2011-08-04 20:12:22 --> Input Class Initialized
DEBUG - 2011-08-04 20:12:22 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-04 20:12:22 --> Language Class Initialized
DEBUG - 2011-08-04 20:12:22 --> Loader Class Initialized
DEBUG - 2011-08-04 20:12:22 --> Controller Class Initialized
DEBUG - 2011-08-04 20:12:22 --> Model Class Initialized
DEBUG - 2011-08-04 20:12:22 --> Model Class Initialized
DEBUG - 2011-08-04 20:12:22 --> Model Class Initialized
DEBUG - 2011-08-04 20:12:22 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-04 20:12:22 --> Database Driver Class Initialized
DEBUG - 2011-08-04 20:12:22 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-04 20:12:22 --> Helper loaded: url_helper
DEBUG - 2011-08-04 20:12:22 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-04 20:12:22 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-04 20:12:22 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-04 20:12:22 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-04 20:12:22 --> Final output sent to browser
DEBUG - 2011-08-04 20:12:22 --> Total execution time: 0.0488
DEBUG - 2011-08-04 20:12:23 --> Config Class Initialized
DEBUG - 2011-08-04 20:12:23 --> Hooks Class Initialized
DEBUG - 2011-08-04 20:12:23 --> Utf8 Class Initialized
DEBUG - 2011-08-04 20:12:23 --> UTF-8 Support Enabled
DEBUG - 2011-08-04 20:12:23 --> URI Class Initialized
DEBUG - 2011-08-04 20:12:23 --> Router Class Initialized
DEBUG - 2011-08-04 20:12:23 --> Output Class Initialized
DEBUG - 2011-08-04 20:12:23 --> Input Class Initialized
DEBUG - 2011-08-04 20:12:23 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-04 20:12:23 --> Language Class Initialized
DEBUG - 2011-08-04 20:12:23 --> Loader Class Initialized
DEBUG - 2011-08-04 20:12:23 --> Controller Class Initialized
DEBUG - 2011-08-04 20:12:23 --> Model Class Initialized
DEBUG - 2011-08-04 20:12:23 --> Model Class Initialized
DEBUG - 2011-08-04 20:12:23 --> Model Class Initialized
DEBUG - 2011-08-04 20:12:23 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-04 20:12:23 --> Database Driver Class Initialized
DEBUG - 2011-08-04 20:12:23 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-04 20:12:23 --> Helper loaded: url_helper
DEBUG - 2011-08-04 20:12:23 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-04 20:12:23 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-04 20:12:23 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-04 20:12:23 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-04 20:12:23 --> Final output sent to browser
DEBUG - 2011-08-04 20:12:23 --> Total execution time: 0.2484
DEBUG - 2011-08-04 20:12:24 --> Config Class Initialized
DEBUG - 2011-08-04 20:12:24 --> Hooks Class Initialized
DEBUG - 2011-08-04 20:12:24 --> Utf8 Class Initialized
DEBUG - 2011-08-04 20:12:24 --> UTF-8 Support Enabled
DEBUG - 2011-08-04 20:12:24 --> URI Class Initialized
DEBUG - 2011-08-04 20:12:24 --> Router Class Initialized
DEBUG - 2011-08-04 20:12:24 --> Output Class Initialized
DEBUG - 2011-08-04 20:12:24 --> Input Class Initialized
DEBUG - 2011-08-04 20:12:24 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-04 20:12:24 --> Language Class Initialized
DEBUG - 2011-08-04 20:12:24 --> Loader Class Initialized
DEBUG - 2011-08-04 20:12:24 --> Controller Class Initialized
DEBUG - 2011-08-04 20:12:24 --> Model Class Initialized
DEBUG - 2011-08-04 20:12:24 --> Model Class Initialized
DEBUG - 2011-08-04 20:12:24 --> Model Class Initialized
DEBUG - 2011-08-04 20:12:24 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-04 20:12:24 --> Database Driver Class Initialized
DEBUG - 2011-08-04 20:12:24 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-04 20:12:24 --> Helper loaded: url_helper
DEBUG - 2011-08-04 20:12:24 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-04 20:12:24 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-04 20:12:24 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-04 20:12:24 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-04 20:12:24 --> Final output sent to browser
DEBUG - 2011-08-04 20:12:24 --> Total execution time: 0.0433
DEBUG - 2011-08-04 20:12:24 --> Config Class Initialized
DEBUG - 2011-08-04 20:12:24 --> Hooks Class Initialized
DEBUG - 2011-08-04 20:12:24 --> Utf8 Class Initialized
DEBUG - 2011-08-04 20:12:24 --> UTF-8 Support Enabled
DEBUG - 2011-08-04 20:12:24 --> URI Class Initialized
DEBUG - 2011-08-04 20:12:24 --> Router Class Initialized
ERROR - 2011-08-04 20:12:24 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-04 20:12:29 --> Config Class Initialized
DEBUG - 2011-08-04 20:12:29 --> Hooks Class Initialized
DEBUG - 2011-08-04 20:12:29 --> Utf8 Class Initialized
DEBUG - 2011-08-04 20:12:29 --> UTF-8 Support Enabled
DEBUG - 2011-08-04 20:12:29 --> URI Class Initialized
DEBUG - 2011-08-04 20:12:29 --> Router Class Initialized
DEBUG - 2011-08-04 20:12:29 --> Output Class Initialized
DEBUG - 2011-08-04 20:12:29 --> Input Class Initialized
DEBUG - 2011-08-04 20:12:29 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-04 20:12:29 --> Language Class Initialized
DEBUG - 2011-08-04 20:12:29 --> Loader Class Initialized
DEBUG - 2011-08-04 20:12:29 --> Controller Class Initialized
DEBUG - 2011-08-04 20:12:29 --> Model Class Initialized
DEBUG - 2011-08-04 20:12:29 --> Model Class Initialized
DEBUG - 2011-08-04 20:12:29 --> Model Class Initialized
DEBUG - 2011-08-04 20:12:29 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-04 20:12:29 --> Database Driver Class Initialized
DEBUG - 2011-08-04 20:12:29 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-04 20:12:29 --> Helper loaded: url_helper
DEBUG - 2011-08-04 20:12:29 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-04 20:12:29 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-04 20:12:29 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-04 20:12:29 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-04 20:12:29 --> Final output sent to browser
DEBUG - 2011-08-04 20:12:29 --> Total execution time: 0.2691
DEBUG - 2011-08-04 20:12:30 --> Config Class Initialized
DEBUG - 2011-08-04 20:12:30 --> Hooks Class Initialized
DEBUG - 2011-08-04 20:12:30 --> Utf8 Class Initialized
DEBUG - 2011-08-04 20:12:30 --> UTF-8 Support Enabled
DEBUG - 2011-08-04 20:12:30 --> URI Class Initialized
DEBUG - 2011-08-04 20:12:30 --> Router Class Initialized
DEBUG - 2011-08-04 20:12:30 --> Output Class Initialized
DEBUG - 2011-08-04 20:12:30 --> Input Class Initialized
DEBUG - 2011-08-04 20:12:30 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-04 20:12:30 --> Language Class Initialized
DEBUG - 2011-08-04 20:12:30 --> Loader Class Initialized
DEBUG - 2011-08-04 20:12:30 --> Controller Class Initialized
DEBUG - 2011-08-04 20:12:30 --> Model Class Initialized
DEBUG - 2011-08-04 20:12:30 --> Model Class Initialized
DEBUG - 2011-08-04 20:12:30 --> Model Class Initialized
DEBUG - 2011-08-04 20:12:30 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-04 20:12:30 --> Database Driver Class Initialized
DEBUG - 2011-08-04 20:12:30 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-04 20:12:30 --> Helper loaded: url_helper
DEBUG - 2011-08-04 20:12:30 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-04 20:12:30 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-04 20:12:30 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-04 20:12:30 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-04 20:12:30 --> Final output sent to browser
DEBUG - 2011-08-04 20:12:30 --> Total execution time: 0.0774
DEBUG - 2011-08-04 20:12:30 --> Config Class Initialized
DEBUG - 2011-08-04 20:12:30 --> Hooks Class Initialized
DEBUG - 2011-08-04 20:12:30 --> Utf8 Class Initialized
DEBUG - 2011-08-04 20:12:30 --> UTF-8 Support Enabled
DEBUG - 2011-08-04 20:12:30 --> URI Class Initialized
DEBUG - 2011-08-04 20:12:30 --> Router Class Initialized
ERROR - 2011-08-04 20:12:30 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-04 20:12:34 --> Config Class Initialized
DEBUG - 2011-08-04 20:12:34 --> Hooks Class Initialized
DEBUG - 2011-08-04 20:12:34 --> Utf8 Class Initialized
DEBUG - 2011-08-04 20:12:34 --> UTF-8 Support Enabled
DEBUG - 2011-08-04 20:12:34 --> URI Class Initialized
DEBUG - 2011-08-04 20:12:34 --> Router Class Initialized
DEBUG - 2011-08-04 20:12:34 --> Output Class Initialized
DEBUG - 2011-08-04 20:12:34 --> Input Class Initialized
DEBUG - 2011-08-04 20:12:34 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-04 20:12:34 --> Language Class Initialized
DEBUG - 2011-08-04 20:12:34 --> Loader Class Initialized
DEBUG - 2011-08-04 20:12:34 --> Controller Class Initialized
DEBUG - 2011-08-04 20:12:34 --> Model Class Initialized
DEBUG - 2011-08-04 20:12:34 --> Model Class Initialized
DEBUG - 2011-08-04 20:12:34 --> Model Class Initialized
DEBUG - 2011-08-04 20:12:34 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-04 20:12:34 --> Database Driver Class Initialized
DEBUG - 2011-08-04 20:12:34 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-04 20:12:34 --> Helper loaded: url_helper
DEBUG - 2011-08-04 20:12:34 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-04 20:12:34 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-04 20:12:34 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-04 20:12:34 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-04 20:12:34 --> Final output sent to browser
DEBUG - 2011-08-04 20:12:34 --> Total execution time: 0.1995
DEBUG - 2011-08-04 20:12:35 --> Config Class Initialized
DEBUG - 2011-08-04 20:12:35 --> Hooks Class Initialized
DEBUG - 2011-08-04 20:12:35 --> Utf8 Class Initialized
DEBUG - 2011-08-04 20:12:35 --> UTF-8 Support Enabled
DEBUG - 2011-08-04 20:12:35 --> URI Class Initialized
DEBUG - 2011-08-04 20:12:35 --> Router Class Initialized
ERROR - 2011-08-04 20:12:35 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-04 20:12:35 --> Config Class Initialized
DEBUG - 2011-08-04 20:12:35 --> Hooks Class Initialized
DEBUG - 2011-08-04 20:12:35 --> Utf8 Class Initialized
DEBUG - 2011-08-04 20:12:35 --> UTF-8 Support Enabled
DEBUG - 2011-08-04 20:12:35 --> URI Class Initialized
DEBUG - 2011-08-04 20:12:35 --> Router Class Initialized
DEBUG - 2011-08-04 20:12:35 --> Output Class Initialized
DEBUG - 2011-08-04 20:12:35 --> Input Class Initialized
DEBUG - 2011-08-04 20:12:35 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-04 20:12:35 --> Language Class Initialized
DEBUG - 2011-08-04 20:12:35 --> Loader Class Initialized
DEBUG - 2011-08-04 20:12:35 --> Controller Class Initialized
DEBUG - 2011-08-04 20:12:35 --> Model Class Initialized
DEBUG - 2011-08-04 20:12:35 --> Model Class Initialized
DEBUG - 2011-08-04 20:12:35 --> Model Class Initialized
DEBUG - 2011-08-04 20:12:35 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-04 20:12:35 --> Database Driver Class Initialized
DEBUG - 2011-08-04 20:12:36 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-04 20:12:36 --> Helper loaded: url_helper
DEBUG - 2011-08-04 20:12:36 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-04 20:12:36 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-04 20:12:36 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-04 20:12:36 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-04 20:12:36 --> Final output sent to browser
DEBUG - 2011-08-04 20:12:36 --> Total execution time: 0.0460
DEBUG - 2011-08-04 20:12:40 --> Config Class Initialized
DEBUG - 2011-08-04 20:12:40 --> Hooks Class Initialized
DEBUG - 2011-08-04 20:12:40 --> Utf8 Class Initialized
DEBUG - 2011-08-04 20:12:40 --> UTF-8 Support Enabled
DEBUG - 2011-08-04 20:12:40 --> URI Class Initialized
DEBUG - 2011-08-04 20:12:40 --> Router Class Initialized
DEBUG - 2011-08-04 20:12:40 --> Output Class Initialized
DEBUG - 2011-08-04 20:12:40 --> Input Class Initialized
DEBUG - 2011-08-04 20:12:40 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-04 20:12:40 --> Language Class Initialized
DEBUG - 2011-08-04 20:12:40 --> Loader Class Initialized
DEBUG - 2011-08-04 20:12:40 --> Controller Class Initialized
DEBUG - 2011-08-04 20:12:40 --> Model Class Initialized
DEBUG - 2011-08-04 20:12:40 --> Model Class Initialized
DEBUG - 2011-08-04 20:12:40 --> Model Class Initialized
DEBUG - 2011-08-04 20:12:40 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-04 20:12:40 --> Database Driver Class Initialized
DEBUG - 2011-08-04 20:12:40 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-04 20:12:40 --> Helper loaded: url_helper
DEBUG - 2011-08-04 20:12:40 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-04 20:12:40 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-04 20:12:40 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-04 20:12:40 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-04 20:12:40 --> Final output sent to browser
DEBUG - 2011-08-04 20:12:40 --> Total execution time: 0.2960
DEBUG - 2011-08-04 20:12:41 --> Config Class Initialized
DEBUG - 2011-08-04 20:12:41 --> Hooks Class Initialized
DEBUG - 2011-08-04 20:12:41 --> Utf8 Class Initialized
DEBUG - 2011-08-04 20:12:41 --> UTF-8 Support Enabled
DEBUG - 2011-08-04 20:12:41 --> URI Class Initialized
DEBUG - 2011-08-04 20:12:41 --> Router Class Initialized
ERROR - 2011-08-04 20:12:41 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-04 20:12:42 --> Config Class Initialized
DEBUG - 2011-08-04 20:12:42 --> Hooks Class Initialized
DEBUG - 2011-08-04 20:12:42 --> Utf8 Class Initialized
DEBUG - 2011-08-04 20:12:42 --> UTF-8 Support Enabled
DEBUG - 2011-08-04 20:12:42 --> URI Class Initialized
DEBUG - 2011-08-04 20:12:42 --> Router Class Initialized
DEBUG - 2011-08-04 20:12:42 --> Output Class Initialized
DEBUG - 2011-08-04 20:12:42 --> Input Class Initialized
DEBUG - 2011-08-04 20:12:42 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-04 20:12:42 --> Language Class Initialized
DEBUG - 2011-08-04 20:12:42 --> Loader Class Initialized
DEBUG - 2011-08-04 20:12:42 --> Controller Class Initialized
DEBUG - 2011-08-04 20:12:42 --> Model Class Initialized
DEBUG - 2011-08-04 20:12:42 --> Model Class Initialized
DEBUG - 2011-08-04 20:12:42 --> Model Class Initialized
DEBUG - 2011-08-04 20:12:42 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-04 20:12:42 --> Database Driver Class Initialized
DEBUG - 2011-08-04 20:12:42 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-04 20:12:42 --> Helper loaded: url_helper
DEBUG - 2011-08-04 20:12:42 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-04 20:12:42 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-04 20:12:42 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-04 20:12:42 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-04 20:12:42 --> Final output sent to browser
DEBUG - 2011-08-04 20:12:42 --> Total execution time: 0.0495
DEBUG - 2011-08-04 20:12:45 --> Config Class Initialized
DEBUG - 2011-08-04 20:12:45 --> Hooks Class Initialized
DEBUG - 2011-08-04 20:12:45 --> Utf8 Class Initialized
DEBUG - 2011-08-04 20:12:45 --> UTF-8 Support Enabled
DEBUG - 2011-08-04 20:12:45 --> URI Class Initialized
DEBUG - 2011-08-04 20:12:45 --> Router Class Initialized
DEBUG - 2011-08-04 20:12:45 --> Output Class Initialized
DEBUG - 2011-08-04 20:12:45 --> Input Class Initialized
DEBUG - 2011-08-04 20:12:45 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-04 20:12:45 --> Language Class Initialized
DEBUG - 2011-08-04 20:12:45 --> Loader Class Initialized
DEBUG - 2011-08-04 20:12:45 --> Controller Class Initialized
DEBUG - 2011-08-04 20:12:45 --> Model Class Initialized
DEBUG - 2011-08-04 20:12:45 --> Model Class Initialized
DEBUG - 2011-08-04 20:12:45 --> Model Class Initialized
DEBUG - 2011-08-04 20:12:45 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-04 20:12:45 --> Database Driver Class Initialized
DEBUG - 2011-08-04 20:12:45 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-04 20:12:45 --> Helper loaded: url_helper
DEBUG - 2011-08-04 20:12:45 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-04 20:12:45 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-04 20:12:45 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-04 20:12:45 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-04 20:12:45 --> Final output sent to browser
DEBUG - 2011-08-04 20:12:45 --> Total execution time: 0.3577
DEBUG - 2011-08-04 20:12:46 --> Config Class Initialized
DEBUG - 2011-08-04 20:12:46 --> Hooks Class Initialized
DEBUG - 2011-08-04 20:12:46 --> Utf8 Class Initialized
DEBUG - 2011-08-04 20:12:46 --> UTF-8 Support Enabled
DEBUG - 2011-08-04 20:12:46 --> URI Class Initialized
DEBUG - 2011-08-04 20:12:46 --> Router Class Initialized
ERROR - 2011-08-04 20:12:46 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-04 20:12:46 --> Config Class Initialized
DEBUG - 2011-08-04 20:12:46 --> Hooks Class Initialized
DEBUG - 2011-08-04 20:12:46 --> Utf8 Class Initialized
DEBUG - 2011-08-04 20:12:46 --> UTF-8 Support Enabled
DEBUG - 2011-08-04 20:12:46 --> URI Class Initialized
DEBUG - 2011-08-04 20:12:46 --> Router Class Initialized
ERROR - 2011-08-04 20:12:46 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-04 20:12:49 --> Config Class Initialized
DEBUG - 2011-08-04 20:12:49 --> Hooks Class Initialized
DEBUG - 2011-08-04 20:12:49 --> Utf8 Class Initialized
DEBUG - 2011-08-04 20:12:49 --> UTF-8 Support Enabled
DEBUG - 2011-08-04 20:12:49 --> URI Class Initialized
DEBUG - 2011-08-04 20:12:49 --> Router Class Initialized
DEBUG - 2011-08-04 20:12:49 --> Output Class Initialized
DEBUG - 2011-08-04 20:12:49 --> Input Class Initialized
DEBUG - 2011-08-04 20:12:49 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-04 20:12:49 --> Language Class Initialized
DEBUG - 2011-08-04 20:12:49 --> Loader Class Initialized
DEBUG - 2011-08-04 20:12:49 --> Controller Class Initialized
DEBUG - 2011-08-04 20:12:49 --> Model Class Initialized
DEBUG - 2011-08-04 20:12:49 --> Model Class Initialized
DEBUG - 2011-08-04 20:12:49 --> Model Class Initialized
DEBUG - 2011-08-04 20:12:49 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-04 20:12:49 --> Database Driver Class Initialized
DEBUG - 2011-08-04 20:12:49 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-04 20:12:49 --> Helper loaded: url_helper
DEBUG - 2011-08-04 20:12:49 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-04 20:12:49 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-04 20:12:49 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-04 20:12:49 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-04 20:12:49 --> Final output sent to browser
DEBUG - 2011-08-04 20:12:49 --> Total execution time: 0.3221
DEBUG - 2011-08-04 20:12:50 --> Config Class Initialized
DEBUG - 2011-08-04 20:12:50 --> Hooks Class Initialized
DEBUG - 2011-08-04 20:12:50 --> Utf8 Class Initialized
DEBUG - 2011-08-04 20:12:50 --> UTF-8 Support Enabled
DEBUG - 2011-08-04 20:12:50 --> URI Class Initialized
DEBUG - 2011-08-04 20:12:50 --> Router Class Initialized
ERROR - 2011-08-04 20:12:50 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-04 20:12:50 --> Config Class Initialized
DEBUG - 2011-08-04 20:12:50 --> Hooks Class Initialized
DEBUG - 2011-08-04 20:12:50 --> Utf8 Class Initialized
DEBUG - 2011-08-04 20:12:50 --> UTF-8 Support Enabled
DEBUG - 2011-08-04 20:12:50 --> URI Class Initialized
DEBUG - 2011-08-04 20:12:50 --> Router Class Initialized
ERROR - 2011-08-04 20:12:50 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-04 20:12:54 --> Config Class Initialized
DEBUG - 2011-08-04 20:12:54 --> Hooks Class Initialized
DEBUG - 2011-08-04 20:12:54 --> Utf8 Class Initialized
DEBUG - 2011-08-04 20:12:54 --> UTF-8 Support Enabled
DEBUG - 2011-08-04 20:12:54 --> URI Class Initialized
DEBUG - 2011-08-04 20:12:54 --> Router Class Initialized
DEBUG - 2011-08-04 20:12:54 --> Output Class Initialized
DEBUG - 2011-08-04 20:12:54 --> Input Class Initialized
DEBUG - 2011-08-04 20:12:54 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-04 20:12:54 --> Language Class Initialized
DEBUG - 2011-08-04 20:12:54 --> Loader Class Initialized
DEBUG - 2011-08-04 20:12:54 --> Controller Class Initialized
DEBUG - 2011-08-04 20:12:54 --> Model Class Initialized
DEBUG - 2011-08-04 20:12:54 --> Model Class Initialized
DEBUG - 2011-08-04 20:12:54 --> Model Class Initialized
DEBUG - 2011-08-04 20:12:54 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-04 20:12:54 --> Database Driver Class Initialized
DEBUG - 2011-08-04 20:12:54 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-04 20:12:54 --> Helper loaded: url_helper
DEBUG - 2011-08-04 20:12:54 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-04 20:12:54 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-04 20:12:54 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-04 20:12:54 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-04 20:12:54 --> Final output sent to browser
DEBUG - 2011-08-04 20:12:54 --> Total execution time: 0.2399
DEBUG - 2011-08-04 20:12:55 --> Config Class Initialized
DEBUG - 2011-08-04 20:12:55 --> Hooks Class Initialized
DEBUG - 2011-08-04 20:12:55 --> Utf8 Class Initialized
DEBUG - 2011-08-04 20:12:55 --> UTF-8 Support Enabled
DEBUG - 2011-08-04 20:12:55 --> URI Class Initialized
DEBUG - 2011-08-04 20:12:55 --> Router Class Initialized
ERROR - 2011-08-04 20:12:55 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-04 20:12:58 --> Config Class Initialized
DEBUG - 2011-08-04 20:12:58 --> Hooks Class Initialized
DEBUG - 2011-08-04 20:12:58 --> Utf8 Class Initialized
DEBUG - 2011-08-04 20:12:58 --> UTF-8 Support Enabled
DEBUG - 2011-08-04 20:12:58 --> URI Class Initialized
DEBUG - 2011-08-04 20:12:58 --> Router Class Initialized
DEBUG - 2011-08-04 20:12:58 --> Output Class Initialized
DEBUG - 2011-08-04 20:12:58 --> Input Class Initialized
DEBUG - 2011-08-04 20:12:58 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-04 20:12:58 --> Language Class Initialized
DEBUG - 2011-08-04 20:12:58 --> Loader Class Initialized
DEBUG - 2011-08-04 20:12:58 --> Controller Class Initialized
DEBUG - 2011-08-04 20:12:58 --> Model Class Initialized
DEBUG - 2011-08-04 20:12:58 --> Model Class Initialized
DEBUG - 2011-08-04 20:12:58 --> Model Class Initialized
DEBUG - 2011-08-04 20:12:58 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-04 20:12:58 --> Database Driver Class Initialized
DEBUG - 2011-08-04 20:12:59 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-04 20:12:59 --> Helper loaded: url_helper
DEBUG - 2011-08-04 20:12:59 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-04 20:12:59 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-04 20:12:59 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-04 20:12:59 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-04 20:12:59 --> Final output sent to browser
DEBUG - 2011-08-04 20:12:59 --> Total execution time: 0.3947
DEBUG - 2011-08-04 20:13:00 --> Config Class Initialized
DEBUG - 2011-08-04 20:13:00 --> Hooks Class Initialized
DEBUG - 2011-08-04 20:13:00 --> Utf8 Class Initialized
DEBUG - 2011-08-04 20:13:00 --> UTF-8 Support Enabled
DEBUG - 2011-08-04 20:13:00 --> URI Class Initialized
DEBUG - 2011-08-04 20:13:00 --> Router Class Initialized
ERROR - 2011-08-04 20:13:00 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-04 20:13:03 --> Config Class Initialized
DEBUG - 2011-08-04 20:13:03 --> Hooks Class Initialized
DEBUG - 2011-08-04 20:13:03 --> Utf8 Class Initialized
DEBUG - 2011-08-04 20:13:03 --> UTF-8 Support Enabled
DEBUG - 2011-08-04 20:13:03 --> URI Class Initialized
DEBUG - 2011-08-04 20:13:03 --> Router Class Initialized
DEBUG - 2011-08-04 20:13:03 --> Output Class Initialized
DEBUG - 2011-08-04 20:13:03 --> Input Class Initialized
DEBUG - 2011-08-04 20:13:03 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-04 20:13:03 --> Language Class Initialized
DEBUG - 2011-08-04 20:13:03 --> Loader Class Initialized
DEBUG - 2011-08-04 20:13:03 --> Controller Class Initialized
DEBUG - 2011-08-04 20:13:03 --> Model Class Initialized
DEBUG - 2011-08-04 20:13:03 --> Model Class Initialized
DEBUG - 2011-08-04 20:13:03 --> Model Class Initialized
DEBUG - 2011-08-04 20:13:03 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-04 20:13:03 --> Database Driver Class Initialized
DEBUG - 2011-08-04 20:13:03 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-04 20:13:03 --> Helper loaded: url_helper
DEBUG - 2011-08-04 20:13:03 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-04 20:13:03 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-04 20:13:03 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-04 20:13:03 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-04 20:13:03 --> Final output sent to browser
DEBUG - 2011-08-04 20:13:03 --> Total execution time: 0.2374
DEBUG - 2011-08-04 20:13:04 --> Config Class Initialized
DEBUG - 2011-08-04 20:13:04 --> Hooks Class Initialized
DEBUG - 2011-08-04 20:13:04 --> Utf8 Class Initialized
DEBUG - 2011-08-04 20:13:04 --> UTF-8 Support Enabled
DEBUG - 2011-08-04 20:13:04 --> URI Class Initialized
DEBUG - 2011-08-04 20:13:04 --> Router Class Initialized
ERROR - 2011-08-04 20:13:04 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-04 20:13:08 --> Config Class Initialized
DEBUG - 2011-08-04 20:13:08 --> Hooks Class Initialized
DEBUG - 2011-08-04 20:13:08 --> Utf8 Class Initialized
DEBUG - 2011-08-04 20:13:08 --> UTF-8 Support Enabled
DEBUG - 2011-08-04 20:13:08 --> URI Class Initialized
DEBUG - 2011-08-04 20:13:08 --> Router Class Initialized
DEBUG - 2011-08-04 20:13:08 --> Output Class Initialized
DEBUG - 2011-08-04 20:13:08 --> Input Class Initialized
DEBUG - 2011-08-04 20:13:08 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-04 20:13:08 --> Language Class Initialized
DEBUG - 2011-08-04 20:13:08 --> Loader Class Initialized
DEBUG - 2011-08-04 20:13:08 --> Controller Class Initialized
DEBUG - 2011-08-04 20:13:08 --> Model Class Initialized
DEBUG - 2011-08-04 20:13:08 --> Model Class Initialized
DEBUG - 2011-08-04 20:13:08 --> Model Class Initialized
DEBUG - 2011-08-04 20:13:08 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-04 20:13:08 --> Database Driver Class Initialized
DEBUG - 2011-08-04 20:13:09 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-04 20:13:09 --> Helper loaded: url_helper
DEBUG - 2011-08-04 20:13:09 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-04 20:13:09 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-04 20:13:09 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-04 20:13:09 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-04 20:13:09 --> Final output sent to browser
DEBUG - 2011-08-04 20:13:09 --> Total execution time: 0.2404
DEBUG - 2011-08-04 20:13:10 --> Config Class Initialized
DEBUG - 2011-08-04 20:13:10 --> Hooks Class Initialized
DEBUG - 2011-08-04 20:13:10 --> Utf8 Class Initialized
DEBUG - 2011-08-04 20:13:10 --> UTF-8 Support Enabled
DEBUG - 2011-08-04 20:13:10 --> URI Class Initialized
DEBUG - 2011-08-04 20:13:10 --> Router Class Initialized
ERROR - 2011-08-04 20:13:10 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-04 20:13:10 --> Config Class Initialized
DEBUG - 2011-08-04 20:13:10 --> Hooks Class Initialized
DEBUG - 2011-08-04 20:13:10 --> Utf8 Class Initialized
DEBUG - 2011-08-04 20:13:10 --> UTF-8 Support Enabled
DEBUG - 2011-08-04 20:13:10 --> URI Class Initialized
DEBUG - 2011-08-04 20:13:10 --> Router Class Initialized
ERROR - 2011-08-04 20:13:10 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-04 20:13:14 --> Config Class Initialized
DEBUG - 2011-08-04 20:13:14 --> Hooks Class Initialized
DEBUG - 2011-08-04 20:13:14 --> Utf8 Class Initialized
DEBUG - 2011-08-04 20:13:14 --> UTF-8 Support Enabled
DEBUG - 2011-08-04 20:13:14 --> URI Class Initialized
DEBUG - 2011-08-04 20:13:14 --> Router Class Initialized
DEBUG - 2011-08-04 20:13:14 --> Output Class Initialized
DEBUG - 2011-08-04 20:13:14 --> Input Class Initialized
DEBUG - 2011-08-04 20:13:14 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-04 20:13:14 --> Language Class Initialized
DEBUG - 2011-08-04 20:13:14 --> Loader Class Initialized
DEBUG - 2011-08-04 20:13:14 --> Controller Class Initialized
DEBUG - 2011-08-04 20:13:14 --> Model Class Initialized
DEBUG - 2011-08-04 20:13:14 --> Model Class Initialized
DEBUG - 2011-08-04 20:13:14 --> Model Class Initialized
DEBUG - 2011-08-04 20:13:14 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-04 20:13:14 --> Database Driver Class Initialized
DEBUG - 2011-08-04 20:13:14 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-04 20:13:14 --> Helper loaded: url_helper
DEBUG - 2011-08-04 20:13:14 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-04 20:13:14 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-04 20:13:14 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-04 20:13:14 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-04 20:13:14 --> Final output sent to browser
DEBUG - 2011-08-04 20:13:14 --> Total execution time: 0.5821
DEBUG - 2011-08-04 20:13:15 --> Config Class Initialized
DEBUG - 2011-08-04 20:13:15 --> Hooks Class Initialized
DEBUG - 2011-08-04 20:13:15 --> Utf8 Class Initialized
DEBUG - 2011-08-04 20:13:15 --> UTF-8 Support Enabled
DEBUG - 2011-08-04 20:13:15 --> URI Class Initialized
DEBUG - 2011-08-04 20:13:15 --> Router Class Initialized
ERROR - 2011-08-04 20:13:15 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-04 20:13:19 --> Config Class Initialized
DEBUG - 2011-08-04 20:13:19 --> Hooks Class Initialized
DEBUG - 2011-08-04 20:13:19 --> Utf8 Class Initialized
DEBUG - 2011-08-04 20:13:19 --> UTF-8 Support Enabled
DEBUG - 2011-08-04 20:13:19 --> URI Class Initialized
DEBUG - 2011-08-04 20:13:19 --> Router Class Initialized
DEBUG - 2011-08-04 20:13:19 --> Output Class Initialized
DEBUG - 2011-08-04 20:13:19 --> Input Class Initialized
DEBUG - 2011-08-04 20:13:19 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-04 20:13:19 --> Language Class Initialized
DEBUG - 2011-08-04 20:13:19 --> Loader Class Initialized
DEBUG - 2011-08-04 20:13:19 --> Controller Class Initialized
DEBUG - 2011-08-04 20:13:19 --> Model Class Initialized
DEBUG - 2011-08-04 20:13:19 --> Model Class Initialized
DEBUG - 2011-08-04 20:13:19 --> Model Class Initialized
DEBUG - 2011-08-04 20:13:19 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-04 20:13:19 --> Database Driver Class Initialized
DEBUG - 2011-08-04 20:13:20 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-04 20:13:20 --> Helper loaded: url_helper
DEBUG - 2011-08-04 20:13:20 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-04 20:13:20 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-04 20:13:20 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-04 20:13:20 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-04 20:13:20 --> Final output sent to browser
DEBUG - 2011-08-04 20:13:20 --> Total execution time: 0.2942
DEBUG - 2011-08-04 20:13:21 --> Config Class Initialized
DEBUG - 2011-08-04 20:13:21 --> Hooks Class Initialized
DEBUG - 2011-08-04 20:13:21 --> Utf8 Class Initialized
DEBUG - 2011-08-04 20:13:21 --> UTF-8 Support Enabled
DEBUG - 2011-08-04 20:13:21 --> URI Class Initialized
DEBUG - 2011-08-04 20:13:21 --> Router Class Initialized
ERROR - 2011-08-04 20:13:21 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-04 20:13:21 --> Config Class Initialized
DEBUG - 2011-08-04 20:13:21 --> Hooks Class Initialized
DEBUG - 2011-08-04 20:13:21 --> Utf8 Class Initialized
DEBUG - 2011-08-04 20:13:21 --> UTF-8 Support Enabled
DEBUG - 2011-08-04 20:13:21 --> URI Class Initialized
DEBUG - 2011-08-04 20:13:21 --> Router Class Initialized
ERROR - 2011-08-04 20:13:21 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-04 20:13:23 --> Config Class Initialized
DEBUG - 2011-08-04 20:13:23 --> Hooks Class Initialized
DEBUG - 2011-08-04 20:13:23 --> Utf8 Class Initialized
DEBUG - 2011-08-04 20:13:23 --> UTF-8 Support Enabled
DEBUG - 2011-08-04 20:13:23 --> URI Class Initialized
DEBUG - 2011-08-04 20:13:23 --> Router Class Initialized
DEBUG - 2011-08-04 20:13:23 --> Output Class Initialized
DEBUG - 2011-08-04 20:13:23 --> Input Class Initialized
DEBUG - 2011-08-04 20:13:23 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-04 20:13:23 --> Language Class Initialized
DEBUG - 2011-08-04 20:13:23 --> Loader Class Initialized
DEBUG - 2011-08-04 20:13:23 --> Controller Class Initialized
DEBUG - 2011-08-04 20:13:23 --> Model Class Initialized
DEBUG - 2011-08-04 20:13:23 --> Model Class Initialized
DEBUG - 2011-08-04 20:13:23 --> Model Class Initialized
DEBUG - 2011-08-04 20:13:23 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-04 20:13:23 --> Database Driver Class Initialized
DEBUG - 2011-08-04 20:13:24 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-04 20:13:24 --> Helper loaded: url_helper
DEBUG - 2011-08-04 20:13:24 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-04 20:13:24 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-04 20:13:24 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-04 20:13:24 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-04 20:13:24 --> Final output sent to browser
DEBUG - 2011-08-04 20:13:24 --> Total execution time: 0.8973
DEBUG - 2011-08-04 20:13:25 --> Config Class Initialized
DEBUG - 2011-08-04 20:13:25 --> Hooks Class Initialized
DEBUG - 2011-08-04 20:13:25 --> Utf8 Class Initialized
DEBUG - 2011-08-04 20:13:25 --> UTF-8 Support Enabled
DEBUG - 2011-08-04 20:13:25 --> URI Class Initialized
DEBUG - 2011-08-04 20:13:25 --> Router Class Initialized
ERROR - 2011-08-04 20:13:25 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-04 20:13:27 --> Config Class Initialized
DEBUG - 2011-08-04 20:13:27 --> Hooks Class Initialized
DEBUG - 2011-08-04 20:13:27 --> Utf8 Class Initialized
DEBUG - 2011-08-04 20:13:27 --> UTF-8 Support Enabled
DEBUG - 2011-08-04 20:13:28 --> URI Class Initialized
DEBUG - 2011-08-04 20:13:28 --> Router Class Initialized
DEBUG - 2011-08-04 20:13:28 --> Output Class Initialized
DEBUG - 2011-08-04 20:13:28 --> Input Class Initialized
DEBUG - 2011-08-04 20:13:28 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-04 20:13:28 --> Language Class Initialized
DEBUG - 2011-08-04 20:13:28 --> Loader Class Initialized
DEBUG - 2011-08-04 20:13:28 --> Controller Class Initialized
DEBUG - 2011-08-04 20:13:28 --> Model Class Initialized
DEBUG - 2011-08-04 20:13:28 --> Model Class Initialized
DEBUG - 2011-08-04 20:13:28 --> Model Class Initialized
DEBUG - 2011-08-04 20:13:28 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-04 20:13:28 --> Database Driver Class Initialized
DEBUG - 2011-08-04 20:13:28 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-04 20:13:28 --> Helper loaded: url_helper
DEBUG - 2011-08-04 20:13:28 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-04 20:13:28 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-04 20:13:28 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-04 20:13:28 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-04 20:13:28 --> Final output sent to browser
DEBUG - 2011-08-04 20:13:28 --> Total execution time: 0.5397
DEBUG - 2011-08-04 20:13:29 --> Config Class Initialized
DEBUG - 2011-08-04 20:13:29 --> Hooks Class Initialized
DEBUG - 2011-08-04 20:13:29 --> Utf8 Class Initialized
DEBUG - 2011-08-04 20:13:29 --> UTF-8 Support Enabled
DEBUG - 2011-08-04 20:13:29 --> URI Class Initialized
DEBUG - 2011-08-04 20:13:29 --> Router Class Initialized
ERROR - 2011-08-04 20:13:29 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-04 20:13:33 --> Config Class Initialized
DEBUG - 2011-08-04 20:13:33 --> Hooks Class Initialized
DEBUG - 2011-08-04 20:13:33 --> Utf8 Class Initialized
DEBUG - 2011-08-04 20:13:33 --> UTF-8 Support Enabled
DEBUG - 2011-08-04 20:13:33 --> URI Class Initialized
DEBUG - 2011-08-04 20:13:33 --> Router Class Initialized
DEBUG - 2011-08-04 20:13:33 --> Output Class Initialized
DEBUG - 2011-08-04 20:13:33 --> Input Class Initialized
DEBUG - 2011-08-04 20:13:33 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-04 20:13:33 --> Language Class Initialized
DEBUG - 2011-08-04 20:13:33 --> Loader Class Initialized
DEBUG - 2011-08-04 20:13:33 --> Controller Class Initialized
DEBUG - 2011-08-04 20:13:33 --> Model Class Initialized
DEBUG - 2011-08-04 20:13:33 --> Model Class Initialized
DEBUG - 2011-08-04 20:13:33 --> Model Class Initialized
DEBUG - 2011-08-04 20:13:33 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-04 20:13:33 --> Database Driver Class Initialized
DEBUG - 2011-08-04 20:13:33 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-04 20:13:33 --> Helper loaded: url_helper
DEBUG - 2011-08-04 20:13:33 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-04 20:13:33 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-04 20:13:33 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-04 20:13:33 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-04 20:13:33 --> Final output sent to browser
DEBUG - 2011-08-04 20:13:33 --> Total execution time: 0.2572
DEBUG - 2011-08-04 20:13:34 --> Config Class Initialized
DEBUG - 2011-08-04 20:13:34 --> Hooks Class Initialized
DEBUG - 2011-08-04 20:13:34 --> Utf8 Class Initialized
DEBUG - 2011-08-04 20:13:34 --> UTF-8 Support Enabled
DEBUG - 2011-08-04 20:13:34 --> URI Class Initialized
DEBUG - 2011-08-04 20:13:34 --> Router Class Initialized
ERROR - 2011-08-04 20:13:34 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-04 20:13:37 --> Config Class Initialized
DEBUG - 2011-08-04 20:13:37 --> Hooks Class Initialized
DEBUG - 2011-08-04 20:13:37 --> Utf8 Class Initialized
DEBUG - 2011-08-04 20:13:37 --> UTF-8 Support Enabled
DEBUG - 2011-08-04 20:13:37 --> URI Class Initialized
DEBUG - 2011-08-04 20:13:37 --> Router Class Initialized
DEBUG - 2011-08-04 20:13:37 --> Output Class Initialized
DEBUG - 2011-08-04 20:13:37 --> Input Class Initialized
DEBUG - 2011-08-04 20:13:37 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-04 20:13:37 --> Language Class Initialized
DEBUG - 2011-08-04 20:13:37 --> Loader Class Initialized
DEBUG - 2011-08-04 20:13:37 --> Controller Class Initialized
DEBUG - 2011-08-04 20:13:37 --> Model Class Initialized
DEBUG - 2011-08-04 20:13:37 --> Model Class Initialized
DEBUG - 2011-08-04 20:13:37 --> Model Class Initialized
DEBUG - 2011-08-04 20:13:37 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-04 20:13:37 --> Database Driver Class Initialized
DEBUG - 2011-08-04 20:13:37 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-04 20:13:37 --> Helper loaded: url_helper
DEBUG - 2011-08-04 20:13:37 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-04 20:13:37 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-04 20:13:37 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-04 20:13:37 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-04 20:13:37 --> Final output sent to browser
DEBUG - 2011-08-04 20:13:37 --> Total execution time: 0.0420
DEBUG - 2011-08-04 20:13:38 --> Config Class Initialized
DEBUG - 2011-08-04 20:13:38 --> Hooks Class Initialized
DEBUG - 2011-08-04 20:13:38 --> Utf8 Class Initialized
DEBUG - 2011-08-04 20:13:38 --> UTF-8 Support Enabled
DEBUG - 2011-08-04 20:13:38 --> URI Class Initialized
DEBUG - 2011-08-04 20:13:38 --> Router Class Initialized
ERROR - 2011-08-04 20:13:38 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-04 20:13:38 --> Config Class Initialized
DEBUG - 2011-08-04 20:13:38 --> Hooks Class Initialized
DEBUG - 2011-08-04 20:13:38 --> Utf8 Class Initialized
DEBUG - 2011-08-04 20:13:38 --> UTF-8 Support Enabled
DEBUG - 2011-08-04 20:13:38 --> URI Class Initialized
DEBUG - 2011-08-04 20:13:38 --> Router Class Initialized
DEBUG - 2011-08-04 20:13:38 --> Output Class Initialized
DEBUG - 2011-08-04 20:13:38 --> Input Class Initialized
DEBUG - 2011-08-04 20:13:38 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-04 20:13:38 --> Language Class Initialized
DEBUG - 2011-08-04 20:13:38 --> Loader Class Initialized
DEBUG - 2011-08-04 20:13:38 --> Controller Class Initialized
DEBUG - 2011-08-04 20:13:38 --> Model Class Initialized
DEBUG - 2011-08-04 20:13:38 --> Model Class Initialized
DEBUG - 2011-08-04 20:13:38 --> Model Class Initialized
DEBUG - 2011-08-04 20:13:38 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-04 20:13:38 --> Database Driver Class Initialized
DEBUG - 2011-08-04 20:13:38 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-04 20:13:38 --> Helper loaded: url_helper
DEBUG - 2011-08-04 20:13:38 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-04 20:13:38 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-04 20:13:38 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-04 20:13:38 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-04 20:13:38 --> Final output sent to browser
DEBUG - 2011-08-04 20:13:38 --> Total execution time: 0.0440
DEBUG - 2011-08-04 20:13:56 --> Config Class Initialized
DEBUG - 2011-08-04 20:13:56 --> Hooks Class Initialized
DEBUG - 2011-08-04 20:13:56 --> Utf8 Class Initialized
DEBUG - 2011-08-04 20:13:56 --> UTF-8 Support Enabled
DEBUG - 2011-08-04 20:13:56 --> URI Class Initialized
DEBUG - 2011-08-04 20:13:56 --> Router Class Initialized
DEBUG - 2011-08-04 20:13:56 --> Output Class Initialized
DEBUG - 2011-08-04 20:13:56 --> Input Class Initialized
DEBUG - 2011-08-04 20:13:56 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-04 20:13:56 --> Language Class Initialized
DEBUG - 2011-08-04 20:13:56 --> Loader Class Initialized
DEBUG - 2011-08-04 20:13:56 --> Controller Class Initialized
DEBUG - 2011-08-04 20:13:56 --> Model Class Initialized
DEBUG - 2011-08-04 20:13:56 --> Model Class Initialized
DEBUG - 2011-08-04 20:13:56 --> Model Class Initialized
DEBUG - 2011-08-04 20:13:56 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-04 20:13:56 --> Database Driver Class Initialized
DEBUG - 2011-08-04 20:13:57 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-04 20:13:57 --> Helper loaded: url_helper
DEBUG - 2011-08-04 20:13:57 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-04 20:13:57 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-04 20:13:57 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-04 20:13:57 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-04 20:13:57 --> Final output sent to browser
DEBUG - 2011-08-04 20:13:57 --> Total execution time: 0.6429
DEBUG - 2011-08-04 20:13:58 --> Config Class Initialized
DEBUG - 2011-08-04 20:13:58 --> Hooks Class Initialized
DEBUG - 2011-08-04 20:13:58 --> Utf8 Class Initialized
DEBUG - 2011-08-04 20:13:58 --> UTF-8 Support Enabled
DEBUG - 2011-08-04 20:13:58 --> URI Class Initialized
DEBUG - 2011-08-04 20:13:58 --> Router Class Initialized
DEBUG - 2011-08-04 20:13:58 --> Output Class Initialized
DEBUG - 2011-08-04 20:13:58 --> Input Class Initialized
DEBUG - 2011-08-04 20:13:58 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-04 20:13:58 --> Language Class Initialized
DEBUG - 2011-08-04 20:13:58 --> Loader Class Initialized
DEBUG - 2011-08-04 20:13:58 --> Controller Class Initialized
DEBUG - 2011-08-04 20:13:58 --> Model Class Initialized
DEBUG - 2011-08-04 20:13:58 --> Model Class Initialized
DEBUG - 2011-08-04 20:13:58 --> Model Class Initialized
DEBUG - 2011-08-04 20:13:58 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-04 20:13:58 --> Database Driver Class Initialized
DEBUG - 2011-08-04 20:13:58 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-04 20:13:58 --> Helper loaded: url_helper
DEBUG - 2011-08-04 20:13:58 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-04 20:13:58 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-04 20:13:58 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-04 20:13:58 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-04 20:13:58 --> Final output sent to browser
DEBUG - 2011-08-04 20:13:58 --> Total execution time: 0.0447
DEBUG - 2011-08-04 20:13:58 --> Config Class Initialized
DEBUG - 2011-08-04 20:13:58 --> Hooks Class Initialized
DEBUG - 2011-08-04 20:13:58 --> Utf8 Class Initialized
DEBUG - 2011-08-04 20:13:58 --> UTF-8 Support Enabled
DEBUG - 2011-08-04 20:13:58 --> URI Class Initialized
DEBUG - 2011-08-04 20:13:58 --> Router Class Initialized
DEBUG - 2011-08-04 20:13:58 --> Output Class Initialized
DEBUG - 2011-08-04 20:13:58 --> Input Class Initialized
DEBUG - 2011-08-04 20:13:58 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-04 20:13:58 --> Language Class Initialized
DEBUG - 2011-08-04 20:13:58 --> Loader Class Initialized
DEBUG - 2011-08-04 20:13:58 --> Controller Class Initialized
DEBUG - 2011-08-04 20:13:58 --> Model Class Initialized
DEBUG - 2011-08-04 20:13:58 --> Model Class Initialized
DEBUG - 2011-08-04 20:13:59 --> Model Class Initialized
DEBUG - 2011-08-04 20:13:59 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-04 20:13:59 --> Database Driver Class Initialized
DEBUG - 2011-08-04 20:13:59 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-04 20:13:59 --> Helper loaded: url_helper
DEBUG - 2011-08-04 20:13:59 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-04 20:13:59 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-04 20:13:59 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-04 20:13:59 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-04 20:13:59 --> Final output sent to browser
DEBUG - 2011-08-04 20:13:59 --> Total execution time: 0.0550
DEBUG - 2011-08-04 20:13:59 --> Config Class Initialized
DEBUG - 2011-08-04 20:13:59 --> Hooks Class Initialized
DEBUG - 2011-08-04 20:13:59 --> Utf8 Class Initialized
DEBUG - 2011-08-04 20:13:59 --> UTF-8 Support Enabled
DEBUG - 2011-08-04 20:13:59 --> URI Class Initialized
DEBUG - 2011-08-04 20:13:59 --> Router Class Initialized
ERROR - 2011-08-04 20:13:59 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-04 20:14:04 --> Config Class Initialized
DEBUG - 2011-08-04 20:14:04 --> Hooks Class Initialized
DEBUG - 2011-08-04 20:14:04 --> Utf8 Class Initialized
DEBUG - 2011-08-04 20:14:04 --> UTF-8 Support Enabled
DEBUG - 2011-08-04 20:14:04 --> URI Class Initialized
DEBUG - 2011-08-04 20:14:04 --> Router Class Initialized
DEBUG - 2011-08-04 20:14:04 --> Output Class Initialized
DEBUG - 2011-08-04 20:14:04 --> Input Class Initialized
DEBUG - 2011-08-04 20:14:04 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-04 20:14:04 --> Language Class Initialized
DEBUG - 2011-08-04 20:14:04 --> Loader Class Initialized
DEBUG - 2011-08-04 20:14:04 --> Controller Class Initialized
DEBUG - 2011-08-04 20:14:04 --> Model Class Initialized
DEBUG - 2011-08-04 20:14:04 --> Model Class Initialized
DEBUG - 2011-08-04 20:14:04 --> Model Class Initialized
DEBUG - 2011-08-04 20:14:04 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-04 20:14:04 --> Database Driver Class Initialized
DEBUG - 2011-08-04 20:14:04 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-04 20:14:04 --> Helper loaded: url_helper
DEBUG - 2011-08-04 20:14:04 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-04 20:14:04 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-04 20:14:04 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-04 20:14:04 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-04 20:14:04 --> Final output sent to browser
DEBUG - 2011-08-04 20:14:04 --> Total execution time: 0.4957
DEBUG - 2011-08-04 20:14:05 --> Config Class Initialized
DEBUG - 2011-08-04 20:14:05 --> Hooks Class Initialized
DEBUG - 2011-08-04 20:14:05 --> Utf8 Class Initialized
DEBUG - 2011-08-04 20:14:05 --> UTF-8 Support Enabled
DEBUG - 2011-08-04 20:14:05 --> URI Class Initialized
DEBUG - 2011-08-04 20:14:05 --> Router Class Initialized
DEBUG - 2011-08-04 20:14:05 --> Output Class Initialized
DEBUG - 2011-08-04 20:14:05 --> Input Class Initialized
DEBUG - 2011-08-04 20:14:05 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-04 20:14:05 --> Language Class Initialized
DEBUG - 2011-08-04 20:14:05 --> Loader Class Initialized
DEBUG - 2011-08-04 20:14:05 --> Controller Class Initialized
DEBUG - 2011-08-04 20:14:05 --> Model Class Initialized
DEBUG - 2011-08-04 20:14:05 --> Model Class Initialized
DEBUG - 2011-08-04 20:14:05 --> Model Class Initialized
DEBUG - 2011-08-04 20:14:05 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-04 20:14:05 --> Database Driver Class Initialized
DEBUG - 2011-08-04 20:14:05 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-04 20:14:05 --> Helper loaded: url_helper
DEBUG - 2011-08-04 20:14:05 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-04 20:14:05 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-04 20:14:05 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-04 20:14:05 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-04 20:14:05 --> Final output sent to browser
DEBUG - 2011-08-04 20:14:05 --> Total execution time: 0.0474
DEBUG - 2011-08-04 20:14:06 --> Config Class Initialized
DEBUG - 2011-08-04 20:14:06 --> Hooks Class Initialized
DEBUG - 2011-08-04 20:14:06 --> Utf8 Class Initialized
DEBUG - 2011-08-04 20:14:06 --> UTF-8 Support Enabled
DEBUG - 2011-08-04 20:14:06 --> URI Class Initialized
DEBUG - 2011-08-04 20:14:06 --> Router Class Initialized
ERROR - 2011-08-04 20:14:06 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-04 20:14:06 --> Config Class Initialized
DEBUG - 2011-08-04 20:14:06 --> Hooks Class Initialized
DEBUG - 2011-08-04 20:14:06 --> Utf8 Class Initialized
DEBUG - 2011-08-04 20:14:06 --> UTF-8 Support Enabled
DEBUG - 2011-08-04 20:14:06 --> URI Class Initialized
DEBUG - 2011-08-04 20:14:06 --> Router Class Initialized
ERROR - 2011-08-04 20:14:06 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-04 20:14:13 --> Config Class Initialized
DEBUG - 2011-08-04 20:14:13 --> Hooks Class Initialized
DEBUG - 2011-08-04 20:14:13 --> Utf8 Class Initialized
DEBUG - 2011-08-04 20:14:13 --> UTF-8 Support Enabled
DEBUG - 2011-08-04 20:14:13 --> URI Class Initialized
DEBUG - 2011-08-04 20:14:13 --> Router Class Initialized
DEBUG - 2011-08-04 20:14:13 --> Output Class Initialized
DEBUG - 2011-08-04 20:14:13 --> Input Class Initialized
DEBUG - 2011-08-04 20:14:13 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-04 20:14:13 --> Language Class Initialized
DEBUG - 2011-08-04 20:14:13 --> Loader Class Initialized
DEBUG - 2011-08-04 20:14:13 --> Controller Class Initialized
DEBUG - 2011-08-04 20:14:13 --> Model Class Initialized
DEBUG - 2011-08-04 20:14:13 --> Model Class Initialized
DEBUG - 2011-08-04 20:14:13 --> Model Class Initialized
DEBUG - 2011-08-04 20:14:13 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-04 20:14:13 --> Database Driver Class Initialized
DEBUG - 2011-08-04 20:14:13 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-04 20:14:13 --> Helper loaded: url_helper
DEBUG - 2011-08-04 20:14:13 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-04 20:14:13 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-04 20:14:13 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-04 20:14:13 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-04 20:14:13 --> Final output sent to browser
DEBUG - 2011-08-04 20:14:13 --> Total execution time: 0.2991
DEBUG - 2011-08-04 20:14:14 --> Config Class Initialized
DEBUG - 2011-08-04 20:14:14 --> Hooks Class Initialized
DEBUG - 2011-08-04 20:14:14 --> Utf8 Class Initialized
DEBUG - 2011-08-04 20:14:14 --> UTF-8 Support Enabled
DEBUG - 2011-08-04 20:14:14 --> URI Class Initialized
DEBUG - 2011-08-04 20:14:14 --> Router Class Initialized
DEBUG - 2011-08-04 20:14:14 --> Output Class Initialized
DEBUG - 2011-08-04 20:14:14 --> Input Class Initialized
DEBUG - 2011-08-04 20:14:14 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-04 20:14:14 --> Language Class Initialized
DEBUG - 2011-08-04 20:14:14 --> Loader Class Initialized
DEBUG - 2011-08-04 20:14:14 --> Controller Class Initialized
DEBUG - 2011-08-04 20:14:14 --> Model Class Initialized
DEBUG - 2011-08-04 20:14:14 --> Model Class Initialized
DEBUG - 2011-08-04 20:14:14 --> Model Class Initialized
DEBUG - 2011-08-04 20:14:14 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-04 20:14:14 --> Database Driver Class Initialized
DEBUG - 2011-08-04 20:14:14 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-04 20:14:14 --> Helper loaded: url_helper
DEBUG - 2011-08-04 20:14:14 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-04 20:14:14 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-04 20:14:14 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-04 20:14:14 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-04 20:14:14 --> Final output sent to browser
DEBUG - 2011-08-04 20:14:14 --> Total execution time: 0.0444
DEBUG - 2011-08-04 20:14:14 --> Config Class Initialized
DEBUG - 2011-08-04 20:14:14 --> Hooks Class Initialized
DEBUG - 2011-08-04 20:14:14 --> Utf8 Class Initialized
DEBUG - 2011-08-04 20:14:14 --> UTF-8 Support Enabled
DEBUG - 2011-08-04 20:14:14 --> URI Class Initialized
DEBUG - 2011-08-04 20:14:14 --> Router Class Initialized
DEBUG - 2011-08-04 20:14:14 --> Output Class Initialized
DEBUG - 2011-08-04 20:14:14 --> Input Class Initialized
DEBUG - 2011-08-04 20:14:14 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-04 20:14:14 --> Language Class Initialized
DEBUG - 2011-08-04 20:14:14 --> Loader Class Initialized
DEBUG - 2011-08-04 20:14:14 --> Controller Class Initialized
DEBUG - 2011-08-04 20:14:14 --> Model Class Initialized
DEBUG - 2011-08-04 20:14:14 --> Model Class Initialized
DEBUG - 2011-08-04 20:14:14 --> Model Class Initialized
DEBUG - 2011-08-04 20:14:14 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-04 20:14:14 --> Database Driver Class Initialized
DEBUG - 2011-08-04 20:14:14 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-04 20:14:14 --> Helper loaded: url_helper
DEBUG - 2011-08-04 20:14:14 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-04 20:14:14 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-04 20:14:14 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-04 20:14:14 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-04 20:14:14 --> Final output sent to browser
DEBUG - 2011-08-04 20:14:14 --> Total execution time: 0.0432
DEBUG - 2011-08-04 20:14:14 --> Config Class Initialized
DEBUG - 2011-08-04 20:14:14 --> Hooks Class Initialized
DEBUG - 2011-08-04 20:14:14 --> Utf8 Class Initialized
DEBUG - 2011-08-04 20:14:14 --> UTF-8 Support Enabled
DEBUG - 2011-08-04 20:14:14 --> URI Class Initialized
DEBUG - 2011-08-04 20:14:14 --> Router Class Initialized
ERROR - 2011-08-04 20:14:14 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-04 20:14:19 --> Config Class Initialized
DEBUG - 2011-08-04 20:14:19 --> Hooks Class Initialized
DEBUG - 2011-08-04 20:14:19 --> Utf8 Class Initialized
DEBUG - 2011-08-04 20:14:19 --> UTF-8 Support Enabled
DEBUG - 2011-08-04 20:14:19 --> URI Class Initialized
DEBUG - 2011-08-04 20:14:19 --> Router Class Initialized
DEBUG - 2011-08-04 20:14:19 --> Output Class Initialized
DEBUG - 2011-08-04 20:14:19 --> Input Class Initialized
DEBUG - 2011-08-04 20:14:19 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-04 20:14:19 --> Language Class Initialized
DEBUG - 2011-08-04 20:14:19 --> Loader Class Initialized
DEBUG - 2011-08-04 20:14:19 --> Controller Class Initialized
DEBUG - 2011-08-04 20:14:19 --> Model Class Initialized
DEBUG - 2011-08-04 20:14:19 --> Model Class Initialized
DEBUG - 2011-08-04 20:14:19 --> Model Class Initialized
DEBUG - 2011-08-04 20:14:19 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-04 20:14:19 --> Database Driver Class Initialized
DEBUG - 2011-08-04 20:14:19 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-04 20:14:19 --> Helper loaded: url_helper
DEBUG - 2011-08-04 20:14:19 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-04 20:14:19 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-04 20:14:19 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-04 20:14:19 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-04 20:14:19 --> Final output sent to browser
DEBUG - 2011-08-04 20:14:19 --> Total execution time: 0.3593
DEBUG - 2011-08-04 20:14:20 --> Config Class Initialized
DEBUG - 2011-08-04 20:14:20 --> Hooks Class Initialized
DEBUG - 2011-08-04 20:14:20 --> Utf8 Class Initialized
DEBUG - 2011-08-04 20:14:20 --> UTF-8 Support Enabled
DEBUG - 2011-08-04 20:14:20 --> URI Class Initialized
DEBUG - 2011-08-04 20:14:20 --> Router Class Initialized
DEBUG - 2011-08-04 20:14:20 --> Output Class Initialized
DEBUG - 2011-08-04 20:14:20 --> Input Class Initialized
DEBUG - 2011-08-04 20:14:20 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-04 20:14:20 --> Language Class Initialized
DEBUG - 2011-08-04 20:14:20 --> Loader Class Initialized
DEBUG - 2011-08-04 20:14:20 --> Controller Class Initialized
DEBUG - 2011-08-04 20:14:20 --> Model Class Initialized
DEBUG - 2011-08-04 20:14:20 --> Model Class Initialized
DEBUG - 2011-08-04 20:14:20 --> Model Class Initialized
DEBUG - 2011-08-04 20:14:20 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-04 20:14:20 --> Database Driver Class Initialized
DEBUG - 2011-08-04 20:14:20 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-04 20:14:20 --> Helper loaded: url_helper
DEBUG - 2011-08-04 20:14:20 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-04 20:14:20 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-04 20:14:20 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-04 20:14:20 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-04 20:14:20 --> Final output sent to browser
DEBUG - 2011-08-04 20:14:20 --> Total execution time: 0.1121
DEBUG - 2011-08-04 20:14:21 --> Config Class Initialized
DEBUG - 2011-08-04 20:14:21 --> Hooks Class Initialized
DEBUG - 2011-08-04 20:14:21 --> Utf8 Class Initialized
DEBUG - 2011-08-04 20:14:21 --> UTF-8 Support Enabled
DEBUG - 2011-08-04 20:14:21 --> URI Class Initialized
DEBUG - 2011-08-04 20:14:21 --> Router Class Initialized
DEBUG - 2011-08-04 20:14:21 --> Output Class Initialized
DEBUG - 2011-08-04 20:14:21 --> Input Class Initialized
DEBUG - 2011-08-04 20:14:21 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-04 20:14:21 --> Language Class Initialized
DEBUG - 2011-08-04 20:14:21 --> Loader Class Initialized
DEBUG - 2011-08-04 20:14:21 --> Controller Class Initialized
DEBUG - 2011-08-04 20:14:21 --> Model Class Initialized
DEBUG - 2011-08-04 20:14:21 --> Model Class Initialized
DEBUG - 2011-08-04 20:14:21 --> Model Class Initialized
DEBUG - 2011-08-04 20:14:21 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-04 20:14:21 --> Database Driver Class Initialized
DEBUG - 2011-08-04 20:14:21 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-04 20:14:21 --> Helper loaded: url_helper
DEBUG - 2011-08-04 20:14:21 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-04 20:14:21 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-04 20:14:21 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-04 20:14:21 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-04 20:14:21 --> Final output sent to browser
DEBUG - 2011-08-04 20:14:21 --> Total execution time: 0.0508
DEBUG - 2011-08-04 20:14:21 --> Config Class Initialized
DEBUG - 2011-08-04 20:14:21 --> Hooks Class Initialized
DEBUG - 2011-08-04 20:14:21 --> Utf8 Class Initialized
DEBUG - 2011-08-04 20:14:21 --> UTF-8 Support Enabled
DEBUG - 2011-08-04 20:14:21 --> URI Class Initialized
DEBUG - 2011-08-04 20:14:21 --> Router Class Initialized
ERROR - 2011-08-04 20:14:21 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-04 20:14:24 --> Config Class Initialized
DEBUG - 2011-08-04 20:14:24 --> Hooks Class Initialized
DEBUG - 2011-08-04 20:14:24 --> Utf8 Class Initialized
DEBUG - 2011-08-04 20:14:24 --> UTF-8 Support Enabled
DEBUG - 2011-08-04 20:14:24 --> URI Class Initialized
DEBUG - 2011-08-04 20:14:24 --> Router Class Initialized
DEBUG - 2011-08-04 20:14:24 --> Output Class Initialized
DEBUG - 2011-08-04 20:14:24 --> Input Class Initialized
DEBUG - 2011-08-04 20:14:24 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-04 20:14:24 --> Language Class Initialized
DEBUG - 2011-08-04 20:14:24 --> Loader Class Initialized
DEBUG - 2011-08-04 20:14:24 --> Controller Class Initialized
DEBUG - 2011-08-04 20:14:24 --> Model Class Initialized
DEBUG - 2011-08-04 20:14:24 --> Model Class Initialized
DEBUG - 2011-08-04 20:14:24 --> Model Class Initialized
DEBUG - 2011-08-04 20:14:24 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-04 20:14:24 --> Database Driver Class Initialized
DEBUG - 2011-08-04 20:14:24 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-04 20:14:24 --> Helper loaded: url_helper
DEBUG - 2011-08-04 20:14:24 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-04 20:14:24 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-04 20:14:24 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-04 20:14:24 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-04 20:14:24 --> Final output sent to browser
DEBUG - 2011-08-04 20:14:24 --> Total execution time: 0.2124
DEBUG - 2011-08-04 20:14:25 --> Config Class Initialized
DEBUG - 2011-08-04 20:14:25 --> Hooks Class Initialized
DEBUG - 2011-08-04 20:14:25 --> Utf8 Class Initialized
DEBUG - 2011-08-04 20:14:25 --> UTF-8 Support Enabled
DEBUG - 2011-08-04 20:14:25 --> URI Class Initialized
DEBUG - 2011-08-04 20:14:25 --> Router Class Initialized
DEBUG - 2011-08-04 20:14:25 --> Output Class Initialized
DEBUG - 2011-08-04 20:14:25 --> Input Class Initialized
DEBUG - 2011-08-04 20:14:25 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-04 20:14:25 --> Language Class Initialized
DEBUG - 2011-08-04 20:14:25 --> Loader Class Initialized
DEBUG - 2011-08-04 20:14:25 --> Controller Class Initialized
DEBUG - 2011-08-04 20:14:25 --> Model Class Initialized
DEBUG - 2011-08-04 20:14:25 --> Model Class Initialized
DEBUG - 2011-08-04 20:14:25 --> Model Class Initialized
DEBUG - 2011-08-04 20:14:25 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-04 20:14:25 --> Database Driver Class Initialized
DEBUG - 2011-08-04 20:14:25 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-04 20:14:25 --> Helper loaded: url_helper
DEBUG - 2011-08-04 20:14:25 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-04 20:14:25 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-04 20:14:25 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-04 20:14:25 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-04 20:14:25 --> Final output sent to browser
DEBUG - 2011-08-04 20:14:25 --> Total execution time: 0.0724
DEBUG - 2011-08-04 20:14:25 --> Config Class Initialized
DEBUG - 2011-08-04 20:14:25 --> Hooks Class Initialized
DEBUG - 2011-08-04 20:14:25 --> Utf8 Class Initialized
DEBUG - 2011-08-04 20:14:25 --> UTF-8 Support Enabled
DEBUG - 2011-08-04 20:14:25 --> URI Class Initialized
DEBUG - 2011-08-04 20:14:25 --> Router Class Initialized
DEBUG - 2011-08-04 20:14:25 --> Output Class Initialized
DEBUG - 2011-08-04 20:14:25 --> Input Class Initialized
DEBUG - 2011-08-04 20:14:25 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-04 20:14:25 --> Language Class Initialized
DEBUG - 2011-08-04 20:14:25 --> Loader Class Initialized
DEBUG - 2011-08-04 20:14:25 --> Controller Class Initialized
DEBUG - 2011-08-04 20:14:25 --> Model Class Initialized
DEBUG - 2011-08-04 20:14:25 --> Model Class Initialized
DEBUG - 2011-08-04 20:14:25 --> Model Class Initialized
DEBUG - 2011-08-04 20:14:25 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-04 20:14:25 --> Database Driver Class Initialized
DEBUG - 2011-08-04 20:14:25 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-04 20:14:25 --> Helper loaded: url_helper
DEBUG - 2011-08-04 20:14:25 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-04 20:14:25 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-04 20:14:25 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-04 20:14:25 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-04 20:14:25 --> Final output sent to browser
DEBUG - 2011-08-04 20:14:25 --> Total execution time: 0.0781
DEBUG - 2011-08-04 20:14:25 --> Config Class Initialized
DEBUG - 2011-08-04 20:14:25 --> Hooks Class Initialized
DEBUG - 2011-08-04 20:14:25 --> Utf8 Class Initialized
DEBUG - 2011-08-04 20:14:25 --> UTF-8 Support Enabled
DEBUG - 2011-08-04 20:14:25 --> URI Class Initialized
DEBUG - 2011-08-04 20:14:25 --> Router Class Initialized
ERROR - 2011-08-04 20:14:25 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-04 20:14:28 --> Config Class Initialized
DEBUG - 2011-08-04 20:14:28 --> Hooks Class Initialized
DEBUG - 2011-08-04 20:14:28 --> Utf8 Class Initialized
DEBUG - 2011-08-04 20:14:28 --> UTF-8 Support Enabled
DEBUG - 2011-08-04 20:14:28 --> URI Class Initialized
DEBUG - 2011-08-04 20:14:28 --> Router Class Initialized
DEBUG - 2011-08-04 20:14:28 --> Output Class Initialized
DEBUG - 2011-08-04 20:14:28 --> Input Class Initialized
DEBUG - 2011-08-04 20:14:28 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-04 20:14:28 --> Language Class Initialized
DEBUG - 2011-08-04 20:14:28 --> Loader Class Initialized
DEBUG - 2011-08-04 20:14:28 --> Controller Class Initialized
DEBUG - 2011-08-04 20:14:28 --> Model Class Initialized
DEBUG - 2011-08-04 20:14:28 --> Model Class Initialized
DEBUG - 2011-08-04 20:14:28 --> Model Class Initialized
DEBUG - 2011-08-04 20:14:28 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-04 20:14:28 --> Database Driver Class Initialized
DEBUG - 2011-08-04 20:14:28 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-04 20:14:28 --> Helper loaded: url_helper
DEBUG - 2011-08-04 20:14:28 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-04 20:14:28 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-04 20:14:28 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-04 20:14:28 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-04 20:14:28 --> Final output sent to browser
DEBUG - 2011-08-04 20:14:28 --> Total execution time: 0.2319
DEBUG - 2011-08-04 20:14:29 --> Config Class Initialized
DEBUG - 2011-08-04 20:14:29 --> Hooks Class Initialized
DEBUG - 2011-08-04 20:14:29 --> Utf8 Class Initialized
DEBUG - 2011-08-04 20:14:29 --> UTF-8 Support Enabled
DEBUG - 2011-08-04 20:14:29 --> URI Class Initialized
DEBUG - 2011-08-04 20:14:29 --> Router Class Initialized
DEBUG - 2011-08-04 20:14:29 --> Output Class Initialized
DEBUG - 2011-08-04 20:14:29 --> Input Class Initialized
DEBUG - 2011-08-04 20:14:29 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-04 20:14:29 --> Language Class Initialized
DEBUG - 2011-08-04 20:14:29 --> Loader Class Initialized
DEBUG - 2011-08-04 20:14:29 --> Controller Class Initialized
DEBUG - 2011-08-04 20:14:29 --> Model Class Initialized
DEBUG - 2011-08-04 20:14:29 --> Model Class Initialized
DEBUG - 2011-08-04 20:14:29 --> Model Class Initialized
DEBUG - 2011-08-04 20:14:29 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-04 20:14:29 --> Database Driver Class Initialized
DEBUG - 2011-08-04 20:14:29 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-04 20:14:29 --> Helper loaded: url_helper
DEBUG - 2011-08-04 20:14:29 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-04 20:14:29 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-04 20:14:29 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-04 20:14:29 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-04 20:14:29 --> Final output sent to browser
DEBUG - 2011-08-04 20:14:29 --> Total execution time: 0.0485
DEBUG - 2011-08-04 20:14:29 --> Config Class Initialized
DEBUG - 2011-08-04 20:14:29 --> Hooks Class Initialized
DEBUG - 2011-08-04 20:14:29 --> Utf8 Class Initialized
DEBUG - 2011-08-04 20:14:29 --> UTF-8 Support Enabled
DEBUG - 2011-08-04 20:14:29 --> URI Class Initialized
DEBUG - 2011-08-04 20:14:29 --> Router Class Initialized
ERROR - 2011-08-04 20:14:29 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-04 20:14:33 --> Config Class Initialized
DEBUG - 2011-08-04 20:14:33 --> Hooks Class Initialized
DEBUG - 2011-08-04 20:14:33 --> Utf8 Class Initialized
DEBUG - 2011-08-04 20:14:33 --> UTF-8 Support Enabled
DEBUG - 2011-08-04 20:14:33 --> URI Class Initialized
DEBUG - 2011-08-04 20:14:33 --> Router Class Initialized
DEBUG - 2011-08-04 20:14:33 --> Output Class Initialized
DEBUG - 2011-08-04 20:14:33 --> Input Class Initialized
DEBUG - 2011-08-04 20:14:33 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-04 20:14:33 --> Language Class Initialized
DEBUG - 2011-08-04 20:14:33 --> Loader Class Initialized
DEBUG - 2011-08-04 20:14:33 --> Controller Class Initialized
DEBUG - 2011-08-04 20:14:33 --> Model Class Initialized
DEBUG - 2011-08-04 20:14:33 --> Model Class Initialized
DEBUG - 2011-08-04 20:14:33 --> Model Class Initialized
DEBUG - 2011-08-04 20:14:33 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-04 20:14:33 --> Database Driver Class Initialized
DEBUG - 2011-08-04 20:14:33 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-04 20:14:33 --> Helper loaded: url_helper
DEBUG - 2011-08-04 20:14:33 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-04 20:14:33 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-04 20:14:33 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-04 20:14:33 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-04 20:14:33 --> Final output sent to browser
DEBUG - 2011-08-04 20:14:33 --> Total execution time: 0.2769
DEBUG - 2011-08-04 20:14:33 --> Config Class Initialized
DEBUG - 2011-08-04 20:14:33 --> Hooks Class Initialized
DEBUG - 2011-08-04 20:14:33 --> Utf8 Class Initialized
DEBUG - 2011-08-04 20:14:33 --> UTF-8 Support Enabled
DEBUG - 2011-08-04 20:14:33 --> URI Class Initialized
DEBUG - 2011-08-04 20:14:33 --> Router Class Initialized
DEBUG - 2011-08-04 20:14:33 --> Output Class Initialized
DEBUG - 2011-08-04 20:14:33 --> Input Class Initialized
DEBUG - 2011-08-04 20:14:33 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-04 20:14:33 --> Language Class Initialized
DEBUG - 2011-08-04 20:14:33 --> Loader Class Initialized
DEBUG - 2011-08-04 20:14:33 --> Controller Class Initialized
DEBUG - 2011-08-04 20:14:33 --> Model Class Initialized
DEBUG - 2011-08-04 20:14:33 --> Model Class Initialized
DEBUG - 2011-08-04 20:14:33 --> Model Class Initialized
DEBUG - 2011-08-04 20:14:33 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-04 20:14:33 --> Database Driver Class Initialized
DEBUG - 2011-08-04 20:14:33 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-04 20:14:33 --> Helper loaded: url_helper
DEBUG - 2011-08-04 20:14:33 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-04 20:14:33 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-04 20:14:33 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-04 20:14:33 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-04 20:14:33 --> Final output sent to browser
DEBUG - 2011-08-04 20:14:33 --> Total execution time: 0.0415
DEBUG - 2011-08-04 20:14:34 --> Config Class Initialized
DEBUG - 2011-08-04 20:14:34 --> Hooks Class Initialized
DEBUG - 2011-08-04 20:14:34 --> Utf8 Class Initialized
DEBUG - 2011-08-04 20:14:34 --> UTF-8 Support Enabled
DEBUG - 2011-08-04 20:14:34 --> URI Class Initialized
DEBUG - 2011-08-04 20:14:34 --> Router Class Initialized
DEBUG - 2011-08-04 20:14:34 --> Output Class Initialized
DEBUG - 2011-08-04 20:14:34 --> Input Class Initialized
DEBUG - 2011-08-04 20:14:34 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-04 20:14:34 --> Language Class Initialized
DEBUG - 2011-08-04 20:14:34 --> Loader Class Initialized
DEBUG - 2011-08-04 20:14:34 --> Controller Class Initialized
DEBUG - 2011-08-04 20:14:34 --> Model Class Initialized
DEBUG - 2011-08-04 20:14:34 --> Model Class Initialized
DEBUG - 2011-08-04 20:14:34 --> Model Class Initialized
DEBUG - 2011-08-04 20:14:34 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-04 20:14:34 --> Database Driver Class Initialized
DEBUG - 2011-08-04 20:14:34 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-04 20:14:34 --> Helper loaded: url_helper
DEBUG - 2011-08-04 20:14:34 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-04 20:14:34 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-04 20:14:34 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-04 20:14:34 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-04 20:14:34 --> Final output sent to browser
DEBUG - 2011-08-04 20:14:34 --> Total execution time: 0.0456
DEBUG - 2011-08-04 20:14:35 --> Config Class Initialized
DEBUG - 2011-08-04 20:14:35 --> Hooks Class Initialized
DEBUG - 2011-08-04 20:14:35 --> Utf8 Class Initialized
DEBUG - 2011-08-04 20:14:35 --> UTF-8 Support Enabled
DEBUG - 2011-08-04 20:14:35 --> URI Class Initialized
DEBUG - 2011-08-04 20:14:35 --> Router Class Initialized
ERROR - 2011-08-04 20:14:35 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-04 20:14:37 --> Config Class Initialized
DEBUG - 2011-08-04 20:14:37 --> Hooks Class Initialized
DEBUG - 2011-08-04 20:14:37 --> Utf8 Class Initialized
DEBUG - 2011-08-04 20:14:37 --> UTF-8 Support Enabled
DEBUG - 2011-08-04 20:14:37 --> URI Class Initialized
DEBUG - 2011-08-04 20:14:37 --> Router Class Initialized
DEBUG - 2011-08-04 20:14:37 --> Output Class Initialized
DEBUG - 2011-08-04 20:14:37 --> Input Class Initialized
DEBUG - 2011-08-04 20:14:37 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-04 20:14:37 --> Language Class Initialized
DEBUG - 2011-08-04 20:14:37 --> Loader Class Initialized
DEBUG - 2011-08-04 20:14:37 --> Controller Class Initialized
DEBUG - 2011-08-04 20:14:37 --> Model Class Initialized
DEBUG - 2011-08-04 20:14:37 --> Model Class Initialized
DEBUG - 2011-08-04 20:14:37 --> Model Class Initialized
DEBUG - 2011-08-04 20:14:37 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-04 20:14:37 --> Database Driver Class Initialized
DEBUG - 2011-08-04 20:14:38 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-04 20:14:38 --> Helper loaded: url_helper
DEBUG - 2011-08-04 20:14:38 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-04 20:14:38 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-04 20:14:38 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-04 20:14:38 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-04 20:14:38 --> Final output sent to browser
DEBUG - 2011-08-04 20:14:38 --> Total execution time: 0.3230
DEBUG - 2011-08-04 20:14:38 --> Config Class Initialized
DEBUG - 2011-08-04 20:14:38 --> Hooks Class Initialized
DEBUG - 2011-08-04 20:14:38 --> Utf8 Class Initialized
DEBUG - 2011-08-04 20:14:38 --> UTF-8 Support Enabled
DEBUG - 2011-08-04 20:14:38 --> URI Class Initialized
DEBUG - 2011-08-04 20:14:38 --> Router Class Initialized
DEBUG - 2011-08-04 20:14:38 --> Output Class Initialized
DEBUG - 2011-08-04 20:14:38 --> Input Class Initialized
DEBUG - 2011-08-04 20:14:38 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-04 20:14:38 --> Language Class Initialized
DEBUG - 2011-08-04 20:14:38 --> Loader Class Initialized
DEBUG - 2011-08-04 20:14:38 --> Controller Class Initialized
DEBUG - 2011-08-04 20:14:38 --> Model Class Initialized
DEBUG - 2011-08-04 20:14:38 --> Model Class Initialized
DEBUG - 2011-08-04 20:14:38 --> Model Class Initialized
DEBUG - 2011-08-04 20:14:38 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-04 20:14:38 --> Database Driver Class Initialized
DEBUG - 2011-08-04 20:14:38 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-04 20:14:38 --> Helper loaded: url_helper
DEBUG - 2011-08-04 20:14:38 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-04 20:14:38 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-04 20:14:38 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-04 20:14:38 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-04 20:14:38 --> Final output sent to browser
DEBUG - 2011-08-04 20:14:38 --> Total execution time: 0.0418
DEBUG - 2011-08-04 20:14:39 --> Config Class Initialized
DEBUG - 2011-08-04 20:14:39 --> Hooks Class Initialized
DEBUG - 2011-08-04 20:14:39 --> Utf8 Class Initialized
DEBUG - 2011-08-04 20:14:39 --> UTF-8 Support Enabled
DEBUG - 2011-08-04 20:14:39 --> URI Class Initialized
DEBUG - 2011-08-04 20:14:39 --> Router Class Initialized
ERROR - 2011-08-04 20:14:39 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-04 20:14:41 --> Config Class Initialized
DEBUG - 2011-08-04 20:14:41 --> Hooks Class Initialized
DEBUG - 2011-08-04 20:14:41 --> Utf8 Class Initialized
DEBUG - 2011-08-04 20:14:41 --> UTF-8 Support Enabled
DEBUG - 2011-08-04 20:14:41 --> URI Class Initialized
DEBUG - 2011-08-04 20:14:41 --> Router Class Initialized
DEBUG - 2011-08-04 20:14:41 --> Output Class Initialized
DEBUG - 2011-08-04 20:14:41 --> Input Class Initialized
DEBUG - 2011-08-04 20:14:41 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-04 20:14:41 --> Language Class Initialized
DEBUG - 2011-08-04 20:14:41 --> Loader Class Initialized
DEBUG - 2011-08-04 20:14:41 --> Controller Class Initialized
DEBUG - 2011-08-04 20:14:41 --> Model Class Initialized
DEBUG - 2011-08-04 20:14:41 --> Model Class Initialized
DEBUG - 2011-08-04 20:14:41 --> Model Class Initialized
DEBUG - 2011-08-04 20:14:41 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-04 20:14:41 --> Database Driver Class Initialized
DEBUG - 2011-08-04 20:14:41 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-04 20:14:41 --> Helper loaded: url_helper
DEBUG - 2011-08-04 20:14:41 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-04 20:14:41 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-04 20:14:41 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-04 20:14:41 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-04 20:14:41 --> Final output sent to browser
DEBUG - 2011-08-04 20:14:41 --> Total execution time: 0.2486
DEBUG - 2011-08-04 20:14:42 --> Config Class Initialized
DEBUG - 2011-08-04 20:14:42 --> Hooks Class Initialized
DEBUG - 2011-08-04 20:14:42 --> Utf8 Class Initialized
DEBUG - 2011-08-04 20:14:42 --> UTF-8 Support Enabled
DEBUG - 2011-08-04 20:14:42 --> URI Class Initialized
DEBUG - 2011-08-04 20:14:42 --> Router Class Initialized
DEBUG - 2011-08-04 20:14:42 --> Output Class Initialized
DEBUG - 2011-08-04 20:14:42 --> Input Class Initialized
DEBUG - 2011-08-04 20:14:42 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-04 20:14:42 --> Language Class Initialized
DEBUG - 2011-08-04 20:14:42 --> Loader Class Initialized
DEBUG - 2011-08-04 20:14:42 --> Controller Class Initialized
DEBUG - 2011-08-04 20:14:42 --> Model Class Initialized
DEBUG - 2011-08-04 20:14:42 --> Model Class Initialized
DEBUG - 2011-08-04 20:14:42 --> Model Class Initialized
DEBUG - 2011-08-04 20:14:42 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-04 20:14:42 --> Database Driver Class Initialized
DEBUG - 2011-08-04 20:14:42 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-04 20:14:42 --> Helper loaded: url_helper
DEBUG - 2011-08-04 20:14:42 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-04 20:14:42 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-04 20:14:42 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-04 20:14:42 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-04 20:14:42 --> Final output sent to browser
DEBUG - 2011-08-04 20:14:42 --> Total execution time: 0.0502
DEBUG - 2011-08-04 20:14:42 --> Config Class Initialized
DEBUG - 2011-08-04 20:14:42 --> Hooks Class Initialized
DEBUG - 2011-08-04 20:14:42 --> Utf8 Class Initialized
DEBUG - 2011-08-04 20:14:42 --> UTF-8 Support Enabled
DEBUG - 2011-08-04 20:14:42 --> URI Class Initialized
DEBUG - 2011-08-04 20:14:42 --> Router Class Initialized
DEBUG - 2011-08-04 20:14:42 --> Output Class Initialized
DEBUG - 2011-08-04 20:14:42 --> Input Class Initialized
DEBUG - 2011-08-04 20:14:42 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-04 20:14:42 --> Language Class Initialized
DEBUG - 2011-08-04 20:14:42 --> Loader Class Initialized
DEBUG - 2011-08-04 20:14:42 --> Controller Class Initialized
DEBUG - 2011-08-04 20:14:42 --> Model Class Initialized
DEBUG - 2011-08-04 20:14:42 --> Model Class Initialized
DEBUG - 2011-08-04 20:14:42 --> Model Class Initialized
DEBUG - 2011-08-04 20:14:42 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-04 20:14:42 --> Database Driver Class Initialized
DEBUG - 2011-08-04 20:14:42 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-04 20:14:42 --> Helper loaded: url_helper
DEBUG - 2011-08-04 20:14:42 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-04 20:14:42 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-04 20:14:42 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-04 20:14:42 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-04 20:14:42 --> Final output sent to browser
DEBUG - 2011-08-04 20:14:42 --> Total execution time: 0.0507
DEBUG - 2011-08-04 20:14:42 --> Config Class Initialized
DEBUG - 2011-08-04 20:14:42 --> Hooks Class Initialized
DEBUG - 2011-08-04 20:14:42 --> Utf8 Class Initialized
DEBUG - 2011-08-04 20:14:42 --> UTF-8 Support Enabled
DEBUG - 2011-08-04 20:14:42 --> URI Class Initialized
DEBUG - 2011-08-04 20:14:42 --> Router Class Initialized
ERROR - 2011-08-04 20:14:42 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-04 20:14:44 --> Config Class Initialized
DEBUG - 2011-08-04 20:14:44 --> Hooks Class Initialized
DEBUG - 2011-08-04 20:14:44 --> Utf8 Class Initialized
DEBUG - 2011-08-04 20:14:44 --> UTF-8 Support Enabled
DEBUG - 2011-08-04 20:14:44 --> URI Class Initialized
DEBUG - 2011-08-04 20:14:44 --> Router Class Initialized
DEBUG - 2011-08-04 20:14:44 --> Output Class Initialized
DEBUG - 2011-08-04 20:14:44 --> Input Class Initialized
DEBUG - 2011-08-04 20:14:44 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-04 20:14:44 --> Language Class Initialized
DEBUG - 2011-08-04 20:14:44 --> Loader Class Initialized
DEBUG - 2011-08-04 20:14:44 --> Controller Class Initialized
DEBUG - 2011-08-04 20:14:44 --> Model Class Initialized
DEBUG - 2011-08-04 20:14:44 --> Model Class Initialized
DEBUG - 2011-08-04 20:14:44 --> Model Class Initialized
DEBUG - 2011-08-04 20:14:44 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-04 20:14:44 --> Database Driver Class Initialized
DEBUG - 2011-08-04 20:14:44 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-04 20:14:44 --> Helper loaded: url_helper
DEBUG - 2011-08-04 20:14:44 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-04 20:14:44 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-04 20:14:44 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-04 20:14:44 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-04 20:14:44 --> Final output sent to browser
DEBUG - 2011-08-04 20:14:44 --> Total execution time: 0.2299
DEBUG - 2011-08-04 20:14:45 --> Config Class Initialized
DEBUG - 2011-08-04 20:14:45 --> Hooks Class Initialized
DEBUG - 2011-08-04 20:14:45 --> Utf8 Class Initialized
DEBUG - 2011-08-04 20:14:45 --> UTF-8 Support Enabled
DEBUG - 2011-08-04 20:14:45 --> URI Class Initialized
DEBUG - 2011-08-04 20:14:45 --> Router Class Initialized
DEBUG - 2011-08-04 20:14:45 --> Output Class Initialized
DEBUG - 2011-08-04 20:14:45 --> Input Class Initialized
DEBUG - 2011-08-04 20:14:45 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-04 20:14:45 --> Language Class Initialized
DEBUG - 2011-08-04 20:14:45 --> Loader Class Initialized
DEBUG - 2011-08-04 20:14:45 --> Controller Class Initialized
DEBUG - 2011-08-04 20:14:45 --> Model Class Initialized
DEBUG - 2011-08-04 20:14:45 --> Model Class Initialized
DEBUG - 2011-08-04 20:14:45 --> Model Class Initialized
DEBUG - 2011-08-04 20:14:45 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-04 20:14:45 --> Database Driver Class Initialized
DEBUG - 2011-08-04 20:14:45 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-04 20:14:45 --> Helper loaded: url_helper
DEBUG - 2011-08-04 20:14:45 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-04 20:14:45 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-04 20:14:45 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-04 20:14:45 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-04 20:14:45 --> Final output sent to browser
DEBUG - 2011-08-04 20:14:45 --> Total execution time: 0.0435
DEBUG - 2011-08-04 20:14:46 --> Config Class Initialized
DEBUG - 2011-08-04 20:14:46 --> Hooks Class Initialized
DEBUG - 2011-08-04 20:14:46 --> Utf8 Class Initialized
DEBUG - 2011-08-04 20:14:46 --> UTF-8 Support Enabled
DEBUG - 2011-08-04 20:14:46 --> URI Class Initialized
DEBUG - 2011-08-04 20:14:46 --> Router Class Initialized
ERROR - 2011-08-04 20:14:46 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-04 20:14:47 --> Config Class Initialized
DEBUG - 2011-08-04 20:14:47 --> Hooks Class Initialized
DEBUG - 2011-08-04 20:14:47 --> Utf8 Class Initialized
DEBUG - 2011-08-04 20:14:47 --> UTF-8 Support Enabled
DEBUG - 2011-08-04 20:14:47 --> URI Class Initialized
DEBUG - 2011-08-04 20:14:47 --> Router Class Initialized
DEBUG - 2011-08-04 20:14:47 --> Output Class Initialized
DEBUG - 2011-08-04 20:14:47 --> Input Class Initialized
DEBUG - 2011-08-04 20:14:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-04 20:14:47 --> Language Class Initialized
DEBUG - 2011-08-04 20:14:47 --> Loader Class Initialized
DEBUG - 2011-08-04 20:14:47 --> Controller Class Initialized
DEBUG - 2011-08-04 20:14:47 --> Model Class Initialized
DEBUG - 2011-08-04 20:14:47 --> Model Class Initialized
DEBUG - 2011-08-04 20:14:47 --> Model Class Initialized
DEBUG - 2011-08-04 20:14:47 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-04 20:14:47 --> Database Driver Class Initialized
DEBUG - 2011-08-04 20:14:48 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-04 20:14:48 --> Helper loaded: url_helper
DEBUG - 2011-08-04 20:14:48 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-04 20:14:48 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-04 20:14:48 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-04 20:14:48 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-04 20:14:48 --> Final output sent to browser
DEBUG - 2011-08-04 20:14:48 --> Total execution time: 0.2454
DEBUG - 2011-08-04 20:14:48 --> Config Class Initialized
DEBUG - 2011-08-04 20:14:48 --> Hooks Class Initialized
DEBUG - 2011-08-04 20:14:48 --> Utf8 Class Initialized
DEBUG - 2011-08-04 20:14:48 --> UTF-8 Support Enabled
DEBUG - 2011-08-04 20:14:48 --> URI Class Initialized
DEBUG - 2011-08-04 20:14:48 --> Router Class Initialized
DEBUG - 2011-08-04 20:14:48 --> Output Class Initialized
DEBUG - 2011-08-04 20:14:48 --> Input Class Initialized
DEBUG - 2011-08-04 20:14:48 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-04 20:14:48 --> Language Class Initialized
DEBUG - 2011-08-04 20:14:48 --> Loader Class Initialized
DEBUG - 2011-08-04 20:14:48 --> Controller Class Initialized
DEBUG - 2011-08-04 20:14:48 --> Model Class Initialized
DEBUG - 2011-08-04 20:14:48 --> Model Class Initialized
DEBUG - 2011-08-04 20:14:48 --> Model Class Initialized
DEBUG - 2011-08-04 20:14:48 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-04 20:14:48 --> Database Driver Class Initialized
DEBUG - 2011-08-04 20:14:48 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-04 20:14:48 --> Helper loaded: url_helper
DEBUG - 2011-08-04 20:14:48 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-04 20:14:48 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-04 20:14:48 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-04 20:14:48 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-04 20:14:48 --> Final output sent to browser
DEBUG - 2011-08-04 20:14:48 --> Total execution time: 0.0510
DEBUG - 2011-08-04 20:14:49 --> Config Class Initialized
DEBUG - 2011-08-04 20:14:49 --> Hooks Class Initialized
DEBUG - 2011-08-04 20:14:49 --> Utf8 Class Initialized
DEBUG - 2011-08-04 20:14:49 --> UTF-8 Support Enabled
DEBUG - 2011-08-04 20:14:49 --> URI Class Initialized
DEBUG - 2011-08-04 20:14:49 --> Router Class Initialized
ERROR - 2011-08-04 20:14:49 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-04 20:14:49 --> Config Class Initialized
DEBUG - 2011-08-04 20:14:49 --> Hooks Class Initialized
DEBUG - 2011-08-04 20:14:49 --> Utf8 Class Initialized
DEBUG - 2011-08-04 20:14:49 --> UTF-8 Support Enabled
DEBUG - 2011-08-04 20:14:49 --> URI Class Initialized
DEBUG - 2011-08-04 20:14:49 --> Router Class Initialized
ERROR - 2011-08-04 20:14:49 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-04 20:14:54 --> Config Class Initialized
DEBUG - 2011-08-04 20:14:54 --> Hooks Class Initialized
DEBUG - 2011-08-04 20:14:54 --> Utf8 Class Initialized
DEBUG - 2011-08-04 20:14:54 --> UTF-8 Support Enabled
DEBUG - 2011-08-04 20:14:54 --> URI Class Initialized
DEBUG - 2011-08-04 20:14:54 --> Router Class Initialized
DEBUG - 2011-08-04 20:14:54 --> Output Class Initialized
DEBUG - 2011-08-04 20:14:54 --> Input Class Initialized
DEBUG - 2011-08-04 20:14:54 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-04 20:14:54 --> Language Class Initialized
DEBUG - 2011-08-04 20:14:54 --> Loader Class Initialized
DEBUG - 2011-08-04 20:14:54 --> Controller Class Initialized
DEBUG - 2011-08-04 20:14:54 --> Model Class Initialized
DEBUG - 2011-08-04 20:14:54 --> Model Class Initialized
DEBUG - 2011-08-04 20:14:54 --> Model Class Initialized
DEBUG - 2011-08-04 20:14:54 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-04 20:14:54 --> Database Driver Class Initialized
DEBUG - 2011-08-04 20:14:55 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-04 20:14:55 --> Helper loaded: url_helper
DEBUG - 2011-08-04 20:14:55 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-04 20:14:55 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-04 20:14:55 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-04 20:14:55 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-04 20:14:55 --> Final output sent to browser
DEBUG - 2011-08-04 20:14:55 --> Total execution time: 0.2227
DEBUG - 2011-08-04 20:14:56 --> Config Class Initialized
DEBUG - 2011-08-04 20:14:56 --> Hooks Class Initialized
DEBUG - 2011-08-04 20:14:56 --> Utf8 Class Initialized
DEBUG - 2011-08-04 20:14:56 --> UTF-8 Support Enabled
DEBUG - 2011-08-04 20:14:56 --> URI Class Initialized
DEBUG - 2011-08-04 20:14:56 --> Router Class Initialized
ERROR - 2011-08-04 20:14:56 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-04 20:14:56 --> Config Class Initialized
DEBUG - 2011-08-04 20:14:56 --> Hooks Class Initialized
DEBUG - 2011-08-04 20:14:56 --> Utf8 Class Initialized
DEBUG - 2011-08-04 20:14:56 --> UTF-8 Support Enabled
DEBUG - 2011-08-04 20:14:56 --> URI Class Initialized
DEBUG - 2011-08-04 20:14:56 --> Router Class Initialized
DEBUG - 2011-08-04 20:14:56 --> Output Class Initialized
DEBUG - 2011-08-04 20:14:56 --> Input Class Initialized
DEBUG - 2011-08-04 20:14:56 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-04 20:14:56 --> Language Class Initialized
DEBUG - 2011-08-04 20:14:56 --> Loader Class Initialized
DEBUG - 2011-08-04 20:14:56 --> Controller Class Initialized
DEBUG - 2011-08-04 20:14:56 --> Model Class Initialized
DEBUG - 2011-08-04 20:14:56 --> Model Class Initialized
DEBUG - 2011-08-04 20:14:56 --> Model Class Initialized
DEBUG - 2011-08-04 20:14:56 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-04 20:14:56 --> Database Driver Class Initialized
DEBUG - 2011-08-04 20:14:56 --> Config Class Initialized
DEBUG - 2011-08-04 20:14:56 --> Hooks Class Initialized
DEBUG - 2011-08-04 20:14:56 --> Utf8 Class Initialized
DEBUG - 2011-08-04 20:14:56 --> UTF-8 Support Enabled
DEBUG - 2011-08-04 20:14:56 --> URI Class Initialized
DEBUG - 2011-08-04 20:14:56 --> Router Class Initialized
ERROR - 2011-08-04 20:14:56 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-04 20:14:56 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-04 20:14:56 --> Helper loaded: url_helper
DEBUG - 2011-08-04 20:14:56 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-04 20:14:56 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-04 20:14:56 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-04 20:14:56 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-04 20:14:56 --> Final output sent to browser
DEBUG - 2011-08-04 20:14:56 --> Total execution time: 0.1845
DEBUG - 2011-08-04 20:15:01 --> Config Class Initialized
DEBUG - 2011-08-04 20:15:01 --> Hooks Class Initialized
DEBUG - 2011-08-04 20:15:01 --> Utf8 Class Initialized
DEBUG - 2011-08-04 20:15:01 --> UTF-8 Support Enabled
DEBUG - 2011-08-04 20:15:01 --> URI Class Initialized
DEBUG - 2011-08-04 20:15:01 --> Router Class Initialized
DEBUG - 2011-08-04 20:15:01 --> Output Class Initialized
DEBUG - 2011-08-04 20:15:01 --> Input Class Initialized
DEBUG - 2011-08-04 20:15:01 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-04 20:15:01 --> Language Class Initialized
DEBUG - 2011-08-04 20:15:01 --> Loader Class Initialized
DEBUG - 2011-08-04 20:15:01 --> Controller Class Initialized
DEBUG - 2011-08-04 20:15:01 --> Model Class Initialized
DEBUG - 2011-08-04 20:15:01 --> Model Class Initialized
DEBUG - 2011-08-04 20:15:01 --> Model Class Initialized
DEBUG - 2011-08-04 20:15:01 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-04 20:15:01 --> Database Driver Class Initialized
DEBUG - 2011-08-04 20:15:03 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-04 20:15:03 --> Helper loaded: url_helper
DEBUG - 2011-08-04 20:15:03 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-04 20:15:03 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-04 20:15:03 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-04 20:15:03 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-04 20:15:03 --> Final output sent to browser
DEBUG - 2011-08-04 20:15:03 --> Total execution time: 1.5746
DEBUG - 2011-08-04 20:15:04 --> Config Class Initialized
DEBUG - 2011-08-04 20:15:04 --> Hooks Class Initialized
DEBUG - 2011-08-04 20:15:04 --> Utf8 Class Initialized
DEBUG - 2011-08-04 20:15:04 --> UTF-8 Support Enabled
DEBUG - 2011-08-04 20:15:04 --> URI Class Initialized
DEBUG - 2011-08-04 20:15:04 --> Router Class Initialized
DEBUG - 2011-08-04 20:15:04 --> Output Class Initialized
DEBUG - 2011-08-04 20:15:04 --> Input Class Initialized
DEBUG - 2011-08-04 20:15:04 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-04 20:15:04 --> Language Class Initialized
DEBUG - 2011-08-04 20:15:04 --> Loader Class Initialized
DEBUG - 2011-08-04 20:15:04 --> Controller Class Initialized
DEBUG - 2011-08-04 20:15:04 --> Model Class Initialized
DEBUG - 2011-08-04 20:15:04 --> Model Class Initialized
DEBUG - 2011-08-04 20:15:04 --> Model Class Initialized
DEBUG - 2011-08-04 20:15:04 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-04 20:15:04 --> Database Driver Class Initialized
DEBUG - 2011-08-04 20:15:04 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-04 20:15:04 --> Helper loaded: url_helper
DEBUG - 2011-08-04 20:15:04 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-04 20:15:04 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-04 20:15:04 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-04 20:15:04 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-04 20:15:04 --> Final output sent to browser
DEBUG - 2011-08-04 20:15:04 --> Total execution time: 0.0692
DEBUG - 2011-08-04 20:15:04 --> Config Class Initialized
DEBUG - 2011-08-04 20:15:04 --> Hooks Class Initialized
DEBUG - 2011-08-04 20:15:04 --> Utf8 Class Initialized
DEBUG - 2011-08-04 20:15:04 --> UTF-8 Support Enabled
DEBUG - 2011-08-04 20:15:04 --> URI Class Initialized
DEBUG - 2011-08-04 20:15:04 --> Router Class Initialized
ERROR - 2011-08-04 20:15:04 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-04 20:15:07 --> Config Class Initialized
DEBUG - 2011-08-04 20:15:07 --> Hooks Class Initialized
DEBUG - 2011-08-04 20:15:07 --> Utf8 Class Initialized
DEBUG - 2011-08-04 20:15:07 --> UTF-8 Support Enabled
DEBUG - 2011-08-04 20:15:07 --> URI Class Initialized
DEBUG - 2011-08-04 20:15:07 --> Router Class Initialized
DEBUG - 2011-08-04 20:15:07 --> Output Class Initialized
DEBUG - 2011-08-04 20:15:07 --> Input Class Initialized
DEBUG - 2011-08-04 20:15:07 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-04 20:15:07 --> Language Class Initialized
DEBUG - 2011-08-04 20:15:07 --> Loader Class Initialized
DEBUG - 2011-08-04 20:15:07 --> Controller Class Initialized
DEBUG - 2011-08-04 20:15:07 --> Model Class Initialized
DEBUG - 2011-08-04 20:15:07 --> Model Class Initialized
DEBUG - 2011-08-04 20:15:07 --> Model Class Initialized
DEBUG - 2011-08-04 20:15:07 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-04 20:15:07 --> Database Driver Class Initialized
DEBUG - 2011-08-04 20:15:07 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-04 20:15:07 --> Helper loaded: url_helper
DEBUG - 2011-08-04 20:15:07 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-04 20:15:07 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-04 20:15:07 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-04 20:15:07 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-04 20:15:07 --> Final output sent to browser
DEBUG - 2011-08-04 20:15:07 --> Total execution time: 0.7677
DEBUG - 2011-08-04 20:15:08 --> Config Class Initialized
DEBUG - 2011-08-04 20:15:08 --> Hooks Class Initialized
DEBUG - 2011-08-04 20:15:08 --> Utf8 Class Initialized
DEBUG - 2011-08-04 20:15:08 --> UTF-8 Support Enabled
DEBUG - 2011-08-04 20:15:08 --> URI Class Initialized
DEBUG - 2011-08-04 20:15:08 --> Router Class Initialized
DEBUG - 2011-08-04 20:15:08 --> Output Class Initialized
DEBUG - 2011-08-04 20:15:08 --> Input Class Initialized
DEBUG - 2011-08-04 20:15:08 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-04 20:15:08 --> Language Class Initialized
DEBUG - 2011-08-04 20:15:08 --> Loader Class Initialized
DEBUG - 2011-08-04 20:15:08 --> Controller Class Initialized
DEBUG - 2011-08-04 20:15:08 --> Model Class Initialized
DEBUG - 2011-08-04 20:15:08 --> Model Class Initialized
DEBUG - 2011-08-04 20:15:08 --> Model Class Initialized
DEBUG - 2011-08-04 20:15:08 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-04 20:15:08 --> Database Driver Class Initialized
DEBUG - 2011-08-04 20:15:08 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-04 20:15:08 --> Helper loaded: url_helper
DEBUG - 2011-08-04 20:15:08 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-04 20:15:08 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-04 20:15:08 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-04 20:15:08 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-04 20:15:08 --> Final output sent to browser
DEBUG - 2011-08-04 20:15:08 --> Total execution time: 0.0498
DEBUG - 2011-08-04 20:15:09 --> Config Class Initialized
DEBUG - 2011-08-04 20:15:09 --> Hooks Class Initialized
DEBUG - 2011-08-04 20:15:09 --> Utf8 Class Initialized
DEBUG - 2011-08-04 20:15:09 --> UTF-8 Support Enabled
DEBUG - 2011-08-04 20:15:09 --> URI Class Initialized
DEBUG - 2011-08-04 20:15:09 --> Router Class Initialized
ERROR - 2011-08-04 20:15:09 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-04 20:15:11 --> Config Class Initialized
DEBUG - 2011-08-04 20:15:11 --> Hooks Class Initialized
DEBUG - 2011-08-04 20:15:11 --> Utf8 Class Initialized
DEBUG - 2011-08-04 20:15:11 --> UTF-8 Support Enabled
DEBUG - 2011-08-04 20:15:11 --> URI Class Initialized
DEBUG - 2011-08-04 20:15:11 --> Router Class Initialized
DEBUG - 2011-08-04 20:15:11 --> Output Class Initialized
DEBUG - 2011-08-04 20:15:11 --> Input Class Initialized
DEBUG - 2011-08-04 20:15:11 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-04 20:15:11 --> Language Class Initialized
DEBUG - 2011-08-04 20:15:11 --> Loader Class Initialized
DEBUG - 2011-08-04 20:15:11 --> Controller Class Initialized
DEBUG - 2011-08-04 20:15:11 --> Model Class Initialized
DEBUG - 2011-08-04 20:15:11 --> Model Class Initialized
DEBUG - 2011-08-04 20:15:11 --> Model Class Initialized
DEBUG - 2011-08-04 20:15:11 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-04 20:15:11 --> Database Driver Class Initialized
DEBUG - 2011-08-04 20:15:11 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-04 20:15:11 --> Helper loaded: url_helper
DEBUG - 2011-08-04 20:15:11 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-04 20:15:11 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-04 20:15:11 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-04 20:15:11 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-04 20:15:11 --> Final output sent to browser
DEBUG - 2011-08-04 20:15:11 --> Total execution time: 0.1983
DEBUG - 2011-08-04 20:15:12 --> Config Class Initialized
DEBUG - 2011-08-04 20:15:12 --> Hooks Class Initialized
DEBUG - 2011-08-04 20:15:12 --> Utf8 Class Initialized
DEBUG - 2011-08-04 20:15:12 --> UTF-8 Support Enabled
DEBUG - 2011-08-04 20:15:12 --> URI Class Initialized
DEBUG - 2011-08-04 20:15:12 --> Router Class Initialized
DEBUG - 2011-08-04 20:15:12 --> Output Class Initialized
DEBUG - 2011-08-04 20:15:12 --> Input Class Initialized
DEBUG - 2011-08-04 20:15:12 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-04 20:15:12 --> Language Class Initialized
DEBUG - 2011-08-04 20:15:12 --> Loader Class Initialized
DEBUG - 2011-08-04 20:15:12 --> Controller Class Initialized
DEBUG - 2011-08-04 20:15:12 --> Model Class Initialized
DEBUG - 2011-08-04 20:15:12 --> Model Class Initialized
DEBUG - 2011-08-04 20:15:12 --> Model Class Initialized
DEBUG - 2011-08-04 20:15:12 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-04 20:15:12 --> Database Driver Class Initialized
DEBUG - 2011-08-04 20:15:12 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-04 20:15:12 --> Helper loaded: url_helper
DEBUG - 2011-08-04 20:15:12 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-04 20:15:12 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-04 20:15:12 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-04 20:15:12 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-04 20:15:12 --> Final output sent to browser
DEBUG - 2011-08-04 20:15:12 --> Total execution time: 0.0458
DEBUG - 2011-08-04 20:15:12 --> Config Class Initialized
DEBUG - 2011-08-04 20:15:12 --> Hooks Class Initialized
DEBUG - 2011-08-04 20:15:12 --> Utf8 Class Initialized
DEBUG - 2011-08-04 20:15:12 --> UTF-8 Support Enabled
DEBUG - 2011-08-04 20:15:12 --> URI Class Initialized
DEBUG - 2011-08-04 20:15:12 --> Router Class Initialized
ERROR - 2011-08-04 20:15:12 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-04 23:11:18 --> Config Class Initialized
DEBUG - 2011-08-04 23:11:18 --> Hooks Class Initialized
DEBUG - 2011-08-04 23:11:18 --> Utf8 Class Initialized
DEBUG - 2011-08-04 23:11:18 --> UTF-8 Support Enabled
DEBUG - 2011-08-04 23:11:18 --> URI Class Initialized
DEBUG - 2011-08-04 23:11:19 --> Router Class Initialized
ERROR - 2011-08-04 23:11:19 --> 404 Page Not Found --> robots.txt

<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2011-07-05 00:11:05 --> Config Class Initialized
DEBUG - 2011-07-05 00:11:05 --> Hooks Class Initialized
DEBUG - 2011-07-05 00:11:05 --> Utf8 Class Initialized
DEBUG - 2011-07-05 00:11:05 --> UTF-8 Support Enabled
DEBUG - 2011-07-05 00:11:05 --> URI Class Initialized
DEBUG - 2011-07-05 00:11:05 --> Router Class Initialized
DEBUG - 2011-07-05 00:11:05 --> Output Class Initialized
DEBUG - 2011-07-05 00:11:05 --> Input Class Initialized
DEBUG - 2011-07-05 00:11:05 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-05 00:11:05 --> Language Class Initialized
DEBUG - 2011-07-05 00:11:05 --> Loader Class Initialized
DEBUG - 2011-07-05 00:11:05 --> Controller Class Initialized
DEBUG - 2011-07-05 00:11:05 --> Model Class Initialized
DEBUG - 2011-07-05 00:11:05 --> Model Class Initialized
DEBUG - 2011-07-05 00:11:05 --> Model Class Initialized
DEBUG - 2011-07-05 00:11:05 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-05 00:11:05 --> Database Driver Class Initialized
DEBUG - 2011-07-05 00:11:05 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-05 00:11:05 --> Helper loaded: url_helper
DEBUG - 2011-07-05 00:11:05 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-05 00:11:05 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-05 00:11:05 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-05 00:11:05 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-05 00:11:05 --> Final output sent to browser
DEBUG - 2011-07-05 00:11:05 --> Total execution time: 0.2844
DEBUG - 2011-07-05 00:11:14 --> Config Class Initialized
DEBUG - 2011-07-05 00:11:14 --> Hooks Class Initialized
DEBUG - 2011-07-05 00:11:14 --> Utf8 Class Initialized
DEBUG - 2011-07-05 00:11:14 --> UTF-8 Support Enabled
DEBUG - 2011-07-05 00:11:14 --> URI Class Initialized
DEBUG - 2011-07-05 00:11:14 --> Router Class Initialized
ERROR - 2011-07-05 00:11:14 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-05 00:11:15 --> Config Class Initialized
DEBUG - 2011-07-05 00:11:15 --> Hooks Class Initialized
DEBUG - 2011-07-05 00:11:15 --> Utf8 Class Initialized
DEBUG - 2011-07-05 00:11:15 --> UTF-8 Support Enabled
DEBUG - 2011-07-05 00:11:15 --> URI Class Initialized
DEBUG - 2011-07-05 00:11:15 --> Router Class Initialized
ERROR - 2011-07-05 00:11:15 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-05 00:11:16 --> Config Class Initialized
DEBUG - 2011-07-05 00:11:16 --> Hooks Class Initialized
DEBUG - 2011-07-05 00:11:16 --> Utf8 Class Initialized
DEBUG - 2011-07-05 00:11:16 --> UTF-8 Support Enabled
DEBUG - 2011-07-05 00:11:16 --> URI Class Initialized
DEBUG - 2011-07-05 00:11:16 --> Router Class Initialized
ERROR - 2011-07-05 00:11:16 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-05 00:11:22 --> Config Class Initialized
DEBUG - 2011-07-05 00:11:22 --> Hooks Class Initialized
DEBUG - 2011-07-05 00:11:22 --> Utf8 Class Initialized
DEBUG - 2011-07-05 00:11:22 --> UTF-8 Support Enabled
DEBUG - 2011-07-05 00:11:22 --> URI Class Initialized
DEBUG - 2011-07-05 00:11:22 --> Router Class Initialized
DEBUG - 2011-07-05 00:11:22 --> Output Class Initialized
DEBUG - 2011-07-05 00:11:22 --> Input Class Initialized
DEBUG - 2011-07-05 00:11:22 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-05 00:11:22 --> Language Class Initialized
DEBUG - 2011-07-05 00:11:22 --> Loader Class Initialized
DEBUG - 2011-07-05 00:11:22 --> Controller Class Initialized
DEBUG - 2011-07-05 00:11:22 --> Model Class Initialized
DEBUG - 2011-07-05 00:11:22 --> Model Class Initialized
DEBUG - 2011-07-05 00:11:22 --> Model Class Initialized
DEBUG - 2011-07-05 00:11:22 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-05 00:11:22 --> Database Driver Class Initialized
DEBUG - 2011-07-05 00:11:22 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-05 00:11:22 --> Helper loaded: url_helper
DEBUG - 2011-07-05 00:11:22 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-05 00:11:22 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-05 00:11:22 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-05 00:11:22 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-05 00:11:22 --> Final output sent to browser
DEBUG - 2011-07-05 00:11:22 --> Total execution time: 0.0457
DEBUG - 2011-07-05 02:18:11 --> Config Class Initialized
DEBUG - 2011-07-05 02:18:11 --> Hooks Class Initialized
DEBUG - 2011-07-05 02:18:11 --> Utf8 Class Initialized
DEBUG - 2011-07-05 02:18:11 --> UTF-8 Support Enabled
DEBUG - 2011-07-05 02:18:11 --> URI Class Initialized
DEBUG - 2011-07-05 02:18:11 --> Router Class Initialized
DEBUG - 2011-07-05 02:18:11 --> Output Class Initialized
DEBUG - 2011-07-05 02:18:11 --> Input Class Initialized
DEBUG - 2011-07-05 02:18:11 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-05 02:18:11 --> Language Class Initialized
DEBUG - 2011-07-05 02:18:11 --> Loader Class Initialized
DEBUG - 2011-07-05 02:18:11 --> Controller Class Initialized
ERROR - 2011-07-05 02:18:11 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-05 02:18:11 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-05 02:18:11 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-05 02:18:11 --> Model Class Initialized
DEBUG - 2011-07-05 02:18:11 --> Model Class Initialized
DEBUG - 2011-07-05 02:18:11 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-05 02:18:11 --> Database Driver Class Initialized
DEBUG - 2011-07-05 02:18:12 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-05 02:18:12 --> Helper loaded: url_helper
DEBUG - 2011-07-05 02:18:12 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-05 02:18:12 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-05 02:18:12 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-05 02:18:12 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-05 02:18:12 --> Final output sent to browser
DEBUG - 2011-07-05 02:18:12 --> Total execution time: 1.7668
DEBUG - 2011-07-05 02:18:14 --> Config Class Initialized
DEBUG - 2011-07-05 02:18:14 --> Hooks Class Initialized
DEBUG - 2011-07-05 02:18:14 --> Utf8 Class Initialized
DEBUG - 2011-07-05 02:18:14 --> UTF-8 Support Enabled
DEBUG - 2011-07-05 02:18:14 --> URI Class Initialized
DEBUG - 2011-07-05 02:18:14 --> Router Class Initialized
DEBUG - 2011-07-05 02:18:14 --> Output Class Initialized
DEBUG - 2011-07-05 02:18:14 --> Input Class Initialized
DEBUG - 2011-07-05 02:18:14 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-05 02:18:14 --> Language Class Initialized
DEBUG - 2011-07-05 02:18:14 --> Loader Class Initialized
DEBUG - 2011-07-05 02:18:14 --> Controller Class Initialized
DEBUG - 2011-07-05 02:18:14 --> Model Class Initialized
DEBUG - 2011-07-05 02:18:14 --> Model Class Initialized
DEBUG - 2011-07-05 02:18:14 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-05 02:18:14 --> Database Driver Class Initialized
DEBUG - 2011-07-05 02:18:15 --> Final output sent to browser
DEBUG - 2011-07-05 02:18:15 --> Total execution time: 1.2621
DEBUG - 2011-07-05 02:18:16 --> Config Class Initialized
DEBUG - 2011-07-05 02:18:16 --> Hooks Class Initialized
DEBUG - 2011-07-05 02:18:16 --> Utf8 Class Initialized
DEBUG - 2011-07-05 02:18:16 --> UTF-8 Support Enabled
DEBUG - 2011-07-05 02:18:16 --> URI Class Initialized
DEBUG - 2011-07-05 02:18:16 --> Router Class Initialized
ERROR - 2011-07-05 02:18:16 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-05 02:19:17 --> Config Class Initialized
DEBUG - 2011-07-05 02:19:17 --> Hooks Class Initialized
DEBUG - 2011-07-05 02:19:17 --> Utf8 Class Initialized
DEBUG - 2011-07-05 02:19:17 --> UTF-8 Support Enabled
DEBUG - 2011-07-05 02:19:18 --> URI Class Initialized
DEBUG - 2011-07-05 02:19:18 --> Router Class Initialized
DEBUG - 2011-07-05 02:19:18 --> Output Class Initialized
DEBUG - 2011-07-05 02:19:18 --> Input Class Initialized
DEBUG - 2011-07-05 02:19:18 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-05 02:19:18 --> Language Class Initialized
DEBUG - 2011-07-05 02:19:18 --> Loader Class Initialized
DEBUG - 2011-07-05 02:19:18 --> Controller Class Initialized
DEBUG - 2011-07-05 02:19:18 --> Model Class Initialized
DEBUG - 2011-07-05 02:19:18 --> Model Class Initialized
DEBUG - 2011-07-05 02:19:18 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-05 02:19:18 --> Database Driver Class Initialized
DEBUG - 2011-07-05 02:19:18 --> Final output sent to browser
DEBUG - 2011-07-05 02:19:18 --> Total execution time: 0.6095
DEBUG - 2011-07-05 02:19:24 --> Config Class Initialized
DEBUG - 2011-07-05 02:19:24 --> Hooks Class Initialized
DEBUG - 2011-07-05 02:19:24 --> Utf8 Class Initialized
DEBUG - 2011-07-05 02:19:24 --> UTF-8 Support Enabled
DEBUG - 2011-07-05 02:19:24 --> URI Class Initialized
DEBUG - 2011-07-05 02:19:24 --> Router Class Initialized
DEBUG - 2011-07-05 02:19:24 --> Output Class Initialized
DEBUG - 2011-07-05 02:19:24 --> Input Class Initialized
DEBUG - 2011-07-05 02:19:24 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-05 02:19:24 --> Language Class Initialized
DEBUG - 2011-07-05 02:19:24 --> Loader Class Initialized
DEBUG - 2011-07-05 02:19:24 --> Controller Class Initialized
ERROR - 2011-07-05 02:19:24 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-05 02:19:24 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-05 02:19:24 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-05 02:19:24 --> Model Class Initialized
DEBUG - 2011-07-05 02:19:24 --> Model Class Initialized
DEBUG - 2011-07-05 02:19:24 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-05 02:19:24 --> Database Driver Class Initialized
DEBUG - 2011-07-05 02:19:24 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-05 02:19:24 --> Helper loaded: url_helper
DEBUG - 2011-07-05 02:19:24 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-05 02:19:24 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-05 02:19:24 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-05 02:19:24 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-05 02:19:24 --> Final output sent to browser
DEBUG - 2011-07-05 02:19:24 --> Total execution time: 0.0287
DEBUG - 2011-07-05 02:19:24 --> Config Class Initialized
DEBUG - 2011-07-05 02:19:24 --> Hooks Class Initialized
DEBUG - 2011-07-05 02:19:24 --> Utf8 Class Initialized
DEBUG - 2011-07-05 02:19:24 --> UTF-8 Support Enabled
DEBUG - 2011-07-05 02:19:24 --> URI Class Initialized
DEBUG - 2011-07-05 02:19:24 --> Router Class Initialized
DEBUG - 2011-07-05 02:19:24 --> Output Class Initialized
DEBUG - 2011-07-05 02:19:24 --> Input Class Initialized
DEBUG - 2011-07-05 02:19:24 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-05 02:19:24 --> Language Class Initialized
DEBUG - 2011-07-05 02:19:24 --> Loader Class Initialized
DEBUG - 2011-07-05 02:19:24 --> Controller Class Initialized
DEBUG - 2011-07-05 02:19:24 --> Model Class Initialized
DEBUG - 2011-07-05 02:19:24 --> Model Class Initialized
DEBUG - 2011-07-05 02:19:24 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-05 02:19:24 --> Database Driver Class Initialized
DEBUG - 2011-07-05 02:19:25 --> Final output sent to browser
DEBUG - 2011-07-05 02:19:25 --> Total execution time: 0.5673
DEBUG - 2011-07-05 02:19:38 --> Config Class Initialized
DEBUG - 2011-07-05 02:19:38 --> Hooks Class Initialized
DEBUG - 2011-07-05 02:19:38 --> Utf8 Class Initialized
DEBUG - 2011-07-05 02:19:38 --> UTF-8 Support Enabled
DEBUG - 2011-07-05 02:19:38 --> URI Class Initialized
DEBUG - 2011-07-05 02:19:38 --> Router Class Initialized
DEBUG - 2011-07-05 02:19:38 --> Output Class Initialized
DEBUG - 2011-07-05 02:19:38 --> Input Class Initialized
DEBUG - 2011-07-05 02:19:38 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-05 02:19:38 --> Language Class Initialized
DEBUG - 2011-07-05 02:19:38 --> Loader Class Initialized
DEBUG - 2011-07-05 02:19:38 --> Controller Class Initialized
ERROR - 2011-07-05 02:19:38 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-05 02:19:38 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-05 02:19:38 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-05 02:19:38 --> Model Class Initialized
DEBUG - 2011-07-05 02:19:38 --> Model Class Initialized
DEBUG - 2011-07-05 02:19:38 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-05 02:19:38 --> Database Driver Class Initialized
DEBUG - 2011-07-05 02:19:38 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-05 02:19:38 --> Helper loaded: url_helper
DEBUG - 2011-07-05 02:19:38 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-05 02:19:38 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-05 02:19:38 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-05 02:19:38 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-05 02:19:38 --> Final output sent to browser
DEBUG - 2011-07-05 02:19:38 --> Total execution time: 0.0311
DEBUG - 2011-07-05 02:19:39 --> Config Class Initialized
DEBUG - 2011-07-05 02:19:39 --> Hooks Class Initialized
DEBUG - 2011-07-05 02:19:39 --> Utf8 Class Initialized
DEBUG - 2011-07-05 02:19:39 --> UTF-8 Support Enabled
DEBUG - 2011-07-05 02:19:39 --> URI Class Initialized
DEBUG - 2011-07-05 02:19:39 --> Router Class Initialized
DEBUG - 2011-07-05 02:19:39 --> Output Class Initialized
DEBUG - 2011-07-05 02:19:39 --> Input Class Initialized
DEBUG - 2011-07-05 02:19:39 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-05 02:19:39 --> Language Class Initialized
DEBUG - 2011-07-05 02:19:39 --> Loader Class Initialized
DEBUG - 2011-07-05 02:19:39 --> Controller Class Initialized
DEBUG - 2011-07-05 02:19:39 --> Model Class Initialized
DEBUG - 2011-07-05 02:19:39 --> Model Class Initialized
DEBUG - 2011-07-05 02:19:39 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-05 02:19:39 --> Database Driver Class Initialized
DEBUG - 2011-07-05 02:19:39 --> Final output sent to browser
DEBUG - 2011-07-05 02:19:39 --> Total execution time: 0.4829
DEBUG - 2011-07-05 02:19:54 --> Config Class Initialized
DEBUG - 2011-07-05 02:19:54 --> Hooks Class Initialized
DEBUG - 2011-07-05 02:19:54 --> Utf8 Class Initialized
DEBUG - 2011-07-05 02:19:54 --> UTF-8 Support Enabled
DEBUG - 2011-07-05 02:19:54 --> URI Class Initialized
DEBUG - 2011-07-05 02:19:54 --> Router Class Initialized
DEBUG - 2011-07-05 02:19:54 --> Output Class Initialized
DEBUG - 2011-07-05 02:19:54 --> Input Class Initialized
DEBUG - 2011-07-05 02:19:54 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-05 02:19:54 --> Language Class Initialized
DEBUG - 2011-07-05 02:19:54 --> Loader Class Initialized
DEBUG - 2011-07-05 02:19:54 --> Controller Class Initialized
ERROR - 2011-07-05 02:19:54 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-05 02:19:54 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-05 02:19:54 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-05 02:19:54 --> Model Class Initialized
DEBUG - 2011-07-05 02:19:54 --> Model Class Initialized
DEBUG - 2011-07-05 02:19:54 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-05 02:19:54 --> Database Driver Class Initialized
DEBUG - 2011-07-05 02:19:54 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-05 02:19:54 --> Helper loaded: url_helper
DEBUG - 2011-07-05 02:19:54 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-05 02:19:54 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-05 02:19:54 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-05 02:19:54 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-05 02:19:54 --> Final output sent to browser
DEBUG - 2011-07-05 02:19:54 --> Total execution time: 0.0306
DEBUG - 2011-07-05 02:20:10 --> Config Class Initialized
DEBUG - 2011-07-05 02:20:10 --> Hooks Class Initialized
DEBUG - 2011-07-05 02:20:10 --> Utf8 Class Initialized
DEBUG - 2011-07-05 02:20:10 --> UTF-8 Support Enabled
DEBUG - 2011-07-05 02:20:10 --> URI Class Initialized
DEBUG - 2011-07-05 02:20:10 --> Router Class Initialized
DEBUG - 2011-07-05 02:20:10 --> Output Class Initialized
DEBUG - 2011-07-05 02:20:10 --> Input Class Initialized
DEBUG - 2011-07-05 02:20:10 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-05 02:20:10 --> Language Class Initialized
DEBUG - 2011-07-05 02:20:10 --> Loader Class Initialized
DEBUG - 2011-07-05 02:20:10 --> Controller Class Initialized
ERROR - 2011-07-05 02:20:10 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-05 02:20:10 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-05 02:20:10 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-05 02:20:10 --> Model Class Initialized
DEBUG - 2011-07-05 02:20:10 --> Model Class Initialized
DEBUG - 2011-07-05 02:20:10 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-05 02:20:10 --> Database Driver Class Initialized
DEBUG - 2011-07-05 02:20:10 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-05 02:20:10 --> Helper loaded: url_helper
DEBUG - 2011-07-05 02:20:10 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-05 02:20:10 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-05 02:20:10 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-05 02:20:10 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-05 02:20:10 --> Final output sent to browser
DEBUG - 2011-07-05 02:20:10 --> Total execution time: 0.0462
DEBUG - 2011-07-05 02:20:11 --> Config Class Initialized
DEBUG - 2011-07-05 02:20:11 --> Hooks Class Initialized
DEBUG - 2011-07-05 02:20:11 --> Utf8 Class Initialized
DEBUG - 2011-07-05 02:20:11 --> UTF-8 Support Enabled
DEBUG - 2011-07-05 02:20:11 --> URI Class Initialized
DEBUG - 2011-07-05 02:20:11 --> Router Class Initialized
DEBUG - 2011-07-05 02:20:11 --> Output Class Initialized
DEBUG - 2011-07-05 02:20:11 --> Input Class Initialized
DEBUG - 2011-07-05 02:20:11 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-05 02:20:11 --> Language Class Initialized
DEBUG - 2011-07-05 02:20:11 --> Loader Class Initialized
DEBUG - 2011-07-05 02:20:11 --> Controller Class Initialized
DEBUG - 2011-07-05 02:20:11 --> Model Class Initialized
DEBUG - 2011-07-05 02:20:11 --> Model Class Initialized
DEBUG - 2011-07-05 02:20:11 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-05 02:20:11 --> Database Driver Class Initialized
DEBUG - 2011-07-05 02:20:11 --> Final output sent to browser
DEBUG - 2011-07-05 02:20:11 --> Total execution time: 0.7053
DEBUG - 2011-07-05 02:20:13 --> Config Class Initialized
DEBUG - 2011-07-05 02:20:13 --> Hooks Class Initialized
DEBUG - 2011-07-05 02:20:13 --> Utf8 Class Initialized
DEBUG - 2011-07-05 02:20:13 --> UTF-8 Support Enabled
DEBUG - 2011-07-05 02:20:13 --> URI Class Initialized
DEBUG - 2011-07-05 02:20:13 --> Router Class Initialized
DEBUG - 2011-07-05 02:20:13 --> Output Class Initialized
DEBUG - 2011-07-05 02:20:13 --> Input Class Initialized
DEBUG - 2011-07-05 02:20:13 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-05 02:20:13 --> Language Class Initialized
DEBUG - 2011-07-05 02:20:13 --> Loader Class Initialized
DEBUG - 2011-07-05 02:20:13 --> Controller Class Initialized
ERROR - 2011-07-05 02:20:13 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-05 02:20:13 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-05 02:20:13 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-05 02:20:13 --> Model Class Initialized
DEBUG - 2011-07-05 02:20:13 --> Model Class Initialized
DEBUG - 2011-07-05 02:20:13 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-05 02:20:13 --> Database Driver Class Initialized
DEBUG - 2011-07-05 02:20:13 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-05 02:20:13 --> Helper loaded: url_helper
DEBUG - 2011-07-05 02:20:13 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-05 02:20:13 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-05 02:20:13 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-05 02:20:13 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-05 02:20:13 --> Final output sent to browser
DEBUG - 2011-07-05 02:20:13 --> Total execution time: 0.0459
DEBUG - 2011-07-05 02:20:27 --> Config Class Initialized
DEBUG - 2011-07-05 02:20:27 --> Hooks Class Initialized
DEBUG - 2011-07-05 02:20:27 --> Utf8 Class Initialized
DEBUG - 2011-07-05 02:20:27 --> UTF-8 Support Enabled
DEBUG - 2011-07-05 02:20:27 --> URI Class Initialized
DEBUG - 2011-07-05 02:20:27 --> Router Class Initialized
DEBUG - 2011-07-05 02:20:27 --> Output Class Initialized
DEBUG - 2011-07-05 02:20:27 --> Input Class Initialized
DEBUG - 2011-07-05 02:20:27 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-05 02:20:27 --> Language Class Initialized
DEBUG - 2011-07-05 02:20:27 --> Loader Class Initialized
DEBUG - 2011-07-05 02:20:27 --> Controller Class Initialized
ERROR - 2011-07-05 02:20:27 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-05 02:20:27 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-05 02:20:27 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-05 02:20:27 --> Model Class Initialized
DEBUG - 2011-07-05 02:20:27 --> Model Class Initialized
DEBUG - 2011-07-05 02:20:27 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-05 02:20:27 --> Database Driver Class Initialized
DEBUG - 2011-07-05 02:20:27 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-05 02:20:27 --> Helper loaded: url_helper
DEBUG - 2011-07-05 02:20:27 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-05 02:20:27 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-05 02:20:27 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-05 02:20:27 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-05 02:20:27 --> Final output sent to browser
DEBUG - 2011-07-05 02:20:27 --> Total execution time: 0.0282
DEBUG - 2011-07-05 02:20:28 --> Config Class Initialized
DEBUG - 2011-07-05 02:20:28 --> Hooks Class Initialized
DEBUG - 2011-07-05 02:20:28 --> Utf8 Class Initialized
DEBUG - 2011-07-05 02:20:28 --> UTF-8 Support Enabled
DEBUG - 2011-07-05 02:20:28 --> URI Class Initialized
DEBUG - 2011-07-05 02:20:28 --> Router Class Initialized
DEBUG - 2011-07-05 02:20:28 --> Output Class Initialized
DEBUG - 2011-07-05 02:20:28 --> Input Class Initialized
DEBUG - 2011-07-05 02:20:28 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-05 02:20:28 --> Language Class Initialized
DEBUG - 2011-07-05 02:20:28 --> Loader Class Initialized
DEBUG - 2011-07-05 02:20:28 --> Controller Class Initialized
DEBUG - 2011-07-05 02:20:28 --> Model Class Initialized
DEBUG - 2011-07-05 02:20:28 --> Model Class Initialized
DEBUG - 2011-07-05 02:20:28 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-05 02:20:28 --> Database Driver Class Initialized
DEBUG - 2011-07-05 02:20:28 --> Final output sent to browser
DEBUG - 2011-07-05 02:20:28 --> Total execution time: 0.4961
DEBUG - 2011-07-05 02:20:31 --> Config Class Initialized
DEBUG - 2011-07-05 02:20:31 --> Hooks Class Initialized
DEBUG - 2011-07-05 02:20:31 --> Utf8 Class Initialized
DEBUG - 2011-07-05 02:20:31 --> UTF-8 Support Enabled
DEBUG - 2011-07-05 02:20:31 --> URI Class Initialized
DEBUG - 2011-07-05 02:20:31 --> Router Class Initialized
DEBUG - 2011-07-05 02:20:31 --> Output Class Initialized
DEBUG - 2011-07-05 02:20:31 --> Input Class Initialized
DEBUG - 2011-07-05 02:20:31 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-05 02:20:31 --> Language Class Initialized
DEBUG - 2011-07-05 02:20:31 --> Loader Class Initialized
DEBUG - 2011-07-05 02:20:31 --> Controller Class Initialized
ERROR - 2011-07-05 02:20:31 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-05 02:20:31 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-05 02:20:31 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-05 02:20:31 --> Model Class Initialized
DEBUG - 2011-07-05 02:20:31 --> Model Class Initialized
DEBUG - 2011-07-05 02:20:31 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-05 02:20:31 --> Database Driver Class Initialized
DEBUG - 2011-07-05 02:20:31 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-05 02:20:31 --> Helper loaded: url_helper
DEBUG - 2011-07-05 02:20:31 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-05 02:20:31 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-05 02:20:31 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-05 02:20:31 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-05 02:20:31 --> Final output sent to browser
DEBUG - 2011-07-05 02:20:31 --> Total execution time: 0.0896
DEBUG - 2011-07-05 02:20:35 --> Config Class Initialized
DEBUG - 2011-07-05 02:20:35 --> Hooks Class Initialized
DEBUG - 2011-07-05 02:20:35 --> Utf8 Class Initialized
DEBUG - 2011-07-05 02:20:35 --> UTF-8 Support Enabled
DEBUG - 2011-07-05 02:20:35 --> URI Class Initialized
DEBUG - 2011-07-05 02:20:35 --> Router Class Initialized
DEBUG - 2011-07-05 02:20:35 --> Output Class Initialized
DEBUG - 2011-07-05 02:20:35 --> Input Class Initialized
DEBUG - 2011-07-05 02:20:35 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-05 02:20:35 --> Language Class Initialized
DEBUG - 2011-07-05 02:20:35 --> Loader Class Initialized
DEBUG - 2011-07-05 02:20:35 --> Controller Class Initialized
ERROR - 2011-07-05 02:20:35 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-05 02:20:35 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-05 02:20:35 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-05 02:20:35 --> Model Class Initialized
DEBUG - 2011-07-05 02:20:35 --> Model Class Initialized
DEBUG - 2011-07-05 02:20:35 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-05 02:20:35 --> Database Driver Class Initialized
DEBUG - 2011-07-05 02:20:35 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-05 02:20:35 --> Helper loaded: url_helper
DEBUG - 2011-07-05 02:20:35 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-05 02:20:35 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-05 02:20:35 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-05 02:20:35 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-05 02:20:35 --> Final output sent to browser
DEBUG - 2011-07-05 02:20:35 --> Total execution time: 0.0348
DEBUG - 2011-07-05 02:20:35 --> Config Class Initialized
DEBUG - 2011-07-05 02:20:35 --> Hooks Class Initialized
DEBUG - 2011-07-05 02:20:35 --> Utf8 Class Initialized
DEBUG - 2011-07-05 02:20:35 --> UTF-8 Support Enabled
DEBUG - 2011-07-05 02:20:35 --> URI Class Initialized
DEBUG - 2011-07-05 02:20:35 --> Router Class Initialized
DEBUG - 2011-07-05 02:20:35 --> Output Class Initialized
DEBUG - 2011-07-05 02:20:35 --> Input Class Initialized
DEBUG - 2011-07-05 02:20:35 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-05 02:20:35 --> Language Class Initialized
DEBUG - 2011-07-05 02:20:35 --> Loader Class Initialized
DEBUG - 2011-07-05 02:20:35 --> Controller Class Initialized
DEBUG - 2011-07-05 02:20:35 --> Model Class Initialized
DEBUG - 2011-07-05 02:20:35 --> Model Class Initialized
DEBUG - 2011-07-05 02:20:35 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-05 02:20:35 --> Database Driver Class Initialized
DEBUG - 2011-07-05 02:20:35 --> Config Class Initialized
DEBUG - 2011-07-05 02:20:35 --> Hooks Class Initialized
DEBUG - 2011-07-05 02:20:35 --> Utf8 Class Initialized
DEBUG - 2011-07-05 02:20:35 --> UTF-8 Support Enabled
DEBUG - 2011-07-05 02:20:35 --> URI Class Initialized
DEBUG - 2011-07-05 02:20:35 --> Router Class Initialized
DEBUG - 2011-07-05 02:20:35 --> Output Class Initialized
DEBUG - 2011-07-05 02:20:35 --> Input Class Initialized
DEBUG - 2011-07-05 02:20:35 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-05 02:20:35 --> Language Class Initialized
DEBUG - 2011-07-05 02:20:35 --> Loader Class Initialized
DEBUG - 2011-07-05 02:20:35 --> Controller Class Initialized
ERROR - 2011-07-05 02:20:35 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-05 02:20:35 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-05 02:20:35 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-05 02:20:35 --> Model Class Initialized
DEBUG - 2011-07-05 02:20:35 --> Model Class Initialized
DEBUG - 2011-07-05 02:20:35 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-05 02:20:35 --> Database Driver Class Initialized
DEBUG - 2011-07-05 02:20:35 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-05 02:20:35 --> Helper loaded: url_helper
DEBUG - 2011-07-05 02:20:35 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-05 02:20:35 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-05 02:20:35 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-05 02:20:35 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-05 02:20:35 --> Final output sent to browser
DEBUG - 2011-07-05 02:20:35 --> Total execution time: 0.0307
DEBUG - 2011-07-05 02:20:36 --> Final output sent to browser
DEBUG - 2011-07-05 02:20:36 --> Total execution time: 0.9266
DEBUG - 2011-07-05 02:20:41 --> Config Class Initialized
DEBUG - 2011-07-05 02:20:41 --> Hooks Class Initialized
DEBUG - 2011-07-05 02:20:41 --> Utf8 Class Initialized
DEBUG - 2011-07-05 02:20:41 --> UTF-8 Support Enabled
DEBUG - 2011-07-05 02:20:41 --> URI Class Initialized
DEBUG - 2011-07-05 02:20:41 --> Router Class Initialized
DEBUG - 2011-07-05 02:20:41 --> Output Class Initialized
DEBUG - 2011-07-05 02:20:41 --> Input Class Initialized
DEBUG - 2011-07-05 02:20:41 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-05 02:20:41 --> Language Class Initialized
DEBUG - 2011-07-05 02:20:41 --> Loader Class Initialized
DEBUG - 2011-07-05 02:20:41 --> Controller Class Initialized
ERROR - 2011-07-05 02:20:41 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-05 02:20:41 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-05 02:20:41 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-05 02:20:41 --> Model Class Initialized
DEBUG - 2011-07-05 02:20:41 --> Model Class Initialized
DEBUG - 2011-07-05 02:20:41 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-05 02:20:41 --> Database Driver Class Initialized
DEBUG - 2011-07-05 02:20:41 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-05 02:20:41 --> Helper loaded: url_helper
DEBUG - 2011-07-05 02:20:41 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-05 02:20:41 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-05 02:20:41 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-05 02:20:41 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-05 02:20:41 --> Final output sent to browser
DEBUG - 2011-07-05 02:20:41 --> Total execution time: 0.0310
DEBUG - 2011-07-05 02:20:42 --> Config Class Initialized
DEBUG - 2011-07-05 02:20:42 --> Hooks Class Initialized
DEBUG - 2011-07-05 02:20:42 --> Utf8 Class Initialized
DEBUG - 2011-07-05 02:20:42 --> UTF-8 Support Enabled
DEBUG - 2011-07-05 02:20:42 --> URI Class Initialized
DEBUG - 2011-07-05 02:20:42 --> Router Class Initialized
DEBUG - 2011-07-05 02:20:42 --> Output Class Initialized
DEBUG - 2011-07-05 02:20:42 --> Input Class Initialized
DEBUG - 2011-07-05 02:20:42 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-05 02:20:42 --> Language Class Initialized
DEBUG - 2011-07-05 02:20:42 --> Loader Class Initialized
DEBUG - 2011-07-05 02:20:42 --> Controller Class Initialized
DEBUG - 2011-07-05 02:20:42 --> Model Class Initialized
DEBUG - 2011-07-05 02:20:42 --> Model Class Initialized
DEBUG - 2011-07-05 02:20:42 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-05 02:20:42 --> Database Driver Class Initialized
DEBUG - 2011-07-05 02:20:44 --> Config Class Initialized
DEBUG - 2011-07-05 02:20:44 --> Hooks Class Initialized
DEBUG - 2011-07-05 02:20:44 --> Utf8 Class Initialized
DEBUG - 2011-07-05 02:20:44 --> UTF-8 Support Enabled
DEBUG - 2011-07-05 02:20:44 --> URI Class Initialized
DEBUG - 2011-07-05 02:20:44 --> Router Class Initialized
DEBUG - 2011-07-05 02:20:44 --> Output Class Initialized
DEBUG - 2011-07-05 02:20:44 --> Input Class Initialized
DEBUG - 2011-07-05 02:20:44 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-05 02:20:44 --> Language Class Initialized
DEBUG - 2011-07-05 02:20:44 --> Loader Class Initialized
DEBUG - 2011-07-05 02:20:44 --> Controller Class Initialized
ERROR - 2011-07-05 02:20:44 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-05 02:20:44 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-05 02:20:44 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-05 02:20:44 --> Model Class Initialized
DEBUG - 2011-07-05 02:20:44 --> Model Class Initialized
DEBUG - 2011-07-05 02:20:44 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-05 02:20:44 --> Database Driver Class Initialized
DEBUG - 2011-07-05 02:20:44 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-05 02:20:44 --> Helper loaded: url_helper
DEBUG - 2011-07-05 02:20:44 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-05 02:20:44 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-05 02:20:44 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-05 02:20:44 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-05 02:20:44 --> Final output sent to browser
DEBUG - 2011-07-05 02:20:44 --> Total execution time: 0.0369
DEBUG - 2011-07-05 02:20:49 --> Config Class Initialized
DEBUG - 2011-07-05 02:20:49 --> Hooks Class Initialized
DEBUG - 2011-07-05 02:20:49 --> Utf8 Class Initialized
DEBUG - 2011-07-05 02:20:49 --> UTF-8 Support Enabled
DEBUG - 2011-07-05 02:20:49 --> URI Class Initialized
DEBUG - 2011-07-05 02:20:49 --> Router Class Initialized
DEBUG - 2011-07-05 02:20:49 --> Output Class Initialized
DEBUG - 2011-07-05 02:20:49 --> Input Class Initialized
DEBUG - 2011-07-05 02:20:49 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-05 02:20:49 --> Language Class Initialized
DEBUG - 2011-07-05 02:20:49 --> Loader Class Initialized
DEBUG - 2011-07-05 02:20:49 --> Controller Class Initialized
ERROR - 2011-07-05 02:20:49 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-05 02:20:49 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-05 02:20:49 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-05 02:20:49 --> Model Class Initialized
DEBUG - 2011-07-05 02:20:49 --> Model Class Initialized
DEBUG - 2011-07-05 02:20:49 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-05 02:20:49 --> Database Driver Class Initialized
DEBUG - 2011-07-05 02:20:49 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-05 02:20:49 --> Helper loaded: url_helper
DEBUG - 2011-07-05 02:20:49 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-05 02:20:49 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-05 02:20:49 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-05 02:20:49 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-05 02:20:49 --> Final output sent to browser
DEBUG - 2011-07-05 02:20:49 --> Total execution time: 0.0386
DEBUG - 2011-07-05 02:20:49 --> Config Class Initialized
DEBUG - 2011-07-05 02:20:49 --> Hooks Class Initialized
DEBUG - 2011-07-05 02:20:49 --> Utf8 Class Initialized
DEBUG - 2011-07-05 02:20:49 --> UTF-8 Support Enabled
DEBUG - 2011-07-05 02:20:49 --> URI Class Initialized
DEBUG - 2011-07-05 02:20:49 --> Router Class Initialized
DEBUG - 2011-07-05 02:20:49 --> Output Class Initialized
DEBUG - 2011-07-05 02:20:49 --> Input Class Initialized
DEBUG - 2011-07-05 02:20:49 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-05 02:20:49 --> Language Class Initialized
DEBUG - 2011-07-05 02:20:49 --> Loader Class Initialized
DEBUG - 2011-07-05 02:20:49 --> Controller Class Initialized
DEBUG - 2011-07-05 02:20:49 --> Model Class Initialized
DEBUG - 2011-07-05 02:20:49 --> Model Class Initialized
DEBUG - 2011-07-05 02:20:49 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-05 02:20:49 --> Database Driver Class Initialized
DEBUG - 2011-07-05 02:20:54 --> Config Class Initialized
DEBUG - 2011-07-05 02:20:54 --> Hooks Class Initialized
DEBUG - 2011-07-05 02:20:54 --> Utf8 Class Initialized
DEBUG - 2011-07-05 02:20:54 --> UTF-8 Support Enabled
DEBUG - 2011-07-05 02:20:54 --> URI Class Initialized
DEBUG - 2011-07-05 02:20:54 --> Router Class Initialized
DEBUG - 2011-07-05 02:20:54 --> Output Class Initialized
DEBUG - 2011-07-05 02:20:54 --> Input Class Initialized
DEBUG - 2011-07-05 02:20:54 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-05 02:20:54 --> Language Class Initialized
DEBUG - 2011-07-05 02:20:54 --> Loader Class Initialized
DEBUG - 2011-07-05 02:20:54 --> Controller Class Initialized
ERROR - 2011-07-05 02:20:54 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-05 02:20:54 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-05 02:20:54 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-05 02:20:54 --> Model Class Initialized
DEBUG - 2011-07-05 02:20:54 --> Model Class Initialized
DEBUG - 2011-07-05 02:20:54 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-05 02:20:54 --> Database Driver Class Initialized
DEBUG - 2011-07-05 02:20:54 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-05 02:20:54 --> Helper loaded: url_helper
DEBUG - 2011-07-05 02:20:54 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-05 02:20:54 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-05 02:20:54 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-05 02:20:54 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-05 02:20:54 --> Final output sent to browser
DEBUG - 2011-07-05 02:20:54 --> Total execution time: 0.0322
DEBUG - 2011-07-05 02:20:54 --> Final output sent to browser
DEBUG - 2011-07-05 02:20:54 --> Total execution time: 5.0066
DEBUG - 2011-07-05 02:20:55 --> Config Class Initialized
DEBUG - 2011-07-05 02:20:55 --> Hooks Class Initialized
DEBUG - 2011-07-05 02:20:55 --> Utf8 Class Initialized
DEBUG - 2011-07-05 02:20:55 --> UTF-8 Support Enabled
DEBUG - 2011-07-05 02:20:55 --> URI Class Initialized
DEBUG - 2011-07-05 02:20:55 --> Router Class Initialized
DEBUG - 2011-07-05 02:20:55 --> Output Class Initialized
DEBUG - 2011-07-05 02:20:55 --> Input Class Initialized
DEBUG - 2011-07-05 02:20:55 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-05 02:20:55 --> Language Class Initialized
DEBUG - 2011-07-05 02:20:55 --> Loader Class Initialized
DEBUG - 2011-07-05 02:20:55 --> Controller Class Initialized
ERROR - 2011-07-05 02:20:55 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-05 02:20:55 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-05 02:20:55 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-05 02:20:55 --> Model Class Initialized
DEBUG - 2011-07-05 02:20:55 --> Model Class Initialized
DEBUG - 2011-07-05 02:20:55 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-05 02:20:55 --> Database Driver Class Initialized
DEBUG - 2011-07-05 02:20:55 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-05 02:20:55 --> Helper loaded: url_helper
DEBUG - 2011-07-05 02:20:55 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-05 02:20:55 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-05 02:20:55 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-05 02:20:55 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-05 02:20:55 --> Final output sent to browser
DEBUG - 2011-07-05 02:20:55 --> Total execution time: 0.0286
DEBUG - 2011-07-05 02:20:55 --> Config Class Initialized
DEBUG - 2011-07-05 02:20:55 --> Hooks Class Initialized
DEBUG - 2011-07-05 02:20:55 --> Utf8 Class Initialized
DEBUG - 2011-07-05 02:20:55 --> UTF-8 Support Enabled
DEBUG - 2011-07-05 02:20:55 --> URI Class Initialized
DEBUG - 2011-07-05 02:20:55 --> Router Class Initialized
DEBUG - 2011-07-05 02:20:55 --> Output Class Initialized
DEBUG - 2011-07-05 02:20:55 --> Input Class Initialized
DEBUG - 2011-07-05 02:20:55 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-05 02:20:55 --> Language Class Initialized
DEBUG - 2011-07-05 02:20:55 --> Loader Class Initialized
DEBUG - 2011-07-05 02:20:55 --> Controller Class Initialized
DEBUG - 2011-07-05 02:20:55 --> Model Class Initialized
DEBUG - 2011-07-05 02:20:55 --> Model Class Initialized
DEBUG - 2011-07-05 02:20:55 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-05 02:20:55 --> Database Driver Class Initialized
DEBUG - 2011-07-05 02:20:59 --> Final output sent to browser
DEBUG - 2011-07-05 02:20:59 --> Total execution time: 4.1389
DEBUG - 2011-07-05 02:21:10 --> Config Class Initialized
DEBUG - 2011-07-05 02:21:10 --> Hooks Class Initialized
DEBUG - 2011-07-05 02:21:10 --> Utf8 Class Initialized
DEBUG - 2011-07-05 02:21:10 --> UTF-8 Support Enabled
DEBUG - 2011-07-05 02:21:10 --> URI Class Initialized
DEBUG - 2011-07-05 02:21:10 --> Router Class Initialized
DEBUG - 2011-07-05 02:21:10 --> Output Class Initialized
DEBUG - 2011-07-05 02:21:10 --> Input Class Initialized
DEBUG - 2011-07-05 02:21:10 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-05 02:21:10 --> Language Class Initialized
DEBUG - 2011-07-05 02:21:10 --> Loader Class Initialized
DEBUG - 2011-07-05 02:21:10 --> Controller Class Initialized
ERROR - 2011-07-05 02:21:10 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-05 02:21:10 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-05 02:21:10 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-05 02:21:10 --> Model Class Initialized
DEBUG - 2011-07-05 02:21:10 --> Model Class Initialized
DEBUG - 2011-07-05 02:21:10 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-05 02:21:10 --> Database Driver Class Initialized
DEBUG - 2011-07-05 02:21:10 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-05 02:21:10 --> Helper loaded: url_helper
DEBUG - 2011-07-05 02:21:10 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-05 02:21:10 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-05 02:21:10 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-05 02:21:10 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-05 02:21:10 --> Final output sent to browser
DEBUG - 2011-07-05 02:21:10 --> Total execution time: 0.0288
DEBUG - 2011-07-05 04:22:30 --> Config Class Initialized
DEBUG - 2011-07-05 04:22:30 --> Hooks Class Initialized
DEBUG - 2011-07-05 04:22:30 --> Utf8 Class Initialized
DEBUG - 2011-07-05 04:22:30 --> UTF-8 Support Enabled
DEBUG - 2011-07-05 04:22:30 --> URI Class Initialized
DEBUG - 2011-07-05 04:22:30 --> Router Class Initialized
ERROR - 2011-07-05 04:22:30 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-07-05 04:22:30 --> Config Class Initialized
DEBUG - 2011-07-05 04:22:30 --> Hooks Class Initialized
DEBUG - 2011-07-05 04:22:30 --> Utf8 Class Initialized
DEBUG - 2011-07-05 04:22:30 --> UTF-8 Support Enabled
DEBUG - 2011-07-05 04:22:30 --> URI Class Initialized
DEBUG - 2011-07-05 04:22:30 --> Router Class Initialized
DEBUG - 2011-07-05 04:22:30 --> Output Class Initialized
DEBUG - 2011-07-05 04:22:30 --> Input Class Initialized
DEBUG - 2011-07-05 04:22:30 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-05 04:22:30 --> Language Class Initialized
DEBUG - 2011-07-05 04:22:30 --> Loader Class Initialized
DEBUG - 2011-07-05 04:22:30 --> Controller Class Initialized
ERROR - 2011-07-05 04:22:30 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-05 04:22:30 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-05 04:22:30 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-05 04:22:30 --> Model Class Initialized
DEBUG - 2011-07-05 04:22:30 --> Model Class Initialized
DEBUG - 2011-07-05 04:22:30 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-05 04:22:30 --> Database Driver Class Initialized
DEBUG - 2011-07-05 04:22:30 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-05 04:22:31 --> Helper loaded: url_helper
DEBUG - 2011-07-05 04:22:31 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-05 04:22:31 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-05 04:22:31 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-05 04:22:31 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-05 04:22:31 --> Final output sent to browser
DEBUG - 2011-07-05 04:22:31 --> Total execution time: 0.7547
DEBUG - 2011-07-05 05:03:17 --> Config Class Initialized
DEBUG - 2011-07-05 05:03:17 --> Hooks Class Initialized
DEBUG - 2011-07-05 05:03:17 --> Utf8 Class Initialized
DEBUG - 2011-07-05 05:03:17 --> UTF-8 Support Enabled
DEBUG - 2011-07-05 05:03:17 --> URI Class Initialized
DEBUG - 2011-07-05 05:03:17 --> Router Class Initialized
DEBUG - 2011-07-05 05:03:17 --> Output Class Initialized
DEBUG - 2011-07-05 05:03:17 --> Input Class Initialized
DEBUG - 2011-07-05 05:03:17 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-05 05:03:17 --> Language Class Initialized
DEBUG - 2011-07-05 05:03:17 --> Loader Class Initialized
DEBUG - 2011-07-05 05:03:17 --> Controller Class Initialized
DEBUG - 2011-07-05 05:03:17 --> Model Class Initialized
DEBUG - 2011-07-05 05:03:17 --> Model Class Initialized
DEBUG - 2011-07-05 05:03:17 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-05 05:03:17 --> Database Driver Class Initialized
DEBUG - 2011-07-05 05:03:18 --> Final output sent to browser
DEBUG - 2011-07-05 05:03:18 --> Total execution time: 0.9950
DEBUG - 2011-07-05 10:38:52 --> Config Class Initialized
DEBUG - 2011-07-05 10:38:52 --> Hooks Class Initialized
DEBUG - 2011-07-05 10:38:52 --> Utf8 Class Initialized
DEBUG - 2011-07-05 10:38:52 --> UTF-8 Support Enabled
DEBUG - 2011-07-05 10:38:52 --> URI Class Initialized
DEBUG - 2011-07-05 10:38:52 --> Router Class Initialized
DEBUG - 2011-07-05 10:38:52 --> Output Class Initialized
DEBUG - 2011-07-05 10:38:52 --> Input Class Initialized
DEBUG - 2011-07-05 10:38:52 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-05 10:38:52 --> Language Class Initialized
DEBUG - 2011-07-05 10:38:52 --> Loader Class Initialized
DEBUG - 2011-07-05 10:38:52 --> Controller Class Initialized
ERROR - 2011-07-05 10:38:52 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-05 10:38:52 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-05 10:38:52 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-05 10:38:52 --> Model Class Initialized
DEBUG - 2011-07-05 10:38:52 --> Model Class Initialized
DEBUG - 2011-07-05 10:38:52 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-05 10:38:52 --> Database Driver Class Initialized
DEBUG - 2011-07-05 10:38:52 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-05 10:38:52 --> Helper loaded: url_helper
DEBUG - 2011-07-05 10:38:52 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-05 10:38:52 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-05 10:38:52 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-05 10:38:52 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-05 10:38:52 --> Final output sent to browser
DEBUG - 2011-07-05 10:38:52 --> Total execution time: 0.4247
DEBUG - 2011-07-05 10:39:25 --> Config Class Initialized
DEBUG - 2011-07-05 10:39:25 --> Hooks Class Initialized
DEBUG - 2011-07-05 10:39:25 --> Utf8 Class Initialized
DEBUG - 2011-07-05 10:39:25 --> UTF-8 Support Enabled
DEBUG - 2011-07-05 10:39:25 --> URI Class Initialized
DEBUG - 2011-07-05 10:39:25 --> Router Class Initialized
DEBUG - 2011-07-05 10:39:25 --> Output Class Initialized
DEBUG - 2011-07-05 10:39:25 --> Input Class Initialized
DEBUG - 2011-07-05 10:39:25 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-05 10:39:25 --> Language Class Initialized
DEBUG - 2011-07-05 10:39:25 --> Loader Class Initialized
DEBUG - 2011-07-05 10:39:25 --> Controller Class Initialized
DEBUG - 2011-07-05 10:39:25 --> Model Class Initialized
DEBUG - 2011-07-05 10:39:25 --> Model Class Initialized
DEBUG - 2011-07-05 10:39:25 --> Model Class Initialized
DEBUG - 2011-07-05 10:39:25 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-05 10:39:25 --> Database Driver Class Initialized
DEBUG - 2011-07-05 10:39:28 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-05 10:39:28 --> Helper loaded: url_helper
DEBUG - 2011-07-05 10:39:28 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-05 10:39:28 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-05 10:39:28 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-05 10:39:28 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-05 10:39:28 --> Final output sent to browser
DEBUG - 2011-07-05 10:39:28 --> Total execution time: 3.6168
DEBUG - 2011-07-05 10:48:59 --> Config Class Initialized
DEBUG - 2011-07-05 10:48:59 --> Hooks Class Initialized
DEBUG - 2011-07-05 10:48:59 --> Utf8 Class Initialized
DEBUG - 2011-07-05 10:48:59 --> UTF-8 Support Enabled
DEBUG - 2011-07-05 10:48:59 --> URI Class Initialized
DEBUG - 2011-07-05 10:48:59 --> Router Class Initialized
DEBUG - 2011-07-05 10:48:59 --> Output Class Initialized
DEBUG - 2011-07-05 10:48:59 --> Input Class Initialized
DEBUG - 2011-07-05 10:48:59 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-05 10:48:59 --> Language Class Initialized
DEBUG - 2011-07-05 10:48:59 --> Loader Class Initialized
DEBUG - 2011-07-05 10:48:59 --> Controller Class Initialized
ERROR - 2011-07-05 10:48:59 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-05 10:48:59 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-05 10:48:59 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-05 10:48:59 --> Model Class Initialized
DEBUG - 2011-07-05 10:48:59 --> Model Class Initialized
DEBUG - 2011-07-05 10:48:59 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-05 10:48:59 --> Database Driver Class Initialized
DEBUG - 2011-07-05 10:48:59 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-05 10:48:59 --> Helper loaded: url_helper
DEBUG - 2011-07-05 10:48:59 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-05 10:48:59 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-05 10:48:59 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-05 10:48:59 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-05 10:48:59 --> Final output sent to browser
DEBUG - 2011-07-05 10:48:59 --> Total execution time: 0.1308
DEBUG - 2011-07-05 10:49:01 --> Config Class Initialized
DEBUG - 2011-07-05 10:49:01 --> Hooks Class Initialized
DEBUG - 2011-07-05 10:49:01 --> Utf8 Class Initialized
DEBUG - 2011-07-05 10:49:01 --> UTF-8 Support Enabled
DEBUG - 2011-07-05 10:49:01 --> URI Class Initialized
DEBUG - 2011-07-05 10:49:01 --> Router Class Initialized
DEBUG - 2011-07-05 10:49:01 --> Output Class Initialized
DEBUG - 2011-07-05 10:49:01 --> Input Class Initialized
DEBUG - 2011-07-05 10:49:01 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-05 10:49:01 --> Language Class Initialized
DEBUG - 2011-07-05 10:49:01 --> Loader Class Initialized
DEBUG - 2011-07-05 10:49:01 --> Controller Class Initialized
DEBUG - 2011-07-05 10:49:01 --> Model Class Initialized
DEBUG - 2011-07-05 10:49:01 --> Model Class Initialized
DEBUG - 2011-07-05 10:49:01 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-05 10:49:01 --> Database Driver Class Initialized
DEBUG - 2011-07-05 10:49:01 --> Final output sent to browser
DEBUG - 2011-07-05 10:49:01 --> Total execution time: 0.7757
DEBUG - 2011-07-05 10:49:07 --> Config Class Initialized
DEBUG - 2011-07-05 10:49:07 --> Hooks Class Initialized
DEBUG - 2011-07-05 10:49:07 --> Utf8 Class Initialized
DEBUG - 2011-07-05 10:49:07 --> UTF-8 Support Enabled
DEBUG - 2011-07-05 10:49:07 --> URI Class Initialized
DEBUG - 2011-07-05 10:49:07 --> Router Class Initialized
ERROR - 2011-07-05 10:49:07 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-05 12:40:42 --> Config Class Initialized
DEBUG - 2011-07-05 12:40:43 --> Hooks Class Initialized
DEBUG - 2011-07-05 12:40:43 --> Utf8 Class Initialized
DEBUG - 2011-07-05 12:40:43 --> UTF-8 Support Enabled
DEBUG - 2011-07-05 12:40:43 --> URI Class Initialized
DEBUG - 2011-07-05 12:40:43 --> Router Class Initialized
DEBUG - 2011-07-05 12:40:43 --> Output Class Initialized
DEBUG - 2011-07-05 12:40:43 --> Input Class Initialized
DEBUG - 2011-07-05 12:40:43 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-05 12:40:43 --> Language Class Initialized
DEBUG - 2011-07-05 12:40:43 --> Loader Class Initialized
DEBUG - 2011-07-05 12:40:43 --> Controller Class Initialized
DEBUG - 2011-07-05 12:40:43 --> Model Class Initialized
DEBUG - 2011-07-05 12:40:43 --> Model Class Initialized
DEBUG - 2011-07-05 12:40:43 --> Model Class Initialized
DEBUG - 2011-07-05 12:40:43 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-05 12:40:43 --> Database Driver Class Initialized
DEBUG - 2011-07-05 12:40:43 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-05 12:40:43 --> Helper loaded: url_helper
DEBUG - 2011-07-05 12:40:43 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-05 12:40:44 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-05 12:40:44 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-05 12:40:44 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-05 12:40:44 --> Final output sent to browser
DEBUG - 2011-07-05 12:40:44 --> Total execution time: 1.2726
DEBUG - 2011-07-05 12:40:48 --> Config Class Initialized
DEBUG - 2011-07-05 12:40:48 --> Hooks Class Initialized
DEBUG - 2011-07-05 12:40:48 --> Utf8 Class Initialized
DEBUG - 2011-07-05 12:40:48 --> UTF-8 Support Enabled
DEBUG - 2011-07-05 12:40:48 --> URI Class Initialized
DEBUG - 2011-07-05 12:40:48 --> Router Class Initialized
DEBUG - 2011-07-05 12:40:48 --> Output Class Initialized
DEBUG - 2011-07-05 12:40:48 --> Input Class Initialized
DEBUG - 2011-07-05 12:40:48 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-05 12:40:48 --> Language Class Initialized
DEBUG - 2011-07-05 12:40:48 --> Loader Class Initialized
DEBUG - 2011-07-05 12:40:48 --> Controller Class Initialized
ERROR - 2011-07-05 12:40:48 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-05 12:40:48 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-05 12:40:48 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-05 12:40:48 --> Model Class Initialized
DEBUG - 2011-07-05 12:40:48 --> Model Class Initialized
DEBUG - 2011-07-05 12:40:48 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-05 12:40:48 --> Database Driver Class Initialized
DEBUG - 2011-07-05 12:40:48 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-05 12:40:48 --> Helper loaded: url_helper
DEBUG - 2011-07-05 12:40:48 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-05 12:40:48 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-05 12:40:48 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-05 12:40:48 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-05 12:40:48 --> Final output sent to browser
DEBUG - 2011-07-05 12:40:48 --> Total execution time: 0.0970
DEBUG - 2011-07-05 12:40:50 --> Config Class Initialized
DEBUG - 2011-07-05 12:40:50 --> Hooks Class Initialized
DEBUG - 2011-07-05 12:40:50 --> Utf8 Class Initialized
DEBUG - 2011-07-05 12:40:50 --> UTF-8 Support Enabled
DEBUG - 2011-07-05 12:40:50 --> URI Class Initialized
DEBUG - 2011-07-05 12:40:50 --> Router Class Initialized
DEBUG - 2011-07-05 12:40:50 --> Output Class Initialized
DEBUG - 2011-07-05 12:40:50 --> Input Class Initialized
DEBUG - 2011-07-05 12:40:50 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-05 12:40:50 --> Language Class Initialized
DEBUG - 2011-07-05 12:40:50 --> Loader Class Initialized
DEBUG - 2011-07-05 12:40:50 --> Controller Class Initialized
DEBUG - 2011-07-05 12:40:50 --> Model Class Initialized
DEBUG - 2011-07-05 12:40:50 --> Model Class Initialized
DEBUG - 2011-07-05 12:40:50 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-05 12:40:50 --> Database Driver Class Initialized
DEBUG - 2011-07-05 12:40:50 --> Final output sent to browser
DEBUG - 2011-07-05 12:40:50 --> Total execution time: 0.7221
DEBUG - 2011-07-05 12:41:01 --> Config Class Initialized
DEBUG - 2011-07-05 12:41:01 --> Hooks Class Initialized
DEBUG - 2011-07-05 12:41:01 --> Utf8 Class Initialized
DEBUG - 2011-07-05 12:41:01 --> UTF-8 Support Enabled
DEBUG - 2011-07-05 12:41:01 --> URI Class Initialized
DEBUG - 2011-07-05 12:41:01 --> Router Class Initialized
ERROR - 2011-07-05 12:41:01 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-05 12:41:02 --> Config Class Initialized
DEBUG - 2011-07-05 12:41:02 --> Hooks Class Initialized
DEBUG - 2011-07-05 12:41:02 --> Utf8 Class Initialized
DEBUG - 2011-07-05 12:41:02 --> UTF-8 Support Enabled
DEBUG - 2011-07-05 12:41:02 --> URI Class Initialized
DEBUG - 2011-07-05 12:41:02 --> Router Class Initialized
ERROR - 2011-07-05 12:41:02 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-05 12:41:02 --> Config Class Initialized
DEBUG - 2011-07-05 12:41:02 --> Hooks Class Initialized
DEBUG - 2011-07-05 12:41:02 --> Utf8 Class Initialized
DEBUG - 2011-07-05 12:41:02 --> UTF-8 Support Enabled
DEBUG - 2011-07-05 12:41:02 --> URI Class Initialized
DEBUG - 2011-07-05 12:41:02 --> Router Class Initialized
ERROR - 2011-07-05 12:41:02 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-05 12:49:18 --> Config Class Initialized
DEBUG - 2011-07-05 12:49:18 --> Hooks Class Initialized
DEBUG - 2011-07-05 12:49:18 --> Utf8 Class Initialized
DEBUG - 2011-07-05 12:49:18 --> UTF-8 Support Enabled
DEBUG - 2011-07-05 12:49:18 --> URI Class Initialized
DEBUG - 2011-07-05 12:49:18 --> Router Class Initialized
DEBUG - 2011-07-05 12:49:18 --> Output Class Initialized
DEBUG - 2011-07-05 12:49:18 --> Input Class Initialized
DEBUG - 2011-07-05 12:49:18 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-05 12:49:18 --> Language Class Initialized
DEBUG - 2011-07-05 12:49:18 --> Loader Class Initialized
DEBUG - 2011-07-05 12:49:18 --> Controller Class Initialized
ERROR - 2011-07-05 12:49:18 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-05 12:49:18 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-05 12:49:18 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-05 12:49:18 --> Model Class Initialized
DEBUG - 2011-07-05 12:49:18 --> Model Class Initialized
DEBUG - 2011-07-05 12:49:18 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-05 12:49:18 --> Database Driver Class Initialized
DEBUG - 2011-07-05 12:49:18 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-05 12:49:19 --> Helper loaded: url_helper
DEBUG - 2011-07-05 12:49:19 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-05 12:49:19 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-05 12:49:19 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-05 12:49:19 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-05 12:49:19 --> Final output sent to browser
DEBUG - 2011-07-05 12:49:19 --> Total execution time: 0.3631
DEBUG - 2011-07-05 12:49:20 --> Config Class Initialized
DEBUG - 2011-07-05 12:49:20 --> Hooks Class Initialized
DEBUG - 2011-07-05 12:49:20 --> Utf8 Class Initialized
DEBUG - 2011-07-05 12:49:20 --> UTF-8 Support Enabled
DEBUG - 2011-07-05 12:49:20 --> URI Class Initialized
DEBUG - 2011-07-05 12:49:20 --> Router Class Initialized
ERROR - 2011-07-05 12:49:20 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-05 12:49:20 --> Config Class Initialized
DEBUG - 2011-07-05 12:49:20 --> Hooks Class Initialized
DEBUG - 2011-07-05 12:49:20 --> Utf8 Class Initialized
DEBUG - 2011-07-05 12:49:20 --> UTF-8 Support Enabled
DEBUG - 2011-07-05 12:49:20 --> URI Class Initialized
DEBUG - 2011-07-05 12:49:20 --> Router Class Initialized
DEBUG - 2011-07-05 12:49:20 --> Output Class Initialized
DEBUG - 2011-07-05 12:49:20 --> Input Class Initialized
DEBUG - 2011-07-05 12:49:20 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-05 12:49:20 --> Language Class Initialized
DEBUG - 2011-07-05 12:49:20 --> Loader Class Initialized
DEBUG - 2011-07-05 12:49:20 --> Controller Class Initialized
DEBUG - 2011-07-05 12:49:20 --> Model Class Initialized
DEBUG - 2011-07-05 12:49:20 --> Model Class Initialized
DEBUG - 2011-07-05 12:49:20 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-05 12:49:20 --> Database Driver Class Initialized
DEBUG - 2011-07-05 12:49:21 --> Final output sent to browser
DEBUG - 2011-07-05 12:49:21 --> Total execution time: 0.7433
DEBUG - 2011-07-05 13:22:22 --> Config Class Initialized
DEBUG - 2011-07-05 13:22:22 --> Hooks Class Initialized
DEBUG - 2011-07-05 13:22:22 --> Utf8 Class Initialized
DEBUG - 2011-07-05 13:22:22 --> UTF-8 Support Enabled
DEBUG - 2011-07-05 13:22:22 --> URI Class Initialized
DEBUG - 2011-07-05 13:22:22 --> Router Class Initialized
DEBUG - 2011-07-05 13:22:22 --> Output Class Initialized
DEBUG - 2011-07-05 13:22:22 --> Input Class Initialized
DEBUG - 2011-07-05 13:22:22 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-05 13:22:22 --> Language Class Initialized
DEBUG - 2011-07-05 13:22:22 --> Loader Class Initialized
DEBUG - 2011-07-05 13:22:22 --> Controller Class Initialized
ERROR - 2011-07-05 13:22:22 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-05 13:22:22 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-05 13:22:22 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-05 13:22:22 --> Model Class Initialized
DEBUG - 2011-07-05 13:22:22 --> Model Class Initialized
DEBUG - 2011-07-05 13:22:22 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-05 13:22:22 --> Database Driver Class Initialized
DEBUG - 2011-07-05 13:22:22 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-05 13:22:22 --> Helper loaded: url_helper
DEBUG - 2011-07-05 13:22:22 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-05 13:22:22 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-05 13:22:22 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-05 13:22:22 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-05 13:22:22 --> Final output sent to browser
DEBUG - 2011-07-05 13:22:22 --> Total execution time: 0.4345
DEBUG - 2011-07-05 13:22:23 --> Config Class Initialized
DEBUG - 2011-07-05 13:22:23 --> Hooks Class Initialized
DEBUG - 2011-07-05 13:22:23 --> Utf8 Class Initialized
DEBUG - 2011-07-05 13:22:23 --> UTF-8 Support Enabled
DEBUG - 2011-07-05 13:22:23 --> URI Class Initialized
DEBUG - 2011-07-05 13:22:23 --> Router Class Initialized
DEBUG - 2011-07-05 13:22:23 --> Output Class Initialized
DEBUG - 2011-07-05 13:22:23 --> Input Class Initialized
DEBUG - 2011-07-05 13:22:23 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-05 13:22:23 --> Language Class Initialized
DEBUG - 2011-07-05 13:22:23 --> Loader Class Initialized
DEBUG - 2011-07-05 13:22:23 --> Controller Class Initialized
DEBUG - 2011-07-05 13:22:23 --> Model Class Initialized
DEBUG - 2011-07-05 13:22:23 --> Model Class Initialized
DEBUG - 2011-07-05 13:22:23 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-05 13:22:23 --> Database Driver Class Initialized
DEBUG - 2011-07-05 13:22:24 --> Final output sent to browser
DEBUG - 2011-07-05 13:22:24 --> Total execution time: 0.9993
DEBUG - 2011-07-05 13:27:33 --> Config Class Initialized
DEBUG - 2011-07-05 13:27:33 --> Hooks Class Initialized
DEBUG - 2011-07-05 13:27:33 --> Utf8 Class Initialized
DEBUG - 2011-07-05 13:27:33 --> UTF-8 Support Enabled
DEBUG - 2011-07-05 13:27:33 --> URI Class Initialized
DEBUG - 2011-07-05 13:27:33 --> Router Class Initialized
ERROR - 2011-07-05 13:27:33 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-07-05 13:27:33 --> Config Class Initialized
DEBUG - 2011-07-05 13:27:33 --> Hooks Class Initialized
DEBUG - 2011-07-05 13:27:33 --> Utf8 Class Initialized
DEBUG - 2011-07-05 13:27:33 --> UTF-8 Support Enabled
DEBUG - 2011-07-05 13:27:33 --> URI Class Initialized
DEBUG - 2011-07-05 13:27:33 --> Router Class Initialized
DEBUG - 2011-07-05 13:27:33 --> No URI present. Default controller set.
DEBUG - 2011-07-05 13:27:33 --> Output Class Initialized
DEBUG - 2011-07-05 13:27:33 --> Input Class Initialized
DEBUG - 2011-07-05 13:27:33 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-05 13:27:33 --> Language Class Initialized
DEBUG - 2011-07-05 13:27:33 --> Loader Class Initialized
DEBUG - 2011-07-05 13:27:33 --> Controller Class Initialized
DEBUG - 2011-07-05 13:27:33 --> File loaded: application/views/splash/main.php
DEBUG - 2011-07-05 13:27:33 --> Helper loaded: url_helper
DEBUG - 2011-07-05 13:27:33 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-05 13:27:33 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-05 13:27:33 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-05 13:27:33 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-05 13:27:33 --> Final output sent to browser
DEBUG - 2011-07-05 13:27:33 --> Total execution time: 0.0632
DEBUG - 2011-07-05 13:43:27 --> Config Class Initialized
DEBUG - 2011-07-05 13:43:27 --> Hooks Class Initialized
DEBUG - 2011-07-05 13:43:27 --> Utf8 Class Initialized
DEBUG - 2011-07-05 13:43:27 --> UTF-8 Support Enabled
DEBUG - 2011-07-05 13:43:27 --> URI Class Initialized
DEBUG - 2011-07-05 13:43:27 --> Router Class Initialized
DEBUG - 2011-07-05 13:43:27 --> Output Class Initialized
DEBUG - 2011-07-05 13:43:27 --> Input Class Initialized
DEBUG - 2011-07-05 13:43:27 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-05 13:43:27 --> Language Class Initialized
DEBUG - 2011-07-05 13:43:27 --> Loader Class Initialized
DEBUG - 2011-07-05 13:43:27 --> Controller Class Initialized
ERROR - 2011-07-05 13:43:27 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-05 13:43:27 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-05 13:43:27 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-05 13:43:27 --> Model Class Initialized
DEBUG - 2011-07-05 13:43:27 --> Model Class Initialized
DEBUG - 2011-07-05 13:43:27 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-05 13:43:27 --> Database Driver Class Initialized
DEBUG - 2011-07-05 13:43:27 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-05 13:43:27 --> Helper loaded: url_helper
DEBUG - 2011-07-05 13:43:27 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-05 13:43:27 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-05 13:43:27 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-05 13:43:27 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-05 13:43:27 --> Final output sent to browser
DEBUG - 2011-07-05 13:43:27 --> Total execution time: 0.2198
DEBUG - 2011-07-05 13:43:28 --> Config Class Initialized
DEBUG - 2011-07-05 13:43:28 --> Hooks Class Initialized
DEBUG - 2011-07-05 13:43:28 --> Utf8 Class Initialized
DEBUG - 2011-07-05 13:43:28 --> UTF-8 Support Enabled
DEBUG - 2011-07-05 13:43:28 --> URI Class Initialized
DEBUG - 2011-07-05 13:43:28 --> Router Class Initialized
DEBUG - 2011-07-05 13:43:28 --> Output Class Initialized
DEBUG - 2011-07-05 13:43:28 --> Input Class Initialized
DEBUG - 2011-07-05 13:43:28 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-05 13:43:28 --> Language Class Initialized
DEBUG - 2011-07-05 13:43:28 --> Loader Class Initialized
DEBUG - 2011-07-05 13:43:28 --> Controller Class Initialized
DEBUG - 2011-07-05 13:43:28 --> Model Class Initialized
DEBUG - 2011-07-05 13:43:28 --> Model Class Initialized
DEBUG - 2011-07-05 13:43:28 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-05 13:43:28 --> Database Driver Class Initialized
DEBUG - 2011-07-05 13:43:29 --> Final output sent to browser
DEBUG - 2011-07-05 13:43:29 --> Total execution time: 0.6882
DEBUG - 2011-07-05 13:43:29 --> Config Class Initialized
DEBUG - 2011-07-05 13:43:29 --> Hooks Class Initialized
DEBUG - 2011-07-05 13:43:29 --> Utf8 Class Initialized
DEBUG - 2011-07-05 13:43:29 --> UTF-8 Support Enabled
DEBUG - 2011-07-05 13:43:29 --> URI Class Initialized
DEBUG - 2011-07-05 13:43:29 --> Router Class Initialized
ERROR - 2011-07-05 13:43:29 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-05 13:49:13 --> Config Class Initialized
DEBUG - 2011-07-05 13:49:13 --> Hooks Class Initialized
DEBUG - 2011-07-05 13:49:13 --> Utf8 Class Initialized
DEBUG - 2011-07-05 13:49:13 --> UTF-8 Support Enabled
DEBUG - 2011-07-05 13:49:13 --> URI Class Initialized
DEBUG - 2011-07-05 13:49:13 --> Router Class Initialized
ERROR - 2011-07-05 13:49:13 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-05 16:11:53 --> Config Class Initialized
DEBUG - 2011-07-05 16:11:53 --> Hooks Class Initialized
DEBUG - 2011-07-05 16:11:53 --> Utf8 Class Initialized
DEBUG - 2011-07-05 16:11:53 --> UTF-8 Support Enabled
DEBUG - 2011-07-05 16:11:53 --> URI Class Initialized
DEBUG - 2011-07-05 16:11:53 --> Router Class Initialized
DEBUG - 2011-07-05 16:11:53 --> Output Class Initialized
DEBUG - 2011-07-05 16:11:53 --> Input Class Initialized
DEBUG - 2011-07-05 16:11:53 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-05 16:11:53 --> Language Class Initialized
DEBUG - 2011-07-05 16:11:53 --> Loader Class Initialized
DEBUG - 2011-07-05 16:11:53 --> Controller Class Initialized
ERROR - 2011-07-05 16:11:53 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-05 16:11:53 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-05 16:11:53 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-05 16:11:53 --> Model Class Initialized
DEBUG - 2011-07-05 16:11:53 --> Model Class Initialized
DEBUG - 2011-07-05 16:11:53 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-05 16:11:53 --> Database Driver Class Initialized
DEBUG - 2011-07-05 16:11:53 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-05 16:11:53 --> Helper loaded: url_helper
DEBUG - 2011-07-05 16:11:53 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-05 16:11:53 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-05 16:11:53 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-05 16:11:53 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-05 16:11:53 --> Final output sent to browser
DEBUG - 2011-07-05 16:11:53 --> Total execution time: 0.3643
DEBUG - 2011-07-05 18:12:09 --> Config Class Initialized
DEBUG - 2011-07-05 18:12:09 --> Hooks Class Initialized
DEBUG - 2011-07-05 18:12:09 --> Utf8 Class Initialized
DEBUG - 2011-07-05 18:12:09 --> UTF-8 Support Enabled
DEBUG - 2011-07-05 18:12:09 --> URI Class Initialized
DEBUG - 2011-07-05 18:12:09 --> Router Class Initialized
DEBUG - 2011-07-05 18:12:09 --> Output Class Initialized
DEBUG - 2011-07-05 18:12:09 --> Input Class Initialized
DEBUG - 2011-07-05 18:12:09 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-05 18:12:09 --> Language Class Initialized
DEBUG - 2011-07-05 18:12:09 --> Loader Class Initialized
DEBUG - 2011-07-05 18:12:09 --> Controller Class Initialized
ERROR - 2011-07-05 18:12:09 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-05 18:12:09 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-05 18:12:09 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-05 18:12:09 --> Model Class Initialized
DEBUG - 2011-07-05 18:12:09 --> Model Class Initialized
DEBUG - 2011-07-05 18:12:09 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-05 18:12:09 --> Database Driver Class Initialized
DEBUG - 2011-07-05 18:12:09 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-05 18:12:09 --> Helper loaded: url_helper
DEBUG - 2011-07-05 18:12:09 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-05 18:12:09 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-05 18:12:09 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-05 18:12:09 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-05 18:12:09 --> Final output sent to browser
DEBUG - 2011-07-05 18:12:09 --> Total execution time: 0.3993
DEBUG - 2011-07-05 19:14:02 --> Config Class Initialized
DEBUG - 2011-07-05 19:14:02 --> Hooks Class Initialized
DEBUG - 2011-07-05 19:14:02 --> Utf8 Class Initialized
DEBUG - 2011-07-05 19:14:02 --> UTF-8 Support Enabled
DEBUG - 2011-07-05 19:14:02 --> URI Class Initialized
DEBUG - 2011-07-05 19:14:02 --> Router Class Initialized
DEBUG - 2011-07-05 19:14:02 --> Output Class Initialized
DEBUG - 2011-07-05 19:14:02 --> Input Class Initialized
DEBUG - 2011-07-05 19:14:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-05 19:14:02 --> Language Class Initialized
DEBUG - 2011-07-05 19:14:02 --> Loader Class Initialized
DEBUG - 2011-07-05 19:14:02 --> Controller Class Initialized
ERROR - 2011-07-05 19:14:02 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-05 19:14:02 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-05 19:14:02 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-05 19:14:02 --> Model Class Initialized
DEBUG - 2011-07-05 19:14:02 --> Model Class Initialized
DEBUG - 2011-07-05 19:14:02 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-05 19:14:02 --> Database Driver Class Initialized
DEBUG - 2011-07-05 19:14:02 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-05 19:14:03 --> Helper loaded: url_helper
DEBUG - 2011-07-05 19:14:03 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-05 19:14:03 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-05 19:14:03 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-05 19:14:03 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-05 19:14:03 --> Final output sent to browser
DEBUG - 2011-07-05 19:14:03 --> Total execution time: 0.3886
DEBUG - 2011-07-05 19:14:07 --> Config Class Initialized
DEBUG - 2011-07-05 19:14:07 --> Hooks Class Initialized
DEBUG - 2011-07-05 19:14:07 --> Utf8 Class Initialized
DEBUG - 2011-07-05 19:14:07 --> UTF-8 Support Enabled
DEBUG - 2011-07-05 19:14:07 --> URI Class Initialized
DEBUG - 2011-07-05 19:14:07 --> Router Class Initialized
DEBUG - 2011-07-05 19:14:07 --> Output Class Initialized
DEBUG - 2011-07-05 19:14:07 --> Input Class Initialized
DEBUG - 2011-07-05 19:14:07 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-05 19:14:07 --> Language Class Initialized
DEBUG - 2011-07-05 19:14:07 --> Loader Class Initialized
DEBUG - 2011-07-05 19:14:07 --> Controller Class Initialized
DEBUG - 2011-07-05 19:14:07 --> Model Class Initialized
DEBUG - 2011-07-05 19:14:07 --> Model Class Initialized
DEBUG - 2011-07-05 19:14:07 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-05 19:14:07 --> Database Driver Class Initialized
DEBUG - 2011-07-05 19:14:08 --> Final output sent to browser
DEBUG - 2011-07-05 19:14:08 --> Total execution time: 0.7671
DEBUG - 2011-07-05 19:22:13 --> Config Class Initialized
DEBUG - 2011-07-05 19:22:13 --> Hooks Class Initialized
DEBUG - 2011-07-05 19:22:13 --> Utf8 Class Initialized
DEBUG - 2011-07-05 19:22:13 --> UTF-8 Support Enabled
DEBUG - 2011-07-05 19:22:13 --> URI Class Initialized
DEBUG - 2011-07-05 19:22:13 --> Router Class Initialized
DEBUG - 2011-07-05 19:22:13 --> Output Class Initialized
DEBUG - 2011-07-05 19:22:13 --> Input Class Initialized
DEBUG - 2011-07-05 19:22:13 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-05 19:22:13 --> Language Class Initialized
DEBUG - 2011-07-05 19:22:13 --> Loader Class Initialized
DEBUG - 2011-07-05 19:22:13 --> Controller Class Initialized
ERROR - 2011-07-05 19:22:13 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-05 19:22:13 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-05 19:22:13 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-05 19:22:13 --> Model Class Initialized
DEBUG - 2011-07-05 19:22:13 --> Model Class Initialized
DEBUG - 2011-07-05 19:22:13 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-05 19:22:14 --> Database Driver Class Initialized
DEBUG - 2011-07-05 19:22:14 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-05 19:22:14 --> Helper loaded: url_helper
DEBUG - 2011-07-05 19:22:14 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-05 19:22:14 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-05 19:22:14 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-05 19:22:14 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-05 19:22:14 --> Final output sent to browser
DEBUG - 2011-07-05 19:22:14 --> Total execution time: 0.0287
DEBUG - 2011-07-05 19:22:15 --> Config Class Initialized
DEBUG - 2011-07-05 19:22:15 --> Hooks Class Initialized
DEBUG - 2011-07-05 19:22:15 --> Utf8 Class Initialized
DEBUG - 2011-07-05 19:22:15 --> UTF-8 Support Enabled
DEBUG - 2011-07-05 19:22:15 --> URI Class Initialized
DEBUG - 2011-07-05 19:22:15 --> Router Class Initialized
DEBUG - 2011-07-05 19:22:15 --> Output Class Initialized
DEBUG - 2011-07-05 19:22:15 --> Input Class Initialized
DEBUG - 2011-07-05 19:22:15 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-05 19:22:15 --> Language Class Initialized
DEBUG - 2011-07-05 19:22:15 --> Loader Class Initialized
DEBUG - 2011-07-05 19:22:15 --> Controller Class Initialized
DEBUG - 2011-07-05 19:22:15 --> Model Class Initialized
DEBUG - 2011-07-05 19:22:15 --> Model Class Initialized
DEBUG - 2011-07-05 19:22:15 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-05 19:22:15 --> Database Driver Class Initialized
DEBUG - 2011-07-05 19:22:15 --> Final output sent to browser
DEBUG - 2011-07-05 19:22:15 --> Total execution time: 0.5081
DEBUG - 2011-07-05 19:57:48 --> Config Class Initialized
DEBUG - 2011-07-05 19:57:48 --> Hooks Class Initialized
DEBUG - 2011-07-05 19:57:48 --> Utf8 Class Initialized
DEBUG - 2011-07-05 19:57:48 --> UTF-8 Support Enabled
DEBUG - 2011-07-05 19:57:48 --> URI Class Initialized
DEBUG - 2011-07-05 19:57:48 --> Router Class Initialized
DEBUG - 2011-07-05 19:57:48 --> Output Class Initialized
DEBUG - 2011-07-05 19:57:48 --> Input Class Initialized
DEBUG - 2011-07-05 19:57:48 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-05 19:57:48 --> Language Class Initialized
DEBUG - 2011-07-05 19:57:48 --> Loader Class Initialized
DEBUG - 2011-07-05 19:57:48 --> Controller Class Initialized
ERROR - 2011-07-05 19:57:48 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-05 19:57:48 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-05 19:57:48 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-05 19:57:48 --> Model Class Initialized
DEBUG - 2011-07-05 19:57:48 --> Model Class Initialized
DEBUG - 2011-07-05 19:57:48 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-05 19:57:48 --> Database Driver Class Initialized
DEBUG - 2011-07-05 19:57:48 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-05 19:57:48 --> Helper loaded: url_helper
DEBUG - 2011-07-05 19:57:48 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-05 19:57:48 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-05 19:57:48 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-05 19:57:48 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-05 19:57:48 --> Final output sent to browser
DEBUG - 2011-07-05 19:57:48 --> Total execution time: 0.3031
DEBUG - 2011-07-05 21:09:07 --> Config Class Initialized
DEBUG - 2011-07-05 21:09:07 --> Hooks Class Initialized
DEBUG - 2011-07-05 21:09:07 --> Utf8 Class Initialized
DEBUG - 2011-07-05 21:09:07 --> UTF-8 Support Enabled
DEBUG - 2011-07-05 21:09:07 --> URI Class Initialized
DEBUG - 2011-07-05 21:09:07 --> Router Class Initialized
DEBUG - 2011-07-05 21:09:07 --> Output Class Initialized
DEBUG - 2011-07-05 21:09:07 --> Input Class Initialized
DEBUG - 2011-07-05 21:09:07 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-05 21:09:07 --> Language Class Initialized
DEBUG - 2011-07-05 21:09:07 --> Loader Class Initialized
DEBUG - 2011-07-05 21:09:07 --> Controller Class Initialized
DEBUG - 2011-07-05 21:09:07 --> Model Class Initialized
DEBUG - 2011-07-05 21:09:07 --> Model Class Initialized
DEBUG - 2011-07-05 21:09:07 --> Model Class Initialized
DEBUG - 2011-07-05 21:09:07 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-05 21:09:07 --> Database Driver Class Initialized
DEBUG - 2011-07-05 21:09:08 --> Config Class Initialized
DEBUG - 2011-07-05 21:09:08 --> Hooks Class Initialized
DEBUG - 2011-07-05 21:09:08 --> Utf8 Class Initialized
DEBUG - 2011-07-05 21:09:08 --> UTF-8 Support Enabled
DEBUG - 2011-07-05 21:09:08 --> URI Class Initialized
DEBUG - 2011-07-05 21:09:08 --> Router Class Initialized
DEBUG - 2011-07-05 21:09:08 --> Output Class Initialized
DEBUG - 2011-07-05 21:09:08 --> Input Class Initialized
DEBUG - 2011-07-05 21:09:08 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-05 21:09:08 --> Language Class Initialized
DEBUG - 2011-07-05 21:09:08 --> Loader Class Initialized
DEBUG - 2011-07-05 21:09:08 --> Controller Class Initialized
ERROR - 2011-07-05 21:09:08 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-05 21:09:08 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-05 21:09:08 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-05 21:09:08 --> Model Class Initialized
DEBUG - 2011-07-05 21:09:08 --> Model Class Initialized
DEBUG - 2011-07-05 21:09:08 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-05 21:09:08 --> Database Driver Class Initialized
DEBUG - 2011-07-05 21:09:08 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-05 21:09:09 --> Helper loaded: url_helper
DEBUG - 2011-07-05 21:09:09 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-05 21:09:09 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-05 21:09:09 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-05 21:09:09 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-05 21:09:09 --> Final output sent to browser
DEBUG - 2011-07-05 21:09:09 --> Total execution time: 0.5193
DEBUG - 2011-07-05 21:09:09 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-05 21:09:09 --> Helper loaded: url_helper
DEBUG - 2011-07-05 21:09:09 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-05 21:09:09 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-05 21:09:09 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-05 21:09:09 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-05 21:09:09 --> Final output sent to browser
DEBUG - 2011-07-05 21:09:09 --> Total execution time: 2.3347
DEBUG - 2011-07-05 21:09:10 --> Config Class Initialized
DEBUG - 2011-07-05 21:09:10 --> Hooks Class Initialized
DEBUG - 2011-07-05 21:09:10 --> Utf8 Class Initialized
DEBUG - 2011-07-05 21:09:10 --> UTF-8 Support Enabled
DEBUG - 2011-07-05 21:09:10 --> URI Class Initialized
DEBUG - 2011-07-05 21:09:10 --> Router Class Initialized
DEBUG - 2011-07-05 21:09:10 --> Output Class Initialized
DEBUG - 2011-07-05 21:09:10 --> Input Class Initialized
DEBUG - 2011-07-05 21:09:10 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-05 21:09:10 --> Language Class Initialized
DEBUG - 2011-07-05 21:09:10 --> Loader Class Initialized
DEBUG - 2011-07-05 21:09:10 --> Controller Class Initialized
DEBUG - 2011-07-05 21:09:10 --> Model Class Initialized
DEBUG - 2011-07-05 21:09:10 --> Model Class Initialized
DEBUG - 2011-07-05 21:09:10 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-05 21:09:10 --> Database Driver Class Initialized
DEBUG - 2011-07-05 21:09:12 --> Final output sent to browser
DEBUG - 2011-07-05 21:09:12 --> Total execution time: 1.7935
DEBUG - 2011-07-05 21:09:14 --> Config Class Initialized
DEBUG - 2011-07-05 21:09:14 --> Hooks Class Initialized
DEBUG - 2011-07-05 21:09:14 --> Utf8 Class Initialized
DEBUG - 2011-07-05 21:09:14 --> UTF-8 Support Enabled
DEBUG - 2011-07-05 21:09:14 --> URI Class Initialized
DEBUG - 2011-07-05 21:09:14 --> Router Class Initialized
ERROR - 2011-07-05 21:09:14 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-05 21:09:15 --> Config Class Initialized
DEBUG - 2011-07-05 21:09:15 --> Hooks Class Initialized
DEBUG - 2011-07-05 21:09:15 --> Utf8 Class Initialized
DEBUG - 2011-07-05 21:09:15 --> UTF-8 Support Enabled
DEBUG - 2011-07-05 21:09:15 --> URI Class Initialized
DEBUG - 2011-07-05 21:09:15 --> Router Class Initialized
ERROR - 2011-07-05 21:09:15 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-05 21:09:19 --> Config Class Initialized
DEBUG - 2011-07-05 21:09:19 --> Hooks Class Initialized
DEBUG - 2011-07-05 21:09:19 --> Utf8 Class Initialized
DEBUG - 2011-07-05 21:09:19 --> UTF-8 Support Enabled
DEBUG - 2011-07-05 21:09:19 --> URI Class Initialized
DEBUG - 2011-07-05 21:09:19 --> Router Class Initialized
DEBUG - 2011-07-05 21:09:19 --> Output Class Initialized
DEBUG - 2011-07-05 21:09:19 --> Input Class Initialized
DEBUG - 2011-07-05 21:09:19 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-05 21:09:19 --> Language Class Initialized
DEBUG - 2011-07-05 21:09:19 --> Loader Class Initialized
DEBUG - 2011-07-05 21:09:19 --> Controller Class Initialized
DEBUG - 2011-07-05 21:09:19 --> Model Class Initialized
DEBUG - 2011-07-05 21:09:19 --> Model Class Initialized
DEBUG - 2011-07-05 21:09:19 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-05 21:09:19 --> Database Driver Class Initialized
DEBUG - 2011-07-05 21:09:20 --> Final output sent to browser
DEBUG - 2011-07-05 21:09:20 --> Total execution time: 0.7094
DEBUG - 2011-07-05 21:09:21 --> Config Class Initialized
DEBUG - 2011-07-05 21:09:21 --> Hooks Class Initialized
DEBUG - 2011-07-05 21:09:21 --> Utf8 Class Initialized
DEBUG - 2011-07-05 21:09:21 --> UTF-8 Support Enabled
DEBUG - 2011-07-05 21:09:21 --> URI Class Initialized
DEBUG - 2011-07-05 21:09:21 --> Router Class Initialized
ERROR - 2011-07-05 21:09:21 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-05 21:09:42 --> Config Class Initialized
DEBUG - 2011-07-05 21:09:42 --> Hooks Class Initialized
DEBUG - 2011-07-05 21:09:42 --> Utf8 Class Initialized
DEBUG - 2011-07-05 21:09:42 --> UTF-8 Support Enabled
DEBUG - 2011-07-05 21:09:42 --> URI Class Initialized
DEBUG - 2011-07-05 21:09:42 --> Router Class Initialized
DEBUG - 2011-07-05 21:09:42 --> Output Class Initialized
DEBUG - 2011-07-05 21:09:42 --> Input Class Initialized
DEBUG - 2011-07-05 21:09:42 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-05 21:09:42 --> Language Class Initialized
DEBUG - 2011-07-05 21:09:42 --> Loader Class Initialized
DEBUG - 2011-07-05 21:09:42 --> Controller Class Initialized
ERROR - 2011-07-05 21:09:42 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-05 21:09:42 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-05 21:09:42 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-05 21:09:42 --> Model Class Initialized
DEBUG - 2011-07-05 21:09:42 --> Model Class Initialized
DEBUG - 2011-07-05 21:09:42 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-05 21:09:42 --> Database Driver Class Initialized
DEBUG - 2011-07-05 21:09:42 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-05 21:09:42 --> Helper loaded: url_helper
DEBUG - 2011-07-05 21:09:42 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-05 21:09:42 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-05 21:09:42 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-05 21:09:42 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-05 21:09:42 --> Final output sent to browser
DEBUG - 2011-07-05 21:09:42 --> Total execution time: 0.0311
DEBUG - 2011-07-05 21:09:43 --> Config Class Initialized
DEBUG - 2011-07-05 21:09:43 --> Hooks Class Initialized
DEBUG - 2011-07-05 21:09:43 --> Utf8 Class Initialized
DEBUG - 2011-07-05 21:09:43 --> UTF-8 Support Enabled
DEBUG - 2011-07-05 21:09:43 --> URI Class Initialized
DEBUG - 2011-07-05 21:09:43 --> Router Class Initialized
DEBUG - 2011-07-05 21:09:43 --> Output Class Initialized
DEBUG - 2011-07-05 21:09:43 --> Input Class Initialized
DEBUG - 2011-07-05 21:09:43 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-05 21:09:43 --> Language Class Initialized
DEBUG - 2011-07-05 21:09:43 --> Loader Class Initialized
DEBUG - 2011-07-05 21:09:43 --> Controller Class Initialized
DEBUG - 2011-07-05 21:09:43 --> Model Class Initialized
DEBUG - 2011-07-05 21:09:43 --> Model Class Initialized
DEBUG - 2011-07-05 21:09:43 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-05 21:09:43 --> Database Driver Class Initialized
DEBUG - 2011-07-05 21:09:44 --> Final output sent to browser
DEBUG - 2011-07-05 21:09:44 --> Total execution time: 0.7533
DEBUG - 2011-07-05 21:09:45 --> Config Class Initialized
DEBUG - 2011-07-05 21:09:45 --> Hooks Class Initialized
DEBUG - 2011-07-05 21:09:45 --> Utf8 Class Initialized
DEBUG - 2011-07-05 21:09:45 --> UTF-8 Support Enabled
DEBUG - 2011-07-05 21:09:45 --> URI Class Initialized
DEBUG - 2011-07-05 21:09:45 --> Router Class Initialized
ERROR - 2011-07-05 21:09:45 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-05 21:09:54 --> Config Class Initialized
DEBUG - 2011-07-05 21:09:54 --> Hooks Class Initialized
DEBUG - 2011-07-05 21:09:54 --> Utf8 Class Initialized
DEBUG - 2011-07-05 21:09:54 --> UTF-8 Support Enabled
DEBUG - 2011-07-05 21:09:54 --> URI Class Initialized
DEBUG - 2011-07-05 21:09:54 --> Router Class Initialized
DEBUG - 2011-07-05 21:09:54 --> Output Class Initialized
DEBUG - 2011-07-05 21:09:54 --> Input Class Initialized
DEBUG - 2011-07-05 21:09:54 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-05 21:09:54 --> Language Class Initialized
DEBUG - 2011-07-05 21:09:54 --> Loader Class Initialized
DEBUG - 2011-07-05 21:09:54 --> Controller Class Initialized
ERROR - 2011-07-05 21:09:54 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-05 21:09:54 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-05 21:09:54 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-05 21:09:54 --> Model Class Initialized
DEBUG - 2011-07-05 21:09:54 --> Model Class Initialized
DEBUG - 2011-07-05 21:09:54 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-05 21:09:54 --> Database Driver Class Initialized
DEBUG - 2011-07-05 21:09:54 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-05 21:09:54 --> Helper loaded: url_helper
DEBUG - 2011-07-05 21:09:54 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-05 21:09:54 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-05 21:09:54 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-05 21:09:54 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-05 21:09:54 --> Final output sent to browser
DEBUG - 2011-07-05 21:09:54 --> Total execution time: 0.0295
DEBUG - 2011-07-05 21:10:01 --> Config Class Initialized
DEBUG - 2011-07-05 21:10:01 --> Hooks Class Initialized
DEBUG - 2011-07-05 21:10:01 --> Utf8 Class Initialized
DEBUG - 2011-07-05 21:10:01 --> UTF-8 Support Enabled
DEBUG - 2011-07-05 21:10:01 --> URI Class Initialized
DEBUG - 2011-07-05 21:10:01 --> Router Class Initialized
DEBUG - 2011-07-05 21:10:01 --> Output Class Initialized
DEBUG - 2011-07-05 21:10:01 --> Input Class Initialized
DEBUG - 2011-07-05 21:10:01 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-05 21:10:01 --> Language Class Initialized
DEBUG - 2011-07-05 21:10:01 --> Loader Class Initialized
DEBUG - 2011-07-05 21:10:01 --> Controller Class Initialized
DEBUG - 2011-07-05 21:10:01 --> Model Class Initialized
DEBUG - 2011-07-05 21:10:01 --> Model Class Initialized
DEBUG - 2011-07-05 21:10:01 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-05 21:10:01 --> Database Driver Class Initialized
DEBUG - 2011-07-05 21:10:02 --> Final output sent to browser
DEBUG - 2011-07-05 21:10:02 --> Total execution time: 0.6146
DEBUG - 2011-07-05 21:10:04 --> Config Class Initialized
DEBUG - 2011-07-05 21:10:04 --> Hooks Class Initialized
DEBUG - 2011-07-05 21:10:04 --> Utf8 Class Initialized
DEBUG - 2011-07-05 21:10:04 --> UTF-8 Support Enabled
DEBUG - 2011-07-05 21:10:04 --> URI Class Initialized
DEBUG - 2011-07-05 21:10:04 --> Router Class Initialized
ERROR - 2011-07-05 21:10:04 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-05 21:10:21 --> Config Class Initialized
DEBUG - 2011-07-05 21:10:21 --> Hooks Class Initialized
DEBUG - 2011-07-05 21:10:21 --> Utf8 Class Initialized
DEBUG - 2011-07-05 21:10:21 --> UTF-8 Support Enabled
DEBUG - 2011-07-05 21:10:21 --> URI Class Initialized
DEBUG - 2011-07-05 21:10:21 --> Router Class Initialized
DEBUG - 2011-07-05 21:10:21 --> Output Class Initialized
DEBUG - 2011-07-05 21:10:21 --> Input Class Initialized
DEBUG - 2011-07-05 21:10:21 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-05 21:10:21 --> Language Class Initialized
DEBUG - 2011-07-05 21:10:21 --> Loader Class Initialized
DEBUG - 2011-07-05 21:10:21 --> Controller Class Initialized
ERROR - 2011-07-05 21:10:21 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-05 21:10:21 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-05 21:10:21 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-05 21:10:21 --> Model Class Initialized
DEBUG - 2011-07-05 21:10:21 --> Model Class Initialized
DEBUG - 2011-07-05 21:10:21 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-05 21:10:21 --> Database Driver Class Initialized
DEBUG - 2011-07-05 21:10:21 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-05 21:10:21 --> Helper loaded: url_helper
DEBUG - 2011-07-05 21:10:21 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-05 21:10:21 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-05 21:10:21 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-05 21:10:21 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-05 21:10:21 --> Final output sent to browser
DEBUG - 2011-07-05 21:10:21 --> Total execution time: 0.0442
DEBUG - 2011-07-05 21:10:22 --> Config Class Initialized
DEBUG - 2011-07-05 21:10:22 --> Hooks Class Initialized
DEBUG - 2011-07-05 21:10:22 --> Utf8 Class Initialized
DEBUG - 2011-07-05 21:10:22 --> UTF-8 Support Enabled
DEBUG - 2011-07-05 21:10:22 --> URI Class Initialized
DEBUG - 2011-07-05 21:10:22 --> Router Class Initialized
DEBUG - 2011-07-05 21:10:22 --> Output Class Initialized
DEBUG - 2011-07-05 21:10:22 --> Input Class Initialized
DEBUG - 2011-07-05 21:10:22 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-05 21:10:22 --> Language Class Initialized
DEBUG - 2011-07-05 21:10:22 --> Loader Class Initialized
DEBUG - 2011-07-05 21:10:22 --> Controller Class Initialized
DEBUG - 2011-07-05 21:10:22 --> Model Class Initialized
DEBUG - 2011-07-05 21:10:22 --> Model Class Initialized
DEBUG - 2011-07-05 21:10:22 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-05 21:10:22 --> Database Driver Class Initialized
DEBUG - 2011-07-05 21:10:23 --> Final output sent to browser
DEBUG - 2011-07-05 21:10:23 --> Total execution time: 0.6091
DEBUG - 2011-07-05 21:10:24 --> Config Class Initialized
DEBUG - 2011-07-05 21:10:24 --> Hooks Class Initialized
DEBUG - 2011-07-05 21:10:24 --> Utf8 Class Initialized
DEBUG - 2011-07-05 21:10:24 --> UTF-8 Support Enabled
DEBUG - 2011-07-05 21:10:24 --> URI Class Initialized
DEBUG - 2011-07-05 21:10:24 --> Router Class Initialized
DEBUG - 2011-07-05 21:10:24 --> Output Class Initialized
DEBUG - 2011-07-05 21:10:24 --> Input Class Initialized
DEBUG - 2011-07-05 21:10:24 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-05 21:10:24 --> Language Class Initialized
DEBUG - 2011-07-05 21:10:24 --> Loader Class Initialized
DEBUG - 2011-07-05 21:10:24 --> Controller Class Initialized
ERROR - 2011-07-05 21:10:24 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-05 21:10:24 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-05 21:10:24 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-05 21:10:24 --> Model Class Initialized
DEBUG - 2011-07-05 21:10:24 --> Model Class Initialized
DEBUG - 2011-07-05 21:10:24 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-05 21:10:24 --> Database Driver Class Initialized
DEBUG - 2011-07-05 21:10:24 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-05 21:10:24 --> Helper loaded: url_helper
DEBUG - 2011-07-05 21:10:24 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-05 21:10:24 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-05 21:10:24 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-05 21:10:24 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-05 21:10:24 --> Final output sent to browser
DEBUG - 2011-07-05 21:10:24 --> Total execution time: 0.0287
DEBUG - 2011-07-05 21:10:24 --> Config Class Initialized
DEBUG - 2011-07-05 21:10:24 --> Hooks Class Initialized
DEBUG - 2011-07-05 21:10:24 --> Utf8 Class Initialized
DEBUG - 2011-07-05 21:10:24 --> UTF-8 Support Enabled
DEBUG - 2011-07-05 21:10:24 --> URI Class Initialized
DEBUG - 2011-07-05 21:10:24 --> Router Class Initialized
ERROR - 2011-07-05 21:10:24 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-05 21:10:26 --> Config Class Initialized
DEBUG - 2011-07-05 21:10:26 --> Hooks Class Initialized
DEBUG - 2011-07-05 21:10:26 --> Utf8 Class Initialized
DEBUG - 2011-07-05 21:10:26 --> UTF-8 Support Enabled
DEBUG - 2011-07-05 21:10:26 --> URI Class Initialized
DEBUG - 2011-07-05 21:10:26 --> Router Class Initialized
DEBUG - 2011-07-05 21:10:26 --> Output Class Initialized
DEBUG - 2011-07-05 21:10:26 --> Input Class Initialized
DEBUG - 2011-07-05 21:10:26 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-05 21:10:26 --> Language Class Initialized
DEBUG - 2011-07-05 21:10:26 --> Loader Class Initialized
DEBUG - 2011-07-05 21:10:26 --> Controller Class Initialized
ERROR - 2011-07-05 21:10:26 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-05 21:10:26 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-05 21:10:26 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-05 21:10:26 --> Model Class Initialized
DEBUG - 2011-07-05 21:10:26 --> Model Class Initialized
DEBUG - 2011-07-05 21:10:26 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-05 21:10:26 --> Database Driver Class Initialized
DEBUG - 2011-07-05 21:10:26 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-05 21:10:26 --> Helper loaded: url_helper
DEBUG - 2011-07-05 21:10:26 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-05 21:10:26 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-05 21:10:26 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-05 21:10:26 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-05 21:10:26 --> Final output sent to browser
DEBUG - 2011-07-05 21:10:26 --> Total execution time: 0.0292
DEBUG - 2011-07-05 21:27:29 --> Config Class Initialized
DEBUG - 2011-07-05 21:27:29 --> Hooks Class Initialized
DEBUG - 2011-07-05 21:27:29 --> Utf8 Class Initialized
DEBUG - 2011-07-05 21:27:29 --> UTF-8 Support Enabled
DEBUG - 2011-07-05 21:27:29 --> URI Class Initialized
DEBUG - 2011-07-05 21:27:29 --> Router Class Initialized
DEBUG - 2011-07-05 21:27:29 --> Output Class Initialized
DEBUG - 2011-07-05 21:27:29 --> Input Class Initialized
DEBUG - 2011-07-05 21:27:29 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-05 21:27:29 --> Language Class Initialized
DEBUG - 2011-07-05 21:27:29 --> Loader Class Initialized
DEBUG - 2011-07-05 21:27:29 --> Controller Class Initialized
DEBUG - 2011-07-05 21:27:29 --> Model Class Initialized
DEBUG - 2011-07-05 21:27:29 --> Model Class Initialized
DEBUG - 2011-07-05 21:27:29 --> Model Class Initialized
DEBUG - 2011-07-05 21:27:29 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-05 21:27:29 --> Database Driver Class Initialized
DEBUG - 2011-07-05 21:27:29 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-05 21:27:29 --> Helper loaded: url_helper
DEBUG - 2011-07-05 21:27:29 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-05 21:27:29 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-05 21:27:29 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-05 21:27:29 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-05 21:27:29 --> Final output sent to browser
DEBUG - 2011-07-05 21:27:29 --> Total execution time: 0.0797
DEBUG - 2011-07-05 21:27:32 --> Config Class Initialized
DEBUG - 2011-07-05 21:27:32 --> Hooks Class Initialized
DEBUG - 2011-07-05 21:27:32 --> Utf8 Class Initialized
DEBUG - 2011-07-05 21:27:32 --> UTF-8 Support Enabled
DEBUG - 2011-07-05 21:27:32 --> URI Class Initialized
DEBUG - 2011-07-05 21:27:32 --> Router Class Initialized
ERROR - 2011-07-05 21:27:32 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-05 21:27:33 --> Config Class Initialized
DEBUG - 2011-07-05 21:27:33 --> Hooks Class Initialized
DEBUG - 2011-07-05 21:27:33 --> Utf8 Class Initialized
DEBUG - 2011-07-05 21:27:33 --> UTF-8 Support Enabled
DEBUG - 2011-07-05 21:27:33 --> URI Class Initialized
DEBUG - 2011-07-05 21:27:33 --> Router Class Initialized
ERROR - 2011-07-05 21:27:33 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-05 21:27:33 --> Config Class Initialized
DEBUG - 2011-07-05 21:27:33 --> Hooks Class Initialized
DEBUG - 2011-07-05 21:27:33 --> Utf8 Class Initialized
DEBUG - 2011-07-05 21:27:33 --> UTF-8 Support Enabled
DEBUG - 2011-07-05 21:27:33 --> URI Class Initialized
DEBUG - 2011-07-05 21:27:33 --> Router Class Initialized
ERROR - 2011-07-05 21:27:33 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-05 21:27:41 --> Config Class Initialized
DEBUG - 2011-07-05 21:27:41 --> Hooks Class Initialized
DEBUG - 2011-07-05 21:27:41 --> Utf8 Class Initialized
DEBUG - 2011-07-05 21:27:41 --> UTF-8 Support Enabled
DEBUG - 2011-07-05 21:27:41 --> URI Class Initialized
DEBUG - 2011-07-05 21:27:41 --> Router Class Initialized
DEBUG - 2011-07-05 21:27:41 --> Output Class Initialized
DEBUG - 2011-07-05 21:27:41 --> Input Class Initialized
DEBUG - 2011-07-05 21:27:41 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-05 21:27:41 --> Language Class Initialized
DEBUG - 2011-07-05 21:27:41 --> Loader Class Initialized
DEBUG - 2011-07-05 21:27:41 --> Controller Class Initialized
ERROR - 2011-07-05 21:27:41 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-05 21:27:41 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-05 21:27:41 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-05 21:27:41 --> Model Class Initialized
DEBUG - 2011-07-05 21:27:41 --> Model Class Initialized
DEBUG - 2011-07-05 21:27:41 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-05 21:27:41 --> Database Driver Class Initialized
DEBUG - 2011-07-05 21:27:41 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-05 21:27:41 --> Helper loaded: url_helper
DEBUG - 2011-07-05 21:27:41 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-05 21:27:41 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-05 21:27:41 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-05 21:27:41 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-05 21:27:41 --> Final output sent to browser
DEBUG - 2011-07-05 21:27:41 --> Total execution time: 0.0288
DEBUG - 2011-07-05 21:27:42 --> Config Class Initialized
DEBUG - 2011-07-05 21:27:42 --> Hooks Class Initialized
DEBUG - 2011-07-05 21:27:42 --> Utf8 Class Initialized
DEBUG - 2011-07-05 21:27:42 --> UTF-8 Support Enabled
DEBUG - 2011-07-05 21:27:42 --> URI Class Initialized
DEBUG - 2011-07-05 21:27:42 --> Router Class Initialized
DEBUG - 2011-07-05 21:27:42 --> Output Class Initialized
DEBUG - 2011-07-05 21:27:42 --> Input Class Initialized
DEBUG - 2011-07-05 21:27:42 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-05 21:27:42 --> Language Class Initialized
DEBUG - 2011-07-05 21:27:42 --> Loader Class Initialized
DEBUG - 2011-07-05 21:27:42 --> Controller Class Initialized
DEBUG - 2011-07-05 21:27:42 --> Model Class Initialized
DEBUG - 2011-07-05 21:27:42 --> Model Class Initialized
DEBUG - 2011-07-05 21:27:42 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-05 21:27:42 --> Database Driver Class Initialized
DEBUG - 2011-07-05 21:27:43 --> Final output sent to browser
DEBUG - 2011-07-05 21:27:43 --> Total execution time: 0.5008
DEBUG - 2011-07-05 22:18:07 --> Config Class Initialized
DEBUG - 2011-07-05 22:18:07 --> Hooks Class Initialized
DEBUG - 2011-07-05 22:18:07 --> Utf8 Class Initialized
DEBUG - 2011-07-05 22:18:07 --> UTF-8 Support Enabled
DEBUG - 2011-07-05 22:18:07 --> URI Class Initialized
DEBUG - 2011-07-05 22:18:07 --> Router Class Initialized
DEBUG - 2011-07-05 22:18:07 --> No URI present. Default controller set.
DEBUG - 2011-07-05 22:18:07 --> Output Class Initialized
DEBUG - 2011-07-05 22:18:07 --> Input Class Initialized
DEBUG - 2011-07-05 22:18:07 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-05 22:18:07 --> Language Class Initialized
DEBUG - 2011-07-05 22:18:07 --> Loader Class Initialized
DEBUG - 2011-07-05 22:18:07 --> Controller Class Initialized
DEBUG - 2011-07-05 22:18:07 --> File loaded: application/views/splash/main.php
DEBUG - 2011-07-05 22:18:07 --> Helper loaded: url_helper
DEBUG - 2011-07-05 22:18:07 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-05 22:18:07 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-05 22:18:07 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-05 22:18:07 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-05 22:18:07 --> Final output sent to browser
DEBUG - 2011-07-05 22:18:07 --> Total execution time: 0.2959

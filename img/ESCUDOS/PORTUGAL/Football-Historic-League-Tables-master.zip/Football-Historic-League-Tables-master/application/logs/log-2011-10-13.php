<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2011-10-13 00:11:38 --> Config Class Initialized
DEBUG - 2011-10-13 00:11:38 --> Hooks Class Initialized
DEBUG - 2011-10-13 00:11:38 --> Utf8 Class Initialized
DEBUG - 2011-10-13 00:11:38 --> UTF-8 Support Enabled
DEBUG - 2011-10-13 00:11:38 --> URI Class Initialized
DEBUG - 2011-10-13 00:11:38 --> Router Class Initialized
DEBUG - 2011-10-13 00:11:38 --> Output Class Initialized
DEBUG - 2011-10-13 00:11:38 --> Input Class Initialized
DEBUG - 2011-10-13 00:11:38 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-13 00:11:38 --> Language Class Initialized
DEBUG - 2011-10-13 00:11:38 --> Loader Class Initialized
DEBUG - 2011-10-13 00:11:38 --> Controller Class Initialized
DEBUG - 2011-10-13 00:11:38 --> Model Class Initialized
DEBUG - 2011-10-13 00:11:38 --> Model Class Initialized
DEBUG - 2011-10-13 00:11:38 --> Model Class Initialized
DEBUG - 2011-10-13 00:11:38 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-13 00:11:38 --> Database Driver Class Initialized
DEBUG - 2011-10-13 00:11:39 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-13 00:11:39 --> Helper loaded: url_helper
DEBUG - 2011-10-13 00:11:39 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-13 00:11:39 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-13 00:11:39 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-13 00:11:39 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-13 00:11:39 --> Final output sent to browser
DEBUG - 2011-10-13 00:11:39 --> Total execution time: 1.3664
DEBUG - 2011-10-13 00:11:40 --> Config Class Initialized
DEBUG - 2011-10-13 00:11:40 --> Hooks Class Initialized
DEBUG - 2011-10-13 00:11:40 --> Utf8 Class Initialized
DEBUG - 2011-10-13 00:11:40 --> UTF-8 Support Enabled
DEBUG - 2011-10-13 00:11:40 --> URI Class Initialized
DEBUG - 2011-10-13 00:11:40 --> Router Class Initialized
DEBUG - 2011-10-13 00:11:40 --> Output Class Initialized
DEBUG - 2011-10-13 00:11:40 --> Input Class Initialized
DEBUG - 2011-10-13 00:11:40 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-13 00:11:40 --> Language Class Initialized
DEBUG - 2011-10-13 00:11:40 --> Loader Class Initialized
DEBUG - 2011-10-13 00:11:40 --> Controller Class Initialized
ERROR - 2011-10-13 00:11:40 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-10-13 00:11:40 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-10-13 00:11:40 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-13 00:11:40 --> Model Class Initialized
DEBUG - 2011-10-13 00:11:40 --> Model Class Initialized
DEBUG - 2011-10-13 00:11:40 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-13 00:11:40 --> Database Driver Class Initialized
DEBUG - 2011-10-13 00:11:40 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-13 00:11:40 --> Helper loaded: url_helper
DEBUG - 2011-10-13 00:11:40 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-13 00:11:40 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-13 00:11:40 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-13 00:11:40 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-13 00:11:40 --> Final output sent to browser
DEBUG - 2011-10-13 00:11:40 --> Total execution time: 0.0783
DEBUG - 2011-10-13 05:12:40 --> Config Class Initialized
DEBUG - 2011-10-13 05:12:40 --> Hooks Class Initialized
DEBUG - 2011-10-13 05:12:40 --> Utf8 Class Initialized
DEBUG - 2011-10-13 05:12:40 --> UTF-8 Support Enabled
DEBUG - 2011-10-13 05:12:40 --> URI Class Initialized
DEBUG - 2011-10-13 05:12:40 --> Router Class Initialized
DEBUG - 2011-10-13 05:12:40 --> Output Class Initialized
DEBUG - 2011-10-13 05:12:40 --> Input Class Initialized
DEBUG - 2011-10-13 05:12:40 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-13 05:12:40 --> Language Class Initialized
DEBUG - 2011-10-13 05:12:40 --> Loader Class Initialized
DEBUG - 2011-10-13 05:12:40 --> Controller Class Initialized
DEBUG - 2011-10-13 05:12:40 --> Model Class Initialized
DEBUG - 2011-10-13 05:12:40 --> Model Class Initialized
DEBUG - 2011-10-13 05:12:40 --> Model Class Initialized
DEBUG - 2011-10-13 05:12:40 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-13 05:12:40 --> Database Driver Class Initialized
DEBUG - 2011-10-13 05:12:41 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-13 05:12:41 --> Helper loaded: url_helper
DEBUG - 2011-10-13 05:12:41 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-13 05:12:41 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-13 05:12:41 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-13 05:12:41 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-13 05:12:41 --> Final output sent to browser
DEBUG - 2011-10-13 05:12:41 --> Total execution time: 1.1753
DEBUG - 2011-10-13 05:12:44 --> Config Class Initialized
DEBUG - 2011-10-13 05:12:44 --> Hooks Class Initialized
DEBUG - 2011-10-13 05:12:44 --> Utf8 Class Initialized
DEBUG - 2011-10-13 05:12:44 --> UTF-8 Support Enabled
DEBUG - 2011-10-13 05:12:44 --> URI Class Initialized
DEBUG - 2011-10-13 05:12:44 --> Router Class Initialized
ERROR - 2011-10-13 05:12:44 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-13 05:12:45 --> Config Class Initialized
DEBUG - 2011-10-13 05:12:45 --> Hooks Class Initialized
DEBUG - 2011-10-13 05:12:45 --> Utf8 Class Initialized
DEBUG - 2011-10-13 05:12:45 --> UTF-8 Support Enabled
DEBUG - 2011-10-13 05:12:45 --> URI Class Initialized
DEBUG - 2011-10-13 05:12:45 --> Router Class Initialized
ERROR - 2011-10-13 05:12:45 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-13 05:12:47 --> Config Class Initialized
DEBUG - 2011-10-13 05:12:47 --> Hooks Class Initialized
DEBUG - 2011-10-13 05:12:47 --> Utf8 Class Initialized
DEBUG - 2011-10-13 05:12:47 --> UTF-8 Support Enabled
DEBUG - 2011-10-13 05:12:47 --> URI Class Initialized
DEBUG - 2011-10-13 05:12:47 --> Router Class Initialized
DEBUG - 2011-10-13 05:12:47 --> Output Class Initialized
DEBUG - 2011-10-13 05:12:47 --> Input Class Initialized
DEBUG - 2011-10-13 05:12:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-13 05:12:47 --> Language Class Initialized
DEBUG - 2011-10-13 05:12:47 --> Loader Class Initialized
DEBUG - 2011-10-13 05:12:47 --> Controller Class Initialized
ERROR - 2011-10-13 05:12:47 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-10-13 05:12:47 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-10-13 05:12:47 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-13 05:12:47 --> Model Class Initialized
DEBUG - 2011-10-13 05:12:47 --> Model Class Initialized
DEBUG - 2011-10-13 05:12:47 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-13 05:12:47 --> Database Driver Class Initialized
DEBUG - 2011-10-13 05:12:47 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-13 05:12:47 --> Helper loaded: url_helper
DEBUG - 2011-10-13 05:12:47 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-13 05:12:47 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-13 05:12:47 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-13 05:12:47 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-13 05:12:47 --> Final output sent to browser
DEBUG - 2011-10-13 05:12:47 --> Total execution time: 0.0812
DEBUG - 2011-10-13 05:12:49 --> Config Class Initialized
DEBUG - 2011-10-13 05:12:49 --> Hooks Class Initialized
DEBUG - 2011-10-13 05:12:49 --> Utf8 Class Initialized
DEBUG - 2011-10-13 05:12:49 --> UTF-8 Support Enabled
DEBUG - 2011-10-13 05:12:49 --> URI Class Initialized
DEBUG - 2011-10-13 05:12:49 --> Router Class Initialized
DEBUG - 2011-10-13 05:12:49 --> Output Class Initialized
DEBUG - 2011-10-13 05:12:49 --> Input Class Initialized
DEBUG - 2011-10-13 05:12:49 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-13 05:12:49 --> Language Class Initialized
DEBUG - 2011-10-13 05:12:49 --> Loader Class Initialized
DEBUG - 2011-10-13 05:12:49 --> Controller Class Initialized
DEBUG - 2011-10-13 05:12:49 --> Model Class Initialized
DEBUG - 2011-10-13 05:12:49 --> Model Class Initialized
DEBUG - 2011-10-13 05:12:49 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-13 05:12:49 --> Database Driver Class Initialized
DEBUG - 2011-10-13 05:12:49 --> Final output sent to browser
DEBUG - 2011-10-13 05:12:49 --> Total execution time: 0.5556
DEBUG - 2011-10-13 05:12:52 --> Config Class Initialized
DEBUG - 2011-10-13 05:12:52 --> Hooks Class Initialized
DEBUG - 2011-10-13 05:12:52 --> Utf8 Class Initialized
DEBUG - 2011-10-13 05:12:52 --> UTF-8 Support Enabled
DEBUG - 2011-10-13 05:12:52 --> URI Class Initialized
DEBUG - 2011-10-13 05:12:52 --> Router Class Initialized
DEBUG - 2011-10-13 05:12:52 --> Output Class Initialized
DEBUG - 2011-10-13 05:12:52 --> Input Class Initialized
DEBUG - 2011-10-13 05:12:52 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-13 05:12:52 --> Language Class Initialized
DEBUG - 2011-10-13 05:12:52 --> Loader Class Initialized
DEBUG - 2011-10-13 05:12:52 --> Controller Class Initialized
ERROR - 2011-10-13 05:12:52 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-10-13 05:12:52 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-10-13 05:12:52 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-13 05:12:52 --> Model Class Initialized
DEBUG - 2011-10-13 05:12:52 --> Model Class Initialized
DEBUG - 2011-10-13 05:12:52 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-13 05:12:52 --> Database Driver Class Initialized
DEBUG - 2011-10-13 05:12:52 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-13 05:12:52 --> Helper loaded: url_helper
DEBUG - 2011-10-13 05:12:52 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-13 05:12:52 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-13 05:12:52 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-13 05:12:52 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-13 05:12:52 --> Final output sent to browser
DEBUG - 2011-10-13 05:12:52 --> Total execution time: 0.0316
DEBUG - 2011-10-13 05:12:53 --> Config Class Initialized
DEBUG - 2011-10-13 05:12:53 --> Hooks Class Initialized
DEBUG - 2011-10-13 05:12:53 --> Utf8 Class Initialized
DEBUG - 2011-10-13 05:12:53 --> UTF-8 Support Enabled
DEBUG - 2011-10-13 05:12:53 --> URI Class Initialized
DEBUG - 2011-10-13 05:12:53 --> Router Class Initialized
DEBUG - 2011-10-13 05:12:53 --> Output Class Initialized
DEBUG - 2011-10-13 05:12:53 --> Input Class Initialized
DEBUG - 2011-10-13 05:12:53 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-13 05:12:53 --> Language Class Initialized
DEBUG - 2011-10-13 05:12:53 --> Loader Class Initialized
DEBUG - 2011-10-13 05:12:53 --> Controller Class Initialized
DEBUG - 2011-10-13 05:12:53 --> Model Class Initialized
DEBUG - 2011-10-13 05:12:53 --> Model Class Initialized
DEBUG - 2011-10-13 05:12:53 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-13 05:12:53 --> Database Driver Class Initialized
DEBUG - 2011-10-13 05:12:53 --> Final output sent to browser
DEBUG - 2011-10-13 05:12:53 --> Total execution time: 0.6487
DEBUG - 2011-10-13 05:39:23 --> Config Class Initialized
DEBUG - 2011-10-13 05:39:23 --> Hooks Class Initialized
DEBUG - 2011-10-13 05:39:23 --> Utf8 Class Initialized
DEBUG - 2011-10-13 05:39:23 --> UTF-8 Support Enabled
DEBUG - 2011-10-13 05:39:23 --> URI Class Initialized
DEBUG - 2011-10-13 05:39:23 --> Router Class Initialized
DEBUG - 2011-10-13 05:39:23 --> Output Class Initialized
DEBUG - 2011-10-13 05:39:23 --> Input Class Initialized
DEBUG - 2011-10-13 05:39:23 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-13 05:39:23 --> Language Class Initialized
DEBUG - 2011-10-13 05:39:23 --> Loader Class Initialized
DEBUG - 2011-10-13 05:39:23 --> Controller Class Initialized
ERROR - 2011-10-13 05:39:23 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-10-13 05:39:23 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-10-13 05:39:23 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-13 05:39:23 --> Model Class Initialized
DEBUG - 2011-10-13 05:39:23 --> Model Class Initialized
DEBUG - 2011-10-13 05:39:23 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-13 05:39:23 --> Database Driver Class Initialized
DEBUG - 2011-10-13 05:39:23 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-13 05:39:23 --> Helper loaded: url_helper
DEBUG - 2011-10-13 05:39:23 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-13 05:39:23 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-13 05:39:23 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-13 05:39:23 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-13 05:39:23 --> Final output sent to browser
DEBUG - 2011-10-13 05:39:23 --> Total execution time: 0.0442
DEBUG - 2011-10-13 05:39:24 --> Config Class Initialized
DEBUG - 2011-10-13 05:39:24 --> Hooks Class Initialized
DEBUG - 2011-10-13 05:39:24 --> Utf8 Class Initialized
DEBUG - 2011-10-13 05:39:24 --> UTF-8 Support Enabled
DEBUG - 2011-10-13 05:39:24 --> URI Class Initialized
DEBUG - 2011-10-13 05:39:24 --> Router Class Initialized
DEBUG - 2011-10-13 05:39:24 --> Output Class Initialized
DEBUG - 2011-10-13 05:39:24 --> Input Class Initialized
DEBUG - 2011-10-13 05:39:24 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-13 05:39:24 --> Language Class Initialized
DEBUG - 2011-10-13 05:39:24 --> Loader Class Initialized
DEBUG - 2011-10-13 05:39:24 --> Controller Class Initialized
DEBUG - 2011-10-13 05:39:24 --> Model Class Initialized
DEBUG - 2011-10-13 05:39:24 --> Model Class Initialized
DEBUG - 2011-10-13 05:39:24 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-13 05:39:24 --> Database Driver Class Initialized
DEBUG - 2011-10-13 05:39:25 --> Final output sent to browser
DEBUG - 2011-10-13 05:39:25 --> Total execution time: 0.6091
DEBUG - 2011-10-13 05:39:27 --> Config Class Initialized
DEBUG - 2011-10-13 05:39:27 --> Hooks Class Initialized
DEBUG - 2011-10-13 05:39:27 --> Utf8 Class Initialized
DEBUG - 2011-10-13 05:39:27 --> UTF-8 Support Enabled
DEBUG - 2011-10-13 05:39:27 --> URI Class Initialized
DEBUG - 2011-10-13 05:39:27 --> Router Class Initialized
ERROR - 2011-10-13 05:39:27 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-13 05:40:00 --> Config Class Initialized
DEBUG - 2011-10-13 05:40:00 --> Hooks Class Initialized
DEBUG - 2011-10-13 05:40:00 --> Utf8 Class Initialized
DEBUG - 2011-10-13 05:40:00 --> UTF-8 Support Enabled
DEBUG - 2011-10-13 05:40:00 --> URI Class Initialized
DEBUG - 2011-10-13 05:40:00 --> Router Class Initialized
DEBUG - 2011-10-13 05:40:00 --> Output Class Initialized
DEBUG - 2011-10-13 05:40:00 --> Input Class Initialized
DEBUG - 2011-10-13 05:40:00 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-13 05:40:00 --> Language Class Initialized
DEBUG - 2011-10-13 05:40:00 --> Loader Class Initialized
DEBUG - 2011-10-13 05:40:00 --> Controller Class Initialized
ERROR - 2011-10-13 05:40:00 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-10-13 05:40:00 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-10-13 05:40:00 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-13 05:40:00 --> Model Class Initialized
DEBUG - 2011-10-13 05:40:00 --> Model Class Initialized
DEBUG - 2011-10-13 05:40:00 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-13 05:40:00 --> Database Driver Class Initialized
DEBUG - 2011-10-13 05:40:00 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-13 05:40:00 --> Helper loaded: url_helper
DEBUG - 2011-10-13 05:40:00 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-13 05:40:00 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-13 05:40:00 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-13 05:40:00 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-13 05:40:00 --> Final output sent to browser
DEBUG - 2011-10-13 05:40:00 --> Total execution time: 0.0514
DEBUG - 2011-10-13 05:40:02 --> Config Class Initialized
DEBUG - 2011-10-13 05:40:02 --> Hooks Class Initialized
DEBUG - 2011-10-13 05:40:02 --> Utf8 Class Initialized
DEBUG - 2011-10-13 05:40:02 --> UTF-8 Support Enabled
DEBUG - 2011-10-13 05:40:02 --> URI Class Initialized
DEBUG - 2011-10-13 05:40:02 --> Router Class Initialized
DEBUG - 2011-10-13 05:40:02 --> Output Class Initialized
DEBUG - 2011-10-13 05:40:02 --> Input Class Initialized
DEBUG - 2011-10-13 05:40:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-13 05:40:02 --> Language Class Initialized
DEBUG - 2011-10-13 05:40:02 --> Loader Class Initialized
DEBUG - 2011-10-13 05:40:02 --> Controller Class Initialized
DEBUG - 2011-10-13 05:40:02 --> Model Class Initialized
DEBUG - 2011-10-13 05:40:02 --> Model Class Initialized
DEBUG - 2011-10-13 05:40:02 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-13 05:40:02 --> Database Driver Class Initialized
DEBUG - 2011-10-13 05:40:03 --> Final output sent to browser
DEBUG - 2011-10-13 05:40:03 --> Total execution time: 1.4955
DEBUG - 2011-10-13 05:40:35 --> Config Class Initialized
DEBUG - 2011-10-13 05:40:35 --> Hooks Class Initialized
DEBUG - 2011-10-13 05:40:35 --> Utf8 Class Initialized
DEBUG - 2011-10-13 05:40:35 --> UTF-8 Support Enabled
DEBUG - 2011-10-13 05:40:35 --> URI Class Initialized
DEBUG - 2011-10-13 05:40:35 --> Router Class Initialized
DEBUG - 2011-10-13 05:40:35 --> Output Class Initialized
DEBUG - 2011-10-13 05:40:35 --> Input Class Initialized
DEBUG - 2011-10-13 05:40:35 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-13 05:40:35 --> Language Class Initialized
DEBUG - 2011-10-13 05:40:35 --> Loader Class Initialized
DEBUG - 2011-10-13 05:40:35 --> Controller Class Initialized
ERROR - 2011-10-13 05:40:35 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-10-13 05:40:35 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-10-13 05:40:35 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-13 05:40:35 --> Model Class Initialized
DEBUG - 2011-10-13 05:40:35 --> Model Class Initialized
DEBUG - 2011-10-13 05:40:35 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-13 05:40:35 --> Database Driver Class Initialized
DEBUG - 2011-10-13 05:40:35 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-13 05:40:35 --> Helper loaded: url_helper
DEBUG - 2011-10-13 05:40:35 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-13 05:40:35 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-13 05:40:35 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-13 05:40:35 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-13 05:40:35 --> Final output sent to browser
DEBUG - 2011-10-13 05:40:35 --> Total execution time: 0.0484
DEBUG - 2011-10-13 05:40:36 --> Config Class Initialized
DEBUG - 2011-10-13 05:40:36 --> Hooks Class Initialized
DEBUG - 2011-10-13 05:40:36 --> Utf8 Class Initialized
DEBUG - 2011-10-13 05:40:36 --> UTF-8 Support Enabled
DEBUG - 2011-10-13 05:40:36 --> URI Class Initialized
DEBUG - 2011-10-13 05:40:36 --> Router Class Initialized
DEBUG - 2011-10-13 05:40:36 --> Output Class Initialized
DEBUG - 2011-10-13 05:40:36 --> Input Class Initialized
DEBUG - 2011-10-13 05:40:36 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-13 05:40:36 --> Language Class Initialized
DEBUG - 2011-10-13 05:40:36 --> Loader Class Initialized
DEBUG - 2011-10-13 05:40:36 --> Controller Class Initialized
DEBUG - 2011-10-13 05:40:36 --> Model Class Initialized
DEBUG - 2011-10-13 05:40:36 --> Model Class Initialized
DEBUG - 2011-10-13 05:40:36 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-13 05:40:36 --> Database Driver Class Initialized
DEBUG - 2011-10-13 05:40:36 --> Final output sent to browser
DEBUG - 2011-10-13 05:40:36 --> Total execution time: 0.6775
DEBUG - 2011-10-13 05:40:52 --> Config Class Initialized
DEBUG - 2011-10-13 05:40:52 --> Hooks Class Initialized
DEBUG - 2011-10-13 05:40:52 --> Utf8 Class Initialized
DEBUG - 2011-10-13 05:40:52 --> UTF-8 Support Enabled
DEBUG - 2011-10-13 05:40:52 --> URI Class Initialized
DEBUG - 2011-10-13 05:40:52 --> Router Class Initialized
DEBUG - 2011-10-13 05:40:52 --> Output Class Initialized
DEBUG - 2011-10-13 05:40:52 --> Input Class Initialized
DEBUG - 2011-10-13 05:40:52 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-13 05:40:52 --> Language Class Initialized
DEBUG - 2011-10-13 05:40:52 --> Loader Class Initialized
DEBUG - 2011-10-13 05:40:52 --> Controller Class Initialized
ERROR - 2011-10-13 05:40:52 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-10-13 05:40:52 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-10-13 05:40:52 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-13 05:40:52 --> Model Class Initialized
DEBUG - 2011-10-13 05:40:52 --> Model Class Initialized
DEBUG - 2011-10-13 05:40:52 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-13 05:40:52 --> Database Driver Class Initialized
DEBUG - 2011-10-13 05:40:52 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-13 05:40:52 --> Helper loaded: url_helper
DEBUG - 2011-10-13 05:40:52 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-13 05:40:52 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-13 05:40:52 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-13 05:40:52 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-13 05:40:52 --> Final output sent to browser
DEBUG - 2011-10-13 05:40:52 --> Total execution time: 0.0888
DEBUG - 2011-10-13 05:40:53 --> Config Class Initialized
DEBUG - 2011-10-13 05:40:53 --> Hooks Class Initialized
DEBUG - 2011-10-13 05:40:53 --> Utf8 Class Initialized
DEBUG - 2011-10-13 05:40:53 --> UTF-8 Support Enabled
DEBUG - 2011-10-13 05:40:53 --> URI Class Initialized
DEBUG - 2011-10-13 05:40:53 --> Router Class Initialized
DEBUG - 2011-10-13 05:40:53 --> Output Class Initialized
DEBUG - 2011-10-13 05:40:53 --> Input Class Initialized
DEBUG - 2011-10-13 05:40:53 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-13 05:40:53 --> Language Class Initialized
DEBUG - 2011-10-13 05:40:53 --> Loader Class Initialized
DEBUG - 2011-10-13 05:40:53 --> Controller Class Initialized
DEBUG - 2011-10-13 05:40:53 --> Model Class Initialized
DEBUG - 2011-10-13 05:40:53 --> Model Class Initialized
DEBUG - 2011-10-13 05:40:53 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-13 05:40:53 --> Database Driver Class Initialized
DEBUG - 2011-10-13 05:40:53 --> Final output sent to browser
DEBUG - 2011-10-13 05:40:53 --> Total execution time: 0.4658
DEBUG - 2011-10-13 05:41:33 --> Config Class Initialized
DEBUG - 2011-10-13 05:41:33 --> Hooks Class Initialized
DEBUG - 2011-10-13 05:41:33 --> Utf8 Class Initialized
DEBUG - 2011-10-13 05:41:33 --> UTF-8 Support Enabled
DEBUG - 2011-10-13 05:41:33 --> URI Class Initialized
DEBUG - 2011-10-13 05:41:33 --> Router Class Initialized
DEBUG - 2011-10-13 05:41:33 --> Output Class Initialized
DEBUG - 2011-10-13 05:41:33 --> Input Class Initialized
DEBUG - 2011-10-13 05:41:33 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-13 05:41:33 --> Language Class Initialized
DEBUG - 2011-10-13 05:41:33 --> Loader Class Initialized
DEBUG - 2011-10-13 05:41:33 --> Controller Class Initialized
ERROR - 2011-10-13 05:41:33 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-10-13 05:41:33 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-10-13 05:41:33 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-13 05:41:33 --> Model Class Initialized
DEBUG - 2011-10-13 05:41:33 --> Model Class Initialized
DEBUG - 2011-10-13 05:41:33 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-13 05:41:33 --> Database Driver Class Initialized
DEBUG - 2011-10-13 05:41:33 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-13 05:41:33 --> Helper loaded: url_helper
DEBUG - 2011-10-13 05:41:33 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-13 05:41:33 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-13 05:41:33 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-13 05:41:33 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-13 05:41:33 --> Final output sent to browser
DEBUG - 2011-10-13 05:41:33 --> Total execution time: 0.0324
DEBUG - 2011-10-13 05:41:33 --> Config Class Initialized
DEBUG - 2011-10-13 05:41:33 --> Hooks Class Initialized
DEBUG - 2011-10-13 05:41:33 --> Utf8 Class Initialized
DEBUG - 2011-10-13 05:41:33 --> UTF-8 Support Enabled
DEBUG - 2011-10-13 05:41:33 --> URI Class Initialized
DEBUG - 2011-10-13 05:41:33 --> Router Class Initialized
DEBUG - 2011-10-13 05:41:33 --> Output Class Initialized
DEBUG - 2011-10-13 05:41:33 --> Input Class Initialized
DEBUG - 2011-10-13 05:41:33 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-13 05:41:33 --> Language Class Initialized
DEBUG - 2011-10-13 05:41:33 --> Loader Class Initialized
DEBUG - 2011-10-13 05:41:33 --> Controller Class Initialized
DEBUG - 2011-10-13 05:41:33 --> Model Class Initialized
DEBUG - 2011-10-13 05:41:33 --> Model Class Initialized
DEBUG - 2011-10-13 05:41:33 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-13 05:41:33 --> Database Driver Class Initialized
DEBUG - 2011-10-13 05:41:34 --> Final output sent to browser
DEBUG - 2011-10-13 05:41:34 --> Total execution time: 0.6288
DEBUG - 2011-10-13 06:36:27 --> Config Class Initialized
DEBUG - 2011-10-13 06:36:27 --> Hooks Class Initialized
DEBUG - 2011-10-13 06:36:27 --> Utf8 Class Initialized
DEBUG - 2011-10-13 06:36:27 --> UTF-8 Support Enabled
DEBUG - 2011-10-13 06:36:27 --> URI Class Initialized
DEBUG - 2011-10-13 06:36:27 --> Router Class Initialized
DEBUG - 2011-10-13 06:36:27 --> No URI present. Default controller set.
DEBUG - 2011-10-13 06:36:27 --> Output Class Initialized
DEBUG - 2011-10-13 06:36:28 --> Input Class Initialized
DEBUG - 2011-10-13 06:36:28 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-13 06:36:28 --> Language Class Initialized
DEBUG - 2011-10-13 06:36:28 --> Loader Class Initialized
DEBUG - 2011-10-13 06:36:28 --> Controller Class Initialized
DEBUG - 2011-10-13 06:36:28 --> File loaded: application/views/splash/main.php
DEBUG - 2011-10-13 06:36:28 --> Helper loaded: url_helper
DEBUG - 2011-10-13 06:36:28 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-13 06:36:28 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-13 06:36:28 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-13 06:36:28 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-13 06:36:28 --> Final output sent to browser
DEBUG - 2011-10-13 06:36:28 --> Total execution time: 0.2328
DEBUG - 2011-10-13 06:44:15 --> Config Class Initialized
DEBUG - 2011-10-13 06:44:15 --> Hooks Class Initialized
DEBUG - 2011-10-13 06:44:15 --> Utf8 Class Initialized
DEBUG - 2011-10-13 06:44:15 --> UTF-8 Support Enabled
DEBUG - 2011-10-13 06:44:15 --> URI Class Initialized
DEBUG - 2011-10-13 06:44:15 --> Router Class Initialized
ERROR - 2011-10-13 06:44:15 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-10-13 06:44:15 --> Config Class Initialized
DEBUG - 2011-10-13 06:44:15 --> Hooks Class Initialized
DEBUG - 2011-10-13 06:44:15 --> Utf8 Class Initialized
DEBUG - 2011-10-13 06:44:15 --> UTF-8 Support Enabled
DEBUG - 2011-10-13 06:44:15 --> URI Class Initialized
DEBUG - 2011-10-13 06:44:15 --> Router Class Initialized
DEBUG - 2011-10-13 06:44:15 --> Output Class Initialized
DEBUG - 2011-10-13 06:44:15 --> Input Class Initialized
DEBUG - 2011-10-13 06:44:15 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-13 06:44:15 --> Language Class Initialized
DEBUG - 2011-10-13 06:44:15 --> Loader Class Initialized
DEBUG - 2011-10-13 06:44:15 --> Controller Class Initialized
ERROR - 2011-10-13 06:44:15 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-10-13 06:44:15 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-10-13 06:44:15 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-13 06:44:15 --> Model Class Initialized
DEBUG - 2011-10-13 06:44:15 --> Model Class Initialized
DEBUG - 2011-10-13 06:44:15 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-13 06:44:15 --> Database Driver Class Initialized
DEBUG - 2011-10-13 06:44:16 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-13 06:44:17 --> Helper loaded: url_helper
DEBUG - 2011-10-13 06:44:17 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-13 06:44:17 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-13 06:44:17 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-13 06:44:17 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-13 06:44:17 --> Final output sent to browser
DEBUG - 2011-10-13 06:44:17 --> Total execution time: 1.4926
DEBUG - 2011-10-13 07:01:06 --> Config Class Initialized
DEBUG - 2011-10-13 07:01:06 --> Hooks Class Initialized
DEBUG - 2011-10-13 07:01:06 --> Utf8 Class Initialized
DEBUG - 2011-10-13 07:01:06 --> UTF-8 Support Enabled
DEBUG - 2011-10-13 07:01:06 --> URI Class Initialized
DEBUG - 2011-10-13 07:01:06 --> Router Class Initialized
DEBUG - 2011-10-13 07:01:06 --> Output Class Initialized
DEBUG - 2011-10-13 07:01:06 --> Input Class Initialized
DEBUG - 2011-10-13 07:01:06 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-13 07:01:06 --> Language Class Initialized
DEBUG - 2011-10-13 07:01:06 --> Loader Class Initialized
DEBUG - 2011-10-13 07:01:06 --> Controller Class Initialized
DEBUG - 2011-10-13 07:01:06 --> Model Class Initialized
DEBUG - 2011-10-13 07:01:06 --> Model Class Initialized
DEBUG - 2011-10-13 07:01:06 --> Model Class Initialized
DEBUG - 2011-10-13 07:01:06 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-13 07:01:06 --> Database Driver Class Initialized
DEBUG - 2011-10-13 07:01:07 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-13 07:01:07 --> Helper loaded: url_helper
DEBUG - 2011-10-13 07:01:07 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-13 07:01:07 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-13 07:01:07 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-13 07:01:07 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-13 07:01:07 --> Final output sent to browser
DEBUG - 2011-10-13 07:01:07 --> Total execution time: 0.7742
DEBUG - 2011-10-13 07:01:09 --> Config Class Initialized
DEBUG - 2011-10-13 07:01:09 --> Hooks Class Initialized
DEBUG - 2011-10-13 07:01:09 --> Utf8 Class Initialized
DEBUG - 2011-10-13 07:01:09 --> UTF-8 Support Enabled
DEBUG - 2011-10-13 07:01:09 --> URI Class Initialized
DEBUG - 2011-10-13 07:01:09 --> Router Class Initialized
DEBUG - 2011-10-13 07:01:09 --> Output Class Initialized
DEBUG - 2011-10-13 07:01:09 --> Input Class Initialized
DEBUG - 2011-10-13 07:01:09 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-13 07:01:09 --> Language Class Initialized
DEBUG - 2011-10-13 07:01:09 --> Loader Class Initialized
DEBUG - 2011-10-13 07:01:09 --> Controller Class Initialized
ERROR - 2011-10-13 07:01:09 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-10-13 07:01:09 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-10-13 07:01:09 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-13 07:01:09 --> Model Class Initialized
DEBUG - 2011-10-13 07:01:09 --> Model Class Initialized
DEBUG - 2011-10-13 07:01:09 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-13 07:01:09 --> Database Driver Class Initialized
DEBUG - 2011-10-13 07:01:09 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-13 07:01:09 --> Helper loaded: url_helper
DEBUG - 2011-10-13 07:01:09 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-13 07:01:09 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-13 07:01:09 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-13 07:01:09 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-13 07:01:09 --> Final output sent to browser
DEBUG - 2011-10-13 07:01:09 --> Total execution time: 0.0509
DEBUG - 2011-10-13 07:21:48 --> Config Class Initialized
DEBUG - 2011-10-13 07:21:48 --> Hooks Class Initialized
DEBUG - 2011-10-13 07:21:48 --> Utf8 Class Initialized
DEBUG - 2011-10-13 07:21:48 --> UTF-8 Support Enabled
DEBUG - 2011-10-13 07:21:48 --> URI Class Initialized
DEBUG - 2011-10-13 07:21:48 --> Router Class Initialized
ERROR - 2011-10-13 07:21:48 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-10-13 07:21:48 --> Config Class Initialized
DEBUG - 2011-10-13 07:21:48 --> Hooks Class Initialized
DEBUG - 2011-10-13 07:21:48 --> Utf8 Class Initialized
DEBUG - 2011-10-13 07:21:48 --> UTF-8 Support Enabled
DEBUG - 2011-10-13 07:21:48 --> URI Class Initialized
DEBUG - 2011-10-13 07:21:48 --> Router Class Initialized
DEBUG - 2011-10-13 07:21:48 --> Output Class Initialized
DEBUG - 2011-10-13 07:21:48 --> Input Class Initialized
DEBUG - 2011-10-13 07:21:48 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-13 07:21:48 --> Language Class Initialized
DEBUG - 2011-10-13 07:21:48 --> Loader Class Initialized
DEBUG - 2011-10-13 07:21:48 --> Controller Class Initialized
DEBUG - 2011-10-13 07:21:48 --> Model Class Initialized
DEBUG - 2011-10-13 07:21:48 --> Model Class Initialized
DEBUG - 2011-10-13 07:21:48 --> Model Class Initialized
DEBUG - 2011-10-13 07:21:48 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-13 07:21:48 --> Database Driver Class Initialized
DEBUG - 2011-10-13 07:21:49 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-13 07:21:49 --> Helper loaded: url_helper
DEBUG - 2011-10-13 07:21:49 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-13 07:21:49 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-13 07:21:49 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-13 07:21:49 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-13 07:21:49 --> Final output sent to browser
DEBUG - 2011-10-13 07:21:49 --> Total execution time: 0.9284
DEBUG - 2011-10-13 07:32:15 --> Config Class Initialized
DEBUG - 2011-10-13 07:32:15 --> Hooks Class Initialized
DEBUG - 2011-10-13 07:32:15 --> Utf8 Class Initialized
DEBUG - 2011-10-13 07:32:15 --> UTF-8 Support Enabled
DEBUG - 2011-10-13 07:32:15 --> URI Class Initialized
DEBUG - 2011-10-13 07:32:15 --> Router Class Initialized
DEBUG - 2011-10-13 07:32:15 --> No URI present. Default controller set.
DEBUG - 2011-10-13 07:32:15 --> Output Class Initialized
DEBUG - 2011-10-13 07:32:15 --> Input Class Initialized
DEBUG - 2011-10-13 07:32:15 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-13 07:32:15 --> Language Class Initialized
DEBUG - 2011-10-13 07:32:15 --> Loader Class Initialized
DEBUG - 2011-10-13 07:32:15 --> Controller Class Initialized
DEBUG - 2011-10-13 07:32:15 --> File loaded: application/views/splash/main.php
DEBUG - 2011-10-13 07:32:15 --> Helper loaded: url_helper
DEBUG - 2011-10-13 07:32:15 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-13 07:32:15 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-13 07:32:15 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-13 07:32:15 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-13 07:32:15 --> Final output sent to browser
DEBUG - 2011-10-13 07:32:15 --> Total execution time: 0.1044
DEBUG - 2011-10-13 08:00:37 --> Config Class Initialized
DEBUG - 2011-10-13 08:00:37 --> Hooks Class Initialized
DEBUG - 2011-10-13 08:00:37 --> Utf8 Class Initialized
DEBUG - 2011-10-13 08:00:37 --> UTF-8 Support Enabled
DEBUG - 2011-10-13 08:00:37 --> URI Class Initialized
DEBUG - 2011-10-13 08:00:37 --> Router Class Initialized
DEBUG - 2011-10-13 08:00:37 --> Output Class Initialized
DEBUG - 2011-10-13 08:00:37 --> Input Class Initialized
DEBUG - 2011-10-13 08:00:37 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-13 08:00:37 --> Language Class Initialized
DEBUG - 2011-10-13 08:00:37 --> Loader Class Initialized
DEBUG - 2011-10-13 08:00:37 --> Controller Class Initialized
DEBUG - 2011-10-13 08:00:37 --> Model Class Initialized
DEBUG - 2011-10-13 08:00:37 --> Model Class Initialized
DEBUG - 2011-10-13 08:00:37 --> Model Class Initialized
DEBUG - 2011-10-13 08:00:37 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-13 08:00:37 --> Database Driver Class Initialized
DEBUG - 2011-10-13 08:00:39 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-13 08:00:39 --> Helper loaded: url_helper
DEBUG - 2011-10-13 08:00:39 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-13 08:00:39 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-13 08:00:39 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-13 08:00:39 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-13 08:00:39 --> Final output sent to browser
DEBUG - 2011-10-13 08:00:39 --> Total execution time: 2.0986
DEBUG - 2011-10-13 08:00:41 --> Config Class Initialized
DEBUG - 2011-10-13 08:00:41 --> Hooks Class Initialized
DEBUG - 2011-10-13 08:00:41 --> Utf8 Class Initialized
DEBUG - 2011-10-13 08:00:41 --> UTF-8 Support Enabled
DEBUG - 2011-10-13 08:00:41 --> URI Class Initialized
DEBUG - 2011-10-13 08:00:41 --> Router Class Initialized
ERROR - 2011-10-13 08:00:41 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-13 08:00:42 --> Config Class Initialized
DEBUG - 2011-10-13 08:00:42 --> Hooks Class Initialized
DEBUG - 2011-10-13 08:00:42 --> Utf8 Class Initialized
DEBUG - 2011-10-13 08:00:42 --> UTF-8 Support Enabled
DEBUG - 2011-10-13 08:00:42 --> URI Class Initialized
DEBUG - 2011-10-13 08:00:42 --> Router Class Initialized
ERROR - 2011-10-13 08:00:42 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-13 08:00:50 --> Config Class Initialized
DEBUG - 2011-10-13 08:00:50 --> Hooks Class Initialized
DEBUG - 2011-10-13 08:00:50 --> Utf8 Class Initialized
DEBUG - 2011-10-13 08:00:50 --> UTF-8 Support Enabled
DEBUG - 2011-10-13 08:00:50 --> URI Class Initialized
DEBUG - 2011-10-13 08:00:50 --> Router Class Initialized
DEBUG - 2011-10-13 08:00:50 --> Output Class Initialized
DEBUG - 2011-10-13 08:00:50 --> Input Class Initialized
DEBUG - 2011-10-13 08:00:50 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-13 08:00:50 --> Language Class Initialized
DEBUG - 2011-10-13 08:00:50 --> Loader Class Initialized
DEBUG - 2011-10-13 08:00:50 --> Controller Class Initialized
ERROR - 2011-10-13 08:00:50 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-10-13 08:00:50 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-10-13 08:00:50 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-13 08:00:50 --> Model Class Initialized
DEBUG - 2011-10-13 08:00:50 --> Model Class Initialized
DEBUG - 2011-10-13 08:00:50 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-13 08:00:50 --> Database Driver Class Initialized
DEBUG - 2011-10-13 08:00:50 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-13 08:00:50 --> Helper loaded: url_helper
DEBUG - 2011-10-13 08:00:50 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-13 08:00:50 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-13 08:00:50 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-13 08:00:50 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-13 08:00:50 --> Final output sent to browser
DEBUG - 2011-10-13 08:00:50 --> Total execution time: 0.1181
DEBUG - 2011-10-13 08:00:51 --> Config Class Initialized
DEBUG - 2011-10-13 08:00:51 --> Hooks Class Initialized
DEBUG - 2011-10-13 08:00:51 --> Utf8 Class Initialized
DEBUG - 2011-10-13 08:00:51 --> UTF-8 Support Enabled
DEBUG - 2011-10-13 08:00:51 --> URI Class Initialized
DEBUG - 2011-10-13 08:00:51 --> Router Class Initialized
DEBUG - 2011-10-13 08:00:51 --> Output Class Initialized
DEBUG - 2011-10-13 08:00:51 --> Input Class Initialized
DEBUG - 2011-10-13 08:00:51 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-13 08:00:51 --> Language Class Initialized
DEBUG - 2011-10-13 08:00:51 --> Loader Class Initialized
DEBUG - 2011-10-13 08:00:51 --> Controller Class Initialized
DEBUG - 2011-10-13 08:00:51 --> Model Class Initialized
DEBUG - 2011-10-13 08:00:51 --> Model Class Initialized
DEBUG - 2011-10-13 08:00:51 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-13 08:00:51 --> Database Driver Class Initialized
DEBUG - 2011-10-13 08:00:52 --> Final output sent to browser
DEBUG - 2011-10-13 08:00:52 --> Total execution time: 0.6037
DEBUG - 2011-10-13 08:03:07 --> Config Class Initialized
DEBUG - 2011-10-13 08:03:07 --> Hooks Class Initialized
DEBUG - 2011-10-13 08:03:07 --> Utf8 Class Initialized
DEBUG - 2011-10-13 08:03:07 --> UTF-8 Support Enabled
DEBUG - 2011-10-13 08:03:07 --> URI Class Initialized
DEBUG - 2011-10-13 08:03:07 --> Router Class Initialized
DEBUG - 2011-10-13 08:03:07 --> Output Class Initialized
DEBUG - 2011-10-13 08:03:07 --> Input Class Initialized
DEBUG - 2011-10-13 08:03:07 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-13 08:03:07 --> Language Class Initialized
DEBUG - 2011-10-13 08:03:07 --> Loader Class Initialized
DEBUG - 2011-10-13 08:03:07 --> Controller Class Initialized
DEBUG - 2011-10-13 08:03:07 --> Model Class Initialized
DEBUG - 2011-10-13 08:03:07 --> Model Class Initialized
DEBUG - 2011-10-13 08:03:07 --> Model Class Initialized
DEBUG - 2011-10-13 08:03:07 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-13 08:03:07 --> Database Driver Class Initialized
DEBUG - 2011-10-13 08:03:08 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-13 08:03:08 --> Helper loaded: url_helper
DEBUG - 2011-10-13 08:03:08 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-13 08:03:08 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-13 08:03:08 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-13 08:03:08 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-13 08:03:08 --> Final output sent to browser
DEBUG - 2011-10-13 08:03:08 --> Total execution time: 0.4199
DEBUG - 2011-10-13 08:03:11 --> Config Class Initialized
DEBUG - 2011-10-13 08:03:11 --> Hooks Class Initialized
DEBUG - 2011-10-13 08:03:11 --> Utf8 Class Initialized
DEBUG - 2011-10-13 08:03:11 --> UTF-8 Support Enabled
DEBUG - 2011-10-13 08:03:11 --> URI Class Initialized
DEBUG - 2011-10-13 08:03:11 --> Router Class Initialized
ERROR - 2011-10-13 08:03:11 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-13 08:03:11 --> Config Class Initialized
DEBUG - 2011-10-13 08:03:11 --> Hooks Class Initialized
DEBUG - 2011-10-13 08:03:11 --> Utf8 Class Initialized
DEBUG - 2011-10-13 08:03:11 --> UTF-8 Support Enabled
DEBUG - 2011-10-13 08:03:11 --> URI Class Initialized
DEBUG - 2011-10-13 08:03:11 --> Router Class Initialized
DEBUG - 2011-10-13 08:03:11 --> Output Class Initialized
DEBUG - 2011-10-13 08:03:11 --> Input Class Initialized
DEBUG - 2011-10-13 08:03:11 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-13 08:03:11 --> Language Class Initialized
DEBUG - 2011-10-13 08:03:11 --> Loader Class Initialized
DEBUG - 2011-10-13 08:03:11 --> Controller Class Initialized
DEBUG - 2011-10-13 08:03:11 --> Model Class Initialized
DEBUG - 2011-10-13 08:03:11 --> Model Class Initialized
DEBUG - 2011-10-13 08:03:11 --> Model Class Initialized
DEBUG - 2011-10-13 08:03:11 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-13 08:03:11 --> Database Driver Class Initialized
DEBUG - 2011-10-13 08:03:11 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-13 08:03:11 --> Helper loaded: url_helper
DEBUG - 2011-10-13 08:03:11 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-13 08:03:11 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-13 08:03:11 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-13 08:03:11 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-13 08:03:11 --> Final output sent to browser
DEBUG - 2011-10-13 08:03:11 --> Total execution time: 0.0451
DEBUG - 2011-10-13 08:03:13 --> Config Class Initialized
DEBUG - 2011-10-13 08:03:13 --> Hooks Class Initialized
DEBUG - 2011-10-13 08:03:13 --> Utf8 Class Initialized
DEBUG - 2011-10-13 08:03:13 --> UTF-8 Support Enabled
DEBUG - 2011-10-13 08:03:13 --> URI Class Initialized
DEBUG - 2011-10-13 08:03:13 --> Router Class Initialized
ERROR - 2011-10-13 08:03:13 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-13 08:03:30 --> Config Class Initialized
DEBUG - 2011-10-13 08:03:30 --> Hooks Class Initialized
DEBUG - 2011-10-13 08:03:30 --> Utf8 Class Initialized
DEBUG - 2011-10-13 08:03:30 --> UTF-8 Support Enabled
DEBUG - 2011-10-13 08:03:30 --> URI Class Initialized
DEBUG - 2011-10-13 08:03:30 --> Router Class Initialized
DEBUG - 2011-10-13 08:03:30 --> Output Class Initialized
DEBUG - 2011-10-13 08:03:30 --> Input Class Initialized
DEBUG - 2011-10-13 08:03:30 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-13 08:03:30 --> Language Class Initialized
DEBUG - 2011-10-13 08:03:30 --> Loader Class Initialized
DEBUG - 2011-10-13 08:03:30 --> Controller Class Initialized
DEBUG - 2011-10-13 08:03:30 --> Model Class Initialized
DEBUG - 2011-10-13 08:03:30 --> Model Class Initialized
DEBUG - 2011-10-13 08:03:30 --> Model Class Initialized
DEBUG - 2011-10-13 08:03:30 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-13 08:03:30 --> Database Driver Class Initialized
DEBUG - 2011-10-13 08:03:30 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-13 08:03:30 --> Helper loaded: url_helper
DEBUG - 2011-10-13 08:03:30 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-13 08:03:30 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-13 08:03:30 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-13 08:03:30 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-13 08:03:30 --> Final output sent to browser
DEBUG - 2011-10-13 08:03:30 --> Total execution time: 0.3746
DEBUG - 2011-10-13 08:03:32 --> Config Class Initialized
DEBUG - 2011-10-13 08:03:32 --> Hooks Class Initialized
DEBUG - 2011-10-13 08:03:32 --> Utf8 Class Initialized
DEBUG - 2011-10-13 08:03:32 --> UTF-8 Support Enabled
DEBUG - 2011-10-13 08:03:32 --> URI Class Initialized
DEBUG - 2011-10-13 08:03:32 --> Router Class Initialized
DEBUG - 2011-10-13 08:03:32 --> Output Class Initialized
DEBUG - 2011-10-13 08:03:32 --> Input Class Initialized
DEBUG - 2011-10-13 08:03:32 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-13 08:03:32 --> Language Class Initialized
DEBUG - 2011-10-13 08:03:32 --> Loader Class Initialized
DEBUG - 2011-10-13 08:03:32 --> Controller Class Initialized
DEBUG - 2011-10-13 08:03:32 --> Model Class Initialized
DEBUG - 2011-10-13 08:03:32 --> Model Class Initialized
DEBUG - 2011-10-13 08:03:32 --> Model Class Initialized
DEBUG - 2011-10-13 08:03:32 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-13 08:03:32 --> Database Driver Class Initialized
DEBUG - 2011-10-13 08:03:32 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-13 08:03:32 --> Helper loaded: url_helper
DEBUG - 2011-10-13 08:03:32 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-13 08:03:32 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-13 08:03:32 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-13 08:03:32 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-13 08:03:32 --> Final output sent to browser
DEBUG - 2011-10-13 08:03:32 --> Total execution time: 0.0743
DEBUG - 2011-10-13 08:03:38 --> Config Class Initialized
DEBUG - 2011-10-13 08:03:38 --> Hooks Class Initialized
DEBUG - 2011-10-13 08:03:38 --> Utf8 Class Initialized
DEBUG - 2011-10-13 08:03:38 --> UTF-8 Support Enabled
DEBUG - 2011-10-13 08:03:38 --> URI Class Initialized
DEBUG - 2011-10-13 08:03:38 --> Router Class Initialized
DEBUG - 2011-10-13 08:03:38 --> Output Class Initialized
DEBUG - 2011-10-13 08:03:38 --> Input Class Initialized
DEBUG - 2011-10-13 08:03:38 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-13 08:03:38 --> Language Class Initialized
DEBUG - 2011-10-13 08:03:38 --> Loader Class Initialized
DEBUG - 2011-10-13 08:03:39 --> Controller Class Initialized
DEBUG - 2011-10-13 08:03:39 --> Model Class Initialized
DEBUG - 2011-10-13 08:03:39 --> Model Class Initialized
DEBUG - 2011-10-13 08:03:39 --> Model Class Initialized
DEBUG - 2011-10-13 08:03:39 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-13 08:03:39 --> Database Driver Class Initialized
DEBUG - 2011-10-13 08:03:39 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-13 08:03:39 --> Helper loaded: url_helper
DEBUG - 2011-10-13 08:03:39 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-13 08:03:39 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-13 08:03:39 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-13 08:03:39 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-13 08:03:39 --> Final output sent to browser
DEBUG - 2011-10-13 08:03:39 --> Total execution time: 0.3167
DEBUG - 2011-10-13 08:03:40 --> Config Class Initialized
DEBUG - 2011-10-13 08:03:40 --> Hooks Class Initialized
DEBUG - 2011-10-13 08:03:40 --> Utf8 Class Initialized
DEBUG - 2011-10-13 08:03:40 --> UTF-8 Support Enabled
DEBUG - 2011-10-13 08:03:40 --> URI Class Initialized
DEBUG - 2011-10-13 08:03:40 --> Router Class Initialized
DEBUG - 2011-10-13 08:03:40 --> Output Class Initialized
DEBUG - 2011-10-13 08:03:40 --> Input Class Initialized
DEBUG - 2011-10-13 08:03:40 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-13 08:03:40 --> Language Class Initialized
DEBUG - 2011-10-13 08:03:40 --> Loader Class Initialized
DEBUG - 2011-10-13 08:03:40 --> Controller Class Initialized
DEBUG - 2011-10-13 08:03:40 --> Model Class Initialized
DEBUG - 2011-10-13 08:03:40 --> Model Class Initialized
DEBUG - 2011-10-13 08:03:40 --> Model Class Initialized
DEBUG - 2011-10-13 08:03:40 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-13 08:03:40 --> Database Driver Class Initialized
DEBUG - 2011-10-13 08:03:40 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-13 08:03:40 --> Helper loaded: url_helper
DEBUG - 2011-10-13 08:03:40 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-13 08:03:40 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-13 08:03:40 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-13 08:03:40 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-13 08:03:40 --> Final output sent to browser
DEBUG - 2011-10-13 08:03:40 --> Total execution time: 0.0602
DEBUG - 2011-10-13 08:05:30 --> Config Class Initialized
DEBUG - 2011-10-13 08:05:30 --> Hooks Class Initialized
DEBUG - 2011-10-13 08:05:30 --> Utf8 Class Initialized
DEBUG - 2011-10-13 08:05:30 --> UTF-8 Support Enabled
DEBUG - 2011-10-13 08:05:30 --> URI Class Initialized
DEBUG - 2011-10-13 08:05:30 --> Router Class Initialized
DEBUG - 2011-10-13 08:05:30 --> Output Class Initialized
DEBUG - 2011-10-13 08:05:30 --> Input Class Initialized
DEBUG - 2011-10-13 08:05:30 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-13 08:05:30 --> Language Class Initialized
DEBUG - 2011-10-13 08:05:30 --> Loader Class Initialized
DEBUG - 2011-10-13 08:05:30 --> Controller Class Initialized
DEBUG - 2011-10-13 08:05:30 --> Model Class Initialized
DEBUG - 2011-10-13 08:05:30 --> Model Class Initialized
DEBUG - 2011-10-13 08:05:30 --> Model Class Initialized
DEBUG - 2011-10-13 08:05:30 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-13 08:05:30 --> Database Driver Class Initialized
DEBUG - 2011-10-13 08:05:31 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-13 08:05:31 --> Helper loaded: url_helper
DEBUG - 2011-10-13 08:05:31 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-13 08:05:31 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-13 08:05:31 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-13 08:05:31 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-13 08:05:31 --> Final output sent to browser
DEBUG - 2011-10-13 08:05:31 --> Total execution time: 0.9393
DEBUG - 2011-10-13 08:05:37 --> Config Class Initialized
DEBUG - 2011-10-13 08:05:37 --> Hooks Class Initialized
DEBUG - 2011-10-13 08:05:37 --> Utf8 Class Initialized
DEBUG - 2011-10-13 08:05:37 --> UTF-8 Support Enabled
DEBUG - 2011-10-13 08:05:37 --> URI Class Initialized
DEBUG - 2011-10-13 08:05:37 --> Router Class Initialized
DEBUG - 2011-10-13 08:05:37 --> Output Class Initialized
DEBUG - 2011-10-13 08:05:37 --> Input Class Initialized
DEBUG - 2011-10-13 08:05:37 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-13 08:05:37 --> Language Class Initialized
DEBUG - 2011-10-13 08:05:37 --> Loader Class Initialized
DEBUG - 2011-10-13 08:05:37 --> Controller Class Initialized
DEBUG - 2011-10-13 08:05:37 --> Model Class Initialized
DEBUG - 2011-10-13 08:05:37 --> Model Class Initialized
DEBUG - 2011-10-13 08:05:37 --> Model Class Initialized
DEBUG - 2011-10-13 08:05:37 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-13 08:05:37 --> Database Driver Class Initialized
DEBUG - 2011-10-13 08:05:37 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-13 08:05:37 --> Helper loaded: url_helper
DEBUG - 2011-10-13 08:05:37 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-13 08:05:37 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-13 08:05:37 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-13 08:05:37 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-13 08:05:37 --> Final output sent to browser
DEBUG - 2011-10-13 08:05:37 --> Total execution time: 0.0753
DEBUG - 2011-10-13 08:05:48 --> Config Class Initialized
DEBUG - 2011-10-13 08:05:48 --> Hooks Class Initialized
DEBUG - 2011-10-13 08:05:48 --> Utf8 Class Initialized
DEBUG - 2011-10-13 08:05:48 --> UTF-8 Support Enabled
DEBUG - 2011-10-13 08:05:48 --> URI Class Initialized
DEBUG - 2011-10-13 08:05:48 --> Router Class Initialized
DEBUG - 2011-10-13 08:05:48 --> Output Class Initialized
DEBUG - 2011-10-13 08:05:48 --> Input Class Initialized
DEBUG - 2011-10-13 08:05:48 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-13 08:05:48 --> Language Class Initialized
DEBUG - 2011-10-13 08:05:48 --> Loader Class Initialized
DEBUG - 2011-10-13 08:05:48 --> Controller Class Initialized
DEBUG - 2011-10-13 08:05:48 --> Model Class Initialized
DEBUG - 2011-10-13 08:05:48 --> Model Class Initialized
DEBUG - 2011-10-13 08:05:48 --> Model Class Initialized
DEBUG - 2011-10-13 08:05:48 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-13 08:05:48 --> Database Driver Class Initialized
DEBUG - 2011-10-13 08:05:49 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-13 08:05:49 --> Helper loaded: url_helper
DEBUG - 2011-10-13 08:05:49 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-13 08:05:49 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-13 08:05:49 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-13 08:05:49 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-13 08:05:49 --> Final output sent to browser
DEBUG - 2011-10-13 08:05:49 --> Total execution time: 0.8109
DEBUG - 2011-10-13 08:05:50 --> Config Class Initialized
DEBUG - 2011-10-13 08:05:50 --> Hooks Class Initialized
DEBUG - 2011-10-13 08:05:50 --> Utf8 Class Initialized
DEBUG - 2011-10-13 08:05:50 --> UTF-8 Support Enabled
DEBUG - 2011-10-13 08:05:50 --> URI Class Initialized
DEBUG - 2011-10-13 08:05:50 --> Router Class Initialized
DEBUG - 2011-10-13 08:05:50 --> Output Class Initialized
DEBUG - 2011-10-13 08:05:50 --> Input Class Initialized
DEBUG - 2011-10-13 08:05:50 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-13 08:05:50 --> Language Class Initialized
DEBUG - 2011-10-13 08:05:50 --> Loader Class Initialized
DEBUG - 2011-10-13 08:05:50 --> Controller Class Initialized
DEBUG - 2011-10-13 08:05:50 --> Model Class Initialized
DEBUG - 2011-10-13 08:05:50 --> Model Class Initialized
DEBUG - 2011-10-13 08:05:50 --> Model Class Initialized
DEBUG - 2011-10-13 08:05:50 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-13 08:05:50 --> Database Driver Class Initialized
DEBUG - 2011-10-13 08:05:50 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-13 08:05:50 --> Helper loaded: url_helper
DEBUG - 2011-10-13 08:05:50 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-13 08:05:50 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-13 08:05:50 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-13 08:05:50 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-13 08:05:50 --> Final output sent to browser
DEBUG - 2011-10-13 08:05:50 --> Total execution time: 0.0501
DEBUG - 2011-10-13 08:08:17 --> Config Class Initialized
DEBUG - 2011-10-13 08:08:17 --> Hooks Class Initialized
DEBUG - 2011-10-13 08:08:17 --> Utf8 Class Initialized
DEBUG - 2011-10-13 08:08:17 --> UTF-8 Support Enabled
DEBUG - 2011-10-13 08:08:17 --> URI Class Initialized
DEBUG - 2011-10-13 08:08:17 --> Router Class Initialized
DEBUG - 2011-10-13 08:08:17 --> Output Class Initialized
DEBUG - 2011-10-13 08:08:17 --> Input Class Initialized
DEBUG - 2011-10-13 08:08:17 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-13 08:08:17 --> Language Class Initialized
DEBUG - 2011-10-13 08:08:17 --> Loader Class Initialized
DEBUG - 2011-10-13 08:08:17 --> Controller Class Initialized
DEBUG - 2011-10-13 08:08:17 --> Model Class Initialized
DEBUG - 2011-10-13 08:08:17 --> Model Class Initialized
DEBUG - 2011-10-13 08:08:17 --> Model Class Initialized
DEBUG - 2011-10-13 08:08:17 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-13 08:08:17 --> Database Driver Class Initialized
DEBUG - 2011-10-13 08:08:18 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-13 08:08:18 --> Helper loaded: url_helper
DEBUG - 2011-10-13 08:08:18 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-13 08:08:18 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-13 08:08:18 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-13 08:08:18 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-13 08:08:18 --> Final output sent to browser
DEBUG - 2011-10-13 08:08:18 --> Total execution time: 0.3247
DEBUG - 2011-10-13 08:08:20 --> Config Class Initialized
DEBUG - 2011-10-13 08:08:20 --> Hooks Class Initialized
DEBUG - 2011-10-13 08:08:20 --> Utf8 Class Initialized
DEBUG - 2011-10-13 08:08:20 --> UTF-8 Support Enabled
DEBUG - 2011-10-13 08:08:20 --> URI Class Initialized
DEBUG - 2011-10-13 08:08:20 --> Router Class Initialized
DEBUG - 2011-10-13 08:08:20 --> Output Class Initialized
DEBUG - 2011-10-13 08:08:20 --> Input Class Initialized
DEBUG - 2011-10-13 08:08:20 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-13 08:08:20 --> Language Class Initialized
DEBUG - 2011-10-13 08:08:20 --> Loader Class Initialized
DEBUG - 2011-10-13 08:08:20 --> Controller Class Initialized
DEBUG - 2011-10-13 08:08:20 --> Model Class Initialized
DEBUG - 2011-10-13 08:08:20 --> Model Class Initialized
DEBUG - 2011-10-13 08:08:20 --> Model Class Initialized
DEBUG - 2011-10-13 08:08:20 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-13 08:08:20 --> Database Driver Class Initialized
DEBUG - 2011-10-13 08:08:21 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-13 08:08:21 --> Helper loaded: url_helper
DEBUG - 2011-10-13 08:08:21 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-13 08:08:21 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-13 08:08:21 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-13 08:08:21 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-13 08:08:21 --> Final output sent to browser
DEBUG - 2011-10-13 08:08:21 --> Total execution time: 0.0811
DEBUG - 2011-10-13 08:08:33 --> Config Class Initialized
DEBUG - 2011-10-13 08:08:33 --> Hooks Class Initialized
DEBUG - 2011-10-13 08:08:33 --> Utf8 Class Initialized
DEBUG - 2011-10-13 08:08:33 --> UTF-8 Support Enabled
DEBUG - 2011-10-13 08:08:33 --> URI Class Initialized
DEBUG - 2011-10-13 08:08:33 --> Router Class Initialized
DEBUG - 2011-10-13 08:08:33 --> Output Class Initialized
DEBUG - 2011-10-13 08:08:33 --> Input Class Initialized
DEBUG - 2011-10-13 08:08:33 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-13 08:08:33 --> Language Class Initialized
DEBUG - 2011-10-13 08:08:33 --> Loader Class Initialized
DEBUG - 2011-10-13 08:08:33 --> Controller Class Initialized
DEBUG - 2011-10-13 08:08:33 --> Model Class Initialized
DEBUG - 2011-10-13 08:08:33 --> Model Class Initialized
DEBUG - 2011-10-13 08:08:33 --> Model Class Initialized
DEBUG - 2011-10-13 08:08:33 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-13 08:08:33 --> Database Driver Class Initialized
DEBUG - 2011-10-13 08:08:33 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-13 08:08:33 --> Helper loaded: url_helper
DEBUG - 2011-10-13 08:08:33 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-13 08:08:33 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-13 08:08:33 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-13 08:08:33 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-13 08:08:33 --> Final output sent to browser
DEBUG - 2011-10-13 08:08:33 --> Total execution time: 0.2637
DEBUG - 2011-10-13 08:08:35 --> Config Class Initialized
DEBUG - 2011-10-13 08:08:35 --> Hooks Class Initialized
DEBUG - 2011-10-13 08:08:35 --> Utf8 Class Initialized
DEBUG - 2011-10-13 08:08:35 --> UTF-8 Support Enabled
DEBUG - 2011-10-13 08:08:35 --> URI Class Initialized
DEBUG - 2011-10-13 08:08:35 --> Router Class Initialized
DEBUG - 2011-10-13 08:08:35 --> Output Class Initialized
DEBUG - 2011-10-13 08:08:35 --> Input Class Initialized
DEBUG - 2011-10-13 08:08:35 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-13 08:08:35 --> Language Class Initialized
DEBUG - 2011-10-13 08:08:35 --> Loader Class Initialized
DEBUG - 2011-10-13 08:08:35 --> Controller Class Initialized
DEBUG - 2011-10-13 08:08:35 --> Model Class Initialized
DEBUG - 2011-10-13 08:08:35 --> Model Class Initialized
DEBUG - 2011-10-13 08:08:35 --> Model Class Initialized
DEBUG - 2011-10-13 08:08:35 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-13 08:08:35 --> Database Driver Class Initialized
DEBUG - 2011-10-13 08:08:35 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-13 08:08:35 --> Helper loaded: url_helper
DEBUG - 2011-10-13 08:08:35 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-13 08:08:35 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-13 08:08:35 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-13 08:08:35 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-13 08:08:35 --> Final output sent to browser
DEBUG - 2011-10-13 08:08:35 --> Total execution time: 0.0706
DEBUG - 2011-10-13 08:30:19 --> Config Class Initialized
DEBUG - 2011-10-13 08:30:19 --> Hooks Class Initialized
DEBUG - 2011-10-13 08:30:19 --> Utf8 Class Initialized
DEBUG - 2011-10-13 08:30:19 --> UTF-8 Support Enabled
DEBUG - 2011-10-13 08:30:19 --> URI Class Initialized
DEBUG - 2011-10-13 08:30:19 --> Router Class Initialized
DEBUG - 2011-10-13 08:30:19 --> Output Class Initialized
DEBUG - 2011-10-13 08:30:19 --> Input Class Initialized
DEBUG - 2011-10-13 08:30:19 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-13 08:30:19 --> Language Class Initialized
DEBUG - 2011-10-13 08:30:19 --> Loader Class Initialized
DEBUG - 2011-10-13 08:30:19 --> Controller Class Initialized
DEBUG - 2011-10-13 08:30:19 --> Model Class Initialized
DEBUG - 2011-10-13 08:30:19 --> Model Class Initialized
DEBUG - 2011-10-13 08:30:19 --> Model Class Initialized
DEBUG - 2011-10-13 08:30:19 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-13 08:30:19 --> Database Driver Class Initialized
DEBUG - 2011-10-13 08:30:20 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-13 08:30:20 --> Helper loaded: url_helper
DEBUG - 2011-10-13 08:30:20 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-13 08:30:20 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-13 08:30:20 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-13 08:30:20 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-13 08:30:20 --> Final output sent to browser
DEBUG - 2011-10-13 08:30:20 --> Total execution time: 0.7851
DEBUG - 2011-10-13 08:30:23 --> Config Class Initialized
DEBUG - 2011-10-13 08:30:23 --> Hooks Class Initialized
DEBUG - 2011-10-13 08:30:23 --> Utf8 Class Initialized
DEBUG - 2011-10-13 08:30:23 --> UTF-8 Support Enabled
DEBUG - 2011-10-13 08:30:23 --> URI Class Initialized
DEBUG - 2011-10-13 08:30:23 --> Router Class Initialized
ERROR - 2011-10-13 08:30:23 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-13 08:31:05 --> Config Class Initialized
DEBUG - 2011-10-13 08:31:05 --> Hooks Class Initialized
DEBUG - 2011-10-13 08:31:05 --> Utf8 Class Initialized
DEBUG - 2011-10-13 08:31:05 --> UTF-8 Support Enabled
DEBUG - 2011-10-13 08:31:05 --> URI Class Initialized
DEBUG - 2011-10-13 08:31:05 --> Router Class Initialized
DEBUG - 2011-10-13 08:31:05 --> Output Class Initialized
DEBUG - 2011-10-13 08:31:05 --> Input Class Initialized
DEBUG - 2011-10-13 08:31:05 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-13 08:31:05 --> Language Class Initialized
DEBUG - 2011-10-13 08:31:05 --> Loader Class Initialized
DEBUG - 2011-10-13 08:31:05 --> Controller Class Initialized
DEBUG - 2011-10-13 08:31:05 --> Model Class Initialized
DEBUG - 2011-10-13 08:31:05 --> Model Class Initialized
DEBUG - 2011-10-13 08:31:05 --> Model Class Initialized
DEBUG - 2011-10-13 08:31:05 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-13 08:31:05 --> Database Driver Class Initialized
DEBUG - 2011-10-13 08:31:05 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-13 08:31:05 --> Helper loaded: url_helper
DEBUG - 2011-10-13 08:31:05 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-13 08:31:05 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-13 08:31:05 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-13 08:31:05 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-13 08:31:05 --> Final output sent to browser
DEBUG - 2011-10-13 08:31:05 --> Total execution time: 0.0512
DEBUG - 2011-10-13 08:31:09 --> Config Class Initialized
DEBUG - 2011-10-13 08:31:09 --> Hooks Class Initialized
DEBUG - 2011-10-13 08:31:09 --> Utf8 Class Initialized
DEBUG - 2011-10-13 08:31:09 --> UTF-8 Support Enabled
DEBUG - 2011-10-13 08:31:09 --> URI Class Initialized
DEBUG - 2011-10-13 08:31:09 --> Router Class Initialized
ERROR - 2011-10-13 08:31:09 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-13 08:31:09 --> Config Class Initialized
DEBUG - 2011-10-13 08:31:09 --> Hooks Class Initialized
DEBUG - 2011-10-13 08:31:09 --> Utf8 Class Initialized
DEBUG - 2011-10-13 08:31:09 --> UTF-8 Support Enabled
DEBUG - 2011-10-13 08:31:09 --> URI Class Initialized
DEBUG - 2011-10-13 08:31:09 --> Router Class Initialized
ERROR - 2011-10-13 08:31:09 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-13 09:07:30 --> Config Class Initialized
DEBUG - 2011-10-13 09:07:30 --> Hooks Class Initialized
DEBUG - 2011-10-13 09:07:30 --> Utf8 Class Initialized
DEBUG - 2011-10-13 09:07:30 --> UTF-8 Support Enabled
DEBUG - 2011-10-13 09:07:30 --> URI Class Initialized
DEBUG - 2011-10-13 09:07:30 --> Router Class Initialized
DEBUG - 2011-10-13 09:07:30 --> No URI present. Default controller set.
DEBUG - 2011-10-13 09:07:30 --> Output Class Initialized
DEBUG - 2011-10-13 09:07:30 --> Input Class Initialized
DEBUG - 2011-10-13 09:07:30 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-13 09:07:30 --> Language Class Initialized
DEBUG - 2011-10-13 09:07:30 --> Loader Class Initialized
DEBUG - 2011-10-13 09:07:30 --> Controller Class Initialized
DEBUG - 2011-10-13 09:07:30 --> File loaded: application/views/splash/main.php
DEBUG - 2011-10-13 09:07:30 --> Helper loaded: url_helper
DEBUG - 2011-10-13 09:07:30 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-13 09:07:30 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-13 09:07:30 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-13 09:07:30 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-13 09:07:30 --> Final output sent to browser
DEBUG - 2011-10-13 09:07:30 --> Total execution time: 0.0745
DEBUG - 2011-10-13 09:56:52 --> Config Class Initialized
DEBUG - 2011-10-13 09:56:52 --> Hooks Class Initialized
DEBUG - 2011-10-13 09:56:52 --> Utf8 Class Initialized
DEBUG - 2011-10-13 09:56:52 --> UTF-8 Support Enabled
DEBUG - 2011-10-13 09:56:52 --> URI Class Initialized
DEBUG - 2011-10-13 09:56:52 --> Router Class Initialized
DEBUG - 2011-10-13 09:56:52 --> Output Class Initialized
DEBUG - 2011-10-13 09:56:52 --> Input Class Initialized
DEBUG - 2011-10-13 09:56:52 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-13 09:56:52 --> Language Class Initialized
DEBUG - 2011-10-13 09:56:52 --> Loader Class Initialized
DEBUG - 2011-10-13 09:56:52 --> Controller Class Initialized
DEBUG - 2011-10-13 09:56:52 --> Model Class Initialized
DEBUG - 2011-10-13 09:56:52 --> Model Class Initialized
DEBUG - 2011-10-13 09:56:52 --> Model Class Initialized
DEBUG - 2011-10-13 09:56:52 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-13 09:56:52 --> Database Driver Class Initialized
DEBUG - 2011-10-13 09:56:53 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-13 09:56:53 --> Helper loaded: url_helper
DEBUG - 2011-10-13 09:56:53 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-13 09:56:53 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-13 09:56:53 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-13 09:56:53 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-13 09:56:53 --> Final output sent to browser
DEBUG - 2011-10-13 09:56:53 --> Total execution time: 1.0835
DEBUG - 2011-10-13 09:56:59 --> Config Class Initialized
DEBUG - 2011-10-13 09:56:59 --> Hooks Class Initialized
DEBUG - 2011-10-13 09:56:59 --> Utf8 Class Initialized
DEBUG - 2011-10-13 09:56:59 --> UTF-8 Support Enabled
DEBUG - 2011-10-13 09:56:59 --> URI Class Initialized
DEBUG - 2011-10-13 09:56:59 --> Router Class Initialized
ERROR - 2011-10-13 09:56:59 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-13 10:04:05 --> Config Class Initialized
DEBUG - 2011-10-13 10:04:05 --> Hooks Class Initialized
DEBUG - 2011-10-13 10:04:05 --> Utf8 Class Initialized
DEBUG - 2011-10-13 10:04:05 --> UTF-8 Support Enabled
DEBUG - 2011-10-13 10:04:05 --> URI Class Initialized
DEBUG - 2011-10-13 10:04:05 --> Router Class Initialized
DEBUG - 2011-10-13 10:04:05 --> Output Class Initialized
DEBUG - 2011-10-13 10:04:05 --> Input Class Initialized
DEBUG - 2011-10-13 10:04:05 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-13 10:04:05 --> Language Class Initialized
DEBUG - 2011-10-13 10:04:05 --> Loader Class Initialized
DEBUG - 2011-10-13 10:04:05 --> Controller Class Initialized
DEBUG - 2011-10-13 10:04:05 --> Model Class Initialized
DEBUG - 2011-10-13 10:04:05 --> Model Class Initialized
DEBUG - 2011-10-13 10:04:05 --> Model Class Initialized
DEBUG - 2011-10-13 10:04:05 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-13 10:04:05 --> Database Driver Class Initialized
DEBUG - 2011-10-13 10:04:06 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-13 10:04:06 --> Helper loaded: url_helper
DEBUG - 2011-10-13 10:04:06 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-13 10:04:06 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-13 10:04:06 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-13 10:04:06 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-13 10:04:06 --> Final output sent to browser
DEBUG - 2011-10-13 10:04:06 --> Total execution time: 1.0360
DEBUG - 2011-10-13 10:04:10 --> Config Class Initialized
DEBUG - 2011-10-13 10:04:10 --> Hooks Class Initialized
DEBUG - 2011-10-13 10:04:10 --> Utf8 Class Initialized
DEBUG - 2011-10-13 10:04:10 --> UTF-8 Support Enabled
DEBUG - 2011-10-13 10:04:10 --> URI Class Initialized
DEBUG - 2011-10-13 10:04:10 --> Router Class Initialized
DEBUG - 2011-10-13 10:04:10 --> Output Class Initialized
DEBUG - 2011-10-13 10:04:10 --> Input Class Initialized
DEBUG - 2011-10-13 10:04:10 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-13 10:04:10 --> Language Class Initialized
DEBUG - 2011-10-13 10:04:10 --> Loader Class Initialized
DEBUG - 2011-10-13 10:04:10 --> Controller Class Initialized
DEBUG - 2011-10-13 10:04:10 --> Model Class Initialized
DEBUG - 2011-10-13 10:04:10 --> Model Class Initialized
DEBUG - 2011-10-13 10:04:10 --> Model Class Initialized
DEBUG - 2011-10-13 10:04:10 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-13 10:04:10 --> Database Driver Class Initialized
DEBUG - 2011-10-13 10:04:10 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-13 10:04:10 --> Helper loaded: url_helper
DEBUG - 2011-10-13 10:04:10 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-13 10:04:10 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-13 10:04:10 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-13 10:04:10 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-13 10:04:10 --> Final output sent to browser
DEBUG - 2011-10-13 10:04:10 --> Total execution time: 0.0459
DEBUG - 2011-10-13 10:04:29 --> Config Class Initialized
DEBUG - 2011-10-13 10:04:29 --> Hooks Class Initialized
DEBUG - 2011-10-13 10:04:29 --> Utf8 Class Initialized
DEBUG - 2011-10-13 10:04:29 --> UTF-8 Support Enabled
DEBUG - 2011-10-13 10:04:29 --> URI Class Initialized
DEBUG - 2011-10-13 10:04:29 --> Router Class Initialized
DEBUG - 2011-10-13 10:04:29 --> Output Class Initialized
DEBUG - 2011-10-13 10:04:29 --> Input Class Initialized
DEBUG - 2011-10-13 10:04:29 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-13 10:04:29 --> Language Class Initialized
DEBUG - 2011-10-13 10:04:29 --> Loader Class Initialized
DEBUG - 2011-10-13 10:04:29 --> Controller Class Initialized
DEBUG - 2011-10-13 10:04:29 --> Model Class Initialized
DEBUG - 2011-10-13 10:04:29 --> Model Class Initialized
DEBUG - 2011-10-13 10:04:29 --> Model Class Initialized
DEBUG - 2011-10-13 10:04:29 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-13 10:04:29 --> Database Driver Class Initialized
DEBUG - 2011-10-13 10:04:29 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-13 10:04:29 --> Helper loaded: url_helper
DEBUG - 2011-10-13 10:04:29 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-13 10:04:29 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-13 10:04:29 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-13 10:04:29 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-13 10:04:29 --> Final output sent to browser
DEBUG - 2011-10-13 10:04:29 --> Total execution time: 0.3141
DEBUG - 2011-10-13 10:04:32 --> Config Class Initialized
DEBUG - 2011-10-13 10:04:32 --> Hooks Class Initialized
DEBUG - 2011-10-13 10:04:32 --> Utf8 Class Initialized
DEBUG - 2011-10-13 10:04:32 --> UTF-8 Support Enabled
DEBUG - 2011-10-13 10:04:32 --> URI Class Initialized
DEBUG - 2011-10-13 10:04:32 --> Router Class Initialized
DEBUG - 2011-10-13 10:04:32 --> Output Class Initialized
DEBUG - 2011-10-13 10:04:32 --> Input Class Initialized
DEBUG - 2011-10-13 10:04:32 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-13 10:04:32 --> Language Class Initialized
DEBUG - 2011-10-13 10:04:32 --> Loader Class Initialized
DEBUG - 2011-10-13 10:04:32 --> Controller Class Initialized
DEBUG - 2011-10-13 10:04:32 --> Model Class Initialized
DEBUG - 2011-10-13 10:04:32 --> Model Class Initialized
DEBUG - 2011-10-13 10:04:32 --> Model Class Initialized
DEBUG - 2011-10-13 10:04:32 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-13 10:04:32 --> Database Driver Class Initialized
DEBUG - 2011-10-13 10:04:32 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-13 10:04:32 --> Helper loaded: url_helper
DEBUG - 2011-10-13 10:04:32 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-13 10:04:32 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-13 10:04:32 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-13 10:04:32 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-13 10:04:32 --> Final output sent to browser
DEBUG - 2011-10-13 10:04:32 --> Total execution time: 0.2001
DEBUG - 2011-10-13 10:04:53 --> Config Class Initialized
DEBUG - 2011-10-13 10:04:53 --> Hooks Class Initialized
DEBUG - 2011-10-13 10:04:53 --> Utf8 Class Initialized
DEBUG - 2011-10-13 10:04:53 --> UTF-8 Support Enabled
DEBUG - 2011-10-13 10:04:53 --> URI Class Initialized
DEBUG - 2011-10-13 10:04:53 --> Router Class Initialized
DEBUG - 2011-10-13 10:04:53 --> Output Class Initialized
DEBUG - 2011-10-13 10:04:53 --> Input Class Initialized
DEBUG - 2011-10-13 10:04:53 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-13 10:04:53 --> Language Class Initialized
DEBUG - 2011-10-13 10:04:53 --> Loader Class Initialized
DEBUG - 2011-10-13 10:04:53 --> Controller Class Initialized
DEBUG - 2011-10-13 10:04:53 --> Model Class Initialized
DEBUG - 2011-10-13 10:04:53 --> Model Class Initialized
DEBUG - 2011-10-13 10:04:53 --> Model Class Initialized
DEBUG - 2011-10-13 10:04:53 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-13 10:04:53 --> Database Driver Class Initialized
DEBUG - 2011-10-13 10:04:53 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-13 10:04:53 --> Helper loaded: url_helper
DEBUG - 2011-10-13 10:04:53 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-13 10:04:53 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-13 10:04:53 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-13 10:04:53 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-13 10:04:53 --> Final output sent to browser
DEBUG - 2011-10-13 10:04:53 --> Total execution time: 0.2894
DEBUG - 2011-10-13 10:04:56 --> Config Class Initialized
DEBUG - 2011-10-13 10:04:56 --> Hooks Class Initialized
DEBUG - 2011-10-13 10:04:56 --> Utf8 Class Initialized
DEBUG - 2011-10-13 10:04:56 --> UTF-8 Support Enabled
DEBUG - 2011-10-13 10:04:56 --> URI Class Initialized
DEBUG - 2011-10-13 10:04:56 --> Router Class Initialized
DEBUG - 2011-10-13 10:04:56 --> Output Class Initialized
DEBUG - 2011-10-13 10:04:56 --> Input Class Initialized
DEBUG - 2011-10-13 10:04:56 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-13 10:04:56 --> Language Class Initialized
DEBUG - 2011-10-13 10:04:56 --> Loader Class Initialized
DEBUG - 2011-10-13 10:04:56 --> Controller Class Initialized
DEBUG - 2011-10-13 10:04:56 --> Model Class Initialized
DEBUG - 2011-10-13 10:04:56 --> Model Class Initialized
DEBUG - 2011-10-13 10:04:56 --> Model Class Initialized
DEBUG - 2011-10-13 10:04:56 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-13 10:04:56 --> Database Driver Class Initialized
DEBUG - 2011-10-13 10:04:56 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-13 10:04:56 --> Helper loaded: url_helper
DEBUG - 2011-10-13 10:04:56 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-13 10:04:56 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-13 10:04:56 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-13 10:04:56 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-13 10:04:56 --> Final output sent to browser
DEBUG - 2011-10-13 10:04:56 --> Total execution time: 0.0559
DEBUG - 2011-10-13 10:05:04 --> Config Class Initialized
DEBUG - 2011-10-13 10:05:04 --> Hooks Class Initialized
DEBUG - 2011-10-13 10:05:04 --> Utf8 Class Initialized
DEBUG - 2011-10-13 10:05:04 --> UTF-8 Support Enabled
DEBUG - 2011-10-13 10:05:04 --> URI Class Initialized
DEBUG - 2011-10-13 10:05:04 --> Router Class Initialized
DEBUG - 2011-10-13 10:05:04 --> Output Class Initialized
DEBUG - 2011-10-13 10:05:04 --> Input Class Initialized
DEBUG - 2011-10-13 10:05:04 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-13 10:05:04 --> Language Class Initialized
DEBUG - 2011-10-13 10:05:04 --> Loader Class Initialized
DEBUG - 2011-10-13 10:05:04 --> Controller Class Initialized
DEBUG - 2011-10-13 10:05:04 --> Model Class Initialized
DEBUG - 2011-10-13 10:05:04 --> Model Class Initialized
DEBUG - 2011-10-13 10:05:04 --> Model Class Initialized
DEBUG - 2011-10-13 10:05:04 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-13 10:05:04 --> Database Driver Class Initialized
DEBUG - 2011-10-13 10:05:06 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-13 10:05:06 --> Helper loaded: url_helper
DEBUG - 2011-10-13 10:05:06 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-13 10:05:06 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-13 10:05:06 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-13 10:05:06 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-13 10:05:06 --> Final output sent to browser
DEBUG - 2011-10-13 10:05:06 --> Total execution time: 2.1221
DEBUG - 2011-10-13 10:05:08 --> Config Class Initialized
DEBUG - 2011-10-13 10:05:08 --> Hooks Class Initialized
DEBUG - 2011-10-13 10:05:08 --> Utf8 Class Initialized
DEBUG - 2011-10-13 10:05:08 --> UTF-8 Support Enabled
DEBUG - 2011-10-13 10:05:08 --> URI Class Initialized
DEBUG - 2011-10-13 10:05:08 --> Router Class Initialized
DEBUG - 2011-10-13 10:05:08 --> Output Class Initialized
DEBUG - 2011-10-13 10:05:08 --> Input Class Initialized
DEBUG - 2011-10-13 10:05:08 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-13 10:05:08 --> Language Class Initialized
DEBUG - 2011-10-13 10:05:08 --> Loader Class Initialized
DEBUG - 2011-10-13 10:05:08 --> Controller Class Initialized
DEBUG - 2011-10-13 10:05:08 --> Model Class Initialized
DEBUG - 2011-10-13 10:05:08 --> Model Class Initialized
DEBUG - 2011-10-13 10:05:08 --> Model Class Initialized
DEBUG - 2011-10-13 10:05:08 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-13 10:05:08 --> Database Driver Class Initialized
DEBUG - 2011-10-13 10:05:08 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-13 10:05:08 --> Helper loaded: url_helper
DEBUG - 2011-10-13 10:05:08 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-13 10:05:08 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-13 10:05:08 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-13 10:05:08 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-13 10:05:08 --> Final output sent to browser
DEBUG - 2011-10-13 10:05:08 --> Total execution time: 0.3070
DEBUG - 2011-10-13 10:05:09 --> Config Class Initialized
DEBUG - 2011-10-13 10:05:09 --> Hooks Class Initialized
DEBUG - 2011-10-13 10:05:09 --> Utf8 Class Initialized
DEBUG - 2011-10-13 10:05:09 --> UTF-8 Support Enabled
DEBUG - 2011-10-13 10:05:09 --> URI Class Initialized
DEBUG - 2011-10-13 10:05:09 --> Router Class Initialized
DEBUG - 2011-10-13 10:05:09 --> Output Class Initialized
DEBUG - 2011-10-13 10:05:09 --> Input Class Initialized
DEBUG - 2011-10-13 10:05:09 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-13 10:05:09 --> Language Class Initialized
DEBUG - 2011-10-13 10:05:09 --> Loader Class Initialized
DEBUG - 2011-10-13 10:05:09 --> Controller Class Initialized
DEBUG - 2011-10-13 10:05:09 --> Model Class Initialized
DEBUG - 2011-10-13 10:05:09 --> Model Class Initialized
DEBUG - 2011-10-13 10:05:09 --> Model Class Initialized
DEBUG - 2011-10-13 10:05:09 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-13 10:05:09 --> Database Driver Class Initialized
DEBUG - 2011-10-13 10:05:09 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-13 10:05:09 --> Helper loaded: url_helper
DEBUG - 2011-10-13 10:05:09 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-13 10:05:09 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-13 10:05:09 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-13 10:05:09 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-13 10:05:09 --> Final output sent to browser
DEBUG - 2011-10-13 10:05:09 --> Total execution time: 0.1409
DEBUG - 2011-10-13 10:06:23 --> Config Class Initialized
DEBUG - 2011-10-13 10:06:23 --> Hooks Class Initialized
DEBUG - 2011-10-13 10:06:23 --> Utf8 Class Initialized
DEBUG - 2011-10-13 10:06:23 --> UTF-8 Support Enabled
DEBUG - 2011-10-13 10:06:23 --> URI Class Initialized
DEBUG - 2011-10-13 10:06:23 --> Router Class Initialized
DEBUG - 2011-10-13 10:06:23 --> Output Class Initialized
DEBUG - 2011-10-13 10:06:23 --> Input Class Initialized
DEBUG - 2011-10-13 10:06:23 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-13 10:06:23 --> Language Class Initialized
DEBUG - 2011-10-13 10:06:23 --> Loader Class Initialized
DEBUG - 2011-10-13 10:06:23 --> Controller Class Initialized
DEBUG - 2011-10-13 10:06:23 --> Model Class Initialized
DEBUG - 2011-10-13 10:06:23 --> Model Class Initialized
DEBUG - 2011-10-13 10:06:23 --> Model Class Initialized
DEBUG - 2011-10-13 10:06:23 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-13 10:06:23 --> Database Driver Class Initialized
DEBUG - 2011-10-13 10:06:23 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-13 10:06:23 --> Helper loaded: url_helper
DEBUG - 2011-10-13 10:06:23 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-13 10:06:23 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-13 10:06:23 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-13 10:06:23 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-13 10:06:23 --> Final output sent to browser
DEBUG - 2011-10-13 10:06:23 --> Total execution time: 0.3548
DEBUG - 2011-10-13 10:06:28 --> Config Class Initialized
DEBUG - 2011-10-13 10:06:28 --> Hooks Class Initialized
DEBUG - 2011-10-13 10:06:28 --> Utf8 Class Initialized
DEBUG - 2011-10-13 10:06:28 --> UTF-8 Support Enabled
DEBUG - 2011-10-13 10:06:28 --> URI Class Initialized
DEBUG - 2011-10-13 10:06:28 --> Router Class Initialized
DEBUG - 2011-10-13 10:06:28 --> Output Class Initialized
DEBUG - 2011-10-13 10:06:28 --> Input Class Initialized
DEBUG - 2011-10-13 10:06:28 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-13 10:06:28 --> Language Class Initialized
DEBUG - 2011-10-13 10:06:28 --> Loader Class Initialized
DEBUG - 2011-10-13 10:06:28 --> Controller Class Initialized
DEBUG - 2011-10-13 10:06:28 --> Model Class Initialized
DEBUG - 2011-10-13 10:06:28 --> Model Class Initialized
DEBUG - 2011-10-13 10:06:28 --> Model Class Initialized
DEBUG - 2011-10-13 10:06:28 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-13 10:06:28 --> Database Driver Class Initialized
DEBUG - 2011-10-13 10:06:28 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-13 10:06:28 --> Helper loaded: url_helper
DEBUG - 2011-10-13 10:06:28 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-13 10:06:28 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-13 10:06:28 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-13 10:06:28 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-13 10:06:28 --> Final output sent to browser
DEBUG - 2011-10-13 10:06:28 --> Total execution time: 0.0467
DEBUG - 2011-10-13 10:39:53 --> Config Class Initialized
DEBUG - 2011-10-13 10:39:53 --> Hooks Class Initialized
DEBUG - 2011-10-13 10:39:53 --> Utf8 Class Initialized
DEBUG - 2011-10-13 10:39:53 --> UTF-8 Support Enabled
DEBUG - 2011-10-13 10:39:53 --> URI Class Initialized
DEBUG - 2011-10-13 10:39:53 --> Router Class Initialized
DEBUG - 2011-10-13 10:39:53 --> Output Class Initialized
DEBUG - 2011-10-13 10:39:53 --> Input Class Initialized
DEBUG - 2011-10-13 10:39:53 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-13 10:39:53 --> Language Class Initialized
DEBUG - 2011-10-13 10:39:53 --> Loader Class Initialized
DEBUG - 2011-10-13 10:39:53 --> Controller Class Initialized
ERROR - 2011-10-13 10:39:53 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-10-13 10:39:53 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-10-13 10:39:53 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-13 10:39:53 --> Model Class Initialized
DEBUG - 2011-10-13 10:39:53 --> Model Class Initialized
DEBUG - 2011-10-13 10:39:53 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-13 10:39:53 --> Database Driver Class Initialized
DEBUG - 2011-10-13 10:39:53 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-13 10:39:53 --> Helper loaded: url_helper
DEBUG - 2011-10-13 10:39:53 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-13 10:39:53 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-13 10:39:53 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-13 10:39:53 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-13 10:39:53 --> Final output sent to browser
DEBUG - 2011-10-13 10:39:53 --> Total execution time: 0.3383
DEBUG - 2011-10-13 10:39:55 --> Config Class Initialized
DEBUG - 2011-10-13 10:39:55 --> Hooks Class Initialized
DEBUG - 2011-10-13 10:39:55 --> Utf8 Class Initialized
DEBUG - 2011-10-13 10:39:55 --> UTF-8 Support Enabled
DEBUG - 2011-10-13 10:39:55 --> URI Class Initialized
DEBUG - 2011-10-13 10:39:55 --> Router Class Initialized
DEBUG - 2011-10-13 10:39:55 --> Output Class Initialized
DEBUG - 2011-10-13 10:39:55 --> Input Class Initialized
DEBUG - 2011-10-13 10:39:55 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-13 10:39:55 --> Language Class Initialized
DEBUG - 2011-10-13 10:39:55 --> Loader Class Initialized
DEBUG - 2011-10-13 10:39:55 --> Controller Class Initialized
DEBUG - 2011-10-13 10:39:55 --> Model Class Initialized
DEBUG - 2011-10-13 10:39:55 --> Model Class Initialized
DEBUG - 2011-10-13 10:39:55 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-13 10:39:55 --> Database Driver Class Initialized
DEBUG - 2011-10-13 10:39:56 --> Final output sent to browser
DEBUG - 2011-10-13 10:39:56 --> Total execution time: 0.6522
DEBUG - 2011-10-13 10:39:58 --> Config Class Initialized
DEBUG - 2011-10-13 10:39:58 --> Hooks Class Initialized
DEBUG - 2011-10-13 10:39:58 --> Utf8 Class Initialized
DEBUG - 2011-10-13 10:39:58 --> UTF-8 Support Enabled
DEBUG - 2011-10-13 10:39:58 --> URI Class Initialized
DEBUG - 2011-10-13 10:39:58 --> Router Class Initialized
ERROR - 2011-10-13 10:39:58 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-13 10:40:41 --> Config Class Initialized
DEBUG - 2011-10-13 10:40:41 --> Hooks Class Initialized
DEBUG - 2011-10-13 10:40:41 --> Utf8 Class Initialized
DEBUG - 2011-10-13 10:40:41 --> UTF-8 Support Enabled
DEBUG - 2011-10-13 10:40:41 --> URI Class Initialized
DEBUG - 2011-10-13 10:40:41 --> Router Class Initialized
DEBUG - 2011-10-13 10:40:41 --> Output Class Initialized
DEBUG - 2011-10-13 10:40:41 --> Input Class Initialized
DEBUG - 2011-10-13 10:40:41 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-13 10:40:41 --> Language Class Initialized
DEBUG - 2011-10-13 10:40:41 --> Loader Class Initialized
DEBUG - 2011-10-13 10:40:41 --> Controller Class Initialized
ERROR - 2011-10-13 10:40:41 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-10-13 10:40:41 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-10-13 10:40:41 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-13 10:40:41 --> Model Class Initialized
DEBUG - 2011-10-13 10:40:41 --> Model Class Initialized
DEBUG - 2011-10-13 10:40:41 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-13 10:40:41 --> Database Driver Class Initialized
DEBUG - 2011-10-13 10:40:41 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-13 10:40:41 --> Helper loaded: url_helper
DEBUG - 2011-10-13 10:40:41 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-13 10:40:41 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-13 10:40:41 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-13 10:40:41 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-13 10:40:41 --> Final output sent to browser
DEBUG - 2011-10-13 10:40:41 --> Total execution time: 0.0351
DEBUG - 2011-10-13 10:40:42 --> Config Class Initialized
DEBUG - 2011-10-13 10:40:42 --> Hooks Class Initialized
DEBUG - 2011-10-13 10:40:42 --> Utf8 Class Initialized
DEBUG - 2011-10-13 10:40:42 --> UTF-8 Support Enabled
DEBUG - 2011-10-13 10:40:42 --> URI Class Initialized
DEBUG - 2011-10-13 10:40:42 --> Router Class Initialized
DEBUG - 2011-10-13 10:40:42 --> Output Class Initialized
DEBUG - 2011-10-13 10:40:42 --> Input Class Initialized
DEBUG - 2011-10-13 10:40:42 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-13 10:40:42 --> Language Class Initialized
DEBUG - 2011-10-13 10:40:42 --> Loader Class Initialized
DEBUG - 2011-10-13 10:40:42 --> Controller Class Initialized
DEBUG - 2011-10-13 10:40:42 --> Model Class Initialized
DEBUG - 2011-10-13 10:40:42 --> Model Class Initialized
DEBUG - 2011-10-13 10:40:42 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-13 10:40:42 --> Database Driver Class Initialized
DEBUG - 2011-10-13 10:40:43 --> Final output sent to browser
DEBUG - 2011-10-13 10:40:43 --> Total execution time: 0.7746
DEBUG - 2011-10-13 10:40:45 --> Config Class Initialized
DEBUG - 2011-10-13 10:40:45 --> Hooks Class Initialized
DEBUG - 2011-10-13 10:40:45 --> Utf8 Class Initialized
DEBUG - 2011-10-13 10:40:45 --> UTF-8 Support Enabled
DEBUG - 2011-10-13 10:40:45 --> URI Class Initialized
DEBUG - 2011-10-13 10:40:45 --> Router Class Initialized
ERROR - 2011-10-13 10:40:45 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-13 10:41:13 --> Config Class Initialized
DEBUG - 2011-10-13 10:41:13 --> Hooks Class Initialized
DEBUG - 2011-10-13 10:41:13 --> Utf8 Class Initialized
DEBUG - 2011-10-13 10:41:13 --> UTF-8 Support Enabled
DEBUG - 2011-10-13 10:41:13 --> URI Class Initialized
DEBUG - 2011-10-13 10:41:13 --> Router Class Initialized
DEBUG - 2011-10-13 10:41:13 --> Output Class Initialized
DEBUG - 2011-10-13 10:41:13 --> Input Class Initialized
DEBUG - 2011-10-13 10:41:13 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-13 10:41:13 --> Language Class Initialized
DEBUG - 2011-10-13 10:41:13 --> Loader Class Initialized
DEBUG - 2011-10-13 10:41:13 --> Controller Class Initialized
ERROR - 2011-10-13 10:41:13 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-10-13 10:41:13 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-10-13 10:41:13 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-13 10:41:13 --> Model Class Initialized
DEBUG - 2011-10-13 10:41:13 --> Model Class Initialized
DEBUG - 2011-10-13 10:41:13 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-13 10:41:13 --> Database Driver Class Initialized
DEBUG - 2011-10-13 10:41:13 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-13 10:41:13 --> Helper loaded: url_helper
DEBUG - 2011-10-13 10:41:13 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-13 10:41:13 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-13 10:41:13 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-13 10:41:13 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-13 10:41:13 --> Final output sent to browser
DEBUG - 2011-10-13 10:41:13 --> Total execution time: 0.0449
DEBUG - 2011-10-13 10:41:14 --> Config Class Initialized
DEBUG - 2011-10-13 10:41:14 --> Hooks Class Initialized
DEBUG - 2011-10-13 10:41:14 --> Utf8 Class Initialized
DEBUG - 2011-10-13 10:41:14 --> UTF-8 Support Enabled
DEBUG - 2011-10-13 10:41:14 --> URI Class Initialized
DEBUG - 2011-10-13 10:41:14 --> Router Class Initialized
DEBUG - 2011-10-13 10:41:14 --> Output Class Initialized
DEBUG - 2011-10-13 10:41:14 --> Input Class Initialized
DEBUG - 2011-10-13 10:41:14 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-13 10:41:14 --> Language Class Initialized
DEBUG - 2011-10-13 10:41:14 --> Loader Class Initialized
DEBUG - 2011-10-13 10:41:14 --> Controller Class Initialized
DEBUG - 2011-10-13 10:41:14 --> Model Class Initialized
DEBUG - 2011-10-13 10:41:14 --> Model Class Initialized
DEBUG - 2011-10-13 10:41:14 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-13 10:41:14 --> Database Driver Class Initialized
DEBUG - 2011-10-13 10:41:15 --> Final output sent to browser
DEBUG - 2011-10-13 10:41:15 --> Total execution time: 0.7788
DEBUG - 2011-10-13 10:41:15 --> Config Class Initialized
DEBUG - 2011-10-13 10:41:15 --> Hooks Class Initialized
DEBUG - 2011-10-13 10:41:15 --> Utf8 Class Initialized
DEBUG - 2011-10-13 10:41:15 --> UTF-8 Support Enabled
DEBUG - 2011-10-13 10:41:15 --> URI Class Initialized
DEBUG - 2011-10-13 10:41:15 --> Router Class Initialized
DEBUG - 2011-10-13 10:41:15 --> Output Class Initialized
DEBUG - 2011-10-13 10:41:15 --> Input Class Initialized
DEBUG - 2011-10-13 10:41:15 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-13 10:41:15 --> Language Class Initialized
DEBUG - 2011-10-13 10:41:15 --> Loader Class Initialized
DEBUG - 2011-10-13 10:41:15 --> Controller Class Initialized
ERROR - 2011-10-13 10:41:15 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-10-13 10:41:15 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-10-13 10:41:15 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-13 10:41:15 --> Model Class Initialized
DEBUG - 2011-10-13 10:41:15 --> Model Class Initialized
DEBUG - 2011-10-13 10:41:15 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-13 10:41:15 --> Database Driver Class Initialized
DEBUG - 2011-10-13 10:41:15 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-13 10:41:15 --> Helper loaded: url_helper
DEBUG - 2011-10-13 10:41:15 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-13 10:41:15 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-13 10:41:15 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-13 10:41:15 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-13 10:41:15 --> Final output sent to browser
DEBUG - 2011-10-13 10:41:15 --> Total execution time: 0.0314
DEBUG - 2011-10-13 10:41:17 --> Config Class Initialized
DEBUG - 2011-10-13 10:41:17 --> Hooks Class Initialized
DEBUG - 2011-10-13 10:41:17 --> Utf8 Class Initialized
DEBUG - 2011-10-13 10:41:17 --> UTF-8 Support Enabled
DEBUG - 2011-10-13 10:41:17 --> URI Class Initialized
DEBUG - 2011-10-13 10:41:17 --> Router Class Initialized
ERROR - 2011-10-13 10:41:17 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-13 10:41:21 --> Config Class Initialized
DEBUG - 2011-10-13 10:41:21 --> Hooks Class Initialized
DEBUG - 2011-10-13 10:41:21 --> Utf8 Class Initialized
DEBUG - 2011-10-13 10:41:21 --> UTF-8 Support Enabled
DEBUG - 2011-10-13 10:41:21 --> URI Class Initialized
DEBUG - 2011-10-13 10:41:21 --> Router Class Initialized
DEBUG - 2011-10-13 10:41:21 --> Output Class Initialized
DEBUG - 2011-10-13 10:41:21 --> Input Class Initialized
DEBUG - 2011-10-13 10:41:21 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-13 10:41:21 --> Language Class Initialized
DEBUG - 2011-10-13 10:41:21 --> Loader Class Initialized
DEBUG - 2011-10-13 10:41:21 --> Controller Class Initialized
ERROR - 2011-10-13 10:41:21 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-10-13 10:41:21 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-10-13 10:41:21 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-13 10:41:21 --> Model Class Initialized
DEBUG - 2011-10-13 10:41:21 --> Model Class Initialized
DEBUG - 2011-10-13 10:41:21 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-13 10:41:21 --> Database Driver Class Initialized
DEBUG - 2011-10-13 10:41:21 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-13 10:41:21 --> Helper loaded: url_helper
DEBUG - 2011-10-13 10:41:21 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-13 10:41:21 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-13 10:41:21 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-13 10:41:21 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-13 10:41:21 --> Final output sent to browser
DEBUG - 2011-10-13 10:41:21 --> Total execution time: 0.0433
DEBUG - 2011-10-13 10:41:22 --> Config Class Initialized
DEBUG - 2011-10-13 10:41:22 --> Hooks Class Initialized
DEBUG - 2011-10-13 10:41:22 --> Utf8 Class Initialized
DEBUG - 2011-10-13 10:41:22 --> UTF-8 Support Enabled
DEBUG - 2011-10-13 10:41:22 --> URI Class Initialized
DEBUG - 2011-10-13 10:41:22 --> Router Class Initialized
DEBUG - 2011-10-13 10:41:22 --> Output Class Initialized
DEBUG - 2011-10-13 10:41:22 --> Input Class Initialized
DEBUG - 2011-10-13 10:41:22 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-13 10:41:22 --> Language Class Initialized
DEBUG - 2011-10-13 10:41:22 --> Loader Class Initialized
DEBUG - 2011-10-13 10:41:22 --> Controller Class Initialized
DEBUG - 2011-10-13 10:41:22 --> Model Class Initialized
DEBUG - 2011-10-13 10:41:22 --> Model Class Initialized
DEBUG - 2011-10-13 10:41:22 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-13 10:41:22 --> Database Driver Class Initialized
DEBUG - 2011-10-13 10:41:23 --> Final output sent to browser
DEBUG - 2011-10-13 10:41:23 --> Total execution time: 0.5242
DEBUG - 2011-10-13 10:41:25 --> Config Class Initialized
DEBUG - 2011-10-13 10:41:25 --> Hooks Class Initialized
DEBUG - 2011-10-13 10:41:25 --> Utf8 Class Initialized
DEBUG - 2011-10-13 10:41:25 --> UTF-8 Support Enabled
DEBUG - 2011-10-13 10:41:25 --> URI Class Initialized
DEBUG - 2011-10-13 10:41:25 --> Router Class Initialized
ERROR - 2011-10-13 10:41:25 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-13 10:45:52 --> Config Class Initialized
DEBUG - 2011-10-13 10:45:52 --> Hooks Class Initialized
DEBUG - 2011-10-13 10:45:52 --> Utf8 Class Initialized
DEBUG - 2011-10-13 10:45:52 --> UTF-8 Support Enabled
DEBUG - 2011-10-13 10:45:52 --> URI Class Initialized
DEBUG - 2011-10-13 10:45:52 --> Router Class Initialized
DEBUG - 2011-10-13 10:45:52 --> Output Class Initialized
DEBUG - 2011-10-13 10:45:52 --> Input Class Initialized
DEBUG - 2011-10-13 10:45:52 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-13 10:45:52 --> Language Class Initialized
DEBUG - 2011-10-13 10:45:52 --> Loader Class Initialized
DEBUG - 2011-10-13 10:45:52 --> Controller Class Initialized
ERROR - 2011-10-13 10:45:52 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-10-13 10:45:52 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-10-13 10:45:52 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-13 10:45:52 --> Model Class Initialized
DEBUG - 2011-10-13 10:45:52 --> Model Class Initialized
DEBUG - 2011-10-13 10:45:52 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-13 10:45:52 --> Database Driver Class Initialized
DEBUG - 2011-10-13 10:45:52 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-13 10:45:52 --> Helper loaded: url_helper
DEBUG - 2011-10-13 10:45:52 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-13 10:45:52 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-13 10:45:52 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-13 10:45:52 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-13 10:45:52 --> Final output sent to browser
DEBUG - 2011-10-13 10:45:52 --> Total execution time: 0.0457
DEBUG - 2011-10-13 10:45:53 --> Config Class Initialized
DEBUG - 2011-10-13 10:45:53 --> Hooks Class Initialized
DEBUG - 2011-10-13 10:45:53 --> Utf8 Class Initialized
DEBUG - 2011-10-13 10:45:53 --> UTF-8 Support Enabled
DEBUG - 2011-10-13 10:45:53 --> URI Class Initialized
DEBUG - 2011-10-13 10:45:53 --> Router Class Initialized
DEBUG - 2011-10-13 10:45:53 --> Output Class Initialized
DEBUG - 2011-10-13 10:45:53 --> Input Class Initialized
DEBUG - 2011-10-13 10:45:53 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-13 10:45:53 --> Language Class Initialized
DEBUG - 2011-10-13 10:45:53 --> Loader Class Initialized
DEBUG - 2011-10-13 10:45:53 --> Controller Class Initialized
DEBUG - 2011-10-13 10:45:53 --> Model Class Initialized
DEBUG - 2011-10-13 10:45:53 --> Model Class Initialized
DEBUG - 2011-10-13 10:45:53 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-13 10:45:53 --> Database Driver Class Initialized
DEBUG - 2011-10-13 10:45:53 --> Final output sent to browser
DEBUG - 2011-10-13 10:45:53 --> Total execution time: 0.5322
DEBUG - 2011-10-13 12:38:13 --> Config Class Initialized
DEBUG - 2011-10-13 12:38:13 --> Hooks Class Initialized
DEBUG - 2011-10-13 12:38:13 --> Utf8 Class Initialized
DEBUG - 2011-10-13 12:38:13 --> UTF-8 Support Enabled
DEBUG - 2011-10-13 12:38:13 --> URI Class Initialized
DEBUG - 2011-10-13 12:38:13 --> Router Class Initialized
ERROR - 2011-10-13 12:38:13 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-10-13 14:07:50 --> Config Class Initialized
DEBUG - 2011-10-13 14:07:50 --> Hooks Class Initialized
DEBUG - 2011-10-13 14:07:50 --> Utf8 Class Initialized
DEBUG - 2011-10-13 14:07:50 --> UTF-8 Support Enabled
DEBUG - 2011-10-13 14:07:50 --> URI Class Initialized
DEBUG - 2011-10-13 14:07:50 --> Router Class Initialized
DEBUG - 2011-10-13 14:07:50 --> No URI present. Default controller set.
DEBUG - 2011-10-13 14:07:50 --> Output Class Initialized
DEBUG - 2011-10-13 14:07:50 --> Input Class Initialized
DEBUG - 2011-10-13 14:07:50 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-13 14:07:50 --> Language Class Initialized
DEBUG - 2011-10-13 14:07:50 --> Loader Class Initialized
DEBUG - 2011-10-13 14:07:50 --> Controller Class Initialized
DEBUG - 2011-10-13 14:07:50 --> File loaded: application/views/splash/main.php
DEBUG - 2011-10-13 14:07:50 --> Helper loaded: url_helper
DEBUG - 2011-10-13 14:07:50 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-13 14:07:50 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-13 14:07:50 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-13 14:07:50 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-13 14:07:50 --> Final output sent to browser
DEBUG - 2011-10-13 14:07:50 --> Total execution time: 0.1189
DEBUG - 2011-10-13 15:46:29 --> Config Class Initialized
DEBUG - 2011-10-13 15:46:29 --> Hooks Class Initialized
DEBUG - 2011-10-13 15:46:29 --> Utf8 Class Initialized
DEBUG - 2011-10-13 15:46:29 --> UTF-8 Support Enabled
DEBUG - 2011-10-13 15:46:29 --> URI Class Initialized
DEBUG - 2011-10-13 15:46:29 --> Router Class Initialized
DEBUG - 2011-10-13 15:46:29 --> Output Class Initialized
DEBUG - 2011-10-13 15:46:29 --> Input Class Initialized
DEBUG - 2011-10-13 15:46:29 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-13 15:46:29 --> Language Class Initialized
DEBUG - 2011-10-13 15:46:29 --> Loader Class Initialized
DEBUG - 2011-10-13 15:46:29 --> Controller Class Initialized
ERROR - 2011-10-13 15:46:29 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-10-13 15:46:29 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-10-13 15:46:29 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-13 15:46:29 --> Model Class Initialized
DEBUG - 2011-10-13 15:46:29 --> Model Class Initialized
DEBUG - 2011-10-13 15:46:29 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-13 15:46:29 --> Database Driver Class Initialized
DEBUG - 2011-10-13 15:46:30 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-13 15:46:30 --> Helper loaded: url_helper
DEBUG - 2011-10-13 15:46:30 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-13 15:46:30 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-13 15:46:30 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-13 15:46:30 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-13 15:46:30 --> Final output sent to browser
DEBUG - 2011-10-13 15:46:30 --> Total execution time: 0.5642
DEBUG - 2011-10-13 15:46:31 --> Config Class Initialized
DEBUG - 2011-10-13 15:46:31 --> Hooks Class Initialized
DEBUG - 2011-10-13 15:46:31 --> Utf8 Class Initialized
DEBUG - 2011-10-13 15:46:31 --> UTF-8 Support Enabled
DEBUG - 2011-10-13 15:46:31 --> URI Class Initialized
DEBUG - 2011-10-13 15:46:31 --> Router Class Initialized
DEBUG - 2011-10-13 15:46:31 --> Output Class Initialized
DEBUG - 2011-10-13 15:46:31 --> Input Class Initialized
DEBUG - 2011-10-13 15:46:31 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-13 15:46:31 --> Language Class Initialized
DEBUG - 2011-10-13 15:46:31 --> Loader Class Initialized
DEBUG - 2011-10-13 15:46:31 --> Controller Class Initialized
DEBUG - 2011-10-13 15:46:31 --> Model Class Initialized
DEBUG - 2011-10-13 15:46:31 --> Model Class Initialized
DEBUG - 2011-10-13 15:46:31 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-13 15:46:31 --> Database Driver Class Initialized
DEBUG - 2011-10-13 15:46:32 --> Final output sent to browser
DEBUG - 2011-10-13 15:46:32 --> Total execution time: 0.8618
DEBUG - 2011-10-13 15:46:33 --> Config Class Initialized
DEBUG - 2011-10-13 15:46:33 --> Hooks Class Initialized
DEBUG - 2011-10-13 15:46:33 --> Utf8 Class Initialized
DEBUG - 2011-10-13 15:46:33 --> UTF-8 Support Enabled
DEBUG - 2011-10-13 15:46:33 --> URI Class Initialized
DEBUG - 2011-10-13 15:46:33 --> Router Class Initialized
ERROR - 2011-10-13 15:46:33 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-13 17:53:40 --> Config Class Initialized
DEBUG - 2011-10-13 17:53:40 --> Hooks Class Initialized
DEBUG - 2011-10-13 17:53:40 --> Utf8 Class Initialized
DEBUG - 2011-10-13 17:53:40 --> UTF-8 Support Enabled
DEBUG - 2011-10-13 17:53:40 --> URI Class Initialized
DEBUG - 2011-10-13 17:53:40 --> Router Class Initialized
DEBUG - 2011-10-13 17:53:40 --> Output Class Initialized
DEBUG - 2011-10-13 17:53:40 --> Input Class Initialized
DEBUG - 2011-10-13 17:53:40 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-13 17:53:40 --> Language Class Initialized
DEBUG - 2011-10-13 17:53:40 --> Loader Class Initialized
DEBUG - 2011-10-13 17:53:40 --> Controller Class Initialized
ERROR - 2011-10-13 17:53:40 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-10-13 17:53:40 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-10-13 17:53:40 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-13 17:53:40 --> Model Class Initialized
DEBUG - 2011-10-13 17:53:40 --> Model Class Initialized
DEBUG - 2011-10-13 17:53:40 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-13 17:53:40 --> Database Driver Class Initialized
DEBUG - 2011-10-13 17:53:42 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-13 17:53:42 --> Helper loaded: url_helper
DEBUG - 2011-10-13 17:53:42 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-13 17:53:42 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-13 17:53:42 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-13 17:53:42 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-13 17:53:42 --> Final output sent to browser
DEBUG - 2011-10-13 17:53:42 --> Total execution time: 2.1112
DEBUG - 2011-10-13 21:26:04 --> Config Class Initialized
DEBUG - 2011-10-13 21:26:04 --> Hooks Class Initialized
DEBUG - 2011-10-13 21:26:04 --> Utf8 Class Initialized
DEBUG - 2011-10-13 21:26:04 --> UTF-8 Support Enabled
DEBUG - 2011-10-13 21:26:04 --> URI Class Initialized
DEBUG - 2011-10-13 21:26:04 --> Router Class Initialized
DEBUG - 2011-10-13 21:26:04 --> No URI present. Default controller set.
DEBUG - 2011-10-13 21:26:04 --> Output Class Initialized
DEBUG - 2011-10-13 21:26:04 --> Input Class Initialized
DEBUG - 2011-10-13 21:26:04 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-13 21:26:04 --> Language Class Initialized
DEBUG - 2011-10-13 21:26:04 --> Loader Class Initialized
DEBUG - 2011-10-13 21:26:04 --> Controller Class Initialized
DEBUG - 2011-10-13 21:26:04 --> File loaded: application/views/splash/main.php
DEBUG - 2011-10-13 21:26:04 --> Helper loaded: url_helper
DEBUG - 2011-10-13 21:26:04 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-13 21:26:04 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-13 21:26:04 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-13 21:26:04 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-13 21:26:04 --> Final output sent to browser
DEBUG - 2011-10-13 21:26:04 --> Total execution time: 0.1990
DEBUG - 2011-10-13 23:59:52 --> Config Class Initialized
DEBUG - 2011-10-13 23:59:52 --> Hooks Class Initialized
DEBUG - 2011-10-13 23:59:52 --> Utf8 Class Initialized
DEBUG - 2011-10-13 23:59:52 --> UTF-8 Support Enabled
DEBUG - 2011-10-13 23:59:52 --> URI Class Initialized
DEBUG - 2011-10-13 23:59:52 --> Router Class Initialized
ERROR - 2011-10-13 23:59:52 --> 404 Page Not Found --> robots.txt

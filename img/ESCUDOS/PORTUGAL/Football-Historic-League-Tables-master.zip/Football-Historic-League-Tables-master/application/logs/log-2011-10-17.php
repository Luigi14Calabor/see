<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2011-10-17 00:43:02 --> Config Class Initialized
DEBUG - 2011-10-17 00:43:02 --> Hooks Class Initialized
DEBUG - 2011-10-17 00:43:02 --> Utf8 Class Initialized
DEBUG - 2011-10-17 00:43:02 --> UTF-8 Support Enabled
DEBUG - 2011-10-17 00:43:02 --> URI Class Initialized
DEBUG - 2011-10-17 00:43:02 --> Router Class Initialized
DEBUG - 2011-10-17 00:43:02 --> No URI present. Default controller set.
DEBUG - 2011-10-17 00:43:02 --> Output Class Initialized
DEBUG - 2011-10-17 00:43:02 --> Input Class Initialized
DEBUG - 2011-10-17 00:43:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-17 00:43:02 --> Language Class Initialized
DEBUG - 2011-10-17 00:43:02 --> Loader Class Initialized
DEBUG - 2011-10-17 00:43:02 --> Controller Class Initialized
DEBUG - 2011-10-17 00:43:02 --> File loaded: application/views/splash/main.php
DEBUG - 2011-10-17 00:43:02 --> Helper loaded: url_helper
DEBUG - 2011-10-17 00:43:02 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-17 00:43:02 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-17 00:43:02 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-17 00:43:02 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-17 00:43:02 --> Final output sent to browser
DEBUG - 2011-10-17 00:43:02 --> Total execution time: 0.6244
DEBUG - 2011-10-17 00:43:58 --> Config Class Initialized
DEBUG - 2011-10-17 00:43:58 --> Hooks Class Initialized
DEBUG - 2011-10-17 00:43:58 --> Utf8 Class Initialized
DEBUG - 2011-10-17 00:43:58 --> UTF-8 Support Enabled
DEBUG - 2011-10-17 00:43:58 --> URI Class Initialized
DEBUG - 2011-10-17 00:43:58 --> Router Class Initialized
DEBUG - 2011-10-17 00:43:58 --> Output Class Initialized
DEBUG - 2011-10-17 00:43:58 --> Input Class Initialized
DEBUG - 2011-10-17 00:43:58 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-17 00:43:58 --> Language Class Initialized
DEBUG - 2011-10-17 00:43:58 --> Loader Class Initialized
DEBUG - 2011-10-17 00:43:58 --> Controller Class Initialized
ERROR - 2011-10-17 00:43:58 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-10-17 00:43:58 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-10-17 00:43:58 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-17 00:43:58 --> Model Class Initialized
DEBUG - 2011-10-17 00:43:58 --> Model Class Initialized
DEBUG - 2011-10-17 00:43:58 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-17 00:43:58 --> Database Driver Class Initialized
DEBUG - 2011-10-17 00:43:59 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-17 00:43:59 --> Helper loaded: url_helper
DEBUG - 2011-10-17 00:43:59 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-17 00:43:59 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-17 00:43:59 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-17 00:43:59 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-17 00:43:59 --> Final output sent to browser
DEBUG - 2011-10-17 00:43:59 --> Total execution time: 0.6733
DEBUG - 2011-10-17 00:44:01 --> Config Class Initialized
DEBUG - 2011-10-17 00:44:01 --> Hooks Class Initialized
DEBUG - 2011-10-17 00:44:01 --> Utf8 Class Initialized
DEBUG - 2011-10-17 00:44:01 --> UTF-8 Support Enabled
DEBUG - 2011-10-17 00:44:01 --> URI Class Initialized
DEBUG - 2011-10-17 00:44:01 --> Router Class Initialized
DEBUG - 2011-10-17 00:44:01 --> Output Class Initialized
DEBUG - 2011-10-17 00:44:01 --> Input Class Initialized
DEBUG - 2011-10-17 00:44:01 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-17 00:44:01 --> Language Class Initialized
DEBUG - 2011-10-17 00:44:01 --> Loader Class Initialized
DEBUG - 2011-10-17 00:44:01 --> Controller Class Initialized
DEBUG - 2011-10-17 00:44:01 --> Model Class Initialized
DEBUG - 2011-10-17 00:44:02 --> Model Class Initialized
DEBUG - 2011-10-17 00:44:02 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-17 00:44:02 --> Database Driver Class Initialized
DEBUG - 2011-10-17 00:44:02 --> Final output sent to browser
DEBUG - 2011-10-17 00:44:02 --> Total execution time: 1.0166
DEBUG - 2011-10-17 00:44:05 --> Config Class Initialized
DEBUG - 2011-10-17 00:44:05 --> Hooks Class Initialized
DEBUG - 2011-10-17 00:44:05 --> Utf8 Class Initialized
DEBUG - 2011-10-17 00:44:05 --> UTF-8 Support Enabled
DEBUG - 2011-10-17 00:44:05 --> URI Class Initialized
DEBUG - 2011-10-17 00:44:05 --> Router Class Initialized
ERROR - 2011-10-17 00:44:05 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-17 00:44:32 --> Config Class Initialized
DEBUG - 2011-10-17 00:44:32 --> Hooks Class Initialized
DEBUG - 2011-10-17 00:44:32 --> Utf8 Class Initialized
DEBUG - 2011-10-17 00:44:32 --> UTF-8 Support Enabled
DEBUG - 2011-10-17 00:44:32 --> URI Class Initialized
DEBUG - 2011-10-17 00:44:32 --> Router Class Initialized
DEBUG - 2011-10-17 00:44:32 --> Output Class Initialized
DEBUG - 2011-10-17 00:44:32 --> Input Class Initialized
DEBUG - 2011-10-17 00:44:32 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-17 00:44:32 --> Language Class Initialized
DEBUG - 2011-10-17 00:44:32 --> Loader Class Initialized
DEBUG - 2011-10-17 00:44:32 --> Controller Class Initialized
ERROR - 2011-10-17 00:44:32 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-10-17 00:44:32 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-10-17 00:44:32 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-17 00:44:32 --> Model Class Initialized
DEBUG - 2011-10-17 00:44:32 --> Model Class Initialized
DEBUG - 2011-10-17 00:44:32 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-17 00:44:32 --> Database Driver Class Initialized
DEBUG - 2011-10-17 00:44:32 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-17 00:44:32 --> Helper loaded: url_helper
DEBUG - 2011-10-17 00:44:32 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-17 00:44:32 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-17 00:44:32 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-17 00:44:32 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-17 00:44:32 --> Final output sent to browser
DEBUG - 2011-10-17 00:44:32 --> Total execution time: 0.0344
DEBUG - 2011-10-17 00:44:34 --> Config Class Initialized
DEBUG - 2011-10-17 00:44:34 --> Hooks Class Initialized
DEBUG - 2011-10-17 00:44:34 --> Utf8 Class Initialized
DEBUG - 2011-10-17 00:44:34 --> UTF-8 Support Enabled
DEBUG - 2011-10-17 00:44:34 --> URI Class Initialized
DEBUG - 2011-10-17 00:44:34 --> Router Class Initialized
DEBUG - 2011-10-17 00:44:34 --> Output Class Initialized
DEBUG - 2011-10-17 00:44:34 --> Input Class Initialized
DEBUG - 2011-10-17 00:44:34 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-17 00:44:34 --> Language Class Initialized
DEBUG - 2011-10-17 00:44:34 --> Loader Class Initialized
DEBUG - 2011-10-17 00:44:34 --> Controller Class Initialized
DEBUG - 2011-10-17 00:44:34 --> Model Class Initialized
DEBUG - 2011-10-17 00:44:34 --> Model Class Initialized
DEBUG - 2011-10-17 00:44:34 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-17 00:44:34 --> Database Driver Class Initialized
DEBUG - 2011-10-17 00:44:34 --> Final output sent to browser
DEBUG - 2011-10-17 00:44:34 --> Total execution time: 0.5059
DEBUG - 2011-10-17 00:44:37 --> Config Class Initialized
DEBUG - 2011-10-17 00:44:37 --> Hooks Class Initialized
DEBUG - 2011-10-17 00:44:37 --> Utf8 Class Initialized
DEBUG - 2011-10-17 00:44:37 --> UTF-8 Support Enabled
DEBUG - 2011-10-17 00:44:37 --> URI Class Initialized
DEBUG - 2011-10-17 00:44:37 --> Router Class Initialized
ERROR - 2011-10-17 00:44:37 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-17 01:01:43 --> Config Class Initialized
DEBUG - 2011-10-17 01:01:43 --> Hooks Class Initialized
DEBUG - 2011-10-17 01:01:43 --> Utf8 Class Initialized
DEBUG - 2011-10-17 01:01:43 --> UTF-8 Support Enabled
DEBUG - 2011-10-17 01:01:43 --> URI Class Initialized
DEBUG - 2011-10-17 01:01:43 --> Router Class Initialized
DEBUG - 2011-10-17 01:01:43 --> Output Class Initialized
DEBUG - 2011-10-17 01:01:43 --> Input Class Initialized
DEBUG - 2011-10-17 01:01:43 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-17 01:01:43 --> Language Class Initialized
DEBUG - 2011-10-17 01:01:43 --> Loader Class Initialized
DEBUG - 2011-10-17 01:01:43 --> Controller Class Initialized
ERROR - 2011-10-17 01:01:43 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-10-17 01:01:43 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-10-17 01:01:43 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-17 01:01:43 --> Model Class Initialized
DEBUG - 2011-10-17 01:01:43 --> Model Class Initialized
DEBUG - 2011-10-17 01:01:43 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-17 01:01:43 --> Database Driver Class Initialized
DEBUG - 2011-10-17 01:01:43 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-17 01:01:43 --> Helper loaded: url_helper
DEBUG - 2011-10-17 01:01:43 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-17 01:01:43 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-17 01:01:43 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-17 01:01:43 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-17 01:01:43 --> Final output sent to browser
DEBUG - 2011-10-17 01:01:43 --> Total execution time: 0.0991
DEBUG - 2011-10-17 01:01:46 --> Config Class Initialized
DEBUG - 2011-10-17 01:01:46 --> Hooks Class Initialized
DEBUG - 2011-10-17 01:01:46 --> Utf8 Class Initialized
DEBUG - 2011-10-17 01:01:46 --> UTF-8 Support Enabled
DEBUG - 2011-10-17 01:01:46 --> URI Class Initialized
DEBUG - 2011-10-17 01:01:46 --> Router Class Initialized
DEBUG - 2011-10-17 01:01:46 --> Output Class Initialized
DEBUG - 2011-10-17 01:01:46 --> Input Class Initialized
DEBUG - 2011-10-17 01:01:46 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-17 01:01:46 --> Language Class Initialized
DEBUG - 2011-10-17 01:01:46 --> Loader Class Initialized
DEBUG - 2011-10-17 01:01:46 --> Controller Class Initialized
DEBUG - 2011-10-17 01:01:46 --> Model Class Initialized
DEBUG - 2011-10-17 01:01:46 --> Model Class Initialized
DEBUG - 2011-10-17 01:01:46 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-17 01:01:46 --> Database Driver Class Initialized
DEBUG - 2011-10-17 01:01:47 --> Final output sent to browser
DEBUG - 2011-10-17 01:01:47 --> Total execution time: 0.5013
DEBUG - 2011-10-17 01:01:49 --> Config Class Initialized
DEBUG - 2011-10-17 01:01:49 --> Hooks Class Initialized
DEBUG - 2011-10-17 01:01:49 --> Utf8 Class Initialized
DEBUG - 2011-10-17 01:01:49 --> UTF-8 Support Enabled
DEBUG - 2011-10-17 01:01:49 --> URI Class Initialized
DEBUG - 2011-10-17 01:01:49 --> Router Class Initialized
ERROR - 2011-10-17 01:01:49 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-17 01:05:35 --> Config Class Initialized
DEBUG - 2011-10-17 01:05:35 --> Hooks Class Initialized
DEBUG - 2011-10-17 01:05:35 --> Utf8 Class Initialized
DEBUG - 2011-10-17 01:05:35 --> UTF-8 Support Enabled
DEBUG - 2011-10-17 01:05:35 --> URI Class Initialized
DEBUG - 2011-10-17 01:05:35 --> Router Class Initialized
DEBUG - 2011-10-17 01:05:35 --> Output Class Initialized
DEBUG - 2011-10-17 01:05:35 --> Input Class Initialized
DEBUG - 2011-10-17 01:05:35 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-17 01:05:35 --> Language Class Initialized
DEBUG - 2011-10-17 01:05:35 --> Loader Class Initialized
DEBUG - 2011-10-17 01:05:35 --> Controller Class Initialized
DEBUG - 2011-10-17 01:05:35 --> Model Class Initialized
DEBUG - 2011-10-17 01:05:35 --> Model Class Initialized
DEBUG - 2011-10-17 01:05:35 --> Model Class Initialized
DEBUG - 2011-10-17 01:05:35 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-17 01:05:35 --> Database Driver Class Initialized
DEBUG - 2011-10-17 01:05:35 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-17 01:05:35 --> Helper loaded: url_helper
DEBUG - 2011-10-17 01:05:35 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-17 01:05:35 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-17 01:05:35 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-17 01:05:35 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-17 01:05:35 --> Final output sent to browser
DEBUG - 2011-10-17 01:05:35 --> Total execution time: 0.4739
DEBUG - 2011-10-17 01:05:38 --> Config Class Initialized
DEBUG - 2011-10-17 01:05:38 --> Hooks Class Initialized
DEBUG - 2011-10-17 01:05:38 --> Utf8 Class Initialized
DEBUG - 2011-10-17 01:05:38 --> UTF-8 Support Enabled
DEBUG - 2011-10-17 01:05:38 --> URI Class Initialized
DEBUG - 2011-10-17 01:05:38 --> Router Class Initialized
ERROR - 2011-10-17 01:05:38 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-17 01:06:24 --> Config Class Initialized
DEBUG - 2011-10-17 01:06:24 --> Hooks Class Initialized
DEBUG - 2011-10-17 01:06:24 --> Utf8 Class Initialized
DEBUG - 2011-10-17 01:06:24 --> UTF-8 Support Enabled
DEBUG - 2011-10-17 01:06:24 --> URI Class Initialized
DEBUG - 2011-10-17 01:06:24 --> Router Class Initialized
DEBUG - 2011-10-17 01:06:24 --> Output Class Initialized
DEBUG - 2011-10-17 01:06:24 --> Input Class Initialized
DEBUG - 2011-10-17 01:06:24 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-17 01:06:24 --> Language Class Initialized
DEBUG - 2011-10-17 01:06:24 --> Loader Class Initialized
DEBUG - 2011-10-17 01:06:24 --> Controller Class Initialized
DEBUG - 2011-10-17 01:06:24 --> Model Class Initialized
DEBUG - 2011-10-17 01:06:24 --> Model Class Initialized
DEBUG - 2011-10-17 01:06:24 --> Model Class Initialized
DEBUG - 2011-10-17 01:06:24 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-17 01:06:24 --> Database Driver Class Initialized
DEBUG - 2011-10-17 01:06:24 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-17 01:06:24 --> Helper loaded: url_helper
DEBUG - 2011-10-17 01:06:24 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-17 01:06:24 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-17 01:06:24 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-17 01:06:24 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-17 01:06:24 --> Final output sent to browser
DEBUG - 2011-10-17 01:06:24 --> Total execution time: 0.4415
DEBUG - 2011-10-17 01:06:25 --> Config Class Initialized
DEBUG - 2011-10-17 01:06:25 --> Hooks Class Initialized
DEBUG - 2011-10-17 01:06:25 --> Utf8 Class Initialized
DEBUG - 2011-10-17 01:06:25 --> UTF-8 Support Enabled
DEBUG - 2011-10-17 01:06:25 --> URI Class Initialized
DEBUG - 2011-10-17 01:06:25 --> Router Class Initialized
ERROR - 2011-10-17 01:06:25 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-17 01:06:43 --> Config Class Initialized
DEBUG - 2011-10-17 01:06:43 --> Hooks Class Initialized
DEBUG - 2011-10-17 01:06:43 --> Utf8 Class Initialized
DEBUG - 2011-10-17 01:06:43 --> UTF-8 Support Enabled
DEBUG - 2011-10-17 01:06:43 --> URI Class Initialized
DEBUG - 2011-10-17 01:06:43 --> Router Class Initialized
DEBUG - 2011-10-17 01:06:43 --> Output Class Initialized
DEBUG - 2011-10-17 01:06:43 --> Input Class Initialized
DEBUG - 2011-10-17 01:06:43 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-17 01:06:43 --> Language Class Initialized
DEBUG - 2011-10-17 01:06:43 --> Loader Class Initialized
DEBUG - 2011-10-17 01:06:43 --> Controller Class Initialized
DEBUG - 2011-10-17 01:06:43 --> Model Class Initialized
DEBUG - 2011-10-17 01:06:43 --> Model Class Initialized
DEBUG - 2011-10-17 01:06:43 --> Model Class Initialized
DEBUG - 2011-10-17 01:06:43 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-17 01:06:43 --> Database Driver Class Initialized
DEBUG - 2011-10-17 01:06:44 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-17 01:06:44 --> Helper loaded: url_helper
DEBUG - 2011-10-17 01:06:44 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-17 01:06:44 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-17 01:06:44 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-17 01:06:44 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-17 01:06:44 --> Final output sent to browser
DEBUG - 2011-10-17 01:06:44 --> Total execution time: 1.1650
DEBUG - 2011-10-17 01:06:45 --> Config Class Initialized
DEBUG - 2011-10-17 01:06:45 --> Hooks Class Initialized
DEBUG - 2011-10-17 01:06:45 --> Utf8 Class Initialized
DEBUG - 2011-10-17 01:06:45 --> UTF-8 Support Enabled
DEBUG - 2011-10-17 01:06:45 --> URI Class Initialized
DEBUG - 2011-10-17 01:06:45 --> Router Class Initialized
ERROR - 2011-10-17 01:06:45 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-17 01:07:09 --> Config Class Initialized
DEBUG - 2011-10-17 01:07:09 --> Hooks Class Initialized
DEBUG - 2011-10-17 01:07:09 --> Utf8 Class Initialized
DEBUG - 2011-10-17 01:07:09 --> UTF-8 Support Enabled
DEBUG - 2011-10-17 01:07:09 --> URI Class Initialized
DEBUG - 2011-10-17 01:07:09 --> Router Class Initialized
DEBUG - 2011-10-17 01:07:09 --> Output Class Initialized
DEBUG - 2011-10-17 01:07:09 --> Input Class Initialized
DEBUG - 2011-10-17 01:07:09 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-17 01:07:09 --> Language Class Initialized
DEBUG - 2011-10-17 01:07:09 --> Loader Class Initialized
DEBUG - 2011-10-17 01:07:09 --> Controller Class Initialized
DEBUG - 2011-10-17 01:07:09 --> Model Class Initialized
DEBUG - 2011-10-17 01:07:09 --> Model Class Initialized
DEBUG - 2011-10-17 01:07:09 --> Model Class Initialized
DEBUG - 2011-10-17 01:07:09 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-17 01:07:09 --> Database Driver Class Initialized
DEBUG - 2011-10-17 01:07:09 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-17 01:07:09 --> Helper loaded: url_helper
DEBUG - 2011-10-17 01:07:09 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-17 01:07:09 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-17 01:07:09 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-17 01:07:09 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-17 01:07:09 --> Final output sent to browser
DEBUG - 2011-10-17 01:07:09 --> Total execution time: 0.2916
DEBUG - 2011-10-17 01:07:11 --> Config Class Initialized
DEBUG - 2011-10-17 01:07:11 --> Hooks Class Initialized
DEBUG - 2011-10-17 01:07:11 --> Utf8 Class Initialized
DEBUG - 2011-10-17 01:07:11 --> UTF-8 Support Enabled
DEBUG - 2011-10-17 01:07:11 --> URI Class Initialized
DEBUG - 2011-10-17 01:07:11 --> Router Class Initialized
ERROR - 2011-10-17 01:07:11 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-17 01:07:17 --> Config Class Initialized
DEBUG - 2011-10-17 01:07:17 --> Hooks Class Initialized
DEBUG - 2011-10-17 01:07:17 --> Utf8 Class Initialized
DEBUG - 2011-10-17 01:07:17 --> UTF-8 Support Enabled
DEBUG - 2011-10-17 01:07:17 --> URI Class Initialized
DEBUG - 2011-10-17 01:07:17 --> Router Class Initialized
DEBUG - 2011-10-17 01:07:17 --> Output Class Initialized
DEBUG - 2011-10-17 01:07:17 --> Input Class Initialized
DEBUG - 2011-10-17 01:07:17 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-17 01:07:17 --> Language Class Initialized
DEBUG - 2011-10-17 01:07:17 --> Loader Class Initialized
DEBUG - 2011-10-17 01:07:17 --> Controller Class Initialized
DEBUG - 2011-10-17 01:07:17 --> Model Class Initialized
DEBUG - 2011-10-17 01:07:17 --> Model Class Initialized
DEBUG - 2011-10-17 01:07:17 --> Model Class Initialized
DEBUG - 2011-10-17 01:07:17 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-17 01:07:17 --> Database Driver Class Initialized
DEBUG - 2011-10-17 01:07:17 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-17 01:07:17 --> Helper loaded: url_helper
DEBUG - 2011-10-17 01:07:17 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-17 01:07:17 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-17 01:07:17 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-17 01:07:17 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-17 01:07:17 --> Final output sent to browser
DEBUG - 2011-10-17 01:07:17 --> Total execution time: 0.0545
DEBUG - 2011-10-17 01:07:18 --> Config Class Initialized
DEBUG - 2011-10-17 01:07:18 --> Hooks Class Initialized
DEBUG - 2011-10-17 01:07:18 --> Utf8 Class Initialized
DEBUG - 2011-10-17 01:07:18 --> UTF-8 Support Enabled
DEBUG - 2011-10-17 01:07:18 --> URI Class Initialized
DEBUG - 2011-10-17 01:07:18 --> Router Class Initialized
DEBUG - 2011-10-17 01:07:18 --> Output Class Initialized
DEBUG - 2011-10-17 01:07:18 --> Input Class Initialized
DEBUG - 2011-10-17 01:07:18 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-17 01:07:18 --> Language Class Initialized
DEBUG - 2011-10-17 01:07:18 --> Loader Class Initialized
DEBUG - 2011-10-17 01:07:18 --> Controller Class Initialized
ERROR - 2011-10-17 01:07:18 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-10-17 01:07:18 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-10-17 01:07:18 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-17 01:07:18 --> Model Class Initialized
DEBUG - 2011-10-17 01:07:18 --> Model Class Initialized
DEBUG - 2011-10-17 01:07:18 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-17 01:07:18 --> Database Driver Class Initialized
DEBUG - 2011-10-17 01:07:18 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-17 01:07:18 --> Helper loaded: url_helper
DEBUG - 2011-10-17 01:07:18 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-17 01:07:18 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-17 01:07:18 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-17 01:07:18 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-17 01:07:18 --> Final output sent to browser
DEBUG - 2011-10-17 01:07:18 --> Total execution time: 0.0414
DEBUG - 2011-10-17 01:14:25 --> Config Class Initialized
DEBUG - 2011-10-17 01:14:25 --> Hooks Class Initialized
DEBUG - 2011-10-17 01:14:25 --> Utf8 Class Initialized
DEBUG - 2011-10-17 01:14:25 --> UTF-8 Support Enabled
DEBUG - 2011-10-17 01:14:25 --> URI Class Initialized
DEBUG - 2011-10-17 01:14:25 --> Router Class Initialized
ERROR - 2011-10-17 01:14:25 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-10-17 01:14:26 --> Config Class Initialized
DEBUG - 2011-10-17 01:14:26 --> Hooks Class Initialized
DEBUG - 2011-10-17 01:14:26 --> Utf8 Class Initialized
DEBUG - 2011-10-17 01:14:26 --> UTF-8 Support Enabled
DEBUG - 2011-10-17 01:14:26 --> URI Class Initialized
DEBUG - 2011-10-17 01:14:26 --> Router Class Initialized
DEBUG - 2011-10-17 01:14:26 --> Output Class Initialized
DEBUG - 2011-10-17 01:14:26 --> Input Class Initialized
DEBUG - 2011-10-17 01:14:26 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-17 01:14:26 --> Language Class Initialized
DEBUG - 2011-10-17 01:14:26 --> Loader Class Initialized
DEBUG - 2011-10-17 01:14:26 --> Controller Class Initialized
DEBUG - 2011-10-17 01:14:26 --> Model Class Initialized
DEBUG - 2011-10-17 01:14:26 --> Model Class Initialized
DEBUG - 2011-10-17 01:14:26 --> Model Class Initialized
DEBUG - 2011-10-17 01:14:26 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-17 01:14:26 --> Database Driver Class Initialized
DEBUG - 2011-10-17 01:14:26 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-17 01:14:26 --> Helper loaded: url_helper
DEBUG - 2011-10-17 01:14:26 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-17 01:14:26 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-17 01:14:26 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-17 01:14:26 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-17 01:14:26 --> Final output sent to browser
DEBUG - 2011-10-17 01:14:26 --> Total execution time: 0.1103
DEBUG - 2011-10-17 01:29:59 --> Config Class Initialized
DEBUG - 2011-10-17 01:29:59 --> Hooks Class Initialized
DEBUG - 2011-10-17 01:29:59 --> Utf8 Class Initialized
DEBUG - 2011-10-17 01:29:59 --> UTF-8 Support Enabled
DEBUG - 2011-10-17 01:29:59 --> URI Class Initialized
DEBUG - 2011-10-17 01:29:59 --> Router Class Initialized
DEBUG - 2011-10-17 01:29:59 --> Output Class Initialized
DEBUG - 2011-10-17 01:29:59 --> Input Class Initialized
DEBUG - 2011-10-17 01:29:59 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-17 01:29:59 --> Language Class Initialized
DEBUG - 2011-10-17 01:29:59 --> Loader Class Initialized
DEBUG - 2011-10-17 01:29:59 --> Controller Class Initialized
DEBUG - 2011-10-17 01:29:59 --> Model Class Initialized
DEBUG - 2011-10-17 01:29:59 --> Model Class Initialized
DEBUG - 2011-10-17 01:29:59 --> Model Class Initialized
DEBUG - 2011-10-17 01:29:59 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-17 01:29:59 --> Database Driver Class Initialized
DEBUG - 2011-10-17 01:29:59 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-17 01:29:59 --> Helper loaded: url_helper
DEBUG - 2011-10-17 01:29:59 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-17 01:29:59 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-17 01:29:59 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-17 01:29:59 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-17 01:29:59 --> Final output sent to browser
DEBUG - 2011-10-17 01:29:59 --> Total execution time: 0.0477
DEBUG - 2011-10-17 01:30:30 --> Config Class Initialized
DEBUG - 2011-10-17 01:30:30 --> Hooks Class Initialized
DEBUG - 2011-10-17 01:30:30 --> Utf8 Class Initialized
DEBUG - 2011-10-17 01:30:30 --> UTF-8 Support Enabled
DEBUG - 2011-10-17 01:30:30 --> URI Class Initialized
DEBUG - 2011-10-17 01:30:30 --> Router Class Initialized
DEBUG - 2011-10-17 01:30:30 --> Output Class Initialized
DEBUG - 2011-10-17 01:30:30 --> Input Class Initialized
DEBUG - 2011-10-17 01:30:30 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-17 01:30:30 --> Language Class Initialized
DEBUG - 2011-10-17 01:30:30 --> Loader Class Initialized
DEBUG - 2011-10-17 01:30:30 --> Controller Class Initialized
DEBUG - 2011-10-17 01:30:30 --> Model Class Initialized
DEBUG - 2011-10-17 01:30:30 --> Model Class Initialized
DEBUG - 2011-10-17 01:30:30 --> Model Class Initialized
DEBUG - 2011-10-17 01:30:30 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-17 01:30:30 --> Database Driver Class Initialized
DEBUG - 2011-10-17 01:30:30 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-17 01:30:30 --> Helper loaded: url_helper
DEBUG - 2011-10-17 01:30:30 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-17 01:30:30 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-17 01:30:30 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-17 01:30:30 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-17 01:30:30 --> Final output sent to browser
DEBUG - 2011-10-17 01:30:30 --> Total execution time: 0.0459
DEBUG - 2011-10-17 01:53:29 --> Config Class Initialized
DEBUG - 2011-10-17 01:53:29 --> Hooks Class Initialized
DEBUG - 2011-10-17 01:53:29 --> Utf8 Class Initialized
DEBUG - 2011-10-17 01:53:29 --> UTF-8 Support Enabled
DEBUG - 2011-10-17 01:53:29 --> URI Class Initialized
DEBUG - 2011-10-17 01:53:29 --> Router Class Initialized
DEBUG - 2011-10-17 01:53:29 --> Output Class Initialized
DEBUG - 2011-10-17 01:53:29 --> Input Class Initialized
DEBUG - 2011-10-17 01:53:29 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-17 01:53:29 --> Language Class Initialized
DEBUG - 2011-10-17 01:53:29 --> Loader Class Initialized
DEBUG - 2011-10-17 01:53:29 --> Controller Class Initialized
ERROR - 2011-10-17 01:53:29 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-10-17 01:53:29 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-10-17 01:53:29 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-17 01:53:29 --> Model Class Initialized
DEBUG - 2011-10-17 01:53:29 --> Model Class Initialized
DEBUG - 2011-10-17 01:53:29 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-17 01:53:29 --> Database Driver Class Initialized
DEBUG - 2011-10-17 01:53:30 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-17 01:53:30 --> Helper loaded: url_helper
DEBUG - 2011-10-17 01:53:30 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-17 01:53:30 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-17 01:53:30 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-17 01:53:30 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-17 01:53:30 --> Final output sent to browser
DEBUG - 2011-10-17 01:53:30 --> Total execution time: 1.3697
DEBUG - 2011-10-17 01:53:39 --> Config Class Initialized
DEBUG - 2011-10-17 01:53:39 --> Hooks Class Initialized
DEBUG - 2011-10-17 01:53:39 --> Utf8 Class Initialized
DEBUG - 2011-10-17 01:53:39 --> UTF-8 Support Enabled
DEBUG - 2011-10-17 01:53:39 --> URI Class Initialized
DEBUG - 2011-10-17 01:53:39 --> Router Class Initialized
DEBUG - 2011-10-17 01:53:39 --> Output Class Initialized
DEBUG - 2011-10-17 01:53:39 --> Input Class Initialized
DEBUG - 2011-10-17 01:53:39 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-17 01:53:39 --> Language Class Initialized
DEBUG - 2011-10-17 01:53:39 --> Loader Class Initialized
DEBUG - 2011-10-17 01:53:39 --> Controller Class Initialized
DEBUG - 2011-10-17 01:53:39 --> Model Class Initialized
DEBUG - 2011-10-17 01:53:39 --> Model Class Initialized
DEBUG - 2011-10-17 01:53:39 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-17 01:53:39 --> Database Driver Class Initialized
DEBUG - 2011-10-17 01:53:41 --> Final output sent to browser
DEBUG - 2011-10-17 01:53:41 --> Total execution time: 1.4979
DEBUG - 2011-10-17 01:54:08 --> Config Class Initialized
DEBUG - 2011-10-17 01:54:08 --> Hooks Class Initialized
DEBUG - 2011-10-17 01:54:08 --> Utf8 Class Initialized
DEBUG - 2011-10-17 01:54:08 --> UTF-8 Support Enabled
DEBUG - 2011-10-17 01:54:08 --> URI Class Initialized
DEBUG - 2011-10-17 01:54:08 --> Router Class Initialized
ERROR - 2011-10-17 01:54:08 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-17 01:54:10 --> Config Class Initialized
DEBUG - 2011-10-17 01:54:10 --> Hooks Class Initialized
DEBUG - 2011-10-17 01:54:10 --> Utf8 Class Initialized
DEBUG - 2011-10-17 01:54:10 --> UTF-8 Support Enabled
DEBUG - 2011-10-17 01:54:10 --> URI Class Initialized
DEBUG - 2011-10-17 01:54:10 --> Router Class Initialized
ERROR - 2011-10-17 01:54:11 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-17 01:54:13 --> Config Class Initialized
DEBUG - 2011-10-17 01:54:13 --> Hooks Class Initialized
DEBUG - 2011-10-17 01:54:13 --> Utf8 Class Initialized
DEBUG - 2011-10-17 01:54:13 --> UTF-8 Support Enabled
DEBUG - 2011-10-17 01:54:13 --> URI Class Initialized
DEBUG - 2011-10-17 01:54:13 --> Router Class Initialized
ERROR - 2011-10-17 01:54:13 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-17 02:49:34 --> Config Class Initialized
DEBUG - 2011-10-17 02:49:34 --> Hooks Class Initialized
DEBUG - 2011-10-17 02:49:34 --> Utf8 Class Initialized
DEBUG - 2011-10-17 02:49:34 --> UTF-8 Support Enabled
DEBUG - 2011-10-17 02:49:34 --> URI Class Initialized
DEBUG - 2011-10-17 02:49:34 --> Router Class Initialized
DEBUG - 2011-10-17 02:49:34 --> Output Class Initialized
DEBUG - 2011-10-17 02:49:34 --> Input Class Initialized
DEBUG - 2011-10-17 02:49:34 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-17 02:49:34 --> Language Class Initialized
DEBUG - 2011-10-17 02:49:34 --> Loader Class Initialized
DEBUG - 2011-10-17 02:49:34 --> Controller Class Initialized
DEBUG - 2011-10-17 02:49:34 --> Model Class Initialized
DEBUG - 2011-10-17 02:49:35 --> Model Class Initialized
DEBUG - 2011-10-17 02:49:35 --> Model Class Initialized
DEBUG - 2011-10-17 02:49:35 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-17 02:49:35 --> Database Driver Class Initialized
DEBUG - 2011-10-17 02:49:37 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-17 02:49:37 --> Helper loaded: url_helper
DEBUG - 2011-10-17 02:49:37 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-17 02:49:37 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-17 02:49:37 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-17 02:49:37 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-17 02:49:37 --> Final output sent to browser
DEBUG - 2011-10-17 02:49:37 --> Total execution time: 2.5657
DEBUG - 2011-10-17 02:49:39 --> Config Class Initialized
DEBUG - 2011-10-17 02:49:39 --> Hooks Class Initialized
DEBUG - 2011-10-17 02:49:39 --> Utf8 Class Initialized
DEBUG - 2011-10-17 02:49:39 --> UTF-8 Support Enabled
DEBUG - 2011-10-17 02:49:39 --> URI Class Initialized
DEBUG - 2011-10-17 02:49:39 --> Router Class Initialized
ERROR - 2011-10-17 02:49:39 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-17 02:49:40 --> Config Class Initialized
DEBUG - 2011-10-17 02:49:40 --> Hooks Class Initialized
DEBUG - 2011-10-17 02:49:40 --> Utf8 Class Initialized
DEBUG - 2011-10-17 02:49:40 --> UTF-8 Support Enabled
DEBUG - 2011-10-17 02:49:40 --> URI Class Initialized
DEBUG - 2011-10-17 02:49:40 --> Router Class Initialized
ERROR - 2011-10-17 02:49:40 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-17 02:49:41 --> Config Class Initialized
DEBUG - 2011-10-17 02:49:41 --> Hooks Class Initialized
DEBUG - 2011-10-17 02:49:41 --> Utf8 Class Initialized
DEBUG - 2011-10-17 02:49:41 --> UTF-8 Support Enabled
DEBUG - 2011-10-17 02:49:41 --> URI Class Initialized
DEBUG - 2011-10-17 02:49:41 --> Router Class Initialized
ERROR - 2011-10-17 02:49:41 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-17 02:49:42 --> Config Class Initialized
DEBUG - 2011-10-17 02:49:42 --> Hooks Class Initialized
DEBUG - 2011-10-17 02:49:42 --> Utf8 Class Initialized
DEBUG - 2011-10-17 02:49:42 --> UTF-8 Support Enabled
DEBUG - 2011-10-17 02:49:42 --> URI Class Initialized
DEBUG - 2011-10-17 02:49:42 --> Router Class Initialized
ERROR - 2011-10-17 02:49:42 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-17 03:44:56 --> Config Class Initialized
DEBUG - 2011-10-17 03:44:56 --> Hooks Class Initialized
DEBUG - 2011-10-17 03:44:56 --> Utf8 Class Initialized
DEBUG - 2011-10-17 03:44:56 --> UTF-8 Support Enabled
DEBUG - 2011-10-17 03:44:56 --> URI Class Initialized
DEBUG - 2011-10-17 03:44:56 --> Router Class Initialized
DEBUG - 2011-10-17 03:44:56 --> Output Class Initialized
DEBUG - 2011-10-17 03:44:56 --> Input Class Initialized
DEBUG - 2011-10-17 03:44:56 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-17 03:44:56 --> Language Class Initialized
DEBUG - 2011-10-17 03:44:56 --> Loader Class Initialized
DEBUG - 2011-10-17 03:44:56 --> Controller Class Initialized
ERROR - 2011-10-17 03:44:56 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-10-17 03:44:56 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-10-17 03:44:56 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-17 03:44:56 --> Model Class Initialized
DEBUG - 2011-10-17 03:44:56 --> Model Class Initialized
DEBUG - 2011-10-17 03:44:56 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-17 03:44:56 --> Database Driver Class Initialized
DEBUG - 2011-10-17 03:44:57 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-17 03:44:57 --> Helper loaded: url_helper
DEBUG - 2011-10-17 03:44:57 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-17 03:44:57 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-17 03:44:57 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-17 03:44:57 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-17 03:44:57 --> Final output sent to browser
DEBUG - 2011-10-17 03:44:57 --> Total execution time: 0.6232
DEBUG - 2011-10-17 03:44:58 --> Config Class Initialized
DEBUG - 2011-10-17 03:44:58 --> Hooks Class Initialized
DEBUG - 2011-10-17 03:44:58 --> Utf8 Class Initialized
DEBUG - 2011-10-17 03:44:58 --> UTF-8 Support Enabled
DEBUG - 2011-10-17 03:44:58 --> URI Class Initialized
DEBUG - 2011-10-17 03:44:58 --> Router Class Initialized
DEBUG - 2011-10-17 03:44:58 --> Output Class Initialized
DEBUG - 2011-10-17 03:44:58 --> Input Class Initialized
DEBUG - 2011-10-17 03:44:58 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-17 03:44:58 --> Language Class Initialized
DEBUG - 2011-10-17 03:44:58 --> Loader Class Initialized
DEBUG - 2011-10-17 03:44:58 --> Controller Class Initialized
DEBUG - 2011-10-17 03:44:58 --> Model Class Initialized
DEBUG - 2011-10-17 03:44:58 --> Model Class Initialized
DEBUG - 2011-10-17 03:44:58 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-17 03:44:58 --> Database Driver Class Initialized
DEBUG - 2011-10-17 03:44:59 --> Final output sent to browser
DEBUG - 2011-10-17 03:44:59 --> Total execution time: 0.7827
DEBUG - 2011-10-17 03:45:01 --> Config Class Initialized
DEBUG - 2011-10-17 03:45:01 --> Hooks Class Initialized
DEBUG - 2011-10-17 03:45:01 --> Utf8 Class Initialized
DEBUG - 2011-10-17 03:45:01 --> UTF-8 Support Enabled
DEBUG - 2011-10-17 03:45:01 --> URI Class Initialized
DEBUG - 2011-10-17 03:45:01 --> Router Class Initialized
ERROR - 2011-10-17 03:45:01 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-17 03:45:02 --> Config Class Initialized
DEBUG - 2011-10-17 03:45:02 --> Hooks Class Initialized
DEBUG - 2011-10-17 03:45:02 --> Utf8 Class Initialized
DEBUG - 2011-10-17 03:45:02 --> UTF-8 Support Enabled
DEBUG - 2011-10-17 03:45:02 --> URI Class Initialized
DEBUG - 2011-10-17 03:45:02 --> Router Class Initialized
ERROR - 2011-10-17 03:45:02 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-17 03:45:03 --> Config Class Initialized
DEBUG - 2011-10-17 03:45:03 --> Hooks Class Initialized
DEBUG - 2011-10-17 03:45:03 --> Utf8 Class Initialized
DEBUG - 2011-10-17 03:45:03 --> UTF-8 Support Enabled
DEBUG - 2011-10-17 03:45:03 --> URI Class Initialized
DEBUG - 2011-10-17 03:45:03 --> Router Class Initialized
ERROR - 2011-10-17 03:45:03 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-17 03:45:10 --> Config Class Initialized
DEBUG - 2011-10-17 03:45:10 --> Hooks Class Initialized
DEBUG - 2011-10-17 03:45:10 --> Utf8 Class Initialized
DEBUG - 2011-10-17 03:45:10 --> UTF-8 Support Enabled
DEBUG - 2011-10-17 03:45:10 --> URI Class Initialized
DEBUG - 2011-10-17 03:45:10 --> Router Class Initialized
DEBUG - 2011-10-17 03:45:10 --> Output Class Initialized
DEBUG - 2011-10-17 03:45:10 --> Input Class Initialized
DEBUG - 2011-10-17 03:45:10 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-17 03:45:10 --> Language Class Initialized
DEBUG - 2011-10-17 03:45:10 --> Loader Class Initialized
DEBUG - 2011-10-17 03:45:10 --> Controller Class Initialized
ERROR - 2011-10-17 03:45:10 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-10-17 03:45:10 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-10-17 03:45:10 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-17 03:45:10 --> Model Class Initialized
DEBUG - 2011-10-17 03:45:10 --> Model Class Initialized
DEBUG - 2011-10-17 03:45:10 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-17 03:45:10 --> Database Driver Class Initialized
DEBUG - 2011-10-17 03:45:10 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-17 03:45:10 --> Helper loaded: url_helper
DEBUG - 2011-10-17 03:45:10 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-17 03:45:10 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-17 03:45:10 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-17 03:45:10 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-17 03:45:10 --> Final output sent to browser
DEBUG - 2011-10-17 03:45:10 --> Total execution time: 0.0910
DEBUG - 2011-10-17 03:45:11 --> Config Class Initialized
DEBUG - 2011-10-17 03:45:11 --> Hooks Class Initialized
DEBUG - 2011-10-17 03:45:11 --> Utf8 Class Initialized
DEBUG - 2011-10-17 03:45:11 --> UTF-8 Support Enabled
DEBUG - 2011-10-17 03:45:11 --> URI Class Initialized
DEBUG - 2011-10-17 03:45:11 --> Router Class Initialized
DEBUG - 2011-10-17 03:45:11 --> Output Class Initialized
DEBUG - 2011-10-17 03:45:11 --> Input Class Initialized
DEBUG - 2011-10-17 03:45:11 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-17 03:45:11 --> Language Class Initialized
DEBUG - 2011-10-17 03:45:11 --> Loader Class Initialized
DEBUG - 2011-10-17 03:45:11 --> Controller Class Initialized
DEBUG - 2011-10-17 03:45:11 --> Model Class Initialized
DEBUG - 2011-10-17 03:45:11 --> Model Class Initialized
DEBUG - 2011-10-17 03:45:11 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-17 03:45:11 --> Database Driver Class Initialized
DEBUG - 2011-10-17 03:45:12 --> Final output sent to browser
DEBUG - 2011-10-17 03:45:12 --> Total execution time: 0.6544
DEBUG - 2011-10-17 04:31:28 --> Config Class Initialized
DEBUG - 2011-10-17 04:31:28 --> Hooks Class Initialized
DEBUG - 2011-10-17 04:31:28 --> Utf8 Class Initialized
DEBUG - 2011-10-17 04:31:28 --> UTF-8 Support Enabled
DEBUG - 2011-10-17 04:31:28 --> URI Class Initialized
DEBUG - 2011-10-17 04:31:28 --> Router Class Initialized
DEBUG - 2011-10-17 04:31:28 --> Output Class Initialized
DEBUG - 2011-10-17 04:31:28 --> Input Class Initialized
DEBUG - 2011-10-17 04:31:28 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-17 04:31:28 --> Language Class Initialized
DEBUG - 2011-10-17 04:31:28 --> Loader Class Initialized
DEBUG - 2011-10-17 04:31:28 --> Controller Class Initialized
DEBUG - 2011-10-17 04:31:28 --> Model Class Initialized
DEBUG - 2011-10-17 04:31:28 --> Model Class Initialized
DEBUG - 2011-10-17 04:31:28 --> Model Class Initialized
DEBUG - 2011-10-17 04:31:28 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-17 04:31:28 --> Database Driver Class Initialized
DEBUG - 2011-10-17 04:31:30 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-17 04:31:30 --> Helper loaded: url_helper
DEBUG - 2011-10-17 04:31:30 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-17 04:31:30 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-17 04:31:30 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-17 04:31:30 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-17 04:31:30 --> Final output sent to browser
DEBUG - 2011-10-17 04:31:30 --> Total execution time: 2.6917
DEBUG - 2011-10-17 04:57:23 --> Config Class Initialized
DEBUG - 2011-10-17 04:57:23 --> Hooks Class Initialized
DEBUG - 2011-10-17 04:57:23 --> Utf8 Class Initialized
DEBUG - 2011-10-17 04:57:23 --> UTF-8 Support Enabled
DEBUG - 2011-10-17 04:57:23 --> URI Class Initialized
DEBUG - 2011-10-17 04:57:23 --> Router Class Initialized
DEBUG - 2011-10-17 04:57:23 --> Output Class Initialized
DEBUG - 2011-10-17 04:57:23 --> Input Class Initialized
DEBUG - 2011-10-17 04:57:23 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-17 04:57:23 --> Language Class Initialized
DEBUG - 2011-10-17 04:57:23 --> Loader Class Initialized
DEBUG - 2011-10-17 04:57:23 --> Controller Class Initialized
DEBUG - 2011-10-17 04:57:23 --> Model Class Initialized
DEBUG - 2011-10-17 04:57:23 --> Model Class Initialized
DEBUG - 2011-10-17 04:57:23 --> Model Class Initialized
DEBUG - 2011-10-17 04:57:23 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-17 04:57:23 --> Database Driver Class Initialized
DEBUG - 2011-10-17 04:57:26 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-17 04:57:26 --> Helper loaded: url_helper
DEBUG - 2011-10-17 04:57:26 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-17 04:57:26 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-17 04:57:26 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-17 04:57:26 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-17 04:57:26 --> Final output sent to browser
DEBUG - 2011-10-17 04:57:26 --> Total execution time: 3.3668
DEBUG - 2011-10-17 04:58:24 --> Config Class Initialized
DEBUG - 2011-10-17 04:58:24 --> Hooks Class Initialized
DEBUG - 2011-10-17 04:58:24 --> Utf8 Class Initialized
DEBUG - 2011-10-17 04:58:24 --> UTF-8 Support Enabled
DEBUG - 2011-10-17 04:58:24 --> URI Class Initialized
DEBUG - 2011-10-17 04:58:24 --> Router Class Initialized
DEBUG - 2011-10-17 04:58:24 --> Output Class Initialized
DEBUG - 2011-10-17 04:58:24 --> Input Class Initialized
DEBUG - 2011-10-17 04:58:24 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-17 04:58:24 --> Language Class Initialized
DEBUG - 2011-10-17 04:58:24 --> Loader Class Initialized
DEBUG - 2011-10-17 04:58:24 --> Controller Class Initialized
DEBUG - 2011-10-17 04:58:24 --> Model Class Initialized
DEBUG - 2011-10-17 04:58:24 --> Model Class Initialized
DEBUG - 2011-10-17 04:58:24 --> Model Class Initialized
DEBUG - 2011-10-17 04:58:24 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-17 04:58:24 --> Database Driver Class Initialized
DEBUG - 2011-10-17 04:58:25 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-17 04:58:25 --> Helper loaded: url_helper
DEBUG - 2011-10-17 04:58:25 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-17 04:58:25 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-17 04:58:25 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-17 04:58:25 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-17 04:58:25 --> Final output sent to browser
DEBUG - 2011-10-17 04:58:25 --> Total execution time: 1.0505
DEBUG - 2011-10-17 04:58:27 --> Config Class Initialized
DEBUG - 2011-10-17 04:58:27 --> Hooks Class Initialized
DEBUG - 2011-10-17 04:58:27 --> Utf8 Class Initialized
DEBUG - 2011-10-17 04:58:27 --> UTF-8 Support Enabled
DEBUG - 2011-10-17 04:58:27 --> URI Class Initialized
DEBUG - 2011-10-17 04:58:27 --> Router Class Initialized
ERROR - 2011-10-17 04:58:27 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-17 04:58:28 --> Config Class Initialized
DEBUG - 2011-10-17 04:58:28 --> Hooks Class Initialized
DEBUG - 2011-10-17 04:58:28 --> Utf8 Class Initialized
DEBUG - 2011-10-17 04:58:28 --> UTF-8 Support Enabled
DEBUG - 2011-10-17 04:58:28 --> URI Class Initialized
DEBUG - 2011-10-17 04:58:28 --> Router Class Initialized
ERROR - 2011-10-17 04:58:28 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-17 04:58:50 --> Config Class Initialized
DEBUG - 2011-10-17 04:58:50 --> Hooks Class Initialized
DEBUG - 2011-10-17 04:58:50 --> Utf8 Class Initialized
DEBUG - 2011-10-17 04:58:50 --> UTF-8 Support Enabled
DEBUG - 2011-10-17 04:58:50 --> URI Class Initialized
DEBUG - 2011-10-17 04:58:50 --> Router Class Initialized
DEBUG - 2011-10-17 04:58:50 --> Output Class Initialized
DEBUG - 2011-10-17 04:58:50 --> Input Class Initialized
DEBUG - 2011-10-17 04:58:50 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-17 04:58:50 --> Language Class Initialized
DEBUG - 2011-10-17 04:58:50 --> Loader Class Initialized
DEBUG - 2011-10-17 04:58:50 --> Controller Class Initialized
DEBUG - 2011-10-17 04:58:50 --> Model Class Initialized
DEBUG - 2011-10-17 04:58:50 --> Model Class Initialized
DEBUG - 2011-10-17 04:58:50 --> Model Class Initialized
DEBUG - 2011-10-17 04:58:50 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-17 04:58:50 --> Database Driver Class Initialized
DEBUG - 2011-10-17 04:58:52 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-17 04:58:52 --> Helper loaded: url_helper
DEBUG - 2011-10-17 04:58:52 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-17 04:58:52 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-17 04:58:52 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-17 04:58:52 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-17 04:58:52 --> Final output sent to browser
DEBUG - 2011-10-17 04:58:52 --> Total execution time: 2.0510
DEBUG - 2011-10-17 05:01:27 --> Config Class Initialized
DEBUG - 2011-10-17 05:01:27 --> Hooks Class Initialized
DEBUG - 2011-10-17 05:01:27 --> Utf8 Class Initialized
DEBUG - 2011-10-17 05:01:27 --> UTF-8 Support Enabled
DEBUG - 2011-10-17 05:01:27 --> URI Class Initialized
DEBUG - 2011-10-17 05:01:27 --> Router Class Initialized
DEBUG - 2011-10-17 05:01:27 --> Output Class Initialized
DEBUG - 2011-10-17 05:01:27 --> Input Class Initialized
DEBUG - 2011-10-17 05:01:27 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-17 05:01:27 --> Language Class Initialized
DEBUG - 2011-10-17 05:01:27 --> Loader Class Initialized
DEBUG - 2011-10-17 05:01:27 --> Controller Class Initialized
DEBUG - 2011-10-17 05:01:27 --> Model Class Initialized
DEBUG - 2011-10-17 05:01:27 --> Model Class Initialized
DEBUG - 2011-10-17 05:01:27 --> Model Class Initialized
DEBUG - 2011-10-17 05:01:27 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-17 05:01:27 --> Database Driver Class Initialized
DEBUG - 2011-10-17 05:01:27 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-17 05:01:27 --> Helper loaded: url_helper
DEBUG - 2011-10-17 05:01:27 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-17 05:01:27 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-17 05:01:27 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-17 05:01:27 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-17 05:01:27 --> Final output sent to browser
DEBUG - 2011-10-17 05:01:27 --> Total execution time: 0.0417
DEBUG - 2011-10-17 05:01:32 --> Config Class Initialized
DEBUG - 2011-10-17 05:01:32 --> Hooks Class Initialized
DEBUG - 2011-10-17 05:01:32 --> Utf8 Class Initialized
DEBUG - 2011-10-17 05:01:32 --> UTF-8 Support Enabled
DEBUG - 2011-10-17 05:01:32 --> URI Class Initialized
DEBUG - 2011-10-17 05:01:32 --> Router Class Initialized
ERROR - 2011-10-17 05:01:32 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-17 05:01:32 --> Config Class Initialized
DEBUG - 2011-10-17 05:01:32 --> Hooks Class Initialized
DEBUG - 2011-10-17 05:01:32 --> Utf8 Class Initialized
DEBUG - 2011-10-17 05:01:32 --> UTF-8 Support Enabled
DEBUG - 2011-10-17 05:01:32 --> URI Class Initialized
DEBUG - 2011-10-17 05:01:32 --> Router Class Initialized
ERROR - 2011-10-17 05:01:32 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-17 05:12:08 --> Config Class Initialized
DEBUG - 2011-10-17 05:12:08 --> Hooks Class Initialized
DEBUG - 2011-10-17 05:12:08 --> Utf8 Class Initialized
DEBUG - 2011-10-17 05:12:08 --> UTF-8 Support Enabled
DEBUG - 2011-10-17 05:12:08 --> URI Class Initialized
DEBUG - 2011-10-17 05:12:08 --> Router Class Initialized
DEBUG - 2011-10-17 05:12:08 --> Output Class Initialized
DEBUG - 2011-10-17 05:12:08 --> Input Class Initialized
DEBUG - 2011-10-17 05:12:08 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-17 05:12:08 --> Language Class Initialized
DEBUG - 2011-10-17 05:12:08 --> Loader Class Initialized
DEBUG - 2011-10-17 05:12:08 --> Controller Class Initialized
ERROR - 2011-10-17 05:12:08 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-10-17 05:12:08 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-10-17 05:12:08 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-17 05:12:08 --> Model Class Initialized
DEBUG - 2011-10-17 05:12:08 --> Model Class Initialized
DEBUG - 2011-10-17 05:12:08 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-17 05:12:08 --> Database Driver Class Initialized
DEBUG - 2011-10-17 05:12:08 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-17 05:12:08 --> Helper loaded: url_helper
DEBUG - 2011-10-17 05:12:08 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-17 05:12:08 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-17 05:12:08 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-17 05:12:08 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-17 05:12:08 --> Final output sent to browser
DEBUG - 2011-10-17 05:12:08 --> Total execution time: 0.0901
DEBUG - 2011-10-17 05:13:07 --> Config Class Initialized
DEBUG - 2011-10-17 05:13:07 --> Hooks Class Initialized
DEBUG - 2011-10-17 05:13:07 --> Utf8 Class Initialized
DEBUG - 2011-10-17 05:13:07 --> UTF-8 Support Enabled
DEBUG - 2011-10-17 05:13:07 --> URI Class Initialized
DEBUG - 2011-10-17 05:13:07 --> Router Class Initialized
DEBUG - 2011-10-17 05:13:07 --> Output Class Initialized
DEBUG - 2011-10-17 05:13:07 --> Input Class Initialized
DEBUG - 2011-10-17 05:13:07 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-17 05:13:07 --> Language Class Initialized
DEBUG - 2011-10-17 05:13:07 --> Loader Class Initialized
DEBUG - 2011-10-17 05:13:07 --> Controller Class Initialized
DEBUG - 2011-10-17 05:13:07 --> Model Class Initialized
DEBUG - 2011-10-17 05:13:07 --> Model Class Initialized
DEBUG - 2011-10-17 05:13:07 --> Model Class Initialized
DEBUG - 2011-10-17 05:13:07 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-17 05:13:07 --> Database Driver Class Initialized
DEBUG - 2011-10-17 05:13:07 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-17 05:13:07 --> Helper loaded: url_helper
DEBUG - 2011-10-17 05:13:07 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-17 05:13:07 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-17 05:13:07 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-17 05:13:07 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-17 05:13:07 --> Final output sent to browser
DEBUG - 2011-10-17 05:13:07 --> Total execution time: 0.1186
DEBUG - 2011-10-17 05:13:09 --> Config Class Initialized
DEBUG - 2011-10-17 05:13:09 --> Hooks Class Initialized
DEBUG - 2011-10-17 05:13:09 --> Utf8 Class Initialized
DEBUG - 2011-10-17 05:13:09 --> UTF-8 Support Enabled
DEBUG - 2011-10-17 05:13:09 --> URI Class Initialized
DEBUG - 2011-10-17 05:13:09 --> Router Class Initialized
ERROR - 2011-10-17 05:13:09 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-17 05:13:10 --> Config Class Initialized
DEBUG - 2011-10-17 05:13:10 --> Hooks Class Initialized
DEBUG - 2011-10-17 05:13:10 --> Utf8 Class Initialized
DEBUG - 2011-10-17 05:13:10 --> UTF-8 Support Enabled
DEBUG - 2011-10-17 05:13:10 --> URI Class Initialized
DEBUG - 2011-10-17 05:13:10 --> Router Class Initialized
ERROR - 2011-10-17 05:13:10 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-17 05:13:10 --> Config Class Initialized
DEBUG - 2011-10-17 05:13:10 --> Hooks Class Initialized
DEBUG - 2011-10-17 05:13:10 --> Utf8 Class Initialized
DEBUG - 2011-10-17 05:13:10 --> UTF-8 Support Enabled
DEBUG - 2011-10-17 05:13:10 --> URI Class Initialized
DEBUG - 2011-10-17 05:13:10 --> Router Class Initialized
ERROR - 2011-10-17 05:13:10 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-17 05:13:42 --> Config Class Initialized
DEBUG - 2011-10-17 05:13:42 --> Hooks Class Initialized
DEBUG - 2011-10-17 05:13:42 --> Utf8 Class Initialized
DEBUG - 2011-10-17 05:13:42 --> UTF-8 Support Enabled
DEBUG - 2011-10-17 05:13:42 --> URI Class Initialized
DEBUG - 2011-10-17 05:13:42 --> Router Class Initialized
DEBUG - 2011-10-17 05:13:42 --> Output Class Initialized
DEBUG - 2011-10-17 05:13:42 --> Input Class Initialized
DEBUG - 2011-10-17 05:13:42 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-17 05:13:42 --> Language Class Initialized
DEBUG - 2011-10-17 05:13:42 --> Loader Class Initialized
DEBUG - 2011-10-17 05:13:42 --> Controller Class Initialized
ERROR - 2011-10-17 05:13:42 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-10-17 05:13:42 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-10-17 05:13:42 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-17 05:13:42 --> Model Class Initialized
DEBUG - 2011-10-17 05:13:42 --> Model Class Initialized
DEBUG - 2011-10-17 05:13:42 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-17 05:13:42 --> Database Driver Class Initialized
DEBUG - 2011-10-17 05:13:42 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-17 05:13:42 --> Helper loaded: url_helper
DEBUG - 2011-10-17 05:13:42 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-17 05:13:42 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-17 05:13:42 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-17 05:13:42 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-17 05:13:42 --> Final output sent to browser
DEBUG - 2011-10-17 05:13:42 --> Total execution time: 0.0273
DEBUG - 2011-10-17 05:13:42 --> Config Class Initialized
DEBUG - 2011-10-17 05:13:42 --> Hooks Class Initialized
DEBUG - 2011-10-17 05:13:42 --> Utf8 Class Initialized
DEBUG - 2011-10-17 05:13:42 --> UTF-8 Support Enabled
DEBUG - 2011-10-17 05:13:42 --> URI Class Initialized
DEBUG - 2011-10-17 05:13:42 --> Router Class Initialized
DEBUG - 2011-10-17 05:13:42 --> Output Class Initialized
DEBUG - 2011-10-17 05:13:42 --> Input Class Initialized
DEBUG - 2011-10-17 05:13:42 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-17 05:13:42 --> Language Class Initialized
DEBUG - 2011-10-17 05:13:42 --> Loader Class Initialized
DEBUG - 2011-10-17 05:13:42 --> Controller Class Initialized
DEBUG - 2011-10-17 05:13:42 --> Model Class Initialized
DEBUG - 2011-10-17 05:13:42 --> Model Class Initialized
DEBUG - 2011-10-17 05:13:42 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-17 05:13:42 --> Database Driver Class Initialized
DEBUG - 2011-10-17 05:13:43 --> Final output sent to browser
DEBUG - 2011-10-17 05:13:43 --> Total execution time: 0.7395
DEBUG - 2011-10-17 05:14:28 --> Config Class Initialized
DEBUG - 2011-10-17 05:14:28 --> Hooks Class Initialized
DEBUG - 2011-10-17 05:14:28 --> Utf8 Class Initialized
DEBUG - 2011-10-17 05:14:28 --> UTF-8 Support Enabled
DEBUG - 2011-10-17 05:14:28 --> URI Class Initialized
DEBUG - 2011-10-17 05:14:28 --> Router Class Initialized
DEBUG - 2011-10-17 05:14:28 --> Output Class Initialized
DEBUG - 2011-10-17 05:14:28 --> Input Class Initialized
DEBUG - 2011-10-17 05:14:28 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-17 05:14:28 --> Language Class Initialized
DEBUG - 2011-10-17 05:14:28 --> Loader Class Initialized
DEBUG - 2011-10-17 05:14:28 --> Controller Class Initialized
ERROR - 2011-10-17 05:14:28 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-10-17 05:14:28 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-10-17 05:14:28 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-17 05:14:28 --> Model Class Initialized
DEBUG - 2011-10-17 05:14:28 --> Model Class Initialized
DEBUG - 2011-10-17 05:14:28 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-17 05:14:28 --> Database Driver Class Initialized
DEBUG - 2011-10-17 05:14:28 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-17 05:14:28 --> Helper loaded: url_helper
DEBUG - 2011-10-17 05:14:28 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-17 05:14:28 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-17 05:14:28 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-17 05:14:28 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-17 05:14:28 --> Final output sent to browser
DEBUG - 2011-10-17 05:14:28 --> Total execution time: 0.0292
DEBUG - 2011-10-17 05:14:28 --> Config Class Initialized
DEBUG - 2011-10-17 05:14:28 --> Hooks Class Initialized
DEBUG - 2011-10-17 05:14:28 --> Utf8 Class Initialized
DEBUG - 2011-10-17 05:14:28 --> UTF-8 Support Enabled
DEBUG - 2011-10-17 05:14:28 --> URI Class Initialized
DEBUG - 2011-10-17 05:14:28 --> Router Class Initialized
DEBUG - 2011-10-17 05:14:28 --> Output Class Initialized
DEBUG - 2011-10-17 05:14:28 --> Input Class Initialized
DEBUG - 2011-10-17 05:14:28 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-17 05:14:28 --> Language Class Initialized
DEBUG - 2011-10-17 05:14:28 --> Loader Class Initialized
DEBUG - 2011-10-17 05:14:28 --> Controller Class Initialized
DEBUG - 2011-10-17 05:14:28 --> Model Class Initialized
DEBUG - 2011-10-17 05:14:28 --> Model Class Initialized
DEBUG - 2011-10-17 05:14:28 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-17 05:14:28 --> Database Driver Class Initialized
DEBUG - 2011-10-17 05:14:29 --> Final output sent to browser
DEBUG - 2011-10-17 05:14:29 --> Total execution time: 0.6813
DEBUG - 2011-10-17 05:14:54 --> Config Class Initialized
DEBUG - 2011-10-17 05:14:54 --> Hooks Class Initialized
DEBUG - 2011-10-17 05:14:54 --> Utf8 Class Initialized
DEBUG - 2011-10-17 05:14:54 --> UTF-8 Support Enabled
DEBUG - 2011-10-17 05:14:54 --> URI Class Initialized
DEBUG - 2011-10-17 05:14:54 --> Router Class Initialized
DEBUG - 2011-10-17 05:14:54 --> Output Class Initialized
DEBUG - 2011-10-17 05:14:54 --> Input Class Initialized
DEBUG - 2011-10-17 05:14:54 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-17 05:14:54 --> Language Class Initialized
DEBUG - 2011-10-17 05:14:54 --> Loader Class Initialized
DEBUG - 2011-10-17 05:14:54 --> Controller Class Initialized
ERROR - 2011-10-17 05:14:54 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-10-17 05:14:54 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-10-17 05:14:54 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-17 05:14:54 --> Model Class Initialized
DEBUG - 2011-10-17 05:14:54 --> Model Class Initialized
DEBUG - 2011-10-17 05:14:54 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-17 05:14:54 --> Database Driver Class Initialized
DEBUG - 2011-10-17 05:14:54 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-17 05:14:54 --> Helper loaded: url_helper
DEBUG - 2011-10-17 05:14:54 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-17 05:14:54 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-17 05:14:54 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-17 05:14:54 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-17 05:14:54 --> Final output sent to browser
DEBUG - 2011-10-17 05:14:54 --> Total execution time: 0.0309
DEBUG - 2011-10-17 05:14:55 --> Config Class Initialized
DEBUG - 2011-10-17 05:14:55 --> Hooks Class Initialized
DEBUG - 2011-10-17 05:14:55 --> Utf8 Class Initialized
DEBUG - 2011-10-17 05:14:55 --> UTF-8 Support Enabled
DEBUG - 2011-10-17 05:14:55 --> URI Class Initialized
DEBUG - 2011-10-17 05:14:55 --> Router Class Initialized
DEBUG - 2011-10-17 05:14:55 --> Output Class Initialized
DEBUG - 2011-10-17 05:14:55 --> Input Class Initialized
DEBUG - 2011-10-17 05:14:55 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-17 05:14:55 --> Language Class Initialized
DEBUG - 2011-10-17 05:14:55 --> Loader Class Initialized
DEBUG - 2011-10-17 05:14:55 --> Controller Class Initialized
DEBUG - 2011-10-17 05:14:55 --> Model Class Initialized
DEBUG - 2011-10-17 05:14:55 --> Model Class Initialized
DEBUG - 2011-10-17 05:14:55 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-17 05:14:55 --> Database Driver Class Initialized
DEBUG - 2011-10-17 05:14:55 --> Final output sent to browser
DEBUG - 2011-10-17 05:14:55 --> Total execution time: 0.7129
DEBUG - 2011-10-17 05:15:08 --> Config Class Initialized
DEBUG - 2011-10-17 05:15:08 --> Hooks Class Initialized
DEBUG - 2011-10-17 05:15:08 --> Utf8 Class Initialized
DEBUG - 2011-10-17 05:15:08 --> UTF-8 Support Enabled
DEBUG - 2011-10-17 05:15:08 --> URI Class Initialized
DEBUG - 2011-10-17 05:15:08 --> Router Class Initialized
DEBUG - 2011-10-17 05:15:08 --> Output Class Initialized
DEBUG - 2011-10-17 05:15:08 --> Input Class Initialized
DEBUG - 2011-10-17 05:15:08 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-17 05:15:08 --> Language Class Initialized
DEBUG - 2011-10-17 05:15:08 --> Loader Class Initialized
DEBUG - 2011-10-17 05:15:08 --> Controller Class Initialized
ERROR - 2011-10-17 05:15:08 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-10-17 05:15:08 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-10-17 05:15:08 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-17 05:15:08 --> Model Class Initialized
DEBUG - 2011-10-17 05:15:08 --> Model Class Initialized
DEBUG - 2011-10-17 05:15:08 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-17 05:15:08 --> Database Driver Class Initialized
DEBUG - 2011-10-17 05:15:08 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-17 05:15:08 --> Helper loaded: url_helper
DEBUG - 2011-10-17 05:15:08 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-17 05:15:08 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-17 05:15:08 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-17 05:15:08 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-17 05:15:08 --> Final output sent to browser
DEBUG - 2011-10-17 05:15:08 --> Total execution time: 0.1487
DEBUG - 2011-10-17 05:15:09 --> Config Class Initialized
DEBUG - 2011-10-17 05:15:09 --> Hooks Class Initialized
DEBUG - 2011-10-17 05:15:09 --> Utf8 Class Initialized
DEBUG - 2011-10-17 05:15:09 --> UTF-8 Support Enabled
DEBUG - 2011-10-17 05:15:09 --> URI Class Initialized
DEBUG - 2011-10-17 05:15:09 --> Router Class Initialized
DEBUG - 2011-10-17 05:15:09 --> Output Class Initialized
DEBUG - 2011-10-17 05:15:09 --> Input Class Initialized
DEBUG - 2011-10-17 05:15:09 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-17 05:15:09 --> Language Class Initialized
DEBUG - 2011-10-17 05:15:09 --> Loader Class Initialized
DEBUG - 2011-10-17 05:15:09 --> Controller Class Initialized
DEBUG - 2011-10-17 05:15:09 --> Model Class Initialized
DEBUG - 2011-10-17 05:15:09 --> Model Class Initialized
DEBUG - 2011-10-17 05:15:09 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-17 05:15:09 --> Database Driver Class Initialized
DEBUG - 2011-10-17 05:15:10 --> Final output sent to browser
DEBUG - 2011-10-17 05:15:10 --> Total execution time: 0.9823
DEBUG - 2011-10-17 06:16:18 --> Config Class Initialized
DEBUG - 2011-10-17 06:16:18 --> Hooks Class Initialized
DEBUG - 2011-10-17 06:16:18 --> Utf8 Class Initialized
DEBUG - 2011-10-17 06:16:18 --> UTF-8 Support Enabled
DEBUG - 2011-10-17 06:16:18 --> URI Class Initialized
DEBUG - 2011-10-17 06:16:18 --> Router Class Initialized
DEBUG - 2011-10-17 06:16:18 --> Output Class Initialized
DEBUG - 2011-10-17 06:16:18 --> Input Class Initialized
DEBUG - 2011-10-17 06:16:18 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-17 06:16:18 --> Language Class Initialized
DEBUG - 2011-10-17 06:16:18 --> Loader Class Initialized
DEBUG - 2011-10-17 06:16:18 --> Controller Class Initialized
DEBUG - 2011-10-17 06:16:18 --> Model Class Initialized
DEBUG - 2011-10-17 06:16:18 --> Model Class Initialized
DEBUG - 2011-10-17 06:16:18 --> Model Class Initialized
DEBUG - 2011-10-17 06:16:18 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-17 06:16:18 --> Database Driver Class Initialized
DEBUG - 2011-10-17 06:16:19 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-17 06:16:19 --> Helper loaded: url_helper
DEBUG - 2011-10-17 06:16:19 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-17 06:16:19 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-17 06:16:19 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-17 06:16:19 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-17 06:16:19 --> Final output sent to browser
DEBUG - 2011-10-17 06:16:19 --> Total execution time: 1.0767
DEBUG - 2011-10-17 06:16:21 --> Config Class Initialized
DEBUG - 2011-10-17 06:16:21 --> Hooks Class Initialized
DEBUG - 2011-10-17 06:16:21 --> Utf8 Class Initialized
DEBUG - 2011-10-17 06:16:21 --> UTF-8 Support Enabled
DEBUG - 2011-10-17 06:16:21 --> URI Class Initialized
DEBUG - 2011-10-17 06:16:21 --> Router Class Initialized
ERROR - 2011-10-17 06:16:21 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-17 06:16:22 --> Config Class Initialized
DEBUG - 2011-10-17 06:16:22 --> Hooks Class Initialized
DEBUG - 2011-10-17 06:16:22 --> Utf8 Class Initialized
DEBUG - 2011-10-17 06:16:22 --> UTF-8 Support Enabled
DEBUG - 2011-10-17 06:16:22 --> URI Class Initialized
DEBUG - 2011-10-17 06:16:22 --> Router Class Initialized
ERROR - 2011-10-17 06:16:22 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-17 06:27:39 --> Config Class Initialized
DEBUG - 2011-10-17 06:27:39 --> Hooks Class Initialized
DEBUG - 2011-10-17 06:27:39 --> Utf8 Class Initialized
DEBUG - 2011-10-17 06:27:39 --> UTF-8 Support Enabled
DEBUG - 2011-10-17 06:27:39 --> URI Class Initialized
DEBUG - 2011-10-17 06:27:39 --> Router Class Initialized
DEBUG - 2011-10-17 06:27:39 --> Output Class Initialized
DEBUG - 2011-10-17 06:27:39 --> Input Class Initialized
DEBUG - 2011-10-17 06:27:39 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-17 06:27:39 --> Language Class Initialized
DEBUG - 2011-10-17 06:27:39 --> Loader Class Initialized
DEBUG - 2011-10-17 06:27:39 --> Controller Class Initialized
DEBUG - 2011-10-17 06:27:39 --> Model Class Initialized
DEBUG - 2011-10-17 06:27:39 --> Model Class Initialized
DEBUG - 2011-10-17 06:27:39 --> Model Class Initialized
DEBUG - 2011-10-17 06:27:39 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-17 06:27:39 --> Database Driver Class Initialized
DEBUG - 2011-10-17 06:27:39 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-17 06:27:39 --> Helper loaded: url_helper
DEBUG - 2011-10-17 06:27:39 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-17 06:27:39 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-17 06:27:39 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-17 06:27:39 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-17 06:27:39 --> Final output sent to browser
DEBUG - 2011-10-17 06:27:39 --> Total execution time: 0.4084
DEBUG - 2011-10-17 06:27:41 --> Config Class Initialized
DEBUG - 2011-10-17 06:27:41 --> Hooks Class Initialized
DEBUG - 2011-10-17 06:27:41 --> Utf8 Class Initialized
DEBUG - 2011-10-17 06:27:41 --> UTF-8 Support Enabled
DEBUG - 2011-10-17 06:27:41 --> URI Class Initialized
DEBUG - 2011-10-17 06:27:41 --> Router Class Initialized
ERROR - 2011-10-17 06:27:41 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-17 06:27:41 --> Config Class Initialized
DEBUG - 2011-10-17 06:27:41 --> Hooks Class Initialized
DEBUG - 2011-10-17 06:27:41 --> Utf8 Class Initialized
DEBUG - 2011-10-17 06:27:41 --> UTF-8 Support Enabled
DEBUG - 2011-10-17 06:27:41 --> URI Class Initialized
DEBUG - 2011-10-17 06:27:41 --> Router Class Initialized
ERROR - 2011-10-17 06:27:41 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-17 06:28:28 --> Config Class Initialized
DEBUG - 2011-10-17 06:28:28 --> Hooks Class Initialized
DEBUG - 2011-10-17 06:28:28 --> Utf8 Class Initialized
DEBUG - 2011-10-17 06:28:28 --> UTF-8 Support Enabled
DEBUG - 2011-10-17 06:28:28 --> URI Class Initialized
DEBUG - 2011-10-17 06:28:28 --> Router Class Initialized
DEBUG - 2011-10-17 06:28:28 --> Output Class Initialized
DEBUG - 2011-10-17 06:28:28 --> Input Class Initialized
DEBUG - 2011-10-17 06:28:28 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-17 06:28:28 --> Language Class Initialized
DEBUG - 2011-10-17 06:28:28 --> Loader Class Initialized
DEBUG - 2011-10-17 06:28:28 --> Controller Class Initialized
DEBUG - 2011-10-17 06:28:28 --> Model Class Initialized
DEBUG - 2011-10-17 06:28:28 --> Model Class Initialized
DEBUG - 2011-10-17 06:28:28 --> Model Class Initialized
DEBUG - 2011-10-17 06:28:28 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-17 06:28:28 --> Database Driver Class Initialized
DEBUG - 2011-10-17 06:28:28 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-17 06:28:28 --> Helper loaded: url_helper
DEBUG - 2011-10-17 06:28:28 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-17 06:28:28 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-17 06:28:28 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-17 06:28:28 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-17 06:28:28 --> Final output sent to browser
DEBUG - 2011-10-17 06:28:28 --> Total execution time: 0.3907
DEBUG - 2011-10-17 06:28:29 --> Config Class Initialized
DEBUG - 2011-10-17 06:28:29 --> Hooks Class Initialized
DEBUG - 2011-10-17 06:28:29 --> Utf8 Class Initialized
DEBUG - 2011-10-17 06:28:29 --> UTF-8 Support Enabled
DEBUG - 2011-10-17 06:28:29 --> URI Class Initialized
DEBUG - 2011-10-17 06:28:29 --> Router Class Initialized
ERROR - 2011-10-17 06:28:29 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-10-17 06:28:29 --> Config Class Initialized
DEBUG - 2011-10-17 06:28:29 --> Hooks Class Initialized
DEBUG - 2011-10-17 06:28:29 --> Utf8 Class Initialized
DEBUG - 2011-10-17 06:28:29 --> UTF-8 Support Enabled
DEBUG - 2011-10-17 06:28:29 --> URI Class Initialized
DEBUG - 2011-10-17 06:28:29 --> Router Class Initialized
DEBUG - 2011-10-17 06:28:29 --> Output Class Initialized
DEBUG - 2011-10-17 06:28:29 --> Input Class Initialized
DEBUG - 2011-10-17 06:28:29 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-17 06:28:29 --> Language Class Initialized
DEBUG - 2011-10-17 06:28:29 --> Loader Class Initialized
DEBUG - 2011-10-17 06:28:29 --> Controller Class Initialized
DEBUG - 2011-10-17 06:28:29 --> Model Class Initialized
DEBUG - 2011-10-17 06:28:29 --> Model Class Initialized
DEBUG - 2011-10-17 06:28:29 --> Model Class Initialized
DEBUG - 2011-10-17 06:28:29 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-17 06:28:29 --> Database Driver Class Initialized
DEBUG - 2011-10-17 06:28:29 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-17 06:28:29 --> Helper loaded: url_helper
DEBUG - 2011-10-17 06:28:29 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-17 06:28:29 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-17 06:28:29 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-17 06:28:29 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-17 06:28:29 --> Final output sent to browser
DEBUG - 2011-10-17 06:28:29 --> Total execution time: 0.0413
DEBUG - 2011-10-17 06:28:41 --> Config Class Initialized
DEBUG - 2011-10-17 06:28:41 --> Hooks Class Initialized
DEBUG - 2011-10-17 06:28:41 --> Utf8 Class Initialized
DEBUG - 2011-10-17 06:28:41 --> UTF-8 Support Enabled
DEBUG - 2011-10-17 06:28:41 --> URI Class Initialized
DEBUG - 2011-10-17 06:28:41 --> Router Class Initialized
DEBUG - 2011-10-17 06:28:41 --> Output Class Initialized
DEBUG - 2011-10-17 06:28:41 --> Input Class Initialized
DEBUG - 2011-10-17 06:28:41 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-17 06:28:41 --> Language Class Initialized
DEBUG - 2011-10-17 06:28:41 --> Loader Class Initialized
DEBUG - 2011-10-17 06:28:41 --> Controller Class Initialized
DEBUG - 2011-10-17 06:28:41 --> Model Class Initialized
DEBUG - 2011-10-17 06:28:41 --> Model Class Initialized
DEBUG - 2011-10-17 06:28:41 --> Model Class Initialized
DEBUG - 2011-10-17 06:28:41 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-17 06:28:41 --> Database Driver Class Initialized
DEBUG - 2011-10-17 06:28:41 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-17 06:28:41 --> Helper loaded: url_helper
DEBUG - 2011-10-17 06:28:41 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-17 06:28:41 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-17 06:28:41 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-17 06:28:41 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-17 06:28:41 --> Final output sent to browser
DEBUG - 2011-10-17 06:28:41 --> Total execution time: 0.5062
DEBUG - 2011-10-17 06:28:42 --> Config Class Initialized
DEBUG - 2011-10-17 06:28:42 --> Hooks Class Initialized
DEBUG - 2011-10-17 06:28:42 --> Utf8 Class Initialized
DEBUG - 2011-10-17 06:28:42 --> UTF-8 Support Enabled
DEBUG - 2011-10-17 06:28:42 --> URI Class Initialized
DEBUG - 2011-10-17 06:28:42 --> Router Class Initialized
DEBUG - 2011-10-17 06:28:42 --> Output Class Initialized
DEBUG - 2011-10-17 06:28:42 --> Input Class Initialized
DEBUG - 2011-10-17 06:28:42 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-17 06:28:42 --> Language Class Initialized
DEBUG - 2011-10-17 06:28:42 --> Loader Class Initialized
DEBUG - 2011-10-17 06:28:42 --> Controller Class Initialized
DEBUG - 2011-10-17 06:28:42 --> Model Class Initialized
DEBUG - 2011-10-17 06:28:42 --> Model Class Initialized
DEBUG - 2011-10-17 06:28:42 --> Model Class Initialized
DEBUG - 2011-10-17 06:28:42 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-17 06:28:42 --> Database Driver Class Initialized
DEBUG - 2011-10-17 06:28:42 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-17 06:28:42 --> Helper loaded: url_helper
DEBUG - 2011-10-17 06:28:42 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-17 06:28:42 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-17 06:28:42 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-17 06:28:42 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-17 06:28:42 --> Final output sent to browser
DEBUG - 2011-10-17 06:28:42 --> Total execution time: 0.0449
DEBUG - 2011-10-17 06:37:50 --> Config Class Initialized
DEBUG - 2011-10-17 06:37:50 --> Hooks Class Initialized
DEBUG - 2011-10-17 06:37:50 --> Utf8 Class Initialized
DEBUG - 2011-10-17 06:37:50 --> UTF-8 Support Enabled
DEBUG - 2011-10-17 06:37:50 --> URI Class Initialized
DEBUG - 2011-10-17 06:37:50 --> Router Class Initialized
DEBUG - 2011-10-17 06:37:50 --> Output Class Initialized
DEBUG - 2011-10-17 06:37:50 --> Input Class Initialized
DEBUG - 2011-10-17 06:37:50 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-17 06:37:50 --> Language Class Initialized
DEBUG - 2011-10-17 06:37:50 --> Loader Class Initialized
DEBUG - 2011-10-17 06:37:50 --> Controller Class Initialized
DEBUG - 2011-10-17 06:37:50 --> Model Class Initialized
DEBUG - 2011-10-17 06:37:50 --> Model Class Initialized
DEBUG - 2011-10-17 06:37:50 --> Model Class Initialized
DEBUG - 2011-10-17 06:37:50 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-17 06:37:50 --> Database Driver Class Initialized
DEBUG - 2011-10-17 06:37:50 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-17 06:37:50 --> Helper loaded: url_helper
DEBUG - 2011-10-17 06:37:50 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-17 06:37:50 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-17 06:37:50 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-17 06:37:50 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-17 06:37:50 --> Final output sent to browser
DEBUG - 2011-10-17 06:37:50 --> Total execution time: 0.3226
DEBUG - 2011-10-17 06:37:54 --> Config Class Initialized
DEBUG - 2011-10-17 06:37:54 --> Hooks Class Initialized
DEBUG - 2011-10-17 06:37:54 --> Utf8 Class Initialized
DEBUG - 2011-10-17 06:37:54 --> UTF-8 Support Enabled
DEBUG - 2011-10-17 06:37:54 --> URI Class Initialized
DEBUG - 2011-10-17 06:37:54 --> Router Class Initialized
ERROR - 2011-10-17 06:37:54 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-17 06:37:57 --> Config Class Initialized
DEBUG - 2011-10-17 06:37:57 --> Hooks Class Initialized
DEBUG - 2011-10-17 06:37:57 --> Utf8 Class Initialized
DEBUG - 2011-10-17 06:37:57 --> UTF-8 Support Enabled
DEBUG - 2011-10-17 06:37:57 --> URI Class Initialized
DEBUG - 2011-10-17 06:37:57 --> Router Class Initialized
DEBUG - 2011-10-17 06:37:57 --> Output Class Initialized
DEBUG - 2011-10-17 06:37:57 --> Input Class Initialized
DEBUG - 2011-10-17 06:37:57 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-17 06:37:57 --> Language Class Initialized
DEBUG - 2011-10-17 06:37:57 --> Loader Class Initialized
DEBUG - 2011-10-17 06:37:57 --> Controller Class Initialized
DEBUG - 2011-10-17 06:37:57 --> Model Class Initialized
DEBUG - 2011-10-17 06:37:57 --> Model Class Initialized
DEBUG - 2011-10-17 06:37:57 --> Model Class Initialized
DEBUG - 2011-10-17 06:37:57 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-17 06:37:57 --> Database Driver Class Initialized
DEBUG - 2011-10-17 06:37:57 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-17 06:37:57 --> Helper loaded: url_helper
DEBUG - 2011-10-17 06:37:57 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-17 06:37:57 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-17 06:37:57 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-17 06:37:57 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-17 06:37:57 --> Final output sent to browser
DEBUG - 2011-10-17 06:37:57 --> Total execution time: 0.0574
DEBUG - 2011-10-17 06:38:07 --> Config Class Initialized
DEBUG - 2011-10-17 06:38:07 --> Hooks Class Initialized
DEBUG - 2011-10-17 06:38:07 --> Utf8 Class Initialized
DEBUG - 2011-10-17 06:38:07 --> UTF-8 Support Enabled
DEBUG - 2011-10-17 06:38:07 --> URI Class Initialized
DEBUG - 2011-10-17 06:38:07 --> Router Class Initialized
DEBUG - 2011-10-17 06:38:07 --> Output Class Initialized
DEBUG - 2011-10-17 06:38:07 --> Input Class Initialized
DEBUG - 2011-10-17 06:38:07 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-17 06:38:07 --> Language Class Initialized
DEBUG - 2011-10-17 06:38:07 --> Loader Class Initialized
DEBUG - 2011-10-17 06:38:07 --> Controller Class Initialized
DEBUG - 2011-10-17 06:38:07 --> Model Class Initialized
DEBUG - 2011-10-17 06:38:07 --> Model Class Initialized
DEBUG - 2011-10-17 06:38:07 --> Model Class Initialized
DEBUG - 2011-10-17 06:38:07 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-17 06:38:07 --> Database Driver Class Initialized
DEBUG - 2011-10-17 06:38:07 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-17 06:38:07 --> Helper loaded: url_helper
DEBUG - 2011-10-17 06:38:07 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-17 06:38:07 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-17 06:38:07 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-17 06:38:07 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-17 06:38:07 --> Final output sent to browser
DEBUG - 2011-10-17 06:38:07 --> Total execution time: 0.0542
DEBUG - 2011-10-17 06:38:38 --> Config Class Initialized
DEBUG - 2011-10-17 06:38:38 --> Hooks Class Initialized
DEBUG - 2011-10-17 06:38:38 --> Utf8 Class Initialized
DEBUG - 2011-10-17 06:38:38 --> UTF-8 Support Enabled
DEBUG - 2011-10-17 06:38:38 --> URI Class Initialized
DEBUG - 2011-10-17 06:38:38 --> Router Class Initialized
DEBUG - 2011-10-17 06:38:38 --> Output Class Initialized
DEBUG - 2011-10-17 06:38:38 --> Input Class Initialized
DEBUG - 2011-10-17 06:38:38 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-17 06:38:38 --> Language Class Initialized
DEBUG - 2011-10-17 06:38:38 --> Loader Class Initialized
DEBUG - 2011-10-17 06:38:38 --> Controller Class Initialized
DEBUG - 2011-10-17 06:38:38 --> Model Class Initialized
DEBUG - 2011-10-17 06:38:38 --> Model Class Initialized
DEBUG - 2011-10-17 06:38:38 --> Model Class Initialized
DEBUG - 2011-10-17 06:38:38 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-17 06:38:38 --> Database Driver Class Initialized
DEBUG - 2011-10-17 06:38:39 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-17 06:38:39 --> Helper loaded: url_helper
DEBUG - 2011-10-17 06:38:39 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-17 06:38:39 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-17 06:38:39 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-17 06:38:39 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-17 06:38:39 --> Final output sent to browser
DEBUG - 2011-10-17 06:38:39 --> Total execution time: 0.4040
DEBUG - 2011-10-17 06:38:41 --> Config Class Initialized
DEBUG - 2011-10-17 06:38:41 --> Hooks Class Initialized
DEBUG - 2011-10-17 06:38:41 --> Utf8 Class Initialized
DEBUG - 2011-10-17 06:38:41 --> UTF-8 Support Enabled
DEBUG - 2011-10-17 06:38:41 --> URI Class Initialized
DEBUG - 2011-10-17 06:38:41 --> Router Class Initialized
DEBUG - 2011-10-17 06:38:41 --> Output Class Initialized
DEBUG - 2011-10-17 06:38:41 --> Input Class Initialized
DEBUG - 2011-10-17 06:38:41 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-17 06:38:41 --> Language Class Initialized
DEBUG - 2011-10-17 06:38:41 --> Loader Class Initialized
DEBUG - 2011-10-17 06:38:41 --> Controller Class Initialized
DEBUG - 2011-10-17 06:38:41 --> Model Class Initialized
DEBUG - 2011-10-17 06:38:41 --> Model Class Initialized
DEBUG - 2011-10-17 06:38:41 --> Model Class Initialized
DEBUG - 2011-10-17 06:38:41 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-17 06:38:41 --> Database Driver Class Initialized
DEBUG - 2011-10-17 06:38:41 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-17 06:38:41 --> Helper loaded: url_helper
DEBUG - 2011-10-17 06:38:41 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-17 06:38:41 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-17 06:38:41 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-17 06:38:41 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-17 06:38:41 --> Final output sent to browser
DEBUG - 2011-10-17 06:38:41 --> Total execution time: 0.0439
DEBUG - 2011-10-17 06:38:55 --> Config Class Initialized
DEBUG - 2011-10-17 06:38:55 --> Hooks Class Initialized
DEBUG - 2011-10-17 06:38:55 --> Utf8 Class Initialized
DEBUG - 2011-10-17 06:38:55 --> UTF-8 Support Enabled
DEBUG - 2011-10-17 06:38:55 --> URI Class Initialized
DEBUG - 2011-10-17 06:38:55 --> Router Class Initialized
DEBUG - 2011-10-17 06:38:55 --> Output Class Initialized
DEBUG - 2011-10-17 06:38:55 --> Input Class Initialized
DEBUG - 2011-10-17 06:38:55 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-17 06:38:55 --> Language Class Initialized
DEBUG - 2011-10-17 06:38:55 --> Loader Class Initialized
DEBUG - 2011-10-17 06:38:55 --> Controller Class Initialized
DEBUG - 2011-10-17 06:38:55 --> Model Class Initialized
DEBUG - 2011-10-17 06:38:55 --> Model Class Initialized
DEBUG - 2011-10-17 06:38:55 --> Model Class Initialized
DEBUG - 2011-10-17 06:38:55 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-17 06:38:55 --> Database Driver Class Initialized
DEBUG - 2011-10-17 06:38:55 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-17 06:38:55 --> Helper loaded: url_helper
DEBUG - 2011-10-17 06:38:55 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-17 06:38:55 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-17 06:38:55 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-17 06:38:55 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-17 06:38:55 --> Final output sent to browser
DEBUG - 2011-10-17 06:38:55 --> Total execution time: 0.2858
DEBUG - 2011-10-17 06:38:58 --> Config Class Initialized
DEBUG - 2011-10-17 06:38:58 --> Hooks Class Initialized
DEBUG - 2011-10-17 06:38:58 --> Utf8 Class Initialized
DEBUG - 2011-10-17 06:38:58 --> UTF-8 Support Enabled
DEBUG - 2011-10-17 06:38:58 --> URI Class Initialized
DEBUG - 2011-10-17 06:38:58 --> Router Class Initialized
DEBUG - 2011-10-17 06:38:58 --> Output Class Initialized
DEBUG - 2011-10-17 06:38:58 --> Input Class Initialized
DEBUG - 2011-10-17 06:38:58 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-17 06:38:58 --> Language Class Initialized
DEBUG - 2011-10-17 06:38:58 --> Loader Class Initialized
DEBUG - 2011-10-17 06:38:58 --> Controller Class Initialized
DEBUG - 2011-10-17 06:38:58 --> Model Class Initialized
DEBUG - 2011-10-17 06:38:58 --> Model Class Initialized
DEBUG - 2011-10-17 06:38:58 --> Model Class Initialized
DEBUG - 2011-10-17 06:38:58 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-17 06:38:58 --> Database Driver Class Initialized
DEBUG - 2011-10-17 06:38:58 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-17 06:38:58 --> Helper loaded: url_helper
DEBUG - 2011-10-17 06:38:58 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-17 06:38:58 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-17 06:38:58 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-17 06:38:58 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-17 06:38:58 --> Final output sent to browser
DEBUG - 2011-10-17 06:38:58 --> Total execution time: 0.0670
DEBUG - 2011-10-17 06:39:10 --> Config Class Initialized
DEBUG - 2011-10-17 06:39:10 --> Hooks Class Initialized
DEBUG - 2011-10-17 06:39:10 --> Utf8 Class Initialized
DEBUG - 2011-10-17 06:39:10 --> UTF-8 Support Enabled
DEBUG - 2011-10-17 06:39:10 --> URI Class Initialized
DEBUG - 2011-10-17 06:39:10 --> Router Class Initialized
DEBUG - 2011-10-17 06:39:10 --> Output Class Initialized
DEBUG - 2011-10-17 06:39:10 --> Input Class Initialized
DEBUG - 2011-10-17 06:39:10 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-17 06:39:10 --> Language Class Initialized
DEBUG - 2011-10-17 06:39:10 --> Loader Class Initialized
DEBUG - 2011-10-17 06:39:10 --> Controller Class Initialized
DEBUG - 2011-10-17 06:39:10 --> Model Class Initialized
DEBUG - 2011-10-17 06:39:10 --> Model Class Initialized
DEBUG - 2011-10-17 06:39:10 --> Model Class Initialized
DEBUG - 2011-10-17 06:39:10 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-17 06:39:10 --> Database Driver Class Initialized
DEBUG - 2011-10-17 06:39:11 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-17 06:39:11 --> Helper loaded: url_helper
DEBUG - 2011-10-17 06:39:11 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-17 06:39:11 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-17 06:39:11 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-17 06:39:11 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-17 06:39:11 --> Final output sent to browser
DEBUG - 2011-10-17 06:39:11 --> Total execution time: 0.4761
DEBUG - 2011-10-17 06:39:14 --> Config Class Initialized
DEBUG - 2011-10-17 06:39:14 --> Hooks Class Initialized
DEBUG - 2011-10-17 06:39:14 --> Utf8 Class Initialized
DEBUG - 2011-10-17 06:39:14 --> UTF-8 Support Enabled
DEBUG - 2011-10-17 06:39:15 --> URI Class Initialized
DEBUG - 2011-10-17 06:39:15 --> Router Class Initialized
DEBUG - 2011-10-17 06:39:15 --> Output Class Initialized
DEBUG - 2011-10-17 06:39:15 --> Input Class Initialized
DEBUG - 2011-10-17 06:39:15 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-17 06:39:15 --> Language Class Initialized
DEBUG - 2011-10-17 06:39:15 --> Loader Class Initialized
DEBUG - 2011-10-17 06:39:15 --> Controller Class Initialized
DEBUG - 2011-10-17 06:39:15 --> Model Class Initialized
DEBUG - 2011-10-17 06:39:15 --> Model Class Initialized
DEBUG - 2011-10-17 06:39:15 --> Model Class Initialized
DEBUG - 2011-10-17 06:39:15 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-17 06:39:15 --> Database Driver Class Initialized
DEBUG - 2011-10-17 06:39:15 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-17 06:39:15 --> Helper loaded: url_helper
DEBUG - 2011-10-17 06:39:15 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-17 06:39:15 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-17 06:39:15 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-17 06:39:15 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-17 06:39:15 --> Final output sent to browser
DEBUG - 2011-10-17 06:39:15 --> Total execution time: 0.3488
DEBUG - 2011-10-17 06:39:31 --> Config Class Initialized
DEBUG - 2011-10-17 06:39:31 --> Hooks Class Initialized
DEBUG - 2011-10-17 06:39:31 --> Utf8 Class Initialized
DEBUG - 2011-10-17 06:39:31 --> UTF-8 Support Enabled
DEBUG - 2011-10-17 06:39:31 --> URI Class Initialized
DEBUG - 2011-10-17 06:39:31 --> Router Class Initialized
DEBUG - 2011-10-17 06:39:31 --> Output Class Initialized
DEBUG - 2011-10-17 06:39:31 --> Input Class Initialized
DEBUG - 2011-10-17 06:39:31 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-17 06:39:31 --> Language Class Initialized
DEBUG - 2011-10-17 06:39:31 --> Loader Class Initialized
DEBUG - 2011-10-17 06:39:31 --> Controller Class Initialized
DEBUG - 2011-10-17 06:39:31 --> Model Class Initialized
DEBUG - 2011-10-17 06:39:31 --> Model Class Initialized
DEBUG - 2011-10-17 06:39:31 --> Model Class Initialized
DEBUG - 2011-10-17 06:39:31 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-17 06:39:31 --> Database Driver Class Initialized
DEBUG - 2011-10-17 06:39:32 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-17 06:39:32 --> Helper loaded: url_helper
DEBUG - 2011-10-17 06:39:32 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-17 06:39:32 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-17 06:39:32 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-17 06:39:32 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-17 06:39:32 --> Final output sent to browser
DEBUG - 2011-10-17 06:39:32 --> Total execution time: 0.4537
DEBUG - 2011-10-17 06:39:40 --> Config Class Initialized
DEBUG - 2011-10-17 06:39:40 --> Hooks Class Initialized
DEBUG - 2011-10-17 06:39:40 --> Utf8 Class Initialized
DEBUG - 2011-10-17 06:39:40 --> UTF-8 Support Enabled
DEBUG - 2011-10-17 06:39:40 --> URI Class Initialized
DEBUG - 2011-10-17 06:39:40 --> Router Class Initialized
DEBUG - 2011-10-17 06:39:40 --> Output Class Initialized
DEBUG - 2011-10-17 06:39:40 --> Input Class Initialized
DEBUG - 2011-10-17 06:39:40 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-17 06:39:40 --> Language Class Initialized
DEBUG - 2011-10-17 06:39:40 --> Loader Class Initialized
DEBUG - 2011-10-17 06:39:40 --> Controller Class Initialized
DEBUG - 2011-10-17 06:39:40 --> Model Class Initialized
DEBUG - 2011-10-17 06:39:40 --> Model Class Initialized
DEBUG - 2011-10-17 06:39:40 --> Model Class Initialized
DEBUG - 2011-10-17 06:39:40 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-17 06:39:40 --> Database Driver Class Initialized
DEBUG - 2011-10-17 06:39:40 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-17 06:39:40 --> Helper loaded: url_helper
DEBUG - 2011-10-17 06:39:40 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-17 06:39:40 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-17 06:39:40 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-17 06:39:40 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-17 06:39:40 --> Final output sent to browser
DEBUG - 2011-10-17 06:39:40 --> Total execution time: 0.2285
DEBUG - 2011-10-17 06:39:50 --> Config Class Initialized
DEBUG - 2011-10-17 06:39:50 --> Hooks Class Initialized
DEBUG - 2011-10-17 06:39:50 --> Utf8 Class Initialized
DEBUG - 2011-10-17 06:39:50 --> UTF-8 Support Enabled
DEBUG - 2011-10-17 06:39:50 --> URI Class Initialized
DEBUG - 2011-10-17 06:39:50 --> Router Class Initialized
DEBUG - 2011-10-17 06:39:50 --> Output Class Initialized
DEBUG - 2011-10-17 06:39:50 --> Input Class Initialized
DEBUG - 2011-10-17 06:39:50 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-17 06:39:50 --> Language Class Initialized
DEBUG - 2011-10-17 06:39:50 --> Loader Class Initialized
DEBUG - 2011-10-17 06:39:50 --> Controller Class Initialized
DEBUG - 2011-10-17 06:39:50 --> Model Class Initialized
DEBUG - 2011-10-17 06:39:50 --> Model Class Initialized
DEBUG - 2011-10-17 06:39:50 --> Model Class Initialized
DEBUG - 2011-10-17 06:39:50 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-17 06:39:50 --> Database Driver Class Initialized
DEBUG - 2011-10-17 06:39:51 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-17 06:39:51 --> Helper loaded: url_helper
DEBUG - 2011-10-17 06:39:51 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-17 06:39:51 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-17 06:39:51 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-17 06:39:51 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-17 06:39:51 --> Final output sent to browser
DEBUG - 2011-10-17 06:39:51 --> Total execution time: 0.4926
DEBUG - 2011-10-17 06:39:55 --> Config Class Initialized
DEBUG - 2011-10-17 06:39:55 --> Hooks Class Initialized
DEBUG - 2011-10-17 06:39:55 --> Utf8 Class Initialized
DEBUG - 2011-10-17 06:39:55 --> UTF-8 Support Enabled
DEBUG - 2011-10-17 06:39:55 --> URI Class Initialized
DEBUG - 2011-10-17 06:39:55 --> Router Class Initialized
DEBUG - 2011-10-17 06:39:55 --> Output Class Initialized
DEBUG - 2011-10-17 06:39:55 --> Input Class Initialized
DEBUG - 2011-10-17 06:39:55 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-17 06:39:55 --> Language Class Initialized
DEBUG - 2011-10-17 06:39:55 --> Loader Class Initialized
DEBUG - 2011-10-17 06:39:55 --> Controller Class Initialized
DEBUG - 2011-10-17 06:39:55 --> Model Class Initialized
DEBUG - 2011-10-17 06:39:55 --> Model Class Initialized
DEBUG - 2011-10-17 06:39:55 --> Model Class Initialized
DEBUG - 2011-10-17 06:39:55 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-17 06:39:55 --> Database Driver Class Initialized
DEBUG - 2011-10-17 06:39:55 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-17 06:39:55 --> Helper loaded: url_helper
DEBUG - 2011-10-17 06:39:55 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-17 06:39:55 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-17 06:39:55 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-17 06:39:55 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-17 06:39:55 --> Final output sent to browser
DEBUG - 2011-10-17 06:39:55 --> Total execution time: 0.0811
DEBUG - 2011-10-17 06:41:09 --> Config Class Initialized
DEBUG - 2011-10-17 06:41:09 --> Hooks Class Initialized
DEBUG - 2011-10-17 06:41:09 --> Utf8 Class Initialized
DEBUG - 2011-10-17 06:41:09 --> UTF-8 Support Enabled
DEBUG - 2011-10-17 06:41:09 --> URI Class Initialized
DEBUG - 2011-10-17 06:41:09 --> Router Class Initialized
DEBUG - 2011-10-17 06:41:09 --> Output Class Initialized
DEBUG - 2011-10-17 06:41:09 --> Input Class Initialized
DEBUG - 2011-10-17 06:41:09 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-17 06:41:09 --> Language Class Initialized
DEBUG - 2011-10-17 06:41:09 --> Loader Class Initialized
DEBUG - 2011-10-17 06:41:09 --> Controller Class Initialized
ERROR - 2011-10-17 06:41:09 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-10-17 06:41:09 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-10-17 06:41:09 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-17 06:41:09 --> Model Class Initialized
DEBUG - 2011-10-17 06:41:09 --> Model Class Initialized
DEBUG - 2011-10-17 06:41:09 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-17 06:41:09 --> Database Driver Class Initialized
DEBUG - 2011-10-17 06:41:09 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-17 06:41:09 --> Helper loaded: url_helper
DEBUG - 2011-10-17 06:41:09 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-17 06:41:09 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-17 06:41:09 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-17 06:41:09 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-17 06:41:09 --> Final output sent to browser
DEBUG - 2011-10-17 06:41:09 --> Total execution time: 0.1065
DEBUG - 2011-10-17 06:41:10 --> Config Class Initialized
DEBUG - 2011-10-17 06:41:10 --> Hooks Class Initialized
DEBUG - 2011-10-17 06:41:10 --> Utf8 Class Initialized
DEBUG - 2011-10-17 06:41:10 --> UTF-8 Support Enabled
DEBUG - 2011-10-17 06:41:10 --> URI Class Initialized
DEBUG - 2011-10-17 06:41:10 --> Router Class Initialized
DEBUG - 2011-10-17 06:41:10 --> Output Class Initialized
DEBUG - 2011-10-17 06:41:10 --> Input Class Initialized
DEBUG - 2011-10-17 06:41:10 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-17 06:41:10 --> Language Class Initialized
DEBUG - 2011-10-17 06:41:10 --> Loader Class Initialized
DEBUG - 2011-10-17 06:41:10 --> Controller Class Initialized
DEBUG - 2011-10-17 06:41:10 --> Model Class Initialized
DEBUG - 2011-10-17 06:41:10 --> Model Class Initialized
DEBUG - 2011-10-17 06:41:10 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-17 06:41:10 --> Database Driver Class Initialized
DEBUG - 2011-10-17 06:41:11 --> Final output sent to browser
DEBUG - 2011-10-17 06:41:11 --> Total execution time: 0.7708
DEBUG - 2011-10-17 06:41:14 --> Config Class Initialized
DEBUG - 2011-10-17 06:41:14 --> Hooks Class Initialized
DEBUG - 2011-10-17 06:41:14 --> Utf8 Class Initialized
DEBUG - 2011-10-17 06:41:14 --> UTF-8 Support Enabled
DEBUG - 2011-10-17 06:41:14 --> URI Class Initialized
DEBUG - 2011-10-17 06:41:14 --> Router Class Initialized
ERROR - 2011-10-17 06:41:14 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-17 06:41:17 --> Config Class Initialized
DEBUG - 2011-10-17 06:41:17 --> Hooks Class Initialized
DEBUG - 2011-10-17 06:41:17 --> Utf8 Class Initialized
DEBUG - 2011-10-17 06:41:17 --> UTF-8 Support Enabled
DEBUG - 2011-10-17 06:41:17 --> URI Class Initialized
DEBUG - 2011-10-17 06:41:17 --> Router Class Initialized
ERROR - 2011-10-17 06:41:17 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-17 06:42:42 --> Config Class Initialized
DEBUG - 2011-10-17 06:42:42 --> Hooks Class Initialized
DEBUG - 2011-10-17 06:42:42 --> Utf8 Class Initialized
DEBUG - 2011-10-17 06:42:42 --> UTF-8 Support Enabled
DEBUG - 2011-10-17 06:42:42 --> URI Class Initialized
DEBUG - 2011-10-17 06:42:42 --> Router Class Initialized
DEBUG - 2011-10-17 06:42:42 --> Output Class Initialized
DEBUG - 2011-10-17 06:42:42 --> Input Class Initialized
DEBUG - 2011-10-17 06:42:42 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-17 06:42:42 --> Language Class Initialized
DEBUG - 2011-10-17 06:42:42 --> Loader Class Initialized
DEBUG - 2011-10-17 06:42:42 --> Controller Class Initialized
ERROR - 2011-10-17 06:42:42 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-10-17 06:42:42 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-10-17 06:42:42 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-17 06:42:42 --> Model Class Initialized
DEBUG - 2011-10-17 06:42:42 --> Model Class Initialized
DEBUG - 2011-10-17 06:42:42 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-17 06:42:42 --> Database Driver Class Initialized
DEBUG - 2011-10-17 06:42:42 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-17 06:42:42 --> Helper loaded: url_helper
DEBUG - 2011-10-17 06:42:42 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-17 06:42:42 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-17 06:42:42 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-17 06:42:42 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-17 06:42:42 --> Final output sent to browser
DEBUG - 2011-10-17 06:42:42 --> Total execution time: 0.0343
DEBUG - 2011-10-17 06:42:43 --> Config Class Initialized
DEBUG - 2011-10-17 06:42:43 --> Hooks Class Initialized
DEBUG - 2011-10-17 06:42:43 --> Utf8 Class Initialized
DEBUG - 2011-10-17 06:42:43 --> UTF-8 Support Enabled
DEBUG - 2011-10-17 06:42:43 --> URI Class Initialized
DEBUG - 2011-10-17 06:42:43 --> Router Class Initialized
DEBUG - 2011-10-17 06:42:43 --> Output Class Initialized
DEBUG - 2011-10-17 06:42:43 --> Input Class Initialized
DEBUG - 2011-10-17 06:42:43 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-17 06:42:43 --> Language Class Initialized
DEBUG - 2011-10-17 06:42:43 --> Loader Class Initialized
DEBUG - 2011-10-17 06:42:43 --> Controller Class Initialized
DEBUG - 2011-10-17 06:42:43 --> Model Class Initialized
DEBUG - 2011-10-17 06:42:43 --> Model Class Initialized
DEBUG - 2011-10-17 06:42:43 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-17 06:42:43 --> Database Driver Class Initialized
DEBUG - 2011-10-17 06:42:44 --> Final output sent to browser
DEBUG - 2011-10-17 06:42:44 --> Total execution time: 1.3849
DEBUG - 2011-10-17 06:42:54 --> Config Class Initialized
DEBUG - 2011-10-17 06:42:54 --> Hooks Class Initialized
DEBUG - 2011-10-17 06:42:54 --> Utf8 Class Initialized
DEBUG - 2011-10-17 06:42:54 --> UTF-8 Support Enabled
DEBUG - 2011-10-17 06:42:54 --> URI Class Initialized
DEBUG - 2011-10-17 06:42:54 --> Router Class Initialized
DEBUG - 2011-10-17 06:42:54 --> Output Class Initialized
DEBUG - 2011-10-17 06:42:54 --> Input Class Initialized
DEBUG - 2011-10-17 06:42:54 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-17 06:42:54 --> Language Class Initialized
DEBUG - 2011-10-17 06:42:54 --> Loader Class Initialized
DEBUG - 2011-10-17 06:42:54 --> Controller Class Initialized
ERROR - 2011-10-17 06:42:54 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-10-17 06:42:54 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-10-17 06:42:54 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-17 06:42:54 --> Model Class Initialized
DEBUG - 2011-10-17 06:42:54 --> Model Class Initialized
DEBUG - 2011-10-17 06:42:54 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-17 06:42:54 --> Database Driver Class Initialized
DEBUG - 2011-10-17 06:42:54 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-17 06:42:54 --> Helper loaded: url_helper
DEBUG - 2011-10-17 06:42:54 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-17 06:42:54 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-17 06:42:54 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-17 06:42:54 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-17 06:42:54 --> Final output sent to browser
DEBUG - 2011-10-17 06:42:54 --> Total execution time: 0.0267
DEBUG - 2011-10-17 06:42:55 --> Config Class Initialized
DEBUG - 2011-10-17 06:42:55 --> Hooks Class Initialized
DEBUG - 2011-10-17 06:42:55 --> Utf8 Class Initialized
DEBUG - 2011-10-17 06:42:55 --> UTF-8 Support Enabled
DEBUG - 2011-10-17 06:42:55 --> URI Class Initialized
DEBUG - 2011-10-17 06:42:55 --> Router Class Initialized
DEBUG - 2011-10-17 06:42:55 --> Output Class Initialized
DEBUG - 2011-10-17 06:42:55 --> Input Class Initialized
DEBUG - 2011-10-17 06:42:55 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-17 06:42:55 --> Language Class Initialized
DEBUG - 2011-10-17 06:42:55 --> Loader Class Initialized
DEBUG - 2011-10-17 06:42:55 --> Controller Class Initialized
DEBUG - 2011-10-17 06:42:55 --> Model Class Initialized
DEBUG - 2011-10-17 06:42:55 --> Model Class Initialized
DEBUG - 2011-10-17 06:42:55 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-17 06:42:55 --> Database Driver Class Initialized
DEBUG - 2011-10-17 06:43:01 --> Final output sent to browser
DEBUG - 2011-10-17 06:43:01 --> Total execution time: 6.0326
DEBUG - 2011-10-17 06:43:06 --> Config Class Initialized
DEBUG - 2011-10-17 06:43:06 --> Hooks Class Initialized
DEBUG - 2011-10-17 06:43:06 --> Utf8 Class Initialized
DEBUG - 2011-10-17 06:43:06 --> UTF-8 Support Enabled
DEBUG - 2011-10-17 06:43:06 --> URI Class Initialized
DEBUG - 2011-10-17 06:43:06 --> Router Class Initialized
DEBUG - 2011-10-17 06:43:06 --> Output Class Initialized
DEBUG - 2011-10-17 06:43:06 --> Input Class Initialized
DEBUG - 2011-10-17 06:43:06 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-17 06:43:06 --> Language Class Initialized
DEBUG - 2011-10-17 06:43:06 --> Loader Class Initialized
DEBUG - 2011-10-17 06:43:06 --> Controller Class Initialized
ERROR - 2011-10-17 06:43:06 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-10-17 06:43:06 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-10-17 06:43:06 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-17 06:43:06 --> Model Class Initialized
DEBUG - 2011-10-17 06:43:06 --> Model Class Initialized
DEBUG - 2011-10-17 06:43:06 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-17 06:43:06 --> Database Driver Class Initialized
DEBUG - 2011-10-17 06:43:06 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-17 06:43:06 --> Helper loaded: url_helper
DEBUG - 2011-10-17 06:43:06 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-17 06:43:06 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-17 06:43:06 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-17 06:43:06 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-17 06:43:06 --> Final output sent to browser
DEBUG - 2011-10-17 06:43:06 --> Total execution time: 0.0385
DEBUG - 2011-10-17 06:43:07 --> Config Class Initialized
DEBUG - 2011-10-17 06:43:07 --> Hooks Class Initialized
DEBUG - 2011-10-17 06:43:07 --> Utf8 Class Initialized
DEBUG - 2011-10-17 06:43:07 --> UTF-8 Support Enabled
DEBUG - 2011-10-17 06:43:07 --> URI Class Initialized
DEBUG - 2011-10-17 06:43:07 --> Router Class Initialized
DEBUG - 2011-10-17 06:43:07 --> Output Class Initialized
DEBUG - 2011-10-17 06:43:07 --> Input Class Initialized
DEBUG - 2011-10-17 06:43:07 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-17 06:43:07 --> Language Class Initialized
DEBUG - 2011-10-17 06:43:07 --> Loader Class Initialized
DEBUG - 2011-10-17 06:43:07 --> Controller Class Initialized
DEBUG - 2011-10-17 06:43:07 --> Model Class Initialized
DEBUG - 2011-10-17 06:43:07 --> Model Class Initialized
DEBUG - 2011-10-17 06:43:07 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-17 06:43:07 --> Database Driver Class Initialized
DEBUG - 2011-10-17 06:43:08 --> Final output sent to browser
DEBUG - 2011-10-17 06:43:08 --> Total execution time: 1.0793
DEBUG - 2011-10-17 06:43:14 --> Config Class Initialized
DEBUG - 2011-10-17 06:43:14 --> Hooks Class Initialized
DEBUG - 2011-10-17 06:43:14 --> Utf8 Class Initialized
DEBUG - 2011-10-17 06:43:14 --> UTF-8 Support Enabled
DEBUG - 2011-10-17 06:43:14 --> URI Class Initialized
DEBUG - 2011-10-17 06:43:14 --> Router Class Initialized
DEBUG - 2011-10-17 06:43:14 --> Output Class Initialized
DEBUG - 2011-10-17 06:43:14 --> Input Class Initialized
DEBUG - 2011-10-17 06:43:14 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-17 06:43:14 --> Language Class Initialized
DEBUG - 2011-10-17 06:43:14 --> Loader Class Initialized
DEBUG - 2011-10-17 06:43:14 --> Controller Class Initialized
ERROR - 2011-10-17 06:43:14 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-10-17 06:43:14 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-10-17 06:43:14 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-17 06:43:14 --> Model Class Initialized
DEBUG - 2011-10-17 06:43:14 --> Model Class Initialized
DEBUG - 2011-10-17 06:43:14 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-17 06:43:14 --> Database Driver Class Initialized
DEBUG - 2011-10-17 06:43:14 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-17 06:43:14 --> Helper loaded: url_helper
DEBUG - 2011-10-17 06:43:14 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-17 06:43:14 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-17 06:43:14 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-17 06:43:14 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-17 06:43:14 --> Final output sent to browser
DEBUG - 2011-10-17 06:43:14 --> Total execution time: 0.0386
DEBUG - 2011-10-17 06:43:15 --> Config Class Initialized
DEBUG - 2011-10-17 06:43:15 --> Hooks Class Initialized
DEBUG - 2011-10-17 06:43:15 --> Utf8 Class Initialized
DEBUG - 2011-10-17 06:43:15 --> UTF-8 Support Enabled
DEBUG - 2011-10-17 06:43:15 --> URI Class Initialized
DEBUG - 2011-10-17 06:43:15 --> Router Class Initialized
DEBUG - 2011-10-17 06:43:15 --> Output Class Initialized
DEBUG - 2011-10-17 06:43:15 --> Input Class Initialized
DEBUG - 2011-10-17 06:43:15 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-17 06:43:15 --> Language Class Initialized
DEBUG - 2011-10-17 06:43:15 --> Loader Class Initialized
DEBUG - 2011-10-17 06:43:15 --> Controller Class Initialized
DEBUG - 2011-10-17 06:43:15 --> Model Class Initialized
DEBUG - 2011-10-17 06:43:15 --> Model Class Initialized
DEBUG - 2011-10-17 06:43:15 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-17 06:43:15 --> Database Driver Class Initialized
DEBUG - 2011-10-17 06:43:16 --> Final output sent to browser
DEBUG - 2011-10-17 06:43:16 --> Total execution time: 0.6725
DEBUG - 2011-10-17 06:43:22 --> Config Class Initialized
DEBUG - 2011-10-17 06:43:22 --> Hooks Class Initialized
DEBUG - 2011-10-17 06:43:22 --> Utf8 Class Initialized
DEBUG - 2011-10-17 06:43:22 --> UTF-8 Support Enabled
DEBUG - 2011-10-17 06:43:22 --> URI Class Initialized
DEBUG - 2011-10-17 06:43:22 --> Router Class Initialized
DEBUG - 2011-10-17 06:43:22 --> Output Class Initialized
DEBUG - 2011-10-17 06:43:22 --> Input Class Initialized
DEBUG - 2011-10-17 06:43:22 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-17 06:43:22 --> Language Class Initialized
DEBUG - 2011-10-17 06:43:22 --> Loader Class Initialized
DEBUG - 2011-10-17 06:43:22 --> Controller Class Initialized
ERROR - 2011-10-17 06:43:22 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-10-17 06:43:22 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-10-17 06:43:22 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-17 06:43:22 --> Model Class Initialized
DEBUG - 2011-10-17 06:43:22 --> Model Class Initialized
DEBUG - 2011-10-17 06:43:22 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-17 06:43:22 --> Database Driver Class Initialized
DEBUG - 2011-10-17 06:43:22 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-17 06:43:22 --> Helper loaded: url_helper
DEBUG - 2011-10-17 06:43:22 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-17 06:43:22 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-17 06:43:22 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-17 06:43:22 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-17 06:43:22 --> Final output sent to browser
DEBUG - 2011-10-17 06:43:22 --> Total execution time: 0.0303
DEBUG - 2011-10-17 06:43:25 --> Config Class Initialized
DEBUG - 2011-10-17 06:43:25 --> Hooks Class Initialized
DEBUG - 2011-10-17 06:43:25 --> Utf8 Class Initialized
DEBUG - 2011-10-17 06:43:25 --> UTF-8 Support Enabled
DEBUG - 2011-10-17 06:43:25 --> URI Class Initialized
DEBUG - 2011-10-17 06:43:25 --> Router Class Initialized
DEBUG - 2011-10-17 06:43:25 --> Output Class Initialized
DEBUG - 2011-10-17 06:43:25 --> Input Class Initialized
DEBUG - 2011-10-17 06:43:25 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-17 06:43:25 --> Language Class Initialized
DEBUG - 2011-10-17 06:43:25 --> Loader Class Initialized
DEBUG - 2011-10-17 06:43:25 --> Controller Class Initialized
DEBUG - 2011-10-17 06:43:25 --> Model Class Initialized
DEBUG - 2011-10-17 06:43:25 --> Model Class Initialized
DEBUG - 2011-10-17 06:43:25 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-17 06:43:25 --> Database Driver Class Initialized
DEBUG - 2011-10-17 06:43:25 --> Final output sent to browser
DEBUG - 2011-10-17 06:43:25 --> Total execution time: 0.5783
DEBUG - 2011-10-17 06:43:33 --> Config Class Initialized
DEBUG - 2011-10-17 06:43:33 --> Hooks Class Initialized
DEBUG - 2011-10-17 06:43:33 --> Utf8 Class Initialized
DEBUG - 2011-10-17 06:43:33 --> UTF-8 Support Enabled
DEBUG - 2011-10-17 06:43:33 --> URI Class Initialized
DEBUG - 2011-10-17 06:43:33 --> Router Class Initialized
DEBUG - 2011-10-17 06:43:33 --> Output Class Initialized
DEBUG - 2011-10-17 06:43:33 --> Input Class Initialized
DEBUG - 2011-10-17 06:43:33 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-17 06:43:33 --> Language Class Initialized
DEBUG - 2011-10-17 06:43:33 --> Loader Class Initialized
DEBUG - 2011-10-17 06:43:33 --> Controller Class Initialized
ERROR - 2011-10-17 06:43:33 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-10-17 06:43:33 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-10-17 06:43:33 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-17 06:43:33 --> Model Class Initialized
DEBUG - 2011-10-17 06:43:33 --> Model Class Initialized
DEBUG - 2011-10-17 06:43:33 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-17 06:43:33 --> Database Driver Class Initialized
DEBUG - 2011-10-17 06:43:33 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-17 06:43:33 --> Helper loaded: url_helper
DEBUG - 2011-10-17 06:43:33 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-17 06:43:33 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-17 06:43:33 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-17 06:43:33 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-17 06:43:33 --> Final output sent to browser
DEBUG - 2011-10-17 06:43:33 --> Total execution time: 0.0297
DEBUG - 2011-10-17 06:43:34 --> Config Class Initialized
DEBUG - 2011-10-17 06:43:34 --> Hooks Class Initialized
DEBUG - 2011-10-17 06:43:34 --> Utf8 Class Initialized
DEBUG - 2011-10-17 06:43:34 --> UTF-8 Support Enabled
DEBUG - 2011-10-17 06:43:34 --> URI Class Initialized
DEBUG - 2011-10-17 06:43:34 --> Router Class Initialized
DEBUG - 2011-10-17 06:43:34 --> Output Class Initialized
DEBUG - 2011-10-17 06:43:34 --> Input Class Initialized
DEBUG - 2011-10-17 06:43:34 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-17 06:43:34 --> Language Class Initialized
DEBUG - 2011-10-17 06:43:34 --> Loader Class Initialized
DEBUG - 2011-10-17 06:43:34 --> Controller Class Initialized
DEBUG - 2011-10-17 06:43:34 --> Model Class Initialized
DEBUG - 2011-10-17 06:43:34 --> Model Class Initialized
DEBUG - 2011-10-17 06:43:34 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-17 06:43:34 --> Database Driver Class Initialized
DEBUG - 2011-10-17 06:43:35 --> Final output sent to browser
DEBUG - 2011-10-17 06:43:35 --> Total execution time: 1.1327
DEBUG - 2011-10-17 06:43:43 --> Config Class Initialized
DEBUG - 2011-10-17 06:43:43 --> Hooks Class Initialized
DEBUG - 2011-10-17 06:43:43 --> Utf8 Class Initialized
DEBUG - 2011-10-17 06:43:43 --> UTF-8 Support Enabled
DEBUG - 2011-10-17 06:43:43 --> URI Class Initialized
DEBUG - 2011-10-17 06:43:43 --> Router Class Initialized
DEBUG - 2011-10-17 06:43:43 --> Output Class Initialized
DEBUG - 2011-10-17 06:43:43 --> Input Class Initialized
DEBUG - 2011-10-17 06:43:43 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-17 06:43:43 --> Language Class Initialized
DEBUG - 2011-10-17 06:43:43 --> Loader Class Initialized
DEBUG - 2011-10-17 06:43:43 --> Controller Class Initialized
ERROR - 2011-10-17 06:43:43 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-10-17 06:43:43 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-10-17 06:43:43 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-17 06:43:43 --> Model Class Initialized
DEBUG - 2011-10-17 06:43:43 --> Model Class Initialized
DEBUG - 2011-10-17 06:43:43 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-17 06:43:43 --> Database Driver Class Initialized
DEBUG - 2011-10-17 06:43:43 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-17 06:43:43 --> Helper loaded: url_helper
DEBUG - 2011-10-17 06:43:43 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-17 06:43:43 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-17 06:43:43 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-17 06:43:43 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-17 06:43:43 --> Final output sent to browser
DEBUG - 2011-10-17 06:43:43 --> Total execution time: 0.1119
DEBUG - 2011-10-17 06:43:43 --> Config Class Initialized
DEBUG - 2011-10-17 06:43:43 --> Hooks Class Initialized
DEBUG - 2011-10-17 06:43:43 --> Utf8 Class Initialized
DEBUG - 2011-10-17 06:43:43 --> UTF-8 Support Enabled
DEBUG - 2011-10-17 06:43:43 --> URI Class Initialized
DEBUG - 2011-10-17 06:43:43 --> Router Class Initialized
DEBUG - 2011-10-17 06:43:43 --> Output Class Initialized
DEBUG - 2011-10-17 06:43:43 --> Input Class Initialized
DEBUG - 2011-10-17 06:43:43 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-17 06:43:43 --> Language Class Initialized
DEBUG - 2011-10-17 06:43:43 --> Loader Class Initialized
DEBUG - 2011-10-17 06:43:43 --> Controller Class Initialized
DEBUG - 2011-10-17 06:43:43 --> Model Class Initialized
DEBUG - 2011-10-17 06:43:43 --> Model Class Initialized
DEBUG - 2011-10-17 06:43:43 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-17 06:43:43 --> Database Driver Class Initialized
DEBUG - 2011-10-17 06:43:44 --> Final output sent to browser
DEBUG - 2011-10-17 06:43:44 --> Total execution time: 0.4695
DEBUG - 2011-10-17 06:43:48 --> Config Class Initialized
DEBUG - 2011-10-17 06:43:48 --> Hooks Class Initialized
DEBUG - 2011-10-17 06:43:48 --> Utf8 Class Initialized
DEBUG - 2011-10-17 06:43:48 --> UTF-8 Support Enabled
DEBUG - 2011-10-17 06:43:48 --> URI Class Initialized
DEBUG - 2011-10-17 06:43:48 --> Router Class Initialized
DEBUG - 2011-10-17 06:43:48 --> Output Class Initialized
DEBUG - 2011-10-17 06:43:48 --> Input Class Initialized
DEBUG - 2011-10-17 06:43:48 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-17 06:43:48 --> Language Class Initialized
DEBUG - 2011-10-17 06:43:48 --> Loader Class Initialized
DEBUG - 2011-10-17 06:43:48 --> Controller Class Initialized
ERROR - 2011-10-17 06:43:48 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-10-17 06:43:48 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-10-17 06:43:48 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-17 06:43:48 --> Model Class Initialized
DEBUG - 2011-10-17 06:43:48 --> Model Class Initialized
DEBUG - 2011-10-17 06:43:48 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-17 06:43:48 --> Database Driver Class Initialized
DEBUG - 2011-10-17 06:43:48 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-17 06:43:48 --> Helper loaded: url_helper
DEBUG - 2011-10-17 06:43:48 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-17 06:43:48 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-17 06:43:48 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-17 06:43:48 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-17 06:43:48 --> Final output sent to browser
DEBUG - 2011-10-17 06:43:48 --> Total execution time: 0.0821
DEBUG - 2011-10-17 06:43:48 --> Config Class Initialized
DEBUG - 2011-10-17 06:43:48 --> Hooks Class Initialized
DEBUG - 2011-10-17 06:43:48 --> Utf8 Class Initialized
DEBUG - 2011-10-17 06:43:48 --> UTF-8 Support Enabled
DEBUG - 2011-10-17 06:43:48 --> URI Class Initialized
DEBUG - 2011-10-17 06:43:48 --> Router Class Initialized
DEBUG - 2011-10-17 06:43:48 --> Output Class Initialized
DEBUG - 2011-10-17 06:43:48 --> Input Class Initialized
DEBUG - 2011-10-17 06:43:48 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-17 06:43:48 --> Language Class Initialized
DEBUG - 2011-10-17 06:43:48 --> Loader Class Initialized
DEBUG - 2011-10-17 06:43:48 --> Controller Class Initialized
DEBUG - 2011-10-17 06:43:48 --> Model Class Initialized
DEBUG - 2011-10-17 06:43:48 --> Model Class Initialized
DEBUG - 2011-10-17 06:43:48 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-17 06:43:48 --> Database Driver Class Initialized
DEBUG - 2011-10-17 06:43:49 --> Final output sent to browser
DEBUG - 2011-10-17 06:43:49 --> Total execution time: 0.9337
DEBUG - 2011-10-17 06:43:58 --> Config Class Initialized
DEBUG - 2011-10-17 06:43:58 --> Hooks Class Initialized
DEBUG - 2011-10-17 06:43:58 --> Utf8 Class Initialized
DEBUG - 2011-10-17 06:43:58 --> UTF-8 Support Enabled
DEBUG - 2011-10-17 06:43:58 --> URI Class Initialized
DEBUG - 2011-10-17 06:43:58 --> Router Class Initialized
DEBUG - 2011-10-17 06:43:58 --> Output Class Initialized
DEBUG - 2011-10-17 06:43:58 --> Input Class Initialized
DEBUG - 2011-10-17 06:43:58 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-17 06:43:58 --> Language Class Initialized
DEBUG - 2011-10-17 06:43:58 --> Loader Class Initialized
DEBUG - 2011-10-17 06:43:58 --> Controller Class Initialized
ERROR - 2011-10-17 06:43:58 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-10-17 06:43:58 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-10-17 06:43:58 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-17 06:43:58 --> Model Class Initialized
DEBUG - 2011-10-17 06:43:58 --> Model Class Initialized
DEBUG - 2011-10-17 06:43:58 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-17 06:43:58 --> Database Driver Class Initialized
DEBUG - 2011-10-17 06:43:58 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-17 06:43:58 --> Helper loaded: url_helper
DEBUG - 2011-10-17 06:43:58 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-17 06:43:58 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-17 06:43:58 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-17 06:43:58 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-17 06:43:58 --> Final output sent to browser
DEBUG - 2011-10-17 06:43:58 --> Total execution time: 0.0336
DEBUG - 2011-10-17 06:43:59 --> Config Class Initialized
DEBUG - 2011-10-17 06:43:59 --> Hooks Class Initialized
DEBUG - 2011-10-17 06:43:59 --> Utf8 Class Initialized
DEBUG - 2011-10-17 06:43:59 --> UTF-8 Support Enabled
DEBUG - 2011-10-17 06:43:59 --> URI Class Initialized
DEBUG - 2011-10-17 06:43:59 --> Router Class Initialized
DEBUG - 2011-10-17 06:43:59 --> Output Class Initialized
DEBUG - 2011-10-17 06:43:59 --> Input Class Initialized
DEBUG - 2011-10-17 06:43:59 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-17 06:43:59 --> Language Class Initialized
DEBUG - 2011-10-17 06:43:59 --> Loader Class Initialized
DEBUG - 2011-10-17 06:43:59 --> Controller Class Initialized
DEBUG - 2011-10-17 06:43:59 --> Model Class Initialized
DEBUG - 2011-10-17 06:43:59 --> Model Class Initialized
DEBUG - 2011-10-17 06:43:59 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-17 06:43:59 --> Database Driver Class Initialized
DEBUG - 2011-10-17 06:44:00 --> Final output sent to browser
DEBUG - 2011-10-17 06:44:00 --> Total execution time: 1.0332
DEBUG - 2011-10-17 06:44:26 --> Config Class Initialized
DEBUG - 2011-10-17 06:44:26 --> Hooks Class Initialized
DEBUG - 2011-10-17 06:44:26 --> Utf8 Class Initialized
DEBUG - 2011-10-17 06:44:26 --> UTF-8 Support Enabled
DEBUG - 2011-10-17 06:44:26 --> URI Class Initialized
DEBUG - 2011-10-17 06:44:26 --> Router Class Initialized
DEBUG - 2011-10-17 06:44:26 --> Output Class Initialized
DEBUG - 2011-10-17 06:44:26 --> Input Class Initialized
DEBUG - 2011-10-17 06:44:26 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-17 06:44:26 --> Language Class Initialized
DEBUG - 2011-10-17 06:44:26 --> Loader Class Initialized
DEBUG - 2011-10-17 06:44:26 --> Controller Class Initialized
ERROR - 2011-10-17 06:44:26 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-10-17 06:44:26 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-10-17 06:44:26 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-17 06:44:26 --> Model Class Initialized
DEBUG - 2011-10-17 06:44:26 --> Model Class Initialized
DEBUG - 2011-10-17 06:44:26 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-17 06:44:26 --> Database Driver Class Initialized
DEBUG - 2011-10-17 06:44:27 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-17 06:44:27 --> Helper loaded: url_helper
DEBUG - 2011-10-17 06:44:27 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-17 06:44:27 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-17 06:44:27 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-17 06:44:27 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-17 06:44:27 --> Final output sent to browser
DEBUG - 2011-10-17 06:44:27 --> Total execution time: 0.7082
DEBUG - 2011-10-17 06:44:28 --> Config Class Initialized
DEBUG - 2011-10-17 06:44:28 --> Hooks Class Initialized
DEBUG - 2011-10-17 06:44:28 --> Utf8 Class Initialized
DEBUG - 2011-10-17 06:44:28 --> UTF-8 Support Enabled
DEBUG - 2011-10-17 06:44:28 --> URI Class Initialized
DEBUG - 2011-10-17 06:44:28 --> Router Class Initialized
DEBUG - 2011-10-17 06:44:28 --> Output Class Initialized
DEBUG - 2011-10-17 06:44:28 --> Input Class Initialized
DEBUG - 2011-10-17 06:44:28 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-17 06:44:28 --> Language Class Initialized
DEBUG - 2011-10-17 06:44:28 --> Loader Class Initialized
DEBUG - 2011-10-17 06:44:28 --> Controller Class Initialized
DEBUG - 2011-10-17 06:44:28 --> Model Class Initialized
DEBUG - 2011-10-17 06:44:28 --> Model Class Initialized
DEBUG - 2011-10-17 06:44:28 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-17 06:44:28 --> Database Driver Class Initialized
DEBUG - 2011-10-17 06:44:29 --> Final output sent to browser
DEBUG - 2011-10-17 06:44:29 --> Total execution time: 0.5437
DEBUG - 2011-10-17 06:46:45 --> Config Class Initialized
DEBUG - 2011-10-17 06:46:45 --> Hooks Class Initialized
DEBUG - 2011-10-17 06:46:45 --> Utf8 Class Initialized
DEBUG - 2011-10-17 06:46:45 --> UTF-8 Support Enabled
DEBUG - 2011-10-17 06:46:45 --> URI Class Initialized
DEBUG - 2011-10-17 06:46:45 --> Router Class Initialized
DEBUG - 2011-10-17 06:46:45 --> Output Class Initialized
DEBUG - 2011-10-17 06:46:45 --> Input Class Initialized
DEBUG - 2011-10-17 06:46:45 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-17 06:46:45 --> Language Class Initialized
DEBUG - 2011-10-17 06:46:45 --> Loader Class Initialized
DEBUG - 2011-10-17 06:46:45 --> Controller Class Initialized
DEBUG - 2011-10-17 06:46:45 --> Model Class Initialized
DEBUG - 2011-10-17 06:46:45 --> Model Class Initialized
DEBUG - 2011-10-17 06:46:45 --> Model Class Initialized
DEBUG - 2011-10-17 06:46:45 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-17 06:46:45 --> Database Driver Class Initialized
DEBUG - 2011-10-17 06:46:45 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-17 06:46:45 --> Helper loaded: url_helper
DEBUG - 2011-10-17 06:46:45 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-17 06:46:45 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-17 06:46:45 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-17 06:46:45 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-17 06:46:45 --> Final output sent to browser
DEBUG - 2011-10-17 06:46:45 --> Total execution time: 0.0467
DEBUG - 2011-10-17 06:46:49 --> Config Class Initialized
DEBUG - 2011-10-17 06:46:49 --> Hooks Class Initialized
DEBUG - 2011-10-17 06:46:49 --> Utf8 Class Initialized
DEBUG - 2011-10-17 06:46:49 --> UTF-8 Support Enabled
DEBUG - 2011-10-17 06:46:49 --> URI Class Initialized
DEBUG - 2011-10-17 06:46:49 --> Router Class Initialized
ERROR - 2011-10-17 06:46:49 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-17 06:47:48 --> Config Class Initialized
DEBUG - 2011-10-17 06:47:48 --> Hooks Class Initialized
DEBUG - 2011-10-17 06:47:48 --> Utf8 Class Initialized
DEBUG - 2011-10-17 06:47:48 --> UTF-8 Support Enabled
DEBUG - 2011-10-17 06:47:48 --> URI Class Initialized
DEBUG - 2011-10-17 06:47:48 --> Router Class Initialized
DEBUG - 2011-10-17 06:47:48 --> Output Class Initialized
DEBUG - 2011-10-17 06:47:48 --> Input Class Initialized
DEBUG - 2011-10-17 06:47:48 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-17 06:47:48 --> Language Class Initialized
DEBUG - 2011-10-17 06:47:48 --> Loader Class Initialized
DEBUG - 2011-10-17 06:47:48 --> Controller Class Initialized
DEBUG - 2011-10-17 06:47:48 --> Model Class Initialized
DEBUG - 2011-10-17 06:47:48 --> Model Class Initialized
DEBUG - 2011-10-17 06:47:48 --> Model Class Initialized
DEBUG - 2011-10-17 06:47:48 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-17 06:47:48 --> Database Driver Class Initialized
DEBUG - 2011-10-17 06:47:48 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-17 06:47:48 --> Helper loaded: url_helper
DEBUG - 2011-10-17 06:47:48 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-17 06:47:48 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-17 06:47:48 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-17 06:47:48 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-17 06:47:48 --> Final output sent to browser
DEBUG - 2011-10-17 06:47:48 --> Total execution time: 0.0802
DEBUG - 2011-10-17 06:48:00 --> Config Class Initialized
DEBUG - 2011-10-17 06:48:00 --> Hooks Class Initialized
DEBUG - 2011-10-17 06:48:00 --> Utf8 Class Initialized
DEBUG - 2011-10-17 06:48:00 --> UTF-8 Support Enabled
DEBUG - 2011-10-17 06:48:00 --> URI Class Initialized
DEBUG - 2011-10-17 06:48:00 --> Router Class Initialized
DEBUG - 2011-10-17 06:48:00 --> Output Class Initialized
DEBUG - 2011-10-17 06:48:00 --> Input Class Initialized
DEBUG - 2011-10-17 06:48:00 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-17 06:48:00 --> Language Class Initialized
DEBUG - 2011-10-17 06:48:00 --> Loader Class Initialized
DEBUG - 2011-10-17 06:48:00 --> Controller Class Initialized
ERROR - 2011-10-17 06:48:00 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-10-17 06:48:00 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-10-17 06:48:00 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-17 06:48:00 --> Model Class Initialized
DEBUG - 2011-10-17 06:48:00 --> Model Class Initialized
DEBUG - 2011-10-17 06:48:00 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-17 06:48:00 --> Database Driver Class Initialized
DEBUG - 2011-10-17 06:48:00 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-17 06:48:00 --> Helper loaded: url_helper
DEBUG - 2011-10-17 06:48:00 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-17 06:48:00 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-17 06:48:00 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-17 06:48:00 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-17 06:48:00 --> Final output sent to browser
DEBUG - 2011-10-17 06:48:00 --> Total execution time: 0.0413
DEBUG - 2011-10-17 06:48:02 --> Config Class Initialized
DEBUG - 2011-10-17 06:48:02 --> Hooks Class Initialized
DEBUG - 2011-10-17 06:48:02 --> Utf8 Class Initialized
DEBUG - 2011-10-17 06:48:02 --> UTF-8 Support Enabled
DEBUG - 2011-10-17 06:48:02 --> URI Class Initialized
DEBUG - 2011-10-17 06:48:02 --> Router Class Initialized
DEBUG - 2011-10-17 06:48:02 --> Output Class Initialized
DEBUG - 2011-10-17 06:48:02 --> Input Class Initialized
DEBUG - 2011-10-17 06:48:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-17 06:48:02 --> Language Class Initialized
DEBUG - 2011-10-17 06:48:02 --> Loader Class Initialized
DEBUG - 2011-10-17 06:48:02 --> Controller Class Initialized
DEBUG - 2011-10-17 06:48:02 --> Model Class Initialized
DEBUG - 2011-10-17 06:48:02 --> Model Class Initialized
DEBUG - 2011-10-17 06:48:02 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-17 06:48:02 --> Database Driver Class Initialized
DEBUG - 2011-10-17 06:48:02 --> Config Class Initialized
DEBUG - 2011-10-17 06:48:02 --> Hooks Class Initialized
DEBUG - 2011-10-17 06:48:02 --> Utf8 Class Initialized
DEBUG - 2011-10-17 06:48:02 --> UTF-8 Support Enabled
DEBUG - 2011-10-17 06:48:02 --> URI Class Initialized
DEBUG - 2011-10-17 06:48:02 --> Router Class Initialized
DEBUG - 2011-10-17 06:48:02 --> Output Class Initialized
DEBUG - 2011-10-17 06:48:02 --> Input Class Initialized
DEBUG - 2011-10-17 06:48:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-17 06:48:02 --> Language Class Initialized
DEBUG - 2011-10-17 06:48:02 --> Loader Class Initialized
DEBUG - 2011-10-17 06:48:02 --> Controller Class Initialized
DEBUG - 2011-10-17 06:48:02 --> Model Class Initialized
DEBUG - 2011-10-17 06:48:02 --> Model Class Initialized
DEBUG - 2011-10-17 06:48:02 --> Model Class Initialized
DEBUG - 2011-10-17 06:48:02 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-17 06:48:02 --> Database Driver Class Initialized
DEBUG - 2011-10-17 06:48:03 --> Final output sent to browser
DEBUG - 2011-10-17 06:48:03 --> Total execution time: 0.6425
DEBUG - 2011-10-17 06:48:03 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-17 06:48:03 --> Helper loaded: url_helper
DEBUG - 2011-10-17 06:48:03 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-17 06:48:03 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-17 06:48:03 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-17 06:48:03 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-17 06:48:03 --> Final output sent to browser
DEBUG - 2011-10-17 06:48:03 --> Total execution time: 0.6668
DEBUG - 2011-10-17 06:48:07 --> Config Class Initialized
DEBUG - 2011-10-17 06:48:07 --> Hooks Class Initialized
DEBUG - 2011-10-17 06:48:07 --> Utf8 Class Initialized
DEBUG - 2011-10-17 06:48:07 --> UTF-8 Support Enabled
DEBUG - 2011-10-17 06:48:07 --> URI Class Initialized
DEBUG - 2011-10-17 06:48:07 --> Router Class Initialized
DEBUG - 2011-10-17 06:48:07 --> Output Class Initialized
DEBUG - 2011-10-17 06:48:07 --> Input Class Initialized
DEBUG - 2011-10-17 06:48:07 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-17 06:48:07 --> Language Class Initialized
DEBUG - 2011-10-17 06:48:07 --> Loader Class Initialized
DEBUG - 2011-10-17 06:48:07 --> Controller Class Initialized
DEBUG - 2011-10-17 06:48:07 --> Model Class Initialized
DEBUG - 2011-10-17 06:48:07 --> Model Class Initialized
DEBUG - 2011-10-17 06:48:07 --> Model Class Initialized
DEBUG - 2011-10-17 06:48:07 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-17 06:48:07 --> Database Driver Class Initialized
DEBUG - 2011-10-17 06:48:07 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-17 06:48:07 --> Helper loaded: url_helper
DEBUG - 2011-10-17 06:48:07 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-17 06:48:07 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-17 06:48:07 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-17 06:48:07 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-17 06:48:07 --> Final output sent to browser
DEBUG - 2011-10-17 06:48:07 --> Total execution time: 0.0673
DEBUG - 2011-10-17 06:48:28 --> Config Class Initialized
DEBUG - 2011-10-17 06:48:28 --> Hooks Class Initialized
DEBUG - 2011-10-17 06:48:28 --> Utf8 Class Initialized
DEBUG - 2011-10-17 06:48:28 --> UTF-8 Support Enabled
DEBUG - 2011-10-17 06:48:28 --> URI Class Initialized
DEBUG - 2011-10-17 06:48:28 --> Router Class Initialized
DEBUG - 2011-10-17 06:48:28 --> Output Class Initialized
DEBUG - 2011-10-17 06:48:28 --> Input Class Initialized
DEBUG - 2011-10-17 06:48:28 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-17 06:48:28 --> Language Class Initialized
DEBUG - 2011-10-17 06:48:28 --> Loader Class Initialized
DEBUG - 2011-10-17 06:48:28 --> Controller Class Initialized
ERROR - 2011-10-17 06:48:28 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-10-17 06:48:28 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-10-17 06:48:28 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-17 06:48:28 --> Model Class Initialized
DEBUG - 2011-10-17 06:48:28 --> Model Class Initialized
DEBUG - 2011-10-17 06:48:28 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-17 06:48:28 --> Database Driver Class Initialized
DEBUG - 2011-10-17 06:48:28 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-17 06:48:28 --> Helper loaded: url_helper
DEBUG - 2011-10-17 06:48:28 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-17 06:48:28 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-17 06:48:28 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-17 06:48:28 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-17 06:48:28 --> Final output sent to browser
DEBUG - 2011-10-17 06:48:28 --> Total execution time: 0.0480
DEBUG - 2011-10-17 06:48:29 --> Config Class Initialized
DEBUG - 2011-10-17 06:48:29 --> Hooks Class Initialized
DEBUG - 2011-10-17 06:48:29 --> Utf8 Class Initialized
DEBUG - 2011-10-17 06:48:29 --> UTF-8 Support Enabled
DEBUG - 2011-10-17 06:48:29 --> URI Class Initialized
DEBUG - 2011-10-17 06:48:29 --> Router Class Initialized
DEBUG - 2011-10-17 06:48:29 --> Output Class Initialized
DEBUG - 2011-10-17 06:48:29 --> Input Class Initialized
DEBUG - 2011-10-17 06:48:29 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-17 06:48:29 --> Language Class Initialized
DEBUG - 2011-10-17 06:48:29 --> Loader Class Initialized
DEBUG - 2011-10-17 06:48:29 --> Controller Class Initialized
DEBUG - 2011-10-17 06:48:29 --> Model Class Initialized
DEBUG - 2011-10-17 06:48:29 --> Model Class Initialized
DEBUG - 2011-10-17 06:48:29 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-17 06:48:29 --> Database Driver Class Initialized
DEBUG - 2011-10-17 06:48:30 --> Final output sent to browser
DEBUG - 2011-10-17 06:48:30 --> Total execution time: 0.5463
DEBUG - 2011-10-17 06:48:36 --> Config Class Initialized
DEBUG - 2011-10-17 06:48:36 --> Hooks Class Initialized
DEBUG - 2011-10-17 06:48:36 --> Utf8 Class Initialized
DEBUG - 2011-10-17 06:48:36 --> UTF-8 Support Enabled
DEBUG - 2011-10-17 06:48:36 --> URI Class Initialized
DEBUG - 2011-10-17 06:48:36 --> Router Class Initialized
DEBUG - 2011-10-17 06:48:36 --> Output Class Initialized
DEBUG - 2011-10-17 06:48:36 --> Input Class Initialized
DEBUG - 2011-10-17 06:48:36 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-17 06:48:36 --> Language Class Initialized
DEBUG - 2011-10-17 06:48:36 --> Loader Class Initialized
DEBUG - 2011-10-17 06:48:36 --> Controller Class Initialized
DEBUG - 2011-10-17 06:48:36 --> Model Class Initialized
DEBUG - 2011-10-17 06:48:36 --> Model Class Initialized
DEBUG - 2011-10-17 06:48:36 --> Model Class Initialized
DEBUG - 2011-10-17 06:48:36 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-17 06:48:36 --> Database Driver Class Initialized
DEBUG - 2011-10-17 06:48:36 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-17 06:48:36 --> Helper loaded: url_helper
DEBUG - 2011-10-17 06:48:36 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-17 06:48:36 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-17 06:48:36 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-17 06:48:36 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-17 06:48:36 --> Final output sent to browser
DEBUG - 2011-10-17 06:48:36 --> Total execution time: 0.2556
DEBUG - 2011-10-17 06:48:37 --> Config Class Initialized
DEBUG - 2011-10-17 06:48:37 --> Hooks Class Initialized
DEBUG - 2011-10-17 06:48:37 --> Utf8 Class Initialized
DEBUG - 2011-10-17 06:48:37 --> UTF-8 Support Enabled
DEBUG - 2011-10-17 06:48:37 --> URI Class Initialized
DEBUG - 2011-10-17 06:48:37 --> Router Class Initialized
DEBUG - 2011-10-17 06:48:37 --> Output Class Initialized
DEBUG - 2011-10-17 06:48:37 --> Input Class Initialized
DEBUG - 2011-10-17 06:48:37 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-17 06:48:37 --> Language Class Initialized
DEBUG - 2011-10-17 06:48:37 --> Loader Class Initialized
DEBUG - 2011-10-17 06:48:37 --> Controller Class Initialized
DEBUG - 2011-10-17 06:48:37 --> Model Class Initialized
DEBUG - 2011-10-17 06:48:37 --> Model Class Initialized
DEBUG - 2011-10-17 06:48:37 --> Model Class Initialized
DEBUG - 2011-10-17 06:48:37 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-17 06:48:37 --> Database Driver Class Initialized
DEBUG - 2011-10-17 06:48:37 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-17 06:48:37 --> Helper loaded: url_helper
DEBUG - 2011-10-17 06:48:37 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-17 06:48:37 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-17 06:48:37 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-17 06:48:37 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-17 06:48:37 --> Final output sent to browser
DEBUG - 2011-10-17 06:48:37 --> Total execution time: 0.0422
DEBUG - 2011-10-17 06:48:54 --> Config Class Initialized
DEBUG - 2011-10-17 06:48:54 --> Hooks Class Initialized
DEBUG - 2011-10-17 06:48:54 --> Utf8 Class Initialized
DEBUG - 2011-10-17 06:48:54 --> UTF-8 Support Enabled
DEBUG - 2011-10-17 06:48:54 --> URI Class Initialized
DEBUG - 2011-10-17 06:48:54 --> Router Class Initialized
DEBUG - 2011-10-17 06:48:54 --> Output Class Initialized
DEBUG - 2011-10-17 06:48:54 --> Input Class Initialized
DEBUG - 2011-10-17 06:48:54 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-17 06:48:54 --> Language Class Initialized
DEBUG - 2011-10-17 06:48:54 --> Loader Class Initialized
DEBUG - 2011-10-17 06:48:54 --> Controller Class Initialized
DEBUG - 2011-10-17 06:48:54 --> Model Class Initialized
DEBUG - 2011-10-17 06:48:54 --> Model Class Initialized
DEBUG - 2011-10-17 06:48:54 --> Model Class Initialized
DEBUG - 2011-10-17 06:48:54 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-17 06:48:54 --> Database Driver Class Initialized
DEBUG - 2011-10-17 06:48:54 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-17 06:48:54 --> Helper loaded: url_helper
DEBUG - 2011-10-17 06:48:54 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-17 06:48:54 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-17 06:48:54 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-17 06:48:54 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-17 06:48:54 --> Final output sent to browser
DEBUG - 2011-10-17 06:48:54 --> Total execution time: 0.2190
DEBUG - 2011-10-17 06:48:55 --> Config Class Initialized
DEBUG - 2011-10-17 06:48:55 --> Hooks Class Initialized
DEBUG - 2011-10-17 06:48:55 --> Utf8 Class Initialized
DEBUG - 2011-10-17 06:48:55 --> UTF-8 Support Enabled
DEBUG - 2011-10-17 06:48:55 --> URI Class Initialized
DEBUG - 2011-10-17 06:48:55 --> Router Class Initialized
DEBUG - 2011-10-17 06:48:55 --> Output Class Initialized
DEBUG - 2011-10-17 06:48:55 --> Input Class Initialized
DEBUG - 2011-10-17 06:48:55 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-17 06:48:55 --> Language Class Initialized
DEBUG - 2011-10-17 06:48:55 --> Loader Class Initialized
DEBUG - 2011-10-17 06:48:55 --> Controller Class Initialized
DEBUG - 2011-10-17 06:48:55 --> Model Class Initialized
DEBUG - 2011-10-17 06:48:55 --> Model Class Initialized
DEBUG - 2011-10-17 06:48:55 --> Model Class Initialized
DEBUG - 2011-10-17 06:48:55 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-17 06:48:55 --> Database Driver Class Initialized
DEBUG - 2011-10-17 06:48:55 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-17 06:48:55 --> Helper loaded: url_helper
DEBUG - 2011-10-17 06:48:55 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-17 06:48:55 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-17 06:48:55 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-17 06:48:55 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-17 06:48:55 --> Final output sent to browser
DEBUG - 2011-10-17 06:48:55 --> Total execution time: 0.0771
DEBUG - 2011-10-17 06:49:02 --> Config Class Initialized
DEBUG - 2011-10-17 06:49:02 --> Hooks Class Initialized
DEBUG - 2011-10-17 06:49:02 --> Utf8 Class Initialized
DEBUG - 2011-10-17 06:49:02 --> UTF-8 Support Enabled
DEBUG - 2011-10-17 06:49:02 --> URI Class Initialized
DEBUG - 2011-10-17 06:49:02 --> Router Class Initialized
DEBUG - 2011-10-17 06:49:02 --> Output Class Initialized
DEBUG - 2011-10-17 06:49:02 --> Input Class Initialized
DEBUG - 2011-10-17 06:49:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-17 06:49:02 --> Language Class Initialized
DEBUG - 2011-10-17 06:49:02 --> Loader Class Initialized
DEBUG - 2011-10-17 06:49:02 --> Controller Class Initialized
DEBUG - 2011-10-17 06:49:02 --> Model Class Initialized
DEBUG - 2011-10-17 06:49:02 --> Model Class Initialized
DEBUG - 2011-10-17 06:49:02 --> Model Class Initialized
DEBUG - 2011-10-17 06:49:02 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-17 06:49:02 --> Database Driver Class Initialized
DEBUG - 2011-10-17 06:49:03 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-17 06:49:03 --> Helper loaded: url_helper
DEBUG - 2011-10-17 06:49:03 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-17 06:49:03 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-17 06:49:03 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-17 06:49:03 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-17 06:49:03 --> Final output sent to browser
DEBUG - 2011-10-17 06:49:03 --> Total execution time: 0.6331
DEBUG - 2011-10-17 06:49:04 --> Config Class Initialized
DEBUG - 2011-10-17 06:49:04 --> Hooks Class Initialized
DEBUG - 2011-10-17 06:49:04 --> Utf8 Class Initialized
DEBUG - 2011-10-17 06:49:04 --> UTF-8 Support Enabled
DEBUG - 2011-10-17 06:49:04 --> URI Class Initialized
DEBUG - 2011-10-17 06:49:04 --> Router Class Initialized
DEBUG - 2011-10-17 06:49:04 --> Output Class Initialized
DEBUG - 2011-10-17 06:49:04 --> Input Class Initialized
DEBUG - 2011-10-17 06:49:04 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-17 06:49:04 --> Language Class Initialized
DEBUG - 2011-10-17 06:49:04 --> Loader Class Initialized
DEBUG - 2011-10-17 06:49:04 --> Controller Class Initialized
DEBUG - 2011-10-17 06:49:04 --> Model Class Initialized
DEBUG - 2011-10-17 06:49:04 --> Model Class Initialized
DEBUG - 2011-10-17 06:49:04 --> Model Class Initialized
DEBUG - 2011-10-17 06:49:04 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-17 06:49:04 --> Database Driver Class Initialized
DEBUG - 2011-10-17 06:49:04 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-17 06:49:04 --> Helper loaded: url_helper
DEBUG - 2011-10-17 06:49:04 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-17 06:49:04 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-17 06:49:04 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-17 06:49:04 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-17 06:49:04 --> Final output sent to browser
DEBUG - 2011-10-17 06:49:04 --> Total execution time: 0.1674
DEBUG - 2011-10-17 06:49:11 --> Config Class Initialized
DEBUG - 2011-10-17 06:49:11 --> Hooks Class Initialized
DEBUG - 2011-10-17 06:49:11 --> Utf8 Class Initialized
DEBUG - 2011-10-17 06:49:11 --> UTF-8 Support Enabled
DEBUG - 2011-10-17 06:49:11 --> URI Class Initialized
DEBUG - 2011-10-17 06:49:11 --> Router Class Initialized
DEBUG - 2011-10-17 06:49:11 --> Output Class Initialized
DEBUG - 2011-10-17 06:49:11 --> Input Class Initialized
DEBUG - 2011-10-17 06:49:11 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-17 06:49:11 --> Language Class Initialized
DEBUG - 2011-10-17 06:49:11 --> Loader Class Initialized
DEBUG - 2011-10-17 06:49:11 --> Controller Class Initialized
DEBUG - 2011-10-17 06:49:11 --> Model Class Initialized
DEBUG - 2011-10-17 06:49:11 --> Model Class Initialized
DEBUG - 2011-10-17 06:49:11 --> Model Class Initialized
DEBUG - 2011-10-17 06:49:11 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-17 06:49:11 --> Database Driver Class Initialized
DEBUG - 2011-10-17 06:49:11 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-17 06:49:11 --> Helper loaded: url_helper
DEBUG - 2011-10-17 06:49:11 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-17 06:49:11 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-17 06:49:11 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-17 06:49:11 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-17 06:49:11 --> Final output sent to browser
DEBUG - 2011-10-17 06:49:11 --> Total execution time: 0.0885
DEBUG - 2011-10-17 06:49:27 --> Config Class Initialized
DEBUG - 2011-10-17 06:49:27 --> Hooks Class Initialized
DEBUG - 2011-10-17 06:49:27 --> Utf8 Class Initialized
DEBUG - 2011-10-17 06:49:27 --> UTF-8 Support Enabled
DEBUG - 2011-10-17 06:49:27 --> URI Class Initialized
DEBUG - 2011-10-17 06:49:27 --> Router Class Initialized
DEBUG - 2011-10-17 06:49:27 --> Output Class Initialized
DEBUG - 2011-10-17 06:49:27 --> Input Class Initialized
DEBUG - 2011-10-17 06:49:27 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-17 06:49:27 --> Language Class Initialized
DEBUG - 2011-10-17 06:49:27 --> Loader Class Initialized
DEBUG - 2011-10-17 06:49:27 --> Controller Class Initialized
DEBUG - 2011-10-17 06:49:27 --> Model Class Initialized
DEBUG - 2011-10-17 06:49:27 --> Model Class Initialized
DEBUG - 2011-10-17 06:49:27 --> Model Class Initialized
DEBUG - 2011-10-17 06:49:27 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-17 06:49:27 --> Database Driver Class Initialized
DEBUG - 2011-10-17 06:49:28 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-17 06:49:28 --> Helper loaded: url_helper
DEBUG - 2011-10-17 06:49:28 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-17 06:49:28 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-17 06:49:28 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-17 06:49:28 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-17 06:49:28 --> Final output sent to browser
DEBUG - 2011-10-17 06:49:28 --> Total execution time: 0.2105
DEBUG - 2011-10-17 06:49:30 --> Config Class Initialized
DEBUG - 2011-10-17 06:49:30 --> Hooks Class Initialized
DEBUG - 2011-10-17 06:49:30 --> Utf8 Class Initialized
DEBUG - 2011-10-17 06:49:30 --> UTF-8 Support Enabled
DEBUG - 2011-10-17 06:49:30 --> URI Class Initialized
DEBUG - 2011-10-17 06:49:30 --> Router Class Initialized
DEBUG - 2011-10-17 06:49:30 --> Output Class Initialized
DEBUG - 2011-10-17 06:49:30 --> Input Class Initialized
DEBUG - 2011-10-17 06:49:30 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-17 06:49:30 --> Language Class Initialized
DEBUG - 2011-10-17 06:49:30 --> Loader Class Initialized
DEBUG - 2011-10-17 06:49:30 --> Controller Class Initialized
DEBUG - 2011-10-17 06:49:30 --> Model Class Initialized
DEBUG - 2011-10-17 06:49:30 --> Model Class Initialized
DEBUG - 2011-10-17 06:49:30 --> Model Class Initialized
DEBUG - 2011-10-17 06:49:30 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-17 06:49:30 --> Database Driver Class Initialized
DEBUG - 2011-10-17 06:49:30 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-17 06:49:30 --> Helper loaded: url_helper
DEBUG - 2011-10-17 06:49:30 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-17 06:49:30 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-17 06:49:30 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-17 06:49:30 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-17 06:49:30 --> Final output sent to browser
DEBUG - 2011-10-17 06:49:30 --> Total execution time: 0.0678
DEBUG - 2011-10-17 06:49:39 --> Config Class Initialized
DEBUG - 2011-10-17 06:49:39 --> Hooks Class Initialized
DEBUG - 2011-10-17 06:49:39 --> Utf8 Class Initialized
DEBUG - 2011-10-17 06:49:39 --> UTF-8 Support Enabled
DEBUG - 2011-10-17 06:49:39 --> URI Class Initialized
DEBUG - 2011-10-17 06:49:39 --> Router Class Initialized
DEBUG - 2011-10-17 06:49:39 --> Output Class Initialized
DEBUG - 2011-10-17 06:49:39 --> Input Class Initialized
DEBUG - 2011-10-17 06:49:39 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-17 06:49:39 --> Language Class Initialized
DEBUG - 2011-10-17 06:49:39 --> Loader Class Initialized
DEBUG - 2011-10-17 06:49:39 --> Controller Class Initialized
DEBUG - 2011-10-17 06:49:39 --> Model Class Initialized
DEBUG - 2011-10-17 06:49:39 --> Model Class Initialized
DEBUG - 2011-10-17 06:49:39 --> Model Class Initialized
DEBUG - 2011-10-17 06:49:39 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-17 06:49:39 --> Database Driver Class Initialized
DEBUG - 2011-10-17 06:49:39 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-17 06:49:39 --> Helper loaded: url_helper
DEBUG - 2011-10-17 06:49:39 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-17 06:49:39 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-17 06:49:39 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-17 06:49:39 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-17 06:49:39 --> Final output sent to browser
DEBUG - 2011-10-17 06:49:39 --> Total execution time: 0.2888
DEBUG - 2011-10-17 06:49:53 --> Config Class Initialized
DEBUG - 2011-10-17 06:49:53 --> Hooks Class Initialized
DEBUG - 2011-10-17 06:49:53 --> Utf8 Class Initialized
DEBUG - 2011-10-17 06:49:53 --> UTF-8 Support Enabled
DEBUG - 2011-10-17 06:49:53 --> URI Class Initialized
DEBUG - 2011-10-17 06:49:53 --> Router Class Initialized
DEBUG - 2011-10-17 06:49:53 --> Output Class Initialized
DEBUG - 2011-10-17 06:49:53 --> Input Class Initialized
DEBUG - 2011-10-17 06:49:53 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-17 06:49:53 --> Language Class Initialized
DEBUG - 2011-10-17 06:49:53 --> Loader Class Initialized
DEBUG - 2011-10-17 06:49:53 --> Controller Class Initialized
DEBUG - 2011-10-17 06:49:53 --> Model Class Initialized
DEBUG - 2011-10-17 06:49:53 --> Model Class Initialized
DEBUG - 2011-10-17 06:49:53 --> Model Class Initialized
DEBUG - 2011-10-17 06:49:53 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-17 06:49:53 --> Database Driver Class Initialized
DEBUG - 2011-10-17 06:49:53 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-17 06:49:53 --> Helper loaded: url_helper
DEBUG - 2011-10-17 06:49:53 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-17 06:49:53 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-17 06:49:53 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-17 06:49:53 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-17 06:49:53 --> Final output sent to browser
DEBUG - 2011-10-17 06:49:53 --> Total execution time: 0.1944
DEBUG - 2011-10-17 06:49:58 --> Config Class Initialized
DEBUG - 2011-10-17 06:49:58 --> Hooks Class Initialized
DEBUG - 2011-10-17 06:49:58 --> Utf8 Class Initialized
DEBUG - 2011-10-17 06:49:58 --> UTF-8 Support Enabled
DEBUG - 2011-10-17 06:49:58 --> URI Class Initialized
DEBUG - 2011-10-17 06:49:58 --> Router Class Initialized
DEBUG - 2011-10-17 06:49:58 --> Output Class Initialized
DEBUG - 2011-10-17 06:49:58 --> Input Class Initialized
DEBUG - 2011-10-17 06:49:58 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-17 06:49:58 --> Language Class Initialized
DEBUG - 2011-10-17 06:49:58 --> Loader Class Initialized
DEBUG - 2011-10-17 06:49:58 --> Controller Class Initialized
DEBUG - 2011-10-17 06:49:58 --> Model Class Initialized
DEBUG - 2011-10-17 06:49:58 --> Model Class Initialized
DEBUG - 2011-10-17 06:49:58 --> Model Class Initialized
DEBUG - 2011-10-17 06:49:58 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-17 06:49:58 --> Database Driver Class Initialized
DEBUG - 2011-10-17 06:49:58 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-17 06:49:58 --> Helper loaded: url_helper
DEBUG - 2011-10-17 06:49:58 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-17 06:49:58 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-17 06:49:58 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-17 06:49:58 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-17 06:49:58 --> Final output sent to browser
DEBUG - 2011-10-17 06:49:58 --> Total execution time: 0.0718
DEBUG - 2011-10-17 06:50:02 --> Config Class Initialized
DEBUG - 2011-10-17 06:50:02 --> Hooks Class Initialized
DEBUG - 2011-10-17 06:50:02 --> Utf8 Class Initialized
DEBUG - 2011-10-17 06:50:02 --> UTF-8 Support Enabled
DEBUG - 2011-10-17 06:50:02 --> URI Class Initialized
DEBUG - 2011-10-17 06:50:02 --> Router Class Initialized
DEBUG - 2011-10-17 06:50:02 --> Output Class Initialized
DEBUG - 2011-10-17 06:50:02 --> Input Class Initialized
DEBUG - 2011-10-17 06:50:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-17 06:50:02 --> Language Class Initialized
DEBUG - 2011-10-17 06:50:02 --> Loader Class Initialized
DEBUG - 2011-10-17 06:50:02 --> Controller Class Initialized
DEBUG - 2011-10-17 06:50:02 --> Model Class Initialized
DEBUG - 2011-10-17 06:50:02 --> Model Class Initialized
DEBUG - 2011-10-17 06:50:02 --> Model Class Initialized
DEBUG - 2011-10-17 06:50:02 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-17 06:50:02 --> Database Driver Class Initialized
DEBUG - 2011-10-17 06:50:03 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-17 06:50:03 --> Helper loaded: url_helper
DEBUG - 2011-10-17 06:50:03 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-17 06:50:03 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-17 06:50:03 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-17 06:50:03 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-17 06:50:03 --> Final output sent to browser
DEBUG - 2011-10-17 06:50:03 --> Total execution time: 0.5223
DEBUG - 2011-10-17 06:50:12 --> Config Class Initialized
DEBUG - 2011-10-17 06:50:12 --> Hooks Class Initialized
DEBUG - 2011-10-17 06:50:12 --> Utf8 Class Initialized
DEBUG - 2011-10-17 06:50:12 --> UTF-8 Support Enabled
DEBUG - 2011-10-17 06:50:12 --> URI Class Initialized
DEBUG - 2011-10-17 06:50:12 --> Router Class Initialized
DEBUG - 2011-10-17 06:50:12 --> Output Class Initialized
DEBUG - 2011-10-17 06:50:12 --> Input Class Initialized
DEBUG - 2011-10-17 06:50:12 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-17 06:50:12 --> Language Class Initialized
DEBUG - 2011-10-17 06:50:12 --> Loader Class Initialized
DEBUG - 2011-10-17 06:50:12 --> Controller Class Initialized
DEBUG - 2011-10-17 06:50:12 --> Model Class Initialized
DEBUG - 2011-10-17 06:50:12 --> Model Class Initialized
DEBUG - 2011-10-17 06:50:12 --> Model Class Initialized
DEBUG - 2011-10-17 06:50:12 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-17 06:50:12 --> Database Driver Class Initialized
DEBUG - 2011-10-17 06:50:12 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-17 06:50:12 --> Helper loaded: url_helper
DEBUG - 2011-10-17 06:50:12 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-17 06:50:12 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-17 06:50:12 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-17 06:50:12 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-17 06:50:12 --> Final output sent to browser
DEBUG - 2011-10-17 06:50:12 --> Total execution time: 0.0697
DEBUG - 2011-10-17 06:50:23 --> Config Class Initialized
DEBUG - 2011-10-17 06:50:23 --> Hooks Class Initialized
DEBUG - 2011-10-17 06:50:23 --> Utf8 Class Initialized
DEBUG - 2011-10-17 06:50:23 --> UTF-8 Support Enabled
DEBUG - 2011-10-17 06:50:23 --> URI Class Initialized
DEBUG - 2011-10-17 06:50:23 --> Router Class Initialized
DEBUG - 2011-10-17 06:50:23 --> Output Class Initialized
DEBUG - 2011-10-17 06:50:23 --> Input Class Initialized
DEBUG - 2011-10-17 06:50:23 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-17 06:50:23 --> Language Class Initialized
DEBUG - 2011-10-17 06:50:23 --> Loader Class Initialized
DEBUG - 2011-10-17 06:50:23 --> Controller Class Initialized
DEBUG - 2011-10-17 06:50:23 --> Model Class Initialized
DEBUG - 2011-10-17 06:50:23 --> Model Class Initialized
DEBUG - 2011-10-17 06:50:23 --> Model Class Initialized
DEBUG - 2011-10-17 06:50:23 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-17 06:50:23 --> Database Driver Class Initialized
DEBUG - 2011-10-17 06:50:23 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-17 06:50:23 --> Helper loaded: url_helper
DEBUG - 2011-10-17 06:50:23 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-17 06:50:23 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-17 06:50:23 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-17 06:50:23 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-17 06:50:23 --> Final output sent to browser
DEBUG - 2011-10-17 06:50:23 --> Total execution time: 0.0688
DEBUG - 2011-10-17 07:17:41 --> Config Class Initialized
DEBUG - 2011-10-17 07:17:41 --> Hooks Class Initialized
DEBUG - 2011-10-17 07:17:41 --> Utf8 Class Initialized
DEBUG - 2011-10-17 07:17:41 --> UTF-8 Support Enabled
DEBUG - 2011-10-17 07:17:41 --> URI Class Initialized
DEBUG - 2011-10-17 07:17:41 --> Router Class Initialized
DEBUG - 2011-10-17 07:17:41 --> Output Class Initialized
DEBUG - 2011-10-17 07:17:41 --> Input Class Initialized
DEBUG - 2011-10-17 07:17:41 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-17 07:17:41 --> Language Class Initialized
DEBUG - 2011-10-17 07:17:41 --> Loader Class Initialized
DEBUG - 2011-10-17 07:17:42 --> Controller Class Initialized
ERROR - 2011-10-17 07:17:42 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-10-17 07:17:42 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-10-17 07:17:42 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-17 07:17:42 --> Model Class Initialized
DEBUG - 2011-10-17 07:17:42 --> Model Class Initialized
DEBUG - 2011-10-17 07:17:42 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-17 07:17:42 --> Database Driver Class Initialized
DEBUG - 2011-10-17 07:17:42 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-17 07:17:42 --> Helper loaded: url_helper
DEBUG - 2011-10-17 07:17:42 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-17 07:17:42 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-17 07:17:42 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-17 07:17:42 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-17 07:17:42 --> Final output sent to browser
DEBUG - 2011-10-17 07:17:42 --> Total execution time: 0.6112
DEBUG - 2011-10-17 07:17:43 --> Config Class Initialized
DEBUG - 2011-10-17 07:17:43 --> Hooks Class Initialized
DEBUG - 2011-10-17 07:17:43 --> Utf8 Class Initialized
DEBUG - 2011-10-17 07:17:43 --> UTF-8 Support Enabled
DEBUG - 2011-10-17 07:17:43 --> URI Class Initialized
DEBUG - 2011-10-17 07:17:43 --> Router Class Initialized
DEBUG - 2011-10-17 07:17:43 --> Output Class Initialized
DEBUG - 2011-10-17 07:17:43 --> Input Class Initialized
DEBUG - 2011-10-17 07:17:43 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-17 07:17:43 --> Language Class Initialized
DEBUG - 2011-10-17 07:17:43 --> Loader Class Initialized
DEBUG - 2011-10-17 07:17:43 --> Controller Class Initialized
DEBUG - 2011-10-17 07:17:43 --> Model Class Initialized
DEBUG - 2011-10-17 07:17:43 --> Model Class Initialized
DEBUG - 2011-10-17 07:17:43 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-17 07:17:43 --> Database Driver Class Initialized
DEBUG - 2011-10-17 07:17:43 --> Final output sent to browser
DEBUG - 2011-10-17 07:17:43 --> Total execution time: 0.6677
DEBUG - 2011-10-17 07:17:45 --> Config Class Initialized
DEBUG - 2011-10-17 07:17:45 --> Hooks Class Initialized
DEBUG - 2011-10-17 07:17:45 --> Utf8 Class Initialized
DEBUG - 2011-10-17 07:17:45 --> UTF-8 Support Enabled
DEBUG - 2011-10-17 07:17:45 --> URI Class Initialized
DEBUG - 2011-10-17 07:17:45 --> Router Class Initialized
ERROR - 2011-10-17 07:17:45 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-17 07:17:46 --> Config Class Initialized
DEBUG - 2011-10-17 07:17:46 --> Hooks Class Initialized
DEBUG - 2011-10-17 07:17:46 --> Utf8 Class Initialized
DEBUG - 2011-10-17 07:17:46 --> UTF-8 Support Enabled
DEBUG - 2011-10-17 07:17:46 --> URI Class Initialized
DEBUG - 2011-10-17 07:17:46 --> Router Class Initialized
ERROR - 2011-10-17 07:17:46 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-17 07:19:10 --> Config Class Initialized
DEBUG - 2011-10-17 07:19:10 --> Hooks Class Initialized
DEBUG - 2011-10-17 07:19:10 --> Utf8 Class Initialized
DEBUG - 2011-10-17 07:19:10 --> UTF-8 Support Enabled
DEBUG - 2011-10-17 07:19:10 --> URI Class Initialized
DEBUG - 2011-10-17 07:19:10 --> Router Class Initialized
DEBUG - 2011-10-17 07:19:10 --> Output Class Initialized
DEBUG - 2011-10-17 07:19:10 --> Input Class Initialized
DEBUG - 2011-10-17 07:19:10 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-17 07:19:10 --> Language Class Initialized
DEBUG - 2011-10-17 07:19:10 --> Loader Class Initialized
DEBUG - 2011-10-17 07:19:10 --> Controller Class Initialized
ERROR - 2011-10-17 07:19:10 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-10-17 07:19:10 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-10-17 07:19:10 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-17 07:19:10 --> Model Class Initialized
DEBUG - 2011-10-17 07:19:10 --> Model Class Initialized
DEBUG - 2011-10-17 07:19:10 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-17 07:19:10 --> Database Driver Class Initialized
DEBUG - 2011-10-17 07:19:10 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-17 07:19:10 --> Helper loaded: url_helper
DEBUG - 2011-10-17 07:19:10 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-17 07:19:10 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-17 07:19:10 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-17 07:19:10 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-17 07:19:10 --> Final output sent to browser
DEBUG - 2011-10-17 07:19:10 --> Total execution time: 0.0664
DEBUG - 2011-10-17 07:19:11 --> Config Class Initialized
DEBUG - 2011-10-17 07:19:11 --> Hooks Class Initialized
DEBUG - 2011-10-17 07:19:11 --> Utf8 Class Initialized
DEBUG - 2011-10-17 07:19:11 --> UTF-8 Support Enabled
DEBUG - 2011-10-17 07:19:11 --> URI Class Initialized
DEBUG - 2011-10-17 07:19:11 --> Router Class Initialized
DEBUG - 2011-10-17 07:19:11 --> Output Class Initialized
DEBUG - 2011-10-17 07:19:11 --> Input Class Initialized
DEBUG - 2011-10-17 07:19:11 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-17 07:19:11 --> Language Class Initialized
DEBUG - 2011-10-17 07:19:11 --> Loader Class Initialized
DEBUG - 2011-10-17 07:19:11 --> Controller Class Initialized
DEBUG - 2011-10-17 07:19:11 --> Model Class Initialized
DEBUG - 2011-10-17 07:19:11 --> Model Class Initialized
DEBUG - 2011-10-17 07:19:11 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-17 07:19:11 --> Database Driver Class Initialized
DEBUG - 2011-10-17 07:19:12 --> Final output sent to browser
DEBUG - 2011-10-17 07:19:12 --> Total execution time: 0.4600
DEBUG - 2011-10-17 07:19:28 --> Config Class Initialized
DEBUG - 2011-10-17 07:19:28 --> Hooks Class Initialized
DEBUG - 2011-10-17 07:19:28 --> Utf8 Class Initialized
DEBUG - 2011-10-17 07:19:28 --> UTF-8 Support Enabled
DEBUG - 2011-10-17 07:19:28 --> URI Class Initialized
DEBUG - 2011-10-17 07:19:28 --> Router Class Initialized
ERROR - 2011-10-17 07:19:28 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-10-17 07:19:28 --> Config Class Initialized
DEBUG - 2011-10-17 07:19:28 --> Hooks Class Initialized
DEBUG - 2011-10-17 07:19:28 --> Utf8 Class Initialized
DEBUG - 2011-10-17 07:19:28 --> UTF-8 Support Enabled
DEBUG - 2011-10-17 07:19:28 --> URI Class Initialized
DEBUG - 2011-10-17 07:19:28 --> Router Class Initialized
DEBUG - 2011-10-17 07:19:28 --> Output Class Initialized
DEBUG - 2011-10-17 07:19:28 --> Input Class Initialized
DEBUG - 2011-10-17 07:19:28 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-17 07:19:28 --> Language Class Initialized
DEBUG - 2011-10-17 07:19:28 --> Loader Class Initialized
DEBUG - 2011-10-17 07:19:28 --> Controller Class Initialized
DEBUG - 2011-10-17 07:19:28 --> Model Class Initialized
DEBUG - 2011-10-17 07:19:28 --> Model Class Initialized
DEBUG - 2011-10-17 07:19:28 --> Model Class Initialized
DEBUG - 2011-10-17 07:19:28 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-17 07:19:28 --> Database Driver Class Initialized
DEBUG - 2011-10-17 07:19:28 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-17 07:19:28 --> Helper loaded: url_helper
DEBUG - 2011-10-17 07:19:28 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-17 07:19:28 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-17 07:19:28 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-17 07:19:28 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-17 07:19:28 --> Final output sent to browser
DEBUG - 2011-10-17 07:19:28 --> Total execution time: 0.2837
DEBUG - 2011-10-17 07:19:38 --> Config Class Initialized
DEBUG - 2011-10-17 07:19:38 --> Hooks Class Initialized
DEBUG - 2011-10-17 07:19:38 --> Utf8 Class Initialized
DEBUG - 2011-10-17 07:19:38 --> UTF-8 Support Enabled
DEBUG - 2011-10-17 07:19:38 --> URI Class Initialized
DEBUG - 2011-10-17 07:19:38 --> Router Class Initialized
DEBUG - 2011-10-17 07:19:38 --> Output Class Initialized
DEBUG - 2011-10-17 07:19:38 --> Input Class Initialized
DEBUG - 2011-10-17 07:19:38 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-17 07:19:38 --> Language Class Initialized
DEBUG - 2011-10-17 07:19:38 --> Loader Class Initialized
DEBUG - 2011-10-17 07:19:38 --> Controller Class Initialized
DEBUG - 2011-10-17 07:19:38 --> Model Class Initialized
DEBUG - 2011-10-17 07:19:38 --> Model Class Initialized
DEBUG - 2011-10-17 07:19:38 --> Model Class Initialized
DEBUG - 2011-10-17 07:19:38 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-17 07:19:38 --> Database Driver Class Initialized
DEBUG - 2011-10-17 07:19:38 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-17 07:19:38 --> Helper loaded: url_helper
DEBUG - 2011-10-17 07:19:38 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-17 07:19:38 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-17 07:19:38 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-17 07:19:38 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-17 07:19:38 --> Final output sent to browser
DEBUG - 2011-10-17 07:19:38 --> Total execution time: 0.0517
DEBUG - 2011-10-17 07:19:42 --> Config Class Initialized
DEBUG - 2011-10-17 07:19:42 --> Hooks Class Initialized
DEBUG - 2011-10-17 07:19:42 --> Utf8 Class Initialized
DEBUG - 2011-10-17 07:19:42 --> UTF-8 Support Enabled
DEBUG - 2011-10-17 07:19:42 --> URI Class Initialized
DEBUG - 2011-10-17 07:19:42 --> Router Class Initialized
ERROR - 2011-10-17 07:19:42 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-17 07:19:43 --> Config Class Initialized
DEBUG - 2011-10-17 07:19:43 --> Hooks Class Initialized
DEBUG - 2011-10-17 07:19:43 --> Utf8 Class Initialized
DEBUG - 2011-10-17 07:19:43 --> UTF-8 Support Enabled
DEBUG - 2011-10-17 07:19:43 --> URI Class Initialized
DEBUG - 2011-10-17 07:19:43 --> Router Class Initialized
ERROR - 2011-10-17 07:19:43 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-17 07:23:49 --> Config Class Initialized
DEBUG - 2011-10-17 07:23:49 --> Hooks Class Initialized
DEBUG - 2011-10-17 07:23:49 --> Utf8 Class Initialized
DEBUG - 2011-10-17 07:23:49 --> UTF-8 Support Enabled
DEBUG - 2011-10-17 07:23:49 --> URI Class Initialized
DEBUG - 2011-10-17 07:23:49 --> Router Class Initialized
DEBUG - 2011-10-17 07:23:49 --> Output Class Initialized
DEBUG - 2011-10-17 07:23:49 --> Input Class Initialized
DEBUG - 2011-10-17 07:23:49 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-17 07:23:49 --> Language Class Initialized
DEBUG - 2011-10-17 07:23:49 --> Loader Class Initialized
DEBUG - 2011-10-17 07:23:49 --> Controller Class Initialized
DEBUG - 2011-10-17 07:23:49 --> Model Class Initialized
DEBUG - 2011-10-17 07:23:49 --> Model Class Initialized
DEBUG - 2011-10-17 07:23:49 --> Model Class Initialized
DEBUG - 2011-10-17 07:23:49 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-17 07:23:49 --> Database Driver Class Initialized
DEBUG - 2011-10-17 07:23:49 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-17 07:23:49 --> Helper loaded: url_helper
DEBUG - 2011-10-17 07:23:49 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-17 07:23:49 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-17 07:23:49 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-17 07:23:49 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-17 07:23:49 --> Final output sent to browser
DEBUG - 2011-10-17 07:23:49 --> Total execution time: 0.0512
DEBUG - 2011-10-17 07:23:53 --> Config Class Initialized
DEBUG - 2011-10-17 07:23:53 --> Hooks Class Initialized
DEBUG - 2011-10-17 07:23:53 --> Utf8 Class Initialized
DEBUG - 2011-10-17 07:23:53 --> UTF-8 Support Enabled
DEBUG - 2011-10-17 07:23:53 --> URI Class Initialized
DEBUG - 2011-10-17 07:23:53 --> Router Class Initialized
DEBUG - 2011-10-17 07:23:53 --> Output Class Initialized
DEBUG - 2011-10-17 07:23:53 --> Input Class Initialized
DEBUG - 2011-10-17 07:23:53 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-17 07:23:53 --> Language Class Initialized
DEBUG - 2011-10-17 07:23:53 --> Loader Class Initialized
DEBUG - 2011-10-17 07:23:53 --> Controller Class Initialized
DEBUG - 2011-10-17 07:23:53 --> Model Class Initialized
DEBUG - 2011-10-17 07:23:53 --> Model Class Initialized
DEBUG - 2011-10-17 07:23:53 --> Model Class Initialized
DEBUG - 2011-10-17 07:23:53 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-17 07:23:53 --> Database Driver Class Initialized
DEBUG - 2011-10-17 07:23:53 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-17 07:23:53 --> Helper loaded: url_helper
DEBUG - 2011-10-17 07:23:53 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-17 07:23:53 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-17 07:23:53 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-17 07:23:53 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-17 07:23:53 --> Final output sent to browser
DEBUG - 2011-10-17 07:23:53 --> Total execution time: 0.0769
DEBUG - 2011-10-17 07:24:14 --> Config Class Initialized
DEBUG - 2011-10-17 07:24:14 --> Hooks Class Initialized
DEBUG - 2011-10-17 07:24:14 --> Utf8 Class Initialized
DEBUG - 2011-10-17 07:24:14 --> UTF-8 Support Enabled
DEBUG - 2011-10-17 07:24:14 --> URI Class Initialized
DEBUG - 2011-10-17 07:24:14 --> Router Class Initialized
DEBUG - 2011-10-17 07:24:14 --> Output Class Initialized
DEBUG - 2011-10-17 07:24:14 --> Input Class Initialized
DEBUG - 2011-10-17 07:24:14 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-17 07:24:14 --> Language Class Initialized
DEBUG - 2011-10-17 07:24:14 --> Loader Class Initialized
DEBUG - 2011-10-17 07:24:14 --> Controller Class Initialized
ERROR - 2011-10-17 07:24:14 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-10-17 07:24:14 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-10-17 07:24:14 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-17 07:24:14 --> Model Class Initialized
DEBUG - 2011-10-17 07:24:14 --> Model Class Initialized
DEBUG - 2011-10-17 07:24:14 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-17 07:24:14 --> Database Driver Class Initialized
DEBUG - 2011-10-17 07:24:14 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-17 07:24:14 --> Helper loaded: url_helper
DEBUG - 2011-10-17 07:24:14 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-17 07:24:14 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-17 07:24:14 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-17 07:24:14 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-17 07:24:14 --> Final output sent to browser
DEBUG - 2011-10-17 07:24:14 --> Total execution time: 0.0262
DEBUG - 2011-10-17 07:24:17 --> Config Class Initialized
DEBUG - 2011-10-17 07:24:17 --> Hooks Class Initialized
DEBUG - 2011-10-17 07:24:17 --> Utf8 Class Initialized
DEBUG - 2011-10-17 07:24:17 --> UTF-8 Support Enabled
DEBUG - 2011-10-17 07:24:17 --> URI Class Initialized
DEBUG - 2011-10-17 07:24:17 --> Router Class Initialized
DEBUG - 2011-10-17 07:24:17 --> Output Class Initialized
DEBUG - 2011-10-17 07:24:17 --> Input Class Initialized
DEBUG - 2011-10-17 07:24:17 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-17 07:24:17 --> Language Class Initialized
DEBUG - 2011-10-17 07:24:17 --> Loader Class Initialized
DEBUG - 2011-10-17 07:24:17 --> Controller Class Initialized
DEBUG - 2011-10-17 07:24:17 --> Model Class Initialized
DEBUG - 2011-10-17 07:24:17 --> Model Class Initialized
DEBUG - 2011-10-17 07:24:17 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-17 07:24:17 --> Database Driver Class Initialized
DEBUG - 2011-10-17 07:24:17 --> Final output sent to browser
DEBUG - 2011-10-17 07:24:17 --> Total execution time: 0.4565
DEBUG - 2011-10-17 07:24:19 --> Config Class Initialized
DEBUG - 2011-10-17 07:24:19 --> Hooks Class Initialized
DEBUG - 2011-10-17 07:24:19 --> Utf8 Class Initialized
DEBUG - 2011-10-17 07:24:19 --> UTF-8 Support Enabled
DEBUG - 2011-10-17 07:24:19 --> URI Class Initialized
DEBUG - 2011-10-17 07:24:19 --> Router Class Initialized
ERROR - 2011-10-17 07:24:19 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-17 07:25:28 --> Config Class Initialized
DEBUG - 2011-10-17 07:25:28 --> Hooks Class Initialized
DEBUG - 2011-10-17 07:25:28 --> Utf8 Class Initialized
DEBUG - 2011-10-17 07:25:28 --> UTF-8 Support Enabled
DEBUG - 2011-10-17 07:25:28 --> URI Class Initialized
DEBUG - 2011-10-17 07:25:28 --> Router Class Initialized
DEBUG - 2011-10-17 07:25:28 --> Output Class Initialized
DEBUG - 2011-10-17 07:25:28 --> Input Class Initialized
DEBUG - 2011-10-17 07:25:28 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-17 07:25:28 --> Language Class Initialized
DEBUG - 2011-10-17 07:25:28 --> Loader Class Initialized
DEBUG - 2011-10-17 07:25:28 --> Controller Class Initialized
ERROR - 2011-10-17 07:25:28 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-10-17 07:25:28 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-10-17 07:25:28 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-17 07:25:28 --> Model Class Initialized
DEBUG - 2011-10-17 07:25:28 --> Model Class Initialized
DEBUG - 2011-10-17 07:25:28 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-17 07:25:28 --> Database Driver Class Initialized
DEBUG - 2011-10-17 07:25:28 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-17 07:25:28 --> Helper loaded: url_helper
DEBUG - 2011-10-17 07:25:28 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-17 07:25:28 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-17 07:25:28 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-17 07:25:28 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-17 07:25:28 --> Final output sent to browser
DEBUG - 2011-10-17 07:25:28 --> Total execution time: 0.0319
DEBUG - 2011-10-17 07:25:29 --> Config Class Initialized
DEBUG - 2011-10-17 07:25:29 --> Hooks Class Initialized
DEBUG - 2011-10-17 07:25:29 --> Utf8 Class Initialized
DEBUG - 2011-10-17 07:25:29 --> UTF-8 Support Enabled
DEBUG - 2011-10-17 07:25:29 --> URI Class Initialized
DEBUG - 2011-10-17 07:25:29 --> Router Class Initialized
DEBUG - 2011-10-17 07:25:29 --> Output Class Initialized
DEBUG - 2011-10-17 07:25:29 --> Input Class Initialized
DEBUG - 2011-10-17 07:25:29 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-17 07:25:29 --> Language Class Initialized
DEBUG - 2011-10-17 07:25:29 --> Loader Class Initialized
DEBUG - 2011-10-17 07:25:29 --> Controller Class Initialized
DEBUG - 2011-10-17 07:25:29 --> Model Class Initialized
DEBUG - 2011-10-17 07:25:29 --> Model Class Initialized
DEBUG - 2011-10-17 07:25:29 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-17 07:25:29 --> Database Driver Class Initialized
DEBUG - 2011-10-17 07:25:29 --> Final output sent to browser
DEBUG - 2011-10-17 07:25:29 --> Total execution time: 0.5915
DEBUG - 2011-10-17 07:25:31 --> Config Class Initialized
DEBUG - 2011-10-17 07:25:31 --> Hooks Class Initialized
DEBUG - 2011-10-17 07:25:31 --> Utf8 Class Initialized
DEBUG - 2011-10-17 07:25:31 --> UTF-8 Support Enabled
DEBUG - 2011-10-17 07:25:31 --> URI Class Initialized
DEBUG - 2011-10-17 07:25:31 --> Router Class Initialized
ERROR - 2011-10-17 07:25:31 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-17 07:26:24 --> Config Class Initialized
DEBUG - 2011-10-17 07:26:24 --> Hooks Class Initialized
DEBUG - 2011-10-17 07:26:24 --> Utf8 Class Initialized
DEBUG - 2011-10-17 07:26:24 --> UTF-8 Support Enabled
DEBUG - 2011-10-17 07:26:24 --> URI Class Initialized
DEBUG - 2011-10-17 07:26:24 --> Router Class Initialized
DEBUG - 2011-10-17 07:26:24 --> Output Class Initialized
DEBUG - 2011-10-17 07:26:24 --> Input Class Initialized
DEBUG - 2011-10-17 07:26:24 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-17 07:26:24 --> Language Class Initialized
DEBUG - 2011-10-17 07:26:24 --> Loader Class Initialized
DEBUG - 2011-10-17 07:26:24 --> Controller Class Initialized
ERROR - 2011-10-17 07:26:24 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-10-17 07:26:24 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-10-17 07:26:24 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-17 07:26:24 --> Model Class Initialized
DEBUG - 2011-10-17 07:26:24 --> Model Class Initialized
DEBUG - 2011-10-17 07:26:24 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-17 07:26:24 --> Database Driver Class Initialized
DEBUG - 2011-10-17 07:26:24 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-17 07:26:24 --> Helper loaded: url_helper
DEBUG - 2011-10-17 07:26:24 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-17 07:26:24 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-17 07:26:24 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-17 07:26:24 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-17 07:26:24 --> Final output sent to browser
DEBUG - 2011-10-17 07:26:24 --> Total execution time: 0.0727
DEBUG - 2011-10-17 07:26:26 --> Config Class Initialized
DEBUG - 2011-10-17 07:26:26 --> Hooks Class Initialized
DEBUG - 2011-10-17 07:26:26 --> Utf8 Class Initialized
DEBUG - 2011-10-17 07:26:26 --> UTF-8 Support Enabled
DEBUG - 2011-10-17 07:26:26 --> URI Class Initialized
DEBUG - 2011-10-17 07:26:26 --> Router Class Initialized
DEBUG - 2011-10-17 07:26:26 --> Output Class Initialized
DEBUG - 2011-10-17 07:26:26 --> Input Class Initialized
DEBUG - 2011-10-17 07:26:26 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-17 07:26:26 --> Language Class Initialized
DEBUG - 2011-10-17 07:26:26 --> Loader Class Initialized
DEBUG - 2011-10-17 07:26:26 --> Controller Class Initialized
DEBUG - 2011-10-17 07:26:26 --> Model Class Initialized
DEBUG - 2011-10-17 07:26:26 --> Model Class Initialized
DEBUG - 2011-10-17 07:26:26 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-17 07:26:26 --> Database Driver Class Initialized
DEBUG - 2011-10-17 07:26:27 --> Final output sent to browser
DEBUG - 2011-10-17 07:26:27 --> Total execution time: 0.6468
DEBUG - 2011-10-17 07:26:28 --> Config Class Initialized
DEBUG - 2011-10-17 07:26:28 --> Hooks Class Initialized
DEBUG - 2011-10-17 07:26:28 --> Utf8 Class Initialized
DEBUG - 2011-10-17 07:26:28 --> UTF-8 Support Enabled
DEBUG - 2011-10-17 07:26:28 --> URI Class Initialized
DEBUG - 2011-10-17 07:26:28 --> Router Class Initialized
ERROR - 2011-10-17 07:26:28 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-17 07:29:36 --> Config Class Initialized
DEBUG - 2011-10-17 07:29:36 --> Hooks Class Initialized
DEBUG - 2011-10-17 07:29:36 --> Utf8 Class Initialized
DEBUG - 2011-10-17 07:29:36 --> UTF-8 Support Enabled
DEBUG - 2011-10-17 07:29:36 --> URI Class Initialized
DEBUG - 2011-10-17 07:29:36 --> Router Class Initialized
ERROR - 2011-10-17 07:29:36 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-17 07:29:43 --> Config Class Initialized
DEBUG - 2011-10-17 07:29:43 --> Hooks Class Initialized
DEBUG - 2011-10-17 07:29:43 --> Utf8 Class Initialized
DEBUG - 2011-10-17 07:29:43 --> UTF-8 Support Enabled
DEBUG - 2011-10-17 07:29:43 --> URI Class Initialized
DEBUG - 2011-10-17 07:29:43 --> Router Class Initialized
DEBUG - 2011-10-17 07:29:43 --> Output Class Initialized
DEBUG - 2011-10-17 07:29:43 --> Input Class Initialized
DEBUG - 2011-10-17 07:29:43 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-17 07:29:43 --> Language Class Initialized
DEBUG - 2011-10-17 07:29:43 --> Loader Class Initialized
DEBUG - 2011-10-17 07:29:43 --> Controller Class Initialized
ERROR - 2011-10-17 07:29:43 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-10-17 07:29:43 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-10-17 07:29:43 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-17 07:29:43 --> Model Class Initialized
DEBUG - 2011-10-17 07:29:43 --> Model Class Initialized
DEBUG - 2011-10-17 07:29:43 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-17 07:29:43 --> Database Driver Class Initialized
DEBUG - 2011-10-17 07:29:43 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-17 07:29:43 --> Helper loaded: url_helper
DEBUG - 2011-10-17 07:29:43 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-17 07:29:43 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-17 07:29:43 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-17 07:29:43 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-17 07:29:43 --> Final output sent to browser
DEBUG - 2011-10-17 07:29:43 --> Total execution time: 0.1303
DEBUG - 2011-10-17 07:29:45 --> Config Class Initialized
DEBUG - 2011-10-17 07:29:45 --> Hooks Class Initialized
DEBUG - 2011-10-17 07:29:45 --> Utf8 Class Initialized
DEBUG - 2011-10-17 07:29:45 --> UTF-8 Support Enabled
DEBUG - 2011-10-17 07:29:45 --> URI Class Initialized
DEBUG - 2011-10-17 07:29:45 --> Router Class Initialized
DEBUG - 2011-10-17 07:29:45 --> Output Class Initialized
DEBUG - 2011-10-17 07:29:45 --> Input Class Initialized
DEBUG - 2011-10-17 07:29:45 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-17 07:29:45 --> Language Class Initialized
DEBUG - 2011-10-17 07:29:45 --> Loader Class Initialized
DEBUG - 2011-10-17 07:29:45 --> Controller Class Initialized
DEBUG - 2011-10-17 07:29:45 --> Model Class Initialized
DEBUG - 2011-10-17 07:29:45 --> Model Class Initialized
DEBUG - 2011-10-17 07:29:45 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-17 07:29:45 --> Database Driver Class Initialized
DEBUG - 2011-10-17 07:29:45 --> Final output sent to browser
DEBUG - 2011-10-17 07:29:45 --> Total execution time: 0.6833
DEBUG - 2011-10-17 07:29:47 --> Config Class Initialized
DEBUG - 2011-10-17 07:29:47 --> Hooks Class Initialized
DEBUG - 2011-10-17 07:29:47 --> Utf8 Class Initialized
DEBUG - 2011-10-17 07:29:47 --> UTF-8 Support Enabled
DEBUG - 2011-10-17 07:29:47 --> URI Class Initialized
DEBUG - 2011-10-17 07:29:47 --> Router Class Initialized
ERROR - 2011-10-17 07:29:47 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-17 07:30:07 --> Config Class Initialized
DEBUG - 2011-10-17 07:30:07 --> Hooks Class Initialized
DEBUG - 2011-10-17 07:30:07 --> Utf8 Class Initialized
DEBUG - 2011-10-17 07:30:07 --> UTF-8 Support Enabled
DEBUG - 2011-10-17 07:30:07 --> URI Class Initialized
DEBUG - 2011-10-17 07:30:07 --> Router Class Initialized
DEBUG - 2011-10-17 07:30:07 --> Output Class Initialized
DEBUG - 2011-10-17 07:30:07 --> Input Class Initialized
DEBUG - 2011-10-17 07:30:07 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-17 07:30:07 --> Language Class Initialized
DEBUG - 2011-10-17 07:30:07 --> Loader Class Initialized
DEBUG - 2011-10-17 07:30:07 --> Controller Class Initialized
ERROR - 2011-10-17 07:30:07 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-10-17 07:30:07 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-10-17 07:30:07 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-17 07:30:07 --> Model Class Initialized
DEBUG - 2011-10-17 07:30:07 --> Model Class Initialized
DEBUG - 2011-10-17 07:30:07 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-17 07:30:07 --> Database Driver Class Initialized
DEBUG - 2011-10-17 07:30:07 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-17 07:30:08 --> Helper loaded: url_helper
DEBUG - 2011-10-17 07:30:08 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-17 07:30:08 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-17 07:30:08 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-17 07:30:08 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-17 07:30:08 --> Final output sent to browser
DEBUG - 2011-10-17 07:30:08 --> Total execution time: 0.1215
DEBUG - 2011-10-17 07:30:09 --> Config Class Initialized
DEBUG - 2011-10-17 07:30:09 --> Hooks Class Initialized
DEBUG - 2011-10-17 07:30:09 --> Utf8 Class Initialized
DEBUG - 2011-10-17 07:30:09 --> UTF-8 Support Enabled
DEBUG - 2011-10-17 07:30:09 --> URI Class Initialized
DEBUG - 2011-10-17 07:30:09 --> Router Class Initialized
DEBUG - 2011-10-17 07:30:09 --> Output Class Initialized
DEBUG - 2011-10-17 07:30:09 --> Input Class Initialized
DEBUG - 2011-10-17 07:30:09 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-17 07:30:09 --> Language Class Initialized
DEBUG - 2011-10-17 07:30:09 --> Loader Class Initialized
DEBUG - 2011-10-17 07:30:09 --> Controller Class Initialized
DEBUG - 2011-10-17 07:30:09 --> Model Class Initialized
DEBUG - 2011-10-17 07:30:09 --> Model Class Initialized
DEBUG - 2011-10-17 07:30:09 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-17 07:30:09 --> Database Driver Class Initialized
DEBUG - 2011-10-17 07:30:10 --> Final output sent to browser
DEBUG - 2011-10-17 07:30:10 --> Total execution time: 0.7209
DEBUG - 2011-10-17 07:30:12 --> Config Class Initialized
DEBUG - 2011-10-17 07:30:12 --> Hooks Class Initialized
DEBUG - 2011-10-17 07:30:12 --> Utf8 Class Initialized
DEBUG - 2011-10-17 07:30:12 --> UTF-8 Support Enabled
DEBUG - 2011-10-17 07:30:12 --> URI Class Initialized
DEBUG - 2011-10-17 07:30:12 --> Router Class Initialized
ERROR - 2011-10-17 07:30:12 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-17 07:30:21 --> Config Class Initialized
DEBUG - 2011-10-17 07:30:21 --> Hooks Class Initialized
DEBUG - 2011-10-17 07:30:21 --> Utf8 Class Initialized
DEBUG - 2011-10-17 07:30:21 --> UTF-8 Support Enabled
DEBUG - 2011-10-17 07:30:21 --> URI Class Initialized
DEBUG - 2011-10-17 07:30:21 --> Router Class Initialized
DEBUG - 2011-10-17 07:30:21 --> Output Class Initialized
DEBUG - 2011-10-17 07:30:21 --> Input Class Initialized
DEBUG - 2011-10-17 07:30:21 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-17 07:30:21 --> Language Class Initialized
DEBUG - 2011-10-17 07:30:21 --> Loader Class Initialized
DEBUG - 2011-10-17 07:30:21 --> Controller Class Initialized
ERROR - 2011-10-17 07:30:21 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-10-17 07:30:21 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-10-17 07:30:21 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-17 07:30:21 --> Model Class Initialized
DEBUG - 2011-10-17 07:30:21 --> Model Class Initialized
DEBUG - 2011-10-17 07:30:21 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-17 07:30:21 --> Database Driver Class Initialized
DEBUG - 2011-10-17 07:30:21 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-17 07:30:21 --> Helper loaded: url_helper
DEBUG - 2011-10-17 07:30:21 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-17 07:30:21 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-17 07:30:21 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-17 07:30:21 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-17 07:30:21 --> Final output sent to browser
DEBUG - 2011-10-17 07:30:21 --> Total execution time: 0.0495
DEBUG - 2011-10-17 07:30:22 --> Config Class Initialized
DEBUG - 2011-10-17 07:30:22 --> Hooks Class Initialized
DEBUG - 2011-10-17 07:30:22 --> Utf8 Class Initialized
DEBUG - 2011-10-17 07:30:22 --> UTF-8 Support Enabled
DEBUG - 2011-10-17 07:30:22 --> URI Class Initialized
DEBUG - 2011-10-17 07:30:22 --> Router Class Initialized
DEBUG - 2011-10-17 07:30:22 --> Output Class Initialized
DEBUG - 2011-10-17 07:30:22 --> Input Class Initialized
DEBUG - 2011-10-17 07:30:22 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-17 07:30:22 --> Language Class Initialized
DEBUG - 2011-10-17 07:30:22 --> Loader Class Initialized
DEBUG - 2011-10-17 07:30:22 --> Controller Class Initialized
DEBUG - 2011-10-17 07:30:22 --> Model Class Initialized
DEBUG - 2011-10-17 07:30:22 --> Model Class Initialized
DEBUG - 2011-10-17 07:30:22 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-17 07:30:22 --> Database Driver Class Initialized
DEBUG - 2011-10-17 07:30:23 --> Final output sent to browser
DEBUG - 2011-10-17 07:30:23 --> Total execution time: 0.6304
DEBUG - 2011-10-17 07:30:24 --> Config Class Initialized
DEBUG - 2011-10-17 07:30:24 --> Hooks Class Initialized
DEBUG - 2011-10-17 07:30:24 --> Utf8 Class Initialized
DEBUG - 2011-10-17 07:30:24 --> UTF-8 Support Enabled
DEBUG - 2011-10-17 07:30:24 --> URI Class Initialized
DEBUG - 2011-10-17 07:30:24 --> Router Class Initialized
ERROR - 2011-10-17 07:30:24 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-17 07:30:40 --> Config Class Initialized
DEBUG - 2011-10-17 07:30:40 --> Hooks Class Initialized
DEBUG - 2011-10-17 07:30:40 --> Utf8 Class Initialized
DEBUG - 2011-10-17 07:30:40 --> UTF-8 Support Enabled
DEBUG - 2011-10-17 07:30:40 --> URI Class Initialized
DEBUG - 2011-10-17 07:30:40 --> Router Class Initialized
DEBUG - 2011-10-17 07:30:40 --> Output Class Initialized
DEBUG - 2011-10-17 07:30:40 --> Input Class Initialized
DEBUG - 2011-10-17 07:30:40 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-17 07:30:40 --> Language Class Initialized
DEBUG - 2011-10-17 07:30:40 --> Loader Class Initialized
DEBUG - 2011-10-17 07:30:40 --> Controller Class Initialized
ERROR - 2011-10-17 07:30:40 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-10-17 07:30:40 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-10-17 07:30:40 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-17 07:30:40 --> Model Class Initialized
DEBUG - 2011-10-17 07:30:40 --> Model Class Initialized
DEBUG - 2011-10-17 07:30:40 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-17 07:30:40 --> Database Driver Class Initialized
DEBUG - 2011-10-17 07:30:40 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-17 07:30:40 --> Helper loaded: url_helper
DEBUG - 2011-10-17 07:30:40 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-17 07:30:40 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-17 07:30:40 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-17 07:30:40 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-17 07:30:40 --> Final output sent to browser
DEBUG - 2011-10-17 07:30:40 --> Total execution time: 0.0333
DEBUG - 2011-10-17 07:30:41 --> Config Class Initialized
DEBUG - 2011-10-17 07:30:41 --> Hooks Class Initialized
DEBUG - 2011-10-17 07:30:41 --> Utf8 Class Initialized
DEBUG - 2011-10-17 07:30:41 --> UTF-8 Support Enabled
DEBUG - 2011-10-17 07:30:41 --> URI Class Initialized
DEBUG - 2011-10-17 07:30:41 --> Router Class Initialized
DEBUG - 2011-10-17 07:30:41 --> Output Class Initialized
DEBUG - 2011-10-17 07:30:41 --> Input Class Initialized
DEBUG - 2011-10-17 07:30:41 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-17 07:30:41 --> Language Class Initialized
DEBUG - 2011-10-17 07:30:41 --> Loader Class Initialized
DEBUG - 2011-10-17 07:30:41 --> Controller Class Initialized
ERROR - 2011-10-17 07:30:41 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-10-17 07:30:41 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-10-17 07:30:41 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-17 07:30:41 --> Model Class Initialized
DEBUG - 2011-10-17 07:30:41 --> Model Class Initialized
DEBUG - 2011-10-17 07:30:41 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-17 07:30:41 --> Database Driver Class Initialized
DEBUG - 2011-10-17 07:30:41 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-17 07:30:41 --> Helper loaded: url_helper
DEBUG - 2011-10-17 07:30:41 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-17 07:30:41 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-17 07:30:41 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-17 07:30:41 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-17 07:30:41 --> Final output sent to browser
DEBUG - 2011-10-17 07:30:41 --> Total execution time: 0.0442
DEBUG - 2011-10-17 07:30:42 --> Config Class Initialized
DEBUG - 2011-10-17 07:30:42 --> Hooks Class Initialized
DEBUG - 2011-10-17 07:30:42 --> Utf8 Class Initialized
DEBUG - 2011-10-17 07:30:42 --> UTF-8 Support Enabled
DEBUG - 2011-10-17 07:30:42 --> URI Class Initialized
DEBUG - 2011-10-17 07:30:42 --> Router Class Initialized
DEBUG - 2011-10-17 07:30:42 --> Output Class Initialized
DEBUG - 2011-10-17 07:30:42 --> Input Class Initialized
DEBUG - 2011-10-17 07:30:42 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-17 07:30:42 --> Language Class Initialized
DEBUG - 2011-10-17 07:30:42 --> Loader Class Initialized
DEBUG - 2011-10-17 07:30:42 --> Controller Class Initialized
DEBUG - 2011-10-17 07:30:42 --> Model Class Initialized
DEBUG - 2011-10-17 07:30:42 --> Model Class Initialized
DEBUG - 2011-10-17 07:30:42 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-17 07:30:42 --> Database Driver Class Initialized
DEBUG - 2011-10-17 07:30:43 --> Final output sent to browser
DEBUG - 2011-10-17 07:30:43 --> Total execution time: 0.6430
DEBUG - 2011-10-17 07:30:44 --> Config Class Initialized
DEBUG - 2011-10-17 07:30:44 --> Hooks Class Initialized
DEBUG - 2011-10-17 07:30:44 --> Utf8 Class Initialized
DEBUG - 2011-10-17 07:30:44 --> UTF-8 Support Enabled
DEBUG - 2011-10-17 07:30:44 --> URI Class Initialized
DEBUG - 2011-10-17 07:30:44 --> Router Class Initialized
ERROR - 2011-10-17 07:30:44 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-17 07:31:03 --> Config Class Initialized
DEBUG - 2011-10-17 07:31:03 --> Hooks Class Initialized
DEBUG - 2011-10-17 07:31:03 --> Utf8 Class Initialized
DEBUG - 2011-10-17 07:31:03 --> UTF-8 Support Enabled
DEBUG - 2011-10-17 07:31:03 --> URI Class Initialized
DEBUG - 2011-10-17 07:31:03 --> Router Class Initialized
DEBUG - 2011-10-17 07:31:03 --> Output Class Initialized
DEBUG - 2011-10-17 07:31:03 --> Input Class Initialized
DEBUG - 2011-10-17 07:31:03 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-17 07:31:03 --> Language Class Initialized
DEBUG - 2011-10-17 07:31:03 --> Loader Class Initialized
DEBUG - 2011-10-17 07:31:03 --> Controller Class Initialized
ERROR - 2011-10-17 07:31:03 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-10-17 07:31:03 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-10-17 07:31:03 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-17 07:31:03 --> Model Class Initialized
DEBUG - 2011-10-17 07:31:03 --> Model Class Initialized
DEBUG - 2011-10-17 07:31:03 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-17 07:31:03 --> Database Driver Class Initialized
DEBUG - 2011-10-17 07:31:03 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-17 07:31:03 --> Helper loaded: url_helper
DEBUG - 2011-10-17 07:31:03 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-17 07:31:03 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-17 07:31:03 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-17 07:31:03 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-17 07:31:03 --> Final output sent to browser
DEBUG - 2011-10-17 07:31:03 --> Total execution time: 0.0336
DEBUG - 2011-10-17 07:31:04 --> Config Class Initialized
DEBUG - 2011-10-17 07:31:04 --> Hooks Class Initialized
DEBUG - 2011-10-17 07:31:04 --> Utf8 Class Initialized
DEBUG - 2011-10-17 07:31:04 --> UTF-8 Support Enabled
DEBUG - 2011-10-17 07:31:04 --> URI Class Initialized
DEBUG - 2011-10-17 07:31:04 --> Router Class Initialized
DEBUG - 2011-10-17 07:31:04 --> Output Class Initialized
DEBUG - 2011-10-17 07:31:04 --> Input Class Initialized
DEBUG - 2011-10-17 07:31:04 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-17 07:31:04 --> Language Class Initialized
DEBUG - 2011-10-17 07:31:04 --> Loader Class Initialized
DEBUG - 2011-10-17 07:31:04 --> Controller Class Initialized
DEBUG - 2011-10-17 07:31:04 --> Model Class Initialized
DEBUG - 2011-10-17 07:31:04 --> Model Class Initialized
DEBUG - 2011-10-17 07:31:04 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-17 07:31:04 --> Database Driver Class Initialized
DEBUG - 2011-10-17 07:31:05 --> Final output sent to browser
DEBUG - 2011-10-17 07:31:05 --> Total execution time: 1.0082
DEBUG - 2011-10-17 07:31:07 --> Config Class Initialized
DEBUG - 2011-10-17 07:31:07 --> Hooks Class Initialized
DEBUG - 2011-10-17 07:31:07 --> Utf8 Class Initialized
DEBUG - 2011-10-17 07:31:07 --> UTF-8 Support Enabled
DEBUG - 2011-10-17 07:31:07 --> URI Class Initialized
DEBUG - 2011-10-17 07:31:07 --> Router Class Initialized
ERROR - 2011-10-17 07:31:07 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-17 07:31:14 --> Config Class Initialized
DEBUG - 2011-10-17 07:31:14 --> Hooks Class Initialized
DEBUG - 2011-10-17 07:31:14 --> Utf8 Class Initialized
DEBUG - 2011-10-17 07:31:14 --> UTF-8 Support Enabled
DEBUG - 2011-10-17 07:31:14 --> URI Class Initialized
DEBUG - 2011-10-17 07:31:14 --> Router Class Initialized
DEBUG - 2011-10-17 07:31:14 --> Output Class Initialized
DEBUG - 2011-10-17 07:31:14 --> Input Class Initialized
DEBUG - 2011-10-17 07:31:14 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-17 07:31:14 --> Language Class Initialized
DEBUG - 2011-10-17 07:31:14 --> Loader Class Initialized
DEBUG - 2011-10-17 07:31:14 --> Controller Class Initialized
ERROR - 2011-10-17 07:31:14 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-10-17 07:31:14 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-10-17 07:31:14 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-17 07:31:14 --> Model Class Initialized
DEBUG - 2011-10-17 07:31:14 --> Model Class Initialized
DEBUG - 2011-10-17 07:31:14 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-17 07:31:14 --> Database Driver Class Initialized
DEBUG - 2011-10-17 07:31:14 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-17 07:31:14 --> Helper loaded: url_helper
DEBUG - 2011-10-17 07:31:14 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-17 07:31:14 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-17 07:31:14 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-17 07:31:14 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-17 07:31:14 --> Final output sent to browser
DEBUG - 2011-10-17 07:31:14 --> Total execution time: 0.0298
DEBUG - 2011-10-17 07:31:15 --> Config Class Initialized
DEBUG - 2011-10-17 07:31:15 --> Hooks Class Initialized
DEBUG - 2011-10-17 07:31:15 --> Utf8 Class Initialized
DEBUG - 2011-10-17 07:31:15 --> UTF-8 Support Enabled
DEBUG - 2011-10-17 07:31:15 --> URI Class Initialized
DEBUG - 2011-10-17 07:31:15 --> Router Class Initialized
DEBUG - 2011-10-17 07:31:15 --> Output Class Initialized
DEBUG - 2011-10-17 07:31:15 --> Input Class Initialized
DEBUG - 2011-10-17 07:31:15 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-17 07:31:15 --> Language Class Initialized
DEBUG - 2011-10-17 07:31:15 --> Loader Class Initialized
DEBUG - 2011-10-17 07:31:15 --> Controller Class Initialized
DEBUG - 2011-10-17 07:31:15 --> Model Class Initialized
DEBUG - 2011-10-17 07:31:15 --> Model Class Initialized
DEBUG - 2011-10-17 07:31:15 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-17 07:31:15 --> Database Driver Class Initialized
DEBUG - 2011-10-17 07:31:16 --> Final output sent to browser
DEBUG - 2011-10-17 07:31:16 --> Total execution time: 0.7718
DEBUG - 2011-10-17 07:31:17 --> Config Class Initialized
DEBUG - 2011-10-17 07:31:17 --> Hooks Class Initialized
DEBUG - 2011-10-17 07:31:17 --> Utf8 Class Initialized
DEBUG - 2011-10-17 07:31:17 --> UTF-8 Support Enabled
DEBUG - 2011-10-17 07:31:17 --> URI Class Initialized
DEBUG - 2011-10-17 07:31:17 --> Router Class Initialized
ERROR - 2011-10-17 07:31:17 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-17 07:40:34 --> Config Class Initialized
DEBUG - 2011-10-17 07:40:34 --> Hooks Class Initialized
DEBUG - 2011-10-17 07:40:34 --> Utf8 Class Initialized
DEBUG - 2011-10-17 07:40:34 --> UTF-8 Support Enabled
DEBUG - 2011-10-17 07:40:34 --> URI Class Initialized
DEBUG - 2011-10-17 07:40:34 --> Router Class Initialized
DEBUG - 2011-10-17 07:40:34 --> Output Class Initialized
DEBUG - 2011-10-17 07:40:34 --> Input Class Initialized
DEBUG - 2011-10-17 07:40:34 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-17 07:40:34 --> Language Class Initialized
DEBUG - 2011-10-17 07:40:34 --> Loader Class Initialized
DEBUG - 2011-10-17 07:40:34 --> Controller Class Initialized
DEBUG - 2011-10-17 07:40:34 --> Model Class Initialized
DEBUG - 2011-10-17 07:40:34 --> Model Class Initialized
DEBUG - 2011-10-17 07:40:34 --> Model Class Initialized
DEBUG - 2011-10-17 07:40:34 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-17 07:40:34 --> Database Driver Class Initialized
DEBUG - 2011-10-17 07:40:34 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-17 07:40:34 --> Helper loaded: url_helper
DEBUG - 2011-10-17 07:40:34 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-17 07:40:34 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-17 07:40:34 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-17 07:40:34 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-17 07:40:34 --> Final output sent to browser
DEBUG - 2011-10-17 07:40:34 --> Total execution time: 0.0645
DEBUG - 2011-10-17 07:40:37 --> Config Class Initialized
DEBUG - 2011-10-17 07:40:37 --> Hooks Class Initialized
DEBUG - 2011-10-17 07:40:37 --> Utf8 Class Initialized
DEBUG - 2011-10-17 07:40:37 --> UTF-8 Support Enabled
DEBUG - 2011-10-17 07:40:37 --> URI Class Initialized
DEBUG - 2011-10-17 07:40:37 --> Router Class Initialized
ERROR - 2011-10-17 07:40:37 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-17 07:41:25 --> Config Class Initialized
DEBUG - 2011-10-17 07:41:25 --> Hooks Class Initialized
DEBUG - 2011-10-17 07:41:25 --> Utf8 Class Initialized
DEBUG - 2011-10-17 07:41:25 --> UTF-8 Support Enabled
DEBUG - 2011-10-17 07:41:25 --> URI Class Initialized
DEBUG - 2011-10-17 07:41:25 --> Router Class Initialized
DEBUG - 2011-10-17 07:41:25 --> Output Class Initialized
DEBUG - 2011-10-17 07:41:25 --> Input Class Initialized
DEBUG - 2011-10-17 07:41:25 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-17 07:41:25 --> Language Class Initialized
DEBUG - 2011-10-17 07:41:25 --> Loader Class Initialized
DEBUG - 2011-10-17 07:41:25 --> Controller Class Initialized
DEBUG - 2011-10-17 07:41:25 --> Model Class Initialized
DEBUG - 2011-10-17 07:41:25 --> Model Class Initialized
DEBUG - 2011-10-17 07:41:25 --> Model Class Initialized
DEBUG - 2011-10-17 07:41:25 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-17 07:41:25 --> Database Driver Class Initialized
DEBUG - 2011-10-17 07:41:25 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-17 07:41:25 --> Helper loaded: url_helper
DEBUG - 2011-10-17 07:41:25 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-17 07:41:25 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-17 07:41:25 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-17 07:41:25 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-17 07:41:25 --> Final output sent to browser
DEBUG - 2011-10-17 07:41:25 --> Total execution time: 0.1911
DEBUG - 2011-10-17 07:41:27 --> Config Class Initialized
DEBUG - 2011-10-17 07:41:27 --> Hooks Class Initialized
DEBUG - 2011-10-17 07:41:27 --> Utf8 Class Initialized
DEBUG - 2011-10-17 07:41:27 --> UTF-8 Support Enabled
DEBUG - 2011-10-17 07:41:27 --> URI Class Initialized
DEBUG - 2011-10-17 07:41:27 --> Router Class Initialized
ERROR - 2011-10-17 07:41:27 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-17 07:41:37 --> Config Class Initialized
DEBUG - 2011-10-17 07:41:37 --> Hooks Class Initialized
DEBUG - 2011-10-17 07:41:37 --> Utf8 Class Initialized
DEBUG - 2011-10-17 07:41:37 --> UTF-8 Support Enabled
DEBUG - 2011-10-17 07:41:37 --> URI Class Initialized
DEBUG - 2011-10-17 07:41:37 --> Router Class Initialized
DEBUG - 2011-10-17 07:41:37 --> Output Class Initialized
DEBUG - 2011-10-17 07:41:37 --> Input Class Initialized
DEBUG - 2011-10-17 07:41:37 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-17 07:41:37 --> Language Class Initialized
DEBUG - 2011-10-17 07:41:37 --> Loader Class Initialized
DEBUG - 2011-10-17 07:41:37 --> Controller Class Initialized
DEBUG - 2011-10-17 07:41:37 --> Model Class Initialized
DEBUG - 2011-10-17 07:41:37 --> Model Class Initialized
DEBUG - 2011-10-17 07:41:37 --> Model Class Initialized
DEBUG - 2011-10-17 07:41:37 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-17 07:41:37 --> Database Driver Class Initialized
DEBUG - 2011-10-17 07:41:37 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-17 07:41:37 --> Helper loaded: url_helper
DEBUG - 2011-10-17 07:41:37 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-17 07:41:37 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-17 07:41:37 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-17 07:41:37 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-17 07:41:37 --> Final output sent to browser
DEBUG - 2011-10-17 07:41:37 --> Total execution time: 0.1989
DEBUG - 2011-10-17 07:41:39 --> Config Class Initialized
DEBUG - 2011-10-17 07:41:39 --> Hooks Class Initialized
DEBUG - 2011-10-17 07:41:39 --> Utf8 Class Initialized
DEBUG - 2011-10-17 07:41:39 --> UTF-8 Support Enabled
DEBUG - 2011-10-17 07:41:39 --> URI Class Initialized
DEBUG - 2011-10-17 07:41:39 --> Router Class Initialized
ERROR - 2011-10-17 07:41:39 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-17 07:41:39 --> Config Class Initialized
DEBUG - 2011-10-17 07:41:39 --> Hooks Class Initialized
DEBUG - 2011-10-17 07:41:39 --> Utf8 Class Initialized
DEBUG - 2011-10-17 07:41:39 --> UTF-8 Support Enabled
DEBUG - 2011-10-17 07:41:39 --> URI Class Initialized
DEBUG - 2011-10-17 07:41:39 --> Router Class Initialized
DEBUG - 2011-10-17 07:41:39 --> Output Class Initialized
DEBUG - 2011-10-17 07:41:39 --> Input Class Initialized
DEBUG - 2011-10-17 07:41:39 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-17 07:41:39 --> Language Class Initialized
DEBUG - 2011-10-17 07:41:39 --> Loader Class Initialized
DEBUG - 2011-10-17 07:41:39 --> Controller Class Initialized
DEBUG - 2011-10-17 07:41:39 --> Model Class Initialized
DEBUG - 2011-10-17 07:41:39 --> Model Class Initialized
DEBUG - 2011-10-17 07:41:39 --> Model Class Initialized
DEBUG - 2011-10-17 07:41:39 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-17 07:41:39 --> Database Driver Class Initialized
DEBUG - 2011-10-17 07:41:39 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-17 07:41:39 --> Helper loaded: url_helper
DEBUG - 2011-10-17 07:41:39 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-17 07:41:39 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-17 07:41:39 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-17 07:41:39 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-17 07:41:39 --> Final output sent to browser
DEBUG - 2011-10-17 07:41:39 --> Total execution time: 0.0445
DEBUG - 2011-10-17 07:42:58 --> Config Class Initialized
DEBUG - 2011-10-17 07:42:58 --> Hooks Class Initialized
DEBUG - 2011-10-17 07:42:58 --> Utf8 Class Initialized
DEBUG - 2011-10-17 07:42:58 --> UTF-8 Support Enabled
DEBUG - 2011-10-17 07:42:58 --> URI Class Initialized
DEBUG - 2011-10-17 07:42:58 --> Router Class Initialized
DEBUG - 2011-10-17 07:42:58 --> Output Class Initialized
DEBUG - 2011-10-17 07:42:58 --> Input Class Initialized
DEBUG - 2011-10-17 07:42:58 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-17 07:42:58 --> Language Class Initialized
DEBUG - 2011-10-17 07:42:58 --> Loader Class Initialized
DEBUG - 2011-10-17 07:42:58 --> Controller Class Initialized
ERROR - 2011-10-17 07:42:58 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-10-17 07:42:58 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-10-17 07:42:58 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-17 07:42:58 --> Model Class Initialized
DEBUG - 2011-10-17 07:42:58 --> Model Class Initialized
DEBUG - 2011-10-17 07:42:58 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-17 07:42:58 --> Database Driver Class Initialized
DEBUG - 2011-10-17 07:42:58 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-17 07:42:58 --> Helper loaded: url_helper
DEBUG - 2011-10-17 07:42:58 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-17 07:42:58 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-17 07:42:58 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-17 07:42:58 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-17 07:42:58 --> Final output sent to browser
DEBUG - 2011-10-17 07:42:58 --> Total execution time: 0.0299
DEBUG - 2011-10-17 07:42:58 --> Config Class Initialized
DEBUG - 2011-10-17 07:42:58 --> Hooks Class Initialized
DEBUG - 2011-10-17 07:42:58 --> Utf8 Class Initialized
DEBUG - 2011-10-17 07:42:58 --> UTF-8 Support Enabled
DEBUG - 2011-10-17 07:42:58 --> URI Class Initialized
DEBUG - 2011-10-17 07:42:58 --> Router Class Initialized
DEBUG - 2011-10-17 07:42:58 --> Output Class Initialized
DEBUG - 2011-10-17 07:42:58 --> Input Class Initialized
DEBUG - 2011-10-17 07:42:58 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-17 07:42:58 --> Language Class Initialized
DEBUG - 2011-10-17 07:42:58 --> Loader Class Initialized
DEBUG - 2011-10-17 07:42:58 --> Controller Class Initialized
DEBUG - 2011-10-17 07:42:58 --> Model Class Initialized
DEBUG - 2011-10-17 07:42:58 --> Model Class Initialized
DEBUG - 2011-10-17 07:42:58 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-17 07:42:58 --> Database Driver Class Initialized
DEBUG - 2011-10-17 07:42:59 --> Final output sent to browser
DEBUG - 2011-10-17 07:42:59 --> Total execution time: 0.8319
DEBUG - 2011-10-17 07:44:43 --> Config Class Initialized
DEBUG - 2011-10-17 07:44:43 --> Hooks Class Initialized
DEBUG - 2011-10-17 07:44:43 --> Utf8 Class Initialized
DEBUG - 2011-10-17 07:44:43 --> UTF-8 Support Enabled
DEBUG - 2011-10-17 07:44:43 --> URI Class Initialized
DEBUG - 2011-10-17 07:44:43 --> Router Class Initialized
DEBUG - 2011-10-17 07:44:43 --> Output Class Initialized
DEBUG - 2011-10-17 07:44:43 --> Input Class Initialized
DEBUG - 2011-10-17 07:44:43 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-17 07:44:43 --> Language Class Initialized
DEBUG - 2011-10-17 07:44:43 --> Loader Class Initialized
DEBUG - 2011-10-17 07:44:43 --> Controller Class Initialized
DEBUG - 2011-10-17 07:44:43 --> Model Class Initialized
DEBUG - 2011-10-17 07:44:43 --> Model Class Initialized
DEBUG - 2011-10-17 07:44:43 --> Model Class Initialized
DEBUG - 2011-10-17 07:44:43 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-17 07:44:43 --> Database Driver Class Initialized
DEBUG - 2011-10-17 07:44:43 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-17 07:44:43 --> Helper loaded: url_helper
DEBUG - 2011-10-17 07:44:43 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-17 07:44:43 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-17 07:44:43 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-17 07:44:43 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-17 07:44:43 --> Final output sent to browser
DEBUG - 2011-10-17 07:44:43 --> Total execution time: 0.3808
DEBUG - 2011-10-17 07:44:45 --> Config Class Initialized
DEBUG - 2011-10-17 07:44:45 --> Hooks Class Initialized
DEBUG - 2011-10-17 07:44:45 --> Utf8 Class Initialized
DEBUG - 2011-10-17 07:44:45 --> UTF-8 Support Enabled
DEBUG - 2011-10-17 07:44:45 --> URI Class Initialized
DEBUG - 2011-10-17 07:44:45 --> Router Class Initialized
ERROR - 2011-10-17 07:44:45 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-17 07:44:45 --> Config Class Initialized
DEBUG - 2011-10-17 07:44:45 --> Hooks Class Initialized
DEBUG - 2011-10-17 07:44:45 --> Utf8 Class Initialized
DEBUG - 2011-10-17 07:44:45 --> UTF-8 Support Enabled
DEBUG - 2011-10-17 07:44:45 --> URI Class Initialized
DEBUG - 2011-10-17 07:44:45 --> Router Class Initialized
DEBUG - 2011-10-17 07:44:45 --> Output Class Initialized
DEBUG - 2011-10-17 07:44:45 --> Input Class Initialized
DEBUG - 2011-10-17 07:44:45 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-17 07:44:45 --> Language Class Initialized
DEBUG - 2011-10-17 07:44:45 --> Loader Class Initialized
DEBUG - 2011-10-17 07:44:45 --> Controller Class Initialized
DEBUG - 2011-10-17 07:44:45 --> Model Class Initialized
DEBUG - 2011-10-17 07:44:45 --> Model Class Initialized
DEBUG - 2011-10-17 07:44:45 --> Model Class Initialized
DEBUG - 2011-10-17 07:44:45 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-17 07:44:45 --> Database Driver Class Initialized
DEBUG - 2011-10-17 07:44:45 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-17 07:44:45 --> Helper loaded: url_helper
DEBUG - 2011-10-17 07:44:45 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-17 07:44:45 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-17 07:44:45 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-17 07:44:45 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-17 07:44:45 --> Final output sent to browser
DEBUG - 2011-10-17 07:44:45 --> Total execution time: 0.1177
DEBUG - 2011-10-17 07:44:52 --> Config Class Initialized
DEBUG - 2011-10-17 07:44:52 --> Hooks Class Initialized
DEBUG - 2011-10-17 07:44:52 --> Utf8 Class Initialized
DEBUG - 2011-10-17 07:44:52 --> UTF-8 Support Enabled
DEBUG - 2011-10-17 07:44:52 --> URI Class Initialized
DEBUG - 2011-10-17 07:44:52 --> Router Class Initialized
DEBUG - 2011-10-17 07:44:52 --> Output Class Initialized
DEBUG - 2011-10-17 07:44:52 --> Input Class Initialized
DEBUG - 2011-10-17 07:44:52 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-17 07:44:52 --> Language Class Initialized
DEBUG - 2011-10-17 07:44:52 --> Loader Class Initialized
DEBUG - 2011-10-17 07:44:52 --> Controller Class Initialized
DEBUG - 2011-10-17 07:44:52 --> Model Class Initialized
DEBUG - 2011-10-17 07:44:52 --> Model Class Initialized
DEBUG - 2011-10-17 07:44:52 --> Model Class Initialized
DEBUG - 2011-10-17 07:44:52 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-17 07:44:52 --> Database Driver Class Initialized
DEBUG - 2011-10-17 07:44:53 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-17 07:44:53 --> Helper loaded: url_helper
DEBUG - 2011-10-17 07:44:53 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-17 07:44:53 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-17 07:44:53 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-17 07:44:53 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-17 07:44:53 --> Final output sent to browser
DEBUG - 2011-10-17 07:44:53 --> Total execution time: 1.0358
DEBUG - 2011-10-17 07:44:55 --> Config Class Initialized
DEBUG - 2011-10-17 07:44:55 --> Hooks Class Initialized
DEBUG - 2011-10-17 07:44:55 --> Utf8 Class Initialized
DEBUG - 2011-10-17 07:44:55 --> UTF-8 Support Enabled
DEBUG - 2011-10-17 07:44:55 --> URI Class Initialized
DEBUG - 2011-10-17 07:44:55 --> Router Class Initialized
ERROR - 2011-10-17 07:44:55 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-17 07:44:56 --> Config Class Initialized
DEBUG - 2011-10-17 07:44:56 --> Hooks Class Initialized
DEBUG - 2011-10-17 07:44:56 --> Utf8 Class Initialized
DEBUG - 2011-10-17 07:44:56 --> UTF-8 Support Enabled
DEBUG - 2011-10-17 07:44:56 --> URI Class Initialized
DEBUG - 2011-10-17 07:44:56 --> Router Class Initialized
DEBUG - 2011-10-17 07:44:56 --> Output Class Initialized
DEBUG - 2011-10-17 07:44:56 --> Input Class Initialized
DEBUG - 2011-10-17 07:44:56 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-17 07:44:56 --> Language Class Initialized
DEBUG - 2011-10-17 07:44:56 --> Loader Class Initialized
DEBUG - 2011-10-17 07:44:56 --> Controller Class Initialized
DEBUG - 2011-10-17 07:44:56 --> Model Class Initialized
DEBUG - 2011-10-17 07:44:56 --> Model Class Initialized
DEBUG - 2011-10-17 07:44:56 --> Model Class Initialized
DEBUG - 2011-10-17 07:44:56 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-17 07:44:56 --> Database Driver Class Initialized
DEBUG - 2011-10-17 07:44:57 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-17 07:44:57 --> Helper loaded: url_helper
DEBUG - 2011-10-17 07:44:57 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-17 07:44:57 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-17 07:44:57 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-17 07:44:57 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-17 07:44:57 --> Final output sent to browser
DEBUG - 2011-10-17 07:44:57 --> Total execution time: 0.2887
DEBUG - 2011-10-17 07:45:04 --> Config Class Initialized
DEBUG - 2011-10-17 07:45:04 --> Hooks Class Initialized
DEBUG - 2011-10-17 07:45:04 --> Utf8 Class Initialized
DEBUG - 2011-10-17 07:45:04 --> UTF-8 Support Enabled
DEBUG - 2011-10-17 07:45:04 --> URI Class Initialized
DEBUG - 2011-10-17 07:45:04 --> Router Class Initialized
DEBUG - 2011-10-17 07:45:04 --> Output Class Initialized
DEBUG - 2011-10-17 07:45:04 --> Input Class Initialized
DEBUG - 2011-10-17 07:45:04 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-17 07:45:04 --> Language Class Initialized
DEBUG - 2011-10-17 07:45:04 --> Loader Class Initialized
DEBUG - 2011-10-17 07:45:04 --> Controller Class Initialized
DEBUG - 2011-10-17 07:45:04 --> Model Class Initialized
DEBUG - 2011-10-17 07:45:04 --> Model Class Initialized
DEBUG - 2011-10-17 07:45:04 --> Model Class Initialized
DEBUG - 2011-10-17 07:45:04 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-17 07:45:05 --> Database Driver Class Initialized
DEBUG - 2011-10-17 07:45:06 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-17 07:45:06 --> Helper loaded: url_helper
DEBUG - 2011-10-17 07:45:06 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-17 07:45:06 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-17 07:45:06 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-17 07:45:06 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-17 07:45:06 --> Final output sent to browser
DEBUG - 2011-10-17 07:45:06 --> Total execution time: 1.4929
DEBUG - 2011-10-17 07:45:09 --> Config Class Initialized
DEBUG - 2011-10-17 07:45:09 --> Hooks Class Initialized
DEBUG - 2011-10-17 07:45:09 --> Utf8 Class Initialized
DEBUG - 2011-10-17 07:45:09 --> UTF-8 Support Enabled
DEBUG - 2011-10-17 07:45:09 --> URI Class Initialized
DEBUG - 2011-10-17 07:45:09 --> Router Class Initialized
ERROR - 2011-10-17 07:45:09 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-17 07:45:12 --> Config Class Initialized
DEBUG - 2011-10-17 07:45:12 --> Hooks Class Initialized
DEBUG - 2011-10-17 07:45:12 --> Utf8 Class Initialized
DEBUG - 2011-10-17 07:45:12 --> UTF-8 Support Enabled
DEBUG - 2011-10-17 07:45:12 --> URI Class Initialized
DEBUG - 2011-10-17 07:45:12 --> Router Class Initialized
DEBUG - 2011-10-17 07:45:12 --> Output Class Initialized
DEBUG - 2011-10-17 07:45:12 --> Input Class Initialized
DEBUG - 2011-10-17 07:45:12 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-17 07:45:12 --> Language Class Initialized
DEBUG - 2011-10-17 07:45:12 --> Loader Class Initialized
DEBUG - 2011-10-17 07:45:12 --> Controller Class Initialized
DEBUG - 2011-10-17 07:45:12 --> Model Class Initialized
DEBUG - 2011-10-17 07:45:12 --> Model Class Initialized
DEBUG - 2011-10-17 07:45:12 --> Model Class Initialized
DEBUG - 2011-10-17 07:45:12 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-17 07:45:12 --> Database Driver Class Initialized
DEBUG - 2011-10-17 07:45:12 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-17 07:45:12 --> Helper loaded: url_helper
DEBUG - 2011-10-17 07:45:12 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-17 07:45:12 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-17 07:45:12 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-17 07:45:12 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-17 07:45:12 --> Final output sent to browser
DEBUG - 2011-10-17 07:45:12 --> Total execution time: 0.1899
DEBUG - 2011-10-17 07:45:41 --> Config Class Initialized
DEBUG - 2011-10-17 07:45:41 --> Hooks Class Initialized
DEBUG - 2011-10-17 07:45:41 --> Utf8 Class Initialized
DEBUG - 2011-10-17 07:45:41 --> UTF-8 Support Enabled
DEBUG - 2011-10-17 07:45:41 --> URI Class Initialized
DEBUG - 2011-10-17 07:45:41 --> Router Class Initialized
DEBUG - 2011-10-17 07:45:41 --> Output Class Initialized
DEBUG - 2011-10-17 07:45:41 --> Input Class Initialized
DEBUG - 2011-10-17 07:45:41 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-17 07:45:41 --> Language Class Initialized
DEBUG - 2011-10-17 07:45:41 --> Loader Class Initialized
DEBUG - 2011-10-17 07:45:41 --> Controller Class Initialized
DEBUG - 2011-10-17 07:45:41 --> Model Class Initialized
DEBUG - 2011-10-17 07:45:41 --> Model Class Initialized
DEBUG - 2011-10-17 07:45:41 --> Model Class Initialized
DEBUG - 2011-10-17 07:45:41 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-17 07:45:41 --> Database Driver Class Initialized
DEBUG - 2011-10-17 07:45:41 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-17 07:45:41 --> Helper loaded: url_helper
DEBUG - 2011-10-17 07:45:41 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-17 07:45:41 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-17 07:45:41 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-17 07:45:41 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-17 07:45:41 --> Final output sent to browser
DEBUG - 2011-10-17 07:45:41 --> Total execution time: 0.0461
DEBUG - 2011-10-17 07:45:43 --> Config Class Initialized
DEBUG - 2011-10-17 07:45:43 --> Hooks Class Initialized
DEBUG - 2011-10-17 07:45:43 --> Utf8 Class Initialized
DEBUG - 2011-10-17 07:45:43 --> UTF-8 Support Enabled
DEBUG - 2011-10-17 07:45:43 --> URI Class Initialized
DEBUG - 2011-10-17 07:45:43 --> Router Class Initialized
ERROR - 2011-10-17 07:45:43 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-17 07:48:23 --> Config Class Initialized
DEBUG - 2011-10-17 07:48:23 --> Hooks Class Initialized
DEBUG - 2011-10-17 07:48:23 --> Utf8 Class Initialized
DEBUG - 2011-10-17 07:48:23 --> UTF-8 Support Enabled
DEBUG - 2011-10-17 07:48:23 --> URI Class Initialized
DEBUG - 2011-10-17 07:48:23 --> Router Class Initialized
DEBUG - 2011-10-17 07:48:23 --> No URI present. Default controller set.
DEBUG - 2011-10-17 07:48:23 --> Output Class Initialized
DEBUG - 2011-10-17 07:48:23 --> Input Class Initialized
DEBUG - 2011-10-17 07:48:23 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-17 07:48:23 --> Language Class Initialized
DEBUG - 2011-10-17 07:48:23 --> Loader Class Initialized
DEBUG - 2011-10-17 07:48:23 --> Controller Class Initialized
DEBUG - 2011-10-17 07:48:23 --> File loaded: application/views/splash/main.php
DEBUG - 2011-10-17 07:48:23 --> Helper loaded: url_helper
DEBUG - 2011-10-17 07:48:23 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-17 07:48:23 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-17 07:48:23 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-17 07:48:23 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-17 07:48:23 --> Final output sent to browser
DEBUG - 2011-10-17 07:48:23 --> Total execution time: 0.1560
DEBUG - 2011-10-17 07:48:30 --> Config Class Initialized
DEBUG - 2011-10-17 07:48:30 --> Hooks Class Initialized
DEBUG - 2011-10-17 07:48:30 --> Utf8 Class Initialized
DEBUG - 2011-10-17 07:48:30 --> UTF-8 Support Enabled
DEBUG - 2011-10-17 07:48:30 --> URI Class Initialized
DEBUG - 2011-10-17 07:48:30 --> Router Class Initialized
DEBUG - 2011-10-17 07:48:30 --> Output Class Initialized
DEBUG - 2011-10-17 07:48:30 --> Input Class Initialized
DEBUG - 2011-10-17 07:48:30 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-17 07:48:30 --> Language Class Initialized
DEBUG - 2011-10-17 07:48:30 --> Loader Class Initialized
DEBUG - 2011-10-17 07:48:30 --> Controller Class Initialized
DEBUG - 2011-10-17 07:48:30 --> Model Class Initialized
DEBUG - 2011-10-17 07:48:30 --> Model Class Initialized
DEBUG - 2011-10-17 07:48:30 --> Model Class Initialized
DEBUG - 2011-10-17 07:48:30 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-17 07:48:30 --> Database Driver Class Initialized
DEBUG - 2011-10-17 07:48:31 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-17 07:48:31 --> Helper loaded: url_helper
DEBUG - 2011-10-17 07:48:31 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-17 07:48:31 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-17 07:48:31 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-17 07:48:31 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-17 07:48:31 --> Final output sent to browser
DEBUG - 2011-10-17 07:48:31 --> Total execution time: 1.0621
DEBUG - 2011-10-17 07:48:33 --> Config Class Initialized
DEBUG - 2011-10-17 07:48:33 --> Hooks Class Initialized
DEBUG - 2011-10-17 07:48:33 --> Utf8 Class Initialized
DEBUG - 2011-10-17 07:48:33 --> UTF-8 Support Enabled
DEBUG - 2011-10-17 07:48:33 --> URI Class Initialized
DEBUG - 2011-10-17 07:48:33 --> Router Class Initialized
ERROR - 2011-10-17 07:48:33 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-17 07:48:38 --> Config Class Initialized
DEBUG - 2011-10-17 07:48:38 --> Hooks Class Initialized
DEBUG - 2011-10-17 07:48:38 --> Utf8 Class Initialized
DEBUG - 2011-10-17 07:48:38 --> UTF-8 Support Enabled
DEBUG - 2011-10-17 07:48:38 --> URI Class Initialized
DEBUG - 2011-10-17 07:48:38 --> Router Class Initialized
DEBUG - 2011-10-17 07:48:38 --> Output Class Initialized
DEBUG - 2011-10-17 07:48:38 --> Input Class Initialized
DEBUG - 2011-10-17 07:48:38 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-17 07:48:38 --> Language Class Initialized
DEBUG - 2011-10-17 07:48:38 --> Loader Class Initialized
DEBUG - 2011-10-17 07:48:38 --> Controller Class Initialized
DEBUG - 2011-10-17 07:48:38 --> Model Class Initialized
DEBUG - 2011-10-17 07:48:38 --> Model Class Initialized
DEBUG - 2011-10-17 07:48:38 --> Model Class Initialized
DEBUG - 2011-10-17 07:48:38 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-17 07:48:38 --> Database Driver Class Initialized
DEBUG - 2011-10-17 07:48:38 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-17 07:48:38 --> Helper loaded: url_helper
DEBUG - 2011-10-17 07:48:38 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-17 07:48:38 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-17 07:48:38 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-17 07:48:38 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-17 07:48:38 --> Final output sent to browser
DEBUG - 2011-10-17 07:48:38 --> Total execution time: 0.0556
DEBUG - 2011-10-17 07:49:10 --> Config Class Initialized
DEBUG - 2011-10-17 07:49:10 --> Hooks Class Initialized
DEBUG - 2011-10-17 07:49:10 --> Utf8 Class Initialized
DEBUG - 2011-10-17 07:49:10 --> UTF-8 Support Enabled
DEBUG - 2011-10-17 07:49:10 --> URI Class Initialized
DEBUG - 2011-10-17 07:49:10 --> Router Class Initialized
DEBUG - 2011-10-17 07:49:10 --> Output Class Initialized
DEBUG - 2011-10-17 07:49:10 --> Input Class Initialized
DEBUG - 2011-10-17 07:49:10 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-17 07:49:10 --> Language Class Initialized
DEBUG - 2011-10-17 07:49:10 --> Loader Class Initialized
DEBUG - 2011-10-17 07:49:10 --> Controller Class Initialized
ERROR - 2011-10-17 07:49:10 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-10-17 07:49:10 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-10-17 07:49:10 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-17 07:49:10 --> Model Class Initialized
DEBUG - 2011-10-17 07:49:10 --> Model Class Initialized
DEBUG - 2011-10-17 07:49:10 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-17 07:49:10 --> Database Driver Class Initialized
DEBUG - 2011-10-17 07:49:10 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-17 07:49:10 --> Helper loaded: url_helper
DEBUG - 2011-10-17 07:49:10 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-17 07:49:10 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-17 07:49:10 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-17 07:49:10 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-17 07:49:10 --> Final output sent to browser
DEBUG - 2011-10-17 07:49:10 --> Total execution time: 0.1184
DEBUG - 2011-10-17 07:49:12 --> Config Class Initialized
DEBUG - 2011-10-17 07:49:12 --> Hooks Class Initialized
DEBUG - 2011-10-17 07:49:12 --> Utf8 Class Initialized
DEBUG - 2011-10-17 07:49:12 --> UTF-8 Support Enabled
DEBUG - 2011-10-17 07:49:12 --> URI Class Initialized
DEBUG - 2011-10-17 07:49:12 --> Router Class Initialized
DEBUG - 2011-10-17 07:49:12 --> Output Class Initialized
DEBUG - 2011-10-17 07:49:12 --> Input Class Initialized
DEBUG - 2011-10-17 07:49:12 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-17 07:49:12 --> Language Class Initialized
DEBUG - 2011-10-17 07:49:12 --> Loader Class Initialized
DEBUG - 2011-10-17 07:49:12 --> Controller Class Initialized
DEBUG - 2011-10-17 07:49:12 --> Model Class Initialized
DEBUG - 2011-10-17 07:49:12 --> Model Class Initialized
DEBUG - 2011-10-17 07:49:12 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-17 07:49:12 --> Database Driver Class Initialized
DEBUG - 2011-10-17 07:49:14 --> Final output sent to browser
DEBUG - 2011-10-17 07:49:14 --> Total execution time: 1.4002
DEBUG - 2011-10-17 07:49:18 --> Config Class Initialized
DEBUG - 2011-10-17 07:49:18 --> Hooks Class Initialized
DEBUG - 2011-10-17 07:49:18 --> Utf8 Class Initialized
DEBUG - 2011-10-17 07:49:18 --> UTF-8 Support Enabled
DEBUG - 2011-10-17 07:49:18 --> URI Class Initialized
DEBUG - 2011-10-17 07:49:18 --> Router Class Initialized
ERROR - 2011-10-17 07:49:18 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-17 07:53:42 --> Config Class Initialized
DEBUG - 2011-10-17 07:53:42 --> Hooks Class Initialized
DEBUG - 2011-10-17 07:53:42 --> Utf8 Class Initialized
DEBUG - 2011-10-17 07:53:42 --> UTF-8 Support Enabled
DEBUG - 2011-10-17 07:53:42 --> URI Class Initialized
DEBUG - 2011-10-17 07:53:42 --> Router Class Initialized
ERROR - 2011-10-17 07:53:42 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-10-17 07:53:43 --> Config Class Initialized
DEBUG - 2011-10-17 07:53:43 --> Hooks Class Initialized
DEBUG - 2011-10-17 07:53:43 --> Utf8 Class Initialized
DEBUG - 2011-10-17 07:53:43 --> UTF-8 Support Enabled
DEBUG - 2011-10-17 07:53:43 --> URI Class Initialized
DEBUG - 2011-10-17 07:53:43 --> Router Class Initialized
DEBUG - 2011-10-17 07:53:43 --> Output Class Initialized
DEBUG - 2011-10-17 07:53:43 --> Input Class Initialized
DEBUG - 2011-10-17 07:53:43 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-17 07:53:43 --> Language Class Initialized
DEBUG - 2011-10-17 07:53:43 --> Loader Class Initialized
DEBUG - 2011-10-17 07:53:43 --> Controller Class Initialized
DEBUG - 2011-10-17 07:53:43 --> Model Class Initialized
DEBUG - 2011-10-17 07:53:43 --> Model Class Initialized
DEBUG - 2011-10-17 07:53:43 --> Model Class Initialized
DEBUG - 2011-10-17 07:53:43 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-17 07:53:43 --> Database Driver Class Initialized
DEBUG - 2011-10-17 07:53:43 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-17 07:53:43 --> Helper loaded: url_helper
DEBUG - 2011-10-17 07:53:43 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-17 07:53:43 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-17 07:53:43 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-17 07:53:43 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-17 07:53:43 --> Final output sent to browser
DEBUG - 2011-10-17 07:53:43 --> Total execution time: 0.1131
DEBUG - 2011-10-17 08:31:38 --> Config Class Initialized
DEBUG - 2011-10-17 08:31:38 --> Hooks Class Initialized
DEBUG - 2011-10-17 08:31:38 --> Utf8 Class Initialized
DEBUG - 2011-10-17 08:31:38 --> UTF-8 Support Enabled
DEBUG - 2011-10-17 08:31:38 --> URI Class Initialized
DEBUG - 2011-10-17 08:31:38 --> Router Class Initialized
DEBUG - 2011-10-17 08:31:38 --> Output Class Initialized
DEBUG - 2011-10-17 08:31:38 --> Input Class Initialized
DEBUG - 2011-10-17 08:31:38 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-17 08:31:38 --> Language Class Initialized
DEBUG - 2011-10-17 08:31:38 --> Loader Class Initialized
DEBUG - 2011-10-17 08:31:38 --> Controller Class Initialized
DEBUG - 2011-10-17 08:31:38 --> Model Class Initialized
DEBUG - 2011-10-17 08:31:38 --> Model Class Initialized
DEBUG - 2011-10-17 08:31:38 --> Model Class Initialized
DEBUG - 2011-10-17 08:31:38 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-17 08:31:38 --> Database Driver Class Initialized
DEBUG - 2011-10-17 08:31:38 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-17 08:31:38 --> Helper loaded: url_helper
DEBUG - 2011-10-17 08:31:38 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-17 08:31:38 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-17 08:31:38 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-17 08:31:38 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-17 08:31:38 --> Final output sent to browser
DEBUG - 2011-10-17 08:31:38 --> Total execution time: 0.3884
DEBUG - 2011-10-17 08:31:40 --> Config Class Initialized
DEBUG - 2011-10-17 08:31:40 --> Hooks Class Initialized
DEBUG - 2011-10-17 08:31:40 --> Utf8 Class Initialized
DEBUG - 2011-10-17 08:31:40 --> UTF-8 Support Enabled
DEBUG - 2011-10-17 08:31:40 --> URI Class Initialized
DEBUG - 2011-10-17 08:31:40 --> Router Class Initialized
ERROR - 2011-10-17 08:31:40 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-17 08:36:06 --> Config Class Initialized
DEBUG - 2011-10-17 08:36:06 --> Hooks Class Initialized
DEBUG - 2011-10-17 08:36:06 --> Utf8 Class Initialized
DEBUG - 2011-10-17 08:36:06 --> UTF-8 Support Enabled
DEBUG - 2011-10-17 08:36:06 --> URI Class Initialized
DEBUG - 2011-10-17 08:36:06 --> Router Class Initialized
DEBUG - 2011-10-17 08:36:06 --> Output Class Initialized
DEBUG - 2011-10-17 08:36:06 --> Input Class Initialized
DEBUG - 2011-10-17 08:36:06 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-17 08:36:06 --> Language Class Initialized
DEBUG - 2011-10-17 08:36:06 --> Loader Class Initialized
DEBUG - 2011-10-17 08:36:06 --> Controller Class Initialized
ERROR - 2011-10-17 08:36:06 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-10-17 08:36:06 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-10-17 08:36:06 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-17 08:36:06 --> Model Class Initialized
DEBUG - 2011-10-17 08:36:06 --> Model Class Initialized
DEBUG - 2011-10-17 08:36:06 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-17 08:36:06 --> Database Driver Class Initialized
DEBUG - 2011-10-17 08:36:06 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-17 08:36:06 --> Helper loaded: url_helper
DEBUG - 2011-10-17 08:36:06 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-17 08:36:06 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-17 08:36:06 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-17 08:36:06 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-17 08:36:06 --> Final output sent to browser
DEBUG - 2011-10-17 08:36:06 --> Total execution time: 0.0295
DEBUG - 2011-10-17 08:36:10 --> Config Class Initialized
DEBUG - 2011-10-17 08:36:10 --> Hooks Class Initialized
DEBUG - 2011-10-17 08:36:10 --> Utf8 Class Initialized
DEBUG - 2011-10-17 08:36:10 --> UTF-8 Support Enabled
DEBUG - 2011-10-17 08:36:10 --> URI Class Initialized
DEBUG - 2011-10-17 08:36:10 --> Router Class Initialized
DEBUG - 2011-10-17 08:36:10 --> Output Class Initialized
DEBUG - 2011-10-17 08:36:10 --> Input Class Initialized
DEBUG - 2011-10-17 08:36:10 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-17 08:36:10 --> Language Class Initialized
DEBUG - 2011-10-17 08:36:10 --> Loader Class Initialized
DEBUG - 2011-10-17 08:36:10 --> Controller Class Initialized
DEBUG - 2011-10-17 08:36:10 --> Model Class Initialized
DEBUG - 2011-10-17 08:36:10 --> Model Class Initialized
DEBUG - 2011-10-17 08:36:10 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-17 08:36:10 --> Database Driver Class Initialized
DEBUG - 2011-10-17 08:36:10 --> Final output sent to browser
DEBUG - 2011-10-17 08:36:10 --> Total execution time: 0.6791
DEBUG - 2011-10-17 08:47:13 --> Config Class Initialized
DEBUG - 2011-10-17 08:47:13 --> Hooks Class Initialized
DEBUG - 2011-10-17 08:47:13 --> Utf8 Class Initialized
DEBUG - 2011-10-17 08:47:13 --> UTF-8 Support Enabled
DEBUG - 2011-10-17 08:47:13 --> URI Class Initialized
DEBUG - 2011-10-17 08:47:13 --> Router Class Initialized
DEBUG - 2011-10-17 08:47:13 --> Output Class Initialized
DEBUG - 2011-10-17 08:47:13 --> Input Class Initialized
DEBUG - 2011-10-17 08:47:13 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-17 08:47:13 --> Language Class Initialized
DEBUG - 2011-10-17 08:47:13 --> Loader Class Initialized
DEBUG - 2011-10-17 08:47:13 --> Controller Class Initialized
DEBUG - 2011-10-17 08:47:13 --> Model Class Initialized
DEBUG - 2011-10-17 08:47:13 --> Model Class Initialized
DEBUG - 2011-10-17 08:47:13 --> Model Class Initialized
DEBUG - 2011-10-17 08:47:13 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-17 08:47:13 --> Database Driver Class Initialized
DEBUG - 2011-10-17 08:47:13 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-17 08:47:13 --> Helper loaded: url_helper
DEBUG - 2011-10-17 08:47:13 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-17 08:47:13 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-17 08:47:13 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-17 08:47:13 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-17 08:47:13 --> Final output sent to browser
DEBUG - 2011-10-17 08:47:13 --> Total execution time: 0.0714
DEBUG - 2011-10-17 08:47:36 --> Config Class Initialized
DEBUG - 2011-10-17 08:47:36 --> Hooks Class Initialized
DEBUG - 2011-10-17 08:47:36 --> Utf8 Class Initialized
DEBUG - 2011-10-17 08:47:36 --> UTF-8 Support Enabled
DEBUG - 2011-10-17 08:47:36 --> URI Class Initialized
DEBUG - 2011-10-17 08:47:36 --> Router Class Initialized
DEBUG - 2011-10-17 08:47:36 --> Output Class Initialized
DEBUG - 2011-10-17 08:47:36 --> Input Class Initialized
DEBUG - 2011-10-17 08:47:36 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-17 08:47:36 --> Language Class Initialized
DEBUG - 2011-10-17 08:47:36 --> Loader Class Initialized
DEBUG - 2011-10-17 08:47:36 --> Controller Class Initialized
DEBUG - 2011-10-17 08:47:36 --> Model Class Initialized
DEBUG - 2011-10-17 08:47:36 --> Model Class Initialized
DEBUG - 2011-10-17 08:47:36 --> Model Class Initialized
DEBUG - 2011-10-17 08:47:36 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-17 08:47:36 --> Database Driver Class Initialized
DEBUG - 2011-10-17 08:47:36 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-17 08:47:36 --> Helper loaded: url_helper
DEBUG - 2011-10-17 08:47:36 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-17 08:47:36 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-17 08:47:36 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-17 08:47:36 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-17 08:47:36 --> Final output sent to browser
DEBUG - 2011-10-17 08:47:36 --> Total execution time: 0.6368
DEBUG - 2011-10-17 08:47:41 --> Config Class Initialized
DEBUG - 2011-10-17 08:47:41 --> Hooks Class Initialized
DEBUG - 2011-10-17 08:47:41 --> Utf8 Class Initialized
DEBUG - 2011-10-17 08:47:41 --> UTF-8 Support Enabled
DEBUG - 2011-10-17 08:47:41 --> URI Class Initialized
DEBUG - 2011-10-17 08:47:41 --> Router Class Initialized
DEBUG - 2011-10-17 08:47:41 --> Output Class Initialized
DEBUG - 2011-10-17 08:47:41 --> Input Class Initialized
DEBUG - 2011-10-17 08:47:41 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-17 08:47:41 --> Language Class Initialized
DEBUG - 2011-10-17 08:47:41 --> Loader Class Initialized
DEBUG - 2011-10-17 08:47:41 --> Controller Class Initialized
DEBUG - 2011-10-17 08:47:41 --> Model Class Initialized
DEBUG - 2011-10-17 08:47:41 --> Model Class Initialized
DEBUG - 2011-10-17 08:47:41 --> Model Class Initialized
DEBUG - 2011-10-17 08:47:41 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-17 08:47:41 --> Database Driver Class Initialized
DEBUG - 2011-10-17 08:47:41 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-17 08:47:41 --> Helper loaded: url_helper
DEBUG - 2011-10-17 08:47:41 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-17 08:47:41 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-17 08:47:41 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-17 08:47:41 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-17 08:47:41 --> Final output sent to browser
DEBUG - 2011-10-17 08:47:41 --> Total execution time: 0.0866
DEBUG - 2011-10-17 08:48:58 --> Config Class Initialized
DEBUG - 2011-10-17 08:48:58 --> Hooks Class Initialized
DEBUG - 2011-10-17 08:48:58 --> Utf8 Class Initialized
DEBUG - 2011-10-17 08:48:58 --> UTF-8 Support Enabled
DEBUG - 2011-10-17 08:48:58 --> URI Class Initialized
DEBUG - 2011-10-17 08:48:58 --> Router Class Initialized
DEBUG - 2011-10-17 08:48:58 --> Output Class Initialized
DEBUG - 2011-10-17 08:48:58 --> Input Class Initialized
DEBUG - 2011-10-17 08:48:58 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-17 08:48:58 --> Language Class Initialized
DEBUG - 2011-10-17 08:48:58 --> Loader Class Initialized
DEBUG - 2011-10-17 08:48:58 --> Controller Class Initialized
DEBUG - 2011-10-17 08:48:58 --> Model Class Initialized
DEBUG - 2011-10-17 08:48:58 --> Model Class Initialized
DEBUG - 2011-10-17 08:48:58 --> Model Class Initialized
DEBUG - 2011-10-17 08:48:58 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-17 08:48:58 --> Database Driver Class Initialized
DEBUG - 2011-10-17 08:48:58 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-17 08:48:58 --> Helper loaded: url_helper
DEBUG - 2011-10-17 08:48:58 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-17 08:48:58 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-17 08:48:58 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-17 08:48:58 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-17 08:48:58 --> Final output sent to browser
DEBUG - 2011-10-17 08:48:58 --> Total execution time: 0.0495
DEBUG - 2011-10-17 08:49:06 --> Config Class Initialized
DEBUG - 2011-10-17 08:49:06 --> Hooks Class Initialized
DEBUG - 2011-10-17 08:49:06 --> Utf8 Class Initialized
DEBUG - 2011-10-17 08:49:06 --> UTF-8 Support Enabled
DEBUG - 2011-10-17 08:49:06 --> URI Class Initialized
DEBUG - 2011-10-17 08:49:06 --> Router Class Initialized
ERROR - 2011-10-17 08:49:06 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-17 08:49:41 --> Config Class Initialized
DEBUG - 2011-10-17 08:49:41 --> Hooks Class Initialized
DEBUG - 2011-10-17 08:49:41 --> Utf8 Class Initialized
DEBUG - 2011-10-17 08:49:41 --> UTF-8 Support Enabled
DEBUG - 2011-10-17 08:49:41 --> URI Class Initialized
DEBUG - 2011-10-17 08:49:41 --> Router Class Initialized
DEBUG - 2011-10-17 08:49:41 --> Output Class Initialized
DEBUG - 2011-10-17 08:49:41 --> Input Class Initialized
DEBUG - 2011-10-17 08:49:41 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-17 08:49:41 --> Language Class Initialized
DEBUG - 2011-10-17 08:49:41 --> Loader Class Initialized
DEBUG - 2011-10-17 08:49:41 --> Controller Class Initialized
DEBUG - 2011-10-17 08:49:41 --> Model Class Initialized
DEBUG - 2011-10-17 08:49:41 --> Model Class Initialized
DEBUG - 2011-10-17 08:49:41 --> Model Class Initialized
DEBUG - 2011-10-17 08:49:41 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-17 08:49:41 --> Database Driver Class Initialized
DEBUG - 2011-10-17 08:49:41 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-17 08:49:41 --> Helper loaded: url_helper
DEBUG - 2011-10-17 08:49:41 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-17 08:49:41 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-17 08:49:41 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-17 08:49:41 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-17 08:49:41 --> Final output sent to browser
DEBUG - 2011-10-17 08:49:41 --> Total execution time: 0.3862
DEBUG - 2011-10-17 08:49:55 --> Config Class Initialized
DEBUG - 2011-10-17 08:49:55 --> Hooks Class Initialized
DEBUG - 2011-10-17 08:49:55 --> Utf8 Class Initialized
DEBUG - 2011-10-17 08:49:55 --> UTF-8 Support Enabled
DEBUG - 2011-10-17 08:49:55 --> URI Class Initialized
DEBUG - 2011-10-17 08:49:55 --> Router Class Initialized
DEBUG - 2011-10-17 08:49:55 --> Output Class Initialized
DEBUG - 2011-10-17 08:49:55 --> Input Class Initialized
DEBUG - 2011-10-17 08:49:55 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-17 08:49:55 --> Language Class Initialized
DEBUG - 2011-10-17 08:49:55 --> Loader Class Initialized
DEBUG - 2011-10-17 08:49:55 --> Controller Class Initialized
DEBUG - 2011-10-17 08:49:55 --> Model Class Initialized
DEBUG - 2011-10-17 08:49:55 --> Model Class Initialized
DEBUG - 2011-10-17 08:49:55 --> Model Class Initialized
DEBUG - 2011-10-17 08:49:55 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-17 08:49:55 --> Database Driver Class Initialized
DEBUG - 2011-10-17 08:49:56 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-17 08:49:56 --> Helper loaded: url_helper
DEBUG - 2011-10-17 08:49:56 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-17 08:49:56 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-17 08:49:56 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-17 08:49:56 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-17 08:49:56 --> Final output sent to browser
DEBUG - 2011-10-17 08:49:56 --> Total execution time: 0.3958
DEBUG - 2011-10-17 08:50:21 --> Config Class Initialized
DEBUG - 2011-10-17 08:50:21 --> Hooks Class Initialized
DEBUG - 2011-10-17 08:50:21 --> Utf8 Class Initialized
DEBUG - 2011-10-17 08:50:21 --> UTF-8 Support Enabled
DEBUG - 2011-10-17 08:50:21 --> URI Class Initialized
DEBUG - 2011-10-17 08:50:21 --> Router Class Initialized
DEBUG - 2011-10-17 08:50:21 --> Output Class Initialized
DEBUG - 2011-10-17 08:50:21 --> Input Class Initialized
DEBUG - 2011-10-17 08:50:21 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-17 08:50:21 --> Language Class Initialized
DEBUG - 2011-10-17 08:50:21 --> Loader Class Initialized
DEBUG - 2011-10-17 08:50:21 --> Controller Class Initialized
DEBUG - 2011-10-17 08:50:21 --> Model Class Initialized
DEBUG - 2011-10-17 08:50:21 --> Model Class Initialized
DEBUG - 2011-10-17 08:50:21 --> Model Class Initialized
DEBUG - 2011-10-17 08:50:21 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-17 08:50:21 --> Database Driver Class Initialized
DEBUG - 2011-10-17 08:50:22 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-17 08:50:22 --> Helper loaded: url_helper
DEBUG - 2011-10-17 08:50:22 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-17 08:50:22 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-17 08:50:22 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-17 08:50:22 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-17 08:50:22 --> Final output sent to browser
DEBUG - 2011-10-17 08:50:22 --> Total execution time: 0.0534
DEBUG - 2011-10-17 08:50:29 --> Config Class Initialized
DEBUG - 2011-10-17 08:50:29 --> Hooks Class Initialized
DEBUG - 2011-10-17 08:50:29 --> Utf8 Class Initialized
DEBUG - 2011-10-17 08:50:29 --> UTF-8 Support Enabled
DEBUG - 2011-10-17 08:50:29 --> URI Class Initialized
DEBUG - 2011-10-17 08:50:29 --> Router Class Initialized
DEBUG - 2011-10-17 08:50:29 --> Output Class Initialized
DEBUG - 2011-10-17 08:50:29 --> Input Class Initialized
DEBUG - 2011-10-17 08:50:29 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-17 08:50:29 --> Language Class Initialized
DEBUG - 2011-10-17 08:50:29 --> Loader Class Initialized
DEBUG - 2011-10-17 08:50:29 --> Controller Class Initialized
DEBUG - 2011-10-17 08:50:29 --> Model Class Initialized
DEBUG - 2011-10-17 08:50:29 --> Model Class Initialized
DEBUG - 2011-10-17 08:50:29 --> Model Class Initialized
DEBUG - 2011-10-17 08:50:29 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-17 08:50:29 --> Database Driver Class Initialized
DEBUG - 2011-10-17 08:50:29 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-17 08:50:29 --> Helper loaded: url_helper
DEBUG - 2011-10-17 08:50:29 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-17 08:50:29 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-17 08:50:29 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-17 08:50:29 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-17 08:50:29 --> Final output sent to browser
DEBUG - 2011-10-17 08:50:29 --> Total execution time: 0.4982
DEBUG - 2011-10-17 08:50:42 --> Config Class Initialized
DEBUG - 2011-10-17 08:50:42 --> Hooks Class Initialized
DEBUG - 2011-10-17 08:50:42 --> Utf8 Class Initialized
DEBUG - 2011-10-17 08:50:42 --> UTF-8 Support Enabled
DEBUG - 2011-10-17 08:50:42 --> URI Class Initialized
DEBUG - 2011-10-17 08:50:42 --> Router Class Initialized
DEBUG - 2011-10-17 08:50:42 --> Output Class Initialized
DEBUG - 2011-10-17 08:50:42 --> Input Class Initialized
DEBUG - 2011-10-17 08:50:42 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-17 08:50:42 --> Language Class Initialized
DEBUG - 2011-10-17 08:50:42 --> Loader Class Initialized
DEBUG - 2011-10-17 08:50:42 --> Controller Class Initialized
DEBUG - 2011-10-17 08:50:42 --> Model Class Initialized
DEBUG - 2011-10-17 08:50:42 --> Model Class Initialized
DEBUG - 2011-10-17 08:50:42 --> Model Class Initialized
DEBUG - 2011-10-17 08:50:42 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-17 08:50:42 --> Database Driver Class Initialized
DEBUG - 2011-10-17 08:50:43 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-17 08:50:43 --> Helper loaded: url_helper
DEBUG - 2011-10-17 08:50:43 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-17 08:50:43 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-17 08:50:43 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-17 08:50:43 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-17 08:50:43 --> Final output sent to browser
DEBUG - 2011-10-17 08:50:43 --> Total execution time: 0.2302
DEBUG - 2011-10-17 08:50:58 --> Config Class Initialized
DEBUG - 2011-10-17 08:50:58 --> Hooks Class Initialized
DEBUG - 2011-10-17 08:50:58 --> Utf8 Class Initialized
DEBUG - 2011-10-17 08:50:58 --> UTF-8 Support Enabled
DEBUG - 2011-10-17 08:50:58 --> URI Class Initialized
DEBUG - 2011-10-17 08:50:58 --> Router Class Initialized
DEBUG - 2011-10-17 08:50:58 --> Output Class Initialized
DEBUG - 2011-10-17 08:50:58 --> Input Class Initialized
DEBUG - 2011-10-17 08:50:58 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-17 08:50:58 --> Language Class Initialized
DEBUG - 2011-10-17 08:50:58 --> Loader Class Initialized
DEBUG - 2011-10-17 08:50:58 --> Controller Class Initialized
DEBUG - 2011-10-17 08:50:58 --> Model Class Initialized
DEBUG - 2011-10-17 08:50:58 --> Model Class Initialized
DEBUG - 2011-10-17 08:50:58 --> Model Class Initialized
DEBUG - 2011-10-17 08:50:58 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-17 08:50:58 --> Database Driver Class Initialized
DEBUG - 2011-10-17 08:50:58 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-17 08:50:58 --> Helper loaded: url_helper
DEBUG - 2011-10-17 08:50:58 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-17 08:50:58 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-17 08:50:58 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-17 08:50:58 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-17 08:50:58 --> Final output sent to browser
DEBUG - 2011-10-17 08:50:58 --> Total execution time: 0.1983
DEBUG - 2011-10-17 08:51:13 --> Config Class Initialized
DEBUG - 2011-10-17 08:51:13 --> Hooks Class Initialized
DEBUG - 2011-10-17 08:51:13 --> Utf8 Class Initialized
DEBUG - 2011-10-17 08:51:13 --> UTF-8 Support Enabled
DEBUG - 2011-10-17 08:51:13 --> URI Class Initialized
DEBUG - 2011-10-17 08:51:13 --> Router Class Initialized
DEBUG - 2011-10-17 08:51:13 --> Output Class Initialized
DEBUG - 2011-10-17 08:51:13 --> Input Class Initialized
DEBUG - 2011-10-17 08:51:13 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-17 08:51:13 --> Language Class Initialized
DEBUG - 2011-10-17 08:51:13 --> Loader Class Initialized
DEBUG - 2011-10-17 08:51:13 --> Controller Class Initialized
DEBUG - 2011-10-17 08:51:13 --> Model Class Initialized
DEBUG - 2011-10-17 08:51:13 --> Model Class Initialized
DEBUG - 2011-10-17 08:51:13 --> Model Class Initialized
DEBUG - 2011-10-17 08:51:13 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-17 08:51:13 --> Database Driver Class Initialized
DEBUG - 2011-10-17 08:51:13 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-17 08:51:13 --> Helper loaded: url_helper
DEBUG - 2011-10-17 08:51:13 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-17 08:51:13 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-17 08:51:13 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-17 08:51:13 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-17 08:51:13 --> Final output sent to browser
DEBUG - 2011-10-17 08:51:13 --> Total execution time: 0.4042
DEBUG - 2011-10-17 08:51:26 --> Config Class Initialized
DEBUG - 2011-10-17 08:51:26 --> Hooks Class Initialized
DEBUG - 2011-10-17 08:51:26 --> Utf8 Class Initialized
DEBUG - 2011-10-17 08:51:26 --> UTF-8 Support Enabled
DEBUG - 2011-10-17 08:51:26 --> URI Class Initialized
DEBUG - 2011-10-17 08:51:26 --> Router Class Initialized
DEBUG - 2011-10-17 08:51:26 --> Output Class Initialized
DEBUG - 2011-10-17 08:51:26 --> Input Class Initialized
DEBUG - 2011-10-17 08:51:26 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-17 08:51:26 --> Language Class Initialized
DEBUG - 2011-10-17 08:51:26 --> Loader Class Initialized
DEBUG - 2011-10-17 08:51:26 --> Controller Class Initialized
DEBUG - 2011-10-17 08:51:26 --> Model Class Initialized
DEBUG - 2011-10-17 08:51:26 --> Model Class Initialized
DEBUG - 2011-10-17 08:51:26 --> Model Class Initialized
DEBUG - 2011-10-17 08:51:26 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-17 08:51:26 --> Database Driver Class Initialized
DEBUG - 2011-10-17 08:51:26 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-17 08:51:26 --> Helper loaded: url_helper
DEBUG - 2011-10-17 08:51:26 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-17 08:51:26 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-17 08:51:26 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-17 08:51:26 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-17 08:51:26 --> Final output sent to browser
DEBUG - 2011-10-17 08:51:26 --> Total execution time: 0.2067
DEBUG - 2011-10-17 08:51:37 --> Config Class Initialized
DEBUG - 2011-10-17 08:51:37 --> Hooks Class Initialized
DEBUG - 2011-10-17 08:51:37 --> Utf8 Class Initialized
DEBUG - 2011-10-17 08:51:37 --> UTF-8 Support Enabled
DEBUG - 2011-10-17 08:51:37 --> URI Class Initialized
DEBUG - 2011-10-17 08:51:37 --> Router Class Initialized
DEBUG - 2011-10-17 08:51:37 --> Output Class Initialized
DEBUG - 2011-10-17 08:51:37 --> Input Class Initialized
DEBUG - 2011-10-17 08:51:37 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-17 08:51:37 --> Language Class Initialized
DEBUG - 2011-10-17 08:51:37 --> Loader Class Initialized
DEBUG - 2011-10-17 08:51:37 --> Controller Class Initialized
DEBUG - 2011-10-17 08:51:37 --> Model Class Initialized
DEBUG - 2011-10-17 08:51:37 --> Model Class Initialized
DEBUG - 2011-10-17 08:51:37 --> Model Class Initialized
DEBUG - 2011-10-17 08:51:37 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-17 08:51:37 --> Database Driver Class Initialized
DEBUG - 2011-10-17 08:51:37 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-17 08:51:37 --> Helper loaded: url_helper
DEBUG - 2011-10-17 08:51:37 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-17 08:51:37 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-17 08:51:37 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-17 08:51:37 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-17 08:51:37 --> Final output sent to browser
DEBUG - 2011-10-17 08:51:37 --> Total execution time: 0.0586
DEBUG - 2011-10-17 08:51:51 --> Config Class Initialized
DEBUG - 2011-10-17 08:51:51 --> Hooks Class Initialized
DEBUG - 2011-10-17 08:51:51 --> Utf8 Class Initialized
DEBUG - 2011-10-17 08:51:51 --> UTF-8 Support Enabled
DEBUG - 2011-10-17 08:51:51 --> URI Class Initialized
DEBUG - 2011-10-17 08:51:51 --> Router Class Initialized
DEBUG - 2011-10-17 08:51:51 --> Output Class Initialized
DEBUG - 2011-10-17 08:51:51 --> Input Class Initialized
DEBUG - 2011-10-17 08:51:51 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-17 08:51:51 --> Language Class Initialized
DEBUG - 2011-10-17 08:51:51 --> Loader Class Initialized
DEBUG - 2011-10-17 08:51:51 --> Controller Class Initialized
DEBUG - 2011-10-17 08:51:51 --> Model Class Initialized
DEBUG - 2011-10-17 08:51:51 --> Model Class Initialized
DEBUG - 2011-10-17 08:51:51 --> Model Class Initialized
DEBUG - 2011-10-17 08:51:51 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-17 08:51:51 --> Database Driver Class Initialized
DEBUG - 2011-10-17 08:51:51 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-17 08:51:51 --> Helper loaded: url_helper
DEBUG - 2011-10-17 08:51:51 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-17 08:51:51 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-17 08:51:51 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-17 08:51:51 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-17 08:51:51 --> Final output sent to browser
DEBUG - 2011-10-17 08:51:51 --> Total execution time: 0.2041
DEBUG - 2011-10-17 08:51:59 --> Config Class Initialized
DEBUG - 2011-10-17 08:51:59 --> Hooks Class Initialized
DEBUG - 2011-10-17 08:51:59 --> Utf8 Class Initialized
DEBUG - 2011-10-17 08:51:59 --> UTF-8 Support Enabled
DEBUG - 2011-10-17 08:51:59 --> URI Class Initialized
DEBUG - 2011-10-17 08:51:59 --> Router Class Initialized
DEBUG - 2011-10-17 08:51:59 --> Output Class Initialized
DEBUG - 2011-10-17 08:51:59 --> Input Class Initialized
DEBUG - 2011-10-17 08:51:59 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-17 08:51:59 --> Language Class Initialized
DEBUG - 2011-10-17 08:51:59 --> Loader Class Initialized
DEBUG - 2011-10-17 08:51:59 --> Controller Class Initialized
DEBUG - 2011-10-17 08:51:59 --> Model Class Initialized
DEBUG - 2011-10-17 08:51:59 --> Model Class Initialized
DEBUG - 2011-10-17 08:51:59 --> Model Class Initialized
DEBUG - 2011-10-17 08:51:59 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-17 08:51:59 --> Database Driver Class Initialized
DEBUG - 2011-10-17 08:51:59 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-17 08:51:59 --> Helper loaded: url_helper
DEBUG - 2011-10-17 08:51:59 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-17 08:51:59 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-17 08:51:59 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-17 08:51:59 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-17 08:51:59 --> Final output sent to browser
DEBUG - 2011-10-17 08:51:59 --> Total execution time: 0.1995
DEBUG - 2011-10-17 09:19:17 --> Config Class Initialized
DEBUG - 2011-10-17 09:19:17 --> Hooks Class Initialized
DEBUG - 2011-10-17 09:19:17 --> Utf8 Class Initialized
DEBUG - 2011-10-17 09:19:17 --> UTF-8 Support Enabled
DEBUG - 2011-10-17 09:19:17 --> URI Class Initialized
DEBUG - 2011-10-17 09:19:17 --> Router Class Initialized
DEBUG - 2011-10-17 09:19:17 --> Output Class Initialized
DEBUG - 2011-10-17 09:19:17 --> Input Class Initialized
DEBUG - 2011-10-17 09:19:17 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-17 09:19:17 --> Language Class Initialized
DEBUG - 2011-10-17 09:19:17 --> Loader Class Initialized
DEBUG - 2011-10-17 09:19:17 --> Controller Class Initialized
DEBUG - 2011-10-17 09:19:17 --> Model Class Initialized
DEBUG - 2011-10-17 09:19:17 --> Model Class Initialized
DEBUG - 2011-10-17 09:19:17 --> Model Class Initialized
DEBUG - 2011-10-17 09:19:17 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-17 09:19:17 --> Database Driver Class Initialized
DEBUG - 2011-10-17 09:19:17 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-17 09:19:17 --> Helper loaded: url_helper
DEBUG - 2011-10-17 09:19:17 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-17 09:19:17 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-17 09:19:17 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-17 09:19:17 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-17 09:19:17 --> Final output sent to browser
DEBUG - 2011-10-17 09:19:17 --> Total execution time: 0.2382
DEBUG - 2011-10-17 09:19:18 --> Config Class Initialized
DEBUG - 2011-10-17 09:19:18 --> Hooks Class Initialized
DEBUG - 2011-10-17 09:19:18 --> Utf8 Class Initialized
DEBUG - 2011-10-17 09:19:18 --> UTF-8 Support Enabled
DEBUG - 2011-10-17 09:19:18 --> URI Class Initialized
DEBUG - 2011-10-17 09:19:18 --> Router Class Initialized
DEBUG - 2011-10-17 09:19:18 --> Output Class Initialized
DEBUG - 2011-10-17 09:19:18 --> Input Class Initialized
DEBUG - 2011-10-17 09:19:18 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-17 09:19:18 --> Language Class Initialized
DEBUG - 2011-10-17 09:19:18 --> Loader Class Initialized
DEBUG - 2011-10-17 09:19:18 --> Controller Class Initialized
ERROR - 2011-10-17 09:19:18 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-10-17 09:19:18 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-10-17 09:19:18 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-17 09:19:18 --> Model Class Initialized
DEBUG - 2011-10-17 09:19:18 --> Model Class Initialized
DEBUG - 2011-10-17 09:19:18 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-17 09:19:18 --> Database Driver Class Initialized
DEBUG - 2011-10-17 09:19:18 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-17 09:19:18 --> Helper loaded: url_helper
DEBUG - 2011-10-17 09:19:18 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-17 09:19:18 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-17 09:19:18 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-17 09:19:18 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-17 09:19:18 --> Final output sent to browser
DEBUG - 2011-10-17 09:19:18 --> Total execution time: 0.0281
DEBUG - 2011-10-17 09:19:19 --> Config Class Initialized
DEBUG - 2011-10-17 09:19:19 --> Hooks Class Initialized
DEBUG - 2011-10-17 09:19:19 --> Utf8 Class Initialized
DEBUG - 2011-10-17 09:19:19 --> UTF-8 Support Enabled
DEBUG - 2011-10-17 09:19:19 --> URI Class Initialized
DEBUG - 2011-10-17 09:19:19 --> Router Class Initialized
DEBUG - 2011-10-17 09:19:19 --> Output Class Initialized
DEBUG - 2011-10-17 09:19:19 --> Input Class Initialized
DEBUG - 2011-10-17 09:19:19 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-17 09:19:19 --> Language Class Initialized
DEBUG - 2011-10-17 09:19:19 --> Loader Class Initialized
DEBUG - 2011-10-17 09:19:19 --> Controller Class Initialized
DEBUG - 2011-10-17 09:19:19 --> Model Class Initialized
DEBUG - 2011-10-17 09:19:19 --> Model Class Initialized
DEBUG - 2011-10-17 09:19:19 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-17 09:19:19 --> Database Driver Class Initialized
DEBUG - 2011-10-17 09:19:20 --> Final output sent to browser
DEBUG - 2011-10-17 09:19:20 --> Total execution time: 0.6469
DEBUG - 2011-10-17 09:19:25 --> Config Class Initialized
DEBUG - 2011-10-17 09:19:25 --> Hooks Class Initialized
DEBUG - 2011-10-17 09:19:25 --> Utf8 Class Initialized
DEBUG - 2011-10-17 09:19:25 --> UTF-8 Support Enabled
DEBUG - 2011-10-17 09:19:25 --> URI Class Initialized
DEBUG - 2011-10-17 09:19:25 --> Router Class Initialized
ERROR - 2011-10-17 09:19:25 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-17 09:19:33 --> Config Class Initialized
DEBUG - 2011-10-17 09:19:33 --> Hooks Class Initialized
DEBUG - 2011-10-17 09:19:33 --> Utf8 Class Initialized
DEBUG - 2011-10-17 09:19:33 --> UTF-8 Support Enabled
DEBUG - 2011-10-17 09:19:33 --> URI Class Initialized
DEBUG - 2011-10-17 09:19:33 --> Router Class Initialized
DEBUG - 2011-10-17 09:19:33 --> Output Class Initialized
DEBUG - 2011-10-17 09:19:33 --> Input Class Initialized
DEBUG - 2011-10-17 09:19:33 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-17 09:19:33 --> Language Class Initialized
DEBUG - 2011-10-17 09:19:33 --> Loader Class Initialized
DEBUG - 2011-10-17 09:19:33 --> Controller Class Initialized
ERROR - 2011-10-17 09:19:33 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-10-17 09:19:33 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-10-17 09:19:33 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-17 09:19:33 --> Model Class Initialized
DEBUG - 2011-10-17 09:19:33 --> Model Class Initialized
DEBUG - 2011-10-17 09:19:33 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-17 09:19:33 --> Database Driver Class Initialized
DEBUG - 2011-10-17 09:19:33 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-17 09:19:33 --> Helper loaded: url_helper
DEBUG - 2011-10-17 09:19:33 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-17 09:19:33 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-17 09:19:33 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-17 09:19:33 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-17 09:19:33 --> Final output sent to browser
DEBUG - 2011-10-17 09:19:33 --> Total execution time: 0.1183
DEBUG - 2011-10-17 09:19:35 --> Config Class Initialized
DEBUG - 2011-10-17 09:19:35 --> Hooks Class Initialized
DEBUG - 2011-10-17 09:19:35 --> Utf8 Class Initialized
DEBUG - 2011-10-17 09:19:35 --> UTF-8 Support Enabled
DEBUG - 2011-10-17 09:19:35 --> URI Class Initialized
DEBUG - 2011-10-17 09:19:35 --> Router Class Initialized
DEBUG - 2011-10-17 09:19:35 --> Output Class Initialized
DEBUG - 2011-10-17 09:19:35 --> Input Class Initialized
DEBUG - 2011-10-17 09:19:35 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-17 09:19:35 --> Language Class Initialized
DEBUG - 2011-10-17 09:19:35 --> Loader Class Initialized
DEBUG - 2011-10-17 09:19:35 --> Controller Class Initialized
DEBUG - 2011-10-17 09:19:35 --> Model Class Initialized
DEBUG - 2011-10-17 09:19:35 --> Model Class Initialized
DEBUG - 2011-10-17 09:19:35 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-17 09:19:35 --> Database Driver Class Initialized
DEBUG - 2011-10-17 09:19:36 --> Final output sent to browser
DEBUG - 2011-10-17 09:19:36 --> Total execution time: 0.6775
DEBUG - 2011-10-17 09:20:40 --> Config Class Initialized
DEBUG - 2011-10-17 09:20:40 --> Hooks Class Initialized
DEBUG - 2011-10-17 09:20:40 --> Utf8 Class Initialized
DEBUG - 2011-10-17 09:20:40 --> UTF-8 Support Enabled
DEBUG - 2011-10-17 09:20:40 --> URI Class Initialized
DEBUG - 2011-10-17 09:20:40 --> Router Class Initialized
DEBUG - 2011-10-17 09:20:40 --> Output Class Initialized
DEBUG - 2011-10-17 09:20:40 --> Input Class Initialized
DEBUG - 2011-10-17 09:20:40 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-17 09:20:40 --> Language Class Initialized
DEBUG - 2011-10-17 09:20:40 --> Loader Class Initialized
DEBUG - 2011-10-17 09:20:40 --> Controller Class Initialized
ERROR - 2011-10-17 09:20:40 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-10-17 09:20:40 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-10-17 09:20:40 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-17 09:20:40 --> Model Class Initialized
DEBUG - 2011-10-17 09:20:40 --> Model Class Initialized
DEBUG - 2011-10-17 09:20:40 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-17 09:20:40 --> Database Driver Class Initialized
DEBUG - 2011-10-17 09:20:40 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-17 09:20:40 --> Helper loaded: url_helper
DEBUG - 2011-10-17 09:20:40 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-17 09:20:40 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-17 09:20:40 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-17 09:20:40 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-17 09:20:40 --> Final output sent to browser
DEBUG - 2011-10-17 09:20:40 --> Total execution time: 0.0307
DEBUG - 2011-10-17 09:20:41 --> Config Class Initialized
DEBUG - 2011-10-17 09:20:41 --> Hooks Class Initialized
DEBUG - 2011-10-17 09:20:41 --> Utf8 Class Initialized
DEBUG - 2011-10-17 09:20:41 --> UTF-8 Support Enabled
DEBUG - 2011-10-17 09:20:41 --> URI Class Initialized
DEBUG - 2011-10-17 09:20:41 --> Router Class Initialized
DEBUG - 2011-10-17 09:20:41 --> Output Class Initialized
DEBUG - 2011-10-17 09:20:41 --> Input Class Initialized
DEBUG - 2011-10-17 09:20:41 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-17 09:20:41 --> Language Class Initialized
DEBUG - 2011-10-17 09:20:41 --> Loader Class Initialized
DEBUG - 2011-10-17 09:20:41 --> Controller Class Initialized
DEBUG - 2011-10-17 09:20:41 --> Model Class Initialized
DEBUG - 2011-10-17 09:20:41 --> Model Class Initialized
DEBUG - 2011-10-17 09:20:41 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-17 09:20:41 --> Database Driver Class Initialized
DEBUG - 2011-10-17 09:20:41 --> Final output sent to browser
DEBUG - 2011-10-17 09:20:41 --> Total execution time: 0.7653
DEBUG - 2011-10-17 09:20:48 --> Config Class Initialized
DEBUG - 2011-10-17 09:20:48 --> Hooks Class Initialized
DEBUG - 2011-10-17 09:20:48 --> Utf8 Class Initialized
DEBUG - 2011-10-17 09:20:48 --> UTF-8 Support Enabled
DEBUG - 2011-10-17 09:20:48 --> URI Class Initialized
DEBUG - 2011-10-17 09:20:48 --> Router Class Initialized
DEBUG - 2011-10-17 09:20:48 --> Output Class Initialized
DEBUG - 2011-10-17 09:20:48 --> Input Class Initialized
DEBUG - 2011-10-17 09:20:48 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-17 09:20:48 --> Language Class Initialized
DEBUG - 2011-10-17 09:20:48 --> Loader Class Initialized
DEBUG - 2011-10-17 09:20:48 --> Controller Class Initialized
ERROR - 2011-10-17 09:20:48 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-10-17 09:20:48 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-10-17 09:20:48 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-17 09:20:48 --> Model Class Initialized
DEBUG - 2011-10-17 09:20:48 --> Model Class Initialized
DEBUG - 2011-10-17 09:20:48 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-17 09:20:48 --> Database Driver Class Initialized
DEBUG - 2011-10-17 09:20:48 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-17 09:20:48 --> Helper loaded: url_helper
DEBUG - 2011-10-17 09:20:48 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-17 09:20:48 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-17 09:20:48 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-17 09:20:48 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-17 09:20:48 --> Final output sent to browser
DEBUG - 2011-10-17 09:20:48 --> Total execution time: 0.0265
DEBUG - 2011-10-17 09:20:49 --> Config Class Initialized
DEBUG - 2011-10-17 09:20:49 --> Hooks Class Initialized
DEBUG - 2011-10-17 09:20:49 --> Utf8 Class Initialized
DEBUG - 2011-10-17 09:20:49 --> UTF-8 Support Enabled
DEBUG - 2011-10-17 09:20:49 --> URI Class Initialized
DEBUG - 2011-10-17 09:20:49 --> Router Class Initialized
DEBUG - 2011-10-17 09:20:49 --> Output Class Initialized
DEBUG - 2011-10-17 09:20:49 --> Input Class Initialized
DEBUG - 2011-10-17 09:20:49 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-17 09:20:49 --> Language Class Initialized
DEBUG - 2011-10-17 09:20:49 --> Loader Class Initialized
DEBUG - 2011-10-17 09:20:49 --> Controller Class Initialized
DEBUG - 2011-10-17 09:20:49 --> Model Class Initialized
DEBUG - 2011-10-17 09:20:49 --> Model Class Initialized
DEBUG - 2011-10-17 09:20:49 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-17 09:20:49 --> Database Driver Class Initialized
DEBUG - 2011-10-17 09:20:49 --> Final output sent to browser
DEBUG - 2011-10-17 09:20:49 --> Total execution time: 0.6069
DEBUG - 2011-10-17 09:21:00 --> Config Class Initialized
DEBUG - 2011-10-17 09:21:00 --> Hooks Class Initialized
DEBUG - 2011-10-17 09:21:00 --> Utf8 Class Initialized
DEBUG - 2011-10-17 09:21:00 --> UTF-8 Support Enabled
DEBUG - 2011-10-17 09:21:00 --> URI Class Initialized
DEBUG - 2011-10-17 09:21:00 --> Router Class Initialized
DEBUG - 2011-10-17 09:21:00 --> Output Class Initialized
DEBUG - 2011-10-17 09:21:00 --> Input Class Initialized
DEBUG - 2011-10-17 09:21:00 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-17 09:21:00 --> Language Class Initialized
DEBUG - 2011-10-17 09:21:00 --> Loader Class Initialized
DEBUG - 2011-10-17 09:21:00 --> Controller Class Initialized
ERROR - 2011-10-17 09:21:00 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-10-17 09:21:00 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-10-17 09:21:00 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-17 09:21:00 --> Model Class Initialized
DEBUG - 2011-10-17 09:21:00 --> Model Class Initialized
DEBUG - 2011-10-17 09:21:00 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-17 09:21:00 --> Database Driver Class Initialized
DEBUG - 2011-10-17 09:21:00 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-17 09:21:00 --> Helper loaded: url_helper
DEBUG - 2011-10-17 09:21:00 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-17 09:21:00 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-17 09:21:00 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-17 09:21:00 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-17 09:21:00 --> Final output sent to browser
DEBUG - 2011-10-17 09:21:00 --> Total execution time: 0.0331
DEBUG - 2011-10-17 09:21:01 --> Config Class Initialized
DEBUG - 2011-10-17 09:21:01 --> Hooks Class Initialized
DEBUG - 2011-10-17 09:21:01 --> Utf8 Class Initialized
DEBUG - 2011-10-17 09:21:01 --> UTF-8 Support Enabled
DEBUG - 2011-10-17 09:21:01 --> URI Class Initialized
DEBUG - 2011-10-17 09:21:01 --> Router Class Initialized
DEBUG - 2011-10-17 09:21:01 --> Output Class Initialized
DEBUG - 2011-10-17 09:21:01 --> Input Class Initialized
DEBUG - 2011-10-17 09:21:01 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-17 09:21:01 --> Language Class Initialized
DEBUG - 2011-10-17 09:21:01 --> Loader Class Initialized
DEBUG - 2011-10-17 09:21:01 --> Controller Class Initialized
DEBUG - 2011-10-17 09:21:01 --> Model Class Initialized
DEBUG - 2011-10-17 09:21:01 --> Model Class Initialized
DEBUG - 2011-10-17 09:21:01 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-17 09:21:01 --> Database Driver Class Initialized
DEBUG - 2011-10-17 09:21:01 --> Final output sent to browser
DEBUG - 2011-10-17 09:21:01 --> Total execution time: 0.5912
DEBUG - 2011-10-17 09:36:57 --> Config Class Initialized
DEBUG - 2011-10-17 09:36:57 --> Hooks Class Initialized
DEBUG - 2011-10-17 09:36:57 --> Utf8 Class Initialized
DEBUG - 2011-10-17 09:36:57 --> UTF-8 Support Enabled
DEBUG - 2011-10-17 09:36:57 --> URI Class Initialized
DEBUG - 2011-10-17 09:36:57 --> Router Class Initialized
DEBUG - 2011-10-17 09:36:57 --> Output Class Initialized
DEBUG - 2011-10-17 09:36:57 --> Input Class Initialized
DEBUG - 2011-10-17 09:36:57 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-17 09:36:57 --> Language Class Initialized
DEBUG - 2011-10-17 09:36:57 --> Loader Class Initialized
DEBUG - 2011-10-17 09:36:57 --> Controller Class Initialized
ERROR - 2011-10-17 09:36:57 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-10-17 09:36:57 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-10-17 09:36:57 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-17 09:36:57 --> Model Class Initialized
DEBUG - 2011-10-17 09:36:57 --> Model Class Initialized
DEBUG - 2011-10-17 09:36:57 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-17 09:36:57 --> Database Driver Class Initialized
DEBUG - 2011-10-17 09:36:57 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-17 09:36:57 --> Helper loaded: url_helper
DEBUG - 2011-10-17 09:36:57 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-17 09:36:57 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-17 09:36:57 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-17 09:36:57 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-17 09:36:57 --> Final output sent to browser
DEBUG - 2011-10-17 09:36:57 --> Total execution time: 0.0829
DEBUG - 2011-10-17 09:36:58 --> Config Class Initialized
DEBUG - 2011-10-17 09:36:58 --> Hooks Class Initialized
DEBUG - 2011-10-17 09:36:58 --> Utf8 Class Initialized
DEBUG - 2011-10-17 09:36:58 --> UTF-8 Support Enabled
DEBUG - 2011-10-17 09:36:58 --> URI Class Initialized
DEBUG - 2011-10-17 09:36:58 --> Router Class Initialized
DEBUG - 2011-10-17 09:36:58 --> Output Class Initialized
DEBUG - 2011-10-17 09:36:58 --> Input Class Initialized
DEBUG - 2011-10-17 09:36:58 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-17 09:36:58 --> Language Class Initialized
DEBUG - 2011-10-17 09:36:58 --> Loader Class Initialized
DEBUG - 2011-10-17 09:36:58 --> Controller Class Initialized
DEBUG - 2011-10-17 09:36:58 --> Model Class Initialized
DEBUG - 2011-10-17 09:36:58 --> Model Class Initialized
DEBUG - 2011-10-17 09:36:58 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-17 09:36:58 --> Database Driver Class Initialized
DEBUG - 2011-10-17 09:36:59 --> Final output sent to browser
DEBUG - 2011-10-17 09:36:59 --> Total execution time: 0.6323
DEBUG - 2011-10-17 09:37:00 --> Config Class Initialized
DEBUG - 2011-10-17 09:37:00 --> Hooks Class Initialized
DEBUG - 2011-10-17 09:37:00 --> Utf8 Class Initialized
DEBUG - 2011-10-17 09:37:00 --> UTF-8 Support Enabled
DEBUG - 2011-10-17 09:37:00 --> URI Class Initialized
DEBUG - 2011-10-17 09:37:00 --> Router Class Initialized
ERROR - 2011-10-17 09:37:00 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-17 09:37:15 --> Config Class Initialized
DEBUG - 2011-10-17 09:37:15 --> Hooks Class Initialized
DEBUG - 2011-10-17 09:37:15 --> Utf8 Class Initialized
DEBUG - 2011-10-17 09:37:15 --> UTF-8 Support Enabled
DEBUG - 2011-10-17 09:37:15 --> URI Class Initialized
DEBUG - 2011-10-17 09:37:15 --> Router Class Initialized
DEBUG - 2011-10-17 09:37:15 --> Output Class Initialized
DEBUG - 2011-10-17 09:37:15 --> Input Class Initialized
DEBUG - 2011-10-17 09:37:15 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-17 09:37:15 --> Language Class Initialized
DEBUG - 2011-10-17 09:37:15 --> Loader Class Initialized
DEBUG - 2011-10-17 09:37:15 --> Controller Class Initialized
ERROR - 2011-10-17 09:37:15 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-10-17 09:37:15 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-10-17 09:37:15 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-17 09:37:15 --> Model Class Initialized
DEBUG - 2011-10-17 09:37:15 --> Model Class Initialized
DEBUG - 2011-10-17 09:37:15 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-17 09:37:15 --> Database Driver Class Initialized
DEBUG - 2011-10-17 09:37:15 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-17 09:37:15 --> Helper loaded: url_helper
DEBUG - 2011-10-17 09:37:15 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-17 09:37:15 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-17 09:37:15 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-17 09:37:15 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-17 09:37:15 --> Final output sent to browser
DEBUG - 2011-10-17 09:37:15 --> Total execution time: 0.0265
DEBUG - 2011-10-17 09:37:16 --> Config Class Initialized
DEBUG - 2011-10-17 09:37:16 --> Hooks Class Initialized
DEBUG - 2011-10-17 09:37:16 --> Utf8 Class Initialized
DEBUG - 2011-10-17 09:37:16 --> UTF-8 Support Enabled
DEBUG - 2011-10-17 09:37:16 --> URI Class Initialized
DEBUG - 2011-10-17 09:37:16 --> Router Class Initialized
DEBUG - 2011-10-17 09:37:16 --> Output Class Initialized
DEBUG - 2011-10-17 09:37:16 --> Input Class Initialized
DEBUG - 2011-10-17 09:37:16 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-17 09:37:16 --> Language Class Initialized
DEBUG - 2011-10-17 09:37:16 --> Loader Class Initialized
DEBUG - 2011-10-17 09:37:16 --> Controller Class Initialized
DEBUG - 2011-10-17 09:37:16 --> Model Class Initialized
DEBUG - 2011-10-17 09:37:16 --> Model Class Initialized
DEBUG - 2011-10-17 09:37:16 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-17 09:37:16 --> Database Driver Class Initialized
DEBUG - 2011-10-17 09:37:16 --> Final output sent to browser
DEBUG - 2011-10-17 09:37:16 --> Total execution time: 0.5854
DEBUG - 2011-10-17 09:37:17 --> Config Class Initialized
DEBUG - 2011-10-17 09:37:17 --> Hooks Class Initialized
DEBUG - 2011-10-17 09:37:17 --> Utf8 Class Initialized
DEBUG - 2011-10-17 09:37:17 --> UTF-8 Support Enabled
DEBUG - 2011-10-17 09:37:17 --> URI Class Initialized
DEBUG - 2011-10-17 09:37:17 --> Router Class Initialized
ERROR - 2011-10-17 09:37:17 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-17 09:38:56 --> Config Class Initialized
DEBUG - 2011-10-17 09:38:56 --> Hooks Class Initialized
DEBUG - 2011-10-17 09:38:56 --> Utf8 Class Initialized
DEBUG - 2011-10-17 09:38:56 --> UTF-8 Support Enabled
DEBUG - 2011-10-17 09:38:56 --> URI Class Initialized
DEBUG - 2011-10-17 09:38:56 --> Router Class Initialized
DEBUG - 2011-10-17 09:38:56 --> Output Class Initialized
DEBUG - 2011-10-17 09:38:56 --> Input Class Initialized
DEBUG - 2011-10-17 09:38:56 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-17 09:38:56 --> Language Class Initialized
DEBUG - 2011-10-17 09:38:56 --> Loader Class Initialized
DEBUG - 2011-10-17 09:38:56 --> Controller Class Initialized
DEBUG - 2011-10-17 09:38:56 --> Model Class Initialized
DEBUG - 2011-10-17 09:38:56 --> Model Class Initialized
DEBUG - 2011-10-17 09:38:56 --> Model Class Initialized
DEBUG - 2011-10-17 09:38:56 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-17 09:38:56 --> Database Driver Class Initialized
DEBUG - 2011-10-17 09:38:56 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-17 09:38:56 --> Helper loaded: url_helper
DEBUG - 2011-10-17 09:38:56 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-17 09:38:56 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-17 09:38:56 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-17 09:38:56 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-17 09:38:56 --> Final output sent to browser
DEBUG - 2011-10-17 09:38:56 --> Total execution time: 0.3332
DEBUG - 2011-10-17 09:39:04 --> Config Class Initialized
DEBUG - 2011-10-17 09:39:04 --> Hooks Class Initialized
DEBUG - 2011-10-17 09:39:04 --> Utf8 Class Initialized
DEBUG - 2011-10-17 09:39:04 --> UTF-8 Support Enabled
DEBUG - 2011-10-17 09:39:04 --> URI Class Initialized
DEBUG - 2011-10-17 09:39:04 --> Router Class Initialized
ERROR - 2011-10-17 09:39:04 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-17 10:01:34 --> Config Class Initialized
DEBUG - 2011-10-17 10:01:34 --> Hooks Class Initialized
DEBUG - 2011-10-17 10:01:34 --> Utf8 Class Initialized
DEBUG - 2011-10-17 10:01:34 --> UTF-8 Support Enabled
DEBUG - 2011-10-17 10:01:34 --> URI Class Initialized
DEBUG - 2011-10-17 10:01:34 --> Router Class Initialized
DEBUG - 2011-10-17 10:01:34 --> Output Class Initialized
DEBUG - 2011-10-17 10:01:34 --> Input Class Initialized
DEBUG - 2011-10-17 10:01:34 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-17 10:01:34 --> Language Class Initialized
DEBUG - 2011-10-17 10:01:34 --> Loader Class Initialized
DEBUG - 2011-10-17 10:01:34 --> Controller Class Initialized
DEBUG - 2011-10-17 10:01:34 --> Model Class Initialized
DEBUG - 2011-10-17 10:01:34 --> Model Class Initialized
DEBUG - 2011-10-17 10:01:34 --> Model Class Initialized
DEBUG - 2011-10-17 10:01:34 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-17 10:01:34 --> Database Driver Class Initialized
DEBUG - 2011-10-17 10:01:35 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-17 10:01:35 --> Helper loaded: url_helper
DEBUG - 2011-10-17 10:01:35 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-17 10:01:35 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-17 10:01:35 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-17 10:01:35 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-17 10:01:35 --> Final output sent to browser
DEBUG - 2011-10-17 10:01:35 --> Total execution time: 0.9736
DEBUG - 2011-10-17 10:01:36 --> Config Class Initialized
DEBUG - 2011-10-17 10:01:36 --> Hooks Class Initialized
DEBUG - 2011-10-17 10:01:36 --> Utf8 Class Initialized
DEBUG - 2011-10-17 10:01:36 --> UTF-8 Support Enabled
DEBUG - 2011-10-17 10:01:36 --> URI Class Initialized
DEBUG - 2011-10-17 10:01:36 --> Router Class Initialized
ERROR - 2011-10-17 10:01:36 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-17 10:01:48 --> Config Class Initialized
DEBUG - 2011-10-17 10:01:48 --> Hooks Class Initialized
DEBUG - 2011-10-17 10:01:48 --> Utf8 Class Initialized
DEBUG - 2011-10-17 10:01:48 --> UTF-8 Support Enabled
DEBUG - 2011-10-17 10:01:48 --> URI Class Initialized
DEBUG - 2011-10-17 10:01:48 --> Router Class Initialized
DEBUG - 2011-10-17 10:01:48 --> Output Class Initialized
DEBUG - 2011-10-17 10:01:48 --> Input Class Initialized
DEBUG - 2011-10-17 10:01:48 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-17 10:01:48 --> Language Class Initialized
DEBUG - 2011-10-17 10:01:48 --> Loader Class Initialized
DEBUG - 2011-10-17 10:01:48 --> Controller Class Initialized
DEBUG - 2011-10-17 10:01:48 --> Model Class Initialized
DEBUG - 2011-10-17 10:01:48 --> Model Class Initialized
DEBUG - 2011-10-17 10:01:48 --> Model Class Initialized
DEBUG - 2011-10-17 10:01:48 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-17 10:01:48 --> Database Driver Class Initialized
DEBUG - 2011-10-17 10:01:49 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-17 10:01:49 --> Helper loaded: url_helper
DEBUG - 2011-10-17 10:01:49 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-17 10:01:49 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-17 10:01:49 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-17 10:01:49 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-17 10:01:49 --> Final output sent to browser
DEBUG - 2011-10-17 10:01:49 --> Total execution time: 0.8450
DEBUG - 2011-10-17 10:15:30 --> Config Class Initialized
DEBUG - 2011-10-17 10:15:30 --> Hooks Class Initialized
DEBUG - 2011-10-17 10:15:30 --> Utf8 Class Initialized
DEBUG - 2011-10-17 10:15:30 --> UTF-8 Support Enabled
DEBUG - 2011-10-17 10:15:30 --> URI Class Initialized
DEBUG - 2011-10-17 10:15:30 --> Router Class Initialized
DEBUG - 2011-10-17 10:15:30 --> Output Class Initialized
DEBUG - 2011-10-17 10:15:30 --> Input Class Initialized
DEBUG - 2011-10-17 10:15:30 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-17 10:15:30 --> Language Class Initialized
DEBUG - 2011-10-17 10:15:30 --> Loader Class Initialized
DEBUG - 2011-10-17 10:15:30 --> Controller Class Initialized
DEBUG - 2011-10-17 10:15:30 --> Model Class Initialized
DEBUG - 2011-10-17 10:15:30 --> Model Class Initialized
DEBUG - 2011-10-17 10:15:30 --> Model Class Initialized
DEBUG - 2011-10-17 10:15:30 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-17 10:15:30 --> Database Driver Class Initialized
DEBUG - 2011-10-17 10:15:31 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-17 10:15:31 --> Helper loaded: url_helper
DEBUG - 2011-10-17 10:15:31 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-17 10:15:31 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-17 10:15:31 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-17 10:15:31 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-17 10:15:31 --> Final output sent to browser
DEBUG - 2011-10-17 10:15:31 --> Total execution time: 0.0884
DEBUG - 2011-10-17 10:15:51 --> Config Class Initialized
DEBUG - 2011-10-17 10:15:51 --> Hooks Class Initialized
DEBUG - 2011-10-17 10:15:51 --> Utf8 Class Initialized
DEBUG - 2011-10-17 10:15:51 --> UTF-8 Support Enabled
DEBUG - 2011-10-17 10:15:51 --> URI Class Initialized
DEBUG - 2011-10-17 10:15:51 --> Router Class Initialized
ERROR - 2011-10-17 10:15:51 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-17 10:15:54 --> Config Class Initialized
DEBUG - 2011-10-17 10:15:54 --> Hooks Class Initialized
DEBUG - 2011-10-17 10:15:54 --> Utf8 Class Initialized
DEBUG - 2011-10-17 10:15:54 --> UTF-8 Support Enabled
DEBUG - 2011-10-17 10:15:54 --> URI Class Initialized
DEBUG - 2011-10-17 10:15:54 --> Router Class Initialized
ERROR - 2011-10-17 10:15:54 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-17 10:19:33 --> Config Class Initialized
DEBUG - 2011-10-17 10:19:33 --> Hooks Class Initialized
DEBUG - 2011-10-17 10:19:33 --> Utf8 Class Initialized
DEBUG - 2011-10-17 10:19:33 --> UTF-8 Support Enabled
DEBUG - 2011-10-17 10:19:33 --> URI Class Initialized
DEBUG - 2011-10-17 10:19:33 --> Router Class Initialized
DEBUG - 2011-10-17 10:19:33 --> Output Class Initialized
DEBUG - 2011-10-17 10:19:33 --> Input Class Initialized
DEBUG - 2011-10-17 10:19:33 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-17 10:19:33 --> Language Class Initialized
DEBUG - 2011-10-17 10:19:33 --> Loader Class Initialized
DEBUG - 2011-10-17 10:19:33 --> Controller Class Initialized
DEBUG - 2011-10-17 10:19:33 --> Model Class Initialized
DEBUG - 2011-10-17 10:19:33 --> Model Class Initialized
DEBUG - 2011-10-17 10:19:33 --> Model Class Initialized
DEBUG - 2011-10-17 10:19:33 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-17 10:19:33 --> Database Driver Class Initialized
DEBUG - 2011-10-17 10:19:33 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-17 10:19:33 --> Helper loaded: url_helper
DEBUG - 2011-10-17 10:19:33 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-17 10:19:33 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-17 10:19:33 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-17 10:19:33 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-17 10:19:33 --> Final output sent to browser
DEBUG - 2011-10-17 10:19:33 --> Total execution time: 0.3220
DEBUG - 2011-10-17 10:19:39 --> Config Class Initialized
DEBUG - 2011-10-17 10:19:39 --> Hooks Class Initialized
DEBUG - 2011-10-17 10:19:39 --> Utf8 Class Initialized
DEBUG - 2011-10-17 10:19:39 --> UTF-8 Support Enabled
DEBUG - 2011-10-17 10:19:39 --> URI Class Initialized
DEBUG - 2011-10-17 10:19:39 --> Router Class Initialized
ERROR - 2011-10-17 10:19:39 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-17 10:35:35 --> Config Class Initialized
DEBUG - 2011-10-17 10:35:35 --> Hooks Class Initialized
DEBUG - 2011-10-17 10:35:35 --> Utf8 Class Initialized
DEBUG - 2011-10-17 10:35:35 --> UTF-8 Support Enabled
DEBUG - 2011-10-17 10:35:35 --> URI Class Initialized
DEBUG - 2011-10-17 10:35:35 --> Router Class Initialized
DEBUG - 2011-10-17 10:35:35 --> Output Class Initialized
DEBUG - 2011-10-17 10:35:35 --> Input Class Initialized
DEBUG - 2011-10-17 10:35:35 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-17 10:35:35 --> Language Class Initialized
DEBUG - 2011-10-17 10:35:35 --> Loader Class Initialized
DEBUG - 2011-10-17 10:35:35 --> Controller Class Initialized
ERROR - 2011-10-17 10:35:35 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-10-17 10:35:35 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-10-17 10:35:35 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-17 10:35:35 --> Model Class Initialized
DEBUG - 2011-10-17 10:35:35 --> Model Class Initialized
DEBUG - 2011-10-17 10:35:35 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-17 10:35:35 --> Database Driver Class Initialized
DEBUG - 2011-10-17 10:35:35 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-17 10:35:35 --> Helper loaded: url_helper
DEBUG - 2011-10-17 10:35:35 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-17 10:35:35 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-17 10:35:35 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-17 10:35:35 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-17 10:35:35 --> Final output sent to browser
DEBUG - 2011-10-17 10:35:35 --> Total execution time: 0.0280
DEBUG - 2011-10-17 10:35:40 --> Config Class Initialized
DEBUG - 2011-10-17 10:35:40 --> Hooks Class Initialized
DEBUG - 2011-10-17 10:35:40 --> Utf8 Class Initialized
DEBUG - 2011-10-17 10:35:40 --> UTF-8 Support Enabled
DEBUG - 2011-10-17 10:35:40 --> URI Class Initialized
DEBUG - 2011-10-17 10:35:40 --> Router Class Initialized
DEBUG - 2011-10-17 10:35:40 --> Output Class Initialized
DEBUG - 2011-10-17 10:35:40 --> Input Class Initialized
DEBUG - 2011-10-17 10:35:40 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-17 10:35:40 --> Language Class Initialized
DEBUG - 2011-10-17 10:35:40 --> Loader Class Initialized
DEBUG - 2011-10-17 10:35:40 --> Controller Class Initialized
DEBUG - 2011-10-17 10:35:40 --> Model Class Initialized
DEBUG - 2011-10-17 10:35:40 --> Model Class Initialized
DEBUG - 2011-10-17 10:35:40 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-17 10:35:40 --> Database Driver Class Initialized
DEBUG - 2011-10-17 10:35:41 --> Final output sent to browser
DEBUG - 2011-10-17 10:35:41 --> Total execution time: 0.7443
DEBUG - 2011-10-17 10:35:45 --> Config Class Initialized
DEBUG - 2011-10-17 10:35:45 --> Hooks Class Initialized
DEBUG - 2011-10-17 10:35:45 --> Utf8 Class Initialized
DEBUG - 2011-10-17 10:35:45 --> UTF-8 Support Enabled
DEBUG - 2011-10-17 10:35:45 --> URI Class Initialized
DEBUG - 2011-10-17 10:35:45 --> Router Class Initialized
ERROR - 2011-10-17 10:35:45 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-17 10:36:40 --> Config Class Initialized
DEBUG - 2011-10-17 10:36:40 --> Hooks Class Initialized
DEBUG - 2011-10-17 10:36:40 --> Utf8 Class Initialized
DEBUG - 2011-10-17 10:36:40 --> UTF-8 Support Enabled
DEBUG - 2011-10-17 10:36:40 --> URI Class Initialized
DEBUG - 2011-10-17 10:36:40 --> Router Class Initialized
DEBUG - 2011-10-17 10:36:40 --> Output Class Initialized
DEBUG - 2011-10-17 10:36:40 --> Input Class Initialized
DEBUG - 2011-10-17 10:36:40 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-17 10:36:40 --> Language Class Initialized
DEBUG - 2011-10-17 10:36:40 --> Loader Class Initialized
DEBUG - 2011-10-17 10:36:40 --> Controller Class Initialized
ERROR - 2011-10-17 10:36:40 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-10-17 10:36:40 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-10-17 10:36:40 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-17 10:36:40 --> Model Class Initialized
DEBUG - 2011-10-17 10:36:40 --> Model Class Initialized
DEBUG - 2011-10-17 10:36:40 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-17 10:36:40 --> Database Driver Class Initialized
DEBUG - 2011-10-17 10:36:40 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-17 10:36:40 --> Helper loaded: url_helper
DEBUG - 2011-10-17 10:36:40 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-17 10:36:40 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-17 10:36:40 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-17 10:36:40 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-17 10:36:40 --> Final output sent to browser
DEBUG - 2011-10-17 10:36:40 --> Total execution time: 0.0328
DEBUG - 2011-10-17 10:36:41 --> Config Class Initialized
DEBUG - 2011-10-17 10:36:41 --> Hooks Class Initialized
DEBUG - 2011-10-17 10:36:41 --> Utf8 Class Initialized
DEBUG - 2011-10-17 10:36:41 --> UTF-8 Support Enabled
DEBUG - 2011-10-17 10:36:41 --> URI Class Initialized
DEBUG - 2011-10-17 10:36:41 --> Router Class Initialized
DEBUG - 2011-10-17 10:36:41 --> Output Class Initialized
DEBUG - 2011-10-17 10:36:41 --> Input Class Initialized
DEBUG - 2011-10-17 10:36:41 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-17 10:36:41 --> Language Class Initialized
DEBUG - 2011-10-17 10:36:41 --> Loader Class Initialized
DEBUG - 2011-10-17 10:36:41 --> Controller Class Initialized
DEBUG - 2011-10-17 10:36:41 --> Model Class Initialized
DEBUG - 2011-10-17 10:36:41 --> Model Class Initialized
DEBUG - 2011-10-17 10:36:41 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-17 10:36:41 --> Database Driver Class Initialized
DEBUG - 2011-10-17 10:36:42 --> Final output sent to browser
DEBUG - 2011-10-17 10:36:42 --> Total execution time: 0.6302
DEBUG - 2011-10-17 10:36:46 --> Config Class Initialized
DEBUG - 2011-10-17 10:36:46 --> Hooks Class Initialized
DEBUG - 2011-10-17 10:36:46 --> Utf8 Class Initialized
DEBUG - 2011-10-17 10:36:46 --> UTF-8 Support Enabled
DEBUG - 2011-10-17 10:36:46 --> URI Class Initialized
DEBUG - 2011-10-17 10:36:46 --> Router Class Initialized
ERROR - 2011-10-17 10:36:46 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-17 10:37:01 --> Config Class Initialized
DEBUG - 2011-10-17 10:37:01 --> Hooks Class Initialized
DEBUG - 2011-10-17 10:37:01 --> Utf8 Class Initialized
DEBUG - 2011-10-17 10:37:01 --> UTF-8 Support Enabled
DEBUG - 2011-10-17 10:37:01 --> URI Class Initialized
DEBUG - 2011-10-17 10:37:01 --> Router Class Initialized
DEBUG - 2011-10-17 10:37:01 --> Output Class Initialized
DEBUG - 2011-10-17 10:37:01 --> Input Class Initialized
DEBUG - 2011-10-17 10:37:01 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-17 10:37:01 --> Language Class Initialized
DEBUG - 2011-10-17 10:37:01 --> Loader Class Initialized
DEBUG - 2011-10-17 10:37:01 --> Controller Class Initialized
ERROR - 2011-10-17 10:37:01 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-10-17 10:37:01 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-10-17 10:37:01 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-17 10:37:01 --> Model Class Initialized
DEBUG - 2011-10-17 10:37:01 --> Model Class Initialized
DEBUG - 2011-10-17 10:37:01 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-17 10:37:01 --> Database Driver Class Initialized
DEBUG - 2011-10-17 10:37:01 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-17 10:37:01 --> Helper loaded: url_helper
DEBUG - 2011-10-17 10:37:01 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-17 10:37:01 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-17 10:37:01 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-17 10:37:01 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-17 10:37:01 --> Final output sent to browser
DEBUG - 2011-10-17 10:37:01 --> Total execution time: 0.0387
DEBUG - 2011-10-17 10:37:04 --> Config Class Initialized
DEBUG - 2011-10-17 10:37:04 --> Hooks Class Initialized
DEBUG - 2011-10-17 10:37:04 --> Utf8 Class Initialized
DEBUG - 2011-10-17 10:37:04 --> UTF-8 Support Enabled
DEBUG - 2011-10-17 10:37:04 --> URI Class Initialized
DEBUG - 2011-10-17 10:37:04 --> Router Class Initialized
DEBUG - 2011-10-17 10:37:04 --> Output Class Initialized
DEBUG - 2011-10-17 10:37:04 --> Input Class Initialized
DEBUG - 2011-10-17 10:37:04 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-17 10:37:04 --> Language Class Initialized
DEBUG - 2011-10-17 10:37:04 --> Loader Class Initialized
DEBUG - 2011-10-17 10:37:04 --> Controller Class Initialized
DEBUG - 2011-10-17 10:37:04 --> Model Class Initialized
DEBUG - 2011-10-17 10:37:04 --> Model Class Initialized
DEBUG - 2011-10-17 10:37:04 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-17 10:37:04 --> Database Driver Class Initialized
DEBUG - 2011-10-17 10:37:06 --> Final output sent to browser
DEBUG - 2011-10-17 10:37:06 --> Total execution time: 1.7648
DEBUG - 2011-10-17 10:37:13 --> Config Class Initialized
DEBUG - 2011-10-17 10:37:13 --> Hooks Class Initialized
DEBUG - 2011-10-17 10:37:13 --> Utf8 Class Initialized
DEBUG - 2011-10-17 10:37:13 --> UTF-8 Support Enabled
DEBUG - 2011-10-17 10:37:13 --> URI Class Initialized
DEBUG - 2011-10-17 10:37:13 --> Router Class Initialized
ERROR - 2011-10-17 10:37:13 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-17 10:37:51 --> Config Class Initialized
DEBUG - 2011-10-17 10:37:51 --> Hooks Class Initialized
DEBUG - 2011-10-17 10:37:51 --> Utf8 Class Initialized
DEBUG - 2011-10-17 10:37:51 --> UTF-8 Support Enabled
DEBUG - 2011-10-17 10:37:51 --> URI Class Initialized
DEBUG - 2011-10-17 10:37:51 --> Router Class Initialized
DEBUG - 2011-10-17 10:37:51 --> Output Class Initialized
DEBUG - 2011-10-17 10:37:51 --> Input Class Initialized
DEBUG - 2011-10-17 10:37:51 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-17 10:37:51 --> Language Class Initialized
DEBUG - 2011-10-17 10:37:51 --> Loader Class Initialized
DEBUG - 2011-10-17 10:37:51 --> Controller Class Initialized
ERROR - 2011-10-17 10:37:51 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-10-17 10:37:51 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-10-17 10:37:51 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-17 10:37:51 --> Model Class Initialized
DEBUG - 2011-10-17 10:37:51 --> Model Class Initialized
DEBUG - 2011-10-17 10:37:51 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-17 10:37:51 --> Database Driver Class Initialized
DEBUG - 2011-10-17 10:37:51 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-17 10:37:51 --> Helper loaded: url_helper
DEBUG - 2011-10-17 10:37:51 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-17 10:37:51 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-17 10:37:51 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-17 10:37:51 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-17 10:37:51 --> Final output sent to browser
DEBUG - 2011-10-17 10:37:51 --> Total execution time: 0.0307
DEBUG - 2011-10-17 10:37:53 --> Config Class Initialized
DEBUG - 2011-10-17 10:37:53 --> Hooks Class Initialized
DEBUG - 2011-10-17 10:37:53 --> Utf8 Class Initialized
DEBUG - 2011-10-17 10:37:53 --> UTF-8 Support Enabled
DEBUG - 2011-10-17 10:37:53 --> URI Class Initialized
DEBUG - 2011-10-17 10:37:53 --> Router Class Initialized
DEBUG - 2011-10-17 10:37:53 --> Output Class Initialized
DEBUG - 2011-10-17 10:37:53 --> Input Class Initialized
DEBUG - 2011-10-17 10:37:53 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-17 10:37:53 --> Language Class Initialized
DEBUG - 2011-10-17 10:37:53 --> Loader Class Initialized
DEBUG - 2011-10-17 10:37:53 --> Controller Class Initialized
DEBUG - 2011-10-17 10:37:53 --> Model Class Initialized
DEBUG - 2011-10-17 10:37:53 --> Model Class Initialized
DEBUG - 2011-10-17 10:37:53 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-17 10:37:53 --> Database Driver Class Initialized
DEBUG - 2011-10-17 10:37:54 --> Final output sent to browser
DEBUG - 2011-10-17 10:37:54 --> Total execution time: 0.7997
DEBUG - 2011-10-17 10:38:00 --> Config Class Initialized
DEBUG - 2011-10-17 10:38:00 --> Hooks Class Initialized
DEBUG - 2011-10-17 10:38:00 --> Utf8 Class Initialized
DEBUG - 2011-10-17 10:38:00 --> UTF-8 Support Enabled
DEBUG - 2011-10-17 10:38:00 --> URI Class Initialized
DEBUG - 2011-10-17 10:38:00 --> Router Class Initialized
ERROR - 2011-10-17 10:38:00 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-17 11:29:25 --> Config Class Initialized
DEBUG - 2011-10-17 11:29:25 --> Hooks Class Initialized
DEBUG - 2011-10-17 11:29:25 --> Utf8 Class Initialized
DEBUG - 2011-10-17 11:29:25 --> UTF-8 Support Enabled
DEBUG - 2011-10-17 11:29:25 --> URI Class Initialized
DEBUG - 2011-10-17 11:29:25 --> Router Class Initialized
DEBUG - 2011-10-17 11:29:25 --> Output Class Initialized
DEBUG - 2011-10-17 11:29:25 --> Input Class Initialized
DEBUG - 2011-10-17 11:29:25 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-17 11:29:25 --> Language Class Initialized
DEBUG - 2011-10-17 11:29:25 --> Loader Class Initialized
DEBUG - 2011-10-17 11:29:25 --> Controller Class Initialized
ERROR - 2011-10-17 11:29:25 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-10-17 11:29:25 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-10-17 11:29:25 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-17 11:29:25 --> Model Class Initialized
DEBUG - 2011-10-17 11:29:25 --> Model Class Initialized
DEBUG - 2011-10-17 11:29:25 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-17 11:29:25 --> Database Driver Class Initialized
DEBUG - 2011-10-17 11:29:25 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-17 11:29:25 --> Helper loaded: url_helper
DEBUG - 2011-10-17 11:29:25 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-17 11:29:25 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-17 11:29:25 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-17 11:29:25 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-17 11:29:25 --> Final output sent to browser
DEBUG - 2011-10-17 11:29:25 --> Total execution time: 0.0540
DEBUG - 2011-10-17 11:29:25 --> Config Class Initialized
DEBUG - 2011-10-17 11:29:25 --> Hooks Class Initialized
DEBUG - 2011-10-17 11:29:25 --> Utf8 Class Initialized
DEBUG - 2011-10-17 11:29:25 --> UTF-8 Support Enabled
DEBUG - 2011-10-17 11:29:25 --> URI Class Initialized
DEBUG - 2011-10-17 11:29:25 --> Router Class Initialized
DEBUG - 2011-10-17 11:29:25 --> Output Class Initialized
DEBUG - 2011-10-17 11:29:25 --> Input Class Initialized
DEBUG - 2011-10-17 11:29:25 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-17 11:29:25 --> Language Class Initialized
DEBUG - 2011-10-17 11:29:25 --> Loader Class Initialized
DEBUG - 2011-10-17 11:29:25 --> Controller Class Initialized
ERROR - 2011-10-17 11:29:25 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-10-17 11:29:25 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-10-17 11:29:25 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-17 11:29:25 --> Model Class Initialized
DEBUG - 2011-10-17 11:29:25 --> Model Class Initialized
DEBUG - 2011-10-17 11:29:25 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-17 11:29:25 --> Database Driver Class Initialized
DEBUG - 2011-10-17 11:29:25 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-17 11:29:25 --> Helper loaded: url_helper
DEBUG - 2011-10-17 11:29:25 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-17 11:29:25 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-17 11:29:25 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-17 11:29:25 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-17 11:29:25 --> Final output sent to browser
DEBUG - 2011-10-17 11:29:25 --> Total execution time: 0.0470
DEBUG - 2011-10-17 11:29:26 --> Config Class Initialized
DEBUG - 2011-10-17 11:29:26 --> Hooks Class Initialized
DEBUG - 2011-10-17 11:29:26 --> Utf8 Class Initialized
DEBUG - 2011-10-17 11:29:26 --> UTF-8 Support Enabled
DEBUG - 2011-10-17 11:29:26 --> URI Class Initialized
DEBUG - 2011-10-17 11:29:26 --> Router Class Initialized
DEBUG - 2011-10-17 11:29:26 --> Output Class Initialized
DEBUG - 2011-10-17 11:29:26 --> Input Class Initialized
DEBUG - 2011-10-17 11:29:26 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-17 11:29:26 --> Language Class Initialized
DEBUG - 2011-10-17 11:29:26 --> Loader Class Initialized
DEBUG - 2011-10-17 11:29:26 --> Controller Class Initialized
DEBUG - 2011-10-17 11:29:26 --> Model Class Initialized
DEBUG - 2011-10-17 11:29:26 --> Model Class Initialized
DEBUG - 2011-10-17 11:29:26 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-17 11:29:26 --> Database Driver Class Initialized
DEBUG - 2011-10-17 11:29:27 --> Final output sent to browser
DEBUG - 2011-10-17 11:29:27 --> Total execution time: 0.5692
DEBUG - 2011-10-17 11:29:28 --> Config Class Initialized
DEBUG - 2011-10-17 11:29:28 --> Hooks Class Initialized
DEBUG - 2011-10-17 11:29:28 --> Utf8 Class Initialized
DEBUG - 2011-10-17 11:29:28 --> UTF-8 Support Enabled
DEBUG - 2011-10-17 11:29:28 --> URI Class Initialized
DEBUG - 2011-10-17 11:29:28 --> Router Class Initialized
ERROR - 2011-10-17 11:29:28 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-17 11:29:29 --> Config Class Initialized
DEBUG - 2011-10-17 11:29:29 --> Hooks Class Initialized
DEBUG - 2011-10-17 11:29:29 --> Utf8 Class Initialized
DEBUG - 2011-10-17 11:29:29 --> UTF-8 Support Enabled
DEBUG - 2011-10-17 11:29:29 --> URI Class Initialized
DEBUG - 2011-10-17 11:29:29 --> Router Class Initialized
ERROR - 2011-10-17 11:29:29 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-17 11:42:57 --> Config Class Initialized
DEBUG - 2011-10-17 11:42:57 --> Hooks Class Initialized
DEBUG - 2011-10-17 11:42:57 --> Utf8 Class Initialized
DEBUG - 2011-10-17 11:42:57 --> UTF-8 Support Enabled
DEBUG - 2011-10-17 11:42:57 --> URI Class Initialized
DEBUG - 2011-10-17 11:42:57 --> Router Class Initialized
DEBUG - 2011-10-17 11:42:57 --> Output Class Initialized
DEBUG - 2011-10-17 11:42:57 --> Input Class Initialized
DEBUG - 2011-10-17 11:42:57 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-17 11:42:57 --> Language Class Initialized
DEBUG - 2011-10-17 11:42:57 --> Loader Class Initialized
DEBUG - 2011-10-17 11:42:57 --> Controller Class Initialized
DEBUG - 2011-10-17 11:42:57 --> Model Class Initialized
DEBUG - 2011-10-17 11:42:57 --> Model Class Initialized
DEBUG - 2011-10-17 11:42:57 --> Model Class Initialized
DEBUG - 2011-10-17 11:42:57 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-17 11:42:57 --> Database Driver Class Initialized
DEBUG - 2011-10-17 11:42:57 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-17 11:42:57 --> Helper loaded: url_helper
DEBUG - 2011-10-17 11:42:57 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-17 11:42:57 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-17 11:42:57 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-17 11:42:57 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-17 11:42:57 --> Final output sent to browser
DEBUG - 2011-10-17 11:42:57 --> Total execution time: 0.2827
DEBUG - 2011-10-17 11:43:00 --> Config Class Initialized
DEBUG - 2011-10-17 11:43:00 --> Hooks Class Initialized
DEBUG - 2011-10-17 11:43:00 --> Utf8 Class Initialized
DEBUG - 2011-10-17 11:43:00 --> UTF-8 Support Enabled
DEBUG - 2011-10-17 11:43:00 --> URI Class Initialized
DEBUG - 2011-10-17 11:43:00 --> Router Class Initialized
ERROR - 2011-10-17 11:43:00 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-17 11:43:00 --> Config Class Initialized
DEBUG - 2011-10-17 11:43:00 --> Hooks Class Initialized
DEBUG - 2011-10-17 11:43:00 --> Utf8 Class Initialized
DEBUG - 2011-10-17 11:43:00 --> UTF-8 Support Enabled
DEBUG - 2011-10-17 11:43:00 --> URI Class Initialized
DEBUG - 2011-10-17 11:43:00 --> Router Class Initialized
ERROR - 2011-10-17 11:43:00 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-17 11:43:00 --> Config Class Initialized
DEBUG - 2011-10-17 11:43:00 --> Hooks Class Initialized
DEBUG - 2011-10-17 11:43:00 --> Utf8 Class Initialized
DEBUG - 2011-10-17 11:43:00 --> UTF-8 Support Enabled
DEBUG - 2011-10-17 11:43:00 --> URI Class Initialized
DEBUG - 2011-10-17 11:43:00 --> Router Class Initialized
ERROR - 2011-10-17 11:43:00 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-17 11:43:11 --> Config Class Initialized
DEBUG - 2011-10-17 11:43:11 --> Hooks Class Initialized
DEBUG - 2011-10-17 11:43:11 --> Utf8 Class Initialized
DEBUG - 2011-10-17 11:43:11 --> UTF-8 Support Enabled
DEBUG - 2011-10-17 11:43:11 --> URI Class Initialized
DEBUG - 2011-10-17 11:43:11 --> Router Class Initialized
DEBUG - 2011-10-17 11:43:11 --> Output Class Initialized
DEBUG - 2011-10-17 11:43:12 --> Input Class Initialized
DEBUG - 2011-10-17 11:43:12 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-17 11:43:12 --> Language Class Initialized
DEBUG - 2011-10-17 11:43:12 --> Loader Class Initialized
DEBUG - 2011-10-17 11:43:12 --> Controller Class Initialized
DEBUG - 2011-10-17 11:43:12 --> Model Class Initialized
DEBUG - 2011-10-17 11:43:12 --> Model Class Initialized
DEBUG - 2011-10-17 11:43:12 --> Model Class Initialized
DEBUG - 2011-10-17 11:43:12 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-17 11:43:12 --> Database Driver Class Initialized
DEBUG - 2011-10-17 11:43:12 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-17 11:43:12 --> Helper loaded: url_helper
DEBUG - 2011-10-17 11:43:12 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-17 11:43:12 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-17 11:43:12 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-17 11:43:12 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-17 11:43:12 --> Final output sent to browser
DEBUG - 2011-10-17 11:43:12 --> Total execution time: 0.1950
DEBUG - 2011-10-17 11:43:26 --> Config Class Initialized
DEBUG - 2011-10-17 11:43:26 --> Hooks Class Initialized
DEBUG - 2011-10-17 11:43:26 --> Utf8 Class Initialized
DEBUG - 2011-10-17 11:43:26 --> UTF-8 Support Enabled
DEBUG - 2011-10-17 11:43:26 --> URI Class Initialized
DEBUG - 2011-10-17 11:43:26 --> Router Class Initialized
DEBUG - 2011-10-17 11:43:26 --> Output Class Initialized
DEBUG - 2011-10-17 11:43:26 --> Input Class Initialized
DEBUG - 2011-10-17 11:43:26 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-17 11:43:26 --> Language Class Initialized
DEBUG - 2011-10-17 11:43:26 --> Loader Class Initialized
DEBUG - 2011-10-17 11:43:26 --> Controller Class Initialized
DEBUG - 2011-10-17 11:43:26 --> Model Class Initialized
DEBUG - 2011-10-17 11:43:26 --> Model Class Initialized
DEBUG - 2011-10-17 11:43:26 --> Model Class Initialized
DEBUG - 2011-10-17 11:43:26 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-17 11:43:26 --> Database Driver Class Initialized
DEBUG - 2011-10-17 11:43:27 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-17 11:43:27 --> Helper loaded: url_helper
DEBUG - 2011-10-17 11:43:27 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-17 11:43:27 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-17 11:43:27 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-17 11:43:27 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-17 11:43:27 --> Final output sent to browser
DEBUG - 2011-10-17 11:43:27 --> Total execution time: 0.3969
DEBUG - 2011-10-17 11:43:28 --> Config Class Initialized
DEBUG - 2011-10-17 11:43:28 --> Hooks Class Initialized
DEBUG - 2011-10-17 11:43:28 --> Utf8 Class Initialized
DEBUG - 2011-10-17 11:43:28 --> UTF-8 Support Enabled
DEBUG - 2011-10-17 11:43:28 --> URI Class Initialized
DEBUG - 2011-10-17 11:43:28 --> Router Class Initialized
DEBUG - 2011-10-17 11:43:28 --> Output Class Initialized
DEBUG - 2011-10-17 11:43:28 --> Input Class Initialized
DEBUG - 2011-10-17 11:43:28 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-17 11:43:28 --> Language Class Initialized
DEBUG - 2011-10-17 11:43:28 --> Loader Class Initialized
DEBUG - 2011-10-17 11:43:28 --> Controller Class Initialized
DEBUG - 2011-10-17 11:43:28 --> Model Class Initialized
DEBUG - 2011-10-17 11:43:28 --> Model Class Initialized
DEBUG - 2011-10-17 11:43:28 --> Model Class Initialized
DEBUG - 2011-10-17 11:43:28 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-17 11:43:28 --> Database Driver Class Initialized
DEBUG - 2011-10-17 11:43:28 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-17 11:43:28 --> Helper loaded: url_helper
DEBUG - 2011-10-17 11:43:28 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-17 11:43:28 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-17 11:43:28 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-17 11:43:28 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-17 11:43:28 --> Final output sent to browser
DEBUG - 2011-10-17 11:43:28 --> Total execution time: 0.1129
DEBUG - 2011-10-17 11:43:54 --> Config Class Initialized
DEBUG - 2011-10-17 11:43:54 --> Hooks Class Initialized
DEBUG - 2011-10-17 11:43:54 --> Utf8 Class Initialized
DEBUG - 2011-10-17 11:43:54 --> UTF-8 Support Enabled
DEBUG - 2011-10-17 11:43:54 --> URI Class Initialized
DEBUG - 2011-10-17 11:43:54 --> Router Class Initialized
DEBUG - 2011-10-17 11:43:54 --> Output Class Initialized
DEBUG - 2011-10-17 11:43:54 --> Input Class Initialized
DEBUG - 2011-10-17 11:43:54 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-17 11:43:54 --> Language Class Initialized
DEBUG - 2011-10-17 11:43:54 --> Loader Class Initialized
DEBUG - 2011-10-17 11:43:54 --> Controller Class Initialized
DEBUG - 2011-10-17 11:43:54 --> Model Class Initialized
DEBUG - 2011-10-17 11:43:54 --> Model Class Initialized
DEBUG - 2011-10-17 11:43:54 --> Model Class Initialized
DEBUG - 2011-10-17 11:43:54 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-17 11:43:54 --> Database Driver Class Initialized
DEBUG - 2011-10-17 11:43:54 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-17 11:43:54 --> Helper loaded: url_helper
DEBUG - 2011-10-17 11:43:54 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-17 11:43:54 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-17 11:43:54 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-17 11:43:54 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-17 11:43:54 --> Final output sent to browser
DEBUG - 2011-10-17 11:43:54 --> Total execution time: 0.1422
DEBUG - 2011-10-17 11:44:04 --> Config Class Initialized
DEBUG - 2011-10-17 11:44:04 --> Hooks Class Initialized
DEBUG - 2011-10-17 11:44:04 --> Utf8 Class Initialized
DEBUG - 2011-10-17 11:44:04 --> UTF-8 Support Enabled
DEBUG - 2011-10-17 11:44:04 --> URI Class Initialized
DEBUG - 2011-10-17 11:44:04 --> Router Class Initialized
DEBUG - 2011-10-17 11:44:04 --> Output Class Initialized
DEBUG - 2011-10-17 11:44:04 --> Input Class Initialized
DEBUG - 2011-10-17 11:44:04 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-17 11:44:04 --> Language Class Initialized
DEBUG - 2011-10-17 11:44:04 --> Loader Class Initialized
DEBUG - 2011-10-17 11:44:04 --> Controller Class Initialized
ERROR - 2011-10-17 11:44:04 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-10-17 11:44:04 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-10-17 11:44:04 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-17 11:44:04 --> Model Class Initialized
DEBUG - 2011-10-17 11:44:04 --> Model Class Initialized
DEBUG - 2011-10-17 11:44:04 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-17 11:44:04 --> Database Driver Class Initialized
DEBUG - 2011-10-17 11:44:04 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-17 11:44:04 --> Helper loaded: url_helper
DEBUG - 2011-10-17 11:44:04 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-17 11:44:04 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-17 11:44:04 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-17 11:44:04 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-17 11:44:04 --> Final output sent to browser
DEBUG - 2011-10-17 11:44:04 --> Total execution time: 0.0990
DEBUG - 2011-10-17 11:44:05 --> Config Class Initialized
DEBUG - 2011-10-17 11:44:05 --> Hooks Class Initialized
DEBUG - 2011-10-17 11:44:05 --> Utf8 Class Initialized
DEBUG - 2011-10-17 11:44:05 --> UTF-8 Support Enabled
DEBUG - 2011-10-17 11:44:05 --> URI Class Initialized
DEBUG - 2011-10-17 11:44:05 --> Router Class Initialized
DEBUG - 2011-10-17 11:44:05 --> Output Class Initialized
DEBUG - 2011-10-17 11:44:05 --> Input Class Initialized
DEBUG - 2011-10-17 11:44:05 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-17 11:44:05 --> Language Class Initialized
DEBUG - 2011-10-17 11:44:05 --> Loader Class Initialized
DEBUG - 2011-10-17 11:44:05 --> Controller Class Initialized
DEBUG - 2011-10-17 11:44:05 --> Model Class Initialized
DEBUG - 2011-10-17 11:44:05 --> Model Class Initialized
DEBUG - 2011-10-17 11:44:05 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-17 11:44:05 --> Database Driver Class Initialized
DEBUG - 2011-10-17 11:44:06 --> Final output sent to browser
DEBUG - 2011-10-17 11:44:06 --> Total execution time: 0.6077
DEBUG - 2011-10-17 11:44:11 --> Config Class Initialized
DEBUG - 2011-10-17 11:44:11 --> Hooks Class Initialized
DEBUG - 2011-10-17 11:44:11 --> Utf8 Class Initialized
DEBUG - 2011-10-17 11:44:11 --> UTF-8 Support Enabled
DEBUG - 2011-10-17 11:44:11 --> URI Class Initialized
DEBUG - 2011-10-17 11:44:11 --> Router Class Initialized
DEBUG - 2011-10-17 11:44:11 --> Output Class Initialized
DEBUG - 2011-10-17 11:44:11 --> Input Class Initialized
DEBUG - 2011-10-17 11:44:11 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-17 11:44:11 --> Language Class Initialized
DEBUG - 2011-10-17 11:44:11 --> Loader Class Initialized
DEBUG - 2011-10-17 11:44:11 --> Controller Class Initialized
ERROR - 2011-10-17 11:44:11 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-10-17 11:44:11 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-10-17 11:44:11 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-17 11:44:11 --> Model Class Initialized
DEBUG - 2011-10-17 11:44:11 --> Model Class Initialized
DEBUG - 2011-10-17 11:44:11 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-17 11:44:11 --> Database Driver Class Initialized
DEBUG - 2011-10-17 11:44:11 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-17 11:44:11 --> Helper loaded: url_helper
DEBUG - 2011-10-17 11:44:11 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-17 11:44:11 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-17 11:44:11 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-17 11:44:11 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-17 11:44:11 --> Final output sent to browser
DEBUG - 2011-10-17 11:44:11 --> Total execution time: 0.0280
DEBUG - 2011-10-17 11:44:12 --> Config Class Initialized
DEBUG - 2011-10-17 11:44:12 --> Hooks Class Initialized
DEBUG - 2011-10-17 11:44:12 --> Utf8 Class Initialized
DEBUG - 2011-10-17 11:44:12 --> UTF-8 Support Enabled
DEBUG - 2011-10-17 11:44:12 --> URI Class Initialized
DEBUG - 2011-10-17 11:44:12 --> Router Class Initialized
DEBUG - 2011-10-17 11:44:12 --> Output Class Initialized
DEBUG - 2011-10-17 11:44:12 --> Input Class Initialized
DEBUG - 2011-10-17 11:44:12 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-17 11:44:12 --> Language Class Initialized
DEBUG - 2011-10-17 11:44:12 --> Loader Class Initialized
DEBUG - 2011-10-17 11:44:12 --> Controller Class Initialized
DEBUG - 2011-10-17 11:44:12 --> Model Class Initialized
DEBUG - 2011-10-17 11:44:12 --> Model Class Initialized
DEBUG - 2011-10-17 11:44:12 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-17 11:44:12 --> Database Driver Class Initialized
DEBUG - 2011-10-17 11:44:13 --> Final output sent to browser
DEBUG - 2011-10-17 11:44:13 --> Total execution time: 0.5632
DEBUG - 2011-10-17 12:19:54 --> Config Class Initialized
DEBUG - 2011-10-17 12:19:54 --> Hooks Class Initialized
DEBUG - 2011-10-17 12:19:54 --> Utf8 Class Initialized
DEBUG - 2011-10-17 12:19:54 --> UTF-8 Support Enabled
DEBUG - 2011-10-17 12:19:54 --> URI Class Initialized
DEBUG - 2011-10-17 12:19:54 --> Router Class Initialized
DEBUG - 2011-10-17 12:19:54 --> Output Class Initialized
DEBUG - 2011-10-17 12:19:54 --> Input Class Initialized
DEBUG - 2011-10-17 12:19:54 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-17 12:19:54 --> Language Class Initialized
DEBUG - 2011-10-17 12:19:54 --> Loader Class Initialized
DEBUG - 2011-10-17 12:19:54 --> Controller Class Initialized
DEBUG - 2011-10-17 12:19:54 --> Model Class Initialized
DEBUG - 2011-10-17 12:19:54 --> Model Class Initialized
DEBUG - 2011-10-17 12:19:54 --> Model Class Initialized
DEBUG - 2011-10-17 12:19:54 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-17 12:19:54 --> Database Driver Class Initialized
DEBUG - 2011-10-17 12:19:54 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-17 12:19:54 --> Helper loaded: url_helper
DEBUG - 2011-10-17 12:19:54 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-17 12:19:54 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-17 12:19:54 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-17 12:19:54 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-17 12:19:54 --> Final output sent to browser
DEBUG - 2011-10-17 12:19:54 --> Total execution time: 0.2934
DEBUG - 2011-10-17 12:19:55 --> Config Class Initialized
DEBUG - 2011-10-17 12:19:55 --> Hooks Class Initialized
DEBUG - 2011-10-17 12:19:55 --> Utf8 Class Initialized
DEBUG - 2011-10-17 12:19:55 --> UTF-8 Support Enabled
DEBUG - 2011-10-17 12:19:55 --> URI Class Initialized
DEBUG - 2011-10-17 12:19:55 --> Router Class Initialized
DEBUG - 2011-10-17 12:19:55 --> Output Class Initialized
DEBUG - 2011-10-17 12:19:55 --> Input Class Initialized
DEBUG - 2011-10-17 12:19:55 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-17 12:19:55 --> Language Class Initialized
DEBUG - 2011-10-17 12:19:55 --> Loader Class Initialized
DEBUG - 2011-10-17 12:19:55 --> Controller Class Initialized
ERROR - 2011-10-17 12:19:55 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-10-17 12:19:55 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-10-17 12:19:55 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-17 12:19:55 --> Model Class Initialized
DEBUG - 2011-10-17 12:19:55 --> Model Class Initialized
DEBUG - 2011-10-17 12:19:55 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-17 12:19:55 --> Database Driver Class Initialized
DEBUG - 2011-10-17 12:19:55 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-17 12:19:55 --> Helper loaded: url_helper
DEBUG - 2011-10-17 12:19:55 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-17 12:19:55 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-17 12:19:55 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-17 12:19:55 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-17 12:19:55 --> Final output sent to browser
DEBUG - 2011-10-17 12:19:55 --> Total execution time: 0.0674
DEBUG - 2011-10-17 12:21:05 --> Config Class Initialized
DEBUG - 2011-10-17 12:21:05 --> Hooks Class Initialized
DEBUG - 2011-10-17 12:21:05 --> Utf8 Class Initialized
DEBUG - 2011-10-17 12:21:05 --> UTF-8 Support Enabled
DEBUG - 2011-10-17 12:21:05 --> URI Class Initialized
DEBUG - 2011-10-17 12:21:05 --> Router Class Initialized
DEBUG - 2011-10-17 12:21:05 --> No URI present. Default controller set.
DEBUG - 2011-10-17 12:21:05 --> Output Class Initialized
DEBUG - 2011-10-17 12:21:05 --> Input Class Initialized
DEBUG - 2011-10-17 12:21:05 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-17 12:21:05 --> Language Class Initialized
DEBUG - 2011-10-17 12:21:05 --> Loader Class Initialized
DEBUG - 2011-10-17 12:21:05 --> Controller Class Initialized
DEBUG - 2011-10-17 12:21:05 --> File loaded: application/views/splash/main.php
DEBUG - 2011-10-17 12:21:05 --> Helper loaded: url_helper
DEBUG - 2011-10-17 12:21:05 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-17 12:21:05 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-17 12:21:05 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-17 12:21:05 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-17 12:21:05 --> Final output sent to browser
DEBUG - 2011-10-17 12:21:05 --> Total execution time: 0.0860
DEBUG - 2011-10-17 12:31:36 --> Config Class Initialized
DEBUG - 2011-10-17 12:31:36 --> Hooks Class Initialized
DEBUG - 2011-10-17 12:31:36 --> Utf8 Class Initialized
DEBUG - 2011-10-17 12:31:36 --> UTF-8 Support Enabled
DEBUG - 2011-10-17 12:31:36 --> URI Class Initialized
DEBUG - 2011-10-17 12:31:36 --> Router Class Initialized
DEBUG - 2011-10-17 12:31:36 --> Output Class Initialized
DEBUG - 2011-10-17 12:31:36 --> Input Class Initialized
DEBUG - 2011-10-17 12:31:36 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-17 12:31:36 --> Language Class Initialized
DEBUG - 2011-10-17 12:31:36 --> Loader Class Initialized
DEBUG - 2011-10-17 12:31:36 --> Controller Class Initialized
ERROR - 2011-10-17 12:31:36 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-10-17 12:31:36 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-10-17 12:31:36 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-17 12:31:36 --> Model Class Initialized
DEBUG - 2011-10-17 12:31:36 --> Model Class Initialized
DEBUG - 2011-10-17 12:31:36 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-17 12:31:36 --> Database Driver Class Initialized
DEBUG - 2011-10-17 12:31:36 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-17 12:31:36 --> Helper loaded: url_helper
DEBUG - 2011-10-17 12:31:36 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-17 12:31:36 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-17 12:31:36 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-17 12:31:36 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-17 12:31:36 --> Final output sent to browser
DEBUG - 2011-10-17 12:31:36 --> Total execution time: 0.0512
DEBUG - 2011-10-17 12:31:46 --> Config Class Initialized
DEBUG - 2011-10-17 12:31:46 --> Hooks Class Initialized
DEBUG - 2011-10-17 12:31:46 --> Utf8 Class Initialized
DEBUG - 2011-10-17 12:31:46 --> UTF-8 Support Enabled
DEBUG - 2011-10-17 12:31:46 --> URI Class Initialized
DEBUG - 2011-10-17 12:31:46 --> Router Class Initialized
DEBUG - 2011-10-17 12:31:46 --> Output Class Initialized
DEBUG - 2011-10-17 12:31:46 --> Input Class Initialized
DEBUG - 2011-10-17 12:31:46 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-17 12:31:46 --> Language Class Initialized
DEBUG - 2011-10-17 12:31:46 --> Loader Class Initialized
DEBUG - 2011-10-17 12:31:46 --> Controller Class Initialized
DEBUG - 2011-10-17 12:31:46 --> Model Class Initialized
DEBUG - 2011-10-17 12:31:46 --> Model Class Initialized
DEBUG - 2011-10-17 12:31:46 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-17 12:31:46 --> Database Driver Class Initialized
DEBUG - 2011-10-17 12:31:46 --> Final output sent to browser
DEBUG - 2011-10-17 12:31:46 --> Total execution time: 0.7922
DEBUG - 2011-10-17 12:31:53 --> Config Class Initialized
DEBUG - 2011-10-17 12:31:53 --> Hooks Class Initialized
DEBUG - 2011-10-17 12:31:53 --> Utf8 Class Initialized
DEBUG - 2011-10-17 12:31:53 --> UTF-8 Support Enabled
DEBUG - 2011-10-17 12:31:53 --> URI Class Initialized
DEBUG - 2011-10-17 12:31:53 --> Router Class Initialized
ERROR - 2011-10-17 12:31:53 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-17 12:31:58 --> Config Class Initialized
DEBUG - 2011-10-17 12:31:58 --> Hooks Class Initialized
DEBUG - 2011-10-17 12:31:58 --> Utf8 Class Initialized
DEBUG - 2011-10-17 12:31:58 --> UTF-8 Support Enabled
DEBUG - 2011-10-17 12:31:58 --> URI Class Initialized
DEBUG - 2011-10-17 12:31:58 --> Router Class Initialized
DEBUG - 2011-10-17 12:31:58 --> Output Class Initialized
DEBUG - 2011-10-17 12:31:58 --> Input Class Initialized
DEBUG - 2011-10-17 12:31:58 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-17 12:31:58 --> Language Class Initialized
DEBUG - 2011-10-17 12:31:58 --> Loader Class Initialized
DEBUG - 2011-10-17 12:31:58 --> Controller Class Initialized
ERROR - 2011-10-17 12:31:58 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-10-17 12:31:58 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-10-17 12:31:58 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-17 12:31:58 --> Model Class Initialized
DEBUG - 2011-10-17 12:31:58 --> Model Class Initialized
DEBUG - 2011-10-17 12:31:58 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-17 12:31:58 --> Database Driver Class Initialized
DEBUG - 2011-10-17 12:31:58 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-17 12:31:58 --> Helper loaded: url_helper
DEBUG - 2011-10-17 12:31:58 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-17 12:31:58 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-17 12:31:58 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-17 12:31:58 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-17 12:31:58 --> Final output sent to browser
DEBUG - 2011-10-17 12:31:58 --> Total execution time: 0.0293
DEBUG - 2011-10-17 12:32:03 --> Config Class Initialized
DEBUG - 2011-10-17 12:32:03 --> Hooks Class Initialized
DEBUG - 2011-10-17 12:32:03 --> Utf8 Class Initialized
DEBUG - 2011-10-17 12:32:03 --> UTF-8 Support Enabled
DEBUG - 2011-10-17 12:32:03 --> URI Class Initialized
DEBUG - 2011-10-17 12:32:03 --> Router Class Initialized
DEBUG - 2011-10-17 12:32:03 --> Output Class Initialized
DEBUG - 2011-10-17 12:32:03 --> Input Class Initialized
DEBUG - 2011-10-17 12:32:03 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-17 12:32:03 --> Language Class Initialized
DEBUG - 2011-10-17 12:32:03 --> Loader Class Initialized
DEBUG - 2011-10-17 12:32:03 --> Controller Class Initialized
DEBUG - 2011-10-17 12:32:03 --> Model Class Initialized
DEBUG - 2011-10-17 12:32:03 --> Model Class Initialized
DEBUG - 2011-10-17 12:32:03 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-17 12:32:03 --> Database Driver Class Initialized
DEBUG - 2011-10-17 12:32:04 --> Final output sent to browser
DEBUG - 2011-10-17 12:32:04 --> Total execution time: 0.9082
DEBUG - 2011-10-17 12:32:17 --> Config Class Initialized
DEBUG - 2011-10-17 12:32:17 --> Hooks Class Initialized
DEBUG - 2011-10-17 12:32:17 --> Utf8 Class Initialized
DEBUG - 2011-10-17 12:32:17 --> UTF-8 Support Enabled
DEBUG - 2011-10-17 12:32:17 --> URI Class Initialized
DEBUG - 2011-10-17 12:32:17 --> Router Class Initialized
DEBUG - 2011-10-17 12:32:17 --> Output Class Initialized
DEBUG - 2011-10-17 12:32:17 --> Input Class Initialized
DEBUG - 2011-10-17 12:32:17 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-17 12:32:17 --> Language Class Initialized
DEBUG - 2011-10-17 12:32:17 --> Loader Class Initialized
DEBUG - 2011-10-17 12:32:17 --> Controller Class Initialized
DEBUG - 2011-10-17 12:32:17 --> Model Class Initialized
DEBUG - 2011-10-17 12:32:17 --> Model Class Initialized
DEBUG - 2011-10-17 12:32:17 --> Model Class Initialized
DEBUG - 2011-10-17 12:32:17 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-17 12:32:17 --> Database Driver Class Initialized
DEBUG - 2011-10-17 12:32:17 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-17 12:32:17 --> Helper loaded: url_helper
DEBUG - 2011-10-17 12:32:17 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-17 12:32:17 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-17 12:32:17 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-17 12:32:17 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-17 12:32:17 --> Final output sent to browser
DEBUG - 2011-10-17 12:32:17 --> Total execution time: 0.0476
DEBUG - 2011-10-17 12:32:19 --> Config Class Initialized
DEBUG - 2011-10-17 12:32:19 --> Hooks Class Initialized
DEBUG - 2011-10-17 12:32:19 --> Utf8 Class Initialized
DEBUG - 2011-10-17 12:32:19 --> UTF-8 Support Enabled
DEBUG - 2011-10-17 12:32:19 --> URI Class Initialized
DEBUG - 2011-10-17 12:32:19 --> Router Class Initialized
ERROR - 2011-10-17 12:32:19 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-17 12:32:19 --> Config Class Initialized
DEBUG - 2011-10-17 12:32:19 --> Hooks Class Initialized
DEBUG - 2011-10-17 12:32:19 --> Utf8 Class Initialized
DEBUG - 2011-10-17 12:32:19 --> UTF-8 Support Enabled
DEBUG - 2011-10-17 12:32:19 --> URI Class Initialized
DEBUG - 2011-10-17 12:32:19 --> Router Class Initialized
ERROR - 2011-10-17 12:32:19 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-17 12:48:13 --> Config Class Initialized
DEBUG - 2011-10-17 12:48:13 --> Hooks Class Initialized
DEBUG - 2011-10-17 12:48:13 --> Utf8 Class Initialized
DEBUG - 2011-10-17 12:48:13 --> UTF-8 Support Enabled
DEBUG - 2011-10-17 12:48:13 --> URI Class Initialized
DEBUG - 2011-10-17 12:48:13 --> Router Class Initialized
DEBUG - 2011-10-17 12:48:13 --> Output Class Initialized
DEBUG - 2011-10-17 12:48:13 --> Input Class Initialized
DEBUG - 2011-10-17 12:48:13 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-17 12:48:13 --> Language Class Initialized
DEBUG - 2011-10-17 12:48:13 --> Loader Class Initialized
DEBUG - 2011-10-17 12:48:13 --> Controller Class Initialized
ERROR - 2011-10-17 12:48:13 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-10-17 12:48:13 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-10-17 12:48:13 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-17 12:48:13 --> Model Class Initialized
DEBUG - 2011-10-17 12:48:13 --> Model Class Initialized
DEBUG - 2011-10-17 12:48:13 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-17 12:48:13 --> Database Driver Class Initialized
DEBUG - 2011-10-17 12:48:13 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-17 12:48:13 --> Helper loaded: url_helper
DEBUG - 2011-10-17 12:48:13 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-17 12:48:13 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-17 12:48:13 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-17 12:48:13 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-17 12:48:13 --> Final output sent to browser
DEBUG - 2011-10-17 12:48:13 --> Total execution time: 0.0305
DEBUG - 2011-10-17 12:48:15 --> Config Class Initialized
DEBUG - 2011-10-17 12:48:15 --> Hooks Class Initialized
DEBUG - 2011-10-17 12:48:15 --> Utf8 Class Initialized
DEBUG - 2011-10-17 12:48:15 --> UTF-8 Support Enabled
DEBUG - 2011-10-17 12:48:15 --> URI Class Initialized
DEBUG - 2011-10-17 12:48:15 --> Router Class Initialized
DEBUG - 2011-10-17 12:48:15 --> Output Class Initialized
DEBUG - 2011-10-17 12:48:15 --> Input Class Initialized
DEBUG - 2011-10-17 12:48:15 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-17 12:48:15 --> Language Class Initialized
DEBUG - 2011-10-17 12:48:15 --> Loader Class Initialized
DEBUG - 2011-10-17 12:48:15 --> Controller Class Initialized
DEBUG - 2011-10-17 12:48:15 --> Model Class Initialized
DEBUG - 2011-10-17 12:48:15 --> Model Class Initialized
DEBUG - 2011-10-17 12:48:15 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-17 12:48:15 --> Database Driver Class Initialized
DEBUG - 2011-10-17 12:48:16 --> Final output sent to browser
DEBUG - 2011-10-17 12:48:16 --> Total execution time: 0.7120
DEBUG - 2011-10-17 12:48:22 --> Config Class Initialized
DEBUG - 2011-10-17 12:48:22 --> Hooks Class Initialized
DEBUG - 2011-10-17 12:48:22 --> Utf8 Class Initialized
DEBUG - 2011-10-17 12:48:22 --> UTF-8 Support Enabled
DEBUG - 2011-10-17 12:48:22 --> URI Class Initialized
DEBUG - 2011-10-17 12:48:22 --> Router Class Initialized
ERROR - 2011-10-17 12:48:22 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-17 12:48:29 --> Config Class Initialized
DEBUG - 2011-10-17 12:48:29 --> Hooks Class Initialized
DEBUG - 2011-10-17 12:48:29 --> Utf8 Class Initialized
DEBUG - 2011-10-17 12:48:29 --> UTF-8 Support Enabled
DEBUG - 2011-10-17 12:48:29 --> URI Class Initialized
DEBUG - 2011-10-17 12:48:29 --> Router Class Initialized
ERROR - 2011-10-17 12:48:29 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-17 12:57:00 --> Config Class Initialized
DEBUG - 2011-10-17 12:57:00 --> Hooks Class Initialized
DEBUG - 2011-10-17 12:57:00 --> Utf8 Class Initialized
DEBUG - 2011-10-17 12:57:00 --> UTF-8 Support Enabled
DEBUG - 2011-10-17 12:57:00 --> URI Class Initialized
DEBUG - 2011-10-17 12:57:00 --> Router Class Initialized
DEBUG - 2011-10-17 12:57:00 --> Output Class Initialized
DEBUG - 2011-10-17 12:57:00 --> Input Class Initialized
DEBUG - 2011-10-17 12:57:00 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-17 12:57:00 --> Language Class Initialized
DEBUG - 2011-10-17 12:57:00 --> Config Class Initialized
DEBUG - 2011-10-17 12:57:00 --> Hooks Class Initialized
DEBUG - 2011-10-17 12:57:00 --> Utf8 Class Initialized
DEBUG - 2011-10-17 12:57:00 --> UTF-8 Support Enabled
DEBUG - 2011-10-17 12:57:00 --> Loader Class Initialized
DEBUG - 2011-10-17 12:57:00 --> URI Class Initialized
DEBUG - 2011-10-17 12:57:00 --> Router Class Initialized
DEBUG - 2011-10-17 12:57:00 --> Output Class Initialized
DEBUG - 2011-10-17 12:57:00 --> Input Class Initialized
DEBUG - 2011-10-17 12:57:00 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-17 12:57:00 --> Language Class Initialized
DEBUG - 2011-10-17 12:57:00 --> Loader Class Initialized
DEBUG - 2011-10-17 12:57:00 --> Controller Class Initialized
DEBUG - 2011-10-17 12:57:00 --> Controller Class Initialized
DEBUG - 2011-10-17 12:57:00 --> Model Class Initialized
ERROR - 2011-10-17 12:57:00 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-10-17 12:57:00 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-10-17 12:57:00 --> Model Class Initialized
DEBUG - 2011-10-17 12:57:00 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-17 12:57:00 --> Model Class Initialized
DEBUG - 2011-10-17 12:57:00 --> Model Class Initialized
DEBUG - 2011-10-17 12:57:00 --> Model Class Initialized
DEBUG - 2011-10-17 12:57:00 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-17 12:57:00 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-17 12:57:00 --> Database Driver Class Initialized
DEBUG - 2011-10-17 12:57:00 --> Database Driver Class Initialized
DEBUG - 2011-10-17 12:57:00 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-17 12:57:00 --> Helper loaded: url_helper
DEBUG - 2011-10-17 12:57:00 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-17 12:57:00 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-17 12:57:00 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-17 12:57:00 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-17 12:57:00 --> Final output sent to browser
DEBUG - 2011-10-17 12:57:00 --> Total execution time: 0.0558
DEBUG - 2011-10-17 12:57:01 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-17 12:57:01 --> Helper loaded: url_helper
DEBUG - 2011-10-17 12:57:01 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-17 12:57:01 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-17 12:57:01 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-17 12:57:01 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-17 12:57:01 --> Final output sent to browser
DEBUG - 2011-10-17 12:57:01 --> Total execution time: 0.4215
DEBUG - 2011-10-17 13:04:38 --> Config Class Initialized
DEBUG - 2011-10-17 13:04:38 --> Hooks Class Initialized
DEBUG - 2011-10-17 13:04:38 --> Utf8 Class Initialized
DEBUG - 2011-10-17 13:04:38 --> UTF-8 Support Enabled
DEBUG - 2011-10-17 13:04:38 --> URI Class Initialized
DEBUG - 2011-10-17 13:04:38 --> Router Class Initialized
DEBUG - 2011-10-17 13:04:38 --> Output Class Initialized
DEBUG - 2011-10-17 13:04:38 --> Input Class Initialized
DEBUG - 2011-10-17 13:04:38 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-17 13:04:38 --> Language Class Initialized
DEBUG - 2011-10-17 13:04:38 --> Loader Class Initialized
DEBUG - 2011-10-17 13:04:38 --> Controller Class Initialized
ERROR - 2011-10-17 13:04:38 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-10-17 13:04:38 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-10-17 13:04:38 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-17 13:04:38 --> Model Class Initialized
DEBUG - 2011-10-17 13:04:38 --> Model Class Initialized
DEBUG - 2011-10-17 13:04:38 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-17 13:04:38 --> Database Driver Class Initialized
DEBUG - 2011-10-17 13:04:38 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-17 13:04:38 --> Helper loaded: url_helper
DEBUG - 2011-10-17 13:04:38 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-17 13:04:38 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-17 13:04:38 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-17 13:04:38 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-17 13:04:38 --> Final output sent to browser
DEBUG - 2011-10-17 13:04:38 --> Total execution time: 0.0331
DEBUG - 2011-10-17 13:04:40 --> Config Class Initialized
DEBUG - 2011-10-17 13:04:40 --> Hooks Class Initialized
DEBUG - 2011-10-17 13:04:40 --> Utf8 Class Initialized
DEBUG - 2011-10-17 13:04:40 --> UTF-8 Support Enabled
DEBUG - 2011-10-17 13:04:40 --> URI Class Initialized
DEBUG - 2011-10-17 13:04:40 --> Router Class Initialized
DEBUG - 2011-10-17 13:04:40 --> Output Class Initialized
DEBUG - 2011-10-17 13:04:40 --> Input Class Initialized
DEBUG - 2011-10-17 13:04:40 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-17 13:04:40 --> Language Class Initialized
DEBUG - 2011-10-17 13:04:40 --> Loader Class Initialized
DEBUG - 2011-10-17 13:04:40 --> Controller Class Initialized
DEBUG - 2011-10-17 13:04:40 --> Model Class Initialized
DEBUG - 2011-10-17 13:04:40 --> Model Class Initialized
DEBUG - 2011-10-17 13:04:40 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-17 13:04:40 --> Database Driver Class Initialized
DEBUG - 2011-10-17 13:04:40 --> Final output sent to browser
DEBUG - 2011-10-17 13:04:40 --> Total execution time: 0.7037
DEBUG - 2011-10-17 13:06:11 --> Config Class Initialized
DEBUG - 2011-10-17 13:06:11 --> Hooks Class Initialized
DEBUG - 2011-10-17 13:06:11 --> Utf8 Class Initialized
DEBUG - 2011-10-17 13:06:11 --> UTF-8 Support Enabled
DEBUG - 2011-10-17 13:06:11 --> URI Class Initialized
DEBUG - 2011-10-17 13:06:11 --> Router Class Initialized
DEBUG - 2011-10-17 13:06:11 --> Output Class Initialized
DEBUG - 2011-10-17 13:06:11 --> Input Class Initialized
DEBUG - 2011-10-17 13:06:11 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-17 13:06:11 --> Language Class Initialized
DEBUG - 2011-10-17 13:06:11 --> Loader Class Initialized
DEBUG - 2011-10-17 13:06:11 --> Controller Class Initialized
ERROR - 2011-10-17 13:06:11 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-10-17 13:06:11 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-10-17 13:06:11 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-17 13:06:11 --> Model Class Initialized
DEBUG - 2011-10-17 13:06:11 --> Model Class Initialized
DEBUG - 2011-10-17 13:06:11 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-17 13:06:11 --> Database Driver Class Initialized
DEBUG - 2011-10-17 13:06:11 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-17 13:06:11 --> Helper loaded: url_helper
DEBUG - 2011-10-17 13:06:11 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-17 13:06:11 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-17 13:06:11 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-17 13:06:11 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-17 13:06:11 --> Final output sent to browser
DEBUG - 2011-10-17 13:06:11 --> Total execution time: 0.0274
DEBUG - 2011-10-17 13:06:13 --> Config Class Initialized
DEBUG - 2011-10-17 13:06:13 --> Hooks Class Initialized
DEBUG - 2011-10-17 13:06:13 --> Utf8 Class Initialized
DEBUG - 2011-10-17 13:06:13 --> UTF-8 Support Enabled
DEBUG - 2011-10-17 13:06:13 --> URI Class Initialized
DEBUG - 2011-10-17 13:06:13 --> Router Class Initialized
DEBUG - 2011-10-17 13:06:13 --> Output Class Initialized
DEBUG - 2011-10-17 13:06:13 --> Input Class Initialized
DEBUG - 2011-10-17 13:06:13 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-17 13:06:13 --> Language Class Initialized
DEBUG - 2011-10-17 13:06:13 --> Loader Class Initialized
DEBUG - 2011-10-17 13:06:13 --> Controller Class Initialized
DEBUG - 2011-10-17 13:06:13 --> Model Class Initialized
DEBUG - 2011-10-17 13:06:13 --> Model Class Initialized
DEBUG - 2011-10-17 13:06:13 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-17 13:06:13 --> Database Driver Class Initialized
DEBUG - 2011-10-17 13:06:13 --> Final output sent to browser
DEBUG - 2011-10-17 13:06:13 --> Total execution time: 0.5276
DEBUG - 2011-10-17 13:23:15 --> Config Class Initialized
DEBUG - 2011-10-17 13:23:15 --> Hooks Class Initialized
DEBUG - 2011-10-17 13:23:15 --> Utf8 Class Initialized
DEBUG - 2011-10-17 13:23:15 --> UTF-8 Support Enabled
DEBUG - 2011-10-17 13:23:15 --> URI Class Initialized
DEBUG - 2011-10-17 13:23:15 --> Router Class Initialized
DEBUG - 2011-10-17 13:23:15 --> Output Class Initialized
DEBUG - 2011-10-17 13:23:15 --> Input Class Initialized
DEBUG - 2011-10-17 13:23:15 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-17 13:23:15 --> Language Class Initialized
DEBUG - 2011-10-17 13:23:15 --> Loader Class Initialized
DEBUG - 2011-10-17 13:23:15 --> Controller Class Initialized
DEBUG - 2011-10-17 13:23:15 --> Config Class Initialized
DEBUG - 2011-10-17 13:23:15 --> Hooks Class Initialized
DEBUG - 2011-10-17 13:23:15 --> Utf8 Class Initialized
DEBUG - 2011-10-17 13:23:15 --> UTF-8 Support Enabled
DEBUG - 2011-10-17 13:23:15 --> URI Class Initialized
DEBUG - 2011-10-17 13:23:15 --> Router Class Initialized
DEBUG - 2011-10-17 13:23:15 --> Output Class Initialized
DEBUG - 2011-10-17 13:23:15 --> Input Class Initialized
DEBUG - 2011-10-17 13:23:15 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-17 13:23:15 --> Language Class Initialized
ERROR - 2011-10-17 13:23:15 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-10-17 13:23:15 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-10-17 13:23:15 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-17 13:23:15 --> Model Class Initialized
DEBUG - 2011-10-17 13:23:15 --> Model Class Initialized
DEBUG - 2011-10-17 13:23:15 --> Loader Class Initialized
DEBUG - 2011-10-17 13:23:15 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-17 13:23:15 --> Controller Class Initialized
DEBUG - 2011-10-17 13:23:15 --> Model Class Initialized
DEBUG - 2011-10-17 13:23:15 --> Model Class Initialized
DEBUG - 2011-10-17 13:23:15 --> Model Class Initialized
DEBUG - 2011-10-17 13:23:15 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-17 13:23:15 --> Database Driver Class Initialized
DEBUG - 2011-10-17 13:23:15 --> Database Driver Class Initialized
DEBUG - 2011-10-17 13:23:15 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-17 13:23:15 --> Helper loaded: url_helper
DEBUG - 2011-10-17 13:23:15 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-17 13:23:15 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-17 13:23:15 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-17 13:23:15 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-17 13:23:15 --> Final output sent to browser
DEBUG - 2011-10-17 13:23:15 --> Total execution time: 0.0456
DEBUG - 2011-10-17 13:23:15 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-17 13:23:15 --> Helper loaded: url_helper
DEBUG - 2011-10-17 13:23:15 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-17 13:23:15 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-17 13:23:15 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-17 13:23:15 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-17 13:23:15 --> Final output sent to browser
DEBUG - 2011-10-17 13:23:15 --> Total execution time: 0.2826
DEBUG - 2011-10-17 13:32:17 --> Config Class Initialized
DEBUG - 2011-10-17 13:32:17 --> Hooks Class Initialized
DEBUG - 2011-10-17 13:32:17 --> Utf8 Class Initialized
DEBUG - 2011-10-17 13:32:17 --> UTF-8 Support Enabled
DEBUG - 2011-10-17 13:32:17 --> URI Class Initialized
DEBUG - 2011-10-17 13:32:17 --> Router Class Initialized
DEBUG - 2011-10-17 13:32:17 --> Output Class Initialized
DEBUG - 2011-10-17 13:32:17 --> Input Class Initialized
DEBUG - 2011-10-17 13:32:17 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-17 13:32:17 --> Language Class Initialized
DEBUG - 2011-10-17 13:32:17 --> Loader Class Initialized
DEBUG - 2011-10-17 13:32:17 --> Controller Class Initialized
DEBUG - 2011-10-17 13:32:17 --> Model Class Initialized
DEBUG - 2011-10-17 13:32:17 --> Model Class Initialized
DEBUG - 2011-10-17 13:32:17 --> Model Class Initialized
DEBUG - 2011-10-17 13:32:17 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-17 13:32:17 --> Database Driver Class Initialized
DEBUG - 2011-10-17 13:32:17 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-17 13:32:17 --> Helper loaded: url_helper
DEBUG - 2011-10-17 13:32:17 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-17 13:32:17 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-17 13:32:17 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-17 13:32:17 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-17 13:32:17 --> Final output sent to browser
DEBUG - 2011-10-17 13:32:17 --> Total execution time: 0.0588
DEBUG - 2011-10-17 13:32:19 --> Config Class Initialized
DEBUG - 2011-10-17 13:32:19 --> Hooks Class Initialized
DEBUG - 2011-10-17 13:32:19 --> Utf8 Class Initialized
DEBUG - 2011-10-17 13:32:19 --> UTF-8 Support Enabled
DEBUG - 2011-10-17 13:32:19 --> URI Class Initialized
DEBUG - 2011-10-17 13:32:19 --> Router Class Initialized
ERROR - 2011-10-17 13:32:19 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-17 13:32:20 --> Config Class Initialized
DEBUG - 2011-10-17 13:32:20 --> Hooks Class Initialized
DEBUG - 2011-10-17 13:32:20 --> Utf8 Class Initialized
DEBUG - 2011-10-17 13:32:20 --> UTF-8 Support Enabled
DEBUG - 2011-10-17 13:32:20 --> URI Class Initialized
DEBUG - 2011-10-17 13:32:20 --> Router Class Initialized
ERROR - 2011-10-17 13:32:20 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-17 13:32:40 --> Config Class Initialized
DEBUG - 2011-10-17 13:32:40 --> Hooks Class Initialized
DEBUG - 2011-10-17 13:32:40 --> Utf8 Class Initialized
DEBUG - 2011-10-17 13:32:40 --> UTF-8 Support Enabled
DEBUG - 2011-10-17 13:32:40 --> URI Class Initialized
DEBUG - 2011-10-17 13:32:40 --> Router Class Initialized
DEBUG - 2011-10-17 13:32:40 --> Output Class Initialized
DEBUG - 2011-10-17 13:32:40 --> Input Class Initialized
DEBUG - 2011-10-17 13:32:40 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-17 13:32:40 --> Language Class Initialized
DEBUG - 2011-10-17 13:32:40 --> Loader Class Initialized
DEBUG - 2011-10-17 13:32:40 --> Controller Class Initialized
DEBUG - 2011-10-17 13:32:40 --> Model Class Initialized
DEBUG - 2011-10-17 13:32:40 --> Model Class Initialized
DEBUG - 2011-10-17 13:32:40 --> Model Class Initialized
DEBUG - 2011-10-17 13:32:40 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-17 13:32:40 --> Database Driver Class Initialized
DEBUG - 2011-10-17 13:32:41 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-17 13:32:41 --> Helper loaded: url_helper
DEBUG - 2011-10-17 13:32:41 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-17 13:32:41 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-17 13:32:41 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-17 13:32:41 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-17 13:32:41 --> Final output sent to browser
DEBUG - 2011-10-17 13:32:41 --> Total execution time: 0.4595
DEBUG - 2011-10-17 13:32:42 --> Config Class Initialized
DEBUG - 2011-10-17 13:32:42 --> Hooks Class Initialized
DEBUG - 2011-10-17 13:32:42 --> Utf8 Class Initialized
DEBUG - 2011-10-17 13:32:42 --> UTF-8 Support Enabled
DEBUG - 2011-10-17 13:32:42 --> URI Class Initialized
DEBUG - 2011-10-17 13:32:42 --> Router Class Initialized
ERROR - 2011-10-17 13:32:42 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-17 13:32:42 --> Config Class Initialized
DEBUG - 2011-10-17 13:32:42 --> Hooks Class Initialized
DEBUG - 2011-10-17 13:32:42 --> Utf8 Class Initialized
DEBUG - 2011-10-17 13:32:42 --> UTF-8 Support Enabled
DEBUG - 2011-10-17 13:32:42 --> URI Class Initialized
DEBUG - 2011-10-17 13:32:42 --> Router Class Initialized
ERROR - 2011-10-17 13:32:42 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-17 13:32:44 --> Config Class Initialized
DEBUG - 2011-10-17 13:32:44 --> Hooks Class Initialized
DEBUG - 2011-10-17 13:32:44 --> Utf8 Class Initialized
DEBUG - 2011-10-17 13:32:44 --> UTF-8 Support Enabled
DEBUG - 2011-10-17 13:32:44 --> URI Class Initialized
DEBUG - 2011-10-17 13:32:44 --> Router Class Initialized
ERROR - 2011-10-17 13:32:44 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-17 13:32:44 --> Config Class Initialized
DEBUG - 2011-10-17 13:32:44 --> Hooks Class Initialized
DEBUG - 2011-10-17 13:32:44 --> Utf8 Class Initialized
DEBUG - 2011-10-17 13:32:44 --> UTF-8 Support Enabled
DEBUG - 2011-10-17 13:32:44 --> URI Class Initialized
DEBUG - 2011-10-17 13:32:44 --> Router Class Initialized
ERROR - 2011-10-17 13:32:44 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-17 13:33:10 --> Config Class Initialized
DEBUG - 2011-10-17 13:33:10 --> Hooks Class Initialized
DEBUG - 2011-10-17 13:33:10 --> Utf8 Class Initialized
DEBUG - 2011-10-17 13:33:10 --> UTF-8 Support Enabled
DEBUG - 2011-10-17 13:33:10 --> URI Class Initialized
DEBUG - 2011-10-17 13:33:10 --> Router Class Initialized
DEBUG - 2011-10-17 13:33:10 --> Output Class Initialized
DEBUG - 2011-10-17 13:33:10 --> Input Class Initialized
DEBUG - 2011-10-17 13:33:10 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-17 13:33:10 --> Language Class Initialized
DEBUG - 2011-10-17 13:33:10 --> Loader Class Initialized
DEBUG - 2011-10-17 13:33:10 --> Controller Class Initialized
DEBUG - 2011-10-17 13:33:10 --> Model Class Initialized
DEBUG - 2011-10-17 13:33:10 --> Model Class Initialized
DEBUG - 2011-10-17 13:33:10 --> Model Class Initialized
DEBUG - 2011-10-17 13:33:10 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-17 13:33:10 --> Database Driver Class Initialized
DEBUG - 2011-10-17 13:33:10 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-17 13:33:10 --> Helper loaded: url_helper
DEBUG - 2011-10-17 13:33:10 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-17 13:33:10 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-17 13:33:10 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-17 13:33:10 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-17 13:33:10 --> Final output sent to browser
DEBUG - 2011-10-17 13:33:10 --> Total execution time: 0.0810
DEBUG - 2011-10-17 13:33:12 --> Config Class Initialized
DEBUG - 2011-10-17 13:33:12 --> Hooks Class Initialized
DEBUG - 2011-10-17 13:33:12 --> Utf8 Class Initialized
DEBUG - 2011-10-17 13:33:12 --> UTF-8 Support Enabled
DEBUG - 2011-10-17 13:33:12 --> URI Class Initialized
DEBUG - 2011-10-17 13:33:12 --> Router Class Initialized
DEBUG - 2011-10-17 13:33:12 --> Output Class Initialized
DEBUG - 2011-10-17 13:33:12 --> Input Class Initialized
DEBUG - 2011-10-17 13:33:12 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-17 13:33:12 --> Language Class Initialized
DEBUG - 2011-10-17 13:33:12 --> Loader Class Initialized
DEBUG - 2011-10-17 13:33:12 --> Controller Class Initialized
DEBUG - 2011-10-17 13:33:12 --> Model Class Initialized
DEBUG - 2011-10-17 13:33:12 --> Model Class Initialized
DEBUG - 2011-10-17 13:33:12 --> Model Class Initialized
DEBUG - 2011-10-17 13:33:12 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-17 13:33:12 --> Database Driver Class Initialized
DEBUG - 2011-10-17 13:33:12 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-17 13:33:12 --> Helper loaded: url_helper
DEBUG - 2011-10-17 13:33:12 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-17 13:33:12 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-17 13:33:12 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-17 13:33:12 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-17 13:33:12 --> Final output sent to browser
DEBUG - 2011-10-17 13:33:12 --> Total execution time: 0.0608
DEBUG - 2011-10-17 13:34:13 --> Config Class Initialized
DEBUG - 2011-10-17 13:34:13 --> Hooks Class Initialized
DEBUG - 2011-10-17 13:34:13 --> Utf8 Class Initialized
DEBUG - 2011-10-17 13:34:13 --> UTF-8 Support Enabled
DEBUG - 2011-10-17 13:34:13 --> URI Class Initialized
DEBUG - 2011-10-17 13:34:13 --> Router Class Initialized
DEBUG - 2011-10-17 13:34:13 --> Output Class Initialized
DEBUG - 2011-10-17 13:34:13 --> Input Class Initialized
DEBUG - 2011-10-17 13:34:13 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-17 13:34:13 --> Language Class Initialized
DEBUG - 2011-10-17 13:34:13 --> Loader Class Initialized
DEBUG - 2011-10-17 13:34:13 --> Controller Class Initialized
DEBUG - 2011-10-17 13:34:13 --> Model Class Initialized
DEBUG - 2011-10-17 13:34:13 --> Model Class Initialized
DEBUG - 2011-10-17 13:34:13 --> Model Class Initialized
DEBUG - 2011-10-17 13:34:13 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-17 13:34:13 --> Database Driver Class Initialized
DEBUG - 2011-10-17 13:34:13 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-17 13:34:13 --> Helper loaded: url_helper
DEBUG - 2011-10-17 13:34:13 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-17 13:34:13 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-17 13:34:13 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-17 13:34:13 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-17 13:34:13 --> Final output sent to browser
DEBUG - 2011-10-17 13:34:13 --> Total execution time: 0.1922
DEBUG - 2011-10-17 13:34:15 --> Config Class Initialized
DEBUG - 2011-10-17 13:34:15 --> Hooks Class Initialized
DEBUG - 2011-10-17 13:34:15 --> Utf8 Class Initialized
DEBUG - 2011-10-17 13:34:15 --> UTF-8 Support Enabled
DEBUG - 2011-10-17 13:34:15 --> URI Class Initialized
DEBUG - 2011-10-17 13:34:15 --> Router Class Initialized
ERROR - 2011-10-17 13:34:15 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-17 13:34:15 --> Config Class Initialized
DEBUG - 2011-10-17 13:34:15 --> Hooks Class Initialized
DEBUG - 2011-10-17 13:34:15 --> Utf8 Class Initialized
DEBUG - 2011-10-17 13:34:15 --> UTF-8 Support Enabled
DEBUG - 2011-10-17 13:34:15 --> URI Class Initialized
DEBUG - 2011-10-17 13:34:15 --> Router Class Initialized
ERROR - 2011-10-17 13:34:15 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-17 13:39:15 --> Config Class Initialized
DEBUG - 2011-10-17 13:39:15 --> Hooks Class Initialized
DEBUG - 2011-10-17 13:39:15 --> Utf8 Class Initialized
DEBUG - 2011-10-17 13:39:15 --> UTF-8 Support Enabled
DEBUG - 2011-10-17 13:39:15 --> URI Class Initialized
DEBUG - 2011-10-17 13:39:15 --> Router Class Initialized
DEBUG - 2011-10-17 13:39:15 --> Output Class Initialized
DEBUG - 2011-10-17 13:39:15 --> Input Class Initialized
DEBUG - 2011-10-17 13:39:15 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-17 13:39:15 --> Language Class Initialized
DEBUG - 2011-10-17 13:39:15 --> Loader Class Initialized
DEBUG - 2011-10-17 13:39:15 --> Controller Class Initialized
ERROR - 2011-10-17 13:39:15 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-10-17 13:39:15 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-10-17 13:39:15 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-17 13:39:15 --> Model Class Initialized
DEBUG - 2011-10-17 13:39:15 --> Model Class Initialized
DEBUG - 2011-10-17 13:39:15 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-17 13:39:15 --> Database Driver Class Initialized
DEBUG - 2011-10-17 13:39:15 --> Config Class Initialized
DEBUG - 2011-10-17 13:39:15 --> Hooks Class Initialized
DEBUG - 2011-10-17 13:39:15 --> Utf8 Class Initialized
DEBUG - 2011-10-17 13:39:15 --> UTF-8 Support Enabled
DEBUG - 2011-10-17 13:39:15 --> URI Class Initialized
DEBUG - 2011-10-17 13:39:15 --> Router Class Initialized
DEBUG - 2011-10-17 13:39:15 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-17 13:39:15 --> Helper loaded: url_helper
DEBUG - 2011-10-17 13:39:15 --> Output Class Initialized
DEBUG - 2011-10-17 13:39:15 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-17 13:39:15 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-17 13:39:15 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-17 13:39:15 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-17 13:39:15 --> Final output sent to browser
DEBUG - 2011-10-17 13:39:15 --> Total execution time: 0.0504
DEBUG - 2011-10-17 13:39:15 --> Input Class Initialized
DEBUG - 2011-10-17 13:39:15 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-17 13:39:15 --> Language Class Initialized
DEBUG - 2011-10-17 13:39:15 --> Loader Class Initialized
DEBUG - 2011-10-17 13:39:15 --> Controller Class Initialized
DEBUG - 2011-10-17 13:39:15 --> Model Class Initialized
DEBUG - 2011-10-17 13:39:15 --> Model Class Initialized
DEBUG - 2011-10-17 13:39:15 --> Model Class Initialized
DEBUG - 2011-10-17 13:39:15 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-17 13:39:15 --> Database Driver Class Initialized
DEBUG - 2011-10-17 13:39:15 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-17 13:39:15 --> Helper loaded: url_helper
DEBUG - 2011-10-17 13:39:15 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-17 13:39:15 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-17 13:39:15 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-17 13:39:15 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-17 13:39:15 --> Final output sent to browser
DEBUG - 2011-10-17 13:39:15 --> Total execution time: 0.1250
DEBUG - 2011-10-17 14:02:58 --> Config Class Initialized
DEBUG - 2011-10-17 14:02:58 --> Hooks Class Initialized
DEBUG - 2011-10-17 14:02:58 --> Utf8 Class Initialized
DEBUG - 2011-10-17 14:02:58 --> UTF-8 Support Enabled
DEBUG - 2011-10-17 14:02:58 --> URI Class Initialized
DEBUG - 2011-10-17 14:02:58 --> Router Class Initialized
DEBUG - 2011-10-17 14:02:58 --> Output Class Initialized
DEBUG - 2011-10-17 14:02:58 --> Input Class Initialized
DEBUG - 2011-10-17 14:02:58 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-17 14:02:58 --> Language Class Initialized
DEBUG - 2011-10-17 14:02:58 --> Loader Class Initialized
DEBUG - 2011-10-17 14:02:58 --> Controller Class Initialized
ERROR - 2011-10-17 14:02:58 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-10-17 14:02:58 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-10-17 14:02:58 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-17 14:02:58 --> Model Class Initialized
DEBUG - 2011-10-17 14:02:58 --> Model Class Initialized
DEBUG - 2011-10-17 14:02:58 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-17 14:02:58 --> Database Driver Class Initialized
DEBUG - 2011-10-17 14:02:58 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-17 14:02:58 --> Helper loaded: url_helper
DEBUG - 2011-10-17 14:02:58 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-17 14:02:58 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-17 14:02:58 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-17 14:02:58 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-17 14:02:58 --> Final output sent to browser
DEBUG - 2011-10-17 14:02:58 --> Total execution time: 0.0310
DEBUG - 2011-10-17 14:02:59 --> Config Class Initialized
DEBUG - 2011-10-17 14:02:59 --> Hooks Class Initialized
DEBUG - 2011-10-17 14:02:59 --> Utf8 Class Initialized
DEBUG - 2011-10-17 14:02:59 --> UTF-8 Support Enabled
DEBUG - 2011-10-17 14:02:59 --> URI Class Initialized
DEBUG - 2011-10-17 14:02:59 --> Router Class Initialized
DEBUG - 2011-10-17 14:02:59 --> Output Class Initialized
DEBUG - 2011-10-17 14:02:59 --> Input Class Initialized
DEBUG - 2011-10-17 14:02:59 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-17 14:02:59 --> Language Class Initialized
DEBUG - 2011-10-17 14:02:59 --> Loader Class Initialized
DEBUG - 2011-10-17 14:02:59 --> Controller Class Initialized
DEBUG - 2011-10-17 14:02:59 --> Model Class Initialized
DEBUG - 2011-10-17 14:02:59 --> Model Class Initialized
DEBUG - 2011-10-17 14:02:59 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-17 14:02:59 --> Database Driver Class Initialized
DEBUG - 2011-10-17 14:03:00 --> Final output sent to browser
DEBUG - 2011-10-17 14:03:00 --> Total execution time: 0.6793
DEBUG - 2011-10-17 14:03:13 --> Config Class Initialized
DEBUG - 2011-10-17 14:03:13 --> Hooks Class Initialized
DEBUG - 2011-10-17 14:03:13 --> Utf8 Class Initialized
DEBUG - 2011-10-17 14:03:13 --> UTF-8 Support Enabled
DEBUG - 2011-10-17 14:03:13 --> URI Class Initialized
DEBUG - 2011-10-17 14:03:13 --> Router Class Initialized
DEBUG - 2011-10-17 14:03:13 --> Output Class Initialized
DEBUG - 2011-10-17 14:03:13 --> Input Class Initialized
DEBUG - 2011-10-17 14:03:13 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-17 14:03:13 --> Language Class Initialized
DEBUG - 2011-10-17 14:03:13 --> Loader Class Initialized
DEBUG - 2011-10-17 14:03:13 --> Controller Class Initialized
ERROR - 2011-10-17 14:03:13 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-10-17 14:03:13 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-10-17 14:03:13 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-17 14:03:13 --> Model Class Initialized
DEBUG - 2011-10-17 14:03:13 --> Model Class Initialized
DEBUG - 2011-10-17 14:03:13 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-17 14:03:13 --> Database Driver Class Initialized
DEBUG - 2011-10-17 14:03:13 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-17 14:03:13 --> Helper loaded: url_helper
DEBUG - 2011-10-17 14:03:13 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-17 14:03:13 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-17 14:03:13 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-17 14:03:13 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-17 14:03:13 --> Final output sent to browser
DEBUG - 2011-10-17 14:03:13 --> Total execution time: 0.0461
DEBUG - 2011-10-17 14:03:14 --> Config Class Initialized
DEBUG - 2011-10-17 14:03:14 --> Hooks Class Initialized
DEBUG - 2011-10-17 14:03:14 --> Utf8 Class Initialized
DEBUG - 2011-10-17 14:03:14 --> UTF-8 Support Enabled
DEBUG - 2011-10-17 14:03:14 --> URI Class Initialized
DEBUG - 2011-10-17 14:03:14 --> Router Class Initialized
DEBUG - 2011-10-17 14:03:14 --> Output Class Initialized
DEBUG - 2011-10-17 14:03:14 --> Input Class Initialized
DEBUG - 2011-10-17 14:03:14 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-17 14:03:14 --> Language Class Initialized
DEBUG - 2011-10-17 14:03:14 --> Loader Class Initialized
DEBUG - 2011-10-17 14:03:14 --> Controller Class Initialized
DEBUG - 2011-10-17 14:03:14 --> Model Class Initialized
DEBUG - 2011-10-17 14:03:14 --> Model Class Initialized
DEBUG - 2011-10-17 14:03:14 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-17 14:03:14 --> Database Driver Class Initialized
DEBUG - 2011-10-17 14:03:15 --> Final output sent to browser
DEBUG - 2011-10-17 14:03:15 --> Total execution time: 1.1318
DEBUG - 2011-10-17 14:03:22 --> Config Class Initialized
DEBUG - 2011-10-17 14:03:22 --> Hooks Class Initialized
DEBUG - 2011-10-17 14:03:22 --> Utf8 Class Initialized
DEBUG - 2011-10-17 14:03:22 --> UTF-8 Support Enabled
DEBUG - 2011-10-17 14:03:22 --> URI Class Initialized
DEBUG - 2011-10-17 14:03:22 --> Router Class Initialized
DEBUG - 2011-10-17 14:03:22 --> Output Class Initialized
DEBUG - 2011-10-17 14:03:22 --> Input Class Initialized
DEBUG - 2011-10-17 14:03:22 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-17 14:03:22 --> Language Class Initialized
DEBUG - 2011-10-17 14:03:22 --> Loader Class Initialized
DEBUG - 2011-10-17 14:03:22 --> Controller Class Initialized
ERROR - 2011-10-17 14:03:22 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-10-17 14:03:22 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-10-17 14:03:22 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-17 14:03:22 --> Model Class Initialized
DEBUG - 2011-10-17 14:03:22 --> Model Class Initialized
DEBUG - 2011-10-17 14:03:22 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-17 14:03:22 --> Database Driver Class Initialized
DEBUG - 2011-10-17 14:03:22 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-17 14:03:22 --> Helper loaded: url_helper
DEBUG - 2011-10-17 14:03:22 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-17 14:03:22 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-17 14:03:22 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-17 14:03:22 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-17 14:03:22 --> Final output sent to browser
DEBUG - 2011-10-17 14:03:22 --> Total execution time: 0.0356
DEBUG - 2011-10-17 14:03:23 --> Config Class Initialized
DEBUG - 2011-10-17 14:03:23 --> Hooks Class Initialized
DEBUG - 2011-10-17 14:03:23 --> Utf8 Class Initialized
DEBUG - 2011-10-17 14:03:23 --> UTF-8 Support Enabled
DEBUG - 2011-10-17 14:03:23 --> URI Class Initialized
DEBUG - 2011-10-17 14:03:23 --> Router Class Initialized
DEBUG - 2011-10-17 14:03:23 --> Output Class Initialized
DEBUG - 2011-10-17 14:03:23 --> Input Class Initialized
DEBUG - 2011-10-17 14:03:23 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-17 14:03:23 --> Language Class Initialized
DEBUG - 2011-10-17 14:03:23 --> Loader Class Initialized
DEBUG - 2011-10-17 14:03:23 --> Controller Class Initialized
DEBUG - 2011-10-17 14:03:23 --> Model Class Initialized
DEBUG - 2011-10-17 14:03:23 --> Model Class Initialized
DEBUG - 2011-10-17 14:03:23 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-17 14:03:23 --> Database Driver Class Initialized
DEBUG - 2011-10-17 14:03:23 --> Config Class Initialized
DEBUG - 2011-10-17 14:03:23 --> Hooks Class Initialized
DEBUG - 2011-10-17 14:03:23 --> Utf8 Class Initialized
DEBUG - 2011-10-17 14:03:23 --> UTF-8 Support Enabled
DEBUG - 2011-10-17 14:03:23 --> URI Class Initialized
DEBUG - 2011-10-17 14:03:23 --> Router Class Initialized
DEBUG - 2011-10-17 14:03:23 --> Output Class Initialized
DEBUG - 2011-10-17 14:03:23 --> Input Class Initialized
DEBUG - 2011-10-17 14:03:23 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-17 14:03:23 --> Language Class Initialized
DEBUG - 2011-10-17 14:03:23 --> Loader Class Initialized
DEBUG - 2011-10-17 14:03:23 --> Controller Class Initialized
DEBUG - 2011-10-17 14:03:23 --> Model Class Initialized
DEBUG - 2011-10-17 14:03:23 --> Model Class Initialized
DEBUG - 2011-10-17 14:03:23 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-17 14:03:23 --> Database Driver Class Initialized
DEBUG - 2011-10-17 14:03:23 --> Final output sent to browser
DEBUG - 2011-10-17 14:03:23 --> Total execution time: 0.5566
DEBUG - 2011-10-17 14:03:23 --> Final output sent to browser
DEBUG - 2011-10-17 14:03:23 --> Total execution time: 0.5989
DEBUG - 2011-10-17 14:03:40 --> Config Class Initialized
DEBUG - 2011-10-17 14:03:40 --> Hooks Class Initialized
DEBUG - 2011-10-17 14:03:40 --> Utf8 Class Initialized
DEBUG - 2011-10-17 14:03:40 --> UTF-8 Support Enabled
DEBUG - 2011-10-17 14:03:40 --> URI Class Initialized
DEBUG - 2011-10-17 14:03:40 --> Router Class Initialized
DEBUG - 2011-10-17 14:03:40 --> Output Class Initialized
DEBUG - 2011-10-17 14:03:40 --> Input Class Initialized
DEBUG - 2011-10-17 14:03:40 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-17 14:03:40 --> Language Class Initialized
DEBUG - 2011-10-17 14:03:40 --> Loader Class Initialized
DEBUG - 2011-10-17 14:03:40 --> Controller Class Initialized
ERROR - 2011-10-17 14:03:40 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-10-17 14:03:40 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-10-17 14:03:40 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-17 14:03:40 --> Model Class Initialized
DEBUG - 2011-10-17 14:03:40 --> Model Class Initialized
DEBUG - 2011-10-17 14:03:40 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-17 14:03:41 --> Database Driver Class Initialized
DEBUG - 2011-10-17 14:03:41 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-17 14:03:41 --> Helper loaded: url_helper
DEBUG - 2011-10-17 14:03:41 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-17 14:03:41 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-17 14:03:41 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-17 14:03:41 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-17 14:03:41 --> Final output sent to browser
DEBUG - 2011-10-17 14:03:41 --> Total execution time: 0.0917
DEBUG - 2011-10-17 14:03:42 --> Config Class Initialized
DEBUG - 2011-10-17 14:03:42 --> Hooks Class Initialized
DEBUG - 2011-10-17 14:03:42 --> Utf8 Class Initialized
DEBUG - 2011-10-17 14:03:42 --> UTF-8 Support Enabled
DEBUG - 2011-10-17 14:03:42 --> URI Class Initialized
DEBUG - 2011-10-17 14:03:42 --> Router Class Initialized
DEBUG - 2011-10-17 14:03:42 --> Output Class Initialized
DEBUG - 2011-10-17 14:03:42 --> Input Class Initialized
DEBUG - 2011-10-17 14:03:42 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-17 14:03:42 --> Language Class Initialized
DEBUG - 2011-10-17 14:03:42 --> Loader Class Initialized
DEBUG - 2011-10-17 14:03:42 --> Controller Class Initialized
DEBUG - 2011-10-17 14:03:42 --> Model Class Initialized
DEBUG - 2011-10-17 14:03:42 --> Model Class Initialized
DEBUG - 2011-10-17 14:03:42 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-17 14:03:42 --> Database Driver Class Initialized
DEBUG - 2011-10-17 14:03:42 --> Final output sent to browser
DEBUG - 2011-10-17 14:03:42 --> Total execution time: 0.5362
DEBUG - 2011-10-17 14:04:15 --> Config Class Initialized
DEBUG - 2011-10-17 14:04:15 --> Hooks Class Initialized
DEBUG - 2011-10-17 14:04:15 --> Utf8 Class Initialized
DEBUG - 2011-10-17 14:04:15 --> UTF-8 Support Enabled
DEBUG - 2011-10-17 14:04:15 --> URI Class Initialized
DEBUG - 2011-10-17 14:04:15 --> Router Class Initialized
DEBUG - 2011-10-17 14:04:15 --> Output Class Initialized
DEBUG - 2011-10-17 14:04:15 --> Input Class Initialized
DEBUG - 2011-10-17 14:04:15 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-17 14:04:15 --> Language Class Initialized
DEBUG - 2011-10-17 14:04:15 --> Loader Class Initialized
DEBUG - 2011-10-17 14:04:15 --> Controller Class Initialized
ERROR - 2011-10-17 14:04:15 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-10-17 14:04:15 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-10-17 14:04:15 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-17 14:04:15 --> Model Class Initialized
DEBUG - 2011-10-17 14:04:15 --> Model Class Initialized
DEBUG - 2011-10-17 14:04:15 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-17 14:04:15 --> Database Driver Class Initialized
DEBUG - 2011-10-17 14:04:15 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-17 14:04:15 --> Helper loaded: url_helper
DEBUG - 2011-10-17 14:04:15 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-17 14:04:15 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-17 14:04:15 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-17 14:04:15 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-17 14:04:15 --> Final output sent to browser
DEBUG - 2011-10-17 14:04:15 --> Total execution time: 0.0294
DEBUG - 2011-10-17 14:04:15 --> Config Class Initialized
DEBUG - 2011-10-17 14:04:15 --> Hooks Class Initialized
DEBUG - 2011-10-17 14:04:15 --> Utf8 Class Initialized
DEBUG - 2011-10-17 14:04:15 --> UTF-8 Support Enabled
DEBUG - 2011-10-17 14:04:15 --> URI Class Initialized
DEBUG - 2011-10-17 14:04:15 --> Router Class Initialized
DEBUG - 2011-10-17 14:04:15 --> Output Class Initialized
DEBUG - 2011-10-17 14:04:15 --> Input Class Initialized
DEBUG - 2011-10-17 14:04:15 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-17 14:04:15 --> Language Class Initialized
DEBUG - 2011-10-17 14:04:15 --> Loader Class Initialized
DEBUG - 2011-10-17 14:04:15 --> Controller Class Initialized
DEBUG - 2011-10-17 14:04:15 --> Model Class Initialized
DEBUG - 2011-10-17 14:04:15 --> Model Class Initialized
DEBUG - 2011-10-17 14:04:15 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-17 14:04:15 --> Database Driver Class Initialized
DEBUG - 2011-10-17 14:04:16 --> Final output sent to browser
DEBUG - 2011-10-17 14:04:16 --> Total execution time: 0.5712
DEBUG - 2011-10-17 14:04:16 --> Config Class Initialized
DEBUG - 2011-10-17 14:04:16 --> Hooks Class Initialized
DEBUG - 2011-10-17 14:04:16 --> Utf8 Class Initialized
DEBUG - 2011-10-17 14:04:16 --> UTF-8 Support Enabled
DEBUG - 2011-10-17 14:04:16 --> URI Class Initialized
DEBUG - 2011-10-17 14:04:16 --> Router Class Initialized
DEBUG - 2011-10-17 14:04:16 --> Output Class Initialized
DEBUG - 2011-10-17 14:04:16 --> Input Class Initialized
DEBUG - 2011-10-17 14:04:16 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-17 14:04:16 --> Language Class Initialized
DEBUG - 2011-10-17 14:04:16 --> Loader Class Initialized
DEBUG - 2011-10-17 14:04:16 --> Controller Class Initialized
ERROR - 2011-10-17 14:04:16 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-10-17 14:04:16 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-10-17 14:04:16 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-17 14:04:16 --> Model Class Initialized
DEBUG - 2011-10-17 14:04:16 --> Model Class Initialized
DEBUG - 2011-10-17 14:04:16 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-17 14:04:16 --> Database Driver Class Initialized
DEBUG - 2011-10-17 14:04:16 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-17 14:04:16 --> Helper loaded: url_helper
DEBUG - 2011-10-17 14:04:16 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-17 14:04:16 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-17 14:04:16 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-17 14:04:16 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-17 14:04:16 --> Final output sent to browser
DEBUG - 2011-10-17 14:04:16 --> Total execution time: 0.0566
DEBUG - 2011-10-17 15:07:07 --> Config Class Initialized
DEBUG - 2011-10-17 15:07:07 --> Hooks Class Initialized
DEBUG - 2011-10-17 15:07:07 --> Utf8 Class Initialized
DEBUG - 2011-10-17 15:07:07 --> UTF-8 Support Enabled
DEBUG - 2011-10-17 15:07:07 --> URI Class Initialized
DEBUG - 2011-10-17 15:07:07 --> Router Class Initialized
DEBUG - 2011-10-17 15:07:07 --> Output Class Initialized
DEBUG - 2011-10-17 15:07:07 --> Input Class Initialized
DEBUG - 2011-10-17 15:07:07 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-17 15:07:07 --> Language Class Initialized
DEBUG - 2011-10-17 15:07:07 --> Loader Class Initialized
DEBUG - 2011-10-17 15:07:07 --> Controller Class Initialized
ERROR - 2011-10-17 15:07:07 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-10-17 15:07:07 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-10-17 15:07:07 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-17 15:07:07 --> Model Class Initialized
DEBUG - 2011-10-17 15:07:07 --> Model Class Initialized
DEBUG - 2011-10-17 15:07:07 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-17 15:07:07 --> Database Driver Class Initialized
DEBUG - 2011-10-17 15:07:07 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-17 15:07:07 --> Helper loaded: url_helper
DEBUG - 2011-10-17 15:07:07 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-17 15:07:07 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-17 15:07:07 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-17 15:07:07 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-17 15:07:07 --> Final output sent to browser
DEBUG - 2011-10-17 15:07:07 --> Total execution time: 0.1087
DEBUG - 2011-10-17 15:07:08 --> Config Class Initialized
DEBUG - 2011-10-17 15:07:08 --> Hooks Class Initialized
DEBUG - 2011-10-17 15:07:08 --> Utf8 Class Initialized
DEBUG - 2011-10-17 15:07:08 --> UTF-8 Support Enabled
DEBUG - 2011-10-17 15:07:08 --> URI Class Initialized
DEBUG - 2011-10-17 15:07:08 --> Router Class Initialized
DEBUG - 2011-10-17 15:07:08 --> Output Class Initialized
DEBUG - 2011-10-17 15:07:08 --> Input Class Initialized
DEBUG - 2011-10-17 15:07:08 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-17 15:07:08 --> Language Class Initialized
DEBUG - 2011-10-17 15:07:08 --> Loader Class Initialized
DEBUG - 2011-10-17 15:07:08 --> Controller Class Initialized
DEBUG - 2011-10-17 15:07:08 --> Model Class Initialized
DEBUG - 2011-10-17 15:07:08 --> Model Class Initialized
DEBUG - 2011-10-17 15:07:08 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-17 15:07:08 --> Database Driver Class Initialized
DEBUG - 2011-10-17 15:07:08 --> Final output sent to browser
DEBUG - 2011-10-17 15:07:08 --> Total execution time: 0.6066
DEBUG - 2011-10-17 15:07:09 --> Config Class Initialized
DEBUG - 2011-10-17 15:07:09 --> Hooks Class Initialized
DEBUG - 2011-10-17 15:07:09 --> Utf8 Class Initialized
DEBUG - 2011-10-17 15:07:09 --> UTF-8 Support Enabled
DEBUG - 2011-10-17 15:07:09 --> URI Class Initialized
DEBUG - 2011-10-17 15:07:09 --> Router Class Initialized
ERROR - 2011-10-17 15:07:09 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-17 15:07:09 --> Config Class Initialized
DEBUG - 2011-10-17 15:07:09 --> Hooks Class Initialized
DEBUG - 2011-10-17 15:07:09 --> Utf8 Class Initialized
DEBUG - 2011-10-17 15:07:09 --> UTF-8 Support Enabled
DEBUG - 2011-10-17 15:07:09 --> URI Class Initialized
DEBUG - 2011-10-17 15:07:09 --> Router Class Initialized
ERROR - 2011-10-17 15:07:09 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-17 15:07:11 --> Config Class Initialized
DEBUG - 2011-10-17 15:07:11 --> Hooks Class Initialized
DEBUG - 2011-10-17 15:07:11 --> Utf8 Class Initialized
DEBUG - 2011-10-17 15:07:11 --> UTF-8 Support Enabled
DEBUG - 2011-10-17 15:07:11 --> URI Class Initialized
DEBUG - 2011-10-17 15:07:11 --> Router Class Initialized
ERROR - 2011-10-17 15:07:11 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-17 15:08:06 --> Config Class Initialized
DEBUG - 2011-10-17 15:08:06 --> Hooks Class Initialized
DEBUG - 2011-10-17 15:08:06 --> Utf8 Class Initialized
DEBUG - 2011-10-17 15:08:06 --> UTF-8 Support Enabled
DEBUG - 2011-10-17 15:08:06 --> URI Class Initialized
DEBUG - 2011-10-17 15:08:06 --> Router Class Initialized
DEBUG - 2011-10-17 15:08:06 --> Output Class Initialized
DEBUG - 2011-10-17 15:08:06 --> Input Class Initialized
DEBUG - 2011-10-17 15:08:06 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-17 15:08:06 --> Language Class Initialized
DEBUG - 2011-10-17 15:08:06 --> Loader Class Initialized
DEBUG - 2011-10-17 15:08:06 --> Controller Class Initialized
ERROR - 2011-10-17 15:08:06 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-10-17 15:08:06 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-10-17 15:08:06 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-17 15:08:06 --> Model Class Initialized
DEBUG - 2011-10-17 15:08:06 --> Model Class Initialized
DEBUG - 2011-10-17 15:08:06 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-17 15:08:06 --> Database Driver Class Initialized
DEBUG - 2011-10-17 15:08:06 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-17 15:08:06 --> Helper loaded: url_helper
DEBUG - 2011-10-17 15:08:06 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-17 15:08:06 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-17 15:08:06 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-17 15:08:06 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-17 15:08:06 --> Final output sent to browser
DEBUG - 2011-10-17 15:08:06 --> Total execution time: 0.0276
DEBUG - 2011-10-17 15:08:07 --> Config Class Initialized
DEBUG - 2011-10-17 15:08:07 --> Hooks Class Initialized
DEBUG - 2011-10-17 15:08:07 --> Utf8 Class Initialized
DEBUG - 2011-10-17 15:08:07 --> UTF-8 Support Enabled
DEBUG - 2011-10-17 15:08:07 --> URI Class Initialized
DEBUG - 2011-10-17 15:08:07 --> Router Class Initialized
DEBUG - 2011-10-17 15:08:07 --> Output Class Initialized
DEBUG - 2011-10-17 15:08:07 --> Input Class Initialized
DEBUG - 2011-10-17 15:08:07 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-17 15:08:07 --> Language Class Initialized
DEBUG - 2011-10-17 15:08:07 --> Loader Class Initialized
DEBUG - 2011-10-17 15:08:07 --> Controller Class Initialized
DEBUG - 2011-10-17 15:08:07 --> Model Class Initialized
DEBUG - 2011-10-17 15:08:07 --> Model Class Initialized
DEBUG - 2011-10-17 15:08:07 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-17 15:08:07 --> Database Driver Class Initialized
DEBUG - 2011-10-17 15:08:07 --> Final output sent to browser
DEBUG - 2011-10-17 15:08:07 --> Total execution time: 0.6515
DEBUG - 2011-10-17 15:08:31 --> Config Class Initialized
DEBUG - 2011-10-17 15:08:31 --> Hooks Class Initialized
DEBUG - 2011-10-17 15:08:31 --> Utf8 Class Initialized
DEBUG - 2011-10-17 15:08:31 --> UTF-8 Support Enabled
DEBUG - 2011-10-17 15:08:31 --> URI Class Initialized
DEBUG - 2011-10-17 15:08:31 --> Router Class Initialized
DEBUG - 2011-10-17 15:08:31 --> Output Class Initialized
DEBUG - 2011-10-17 15:08:31 --> Input Class Initialized
DEBUG - 2011-10-17 15:08:31 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-17 15:08:31 --> Language Class Initialized
DEBUG - 2011-10-17 15:08:31 --> Loader Class Initialized
DEBUG - 2011-10-17 15:08:31 --> Controller Class Initialized
ERROR - 2011-10-17 15:08:31 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-10-17 15:08:31 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-10-17 15:08:31 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-17 15:08:31 --> Model Class Initialized
DEBUG - 2011-10-17 15:08:31 --> Model Class Initialized
DEBUG - 2011-10-17 15:08:31 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-17 15:08:31 --> Database Driver Class Initialized
DEBUG - 2011-10-17 15:08:31 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-17 15:08:31 --> Helper loaded: url_helper
DEBUG - 2011-10-17 15:08:31 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-17 15:08:31 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-17 15:08:31 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-17 15:08:31 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-17 15:08:31 --> Final output sent to browser
DEBUG - 2011-10-17 15:08:31 --> Total execution time: 0.0276
DEBUG - 2011-10-17 15:08:32 --> Config Class Initialized
DEBUG - 2011-10-17 15:08:32 --> Hooks Class Initialized
DEBUG - 2011-10-17 15:08:32 --> Utf8 Class Initialized
DEBUG - 2011-10-17 15:08:32 --> UTF-8 Support Enabled
DEBUG - 2011-10-17 15:08:32 --> URI Class Initialized
DEBUG - 2011-10-17 15:08:32 --> Router Class Initialized
DEBUG - 2011-10-17 15:08:32 --> Output Class Initialized
DEBUG - 2011-10-17 15:08:32 --> Input Class Initialized
DEBUG - 2011-10-17 15:08:32 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-17 15:08:32 --> Language Class Initialized
DEBUG - 2011-10-17 15:08:32 --> Loader Class Initialized
DEBUG - 2011-10-17 15:08:32 --> Controller Class Initialized
DEBUG - 2011-10-17 15:08:32 --> Model Class Initialized
DEBUG - 2011-10-17 15:08:32 --> Model Class Initialized
DEBUG - 2011-10-17 15:08:32 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-17 15:08:32 --> Database Driver Class Initialized
DEBUG - 2011-10-17 15:08:32 --> Final output sent to browser
DEBUG - 2011-10-17 15:08:32 --> Total execution time: 0.5487
DEBUG - 2011-10-17 15:10:57 --> Config Class Initialized
DEBUG - 2011-10-17 15:10:57 --> Hooks Class Initialized
DEBUG - 2011-10-17 15:10:57 --> Utf8 Class Initialized
DEBUG - 2011-10-17 15:10:57 --> UTF-8 Support Enabled
DEBUG - 2011-10-17 15:10:57 --> URI Class Initialized
DEBUG - 2011-10-17 15:10:57 --> Router Class Initialized
DEBUG - 2011-10-17 15:10:57 --> No URI present. Default controller set.
DEBUG - 2011-10-17 15:10:57 --> Output Class Initialized
DEBUG - 2011-10-17 15:10:57 --> Input Class Initialized
DEBUG - 2011-10-17 15:10:57 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-17 15:10:57 --> Language Class Initialized
DEBUG - 2011-10-17 15:10:57 --> Loader Class Initialized
DEBUG - 2011-10-17 15:10:57 --> Controller Class Initialized
DEBUG - 2011-10-17 15:10:57 --> File loaded: application/views/splash/main.php
DEBUG - 2011-10-17 15:10:57 --> Helper loaded: url_helper
DEBUG - 2011-10-17 15:10:57 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-17 15:10:57 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-17 15:10:57 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-17 15:10:57 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-17 15:10:57 --> Final output sent to browser
DEBUG - 2011-10-17 15:10:57 --> Total execution time: 0.0302
DEBUG - 2011-10-17 15:25:27 --> Config Class Initialized
DEBUG - 2011-10-17 15:25:27 --> Hooks Class Initialized
DEBUG - 2011-10-17 15:25:27 --> Utf8 Class Initialized
DEBUG - 2011-10-17 15:25:27 --> UTF-8 Support Enabled
DEBUG - 2011-10-17 15:25:27 --> URI Class Initialized
DEBUG - 2011-10-17 15:25:27 --> Router Class Initialized
DEBUG - 2011-10-17 15:25:27 --> Output Class Initialized
DEBUG - 2011-10-17 15:25:27 --> Input Class Initialized
DEBUG - 2011-10-17 15:25:27 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-17 15:25:27 --> Language Class Initialized
DEBUG - 2011-10-17 15:25:27 --> Loader Class Initialized
DEBUG - 2011-10-17 15:25:27 --> Controller Class Initialized
DEBUG - 2011-10-17 15:25:27 --> Model Class Initialized
DEBUG - 2011-10-17 15:25:27 --> Model Class Initialized
DEBUG - 2011-10-17 15:25:27 --> Model Class Initialized
DEBUG - 2011-10-17 15:25:27 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-17 15:25:27 --> Database Driver Class Initialized
DEBUG - 2011-10-17 15:25:27 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-17 15:25:27 --> Helper loaded: url_helper
DEBUG - 2011-10-17 15:25:27 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-17 15:25:27 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-17 15:25:27 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-17 15:25:27 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-17 15:25:27 --> Final output sent to browser
DEBUG - 2011-10-17 15:25:27 --> Total execution time: 0.2081
DEBUG - 2011-10-17 15:25:33 --> Config Class Initialized
DEBUG - 2011-10-17 15:25:33 --> Hooks Class Initialized
DEBUG - 2011-10-17 15:25:33 --> Utf8 Class Initialized
DEBUG - 2011-10-17 15:25:33 --> UTF-8 Support Enabled
DEBUG - 2011-10-17 15:25:33 --> URI Class Initialized
DEBUG - 2011-10-17 15:25:33 --> Router Class Initialized
ERROR - 2011-10-17 15:25:33 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-17 15:25:55 --> Config Class Initialized
DEBUG - 2011-10-17 15:25:55 --> Hooks Class Initialized
DEBUG - 2011-10-17 15:25:55 --> Utf8 Class Initialized
DEBUG - 2011-10-17 15:25:55 --> UTF-8 Support Enabled
DEBUG - 2011-10-17 15:25:55 --> URI Class Initialized
DEBUG - 2011-10-17 15:25:55 --> Router Class Initialized
DEBUG - 2011-10-17 15:25:55 --> Output Class Initialized
DEBUG - 2011-10-17 15:25:55 --> Input Class Initialized
DEBUG - 2011-10-17 15:25:55 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-17 15:25:55 --> Language Class Initialized
DEBUG - 2011-10-17 15:25:55 --> Loader Class Initialized
DEBUG - 2011-10-17 15:25:55 --> Controller Class Initialized
ERROR - 2011-10-17 15:25:55 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-10-17 15:25:55 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-10-17 15:25:55 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-17 15:25:55 --> Model Class Initialized
DEBUG - 2011-10-17 15:25:55 --> Model Class Initialized
DEBUG - 2011-10-17 15:25:55 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-17 15:25:55 --> Database Driver Class Initialized
DEBUG - 2011-10-17 15:25:55 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-17 15:25:55 --> Helper loaded: url_helper
DEBUG - 2011-10-17 15:25:55 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-17 15:25:55 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-17 15:25:55 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-17 15:25:55 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-17 15:25:55 --> Final output sent to browser
DEBUG - 2011-10-17 15:25:55 --> Total execution time: 0.0325
DEBUG - 2011-10-17 15:25:56 --> Config Class Initialized
DEBUG - 2011-10-17 15:25:56 --> Hooks Class Initialized
DEBUG - 2011-10-17 15:25:56 --> Utf8 Class Initialized
DEBUG - 2011-10-17 15:25:56 --> UTF-8 Support Enabled
DEBUG - 2011-10-17 15:25:56 --> URI Class Initialized
DEBUG - 2011-10-17 15:25:56 --> Router Class Initialized
DEBUG - 2011-10-17 15:25:56 --> Output Class Initialized
DEBUG - 2011-10-17 15:25:56 --> Input Class Initialized
DEBUG - 2011-10-17 15:25:56 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-17 15:25:56 --> Language Class Initialized
DEBUG - 2011-10-17 15:25:56 --> Loader Class Initialized
DEBUG - 2011-10-17 15:25:56 --> Controller Class Initialized
DEBUG - 2011-10-17 15:25:56 --> Model Class Initialized
DEBUG - 2011-10-17 15:25:56 --> Model Class Initialized
DEBUG - 2011-10-17 15:25:56 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-17 15:25:56 --> Database Driver Class Initialized
DEBUG - 2011-10-17 15:25:57 --> Final output sent to browser
DEBUG - 2011-10-17 15:25:57 --> Total execution time: 0.5021
DEBUG - 2011-10-17 15:26:01 --> Config Class Initialized
DEBUG - 2011-10-17 15:26:01 --> Hooks Class Initialized
DEBUG - 2011-10-17 15:26:01 --> Utf8 Class Initialized
DEBUG - 2011-10-17 15:26:01 --> UTF-8 Support Enabled
DEBUG - 2011-10-17 15:26:01 --> URI Class Initialized
DEBUG - 2011-10-17 15:26:01 --> Router Class Initialized
ERROR - 2011-10-17 15:26:01 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-17 15:26:02 --> Config Class Initialized
DEBUG - 2011-10-17 15:26:02 --> Hooks Class Initialized
DEBUG - 2011-10-17 15:26:02 --> Utf8 Class Initialized
DEBUG - 2011-10-17 15:26:02 --> UTF-8 Support Enabled
DEBUG - 2011-10-17 15:26:02 --> URI Class Initialized
DEBUG - 2011-10-17 15:26:02 --> Router Class Initialized
DEBUG - 2011-10-17 15:26:02 --> Output Class Initialized
DEBUG - 2011-10-17 15:26:02 --> Input Class Initialized
DEBUG - 2011-10-17 15:26:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-17 15:26:02 --> Language Class Initialized
DEBUG - 2011-10-17 15:26:02 --> Loader Class Initialized
DEBUG - 2011-10-17 15:26:02 --> Controller Class Initialized
DEBUG - 2011-10-17 15:26:02 --> Model Class Initialized
DEBUG - 2011-10-17 15:26:02 --> Model Class Initialized
DEBUG - 2011-10-17 15:26:02 --> Model Class Initialized
DEBUG - 2011-10-17 15:26:02 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-17 15:26:02 --> Database Driver Class Initialized
DEBUG - 2011-10-17 15:26:03 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-17 15:26:03 --> Helper loaded: url_helper
DEBUG - 2011-10-17 15:26:03 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-17 15:26:03 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-17 15:26:03 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-17 15:26:03 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-17 15:26:03 --> Final output sent to browser
DEBUG - 2011-10-17 15:26:03 --> Total execution time: 0.5065
DEBUG - 2011-10-17 15:26:07 --> Config Class Initialized
DEBUG - 2011-10-17 15:26:07 --> Hooks Class Initialized
DEBUG - 2011-10-17 15:26:07 --> Utf8 Class Initialized
DEBUG - 2011-10-17 15:26:07 --> UTF-8 Support Enabled
DEBUG - 2011-10-17 15:26:07 --> URI Class Initialized
DEBUG - 2011-10-17 15:26:07 --> Router Class Initialized
DEBUG - 2011-10-17 15:26:07 --> Output Class Initialized
DEBUG - 2011-10-17 15:26:07 --> Input Class Initialized
DEBUG - 2011-10-17 15:26:07 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-17 15:26:07 --> Language Class Initialized
DEBUG - 2011-10-17 15:26:07 --> Loader Class Initialized
DEBUG - 2011-10-17 15:26:07 --> Controller Class Initialized
DEBUG - 2011-10-17 15:26:07 --> Model Class Initialized
DEBUG - 2011-10-17 15:26:07 --> Model Class Initialized
DEBUG - 2011-10-17 15:26:07 --> Model Class Initialized
DEBUG - 2011-10-17 15:26:07 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-17 15:26:07 --> Database Driver Class Initialized
DEBUG - 2011-10-17 15:26:07 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-17 15:26:07 --> Helper loaded: url_helper
DEBUG - 2011-10-17 15:26:07 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-17 15:26:07 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-17 15:26:07 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-17 15:26:07 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-17 15:26:07 --> Final output sent to browser
DEBUG - 2011-10-17 15:26:07 --> Total execution time: 0.0988
DEBUG - 2011-10-17 15:26:08 --> Config Class Initialized
DEBUG - 2011-10-17 15:26:08 --> Hooks Class Initialized
DEBUG - 2011-10-17 15:26:08 --> Utf8 Class Initialized
DEBUG - 2011-10-17 15:26:08 --> UTF-8 Support Enabled
DEBUG - 2011-10-17 15:26:08 --> URI Class Initialized
DEBUG - 2011-10-17 15:26:08 --> Router Class Initialized
ERROR - 2011-10-17 15:26:08 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-17 15:26:08 --> Config Class Initialized
DEBUG - 2011-10-17 15:26:08 --> Hooks Class Initialized
DEBUG - 2011-10-17 15:26:08 --> Utf8 Class Initialized
DEBUG - 2011-10-17 15:26:08 --> UTF-8 Support Enabled
DEBUG - 2011-10-17 15:26:08 --> URI Class Initialized
DEBUG - 2011-10-17 15:26:08 --> Router Class Initialized
ERROR - 2011-10-17 15:26:08 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-17 15:26:09 --> Config Class Initialized
DEBUG - 2011-10-17 15:26:09 --> Hooks Class Initialized
DEBUG - 2011-10-17 15:26:09 --> Utf8 Class Initialized
DEBUG - 2011-10-17 15:26:09 --> UTF-8 Support Enabled
DEBUG - 2011-10-17 15:26:09 --> URI Class Initialized
DEBUG - 2011-10-17 15:26:09 --> Router Class Initialized
ERROR - 2011-10-17 15:26:09 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-17 15:26:14 --> Config Class Initialized
DEBUG - 2011-10-17 15:26:14 --> Hooks Class Initialized
DEBUG - 2011-10-17 15:26:14 --> Utf8 Class Initialized
DEBUG - 2011-10-17 15:26:14 --> UTF-8 Support Enabled
DEBUG - 2011-10-17 15:26:14 --> URI Class Initialized
DEBUG - 2011-10-17 15:26:14 --> Router Class Initialized
DEBUG - 2011-10-17 15:26:14 --> Output Class Initialized
DEBUG - 2011-10-17 15:26:14 --> Input Class Initialized
DEBUG - 2011-10-17 15:26:14 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-17 15:26:14 --> Language Class Initialized
DEBUG - 2011-10-17 15:26:14 --> Loader Class Initialized
DEBUG - 2011-10-17 15:26:14 --> Controller Class Initialized
DEBUG - 2011-10-17 15:26:14 --> Model Class Initialized
DEBUG - 2011-10-17 15:26:14 --> Model Class Initialized
DEBUG - 2011-10-17 15:26:14 --> Model Class Initialized
DEBUG - 2011-10-17 15:26:14 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-17 15:26:14 --> Database Driver Class Initialized
DEBUG - 2011-10-17 15:26:14 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-17 15:26:14 --> Helper loaded: url_helper
DEBUG - 2011-10-17 15:26:14 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-17 15:26:14 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-17 15:26:14 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-17 15:26:14 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-17 15:26:14 --> Final output sent to browser
DEBUG - 2011-10-17 15:26:14 --> Total execution time: 0.3994
DEBUG - 2011-10-17 15:26:18 --> Config Class Initialized
DEBUG - 2011-10-17 15:26:18 --> Hooks Class Initialized
DEBUG - 2011-10-17 15:26:18 --> Utf8 Class Initialized
DEBUG - 2011-10-17 15:26:18 --> UTF-8 Support Enabled
DEBUG - 2011-10-17 15:26:18 --> URI Class Initialized
DEBUG - 2011-10-17 15:26:18 --> Router Class Initialized
DEBUG - 2011-10-17 15:26:18 --> Output Class Initialized
DEBUG - 2011-10-17 15:26:18 --> Input Class Initialized
DEBUG - 2011-10-17 15:26:18 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-17 15:26:18 --> Language Class Initialized
DEBUG - 2011-10-17 15:26:18 --> Loader Class Initialized
DEBUG - 2011-10-17 15:26:18 --> Controller Class Initialized
DEBUG - 2011-10-17 15:26:18 --> Model Class Initialized
DEBUG - 2011-10-17 15:26:18 --> Model Class Initialized
DEBUG - 2011-10-17 15:26:18 --> Model Class Initialized
DEBUG - 2011-10-17 15:26:18 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-17 15:26:18 --> Database Driver Class Initialized
DEBUG - 2011-10-17 15:26:18 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-17 15:26:18 --> Helper loaded: url_helper
DEBUG - 2011-10-17 15:26:18 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-17 15:26:18 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-17 15:26:18 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-17 15:26:18 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-17 15:26:18 --> Final output sent to browser
DEBUG - 2011-10-17 15:26:18 --> Total execution time: 0.0721
DEBUG - 2011-10-17 15:26:18 --> Config Class Initialized
DEBUG - 2011-10-17 15:26:18 --> Hooks Class Initialized
DEBUG - 2011-10-17 15:26:18 --> Utf8 Class Initialized
DEBUG - 2011-10-17 15:26:18 --> UTF-8 Support Enabled
DEBUG - 2011-10-17 15:26:18 --> URI Class Initialized
DEBUG - 2011-10-17 15:26:18 --> Router Class Initialized
ERROR - 2011-10-17 15:26:18 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-17 15:26:20 --> Config Class Initialized
DEBUG - 2011-10-17 15:26:20 --> Hooks Class Initialized
DEBUG - 2011-10-17 15:26:20 --> Utf8 Class Initialized
DEBUG - 2011-10-17 15:26:20 --> UTF-8 Support Enabled
DEBUG - 2011-10-17 15:26:20 --> URI Class Initialized
DEBUG - 2011-10-17 15:26:20 --> Router Class Initialized
ERROR - 2011-10-17 15:26:20 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-17 15:26:26 --> Config Class Initialized
DEBUG - 2011-10-17 15:26:26 --> Hooks Class Initialized
DEBUG - 2011-10-17 15:26:26 --> Utf8 Class Initialized
DEBUG - 2011-10-17 15:26:26 --> UTF-8 Support Enabled
DEBUG - 2011-10-17 15:26:26 --> URI Class Initialized
DEBUG - 2011-10-17 15:26:26 --> Router Class Initialized
DEBUG - 2011-10-17 15:26:26 --> Output Class Initialized
DEBUG - 2011-10-17 15:26:26 --> Input Class Initialized
DEBUG - 2011-10-17 15:26:26 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-17 15:26:26 --> Language Class Initialized
DEBUG - 2011-10-17 15:26:26 --> Loader Class Initialized
DEBUG - 2011-10-17 15:26:26 --> Controller Class Initialized
DEBUG - 2011-10-17 15:26:26 --> Model Class Initialized
DEBUG - 2011-10-17 15:26:26 --> Model Class Initialized
DEBUG - 2011-10-17 15:26:26 --> Model Class Initialized
DEBUG - 2011-10-17 15:26:26 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-17 15:26:26 --> Database Driver Class Initialized
DEBUG - 2011-10-17 15:26:26 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-17 15:26:26 --> Helper loaded: url_helper
DEBUG - 2011-10-17 15:26:26 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-17 15:26:26 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-17 15:26:26 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-17 15:26:26 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-17 15:26:26 --> Final output sent to browser
DEBUG - 2011-10-17 15:26:26 --> Total execution time: 0.3485
DEBUG - 2011-10-17 15:26:30 --> Config Class Initialized
DEBUG - 2011-10-17 15:26:30 --> Hooks Class Initialized
DEBUG - 2011-10-17 15:26:30 --> Utf8 Class Initialized
DEBUG - 2011-10-17 15:26:30 --> UTF-8 Support Enabled
DEBUG - 2011-10-17 15:26:30 --> URI Class Initialized
DEBUG - 2011-10-17 15:26:30 --> Router Class Initialized
ERROR - 2011-10-17 15:26:30 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-17 15:26:31 --> Config Class Initialized
DEBUG - 2011-10-17 15:26:31 --> Hooks Class Initialized
DEBUG - 2011-10-17 15:26:31 --> Utf8 Class Initialized
DEBUG - 2011-10-17 15:26:31 --> UTF-8 Support Enabled
DEBUG - 2011-10-17 15:26:31 --> URI Class Initialized
DEBUG - 2011-10-17 15:26:31 --> Router Class Initialized
ERROR - 2011-10-17 15:26:31 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-17 15:26:39 --> Config Class Initialized
DEBUG - 2011-10-17 15:26:39 --> Hooks Class Initialized
DEBUG - 2011-10-17 15:26:39 --> Utf8 Class Initialized
DEBUG - 2011-10-17 15:26:39 --> UTF-8 Support Enabled
DEBUG - 2011-10-17 15:26:39 --> URI Class Initialized
DEBUG - 2011-10-17 15:26:39 --> Router Class Initialized
DEBUG - 2011-10-17 15:26:39 --> Output Class Initialized
DEBUG - 2011-10-17 15:26:39 --> Input Class Initialized
DEBUG - 2011-10-17 15:26:39 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-17 15:26:39 --> Language Class Initialized
DEBUG - 2011-10-17 15:26:39 --> Loader Class Initialized
DEBUG - 2011-10-17 15:26:39 --> Controller Class Initialized
DEBUG - 2011-10-17 15:26:39 --> Model Class Initialized
DEBUG - 2011-10-17 15:26:39 --> Model Class Initialized
DEBUG - 2011-10-17 15:26:39 --> Model Class Initialized
DEBUG - 2011-10-17 15:26:39 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-17 15:26:39 --> Database Driver Class Initialized
DEBUG - 2011-10-17 15:26:39 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-17 15:26:39 --> Helper loaded: url_helper
DEBUG - 2011-10-17 15:26:39 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-17 15:26:39 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-17 15:26:39 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-17 15:26:39 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-17 15:26:39 --> Final output sent to browser
DEBUG - 2011-10-17 15:26:39 --> Total execution time: 0.3983
DEBUG - 2011-10-17 15:26:41 --> Config Class Initialized
DEBUG - 2011-10-17 15:26:41 --> Hooks Class Initialized
DEBUG - 2011-10-17 15:26:41 --> Utf8 Class Initialized
DEBUG - 2011-10-17 15:26:41 --> UTF-8 Support Enabled
DEBUG - 2011-10-17 15:26:41 --> URI Class Initialized
DEBUG - 2011-10-17 15:26:41 --> Router Class Initialized
DEBUG - 2011-10-17 15:26:41 --> Output Class Initialized
DEBUG - 2011-10-17 15:26:41 --> Input Class Initialized
DEBUG - 2011-10-17 15:26:41 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-17 15:26:41 --> Language Class Initialized
DEBUG - 2011-10-17 15:26:41 --> Loader Class Initialized
DEBUG - 2011-10-17 15:26:41 --> Controller Class Initialized
DEBUG - 2011-10-17 15:26:41 --> Model Class Initialized
DEBUG - 2011-10-17 15:26:41 --> Model Class Initialized
DEBUG - 2011-10-17 15:26:41 --> Model Class Initialized
DEBUG - 2011-10-17 15:26:41 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-17 15:26:41 --> Database Driver Class Initialized
DEBUG - 2011-10-17 15:26:41 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-17 15:26:41 --> Helper loaded: url_helper
DEBUG - 2011-10-17 15:26:41 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-17 15:26:41 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-17 15:26:41 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-17 15:26:41 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-17 15:26:41 --> Final output sent to browser
DEBUG - 2011-10-17 15:26:41 --> Total execution time: 0.0662
DEBUG - 2011-10-17 15:26:42 --> Config Class Initialized
DEBUG - 2011-10-17 15:26:42 --> Hooks Class Initialized
DEBUG - 2011-10-17 15:26:42 --> Utf8 Class Initialized
DEBUG - 2011-10-17 15:26:42 --> UTF-8 Support Enabled
DEBUG - 2011-10-17 15:26:42 --> URI Class Initialized
DEBUG - 2011-10-17 15:26:42 --> Router Class Initialized
ERROR - 2011-10-17 15:26:42 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-17 15:26:43 --> Config Class Initialized
DEBUG - 2011-10-17 15:26:43 --> Hooks Class Initialized
DEBUG - 2011-10-17 15:26:43 --> Utf8 Class Initialized
DEBUG - 2011-10-17 15:26:43 --> UTF-8 Support Enabled
DEBUG - 2011-10-17 15:26:43 --> URI Class Initialized
DEBUG - 2011-10-17 15:26:43 --> Router Class Initialized
ERROR - 2011-10-17 15:26:43 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-17 15:26:43 --> Config Class Initialized
DEBUG - 2011-10-17 15:26:43 --> Hooks Class Initialized
DEBUG - 2011-10-17 15:26:43 --> Utf8 Class Initialized
DEBUG - 2011-10-17 15:26:43 --> UTF-8 Support Enabled
DEBUG - 2011-10-17 15:26:43 --> URI Class Initialized
DEBUG - 2011-10-17 15:26:43 --> Router Class Initialized
ERROR - 2011-10-17 15:26:43 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-17 15:26:47 --> Config Class Initialized
DEBUG - 2011-10-17 15:26:47 --> Hooks Class Initialized
DEBUG - 2011-10-17 15:26:47 --> Utf8 Class Initialized
DEBUG - 2011-10-17 15:26:47 --> UTF-8 Support Enabled
DEBUG - 2011-10-17 15:26:47 --> URI Class Initialized
DEBUG - 2011-10-17 15:26:47 --> Router Class Initialized
DEBUG - 2011-10-17 15:26:47 --> Output Class Initialized
DEBUG - 2011-10-17 15:26:47 --> Input Class Initialized
DEBUG - 2011-10-17 15:26:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-17 15:26:47 --> Language Class Initialized
DEBUG - 2011-10-17 15:26:47 --> Loader Class Initialized
DEBUG - 2011-10-17 15:26:47 --> Controller Class Initialized
DEBUG - 2011-10-17 15:26:47 --> Model Class Initialized
DEBUG - 2011-10-17 15:26:47 --> Model Class Initialized
DEBUG - 2011-10-17 15:26:47 --> Model Class Initialized
DEBUG - 2011-10-17 15:26:47 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-17 15:26:47 --> Database Driver Class Initialized
DEBUG - 2011-10-17 15:26:47 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-17 15:26:47 --> Helper loaded: url_helper
DEBUG - 2011-10-17 15:26:47 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-17 15:26:47 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-17 15:26:47 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-17 15:26:47 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-17 15:26:47 --> Final output sent to browser
DEBUG - 2011-10-17 15:26:47 --> Total execution time: 0.2436
DEBUG - 2011-10-17 15:26:53 --> Config Class Initialized
DEBUG - 2011-10-17 15:26:53 --> Hooks Class Initialized
DEBUG - 2011-10-17 15:26:53 --> Utf8 Class Initialized
DEBUG - 2011-10-17 15:26:53 --> UTF-8 Support Enabled
DEBUG - 2011-10-17 15:26:53 --> URI Class Initialized
DEBUG - 2011-10-17 15:26:53 --> Router Class Initialized
DEBUG - 2011-10-17 15:26:53 --> Output Class Initialized
DEBUG - 2011-10-17 15:26:53 --> Input Class Initialized
DEBUG - 2011-10-17 15:26:53 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-17 15:26:53 --> Language Class Initialized
DEBUG - 2011-10-17 15:26:53 --> Loader Class Initialized
DEBUG - 2011-10-17 15:26:53 --> Controller Class Initialized
DEBUG - 2011-10-17 15:26:53 --> Model Class Initialized
DEBUG - 2011-10-17 15:26:53 --> Model Class Initialized
DEBUG - 2011-10-17 15:26:53 --> Model Class Initialized
DEBUG - 2011-10-17 15:26:53 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-17 15:26:53 --> Database Driver Class Initialized
DEBUG - 2011-10-17 15:26:53 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-17 15:26:53 --> Helper loaded: url_helper
DEBUG - 2011-10-17 15:26:53 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-17 15:26:53 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-17 15:26:53 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-17 15:26:53 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-17 15:26:53 --> Final output sent to browser
DEBUG - 2011-10-17 15:26:53 --> Total execution time: 0.0511
DEBUG - 2011-10-17 15:26:53 --> Config Class Initialized
DEBUG - 2011-10-17 15:26:53 --> Hooks Class Initialized
DEBUG - 2011-10-17 15:26:53 --> Utf8 Class Initialized
DEBUG - 2011-10-17 15:26:53 --> UTF-8 Support Enabled
DEBUG - 2011-10-17 15:26:53 --> URI Class Initialized
DEBUG - 2011-10-17 15:26:53 --> Router Class Initialized
ERROR - 2011-10-17 15:26:53 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-17 15:26:57 --> Config Class Initialized
DEBUG - 2011-10-17 15:26:57 --> Hooks Class Initialized
DEBUG - 2011-10-17 15:26:57 --> Utf8 Class Initialized
DEBUG - 2011-10-17 15:26:57 --> UTF-8 Support Enabled
DEBUG - 2011-10-17 15:26:57 --> URI Class Initialized
DEBUG - 2011-10-17 15:26:57 --> Router Class Initialized
DEBUG - 2011-10-17 15:26:57 --> Output Class Initialized
DEBUG - 2011-10-17 15:26:57 --> Input Class Initialized
DEBUG - 2011-10-17 15:26:57 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-17 15:26:57 --> Language Class Initialized
DEBUG - 2011-10-17 15:26:57 --> Loader Class Initialized
DEBUG - 2011-10-17 15:26:57 --> Controller Class Initialized
DEBUG - 2011-10-17 15:26:57 --> Model Class Initialized
DEBUG - 2011-10-17 15:26:57 --> Model Class Initialized
DEBUG - 2011-10-17 15:26:57 --> Model Class Initialized
DEBUG - 2011-10-17 15:26:57 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-17 15:26:57 --> Database Driver Class Initialized
DEBUG - 2011-10-17 15:26:58 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-17 15:26:58 --> Helper loaded: url_helper
DEBUG - 2011-10-17 15:26:58 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-17 15:26:58 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-17 15:26:58 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-17 15:26:58 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-17 15:26:58 --> Final output sent to browser
DEBUG - 2011-10-17 15:26:58 --> Total execution time: 0.4793
DEBUG - 2011-10-17 15:27:00 --> Config Class Initialized
DEBUG - 2011-10-17 15:27:00 --> Hooks Class Initialized
DEBUG - 2011-10-17 15:27:00 --> Utf8 Class Initialized
DEBUG - 2011-10-17 15:27:00 --> UTF-8 Support Enabled
DEBUG - 2011-10-17 15:27:00 --> URI Class Initialized
DEBUG - 2011-10-17 15:27:00 --> Router Class Initialized
DEBUG - 2011-10-17 15:27:00 --> Output Class Initialized
DEBUG - 2011-10-17 15:27:00 --> Input Class Initialized
DEBUG - 2011-10-17 15:27:00 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-17 15:27:00 --> Language Class Initialized
DEBUG - 2011-10-17 15:27:00 --> Loader Class Initialized
DEBUG - 2011-10-17 15:27:00 --> Controller Class Initialized
DEBUG - 2011-10-17 15:27:00 --> Model Class Initialized
DEBUG - 2011-10-17 15:27:00 --> Model Class Initialized
DEBUG - 2011-10-17 15:27:00 --> Model Class Initialized
DEBUG - 2011-10-17 15:27:00 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-17 15:27:00 --> Database Driver Class Initialized
DEBUG - 2011-10-17 15:27:00 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-17 15:27:00 --> Helper loaded: url_helper
DEBUG - 2011-10-17 15:27:00 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-17 15:27:00 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-17 15:27:00 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-17 15:27:00 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-17 15:27:00 --> Final output sent to browser
DEBUG - 2011-10-17 15:27:00 --> Total execution time: 0.0583
DEBUG - 2011-10-17 15:27:01 --> Config Class Initialized
DEBUG - 2011-10-17 15:27:01 --> Hooks Class Initialized
DEBUG - 2011-10-17 15:27:01 --> Utf8 Class Initialized
DEBUG - 2011-10-17 15:27:01 --> UTF-8 Support Enabled
DEBUG - 2011-10-17 15:27:01 --> URI Class Initialized
DEBUG - 2011-10-17 15:27:01 --> Router Class Initialized
ERROR - 2011-10-17 15:27:01 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-17 15:27:02 --> Config Class Initialized
DEBUG - 2011-10-17 15:27:02 --> Hooks Class Initialized
DEBUG - 2011-10-17 15:27:02 --> Utf8 Class Initialized
DEBUG - 2011-10-17 15:27:02 --> UTF-8 Support Enabled
DEBUG - 2011-10-17 15:27:02 --> URI Class Initialized
DEBUG - 2011-10-17 15:27:02 --> Router Class Initialized
ERROR - 2011-10-17 15:27:02 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-17 15:27:05 --> Config Class Initialized
DEBUG - 2011-10-17 15:27:05 --> Hooks Class Initialized
DEBUG - 2011-10-17 15:27:05 --> Utf8 Class Initialized
DEBUG - 2011-10-17 15:27:05 --> UTF-8 Support Enabled
DEBUG - 2011-10-17 15:27:05 --> URI Class Initialized
DEBUG - 2011-10-17 15:27:05 --> Router Class Initialized
DEBUG - 2011-10-17 15:27:05 --> Output Class Initialized
DEBUG - 2011-10-17 15:27:05 --> Input Class Initialized
DEBUG - 2011-10-17 15:27:05 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-17 15:27:05 --> Language Class Initialized
DEBUG - 2011-10-17 15:27:05 --> Loader Class Initialized
DEBUG - 2011-10-17 15:27:05 --> Controller Class Initialized
DEBUG - 2011-10-17 15:27:05 --> Model Class Initialized
DEBUG - 2011-10-17 15:27:05 --> Model Class Initialized
DEBUG - 2011-10-17 15:27:05 --> Model Class Initialized
DEBUG - 2011-10-17 15:27:05 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-17 15:27:05 --> Database Driver Class Initialized
DEBUG - 2011-10-17 15:27:06 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-17 15:27:06 --> Helper loaded: url_helper
DEBUG - 2011-10-17 15:27:06 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-17 15:27:06 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-17 15:27:06 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-17 15:27:06 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-17 15:27:06 --> Final output sent to browser
DEBUG - 2011-10-17 15:27:06 --> Total execution time: 0.5101
DEBUG - 2011-10-17 15:27:09 --> Config Class Initialized
DEBUG - 2011-10-17 15:27:09 --> Hooks Class Initialized
DEBUG - 2011-10-17 15:27:09 --> Utf8 Class Initialized
DEBUG - 2011-10-17 15:27:09 --> UTF-8 Support Enabled
DEBUG - 2011-10-17 15:27:09 --> URI Class Initialized
DEBUG - 2011-10-17 15:27:09 --> Router Class Initialized
DEBUG - 2011-10-17 15:27:09 --> Output Class Initialized
DEBUG - 2011-10-17 15:27:09 --> Input Class Initialized
DEBUG - 2011-10-17 15:27:09 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-17 15:27:09 --> Language Class Initialized
DEBUG - 2011-10-17 15:27:09 --> Loader Class Initialized
DEBUG - 2011-10-17 15:27:09 --> Controller Class Initialized
DEBUG - 2011-10-17 15:27:09 --> Model Class Initialized
DEBUG - 2011-10-17 15:27:09 --> Model Class Initialized
DEBUG - 2011-10-17 15:27:09 --> Model Class Initialized
DEBUG - 2011-10-17 15:27:09 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-17 15:27:09 --> Database Driver Class Initialized
DEBUG - 2011-10-17 15:27:09 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-17 15:27:09 --> Helper loaded: url_helper
DEBUG - 2011-10-17 15:27:09 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-17 15:27:09 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-17 15:27:09 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-17 15:27:09 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-17 15:27:09 --> Final output sent to browser
DEBUG - 2011-10-17 15:27:09 --> Total execution time: 0.0481
DEBUG - 2011-10-17 15:27:11 --> Config Class Initialized
DEBUG - 2011-10-17 15:27:11 --> Hooks Class Initialized
DEBUG - 2011-10-17 15:27:11 --> Utf8 Class Initialized
DEBUG - 2011-10-17 15:27:11 --> UTF-8 Support Enabled
DEBUG - 2011-10-17 15:27:11 --> URI Class Initialized
DEBUG - 2011-10-17 15:27:11 --> Router Class Initialized
ERROR - 2011-10-17 15:27:11 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-17 15:27:12 --> Config Class Initialized
DEBUG - 2011-10-17 15:27:12 --> Hooks Class Initialized
DEBUG - 2011-10-17 15:27:12 --> Utf8 Class Initialized
DEBUG - 2011-10-17 15:27:12 --> UTF-8 Support Enabled
DEBUG - 2011-10-17 15:27:12 --> URI Class Initialized
DEBUG - 2011-10-17 15:27:12 --> Router Class Initialized
ERROR - 2011-10-17 15:27:12 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-17 15:27:15 --> Config Class Initialized
DEBUG - 2011-10-17 15:27:15 --> Hooks Class Initialized
DEBUG - 2011-10-17 15:27:15 --> Utf8 Class Initialized
DEBUG - 2011-10-17 15:27:15 --> UTF-8 Support Enabled
DEBUG - 2011-10-17 15:27:15 --> URI Class Initialized
DEBUG - 2011-10-17 15:27:15 --> Router Class Initialized
DEBUG - 2011-10-17 15:27:15 --> Output Class Initialized
DEBUG - 2011-10-17 15:27:15 --> Input Class Initialized
DEBUG - 2011-10-17 15:27:15 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-17 15:27:15 --> Language Class Initialized
DEBUG - 2011-10-17 15:27:15 --> Loader Class Initialized
DEBUG - 2011-10-17 15:27:15 --> Controller Class Initialized
DEBUG - 2011-10-17 15:27:15 --> Model Class Initialized
DEBUG - 2011-10-17 15:27:15 --> Model Class Initialized
DEBUG - 2011-10-17 15:27:15 --> Model Class Initialized
DEBUG - 2011-10-17 15:27:15 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-17 15:27:15 --> Database Driver Class Initialized
DEBUG - 2011-10-17 15:27:15 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-17 15:27:15 --> Helper loaded: url_helper
DEBUG - 2011-10-17 15:27:15 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-17 15:27:15 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-17 15:27:15 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-17 15:27:15 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-17 15:27:15 --> Final output sent to browser
DEBUG - 2011-10-17 15:27:15 --> Total execution time: 0.4635
DEBUG - 2011-10-17 15:27:18 --> Config Class Initialized
DEBUG - 2011-10-17 15:27:18 --> Hooks Class Initialized
DEBUG - 2011-10-17 15:27:18 --> Utf8 Class Initialized
DEBUG - 2011-10-17 15:27:18 --> UTF-8 Support Enabled
DEBUG - 2011-10-17 15:27:18 --> URI Class Initialized
DEBUG - 2011-10-17 15:27:18 --> Router Class Initialized
DEBUG - 2011-10-17 15:27:18 --> Output Class Initialized
DEBUG - 2011-10-17 15:27:18 --> Input Class Initialized
DEBUG - 2011-10-17 15:27:18 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-17 15:27:18 --> Language Class Initialized
DEBUG - 2011-10-17 15:27:18 --> Loader Class Initialized
DEBUG - 2011-10-17 15:27:18 --> Controller Class Initialized
DEBUG - 2011-10-17 15:27:18 --> Model Class Initialized
DEBUG - 2011-10-17 15:27:18 --> Model Class Initialized
DEBUG - 2011-10-17 15:27:18 --> Model Class Initialized
DEBUG - 2011-10-17 15:27:18 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-17 15:27:18 --> Database Driver Class Initialized
DEBUG - 2011-10-17 15:27:18 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-17 15:27:18 --> Helper loaded: url_helper
DEBUG - 2011-10-17 15:27:18 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-17 15:27:18 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-17 15:27:18 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-17 15:27:18 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-17 15:27:18 --> Final output sent to browser
DEBUG - 2011-10-17 15:27:18 --> Total execution time: 0.0479
DEBUG - 2011-10-17 15:27:20 --> Config Class Initialized
DEBUG - 2011-10-17 15:27:20 --> Hooks Class Initialized
DEBUG - 2011-10-17 15:27:20 --> Utf8 Class Initialized
DEBUG - 2011-10-17 15:27:20 --> UTF-8 Support Enabled
DEBUG - 2011-10-17 15:27:20 --> URI Class Initialized
DEBUG - 2011-10-17 15:27:20 --> Router Class Initialized
ERROR - 2011-10-17 15:27:20 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-17 15:27:21 --> Config Class Initialized
DEBUG - 2011-10-17 15:27:21 --> Hooks Class Initialized
DEBUG - 2011-10-17 15:27:21 --> Utf8 Class Initialized
DEBUG - 2011-10-17 15:27:21 --> UTF-8 Support Enabled
DEBUG - 2011-10-17 15:27:21 --> URI Class Initialized
DEBUG - 2011-10-17 15:27:21 --> Router Class Initialized
ERROR - 2011-10-17 15:27:21 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-17 15:27:23 --> Config Class Initialized
DEBUG - 2011-10-17 15:27:23 --> Hooks Class Initialized
DEBUG - 2011-10-17 15:27:23 --> Utf8 Class Initialized
DEBUG - 2011-10-17 15:27:23 --> UTF-8 Support Enabled
DEBUG - 2011-10-17 15:27:23 --> URI Class Initialized
DEBUG - 2011-10-17 15:27:23 --> Router Class Initialized
DEBUG - 2011-10-17 15:27:23 --> Output Class Initialized
DEBUG - 2011-10-17 15:27:23 --> Input Class Initialized
DEBUG - 2011-10-17 15:27:23 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-17 15:27:23 --> Language Class Initialized
DEBUG - 2011-10-17 15:27:23 --> Loader Class Initialized
DEBUG - 2011-10-17 15:27:23 --> Controller Class Initialized
DEBUG - 2011-10-17 15:27:23 --> Model Class Initialized
DEBUG - 2011-10-17 15:27:23 --> Model Class Initialized
DEBUG - 2011-10-17 15:27:23 --> Model Class Initialized
DEBUG - 2011-10-17 15:27:23 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-17 15:27:23 --> Database Driver Class Initialized
DEBUG - 2011-10-17 15:27:24 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-17 15:27:24 --> Helper loaded: url_helper
DEBUG - 2011-10-17 15:27:24 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-17 15:27:24 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-17 15:27:24 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-17 15:27:24 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-17 15:27:24 --> Final output sent to browser
DEBUG - 2011-10-17 15:27:24 --> Total execution time: 0.2401
DEBUG - 2011-10-17 15:27:28 --> Config Class Initialized
DEBUG - 2011-10-17 15:27:28 --> Hooks Class Initialized
DEBUG - 2011-10-17 15:27:28 --> Utf8 Class Initialized
DEBUG - 2011-10-17 15:27:28 --> UTF-8 Support Enabled
DEBUG - 2011-10-17 15:27:28 --> URI Class Initialized
DEBUG - 2011-10-17 15:27:28 --> Router Class Initialized
ERROR - 2011-10-17 15:27:28 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-17 15:27:29 --> Config Class Initialized
DEBUG - 2011-10-17 15:27:29 --> Hooks Class Initialized
DEBUG - 2011-10-17 15:27:29 --> Utf8 Class Initialized
DEBUG - 2011-10-17 15:27:29 --> UTF-8 Support Enabled
DEBUG - 2011-10-17 15:27:29 --> URI Class Initialized
DEBUG - 2011-10-17 15:27:29 --> Router Class Initialized
ERROR - 2011-10-17 15:27:29 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-17 15:27:31 --> Config Class Initialized
DEBUG - 2011-10-17 15:27:31 --> Hooks Class Initialized
DEBUG - 2011-10-17 15:27:31 --> Utf8 Class Initialized
DEBUG - 2011-10-17 15:27:31 --> UTF-8 Support Enabled
DEBUG - 2011-10-17 15:27:31 --> URI Class Initialized
DEBUG - 2011-10-17 15:27:31 --> Router Class Initialized
DEBUG - 2011-10-17 15:27:31 --> Output Class Initialized
DEBUG - 2011-10-17 15:27:31 --> Input Class Initialized
DEBUG - 2011-10-17 15:27:31 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-17 15:27:31 --> Language Class Initialized
DEBUG - 2011-10-17 15:27:31 --> Loader Class Initialized
DEBUG - 2011-10-17 15:27:31 --> Controller Class Initialized
DEBUG - 2011-10-17 15:27:31 --> Model Class Initialized
DEBUG - 2011-10-17 15:27:31 --> Model Class Initialized
DEBUG - 2011-10-17 15:27:31 --> Model Class Initialized
DEBUG - 2011-10-17 15:27:31 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-17 15:27:31 --> Database Driver Class Initialized
DEBUG - 2011-10-17 15:27:32 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-17 15:27:32 --> Helper loaded: url_helper
DEBUG - 2011-10-17 15:27:32 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-17 15:27:32 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-17 15:27:32 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-17 15:27:32 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-17 15:27:32 --> Final output sent to browser
DEBUG - 2011-10-17 15:27:32 --> Total execution time: 0.6185
DEBUG - 2011-10-17 15:27:34 --> Config Class Initialized
DEBUG - 2011-10-17 15:27:34 --> Hooks Class Initialized
DEBUG - 2011-10-17 15:27:34 --> Utf8 Class Initialized
DEBUG - 2011-10-17 15:27:34 --> UTF-8 Support Enabled
DEBUG - 2011-10-17 15:27:34 --> URI Class Initialized
DEBUG - 2011-10-17 15:27:34 --> Router Class Initialized
DEBUG - 2011-10-17 15:27:34 --> Output Class Initialized
DEBUG - 2011-10-17 15:27:34 --> Input Class Initialized
DEBUG - 2011-10-17 15:27:34 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-17 15:27:34 --> Language Class Initialized
DEBUG - 2011-10-17 15:27:34 --> Loader Class Initialized
DEBUG - 2011-10-17 15:27:34 --> Controller Class Initialized
DEBUG - 2011-10-17 15:27:34 --> Model Class Initialized
DEBUG - 2011-10-17 15:27:34 --> Model Class Initialized
DEBUG - 2011-10-17 15:27:34 --> Model Class Initialized
DEBUG - 2011-10-17 15:27:34 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-17 15:27:34 --> Database Driver Class Initialized
DEBUG - 2011-10-17 15:27:34 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-17 15:27:34 --> Helper loaded: url_helper
DEBUG - 2011-10-17 15:27:34 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-17 15:27:34 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-17 15:27:34 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-17 15:27:34 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-17 15:27:34 --> Final output sent to browser
DEBUG - 2011-10-17 15:27:34 --> Total execution time: 0.1221
DEBUG - 2011-10-17 15:27:35 --> Config Class Initialized
DEBUG - 2011-10-17 15:27:35 --> Hooks Class Initialized
DEBUG - 2011-10-17 15:27:35 --> Utf8 Class Initialized
DEBUG - 2011-10-17 15:27:35 --> UTF-8 Support Enabled
DEBUG - 2011-10-17 15:27:35 --> URI Class Initialized
DEBUG - 2011-10-17 15:27:35 --> Router Class Initialized
ERROR - 2011-10-17 15:27:35 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-17 15:27:38 --> Config Class Initialized
DEBUG - 2011-10-17 15:27:38 --> Hooks Class Initialized
DEBUG - 2011-10-17 15:27:38 --> Utf8 Class Initialized
DEBUG - 2011-10-17 15:27:38 --> UTF-8 Support Enabled
DEBUG - 2011-10-17 15:27:38 --> URI Class Initialized
DEBUG - 2011-10-17 15:27:38 --> Router Class Initialized
ERROR - 2011-10-17 15:27:38 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-17 15:27:38 --> Config Class Initialized
DEBUG - 2011-10-17 15:27:38 --> Hooks Class Initialized
DEBUG - 2011-10-17 15:27:38 --> Utf8 Class Initialized
DEBUG - 2011-10-17 15:27:38 --> UTF-8 Support Enabled
DEBUG - 2011-10-17 15:27:38 --> URI Class Initialized
DEBUG - 2011-10-17 15:27:38 --> Router Class Initialized
ERROR - 2011-10-17 15:27:38 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-17 15:27:42 --> Config Class Initialized
DEBUG - 2011-10-17 15:27:42 --> Hooks Class Initialized
DEBUG - 2011-10-17 15:27:42 --> Utf8 Class Initialized
DEBUG - 2011-10-17 15:27:42 --> UTF-8 Support Enabled
DEBUG - 2011-10-17 15:27:42 --> URI Class Initialized
DEBUG - 2011-10-17 15:27:42 --> Router Class Initialized
DEBUG - 2011-10-17 15:27:42 --> Output Class Initialized
DEBUG - 2011-10-17 15:27:42 --> Input Class Initialized
DEBUG - 2011-10-17 15:27:42 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-17 15:27:42 --> Language Class Initialized
DEBUG - 2011-10-17 15:27:42 --> Loader Class Initialized
DEBUG - 2011-10-17 15:27:42 --> Controller Class Initialized
DEBUG - 2011-10-17 15:27:42 --> Model Class Initialized
DEBUG - 2011-10-17 15:27:42 --> Model Class Initialized
DEBUG - 2011-10-17 15:27:42 --> Model Class Initialized
DEBUG - 2011-10-17 15:27:42 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-17 15:27:42 --> Database Driver Class Initialized
DEBUG - 2011-10-17 15:27:43 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-17 15:27:43 --> Helper loaded: url_helper
DEBUG - 2011-10-17 15:27:43 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-17 15:27:43 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-17 15:27:43 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-17 15:27:43 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-17 15:27:43 --> Final output sent to browser
DEBUG - 2011-10-17 15:27:43 --> Total execution time: 0.3444
DEBUG - 2011-10-17 15:27:46 --> Config Class Initialized
DEBUG - 2011-10-17 15:27:46 --> Hooks Class Initialized
DEBUG - 2011-10-17 15:27:46 --> Utf8 Class Initialized
DEBUG - 2011-10-17 15:27:46 --> UTF-8 Support Enabled
DEBUG - 2011-10-17 15:27:46 --> URI Class Initialized
DEBUG - 2011-10-17 15:27:46 --> Router Class Initialized
DEBUG - 2011-10-17 15:27:46 --> Output Class Initialized
DEBUG - 2011-10-17 15:27:46 --> Input Class Initialized
DEBUG - 2011-10-17 15:27:46 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-17 15:27:46 --> Language Class Initialized
DEBUG - 2011-10-17 15:27:46 --> Loader Class Initialized
DEBUG - 2011-10-17 15:27:46 --> Controller Class Initialized
DEBUG - 2011-10-17 15:27:46 --> Model Class Initialized
DEBUG - 2011-10-17 15:27:46 --> Model Class Initialized
DEBUG - 2011-10-17 15:27:46 --> Model Class Initialized
DEBUG - 2011-10-17 15:27:46 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-17 15:27:46 --> Database Driver Class Initialized
DEBUG - 2011-10-17 15:27:46 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-17 15:27:46 --> Helper loaded: url_helper
DEBUG - 2011-10-17 15:27:46 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-17 15:27:46 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-17 15:27:46 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-17 15:27:46 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-17 15:27:46 --> Final output sent to browser
DEBUG - 2011-10-17 15:27:46 --> Total execution time: 0.0546
DEBUG - 2011-10-17 15:27:46 --> Config Class Initialized
DEBUG - 2011-10-17 15:27:46 --> Hooks Class Initialized
DEBUG - 2011-10-17 15:27:46 --> Utf8 Class Initialized
DEBUG - 2011-10-17 15:27:46 --> UTF-8 Support Enabled
DEBUG - 2011-10-17 15:27:46 --> URI Class Initialized
DEBUG - 2011-10-17 15:27:46 --> Router Class Initialized
ERROR - 2011-10-17 15:27:46 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-17 15:27:50 --> Config Class Initialized
DEBUG - 2011-10-17 15:27:50 --> Hooks Class Initialized
DEBUG - 2011-10-17 15:27:50 --> Utf8 Class Initialized
DEBUG - 2011-10-17 15:27:50 --> UTF-8 Support Enabled
DEBUG - 2011-10-17 15:27:50 --> URI Class Initialized
DEBUG - 2011-10-17 15:27:50 --> Router Class Initialized
DEBUG - 2011-10-17 15:27:50 --> Output Class Initialized
DEBUG - 2011-10-17 15:27:50 --> Input Class Initialized
DEBUG - 2011-10-17 15:27:50 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-17 15:27:50 --> Language Class Initialized
DEBUG - 2011-10-17 15:27:50 --> Loader Class Initialized
DEBUG - 2011-10-17 15:27:50 --> Controller Class Initialized
DEBUG - 2011-10-17 15:27:50 --> Model Class Initialized
DEBUG - 2011-10-17 15:27:50 --> Model Class Initialized
DEBUG - 2011-10-17 15:27:50 --> Model Class Initialized
DEBUG - 2011-10-17 15:27:50 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-17 15:27:50 --> Database Driver Class Initialized
DEBUG - 2011-10-17 15:27:50 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-17 15:27:50 --> Helper loaded: url_helper
DEBUG - 2011-10-17 15:27:50 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-17 15:27:50 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-17 15:27:50 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-17 15:27:50 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-17 15:27:50 --> Final output sent to browser
DEBUG - 2011-10-17 15:27:50 --> Total execution time: 0.2713
DEBUG - 2011-10-17 15:27:55 --> Config Class Initialized
DEBUG - 2011-10-17 15:27:55 --> Hooks Class Initialized
DEBUG - 2011-10-17 15:27:55 --> Utf8 Class Initialized
DEBUG - 2011-10-17 15:27:55 --> UTF-8 Support Enabled
DEBUG - 2011-10-17 15:27:55 --> URI Class Initialized
DEBUG - 2011-10-17 15:27:55 --> Router Class Initialized
DEBUG - 2011-10-17 15:27:55 --> Output Class Initialized
DEBUG - 2011-10-17 15:27:55 --> Input Class Initialized
DEBUG - 2011-10-17 15:27:55 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-17 15:27:55 --> Language Class Initialized
DEBUG - 2011-10-17 15:27:55 --> Loader Class Initialized
DEBUG - 2011-10-17 15:27:55 --> Controller Class Initialized
DEBUG - 2011-10-17 15:27:55 --> Model Class Initialized
DEBUG - 2011-10-17 15:27:55 --> Model Class Initialized
DEBUG - 2011-10-17 15:27:55 --> Model Class Initialized
DEBUG - 2011-10-17 15:27:55 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-17 15:27:55 --> Database Driver Class Initialized
DEBUG - 2011-10-17 15:27:55 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-17 15:27:55 --> Helper loaded: url_helper
DEBUG - 2011-10-17 15:27:55 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-17 15:27:55 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-17 15:27:55 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-17 15:27:55 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-17 15:27:55 --> Final output sent to browser
DEBUG - 2011-10-17 15:27:55 --> Total execution time: 0.2476
DEBUG - 2011-10-17 15:27:59 --> Config Class Initialized
DEBUG - 2011-10-17 15:27:59 --> Hooks Class Initialized
DEBUG - 2011-10-17 15:27:59 --> Utf8 Class Initialized
DEBUG - 2011-10-17 15:27:59 --> UTF-8 Support Enabled
DEBUG - 2011-10-17 15:27:59 --> URI Class Initialized
DEBUG - 2011-10-17 15:27:59 --> Router Class Initialized
ERROR - 2011-10-17 15:27:59 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-17 16:31:45 --> Config Class Initialized
DEBUG - 2011-10-17 16:31:45 --> Hooks Class Initialized
DEBUG - 2011-10-17 16:31:45 --> Utf8 Class Initialized
DEBUG - 2011-10-17 16:31:45 --> UTF-8 Support Enabled
DEBUG - 2011-10-17 16:31:45 --> URI Class Initialized
DEBUG - 2011-10-17 16:31:45 --> Router Class Initialized
ERROR - 2011-10-17 16:31:45 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-10-17 16:31:46 --> Config Class Initialized
DEBUG - 2011-10-17 16:31:46 --> Hooks Class Initialized
DEBUG - 2011-10-17 16:31:46 --> Utf8 Class Initialized
DEBUG - 2011-10-17 16:31:46 --> UTF-8 Support Enabled
DEBUG - 2011-10-17 16:31:46 --> URI Class Initialized
DEBUG - 2011-10-17 16:31:46 --> Router Class Initialized
DEBUG - 2011-10-17 16:31:46 --> No URI present. Default controller set.
DEBUG - 2011-10-17 16:31:46 --> Output Class Initialized
DEBUG - 2011-10-17 16:31:46 --> Input Class Initialized
DEBUG - 2011-10-17 16:31:46 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-17 16:31:46 --> Language Class Initialized
DEBUG - 2011-10-17 16:31:46 --> Loader Class Initialized
DEBUG - 2011-10-17 16:31:46 --> Controller Class Initialized
DEBUG - 2011-10-17 16:31:46 --> File loaded: application/views/splash/main.php
DEBUG - 2011-10-17 16:31:46 --> Helper loaded: url_helper
DEBUG - 2011-10-17 16:31:46 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-17 16:31:46 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-17 16:31:46 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-17 16:31:46 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-17 16:31:46 --> Final output sent to browser
DEBUG - 2011-10-17 16:31:46 --> Total execution time: 0.0664
DEBUG - 2011-10-17 16:31:47 --> Config Class Initialized
DEBUG - 2011-10-17 16:31:47 --> Hooks Class Initialized
DEBUG - 2011-10-17 16:31:47 --> Utf8 Class Initialized
DEBUG - 2011-10-17 16:31:47 --> UTF-8 Support Enabled
DEBUG - 2011-10-17 16:31:47 --> URI Class Initialized
DEBUG - 2011-10-17 16:31:47 --> Router Class Initialized
DEBUG - 2011-10-17 16:31:47 --> Output Class Initialized
DEBUG - 2011-10-17 16:31:47 --> Input Class Initialized
DEBUG - 2011-10-17 16:31:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-17 16:31:47 --> Language Class Initialized
DEBUG - 2011-10-17 16:31:47 --> Loader Class Initialized
DEBUG - 2011-10-17 16:31:47 --> Controller Class Initialized
ERROR - 2011-10-17 16:31:47 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-10-17 16:31:47 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-10-17 16:31:47 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-17 16:31:47 --> Model Class Initialized
DEBUG - 2011-10-17 16:31:47 --> Model Class Initialized
DEBUG - 2011-10-17 16:31:47 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-17 16:31:47 --> Database Driver Class Initialized
DEBUG - 2011-10-17 16:31:47 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-17 16:31:47 --> Helper loaded: url_helper
DEBUG - 2011-10-17 16:31:47 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-17 16:31:47 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-17 16:31:47 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-17 16:31:47 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-17 16:31:47 --> Final output sent to browser
DEBUG - 2011-10-17 16:31:47 --> Total execution time: 0.0464
DEBUG - 2011-10-17 16:40:04 --> Config Class Initialized
DEBUG - 2011-10-17 16:40:04 --> Hooks Class Initialized
DEBUG - 2011-10-17 16:40:04 --> Utf8 Class Initialized
DEBUG - 2011-10-17 16:40:04 --> UTF-8 Support Enabled
DEBUG - 2011-10-17 16:40:04 --> URI Class Initialized
DEBUG - 2011-10-17 16:40:04 --> Router Class Initialized
DEBUG - 2011-10-17 16:40:04 --> Output Class Initialized
DEBUG - 2011-10-17 16:40:04 --> Input Class Initialized
DEBUG - 2011-10-17 16:40:04 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-17 16:40:04 --> Language Class Initialized
DEBUG - 2011-10-17 16:40:04 --> Loader Class Initialized
DEBUG - 2011-10-17 16:40:04 --> Controller Class Initialized
DEBUG - 2011-10-17 16:40:04 --> Model Class Initialized
DEBUG - 2011-10-17 16:40:04 --> Model Class Initialized
DEBUG - 2011-10-17 16:40:04 --> Model Class Initialized
DEBUG - 2011-10-17 16:40:04 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-17 16:40:04 --> Database Driver Class Initialized
DEBUG - 2011-10-17 16:40:05 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-17 16:40:05 --> Helper loaded: url_helper
DEBUG - 2011-10-17 16:40:05 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-17 16:40:05 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-17 16:40:05 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-17 16:40:05 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-17 16:40:05 --> Final output sent to browser
DEBUG - 2011-10-17 16:40:05 --> Total execution time: 1.2119
DEBUG - 2011-10-17 16:40:32 --> Config Class Initialized
DEBUG - 2011-10-17 16:40:32 --> Hooks Class Initialized
DEBUG - 2011-10-17 16:40:32 --> Utf8 Class Initialized
DEBUG - 2011-10-17 16:40:32 --> UTF-8 Support Enabled
DEBUG - 2011-10-17 16:40:32 --> URI Class Initialized
DEBUG - 2011-10-17 16:40:32 --> Router Class Initialized
DEBUG - 2011-10-17 16:40:32 --> Output Class Initialized
DEBUG - 2011-10-17 16:40:32 --> Input Class Initialized
DEBUG - 2011-10-17 16:40:32 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-17 16:40:32 --> Language Class Initialized
DEBUG - 2011-10-17 16:40:32 --> Loader Class Initialized
DEBUG - 2011-10-17 16:40:32 --> Controller Class Initialized
ERROR - 2011-10-17 16:40:32 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-10-17 16:40:32 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-10-17 16:40:32 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-17 16:40:32 --> Model Class Initialized
DEBUG - 2011-10-17 16:40:32 --> Model Class Initialized
DEBUG - 2011-10-17 16:40:32 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-17 16:40:32 --> Database Driver Class Initialized
DEBUG - 2011-10-17 16:40:32 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-17 16:40:32 --> Helper loaded: url_helper
DEBUG - 2011-10-17 16:40:32 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-17 16:40:32 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-17 16:40:32 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-17 16:40:32 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-17 16:40:32 --> Final output sent to browser
DEBUG - 2011-10-17 16:40:32 --> Total execution time: 0.0350
DEBUG - 2011-10-17 16:40:32 --> Config Class Initialized
DEBUG - 2011-10-17 16:40:32 --> Hooks Class Initialized
DEBUG - 2011-10-17 16:40:32 --> Utf8 Class Initialized
DEBUG - 2011-10-17 16:40:32 --> UTF-8 Support Enabled
DEBUG - 2011-10-17 16:40:32 --> URI Class Initialized
DEBUG - 2011-10-17 16:40:32 --> Router Class Initialized
DEBUG - 2011-10-17 16:40:32 --> Output Class Initialized
DEBUG - 2011-10-17 16:40:32 --> Input Class Initialized
DEBUG - 2011-10-17 16:40:32 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-17 16:40:32 --> Language Class Initialized
DEBUG - 2011-10-17 16:40:32 --> Loader Class Initialized
DEBUG - 2011-10-17 16:40:32 --> Controller Class Initialized
DEBUG - 2011-10-17 16:40:32 --> Model Class Initialized
DEBUG - 2011-10-17 16:40:32 --> Model Class Initialized
DEBUG - 2011-10-17 16:40:32 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-17 16:40:32 --> Database Driver Class Initialized
DEBUG - 2011-10-17 16:40:33 --> Final output sent to browser
DEBUG - 2011-10-17 16:40:33 --> Total execution time: 0.7970
DEBUG - 2011-10-17 17:03:09 --> Config Class Initialized
DEBUG - 2011-10-17 17:03:09 --> Hooks Class Initialized
DEBUG - 2011-10-17 17:03:09 --> Utf8 Class Initialized
DEBUG - 2011-10-17 17:03:09 --> UTF-8 Support Enabled
DEBUG - 2011-10-17 17:03:09 --> URI Class Initialized
DEBUG - 2011-10-17 17:03:09 --> Router Class Initialized
DEBUG - 2011-10-17 17:03:09 --> Output Class Initialized
DEBUG - 2011-10-17 17:03:09 --> Input Class Initialized
DEBUG - 2011-10-17 17:03:09 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-17 17:03:09 --> Language Class Initialized
DEBUG - 2011-10-17 17:03:09 --> Loader Class Initialized
DEBUG - 2011-10-17 17:03:09 --> Controller Class Initialized
ERROR - 2011-10-17 17:03:09 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-10-17 17:03:09 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-10-17 17:03:09 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-17 17:03:09 --> Model Class Initialized
DEBUG - 2011-10-17 17:03:09 --> Model Class Initialized
DEBUG - 2011-10-17 17:03:09 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-17 17:03:09 --> Database Driver Class Initialized
DEBUG - 2011-10-17 17:03:09 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-17 17:03:09 --> Helper loaded: url_helper
DEBUG - 2011-10-17 17:03:09 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-17 17:03:09 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-17 17:03:09 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-17 17:03:09 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-17 17:03:09 --> Final output sent to browser
DEBUG - 2011-10-17 17:03:09 --> Total execution time: 0.0917
DEBUG - 2011-10-17 17:03:10 --> Config Class Initialized
DEBUG - 2011-10-17 17:03:10 --> Hooks Class Initialized
DEBUG - 2011-10-17 17:03:10 --> Utf8 Class Initialized
DEBUG - 2011-10-17 17:03:10 --> UTF-8 Support Enabled
DEBUG - 2011-10-17 17:03:10 --> URI Class Initialized
DEBUG - 2011-10-17 17:03:10 --> Router Class Initialized
DEBUG - 2011-10-17 17:03:10 --> Output Class Initialized
DEBUG - 2011-10-17 17:03:10 --> Input Class Initialized
DEBUG - 2011-10-17 17:03:10 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-17 17:03:10 --> Language Class Initialized
DEBUG - 2011-10-17 17:03:10 --> Loader Class Initialized
DEBUG - 2011-10-17 17:03:10 --> Controller Class Initialized
DEBUG - 2011-10-17 17:03:10 --> Model Class Initialized
DEBUG - 2011-10-17 17:03:10 --> Model Class Initialized
DEBUG - 2011-10-17 17:03:10 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-17 17:03:10 --> Database Driver Class Initialized
DEBUG - 2011-10-17 17:03:10 --> Final output sent to browser
DEBUG - 2011-10-17 17:03:10 --> Total execution time: 0.5714
DEBUG - 2011-10-17 17:29:57 --> Config Class Initialized
DEBUG - 2011-10-17 17:29:57 --> Hooks Class Initialized
DEBUG - 2011-10-17 17:29:57 --> Utf8 Class Initialized
DEBUG - 2011-10-17 17:29:57 --> UTF-8 Support Enabled
DEBUG - 2011-10-17 17:29:57 --> URI Class Initialized
DEBUG - 2011-10-17 17:29:57 --> Router Class Initialized
ERROR - 2011-10-17 17:29:57 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-10-17 18:24:10 --> Config Class Initialized
DEBUG - 2011-10-17 18:24:10 --> Hooks Class Initialized
DEBUG - 2011-10-17 18:24:10 --> Utf8 Class Initialized
DEBUG - 2011-10-17 18:24:10 --> UTF-8 Support Enabled
DEBUG - 2011-10-17 18:24:10 --> URI Class Initialized
DEBUG - 2011-10-17 18:24:10 --> Router Class Initialized
DEBUG - 2011-10-17 18:24:10 --> Output Class Initialized
DEBUG - 2011-10-17 18:24:10 --> Input Class Initialized
DEBUG - 2011-10-17 18:24:10 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-17 18:24:10 --> Language Class Initialized
DEBUG - 2011-10-17 18:24:10 --> Loader Class Initialized
DEBUG - 2011-10-17 18:24:10 --> Controller Class Initialized
DEBUG - 2011-10-17 18:24:10 --> Model Class Initialized
DEBUG - 2011-10-17 18:24:10 --> Model Class Initialized
DEBUG - 2011-10-17 18:24:10 --> Model Class Initialized
DEBUG - 2011-10-17 18:24:10 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-17 18:24:10 --> Database Driver Class Initialized
DEBUG - 2011-10-17 18:24:11 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-17 18:24:11 --> Helper loaded: url_helper
DEBUG - 2011-10-17 18:24:11 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-17 18:24:11 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-17 18:24:11 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-17 18:24:11 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-17 18:24:11 --> Final output sent to browser
DEBUG - 2011-10-17 18:24:11 --> Total execution time: 0.5978
DEBUG - 2011-10-17 18:25:04 --> Config Class Initialized
DEBUG - 2011-10-17 18:25:04 --> Hooks Class Initialized
DEBUG - 2011-10-17 18:25:04 --> Utf8 Class Initialized
DEBUG - 2011-10-17 18:25:04 --> UTF-8 Support Enabled
DEBUG - 2011-10-17 18:25:04 --> URI Class Initialized
DEBUG - 2011-10-17 18:25:04 --> Router Class Initialized
DEBUG - 2011-10-17 18:25:04 --> Output Class Initialized
DEBUG - 2011-10-17 18:25:04 --> Input Class Initialized
DEBUG - 2011-10-17 18:25:04 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-17 18:25:04 --> Language Class Initialized
DEBUG - 2011-10-17 18:25:04 --> Loader Class Initialized
DEBUG - 2011-10-17 18:25:04 --> Controller Class Initialized
DEBUG - 2011-10-17 18:25:04 --> Model Class Initialized
DEBUG - 2011-10-17 18:25:04 --> Model Class Initialized
DEBUG - 2011-10-17 18:25:04 --> Model Class Initialized
DEBUG - 2011-10-17 18:25:04 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-17 18:25:04 --> Database Driver Class Initialized
DEBUG - 2011-10-17 18:25:05 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-17 18:25:05 --> Helper loaded: url_helper
DEBUG - 2011-10-17 18:25:05 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-17 18:25:05 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-17 18:25:05 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-17 18:25:05 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-17 18:25:05 --> Final output sent to browser
DEBUG - 2011-10-17 18:25:05 --> Total execution time: 0.7541
DEBUG - 2011-10-17 18:25:24 --> Config Class Initialized
DEBUG - 2011-10-17 18:25:24 --> Hooks Class Initialized
DEBUG - 2011-10-17 18:25:24 --> Utf8 Class Initialized
DEBUG - 2011-10-17 18:25:24 --> UTF-8 Support Enabled
DEBUG - 2011-10-17 18:25:24 --> URI Class Initialized
DEBUG - 2011-10-17 18:25:24 --> Router Class Initialized
DEBUG - 2011-10-17 18:25:24 --> Output Class Initialized
DEBUG - 2011-10-17 18:25:24 --> Input Class Initialized
DEBUG - 2011-10-17 18:25:24 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-17 18:25:24 --> Language Class Initialized
DEBUG - 2011-10-17 18:25:24 --> Loader Class Initialized
DEBUG - 2011-10-17 18:25:24 --> Controller Class Initialized
DEBUG - 2011-10-17 18:25:24 --> Model Class Initialized
DEBUG - 2011-10-17 18:25:24 --> Model Class Initialized
DEBUG - 2011-10-17 18:25:24 --> Model Class Initialized
DEBUG - 2011-10-17 18:25:24 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-17 18:25:24 --> Database Driver Class Initialized
DEBUG - 2011-10-17 18:25:24 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-17 18:25:24 --> Helper loaded: url_helper
DEBUG - 2011-10-17 18:25:24 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-17 18:25:24 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-17 18:25:24 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-17 18:25:24 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-17 18:25:24 --> Final output sent to browser
DEBUG - 2011-10-17 18:25:24 --> Total execution time: 0.2847
DEBUG - 2011-10-17 18:25:59 --> Config Class Initialized
DEBUG - 2011-10-17 18:25:59 --> Hooks Class Initialized
DEBUG - 2011-10-17 18:25:59 --> Utf8 Class Initialized
DEBUG - 2011-10-17 18:25:59 --> UTF-8 Support Enabled
DEBUG - 2011-10-17 18:25:59 --> URI Class Initialized
DEBUG - 2011-10-17 18:25:59 --> Router Class Initialized
DEBUG - 2011-10-17 18:25:59 --> Output Class Initialized
DEBUG - 2011-10-17 18:25:59 --> Input Class Initialized
DEBUG - 2011-10-17 18:25:59 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-17 18:25:59 --> Language Class Initialized
DEBUG - 2011-10-17 18:25:59 --> Loader Class Initialized
DEBUG - 2011-10-17 18:25:59 --> Controller Class Initialized
DEBUG - 2011-10-17 18:25:59 --> Model Class Initialized
DEBUG - 2011-10-17 18:25:59 --> Model Class Initialized
DEBUG - 2011-10-17 18:25:59 --> Model Class Initialized
DEBUG - 2011-10-17 18:25:59 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-17 18:25:59 --> Database Driver Class Initialized
DEBUG - 2011-10-17 18:25:59 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-17 18:25:59 --> Helper loaded: url_helper
DEBUG - 2011-10-17 18:25:59 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-17 18:25:59 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-17 18:25:59 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-17 18:25:59 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-17 18:25:59 --> Final output sent to browser
DEBUG - 2011-10-17 18:25:59 --> Total execution time: 0.4463
DEBUG - 2011-10-17 18:26:11 --> Config Class Initialized
DEBUG - 2011-10-17 18:26:11 --> Hooks Class Initialized
DEBUG - 2011-10-17 18:26:11 --> Utf8 Class Initialized
DEBUG - 2011-10-17 18:26:11 --> UTF-8 Support Enabled
DEBUG - 2011-10-17 18:26:12 --> URI Class Initialized
DEBUG - 2011-10-17 18:26:12 --> Router Class Initialized
DEBUG - 2011-10-17 18:26:12 --> Output Class Initialized
DEBUG - 2011-10-17 18:26:12 --> Input Class Initialized
DEBUG - 2011-10-17 18:26:12 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-17 18:26:12 --> Language Class Initialized
DEBUG - 2011-10-17 18:26:12 --> Loader Class Initialized
DEBUG - 2011-10-17 18:26:12 --> Controller Class Initialized
DEBUG - 2011-10-17 18:26:12 --> Model Class Initialized
DEBUG - 2011-10-17 18:26:12 --> Model Class Initialized
DEBUG - 2011-10-17 18:26:12 --> Model Class Initialized
DEBUG - 2011-10-17 18:26:12 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-17 18:26:12 --> Database Driver Class Initialized
DEBUG - 2011-10-17 18:26:12 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-17 18:26:12 --> Helper loaded: url_helper
DEBUG - 2011-10-17 18:26:12 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-17 18:26:12 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-17 18:26:12 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-17 18:26:12 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-17 18:26:12 --> Final output sent to browser
DEBUG - 2011-10-17 18:26:12 --> Total execution time: 0.4218
DEBUG - 2011-10-17 18:26:27 --> Config Class Initialized
DEBUG - 2011-10-17 18:26:27 --> Hooks Class Initialized
DEBUG - 2011-10-17 18:26:27 --> Utf8 Class Initialized
DEBUG - 2011-10-17 18:26:27 --> UTF-8 Support Enabled
DEBUG - 2011-10-17 18:26:27 --> URI Class Initialized
DEBUG - 2011-10-17 18:26:27 --> Router Class Initialized
DEBUG - 2011-10-17 18:26:27 --> Output Class Initialized
DEBUG - 2011-10-17 18:26:27 --> Input Class Initialized
DEBUG - 2011-10-17 18:26:27 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-17 18:26:27 --> Language Class Initialized
DEBUG - 2011-10-17 18:26:27 --> Loader Class Initialized
DEBUG - 2011-10-17 18:26:27 --> Controller Class Initialized
DEBUG - 2011-10-17 18:26:27 --> Model Class Initialized
DEBUG - 2011-10-17 18:26:27 --> Model Class Initialized
DEBUG - 2011-10-17 18:26:27 --> Model Class Initialized
DEBUG - 2011-10-17 18:26:27 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-17 18:26:27 --> Database Driver Class Initialized
DEBUG - 2011-10-17 18:26:27 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-17 18:26:27 --> Helper loaded: url_helper
DEBUG - 2011-10-17 18:26:27 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-17 18:26:27 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-17 18:26:27 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-17 18:26:27 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-17 18:26:27 --> Final output sent to browser
DEBUG - 2011-10-17 18:26:27 --> Total execution time: 0.2132
DEBUG - 2011-10-17 18:26:42 --> Config Class Initialized
DEBUG - 2011-10-17 18:26:42 --> Hooks Class Initialized
DEBUG - 2011-10-17 18:26:42 --> Utf8 Class Initialized
DEBUG - 2011-10-17 18:26:42 --> UTF-8 Support Enabled
DEBUG - 2011-10-17 18:26:42 --> URI Class Initialized
DEBUG - 2011-10-17 18:26:42 --> Router Class Initialized
DEBUG - 2011-10-17 18:26:42 --> Output Class Initialized
DEBUG - 2011-10-17 18:26:42 --> Input Class Initialized
DEBUG - 2011-10-17 18:26:42 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-17 18:26:42 --> Language Class Initialized
DEBUG - 2011-10-17 18:26:42 --> Loader Class Initialized
DEBUG - 2011-10-17 18:26:42 --> Controller Class Initialized
DEBUG - 2011-10-17 18:26:42 --> Model Class Initialized
DEBUG - 2011-10-17 18:26:42 --> Model Class Initialized
DEBUG - 2011-10-17 18:26:42 --> Model Class Initialized
DEBUG - 2011-10-17 18:26:42 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-17 18:26:42 --> Database Driver Class Initialized
DEBUG - 2011-10-17 18:26:42 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-17 18:26:42 --> Helper loaded: url_helper
DEBUG - 2011-10-17 18:26:42 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-17 18:26:42 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-17 18:26:42 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-17 18:26:42 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-17 18:26:42 --> Final output sent to browser
DEBUG - 2011-10-17 18:26:42 --> Total execution time: 0.2573
DEBUG - 2011-10-17 18:26:50 --> Config Class Initialized
DEBUG - 2011-10-17 18:26:50 --> Hooks Class Initialized
DEBUG - 2011-10-17 18:26:50 --> Utf8 Class Initialized
DEBUG - 2011-10-17 18:26:50 --> UTF-8 Support Enabled
DEBUG - 2011-10-17 18:26:50 --> URI Class Initialized
DEBUG - 2011-10-17 18:26:50 --> Router Class Initialized
DEBUG - 2011-10-17 18:26:50 --> Output Class Initialized
DEBUG - 2011-10-17 18:26:50 --> Input Class Initialized
DEBUG - 2011-10-17 18:26:50 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-17 18:26:50 --> Language Class Initialized
DEBUG - 2011-10-17 18:26:50 --> Loader Class Initialized
DEBUG - 2011-10-17 18:26:50 --> Controller Class Initialized
DEBUG - 2011-10-17 18:26:50 --> Model Class Initialized
DEBUG - 2011-10-17 18:26:50 --> Model Class Initialized
DEBUG - 2011-10-17 18:26:50 --> Model Class Initialized
DEBUG - 2011-10-17 18:26:50 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-17 18:26:50 --> Database Driver Class Initialized
DEBUG - 2011-10-17 18:26:51 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-17 18:26:51 --> Helper loaded: url_helper
DEBUG - 2011-10-17 18:26:51 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-17 18:26:51 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-17 18:26:51 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-17 18:26:51 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-17 18:26:51 --> Final output sent to browser
DEBUG - 2011-10-17 18:26:51 --> Total execution time: 0.7925
DEBUG - 2011-10-17 18:26:58 --> Config Class Initialized
DEBUG - 2011-10-17 18:26:58 --> Hooks Class Initialized
DEBUG - 2011-10-17 18:26:58 --> Utf8 Class Initialized
DEBUG - 2011-10-17 18:26:58 --> UTF-8 Support Enabled
DEBUG - 2011-10-17 18:26:58 --> URI Class Initialized
DEBUG - 2011-10-17 18:26:58 --> Router Class Initialized
DEBUG - 2011-10-17 18:26:58 --> Output Class Initialized
DEBUG - 2011-10-17 18:26:58 --> Input Class Initialized
DEBUG - 2011-10-17 18:26:58 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-17 18:26:58 --> Language Class Initialized
DEBUG - 2011-10-17 18:26:58 --> Loader Class Initialized
DEBUG - 2011-10-17 18:26:58 --> Controller Class Initialized
DEBUG - 2011-10-17 18:26:58 --> Model Class Initialized
DEBUG - 2011-10-17 18:26:58 --> Model Class Initialized
DEBUG - 2011-10-17 18:26:58 --> Model Class Initialized
DEBUG - 2011-10-17 18:26:58 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-17 18:26:58 --> Database Driver Class Initialized
DEBUG - 2011-10-17 18:26:59 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-17 18:26:59 --> Helper loaded: url_helper
DEBUG - 2011-10-17 18:26:59 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-17 18:26:59 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-17 18:26:59 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-17 18:26:59 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-17 18:26:59 --> Final output sent to browser
DEBUG - 2011-10-17 18:26:59 --> Total execution time: 0.2370
DEBUG - 2011-10-17 18:27:02 --> Config Class Initialized
DEBUG - 2011-10-17 18:27:02 --> Hooks Class Initialized
DEBUG - 2011-10-17 18:27:02 --> Utf8 Class Initialized
DEBUG - 2011-10-17 18:27:02 --> UTF-8 Support Enabled
DEBUG - 2011-10-17 18:27:02 --> URI Class Initialized
DEBUG - 2011-10-17 18:27:02 --> Router Class Initialized
DEBUG - 2011-10-17 18:27:02 --> Output Class Initialized
DEBUG - 2011-10-17 18:27:02 --> Input Class Initialized
DEBUG - 2011-10-17 18:27:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-17 18:27:02 --> Language Class Initialized
DEBUG - 2011-10-17 18:27:02 --> Loader Class Initialized
DEBUG - 2011-10-17 18:27:02 --> Controller Class Initialized
DEBUG - 2011-10-17 18:27:02 --> Model Class Initialized
DEBUG - 2011-10-17 18:27:02 --> Model Class Initialized
DEBUG - 2011-10-17 18:27:02 --> Model Class Initialized
DEBUG - 2011-10-17 18:27:02 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-17 18:27:02 --> Database Driver Class Initialized
DEBUG - 2011-10-17 18:27:03 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-17 18:27:03 --> Helper loaded: url_helper
DEBUG - 2011-10-17 18:27:03 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-17 18:27:03 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-17 18:27:03 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-17 18:27:03 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-17 18:27:03 --> Final output sent to browser
DEBUG - 2011-10-17 18:27:03 --> Total execution time: 0.3495
DEBUG - 2011-10-17 18:27:10 --> Config Class Initialized
DEBUG - 2011-10-17 18:27:10 --> Hooks Class Initialized
DEBUG - 2011-10-17 18:27:10 --> Utf8 Class Initialized
DEBUG - 2011-10-17 18:27:10 --> UTF-8 Support Enabled
DEBUG - 2011-10-17 18:27:10 --> URI Class Initialized
DEBUG - 2011-10-17 18:27:10 --> Router Class Initialized
DEBUG - 2011-10-17 18:27:10 --> Output Class Initialized
DEBUG - 2011-10-17 18:27:10 --> Input Class Initialized
DEBUG - 2011-10-17 18:27:10 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-17 18:27:10 --> Language Class Initialized
DEBUG - 2011-10-17 18:27:10 --> Loader Class Initialized
DEBUG - 2011-10-17 18:27:10 --> Controller Class Initialized
DEBUG - 2011-10-17 18:27:10 --> Model Class Initialized
DEBUG - 2011-10-17 18:27:10 --> Model Class Initialized
DEBUG - 2011-10-17 18:27:10 --> Model Class Initialized
DEBUG - 2011-10-17 18:27:10 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-17 18:27:10 --> Database Driver Class Initialized
DEBUG - 2011-10-17 18:27:10 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-17 18:27:10 --> Helper loaded: url_helper
DEBUG - 2011-10-17 18:27:10 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-17 18:27:10 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-17 18:27:10 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-17 18:27:10 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-17 18:27:10 --> Final output sent to browser
DEBUG - 2011-10-17 18:27:10 --> Total execution time: 0.3052
DEBUG - 2011-10-17 18:27:24 --> Config Class Initialized
DEBUG - 2011-10-17 18:27:24 --> Hooks Class Initialized
DEBUG - 2011-10-17 18:27:24 --> Utf8 Class Initialized
DEBUG - 2011-10-17 18:27:24 --> UTF-8 Support Enabled
DEBUG - 2011-10-17 18:27:24 --> URI Class Initialized
DEBUG - 2011-10-17 18:27:24 --> Router Class Initialized
DEBUG - 2011-10-17 18:27:24 --> Output Class Initialized
DEBUG - 2011-10-17 18:27:24 --> Input Class Initialized
DEBUG - 2011-10-17 18:27:24 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-17 18:27:24 --> Language Class Initialized
DEBUG - 2011-10-17 18:27:24 --> Loader Class Initialized
DEBUG - 2011-10-17 18:27:24 --> Controller Class Initialized
DEBUG - 2011-10-17 18:27:24 --> Model Class Initialized
DEBUG - 2011-10-17 18:27:24 --> Model Class Initialized
DEBUG - 2011-10-17 18:27:24 --> Model Class Initialized
DEBUG - 2011-10-17 18:27:24 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-17 18:27:24 --> Database Driver Class Initialized
DEBUG - 2011-10-17 18:27:25 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-17 18:27:25 --> Helper loaded: url_helper
DEBUG - 2011-10-17 18:27:25 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-17 18:27:25 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-17 18:27:25 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-17 18:27:25 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-17 18:27:25 --> Final output sent to browser
DEBUG - 2011-10-17 18:27:25 --> Total execution time: 0.3024
DEBUG - 2011-10-17 18:27:32 --> Config Class Initialized
DEBUG - 2011-10-17 18:27:32 --> Hooks Class Initialized
DEBUG - 2011-10-17 18:27:32 --> Utf8 Class Initialized
DEBUG - 2011-10-17 18:27:32 --> UTF-8 Support Enabled
DEBUG - 2011-10-17 18:27:32 --> URI Class Initialized
DEBUG - 2011-10-17 18:27:32 --> Router Class Initialized
DEBUG - 2011-10-17 18:27:32 --> Output Class Initialized
DEBUG - 2011-10-17 18:27:32 --> Input Class Initialized
DEBUG - 2011-10-17 18:27:32 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-17 18:27:32 --> Language Class Initialized
DEBUG - 2011-10-17 18:27:32 --> Loader Class Initialized
DEBUG - 2011-10-17 18:27:32 --> Controller Class Initialized
DEBUG - 2011-10-17 18:27:32 --> Model Class Initialized
DEBUG - 2011-10-17 18:27:32 --> Model Class Initialized
DEBUG - 2011-10-17 18:27:32 --> Model Class Initialized
DEBUG - 2011-10-17 18:27:32 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-17 18:27:32 --> Database Driver Class Initialized
DEBUG - 2011-10-17 18:27:32 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-17 18:27:32 --> Helper loaded: url_helper
DEBUG - 2011-10-17 18:27:32 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-17 18:27:32 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-17 18:27:32 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-17 18:27:32 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-17 18:27:32 --> Final output sent to browser
DEBUG - 2011-10-17 18:27:32 --> Total execution time: 0.3254
DEBUG - 2011-10-17 18:27:50 --> Config Class Initialized
DEBUG - 2011-10-17 18:27:50 --> Hooks Class Initialized
DEBUG - 2011-10-17 18:27:50 --> Utf8 Class Initialized
DEBUG - 2011-10-17 18:27:50 --> UTF-8 Support Enabled
DEBUG - 2011-10-17 18:27:50 --> URI Class Initialized
DEBUG - 2011-10-17 18:27:50 --> Router Class Initialized
DEBUG - 2011-10-17 18:27:50 --> Output Class Initialized
DEBUG - 2011-10-17 18:27:50 --> Input Class Initialized
DEBUG - 2011-10-17 18:27:50 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-17 18:27:50 --> Language Class Initialized
DEBUG - 2011-10-17 18:27:50 --> Loader Class Initialized
DEBUG - 2011-10-17 18:27:50 --> Controller Class Initialized
DEBUG - 2011-10-17 18:27:50 --> Model Class Initialized
DEBUG - 2011-10-17 18:27:50 --> Model Class Initialized
DEBUG - 2011-10-17 18:27:50 --> Model Class Initialized
DEBUG - 2011-10-17 18:27:50 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-17 18:27:50 --> Database Driver Class Initialized
DEBUG - 2011-10-17 18:27:50 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-17 18:27:50 --> Helper loaded: url_helper
DEBUG - 2011-10-17 18:27:50 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-17 18:27:50 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-17 18:27:50 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-17 18:27:50 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-17 18:27:50 --> Final output sent to browser
DEBUG - 2011-10-17 18:27:50 --> Total execution time: 0.6861
DEBUG - 2011-10-17 18:28:01 --> Config Class Initialized
DEBUG - 2011-10-17 18:28:01 --> Hooks Class Initialized
DEBUG - 2011-10-17 18:28:01 --> Utf8 Class Initialized
DEBUG - 2011-10-17 18:28:01 --> UTF-8 Support Enabled
DEBUG - 2011-10-17 18:28:01 --> URI Class Initialized
DEBUG - 2011-10-17 18:28:01 --> Router Class Initialized
DEBUG - 2011-10-17 18:28:01 --> Output Class Initialized
DEBUG - 2011-10-17 18:28:01 --> Input Class Initialized
DEBUG - 2011-10-17 18:28:01 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-17 18:28:01 --> Language Class Initialized
DEBUG - 2011-10-17 18:28:01 --> Loader Class Initialized
DEBUG - 2011-10-17 18:28:01 --> Controller Class Initialized
DEBUG - 2011-10-17 18:28:01 --> Model Class Initialized
DEBUG - 2011-10-17 18:28:01 --> Model Class Initialized
DEBUG - 2011-10-17 18:28:01 --> Model Class Initialized
DEBUG - 2011-10-17 18:28:01 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-17 18:28:01 --> Database Driver Class Initialized
DEBUG - 2011-10-17 18:28:02 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-17 18:28:02 --> Helper loaded: url_helper
DEBUG - 2011-10-17 18:28:02 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-17 18:28:02 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-17 18:28:02 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-17 18:28:02 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-17 18:28:02 --> Final output sent to browser
DEBUG - 2011-10-17 18:28:02 --> Total execution time: 0.4711
DEBUG - 2011-10-17 18:28:06 --> Config Class Initialized
DEBUG - 2011-10-17 18:28:06 --> Hooks Class Initialized
DEBUG - 2011-10-17 18:28:06 --> Utf8 Class Initialized
DEBUG - 2011-10-17 18:28:06 --> UTF-8 Support Enabled
DEBUG - 2011-10-17 18:28:06 --> URI Class Initialized
DEBUG - 2011-10-17 18:28:06 --> Router Class Initialized
DEBUG - 2011-10-17 18:28:06 --> Output Class Initialized
DEBUG - 2011-10-17 18:28:06 --> Input Class Initialized
DEBUG - 2011-10-17 18:28:06 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-17 18:28:06 --> Language Class Initialized
DEBUG - 2011-10-17 18:28:06 --> Loader Class Initialized
DEBUG - 2011-10-17 18:28:06 --> Controller Class Initialized
DEBUG - 2011-10-17 18:28:06 --> Model Class Initialized
DEBUG - 2011-10-17 18:28:06 --> Model Class Initialized
DEBUG - 2011-10-17 18:28:06 --> Model Class Initialized
DEBUG - 2011-10-17 18:28:06 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-17 18:28:06 --> Database Driver Class Initialized
DEBUG - 2011-10-17 18:28:06 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-17 18:28:06 --> Helper loaded: url_helper
DEBUG - 2011-10-17 18:28:06 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-17 18:28:06 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-17 18:28:06 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-17 18:28:06 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-17 18:28:06 --> Final output sent to browser
DEBUG - 2011-10-17 18:28:06 --> Total execution time: 0.0459
DEBUG - 2011-10-17 18:28:11 --> Config Class Initialized
DEBUG - 2011-10-17 18:28:11 --> Hooks Class Initialized
DEBUG - 2011-10-17 18:28:11 --> Utf8 Class Initialized
DEBUG - 2011-10-17 18:28:11 --> UTF-8 Support Enabled
DEBUG - 2011-10-17 18:28:11 --> URI Class Initialized
DEBUG - 2011-10-17 18:28:11 --> Router Class Initialized
DEBUG - 2011-10-17 18:28:11 --> Output Class Initialized
DEBUG - 2011-10-17 18:28:11 --> Input Class Initialized
DEBUG - 2011-10-17 18:28:11 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-17 18:28:11 --> Language Class Initialized
DEBUG - 2011-10-17 18:28:11 --> Loader Class Initialized
DEBUG - 2011-10-17 18:28:11 --> Controller Class Initialized
DEBUG - 2011-10-17 18:28:11 --> Model Class Initialized
DEBUG - 2011-10-17 18:28:11 --> Model Class Initialized
DEBUG - 2011-10-17 18:28:11 --> Model Class Initialized
DEBUG - 2011-10-17 18:28:11 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-17 18:28:11 --> Database Driver Class Initialized
DEBUG - 2011-10-17 18:28:12 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-17 18:28:12 --> Helper loaded: url_helper
DEBUG - 2011-10-17 18:28:12 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-17 18:28:12 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-17 18:28:12 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-17 18:28:12 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-17 18:28:12 --> Final output sent to browser
DEBUG - 2011-10-17 18:28:12 --> Total execution time: 0.4667
DEBUG - 2011-10-17 18:28:14 --> Config Class Initialized
DEBUG - 2011-10-17 18:28:14 --> Hooks Class Initialized
DEBUG - 2011-10-17 18:28:14 --> Utf8 Class Initialized
DEBUG - 2011-10-17 18:28:14 --> UTF-8 Support Enabled
DEBUG - 2011-10-17 18:28:14 --> URI Class Initialized
DEBUG - 2011-10-17 18:28:14 --> Router Class Initialized
DEBUG - 2011-10-17 18:28:14 --> Output Class Initialized
DEBUG - 2011-10-17 18:28:14 --> Input Class Initialized
DEBUG - 2011-10-17 18:28:14 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-17 18:28:14 --> Language Class Initialized
DEBUG - 2011-10-17 18:28:14 --> Loader Class Initialized
DEBUG - 2011-10-17 18:28:14 --> Controller Class Initialized
DEBUG - 2011-10-17 18:28:14 --> Model Class Initialized
DEBUG - 2011-10-17 18:28:14 --> Model Class Initialized
DEBUG - 2011-10-17 18:28:14 --> Model Class Initialized
DEBUG - 2011-10-17 18:28:14 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-17 18:28:14 --> Database Driver Class Initialized
DEBUG - 2011-10-17 18:28:14 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-17 18:28:14 --> Helper loaded: url_helper
DEBUG - 2011-10-17 18:28:14 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-17 18:28:14 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-17 18:28:14 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-17 18:28:14 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-17 18:28:14 --> Final output sent to browser
DEBUG - 2011-10-17 18:28:14 --> Total execution time: 0.0436
DEBUG - 2011-10-17 18:28:19 --> Config Class Initialized
DEBUG - 2011-10-17 18:28:19 --> Hooks Class Initialized
DEBUG - 2011-10-17 18:28:19 --> Utf8 Class Initialized
DEBUG - 2011-10-17 18:28:19 --> UTF-8 Support Enabled
DEBUG - 2011-10-17 18:28:19 --> URI Class Initialized
DEBUG - 2011-10-17 18:28:19 --> Router Class Initialized
DEBUG - 2011-10-17 18:28:19 --> Output Class Initialized
DEBUG - 2011-10-17 18:28:19 --> Input Class Initialized
DEBUG - 2011-10-17 18:28:19 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-17 18:28:19 --> Language Class Initialized
DEBUG - 2011-10-17 18:28:19 --> Loader Class Initialized
DEBUG - 2011-10-17 18:28:19 --> Controller Class Initialized
DEBUG - 2011-10-17 18:28:19 --> Model Class Initialized
DEBUG - 2011-10-17 18:28:19 --> Model Class Initialized
DEBUG - 2011-10-17 18:28:19 --> Model Class Initialized
DEBUG - 2011-10-17 18:28:19 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-17 18:28:19 --> Database Driver Class Initialized
DEBUG - 2011-10-17 18:28:19 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-17 18:28:19 --> Helper loaded: url_helper
DEBUG - 2011-10-17 18:28:19 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-17 18:28:19 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-17 18:28:19 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-17 18:28:19 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-17 18:28:19 --> Final output sent to browser
DEBUG - 2011-10-17 18:28:19 --> Total execution time: 0.2406
DEBUG - 2011-10-17 18:28:22 --> Config Class Initialized
DEBUG - 2011-10-17 18:28:22 --> Hooks Class Initialized
DEBUG - 2011-10-17 18:28:22 --> Utf8 Class Initialized
DEBUG - 2011-10-17 18:28:22 --> UTF-8 Support Enabled
DEBUG - 2011-10-17 18:28:22 --> URI Class Initialized
DEBUG - 2011-10-17 18:28:22 --> Router Class Initialized
DEBUG - 2011-10-17 18:28:22 --> Output Class Initialized
DEBUG - 2011-10-17 18:28:22 --> Input Class Initialized
DEBUG - 2011-10-17 18:28:22 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-17 18:28:22 --> Language Class Initialized
DEBUG - 2011-10-17 18:28:22 --> Loader Class Initialized
DEBUG - 2011-10-17 18:28:22 --> Controller Class Initialized
DEBUG - 2011-10-17 18:28:22 --> Model Class Initialized
DEBUG - 2011-10-17 18:28:22 --> Model Class Initialized
DEBUG - 2011-10-17 18:28:22 --> Model Class Initialized
DEBUG - 2011-10-17 18:28:22 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-17 18:28:22 --> Database Driver Class Initialized
DEBUG - 2011-10-17 18:28:22 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-17 18:28:22 --> Helper loaded: url_helper
DEBUG - 2011-10-17 18:28:22 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-17 18:28:22 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-17 18:28:22 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-17 18:28:22 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-17 18:28:22 --> Final output sent to browser
DEBUG - 2011-10-17 18:28:22 --> Total execution time: 0.0498
DEBUG - 2011-10-17 18:28:26 --> Config Class Initialized
DEBUG - 2011-10-17 18:28:26 --> Hooks Class Initialized
DEBUG - 2011-10-17 18:28:26 --> Utf8 Class Initialized
DEBUG - 2011-10-17 18:28:26 --> UTF-8 Support Enabled
DEBUG - 2011-10-17 18:28:26 --> URI Class Initialized
DEBUG - 2011-10-17 18:28:26 --> Router Class Initialized
DEBUG - 2011-10-17 18:28:26 --> Output Class Initialized
DEBUG - 2011-10-17 18:28:26 --> Input Class Initialized
DEBUG - 2011-10-17 18:28:26 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-17 18:28:26 --> Language Class Initialized
DEBUG - 2011-10-17 18:28:26 --> Loader Class Initialized
DEBUG - 2011-10-17 18:28:26 --> Controller Class Initialized
DEBUG - 2011-10-17 18:28:26 --> Model Class Initialized
DEBUG - 2011-10-17 18:28:26 --> Model Class Initialized
DEBUG - 2011-10-17 18:28:26 --> Model Class Initialized
DEBUG - 2011-10-17 18:28:26 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-17 18:28:26 --> Database Driver Class Initialized
DEBUG - 2011-10-17 18:28:26 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-17 18:28:26 --> Helper loaded: url_helper
DEBUG - 2011-10-17 18:28:26 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-17 18:28:26 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-17 18:28:26 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-17 18:28:26 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-17 18:28:26 --> Final output sent to browser
DEBUG - 2011-10-17 18:28:26 --> Total execution time: 0.2995
DEBUG - 2011-10-17 18:28:29 --> Config Class Initialized
DEBUG - 2011-10-17 18:28:29 --> Hooks Class Initialized
DEBUG - 2011-10-17 18:28:29 --> Utf8 Class Initialized
DEBUG - 2011-10-17 18:28:29 --> UTF-8 Support Enabled
DEBUG - 2011-10-17 18:28:29 --> URI Class Initialized
DEBUG - 2011-10-17 18:28:29 --> Router Class Initialized
DEBUG - 2011-10-17 18:28:29 --> Output Class Initialized
DEBUG - 2011-10-17 18:28:29 --> Input Class Initialized
DEBUG - 2011-10-17 18:28:29 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-17 18:28:29 --> Language Class Initialized
DEBUG - 2011-10-17 18:28:29 --> Loader Class Initialized
DEBUG - 2011-10-17 18:28:29 --> Controller Class Initialized
DEBUG - 2011-10-17 18:28:29 --> Model Class Initialized
DEBUG - 2011-10-17 18:28:29 --> Model Class Initialized
DEBUG - 2011-10-17 18:28:29 --> Model Class Initialized
DEBUG - 2011-10-17 18:28:29 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-17 18:28:29 --> Database Driver Class Initialized
DEBUG - 2011-10-17 18:28:29 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-17 18:28:29 --> Helper loaded: url_helper
DEBUG - 2011-10-17 18:28:29 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-17 18:28:29 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-17 18:28:29 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-17 18:28:29 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-17 18:28:29 --> Final output sent to browser
DEBUG - 2011-10-17 18:28:29 --> Total execution time: 0.0485
DEBUG - 2011-10-17 18:28:29 --> Config Class Initialized
DEBUG - 2011-10-17 18:28:29 --> Hooks Class Initialized
DEBUG - 2011-10-17 18:28:29 --> Utf8 Class Initialized
DEBUG - 2011-10-17 18:28:29 --> UTF-8 Support Enabled
DEBUG - 2011-10-17 18:28:29 --> URI Class Initialized
DEBUG - 2011-10-17 18:28:29 --> Router Class Initialized
ERROR - 2011-10-17 18:28:29 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-10-17 18:28:37 --> Config Class Initialized
DEBUG - 2011-10-17 18:28:37 --> Hooks Class Initialized
DEBUG - 2011-10-17 18:28:37 --> Utf8 Class Initialized
DEBUG - 2011-10-17 18:28:37 --> UTF-8 Support Enabled
DEBUG - 2011-10-17 18:28:37 --> URI Class Initialized
DEBUG - 2011-10-17 18:28:37 --> Router Class Initialized
DEBUG - 2011-10-17 18:28:37 --> Output Class Initialized
DEBUG - 2011-10-17 18:28:37 --> Input Class Initialized
DEBUG - 2011-10-17 18:28:37 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-17 18:28:37 --> Language Class Initialized
DEBUG - 2011-10-17 18:28:37 --> Loader Class Initialized
DEBUG - 2011-10-17 18:28:37 --> Controller Class Initialized
DEBUG - 2011-10-17 18:28:37 --> Model Class Initialized
DEBUG - 2011-10-17 18:28:37 --> Model Class Initialized
DEBUG - 2011-10-17 18:28:37 --> Model Class Initialized
DEBUG - 2011-10-17 18:28:37 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-17 18:28:37 --> Database Driver Class Initialized
DEBUG - 2011-10-17 18:28:37 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-17 18:28:37 --> Helper loaded: url_helper
DEBUG - 2011-10-17 18:28:37 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-17 18:28:37 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-17 18:28:37 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-17 18:28:37 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-17 18:28:37 --> Final output sent to browser
DEBUG - 2011-10-17 18:28:37 --> Total execution time: 0.3455
DEBUG - 2011-10-17 18:28:47 --> Config Class Initialized
DEBUG - 2011-10-17 18:28:47 --> Hooks Class Initialized
DEBUG - 2011-10-17 18:28:47 --> Utf8 Class Initialized
DEBUG - 2011-10-17 18:28:47 --> UTF-8 Support Enabled
DEBUG - 2011-10-17 18:28:47 --> URI Class Initialized
DEBUG - 2011-10-17 18:28:47 --> Router Class Initialized
DEBUG - 2011-10-17 18:28:47 --> Output Class Initialized
DEBUG - 2011-10-17 18:28:47 --> Input Class Initialized
DEBUG - 2011-10-17 18:28:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-17 18:28:47 --> Language Class Initialized
DEBUG - 2011-10-17 18:28:47 --> Loader Class Initialized
DEBUG - 2011-10-17 18:28:47 --> Controller Class Initialized
DEBUG - 2011-10-17 18:28:47 --> Model Class Initialized
DEBUG - 2011-10-17 18:28:47 --> Model Class Initialized
DEBUG - 2011-10-17 18:28:47 --> Model Class Initialized
DEBUG - 2011-10-17 18:28:47 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-17 18:28:47 --> Database Driver Class Initialized
DEBUG - 2011-10-17 18:28:47 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-17 18:28:47 --> Helper loaded: url_helper
DEBUG - 2011-10-17 18:28:47 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-17 18:28:47 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-17 18:28:47 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-17 18:28:47 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-17 18:28:47 --> Final output sent to browser
DEBUG - 2011-10-17 18:28:47 --> Total execution time: 0.0636
DEBUG - 2011-10-17 18:28:56 --> Config Class Initialized
DEBUG - 2011-10-17 18:28:56 --> Hooks Class Initialized
DEBUG - 2011-10-17 18:28:56 --> Utf8 Class Initialized
DEBUG - 2011-10-17 18:28:56 --> UTF-8 Support Enabled
DEBUG - 2011-10-17 18:28:56 --> URI Class Initialized
DEBUG - 2011-10-17 18:28:56 --> Router Class Initialized
DEBUG - 2011-10-17 18:28:56 --> Output Class Initialized
DEBUG - 2011-10-17 18:28:56 --> Input Class Initialized
DEBUG - 2011-10-17 18:28:56 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-17 18:28:56 --> Language Class Initialized
DEBUG - 2011-10-17 18:28:56 --> Loader Class Initialized
DEBUG - 2011-10-17 18:28:56 --> Controller Class Initialized
DEBUG - 2011-10-17 18:28:56 --> Model Class Initialized
DEBUG - 2011-10-17 18:28:56 --> Model Class Initialized
DEBUG - 2011-10-17 18:28:56 --> Model Class Initialized
DEBUG - 2011-10-17 18:28:56 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-17 18:28:56 --> Database Driver Class Initialized
DEBUG - 2011-10-17 18:28:56 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-17 18:28:56 --> Helper loaded: url_helper
DEBUG - 2011-10-17 18:28:56 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-17 18:28:56 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-17 18:28:56 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-17 18:28:56 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-17 18:28:56 --> Final output sent to browser
DEBUG - 2011-10-17 18:28:56 --> Total execution time: 0.1921
DEBUG - 2011-10-17 18:50:37 --> Config Class Initialized
DEBUG - 2011-10-17 18:50:37 --> Hooks Class Initialized
DEBUG - 2011-10-17 18:50:37 --> Utf8 Class Initialized
DEBUG - 2011-10-17 18:50:37 --> UTF-8 Support Enabled
DEBUG - 2011-10-17 18:50:37 --> URI Class Initialized
DEBUG - 2011-10-17 18:50:37 --> Router Class Initialized
ERROR - 2011-10-17 18:50:37 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-10-17 18:50:37 --> Config Class Initialized
DEBUG - 2011-10-17 18:50:37 --> Hooks Class Initialized
DEBUG - 2011-10-17 18:50:37 --> Utf8 Class Initialized
DEBUG - 2011-10-17 18:50:37 --> UTF-8 Support Enabled
DEBUG - 2011-10-17 18:50:37 --> URI Class Initialized
DEBUG - 2011-10-17 18:50:37 --> Router Class Initialized
DEBUG - 2011-10-17 18:50:37 --> Output Class Initialized
DEBUG - 2011-10-17 18:50:37 --> Input Class Initialized
DEBUG - 2011-10-17 18:50:37 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-17 18:50:37 --> Language Class Initialized
DEBUG - 2011-10-17 18:50:37 --> Loader Class Initialized
DEBUG - 2011-10-17 18:50:37 --> Controller Class Initialized
DEBUG - 2011-10-17 18:50:37 --> Model Class Initialized
DEBUG - 2011-10-17 18:50:37 --> Model Class Initialized
DEBUG - 2011-10-17 18:50:37 --> Model Class Initialized
DEBUG - 2011-10-17 18:50:37 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-17 18:50:37 --> Database Driver Class Initialized
DEBUG - 2011-10-17 18:50:37 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-17 18:50:37 --> Helper loaded: url_helper
DEBUG - 2011-10-17 18:50:37 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-17 18:50:37 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-17 18:50:37 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-17 18:50:37 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-17 18:50:37 --> Final output sent to browser
DEBUG - 2011-10-17 18:50:37 --> Total execution time: 0.0634
DEBUG - 2011-10-17 18:50:39 --> Config Class Initialized
DEBUG - 2011-10-17 18:50:39 --> Hooks Class Initialized
DEBUG - 2011-10-17 18:50:39 --> Utf8 Class Initialized
DEBUG - 2011-10-17 18:50:39 --> UTF-8 Support Enabled
DEBUG - 2011-10-17 18:50:39 --> URI Class Initialized
DEBUG - 2011-10-17 18:50:39 --> Router Class Initialized
DEBUG - 2011-10-17 18:50:39 --> Output Class Initialized
DEBUG - 2011-10-17 18:50:39 --> Input Class Initialized
DEBUG - 2011-10-17 18:50:39 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-17 18:50:39 --> Language Class Initialized
DEBUG - 2011-10-17 18:50:39 --> Loader Class Initialized
DEBUG - 2011-10-17 18:50:39 --> Controller Class Initialized
ERROR - 2011-10-17 18:50:39 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-10-17 18:50:39 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-10-17 18:50:39 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-17 18:50:39 --> Model Class Initialized
DEBUG - 2011-10-17 18:50:39 --> Model Class Initialized
DEBUG - 2011-10-17 18:50:39 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-17 18:50:39 --> Database Driver Class Initialized
DEBUG - 2011-10-17 18:50:39 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-17 18:50:39 --> Helper loaded: url_helper
DEBUG - 2011-10-17 18:50:39 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-17 18:50:39 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-17 18:50:39 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-17 18:50:39 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-17 18:50:39 --> Final output sent to browser
DEBUG - 2011-10-17 18:50:39 --> Total execution time: 0.0367
DEBUG - 2011-10-17 19:19:11 --> Config Class Initialized
DEBUG - 2011-10-17 19:19:11 --> Hooks Class Initialized
DEBUG - 2011-10-17 19:19:11 --> Utf8 Class Initialized
DEBUG - 2011-10-17 19:19:11 --> UTF-8 Support Enabled
DEBUG - 2011-10-17 19:19:11 --> URI Class Initialized
DEBUG - 2011-10-17 19:19:11 --> Router Class Initialized
DEBUG - 2011-10-17 19:19:11 --> Output Class Initialized
DEBUG - 2011-10-17 19:19:11 --> Input Class Initialized
DEBUG - 2011-10-17 19:19:11 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-17 19:19:11 --> Language Class Initialized
DEBUG - 2011-10-17 19:19:11 --> Loader Class Initialized
DEBUG - 2011-10-17 19:19:11 --> Controller Class Initialized
DEBUG - 2011-10-17 19:19:11 --> Model Class Initialized
DEBUG - 2011-10-17 19:19:11 --> Model Class Initialized
DEBUG - 2011-10-17 19:19:11 --> Model Class Initialized
DEBUG - 2011-10-17 19:19:11 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-17 19:19:11 --> Database Driver Class Initialized
DEBUG - 2011-10-17 19:19:12 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-17 19:19:12 --> Helper loaded: url_helper
DEBUG - 2011-10-17 19:19:12 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-17 19:19:12 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-17 19:19:12 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-17 19:19:12 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-17 19:19:12 --> Final output sent to browser
DEBUG - 2011-10-17 19:19:12 --> Total execution time: 0.6768
DEBUG - 2011-10-17 19:19:16 --> Config Class Initialized
DEBUG - 2011-10-17 19:19:16 --> Hooks Class Initialized
DEBUG - 2011-10-17 19:19:16 --> Utf8 Class Initialized
DEBUG - 2011-10-17 19:19:16 --> UTF-8 Support Enabled
DEBUG - 2011-10-17 19:19:16 --> URI Class Initialized
DEBUG - 2011-10-17 19:19:16 --> Router Class Initialized
ERROR - 2011-10-17 19:19:16 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-17 19:19:51 --> Config Class Initialized
DEBUG - 2011-10-17 19:19:51 --> Hooks Class Initialized
DEBUG - 2011-10-17 19:19:51 --> Utf8 Class Initialized
DEBUG - 2011-10-17 19:19:51 --> UTF-8 Support Enabled
DEBUG - 2011-10-17 19:19:51 --> URI Class Initialized
DEBUG - 2011-10-17 19:19:51 --> Router Class Initialized
DEBUG - 2011-10-17 19:19:51 --> Output Class Initialized
DEBUG - 2011-10-17 19:19:51 --> Input Class Initialized
DEBUG - 2011-10-17 19:19:51 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-17 19:19:51 --> Language Class Initialized
DEBUG - 2011-10-17 19:19:51 --> Loader Class Initialized
DEBUG - 2011-10-17 19:19:51 --> Controller Class Initialized
DEBUG - 2011-10-17 19:19:51 --> Model Class Initialized
DEBUG - 2011-10-17 19:19:51 --> Model Class Initialized
DEBUG - 2011-10-17 19:19:51 --> Model Class Initialized
DEBUG - 2011-10-17 19:19:51 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-17 19:19:51 --> Database Driver Class Initialized
DEBUG - 2011-10-17 19:19:52 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-17 19:19:52 --> Helper loaded: url_helper
DEBUG - 2011-10-17 19:19:52 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-17 19:19:52 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-17 19:19:52 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-17 19:19:52 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-17 19:19:52 --> Final output sent to browser
DEBUG - 2011-10-17 19:19:52 --> Total execution time: 0.4003
DEBUG - 2011-10-17 19:19:54 --> Config Class Initialized
DEBUG - 2011-10-17 19:19:54 --> Hooks Class Initialized
DEBUG - 2011-10-17 19:19:54 --> Utf8 Class Initialized
DEBUG - 2011-10-17 19:19:54 --> UTF-8 Support Enabled
DEBUG - 2011-10-17 19:19:54 --> URI Class Initialized
DEBUG - 2011-10-17 19:19:54 --> Router Class Initialized
DEBUG - 2011-10-17 19:19:54 --> Output Class Initialized
DEBUG - 2011-10-17 19:19:54 --> Input Class Initialized
DEBUG - 2011-10-17 19:19:54 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-17 19:19:54 --> Language Class Initialized
DEBUG - 2011-10-17 19:19:54 --> Loader Class Initialized
DEBUG - 2011-10-17 19:19:54 --> Controller Class Initialized
DEBUG - 2011-10-17 19:19:54 --> Model Class Initialized
DEBUG - 2011-10-17 19:19:54 --> Model Class Initialized
DEBUG - 2011-10-17 19:19:54 --> Model Class Initialized
DEBUG - 2011-10-17 19:19:54 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-17 19:19:54 --> Database Driver Class Initialized
DEBUG - 2011-10-17 19:19:54 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-17 19:19:54 --> Helper loaded: url_helper
DEBUG - 2011-10-17 19:19:54 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-17 19:19:54 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-17 19:19:54 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-17 19:19:54 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-17 19:19:54 --> Final output sent to browser
DEBUG - 2011-10-17 19:19:54 --> Total execution time: 0.1047
DEBUG - 2011-10-17 19:20:09 --> Config Class Initialized
DEBUG - 2011-10-17 19:20:09 --> Hooks Class Initialized
DEBUG - 2011-10-17 19:20:09 --> Utf8 Class Initialized
DEBUG - 2011-10-17 19:20:09 --> UTF-8 Support Enabled
DEBUG - 2011-10-17 19:20:09 --> URI Class Initialized
DEBUG - 2011-10-17 19:20:09 --> Router Class Initialized
DEBUG - 2011-10-17 19:20:09 --> Output Class Initialized
DEBUG - 2011-10-17 19:20:09 --> Input Class Initialized
DEBUG - 2011-10-17 19:20:09 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-17 19:20:09 --> Language Class Initialized
DEBUG - 2011-10-17 19:20:09 --> Loader Class Initialized
DEBUG - 2011-10-17 19:20:09 --> Controller Class Initialized
DEBUG - 2011-10-17 19:20:09 --> Model Class Initialized
DEBUG - 2011-10-17 19:20:09 --> Model Class Initialized
DEBUG - 2011-10-17 19:20:09 --> Model Class Initialized
DEBUG - 2011-10-17 19:20:09 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-17 19:20:09 --> Database Driver Class Initialized
DEBUG - 2011-10-17 19:20:09 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-17 19:20:09 --> Helper loaded: url_helper
DEBUG - 2011-10-17 19:20:09 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-17 19:20:09 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-17 19:20:09 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-17 19:20:09 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-17 19:20:09 --> Final output sent to browser
DEBUG - 2011-10-17 19:20:09 --> Total execution time: 0.3199
DEBUG - 2011-10-17 19:20:12 --> Config Class Initialized
DEBUG - 2011-10-17 19:20:12 --> Hooks Class Initialized
DEBUG - 2011-10-17 19:20:12 --> Utf8 Class Initialized
DEBUG - 2011-10-17 19:20:12 --> UTF-8 Support Enabled
DEBUG - 2011-10-17 19:20:12 --> URI Class Initialized
DEBUG - 2011-10-17 19:20:12 --> Router Class Initialized
DEBUG - 2011-10-17 19:20:12 --> Output Class Initialized
DEBUG - 2011-10-17 19:20:12 --> Input Class Initialized
DEBUG - 2011-10-17 19:20:12 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-17 19:20:12 --> Language Class Initialized
DEBUG - 2011-10-17 19:20:12 --> Loader Class Initialized
DEBUG - 2011-10-17 19:20:12 --> Controller Class Initialized
DEBUG - 2011-10-17 19:20:12 --> Model Class Initialized
DEBUG - 2011-10-17 19:20:12 --> Model Class Initialized
DEBUG - 2011-10-17 19:20:12 --> Model Class Initialized
DEBUG - 2011-10-17 19:20:12 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-17 19:20:12 --> Database Driver Class Initialized
DEBUG - 2011-10-17 19:20:12 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-17 19:20:12 --> Helper loaded: url_helper
DEBUG - 2011-10-17 19:20:12 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-17 19:20:12 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-17 19:20:12 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-17 19:20:12 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-17 19:20:12 --> Final output sent to browser
DEBUG - 2011-10-17 19:20:12 --> Total execution time: 0.0789
DEBUG - 2011-10-17 19:20:33 --> Config Class Initialized
DEBUG - 2011-10-17 19:20:33 --> Hooks Class Initialized
DEBUG - 2011-10-17 19:20:33 --> Utf8 Class Initialized
DEBUG - 2011-10-17 19:20:33 --> UTF-8 Support Enabled
DEBUG - 2011-10-17 19:20:33 --> URI Class Initialized
DEBUG - 2011-10-17 19:20:33 --> Router Class Initialized
DEBUG - 2011-10-17 19:20:33 --> Output Class Initialized
DEBUG - 2011-10-17 19:20:33 --> Input Class Initialized
DEBUG - 2011-10-17 19:20:33 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-17 19:20:33 --> Language Class Initialized
DEBUG - 2011-10-17 19:20:33 --> Loader Class Initialized
DEBUG - 2011-10-17 19:20:33 --> Controller Class Initialized
ERROR - 2011-10-17 19:20:33 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-10-17 19:20:33 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-10-17 19:20:33 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-17 19:20:33 --> Model Class Initialized
DEBUG - 2011-10-17 19:20:33 --> Model Class Initialized
DEBUG - 2011-10-17 19:20:33 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-17 19:20:33 --> Database Driver Class Initialized
DEBUG - 2011-10-17 19:20:33 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-17 19:20:33 --> Helper loaded: url_helper
DEBUG - 2011-10-17 19:20:33 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-17 19:20:33 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-17 19:20:33 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-17 19:20:33 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-17 19:20:33 --> Final output sent to browser
DEBUG - 2011-10-17 19:20:33 --> Total execution time: 0.0306
DEBUG - 2011-10-17 19:20:35 --> Config Class Initialized
DEBUG - 2011-10-17 19:20:35 --> Hooks Class Initialized
DEBUG - 2011-10-17 19:20:35 --> Utf8 Class Initialized
DEBUG - 2011-10-17 19:20:35 --> UTF-8 Support Enabled
DEBUG - 2011-10-17 19:20:35 --> URI Class Initialized
DEBUG - 2011-10-17 19:20:35 --> Router Class Initialized
DEBUG - 2011-10-17 19:20:35 --> Output Class Initialized
DEBUG - 2011-10-17 19:20:35 --> Input Class Initialized
DEBUG - 2011-10-17 19:20:35 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-17 19:20:35 --> Language Class Initialized
DEBUG - 2011-10-17 19:20:35 --> Loader Class Initialized
DEBUG - 2011-10-17 19:20:35 --> Controller Class Initialized
DEBUG - 2011-10-17 19:20:35 --> Model Class Initialized
DEBUG - 2011-10-17 19:20:35 --> Model Class Initialized
DEBUG - 2011-10-17 19:20:35 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-17 19:20:35 --> Database Driver Class Initialized
DEBUG - 2011-10-17 19:20:36 --> Final output sent to browser
DEBUG - 2011-10-17 19:20:36 --> Total execution time: 0.7111
DEBUG - 2011-10-17 19:21:37 --> Config Class Initialized
DEBUG - 2011-10-17 19:21:37 --> Hooks Class Initialized
DEBUG - 2011-10-17 19:21:37 --> Utf8 Class Initialized
DEBUG - 2011-10-17 19:21:37 --> UTF-8 Support Enabled
DEBUG - 2011-10-17 19:21:37 --> URI Class Initialized
DEBUG - 2011-10-17 19:21:37 --> Router Class Initialized
DEBUG - 2011-10-17 19:21:37 --> Output Class Initialized
DEBUG - 2011-10-17 19:21:37 --> Input Class Initialized
DEBUG - 2011-10-17 19:21:37 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-17 19:21:37 --> Language Class Initialized
DEBUG - 2011-10-17 19:21:37 --> Loader Class Initialized
DEBUG - 2011-10-17 19:21:37 --> Controller Class Initialized
ERROR - 2011-10-17 19:21:37 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-10-17 19:21:37 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-10-17 19:21:37 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-17 19:21:37 --> Model Class Initialized
DEBUG - 2011-10-17 19:21:37 --> Model Class Initialized
DEBUG - 2011-10-17 19:21:37 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-17 19:21:37 --> Database Driver Class Initialized
DEBUG - 2011-10-17 19:21:37 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-17 19:21:37 --> Helper loaded: url_helper
DEBUG - 2011-10-17 19:21:37 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-17 19:21:37 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-17 19:21:37 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-17 19:21:37 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-17 19:21:37 --> Final output sent to browser
DEBUG - 2011-10-17 19:21:37 --> Total execution time: 0.0296
DEBUG - 2011-10-17 19:21:37 --> Config Class Initialized
DEBUG - 2011-10-17 19:21:37 --> Hooks Class Initialized
DEBUG - 2011-10-17 19:21:37 --> Utf8 Class Initialized
DEBUG - 2011-10-17 19:21:37 --> UTF-8 Support Enabled
DEBUG - 2011-10-17 19:21:37 --> URI Class Initialized
DEBUG - 2011-10-17 19:21:37 --> Router Class Initialized
DEBUG - 2011-10-17 19:21:37 --> Output Class Initialized
DEBUG - 2011-10-17 19:21:37 --> Input Class Initialized
DEBUG - 2011-10-17 19:21:37 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-17 19:21:37 --> Language Class Initialized
DEBUG - 2011-10-17 19:21:37 --> Loader Class Initialized
DEBUG - 2011-10-17 19:21:37 --> Controller Class Initialized
DEBUG - 2011-10-17 19:21:37 --> Model Class Initialized
DEBUG - 2011-10-17 19:21:37 --> Model Class Initialized
DEBUG - 2011-10-17 19:21:37 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-17 19:21:37 --> Database Driver Class Initialized
DEBUG - 2011-10-17 19:21:38 --> Final output sent to browser
DEBUG - 2011-10-17 19:21:38 --> Total execution time: 0.7284
DEBUG - 2011-10-17 19:21:57 --> Config Class Initialized
DEBUG - 2011-10-17 19:21:57 --> Hooks Class Initialized
DEBUG - 2011-10-17 19:21:57 --> Utf8 Class Initialized
DEBUG - 2011-10-17 19:21:57 --> UTF-8 Support Enabled
DEBUG - 2011-10-17 19:21:57 --> URI Class Initialized
DEBUG - 2011-10-17 19:21:57 --> Router Class Initialized
DEBUG - 2011-10-17 19:21:57 --> Output Class Initialized
DEBUG - 2011-10-17 19:21:57 --> Input Class Initialized
DEBUG - 2011-10-17 19:21:57 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-17 19:21:57 --> Language Class Initialized
DEBUG - 2011-10-17 19:21:57 --> Loader Class Initialized
DEBUG - 2011-10-17 19:21:57 --> Controller Class Initialized
ERROR - 2011-10-17 19:21:57 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-10-17 19:21:57 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-10-17 19:21:57 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-17 19:21:57 --> Model Class Initialized
DEBUG - 2011-10-17 19:21:57 --> Model Class Initialized
DEBUG - 2011-10-17 19:21:57 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-17 19:21:57 --> Database Driver Class Initialized
DEBUG - 2011-10-17 19:21:57 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-17 19:21:57 --> Helper loaded: url_helper
DEBUG - 2011-10-17 19:21:57 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-17 19:21:57 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-17 19:21:57 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-17 19:21:57 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-17 19:21:57 --> Final output sent to browser
DEBUG - 2011-10-17 19:21:57 --> Total execution time: 0.0321
DEBUG - 2011-10-17 19:21:58 --> Config Class Initialized
DEBUG - 2011-10-17 19:21:58 --> Hooks Class Initialized
DEBUG - 2011-10-17 19:21:58 --> Utf8 Class Initialized
DEBUG - 2011-10-17 19:21:58 --> UTF-8 Support Enabled
DEBUG - 2011-10-17 19:21:58 --> URI Class Initialized
DEBUG - 2011-10-17 19:21:58 --> Router Class Initialized
DEBUG - 2011-10-17 19:21:58 --> Output Class Initialized
DEBUG - 2011-10-17 19:21:58 --> Input Class Initialized
DEBUG - 2011-10-17 19:21:58 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-17 19:21:58 --> Language Class Initialized
DEBUG - 2011-10-17 19:21:58 --> Loader Class Initialized
DEBUG - 2011-10-17 19:21:58 --> Controller Class Initialized
DEBUG - 2011-10-17 19:21:58 --> Model Class Initialized
DEBUG - 2011-10-17 19:21:58 --> Model Class Initialized
DEBUG - 2011-10-17 19:21:58 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-17 19:21:58 --> Database Driver Class Initialized
DEBUG - 2011-10-17 19:21:59 --> Final output sent to browser
DEBUG - 2011-10-17 19:21:59 --> Total execution time: 0.5730
DEBUG - 2011-10-17 19:22:13 --> Config Class Initialized
DEBUG - 2011-10-17 19:22:13 --> Hooks Class Initialized
DEBUG - 2011-10-17 19:22:13 --> Utf8 Class Initialized
DEBUG - 2011-10-17 19:22:13 --> UTF-8 Support Enabled
DEBUG - 2011-10-17 19:22:13 --> URI Class Initialized
DEBUG - 2011-10-17 19:22:13 --> Router Class Initialized
DEBUG - 2011-10-17 19:22:13 --> Output Class Initialized
DEBUG - 2011-10-17 19:22:13 --> Input Class Initialized
DEBUG - 2011-10-17 19:22:13 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-17 19:22:13 --> Language Class Initialized
DEBUG - 2011-10-17 19:22:13 --> Loader Class Initialized
DEBUG - 2011-10-17 19:22:13 --> Controller Class Initialized
ERROR - 2011-10-17 19:22:13 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-10-17 19:22:13 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-10-17 19:22:13 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-17 19:22:13 --> Model Class Initialized
DEBUG - 2011-10-17 19:22:13 --> Model Class Initialized
DEBUG - 2011-10-17 19:22:13 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-17 19:22:13 --> Database Driver Class Initialized
DEBUG - 2011-10-17 19:22:13 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-17 19:22:13 --> Helper loaded: url_helper
DEBUG - 2011-10-17 19:22:13 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-17 19:22:13 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-17 19:22:13 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-17 19:22:13 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-17 19:22:13 --> Final output sent to browser
DEBUG - 2011-10-17 19:22:13 --> Total execution time: 0.0271
DEBUG - 2011-10-17 19:22:14 --> Config Class Initialized
DEBUG - 2011-10-17 19:22:14 --> Hooks Class Initialized
DEBUG - 2011-10-17 19:22:14 --> Utf8 Class Initialized
DEBUG - 2011-10-17 19:22:14 --> UTF-8 Support Enabled
DEBUG - 2011-10-17 19:22:14 --> URI Class Initialized
DEBUG - 2011-10-17 19:22:14 --> Router Class Initialized
DEBUG - 2011-10-17 19:22:14 --> Output Class Initialized
DEBUG - 2011-10-17 19:22:14 --> Input Class Initialized
DEBUG - 2011-10-17 19:22:14 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-17 19:22:14 --> Language Class Initialized
DEBUG - 2011-10-17 19:22:14 --> Loader Class Initialized
DEBUG - 2011-10-17 19:22:14 --> Controller Class Initialized
DEBUG - 2011-10-17 19:22:14 --> Model Class Initialized
DEBUG - 2011-10-17 19:22:14 --> Model Class Initialized
DEBUG - 2011-10-17 19:22:14 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-17 19:22:14 --> Database Driver Class Initialized
DEBUG - 2011-10-17 19:22:15 --> Final output sent to browser
DEBUG - 2011-10-17 19:22:15 --> Total execution time: 0.7076
DEBUG - 2011-10-17 19:22:22 --> Config Class Initialized
DEBUG - 2011-10-17 19:22:22 --> Hooks Class Initialized
DEBUG - 2011-10-17 19:22:22 --> Utf8 Class Initialized
DEBUG - 2011-10-17 19:22:22 --> UTF-8 Support Enabled
DEBUG - 2011-10-17 19:22:22 --> URI Class Initialized
DEBUG - 2011-10-17 19:22:22 --> Router Class Initialized
DEBUG - 2011-10-17 19:22:22 --> Output Class Initialized
DEBUG - 2011-10-17 19:22:22 --> Input Class Initialized
DEBUG - 2011-10-17 19:22:22 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-17 19:22:22 --> Language Class Initialized
DEBUG - 2011-10-17 19:22:22 --> Loader Class Initialized
DEBUG - 2011-10-17 19:22:22 --> Controller Class Initialized
ERROR - 2011-10-17 19:22:22 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-10-17 19:22:22 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-10-17 19:22:22 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-17 19:22:22 --> Model Class Initialized
DEBUG - 2011-10-17 19:22:22 --> Model Class Initialized
DEBUG - 2011-10-17 19:22:22 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-17 19:22:22 --> Database Driver Class Initialized
DEBUG - 2011-10-17 19:22:22 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-17 19:22:22 --> Helper loaded: url_helper
DEBUG - 2011-10-17 19:22:22 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-17 19:22:22 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-17 19:22:22 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-17 19:22:22 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-17 19:22:22 --> Final output sent to browser
DEBUG - 2011-10-17 19:22:22 --> Total execution time: 0.0275
DEBUG - 2011-10-17 19:22:23 --> Config Class Initialized
DEBUG - 2011-10-17 19:22:23 --> Hooks Class Initialized
DEBUG - 2011-10-17 19:22:23 --> Utf8 Class Initialized
DEBUG - 2011-10-17 19:22:23 --> UTF-8 Support Enabled
DEBUG - 2011-10-17 19:22:23 --> URI Class Initialized
DEBUG - 2011-10-17 19:22:23 --> Router Class Initialized
DEBUG - 2011-10-17 19:22:23 --> Output Class Initialized
DEBUG - 2011-10-17 19:22:23 --> Input Class Initialized
DEBUG - 2011-10-17 19:22:23 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-17 19:22:23 --> Language Class Initialized
DEBUG - 2011-10-17 19:22:23 --> Loader Class Initialized
DEBUG - 2011-10-17 19:22:23 --> Controller Class Initialized
DEBUG - 2011-10-17 19:22:23 --> Model Class Initialized
DEBUG - 2011-10-17 19:22:23 --> Model Class Initialized
DEBUG - 2011-10-17 19:22:23 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-17 19:22:23 --> Database Driver Class Initialized
DEBUG - 2011-10-17 19:22:23 --> Config Class Initialized
DEBUG - 2011-10-17 19:22:23 --> Hooks Class Initialized
DEBUG - 2011-10-17 19:22:23 --> Utf8 Class Initialized
DEBUG - 2011-10-17 19:22:23 --> UTF-8 Support Enabled
DEBUG - 2011-10-17 19:22:23 --> URI Class Initialized
DEBUG - 2011-10-17 19:22:23 --> Router Class Initialized
DEBUG - 2011-10-17 19:22:23 --> Output Class Initialized
DEBUG - 2011-10-17 19:22:23 --> Input Class Initialized
DEBUG - 2011-10-17 19:22:23 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-17 19:22:23 --> Language Class Initialized
DEBUG - 2011-10-17 19:22:24 --> Loader Class Initialized
DEBUG - 2011-10-17 19:22:24 --> Controller Class Initialized
ERROR - 2011-10-17 19:22:24 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-10-17 19:22:24 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-10-17 19:22:24 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-17 19:22:24 --> Model Class Initialized
DEBUG - 2011-10-17 19:22:24 --> Model Class Initialized
DEBUG - 2011-10-17 19:22:24 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-17 19:22:24 --> Database Driver Class Initialized
DEBUG - 2011-10-17 19:22:24 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-17 19:22:24 --> Helper loaded: url_helper
DEBUG - 2011-10-17 19:22:24 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-17 19:22:24 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-17 19:22:24 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-17 19:22:24 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-17 19:22:24 --> Final output sent to browser
DEBUG - 2011-10-17 19:22:24 --> Total execution time: 0.0279
DEBUG - 2011-10-17 19:22:24 --> Final output sent to browser
DEBUG - 2011-10-17 19:22:24 --> Total execution time: 0.4931
DEBUG - 2011-10-17 19:22:39 --> Config Class Initialized
DEBUG - 2011-10-17 19:22:39 --> Hooks Class Initialized
DEBUG - 2011-10-17 19:22:39 --> Utf8 Class Initialized
DEBUG - 2011-10-17 19:22:39 --> UTF-8 Support Enabled
DEBUG - 2011-10-17 19:22:39 --> URI Class Initialized
DEBUG - 2011-10-17 19:22:39 --> Router Class Initialized
DEBUG - 2011-10-17 19:22:39 --> Output Class Initialized
DEBUG - 2011-10-17 19:22:39 --> Input Class Initialized
DEBUG - 2011-10-17 19:22:39 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-17 19:22:39 --> Language Class Initialized
DEBUG - 2011-10-17 19:22:39 --> Loader Class Initialized
DEBUG - 2011-10-17 19:22:39 --> Controller Class Initialized
ERROR - 2011-10-17 19:22:39 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-10-17 19:22:39 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-10-17 19:22:39 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-17 19:22:39 --> Model Class Initialized
DEBUG - 2011-10-17 19:22:39 --> Model Class Initialized
DEBUG - 2011-10-17 19:22:39 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-17 19:22:39 --> Database Driver Class Initialized
DEBUG - 2011-10-17 19:22:39 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-17 19:22:39 --> Helper loaded: url_helper
DEBUG - 2011-10-17 19:22:39 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-17 19:22:39 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-17 19:22:39 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-17 19:22:39 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-17 19:22:39 --> Final output sent to browser
DEBUG - 2011-10-17 19:22:39 --> Total execution time: 0.0371
DEBUG - 2011-10-17 19:22:40 --> Config Class Initialized
DEBUG - 2011-10-17 19:22:40 --> Hooks Class Initialized
DEBUG - 2011-10-17 19:22:40 --> Utf8 Class Initialized
DEBUG - 2011-10-17 19:22:40 --> UTF-8 Support Enabled
DEBUG - 2011-10-17 19:22:40 --> URI Class Initialized
DEBUG - 2011-10-17 19:22:40 --> Router Class Initialized
DEBUG - 2011-10-17 19:22:40 --> Output Class Initialized
DEBUG - 2011-10-17 19:22:40 --> Input Class Initialized
DEBUG - 2011-10-17 19:22:40 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-17 19:22:40 --> Language Class Initialized
DEBUG - 2011-10-17 19:22:40 --> Loader Class Initialized
DEBUG - 2011-10-17 19:22:40 --> Controller Class Initialized
ERROR - 2011-10-17 19:22:40 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-10-17 19:22:40 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-10-17 19:22:40 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-17 19:22:40 --> Model Class Initialized
DEBUG - 2011-10-17 19:22:40 --> Model Class Initialized
DEBUG - 2011-10-17 19:22:40 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-17 19:22:40 --> Database Driver Class Initialized
DEBUG - 2011-10-17 19:22:40 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-17 19:22:40 --> Helper loaded: url_helper
DEBUG - 2011-10-17 19:22:40 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-17 19:22:40 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-17 19:22:40 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-17 19:22:40 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-17 19:22:40 --> Final output sent to browser
DEBUG - 2011-10-17 19:22:40 --> Total execution time: 0.0337
DEBUG - 2011-10-17 19:22:40 --> Config Class Initialized
DEBUG - 2011-10-17 19:22:40 --> Hooks Class Initialized
DEBUG - 2011-10-17 19:22:40 --> Utf8 Class Initialized
DEBUG - 2011-10-17 19:22:40 --> UTF-8 Support Enabled
DEBUG - 2011-10-17 19:22:40 --> URI Class Initialized
DEBUG - 2011-10-17 19:22:40 --> Router Class Initialized
DEBUG - 2011-10-17 19:22:40 --> Output Class Initialized
DEBUG - 2011-10-17 19:22:40 --> Input Class Initialized
DEBUG - 2011-10-17 19:22:40 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-17 19:22:40 --> Language Class Initialized
DEBUG - 2011-10-17 19:22:40 --> Loader Class Initialized
DEBUG - 2011-10-17 19:22:40 --> Controller Class Initialized
DEBUG - 2011-10-17 19:22:40 --> Model Class Initialized
DEBUG - 2011-10-17 19:22:40 --> Model Class Initialized
DEBUG - 2011-10-17 19:22:40 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-17 19:22:40 --> Database Driver Class Initialized
DEBUG - 2011-10-17 19:22:40 --> Final output sent to browser
DEBUG - 2011-10-17 19:22:40 --> Total execution time: 0.5427
DEBUG - 2011-10-17 19:23:12 --> Config Class Initialized
DEBUG - 2011-10-17 19:23:12 --> Hooks Class Initialized
DEBUG - 2011-10-17 19:23:12 --> Utf8 Class Initialized
DEBUG - 2011-10-17 19:23:12 --> UTF-8 Support Enabled
DEBUG - 2011-10-17 19:23:12 --> URI Class Initialized
DEBUG - 2011-10-17 19:23:12 --> Router Class Initialized
DEBUG - 2011-10-17 19:23:12 --> Output Class Initialized
DEBUG - 2011-10-17 19:23:12 --> Input Class Initialized
DEBUG - 2011-10-17 19:23:12 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-17 19:23:12 --> Language Class Initialized
DEBUG - 2011-10-17 19:23:12 --> Loader Class Initialized
DEBUG - 2011-10-17 19:23:12 --> Controller Class Initialized
ERROR - 2011-10-17 19:23:12 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-10-17 19:23:12 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-10-17 19:23:12 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-17 19:23:12 --> Model Class Initialized
DEBUG - 2011-10-17 19:23:12 --> Model Class Initialized
DEBUG - 2011-10-17 19:23:12 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-17 19:23:12 --> Database Driver Class Initialized
DEBUG - 2011-10-17 19:23:12 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-17 19:23:12 --> Helper loaded: url_helper
DEBUG - 2011-10-17 19:23:12 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-17 19:23:12 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-17 19:23:12 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-17 19:23:12 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-17 19:23:12 --> Final output sent to browser
DEBUG - 2011-10-17 19:23:12 --> Total execution time: 0.0344
DEBUG - 2011-10-17 19:23:13 --> Config Class Initialized
DEBUG - 2011-10-17 19:23:13 --> Hooks Class Initialized
DEBUG - 2011-10-17 19:23:13 --> Utf8 Class Initialized
DEBUG - 2011-10-17 19:23:13 --> UTF-8 Support Enabled
DEBUG - 2011-10-17 19:23:13 --> URI Class Initialized
DEBUG - 2011-10-17 19:23:13 --> Router Class Initialized
DEBUG - 2011-10-17 19:23:13 --> Output Class Initialized
DEBUG - 2011-10-17 19:23:13 --> Input Class Initialized
DEBUG - 2011-10-17 19:23:13 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-17 19:23:13 --> Language Class Initialized
DEBUG - 2011-10-17 19:23:13 --> Loader Class Initialized
DEBUG - 2011-10-17 19:23:13 --> Controller Class Initialized
DEBUG - 2011-10-17 19:23:13 --> Model Class Initialized
DEBUG - 2011-10-17 19:23:13 --> Model Class Initialized
DEBUG - 2011-10-17 19:23:13 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-17 19:23:13 --> Database Driver Class Initialized
DEBUG - 2011-10-17 19:23:13 --> Final output sent to browser
DEBUG - 2011-10-17 19:23:13 --> Total execution time: 0.5797
DEBUG - 2011-10-17 19:23:48 --> Config Class Initialized
DEBUG - 2011-10-17 19:23:48 --> Hooks Class Initialized
DEBUG - 2011-10-17 19:23:48 --> Utf8 Class Initialized
DEBUG - 2011-10-17 19:23:48 --> UTF-8 Support Enabled
DEBUG - 2011-10-17 19:23:48 --> URI Class Initialized
DEBUG - 2011-10-17 19:23:48 --> Router Class Initialized
DEBUG - 2011-10-17 19:23:48 --> Output Class Initialized
DEBUG - 2011-10-17 19:23:48 --> Input Class Initialized
DEBUG - 2011-10-17 19:23:48 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-17 19:23:48 --> Language Class Initialized
DEBUG - 2011-10-17 19:23:48 --> Loader Class Initialized
DEBUG - 2011-10-17 19:23:48 --> Controller Class Initialized
ERROR - 2011-10-17 19:23:48 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-10-17 19:23:48 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-10-17 19:23:48 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-17 19:23:48 --> Model Class Initialized
DEBUG - 2011-10-17 19:23:48 --> Model Class Initialized
DEBUG - 2011-10-17 19:23:48 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-17 19:23:48 --> Database Driver Class Initialized
DEBUG - 2011-10-17 19:23:48 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-17 19:23:48 --> Helper loaded: url_helper
DEBUG - 2011-10-17 19:23:48 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-17 19:23:48 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-17 19:23:48 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-17 19:23:48 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-17 19:23:48 --> Final output sent to browser
DEBUG - 2011-10-17 19:23:48 --> Total execution time: 0.0284
DEBUG - 2011-10-17 19:23:48 --> Config Class Initialized
DEBUG - 2011-10-17 19:23:48 --> Hooks Class Initialized
DEBUG - 2011-10-17 19:23:48 --> Utf8 Class Initialized
DEBUG - 2011-10-17 19:23:48 --> UTF-8 Support Enabled
DEBUG - 2011-10-17 19:23:48 --> URI Class Initialized
DEBUG - 2011-10-17 19:23:48 --> Router Class Initialized
DEBUG - 2011-10-17 19:23:48 --> Output Class Initialized
DEBUG - 2011-10-17 19:23:48 --> Input Class Initialized
DEBUG - 2011-10-17 19:23:48 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-17 19:23:48 --> Language Class Initialized
DEBUG - 2011-10-17 19:23:48 --> Loader Class Initialized
DEBUG - 2011-10-17 19:23:48 --> Controller Class Initialized
DEBUG - 2011-10-17 19:23:48 --> Model Class Initialized
DEBUG - 2011-10-17 19:23:48 --> Model Class Initialized
DEBUG - 2011-10-17 19:23:48 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-17 19:23:48 --> Database Driver Class Initialized
DEBUG - 2011-10-17 19:23:48 --> Config Class Initialized
DEBUG - 2011-10-17 19:23:48 --> Hooks Class Initialized
DEBUG - 2011-10-17 19:23:48 --> Utf8 Class Initialized
DEBUG - 2011-10-17 19:23:48 --> UTF-8 Support Enabled
DEBUG - 2011-10-17 19:23:48 --> URI Class Initialized
DEBUG - 2011-10-17 19:23:48 --> Router Class Initialized
DEBUG - 2011-10-17 19:23:48 --> Output Class Initialized
DEBUG - 2011-10-17 19:23:48 --> Input Class Initialized
DEBUG - 2011-10-17 19:23:48 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-17 19:23:48 --> Language Class Initialized
DEBUG - 2011-10-17 19:23:48 --> Loader Class Initialized
DEBUG - 2011-10-17 19:23:48 --> Controller Class Initialized
ERROR - 2011-10-17 19:23:48 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-10-17 19:23:48 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-10-17 19:23:48 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-17 19:23:48 --> Model Class Initialized
DEBUG - 2011-10-17 19:23:48 --> Model Class Initialized
DEBUG - 2011-10-17 19:23:48 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-17 19:23:48 --> Database Driver Class Initialized
DEBUG - 2011-10-17 19:23:48 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-17 19:23:48 --> Helper loaded: url_helper
DEBUG - 2011-10-17 19:23:48 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-17 19:23:48 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-17 19:23:48 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-17 19:23:48 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-17 19:23:48 --> Final output sent to browser
DEBUG - 2011-10-17 19:23:48 --> Total execution time: 0.0275
DEBUG - 2011-10-17 19:23:49 --> Final output sent to browser
DEBUG - 2011-10-17 19:23:49 --> Total execution time: 0.6057
DEBUG - 2011-10-17 19:24:01 --> Config Class Initialized
DEBUG - 2011-10-17 19:24:01 --> Hooks Class Initialized
DEBUG - 2011-10-17 19:24:01 --> Utf8 Class Initialized
DEBUG - 2011-10-17 19:24:01 --> UTF-8 Support Enabled
DEBUG - 2011-10-17 19:24:01 --> URI Class Initialized
DEBUG - 2011-10-17 19:24:01 --> Router Class Initialized
DEBUG - 2011-10-17 19:24:01 --> Output Class Initialized
DEBUG - 2011-10-17 19:24:01 --> Input Class Initialized
DEBUG - 2011-10-17 19:24:01 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-17 19:24:01 --> Language Class Initialized
DEBUG - 2011-10-17 19:24:01 --> Loader Class Initialized
DEBUG - 2011-10-17 19:24:01 --> Controller Class Initialized
ERROR - 2011-10-17 19:24:01 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-10-17 19:24:01 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-10-17 19:24:01 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-17 19:24:01 --> Model Class Initialized
DEBUG - 2011-10-17 19:24:01 --> Model Class Initialized
DEBUG - 2011-10-17 19:24:01 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-17 19:24:01 --> Database Driver Class Initialized
DEBUG - 2011-10-17 19:24:01 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-17 19:24:01 --> Helper loaded: url_helper
DEBUG - 2011-10-17 19:24:01 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-17 19:24:01 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-17 19:24:01 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-17 19:24:01 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-17 19:24:01 --> Final output sent to browser
DEBUG - 2011-10-17 19:24:01 --> Total execution time: 0.0809
DEBUG - 2011-10-17 19:24:03 --> Config Class Initialized
DEBUG - 2011-10-17 19:24:03 --> Hooks Class Initialized
DEBUG - 2011-10-17 19:24:03 --> Utf8 Class Initialized
DEBUG - 2011-10-17 19:24:03 --> UTF-8 Support Enabled
DEBUG - 2011-10-17 19:24:03 --> URI Class Initialized
DEBUG - 2011-10-17 19:24:03 --> Router Class Initialized
DEBUG - 2011-10-17 19:24:03 --> Output Class Initialized
DEBUG - 2011-10-17 19:24:03 --> Input Class Initialized
DEBUG - 2011-10-17 19:24:03 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-17 19:24:03 --> Language Class Initialized
DEBUG - 2011-10-17 19:24:03 --> Loader Class Initialized
DEBUG - 2011-10-17 19:24:03 --> Controller Class Initialized
DEBUG - 2011-10-17 19:24:03 --> Model Class Initialized
DEBUG - 2011-10-17 19:24:03 --> Model Class Initialized
DEBUG - 2011-10-17 19:24:03 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-17 19:24:03 --> Database Driver Class Initialized
DEBUG - 2011-10-17 19:24:03 --> Config Class Initialized
DEBUG - 2011-10-17 19:24:03 --> Hooks Class Initialized
DEBUG - 2011-10-17 19:24:03 --> Utf8 Class Initialized
DEBUG - 2011-10-17 19:24:03 --> UTF-8 Support Enabled
DEBUG - 2011-10-17 19:24:03 --> URI Class Initialized
DEBUG - 2011-10-17 19:24:03 --> Router Class Initialized
DEBUG - 2011-10-17 19:24:03 --> Output Class Initialized
DEBUG - 2011-10-17 19:24:03 --> Input Class Initialized
DEBUG - 2011-10-17 19:24:03 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-17 19:24:03 --> Language Class Initialized
DEBUG - 2011-10-17 19:24:03 --> Loader Class Initialized
DEBUG - 2011-10-17 19:24:03 --> Controller Class Initialized
ERROR - 2011-10-17 19:24:03 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-10-17 19:24:03 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-10-17 19:24:03 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-17 19:24:03 --> Model Class Initialized
DEBUG - 2011-10-17 19:24:03 --> Model Class Initialized
DEBUG - 2011-10-17 19:24:03 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-17 19:24:03 --> Database Driver Class Initialized
DEBUG - 2011-10-17 19:24:03 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-17 19:24:03 --> Helper loaded: url_helper
DEBUG - 2011-10-17 19:24:03 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-17 19:24:03 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-17 19:24:03 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-17 19:24:03 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-17 19:24:03 --> Final output sent to browser
DEBUG - 2011-10-17 19:24:03 --> Total execution time: 0.0394
DEBUG - 2011-10-17 19:24:03 --> Final output sent to browser
DEBUG - 2011-10-17 19:24:03 --> Total execution time: 0.6573
DEBUG - 2011-10-17 19:24:24 --> Config Class Initialized
DEBUG - 2011-10-17 19:24:24 --> Hooks Class Initialized
DEBUG - 2011-10-17 19:24:24 --> Utf8 Class Initialized
DEBUG - 2011-10-17 19:24:24 --> UTF-8 Support Enabled
DEBUG - 2011-10-17 19:24:24 --> URI Class Initialized
DEBUG - 2011-10-17 19:24:24 --> Router Class Initialized
DEBUG - 2011-10-17 19:24:24 --> Output Class Initialized
DEBUG - 2011-10-17 19:24:24 --> Input Class Initialized
DEBUG - 2011-10-17 19:24:24 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-17 19:24:24 --> Language Class Initialized
DEBUG - 2011-10-17 19:24:24 --> Loader Class Initialized
DEBUG - 2011-10-17 19:24:24 --> Controller Class Initialized
ERROR - 2011-10-17 19:24:24 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-10-17 19:24:24 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-10-17 19:24:24 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-17 19:24:24 --> Model Class Initialized
DEBUG - 2011-10-17 19:24:24 --> Model Class Initialized
DEBUG - 2011-10-17 19:24:24 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-17 19:24:24 --> Database Driver Class Initialized
DEBUG - 2011-10-17 19:24:24 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-17 19:24:24 --> Helper loaded: url_helper
DEBUG - 2011-10-17 19:24:24 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-17 19:24:24 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-17 19:24:24 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-17 19:24:24 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-17 19:24:24 --> Final output sent to browser
DEBUG - 2011-10-17 19:24:24 --> Total execution time: 0.0315
DEBUG - 2011-10-17 19:24:25 --> Config Class Initialized
DEBUG - 2011-10-17 19:24:25 --> Hooks Class Initialized
DEBUG - 2011-10-17 19:24:25 --> Utf8 Class Initialized
DEBUG - 2011-10-17 19:24:25 --> UTF-8 Support Enabled
DEBUG - 2011-10-17 19:24:25 --> URI Class Initialized
DEBUG - 2011-10-17 19:24:25 --> Router Class Initialized
DEBUG - 2011-10-17 19:24:25 --> Output Class Initialized
DEBUG - 2011-10-17 19:24:25 --> Input Class Initialized
DEBUG - 2011-10-17 19:24:25 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-17 19:24:25 --> Language Class Initialized
DEBUG - 2011-10-17 19:24:25 --> Loader Class Initialized
DEBUG - 2011-10-17 19:24:25 --> Controller Class Initialized
DEBUG - 2011-10-17 19:24:25 --> Model Class Initialized
DEBUG - 2011-10-17 19:24:25 --> Model Class Initialized
DEBUG - 2011-10-17 19:24:25 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-17 19:24:25 --> Database Driver Class Initialized
DEBUG - 2011-10-17 19:24:25 --> Final output sent to browser
DEBUG - 2011-10-17 19:24:25 --> Total execution time: 0.5252
DEBUG - 2011-10-17 19:24:25 --> Config Class Initialized
DEBUG - 2011-10-17 19:24:25 --> Hooks Class Initialized
DEBUG - 2011-10-17 19:24:25 --> Utf8 Class Initialized
DEBUG - 2011-10-17 19:24:25 --> UTF-8 Support Enabled
DEBUG - 2011-10-17 19:24:25 --> URI Class Initialized
DEBUG - 2011-10-17 19:24:25 --> Router Class Initialized
DEBUG - 2011-10-17 19:24:25 --> Output Class Initialized
DEBUG - 2011-10-17 19:24:25 --> Input Class Initialized
DEBUG - 2011-10-17 19:24:25 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-17 19:24:25 --> Language Class Initialized
DEBUG - 2011-10-17 19:24:25 --> Loader Class Initialized
DEBUG - 2011-10-17 19:24:25 --> Controller Class Initialized
ERROR - 2011-10-17 19:24:25 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-10-17 19:24:25 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-10-17 19:24:25 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-17 19:24:25 --> Model Class Initialized
DEBUG - 2011-10-17 19:24:25 --> Model Class Initialized
DEBUG - 2011-10-17 19:24:25 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-17 19:24:25 --> Database Driver Class Initialized
DEBUG - 2011-10-17 19:24:26 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-17 19:24:26 --> Helper loaded: url_helper
DEBUG - 2011-10-17 19:24:26 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-17 19:24:26 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-17 19:24:26 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-17 19:24:26 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-17 19:24:26 --> Final output sent to browser
DEBUG - 2011-10-17 19:24:26 --> Total execution time: 0.0737
DEBUG - 2011-10-17 19:24:51 --> Config Class Initialized
DEBUG - 2011-10-17 19:24:51 --> Hooks Class Initialized
DEBUG - 2011-10-17 19:24:51 --> Utf8 Class Initialized
DEBUG - 2011-10-17 19:24:51 --> UTF-8 Support Enabled
DEBUG - 2011-10-17 19:24:51 --> URI Class Initialized
DEBUG - 2011-10-17 19:24:51 --> Router Class Initialized
DEBUG - 2011-10-17 19:24:51 --> Output Class Initialized
DEBUG - 2011-10-17 19:24:51 --> Input Class Initialized
DEBUG - 2011-10-17 19:24:51 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-17 19:24:51 --> Language Class Initialized
DEBUG - 2011-10-17 19:24:51 --> Loader Class Initialized
DEBUG - 2011-10-17 19:24:51 --> Controller Class Initialized
ERROR - 2011-10-17 19:24:51 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-10-17 19:24:51 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-10-17 19:24:51 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-17 19:24:51 --> Model Class Initialized
DEBUG - 2011-10-17 19:24:51 --> Model Class Initialized
DEBUG - 2011-10-17 19:24:51 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-17 19:24:51 --> Database Driver Class Initialized
DEBUG - 2011-10-17 19:24:51 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-17 19:24:51 --> Helper loaded: url_helper
DEBUG - 2011-10-17 19:24:51 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-17 19:24:51 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-17 19:24:51 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-17 19:24:51 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-17 19:24:51 --> Final output sent to browser
DEBUG - 2011-10-17 19:24:51 --> Total execution time: 0.0274
DEBUG - 2011-10-17 19:24:52 --> Config Class Initialized
DEBUG - 2011-10-17 19:24:52 --> Hooks Class Initialized
DEBUG - 2011-10-17 19:24:52 --> Utf8 Class Initialized
DEBUG - 2011-10-17 19:24:52 --> UTF-8 Support Enabled
DEBUG - 2011-10-17 19:24:52 --> URI Class Initialized
DEBUG - 2011-10-17 19:24:52 --> Router Class Initialized
DEBUG - 2011-10-17 19:24:52 --> Output Class Initialized
DEBUG - 2011-10-17 19:24:52 --> Input Class Initialized
DEBUG - 2011-10-17 19:24:52 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-17 19:24:52 --> Language Class Initialized
DEBUG - 2011-10-17 19:24:52 --> Loader Class Initialized
DEBUG - 2011-10-17 19:24:52 --> Controller Class Initialized
ERROR - 2011-10-17 19:24:52 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-10-17 19:24:52 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-10-17 19:24:52 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-17 19:24:52 --> Model Class Initialized
DEBUG - 2011-10-17 19:24:52 --> Model Class Initialized
DEBUG - 2011-10-17 19:24:52 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-17 19:24:52 --> Database Driver Class Initialized
DEBUG - 2011-10-17 19:24:52 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-17 19:24:52 --> Helper loaded: url_helper
DEBUG - 2011-10-17 19:24:52 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-17 19:24:52 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-17 19:24:52 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-17 19:24:52 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-17 19:24:52 --> Final output sent to browser
DEBUG - 2011-10-17 19:24:52 --> Total execution time: 0.0299
DEBUG - 2011-10-17 19:24:53 --> Config Class Initialized
DEBUG - 2011-10-17 19:24:53 --> Hooks Class Initialized
DEBUG - 2011-10-17 19:24:53 --> Utf8 Class Initialized
DEBUG - 2011-10-17 19:24:53 --> UTF-8 Support Enabled
DEBUG - 2011-10-17 19:24:53 --> URI Class Initialized
DEBUG - 2011-10-17 19:24:53 --> Router Class Initialized
DEBUG - 2011-10-17 19:24:53 --> Output Class Initialized
DEBUG - 2011-10-17 19:24:53 --> Input Class Initialized
DEBUG - 2011-10-17 19:24:53 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-17 19:24:53 --> Language Class Initialized
DEBUG - 2011-10-17 19:24:53 --> Loader Class Initialized
DEBUG - 2011-10-17 19:24:53 --> Controller Class Initialized
DEBUG - 2011-10-17 19:24:53 --> Model Class Initialized
DEBUG - 2011-10-17 19:24:53 --> Model Class Initialized
DEBUG - 2011-10-17 19:24:53 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-17 19:24:53 --> Database Driver Class Initialized
DEBUG - 2011-10-17 19:24:53 --> Final output sent to browser
DEBUG - 2011-10-17 19:24:53 --> Total execution time: 0.6304
DEBUG - 2011-10-17 19:25:07 --> Config Class Initialized
DEBUG - 2011-10-17 19:25:07 --> Hooks Class Initialized
DEBUG - 2011-10-17 19:25:07 --> Utf8 Class Initialized
DEBUG - 2011-10-17 19:25:07 --> UTF-8 Support Enabled
DEBUG - 2011-10-17 19:25:07 --> URI Class Initialized
DEBUG - 2011-10-17 19:25:07 --> Router Class Initialized
DEBUG - 2011-10-17 19:25:07 --> Output Class Initialized
DEBUG - 2011-10-17 19:25:07 --> Input Class Initialized
DEBUG - 2011-10-17 19:25:07 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-17 19:25:07 --> Language Class Initialized
DEBUG - 2011-10-17 19:25:07 --> Loader Class Initialized
DEBUG - 2011-10-17 19:25:07 --> Controller Class Initialized
ERROR - 2011-10-17 19:25:07 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-10-17 19:25:07 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-10-17 19:25:07 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-17 19:25:07 --> Model Class Initialized
DEBUG - 2011-10-17 19:25:07 --> Model Class Initialized
DEBUG - 2011-10-17 19:25:07 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-17 19:25:07 --> Database Driver Class Initialized
DEBUG - 2011-10-17 19:25:07 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-17 19:25:07 --> Helper loaded: url_helper
DEBUG - 2011-10-17 19:25:07 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-17 19:25:07 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-17 19:25:07 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-17 19:25:07 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-17 19:25:07 --> Final output sent to browser
DEBUG - 2011-10-17 19:25:07 --> Total execution time: 0.0318
DEBUG - 2011-10-17 19:25:07 --> Config Class Initialized
DEBUG - 2011-10-17 19:25:07 --> Hooks Class Initialized
DEBUG - 2011-10-17 19:25:07 --> Utf8 Class Initialized
DEBUG - 2011-10-17 19:25:07 --> UTF-8 Support Enabled
DEBUG - 2011-10-17 19:25:07 --> URI Class Initialized
DEBUG - 2011-10-17 19:25:07 --> Router Class Initialized
DEBUG - 2011-10-17 19:25:07 --> Output Class Initialized
DEBUG - 2011-10-17 19:25:07 --> Input Class Initialized
DEBUG - 2011-10-17 19:25:07 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-17 19:25:07 --> Language Class Initialized
DEBUG - 2011-10-17 19:25:07 --> Loader Class Initialized
DEBUG - 2011-10-17 19:25:07 --> Controller Class Initialized
DEBUG - 2011-10-17 19:25:07 --> Model Class Initialized
DEBUG - 2011-10-17 19:25:07 --> Model Class Initialized
DEBUG - 2011-10-17 19:25:07 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-17 19:25:07 --> Database Driver Class Initialized
DEBUG - 2011-10-17 19:25:07 --> Config Class Initialized
DEBUG - 2011-10-17 19:25:07 --> Hooks Class Initialized
DEBUG - 2011-10-17 19:25:07 --> Utf8 Class Initialized
DEBUG - 2011-10-17 19:25:07 --> UTF-8 Support Enabled
DEBUG - 2011-10-17 19:25:07 --> URI Class Initialized
DEBUG - 2011-10-17 19:25:07 --> Router Class Initialized
DEBUG - 2011-10-17 19:25:07 --> Output Class Initialized
DEBUG - 2011-10-17 19:25:07 --> Input Class Initialized
DEBUG - 2011-10-17 19:25:07 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-17 19:25:07 --> Language Class Initialized
DEBUG - 2011-10-17 19:25:07 --> Loader Class Initialized
DEBUG - 2011-10-17 19:25:07 --> Controller Class Initialized
ERROR - 2011-10-17 19:25:07 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-10-17 19:25:07 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-10-17 19:25:07 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-17 19:25:07 --> Model Class Initialized
DEBUG - 2011-10-17 19:25:08 --> Model Class Initialized
DEBUG - 2011-10-17 19:25:08 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-17 19:25:08 --> Database Driver Class Initialized
DEBUG - 2011-10-17 19:25:08 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-17 19:25:08 --> Helper loaded: url_helper
DEBUG - 2011-10-17 19:25:08 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-17 19:25:08 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-17 19:25:08 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-17 19:25:08 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-17 19:25:08 --> Final output sent to browser
DEBUG - 2011-10-17 19:25:08 --> Total execution time: 0.1055
DEBUG - 2011-10-17 19:25:08 --> Final output sent to browser
DEBUG - 2011-10-17 19:25:08 --> Total execution time: 0.6832
DEBUG - 2011-10-17 19:25:17 --> Config Class Initialized
DEBUG - 2011-10-17 19:25:17 --> Hooks Class Initialized
DEBUG - 2011-10-17 19:25:17 --> Utf8 Class Initialized
DEBUG - 2011-10-17 19:25:17 --> UTF-8 Support Enabled
DEBUG - 2011-10-17 19:25:17 --> URI Class Initialized
DEBUG - 2011-10-17 19:25:17 --> Router Class Initialized
DEBUG - 2011-10-17 19:25:17 --> Output Class Initialized
DEBUG - 2011-10-17 19:25:17 --> Input Class Initialized
DEBUG - 2011-10-17 19:25:17 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-17 19:25:17 --> Language Class Initialized
DEBUG - 2011-10-17 19:25:17 --> Loader Class Initialized
DEBUG - 2011-10-17 19:25:17 --> Controller Class Initialized
ERROR - 2011-10-17 19:25:17 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-10-17 19:25:17 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-10-17 19:25:17 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-17 19:25:17 --> Model Class Initialized
DEBUG - 2011-10-17 19:25:17 --> Model Class Initialized
DEBUG - 2011-10-17 19:25:17 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-17 19:25:17 --> Database Driver Class Initialized
DEBUG - 2011-10-17 19:25:17 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-17 19:25:17 --> Helper loaded: url_helper
DEBUG - 2011-10-17 19:25:17 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-17 19:25:17 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-17 19:25:17 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-17 19:25:17 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-17 19:25:17 --> Final output sent to browser
DEBUG - 2011-10-17 19:25:17 --> Total execution time: 0.0273
DEBUG - 2011-10-17 19:25:18 --> Config Class Initialized
DEBUG - 2011-10-17 19:25:18 --> Hooks Class Initialized
DEBUG - 2011-10-17 19:25:18 --> Utf8 Class Initialized
DEBUG - 2011-10-17 19:25:18 --> UTF-8 Support Enabled
DEBUG - 2011-10-17 19:25:18 --> URI Class Initialized
DEBUG - 2011-10-17 19:25:18 --> Router Class Initialized
DEBUG - 2011-10-17 19:25:18 --> Output Class Initialized
DEBUG - 2011-10-17 19:25:18 --> Input Class Initialized
DEBUG - 2011-10-17 19:25:18 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-17 19:25:18 --> Language Class Initialized
DEBUG - 2011-10-17 19:25:18 --> Loader Class Initialized
DEBUG - 2011-10-17 19:25:18 --> Controller Class Initialized
DEBUG - 2011-10-17 19:25:18 --> Model Class Initialized
DEBUG - 2011-10-17 19:25:18 --> Model Class Initialized
DEBUG - 2011-10-17 19:25:18 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-17 19:25:18 --> Database Driver Class Initialized
DEBUG - 2011-10-17 19:25:18 --> Final output sent to browser
DEBUG - 2011-10-17 19:25:18 --> Total execution time: 0.5270
DEBUG - 2011-10-17 19:25:19 --> Config Class Initialized
DEBUG - 2011-10-17 19:25:19 --> Hooks Class Initialized
DEBUG - 2011-10-17 19:25:19 --> Utf8 Class Initialized
DEBUG - 2011-10-17 19:25:19 --> UTF-8 Support Enabled
DEBUG - 2011-10-17 19:25:19 --> URI Class Initialized
DEBUG - 2011-10-17 19:25:19 --> Router Class Initialized
DEBUG - 2011-10-17 19:25:19 --> Output Class Initialized
DEBUG - 2011-10-17 19:25:19 --> Input Class Initialized
DEBUG - 2011-10-17 19:25:19 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-17 19:25:19 --> Language Class Initialized
DEBUG - 2011-10-17 19:25:19 --> Loader Class Initialized
DEBUG - 2011-10-17 19:25:19 --> Controller Class Initialized
ERROR - 2011-10-17 19:25:19 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-10-17 19:25:19 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-10-17 19:25:19 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-17 19:25:19 --> Model Class Initialized
DEBUG - 2011-10-17 19:25:19 --> Model Class Initialized
DEBUG - 2011-10-17 19:25:19 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-17 19:25:19 --> Database Driver Class Initialized
DEBUG - 2011-10-17 19:25:19 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-17 19:25:19 --> Helper loaded: url_helper
DEBUG - 2011-10-17 19:25:19 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-17 19:25:19 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-17 19:25:19 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-17 19:25:19 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-17 19:25:19 --> Final output sent to browser
DEBUG - 2011-10-17 19:25:19 --> Total execution time: 0.0305
DEBUG - 2011-10-17 19:25:25 --> Config Class Initialized
DEBUG - 2011-10-17 19:25:25 --> Hooks Class Initialized
DEBUG - 2011-10-17 19:25:25 --> Utf8 Class Initialized
DEBUG - 2011-10-17 19:25:25 --> UTF-8 Support Enabled
DEBUG - 2011-10-17 19:25:25 --> URI Class Initialized
DEBUG - 2011-10-17 19:25:25 --> Router Class Initialized
DEBUG - 2011-10-17 19:25:25 --> Output Class Initialized
DEBUG - 2011-10-17 19:25:25 --> Input Class Initialized
DEBUG - 2011-10-17 19:25:25 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-17 19:25:25 --> Language Class Initialized
DEBUG - 2011-10-17 19:25:25 --> Loader Class Initialized
DEBUG - 2011-10-17 19:25:25 --> Controller Class Initialized
ERROR - 2011-10-17 19:25:25 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-10-17 19:25:25 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-10-17 19:25:25 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-17 19:25:25 --> Model Class Initialized
DEBUG - 2011-10-17 19:25:25 --> Model Class Initialized
DEBUG - 2011-10-17 19:25:25 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-17 19:25:25 --> Database Driver Class Initialized
DEBUG - 2011-10-17 19:25:25 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-17 19:25:25 --> Helper loaded: url_helper
DEBUG - 2011-10-17 19:25:25 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-17 19:25:25 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-17 19:25:25 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-17 19:25:25 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-17 19:25:25 --> Final output sent to browser
DEBUG - 2011-10-17 19:25:25 --> Total execution time: 0.0276
DEBUG - 2011-10-17 19:25:26 --> Config Class Initialized
DEBUG - 2011-10-17 19:25:26 --> Hooks Class Initialized
DEBUG - 2011-10-17 19:25:26 --> Utf8 Class Initialized
DEBUG - 2011-10-17 19:25:26 --> UTF-8 Support Enabled
DEBUG - 2011-10-17 19:25:26 --> URI Class Initialized
DEBUG - 2011-10-17 19:25:26 --> Router Class Initialized
DEBUG - 2011-10-17 19:25:26 --> Output Class Initialized
DEBUG - 2011-10-17 19:25:26 --> Input Class Initialized
DEBUG - 2011-10-17 19:25:26 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-17 19:25:26 --> Language Class Initialized
DEBUG - 2011-10-17 19:25:26 --> Loader Class Initialized
DEBUG - 2011-10-17 19:25:26 --> Controller Class Initialized
DEBUG - 2011-10-17 19:25:26 --> Model Class Initialized
DEBUG - 2011-10-17 19:25:26 --> Model Class Initialized
DEBUG - 2011-10-17 19:25:26 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-17 19:25:26 --> Database Driver Class Initialized
DEBUG - 2011-10-17 19:25:26 --> Config Class Initialized
DEBUG - 2011-10-17 19:25:26 --> Hooks Class Initialized
DEBUG - 2011-10-17 19:25:26 --> Utf8 Class Initialized
DEBUG - 2011-10-17 19:25:26 --> UTF-8 Support Enabled
DEBUG - 2011-10-17 19:25:26 --> URI Class Initialized
DEBUG - 2011-10-17 19:25:26 --> Router Class Initialized
DEBUG - 2011-10-17 19:25:26 --> Output Class Initialized
DEBUG - 2011-10-17 19:25:26 --> Input Class Initialized
DEBUG - 2011-10-17 19:25:26 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-17 19:25:26 --> Language Class Initialized
DEBUG - 2011-10-17 19:25:26 --> Loader Class Initialized
DEBUG - 2011-10-17 19:25:26 --> Controller Class Initialized
ERROR - 2011-10-17 19:25:26 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-10-17 19:25:26 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-10-17 19:25:26 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-17 19:25:26 --> Model Class Initialized
DEBUG - 2011-10-17 19:25:26 --> Model Class Initialized
DEBUG - 2011-10-17 19:25:26 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-17 19:25:26 --> Database Driver Class Initialized
DEBUG - 2011-10-17 19:25:26 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-17 19:25:26 --> Helper loaded: url_helper
DEBUG - 2011-10-17 19:25:26 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-17 19:25:26 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-17 19:25:26 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-17 19:25:26 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-17 19:25:26 --> Final output sent to browser
DEBUG - 2011-10-17 19:25:26 --> Total execution time: 0.0330
DEBUG - 2011-10-17 19:25:26 --> Final output sent to browser
DEBUG - 2011-10-17 19:25:26 --> Total execution time: 0.7866
DEBUG - 2011-10-17 19:25:35 --> Config Class Initialized
DEBUG - 2011-10-17 19:25:35 --> Hooks Class Initialized
DEBUG - 2011-10-17 19:25:35 --> Utf8 Class Initialized
DEBUG - 2011-10-17 19:25:35 --> UTF-8 Support Enabled
DEBUG - 2011-10-17 19:25:35 --> URI Class Initialized
DEBUG - 2011-10-17 19:25:35 --> Router Class Initialized
DEBUG - 2011-10-17 19:25:35 --> Output Class Initialized
DEBUG - 2011-10-17 19:25:35 --> Input Class Initialized
DEBUG - 2011-10-17 19:25:35 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-17 19:25:35 --> Language Class Initialized
DEBUG - 2011-10-17 19:25:35 --> Loader Class Initialized
DEBUG - 2011-10-17 19:25:35 --> Controller Class Initialized
ERROR - 2011-10-17 19:25:35 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-10-17 19:25:35 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-10-17 19:25:35 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-17 19:25:35 --> Model Class Initialized
DEBUG - 2011-10-17 19:25:35 --> Model Class Initialized
DEBUG - 2011-10-17 19:25:35 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-17 19:25:35 --> Database Driver Class Initialized
DEBUG - 2011-10-17 19:25:35 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-17 19:25:35 --> Helper loaded: url_helper
DEBUG - 2011-10-17 19:25:35 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-17 19:25:35 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-17 19:25:35 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-17 19:25:35 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-17 19:25:35 --> Final output sent to browser
DEBUG - 2011-10-17 19:25:35 --> Total execution time: 0.1205
DEBUG - 2011-10-17 19:25:35 --> Config Class Initialized
DEBUG - 2011-10-17 19:25:35 --> Hooks Class Initialized
DEBUG - 2011-10-17 19:25:35 --> Utf8 Class Initialized
DEBUG - 2011-10-17 19:25:35 --> UTF-8 Support Enabled
DEBUG - 2011-10-17 19:25:35 --> URI Class Initialized
DEBUG - 2011-10-17 19:25:35 --> Router Class Initialized
DEBUG - 2011-10-17 19:25:35 --> Output Class Initialized
DEBUG - 2011-10-17 19:25:35 --> Input Class Initialized
DEBUG - 2011-10-17 19:25:35 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-17 19:25:35 --> Language Class Initialized
DEBUG - 2011-10-17 19:25:35 --> Loader Class Initialized
DEBUG - 2011-10-17 19:25:35 --> Controller Class Initialized
DEBUG - 2011-10-17 19:25:35 --> Model Class Initialized
DEBUG - 2011-10-17 19:25:35 --> Model Class Initialized
DEBUG - 2011-10-17 19:25:35 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-17 19:25:36 --> Database Driver Class Initialized
DEBUG - 2011-10-17 19:25:36 --> Config Class Initialized
DEBUG - 2011-10-17 19:25:36 --> Hooks Class Initialized
DEBUG - 2011-10-17 19:25:36 --> Utf8 Class Initialized
DEBUG - 2011-10-17 19:25:36 --> UTF-8 Support Enabled
DEBUG - 2011-10-17 19:25:36 --> URI Class Initialized
DEBUG - 2011-10-17 19:25:36 --> Router Class Initialized
DEBUG - 2011-10-17 19:25:36 --> Output Class Initialized
DEBUG - 2011-10-17 19:25:36 --> Input Class Initialized
DEBUG - 2011-10-17 19:25:36 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-17 19:25:36 --> Language Class Initialized
DEBUG - 2011-10-17 19:25:36 --> Loader Class Initialized
DEBUG - 2011-10-17 19:25:36 --> Controller Class Initialized
ERROR - 2011-10-17 19:25:36 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-10-17 19:25:36 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-10-17 19:25:36 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-17 19:25:36 --> Model Class Initialized
DEBUG - 2011-10-17 19:25:36 --> Model Class Initialized
DEBUG - 2011-10-17 19:25:36 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-17 19:25:36 --> Database Driver Class Initialized
DEBUG - 2011-10-17 19:25:36 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-17 19:25:36 --> Helper loaded: url_helper
DEBUG - 2011-10-17 19:25:36 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-17 19:25:36 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-17 19:25:36 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-17 19:25:36 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-17 19:25:36 --> Final output sent to browser
DEBUG - 2011-10-17 19:25:36 --> Total execution time: 0.0561
DEBUG - 2011-10-17 19:25:36 --> Final output sent to browser
DEBUG - 2011-10-17 19:25:36 --> Total execution time: 0.5929
DEBUG - 2011-10-17 20:21:51 --> Config Class Initialized
DEBUG - 2011-10-17 20:21:51 --> Hooks Class Initialized
DEBUG - 2011-10-17 20:21:51 --> Utf8 Class Initialized
DEBUG - 2011-10-17 20:21:51 --> UTF-8 Support Enabled
DEBUG - 2011-10-17 20:21:51 --> URI Class Initialized
DEBUG - 2011-10-17 20:21:51 --> Router Class Initialized
DEBUG - 2011-10-17 20:21:51 --> Output Class Initialized
DEBUG - 2011-10-17 20:21:51 --> Input Class Initialized
DEBUG - 2011-10-17 20:21:51 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-17 20:21:51 --> Language Class Initialized
DEBUG - 2011-10-17 20:21:51 --> Loader Class Initialized
DEBUG - 2011-10-17 20:21:51 --> Controller Class Initialized
ERROR - 2011-10-17 20:21:51 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-10-17 20:21:51 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-10-17 20:21:51 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-17 20:21:51 --> Model Class Initialized
DEBUG - 2011-10-17 20:21:51 --> Model Class Initialized
DEBUG - 2011-10-17 20:21:51 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-17 20:21:51 --> Database Driver Class Initialized
DEBUG - 2011-10-17 20:21:51 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-17 20:21:51 --> Helper loaded: url_helper
DEBUG - 2011-10-17 20:21:51 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-17 20:21:51 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-17 20:21:51 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-17 20:21:51 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-17 20:21:51 --> Final output sent to browser
DEBUG - 2011-10-17 20:21:51 --> Total execution time: 0.0736
DEBUG - 2011-10-17 20:21:52 --> Config Class Initialized
DEBUG - 2011-10-17 20:21:52 --> Hooks Class Initialized
DEBUG - 2011-10-17 20:21:52 --> Utf8 Class Initialized
DEBUG - 2011-10-17 20:21:52 --> UTF-8 Support Enabled
DEBUG - 2011-10-17 20:21:52 --> URI Class Initialized
DEBUG - 2011-10-17 20:21:52 --> Router Class Initialized
DEBUG - 2011-10-17 20:21:52 --> Output Class Initialized
DEBUG - 2011-10-17 20:21:52 --> Input Class Initialized
DEBUG - 2011-10-17 20:21:52 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-17 20:21:52 --> Language Class Initialized
DEBUG - 2011-10-17 20:21:52 --> Loader Class Initialized
DEBUG - 2011-10-17 20:21:52 --> Controller Class Initialized
DEBUG - 2011-10-17 20:21:52 --> Model Class Initialized
DEBUG - 2011-10-17 20:21:52 --> Model Class Initialized
DEBUG - 2011-10-17 20:21:52 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-17 20:21:52 --> Database Driver Class Initialized
DEBUG - 2011-10-17 20:21:53 --> Final output sent to browser
DEBUG - 2011-10-17 20:21:53 --> Total execution time: 0.6518
DEBUG - 2011-10-17 20:22:00 --> Config Class Initialized
DEBUG - 2011-10-17 20:22:00 --> Hooks Class Initialized
DEBUG - 2011-10-17 20:22:00 --> Utf8 Class Initialized
DEBUG - 2011-10-17 20:22:00 --> UTF-8 Support Enabled
DEBUG - 2011-10-17 20:22:00 --> URI Class Initialized
DEBUG - 2011-10-17 20:22:00 --> Router Class Initialized
DEBUG - 2011-10-17 20:22:00 --> Output Class Initialized
DEBUG - 2011-10-17 20:22:00 --> Input Class Initialized
DEBUG - 2011-10-17 20:22:00 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-17 20:22:00 --> Language Class Initialized
DEBUG - 2011-10-17 20:22:00 --> Loader Class Initialized
DEBUG - 2011-10-17 20:22:00 --> Controller Class Initialized
ERROR - 2011-10-17 20:22:00 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-10-17 20:22:00 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-10-17 20:22:00 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-17 20:22:00 --> Model Class Initialized
DEBUG - 2011-10-17 20:22:00 --> Model Class Initialized
DEBUG - 2011-10-17 20:22:00 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-17 20:22:00 --> Database Driver Class Initialized
DEBUG - 2011-10-17 20:22:01 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-17 20:22:01 --> Helper loaded: url_helper
DEBUG - 2011-10-17 20:22:01 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-17 20:22:01 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-17 20:22:01 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-17 20:22:01 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-17 20:22:01 --> Final output sent to browser
DEBUG - 2011-10-17 20:22:01 --> Total execution time: 0.0296
DEBUG - 2011-10-17 20:22:01 --> Config Class Initialized
DEBUG - 2011-10-17 20:22:01 --> Hooks Class Initialized
DEBUG - 2011-10-17 20:22:01 --> Utf8 Class Initialized
DEBUG - 2011-10-17 20:22:01 --> UTF-8 Support Enabled
DEBUG - 2011-10-17 20:22:01 --> URI Class Initialized
DEBUG - 2011-10-17 20:22:01 --> Router Class Initialized
ERROR - 2011-10-17 20:22:01 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-17 20:22:01 --> Config Class Initialized
DEBUG - 2011-10-17 20:22:01 --> Hooks Class Initialized
DEBUG - 2011-10-17 20:22:01 --> Utf8 Class Initialized
DEBUG - 2011-10-17 20:22:01 --> UTF-8 Support Enabled
DEBUG - 2011-10-17 20:22:01 --> URI Class Initialized
DEBUG - 2011-10-17 20:22:01 --> Router Class Initialized
DEBUG - 2011-10-17 20:22:01 --> Output Class Initialized
DEBUG - 2011-10-17 20:22:01 --> Input Class Initialized
DEBUG - 2011-10-17 20:22:01 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-17 20:22:01 --> Language Class Initialized
DEBUG - 2011-10-17 20:22:01 --> Loader Class Initialized
DEBUG - 2011-10-17 20:22:01 --> Controller Class Initialized
DEBUG - 2011-10-17 20:22:01 --> Model Class Initialized
DEBUG - 2011-10-17 20:22:01 --> Model Class Initialized
DEBUG - 2011-10-17 20:22:01 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-17 20:22:01 --> Database Driver Class Initialized
DEBUG - 2011-10-17 20:22:02 --> Final output sent to browser
DEBUG - 2011-10-17 20:22:02 --> Total execution time: 0.5790
DEBUG - 2011-10-17 20:22:21 --> Config Class Initialized
DEBUG - 2011-10-17 20:22:21 --> Hooks Class Initialized
DEBUG - 2011-10-17 20:22:21 --> Utf8 Class Initialized
DEBUG - 2011-10-17 20:22:21 --> UTF-8 Support Enabled
DEBUG - 2011-10-17 20:22:21 --> URI Class Initialized
DEBUG - 2011-10-17 20:22:21 --> Router Class Initialized
ERROR - 2011-10-17 20:22:21 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-17 20:34:13 --> Config Class Initialized
DEBUG - 2011-10-17 20:34:13 --> Hooks Class Initialized
DEBUG - 2011-10-17 20:34:13 --> Utf8 Class Initialized
DEBUG - 2011-10-17 20:34:13 --> UTF-8 Support Enabled
DEBUG - 2011-10-17 20:34:13 --> URI Class Initialized
DEBUG - 2011-10-17 20:34:13 --> Router Class Initialized
DEBUG - 2011-10-17 20:34:13 --> Output Class Initialized
DEBUG - 2011-10-17 20:34:13 --> Input Class Initialized
DEBUG - 2011-10-17 20:34:13 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-17 20:34:13 --> Language Class Initialized
DEBUG - 2011-10-17 20:34:13 --> Loader Class Initialized
DEBUG - 2011-10-17 20:34:13 --> Controller Class Initialized
DEBUG - 2011-10-17 20:34:13 --> Model Class Initialized
DEBUG - 2011-10-17 20:34:13 --> Model Class Initialized
DEBUG - 2011-10-17 20:34:13 --> Model Class Initialized
DEBUG - 2011-10-17 20:34:13 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-17 20:34:13 --> Database Driver Class Initialized
DEBUG - 2011-10-17 20:34:13 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-17 20:34:13 --> Helper loaded: url_helper
DEBUG - 2011-10-17 20:34:13 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-17 20:34:13 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-17 20:34:13 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-17 20:34:13 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-17 20:34:13 --> Final output sent to browser
DEBUG - 2011-10-17 20:34:13 --> Total execution time: 0.2345
DEBUG - 2011-10-17 20:34:15 --> Config Class Initialized
DEBUG - 2011-10-17 20:34:15 --> Hooks Class Initialized
DEBUG - 2011-10-17 20:34:15 --> Utf8 Class Initialized
DEBUG - 2011-10-17 20:34:15 --> UTF-8 Support Enabled
DEBUG - 2011-10-17 20:34:15 --> URI Class Initialized
DEBUG - 2011-10-17 20:34:15 --> Router Class Initialized
ERROR - 2011-10-17 20:34:15 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-17 20:34:24 --> Config Class Initialized
DEBUG - 2011-10-17 20:34:24 --> Hooks Class Initialized
DEBUG - 2011-10-17 20:34:24 --> Utf8 Class Initialized
DEBUG - 2011-10-17 20:34:24 --> UTF-8 Support Enabled
DEBUG - 2011-10-17 20:34:24 --> URI Class Initialized
DEBUG - 2011-10-17 20:34:24 --> Router Class Initialized
DEBUG - 2011-10-17 20:34:24 --> Output Class Initialized
DEBUG - 2011-10-17 20:34:24 --> Input Class Initialized
DEBUG - 2011-10-17 20:34:24 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-17 20:34:24 --> Language Class Initialized
DEBUG - 2011-10-17 20:34:24 --> Loader Class Initialized
DEBUG - 2011-10-17 20:34:24 --> Controller Class Initialized
ERROR - 2011-10-17 20:34:24 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-10-17 20:34:24 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-10-17 20:34:24 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-17 20:34:24 --> Model Class Initialized
DEBUG - 2011-10-17 20:34:24 --> Model Class Initialized
DEBUG - 2011-10-17 20:34:24 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-17 20:34:24 --> Database Driver Class Initialized
DEBUG - 2011-10-17 20:34:24 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-17 20:34:24 --> Helper loaded: url_helper
DEBUG - 2011-10-17 20:34:24 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-17 20:34:24 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-17 20:34:24 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-17 20:34:24 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-17 20:34:24 --> Final output sent to browser
DEBUG - 2011-10-17 20:34:24 --> Total execution time: 0.0407
DEBUG - 2011-10-17 20:34:25 --> Config Class Initialized
DEBUG - 2011-10-17 20:34:25 --> Hooks Class Initialized
DEBUG - 2011-10-17 20:34:25 --> Utf8 Class Initialized
DEBUG - 2011-10-17 20:34:25 --> UTF-8 Support Enabled
DEBUG - 2011-10-17 20:34:25 --> URI Class Initialized
DEBUG - 2011-10-17 20:34:25 --> Router Class Initialized
DEBUG - 2011-10-17 20:34:25 --> Output Class Initialized
DEBUG - 2011-10-17 20:34:25 --> Input Class Initialized
DEBUG - 2011-10-17 20:34:25 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-17 20:34:25 --> Language Class Initialized
DEBUG - 2011-10-17 20:34:25 --> Loader Class Initialized
DEBUG - 2011-10-17 20:34:25 --> Controller Class Initialized
DEBUG - 2011-10-17 20:34:25 --> Model Class Initialized
DEBUG - 2011-10-17 20:34:25 --> Model Class Initialized
DEBUG - 2011-10-17 20:34:25 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-17 20:34:25 --> Database Driver Class Initialized
DEBUG - 2011-10-17 20:34:26 --> Final output sent to browser
DEBUG - 2011-10-17 20:34:26 --> Total execution time: 0.4990
DEBUG - 2011-10-17 20:34:26 --> Config Class Initialized
DEBUG - 2011-10-17 20:34:26 --> Hooks Class Initialized
DEBUG - 2011-10-17 20:34:26 --> Utf8 Class Initialized
DEBUG - 2011-10-17 20:34:26 --> UTF-8 Support Enabled
DEBUG - 2011-10-17 20:34:26 --> URI Class Initialized
DEBUG - 2011-10-17 20:34:26 --> Router Class Initialized
ERROR - 2011-10-17 20:34:26 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-17 20:35:21 --> Config Class Initialized
DEBUG - 2011-10-17 20:35:21 --> Hooks Class Initialized
DEBUG - 2011-10-17 20:35:21 --> Utf8 Class Initialized
DEBUG - 2011-10-17 20:35:21 --> UTF-8 Support Enabled
DEBUG - 2011-10-17 20:35:21 --> URI Class Initialized
DEBUG - 2011-10-17 20:35:21 --> Router Class Initialized
DEBUG - 2011-10-17 20:35:21 --> Output Class Initialized
DEBUG - 2011-10-17 20:35:21 --> Input Class Initialized
DEBUG - 2011-10-17 20:35:21 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-17 20:35:21 --> Language Class Initialized
DEBUG - 2011-10-17 20:35:21 --> Loader Class Initialized
DEBUG - 2011-10-17 20:35:21 --> Controller Class Initialized
ERROR - 2011-10-17 20:35:21 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-10-17 20:35:21 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-10-17 20:35:21 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-17 20:35:21 --> Model Class Initialized
DEBUG - 2011-10-17 20:35:21 --> Model Class Initialized
DEBUG - 2011-10-17 20:35:21 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-17 20:35:21 --> Database Driver Class Initialized
DEBUG - 2011-10-17 20:35:21 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-17 20:35:21 --> Helper loaded: url_helper
DEBUG - 2011-10-17 20:35:21 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-17 20:35:21 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-17 20:35:21 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-17 20:35:21 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-17 20:35:21 --> Final output sent to browser
DEBUG - 2011-10-17 20:35:21 --> Total execution time: 0.0623
DEBUG - 2011-10-17 20:35:23 --> Config Class Initialized
DEBUG - 2011-10-17 20:35:23 --> Hooks Class Initialized
DEBUG - 2011-10-17 20:35:23 --> Utf8 Class Initialized
DEBUG - 2011-10-17 20:35:23 --> UTF-8 Support Enabled
DEBUG - 2011-10-17 20:35:23 --> URI Class Initialized
DEBUG - 2011-10-17 20:35:23 --> Router Class Initialized
DEBUG - 2011-10-17 20:35:23 --> Output Class Initialized
DEBUG - 2011-10-17 20:35:23 --> Input Class Initialized
DEBUG - 2011-10-17 20:35:23 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-17 20:35:23 --> Language Class Initialized
DEBUG - 2011-10-17 20:35:23 --> Loader Class Initialized
DEBUG - 2011-10-17 20:35:23 --> Controller Class Initialized
DEBUG - 2011-10-17 20:35:23 --> Model Class Initialized
DEBUG - 2011-10-17 20:35:23 --> Model Class Initialized
DEBUG - 2011-10-17 20:35:23 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-17 20:35:23 --> Database Driver Class Initialized
DEBUG - 2011-10-17 20:35:24 --> Final output sent to browser
DEBUG - 2011-10-17 20:35:24 --> Total execution time: 0.5513
DEBUG - 2011-10-17 20:35:27 --> Config Class Initialized
DEBUG - 2011-10-17 20:35:27 --> Hooks Class Initialized
DEBUG - 2011-10-17 20:35:27 --> Utf8 Class Initialized
DEBUG - 2011-10-17 20:35:27 --> UTF-8 Support Enabled
DEBUG - 2011-10-17 20:35:27 --> URI Class Initialized
DEBUG - 2011-10-17 20:35:27 --> Router Class Initialized
ERROR - 2011-10-17 20:35:27 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-17 21:44:44 --> Config Class Initialized
DEBUG - 2011-10-17 21:44:44 --> Hooks Class Initialized
DEBUG - 2011-10-17 21:44:44 --> Utf8 Class Initialized
DEBUG - 2011-10-17 21:44:44 --> UTF-8 Support Enabled
DEBUG - 2011-10-17 21:44:44 --> URI Class Initialized
DEBUG - 2011-10-17 21:44:44 --> Router Class Initialized
DEBUG - 2011-10-17 21:44:44 --> Config Class Initialized
DEBUG - 2011-10-17 21:44:44 --> Hooks Class Initialized
DEBUG - 2011-10-17 21:44:44 --> Utf8 Class Initialized
DEBUG - 2011-10-17 21:44:44 --> UTF-8 Support Enabled
DEBUG - 2011-10-17 21:44:44 --> URI Class Initialized
DEBUG - 2011-10-17 21:44:44 --> Router Class Initialized
DEBUG - 2011-10-17 21:44:44 --> Output Class Initialized
DEBUG - 2011-10-17 21:44:44 --> Output Class Initialized
DEBUG - 2011-10-17 21:44:44 --> Input Class Initialized
DEBUG - 2011-10-17 21:44:44 --> Input Class Initialized
DEBUG - 2011-10-17 21:44:44 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-17 21:44:44 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-17 21:44:44 --> Language Class Initialized
DEBUG - 2011-10-17 21:44:44 --> Language Class Initialized
DEBUG - 2011-10-17 21:44:44 --> Loader Class Initialized
DEBUG - 2011-10-17 21:44:44 --> Controller Class Initialized
DEBUG - 2011-10-17 21:44:44 --> Loader Class Initialized
DEBUG - 2011-10-17 21:44:44 --> Controller Class Initialized
DEBUG - 2011-10-17 21:44:44 --> Model Class Initialized
ERROR - 2011-10-17 21:44:44 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-10-17 21:44:44 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-10-17 21:44:44 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-17 21:44:44 --> Model Class Initialized
DEBUG - 2011-10-17 21:44:44 --> Model Class Initialized
DEBUG - 2011-10-17 21:44:44 --> Model Class Initialized
DEBUG - 2011-10-17 21:44:44 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-17 21:44:44 --> Model Class Initialized
DEBUG - 2011-10-17 21:44:44 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-17 21:44:44 --> Database Driver Class Initialized
DEBUG - 2011-10-17 21:44:44 --> Database Driver Class Initialized
DEBUG - 2011-10-17 21:44:44 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-17 21:44:44 --> Helper loaded: url_helper
DEBUG - 2011-10-17 21:44:44 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-17 21:44:44 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-17 21:44:44 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-17 21:44:44 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-17 21:44:44 --> Final output sent to browser
DEBUG - 2011-10-17 21:44:44 --> Total execution time: 0.0785
DEBUG - 2011-10-17 21:44:44 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-17 21:44:44 --> Helper loaded: url_helper
DEBUG - 2011-10-17 21:44:44 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-17 21:44:44 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-17 21:44:44 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-17 21:44:44 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-17 21:44:44 --> Final output sent to browser
DEBUG - 2011-10-17 21:44:44 --> Total execution time: 0.2960
DEBUG - 2011-10-17 21:45:09 --> Config Class Initialized
DEBUG - 2011-10-17 21:45:09 --> Hooks Class Initialized
DEBUG - 2011-10-17 21:45:09 --> Utf8 Class Initialized
DEBUG - 2011-10-17 21:45:09 --> UTF-8 Support Enabled
DEBUG - 2011-10-17 21:45:09 --> Config Class Initialized
DEBUG - 2011-10-17 21:45:09 --> Hooks Class Initialized
DEBUG - 2011-10-17 21:45:09 --> Utf8 Class Initialized
DEBUG - 2011-10-17 21:45:09 --> UTF-8 Support Enabled
DEBUG - 2011-10-17 21:45:09 --> URI Class Initialized
DEBUG - 2011-10-17 21:45:09 --> URI Class Initialized
DEBUG - 2011-10-17 21:45:09 --> Router Class Initialized
DEBUG - 2011-10-17 21:45:09 --> Router Class Initialized
DEBUG - 2011-10-17 21:45:09 --> Output Class Initialized
DEBUG - 2011-10-17 21:45:09 --> Input Class Initialized
DEBUG - 2011-10-17 21:45:09 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-17 21:45:09 --> Output Class Initialized
DEBUG - 2011-10-17 21:45:09 --> Language Class Initialized
DEBUG - 2011-10-17 21:45:09 --> Input Class Initialized
DEBUG - 2011-10-17 21:45:09 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-17 21:45:09 --> Language Class Initialized
DEBUG - 2011-10-17 21:45:09 --> Loader Class Initialized
DEBUG - 2011-10-17 21:45:09 --> Controller Class Initialized
DEBUG - 2011-10-17 21:45:09 --> Model Class Initialized
DEBUG - 2011-10-17 21:45:09 --> Loader Class Initialized
DEBUG - 2011-10-17 21:45:09 --> Controller Class Initialized
DEBUG - 2011-10-17 21:45:09 --> Model Class Initialized
DEBUG - 2011-10-17 21:45:09 --> Model Class Initialized
ERROR - 2011-10-17 21:45:09 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-10-17 21:45:09 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-10-17 21:45:09 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-17 21:45:09 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-17 21:45:09 --> Model Class Initialized
DEBUG - 2011-10-17 21:45:09 --> Model Class Initialized
DEBUG - 2011-10-17 21:45:09 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-17 21:45:09 --> Database Driver Class Initialized
DEBUG - 2011-10-17 21:45:09 --> Database Driver Class Initialized
DEBUG - 2011-10-17 21:45:09 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-17 21:45:09 --> Helper loaded: url_helper
DEBUG - 2011-10-17 21:45:09 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-17 21:45:09 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-17 21:45:09 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-17 21:45:09 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-17 21:45:09 --> Final output sent to browser
DEBUG - 2011-10-17 21:45:09 --> Total execution time: 0.0424
DEBUG - 2011-10-17 21:45:09 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-17 21:45:09 --> Helper loaded: url_helper
DEBUG - 2011-10-17 21:45:09 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-17 21:45:09 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-17 21:45:09 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-17 21:45:09 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-17 21:45:09 --> Final output sent to browser
DEBUG - 2011-10-17 21:45:09 --> Total execution time: 0.0857
DEBUG - 2011-10-17 21:48:46 --> Config Class Initialized
DEBUG - 2011-10-17 21:48:46 --> Hooks Class Initialized
DEBUG - 2011-10-17 21:48:46 --> Utf8 Class Initialized
DEBUG - 2011-10-17 21:48:46 --> UTF-8 Support Enabled
DEBUG - 2011-10-17 21:48:46 --> URI Class Initialized
DEBUG - 2011-10-17 21:48:46 --> Router Class Initialized
DEBUG - 2011-10-17 21:48:46 --> Output Class Initialized
DEBUG - 2011-10-17 21:48:46 --> Input Class Initialized
DEBUG - 2011-10-17 21:48:46 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-17 21:48:46 --> Language Class Initialized
DEBUG - 2011-10-17 21:48:46 --> Loader Class Initialized
DEBUG - 2011-10-17 21:48:46 --> Controller Class Initialized
ERROR - 2011-10-17 21:48:46 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-10-17 21:48:46 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-10-17 21:48:46 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-17 21:48:46 --> Model Class Initialized
DEBUG - 2011-10-17 21:48:46 --> Model Class Initialized
DEBUG - 2011-10-17 21:48:46 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-17 21:48:46 --> Database Driver Class Initialized
DEBUG - 2011-10-17 21:48:46 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-17 21:48:46 --> Helper loaded: url_helper
DEBUG - 2011-10-17 21:48:46 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-17 21:48:46 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-17 21:48:46 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-17 21:48:46 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-17 21:48:46 --> Final output sent to browser
DEBUG - 2011-10-17 21:48:46 --> Total execution time: 0.0292
DEBUG - 2011-10-17 22:26:04 --> Config Class Initialized
DEBUG - 2011-10-17 22:26:04 --> Hooks Class Initialized
DEBUG - 2011-10-17 22:26:04 --> Utf8 Class Initialized
DEBUG - 2011-10-17 22:26:04 --> UTF-8 Support Enabled
DEBUG - 2011-10-17 22:26:04 --> URI Class Initialized
DEBUG - 2011-10-17 22:26:04 --> Router Class Initialized
DEBUG - 2011-10-17 22:26:04 --> No URI present. Default controller set.
DEBUG - 2011-10-17 22:26:04 --> Output Class Initialized
DEBUG - 2011-10-17 22:26:04 --> Input Class Initialized
DEBUG - 2011-10-17 22:26:04 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-17 22:26:04 --> Language Class Initialized
DEBUG - 2011-10-17 22:26:04 --> Loader Class Initialized
DEBUG - 2011-10-17 22:26:04 --> Controller Class Initialized
DEBUG - 2011-10-17 22:26:04 --> File loaded: application/views/splash/main.php
DEBUG - 2011-10-17 22:26:04 --> Helper loaded: url_helper
DEBUG - 2011-10-17 22:26:04 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-17 22:26:04 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-17 22:26:04 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-17 22:26:04 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-17 22:26:04 --> Final output sent to browser
DEBUG - 2011-10-17 22:26:04 --> Total execution time: 0.0744
DEBUG - 2011-10-17 22:59:01 --> Config Class Initialized
DEBUG - 2011-10-17 22:59:01 --> Hooks Class Initialized
DEBUG - 2011-10-17 22:59:01 --> Utf8 Class Initialized
DEBUG - 2011-10-17 22:59:01 --> UTF-8 Support Enabled
DEBUG - 2011-10-17 22:59:01 --> URI Class Initialized
DEBUG - 2011-10-17 22:59:01 --> Router Class Initialized
DEBUG - 2011-10-17 22:59:01 --> Output Class Initialized
DEBUG - 2011-10-17 22:59:01 --> Input Class Initialized
DEBUG - 2011-10-17 22:59:01 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-17 22:59:01 --> Language Class Initialized
DEBUG - 2011-10-17 22:59:01 --> Loader Class Initialized
DEBUG - 2011-10-17 22:59:01 --> Controller Class Initialized
ERROR - 2011-10-17 22:59:01 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-10-17 22:59:01 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-10-17 22:59:01 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-17 22:59:01 --> Model Class Initialized
DEBUG - 2011-10-17 22:59:01 --> Model Class Initialized
DEBUG - 2011-10-17 22:59:01 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-17 22:59:01 --> Database Driver Class Initialized
DEBUG - 2011-10-17 22:59:01 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-17 22:59:01 --> Helper loaded: url_helper
DEBUG - 2011-10-17 22:59:01 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-17 22:59:01 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-17 22:59:01 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-17 22:59:01 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-17 22:59:01 --> Final output sent to browser
DEBUG - 2011-10-17 22:59:01 --> Total execution time: 0.0947
DEBUG - 2011-10-17 22:59:02 --> Config Class Initialized
DEBUG - 2011-10-17 22:59:02 --> Hooks Class Initialized
DEBUG - 2011-10-17 22:59:02 --> Utf8 Class Initialized
DEBUG - 2011-10-17 22:59:02 --> UTF-8 Support Enabled
DEBUG - 2011-10-17 22:59:02 --> URI Class Initialized
DEBUG - 2011-10-17 22:59:02 --> Router Class Initialized
DEBUG - 2011-10-17 22:59:02 --> Output Class Initialized
DEBUG - 2011-10-17 22:59:02 --> Input Class Initialized
DEBUG - 2011-10-17 22:59:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-17 22:59:02 --> Language Class Initialized
DEBUG - 2011-10-17 22:59:02 --> Loader Class Initialized
DEBUG - 2011-10-17 22:59:02 --> Controller Class Initialized
DEBUG - 2011-10-17 22:59:02 --> Model Class Initialized
DEBUG - 2011-10-17 22:59:02 --> Model Class Initialized
DEBUG - 2011-10-17 22:59:02 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-17 22:59:02 --> Database Driver Class Initialized
DEBUG - 2011-10-17 22:59:03 --> Final output sent to browser
DEBUG - 2011-10-17 22:59:03 --> Total execution time: 0.6361
DEBUG - 2011-10-17 22:59:04 --> Config Class Initialized
DEBUG - 2011-10-17 22:59:04 --> Hooks Class Initialized
DEBUG - 2011-10-17 22:59:04 --> Utf8 Class Initialized
DEBUG - 2011-10-17 22:59:04 --> UTF-8 Support Enabled
DEBUG - 2011-10-17 22:59:04 --> URI Class Initialized
DEBUG - 2011-10-17 22:59:04 --> Router Class Initialized
ERROR - 2011-10-17 22:59:04 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-17 22:59:22 --> Config Class Initialized
DEBUG - 2011-10-17 22:59:22 --> Hooks Class Initialized
DEBUG - 2011-10-17 22:59:22 --> Utf8 Class Initialized
DEBUG - 2011-10-17 22:59:22 --> UTF-8 Support Enabled
DEBUG - 2011-10-17 22:59:22 --> URI Class Initialized
DEBUG - 2011-10-17 22:59:22 --> Router Class Initialized
DEBUG - 2011-10-17 22:59:22 --> Output Class Initialized
DEBUG - 2011-10-17 22:59:22 --> Input Class Initialized
DEBUG - 2011-10-17 22:59:22 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-17 22:59:22 --> Language Class Initialized
DEBUG - 2011-10-17 22:59:22 --> Loader Class Initialized
DEBUG - 2011-10-17 22:59:22 --> Controller Class Initialized
ERROR - 2011-10-17 22:59:22 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-10-17 22:59:22 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-10-17 22:59:22 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-17 22:59:22 --> Model Class Initialized
DEBUG - 2011-10-17 22:59:22 --> Model Class Initialized
DEBUG - 2011-10-17 22:59:22 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-17 22:59:22 --> Database Driver Class Initialized
DEBUG - 2011-10-17 22:59:22 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-17 22:59:22 --> Helper loaded: url_helper
DEBUG - 2011-10-17 22:59:22 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-17 22:59:22 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-17 22:59:22 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-17 22:59:22 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-17 22:59:22 --> Final output sent to browser
DEBUG - 2011-10-17 22:59:22 --> Total execution time: 0.0350
DEBUG - 2011-10-17 22:59:23 --> Config Class Initialized
DEBUG - 2011-10-17 22:59:23 --> Hooks Class Initialized
DEBUG - 2011-10-17 22:59:23 --> Utf8 Class Initialized
DEBUG - 2011-10-17 22:59:23 --> UTF-8 Support Enabled
DEBUG - 2011-10-17 22:59:23 --> URI Class Initialized
DEBUG - 2011-10-17 22:59:23 --> Router Class Initialized
DEBUG - 2011-10-17 22:59:23 --> Output Class Initialized
DEBUG - 2011-10-17 22:59:23 --> Input Class Initialized
DEBUG - 2011-10-17 22:59:23 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-17 22:59:23 --> Language Class Initialized
DEBUG - 2011-10-17 22:59:23 --> Loader Class Initialized
DEBUG - 2011-10-17 22:59:23 --> Controller Class Initialized
DEBUG - 2011-10-17 22:59:23 --> Model Class Initialized
DEBUG - 2011-10-17 22:59:23 --> Model Class Initialized
DEBUG - 2011-10-17 22:59:23 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-17 22:59:23 --> Database Driver Class Initialized
DEBUG - 2011-10-17 22:59:24 --> Final output sent to browser
DEBUG - 2011-10-17 22:59:24 --> Total execution time: 0.6431
DEBUG - 2011-10-17 22:59:25 --> Config Class Initialized
DEBUG - 2011-10-17 22:59:25 --> Hooks Class Initialized
DEBUG - 2011-10-17 22:59:25 --> Utf8 Class Initialized
DEBUG - 2011-10-17 22:59:25 --> UTF-8 Support Enabled
DEBUG - 2011-10-17 22:59:25 --> URI Class Initialized
DEBUG - 2011-10-17 22:59:25 --> Router Class Initialized
ERROR - 2011-10-17 22:59:25 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-17 22:59:40 --> Config Class Initialized
DEBUG - 2011-10-17 22:59:40 --> Hooks Class Initialized
DEBUG - 2011-10-17 22:59:40 --> Utf8 Class Initialized
DEBUG - 2011-10-17 22:59:40 --> UTF-8 Support Enabled
DEBUG - 2011-10-17 22:59:40 --> URI Class Initialized
DEBUG - 2011-10-17 22:59:40 --> Router Class Initialized
DEBUG - 2011-10-17 22:59:40 --> Output Class Initialized
DEBUG - 2011-10-17 22:59:40 --> Input Class Initialized
DEBUG - 2011-10-17 22:59:40 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-17 22:59:40 --> Language Class Initialized
DEBUG - 2011-10-17 22:59:40 --> Loader Class Initialized
DEBUG - 2011-10-17 22:59:40 --> Controller Class Initialized
ERROR - 2011-10-17 22:59:40 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-10-17 22:59:40 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-10-17 22:59:40 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-17 22:59:40 --> Model Class Initialized
DEBUG - 2011-10-17 22:59:40 --> Model Class Initialized
DEBUG - 2011-10-17 22:59:40 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-17 22:59:40 --> Database Driver Class Initialized
DEBUG - 2011-10-17 22:59:40 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-17 22:59:40 --> Helper loaded: url_helper
DEBUG - 2011-10-17 22:59:40 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-17 22:59:40 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-17 22:59:40 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-17 22:59:40 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-17 22:59:40 --> Final output sent to browser
DEBUG - 2011-10-17 22:59:40 --> Total execution time: 0.0308
DEBUG - 2011-10-17 22:59:41 --> Config Class Initialized
DEBUG - 2011-10-17 22:59:41 --> Hooks Class Initialized
DEBUG - 2011-10-17 22:59:41 --> Utf8 Class Initialized
DEBUG - 2011-10-17 22:59:41 --> UTF-8 Support Enabled
DEBUG - 2011-10-17 22:59:41 --> URI Class Initialized
DEBUG - 2011-10-17 22:59:41 --> Router Class Initialized
DEBUG - 2011-10-17 22:59:41 --> Output Class Initialized
DEBUG - 2011-10-17 22:59:41 --> Input Class Initialized
DEBUG - 2011-10-17 22:59:41 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-17 22:59:41 --> Language Class Initialized
DEBUG - 2011-10-17 22:59:41 --> Loader Class Initialized
DEBUG - 2011-10-17 22:59:41 --> Controller Class Initialized
DEBUG - 2011-10-17 22:59:41 --> Model Class Initialized
DEBUG - 2011-10-17 22:59:41 --> Model Class Initialized
DEBUG - 2011-10-17 22:59:41 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-17 22:59:41 --> Database Driver Class Initialized
DEBUG - 2011-10-17 22:59:42 --> Final output sent to browser
DEBUG - 2011-10-17 22:59:42 --> Total execution time: 0.9197
DEBUG - 2011-10-17 22:59:43 --> Config Class Initialized
DEBUG - 2011-10-17 22:59:43 --> Hooks Class Initialized
DEBUG - 2011-10-17 22:59:43 --> Utf8 Class Initialized
DEBUG - 2011-10-17 22:59:43 --> UTF-8 Support Enabled
DEBUG - 2011-10-17 22:59:43 --> URI Class Initialized
DEBUG - 2011-10-17 22:59:43 --> Router Class Initialized
ERROR - 2011-10-17 22:59:43 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-17 22:59:46 --> Config Class Initialized
DEBUG - 2011-10-17 22:59:46 --> Hooks Class Initialized
DEBUG - 2011-10-17 22:59:46 --> Utf8 Class Initialized
DEBUG - 2011-10-17 22:59:46 --> UTF-8 Support Enabled
DEBUG - 2011-10-17 22:59:46 --> URI Class Initialized
DEBUG - 2011-10-17 22:59:46 --> Router Class Initialized
DEBUG - 2011-10-17 22:59:46 --> Output Class Initialized
DEBUG - 2011-10-17 22:59:46 --> Input Class Initialized
DEBUG - 2011-10-17 22:59:46 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-17 22:59:46 --> Language Class Initialized
DEBUG - 2011-10-17 22:59:46 --> Loader Class Initialized
DEBUG - 2011-10-17 22:59:46 --> Controller Class Initialized
ERROR - 2011-10-17 22:59:46 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-10-17 22:59:46 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-10-17 22:59:46 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-17 22:59:46 --> Model Class Initialized
DEBUG - 2011-10-17 22:59:46 --> Model Class Initialized
DEBUG - 2011-10-17 22:59:46 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-17 22:59:46 --> Database Driver Class Initialized
DEBUG - 2011-10-17 22:59:46 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-17 22:59:46 --> Helper loaded: url_helper
DEBUG - 2011-10-17 22:59:46 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-17 22:59:46 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-17 22:59:46 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-17 22:59:46 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-17 22:59:46 --> Final output sent to browser
DEBUG - 2011-10-17 22:59:46 --> Total execution time: 0.0933
DEBUG - 2011-10-17 22:59:47 --> Config Class Initialized
DEBUG - 2011-10-17 22:59:47 --> Hooks Class Initialized
DEBUG - 2011-10-17 22:59:47 --> Utf8 Class Initialized
DEBUG - 2011-10-17 22:59:47 --> UTF-8 Support Enabled
DEBUG - 2011-10-17 22:59:47 --> URI Class Initialized
DEBUG - 2011-10-17 22:59:47 --> Router Class Initialized
DEBUG - 2011-10-17 22:59:47 --> Output Class Initialized
DEBUG - 2011-10-17 22:59:47 --> Input Class Initialized
DEBUG - 2011-10-17 22:59:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-17 22:59:47 --> Language Class Initialized
DEBUG - 2011-10-17 22:59:47 --> Loader Class Initialized
DEBUG - 2011-10-17 22:59:47 --> Controller Class Initialized
DEBUG - 2011-10-17 22:59:47 --> Model Class Initialized
DEBUG - 2011-10-17 22:59:47 --> Model Class Initialized
DEBUG - 2011-10-17 22:59:47 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-17 22:59:47 --> Database Driver Class Initialized
DEBUG - 2011-10-17 22:59:47 --> Final output sent to browser
DEBUG - 2011-10-17 22:59:47 --> Total execution time: 0.5635
DEBUG - 2011-10-17 22:59:49 --> Config Class Initialized
DEBUG - 2011-10-17 22:59:49 --> Hooks Class Initialized
DEBUG - 2011-10-17 22:59:49 --> Utf8 Class Initialized
DEBUG - 2011-10-17 22:59:49 --> UTF-8 Support Enabled
DEBUG - 2011-10-17 22:59:49 --> URI Class Initialized
DEBUG - 2011-10-17 22:59:49 --> Router Class Initialized
ERROR - 2011-10-17 22:59:49 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-17 23:05:57 --> Config Class Initialized
DEBUG - 2011-10-17 23:05:57 --> Hooks Class Initialized
DEBUG - 2011-10-17 23:05:57 --> Utf8 Class Initialized
DEBUG - 2011-10-17 23:05:57 --> UTF-8 Support Enabled
DEBUG - 2011-10-17 23:05:57 --> URI Class Initialized
DEBUG - 2011-10-17 23:05:57 --> Router Class Initialized
DEBUG - 2011-10-17 23:05:57 --> Output Class Initialized
DEBUG - 2011-10-17 23:05:57 --> Input Class Initialized
DEBUG - 2011-10-17 23:05:57 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-17 23:05:57 --> Language Class Initialized
DEBUG - 2011-10-17 23:05:57 --> Loader Class Initialized
DEBUG - 2011-10-17 23:05:57 --> Controller Class Initialized
DEBUG - 2011-10-17 23:05:57 --> Model Class Initialized
DEBUG - 2011-10-17 23:05:57 --> Model Class Initialized
DEBUG - 2011-10-17 23:05:57 --> Model Class Initialized
DEBUG - 2011-10-17 23:05:57 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-17 23:05:57 --> Database Driver Class Initialized
DEBUG - 2011-10-17 23:05:57 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-17 23:05:57 --> Helper loaded: url_helper
DEBUG - 2011-10-17 23:05:57 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-17 23:05:57 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-17 23:05:57 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-17 23:05:57 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-17 23:05:57 --> Final output sent to browser
DEBUG - 2011-10-17 23:05:57 --> Total execution time: 0.4130
DEBUG - 2011-10-17 23:05:59 --> Config Class Initialized
DEBUG - 2011-10-17 23:05:59 --> Hooks Class Initialized
DEBUG - 2011-10-17 23:05:59 --> Utf8 Class Initialized
DEBUG - 2011-10-17 23:05:59 --> UTF-8 Support Enabled
DEBUG - 2011-10-17 23:05:59 --> URI Class Initialized
DEBUG - 2011-10-17 23:05:59 --> Router Class Initialized
ERROR - 2011-10-17 23:05:59 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-17 23:06:52 --> Config Class Initialized
DEBUG - 2011-10-17 23:06:52 --> Hooks Class Initialized
DEBUG - 2011-10-17 23:06:52 --> Utf8 Class Initialized
DEBUG - 2011-10-17 23:06:52 --> UTF-8 Support Enabled
DEBUG - 2011-10-17 23:06:52 --> URI Class Initialized
DEBUG - 2011-10-17 23:06:52 --> Router Class Initialized
DEBUG - 2011-10-17 23:06:52 --> Output Class Initialized
DEBUG - 2011-10-17 23:06:52 --> Input Class Initialized
DEBUG - 2011-10-17 23:06:52 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-17 23:06:52 --> Language Class Initialized
DEBUG - 2011-10-17 23:06:52 --> Loader Class Initialized
DEBUG - 2011-10-17 23:06:52 --> Controller Class Initialized
DEBUG - 2011-10-17 23:06:52 --> Model Class Initialized
DEBUG - 2011-10-17 23:06:52 --> Model Class Initialized
DEBUG - 2011-10-17 23:06:52 --> Model Class Initialized
DEBUG - 2011-10-17 23:06:52 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-17 23:06:52 --> Database Driver Class Initialized
DEBUG - 2011-10-17 23:06:52 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-17 23:06:52 --> Helper loaded: url_helper
DEBUG - 2011-10-17 23:06:52 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-17 23:06:52 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-17 23:06:52 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-17 23:06:52 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-17 23:06:52 --> Final output sent to browser
DEBUG - 2011-10-17 23:06:52 --> Total execution time: 0.2433
DEBUG - 2011-10-17 23:06:53 --> Config Class Initialized
DEBUG - 2011-10-17 23:06:53 --> Hooks Class Initialized
DEBUG - 2011-10-17 23:06:53 --> Utf8 Class Initialized
DEBUG - 2011-10-17 23:06:53 --> UTF-8 Support Enabled
DEBUG - 2011-10-17 23:06:53 --> URI Class Initialized
DEBUG - 2011-10-17 23:06:53 --> Router Class Initialized
DEBUG - 2011-10-17 23:06:53 --> Output Class Initialized
DEBUG - 2011-10-17 23:06:53 --> Input Class Initialized
DEBUG - 2011-10-17 23:06:53 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-17 23:06:53 --> Language Class Initialized
DEBUG - 2011-10-17 23:06:53 --> Loader Class Initialized
DEBUG - 2011-10-17 23:06:53 --> Controller Class Initialized
DEBUG - 2011-10-17 23:06:53 --> Model Class Initialized
DEBUG - 2011-10-17 23:06:53 --> Model Class Initialized
DEBUG - 2011-10-17 23:06:53 --> Model Class Initialized
DEBUG - 2011-10-17 23:06:53 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-17 23:06:53 --> Database Driver Class Initialized
DEBUG - 2011-10-17 23:06:53 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-17 23:06:53 --> Helper loaded: url_helper
DEBUG - 2011-10-17 23:06:53 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-17 23:06:53 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-17 23:06:53 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-17 23:06:53 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-17 23:06:53 --> Final output sent to browser
DEBUG - 2011-10-17 23:06:53 --> Total execution time: 0.1347
DEBUG - 2011-10-17 23:07:09 --> Config Class Initialized
DEBUG - 2011-10-17 23:07:09 --> Hooks Class Initialized
DEBUG - 2011-10-17 23:07:09 --> Utf8 Class Initialized
DEBUG - 2011-10-17 23:07:09 --> UTF-8 Support Enabled
DEBUG - 2011-10-17 23:07:09 --> URI Class Initialized
DEBUG - 2011-10-17 23:07:09 --> Router Class Initialized
DEBUG - 2011-10-17 23:07:09 --> Output Class Initialized
DEBUG - 2011-10-17 23:07:09 --> Input Class Initialized
DEBUG - 2011-10-17 23:07:09 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-17 23:07:09 --> Language Class Initialized
DEBUG - 2011-10-17 23:07:09 --> Loader Class Initialized
DEBUG - 2011-10-17 23:07:09 --> Controller Class Initialized
DEBUG - 2011-10-17 23:07:09 --> Model Class Initialized
DEBUG - 2011-10-17 23:07:09 --> Model Class Initialized
DEBUG - 2011-10-17 23:07:09 --> Model Class Initialized
DEBUG - 2011-10-17 23:07:09 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-17 23:07:09 --> Database Driver Class Initialized
DEBUG - 2011-10-17 23:07:09 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-17 23:07:09 --> Helper loaded: url_helper
DEBUG - 2011-10-17 23:07:09 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-17 23:07:09 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-17 23:07:09 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-17 23:07:09 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-17 23:07:09 --> Final output sent to browser
DEBUG - 2011-10-17 23:07:09 --> Total execution time: 0.2024
DEBUG - 2011-10-17 23:07:31 --> Config Class Initialized
DEBUG - 2011-10-17 23:07:31 --> Hooks Class Initialized
DEBUG - 2011-10-17 23:07:31 --> Utf8 Class Initialized
DEBUG - 2011-10-17 23:07:31 --> UTF-8 Support Enabled
DEBUG - 2011-10-17 23:07:31 --> URI Class Initialized
DEBUG - 2011-10-17 23:07:31 --> Router Class Initialized
DEBUG - 2011-10-17 23:07:31 --> Output Class Initialized
DEBUG - 2011-10-17 23:07:31 --> Input Class Initialized
DEBUG - 2011-10-17 23:07:31 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-17 23:07:31 --> Language Class Initialized
DEBUG - 2011-10-17 23:07:31 --> Loader Class Initialized
DEBUG - 2011-10-17 23:07:31 --> Controller Class Initialized
DEBUG - 2011-10-17 23:07:31 --> Model Class Initialized
DEBUG - 2011-10-17 23:07:31 --> Model Class Initialized
DEBUG - 2011-10-17 23:07:31 --> Model Class Initialized
DEBUG - 2011-10-17 23:07:31 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-17 23:07:31 --> Database Driver Class Initialized
DEBUG - 2011-10-17 23:07:31 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-17 23:07:31 --> Helper loaded: url_helper
DEBUG - 2011-10-17 23:07:31 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-17 23:07:31 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-17 23:07:31 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-17 23:07:31 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-17 23:07:31 --> Final output sent to browser
DEBUG - 2011-10-17 23:07:31 --> Total execution time: 0.0548
DEBUG - 2011-10-17 23:07:33 --> Config Class Initialized
DEBUG - 2011-10-17 23:07:33 --> Hooks Class Initialized
DEBUG - 2011-10-17 23:07:33 --> Utf8 Class Initialized
DEBUG - 2011-10-17 23:07:33 --> UTF-8 Support Enabled
DEBUG - 2011-10-17 23:07:33 --> URI Class Initialized
DEBUG - 2011-10-17 23:07:33 --> Router Class Initialized
DEBUG - 2011-10-17 23:07:33 --> Output Class Initialized
DEBUG - 2011-10-17 23:07:33 --> Input Class Initialized
DEBUG - 2011-10-17 23:07:33 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-17 23:07:33 --> Language Class Initialized
DEBUG - 2011-10-17 23:07:33 --> Loader Class Initialized
DEBUG - 2011-10-17 23:07:33 --> Controller Class Initialized
DEBUG - 2011-10-17 23:07:33 --> Model Class Initialized
DEBUG - 2011-10-17 23:07:33 --> Model Class Initialized
DEBUG - 2011-10-17 23:07:33 --> Model Class Initialized
DEBUG - 2011-10-17 23:07:33 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-17 23:07:33 --> Database Driver Class Initialized
DEBUG - 2011-10-17 23:07:33 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-17 23:07:33 --> Helper loaded: url_helper
DEBUG - 2011-10-17 23:07:33 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-17 23:07:33 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-17 23:07:33 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-17 23:07:33 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-17 23:07:33 --> Final output sent to browser
DEBUG - 2011-10-17 23:07:33 --> Total execution time: 0.0586
DEBUG - 2011-10-17 23:34:35 --> Config Class Initialized
DEBUG - 2011-10-17 23:34:35 --> Hooks Class Initialized
DEBUG - 2011-10-17 23:34:35 --> Utf8 Class Initialized
DEBUG - 2011-10-17 23:34:35 --> UTF-8 Support Enabled
DEBUG - 2011-10-17 23:34:35 --> URI Class Initialized
DEBUG - 2011-10-17 23:34:35 --> Router Class Initialized
DEBUG - 2011-10-17 23:34:35 --> Output Class Initialized
DEBUG - 2011-10-17 23:34:35 --> Input Class Initialized
DEBUG - 2011-10-17 23:34:35 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-17 23:34:35 --> Language Class Initialized
DEBUG - 2011-10-17 23:34:35 --> Loader Class Initialized
DEBUG - 2011-10-17 23:34:35 --> Controller Class Initialized
ERROR - 2011-10-17 23:34:35 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-10-17 23:34:35 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-10-17 23:34:35 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-17 23:34:35 --> Model Class Initialized
DEBUG - 2011-10-17 23:34:35 --> Model Class Initialized
DEBUG - 2011-10-17 23:34:35 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-17 23:34:35 --> Database Driver Class Initialized
DEBUG - 2011-10-17 23:34:35 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-17 23:34:35 --> Helper loaded: url_helper
DEBUG - 2011-10-17 23:34:35 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-17 23:34:35 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-17 23:34:35 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-17 23:34:35 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-17 23:34:35 --> Final output sent to browser
DEBUG - 2011-10-17 23:34:35 --> Total execution time: 0.0447
DEBUG - 2011-10-17 23:34:36 --> Config Class Initialized
DEBUG - 2011-10-17 23:34:36 --> Hooks Class Initialized
DEBUG - 2011-10-17 23:34:36 --> Utf8 Class Initialized
DEBUG - 2011-10-17 23:34:36 --> UTF-8 Support Enabled
DEBUG - 2011-10-17 23:34:36 --> URI Class Initialized
DEBUG - 2011-10-17 23:34:36 --> Router Class Initialized
DEBUG - 2011-10-17 23:34:36 --> Output Class Initialized
DEBUG - 2011-10-17 23:34:36 --> Input Class Initialized
DEBUG - 2011-10-17 23:34:36 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-17 23:34:36 --> Language Class Initialized
DEBUG - 2011-10-17 23:34:36 --> Loader Class Initialized
DEBUG - 2011-10-17 23:34:36 --> Controller Class Initialized
DEBUG - 2011-10-17 23:34:36 --> Model Class Initialized
DEBUG - 2011-10-17 23:34:36 --> Model Class Initialized
DEBUG - 2011-10-17 23:34:36 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-17 23:34:36 --> Database Driver Class Initialized
DEBUG - 2011-10-17 23:34:37 --> Final output sent to browser
DEBUG - 2011-10-17 23:34:37 --> Total execution time: 0.6014
DEBUG - 2011-10-17 23:34:37 --> Config Class Initialized
DEBUG - 2011-10-17 23:34:37 --> Hooks Class Initialized
DEBUG - 2011-10-17 23:34:37 --> Utf8 Class Initialized
DEBUG - 2011-10-17 23:34:37 --> UTF-8 Support Enabled
DEBUG - 2011-10-17 23:34:37 --> URI Class Initialized
DEBUG - 2011-10-17 23:34:37 --> Router Class Initialized
DEBUG - 2011-10-17 23:34:37 --> Output Class Initialized
DEBUG - 2011-10-17 23:34:37 --> Input Class Initialized
DEBUG - 2011-10-17 23:34:37 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-17 23:34:37 --> Language Class Initialized
DEBUG - 2011-10-17 23:34:37 --> Loader Class Initialized
DEBUG - 2011-10-17 23:34:37 --> Controller Class Initialized
ERROR - 2011-10-17 23:34:37 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-10-17 23:34:37 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-10-17 23:34:37 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-17 23:34:37 --> Model Class Initialized
DEBUG - 2011-10-17 23:34:37 --> Model Class Initialized
DEBUG - 2011-10-17 23:34:37 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-17 23:34:37 --> Database Driver Class Initialized
DEBUG - 2011-10-17 23:34:37 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-17 23:34:37 --> Helper loaded: url_helper
DEBUG - 2011-10-17 23:34:37 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-17 23:34:37 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-17 23:34:37 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-17 23:34:37 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-17 23:34:37 --> Final output sent to browser
DEBUG - 2011-10-17 23:34:37 --> Total execution time: 0.0271
DEBUG - 2011-10-17 23:34:38 --> Config Class Initialized
DEBUG - 2011-10-17 23:34:38 --> Hooks Class Initialized
DEBUG - 2011-10-17 23:34:38 --> Utf8 Class Initialized
DEBUG - 2011-10-17 23:34:38 --> UTF-8 Support Enabled
DEBUG - 2011-10-17 23:34:38 --> URI Class Initialized
DEBUG - 2011-10-17 23:34:38 --> Router Class Initialized
ERROR - 2011-10-17 23:34:38 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-17 23:34:39 --> Config Class Initialized
DEBUG - 2011-10-17 23:34:39 --> Hooks Class Initialized
DEBUG - 2011-10-17 23:34:39 --> Utf8 Class Initialized
DEBUG - 2011-10-17 23:34:39 --> UTF-8 Support Enabled
DEBUG - 2011-10-17 23:34:39 --> URI Class Initialized
DEBUG - 2011-10-17 23:34:39 --> Router Class Initialized
ERROR - 2011-10-17 23:34:39 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-17 23:35:02 --> Config Class Initialized
DEBUG - 2011-10-17 23:35:02 --> Hooks Class Initialized
DEBUG - 2011-10-17 23:35:02 --> Utf8 Class Initialized
DEBUG - 2011-10-17 23:35:02 --> UTF-8 Support Enabled
DEBUG - 2011-10-17 23:35:02 --> URI Class Initialized
DEBUG - 2011-10-17 23:35:02 --> Router Class Initialized
DEBUG - 2011-10-17 23:35:02 --> Output Class Initialized
DEBUG - 2011-10-17 23:35:02 --> Input Class Initialized
DEBUG - 2011-10-17 23:35:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-17 23:35:02 --> Language Class Initialized
DEBUG - 2011-10-17 23:35:02 --> Loader Class Initialized
DEBUG - 2011-10-17 23:35:02 --> Controller Class Initialized
ERROR - 2011-10-17 23:35:02 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-10-17 23:35:02 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-10-17 23:35:02 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-17 23:35:02 --> Model Class Initialized
DEBUG - 2011-10-17 23:35:02 --> Model Class Initialized
DEBUG - 2011-10-17 23:35:02 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-17 23:35:02 --> Database Driver Class Initialized
DEBUG - 2011-10-17 23:35:02 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-17 23:35:02 --> Helper loaded: url_helper
DEBUG - 2011-10-17 23:35:02 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-17 23:35:02 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-17 23:35:02 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-17 23:35:02 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-17 23:35:02 --> Final output sent to browser
DEBUG - 2011-10-17 23:35:02 --> Total execution time: 0.0727
DEBUG - 2011-10-17 23:35:03 --> Config Class Initialized
DEBUG - 2011-10-17 23:35:03 --> Hooks Class Initialized
DEBUG - 2011-10-17 23:35:03 --> Utf8 Class Initialized
DEBUG - 2011-10-17 23:35:03 --> UTF-8 Support Enabled
DEBUG - 2011-10-17 23:35:03 --> URI Class Initialized
DEBUG - 2011-10-17 23:35:03 --> Router Class Initialized
DEBUG - 2011-10-17 23:35:03 --> Output Class Initialized
DEBUG - 2011-10-17 23:35:03 --> Input Class Initialized
DEBUG - 2011-10-17 23:35:03 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-17 23:35:03 --> Language Class Initialized
DEBUG - 2011-10-17 23:35:03 --> Loader Class Initialized
DEBUG - 2011-10-17 23:35:03 --> Controller Class Initialized
DEBUG - 2011-10-17 23:35:03 --> Model Class Initialized
DEBUG - 2011-10-17 23:35:03 --> Model Class Initialized
DEBUG - 2011-10-17 23:35:03 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-17 23:35:03 --> Database Driver Class Initialized
DEBUG - 2011-10-17 23:35:04 --> Final output sent to browser
DEBUG - 2011-10-17 23:35:04 --> Total execution time: 0.5427
DEBUG - 2011-10-17 23:35:05 --> Config Class Initialized
DEBUG - 2011-10-17 23:35:05 --> Hooks Class Initialized
DEBUG - 2011-10-17 23:35:05 --> Utf8 Class Initialized
DEBUG - 2011-10-17 23:35:05 --> UTF-8 Support Enabled
DEBUG - 2011-10-17 23:35:05 --> URI Class Initialized
DEBUG - 2011-10-17 23:35:05 --> Router Class Initialized
ERROR - 2011-10-17 23:35:05 --> 404 Page Not Found --> favicon.ico

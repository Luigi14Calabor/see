<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2011-09-06 01:14:20 --> Config Class Initialized
DEBUG - 2011-09-06 01:14:20 --> Hooks Class Initialized
DEBUG - 2011-09-06 01:14:20 --> Utf8 Class Initialized
DEBUG - 2011-09-06 01:14:20 --> UTF-8 Support Enabled
DEBUG - 2011-09-06 01:14:20 --> URI Class Initialized
DEBUG - 2011-09-06 01:14:20 --> Router Class Initialized
DEBUG - 2011-09-06 01:14:20 --> Output Class Initialized
DEBUG - 2011-09-06 01:14:20 --> Input Class Initialized
DEBUG - 2011-09-06 01:14:20 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-06 01:14:20 --> Language Class Initialized
DEBUG - 2011-09-06 01:14:20 --> Loader Class Initialized
DEBUG - 2011-09-06 01:14:20 --> Controller Class Initialized
DEBUG - 2011-09-06 01:14:20 --> Model Class Initialized
DEBUG - 2011-09-06 01:14:20 --> Model Class Initialized
DEBUG - 2011-09-06 01:14:20 --> Model Class Initialized
DEBUG - 2011-09-06 01:14:20 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-06 01:14:20 --> Database Driver Class Initialized
DEBUG - 2011-09-06 01:14:20 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-06 01:14:20 --> Helper loaded: url_helper
DEBUG - 2011-09-06 01:14:20 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-06 01:14:20 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-06 01:14:20 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-06 01:14:20 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-06 01:14:20 --> Final output sent to browser
DEBUG - 2011-09-06 01:14:20 --> Total execution time: 0.2491
DEBUG - 2011-09-06 01:14:21 --> Config Class Initialized
DEBUG - 2011-09-06 01:14:21 --> Hooks Class Initialized
DEBUG - 2011-09-06 01:14:21 --> Utf8 Class Initialized
DEBUG - 2011-09-06 01:14:21 --> UTF-8 Support Enabled
DEBUG - 2011-09-06 01:14:21 --> URI Class Initialized
DEBUG - 2011-09-06 01:14:21 --> Router Class Initialized
DEBUG - 2011-09-06 01:14:21 --> Output Class Initialized
DEBUG - 2011-09-06 01:14:21 --> Input Class Initialized
DEBUG - 2011-09-06 01:14:21 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-06 01:14:21 --> Language Class Initialized
DEBUG - 2011-09-06 01:14:21 --> Loader Class Initialized
DEBUG - 2011-09-06 01:14:21 --> Controller Class Initialized
DEBUG - 2011-09-06 01:14:21 --> Model Class Initialized
DEBUG - 2011-09-06 01:14:21 --> Model Class Initialized
DEBUG - 2011-09-06 01:14:21 --> Model Class Initialized
DEBUG - 2011-09-06 01:14:21 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-06 01:14:21 --> Database Driver Class Initialized
DEBUG - 2011-09-06 01:14:21 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-06 01:14:21 --> Helper loaded: url_helper
DEBUG - 2011-09-06 01:14:21 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-06 01:14:21 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-06 01:14:21 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-06 01:14:21 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-06 01:14:21 --> Final output sent to browser
DEBUG - 2011-09-06 01:14:21 --> Total execution time: 0.2242
DEBUG - 2011-09-06 01:14:22 --> Config Class Initialized
DEBUG - 2011-09-06 01:14:22 --> Hooks Class Initialized
DEBUG - 2011-09-06 01:14:22 --> Utf8 Class Initialized
DEBUG - 2011-09-06 01:14:22 --> UTF-8 Support Enabled
DEBUG - 2011-09-06 01:14:22 --> URI Class Initialized
DEBUG - 2011-09-06 01:14:22 --> Router Class Initialized
DEBUG - 2011-09-06 01:14:22 --> Output Class Initialized
DEBUG - 2011-09-06 01:14:22 --> Input Class Initialized
DEBUG - 2011-09-06 01:14:22 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-06 01:14:22 --> Language Class Initialized
DEBUG - 2011-09-06 01:14:22 --> Loader Class Initialized
DEBUG - 2011-09-06 01:14:22 --> Controller Class Initialized
DEBUG - 2011-09-06 01:14:22 --> Model Class Initialized
DEBUG - 2011-09-06 01:14:22 --> Model Class Initialized
DEBUG - 2011-09-06 01:14:22 --> Model Class Initialized
DEBUG - 2011-09-06 01:14:22 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-06 01:14:22 --> Database Driver Class Initialized
DEBUG - 2011-09-06 01:14:23 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-06 01:14:23 --> Helper loaded: url_helper
DEBUG - 2011-09-06 01:14:23 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-06 01:14:23 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-06 01:14:23 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-06 01:14:23 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-06 01:14:23 --> Final output sent to browser
DEBUG - 2011-09-06 01:14:23 --> Total execution time: 0.8261
DEBUG - 2011-09-06 01:15:03 --> Config Class Initialized
DEBUG - 2011-09-06 01:15:03 --> Hooks Class Initialized
DEBUG - 2011-09-06 01:15:03 --> Utf8 Class Initialized
DEBUG - 2011-09-06 01:15:03 --> UTF-8 Support Enabled
DEBUG - 2011-09-06 01:15:03 --> URI Class Initialized
DEBUG - 2011-09-06 01:15:03 --> Router Class Initialized
DEBUG - 2011-09-06 01:15:03 --> No URI present. Default controller set.
DEBUG - 2011-09-06 01:15:03 --> Output Class Initialized
DEBUG - 2011-09-06 01:15:03 --> Input Class Initialized
DEBUG - 2011-09-06 01:15:03 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-06 01:15:03 --> Language Class Initialized
DEBUG - 2011-09-06 01:15:03 --> Loader Class Initialized
DEBUG - 2011-09-06 01:15:03 --> Controller Class Initialized
DEBUG - 2011-09-06 01:15:03 --> File loaded: application/views/splash/main.php
DEBUG - 2011-09-06 01:15:03 --> Helper loaded: url_helper
DEBUG - 2011-09-06 01:15:03 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-06 01:15:03 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-06 01:15:03 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-06 01:15:03 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-06 01:15:03 --> Final output sent to browser
DEBUG - 2011-09-06 01:15:03 --> Total execution time: 0.6313
DEBUG - 2011-09-06 01:26:38 --> Config Class Initialized
DEBUG - 2011-09-06 01:26:38 --> Hooks Class Initialized
DEBUG - 2011-09-06 01:26:38 --> Utf8 Class Initialized
DEBUG - 2011-09-06 01:26:38 --> UTF-8 Support Enabled
DEBUG - 2011-09-06 01:26:38 --> URI Class Initialized
DEBUG - 2011-09-06 01:26:38 --> Router Class Initialized
DEBUG - 2011-09-06 01:26:38 --> No URI present. Default controller set.
DEBUG - 2011-09-06 01:26:38 --> Output Class Initialized
DEBUG - 2011-09-06 01:26:38 --> Input Class Initialized
DEBUG - 2011-09-06 01:26:38 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-06 01:26:38 --> Language Class Initialized
DEBUG - 2011-09-06 01:26:38 --> Loader Class Initialized
DEBUG - 2011-09-06 01:26:38 --> Controller Class Initialized
DEBUG - 2011-09-06 01:26:38 --> File loaded: application/views/splash/main.php
DEBUG - 2011-09-06 01:26:38 --> Helper loaded: url_helper
DEBUG - 2011-09-06 01:26:38 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-06 01:26:38 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-06 01:26:38 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-06 01:26:38 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-06 01:26:38 --> Final output sent to browser
DEBUG - 2011-09-06 01:26:38 --> Total execution time: 0.0144
DEBUG - 2011-09-06 03:26:14 --> Config Class Initialized
DEBUG - 2011-09-06 03:26:14 --> Hooks Class Initialized
DEBUG - 2011-09-06 03:26:14 --> Utf8 Class Initialized
DEBUG - 2011-09-06 03:26:14 --> UTF-8 Support Enabled
DEBUG - 2011-09-06 03:26:14 --> URI Class Initialized
DEBUG - 2011-09-06 03:26:14 --> Router Class Initialized
DEBUG - 2011-09-06 03:26:14 --> Output Class Initialized
DEBUG - 2011-09-06 03:26:14 --> Input Class Initialized
DEBUG - 2011-09-06 03:26:14 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-06 03:26:14 --> Language Class Initialized
DEBUG - 2011-09-06 03:26:14 --> Loader Class Initialized
DEBUG - 2011-09-06 03:26:14 --> Controller Class Initialized
ERROR - 2011-09-06 03:26:14 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-06 03:26:14 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-06 03:26:14 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-06 03:26:14 --> Model Class Initialized
DEBUG - 2011-09-06 03:26:14 --> Model Class Initialized
DEBUG - 2011-09-06 03:26:14 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-06 03:26:14 --> Database Driver Class Initialized
DEBUG - 2011-09-06 03:26:14 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-06 03:26:14 --> Helper loaded: url_helper
DEBUG - 2011-09-06 03:26:14 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-06 03:26:14 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-06 03:26:14 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-06 03:26:14 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-06 03:26:14 --> Final output sent to browser
DEBUG - 2011-09-06 03:26:14 --> Total execution time: 0.7417
DEBUG - 2011-09-06 03:32:51 --> Config Class Initialized
DEBUG - 2011-09-06 03:32:51 --> Hooks Class Initialized
DEBUG - 2011-09-06 03:32:51 --> Utf8 Class Initialized
DEBUG - 2011-09-06 03:32:51 --> UTF-8 Support Enabled
DEBUG - 2011-09-06 03:32:51 --> URI Class Initialized
DEBUG - 2011-09-06 03:32:51 --> Router Class Initialized
DEBUG - 2011-09-06 03:32:51 --> No URI present. Default controller set.
DEBUG - 2011-09-06 03:32:51 --> Output Class Initialized
DEBUG - 2011-09-06 03:32:51 --> Input Class Initialized
DEBUG - 2011-09-06 03:32:51 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-06 03:32:51 --> Language Class Initialized
DEBUG - 2011-09-06 03:32:51 --> Loader Class Initialized
DEBUG - 2011-09-06 03:32:51 --> Controller Class Initialized
DEBUG - 2011-09-06 03:32:51 --> File loaded: application/views/splash/main.php
DEBUG - 2011-09-06 03:32:51 --> Helper loaded: url_helper
DEBUG - 2011-09-06 03:32:51 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-06 03:32:51 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-06 03:32:51 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-06 03:32:51 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-06 03:32:51 --> Final output sent to browser
DEBUG - 2011-09-06 03:32:51 --> Total execution time: 0.5693
DEBUG - 2011-09-06 05:36:55 --> Config Class Initialized
DEBUG - 2011-09-06 05:36:55 --> Hooks Class Initialized
DEBUG - 2011-09-06 05:36:55 --> Utf8 Class Initialized
DEBUG - 2011-09-06 05:36:55 --> UTF-8 Support Enabled
DEBUG - 2011-09-06 05:36:55 --> URI Class Initialized
DEBUG - 2011-09-06 05:36:55 --> Router Class Initialized
DEBUG - 2011-09-06 05:36:55 --> Output Class Initialized
DEBUG - 2011-09-06 05:36:55 --> Input Class Initialized
DEBUG - 2011-09-06 05:36:55 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-06 05:36:55 --> Language Class Initialized
DEBUG - 2011-09-06 05:36:55 --> Loader Class Initialized
DEBUG - 2011-09-06 05:36:55 --> Controller Class Initialized
ERROR - 2011-09-06 05:36:55 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-06 05:36:55 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-06 05:36:55 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-06 05:36:55 --> Model Class Initialized
DEBUG - 2011-09-06 05:36:55 --> Model Class Initialized
DEBUG - 2011-09-06 05:36:55 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-06 05:36:55 --> Database Driver Class Initialized
DEBUG - 2011-09-06 05:36:55 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-06 05:36:55 --> Helper loaded: url_helper
DEBUG - 2011-09-06 05:36:55 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-06 05:36:55 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-06 05:36:55 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-06 05:36:55 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-06 05:36:55 --> Final output sent to browser
DEBUG - 2011-09-06 05:36:55 --> Total execution time: 0.6141
DEBUG - 2011-09-06 05:37:00 --> Config Class Initialized
DEBUG - 2011-09-06 05:37:00 --> Hooks Class Initialized
DEBUG - 2011-09-06 05:37:00 --> Utf8 Class Initialized
DEBUG - 2011-09-06 05:37:00 --> UTF-8 Support Enabled
DEBUG - 2011-09-06 05:37:00 --> URI Class Initialized
DEBUG - 2011-09-06 05:37:00 --> Router Class Initialized
DEBUG - 2011-09-06 05:37:00 --> Output Class Initialized
DEBUG - 2011-09-06 05:37:00 --> Input Class Initialized
DEBUG - 2011-09-06 05:37:00 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-06 05:37:00 --> Language Class Initialized
DEBUG - 2011-09-06 05:37:00 --> Loader Class Initialized
DEBUG - 2011-09-06 05:37:00 --> Controller Class Initialized
DEBUG - 2011-09-06 05:37:00 --> Model Class Initialized
DEBUG - 2011-09-06 05:37:00 --> Model Class Initialized
DEBUG - 2011-09-06 05:37:00 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-06 05:37:00 --> Database Driver Class Initialized
DEBUG - 2011-09-06 05:37:01 --> Final output sent to browser
DEBUG - 2011-09-06 05:37:01 --> Total execution time: 0.8036
DEBUG - 2011-09-06 05:37:06 --> Config Class Initialized
DEBUG - 2011-09-06 05:37:06 --> Hooks Class Initialized
DEBUG - 2011-09-06 05:37:06 --> Utf8 Class Initialized
DEBUG - 2011-09-06 05:37:06 --> UTF-8 Support Enabled
DEBUG - 2011-09-06 05:37:06 --> URI Class Initialized
DEBUG - 2011-09-06 05:37:06 --> Router Class Initialized
ERROR - 2011-09-06 05:37:06 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-06 05:37:09 --> Config Class Initialized
DEBUG - 2011-09-06 05:37:09 --> Hooks Class Initialized
DEBUG - 2011-09-06 05:37:09 --> Utf8 Class Initialized
DEBUG - 2011-09-06 05:37:09 --> UTF-8 Support Enabled
DEBUG - 2011-09-06 05:37:09 --> URI Class Initialized
DEBUG - 2011-09-06 05:37:09 --> Router Class Initialized
ERROR - 2011-09-06 05:37:09 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-06 05:50:59 --> Config Class Initialized
DEBUG - 2011-09-06 05:50:59 --> Hooks Class Initialized
DEBUG - 2011-09-06 05:50:59 --> Utf8 Class Initialized
DEBUG - 2011-09-06 05:50:59 --> UTF-8 Support Enabled
DEBUG - 2011-09-06 05:50:59 --> URI Class Initialized
DEBUG - 2011-09-06 05:50:59 --> Router Class Initialized
DEBUG - 2011-09-06 05:50:59 --> No URI present. Default controller set.
DEBUG - 2011-09-06 05:50:59 --> Output Class Initialized
DEBUG - 2011-09-06 05:50:59 --> Input Class Initialized
DEBUG - 2011-09-06 05:50:59 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-06 05:50:59 --> Language Class Initialized
DEBUG - 2011-09-06 05:50:59 --> Loader Class Initialized
DEBUG - 2011-09-06 05:50:59 --> Controller Class Initialized
DEBUG - 2011-09-06 05:50:59 --> File loaded: application/views/splash/main.php
DEBUG - 2011-09-06 05:50:59 --> Helper loaded: url_helper
DEBUG - 2011-09-06 05:50:59 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-06 05:50:59 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-06 05:50:59 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-06 05:50:59 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-06 05:50:59 --> Final output sent to browser
DEBUG - 2011-09-06 05:50:59 --> Total execution time: 0.1009
DEBUG - 2011-09-06 05:50:59 --> Config Class Initialized
DEBUG - 2011-09-06 05:50:59 --> Hooks Class Initialized
DEBUG - 2011-09-06 05:50:59 --> Utf8 Class Initialized
DEBUG - 2011-09-06 05:50:59 --> UTF-8 Support Enabled
DEBUG - 2011-09-06 05:50:59 --> URI Class Initialized
DEBUG - 2011-09-06 05:50:59 --> Router Class Initialized
ERROR - 2011-09-06 05:50:59 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-09-06 05:50:59 --> Config Class Initialized
DEBUG - 2011-09-06 05:50:59 --> Hooks Class Initialized
DEBUG - 2011-09-06 05:50:59 --> Utf8 Class Initialized
DEBUG - 2011-09-06 05:50:59 --> UTF-8 Support Enabled
DEBUG - 2011-09-06 05:50:59 --> URI Class Initialized
DEBUG - 2011-09-06 05:50:59 --> Router Class Initialized
DEBUG - 2011-09-06 05:50:59 --> Output Class Initialized
DEBUG - 2011-09-06 05:50:59 --> Input Class Initialized
DEBUG - 2011-09-06 05:50:59 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-06 05:50:59 --> Language Class Initialized
DEBUG - 2011-09-06 05:50:59 --> Loader Class Initialized
DEBUG - 2011-09-06 05:50:59 --> Controller Class Initialized
DEBUG - 2011-09-06 05:50:59 --> Model Class Initialized
DEBUG - 2011-09-06 05:50:59 --> Model Class Initialized
DEBUG - 2011-09-06 05:50:59 --> Model Class Initialized
DEBUG - 2011-09-06 05:50:59 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-06 05:50:59 --> Database Driver Class Initialized
DEBUG - 2011-09-06 05:51:00 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-06 05:51:00 --> Helper loaded: url_helper
DEBUG - 2011-09-06 05:51:00 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-06 05:51:00 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-06 05:51:00 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-06 05:51:00 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-06 05:51:00 --> Final output sent to browser
DEBUG - 2011-09-06 05:51:00 --> Total execution time: 0.4117
DEBUG - 2011-09-06 05:51:00 --> Config Class Initialized
DEBUG - 2011-09-06 05:51:00 --> Hooks Class Initialized
DEBUG - 2011-09-06 05:51:00 --> Utf8 Class Initialized
DEBUG - 2011-09-06 05:51:00 --> UTF-8 Support Enabled
DEBUG - 2011-09-06 05:51:00 --> URI Class Initialized
DEBUG - 2011-09-06 05:51:00 --> Router Class Initialized
DEBUG - 2011-09-06 05:51:00 --> Output Class Initialized
DEBUG - 2011-09-06 05:51:00 --> Input Class Initialized
DEBUG - 2011-09-06 05:51:00 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-06 05:51:00 --> Language Class Initialized
DEBUG - 2011-09-06 05:51:00 --> Loader Class Initialized
DEBUG - 2011-09-06 05:51:00 --> Controller Class Initialized
ERROR - 2011-09-06 05:51:00 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-06 05:51:00 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-06 05:51:00 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-06 05:51:00 --> Model Class Initialized
DEBUG - 2011-09-06 05:51:00 --> Model Class Initialized
DEBUG - 2011-09-06 05:51:00 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-06 05:51:00 --> Database Driver Class Initialized
DEBUG - 2011-09-06 05:51:00 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-06 05:51:00 --> Helper loaded: url_helper
DEBUG - 2011-09-06 05:51:00 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-06 05:51:00 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-06 05:51:00 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-06 05:51:00 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-06 05:51:00 --> Final output sent to browser
DEBUG - 2011-09-06 05:51:00 --> Total execution time: 0.0366
DEBUG - 2011-09-06 05:51:01 --> Config Class Initialized
DEBUG - 2011-09-06 05:51:01 --> Hooks Class Initialized
DEBUG - 2011-09-06 05:51:01 --> Utf8 Class Initialized
DEBUG - 2011-09-06 05:51:01 --> UTF-8 Support Enabled
DEBUG - 2011-09-06 05:51:01 --> URI Class Initialized
DEBUG - 2011-09-06 05:51:01 --> Router Class Initialized
DEBUG - 2011-09-06 05:51:01 --> Output Class Initialized
DEBUG - 2011-09-06 05:51:01 --> Input Class Initialized
DEBUG - 2011-09-06 05:51:01 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-06 05:51:01 --> Language Class Initialized
DEBUG - 2011-09-06 05:51:01 --> Loader Class Initialized
DEBUG - 2011-09-06 05:51:01 --> Controller Class Initialized
DEBUG - 2011-09-06 05:51:01 --> Model Class Initialized
DEBUG - 2011-09-06 05:51:01 --> Model Class Initialized
DEBUG - 2011-09-06 05:51:01 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-06 05:51:01 --> Database Driver Class Initialized
DEBUG - 2011-09-06 05:51:02 --> Final output sent to browser
DEBUG - 2011-09-06 05:51:02 --> Total execution time: 0.6252
DEBUG - 2011-09-06 07:09:21 --> Config Class Initialized
DEBUG - 2011-09-06 07:09:22 --> Hooks Class Initialized
DEBUG - 2011-09-06 07:09:22 --> Utf8 Class Initialized
DEBUG - 2011-09-06 07:09:22 --> UTF-8 Support Enabled
DEBUG - 2011-09-06 07:09:22 --> URI Class Initialized
DEBUG - 2011-09-06 07:09:22 --> Router Class Initialized
DEBUG - 2011-09-06 07:09:22 --> Output Class Initialized
DEBUG - 2011-09-06 07:09:22 --> Input Class Initialized
DEBUG - 2011-09-06 07:09:22 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-06 07:09:22 --> Language Class Initialized
DEBUG - 2011-09-06 07:09:22 --> Loader Class Initialized
DEBUG - 2011-09-06 07:09:22 --> Controller Class Initialized
ERROR - 2011-09-06 07:09:22 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-06 07:09:22 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-06 07:09:22 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-06 07:09:22 --> Model Class Initialized
DEBUG - 2011-09-06 07:09:22 --> Model Class Initialized
DEBUG - 2011-09-06 07:09:22 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-06 07:09:22 --> Database Driver Class Initialized
DEBUG - 2011-09-06 07:09:22 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-06 07:09:22 --> Helper loaded: url_helper
DEBUG - 2011-09-06 07:09:22 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-06 07:09:22 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-06 07:09:22 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-06 07:09:22 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-06 07:09:22 --> Final output sent to browser
DEBUG - 2011-09-06 07:09:22 --> Total execution time: 0.2542
DEBUG - 2011-09-06 07:09:25 --> Config Class Initialized
DEBUG - 2011-09-06 07:09:25 --> Hooks Class Initialized
DEBUG - 2011-09-06 07:09:25 --> Utf8 Class Initialized
DEBUG - 2011-09-06 07:09:25 --> UTF-8 Support Enabled
DEBUG - 2011-09-06 07:09:25 --> URI Class Initialized
DEBUG - 2011-09-06 07:09:25 --> Router Class Initialized
DEBUG - 2011-09-06 07:09:25 --> Output Class Initialized
DEBUG - 2011-09-06 07:09:25 --> Input Class Initialized
DEBUG - 2011-09-06 07:09:25 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-06 07:09:25 --> Language Class Initialized
DEBUG - 2011-09-06 07:09:25 --> Loader Class Initialized
DEBUG - 2011-09-06 07:09:25 --> Controller Class Initialized
DEBUG - 2011-09-06 07:09:25 --> Model Class Initialized
DEBUG - 2011-09-06 07:09:25 --> Model Class Initialized
DEBUG - 2011-09-06 07:09:25 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-06 07:09:25 --> Database Driver Class Initialized
DEBUG - 2011-09-06 07:09:26 --> Final output sent to browser
DEBUG - 2011-09-06 07:09:26 --> Total execution time: 1.0029
DEBUG - 2011-09-06 07:09:48 --> Config Class Initialized
DEBUG - 2011-09-06 07:09:48 --> Hooks Class Initialized
DEBUG - 2011-09-06 07:09:48 --> Utf8 Class Initialized
DEBUG - 2011-09-06 07:09:48 --> UTF-8 Support Enabled
DEBUG - 2011-09-06 07:09:48 --> URI Class Initialized
DEBUG - 2011-09-06 07:09:48 --> Router Class Initialized
ERROR - 2011-09-06 07:09:48 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-06 07:09:54 --> Config Class Initialized
DEBUG - 2011-09-06 07:09:54 --> Hooks Class Initialized
DEBUG - 2011-09-06 07:09:54 --> Utf8 Class Initialized
DEBUG - 2011-09-06 07:09:54 --> UTF-8 Support Enabled
DEBUG - 2011-09-06 07:09:54 --> URI Class Initialized
DEBUG - 2011-09-06 07:09:54 --> Router Class Initialized
DEBUG - 2011-09-06 07:09:54 --> Output Class Initialized
DEBUG - 2011-09-06 07:09:54 --> Input Class Initialized
DEBUG - 2011-09-06 07:09:54 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-06 07:09:54 --> Language Class Initialized
DEBUG - 2011-09-06 07:09:54 --> Loader Class Initialized
DEBUG - 2011-09-06 07:09:54 --> Controller Class Initialized
ERROR - 2011-09-06 07:09:54 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-06 07:09:54 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-06 07:09:54 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-06 07:09:54 --> Model Class Initialized
DEBUG - 2011-09-06 07:09:54 --> Model Class Initialized
DEBUG - 2011-09-06 07:09:54 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-06 07:09:54 --> Database Driver Class Initialized
DEBUG - 2011-09-06 07:09:54 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-06 07:09:54 --> Helper loaded: url_helper
DEBUG - 2011-09-06 07:09:54 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-06 07:09:54 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-06 07:09:54 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-06 07:09:54 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-06 07:09:54 --> Final output sent to browser
DEBUG - 2011-09-06 07:09:54 --> Total execution time: 0.0320
DEBUG - 2011-09-06 07:09:55 --> Config Class Initialized
DEBUG - 2011-09-06 07:09:55 --> Hooks Class Initialized
DEBUG - 2011-09-06 07:09:55 --> Utf8 Class Initialized
DEBUG - 2011-09-06 07:09:55 --> UTF-8 Support Enabled
DEBUG - 2011-09-06 07:09:55 --> URI Class Initialized
DEBUG - 2011-09-06 07:09:55 --> Router Class Initialized
DEBUG - 2011-09-06 07:09:55 --> Output Class Initialized
DEBUG - 2011-09-06 07:09:55 --> Input Class Initialized
DEBUG - 2011-09-06 07:09:55 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-06 07:09:55 --> Language Class Initialized
DEBUG - 2011-09-06 07:09:55 --> Loader Class Initialized
DEBUG - 2011-09-06 07:09:55 --> Controller Class Initialized
DEBUG - 2011-09-06 07:09:55 --> Model Class Initialized
DEBUG - 2011-09-06 07:09:55 --> Model Class Initialized
DEBUG - 2011-09-06 07:09:55 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-06 07:09:55 --> Database Driver Class Initialized
DEBUG - 2011-09-06 07:09:56 --> Final output sent to browser
DEBUG - 2011-09-06 07:09:56 --> Total execution time: 1.6186
DEBUG - 2011-09-06 07:09:58 --> Config Class Initialized
DEBUG - 2011-09-06 07:09:58 --> Hooks Class Initialized
DEBUG - 2011-09-06 07:09:58 --> Utf8 Class Initialized
DEBUG - 2011-09-06 07:09:58 --> UTF-8 Support Enabled
DEBUG - 2011-09-06 07:09:58 --> URI Class Initialized
DEBUG - 2011-09-06 07:09:58 --> Router Class Initialized
ERROR - 2011-09-06 07:09:58 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-06 07:10:11 --> Config Class Initialized
DEBUG - 2011-09-06 07:10:11 --> Hooks Class Initialized
DEBUG - 2011-09-06 07:10:11 --> Utf8 Class Initialized
DEBUG - 2011-09-06 07:10:11 --> UTF-8 Support Enabled
DEBUG - 2011-09-06 07:10:11 --> URI Class Initialized
DEBUG - 2011-09-06 07:10:11 --> Router Class Initialized
DEBUG - 2011-09-06 07:10:11 --> Output Class Initialized
DEBUG - 2011-09-06 07:10:11 --> Input Class Initialized
DEBUG - 2011-09-06 07:10:11 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-06 07:10:11 --> Language Class Initialized
DEBUG - 2011-09-06 07:10:11 --> Loader Class Initialized
DEBUG - 2011-09-06 07:10:11 --> Controller Class Initialized
ERROR - 2011-09-06 07:10:11 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-06 07:10:11 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-06 07:10:11 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-06 07:10:11 --> Model Class Initialized
DEBUG - 2011-09-06 07:10:11 --> Model Class Initialized
DEBUG - 2011-09-06 07:10:11 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-06 07:10:11 --> Database Driver Class Initialized
DEBUG - 2011-09-06 07:10:11 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-06 07:10:11 --> Helper loaded: url_helper
DEBUG - 2011-09-06 07:10:11 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-06 07:10:11 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-06 07:10:11 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-06 07:10:11 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-06 07:10:11 --> Final output sent to browser
DEBUG - 2011-09-06 07:10:11 --> Total execution time: 0.0603
DEBUG - 2011-09-06 07:10:13 --> Config Class Initialized
DEBUG - 2011-09-06 07:10:13 --> Hooks Class Initialized
DEBUG - 2011-09-06 07:10:13 --> Utf8 Class Initialized
DEBUG - 2011-09-06 07:10:13 --> UTF-8 Support Enabled
DEBUG - 2011-09-06 07:10:13 --> URI Class Initialized
DEBUG - 2011-09-06 07:10:13 --> Router Class Initialized
DEBUG - 2011-09-06 07:10:13 --> Output Class Initialized
DEBUG - 2011-09-06 07:10:13 --> Input Class Initialized
DEBUG - 2011-09-06 07:10:13 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-06 07:10:13 --> Language Class Initialized
DEBUG - 2011-09-06 07:10:13 --> Loader Class Initialized
DEBUG - 2011-09-06 07:10:13 --> Controller Class Initialized
DEBUG - 2011-09-06 07:10:13 --> Model Class Initialized
DEBUG - 2011-09-06 07:10:13 --> Model Class Initialized
DEBUG - 2011-09-06 07:10:13 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-06 07:10:13 --> Database Driver Class Initialized
DEBUG - 2011-09-06 07:10:14 --> Final output sent to browser
DEBUG - 2011-09-06 07:10:14 --> Total execution time: 0.7625
DEBUG - 2011-09-06 07:10:16 --> Config Class Initialized
DEBUG - 2011-09-06 07:10:16 --> Hooks Class Initialized
DEBUG - 2011-09-06 07:10:16 --> Utf8 Class Initialized
DEBUG - 2011-09-06 07:10:16 --> UTF-8 Support Enabled
DEBUG - 2011-09-06 07:10:16 --> URI Class Initialized
DEBUG - 2011-09-06 07:10:16 --> Router Class Initialized
ERROR - 2011-09-06 07:10:16 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-06 07:10:23 --> Config Class Initialized
DEBUG - 2011-09-06 07:10:23 --> Hooks Class Initialized
DEBUG - 2011-09-06 07:10:23 --> Utf8 Class Initialized
DEBUG - 2011-09-06 07:10:23 --> UTF-8 Support Enabled
DEBUG - 2011-09-06 07:10:23 --> URI Class Initialized
DEBUG - 2011-09-06 07:10:23 --> Router Class Initialized
DEBUG - 2011-09-06 07:10:23 --> Output Class Initialized
DEBUG - 2011-09-06 07:10:23 --> Input Class Initialized
DEBUG - 2011-09-06 07:10:23 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-06 07:10:23 --> Language Class Initialized
DEBUG - 2011-09-06 07:10:23 --> Loader Class Initialized
DEBUG - 2011-09-06 07:10:23 --> Controller Class Initialized
ERROR - 2011-09-06 07:10:23 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-06 07:10:23 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-06 07:10:23 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-06 07:10:23 --> Model Class Initialized
DEBUG - 2011-09-06 07:10:23 --> Model Class Initialized
DEBUG - 2011-09-06 07:10:23 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-06 07:10:23 --> Database Driver Class Initialized
DEBUG - 2011-09-06 07:10:23 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-06 07:10:23 --> Helper loaded: url_helper
DEBUG - 2011-09-06 07:10:23 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-06 07:10:23 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-06 07:10:23 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-06 07:10:23 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-06 07:10:23 --> Final output sent to browser
DEBUG - 2011-09-06 07:10:23 --> Total execution time: 0.0342
DEBUG - 2011-09-06 07:10:24 --> Config Class Initialized
DEBUG - 2011-09-06 07:10:24 --> Hooks Class Initialized
DEBUG - 2011-09-06 07:10:24 --> Utf8 Class Initialized
DEBUG - 2011-09-06 07:10:24 --> UTF-8 Support Enabled
DEBUG - 2011-09-06 07:10:24 --> URI Class Initialized
DEBUG - 2011-09-06 07:10:24 --> Router Class Initialized
DEBUG - 2011-09-06 07:10:24 --> Output Class Initialized
DEBUG - 2011-09-06 07:10:24 --> Input Class Initialized
DEBUG - 2011-09-06 07:10:24 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-06 07:10:24 --> Language Class Initialized
DEBUG - 2011-09-06 07:10:24 --> Loader Class Initialized
DEBUG - 2011-09-06 07:10:24 --> Controller Class Initialized
DEBUG - 2011-09-06 07:10:24 --> Model Class Initialized
DEBUG - 2011-09-06 07:10:24 --> Model Class Initialized
DEBUG - 2011-09-06 07:10:24 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-06 07:10:24 --> Database Driver Class Initialized
DEBUG - 2011-09-06 07:10:25 --> Final output sent to browser
DEBUG - 2011-09-06 07:10:25 --> Total execution time: 0.7338
DEBUG - 2011-09-06 07:10:27 --> Config Class Initialized
DEBUG - 2011-09-06 07:10:27 --> Hooks Class Initialized
DEBUG - 2011-09-06 07:10:27 --> Utf8 Class Initialized
DEBUG - 2011-09-06 07:10:27 --> UTF-8 Support Enabled
DEBUG - 2011-09-06 07:10:27 --> URI Class Initialized
DEBUG - 2011-09-06 07:10:27 --> Router Class Initialized
ERROR - 2011-09-06 07:10:27 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-06 07:10:40 --> Config Class Initialized
DEBUG - 2011-09-06 07:10:40 --> Hooks Class Initialized
DEBUG - 2011-09-06 07:10:40 --> Utf8 Class Initialized
DEBUG - 2011-09-06 07:10:40 --> UTF-8 Support Enabled
DEBUG - 2011-09-06 07:10:40 --> URI Class Initialized
DEBUG - 2011-09-06 07:10:40 --> Router Class Initialized
DEBUG - 2011-09-06 07:10:40 --> Output Class Initialized
DEBUG - 2011-09-06 07:10:40 --> Input Class Initialized
DEBUG - 2011-09-06 07:10:40 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-06 07:10:40 --> Language Class Initialized
DEBUG - 2011-09-06 07:10:40 --> Loader Class Initialized
DEBUG - 2011-09-06 07:10:40 --> Controller Class Initialized
ERROR - 2011-09-06 07:10:40 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-06 07:10:40 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-06 07:10:40 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-06 07:10:40 --> Model Class Initialized
DEBUG - 2011-09-06 07:10:40 --> Model Class Initialized
DEBUG - 2011-09-06 07:10:40 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-06 07:10:40 --> Database Driver Class Initialized
DEBUG - 2011-09-06 07:10:40 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-06 07:10:40 --> Helper loaded: url_helper
DEBUG - 2011-09-06 07:10:40 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-06 07:10:40 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-06 07:10:40 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-06 07:10:40 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-06 07:10:40 --> Final output sent to browser
DEBUG - 2011-09-06 07:10:40 --> Total execution time: 0.0410
DEBUG - 2011-09-06 07:10:42 --> Config Class Initialized
DEBUG - 2011-09-06 07:10:42 --> Hooks Class Initialized
DEBUG - 2011-09-06 07:10:42 --> Utf8 Class Initialized
DEBUG - 2011-09-06 07:10:42 --> UTF-8 Support Enabled
DEBUG - 2011-09-06 07:10:42 --> URI Class Initialized
DEBUG - 2011-09-06 07:10:42 --> Router Class Initialized
DEBUG - 2011-09-06 07:10:42 --> Output Class Initialized
DEBUG - 2011-09-06 07:10:42 --> Input Class Initialized
DEBUG - 2011-09-06 07:10:42 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-06 07:10:42 --> Language Class Initialized
DEBUG - 2011-09-06 07:10:42 --> Loader Class Initialized
DEBUG - 2011-09-06 07:10:42 --> Controller Class Initialized
DEBUG - 2011-09-06 07:10:42 --> Model Class Initialized
DEBUG - 2011-09-06 07:10:42 --> Model Class Initialized
DEBUG - 2011-09-06 07:10:42 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-06 07:10:42 --> Database Driver Class Initialized
DEBUG - 2011-09-06 07:10:42 --> Final output sent to browser
DEBUG - 2011-09-06 07:10:42 --> Total execution time: 0.5543
DEBUG - 2011-09-06 07:10:44 --> Config Class Initialized
DEBUG - 2011-09-06 07:10:44 --> Hooks Class Initialized
DEBUG - 2011-09-06 07:10:44 --> Utf8 Class Initialized
DEBUG - 2011-09-06 07:10:44 --> UTF-8 Support Enabled
DEBUG - 2011-09-06 07:10:44 --> URI Class Initialized
DEBUG - 2011-09-06 07:10:44 --> Router Class Initialized
ERROR - 2011-09-06 07:10:44 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-06 07:10:48 --> Config Class Initialized
DEBUG - 2011-09-06 07:10:48 --> Hooks Class Initialized
DEBUG - 2011-09-06 07:10:48 --> Utf8 Class Initialized
DEBUG - 2011-09-06 07:10:48 --> UTF-8 Support Enabled
DEBUG - 2011-09-06 07:10:48 --> URI Class Initialized
DEBUG - 2011-09-06 07:10:48 --> Router Class Initialized
DEBUG - 2011-09-06 07:10:48 --> Output Class Initialized
DEBUG - 2011-09-06 07:10:48 --> Input Class Initialized
DEBUG - 2011-09-06 07:10:48 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-06 07:10:48 --> Language Class Initialized
DEBUG - 2011-09-06 07:10:48 --> Loader Class Initialized
DEBUG - 2011-09-06 07:10:48 --> Controller Class Initialized
ERROR - 2011-09-06 07:10:48 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-06 07:10:48 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-06 07:10:48 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-06 07:10:48 --> Model Class Initialized
DEBUG - 2011-09-06 07:10:48 --> Model Class Initialized
DEBUG - 2011-09-06 07:10:48 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-06 07:10:48 --> Database Driver Class Initialized
DEBUG - 2011-09-06 07:10:48 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-06 07:10:48 --> Helper loaded: url_helper
DEBUG - 2011-09-06 07:10:48 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-06 07:10:48 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-06 07:10:48 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-06 07:10:48 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-06 07:10:48 --> Final output sent to browser
DEBUG - 2011-09-06 07:10:48 --> Total execution time: 0.0288
DEBUG - 2011-09-06 07:10:49 --> Config Class Initialized
DEBUG - 2011-09-06 07:10:49 --> Hooks Class Initialized
DEBUG - 2011-09-06 07:10:49 --> Utf8 Class Initialized
DEBUG - 2011-09-06 07:10:49 --> UTF-8 Support Enabled
DEBUG - 2011-09-06 07:10:49 --> URI Class Initialized
DEBUG - 2011-09-06 07:10:49 --> Router Class Initialized
DEBUG - 2011-09-06 07:10:49 --> Output Class Initialized
DEBUG - 2011-09-06 07:10:49 --> Input Class Initialized
DEBUG - 2011-09-06 07:10:49 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-06 07:10:49 --> Language Class Initialized
DEBUG - 2011-09-06 07:10:49 --> Loader Class Initialized
DEBUG - 2011-09-06 07:10:49 --> Controller Class Initialized
DEBUG - 2011-09-06 07:10:49 --> Model Class Initialized
DEBUG - 2011-09-06 07:10:49 --> Model Class Initialized
DEBUG - 2011-09-06 07:10:49 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-06 07:10:49 --> Database Driver Class Initialized
DEBUG - 2011-09-06 07:10:50 --> Final output sent to browser
DEBUG - 2011-09-06 07:10:50 --> Total execution time: 0.6593
DEBUG - 2011-09-06 07:10:51 --> Config Class Initialized
DEBUG - 2011-09-06 07:10:51 --> Hooks Class Initialized
DEBUG - 2011-09-06 07:10:51 --> Utf8 Class Initialized
DEBUG - 2011-09-06 07:10:51 --> UTF-8 Support Enabled
DEBUG - 2011-09-06 07:10:51 --> URI Class Initialized
DEBUG - 2011-09-06 07:10:51 --> Router Class Initialized
ERROR - 2011-09-06 07:10:51 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-06 07:10:56 --> Config Class Initialized
DEBUG - 2011-09-06 07:10:56 --> Hooks Class Initialized
DEBUG - 2011-09-06 07:10:56 --> Utf8 Class Initialized
DEBUG - 2011-09-06 07:10:56 --> UTF-8 Support Enabled
DEBUG - 2011-09-06 07:10:56 --> URI Class Initialized
DEBUG - 2011-09-06 07:10:56 --> Router Class Initialized
DEBUG - 2011-09-06 07:10:56 --> Output Class Initialized
DEBUG - 2011-09-06 07:10:56 --> Input Class Initialized
DEBUG - 2011-09-06 07:10:56 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-06 07:10:56 --> Language Class Initialized
DEBUG - 2011-09-06 07:10:56 --> Loader Class Initialized
DEBUG - 2011-09-06 07:10:56 --> Controller Class Initialized
ERROR - 2011-09-06 07:10:56 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-06 07:10:56 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-06 07:10:56 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-06 07:10:56 --> Model Class Initialized
DEBUG - 2011-09-06 07:10:56 --> Model Class Initialized
DEBUG - 2011-09-06 07:10:56 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-06 07:10:56 --> Database Driver Class Initialized
DEBUG - 2011-09-06 07:10:56 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-06 07:10:56 --> Helper loaded: url_helper
DEBUG - 2011-09-06 07:10:56 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-06 07:10:56 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-06 07:10:56 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-06 07:10:56 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-06 07:10:56 --> Final output sent to browser
DEBUG - 2011-09-06 07:10:56 --> Total execution time: 0.0303
DEBUG - 2011-09-06 07:10:56 --> Config Class Initialized
DEBUG - 2011-09-06 07:10:56 --> Hooks Class Initialized
DEBUG - 2011-09-06 07:10:56 --> Utf8 Class Initialized
DEBUG - 2011-09-06 07:10:56 --> UTF-8 Support Enabled
DEBUG - 2011-09-06 07:10:56 --> URI Class Initialized
DEBUG - 2011-09-06 07:10:56 --> Router Class Initialized
DEBUG - 2011-09-06 07:10:56 --> Output Class Initialized
DEBUG - 2011-09-06 07:10:56 --> Input Class Initialized
DEBUG - 2011-09-06 07:10:56 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-06 07:10:56 --> Language Class Initialized
DEBUG - 2011-09-06 07:10:56 --> Loader Class Initialized
DEBUG - 2011-09-06 07:10:56 --> Controller Class Initialized
DEBUG - 2011-09-06 07:10:56 --> Model Class Initialized
DEBUG - 2011-09-06 07:10:56 --> Model Class Initialized
DEBUG - 2011-09-06 07:10:56 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-06 07:10:56 --> Database Driver Class Initialized
DEBUG - 2011-09-06 07:10:57 --> Final output sent to browser
DEBUG - 2011-09-06 07:10:57 --> Total execution time: 0.5651
DEBUG - 2011-09-06 07:10:59 --> Config Class Initialized
DEBUG - 2011-09-06 07:10:59 --> Hooks Class Initialized
DEBUG - 2011-09-06 07:10:59 --> Utf8 Class Initialized
DEBUG - 2011-09-06 07:10:59 --> UTF-8 Support Enabled
DEBUG - 2011-09-06 07:10:59 --> URI Class Initialized
DEBUG - 2011-09-06 07:10:59 --> Router Class Initialized
ERROR - 2011-09-06 07:10:59 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-06 07:12:00 --> Config Class Initialized
DEBUG - 2011-09-06 07:12:00 --> Hooks Class Initialized
DEBUG - 2011-09-06 07:12:00 --> Utf8 Class Initialized
DEBUG - 2011-09-06 07:12:00 --> UTF-8 Support Enabled
DEBUG - 2011-09-06 07:12:00 --> URI Class Initialized
DEBUG - 2011-09-06 07:12:00 --> Router Class Initialized
DEBUG - 2011-09-06 07:12:00 --> Output Class Initialized
DEBUG - 2011-09-06 07:12:00 --> Input Class Initialized
DEBUG - 2011-09-06 07:12:00 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-06 07:12:00 --> Language Class Initialized
DEBUG - 2011-09-06 07:12:00 --> Loader Class Initialized
DEBUG - 2011-09-06 07:12:00 --> Controller Class Initialized
ERROR - 2011-09-06 07:12:00 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-06 07:12:00 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-06 07:12:00 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-06 07:12:00 --> Model Class Initialized
DEBUG - 2011-09-06 07:12:00 --> Model Class Initialized
DEBUG - 2011-09-06 07:12:00 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-06 07:12:00 --> Database Driver Class Initialized
DEBUG - 2011-09-06 07:12:00 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-06 07:12:00 --> Helper loaded: url_helper
DEBUG - 2011-09-06 07:12:00 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-06 07:12:00 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-06 07:12:00 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-06 07:12:00 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-06 07:12:00 --> Final output sent to browser
DEBUG - 2011-09-06 07:12:00 --> Total execution time: 0.0279
DEBUG - 2011-09-06 07:12:02 --> Config Class Initialized
DEBUG - 2011-09-06 07:12:02 --> Hooks Class Initialized
DEBUG - 2011-09-06 07:12:02 --> Utf8 Class Initialized
DEBUG - 2011-09-06 07:12:02 --> UTF-8 Support Enabled
DEBUG - 2011-09-06 07:12:02 --> URI Class Initialized
DEBUG - 2011-09-06 07:12:02 --> Router Class Initialized
DEBUG - 2011-09-06 07:12:02 --> Output Class Initialized
DEBUG - 2011-09-06 07:12:02 --> Input Class Initialized
DEBUG - 2011-09-06 07:12:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-06 07:12:02 --> Language Class Initialized
DEBUG - 2011-09-06 07:12:02 --> Loader Class Initialized
DEBUG - 2011-09-06 07:12:02 --> Controller Class Initialized
DEBUG - 2011-09-06 07:12:02 --> Model Class Initialized
DEBUG - 2011-09-06 07:12:02 --> Model Class Initialized
DEBUG - 2011-09-06 07:12:02 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-06 07:12:02 --> Database Driver Class Initialized
DEBUG - 2011-09-06 07:12:02 --> Final output sent to browser
DEBUG - 2011-09-06 07:12:02 --> Total execution time: 0.6335
DEBUG - 2011-09-06 07:58:41 --> Config Class Initialized
DEBUG - 2011-09-06 07:58:42 --> Hooks Class Initialized
DEBUG - 2011-09-06 07:58:42 --> Utf8 Class Initialized
DEBUG - 2011-09-06 07:58:42 --> UTF-8 Support Enabled
DEBUG - 2011-09-06 07:58:42 --> URI Class Initialized
DEBUG - 2011-09-06 07:58:42 --> Router Class Initialized
DEBUG - 2011-09-06 07:58:42 --> Output Class Initialized
DEBUG - 2011-09-06 07:58:42 --> Input Class Initialized
DEBUG - 2011-09-06 07:58:42 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-06 07:58:42 --> Language Class Initialized
DEBUG - 2011-09-06 07:58:42 --> Loader Class Initialized
DEBUG - 2011-09-06 07:58:42 --> Controller Class Initialized
ERROR - 2011-09-06 07:58:42 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-06 07:58:42 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-06 07:58:42 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-06 07:58:42 --> Model Class Initialized
DEBUG - 2011-09-06 07:58:42 --> Model Class Initialized
DEBUG - 2011-09-06 07:58:42 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-06 07:58:42 --> Database Driver Class Initialized
DEBUG - 2011-09-06 07:58:42 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-06 07:58:42 --> Helper loaded: url_helper
DEBUG - 2011-09-06 07:58:42 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-06 07:58:42 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-06 07:58:42 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-06 07:58:42 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-06 07:58:42 --> Final output sent to browser
DEBUG - 2011-09-06 07:58:42 --> Total execution time: 0.6847
DEBUG - 2011-09-06 07:58:53 --> Config Class Initialized
DEBUG - 2011-09-06 07:58:53 --> Hooks Class Initialized
DEBUG - 2011-09-06 07:58:53 --> Utf8 Class Initialized
DEBUG - 2011-09-06 07:58:53 --> UTF-8 Support Enabled
DEBUG - 2011-09-06 07:58:53 --> URI Class Initialized
DEBUG - 2011-09-06 07:58:53 --> Router Class Initialized
DEBUG - 2011-09-06 07:58:53 --> Output Class Initialized
DEBUG - 2011-09-06 07:58:53 --> Input Class Initialized
DEBUG - 2011-09-06 07:58:53 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-06 07:58:53 --> Language Class Initialized
DEBUG - 2011-09-06 07:58:53 --> Loader Class Initialized
DEBUG - 2011-09-06 07:58:53 --> Controller Class Initialized
DEBUG - 2011-09-06 07:58:53 --> Model Class Initialized
DEBUG - 2011-09-06 07:58:53 --> Model Class Initialized
DEBUG - 2011-09-06 07:58:53 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-06 07:58:53 --> Database Driver Class Initialized
DEBUG - 2011-09-06 07:58:53 --> Final output sent to browser
DEBUG - 2011-09-06 07:58:53 --> Total execution time: 0.7655
DEBUG - 2011-09-06 07:58:59 --> Config Class Initialized
DEBUG - 2011-09-06 07:58:59 --> Hooks Class Initialized
DEBUG - 2011-09-06 07:58:59 --> Config Class Initialized
DEBUG - 2011-09-06 07:58:59 --> Hooks Class Initialized
DEBUG - 2011-09-06 07:58:59 --> Utf8 Class Initialized
DEBUG - 2011-09-06 07:58:59 --> UTF-8 Support Enabled
DEBUG - 2011-09-06 07:58:59 --> Utf8 Class Initialized
DEBUG - 2011-09-06 07:58:59 --> UTF-8 Support Enabled
DEBUG - 2011-09-06 07:58:59 --> URI Class Initialized
DEBUG - 2011-09-06 07:58:59 --> Router Class Initialized
DEBUG - 2011-09-06 07:58:59 --> URI Class Initialized
ERROR - 2011-09-06 07:58:59 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-06 07:58:59 --> Router Class Initialized
DEBUG - 2011-09-06 07:58:59 --> Output Class Initialized
DEBUG - 2011-09-06 07:58:59 --> Input Class Initialized
DEBUG - 2011-09-06 07:58:59 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-06 07:58:59 --> Language Class Initialized
DEBUG - 2011-09-06 07:58:59 --> Loader Class Initialized
DEBUG - 2011-09-06 07:58:59 --> Controller Class Initialized
ERROR - 2011-09-06 07:58:59 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-06 07:58:59 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-06 07:58:59 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-06 07:58:59 --> Model Class Initialized
DEBUG - 2011-09-06 07:58:59 --> Model Class Initialized
DEBUG - 2011-09-06 07:58:59 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-06 07:58:59 --> Database Driver Class Initialized
DEBUG - 2011-09-06 07:58:59 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-06 07:58:59 --> Helper loaded: url_helper
DEBUG - 2011-09-06 07:58:59 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-06 07:58:59 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-06 07:58:59 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-06 07:58:59 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-06 07:58:59 --> Final output sent to browser
DEBUG - 2011-09-06 07:58:59 --> Total execution time: 0.0349
DEBUG - 2011-09-06 07:59:02 --> Config Class Initialized
DEBUG - 2011-09-06 07:59:02 --> Hooks Class Initialized
DEBUG - 2011-09-06 07:59:02 --> Utf8 Class Initialized
DEBUG - 2011-09-06 07:59:02 --> UTF-8 Support Enabled
DEBUG - 2011-09-06 07:59:02 --> URI Class Initialized
DEBUG - 2011-09-06 07:59:02 --> Router Class Initialized
DEBUG - 2011-09-06 07:59:02 --> Output Class Initialized
DEBUG - 2011-09-06 07:59:02 --> Input Class Initialized
DEBUG - 2011-09-06 07:59:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-06 07:59:02 --> Language Class Initialized
DEBUG - 2011-09-06 07:59:02 --> Loader Class Initialized
DEBUG - 2011-09-06 07:59:02 --> Controller Class Initialized
DEBUG - 2011-09-06 07:59:02 --> Model Class Initialized
DEBUG - 2011-09-06 07:59:02 --> Model Class Initialized
DEBUG - 2011-09-06 07:59:02 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-06 07:59:02 --> Database Driver Class Initialized
DEBUG - 2011-09-06 07:59:03 --> Final output sent to browser
DEBUG - 2011-09-06 07:59:03 --> Total execution time: 0.5960
DEBUG - 2011-09-06 07:59:57 --> Config Class Initialized
DEBUG - 2011-09-06 07:59:57 --> Hooks Class Initialized
DEBUG - 2011-09-06 07:59:57 --> Utf8 Class Initialized
DEBUG - 2011-09-06 07:59:57 --> UTF-8 Support Enabled
DEBUG - 2011-09-06 07:59:57 --> URI Class Initialized
DEBUG - 2011-09-06 07:59:57 --> Router Class Initialized
ERROR - 2011-09-06 07:59:57 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-06 08:01:02 --> Config Class Initialized
DEBUG - 2011-09-06 08:01:02 --> Hooks Class Initialized
DEBUG - 2011-09-06 08:01:02 --> Utf8 Class Initialized
DEBUG - 2011-09-06 08:01:02 --> UTF-8 Support Enabled
DEBUG - 2011-09-06 08:01:02 --> URI Class Initialized
DEBUG - 2011-09-06 08:01:02 --> Router Class Initialized
DEBUG - 2011-09-06 08:01:02 --> Output Class Initialized
DEBUG - 2011-09-06 08:01:02 --> Input Class Initialized
DEBUG - 2011-09-06 08:01:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-06 08:01:02 --> Language Class Initialized
DEBUG - 2011-09-06 08:01:02 --> Loader Class Initialized
DEBUG - 2011-09-06 08:01:02 --> Controller Class Initialized
ERROR - 2011-09-06 08:01:02 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-06 08:01:02 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-06 08:01:02 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-06 08:01:02 --> Model Class Initialized
DEBUG - 2011-09-06 08:01:02 --> Model Class Initialized
DEBUG - 2011-09-06 08:01:02 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-06 08:01:02 --> Database Driver Class Initialized
DEBUG - 2011-09-06 08:01:02 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-06 08:01:02 --> Helper loaded: url_helper
DEBUG - 2011-09-06 08:01:03 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-06 08:01:03 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-06 08:01:03 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-06 08:01:03 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-06 08:01:03 --> Final output sent to browser
DEBUG - 2011-09-06 08:01:03 --> Total execution time: 0.0831
DEBUG - 2011-09-06 08:01:05 --> Config Class Initialized
DEBUG - 2011-09-06 08:01:05 --> Hooks Class Initialized
DEBUG - 2011-09-06 08:01:05 --> Utf8 Class Initialized
DEBUG - 2011-09-06 08:01:05 --> UTF-8 Support Enabled
DEBUG - 2011-09-06 08:01:05 --> URI Class Initialized
DEBUG - 2011-09-06 08:01:05 --> Router Class Initialized
DEBUG - 2011-09-06 08:01:05 --> Output Class Initialized
DEBUG - 2011-09-06 08:01:05 --> Input Class Initialized
DEBUG - 2011-09-06 08:01:05 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-06 08:01:05 --> Language Class Initialized
DEBUG - 2011-09-06 08:01:05 --> Loader Class Initialized
DEBUG - 2011-09-06 08:01:05 --> Controller Class Initialized
DEBUG - 2011-09-06 08:01:05 --> Model Class Initialized
DEBUG - 2011-09-06 08:01:05 --> Model Class Initialized
DEBUG - 2011-09-06 08:01:05 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-06 08:01:05 --> Database Driver Class Initialized
DEBUG - 2011-09-06 08:01:06 --> Config Class Initialized
DEBUG - 2011-09-06 08:01:06 --> Hooks Class Initialized
DEBUG - 2011-09-06 08:01:06 --> Utf8 Class Initialized
DEBUG - 2011-09-06 08:01:06 --> UTF-8 Support Enabled
DEBUG - 2011-09-06 08:01:06 --> URI Class Initialized
DEBUG - 2011-09-06 08:01:06 --> Router Class Initialized
DEBUG - 2011-09-06 08:01:06 --> Output Class Initialized
DEBUG - 2011-09-06 08:01:06 --> Input Class Initialized
DEBUG - 2011-09-06 08:01:06 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-06 08:01:06 --> Language Class Initialized
DEBUG - 2011-09-06 08:01:06 --> Loader Class Initialized
DEBUG - 2011-09-06 08:01:06 --> Controller Class Initialized
ERROR - 2011-09-06 08:01:06 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-06 08:01:06 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-06 08:01:06 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-06 08:01:06 --> Model Class Initialized
DEBUG - 2011-09-06 08:01:06 --> Model Class Initialized
DEBUG - 2011-09-06 08:01:06 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-06 08:01:06 --> Database Driver Class Initialized
DEBUG - 2011-09-06 08:01:06 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-06 08:01:06 --> Helper loaded: url_helper
DEBUG - 2011-09-06 08:01:06 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-06 08:01:06 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-06 08:01:06 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-06 08:01:06 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-06 08:01:06 --> Final output sent to browser
DEBUG - 2011-09-06 08:01:06 --> Total execution time: 0.0282
DEBUG - 2011-09-06 08:01:07 --> Final output sent to browser
DEBUG - 2011-09-06 08:01:07 --> Total execution time: 1.1109
DEBUG - 2011-09-06 08:01:33 --> Config Class Initialized
DEBUG - 2011-09-06 08:01:33 --> Hooks Class Initialized
DEBUG - 2011-09-06 08:01:33 --> Utf8 Class Initialized
DEBUG - 2011-09-06 08:01:33 --> UTF-8 Support Enabled
DEBUG - 2011-09-06 08:01:33 --> URI Class Initialized
DEBUG - 2011-09-06 08:01:33 --> Router Class Initialized
ERROR - 2011-09-06 08:01:33 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-06 08:02:16 --> Config Class Initialized
DEBUG - 2011-09-06 08:02:16 --> Hooks Class Initialized
DEBUG - 2011-09-06 08:02:16 --> Utf8 Class Initialized
DEBUG - 2011-09-06 08:02:16 --> UTF-8 Support Enabled
DEBUG - 2011-09-06 08:02:16 --> URI Class Initialized
DEBUG - 2011-09-06 08:02:16 --> Router Class Initialized
DEBUG - 2011-09-06 08:02:16 --> Output Class Initialized
DEBUG - 2011-09-06 08:02:16 --> Input Class Initialized
DEBUG - 2011-09-06 08:02:16 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-06 08:02:16 --> Language Class Initialized
DEBUG - 2011-09-06 08:02:16 --> Loader Class Initialized
DEBUG - 2011-09-06 08:02:16 --> Controller Class Initialized
ERROR - 2011-09-06 08:02:16 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-06 08:02:16 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-06 08:02:16 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-06 08:02:16 --> Model Class Initialized
DEBUG - 2011-09-06 08:02:16 --> Model Class Initialized
DEBUG - 2011-09-06 08:02:16 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-06 08:02:16 --> Database Driver Class Initialized
DEBUG - 2011-09-06 08:02:16 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-06 08:02:16 --> Helper loaded: url_helper
DEBUG - 2011-09-06 08:02:16 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-06 08:02:16 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-06 08:02:16 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-06 08:02:16 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-06 08:02:16 --> Final output sent to browser
DEBUG - 2011-09-06 08:02:16 --> Total execution time: 0.0440
DEBUG - 2011-09-06 08:02:18 --> Config Class Initialized
DEBUG - 2011-09-06 08:02:18 --> Hooks Class Initialized
DEBUG - 2011-09-06 08:02:18 --> Utf8 Class Initialized
DEBUG - 2011-09-06 08:02:18 --> UTF-8 Support Enabled
DEBUG - 2011-09-06 08:02:18 --> URI Class Initialized
DEBUG - 2011-09-06 08:02:18 --> Router Class Initialized
DEBUG - 2011-09-06 08:02:18 --> Output Class Initialized
DEBUG - 2011-09-06 08:02:18 --> Input Class Initialized
DEBUG - 2011-09-06 08:02:18 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-06 08:02:18 --> Language Class Initialized
DEBUG - 2011-09-06 08:02:18 --> Loader Class Initialized
DEBUG - 2011-09-06 08:02:18 --> Controller Class Initialized
DEBUG - 2011-09-06 08:02:18 --> Model Class Initialized
DEBUG - 2011-09-06 08:02:18 --> Model Class Initialized
DEBUG - 2011-09-06 08:02:18 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-06 08:02:18 --> Database Driver Class Initialized
DEBUG - 2011-09-06 08:02:18 --> Final output sent to browser
DEBUG - 2011-09-06 08:02:18 --> Total execution time: 0.6085
DEBUG - 2011-09-06 08:02:19 --> Config Class Initialized
DEBUG - 2011-09-06 08:02:19 --> Hooks Class Initialized
DEBUG - 2011-09-06 08:02:19 --> Utf8 Class Initialized
DEBUG - 2011-09-06 08:02:19 --> UTF-8 Support Enabled
DEBUG - 2011-09-06 08:02:19 --> URI Class Initialized
DEBUG - 2011-09-06 08:02:19 --> Router Class Initialized
DEBUG - 2011-09-06 08:02:19 --> Output Class Initialized
DEBUG - 2011-09-06 08:02:19 --> Input Class Initialized
DEBUG - 2011-09-06 08:02:19 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-06 08:02:19 --> Language Class Initialized
DEBUG - 2011-09-06 08:02:19 --> Loader Class Initialized
DEBUG - 2011-09-06 08:02:19 --> Controller Class Initialized
ERROR - 2011-09-06 08:02:19 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-06 08:02:19 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-06 08:02:19 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-06 08:02:19 --> Model Class Initialized
DEBUG - 2011-09-06 08:02:19 --> Model Class Initialized
DEBUG - 2011-09-06 08:02:19 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-06 08:02:19 --> Database Driver Class Initialized
DEBUG - 2011-09-06 08:02:19 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-06 08:02:19 --> Helper loaded: url_helper
DEBUG - 2011-09-06 08:02:19 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-06 08:02:19 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-06 08:02:19 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-06 08:02:19 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-06 08:02:19 --> Final output sent to browser
DEBUG - 2011-09-06 08:02:19 --> Total execution time: 0.1222
DEBUG - 2011-09-06 08:02:38 --> Config Class Initialized
DEBUG - 2011-09-06 08:02:38 --> Hooks Class Initialized
DEBUG - 2011-09-06 08:02:38 --> Utf8 Class Initialized
DEBUG - 2011-09-06 08:02:38 --> UTF-8 Support Enabled
DEBUG - 2011-09-06 08:02:38 --> URI Class Initialized
DEBUG - 2011-09-06 08:02:38 --> Router Class Initialized
ERROR - 2011-09-06 08:02:38 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-06 08:03:33 --> Config Class Initialized
DEBUG - 2011-09-06 08:03:33 --> Hooks Class Initialized
DEBUG - 2011-09-06 08:03:33 --> Utf8 Class Initialized
DEBUG - 2011-09-06 08:03:33 --> UTF-8 Support Enabled
DEBUG - 2011-09-06 08:03:33 --> URI Class Initialized
DEBUG - 2011-09-06 08:03:33 --> Router Class Initialized
DEBUG - 2011-09-06 08:03:33 --> Output Class Initialized
DEBUG - 2011-09-06 08:03:33 --> Input Class Initialized
DEBUG - 2011-09-06 08:03:33 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-06 08:03:33 --> Language Class Initialized
DEBUG - 2011-09-06 08:03:33 --> Loader Class Initialized
DEBUG - 2011-09-06 08:03:33 --> Controller Class Initialized
ERROR - 2011-09-06 08:03:33 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-06 08:03:33 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-06 08:03:33 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-06 08:03:33 --> Model Class Initialized
DEBUG - 2011-09-06 08:03:33 --> Model Class Initialized
DEBUG - 2011-09-06 08:03:33 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-06 08:03:33 --> Database Driver Class Initialized
DEBUG - 2011-09-06 08:03:33 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-06 08:03:33 --> Helper loaded: url_helper
DEBUG - 2011-09-06 08:03:33 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-06 08:03:33 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-06 08:03:33 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-06 08:03:33 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-06 08:03:33 --> Final output sent to browser
DEBUG - 2011-09-06 08:03:33 --> Total execution time: 0.0475
DEBUG - 2011-09-06 08:03:37 --> Config Class Initialized
DEBUG - 2011-09-06 08:03:37 --> Hooks Class Initialized
DEBUG - 2011-09-06 08:03:37 --> Utf8 Class Initialized
DEBUG - 2011-09-06 08:03:37 --> UTF-8 Support Enabled
DEBUG - 2011-09-06 08:03:37 --> URI Class Initialized
DEBUG - 2011-09-06 08:03:37 --> Router Class Initialized
DEBUG - 2011-09-06 08:03:37 --> Output Class Initialized
DEBUG - 2011-09-06 08:03:37 --> Input Class Initialized
DEBUG - 2011-09-06 08:03:37 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-06 08:03:37 --> Language Class Initialized
DEBUG - 2011-09-06 08:03:37 --> Loader Class Initialized
DEBUG - 2011-09-06 08:03:37 --> Controller Class Initialized
DEBUG - 2011-09-06 08:03:37 --> Model Class Initialized
DEBUG - 2011-09-06 08:03:37 --> Model Class Initialized
DEBUG - 2011-09-06 08:03:37 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-06 08:03:37 --> Database Driver Class Initialized
DEBUG - 2011-09-06 08:03:38 --> Final output sent to browser
DEBUG - 2011-09-06 08:03:38 --> Total execution time: 0.5875
DEBUG - 2011-09-06 08:04:28 --> Config Class Initialized
DEBUG - 2011-09-06 08:04:28 --> Hooks Class Initialized
DEBUG - 2011-09-06 08:04:28 --> Utf8 Class Initialized
DEBUG - 2011-09-06 08:04:28 --> UTF-8 Support Enabled
DEBUG - 2011-09-06 08:04:28 --> URI Class Initialized
DEBUG - 2011-09-06 08:04:28 --> Router Class Initialized
ERROR - 2011-09-06 08:04:28 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-06 08:12:57 --> Config Class Initialized
DEBUG - 2011-09-06 08:12:57 --> Hooks Class Initialized
DEBUG - 2011-09-06 08:12:57 --> Utf8 Class Initialized
DEBUG - 2011-09-06 08:12:57 --> UTF-8 Support Enabled
DEBUG - 2011-09-06 08:12:57 --> URI Class Initialized
DEBUG - 2011-09-06 08:12:57 --> Router Class Initialized
DEBUG - 2011-09-06 08:12:57 --> Output Class Initialized
DEBUG - 2011-09-06 08:12:57 --> Input Class Initialized
DEBUG - 2011-09-06 08:12:57 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-06 08:12:57 --> Language Class Initialized
DEBUG - 2011-09-06 08:12:57 --> Loader Class Initialized
DEBUG - 2011-09-06 08:12:57 --> Controller Class Initialized
DEBUG - 2011-09-06 08:12:57 --> Model Class Initialized
DEBUG - 2011-09-06 08:12:57 --> Model Class Initialized
DEBUG - 2011-09-06 08:12:57 --> Model Class Initialized
DEBUG - 2011-09-06 08:12:57 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-06 08:12:57 --> Database Driver Class Initialized
DEBUG - 2011-09-06 08:12:58 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-06 08:12:58 --> Helper loaded: url_helper
DEBUG - 2011-09-06 08:12:58 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-06 08:12:58 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-06 08:12:58 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-06 08:12:58 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-06 08:12:58 --> Final output sent to browser
DEBUG - 2011-09-06 08:12:58 --> Total execution time: 0.2949
DEBUG - 2011-09-06 08:12:59 --> Config Class Initialized
DEBUG - 2011-09-06 08:12:59 --> Hooks Class Initialized
DEBUG - 2011-09-06 08:12:59 --> Utf8 Class Initialized
DEBUG - 2011-09-06 08:12:59 --> UTF-8 Support Enabled
DEBUG - 2011-09-06 08:12:59 --> URI Class Initialized
DEBUG - 2011-09-06 08:12:59 --> Router Class Initialized
ERROR - 2011-09-06 08:12:59 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-06 08:13:12 --> Config Class Initialized
DEBUG - 2011-09-06 08:13:12 --> Hooks Class Initialized
DEBUG - 2011-09-06 08:13:12 --> Utf8 Class Initialized
DEBUG - 2011-09-06 08:13:12 --> UTF-8 Support Enabled
DEBUG - 2011-09-06 08:13:12 --> URI Class Initialized
DEBUG - 2011-09-06 08:13:12 --> Router Class Initialized
DEBUG - 2011-09-06 08:13:12 --> Output Class Initialized
DEBUG - 2011-09-06 08:13:12 --> Input Class Initialized
DEBUG - 2011-09-06 08:13:12 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-06 08:13:12 --> Language Class Initialized
DEBUG - 2011-09-06 08:13:12 --> Loader Class Initialized
DEBUG - 2011-09-06 08:13:12 --> Controller Class Initialized
DEBUG - 2011-09-06 08:13:12 --> Model Class Initialized
DEBUG - 2011-09-06 08:13:12 --> Model Class Initialized
DEBUG - 2011-09-06 08:13:12 --> Model Class Initialized
DEBUG - 2011-09-06 08:13:12 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-06 08:13:12 --> Database Driver Class Initialized
DEBUG - 2011-09-06 08:13:12 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-06 08:13:12 --> Helper loaded: url_helper
DEBUG - 2011-09-06 08:13:12 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-06 08:13:12 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-06 08:13:12 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-06 08:13:12 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-06 08:13:12 --> Final output sent to browser
DEBUG - 2011-09-06 08:13:12 --> Total execution time: 0.7827
DEBUG - 2011-09-06 08:13:14 --> Config Class Initialized
DEBUG - 2011-09-06 08:13:14 --> Hooks Class Initialized
DEBUG - 2011-09-06 08:13:14 --> Utf8 Class Initialized
DEBUG - 2011-09-06 08:13:14 --> UTF-8 Support Enabled
DEBUG - 2011-09-06 08:13:14 --> URI Class Initialized
DEBUG - 2011-09-06 08:13:14 --> Router Class Initialized
ERROR - 2011-09-06 08:13:14 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-06 08:13:14 --> Config Class Initialized
DEBUG - 2011-09-06 08:13:14 --> Hooks Class Initialized
DEBUG - 2011-09-06 08:13:14 --> Utf8 Class Initialized
DEBUG - 2011-09-06 08:13:14 --> UTF-8 Support Enabled
DEBUG - 2011-09-06 08:13:14 --> URI Class Initialized
DEBUG - 2011-09-06 08:13:14 --> Router Class Initialized
DEBUG - 2011-09-06 08:13:14 --> Output Class Initialized
DEBUG - 2011-09-06 08:13:14 --> Input Class Initialized
DEBUG - 2011-09-06 08:13:14 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-06 08:13:14 --> Language Class Initialized
DEBUG - 2011-09-06 08:13:14 --> Loader Class Initialized
DEBUG - 2011-09-06 08:13:14 --> Controller Class Initialized
DEBUG - 2011-09-06 08:13:14 --> Model Class Initialized
DEBUG - 2011-09-06 08:13:14 --> Model Class Initialized
DEBUG - 2011-09-06 08:13:14 --> Model Class Initialized
DEBUG - 2011-09-06 08:13:14 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-06 08:13:14 --> Database Driver Class Initialized
DEBUG - 2011-09-06 08:13:14 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-06 08:13:14 --> Helper loaded: url_helper
DEBUG - 2011-09-06 08:13:14 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-06 08:13:14 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-06 08:13:14 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-06 08:13:14 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-06 08:13:14 --> Final output sent to browser
DEBUG - 2011-09-06 08:13:14 --> Total execution time: 0.0425
DEBUG - 2011-09-06 08:13:27 --> Config Class Initialized
DEBUG - 2011-09-06 08:13:27 --> Hooks Class Initialized
DEBUG - 2011-09-06 08:13:27 --> Utf8 Class Initialized
DEBUG - 2011-09-06 08:13:27 --> UTF-8 Support Enabled
DEBUG - 2011-09-06 08:13:27 --> URI Class Initialized
DEBUG - 2011-09-06 08:13:27 --> Router Class Initialized
DEBUG - 2011-09-06 08:13:27 --> Output Class Initialized
DEBUG - 2011-09-06 08:13:27 --> Input Class Initialized
DEBUG - 2011-09-06 08:13:27 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-06 08:13:27 --> Language Class Initialized
DEBUG - 2011-09-06 08:13:27 --> Loader Class Initialized
DEBUG - 2011-09-06 08:13:27 --> Controller Class Initialized
DEBUG - 2011-09-06 08:13:27 --> Model Class Initialized
DEBUG - 2011-09-06 08:13:27 --> Model Class Initialized
DEBUG - 2011-09-06 08:13:27 --> Model Class Initialized
DEBUG - 2011-09-06 08:13:27 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-06 08:13:27 --> Database Driver Class Initialized
DEBUG - 2011-09-06 08:13:28 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-06 08:13:28 --> Helper loaded: url_helper
DEBUG - 2011-09-06 08:13:28 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-06 08:13:28 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-06 08:13:28 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-06 08:13:28 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-06 08:13:28 --> Final output sent to browser
DEBUG - 2011-09-06 08:13:28 --> Total execution time: 0.6616
DEBUG - 2011-09-06 08:13:29 --> Config Class Initialized
DEBUG - 2011-09-06 08:13:29 --> Hooks Class Initialized
DEBUG - 2011-09-06 08:13:29 --> Utf8 Class Initialized
DEBUG - 2011-09-06 08:13:29 --> UTF-8 Support Enabled
DEBUG - 2011-09-06 08:13:29 --> URI Class Initialized
DEBUG - 2011-09-06 08:13:29 --> Router Class Initialized
ERROR - 2011-09-06 08:13:29 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-06 08:13:29 --> Config Class Initialized
DEBUG - 2011-09-06 08:13:29 --> Hooks Class Initialized
DEBUG - 2011-09-06 08:13:29 --> Utf8 Class Initialized
DEBUG - 2011-09-06 08:13:29 --> UTF-8 Support Enabled
DEBUG - 2011-09-06 08:13:29 --> URI Class Initialized
DEBUG - 2011-09-06 08:13:29 --> Router Class Initialized
DEBUG - 2011-09-06 08:13:29 --> Output Class Initialized
DEBUG - 2011-09-06 08:13:29 --> Input Class Initialized
DEBUG - 2011-09-06 08:13:29 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-06 08:13:29 --> Language Class Initialized
DEBUG - 2011-09-06 08:13:29 --> Loader Class Initialized
DEBUG - 2011-09-06 08:13:29 --> Controller Class Initialized
DEBUG - 2011-09-06 08:13:29 --> Model Class Initialized
DEBUG - 2011-09-06 08:13:29 --> Model Class Initialized
DEBUG - 2011-09-06 08:13:29 --> Model Class Initialized
DEBUG - 2011-09-06 08:13:29 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-06 08:13:29 --> Database Driver Class Initialized
DEBUG - 2011-09-06 08:13:30 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-06 08:13:30 --> Helper loaded: url_helper
DEBUG - 2011-09-06 08:13:30 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-06 08:13:30 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-06 08:13:30 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-06 08:13:30 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-06 08:13:30 --> Final output sent to browser
DEBUG - 2011-09-06 08:13:30 --> Total execution time: 0.0534
DEBUG - 2011-09-06 08:17:30 --> Config Class Initialized
DEBUG - 2011-09-06 08:17:30 --> Hooks Class Initialized
DEBUG - 2011-09-06 08:17:30 --> Utf8 Class Initialized
DEBUG - 2011-09-06 08:17:30 --> UTF-8 Support Enabled
DEBUG - 2011-09-06 08:17:30 --> URI Class Initialized
DEBUG - 2011-09-06 08:17:30 --> Router Class Initialized
DEBUG - 2011-09-06 08:17:30 --> No URI present. Default controller set.
DEBUG - 2011-09-06 08:17:30 --> Output Class Initialized
DEBUG - 2011-09-06 08:17:30 --> Input Class Initialized
DEBUG - 2011-09-06 08:17:30 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-06 08:17:30 --> Language Class Initialized
DEBUG - 2011-09-06 08:17:30 --> Loader Class Initialized
DEBUG - 2011-09-06 08:17:30 --> Controller Class Initialized
DEBUG - 2011-09-06 08:17:30 --> File loaded: application/views/splash/main.php
DEBUG - 2011-09-06 08:17:30 --> Helper loaded: url_helper
DEBUG - 2011-09-06 08:17:30 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-06 08:17:30 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-06 08:17:30 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-06 08:17:30 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-06 08:17:30 --> Final output sent to browser
DEBUG - 2011-09-06 08:17:30 --> Total execution time: 0.1048
DEBUG - 2011-09-06 08:29:46 --> Config Class Initialized
DEBUG - 2011-09-06 08:29:46 --> Hooks Class Initialized
DEBUG - 2011-09-06 08:29:46 --> Utf8 Class Initialized
DEBUG - 2011-09-06 08:29:46 --> UTF-8 Support Enabled
DEBUG - 2011-09-06 08:29:46 --> URI Class Initialized
DEBUG - 2011-09-06 08:29:46 --> Router Class Initialized
DEBUG - 2011-09-06 08:29:46 --> Output Class Initialized
DEBUG - 2011-09-06 08:29:46 --> Input Class Initialized
DEBUG - 2011-09-06 08:29:46 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-06 08:29:46 --> Language Class Initialized
DEBUG - 2011-09-06 08:29:46 --> Loader Class Initialized
DEBUG - 2011-09-06 08:29:46 --> Controller Class Initialized
ERROR - 2011-09-06 08:29:46 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-06 08:29:46 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-06 08:29:46 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-06 08:29:46 --> Model Class Initialized
DEBUG - 2011-09-06 08:29:46 --> Model Class Initialized
DEBUG - 2011-09-06 08:29:46 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-06 08:29:46 --> Database Driver Class Initialized
DEBUG - 2011-09-06 08:29:46 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-06 08:29:46 --> Helper loaded: url_helper
DEBUG - 2011-09-06 08:29:46 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-06 08:29:46 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-06 08:29:46 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-06 08:29:46 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-06 08:29:46 --> Final output sent to browser
DEBUG - 2011-09-06 08:29:46 --> Total execution time: 0.3761
DEBUG - 2011-09-06 08:29:50 --> Config Class Initialized
DEBUG - 2011-09-06 08:29:50 --> Hooks Class Initialized
DEBUG - 2011-09-06 08:29:50 --> Utf8 Class Initialized
DEBUG - 2011-09-06 08:29:50 --> UTF-8 Support Enabled
DEBUG - 2011-09-06 08:29:50 --> URI Class Initialized
DEBUG - 2011-09-06 08:29:50 --> Router Class Initialized
DEBUG - 2011-09-06 08:29:50 --> Output Class Initialized
DEBUG - 2011-09-06 08:29:50 --> Input Class Initialized
DEBUG - 2011-09-06 08:29:50 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-06 08:29:50 --> Language Class Initialized
DEBUG - 2011-09-06 08:29:50 --> Loader Class Initialized
DEBUG - 2011-09-06 08:29:50 --> Controller Class Initialized
DEBUG - 2011-09-06 08:29:50 --> Model Class Initialized
DEBUG - 2011-09-06 08:29:50 --> Model Class Initialized
DEBUG - 2011-09-06 08:29:50 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-06 08:29:50 --> Database Driver Class Initialized
DEBUG - 2011-09-06 08:29:51 --> Final output sent to browser
DEBUG - 2011-09-06 08:29:51 --> Total execution time: 0.8642
DEBUG - 2011-09-06 09:19:07 --> Config Class Initialized
DEBUG - 2011-09-06 09:19:07 --> Hooks Class Initialized
DEBUG - 2011-09-06 09:19:07 --> Utf8 Class Initialized
DEBUG - 2011-09-06 09:19:07 --> UTF-8 Support Enabled
DEBUG - 2011-09-06 09:19:07 --> URI Class Initialized
DEBUG - 2011-09-06 09:19:07 --> Router Class Initialized
DEBUG - 2011-09-06 09:19:07 --> Output Class Initialized
DEBUG - 2011-09-06 09:19:07 --> Input Class Initialized
DEBUG - 2011-09-06 09:19:07 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-06 09:19:07 --> Language Class Initialized
DEBUG - 2011-09-06 09:19:07 --> Loader Class Initialized
DEBUG - 2011-09-06 09:19:07 --> Controller Class Initialized
DEBUG - 2011-09-06 09:19:07 --> Model Class Initialized
DEBUG - 2011-09-06 09:19:07 --> Model Class Initialized
DEBUG - 2011-09-06 09:19:07 --> Model Class Initialized
DEBUG - 2011-09-06 09:19:07 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-06 09:19:07 --> Database Driver Class Initialized
DEBUG - 2011-09-06 09:19:07 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-06 09:19:07 --> Helper loaded: url_helper
DEBUG - 2011-09-06 09:19:07 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-06 09:19:07 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-06 09:19:07 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-06 09:19:07 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-06 09:19:07 --> Final output sent to browser
DEBUG - 2011-09-06 09:19:07 --> Total execution time: 0.6510
DEBUG - 2011-09-06 09:19:11 --> Config Class Initialized
DEBUG - 2011-09-06 09:19:11 --> Hooks Class Initialized
DEBUG - 2011-09-06 09:19:11 --> Utf8 Class Initialized
DEBUG - 2011-09-06 09:19:11 --> UTF-8 Support Enabled
DEBUG - 2011-09-06 09:19:11 --> URI Class Initialized
DEBUG - 2011-09-06 09:19:11 --> Router Class Initialized
ERROR - 2011-09-06 09:19:11 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-06 09:19:11 --> Config Class Initialized
DEBUG - 2011-09-06 09:19:11 --> Hooks Class Initialized
DEBUG - 2011-09-06 09:19:11 --> Utf8 Class Initialized
DEBUG - 2011-09-06 09:19:11 --> UTF-8 Support Enabled
DEBUG - 2011-09-06 09:19:11 --> URI Class Initialized
DEBUG - 2011-09-06 09:19:11 --> Router Class Initialized
DEBUG - 2011-09-06 09:19:11 --> Output Class Initialized
DEBUG - 2011-09-06 09:19:11 --> Input Class Initialized
DEBUG - 2011-09-06 09:19:11 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-06 09:19:11 --> Language Class Initialized
DEBUG - 2011-09-06 09:19:11 --> Loader Class Initialized
DEBUG - 2011-09-06 09:19:11 --> Controller Class Initialized
DEBUG - 2011-09-06 09:19:11 --> Model Class Initialized
DEBUG - 2011-09-06 09:19:11 --> Model Class Initialized
DEBUG - 2011-09-06 09:19:11 --> Model Class Initialized
DEBUG - 2011-09-06 09:19:11 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-06 09:19:11 --> Database Driver Class Initialized
DEBUG - 2011-09-06 09:19:11 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-06 09:19:11 --> Helper loaded: url_helper
DEBUG - 2011-09-06 09:19:11 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-06 09:19:11 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-06 09:19:11 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-06 09:19:11 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-06 09:19:11 --> Final output sent to browser
DEBUG - 2011-09-06 09:19:11 --> Total execution time: 0.0839
DEBUG - 2011-09-06 09:19:24 --> Config Class Initialized
DEBUG - 2011-09-06 09:19:24 --> Hooks Class Initialized
DEBUG - 2011-09-06 09:19:24 --> Utf8 Class Initialized
DEBUG - 2011-09-06 09:19:24 --> UTF-8 Support Enabled
DEBUG - 2011-09-06 09:19:24 --> URI Class Initialized
DEBUG - 2011-09-06 09:19:24 --> Router Class Initialized
DEBUG - 2011-09-06 09:19:24 --> Output Class Initialized
DEBUG - 2011-09-06 09:19:24 --> Input Class Initialized
DEBUG - 2011-09-06 09:19:24 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-06 09:19:24 --> Language Class Initialized
DEBUG - 2011-09-06 09:19:24 --> Loader Class Initialized
DEBUG - 2011-09-06 09:19:24 --> Controller Class Initialized
DEBUG - 2011-09-06 09:19:24 --> Model Class Initialized
DEBUG - 2011-09-06 09:19:24 --> Model Class Initialized
DEBUG - 2011-09-06 09:19:24 --> Model Class Initialized
DEBUG - 2011-09-06 09:19:24 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-06 09:19:24 --> Database Driver Class Initialized
DEBUG - 2011-09-06 09:19:25 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-06 09:19:25 --> Helper loaded: url_helper
DEBUG - 2011-09-06 09:19:25 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-06 09:19:25 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-06 09:19:25 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-06 09:19:25 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-06 09:19:25 --> Final output sent to browser
DEBUG - 2011-09-06 09:19:25 --> Total execution time: 0.6194
DEBUG - 2011-09-06 09:19:26 --> Config Class Initialized
DEBUG - 2011-09-06 09:19:26 --> Hooks Class Initialized
DEBUG - 2011-09-06 09:19:26 --> Utf8 Class Initialized
DEBUG - 2011-09-06 09:19:26 --> UTF-8 Support Enabled
DEBUG - 2011-09-06 09:19:26 --> URI Class Initialized
DEBUG - 2011-09-06 09:19:26 --> Router Class Initialized
DEBUG - 2011-09-06 09:19:26 --> Output Class Initialized
DEBUG - 2011-09-06 09:19:26 --> Input Class Initialized
DEBUG - 2011-09-06 09:19:26 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-06 09:19:26 --> Language Class Initialized
DEBUG - 2011-09-06 09:19:27 --> Loader Class Initialized
DEBUG - 2011-09-06 09:19:27 --> Controller Class Initialized
DEBUG - 2011-09-06 09:19:27 --> Model Class Initialized
DEBUG - 2011-09-06 09:19:27 --> Model Class Initialized
DEBUG - 2011-09-06 09:19:27 --> Model Class Initialized
DEBUG - 2011-09-06 09:19:27 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-06 09:19:27 --> Database Driver Class Initialized
DEBUG - 2011-09-06 09:19:27 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-06 09:19:27 --> Helper loaded: url_helper
DEBUG - 2011-09-06 09:19:27 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-06 09:19:27 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-06 09:19:27 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-06 09:19:27 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-06 09:19:27 --> Final output sent to browser
DEBUG - 2011-09-06 09:19:27 --> Total execution time: 0.1056
DEBUG - 2011-09-06 09:19:39 --> Config Class Initialized
DEBUG - 2011-09-06 09:19:39 --> Hooks Class Initialized
DEBUG - 2011-09-06 09:19:39 --> Utf8 Class Initialized
DEBUG - 2011-09-06 09:19:39 --> UTF-8 Support Enabled
DEBUG - 2011-09-06 09:19:39 --> URI Class Initialized
DEBUG - 2011-09-06 09:19:39 --> Router Class Initialized
DEBUG - 2011-09-06 09:19:39 --> Output Class Initialized
DEBUG - 2011-09-06 09:19:39 --> Input Class Initialized
DEBUG - 2011-09-06 09:19:39 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-06 09:19:39 --> Language Class Initialized
DEBUG - 2011-09-06 09:19:39 --> Loader Class Initialized
DEBUG - 2011-09-06 09:19:39 --> Controller Class Initialized
DEBUG - 2011-09-06 09:19:39 --> Model Class Initialized
DEBUG - 2011-09-06 09:19:39 --> Model Class Initialized
DEBUG - 2011-09-06 09:19:39 --> Model Class Initialized
DEBUG - 2011-09-06 09:19:39 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-06 09:19:39 --> Database Driver Class Initialized
DEBUG - 2011-09-06 09:19:39 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-06 09:19:39 --> Helper loaded: url_helper
DEBUG - 2011-09-06 09:19:39 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-06 09:19:39 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-06 09:19:39 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-06 09:19:39 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-06 09:19:39 --> Final output sent to browser
DEBUG - 2011-09-06 09:19:39 --> Total execution time: 0.2842
DEBUG - 2011-09-06 09:19:41 --> Config Class Initialized
DEBUG - 2011-09-06 09:19:41 --> Hooks Class Initialized
DEBUG - 2011-09-06 09:19:41 --> Utf8 Class Initialized
DEBUG - 2011-09-06 09:19:41 --> UTF-8 Support Enabled
DEBUG - 2011-09-06 09:19:41 --> URI Class Initialized
DEBUG - 2011-09-06 09:19:41 --> Router Class Initialized
DEBUG - 2011-09-06 09:19:41 --> Output Class Initialized
DEBUG - 2011-09-06 09:19:41 --> Input Class Initialized
DEBUG - 2011-09-06 09:19:41 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-06 09:19:41 --> Language Class Initialized
DEBUG - 2011-09-06 09:19:41 --> Loader Class Initialized
DEBUG - 2011-09-06 09:19:41 --> Controller Class Initialized
DEBUG - 2011-09-06 09:19:41 --> Model Class Initialized
DEBUG - 2011-09-06 09:19:41 --> Model Class Initialized
DEBUG - 2011-09-06 09:19:41 --> Model Class Initialized
DEBUG - 2011-09-06 09:19:41 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-06 09:19:41 --> Database Driver Class Initialized
DEBUG - 2011-09-06 09:19:41 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-06 09:19:41 --> Helper loaded: url_helper
DEBUG - 2011-09-06 09:19:41 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-06 09:19:41 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-06 09:19:41 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-06 09:19:41 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-06 09:19:41 --> Final output sent to browser
DEBUG - 2011-09-06 09:19:41 --> Total execution time: 0.0648
DEBUG - 2011-09-06 09:35:24 --> Config Class Initialized
DEBUG - 2011-09-06 09:35:24 --> Hooks Class Initialized
DEBUG - 2011-09-06 09:35:24 --> Utf8 Class Initialized
DEBUG - 2011-09-06 09:35:24 --> UTF-8 Support Enabled
DEBUG - 2011-09-06 09:35:24 --> URI Class Initialized
DEBUG - 2011-09-06 09:35:24 --> Router Class Initialized
DEBUG - 2011-09-06 09:35:24 --> Output Class Initialized
DEBUG - 2011-09-06 09:35:24 --> Input Class Initialized
DEBUG - 2011-09-06 09:35:24 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-06 09:35:24 --> Language Class Initialized
DEBUG - 2011-09-06 09:35:24 --> Loader Class Initialized
DEBUG - 2011-09-06 09:35:24 --> Controller Class Initialized
DEBUG - 2011-09-06 09:35:24 --> Model Class Initialized
DEBUG - 2011-09-06 09:35:24 --> Model Class Initialized
DEBUG - 2011-09-06 09:35:24 --> Model Class Initialized
DEBUG - 2011-09-06 09:35:24 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-06 09:35:24 --> Database Driver Class Initialized
DEBUG - 2011-09-06 09:35:25 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-06 09:35:25 --> Helper loaded: url_helper
DEBUG - 2011-09-06 09:35:25 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-06 09:35:25 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-06 09:35:25 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-06 09:35:25 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-06 09:35:25 --> Final output sent to browser
DEBUG - 2011-09-06 09:35:25 --> Total execution time: 1.0379
DEBUG - 2011-09-06 09:35:29 --> Config Class Initialized
DEBUG - 2011-09-06 09:35:29 --> Hooks Class Initialized
DEBUG - 2011-09-06 09:35:29 --> Utf8 Class Initialized
DEBUG - 2011-09-06 09:35:29 --> UTF-8 Support Enabled
DEBUG - 2011-09-06 09:35:29 --> URI Class Initialized
DEBUG - 2011-09-06 09:35:29 --> Router Class Initialized
ERROR - 2011-09-06 09:35:29 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-06 09:58:56 --> Config Class Initialized
DEBUG - 2011-09-06 09:58:56 --> Hooks Class Initialized
DEBUG - 2011-09-06 09:58:56 --> Utf8 Class Initialized
DEBUG - 2011-09-06 09:58:56 --> UTF-8 Support Enabled
DEBUG - 2011-09-06 09:58:56 --> URI Class Initialized
DEBUG - 2011-09-06 09:58:56 --> Router Class Initialized
DEBUG - 2011-09-06 09:58:56 --> Output Class Initialized
DEBUG - 2011-09-06 09:58:56 --> Input Class Initialized
DEBUG - 2011-09-06 09:58:56 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-06 09:58:56 --> Language Class Initialized
DEBUG - 2011-09-06 09:58:56 --> Loader Class Initialized
DEBUG - 2011-09-06 09:58:56 --> Controller Class Initialized
DEBUG - 2011-09-06 09:58:56 --> Model Class Initialized
DEBUG - 2011-09-06 09:58:56 --> Model Class Initialized
DEBUG - 2011-09-06 09:58:56 --> Model Class Initialized
DEBUG - 2011-09-06 09:58:56 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-06 09:58:56 --> Database Driver Class Initialized
DEBUG - 2011-09-06 09:58:57 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-06 09:58:57 --> Helper loaded: url_helper
DEBUG - 2011-09-06 09:58:57 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-06 09:58:57 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-06 09:58:57 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-06 09:58:57 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-06 09:58:57 --> Final output sent to browser
DEBUG - 2011-09-06 09:58:57 --> Total execution time: 0.5605
DEBUG - 2011-09-06 09:59:00 --> Config Class Initialized
DEBUG - 2011-09-06 09:59:00 --> Hooks Class Initialized
DEBUG - 2011-09-06 09:59:00 --> Utf8 Class Initialized
DEBUG - 2011-09-06 09:59:00 --> UTF-8 Support Enabled
DEBUG - 2011-09-06 09:59:00 --> URI Class Initialized
DEBUG - 2011-09-06 09:59:00 --> Router Class Initialized
ERROR - 2011-09-06 09:59:00 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-06 09:59:14 --> Config Class Initialized
DEBUG - 2011-09-06 09:59:14 --> Hooks Class Initialized
DEBUG - 2011-09-06 09:59:14 --> Utf8 Class Initialized
DEBUG - 2011-09-06 09:59:14 --> UTF-8 Support Enabled
DEBUG - 2011-09-06 09:59:14 --> URI Class Initialized
DEBUG - 2011-09-06 09:59:14 --> Router Class Initialized
DEBUG - 2011-09-06 09:59:14 --> Output Class Initialized
DEBUG - 2011-09-06 09:59:14 --> Input Class Initialized
DEBUG - 2011-09-06 09:59:14 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-06 09:59:14 --> Language Class Initialized
DEBUG - 2011-09-06 09:59:14 --> Loader Class Initialized
DEBUG - 2011-09-06 09:59:14 --> Controller Class Initialized
DEBUG - 2011-09-06 09:59:14 --> Model Class Initialized
DEBUG - 2011-09-06 09:59:14 --> Model Class Initialized
DEBUG - 2011-09-06 09:59:14 --> Model Class Initialized
DEBUG - 2011-09-06 09:59:14 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-06 09:59:14 --> Database Driver Class Initialized
DEBUG - 2011-09-06 09:59:15 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-06 09:59:15 --> Helper loaded: url_helper
DEBUG - 2011-09-06 09:59:15 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-06 09:59:15 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-06 09:59:15 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-06 09:59:15 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-06 09:59:15 --> Final output sent to browser
DEBUG - 2011-09-06 09:59:15 --> Total execution time: 1.0657
DEBUG - 2011-09-06 09:59:18 --> Config Class Initialized
DEBUG - 2011-09-06 09:59:18 --> Hooks Class Initialized
DEBUG - 2011-09-06 09:59:18 --> Utf8 Class Initialized
DEBUG - 2011-09-06 09:59:18 --> UTF-8 Support Enabled
DEBUG - 2011-09-06 09:59:18 --> URI Class Initialized
DEBUG - 2011-09-06 09:59:18 --> Router Class Initialized
ERROR - 2011-09-06 09:59:18 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-06 09:59:38 --> Config Class Initialized
DEBUG - 2011-09-06 09:59:38 --> Hooks Class Initialized
DEBUG - 2011-09-06 09:59:38 --> Utf8 Class Initialized
DEBUG - 2011-09-06 09:59:38 --> UTF-8 Support Enabled
DEBUG - 2011-09-06 09:59:38 --> URI Class Initialized
DEBUG - 2011-09-06 09:59:38 --> Router Class Initialized
DEBUG - 2011-09-06 09:59:38 --> Output Class Initialized
DEBUG - 2011-09-06 09:59:38 --> Input Class Initialized
DEBUG - 2011-09-06 09:59:38 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-06 09:59:38 --> Language Class Initialized
DEBUG - 2011-09-06 09:59:38 --> Loader Class Initialized
DEBUG - 2011-09-06 09:59:38 --> Controller Class Initialized
DEBUG - 2011-09-06 09:59:38 --> Model Class Initialized
DEBUG - 2011-09-06 09:59:38 --> Model Class Initialized
DEBUG - 2011-09-06 09:59:38 --> Model Class Initialized
DEBUG - 2011-09-06 09:59:38 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-06 09:59:38 --> Database Driver Class Initialized
DEBUG - 2011-09-06 09:59:39 --> Config Class Initialized
DEBUG - 2011-09-06 09:59:39 --> Hooks Class Initialized
DEBUG - 2011-09-06 09:59:39 --> Utf8 Class Initialized
DEBUG - 2011-09-06 09:59:39 --> UTF-8 Support Enabled
DEBUG - 2011-09-06 09:59:39 --> URI Class Initialized
DEBUG - 2011-09-06 09:59:39 --> Router Class Initialized
ERROR - 2011-09-06 09:59:39 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-09-06 09:59:39 --> Config Class Initialized
DEBUG - 2011-09-06 09:59:39 --> Hooks Class Initialized
DEBUG - 2011-09-06 09:59:39 --> Utf8 Class Initialized
DEBUG - 2011-09-06 09:59:39 --> UTF-8 Support Enabled
DEBUG - 2011-09-06 09:59:39 --> URI Class Initialized
DEBUG - 2011-09-06 09:59:39 --> Router Class Initialized
DEBUG - 2011-09-06 09:59:39 --> Output Class Initialized
DEBUG - 2011-09-06 09:59:39 --> Input Class Initialized
DEBUG - 2011-09-06 09:59:39 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-06 09:59:39 --> Language Class Initialized
DEBUG - 2011-09-06 09:59:39 --> Loader Class Initialized
DEBUG - 2011-09-06 09:59:39 --> Controller Class Initialized
DEBUG - 2011-09-06 09:59:39 --> Model Class Initialized
DEBUG - 2011-09-06 09:59:39 --> Model Class Initialized
DEBUG - 2011-09-06 09:59:39 --> Model Class Initialized
DEBUG - 2011-09-06 09:59:39 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-06 09:59:39 --> Database Driver Class Initialized
DEBUG - 2011-09-06 09:59:39 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-06 09:59:39 --> Helper loaded: url_helper
DEBUG - 2011-09-06 09:59:39 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-06 09:59:39 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-06 09:59:39 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-06 09:59:39 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-06 09:59:39 --> Final output sent to browser
DEBUG - 2011-09-06 09:59:39 --> Total execution time: 0.1525
DEBUG - 2011-09-06 09:59:40 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-06 09:59:40 --> Helper loaded: url_helper
DEBUG - 2011-09-06 09:59:40 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-06 09:59:40 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-06 09:59:40 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-06 09:59:40 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-06 09:59:40 --> Final output sent to browser
DEBUG - 2011-09-06 09:59:40 --> Total execution time: 1.8580
DEBUG - 2011-09-06 09:59:47 --> Config Class Initialized
DEBUG - 2011-09-06 09:59:47 --> Hooks Class Initialized
DEBUG - 2011-09-06 09:59:47 --> Utf8 Class Initialized
DEBUG - 2011-09-06 09:59:47 --> UTF-8 Support Enabled
DEBUG - 2011-09-06 09:59:47 --> URI Class Initialized
DEBUG - 2011-09-06 09:59:47 --> Router Class Initialized
ERROR - 2011-09-06 09:59:47 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-06 10:00:00 --> Config Class Initialized
DEBUG - 2011-09-06 10:00:00 --> Hooks Class Initialized
DEBUG - 2011-09-06 10:00:00 --> Utf8 Class Initialized
DEBUG - 2011-09-06 10:00:00 --> UTF-8 Support Enabled
DEBUG - 2011-09-06 10:00:00 --> URI Class Initialized
DEBUG - 2011-09-06 10:00:00 --> Router Class Initialized
DEBUG - 2011-09-06 10:00:00 --> Output Class Initialized
DEBUG - 2011-09-06 10:00:00 --> Input Class Initialized
DEBUG - 2011-09-06 10:00:00 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-06 10:00:00 --> Language Class Initialized
DEBUG - 2011-09-06 10:00:00 --> Loader Class Initialized
DEBUG - 2011-09-06 10:00:00 --> Controller Class Initialized
DEBUG - 2011-09-06 10:00:00 --> Model Class Initialized
DEBUG - 2011-09-06 10:00:00 --> Model Class Initialized
DEBUG - 2011-09-06 10:00:00 --> Model Class Initialized
DEBUG - 2011-09-06 10:00:00 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-06 10:00:00 --> Database Driver Class Initialized
DEBUG - 2011-09-06 10:00:00 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-06 10:00:00 --> Helper loaded: url_helper
DEBUG - 2011-09-06 10:00:00 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-06 10:00:00 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-06 10:00:00 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-06 10:00:00 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-06 10:00:00 --> Final output sent to browser
DEBUG - 2011-09-06 10:00:00 --> Total execution time: 0.1019
DEBUG - 2011-09-06 10:00:04 --> Config Class Initialized
DEBUG - 2011-09-06 10:00:04 --> Hooks Class Initialized
DEBUG - 2011-09-06 10:00:04 --> Utf8 Class Initialized
DEBUG - 2011-09-06 10:00:04 --> UTF-8 Support Enabled
DEBUG - 2011-09-06 10:00:04 --> URI Class Initialized
DEBUG - 2011-09-06 10:00:04 --> Router Class Initialized
ERROR - 2011-09-06 10:00:04 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-06 10:00:10 --> Config Class Initialized
DEBUG - 2011-09-06 10:00:10 --> Hooks Class Initialized
DEBUG - 2011-09-06 10:00:10 --> Utf8 Class Initialized
DEBUG - 2011-09-06 10:00:10 --> UTF-8 Support Enabled
DEBUG - 2011-09-06 10:00:10 --> URI Class Initialized
DEBUG - 2011-09-06 10:00:10 --> Router Class Initialized
ERROR - 2011-09-06 10:00:10 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-06 10:00:13 --> Config Class Initialized
DEBUG - 2011-09-06 10:00:13 --> Hooks Class Initialized
DEBUG - 2011-09-06 10:00:13 --> Utf8 Class Initialized
DEBUG - 2011-09-06 10:00:13 --> UTF-8 Support Enabled
DEBUG - 2011-09-06 10:00:13 --> URI Class Initialized
DEBUG - 2011-09-06 10:00:13 --> Router Class Initialized
DEBUG - 2011-09-06 10:00:13 --> Output Class Initialized
DEBUG - 2011-09-06 10:00:13 --> Input Class Initialized
DEBUG - 2011-09-06 10:00:13 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-06 10:00:13 --> Language Class Initialized
DEBUG - 2011-09-06 10:00:13 --> Loader Class Initialized
DEBUG - 2011-09-06 10:00:13 --> Controller Class Initialized
DEBUG - 2011-09-06 10:00:13 --> Model Class Initialized
DEBUG - 2011-09-06 10:00:13 --> Model Class Initialized
DEBUG - 2011-09-06 10:00:13 --> Model Class Initialized
DEBUG - 2011-09-06 10:00:13 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-06 10:00:13 --> Database Driver Class Initialized
DEBUG - 2011-09-06 10:00:13 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-06 10:00:13 --> Helper loaded: url_helper
DEBUG - 2011-09-06 10:00:13 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-06 10:00:13 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-06 10:00:13 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-06 10:00:13 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-06 10:00:13 --> Final output sent to browser
DEBUG - 2011-09-06 10:00:13 --> Total execution time: 0.0458
DEBUG - 2011-09-06 10:00:17 --> Config Class Initialized
DEBUG - 2011-09-06 10:00:17 --> Hooks Class Initialized
DEBUG - 2011-09-06 10:00:17 --> Utf8 Class Initialized
DEBUG - 2011-09-06 10:00:17 --> UTF-8 Support Enabled
DEBUG - 2011-09-06 10:00:17 --> URI Class Initialized
DEBUG - 2011-09-06 10:00:17 --> Router Class Initialized
ERROR - 2011-09-06 10:00:17 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-06 10:00:29 --> Config Class Initialized
DEBUG - 2011-09-06 10:00:29 --> Hooks Class Initialized
DEBUG - 2011-09-06 10:00:29 --> Utf8 Class Initialized
DEBUG - 2011-09-06 10:00:29 --> UTF-8 Support Enabled
DEBUG - 2011-09-06 10:00:29 --> URI Class Initialized
DEBUG - 2011-09-06 10:00:29 --> Router Class Initialized
DEBUG - 2011-09-06 10:00:29 --> Output Class Initialized
DEBUG - 2011-09-06 10:00:29 --> Input Class Initialized
DEBUG - 2011-09-06 10:00:29 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-06 10:00:29 --> Language Class Initialized
DEBUG - 2011-09-06 10:00:29 --> Loader Class Initialized
DEBUG - 2011-09-06 10:00:29 --> Controller Class Initialized
DEBUG - 2011-09-06 10:00:29 --> Model Class Initialized
DEBUG - 2011-09-06 10:00:29 --> Model Class Initialized
DEBUG - 2011-09-06 10:00:29 --> Model Class Initialized
DEBUG - 2011-09-06 10:00:29 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-06 10:00:29 --> Database Driver Class Initialized
DEBUG - 2011-09-06 10:00:30 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-06 10:00:30 --> Helper loaded: url_helper
DEBUG - 2011-09-06 10:00:30 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-06 10:00:30 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-06 10:00:30 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-06 10:00:30 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-06 10:00:30 --> Final output sent to browser
DEBUG - 2011-09-06 10:00:30 --> Total execution time: 0.1119
DEBUG - 2011-09-06 10:00:33 --> Config Class Initialized
DEBUG - 2011-09-06 10:00:33 --> Hooks Class Initialized
DEBUG - 2011-09-06 10:00:33 --> Utf8 Class Initialized
DEBUG - 2011-09-06 10:00:33 --> UTF-8 Support Enabled
DEBUG - 2011-09-06 10:00:33 --> URI Class Initialized
DEBUG - 2011-09-06 10:00:33 --> Router Class Initialized
ERROR - 2011-09-06 10:00:33 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-06 10:03:03 --> Config Class Initialized
DEBUG - 2011-09-06 10:03:03 --> Hooks Class Initialized
DEBUG - 2011-09-06 10:03:03 --> Utf8 Class Initialized
DEBUG - 2011-09-06 10:03:03 --> UTF-8 Support Enabled
DEBUG - 2011-09-06 10:03:03 --> URI Class Initialized
DEBUG - 2011-09-06 10:03:03 --> Router Class Initialized
DEBUG - 2011-09-06 10:03:03 --> Output Class Initialized
DEBUG - 2011-09-06 10:03:03 --> Input Class Initialized
DEBUG - 2011-09-06 10:03:03 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-06 10:03:03 --> Language Class Initialized
DEBUG - 2011-09-06 10:03:03 --> Loader Class Initialized
DEBUG - 2011-09-06 10:03:03 --> Controller Class Initialized
ERROR - 2011-09-06 10:03:03 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-06 10:03:03 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-06 10:03:03 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-06 10:03:03 --> Model Class Initialized
DEBUG - 2011-09-06 10:03:03 --> Model Class Initialized
DEBUG - 2011-09-06 10:03:03 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-06 10:03:03 --> Database Driver Class Initialized
DEBUG - 2011-09-06 10:03:03 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-06 10:03:03 --> Helper loaded: url_helper
DEBUG - 2011-09-06 10:03:03 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-06 10:03:03 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-06 10:03:03 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-06 10:03:03 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-06 10:03:03 --> Final output sent to browser
DEBUG - 2011-09-06 10:03:03 --> Total execution time: 0.1342
DEBUG - 2011-09-06 10:03:06 --> Config Class Initialized
DEBUG - 2011-09-06 10:03:06 --> Hooks Class Initialized
DEBUG - 2011-09-06 10:03:06 --> Utf8 Class Initialized
DEBUG - 2011-09-06 10:03:06 --> UTF-8 Support Enabled
DEBUG - 2011-09-06 10:03:06 --> URI Class Initialized
DEBUG - 2011-09-06 10:03:06 --> Router Class Initialized
DEBUG - 2011-09-06 10:03:06 --> Output Class Initialized
DEBUG - 2011-09-06 10:03:06 --> Input Class Initialized
DEBUG - 2011-09-06 10:03:06 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-06 10:03:06 --> Language Class Initialized
DEBUG - 2011-09-06 10:03:06 --> Loader Class Initialized
DEBUG - 2011-09-06 10:03:06 --> Controller Class Initialized
DEBUG - 2011-09-06 10:03:06 --> Model Class Initialized
DEBUG - 2011-09-06 10:03:06 --> Model Class Initialized
DEBUG - 2011-09-06 10:03:06 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-06 10:03:06 --> Database Driver Class Initialized
DEBUG - 2011-09-06 10:03:06 --> Final output sent to browser
DEBUG - 2011-09-06 10:03:06 --> Total execution time: 0.7337
DEBUG - 2011-09-06 10:03:35 --> Config Class Initialized
DEBUG - 2011-09-06 10:03:35 --> Hooks Class Initialized
DEBUG - 2011-09-06 10:03:35 --> Utf8 Class Initialized
DEBUG - 2011-09-06 10:03:35 --> UTF-8 Support Enabled
DEBUG - 2011-09-06 10:03:35 --> URI Class Initialized
DEBUG - 2011-09-06 10:03:35 --> Router Class Initialized
ERROR - 2011-09-06 10:03:35 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-09-06 10:03:35 --> Config Class Initialized
DEBUG - 2011-09-06 10:03:35 --> Hooks Class Initialized
DEBUG - 2011-09-06 10:03:35 --> Utf8 Class Initialized
DEBUG - 2011-09-06 10:03:35 --> UTF-8 Support Enabled
DEBUG - 2011-09-06 10:03:35 --> URI Class Initialized
DEBUG - 2011-09-06 10:03:35 --> Router Class Initialized
DEBUG - 2011-09-06 10:03:35 --> Output Class Initialized
DEBUG - 2011-09-06 10:03:35 --> Input Class Initialized
DEBUG - 2011-09-06 10:03:35 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-06 10:03:35 --> Language Class Initialized
DEBUG - 2011-09-06 10:03:35 --> Loader Class Initialized
DEBUG - 2011-09-06 10:03:35 --> Controller Class Initialized
ERROR - 2011-09-06 10:03:35 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-06 10:03:35 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-06 10:03:35 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-06 10:03:35 --> Model Class Initialized
DEBUG - 2011-09-06 10:03:35 --> Model Class Initialized
DEBUG - 2011-09-06 10:03:35 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-06 10:03:35 --> Database Driver Class Initialized
DEBUG - 2011-09-06 10:03:35 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-06 10:03:35 --> Helper loaded: url_helper
DEBUG - 2011-09-06 10:03:35 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-06 10:03:35 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-06 10:03:35 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-06 10:03:35 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-06 10:03:35 --> Final output sent to browser
DEBUG - 2011-09-06 10:03:35 --> Total execution time: 0.0424
DEBUG - 2011-09-06 10:03:38 --> Config Class Initialized
DEBUG - 2011-09-06 10:03:38 --> Hooks Class Initialized
DEBUG - 2011-09-06 10:03:38 --> Utf8 Class Initialized
DEBUG - 2011-09-06 10:03:38 --> UTF-8 Support Enabled
DEBUG - 2011-09-06 10:03:38 --> URI Class Initialized
DEBUG - 2011-09-06 10:03:38 --> Router Class Initialized
ERROR - 2011-09-06 10:03:38 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-09-06 10:03:38 --> Config Class Initialized
DEBUG - 2011-09-06 10:03:38 --> Hooks Class Initialized
DEBUG - 2011-09-06 10:03:38 --> Utf8 Class Initialized
DEBUG - 2011-09-06 10:03:38 --> UTF-8 Support Enabled
DEBUG - 2011-09-06 10:03:38 --> URI Class Initialized
DEBUG - 2011-09-06 10:03:38 --> Router Class Initialized
DEBUG - 2011-09-06 10:03:38 --> Output Class Initialized
DEBUG - 2011-09-06 10:03:38 --> Input Class Initialized
DEBUG - 2011-09-06 10:03:38 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-06 10:03:38 --> Language Class Initialized
DEBUG - 2011-09-06 10:03:38 --> Loader Class Initialized
DEBUG - 2011-09-06 10:03:38 --> Controller Class Initialized
DEBUG - 2011-09-06 10:03:38 --> Model Class Initialized
DEBUG - 2011-09-06 10:03:38 --> Model Class Initialized
DEBUG - 2011-09-06 10:03:38 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-06 10:03:38 --> Database Driver Class Initialized
DEBUG - 2011-09-06 10:03:38 --> Final output sent to browser
DEBUG - 2011-09-06 10:03:38 --> Total execution time: 0.3184
DEBUG - 2011-09-06 10:11:02 --> Config Class Initialized
DEBUG - 2011-09-06 10:11:02 --> Hooks Class Initialized
DEBUG - 2011-09-06 10:11:02 --> Utf8 Class Initialized
DEBUG - 2011-09-06 10:11:02 --> UTF-8 Support Enabled
DEBUG - 2011-09-06 10:11:02 --> URI Class Initialized
DEBUG - 2011-09-06 10:11:02 --> Router Class Initialized
DEBUG - 2011-09-06 10:11:02 --> Output Class Initialized
DEBUG - 2011-09-06 10:11:02 --> Input Class Initialized
DEBUG - 2011-09-06 10:11:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-06 10:11:02 --> Language Class Initialized
DEBUG - 2011-09-06 10:11:02 --> Loader Class Initialized
DEBUG - 2011-09-06 10:11:02 --> Controller Class Initialized
ERROR - 2011-09-06 10:11:02 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-06 10:11:02 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-06 10:11:02 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-06 10:11:02 --> Model Class Initialized
DEBUG - 2011-09-06 10:11:02 --> Model Class Initialized
DEBUG - 2011-09-06 10:11:02 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-06 10:11:02 --> Database Driver Class Initialized
DEBUG - 2011-09-06 10:11:02 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-06 10:11:02 --> Helper loaded: url_helper
DEBUG - 2011-09-06 10:11:02 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-06 10:11:02 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-06 10:11:02 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-06 10:11:02 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-06 10:11:02 --> Final output sent to browser
DEBUG - 2011-09-06 10:11:02 --> Total execution time: 0.0278
DEBUG - 2011-09-06 10:11:03 --> Config Class Initialized
DEBUG - 2011-09-06 10:11:03 --> Hooks Class Initialized
DEBUG - 2011-09-06 10:11:03 --> Utf8 Class Initialized
DEBUG - 2011-09-06 10:11:03 --> UTF-8 Support Enabled
DEBUG - 2011-09-06 10:11:03 --> URI Class Initialized
DEBUG - 2011-09-06 10:11:03 --> Router Class Initialized
DEBUG - 2011-09-06 10:11:03 --> Output Class Initialized
DEBUG - 2011-09-06 10:11:03 --> Input Class Initialized
DEBUG - 2011-09-06 10:11:03 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-06 10:11:03 --> Language Class Initialized
DEBUG - 2011-09-06 10:11:03 --> Loader Class Initialized
DEBUG - 2011-09-06 10:11:03 --> Controller Class Initialized
DEBUG - 2011-09-06 10:11:03 --> Model Class Initialized
DEBUG - 2011-09-06 10:11:03 --> Model Class Initialized
DEBUG - 2011-09-06 10:11:03 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-06 10:11:03 --> Database Driver Class Initialized
DEBUG - 2011-09-06 10:11:04 --> Final output sent to browser
DEBUG - 2011-09-06 10:11:04 --> Total execution time: 0.6291
DEBUG - 2011-09-06 10:12:36 --> Config Class Initialized
DEBUG - 2011-09-06 10:12:36 --> Hooks Class Initialized
DEBUG - 2011-09-06 10:12:36 --> Utf8 Class Initialized
DEBUG - 2011-09-06 10:12:36 --> UTF-8 Support Enabled
DEBUG - 2011-09-06 10:12:36 --> URI Class Initialized
DEBUG - 2011-09-06 10:12:36 --> Router Class Initialized
DEBUG - 2011-09-06 10:12:36 --> Output Class Initialized
DEBUG - 2011-09-06 10:12:36 --> Input Class Initialized
DEBUG - 2011-09-06 10:12:36 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-06 10:12:36 --> Language Class Initialized
DEBUG - 2011-09-06 10:12:36 --> Loader Class Initialized
DEBUG - 2011-09-06 10:12:36 --> Controller Class Initialized
DEBUG - 2011-09-06 10:12:36 --> Model Class Initialized
DEBUG - 2011-09-06 10:12:36 --> Model Class Initialized
DEBUG - 2011-09-06 10:12:36 --> Model Class Initialized
DEBUG - 2011-09-06 10:12:36 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-06 10:12:36 --> Database Driver Class Initialized
DEBUG - 2011-09-06 10:12:36 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-06 10:12:36 --> Helper loaded: url_helper
DEBUG - 2011-09-06 10:12:36 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-06 10:12:36 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-06 10:12:36 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-06 10:12:36 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-06 10:12:36 --> Final output sent to browser
DEBUG - 2011-09-06 10:12:36 --> Total execution time: 0.1467
DEBUG - 2011-09-06 10:12:52 --> Config Class Initialized
DEBUG - 2011-09-06 10:12:52 --> Hooks Class Initialized
DEBUG - 2011-09-06 10:12:52 --> Utf8 Class Initialized
DEBUG - 2011-09-06 10:12:52 --> UTF-8 Support Enabled
DEBUG - 2011-09-06 10:12:52 --> URI Class Initialized
DEBUG - 2011-09-06 10:12:52 --> Router Class Initialized
DEBUG - 2011-09-06 10:12:52 --> Output Class Initialized
DEBUG - 2011-09-06 10:12:52 --> Input Class Initialized
DEBUG - 2011-09-06 10:12:52 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-06 10:12:52 --> Language Class Initialized
DEBUG - 2011-09-06 10:12:52 --> Loader Class Initialized
DEBUG - 2011-09-06 10:12:52 --> Controller Class Initialized
DEBUG - 2011-09-06 10:12:52 --> Model Class Initialized
DEBUG - 2011-09-06 10:12:52 --> Model Class Initialized
DEBUG - 2011-09-06 10:12:52 --> Model Class Initialized
DEBUG - 2011-09-06 10:12:52 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-06 10:12:52 --> Database Driver Class Initialized
DEBUG - 2011-09-06 10:12:52 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-06 10:12:52 --> Helper loaded: url_helper
DEBUG - 2011-09-06 10:12:52 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-06 10:12:52 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-06 10:12:52 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-06 10:12:52 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-06 10:12:52 --> Final output sent to browser
DEBUG - 2011-09-06 10:12:52 --> Total execution time: 0.1429
DEBUG - 2011-09-06 10:12:54 --> Config Class Initialized
DEBUG - 2011-09-06 10:12:54 --> Hooks Class Initialized
DEBUG - 2011-09-06 10:12:54 --> Utf8 Class Initialized
DEBUG - 2011-09-06 10:12:54 --> UTF-8 Support Enabled
DEBUG - 2011-09-06 10:12:54 --> URI Class Initialized
DEBUG - 2011-09-06 10:12:54 --> Router Class Initialized
DEBUG - 2011-09-06 10:12:54 --> Output Class Initialized
DEBUG - 2011-09-06 10:12:54 --> Input Class Initialized
DEBUG - 2011-09-06 10:12:54 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-06 10:12:54 --> Language Class Initialized
DEBUG - 2011-09-06 10:12:54 --> Loader Class Initialized
DEBUG - 2011-09-06 10:12:54 --> Controller Class Initialized
DEBUG - 2011-09-06 10:12:54 --> Model Class Initialized
DEBUG - 2011-09-06 10:12:54 --> Model Class Initialized
DEBUG - 2011-09-06 10:12:54 --> Model Class Initialized
DEBUG - 2011-09-06 10:12:54 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-06 10:12:54 --> Database Driver Class Initialized
DEBUG - 2011-09-06 10:12:54 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-06 10:12:54 --> Helper loaded: url_helper
DEBUG - 2011-09-06 10:12:54 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-06 10:12:54 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-06 10:12:54 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-06 10:12:54 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-06 10:12:54 --> Final output sent to browser
DEBUG - 2011-09-06 10:12:54 --> Total execution time: 0.0388
DEBUG - 2011-09-06 10:13:09 --> Config Class Initialized
DEBUG - 2011-09-06 10:13:09 --> Hooks Class Initialized
DEBUG - 2011-09-06 10:13:09 --> Utf8 Class Initialized
DEBUG - 2011-09-06 10:13:09 --> UTF-8 Support Enabled
DEBUG - 2011-09-06 10:13:09 --> URI Class Initialized
DEBUG - 2011-09-06 10:13:09 --> Router Class Initialized
DEBUG - 2011-09-06 10:13:09 --> Output Class Initialized
DEBUG - 2011-09-06 10:13:09 --> Input Class Initialized
DEBUG - 2011-09-06 10:13:09 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-06 10:13:09 --> Language Class Initialized
DEBUG - 2011-09-06 10:13:09 --> Loader Class Initialized
DEBUG - 2011-09-06 10:13:09 --> Controller Class Initialized
ERROR - 2011-09-06 10:13:09 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-06 10:13:09 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-06 10:13:09 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-06 10:13:09 --> Model Class Initialized
DEBUG - 2011-09-06 10:13:09 --> Model Class Initialized
DEBUG - 2011-09-06 10:13:09 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-06 10:13:09 --> Database Driver Class Initialized
DEBUG - 2011-09-06 10:13:09 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-06 10:13:09 --> Helper loaded: url_helper
DEBUG - 2011-09-06 10:13:09 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-06 10:13:09 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-06 10:13:09 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-06 10:13:09 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-06 10:13:09 --> Final output sent to browser
DEBUG - 2011-09-06 10:13:09 --> Total execution time: 0.0428
DEBUG - 2011-09-06 10:13:14 --> Config Class Initialized
DEBUG - 2011-09-06 10:13:14 --> Hooks Class Initialized
DEBUG - 2011-09-06 10:13:14 --> Utf8 Class Initialized
DEBUG - 2011-09-06 10:13:14 --> UTF-8 Support Enabled
DEBUG - 2011-09-06 10:13:14 --> URI Class Initialized
DEBUG - 2011-09-06 10:13:14 --> Router Class Initialized
DEBUG - 2011-09-06 10:13:14 --> Output Class Initialized
DEBUG - 2011-09-06 10:13:14 --> Input Class Initialized
DEBUG - 2011-09-06 10:13:14 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-06 10:13:14 --> Language Class Initialized
DEBUG - 2011-09-06 10:13:14 --> Loader Class Initialized
DEBUG - 2011-09-06 10:13:14 --> Controller Class Initialized
DEBUG - 2011-09-06 10:13:14 --> Model Class Initialized
DEBUG - 2011-09-06 10:13:14 --> Model Class Initialized
DEBUG - 2011-09-06 10:13:14 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-06 10:13:14 --> Database Driver Class Initialized
DEBUG - 2011-09-06 10:13:15 --> Final output sent to browser
DEBUG - 2011-09-06 10:13:15 --> Total execution time: 0.7277
DEBUG - 2011-09-06 10:13:17 --> Config Class Initialized
DEBUG - 2011-09-06 10:13:17 --> Hooks Class Initialized
DEBUG - 2011-09-06 10:13:17 --> Utf8 Class Initialized
DEBUG - 2011-09-06 10:13:17 --> UTF-8 Support Enabled
DEBUG - 2011-09-06 10:13:17 --> URI Class Initialized
DEBUG - 2011-09-06 10:13:17 --> Router Class Initialized
ERROR - 2011-09-06 10:13:17 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-06 10:14:06 --> Config Class Initialized
DEBUG - 2011-09-06 10:14:06 --> Hooks Class Initialized
DEBUG - 2011-09-06 10:14:06 --> Utf8 Class Initialized
DEBUG - 2011-09-06 10:14:06 --> UTF-8 Support Enabled
DEBUG - 2011-09-06 10:14:06 --> URI Class Initialized
DEBUG - 2011-09-06 10:14:06 --> Router Class Initialized
DEBUG - 2011-09-06 10:14:06 --> Output Class Initialized
DEBUG - 2011-09-06 10:14:06 --> Input Class Initialized
DEBUG - 2011-09-06 10:14:06 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-06 10:14:06 --> Language Class Initialized
DEBUG - 2011-09-06 10:14:06 --> Loader Class Initialized
DEBUG - 2011-09-06 10:14:06 --> Controller Class Initialized
ERROR - 2011-09-06 10:14:06 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-06 10:14:06 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-06 10:14:06 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-06 10:14:06 --> Model Class Initialized
DEBUG - 2011-09-06 10:14:06 --> Model Class Initialized
DEBUG - 2011-09-06 10:14:06 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-06 10:14:06 --> Database Driver Class Initialized
DEBUG - 2011-09-06 10:14:06 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-06 10:14:06 --> Helper loaded: url_helper
DEBUG - 2011-09-06 10:14:06 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-06 10:14:06 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-06 10:14:06 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-06 10:14:06 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-06 10:14:06 --> Final output sent to browser
DEBUG - 2011-09-06 10:14:06 --> Total execution time: 0.0344
DEBUG - 2011-09-06 10:14:07 --> Config Class Initialized
DEBUG - 2011-09-06 10:14:07 --> Hooks Class Initialized
DEBUG - 2011-09-06 10:14:07 --> Utf8 Class Initialized
DEBUG - 2011-09-06 10:14:07 --> UTF-8 Support Enabled
DEBUG - 2011-09-06 10:14:07 --> URI Class Initialized
DEBUG - 2011-09-06 10:14:07 --> Router Class Initialized
DEBUG - 2011-09-06 10:14:07 --> Output Class Initialized
DEBUG - 2011-09-06 10:14:07 --> Input Class Initialized
DEBUG - 2011-09-06 10:14:07 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-06 10:14:07 --> Language Class Initialized
DEBUG - 2011-09-06 10:14:07 --> Loader Class Initialized
DEBUG - 2011-09-06 10:14:07 --> Controller Class Initialized
DEBUG - 2011-09-06 10:14:07 --> Model Class Initialized
DEBUG - 2011-09-06 10:14:07 --> Model Class Initialized
DEBUG - 2011-09-06 10:14:07 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-06 10:14:07 --> Database Driver Class Initialized
DEBUG - 2011-09-06 10:14:08 --> Final output sent to browser
DEBUG - 2011-09-06 10:14:08 --> Total execution time: 0.6061
DEBUG - 2011-09-06 10:14:09 --> Config Class Initialized
DEBUG - 2011-09-06 10:14:09 --> Hooks Class Initialized
DEBUG - 2011-09-06 10:14:09 --> Utf8 Class Initialized
DEBUG - 2011-09-06 10:14:09 --> UTF-8 Support Enabled
DEBUG - 2011-09-06 10:14:09 --> URI Class Initialized
DEBUG - 2011-09-06 10:14:09 --> Router Class Initialized
ERROR - 2011-09-06 10:14:09 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-06 10:14:29 --> Config Class Initialized
DEBUG - 2011-09-06 10:14:29 --> Hooks Class Initialized
DEBUG - 2011-09-06 10:14:29 --> Utf8 Class Initialized
DEBUG - 2011-09-06 10:14:29 --> UTF-8 Support Enabled
DEBUG - 2011-09-06 10:14:29 --> URI Class Initialized
DEBUG - 2011-09-06 10:14:29 --> Router Class Initialized
DEBUG - 2011-09-06 10:14:29 --> Output Class Initialized
DEBUG - 2011-09-06 10:14:29 --> Input Class Initialized
DEBUG - 2011-09-06 10:14:29 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-06 10:14:29 --> Language Class Initialized
DEBUG - 2011-09-06 10:14:29 --> Loader Class Initialized
DEBUG - 2011-09-06 10:14:29 --> Controller Class Initialized
ERROR - 2011-09-06 10:14:29 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-06 10:14:29 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-06 10:14:29 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-06 10:14:29 --> Model Class Initialized
DEBUG - 2011-09-06 10:14:29 --> Model Class Initialized
DEBUG - 2011-09-06 10:14:29 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-06 10:14:29 --> Database Driver Class Initialized
DEBUG - 2011-09-06 10:14:29 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-06 10:14:29 --> Helper loaded: url_helper
DEBUG - 2011-09-06 10:14:29 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-06 10:14:29 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-06 10:14:29 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-06 10:14:29 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-06 10:14:29 --> Final output sent to browser
DEBUG - 2011-09-06 10:14:29 --> Total execution time: 0.0290
DEBUG - 2011-09-06 10:14:30 --> Config Class Initialized
DEBUG - 2011-09-06 10:14:30 --> Hooks Class Initialized
DEBUG - 2011-09-06 10:14:30 --> Utf8 Class Initialized
DEBUG - 2011-09-06 10:14:30 --> UTF-8 Support Enabled
DEBUG - 2011-09-06 10:14:30 --> URI Class Initialized
DEBUG - 2011-09-06 10:14:30 --> Router Class Initialized
DEBUG - 2011-09-06 10:14:30 --> Output Class Initialized
DEBUG - 2011-09-06 10:14:30 --> Input Class Initialized
DEBUG - 2011-09-06 10:14:30 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-06 10:14:30 --> Language Class Initialized
DEBUG - 2011-09-06 10:14:30 --> Loader Class Initialized
DEBUG - 2011-09-06 10:14:30 --> Controller Class Initialized
DEBUG - 2011-09-06 10:14:30 --> Model Class Initialized
DEBUG - 2011-09-06 10:14:30 --> Model Class Initialized
DEBUG - 2011-09-06 10:14:30 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-06 10:14:30 --> Database Driver Class Initialized
DEBUG - 2011-09-06 10:14:31 --> Final output sent to browser
DEBUG - 2011-09-06 10:14:31 --> Total execution time: 0.6651
DEBUG - 2011-09-06 10:14:32 --> Config Class Initialized
DEBUG - 2011-09-06 10:14:32 --> Hooks Class Initialized
DEBUG - 2011-09-06 10:14:32 --> Utf8 Class Initialized
DEBUG - 2011-09-06 10:14:32 --> UTF-8 Support Enabled
DEBUG - 2011-09-06 10:14:32 --> URI Class Initialized
DEBUG - 2011-09-06 10:14:32 --> Router Class Initialized
ERROR - 2011-09-06 10:14:32 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-06 10:14:43 --> Config Class Initialized
DEBUG - 2011-09-06 10:14:43 --> Hooks Class Initialized
DEBUG - 2011-09-06 10:14:43 --> Utf8 Class Initialized
DEBUG - 2011-09-06 10:14:43 --> UTF-8 Support Enabled
DEBUG - 2011-09-06 10:14:43 --> URI Class Initialized
DEBUG - 2011-09-06 10:14:43 --> Router Class Initialized
DEBUG - 2011-09-06 10:14:43 --> Output Class Initialized
DEBUG - 2011-09-06 10:14:43 --> Input Class Initialized
DEBUG - 2011-09-06 10:14:43 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-06 10:14:43 --> Language Class Initialized
DEBUG - 2011-09-06 10:14:43 --> Loader Class Initialized
DEBUG - 2011-09-06 10:14:43 --> Controller Class Initialized
ERROR - 2011-09-06 10:14:43 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-06 10:14:43 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-06 10:14:43 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-06 10:14:43 --> Model Class Initialized
DEBUG - 2011-09-06 10:14:43 --> Model Class Initialized
DEBUG - 2011-09-06 10:14:43 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-06 10:14:43 --> Database Driver Class Initialized
DEBUG - 2011-09-06 10:14:43 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-06 10:14:43 --> Helper loaded: url_helper
DEBUG - 2011-09-06 10:14:43 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-06 10:14:43 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-06 10:14:43 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-06 10:14:43 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-06 10:14:43 --> Final output sent to browser
DEBUG - 2011-09-06 10:14:43 --> Total execution time: 0.0318
DEBUG - 2011-09-06 10:14:44 --> Config Class Initialized
DEBUG - 2011-09-06 10:14:44 --> Hooks Class Initialized
DEBUG - 2011-09-06 10:14:44 --> Utf8 Class Initialized
DEBUG - 2011-09-06 10:14:44 --> UTF-8 Support Enabled
DEBUG - 2011-09-06 10:14:44 --> URI Class Initialized
DEBUG - 2011-09-06 10:14:44 --> Router Class Initialized
DEBUG - 2011-09-06 10:14:44 --> Output Class Initialized
DEBUG - 2011-09-06 10:14:44 --> Input Class Initialized
DEBUG - 2011-09-06 10:14:44 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-06 10:14:44 --> Language Class Initialized
DEBUG - 2011-09-06 10:14:44 --> Loader Class Initialized
DEBUG - 2011-09-06 10:14:44 --> Controller Class Initialized
DEBUG - 2011-09-06 10:14:44 --> Model Class Initialized
DEBUG - 2011-09-06 10:14:44 --> Model Class Initialized
DEBUG - 2011-09-06 10:14:44 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-06 10:14:44 --> Database Driver Class Initialized
DEBUG - 2011-09-06 10:14:44 --> Final output sent to browser
DEBUG - 2011-09-06 10:14:44 --> Total execution time: 0.6268
DEBUG - 2011-09-06 10:14:46 --> Config Class Initialized
DEBUG - 2011-09-06 10:14:46 --> Hooks Class Initialized
DEBUG - 2011-09-06 10:14:46 --> Utf8 Class Initialized
DEBUG - 2011-09-06 10:14:46 --> UTF-8 Support Enabled
DEBUG - 2011-09-06 10:14:46 --> URI Class Initialized
DEBUG - 2011-09-06 10:14:46 --> Router Class Initialized
ERROR - 2011-09-06 10:14:46 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-06 10:14:50 --> Config Class Initialized
DEBUG - 2011-09-06 10:14:50 --> Hooks Class Initialized
DEBUG - 2011-09-06 10:14:50 --> Utf8 Class Initialized
DEBUG - 2011-09-06 10:14:50 --> UTF-8 Support Enabled
DEBUG - 2011-09-06 10:14:50 --> URI Class Initialized
DEBUG - 2011-09-06 10:14:50 --> Router Class Initialized
DEBUG - 2011-09-06 10:14:50 --> Output Class Initialized
DEBUG - 2011-09-06 10:14:50 --> Input Class Initialized
DEBUG - 2011-09-06 10:14:50 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-06 10:14:50 --> Language Class Initialized
DEBUG - 2011-09-06 10:14:50 --> Loader Class Initialized
DEBUG - 2011-09-06 10:14:50 --> Controller Class Initialized
ERROR - 2011-09-06 10:14:50 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-06 10:14:50 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-06 10:14:50 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-06 10:14:50 --> Model Class Initialized
DEBUG - 2011-09-06 10:14:50 --> Model Class Initialized
DEBUG - 2011-09-06 10:14:50 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-06 10:14:50 --> Database Driver Class Initialized
DEBUG - 2011-09-06 10:14:50 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-06 10:14:50 --> Helper loaded: url_helper
DEBUG - 2011-09-06 10:14:50 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-06 10:14:50 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-06 10:14:50 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-06 10:14:50 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-06 10:14:50 --> Final output sent to browser
DEBUG - 2011-09-06 10:14:50 --> Total execution time: 0.0351
DEBUG - 2011-09-06 10:14:52 --> Config Class Initialized
DEBUG - 2011-09-06 10:14:52 --> Hooks Class Initialized
DEBUG - 2011-09-06 10:14:52 --> Utf8 Class Initialized
DEBUG - 2011-09-06 10:14:52 --> UTF-8 Support Enabled
DEBUG - 2011-09-06 10:14:52 --> URI Class Initialized
DEBUG - 2011-09-06 10:14:52 --> Router Class Initialized
DEBUG - 2011-09-06 10:14:52 --> Output Class Initialized
DEBUG - 2011-09-06 10:14:52 --> Input Class Initialized
DEBUG - 2011-09-06 10:14:52 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-06 10:14:52 --> Language Class Initialized
DEBUG - 2011-09-06 10:14:52 --> Loader Class Initialized
DEBUG - 2011-09-06 10:14:52 --> Controller Class Initialized
DEBUG - 2011-09-06 10:14:52 --> Model Class Initialized
DEBUG - 2011-09-06 10:14:52 --> Model Class Initialized
DEBUG - 2011-09-06 10:14:52 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-06 10:14:52 --> Database Driver Class Initialized
DEBUG - 2011-09-06 10:14:52 --> Final output sent to browser
DEBUG - 2011-09-06 10:14:52 --> Total execution time: 0.5495
DEBUG - 2011-09-06 10:14:54 --> Config Class Initialized
DEBUG - 2011-09-06 10:14:54 --> Hooks Class Initialized
DEBUG - 2011-09-06 10:14:54 --> Utf8 Class Initialized
DEBUG - 2011-09-06 10:14:54 --> UTF-8 Support Enabled
DEBUG - 2011-09-06 10:14:54 --> URI Class Initialized
DEBUG - 2011-09-06 10:14:54 --> Router Class Initialized
ERROR - 2011-09-06 10:14:54 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-06 10:30:50 --> Config Class Initialized
DEBUG - 2011-09-06 10:30:50 --> Hooks Class Initialized
DEBUG - 2011-09-06 10:30:50 --> Utf8 Class Initialized
DEBUG - 2011-09-06 10:30:50 --> UTF-8 Support Enabled
DEBUG - 2011-09-06 10:30:50 --> URI Class Initialized
DEBUG - 2011-09-06 10:30:50 --> Router Class Initialized
DEBUG - 2011-09-06 10:30:50 --> Output Class Initialized
DEBUG - 2011-09-06 10:30:50 --> Input Class Initialized
DEBUG - 2011-09-06 10:30:50 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-06 10:30:50 --> Language Class Initialized
DEBUG - 2011-09-06 10:30:50 --> Loader Class Initialized
DEBUG - 2011-09-06 10:30:50 --> Controller Class Initialized
DEBUG - 2011-09-06 10:30:50 --> Model Class Initialized
DEBUG - 2011-09-06 10:30:50 --> Model Class Initialized
DEBUG - 2011-09-06 10:30:50 --> Model Class Initialized
DEBUG - 2011-09-06 10:30:50 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-06 10:30:50 --> Database Driver Class Initialized
DEBUG - 2011-09-06 10:30:50 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-06 10:30:50 --> Helper loaded: url_helper
DEBUG - 2011-09-06 10:30:50 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-06 10:30:50 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-06 10:30:50 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-06 10:30:50 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-06 10:30:50 --> Final output sent to browser
DEBUG - 2011-09-06 10:30:50 --> Total execution time: 0.0618
DEBUG - 2011-09-06 10:30:52 --> Config Class Initialized
DEBUG - 2011-09-06 10:30:52 --> Hooks Class Initialized
DEBUG - 2011-09-06 10:30:52 --> Utf8 Class Initialized
DEBUG - 2011-09-06 10:30:52 --> UTF-8 Support Enabled
DEBUG - 2011-09-06 10:30:52 --> URI Class Initialized
DEBUG - 2011-09-06 10:30:52 --> Router Class Initialized
ERROR - 2011-09-06 10:30:52 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-06 11:24:55 --> Config Class Initialized
DEBUG - 2011-09-06 11:24:55 --> Hooks Class Initialized
DEBUG - 2011-09-06 11:24:55 --> Utf8 Class Initialized
DEBUG - 2011-09-06 11:24:55 --> UTF-8 Support Enabled
DEBUG - 2011-09-06 11:24:55 --> URI Class Initialized
DEBUG - 2011-09-06 11:24:55 --> Router Class Initialized
DEBUG - 2011-09-06 11:24:55 --> Output Class Initialized
DEBUG - 2011-09-06 11:24:55 --> Input Class Initialized
DEBUG - 2011-09-06 11:24:55 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-06 11:24:55 --> Language Class Initialized
DEBUG - 2011-09-06 11:24:56 --> Loader Class Initialized
DEBUG - 2011-09-06 11:24:56 --> Controller Class Initialized
ERROR - 2011-09-06 11:24:56 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-06 11:24:56 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-06 11:24:56 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-06 11:24:56 --> Model Class Initialized
DEBUG - 2011-09-06 11:24:56 --> Model Class Initialized
DEBUG - 2011-09-06 11:24:56 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-06 11:24:56 --> Database Driver Class Initialized
DEBUG - 2011-09-06 11:24:56 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-06 11:24:56 --> Helper loaded: url_helper
DEBUG - 2011-09-06 11:24:56 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-06 11:24:56 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-06 11:24:56 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-06 11:24:56 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-06 11:24:56 --> Final output sent to browser
DEBUG - 2011-09-06 11:24:56 --> Total execution time: 0.1549
DEBUG - 2011-09-06 11:24:57 --> Config Class Initialized
DEBUG - 2011-09-06 11:24:57 --> Hooks Class Initialized
DEBUG - 2011-09-06 11:24:57 --> Utf8 Class Initialized
DEBUG - 2011-09-06 11:24:57 --> UTF-8 Support Enabled
DEBUG - 2011-09-06 11:24:57 --> URI Class Initialized
DEBUG - 2011-09-06 11:24:57 --> Router Class Initialized
DEBUG - 2011-09-06 11:24:57 --> Output Class Initialized
DEBUG - 2011-09-06 11:24:57 --> Input Class Initialized
DEBUG - 2011-09-06 11:24:57 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-06 11:24:57 --> Language Class Initialized
DEBUG - 2011-09-06 11:24:57 --> Loader Class Initialized
DEBUG - 2011-09-06 11:24:57 --> Controller Class Initialized
DEBUG - 2011-09-06 11:24:57 --> Model Class Initialized
DEBUG - 2011-09-06 11:24:57 --> Model Class Initialized
DEBUG - 2011-09-06 11:24:57 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-06 11:24:57 --> Database Driver Class Initialized
DEBUG - 2011-09-06 11:24:58 --> Final output sent to browser
DEBUG - 2011-09-06 11:24:58 --> Total execution time: 1.0391
DEBUG - 2011-09-06 11:24:59 --> Config Class Initialized
DEBUG - 2011-09-06 11:24:59 --> Hooks Class Initialized
DEBUG - 2011-09-06 11:24:59 --> Utf8 Class Initialized
DEBUG - 2011-09-06 11:24:59 --> UTF-8 Support Enabled
DEBUG - 2011-09-06 11:24:59 --> URI Class Initialized
DEBUG - 2011-09-06 11:24:59 --> Router Class Initialized
ERROR - 2011-09-06 11:24:59 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-06 11:25:01 --> Config Class Initialized
DEBUG - 2011-09-06 11:25:01 --> Hooks Class Initialized
DEBUG - 2011-09-06 11:25:01 --> Utf8 Class Initialized
DEBUG - 2011-09-06 11:25:01 --> UTF-8 Support Enabled
DEBUG - 2011-09-06 11:25:01 --> URI Class Initialized
DEBUG - 2011-09-06 11:25:01 --> Router Class Initialized
ERROR - 2011-09-06 11:25:01 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-06 11:25:06 --> Config Class Initialized
DEBUG - 2011-09-06 11:25:06 --> Hooks Class Initialized
DEBUG - 2011-09-06 11:25:06 --> Utf8 Class Initialized
DEBUG - 2011-09-06 11:25:06 --> UTF-8 Support Enabled
DEBUG - 2011-09-06 11:25:06 --> URI Class Initialized
DEBUG - 2011-09-06 11:25:06 --> Router Class Initialized
DEBUG - 2011-09-06 11:25:06 --> Output Class Initialized
DEBUG - 2011-09-06 11:25:06 --> Input Class Initialized
DEBUG - 2011-09-06 11:25:06 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-06 11:25:06 --> Language Class Initialized
DEBUG - 2011-09-06 11:25:06 --> Loader Class Initialized
DEBUG - 2011-09-06 11:25:06 --> Controller Class Initialized
ERROR - 2011-09-06 11:25:06 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-06 11:25:06 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-06 11:25:06 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-06 11:25:06 --> Model Class Initialized
DEBUG - 2011-09-06 11:25:06 --> Model Class Initialized
DEBUG - 2011-09-06 11:25:06 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-06 11:25:06 --> Database Driver Class Initialized
DEBUG - 2011-09-06 11:25:06 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-06 11:25:06 --> Helper loaded: url_helper
DEBUG - 2011-09-06 11:25:06 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-06 11:25:06 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-06 11:25:06 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-06 11:25:06 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-06 11:25:06 --> Final output sent to browser
DEBUG - 2011-09-06 11:25:06 --> Total execution time: 0.0430
DEBUG - 2011-09-06 11:25:07 --> Config Class Initialized
DEBUG - 2011-09-06 11:25:07 --> Hooks Class Initialized
DEBUG - 2011-09-06 11:25:07 --> Utf8 Class Initialized
DEBUG - 2011-09-06 11:25:07 --> UTF-8 Support Enabled
DEBUG - 2011-09-06 11:25:07 --> URI Class Initialized
DEBUG - 2011-09-06 11:25:07 --> Router Class Initialized
DEBUG - 2011-09-06 11:25:07 --> Output Class Initialized
DEBUG - 2011-09-06 11:25:07 --> Input Class Initialized
DEBUG - 2011-09-06 11:25:07 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-06 11:25:07 --> Language Class Initialized
DEBUG - 2011-09-06 11:25:07 --> Loader Class Initialized
DEBUG - 2011-09-06 11:25:07 --> Controller Class Initialized
DEBUG - 2011-09-06 11:25:07 --> Model Class Initialized
DEBUG - 2011-09-06 11:25:07 --> Model Class Initialized
DEBUG - 2011-09-06 11:25:07 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-06 11:25:07 --> Database Driver Class Initialized
DEBUG - 2011-09-06 11:25:08 --> Final output sent to browser
DEBUG - 2011-09-06 11:25:08 --> Total execution time: 0.5221
DEBUG - 2011-09-06 11:25:25 --> Config Class Initialized
DEBUG - 2011-09-06 11:25:25 --> Hooks Class Initialized
DEBUG - 2011-09-06 11:25:25 --> Utf8 Class Initialized
DEBUG - 2011-09-06 11:25:25 --> UTF-8 Support Enabled
DEBUG - 2011-09-06 11:25:25 --> URI Class Initialized
DEBUG - 2011-09-06 11:25:25 --> Router Class Initialized
DEBUG - 2011-09-06 11:25:25 --> Output Class Initialized
DEBUG - 2011-09-06 11:25:25 --> Input Class Initialized
DEBUG - 2011-09-06 11:25:25 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-06 11:25:25 --> Language Class Initialized
DEBUG - 2011-09-06 11:25:25 --> Loader Class Initialized
DEBUG - 2011-09-06 11:25:25 --> Controller Class Initialized
DEBUG - 2011-09-06 11:25:25 --> Model Class Initialized
DEBUG - 2011-09-06 11:25:25 --> Model Class Initialized
DEBUG - 2011-09-06 11:25:25 --> Model Class Initialized
DEBUG - 2011-09-06 11:25:25 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-06 11:25:25 --> Database Driver Class Initialized
DEBUG - 2011-09-06 11:25:26 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-06 11:25:26 --> Helper loaded: url_helper
DEBUG - 2011-09-06 11:25:26 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-06 11:25:26 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-06 11:25:26 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-06 11:25:26 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-06 11:25:26 --> Final output sent to browser
DEBUG - 2011-09-06 11:25:26 --> Total execution time: 0.4471
DEBUG - 2011-09-06 11:25:35 --> Config Class Initialized
DEBUG - 2011-09-06 11:25:35 --> Hooks Class Initialized
DEBUG - 2011-09-06 11:25:35 --> Utf8 Class Initialized
DEBUG - 2011-09-06 11:25:35 --> UTF-8 Support Enabled
DEBUG - 2011-09-06 11:25:35 --> URI Class Initialized
DEBUG - 2011-09-06 11:25:35 --> Router Class Initialized
DEBUG - 2011-09-06 11:25:35 --> Output Class Initialized
DEBUG - 2011-09-06 11:25:35 --> Input Class Initialized
DEBUG - 2011-09-06 11:25:35 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-06 11:25:35 --> Language Class Initialized
DEBUG - 2011-09-06 11:25:35 --> Loader Class Initialized
DEBUG - 2011-09-06 11:25:35 --> Controller Class Initialized
DEBUG - 2011-09-06 11:25:35 --> Model Class Initialized
DEBUG - 2011-09-06 11:25:35 --> Model Class Initialized
DEBUG - 2011-09-06 11:25:35 --> Model Class Initialized
DEBUG - 2011-09-06 11:25:35 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-06 11:25:35 --> Database Driver Class Initialized
DEBUG - 2011-09-06 11:25:35 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-06 11:25:35 --> Helper loaded: url_helper
DEBUG - 2011-09-06 11:25:35 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-06 11:25:35 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-06 11:25:35 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-06 11:25:35 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-06 11:25:35 --> Final output sent to browser
DEBUG - 2011-09-06 11:25:35 --> Total execution time: 0.1202
DEBUG - 2011-09-06 11:25:38 --> Config Class Initialized
DEBUG - 2011-09-06 11:25:38 --> Hooks Class Initialized
DEBUG - 2011-09-06 11:25:38 --> Utf8 Class Initialized
DEBUG - 2011-09-06 11:25:38 --> UTF-8 Support Enabled
DEBUG - 2011-09-06 11:25:38 --> URI Class Initialized
DEBUG - 2011-09-06 11:25:38 --> Router Class Initialized
ERROR - 2011-09-06 11:25:38 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-06 11:26:07 --> Config Class Initialized
DEBUG - 2011-09-06 11:26:07 --> Hooks Class Initialized
DEBUG - 2011-09-06 11:26:07 --> Utf8 Class Initialized
DEBUG - 2011-09-06 11:26:07 --> UTF-8 Support Enabled
DEBUG - 2011-09-06 11:26:07 --> URI Class Initialized
DEBUG - 2011-09-06 11:26:07 --> Router Class Initialized
DEBUG - 2011-09-06 11:26:07 --> Output Class Initialized
DEBUG - 2011-09-06 11:26:07 --> Input Class Initialized
DEBUG - 2011-09-06 11:26:07 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-06 11:26:07 --> Language Class Initialized
DEBUG - 2011-09-06 11:26:07 --> Loader Class Initialized
DEBUG - 2011-09-06 11:26:07 --> Controller Class Initialized
DEBUG - 2011-09-06 11:26:07 --> Model Class Initialized
DEBUG - 2011-09-06 11:26:07 --> Model Class Initialized
DEBUG - 2011-09-06 11:26:07 --> Model Class Initialized
DEBUG - 2011-09-06 11:26:07 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-06 11:26:07 --> Database Driver Class Initialized
DEBUG - 2011-09-06 11:26:08 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-06 11:26:08 --> Helper loaded: url_helper
DEBUG - 2011-09-06 11:26:08 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-06 11:26:08 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-06 11:26:08 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-06 11:26:08 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-06 11:26:08 --> Final output sent to browser
DEBUG - 2011-09-06 11:26:08 --> Total execution time: 0.6819
DEBUG - 2011-09-06 11:26:09 --> Config Class Initialized
DEBUG - 2011-09-06 11:26:09 --> Hooks Class Initialized
DEBUG - 2011-09-06 11:26:09 --> Utf8 Class Initialized
DEBUG - 2011-09-06 11:26:09 --> UTF-8 Support Enabled
DEBUG - 2011-09-06 11:26:09 --> URI Class Initialized
DEBUG - 2011-09-06 11:26:09 --> Router Class Initialized
DEBUG - 2011-09-06 11:26:09 --> Output Class Initialized
DEBUG - 2011-09-06 11:26:09 --> Input Class Initialized
DEBUG - 2011-09-06 11:26:09 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-06 11:26:09 --> Language Class Initialized
DEBUG - 2011-09-06 11:26:09 --> Loader Class Initialized
DEBUG - 2011-09-06 11:26:09 --> Controller Class Initialized
DEBUG - 2011-09-06 11:26:09 --> Model Class Initialized
DEBUG - 2011-09-06 11:26:09 --> Model Class Initialized
DEBUG - 2011-09-06 11:26:09 --> Model Class Initialized
DEBUG - 2011-09-06 11:26:09 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-06 11:26:09 --> Database Driver Class Initialized
DEBUG - 2011-09-06 11:26:09 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-06 11:26:09 --> Helper loaded: url_helper
DEBUG - 2011-09-06 11:26:09 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-06 11:26:09 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-06 11:26:09 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-06 11:26:09 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-06 11:26:09 --> Final output sent to browser
DEBUG - 2011-09-06 11:26:09 --> Total execution time: 0.0501
DEBUG - 2011-09-06 11:26:19 --> Config Class Initialized
DEBUG - 2011-09-06 11:26:19 --> Hooks Class Initialized
DEBUG - 2011-09-06 11:26:19 --> Utf8 Class Initialized
DEBUG - 2011-09-06 11:26:19 --> UTF-8 Support Enabled
DEBUG - 2011-09-06 11:26:19 --> URI Class Initialized
DEBUG - 2011-09-06 11:26:19 --> Router Class Initialized
DEBUG - 2011-09-06 11:26:19 --> Output Class Initialized
DEBUG - 2011-09-06 11:26:19 --> Input Class Initialized
DEBUG - 2011-09-06 11:26:19 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-06 11:26:19 --> Language Class Initialized
DEBUG - 2011-09-06 11:26:19 --> Loader Class Initialized
DEBUG - 2011-09-06 11:26:19 --> Controller Class Initialized
DEBUG - 2011-09-06 11:26:19 --> Model Class Initialized
DEBUG - 2011-09-06 11:26:19 --> Model Class Initialized
DEBUG - 2011-09-06 11:26:19 --> Model Class Initialized
DEBUG - 2011-09-06 11:26:19 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-06 11:26:19 --> Database Driver Class Initialized
DEBUG - 2011-09-06 11:26:20 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-06 11:26:20 --> Helper loaded: url_helper
DEBUG - 2011-09-06 11:26:20 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-06 11:26:20 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-06 11:26:20 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-06 11:26:20 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-06 11:26:20 --> Final output sent to browser
DEBUG - 2011-09-06 11:26:20 --> Total execution time: 0.4833
DEBUG - 2011-09-06 11:26:21 --> Config Class Initialized
DEBUG - 2011-09-06 11:26:21 --> Hooks Class Initialized
DEBUG - 2011-09-06 11:26:21 --> Utf8 Class Initialized
DEBUG - 2011-09-06 11:26:21 --> UTF-8 Support Enabled
DEBUG - 2011-09-06 11:26:21 --> URI Class Initialized
DEBUG - 2011-09-06 11:26:21 --> Router Class Initialized
DEBUG - 2011-09-06 11:26:21 --> Output Class Initialized
DEBUG - 2011-09-06 11:26:21 --> Input Class Initialized
DEBUG - 2011-09-06 11:26:21 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-06 11:26:21 --> Language Class Initialized
DEBUG - 2011-09-06 11:26:21 --> Loader Class Initialized
DEBUG - 2011-09-06 11:26:21 --> Controller Class Initialized
DEBUG - 2011-09-06 11:26:21 --> Model Class Initialized
DEBUG - 2011-09-06 11:26:21 --> Model Class Initialized
DEBUG - 2011-09-06 11:26:21 --> Model Class Initialized
DEBUG - 2011-09-06 11:26:21 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-06 11:26:21 --> Database Driver Class Initialized
DEBUG - 2011-09-06 11:26:21 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-06 11:26:21 --> Helper loaded: url_helper
DEBUG - 2011-09-06 11:26:21 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-06 11:26:21 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-06 11:26:21 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-06 11:26:21 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-06 11:26:21 --> Final output sent to browser
DEBUG - 2011-09-06 11:26:21 --> Total execution time: 0.1265
DEBUG - 2011-09-06 11:26:35 --> Config Class Initialized
DEBUG - 2011-09-06 11:26:35 --> Hooks Class Initialized
DEBUG - 2011-09-06 11:26:35 --> Utf8 Class Initialized
DEBUG - 2011-09-06 11:26:35 --> UTF-8 Support Enabled
DEBUG - 2011-09-06 11:26:35 --> URI Class Initialized
DEBUG - 2011-09-06 11:26:35 --> Router Class Initialized
DEBUG - 2011-09-06 11:26:35 --> Output Class Initialized
DEBUG - 2011-09-06 11:26:35 --> Input Class Initialized
DEBUG - 2011-09-06 11:26:35 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-06 11:26:35 --> Language Class Initialized
DEBUG - 2011-09-06 11:26:35 --> Loader Class Initialized
DEBUG - 2011-09-06 11:26:35 --> Controller Class Initialized
DEBUG - 2011-09-06 11:26:35 --> Model Class Initialized
DEBUG - 2011-09-06 11:26:35 --> Model Class Initialized
DEBUG - 2011-09-06 11:26:35 --> Model Class Initialized
DEBUG - 2011-09-06 11:26:35 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-06 11:26:35 --> Database Driver Class Initialized
DEBUG - 2011-09-06 11:26:35 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-06 11:26:35 --> Helper loaded: url_helper
DEBUG - 2011-09-06 11:26:35 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-06 11:26:35 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-06 11:26:35 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-06 11:26:35 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-06 11:26:35 --> Final output sent to browser
DEBUG - 2011-09-06 11:26:35 --> Total execution time: 0.3239
DEBUG - 2011-09-06 11:26:37 --> Config Class Initialized
DEBUG - 2011-09-06 11:26:37 --> Hooks Class Initialized
DEBUG - 2011-09-06 11:26:37 --> Utf8 Class Initialized
DEBUG - 2011-09-06 11:26:37 --> UTF-8 Support Enabled
DEBUG - 2011-09-06 11:26:37 --> URI Class Initialized
DEBUG - 2011-09-06 11:26:37 --> Router Class Initialized
DEBUG - 2011-09-06 11:26:37 --> Output Class Initialized
DEBUG - 2011-09-06 11:26:37 --> Input Class Initialized
DEBUG - 2011-09-06 11:26:37 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-06 11:26:37 --> Language Class Initialized
DEBUG - 2011-09-06 11:26:37 --> Loader Class Initialized
DEBUG - 2011-09-06 11:26:37 --> Controller Class Initialized
DEBUG - 2011-09-06 11:26:37 --> Model Class Initialized
DEBUG - 2011-09-06 11:26:37 --> Model Class Initialized
DEBUG - 2011-09-06 11:26:37 --> Model Class Initialized
DEBUG - 2011-09-06 11:26:37 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-06 11:26:37 --> Database Driver Class Initialized
DEBUG - 2011-09-06 11:26:37 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-06 11:26:37 --> Helper loaded: url_helper
DEBUG - 2011-09-06 11:26:37 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-06 11:26:37 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-06 11:26:37 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-06 11:26:37 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-06 11:26:37 --> Final output sent to browser
DEBUG - 2011-09-06 11:26:37 --> Total execution time: 0.0481
DEBUG - 2011-09-06 11:38:57 --> Config Class Initialized
DEBUG - 2011-09-06 11:38:57 --> Hooks Class Initialized
DEBUG - 2011-09-06 11:38:57 --> Utf8 Class Initialized
DEBUG - 2011-09-06 11:38:57 --> UTF-8 Support Enabled
DEBUG - 2011-09-06 11:38:57 --> URI Class Initialized
DEBUG - 2011-09-06 11:38:57 --> Router Class Initialized
ERROR - 2011-09-06 11:38:57 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-09-06 11:38:57 --> Config Class Initialized
DEBUG - 2011-09-06 11:38:57 --> Hooks Class Initialized
DEBUG - 2011-09-06 11:38:57 --> Utf8 Class Initialized
DEBUG - 2011-09-06 11:38:57 --> UTF-8 Support Enabled
DEBUG - 2011-09-06 11:38:57 --> URI Class Initialized
DEBUG - 2011-09-06 11:38:57 --> Router Class Initialized
DEBUG - 2011-09-06 11:38:57 --> Output Class Initialized
DEBUG - 2011-09-06 11:38:57 --> Input Class Initialized
DEBUG - 2011-09-06 11:38:57 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-06 11:38:57 --> Language Class Initialized
DEBUG - 2011-09-06 11:38:57 --> Loader Class Initialized
DEBUG - 2011-09-06 11:38:57 --> Controller Class Initialized
ERROR - 2011-09-06 11:38:57 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-06 11:38:57 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-06 11:38:57 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-06 11:38:57 --> Model Class Initialized
DEBUG - 2011-09-06 11:38:57 --> Model Class Initialized
DEBUG - 2011-09-06 11:38:57 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-06 11:38:57 --> Database Driver Class Initialized
DEBUG - 2011-09-06 11:38:57 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-06 11:38:57 --> Helper loaded: url_helper
DEBUG - 2011-09-06 11:38:57 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-06 11:38:57 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-06 11:38:57 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-06 11:38:57 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-06 11:38:57 --> Final output sent to browser
DEBUG - 2011-09-06 11:38:57 --> Total execution time: 0.0292
DEBUG - 2011-09-06 11:54:58 --> Config Class Initialized
DEBUG - 2011-09-06 11:54:58 --> Hooks Class Initialized
DEBUG - 2011-09-06 11:54:58 --> Utf8 Class Initialized
DEBUG - 2011-09-06 11:54:58 --> UTF-8 Support Enabled
DEBUG - 2011-09-06 11:54:58 --> URI Class Initialized
DEBUG - 2011-09-06 11:54:58 --> Router Class Initialized
DEBUG - 2011-09-06 11:54:58 --> Output Class Initialized
DEBUG - 2011-09-06 11:54:58 --> Input Class Initialized
DEBUG - 2011-09-06 11:54:58 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-06 11:54:58 --> Language Class Initialized
DEBUG - 2011-09-06 11:54:58 --> Loader Class Initialized
DEBUG - 2011-09-06 11:54:58 --> Controller Class Initialized
DEBUG - 2011-09-06 11:54:58 --> Model Class Initialized
DEBUG - 2011-09-06 11:54:58 --> Model Class Initialized
DEBUG - 2011-09-06 11:54:58 --> Model Class Initialized
DEBUG - 2011-09-06 11:54:58 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-06 11:54:58 --> Database Driver Class Initialized
DEBUG - 2011-09-06 11:54:59 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-06 11:54:59 --> Helper loaded: url_helper
DEBUG - 2011-09-06 11:54:59 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-06 11:54:59 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-06 11:54:59 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-06 11:54:59 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-06 11:54:59 --> Final output sent to browser
DEBUG - 2011-09-06 11:54:59 --> Total execution time: 1.0275
DEBUG - 2011-09-06 11:55:01 --> Config Class Initialized
DEBUG - 2011-09-06 11:55:01 --> Hooks Class Initialized
DEBUG - 2011-09-06 11:55:01 --> Utf8 Class Initialized
DEBUG - 2011-09-06 11:55:01 --> UTF-8 Support Enabled
DEBUG - 2011-09-06 11:55:01 --> URI Class Initialized
DEBUG - 2011-09-06 11:55:01 --> Router Class Initialized
ERROR - 2011-09-06 11:55:01 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-06 11:57:01 --> Config Class Initialized
DEBUG - 2011-09-06 11:57:01 --> Hooks Class Initialized
DEBUG - 2011-09-06 11:57:01 --> Utf8 Class Initialized
DEBUG - 2011-09-06 11:57:01 --> UTF-8 Support Enabled
DEBUG - 2011-09-06 11:57:01 --> URI Class Initialized
DEBUG - 2011-09-06 11:57:01 --> Router Class Initialized
DEBUG - 2011-09-06 11:57:01 --> Output Class Initialized
DEBUG - 2011-09-06 11:57:01 --> Input Class Initialized
DEBUG - 2011-09-06 11:57:01 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-06 11:57:01 --> Language Class Initialized
DEBUG - 2011-09-06 11:57:01 --> Loader Class Initialized
DEBUG - 2011-09-06 11:57:01 --> Controller Class Initialized
DEBUG - 2011-09-06 11:57:01 --> Model Class Initialized
DEBUG - 2011-09-06 11:57:01 --> Model Class Initialized
DEBUG - 2011-09-06 11:57:01 --> Model Class Initialized
DEBUG - 2011-09-06 11:57:01 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-06 11:57:01 --> Database Driver Class Initialized
DEBUG - 2011-09-06 11:57:01 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-06 11:57:01 --> Helper loaded: url_helper
DEBUG - 2011-09-06 11:57:01 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-06 11:57:01 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-06 11:57:01 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-06 11:57:01 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-06 11:57:01 --> Final output sent to browser
DEBUG - 2011-09-06 11:57:01 --> Total execution time: 0.1494
DEBUG - 2011-09-06 12:14:42 --> Config Class Initialized
DEBUG - 2011-09-06 12:14:42 --> Hooks Class Initialized
DEBUG - 2011-09-06 12:14:42 --> Utf8 Class Initialized
DEBUG - 2011-09-06 12:14:42 --> UTF-8 Support Enabled
DEBUG - 2011-09-06 12:14:42 --> URI Class Initialized
DEBUG - 2011-09-06 12:14:42 --> Router Class Initialized
DEBUG - 2011-09-06 12:14:42 --> Output Class Initialized
DEBUG - 2011-09-06 12:14:42 --> Input Class Initialized
DEBUG - 2011-09-06 12:14:42 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-06 12:14:42 --> Language Class Initialized
DEBUG - 2011-09-06 12:14:42 --> Loader Class Initialized
DEBUG - 2011-09-06 12:14:42 --> Controller Class Initialized
DEBUG - 2011-09-06 12:14:42 --> Model Class Initialized
DEBUG - 2011-09-06 12:14:42 --> Model Class Initialized
DEBUG - 2011-09-06 12:14:42 --> Model Class Initialized
DEBUG - 2011-09-06 12:14:42 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-06 12:14:42 --> Database Driver Class Initialized
DEBUG - 2011-09-06 12:14:42 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-06 12:14:42 --> Helper loaded: url_helper
DEBUG - 2011-09-06 12:14:42 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-06 12:14:42 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-06 12:14:42 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-06 12:14:42 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-06 12:14:42 --> Final output sent to browser
DEBUG - 2011-09-06 12:14:42 --> Total execution time: 0.2897
DEBUG - 2011-09-06 12:14:45 --> Config Class Initialized
DEBUG - 2011-09-06 12:14:45 --> Hooks Class Initialized
DEBUG - 2011-09-06 12:14:45 --> Utf8 Class Initialized
DEBUG - 2011-09-06 12:14:45 --> UTF-8 Support Enabled
DEBUG - 2011-09-06 12:14:45 --> URI Class Initialized
DEBUG - 2011-09-06 12:14:45 --> Router Class Initialized
DEBUG - 2011-09-06 12:14:45 --> Output Class Initialized
DEBUG - 2011-09-06 12:14:45 --> Input Class Initialized
DEBUG - 2011-09-06 12:14:45 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-06 12:14:45 --> Language Class Initialized
DEBUG - 2011-09-06 12:14:45 --> Loader Class Initialized
DEBUG - 2011-09-06 12:14:45 --> Controller Class Initialized
DEBUG - 2011-09-06 12:14:45 --> Model Class Initialized
DEBUG - 2011-09-06 12:14:45 --> Model Class Initialized
DEBUG - 2011-09-06 12:14:45 --> Model Class Initialized
DEBUG - 2011-09-06 12:14:45 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-06 12:14:45 --> Database Driver Class Initialized
DEBUG - 2011-09-06 12:14:45 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-06 12:14:45 --> Helper loaded: url_helper
DEBUG - 2011-09-06 12:14:45 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-06 12:14:45 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-06 12:14:45 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-06 12:14:45 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-06 12:14:45 --> Final output sent to browser
DEBUG - 2011-09-06 12:14:45 --> Total execution time: 0.0461
DEBUG - 2011-09-06 12:14:57 --> Config Class Initialized
DEBUG - 2011-09-06 12:14:57 --> Hooks Class Initialized
DEBUG - 2011-09-06 12:14:57 --> Utf8 Class Initialized
DEBUG - 2011-09-06 12:14:57 --> UTF-8 Support Enabled
DEBUG - 2011-09-06 12:14:57 --> URI Class Initialized
DEBUG - 2011-09-06 12:14:57 --> Router Class Initialized
DEBUG - 2011-09-06 12:14:57 --> Output Class Initialized
DEBUG - 2011-09-06 12:14:57 --> Input Class Initialized
DEBUG - 2011-09-06 12:14:57 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-06 12:14:57 --> Language Class Initialized
DEBUG - 2011-09-06 12:14:57 --> Loader Class Initialized
DEBUG - 2011-09-06 12:14:57 --> Controller Class Initialized
DEBUG - 2011-09-06 12:14:57 --> Model Class Initialized
DEBUG - 2011-09-06 12:14:57 --> Model Class Initialized
DEBUG - 2011-09-06 12:14:57 --> Model Class Initialized
DEBUG - 2011-09-06 12:14:57 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-06 12:14:57 --> Database Driver Class Initialized
DEBUG - 2011-09-06 12:14:57 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-06 12:14:57 --> Helper loaded: url_helper
DEBUG - 2011-09-06 12:14:57 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-06 12:14:57 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-06 12:14:57 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-06 12:14:57 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-06 12:14:57 --> Final output sent to browser
DEBUG - 2011-09-06 12:14:57 --> Total execution time: 0.6105
DEBUG - 2011-09-06 12:15:02 --> Config Class Initialized
DEBUG - 2011-09-06 12:15:02 --> Hooks Class Initialized
DEBUG - 2011-09-06 12:15:02 --> Utf8 Class Initialized
DEBUG - 2011-09-06 12:15:02 --> UTF-8 Support Enabled
DEBUG - 2011-09-06 12:15:02 --> URI Class Initialized
DEBUG - 2011-09-06 12:15:02 --> Router Class Initialized
DEBUG - 2011-09-06 12:15:02 --> Output Class Initialized
DEBUG - 2011-09-06 12:15:02 --> Input Class Initialized
DEBUG - 2011-09-06 12:15:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-06 12:15:02 --> Language Class Initialized
DEBUG - 2011-09-06 12:15:02 --> Loader Class Initialized
DEBUG - 2011-09-06 12:15:02 --> Controller Class Initialized
DEBUG - 2011-09-06 12:15:02 --> Model Class Initialized
DEBUG - 2011-09-06 12:15:02 --> Model Class Initialized
DEBUG - 2011-09-06 12:15:02 --> Model Class Initialized
DEBUG - 2011-09-06 12:15:02 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-06 12:15:02 --> Database Driver Class Initialized
DEBUG - 2011-09-06 12:15:02 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-06 12:15:02 --> Helper loaded: url_helper
DEBUG - 2011-09-06 12:15:02 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-06 12:15:02 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-06 12:15:02 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-06 12:15:02 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-06 12:15:02 --> Final output sent to browser
DEBUG - 2011-09-06 12:15:02 --> Total execution time: 0.3838
DEBUG - 2011-09-06 12:15:22 --> Config Class Initialized
DEBUG - 2011-09-06 12:15:22 --> Hooks Class Initialized
DEBUG - 2011-09-06 12:15:22 --> Utf8 Class Initialized
DEBUG - 2011-09-06 12:15:22 --> UTF-8 Support Enabled
DEBUG - 2011-09-06 12:15:22 --> URI Class Initialized
DEBUG - 2011-09-06 12:15:22 --> Router Class Initialized
DEBUG - 2011-09-06 12:15:22 --> Output Class Initialized
DEBUG - 2011-09-06 12:15:22 --> Input Class Initialized
DEBUG - 2011-09-06 12:15:22 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-06 12:15:22 --> Language Class Initialized
DEBUG - 2011-09-06 12:15:22 --> Loader Class Initialized
DEBUG - 2011-09-06 12:15:22 --> Controller Class Initialized
DEBUG - 2011-09-06 12:15:22 --> Model Class Initialized
DEBUG - 2011-09-06 12:15:22 --> Model Class Initialized
DEBUG - 2011-09-06 12:15:22 --> Model Class Initialized
DEBUG - 2011-09-06 12:15:22 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-06 12:15:22 --> Database Driver Class Initialized
DEBUG - 2011-09-06 12:15:23 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-06 12:15:23 --> Helper loaded: url_helper
DEBUG - 2011-09-06 12:15:23 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-06 12:15:23 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-06 12:15:23 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-06 12:15:23 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-06 12:15:23 --> Final output sent to browser
DEBUG - 2011-09-06 12:15:23 --> Total execution time: 1.3809
DEBUG - 2011-09-06 12:15:25 --> Config Class Initialized
DEBUG - 2011-09-06 12:15:25 --> Hooks Class Initialized
DEBUG - 2011-09-06 12:15:25 --> Utf8 Class Initialized
DEBUG - 2011-09-06 12:15:25 --> UTF-8 Support Enabled
DEBUG - 2011-09-06 12:15:25 --> URI Class Initialized
DEBUG - 2011-09-06 12:15:25 --> Router Class Initialized
DEBUG - 2011-09-06 12:15:25 --> Output Class Initialized
DEBUG - 2011-09-06 12:15:25 --> Input Class Initialized
DEBUG - 2011-09-06 12:15:25 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-06 12:15:25 --> Language Class Initialized
DEBUG - 2011-09-06 12:15:25 --> Loader Class Initialized
DEBUG - 2011-09-06 12:15:25 --> Controller Class Initialized
DEBUG - 2011-09-06 12:15:25 --> Model Class Initialized
DEBUG - 2011-09-06 12:15:25 --> Model Class Initialized
DEBUG - 2011-09-06 12:15:25 --> Model Class Initialized
DEBUG - 2011-09-06 12:15:25 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-06 12:15:25 --> Database Driver Class Initialized
DEBUG - 2011-09-06 12:15:25 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-06 12:15:25 --> Helper loaded: url_helper
DEBUG - 2011-09-06 12:15:25 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-06 12:15:25 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-06 12:15:25 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-06 12:15:25 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-06 12:15:25 --> Final output sent to browser
DEBUG - 2011-09-06 12:15:25 --> Total execution time: 0.3117
DEBUG - 2011-09-06 12:15:36 --> Config Class Initialized
DEBUG - 2011-09-06 12:15:36 --> Hooks Class Initialized
DEBUG - 2011-09-06 12:15:36 --> Utf8 Class Initialized
DEBUG - 2011-09-06 12:15:36 --> UTF-8 Support Enabled
DEBUG - 2011-09-06 12:15:36 --> URI Class Initialized
DEBUG - 2011-09-06 12:15:36 --> Router Class Initialized
DEBUG - 2011-09-06 12:15:36 --> Output Class Initialized
DEBUG - 2011-09-06 12:15:36 --> Input Class Initialized
DEBUG - 2011-09-06 12:15:36 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-06 12:15:36 --> Language Class Initialized
DEBUG - 2011-09-06 12:15:36 --> Loader Class Initialized
DEBUG - 2011-09-06 12:15:36 --> Controller Class Initialized
DEBUG - 2011-09-06 12:15:36 --> Model Class Initialized
DEBUG - 2011-09-06 12:15:36 --> Model Class Initialized
DEBUG - 2011-09-06 12:15:36 --> Model Class Initialized
DEBUG - 2011-09-06 12:15:36 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-06 12:15:37 --> Database Driver Class Initialized
DEBUG - 2011-09-06 12:15:37 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-06 12:15:37 --> Helper loaded: url_helper
DEBUG - 2011-09-06 12:15:37 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-06 12:15:37 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-06 12:15:37 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-06 12:15:37 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-06 12:15:37 --> Final output sent to browser
DEBUG - 2011-09-06 12:15:37 --> Total execution time: 0.9181
DEBUG - 2011-09-06 12:15:45 --> Config Class Initialized
DEBUG - 2011-09-06 12:15:45 --> Hooks Class Initialized
DEBUG - 2011-09-06 12:15:45 --> Utf8 Class Initialized
DEBUG - 2011-09-06 12:15:45 --> UTF-8 Support Enabled
DEBUG - 2011-09-06 12:15:45 --> URI Class Initialized
DEBUG - 2011-09-06 12:15:45 --> Router Class Initialized
DEBUG - 2011-09-06 12:15:45 --> Output Class Initialized
DEBUG - 2011-09-06 12:15:45 --> Input Class Initialized
DEBUG - 2011-09-06 12:15:45 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-06 12:15:45 --> Language Class Initialized
DEBUG - 2011-09-06 12:15:45 --> Loader Class Initialized
DEBUG - 2011-09-06 12:15:45 --> Controller Class Initialized
DEBUG - 2011-09-06 12:15:45 --> Model Class Initialized
DEBUG - 2011-09-06 12:15:45 --> Model Class Initialized
DEBUG - 2011-09-06 12:15:45 --> Model Class Initialized
DEBUG - 2011-09-06 12:15:45 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-06 12:15:45 --> Database Driver Class Initialized
DEBUG - 2011-09-06 12:15:45 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-06 12:15:45 --> Helper loaded: url_helper
DEBUG - 2011-09-06 12:15:45 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-06 12:15:45 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-06 12:15:45 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-06 12:15:45 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-06 12:15:45 --> Final output sent to browser
DEBUG - 2011-09-06 12:15:45 --> Total execution time: 0.0456
DEBUG - 2011-09-06 12:20:43 --> Config Class Initialized
DEBUG - 2011-09-06 12:20:43 --> Hooks Class Initialized
DEBUG - 2011-09-06 12:20:43 --> Utf8 Class Initialized
DEBUG - 2011-09-06 12:20:43 --> UTF-8 Support Enabled
DEBUG - 2011-09-06 12:20:43 --> URI Class Initialized
DEBUG - 2011-09-06 12:20:43 --> Router Class Initialized
DEBUG - 2011-09-06 12:20:43 --> Output Class Initialized
DEBUG - 2011-09-06 12:20:43 --> Input Class Initialized
DEBUG - 2011-09-06 12:20:43 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-06 12:20:43 --> Language Class Initialized
DEBUG - 2011-09-06 12:20:43 --> Loader Class Initialized
DEBUG - 2011-09-06 12:20:43 --> Controller Class Initialized
DEBUG - 2011-09-06 12:20:43 --> Model Class Initialized
DEBUG - 2011-09-06 12:20:43 --> Model Class Initialized
DEBUG - 2011-09-06 12:20:43 --> Model Class Initialized
DEBUG - 2011-09-06 12:20:43 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-06 12:20:43 --> Database Driver Class Initialized
DEBUG - 2011-09-06 12:20:44 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-06 12:20:44 --> Helper loaded: url_helper
DEBUG - 2011-09-06 12:20:44 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-06 12:20:44 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-06 12:20:44 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-06 12:20:44 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-06 12:20:44 --> Final output sent to browser
DEBUG - 2011-09-06 12:20:44 --> Total execution time: 0.7744
DEBUG - 2011-09-06 12:20:45 --> Config Class Initialized
DEBUG - 2011-09-06 12:20:45 --> Hooks Class Initialized
DEBUG - 2011-09-06 12:20:45 --> Utf8 Class Initialized
DEBUG - 2011-09-06 12:20:45 --> UTF-8 Support Enabled
DEBUG - 2011-09-06 12:20:45 --> URI Class Initialized
DEBUG - 2011-09-06 12:20:45 --> Router Class Initialized
DEBUG - 2011-09-06 12:20:45 --> Output Class Initialized
DEBUG - 2011-09-06 12:20:45 --> Input Class Initialized
DEBUG - 2011-09-06 12:20:45 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-06 12:20:46 --> Language Class Initialized
DEBUG - 2011-09-06 12:20:46 --> Loader Class Initialized
DEBUG - 2011-09-06 12:20:46 --> Controller Class Initialized
DEBUG - 2011-09-06 12:20:46 --> Model Class Initialized
DEBUG - 2011-09-06 12:20:46 --> Model Class Initialized
DEBUG - 2011-09-06 12:20:46 --> Model Class Initialized
DEBUG - 2011-09-06 12:20:46 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-06 12:20:46 --> Database Driver Class Initialized
DEBUG - 2011-09-06 12:20:46 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-06 12:20:46 --> Helper loaded: url_helper
DEBUG - 2011-09-06 12:20:46 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-06 12:20:46 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-06 12:20:46 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-06 12:20:46 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-06 12:20:46 --> Final output sent to browser
DEBUG - 2011-09-06 12:20:46 --> Total execution time: 0.0999
DEBUG - 2011-09-06 12:20:50 --> Config Class Initialized
DEBUG - 2011-09-06 12:20:50 --> Hooks Class Initialized
DEBUG - 2011-09-06 12:20:50 --> Utf8 Class Initialized
DEBUG - 2011-09-06 12:20:50 --> UTF-8 Support Enabled
DEBUG - 2011-09-06 12:20:50 --> URI Class Initialized
DEBUG - 2011-09-06 12:20:50 --> Router Class Initialized
DEBUG - 2011-09-06 12:20:50 --> Output Class Initialized
DEBUG - 2011-09-06 12:20:50 --> Input Class Initialized
DEBUG - 2011-09-06 12:20:50 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-06 12:20:50 --> Language Class Initialized
DEBUG - 2011-09-06 12:20:50 --> Loader Class Initialized
DEBUG - 2011-09-06 12:20:50 --> Controller Class Initialized
DEBUG - 2011-09-06 12:20:50 --> Model Class Initialized
DEBUG - 2011-09-06 12:20:50 --> Model Class Initialized
DEBUG - 2011-09-06 12:20:50 --> Model Class Initialized
DEBUG - 2011-09-06 12:20:50 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-06 12:20:50 --> Database Driver Class Initialized
DEBUG - 2011-09-06 12:20:50 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-06 12:20:50 --> Helper loaded: url_helper
DEBUG - 2011-09-06 12:20:50 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-06 12:20:50 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-06 12:20:50 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-06 12:20:50 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-06 12:20:50 --> Final output sent to browser
DEBUG - 2011-09-06 12:20:50 --> Total execution time: 0.0453
DEBUG - 2011-09-06 12:40:31 --> Config Class Initialized
DEBUG - 2011-09-06 12:40:31 --> Hooks Class Initialized
DEBUG - 2011-09-06 12:40:31 --> Utf8 Class Initialized
DEBUG - 2011-09-06 12:40:31 --> UTF-8 Support Enabled
DEBUG - 2011-09-06 12:40:31 --> URI Class Initialized
DEBUG - 2011-09-06 12:40:31 --> Router Class Initialized
DEBUG - 2011-09-06 12:40:31 --> Output Class Initialized
DEBUG - 2011-09-06 12:40:31 --> Input Class Initialized
DEBUG - 2011-09-06 12:40:31 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-06 12:40:31 --> Language Class Initialized
DEBUG - 2011-09-06 12:40:31 --> Loader Class Initialized
DEBUG - 2011-09-06 12:40:31 --> Controller Class Initialized
DEBUG - 2011-09-06 12:40:31 --> Model Class Initialized
DEBUG - 2011-09-06 12:40:31 --> Model Class Initialized
DEBUG - 2011-09-06 12:40:31 --> Model Class Initialized
DEBUG - 2011-09-06 12:40:31 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-06 12:40:31 --> Database Driver Class Initialized
DEBUG - 2011-09-06 12:40:31 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-06 12:40:31 --> Helper loaded: url_helper
DEBUG - 2011-09-06 12:40:31 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-06 12:40:31 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-06 12:40:31 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-06 12:40:31 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-06 12:40:31 --> Final output sent to browser
DEBUG - 2011-09-06 12:40:31 --> Total execution time: 0.2736
DEBUG - 2011-09-06 12:57:35 --> Config Class Initialized
DEBUG - 2011-09-06 12:57:35 --> Hooks Class Initialized
DEBUG - 2011-09-06 12:57:35 --> Utf8 Class Initialized
DEBUG - 2011-09-06 12:57:35 --> UTF-8 Support Enabled
DEBUG - 2011-09-06 12:57:35 --> URI Class Initialized
DEBUG - 2011-09-06 12:57:35 --> Router Class Initialized
DEBUG - 2011-09-06 12:57:35 --> Output Class Initialized
DEBUG - 2011-09-06 12:57:35 --> Input Class Initialized
DEBUG - 2011-09-06 12:57:35 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-06 12:57:35 --> Language Class Initialized
DEBUG - 2011-09-06 12:57:35 --> Loader Class Initialized
DEBUG - 2011-09-06 12:57:35 --> Controller Class Initialized
ERROR - 2011-09-06 12:57:35 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-06 12:57:35 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-06 12:57:35 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-06 12:57:35 --> Model Class Initialized
DEBUG - 2011-09-06 12:57:35 --> Model Class Initialized
DEBUG - 2011-09-06 12:57:35 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-06 12:57:35 --> Database Driver Class Initialized
DEBUG - 2011-09-06 12:57:35 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-06 12:57:35 --> Helper loaded: url_helper
DEBUG - 2011-09-06 12:57:35 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-06 12:57:35 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-06 12:57:35 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-06 12:57:35 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-06 12:57:35 --> Final output sent to browser
DEBUG - 2011-09-06 12:57:35 --> Total execution time: 0.1211
DEBUG - 2011-09-06 12:57:36 --> Config Class Initialized
DEBUG - 2011-09-06 12:57:36 --> Hooks Class Initialized
DEBUG - 2011-09-06 12:57:36 --> Utf8 Class Initialized
DEBUG - 2011-09-06 12:57:36 --> UTF-8 Support Enabled
DEBUG - 2011-09-06 12:57:36 --> URI Class Initialized
DEBUG - 2011-09-06 12:57:36 --> Router Class Initialized
DEBUG - 2011-09-06 12:57:36 --> Output Class Initialized
DEBUG - 2011-09-06 12:57:36 --> Input Class Initialized
DEBUG - 2011-09-06 12:57:36 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-06 12:57:36 --> Language Class Initialized
DEBUG - 2011-09-06 12:57:36 --> Loader Class Initialized
DEBUG - 2011-09-06 12:57:36 --> Controller Class Initialized
DEBUG - 2011-09-06 12:57:36 --> Model Class Initialized
DEBUG - 2011-09-06 12:57:36 --> Model Class Initialized
DEBUG - 2011-09-06 12:57:36 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-06 12:57:36 --> Database Driver Class Initialized
DEBUG - 2011-09-06 12:57:36 --> Final output sent to browser
DEBUG - 2011-09-06 12:57:36 --> Total execution time: 0.6790
DEBUG - 2011-09-06 12:57:37 --> Config Class Initialized
DEBUG - 2011-09-06 12:57:37 --> Hooks Class Initialized
DEBUG - 2011-09-06 12:57:37 --> Utf8 Class Initialized
DEBUG - 2011-09-06 12:57:37 --> UTF-8 Support Enabled
DEBUG - 2011-09-06 12:57:37 --> URI Class Initialized
DEBUG - 2011-09-06 12:57:37 --> Router Class Initialized
ERROR - 2011-09-06 12:57:37 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-06 13:02:51 --> Config Class Initialized
DEBUG - 2011-09-06 13:02:51 --> Hooks Class Initialized
DEBUG - 2011-09-06 13:02:51 --> Utf8 Class Initialized
DEBUG - 2011-09-06 13:02:51 --> UTF-8 Support Enabled
DEBUG - 2011-09-06 13:02:51 --> URI Class Initialized
DEBUG - 2011-09-06 13:02:51 --> Router Class Initialized
ERROR - 2011-09-06 13:02:51 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-09-06 13:10:08 --> Config Class Initialized
DEBUG - 2011-09-06 13:10:08 --> Hooks Class Initialized
DEBUG - 2011-09-06 13:10:08 --> Utf8 Class Initialized
DEBUG - 2011-09-06 13:10:08 --> UTF-8 Support Enabled
DEBUG - 2011-09-06 13:10:09 --> URI Class Initialized
DEBUG - 2011-09-06 13:10:09 --> Router Class Initialized
DEBUG - 2011-09-06 13:10:09 --> Output Class Initialized
DEBUG - 2011-09-06 13:10:09 --> Input Class Initialized
DEBUG - 2011-09-06 13:10:09 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-06 13:10:09 --> Language Class Initialized
DEBUG - 2011-09-06 13:10:09 --> Loader Class Initialized
DEBUG - 2011-09-06 13:10:09 --> Controller Class Initialized
ERROR - 2011-09-06 13:10:09 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-06 13:10:09 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-06 13:10:09 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-06 13:10:09 --> Model Class Initialized
DEBUG - 2011-09-06 13:10:09 --> Model Class Initialized
DEBUG - 2011-09-06 13:10:09 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-06 13:10:09 --> Database Driver Class Initialized
DEBUG - 2011-09-06 13:10:09 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-06 13:10:09 --> Helper loaded: url_helper
DEBUG - 2011-09-06 13:10:09 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-06 13:10:09 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-06 13:10:09 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-06 13:10:09 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-06 13:10:09 --> Final output sent to browser
DEBUG - 2011-09-06 13:10:09 --> Total execution time: 0.1016
DEBUG - 2011-09-06 13:10:11 --> Config Class Initialized
DEBUG - 2011-09-06 13:10:11 --> Hooks Class Initialized
DEBUG - 2011-09-06 13:10:11 --> Utf8 Class Initialized
DEBUG - 2011-09-06 13:10:11 --> UTF-8 Support Enabled
DEBUG - 2011-09-06 13:10:11 --> URI Class Initialized
DEBUG - 2011-09-06 13:10:11 --> Router Class Initialized
DEBUG - 2011-09-06 13:10:11 --> Output Class Initialized
DEBUG - 2011-09-06 13:10:11 --> Input Class Initialized
DEBUG - 2011-09-06 13:10:11 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-06 13:10:11 --> Language Class Initialized
DEBUG - 2011-09-06 13:10:11 --> Loader Class Initialized
DEBUG - 2011-09-06 13:10:11 --> Controller Class Initialized
DEBUG - 2011-09-06 13:10:11 --> Model Class Initialized
DEBUG - 2011-09-06 13:10:11 --> Model Class Initialized
DEBUG - 2011-09-06 13:10:11 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-06 13:10:11 --> Database Driver Class Initialized
DEBUG - 2011-09-06 13:10:11 --> Final output sent to browser
DEBUG - 2011-09-06 13:10:11 --> Total execution time: 0.4937
DEBUG - 2011-09-06 13:10:16 --> Config Class Initialized
DEBUG - 2011-09-06 13:10:16 --> Hooks Class Initialized
DEBUG - 2011-09-06 13:10:16 --> Utf8 Class Initialized
DEBUG - 2011-09-06 13:10:16 --> UTF-8 Support Enabled
DEBUG - 2011-09-06 13:10:16 --> URI Class Initialized
DEBUG - 2011-09-06 13:10:16 --> Router Class Initialized
ERROR - 2011-09-06 13:10:16 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-06 13:10:16 --> Config Class Initialized
DEBUG - 2011-09-06 13:10:16 --> Hooks Class Initialized
DEBUG - 2011-09-06 13:10:16 --> Utf8 Class Initialized
DEBUG - 2011-09-06 13:10:16 --> UTF-8 Support Enabled
DEBUG - 2011-09-06 13:10:16 --> URI Class Initialized
DEBUG - 2011-09-06 13:10:16 --> Router Class Initialized
ERROR - 2011-09-06 13:10:16 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-06 13:10:16 --> Config Class Initialized
DEBUG - 2011-09-06 13:10:16 --> Hooks Class Initialized
DEBUG - 2011-09-06 13:10:16 --> Utf8 Class Initialized
DEBUG - 2011-09-06 13:10:16 --> UTF-8 Support Enabled
DEBUG - 2011-09-06 13:10:16 --> URI Class Initialized
DEBUG - 2011-09-06 13:10:16 --> Router Class Initialized
ERROR - 2011-09-06 13:10:16 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-06 13:10:23 --> Config Class Initialized
DEBUG - 2011-09-06 13:10:23 --> Hooks Class Initialized
DEBUG - 2011-09-06 13:10:23 --> Utf8 Class Initialized
DEBUG - 2011-09-06 13:10:23 --> UTF-8 Support Enabled
DEBUG - 2011-09-06 13:10:23 --> URI Class Initialized
DEBUG - 2011-09-06 13:10:23 --> Router Class Initialized
DEBUG - 2011-09-06 13:10:23 --> Output Class Initialized
DEBUG - 2011-09-06 13:10:23 --> Input Class Initialized
DEBUG - 2011-09-06 13:10:23 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-06 13:10:23 --> Language Class Initialized
DEBUG - 2011-09-06 13:10:23 --> Loader Class Initialized
DEBUG - 2011-09-06 13:10:23 --> Controller Class Initialized
ERROR - 2011-09-06 13:10:23 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-06 13:10:23 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-06 13:10:23 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-06 13:10:23 --> Model Class Initialized
DEBUG - 2011-09-06 13:10:23 --> Model Class Initialized
DEBUG - 2011-09-06 13:10:23 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-06 13:10:23 --> Database Driver Class Initialized
DEBUG - 2011-09-06 13:10:23 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-06 13:10:23 --> Helper loaded: url_helper
DEBUG - 2011-09-06 13:10:23 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-06 13:10:23 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-06 13:10:23 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-06 13:10:23 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-06 13:10:23 --> Final output sent to browser
DEBUG - 2011-09-06 13:10:23 --> Total execution time: 0.0555
DEBUG - 2011-09-06 13:10:24 --> Config Class Initialized
DEBUG - 2011-09-06 13:10:24 --> Hooks Class Initialized
DEBUG - 2011-09-06 13:10:24 --> Utf8 Class Initialized
DEBUG - 2011-09-06 13:10:24 --> UTF-8 Support Enabled
DEBUG - 2011-09-06 13:10:24 --> URI Class Initialized
DEBUG - 2011-09-06 13:10:24 --> Router Class Initialized
DEBUG - 2011-09-06 13:10:24 --> Output Class Initialized
DEBUG - 2011-09-06 13:10:24 --> Input Class Initialized
DEBUG - 2011-09-06 13:10:24 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-06 13:10:24 --> Language Class Initialized
DEBUG - 2011-09-06 13:10:24 --> Loader Class Initialized
DEBUG - 2011-09-06 13:10:24 --> Controller Class Initialized
DEBUG - 2011-09-06 13:10:24 --> Model Class Initialized
DEBUG - 2011-09-06 13:10:24 --> Model Class Initialized
DEBUG - 2011-09-06 13:10:24 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-06 13:10:24 --> Database Driver Class Initialized
DEBUG - 2011-09-06 13:10:25 --> Final output sent to browser
DEBUG - 2011-09-06 13:10:25 --> Total execution time: 0.5115
DEBUG - 2011-09-06 13:51:07 --> Config Class Initialized
DEBUG - 2011-09-06 13:51:07 --> Hooks Class Initialized
DEBUG - 2011-09-06 13:51:07 --> Utf8 Class Initialized
DEBUG - 2011-09-06 13:51:07 --> UTF-8 Support Enabled
DEBUG - 2011-09-06 13:51:07 --> URI Class Initialized
DEBUG - 2011-09-06 13:51:07 --> Router Class Initialized
DEBUG - 2011-09-06 13:51:07 --> Output Class Initialized
DEBUG - 2011-09-06 13:51:07 --> Input Class Initialized
DEBUG - 2011-09-06 13:51:07 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-06 13:51:07 --> Language Class Initialized
DEBUG - 2011-09-06 13:51:07 --> Loader Class Initialized
DEBUG - 2011-09-06 13:51:07 --> Controller Class Initialized
ERROR - 2011-09-06 13:51:07 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-06 13:51:07 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-06 13:51:07 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-06 13:51:07 --> Model Class Initialized
DEBUG - 2011-09-06 13:51:07 --> Model Class Initialized
DEBUG - 2011-09-06 13:51:07 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-06 13:51:07 --> Database Driver Class Initialized
DEBUG - 2011-09-06 13:51:07 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-06 13:51:07 --> Helper loaded: url_helper
DEBUG - 2011-09-06 13:51:07 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-06 13:51:07 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-06 13:51:07 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-06 13:51:07 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-06 13:51:07 --> Final output sent to browser
DEBUG - 2011-09-06 13:51:07 --> Total execution time: 0.0315
DEBUG - 2011-09-06 13:51:13 --> Config Class Initialized
DEBUG - 2011-09-06 13:51:13 --> Hooks Class Initialized
DEBUG - 2011-09-06 13:51:13 --> Utf8 Class Initialized
DEBUG - 2011-09-06 13:51:13 --> UTF-8 Support Enabled
DEBUG - 2011-09-06 13:51:13 --> URI Class Initialized
DEBUG - 2011-09-06 13:51:13 --> Router Class Initialized
DEBUG - 2011-09-06 13:51:13 --> Output Class Initialized
DEBUG - 2011-09-06 13:51:13 --> Input Class Initialized
DEBUG - 2011-09-06 13:51:13 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-06 13:51:13 --> Language Class Initialized
DEBUG - 2011-09-06 13:51:13 --> Loader Class Initialized
DEBUG - 2011-09-06 13:51:13 --> Controller Class Initialized
DEBUG - 2011-09-06 13:51:13 --> Model Class Initialized
DEBUG - 2011-09-06 13:51:13 --> Model Class Initialized
DEBUG - 2011-09-06 13:51:13 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-06 13:51:13 --> Database Driver Class Initialized
DEBUG - 2011-09-06 13:51:13 --> Final output sent to browser
DEBUG - 2011-09-06 13:51:13 --> Total execution time: 0.5304
DEBUG - 2011-09-06 15:10:42 --> Config Class Initialized
DEBUG - 2011-09-06 15:10:42 --> Hooks Class Initialized
DEBUG - 2011-09-06 15:10:42 --> Utf8 Class Initialized
DEBUG - 2011-09-06 15:10:42 --> UTF-8 Support Enabled
DEBUG - 2011-09-06 15:10:42 --> URI Class Initialized
DEBUG - 2011-09-06 15:10:42 --> Router Class Initialized
DEBUG - 2011-09-06 15:10:42 --> Output Class Initialized
DEBUG - 2011-09-06 15:10:42 --> Input Class Initialized
DEBUG - 2011-09-06 15:10:42 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-06 15:10:42 --> Language Class Initialized
DEBUG - 2011-09-06 15:10:42 --> Loader Class Initialized
DEBUG - 2011-09-06 15:10:42 --> Controller Class Initialized
DEBUG - 2011-09-06 15:10:42 --> Model Class Initialized
DEBUG - 2011-09-06 15:10:43 --> Model Class Initialized
DEBUG - 2011-09-06 15:10:43 --> Model Class Initialized
DEBUG - 2011-09-06 15:10:43 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-06 15:10:43 --> Database Driver Class Initialized
DEBUG - 2011-09-06 15:10:43 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-06 15:10:43 --> Helper loaded: url_helper
DEBUG - 2011-09-06 15:10:43 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-06 15:10:43 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-06 15:10:43 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-06 15:10:43 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-06 15:10:43 --> Final output sent to browser
DEBUG - 2011-09-06 15:10:43 --> Total execution time: 0.5434
DEBUG - 2011-09-06 15:10:44 --> Config Class Initialized
DEBUG - 2011-09-06 15:10:44 --> Hooks Class Initialized
DEBUG - 2011-09-06 15:10:44 --> Utf8 Class Initialized
DEBUG - 2011-09-06 15:10:44 --> UTF-8 Support Enabled
DEBUG - 2011-09-06 15:10:44 --> URI Class Initialized
DEBUG - 2011-09-06 15:10:44 --> Router Class Initialized
DEBUG - 2011-09-06 15:10:44 --> Output Class Initialized
DEBUG - 2011-09-06 15:10:44 --> Input Class Initialized
DEBUG - 2011-09-06 15:10:44 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-06 15:10:44 --> Language Class Initialized
DEBUG - 2011-09-06 15:10:44 --> Loader Class Initialized
DEBUG - 2011-09-06 15:10:44 --> Controller Class Initialized
ERROR - 2011-09-06 15:10:44 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-06 15:10:44 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-06 15:10:44 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-06 15:10:44 --> Model Class Initialized
DEBUG - 2011-09-06 15:10:44 --> Model Class Initialized
DEBUG - 2011-09-06 15:10:44 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-06 15:10:44 --> Database Driver Class Initialized
DEBUG - 2011-09-06 15:10:44 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-06 15:10:44 --> Helper loaded: url_helper
DEBUG - 2011-09-06 15:10:44 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-06 15:10:44 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-06 15:10:44 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-06 15:10:44 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-06 15:10:44 --> Final output sent to browser
DEBUG - 2011-09-06 15:10:44 --> Total execution time: 0.0487
DEBUG - 2011-09-06 15:14:22 --> Config Class Initialized
DEBUG - 2011-09-06 15:14:22 --> Hooks Class Initialized
DEBUG - 2011-09-06 15:14:22 --> Utf8 Class Initialized
DEBUG - 2011-09-06 15:14:22 --> UTF-8 Support Enabled
DEBUG - 2011-09-06 15:14:22 --> URI Class Initialized
DEBUG - 2011-09-06 15:14:22 --> Router Class Initialized
DEBUG - 2011-09-06 15:14:22 --> Output Class Initialized
DEBUG - 2011-09-06 15:14:22 --> Input Class Initialized
DEBUG - 2011-09-06 15:14:22 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-06 15:14:22 --> Language Class Initialized
DEBUG - 2011-09-06 15:14:22 --> Loader Class Initialized
DEBUG - 2011-09-06 15:14:22 --> Controller Class Initialized
DEBUG - 2011-09-06 15:14:22 --> Model Class Initialized
DEBUG - 2011-09-06 15:14:22 --> Model Class Initialized
DEBUG - 2011-09-06 15:14:22 --> Model Class Initialized
DEBUG - 2011-09-06 15:14:22 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-06 15:14:22 --> Database Driver Class Initialized
DEBUG - 2011-09-06 15:14:22 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-06 15:14:22 --> Helper loaded: url_helper
DEBUG - 2011-09-06 15:14:22 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-06 15:14:22 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-06 15:14:22 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-06 15:14:22 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-06 15:14:22 --> Final output sent to browser
DEBUG - 2011-09-06 15:14:22 --> Total execution time: 0.0779
DEBUG - 2011-09-06 15:14:49 --> Config Class Initialized
DEBUG - 2011-09-06 15:14:49 --> Hooks Class Initialized
DEBUG - 2011-09-06 15:14:49 --> Utf8 Class Initialized
DEBUG - 2011-09-06 15:14:49 --> UTF-8 Support Enabled
DEBUG - 2011-09-06 15:14:49 --> URI Class Initialized
DEBUG - 2011-09-06 15:14:49 --> Router Class Initialized
DEBUG - 2011-09-06 15:14:49 --> Output Class Initialized
DEBUG - 2011-09-06 15:14:49 --> Input Class Initialized
DEBUG - 2011-09-06 15:14:49 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-06 15:14:49 --> Language Class Initialized
DEBUG - 2011-09-06 15:14:49 --> Loader Class Initialized
DEBUG - 2011-09-06 15:14:49 --> Controller Class Initialized
ERROR - 2011-09-06 15:14:49 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-06 15:14:49 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-06 15:14:49 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-06 15:14:49 --> Model Class Initialized
DEBUG - 2011-09-06 15:14:49 --> Model Class Initialized
DEBUG - 2011-09-06 15:14:49 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-06 15:14:49 --> Database Driver Class Initialized
DEBUG - 2011-09-06 15:14:49 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-06 15:14:49 --> Helper loaded: url_helper
DEBUG - 2011-09-06 15:14:49 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-06 15:14:49 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-06 15:14:49 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-06 15:14:49 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-06 15:14:49 --> Final output sent to browser
DEBUG - 2011-09-06 15:14:49 --> Total execution time: 0.0870
DEBUG - 2011-09-06 15:14:51 --> Config Class Initialized
DEBUG - 2011-09-06 15:14:51 --> Hooks Class Initialized
DEBUG - 2011-09-06 15:14:51 --> Utf8 Class Initialized
DEBUG - 2011-09-06 15:14:51 --> UTF-8 Support Enabled
DEBUG - 2011-09-06 15:14:51 --> URI Class Initialized
DEBUG - 2011-09-06 15:14:51 --> Router Class Initialized
DEBUG - 2011-09-06 15:14:51 --> Output Class Initialized
DEBUG - 2011-09-06 15:14:51 --> Input Class Initialized
DEBUG - 2011-09-06 15:14:51 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-06 15:14:51 --> Language Class Initialized
DEBUG - 2011-09-06 15:14:51 --> Loader Class Initialized
DEBUG - 2011-09-06 15:14:51 --> Controller Class Initialized
DEBUG - 2011-09-06 15:14:51 --> Model Class Initialized
DEBUG - 2011-09-06 15:14:51 --> Model Class Initialized
DEBUG - 2011-09-06 15:14:51 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-06 15:14:51 --> Database Driver Class Initialized
DEBUG - 2011-09-06 15:14:51 --> Final output sent to browser
DEBUG - 2011-09-06 15:14:51 --> Total execution time: 0.7617
DEBUG - 2011-09-06 15:19:10 --> Config Class Initialized
DEBUG - 2011-09-06 15:19:10 --> Hooks Class Initialized
DEBUG - 2011-09-06 15:19:10 --> Utf8 Class Initialized
DEBUG - 2011-09-06 15:19:10 --> UTF-8 Support Enabled
DEBUG - 2011-09-06 15:19:10 --> URI Class Initialized
DEBUG - 2011-09-06 15:19:10 --> Router Class Initialized
DEBUG - 2011-09-06 15:19:10 --> No URI present. Default controller set.
DEBUG - 2011-09-06 15:19:10 --> Output Class Initialized
DEBUG - 2011-09-06 15:19:10 --> Input Class Initialized
DEBUG - 2011-09-06 15:19:10 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-06 15:19:10 --> Language Class Initialized
DEBUG - 2011-09-06 15:19:10 --> Loader Class Initialized
DEBUG - 2011-09-06 15:19:10 --> Controller Class Initialized
DEBUG - 2011-09-06 15:19:10 --> File loaded: application/views/splash/main.php
DEBUG - 2011-09-06 15:19:10 --> Helper loaded: url_helper
DEBUG - 2011-09-06 15:19:10 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-06 15:19:10 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-06 15:19:10 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-06 15:19:10 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-06 15:19:10 --> Final output sent to browser
DEBUG - 2011-09-06 15:19:10 --> Total execution time: 0.0830
DEBUG - 2011-09-06 15:44:25 --> Config Class Initialized
DEBUG - 2011-09-06 15:44:25 --> Hooks Class Initialized
DEBUG - 2011-09-06 15:44:25 --> Utf8 Class Initialized
DEBUG - 2011-09-06 15:44:25 --> UTF-8 Support Enabled
DEBUG - 2011-09-06 15:44:25 --> URI Class Initialized
DEBUG - 2011-09-06 15:44:25 --> Router Class Initialized
DEBUG - 2011-09-06 15:44:25 --> Output Class Initialized
DEBUG - 2011-09-06 15:44:25 --> Input Class Initialized
DEBUG - 2011-09-06 15:44:25 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-06 15:44:25 --> Language Class Initialized
DEBUG - 2011-09-06 15:44:25 --> Loader Class Initialized
DEBUG - 2011-09-06 15:44:25 --> Controller Class Initialized
ERROR - 2011-09-06 15:44:25 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-06 15:44:25 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-06 15:44:25 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-06 15:44:25 --> Model Class Initialized
DEBUG - 2011-09-06 15:44:25 --> Model Class Initialized
DEBUG - 2011-09-06 15:44:25 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-06 15:44:25 --> Database Driver Class Initialized
DEBUG - 2011-09-06 15:44:25 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-06 15:44:25 --> Helper loaded: url_helper
DEBUG - 2011-09-06 15:44:25 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-06 15:44:25 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-06 15:44:25 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-06 15:44:25 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-06 15:44:25 --> Final output sent to browser
DEBUG - 2011-09-06 15:44:25 --> Total execution time: 0.0439
DEBUG - 2011-09-06 15:44:27 --> Config Class Initialized
DEBUG - 2011-09-06 15:44:27 --> Hooks Class Initialized
DEBUG - 2011-09-06 15:44:27 --> Utf8 Class Initialized
DEBUG - 2011-09-06 15:44:27 --> UTF-8 Support Enabled
DEBUG - 2011-09-06 15:44:27 --> URI Class Initialized
DEBUG - 2011-09-06 15:44:27 --> Router Class Initialized
DEBUG - 2011-09-06 15:44:27 --> Output Class Initialized
DEBUG - 2011-09-06 15:44:27 --> Input Class Initialized
DEBUG - 2011-09-06 15:44:27 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-06 15:44:27 --> Language Class Initialized
DEBUG - 2011-09-06 15:44:27 --> Loader Class Initialized
DEBUG - 2011-09-06 15:44:27 --> Controller Class Initialized
DEBUG - 2011-09-06 15:44:27 --> Model Class Initialized
DEBUG - 2011-09-06 15:44:27 --> Model Class Initialized
DEBUG - 2011-09-06 15:44:27 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-06 15:44:27 --> Database Driver Class Initialized
DEBUG - 2011-09-06 15:44:27 --> Final output sent to browser
DEBUG - 2011-09-06 15:44:27 --> Total execution time: 0.6194
DEBUG - 2011-09-06 16:52:26 --> Config Class Initialized
DEBUG - 2011-09-06 16:52:26 --> Hooks Class Initialized
DEBUG - 2011-09-06 16:52:26 --> Utf8 Class Initialized
DEBUG - 2011-09-06 16:52:26 --> UTF-8 Support Enabled
DEBUG - 2011-09-06 16:52:26 --> URI Class Initialized
DEBUG - 2011-09-06 16:52:26 --> Router Class Initialized
ERROR - 2011-09-06 16:52:26 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-09-06 16:52:27 --> Config Class Initialized
DEBUG - 2011-09-06 16:52:27 --> Hooks Class Initialized
DEBUG - 2011-09-06 16:52:27 --> Utf8 Class Initialized
DEBUG - 2011-09-06 16:52:27 --> UTF-8 Support Enabled
DEBUG - 2011-09-06 16:52:27 --> URI Class Initialized
DEBUG - 2011-09-06 16:52:27 --> Router Class Initialized
DEBUG - 2011-09-06 16:52:27 --> Output Class Initialized
DEBUG - 2011-09-06 16:52:27 --> Input Class Initialized
DEBUG - 2011-09-06 16:52:27 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-06 16:52:27 --> Language Class Initialized
DEBUG - 2011-09-06 16:52:27 --> Loader Class Initialized
DEBUG - 2011-09-06 16:52:27 --> Controller Class Initialized
ERROR - 2011-09-06 16:52:27 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-06 16:52:27 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-06 16:52:27 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-06 16:52:27 --> Model Class Initialized
DEBUG - 2011-09-06 16:52:27 --> Model Class Initialized
DEBUG - 2011-09-06 16:52:27 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-06 16:52:27 --> Database Driver Class Initialized
DEBUG - 2011-09-06 16:52:27 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-06 16:52:27 --> Helper loaded: url_helper
DEBUG - 2011-09-06 16:52:27 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-06 16:52:27 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-06 16:52:27 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-06 16:52:27 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-06 16:52:27 --> Final output sent to browser
DEBUG - 2011-09-06 16:52:27 --> Total execution time: 0.0346
DEBUG - 2011-09-06 16:58:04 --> Config Class Initialized
DEBUG - 2011-09-06 16:58:04 --> Hooks Class Initialized
DEBUG - 2011-09-06 16:58:04 --> Utf8 Class Initialized
DEBUG - 2011-09-06 16:58:04 --> UTF-8 Support Enabled
DEBUG - 2011-09-06 16:58:04 --> URI Class Initialized
DEBUG - 2011-09-06 16:58:04 --> Router Class Initialized
DEBUG - 2011-09-06 16:58:04 --> Output Class Initialized
DEBUG - 2011-09-06 16:58:04 --> Input Class Initialized
DEBUG - 2011-09-06 16:58:04 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-06 16:58:04 --> Language Class Initialized
DEBUG - 2011-09-06 16:58:04 --> Loader Class Initialized
DEBUG - 2011-09-06 16:58:04 --> Controller Class Initialized
ERROR - 2011-09-06 16:58:04 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-06 16:58:04 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-06 16:58:04 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-06 16:58:04 --> Model Class Initialized
DEBUG - 2011-09-06 16:58:04 --> Model Class Initialized
DEBUG - 2011-09-06 16:58:04 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-06 16:58:04 --> Database Driver Class Initialized
DEBUG - 2011-09-06 16:58:04 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-06 16:58:04 --> Helper loaded: url_helper
DEBUG - 2011-09-06 16:58:04 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-06 16:58:04 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-06 16:58:04 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-06 16:58:04 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-06 16:58:04 --> Final output sent to browser
DEBUG - 2011-09-06 16:58:04 --> Total execution time: 0.0458
DEBUG - 2011-09-06 17:29:08 --> Config Class Initialized
DEBUG - 2011-09-06 17:29:08 --> Hooks Class Initialized
DEBUG - 2011-09-06 17:29:08 --> Utf8 Class Initialized
DEBUG - 2011-09-06 17:29:08 --> UTF-8 Support Enabled
DEBUG - 2011-09-06 17:29:08 --> URI Class Initialized
DEBUG - 2011-09-06 17:29:08 --> Router Class Initialized
DEBUG - 2011-09-06 17:29:08 --> Output Class Initialized
DEBUG - 2011-09-06 17:29:08 --> Input Class Initialized
DEBUG - 2011-09-06 17:29:08 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-06 17:29:08 --> Language Class Initialized
DEBUG - 2011-09-06 17:29:08 --> Loader Class Initialized
DEBUG - 2011-09-06 17:29:08 --> Controller Class Initialized
DEBUG - 2011-09-06 17:29:08 --> Model Class Initialized
DEBUG - 2011-09-06 17:29:08 --> Model Class Initialized
DEBUG - 2011-09-06 17:29:08 --> Model Class Initialized
DEBUG - 2011-09-06 17:29:08 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-06 17:29:08 --> Database Driver Class Initialized
DEBUG - 2011-09-06 17:29:08 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-06 17:29:08 --> Helper loaded: url_helper
DEBUG - 2011-09-06 17:29:08 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-06 17:29:08 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-06 17:29:08 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-06 17:29:08 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-06 17:29:08 --> Final output sent to browser
DEBUG - 2011-09-06 17:29:08 --> Total execution time: 0.3026
DEBUG - 2011-09-06 17:29:13 --> Config Class Initialized
DEBUG - 2011-09-06 17:29:13 --> Hooks Class Initialized
DEBUG - 2011-09-06 17:29:13 --> Utf8 Class Initialized
DEBUG - 2011-09-06 17:29:13 --> UTF-8 Support Enabled
DEBUG - 2011-09-06 17:29:13 --> URI Class Initialized
DEBUG - 2011-09-06 17:29:13 --> Router Class Initialized
ERROR - 2011-09-06 17:29:13 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-06 17:29:30 --> Config Class Initialized
DEBUG - 2011-09-06 17:29:30 --> Hooks Class Initialized
DEBUG - 2011-09-06 17:29:30 --> Utf8 Class Initialized
DEBUG - 2011-09-06 17:29:30 --> UTF-8 Support Enabled
DEBUG - 2011-09-06 17:29:30 --> URI Class Initialized
DEBUG - 2011-09-06 17:29:30 --> Router Class Initialized
DEBUG - 2011-09-06 17:29:30 --> Output Class Initialized
DEBUG - 2011-09-06 17:29:30 --> Input Class Initialized
DEBUG - 2011-09-06 17:29:30 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-06 17:29:30 --> Language Class Initialized
DEBUG - 2011-09-06 17:29:30 --> Loader Class Initialized
DEBUG - 2011-09-06 17:29:30 --> Controller Class Initialized
ERROR - 2011-09-06 17:29:30 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-06 17:29:30 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-06 17:29:30 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-06 17:29:30 --> Model Class Initialized
DEBUG - 2011-09-06 17:29:30 --> Model Class Initialized
DEBUG - 2011-09-06 17:29:30 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-06 17:29:30 --> Database Driver Class Initialized
DEBUG - 2011-09-06 17:29:30 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-06 17:29:30 --> Helper loaded: url_helper
DEBUG - 2011-09-06 17:29:30 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-06 17:29:30 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-06 17:29:30 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-06 17:29:30 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-06 17:29:30 --> Final output sent to browser
DEBUG - 2011-09-06 17:29:30 --> Total execution time: 0.0442
DEBUG - 2011-09-06 17:29:31 --> Config Class Initialized
DEBUG - 2011-09-06 17:29:31 --> Hooks Class Initialized
DEBUG - 2011-09-06 17:29:31 --> Utf8 Class Initialized
DEBUG - 2011-09-06 17:29:31 --> UTF-8 Support Enabled
DEBUG - 2011-09-06 17:29:31 --> URI Class Initialized
DEBUG - 2011-09-06 17:29:31 --> Router Class Initialized
DEBUG - 2011-09-06 17:29:31 --> Output Class Initialized
DEBUG - 2011-09-06 17:29:31 --> Input Class Initialized
DEBUG - 2011-09-06 17:29:31 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-06 17:29:31 --> Language Class Initialized
DEBUG - 2011-09-06 17:29:31 --> Loader Class Initialized
DEBUG - 2011-09-06 17:29:31 --> Controller Class Initialized
DEBUG - 2011-09-06 17:29:31 --> Model Class Initialized
DEBUG - 2011-09-06 17:29:31 --> Model Class Initialized
DEBUG - 2011-09-06 17:29:31 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-06 17:29:31 --> Database Driver Class Initialized
DEBUG - 2011-09-06 17:29:32 --> Final output sent to browser
DEBUG - 2011-09-06 17:29:32 --> Total execution time: 0.9121
DEBUG - 2011-09-06 17:29:33 --> Config Class Initialized
DEBUG - 2011-09-06 17:29:33 --> Hooks Class Initialized
DEBUG - 2011-09-06 17:29:33 --> Utf8 Class Initialized
DEBUG - 2011-09-06 17:29:33 --> UTF-8 Support Enabled
DEBUG - 2011-09-06 17:29:33 --> URI Class Initialized
DEBUG - 2011-09-06 17:29:33 --> Router Class Initialized
ERROR - 2011-09-06 17:29:33 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-06 17:47:24 --> Config Class Initialized
DEBUG - 2011-09-06 17:47:24 --> Hooks Class Initialized
DEBUG - 2011-09-06 17:47:24 --> Utf8 Class Initialized
DEBUG - 2011-09-06 17:47:24 --> UTF-8 Support Enabled
DEBUG - 2011-09-06 17:47:24 --> URI Class Initialized
DEBUG - 2011-09-06 17:47:24 --> Router Class Initialized
DEBUG - 2011-09-06 17:47:24 --> Output Class Initialized
DEBUG - 2011-09-06 17:47:24 --> Input Class Initialized
DEBUG - 2011-09-06 17:47:24 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-06 17:47:24 --> Language Class Initialized
DEBUG - 2011-09-06 17:47:24 --> Loader Class Initialized
DEBUG - 2011-09-06 17:47:24 --> Controller Class Initialized
ERROR - 2011-09-06 17:47:24 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-06 17:47:24 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-06 17:47:24 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-06 17:47:24 --> Model Class Initialized
DEBUG - 2011-09-06 17:47:24 --> Model Class Initialized
DEBUG - 2011-09-06 17:47:24 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-06 17:47:24 --> Database Driver Class Initialized
DEBUG - 2011-09-06 17:47:24 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-06 17:47:24 --> Helper loaded: url_helper
DEBUG - 2011-09-06 17:47:24 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-06 17:47:24 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-06 17:47:24 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-06 17:47:24 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-06 17:47:24 --> Final output sent to browser
DEBUG - 2011-09-06 17:47:24 --> Total execution time: 0.0311
DEBUG - 2011-09-06 17:56:14 --> Config Class Initialized
DEBUG - 2011-09-06 17:56:14 --> Hooks Class Initialized
DEBUG - 2011-09-06 17:56:14 --> Utf8 Class Initialized
DEBUG - 2011-09-06 17:56:14 --> UTF-8 Support Enabled
DEBUG - 2011-09-06 17:56:14 --> URI Class Initialized
DEBUG - 2011-09-06 17:56:14 --> Router Class Initialized
DEBUG - 2011-09-06 17:56:14 --> Output Class Initialized
DEBUG - 2011-09-06 17:56:14 --> Input Class Initialized
DEBUG - 2011-09-06 17:56:14 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-06 17:56:14 --> Language Class Initialized
DEBUG - 2011-09-06 17:56:14 --> Loader Class Initialized
DEBUG - 2011-09-06 17:56:14 --> Controller Class Initialized
ERROR - 2011-09-06 17:56:14 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-06 17:56:14 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-06 17:56:14 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-06 17:56:14 --> Model Class Initialized
DEBUG - 2011-09-06 17:56:14 --> Model Class Initialized
DEBUG - 2011-09-06 17:56:14 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-06 17:56:14 --> Database Driver Class Initialized
DEBUG - 2011-09-06 17:56:14 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-06 17:56:14 --> Helper loaded: url_helper
DEBUG - 2011-09-06 17:56:14 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-06 17:56:14 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-06 17:56:14 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-06 17:56:14 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-06 17:56:14 --> Final output sent to browser
DEBUG - 2011-09-06 17:56:14 --> Total execution time: 0.0315
DEBUG - 2011-09-06 17:58:38 --> Config Class Initialized
DEBUG - 2011-09-06 17:58:38 --> Hooks Class Initialized
DEBUG - 2011-09-06 17:58:38 --> Utf8 Class Initialized
DEBUG - 2011-09-06 17:58:38 --> UTF-8 Support Enabled
DEBUG - 2011-09-06 17:58:38 --> URI Class Initialized
DEBUG - 2011-09-06 17:58:38 --> Router Class Initialized
DEBUG - 2011-09-06 17:58:38 --> Output Class Initialized
DEBUG - 2011-09-06 17:58:38 --> Input Class Initialized
DEBUG - 2011-09-06 17:58:38 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-06 17:58:38 --> Language Class Initialized
DEBUG - 2011-09-06 17:58:38 --> Loader Class Initialized
DEBUG - 2011-09-06 17:58:38 --> Controller Class Initialized
ERROR - 2011-09-06 17:58:38 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-06 17:58:38 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-06 17:58:38 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-06 17:58:38 --> Model Class Initialized
DEBUG - 2011-09-06 17:58:38 --> Model Class Initialized
DEBUG - 2011-09-06 17:58:38 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-06 17:58:38 --> Database Driver Class Initialized
DEBUG - 2011-09-06 17:58:38 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-06 17:58:38 --> Helper loaded: url_helper
DEBUG - 2011-09-06 17:58:38 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-06 17:58:38 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-06 17:58:38 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-06 17:58:38 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-06 17:58:38 --> Final output sent to browser
DEBUG - 2011-09-06 17:58:38 --> Total execution time: 0.0283
DEBUG - 2011-09-06 17:58:39 --> Config Class Initialized
DEBUG - 2011-09-06 17:58:39 --> Hooks Class Initialized
DEBUG - 2011-09-06 17:58:39 --> Utf8 Class Initialized
DEBUG - 2011-09-06 17:58:39 --> UTF-8 Support Enabled
DEBUG - 2011-09-06 17:58:39 --> URI Class Initialized
DEBUG - 2011-09-06 17:58:39 --> Router Class Initialized
DEBUG - 2011-09-06 17:58:39 --> Output Class Initialized
DEBUG - 2011-09-06 17:58:39 --> Input Class Initialized
DEBUG - 2011-09-06 17:58:39 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-06 17:58:39 --> Language Class Initialized
DEBUG - 2011-09-06 17:58:39 --> Loader Class Initialized
DEBUG - 2011-09-06 17:58:39 --> Controller Class Initialized
DEBUG - 2011-09-06 17:58:39 --> Model Class Initialized
DEBUG - 2011-09-06 17:58:39 --> Model Class Initialized
DEBUG - 2011-09-06 17:58:39 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-06 17:58:39 --> Database Driver Class Initialized
DEBUG - 2011-09-06 17:58:40 --> Final output sent to browser
DEBUG - 2011-09-06 17:58:40 --> Total execution time: 0.6204
DEBUG - 2011-09-06 17:58:41 --> Config Class Initialized
DEBUG - 2011-09-06 17:58:41 --> Hooks Class Initialized
DEBUG - 2011-09-06 17:58:41 --> Utf8 Class Initialized
DEBUG - 2011-09-06 17:58:41 --> UTF-8 Support Enabled
DEBUG - 2011-09-06 17:58:41 --> URI Class Initialized
DEBUG - 2011-09-06 17:58:41 --> Router Class Initialized
ERROR - 2011-09-06 17:58:41 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-06 18:14:53 --> Config Class Initialized
DEBUG - 2011-09-06 18:14:53 --> Hooks Class Initialized
DEBUG - 2011-09-06 18:14:53 --> Utf8 Class Initialized
DEBUG - 2011-09-06 18:14:53 --> UTF-8 Support Enabled
DEBUG - 2011-09-06 18:14:53 --> URI Class Initialized
DEBUG - 2011-09-06 18:14:53 --> Router Class Initialized
DEBUG - 2011-09-06 18:14:53 --> Output Class Initialized
DEBUG - 2011-09-06 18:14:53 --> Input Class Initialized
DEBUG - 2011-09-06 18:14:53 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-06 18:14:53 --> Language Class Initialized
DEBUG - 2011-09-06 18:14:53 --> Loader Class Initialized
DEBUG - 2011-09-06 18:14:53 --> Controller Class Initialized
DEBUG - 2011-09-06 18:14:53 --> Model Class Initialized
DEBUG - 2011-09-06 18:14:53 --> Model Class Initialized
DEBUG - 2011-09-06 18:14:53 --> Model Class Initialized
DEBUG - 2011-09-06 18:14:53 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-06 18:14:53 --> Database Driver Class Initialized
DEBUG - 2011-09-06 18:14:53 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-06 18:14:53 --> Helper loaded: url_helper
DEBUG - 2011-09-06 18:14:53 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-06 18:14:53 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-06 18:14:53 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-06 18:14:53 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-06 18:14:53 --> Final output sent to browser
DEBUG - 2011-09-06 18:14:53 --> Total execution time: 0.2170
DEBUG - 2011-09-06 18:14:54 --> Config Class Initialized
DEBUG - 2011-09-06 18:14:54 --> Hooks Class Initialized
DEBUG - 2011-09-06 18:14:54 --> Utf8 Class Initialized
DEBUG - 2011-09-06 18:14:54 --> UTF-8 Support Enabled
DEBUG - 2011-09-06 18:14:54 --> URI Class Initialized
DEBUG - 2011-09-06 18:14:54 --> Router Class Initialized
DEBUG - 2011-09-06 18:14:54 --> Output Class Initialized
DEBUG - 2011-09-06 18:14:54 --> Input Class Initialized
DEBUG - 2011-09-06 18:14:54 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-06 18:14:54 --> Language Class Initialized
DEBUG - 2011-09-06 18:14:54 --> Loader Class Initialized
DEBUG - 2011-09-06 18:14:54 --> Controller Class Initialized
ERROR - 2011-09-06 18:14:54 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-06 18:14:54 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-06 18:14:54 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-06 18:14:54 --> Model Class Initialized
DEBUG - 2011-09-06 18:14:54 --> Model Class Initialized
DEBUG - 2011-09-06 18:14:54 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-06 18:14:54 --> Database Driver Class Initialized
DEBUG - 2011-09-06 18:14:54 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-06 18:14:54 --> Helper loaded: url_helper
DEBUG - 2011-09-06 18:14:54 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-06 18:14:54 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-06 18:14:54 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-06 18:14:54 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-06 18:14:54 --> Final output sent to browser
DEBUG - 2011-09-06 18:14:54 --> Total execution time: 0.0305
DEBUG - 2011-09-06 18:31:19 --> Config Class Initialized
DEBUG - 2011-09-06 18:31:19 --> Hooks Class Initialized
DEBUG - 2011-09-06 18:31:19 --> Utf8 Class Initialized
DEBUG - 2011-09-06 18:31:19 --> UTF-8 Support Enabled
DEBUG - 2011-09-06 18:31:19 --> URI Class Initialized
DEBUG - 2011-09-06 18:31:19 --> Router Class Initialized
DEBUG - 2011-09-06 18:31:19 --> Output Class Initialized
DEBUG - 2011-09-06 18:31:19 --> Input Class Initialized
DEBUG - 2011-09-06 18:31:19 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-06 18:31:19 --> Language Class Initialized
DEBUG - 2011-09-06 18:31:19 --> Loader Class Initialized
DEBUG - 2011-09-06 18:31:19 --> Controller Class Initialized
DEBUG - 2011-09-06 18:31:19 --> Model Class Initialized
DEBUG - 2011-09-06 18:31:19 --> Model Class Initialized
DEBUG - 2011-09-06 18:31:19 --> Model Class Initialized
DEBUG - 2011-09-06 18:31:19 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-06 18:31:19 --> Database Driver Class Initialized
DEBUG - 2011-09-06 18:31:19 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-06 18:31:19 --> Helper loaded: url_helper
DEBUG - 2011-09-06 18:31:19 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-06 18:31:19 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-06 18:31:19 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-06 18:31:19 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-06 18:31:19 --> Final output sent to browser
DEBUG - 2011-09-06 18:31:19 --> Total execution time: 0.2773
DEBUG - 2011-09-06 19:52:22 --> Config Class Initialized
DEBUG - 2011-09-06 19:52:22 --> Hooks Class Initialized
DEBUG - 2011-09-06 19:52:22 --> Utf8 Class Initialized
DEBUG - 2011-09-06 19:52:22 --> UTF-8 Support Enabled
DEBUG - 2011-09-06 19:52:22 --> URI Class Initialized
DEBUG - 2011-09-06 19:52:22 --> Router Class Initialized
DEBUG - 2011-09-06 19:52:22 --> No URI present. Default controller set.
DEBUG - 2011-09-06 19:52:22 --> Output Class Initialized
DEBUG - 2011-09-06 19:52:22 --> Input Class Initialized
DEBUG - 2011-09-06 19:52:22 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-06 19:52:22 --> Language Class Initialized
DEBUG - 2011-09-06 19:52:22 --> Loader Class Initialized
DEBUG - 2011-09-06 19:52:22 --> Controller Class Initialized
DEBUG - 2011-09-06 19:52:22 --> File loaded: application/views/splash/main.php
DEBUG - 2011-09-06 19:52:22 --> Helper loaded: url_helper
DEBUG - 2011-09-06 19:52:22 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-06 19:52:22 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-06 19:52:22 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-06 19:52:22 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-06 19:52:22 --> Final output sent to browser
DEBUG - 2011-09-06 19:52:22 --> Total execution time: 0.1568
DEBUG - 2011-09-06 22:33:04 --> Config Class Initialized
DEBUG - 2011-09-06 22:33:04 --> Hooks Class Initialized
DEBUG - 2011-09-06 22:33:04 --> Utf8 Class Initialized
DEBUG - 2011-09-06 22:33:04 --> UTF-8 Support Enabled
DEBUG - 2011-09-06 22:33:04 --> URI Class Initialized
DEBUG - 2011-09-06 22:33:04 --> Router Class Initialized
DEBUG - 2011-09-06 22:33:04 --> Output Class Initialized
DEBUG - 2011-09-06 22:33:04 --> Input Class Initialized
DEBUG - 2011-09-06 22:33:04 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-06 22:33:04 --> Language Class Initialized
DEBUG - 2011-09-06 22:33:04 --> Loader Class Initialized
DEBUG - 2011-09-06 22:33:04 --> Controller Class Initialized
DEBUG - 2011-09-06 22:33:04 --> Model Class Initialized
DEBUG - 2011-09-06 22:33:04 --> Model Class Initialized
DEBUG - 2011-09-06 22:33:04 --> Model Class Initialized
DEBUG - 2011-09-06 22:33:04 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-06 22:33:04 --> Database Driver Class Initialized
DEBUG - 2011-09-06 22:33:05 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-06 22:33:05 --> Helper loaded: url_helper
DEBUG - 2011-09-06 22:33:05 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-06 22:33:05 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-06 22:33:05 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-06 22:33:05 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-06 22:33:05 --> Final output sent to browser
DEBUG - 2011-09-06 22:33:05 --> Total execution time: 1.0163
DEBUG - 2011-09-06 22:36:55 --> Config Class Initialized
DEBUG - 2011-09-06 22:36:55 --> Hooks Class Initialized
DEBUG - 2011-09-06 22:36:55 --> Utf8 Class Initialized
DEBUG - 2011-09-06 22:36:55 --> UTF-8 Support Enabled
DEBUG - 2011-09-06 22:36:55 --> URI Class Initialized
DEBUG - 2011-09-06 22:36:55 --> Router Class Initialized
DEBUG - 2011-09-06 22:36:55 --> No URI present. Default controller set.
DEBUG - 2011-09-06 22:36:55 --> Output Class Initialized
DEBUG - 2011-09-06 22:36:55 --> Input Class Initialized
DEBUG - 2011-09-06 22:36:55 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-06 22:36:55 --> Language Class Initialized
DEBUG - 2011-09-06 22:36:55 --> Loader Class Initialized
DEBUG - 2011-09-06 22:36:55 --> Controller Class Initialized
DEBUG - 2011-09-06 22:36:55 --> File loaded: application/views/splash/main.php
DEBUG - 2011-09-06 22:36:55 --> Helper loaded: url_helper
DEBUG - 2011-09-06 22:36:55 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-06 22:36:55 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-06 22:36:55 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-06 22:36:55 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-06 22:36:55 --> Final output sent to browser
DEBUG - 2011-09-06 22:36:55 --> Total execution time: 0.0396
DEBUG - 2011-09-06 23:25:24 --> Config Class Initialized
DEBUG - 2011-09-06 23:25:24 --> Hooks Class Initialized
DEBUG - 2011-09-06 23:25:24 --> Utf8 Class Initialized
DEBUG - 2011-09-06 23:25:24 --> UTF-8 Support Enabled
DEBUG - 2011-09-06 23:25:24 --> URI Class Initialized
DEBUG - 2011-09-06 23:25:24 --> Router Class Initialized
ERROR - 2011-09-06 23:25:24 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-09-06 23:25:24 --> Config Class Initialized
DEBUG - 2011-09-06 23:25:24 --> Hooks Class Initialized
DEBUG - 2011-09-06 23:25:24 --> Utf8 Class Initialized
DEBUG - 2011-09-06 23:25:24 --> UTF-8 Support Enabled
DEBUG - 2011-09-06 23:25:24 --> URI Class Initialized
DEBUG - 2011-09-06 23:25:24 --> Router Class Initialized
DEBUG - 2011-09-06 23:25:24 --> Output Class Initialized
DEBUG - 2011-09-06 23:25:24 --> Input Class Initialized
DEBUG - 2011-09-06 23:25:24 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-06 23:25:24 --> Language Class Initialized
DEBUG - 2011-09-06 23:25:24 --> Loader Class Initialized
DEBUG - 2011-09-06 23:25:24 --> Controller Class Initialized
ERROR - 2011-09-06 23:25:25 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-06 23:25:25 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-06 23:25:25 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-06 23:25:25 --> Model Class Initialized
DEBUG - 2011-09-06 23:25:25 --> Model Class Initialized
DEBUG - 2011-09-06 23:25:25 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-06 23:25:25 --> Database Driver Class Initialized
DEBUG - 2011-09-06 23:25:25 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-06 23:25:25 --> Helper loaded: url_helper
DEBUG - 2011-09-06 23:25:25 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-06 23:25:25 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-06 23:25:25 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-06 23:25:25 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-06 23:25:25 --> Final output sent to browser
DEBUG - 2011-09-06 23:25:25 --> Total execution time: 0.1047
DEBUG - 2011-09-06 23:46:04 --> Config Class Initialized
DEBUG - 2011-09-06 23:46:04 --> Hooks Class Initialized
DEBUG - 2011-09-06 23:46:04 --> Utf8 Class Initialized
DEBUG - 2011-09-06 23:46:04 --> UTF-8 Support Enabled
DEBUG - 2011-09-06 23:46:04 --> URI Class Initialized
DEBUG - 2011-09-06 23:46:04 --> Router Class Initialized
DEBUG - 2011-09-06 23:46:04 --> Output Class Initialized
DEBUG - 2011-09-06 23:46:04 --> Input Class Initialized
DEBUG - 2011-09-06 23:46:04 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-06 23:46:04 --> Language Class Initialized
DEBUG - 2011-09-06 23:46:04 --> Loader Class Initialized
DEBUG - 2011-09-06 23:46:04 --> Controller Class Initialized
ERROR - 2011-09-06 23:46:04 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-06 23:46:04 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-06 23:46:04 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-06 23:46:04 --> Model Class Initialized
DEBUG - 2011-09-06 23:46:04 --> Model Class Initialized
DEBUG - 2011-09-06 23:46:04 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-06 23:46:04 --> Database Driver Class Initialized
DEBUG - 2011-09-06 23:46:04 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-06 23:46:04 --> Helper loaded: url_helper
DEBUG - 2011-09-06 23:46:04 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-06 23:46:04 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-06 23:46:04 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-06 23:46:04 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-06 23:46:04 --> Final output sent to browser
DEBUG - 2011-09-06 23:46:04 --> Total execution time: 0.0542
DEBUG - 2011-09-06 23:46:06 --> Config Class Initialized
DEBUG - 2011-09-06 23:46:06 --> Hooks Class Initialized
DEBUG - 2011-09-06 23:46:06 --> Utf8 Class Initialized
DEBUG - 2011-09-06 23:46:06 --> UTF-8 Support Enabled
DEBUG - 2011-09-06 23:46:06 --> URI Class Initialized
DEBUG - 2011-09-06 23:46:06 --> Router Class Initialized
DEBUG - 2011-09-06 23:46:06 --> Output Class Initialized
DEBUG - 2011-09-06 23:46:06 --> Input Class Initialized
DEBUG - 2011-09-06 23:46:06 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-06 23:46:06 --> Language Class Initialized
DEBUG - 2011-09-06 23:46:06 --> Loader Class Initialized
DEBUG - 2011-09-06 23:46:06 --> Controller Class Initialized
DEBUG - 2011-09-06 23:46:06 --> Model Class Initialized
DEBUG - 2011-09-06 23:46:06 --> Model Class Initialized
DEBUG - 2011-09-06 23:46:06 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-06 23:46:06 --> Database Driver Class Initialized
DEBUG - 2011-09-06 23:46:07 --> Final output sent to browser
DEBUG - 2011-09-06 23:46:07 --> Total execution time: 0.6046

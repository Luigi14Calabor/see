<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2011-07-17 00:42:27 --> Config Class Initialized
DEBUG - 2011-07-17 00:42:27 --> Hooks Class Initialized
DEBUG - 2011-07-17 00:42:27 --> Utf8 Class Initialized
DEBUG - 2011-07-17 00:42:27 --> UTF-8 Support Enabled
DEBUG - 2011-07-17 00:42:27 --> URI Class Initialized
DEBUG - 2011-07-17 00:42:27 --> Router Class Initialized
DEBUG - 2011-07-17 00:42:27 --> Output Class Initialized
DEBUG - 2011-07-17 00:42:27 --> Input Class Initialized
DEBUG - 2011-07-17 00:42:27 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-17 00:42:27 --> Language Class Initialized
DEBUG - 2011-07-17 00:42:27 --> Loader Class Initialized
DEBUG - 2011-07-17 00:42:27 --> Controller Class Initialized
ERROR - 2011-07-17 00:42:27 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-17 00:42:27 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-17 00:42:27 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-17 00:42:27 --> Model Class Initialized
DEBUG - 2011-07-17 00:42:27 --> Model Class Initialized
DEBUG - 2011-07-17 00:42:27 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-17 00:42:27 --> Database Driver Class Initialized
DEBUG - 2011-07-17 00:42:27 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-17 00:42:27 --> Helper loaded: url_helper
DEBUG - 2011-07-17 00:42:27 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-17 00:42:27 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-17 00:42:27 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-17 00:42:27 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-17 00:42:27 --> Final output sent to browser
DEBUG - 2011-07-17 00:42:27 --> Total execution time: 0.2570
DEBUG - 2011-07-17 00:42:29 --> Config Class Initialized
DEBUG - 2011-07-17 00:42:29 --> Hooks Class Initialized
DEBUG - 2011-07-17 00:42:29 --> Utf8 Class Initialized
DEBUG - 2011-07-17 00:42:29 --> UTF-8 Support Enabled
DEBUG - 2011-07-17 00:42:29 --> URI Class Initialized
DEBUG - 2011-07-17 00:42:29 --> Router Class Initialized
DEBUG - 2011-07-17 00:42:29 --> Output Class Initialized
DEBUG - 2011-07-17 00:42:29 --> Input Class Initialized
DEBUG - 2011-07-17 00:42:29 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-17 00:42:29 --> Language Class Initialized
DEBUG - 2011-07-17 00:42:29 --> Loader Class Initialized
DEBUG - 2011-07-17 00:42:29 --> Controller Class Initialized
DEBUG - 2011-07-17 00:42:29 --> Model Class Initialized
DEBUG - 2011-07-17 00:42:29 --> Model Class Initialized
DEBUG - 2011-07-17 00:42:29 --> Model Class Initialized
DEBUG - 2011-07-17 00:42:29 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-17 00:42:29 --> Database Driver Class Initialized
DEBUG - 2011-07-17 00:42:30 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-17 00:42:30 --> Helper loaded: url_helper
DEBUG - 2011-07-17 00:42:30 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-17 00:42:30 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-17 00:42:30 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-17 00:42:30 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-17 00:42:30 --> Final output sent to browser
DEBUG - 2011-07-17 00:42:30 --> Total execution time: 0.3839
DEBUG - 2011-07-17 00:42:30 --> Config Class Initialized
DEBUG - 2011-07-17 00:42:30 --> Hooks Class Initialized
DEBUG - 2011-07-17 00:42:30 --> Utf8 Class Initialized
DEBUG - 2011-07-17 00:42:30 --> UTF-8 Support Enabled
DEBUG - 2011-07-17 00:42:30 --> URI Class Initialized
DEBUG - 2011-07-17 00:42:30 --> Router Class Initialized
ERROR - 2011-07-17 00:42:30 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-17 00:42:36 --> Config Class Initialized
DEBUG - 2011-07-17 00:42:36 --> Hooks Class Initialized
DEBUG - 2011-07-17 00:42:36 --> Utf8 Class Initialized
DEBUG - 2011-07-17 00:42:36 --> UTF-8 Support Enabled
DEBUG - 2011-07-17 00:42:36 --> URI Class Initialized
DEBUG - 2011-07-17 00:42:36 --> Router Class Initialized
ERROR - 2011-07-17 00:42:36 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-17 00:42:36 --> Config Class Initialized
DEBUG - 2011-07-17 00:42:36 --> Hooks Class Initialized
DEBUG - 2011-07-17 00:42:36 --> Utf8 Class Initialized
DEBUG - 2011-07-17 00:42:36 --> UTF-8 Support Enabled
DEBUG - 2011-07-17 00:42:36 --> URI Class Initialized
DEBUG - 2011-07-17 00:42:36 --> Router Class Initialized
DEBUG - 2011-07-17 00:42:36 --> Output Class Initialized
DEBUG - 2011-07-17 00:42:36 --> Input Class Initialized
DEBUG - 2011-07-17 00:42:36 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-17 00:42:36 --> Language Class Initialized
DEBUG - 2011-07-17 00:42:36 --> Loader Class Initialized
DEBUG - 2011-07-17 00:42:36 --> Controller Class Initialized
DEBUG - 2011-07-17 00:42:36 --> Model Class Initialized
DEBUG - 2011-07-17 00:42:36 --> Model Class Initialized
DEBUG - 2011-07-17 00:42:36 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-17 00:42:36 --> Database Driver Class Initialized
DEBUG - 2011-07-17 00:42:37 --> Final output sent to browser
DEBUG - 2011-07-17 00:42:37 --> Total execution time: 0.8356
DEBUG - 2011-07-17 00:42:38 --> Config Class Initialized
DEBUG - 2011-07-17 00:42:38 --> Hooks Class Initialized
DEBUG - 2011-07-17 00:42:38 --> Utf8 Class Initialized
DEBUG - 2011-07-17 00:42:38 --> UTF-8 Support Enabled
DEBUG - 2011-07-17 00:42:38 --> URI Class Initialized
DEBUG - 2011-07-17 00:42:38 --> Router Class Initialized
ERROR - 2011-07-17 00:42:38 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-17 00:42:39 --> Config Class Initialized
DEBUG - 2011-07-17 00:42:39 --> Hooks Class Initialized
DEBUG - 2011-07-17 00:42:39 --> Utf8 Class Initialized
DEBUG - 2011-07-17 00:42:39 --> UTF-8 Support Enabled
DEBUG - 2011-07-17 00:42:39 --> URI Class Initialized
DEBUG - 2011-07-17 00:42:39 --> Router Class Initialized
ERROR - 2011-07-17 00:42:39 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-17 00:42:40 --> Config Class Initialized
DEBUG - 2011-07-17 00:42:40 --> Hooks Class Initialized
DEBUG - 2011-07-17 00:42:40 --> Utf8 Class Initialized
DEBUG - 2011-07-17 00:42:40 --> UTF-8 Support Enabled
DEBUG - 2011-07-17 00:42:40 --> URI Class Initialized
DEBUG - 2011-07-17 00:42:40 --> Router Class Initialized
ERROR - 2011-07-17 00:42:40 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-17 00:42:52 --> Config Class Initialized
DEBUG - 2011-07-17 00:42:52 --> Hooks Class Initialized
DEBUG - 2011-07-17 00:42:52 --> Utf8 Class Initialized
DEBUG - 2011-07-17 00:42:52 --> UTF-8 Support Enabled
DEBUG - 2011-07-17 00:42:52 --> URI Class Initialized
DEBUG - 2011-07-17 00:42:52 --> Router Class Initialized
ERROR - 2011-07-17 00:42:52 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-17 00:42:56 --> Config Class Initialized
DEBUG - 2011-07-17 00:42:56 --> Hooks Class Initialized
DEBUG - 2011-07-17 00:42:56 --> Utf8 Class Initialized
DEBUG - 2011-07-17 00:42:56 --> UTF-8 Support Enabled
DEBUG - 2011-07-17 00:42:56 --> URI Class Initialized
DEBUG - 2011-07-17 00:42:56 --> Router Class Initialized
ERROR - 2011-07-17 00:42:56 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-17 00:42:57 --> Config Class Initialized
DEBUG - 2011-07-17 00:42:57 --> Hooks Class Initialized
DEBUG - 2011-07-17 00:42:57 --> Utf8 Class Initialized
DEBUG - 2011-07-17 00:42:57 --> UTF-8 Support Enabled
DEBUG - 2011-07-17 00:42:57 --> URI Class Initialized
DEBUG - 2011-07-17 00:42:57 --> Router Class Initialized
ERROR - 2011-07-17 00:42:57 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-17 02:43:59 --> Config Class Initialized
DEBUG - 2011-07-17 02:43:59 --> Hooks Class Initialized
DEBUG - 2011-07-17 02:43:59 --> Utf8 Class Initialized
DEBUG - 2011-07-17 02:43:59 --> UTF-8 Support Enabled
DEBUG - 2011-07-17 02:43:59 --> URI Class Initialized
DEBUG - 2011-07-17 02:43:59 --> Router Class Initialized
DEBUG - 2011-07-17 02:43:59 --> Output Class Initialized
DEBUG - 2011-07-17 02:43:59 --> Input Class Initialized
DEBUG - 2011-07-17 02:43:59 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-17 02:43:59 --> Language Class Initialized
DEBUG - 2011-07-17 02:43:59 --> Loader Class Initialized
DEBUG - 2011-07-17 02:43:59 --> Controller Class Initialized
DEBUG - 2011-07-17 02:43:59 --> Model Class Initialized
DEBUG - 2011-07-17 02:43:59 --> Model Class Initialized
DEBUG - 2011-07-17 02:43:59 --> Model Class Initialized
DEBUG - 2011-07-17 02:43:59 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-17 02:43:59 --> Database Driver Class Initialized
DEBUG - 2011-07-17 02:44:00 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-17 02:44:00 --> Helper loaded: url_helper
DEBUG - 2011-07-17 02:44:00 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-17 02:44:00 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-17 02:44:00 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-17 02:44:00 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-17 02:44:00 --> Final output sent to browser
DEBUG - 2011-07-17 02:44:00 --> Total execution time: 0.9061
DEBUG - 2011-07-17 02:49:02 --> Config Class Initialized
DEBUG - 2011-07-17 02:49:02 --> Hooks Class Initialized
DEBUG - 2011-07-17 02:49:02 --> Utf8 Class Initialized
DEBUG - 2011-07-17 02:49:02 --> UTF-8 Support Enabled
DEBUG - 2011-07-17 02:49:02 --> URI Class Initialized
DEBUG - 2011-07-17 02:49:02 --> Router Class Initialized
ERROR - 2011-07-17 02:49:02 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-07-17 02:49:57 --> Config Class Initialized
DEBUG - 2011-07-17 02:49:57 --> Hooks Class Initialized
DEBUG - 2011-07-17 02:49:57 --> Utf8 Class Initialized
DEBUG - 2011-07-17 02:49:57 --> UTF-8 Support Enabled
DEBUG - 2011-07-17 02:49:57 --> URI Class Initialized
DEBUG - 2011-07-17 02:49:57 --> Router Class Initialized
DEBUG - 2011-07-17 02:49:57 --> Output Class Initialized
DEBUG - 2011-07-17 02:49:57 --> Input Class Initialized
DEBUG - 2011-07-17 02:49:57 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-17 02:49:57 --> Language Class Initialized
DEBUG - 2011-07-17 02:49:57 --> Loader Class Initialized
DEBUG - 2011-07-17 02:49:57 --> Controller Class Initialized
ERROR - 2011-07-17 02:49:57 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-17 02:49:57 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-17 02:49:57 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-17 02:49:57 --> Model Class Initialized
DEBUG - 2011-07-17 02:49:57 --> Model Class Initialized
DEBUG - 2011-07-17 02:49:57 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-17 02:49:57 --> Database Driver Class Initialized
DEBUG - 2011-07-17 02:49:57 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-17 02:49:57 --> Helper loaded: url_helper
DEBUG - 2011-07-17 02:49:57 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-17 02:49:57 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-17 02:49:57 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-17 02:49:57 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-17 02:49:57 --> Final output sent to browser
DEBUG - 2011-07-17 02:49:57 --> Total execution time: 0.1091
DEBUG - 2011-07-17 03:06:07 --> Config Class Initialized
DEBUG - 2011-07-17 03:06:07 --> Hooks Class Initialized
DEBUG - 2011-07-17 03:06:07 --> Utf8 Class Initialized
DEBUG - 2011-07-17 03:06:07 --> UTF-8 Support Enabled
DEBUG - 2011-07-17 03:06:07 --> URI Class Initialized
DEBUG - 2011-07-17 03:06:07 --> Router Class Initialized
DEBUG - 2011-07-17 03:06:07 --> Output Class Initialized
DEBUG - 2011-07-17 03:06:07 --> Input Class Initialized
DEBUG - 2011-07-17 03:06:07 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-17 03:06:07 --> Language Class Initialized
DEBUG - 2011-07-17 03:06:07 --> Loader Class Initialized
DEBUG - 2011-07-17 03:06:07 --> Controller Class Initialized
DEBUG - 2011-07-17 03:06:07 --> Model Class Initialized
DEBUG - 2011-07-17 03:06:07 --> Model Class Initialized
DEBUG - 2011-07-17 03:06:07 --> Model Class Initialized
DEBUG - 2011-07-17 03:06:07 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-17 03:06:07 --> Database Driver Class Initialized
DEBUG - 2011-07-17 03:06:07 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-17 03:06:07 --> Helper loaded: url_helper
DEBUG - 2011-07-17 03:06:07 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-17 03:06:07 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-17 03:06:07 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-17 03:06:07 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-17 03:06:07 --> Final output sent to browser
DEBUG - 2011-07-17 03:06:07 --> Total execution time: 0.4342
DEBUG - 2011-07-17 03:06:18 --> Config Class Initialized
DEBUG - 2011-07-17 03:06:18 --> Hooks Class Initialized
DEBUG - 2011-07-17 03:06:18 --> Utf8 Class Initialized
DEBUG - 2011-07-17 03:06:18 --> UTF-8 Support Enabled
DEBUG - 2011-07-17 03:06:18 --> URI Class Initialized
DEBUG - 2011-07-17 03:06:18 --> Router Class Initialized
ERROR - 2011-07-17 03:06:18 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-17 03:07:08 --> Config Class Initialized
DEBUG - 2011-07-17 03:07:08 --> Hooks Class Initialized
DEBUG - 2011-07-17 03:07:08 --> Utf8 Class Initialized
DEBUG - 2011-07-17 03:07:08 --> UTF-8 Support Enabled
DEBUG - 2011-07-17 03:07:08 --> URI Class Initialized
DEBUG - 2011-07-17 03:07:08 --> Router Class Initialized
DEBUG - 2011-07-17 03:07:08 --> Output Class Initialized
DEBUG - 2011-07-17 03:07:08 --> Input Class Initialized
DEBUG - 2011-07-17 03:07:08 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-17 03:07:08 --> Language Class Initialized
DEBUG - 2011-07-17 03:07:08 --> Loader Class Initialized
DEBUG - 2011-07-17 03:07:08 --> Controller Class Initialized
DEBUG - 2011-07-17 03:07:08 --> Model Class Initialized
DEBUG - 2011-07-17 03:07:08 --> Model Class Initialized
DEBUG - 2011-07-17 03:07:08 --> Model Class Initialized
DEBUG - 2011-07-17 03:07:08 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-17 03:07:08 --> Database Driver Class Initialized
DEBUG - 2011-07-17 03:07:08 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-17 03:07:08 --> Helper loaded: url_helper
DEBUG - 2011-07-17 03:07:08 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-17 03:07:08 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-17 03:07:08 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-17 03:07:08 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-17 03:07:08 --> Final output sent to browser
DEBUG - 2011-07-17 03:07:08 --> Total execution time: 0.2651
DEBUG - 2011-07-17 03:07:10 --> Config Class Initialized
DEBUG - 2011-07-17 03:07:10 --> Hooks Class Initialized
DEBUG - 2011-07-17 03:07:10 --> Utf8 Class Initialized
DEBUG - 2011-07-17 03:07:10 --> UTF-8 Support Enabled
DEBUG - 2011-07-17 03:07:10 --> URI Class Initialized
DEBUG - 2011-07-17 03:07:10 --> Router Class Initialized
DEBUG - 2011-07-17 03:07:10 --> Output Class Initialized
DEBUG - 2011-07-17 03:07:10 --> Input Class Initialized
DEBUG - 2011-07-17 03:07:10 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-17 03:07:10 --> Language Class Initialized
DEBUG - 2011-07-17 03:07:10 --> Loader Class Initialized
DEBUG - 2011-07-17 03:07:10 --> Controller Class Initialized
DEBUG - 2011-07-17 03:07:10 --> Model Class Initialized
DEBUG - 2011-07-17 03:07:10 --> Model Class Initialized
DEBUG - 2011-07-17 03:07:10 --> Model Class Initialized
DEBUG - 2011-07-17 03:07:10 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-17 03:07:10 --> Database Driver Class Initialized
DEBUG - 2011-07-17 03:07:10 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-17 03:07:10 --> Helper loaded: url_helper
DEBUG - 2011-07-17 03:07:10 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-17 03:07:10 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-17 03:07:10 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-17 03:07:10 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-17 03:07:10 --> Final output sent to browser
DEBUG - 2011-07-17 03:07:10 --> Total execution time: 0.0653
DEBUG - 2011-07-17 03:07:12 --> Config Class Initialized
DEBUG - 2011-07-17 03:07:12 --> Hooks Class Initialized
DEBUG - 2011-07-17 03:07:12 --> Utf8 Class Initialized
DEBUG - 2011-07-17 03:07:12 --> UTF-8 Support Enabled
DEBUG - 2011-07-17 03:07:12 --> URI Class Initialized
DEBUG - 2011-07-17 03:07:12 --> Router Class Initialized
ERROR - 2011-07-17 03:07:12 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-17 03:07:41 --> Config Class Initialized
DEBUG - 2011-07-17 03:07:41 --> Hooks Class Initialized
DEBUG - 2011-07-17 03:07:41 --> Utf8 Class Initialized
DEBUG - 2011-07-17 03:07:41 --> UTF-8 Support Enabled
DEBUG - 2011-07-17 03:07:41 --> URI Class Initialized
DEBUG - 2011-07-17 03:07:41 --> Router Class Initialized
DEBUG - 2011-07-17 03:07:41 --> Output Class Initialized
DEBUG - 2011-07-17 03:07:41 --> Input Class Initialized
DEBUG - 2011-07-17 03:07:41 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-17 03:07:41 --> Language Class Initialized
DEBUG - 2011-07-17 03:07:41 --> Loader Class Initialized
DEBUG - 2011-07-17 03:07:41 --> Controller Class Initialized
DEBUG - 2011-07-17 03:07:41 --> Model Class Initialized
DEBUG - 2011-07-17 03:07:41 --> Model Class Initialized
DEBUG - 2011-07-17 03:07:41 --> Model Class Initialized
DEBUG - 2011-07-17 03:07:41 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-17 03:07:41 --> Database Driver Class Initialized
DEBUG - 2011-07-17 03:07:41 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-17 03:07:41 --> Helper loaded: url_helper
DEBUG - 2011-07-17 03:07:41 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-17 03:07:41 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-17 03:07:41 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-17 03:07:41 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-17 03:07:41 --> Final output sent to browser
DEBUG - 2011-07-17 03:07:41 --> Total execution time: 0.2041
DEBUG - 2011-07-17 03:07:44 --> Config Class Initialized
DEBUG - 2011-07-17 03:07:44 --> Hooks Class Initialized
DEBUG - 2011-07-17 03:07:44 --> Utf8 Class Initialized
DEBUG - 2011-07-17 03:07:44 --> UTF-8 Support Enabled
DEBUG - 2011-07-17 03:07:44 --> URI Class Initialized
DEBUG - 2011-07-17 03:07:44 --> Router Class Initialized
ERROR - 2011-07-17 03:07:44 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-17 03:07:45 --> Config Class Initialized
DEBUG - 2011-07-17 03:07:45 --> Hooks Class Initialized
DEBUG - 2011-07-17 03:07:45 --> Utf8 Class Initialized
DEBUG - 2011-07-17 03:07:45 --> UTF-8 Support Enabled
DEBUG - 2011-07-17 03:07:45 --> URI Class Initialized
DEBUG - 2011-07-17 03:07:45 --> Router Class Initialized
DEBUG - 2011-07-17 03:07:45 --> Output Class Initialized
DEBUG - 2011-07-17 03:07:45 --> Input Class Initialized
DEBUG - 2011-07-17 03:07:45 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-17 03:07:45 --> Language Class Initialized
DEBUG - 2011-07-17 03:07:45 --> Loader Class Initialized
DEBUG - 2011-07-17 03:07:45 --> Controller Class Initialized
DEBUG - 2011-07-17 03:07:45 --> Model Class Initialized
DEBUG - 2011-07-17 03:07:45 --> Model Class Initialized
DEBUG - 2011-07-17 03:07:45 --> Model Class Initialized
DEBUG - 2011-07-17 03:07:45 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-17 03:07:45 --> Database Driver Class Initialized
DEBUG - 2011-07-17 03:07:45 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-17 03:07:45 --> Helper loaded: url_helper
DEBUG - 2011-07-17 03:07:45 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-17 03:07:45 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-17 03:07:45 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-17 03:07:45 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-17 03:07:45 --> Final output sent to browser
DEBUG - 2011-07-17 03:07:45 --> Total execution time: 0.0441
DEBUG - 2011-07-17 03:08:04 --> Config Class Initialized
DEBUG - 2011-07-17 03:08:04 --> Hooks Class Initialized
DEBUG - 2011-07-17 03:08:04 --> Utf8 Class Initialized
DEBUG - 2011-07-17 03:08:04 --> UTF-8 Support Enabled
DEBUG - 2011-07-17 03:08:04 --> URI Class Initialized
DEBUG - 2011-07-17 03:08:04 --> Router Class Initialized
DEBUG - 2011-07-17 03:08:04 --> Output Class Initialized
DEBUG - 2011-07-17 03:08:04 --> Input Class Initialized
DEBUG - 2011-07-17 03:08:04 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-17 03:08:04 --> Language Class Initialized
DEBUG - 2011-07-17 03:08:04 --> Loader Class Initialized
DEBUG - 2011-07-17 03:08:04 --> Controller Class Initialized
DEBUG - 2011-07-17 03:08:04 --> Model Class Initialized
DEBUG - 2011-07-17 03:08:04 --> Model Class Initialized
DEBUG - 2011-07-17 03:08:04 --> Model Class Initialized
DEBUG - 2011-07-17 03:08:04 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-17 03:08:04 --> Database Driver Class Initialized
DEBUG - 2011-07-17 03:08:04 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-17 03:08:04 --> Helper loaded: url_helper
DEBUG - 2011-07-17 03:08:04 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-17 03:08:04 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-17 03:08:04 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-17 03:08:04 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-17 03:08:04 --> Final output sent to browser
DEBUG - 2011-07-17 03:08:04 --> Total execution time: 0.4583
DEBUG - 2011-07-17 03:08:06 --> Config Class Initialized
DEBUG - 2011-07-17 03:08:06 --> Hooks Class Initialized
DEBUG - 2011-07-17 03:08:06 --> Utf8 Class Initialized
DEBUG - 2011-07-17 03:08:06 --> UTF-8 Support Enabled
DEBUG - 2011-07-17 03:08:06 --> URI Class Initialized
DEBUG - 2011-07-17 03:08:06 --> Router Class Initialized
DEBUG - 2011-07-17 03:08:06 --> Output Class Initialized
DEBUG - 2011-07-17 03:08:06 --> Input Class Initialized
DEBUG - 2011-07-17 03:08:06 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-17 03:08:06 --> Language Class Initialized
DEBUG - 2011-07-17 03:08:06 --> Loader Class Initialized
DEBUG - 2011-07-17 03:08:06 --> Controller Class Initialized
DEBUG - 2011-07-17 03:08:06 --> Model Class Initialized
DEBUG - 2011-07-17 03:08:06 --> Model Class Initialized
DEBUG - 2011-07-17 03:08:06 --> Model Class Initialized
DEBUG - 2011-07-17 03:08:06 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-17 03:08:06 --> Database Driver Class Initialized
DEBUG - 2011-07-17 03:08:06 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-17 03:08:06 --> Helper loaded: url_helper
DEBUG - 2011-07-17 03:08:06 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-17 03:08:06 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-17 03:08:06 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-17 03:08:06 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-17 03:08:06 --> Final output sent to browser
DEBUG - 2011-07-17 03:08:06 --> Total execution time: 0.0524
DEBUG - 2011-07-17 03:08:11 --> Config Class Initialized
DEBUG - 2011-07-17 03:08:11 --> Hooks Class Initialized
DEBUG - 2011-07-17 03:08:11 --> Utf8 Class Initialized
DEBUG - 2011-07-17 03:08:11 --> UTF-8 Support Enabled
DEBUG - 2011-07-17 03:08:11 --> URI Class Initialized
DEBUG - 2011-07-17 03:08:11 --> Router Class Initialized
ERROR - 2011-07-17 03:08:11 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-17 03:09:17 --> Config Class Initialized
DEBUG - 2011-07-17 03:09:17 --> Hooks Class Initialized
DEBUG - 2011-07-17 03:09:17 --> Utf8 Class Initialized
DEBUG - 2011-07-17 03:09:17 --> UTF-8 Support Enabled
DEBUG - 2011-07-17 03:09:17 --> URI Class Initialized
DEBUG - 2011-07-17 03:09:17 --> Router Class Initialized
ERROR - 2011-07-17 03:09:17 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-17 03:09:30 --> Config Class Initialized
DEBUG - 2011-07-17 03:09:30 --> Hooks Class Initialized
DEBUG - 2011-07-17 03:09:30 --> Utf8 Class Initialized
DEBUG - 2011-07-17 03:09:30 --> UTF-8 Support Enabled
DEBUG - 2011-07-17 03:09:30 --> URI Class Initialized
DEBUG - 2011-07-17 03:09:30 --> Router Class Initialized
DEBUG - 2011-07-17 03:09:30 --> Output Class Initialized
DEBUG - 2011-07-17 03:09:30 --> Input Class Initialized
DEBUG - 2011-07-17 03:09:30 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-17 03:09:30 --> Language Class Initialized
DEBUG - 2011-07-17 03:09:30 --> Loader Class Initialized
DEBUG - 2011-07-17 03:09:30 --> Controller Class Initialized
DEBUG - 2011-07-17 03:09:30 --> Model Class Initialized
DEBUG - 2011-07-17 03:09:30 --> Model Class Initialized
DEBUG - 2011-07-17 03:09:30 --> Model Class Initialized
DEBUG - 2011-07-17 03:09:30 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-17 03:09:30 --> Database Driver Class Initialized
DEBUG - 2011-07-17 03:09:30 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-17 03:09:30 --> Helper loaded: url_helper
DEBUG - 2011-07-17 03:09:30 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-17 03:09:30 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-17 03:09:30 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-17 03:09:30 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-17 03:09:30 --> Final output sent to browser
DEBUG - 2011-07-17 03:09:30 --> Total execution time: 0.1951
DEBUG - 2011-07-17 03:09:33 --> Config Class Initialized
DEBUG - 2011-07-17 03:09:33 --> Hooks Class Initialized
DEBUG - 2011-07-17 03:09:33 --> Utf8 Class Initialized
DEBUG - 2011-07-17 03:09:33 --> UTF-8 Support Enabled
DEBUG - 2011-07-17 03:09:33 --> URI Class Initialized
DEBUG - 2011-07-17 03:09:33 --> Router Class Initialized
ERROR - 2011-07-17 03:09:33 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-17 03:09:35 --> Config Class Initialized
DEBUG - 2011-07-17 03:09:35 --> Hooks Class Initialized
DEBUG - 2011-07-17 03:09:35 --> Utf8 Class Initialized
DEBUG - 2011-07-17 03:09:35 --> UTF-8 Support Enabled
DEBUG - 2011-07-17 03:09:35 --> URI Class Initialized
DEBUG - 2011-07-17 03:09:35 --> Router Class Initialized
DEBUG - 2011-07-17 03:09:35 --> Output Class Initialized
DEBUG - 2011-07-17 03:09:35 --> Input Class Initialized
DEBUG - 2011-07-17 03:09:35 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-17 03:09:35 --> Language Class Initialized
DEBUG - 2011-07-17 03:09:35 --> Loader Class Initialized
DEBUG - 2011-07-17 03:09:35 --> Controller Class Initialized
DEBUG - 2011-07-17 03:09:35 --> Model Class Initialized
DEBUG - 2011-07-17 03:09:35 --> Model Class Initialized
DEBUG - 2011-07-17 03:09:35 --> Model Class Initialized
DEBUG - 2011-07-17 03:09:35 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-17 03:09:35 --> Database Driver Class Initialized
DEBUG - 2011-07-17 03:09:35 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-17 03:09:35 --> Helper loaded: url_helper
DEBUG - 2011-07-17 03:09:35 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-17 03:09:35 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-17 03:09:35 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-17 03:09:35 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-17 03:09:35 --> Final output sent to browser
DEBUG - 2011-07-17 03:09:35 --> Total execution time: 0.0602
DEBUG - 2011-07-17 03:10:04 --> Config Class Initialized
DEBUG - 2011-07-17 03:10:04 --> Hooks Class Initialized
DEBUG - 2011-07-17 03:10:04 --> Utf8 Class Initialized
DEBUG - 2011-07-17 03:10:04 --> UTF-8 Support Enabled
DEBUG - 2011-07-17 03:10:04 --> URI Class Initialized
DEBUG - 2011-07-17 03:10:04 --> Router Class Initialized
DEBUG - 2011-07-17 03:10:04 --> Output Class Initialized
DEBUG - 2011-07-17 03:10:04 --> Input Class Initialized
DEBUG - 2011-07-17 03:10:04 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-17 03:10:04 --> Language Class Initialized
DEBUG - 2011-07-17 03:10:04 --> Loader Class Initialized
DEBUG - 2011-07-17 03:10:04 --> Controller Class Initialized
DEBUG - 2011-07-17 03:10:04 --> Model Class Initialized
DEBUG - 2011-07-17 03:10:04 --> Model Class Initialized
DEBUG - 2011-07-17 03:10:04 --> Model Class Initialized
DEBUG - 2011-07-17 03:10:04 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-17 03:10:04 --> Database Driver Class Initialized
DEBUG - 2011-07-17 03:10:04 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-17 03:10:04 --> Helper loaded: url_helper
DEBUG - 2011-07-17 03:10:04 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-17 03:10:04 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-17 03:10:04 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-17 03:10:04 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-17 03:10:04 --> Final output sent to browser
DEBUG - 2011-07-17 03:10:04 --> Total execution time: 0.4216
DEBUG - 2011-07-17 03:10:07 --> Config Class Initialized
DEBUG - 2011-07-17 03:10:07 --> Hooks Class Initialized
DEBUG - 2011-07-17 03:10:07 --> Utf8 Class Initialized
DEBUG - 2011-07-17 03:10:07 --> UTF-8 Support Enabled
DEBUG - 2011-07-17 03:10:07 --> URI Class Initialized
DEBUG - 2011-07-17 03:10:07 --> Router Class Initialized
ERROR - 2011-07-17 03:10:07 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-17 03:10:10 --> Config Class Initialized
DEBUG - 2011-07-17 03:10:10 --> Hooks Class Initialized
DEBUG - 2011-07-17 03:10:10 --> Utf8 Class Initialized
DEBUG - 2011-07-17 03:10:10 --> UTF-8 Support Enabled
DEBUG - 2011-07-17 03:10:10 --> URI Class Initialized
DEBUG - 2011-07-17 03:10:10 --> Router Class Initialized
DEBUG - 2011-07-17 03:10:10 --> Output Class Initialized
DEBUG - 2011-07-17 03:10:10 --> Input Class Initialized
DEBUG - 2011-07-17 03:10:10 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-17 03:10:10 --> Language Class Initialized
DEBUG - 2011-07-17 03:10:10 --> Loader Class Initialized
DEBUG - 2011-07-17 03:10:10 --> Controller Class Initialized
DEBUG - 2011-07-17 03:10:10 --> Model Class Initialized
DEBUG - 2011-07-17 03:10:10 --> Model Class Initialized
DEBUG - 2011-07-17 03:10:10 --> Model Class Initialized
DEBUG - 2011-07-17 03:10:10 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-17 03:10:10 --> Database Driver Class Initialized
DEBUG - 2011-07-17 03:10:10 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-17 03:10:10 --> Helper loaded: url_helper
DEBUG - 2011-07-17 03:10:10 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-17 03:10:10 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-17 03:10:10 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-17 03:10:10 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-17 03:10:10 --> Final output sent to browser
DEBUG - 2011-07-17 03:10:10 --> Total execution time: 0.0783
DEBUG - 2011-07-17 03:10:16 --> Config Class Initialized
DEBUG - 2011-07-17 03:10:16 --> Hooks Class Initialized
DEBUG - 2011-07-17 03:10:16 --> Utf8 Class Initialized
DEBUG - 2011-07-17 03:10:16 --> UTF-8 Support Enabled
DEBUG - 2011-07-17 03:10:16 --> URI Class Initialized
DEBUG - 2011-07-17 03:10:16 --> Router Class Initialized
DEBUG - 2011-07-17 03:10:16 --> Output Class Initialized
DEBUG - 2011-07-17 03:10:16 --> Input Class Initialized
DEBUG - 2011-07-17 03:10:16 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-17 03:10:16 --> Language Class Initialized
DEBUG - 2011-07-17 03:10:16 --> Loader Class Initialized
DEBUG - 2011-07-17 03:10:16 --> Controller Class Initialized
DEBUG - 2011-07-17 03:10:16 --> Model Class Initialized
DEBUG - 2011-07-17 03:10:16 --> Model Class Initialized
DEBUG - 2011-07-17 03:10:16 --> Model Class Initialized
DEBUG - 2011-07-17 03:10:16 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-17 03:10:16 --> Database Driver Class Initialized
DEBUG - 2011-07-17 03:10:16 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-17 03:10:16 --> Helper loaded: url_helper
DEBUG - 2011-07-17 03:10:16 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-17 03:10:16 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-17 03:10:16 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-17 03:10:16 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-17 03:10:16 --> Final output sent to browser
DEBUG - 2011-07-17 03:10:16 --> Total execution time: 0.1821
DEBUG - 2011-07-17 03:10:20 --> Config Class Initialized
DEBUG - 2011-07-17 03:10:20 --> Hooks Class Initialized
DEBUG - 2011-07-17 03:10:20 --> Utf8 Class Initialized
DEBUG - 2011-07-17 03:10:20 --> UTF-8 Support Enabled
DEBUG - 2011-07-17 03:10:20 --> URI Class Initialized
DEBUG - 2011-07-17 03:10:20 --> Router Class Initialized
ERROR - 2011-07-17 03:10:20 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-17 03:10:24 --> Config Class Initialized
DEBUG - 2011-07-17 03:10:24 --> Hooks Class Initialized
DEBUG - 2011-07-17 03:10:24 --> Utf8 Class Initialized
DEBUG - 2011-07-17 03:10:24 --> UTF-8 Support Enabled
DEBUG - 2011-07-17 03:10:24 --> URI Class Initialized
DEBUG - 2011-07-17 03:10:24 --> Router Class Initialized
DEBUG - 2011-07-17 03:10:24 --> Output Class Initialized
DEBUG - 2011-07-17 03:10:24 --> Input Class Initialized
DEBUG - 2011-07-17 03:10:24 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-17 03:10:24 --> Language Class Initialized
DEBUG - 2011-07-17 03:10:24 --> Loader Class Initialized
DEBUG - 2011-07-17 03:10:24 --> Controller Class Initialized
DEBUG - 2011-07-17 03:10:24 --> Model Class Initialized
DEBUG - 2011-07-17 03:10:24 --> Model Class Initialized
DEBUG - 2011-07-17 03:10:24 --> Model Class Initialized
DEBUG - 2011-07-17 03:10:24 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-17 03:10:24 --> Database Driver Class Initialized
DEBUG - 2011-07-17 03:10:24 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-17 03:10:24 --> Helper loaded: url_helper
DEBUG - 2011-07-17 03:10:24 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-17 03:10:24 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-17 03:10:24 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-17 03:10:24 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-17 03:10:24 --> Final output sent to browser
DEBUG - 2011-07-17 03:10:24 --> Total execution time: 0.0472
DEBUG - 2011-07-17 03:10:43 --> Config Class Initialized
DEBUG - 2011-07-17 03:10:43 --> Hooks Class Initialized
DEBUG - 2011-07-17 03:10:43 --> Utf8 Class Initialized
DEBUG - 2011-07-17 03:10:43 --> UTF-8 Support Enabled
DEBUG - 2011-07-17 03:10:43 --> URI Class Initialized
DEBUG - 2011-07-17 03:10:43 --> Router Class Initialized
DEBUG - 2011-07-17 03:10:43 --> Output Class Initialized
DEBUG - 2011-07-17 03:10:43 --> Input Class Initialized
DEBUG - 2011-07-17 03:10:43 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-17 03:10:43 --> Language Class Initialized
DEBUG - 2011-07-17 03:10:43 --> Loader Class Initialized
DEBUG - 2011-07-17 03:10:43 --> Controller Class Initialized
DEBUG - 2011-07-17 03:10:43 --> Model Class Initialized
DEBUG - 2011-07-17 03:10:43 --> Model Class Initialized
DEBUG - 2011-07-17 03:10:43 --> Model Class Initialized
DEBUG - 2011-07-17 03:10:43 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-17 03:10:43 --> Database Driver Class Initialized
DEBUG - 2011-07-17 03:10:43 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-17 03:10:43 --> Helper loaded: url_helper
DEBUG - 2011-07-17 03:10:43 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-17 03:10:43 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-17 03:10:43 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-17 03:10:43 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-17 03:10:43 --> Final output sent to browser
DEBUG - 2011-07-17 03:10:43 --> Total execution time: 0.2413
DEBUG - 2011-07-17 03:10:46 --> Config Class Initialized
DEBUG - 2011-07-17 03:10:46 --> Hooks Class Initialized
DEBUG - 2011-07-17 03:10:46 --> Utf8 Class Initialized
DEBUG - 2011-07-17 03:10:46 --> UTF-8 Support Enabled
DEBUG - 2011-07-17 03:10:46 --> URI Class Initialized
DEBUG - 2011-07-17 03:10:46 --> Router Class Initialized
DEBUG - 2011-07-17 03:10:46 --> Output Class Initialized
DEBUG - 2011-07-17 03:10:46 --> Input Class Initialized
DEBUG - 2011-07-17 03:10:46 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-17 03:10:46 --> Language Class Initialized
DEBUG - 2011-07-17 03:10:46 --> Loader Class Initialized
DEBUG - 2011-07-17 03:10:46 --> Controller Class Initialized
DEBUG - 2011-07-17 03:10:46 --> Model Class Initialized
DEBUG - 2011-07-17 03:10:46 --> Model Class Initialized
DEBUG - 2011-07-17 03:10:46 --> Model Class Initialized
DEBUG - 2011-07-17 03:10:46 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-17 03:10:46 --> Database Driver Class Initialized
DEBUG - 2011-07-17 03:10:46 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-17 03:10:46 --> Helper loaded: url_helper
DEBUG - 2011-07-17 03:10:46 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-17 03:10:46 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-17 03:10:46 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-17 03:10:46 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-17 03:10:46 --> Final output sent to browser
DEBUG - 2011-07-17 03:10:46 --> Total execution time: 0.0439
DEBUG - 2011-07-17 03:10:47 --> Config Class Initialized
DEBUG - 2011-07-17 03:10:47 --> Hooks Class Initialized
DEBUG - 2011-07-17 03:10:47 --> Utf8 Class Initialized
DEBUG - 2011-07-17 03:10:47 --> UTF-8 Support Enabled
DEBUG - 2011-07-17 03:10:47 --> URI Class Initialized
DEBUG - 2011-07-17 03:10:47 --> Router Class Initialized
ERROR - 2011-07-17 03:10:47 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-17 03:11:04 --> Config Class Initialized
DEBUG - 2011-07-17 03:11:04 --> Hooks Class Initialized
DEBUG - 2011-07-17 03:11:04 --> Utf8 Class Initialized
DEBUG - 2011-07-17 03:11:04 --> UTF-8 Support Enabled
DEBUG - 2011-07-17 03:11:04 --> URI Class Initialized
DEBUG - 2011-07-17 03:11:04 --> Router Class Initialized
DEBUG - 2011-07-17 03:11:04 --> Output Class Initialized
DEBUG - 2011-07-17 03:11:04 --> Input Class Initialized
DEBUG - 2011-07-17 03:11:04 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-17 03:11:04 --> Language Class Initialized
DEBUG - 2011-07-17 03:11:04 --> Loader Class Initialized
DEBUG - 2011-07-17 03:11:04 --> Controller Class Initialized
DEBUG - 2011-07-17 03:11:04 --> Model Class Initialized
DEBUG - 2011-07-17 03:11:04 --> Model Class Initialized
DEBUG - 2011-07-17 03:11:04 --> Model Class Initialized
DEBUG - 2011-07-17 03:11:04 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-17 03:11:04 --> Database Driver Class Initialized
DEBUG - 2011-07-17 03:11:04 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-17 03:11:04 --> Helper loaded: url_helper
DEBUG - 2011-07-17 03:11:04 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-17 03:11:04 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-17 03:11:04 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-17 03:11:04 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-17 03:11:04 --> Final output sent to browser
DEBUG - 2011-07-17 03:11:04 --> Total execution time: 0.2267
DEBUG - 2011-07-17 03:11:07 --> Config Class Initialized
DEBUG - 2011-07-17 03:11:07 --> Hooks Class Initialized
DEBUG - 2011-07-17 03:11:07 --> Utf8 Class Initialized
DEBUG - 2011-07-17 03:11:07 --> UTF-8 Support Enabled
DEBUG - 2011-07-17 03:11:07 --> URI Class Initialized
DEBUG - 2011-07-17 03:11:07 --> Router Class Initialized
DEBUG - 2011-07-17 03:11:07 --> Output Class Initialized
DEBUG - 2011-07-17 03:11:07 --> Input Class Initialized
DEBUG - 2011-07-17 03:11:07 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-17 03:11:07 --> Language Class Initialized
DEBUG - 2011-07-17 03:11:07 --> Loader Class Initialized
DEBUG - 2011-07-17 03:11:07 --> Controller Class Initialized
DEBUG - 2011-07-17 03:11:07 --> Model Class Initialized
DEBUG - 2011-07-17 03:11:07 --> Model Class Initialized
DEBUG - 2011-07-17 03:11:07 --> Model Class Initialized
DEBUG - 2011-07-17 03:11:07 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-17 03:11:07 --> Database Driver Class Initialized
DEBUG - 2011-07-17 03:11:07 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-17 03:11:07 --> Helper loaded: url_helper
DEBUG - 2011-07-17 03:11:07 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-17 03:11:07 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-17 03:11:07 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-17 03:11:07 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-17 03:11:07 --> Final output sent to browser
DEBUG - 2011-07-17 03:11:07 --> Total execution time: 0.0464
DEBUG - 2011-07-17 03:11:10 --> Config Class Initialized
DEBUG - 2011-07-17 03:11:10 --> Hooks Class Initialized
DEBUG - 2011-07-17 03:11:10 --> Utf8 Class Initialized
DEBUG - 2011-07-17 03:11:10 --> UTF-8 Support Enabled
DEBUG - 2011-07-17 03:11:10 --> URI Class Initialized
DEBUG - 2011-07-17 03:11:10 --> Router Class Initialized
ERROR - 2011-07-17 03:11:10 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-17 03:11:19 --> Config Class Initialized
DEBUG - 2011-07-17 03:11:19 --> Hooks Class Initialized
DEBUG - 2011-07-17 03:11:19 --> Utf8 Class Initialized
DEBUG - 2011-07-17 03:11:19 --> UTF-8 Support Enabled
DEBUG - 2011-07-17 03:11:19 --> URI Class Initialized
DEBUG - 2011-07-17 03:11:19 --> Router Class Initialized
DEBUG - 2011-07-17 03:11:19 --> Output Class Initialized
DEBUG - 2011-07-17 03:11:19 --> Input Class Initialized
DEBUG - 2011-07-17 03:11:19 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-17 03:11:19 --> Language Class Initialized
DEBUG - 2011-07-17 03:11:19 --> Loader Class Initialized
DEBUG - 2011-07-17 03:11:19 --> Controller Class Initialized
DEBUG - 2011-07-17 03:11:19 --> Model Class Initialized
DEBUG - 2011-07-17 03:11:19 --> Model Class Initialized
DEBUG - 2011-07-17 03:11:19 --> Model Class Initialized
DEBUG - 2011-07-17 03:11:19 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-17 03:11:19 --> Database Driver Class Initialized
DEBUG - 2011-07-17 03:11:19 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-17 03:11:19 --> Helper loaded: url_helper
DEBUG - 2011-07-17 03:11:19 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-17 03:11:19 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-17 03:11:19 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-17 03:11:19 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-17 03:11:19 --> Final output sent to browser
DEBUG - 2011-07-17 03:11:19 --> Total execution time: 0.2475
DEBUG - 2011-07-17 03:11:21 --> Config Class Initialized
DEBUG - 2011-07-17 03:11:21 --> Hooks Class Initialized
DEBUG - 2011-07-17 03:11:21 --> Utf8 Class Initialized
DEBUG - 2011-07-17 03:11:21 --> UTF-8 Support Enabled
DEBUG - 2011-07-17 03:11:21 --> URI Class Initialized
DEBUG - 2011-07-17 03:11:21 --> Router Class Initialized
DEBUG - 2011-07-17 03:11:21 --> Output Class Initialized
DEBUG - 2011-07-17 03:11:21 --> Input Class Initialized
DEBUG - 2011-07-17 03:11:21 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-17 03:11:21 --> Language Class Initialized
DEBUG - 2011-07-17 03:11:21 --> Loader Class Initialized
DEBUG - 2011-07-17 03:11:21 --> Controller Class Initialized
DEBUG - 2011-07-17 03:11:21 --> Model Class Initialized
DEBUG - 2011-07-17 03:11:21 --> Model Class Initialized
DEBUG - 2011-07-17 03:11:21 --> Model Class Initialized
DEBUG - 2011-07-17 03:11:21 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-17 03:11:21 --> Database Driver Class Initialized
DEBUG - 2011-07-17 03:11:21 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-17 03:11:21 --> Helper loaded: url_helper
DEBUG - 2011-07-17 03:11:21 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-17 03:11:21 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-17 03:11:21 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-17 03:11:21 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-17 03:11:21 --> Final output sent to browser
DEBUG - 2011-07-17 03:11:21 --> Total execution time: 0.0487
DEBUG - 2011-07-17 03:11:22 --> Config Class Initialized
DEBUG - 2011-07-17 03:11:22 --> Hooks Class Initialized
DEBUG - 2011-07-17 03:11:22 --> Utf8 Class Initialized
DEBUG - 2011-07-17 03:11:22 --> UTF-8 Support Enabled
DEBUG - 2011-07-17 03:11:22 --> URI Class Initialized
DEBUG - 2011-07-17 03:11:22 --> Router Class Initialized
ERROR - 2011-07-17 03:11:22 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-17 03:11:58 --> Config Class Initialized
DEBUG - 2011-07-17 03:11:58 --> Hooks Class Initialized
DEBUG - 2011-07-17 03:11:58 --> Utf8 Class Initialized
DEBUG - 2011-07-17 03:11:58 --> UTF-8 Support Enabled
DEBUG - 2011-07-17 03:11:58 --> URI Class Initialized
DEBUG - 2011-07-17 03:11:58 --> Router Class Initialized
DEBUG - 2011-07-17 03:11:58 --> Output Class Initialized
DEBUG - 2011-07-17 03:11:58 --> Input Class Initialized
DEBUG - 2011-07-17 03:11:58 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-17 03:11:58 --> Language Class Initialized
DEBUG - 2011-07-17 03:11:58 --> Loader Class Initialized
DEBUG - 2011-07-17 03:11:58 --> Controller Class Initialized
DEBUG - 2011-07-17 03:11:58 --> Model Class Initialized
DEBUG - 2011-07-17 03:11:58 --> Model Class Initialized
DEBUG - 2011-07-17 03:11:58 --> Model Class Initialized
DEBUG - 2011-07-17 03:11:58 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-17 03:11:58 --> Database Driver Class Initialized
DEBUG - 2011-07-17 03:11:58 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-17 03:11:58 --> Helper loaded: url_helper
DEBUG - 2011-07-17 03:11:58 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-17 03:11:58 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-17 03:11:58 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-17 03:11:58 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-17 03:11:58 --> Final output sent to browser
DEBUG - 2011-07-17 03:11:58 --> Total execution time: 0.2270
DEBUG - 2011-07-17 03:12:00 --> Config Class Initialized
DEBUG - 2011-07-17 03:12:00 --> Hooks Class Initialized
DEBUG - 2011-07-17 03:12:00 --> Utf8 Class Initialized
DEBUG - 2011-07-17 03:12:00 --> UTF-8 Support Enabled
DEBUG - 2011-07-17 03:12:00 --> URI Class Initialized
DEBUG - 2011-07-17 03:12:00 --> Router Class Initialized
ERROR - 2011-07-17 03:12:00 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-17 03:12:09 --> Config Class Initialized
DEBUG - 2011-07-17 03:12:09 --> Hooks Class Initialized
DEBUG - 2011-07-17 03:12:09 --> Utf8 Class Initialized
DEBUG - 2011-07-17 03:12:09 --> UTF-8 Support Enabled
DEBUG - 2011-07-17 03:12:09 --> URI Class Initialized
DEBUG - 2011-07-17 03:12:09 --> Router Class Initialized
DEBUG - 2011-07-17 03:12:09 --> Output Class Initialized
DEBUG - 2011-07-17 03:12:09 --> Input Class Initialized
DEBUG - 2011-07-17 03:12:09 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-17 03:12:09 --> Language Class Initialized
DEBUG - 2011-07-17 03:12:09 --> Loader Class Initialized
DEBUG - 2011-07-17 03:12:09 --> Controller Class Initialized
DEBUG - 2011-07-17 03:12:09 --> Model Class Initialized
DEBUG - 2011-07-17 03:12:09 --> Model Class Initialized
DEBUG - 2011-07-17 03:12:09 --> Model Class Initialized
DEBUG - 2011-07-17 03:12:09 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-17 03:12:09 --> Database Driver Class Initialized
DEBUG - 2011-07-17 03:12:09 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-17 03:12:09 --> Helper loaded: url_helper
DEBUG - 2011-07-17 03:12:09 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-17 03:12:09 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-17 03:12:09 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-17 03:12:09 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-17 03:12:09 --> Final output sent to browser
DEBUG - 2011-07-17 03:12:09 --> Total execution time: 0.0481
DEBUG - 2011-07-17 03:13:09 --> Config Class Initialized
DEBUG - 2011-07-17 03:13:09 --> Hooks Class Initialized
DEBUG - 2011-07-17 03:13:09 --> Utf8 Class Initialized
DEBUG - 2011-07-17 03:13:09 --> UTF-8 Support Enabled
DEBUG - 2011-07-17 03:13:09 --> URI Class Initialized
DEBUG - 2011-07-17 03:13:09 --> Router Class Initialized
ERROR - 2011-07-17 03:13:09 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-17 04:44:14 --> Config Class Initialized
DEBUG - 2011-07-17 04:44:14 --> Hooks Class Initialized
DEBUG - 2011-07-17 04:44:14 --> Utf8 Class Initialized
DEBUG - 2011-07-17 04:44:14 --> UTF-8 Support Enabled
DEBUG - 2011-07-17 04:44:14 --> URI Class Initialized
DEBUG - 2011-07-17 04:44:14 --> Router Class Initialized
DEBUG - 2011-07-17 04:44:14 --> Output Class Initialized
DEBUG - 2011-07-17 04:44:14 --> Input Class Initialized
DEBUG - 2011-07-17 04:44:14 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-17 04:44:14 --> Language Class Initialized
DEBUG - 2011-07-17 04:44:15 --> Loader Class Initialized
DEBUG - 2011-07-17 04:44:15 --> Controller Class Initialized
DEBUG - 2011-07-17 04:44:15 --> Model Class Initialized
DEBUG - 2011-07-17 04:44:16 --> Model Class Initialized
DEBUG - 2011-07-17 04:44:16 --> Model Class Initialized
DEBUG - 2011-07-17 04:44:16 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-17 04:44:16 --> Database Driver Class Initialized
DEBUG - 2011-07-17 04:44:17 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-17 04:44:17 --> Helper loaded: url_helper
DEBUG - 2011-07-17 04:44:17 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-17 04:44:17 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-17 04:44:17 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-17 04:44:17 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-17 04:44:17 --> Final output sent to browser
DEBUG - 2011-07-17 04:44:17 --> Total execution time: 3.5123
DEBUG - 2011-07-17 04:44:21 --> Config Class Initialized
DEBUG - 2011-07-17 04:44:21 --> Hooks Class Initialized
DEBUG - 2011-07-17 04:44:21 --> Utf8 Class Initialized
DEBUG - 2011-07-17 04:44:21 --> UTF-8 Support Enabled
DEBUG - 2011-07-17 04:44:21 --> URI Class Initialized
DEBUG - 2011-07-17 04:44:21 --> Router Class Initialized
ERROR - 2011-07-17 04:44:21 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-17 04:44:21 --> Config Class Initialized
DEBUG - 2011-07-17 04:44:22 --> Hooks Class Initialized
DEBUG - 2011-07-17 04:44:22 --> Utf8 Class Initialized
DEBUG - 2011-07-17 04:44:22 --> UTF-8 Support Enabled
DEBUG - 2011-07-17 04:44:22 --> URI Class Initialized
DEBUG - 2011-07-17 04:44:22 --> Router Class Initialized
ERROR - 2011-07-17 04:44:22 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-17 05:47:20 --> Config Class Initialized
DEBUG - 2011-07-17 05:47:20 --> Hooks Class Initialized
DEBUG - 2011-07-17 05:47:20 --> Utf8 Class Initialized
DEBUG - 2011-07-17 05:47:20 --> UTF-8 Support Enabled
DEBUG - 2011-07-17 05:47:20 --> URI Class Initialized
DEBUG - 2011-07-17 05:47:20 --> Router Class Initialized
DEBUG - 2011-07-17 05:47:20 --> Output Class Initialized
DEBUG - 2011-07-17 05:47:20 --> Input Class Initialized
DEBUG - 2011-07-17 05:47:20 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-17 05:47:20 --> Language Class Initialized
DEBUG - 2011-07-17 05:47:21 --> Loader Class Initialized
DEBUG - 2011-07-17 05:47:21 --> Controller Class Initialized
DEBUG - 2011-07-17 05:47:21 --> Model Class Initialized
DEBUG - 2011-07-17 05:47:21 --> Model Class Initialized
DEBUG - 2011-07-17 05:47:21 --> Model Class Initialized
DEBUG - 2011-07-17 05:47:21 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-17 05:47:21 --> Database Driver Class Initialized
DEBUG - 2011-07-17 05:47:21 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-17 05:47:21 --> Helper loaded: url_helper
DEBUG - 2011-07-17 05:47:21 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-17 05:47:21 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-17 05:47:21 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-17 05:47:21 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-17 05:47:21 --> Final output sent to browser
DEBUG - 2011-07-17 05:47:21 --> Total execution time: 0.4949
DEBUG - 2011-07-17 05:47:55 --> Config Class Initialized
DEBUG - 2011-07-17 05:47:55 --> Hooks Class Initialized
DEBUG - 2011-07-17 05:47:55 --> Utf8 Class Initialized
DEBUG - 2011-07-17 05:47:55 --> UTF-8 Support Enabled
DEBUG - 2011-07-17 05:47:55 --> URI Class Initialized
DEBUG - 2011-07-17 05:47:55 --> Router Class Initialized
DEBUG - 2011-07-17 05:47:55 --> Output Class Initialized
DEBUG - 2011-07-17 05:47:55 --> Input Class Initialized
DEBUG - 2011-07-17 05:47:55 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-17 05:47:55 --> Language Class Initialized
DEBUG - 2011-07-17 05:47:55 --> Loader Class Initialized
DEBUG - 2011-07-17 05:47:55 --> Controller Class Initialized
ERROR - 2011-07-17 05:47:55 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-17 05:47:55 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-17 05:47:55 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-17 05:47:55 --> Model Class Initialized
DEBUG - 2011-07-17 05:47:55 --> Model Class Initialized
DEBUG - 2011-07-17 05:47:55 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-17 05:47:55 --> Database Driver Class Initialized
DEBUG - 2011-07-17 05:47:55 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-17 05:47:55 --> Helper loaded: url_helper
DEBUG - 2011-07-17 05:47:55 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-17 05:47:55 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-17 05:47:55 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-17 05:47:55 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-17 05:47:55 --> Final output sent to browser
DEBUG - 2011-07-17 05:47:55 --> Total execution time: 0.1411
DEBUG - 2011-07-17 06:08:52 --> Config Class Initialized
DEBUG - 2011-07-17 06:08:52 --> Hooks Class Initialized
DEBUG - 2011-07-17 06:08:52 --> Utf8 Class Initialized
DEBUG - 2011-07-17 06:08:52 --> UTF-8 Support Enabled
DEBUG - 2011-07-17 06:08:52 --> URI Class Initialized
DEBUG - 2011-07-17 06:08:52 --> Router Class Initialized
DEBUG - 2011-07-17 06:08:52 --> Output Class Initialized
DEBUG - 2011-07-17 06:08:52 --> Input Class Initialized
DEBUG - 2011-07-17 06:08:52 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-17 06:08:52 --> Language Class Initialized
DEBUG - 2011-07-17 06:08:52 --> Loader Class Initialized
DEBUG - 2011-07-17 06:08:52 --> Controller Class Initialized
ERROR - 2011-07-17 06:08:52 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-17 06:08:52 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-17 06:08:52 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-17 06:08:52 --> Model Class Initialized
DEBUG - 2011-07-17 06:08:52 --> Model Class Initialized
DEBUG - 2011-07-17 06:08:52 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-17 06:08:52 --> Database Driver Class Initialized
DEBUG - 2011-07-17 06:08:52 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-17 06:08:52 --> Helper loaded: url_helper
DEBUG - 2011-07-17 06:08:52 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-17 06:08:52 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-17 06:08:52 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-17 06:08:52 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-17 06:08:52 --> Final output sent to browser
DEBUG - 2011-07-17 06:08:52 --> Total execution time: 0.1922
DEBUG - 2011-07-17 06:08:53 --> Config Class Initialized
DEBUG - 2011-07-17 06:08:53 --> Hooks Class Initialized
DEBUG - 2011-07-17 06:08:53 --> Utf8 Class Initialized
DEBUG - 2011-07-17 06:08:53 --> UTF-8 Support Enabled
DEBUG - 2011-07-17 06:08:53 --> URI Class Initialized
DEBUG - 2011-07-17 06:08:53 --> Router Class Initialized
DEBUG - 2011-07-17 06:08:53 --> Output Class Initialized
DEBUG - 2011-07-17 06:08:53 --> Input Class Initialized
DEBUG - 2011-07-17 06:08:53 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-17 06:08:53 --> Language Class Initialized
DEBUG - 2011-07-17 06:08:53 --> Loader Class Initialized
DEBUG - 2011-07-17 06:08:53 --> Controller Class Initialized
DEBUG - 2011-07-17 06:08:53 --> Model Class Initialized
DEBUG - 2011-07-17 06:08:53 --> Model Class Initialized
DEBUG - 2011-07-17 06:08:53 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-17 06:08:53 --> Database Driver Class Initialized
DEBUG - 2011-07-17 06:08:53 --> Final output sent to browser
DEBUG - 2011-07-17 06:08:53 --> Total execution time: 0.7212
DEBUG - 2011-07-17 07:09:55 --> Config Class Initialized
DEBUG - 2011-07-17 07:09:55 --> Hooks Class Initialized
DEBUG - 2011-07-17 07:09:55 --> Utf8 Class Initialized
DEBUG - 2011-07-17 07:09:55 --> UTF-8 Support Enabled
DEBUG - 2011-07-17 07:09:55 --> URI Class Initialized
DEBUG - 2011-07-17 07:09:55 --> Router Class Initialized
DEBUG - 2011-07-17 07:09:55 --> Output Class Initialized
DEBUG - 2011-07-17 07:09:55 --> Input Class Initialized
DEBUG - 2011-07-17 07:09:55 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-17 07:09:55 --> Language Class Initialized
DEBUG - 2011-07-17 07:09:55 --> Loader Class Initialized
DEBUG - 2011-07-17 07:09:55 --> Controller Class Initialized
DEBUG - 2011-07-17 07:09:55 --> Model Class Initialized
DEBUG - 2011-07-17 07:09:55 --> Model Class Initialized
DEBUG - 2011-07-17 07:09:55 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-17 07:09:55 --> Database Driver Class Initialized
DEBUG - 2011-07-17 07:09:56 --> Final output sent to browser
DEBUG - 2011-07-17 07:09:56 --> Total execution time: 1.0536
DEBUG - 2011-07-17 09:15:07 --> Config Class Initialized
DEBUG - 2011-07-17 09:15:07 --> Hooks Class Initialized
DEBUG - 2011-07-17 09:15:07 --> Utf8 Class Initialized
DEBUG - 2011-07-17 09:15:07 --> UTF-8 Support Enabled
DEBUG - 2011-07-17 09:15:07 --> URI Class Initialized
DEBUG - 2011-07-17 09:15:07 --> Router Class Initialized
ERROR - 2011-07-17 09:15:07 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-07-17 09:15:07 --> Config Class Initialized
DEBUG - 2011-07-17 09:15:07 --> Hooks Class Initialized
DEBUG - 2011-07-17 09:15:07 --> Utf8 Class Initialized
DEBUG - 2011-07-17 09:15:07 --> UTF-8 Support Enabled
DEBUG - 2011-07-17 09:15:07 --> URI Class Initialized
DEBUG - 2011-07-17 09:15:07 --> Router Class Initialized
DEBUG - 2011-07-17 09:15:07 --> Output Class Initialized
DEBUG - 2011-07-17 09:15:07 --> Input Class Initialized
DEBUG - 2011-07-17 09:15:07 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-17 09:15:07 --> Language Class Initialized
DEBUG - 2011-07-17 09:15:07 --> Loader Class Initialized
DEBUG - 2011-07-17 09:15:07 --> Controller Class Initialized
ERROR - 2011-07-17 09:15:07 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-17 09:15:07 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-17 09:15:07 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-17 09:15:07 --> Model Class Initialized
DEBUG - 2011-07-17 09:15:07 --> Model Class Initialized
DEBUG - 2011-07-17 09:15:07 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-17 09:15:07 --> Database Driver Class Initialized
DEBUG - 2011-07-17 09:15:07 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-17 09:15:07 --> Helper loaded: url_helper
DEBUG - 2011-07-17 09:15:07 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-17 09:15:07 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-17 09:15:07 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-17 09:15:07 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-17 09:15:07 --> Final output sent to browser
DEBUG - 2011-07-17 09:15:07 --> Total execution time: 0.4322
DEBUG - 2011-07-17 11:55:00 --> Config Class Initialized
DEBUG - 2011-07-17 11:55:00 --> Hooks Class Initialized
DEBUG - 2011-07-17 11:55:00 --> Utf8 Class Initialized
DEBUG - 2011-07-17 11:55:00 --> UTF-8 Support Enabled
DEBUG - 2011-07-17 11:55:00 --> URI Class Initialized
DEBUG - 2011-07-17 11:55:00 --> Router Class Initialized
DEBUG - 2011-07-17 11:55:00 --> No URI present. Default controller set.
DEBUG - 2011-07-17 11:55:00 --> Output Class Initialized
DEBUG - 2011-07-17 11:55:00 --> Input Class Initialized
DEBUG - 2011-07-17 11:55:00 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-17 11:55:01 --> Language Class Initialized
DEBUG - 2011-07-17 11:55:01 --> Loader Class Initialized
DEBUG - 2011-07-17 11:55:01 --> Controller Class Initialized
DEBUG - 2011-07-17 11:55:01 --> File loaded: application/views/splash/main.php
DEBUG - 2011-07-17 11:55:01 --> Helper loaded: url_helper
DEBUG - 2011-07-17 11:55:01 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-17 11:55:01 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-17 11:55:01 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-17 11:55:01 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-17 11:55:01 --> Final output sent to browser
DEBUG - 2011-07-17 11:55:01 --> Total execution time: 0.2826
DEBUG - 2011-07-17 11:55:03 --> Config Class Initialized
DEBUG - 2011-07-17 11:55:03 --> Hooks Class Initialized
DEBUG - 2011-07-17 11:55:03 --> Utf8 Class Initialized
DEBUG - 2011-07-17 11:55:03 --> UTF-8 Support Enabled
DEBUG - 2011-07-17 11:55:03 --> URI Class Initialized
DEBUG - 2011-07-17 11:55:03 --> Router Class Initialized
ERROR - 2011-07-17 11:55:03 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-17 11:55:06 --> Config Class Initialized
DEBUG - 2011-07-17 11:55:06 --> Hooks Class Initialized
DEBUG - 2011-07-17 11:55:06 --> Utf8 Class Initialized
DEBUG - 2011-07-17 11:55:06 --> UTF-8 Support Enabled
DEBUG - 2011-07-17 11:55:06 --> URI Class Initialized
DEBUG - 2011-07-17 11:55:06 --> Router Class Initialized
DEBUG - 2011-07-17 11:55:06 --> Output Class Initialized
DEBUG - 2011-07-17 11:55:06 --> Input Class Initialized
DEBUG - 2011-07-17 11:55:06 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-17 11:55:06 --> Language Class Initialized
DEBUG - 2011-07-17 11:55:06 --> Loader Class Initialized
DEBUG - 2011-07-17 11:55:06 --> Controller Class Initialized
DEBUG - 2011-07-17 11:55:06 --> Model Class Initialized
DEBUG - 2011-07-17 11:55:06 --> Model Class Initialized
DEBUG - 2011-07-17 11:55:06 --> Model Class Initialized
DEBUG - 2011-07-17 11:55:06 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-17 11:55:06 --> Database Driver Class Initialized
DEBUG - 2011-07-17 11:55:07 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-17 11:55:07 --> Helper loaded: url_helper
DEBUG - 2011-07-17 11:55:07 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-17 11:55:07 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-17 11:55:07 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-17 11:55:07 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-17 11:55:07 --> Final output sent to browser
DEBUG - 2011-07-17 11:55:07 --> Total execution time: 1.1086
DEBUG - 2011-07-17 11:55:08 --> Config Class Initialized
DEBUG - 2011-07-17 11:55:08 --> Hooks Class Initialized
DEBUG - 2011-07-17 11:55:08 --> Utf8 Class Initialized
DEBUG - 2011-07-17 11:55:08 --> UTF-8 Support Enabled
DEBUG - 2011-07-17 11:55:08 --> URI Class Initialized
DEBUG - 2011-07-17 11:55:08 --> Router Class Initialized
ERROR - 2011-07-17 11:55:08 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-17 11:55:26 --> Config Class Initialized
DEBUG - 2011-07-17 11:55:26 --> Hooks Class Initialized
DEBUG - 2011-07-17 11:55:26 --> Utf8 Class Initialized
DEBUG - 2011-07-17 11:55:26 --> UTF-8 Support Enabled
DEBUG - 2011-07-17 11:55:26 --> URI Class Initialized
DEBUG - 2011-07-17 11:55:26 --> Router Class Initialized
DEBUG - 2011-07-17 11:55:26 --> Output Class Initialized
DEBUG - 2011-07-17 11:55:26 --> Input Class Initialized
DEBUG - 2011-07-17 11:55:26 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-17 11:55:26 --> Language Class Initialized
DEBUG - 2011-07-17 11:55:26 --> Loader Class Initialized
DEBUG - 2011-07-17 11:55:26 --> Controller Class Initialized
DEBUG - 2011-07-17 11:55:26 --> Model Class Initialized
DEBUG - 2011-07-17 11:55:26 --> Model Class Initialized
DEBUG - 2011-07-17 11:55:26 --> Model Class Initialized
DEBUG - 2011-07-17 11:55:26 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-17 11:55:26 --> Database Driver Class Initialized
DEBUG - 2011-07-17 11:55:26 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-17 11:55:26 --> Helper loaded: url_helper
DEBUG - 2011-07-17 11:55:26 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-17 11:55:26 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-17 11:55:26 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-17 11:55:26 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-17 11:55:26 --> Final output sent to browser
DEBUG - 2011-07-17 11:55:26 --> Total execution time: 0.0510
DEBUG - 2011-07-17 11:55:26 --> Config Class Initialized
DEBUG - 2011-07-17 11:55:26 --> Hooks Class Initialized
DEBUG - 2011-07-17 11:55:26 --> Utf8 Class Initialized
DEBUG - 2011-07-17 11:55:26 --> UTF-8 Support Enabled
DEBUG - 2011-07-17 11:55:26 --> URI Class Initialized
DEBUG - 2011-07-17 11:55:26 --> Router Class Initialized
DEBUG - 2011-07-17 11:55:26 --> Output Class Initialized
DEBUG - 2011-07-17 11:55:26 --> Input Class Initialized
DEBUG - 2011-07-17 11:55:26 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-17 11:55:26 --> Language Class Initialized
DEBUG - 2011-07-17 11:55:26 --> Loader Class Initialized
DEBUG - 2011-07-17 11:55:26 --> Controller Class Initialized
DEBUG - 2011-07-17 11:55:26 --> Model Class Initialized
DEBUG - 2011-07-17 11:55:26 --> Model Class Initialized
DEBUG - 2011-07-17 11:55:26 --> Model Class Initialized
DEBUG - 2011-07-17 11:55:26 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-17 11:55:26 --> Database Driver Class Initialized
DEBUG - 2011-07-17 11:55:26 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-17 11:55:26 --> Helper loaded: url_helper
DEBUG - 2011-07-17 11:55:26 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-17 11:55:26 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-17 11:55:26 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-17 11:55:26 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-17 11:55:26 --> Final output sent to browser
DEBUG - 2011-07-17 11:55:26 --> Total execution time: 0.0440
DEBUG - 2011-07-17 11:55:27 --> Config Class Initialized
DEBUG - 2011-07-17 11:55:27 --> Hooks Class Initialized
DEBUG - 2011-07-17 11:55:27 --> Utf8 Class Initialized
DEBUG - 2011-07-17 11:55:27 --> UTF-8 Support Enabled
DEBUG - 2011-07-17 11:55:27 --> URI Class Initialized
DEBUG - 2011-07-17 11:55:27 --> Router Class Initialized
ERROR - 2011-07-17 11:55:27 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-17 11:55:52 --> Config Class Initialized
DEBUG - 2011-07-17 11:55:52 --> Hooks Class Initialized
DEBUG - 2011-07-17 11:55:52 --> Utf8 Class Initialized
DEBUG - 2011-07-17 11:55:52 --> UTF-8 Support Enabled
DEBUG - 2011-07-17 11:55:52 --> URI Class Initialized
DEBUG - 2011-07-17 11:55:52 --> Router Class Initialized
DEBUG - 2011-07-17 11:55:52 --> Output Class Initialized
DEBUG - 2011-07-17 11:55:52 --> Input Class Initialized
DEBUG - 2011-07-17 11:55:52 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-17 11:55:52 --> Language Class Initialized
DEBUG - 2011-07-17 11:55:52 --> Loader Class Initialized
DEBUG - 2011-07-17 11:55:52 --> Controller Class Initialized
DEBUG - 2011-07-17 11:55:52 --> Model Class Initialized
DEBUG - 2011-07-17 11:55:52 --> Model Class Initialized
DEBUG - 2011-07-17 11:55:52 --> Model Class Initialized
DEBUG - 2011-07-17 11:55:52 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-17 11:55:52 --> Database Driver Class Initialized
DEBUG - 2011-07-17 11:55:52 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-17 11:55:52 --> Helper loaded: url_helper
DEBUG - 2011-07-17 11:55:52 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-17 11:55:52 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-17 11:55:52 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-17 11:55:52 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-17 11:55:52 --> Final output sent to browser
DEBUG - 2011-07-17 11:55:52 --> Total execution time: 0.0448
DEBUG - 2011-07-17 11:55:53 --> Config Class Initialized
DEBUG - 2011-07-17 11:55:53 --> Hooks Class Initialized
DEBUG - 2011-07-17 11:55:53 --> Utf8 Class Initialized
DEBUG - 2011-07-17 11:55:53 --> UTF-8 Support Enabled
DEBUG - 2011-07-17 11:55:53 --> URI Class Initialized
DEBUG - 2011-07-17 11:55:53 --> Router Class Initialized
ERROR - 2011-07-17 11:55:53 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-17 11:55:55 --> Config Class Initialized
DEBUG - 2011-07-17 11:55:55 --> Hooks Class Initialized
DEBUG - 2011-07-17 11:55:55 --> Utf8 Class Initialized
DEBUG - 2011-07-17 11:55:55 --> UTF-8 Support Enabled
DEBUG - 2011-07-17 11:55:55 --> URI Class Initialized
DEBUG - 2011-07-17 11:55:55 --> Router Class Initialized
DEBUG - 2011-07-17 11:55:55 --> Output Class Initialized
DEBUG - 2011-07-17 11:55:55 --> Input Class Initialized
DEBUG - 2011-07-17 11:55:55 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-17 11:55:55 --> Language Class Initialized
DEBUG - 2011-07-17 11:55:55 --> Loader Class Initialized
DEBUG - 2011-07-17 11:55:55 --> Controller Class Initialized
DEBUG - 2011-07-17 11:55:55 --> Model Class Initialized
DEBUG - 2011-07-17 11:55:55 --> Model Class Initialized
DEBUG - 2011-07-17 11:55:55 --> Model Class Initialized
DEBUG - 2011-07-17 11:55:55 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-17 11:55:55 --> Database Driver Class Initialized
DEBUG - 2011-07-17 11:55:55 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-17 11:55:55 --> Helper loaded: url_helper
DEBUG - 2011-07-17 11:55:55 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-17 11:55:55 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-17 11:55:55 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-17 11:55:55 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-17 11:55:55 --> Final output sent to browser
DEBUG - 2011-07-17 11:55:55 --> Total execution time: 0.0657
DEBUG - 2011-07-17 11:55:56 --> Config Class Initialized
DEBUG - 2011-07-17 11:55:56 --> Hooks Class Initialized
DEBUG - 2011-07-17 11:55:56 --> Utf8 Class Initialized
DEBUG - 2011-07-17 11:55:56 --> UTF-8 Support Enabled
DEBUG - 2011-07-17 11:55:56 --> URI Class Initialized
DEBUG - 2011-07-17 11:55:56 --> Router Class Initialized
ERROR - 2011-07-17 11:55:56 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-17 11:55:59 --> Config Class Initialized
DEBUG - 2011-07-17 11:55:59 --> Hooks Class Initialized
DEBUG - 2011-07-17 11:55:59 --> Utf8 Class Initialized
DEBUG - 2011-07-17 11:55:59 --> UTF-8 Support Enabled
DEBUG - 2011-07-17 11:55:59 --> URI Class Initialized
DEBUG - 2011-07-17 11:55:59 --> Router Class Initialized
DEBUG - 2011-07-17 11:55:59 --> No URI present. Default controller set.
DEBUG - 2011-07-17 11:55:59 --> Output Class Initialized
DEBUG - 2011-07-17 11:55:59 --> Input Class Initialized
DEBUG - 2011-07-17 11:55:59 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-17 11:55:59 --> Language Class Initialized
DEBUG - 2011-07-17 11:55:59 --> Loader Class Initialized
DEBUG - 2011-07-17 11:55:59 --> Controller Class Initialized
DEBUG - 2011-07-17 11:55:59 --> File loaded: application/views/splash/main.php
DEBUG - 2011-07-17 11:55:59 --> Helper loaded: url_helper
DEBUG - 2011-07-17 11:55:59 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-17 11:55:59 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-17 11:55:59 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-17 11:55:59 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-17 11:55:59 --> Final output sent to browser
DEBUG - 2011-07-17 11:55:59 --> Total execution time: 0.0218
DEBUG - 2011-07-17 11:56:04 --> Config Class Initialized
DEBUG - 2011-07-17 11:56:04 --> Hooks Class Initialized
DEBUG - 2011-07-17 11:56:04 --> Utf8 Class Initialized
DEBUG - 2011-07-17 11:56:04 --> UTF-8 Support Enabled
DEBUG - 2011-07-17 11:56:04 --> URI Class Initialized
DEBUG - 2011-07-17 11:56:04 --> Router Class Initialized
DEBUG - 2011-07-17 11:56:04 --> Output Class Initialized
DEBUG - 2011-07-17 11:56:04 --> Input Class Initialized
DEBUG - 2011-07-17 11:56:04 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-17 11:56:04 --> Language Class Initialized
DEBUG - 2011-07-17 11:56:04 --> Loader Class Initialized
DEBUG - 2011-07-17 11:56:04 --> Controller Class Initialized
DEBUG - 2011-07-17 11:56:04 --> Model Class Initialized
DEBUG - 2011-07-17 11:56:04 --> Model Class Initialized
DEBUG - 2011-07-17 11:56:04 --> Model Class Initialized
DEBUG - 2011-07-17 11:56:04 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-17 11:56:04 --> Database Driver Class Initialized
DEBUG - 2011-07-17 11:56:04 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-17 11:56:04 --> Helper loaded: url_helper
DEBUG - 2011-07-17 11:56:04 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-17 11:56:04 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-17 11:56:04 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-17 11:56:04 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-17 11:56:04 --> Final output sent to browser
DEBUG - 2011-07-17 11:56:04 --> Total execution time: 0.0460
DEBUG - 2011-07-17 11:56:05 --> Config Class Initialized
DEBUG - 2011-07-17 11:56:05 --> Hooks Class Initialized
DEBUG - 2011-07-17 11:56:05 --> Utf8 Class Initialized
DEBUG - 2011-07-17 11:56:05 --> UTF-8 Support Enabled
DEBUG - 2011-07-17 11:56:05 --> URI Class Initialized
DEBUG - 2011-07-17 11:56:05 --> Router Class Initialized
ERROR - 2011-07-17 11:56:05 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-17 11:56:12 --> Config Class Initialized
DEBUG - 2011-07-17 11:56:12 --> Hooks Class Initialized
DEBUG - 2011-07-17 11:56:12 --> Utf8 Class Initialized
DEBUG - 2011-07-17 11:56:12 --> UTF-8 Support Enabled
DEBUG - 2011-07-17 11:56:12 --> URI Class Initialized
DEBUG - 2011-07-17 11:56:12 --> Router Class Initialized
DEBUG - 2011-07-17 11:56:12 --> Output Class Initialized
DEBUG - 2011-07-17 11:56:12 --> Input Class Initialized
DEBUG - 2011-07-17 11:56:12 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-17 11:56:12 --> Language Class Initialized
DEBUG - 2011-07-17 11:56:12 --> Loader Class Initialized
DEBUG - 2011-07-17 11:56:12 --> Controller Class Initialized
DEBUG - 2011-07-17 11:56:12 --> Model Class Initialized
DEBUG - 2011-07-17 11:56:12 --> Model Class Initialized
DEBUG - 2011-07-17 11:56:12 --> Model Class Initialized
DEBUG - 2011-07-17 11:56:12 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-17 11:56:12 --> Database Driver Class Initialized
DEBUG - 2011-07-17 11:56:13 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-17 11:56:13 --> Helper loaded: url_helper
DEBUG - 2011-07-17 11:56:13 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-17 11:56:13 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-17 11:56:13 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-17 11:56:13 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-17 11:56:13 --> Final output sent to browser
DEBUG - 2011-07-17 11:56:13 --> Total execution time: 0.1477
DEBUG - 2011-07-17 11:56:27 --> Config Class Initialized
DEBUG - 2011-07-17 11:56:27 --> Hooks Class Initialized
DEBUG - 2011-07-17 11:56:27 --> Utf8 Class Initialized
DEBUG - 2011-07-17 11:56:27 --> UTF-8 Support Enabled
DEBUG - 2011-07-17 11:56:27 --> URI Class Initialized
DEBUG - 2011-07-17 11:56:27 --> Router Class Initialized
DEBUG - 2011-07-17 11:56:27 --> Output Class Initialized
DEBUG - 2011-07-17 11:56:27 --> Input Class Initialized
DEBUG - 2011-07-17 11:56:27 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-17 11:56:27 --> Language Class Initialized
DEBUG - 2011-07-17 11:56:27 --> Loader Class Initialized
DEBUG - 2011-07-17 11:56:27 --> Controller Class Initialized
DEBUG - 2011-07-17 11:56:27 --> Model Class Initialized
DEBUG - 2011-07-17 11:56:27 --> Model Class Initialized
DEBUG - 2011-07-17 11:56:27 --> Model Class Initialized
DEBUG - 2011-07-17 11:56:27 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-17 11:56:27 --> Database Driver Class Initialized
DEBUG - 2011-07-17 11:56:27 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-17 11:56:27 --> Helper loaded: url_helper
DEBUG - 2011-07-17 11:56:27 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-17 11:56:27 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-17 11:56:27 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-17 11:56:27 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-17 11:56:27 --> Final output sent to browser
DEBUG - 2011-07-17 11:56:27 --> Total execution time: 0.0431
DEBUG - 2011-07-17 11:56:28 --> Config Class Initialized
DEBUG - 2011-07-17 11:56:28 --> Hooks Class Initialized
DEBUG - 2011-07-17 11:56:28 --> Utf8 Class Initialized
DEBUG - 2011-07-17 11:56:28 --> UTF-8 Support Enabled
DEBUG - 2011-07-17 11:56:28 --> URI Class Initialized
DEBUG - 2011-07-17 11:56:28 --> Router Class Initialized
DEBUG - 2011-07-17 11:56:28 --> Output Class Initialized
DEBUG - 2011-07-17 11:56:28 --> Input Class Initialized
DEBUG - 2011-07-17 11:56:28 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-17 11:56:28 --> Language Class Initialized
DEBUG - 2011-07-17 11:56:28 --> Loader Class Initialized
DEBUG - 2011-07-17 11:56:28 --> Controller Class Initialized
DEBUG - 2011-07-17 11:56:28 --> Model Class Initialized
DEBUG - 2011-07-17 11:56:28 --> Model Class Initialized
DEBUG - 2011-07-17 11:56:28 --> Model Class Initialized
DEBUG - 2011-07-17 11:56:28 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-17 11:56:28 --> Database Driver Class Initialized
DEBUG - 2011-07-17 11:56:28 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-17 11:56:28 --> Helper loaded: url_helper
DEBUG - 2011-07-17 11:56:28 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-17 11:56:28 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-17 11:56:28 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-17 11:56:28 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-17 11:56:28 --> Final output sent to browser
DEBUG - 2011-07-17 11:56:28 --> Total execution time: 0.0451
DEBUG - 2011-07-17 11:56:29 --> Config Class Initialized
DEBUG - 2011-07-17 11:56:29 --> Hooks Class Initialized
DEBUG - 2011-07-17 11:56:29 --> Utf8 Class Initialized
DEBUG - 2011-07-17 11:56:29 --> UTF-8 Support Enabled
DEBUG - 2011-07-17 11:56:29 --> URI Class Initialized
DEBUG - 2011-07-17 11:56:29 --> Router Class Initialized
ERROR - 2011-07-17 11:56:29 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-17 11:56:32 --> Config Class Initialized
DEBUG - 2011-07-17 11:56:32 --> Hooks Class Initialized
DEBUG - 2011-07-17 11:56:32 --> Utf8 Class Initialized
DEBUG - 2011-07-17 11:56:32 --> UTF-8 Support Enabled
DEBUG - 2011-07-17 11:56:32 --> URI Class Initialized
DEBUG - 2011-07-17 11:56:32 --> Router Class Initialized
ERROR - 2011-07-17 11:56:32 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-17 12:21:12 --> Config Class Initialized
DEBUG - 2011-07-17 12:21:12 --> Hooks Class Initialized
DEBUG - 2011-07-17 12:21:12 --> Utf8 Class Initialized
DEBUG - 2011-07-17 12:21:12 --> UTF-8 Support Enabled
DEBUG - 2011-07-17 12:21:12 --> URI Class Initialized
DEBUG - 2011-07-17 12:21:12 --> Router Class Initialized
DEBUG - 2011-07-17 12:21:12 --> Output Class Initialized
DEBUG - 2011-07-17 12:21:12 --> Input Class Initialized
DEBUG - 2011-07-17 12:21:12 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-17 12:21:12 --> Language Class Initialized
DEBUG - 2011-07-17 12:21:12 --> Loader Class Initialized
DEBUG - 2011-07-17 12:21:12 --> Controller Class Initialized
DEBUG - 2011-07-17 12:21:12 --> Model Class Initialized
DEBUG - 2011-07-17 12:21:12 --> Model Class Initialized
DEBUG - 2011-07-17 12:21:12 --> Model Class Initialized
DEBUG - 2011-07-17 12:21:12 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-17 12:21:12 --> Database Driver Class Initialized
DEBUG - 2011-07-17 12:21:12 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-17 12:21:12 --> Helper loaded: url_helper
DEBUG - 2011-07-17 12:21:12 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-17 12:21:12 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-17 12:21:12 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-17 12:21:12 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-17 12:21:12 --> Final output sent to browser
DEBUG - 2011-07-17 12:21:12 --> Total execution time: 0.0574
DEBUG - 2011-07-17 12:21:14 --> Config Class Initialized
DEBUG - 2011-07-17 12:21:14 --> Hooks Class Initialized
DEBUG - 2011-07-17 12:21:14 --> Utf8 Class Initialized
DEBUG - 2011-07-17 12:21:14 --> UTF-8 Support Enabled
DEBUG - 2011-07-17 12:21:14 --> URI Class Initialized
DEBUG - 2011-07-17 12:21:14 --> Router Class Initialized
ERROR - 2011-07-17 12:21:14 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-17 12:21:24 --> Config Class Initialized
DEBUG - 2011-07-17 12:21:24 --> Hooks Class Initialized
DEBUG - 2011-07-17 12:21:24 --> Utf8 Class Initialized
DEBUG - 2011-07-17 12:21:24 --> UTF-8 Support Enabled
DEBUG - 2011-07-17 12:21:24 --> URI Class Initialized
DEBUG - 2011-07-17 12:21:24 --> Router Class Initialized
DEBUG - 2011-07-17 12:21:24 --> Output Class Initialized
DEBUG - 2011-07-17 12:21:24 --> Input Class Initialized
DEBUG - 2011-07-17 12:21:24 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-17 12:21:24 --> Language Class Initialized
DEBUG - 2011-07-17 12:21:24 --> Loader Class Initialized
DEBUG - 2011-07-17 12:21:24 --> Controller Class Initialized
DEBUG - 2011-07-17 12:21:24 --> Model Class Initialized
DEBUG - 2011-07-17 12:21:24 --> Model Class Initialized
DEBUG - 2011-07-17 12:21:24 --> Model Class Initialized
DEBUG - 2011-07-17 12:21:24 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-17 12:21:24 --> Database Driver Class Initialized
DEBUG - 2011-07-17 12:21:24 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-17 12:21:24 --> Helper loaded: url_helper
DEBUG - 2011-07-17 12:21:24 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-17 12:21:24 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-17 12:21:24 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-17 12:21:24 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-17 12:21:24 --> Final output sent to browser
DEBUG - 2011-07-17 12:21:24 --> Total execution time: 0.5450
DEBUG - 2011-07-17 12:21:25 --> Config Class Initialized
DEBUG - 2011-07-17 12:21:25 --> Hooks Class Initialized
DEBUG - 2011-07-17 12:21:25 --> Utf8 Class Initialized
DEBUG - 2011-07-17 12:21:25 --> UTF-8 Support Enabled
DEBUG - 2011-07-17 12:21:25 --> URI Class Initialized
DEBUG - 2011-07-17 12:21:25 --> Router Class Initialized
DEBUG - 2011-07-17 12:21:25 --> Output Class Initialized
DEBUG - 2011-07-17 12:21:25 --> Input Class Initialized
DEBUG - 2011-07-17 12:21:25 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-17 12:21:25 --> Language Class Initialized
DEBUG - 2011-07-17 12:21:25 --> Loader Class Initialized
DEBUG - 2011-07-17 12:21:25 --> Controller Class Initialized
DEBUG - 2011-07-17 12:21:25 --> Model Class Initialized
DEBUG - 2011-07-17 12:21:25 --> Model Class Initialized
DEBUG - 2011-07-17 12:21:25 --> Model Class Initialized
DEBUG - 2011-07-17 12:21:25 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-17 12:21:25 --> Database Driver Class Initialized
DEBUG - 2011-07-17 12:21:25 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-17 12:21:25 --> Helper loaded: url_helper
DEBUG - 2011-07-17 12:21:25 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-17 12:21:25 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-17 12:21:25 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-17 12:21:25 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-17 12:21:25 --> Final output sent to browser
DEBUG - 2011-07-17 12:21:25 --> Total execution time: 0.0479
DEBUG - 2011-07-17 12:21:25 --> Config Class Initialized
DEBUG - 2011-07-17 12:21:25 --> Hooks Class Initialized
DEBUG - 2011-07-17 12:21:25 --> Utf8 Class Initialized
DEBUG - 2011-07-17 12:21:25 --> UTF-8 Support Enabled
DEBUG - 2011-07-17 12:21:25 --> URI Class Initialized
DEBUG - 2011-07-17 12:21:25 --> Router Class Initialized
ERROR - 2011-07-17 12:21:25 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-17 12:21:29 --> Config Class Initialized
DEBUG - 2011-07-17 12:21:29 --> Hooks Class Initialized
DEBUG - 2011-07-17 12:21:29 --> Utf8 Class Initialized
DEBUG - 2011-07-17 12:21:29 --> UTF-8 Support Enabled
DEBUG - 2011-07-17 12:21:29 --> URI Class Initialized
DEBUG - 2011-07-17 12:21:29 --> Router Class Initialized
DEBUG - 2011-07-17 12:21:29 --> Output Class Initialized
DEBUG - 2011-07-17 12:21:29 --> Input Class Initialized
DEBUG - 2011-07-17 12:21:29 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-17 12:21:29 --> Language Class Initialized
DEBUG - 2011-07-17 12:21:29 --> Loader Class Initialized
DEBUG - 2011-07-17 12:21:29 --> Controller Class Initialized
DEBUG - 2011-07-17 12:21:29 --> Model Class Initialized
DEBUG - 2011-07-17 12:21:29 --> Model Class Initialized
DEBUG - 2011-07-17 12:21:29 --> Model Class Initialized
DEBUG - 2011-07-17 12:21:29 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-17 12:21:29 --> Database Driver Class Initialized
DEBUG - 2011-07-17 12:21:29 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-17 12:21:29 --> Helper loaded: url_helper
DEBUG - 2011-07-17 12:21:29 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-17 12:21:29 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-17 12:21:29 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-17 12:21:29 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-17 12:21:29 --> Final output sent to browser
DEBUG - 2011-07-17 12:21:29 --> Total execution time: 0.3299
DEBUG - 2011-07-17 12:21:30 --> Config Class Initialized
DEBUG - 2011-07-17 12:21:30 --> Hooks Class Initialized
DEBUG - 2011-07-17 12:21:30 --> Utf8 Class Initialized
DEBUG - 2011-07-17 12:21:30 --> UTF-8 Support Enabled
DEBUG - 2011-07-17 12:21:30 --> URI Class Initialized
DEBUG - 2011-07-17 12:21:30 --> Router Class Initialized
DEBUG - 2011-07-17 12:21:30 --> Output Class Initialized
DEBUG - 2011-07-17 12:21:30 --> Input Class Initialized
DEBUG - 2011-07-17 12:21:30 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-17 12:21:30 --> Language Class Initialized
DEBUG - 2011-07-17 12:21:30 --> Loader Class Initialized
DEBUG - 2011-07-17 12:21:30 --> Controller Class Initialized
DEBUG - 2011-07-17 12:21:30 --> Model Class Initialized
DEBUG - 2011-07-17 12:21:30 --> Model Class Initialized
DEBUG - 2011-07-17 12:21:30 --> Model Class Initialized
DEBUG - 2011-07-17 12:21:30 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-17 12:21:30 --> Database Driver Class Initialized
DEBUG - 2011-07-17 12:21:30 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-17 12:21:30 --> Helper loaded: url_helper
DEBUG - 2011-07-17 12:21:30 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-17 12:21:30 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-17 12:21:30 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-17 12:21:30 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-17 12:21:30 --> Final output sent to browser
DEBUG - 2011-07-17 12:21:30 --> Total execution time: 0.0443
DEBUG - 2011-07-17 12:21:31 --> Config Class Initialized
DEBUG - 2011-07-17 12:21:31 --> Hooks Class Initialized
DEBUG - 2011-07-17 12:21:31 --> Utf8 Class Initialized
DEBUG - 2011-07-17 12:21:31 --> UTF-8 Support Enabled
DEBUG - 2011-07-17 12:21:31 --> URI Class Initialized
DEBUG - 2011-07-17 12:21:31 --> Router Class Initialized
ERROR - 2011-07-17 12:21:31 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-17 12:21:32 --> Config Class Initialized
DEBUG - 2011-07-17 12:21:32 --> Hooks Class Initialized
DEBUG - 2011-07-17 12:21:32 --> Utf8 Class Initialized
DEBUG - 2011-07-17 12:21:32 --> UTF-8 Support Enabled
DEBUG - 2011-07-17 12:21:32 --> URI Class Initialized
DEBUG - 2011-07-17 12:21:32 --> Router Class Initialized
DEBUG - 2011-07-17 12:21:32 --> Output Class Initialized
DEBUG - 2011-07-17 12:21:32 --> Input Class Initialized
DEBUG - 2011-07-17 12:21:32 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-17 12:21:32 --> Language Class Initialized
DEBUG - 2011-07-17 12:21:32 --> Loader Class Initialized
DEBUG - 2011-07-17 12:21:32 --> Controller Class Initialized
DEBUG - 2011-07-17 12:21:32 --> Model Class Initialized
DEBUG - 2011-07-17 12:21:32 --> Model Class Initialized
DEBUG - 2011-07-17 12:21:32 --> Model Class Initialized
DEBUG - 2011-07-17 12:21:32 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-17 12:21:32 --> Database Driver Class Initialized
DEBUG - 2011-07-17 12:21:33 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-17 12:21:33 --> Helper loaded: url_helper
DEBUG - 2011-07-17 12:21:33 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-17 12:21:33 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-17 12:21:33 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-17 12:21:33 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-17 12:21:33 --> Final output sent to browser
DEBUG - 2011-07-17 12:21:33 --> Total execution time: 0.2531
DEBUG - 2011-07-17 12:21:33 --> Config Class Initialized
DEBUG - 2011-07-17 12:21:33 --> Hooks Class Initialized
DEBUG - 2011-07-17 12:21:33 --> Utf8 Class Initialized
DEBUG - 2011-07-17 12:21:33 --> UTF-8 Support Enabled
DEBUG - 2011-07-17 12:21:33 --> URI Class Initialized
DEBUG - 2011-07-17 12:21:33 --> Router Class Initialized
ERROR - 2011-07-17 12:21:33 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-17 12:21:34 --> Config Class Initialized
DEBUG - 2011-07-17 12:21:34 --> Hooks Class Initialized
DEBUG - 2011-07-17 12:21:34 --> Utf8 Class Initialized
DEBUG - 2011-07-17 12:21:34 --> UTF-8 Support Enabled
DEBUG - 2011-07-17 12:21:34 --> URI Class Initialized
DEBUG - 2011-07-17 12:21:34 --> Router Class Initialized
DEBUG - 2011-07-17 12:21:34 --> Output Class Initialized
DEBUG - 2011-07-17 12:21:34 --> Input Class Initialized
DEBUG - 2011-07-17 12:21:34 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-17 12:21:34 --> Language Class Initialized
DEBUG - 2011-07-17 12:21:34 --> Loader Class Initialized
DEBUG - 2011-07-17 12:21:34 --> Controller Class Initialized
DEBUG - 2011-07-17 12:21:34 --> Model Class Initialized
DEBUG - 2011-07-17 12:21:34 --> Model Class Initialized
DEBUG - 2011-07-17 12:21:34 --> Model Class Initialized
DEBUG - 2011-07-17 12:21:34 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-17 12:21:34 --> Database Driver Class Initialized
DEBUG - 2011-07-17 12:21:34 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-17 12:21:34 --> Helper loaded: url_helper
DEBUG - 2011-07-17 12:21:34 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-17 12:21:34 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-17 12:21:34 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-17 12:21:34 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-17 12:21:34 --> Final output sent to browser
DEBUG - 2011-07-17 12:21:34 --> Total execution time: 0.0453
DEBUG - 2011-07-17 12:21:36 --> Config Class Initialized
DEBUG - 2011-07-17 12:21:36 --> Hooks Class Initialized
DEBUG - 2011-07-17 12:21:36 --> Utf8 Class Initialized
DEBUG - 2011-07-17 12:21:36 --> UTF-8 Support Enabled
DEBUG - 2011-07-17 12:21:36 --> URI Class Initialized
DEBUG - 2011-07-17 12:21:36 --> Router Class Initialized
DEBUG - 2011-07-17 12:21:36 --> Output Class Initialized
DEBUG - 2011-07-17 12:21:36 --> Input Class Initialized
DEBUG - 2011-07-17 12:21:36 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-17 12:21:36 --> Language Class Initialized
DEBUG - 2011-07-17 12:21:36 --> Loader Class Initialized
DEBUG - 2011-07-17 12:21:36 --> Controller Class Initialized
DEBUG - 2011-07-17 12:21:36 --> Model Class Initialized
DEBUG - 2011-07-17 12:21:36 --> Model Class Initialized
DEBUG - 2011-07-17 12:21:36 --> Model Class Initialized
DEBUG - 2011-07-17 12:21:36 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-17 12:21:36 --> Database Driver Class Initialized
DEBUG - 2011-07-17 12:21:36 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-17 12:21:36 --> Helper loaded: url_helper
DEBUG - 2011-07-17 12:21:36 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-17 12:21:36 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-17 12:21:36 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-17 12:21:36 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-17 12:21:36 --> Final output sent to browser
DEBUG - 2011-07-17 12:21:36 --> Total execution time: 0.2606
DEBUG - 2011-07-17 12:21:37 --> Config Class Initialized
DEBUG - 2011-07-17 12:21:37 --> Hooks Class Initialized
DEBUG - 2011-07-17 12:21:37 --> Utf8 Class Initialized
DEBUG - 2011-07-17 12:21:37 --> UTF-8 Support Enabled
DEBUG - 2011-07-17 12:21:37 --> URI Class Initialized
DEBUG - 2011-07-17 12:21:37 --> Router Class Initialized
ERROR - 2011-07-17 12:21:37 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-17 12:21:37 --> Config Class Initialized
DEBUG - 2011-07-17 12:21:37 --> Hooks Class Initialized
DEBUG - 2011-07-17 12:21:37 --> Utf8 Class Initialized
DEBUG - 2011-07-17 12:21:37 --> UTF-8 Support Enabled
DEBUG - 2011-07-17 12:21:37 --> URI Class Initialized
DEBUG - 2011-07-17 12:21:37 --> Router Class Initialized
DEBUG - 2011-07-17 12:21:37 --> Output Class Initialized
DEBUG - 2011-07-17 12:21:37 --> Input Class Initialized
DEBUG - 2011-07-17 12:21:37 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-17 12:21:37 --> Language Class Initialized
DEBUG - 2011-07-17 12:21:37 --> Loader Class Initialized
DEBUG - 2011-07-17 12:21:37 --> Controller Class Initialized
DEBUG - 2011-07-17 12:21:37 --> Model Class Initialized
DEBUG - 2011-07-17 12:21:37 --> Model Class Initialized
DEBUG - 2011-07-17 12:21:37 --> Model Class Initialized
DEBUG - 2011-07-17 12:21:37 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-17 12:21:37 --> Database Driver Class Initialized
DEBUG - 2011-07-17 12:21:37 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-17 12:21:37 --> Helper loaded: url_helper
DEBUG - 2011-07-17 12:21:37 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-17 12:21:37 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-17 12:21:37 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-17 12:21:37 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-17 12:21:37 --> Final output sent to browser
DEBUG - 2011-07-17 12:21:37 --> Total execution time: 0.0438
DEBUG - 2011-07-17 12:21:39 --> Config Class Initialized
DEBUG - 2011-07-17 12:21:39 --> Hooks Class Initialized
DEBUG - 2011-07-17 12:21:39 --> Utf8 Class Initialized
DEBUG - 2011-07-17 12:21:39 --> UTF-8 Support Enabled
DEBUG - 2011-07-17 12:21:39 --> URI Class Initialized
DEBUG - 2011-07-17 12:21:39 --> Router Class Initialized
DEBUG - 2011-07-17 12:21:39 --> Output Class Initialized
DEBUG - 2011-07-17 12:21:39 --> Input Class Initialized
DEBUG - 2011-07-17 12:21:39 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-17 12:21:39 --> Language Class Initialized
DEBUG - 2011-07-17 12:21:39 --> Loader Class Initialized
DEBUG - 2011-07-17 12:21:39 --> Controller Class Initialized
DEBUG - 2011-07-17 12:21:39 --> Model Class Initialized
DEBUG - 2011-07-17 12:21:39 --> Model Class Initialized
DEBUG - 2011-07-17 12:21:39 --> Model Class Initialized
DEBUG - 2011-07-17 12:21:39 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-17 12:21:39 --> Database Driver Class Initialized
DEBUG - 2011-07-17 12:21:39 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-17 12:21:39 --> Helper loaded: url_helper
DEBUG - 2011-07-17 12:21:39 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-17 12:21:39 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-17 12:21:39 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-17 12:21:39 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-17 12:21:39 --> Final output sent to browser
DEBUG - 2011-07-17 12:21:39 --> Total execution time: 0.2131
DEBUG - 2011-07-17 12:21:40 --> Config Class Initialized
DEBUG - 2011-07-17 12:21:40 --> Hooks Class Initialized
DEBUG - 2011-07-17 12:21:40 --> Utf8 Class Initialized
DEBUG - 2011-07-17 12:21:40 --> UTF-8 Support Enabled
DEBUG - 2011-07-17 12:21:40 --> URI Class Initialized
DEBUG - 2011-07-17 12:21:40 --> Router Class Initialized
ERROR - 2011-07-17 12:21:40 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-17 12:21:40 --> Config Class Initialized
DEBUG - 2011-07-17 12:21:40 --> Hooks Class Initialized
DEBUG - 2011-07-17 12:21:40 --> Utf8 Class Initialized
DEBUG - 2011-07-17 12:21:40 --> UTF-8 Support Enabled
DEBUG - 2011-07-17 12:21:40 --> URI Class Initialized
DEBUG - 2011-07-17 12:21:40 --> Router Class Initialized
DEBUG - 2011-07-17 12:21:40 --> Output Class Initialized
DEBUG - 2011-07-17 12:21:40 --> Input Class Initialized
DEBUG - 2011-07-17 12:21:40 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-17 12:21:40 --> Language Class Initialized
DEBUG - 2011-07-17 12:21:40 --> Loader Class Initialized
DEBUG - 2011-07-17 12:21:40 --> Controller Class Initialized
DEBUG - 2011-07-17 12:21:40 --> Model Class Initialized
DEBUG - 2011-07-17 12:21:40 --> Model Class Initialized
DEBUG - 2011-07-17 12:21:40 --> Model Class Initialized
DEBUG - 2011-07-17 12:21:40 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-17 12:21:40 --> Database Driver Class Initialized
DEBUG - 2011-07-17 12:21:40 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-17 12:21:40 --> Helper loaded: url_helper
DEBUG - 2011-07-17 12:21:40 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-17 12:21:40 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-17 12:21:40 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-17 12:21:40 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-17 12:21:40 --> Final output sent to browser
DEBUG - 2011-07-17 12:21:40 --> Total execution time: 0.0539
DEBUG - 2011-07-17 12:21:43 --> Config Class Initialized
DEBUG - 2011-07-17 12:21:43 --> Hooks Class Initialized
DEBUG - 2011-07-17 12:21:43 --> Utf8 Class Initialized
DEBUG - 2011-07-17 12:21:43 --> UTF-8 Support Enabled
DEBUG - 2011-07-17 12:21:43 --> URI Class Initialized
DEBUG - 2011-07-17 12:21:43 --> Router Class Initialized
DEBUG - 2011-07-17 12:21:43 --> Output Class Initialized
DEBUG - 2011-07-17 12:21:43 --> Input Class Initialized
DEBUG - 2011-07-17 12:21:43 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-17 12:21:43 --> Language Class Initialized
DEBUG - 2011-07-17 12:21:43 --> Loader Class Initialized
DEBUG - 2011-07-17 12:21:43 --> Controller Class Initialized
DEBUG - 2011-07-17 12:21:43 --> Model Class Initialized
DEBUG - 2011-07-17 12:21:43 --> Model Class Initialized
DEBUG - 2011-07-17 12:21:43 --> Model Class Initialized
DEBUG - 2011-07-17 12:21:43 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-17 12:21:43 --> Database Driver Class Initialized
DEBUG - 2011-07-17 12:21:44 --> Config Class Initialized
DEBUG - 2011-07-17 12:21:44 --> Hooks Class Initialized
DEBUG - 2011-07-17 12:21:44 --> Utf8 Class Initialized
DEBUG - 2011-07-17 12:21:44 --> UTF-8 Support Enabled
DEBUG - 2011-07-17 12:21:44 --> URI Class Initialized
DEBUG - 2011-07-17 12:21:44 --> Router Class Initialized
ERROR - 2011-07-17 12:21:44 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-07-17 12:21:44 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-17 12:21:44 --> Helper loaded: url_helper
DEBUG - 2011-07-17 12:21:44 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-17 12:21:44 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-17 12:21:44 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-17 12:21:44 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-17 12:21:44 --> Final output sent to browser
DEBUG - 2011-07-17 12:21:44 --> Total execution time: 0.9956
DEBUG - 2011-07-17 12:21:44 --> Config Class Initialized
DEBUG - 2011-07-17 12:21:44 --> Hooks Class Initialized
DEBUG - 2011-07-17 12:21:44 --> Utf8 Class Initialized
DEBUG - 2011-07-17 12:21:44 --> UTF-8 Support Enabled
DEBUG - 2011-07-17 12:21:44 --> URI Class Initialized
DEBUG - 2011-07-17 12:21:44 --> Router Class Initialized
DEBUG - 2011-07-17 12:21:45 --> Output Class Initialized
DEBUG - 2011-07-17 12:21:45 --> Input Class Initialized
DEBUG - 2011-07-17 12:21:45 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-17 12:21:45 --> Language Class Initialized
DEBUG - 2011-07-17 12:21:45 --> Loader Class Initialized
DEBUG - 2011-07-17 12:21:45 --> Controller Class Initialized
DEBUG - 2011-07-17 12:21:45 --> Model Class Initialized
DEBUG - 2011-07-17 12:21:45 --> Model Class Initialized
DEBUG - 2011-07-17 12:21:45 --> Model Class Initialized
DEBUG - 2011-07-17 12:21:45 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-17 12:21:45 --> Database Driver Class Initialized
DEBUG - 2011-07-17 12:21:45 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-17 12:21:45 --> Helper loaded: url_helper
DEBUG - 2011-07-17 12:21:45 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-17 12:21:45 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-17 12:21:45 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-17 12:21:45 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-17 12:21:45 --> Final output sent to browser
DEBUG - 2011-07-17 12:21:45 --> Total execution time: 0.0927
DEBUG - 2011-07-17 12:21:45 --> Config Class Initialized
DEBUG - 2011-07-17 12:21:45 --> Hooks Class Initialized
DEBUG - 2011-07-17 12:21:45 --> Utf8 Class Initialized
DEBUG - 2011-07-17 12:21:45 --> UTF-8 Support Enabled
DEBUG - 2011-07-17 12:21:45 --> URI Class Initialized
DEBUG - 2011-07-17 12:21:45 --> Router Class Initialized
ERROR - 2011-07-17 12:21:45 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-17 12:21:48 --> Config Class Initialized
DEBUG - 2011-07-17 12:21:48 --> Hooks Class Initialized
DEBUG - 2011-07-17 12:21:48 --> Utf8 Class Initialized
DEBUG - 2011-07-17 12:21:48 --> UTF-8 Support Enabled
DEBUG - 2011-07-17 12:21:48 --> URI Class Initialized
DEBUG - 2011-07-17 12:21:48 --> Router Class Initialized
DEBUG - 2011-07-17 12:21:48 --> Output Class Initialized
DEBUG - 2011-07-17 12:21:48 --> Input Class Initialized
DEBUG - 2011-07-17 12:21:48 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-17 12:21:48 --> Language Class Initialized
DEBUG - 2011-07-17 12:21:48 --> Loader Class Initialized
DEBUG - 2011-07-17 12:21:48 --> Controller Class Initialized
DEBUG - 2011-07-17 12:21:48 --> Model Class Initialized
DEBUG - 2011-07-17 12:21:48 --> Model Class Initialized
DEBUG - 2011-07-17 12:21:48 --> Model Class Initialized
DEBUG - 2011-07-17 12:21:48 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-17 12:21:48 --> Database Driver Class Initialized
DEBUG - 2011-07-17 12:21:49 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-17 12:21:49 --> Helper loaded: url_helper
DEBUG - 2011-07-17 12:21:49 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-17 12:21:49 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-17 12:21:49 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-17 12:21:49 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-17 12:21:49 --> Final output sent to browser
DEBUG - 2011-07-17 12:21:49 --> Total execution time: 0.4369
DEBUG - 2011-07-17 12:21:50 --> Config Class Initialized
DEBUG - 2011-07-17 12:21:50 --> Hooks Class Initialized
DEBUG - 2011-07-17 12:21:50 --> Utf8 Class Initialized
DEBUG - 2011-07-17 12:21:50 --> UTF-8 Support Enabled
DEBUG - 2011-07-17 12:21:50 --> URI Class Initialized
DEBUG - 2011-07-17 12:21:50 --> Router Class Initialized
ERROR - 2011-07-17 12:21:50 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-17 12:21:52 --> Config Class Initialized
DEBUG - 2011-07-17 12:21:52 --> Hooks Class Initialized
DEBUG - 2011-07-17 12:21:52 --> Utf8 Class Initialized
DEBUG - 2011-07-17 12:21:52 --> UTF-8 Support Enabled
DEBUG - 2011-07-17 12:21:52 --> URI Class Initialized
DEBUG - 2011-07-17 12:21:52 --> Router Class Initialized
DEBUG - 2011-07-17 12:21:52 --> Output Class Initialized
DEBUG - 2011-07-17 12:21:52 --> Input Class Initialized
DEBUG - 2011-07-17 12:21:52 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-17 12:21:52 --> Language Class Initialized
DEBUG - 2011-07-17 12:21:52 --> Loader Class Initialized
DEBUG - 2011-07-17 12:21:52 --> Controller Class Initialized
DEBUG - 2011-07-17 12:21:52 --> Model Class Initialized
DEBUG - 2011-07-17 12:21:52 --> Model Class Initialized
DEBUG - 2011-07-17 12:21:52 --> Model Class Initialized
DEBUG - 2011-07-17 12:21:52 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-17 12:21:52 --> Database Driver Class Initialized
DEBUG - 2011-07-17 12:21:52 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-17 12:21:52 --> Helper loaded: url_helper
DEBUG - 2011-07-17 12:21:52 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-17 12:21:52 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-17 12:21:52 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-17 12:21:52 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-17 12:21:52 --> Final output sent to browser
DEBUG - 2011-07-17 12:21:52 --> Total execution time: 0.2013
DEBUG - 2011-07-17 12:21:53 --> Config Class Initialized
DEBUG - 2011-07-17 12:21:53 --> Hooks Class Initialized
DEBUG - 2011-07-17 12:21:53 --> Utf8 Class Initialized
DEBUG - 2011-07-17 12:21:53 --> UTF-8 Support Enabled
DEBUG - 2011-07-17 12:21:53 --> URI Class Initialized
DEBUG - 2011-07-17 12:21:53 --> Router Class Initialized
ERROR - 2011-07-17 12:21:53 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-17 12:21:55 --> Config Class Initialized
DEBUG - 2011-07-17 12:21:55 --> Hooks Class Initialized
DEBUG - 2011-07-17 12:21:55 --> Utf8 Class Initialized
DEBUG - 2011-07-17 12:21:55 --> UTF-8 Support Enabled
DEBUG - 2011-07-17 12:21:55 --> URI Class Initialized
DEBUG - 2011-07-17 12:21:55 --> Router Class Initialized
DEBUG - 2011-07-17 12:21:55 --> Output Class Initialized
DEBUG - 2011-07-17 12:21:55 --> Input Class Initialized
DEBUG - 2011-07-17 12:21:55 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-17 12:21:55 --> Language Class Initialized
DEBUG - 2011-07-17 12:21:55 --> Loader Class Initialized
DEBUG - 2011-07-17 12:21:55 --> Controller Class Initialized
DEBUG - 2011-07-17 12:21:55 --> Model Class Initialized
DEBUG - 2011-07-17 12:21:55 --> Model Class Initialized
DEBUG - 2011-07-17 12:21:55 --> Model Class Initialized
DEBUG - 2011-07-17 12:21:55 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-17 12:21:55 --> Database Driver Class Initialized
DEBUG - 2011-07-17 12:21:55 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-17 12:21:55 --> Helper loaded: url_helper
DEBUG - 2011-07-17 12:21:55 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-17 12:21:55 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-17 12:21:55 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-17 12:21:55 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-17 12:21:55 --> Final output sent to browser
DEBUG - 2011-07-17 12:21:55 --> Total execution time: 0.2381
DEBUG - 2011-07-17 12:21:56 --> Config Class Initialized
DEBUG - 2011-07-17 12:21:56 --> Hooks Class Initialized
DEBUG - 2011-07-17 12:21:56 --> Utf8 Class Initialized
DEBUG - 2011-07-17 12:21:56 --> UTF-8 Support Enabled
DEBUG - 2011-07-17 12:21:56 --> URI Class Initialized
DEBUG - 2011-07-17 12:21:56 --> Router Class Initialized
ERROR - 2011-07-17 12:21:56 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-17 12:21:58 --> Config Class Initialized
DEBUG - 2011-07-17 12:21:58 --> Hooks Class Initialized
DEBUG - 2011-07-17 12:21:58 --> Utf8 Class Initialized
DEBUG - 2011-07-17 12:21:58 --> UTF-8 Support Enabled
DEBUG - 2011-07-17 12:21:58 --> URI Class Initialized
DEBUG - 2011-07-17 12:21:58 --> Router Class Initialized
DEBUG - 2011-07-17 12:21:58 --> Output Class Initialized
DEBUG - 2011-07-17 12:21:58 --> Input Class Initialized
DEBUG - 2011-07-17 12:21:58 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-17 12:21:58 --> Language Class Initialized
DEBUG - 2011-07-17 12:21:58 --> Loader Class Initialized
DEBUG - 2011-07-17 12:21:58 --> Controller Class Initialized
DEBUG - 2011-07-17 12:21:58 --> Model Class Initialized
DEBUG - 2011-07-17 12:21:58 --> Model Class Initialized
DEBUG - 2011-07-17 12:21:58 --> Model Class Initialized
DEBUG - 2011-07-17 12:21:58 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-17 12:21:58 --> Database Driver Class Initialized
DEBUG - 2011-07-17 12:21:58 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-17 12:21:58 --> Helper loaded: url_helper
DEBUG - 2011-07-17 12:21:58 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-17 12:21:58 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-17 12:21:58 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-17 12:21:58 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-17 12:21:58 --> Final output sent to browser
DEBUG - 2011-07-17 12:21:58 --> Total execution time: 0.2215
DEBUG - 2011-07-17 12:21:59 --> Config Class Initialized
DEBUG - 2011-07-17 12:21:59 --> Hooks Class Initialized
DEBUG - 2011-07-17 12:21:59 --> Utf8 Class Initialized
DEBUG - 2011-07-17 12:21:59 --> UTF-8 Support Enabled
DEBUG - 2011-07-17 12:21:59 --> URI Class Initialized
DEBUG - 2011-07-17 12:21:59 --> Router Class Initialized
DEBUG - 2011-07-17 12:21:59 --> Output Class Initialized
DEBUG - 2011-07-17 12:21:59 --> Input Class Initialized
DEBUG - 2011-07-17 12:21:59 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-17 12:21:59 --> Language Class Initialized
DEBUG - 2011-07-17 12:21:59 --> Loader Class Initialized
DEBUG - 2011-07-17 12:21:59 --> Controller Class Initialized
DEBUG - 2011-07-17 12:21:59 --> Model Class Initialized
DEBUG - 2011-07-17 12:21:59 --> Model Class Initialized
DEBUG - 2011-07-17 12:21:59 --> Model Class Initialized
DEBUG - 2011-07-17 12:21:59 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-17 12:21:59 --> Database Driver Class Initialized
DEBUG - 2011-07-17 12:21:59 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-17 12:21:59 --> Helper loaded: url_helper
DEBUG - 2011-07-17 12:21:59 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-17 12:21:59 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-17 12:21:59 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-17 12:21:59 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-17 12:21:59 --> Final output sent to browser
DEBUG - 2011-07-17 12:21:59 --> Total execution time: 0.0421
DEBUG - 2011-07-17 12:21:59 --> Config Class Initialized
DEBUG - 2011-07-17 12:21:59 --> Hooks Class Initialized
DEBUG - 2011-07-17 12:21:59 --> Utf8 Class Initialized
DEBUG - 2011-07-17 12:21:59 --> UTF-8 Support Enabled
DEBUG - 2011-07-17 12:21:59 --> URI Class Initialized
DEBUG - 2011-07-17 12:21:59 --> Router Class Initialized
ERROR - 2011-07-17 12:21:59 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-17 12:22:01 --> Config Class Initialized
DEBUG - 2011-07-17 12:22:01 --> Hooks Class Initialized
DEBUG - 2011-07-17 12:22:01 --> Utf8 Class Initialized
DEBUG - 2011-07-17 12:22:01 --> UTF-8 Support Enabled
DEBUG - 2011-07-17 12:22:01 --> URI Class Initialized
DEBUG - 2011-07-17 12:22:01 --> Router Class Initialized
DEBUG - 2011-07-17 12:22:01 --> Output Class Initialized
DEBUG - 2011-07-17 12:22:01 --> Input Class Initialized
DEBUG - 2011-07-17 12:22:01 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-17 12:22:01 --> Language Class Initialized
DEBUG - 2011-07-17 12:22:01 --> Loader Class Initialized
DEBUG - 2011-07-17 12:22:01 --> Controller Class Initialized
DEBUG - 2011-07-17 12:22:01 --> Model Class Initialized
DEBUG - 2011-07-17 12:22:01 --> Model Class Initialized
DEBUG - 2011-07-17 12:22:01 --> Model Class Initialized
DEBUG - 2011-07-17 12:22:01 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-17 12:22:01 --> Database Driver Class Initialized
DEBUG - 2011-07-17 12:22:01 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-17 12:22:01 --> Helper loaded: url_helper
DEBUG - 2011-07-17 12:22:01 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-17 12:22:01 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-17 12:22:01 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-17 12:22:01 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-17 12:22:01 --> Final output sent to browser
DEBUG - 2011-07-17 12:22:01 --> Total execution time: 0.2671
DEBUG - 2011-07-17 12:22:02 --> Config Class Initialized
DEBUG - 2011-07-17 12:22:02 --> Hooks Class Initialized
DEBUG - 2011-07-17 12:22:02 --> Utf8 Class Initialized
DEBUG - 2011-07-17 12:22:02 --> UTF-8 Support Enabled
DEBUG - 2011-07-17 12:22:02 --> URI Class Initialized
DEBUG - 2011-07-17 12:22:02 --> Router Class Initialized
DEBUG - 2011-07-17 12:22:02 --> Output Class Initialized
DEBUG - 2011-07-17 12:22:02 --> Input Class Initialized
DEBUG - 2011-07-17 12:22:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-17 12:22:02 --> Language Class Initialized
DEBUG - 2011-07-17 12:22:02 --> Loader Class Initialized
DEBUG - 2011-07-17 12:22:02 --> Controller Class Initialized
DEBUG - 2011-07-17 12:22:02 --> Model Class Initialized
DEBUG - 2011-07-17 12:22:02 --> Model Class Initialized
DEBUG - 2011-07-17 12:22:02 --> Model Class Initialized
DEBUG - 2011-07-17 12:22:02 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-17 12:22:02 --> Database Driver Class Initialized
DEBUG - 2011-07-17 12:22:02 --> Config Class Initialized
DEBUG - 2011-07-17 12:22:02 --> Hooks Class Initialized
DEBUG - 2011-07-17 12:22:02 --> Utf8 Class Initialized
DEBUG - 2011-07-17 12:22:02 --> UTF-8 Support Enabled
DEBUG - 2011-07-17 12:22:02 --> URI Class Initialized
DEBUG - 2011-07-17 12:22:02 --> Router Class Initialized
ERROR - 2011-07-17 12:22:02 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-17 12:22:02 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-17 12:22:02 --> Helper loaded: url_helper
DEBUG - 2011-07-17 12:22:02 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-17 12:22:02 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-17 12:22:02 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-17 12:22:02 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-17 12:22:02 --> Final output sent to browser
DEBUG - 2011-07-17 12:22:02 --> Total execution time: 0.1184
DEBUG - 2011-07-17 12:22:04 --> Config Class Initialized
DEBUG - 2011-07-17 12:22:04 --> Hooks Class Initialized
DEBUG - 2011-07-17 12:22:04 --> Utf8 Class Initialized
DEBUG - 2011-07-17 12:22:04 --> UTF-8 Support Enabled
DEBUG - 2011-07-17 12:22:04 --> URI Class Initialized
DEBUG - 2011-07-17 12:22:04 --> Router Class Initialized
DEBUG - 2011-07-17 12:22:04 --> Output Class Initialized
DEBUG - 2011-07-17 12:22:04 --> Input Class Initialized
DEBUG - 2011-07-17 12:22:04 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-17 12:22:04 --> Language Class Initialized
DEBUG - 2011-07-17 12:22:04 --> Loader Class Initialized
DEBUG - 2011-07-17 12:22:04 --> Controller Class Initialized
DEBUG - 2011-07-17 12:22:04 --> Model Class Initialized
DEBUG - 2011-07-17 12:22:04 --> Model Class Initialized
DEBUG - 2011-07-17 12:22:04 --> Model Class Initialized
DEBUG - 2011-07-17 12:22:04 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-17 12:22:04 --> Database Driver Class Initialized
DEBUG - 2011-07-17 12:22:04 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-17 12:22:04 --> Helper loaded: url_helper
DEBUG - 2011-07-17 12:22:04 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-17 12:22:04 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-17 12:22:04 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-17 12:22:04 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-17 12:22:04 --> Final output sent to browser
DEBUG - 2011-07-17 12:22:04 --> Total execution time: 0.1841
DEBUG - 2011-07-17 12:22:05 --> Config Class Initialized
DEBUG - 2011-07-17 12:22:05 --> Hooks Class Initialized
DEBUG - 2011-07-17 12:22:05 --> Utf8 Class Initialized
DEBUG - 2011-07-17 12:22:05 --> UTF-8 Support Enabled
DEBUG - 2011-07-17 12:22:05 --> URI Class Initialized
DEBUG - 2011-07-17 12:22:05 --> Router Class Initialized
ERROR - 2011-07-17 12:22:05 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-17 12:22:08 --> Config Class Initialized
DEBUG - 2011-07-17 12:22:08 --> Hooks Class Initialized
DEBUG - 2011-07-17 12:22:08 --> Utf8 Class Initialized
DEBUG - 2011-07-17 12:22:08 --> UTF-8 Support Enabled
DEBUG - 2011-07-17 12:22:08 --> URI Class Initialized
DEBUG - 2011-07-17 12:22:08 --> Router Class Initialized
DEBUG - 2011-07-17 12:22:08 --> Output Class Initialized
DEBUG - 2011-07-17 12:22:08 --> Input Class Initialized
DEBUG - 2011-07-17 12:22:08 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-17 12:22:08 --> Language Class Initialized
DEBUG - 2011-07-17 12:22:08 --> Loader Class Initialized
DEBUG - 2011-07-17 12:22:08 --> Controller Class Initialized
DEBUG - 2011-07-17 12:22:08 --> Model Class Initialized
DEBUG - 2011-07-17 12:22:08 --> Model Class Initialized
DEBUG - 2011-07-17 12:22:08 --> Model Class Initialized
DEBUG - 2011-07-17 12:22:08 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-17 12:22:08 --> Database Driver Class Initialized
DEBUG - 2011-07-17 12:22:08 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-17 12:22:08 --> Helper loaded: url_helper
DEBUG - 2011-07-17 12:22:08 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-17 12:22:08 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-17 12:22:08 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-17 12:22:08 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-17 12:22:08 --> Final output sent to browser
DEBUG - 2011-07-17 12:22:08 --> Total execution time: 0.1930
DEBUG - 2011-07-17 12:22:09 --> Config Class Initialized
DEBUG - 2011-07-17 12:22:09 --> Hooks Class Initialized
DEBUG - 2011-07-17 12:22:09 --> Utf8 Class Initialized
DEBUG - 2011-07-17 12:22:09 --> UTF-8 Support Enabled
DEBUG - 2011-07-17 12:22:09 --> URI Class Initialized
DEBUG - 2011-07-17 12:22:09 --> Router Class Initialized
ERROR - 2011-07-17 12:22:09 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-17 12:22:11 --> Config Class Initialized
DEBUG - 2011-07-17 12:22:11 --> Hooks Class Initialized
DEBUG - 2011-07-17 12:22:11 --> Utf8 Class Initialized
DEBUG - 2011-07-17 12:22:11 --> UTF-8 Support Enabled
DEBUG - 2011-07-17 12:22:11 --> URI Class Initialized
DEBUG - 2011-07-17 12:22:11 --> Router Class Initialized
DEBUG - 2011-07-17 12:22:11 --> Output Class Initialized
DEBUG - 2011-07-17 12:22:11 --> Input Class Initialized
DEBUG - 2011-07-17 12:22:11 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-17 12:22:11 --> Language Class Initialized
DEBUG - 2011-07-17 12:22:11 --> Loader Class Initialized
DEBUG - 2011-07-17 12:22:11 --> Controller Class Initialized
DEBUG - 2011-07-17 12:22:11 --> Model Class Initialized
DEBUG - 2011-07-17 12:22:11 --> Model Class Initialized
DEBUG - 2011-07-17 12:22:11 --> Model Class Initialized
DEBUG - 2011-07-17 12:22:11 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-17 12:22:11 --> Database Driver Class Initialized
DEBUG - 2011-07-17 12:22:12 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-17 12:22:12 --> Helper loaded: url_helper
DEBUG - 2011-07-17 12:22:12 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-17 12:22:12 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-17 12:22:12 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-17 12:22:12 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-17 12:22:12 --> Final output sent to browser
DEBUG - 2011-07-17 12:22:12 --> Total execution time: 0.4638
DEBUG - 2011-07-17 12:22:13 --> Config Class Initialized
DEBUG - 2011-07-17 12:22:13 --> Hooks Class Initialized
DEBUG - 2011-07-17 12:22:13 --> Utf8 Class Initialized
DEBUG - 2011-07-17 12:22:13 --> UTF-8 Support Enabled
DEBUG - 2011-07-17 12:22:13 --> URI Class Initialized
DEBUG - 2011-07-17 12:22:13 --> Router Class Initialized
ERROR - 2011-07-17 12:22:13 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-17 12:22:15 --> Config Class Initialized
DEBUG - 2011-07-17 12:22:15 --> Hooks Class Initialized
DEBUG - 2011-07-17 12:22:15 --> Utf8 Class Initialized
DEBUG - 2011-07-17 12:22:15 --> UTF-8 Support Enabled
DEBUG - 2011-07-17 12:22:15 --> URI Class Initialized
DEBUG - 2011-07-17 12:22:15 --> Router Class Initialized
DEBUG - 2011-07-17 12:22:15 --> Output Class Initialized
DEBUG - 2011-07-17 12:22:15 --> Input Class Initialized
DEBUG - 2011-07-17 12:22:15 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-17 12:22:15 --> Language Class Initialized
DEBUG - 2011-07-17 12:22:15 --> Loader Class Initialized
DEBUG - 2011-07-17 12:22:15 --> Controller Class Initialized
DEBUG - 2011-07-17 12:22:15 --> Model Class Initialized
DEBUG - 2011-07-17 12:22:15 --> Model Class Initialized
DEBUG - 2011-07-17 12:22:15 --> Model Class Initialized
DEBUG - 2011-07-17 12:22:15 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-17 12:22:15 --> Database Driver Class Initialized
DEBUG - 2011-07-17 12:22:15 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-17 12:22:15 --> Helper loaded: url_helper
DEBUG - 2011-07-17 12:22:15 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-17 12:22:15 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-17 12:22:15 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-17 12:22:15 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-17 12:22:15 --> Final output sent to browser
DEBUG - 2011-07-17 12:22:15 --> Total execution time: 0.2609
DEBUG - 2011-07-17 12:22:16 --> Config Class Initialized
DEBUG - 2011-07-17 12:22:16 --> Hooks Class Initialized
DEBUG - 2011-07-17 12:22:16 --> Utf8 Class Initialized
DEBUG - 2011-07-17 12:22:16 --> UTF-8 Support Enabled
DEBUG - 2011-07-17 12:22:16 --> URI Class Initialized
DEBUG - 2011-07-17 12:22:16 --> Router Class Initialized
ERROR - 2011-07-17 12:22:16 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-17 14:17:04 --> Config Class Initialized
DEBUG - 2011-07-17 14:17:04 --> Hooks Class Initialized
DEBUG - 2011-07-17 14:17:04 --> Utf8 Class Initialized
DEBUG - 2011-07-17 14:17:04 --> UTF-8 Support Enabled
DEBUG - 2011-07-17 14:17:04 --> URI Class Initialized
DEBUG - 2011-07-17 14:17:04 --> Router Class Initialized
DEBUG - 2011-07-17 14:17:04 --> No URI present. Default controller set.
DEBUG - 2011-07-17 14:17:04 --> Output Class Initialized
DEBUG - 2011-07-17 14:17:04 --> Input Class Initialized
DEBUG - 2011-07-17 14:17:04 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-17 14:17:04 --> Language Class Initialized
DEBUG - 2011-07-17 14:17:04 --> Loader Class Initialized
DEBUG - 2011-07-17 14:17:04 --> Controller Class Initialized
DEBUG - 2011-07-17 14:17:04 --> File loaded: application/views/splash/main.php
DEBUG - 2011-07-17 14:17:04 --> Helper loaded: url_helper
DEBUG - 2011-07-17 14:17:04 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-17 14:17:04 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-17 14:17:04 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-17 14:17:04 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-17 14:17:04 --> Final output sent to browser
DEBUG - 2011-07-17 14:17:04 --> Total execution time: 0.3404
DEBUG - 2011-07-17 14:24:44 --> Config Class Initialized
DEBUG - 2011-07-17 14:24:44 --> Hooks Class Initialized
DEBUG - 2011-07-17 14:24:44 --> Utf8 Class Initialized
DEBUG - 2011-07-17 14:24:44 --> UTF-8 Support Enabled
DEBUG - 2011-07-17 14:24:44 --> URI Class Initialized
DEBUG - 2011-07-17 14:24:44 --> Router Class Initialized
ERROR - 2011-07-17 14:24:44 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-07-17 14:24:47 --> Config Class Initialized
DEBUG - 2011-07-17 14:24:47 --> Hooks Class Initialized
DEBUG - 2011-07-17 14:24:47 --> Utf8 Class Initialized
DEBUG - 2011-07-17 14:24:47 --> UTF-8 Support Enabled
DEBUG - 2011-07-17 14:24:47 --> URI Class Initialized
DEBUG - 2011-07-17 14:24:47 --> Router Class Initialized
DEBUG - 2011-07-17 14:24:47 --> Output Class Initialized
DEBUG - 2011-07-17 14:24:47 --> Input Class Initialized
DEBUG - 2011-07-17 14:24:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-17 14:24:47 --> Language Class Initialized
DEBUG - 2011-07-17 14:24:47 --> Loader Class Initialized
DEBUG - 2011-07-17 14:24:47 --> Controller Class Initialized
ERROR - 2011-07-17 14:24:47 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-17 14:24:47 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-17 14:24:47 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-17 14:24:47 --> Model Class Initialized
DEBUG - 2011-07-17 14:24:47 --> Model Class Initialized
DEBUG - 2011-07-17 14:24:48 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-17 14:24:48 --> Database Driver Class Initialized
DEBUG - 2011-07-17 14:24:48 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-17 14:24:48 --> Helper loaded: url_helper
DEBUG - 2011-07-17 14:24:48 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-17 14:24:48 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-17 14:24:48 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-17 14:24:48 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-17 14:24:48 --> Final output sent to browser
DEBUG - 2011-07-17 14:24:48 --> Total execution time: 0.9018
DEBUG - 2011-07-17 18:35:55 --> Config Class Initialized
DEBUG - 2011-07-17 18:35:55 --> Hooks Class Initialized
DEBUG - 2011-07-17 18:35:55 --> Utf8 Class Initialized
DEBUG - 2011-07-17 18:35:55 --> UTF-8 Support Enabled
DEBUG - 2011-07-17 18:35:55 --> URI Class Initialized
DEBUG - 2011-07-17 18:35:55 --> Router Class Initialized
DEBUG - 2011-07-17 18:35:55 --> Output Class Initialized
DEBUG - 2011-07-17 18:35:55 --> Input Class Initialized
DEBUG - 2011-07-17 18:35:55 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-17 18:35:55 --> Language Class Initialized
DEBUG - 2011-07-17 18:35:55 --> Loader Class Initialized
DEBUG - 2011-07-17 18:35:55 --> Controller Class Initialized
DEBUG - 2011-07-17 18:35:55 --> Model Class Initialized
DEBUG - 2011-07-17 18:35:55 --> Model Class Initialized
DEBUG - 2011-07-17 18:35:55 --> Model Class Initialized
DEBUG - 2011-07-17 18:35:55 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-17 18:35:55 --> Database Driver Class Initialized
DEBUG - 2011-07-17 18:35:55 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-17 18:35:55 --> Helper loaded: url_helper
DEBUG - 2011-07-17 18:35:55 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-17 18:35:55 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-17 18:35:55 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-17 18:35:55 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-17 18:35:55 --> Final output sent to browser
DEBUG - 2011-07-17 18:35:55 --> Total execution time: 0.5737
DEBUG - 2011-07-17 19:12:41 --> Config Class Initialized
DEBUG - 2011-07-17 19:12:41 --> Hooks Class Initialized
DEBUG - 2011-07-17 19:12:41 --> Utf8 Class Initialized
DEBUG - 2011-07-17 19:12:41 --> UTF-8 Support Enabled
DEBUG - 2011-07-17 19:12:41 --> URI Class Initialized
DEBUG - 2011-07-17 19:12:41 --> Router Class Initialized
DEBUG - 2011-07-17 19:12:41 --> Output Class Initialized
DEBUG - 2011-07-17 19:12:41 --> Input Class Initialized
DEBUG - 2011-07-17 19:12:41 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-17 19:12:41 --> Language Class Initialized
DEBUG - 2011-07-17 19:12:41 --> Loader Class Initialized
DEBUG - 2011-07-17 19:12:41 --> Controller Class Initialized
ERROR - 2011-07-17 19:12:41 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-17 19:12:41 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-17 19:12:41 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-17 19:12:41 --> Model Class Initialized
DEBUG - 2011-07-17 19:12:41 --> Model Class Initialized
DEBUG - 2011-07-17 19:12:41 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-17 19:12:41 --> Database Driver Class Initialized
DEBUG - 2011-07-17 19:12:41 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-17 19:12:41 --> Helper loaded: url_helper
DEBUG - 2011-07-17 19:12:41 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-17 19:12:41 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-17 19:12:41 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-17 19:12:41 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-17 19:12:41 --> Final output sent to browser
DEBUG - 2011-07-17 19:12:41 --> Total execution time: 0.2658
DEBUG - 2011-07-17 19:12:44 --> Config Class Initialized
DEBUG - 2011-07-17 19:12:44 --> Hooks Class Initialized
DEBUG - 2011-07-17 19:12:44 --> Utf8 Class Initialized
DEBUG - 2011-07-17 19:12:44 --> UTF-8 Support Enabled
DEBUG - 2011-07-17 19:12:44 --> URI Class Initialized
DEBUG - 2011-07-17 19:12:44 --> Router Class Initialized
DEBUG - 2011-07-17 19:12:44 --> Output Class Initialized
DEBUG - 2011-07-17 19:12:44 --> Input Class Initialized
DEBUG - 2011-07-17 19:12:44 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-17 19:12:44 --> Language Class Initialized
DEBUG - 2011-07-17 19:12:44 --> Loader Class Initialized
DEBUG - 2011-07-17 19:12:44 --> Controller Class Initialized
DEBUG - 2011-07-17 19:12:44 --> Model Class Initialized
DEBUG - 2011-07-17 19:12:44 --> Model Class Initialized
DEBUG - 2011-07-17 19:12:44 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-17 19:12:44 --> Database Driver Class Initialized
DEBUG - 2011-07-17 19:12:44 --> Final output sent to browser
DEBUG - 2011-07-17 19:12:44 --> Total execution time: 0.6112
DEBUG - 2011-07-17 19:12:47 --> Config Class Initialized
DEBUG - 2011-07-17 19:12:47 --> Hooks Class Initialized
DEBUG - 2011-07-17 19:12:47 --> Utf8 Class Initialized
DEBUG - 2011-07-17 19:12:47 --> UTF-8 Support Enabled
DEBUG - 2011-07-17 19:12:47 --> URI Class Initialized
DEBUG - 2011-07-17 19:12:47 --> Router Class Initialized
ERROR - 2011-07-17 19:12:47 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-17 19:13:03 --> Config Class Initialized
DEBUG - 2011-07-17 19:13:03 --> Hooks Class Initialized
DEBUG - 2011-07-17 19:13:03 --> Utf8 Class Initialized
DEBUG - 2011-07-17 19:13:03 --> UTF-8 Support Enabled
DEBUG - 2011-07-17 19:13:03 --> URI Class Initialized
DEBUG - 2011-07-17 19:13:03 --> Router Class Initialized
DEBUG - 2011-07-17 19:13:03 --> Output Class Initialized
DEBUG - 2011-07-17 19:13:03 --> Input Class Initialized
DEBUG - 2011-07-17 19:13:03 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-17 19:13:03 --> Language Class Initialized
DEBUG - 2011-07-17 19:13:03 --> Loader Class Initialized
DEBUG - 2011-07-17 19:13:03 --> Controller Class Initialized
ERROR - 2011-07-17 19:13:03 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-17 19:13:03 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-17 19:13:03 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-17 19:13:03 --> Model Class Initialized
DEBUG - 2011-07-17 19:13:03 --> Model Class Initialized
DEBUG - 2011-07-17 19:13:03 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-17 19:13:03 --> Database Driver Class Initialized
DEBUG - 2011-07-17 19:13:03 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-17 19:13:03 --> Helper loaded: url_helper
DEBUG - 2011-07-17 19:13:03 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-17 19:13:03 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-17 19:13:03 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-17 19:13:03 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-17 19:13:03 --> Final output sent to browser
DEBUG - 2011-07-17 19:13:03 --> Total execution time: 0.0579
DEBUG - 2011-07-17 19:13:04 --> Config Class Initialized
DEBUG - 2011-07-17 19:13:04 --> Hooks Class Initialized
DEBUG - 2011-07-17 19:13:04 --> Utf8 Class Initialized
DEBUG - 2011-07-17 19:13:04 --> UTF-8 Support Enabled
DEBUG - 2011-07-17 19:13:04 --> URI Class Initialized
DEBUG - 2011-07-17 19:13:04 --> Router Class Initialized
DEBUG - 2011-07-17 19:13:04 --> Output Class Initialized
DEBUG - 2011-07-17 19:13:04 --> Input Class Initialized
DEBUG - 2011-07-17 19:13:04 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-17 19:13:04 --> Language Class Initialized
DEBUG - 2011-07-17 19:13:04 --> Loader Class Initialized
DEBUG - 2011-07-17 19:13:04 --> Controller Class Initialized
DEBUG - 2011-07-17 19:13:04 --> Model Class Initialized
DEBUG - 2011-07-17 19:13:04 --> Model Class Initialized
DEBUG - 2011-07-17 19:13:04 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-17 19:13:04 --> Database Driver Class Initialized
DEBUG - 2011-07-17 19:13:05 --> Final output sent to browser
DEBUG - 2011-07-17 19:13:05 --> Total execution time: 0.5518
DEBUG - 2011-07-17 19:13:51 --> Config Class Initialized
DEBUG - 2011-07-17 19:13:51 --> Hooks Class Initialized
DEBUG - 2011-07-17 19:13:51 --> Utf8 Class Initialized
DEBUG - 2011-07-17 19:13:51 --> UTF-8 Support Enabled
DEBUG - 2011-07-17 19:13:51 --> URI Class Initialized
DEBUG - 2011-07-17 19:13:51 --> Router Class Initialized
DEBUG - 2011-07-17 19:13:51 --> Output Class Initialized
DEBUG - 2011-07-17 19:13:51 --> Input Class Initialized
DEBUG - 2011-07-17 19:13:51 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-17 19:13:51 --> Language Class Initialized
DEBUG - 2011-07-17 19:13:51 --> Loader Class Initialized
DEBUG - 2011-07-17 19:13:51 --> Controller Class Initialized
ERROR - 2011-07-17 19:13:51 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-17 19:13:51 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-17 19:13:51 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-17 19:13:51 --> Model Class Initialized
DEBUG - 2011-07-17 19:13:51 --> Model Class Initialized
DEBUG - 2011-07-17 19:13:51 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-17 19:13:51 --> Database Driver Class Initialized
DEBUG - 2011-07-17 19:13:51 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-17 19:13:51 --> Helper loaded: url_helper
DEBUG - 2011-07-17 19:13:51 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-17 19:13:51 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-17 19:13:51 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-17 19:13:51 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-17 19:13:51 --> Final output sent to browser
DEBUG - 2011-07-17 19:13:51 --> Total execution time: 0.1178
DEBUG - 2011-07-17 19:13:53 --> Config Class Initialized
DEBUG - 2011-07-17 19:13:53 --> Hooks Class Initialized
DEBUG - 2011-07-17 19:13:53 --> Utf8 Class Initialized
DEBUG - 2011-07-17 19:13:53 --> UTF-8 Support Enabled
DEBUG - 2011-07-17 19:13:53 --> URI Class Initialized
DEBUG - 2011-07-17 19:13:53 --> Router Class Initialized
DEBUG - 2011-07-17 19:13:53 --> Output Class Initialized
DEBUG - 2011-07-17 19:13:53 --> Input Class Initialized
DEBUG - 2011-07-17 19:13:53 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-17 19:13:53 --> Language Class Initialized
DEBUG - 2011-07-17 19:13:53 --> Loader Class Initialized
DEBUG - 2011-07-17 19:13:53 --> Controller Class Initialized
DEBUG - 2011-07-17 19:13:53 --> Model Class Initialized
DEBUG - 2011-07-17 19:13:53 --> Model Class Initialized
DEBUG - 2011-07-17 19:13:53 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-17 19:13:53 --> Database Driver Class Initialized
DEBUG - 2011-07-17 19:13:53 --> Config Class Initialized
DEBUG - 2011-07-17 19:13:53 --> Hooks Class Initialized
DEBUG - 2011-07-17 19:13:53 --> Utf8 Class Initialized
DEBUG - 2011-07-17 19:13:53 --> UTF-8 Support Enabled
DEBUG - 2011-07-17 19:13:53 --> URI Class Initialized
DEBUG - 2011-07-17 19:13:53 --> Router Class Initialized
DEBUG - 2011-07-17 19:13:53 --> Output Class Initialized
DEBUG - 2011-07-17 19:13:53 --> Input Class Initialized
DEBUG - 2011-07-17 19:13:53 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-17 19:13:53 --> Language Class Initialized
DEBUG - 2011-07-17 19:13:53 --> Loader Class Initialized
DEBUG - 2011-07-17 19:13:53 --> Controller Class Initialized
ERROR - 2011-07-17 19:13:53 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-17 19:13:53 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-17 19:13:53 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-17 19:13:53 --> Model Class Initialized
DEBUG - 2011-07-17 19:13:53 --> Model Class Initialized
DEBUG - 2011-07-17 19:13:53 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-17 19:13:53 --> Database Driver Class Initialized
DEBUG - 2011-07-17 19:13:53 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-17 19:13:53 --> Helper loaded: url_helper
DEBUG - 2011-07-17 19:13:53 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-17 19:13:53 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-17 19:13:53 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-17 19:13:53 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-17 19:13:53 --> Final output sent to browser
DEBUG - 2011-07-17 19:13:53 --> Total execution time: 0.1189
DEBUG - 2011-07-17 19:13:54 --> Final output sent to browser
DEBUG - 2011-07-17 19:13:54 --> Total execution time: 1.0836
DEBUG - 2011-07-17 19:14:26 --> Config Class Initialized
DEBUG - 2011-07-17 19:14:26 --> Hooks Class Initialized
DEBUG - 2011-07-17 19:14:26 --> Utf8 Class Initialized
DEBUG - 2011-07-17 19:14:26 --> UTF-8 Support Enabled
DEBUG - 2011-07-17 19:14:26 --> URI Class Initialized
DEBUG - 2011-07-17 19:14:26 --> Router Class Initialized
DEBUG - 2011-07-17 19:14:26 --> Output Class Initialized
DEBUG - 2011-07-17 19:14:26 --> Input Class Initialized
DEBUG - 2011-07-17 19:14:26 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-17 19:14:26 --> Language Class Initialized
DEBUG - 2011-07-17 19:14:26 --> Loader Class Initialized
DEBUG - 2011-07-17 19:14:26 --> Controller Class Initialized
ERROR - 2011-07-17 19:14:26 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-17 19:14:26 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-17 19:14:26 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-17 19:14:26 --> Model Class Initialized
DEBUG - 2011-07-17 19:14:26 --> Model Class Initialized
DEBUG - 2011-07-17 19:14:26 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-17 19:14:26 --> Database Driver Class Initialized
DEBUG - 2011-07-17 19:14:26 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-17 19:14:26 --> Helper loaded: url_helper
DEBUG - 2011-07-17 19:14:26 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-17 19:14:26 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-17 19:14:26 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-17 19:14:26 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-17 19:14:26 --> Final output sent to browser
DEBUG - 2011-07-17 19:14:26 --> Total execution time: 0.0278
DEBUG - 2011-07-17 19:14:27 --> Config Class Initialized
DEBUG - 2011-07-17 19:14:27 --> Hooks Class Initialized
DEBUG - 2011-07-17 19:14:27 --> Utf8 Class Initialized
DEBUG - 2011-07-17 19:14:27 --> UTF-8 Support Enabled
DEBUG - 2011-07-17 19:14:27 --> URI Class Initialized
DEBUG - 2011-07-17 19:14:27 --> Router Class Initialized
DEBUG - 2011-07-17 19:14:27 --> Output Class Initialized
DEBUG - 2011-07-17 19:14:27 --> Input Class Initialized
DEBUG - 2011-07-17 19:14:27 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-17 19:14:27 --> Language Class Initialized
DEBUG - 2011-07-17 19:14:27 --> Loader Class Initialized
DEBUG - 2011-07-17 19:14:27 --> Controller Class Initialized
DEBUG - 2011-07-17 19:14:27 --> Model Class Initialized
DEBUG - 2011-07-17 19:14:27 --> Model Class Initialized
DEBUG - 2011-07-17 19:14:27 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-17 19:14:27 --> Database Driver Class Initialized
DEBUG - 2011-07-17 19:14:27 --> Config Class Initialized
DEBUG - 2011-07-17 19:14:27 --> Hooks Class Initialized
DEBUG - 2011-07-17 19:14:27 --> Utf8 Class Initialized
DEBUG - 2011-07-17 19:14:27 --> UTF-8 Support Enabled
DEBUG - 2011-07-17 19:14:27 --> URI Class Initialized
DEBUG - 2011-07-17 19:14:27 --> Router Class Initialized
DEBUG - 2011-07-17 19:14:27 --> Output Class Initialized
DEBUG - 2011-07-17 19:14:27 --> Input Class Initialized
DEBUG - 2011-07-17 19:14:27 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-17 19:14:27 --> Language Class Initialized
DEBUG - 2011-07-17 19:14:27 --> Loader Class Initialized
DEBUG - 2011-07-17 19:14:27 --> Controller Class Initialized
ERROR - 2011-07-17 19:14:27 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-17 19:14:27 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-17 19:14:27 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-17 19:14:27 --> Model Class Initialized
DEBUG - 2011-07-17 19:14:27 --> Model Class Initialized
DEBUG - 2011-07-17 19:14:27 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-17 19:14:27 --> Database Driver Class Initialized
DEBUG - 2011-07-17 19:14:27 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-17 19:14:27 --> Helper loaded: url_helper
DEBUG - 2011-07-17 19:14:27 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-17 19:14:27 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-17 19:14:27 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-17 19:14:27 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-17 19:14:27 --> Final output sent to browser
DEBUG - 2011-07-17 19:14:27 --> Total execution time: 0.0417
DEBUG - 2011-07-17 19:14:27 --> Final output sent to browser
DEBUG - 2011-07-17 19:14:27 --> Total execution time: 0.5292
DEBUG - 2011-07-17 19:14:40 --> Config Class Initialized
DEBUG - 2011-07-17 19:14:40 --> Hooks Class Initialized
DEBUG - 2011-07-17 19:14:40 --> Utf8 Class Initialized
DEBUG - 2011-07-17 19:14:40 --> UTF-8 Support Enabled
DEBUG - 2011-07-17 19:14:40 --> URI Class Initialized
DEBUG - 2011-07-17 19:14:40 --> Router Class Initialized
DEBUG - 2011-07-17 19:14:40 --> Output Class Initialized
DEBUG - 2011-07-17 19:14:40 --> Input Class Initialized
DEBUG - 2011-07-17 19:14:40 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-17 19:14:40 --> Language Class Initialized
DEBUG - 2011-07-17 19:14:40 --> Loader Class Initialized
DEBUG - 2011-07-17 19:14:40 --> Controller Class Initialized
ERROR - 2011-07-17 19:14:40 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-17 19:14:40 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-17 19:14:40 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-17 19:14:40 --> Model Class Initialized
DEBUG - 2011-07-17 19:14:40 --> Model Class Initialized
DEBUG - 2011-07-17 19:14:40 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-17 19:14:40 --> Database Driver Class Initialized
DEBUG - 2011-07-17 19:14:40 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-17 19:14:40 --> Helper loaded: url_helper
DEBUG - 2011-07-17 19:14:40 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-17 19:14:40 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-17 19:14:40 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-17 19:14:40 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-17 19:14:40 --> Final output sent to browser
DEBUG - 2011-07-17 19:14:40 --> Total execution time: 0.0288
DEBUG - 2011-07-17 19:14:41 --> Config Class Initialized
DEBUG - 2011-07-17 19:14:41 --> Hooks Class Initialized
DEBUG - 2011-07-17 19:14:41 --> Utf8 Class Initialized
DEBUG - 2011-07-17 19:14:41 --> UTF-8 Support Enabled
DEBUG - 2011-07-17 19:14:41 --> URI Class Initialized
DEBUG - 2011-07-17 19:14:41 --> Router Class Initialized
DEBUG - 2011-07-17 19:14:41 --> Output Class Initialized
DEBUG - 2011-07-17 19:14:41 --> Input Class Initialized
DEBUG - 2011-07-17 19:14:41 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-17 19:14:41 --> Language Class Initialized
DEBUG - 2011-07-17 19:14:41 --> Loader Class Initialized
DEBUG - 2011-07-17 19:14:41 --> Controller Class Initialized
ERROR - 2011-07-17 19:14:41 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-17 19:14:41 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-17 19:14:41 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-17 19:14:41 --> Model Class Initialized
DEBUG - 2011-07-17 19:14:41 --> Model Class Initialized
DEBUG - 2011-07-17 19:14:41 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-17 19:14:41 --> Database Driver Class Initialized
DEBUG - 2011-07-17 19:14:41 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-17 19:14:41 --> Helper loaded: url_helper
DEBUG - 2011-07-17 19:14:41 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-17 19:14:41 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-17 19:14:41 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-17 19:14:41 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-17 19:14:41 --> Final output sent to browser
DEBUG - 2011-07-17 19:14:41 --> Total execution time: 0.0384
DEBUG - 2011-07-17 19:14:41 --> Config Class Initialized
DEBUG - 2011-07-17 19:14:41 --> Hooks Class Initialized
DEBUG - 2011-07-17 19:14:41 --> Utf8 Class Initialized
DEBUG - 2011-07-17 19:14:41 --> UTF-8 Support Enabled
DEBUG - 2011-07-17 19:14:41 --> URI Class Initialized
DEBUG - 2011-07-17 19:14:41 --> Router Class Initialized
DEBUG - 2011-07-17 19:14:41 --> Output Class Initialized
DEBUG - 2011-07-17 19:14:41 --> Input Class Initialized
DEBUG - 2011-07-17 19:14:41 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-17 19:14:41 --> Language Class Initialized
DEBUG - 2011-07-17 19:14:41 --> Loader Class Initialized
DEBUG - 2011-07-17 19:14:41 --> Controller Class Initialized
DEBUG - 2011-07-17 19:14:41 --> Model Class Initialized
DEBUG - 2011-07-17 19:14:41 --> Model Class Initialized
DEBUG - 2011-07-17 19:14:41 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-17 19:14:41 --> Database Driver Class Initialized
DEBUG - 2011-07-17 19:14:41 --> Final output sent to browser
DEBUG - 2011-07-17 19:14:41 --> Total execution time: 0.5693
DEBUG - 2011-07-17 19:14:59 --> Config Class Initialized
DEBUG - 2011-07-17 19:14:59 --> Hooks Class Initialized
DEBUG - 2011-07-17 19:14:59 --> Utf8 Class Initialized
DEBUG - 2011-07-17 19:14:59 --> UTF-8 Support Enabled
DEBUG - 2011-07-17 19:14:59 --> URI Class Initialized
DEBUG - 2011-07-17 19:14:59 --> Router Class Initialized
DEBUG - 2011-07-17 19:14:59 --> Output Class Initialized
DEBUG - 2011-07-17 19:14:59 --> Input Class Initialized
DEBUG - 2011-07-17 19:14:59 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-17 19:14:59 --> Language Class Initialized
DEBUG - 2011-07-17 19:14:59 --> Loader Class Initialized
DEBUG - 2011-07-17 19:14:59 --> Controller Class Initialized
ERROR - 2011-07-17 19:14:59 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-17 19:14:59 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-17 19:14:59 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-17 19:14:59 --> Model Class Initialized
DEBUG - 2011-07-17 19:14:59 --> Model Class Initialized
DEBUG - 2011-07-17 19:14:59 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-17 19:14:59 --> Database Driver Class Initialized
DEBUG - 2011-07-17 19:14:59 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-17 19:14:59 --> Helper loaded: url_helper
DEBUG - 2011-07-17 19:14:59 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-17 19:14:59 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-17 19:14:59 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-17 19:14:59 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-17 19:14:59 --> Final output sent to browser
DEBUG - 2011-07-17 19:14:59 --> Total execution time: 0.0285
DEBUG - 2011-07-17 19:15:00 --> Config Class Initialized
DEBUG - 2011-07-17 19:15:00 --> Hooks Class Initialized
DEBUG - 2011-07-17 19:15:00 --> Utf8 Class Initialized
DEBUG - 2011-07-17 19:15:00 --> UTF-8 Support Enabled
DEBUG - 2011-07-17 19:15:00 --> URI Class Initialized
DEBUG - 2011-07-17 19:15:00 --> Router Class Initialized
DEBUG - 2011-07-17 19:15:00 --> Output Class Initialized
DEBUG - 2011-07-17 19:15:00 --> Input Class Initialized
DEBUG - 2011-07-17 19:15:00 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-17 19:15:00 --> Language Class Initialized
DEBUG - 2011-07-17 19:15:00 --> Loader Class Initialized
DEBUG - 2011-07-17 19:15:00 --> Controller Class Initialized
ERROR - 2011-07-17 19:15:00 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-17 19:15:00 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-17 19:15:00 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-17 19:15:00 --> Model Class Initialized
DEBUG - 2011-07-17 19:15:00 --> Model Class Initialized
DEBUG - 2011-07-17 19:15:00 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-17 19:15:00 --> Database Driver Class Initialized
DEBUG - 2011-07-17 19:15:00 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-17 19:15:00 --> Helper loaded: url_helper
DEBUG - 2011-07-17 19:15:00 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-17 19:15:00 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-17 19:15:00 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-17 19:15:00 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-17 19:15:00 --> Final output sent to browser
DEBUG - 2011-07-17 19:15:00 --> Total execution time: 0.0290
DEBUG - 2011-07-17 19:15:09 --> Config Class Initialized
DEBUG - 2011-07-17 19:15:09 --> Hooks Class Initialized
DEBUG - 2011-07-17 19:15:09 --> Utf8 Class Initialized
DEBUG - 2011-07-17 19:15:09 --> UTF-8 Support Enabled
DEBUG - 2011-07-17 19:15:09 --> URI Class Initialized
DEBUG - 2011-07-17 19:15:09 --> Router Class Initialized
DEBUG - 2011-07-17 19:15:09 --> Output Class Initialized
DEBUG - 2011-07-17 19:15:09 --> Input Class Initialized
DEBUG - 2011-07-17 19:15:09 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-17 19:15:09 --> Language Class Initialized
DEBUG - 2011-07-17 19:15:09 --> Loader Class Initialized
DEBUG - 2011-07-17 19:15:09 --> Controller Class Initialized
DEBUG - 2011-07-17 19:15:09 --> Model Class Initialized
DEBUG - 2011-07-17 19:15:09 --> Model Class Initialized
DEBUG - 2011-07-17 19:15:09 --> Model Class Initialized
DEBUG - 2011-07-17 19:15:09 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-17 19:15:09 --> Database Driver Class Initialized
DEBUG - 2011-07-17 19:15:10 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-17 19:15:10 --> Helper loaded: url_helper
DEBUG - 2011-07-17 19:15:10 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-17 19:15:10 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-17 19:15:10 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-17 19:15:10 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-17 19:15:10 --> Final output sent to browser
DEBUG - 2011-07-17 19:15:10 --> Total execution time: 0.6301
DEBUG - 2011-07-17 19:15:30 --> Config Class Initialized
DEBUG - 2011-07-17 19:15:30 --> Hooks Class Initialized
DEBUG - 2011-07-17 19:15:30 --> Utf8 Class Initialized
DEBUG - 2011-07-17 19:15:30 --> UTF-8 Support Enabled
DEBUG - 2011-07-17 19:15:30 --> URI Class Initialized
DEBUG - 2011-07-17 19:15:30 --> Router Class Initialized
DEBUG - 2011-07-17 19:15:30 --> Output Class Initialized
DEBUG - 2011-07-17 19:15:30 --> Input Class Initialized
DEBUG - 2011-07-17 19:15:30 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-17 19:15:30 --> Language Class Initialized
DEBUG - 2011-07-17 19:15:30 --> Loader Class Initialized
DEBUG - 2011-07-17 19:15:30 --> Controller Class Initialized
DEBUG - 2011-07-17 19:15:30 --> Model Class Initialized
DEBUG - 2011-07-17 19:15:30 --> Model Class Initialized
DEBUG - 2011-07-17 19:15:30 --> Model Class Initialized
DEBUG - 2011-07-17 19:15:30 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-17 19:15:30 --> Database Driver Class Initialized
DEBUG - 2011-07-17 19:15:31 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-17 19:15:31 --> Helper loaded: url_helper
DEBUG - 2011-07-17 19:15:31 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-17 19:15:31 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-17 19:15:31 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-17 19:15:31 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-17 19:15:31 --> Final output sent to browser
DEBUG - 2011-07-17 19:15:31 --> Total execution time: 0.3141
DEBUG - 2011-07-17 19:15:32 --> Config Class Initialized
DEBUG - 2011-07-17 19:15:32 --> Hooks Class Initialized
DEBUG - 2011-07-17 19:15:32 --> Utf8 Class Initialized
DEBUG - 2011-07-17 19:15:32 --> UTF-8 Support Enabled
DEBUG - 2011-07-17 19:15:32 --> URI Class Initialized
DEBUG - 2011-07-17 19:15:32 --> Router Class Initialized
DEBUG - 2011-07-17 19:15:32 --> Output Class Initialized
DEBUG - 2011-07-17 19:15:32 --> Input Class Initialized
DEBUG - 2011-07-17 19:15:32 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-17 19:15:32 --> Language Class Initialized
DEBUG - 2011-07-17 19:15:32 --> Loader Class Initialized
DEBUG - 2011-07-17 19:15:32 --> Controller Class Initialized
DEBUG - 2011-07-17 19:15:32 --> Model Class Initialized
DEBUG - 2011-07-17 19:15:32 --> Model Class Initialized
DEBUG - 2011-07-17 19:15:32 --> Model Class Initialized
DEBUG - 2011-07-17 19:15:32 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-17 19:15:32 --> Database Driver Class Initialized
DEBUG - 2011-07-17 19:15:32 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-17 19:15:32 --> Helper loaded: url_helper
DEBUG - 2011-07-17 19:15:32 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-17 19:15:32 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-17 19:15:32 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-17 19:15:32 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-17 19:15:32 --> Final output sent to browser
DEBUG - 2011-07-17 19:15:32 --> Total execution time: 0.0506
DEBUG - 2011-07-17 19:15:38 --> Config Class Initialized
DEBUG - 2011-07-17 19:15:38 --> Hooks Class Initialized
DEBUG - 2011-07-17 19:15:38 --> Utf8 Class Initialized
DEBUG - 2011-07-17 19:15:38 --> UTF-8 Support Enabled
DEBUG - 2011-07-17 19:15:38 --> URI Class Initialized
DEBUG - 2011-07-17 19:15:38 --> Router Class Initialized
DEBUG - 2011-07-17 19:15:38 --> Output Class Initialized
DEBUG - 2011-07-17 19:15:38 --> Input Class Initialized
DEBUG - 2011-07-17 19:15:38 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-17 19:15:38 --> Language Class Initialized
DEBUG - 2011-07-17 19:15:38 --> Loader Class Initialized
DEBUG - 2011-07-17 19:15:38 --> Controller Class Initialized
DEBUG - 2011-07-17 19:15:38 --> Model Class Initialized
DEBUG - 2011-07-17 19:15:38 --> Model Class Initialized
DEBUG - 2011-07-17 19:15:38 --> Model Class Initialized
DEBUG - 2011-07-17 19:15:38 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-17 19:15:38 --> Database Driver Class Initialized
DEBUG - 2011-07-17 19:15:38 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-17 19:15:38 --> Helper loaded: url_helper
DEBUG - 2011-07-17 19:15:38 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-17 19:15:38 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-17 19:15:38 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-17 19:15:38 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-17 19:15:38 --> Final output sent to browser
DEBUG - 2011-07-17 19:15:38 --> Total execution time: 0.5494
DEBUG - 2011-07-17 19:15:42 --> Config Class Initialized
DEBUG - 2011-07-17 19:15:42 --> Hooks Class Initialized
DEBUG - 2011-07-17 19:15:42 --> Utf8 Class Initialized
DEBUG - 2011-07-17 19:15:42 --> UTF-8 Support Enabled
DEBUG - 2011-07-17 19:15:42 --> URI Class Initialized
DEBUG - 2011-07-17 19:15:42 --> Router Class Initialized
DEBUG - 2011-07-17 19:15:42 --> Output Class Initialized
DEBUG - 2011-07-17 19:15:42 --> Input Class Initialized
DEBUG - 2011-07-17 19:15:42 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-17 19:15:42 --> Language Class Initialized
DEBUG - 2011-07-17 19:15:42 --> Loader Class Initialized
DEBUG - 2011-07-17 19:15:42 --> Controller Class Initialized
DEBUG - 2011-07-17 19:15:42 --> Model Class Initialized
DEBUG - 2011-07-17 19:15:42 --> Model Class Initialized
DEBUG - 2011-07-17 19:15:42 --> Model Class Initialized
DEBUG - 2011-07-17 19:15:42 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-17 19:15:42 --> Database Driver Class Initialized
DEBUG - 2011-07-17 19:15:42 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-17 19:15:42 --> Helper loaded: url_helper
DEBUG - 2011-07-17 19:15:42 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-17 19:15:42 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-17 19:15:42 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-17 19:15:42 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-17 19:15:42 --> Final output sent to browser
DEBUG - 2011-07-17 19:15:42 --> Total execution time: 0.0939
DEBUG - 2011-07-17 19:15:46 --> Config Class Initialized
DEBUG - 2011-07-17 19:15:46 --> Hooks Class Initialized
DEBUG - 2011-07-17 19:15:46 --> Utf8 Class Initialized
DEBUG - 2011-07-17 19:15:46 --> UTF-8 Support Enabled
DEBUG - 2011-07-17 19:15:46 --> URI Class Initialized
DEBUG - 2011-07-17 19:15:46 --> Router Class Initialized
DEBUG - 2011-07-17 19:15:46 --> Output Class Initialized
DEBUG - 2011-07-17 19:15:46 --> Input Class Initialized
DEBUG - 2011-07-17 19:15:46 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-17 19:15:46 --> Language Class Initialized
DEBUG - 2011-07-17 19:15:46 --> Loader Class Initialized
DEBUG - 2011-07-17 19:15:46 --> Controller Class Initialized
DEBUG - 2011-07-17 19:15:46 --> Model Class Initialized
DEBUG - 2011-07-17 19:15:46 --> Model Class Initialized
DEBUG - 2011-07-17 19:15:46 --> Model Class Initialized
DEBUG - 2011-07-17 19:15:46 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-17 19:15:46 --> Database Driver Class Initialized
DEBUG - 2011-07-17 19:15:46 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-17 19:15:46 --> Helper loaded: url_helper
DEBUG - 2011-07-17 19:15:46 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-17 19:15:46 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-17 19:15:46 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-17 19:15:46 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-17 19:15:46 --> Final output sent to browser
DEBUG - 2011-07-17 19:15:46 --> Total execution time: 0.3343
DEBUG - 2011-07-17 19:15:59 --> Config Class Initialized
DEBUG - 2011-07-17 19:15:59 --> Hooks Class Initialized
DEBUG - 2011-07-17 19:15:59 --> Utf8 Class Initialized
DEBUG - 2011-07-17 19:15:59 --> UTF-8 Support Enabled
DEBUG - 2011-07-17 19:15:59 --> URI Class Initialized
DEBUG - 2011-07-17 19:15:59 --> Router Class Initialized
DEBUG - 2011-07-17 19:15:59 --> Output Class Initialized
DEBUG - 2011-07-17 19:15:59 --> Input Class Initialized
DEBUG - 2011-07-17 19:15:59 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-17 19:15:59 --> Language Class Initialized
DEBUG - 2011-07-17 19:15:59 --> Loader Class Initialized
DEBUG - 2011-07-17 19:15:59 --> Controller Class Initialized
DEBUG - 2011-07-17 19:15:59 --> Model Class Initialized
DEBUG - 2011-07-17 19:15:59 --> Model Class Initialized
DEBUG - 2011-07-17 19:15:59 --> Model Class Initialized
DEBUG - 2011-07-17 19:15:59 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-17 19:15:59 --> Database Driver Class Initialized
DEBUG - 2011-07-17 19:15:59 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-17 19:15:59 --> Helper loaded: url_helper
DEBUG - 2011-07-17 19:15:59 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-17 19:15:59 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-17 19:15:59 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-17 19:15:59 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-17 19:15:59 --> Final output sent to browser
DEBUG - 2011-07-17 19:15:59 --> Total execution time: 0.8933
DEBUG - 2011-07-17 19:16:06 --> Config Class Initialized
DEBUG - 2011-07-17 19:16:06 --> Hooks Class Initialized
DEBUG - 2011-07-17 19:16:06 --> Utf8 Class Initialized
DEBUG - 2011-07-17 19:16:06 --> UTF-8 Support Enabled
DEBUG - 2011-07-17 19:16:06 --> URI Class Initialized
DEBUG - 2011-07-17 19:16:06 --> Router Class Initialized
DEBUG - 2011-07-17 19:16:06 --> Output Class Initialized
DEBUG - 2011-07-17 19:16:06 --> Input Class Initialized
DEBUG - 2011-07-17 19:16:06 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-17 19:16:06 --> Language Class Initialized
DEBUG - 2011-07-17 19:16:06 --> Loader Class Initialized
DEBUG - 2011-07-17 19:16:06 --> Controller Class Initialized
DEBUG - 2011-07-17 19:16:06 --> Model Class Initialized
DEBUG - 2011-07-17 19:16:06 --> Model Class Initialized
DEBUG - 2011-07-17 19:16:06 --> Model Class Initialized
DEBUG - 2011-07-17 19:16:06 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-17 19:16:06 --> Database Driver Class Initialized
DEBUG - 2011-07-17 19:16:06 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-17 19:16:06 --> Helper loaded: url_helper
DEBUG - 2011-07-17 19:16:06 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-17 19:16:06 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-17 19:16:06 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-17 19:16:06 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-17 19:16:06 --> Final output sent to browser
DEBUG - 2011-07-17 19:16:06 --> Total execution time: 0.0486
DEBUG - 2011-07-17 19:16:09 --> Config Class Initialized
DEBUG - 2011-07-17 19:16:09 --> Hooks Class Initialized
DEBUG - 2011-07-17 19:16:09 --> Utf8 Class Initialized
DEBUG - 2011-07-17 19:16:09 --> UTF-8 Support Enabled
DEBUG - 2011-07-17 19:16:09 --> URI Class Initialized
DEBUG - 2011-07-17 19:16:09 --> Router Class Initialized
DEBUG - 2011-07-17 19:16:09 --> Output Class Initialized
DEBUG - 2011-07-17 19:16:09 --> Input Class Initialized
DEBUG - 2011-07-17 19:16:09 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-17 19:16:09 --> Language Class Initialized
DEBUG - 2011-07-17 19:16:09 --> Loader Class Initialized
DEBUG - 2011-07-17 19:16:09 --> Controller Class Initialized
DEBUG - 2011-07-17 19:16:09 --> Model Class Initialized
DEBUG - 2011-07-17 19:16:09 --> Model Class Initialized
DEBUG - 2011-07-17 19:16:09 --> Model Class Initialized
DEBUG - 2011-07-17 19:16:09 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-17 19:16:09 --> Database Driver Class Initialized
DEBUG - 2011-07-17 19:16:09 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-17 19:16:09 --> Helper loaded: url_helper
DEBUG - 2011-07-17 19:16:09 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-17 19:16:09 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-17 19:16:09 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-17 19:16:09 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-17 19:16:09 --> Final output sent to browser
DEBUG - 2011-07-17 19:16:09 --> Total execution time: 0.0476
DEBUG - 2011-07-17 19:16:10 --> Config Class Initialized
DEBUG - 2011-07-17 19:16:10 --> Hooks Class Initialized
DEBUG - 2011-07-17 19:16:10 --> Utf8 Class Initialized
DEBUG - 2011-07-17 19:16:10 --> UTF-8 Support Enabled
DEBUG - 2011-07-17 19:16:10 --> URI Class Initialized
DEBUG - 2011-07-17 19:16:10 --> Router Class Initialized
DEBUG - 2011-07-17 19:16:10 --> Output Class Initialized
DEBUG - 2011-07-17 19:16:10 --> Input Class Initialized
DEBUG - 2011-07-17 19:16:10 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-17 19:16:10 --> Language Class Initialized
DEBUG - 2011-07-17 19:16:10 --> Loader Class Initialized
DEBUG - 2011-07-17 19:16:10 --> Controller Class Initialized
DEBUG - 2011-07-17 19:16:10 --> Model Class Initialized
DEBUG - 2011-07-17 19:16:10 --> Model Class Initialized
DEBUG - 2011-07-17 19:16:10 --> Model Class Initialized
DEBUG - 2011-07-17 19:16:10 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-17 19:16:10 --> Database Driver Class Initialized
DEBUG - 2011-07-17 19:16:11 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-17 19:16:11 --> Helper loaded: url_helper
DEBUG - 2011-07-17 19:16:11 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-17 19:16:11 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-17 19:16:11 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-17 19:16:11 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-17 19:16:11 --> Final output sent to browser
DEBUG - 2011-07-17 19:16:11 --> Total execution time: 0.3825
DEBUG - 2011-07-17 19:16:12 --> Config Class Initialized
DEBUG - 2011-07-17 19:16:12 --> Hooks Class Initialized
DEBUG - 2011-07-17 19:16:12 --> Utf8 Class Initialized
DEBUG - 2011-07-17 19:16:12 --> UTF-8 Support Enabled
DEBUG - 2011-07-17 19:16:12 --> URI Class Initialized
DEBUG - 2011-07-17 19:16:12 --> Router Class Initialized
DEBUG - 2011-07-17 19:16:12 --> Output Class Initialized
DEBUG - 2011-07-17 19:16:12 --> Input Class Initialized
DEBUG - 2011-07-17 19:16:12 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-17 19:16:12 --> Language Class Initialized
DEBUG - 2011-07-17 19:16:12 --> Loader Class Initialized
DEBUG - 2011-07-17 19:16:12 --> Controller Class Initialized
DEBUG - 2011-07-17 19:16:12 --> Model Class Initialized
DEBUG - 2011-07-17 19:16:12 --> Model Class Initialized
DEBUG - 2011-07-17 19:16:12 --> Model Class Initialized
DEBUG - 2011-07-17 19:16:12 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-17 19:16:12 --> Database Driver Class Initialized
DEBUG - 2011-07-17 19:16:12 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-17 19:16:12 --> Helper loaded: url_helper
DEBUG - 2011-07-17 19:16:12 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-17 19:16:12 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-17 19:16:12 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-17 19:16:12 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-17 19:16:12 --> Final output sent to browser
DEBUG - 2011-07-17 19:16:12 --> Total execution time: 0.1602
DEBUG - 2011-07-17 19:16:24 --> Config Class Initialized
DEBUG - 2011-07-17 19:16:24 --> Hooks Class Initialized
DEBUG - 2011-07-17 19:16:24 --> Utf8 Class Initialized
DEBUG - 2011-07-17 19:16:24 --> UTF-8 Support Enabled
DEBUG - 2011-07-17 19:16:24 --> URI Class Initialized
DEBUG - 2011-07-17 19:16:24 --> Router Class Initialized
DEBUG - 2011-07-17 19:16:24 --> Output Class Initialized
DEBUG - 2011-07-17 19:16:24 --> Input Class Initialized
DEBUG - 2011-07-17 19:16:24 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-17 19:16:24 --> Language Class Initialized
DEBUG - 2011-07-17 19:16:24 --> Loader Class Initialized
DEBUG - 2011-07-17 19:16:24 --> Controller Class Initialized
DEBUG - 2011-07-17 19:16:24 --> Model Class Initialized
DEBUG - 2011-07-17 19:16:24 --> Model Class Initialized
DEBUG - 2011-07-17 19:16:24 --> Model Class Initialized
DEBUG - 2011-07-17 19:16:24 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-17 19:16:24 --> Database Driver Class Initialized
DEBUG - 2011-07-17 19:16:24 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-17 19:16:24 --> Helper loaded: url_helper
DEBUG - 2011-07-17 19:16:24 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-17 19:16:24 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-17 19:16:24 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-17 19:16:24 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-17 19:16:24 --> Final output sent to browser
DEBUG - 2011-07-17 19:16:24 --> Total execution time: 0.2560
DEBUG - 2011-07-17 19:16:25 --> Config Class Initialized
DEBUG - 2011-07-17 19:16:25 --> Hooks Class Initialized
DEBUG - 2011-07-17 19:16:25 --> Utf8 Class Initialized
DEBUG - 2011-07-17 19:16:25 --> UTF-8 Support Enabled
DEBUG - 2011-07-17 19:16:25 --> URI Class Initialized
DEBUG - 2011-07-17 19:16:25 --> Router Class Initialized
DEBUG - 2011-07-17 19:16:25 --> Output Class Initialized
DEBUG - 2011-07-17 19:16:25 --> Input Class Initialized
DEBUG - 2011-07-17 19:16:25 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-17 19:16:25 --> Language Class Initialized
DEBUG - 2011-07-17 19:16:25 --> Loader Class Initialized
DEBUG - 2011-07-17 19:16:25 --> Controller Class Initialized
DEBUG - 2011-07-17 19:16:25 --> Model Class Initialized
DEBUG - 2011-07-17 19:16:25 --> Model Class Initialized
DEBUG - 2011-07-17 19:16:25 --> Model Class Initialized
DEBUG - 2011-07-17 19:16:25 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-17 19:16:25 --> Database Driver Class Initialized
DEBUG - 2011-07-17 19:16:25 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-17 19:16:25 --> Helper loaded: url_helper
DEBUG - 2011-07-17 19:16:25 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-17 19:16:25 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-17 19:16:25 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-17 19:16:25 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-17 19:16:25 --> Final output sent to browser
DEBUG - 2011-07-17 19:16:25 --> Total execution time: 0.1001
DEBUG - 2011-07-17 19:16:39 --> Config Class Initialized
DEBUG - 2011-07-17 19:16:39 --> Hooks Class Initialized
DEBUG - 2011-07-17 19:16:39 --> Utf8 Class Initialized
DEBUG - 2011-07-17 19:16:39 --> UTF-8 Support Enabled
DEBUG - 2011-07-17 19:16:39 --> URI Class Initialized
DEBUG - 2011-07-17 19:16:39 --> Router Class Initialized
DEBUG - 2011-07-17 19:16:39 --> Output Class Initialized
DEBUG - 2011-07-17 19:16:39 --> Input Class Initialized
DEBUG - 2011-07-17 19:16:39 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-17 19:16:39 --> Language Class Initialized
DEBUG - 2011-07-17 19:16:39 --> Loader Class Initialized
DEBUG - 2011-07-17 19:16:39 --> Controller Class Initialized
DEBUG - 2011-07-17 19:16:39 --> Model Class Initialized
DEBUG - 2011-07-17 19:16:39 --> Model Class Initialized
DEBUG - 2011-07-17 19:16:39 --> Model Class Initialized
DEBUG - 2011-07-17 19:16:39 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-17 19:16:39 --> Database Driver Class Initialized
DEBUG - 2011-07-17 19:16:39 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-17 19:16:39 --> Helper loaded: url_helper
DEBUG - 2011-07-17 19:16:39 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-17 19:16:39 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-17 19:16:39 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-17 19:16:39 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-17 19:16:39 --> Final output sent to browser
DEBUG - 2011-07-17 19:16:39 --> Total execution time: 0.4981
DEBUG - 2011-07-17 19:16:41 --> Config Class Initialized
DEBUG - 2011-07-17 19:16:41 --> Hooks Class Initialized
DEBUG - 2011-07-17 19:16:41 --> Utf8 Class Initialized
DEBUG - 2011-07-17 19:16:41 --> UTF-8 Support Enabled
DEBUG - 2011-07-17 19:16:41 --> URI Class Initialized
DEBUG - 2011-07-17 19:16:41 --> Router Class Initialized
DEBUG - 2011-07-17 19:16:41 --> Output Class Initialized
DEBUG - 2011-07-17 19:16:41 --> Input Class Initialized
DEBUG - 2011-07-17 19:16:41 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-17 19:16:41 --> Language Class Initialized
DEBUG - 2011-07-17 19:16:41 --> Loader Class Initialized
DEBUG - 2011-07-17 19:16:41 --> Controller Class Initialized
DEBUG - 2011-07-17 19:16:41 --> Model Class Initialized
DEBUG - 2011-07-17 19:16:41 --> Model Class Initialized
DEBUG - 2011-07-17 19:16:41 --> Model Class Initialized
DEBUG - 2011-07-17 19:16:41 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-17 19:16:41 --> Database Driver Class Initialized
DEBUG - 2011-07-17 19:16:41 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-17 19:16:41 --> Helper loaded: url_helper
DEBUG - 2011-07-17 19:16:41 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-17 19:16:41 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-17 19:16:41 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-17 19:16:41 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-17 19:16:41 --> Final output sent to browser
DEBUG - 2011-07-17 19:16:41 --> Total execution time: 0.0818
DEBUG - 2011-07-17 20:57:51 --> Config Class Initialized
DEBUG - 2011-07-17 20:57:51 --> Hooks Class Initialized
DEBUG - 2011-07-17 20:57:51 --> Utf8 Class Initialized
DEBUG - 2011-07-17 20:57:51 --> UTF-8 Support Enabled
DEBUG - 2011-07-17 20:57:51 --> URI Class Initialized
DEBUG - 2011-07-17 20:57:51 --> Router Class Initialized
DEBUG - 2011-07-17 20:57:51 --> Output Class Initialized
DEBUG - 2011-07-17 20:57:51 --> Input Class Initialized
DEBUG - 2011-07-17 20:57:51 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-17 20:57:51 --> Language Class Initialized
DEBUG - 2011-07-17 20:57:51 --> Loader Class Initialized
DEBUG - 2011-07-17 20:57:51 --> Controller Class Initialized
DEBUG - 2011-07-17 20:57:51 --> Model Class Initialized
DEBUG - 2011-07-17 20:57:51 --> Model Class Initialized
DEBUG - 2011-07-17 20:57:51 --> Model Class Initialized
DEBUG - 2011-07-17 20:57:51 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-17 20:57:51 --> Database Driver Class Initialized
DEBUG - 2011-07-17 20:57:52 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-17 20:57:52 --> Helper loaded: url_helper
DEBUG - 2011-07-17 20:57:52 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-17 20:57:52 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-17 20:57:52 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-17 20:57:52 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-17 20:57:52 --> Final output sent to browser
DEBUG - 2011-07-17 20:57:52 --> Total execution time: 0.6425
DEBUG - 2011-07-17 20:57:53 --> Config Class Initialized
DEBUG - 2011-07-17 20:57:53 --> Hooks Class Initialized
DEBUG - 2011-07-17 20:57:53 --> Utf8 Class Initialized
DEBUG - 2011-07-17 20:57:53 --> UTF-8 Support Enabled
DEBUG - 2011-07-17 20:57:53 --> URI Class Initialized
DEBUG - 2011-07-17 20:57:53 --> Router Class Initialized
DEBUG - 2011-07-17 20:57:53 --> Output Class Initialized
DEBUG - 2011-07-17 20:57:53 --> Input Class Initialized
DEBUG - 2011-07-17 20:57:53 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-17 20:57:53 --> Language Class Initialized
DEBUG - 2011-07-17 20:57:53 --> Loader Class Initialized
DEBUG - 2011-07-17 20:57:53 --> Controller Class Initialized
ERROR - 2011-07-17 20:57:54 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-17 20:57:54 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-17 20:57:54 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-17 20:57:54 --> Model Class Initialized
DEBUG - 2011-07-17 20:57:54 --> Model Class Initialized
DEBUG - 2011-07-17 20:57:54 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-17 20:57:54 --> Database Driver Class Initialized
DEBUG - 2011-07-17 20:57:54 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-17 20:57:54 --> Helper loaded: url_helper
DEBUG - 2011-07-17 20:57:54 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-17 20:57:54 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-17 20:57:54 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-17 20:57:54 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-17 20:57:54 --> Final output sent to browser
DEBUG - 2011-07-17 20:57:54 --> Total execution time: 0.2168
DEBUG - 2011-07-17 20:57:55 --> Config Class Initialized
DEBUG - 2011-07-17 20:57:55 --> Hooks Class Initialized
DEBUG - 2011-07-17 20:57:55 --> Utf8 Class Initialized
DEBUG - 2011-07-17 20:57:55 --> UTF-8 Support Enabled
DEBUG - 2011-07-17 20:57:55 --> URI Class Initialized
DEBUG - 2011-07-17 20:57:55 --> Router Class Initialized
DEBUG - 2011-07-17 20:57:55 --> Output Class Initialized
DEBUG - 2011-07-17 20:57:55 --> Input Class Initialized
DEBUG - 2011-07-17 20:57:55 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-17 20:57:55 --> Language Class Initialized
DEBUG - 2011-07-17 20:57:55 --> Loader Class Initialized
DEBUG - 2011-07-17 20:57:55 --> Controller Class Initialized
DEBUG - 2011-07-17 20:57:55 --> Model Class Initialized
DEBUG - 2011-07-17 20:57:55 --> Model Class Initialized
DEBUG - 2011-07-17 20:57:55 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-17 20:57:55 --> Database Driver Class Initialized
DEBUG - 2011-07-17 20:57:55 --> Final output sent to browser
DEBUG - 2011-07-17 20:57:55 --> Total execution time: 0.8009
DEBUG - 2011-07-17 20:57:57 --> Config Class Initialized
DEBUG - 2011-07-17 20:57:57 --> Hooks Class Initialized
DEBUG - 2011-07-17 20:57:57 --> Utf8 Class Initialized
DEBUG - 2011-07-17 20:57:57 --> UTF-8 Support Enabled
DEBUG - 2011-07-17 20:57:57 --> URI Class Initialized
DEBUG - 2011-07-17 20:57:57 --> Router Class Initialized
ERROR - 2011-07-17 20:57:57 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-17 20:59:18 --> Config Class Initialized
DEBUG - 2011-07-17 20:59:18 --> Hooks Class Initialized
DEBUG - 2011-07-17 20:59:18 --> Utf8 Class Initialized
DEBUG - 2011-07-17 20:59:18 --> UTF-8 Support Enabled
DEBUG - 2011-07-17 20:59:18 --> URI Class Initialized
DEBUG - 2011-07-17 20:59:18 --> Router Class Initialized
DEBUG - 2011-07-17 20:59:18 --> Output Class Initialized
DEBUG - 2011-07-17 20:59:18 --> Input Class Initialized
DEBUG - 2011-07-17 20:59:18 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-17 20:59:18 --> Language Class Initialized
DEBUG - 2011-07-17 20:59:18 --> Loader Class Initialized
DEBUG - 2011-07-17 20:59:18 --> Controller Class Initialized
DEBUG - 2011-07-17 20:59:18 --> Model Class Initialized
DEBUG - 2011-07-17 20:59:18 --> Model Class Initialized
DEBUG - 2011-07-17 20:59:18 --> Model Class Initialized
DEBUG - 2011-07-17 20:59:18 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-17 20:59:18 --> Database Driver Class Initialized
DEBUG - 2011-07-17 20:59:18 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-17 20:59:18 --> Helper loaded: url_helper
DEBUG - 2011-07-17 20:59:18 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-17 20:59:18 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-17 20:59:18 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-17 20:59:18 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-17 20:59:18 --> Final output sent to browser
DEBUG - 2011-07-17 20:59:18 --> Total execution time: 0.0442
DEBUG - 2011-07-17 20:59:20 --> Config Class Initialized
DEBUG - 2011-07-17 20:59:20 --> Hooks Class Initialized
DEBUG - 2011-07-17 20:59:20 --> Utf8 Class Initialized
DEBUG - 2011-07-17 20:59:20 --> UTF-8 Support Enabled
DEBUG - 2011-07-17 20:59:20 --> URI Class Initialized
DEBUG - 2011-07-17 20:59:20 --> Router Class Initialized
ERROR - 2011-07-17 20:59:20 --> 404 Page Not Found --> favicon.ico

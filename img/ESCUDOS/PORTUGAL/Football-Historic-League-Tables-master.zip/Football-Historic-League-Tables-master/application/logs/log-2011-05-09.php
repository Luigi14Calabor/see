<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2011-05-09 00:27:11 --> Config Class Initialized
DEBUG - 2011-05-09 00:27:11 --> Hooks Class Initialized
DEBUG - 2011-05-09 00:27:11 --> Utf8 Class Initialized
DEBUG - 2011-05-09 00:27:11 --> UTF-8 Support Enabled
DEBUG - 2011-05-09 00:27:11 --> URI Class Initialized
DEBUG - 2011-05-09 00:27:11 --> Router Class Initialized
DEBUG - 2011-05-09 00:27:11 --> Output Class Initialized
DEBUG - 2011-05-09 00:27:11 --> Input Class Initialized
DEBUG - 2011-05-09 00:27:11 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-09 00:27:11 --> Language Class Initialized
DEBUG - 2011-05-09 00:27:11 --> Loader Class Initialized
DEBUG - 2011-05-09 00:27:11 --> Controller Class Initialized
DEBUG - 2011-05-09 00:27:11 --> Model Class Initialized
DEBUG - 2011-05-09 00:27:11 --> Model Class Initialized
DEBUG - 2011-05-09 00:27:11 --> Model Class Initialized
DEBUG - 2011-05-09 00:27:11 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-09 00:27:11 --> Database Driver Class Initialized
DEBUG - 2011-05-09 00:27:12 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-09 00:27:12 --> Helper loaded: url_helper
DEBUG - 2011-05-09 00:27:12 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-09 00:27:12 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-09 00:27:12 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-09 00:27:12 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-09 00:27:12 --> Final output sent to browser
DEBUG - 2011-05-09 00:27:12 --> Total execution time: 0.6007
DEBUG - 2011-05-09 00:27:13 --> Config Class Initialized
DEBUG - 2011-05-09 00:27:13 --> Hooks Class Initialized
DEBUG - 2011-05-09 00:27:13 --> Utf8 Class Initialized
DEBUG - 2011-05-09 00:27:13 --> UTF-8 Support Enabled
DEBUG - 2011-05-09 00:27:13 --> URI Class Initialized
DEBUG - 2011-05-09 00:27:13 --> Router Class Initialized
DEBUG - 2011-05-09 00:27:13 --> Output Class Initialized
DEBUG - 2011-05-09 00:27:13 --> Input Class Initialized
DEBUG - 2011-05-09 00:27:13 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-09 00:27:13 --> Language Class Initialized
DEBUG - 2011-05-09 00:27:13 --> Loader Class Initialized
DEBUG - 2011-05-09 00:27:13 --> Controller Class Initialized
ERROR - 2011-05-09 00:27:13 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-09 00:27:13 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-09 00:27:13 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-09 00:27:13 --> Model Class Initialized
DEBUG - 2011-05-09 00:27:13 --> Model Class Initialized
DEBUG - 2011-05-09 00:27:13 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-09 00:27:13 --> Database Driver Class Initialized
DEBUG - 2011-05-09 00:27:13 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-09 00:27:13 --> Helper loaded: url_helper
DEBUG - 2011-05-09 00:27:13 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-09 00:27:13 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-09 00:27:13 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-09 00:27:13 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-09 00:27:13 --> Final output sent to browser
DEBUG - 2011-05-09 00:27:13 --> Total execution time: 0.0863
DEBUG - 2011-05-09 01:59:35 --> Config Class Initialized
DEBUG - 2011-05-09 01:59:35 --> Hooks Class Initialized
DEBUG - 2011-05-09 01:59:35 --> Utf8 Class Initialized
DEBUG - 2011-05-09 01:59:35 --> UTF-8 Support Enabled
DEBUG - 2011-05-09 01:59:35 --> URI Class Initialized
DEBUG - 2011-05-09 01:59:35 --> Router Class Initialized
DEBUG - 2011-05-09 01:59:35 --> Output Class Initialized
DEBUG - 2011-05-09 01:59:35 --> Input Class Initialized
DEBUG - 2011-05-09 01:59:35 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-09 01:59:35 --> Language Class Initialized
DEBUG - 2011-05-09 01:59:35 --> Loader Class Initialized
DEBUG - 2011-05-09 01:59:35 --> Controller Class Initialized
DEBUG - 2011-05-09 01:59:35 --> Model Class Initialized
DEBUG - 2011-05-09 01:59:35 --> Model Class Initialized
DEBUG - 2011-05-09 01:59:35 --> Model Class Initialized
DEBUG - 2011-05-09 01:59:35 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-09 01:59:35 --> Database Driver Class Initialized
DEBUG - 2011-05-09 01:59:43 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-09 01:59:43 --> Helper loaded: url_helper
DEBUG - 2011-05-09 01:59:43 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-09 01:59:43 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-09 01:59:43 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-09 01:59:43 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-09 01:59:43 --> Final output sent to browser
DEBUG - 2011-05-09 01:59:43 --> Total execution time: 7.9410
DEBUG - 2011-05-09 01:59:48 --> Config Class Initialized
DEBUG - 2011-05-09 01:59:48 --> Hooks Class Initialized
DEBUG - 2011-05-09 01:59:48 --> Utf8 Class Initialized
DEBUG - 2011-05-09 01:59:48 --> UTF-8 Support Enabled
DEBUG - 2011-05-09 01:59:48 --> URI Class Initialized
DEBUG - 2011-05-09 01:59:48 --> Router Class Initialized
DEBUG - 2011-05-09 01:59:48 --> Output Class Initialized
DEBUG - 2011-05-09 01:59:48 --> Input Class Initialized
DEBUG - 2011-05-09 01:59:48 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-09 01:59:48 --> Language Class Initialized
DEBUG - 2011-05-09 01:59:48 --> Loader Class Initialized
DEBUG - 2011-05-09 01:59:48 --> Controller Class Initialized
ERROR - 2011-05-09 01:59:48 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-09 01:59:48 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-09 01:59:48 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-09 01:59:48 --> Model Class Initialized
DEBUG - 2011-05-09 01:59:48 --> Model Class Initialized
DEBUG - 2011-05-09 01:59:48 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-09 01:59:48 --> Database Driver Class Initialized
DEBUG - 2011-05-09 01:59:48 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-09 01:59:48 --> Helper loaded: url_helper
DEBUG - 2011-05-09 01:59:48 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-09 01:59:48 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-09 01:59:48 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-09 01:59:48 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-09 01:59:48 --> Final output sent to browser
DEBUG - 2011-05-09 01:59:48 --> Total execution time: 0.1382
DEBUG - 2011-05-09 04:22:10 --> Config Class Initialized
DEBUG - 2011-05-09 04:22:10 --> Hooks Class Initialized
DEBUG - 2011-05-09 04:22:10 --> Utf8 Class Initialized
DEBUG - 2011-05-09 04:22:10 --> UTF-8 Support Enabled
DEBUG - 2011-05-09 04:22:10 --> URI Class Initialized
DEBUG - 2011-05-09 04:22:10 --> Router Class Initialized
DEBUG - 2011-05-09 04:22:10 --> Output Class Initialized
DEBUG - 2011-05-09 04:22:10 --> Input Class Initialized
DEBUG - 2011-05-09 04:22:10 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-09 04:22:10 --> Language Class Initialized
DEBUG - 2011-05-09 04:22:10 --> Loader Class Initialized
DEBUG - 2011-05-09 04:22:10 --> Controller Class Initialized
DEBUG - 2011-05-09 04:22:10 --> Model Class Initialized
DEBUG - 2011-05-09 04:22:10 --> Model Class Initialized
DEBUG - 2011-05-09 04:22:10 --> Model Class Initialized
DEBUG - 2011-05-09 04:22:10 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-09 04:22:10 --> Database Driver Class Initialized
DEBUG - 2011-05-09 04:22:12 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-09 04:22:13 --> Helper loaded: url_helper
DEBUG - 2011-05-09 04:22:13 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-09 04:22:13 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-09 04:22:13 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-09 04:22:13 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-09 04:22:13 --> Final output sent to browser
DEBUG - 2011-05-09 04:22:13 --> Total execution time: 2.4964
DEBUG - 2011-05-09 07:51:44 --> Config Class Initialized
DEBUG - 2011-05-09 07:51:44 --> Hooks Class Initialized
DEBUG - 2011-05-09 07:51:44 --> Utf8 Class Initialized
DEBUG - 2011-05-09 07:51:44 --> UTF-8 Support Enabled
DEBUG - 2011-05-09 07:51:44 --> URI Class Initialized
DEBUG - 2011-05-09 07:51:44 --> Router Class Initialized
DEBUG - 2011-05-09 07:51:44 --> Output Class Initialized
DEBUG - 2011-05-09 07:51:44 --> Input Class Initialized
DEBUG - 2011-05-09 07:51:44 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-09 07:51:44 --> Language Class Initialized
DEBUG - 2011-05-09 07:51:44 --> Loader Class Initialized
DEBUG - 2011-05-09 07:51:44 --> Controller Class Initialized
DEBUG - 2011-05-09 07:51:44 --> Model Class Initialized
DEBUG - 2011-05-09 07:51:44 --> Model Class Initialized
DEBUG - 2011-05-09 07:51:44 --> Model Class Initialized
DEBUG - 2011-05-09 07:51:44 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-09 07:51:44 --> Database Driver Class Initialized
DEBUG - 2011-05-09 07:51:49 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-09 07:51:50 --> Helper loaded: url_helper
DEBUG - 2011-05-09 07:51:50 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-09 07:51:50 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-09 07:51:50 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-09 07:51:50 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-09 07:51:50 --> Final output sent to browser
DEBUG - 2011-05-09 07:51:50 --> Total execution time: 6.1080
DEBUG - 2011-05-09 08:20:16 --> Config Class Initialized
DEBUG - 2011-05-09 08:20:16 --> Hooks Class Initialized
DEBUG - 2011-05-09 08:20:16 --> Utf8 Class Initialized
DEBUG - 2011-05-09 08:20:16 --> UTF-8 Support Enabled
DEBUG - 2011-05-09 08:20:16 --> URI Class Initialized
DEBUG - 2011-05-09 08:20:16 --> Router Class Initialized
DEBUG - 2011-05-09 08:20:16 --> Output Class Initialized
DEBUG - 2011-05-09 08:20:16 --> Input Class Initialized
DEBUG - 2011-05-09 08:20:16 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-09 08:20:16 --> Language Class Initialized
DEBUG - 2011-05-09 08:20:17 --> Loader Class Initialized
DEBUG - 2011-05-09 08:20:17 --> Controller Class Initialized
ERROR - 2011-05-09 08:20:17 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-09 08:20:17 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-09 08:20:17 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-09 08:20:17 --> Model Class Initialized
DEBUG - 2011-05-09 08:20:17 --> Model Class Initialized
DEBUG - 2011-05-09 08:20:17 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-09 08:20:19 --> Database Driver Class Initialized
DEBUG - 2011-05-09 08:20:19 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-09 08:20:20 --> Helper loaded: url_helper
DEBUG - 2011-05-09 08:20:20 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-09 08:20:21 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-09 08:20:21 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-09 08:20:21 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-09 08:20:21 --> Final output sent to browser
DEBUG - 2011-05-09 08:20:21 --> Total execution time: 6.3331
DEBUG - 2011-05-09 08:20:22 --> Config Class Initialized
DEBUG - 2011-05-09 08:20:22 --> Hooks Class Initialized
DEBUG - 2011-05-09 08:20:22 --> Utf8 Class Initialized
DEBUG - 2011-05-09 08:20:22 --> UTF-8 Support Enabled
DEBUG - 2011-05-09 08:20:22 --> URI Class Initialized
DEBUG - 2011-05-09 08:20:22 --> Router Class Initialized
DEBUG - 2011-05-09 08:20:22 --> Output Class Initialized
DEBUG - 2011-05-09 08:20:22 --> Input Class Initialized
DEBUG - 2011-05-09 08:20:22 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-09 08:20:22 --> Language Class Initialized
DEBUG - 2011-05-09 08:20:22 --> Loader Class Initialized
DEBUG - 2011-05-09 08:20:22 --> Controller Class Initialized
DEBUG - 2011-05-09 08:20:22 --> Model Class Initialized
DEBUG - 2011-05-09 08:20:23 --> Model Class Initialized
DEBUG - 2011-05-09 08:20:23 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-09 08:20:23 --> Database Driver Class Initialized
DEBUG - 2011-05-09 08:20:25 --> Final output sent to browser
DEBUG - 2011-05-09 08:20:25 --> Total execution time: 2.3131
DEBUG - 2011-05-09 08:20:26 --> Config Class Initialized
DEBUG - 2011-05-09 08:20:26 --> Hooks Class Initialized
DEBUG - 2011-05-09 08:20:26 --> Utf8 Class Initialized
DEBUG - 2011-05-09 08:20:26 --> UTF-8 Support Enabled
DEBUG - 2011-05-09 08:20:26 --> URI Class Initialized
DEBUG - 2011-05-09 08:20:26 --> Router Class Initialized
ERROR - 2011-05-09 08:20:26 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-09 08:22:40 --> Config Class Initialized
DEBUG - 2011-05-09 08:22:40 --> Hooks Class Initialized
DEBUG - 2011-05-09 08:22:40 --> Utf8 Class Initialized
DEBUG - 2011-05-09 08:22:40 --> UTF-8 Support Enabled
DEBUG - 2011-05-09 08:22:40 --> URI Class Initialized
DEBUG - 2011-05-09 08:22:40 --> Router Class Initialized
DEBUG - 2011-05-09 08:22:40 --> Output Class Initialized
DEBUG - 2011-05-09 08:22:40 --> Input Class Initialized
DEBUG - 2011-05-09 08:22:40 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-09 08:22:40 --> Language Class Initialized
DEBUG - 2011-05-09 08:22:41 --> Loader Class Initialized
DEBUG - 2011-05-09 08:22:41 --> Controller Class Initialized
DEBUG - 2011-05-09 08:22:41 --> Model Class Initialized
DEBUG - 2011-05-09 08:22:41 --> Model Class Initialized
DEBUG - 2011-05-09 08:22:41 --> Model Class Initialized
DEBUG - 2011-05-09 08:22:41 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-09 08:22:41 --> Database Driver Class Initialized
DEBUG - 2011-05-09 08:22:43 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-09 08:22:43 --> Helper loaded: url_helper
DEBUG - 2011-05-09 08:22:43 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-09 08:22:43 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-09 08:22:43 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-09 08:22:43 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-09 08:22:43 --> Final output sent to browser
DEBUG - 2011-05-09 08:22:43 --> Total execution time: 2.6683
DEBUG - 2011-05-09 08:22:55 --> Config Class Initialized
DEBUG - 2011-05-09 08:22:55 --> Hooks Class Initialized
DEBUG - 2011-05-09 08:22:55 --> Utf8 Class Initialized
DEBUG - 2011-05-09 08:22:55 --> UTF-8 Support Enabled
DEBUG - 2011-05-09 08:22:55 --> URI Class Initialized
DEBUG - 2011-05-09 08:22:55 --> Router Class Initialized
ERROR - 2011-05-09 08:22:55 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-05-09 08:22:55 --> Config Class Initialized
DEBUG - 2011-05-09 08:22:55 --> Hooks Class Initialized
DEBUG - 2011-05-09 08:22:55 --> Utf8 Class Initialized
DEBUG - 2011-05-09 08:22:55 --> UTF-8 Support Enabled
DEBUG - 2011-05-09 08:22:55 --> URI Class Initialized
DEBUG - 2011-05-09 08:22:55 --> Router Class Initialized
DEBUG - 2011-05-09 08:22:55 --> Output Class Initialized
DEBUG - 2011-05-09 08:22:55 --> Input Class Initialized
DEBUG - 2011-05-09 08:22:55 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-09 08:22:55 --> Language Class Initialized
DEBUG - 2011-05-09 08:22:55 --> Loader Class Initialized
DEBUG - 2011-05-09 08:22:55 --> Controller Class Initialized
DEBUG - 2011-05-09 08:22:55 --> Model Class Initialized
DEBUG - 2011-05-09 08:22:55 --> Model Class Initialized
DEBUG - 2011-05-09 08:22:55 --> Model Class Initialized
DEBUG - 2011-05-09 08:22:55 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-09 08:22:55 --> Database Driver Class Initialized
DEBUG - 2011-05-09 08:22:55 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-09 08:22:55 --> Helper loaded: url_helper
DEBUG - 2011-05-09 08:22:55 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-09 08:22:55 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-09 08:22:55 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-09 08:22:55 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-09 08:22:55 --> Final output sent to browser
DEBUG - 2011-05-09 08:22:55 --> Total execution time: 0.0866
DEBUG - 2011-05-09 08:23:19 --> Config Class Initialized
DEBUG - 2011-05-09 08:23:19 --> Hooks Class Initialized
DEBUG - 2011-05-09 08:23:19 --> Utf8 Class Initialized
DEBUG - 2011-05-09 08:23:19 --> UTF-8 Support Enabled
DEBUG - 2011-05-09 08:23:19 --> URI Class Initialized
DEBUG - 2011-05-09 08:23:19 --> Router Class Initialized
DEBUG - 2011-05-09 08:23:19 --> Output Class Initialized
DEBUG - 2011-05-09 08:23:19 --> Input Class Initialized
DEBUG - 2011-05-09 08:23:19 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-09 08:23:19 --> Language Class Initialized
DEBUG - 2011-05-09 08:23:19 --> Loader Class Initialized
DEBUG - 2011-05-09 08:23:19 --> Controller Class Initialized
ERROR - 2011-05-09 08:23:19 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-09 08:23:19 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-09 08:23:19 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-09 08:23:19 --> Model Class Initialized
DEBUG - 2011-05-09 08:23:19 --> Model Class Initialized
DEBUG - 2011-05-09 08:23:19 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-09 08:23:19 --> Database Driver Class Initialized
DEBUG - 2011-05-09 08:23:19 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-09 08:23:19 --> Helper loaded: url_helper
DEBUG - 2011-05-09 08:23:19 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-09 08:23:19 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-09 08:23:19 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-09 08:23:19 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-09 08:23:19 --> Final output sent to browser
DEBUG - 2011-05-09 08:23:19 --> Total execution time: 0.0569
DEBUG - 2011-05-09 08:37:42 --> Config Class Initialized
DEBUG - 2011-05-09 08:37:42 --> Hooks Class Initialized
DEBUG - 2011-05-09 08:37:42 --> Utf8 Class Initialized
DEBUG - 2011-05-09 08:37:42 --> UTF-8 Support Enabled
DEBUG - 2011-05-09 08:37:42 --> URI Class Initialized
DEBUG - 2011-05-09 08:37:42 --> Router Class Initialized
DEBUG - 2011-05-09 08:37:42 --> Output Class Initialized
DEBUG - 2011-05-09 08:37:42 --> Input Class Initialized
DEBUG - 2011-05-09 08:37:42 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-09 08:37:42 --> Language Class Initialized
DEBUG - 2011-05-09 08:37:42 --> Loader Class Initialized
DEBUG - 2011-05-09 08:37:42 --> Controller Class Initialized
DEBUG - 2011-05-09 08:37:42 --> Model Class Initialized
DEBUG - 2011-05-09 08:37:42 --> Model Class Initialized
DEBUG - 2011-05-09 08:37:42 --> Model Class Initialized
DEBUG - 2011-05-09 08:37:42 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-09 08:37:42 --> Database Driver Class Initialized
DEBUG - 2011-05-09 08:37:42 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-09 08:37:43 --> Helper loaded: url_helper
DEBUG - 2011-05-09 08:37:43 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-09 08:37:43 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-09 08:37:43 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-09 08:37:43 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-09 08:37:43 --> Final output sent to browser
DEBUG - 2011-05-09 08:37:43 --> Total execution time: 0.4957
DEBUG - 2011-05-09 08:37:49 --> Config Class Initialized
DEBUG - 2011-05-09 08:37:49 --> Hooks Class Initialized
DEBUG - 2011-05-09 08:37:49 --> Utf8 Class Initialized
DEBUG - 2011-05-09 08:37:49 --> UTF-8 Support Enabled
DEBUG - 2011-05-09 08:37:49 --> URI Class Initialized
DEBUG - 2011-05-09 08:37:49 --> Router Class Initialized
ERROR - 2011-05-09 08:37:49 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-09 08:37:50 --> Config Class Initialized
DEBUG - 2011-05-09 08:37:50 --> Hooks Class Initialized
DEBUG - 2011-05-09 08:37:50 --> Utf8 Class Initialized
DEBUG - 2011-05-09 08:37:50 --> UTF-8 Support Enabled
DEBUG - 2011-05-09 08:37:50 --> URI Class Initialized
DEBUG - 2011-05-09 08:37:50 --> Router Class Initialized
ERROR - 2011-05-09 08:37:50 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-09 08:37:51 --> Config Class Initialized
DEBUG - 2011-05-09 08:37:51 --> Hooks Class Initialized
DEBUG - 2011-05-09 08:37:51 --> Utf8 Class Initialized
DEBUG - 2011-05-09 08:37:51 --> UTF-8 Support Enabled
DEBUG - 2011-05-09 08:37:51 --> URI Class Initialized
DEBUG - 2011-05-09 08:37:51 --> Router Class Initialized
ERROR - 2011-05-09 08:37:51 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-09 08:38:20 --> Config Class Initialized
DEBUG - 2011-05-09 08:38:20 --> Hooks Class Initialized
DEBUG - 2011-05-09 08:38:20 --> Utf8 Class Initialized
DEBUG - 2011-05-09 08:38:20 --> UTF-8 Support Enabled
DEBUG - 2011-05-09 08:38:20 --> URI Class Initialized
DEBUG - 2011-05-09 08:38:20 --> Router Class Initialized
DEBUG - 2011-05-09 08:38:20 --> Output Class Initialized
DEBUG - 2011-05-09 08:38:20 --> Input Class Initialized
DEBUG - 2011-05-09 08:38:20 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-09 08:38:20 --> Language Class Initialized
DEBUG - 2011-05-09 08:38:20 --> Loader Class Initialized
DEBUG - 2011-05-09 08:38:20 --> Controller Class Initialized
DEBUG - 2011-05-09 08:38:20 --> Model Class Initialized
DEBUG - 2011-05-09 08:38:20 --> Model Class Initialized
DEBUG - 2011-05-09 08:38:20 --> Model Class Initialized
DEBUG - 2011-05-09 08:38:20 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-09 08:38:20 --> Database Driver Class Initialized
DEBUG - 2011-05-09 08:38:20 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-09 08:38:20 --> Helper loaded: url_helper
DEBUG - 2011-05-09 08:38:20 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-09 08:38:20 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-09 08:38:20 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-09 08:38:20 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-09 08:38:20 --> Final output sent to browser
DEBUG - 2011-05-09 08:38:20 --> Total execution time: 0.2702
DEBUG - 2011-05-09 08:38:25 --> Config Class Initialized
DEBUG - 2011-05-09 08:38:25 --> Hooks Class Initialized
DEBUG - 2011-05-09 08:38:25 --> Utf8 Class Initialized
DEBUG - 2011-05-09 08:38:25 --> UTF-8 Support Enabled
DEBUG - 2011-05-09 08:38:25 --> URI Class Initialized
DEBUG - 2011-05-09 08:38:25 --> Router Class Initialized
ERROR - 2011-05-09 08:38:25 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-05-09 08:38:25 --> Config Class Initialized
DEBUG - 2011-05-09 08:38:25 --> Hooks Class Initialized
DEBUG - 2011-05-09 08:38:25 --> Utf8 Class Initialized
DEBUG - 2011-05-09 08:38:25 --> UTF-8 Support Enabled
DEBUG - 2011-05-09 08:38:25 --> URI Class Initialized
DEBUG - 2011-05-09 08:38:25 --> Router Class Initialized
DEBUG - 2011-05-09 08:38:25 --> Output Class Initialized
DEBUG - 2011-05-09 08:38:25 --> Input Class Initialized
DEBUG - 2011-05-09 08:38:25 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-09 08:38:25 --> Language Class Initialized
DEBUG - 2011-05-09 08:38:25 --> Loader Class Initialized
DEBUG - 2011-05-09 08:38:25 --> Controller Class Initialized
DEBUG - 2011-05-09 08:38:25 --> Model Class Initialized
DEBUG - 2011-05-09 08:38:25 --> Model Class Initialized
DEBUG - 2011-05-09 08:38:25 --> Model Class Initialized
DEBUG - 2011-05-09 08:38:25 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-09 08:38:25 --> Database Driver Class Initialized
DEBUG - 2011-05-09 08:38:25 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-09 08:38:25 --> Helper loaded: url_helper
DEBUG - 2011-05-09 08:38:25 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-09 08:38:25 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-09 08:38:25 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-09 08:38:25 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-09 08:38:25 --> Final output sent to browser
DEBUG - 2011-05-09 08:38:25 --> Total execution time: 0.0548
DEBUG - 2011-05-09 10:08:57 --> Config Class Initialized
DEBUG - 2011-05-09 10:08:57 --> Hooks Class Initialized
DEBUG - 2011-05-09 10:08:57 --> Utf8 Class Initialized
DEBUG - 2011-05-09 10:08:57 --> UTF-8 Support Enabled
DEBUG - 2011-05-09 10:08:57 --> URI Class Initialized
DEBUG - 2011-05-09 10:08:57 --> Router Class Initialized
DEBUG - 2011-05-09 10:08:57 --> Output Class Initialized
DEBUG - 2011-05-09 10:08:57 --> Input Class Initialized
DEBUG - 2011-05-09 10:08:57 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-09 10:08:58 --> Language Class Initialized
DEBUG - 2011-05-09 10:08:58 --> Loader Class Initialized
DEBUG - 2011-05-09 10:08:58 --> Controller Class Initialized
ERROR - 2011-05-09 10:08:58 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-09 10:08:58 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-09 10:08:58 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-09 10:08:58 --> Model Class Initialized
DEBUG - 2011-05-09 10:08:58 --> Model Class Initialized
DEBUG - 2011-05-09 10:08:58 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-09 10:08:58 --> Database Driver Class Initialized
DEBUG - 2011-05-09 10:08:58 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-09 10:08:58 --> Helper loaded: url_helper
DEBUG - 2011-05-09 10:08:58 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-09 10:08:58 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-09 10:08:58 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-09 10:08:58 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-09 10:08:58 --> Final output sent to browser
DEBUG - 2011-05-09 10:08:58 --> Total execution time: 0.4374
DEBUG - 2011-05-09 10:08:59 --> Config Class Initialized
DEBUG - 2011-05-09 10:08:59 --> Hooks Class Initialized
DEBUG - 2011-05-09 10:08:59 --> Utf8 Class Initialized
DEBUG - 2011-05-09 10:08:59 --> UTF-8 Support Enabled
DEBUG - 2011-05-09 10:08:59 --> URI Class Initialized
DEBUG - 2011-05-09 10:08:59 --> Router Class Initialized
DEBUG - 2011-05-09 10:08:59 --> Output Class Initialized
DEBUG - 2011-05-09 10:08:59 --> Input Class Initialized
DEBUG - 2011-05-09 10:08:59 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-09 10:08:59 --> Language Class Initialized
DEBUG - 2011-05-09 10:08:59 --> Loader Class Initialized
DEBUG - 2011-05-09 10:08:59 --> Controller Class Initialized
DEBUG - 2011-05-09 10:08:59 --> Model Class Initialized
DEBUG - 2011-05-09 10:08:59 --> Model Class Initialized
DEBUG - 2011-05-09 10:08:59 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-09 10:08:59 --> Database Driver Class Initialized
DEBUG - 2011-05-09 10:09:00 --> Final output sent to browser
DEBUG - 2011-05-09 10:09:00 --> Total execution time: 0.9079
DEBUG - 2011-05-09 10:09:02 --> Config Class Initialized
DEBUG - 2011-05-09 10:09:02 --> Hooks Class Initialized
DEBUG - 2011-05-09 10:09:02 --> Utf8 Class Initialized
DEBUG - 2011-05-09 10:09:02 --> UTF-8 Support Enabled
DEBUG - 2011-05-09 10:09:02 --> URI Class Initialized
DEBUG - 2011-05-09 10:09:02 --> Router Class Initialized
ERROR - 2011-05-09 10:09:02 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-09 10:21:53 --> Config Class Initialized
DEBUG - 2011-05-09 10:21:53 --> Hooks Class Initialized
DEBUG - 2011-05-09 10:21:53 --> Utf8 Class Initialized
DEBUG - 2011-05-09 10:21:53 --> UTF-8 Support Enabled
DEBUG - 2011-05-09 10:21:53 --> URI Class Initialized
DEBUG - 2011-05-09 10:21:53 --> Router Class Initialized
DEBUG - 2011-05-09 10:21:53 --> Output Class Initialized
DEBUG - 2011-05-09 10:21:53 --> Input Class Initialized
DEBUG - 2011-05-09 10:21:53 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-09 10:21:53 --> Language Class Initialized
DEBUG - 2011-05-09 10:21:53 --> Loader Class Initialized
DEBUG - 2011-05-09 10:21:53 --> Controller Class Initialized
ERROR - 2011-05-09 10:21:53 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-09 10:21:53 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-09 10:21:53 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-09 10:21:53 --> Model Class Initialized
DEBUG - 2011-05-09 10:21:53 --> Model Class Initialized
DEBUG - 2011-05-09 10:21:53 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-09 10:21:53 --> Database Driver Class Initialized
DEBUG - 2011-05-09 10:21:53 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-09 10:21:53 --> Helper loaded: url_helper
DEBUG - 2011-05-09 10:21:53 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-09 10:21:53 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-09 10:21:53 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-09 10:21:53 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-09 10:21:53 --> Final output sent to browser
DEBUG - 2011-05-09 10:21:53 --> Total execution time: 0.3801
DEBUG - 2011-05-09 10:21:54 --> Config Class Initialized
DEBUG - 2011-05-09 10:21:54 --> Hooks Class Initialized
DEBUG - 2011-05-09 10:21:54 --> Utf8 Class Initialized
DEBUG - 2011-05-09 10:21:54 --> UTF-8 Support Enabled
DEBUG - 2011-05-09 10:21:54 --> URI Class Initialized
DEBUG - 2011-05-09 10:21:54 --> Router Class Initialized
DEBUG - 2011-05-09 10:21:54 --> Output Class Initialized
DEBUG - 2011-05-09 10:21:54 --> Input Class Initialized
DEBUG - 2011-05-09 10:21:54 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-09 10:21:54 --> Language Class Initialized
DEBUG - 2011-05-09 10:21:54 --> Loader Class Initialized
DEBUG - 2011-05-09 10:21:54 --> Controller Class Initialized
DEBUG - 2011-05-09 10:21:54 --> Model Class Initialized
DEBUG - 2011-05-09 10:21:54 --> Model Class Initialized
DEBUG - 2011-05-09 10:21:54 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-09 10:21:54 --> Database Driver Class Initialized
DEBUG - 2011-05-09 10:21:54 --> Final output sent to browser
DEBUG - 2011-05-09 10:21:54 --> Total execution time: 0.6459
DEBUG - 2011-05-09 10:22:16 --> Config Class Initialized
DEBUG - 2011-05-09 10:22:16 --> Hooks Class Initialized
DEBUG - 2011-05-09 10:22:16 --> Utf8 Class Initialized
DEBUG - 2011-05-09 10:22:16 --> UTF-8 Support Enabled
DEBUG - 2011-05-09 10:22:16 --> URI Class Initialized
DEBUG - 2011-05-09 10:22:16 --> Router Class Initialized
DEBUG - 2011-05-09 10:22:16 --> Output Class Initialized
DEBUG - 2011-05-09 10:22:16 --> Input Class Initialized
DEBUG - 2011-05-09 10:22:16 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-09 10:22:16 --> Language Class Initialized
DEBUG - 2011-05-09 10:22:16 --> Loader Class Initialized
DEBUG - 2011-05-09 10:22:16 --> Controller Class Initialized
DEBUG - 2011-05-09 10:22:16 --> Model Class Initialized
DEBUG - 2011-05-09 10:22:16 --> Model Class Initialized
DEBUG - 2011-05-09 10:22:16 --> Model Class Initialized
DEBUG - 2011-05-09 10:22:16 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-09 10:22:16 --> Database Driver Class Initialized
DEBUG - 2011-05-09 10:22:16 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-09 10:22:16 --> Helper loaded: url_helper
DEBUG - 2011-05-09 10:22:16 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-09 10:22:16 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-09 10:22:16 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-09 10:22:16 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-09 10:22:16 --> Final output sent to browser
DEBUG - 2011-05-09 10:22:16 --> Total execution time: 0.2818
DEBUG - 2011-05-09 13:28:01 --> Config Class Initialized
DEBUG - 2011-05-09 13:28:01 --> Hooks Class Initialized
DEBUG - 2011-05-09 13:28:01 --> Utf8 Class Initialized
DEBUG - 2011-05-09 13:28:01 --> UTF-8 Support Enabled
DEBUG - 2011-05-09 13:28:01 --> URI Class Initialized
DEBUG - 2011-05-09 13:28:01 --> Router Class Initialized
DEBUG - 2011-05-09 13:28:01 --> Output Class Initialized
DEBUG - 2011-05-09 13:28:01 --> Input Class Initialized
DEBUG - 2011-05-09 13:28:01 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-09 13:28:01 --> Language Class Initialized
DEBUG - 2011-05-09 13:28:01 --> Loader Class Initialized
DEBUG - 2011-05-09 13:28:01 --> Controller Class Initialized
DEBUG - 2011-05-09 13:28:01 --> Model Class Initialized
DEBUG - 2011-05-09 13:28:01 --> Model Class Initialized
DEBUG - 2011-05-09 13:28:01 --> Model Class Initialized
DEBUG - 2011-05-09 13:28:01 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-09 13:28:02 --> Database Driver Class Initialized
DEBUG - 2011-05-09 13:28:02 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-09 13:28:02 --> Helper loaded: url_helper
DEBUG - 2011-05-09 13:28:02 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-09 13:28:02 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-09 13:28:02 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-09 13:28:02 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-09 13:28:02 --> Final output sent to browser
DEBUG - 2011-05-09 13:28:02 --> Total execution time: 1.4972
DEBUG - 2011-05-09 13:28:05 --> Config Class Initialized
DEBUG - 2011-05-09 13:28:05 --> Hooks Class Initialized
DEBUG - 2011-05-09 13:28:05 --> Utf8 Class Initialized
DEBUG - 2011-05-09 13:28:05 --> UTF-8 Support Enabled
DEBUG - 2011-05-09 13:28:05 --> URI Class Initialized
DEBUG - 2011-05-09 13:28:05 --> Router Class Initialized
ERROR - 2011-05-09 13:28:05 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-09 13:28:05 --> Config Class Initialized
DEBUG - 2011-05-09 13:28:05 --> Hooks Class Initialized
DEBUG - 2011-05-09 13:28:05 --> Utf8 Class Initialized
DEBUG - 2011-05-09 13:28:05 --> UTF-8 Support Enabled
DEBUG - 2011-05-09 13:28:05 --> URI Class Initialized
DEBUG - 2011-05-09 13:28:05 --> Router Class Initialized
ERROR - 2011-05-09 13:28:05 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-09 13:28:06 --> Config Class Initialized
DEBUG - 2011-05-09 13:28:06 --> Hooks Class Initialized
DEBUG - 2011-05-09 13:28:06 --> Utf8 Class Initialized
DEBUG - 2011-05-09 13:28:06 --> UTF-8 Support Enabled
DEBUG - 2011-05-09 13:28:06 --> URI Class Initialized
DEBUG - 2011-05-09 13:28:06 --> Router Class Initialized
ERROR - 2011-05-09 13:28:06 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-09 14:30:26 --> Config Class Initialized
DEBUG - 2011-05-09 14:30:26 --> Hooks Class Initialized
DEBUG - 2011-05-09 14:30:26 --> Utf8 Class Initialized
DEBUG - 2011-05-09 14:30:26 --> UTF-8 Support Enabled
DEBUG - 2011-05-09 14:30:26 --> URI Class Initialized
DEBUG - 2011-05-09 14:30:26 --> Router Class Initialized
DEBUG - 2011-05-09 14:30:27 --> Output Class Initialized
DEBUG - 2011-05-09 14:30:27 --> Input Class Initialized
DEBUG - 2011-05-09 14:30:27 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-09 14:30:27 --> Language Class Initialized
DEBUG - 2011-05-09 14:30:27 --> Loader Class Initialized
DEBUG - 2011-05-09 14:30:27 --> Controller Class Initialized
ERROR - 2011-05-09 14:30:27 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-09 14:30:27 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-09 14:30:27 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-09 14:30:27 --> Model Class Initialized
DEBUG - 2011-05-09 14:30:27 --> Model Class Initialized
DEBUG - 2011-05-09 14:30:27 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-09 14:30:27 --> Database Driver Class Initialized
DEBUG - 2011-05-09 14:30:27 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-09 14:30:27 --> Helper loaded: url_helper
DEBUG - 2011-05-09 14:30:27 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-09 14:30:27 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-09 14:30:27 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-09 14:30:27 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-09 14:30:27 --> Final output sent to browser
DEBUG - 2011-05-09 14:30:27 --> Total execution time: 2.1317
DEBUG - 2011-05-09 14:30:28 --> Config Class Initialized
DEBUG - 2011-05-09 14:30:28 --> Hooks Class Initialized
DEBUG - 2011-05-09 14:30:28 --> Utf8 Class Initialized
DEBUG - 2011-05-09 14:30:28 --> UTF-8 Support Enabled
DEBUG - 2011-05-09 14:30:28 --> URI Class Initialized
DEBUG - 2011-05-09 14:30:28 --> Router Class Initialized
DEBUG - 2011-05-09 14:30:28 --> Output Class Initialized
DEBUG - 2011-05-09 14:30:28 --> Input Class Initialized
DEBUG - 2011-05-09 14:30:28 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-09 14:30:28 --> Language Class Initialized
DEBUG - 2011-05-09 14:30:28 --> Loader Class Initialized
DEBUG - 2011-05-09 14:30:28 --> Controller Class Initialized
DEBUG - 2011-05-09 14:30:28 --> Model Class Initialized
DEBUG - 2011-05-09 14:30:28 --> Model Class Initialized
DEBUG - 2011-05-09 14:30:28 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-09 14:30:28 --> Database Driver Class Initialized
DEBUG - 2011-05-09 14:30:29 --> Final output sent to browser
DEBUG - 2011-05-09 14:30:29 --> Total execution time: 1.0148
DEBUG - 2011-05-09 14:30:30 --> Config Class Initialized
DEBUG - 2011-05-09 14:30:30 --> Hooks Class Initialized
DEBUG - 2011-05-09 14:30:30 --> Utf8 Class Initialized
DEBUG - 2011-05-09 14:30:30 --> UTF-8 Support Enabled
DEBUG - 2011-05-09 14:30:30 --> URI Class Initialized
DEBUG - 2011-05-09 14:30:30 --> Router Class Initialized
ERROR - 2011-05-09 14:30:30 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-09 14:30:53 --> Config Class Initialized
DEBUG - 2011-05-09 14:30:53 --> Hooks Class Initialized
DEBUG - 2011-05-09 14:30:53 --> Utf8 Class Initialized
DEBUG - 2011-05-09 14:30:53 --> UTF-8 Support Enabled
DEBUG - 2011-05-09 14:30:53 --> URI Class Initialized
DEBUG - 2011-05-09 14:30:53 --> Router Class Initialized
DEBUG - 2011-05-09 14:30:53 --> Output Class Initialized
DEBUG - 2011-05-09 14:30:53 --> Input Class Initialized
DEBUG - 2011-05-09 14:30:53 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-09 14:30:53 --> Language Class Initialized
DEBUG - 2011-05-09 14:30:53 --> Loader Class Initialized
DEBUG - 2011-05-09 14:30:53 --> Controller Class Initialized
ERROR - 2011-05-09 14:30:53 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-09 14:30:53 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-09 14:30:53 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-09 14:30:53 --> Model Class Initialized
DEBUG - 2011-05-09 14:30:53 --> Model Class Initialized
DEBUG - 2011-05-09 14:30:53 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-09 14:30:53 --> Database Driver Class Initialized
DEBUG - 2011-05-09 14:30:53 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-09 14:30:53 --> Helper loaded: url_helper
DEBUG - 2011-05-09 14:30:53 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-09 14:30:53 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-09 14:30:53 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-09 14:30:53 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-09 14:30:53 --> Final output sent to browser
DEBUG - 2011-05-09 14:30:53 --> Total execution time: 0.0844
DEBUG - 2011-05-09 14:30:53 --> Config Class Initialized
DEBUG - 2011-05-09 14:30:53 --> Hooks Class Initialized
DEBUG - 2011-05-09 14:30:53 --> Utf8 Class Initialized
DEBUG - 2011-05-09 14:30:53 --> UTF-8 Support Enabled
DEBUG - 2011-05-09 14:30:53 --> URI Class Initialized
DEBUG - 2011-05-09 14:30:53 --> Router Class Initialized
DEBUG - 2011-05-09 14:30:53 --> Output Class Initialized
DEBUG - 2011-05-09 14:30:53 --> Input Class Initialized
DEBUG - 2011-05-09 14:30:53 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-09 14:30:53 --> Language Class Initialized
DEBUG - 2011-05-09 14:30:53 --> Loader Class Initialized
DEBUG - 2011-05-09 14:30:53 --> Controller Class Initialized
DEBUG - 2011-05-09 14:30:53 --> Model Class Initialized
DEBUG - 2011-05-09 14:30:53 --> Model Class Initialized
DEBUG - 2011-05-09 14:30:53 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-09 14:30:53 --> Database Driver Class Initialized
DEBUG - 2011-05-09 14:30:54 --> Final output sent to browser
DEBUG - 2011-05-09 14:30:54 --> Total execution time: 0.7681
DEBUG - 2011-05-09 14:30:55 --> Config Class Initialized
DEBUG - 2011-05-09 14:30:55 --> Hooks Class Initialized
DEBUG - 2011-05-09 14:30:55 --> Utf8 Class Initialized
DEBUG - 2011-05-09 14:30:55 --> UTF-8 Support Enabled
DEBUG - 2011-05-09 14:30:55 --> URI Class Initialized
DEBUG - 2011-05-09 14:30:55 --> Router Class Initialized
ERROR - 2011-05-09 14:30:55 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-09 14:31:09 --> Config Class Initialized
DEBUG - 2011-05-09 14:31:09 --> Hooks Class Initialized
DEBUG - 2011-05-09 14:31:09 --> Utf8 Class Initialized
DEBUG - 2011-05-09 14:31:09 --> UTF-8 Support Enabled
DEBUG - 2011-05-09 14:31:09 --> URI Class Initialized
DEBUG - 2011-05-09 14:31:09 --> Router Class Initialized
DEBUG - 2011-05-09 14:31:09 --> Output Class Initialized
DEBUG - 2011-05-09 14:31:09 --> Input Class Initialized
DEBUG - 2011-05-09 14:31:09 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-09 14:31:09 --> Language Class Initialized
DEBUG - 2011-05-09 14:31:09 --> Loader Class Initialized
DEBUG - 2011-05-09 14:31:09 --> Controller Class Initialized
ERROR - 2011-05-09 14:31:09 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-09 14:31:09 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-09 14:31:09 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-09 14:31:09 --> Model Class Initialized
DEBUG - 2011-05-09 14:31:09 --> Model Class Initialized
DEBUG - 2011-05-09 14:31:09 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-09 14:31:09 --> Database Driver Class Initialized
DEBUG - 2011-05-09 14:31:09 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-09 14:31:09 --> Helper loaded: url_helper
DEBUG - 2011-05-09 14:31:09 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-09 14:31:09 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-09 14:31:09 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-09 14:31:09 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-09 14:31:09 --> Final output sent to browser
DEBUG - 2011-05-09 14:31:09 --> Total execution time: 0.0686
DEBUG - 2011-05-09 14:31:10 --> Config Class Initialized
DEBUG - 2011-05-09 14:31:10 --> Hooks Class Initialized
DEBUG - 2011-05-09 14:31:10 --> Utf8 Class Initialized
DEBUG - 2011-05-09 14:31:10 --> UTF-8 Support Enabled
DEBUG - 2011-05-09 14:31:10 --> URI Class Initialized
DEBUG - 2011-05-09 14:31:10 --> Router Class Initialized
DEBUG - 2011-05-09 14:31:10 --> Output Class Initialized
DEBUG - 2011-05-09 14:31:10 --> Input Class Initialized
DEBUG - 2011-05-09 14:31:10 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-09 14:31:10 --> Language Class Initialized
DEBUG - 2011-05-09 14:31:10 --> Loader Class Initialized
DEBUG - 2011-05-09 14:31:10 --> Controller Class Initialized
DEBUG - 2011-05-09 14:31:10 --> Model Class Initialized
DEBUG - 2011-05-09 14:31:10 --> Model Class Initialized
DEBUG - 2011-05-09 14:31:10 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-09 14:31:10 --> Database Driver Class Initialized
DEBUG - 2011-05-09 14:31:11 --> Final output sent to browser
DEBUG - 2011-05-09 14:31:11 --> Total execution time: 0.8391
DEBUG - 2011-05-09 14:31:12 --> Config Class Initialized
DEBUG - 2011-05-09 14:31:12 --> Hooks Class Initialized
DEBUG - 2011-05-09 14:31:12 --> Utf8 Class Initialized
DEBUG - 2011-05-09 14:31:12 --> UTF-8 Support Enabled
DEBUG - 2011-05-09 14:31:12 --> URI Class Initialized
DEBUG - 2011-05-09 14:31:12 --> Router Class Initialized
ERROR - 2011-05-09 14:31:12 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-09 14:31:24 --> Config Class Initialized
DEBUG - 2011-05-09 14:31:24 --> Hooks Class Initialized
DEBUG - 2011-05-09 14:31:24 --> Utf8 Class Initialized
DEBUG - 2011-05-09 14:31:24 --> UTF-8 Support Enabled
DEBUG - 2011-05-09 14:31:24 --> URI Class Initialized
DEBUG - 2011-05-09 14:31:24 --> Router Class Initialized
DEBUG - 2011-05-09 14:31:24 --> Output Class Initialized
DEBUG - 2011-05-09 14:31:24 --> Input Class Initialized
DEBUG - 2011-05-09 14:31:24 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-09 14:31:24 --> Language Class Initialized
DEBUG - 2011-05-09 14:31:24 --> Loader Class Initialized
DEBUG - 2011-05-09 14:31:24 --> Controller Class Initialized
ERROR - 2011-05-09 14:31:24 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-09 14:31:24 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-09 14:31:24 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-09 14:31:24 --> Model Class Initialized
DEBUG - 2011-05-09 14:31:24 --> Model Class Initialized
DEBUG - 2011-05-09 14:31:24 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-09 14:31:24 --> Database Driver Class Initialized
DEBUG - 2011-05-09 14:31:24 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-09 14:31:24 --> Helper loaded: url_helper
DEBUG - 2011-05-09 14:31:24 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-09 14:31:24 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-09 14:31:24 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-09 14:31:24 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-09 14:31:24 --> Final output sent to browser
DEBUG - 2011-05-09 14:31:24 --> Total execution time: 0.1724
DEBUG - 2011-05-09 14:31:24 --> Config Class Initialized
DEBUG - 2011-05-09 14:31:24 --> Hooks Class Initialized
DEBUG - 2011-05-09 14:31:24 --> Utf8 Class Initialized
DEBUG - 2011-05-09 14:31:24 --> UTF-8 Support Enabled
DEBUG - 2011-05-09 14:31:24 --> URI Class Initialized
DEBUG - 2011-05-09 14:31:24 --> Router Class Initialized
DEBUG - 2011-05-09 14:31:24 --> Output Class Initialized
DEBUG - 2011-05-09 14:31:24 --> Input Class Initialized
DEBUG - 2011-05-09 14:31:24 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-09 14:31:24 --> Language Class Initialized
DEBUG - 2011-05-09 14:31:24 --> Loader Class Initialized
DEBUG - 2011-05-09 14:31:24 --> Controller Class Initialized
DEBUG - 2011-05-09 14:31:24 --> Model Class Initialized
DEBUG - 2011-05-09 14:31:24 --> Model Class Initialized
DEBUG - 2011-05-09 14:31:24 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-09 14:31:24 --> Database Driver Class Initialized
DEBUG - 2011-05-09 14:31:25 --> Final output sent to browser
DEBUG - 2011-05-09 14:31:25 --> Total execution time: 1.1086
DEBUG - 2011-05-09 14:31:26 --> Config Class Initialized
DEBUG - 2011-05-09 14:31:26 --> Hooks Class Initialized
DEBUG - 2011-05-09 14:31:26 --> Utf8 Class Initialized
DEBUG - 2011-05-09 14:31:26 --> UTF-8 Support Enabled
DEBUG - 2011-05-09 14:31:26 --> URI Class Initialized
DEBUG - 2011-05-09 14:31:26 --> Router Class Initialized
ERROR - 2011-05-09 14:31:26 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-09 14:31:31 --> Config Class Initialized
DEBUG - 2011-05-09 14:31:31 --> Hooks Class Initialized
DEBUG - 2011-05-09 14:31:31 --> Utf8 Class Initialized
DEBUG - 2011-05-09 14:31:31 --> UTF-8 Support Enabled
DEBUG - 2011-05-09 14:31:31 --> URI Class Initialized
DEBUG - 2011-05-09 14:31:31 --> Router Class Initialized
DEBUG - 2011-05-09 14:31:31 --> Output Class Initialized
DEBUG - 2011-05-09 14:31:31 --> Input Class Initialized
DEBUG - 2011-05-09 14:31:31 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-09 14:31:31 --> Language Class Initialized
DEBUG - 2011-05-09 14:31:31 --> Loader Class Initialized
DEBUG - 2011-05-09 14:31:31 --> Controller Class Initialized
ERROR - 2011-05-09 14:31:31 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-09 14:31:31 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-09 14:31:31 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-09 14:31:31 --> Model Class Initialized
DEBUG - 2011-05-09 14:31:31 --> Model Class Initialized
DEBUG - 2011-05-09 14:31:31 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-09 14:31:31 --> Database Driver Class Initialized
DEBUG - 2011-05-09 14:31:31 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-09 14:31:31 --> Helper loaded: url_helper
DEBUG - 2011-05-09 14:31:31 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-09 14:31:31 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-09 14:31:31 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-09 14:31:31 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-09 14:31:31 --> Final output sent to browser
DEBUG - 2011-05-09 14:31:31 --> Total execution time: 0.0460
DEBUG - 2011-05-09 14:31:31 --> Config Class Initialized
DEBUG - 2011-05-09 14:31:31 --> Hooks Class Initialized
DEBUG - 2011-05-09 14:31:31 --> Utf8 Class Initialized
DEBUG - 2011-05-09 14:31:31 --> UTF-8 Support Enabled
DEBUG - 2011-05-09 14:31:31 --> URI Class Initialized
DEBUG - 2011-05-09 14:31:31 --> Router Class Initialized
DEBUG - 2011-05-09 14:31:31 --> Output Class Initialized
DEBUG - 2011-05-09 14:31:31 --> Input Class Initialized
DEBUG - 2011-05-09 14:31:31 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-09 14:31:32 --> Language Class Initialized
DEBUG - 2011-05-09 14:31:32 --> Loader Class Initialized
DEBUG - 2011-05-09 14:31:32 --> Controller Class Initialized
DEBUG - 2011-05-09 14:31:32 --> Model Class Initialized
DEBUG - 2011-05-09 14:31:32 --> Model Class Initialized
DEBUG - 2011-05-09 14:31:32 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-09 14:31:32 --> Database Driver Class Initialized
DEBUG - 2011-05-09 14:31:32 --> Final output sent to browser
DEBUG - 2011-05-09 14:31:32 --> Total execution time: 0.5967
DEBUG - 2011-05-09 14:31:33 --> Config Class Initialized
DEBUG - 2011-05-09 14:31:33 --> Hooks Class Initialized
DEBUG - 2011-05-09 14:31:33 --> Utf8 Class Initialized
DEBUG - 2011-05-09 14:31:33 --> UTF-8 Support Enabled
DEBUG - 2011-05-09 14:31:33 --> URI Class Initialized
DEBUG - 2011-05-09 14:31:33 --> Router Class Initialized
ERROR - 2011-05-09 14:31:33 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-09 15:53:23 --> Config Class Initialized
DEBUG - 2011-05-09 15:53:23 --> Hooks Class Initialized
DEBUG - 2011-05-09 15:53:23 --> Utf8 Class Initialized
DEBUG - 2011-05-09 15:53:23 --> UTF-8 Support Enabled
DEBUG - 2011-05-09 15:53:24 --> URI Class Initialized
DEBUG - 2011-05-09 15:53:24 --> Router Class Initialized
DEBUG - 2011-05-09 15:53:25 --> Output Class Initialized
DEBUG - 2011-05-09 15:53:25 --> Input Class Initialized
DEBUG - 2011-05-09 15:53:25 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-09 15:53:25 --> Language Class Initialized
DEBUG - 2011-05-09 15:53:25 --> Loader Class Initialized
DEBUG - 2011-05-09 15:53:25 --> Controller Class Initialized
DEBUG - 2011-05-09 15:53:26 --> Model Class Initialized
DEBUG - 2011-05-09 15:53:26 --> Model Class Initialized
DEBUG - 2011-05-09 15:53:26 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-09 15:53:29 --> Database Driver Class Initialized
DEBUG - 2011-05-09 17:05:08 --> Config Class Initialized
DEBUG - 2011-05-09 17:05:08 --> Hooks Class Initialized
DEBUG - 2011-05-09 17:05:08 --> Utf8 Class Initialized
DEBUG - 2011-05-09 17:05:08 --> UTF-8 Support Enabled
DEBUG - 2011-05-09 17:05:08 --> URI Class Initialized
DEBUG - 2011-05-09 17:05:08 --> Router Class Initialized
DEBUG - 2011-05-09 17:05:08 --> Output Class Initialized
DEBUG - 2011-05-09 17:05:08 --> Input Class Initialized
DEBUG - 2011-05-09 17:05:08 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-09 17:05:08 --> Language Class Initialized
DEBUG - 2011-05-09 17:05:08 --> Loader Class Initialized
DEBUG - 2011-05-09 17:05:08 --> Controller Class Initialized
DEBUG - 2011-05-09 17:05:08 --> Model Class Initialized
DEBUG - 2011-05-09 17:05:08 --> Model Class Initialized
DEBUG - 2011-05-09 17:05:08 --> Model Class Initialized
DEBUG - 2011-05-09 17:05:08 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-09 17:05:09 --> Database Driver Class Initialized
DEBUG - 2011-05-09 17:05:09 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-09 17:05:09 --> Helper loaded: url_helper
DEBUG - 2011-05-09 17:05:09 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-09 17:05:09 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-09 17:05:09 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-09 17:05:09 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-09 17:05:09 --> Final output sent to browser
DEBUG - 2011-05-09 17:05:09 --> Total execution time: 2.1372
DEBUG - 2011-05-09 17:05:13 --> Config Class Initialized
DEBUG - 2011-05-09 17:05:13 --> Hooks Class Initialized
DEBUG - 2011-05-09 17:05:13 --> Utf8 Class Initialized
DEBUG - 2011-05-09 17:05:13 --> UTF-8 Support Enabled
DEBUG - 2011-05-09 17:05:13 --> URI Class Initialized
DEBUG - 2011-05-09 17:05:13 --> Router Class Initialized
ERROR - 2011-05-09 17:05:13 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-09 17:05:14 --> Config Class Initialized
DEBUG - 2011-05-09 17:05:14 --> Hooks Class Initialized
DEBUG - 2011-05-09 17:05:14 --> Utf8 Class Initialized
DEBUG - 2011-05-09 17:05:14 --> UTF-8 Support Enabled
DEBUG - 2011-05-09 17:05:14 --> URI Class Initialized
DEBUG - 2011-05-09 17:05:14 --> Router Class Initialized
ERROR - 2011-05-09 17:05:14 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-09 17:05:14 --> Config Class Initialized
DEBUG - 2011-05-09 17:05:14 --> Hooks Class Initialized
DEBUG - 2011-05-09 17:05:14 --> Utf8 Class Initialized
DEBUG - 2011-05-09 17:05:14 --> UTF-8 Support Enabled
DEBUG - 2011-05-09 17:05:14 --> URI Class Initialized
DEBUG - 2011-05-09 17:05:14 --> Router Class Initialized
ERROR - 2011-05-09 17:05:14 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-09 20:29:37 --> Config Class Initialized
DEBUG - 2011-05-09 20:29:37 --> Hooks Class Initialized
DEBUG - 2011-05-09 20:29:37 --> Utf8 Class Initialized
DEBUG - 2011-05-09 20:29:37 --> UTF-8 Support Enabled
DEBUG - 2011-05-09 20:29:37 --> URI Class Initialized
DEBUG - 2011-05-09 20:29:37 --> Router Class Initialized
DEBUG - 2011-05-09 20:29:37 --> No URI present. Default controller set.
DEBUG - 2011-05-09 20:29:37 --> Output Class Initialized
DEBUG - 2011-05-09 20:29:37 --> Input Class Initialized
DEBUG - 2011-05-09 20:29:37 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-09 20:29:37 --> Language Class Initialized
DEBUG - 2011-05-09 20:29:37 --> Loader Class Initialized
DEBUG - 2011-05-09 20:29:37 --> Controller Class Initialized
DEBUG - 2011-05-09 20:29:37 --> File loaded: application/views/splash/main.php
DEBUG - 2011-05-09 20:29:37 --> Helper loaded: url_helper
DEBUG - 2011-05-09 20:29:37 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-09 20:29:37 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-09 20:29:37 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-09 20:29:37 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-09 20:29:37 --> Final output sent to browser
DEBUG - 2011-05-09 20:29:37 --> Total execution time: 0.2495
DEBUG - 2011-05-09 20:34:12 --> Config Class Initialized
DEBUG - 2011-05-09 20:34:12 --> Hooks Class Initialized
DEBUG - 2011-05-09 20:34:12 --> Utf8 Class Initialized
DEBUG - 2011-05-09 20:34:12 --> UTF-8 Support Enabled
DEBUG - 2011-05-09 20:34:12 --> URI Class Initialized
DEBUG - 2011-05-09 20:34:12 --> Router Class Initialized
DEBUG - 2011-05-09 20:34:12 --> Output Class Initialized
DEBUG - 2011-05-09 20:34:12 --> Input Class Initialized
DEBUG - 2011-05-09 20:34:12 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-09 20:34:12 --> Language Class Initialized
DEBUG - 2011-05-09 20:34:12 --> Loader Class Initialized
DEBUG - 2011-05-09 20:34:12 --> Controller Class Initialized
DEBUG - 2011-05-09 20:34:13 --> Model Class Initialized
DEBUG - 2011-05-09 20:34:13 --> Model Class Initialized
DEBUG - 2011-05-09 20:34:13 --> Model Class Initialized
DEBUG - 2011-05-09 20:34:13 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-09 20:34:13 --> Database Driver Class Initialized
DEBUG - 2011-05-09 20:34:13 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-09 20:34:13 --> Helper loaded: url_helper
DEBUG - 2011-05-09 20:34:13 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-09 20:34:13 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-09 20:34:13 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-09 20:34:13 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-09 20:34:13 --> Final output sent to browser
DEBUG - 2011-05-09 20:34:13 --> Total execution time: 1.0687
DEBUG - 2011-05-09 20:35:14 --> Config Class Initialized
DEBUG - 2011-05-09 20:35:14 --> Hooks Class Initialized
DEBUG - 2011-05-09 20:35:14 --> Utf8 Class Initialized
DEBUG - 2011-05-09 20:35:14 --> UTF-8 Support Enabled
DEBUG - 2011-05-09 20:35:14 --> URI Class Initialized
DEBUG - 2011-05-09 20:35:14 --> Router Class Initialized
ERROR - 2011-05-09 20:35:14 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-09 20:35:31 --> Config Class Initialized
DEBUG - 2011-05-09 20:35:31 --> Hooks Class Initialized
DEBUG - 2011-05-09 20:35:31 --> Utf8 Class Initialized
DEBUG - 2011-05-09 20:35:31 --> UTF-8 Support Enabled
DEBUG - 2011-05-09 20:35:31 --> URI Class Initialized
DEBUG - 2011-05-09 20:35:31 --> Router Class Initialized
DEBUG - 2011-05-09 20:35:31 --> Output Class Initialized
DEBUG - 2011-05-09 20:35:31 --> Input Class Initialized
DEBUG - 2011-05-09 20:35:31 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-09 20:35:31 --> Language Class Initialized
DEBUG - 2011-05-09 20:35:31 --> Loader Class Initialized
DEBUG - 2011-05-09 20:35:31 --> Controller Class Initialized
DEBUG - 2011-05-09 20:35:31 --> Model Class Initialized
DEBUG - 2011-05-09 20:35:31 --> Model Class Initialized
DEBUG - 2011-05-09 20:35:31 --> Model Class Initialized
DEBUG - 2011-05-09 20:35:31 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-09 20:35:31 --> Database Driver Class Initialized
DEBUG - 2011-05-09 20:35:31 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-09 20:35:31 --> Helper loaded: url_helper
DEBUG - 2011-05-09 20:35:31 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-09 20:35:31 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-09 20:35:31 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-09 20:35:31 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-09 20:35:31 --> Final output sent to browser
DEBUG - 2011-05-09 20:35:31 --> Total execution time: 0.8191
DEBUG - 2011-05-09 20:35:38 --> Config Class Initialized
DEBUG - 2011-05-09 20:35:38 --> Hooks Class Initialized
DEBUG - 2011-05-09 20:35:38 --> Utf8 Class Initialized
DEBUG - 2011-05-09 20:35:38 --> UTF-8 Support Enabled
DEBUG - 2011-05-09 20:35:38 --> URI Class Initialized
DEBUG - 2011-05-09 20:35:38 --> Router Class Initialized
ERROR - 2011-05-09 20:35:38 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-09 20:36:02 --> Config Class Initialized
DEBUG - 2011-05-09 20:36:02 --> Hooks Class Initialized
DEBUG - 2011-05-09 20:36:02 --> Utf8 Class Initialized
DEBUG - 2011-05-09 20:36:02 --> UTF-8 Support Enabled
DEBUG - 2011-05-09 20:36:02 --> URI Class Initialized
DEBUG - 2011-05-09 20:36:02 --> Router Class Initialized
DEBUG - 2011-05-09 20:36:02 --> Output Class Initialized
DEBUG - 2011-05-09 20:36:02 --> Input Class Initialized
DEBUG - 2011-05-09 20:36:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-09 20:36:02 --> Language Class Initialized
DEBUG - 2011-05-09 20:36:02 --> Loader Class Initialized
DEBUG - 2011-05-09 20:36:02 --> Controller Class Initialized
DEBUG - 2011-05-09 20:36:02 --> Model Class Initialized
DEBUG - 2011-05-09 20:36:02 --> Model Class Initialized
DEBUG - 2011-05-09 20:36:02 --> Model Class Initialized
DEBUG - 2011-05-09 20:36:02 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-09 20:36:02 --> Database Driver Class Initialized
DEBUG - 2011-05-09 20:36:04 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-09 20:36:04 --> Helper loaded: url_helper
DEBUG - 2011-05-09 20:36:04 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-09 20:36:04 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-09 20:36:04 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-09 20:36:04 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-09 20:36:04 --> Final output sent to browser
DEBUG - 2011-05-09 20:36:04 --> Total execution time: 1.4951
DEBUG - 2011-05-09 20:36:10 --> Config Class Initialized
DEBUG - 2011-05-09 20:36:10 --> Hooks Class Initialized
DEBUG - 2011-05-09 20:36:10 --> Utf8 Class Initialized
DEBUG - 2011-05-09 20:36:10 --> UTF-8 Support Enabled
DEBUG - 2011-05-09 20:36:10 --> URI Class Initialized
DEBUG - 2011-05-09 20:36:10 --> Router Class Initialized
DEBUG - 2011-05-09 20:36:10 --> Output Class Initialized
DEBUG - 2011-05-09 20:36:10 --> Input Class Initialized
DEBUG - 2011-05-09 20:36:10 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-09 20:36:10 --> Language Class Initialized
DEBUG - 2011-05-09 20:36:10 --> Loader Class Initialized
DEBUG - 2011-05-09 20:36:10 --> Controller Class Initialized
DEBUG - 2011-05-09 20:36:10 --> Model Class Initialized
DEBUG - 2011-05-09 20:36:10 --> Model Class Initialized
DEBUG - 2011-05-09 20:36:10 --> Model Class Initialized
DEBUG - 2011-05-09 20:36:10 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-09 20:36:10 --> Database Driver Class Initialized
DEBUG - 2011-05-09 20:36:10 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-09 20:36:10 --> Helper loaded: url_helper
DEBUG - 2011-05-09 20:36:10 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-09 20:36:10 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-09 20:36:10 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-09 20:36:10 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-09 20:36:10 --> Final output sent to browser
DEBUG - 2011-05-09 20:36:10 --> Total execution time: 0.0456
DEBUG - 2011-05-09 20:36:12 --> Config Class Initialized
DEBUG - 2011-05-09 20:36:12 --> Hooks Class Initialized
DEBUG - 2011-05-09 20:36:12 --> Utf8 Class Initialized
DEBUG - 2011-05-09 20:36:12 --> UTF-8 Support Enabled
DEBUG - 2011-05-09 20:36:12 --> URI Class Initialized
DEBUG - 2011-05-09 20:36:12 --> Router Class Initialized
ERROR - 2011-05-09 20:36:12 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-09 20:37:08 --> Config Class Initialized
DEBUG - 2011-05-09 20:37:08 --> Hooks Class Initialized
DEBUG - 2011-05-09 20:37:08 --> Utf8 Class Initialized
DEBUG - 2011-05-09 20:37:08 --> UTF-8 Support Enabled
DEBUG - 2011-05-09 20:37:08 --> URI Class Initialized
DEBUG - 2011-05-09 20:37:08 --> Router Class Initialized
DEBUG - 2011-05-09 20:37:08 --> Output Class Initialized
DEBUG - 2011-05-09 20:37:08 --> Input Class Initialized
DEBUG - 2011-05-09 20:37:08 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-09 20:37:08 --> Language Class Initialized
DEBUG - 2011-05-09 20:37:08 --> Loader Class Initialized
DEBUG - 2011-05-09 20:37:08 --> Controller Class Initialized
DEBUG - 2011-05-09 20:37:08 --> Model Class Initialized
DEBUG - 2011-05-09 20:37:08 --> Model Class Initialized
DEBUG - 2011-05-09 20:37:08 --> Model Class Initialized
DEBUG - 2011-05-09 20:37:08 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-09 20:37:08 --> Database Driver Class Initialized
DEBUG - 2011-05-09 20:37:08 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-09 20:37:08 --> Helper loaded: url_helper
DEBUG - 2011-05-09 20:37:08 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-09 20:37:08 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-09 20:37:08 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-09 20:37:08 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-09 20:37:08 --> Final output sent to browser
DEBUG - 2011-05-09 20:37:08 --> Total execution time: 0.3454
DEBUG - 2011-05-09 20:37:11 --> Config Class Initialized
DEBUG - 2011-05-09 20:37:11 --> Hooks Class Initialized
DEBUG - 2011-05-09 20:37:11 --> Utf8 Class Initialized
DEBUG - 2011-05-09 20:37:11 --> UTF-8 Support Enabled
DEBUG - 2011-05-09 20:37:11 --> URI Class Initialized
DEBUG - 2011-05-09 20:37:11 --> Router Class Initialized
DEBUG - 2011-05-09 20:37:11 --> Output Class Initialized
DEBUG - 2011-05-09 20:37:11 --> Input Class Initialized
DEBUG - 2011-05-09 20:37:11 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-09 20:37:11 --> Language Class Initialized
DEBUG - 2011-05-09 20:37:11 --> Loader Class Initialized
DEBUG - 2011-05-09 20:37:11 --> Controller Class Initialized
DEBUG - 2011-05-09 20:37:11 --> Model Class Initialized
DEBUG - 2011-05-09 20:37:11 --> Model Class Initialized
DEBUG - 2011-05-09 20:37:11 --> Model Class Initialized
DEBUG - 2011-05-09 20:37:11 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-09 20:37:11 --> Database Driver Class Initialized
DEBUG - 2011-05-09 20:37:11 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-09 20:37:11 --> Helper loaded: url_helper
DEBUG - 2011-05-09 20:37:11 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-09 20:37:11 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-09 20:37:11 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-09 20:37:11 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-09 20:37:11 --> Final output sent to browser
DEBUG - 2011-05-09 20:37:11 --> Total execution time: 0.0484
DEBUG - 2011-05-09 20:37:17 --> Config Class Initialized
DEBUG - 2011-05-09 20:37:17 --> Hooks Class Initialized
DEBUG - 2011-05-09 20:37:17 --> Utf8 Class Initialized
DEBUG - 2011-05-09 20:37:17 --> UTF-8 Support Enabled
DEBUG - 2011-05-09 20:37:17 --> URI Class Initialized
DEBUG - 2011-05-09 20:37:17 --> Router Class Initialized
ERROR - 2011-05-09 20:37:17 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-09 20:37:45 --> Config Class Initialized
DEBUG - 2011-05-09 20:37:45 --> Hooks Class Initialized
DEBUG - 2011-05-09 20:37:45 --> Utf8 Class Initialized
DEBUG - 2011-05-09 20:37:45 --> UTF-8 Support Enabled
DEBUG - 2011-05-09 20:37:45 --> URI Class Initialized
DEBUG - 2011-05-09 20:37:45 --> Router Class Initialized
DEBUG - 2011-05-09 20:37:45 --> Output Class Initialized
DEBUG - 2011-05-09 20:37:45 --> Input Class Initialized
DEBUG - 2011-05-09 20:37:45 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-09 20:37:45 --> Language Class Initialized
DEBUG - 2011-05-09 20:37:45 --> Loader Class Initialized
DEBUG - 2011-05-09 20:37:45 --> Controller Class Initialized
DEBUG - 2011-05-09 20:37:45 --> Model Class Initialized
DEBUG - 2011-05-09 20:37:45 --> Model Class Initialized
DEBUG - 2011-05-09 20:37:45 --> Model Class Initialized
DEBUG - 2011-05-09 20:37:45 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-09 20:37:45 --> Database Driver Class Initialized
DEBUG - 2011-05-09 20:37:45 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-09 20:37:45 --> Helper loaded: url_helper
DEBUG - 2011-05-09 20:37:45 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-09 20:37:45 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-09 20:37:45 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-09 20:37:45 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-09 20:37:45 --> Final output sent to browser
DEBUG - 2011-05-09 20:37:45 --> Total execution time: 0.4576
DEBUG - 2011-05-09 20:37:48 --> Config Class Initialized
DEBUG - 2011-05-09 20:37:48 --> Hooks Class Initialized
DEBUG - 2011-05-09 20:37:48 --> Utf8 Class Initialized
DEBUG - 2011-05-09 20:37:48 --> UTF-8 Support Enabled
DEBUG - 2011-05-09 20:37:48 --> URI Class Initialized
DEBUG - 2011-05-09 20:37:48 --> Router Class Initialized
DEBUG - 2011-05-09 20:37:48 --> Output Class Initialized
DEBUG - 2011-05-09 20:37:48 --> Input Class Initialized
DEBUG - 2011-05-09 20:37:48 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-09 20:37:48 --> Language Class Initialized
DEBUG - 2011-05-09 20:37:48 --> Loader Class Initialized
DEBUG - 2011-05-09 20:37:48 --> Controller Class Initialized
DEBUG - 2011-05-09 20:37:48 --> Model Class Initialized
DEBUG - 2011-05-09 20:37:48 --> Model Class Initialized
DEBUG - 2011-05-09 20:37:48 --> Model Class Initialized
DEBUG - 2011-05-09 20:37:48 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-09 20:37:48 --> Database Driver Class Initialized
DEBUG - 2011-05-09 20:37:48 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-09 20:37:48 --> Helper loaded: url_helper
DEBUG - 2011-05-09 20:37:48 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-09 20:37:48 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-09 20:37:48 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-09 20:37:48 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-09 20:37:48 --> Final output sent to browser
DEBUG - 2011-05-09 20:37:48 --> Total execution time: 0.0975
DEBUG - 2011-05-09 20:37:56 --> Config Class Initialized
DEBUG - 2011-05-09 20:37:56 --> Hooks Class Initialized
DEBUG - 2011-05-09 20:37:56 --> Utf8 Class Initialized
DEBUG - 2011-05-09 20:37:56 --> UTF-8 Support Enabled
DEBUG - 2011-05-09 20:37:56 --> URI Class Initialized
DEBUG - 2011-05-09 20:37:56 --> Router Class Initialized
ERROR - 2011-05-09 20:37:56 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-09 20:38:34 --> Config Class Initialized
DEBUG - 2011-05-09 20:38:34 --> Hooks Class Initialized
DEBUG - 2011-05-09 20:38:34 --> Utf8 Class Initialized
DEBUG - 2011-05-09 20:38:34 --> UTF-8 Support Enabled
DEBUG - 2011-05-09 20:38:34 --> URI Class Initialized
DEBUG - 2011-05-09 20:38:34 --> Router Class Initialized
DEBUG - 2011-05-09 20:38:34 --> Output Class Initialized
DEBUG - 2011-05-09 20:38:34 --> Input Class Initialized
DEBUG - 2011-05-09 20:38:34 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-09 20:38:34 --> Language Class Initialized
DEBUG - 2011-05-09 20:38:34 --> Loader Class Initialized
DEBUG - 2011-05-09 20:38:34 --> Controller Class Initialized
DEBUG - 2011-05-09 20:38:34 --> Model Class Initialized
DEBUG - 2011-05-09 20:38:34 --> Model Class Initialized
DEBUG - 2011-05-09 20:38:34 --> Model Class Initialized
DEBUG - 2011-05-09 20:38:34 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-09 20:38:34 --> Database Driver Class Initialized
DEBUG - 2011-05-09 20:38:34 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-09 20:38:34 --> Helper loaded: url_helper
DEBUG - 2011-05-09 20:38:34 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-09 20:38:34 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-09 20:38:34 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-09 20:38:34 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-09 20:38:34 --> Final output sent to browser
DEBUG - 2011-05-09 20:38:34 --> Total execution time: 0.2493
DEBUG - 2011-05-09 20:38:42 --> Config Class Initialized
DEBUG - 2011-05-09 20:38:42 --> Hooks Class Initialized
DEBUG - 2011-05-09 20:38:42 --> Utf8 Class Initialized
DEBUG - 2011-05-09 20:38:42 --> UTF-8 Support Enabled
DEBUG - 2011-05-09 20:38:42 --> URI Class Initialized
DEBUG - 2011-05-09 20:38:42 --> Router Class Initialized
ERROR - 2011-05-09 20:38:42 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-05-09 20:38:42 --> Config Class Initialized
DEBUG - 2011-05-09 20:38:42 --> Hooks Class Initialized
DEBUG - 2011-05-09 20:38:42 --> Utf8 Class Initialized
DEBUG - 2011-05-09 20:38:42 --> UTF-8 Support Enabled
DEBUG - 2011-05-09 20:38:42 --> URI Class Initialized
DEBUG - 2011-05-09 20:38:42 --> Router Class Initialized
DEBUG - 2011-05-09 20:38:42 --> Output Class Initialized
DEBUG - 2011-05-09 20:38:42 --> Input Class Initialized
DEBUG - 2011-05-09 20:38:42 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-09 20:38:42 --> Language Class Initialized
DEBUG - 2011-05-09 20:38:42 --> Loader Class Initialized
DEBUG - 2011-05-09 20:38:42 --> Controller Class Initialized
DEBUG - 2011-05-09 20:38:42 --> Model Class Initialized
DEBUG - 2011-05-09 20:38:42 --> Model Class Initialized
DEBUG - 2011-05-09 20:38:42 --> Model Class Initialized
DEBUG - 2011-05-09 20:38:42 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-09 20:38:42 --> Database Driver Class Initialized
DEBUG - 2011-05-09 20:38:42 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-09 20:38:42 --> Helper loaded: url_helper
DEBUG - 2011-05-09 20:38:42 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-09 20:38:42 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-09 20:38:42 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-09 20:38:42 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-09 20:38:42 --> Final output sent to browser
DEBUG - 2011-05-09 20:38:42 --> Total execution time: 0.0734
DEBUG - 2011-05-09 20:38:49 --> Config Class Initialized
DEBUG - 2011-05-09 20:38:49 --> Hooks Class Initialized
DEBUG - 2011-05-09 20:38:49 --> Utf8 Class Initialized
DEBUG - 2011-05-09 20:38:49 --> UTF-8 Support Enabled
DEBUG - 2011-05-09 20:38:49 --> URI Class Initialized
DEBUG - 2011-05-09 20:38:49 --> Router Class Initialized
ERROR - 2011-05-09 20:38:49 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-09 20:39:09 --> Config Class Initialized
DEBUG - 2011-05-09 20:39:09 --> Hooks Class Initialized
DEBUG - 2011-05-09 20:39:09 --> Utf8 Class Initialized
DEBUG - 2011-05-09 20:39:09 --> UTF-8 Support Enabled
DEBUG - 2011-05-09 20:39:09 --> URI Class Initialized
DEBUG - 2011-05-09 20:39:09 --> Router Class Initialized
DEBUG - 2011-05-09 20:39:09 --> Output Class Initialized
DEBUG - 2011-05-09 20:39:09 --> Input Class Initialized
DEBUG - 2011-05-09 20:39:09 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-09 20:39:09 --> Language Class Initialized
DEBUG - 2011-05-09 20:39:09 --> Loader Class Initialized
DEBUG - 2011-05-09 20:39:09 --> Controller Class Initialized
DEBUG - 2011-05-09 20:39:09 --> Model Class Initialized
DEBUG - 2011-05-09 20:39:09 --> Model Class Initialized
DEBUG - 2011-05-09 20:39:09 --> Model Class Initialized
DEBUG - 2011-05-09 20:39:09 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-09 20:39:09 --> Database Driver Class Initialized
DEBUG - 2011-05-09 20:39:10 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-09 20:39:10 --> Helper loaded: url_helper
DEBUG - 2011-05-09 20:39:10 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-09 20:39:10 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-09 20:39:10 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-09 20:39:10 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-09 20:39:10 --> Final output sent to browser
DEBUG - 2011-05-09 20:39:10 --> Total execution time: 0.4855
DEBUG - 2011-05-09 20:39:12 --> Config Class Initialized
DEBUG - 2011-05-09 20:39:12 --> Hooks Class Initialized
DEBUG - 2011-05-09 20:39:12 --> Utf8 Class Initialized
DEBUG - 2011-05-09 20:39:12 --> UTF-8 Support Enabled
DEBUG - 2011-05-09 20:39:12 --> URI Class Initialized
DEBUG - 2011-05-09 20:39:12 --> Router Class Initialized
DEBUG - 2011-05-09 20:39:12 --> Output Class Initialized
DEBUG - 2011-05-09 20:39:12 --> Input Class Initialized
DEBUG - 2011-05-09 20:39:12 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-09 20:39:12 --> Language Class Initialized
DEBUG - 2011-05-09 20:39:12 --> Loader Class Initialized
DEBUG - 2011-05-09 20:39:12 --> Controller Class Initialized
DEBUG - 2011-05-09 20:39:12 --> Model Class Initialized
DEBUG - 2011-05-09 20:39:12 --> Model Class Initialized
DEBUG - 2011-05-09 20:39:12 --> Model Class Initialized
DEBUG - 2011-05-09 20:39:12 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-09 20:39:12 --> Database Driver Class Initialized
DEBUG - 2011-05-09 20:39:12 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-09 20:39:12 --> Helper loaded: url_helper
DEBUG - 2011-05-09 20:39:12 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-09 20:39:12 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-09 20:39:12 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-09 20:39:12 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-09 20:39:12 --> Final output sent to browser
DEBUG - 2011-05-09 20:39:12 --> Total execution time: 0.1001
DEBUG - 2011-05-09 20:39:16 --> Config Class Initialized
DEBUG - 2011-05-09 20:39:16 --> Hooks Class Initialized
DEBUG - 2011-05-09 20:39:16 --> Utf8 Class Initialized
DEBUG - 2011-05-09 20:39:16 --> UTF-8 Support Enabled
DEBUG - 2011-05-09 20:39:16 --> URI Class Initialized
DEBUG - 2011-05-09 20:39:16 --> Router Class Initialized
ERROR - 2011-05-09 20:39:16 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-09 20:40:11 --> Config Class Initialized
DEBUG - 2011-05-09 20:40:11 --> Hooks Class Initialized
DEBUG - 2011-05-09 20:40:11 --> Utf8 Class Initialized
DEBUG - 2011-05-09 20:40:11 --> UTF-8 Support Enabled
DEBUG - 2011-05-09 20:40:11 --> URI Class Initialized
DEBUG - 2011-05-09 20:40:11 --> Router Class Initialized
DEBUG - 2011-05-09 20:40:11 --> Output Class Initialized
DEBUG - 2011-05-09 20:40:11 --> Input Class Initialized
DEBUG - 2011-05-09 20:40:11 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-09 20:40:11 --> Language Class Initialized
DEBUG - 2011-05-09 20:40:11 --> Loader Class Initialized
DEBUG - 2011-05-09 20:40:11 --> Controller Class Initialized
DEBUG - 2011-05-09 20:40:11 --> Model Class Initialized
DEBUG - 2011-05-09 20:40:11 --> Model Class Initialized
DEBUG - 2011-05-09 20:40:11 --> Model Class Initialized
DEBUG - 2011-05-09 20:40:11 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-09 20:40:11 --> Database Driver Class Initialized
DEBUG - 2011-05-09 20:40:13 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-09 20:40:13 --> Helper loaded: url_helper
DEBUG - 2011-05-09 20:40:13 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-09 20:40:13 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-09 20:40:13 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-09 20:40:13 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-09 20:40:13 --> Final output sent to browser
DEBUG - 2011-05-09 20:40:13 --> Total execution time: 2.4504
DEBUG - 2011-05-09 20:40:44 --> Config Class Initialized
DEBUG - 2011-05-09 20:40:44 --> Hooks Class Initialized
DEBUG - 2011-05-09 20:40:44 --> Utf8 Class Initialized
DEBUG - 2011-05-09 20:40:44 --> UTF-8 Support Enabled
DEBUG - 2011-05-09 20:40:44 --> URI Class Initialized
DEBUG - 2011-05-09 20:40:44 --> Router Class Initialized
DEBUG - 2011-05-09 20:40:44 --> Output Class Initialized
DEBUG - 2011-05-09 20:40:44 --> Input Class Initialized
DEBUG - 2011-05-09 20:40:44 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-09 20:40:44 --> Language Class Initialized
DEBUG - 2011-05-09 20:40:44 --> Loader Class Initialized
DEBUG - 2011-05-09 20:40:44 --> Controller Class Initialized
DEBUG - 2011-05-09 20:40:44 --> Model Class Initialized
DEBUG - 2011-05-09 20:40:44 --> Model Class Initialized
DEBUG - 2011-05-09 20:40:44 --> Model Class Initialized
DEBUG - 2011-05-09 20:40:44 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-09 20:40:44 --> Database Driver Class Initialized
DEBUG - 2011-05-09 20:40:44 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-09 20:40:44 --> Helper loaded: url_helper
DEBUG - 2011-05-09 20:40:44 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-09 20:40:44 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-09 20:40:44 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-09 20:40:44 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-09 20:40:44 --> Final output sent to browser
DEBUG - 2011-05-09 20:40:44 --> Total execution time: 0.0510
DEBUG - 2011-05-09 20:40:59 --> Config Class Initialized
DEBUG - 2011-05-09 20:40:59 --> Hooks Class Initialized
DEBUG - 2011-05-09 20:40:59 --> Utf8 Class Initialized
DEBUG - 2011-05-09 20:40:59 --> UTF-8 Support Enabled
DEBUG - 2011-05-09 20:40:59 --> URI Class Initialized
DEBUG - 2011-05-09 20:40:59 --> Router Class Initialized
ERROR - 2011-05-09 20:40:59 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-09 20:41:05 --> Config Class Initialized
DEBUG - 2011-05-09 20:41:05 --> Hooks Class Initialized
DEBUG - 2011-05-09 20:41:05 --> Utf8 Class Initialized
DEBUG - 2011-05-09 20:41:05 --> UTF-8 Support Enabled
DEBUG - 2011-05-09 20:41:05 --> URI Class Initialized
DEBUG - 2011-05-09 20:41:05 --> Router Class Initialized
DEBUG - 2011-05-09 20:41:05 --> Output Class Initialized
DEBUG - 2011-05-09 20:41:05 --> Input Class Initialized
DEBUG - 2011-05-09 20:41:05 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-09 20:41:05 --> Language Class Initialized
DEBUG - 2011-05-09 20:41:05 --> Loader Class Initialized
DEBUG - 2011-05-09 20:41:05 --> Controller Class Initialized
DEBUG - 2011-05-09 20:41:05 --> Model Class Initialized
DEBUG - 2011-05-09 20:41:05 --> Model Class Initialized
DEBUG - 2011-05-09 20:41:05 --> Model Class Initialized
DEBUG - 2011-05-09 20:41:05 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-09 20:41:05 --> Database Driver Class Initialized
DEBUG - 2011-05-09 20:41:05 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-09 20:41:05 --> Helper loaded: url_helper
DEBUG - 2011-05-09 20:41:05 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-09 20:41:05 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-09 20:41:05 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-09 20:41:05 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-09 20:41:05 --> Final output sent to browser
DEBUG - 2011-05-09 20:41:05 --> Total execution time: 0.2779
DEBUG - 2011-05-09 20:41:07 --> Config Class Initialized
DEBUG - 2011-05-09 20:41:07 --> Hooks Class Initialized
DEBUG - 2011-05-09 20:41:07 --> Utf8 Class Initialized
DEBUG - 2011-05-09 20:41:07 --> UTF-8 Support Enabled
DEBUG - 2011-05-09 20:41:07 --> URI Class Initialized
DEBUG - 2011-05-09 20:41:07 --> Router Class Initialized
DEBUG - 2011-05-09 20:41:07 --> Output Class Initialized
DEBUG - 2011-05-09 20:41:07 --> Input Class Initialized
DEBUG - 2011-05-09 20:41:07 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-09 20:41:07 --> Language Class Initialized
DEBUG - 2011-05-09 20:41:07 --> Loader Class Initialized
DEBUG - 2011-05-09 20:41:07 --> Controller Class Initialized
DEBUG - 2011-05-09 20:41:07 --> Model Class Initialized
DEBUG - 2011-05-09 20:41:07 --> Model Class Initialized
DEBUG - 2011-05-09 20:41:07 --> Model Class Initialized
DEBUG - 2011-05-09 20:41:07 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-09 20:41:07 --> Database Driver Class Initialized
DEBUG - 2011-05-09 20:41:07 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-09 20:41:07 --> Helper loaded: url_helper
DEBUG - 2011-05-09 20:41:07 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-09 20:41:07 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-09 20:41:07 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-09 20:41:07 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-09 20:41:07 --> Final output sent to browser
DEBUG - 2011-05-09 20:41:07 --> Total execution time: 0.0512
DEBUG - 2011-05-09 20:41:08 --> Config Class Initialized
DEBUG - 2011-05-09 20:41:08 --> Hooks Class Initialized
DEBUG - 2011-05-09 20:41:08 --> Utf8 Class Initialized
DEBUG - 2011-05-09 20:41:08 --> UTF-8 Support Enabled
DEBUG - 2011-05-09 20:41:08 --> URI Class Initialized
DEBUG - 2011-05-09 20:41:08 --> Router Class Initialized
DEBUG - 2011-05-09 20:41:08 --> Output Class Initialized
DEBUG - 2011-05-09 20:41:08 --> Input Class Initialized
DEBUG - 2011-05-09 20:41:08 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-09 20:41:08 --> Language Class Initialized
DEBUG - 2011-05-09 20:41:08 --> Loader Class Initialized
DEBUG - 2011-05-09 20:41:08 --> Controller Class Initialized
DEBUG - 2011-05-09 20:41:08 --> Model Class Initialized
DEBUG - 2011-05-09 20:41:08 --> Model Class Initialized
DEBUG - 2011-05-09 20:41:08 --> Model Class Initialized
DEBUG - 2011-05-09 20:41:08 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-09 20:41:08 --> Database Driver Class Initialized
DEBUG - 2011-05-09 20:41:08 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-09 20:41:08 --> Helper loaded: url_helper
DEBUG - 2011-05-09 20:41:08 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-09 20:41:08 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-09 20:41:08 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-09 20:41:08 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-09 20:41:08 --> Final output sent to browser
DEBUG - 2011-05-09 20:41:08 --> Total execution time: 0.1441
DEBUG - 2011-05-09 20:41:22 --> Config Class Initialized
DEBUG - 2011-05-09 20:41:22 --> Hooks Class Initialized
DEBUG - 2011-05-09 20:41:22 --> Utf8 Class Initialized
DEBUG - 2011-05-09 20:41:22 --> UTF-8 Support Enabled
DEBUG - 2011-05-09 20:41:22 --> URI Class Initialized
DEBUG - 2011-05-09 20:41:22 --> Router Class Initialized
ERROR - 2011-05-09 20:41:22 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-09 20:42:31 --> Config Class Initialized
DEBUG - 2011-05-09 20:42:31 --> Hooks Class Initialized
DEBUG - 2011-05-09 20:42:31 --> Utf8 Class Initialized
DEBUG - 2011-05-09 20:42:31 --> UTF-8 Support Enabled
DEBUG - 2011-05-09 20:42:31 --> URI Class Initialized
DEBUG - 2011-05-09 20:42:31 --> Router Class Initialized
DEBUG - 2011-05-09 20:42:31 --> Output Class Initialized
DEBUG - 2011-05-09 20:42:31 --> Input Class Initialized
DEBUG - 2011-05-09 20:42:31 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-09 20:42:31 --> Language Class Initialized
DEBUG - 2011-05-09 20:42:31 --> Loader Class Initialized
DEBUG - 2011-05-09 20:42:31 --> Controller Class Initialized
DEBUG - 2011-05-09 20:42:31 --> Model Class Initialized
DEBUG - 2011-05-09 20:42:31 --> Model Class Initialized
DEBUG - 2011-05-09 20:42:31 --> Model Class Initialized
DEBUG - 2011-05-09 20:42:31 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-09 20:42:31 --> Database Driver Class Initialized
DEBUG - 2011-05-09 20:42:31 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-09 20:42:31 --> Helper loaded: url_helper
DEBUG - 2011-05-09 20:42:31 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-09 20:42:31 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-09 20:42:31 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-09 20:42:31 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-09 20:42:31 --> Final output sent to browser
DEBUG - 2011-05-09 20:42:31 --> Total execution time: 0.2632
DEBUG - 2011-05-09 20:42:32 --> Config Class Initialized
DEBUG - 2011-05-09 20:42:32 --> Hooks Class Initialized
DEBUG - 2011-05-09 20:42:32 --> Utf8 Class Initialized
DEBUG - 2011-05-09 20:42:32 --> UTF-8 Support Enabled
DEBUG - 2011-05-09 20:42:32 --> URI Class Initialized
DEBUG - 2011-05-09 20:42:32 --> Router Class Initialized
DEBUG - 2011-05-09 20:42:32 --> Output Class Initialized
DEBUG - 2011-05-09 20:42:32 --> Input Class Initialized
DEBUG - 2011-05-09 20:42:32 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-09 20:42:32 --> Language Class Initialized
DEBUG - 2011-05-09 20:42:32 --> Loader Class Initialized
DEBUG - 2011-05-09 20:42:32 --> Controller Class Initialized
DEBUG - 2011-05-09 20:42:32 --> Model Class Initialized
DEBUG - 2011-05-09 20:42:32 --> Model Class Initialized
DEBUG - 2011-05-09 20:42:32 --> Model Class Initialized
DEBUG - 2011-05-09 20:42:32 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-09 20:42:32 --> Database Driver Class Initialized
DEBUG - 2011-05-09 20:42:33 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-09 20:42:33 --> Helper loaded: url_helper
DEBUG - 2011-05-09 20:42:33 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-09 20:42:33 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-09 20:42:33 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-09 20:42:33 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-09 20:42:33 --> Final output sent to browser
DEBUG - 2011-05-09 20:42:33 --> Total execution time: 0.0526
DEBUG - 2011-05-09 20:42:33 --> Config Class Initialized
DEBUG - 2011-05-09 20:42:33 --> Hooks Class Initialized
DEBUG - 2011-05-09 20:42:33 --> Utf8 Class Initialized
DEBUG - 2011-05-09 20:42:33 --> UTF-8 Support Enabled
DEBUG - 2011-05-09 20:42:33 --> URI Class Initialized
DEBUG - 2011-05-09 20:42:33 --> Router Class Initialized
DEBUG - 2011-05-09 20:42:33 --> Output Class Initialized
DEBUG - 2011-05-09 20:42:33 --> Input Class Initialized
DEBUG - 2011-05-09 20:42:33 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-09 20:42:33 --> Language Class Initialized
DEBUG - 2011-05-09 20:42:33 --> Loader Class Initialized
DEBUG - 2011-05-09 20:42:33 --> Controller Class Initialized
DEBUG - 2011-05-09 20:42:33 --> Model Class Initialized
DEBUG - 2011-05-09 20:42:33 --> Model Class Initialized
DEBUG - 2011-05-09 20:42:33 --> Model Class Initialized
DEBUG - 2011-05-09 20:42:33 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-09 20:42:33 --> Database Driver Class Initialized
DEBUG - 2011-05-09 20:42:33 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-09 20:42:33 --> Helper loaded: url_helper
DEBUG - 2011-05-09 20:42:33 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-09 20:42:33 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-09 20:42:33 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-09 20:42:33 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-09 20:42:33 --> Final output sent to browser
DEBUG - 2011-05-09 20:42:33 --> Total execution time: 0.0486
DEBUG - 2011-05-09 20:42:40 --> Config Class Initialized
DEBUG - 2011-05-09 20:42:40 --> Hooks Class Initialized
DEBUG - 2011-05-09 20:42:40 --> Utf8 Class Initialized
DEBUG - 2011-05-09 20:42:40 --> UTF-8 Support Enabled
DEBUG - 2011-05-09 20:42:40 --> URI Class Initialized
DEBUG - 2011-05-09 20:42:40 --> Router Class Initialized
ERROR - 2011-05-09 20:42:40 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-09 20:43:11 --> Config Class Initialized
DEBUG - 2011-05-09 20:43:11 --> Hooks Class Initialized
DEBUG - 2011-05-09 20:43:11 --> Utf8 Class Initialized
DEBUG - 2011-05-09 20:43:11 --> UTF-8 Support Enabled
DEBUG - 2011-05-09 20:43:11 --> URI Class Initialized
DEBUG - 2011-05-09 20:43:11 --> Router Class Initialized
DEBUG - 2011-05-09 20:43:11 --> Output Class Initialized
DEBUG - 2011-05-09 20:43:11 --> Input Class Initialized
DEBUG - 2011-05-09 20:43:11 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-09 20:43:11 --> Language Class Initialized
DEBUG - 2011-05-09 20:43:11 --> Loader Class Initialized
DEBUG - 2011-05-09 20:43:11 --> Controller Class Initialized
DEBUG - 2011-05-09 20:43:11 --> Model Class Initialized
DEBUG - 2011-05-09 20:43:11 --> Model Class Initialized
DEBUG - 2011-05-09 20:43:11 --> Model Class Initialized
DEBUG - 2011-05-09 20:43:11 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-09 20:43:11 --> Database Driver Class Initialized
DEBUG - 2011-05-09 20:43:11 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-09 20:43:11 --> Helper loaded: url_helper
DEBUG - 2011-05-09 20:43:11 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-09 20:43:11 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-09 20:43:11 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-09 20:43:11 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-09 20:43:11 --> Final output sent to browser
DEBUG - 2011-05-09 20:43:11 --> Total execution time: 0.3240
DEBUG - 2011-05-09 20:43:13 --> Config Class Initialized
DEBUG - 2011-05-09 20:43:13 --> Hooks Class Initialized
DEBUG - 2011-05-09 20:43:13 --> Utf8 Class Initialized
DEBUG - 2011-05-09 20:43:13 --> UTF-8 Support Enabled
DEBUG - 2011-05-09 20:43:13 --> URI Class Initialized
DEBUG - 2011-05-09 20:43:13 --> Router Class Initialized
DEBUG - 2011-05-09 20:43:13 --> Output Class Initialized
DEBUG - 2011-05-09 20:43:13 --> Input Class Initialized
DEBUG - 2011-05-09 20:43:13 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-09 20:43:13 --> Language Class Initialized
DEBUG - 2011-05-09 20:43:13 --> Loader Class Initialized
DEBUG - 2011-05-09 20:43:13 --> Controller Class Initialized
DEBUG - 2011-05-09 20:43:13 --> Model Class Initialized
DEBUG - 2011-05-09 20:43:13 --> Model Class Initialized
DEBUG - 2011-05-09 20:43:13 --> Model Class Initialized
DEBUG - 2011-05-09 20:43:13 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-09 20:43:13 --> Database Driver Class Initialized
DEBUG - 2011-05-09 20:43:13 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-09 20:43:13 --> Helper loaded: url_helper
DEBUG - 2011-05-09 20:43:13 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-09 20:43:13 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-09 20:43:13 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-09 20:43:13 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-09 20:43:13 --> Final output sent to browser
DEBUG - 2011-05-09 20:43:13 --> Total execution time: 0.0443
DEBUG - 2011-05-09 20:43:14 --> Config Class Initialized
DEBUG - 2011-05-09 20:43:14 --> Hooks Class Initialized
DEBUG - 2011-05-09 20:43:14 --> Utf8 Class Initialized
DEBUG - 2011-05-09 20:43:14 --> UTF-8 Support Enabled
DEBUG - 2011-05-09 20:43:14 --> URI Class Initialized
DEBUG - 2011-05-09 20:43:14 --> Router Class Initialized
DEBUG - 2011-05-09 20:43:14 --> Output Class Initialized
DEBUG - 2011-05-09 20:43:14 --> Input Class Initialized
DEBUG - 2011-05-09 20:43:14 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-09 20:43:14 --> Language Class Initialized
DEBUG - 2011-05-09 20:43:14 --> Loader Class Initialized
DEBUG - 2011-05-09 20:43:14 --> Controller Class Initialized
DEBUG - 2011-05-09 20:43:14 --> Model Class Initialized
DEBUG - 2011-05-09 20:43:14 --> Model Class Initialized
DEBUG - 2011-05-09 20:43:14 --> Model Class Initialized
DEBUG - 2011-05-09 20:43:14 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-09 20:43:14 --> Database Driver Class Initialized
DEBUG - 2011-05-09 20:43:14 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-09 20:43:14 --> Helper loaded: url_helper
DEBUG - 2011-05-09 20:43:14 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-09 20:43:14 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-09 20:43:14 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-09 20:43:14 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-09 20:43:14 --> Final output sent to browser
DEBUG - 2011-05-09 20:43:14 --> Total execution time: 0.0436
DEBUG - 2011-05-09 20:43:22 --> Config Class Initialized
DEBUG - 2011-05-09 20:43:22 --> Hooks Class Initialized
DEBUG - 2011-05-09 20:43:22 --> Utf8 Class Initialized
DEBUG - 2011-05-09 20:43:22 --> UTF-8 Support Enabled
DEBUG - 2011-05-09 20:43:22 --> URI Class Initialized
DEBUG - 2011-05-09 20:43:22 --> Router Class Initialized
ERROR - 2011-05-09 20:43:22 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-09 20:43:54 --> Config Class Initialized
DEBUG - 2011-05-09 20:43:54 --> Hooks Class Initialized
DEBUG - 2011-05-09 20:43:54 --> Utf8 Class Initialized
DEBUG - 2011-05-09 20:43:54 --> UTF-8 Support Enabled
DEBUG - 2011-05-09 20:43:54 --> URI Class Initialized
DEBUG - 2011-05-09 20:43:54 --> Router Class Initialized
DEBUG - 2011-05-09 20:43:54 --> Output Class Initialized
DEBUG - 2011-05-09 20:43:54 --> Input Class Initialized
DEBUG - 2011-05-09 20:43:54 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-09 20:43:54 --> Language Class Initialized
DEBUG - 2011-05-09 20:43:54 --> Loader Class Initialized
DEBUG - 2011-05-09 20:43:54 --> Controller Class Initialized
DEBUG - 2011-05-09 20:43:54 --> Model Class Initialized
DEBUG - 2011-05-09 20:43:54 --> Model Class Initialized
DEBUG - 2011-05-09 20:43:54 --> Model Class Initialized
DEBUG - 2011-05-09 20:43:54 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-09 20:43:54 --> Database Driver Class Initialized
DEBUG - 2011-05-09 20:43:54 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-09 20:43:55 --> Helper loaded: url_helper
DEBUG - 2011-05-09 20:43:55 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-09 20:43:55 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-09 20:43:55 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-09 20:43:55 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-09 20:43:55 --> Final output sent to browser
DEBUG - 2011-05-09 20:43:55 --> Total execution time: 0.2337
DEBUG - 2011-05-09 20:44:07 --> Config Class Initialized
DEBUG - 2011-05-09 20:44:07 --> Hooks Class Initialized
DEBUG - 2011-05-09 20:44:07 --> Utf8 Class Initialized
DEBUG - 2011-05-09 20:44:07 --> UTF-8 Support Enabled
DEBUG - 2011-05-09 20:44:07 --> URI Class Initialized
DEBUG - 2011-05-09 20:44:07 --> Router Class Initialized
ERROR - 2011-05-09 20:44:07 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-09 20:44:31 --> Config Class Initialized
DEBUG - 2011-05-09 20:44:31 --> Hooks Class Initialized
DEBUG - 2011-05-09 20:44:31 --> Utf8 Class Initialized
DEBUG - 2011-05-09 20:44:31 --> UTF-8 Support Enabled
DEBUG - 2011-05-09 20:44:31 --> URI Class Initialized
DEBUG - 2011-05-09 20:44:31 --> Router Class Initialized
DEBUG - 2011-05-09 20:44:31 --> Output Class Initialized
DEBUG - 2011-05-09 20:44:31 --> Input Class Initialized
DEBUG - 2011-05-09 20:44:31 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-09 20:44:31 --> Language Class Initialized
DEBUG - 2011-05-09 20:44:31 --> Loader Class Initialized
DEBUG - 2011-05-09 20:44:31 --> Controller Class Initialized
DEBUG - 2011-05-09 20:44:31 --> Model Class Initialized
DEBUG - 2011-05-09 20:44:31 --> Model Class Initialized
DEBUG - 2011-05-09 20:44:31 --> Model Class Initialized
DEBUG - 2011-05-09 20:44:31 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-09 20:44:31 --> Database Driver Class Initialized
DEBUG - 2011-05-09 20:44:32 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-09 20:44:32 --> Helper loaded: url_helper
DEBUG - 2011-05-09 20:44:32 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-09 20:44:32 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-09 20:44:33 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-09 20:44:33 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-09 20:44:33 --> Final output sent to browser
DEBUG - 2011-05-09 20:44:33 --> Total execution time: 1.1408
DEBUG - 2011-05-09 20:44:37 --> Config Class Initialized
DEBUG - 2011-05-09 20:44:37 --> Hooks Class Initialized
DEBUG - 2011-05-09 20:44:37 --> Utf8 Class Initialized
DEBUG - 2011-05-09 20:44:37 --> UTF-8 Support Enabled
DEBUG - 2011-05-09 20:44:37 --> URI Class Initialized
DEBUG - 2011-05-09 20:44:37 --> Router Class Initialized
DEBUG - 2011-05-09 20:44:37 --> Output Class Initialized
DEBUG - 2011-05-09 20:44:37 --> Input Class Initialized
DEBUG - 2011-05-09 20:44:37 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-09 20:44:37 --> Language Class Initialized
DEBUG - 2011-05-09 20:44:37 --> Loader Class Initialized
DEBUG - 2011-05-09 20:44:37 --> Controller Class Initialized
DEBUG - 2011-05-09 20:44:37 --> Model Class Initialized
DEBUG - 2011-05-09 20:44:37 --> Model Class Initialized
DEBUG - 2011-05-09 20:44:37 --> Model Class Initialized
DEBUG - 2011-05-09 20:44:37 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-09 20:44:37 --> Database Driver Class Initialized
DEBUG - 2011-05-09 20:44:37 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-09 20:44:37 --> Helper loaded: url_helper
DEBUG - 2011-05-09 20:44:37 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-09 20:44:37 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-09 20:44:37 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-09 20:44:37 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-09 20:44:37 --> Final output sent to browser
DEBUG - 2011-05-09 20:44:37 --> Total execution time: 0.0874
DEBUG - 2011-05-09 20:44:43 --> Config Class Initialized
DEBUG - 2011-05-09 20:44:43 --> Hooks Class Initialized
DEBUG - 2011-05-09 20:44:43 --> Utf8 Class Initialized
DEBUG - 2011-05-09 20:44:43 --> UTF-8 Support Enabled
DEBUG - 2011-05-09 20:44:43 --> URI Class Initialized
DEBUG - 2011-05-09 20:44:43 --> Router Class Initialized
ERROR - 2011-05-09 20:44:43 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-09 20:45:20 --> Config Class Initialized
DEBUG - 2011-05-09 20:45:20 --> Hooks Class Initialized
DEBUG - 2011-05-09 20:45:20 --> Utf8 Class Initialized
DEBUG - 2011-05-09 20:45:20 --> UTF-8 Support Enabled
DEBUG - 2011-05-09 20:45:20 --> URI Class Initialized
DEBUG - 2011-05-09 20:45:20 --> Router Class Initialized
DEBUG - 2011-05-09 20:45:20 --> Output Class Initialized
DEBUG - 2011-05-09 20:45:20 --> Input Class Initialized
DEBUG - 2011-05-09 20:45:20 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-09 20:45:20 --> Language Class Initialized
DEBUG - 2011-05-09 20:45:20 --> Loader Class Initialized
DEBUG - 2011-05-09 20:45:20 --> Controller Class Initialized
DEBUG - 2011-05-09 20:45:20 --> Model Class Initialized
DEBUG - 2011-05-09 20:45:20 --> Model Class Initialized
DEBUG - 2011-05-09 20:45:20 --> Model Class Initialized
DEBUG - 2011-05-09 20:45:20 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-09 20:45:20 --> Database Driver Class Initialized
DEBUG - 2011-05-09 20:45:21 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-09 20:45:21 --> Helper loaded: url_helper
DEBUG - 2011-05-09 20:45:21 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-09 20:45:21 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-09 20:45:21 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-09 20:45:21 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-09 20:45:21 --> Final output sent to browser
DEBUG - 2011-05-09 20:45:21 --> Total execution time: 0.2627
DEBUG - 2011-05-09 20:45:28 --> Config Class Initialized
DEBUG - 2011-05-09 20:45:28 --> Hooks Class Initialized
DEBUG - 2011-05-09 20:45:28 --> Utf8 Class Initialized
DEBUG - 2011-05-09 20:45:28 --> UTF-8 Support Enabled
DEBUG - 2011-05-09 20:45:28 --> URI Class Initialized
DEBUG - 2011-05-09 20:45:28 --> Router Class Initialized
DEBUG - 2011-05-09 20:45:28 --> Output Class Initialized
DEBUG - 2011-05-09 20:45:28 --> Input Class Initialized
DEBUG - 2011-05-09 20:45:28 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-09 20:45:28 --> Language Class Initialized
DEBUG - 2011-05-09 20:45:28 --> Loader Class Initialized
DEBUG - 2011-05-09 20:45:28 --> Controller Class Initialized
DEBUG - 2011-05-09 20:45:28 --> Model Class Initialized
DEBUG - 2011-05-09 20:45:28 --> Model Class Initialized
DEBUG - 2011-05-09 20:45:28 --> Model Class Initialized
DEBUG - 2011-05-09 20:45:28 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-09 20:45:28 --> Database Driver Class Initialized
DEBUG - 2011-05-09 20:45:28 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-09 20:45:28 --> Helper loaded: url_helper
DEBUG - 2011-05-09 20:45:28 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-09 20:45:28 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-09 20:45:28 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-09 20:45:28 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-09 20:45:28 --> Final output sent to browser
DEBUG - 2011-05-09 20:45:28 --> Total execution time: 0.0468
DEBUG - 2011-05-09 20:45:43 --> Config Class Initialized
DEBUG - 2011-05-09 20:45:43 --> Hooks Class Initialized
DEBUG - 2011-05-09 20:45:43 --> Utf8 Class Initialized
DEBUG - 2011-05-09 20:45:43 --> UTF-8 Support Enabled
DEBUG - 2011-05-09 20:45:43 --> URI Class Initialized
DEBUG - 2011-05-09 20:45:43 --> Router Class Initialized
ERROR - 2011-05-09 20:45:43 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-09 20:46:27 --> Config Class Initialized
DEBUG - 2011-05-09 20:46:27 --> Hooks Class Initialized
DEBUG - 2011-05-09 20:46:27 --> Utf8 Class Initialized
DEBUG - 2011-05-09 20:46:27 --> UTF-8 Support Enabled
DEBUG - 2011-05-09 20:46:27 --> URI Class Initialized
DEBUG - 2011-05-09 20:46:27 --> Router Class Initialized
DEBUG - 2011-05-09 20:46:27 --> Output Class Initialized
DEBUG - 2011-05-09 20:46:27 --> Input Class Initialized
DEBUG - 2011-05-09 20:46:27 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-09 20:46:27 --> Language Class Initialized
DEBUG - 2011-05-09 20:46:27 --> Loader Class Initialized
DEBUG - 2011-05-09 20:46:27 --> Controller Class Initialized
DEBUG - 2011-05-09 20:46:27 --> Model Class Initialized
DEBUG - 2011-05-09 20:46:27 --> Model Class Initialized
DEBUG - 2011-05-09 20:46:27 --> Model Class Initialized
DEBUG - 2011-05-09 20:46:27 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-09 20:46:27 --> Database Driver Class Initialized
DEBUG - 2011-05-09 20:46:27 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-09 20:46:27 --> Helper loaded: url_helper
DEBUG - 2011-05-09 20:46:27 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-09 20:46:27 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-09 20:46:27 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-09 20:46:27 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-09 20:46:27 --> Final output sent to browser
DEBUG - 2011-05-09 20:46:27 --> Total execution time: 0.4674
DEBUG - 2011-05-09 20:46:35 --> Config Class Initialized
DEBUG - 2011-05-09 20:46:35 --> Hooks Class Initialized
DEBUG - 2011-05-09 20:46:35 --> Utf8 Class Initialized
DEBUG - 2011-05-09 20:46:35 --> UTF-8 Support Enabled
DEBUG - 2011-05-09 20:46:35 --> URI Class Initialized
DEBUG - 2011-05-09 20:46:35 --> Router Class Initialized
DEBUG - 2011-05-09 20:46:35 --> Output Class Initialized
DEBUG - 2011-05-09 20:46:35 --> Input Class Initialized
DEBUG - 2011-05-09 20:46:35 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-09 20:46:35 --> Language Class Initialized
DEBUG - 2011-05-09 20:46:35 --> Loader Class Initialized
DEBUG - 2011-05-09 20:46:35 --> Controller Class Initialized
DEBUG - 2011-05-09 20:46:35 --> Model Class Initialized
DEBUG - 2011-05-09 20:46:35 --> Model Class Initialized
DEBUG - 2011-05-09 20:46:35 --> Model Class Initialized
DEBUG - 2011-05-09 20:46:35 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-09 20:46:35 --> Database Driver Class Initialized
DEBUG - 2011-05-09 20:46:35 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-09 20:46:35 --> Helper loaded: url_helper
DEBUG - 2011-05-09 20:46:35 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-09 20:46:35 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-09 20:46:35 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-09 20:46:35 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-09 20:46:35 --> Final output sent to browser
DEBUG - 2011-05-09 20:46:35 --> Total execution time: 0.0957
DEBUG - 2011-05-09 20:46:44 --> Config Class Initialized
DEBUG - 2011-05-09 20:46:44 --> Hooks Class Initialized
DEBUG - 2011-05-09 20:46:44 --> Utf8 Class Initialized
DEBUG - 2011-05-09 20:46:44 --> UTF-8 Support Enabled
DEBUG - 2011-05-09 20:46:44 --> URI Class Initialized
DEBUG - 2011-05-09 20:46:44 --> Router Class Initialized
ERROR - 2011-05-09 20:46:44 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-09 20:47:01 --> Config Class Initialized
DEBUG - 2011-05-09 20:47:01 --> Hooks Class Initialized
DEBUG - 2011-05-09 20:47:01 --> Utf8 Class Initialized
DEBUG - 2011-05-09 20:47:01 --> UTF-8 Support Enabled
DEBUG - 2011-05-09 20:47:01 --> URI Class Initialized
DEBUG - 2011-05-09 20:47:01 --> Router Class Initialized
DEBUG - 2011-05-09 20:47:01 --> Output Class Initialized
DEBUG - 2011-05-09 20:47:01 --> Input Class Initialized
DEBUG - 2011-05-09 20:47:01 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-09 20:47:01 --> Language Class Initialized
DEBUG - 2011-05-09 20:47:01 --> Loader Class Initialized
DEBUG - 2011-05-09 20:47:01 --> Controller Class Initialized
DEBUG - 2011-05-09 20:47:01 --> Model Class Initialized
DEBUG - 2011-05-09 20:47:01 --> Model Class Initialized
DEBUG - 2011-05-09 20:47:01 --> Model Class Initialized
DEBUG - 2011-05-09 20:47:01 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-09 20:47:01 --> Database Driver Class Initialized
DEBUG - 2011-05-09 20:47:01 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-09 20:47:01 --> Helper loaded: url_helper
DEBUG - 2011-05-09 20:47:01 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-09 20:47:01 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-09 20:47:01 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-09 20:47:01 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-09 20:47:01 --> Final output sent to browser
DEBUG - 2011-05-09 20:47:01 --> Total execution time: 0.0717
DEBUG - 2011-05-09 20:47:23 --> Config Class Initialized
DEBUG - 2011-05-09 20:47:23 --> Hooks Class Initialized
DEBUG - 2011-05-09 20:47:23 --> Utf8 Class Initialized
DEBUG - 2011-05-09 20:47:23 --> UTF-8 Support Enabled
DEBUG - 2011-05-09 20:47:23 --> URI Class Initialized
DEBUG - 2011-05-09 20:47:23 --> Router Class Initialized
ERROR - 2011-05-09 20:47:23 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-09 20:52:43 --> Config Class Initialized
DEBUG - 2011-05-09 20:52:43 --> Hooks Class Initialized
DEBUG - 2011-05-09 20:52:43 --> Utf8 Class Initialized
DEBUG - 2011-05-09 20:52:43 --> UTF-8 Support Enabled
DEBUG - 2011-05-09 20:52:43 --> URI Class Initialized
DEBUG - 2011-05-09 20:52:43 --> Router Class Initialized
DEBUG - 2011-05-09 20:52:43 --> Output Class Initialized
DEBUG - 2011-05-09 20:52:43 --> Input Class Initialized
DEBUG - 2011-05-09 20:52:43 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-09 20:52:43 --> Language Class Initialized
DEBUG - 2011-05-09 20:52:43 --> Loader Class Initialized
DEBUG - 2011-05-09 20:52:43 --> Controller Class Initialized
DEBUG - 2011-05-09 20:52:43 --> Model Class Initialized
DEBUG - 2011-05-09 20:52:43 --> Model Class Initialized
DEBUG - 2011-05-09 20:52:43 --> Model Class Initialized
DEBUG - 2011-05-09 20:52:43 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-09 20:52:43 --> Database Driver Class Initialized
DEBUG - 2011-05-09 20:52:43 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-09 20:52:43 --> Helper loaded: url_helper
DEBUG - 2011-05-09 20:52:43 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-09 20:52:43 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-09 20:52:43 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-09 20:52:43 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-09 20:52:43 --> Final output sent to browser
DEBUG - 2011-05-09 20:52:43 --> Total execution time: 0.3232
DEBUG - 2011-05-09 20:52:45 --> Config Class Initialized
DEBUG - 2011-05-09 20:52:45 --> Hooks Class Initialized
DEBUG - 2011-05-09 20:52:45 --> Utf8 Class Initialized
DEBUG - 2011-05-09 20:52:45 --> UTF-8 Support Enabled
DEBUG - 2011-05-09 20:52:45 --> URI Class Initialized
DEBUG - 2011-05-09 20:52:45 --> Router Class Initialized
DEBUG - 2011-05-09 20:52:45 --> Output Class Initialized
DEBUG - 2011-05-09 20:52:45 --> Input Class Initialized
DEBUG - 2011-05-09 20:52:45 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-09 20:52:45 --> Language Class Initialized
DEBUG - 2011-05-09 20:52:45 --> Loader Class Initialized
DEBUG - 2011-05-09 20:52:45 --> Controller Class Initialized
ERROR - 2011-05-09 20:52:45 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-09 20:52:45 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-09 20:52:45 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-09 20:52:45 --> Model Class Initialized
DEBUG - 2011-05-09 20:52:45 --> Model Class Initialized
DEBUG - 2011-05-09 20:52:45 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-09 20:52:45 --> Database Driver Class Initialized
DEBUG - 2011-05-09 20:52:45 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-09 20:52:45 --> Helper loaded: url_helper
DEBUG - 2011-05-09 20:52:45 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-09 20:52:45 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-09 20:52:45 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-09 20:52:45 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-09 20:52:45 --> Final output sent to browser
DEBUG - 2011-05-09 20:52:45 --> Total execution time: 0.1267
DEBUG - 2011-05-09 22:03:12 --> Config Class Initialized
DEBUG - 2011-05-09 22:03:12 --> Hooks Class Initialized
DEBUG - 2011-05-09 22:03:12 --> Utf8 Class Initialized
DEBUG - 2011-05-09 22:03:12 --> UTF-8 Support Enabled
DEBUG - 2011-05-09 22:03:12 --> URI Class Initialized
DEBUG - 2011-05-09 22:03:12 --> Router Class Initialized
DEBUG - 2011-05-09 22:03:12 --> Output Class Initialized
DEBUG - 2011-05-09 22:03:12 --> Input Class Initialized
DEBUG - 2011-05-09 22:03:12 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-09 22:03:12 --> Language Class Initialized
DEBUG - 2011-05-09 22:03:12 --> Loader Class Initialized
DEBUG - 2011-05-09 22:03:12 --> Controller Class Initialized
ERROR - 2011-05-09 22:03:12 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-09 22:03:12 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-09 22:03:12 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-09 22:03:12 --> Model Class Initialized
DEBUG - 2011-05-09 22:03:12 --> Model Class Initialized
DEBUG - 2011-05-09 22:03:12 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-09 22:03:13 --> Database Driver Class Initialized
DEBUG - 2011-05-09 22:03:13 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-09 22:03:13 --> Helper loaded: url_helper
DEBUG - 2011-05-09 22:03:13 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-09 22:03:13 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-09 22:03:13 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-09 22:03:13 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-09 22:03:13 --> Final output sent to browser
DEBUG - 2011-05-09 22:03:13 --> Total execution time: 0.3579
DEBUG - 2011-05-09 22:47:58 --> Config Class Initialized
DEBUG - 2011-05-09 22:47:58 --> Hooks Class Initialized
DEBUG - 2011-05-09 22:47:58 --> Utf8 Class Initialized
DEBUG - 2011-05-09 22:47:58 --> UTF-8 Support Enabled
DEBUG - 2011-05-09 22:47:58 --> URI Class Initialized
DEBUG - 2011-05-09 22:47:58 --> Router Class Initialized
DEBUG - 2011-05-09 22:47:58 --> No URI present. Default controller set.
DEBUG - 2011-05-09 22:47:58 --> Output Class Initialized
DEBUG - 2011-05-09 22:47:58 --> Input Class Initialized
DEBUG - 2011-05-09 22:47:58 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-09 22:47:58 --> Language Class Initialized
DEBUG - 2011-05-09 22:47:58 --> Loader Class Initialized
DEBUG - 2011-05-09 22:47:58 --> Controller Class Initialized
DEBUG - 2011-05-09 22:47:58 --> File loaded: application/views/splash/main.php
DEBUG - 2011-05-09 22:47:58 --> Helper loaded: url_helper
DEBUG - 2011-05-09 22:47:58 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-09 22:47:58 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-09 22:47:58 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-09 22:47:58 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-09 22:47:58 --> Final output sent to browser
DEBUG - 2011-05-09 22:47:58 --> Total execution time: 0.1910
DEBUG - 2011-05-09 22:48:01 --> Config Class Initialized
DEBUG - 2011-05-09 22:48:01 --> Hooks Class Initialized
DEBUG - 2011-05-09 22:48:01 --> Utf8 Class Initialized
DEBUG - 2011-05-09 22:48:01 --> UTF-8 Support Enabled
DEBUG - 2011-05-09 22:48:01 --> URI Class Initialized
DEBUG - 2011-05-09 22:48:01 --> Router Class Initialized
ERROR - 2011-05-09 22:48:01 --> 404 Page Not Found --> favicon.ico

<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2011-09-16 01:32:21 --> Config Class Initialized
DEBUG - 2011-09-16 01:32:21 --> Hooks Class Initialized
DEBUG - 2011-09-16 01:32:21 --> Utf8 Class Initialized
DEBUG - 2011-09-16 01:32:21 --> UTF-8 Support Enabled
DEBUG - 2011-09-16 01:32:21 --> URI Class Initialized
DEBUG - 2011-09-16 01:32:21 --> Router Class Initialized
DEBUG - 2011-09-16 01:32:21 --> Output Class Initialized
DEBUG - 2011-09-16 01:32:21 --> Input Class Initialized
DEBUG - 2011-09-16 01:32:21 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-16 01:32:21 --> Language Class Initialized
DEBUG - 2011-09-16 01:32:21 --> Loader Class Initialized
DEBUG - 2011-09-16 01:32:21 --> Controller Class Initialized
ERROR - 2011-09-16 01:32:21 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-16 01:32:21 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-16 01:32:21 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-16 01:32:21 --> Model Class Initialized
DEBUG - 2011-09-16 01:32:21 --> Model Class Initialized
DEBUG - 2011-09-16 01:32:21 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-16 01:32:21 --> Database Driver Class Initialized
DEBUG - 2011-09-16 01:32:21 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-16 01:32:22 --> Helper loaded: url_helper
DEBUG - 2011-09-16 01:32:22 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-16 01:32:22 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-16 01:32:22 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-16 01:32:22 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-16 01:32:22 --> Final output sent to browser
DEBUG - 2011-09-16 01:32:22 --> Total execution time: 0.6932
DEBUG - 2011-09-16 01:32:22 --> Config Class Initialized
DEBUG - 2011-09-16 01:32:22 --> Hooks Class Initialized
DEBUG - 2011-09-16 01:32:22 --> Utf8 Class Initialized
DEBUG - 2011-09-16 01:32:22 --> UTF-8 Support Enabled
DEBUG - 2011-09-16 01:32:22 --> URI Class Initialized
DEBUG - 2011-09-16 01:32:22 --> Router Class Initialized
DEBUG - 2011-09-16 01:32:22 --> Output Class Initialized
DEBUG - 2011-09-16 01:32:22 --> Input Class Initialized
DEBUG - 2011-09-16 01:32:22 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-16 01:32:22 --> Language Class Initialized
DEBUG - 2011-09-16 01:32:22 --> Loader Class Initialized
DEBUG - 2011-09-16 01:32:22 --> Controller Class Initialized
DEBUG - 2011-09-16 01:32:22 --> Model Class Initialized
DEBUG - 2011-09-16 01:32:22 --> Model Class Initialized
DEBUG - 2011-09-16 01:32:22 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-16 01:32:22 --> Database Driver Class Initialized
DEBUG - 2011-09-16 01:32:23 --> Final output sent to browser
DEBUG - 2011-09-16 01:32:23 --> Total execution time: 0.7646
DEBUG - 2011-09-16 01:32:26 --> Config Class Initialized
DEBUG - 2011-09-16 01:32:26 --> Hooks Class Initialized
DEBUG - 2011-09-16 01:32:26 --> Utf8 Class Initialized
DEBUG - 2011-09-16 01:32:26 --> UTF-8 Support Enabled
DEBUG - 2011-09-16 01:32:26 --> URI Class Initialized
DEBUG - 2011-09-16 01:32:26 --> Router Class Initialized
DEBUG - 2011-09-16 01:32:26 --> Output Class Initialized
DEBUG - 2011-09-16 01:32:26 --> Input Class Initialized
DEBUG - 2011-09-16 01:32:26 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-16 01:32:26 --> Language Class Initialized
DEBUG - 2011-09-16 01:32:26 --> Loader Class Initialized
DEBUG - 2011-09-16 01:32:26 --> Controller Class Initialized
DEBUG - 2011-09-16 01:32:26 --> Model Class Initialized
DEBUG - 2011-09-16 01:32:26 --> Model Class Initialized
DEBUG - 2011-09-16 01:32:26 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-16 01:32:26 --> Database Driver Class Initialized
DEBUG - 2011-09-16 01:32:27 --> Final output sent to browser
DEBUG - 2011-09-16 01:32:27 --> Total execution time: 0.5976
DEBUG - 2011-09-16 01:32:31 --> Config Class Initialized
DEBUG - 2011-09-16 01:32:31 --> Hooks Class Initialized
DEBUG - 2011-09-16 01:32:31 --> Utf8 Class Initialized
DEBUG - 2011-09-16 01:32:31 --> UTF-8 Support Enabled
DEBUG - 2011-09-16 01:32:31 --> URI Class Initialized
DEBUG - 2011-09-16 01:32:31 --> Router Class Initialized
ERROR - 2011-09-16 01:32:31 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-16 01:41:37 --> Config Class Initialized
DEBUG - 2011-09-16 01:41:37 --> Hooks Class Initialized
DEBUG - 2011-09-16 01:41:37 --> Utf8 Class Initialized
DEBUG - 2011-09-16 01:41:37 --> UTF-8 Support Enabled
DEBUG - 2011-09-16 01:41:37 --> URI Class Initialized
DEBUG - 2011-09-16 01:41:37 --> Router Class Initialized
DEBUG - 2011-09-16 01:41:37 --> Output Class Initialized
DEBUG - 2011-09-16 01:41:37 --> Input Class Initialized
DEBUG - 2011-09-16 01:41:37 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-16 01:41:37 --> Language Class Initialized
DEBUG - 2011-09-16 01:41:37 --> Loader Class Initialized
DEBUG - 2011-09-16 01:41:37 --> Controller Class Initialized
ERROR - 2011-09-16 01:41:37 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-16 01:41:37 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-16 01:41:37 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-16 01:41:37 --> Model Class Initialized
DEBUG - 2011-09-16 01:41:37 --> Model Class Initialized
DEBUG - 2011-09-16 01:41:37 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-16 01:41:37 --> Database Driver Class Initialized
DEBUG - 2011-09-16 01:41:37 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-16 01:41:37 --> Helper loaded: url_helper
DEBUG - 2011-09-16 01:41:37 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-16 01:41:37 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-16 01:41:37 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-16 01:41:37 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-16 01:41:37 --> Final output sent to browser
DEBUG - 2011-09-16 01:41:37 --> Total execution time: 0.1674
DEBUG - 2011-09-16 01:41:39 --> Config Class Initialized
DEBUG - 2011-09-16 01:41:39 --> Hooks Class Initialized
DEBUG - 2011-09-16 01:41:39 --> Utf8 Class Initialized
DEBUG - 2011-09-16 01:41:39 --> UTF-8 Support Enabled
DEBUG - 2011-09-16 01:41:39 --> URI Class Initialized
DEBUG - 2011-09-16 01:41:39 --> Router Class Initialized
DEBUG - 2011-09-16 01:41:39 --> Output Class Initialized
DEBUG - 2011-09-16 01:41:39 --> Input Class Initialized
DEBUG - 2011-09-16 01:41:39 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-16 01:41:39 --> Language Class Initialized
DEBUG - 2011-09-16 01:41:39 --> Loader Class Initialized
DEBUG - 2011-09-16 01:41:39 --> Controller Class Initialized
DEBUG - 2011-09-16 01:41:39 --> Model Class Initialized
DEBUG - 2011-09-16 01:41:39 --> Model Class Initialized
DEBUG - 2011-09-16 01:41:39 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-16 01:41:39 --> Database Driver Class Initialized
DEBUG - 2011-09-16 01:41:40 --> Final output sent to browser
DEBUG - 2011-09-16 01:41:40 --> Total execution time: 1.2574
DEBUG - 2011-09-16 01:41:44 --> Config Class Initialized
DEBUG - 2011-09-16 01:41:44 --> Hooks Class Initialized
DEBUG - 2011-09-16 01:41:44 --> Utf8 Class Initialized
DEBUG - 2011-09-16 01:41:44 --> UTF-8 Support Enabled
DEBUG - 2011-09-16 01:41:44 --> URI Class Initialized
DEBUG - 2011-09-16 01:41:44 --> Router Class Initialized
ERROR - 2011-09-16 01:41:44 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-16 01:41:51 --> Config Class Initialized
DEBUG - 2011-09-16 01:41:51 --> Hooks Class Initialized
DEBUG - 2011-09-16 01:41:51 --> Utf8 Class Initialized
DEBUG - 2011-09-16 01:41:51 --> UTF-8 Support Enabled
DEBUG - 2011-09-16 01:41:51 --> URI Class Initialized
DEBUG - 2011-09-16 01:41:51 --> Router Class Initialized
DEBUG - 2011-09-16 01:41:51 --> Output Class Initialized
DEBUG - 2011-09-16 01:41:51 --> Input Class Initialized
DEBUG - 2011-09-16 01:41:51 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-16 01:41:51 --> Language Class Initialized
DEBUG - 2011-09-16 01:41:51 --> Loader Class Initialized
DEBUG - 2011-09-16 01:41:51 --> Controller Class Initialized
ERROR - 2011-09-16 01:41:51 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-16 01:41:51 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-16 01:41:51 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-16 01:41:51 --> Model Class Initialized
DEBUG - 2011-09-16 01:41:51 --> Model Class Initialized
DEBUG - 2011-09-16 01:41:51 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-16 01:41:51 --> Database Driver Class Initialized
DEBUG - 2011-09-16 01:41:51 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-16 01:41:51 --> Helper loaded: url_helper
DEBUG - 2011-09-16 01:41:51 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-16 01:41:51 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-16 01:41:51 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-16 01:41:51 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-16 01:41:51 --> Final output sent to browser
DEBUG - 2011-09-16 01:41:51 --> Total execution time: 0.2898
DEBUG - 2011-09-16 01:41:52 --> Config Class Initialized
DEBUG - 2011-09-16 01:41:52 --> Hooks Class Initialized
DEBUG - 2011-09-16 01:41:52 --> Utf8 Class Initialized
DEBUG - 2011-09-16 01:41:52 --> UTF-8 Support Enabled
DEBUG - 2011-09-16 01:41:52 --> URI Class Initialized
DEBUG - 2011-09-16 01:41:52 --> Router Class Initialized
DEBUG - 2011-09-16 01:41:52 --> Output Class Initialized
DEBUG - 2011-09-16 01:41:52 --> Input Class Initialized
DEBUG - 2011-09-16 01:41:52 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-16 01:41:52 --> Language Class Initialized
DEBUG - 2011-09-16 01:41:52 --> Loader Class Initialized
DEBUG - 2011-09-16 01:41:52 --> Controller Class Initialized
DEBUG - 2011-09-16 01:41:52 --> Model Class Initialized
DEBUG - 2011-09-16 01:41:52 --> Model Class Initialized
DEBUG - 2011-09-16 01:41:52 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-16 01:41:52 --> Database Driver Class Initialized
DEBUG - 2011-09-16 01:41:53 --> Final output sent to browser
DEBUG - 2011-09-16 01:41:53 --> Total execution time: 1.0764
DEBUG - 2011-09-16 01:41:57 --> Config Class Initialized
DEBUG - 2011-09-16 01:41:57 --> Hooks Class Initialized
DEBUG - 2011-09-16 01:41:57 --> Utf8 Class Initialized
DEBUG - 2011-09-16 01:41:57 --> UTF-8 Support Enabled
DEBUG - 2011-09-16 01:41:57 --> URI Class Initialized
DEBUG - 2011-09-16 01:41:57 --> Router Class Initialized
ERROR - 2011-09-16 01:41:57 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-16 01:42:07 --> Config Class Initialized
DEBUG - 2011-09-16 01:42:07 --> Hooks Class Initialized
DEBUG - 2011-09-16 01:42:07 --> Utf8 Class Initialized
DEBUG - 2011-09-16 01:42:07 --> UTF-8 Support Enabled
DEBUG - 2011-09-16 01:42:07 --> URI Class Initialized
DEBUG - 2011-09-16 01:42:07 --> Router Class Initialized
DEBUG - 2011-09-16 01:42:07 --> Output Class Initialized
DEBUG - 2011-09-16 01:42:07 --> Input Class Initialized
DEBUG - 2011-09-16 01:42:07 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-16 01:42:07 --> Language Class Initialized
DEBUG - 2011-09-16 01:42:07 --> Loader Class Initialized
DEBUG - 2011-09-16 01:42:07 --> Controller Class Initialized
ERROR - 2011-09-16 01:42:07 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-16 01:42:07 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-16 01:42:07 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-16 01:42:07 --> Model Class Initialized
DEBUG - 2011-09-16 01:42:07 --> Model Class Initialized
DEBUG - 2011-09-16 01:42:07 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-16 01:42:07 --> Database Driver Class Initialized
DEBUG - 2011-09-16 01:42:07 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-16 01:42:07 --> Helper loaded: url_helper
DEBUG - 2011-09-16 01:42:07 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-16 01:42:07 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-16 01:42:07 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-16 01:42:07 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-16 01:42:07 --> Final output sent to browser
DEBUG - 2011-09-16 01:42:07 --> Total execution time: 0.0706
DEBUG - 2011-09-16 01:42:11 --> Config Class Initialized
DEBUG - 2011-09-16 01:42:11 --> Hooks Class Initialized
DEBUG - 2011-09-16 01:42:11 --> Utf8 Class Initialized
DEBUG - 2011-09-16 01:42:11 --> UTF-8 Support Enabled
DEBUG - 2011-09-16 01:42:11 --> URI Class Initialized
DEBUG - 2011-09-16 01:42:11 --> Router Class Initialized
DEBUG - 2011-09-16 01:42:11 --> Output Class Initialized
DEBUG - 2011-09-16 01:42:11 --> Input Class Initialized
DEBUG - 2011-09-16 01:42:11 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-16 01:42:11 --> Language Class Initialized
DEBUG - 2011-09-16 01:42:11 --> Loader Class Initialized
DEBUG - 2011-09-16 01:42:11 --> Controller Class Initialized
DEBUG - 2011-09-16 01:42:11 --> Model Class Initialized
DEBUG - 2011-09-16 01:42:11 --> Model Class Initialized
DEBUG - 2011-09-16 01:42:11 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-16 01:42:11 --> Database Driver Class Initialized
DEBUG - 2011-09-16 01:42:12 --> Final output sent to browser
DEBUG - 2011-09-16 01:42:12 --> Total execution time: 0.8781
DEBUG - 2011-09-16 01:42:17 --> Config Class Initialized
DEBUG - 2011-09-16 01:42:17 --> Hooks Class Initialized
DEBUG - 2011-09-16 01:42:17 --> Utf8 Class Initialized
DEBUG - 2011-09-16 01:42:17 --> UTF-8 Support Enabled
DEBUG - 2011-09-16 01:42:17 --> URI Class Initialized
DEBUG - 2011-09-16 01:42:17 --> Router Class Initialized
ERROR - 2011-09-16 01:42:17 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-16 01:58:27 --> Config Class Initialized
DEBUG - 2011-09-16 01:58:27 --> Hooks Class Initialized
DEBUG - 2011-09-16 01:58:27 --> Utf8 Class Initialized
DEBUG - 2011-09-16 01:58:27 --> UTF-8 Support Enabled
DEBUG - 2011-09-16 01:58:27 --> URI Class Initialized
DEBUG - 2011-09-16 01:58:27 --> Router Class Initialized
DEBUG - 2011-09-16 01:58:28 --> No URI present. Default controller set.
DEBUG - 2011-09-16 01:58:28 --> Output Class Initialized
DEBUG - 2011-09-16 01:58:28 --> Input Class Initialized
DEBUG - 2011-09-16 01:58:28 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-16 01:58:28 --> Language Class Initialized
DEBUG - 2011-09-16 01:58:28 --> Loader Class Initialized
DEBUG - 2011-09-16 01:58:28 --> Controller Class Initialized
DEBUG - 2011-09-16 01:58:28 --> File loaded: application/views/splash/main.php
DEBUG - 2011-09-16 01:58:28 --> Helper loaded: url_helper
DEBUG - 2011-09-16 01:58:28 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-16 01:58:28 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-16 01:58:28 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-16 01:58:28 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-16 01:58:28 --> Final output sent to browser
DEBUG - 2011-09-16 01:58:28 --> Total execution time: 0.2882
DEBUG - 2011-09-16 02:51:37 --> Config Class Initialized
DEBUG - 2011-09-16 02:51:37 --> Hooks Class Initialized
DEBUG - 2011-09-16 02:51:37 --> Utf8 Class Initialized
DEBUG - 2011-09-16 02:51:37 --> UTF-8 Support Enabled
DEBUG - 2011-09-16 02:51:37 --> URI Class Initialized
DEBUG - 2011-09-16 02:51:37 --> Router Class Initialized
ERROR - 2011-09-16 02:51:37 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-09-16 03:37:26 --> Config Class Initialized
DEBUG - 2011-09-16 03:37:26 --> Hooks Class Initialized
DEBUG - 2011-09-16 03:37:26 --> Utf8 Class Initialized
DEBUG - 2011-09-16 03:37:26 --> UTF-8 Support Enabled
DEBUG - 2011-09-16 03:37:26 --> URI Class Initialized
DEBUG - 2011-09-16 03:37:26 --> Router Class Initialized
ERROR - 2011-09-16 03:37:26 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-09-16 03:37:26 --> Config Class Initialized
DEBUG - 2011-09-16 03:37:26 --> Hooks Class Initialized
DEBUG - 2011-09-16 03:37:26 --> Utf8 Class Initialized
DEBUG - 2011-09-16 03:37:26 --> UTF-8 Support Enabled
DEBUG - 2011-09-16 03:37:26 --> URI Class Initialized
DEBUG - 2011-09-16 03:37:26 --> Router Class Initialized
DEBUG - 2011-09-16 03:37:26 --> Output Class Initialized
DEBUG - 2011-09-16 03:37:26 --> Input Class Initialized
DEBUG - 2011-09-16 03:37:26 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-16 03:37:26 --> Language Class Initialized
DEBUG - 2011-09-16 03:37:26 --> Loader Class Initialized
DEBUG - 2011-09-16 03:37:26 --> Controller Class Initialized
DEBUG - 2011-09-16 03:37:26 --> Model Class Initialized
DEBUG - 2011-09-16 03:37:27 --> Model Class Initialized
DEBUG - 2011-09-16 03:37:27 --> Model Class Initialized
DEBUG - 2011-09-16 03:37:27 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-16 03:37:27 --> Database Driver Class Initialized
DEBUG - 2011-09-16 03:37:28 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-16 03:37:28 --> Helper loaded: url_helper
DEBUG - 2011-09-16 03:37:28 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-16 03:37:28 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-16 03:37:28 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-16 03:37:28 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-16 03:37:28 --> Final output sent to browser
DEBUG - 2011-09-16 03:37:28 --> Total execution time: 2.0209
DEBUG - 2011-09-16 04:48:34 --> Config Class Initialized
DEBUG - 2011-09-16 04:48:34 --> Hooks Class Initialized
DEBUG - 2011-09-16 04:48:34 --> Utf8 Class Initialized
DEBUG - 2011-09-16 04:48:34 --> UTF-8 Support Enabled
DEBUG - 2011-09-16 04:48:34 --> URI Class Initialized
DEBUG - 2011-09-16 04:48:34 --> Router Class Initialized
DEBUG - 2011-09-16 04:48:34 --> Output Class Initialized
DEBUG - 2011-09-16 04:48:34 --> Input Class Initialized
DEBUG - 2011-09-16 04:48:34 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-16 04:48:34 --> Language Class Initialized
DEBUG - 2011-09-16 04:48:34 --> Loader Class Initialized
DEBUG - 2011-09-16 04:48:34 --> Controller Class Initialized
ERROR - 2011-09-16 04:48:34 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-16 04:48:34 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-16 04:48:34 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-16 04:48:34 --> Model Class Initialized
DEBUG - 2011-09-16 04:48:34 --> Model Class Initialized
DEBUG - 2011-09-16 04:48:34 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-16 04:48:34 --> Database Driver Class Initialized
DEBUG - 2011-09-16 04:48:35 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-16 04:48:35 --> Helper loaded: url_helper
DEBUG - 2011-09-16 04:48:35 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-16 04:48:35 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-16 04:48:35 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-16 04:48:35 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-16 04:48:35 --> Final output sent to browser
DEBUG - 2011-09-16 04:48:35 --> Total execution time: 0.6169
DEBUG - 2011-09-16 04:48:37 --> Config Class Initialized
DEBUG - 2011-09-16 04:48:37 --> Hooks Class Initialized
DEBUG - 2011-09-16 04:48:37 --> Utf8 Class Initialized
DEBUG - 2011-09-16 04:48:37 --> UTF-8 Support Enabled
DEBUG - 2011-09-16 04:48:37 --> URI Class Initialized
DEBUG - 2011-09-16 04:48:37 --> Router Class Initialized
DEBUG - 2011-09-16 04:48:37 --> Output Class Initialized
DEBUG - 2011-09-16 04:48:37 --> Input Class Initialized
DEBUG - 2011-09-16 04:48:37 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-16 04:48:37 --> Language Class Initialized
DEBUG - 2011-09-16 04:48:37 --> Loader Class Initialized
DEBUG - 2011-09-16 04:48:37 --> Controller Class Initialized
DEBUG - 2011-09-16 04:48:37 --> Model Class Initialized
DEBUG - 2011-09-16 04:48:37 --> Model Class Initialized
DEBUG - 2011-09-16 04:48:37 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-16 04:48:37 --> Database Driver Class Initialized
DEBUG - 2011-09-16 04:48:38 --> Final output sent to browser
DEBUG - 2011-09-16 04:48:38 --> Total execution time: 0.8450
DEBUG - 2011-09-16 04:48:41 --> Config Class Initialized
DEBUG - 2011-09-16 04:48:41 --> Hooks Class Initialized
DEBUG - 2011-09-16 04:48:41 --> Utf8 Class Initialized
DEBUG - 2011-09-16 04:48:41 --> UTF-8 Support Enabled
DEBUG - 2011-09-16 04:48:41 --> URI Class Initialized
DEBUG - 2011-09-16 04:48:41 --> Router Class Initialized
ERROR - 2011-09-16 04:48:41 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-16 04:59:49 --> Config Class Initialized
DEBUG - 2011-09-16 04:59:49 --> Hooks Class Initialized
DEBUG - 2011-09-16 04:59:49 --> Utf8 Class Initialized
DEBUG - 2011-09-16 04:59:49 --> UTF-8 Support Enabled
DEBUG - 2011-09-16 04:59:49 --> URI Class Initialized
DEBUG - 2011-09-16 04:59:49 --> Router Class Initialized
DEBUG - 2011-09-16 04:59:49 --> Output Class Initialized
DEBUG - 2011-09-16 04:59:49 --> Input Class Initialized
DEBUG - 2011-09-16 04:59:49 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-16 04:59:49 --> Language Class Initialized
DEBUG - 2011-09-16 04:59:49 --> Loader Class Initialized
DEBUG - 2011-09-16 04:59:49 --> Controller Class Initialized
DEBUG - 2011-09-16 04:59:49 --> Model Class Initialized
DEBUG - 2011-09-16 04:59:49 --> Model Class Initialized
DEBUG - 2011-09-16 04:59:49 --> Model Class Initialized
DEBUG - 2011-09-16 04:59:49 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-16 04:59:49 --> Database Driver Class Initialized
DEBUG - 2011-09-16 04:59:50 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-16 04:59:50 --> Helper loaded: url_helper
DEBUG - 2011-09-16 04:59:50 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-16 04:59:50 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-16 04:59:50 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-16 04:59:50 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-16 04:59:50 --> Final output sent to browser
DEBUG - 2011-09-16 04:59:50 --> Total execution time: 0.7941
DEBUG - 2011-09-16 04:59:51 --> Config Class Initialized
DEBUG - 2011-09-16 04:59:51 --> Hooks Class Initialized
DEBUG - 2011-09-16 04:59:51 --> Utf8 Class Initialized
DEBUG - 2011-09-16 04:59:51 --> UTF-8 Support Enabled
DEBUG - 2011-09-16 04:59:51 --> URI Class Initialized
DEBUG - 2011-09-16 04:59:51 --> Router Class Initialized
ERROR - 2011-09-16 04:59:51 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-16 05:06:24 --> Config Class Initialized
DEBUG - 2011-09-16 05:06:24 --> Hooks Class Initialized
DEBUG - 2011-09-16 05:06:24 --> Utf8 Class Initialized
DEBUG - 2011-09-16 05:06:24 --> UTF-8 Support Enabled
DEBUG - 2011-09-16 05:06:24 --> URI Class Initialized
DEBUG - 2011-09-16 05:06:24 --> Router Class Initialized
DEBUG - 2011-09-16 05:06:24 --> Output Class Initialized
DEBUG - 2011-09-16 05:06:24 --> Input Class Initialized
DEBUG - 2011-09-16 05:06:24 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-16 05:06:24 --> Language Class Initialized
DEBUG - 2011-09-16 05:06:24 --> Loader Class Initialized
DEBUG - 2011-09-16 05:06:24 --> Controller Class Initialized
DEBUG - 2011-09-16 05:06:24 --> Model Class Initialized
DEBUG - 2011-09-16 05:06:24 --> Model Class Initialized
DEBUG - 2011-09-16 05:06:24 --> Model Class Initialized
DEBUG - 2011-09-16 05:06:24 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-16 05:06:24 --> Database Driver Class Initialized
DEBUG - 2011-09-16 05:06:24 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-16 05:06:24 --> Helper loaded: url_helper
DEBUG - 2011-09-16 05:06:24 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-16 05:06:24 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-16 05:06:24 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-16 05:06:24 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-16 05:06:24 --> Final output sent to browser
DEBUG - 2011-09-16 05:06:24 --> Total execution time: 0.0671
DEBUG - 2011-09-16 05:06:26 --> Config Class Initialized
DEBUG - 2011-09-16 05:06:26 --> Hooks Class Initialized
DEBUG - 2011-09-16 05:06:26 --> Utf8 Class Initialized
DEBUG - 2011-09-16 05:06:26 --> UTF-8 Support Enabled
DEBUG - 2011-09-16 05:06:26 --> URI Class Initialized
DEBUG - 2011-09-16 05:06:26 --> Router Class Initialized
DEBUG - 2011-09-16 05:06:26 --> Output Class Initialized
DEBUG - 2011-09-16 05:06:26 --> Input Class Initialized
DEBUG - 2011-09-16 05:06:26 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-16 05:06:26 --> Language Class Initialized
DEBUG - 2011-09-16 05:06:26 --> Loader Class Initialized
DEBUG - 2011-09-16 05:06:26 --> Controller Class Initialized
DEBUG - 2011-09-16 05:06:26 --> Model Class Initialized
DEBUG - 2011-09-16 05:06:26 --> Model Class Initialized
DEBUG - 2011-09-16 05:06:26 --> Model Class Initialized
DEBUG - 2011-09-16 05:06:26 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-16 05:06:26 --> Database Driver Class Initialized
DEBUG - 2011-09-16 05:06:26 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-16 05:06:26 --> Helper loaded: url_helper
DEBUG - 2011-09-16 05:06:26 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-16 05:06:26 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-16 05:06:26 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-16 05:06:26 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-16 05:06:26 --> Final output sent to browser
DEBUG - 2011-09-16 05:06:26 --> Total execution time: 0.0549
DEBUG - 2011-09-16 05:07:12 --> Config Class Initialized
DEBUG - 2011-09-16 05:07:12 --> Hooks Class Initialized
DEBUG - 2011-09-16 05:07:12 --> Utf8 Class Initialized
DEBUG - 2011-09-16 05:07:12 --> UTF-8 Support Enabled
DEBUG - 2011-09-16 05:07:12 --> URI Class Initialized
DEBUG - 2011-09-16 05:07:12 --> Router Class Initialized
DEBUG - 2011-09-16 05:07:12 --> Output Class Initialized
DEBUG - 2011-09-16 05:07:12 --> Input Class Initialized
DEBUG - 2011-09-16 05:07:12 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-16 05:07:12 --> Language Class Initialized
DEBUG - 2011-09-16 05:07:12 --> Loader Class Initialized
DEBUG - 2011-09-16 05:07:12 --> Controller Class Initialized
DEBUG - 2011-09-16 05:07:12 --> Model Class Initialized
DEBUG - 2011-09-16 05:07:12 --> Model Class Initialized
DEBUG - 2011-09-16 05:07:12 --> Model Class Initialized
DEBUG - 2011-09-16 05:07:12 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-16 05:07:12 --> Database Driver Class Initialized
DEBUG - 2011-09-16 05:07:13 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-16 05:07:13 --> Helper loaded: url_helper
DEBUG - 2011-09-16 05:07:13 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-16 05:07:13 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-16 05:07:13 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-16 05:07:13 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-16 05:07:13 --> Final output sent to browser
DEBUG - 2011-09-16 05:07:13 --> Total execution time: 1.0744
DEBUG - 2011-09-16 05:07:15 --> Config Class Initialized
DEBUG - 2011-09-16 05:07:15 --> Hooks Class Initialized
DEBUG - 2011-09-16 05:07:15 --> Utf8 Class Initialized
DEBUG - 2011-09-16 05:07:15 --> UTF-8 Support Enabled
DEBUG - 2011-09-16 05:07:15 --> URI Class Initialized
DEBUG - 2011-09-16 05:07:15 --> Router Class Initialized
DEBUG - 2011-09-16 05:07:15 --> Output Class Initialized
DEBUG - 2011-09-16 05:07:15 --> Input Class Initialized
DEBUG - 2011-09-16 05:07:15 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-16 05:07:15 --> Language Class Initialized
DEBUG - 2011-09-16 05:07:15 --> Loader Class Initialized
DEBUG - 2011-09-16 05:07:15 --> Controller Class Initialized
DEBUG - 2011-09-16 05:07:15 --> Model Class Initialized
DEBUG - 2011-09-16 05:07:15 --> Model Class Initialized
DEBUG - 2011-09-16 05:07:15 --> Model Class Initialized
DEBUG - 2011-09-16 05:07:15 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-16 05:07:15 --> Database Driver Class Initialized
DEBUG - 2011-09-16 05:07:15 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-16 05:07:15 --> Helper loaded: url_helper
DEBUG - 2011-09-16 05:07:15 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-16 05:07:15 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-16 05:07:15 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-16 05:07:15 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-16 05:07:15 --> Final output sent to browser
DEBUG - 2011-09-16 05:07:15 --> Total execution time: 0.1517
DEBUG - 2011-09-16 05:07:27 --> Config Class Initialized
DEBUG - 2011-09-16 05:07:27 --> Hooks Class Initialized
DEBUG - 2011-09-16 05:07:27 --> Utf8 Class Initialized
DEBUG - 2011-09-16 05:07:27 --> UTF-8 Support Enabled
DEBUG - 2011-09-16 05:07:27 --> URI Class Initialized
DEBUG - 2011-09-16 05:07:27 --> Router Class Initialized
DEBUG - 2011-09-16 05:07:27 --> Output Class Initialized
DEBUG - 2011-09-16 05:07:27 --> Input Class Initialized
DEBUG - 2011-09-16 05:07:27 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-16 05:07:27 --> Language Class Initialized
DEBUG - 2011-09-16 05:07:27 --> Loader Class Initialized
DEBUG - 2011-09-16 05:07:27 --> Controller Class Initialized
DEBUG - 2011-09-16 05:07:27 --> Model Class Initialized
DEBUG - 2011-09-16 05:07:27 --> Model Class Initialized
DEBUG - 2011-09-16 05:07:27 --> Model Class Initialized
DEBUG - 2011-09-16 05:07:27 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-16 05:07:27 --> Database Driver Class Initialized
DEBUG - 2011-09-16 05:07:28 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-16 05:07:28 --> Helper loaded: url_helper
DEBUG - 2011-09-16 05:07:28 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-16 05:07:28 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-16 05:07:28 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-16 05:07:28 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-16 05:07:28 --> Final output sent to browser
DEBUG - 2011-09-16 05:07:28 --> Total execution time: 0.7709
DEBUG - 2011-09-16 05:07:29 --> Config Class Initialized
DEBUG - 2011-09-16 05:07:29 --> Hooks Class Initialized
DEBUG - 2011-09-16 05:07:29 --> Utf8 Class Initialized
DEBUG - 2011-09-16 05:07:29 --> UTF-8 Support Enabled
DEBUG - 2011-09-16 05:07:29 --> URI Class Initialized
DEBUG - 2011-09-16 05:07:29 --> Router Class Initialized
DEBUG - 2011-09-16 05:07:29 --> Output Class Initialized
DEBUG - 2011-09-16 05:07:29 --> Input Class Initialized
DEBUG - 2011-09-16 05:07:29 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-16 05:07:29 --> Language Class Initialized
DEBUG - 2011-09-16 05:07:29 --> Loader Class Initialized
DEBUG - 2011-09-16 05:07:29 --> Controller Class Initialized
DEBUG - 2011-09-16 05:07:29 --> Model Class Initialized
DEBUG - 2011-09-16 05:07:29 --> Model Class Initialized
DEBUG - 2011-09-16 05:07:29 --> Model Class Initialized
DEBUG - 2011-09-16 05:07:29 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-16 05:07:29 --> Database Driver Class Initialized
DEBUG - 2011-09-16 05:07:29 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-16 05:07:29 --> Helper loaded: url_helper
DEBUG - 2011-09-16 05:07:29 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-16 05:07:29 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-16 05:07:29 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-16 05:07:29 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-16 05:07:29 --> Final output sent to browser
DEBUG - 2011-09-16 05:07:29 --> Total execution time: 0.1195
DEBUG - 2011-09-16 05:07:35 --> Config Class Initialized
DEBUG - 2011-09-16 05:07:35 --> Hooks Class Initialized
DEBUG - 2011-09-16 05:07:35 --> Utf8 Class Initialized
DEBUG - 2011-09-16 05:07:35 --> UTF-8 Support Enabled
DEBUG - 2011-09-16 05:07:35 --> URI Class Initialized
DEBUG - 2011-09-16 05:07:35 --> Router Class Initialized
DEBUG - 2011-09-16 05:07:35 --> Output Class Initialized
DEBUG - 2011-09-16 05:07:35 --> Input Class Initialized
DEBUG - 2011-09-16 05:07:35 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-16 05:07:35 --> Language Class Initialized
DEBUG - 2011-09-16 05:07:35 --> Loader Class Initialized
DEBUG - 2011-09-16 05:07:35 --> Controller Class Initialized
DEBUG - 2011-09-16 05:07:35 --> Model Class Initialized
DEBUG - 2011-09-16 05:07:35 --> Model Class Initialized
DEBUG - 2011-09-16 05:07:35 --> Model Class Initialized
DEBUG - 2011-09-16 05:07:35 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-16 05:07:35 --> Database Driver Class Initialized
DEBUG - 2011-09-16 05:07:40 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-16 05:07:40 --> Helper loaded: url_helper
DEBUG - 2011-09-16 05:07:40 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-16 05:07:40 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-16 05:07:40 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-16 05:07:40 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-16 05:07:40 --> Final output sent to browser
DEBUG - 2011-09-16 05:07:40 --> Total execution time: 4.7639
DEBUG - 2011-09-16 05:07:41 --> Config Class Initialized
DEBUG - 2011-09-16 05:07:41 --> Hooks Class Initialized
DEBUG - 2011-09-16 05:07:41 --> Utf8 Class Initialized
DEBUG - 2011-09-16 05:07:41 --> UTF-8 Support Enabled
DEBUG - 2011-09-16 05:07:41 --> URI Class Initialized
DEBUG - 2011-09-16 05:07:41 --> Router Class Initialized
DEBUG - 2011-09-16 05:07:41 --> Output Class Initialized
DEBUG - 2011-09-16 05:07:41 --> Input Class Initialized
DEBUG - 2011-09-16 05:07:41 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-16 05:07:41 --> Language Class Initialized
DEBUG - 2011-09-16 05:07:41 --> Loader Class Initialized
DEBUG - 2011-09-16 05:07:41 --> Controller Class Initialized
DEBUG - 2011-09-16 05:07:41 --> Model Class Initialized
DEBUG - 2011-09-16 05:07:41 --> Model Class Initialized
DEBUG - 2011-09-16 05:07:41 --> Model Class Initialized
DEBUG - 2011-09-16 05:07:41 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-16 05:07:41 --> Database Driver Class Initialized
DEBUG - 2011-09-16 05:07:41 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-16 05:07:41 --> Helper loaded: url_helper
DEBUG - 2011-09-16 05:07:41 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-16 05:07:41 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-16 05:07:41 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-16 05:07:41 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-16 05:07:41 --> Final output sent to browser
DEBUG - 2011-09-16 05:07:41 --> Total execution time: 0.1182
DEBUG - 2011-09-16 05:07:55 --> Config Class Initialized
DEBUG - 2011-09-16 05:07:55 --> Hooks Class Initialized
DEBUG - 2011-09-16 05:07:55 --> Utf8 Class Initialized
DEBUG - 2011-09-16 05:07:55 --> UTF-8 Support Enabled
DEBUG - 2011-09-16 05:07:55 --> URI Class Initialized
DEBUG - 2011-09-16 05:07:55 --> Router Class Initialized
DEBUG - 2011-09-16 05:07:55 --> Output Class Initialized
DEBUG - 2011-09-16 05:07:55 --> Input Class Initialized
DEBUG - 2011-09-16 05:07:55 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-16 05:07:55 --> Language Class Initialized
DEBUG - 2011-09-16 05:07:55 --> Loader Class Initialized
DEBUG - 2011-09-16 05:07:55 --> Controller Class Initialized
DEBUG - 2011-09-16 05:07:55 --> Model Class Initialized
DEBUG - 2011-09-16 05:07:55 --> Model Class Initialized
DEBUG - 2011-09-16 05:07:55 --> Model Class Initialized
DEBUG - 2011-09-16 05:07:55 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-16 05:07:55 --> Database Driver Class Initialized
DEBUG - 2011-09-16 05:07:56 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-16 05:07:56 --> Helper loaded: url_helper
DEBUG - 2011-09-16 05:07:56 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-16 05:07:56 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-16 05:07:56 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-16 05:07:56 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-16 05:07:56 --> Final output sent to browser
DEBUG - 2011-09-16 05:07:56 --> Total execution time: 0.8926
DEBUG - 2011-09-16 05:07:58 --> Config Class Initialized
DEBUG - 2011-09-16 05:07:58 --> Hooks Class Initialized
DEBUG - 2011-09-16 05:07:58 --> Utf8 Class Initialized
DEBUG - 2011-09-16 05:07:58 --> UTF-8 Support Enabled
DEBUG - 2011-09-16 05:07:58 --> URI Class Initialized
DEBUG - 2011-09-16 05:07:58 --> Router Class Initialized
DEBUG - 2011-09-16 05:07:58 --> Output Class Initialized
DEBUG - 2011-09-16 05:07:58 --> Input Class Initialized
DEBUG - 2011-09-16 05:07:58 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-16 05:07:58 --> Language Class Initialized
DEBUG - 2011-09-16 05:07:58 --> Loader Class Initialized
DEBUG - 2011-09-16 05:07:58 --> Controller Class Initialized
DEBUG - 2011-09-16 05:07:58 --> Model Class Initialized
DEBUG - 2011-09-16 05:07:58 --> Model Class Initialized
DEBUG - 2011-09-16 05:07:58 --> Model Class Initialized
DEBUG - 2011-09-16 05:07:58 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-16 05:07:58 --> Database Driver Class Initialized
DEBUG - 2011-09-16 05:07:59 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-16 05:07:59 --> Helper loaded: url_helper
DEBUG - 2011-09-16 05:07:59 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-16 05:07:59 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-16 05:07:59 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-16 05:07:59 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-16 05:07:59 --> Final output sent to browser
DEBUG - 2011-09-16 05:07:59 --> Total execution time: 0.0520
DEBUG - 2011-09-16 05:08:10 --> Config Class Initialized
DEBUG - 2011-09-16 05:08:10 --> Hooks Class Initialized
DEBUG - 2011-09-16 05:08:10 --> Utf8 Class Initialized
DEBUG - 2011-09-16 05:08:10 --> UTF-8 Support Enabled
DEBUG - 2011-09-16 05:08:10 --> URI Class Initialized
DEBUG - 2011-09-16 05:08:10 --> Router Class Initialized
DEBUG - 2011-09-16 05:08:10 --> Output Class Initialized
DEBUG - 2011-09-16 05:08:10 --> Input Class Initialized
DEBUG - 2011-09-16 05:08:10 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-16 05:08:10 --> Language Class Initialized
DEBUG - 2011-09-16 05:08:10 --> Loader Class Initialized
DEBUG - 2011-09-16 05:08:10 --> Controller Class Initialized
DEBUG - 2011-09-16 05:08:10 --> Model Class Initialized
DEBUG - 2011-09-16 05:08:10 --> Model Class Initialized
DEBUG - 2011-09-16 05:08:10 --> Model Class Initialized
DEBUG - 2011-09-16 05:08:10 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-16 05:08:10 --> Database Driver Class Initialized
DEBUG - 2011-09-16 05:08:10 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-16 05:08:10 --> Helper loaded: url_helper
DEBUG - 2011-09-16 05:08:10 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-16 05:08:10 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-16 05:08:10 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-16 05:08:10 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-16 05:08:10 --> Final output sent to browser
DEBUG - 2011-09-16 05:08:10 --> Total execution time: 0.5301
DEBUG - 2011-09-16 05:08:12 --> Config Class Initialized
DEBUG - 2011-09-16 05:08:12 --> Hooks Class Initialized
DEBUG - 2011-09-16 05:08:12 --> Utf8 Class Initialized
DEBUG - 2011-09-16 05:08:12 --> UTF-8 Support Enabled
DEBUG - 2011-09-16 05:08:12 --> URI Class Initialized
DEBUG - 2011-09-16 05:08:12 --> Router Class Initialized
DEBUG - 2011-09-16 05:08:12 --> Output Class Initialized
DEBUG - 2011-09-16 05:08:12 --> Input Class Initialized
DEBUG - 2011-09-16 05:08:12 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-16 05:08:12 --> Language Class Initialized
DEBUG - 2011-09-16 05:08:12 --> Loader Class Initialized
DEBUG - 2011-09-16 05:08:12 --> Controller Class Initialized
DEBUG - 2011-09-16 05:08:12 --> Model Class Initialized
DEBUG - 2011-09-16 05:08:12 --> Model Class Initialized
DEBUG - 2011-09-16 05:08:12 --> Model Class Initialized
DEBUG - 2011-09-16 05:08:12 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-16 05:08:12 --> Database Driver Class Initialized
DEBUG - 2011-09-16 05:08:12 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-16 05:08:12 --> Helper loaded: url_helper
DEBUG - 2011-09-16 05:08:12 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-16 05:08:12 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-16 05:08:12 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-16 05:08:12 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-16 05:08:12 --> Final output sent to browser
DEBUG - 2011-09-16 05:08:12 --> Total execution time: 0.1269
DEBUG - 2011-09-16 05:08:24 --> Config Class Initialized
DEBUG - 2011-09-16 05:08:24 --> Hooks Class Initialized
DEBUG - 2011-09-16 05:08:24 --> Utf8 Class Initialized
DEBUG - 2011-09-16 05:08:24 --> UTF-8 Support Enabled
DEBUG - 2011-09-16 05:08:24 --> URI Class Initialized
DEBUG - 2011-09-16 05:08:24 --> Router Class Initialized
DEBUG - 2011-09-16 05:08:24 --> Output Class Initialized
DEBUG - 2011-09-16 05:08:24 --> Input Class Initialized
DEBUG - 2011-09-16 05:08:24 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-16 05:08:24 --> Language Class Initialized
DEBUG - 2011-09-16 05:08:24 --> Loader Class Initialized
DEBUG - 2011-09-16 05:08:24 --> Controller Class Initialized
DEBUG - 2011-09-16 05:08:24 --> Model Class Initialized
DEBUG - 2011-09-16 05:08:24 --> Model Class Initialized
DEBUG - 2011-09-16 05:08:24 --> Model Class Initialized
DEBUG - 2011-09-16 05:08:24 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-16 05:08:24 --> Database Driver Class Initialized
DEBUG - 2011-09-16 05:08:25 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-16 05:08:25 --> Helper loaded: url_helper
DEBUG - 2011-09-16 05:08:25 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-16 05:08:25 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-16 05:08:25 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-16 05:08:25 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-16 05:08:25 --> Final output sent to browser
DEBUG - 2011-09-16 05:08:25 --> Total execution time: 0.4816
DEBUG - 2011-09-16 05:08:29 --> Config Class Initialized
DEBUG - 2011-09-16 05:08:29 --> Hooks Class Initialized
DEBUG - 2011-09-16 05:08:29 --> Utf8 Class Initialized
DEBUG - 2011-09-16 05:08:29 --> UTF-8 Support Enabled
DEBUG - 2011-09-16 05:08:29 --> URI Class Initialized
DEBUG - 2011-09-16 05:08:29 --> Router Class Initialized
DEBUG - 2011-09-16 05:08:29 --> Output Class Initialized
DEBUG - 2011-09-16 05:08:29 --> Input Class Initialized
DEBUG - 2011-09-16 05:08:29 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-16 05:08:29 --> Language Class Initialized
DEBUG - 2011-09-16 05:08:29 --> Loader Class Initialized
DEBUG - 2011-09-16 05:08:29 --> Controller Class Initialized
DEBUG - 2011-09-16 05:08:29 --> Model Class Initialized
DEBUG - 2011-09-16 05:08:29 --> Model Class Initialized
DEBUG - 2011-09-16 05:08:29 --> Model Class Initialized
DEBUG - 2011-09-16 05:08:29 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-16 05:08:29 --> Database Driver Class Initialized
DEBUG - 2011-09-16 05:08:29 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-16 05:08:29 --> Helper loaded: url_helper
DEBUG - 2011-09-16 05:08:29 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-16 05:08:29 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-16 05:08:29 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-16 05:08:29 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-16 05:08:29 --> Final output sent to browser
DEBUG - 2011-09-16 05:08:29 --> Total execution time: 0.2299
DEBUG - 2011-09-16 05:09:11 --> Config Class Initialized
DEBUG - 2011-09-16 05:09:11 --> Hooks Class Initialized
DEBUG - 2011-09-16 05:09:11 --> Utf8 Class Initialized
DEBUG - 2011-09-16 05:09:11 --> UTF-8 Support Enabled
DEBUG - 2011-09-16 05:09:11 --> URI Class Initialized
DEBUG - 2011-09-16 05:09:11 --> Router Class Initialized
DEBUG - 2011-09-16 05:09:11 --> Output Class Initialized
DEBUG - 2011-09-16 05:09:11 --> Input Class Initialized
DEBUG - 2011-09-16 05:09:11 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-16 05:09:11 --> Language Class Initialized
DEBUG - 2011-09-16 05:09:11 --> Loader Class Initialized
DEBUG - 2011-09-16 05:09:11 --> Controller Class Initialized
DEBUG - 2011-09-16 05:09:11 --> Model Class Initialized
DEBUG - 2011-09-16 05:09:11 --> Model Class Initialized
DEBUG - 2011-09-16 05:09:11 --> Model Class Initialized
DEBUG - 2011-09-16 05:09:11 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-16 05:09:11 --> Database Driver Class Initialized
DEBUG - 2011-09-16 05:09:13 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-16 05:09:13 --> Helper loaded: url_helper
DEBUG - 2011-09-16 05:09:13 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-16 05:09:13 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-16 05:09:13 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-16 05:09:13 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-16 05:09:13 --> Final output sent to browser
DEBUG - 2011-09-16 05:09:13 --> Total execution time: 1.3944
DEBUG - 2011-09-16 05:09:16 --> Config Class Initialized
DEBUG - 2011-09-16 05:09:16 --> Hooks Class Initialized
DEBUG - 2011-09-16 05:09:16 --> Utf8 Class Initialized
DEBUG - 2011-09-16 05:09:16 --> UTF-8 Support Enabled
DEBUG - 2011-09-16 05:09:16 --> URI Class Initialized
DEBUG - 2011-09-16 05:09:16 --> Router Class Initialized
DEBUG - 2011-09-16 05:09:16 --> Output Class Initialized
DEBUG - 2011-09-16 05:09:16 --> Input Class Initialized
DEBUG - 2011-09-16 05:09:16 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-16 05:09:16 --> Language Class Initialized
DEBUG - 2011-09-16 05:09:16 --> Loader Class Initialized
DEBUG - 2011-09-16 05:09:16 --> Controller Class Initialized
DEBUG - 2011-09-16 05:09:16 --> Model Class Initialized
DEBUG - 2011-09-16 05:09:16 --> Model Class Initialized
DEBUG - 2011-09-16 05:09:16 --> Model Class Initialized
DEBUG - 2011-09-16 05:09:16 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-16 05:09:16 --> Database Driver Class Initialized
DEBUG - 2011-09-16 05:09:17 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-16 05:09:17 --> Helper loaded: url_helper
DEBUG - 2011-09-16 05:09:17 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-16 05:09:17 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-16 05:09:17 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-16 05:09:17 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-16 05:09:17 --> Final output sent to browser
DEBUG - 2011-09-16 05:09:17 --> Total execution time: 0.8254
DEBUG - 2011-09-16 05:09:35 --> Config Class Initialized
DEBUG - 2011-09-16 05:09:35 --> Hooks Class Initialized
DEBUG - 2011-09-16 05:09:35 --> Utf8 Class Initialized
DEBUG - 2011-09-16 05:09:35 --> UTF-8 Support Enabled
DEBUG - 2011-09-16 05:09:35 --> URI Class Initialized
DEBUG - 2011-09-16 05:09:35 --> Router Class Initialized
DEBUG - 2011-09-16 05:09:35 --> Output Class Initialized
DEBUG - 2011-09-16 05:09:35 --> Input Class Initialized
DEBUG - 2011-09-16 05:09:35 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-16 05:09:35 --> Language Class Initialized
DEBUG - 2011-09-16 05:09:35 --> Loader Class Initialized
DEBUG - 2011-09-16 05:09:35 --> Controller Class Initialized
DEBUG - 2011-09-16 05:09:35 --> Model Class Initialized
DEBUG - 2011-09-16 05:09:35 --> Model Class Initialized
DEBUG - 2011-09-16 05:09:35 --> Model Class Initialized
DEBUG - 2011-09-16 05:09:35 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-16 05:09:35 --> Database Driver Class Initialized
DEBUG - 2011-09-16 05:09:37 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-16 05:09:37 --> Helper loaded: url_helper
DEBUG - 2011-09-16 05:09:37 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-16 05:09:37 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-16 05:09:37 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-16 05:09:37 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-16 05:09:37 --> Final output sent to browser
DEBUG - 2011-09-16 05:09:37 --> Total execution time: 1.2885
DEBUG - 2011-09-16 05:09:40 --> Config Class Initialized
DEBUG - 2011-09-16 05:09:40 --> Hooks Class Initialized
DEBUG - 2011-09-16 05:09:40 --> Utf8 Class Initialized
DEBUG - 2011-09-16 05:09:40 --> UTF-8 Support Enabled
DEBUG - 2011-09-16 05:09:40 --> URI Class Initialized
DEBUG - 2011-09-16 05:09:40 --> Router Class Initialized
DEBUG - 2011-09-16 05:09:40 --> Output Class Initialized
DEBUG - 2011-09-16 05:09:40 --> Input Class Initialized
DEBUG - 2011-09-16 05:09:40 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-16 05:09:40 --> Language Class Initialized
DEBUG - 2011-09-16 05:09:40 --> Loader Class Initialized
DEBUG - 2011-09-16 05:09:40 --> Controller Class Initialized
DEBUG - 2011-09-16 05:09:40 --> Model Class Initialized
DEBUG - 2011-09-16 05:09:40 --> Model Class Initialized
DEBUG - 2011-09-16 05:09:40 --> Model Class Initialized
DEBUG - 2011-09-16 05:09:40 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-16 05:09:40 --> Database Driver Class Initialized
DEBUG - 2011-09-16 05:09:40 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-16 05:09:40 --> Helper loaded: url_helper
DEBUG - 2011-09-16 05:09:40 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-16 05:09:40 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-16 05:09:40 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-16 05:09:40 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-16 05:09:40 --> Final output sent to browser
DEBUG - 2011-09-16 05:09:40 --> Total execution time: 0.0483
DEBUG - 2011-09-16 05:09:54 --> Config Class Initialized
DEBUG - 2011-09-16 05:09:54 --> Hooks Class Initialized
DEBUG - 2011-09-16 05:09:54 --> Utf8 Class Initialized
DEBUG - 2011-09-16 05:09:54 --> UTF-8 Support Enabled
DEBUG - 2011-09-16 05:09:54 --> URI Class Initialized
DEBUG - 2011-09-16 05:09:54 --> Router Class Initialized
DEBUG - 2011-09-16 05:09:54 --> Output Class Initialized
DEBUG - 2011-09-16 05:09:54 --> Input Class Initialized
DEBUG - 2011-09-16 05:09:54 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-16 05:09:54 --> Language Class Initialized
DEBUG - 2011-09-16 05:09:54 --> Loader Class Initialized
DEBUG - 2011-09-16 05:09:54 --> Controller Class Initialized
DEBUG - 2011-09-16 05:09:54 --> Model Class Initialized
DEBUG - 2011-09-16 05:09:54 --> Model Class Initialized
DEBUG - 2011-09-16 05:09:54 --> Model Class Initialized
DEBUG - 2011-09-16 05:09:54 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-16 05:09:54 --> Database Driver Class Initialized
DEBUG - 2011-09-16 05:09:57 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-16 05:09:57 --> Helper loaded: url_helper
DEBUG - 2011-09-16 05:09:57 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-16 05:09:57 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-16 05:09:57 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-16 05:09:57 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-16 05:09:57 --> Final output sent to browser
DEBUG - 2011-09-16 05:09:57 --> Total execution time: 2.6499
DEBUG - 2011-09-16 05:09:57 --> Config Class Initialized
DEBUG - 2011-09-16 05:09:58 --> Hooks Class Initialized
DEBUG - 2011-09-16 05:09:58 --> Utf8 Class Initialized
DEBUG - 2011-09-16 05:09:58 --> UTF-8 Support Enabled
DEBUG - 2011-09-16 05:09:58 --> URI Class Initialized
DEBUG - 2011-09-16 05:09:58 --> Router Class Initialized
DEBUG - 2011-09-16 05:09:58 --> Output Class Initialized
DEBUG - 2011-09-16 05:09:58 --> Input Class Initialized
DEBUG - 2011-09-16 05:09:58 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-16 05:09:58 --> Language Class Initialized
DEBUG - 2011-09-16 05:09:58 --> Loader Class Initialized
DEBUG - 2011-09-16 05:09:58 --> Controller Class Initialized
DEBUG - 2011-09-16 05:09:58 --> Model Class Initialized
DEBUG - 2011-09-16 05:09:58 --> Model Class Initialized
DEBUG - 2011-09-16 05:09:58 --> Model Class Initialized
DEBUG - 2011-09-16 05:09:58 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-16 05:09:58 --> Database Driver Class Initialized
DEBUG - 2011-09-16 05:09:58 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-16 05:09:58 --> Helper loaded: url_helper
DEBUG - 2011-09-16 05:09:58 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-16 05:09:58 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-16 05:09:58 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-16 05:09:58 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-16 05:09:58 --> Final output sent to browser
DEBUG - 2011-09-16 05:09:58 --> Total execution time: 0.1887
DEBUG - 2011-09-16 05:09:58 --> Config Class Initialized
DEBUG - 2011-09-16 05:09:58 --> Hooks Class Initialized
DEBUG - 2011-09-16 05:09:58 --> Utf8 Class Initialized
DEBUG - 2011-09-16 05:09:58 --> UTF-8 Support Enabled
DEBUG - 2011-09-16 05:09:58 --> URI Class Initialized
DEBUG - 2011-09-16 05:09:58 --> Router Class Initialized
DEBUG - 2011-09-16 05:09:58 --> Output Class Initialized
DEBUG - 2011-09-16 05:09:58 --> Input Class Initialized
DEBUG - 2011-09-16 05:09:58 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-16 05:09:58 --> Language Class Initialized
DEBUG - 2011-09-16 05:09:58 --> Loader Class Initialized
DEBUG - 2011-09-16 05:09:58 --> Controller Class Initialized
DEBUG - 2011-09-16 05:09:58 --> Model Class Initialized
DEBUG - 2011-09-16 05:09:58 --> Model Class Initialized
DEBUG - 2011-09-16 05:09:58 --> Model Class Initialized
DEBUG - 2011-09-16 05:09:58 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-16 05:09:58 --> Database Driver Class Initialized
DEBUG - 2011-09-16 05:09:58 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-16 05:09:58 --> Helper loaded: url_helper
DEBUG - 2011-09-16 05:09:58 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-16 05:09:58 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-16 05:09:58 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-16 05:09:58 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-16 05:09:58 --> Final output sent to browser
DEBUG - 2011-09-16 05:09:58 --> Total execution time: 0.2004
DEBUG - 2011-09-16 05:10:11 --> Config Class Initialized
DEBUG - 2011-09-16 05:10:11 --> Hooks Class Initialized
DEBUG - 2011-09-16 05:10:11 --> Utf8 Class Initialized
DEBUG - 2011-09-16 05:10:11 --> UTF-8 Support Enabled
DEBUG - 2011-09-16 05:10:11 --> URI Class Initialized
DEBUG - 2011-09-16 05:10:11 --> Router Class Initialized
DEBUG - 2011-09-16 05:10:11 --> Output Class Initialized
DEBUG - 2011-09-16 05:10:11 --> Input Class Initialized
DEBUG - 2011-09-16 05:10:11 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-16 05:10:11 --> Language Class Initialized
DEBUG - 2011-09-16 05:10:11 --> Loader Class Initialized
DEBUG - 2011-09-16 05:10:11 --> Controller Class Initialized
DEBUG - 2011-09-16 05:10:11 --> Model Class Initialized
DEBUG - 2011-09-16 05:10:11 --> Model Class Initialized
DEBUG - 2011-09-16 05:10:11 --> Model Class Initialized
DEBUG - 2011-09-16 05:10:11 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-16 05:10:11 --> Database Driver Class Initialized
DEBUG - 2011-09-16 05:10:16 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-16 05:10:16 --> Helper loaded: url_helper
DEBUG - 2011-09-16 05:10:16 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-16 05:10:16 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-16 05:10:16 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-16 05:10:16 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-16 05:10:16 --> Final output sent to browser
DEBUG - 2011-09-16 05:10:16 --> Total execution time: 5.0936
DEBUG - 2011-09-16 05:10:17 --> Config Class Initialized
DEBUG - 2011-09-16 05:10:17 --> Hooks Class Initialized
DEBUG - 2011-09-16 05:10:17 --> Utf8 Class Initialized
DEBUG - 2011-09-16 05:10:17 --> UTF-8 Support Enabled
DEBUG - 2011-09-16 05:10:17 --> URI Class Initialized
DEBUG - 2011-09-16 05:10:17 --> Router Class Initialized
DEBUG - 2011-09-16 05:10:17 --> Output Class Initialized
DEBUG - 2011-09-16 05:10:17 --> Input Class Initialized
DEBUG - 2011-09-16 05:10:17 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-16 05:10:17 --> Language Class Initialized
DEBUG - 2011-09-16 05:10:17 --> Loader Class Initialized
DEBUG - 2011-09-16 05:10:17 --> Controller Class Initialized
DEBUG - 2011-09-16 05:10:17 --> Model Class Initialized
DEBUG - 2011-09-16 05:10:17 --> Model Class Initialized
DEBUG - 2011-09-16 05:10:17 --> Model Class Initialized
DEBUG - 2011-09-16 05:10:17 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-16 05:10:17 --> Database Driver Class Initialized
DEBUG - 2011-09-16 05:10:17 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-16 05:10:17 --> Helper loaded: url_helper
DEBUG - 2011-09-16 05:10:17 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-16 05:10:17 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-16 05:10:17 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-16 05:10:17 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-16 05:10:17 --> Final output sent to browser
DEBUG - 2011-09-16 05:10:17 --> Total execution time: 0.1011
DEBUG - 2011-09-16 05:10:28 --> Config Class Initialized
DEBUG - 2011-09-16 05:10:28 --> Hooks Class Initialized
DEBUG - 2011-09-16 05:10:28 --> Utf8 Class Initialized
DEBUG - 2011-09-16 05:10:28 --> UTF-8 Support Enabled
DEBUG - 2011-09-16 05:10:28 --> URI Class Initialized
DEBUG - 2011-09-16 05:10:28 --> Router Class Initialized
DEBUG - 2011-09-16 05:10:28 --> Output Class Initialized
DEBUG - 2011-09-16 05:10:28 --> Input Class Initialized
DEBUG - 2011-09-16 05:10:28 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-16 05:10:28 --> Language Class Initialized
DEBUG - 2011-09-16 05:10:28 --> Loader Class Initialized
DEBUG - 2011-09-16 05:10:28 --> Controller Class Initialized
DEBUG - 2011-09-16 05:10:28 --> Model Class Initialized
DEBUG - 2011-09-16 05:10:28 --> Model Class Initialized
DEBUG - 2011-09-16 05:10:28 --> Model Class Initialized
DEBUG - 2011-09-16 05:10:28 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-16 05:10:28 --> Database Driver Class Initialized
DEBUG - 2011-09-16 05:10:28 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-16 05:10:28 --> Helper loaded: url_helper
DEBUG - 2011-09-16 05:10:28 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-16 05:10:28 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-16 05:10:28 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-16 05:10:28 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-16 05:10:28 --> Final output sent to browser
DEBUG - 2011-09-16 05:10:28 --> Total execution time: 0.3582
DEBUG - 2011-09-16 05:10:36 --> Config Class Initialized
DEBUG - 2011-09-16 05:10:36 --> Hooks Class Initialized
DEBUG - 2011-09-16 05:10:36 --> Utf8 Class Initialized
DEBUG - 2011-09-16 05:10:36 --> UTF-8 Support Enabled
DEBUG - 2011-09-16 05:10:36 --> URI Class Initialized
DEBUG - 2011-09-16 05:10:36 --> Router Class Initialized
DEBUG - 2011-09-16 05:10:36 --> Output Class Initialized
DEBUG - 2011-09-16 05:10:36 --> Input Class Initialized
DEBUG - 2011-09-16 05:10:36 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-16 05:10:36 --> Language Class Initialized
DEBUG - 2011-09-16 05:10:36 --> Loader Class Initialized
DEBUG - 2011-09-16 05:10:36 --> Controller Class Initialized
DEBUG - 2011-09-16 05:10:36 --> Model Class Initialized
DEBUG - 2011-09-16 05:10:36 --> Model Class Initialized
DEBUG - 2011-09-16 05:10:36 --> Model Class Initialized
DEBUG - 2011-09-16 05:10:36 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-16 05:10:36 --> Database Driver Class Initialized
DEBUG - 2011-09-16 05:10:36 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-16 05:10:36 --> Helper loaded: url_helper
DEBUG - 2011-09-16 05:10:36 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-16 05:10:36 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-16 05:10:36 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-16 05:10:36 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-16 05:10:36 --> Final output sent to browser
DEBUG - 2011-09-16 05:10:36 --> Total execution time: 0.1442
DEBUG - 2011-09-16 05:10:38 --> Config Class Initialized
DEBUG - 2011-09-16 05:10:38 --> Hooks Class Initialized
DEBUG - 2011-09-16 05:10:38 --> Utf8 Class Initialized
DEBUG - 2011-09-16 05:10:38 --> UTF-8 Support Enabled
DEBUG - 2011-09-16 05:10:38 --> URI Class Initialized
DEBUG - 2011-09-16 05:10:38 --> Router Class Initialized
DEBUG - 2011-09-16 05:10:38 --> Output Class Initialized
DEBUG - 2011-09-16 05:10:38 --> Input Class Initialized
DEBUG - 2011-09-16 05:10:38 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-16 05:10:38 --> Language Class Initialized
DEBUG - 2011-09-16 05:10:38 --> Loader Class Initialized
DEBUG - 2011-09-16 05:10:38 --> Controller Class Initialized
DEBUG - 2011-09-16 05:10:38 --> Model Class Initialized
DEBUG - 2011-09-16 05:10:38 --> Model Class Initialized
DEBUG - 2011-09-16 05:10:38 --> Model Class Initialized
DEBUG - 2011-09-16 05:10:38 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-16 05:10:38 --> Database Driver Class Initialized
DEBUG - 2011-09-16 05:10:41 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-16 05:10:41 --> Helper loaded: url_helper
DEBUG - 2011-09-16 05:10:41 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-16 05:10:41 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-16 05:10:41 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-16 05:10:41 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-16 05:10:41 --> Final output sent to browser
DEBUG - 2011-09-16 05:10:41 --> Total execution time: 2.7339
DEBUG - 2011-09-16 05:10:43 --> Config Class Initialized
DEBUG - 2011-09-16 05:10:43 --> Hooks Class Initialized
DEBUG - 2011-09-16 05:10:43 --> Utf8 Class Initialized
DEBUG - 2011-09-16 05:10:43 --> UTF-8 Support Enabled
DEBUG - 2011-09-16 05:10:43 --> URI Class Initialized
DEBUG - 2011-09-16 05:10:43 --> Router Class Initialized
DEBUG - 2011-09-16 05:10:43 --> Output Class Initialized
DEBUG - 2011-09-16 05:10:43 --> Input Class Initialized
DEBUG - 2011-09-16 05:10:43 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-16 05:10:43 --> Language Class Initialized
DEBUG - 2011-09-16 05:10:43 --> Loader Class Initialized
DEBUG - 2011-09-16 05:10:43 --> Controller Class Initialized
DEBUG - 2011-09-16 05:10:43 --> Model Class Initialized
DEBUG - 2011-09-16 05:10:43 --> Model Class Initialized
DEBUG - 2011-09-16 05:10:43 --> Model Class Initialized
DEBUG - 2011-09-16 05:10:43 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-16 05:10:43 --> Database Driver Class Initialized
DEBUG - 2011-09-16 05:10:43 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-16 05:10:43 --> Helper loaded: url_helper
DEBUG - 2011-09-16 05:10:43 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-16 05:10:43 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-16 05:10:43 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-16 05:10:43 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-16 05:10:43 --> Final output sent to browser
DEBUG - 2011-09-16 05:10:43 --> Total execution time: 0.0523
DEBUG - 2011-09-16 05:10:49 --> Config Class Initialized
DEBUG - 2011-09-16 05:10:49 --> Hooks Class Initialized
DEBUG - 2011-09-16 05:10:49 --> Utf8 Class Initialized
DEBUG - 2011-09-16 05:10:49 --> UTF-8 Support Enabled
DEBUG - 2011-09-16 05:10:49 --> URI Class Initialized
DEBUG - 2011-09-16 05:10:49 --> Router Class Initialized
DEBUG - 2011-09-16 05:10:49 --> Output Class Initialized
DEBUG - 2011-09-16 05:10:49 --> Input Class Initialized
DEBUG - 2011-09-16 05:10:49 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-16 05:10:49 --> Language Class Initialized
DEBUG - 2011-09-16 05:10:49 --> Loader Class Initialized
DEBUG - 2011-09-16 05:10:49 --> Controller Class Initialized
DEBUG - 2011-09-16 05:10:49 --> Model Class Initialized
DEBUG - 2011-09-16 05:10:49 --> Model Class Initialized
DEBUG - 2011-09-16 05:10:49 --> Model Class Initialized
DEBUG - 2011-09-16 05:10:49 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-16 05:10:49 --> Database Driver Class Initialized
DEBUG - 2011-09-16 05:10:49 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-16 05:10:49 --> Helper loaded: url_helper
DEBUG - 2011-09-16 05:10:49 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-16 05:10:49 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-16 05:10:49 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-16 05:10:49 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-16 05:10:49 --> Final output sent to browser
DEBUG - 2011-09-16 05:10:49 --> Total execution time: 0.0691
DEBUG - 2011-09-16 05:56:44 --> Config Class Initialized
DEBUG - 2011-09-16 05:56:44 --> Hooks Class Initialized
DEBUG - 2011-09-16 05:56:44 --> Utf8 Class Initialized
DEBUG - 2011-09-16 05:56:44 --> UTF-8 Support Enabled
DEBUG - 2011-09-16 05:56:44 --> URI Class Initialized
DEBUG - 2011-09-16 05:56:44 --> Router Class Initialized
DEBUG - 2011-09-16 05:56:44 --> Output Class Initialized
DEBUG - 2011-09-16 05:56:44 --> Input Class Initialized
DEBUG - 2011-09-16 05:56:44 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-16 05:56:44 --> Language Class Initialized
DEBUG - 2011-09-16 05:56:44 --> Loader Class Initialized
DEBUG - 2011-09-16 05:56:44 --> Controller Class Initialized
ERROR - 2011-09-16 05:56:44 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-16 05:56:44 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-16 05:56:44 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-16 05:56:44 --> Model Class Initialized
DEBUG - 2011-09-16 05:56:44 --> Model Class Initialized
DEBUG - 2011-09-16 05:56:44 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-16 05:56:44 --> Database Driver Class Initialized
DEBUG - 2011-09-16 05:56:45 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-16 05:56:45 --> Helper loaded: url_helper
DEBUG - 2011-09-16 05:56:45 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-16 05:56:45 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-16 05:56:45 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-16 05:56:45 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-16 05:56:45 --> Final output sent to browser
DEBUG - 2011-09-16 05:56:45 --> Total execution time: 0.5307
DEBUG - 2011-09-16 05:56:47 --> Config Class Initialized
DEBUG - 2011-09-16 05:56:47 --> Hooks Class Initialized
DEBUG - 2011-09-16 05:56:47 --> Utf8 Class Initialized
DEBUG - 2011-09-16 05:56:47 --> UTF-8 Support Enabled
DEBUG - 2011-09-16 05:56:47 --> URI Class Initialized
DEBUG - 2011-09-16 05:56:47 --> Router Class Initialized
DEBUG - 2011-09-16 05:56:47 --> Output Class Initialized
DEBUG - 2011-09-16 05:56:47 --> Input Class Initialized
DEBUG - 2011-09-16 05:56:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-16 05:56:47 --> Language Class Initialized
DEBUG - 2011-09-16 05:56:47 --> Loader Class Initialized
DEBUG - 2011-09-16 05:56:47 --> Controller Class Initialized
DEBUG - 2011-09-16 05:56:47 --> Model Class Initialized
DEBUG - 2011-09-16 05:56:47 --> Model Class Initialized
DEBUG - 2011-09-16 05:56:47 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-16 05:56:47 --> Database Driver Class Initialized
DEBUG - 2011-09-16 05:56:48 --> Final output sent to browser
DEBUG - 2011-09-16 05:56:48 --> Total execution time: 0.7847
DEBUG - 2011-09-16 05:56:56 --> Config Class Initialized
DEBUG - 2011-09-16 05:56:56 --> Hooks Class Initialized
DEBUG - 2011-09-16 05:56:56 --> Utf8 Class Initialized
DEBUG - 2011-09-16 05:56:56 --> UTF-8 Support Enabled
DEBUG - 2011-09-16 05:56:56 --> URI Class Initialized
DEBUG - 2011-09-16 05:56:56 --> Router Class Initialized
DEBUG - 2011-09-16 05:56:56 --> Output Class Initialized
DEBUG - 2011-09-16 05:56:56 --> Input Class Initialized
DEBUG - 2011-09-16 05:56:56 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-16 05:56:56 --> Language Class Initialized
DEBUG - 2011-09-16 05:56:56 --> Loader Class Initialized
DEBUG - 2011-09-16 05:56:56 --> Controller Class Initialized
ERROR - 2011-09-16 05:56:56 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-16 05:56:56 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-16 05:56:56 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-16 05:56:56 --> Model Class Initialized
DEBUG - 2011-09-16 05:56:56 --> Model Class Initialized
DEBUG - 2011-09-16 05:56:56 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-16 05:56:56 --> Database Driver Class Initialized
DEBUG - 2011-09-16 05:56:56 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-16 05:56:56 --> Helper loaded: url_helper
DEBUG - 2011-09-16 05:56:56 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-16 05:56:56 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-16 05:56:56 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-16 05:56:56 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-16 05:56:56 --> Final output sent to browser
DEBUG - 2011-09-16 05:56:56 --> Total execution time: 0.0287
DEBUG - 2011-09-16 05:56:57 --> Config Class Initialized
DEBUG - 2011-09-16 05:56:57 --> Hooks Class Initialized
DEBUG - 2011-09-16 05:56:57 --> Utf8 Class Initialized
DEBUG - 2011-09-16 05:56:57 --> UTF-8 Support Enabled
DEBUG - 2011-09-16 05:56:57 --> URI Class Initialized
DEBUG - 2011-09-16 05:56:57 --> Router Class Initialized
DEBUG - 2011-09-16 05:56:57 --> Output Class Initialized
DEBUG - 2011-09-16 05:56:57 --> Input Class Initialized
DEBUG - 2011-09-16 05:56:57 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-16 05:56:57 --> Language Class Initialized
DEBUG - 2011-09-16 05:56:57 --> Loader Class Initialized
DEBUG - 2011-09-16 05:56:57 --> Controller Class Initialized
DEBUG - 2011-09-16 05:56:57 --> Model Class Initialized
DEBUG - 2011-09-16 05:56:57 --> Model Class Initialized
DEBUG - 2011-09-16 05:56:57 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-16 05:56:57 --> Database Driver Class Initialized
DEBUG - 2011-09-16 05:56:58 --> Final output sent to browser
DEBUG - 2011-09-16 05:56:58 --> Total execution time: 0.6382
DEBUG - 2011-09-16 05:57:21 --> Config Class Initialized
DEBUG - 2011-09-16 05:57:21 --> Hooks Class Initialized
DEBUG - 2011-09-16 05:57:21 --> Utf8 Class Initialized
DEBUG - 2011-09-16 05:57:21 --> UTF-8 Support Enabled
DEBUG - 2011-09-16 05:57:21 --> URI Class Initialized
DEBUG - 2011-09-16 05:57:21 --> Router Class Initialized
DEBUG - 2011-09-16 05:57:21 --> Output Class Initialized
DEBUG - 2011-09-16 05:57:21 --> Input Class Initialized
DEBUG - 2011-09-16 05:57:21 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-16 05:57:21 --> Language Class Initialized
DEBUG - 2011-09-16 05:57:21 --> Loader Class Initialized
DEBUG - 2011-09-16 05:57:21 --> Controller Class Initialized
ERROR - 2011-09-16 05:57:21 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-16 05:57:21 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-16 05:57:21 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-16 05:57:21 --> Model Class Initialized
DEBUG - 2011-09-16 05:57:21 --> Model Class Initialized
DEBUG - 2011-09-16 05:57:21 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-16 05:57:21 --> Database Driver Class Initialized
DEBUG - 2011-09-16 05:57:21 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-16 05:57:21 --> Helper loaded: url_helper
DEBUG - 2011-09-16 05:57:21 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-16 05:57:21 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-16 05:57:21 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-16 05:57:21 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-16 05:57:21 --> Final output sent to browser
DEBUG - 2011-09-16 05:57:21 --> Total execution time: 0.0305
DEBUG - 2011-09-16 05:57:22 --> Config Class Initialized
DEBUG - 2011-09-16 05:57:22 --> Hooks Class Initialized
DEBUG - 2011-09-16 05:57:22 --> Utf8 Class Initialized
DEBUG - 2011-09-16 05:57:22 --> UTF-8 Support Enabled
DEBUG - 2011-09-16 05:57:22 --> URI Class Initialized
DEBUG - 2011-09-16 05:57:22 --> Router Class Initialized
DEBUG - 2011-09-16 05:57:22 --> Output Class Initialized
DEBUG - 2011-09-16 05:57:22 --> Input Class Initialized
DEBUG - 2011-09-16 05:57:22 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-16 05:57:22 --> Language Class Initialized
DEBUG - 2011-09-16 05:57:22 --> Loader Class Initialized
DEBUG - 2011-09-16 05:57:22 --> Controller Class Initialized
DEBUG - 2011-09-16 05:57:22 --> Model Class Initialized
DEBUG - 2011-09-16 05:57:22 --> Model Class Initialized
DEBUG - 2011-09-16 05:57:22 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-16 05:57:22 --> Database Driver Class Initialized
DEBUG - 2011-09-16 05:57:23 --> Final output sent to browser
DEBUG - 2011-09-16 05:57:23 --> Total execution time: 0.7346
DEBUG - 2011-09-16 05:57:33 --> Config Class Initialized
DEBUG - 2011-09-16 05:57:33 --> Hooks Class Initialized
DEBUG - 2011-09-16 05:57:33 --> Utf8 Class Initialized
DEBUG - 2011-09-16 05:57:33 --> UTF-8 Support Enabled
DEBUG - 2011-09-16 05:57:33 --> URI Class Initialized
DEBUG - 2011-09-16 05:57:33 --> Router Class Initialized
DEBUG - 2011-09-16 05:57:33 --> Output Class Initialized
DEBUG - 2011-09-16 05:57:33 --> Input Class Initialized
DEBUG - 2011-09-16 05:57:33 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-16 05:57:33 --> Language Class Initialized
DEBUG - 2011-09-16 05:57:33 --> Loader Class Initialized
DEBUG - 2011-09-16 05:57:33 --> Controller Class Initialized
ERROR - 2011-09-16 05:57:33 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-16 05:57:33 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-16 05:57:33 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-16 05:57:33 --> Model Class Initialized
DEBUG - 2011-09-16 05:57:33 --> Model Class Initialized
DEBUG - 2011-09-16 05:57:33 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-16 05:57:33 --> Database Driver Class Initialized
DEBUG - 2011-09-16 05:57:33 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-16 05:57:33 --> Helper loaded: url_helper
DEBUG - 2011-09-16 05:57:33 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-16 05:57:33 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-16 05:57:33 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-16 05:57:33 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-16 05:57:33 --> Final output sent to browser
DEBUG - 2011-09-16 05:57:33 --> Total execution time: 0.1021
DEBUG - 2011-09-16 05:57:34 --> Config Class Initialized
DEBUG - 2011-09-16 05:57:34 --> Hooks Class Initialized
DEBUG - 2011-09-16 05:57:34 --> Utf8 Class Initialized
DEBUG - 2011-09-16 05:57:34 --> UTF-8 Support Enabled
DEBUG - 2011-09-16 05:57:34 --> URI Class Initialized
DEBUG - 2011-09-16 05:57:34 --> Router Class Initialized
DEBUG - 2011-09-16 05:57:34 --> Output Class Initialized
DEBUG - 2011-09-16 05:57:34 --> Input Class Initialized
DEBUG - 2011-09-16 05:57:34 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-16 05:57:34 --> Language Class Initialized
DEBUG - 2011-09-16 05:57:34 --> Loader Class Initialized
DEBUG - 2011-09-16 05:57:34 --> Controller Class Initialized
DEBUG - 2011-09-16 05:57:34 --> Model Class Initialized
DEBUG - 2011-09-16 05:57:34 --> Model Class Initialized
DEBUG - 2011-09-16 05:57:34 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-16 05:57:34 --> Database Driver Class Initialized
DEBUG - 2011-09-16 05:57:34 --> Final output sent to browser
DEBUG - 2011-09-16 05:57:34 --> Total execution time: 0.7476
DEBUG - 2011-09-16 05:57:55 --> Config Class Initialized
DEBUG - 2011-09-16 05:57:55 --> Hooks Class Initialized
DEBUG - 2011-09-16 05:57:55 --> Utf8 Class Initialized
DEBUG - 2011-09-16 05:57:55 --> UTF-8 Support Enabled
DEBUG - 2011-09-16 05:57:55 --> URI Class Initialized
DEBUG - 2011-09-16 05:57:55 --> Router Class Initialized
DEBUG - 2011-09-16 05:57:55 --> Output Class Initialized
DEBUG - 2011-09-16 05:57:55 --> Input Class Initialized
DEBUG - 2011-09-16 05:57:55 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-16 05:57:55 --> Language Class Initialized
DEBUG - 2011-09-16 05:57:55 --> Loader Class Initialized
DEBUG - 2011-09-16 05:57:55 --> Controller Class Initialized
ERROR - 2011-09-16 05:57:55 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-16 05:57:55 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-16 05:57:55 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-16 05:57:55 --> Model Class Initialized
DEBUG - 2011-09-16 05:57:55 --> Model Class Initialized
DEBUG - 2011-09-16 05:57:55 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-16 05:57:55 --> Database Driver Class Initialized
DEBUG - 2011-09-16 05:57:55 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-16 05:57:55 --> Helper loaded: url_helper
DEBUG - 2011-09-16 05:57:55 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-16 05:57:55 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-16 05:57:55 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-16 05:57:55 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-16 05:57:55 --> Final output sent to browser
DEBUG - 2011-09-16 05:57:55 --> Total execution time: 0.0312
DEBUG - 2011-09-16 05:57:56 --> Config Class Initialized
DEBUG - 2011-09-16 05:57:56 --> Hooks Class Initialized
DEBUG - 2011-09-16 05:57:56 --> Utf8 Class Initialized
DEBUG - 2011-09-16 05:57:56 --> UTF-8 Support Enabled
DEBUG - 2011-09-16 05:57:56 --> URI Class Initialized
DEBUG - 2011-09-16 05:57:56 --> Router Class Initialized
DEBUG - 2011-09-16 05:57:56 --> Output Class Initialized
DEBUG - 2011-09-16 05:57:56 --> Input Class Initialized
DEBUG - 2011-09-16 05:57:56 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-16 05:57:56 --> Language Class Initialized
DEBUG - 2011-09-16 05:57:56 --> Loader Class Initialized
DEBUG - 2011-09-16 05:57:56 --> Controller Class Initialized
DEBUG - 2011-09-16 05:57:56 --> Model Class Initialized
DEBUG - 2011-09-16 05:57:56 --> Model Class Initialized
DEBUG - 2011-09-16 05:57:56 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-16 05:57:56 --> Database Driver Class Initialized
DEBUG - 2011-09-16 05:57:56 --> Final output sent to browser
DEBUG - 2011-09-16 05:57:56 --> Total execution time: 0.5834
DEBUG - 2011-09-16 05:58:05 --> Config Class Initialized
DEBUG - 2011-09-16 05:58:05 --> Hooks Class Initialized
DEBUG - 2011-09-16 05:58:05 --> Utf8 Class Initialized
DEBUG - 2011-09-16 05:58:05 --> UTF-8 Support Enabled
DEBUG - 2011-09-16 05:58:05 --> URI Class Initialized
DEBUG - 2011-09-16 05:58:05 --> Router Class Initialized
DEBUG - 2011-09-16 05:58:05 --> Output Class Initialized
DEBUG - 2011-09-16 05:58:05 --> Input Class Initialized
DEBUG - 2011-09-16 05:58:05 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-16 05:58:05 --> Language Class Initialized
DEBUG - 2011-09-16 05:58:05 --> Loader Class Initialized
DEBUG - 2011-09-16 05:58:05 --> Controller Class Initialized
ERROR - 2011-09-16 05:58:05 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-16 05:58:05 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-16 05:58:05 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-16 05:58:05 --> Model Class Initialized
DEBUG - 2011-09-16 05:58:05 --> Model Class Initialized
DEBUG - 2011-09-16 05:58:05 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-16 05:58:05 --> Database Driver Class Initialized
DEBUG - 2011-09-16 05:58:05 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-16 05:58:05 --> Helper loaded: url_helper
DEBUG - 2011-09-16 05:58:05 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-16 05:58:05 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-16 05:58:05 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-16 05:58:05 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-16 05:58:05 --> Final output sent to browser
DEBUG - 2011-09-16 05:58:05 --> Total execution time: 0.0288
DEBUG - 2011-09-16 05:58:06 --> Config Class Initialized
DEBUG - 2011-09-16 05:58:06 --> Hooks Class Initialized
DEBUG - 2011-09-16 05:58:06 --> Utf8 Class Initialized
DEBUG - 2011-09-16 05:58:06 --> UTF-8 Support Enabled
DEBUG - 2011-09-16 05:58:06 --> URI Class Initialized
DEBUG - 2011-09-16 05:58:06 --> Router Class Initialized
DEBUG - 2011-09-16 05:58:06 --> Output Class Initialized
DEBUG - 2011-09-16 05:58:06 --> Input Class Initialized
DEBUG - 2011-09-16 05:58:06 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-16 05:58:06 --> Language Class Initialized
DEBUG - 2011-09-16 05:58:06 --> Loader Class Initialized
DEBUG - 2011-09-16 05:58:06 --> Controller Class Initialized
DEBUG - 2011-09-16 05:58:06 --> Model Class Initialized
DEBUG - 2011-09-16 05:58:06 --> Model Class Initialized
DEBUG - 2011-09-16 05:58:06 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-16 05:58:06 --> Database Driver Class Initialized
DEBUG - 2011-09-16 05:58:07 --> Final output sent to browser
DEBUG - 2011-09-16 05:58:07 --> Total execution time: 0.5490
DEBUG - 2011-09-16 05:58:24 --> Config Class Initialized
DEBUG - 2011-09-16 05:58:24 --> Hooks Class Initialized
DEBUG - 2011-09-16 05:58:24 --> Utf8 Class Initialized
DEBUG - 2011-09-16 05:58:24 --> UTF-8 Support Enabled
DEBUG - 2011-09-16 05:58:24 --> URI Class Initialized
DEBUG - 2011-09-16 05:58:24 --> Router Class Initialized
DEBUG - 2011-09-16 05:58:24 --> Output Class Initialized
DEBUG - 2011-09-16 05:58:24 --> Input Class Initialized
DEBUG - 2011-09-16 05:58:24 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-16 05:58:24 --> Language Class Initialized
DEBUG - 2011-09-16 05:58:24 --> Loader Class Initialized
DEBUG - 2011-09-16 05:58:24 --> Controller Class Initialized
ERROR - 2011-09-16 05:58:24 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-16 05:58:24 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-16 05:58:24 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-16 05:58:24 --> Model Class Initialized
DEBUG - 2011-09-16 05:58:24 --> Model Class Initialized
DEBUG - 2011-09-16 05:58:24 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-16 05:58:24 --> Database Driver Class Initialized
DEBUG - 2011-09-16 05:58:24 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-16 05:58:24 --> Helper loaded: url_helper
DEBUG - 2011-09-16 05:58:24 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-16 05:58:24 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-16 05:58:24 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-16 05:58:24 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-16 05:58:24 --> Final output sent to browser
DEBUG - 2011-09-16 05:58:24 --> Total execution time: 0.0341
DEBUG - 2011-09-16 05:58:25 --> Config Class Initialized
DEBUG - 2011-09-16 05:58:25 --> Hooks Class Initialized
DEBUG - 2011-09-16 05:58:25 --> Utf8 Class Initialized
DEBUG - 2011-09-16 05:58:25 --> UTF-8 Support Enabled
DEBUG - 2011-09-16 05:58:25 --> URI Class Initialized
DEBUG - 2011-09-16 05:58:25 --> Router Class Initialized
DEBUG - 2011-09-16 05:58:25 --> Output Class Initialized
DEBUG - 2011-09-16 05:58:25 --> Input Class Initialized
DEBUG - 2011-09-16 05:58:25 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-16 05:58:25 --> Language Class Initialized
DEBUG - 2011-09-16 05:58:25 --> Loader Class Initialized
DEBUG - 2011-09-16 05:58:25 --> Controller Class Initialized
DEBUG - 2011-09-16 05:58:25 --> Model Class Initialized
DEBUG - 2011-09-16 05:58:25 --> Model Class Initialized
DEBUG - 2011-09-16 05:58:25 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-16 05:58:25 --> Database Driver Class Initialized
DEBUG - 2011-09-16 05:58:26 --> Final output sent to browser
DEBUG - 2011-09-16 05:58:26 --> Total execution time: 0.5642
DEBUG - 2011-09-16 05:58:43 --> Config Class Initialized
DEBUG - 2011-09-16 05:58:43 --> Hooks Class Initialized
DEBUG - 2011-09-16 05:58:43 --> Utf8 Class Initialized
DEBUG - 2011-09-16 05:58:43 --> UTF-8 Support Enabled
DEBUG - 2011-09-16 05:58:43 --> URI Class Initialized
DEBUG - 2011-09-16 05:58:43 --> Router Class Initialized
DEBUG - 2011-09-16 05:58:43 --> Output Class Initialized
DEBUG - 2011-09-16 05:58:43 --> Input Class Initialized
DEBUG - 2011-09-16 05:58:43 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-16 05:58:43 --> Language Class Initialized
DEBUG - 2011-09-16 05:58:43 --> Loader Class Initialized
DEBUG - 2011-09-16 05:58:43 --> Controller Class Initialized
ERROR - 2011-09-16 05:58:43 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-16 05:58:43 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-16 05:58:43 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-16 05:58:43 --> Model Class Initialized
DEBUG - 2011-09-16 05:58:43 --> Model Class Initialized
DEBUG - 2011-09-16 05:58:43 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-16 05:58:43 --> Database Driver Class Initialized
DEBUG - 2011-09-16 05:58:43 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-16 05:58:43 --> Helper loaded: url_helper
DEBUG - 2011-09-16 05:58:43 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-16 05:58:43 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-16 05:58:43 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-16 05:58:43 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-16 05:58:43 --> Final output sent to browser
DEBUG - 2011-09-16 05:58:43 --> Total execution time: 0.0599
DEBUG - 2011-09-16 05:58:44 --> Config Class Initialized
DEBUG - 2011-09-16 05:58:44 --> Hooks Class Initialized
DEBUG - 2011-09-16 05:58:44 --> Utf8 Class Initialized
DEBUG - 2011-09-16 05:58:44 --> UTF-8 Support Enabled
DEBUG - 2011-09-16 05:58:44 --> URI Class Initialized
DEBUG - 2011-09-16 05:58:44 --> Router Class Initialized
DEBUG - 2011-09-16 05:58:44 --> Output Class Initialized
DEBUG - 2011-09-16 05:58:44 --> Input Class Initialized
DEBUG - 2011-09-16 05:58:44 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-16 05:58:44 --> Language Class Initialized
DEBUG - 2011-09-16 05:58:44 --> Loader Class Initialized
DEBUG - 2011-09-16 05:58:44 --> Controller Class Initialized
DEBUG - 2011-09-16 05:58:44 --> Model Class Initialized
DEBUG - 2011-09-16 05:58:44 --> Model Class Initialized
DEBUG - 2011-09-16 05:58:44 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-16 05:58:44 --> Database Driver Class Initialized
DEBUG - 2011-09-16 05:58:44 --> Final output sent to browser
DEBUG - 2011-09-16 05:58:44 --> Total execution time: 0.5090
DEBUG - 2011-09-16 05:59:06 --> Config Class Initialized
DEBUG - 2011-09-16 05:59:06 --> Hooks Class Initialized
DEBUG - 2011-09-16 05:59:06 --> Utf8 Class Initialized
DEBUG - 2011-09-16 05:59:06 --> UTF-8 Support Enabled
DEBUG - 2011-09-16 05:59:06 --> URI Class Initialized
DEBUG - 2011-09-16 05:59:06 --> Router Class Initialized
DEBUG - 2011-09-16 05:59:06 --> Output Class Initialized
DEBUG - 2011-09-16 05:59:06 --> Input Class Initialized
DEBUG - 2011-09-16 05:59:06 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-16 05:59:06 --> Language Class Initialized
DEBUG - 2011-09-16 05:59:06 --> Loader Class Initialized
DEBUG - 2011-09-16 05:59:06 --> Controller Class Initialized
ERROR - 2011-09-16 05:59:06 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-16 05:59:06 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-16 05:59:06 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-16 05:59:06 --> Model Class Initialized
DEBUG - 2011-09-16 05:59:06 --> Model Class Initialized
DEBUG - 2011-09-16 05:59:06 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-16 05:59:06 --> Database Driver Class Initialized
DEBUG - 2011-09-16 05:59:06 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-16 05:59:06 --> Helper loaded: url_helper
DEBUG - 2011-09-16 05:59:06 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-16 05:59:06 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-16 05:59:06 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-16 05:59:06 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-16 05:59:06 --> Final output sent to browser
DEBUG - 2011-09-16 05:59:06 --> Total execution time: 0.0341
DEBUG - 2011-09-16 05:59:07 --> Config Class Initialized
DEBUG - 2011-09-16 05:59:07 --> Hooks Class Initialized
DEBUG - 2011-09-16 05:59:07 --> Utf8 Class Initialized
DEBUG - 2011-09-16 05:59:07 --> UTF-8 Support Enabled
DEBUG - 2011-09-16 05:59:07 --> URI Class Initialized
DEBUG - 2011-09-16 05:59:07 --> Router Class Initialized
DEBUG - 2011-09-16 05:59:07 --> Output Class Initialized
DEBUG - 2011-09-16 05:59:07 --> Input Class Initialized
DEBUG - 2011-09-16 05:59:07 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-16 05:59:07 --> Language Class Initialized
DEBUG - 2011-09-16 05:59:07 --> Loader Class Initialized
DEBUG - 2011-09-16 05:59:07 --> Controller Class Initialized
DEBUG - 2011-09-16 05:59:07 --> Model Class Initialized
DEBUG - 2011-09-16 05:59:07 --> Model Class Initialized
DEBUG - 2011-09-16 05:59:07 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-16 05:59:07 --> Database Driver Class Initialized
DEBUG - 2011-09-16 05:59:08 --> Final output sent to browser
DEBUG - 2011-09-16 05:59:08 --> Total execution time: 0.7143
DEBUG - 2011-09-16 05:59:26 --> Config Class Initialized
DEBUG - 2011-09-16 05:59:26 --> Hooks Class Initialized
DEBUG - 2011-09-16 05:59:26 --> Utf8 Class Initialized
DEBUG - 2011-09-16 05:59:26 --> UTF-8 Support Enabled
DEBUG - 2011-09-16 05:59:26 --> URI Class Initialized
DEBUG - 2011-09-16 05:59:26 --> Router Class Initialized
DEBUG - 2011-09-16 05:59:26 --> Output Class Initialized
DEBUG - 2011-09-16 05:59:26 --> Input Class Initialized
DEBUG - 2011-09-16 05:59:26 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-16 05:59:26 --> Language Class Initialized
DEBUG - 2011-09-16 05:59:26 --> Loader Class Initialized
DEBUG - 2011-09-16 05:59:26 --> Controller Class Initialized
ERROR - 2011-09-16 05:59:26 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-16 05:59:26 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-16 05:59:26 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-16 05:59:26 --> Model Class Initialized
DEBUG - 2011-09-16 05:59:26 --> Model Class Initialized
DEBUG - 2011-09-16 05:59:26 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-16 05:59:27 --> Database Driver Class Initialized
DEBUG - 2011-09-16 05:59:27 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-16 05:59:27 --> Helper loaded: url_helper
DEBUG - 2011-09-16 05:59:27 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-16 05:59:27 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-16 05:59:27 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-16 05:59:27 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-16 05:59:27 --> Final output sent to browser
DEBUG - 2011-09-16 05:59:27 --> Total execution time: 0.0302
DEBUG - 2011-09-16 05:59:27 --> Config Class Initialized
DEBUG - 2011-09-16 05:59:27 --> Hooks Class Initialized
DEBUG - 2011-09-16 05:59:27 --> Utf8 Class Initialized
DEBUG - 2011-09-16 05:59:27 --> UTF-8 Support Enabled
DEBUG - 2011-09-16 05:59:27 --> URI Class Initialized
DEBUG - 2011-09-16 05:59:27 --> Router Class Initialized
DEBUG - 2011-09-16 05:59:27 --> Output Class Initialized
DEBUG - 2011-09-16 05:59:27 --> Input Class Initialized
DEBUG - 2011-09-16 05:59:27 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-16 05:59:27 --> Language Class Initialized
DEBUG - 2011-09-16 05:59:27 --> Loader Class Initialized
DEBUG - 2011-09-16 05:59:27 --> Controller Class Initialized
DEBUG - 2011-09-16 05:59:27 --> Model Class Initialized
DEBUG - 2011-09-16 05:59:27 --> Model Class Initialized
DEBUG - 2011-09-16 05:59:27 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-16 05:59:27 --> Database Driver Class Initialized
DEBUG - 2011-09-16 05:59:28 --> Final output sent to browser
DEBUG - 2011-09-16 05:59:28 --> Total execution time: 0.5173
DEBUG - 2011-09-16 05:59:50 --> Config Class Initialized
DEBUG - 2011-09-16 05:59:50 --> Hooks Class Initialized
DEBUG - 2011-09-16 05:59:50 --> Utf8 Class Initialized
DEBUG - 2011-09-16 05:59:50 --> UTF-8 Support Enabled
DEBUG - 2011-09-16 05:59:50 --> URI Class Initialized
DEBUG - 2011-09-16 05:59:50 --> Router Class Initialized
DEBUG - 2011-09-16 05:59:50 --> Output Class Initialized
DEBUG - 2011-09-16 05:59:50 --> Input Class Initialized
DEBUG - 2011-09-16 05:59:50 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-16 05:59:50 --> Language Class Initialized
DEBUG - 2011-09-16 05:59:50 --> Loader Class Initialized
DEBUG - 2011-09-16 05:59:50 --> Controller Class Initialized
ERROR - 2011-09-16 05:59:50 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-16 05:59:50 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-16 05:59:50 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-16 05:59:50 --> Model Class Initialized
DEBUG - 2011-09-16 05:59:50 --> Model Class Initialized
DEBUG - 2011-09-16 05:59:50 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-16 05:59:50 --> Database Driver Class Initialized
DEBUG - 2011-09-16 05:59:50 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-16 05:59:50 --> Helper loaded: url_helper
DEBUG - 2011-09-16 05:59:50 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-16 05:59:50 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-16 05:59:50 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-16 05:59:50 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-16 05:59:50 --> Final output sent to browser
DEBUG - 2011-09-16 05:59:50 --> Total execution time: 0.0485
DEBUG - 2011-09-16 06:00:37 --> Config Class Initialized
DEBUG - 2011-09-16 06:00:37 --> Hooks Class Initialized
DEBUG - 2011-09-16 06:00:37 --> Utf8 Class Initialized
DEBUG - 2011-09-16 06:00:37 --> UTF-8 Support Enabled
DEBUG - 2011-09-16 06:00:37 --> URI Class Initialized
DEBUG - 2011-09-16 06:00:37 --> Router Class Initialized
DEBUG - 2011-09-16 06:00:37 --> Output Class Initialized
DEBUG - 2011-09-16 06:00:37 --> Input Class Initialized
DEBUG - 2011-09-16 06:00:37 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-16 06:00:37 --> Language Class Initialized
DEBUG - 2011-09-16 06:00:37 --> Loader Class Initialized
DEBUG - 2011-09-16 06:00:37 --> Controller Class Initialized
ERROR - 2011-09-16 06:00:37 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-16 06:00:37 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-16 06:00:37 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-16 06:00:37 --> Model Class Initialized
DEBUG - 2011-09-16 06:00:37 --> Model Class Initialized
DEBUG - 2011-09-16 06:00:37 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-16 06:00:37 --> Database Driver Class Initialized
DEBUG - 2011-09-16 06:00:37 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-16 06:00:37 --> Helper loaded: url_helper
DEBUG - 2011-09-16 06:00:37 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-16 06:00:37 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-16 06:00:37 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-16 06:00:37 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-16 06:00:37 --> Final output sent to browser
DEBUG - 2011-09-16 06:00:37 --> Total execution time: 0.0312
DEBUG - 2011-09-16 06:00:39 --> Config Class Initialized
DEBUG - 2011-09-16 06:00:39 --> Hooks Class Initialized
DEBUG - 2011-09-16 06:00:39 --> Utf8 Class Initialized
DEBUG - 2011-09-16 06:00:39 --> UTF-8 Support Enabled
DEBUG - 2011-09-16 06:00:39 --> URI Class Initialized
DEBUG - 2011-09-16 06:00:39 --> Router Class Initialized
DEBUG - 2011-09-16 06:00:39 --> Output Class Initialized
DEBUG - 2011-09-16 06:00:39 --> Input Class Initialized
DEBUG - 2011-09-16 06:00:39 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-16 06:00:39 --> Language Class Initialized
DEBUG - 2011-09-16 06:00:39 --> Loader Class Initialized
DEBUG - 2011-09-16 06:00:39 --> Controller Class Initialized
DEBUG - 2011-09-16 06:00:39 --> Model Class Initialized
DEBUG - 2011-09-16 06:00:39 --> Model Class Initialized
DEBUG - 2011-09-16 06:00:39 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-16 06:00:39 --> Database Driver Class Initialized
DEBUG - 2011-09-16 06:00:39 --> Final output sent to browser
DEBUG - 2011-09-16 06:00:39 --> Total execution time: 0.5337
DEBUG - 2011-09-16 09:12:06 --> Config Class Initialized
DEBUG - 2011-09-16 09:12:06 --> Hooks Class Initialized
DEBUG - 2011-09-16 09:12:06 --> Utf8 Class Initialized
DEBUG - 2011-09-16 09:12:06 --> UTF-8 Support Enabled
DEBUG - 2011-09-16 09:12:06 --> URI Class Initialized
DEBUG - 2011-09-16 09:12:06 --> Router Class Initialized
DEBUG - 2011-09-16 09:12:06 --> No URI present. Default controller set.
DEBUG - 2011-09-16 09:12:06 --> Output Class Initialized
DEBUG - 2011-09-16 09:12:06 --> Input Class Initialized
DEBUG - 2011-09-16 09:12:06 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-16 09:12:06 --> Language Class Initialized
DEBUG - 2011-09-16 09:12:06 --> Loader Class Initialized
DEBUG - 2011-09-16 09:12:06 --> Controller Class Initialized
DEBUG - 2011-09-16 09:12:06 --> File loaded: application/views/splash/main.php
DEBUG - 2011-09-16 09:12:07 --> Helper loaded: url_helper
DEBUG - 2011-09-16 09:12:07 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-16 09:12:07 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-16 09:12:07 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-16 09:12:07 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-16 09:12:07 --> Final output sent to browser
DEBUG - 2011-09-16 09:12:07 --> Total execution time: 0.2567
DEBUG - 2011-09-16 10:23:54 --> Config Class Initialized
DEBUG - 2011-09-16 10:23:54 --> Hooks Class Initialized
DEBUG - 2011-09-16 10:23:54 --> Utf8 Class Initialized
DEBUG - 2011-09-16 10:23:54 --> UTF-8 Support Enabled
DEBUG - 2011-09-16 10:23:54 --> URI Class Initialized
DEBUG - 2011-09-16 10:23:54 --> Router Class Initialized
DEBUG - 2011-09-16 10:23:54 --> Output Class Initialized
DEBUG - 2011-09-16 10:23:54 --> Input Class Initialized
DEBUG - 2011-09-16 10:23:54 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-16 10:23:54 --> Language Class Initialized
DEBUG - 2011-09-16 10:23:54 --> Loader Class Initialized
DEBUG - 2011-09-16 10:23:54 --> Controller Class Initialized
ERROR - 2011-09-16 10:23:54 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-16 10:23:54 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-16 10:23:54 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-16 10:23:54 --> Model Class Initialized
DEBUG - 2011-09-16 10:23:54 --> Model Class Initialized
DEBUG - 2011-09-16 10:23:54 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-16 10:23:54 --> Database Driver Class Initialized
DEBUG - 2011-09-16 10:23:55 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-16 10:23:55 --> Helper loaded: url_helper
DEBUG - 2011-09-16 10:23:55 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-16 10:23:55 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-16 10:23:55 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-16 10:23:55 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-16 10:23:55 --> Final output sent to browser
DEBUG - 2011-09-16 10:23:55 --> Total execution time: 0.6922
DEBUG - 2011-09-16 10:23:56 --> Config Class Initialized
DEBUG - 2011-09-16 10:23:56 --> Hooks Class Initialized
DEBUG - 2011-09-16 10:23:56 --> Utf8 Class Initialized
DEBUG - 2011-09-16 10:23:56 --> UTF-8 Support Enabled
DEBUG - 2011-09-16 10:23:56 --> URI Class Initialized
DEBUG - 2011-09-16 10:23:56 --> Router Class Initialized
DEBUG - 2011-09-16 10:23:56 --> Output Class Initialized
DEBUG - 2011-09-16 10:23:56 --> Input Class Initialized
DEBUG - 2011-09-16 10:23:56 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-16 10:23:56 --> Language Class Initialized
DEBUG - 2011-09-16 10:23:56 --> Loader Class Initialized
DEBUG - 2011-09-16 10:23:56 --> Controller Class Initialized
DEBUG - 2011-09-16 10:23:56 --> Model Class Initialized
DEBUG - 2011-09-16 10:23:56 --> Model Class Initialized
DEBUG - 2011-09-16 10:23:56 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-16 10:23:56 --> Database Driver Class Initialized
DEBUG - 2011-09-16 10:23:57 --> Final output sent to browser
DEBUG - 2011-09-16 10:23:57 --> Total execution time: 1.2805
DEBUG - 2011-09-16 10:24:31 --> Config Class Initialized
DEBUG - 2011-09-16 10:24:31 --> Hooks Class Initialized
DEBUG - 2011-09-16 10:24:31 --> Utf8 Class Initialized
DEBUG - 2011-09-16 10:24:31 --> UTF-8 Support Enabled
DEBUG - 2011-09-16 10:24:31 --> URI Class Initialized
DEBUG - 2011-09-16 10:24:31 --> Router Class Initialized
DEBUG - 2011-09-16 10:24:31 --> Output Class Initialized
DEBUG - 2011-09-16 10:24:31 --> Input Class Initialized
DEBUG - 2011-09-16 10:24:31 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-16 10:24:31 --> Language Class Initialized
DEBUG - 2011-09-16 10:24:31 --> Loader Class Initialized
DEBUG - 2011-09-16 10:24:31 --> Controller Class Initialized
DEBUG - 2011-09-16 10:24:31 --> Model Class Initialized
DEBUG - 2011-09-16 10:24:31 --> Model Class Initialized
DEBUG - 2011-09-16 10:24:31 --> Model Class Initialized
DEBUG - 2011-09-16 10:24:31 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-16 10:24:31 --> Database Driver Class Initialized
DEBUG - 2011-09-16 10:24:32 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-16 10:24:32 --> Helper loaded: url_helper
DEBUG - 2011-09-16 10:24:32 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-16 10:24:32 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-16 10:24:32 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-16 10:24:32 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-16 10:24:32 --> Final output sent to browser
DEBUG - 2011-09-16 10:24:32 --> Total execution time: 0.7277
DEBUG - 2011-09-16 11:47:55 --> Config Class Initialized
DEBUG - 2011-09-16 11:47:55 --> Hooks Class Initialized
DEBUG - 2011-09-16 11:47:55 --> Utf8 Class Initialized
DEBUG - 2011-09-16 11:47:55 --> UTF-8 Support Enabled
DEBUG - 2011-09-16 11:47:55 --> URI Class Initialized
DEBUG - 2011-09-16 11:47:55 --> Router Class Initialized
DEBUG - 2011-09-16 11:47:55 --> Output Class Initialized
DEBUG - 2011-09-16 11:47:55 --> Input Class Initialized
DEBUG - 2011-09-16 11:47:55 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-16 11:47:55 --> Language Class Initialized
DEBUG - 2011-09-16 11:47:55 --> Loader Class Initialized
DEBUG - 2011-09-16 11:47:55 --> Controller Class Initialized
ERROR - 2011-09-16 11:47:55 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-16 11:47:55 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-16 11:47:55 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-16 11:47:55 --> Model Class Initialized
DEBUG - 2011-09-16 11:47:55 --> Model Class Initialized
DEBUG - 2011-09-16 11:47:55 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-16 11:47:55 --> Database Driver Class Initialized
DEBUG - 2011-09-16 11:47:56 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-16 11:47:56 --> Helper loaded: url_helper
DEBUG - 2011-09-16 11:47:56 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-16 11:47:56 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-16 11:47:56 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-16 11:47:56 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-16 11:47:56 --> Final output sent to browser
DEBUG - 2011-09-16 11:47:56 --> Total execution time: 0.5187
DEBUG - 2011-09-16 11:47:56 --> Config Class Initialized
DEBUG - 2011-09-16 11:47:56 --> Hooks Class Initialized
DEBUG - 2011-09-16 11:47:56 --> Utf8 Class Initialized
DEBUG - 2011-09-16 11:47:56 --> UTF-8 Support Enabled
DEBUG - 2011-09-16 11:47:56 --> URI Class Initialized
DEBUG - 2011-09-16 11:47:56 --> Router Class Initialized
DEBUG - 2011-09-16 11:47:56 --> Output Class Initialized
DEBUG - 2011-09-16 11:47:56 --> Input Class Initialized
DEBUG - 2011-09-16 11:47:56 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-16 11:47:56 --> Language Class Initialized
DEBUG - 2011-09-16 11:47:56 --> Loader Class Initialized
DEBUG - 2011-09-16 11:47:56 --> Controller Class Initialized
DEBUG - 2011-09-16 11:47:56 --> Model Class Initialized
DEBUG - 2011-09-16 11:47:56 --> Model Class Initialized
DEBUG - 2011-09-16 11:47:56 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-16 11:47:56 --> Database Driver Class Initialized
DEBUG - 2011-09-16 11:47:57 --> Final output sent to browser
DEBUG - 2011-09-16 11:47:57 --> Total execution time: 0.6712
DEBUG - 2011-09-16 11:47:58 --> Config Class Initialized
DEBUG - 2011-09-16 11:47:58 --> Hooks Class Initialized
DEBUG - 2011-09-16 11:47:58 --> Utf8 Class Initialized
DEBUG - 2011-09-16 11:47:58 --> UTF-8 Support Enabled
DEBUG - 2011-09-16 11:47:58 --> URI Class Initialized
DEBUG - 2011-09-16 11:47:58 --> Router Class Initialized
ERROR - 2011-09-16 11:47:58 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-16 11:48:03 --> Config Class Initialized
DEBUG - 2011-09-16 11:48:03 --> Hooks Class Initialized
DEBUG - 2011-09-16 11:48:03 --> Utf8 Class Initialized
DEBUG - 2011-09-16 11:48:03 --> UTF-8 Support Enabled
DEBUG - 2011-09-16 11:48:03 --> URI Class Initialized
DEBUG - 2011-09-16 11:48:03 --> Router Class Initialized
DEBUG - 2011-09-16 11:48:03 --> Output Class Initialized
DEBUG - 2011-09-16 11:48:03 --> Input Class Initialized
DEBUG - 2011-09-16 11:48:03 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-16 11:48:03 --> Language Class Initialized
DEBUG - 2011-09-16 11:48:03 --> Loader Class Initialized
DEBUG - 2011-09-16 11:48:03 --> Controller Class Initialized
ERROR - 2011-09-16 11:48:03 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-16 11:48:03 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-16 11:48:03 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-16 11:48:03 --> Model Class Initialized
DEBUG - 2011-09-16 11:48:03 --> Model Class Initialized
DEBUG - 2011-09-16 11:48:03 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-16 11:48:03 --> Database Driver Class Initialized
DEBUG - 2011-09-16 11:48:03 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-16 11:48:03 --> Helper loaded: url_helper
DEBUG - 2011-09-16 11:48:03 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-16 11:48:03 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-16 11:48:03 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-16 11:48:03 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-16 11:48:03 --> Final output sent to browser
DEBUG - 2011-09-16 11:48:03 --> Total execution time: 0.1680
DEBUG - 2011-09-16 11:48:04 --> Config Class Initialized
DEBUG - 2011-09-16 11:48:04 --> Hooks Class Initialized
DEBUG - 2011-09-16 11:48:04 --> Utf8 Class Initialized
DEBUG - 2011-09-16 11:48:04 --> UTF-8 Support Enabled
DEBUG - 2011-09-16 11:48:04 --> URI Class Initialized
DEBUG - 2011-09-16 11:48:04 --> Router Class Initialized
DEBUG - 2011-09-16 11:48:04 --> Output Class Initialized
DEBUG - 2011-09-16 11:48:04 --> Input Class Initialized
DEBUG - 2011-09-16 11:48:04 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-16 11:48:04 --> Language Class Initialized
DEBUG - 2011-09-16 11:48:04 --> Loader Class Initialized
DEBUG - 2011-09-16 11:48:04 --> Controller Class Initialized
DEBUG - 2011-09-16 11:48:04 --> Model Class Initialized
DEBUG - 2011-09-16 11:48:04 --> Model Class Initialized
DEBUG - 2011-09-16 11:48:04 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-16 11:48:04 --> Database Driver Class Initialized
DEBUG - 2011-09-16 11:48:05 --> Final output sent to browser
DEBUG - 2011-09-16 11:48:05 --> Total execution time: 0.8109
DEBUG - 2011-09-16 11:48:05 --> Config Class Initialized
DEBUG - 2011-09-16 11:48:05 --> Hooks Class Initialized
DEBUG - 2011-09-16 11:48:05 --> Utf8 Class Initialized
DEBUG - 2011-09-16 11:48:05 --> UTF-8 Support Enabled
DEBUG - 2011-09-16 11:48:05 --> URI Class Initialized
DEBUG - 2011-09-16 11:48:05 --> Router Class Initialized
ERROR - 2011-09-16 11:48:05 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-16 11:48:08 --> Config Class Initialized
DEBUG - 2011-09-16 11:48:08 --> Hooks Class Initialized
DEBUG - 2011-09-16 11:48:08 --> Utf8 Class Initialized
DEBUG - 2011-09-16 11:48:08 --> UTF-8 Support Enabled
DEBUG - 2011-09-16 11:48:08 --> URI Class Initialized
DEBUG - 2011-09-16 11:48:08 --> Router Class Initialized
DEBUG - 2011-09-16 11:48:08 --> Output Class Initialized
DEBUG - 2011-09-16 11:48:08 --> Input Class Initialized
DEBUG - 2011-09-16 11:48:08 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-16 11:48:08 --> Language Class Initialized
DEBUG - 2011-09-16 11:48:08 --> Loader Class Initialized
DEBUG - 2011-09-16 11:48:08 --> Controller Class Initialized
ERROR - 2011-09-16 11:48:08 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-16 11:48:08 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-16 11:48:08 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-16 11:48:08 --> Model Class Initialized
DEBUG - 2011-09-16 11:48:08 --> Model Class Initialized
DEBUG - 2011-09-16 11:48:08 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-16 11:48:08 --> Database Driver Class Initialized
DEBUG - 2011-09-16 11:48:08 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-16 11:48:08 --> Helper loaded: url_helper
DEBUG - 2011-09-16 11:48:08 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-16 11:48:08 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-16 11:48:08 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-16 11:48:08 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-16 11:48:08 --> Final output sent to browser
DEBUG - 2011-09-16 11:48:08 --> Total execution time: 0.1244
DEBUG - 2011-09-16 11:48:09 --> Config Class Initialized
DEBUG - 2011-09-16 11:48:09 --> Hooks Class Initialized
DEBUG - 2011-09-16 11:48:09 --> Utf8 Class Initialized
DEBUG - 2011-09-16 11:48:09 --> UTF-8 Support Enabled
DEBUG - 2011-09-16 11:48:09 --> URI Class Initialized
DEBUG - 2011-09-16 11:48:09 --> Router Class Initialized
DEBUG - 2011-09-16 11:48:09 --> Output Class Initialized
DEBUG - 2011-09-16 11:48:09 --> Input Class Initialized
DEBUG - 2011-09-16 11:48:09 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-16 11:48:09 --> Language Class Initialized
DEBUG - 2011-09-16 11:48:09 --> Loader Class Initialized
DEBUG - 2011-09-16 11:48:09 --> Controller Class Initialized
DEBUG - 2011-09-16 11:48:09 --> Model Class Initialized
DEBUG - 2011-09-16 11:48:09 --> Model Class Initialized
DEBUG - 2011-09-16 11:48:09 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-16 11:48:09 --> Database Driver Class Initialized
DEBUG - 2011-09-16 11:48:09 --> Final output sent to browser
DEBUG - 2011-09-16 11:48:09 --> Total execution time: 0.7313
DEBUG - 2011-09-16 11:48:10 --> Config Class Initialized
DEBUG - 2011-09-16 11:48:10 --> Hooks Class Initialized
DEBUG - 2011-09-16 11:48:10 --> Utf8 Class Initialized
DEBUG - 2011-09-16 11:48:10 --> UTF-8 Support Enabled
DEBUG - 2011-09-16 11:48:10 --> URI Class Initialized
DEBUG - 2011-09-16 11:48:10 --> Router Class Initialized
ERROR - 2011-09-16 11:48:10 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-16 11:48:14 --> Config Class Initialized
DEBUG - 2011-09-16 11:48:14 --> Hooks Class Initialized
DEBUG - 2011-09-16 11:48:14 --> Utf8 Class Initialized
DEBUG - 2011-09-16 11:48:14 --> UTF-8 Support Enabled
DEBUG - 2011-09-16 11:48:14 --> URI Class Initialized
DEBUG - 2011-09-16 11:48:14 --> Router Class Initialized
DEBUG - 2011-09-16 11:48:14 --> Output Class Initialized
DEBUG - 2011-09-16 11:48:14 --> Input Class Initialized
DEBUG - 2011-09-16 11:48:14 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-16 11:48:14 --> Language Class Initialized
DEBUG - 2011-09-16 11:48:14 --> Loader Class Initialized
DEBUG - 2011-09-16 11:48:14 --> Controller Class Initialized
ERROR - 2011-09-16 11:48:14 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-16 11:48:14 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-16 11:48:14 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-16 11:48:14 --> Model Class Initialized
DEBUG - 2011-09-16 11:48:14 --> Model Class Initialized
DEBUG - 2011-09-16 11:48:14 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-16 11:48:14 --> Database Driver Class Initialized
DEBUG - 2011-09-16 11:48:14 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-16 11:48:14 --> Helper loaded: url_helper
DEBUG - 2011-09-16 11:48:14 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-16 11:48:14 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-16 11:48:14 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-16 11:48:14 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-16 11:48:14 --> Final output sent to browser
DEBUG - 2011-09-16 11:48:14 --> Total execution time: 0.0302
DEBUG - 2011-09-16 11:48:15 --> Config Class Initialized
DEBUG - 2011-09-16 11:48:15 --> Hooks Class Initialized
DEBUG - 2011-09-16 11:48:15 --> Utf8 Class Initialized
DEBUG - 2011-09-16 11:48:15 --> UTF-8 Support Enabled
DEBUG - 2011-09-16 11:48:15 --> URI Class Initialized
DEBUG - 2011-09-16 11:48:15 --> Router Class Initialized
DEBUG - 2011-09-16 11:48:15 --> Output Class Initialized
DEBUG - 2011-09-16 11:48:15 --> Input Class Initialized
DEBUG - 2011-09-16 11:48:15 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-16 11:48:15 --> Language Class Initialized
DEBUG - 2011-09-16 11:48:15 --> Loader Class Initialized
DEBUG - 2011-09-16 11:48:15 --> Controller Class Initialized
DEBUG - 2011-09-16 11:48:15 --> Model Class Initialized
DEBUG - 2011-09-16 11:48:15 --> Model Class Initialized
DEBUG - 2011-09-16 11:48:15 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-16 11:48:15 --> Database Driver Class Initialized
DEBUG - 2011-09-16 11:48:16 --> Final output sent to browser
DEBUG - 2011-09-16 11:48:16 --> Total execution time: 0.7485
DEBUG - 2011-09-16 11:48:16 --> Config Class Initialized
DEBUG - 2011-09-16 11:48:16 --> Hooks Class Initialized
DEBUG - 2011-09-16 11:48:16 --> Utf8 Class Initialized
DEBUG - 2011-09-16 11:48:16 --> UTF-8 Support Enabled
DEBUG - 2011-09-16 11:48:16 --> URI Class Initialized
DEBUG - 2011-09-16 11:48:16 --> Router Class Initialized
ERROR - 2011-09-16 11:48:16 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-16 11:54:50 --> Config Class Initialized
DEBUG - 2011-09-16 11:54:50 --> Hooks Class Initialized
DEBUG - 2011-09-16 11:54:50 --> Utf8 Class Initialized
DEBUG - 2011-09-16 11:54:50 --> UTF-8 Support Enabled
DEBUG - 2011-09-16 11:54:50 --> URI Class Initialized
DEBUG - 2011-09-16 11:54:50 --> Router Class Initialized
DEBUG - 2011-09-16 11:54:50 --> Output Class Initialized
DEBUG - 2011-09-16 11:54:50 --> Input Class Initialized
DEBUG - 2011-09-16 11:54:50 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-16 11:54:50 --> Language Class Initialized
DEBUG - 2011-09-16 11:54:50 --> Loader Class Initialized
DEBUG - 2011-09-16 11:54:50 --> Controller Class Initialized
ERROR - 2011-09-16 11:54:50 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-16 11:54:50 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-16 11:54:50 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-16 11:54:50 --> Model Class Initialized
DEBUG - 2011-09-16 11:54:50 --> Model Class Initialized
DEBUG - 2011-09-16 11:54:50 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-16 11:54:50 --> Database Driver Class Initialized
DEBUG - 2011-09-16 11:54:50 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-16 11:54:50 --> Helper loaded: url_helper
DEBUG - 2011-09-16 11:54:50 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-16 11:54:50 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-16 11:54:50 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-16 11:54:50 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-16 11:54:50 --> Final output sent to browser
DEBUG - 2011-09-16 11:54:50 --> Total execution time: 0.0609
DEBUG - 2011-09-16 13:15:15 --> Config Class Initialized
DEBUG - 2011-09-16 13:15:15 --> Hooks Class Initialized
DEBUG - 2011-09-16 13:15:15 --> Utf8 Class Initialized
DEBUG - 2011-09-16 13:15:15 --> UTF-8 Support Enabled
DEBUG - 2011-09-16 13:15:15 --> URI Class Initialized
DEBUG - 2011-09-16 13:15:15 --> Router Class Initialized
DEBUG - 2011-09-16 13:15:16 --> Output Class Initialized
DEBUG - 2011-09-16 13:15:16 --> Input Class Initialized
DEBUG - 2011-09-16 13:15:16 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-16 13:15:16 --> Language Class Initialized
DEBUG - 2011-09-16 13:15:16 --> Loader Class Initialized
DEBUG - 2011-09-16 13:15:16 --> Controller Class Initialized
DEBUG - 2011-09-16 13:15:16 --> Model Class Initialized
DEBUG - 2011-09-16 13:15:16 --> Model Class Initialized
DEBUG - 2011-09-16 13:15:16 --> Model Class Initialized
DEBUG - 2011-09-16 13:15:16 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-16 13:15:16 --> Database Driver Class Initialized
DEBUG - 2011-09-16 13:15:18 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-16 13:15:18 --> Helper loaded: url_helper
DEBUG - 2011-09-16 13:15:18 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-16 13:15:18 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-16 13:15:18 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-16 13:15:18 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-16 13:15:18 --> Final output sent to browser
DEBUG - 2011-09-16 13:15:18 --> Total execution time: 2.2783
DEBUG - 2011-09-16 13:18:24 --> Config Class Initialized
DEBUG - 2011-09-16 13:18:24 --> Hooks Class Initialized
DEBUG - 2011-09-16 13:18:24 --> Utf8 Class Initialized
DEBUG - 2011-09-16 13:18:24 --> UTF-8 Support Enabled
DEBUG - 2011-09-16 13:18:24 --> URI Class Initialized
DEBUG - 2011-09-16 13:18:24 --> Router Class Initialized
DEBUG - 2011-09-16 13:18:24 --> Output Class Initialized
DEBUG - 2011-09-16 13:18:24 --> Input Class Initialized
DEBUG - 2011-09-16 13:18:24 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-16 13:18:24 --> Language Class Initialized
DEBUG - 2011-09-16 13:18:24 --> Loader Class Initialized
DEBUG - 2011-09-16 13:18:24 --> Controller Class Initialized
DEBUG - 2011-09-16 13:18:24 --> Model Class Initialized
DEBUG - 2011-09-16 13:18:24 --> Model Class Initialized
DEBUG - 2011-09-16 13:18:24 --> Model Class Initialized
DEBUG - 2011-09-16 13:18:24 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-16 13:18:24 --> Database Driver Class Initialized
DEBUG - 2011-09-16 13:18:24 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-16 13:18:24 --> Helper loaded: url_helper
DEBUG - 2011-09-16 13:18:24 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-16 13:18:24 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-16 13:18:24 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-16 13:18:24 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-16 13:18:24 --> Final output sent to browser
DEBUG - 2011-09-16 13:18:24 --> Total execution time: 0.0468
DEBUG - 2011-09-16 13:18:30 --> Config Class Initialized
DEBUG - 2011-09-16 13:18:30 --> Hooks Class Initialized
DEBUG - 2011-09-16 13:18:30 --> Utf8 Class Initialized
DEBUG - 2011-09-16 13:18:30 --> UTF-8 Support Enabled
DEBUG - 2011-09-16 13:18:30 --> URI Class Initialized
DEBUG - 2011-09-16 13:18:30 --> Router Class Initialized
ERROR - 2011-09-16 13:18:30 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-16 13:18:31 --> Config Class Initialized
DEBUG - 2011-09-16 13:18:31 --> Hooks Class Initialized
DEBUG - 2011-09-16 13:18:31 --> Utf8 Class Initialized
DEBUG - 2011-09-16 13:18:31 --> UTF-8 Support Enabled
DEBUG - 2011-09-16 13:18:31 --> URI Class Initialized
DEBUG - 2011-09-16 13:18:31 --> Router Class Initialized
ERROR - 2011-09-16 13:18:31 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-16 13:18:48 --> Config Class Initialized
DEBUG - 2011-09-16 13:18:48 --> Hooks Class Initialized
DEBUG - 2011-09-16 13:18:48 --> Utf8 Class Initialized
DEBUG - 2011-09-16 13:18:48 --> UTF-8 Support Enabled
DEBUG - 2011-09-16 13:18:48 --> URI Class Initialized
DEBUG - 2011-09-16 13:18:48 --> Router Class Initialized
DEBUG - 2011-09-16 13:18:48 --> Output Class Initialized
DEBUG - 2011-09-16 13:18:48 --> Input Class Initialized
DEBUG - 2011-09-16 13:18:48 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-16 13:18:48 --> Language Class Initialized
DEBUG - 2011-09-16 13:18:48 --> Loader Class Initialized
DEBUG - 2011-09-16 13:18:48 --> Controller Class Initialized
ERROR - 2011-09-16 13:18:48 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-16 13:18:48 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-16 13:18:48 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-16 13:18:48 --> Model Class Initialized
DEBUG - 2011-09-16 13:18:48 --> Model Class Initialized
DEBUG - 2011-09-16 13:18:48 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-16 13:18:48 --> Database Driver Class Initialized
DEBUG - 2011-09-16 13:18:48 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-16 13:18:48 --> Helper loaded: url_helper
DEBUG - 2011-09-16 13:18:48 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-16 13:18:48 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-16 13:18:48 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-16 13:18:48 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-16 13:18:48 --> Final output sent to browser
DEBUG - 2011-09-16 13:18:48 --> Total execution time: 0.0294
DEBUG - 2011-09-16 13:18:49 --> Config Class Initialized
DEBUG - 2011-09-16 13:18:49 --> Hooks Class Initialized
DEBUG - 2011-09-16 13:18:49 --> Utf8 Class Initialized
DEBUG - 2011-09-16 13:18:49 --> UTF-8 Support Enabled
DEBUG - 2011-09-16 13:18:49 --> URI Class Initialized
DEBUG - 2011-09-16 13:18:49 --> Router Class Initialized
DEBUG - 2011-09-16 13:18:49 --> Output Class Initialized
DEBUG - 2011-09-16 13:18:49 --> Input Class Initialized
DEBUG - 2011-09-16 13:18:49 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-16 13:18:49 --> Language Class Initialized
DEBUG - 2011-09-16 13:18:49 --> Loader Class Initialized
DEBUG - 2011-09-16 13:18:49 --> Controller Class Initialized
DEBUG - 2011-09-16 13:18:49 --> Model Class Initialized
DEBUG - 2011-09-16 13:18:49 --> Model Class Initialized
DEBUG - 2011-09-16 13:18:49 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-16 13:18:49 --> Database Driver Class Initialized
DEBUG - 2011-09-16 13:18:50 --> Final output sent to browser
DEBUG - 2011-09-16 13:18:50 --> Total execution time: 0.6355
DEBUG - 2011-09-16 13:19:24 --> Config Class Initialized
DEBUG - 2011-09-16 13:19:24 --> Hooks Class Initialized
DEBUG - 2011-09-16 13:19:24 --> Utf8 Class Initialized
DEBUG - 2011-09-16 13:19:24 --> UTF-8 Support Enabled
DEBUG - 2011-09-16 13:19:24 --> URI Class Initialized
DEBUG - 2011-09-16 13:19:24 --> Router Class Initialized
DEBUG - 2011-09-16 13:19:24 --> Output Class Initialized
DEBUG - 2011-09-16 13:19:24 --> Input Class Initialized
DEBUG - 2011-09-16 13:19:24 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-16 13:19:24 --> Language Class Initialized
DEBUG - 2011-09-16 13:19:24 --> Loader Class Initialized
DEBUG - 2011-09-16 13:19:24 --> Controller Class Initialized
ERROR - 2011-09-16 13:19:24 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-16 13:19:24 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-16 13:19:24 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-16 13:19:24 --> Model Class Initialized
DEBUG - 2011-09-16 13:19:24 --> Model Class Initialized
DEBUG - 2011-09-16 13:19:24 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-16 13:19:24 --> Database Driver Class Initialized
DEBUG - 2011-09-16 13:19:24 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-16 13:19:24 --> Helper loaded: url_helper
DEBUG - 2011-09-16 13:19:24 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-16 13:19:24 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-16 13:19:24 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-16 13:19:24 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-16 13:19:24 --> Final output sent to browser
DEBUG - 2011-09-16 13:19:24 --> Total execution time: 0.0322
DEBUG - 2011-09-16 13:19:25 --> Config Class Initialized
DEBUG - 2011-09-16 13:19:25 --> Hooks Class Initialized
DEBUG - 2011-09-16 13:19:25 --> Utf8 Class Initialized
DEBUG - 2011-09-16 13:19:25 --> UTF-8 Support Enabled
DEBUG - 2011-09-16 13:19:25 --> URI Class Initialized
DEBUG - 2011-09-16 13:19:25 --> Router Class Initialized
DEBUG - 2011-09-16 13:19:25 --> Output Class Initialized
DEBUG - 2011-09-16 13:19:25 --> Input Class Initialized
DEBUG - 2011-09-16 13:19:25 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-16 13:19:25 --> Language Class Initialized
DEBUG - 2011-09-16 13:19:25 --> Loader Class Initialized
DEBUG - 2011-09-16 13:19:25 --> Controller Class Initialized
DEBUG - 2011-09-16 13:19:25 --> Model Class Initialized
DEBUG - 2011-09-16 13:19:25 --> Model Class Initialized
DEBUG - 2011-09-16 13:19:25 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-16 13:19:25 --> Database Driver Class Initialized
DEBUG - 2011-09-16 13:19:26 --> Final output sent to browser
DEBUG - 2011-09-16 13:19:26 --> Total execution time: 0.5031
DEBUG - 2011-09-16 13:19:27 --> Config Class Initialized
DEBUG - 2011-09-16 13:19:27 --> Hooks Class Initialized
DEBUG - 2011-09-16 13:19:27 --> Utf8 Class Initialized
DEBUG - 2011-09-16 13:19:27 --> UTF-8 Support Enabled
DEBUG - 2011-09-16 13:19:27 --> URI Class Initialized
DEBUG - 2011-09-16 13:19:27 --> Router Class Initialized
ERROR - 2011-09-16 13:19:27 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-09-16 13:19:27 --> Config Class Initialized
DEBUG - 2011-09-16 13:19:27 --> Hooks Class Initialized
DEBUG - 2011-09-16 13:19:27 --> Utf8 Class Initialized
DEBUG - 2011-09-16 13:19:27 --> UTF-8 Support Enabled
DEBUG - 2011-09-16 13:19:27 --> URI Class Initialized
DEBUG - 2011-09-16 13:19:27 --> Router Class Initialized
DEBUG - 2011-09-16 13:19:27 --> Output Class Initialized
DEBUG - 2011-09-16 13:19:27 --> Input Class Initialized
DEBUG - 2011-09-16 13:19:27 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-16 13:19:27 --> Language Class Initialized
DEBUG - 2011-09-16 13:19:27 --> Loader Class Initialized
DEBUG - 2011-09-16 13:19:27 --> Controller Class Initialized
ERROR - 2011-09-16 13:19:27 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-16 13:19:27 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-16 13:19:27 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-16 13:19:27 --> Model Class Initialized
DEBUG - 2011-09-16 13:19:27 --> Model Class Initialized
DEBUG - 2011-09-16 13:19:27 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-16 13:19:27 --> Database Driver Class Initialized
DEBUG - 2011-09-16 13:19:27 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-16 13:19:27 --> Helper loaded: url_helper
DEBUG - 2011-09-16 13:19:27 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-16 13:19:27 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-16 13:19:27 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-16 13:19:27 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-16 13:19:27 --> Final output sent to browser
DEBUG - 2011-09-16 13:19:27 --> Total execution time: 0.0291
DEBUG - 2011-09-16 13:19:50 --> Config Class Initialized
DEBUG - 2011-09-16 13:19:50 --> Hooks Class Initialized
DEBUG - 2011-09-16 13:19:50 --> Utf8 Class Initialized
DEBUG - 2011-09-16 13:19:50 --> UTF-8 Support Enabled
DEBUG - 2011-09-16 13:19:50 --> URI Class Initialized
DEBUG - 2011-09-16 13:19:50 --> Router Class Initialized
DEBUG - 2011-09-16 13:19:50 --> Output Class Initialized
DEBUG - 2011-09-16 13:19:50 --> Input Class Initialized
DEBUG - 2011-09-16 13:19:50 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-16 13:19:50 --> Language Class Initialized
DEBUG - 2011-09-16 13:19:50 --> Loader Class Initialized
DEBUG - 2011-09-16 13:19:50 --> Controller Class Initialized
ERROR - 2011-09-16 13:19:50 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-16 13:19:50 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-16 13:19:50 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-16 13:19:50 --> Model Class Initialized
DEBUG - 2011-09-16 13:19:50 --> Model Class Initialized
DEBUG - 2011-09-16 13:19:50 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-16 13:19:50 --> Database Driver Class Initialized
DEBUG - 2011-09-16 13:19:50 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-16 13:19:50 --> Helper loaded: url_helper
DEBUG - 2011-09-16 13:19:50 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-16 13:19:50 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-16 13:19:50 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-16 13:19:50 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-16 13:19:50 --> Final output sent to browser
DEBUG - 2011-09-16 13:19:50 --> Total execution time: 0.0287
DEBUG - 2011-09-16 13:19:51 --> Config Class Initialized
DEBUG - 2011-09-16 13:19:51 --> Hooks Class Initialized
DEBUG - 2011-09-16 13:19:51 --> Utf8 Class Initialized
DEBUG - 2011-09-16 13:19:51 --> UTF-8 Support Enabled
DEBUG - 2011-09-16 13:19:51 --> URI Class Initialized
DEBUG - 2011-09-16 13:19:51 --> Router Class Initialized
DEBUG - 2011-09-16 13:19:51 --> Output Class Initialized
DEBUG - 2011-09-16 13:19:51 --> Input Class Initialized
DEBUG - 2011-09-16 13:19:51 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-16 13:19:51 --> Language Class Initialized
DEBUG - 2011-09-16 13:19:51 --> Loader Class Initialized
DEBUG - 2011-09-16 13:19:51 --> Controller Class Initialized
DEBUG - 2011-09-16 13:19:51 --> Model Class Initialized
DEBUG - 2011-09-16 13:19:51 --> Model Class Initialized
DEBUG - 2011-09-16 13:19:51 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-16 13:19:51 --> Database Driver Class Initialized
DEBUG - 2011-09-16 13:19:52 --> Final output sent to browser
DEBUG - 2011-09-16 13:19:52 --> Total execution time: 0.8216
DEBUG - 2011-09-16 13:21:03 --> Config Class Initialized
DEBUG - 2011-09-16 13:21:03 --> Hooks Class Initialized
DEBUG - 2011-09-16 13:21:03 --> Utf8 Class Initialized
DEBUG - 2011-09-16 13:21:03 --> UTF-8 Support Enabled
DEBUG - 2011-09-16 13:21:03 --> URI Class Initialized
DEBUG - 2011-09-16 13:21:03 --> Router Class Initialized
DEBUG - 2011-09-16 13:21:03 --> Output Class Initialized
DEBUG - 2011-09-16 13:21:03 --> Input Class Initialized
DEBUG - 2011-09-16 13:21:03 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-16 13:21:03 --> Language Class Initialized
DEBUG - 2011-09-16 13:21:03 --> Loader Class Initialized
DEBUG - 2011-09-16 13:21:03 --> Controller Class Initialized
DEBUG - 2011-09-16 13:21:03 --> Model Class Initialized
DEBUG - 2011-09-16 13:21:03 --> Model Class Initialized
DEBUG - 2011-09-16 13:21:03 --> Model Class Initialized
DEBUG - 2011-09-16 13:21:03 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-16 13:21:03 --> Database Driver Class Initialized
DEBUG - 2011-09-16 13:21:03 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-16 13:21:03 --> Helper loaded: url_helper
DEBUG - 2011-09-16 13:21:03 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-16 13:21:03 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-16 13:21:03 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-16 13:21:03 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-16 13:21:03 --> Final output sent to browser
DEBUG - 2011-09-16 13:21:03 --> Total execution time: 0.1539
DEBUG - 2011-09-16 13:21:25 --> Config Class Initialized
DEBUG - 2011-09-16 13:21:25 --> Hooks Class Initialized
DEBUG - 2011-09-16 13:21:25 --> Utf8 Class Initialized
DEBUG - 2011-09-16 13:21:25 --> UTF-8 Support Enabled
DEBUG - 2011-09-16 13:21:25 --> URI Class Initialized
DEBUG - 2011-09-16 13:21:25 --> Router Class Initialized
DEBUG - 2011-09-16 13:21:25 --> Output Class Initialized
DEBUG - 2011-09-16 13:21:25 --> Input Class Initialized
DEBUG - 2011-09-16 13:21:25 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-16 13:21:25 --> Language Class Initialized
DEBUG - 2011-09-16 13:21:25 --> Loader Class Initialized
DEBUG - 2011-09-16 13:21:25 --> Controller Class Initialized
DEBUG - 2011-09-16 13:21:25 --> Model Class Initialized
DEBUG - 2011-09-16 13:21:25 --> Model Class Initialized
DEBUG - 2011-09-16 13:21:25 --> Model Class Initialized
DEBUG - 2011-09-16 13:21:25 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-16 13:21:25 --> Database Driver Class Initialized
DEBUG - 2011-09-16 13:21:25 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-16 13:21:25 --> Helper loaded: url_helper
DEBUG - 2011-09-16 13:21:25 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-16 13:21:25 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-16 13:21:25 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-16 13:21:25 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-16 13:21:25 --> Final output sent to browser
DEBUG - 2011-09-16 13:21:25 --> Total execution time: 0.1116
DEBUG - 2011-09-16 13:21:38 --> Config Class Initialized
DEBUG - 2011-09-16 13:21:38 --> Hooks Class Initialized
DEBUG - 2011-09-16 13:21:38 --> Utf8 Class Initialized
DEBUG - 2011-09-16 13:21:38 --> UTF-8 Support Enabled
DEBUG - 2011-09-16 13:21:38 --> URI Class Initialized
DEBUG - 2011-09-16 13:21:38 --> Router Class Initialized
DEBUG - 2011-09-16 13:21:38 --> Output Class Initialized
DEBUG - 2011-09-16 13:21:38 --> Input Class Initialized
DEBUG - 2011-09-16 13:21:38 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-16 13:21:38 --> Language Class Initialized
DEBUG - 2011-09-16 13:21:38 --> Loader Class Initialized
DEBUG - 2011-09-16 13:21:38 --> Controller Class Initialized
DEBUG - 2011-09-16 13:21:38 --> Model Class Initialized
DEBUG - 2011-09-16 13:21:38 --> Model Class Initialized
DEBUG - 2011-09-16 13:21:38 --> Model Class Initialized
DEBUG - 2011-09-16 13:21:38 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-16 13:21:38 --> Database Driver Class Initialized
DEBUG - 2011-09-16 13:21:39 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-16 13:21:39 --> Helper loaded: url_helper
DEBUG - 2011-09-16 13:21:39 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-16 13:21:39 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-16 13:21:39 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-16 13:21:39 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-16 13:21:39 --> Final output sent to browser
DEBUG - 2011-09-16 13:21:39 --> Total execution time: 0.7596
DEBUG - 2011-09-16 13:21:40 --> Config Class Initialized
DEBUG - 2011-09-16 13:21:40 --> Hooks Class Initialized
DEBUG - 2011-09-16 13:21:40 --> Utf8 Class Initialized
DEBUG - 2011-09-16 13:21:40 --> UTF-8 Support Enabled
DEBUG - 2011-09-16 13:21:40 --> URI Class Initialized
DEBUG - 2011-09-16 13:21:40 --> Router Class Initialized
DEBUG - 2011-09-16 13:21:40 --> Output Class Initialized
DEBUG - 2011-09-16 13:21:40 --> Input Class Initialized
DEBUG - 2011-09-16 13:21:40 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-16 13:21:40 --> Language Class Initialized
DEBUG - 2011-09-16 13:21:40 --> Loader Class Initialized
DEBUG - 2011-09-16 13:21:40 --> Controller Class Initialized
DEBUG - 2011-09-16 13:21:40 --> Model Class Initialized
DEBUG - 2011-09-16 13:21:40 --> Model Class Initialized
DEBUG - 2011-09-16 13:21:40 --> Model Class Initialized
DEBUG - 2011-09-16 13:21:40 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-16 13:21:40 --> Database Driver Class Initialized
DEBUG - 2011-09-16 13:21:40 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-16 13:21:40 --> Helper loaded: url_helper
DEBUG - 2011-09-16 13:21:40 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-16 13:21:40 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-16 13:21:40 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-16 13:21:40 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-16 13:21:40 --> Final output sent to browser
DEBUG - 2011-09-16 13:21:40 --> Total execution time: 0.0463
DEBUG - 2011-09-16 13:21:47 --> Config Class Initialized
DEBUG - 2011-09-16 13:21:47 --> Hooks Class Initialized
DEBUG - 2011-09-16 13:21:47 --> Utf8 Class Initialized
DEBUG - 2011-09-16 13:21:47 --> UTF-8 Support Enabled
DEBUG - 2011-09-16 13:21:47 --> URI Class Initialized
DEBUG - 2011-09-16 13:21:47 --> Router Class Initialized
DEBUG - 2011-09-16 13:21:47 --> Output Class Initialized
DEBUG - 2011-09-16 13:21:47 --> Input Class Initialized
DEBUG - 2011-09-16 13:21:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-16 13:21:47 --> Language Class Initialized
DEBUG - 2011-09-16 13:21:47 --> Loader Class Initialized
DEBUG - 2011-09-16 13:21:47 --> Controller Class Initialized
DEBUG - 2011-09-16 13:21:47 --> Model Class Initialized
DEBUG - 2011-09-16 13:21:47 --> Model Class Initialized
DEBUG - 2011-09-16 13:21:47 --> Model Class Initialized
DEBUG - 2011-09-16 13:21:47 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-16 13:21:47 --> Database Driver Class Initialized
DEBUG - 2011-09-16 13:21:48 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-16 13:21:48 --> Helper loaded: url_helper
DEBUG - 2011-09-16 13:21:48 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-16 13:21:48 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-16 13:21:48 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-16 13:21:48 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-16 13:21:48 --> Final output sent to browser
DEBUG - 2011-09-16 13:21:48 --> Total execution time: 0.2543
DEBUG - 2011-09-16 13:21:50 --> Config Class Initialized
DEBUG - 2011-09-16 13:21:50 --> Hooks Class Initialized
DEBUG - 2011-09-16 13:21:50 --> Utf8 Class Initialized
DEBUG - 2011-09-16 13:21:50 --> UTF-8 Support Enabled
DEBUG - 2011-09-16 13:21:50 --> URI Class Initialized
DEBUG - 2011-09-16 13:21:50 --> Router Class Initialized
DEBUG - 2011-09-16 13:21:50 --> Output Class Initialized
DEBUG - 2011-09-16 13:21:50 --> Input Class Initialized
DEBUG - 2011-09-16 13:21:50 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-16 13:21:50 --> Language Class Initialized
DEBUG - 2011-09-16 13:21:50 --> Loader Class Initialized
DEBUG - 2011-09-16 13:21:50 --> Controller Class Initialized
DEBUG - 2011-09-16 13:21:50 --> Model Class Initialized
DEBUG - 2011-09-16 13:21:50 --> Model Class Initialized
DEBUG - 2011-09-16 13:21:50 --> Model Class Initialized
DEBUG - 2011-09-16 13:21:50 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-16 13:21:50 --> Database Driver Class Initialized
DEBUG - 2011-09-16 13:21:50 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-16 13:21:50 --> Helper loaded: url_helper
DEBUG - 2011-09-16 13:21:50 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-16 13:21:50 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-16 13:21:50 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-16 13:21:50 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-16 13:21:50 --> Final output sent to browser
DEBUG - 2011-09-16 13:21:50 --> Total execution time: 0.0480
DEBUG - 2011-09-16 13:21:53 --> Config Class Initialized
DEBUG - 2011-09-16 13:21:53 --> Hooks Class Initialized
DEBUG - 2011-09-16 13:21:53 --> Utf8 Class Initialized
DEBUG - 2011-09-16 13:21:53 --> UTF-8 Support Enabled
DEBUG - 2011-09-16 13:21:53 --> URI Class Initialized
DEBUG - 2011-09-16 13:21:53 --> Router Class Initialized
DEBUG - 2011-09-16 13:21:53 --> Output Class Initialized
DEBUG - 2011-09-16 13:21:53 --> Input Class Initialized
DEBUG - 2011-09-16 13:21:53 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-16 13:21:53 --> Language Class Initialized
DEBUG - 2011-09-16 13:21:53 --> Loader Class Initialized
DEBUG - 2011-09-16 13:21:53 --> Controller Class Initialized
DEBUG - 2011-09-16 13:21:53 --> Model Class Initialized
DEBUG - 2011-09-16 13:21:53 --> Model Class Initialized
DEBUG - 2011-09-16 13:21:53 --> Model Class Initialized
DEBUG - 2011-09-16 13:21:53 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-16 13:21:53 --> Database Driver Class Initialized
DEBUG - 2011-09-16 13:21:53 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-16 13:21:53 --> Helper loaded: url_helper
DEBUG - 2011-09-16 13:21:53 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-16 13:21:53 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-16 13:21:53 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-16 13:21:53 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-16 13:21:53 --> Final output sent to browser
DEBUG - 2011-09-16 13:21:53 --> Total execution time: 0.2883
DEBUG - 2011-09-16 13:21:54 --> Config Class Initialized
DEBUG - 2011-09-16 13:21:54 --> Hooks Class Initialized
DEBUG - 2011-09-16 13:21:54 --> Utf8 Class Initialized
DEBUG - 2011-09-16 13:21:54 --> UTF-8 Support Enabled
DEBUG - 2011-09-16 13:21:54 --> URI Class Initialized
DEBUG - 2011-09-16 13:21:54 --> Router Class Initialized
DEBUG - 2011-09-16 13:21:54 --> Output Class Initialized
DEBUG - 2011-09-16 13:21:54 --> Input Class Initialized
DEBUG - 2011-09-16 13:21:54 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-16 13:21:54 --> Language Class Initialized
DEBUG - 2011-09-16 13:21:54 --> Loader Class Initialized
DEBUG - 2011-09-16 13:21:54 --> Controller Class Initialized
DEBUG - 2011-09-16 13:21:54 --> Model Class Initialized
DEBUG - 2011-09-16 13:21:54 --> Model Class Initialized
DEBUG - 2011-09-16 13:21:54 --> Model Class Initialized
DEBUG - 2011-09-16 13:21:54 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-16 13:21:54 --> Database Driver Class Initialized
DEBUG - 2011-09-16 13:21:54 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-16 13:21:54 --> Helper loaded: url_helper
DEBUG - 2011-09-16 13:21:54 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-16 13:21:54 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-16 13:21:54 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-16 13:21:54 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-16 13:21:54 --> Final output sent to browser
DEBUG - 2011-09-16 13:21:54 --> Total execution time: 0.0517
DEBUG - 2011-09-16 13:22:05 --> Config Class Initialized
DEBUG - 2011-09-16 13:22:05 --> Hooks Class Initialized
DEBUG - 2011-09-16 13:22:05 --> Utf8 Class Initialized
DEBUG - 2011-09-16 13:22:05 --> UTF-8 Support Enabled
DEBUG - 2011-09-16 13:22:05 --> URI Class Initialized
DEBUG - 2011-09-16 13:22:05 --> Router Class Initialized
DEBUG - 2011-09-16 13:22:05 --> Output Class Initialized
DEBUG - 2011-09-16 13:22:05 --> Input Class Initialized
DEBUG - 2011-09-16 13:22:05 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-16 13:22:05 --> Language Class Initialized
DEBUG - 2011-09-16 13:22:05 --> Loader Class Initialized
DEBUG - 2011-09-16 13:22:05 --> Controller Class Initialized
DEBUG - 2011-09-16 13:22:05 --> Model Class Initialized
DEBUG - 2011-09-16 13:22:05 --> Model Class Initialized
DEBUG - 2011-09-16 13:22:05 --> Model Class Initialized
DEBUG - 2011-09-16 13:22:05 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-16 13:22:05 --> Database Driver Class Initialized
DEBUG - 2011-09-16 13:22:05 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-16 13:22:05 --> Helper loaded: url_helper
DEBUG - 2011-09-16 13:22:05 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-16 13:22:05 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-16 13:22:05 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-16 13:22:05 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-16 13:22:05 --> Final output sent to browser
DEBUG - 2011-09-16 13:22:05 --> Total execution time: 0.3596
DEBUG - 2011-09-16 13:22:11 --> Config Class Initialized
DEBUG - 2011-09-16 13:22:11 --> Hooks Class Initialized
DEBUG - 2011-09-16 13:22:11 --> Utf8 Class Initialized
DEBUG - 2011-09-16 13:22:11 --> UTF-8 Support Enabled
DEBUG - 2011-09-16 13:22:11 --> URI Class Initialized
DEBUG - 2011-09-16 13:22:11 --> Router Class Initialized
DEBUG - 2011-09-16 13:22:11 --> Output Class Initialized
DEBUG - 2011-09-16 13:22:11 --> Input Class Initialized
DEBUG - 2011-09-16 13:22:11 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-16 13:22:11 --> Language Class Initialized
DEBUG - 2011-09-16 13:22:11 --> Loader Class Initialized
DEBUG - 2011-09-16 13:22:11 --> Controller Class Initialized
DEBUG - 2011-09-16 13:22:11 --> Model Class Initialized
DEBUG - 2011-09-16 13:22:11 --> Model Class Initialized
DEBUG - 2011-09-16 13:22:11 --> Model Class Initialized
DEBUG - 2011-09-16 13:22:11 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-16 13:22:11 --> Database Driver Class Initialized
DEBUG - 2011-09-16 13:22:11 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-16 13:22:11 --> Helper loaded: url_helper
DEBUG - 2011-09-16 13:22:11 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-16 13:22:11 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-16 13:22:11 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-16 13:22:11 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-16 13:22:11 --> Final output sent to browser
DEBUG - 2011-09-16 13:22:11 --> Total execution time: 0.0436
DEBUG - 2011-09-16 13:22:12 --> Config Class Initialized
DEBUG - 2011-09-16 13:22:12 --> Hooks Class Initialized
DEBUG - 2011-09-16 13:22:12 --> Utf8 Class Initialized
DEBUG - 2011-09-16 13:22:12 --> UTF-8 Support Enabled
DEBUG - 2011-09-16 13:22:12 --> URI Class Initialized
DEBUG - 2011-09-16 13:22:12 --> Router Class Initialized
DEBUG - 2011-09-16 13:22:12 --> Output Class Initialized
DEBUG - 2011-09-16 13:22:12 --> Input Class Initialized
DEBUG - 2011-09-16 13:22:12 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-16 13:22:12 --> Language Class Initialized
DEBUG - 2011-09-16 13:22:12 --> Loader Class Initialized
DEBUG - 2011-09-16 13:22:12 --> Controller Class Initialized
DEBUG - 2011-09-16 13:22:12 --> Model Class Initialized
DEBUG - 2011-09-16 13:22:12 --> Model Class Initialized
DEBUG - 2011-09-16 13:22:12 --> Model Class Initialized
DEBUG - 2011-09-16 13:22:12 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-16 13:22:12 --> Database Driver Class Initialized
DEBUG - 2011-09-16 13:22:12 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-16 13:22:12 --> Helper loaded: url_helper
DEBUG - 2011-09-16 13:22:12 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-16 13:22:12 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-16 13:22:12 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-16 13:22:12 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-16 13:22:12 --> Final output sent to browser
DEBUG - 2011-09-16 13:22:12 --> Total execution time: 0.0698
DEBUG - 2011-09-16 13:22:25 --> Config Class Initialized
DEBUG - 2011-09-16 13:22:25 --> Hooks Class Initialized
DEBUG - 2011-09-16 13:22:25 --> Utf8 Class Initialized
DEBUG - 2011-09-16 13:22:25 --> UTF-8 Support Enabled
DEBUG - 2011-09-16 13:22:25 --> URI Class Initialized
DEBUG - 2011-09-16 13:22:25 --> Router Class Initialized
DEBUG - 2011-09-16 13:22:25 --> Output Class Initialized
DEBUG - 2011-09-16 13:22:25 --> Input Class Initialized
DEBUG - 2011-09-16 13:22:25 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-16 13:22:25 --> Language Class Initialized
DEBUG - 2011-09-16 13:22:25 --> Loader Class Initialized
DEBUG - 2011-09-16 13:22:25 --> Controller Class Initialized
DEBUG - 2011-09-16 13:22:25 --> Model Class Initialized
DEBUG - 2011-09-16 13:22:25 --> Model Class Initialized
DEBUG - 2011-09-16 13:22:25 --> Model Class Initialized
DEBUG - 2011-09-16 13:22:25 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-16 13:22:25 --> Database Driver Class Initialized
DEBUG - 2011-09-16 13:22:25 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-16 13:22:25 --> Helper loaded: url_helper
DEBUG - 2011-09-16 13:22:25 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-16 13:22:25 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-16 13:22:25 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-16 13:22:25 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-16 13:22:25 --> Final output sent to browser
DEBUG - 2011-09-16 13:22:25 --> Total execution time: 0.2025
DEBUG - 2011-09-16 13:22:26 --> Config Class Initialized
DEBUG - 2011-09-16 13:22:26 --> Hooks Class Initialized
DEBUG - 2011-09-16 13:22:26 --> Utf8 Class Initialized
DEBUG - 2011-09-16 13:22:26 --> UTF-8 Support Enabled
DEBUG - 2011-09-16 13:22:26 --> URI Class Initialized
DEBUG - 2011-09-16 13:22:26 --> Router Class Initialized
DEBUG - 2011-09-16 13:22:26 --> Output Class Initialized
DEBUG - 2011-09-16 13:22:26 --> Input Class Initialized
DEBUG - 2011-09-16 13:22:26 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-16 13:22:26 --> Language Class Initialized
DEBUG - 2011-09-16 13:22:26 --> Loader Class Initialized
DEBUG - 2011-09-16 13:22:26 --> Controller Class Initialized
DEBUG - 2011-09-16 13:22:26 --> Model Class Initialized
DEBUG - 2011-09-16 13:22:26 --> Model Class Initialized
DEBUG - 2011-09-16 13:22:26 --> Model Class Initialized
DEBUG - 2011-09-16 13:22:26 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-16 13:22:26 --> Database Driver Class Initialized
DEBUG - 2011-09-16 13:22:26 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-16 13:22:26 --> Helper loaded: url_helper
DEBUG - 2011-09-16 13:22:26 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-16 13:22:26 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-16 13:22:26 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-16 13:22:26 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-16 13:22:26 --> Final output sent to browser
DEBUG - 2011-09-16 13:22:26 --> Total execution time: 0.0503
DEBUG - 2011-09-16 13:22:57 --> Config Class Initialized
DEBUG - 2011-09-16 13:22:57 --> Hooks Class Initialized
DEBUG - 2011-09-16 13:22:57 --> Utf8 Class Initialized
DEBUG - 2011-09-16 13:22:57 --> UTF-8 Support Enabled
DEBUG - 2011-09-16 13:22:57 --> URI Class Initialized
DEBUG - 2011-09-16 13:22:57 --> Router Class Initialized
DEBUG - 2011-09-16 13:22:57 --> Output Class Initialized
DEBUG - 2011-09-16 13:22:57 --> Input Class Initialized
DEBUG - 2011-09-16 13:22:57 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-16 13:22:57 --> Language Class Initialized
DEBUG - 2011-09-16 13:22:57 --> Loader Class Initialized
DEBUG - 2011-09-16 13:22:57 --> Controller Class Initialized
DEBUG - 2011-09-16 13:22:57 --> Model Class Initialized
DEBUG - 2011-09-16 13:22:57 --> Model Class Initialized
DEBUG - 2011-09-16 13:22:57 --> Model Class Initialized
DEBUG - 2011-09-16 13:22:57 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-16 13:22:57 --> Database Driver Class Initialized
DEBUG - 2011-09-16 13:22:57 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-16 13:22:57 --> Helper loaded: url_helper
DEBUG - 2011-09-16 13:22:57 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-16 13:22:57 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-16 13:22:57 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-16 13:22:57 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-16 13:22:57 --> Final output sent to browser
DEBUG - 2011-09-16 13:22:57 --> Total execution time: 0.2137
DEBUG - 2011-09-16 13:23:29 --> Config Class Initialized
DEBUG - 2011-09-16 13:23:29 --> Hooks Class Initialized
DEBUG - 2011-09-16 13:23:29 --> Utf8 Class Initialized
DEBUG - 2011-09-16 13:23:29 --> UTF-8 Support Enabled
DEBUG - 2011-09-16 13:23:29 --> URI Class Initialized
DEBUG - 2011-09-16 13:23:29 --> Router Class Initialized
DEBUG - 2011-09-16 13:23:29 --> Output Class Initialized
DEBUG - 2011-09-16 13:23:29 --> Input Class Initialized
DEBUG - 2011-09-16 13:23:29 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-16 13:23:29 --> Language Class Initialized
DEBUG - 2011-09-16 13:23:29 --> Loader Class Initialized
DEBUG - 2011-09-16 13:23:29 --> Controller Class Initialized
DEBUG - 2011-09-16 13:23:29 --> Model Class Initialized
DEBUG - 2011-09-16 13:23:29 --> Model Class Initialized
DEBUG - 2011-09-16 13:23:29 --> Model Class Initialized
DEBUG - 2011-09-16 13:23:29 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-16 13:23:29 --> Database Driver Class Initialized
DEBUG - 2011-09-16 13:23:29 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-16 13:23:29 --> Helper loaded: url_helper
DEBUG - 2011-09-16 13:23:29 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-16 13:23:29 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-16 13:23:29 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-16 13:23:29 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-16 13:23:29 --> Final output sent to browser
DEBUG - 2011-09-16 13:23:29 --> Total execution time: 0.0911
DEBUG - 2011-09-16 13:51:06 --> Config Class Initialized
DEBUG - 2011-09-16 13:51:06 --> Hooks Class Initialized
DEBUG - 2011-09-16 13:51:06 --> Utf8 Class Initialized
DEBUG - 2011-09-16 13:51:06 --> UTF-8 Support Enabled
DEBUG - 2011-09-16 13:51:06 --> URI Class Initialized
DEBUG - 2011-09-16 13:51:06 --> Router Class Initialized
DEBUG - 2011-09-16 13:51:06 --> Output Class Initialized
DEBUG - 2011-09-16 13:51:06 --> Input Class Initialized
DEBUG - 2011-09-16 13:51:06 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-16 13:51:06 --> Language Class Initialized
DEBUG - 2011-09-16 13:51:06 --> Loader Class Initialized
DEBUG - 2011-09-16 13:51:06 --> Controller Class Initialized
DEBUG - 2011-09-16 13:51:06 --> Model Class Initialized
DEBUG - 2011-09-16 13:51:06 --> Model Class Initialized
DEBUG - 2011-09-16 13:51:06 --> Model Class Initialized
DEBUG - 2011-09-16 13:51:06 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-16 13:51:06 --> Database Driver Class Initialized
DEBUG - 2011-09-16 13:51:07 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-16 13:51:07 --> Helper loaded: url_helper
DEBUG - 2011-09-16 13:51:07 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-16 13:51:07 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-16 13:51:07 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-16 13:51:07 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-16 13:51:07 --> Final output sent to browser
DEBUG - 2011-09-16 13:51:07 --> Total execution time: 0.2775
DEBUG - 2011-09-16 13:51:08 --> Config Class Initialized
DEBUG - 2011-09-16 13:51:08 --> Hooks Class Initialized
DEBUG - 2011-09-16 13:51:08 --> Utf8 Class Initialized
DEBUG - 2011-09-16 13:51:08 --> UTF-8 Support Enabled
DEBUG - 2011-09-16 13:51:08 --> URI Class Initialized
DEBUG - 2011-09-16 13:51:08 --> Router Class Initialized
DEBUG - 2011-09-16 13:51:08 --> Output Class Initialized
DEBUG - 2011-09-16 13:51:08 --> Input Class Initialized
DEBUG - 2011-09-16 13:51:08 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-16 13:51:08 --> Language Class Initialized
DEBUG - 2011-09-16 13:51:08 --> Loader Class Initialized
DEBUG - 2011-09-16 13:51:08 --> Controller Class Initialized
ERROR - 2011-09-16 13:51:08 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-16 13:51:08 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-16 13:51:08 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-16 13:51:08 --> Model Class Initialized
DEBUG - 2011-09-16 13:51:08 --> Model Class Initialized
DEBUG - 2011-09-16 13:51:08 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-16 13:51:08 --> Database Driver Class Initialized
DEBUG - 2011-09-16 13:51:08 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-16 13:51:08 --> Helper loaded: url_helper
DEBUG - 2011-09-16 13:51:08 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-16 13:51:08 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-16 13:51:08 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-16 13:51:08 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-16 13:51:08 --> Final output sent to browser
DEBUG - 2011-09-16 13:51:08 --> Total execution time: 0.0379
DEBUG - 2011-09-16 13:51:15 --> Config Class Initialized
DEBUG - 2011-09-16 13:51:15 --> Hooks Class Initialized
DEBUG - 2011-09-16 13:51:15 --> Utf8 Class Initialized
DEBUG - 2011-09-16 13:51:15 --> UTF-8 Support Enabled
DEBUG - 2011-09-16 13:51:15 --> URI Class Initialized
DEBUG - 2011-09-16 13:51:15 --> Router Class Initialized
DEBUG - 2011-09-16 13:51:15 --> Output Class Initialized
DEBUG - 2011-09-16 13:51:15 --> Input Class Initialized
DEBUG - 2011-09-16 13:51:15 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-16 13:51:15 --> Language Class Initialized
DEBUG - 2011-09-16 13:51:15 --> Loader Class Initialized
DEBUG - 2011-09-16 13:51:15 --> Controller Class Initialized
DEBUG - 2011-09-16 13:51:15 --> Model Class Initialized
DEBUG - 2011-09-16 13:51:15 --> Model Class Initialized
DEBUG - 2011-09-16 13:51:15 --> Model Class Initialized
DEBUG - 2011-09-16 13:51:15 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-16 13:51:16 --> Database Driver Class Initialized
DEBUG - 2011-09-16 13:51:16 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-16 13:51:16 --> Helper loaded: url_helper
DEBUG - 2011-09-16 13:51:16 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-16 13:51:16 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-16 13:51:16 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-16 13:51:16 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-16 13:51:16 --> Final output sent to browser
DEBUG - 2011-09-16 13:51:16 --> Total execution time: 0.0653
DEBUG - 2011-09-16 13:51:17 --> Config Class Initialized
DEBUG - 2011-09-16 13:51:17 --> Hooks Class Initialized
DEBUG - 2011-09-16 13:51:17 --> Utf8 Class Initialized
DEBUG - 2011-09-16 13:51:17 --> UTF-8 Support Enabled
DEBUG - 2011-09-16 13:51:17 --> URI Class Initialized
DEBUG - 2011-09-16 13:51:17 --> Router Class Initialized
DEBUG - 2011-09-16 13:51:17 --> Output Class Initialized
DEBUG - 2011-09-16 13:51:17 --> Input Class Initialized
DEBUG - 2011-09-16 13:51:17 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-16 13:51:17 --> Language Class Initialized
DEBUG - 2011-09-16 13:51:17 --> Loader Class Initialized
DEBUG - 2011-09-16 13:51:17 --> Controller Class Initialized
ERROR - 2011-09-16 13:51:17 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-16 13:51:17 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-16 13:51:17 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-16 13:51:17 --> Model Class Initialized
DEBUG - 2011-09-16 13:51:17 --> Model Class Initialized
DEBUG - 2011-09-16 13:51:17 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-16 13:51:17 --> Database Driver Class Initialized
DEBUG - 2011-09-16 13:51:17 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-16 13:51:17 --> Helper loaded: url_helper
DEBUG - 2011-09-16 13:51:17 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-16 13:51:17 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-16 13:51:17 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-16 13:51:17 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-16 13:51:17 --> Final output sent to browser
DEBUG - 2011-09-16 13:51:17 --> Total execution time: 0.0304
DEBUG - 2011-09-16 14:01:56 --> Config Class Initialized
DEBUG - 2011-09-16 14:01:56 --> Hooks Class Initialized
DEBUG - 2011-09-16 14:01:56 --> Utf8 Class Initialized
DEBUG - 2011-09-16 14:01:56 --> UTF-8 Support Enabled
DEBUG - 2011-09-16 14:01:56 --> URI Class Initialized
DEBUG - 2011-09-16 14:01:56 --> Router Class Initialized
DEBUG - 2011-09-16 14:01:56 --> Output Class Initialized
DEBUG - 2011-09-16 14:01:56 --> Input Class Initialized
DEBUG - 2011-09-16 14:01:56 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-16 14:01:56 --> Language Class Initialized
DEBUG - 2011-09-16 14:01:56 --> Loader Class Initialized
DEBUG - 2011-09-16 14:01:56 --> Controller Class Initialized
DEBUG - 2011-09-16 14:01:56 --> Model Class Initialized
DEBUG - 2011-09-16 14:01:56 --> Model Class Initialized
DEBUG - 2011-09-16 14:01:56 --> Model Class Initialized
DEBUG - 2011-09-16 14:01:56 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-16 14:01:56 --> Database Driver Class Initialized
DEBUG - 2011-09-16 14:01:56 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-16 14:01:56 --> Helper loaded: url_helper
DEBUG - 2011-09-16 14:01:56 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-16 14:01:56 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-16 14:01:56 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-16 14:01:56 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-16 14:01:56 --> Final output sent to browser
DEBUG - 2011-09-16 14:01:56 --> Total execution time: 0.0636
DEBUG - 2011-09-16 14:02:03 --> Config Class Initialized
DEBUG - 2011-09-16 14:02:03 --> Hooks Class Initialized
DEBUG - 2011-09-16 14:02:03 --> Utf8 Class Initialized
DEBUG - 2011-09-16 14:02:03 --> UTF-8 Support Enabled
DEBUG - 2011-09-16 14:02:03 --> URI Class Initialized
DEBUG - 2011-09-16 14:02:03 --> Router Class Initialized
DEBUG - 2011-09-16 14:02:03 --> Output Class Initialized
DEBUG - 2011-09-16 14:02:03 --> Input Class Initialized
DEBUG - 2011-09-16 14:02:03 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-16 14:02:03 --> Language Class Initialized
DEBUG - 2011-09-16 14:02:03 --> Loader Class Initialized
DEBUG - 2011-09-16 14:02:03 --> Controller Class Initialized
ERROR - 2011-09-16 14:02:03 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-16 14:02:03 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-16 14:02:03 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-16 14:02:03 --> Model Class Initialized
DEBUG - 2011-09-16 14:02:03 --> Model Class Initialized
DEBUG - 2011-09-16 14:02:03 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-16 14:02:03 --> Database Driver Class Initialized
DEBUG - 2011-09-16 14:02:03 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-16 14:02:03 --> Helper loaded: url_helper
DEBUG - 2011-09-16 14:02:03 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-16 14:02:03 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-16 14:02:03 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-16 14:02:03 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-16 14:02:03 --> Final output sent to browser
DEBUG - 2011-09-16 14:02:03 --> Total execution time: 0.0315
DEBUG - 2011-09-16 14:17:16 --> Config Class Initialized
DEBUG - 2011-09-16 14:17:16 --> Hooks Class Initialized
DEBUG - 2011-09-16 14:17:16 --> Utf8 Class Initialized
DEBUG - 2011-09-16 14:17:16 --> UTF-8 Support Enabled
DEBUG - 2011-09-16 14:17:16 --> URI Class Initialized
DEBUG - 2011-09-16 14:17:16 --> Router Class Initialized
DEBUG - 2011-09-16 14:17:16 --> Output Class Initialized
DEBUG - 2011-09-16 14:17:16 --> Input Class Initialized
DEBUG - 2011-09-16 14:17:16 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-16 14:17:16 --> Language Class Initialized
DEBUG - 2011-09-16 14:17:16 --> Loader Class Initialized
DEBUG - 2011-09-16 14:17:16 --> Controller Class Initialized
ERROR - 2011-09-16 14:17:16 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-16 14:17:16 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-16 14:17:16 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-16 14:17:16 --> Model Class Initialized
DEBUG - 2011-09-16 14:17:16 --> Model Class Initialized
DEBUG - 2011-09-16 14:17:16 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-16 14:17:16 --> Database Driver Class Initialized
DEBUG - 2011-09-16 14:17:16 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-16 14:17:16 --> Helper loaded: url_helper
DEBUG - 2011-09-16 14:17:16 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-16 14:17:16 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-16 14:17:16 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-16 14:17:16 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-16 14:17:16 --> Final output sent to browser
DEBUG - 2011-09-16 14:17:16 --> Total execution time: 0.0318
DEBUG - 2011-09-16 14:17:18 --> Config Class Initialized
DEBUG - 2011-09-16 14:17:18 --> Hooks Class Initialized
DEBUG - 2011-09-16 14:17:18 --> Utf8 Class Initialized
DEBUG - 2011-09-16 14:17:18 --> UTF-8 Support Enabled
DEBUG - 2011-09-16 14:17:18 --> URI Class Initialized
DEBUG - 2011-09-16 14:17:18 --> Router Class Initialized
DEBUG - 2011-09-16 14:17:18 --> Output Class Initialized
DEBUG - 2011-09-16 14:17:18 --> Input Class Initialized
DEBUG - 2011-09-16 14:17:18 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-16 14:17:18 --> Language Class Initialized
DEBUG - 2011-09-16 14:17:18 --> Loader Class Initialized
DEBUG - 2011-09-16 14:17:18 --> Controller Class Initialized
DEBUG - 2011-09-16 14:17:18 --> Model Class Initialized
DEBUG - 2011-09-16 14:17:18 --> Model Class Initialized
DEBUG - 2011-09-16 14:17:18 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-16 14:17:18 --> Database Driver Class Initialized
DEBUG - 2011-09-16 14:17:19 --> Final output sent to browser
DEBUG - 2011-09-16 14:17:19 --> Total execution time: 1.4467
DEBUG - 2011-09-16 14:17:21 --> Config Class Initialized
DEBUG - 2011-09-16 14:17:21 --> Hooks Class Initialized
DEBUG - 2011-09-16 14:17:21 --> Utf8 Class Initialized
DEBUG - 2011-09-16 14:17:21 --> UTF-8 Support Enabled
DEBUG - 2011-09-16 14:17:21 --> URI Class Initialized
DEBUG - 2011-09-16 14:17:21 --> Router Class Initialized
ERROR - 2011-09-16 14:17:21 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-16 16:13:43 --> Config Class Initialized
DEBUG - 2011-09-16 16:13:43 --> Hooks Class Initialized
DEBUG - 2011-09-16 16:13:43 --> Utf8 Class Initialized
DEBUG - 2011-09-16 16:13:43 --> UTF-8 Support Enabled
DEBUG - 2011-09-16 16:13:43 --> URI Class Initialized
DEBUG - 2011-09-16 16:13:43 --> Router Class Initialized
DEBUG - 2011-09-16 16:13:43 --> No URI present. Default controller set.
DEBUG - 2011-09-16 16:13:43 --> Output Class Initialized
DEBUG - 2011-09-16 16:13:43 --> Input Class Initialized
DEBUG - 2011-09-16 16:13:43 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-16 16:13:43 --> Language Class Initialized
DEBUG - 2011-09-16 16:13:43 --> Loader Class Initialized
DEBUG - 2011-09-16 16:13:43 --> Controller Class Initialized
DEBUG - 2011-09-16 16:13:43 --> File loaded: application/views/splash/main.php
DEBUG - 2011-09-16 16:13:43 --> Helper loaded: url_helper
DEBUG - 2011-09-16 16:13:43 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-16 16:13:43 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-16 16:13:43 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-16 16:13:43 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-16 16:13:43 --> Final output sent to browser
DEBUG - 2011-09-16 16:13:43 --> Total execution time: 0.0979
DEBUG - 2011-09-16 16:44:10 --> Config Class Initialized
DEBUG - 2011-09-16 16:44:10 --> Hooks Class Initialized
DEBUG - 2011-09-16 16:44:10 --> Utf8 Class Initialized
DEBUG - 2011-09-16 16:44:10 --> UTF-8 Support Enabled
DEBUG - 2011-09-16 16:44:10 --> URI Class Initialized
DEBUG - 2011-09-16 16:44:10 --> Router Class Initialized
DEBUG - 2011-09-16 16:44:10 --> Output Class Initialized
DEBUG - 2011-09-16 16:44:10 --> Input Class Initialized
DEBUG - 2011-09-16 16:44:10 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-16 16:44:10 --> Language Class Initialized
DEBUG - 2011-09-16 16:44:10 --> Loader Class Initialized
DEBUG - 2011-09-16 16:44:10 --> Controller Class Initialized
ERROR - 2011-09-16 16:44:10 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-16 16:44:10 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-16 16:44:10 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-16 16:44:10 --> Model Class Initialized
DEBUG - 2011-09-16 16:44:10 --> Model Class Initialized
DEBUG - 2011-09-16 16:44:10 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-16 16:44:10 --> Database Driver Class Initialized
DEBUG - 2011-09-16 16:44:10 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-16 16:44:10 --> Helper loaded: url_helper
DEBUG - 2011-09-16 16:44:10 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-16 16:44:10 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-16 16:44:10 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-16 16:44:10 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-16 16:44:10 --> Final output sent to browser
DEBUG - 2011-09-16 16:44:10 --> Total execution time: 0.5180
DEBUG - 2011-09-16 16:44:15 --> Config Class Initialized
DEBUG - 2011-09-16 16:44:15 --> Hooks Class Initialized
DEBUG - 2011-09-16 16:44:15 --> Utf8 Class Initialized
DEBUG - 2011-09-16 16:44:15 --> UTF-8 Support Enabled
DEBUG - 2011-09-16 16:44:15 --> URI Class Initialized
DEBUG - 2011-09-16 16:44:15 --> Router Class Initialized
DEBUG - 2011-09-16 16:44:15 --> Output Class Initialized
DEBUG - 2011-09-16 16:44:15 --> Input Class Initialized
DEBUG - 2011-09-16 16:44:15 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-16 16:44:15 --> Language Class Initialized
DEBUG - 2011-09-16 16:44:15 --> Loader Class Initialized
DEBUG - 2011-09-16 16:44:15 --> Controller Class Initialized
DEBUG - 2011-09-16 16:44:15 --> Model Class Initialized
DEBUG - 2011-09-16 16:44:15 --> Model Class Initialized
DEBUG - 2011-09-16 16:44:15 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-16 16:44:15 --> Database Driver Class Initialized
DEBUG - 2011-09-16 16:44:15 --> Final output sent to browser
DEBUG - 2011-09-16 16:44:15 --> Total execution time: 0.6293
DEBUG - 2011-09-16 16:44:18 --> Config Class Initialized
DEBUG - 2011-09-16 16:44:18 --> Hooks Class Initialized
DEBUG - 2011-09-16 16:44:18 --> Utf8 Class Initialized
DEBUG - 2011-09-16 16:44:18 --> UTF-8 Support Enabled
DEBUG - 2011-09-16 16:44:18 --> URI Class Initialized
DEBUG - 2011-09-16 16:44:18 --> Router Class Initialized
ERROR - 2011-09-16 16:44:18 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-16 16:44:27 --> Config Class Initialized
DEBUG - 2011-09-16 16:44:27 --> Hooks Class Initialized
DEBUG - 2011-09-16 16:44:27 --> Utf8 Class Initialized
DEBUG - 2011-09-16 16:44:27 --> UTF-8 Support Enabled
DEBUG - 2011-09-16 16:44:27 --> URI Class Initialized
DEBUG - 2011-09-16 16:44:27 --> Router Class Initialized
DEBUG - 2011-09-16 16:44:27 --> Output Class Initialized
DEBUG - 2011-09-16 16:44:27 --> Input Class Initialized
DEBUG - 2011-09-16 16:44:27 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-16 16:44:27 --> Language Class Initialized
DEBUG - 2011-09-16 16:44:27 --> Loader Class Initialized
DEBUG - 2011-09-16 16:44:27 --> Controller Class Initialized
DEBUG - 2011-09-16 16:44:27 --> Model Class Initialized
DEBUG - 2011-09-16 16:44:27 --> Model Class Initialized
DEBUG - 2011-09-16 16:44:27 --> Model Class Initialized
DEBUG - 2011-09-16 16:44:27 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-16 16:44:27 --> Database Driver Class Initialized
DEBUG - 2011-09-16 16:44:27 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-16 16:44:27 --> Helper loaded: url_helper
DEBUG - 2011-09-16 16:44:27 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-16 16:44:27 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-16 16:44:27 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-16 16:44:27 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-16 16:44:27 --> Final output sent to browser
DEBUG - 2011-09-16 16:44:27 --> Total execution time: 0.5274
DEBUG - 2011-09-16 16:44:29 --> Config Class Initialized
DEBUG - 2011-09-16 16:44:29 --> Hooks Class Initialized
DEBUG - 2011-09-16 16:44:29 --> Utf8 Class Initialized
DEBUG - 2011-09-16 16:44:29 --> UTF-8 Support Enabled
DEBUG - 2011-09-16 16:44:29 --> URI Class Initialized
DEBUG - 2011-09-16 16:44:29 --> Router Class Initialized
ERROR - 2011-09-16 16:44:29 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-16 17:13:27 --> Config Class Initialized
DEBUG - 2011-09-16 17:13:27 --> Hooks Class Initialized
DEBUG - 2011-09-16 17:13:27 --> Utf8 Class Initialized
DEBUG - 2011-09-16 17:13:27 --> UTF-8 Support Enabled
DEBUG - 2011-09-16 17:13:27 --> URI Class Initialized
DEBUG - 2011-09-16 17:13:27 --> Router Class Initialized
ERROR - 2011-09-16 17:13:27 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-09-16 17:13:28 --> Config Class Initialized
DEBUG - 2011-09-16 17:13:28 --> Hooks Class Initialized
DEBUG - 2011-09-16 17:13:28 --> Utf8 Class Initialized
DEBUG - 2011-09-16 17:13:28 --> UTF-8 Support Enabled
DEBUG - 2011-09-16 17:13:28 --> URI Class Initialized
DEBUG - 2011-09-16 17:13:28 --> Router Class Initialized
DEBUG - 2011-09-16 17:13:28 --> No URI present. Default controller set.
DEBUG - 2011-09-16 17:13:28 --> Output Class Initialized
DEBUG - 2011-09-16 17:13:28 --> Input Class Initialized
DEBUG - 2011-09-16 17:13:28 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-16 17:13:28 --> Language Class Initialized
DEBUG - 2011-09-16 17:13:28 --> Loader Class Initialized
DEBUG - 2011-09-16 17:13:28 --> Controller Class Initialized
DEBUG - 2011-09-16 17:13:28 --> File loaded: application/views/splash/main.php
DEBUG - 2011-09-16 17:13:28 --> Helper loaded: url_helper
DEBUG - 2011-09-16 17:13:28 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-16 17:13:28 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-16 17:13:28 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-16 17:13:28 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-16 17:13:28 --> Final output sent to browser
DEBUG - 2011-09-16 17:13:28 --> Total execution time: 0.0132
DEBUG - 2011-09-16 17:57:00 --> Config Class Initialized
DEBUG - 2011-09-16 17:57:00 --> Hooks Class Initialized
DEBUG - 2011-09-16 17:57:00 --> Utf8 Class Initialized
DEBUG - 2011-09-16 17:57:00 --> UTF-8 Support Enabled
DEBUG - 2011-09-16 17:57:00 --> URI Class Initialized
DEBUG - 2011-09-16 17:57:00 --> Router Class Initialized
DEBUG - 2011-09-16 17:57:00 --> Output Class Initialized
DEBUG - 2011-09-16 17:57:00 --> Input Class Initialized
DEBUG - 2011-09-16 17:57:00 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-16 17:57:00 --> Language Class Initialized
DEBUG - 2011-09-16 17:57:00 --> Loader Class Initialized
DEBUG - 2011-09-16 17:57:00 --> Controller Class Initialized
ERROR - 2011-09-16 17:57:00 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-16 17:57:00 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-16 17:57:00 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-16 17:57:00 --> Model Class Initialized
DEBUG - 2011-09-16 17:57:00 --> Model Class Initialized
DEBUG - 2011-09-16 17:57:00 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-16 17:57:00 --> Database Driver Class Initialized
DEBUG - 2011-09-16 17:57:00 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-16 17:57:00 --> Helper loaded: url_helper
DEBUG - 2011-09-16 17:57:00 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-16 17:57:00 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-16 17:57:00 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-16 17:57:00 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-16 17:57:00 --> Final output sent to browser
DEBUG - 2011-09-16 17:57:00 --> Total execution time: 0.0559
DEBUG - 2011-09-16 17:57:01 --> Config Class Initialized
DEBUG - 2011-09-16 17:57:01 --> Hooks Class Initialized
DEBUG - 2011-09-16 17:57:01 --> Utf8 Class Initialized
DEBUG - 2011-09-16 17:57:01 --> UTF-8 Support Enabled
DEBUG - 2011-09-16 17:57:01 --> URI Class Initialized
DEBUG - 2011-09-16 17:57:01 --> Router Class Initialized
DEBUG - 2011-09-16 17:57:01 --> Output Class Initialized
DEBUG - 2011-09-16 17:57:01 --> Input Class Initialized
DEBUG - 2011-09-16 17:57:01 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-16 17:57:01 --> Language Class Initialized
DEBUG - 2011-09-16 17:57:01 --> Loader Class Initialized
DEBUG - 2011-09-16 17:57:01 --> Controller Class Initialized
DEBUG - 2011-09-16 17:57:01 --> Model Class Initialized
DEBUG - 2011-09-16 17:57:01 --> Model Class Initialized
DEBUG - 2011-09-16 17:57:01 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-16 17:57:01 --> Database Driver Class Initialized
DEBUG - 2011-09-16 17:57:01 --> Final output sent to browser
DEBUG - 2011-09-16 17:57:01 --> Total execution time: 0.6050
DEBUG - 2011-09-16 17:57:04 --> Config Class Initialized
DEBUG - 2011-09-16 17:57:04 --> Hooks Class Initialized
DEBUG - 2011-09-16 17:57:04 --> Utf8 Class Initialized
DEBUG - 2011-09-16 17:57:04 --> UTF-8 Support Enabled
DEBUG - 2011-09-16 17:57:04 --> URI Class Initialized
DEBUG - 2011-09-16 17:57:04 --> Router Class Initialized
DEBUG - 2011-09-16 17:57:04 --> Output Class Initialized
DEBUG - 2011-09-16 17:57:04 --> Input Class Initialized
DEBUG - 2011-09-16 17:57:04 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-16 17:57:04 --> Language Class Initialized
DEBUG - 2011-09-16 17:57:04 --> Loader Class Initialized
DEBUG - 2011-09-16 17:57:04 --> Controller Class Initialized
ERROR - 2011-09-16 17:57:04 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-16 17:57:04 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-16 17:57:04 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-16 17:57:04 --> Model Class Initialized
DEBUG - 2011-09-16 17:57:04 --> Model Class Initialized
DEBUG - 2011-09-16 17:57:04 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-16 17:57:04 --> Database Driver Class Initialized
DEBUG - 2011-09-16 17:57:04 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-16 17:57:04 --> Helper loaded: url_helper
DEBUG - 2011-09-16 17:57:04 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-16 17:57:04 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-16 17:57:04 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-16 17:57:04 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-16 17:57:04 --> Final output sent to browser
DEBUG - 2011-09-16 17:57:04 --> Total execution time: 0.0296
DEBUG - 2011-09-16 17:57:06 --> Config Class Initialized
DEBUG - 2011-09-16 17:57:06 --> Hooks Class Initialized
DEBUG - 2011-09-16 17:57:06 --> Utf8 Class Initialized
DEBUG - 2011-09-16 17:57:06 --> UTF-8 Support Enabled
DEBUG - 2011-09-16 17:57:06 --> URI Class Initialized
DEBUG - 2011-09-16 17:57:06 --> Router Class Initialized
DEBUG - 2011-09-16 17:57:06 --> Output Class Initialized
DEBUG - 2011-09-16 17:57:06 --> Input Class Initialized
DEBUG - 2011-09-16 17:57:06 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-16 17:57:06 --> Language Class Initialized
DEBUG - 2011-09-16 17:57:06 --> Loader Class Initialized
DEBUG - 2011-09-16 17:57:06 --> Controller Class Initialized
DEBUG - 2011-09-16 17:57:06 --> Model Class Initialized
DEBUG - 2011-09-16 17:57:06 --> Model Class Initialized
DEBUG - 2011-09-16 17:57:06 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-16 17:57:06 --> Database Driver Class Initialized
DEBUG - 2011-09-16 17:57:07 --> Final output sent to browser
DEBUG - 2011-09-16 17:57:07 --> Total execution time: 0.5205
DEBUG - 2011-09-16 17:57:14 --> Config Class Initialized
DEBUG - 2011-09-16 17:57:14 --> Hooks Class Initialized
DEBUG - 2011-09-16 17:57:14 --> Utf8 Class Initialized
DEBUG - 2011-09-16 17:57:14 --> UTF-8 Support Enabled
DEBUG - 2011-09-16 17:57:14 --> URI Class Initialized
DEBUG - 2011-09-16 17:57:14 --> Router Class Initialized
DEBUG - 2011-09-16 17:57:14 --> Output Class Initialized
DEBUG - 2011-09-16 17:57:14 --> Input Class Initialized
DEBUG - 2011-09-16 17:57:14 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-16 17:57:14 --> Language Class Initialized
DEBUG - 2011-09-16 17:57:14 --> Loader Class Initialized
DEBUG - 2011-09-16 17:57:14 --> Controller Class Initialized
ERROR - 2011-09-16 17:57:14 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-16 17:57:14 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-16 17:57:14 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-16 17:57:14 --> Model Class Initialized
DEBUG - 2011-09-16 17:57:14 --> Model Class Initialized
DEBUG - 2011-09-16 17:57:14 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-16 17:57:14 --> Database Driver Class Initialized
DEBUG - 2011-09-16 17:57:14 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-16 17:57:14 --> Helper loaded: url_helper
DEBUG - 2011-09-16 17:57:14 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-16 17:57:14 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-16 17:57:14 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-16 17:57:14 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-16 17:57:14 --> Final output sent to browser
DEBUG - 2011-09-16 17:57:14 --> Total execution time: 0.0296
DEBUG - 2011-09-16 17:57:15 --> Config Class Initialized
DEBUG - 2011-09-16 17:57:15 --> Hooks Class Initialized
DEBUG - 2011-09-16 17:57:15 --> Utf8 Class Initialized
DEBUG - 2011-09-16 17:57:15 --> UTF-8 Support Enabled
DEBUG - 2011-09-16 17:57:15 --> URI Class Initialized
DEBUG - 2011-09-16 17:57:15 --> Router Class Initialized
DEBUG - 2011-09-16 17:57:15 --> Output Class Initialized
DEBUG - 2011-09-16 17:57:15 --> Input Class Initialized
DEBUG - 2011-09-16 17:57:15 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-16 17:57:15 --> Language Class Initialized
DEBUG - 2011-09-16 17:57:15 --> Loader Class Initialized
DEBUG - 2011-09-16 17:57:15 --> Controller Class Initialized
DEBUG - 2011-09-16 17:57:15 --> Model Class Initialized
DEBUG - 2011-09-16 17:57:15 --> Model Class Initialized
DEBUG - 2011-09-16 17:57:15 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-16 17:57:15 --> Database Driver Class Initialized
DEBUG - 2011-09-16 17:57:16 --> Final output sent to browser
DEBUG - 2011-09-16 17:57:16 --> Total execution time: 0.6693
DEBUG - 2011-09-16 17:58:19 --> Config Class Initialized
DEBUG - 2011-09-16 17:58:19 --> Hooks Class Initialized
DEBUG - 2011-09-16 17:58:19 --> Utf8 Class Initialized
DEBUG - 2011-09-16 17:58:19 --> UTF-8 Support Enabled
DEBUG - 2011-09-16 17:58:19 --> URI Class Initialized
DEBUG - 2011-09-16 17:58:19 --> Router Class Initialized
DEBUG - 2011-09-16 17:58:19 --> Output Class Initialized
DEBUG - 2011-09-16 17:58:19 --> Input Class Initialized
DEBUG - 2011-09-16 17:58:19 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-16 17:58:19 --> Language Class Initialized
DEBUG - 2011-09-16 17:58:19 --> Loader Class Initialized
DEBUG - 2011-09-16 17:58:19 --> Controller Class Initialized
ERROR - 2011-09-16 17:58:19 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-16 17:58:19 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-16 17:58:19 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-16 17:58:19 --> Model Class Initialized
DEBUG - 2011-09-16 17:58:19 --> Model Class Initialized
DEBUG - 2011-09-16 17:58:19 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-16 17:58:19 --> Database Driver Class Initialized
DEBUG - 2011-09-16 17:58:19 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-16 17:58:19 --> Helper loaded: url_helper
DEBUG - 2011-09-16 17:58:19 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-16 17:58:19 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-16 17:58:19 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-16 17:58:19 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-16 17:58:19 --> Final output sent to browser
DEBUG - 2011-09-16 17:58:19 --> Total execution time: 0.0379
DEBUG - 2011-09-16 17:58:20 --> Config Class Initialized
DEBUG - 2011-09-16 17:58:20 --> Hooks Class Initialized
DEBUG - 2011-09-16 17:58:20 --> Utf8 Class Initialized
DEBUG - 2011-09-16 17:58:20 --> UTF-8 Support Enabled
DEBUG - 2011-09-16 17:58:20 --> URI Class Initialized
DEBUG - 2011-09-16 17:58:20 --> Router Class Initialized
DEBUG - 2011-09-16 17:58:20 --> Output Class Initialized
DEBUG - 2011-09-16 17:58:20 --> Input Class Initialized
DEBUG - 2011-09-16 17:58:20 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-16 17:58:20 --> Language Class Initialized
DEBUG - 2011-09-16 17:58:20 --> Loader Class Initialized
DEBUG - 2011-09-16 17:58:20 --> Controller Class Initialized
DEBUG - 2011-09-16 17:58:20 --> Model Class Initialized
DEBUG - 2011-09-16 17:58:20 --> Model Class Initialized
DEBUG - 2011-09-16 17:58:20 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-16 17:58:20 --> Database Driver Class Initialized
DEBUG - 2011-09-16 17:58:20 --> Final output sent to browser
DEBUG - 2011-09-16 17:58:20 --> Total execution time: 0.5073
DEBUG - 2011-09-16 18:21:42 --> Config Class Initialized
DEBUG - 2011-09-16 18:21:42 --> Hooks Class Initialized
DEBUG - 2011-09-16 18:21:42 --> Utf8 Class Initialized
DEBUG - 2011-09-16 18:21:42 --> UTF-8 Support Enabled
DEBUG - 2011-09-16 18:21:42 --> URI Class Initialized
DEBUG - 2011-09-16 18:21:42 --> Router Class Initialized
DEBUG - 2011-09-16 18:21:42 --> Output Class Initialized
DEBUG - 2011-09-16 18:21:42 --> Input Class Initialized
DEBUG - 2011-09-16 18:21:42 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-16 18:21:42 --> Language Class Initialized
DEBUG - 2011-09-16 18:21:42 --> Loader Class Initialized
DEBUG - 2011-09-16 18:21:42 --> Controller Class Initialized
ERROR - 2011-09-16 18:21:42 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-16 18:21:42 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-16 18:21:42 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-16 18:21:42 --> Model Class Initialized
DEBUG - 2011-09-16 18:21:42 --> Model Class Initialized
DEBUG - 2011-09-16 18:21:42 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-16 18:21:42 --> Database Driver Class Initialized
DEBUG - 2011-09-16 18:21:43 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-16 18:21:43 --> Helper loaded: url_helper
DEBUG - 2011-09-16 18:21:43 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-16 18:21:43 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-16 18:21:43 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-16 18:21:43 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-16 18:21:43 --> Final output sent to browser
DEBUG - 2011-09-16 18:21:43 --> Total execution time: 0.0285
DEBUG - 2011-09-16 18:21:43 --> Config Class Initialized
DEBUG - 2011-09-16 18:21:43 --> Hooks Class Initialized
DEBUG - 2011-09-16 18:21:43 --> Utf8 Class Initialized
DEBUG - 2011-09-16 18:21:43 --> UTF-8 Support Enabled
DEBUG - 2011-09-16 18:21:43 --> URI Class Initialized
DEBUG - 2011-09-16 18:21:43 --> Router Class Initialized
DEBUG - 2011-09-16 18:21:43 --> Output Class Initialized
DEBUG - 2011-09-16 18:21:43 --> Input Class Initialized
DEBUG - 2011-09-16 18:21:43 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-16 18:21:43 --> Language Class Initialized
DEBUG - 2011-09-16 18:21:43 --> Loader Class Initialized
DEBUG - 2011-09-16 18:21:43 --> Controller Class Initialized
DEBUG - 2011-09-16 18:21:43 --> Model Class Initialized
DEBUG - 2011-09-16 18:21:43 --> Model Class Initialized
DEBUG - 2011-09-16 18:21:43 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-16 18:21:43 --> Database Driver Class Initialized
DEBUG - 2011-09-16 18:21:44 --> Final output sent to browser
DEBUG - 2011-09-16 18:21:44 --> Total execution time: 0.5969
DEBUG - 2011-09-16 18:21:45 --> Config Class Initialized
DEBUG - 2011-09-16 18:21:45 --> Hooks Class Initialized
DEBUG - 2011-09-16 18:21:45 --> Utf8 Class Initialized
DEBUG - 2011-09-16 18:21:45 --> UTF-8 Support Enabled
DEBUG - 2011-09-16 18:21:45 --> URI Class Initialized
DEBUG - 2011-09-16 18:21:45 --> Router Class Initialized
ERROR - 2011-09-16 18:21:45 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-16 18:35:09 --> Config Class Initialized
DEBUG - 2011-09-16 18:35:09 --> Hooks Class Initialized
DEBUG - 2011-09-16 18:35:09 --> Utf8 Class Initialized
DEBUG - 2011-09-16 18:35:09 --> UTF-8 Support Enabled
DEBUG - 2011-09-16 18:35:09 --> URI Class Initialized
DEBUG - 2011-09-16 18:35:09 --> Router Class Initialized
DEBUG - 2011-09-16 18:35:09 --> Output Class Initialized
DEBUG - 2011-09-16 18:35:09 --> Input Class Initialized
DEBUG - 2011-09-16 18:35:09 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-16 18:35:09 --> Language Class Initialized
DEBUG - 2011-09-16 18:35:09 --> Loader Class Initialized
DEBUG - 2011-09-16 18:35:09 --> Controller Class Initialized
ERROR - 2011-09-16 18:35:09 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-16 18:35:09 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-16 18:35:09 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-16 18:35:09 --> Model Class Initialized
DEBUG - 2011-09-16 18:35:09 --> Model Class Initialized
DEBUG - 2011-09-16 18:35:09 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-16 18:35:09 --> Database Driver Class Initialized
DEBUG - 2011-09-16 18:35:09 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-16 18:35:09 --> Helper loaded: url_helper
DEBUG - 2011-09-16 18:35:09 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-16 18:35:09 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-16 18:35:09 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-16 18:35:09 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-16 18:35:09 --> Final output sent to browser
DEBUG - 2011-09-16 18:35:09 --> Total execution time: 0.0358
DEBUG - 2011-09-16 19:02:28 --> Config Class Initialized
DEBUG - 2011-09-16 19:02:28 --> Hooks Class Initialized
DEBUG - 2011-09-16 19:02:28 --> Utf8 Class Initialized
DEBUG - 2011-09-16 19:02:28 --> UTF-8 Support Enabled
DEBUG - 2011-09-16 19:02:28 --> URI Class Initialized
DEBUG - 2011-09-16 19:02:28 --> Router Class Initialized
ERROR - 2011-09-16 19:02:28 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-09-16 19:03:06 --> Config Class Initialized
DEBUG - 2011-09-16 19:03:06 --> Hooks Class Initialized
DEBUG - 2011-09-16 19:03:06 --> Utf8 Class Initialized
DEBUG - 2011-09-16 19:03:06 --> UTF-8 Support Enabled
DEBUG - 2011-09-16 19:03:06 --> URI Class Initialized
DEBUG - 2011-09-16 19:03:06 --> Router Class Initialized
DEBUG - 2011-09-16 19:03:06 --> Output Class Initialized
DEBUG - 2011-09-16 19:03:06 --> Input Class Initialized
DEBUG - 2011-09-16 19:03:06 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-16 19:03:06 --> Language Class Initialized
DEBUG - 2011-09-16 19:03:06 --> Loader Class Initialized
DEBUG - 2011-09-16 19:03:06 --> Controller Class Initialized
DEBUG - 2011-09-16 19:03:06 --> Model Class Initialized
DEBUG - 2011-09-16 19:03:06 --> Model Class Initialized
DEBUG - 2011-09-16 19:03:06 --> Model Class Initialized
DEBUG - 2011-09-16 19:03:06 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-16 19:03:06 --> Database Driver Class Initialized
DEBUG - 2011-09-16 19:03:07 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-16 19:03:07 --> Helper loaded: url_helper
DEBUG - 2011-09-16 19:03:07 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-16 19:03:07 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-16 19:03:07 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-16 19:03:07 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-16 19:03:07 --> Final output sent to browser
DEBUG - 2011-09-16 19:03:07 --> Total execution time: 0.6970
DEBUG - 2011-09-16 20:36:24 --> Config Class Initialized
DEBUG - 2011-09-16 20:36:24 --> Hooks Class Initialized
DEBUG - 2011-09-16 20:36:24 --> Utf8 Class Initialized
DEBUG - 2011-09-16 20:36:24 --> UTF-8 Support Enabled
DEBUG - 2011-09-16 20:36:24 --> URI Class Initialized
DEBUG - 2011-09-16 20:36:24 --> Router Class Initialized
DEBUG - 2011-09-16 20:36:24 --> Output Class Initialized
DEBUG - 2011-09-16 20:36:24 --> Input Class Initialized
DEBUG - 2011-09-16 20:36:24 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-16 20:36:24 --> Language Class Initialized
DEBUG - 2011-09-16 20:36:24 --> Loader Class Initialized
DEBUG - 2011-09-16 20:36:24 --> Controller Class Initialized
DEBUG - 2011-09-16 20:36:24 --> Model Class Initialized
DEBUG - 2011-09-16 20:36:24 --> Model Class Initialized
DEBUG - 2011-09-16 20:36:24 --> Model Class Initialized
DEBUG - 2011-09-16 20:36:24 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-16 20:36:24 --> Database Driver Class Initialized
DEBUG - 2011-09-16 20:36:25 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-16 20:36:25 --> Helper loaded: url_helper
DEBUG - 2011-09-16 20:36:25 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-16 20:36:25 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-16 20:36:25 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-16 20:36:25 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-16 20:36:25 --> Final output sent to browser
DEBUG - 2011-09-16 20:36:25 --> Total execution time: 0.9076
DEBUG - 2011-09-16 20:36:25 --> Config Class Initialized
DEBUG - 2011-09-16 20:36:25 --> Hooks Class Initialized
DEBUG - 2011-09-16 20:36:25 --> Utf8 Class Initialized
DEBUG - 2011-09-16 20:36:25 --> UTF-8 Support Enabled
DEBUG - 2011-09-16 20:36:25 --> URI Class Initialized
DEBUG - 2011-09-16 20:36:25 --> Router Class Initialized
DEBUG - 2011-09-16 20:36:25 --> Output Class Initialized
DEBUG - 2011-09-16 20:36:25 --> Input Class Initialized
DEBUG - 2011-09-16 20:36:25 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-16 20:36:25 --> Language Class Initialized
DEBUG - 2011-09-16 20:36:25 --> Loader Class Initialized
DEBUG - 2011-09-16 20:36:25 --> Controller Class Initialized
ERROR - 2011-09-16 20:36:25 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-16 20:36:25 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-16 20:36:25 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-16 20:36:25 --> Model Class Initialized
DEBUG - 2011-09-16 20:36:25 --> Model Class Initialized
DEBUG - 2011-09-16 20:36:25 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-16 20:36:25 --> Database Driver Class Initialized
DEBUG - 2011-09-16 20:36:25 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-16 20:36:25 --> Helper loaded: url_helper
DEBUG - 2011-09-16 20:36:25 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-16 20:36:25 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-16 20:36:25 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-16 20:36:25 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-16 20:36:25 --> Final output sent to browser
DEBUG - 2011-09-16 20:36:25 --> Total execution time: 0.0269
DEBUG - 2011-09-16 21:17:05 --> Config Class Initialized
DEBUG - 2011-09-16 21:17:05 --> Hooks Class Initialized
DEBUG - 2011-09-16 21:17:05 --> Utf8 Class Initialized
DEBUG - 2011-09-16 21:17:05 --> UTF-8 Support Enabled
DEBUG - 2011-09-16 21:17:05 --> URI Class Initialized
DEBUG - 2011-09-16 21:17:05 --> Router Class Initialized
DEBUG - 2011-09-16 21:17:05 --> Output Class Initialized
DEBUG - 2011-09-16 21:17:05 --> Input Class Initialized
DEBUG - 2011-09-16 21:17:05 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-16 21:17:05 --> Language Class Initialized
DEBUG - 2011-09-16 21:17:05 --> Loader Class Initialized
DEBUG - 2011-09-16 21:17:05 --> Controller Class Initialized
DEBUG - 2011-09-16 21:17:05 --> Model Class Initialized
DEBUG - 2011-09-16 21:17:05 --> Model Class Initialized
DEBUG - 2011-09-16 21:17:05 --> Model Class Initialized
DEBUG - 2011-09-16 21:17:05 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-16 21:17:05 --> Database Driver Class Initialized
DEBUG - 2011-09-16 21:17:06 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-16 21:17:06 --> Helper loaded: url_helper
DEBUG - 2011-09-16 21:17:06 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-16 21:17:06 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-16 21:17:06 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-16 21:17:06 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-16 21:17:06 --> Final output sent to browser
DEBUG - 2011-09-16 21:17:06 --> Total execution time: 0.2570
DEBUG - 2011-09-16 21:17:07 --> Config Class Initialized
DEBUG - 2011-09-16 21:17:07 --> Hooks Class Initialized
DEBUG - 2011-09-16 21:17:07 --> Utf8 Class Initialized
DEBUG - 2011-09-16 21:17:07 --> UTF-8 Support Enabled
DEBUG - 2011-09-16 21:17:07 --> URI Class Initialized
DEBUG - 2011-09-16 21:17:07 --> Router Class Initialized
DEBUG - 2011-09-16 21:17:07 --> Output Class Initialized
DEBUG - 2011-09-16 21:17:07 --> Input Class Initialized
DEBUG - 2011-09-16 21:17:07 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-16 21:17:07 --> Language Class Initialized
DEBUG - 2011-09-16 21:17:07 --> Loader Class Initialized
DEBUG - 2011-09-16 21:17:07 --> Controller Class Initialized
ERROR - 2011-09-16 21:17:07 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-16 21:17:07 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-16 21:17:07 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-16 21:17:07 --> Model Class Initialized
DEBUG - 2011-09-16 21:17:07 --> Model Class Initialized
DEBUG - 2011-09-16 21:17:07 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-16 21:17:07 --> Database Driver Class Initialized
DEBUG - 2011-09-16 21:17:07 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-16 21:17:07 --> Helper loaded: url_helper
DEBUG - 2011-09-16 21:17:07 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-16 21:17:07 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-16 21:17:07 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-16 21:17:07 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-16 21:17:07 --> Final output sent to browser
DEBUG - 2011-09-16 21:17:07 --> Total execution time: 0.1256
DEBUG - 2011-09-16 22:29:43 --> Config Class Initialized
DEBUG - 2011-09-16 22:29:43 --> Hooks Class Initialized
DEBUG - 2011-09-16 22:29:43 --> Utf8 Class Initialized
DEBUG - 2011-09-16 22:29:43 --> UTF-8 Support Enabled
DEBUG - 2011-09-16 22:29:43 --> URI Class Initialized
DEBUG - 2011-09-16 22:29:43 --> Router Class Initialized
DEBUG - 2011-09-16 22:29:43 --> Output Class Initialized
DEBUG - 2011-09-16 22:29:43 --> Input Class Initialized
DEBUG - 2011-09-16 22:29:43 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-16 22:29:43 --> Language Class Initialized
DEBUG - 2011-09-16 22:29:43 --> Loader Class Initialized
DEBUG - 2011-09-16 22:29:43 --> Controller Class Initialized
ERROR - 2011-09-16 22:29:43 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-16 22:29:43 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-16 22:29:43 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-16 22:29:43 --> Model Class Initialized
DEBUG - 2011-09-16 22:29:43 --> Model Class Initialized
DEBUG - 2011-09-16 22:29:43 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-16 22:29:43 --> Database Driver Class Initialized
DEBUG - 2011-09-16 22:29:43 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-16 22:29:43 --> Helper loaded: url_helper
DEBUG - 2011-09-16 22:29:43 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-16 22:29:43 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-16 22:29:43 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-16 22:29:43 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-16 22:29:43 --> Final output sent to browser
DEBUG - 2011-09-16 22:29:43 --> Total execution time: 0.0353
DEBUG - 2011-09-16 22:30:01 --> Config Class Initialized
DEBUG - 2011-09-16 22:30:01 --> Hooks Class Initialized
DEBUG - 2011-09-16 22:30:01 --> Utf8 Class Initialized
DEBUG - 2011-09-16 22:30:01 --> UTF-8 Support Enabled
DEBUG - 2011-09-16 22:30:01 --> URI Class Initialized
DEBUG - 2011-09-16 22:30:01 --> Router Class Initialized
DEBUG - 2011-09-16 22:30:01 --> Output Class Initialized
DEBUG - 2011-09-16 22:30:01 --> Input Class Initialized
DEBUG - 2011-09-16 22:30:01 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-16 22:30:01 --> Language Class Initialized
DEBUG - 2011-09-16 22:30:01 --> Loader Class Initialized
DEBUG - 2011-09-16 22:30:01 --> Controller Class Initialized
DEBUG - 2011-09-16 22:30:01 --> Model Class Initialized
DEBUG - 2011-09-16 22:30:01 --> Model Class Initialized
DEBUG - 2011-09-16 22:30:01 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-16 22:30:01 --> Database Driver Class Initialized
DEBUG - 2011-09-16 22:30:01 --> Final output sent to browser
DEBUG - 2011-09-16 22:30:01 --> Total execution time: 0.6014
DEBUG - 2011-09-16 23:15:46 --> Config Class Initialized
DEBUG - 2011-09-16 23:15:46 --> Hooks Class Initialized
DEBUG - 2011-09-16 23:15:46 --> Utf8 Class Initialized
DEBUG - 2011-09-16 23:15:46 --> UTF-8 Support Enabled
DEBUG - 2011-09-16 23:15:46 --> URI Class Initialized
DEBUG - 2011-09-16 23:15:46 --> Router Class Initialized
DEBUG - 2011-09-16 23:15:46 --> Output Class Initialized
DEBUG - 2011-09-16 23:15:46 --> Input Class Initialized
DEBUG - 2011-09-16 23:15:46 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-16 23:15:46 --> Language Class Initialized
DEBUG - 2011-09-16 23:15:46 --> Loader Class Initialized
DEBUG - 2011-09-16 23:15:46 --> Controller Class Initialized
DEBUG - 2011-09-16 23:15:46 --> Model Class Initialized
DEBUG - 2011-09-16 23:15:46 --> Model Class Initialized
DEBUG - 2011-09-16 23:15:46 --> Model Class Initialized
DEBUG - 2011-09-16 23:15:46 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-16 23:15:46 --> Database Driver Class Initialized
DEBUG - 2011-09-16 23:15:47 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-16 23:15:47 --> Helper loaded: url_helper
DEBUG - 2011-09-16 23:15:47 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-16 23:15:47 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-16 23:15:47 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-16 23:15:47 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-16 23:15:47 --> Final output sent to browser
DEBUG - 2011-09-16 23:15:47 --> Total execution time: 1.0862
DEBUG - 2011-09-16 23:15:49 --> Config Class Initialized
DEBUG - 2011-09-16 23:15:49 --> Hooks Class Initialized
DEBUG - 2011-09-16 23:15:49 --> Utf8 Class Initialized
DEBUG - 2011-09-16 23:15:49 --> UTF-8 Support Enabled
DEBUG - 2011-09-16 23:15:49 --> URI Class Initialized
DEBUG - 2011-09-16 23:15:49 --> Router Class Initialized
DEBUG - 2011-09-16 23:15:49 --> Output Class Initialized
DEBUG - 2011-09-16 23:15:49 --> Input Class Initialized
DEBUG - 2011-09-16 23:15:49 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-16 23:15:49 --> Language Class Initialized
DEBUG - 2011-09-16 23:15:49 --> Loader Class Initialized
DEBUG - 2011-09-16 23:15:49 --> Controller Class Initialized
ERROR - 2011-09-16 23:15:49 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-16 23:15:49 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-16 23:15:49 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-16 23:15:49 --> Model Class Initialized
DEBUG - 2011-09-16 23:15:49 --> Model Class Initialized
DEBUG - 2011-09-16 23:15:49 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-16 23:15:49 --> Database Driver Class Initialized
DEBUG - 2011-09-16 23:15:49 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-16 23:15:49 --> Helper loaded: url_helper
DEBUG - 2011-09-16 23:15:49 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-16 23:15:49 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-16 23:15:49 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-16 23:15:49 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-16 23:15:49 --> Final output sent to browser
DEBUG - 2011-09-16 23:15:49 --> Total execution time: 0.0331
DEBUG - 2011-09-16 23:22:48 --> Config Class Initialized
DEBUG - 2011-09-16 23:22:48 --> Hooks Class Initialized
DEBUG - 2011-09-16 23:22:48 --> Utf8 Class Initialized
DEBUG - 2011-09-16 23:22:48 --> UTF-8 Support Enabled
DEBUG - 2011-09-16 23:22:48 --> URI Class Initialized
DEBUG - 2011-09-16 23:22:48 --> Router Class Initialized
DEBUG - 2011-09-16 23:22:48 --> No URI present. Default controller set.
DEBUG - 2011-09-16 23:22:48 --> Output Class Initialized
DEBUG - 2011-09-16 23:22:48 --> Input Class Initialized
DEBUG - 2011-09-16 23:22:48 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-16 23:22:48 --> Language Class Initialized
DEBUG - 2011-09-16 23:22:48 --> Loader Class Initialized
DEBUG - 2011-09-16 23:22:48 --> Controller Class Initialized
DEBUG - 2011-09-16 23:22:48 --> File loaded: application/views/splash/main.php
DEBUG - 2011-09-16 23:22:48 --> Helper loaded: url_helper
DEBUG - 2011-09-16 23:22:48 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-16 23:22:48 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-16 23:22:48 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-16 23:22:48 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-16 23:22:48 --> Final output sent to browser
DEBUG - 2011-09-16 23:22:48 --> Total execution time: 0.0742
DEBUG - 2011-09-16 23:46:52 --> Config Class Initialized
DEBUG - 2011-09-16 23:46:52 --> Hooks Class Initialized
DEBUG - 2011-09-16 23:46:52 --> Utf8 Class Initialized
DEBUG - 2011-09-16 23:46:52 --> UTF-8 Support Enabled
DEBUG - 2011-09-16 23:46:52 --> URI Class Initialized
DEBUG - 2011-09-16 23:46:52 --> Router Class Initialized
DEBUG - 2011-09-16 23:46:52 --> Output Class Initialized
DEBUG - 2011-09-16 23:46:52 --> Input Class Initialized
DEBUG - 2011-09-16 23:46:52 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-16 23:46:52 --> Language Class Initialized
DEBUG - 2011-09-16 23:46:52 --> Loader Class Initialized
DEBUG - 2011-09-16 23:46:52 --> Controller Class Initialized
DEBUG - 2011-09-16 23:46:52 --> Model Class Initialized
DEBUG - 2011-09-16 23:46:52 --> Model Class Initialized
DEBUG - 2011-09-16 23:46:52 --> Model Class Initialized
DEBUG - 2011-09-16 23:46:52 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-16 23:46:52 --> Database Driver Class Initialized
DEBUG - 2011-09-16 23:46:52 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-16 23:46:52 --> Helper loaded: url_helper
DEBUG - 2011-09-16 23:46:52 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-16 23:46:52 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-16 23:46:52 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-16 23:46:52 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-16 23:46:52 --> Final output sent to browser
DEBUG - 2011-09-16 23:46:52 --> Total execution time: 0.2161
DEBUG - 2011-09-16 23:47:10 --> Config Class Initialized
DEBUG - 2011-09-16 23:47:10 --> Hooks Class Initialized
DEBUG - 2011-09-16 23:47:10 --> Utf8 Class Initialized
DEBUG - 2011-09-16 23:47:10 --> UTF-8 Support Enabled
DEBUG - 2011-09-16 23:47:10 --> URI Class Initialized
DEBUG - 2011-09-16 23:47:10 --> Router Class Initialized
DEBUG - 2011-09-16 23:47:10 --> Output Class Initialized
DEBUG - 2011-09-16 23:47:10 --> Input Class Initialized
DEBUG - 2011-09-16 23:47:10 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-16 23:47:10 --> Language Class Initialized
DEBUG - 2011-09-16 23:47:10 --> Loader Class Initialized
DEBUG - 2011-09-16 23:47:10 --> Controller Class Initialized
ERROR - 2011-09-16 23:47:10 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-16 23:47:10 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-16 23:47:10 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-16 23:47:10 --> Model Class Initialized
DEBUG - 2011-09-16 23:47:10 --> Model Class Initialized
DEBUG - 2011-09-16 23:47:10 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-16 23:47:10 --> Database Driver Class Initialized
DEBUG - 2011-09-16 23:47:10 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-16 23:47:10 --> Helper loaded: url_helper
DEBUG - 2011-09-16 23:47:10 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-16 23:47:10 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-16 23:47:10 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-16 23:47:10 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-16 23:47:10 --> Final output sent to browser
DEBUG - 2011-09-16 23:47:10 --> Total execution time: 0.0399
DEBUG - 2011-09-16 23:48:19 --> Config Class Initialized
DEBUG - 2011-09-16 23:48:19 --> Hooks Class Initialized
DEBUG - 2011-09-16 23:48:19 --> Utf8 Class Initialized
DEBUG - 2011-09-16 23:48:19 --> UTF-8 Support Enabled
DEBUG - 2011-09-16 23:48:19 --> URI Class Initialized
DEBUG - 2011-09-16 23:48:19 --> Router Class Initialized
DEBUG - 2011-09-16 23:48:19 --> Output Class Initialized
DEBUG - 2011-09-16 23:48:19 --> Input Class Initialized
DEBUG - 2011-09-16 23:48:19 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-16 23:48:19 --> Language Class Initialized
DEBUG - 2011-09-16 23:48:19 --> Loader Class Initialized
DEBUG - 2011-09-16 23:48:19 --> Controller Class Initialized
DEBUG - 2011-09-16 23:48:19 --> Model Class Initialized
DEBUG - 2011-09-16 23:48:19 --> Model Class Initialized
DEBUG - 2011-09-16 23:48:19 --> Model Class Initialized
DEBUG - 2011-09-16 23:48:19 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-16 23:48:19 --> Database Driver Class Initialized
DEBUG - 2011-09-16 23:48:19 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-16 23:48:19 --> Helper loaded: url_helper
DEBUG - 2011-09-16 23:48:19 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-16 23:48:19 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-16 23:48:19 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-16 23:48:19 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-16 23:48:19 --> Final output sent to browser
DEBUG - 2011-09-16 23:48:19 --> Total execution time: 0.0768
DEBUG - 2011-09-16 23:48:31 --> Config Class Initialized
DEBUG - 2011-09-16 23:48:31 --> Hooks Class Initialized
DEBUG - 2011-09-16 23:48:31 --> Utf8 Class Initialized
DEBUG - 2011-09-16 23:48:31 --> UTF-8 Support Enabled
DEBUG - 2011-09-16 23:48:31 --> URI Class Initialized
DEBUG - 2011-09-16 23:48:31 --> Router Class Initialized
DEBUG - 2011-09-16 23:48:31 --> Output Class Initialized
DEBUG - 2011-09-16 23:48:31 --> Input Class Initialized
DEBUG - 2011-09-16 23:48:31 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-16 23:48:31 --> Language Class Initialized
DEBUG - 2011-09-16 23:48:31 --> Loader Class Initialized
DEBUG - 2011-09-16 23:48:31 --> Controller Class Initialized
ERROR - 2011-09-16 23:48:31 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-16 23:48:31 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-16 23:48:31 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-16 23:48:31 --> Model Class Initialized
DEBUG - 2011-09-16 23:48:31 --> Model Class Initialized
DEBUG - 2011-09-16 23:48:31 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-16 23:48:31 --> Database Driver Class Initialized
DEBUG - 2011-09-16 23:48:31 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-16 23:48:31 --> Helper loaded: url_helper
DEBUG - 2011-09-16 23:48:31 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-16 23:48:31 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-16 23:48:31 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-16 23:48:31 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-16 23:48:31 --> Final output sent to browser
DEBUG - 2011-09-16 23:48:31 --> Total execution time: 0.0370
DEBUG - 2011-09-16 23:53:05 --> Config Class Initialized
DEBUG - 2011-09-16 23:53:05 --> Hooks Class Initialized
DEBUG - 2011-09-16 23:53:05 --> Utf8 Class Initialized
DEBUG - 2011-09-16 23:53:05 --> UTF-8 Support Enabled
DEBUG - 2011-09-16 23:53:05 --> URI Class Initialized
DEBUG - 2011-09-16 23:53:05 --> Router Class Initialized
DEBUG - 2011-09-16 23:53:05 --> Output Class Initialized
DEBUG - 2011-09-16 23:53:05 --> Input Class Initialized
DEBUG - 2011-09-16 23:53:05 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-16 23:53:05 --> Language Class Initialized
DEBUG - 2011-09-16 23:53:05 --> Loader Class Initialized
DEBUG - 2011-09-16 23:53:05 --> Controller Class Initialized
DEBUG - 2011-09-16 23:53:05 --> Model Class Initialized
DEBUG - 2011-09-16 23:53:05 --> Model Class Initialized
DEBUG - 2011-09-16 23:53:05 --> Model Class Initialized
DEBUG - 2011-09-16 23:53:05 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-16 23:53:05 --> Database Driver Class Initialized
DEBUG - 2011-09-16 23:53:05 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-16 23:53:05 --> Helper loaded: url_helper
DEBUG - 2011-09-16 23:53:05 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-16 23:53:05 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-16 23:53:05 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-16 23:53:05 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-16 23:53:05 --> Final output sent to browser
DEBUG - 2011-09-16 23:53:05 --> Total execution time: 0.0781

<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2011-05-20 02:27:46 --> Config Class Initialized
DEBUG - 2011-05-20 02:27:46 --> Hooks Class Initialized
DEBUG - 2011-05-20 02:27:46 --> Utf8 Class Initialized
DEBUG - 2011-05-20 02:27:46 --> UTF-8 Support Enabled
DEBUG - 2011-05-20 02:27:46 --> URI Class Initialized
DEBUG - 2011-05-20 02:27:46 --> Router Class Initialized
ERROR - 2011-05-20 02:27:46 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-05-20 02:28:47 --> Config Class Initialized
DEBUG - 2011-05-20 02:28:47 --> Hooks Class Initialized
DEBUG - 2011-05-20 02:28:47 --> Utf8 Class Initialized
DEBUG - 2011-05-20 02:28:47 --> UTF-8 Support Enabled
DEBUG - 2011-05-20 02:28:47 --> URI Class Initialized
DEBUG - 2011-05-20 02:28:47 --> Router Class Initialized
DEBUG - 2011-05-20 02:28:47 --> No URI present. Default controller set.
DEBUG - 2011-05-20 02:28:47 --> Output Class Initialized
DEBUG - 2011-05-20 02:28:47 --> Input Class Initialized
DEBUG - 2011-05-20 02:28:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-20 02:28:47 --> Language Class Initialized
DEBUG - 2011-05-20 02:28:47 --> Loader Class Initialized
DEBUG - 2011-05-20 02:28:47 --> Controller Class Initialized
DEBUG - 2011-05-20 02:28:47 --> File loaded: application/views/splash/main.php
DEBUG - 2011-05-20 02:28:47 --> Helper loaded: url_helper
DEBUG - 2011-05-20 02:28:47 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-20 02:28:47 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-20 02:28:47 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-20 02:28:47 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-20 02:28:47 --> Final output sent to browser
DEBUG - 2011-05-20 02:28:47 --> Total execution time: 0.2227
DEBUG - 2011-05-20 02:33:16 --> Config Class Initialized
DEBUG - 2011-05-20 02:33:16 --> Hooks Class Initialized
DEBUG - 2011-05-20 02:33:16 --> Utf8 Class Initialized
DEBUG - 2011-05-20 02:33:16 --> UTF-8 Support Enabled
DEBUG - 2011-05-20 02:33:16 --> URI Class Initialized
DEBUG - 2011-05-20 02:33:16 --> Router Class Initialized
DEBUG - 2011-05-20 02:33:16 --> No URI present. Default controller set.
DEBUG - 2011-05-20 02:33:16 --> Output Class Initialized
DEBUG - 2011-05-20 02:33:16 --> Input Class Initialized
DEBUG - 2011-05-20 02:33:16 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-20 02:33:16 --> Language Class Initialized
DEBUG - 2011-05-20 02:33:16 --> Loader Class Initialized
DEBUG - 2011-05-20 02:33:16 --> Controller Class Initialized
DEBUG - 2011-05-20 02:33:16 --> File loaded: application/views/splash/main.php
DEBUG - 2011-05-20 02:33:17 --> Helper loaded: url_helper
DEBUG - 2011-05-20 02:33:17 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-20 02:33:17 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-20 02:33:17 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-20 02:33:17 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-20 02:33:17 --> Final output sent to browser
DEBUG - 2011-05-20 02:33:17 --> Total execution time: 0.1690
DEBUG - 2011-05-20 02:33:18 --> Config Class Initialized
DEBUG - 2011-05-20 02:33:18 --> Hooks Class Initialized
DEBUG - 2011-05-20 02:33:18 --> Utf8 Class Initialized
DEBUG - 2011-05-20 02:33:18 --> UTF-8 Support Enabled
DEBUG - 2011-05-20 02:33:18 --> URI Class Initialized
DEBUG - 2011-05-20 02:33:18 --> Router Class Initialized
ERROR - 2011-05-20 02:33:18 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-20 02:33:23 --> Config Class Initialized
DEBUG - 2011-05-20 02:33:23 --> Hooks Class Initialized
DEBUG - 2011-05-20 02:33:23 --> Utf8 Class Initialized
DEBUG - 2011-05-20 02:33:23 --> UTF-8 Support Enabled
DEBUG - 2011-05-20 02:33:23 --> URI Class Initialized
DEBUG - 2011-05-20 02:33:23 --> Router Class Initialized
DEBUG - 2011-05-20 02:33:23 --> Output Class Initialized
DEBUG - 2011-05-20 02:33:23 --> Input Class Initialized
DEBUG - 2011-05-20 02:33:23 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-20 02:33:23 --> Language Class Initialized
DEBUG - 2011-05-20 02:33:23 --> Loader Class Initialized
DEBUG - 2011-05-20 02:33:23 --> Controller Class Initialized
DEBUG - 2011-05-20 02:33:23 --> Model Class Initialized
DEBUG - 2011-05-20 02:33:23 --> Model Class Initialized
DEBUG - 2011-05-20 02:33:23 --> Model Class Initialized
DEBUG - 2011-05-20 02:33:23 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-20 02:33:23 --> Database Driver Class Initialized
DEBUG - 2011-05-20 02:33:26 --> Config Class Initialized
DEBUG - 2011-05-20 02:33:26 --> Hooks Class Initialized
DEBUG - 2011-05-20 02:33:26 --> Utf8 Class Initialized
DEBUG - 2011-05-20 02:33:26 --> UTF-8 Support Enabled
DEBUG - 2011-05-20 02:33:26 --> URI Class Initialized
DEBUG - 2011-05-20 02:33:26 --> Router Class Initialized
DEBUG - 2011-05-20 02:33:26 --> Output Class Initialized
DEBUG - 2011-05-20 02:33:26 --> Input Class Initialized
DEBUG - 2011-05-20 02:33:26 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-20 02:33:26 --> Language Class Initialized
DEBUG - 2011-05-20 02:33:26 --> Loader Class Initialized
DEBUG - 2011-05-20 02:33:26 --> Controller Class Initialized
DEBUG - 2011-05-20 02:33:26 --> Model Class Initialized
DEBUG - 2011-05-20 02:33:26 --> Model Class Initialized
DEBUG - 2011-05-20 02:33:26 --> Model Class Initialized
DEBUG - 2011-05-20 02:33:26 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-20 02:33:26 --> Database Driver Class Initialized
DEBUG - 2011-05-20 02:33:34 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-20 02:33:34 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-20 02:33:34 --> Helper loaded: url_helper
DEBUG - 2011-05-20 02:33:34 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-20 02:33:34 --> Helper loaded: url_helper
DEBUG - 2011-05-20 02:33:34 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-20 02:33:34 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-20 02:33:34 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-20 02:33:34 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-20 02:33:34 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-20 02:33:34 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-20 02:33:34 --> Final output sent to browser
DEBUG - 2011-05-20 02:33:34 --> Total execution time: 7.8510
DEBUG - 2011-05-20 02:33:34 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-20 02:33:34 --> Final output sent to browser
DEBUG - 2011-05-20 02:33:34 --> Total execution time: 10.3162
DEBUG - 2011-05-20 03:09:07 --> Config Class Initialized
DEBUG - 2011-05-20 03:09:07 --> Hooks Class Initialized
DEBUG - 2011-05-20 03:09:07 --> Utf8 Class Initialized
DEBUG - 2011-05-20 03:09:07 --> UTF-8 Support Enabled
DEBUG - 2011-05-20 03:09:07 --> URI Class Initialized
DEBUG - 2011-05-20 03:09:07 --> Router Class Initialized
ERROR - 2011-05-20 03:09:07 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-05-20 03:09:07 --> Config Class Initialized
DEBUG - 2011-05-20 03:09:07 --> Hooks Class Initialized
DEBUG - 2011-05-20 03:09:07 --> Utf8 Class Initialized
DEBUG - 2011-05-20 03:09:07 --> UTF-8 Support Enabled
DEBUG - 2011-05-20 03:09:07 --> URI Class Initialized
DEBUG - 2011-05-20 03:09:07 --> Router Class Initialized
DEBUG - 2011-05-20 03:09:07 --> Output Class Initialized
DEBUG - 2011-05-20 03:09:07 --> Input Class Initialized
DEBUG - 2011-05-20 03:09:07 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-20 03:09:07 --> Language Class Initialized
DEBUG - 2011-05-20 03:09:07 --> Loader Class Initialized
DEBUG - 2011-05-20 03:09:07 --> Controller Class Initialized
ERROR - 2011-05-20 03:09:07 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-20 03:09:07 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-20 03:09:07 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-20 03:09:07 --> Model Class Initialized
DEBUG - 2011-05-20 03:09:07 --> Model Class Initialized
DEBUG - 2011-05-20 03:09:07 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-20 03:09:07 --> Database Driver Class Initialized
DEBUG - 2011-05-20 03:09:08 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-20 03:09:08 --> Helper loaded: url_helper
DEBUG - 2011-05-20 03:09:08 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-20 03:09:08 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-20 03:09:08 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-20 03:09:08 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-20 03:09:08 --> Final output sent to browser
DEBUG - 2011-05-20 03:09:08 --> Total execution time: 0.8764
DEBUG - 2011-05-20 03:26:34 --> Config Class Initialized
DEBUG - 2011-05-20 03:26:34 --> Hooks Class Initialized
DEBUG - 2011-05-20 03:26:34 --> Utf8 Class Initialized
DEBUG - 2011-05-20 03:26:34 --> UTF-8 Support Enabled
DEBUG - 2011-05-20 03:26:34 --> URI Class Initialized
DEBUG - 2011-05-20 03:26:34 --> Router Class Initialized
ERROR - 2011-05-20 03:26:34 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-05-20 03:27:18 --> Config Class Initialized
DEBUG - 2011-05-20 03:27:18 --> Hooks Class Initialized
DEBUG - 2011-05-20 03:27:18 --> Utf8 Class Initialized
DEBUG - 2011-05-20 03:27:18 --> UTF-8 Support Enabled
DEBUG - 2011-05-20 03:27:18 --> URI Class Initialized
DEBUG - 2011-05-20 03:27:18 --> Router Class Initialized
DEBUG - 2011-05-20 03:27:18 --> Output Class Initialized
DEBUG - 2011-05-20 03:27:18 --> Input Class Initialized
DEBUG - 2011-05-20 03:27:18 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-20 03:27:18 --> Language Class Initialized
DEBUG - 2011-05-20 03:27:18 --> Loader Class Initialized
DEBUG - 2011-05-20 03:27:19 --> Controller Class Initialized
DEBUG - 2011-05-20 03:27:19 --> Model Class Initialized
DEBUG - 2011-05-20 03:27:19 --> Model Class Initialized
DEBUG - 2011-05-20 03:27:19 --> Model Class Initialized
DEBUG - 2011-05-20 03:27:19 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-20 03:27:19 --> Database Driver Class Initialized
DEBUG - 2011-05-20 03:27:20 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-20 03:27:20 --> Helper loaded: url_helper
DEBUG - 2011-05-20 03:27:20 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-20 03:27:20 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-20 03:27:20 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-20 03:27:20 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-20 03:27:20 --> Final output sent to browser
DEBUG - 2011-05-20 03:27:20 --> Total execution time: 1.9774
DEBUG - 2011-05-20 07:02:21 --> Config Class Initialized
DEBUG - 2011-05-20 07:02:22 --> Hooks Class Initialized
DEBUG - 2011-05-20 07:02:22 --> Utf8 Class Initialized
DEBUG - 2011-05-20 07:02:22 --> UTF-8 Support Enabled
DEBUG - 2011-05-20 07:02:22 --> URI Class Initialized
DEBUG - 2011-05-20 07:02:22 --> Router Class Initialized
DEBUG - 2011-05-20 07:02:22 --> Output Class Initialized
DEBUG - 2011-05-20 07:02:22 --> Input Class Initialized
DEBUG - 2011-05-20 07:02:22 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-20 07:02:22 --> Language Class Initialized
DEBUG - 2011-05-20 07:02:22 --> Loader Class Initialized
DEBUG - 2011-05-20 07:02:22 --> Controller Class Initialized
DEBUG - 2011-05-20 07:02:22 --> Model Class Initialized
DEBUG - 2011-05-20 07:02:22 --> Model Class Initialized
DEBUG - 2011-05-20 07:02:22 --> Model Class Initialized
DEBUG - 2011-05-20 07:02:22 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-20 07:02:22 --> Database Driver Class Initialized
DEBUG - 2011-05-20 07:02:26 --> Config Class Initialized
DEBUG - 2011-05-20 07:02:26 --> Hooks Class Initialized
DEBUG - 2011-05-20 07:02:26 --> Utf8 Class Initialized
DEBUG - 2011-05-20 07:02:26 --> UTF-8 Support Enabled
DEBUG - 2011-05-20 07:02:26 --> URI Class Initialized
DEBUG - 2011-05-20 07:02:26 --> Router Class Initialized
DEBUG - 2011-05-20 07:02:26 --> Output Class Initialized
DEBUG - 2011-05-20 07:02:26 --> Input Class Initialized
DEBUG - 2011-05-20 07:02:26 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-20 07:02:26 --> Language Class Initialized
DEBUG - 2011-05-20 07:02:26 --> Loader Class Initialized
DEBUG - 2011-05-20 07:02:26 --> Controller Class Initialized
ERROR - 2011-05-20 07:02:26 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-20 07:02:26 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-20 07:02:26 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-20 07:02:26 --> Model Class Initialized
DEBUG - 2011-05-20 07:02:26 --> Model Class Initialized
DEBUG - 2011-05-20 07:02:26 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-20 07:02:26 --> Database Driver Class Initialized
DEBUG - 2011-05-20 07:02:27 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-20 07:02:27 --> Helper loaded: url_helper
DEBUG - 2011-05-20 07:02:27 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-20 07:02:27 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-20 07:02:27 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-20 07:02:27 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-20 07:02:27 --> Final output sent to browser
DEBUG - 2011-05-20 07:02:27 --> Total execution time: 1.4454
DEBUG - 2011-05-20 07:02:29 --> Config Class Initialized
DEBUG - 2011-05-20 07:02:29 --> Hooks Class Initialized
DEBUG - 2011-05-20 07:02:29 --> Utf8 Class Initialized
DEBUG - 2011-05-20 07:02:29 --> UTF-8 Support Enabled
DEBUG - 2011-05-20 07:02:29 --> URI Class Initialized
DEBUG - 2011-05-20 07:02:29 --> Router Class Initialized
DEBUG - 2011-05-20 07:02:29 --> Output Class Initialized
DEBUG - 2011-05-20 07:02:29 --> Input Class Initialized
DEBUG - 2011-05-20 07:02:29 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-20 07:02:29 --> Language Class Initialized
DEBUG - 2011-05-20 07:02:29 --> Loader Class Initialized
DEBUG - 2011-05-20 07:02:29 --> Controller Class Initialized
DEBUG - 2011-05-20 07:02:29 --> Model Class Initialized
DEBUG - 2011-05-20 07:02:29 --> Model Class Initialized
DEBUG - 2011-05-20 07:02:29 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-20 07:02:29 --> Database Driver Class Initialized
DEBUG - 2011-05-20 07:02:32 --> Final output sent to browser
DEBUG - 2011-05-20 07:02:32 --> Total execution time: 2.9466
DEBUG - 2011-05-20 07:02:33 --> Config Class Initialized
DEBUG - 2011-05-20 07:02:33 --> Hooks Class Initialized
DEBUG - 2011-05-20 07:02:33 --> Utf8 Class Initialized
DEBUG - 2011-05-20 07:02:33 --> UTF-8 Support Enabled
DEBUG - 2011-05-20 07:02:33 --> URI Class Initialized
DEBUG - 2011-05-20 07:02:33 --> Router Class Initialized
ERROR - 2011-05-20 07:02:33 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-20 07:02:33 --> Config Class Initialized
DEBUG - 2011-05-20 07:02:33 --> Hooks Class Initialized
DEBUG - 2011-05-20 07:02:33 --> Utf8 Class Initialized
DEBUG - 2011-05-20 07:02:33 --> UTF-8 Support Enabled
DEBUG - 2011-05-20 07:02:33 --> URI Class Initialized
DEBUG - 2011-05-20 07:02:33 --> Router Class Initialized
ERROR - 2011-05-20 07:02:33 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-20 07:02:33 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-20 07:02:33 --> Helper loaded: url_helper
DEBUG - 2011-05-20 07:02:33 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-20 07:02:33 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-20 07:02:33 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-20 07:02:33 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-20 07:02:33 --> Final output sent to browser
DEBUG - 2011-05-20 07:02:33 --> Total execution time: 11.7756
DEBUG - 2011-05-20 07:02:36 --> Config Class Initialized
DEBUG - 2011-05-20 07:02:36 --> Hooks Class Initialized
DEBUG - 2011-05-20 07:02:36 --> Utf8 Class Initialized
DEBUG - 2011-05-20 07:02:36 --> UTF-8 Support Enabled
DEBUG - 2011-05-20 07:02:36 --> URI Class Initialized
DEBUG - 2011-05-20 07:02:36 --> Router Class Initialized
ERROR - 2011-05-20 07:02:36 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-20 07:02:46 --> Config Class Initialized
DEBUG - 2011-05-20 07:02:46 --> Hooks Class Initialized
DEBUG - 2011-05-20 07:02:46 --> Utf8 Class Initialized
DEBUG - 2011-05-20 07:02:46 --> UTF-8 Support Enabled
DEBUG - 2011-05-20 07:02:46 --> URI Class Initialized
DEBUG - 2011-05-20 07:02:46 --> Router Class Initialized
DEBUG - 2011-05-20 07:02:46 --> Output Class Initialized
DEBUG - 2011-05-20 07:02:46 --> Input Class Initialized
DEBUG - 2011-05-20 07:02:46 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-20 07:02:46 --> Language Class Initialized
DEBUG - 2011-05-20 07:02:46 --> Loader Class Initialized
DEBUG - 2011-05-20 07:02:46 --> Controller Class Initialized
ERROR - 2011-05-20 07:02:46 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-20 07:02:46 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-20 07:02:46 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-20 07:02:46 --> Model Class Initialized
DEBUG - 2011-05-20 07:02:46 --> Model Class Initialized
DEBUG - 2011-05-20 07:02:46 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-20 07:02:46 --> Database Driver Class Initialized
DEBUG - 2011-05-20 07:02:46 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-20 07:02:46 --> Helper loaded: url_helper
DEBUG - 2011-05-20 07:02:46 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-20 07:02:46 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-20 07:02:46 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-20 07:02:46 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-20 07:02:46 --> Final output sent to browser
DEBUG - 2011-05-20 07:02:46 --> Total execution time: 0.0438
DEBUG - 2011-05-20 07:02:47 --> Config Class Initialized
DEBUG - 2011-05-20 07:02:47 --> Hooks Class Initialized
DEBUG - 2011-05-20 07:02:47 --> Utf8 Class Initialized
DEBUG - 2011-05-20 07:02:47 --> UTF-8 Support Enabled
DEBUG - 2011-05-20 07:02:47 --> URI Class Initialized
DEBUG - 2011-05-20 07:02:47 --> Router Class Initialized
DEBUG - 2011-05-20 07:02:47 --> Output Class Initialized
DEBUG - 2011-05-20 07:02:47 --> Input Class Initialized
DEBUG - 2011-05-20 07:02:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-20 07:02:47 --> Language Class Initialized
DEBUG - 2011-05-20 07:02:47 --> Loader Class Initialized
DEBUG - 2011-05-20 07:02:47 --> Controller Class Initialized
DEBUG - 2011-05-20 07:02:47 --> Model Class Initialized
DEBUG - 2011-05-20 07:02:47 --> Model Class Initialized
DEBUG - 2011-05-20 07:02:47 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-20 07:02:47 --> Database Driver Class Initialized
DEBUG - 2011-05-20 07:02:47 --> Config Class Initialized
DEBUG - 2011-05-20 07:02:47 --> Hooks Class Initialized
DEBUG - 2011-05-20 07:02:47 --> Utf8 Class Initialized
DEBUG - 2011-05-20 07:02:47 --> UTF-8 Support Enabled
DEBUG - 2011-05-20 07:02:47 --> URI Class Initialized
DEBUG - 2011-05-20 07:02:47 --> Router Class Initialized
DEBUG - 2011-05-20 07:02:47 --> Output Class Initialized
DEBUG - 2011-05-20 07:02:47 --> Input Class Initialized
DEBUG - 2011-05-20 07:02:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-20 07:02:47 --> Language Class Initialized
DEBUG - 2011-05-20 07:02:47 --> Loader Class Initialized
DEBUG - 2011-05-20 07:02:47 --> Controller Class Initialized
ERROR - 2011-05-20 07:02:47 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-20 07:02:47 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-20 07:02:47 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-20 07:02:47 --> Model Class Initialized
DEBUG - 2011-05-20 07:02:47 --> Model Class Initialized
DEBUG - 2011-05-20 07:02:47 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-20 07:02:47 --> Database Driver Class Initialized
DEBUG - 2011-05-20 07:02:47 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-20 07:02:47 --> Helper loaded: url_helper
DEBUG - 2011-05-20 07:02:47 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-20 07:02:47 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-20 07:02:47 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-20 07:02:47 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-20 07:02:47 --> Final output sent to browser
DEBUG - 2011-05-20 07:02:47 --> Total execution time: 0.0424
DEBUG - 2011-05-20 07:02:47 --> Config Class Initialized
DEBUG - 2011-05-20 07:02:47 --> Hooks Class Initialized
DEBUG - 2011-05-20 07:02:47 --> Utf8 Class Initialized
DEBUG - 2011-05-20 07:02:47 --> UTF-8 Support Enabled
DEBUG - 2011-05-20 07:02:47 --> URI Class Initialized
DEBUG - 2011-05-20 07:02:47 --> Router Class Initialized
DEBUG - 2011-05-20 07:02:47 --> Output Class Initialized
DEBUG - 2011-05-20 07:02:47 --> Input Class Initialized
DEBUG - 2011-05-20 07:02:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-20 07:02:47 --> Language Class Initialized
DEBUG - 2011-05-20 07:02:47 --> Loader Class Initialized
DEBUG - 2011-05-20 07:02:47 --> Controller Class Initialized
ERROR - 2011-05-20 07:02:47 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-20 07:02:47 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-20 07:02:47 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-20 07:02:47 --> Model Class Initialized
DEBUG - 2011-05-20 07:02:47 --> Model Class Initialized
DEBUG - 2011-05-20 07:02:47 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-20 07:02:47 --> Database Driver Class Initialized
DEBUG - 2011-05-20 07:02:47 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-20 07:02:47 --> Helper loaded: url_helper
DEBUG - 2011-05-20 07:02:47 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-20 07:02:47 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-20 07:02:47 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-20 07:02:47 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-20 07:02:47 --> Final output sent to browser
DEBUG - 2011-05-20 07:02:47 --> Total execution time: 0.0489
DEBUG - 2011-05-20 07:02:47 --> Final output sent to browser
DEBUG - 2011-05-20 07:02:47 --> Total execution time: 0.8920
DEBUG - 2011-05-20 08:29:39 --> Config Class Initialized
DEBUG - 2011-05-20 08:29:39 --> Hooks Class Initialized
DEBUG - 2011-05-20 08:29:39 --> Utf8 Class Initialized
DEBUG - 2011-05-20 08:29:39 --> UTF-8 Support Enabled
DEBUG - 2011-05-20 08:29:39 --> URI Class Initialized
DEBUG - 2011-05-20 08:29:39 --> Router Class Initialized
DEBUG - 2011-05-20 08:29:39 --> Output Class Initialized
DEBUG - 2011-05-20 08:29:39 --> Input Class Initialized
DEBUG - 2011-05-20 08:29:39 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-20 08:29:39 --> Language Class Initialized
DEBUG - 2011-05-20 08:29:39 --> Loader Class Initialized
DEBUG - 2011-05-20 08:29:39 --> Controller Class Initialized
ERROR - 2011-05-20 08:29:39 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-20 08:29:39 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-20 08:29:39 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-20 08:29:39 --> Model Class Initialized
DEBUG - 2011-05-20 08:29:39 --> Model Class Initialized
DEBUG - 2011-05-20 08:29:39 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-20 08:29:39 --> Database Driver Class Initialized
DEBUG - 2011-05-20 08:29:39 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-20 08:29:39 --> Helper loaded: url_helper
DEBUG - 2011-05-20 08:29:39 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-20 08:29:39 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-20 08:29:39 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-20 08:29:39 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-20 08:29:39 --> Final output sent to browser
DEBUG - 2011-05-20 08:29:39 --> Total execution time: 0.4315
DEBUG - 2011-05-20 08:29:41 --> Config Class Initialized
DEBUG - 2011-05-20 08:29:41 --> Hooks Class Initialized
DEBUG - 2011-05-20 08:29:41 --> Utf8 Class Initialized
DEBUG - 2011-05-20 08:29:41 --> UTF-8 Support Enabled
DEBUG - 2011-05-20 08:29:41 --> URI Class Initialized
DEBUG - 2011-05-20 08:29:41 --> Router Class Initialized
DEBUG - 2011-05-20 08:29:41 --> Output Class Initialized
DEBUG - 2011-05-20 08:29:41 --> Input Class Initialized
DEBUG - 2011-05-20 08:29:41 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-20 08:29:41 --> Language Class Initialized
DEBUG - 2011-05-20 08:29:41 --> Loader Class Initialized
DEBUG - 2011-05-20 08:29:41 --> Controller Class Initialized
DEBUG - 2011-05-20 08:29:41 --> Model Class Initialized
DEBUG - 2011-05-20 08:29:41 --> Model Class Initialized
DEBUG - 2011-05-20 08:29:41 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-20 08:29:41 --> Database Driver Class Initialized
DEBUG - 2011-05-20 08:29:42 --> Final output sent to browser
DEBUG - 2011-05-20 08:29:42 --> Total execution time: 0.6931
DEBUG - 2011-05-20 08:29:43 --> Config Class Initialized
DEBUG - 2011-05-20 08:29:43 --> Hooks Class Initialized
DEBUG - 2011-05-20 08:29:43 --> Utf8 Class Initialized
DEBUG - 2011-05-20 08:29:43 --> UTF-8 Support Enabled
DEBUG - 2011-05-20 08:29:43 --> URI Class Initialized
DEBUG - 2011-05-20 08:29:43 --> Router Class Initialized
ERROR - 2011-05-20 08:29:43 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-20 09:44:23 --> Config Class Initialized
DEBUG - 2011-05-20 09:44:23 --> Hooks Class Initialized
DEBUG - 2011-05-20 09:44:23 --> Utf8 Class Initialized
DEBUG - 2011-05-20 09:44:23 --> UTF-8 Support Enabled
DEBUG - 2011-05-20 09:44:23 --> URI Class Initialized
DEBUG - 2011-05-20 09:44:23 --> Router Class Initialized
ERROR - 2011-05-20 09:44:23 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-05-20 09:47:49 --> Config Class Initialized
DEBUG - 2011-05-20 09:47:49 --> Hooks Class Initialized
DEBUG - 2011-05-20 09:47:49 --> Utf8 Class Initialized
DEBUG - 2011-05-20 09:47:49 --> UTF-8 Support Enabled
DEBUG - 2011-05-20 09:47:49 --> URI Class Initialized
DEBUG - 2011-05-20 09:47:49 --> Router Class Initialized
ERROR - 2011-05-20 09:47:49 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-05-20 10:14:30 --> Config Class Initialized
DEBUG - 2011-05-20 10:14:30 --> Hooks Class Initialized
DEBUG - 2011-05-20 10:14:30 --> Utf8 Class Initialized
DEBUG - 2011-05-20 10:14:30 --> UTF-8 Support Enabled
DEBUG - 2011-05-20 10:14:30 --> URI Class Initialized
DEBUG - 2011-05-20 10:14:30 --> Router Class Initialized
DEBUG - 2011-05-20 10:14:30 --> Output Class Initialized
DEBUG - 2011-05-20 10:14:30 --> Input Class Initialized
DEBUG - 2011-05-20 10:14:30 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-20 10:14:30 --> Language Class Initialized
DEBUG - 2011-05-20 10:14:30 --> Loader Class Initialized
DEBUG - 2011-05-20 10:14:30 --> Controller Class Initialized
DEBUG - 2011-05-20 10:14:30 --> Model Class Initialized
DEBUG - 2011-05-20 10:14:30 --> Model Class Initialized
DEBUG - 2011-05-20 10:14:30 --> Model Class Initialized
DEBUG - 2011-05-20 10:14:30 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-20 10:14:30 --> Database Driver Class Initialized
DEBUG - 2011-05-20 10:14:31 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-20 10:14:31 --> Helper loaded: url_helper
DEBUG - 2011-05-20 10:14:31 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-20 10:14:31 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-20 10:14:31 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-20 10:14:31 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-20 10:14:31 --> Final output sent to browser
DEBUG - 2011-05-20 10:14:31 --> Total execution time: 0.9820
DEBUG - 2011-05-20 10:16:09 --> Config Class Initialized
DEBUG - 2011-05-20 10:16:09 --> Hooks Class Initialized
DEBUG - 2011-05-20 10:16:09 --> Utf8 Class Initialized
DEBUG - 2011-05-20 10:16:09 --> UTF-8 Support Enabled
DEBUG - 2011-05-20 10:16:09 --> URI Class Initialized
DEBUG - 2011-05-20 10:16:09 --> Router Class Initialized
DEBUG - 2011-05-20 10:16:09 --> Output Class Initialized
DEBUG - 2011-05-20 10:16:09 --> Input Class Initialized
DEBUG - 2011-05-20 10:16:09 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-20 10:16:09 --> Language Class Initialized
DEBUG - 2011-05-20 10:16:09 --> Loader Class Initialized
DEBUG - 2011-05-20 10:16:09 --> Controller Class Initialized
ERROR - 2011-05-20 10:16:09 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-20 10:16:09 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-20 10:16:09 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-20 10:16:09 --> Model Class Initialized
DEBUG - 2011-05-20 10:16:09 --> Model Class Initialized
DEBUG - 2011-05-20 10:16:09 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-20 10:16:09 --> Database Driver Class Initialized
DEBUG - 2011-05-20 10:16:09 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-20 10:16:09 --> Helper loaded: url_helper
DEBUG - 2011-05-20 10:16:09 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-20 10:16:09 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-20 10:16:09 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-20 10:16:09 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-20 10:16:09 --> Final output sent to browser
DEBUG - 2011-05-20 10:16:09 --> Total execution time: 0.1352
DEBUG - 2011-05-20 10:18:27 --> Config Class Initialized
DEBUG - 2011-05-20 10:18:27 --> Hooks Class Initialized
DEBUG - 2011-05-20 10:18:27 --> Utf8 Class Initialized
DEBUG - 2011-05-20 10:18:27 --> UTF-8 Support Enabled
DEBUG - 2011-05-20 10:18:27 --> URI Class Initialized
DEBUG - 2011-05-20 10:18:27 --> Router Class Initialized
DEBUG - 2011-05-20 10:18:27 --> Output Class Initialized
DEBUG - 2011-05-20 10:18:27 --> Input Class Initialized
DEBUG - 2011-05-20 10:18:27 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-20 10:18:27 --> Language Class Initialized
DEBUG - 2011-05-20 10:18:27 --> Loader Class Initialized
DEBUG - 2011-05-20 10:18:27 --> Controller Class Initialized
DEBUG - 2011-05-20 10:18:27 --> Model Class Initialized
DEBUG - 2011-05-20 10:18:27 --> Model Class Initialized
DEBUG - 2011-05-20 10:18:27 --> Model Class Initialized
DEBUG - 2011-05-20 10:18:27 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-20 10:18:27 --> Database Driver Class Initialized
DEBUG - 2011-05-20 10:18:27 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-20 10:18:27 --> Helper loaded: url_helper
DEBUG - 2011-05-20 10:18:27 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-20 10:18:27 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-20 10:18:27 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-20 10:18:27 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-20 10:18:27 --> Final output sent to browser
DEBUG - 2011-05-20 10:18:27 --> Total execution time: 0.1471
DEBUG - 2011-05-20 10:18:36 --> Config Class Initialized
DEBUG - 2011-05-20 10:18:36 --> Hooks Class Initialized
DEBUG - 2011-05-20 10:18:36 --> Utf8 Class Initialized
DEBUG - 2011-05-20 10:18:36 --> UTF-8 Support Enabled
DEBUG - 2011-05-20 10:18:36 --> URI Class Initialized
DEBUG - 2011-05-20 10:18:36 --> Router Class Initialized
DEBUG - 2011-05-20 10:18:36 --> Output Class Initialized
DEBUG - 2011-05-20 10:18:36 --> Input Class Initialized
DEBUG - 2011-05-20 10:18:36 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-20 10:18:36 --> Language Class Initialized
DEBUG - 2011-05-20 10:18:36 --> Loader Class Initialized
DEBUG - 2011-05-20 10:18:36 --> Controller Class Initialized
ERROR - 2011-05-20 10:18:36 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-20 10:18:36 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-20 10:18:36 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-20 10:18:36 --> Model Class Initialized
DEBUG - 2011-05-20 10:18:36 --> Model Class Initialized
DEBUG - 2011-05-20 10:18:36 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-20 10:18:36 --> Database Driver Class Initialized
DEBUG - 2011-05-20 10:18:36 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-20 10:18:36 --> Helper loaded: url_helper
DEBUG - 2011-05-20 10:18:36 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-20 10:18:36 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-20 10:18:36 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-20 10:18:36 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-20 10:18:36 --> Final output sent to browser
DEBUG - 2011-05-20 10:18:36 --> Total execution time: 0.0582
DEBUG - 2011-05-20 10:18:54 --> Config Class Initialized
DEBUG - 2011-05-20 10:18:54 --> Hooks Class Initialized
DEBUG - 2011-05-20 10:18:54 --> Utf8 Class Initialized
DEBUG - 2011-05-20 10:18:54 --> UTF-8 Support Enabled
DEBUG - 2011-05-20 10:18:54 --> URI Class Initialized
DEBUG - 2011-05-20 10:18:54 --> Router Class Initialized
DEBUG - 2011-05-20 10:18:54 --> Output Class Initialized
DEBUG - 2011-05-20 10:18:54 --> Input Class Initialized
DEBUG - 2011-05-20 10:18:54 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-20 10:18:54 --> Language Class Initialized
DEBUG - 2011-05-20 10:18:54 --> Loader Class Initialized
DEBUG - 2011-05-20 10:18:54 --> Controller Class Initialized
DEBUG - 2011-05-20 10:18:54 --> Model Class Initialized
DEBUG - 2011-05-20 10:18:54 --> Model Class Initialized
DEBUG - 2011-05-20 10:18:54 --> Model Class Initialized
DEBUG - 2011-05-20 10:18:54 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-20 10:18:54 --> Database Driver Class Initialized
DEBUG - 2011-05-20 10:18:54 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-20 10:18:54 --> Helper loaded: url_helper
DEBUG - 2011-05-20 10:18:54 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-20 10:18:54 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-20 10:18:54 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-20 10:18:54 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-20 10:18:54 --> Final output sent to browser
DEBUG - 2011-05-20 10:18:54 --> Total execution time: 0.0478
DEBUG - 2011-05-20 14:12:37 --> Config Class Initialized
DEBUG - 2011-05-20 14:12:37 --> Hooks Class Initialized
DEBUG - 2011-05-20 14:12:37 --> Utf8 Class Initialized
DEBUG - 2011-05-20 14:12:37 --> UTF-8 Support Enabled
DEBUG - 2011-05-20 14:12:37 --> URI Class Initialized
DEBUG - 2011-05-20 14:12:37 --> Router Class Initialized
ERROR - 2011-05-20 14:12:37 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-05-20 14:19:31 --> Config Class Initialized
DEBUG - 2011-05-20 14:19:31 --> Hooks Class Initialized
DEBUG - 2011-05-20 14:19:31 --> Utf8 Class Initialized
DEBUG - 2011-05-20 14:19:31 --> UTF-8 Support Enabled
DEBUG - 2011-05-20 14:19:31 --> URI Class Initialized
DEBUG - 2011-05-20 14:19:31 --> Router Class Initialized
DEBUG - 2011-05-20 14:19:31 --> Output Class Initialized
DEBUG - 2011-05-20 14:19:31 --> Input Class Initialized
DEBUG - 2011-05-20 14:19:31 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-20 14:19:31 --> Language Class Initialized
DEBUG - 2011-05-20 14:19:31 --> Loader Class Initialized
DEBUG - 2011-05-20 14:19:31 --> Controller Class Initialized
DEBUG - 2011-05-20 14:19:31 --> Model Class Initialized
DEBUG - 2011-05-20 14:19:31 --> Model Class Initialized
DEBUG - 2011-05-20 14:19:31 --> Model Class Initialized
DEBUG - 2011-05-20 14:19:31 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-20 14:19:31 --> Database Driver Class Initialized
DEBUG - 2011-05-20 14:19:31 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-20 14:19:32 --> Helper loaded: url_helper
DEBUG - 2011-05-20 14:19:32 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-20 14:19:32 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-20 14:19:32 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-20 14:19:32 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-20 14:19:32 --> Final output sent to browser
DEBUG - 2011-05-20 14:19:32 --> Total execution time: 0.6456
DEBUG - 2011-05-20 14:20:04 --> Config Class Initialized
DEBUG - 2011-05-20 14:20:04 --> Hooks Class Initialized
DEBUG - 2011-05-20 14:20:04 --> Utf8 Class Initialized
DEBUG - 2011-05-20 14:20:04 --> UTF-8 Support Enabled
DEBUG - 2011-05-20 14:20:04 --> URI Class Initialized
DEBUG - 2011-05-20 14:20:04 --> Router Class Initialized
DEBUG - 2011-05-20 14:20:04 --> Output Class Initialized
DEBUG - 2011-05-20 14:20:04 --> Input Class Initialized
DEBUG - 2011-05-20 14:20:04 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-20 14:20:04 --> Language Class Initialized
DEBUG - 2011-05-20 14:20:04 --> Loader Class Initialized
DEBUG - 2011-05-20 14:20:04 --> Controller Class Initialized
ERROR - 2011-05-20 14:20:04 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-20 14:20:04 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-20 14:20:04 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-20 14:20:04 --> Model Class Initialized
DEBUG - 2011-05-20 14:20:04 --> Model Class Initialized
DEBUG - 2011-05-20 14:20:04 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-20 14:20:04 --> Database Driver Class Initialized
DEBUG - 2011-05-20 14:20:04 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-20 14:20:04 --> Helper loaded: url_helper
DEBUG - 2011-05-20 14:20:04 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-20 14:20:04 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-20 14:20:04 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-20 14:20:04 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-20 14:20:04 --> Final output sent to browser
DEBUG - 2011-05-20 14:20:04 --> Total execution time: 0.4427
DEBUG - 2011-05-20 14:23:44 --> Config Class Initialized
DEBUG - 2011-05-20 14:23:44 --> Hooks Class Initialized
DEBUG - 2011-05-20 14:23:44 --> Utf8 Class Initialized
DEBUG - 2011-05-20 14:23:44 --> UTF-8 Support Enabled
DEBUG - 2011-05-20 14:23:44 --> URI Class Initialized
DEBUG - 2011-05-20 14:23:44 --> Router Class Initialized
DEBUG - 2011-05-20 14:23:44 --> Output Class Initialized
DEBUG - 2011-05-20 14:23:44 --> Input Class Initialized
DEBUG - 2011-05-20 14:23:44 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-20 14:23:44 --> Language Class Initialized
DEBUG - 2011-05-20 14:23:44 --> Loader Class Initialized
DEBUG - 2011-05-20 14:23:44 --> Controller Class Initialized
DEBUG - 2011-05-20 14:23:44 --> Model Class Initialized
DEBUG - 2011-05-20 14:23:44 --> Model Class Initialized
DEBUG - 2011-05-20 14:23:44 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-20 14:23:44 --> Database Driver Class Initialized
DEBUG - 2011-05-20 14:23:50 --> Config Class Initialized
DEBUG - 2011-05-20 14:23:50 --> Hooks Class Initialized
DEBUG - 2011-05-20 14:23:50 --> Utf8 Class Initialized
DEBUG - 2011-05-20 14:23:50 --> UTF-8 Support Enabled
DEBUG - 2011-05-20 14:23:50 --> URI Class Initialized
DEBUG - 2011-05-20 14:23:50 --> Router Class Initialized
DEBUG - 2011-05-20 14:23:50 --> No URI present. Default controller set.
DEBUG - 2011-05-20 14:23:50 --> Output Class Initialized
DEBUG - 2011-05-20 14:23:50 --> Input Class Initialized
DEBUG - 2011-05-20 14:23:50 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-20 14:23:50 --> Language Class Initialized
DEBUG - 2011-05-20 14:23:50 --> Loader Class Initialized
DEBUG - 2011-05-20 14:23:50 --> Controller Class Initialized
DEBUG - 2011-05-20 14:23:50 --> File loaded: application/views/splash/main.php
DEBUG - 2011-05-20 14:23:50 --> Helper loaded: url_helper
DEBUG - 2011-05-20 14:23:50 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-20 14:23:50 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-20 14:23:50 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-20 14:23:50 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-20 14:23:50 --> Final output sent to browser
DEBUG - 2011-05-20 14:23:50 --> Total execution time: 0.0740
DEBUG - 2011-05-20 14:23:51 --> Config Class Initialized
DEBUG - 2011-05-20 14:23:51 --> Hooks Class Initialized
DEBUG - 2011-05-20 14:23:51 --> Utf8 Class Initialized
DEBUG - 2011-05-20 14:23:51 --> UTF-8 Support Enabled
DEBUG - 2011-05-20 14:23:51 --> URI Class Initialized
DEBUG - 2011-05-20 14:23:51 --> Router Class Initialized
DEBUG - 2011-05-20 14:23:51 --> No URI present. Default controller set.
DEBUG - 2011-05-20 14:23:51 --> Output Class Initialized
DEBUG - 2011-05-20 14:23:51 --> Input Class Initialized
DEBUG - 2011-05-20 14:23:51 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-20 14:23:51 --> Language Class Initialized
DEBUG - 2011-05-20 14:23:51 --> Loader Class Initialized
DEBUG - 2011-05-20 14:23:51 --> Controller Class Initialized
DEBUG - 2011-05-20 14:23:51 --> File loaded: application/views/splash/main.php
DEBUG - 2011-05-20 14:23:51 --> Helper loaded: url_helper
DEBUG - 2011-05-20 14:23:51 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-20 14:23:51 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-20 14:23:51 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-20 14:23:51 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-20 14:23:51 --> Final output sent to browser
DEBUG - 2011-05-20 14:23:51 --> Total execution time: 0.0160
DEBUG - 2011-05-20 14:23:56 --> Config Class Initialized
DEBUG - 2011-05-20 14:23:56 --> Hooks Class Initialized
DEBUG - 2011-05-20 14:23:56 --> Utf8 Class Initialized
DEBUG - 2011-05-20 14:23:56 --> UTF-8 Support Enabled
DEBUG - 2011-05-20 14:23:56 --> URI Class Initialized
DEBUG - 2011-05-20 14:23:56 --> Router Class Initialized
DEBUG - 2011-05-20 14:23:56 --> No URI present. Default controller set.
DEBUG - 2011-05-20 14:23:56 --> Output Class Initialized
DEBUG - 2011-05-20 14:23:56 --> Input Class Initialized
DEBUG - 2011-05-20 14:23:56 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-20 14:23:56 --> Language Class Initialized
DEBUG - 2011-05-20 14:23:56 --> Loader Class Initialized
DEBUG - 2011-05-20 14:23:56 --> Controller Class Initialized
DEBUG - 2011-05-20 14:23:56 --> File loaded: application/views/splash/main.php
DEBUG - 2011-05-20 14:23:56 --> Helper loaded: url_helper
DEBUG - 2011-05-20 14:23:56 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-20 14:23:56 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-20 14:23:56 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-20 14:23:56 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-20 14:23:56 --> Final output sent to browser
DEBUG - 2011-05-20 14:23:56 --> Total execution time: 0.0130
DEBUG - 2011-05-20 14:41:54 --> Config Class Initialized
DEBUG - 2011-05-20 14:41:54 --> Hooks Class Initialized
DEBUG - 2011-05-20 14:41:54 --> Utf8 Class Initialized
DEBUG - 2011-05-20 14:41:54 --> UTF-8 Support Enabled
DEBUG - 2011-05-20 14:41:54 --> URI Class Initialized
DEBUG - 2011-05-20 14:41:54 --> Router Class Initialized
DEBUG - 2011-05-20 14:41:54 --> Output Class Initialized
DEBUG - 2011-05-20 14:41:54 --> Input Class Initialized
DEBUG - 2011-05-20 14:41:54 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-20 14:41:54 --> Language Class Initialized
DEBUG - 2011-05-20 14:41:54 --> Loader Class Initialized
DEBUG - 2011-05-20 14:41:54 --> Controller Class Initialized
DEBUG - 2011-05-20 14:41:54 --> Model Class Initialized
DEBUG - 2011-05-20 14:41:54 --> Model Class Initialized
DEBUG - 2011-05-20 14:41:54 --> Model Class Initialized
DEBUG - 2011-05-20 14:41:54 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-20 14:41:54 --> Database Driver Class Initialized
DEBUG - 2011-05-20 14:41:54 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-20 14:41:54 --> Helper loaded: url_helper
DEBUG - 2011-05-20 14:41:54 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-20 14:41:55 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-20 14:41:55 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-20 14:41:55 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-20 14:41:55 --> Final output sent to browser
DEBUG - 2011-05-20 14:41:55 --> Total execution time: 0.5151
DEBUG - 2011-05-20 14:42:00 --> Config Class Initialized
DEBUG - 2011-05-20 14:42:00 --> Hooks Class Initialized
DEBUG - 2011-05-20 14:42:00 --> Utf8 Class Initialized
DEBUG - 2011-05-20 14:42:00 --> UTF-8 Support Enabled
DEBUG - 2011-05-20 14:42:00 --> URI Class Initialized
DEBUG - 2011-05-20 14:42:00 --> Router Class Initialized
ERROR - 2011-05-20 14:42:00 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-20 14:42:00 --> Config Class Initialized
DEBUG - 2011-05-20 14:42:00 --> Hooks Class Initialized
DEBUG - 2011-05-20 14:42:00 --> Utf8 Class Initialized
DEBUG - 2011-05-20 14:42:00 --> UTF-8 Support Enabled
DEBUG - 2011-05-20 14:42:00 --> URI Class Initialized
DEBUG - 2011-05-20 14:42:00 --> Router Class Initialized
ERROR - 2011-05-20 14:42:00 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-20 15:21:29 --> Config Class Initialized
DEBUG - 2011-05-20 15:21:29 --> Hooks Class Initialized
DEBUG - 2011-05-20 15:21:29 --> Config Class Initialized
DEBUG - 2011-05-20 15:21:29 --> Hooks Class Initialized
DEBUG - 2011-05-20 15:21:29 --> Utf8 Class Initialized
DEBUG - 2011-05-20 15:21:29 --> Utf8 Class Initialized
DEBUG - 2011-05-20 15:21:29 --> UTF-8 Support Enabled
DEBUG - 2011-05-20 15:21:29 --> UTF-8 Support Enabled
DEBUG - 2011-05-20 15:21:29 --> URI Class Initialized
DEBUG - 2011-05-20 15:21:29 --> URI Class Initialized
DEBUG - 2011-05-20 15:21:29 --> Router Class Initialized
DEBUG - 2011-05-20 15:21:29 --> Router Class Initialized
DEBUG - 2011-05-20 15:21:29 --> Output Class Initialized
DEBUG - 2011-05-20 15:21:29 --> Output Class Initialized
DEBUG - 2011-05-20 15:21:29 --> Input Class Initialized
DEBUG - 2011-05-20 15:21:29 --> Input Class Initialized
DEBUG - 2011-05-20 15:21:29 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-20 15:21:29 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-20 15:21:29 --> Language Class Initialized
DEBUG - 2011-05-20 15:21:29 --> Language Class Initialized
DEBUG - 2011-05-20 15:21:29 --> Loader Class Initialized
DEBUG - 2011-05-20 15:21:29 --> Loader Class Initialized
DEBUG - 2011-05-20 15:21:30 --> Controller Class Initialized
DEBUG - 2011-05-20 15:21:30 --> Controller Class Initialized
DEBUG - 2011-05-20 15:21:30 --> Model Class Initialized
ERROR - 2011-05-20 15:21:30 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-20 15:21:30 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-20 15:21:30 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-20 15:21:30 --> Model Class Initialized
DEBUG - 2011-05-20 15:21:30 --> Model Class Initialized
DEBUG - 2011-05-20 15:21:30 --> Model Class Initialized
DEBUG - 2011-05-20 15:21:30 --> Model Class Initialized
DEBUG - 2011-05-20 15:21:30 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-20 15:21:30 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-20 15:21:30 --> Database Driver Class Initialized
DEBUG - 2011-05-20 15:21:30 --> Database Driver Class Initialized
DEBUG - 2011-05-20 15:21:30 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-20 15:21:30 --> Helper loaded: url_helper
DEBUG - 2011-05-20 15:21:30 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-20 15:21:30 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-20 15:21:30 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-20 15:21:30 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-20 15:21:30 --> Final output sent to browser
DEBUG - 2011-05-20 15:21:30 --> Total execution time: 0.4435
DEBUG - 2011-05-20 15:21:30 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-20 15:21:30 --> Helper loaded: url_helper
DEBUG - 2011-05-20 15:21:30 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-20 15:21:30 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-20 15:21:30 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-20 15:21:30 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-20 15:21:30 --> Final output sent to browser
DEBUG - 2011-05-20 15:21:30 --> Total execution time: 0.6045
DEBUG - 2011-05-20 15:21:43 --> Config Class Initialized
DEBUG - 2011-05-20 15:21:43 --> Hooks Class Initialized
DEBUG - 2011-05-20 15:21:43 --> Utf8 Class Initialized
DEBUG - 2011-05-20 15:21:43 --> UTF-8 Support Enabled
DEBUG - 2011-05-20 15:21:43 --> URI Class Initialized
DEBUG - 2011-05-20 15:21:43 --> Router Class Initialized
DEBUG - 2011-05-20 15:21:43 --> Output Class Initialized
DEBUG - 2011-05-20 15:21:43 --> Input Class Initialized
DEBUG - 2011-05-20 15:21:43 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-20 15:21:43 --> Language Class Initialized
DEBUG - 2011-05-20 15:21:43 --> Loader Class Initialized
DEBUG - 2011-05-20 15:21:43 --> Controller Class Initialized
ERROR - 2011-05-20 15:21:43 --> 404 Page Not Found --> snakes/arsenalist.com
DEBUG - 2011-05-20 18:34:18 --> Config Class Initialized
DEBUG - 2011-05-20 18:34:18 --> Hooks Class Initialized
DEBUG - 2011-05-20 18:34:18 --> Utf8 Class Initialized
DEBUG - 2011-05-20 18:34:18 --> UTF-8 Support Enabled
DEBUG - 2011-05-20 18:34:18 --> URI Class Initialized
DEBUG - 2011-05-20 18:34:18 --> Router Class Initialized
DEBUG - 2011-05-20 18:34:18 --> No URI present. Default controller set.
DEBUG - 2011-05-20 18:34:18 --> Output Class Initialized
DEBUG - 2011-05-20 18:34:18 --> Input Class Initialized
DEBUG - 2011-05-20 18:34:18 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-20 18:34:18 --> Language Class Initialized
DEBUG - 2011-05-20 18:34:18 --> Loader Class Initialized
DEBUG - 2011-05-20 18:34:18 --> Controller Class Initialized
DEBUG - 2011-05-20 18:34:18 --> File loaded: application/views/splash/main.php
DEBUG - 2011-05-20 18:34:18 --> Helper loaded: url_helper
DEBUG - 2011-05-20 18:34:18 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-20 18:34:18 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-20 18:34:18 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-20 18:34:18 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-20 18:34:18 --> Final output sent to browser
DEBUG - 2011-05-20 18:34:18 --> Total execution time: 0.1928
DEBUG - 2011-05-20 19:12:54 --> Config Class Initialized
DEBUG - 2011-05-20 19:12:54 --> Hooks Class Initialized
DEBUG - 2011-05-20 19:12:54 --> Utf8 Class Initialized
DEBUG - 2011-05-20 19:12:54 --> UTF-8 Support Enabled
DEBUG - 2011-05-20 19:12:54 --> URI Class Initialized
DEBUG - 2011-05-20 19:12:54 --> Router Class Initialized
DEBUG - 2011-05-20 19:12:54 --> Output Class Initialized
DEBUG - 2011-05-20 19:12:54 --> Input Class Initialized
DEBUG - 2011-05-20 19:12:54 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-20 19:12:54 --> Language Class Initialized
DEBUG - 2011-05-20 19:12:54 --> Loader Class Initialized
DEBUG - 2011-05-20 19:12:54 --> Controller Class Initialized
ERROR - 2011-05-20 19:12:54 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-20 19:12:54 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-20 19:12:54 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-20 19:12:54 --> Model Class Initialized
DEBUG - 2011-05-20 19:12:54 --> Model Class Initialized
DEBUG - 2011-05-20 19:12:54 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-20 19:12:54 --> Database Driver Class Initialized
DEBUG - 2011-05-20 19:12:54 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-20 19:12:55 --> Helper loaded: url_helper
DEBUG - 2011-05-20 19:12:55 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-20 19:12:55 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-20 19:12:55 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-20 19:12:55 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-20 19:12:55 --> Final output sent to browser
DEBUG - 2011-05-20 19:12:55 --> Total execution time: 0.4811
DEBUG - 2011-05-20 19:13:07 --> Config Class Initialized
DEBUG - 2011-05-20 19:13:07 --> Hooks Class Initialized
DEBUG - 2011-05-20 19:13:07 --> Utf8 Class Initialized
DEBUG - 2011-05-20 19:13:07 --> UTF-8 Support Enabled
DEBUG - 2011-05-20 19:13:07 --> URI Class Initialized
DEBUG - 2011-05-20 19:13:07 --> Router Class Initialized
DEBUG - 2011-05-20 19:13:07 --> Output Class Initialized
DEBUG - 2011-05-20 19:13:07 --> Input Class Initialized
DEBUG - 2011-05-20 19:13:07 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-20 19:13:07 --> Language Class Initialized
DEBUG - 2011-05-20 19:13:07 --> Loader Class Initialized
DEBUG - 2011-05-20 19:13:07 --> Controller Class Initialized
DEBUG - 2011-05-20 19:13:07 --> Model Class Initialized
DEBUG - 2011-05-20 19:13:07 --> Model Class Initialized
DEBUG - 2011-05-20 19:13:07 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-20 19:13:07 --> Database Driver Class Initialized
DEBUG - 2011-05-20 19:13:07 --> Final output sent to browser
DEBUG - 2011-05-20 19:13:07 --> Total execution time: 0.8653
DEBUG - 2011-05-20 19:13:52 --> Config Class Initialized
DEBUG - 2011-05-20 19:13:52 --> Hooks Class Initialized
DEBUG - 2011-05-20 19:13:52 --> Utf8 Class Initialized
DEBUG - 2011-05-20 19:13:52 --> UTF-8 Support Enabled
DEBUG - 2011-05-20 19:13:52 --> URI Class Initialized
DEBUG - 2011-05-20 19:13:52 --> Router Class Initialized
DEBUG - 2011-05-20 19:13:52 --> Output Class Initialized
DEBUG - 2011-05-20 19:13:52 --> Input Class Initialized
DEBUG - 2011-05-20 19:13:52 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-20 19:13:52 --> Language Class Initialized
DEBUG - 2011-05-20 19:13:52 --> Loader Class Initialized
DEBUG - 2011-05-20 19:13:52 --> Controller Class Initialized
ERROR - 2011-05-20 19:13:52 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-20 19:13:52 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-20 19:13:52 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-20 19:13:52 --> Model Class Initialized
DEBUG - 2011-05-20 19:13:52 --> Model Class Initialized
DEBUG - 2011-05-20 19:13:52 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-20 19:13:52 --> Database Driver Class Initialized
DEBUG - 2011-05-20 19:13:52 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-20 19:13:52 --> Helper loaded: url_helper
DEBUG - 2011-05-20 19:13:52 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-20 19:13:52 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-20 19:13:52 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-20 19:13:52 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-20 19:13:52 --> Final output sent to browser
DEBUG - 2011-05-20 19:13:52 --> Total execution time: 0.0286
DEBUG - 2011-05-20 19:14:21 --> Config Class Initialized
DEBUG - 2011-05-20 19:14:21 --> Hooks Class Initialized
DEBUG - 2011-05-20 19:14:21 --> Utf8 Class Initialized
DEBUG - 2011-05-20 19:14:21 --> UTF-8 Support Enabled
DEBUG - 2011-05-20 19:14:21 --> URI Class Initialized
DEBUG - 2011-05-20 19:14:21 --> Router Class Initialized
ERROR - 2011-05-20 19:14:21 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-20 19:14:24 --> Config Class Initialized
DEBUG - 2011-05-20 19:14:24 --> Hooks Class Initialized
DEBUG - 2011-05-20 19:14:24 --> Utf8 Class Initialized
DEBUG - 2011-05-20 19:14:24 --> UTF-8 Support Enabled
DEBUG - 2011-05-20 19:14:24 --> URI Class Initialized
DEBUG - 2011-05-20 19:14:24 --> Router Class Initialized
ERROR - 2011-05-20 19:14:24 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-20 19:14:58 --> Config Class Initialized
DEBUG - 2011-05-20 19:14:58 --> Hooks Class Initialized
DEBUG - 2011-05-20 19:14:58 --> Utf8 Class Initialized
DEBUG - 2011-05-20 19:14:58 --> UTF-8 Support Enabled
DEBUG - 2011-05-20 19:14:58 --> URI Class Initialized
DEBUG - 2011-05-20 19:14:58 --> Router Class Initialized
DEBUG - 2011-05-20 19:14:58 --> Output Class Initialized
DEBUG - 2011-05-20 19:14:58 --> Input Class Initialized
DEBUG - 2011-05-20 19:14:58 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-20 19:14:58 --> Language Class Initialized
DEBUG - 2011-05-20 19:14:58 --> Loader Class Initialized
DEBUG - 2011-05-20 19:14:58 --> Controller Class Initialized
ERROR - 2011-05-20 19:14:58 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-20 19:14:58 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-20 19:14:58 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-20 19:14:58 --> Model Class Initialized
DEBUG - 2011-05-20 19:14:58 --> Model Class Initialized
DEBUG - 2011-05-20 19:14:58 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-20 19:14:58 --> Database Driver Class Initialized
DEBUG - 2011-05-20 19:14:58 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-20 19:14:58 --> Helper loaded: url_helper
DEBUG - 2011-05-20 19:14:58 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-20 19:14:58 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-20 19:14:58 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-20 19:14:58 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-20 19:14:58 --> Final output sent to browser
DEBUG - 2011-05-20 19:14:58 --> Total execution time: 0.0610
DEBUG - 2011-05-20 19:15:48 --> Config Class Initialized
DEBUG - 2011-05-20 19:15:48 --> Hooks Class Initialized
DEBUG - 2011-05-20 19:15:48 --> Utf8 Class Initialized
DEBUG - 2011-05-20 19:15:48 --> UTF-8 Support Enabled
DEBUG - 2011-05-20 19:15:48 --> URI Class Initialized
DEBUG - 2011-05-20 19:15:48 --> Router Class Initialized
DEBUG - 2011-05-20 19:15:48 --> Output Class Initialized
DEBUG - 2011-05-20 19:15:48 --> Input Class Initialized
DEBUG - 2011-05-20 19:15:48 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-20 19:15:48 --> Language Class Initialized
DEBUG - 2011-05-20 19:15:48 --> Loader Class Initialized
DEBUG - 2011-05-20 19:15:48 --> Controller Class Initialized
DEBUG - 2011-05-20 19:15:48 --> Model Class Initialized
DEBUG - 2011-05-20 19:15:48 --> Model Class Initialized
DEBUG - 2011-05-20 19:15:48 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-20 19:15:48 --> Database Driver Class Initialized
DEBUG - 2011-05-20 19:15:49 --> Final output sent to browser
DEBUG - 2011-05-20 19:15:49 --> Total execution time: 1.0402
DEBUG - 2011-05-20 21:13:01 --> Config Class Initialized
DEBUG - 2011-05-20 21:13:01 --> Hooks Class Initialized
DEBUG - 2011-05-20 21:13:01 --> Utf8 Class Initialized
DEBUG - 2011-05-20 21:13:01 --> UTF-8 Support Enabled
DEBUG - 2011-05-20 21:13:01 --> URI Class Initialized
DEBUG - 2011-05-20 21:13:01 --> Router Class Initialized
DEBUG - 2011-05-20 21:13:01 --> Output Class Initialized
DEBUG - 2011-05-20 21:13:01 --> Input Class Initialized
DEBUG - 2011-05-20 21:13:01 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-20 21:13:01 --> Language Class Initialized
DEBUG - 2011-05-20 21:13:01 --> Loader Class Initialized
DEBUG - 2011-05-20 21:13:01 --> Controller Class Initialized
ERROR - 2011-05-20 21:13:01 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-20 21:13:01 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-20 21:13:01 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-20 21:13:01 --> Model Class Initialized
DEBUG - 2011-05-20 21:13:01 --> Model Class Initialized
DEBUG - 2011-05-20 21:13:01 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-20 21:13:02 --> Database Driver Class Initialized
DEBUG - 2011-05-20 21:13:02 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-20 21:13:02 --> Helper loaded: url_helper
DEBUG - 2011-05-20 21:13:02 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-20 21:13:02 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-20 21:13:02 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-20 21:13:02 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-20 21:13:02 --> Final output sent to browser
DEBUG - 2011-05-20 21:13:02 --> Total execution time: 0.4058
DEBUG - 2011-05-20 21:13:02 --> Config Class Initialized
DEBUG - 2011-05-20 21:13:02 --> Hooks Class Initialized
DEBUG - 2011-05-20 21:13:02 --> Utf8 Class Initialized
DEBUG - 2011-05-20 21:13:02 --> UTF-8 Support Enabled
DEBUG - 2011-05-20 21:13:02 --> URI Class Initialized
DEBUG - 2011-05-20 21:13:02 --> Router Class Initialized
DEBUG - 2011-05-20 21:13:02 --> Output Class Initialized
DEBUG - 2011-05-20 21:13:02 --> Input Class Initialized
DEBUG - 2011-05-20 21:13:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-20 21:13:02 --> Language Class Initialized
DEBUG - 2011-05-20 21:13:02 --> Loader Class Initialized
DEBUG - 2011-05-20 21:13:02 --> Controller Class Initialized
DEBUG - 2011-05-20 21:13:02 --> Model Class Initialized
DEBUG - 2011-05-20 21:13:02 --> Model Class Initialized
DEBUG - 2011-05-20 21:13:02 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-20 21:13:02 --> Database Driver Class Initialized
DEBUG - 2011-05-20 21:13:03 --> Final output sent to browser
DEBUG - 2011-05-20 21:13:03 --> Total execution time: 1.3107
DEBUG - 2011-05-20 21:13:04 --> Config Class Initialized
DEBUG - 2011-05-20 21:13:04 --> Hooks Class Initialized
DEBUG - 2011-05-20 21:13:04 --> Utf8 Class Initialized
DEBUG - 2011-05-20 21:13:04 --> UTF-8 Support Enabled
DEBUG - 2011-05-20 21:13:04 --> URI Class Initialized
DEBUG - 2011-05-20 21:13:04 --> Router Class Initialized
ERROR - 2011-05-20 21:13:04 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-20 21:13:05 --> Config Class Initialized
DEBUG - 2011-05-20 21:13:05 --> Hooks Class Initialized
DEBUG - 2011-05-20 21:13:05 --> Utf8 Class Initialized
DEBUG - 2011-05-20 21:13:05 --> UTF-8 Support Enabled
DEBUG - 2011-05-20 21:13:05 --> URI Class Initialized
DEBUG - 2011-05-20 21:13:05 --> Router Class Initialized
ERROR - 2011-05-20 21:13:05 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-20 21:13:05 --> Config Class Initialized
DEBUG - 2011-05-20 21:13:05 --> Hooks Class Initialized
DEBUG - 2011-05-20 21:13:05 --> Utf8 Class Initialized
DEBUG - 2011-05-20 21:13:05 --> UTF-8 Support Enabled
DEBUG - 2011-05-20 21:13:05 --> URI Class Initialized
DEBUG - 2011-05-20 21:13:05 --> Router Class Initialized
ERROR - 2011-05-20 21:13:05 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-20 21:13:21 --> Config Class Initialized
DEBUG - 2011-05-20 21:13:21 --> Hooks Class Initialized
DEBUG - 2011-05-20 21:13:21 --> Utf8 Class Initialized
DEBUG - 2011-05-20 21:13:21 --> UTF-8 Support Enabled
DEBUG - 2011-05-20 21:13:21 --> URI Class Initialized
DEBUG - 2011-05-20 21:13:21 --> Router Class Initialized
DEBUG - 2011-05-20 21:13:21 --> Output Class Initialized
DEBUG - 2011-05-20 21:13:21 --> Input Class Initialized
DEBUG - 2011-05-20 21:13:21 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-20 21:13:21 --> Language Class Initialized
DEBUG - 2011-05-20 21:13:21 --> Loader Class Initialized
DEBUG - 2011-05-20 21:13:21 --> Controller Class Initialized
DEBUG - 2011-05-20 21:13:21 --> Model Class Initialized
DEBUG - 2011-05-20 21:13:21 --> Model Class Initialized
DEBUG - 2011-05-20 21:13:21 --> Model Class Initialized
DEBUG - 2011-05-20 21:13:21 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-20 21:13:21 --> Database Driver Class Initialized
DEBUG - 2011-05-20 21:13:21 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-20 21:13:21 --> Helper loaded: url_helper
DEBUG - 2011-05-20 21:13:21 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-20 21:13:21 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-20 21:13:21 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-20 21:13:21 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-20 21:13:21 --> Final output sent to browser
DEBUG - 2011-05-20 21:13:21 --> Total execution time: 0.3273
DEBUG - 2011-05-20 22:18:09 --> Config Class Initialized
DEBUG - 2011-05-20 22:18:09 --> Hooks Class Initialized
DEBUG - 2011-05-20 22:18:09 --> Utf8 Class Initialized
DEBUG - 2011-05-20 22:18:09 --> UTF-8 Support Enabled
DEBUG - 2011-05-20 22:18:09 --> URI Class Initialized
DEBUG - 2011-05-20 22:18:09 --> Router Class Initialized
DEBUG - 2011-05-20 22:18:09 --> No URI present. Default controller set.
DEBUG - 2011-05-20 22:18:09 --> Output Class Initialized
DEBUG - 2011-05-20 22:18:09 --> Input Class Initialized
DEBUG - 2011-05-20 22:18:09 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-20 22:18:09 --> Language Class Initialized
DEBUG - 2011-05-20 22:18:09 --> Loader Class Initialized
DEBUG - 2011-05-20 22:18:09 --> Controller Class Initialized
DEBUG - 2011-05-20 22:18:09 --> File loaded: application/views/splash/main.php
DEBUG - 2011-05-20 22:18:09 --> Helper loaded: url_helper
DEBUG - 2011-05-20 22:18:09 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-20 22:18:09 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-20 22:18:09 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-20 22:18:09 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-20 22:18:09 --> Final output sent to browser
DEBUG - 2011-05-20 22:18:09 --> Total execution time: 0.2815
DEBUG - 2011-05-20 23:26:19 --> Config Class Initialized
DEBUG - 2011-05-20 23:26:19 --> Hooks Class Initialized
DEBUG - 2011-05-20 23:26:19 --> Utf8 Class Initialized
DEBUG - 2011-05-20 23:26:19 --> UTF-8 Support Enabled
DEBUG - 2011-05-20 23:26:19 --> URI Class Initialized
DEBUG - 2011-05-20 23:26:19 --> Router Class Initialized
ERROR - 2011-05-20 23:26:19 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-05-20 23:26:19 --> Config Class Initialized
DEBUG - 2011-05-20 23:26:19 --> Hooks Class Initialized
DEBUG - 2011-05-20 23:26:19 --> Utf8 Class Initialized
DEBUG - 2011-05-20 23:26:19 --> UTF-8 Support Enabled
DEBUG - 2011-05-20 23:26:19 --> URI Class Initialized
DEBUG - 2011-05-20 23:26:19 --> Router Class Initialized
DEBUG - 2011-05-20 23:26:19 --> Output Class Initialized
DEBUG - 2011-05-20 23:26:19 --> Input Class Initialized
DEBUG - 2011-05-20 23:26:19 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-20 23:26:19 --> Language Class Initialized
DEBUG - 2011-05-20 23:26:19 --> Loader Class Initialized
DEBUG - 2011-05-20 23:26:19 --> Controller Class Initialized
DEBUG - 2011-05-20 23:26:19 --> Model Class Initialized
DEBUG - 2011-05-20 23:26:19 --> Model Class Initialized
DEBUG - 2011-05-20 23:26:19 --> Model Class Initialized
DEBUG - 2011-05-20 23:26:19 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-20 23:26:19 --> Database Driver Class Initialized
DEBUG - 2011-05-20 23:26:20 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-20 23:26:20 --> Helper loaded: url_helper
DEBUG - 2011-05-20 23:26:20 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-20 23:26:20 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-20 23:26:20 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-20 23:26:20 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-20 23:26:20 --> Final output sent to browser
DEBUG - 2011-05-20 23:26:20 --> Total execution time: 0.5322

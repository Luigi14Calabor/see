<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2011-08-06 00:49:14 --> Config Class Initialized
DEBUG - 2011-08-06 00:49:14 --> Hooks Class Initialized
DEBUG - 2011-08-06 00:49:14 --> Utf8 Class Initialized
DEBUG - 2011-08-06 00:49:14 --> UTF-8 Support Enabled
DEBUG - 2011-08-06 00:49:14 --> URI Class Initialized
DEBUG - 2011-08-06 00:49:14 --> Router Class Initialized
DEBUG - 2011-08-06 00:49:14 --> Output Class Initialized
DEBUG - 2011-08-06 00:49:14 --> Input Class Initialized
DEBUG - 2011-08-06 00:49:14 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-06 00:49:14 --> Language Class Initialized
DEBUG - 2011-08-06 00:49:14 --> Loader Class Initialized
DEBUG - 2011-08-06 00:49:14 --> Controller Class Initialized
DEBUG - 2011-08-06 00:49:14 --> Model Class Initialized
DEBUG - 2011-08-06 00:49:14 --> Model Class Initialized
DEBUG - 2011-08-06 00:49:14 --> Model Class Initialized
DEBUG - 2011-08-06 00:49:14 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-06 00:49:14 --> Database Driver Class Initialized
DEBUG - 2011-08-06 00:49:15 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-06 00:49:15 --> Helper loaded: url_helper
DEBUG - 2011-08-06 00:49:15 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-06 00:49:15 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-06 00:49:15 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-06 00:49:15 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-06 00:49:15 --> Final output sent to browser
DEBUG - 2011-08-06 00:49:15 --> Total execution time: 0.3664
DEBUG - 2011-08-06 00:49:16 --> Config Class Initialized
DEBUG - 2011-08-06 00:49:16 --> Hooks Class Initialized
DEBUG - 2011-08-06 00:49:16 --> Utf8 Class Initialized
DEBUG - 2011-08-06 00:49:16 --> UTF-8 Support Enabled
DEBUG - 2011-08-06 00:49:16 --> URI Class Initialized
DEBUG - 2011-08-06 00:49:16 --> Router Class Initialized
ERROR - 2011-08-06 00:49:16 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-06 03:48:07 --> Config Class Initialized
DEBUG - 2011-08-06 03:48:07 --> Hooks Class Initialized
DEBUG - 2011-08-06 03:48:07 --> Utf8 Class Initialized
DEBUG - 2011-08-06 03:48:07 --> UTF-8 Support Enabled
DEBUG - 2011-08-06 03:48:07 --> URI Class Initialized
DEBUG - 2011-08-06 03:48:07 --> Router Class Initialized
DEBUG - 2011-08-06 03:48:07 --> Output Class Initialized
DEBUG - 2011-08-06 03:48:07 --> Input Class Initialized
DEBUG - 2011-08-06 03:48:07 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-06 03:48:07 --> Language Class Initialized
DEBUG - 2011-08-06 03:48:07 --> Loader Class Initialized
DEBUG - 2011-08-06 03:48:07 --> Controller Class Initialized
ERROR - 2011-08-06 03:48:07 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-06 03:48:07 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-06 03:48:07 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-06 03:48:07 --> Model Class Initialized
DEBUG - 2011-08-06 03:48:07 --> Model Class Initialized
DEBUG - 2011-08-06 03:48:07 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-06 03:48:07 --> Database Driver Class Initialized
DEBUG - 2011-08-06 03:48:07 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-06 03:48:07 --> Helper loaded: url_helper
DEBUG - 2011-08-06 03:48:07 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-06 03:48:07 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-06 03:48:07 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-06 03:48:07 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-06 03:48:07 --> Final output sent to browser
DEBUG - 2011-08-06 03:48:07 --> Total execution time: 0.3985
DEBUG - 2011-08-06 03:48:07 --> Config Class Initialized
DEBUG - 2011-08-06 03:48:07 --> Hooks Class Initialized
DEBUG - 2011-08-06 03:48:07 --> Utf8 Class Initialized
DEBUG - 2011-08-06 03:48:07 --> UTF-8 Support Enabled
DEBUG - 2011-08-06 03:48:07 --> URI Class Initialized
DEBUG - 2011-08-06 03:48:07 --> Router Class Initialized
DEBUG - 2011-08-06 03:48:07 --> Output Class Initialized
DEBUG - 2011-08-06 03:48:07 --> Input Class Initialized
DEBUG - 2011-08-06 03:48:07 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-06 03:48:07 --> Language Class Initialized
DEBUG - 2011-08-06 03:48:07 --> Loader Class Initialized
DEBUG - 2011-08-06 03:48:07 --> Controller Class Initialized
DEBUG - 2011-08-06 03:48:07 --> Model Class Initialized
DEBUG - 2011-08-06 03:48:07 --> Model Class Initialized
DEBUG - 2011-08-06 03:48:07 --> Model Class Initialized
DEBUG - 2011-08-06 03:48:07 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-06 03:48:07 --> Database Driver Class Initialized
DEBUG - 2011-08-06 03:48:08 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-06 03:48:08 --> Helper loaded: url_helper
DEBUG - 2011-08-06 03:48:08 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-06 03:48:08 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-06 03:48:08 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-06 03:48:08 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-06 03:48:08 --> Final output sent to browser
DEBUG - 2011-08-06 03:48:08 --> Total execution time: 0.3547
DEBUG - 2011-08-06 03:48:08 --> Config Class Initialized
DEBUG - 2011-08-06 03:48:08 --> Hooks Class Initialized
DEBUG - 2011-08-06 03:48:08 --> Utf8 Class Initialized
DEBUG - 2011-08-06 03:48:08 --> UTF-8 Support Enabled
DEBUG - 2011-08-06 03:48:08 --> URI Class Initialized
DEBUG - 2011-08-06 03:48:08 --> Router Class Initialized
DEBUG - 2011-08-06 03:48:08 --> Output Class Initialized
DEBUG - 2011-08-06 03:48:08 --> Input Class Initialized
DEBUG - 2011-08-06 03:48:08 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-06 03:48:08 --> Language Class Initialized
DEBUG - 2011-08-06 03:48:08 --> Loader Class Initialized
DEBUG - 2011-08-06 03:48:08 --> Controller Class Initialized
DEBUG - 2011-08-06 03:48:08 --> Model Class Initialized
DEBUG - 2011-08-06 03:48:08 --> Model Class Initialized
DEBUG - 2011-08-06 03:48:08 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-06 03:48:08 --> Database Driver Class Initialized
DEBUG - 2011-08-06 03:48:09 --> Final output sent to browser
DEBUG - 2011-08-06 03:48:09 --> Total execution time: 1.0970
DEBUG - 2011-08-06 03:48:09 --> Config Class Initialized
DEBUG - 2011-08-06 03:48:09 --> Hooks Class Initialized
DEBUG - 2011-08-06 03:48:09 --> Utf8 Class Initialized
DEBUG - 2011-08-06 03:48:09 --> UTF-8 Support Enabled
DEBUG - 2011-08-06 03:48:09 --> URI Class Initialized
DEBUG - 2011-08-06 03:48:09 --> Router Class Initialized
ERROR - 2011-08-06 03:48:09 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-06 03:48:10 --> Config Class Initialized
DEBUG - 2011-08-06 03:48:10 --> Hooks Class Initialized
DEBUG - 2011-08-06 03:48:10 --> Utf8 Class Initialized
DEBUG - 2011-08-06 03:48:10 --> UTF-8 Support Enabled
DEBUG - 2011-08-06 03:48:10 --> URI Class Initialized
DEBUG - 2011-08-06 03:48:10 --> Router Class Initialized
ERROR - 2011-08-06 03:48:10 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-06 03:48:10 --> Config Class Initialized
DEBUG - 2011-08-06 03:48:10 --> Hooks Class Initialized
DEBUG - 2011-08-06 03:48:10 --> Utf8 Class Initialized
DEBUG - 2011-08-06 03:48:10 --> UTF-8 Support Enabled
DEBUG - 2011-08-06 03:48:10 --> URI Class Initialized
DEBUG - 2011-08-06 03:48:10 --> Router Class Initialized
ERROR - 2011-08-06 03:48:10 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-06 03:50:14 --> Config Class Initialized
DEBUG - 2011-08-06 03:50:14 --> Hooks Class Initialized
DEBUG - 2011-08-06 03:50:14 --> Utf8 Class Initialized
DEBUG - 2011-08-06 03:50:14 --> UTF-8 Support Enabled
DEBUG - 2011-08-06 03:50:14 --> URI Class Initialized
DEBUG - 2011-08-06 03:50:14 --> Router Class Initialized
DEBUG - 2011-08-06 03:50:14 --> Output Class Initialized
DEBUG - 2011-08-06 03:50:14 --> Input Class Initialized
DEBUG - 2011-08-06 03:50:14 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-06 03:50:14 --> Language Class Initialized
DEBUG - 2011-08-06 03:50:14 --> Loader Class Initialized
DEBUG - 2011-08-06 03:50:14 --> Controller Class Initialized
ERROR - 2011-08-06 03:50:14 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-06 03:50:14 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-06 03:50:14 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-06 03:50:14 --> Model Class Initialized
DEBUG - 2011-08-06 03:50:14 --> Model Class Initialized
DEBUG - 2011-08-06 03:50:14 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-06 03:50:14 --> Database Driver Class Initialized
DEBUG - 2011-08-06 03:50:14 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-06 03:50:14 --> Helper loaded: url_helper
DEBUG - 2011-08-06 03:50:14 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-06 03:50:14 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-06 03:50:14 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-06 03:50:14 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-06 03:50:14 --> Final output sent to browser
DEBUG - 2011-08-06 03:50:14 --> Total execution time: 0.0295
DEBUG - 2011-08-06 03:50:14 --> Config Class Initialized
DEBUG - 2011-08-06 03:50:14 --> Hooks Class Initialized
DEBUG - 2011-08-06 03:50:14 --> Utf8 Class Initialized
DEBUG - 2011-08-06 03:50:14 --> UTF-8 Support Enabled
DEBUG - 2011-08-06 03:50:14 --> URI Class Initialized
DEBUG - 2011-08-06 03:50:14 --> Router Class Initialized
DEBUG - 2011-08-06 03:50:14 --> Output Class Initialized
DEBUG - 2011-08-06 03:50:14 --> Input Class Initialized
DEBUG - 2011-08-06 03:50:14 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-06 03:50:14 --> Language Class Initialized
DEBUG - 2011-08-06 03:50:14 --> Loader Class Initialized
DEBUG - 2011-08-06 03:50:14 --> Controller Class Initialized
DEBUG - 2011-08-06 03:50:14 --> Model Class Initialized
DEBUG - 2011-08-06 03:50:14 --> Model Class Initialized
DEBUG - 2011-08-06 03:50:14 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-06 03:50:14 --> Database Driver Class Initialized
DEBUG - 2011-08-06 03:50:15 --> Final output sent to browser
DEBUG - 2011-08-06 03:50:15 --> Total execution time: 0.6491
DEBUG - 2011-08-06 03:50:24 --> Config Class Initialized
DEBUG - 2011-08-06 03:50:24 --> Hooks Class Initialized
DEBUG - 2011-08-06 03:50:24 --> Utf8 Class Initialized
DEBUG - 2011-08-06 03:50:24 --> UTF-8 Support Enabled
DEBUG - 2011-08-06 03:50:24 --> URI Class Initialized
DEBUG - 2011-08-06 03:50:24 --> Router Class Initialized
DEBUG - 2011-08-06 03:50:24 --> Output Class Initialized
DEBUG - 2011-08-06 03:50:24 --> Input Class Initialized
DEBUG - 2011-08-06 03:50:24 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-06 03:50:24 --> Language Class Initialized
DEBUG - 2011-08-06 03:50:24 --> Loader Class Initialized
DEBUG - 2011-08-06 03:50:24 --> Controller Class Initialized
ERROR - 2011-08-06 03:50:24 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-06 03:50:24 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-06 03:50:24 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-06 03:50:24 --> Model Class Initialized
DEBUG - 2011-08-06 03:50:24 --> Model Class Initialized
DEBUG - 2011-08-06 03:50:24 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-06 03:50:24 --> Database Driver Class Initialized
DEBUG - 2011-08-06 03:50:24 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-06 03:50:24 --> Helper loaded: url_helper
DEBUG - 2011-08-06 03:50:24 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-06 03:50:24 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-06 03:50:24 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-06 03:50:24 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-06 03:50:24 --> Final output sent to browser
DEBUG - 2011-08-06 03:50:24 --> Total execution time: 0.0281
DEBUG - 2011-08-06 03:50:25 --> Config Class Initialized
DEBUG - 2011-08-06 03:50:25 --> Hooks Class Initialized
DEBUG - 2011-08-06 03:50:25 --> Utf8 Class Initialized
DEBUG - 2011-08-06 03:50:25 --> UTF-8 Support Enabled
DEBUG - 2011-08-06 03:50:25 --> URI Class Initialized
DEBUG - 2011-08-06 03:50:25 --> Router Class Initialized
DEBUG - 2011-08-06 03:50:25 --> Output Class Initialized
DEBUG - 2011-08-06 03:50:25 --> Input Class Initialized
DEBUG - 2011-08-06 03:50:25 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-06 03:50:25 --> Language Class Initialized
DEBUG - 2011-08-06 03:50:25 --> Loader Class Initialized
DEBUG - 2011-08-06 03:50:25 --> Controller Class Initialized
DEBUG - 2011-08-06 03:50:25 --> Model Class Initialized
DEBUG - 2011-08-06 03:50:25 --> Model Class Initialized
DEBUG - 2011-08-06 03:50:25 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-06 03:50:25 --> Database Driver Class Initialized
DEBUG - 2011-08-06 03:50:25 --> Final output sent to browser
DEBUG - 2011-08-06 03:50:25 --> Total execution time: 0.5039
DEBUG - 2011-08-06 03:50:37 --> Config Class Initialized
DEBUG - 2011-08-06 03:50:37 --> Hooks Class Initialized
DEBUG - 2011-08-06 03:50:37 --> Utf8 Class Initialized
DEBUG - 2011-08-06 03:50:37 --> UTF-8 Support Enabled
DEBUG - 2011-08-06 03:50:37 --> URI Class Initialized
DEBUG - 2011-08-06 03:50:37 --> Router Class Initialized
DEBUG - 2011-08-06 03:50:37 --> Output Class Initialized
DEBUG - 2011-08-06 03:50:37 --> Input Class Initialized
DEBUG - 2011-08-06 03:50:37 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-06 03:50:37 --> Language Class Initialized
DEBUG - 2011-08-06 03:50:37 --> Loader Class Initialized
DEBUG - 2011-08-06 03:50:37 --> Controller Class Initialized
ERROR - 2011-08-06 03:50:37 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-06 03:50:37 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-06 03:50:37 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-06 03:50:37 --> Model Class Initialized
DEBUG - 2011-08-06 03:50:37 --> Model Class Initialized
DEBUG - 2011-08-06 03:50:37 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-06 03:50:37 --> Database Driver Class Initialized
DEBUG - 2011-08-06 03:50:37 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-06 03:50:37 --> Helper loaded: url_helper
DEBUG - 2011-08-06 03:50:37 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-06 03:50:37 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-06 03:50:37 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-06 03:50:37 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-06 03:50:37 --> Final output sent to browser
DEBUG - 2011-08-06 03:50:37 --> Total execution time: 0.0286
DEBUG - 2011-08-06 03:50:38 --> Config Class Initialized
DEBUG - 2011-08-06 03:50:38 --> Hooks Class Initialized
DEBUG - 2011-08-06 03:50:38 --> Utf8 Class Initialized
DEBUG - 2011-08-06 03:50:38 --> UTF-8 Support Enabled
DEBUG - 2011-08-06 03:50:38 --> URI Class Initialized
DEBUG - 2011-08-06 03:50:38 --> Router Class Initialized
DEBUG - 2011-08-06 03:50:38 --> Output Class Initialized
DEBUG - 2011-08-06 03:50:38 --> Input Class Initialized
DEBUG - 2011-08-06 03:50:38 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-06 03:50:38 --> Language Class Initialized
DEBUG - 2011-08-06 03:50:38 --> Loader Class Initialized
DEBUG - 2011-08-06 03:50:38 --> Controller Class Initialized
DEBUG - 2011-08-06 03:50:38 --> Model Class Initialized
DEBUG - 2011-08-06 03:50:38 --> Model Class Initialized
DEBUG - 2011-08-06 03:50:38 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-06 03:50:38 --> Database Driver Class Initialized
DEBUG - 2011-08-06 03:50:38 --> Final output sent to browser
DEBUG - 2011-08-06 03:50:38 --> Total execution time: 0.6353
DEBUG - 2011-08-06 03:51:01 --> Config Class Initialized
DEBUG - 2011-08-06 03:51:01 --> Hooks Class Initialized
DEBUG - 2011-08-06 03:51:01 --> Utf8 Class Initialized
DEBUG - 2011-08-06 03:51:01 --> UTF-8 Support Enabled
DEBUG - 2011-08-06 03:51:01 --> URI Class Initialized
DEBUG - 2011-08-06 03:51:01 --> Router Class Initialized
DEBUG - 2011-08-06 03:51:01 --> Output Class Initialized
DEBUG - 2011-08-06 03:51:01 --> Input Class Initialized
DEBUG - 2011-08-06 03:51:01 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-06 03:51:01 --> Language Class Initialized
DEBUG - 2011-08-06 03:51:01 --> Loader Class Initialized
DEBUG - 2011-08-06 03:51:01 --> Controller Class Initialized
ERROR - 2011-08-06 03:51:01 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-06 03:51:01 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-06 03:51:01 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-06 03:51:01 --> Model Class Initialized
DEBUG - 2011-08-06 03:51:01 --> Model Class Initialized
DEBUG - 2011-08-06 03:51:01 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-06 03:51:01 --> Database Driver Class Initialized
DEBUG - 2011-08-06 03:51:01 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-06 03:51:01 --> Helper loaded: url_helper
DEBUG - 2011-08-06 03:51:01 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-06 03:51:01 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-06 03:51:01 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-06 03:51:01 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-06 03:51:01 --> Final output sent to browser
DEBUG - 2011-08-06 03:51:01 --> Total execution time: 0.0291
DEBUG - 2011-08-06 03:51:01 --> Config Class Initialized
DEBUG - 2011-08-06 03:51:01 --> Hooks Class Initialized
DEBUG - 2011-08-06 03:51:01 --> Utf8 Class Initialized
DEBUG - 2011-08-06 03:51:01 --> UTF-8 Support Enabled
DEBUG - 2011-08-06 03:51:01 --> URI Class Initialized
DEBUG - 2011-08-06 03:51:01 --> Router Class Initialized
DEBUG - 2011-08-06 03:51:01 --> Output Class Initialized
DEBUG - 2011-08-06 03:51:01 --> Input Class Initialized
DEBUG - 2011-08-06 03:51:01 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-06 03:51:01 --> Language Class Initialized
DEBUG - 2011-08-06 03:51:01 --> Loader Class Initialized
DEBUG - 2011-08-06 03:51:01 --> Controller Class Initialized
DEBUG - 2011-08-06 03:51:01 --> Model Class Initialized
DEBUG - 2011-08-06 03:51:01 --> Model Class Initialized
DEBUG - 2011-08-06 03:51:01 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-06 03:51:01 --> Database Driver Class Initialized
DEBUG - 2011-08-06 03:51:02 --> Final output sent to browser
DEBUG - 2011-08-06 03:51:02 --> Total execution time: 0.6834
DEBUG - 2011-08-06 03:51:18 --> Config Class Initialized
DEBUG - 2011-08-06 03:51:18 --> Hooks Class Initialized
DEBUG - 2011-08-06 03:51:18 --> Utf8 Class Initialized
DEBUG - 2011-08-06 03:51:18 --> UTF-8 Support Enabled
DEBUG - 2011-08-06 03:51:18 --> URI Class Initialized
DEBUG - 2011-08-06 03:51:18 --> Router Class Initialized
DEBUG - 2011-08-06 03:51:18 --> Output Class Initialized
DEBUG - 2011-08-06 03:51:18 --> Input Class Initialized
DEBUG - 2011-08-06 03:51:18 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-06 03:51:18 --> Language Class Initialized
DEBUG - 2011-08-06 03:51:18 --> Loader Class Initialized
DEBUG - 2011-08-06 03:51:18 --> Controller Class Initialized
ERROR - 2011-08-06 03:51:18 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-06 03:51:18 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-06 03:51:18 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-06 03:51:18 --> Model Class Initialized
DEBUG - 2011-08-06 03:51:18 --> Model Class Initialized
DEBUG - 2011-08-06 03:51:18 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-06 03:51:18 --> Database Driver Class Initialized
DEBUG - 2011-08-06 03:51:18 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-06 03:51:18 --> Helper loaded: url_helper
DEBUG - 2011-08-06 03:51:18 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-06 03:51:18 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-06 03:51:18 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-06 03:51:18 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-06 03:51:18 --> Final output sent to browser
DEBUG - 2011-08-06 03:51:18 --> Total execution time: 0.0287
DEBUG - 2011-08-06 03:51:18 --> Config Class Initialized
DEBUG - 2011-08-06 03:51:18 --> Hooks Class Initialized
DEBUG - 2011-08-06 03:51:18 --> Utf8 Class Initialized
DEBUG - 2011-08-06 03:51:18 --> UTF-8 Support Enabled
DEBUG - 2011-08-06 03:51:18 --> URI Class Initialized
DEBUG - 2011-08-06 03:51:18 --> Router Class Initialized
DEBUG - 2011-08-06 03:51:18 --> Output Class Initialized
DEBUG - 2011-08-06 03:51:18 --> Input Class Initialized
DEBUG - 2011-08-06 03:51:18 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-06 03:51:18 --> Language Class Initialized
DEBUG - 2011-08-06 03:51:18 --> Loader Class Initialized
DEBUG - 2011-08-06 03:51:18 --> Controller Class Initialized
DEBUG - 2011-08-06 03:51:18 --> Model Class Initialized
DEBUG - 2011-08-06 03:51:18 --> Model Class Initialized
DEBUG - 2011-08-06 03:51:18 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-06 03:51:18 --> Database Driver Class Initialized
DEBUG - 2011-08-06 03:51:19 --> Final output sent to browser
DEBUG - 2011-08-06 03:51:19 --> Total execution time: 0.5970
DEBUG - 2011-08-06 03:51:56 --> Config Class Initialized
DEBUG - 2011-08-06 03:51:56 --> Hooks Class Initialized
DEBUG - 2011-08-06 03:51:56 --> Utf8 Class Initialized
DEBUG - 2011-08-06 03:51:56 --> UTF-8 Support Enabled
DEBUG - 2011-08-06 03:51:56 --> URI Class Initialized
DEBUG - 2011-08-06 03:51:56 --> Router Class Initialized
DEBUG - 2011-08-06 03:51:56 --> Output Class Initialized
DEBUG - 2011-08-06 03:51:56 --> Input Class Initialized
DEBUG - 2011-08-06 03:51:56 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-06 03:51:56 --> Language Class Initialized
DEBUG - 2011-08-06 03:51:56 --> Loader Class Initialized
DEBUG - 2011-08-06 03:51:56 --> Controller Class Initialized
DEBUG - 2011-08-06 03:51:56 --> Model Class Initialized
DEBUG - 2011-08-06 03:51:56 --> Model Class Initialized
DEBUG - 2011-08-06 03:51:56 --> Model Class Initialized
DEBUG - 2011-08-06 03:51:56 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-06 03:51:56 --> Database Driver Class Initialized
DEBUG - 2011-08-06 03:51:56 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-06 03:51:56 --> Helper loaded: url_helper
DEBUG - 2011-08-06 03:51:56 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-06 03:51:56 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-06 03:51:56 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-06 03:51:56 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-06 03:51:56 --> Final output sent to browser
DEBUG - 2011-08-06 03:51:56 --> Total execution time: 0.2111
DEBUG - 2011-08-06 03:52:06 --> Config Class Initialized
DEBUG - 2011-08-06 03:52:06 --> Hooks Class Initialized
DEBUG - 2011-08-06 03:52:06 --> Utf8 Class Initialized
DEBUG - 2011-08-06 03:52:06 --> UTF-8 Support Enabled
DEBUG - 2011-08-06 03:52:06 --> URI Class Initialized
DEBUG - 2011-08-06 03:52:06 --> Router Class Initialized
DEBUG - 2011-08-06 03:52:06 --> Output Class Initialized
DEBUG - 2011-08-06 03:52:06 --> Input Class Initialized
DEBUG - 2011-08-06 03:52:06 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-06 03:52:06 --> Language Class Initialized
DEBUG - 2011-08-06 03:52:06 --> Loader Class Initialized
DEBUG - 2011-08-06 03:52:06 --> Controller Class Initialized
DEBUG - 2011-08-06 03:52:06 --> Model Class Initialized
DEBUG - 2011-08-06 03:52:06 --> Model Class Initialized
DEBUG - 2011-08-06 03:52:06 --> Model Class Initialized
DEBUG - 2011-08-06 03:52:06 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-06 03:52:06 --> Database Driver Class Initialized
DEBUG - 2011-08-06 03:52:06 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-06 03:52:06 --> Helper loaded: url_helper
DEBUG - 2011-08-06 03:52:06 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-06 03:52:06 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-06 03:52:06 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-06 03:52:06 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-06 03:52:06 --> Final output sent to browser
DEBUG - 2011-08-06 03:52:06 --> Total execution time: 0.3170
DEBUG - 2011-08-06 04:08:56 --> Config Class Initialized
DEBUG - 2011-08-06 04:08:56 --> Hooks Class Initialized
DEBUG - 2011-08-06 04:08:56 --> Utf8 Class Initialized
DEBUG - 2011-08-06 04:08:56 --> UTF-8 Support Enabled
DEBUG - 2011-08-06 04:08:56 --> URI Class Initialized
DEBUG - 2011-08-06 04:08:56 --> Router Class Initialized
ERROR - 2011-08-06 04:08:56 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-08-06 04:20:10 --> Config Class Initialized
DEBUG - 2011-08-06 04:20:10 --> Hooks Class Initialized
DEBUG - 2011-08-06 04:20:10 --> Utf8 Class Initialized
DEBUG - 2011-08-06 04:20:10 --> UTF-8 Support Enabled
DEBUG - 2011-08-06 04:20:10 --> URI Class Initialized
DEBUG - 2011-08-06 04:20:10 --> Router Class Initialized
DEBUG - 2011-08-06 04:20:10 --> Output Class Initialized
DEBUG - 2011-08-06 04:20:10 --> Input Class Initialized
DEBUG - 2011-08-06 04:20:10 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-06 04:20:10 --> Language Class Initialized
DEBUG - 2011-08-06 04:20:10 --> Loader Class Initialized
DEBUG - 2011-08-06 04:20:10 --> Controller Class Initialized
DEBUG - 2011-08-06 04:20:10 --> Model Class Initialized
DEBUG - 2011-08-06 04:20:10 --> Model Class Initialized
DEBUG - 2011-08-06 04:20:10 --> Model Class Initialized
DEBUG - 2011-08-06 04:20:10 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-06 04:20:10 --> Database Driver Class Initialized
DEBUG - 2011-08-06 04:20:11 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-06 04:20:11 --> Helper loaded: url_helper
DEBUG - 2011-08-06 04:20:11 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-06 04:20:11 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-06 04:20:11 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-06 04:20:11 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-06 04:20:11 --> Final output sent to browser
DEBUG - 2011-08-06 04:20:11 --> Total execution time: 0.2103
DEBUG - 2011-08-06 04:25:42 --> Config Class Initialized
DEBUG - 2011-08-06 04:25:42 --> Hooks Class Initialized
DEBUG - 2011-08-06 04:25:42 --> Utf8 Class Initialized
DEBUG - 2011-08-06 04:25:42 --> UTF-8 Support Enabled
DEBUG - 2011-08-06 04:25:42 --> URI Class Initialized
DEBUG - 2011-08-06 04:25:42 --> Router Class Initialized
DEBUG - 2011-08-06 04:25:42 --> No URI present. Default controller set.
DEBUG - 2011-08-06 04:25:42 --> Output Class Initialized
DEBUG - 2011-08-06 04:25:42 --> Input Class Initialized
DEBUG - 2011-08-06 04:25:42 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-06 04:25:42 --> Language Class Initialized
DEBUG - 2011-08-06 04:25:42 --> Loader Class Initialized
DEBUG - 2011-08-06 04:25:42 --> Controller Class Initialized
DEBUG - 2011-08-06 04:25:42 --> File loaded: application/views/splash/main.php
DEBUG - 2011-08-06 04:25:42 --> Helper loaded: url_helper
DEBUG - 2011-08-06 04:25:42 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-06 04:25:42 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-06 04:25:42 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-06 04:25:42 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-06 04:25:42 --> Final output sent to browser
DEBUG - 2011-08-06 04:25:42 --> Total execution time: 0.0621
DEBUG - 2011-08-06 05:09:08 --> Config Class Initialized
DEBUG - 2011-08-06 05:09:08 --> Hooks Class Initialized
DEBUG - 2011-08-06 05:09:08 --> Utf8 Class Initialized
DEBUG - 2011-08-06 05:09:08 --> UTF-8 Support Enabled
DEBUG - 2011-08-06 05:09:08 --> URI Class Initialized
DEBUG - 2011-08-06 05:09:08 --> Router Class Initialized
DEBUG - 2011-08-06 05:09:08 --> Output Class Initialized
DEBUG - 2011-08-06 05:09:08 --> Input Class Initialized
DEBUG - 2011-08-06 05:09:08 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-06 05:09:08 --> Language Class Initialized
DEBUG - 2011-08-06 05:09:08 --> Loader Class Initialized
DEBUG - 2011-08-06 05:09:08 --> Controller Class Initialized
ERROR - 2011-08-06 05:09:08 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-06 05:09:08 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-06 05:09:08 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-06 05:09:08 --> Model Class Initialized
DEBUG - 2011-08-06 05:09:08 --> Model Class Initialized
DEBUG - 2011-08-06 05:09:08 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-06 05:09:08 --> Database Driver Class Initialized
DEBUG - 2011-08-06 05:09:08 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-06 05:09:08 --> Helper loaded: url_helper
DEBUG - 2011-08-06 05:09:08 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-06 05:09:08 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-06 05:09:08 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-06 05:09:08 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-06 05:09:08 --> Final output sent to browser
DEBUG - 2011-08-06 05:09:08 --> Total execution time: 0.0298
DEBUG - 2011-08-06 05:09:11 --> Config Class Initialized
DEBUG - 2011-08-06 05:09:11 --> Hooks Class Initialized
DEBUG - 2011-08-06 05:09:11 --> Utf8 Class Initialized
DEBUG - 2011-08-06 05:09:11 --> UTF-8 Support Enabled
DEBUG - 2011-08-06 05:09:11 --> URI Class Initialized
DEBUG - 2011-08-06 05:09:11 --> Router Class Initialized
DEBUG - 2011-08-06 05:09:11 --> Output Class Initialized
DEBUG - 2011-08-06 05:09:11 --> Input Class Initialized
DEBUG - 2011-08-06 05:09:11 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-06 05:09:11 --> Language Class Initialized
DEBUG - 2011-08-06 05:09:11 --> Loader Class Initialized
DEBUG - 2011-08-06 05:09:11 --> Controller Class Initialized
DEBUG - 2011-08-06 05:09:11 --> Model Class Initialized
DEBUG - 2011-08-06 05:09:11 --> Model Class Initialized
DEBUG - 2011-08-06 05:09:11 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-06 05:09:11 --> Database Driver Class Initialized
DEBUG - 2011-08-06 05:09:12 --> Final output sent to browser
DEBUG - 2011-08-06 05:09:12 --> Total execution time: 0.7067
DEBUG - 2011-08-06 05:09:21 --> Config Class Initialized
DEBUG - 2011-08-06 05:09:21 --> Hooks Class Initialized
DEBUG - 2011-08-06 05:09:21 --> Utf8 Class Initialized
DEBUG - 2011-08-06 05:09:21 --> UTF-8 Support Enabled
DEBUG - 2011-08-06 05:09:21 --> URI Class Initialized
DEBUG - 2011-08-06 05:09:21 --> Router Class Initialized
ERROR - 2011-08-06 05:09:21 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-06 07:41:53 --> Config Class Initialized
DEBUG - 2011-08-06 07:41:53 --> Hooks Class Initialized
DEBUG - 2011-08-06 07:41:53 --> Utf8 Class Initialized
DEBUG - 2011-08-06 07:41:53 --> UTF-8 Support Enabled
DEBUG - 2011-08-06 07:41:53 --> URI Class Initialized
DEBUG - 2011-08-06 07:41:53 --> Router Class Initialized
DEBUG - 2011-08-06 07:41:53 --> Output Class Initialized
DEBUG - 2011-08-06 07:41:53 --> Input Class Initialized
DEBUG - 2011-08-06 07:41:53 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-06 07:41:53 --> Language Class Initialized
DEBUG - 2011-08-06 07:41:53 --> Loader Class Initialized
DEBUG - 2011-08-06 07:41:53 --> Controller Class Initialized
ERROR - 2011-08-06 07:41:53 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-06 07:41:53 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-06 07:41:53 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-06 07:41:53 --> Model Class Initialized
DEBUG - 2011-08-06 07:41:53 --> Model Class Initialized
DEBUG - 2011-08-06 07:41:53 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-06 07:41:53 --> Database Driver Class Initialized
DEBUG - 2011-08-06 07:41:53 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-06 07:41:54 --> Helper loaded: url_helper
DEBUG - 2011-08-06 07:41:54 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-06 07:41:54 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-06 07:41:54 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-06 07:41:54 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-06 07:41:54 --> Final output sent to browser
DEBUG - 2011-08-06 07:41:54 --> Total execution time: 0.6062
DEBUG - 2011-08-06 07:41:55 --> Config Class Initialized
DEBUG - 2011-08-06 07:41:55 --> Hooks Class Initialized
DEBUG - 2011-08-06 07:41:55 --> Utf8 Class Initialized
DEBUG - 2011-08-06 07:41:55 --> UTF-8 Support Enabled
DEBUG - 2011-08-06 07:41:55 --> URI Class Initialized
DEBUG - 2011-08-06 07:41:55 --> Router Class Initialized
DEBUG - 2011-08-06 07:41:55 --> Output Class Initialized
DEBUG - 2011-08-06 07:41:55 --> Input Class Initialized
DEBUG - 2011-08-06 07:41:55 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-06 07:41:55 --> Language Class Initialized
DEBUG - 2011-08-06 07:41:55 --> Loader Class Initialized
DEBUG - 2011-08-06 07:41:55 --> Controller Class Initialized
DEBUG - 2011-08-06 07:41:55 --> Model Class Initialized
DEBUG - 2011-08-06 07:41:55 --> Model Class Initialized
DEBUG - 2011-08-06 07:41:55 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-06 07:41:55 --> Database Driver Class Initialized
DEBUG - 2011-08-06 07:41:56 --> Final output sent to browser
DEBUG - 2011-08-06 07:41:56 --> Total execution time: 0.6844
DEBUG - 2011-08-06 07:41:57 --> Config Class Initialized
DEBUG - 2011-08-06 07:41:57 --> Hooks Class Initialized
DEBUG - 2011-08-06 07:41:57 --> Utf8 Class Initialized
DEBUG - 2011-08-06 07:41:57 --> UTF-8 Support Enabled
DEBUG - 2011-08-06 07:41:57 --> URI Class Initialized
DEBUG - 2011-08-06 07:41:57 --> Router Class Initialized
ERROR - 2011-08-06 07:41:57 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-06 07:42:24 --> Config Class Initialized
DEBUG - 2011-08-06 07:42:24 --> Hooks Class Initialized
DEBUG - 2011-08-06 07:42:24 --> Utf8 Class Initialized
DEBUG - 2011-08-06 07:42:24 --> UTF-8 Support Enabled
DEBUG - 2011-08-06 07:42:24 --> URI Class Initialized
DEBUG - 2011-08-06 07:42:24 --> Router Class Initialized
ERROR - 2011-08-06 07:42:24 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-08-06 07:42:24 --> Config Class Initialized
DEBUG - 2011-08-06 07:42:24 --> Hooks Class Initialized
DEBUG - 2011-08-06 07:42:24 --> Utf8 Class Initialized
DEBUG - 2011-08-06 07:42:24 --> UTF-8 Support Enabled
DEBUG - 2011-08-06 07:42:24 --> URI Class Initialized
DEBUG - 2011-08-06 07:42:24 --> Router Class Initialized
DEBUG - 2011-08-06 07:42:24 --> Output Class Initialized
DEBUG - 2011-08-06 07:42:24 --> Input Class Initialized
DEBUG - 2011-08-06 07:42:24 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-06 07:42:24 --> Language Class Initialized
DEBUG - 2011-08-06 07:42:24 --> Loader Class Initialized
DEBUG - 2011-08-06 07:42:24 --> Controller Class Initialized
ERROR - 2011-08-06 07:42:24 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-06 07:42:24 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-06 07:42:24 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-06 07:42:24 --> Model Class Initialized
DEBUG - 2011-08-06 07:42:24 --> Model Class Initialized
DEBUG - 2011-08-06 07:42:24 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-06 07:42:24 --> Database Driver Class Initialized
DEBUG - 2011-08-06 07:42:24 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-06 07:42:24 --> Helper loaded: url_helper
DEBUG - 2011-08-06 07:42:24 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-06 07:42:24 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-06 07:42:24 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-06 07:42:24 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-06 07:42:24 --> Final output sent to browser
DEBUG - 2011-08-06 07:42:24 --> Total execution time: 0.0295
DEBUG - 2011-08-06 07:42:27 --> Config Class Initialized
DEBUG - 2011-08-06 07:42:27 --> Hooks Class Initialized
DEBUG - 2011-08-06 07:42:27 --> Utf8 Class Initialized
DEBUG - 2011-08-06 07:42:27 --> UTF-8 Support Enabled
DEBUG - 2011-08-06 07:42:27 --> URI Class Initialized
DEBUG - 2011-08-06 07:42:27 --> Router Class Initialized
DEBUG - 2011-08-06 07:42:27 --> Output Class Initialized
DEBUG - 2011-08-06 07:42:27 --> Input Class Initialized
DEBUG - 2011-08-06 07:42:27 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-06 07:42:27 --> Language Class Initialized
DEBUG - 2011-08-06 07:42:27 --> Loader Class Initialized
DEBUG - 2011-08-06 07:42:27 --> Controller Class Initialized
DEBUG - 2011-08-06 07:42:27 --> Model Class Initialized
DEBUG - 2011-08-06 07:42:27 --> Model Class Initialized
DEBUG - 2011-08-06 07:42:27 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-06 07:42:27 --> Database Driver Class Initialized
DEBUG - 2011-08-06 07:42:27 --> Final output sent to browser
DEBUG - 2011-08-06 07:42:27 --> Total execution time: 0.6084
DEBUG - 2011-08-06 07:43:00 --> Config Class Initialized
DEBUG - 2011-08-06 07:43:00 --> Hooks Class Initialized
DEBUG - 2011-08-06 07:43:00 --> Utf8 Class Initialized
DEBUG - 2011-08-06 07:43:00 --> UTF-8 Support Enabled
DEBUG - 2011-08-06 07:43:00 --> URI Class Initialized
DEBUG - 2011-08-06 07:43:00 --> Router Class Initialized
DEBUG - 2011-08-06 07:43:00 --> Output Class Initialized
DEBUG - 2011-08-06 07:43:00 --> Input Class Initialized
DEBUG - 2011-08-06 07:43:00 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-06 07:43:00 --> Language Class Initialized
DEBUG - 2011-08-06 07:43:00 --> Loader Class Initialized
DEBUG - 2011-08-06 07:43:00 --> Controller Class Initialized
DEBUG - 2011-08-06 07:43:00 --> Model Class Initialized
DEBUG - 2011-08-06 07:43:00 --> Model Class Initialized
DEBUG - 2011-08-06 07:43:00 --> Model Class Initialized
DEBUG - 2011-08-06 07:43:00 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-06 07:43:00 --> Database Driver Class Initialized
DEBUG - 2011-08-06 07:43:01 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-06 07:43:01 --> Helper loaded: url_helper
DEBUG - 2011-08-06 07:43:01 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-06 07:43:01 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-06 07:43:01 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-06 07:43:01 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-06 07:43:01 --> Final output sent to browser
DEBUG - 2011-08-06 07:43:01 --> Total execution time: 0.8237
DEBUG - 2011-08-06 07:43:03 --> Config Class Initialized
DEBUG - 2011-08-06 07:43:03 --> Hooks Class Initialized
DEBUG - 2011-08-06 07:43:03 --> Utf8 Class Initialized
DEBUG - 2011-08-06 07:43:03 --> UTF-8 Support Enabled
DEBUG - 2011-08-06 07:43:03 --> URI Class Initialized
DEBUG - 2011-08-06 07:43:03 --> Router Class Initialized
ERROR - 2011-08-06 07:43:03 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-06 07:43:31 --> Config Class Initialized
DEBUG - 2011-08-06 07:43:31 --> Hooks Class Initialized
DEBUG - 2011-08-06 07:43:31 --> Utf8 Class Initialized
DEBUG - 2011-08-06 07:43:31 --> UTF-8 Support Enabled
DEBUG - 2011-08-06 07:43:31 --> URI Class Initialized
DEBUG - 2011-08-06 07:43:31 --> Router Class Initialized
DEBUG - 2011-08-06 07:43:31 --> Output Class Initialized
DEBUG - 2011-08-06 07:43:31 --> Input Class Initialized
DEBUG - 2011-08-06 07:43:31 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-06 07:43:31 --> Language Class Initialized
DEBUG - 2011-08-06 07:43:31 --> Loader Class Initialized
DEBUG - 2011-08-06 07:43:31 --> Controller Class Initialized
DEBUG - 2011-08-06 07:43:31 --> Model Class Initialized
DEBUG - 2011-08-06 07:43:31 --> Model Class Initialized
DEBUG - 2011-08-06 07:43:31 --> Model Class Initialized
DEBUG - 2011-08-06 07:43:31 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-06 07:43:31 --> Database Driver Class Initialized
DEBUG - 2011-08-06 07:43:31 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-06 07:43:31 --> Helper loaded: url_helper
DEBUG - 2011-08-06 07:43:31 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-06 07:43:31 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-06 07:43:31 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-06 07:43:31 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-06 07:43:31 --> Final output sent to browser
DEBUG - 2011-08-06 07:43:31 --> Total execution time: 0.0483
DEBUG - 2011-08-06 08:36:05 --> Config Class Initialized
DEBUG - 2011-08-06 08:36:05 --> Hooks Class Initialized
DEBUG - 2011-08-06 08:36:05 --> Utf8 Class Initialized
DEBUG - 2011-08-06 08:36:05 --> UTF-8 Support Enabled
DEBUG - 2011-08-06 08:36:05 --> URI Class Initialized
DEBUG - 2011-08-06 08:36:05 --> Router Class Initialized
ERROR - 2011-08-06 08:36:05 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-08-06 08:46:01 --> Config Class Initialized
DEBUG - 2011-08-06 08:46:01 --> Hooks Class Initialized
DEBUG - 2011-08-06 08:46:01 --> Utf8 Class Initialized
DEBUG - 2011-08-06 08:46:01 --> UTF-8 Support Enabled
DEBUG - 2011-08-06 08:46:01 --> URI Class Initialized
DEBUG - 2011-08-06 08:46:01 --> Router Class Initialized
DEBUG - 2011-08-06 08:46:01 --> Output Class Initialized
DEBUG - 2011-08-06 08:46:01 --> Input Class Initialized
DEBUG - 2011-08-06 08:46:01 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-06 08:46:01 --> Language Class Initialized
DEBUG - 2011-08-06 08:46:01 --> Loader Class Initialized
DEBUG - 2011-08-06 08:46:01 --> Controller Class Initialized
ERROR - 2011-08-06 08:46:01 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-06 08:46:01 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-06 08:46:01 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-06 08:46:01 --> Model Class Initialized
DEBUG - 2011-08-06 08:46:01 --> Model Class Initialized
DEBUG - 2011-08-06 08:46:01 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-06 08:46:01 --> Database Driver Class Initialized
DEBUG - 2011-08-06 08:46:01 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-06 08:46:01 --> Helper loaded: url_helper
DEBUG - 2011-08-06 08:46:01 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-06 08:46:01 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-06 08:46:01 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-06 08:46:01 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-06 08:46:01 --> Final output sent to browser
DEBUG - 2011-08-06 08:46:01 --> Total execution time: 0.6662
DEBUG - 2011-08-06 08:57:33 --> Config Class Initialized
DEBUG - 2011-08-06 08:57:33 --> Hooks Class Initialized
DEBUG - 2011-08-06 08:57:33 --> Utf8 Class Initialized
DEBUG - 2011-08-06 08:57:33 --> UTF-8 Support Enabled
DEBUG - 2011-08-06 08:57:33 --> URI Class Initialized
DEBUG - 2011-08-06 08:57:33 --> Router Class Initialized
ERROR - 2011-08-06 08:57:33 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-08-06 09:44:25 --> Config Class Initialized
DEBUG - 2011-08-06 09:44:25 --> Hooks Class Initialized
DEBUG - 2011-08-06 09:44:25 --> Utf8 Class Initialized
DEBUG - 2011-08-06 09:44:25 --> UTF-8 Support Enabled
DEBUG - 2011-08-06 09:44:25 --> URI Class Initialized
DEBUG - 2011-08-06 09:44:25 --> Router Class Initialized
DEBUG - 2011-08-06 09:44:25 --> Output Class Initialized
DEBUG - 2011-08-06 09:44:25 --> Input Class Initialized
DEBUG - 2011-08-06 09:44:25 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-06 09:44:25 --> Language Class Initialized
DEBUG - 2011-08-06 09:44:25 --> Loader Class Initialized
DEBUG - 2011-08-06 09:44:25 --> Controller Class Initialized
DEBUG - 2011-08-06 09:44:25 --> Model Class Initialized
DEBUG - 2011-08-06 09:44:25 --> Model Class Initialized
DEBUG - 2011-08-06 09:44:25 --> Model Class Initialized
DEBUG - 2011-08-06 09:44:25 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-06 09:44:25 --> Database Driver Class Initialized
DEBUG - 2011-08-06 09:44:26 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-06 09:44:26 --> Helper loaded: url_helper
DEBUG - 2011-08-06 09:44:26 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-06 09:44:26 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-06 09:44:26 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-06 09:44:26 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-06 09:44:26 --> Final output sent to browser
DEBUG - 2011-08-06 09:44:26 --> Total execution time: 0.8427
DEBUG - 2011-08-06 10:01:48 --> Config Class Initialized
DEBUG - 2011-08-06 10:01:48 --> Hooks Class Initialized
DEBUG - 2011-08-06 10:01:48 --> Utf8 Class Initialized
DEBUG - 2011-08-06 10:01:48 --> UTF-8 Support Enabled
DEBUG - 2011-08-06 10:01:48 --> URI Class Initialized
DEBUG - 2011-08-06 10:01:48 --> Router Class Initialized
DEBUG - 2011-08-06 10:01:48 --> Output Class Initialized
DEBUG - 2011-08-06 10:01:48 --> Input Class Initialized
DEBUG - 2011-08-06 10:01:48 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-06 10:01:48 --> Language Class Initialized
DEBUG - 2011-08-06 10:01:48 --> Loader Class Initialized
DEBUG - 2011-08-06 10:01:48 --> Controller Class Initialized
DEBUG - 2011-08-06 10:01:48 --> Model Class Initialized
DEBUG - 2011-08-06 10:01:48 --> Model Class Initialized
DEBUG - 2011-08-06 10:01:48 --> Model Class Initialized
DEBUG - 2011-08-06 10:01:48 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-06 10:01:48 --> Database Driver Class Initialized
DEBUG - 2011-08-06 10:01:48 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-06 10:01:48 --> Helper loaded: url_helper
DEBUG - 2011-08-06 10:01:48 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-06 10:01:48 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-06 10:01:48 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-06 10:01:48 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-06 10:01:48 --> Final output sent to browser
DEBUG - 2011-08-06 10:01:48 --> Total execution time: 0.2881
DEBUG - 2011-08-06 10:01:50 --> Config Class Initialized
DEBUG - 2011-08-06 10:01:50 --> Hooks Class Initialized
DEBUG - 2011-08-06 10:01:50 --> Utf8 Class Initialized
DEBUG - 2011-08-06 10:01:50 --> UTF-8 Support Enabled
DEBUG - 2011-08-06 10:01:50 --> URI Class Initialized
DEBUG - 2011-08-06 10:01:50 --> Router Class Initialized
ERROR - 2011-08-06 10:01:50 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-06 10:01:50 --> Config Class Initialized
DEBUG - 2011-08-06 10:01:50 --> Hooks Class Initialized
DEBUG - 2011-08-06 10:01:50 --> Utf8 Class Initialized
DEBUG - 2011-08-06 10:01:50 --> UTF-8 Support Enabled
DEBUG - 2011-08-06 10:01:50 --> URI Class Initialized
DEBUG - 2011-08-06 10:01:50 --> Router Class Initialized
ERROR - 2011-08-06 10:01:50 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-06 10:01:50 --> Config Class Initialized
DEBUG - 2011-08-06 10:01:50 --> Hooks Class Initialized
DEBUG - 2011-08-06 10:01:50 --> Utf8 Class Initialized
DEBUG - 2011-08-06 10:01:50 --> UTF-8 Support Enabled
DEBUG - 2011-08-06 10:01:50 --> URI Class Initialized
DEBUG - 2011-08-06 10:01:50 --> Router Class Initialized
ERROR - 2011-08-06 10:01:50 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-06 10:11:18 --> Config Class Initialized
DEBUG - 2011-08-06 10:11:18 --> Hooks Class Initialized
DEBUG - 2011-08-06 10:11:18 --> Utf8 Class Initialized
DEBUG - 2011-08-06 10:11:18 --> UTF-8 Support Enabled
DEBUG - 2011-08-06 10:11:18 --> URI Class Initialized
DEBUG - 2011-08-06 10:11:18 --> Router Class Initialized
ERROR - 2011-08-06 10:11:18 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-08-06 10:11:18 --> Config Class Initialized
DEBUG - 2011-08-06 10:11:18 --> Hooks Class Initialized
DEBUG - 2011-08-06 10:11:18 --> Utf8 Class Initialized
DEBUG - 2011-08-06 10:11:18 --> UTF-8 Support Enabled
DEBUG - 2011-08-06 10:11:18 --> URI Class Initialized
DEBUG - 2011-08-06 10:11:18 --> Router Class Initialized
DEBUG - 2011-08-06 10:11:18 --> Output Class Initialized
DEBUG - 2011-08-06 10:11:18 --> Input Class Initialized
DEBUG - 2011-08-06 10:11:18 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-06 10:11:18 --> Language Class Initialized
DEBUG - 2011-08-06 10:11:18 --> Loader Class Initialized
DEBUG - 2011-08-06 10:11:18 --> Controller Class Initialized
ERROR - 2011-08-06 10:11:18 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-06 10:11:18 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-06 10:11:18 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-06 10:11:18 --> Model Class Initialized
DEBUG - 2011-08-06 10:11:18 --> Model Class Initialized
DEBUG - 2011-08-06 10:11:18 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-06 10:11:18 --> Database Driver Class Initialized
DEBUG - 2011-08-06 10:11:18 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-06 10:11:18 --> Helper loaded: url_helper
DEBUG - 2011-08-06 10:11:18 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-06 10:11:18 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-06 10:11:18 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-06 10:11:18 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-06 10:11:18 --> Final output sent to browser
DEBUG - 2011-08-06 10:11:18 --> Total execution time: 0.0997
DEBUG - 2011-08-06 10:42:16 --> Config Class Initialized
DEBUG - 2011-08-06 10:42:16 --> Hooks Class Initialized
DEBUG - 2011-08-06 10:42:16 --> Utf8 Class Initialized
DEBUG - 2011-08-06 10:42:16 --> UTF-8 Support Enabled
DEBUG - 2011-08-06 10:42:16 --> URI Class Initialized
DEBUG - 2011-08-06 10:42:16 --> Router Class Initialized
DEBUG - 2011-08-06 10:42:16 --> Output Class Initialized
DEBUG - 2011-08-06 10:42:16 --> Input Class Initialized
DEBUG - 2011-08-06 10:42:16 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-06 10:42:17 --> Language Class Initialized
DEBUG - 2011-08-06 10:42:17 --> Loader Class Initialized
DEBUG - 2011-08-06 10:42:17 --> Controller Class Initialized
ERROR - 2011-08-06 10:42:17 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-06 10:42:17 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-06 10:42:17 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-06 10:42:17 --> Model Class Initialized
DEBUG - 2011-08-06 10:42:17 --> Model Class Initialized
DEBUG - 2011-08-06 10:42:17 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-06 10:42:17 --> Database Driver Class Initialized
DEBUG - 2011-08-06 10:42:17 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-06 10:42:17 --> Helper loaded: url_helper
DEBUG - 2011-08-06 10:42:17 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-06 10:42:17 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-06 10:42:17 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-06 10:42:17 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-06 10:42:17 --> Final output sent to browser
DEBUG - 2011-08-06 10:42:17 --> Total execution time: 1.6137
DEBUG - 2011-08-06 10:42:18 --> Config Class Initialized
DEBUG - 2011-08-06 10:42:18 --> Hooks Class Initialized
DEBUG - 2011-08-06 10:42:18 --> Utf8 Class Initialized
DEBUG - 2011-08-06 10:42:18 --> UTF-8 Support Enabled
DEBUG - 2011-08-06 10:42:18 --> URI Class Initialized
DEBUG - 2011-08-06 10:42:18 --> Router Class Initialized
DEBUG - 2011-08-06 10:42:18 --> Output Class Initialized
DEBUG - 2011-08-06 10:42:18 --> Input Class Initialized
DEBUG - 2011-08-06 10:42:18 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-06 10:42:18 --> Language Class Initialized
DEBUG - 2011-08-06 10:42:18 --> Loader Class Initialized
DEBUG - 2011-08-06 10:42:18 --> Controller Class Initialized
DEBUG - 2011-08-06 10:42:18 --> Model Class Initialized
DEBUG - 2011-08-06 10:42:18 --> Model Class Initialized
DEBUG - 2011-08-06 10:42:18 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-06 10:42:18 --> Database Driver Class Initialized
DEBUG - 2011-08-06 10:42:18 --> Final output sent to browser
DEBUG - 2011-08-06 10:42:18 --> Total execution time: 0.7376
DEBUG - 2011-08-06 10:42:19 --> Config Class Initialized
DEBUG - 2011-08-06 10:42:19 --> Hooks Class Initialized
DEBUG - 2011-08-06 10:42:19 --> Utf8 Class Initialized
DEBUG - 2011-08-06 10:42:19 --> UTF-8 Support Enabled
DEBUG - 2011-08-06 10:42:19 --> URI Class Initialized
DEBUG - 2011-08-06 10:42:19 --> Router Class Initialized
ERROR - 2011-08-06 10:42:19 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-06 10:42:19 --> Config Class Initialized
DEBUG - 2011-08-06 10:42:19 --> Hooks Class Initialized
DEBUG - 2011-08-06 10:42:19 --> Utf8 Class Initialized
DEBUG - 2011-08-06 10:42:19 --> UTF-8 Support Enabled
DEBUG - 2011-08-06 10:42:19 --> URI Class Initialized
DEBUG - 2011-08-06 10:42:19 --> Router Class Initialized
ERROR - 2011-08-06 10:42:19 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-06 10:42:25 --> Config Class Initialized
DEBUG - 2011-08-06 10:42:25 --> Hooks Class Initialized
DEBUG - 2011-08-06 10:42:25 --> Utf8 Class Initialized
DEBUG - 2011-08-06 10:42:25 --> UTF-8 Support Enabled
DEBUG - 2011-08-06 10:42:25 --> URI Class Initialized
DEBUG - 2011-08-06 10:42:25 --> Router Class Initialized
DEBUG - 2011-08-06 10:42:25 --> Output Class Initialized
DEBUG - 2011-08-06 10:42:25 --> Input Class Initialized
DEBUG - 2011-08-06 10:42:25 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-06 10:42:25 --> Language Class Initialized
DEBUG - 2011-08-06 10:42:25 --> Loader Class Initialized
DEBUG - 2011-08-06 10:42:25 --> Controller Class Initialized
ERROR - 2011-08-06 10:42:25 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-06 10:42:25 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-06 10:42:25 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-06 10:42:25 --> Model Class Initialized
DEBUG - 2011-08-06 10:42:25 --> Model Class Initialized
DEBUG - 2011-08-06 10:42:25 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-06 10:42:25 --> Database Driver Class Initialized
DEBUG - 2011-08-06 10:42:25 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-06 10:42:25 --> Helper loaded: url_helper
DEBUG - 2011-08-06 10:42:25 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-06 10:42:25 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-06 10:42:25 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-06 10:42:25 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-06 10:42:25 --> Final output sent to browser
DEBUG - 2011-08-06 10:42:25 --> Total execution time: 0.0295
DEBUG - 2011-08-06 10:42:25 --> Config Class Initialized
DEBUG - 2011-08-06 10:42:25 --> Hooks Class Initialized
DEBUG - 2011-08-06 10:42:25 --> Utf8 Class Initialized
DEBUG - 2011-08-06 10:42:25 --> UTF-8 Support Enabled
DEBUG - 2011-08-06 10:42:25 --> URI Class Initialized
DEBUG - 2011-08-06 10:42:25 --> Router Class Initialized
DEBUG - 2011-08-06 10:42:25 --> Output Class Initialized
DEBUG - 2011-08-06 10:42:25 --> Input Class Initialized
DEBUG - 2011-08-06 10:42:25 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-06 10:42:25 --> Language Class Initialized
DEBUG - 2011-08-06 10:42:25 --> Loader Class Initialized
DEBUG - 2011-08-06 10:42:25 --> Controller Class Initialized
DEBUG - 2011-08-06 10:42:25 --> Model Class Initialized
DEBUG - 2011-08-06 10:42:25 --> Model Class Initialized
DEBUG - 2011-08-06 10:42:25 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-06 10:42:25 --> Database Driver Class Initialized
DEBUG - 2011-08-06 10:42:26 --> Final output sent to browser
DEBUG - 2011-08-06 10:42:26 --> Total execution time: 1.2024
DEBUG - 2011-08-06 10:42:44 --> Config Class Initialized
DEBUG - 2011-08-06 10:42:44 --> Hooks Class Initialized
DEBUG - 2011-08-06 10:42:44 --> Utf8 Class Initialized
DEBUG - 2011-08-06 10:42:44 --> UTF-8 Support Enabled
DEBUG - 2011-08-06 10:42:44 --> URI Class Initialized
DEBUG - 2011-08-06 10:42:44 --> Router Class Initialized
DEBUG - 2011-08-06 10:42:44 --> Output Class Initialized
DEBUG - 2011-08-06 10:42:44 --> Input Class Initialized
DEBUG - 2011-08-06 10:42:44 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-06 10:42:44 --> Language Class Initialized
DEBUG - 2011-08-06 10:42:44 --> Loader Class Initialized
DEBUG - 2011-08-06 10:42:44 --> Controller Class Initialized
ERROR - 2011-08-06 10:42:44 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-06 10:42:44 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-06 10:42:44 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-06 10:42:44 --> Model Class Initialized
DEBUG - 2011-08-06 10:42:44 --> Model Class Initialized
DEBUG - 2011-08-06 10:42:44 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-06 10:42:44 --> Database Driver Class Initialized
DEBUG - 2011-08-06 10:42:44 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-06 10:42:44 --> Helper loaded: url_helper
DEBUG - 2011-08-06 10:42:44 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-06 10:42:44 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-06 10:42:44 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-06 10:42:44 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-06 10:42:44 --> Final output sent to browser
DEBUG - 2011-08-06 10:42:44 --> Total execution time: 0.0804
DEBUG - 2011-08-06 10:42:45 --> Config Class Initialized
DEBUG - 2011-08-06 10:42:45 --> Hooks Class Initialized
DEBUG - 2011-08-06 10:42:45 --> Utf8 Class Initialized
DEBUG - 2011-08-06 10:42:45 --> UTF-8 Support Enabled
DEBUG - 2011-08-06 10:42:45 --> URI Class Initialized
DEBUG - 2011-08-06 10:42:45 --> Router Class Initialized
DEBUG - 2011-08-06 10:42:45 --> Output Class Initialized
DEBUG - 2011-08-06 10:42:45 --> Input Class Initialized
DEBUG - 2011-08-06 10:42:45 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-06 10:42:45 --> Language Class Initialized
DEBUG - 2011-08-06 10:42:45 --> Loader Class Initialized
DEBUG - 2011-08-06 10:42:45 --> Controller Class Initialized
DEBUG - 2011-08-06 10:42:45 --> Model Class Initialized
DEBUG - 2011-08-06 10:42:45 --> Model Class Initialized
DEBUG - 2011-08-06 10:42:45 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-06 10:42:45 --> Database Driver Class Initialized
DEBUG - 2011-08-06 10:42:46 --> Final output sent to browser
DEBUG - 2011-08-06 10:42:46 --> Total execution time: 0.5870
DEBUG - 2011-08-06 10:42:54 --> Config Class Initialized
DEBUG - 2011-08-06 10:42:54 --> Hooks Class Initialized
DEBUG - 2011-08-06 10:42:54 --> Utf8 Class Initialized
DEBUG - 2011-08-06 10:42:54 --> UTF-8 Support Enabled
DEBUG - 2011-08-06 10:42:54 --> URI Class Initialized
DEBUG - 2011-08-06 10:42:54 --> Router Class Initialized
DEBUG - 2011-08-06 10:42:54 --> Output Class Initialized
DEBUG - 2011-08-06 10:42:54 --> Input Class Initialized
DEBUG - 2011-08-06 10:42:54 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-06 10:42:54 --> Language Class Initialized
DEBUG - 2011-08-06 10:42:54 --> Loader Class Initialized
DEBUG - 2011-08-06 10:42:54 --> Controller Class Initialized
ERROR - 2011-08-06 10:42:54 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-06 10:42:54 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-06 10:42:54 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-06 10:42:54 --> Model Class Initialized
DEBUG - 2011-08-06 10:42:54 --> Model Class Initialized
DEBUG - 2011-08-06 10:42:54 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-06 10:42:54 --> Database Driver Class Initialized
DEBUG - 2011-08-06 10:42:54 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-06 10:42:54 --> Helper loaded: url_helper
DEBUG - 2011-08-06 10:42:54 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-06 10:42:54 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-06 10:42:54 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-06 10:42:54 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-06 10:42:54 --> Final output sent to browser
DEBUG - 2011-08-06 10:42:54 --> Total execution time: 0.0662
DEBUG - 2011-08-06 10:42:55 --> Config Class Initialized
DEBUG - 2011-08-06 10:42:55 --> Hooks Class Initialized
DEBUG - 2011-08-06 10:42:55 --> Utf8 Class Initialized
DEBUG - 2011-08-06 10:42:55 --> UTF-8 Support Enabled
DEBUG - 2011-08-06 10:42:55 --> URI Class Initialized
DEBUG - 2011-08-06 10:42:55 --> Router Class Initialized
DEBUG - 2011-08-06 10:42:55 --> Output Class Initialized
DEBUG - 2011-08-06 10:42:55 --> Input Class Initialized
DEBUG - 2011-08-06 10:42:55 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-06 10:42:55 --> Language Class Initialized
DEBUG - 2011-08-06 10:42:55 --> Loader Class Initialized
DEBUG - 2011-08-06 10:42:55 --> Controller Class Initialized
DEBUG - 2011-08-06 10:42:55 --> Model Class Initialized
DEBUG - 2011-08-06 10:42:55 --> Model Class Initialized
DEBUG - 2011-08-06 10:42:55 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-06 10:42:55 --> Database Driver Class Initialized
DEBUG - 2011-08-06 10:42:55 --> Final output sent to browser
DEBUG - 2011-08-06 10:42:55 --> Total execution time: 0.6116
DEBUG - 2011-08-06 11:39:06 --> Config Class Initialized
DEBUG - 2011-08-06 11:39:06 --> Hooks Class Initialized
DEBUG - 2011-08-06 11:39:06 --> Utf8 Class Initialized
DEBUG - 2011-08-06 11:39:06 --> UTF-8 Support Enabled
DEBUG - 2011-08-06 11:39:06 --> URI Class Initialized
DEBUG - 2011-08-06 11:39:06 --> Router Class Initialized
ERROR - 2011-08-06 11:39:06 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-08-06 11:39:07 --> Config Class Initialized
DEBUG - 2011-08-06 11:39:07 --> Hooks Class Initialized
DEBUG - 2011-08-06 11:39:07 --> Utf8 Class Initialized
DEBUG - 2011-08-06 11:39:07 --> UTF-8 Support Enabled
DEBUG - 2011-08-06 11:39:07 --> URI Class Initialized
DEBUG - 2011-08-06 11:39:07 --> Router Class Initialized
DEBUG - 2011-08-06 11:39:07 --> Output Class Initialized
DEBUG - 2011-08-06 11:39:07 --> Input Class Initialized
DEBUG - 2011-08-06 11:39:07 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-06 11:39:07 --> Language Class Initialized
DEBUG - 2011-08-06 11:39:07 --> Loader Class Initialized
DEBUG - 2011-08-06 11:39:07 --> Controller Class Initialized
DEBUG - 2011-08-06 11:39:07 --> Model Class Initialized
DEBUG - 2011-08-06 11:39:07 --> Model Class Initialized
DEBUG - 2011-08-06 11:39:07 --> Model Class Initialized
DEBUG - 2011-08-06 11:39:07 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-06 11:39:07 --> Database Driver Class Initialized
DEBUG - 2011-08-06 11:39:07 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-06 11:39:07 --> Helper loaded: url_helper
DEBUG - 2011-08-06 11:39:07 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-06 11:39:07 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-06 11:39:07 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-06 11:39:07 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-06 11:39:07 --> Final output sent to browser
DEBUG - 2011-08-06 11:39:07 --> Total execution time: 0.4684
DEBUG - 2011-08-06 12:35:15 --> Config Class Initialized
DEBUG - 2011-08-06 12:35:15 --> Hooks Class Initialized
DEBUG - 2011-08-06 12:35:15 --> Utf8 Class Initialized
DEBUG - 2011-08-06 12:35:15 --> UTF-8 Support Enabled
DEBUG - 2011-08-06 12:35:15 --> URI Class Initialized
DEBUG - 2011-08-06 12:35:15 --> Router Class Initialized
DEBUG - 2011-08-06 12:35:15 --> Output Class Initialized
DEBUG - 2011-08-06 12:35:16 --> Input Class Initialized
DEBUG - 2011-08-06 12:35:16 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-06 12:35:16 --> Language Class Initialized
DEBUG - 2011-08-06 12:35:16 --> Loader Class Initialized
DEBUG - 2011-08-06 12:35:16 --> Controller Class Initialized
ERROR - 2011-08-06 12:35:16 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-06 12:35:16 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-06 12:35:16 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-06 12:35:16 --> Model Class Initialized
DEBUG - 2011-08-06 12:35:16 --> Model Class Initialized
DEBUG - 2011-08-06 12:35:16 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-06 12:35:16 --> Database Driver Class Initialized
DEBUG - 2011-08-06 12:35:16 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-06 12:35:16 --> Helper loaded: url_helper
DEBUG - 2011-08-06 12:35:16 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-06 12:35:16 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-06 12:35:16 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-06 12:35:16 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-06 12:35:16 --> Final output sent to browser
DEBUG - 2011-08-06 12:35:16 --> Total execution time: 0.2552
DEBUG - 2011-08-06 12:35:17 --> Config Class Initialized
DEBUG - 2011-08-06 12:35:17 --> Hooks Class Initialized
DEBUG - 2011-08-06 12:35:17 --> Utf8 Class Initialized
DEBUG - 2011-08-06 12:35:17 --> UTF-8 Support Enabled
DEBUG - 2011-08-06 12:35:17 --> URI Class Initialized
DEBUG - 2011-08-06 12:35:17 --> Router Class Initialized
DEBUG - 2011-08-06 12:35:17 --> Output Class Initialized
DEBUG - 2011-08-06 12:35:17 --> Input Class Initialized
DEBUG - 2011-08-06 12:35:17 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-06 12:35:17 --> Language Class Initialized
DEBUG - 2011-08-06 12:35:17 --> Loader Class Initialized
DEBUG - 2011-08-06 12:35:17 --> Controller Class Initialized
DEBUG - 2011-08-06 12:35:17 --> Model Class Initialized
DEBUG - 2011-08-06 12:35:17 --> Model Class Initialized
DEBUG - 2011-08-06 12:35:17 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-06 12:35:17 --> Database Driver Class Initialized
DEBUG - 2011-08-06 12:35:17 --> Final output sent to browser
DEBUG - 2011-08-06 12:35:17 --> Total execution time: 0.6896
DEBUG - 2011-08-06 12:35:19 --> Config Class Initialized
DEBUG - 2011-08-06 12:35:19 --> Hooks Class Initialized
DEBUG - 2011-08-06 12:35:19 --> Utf8 Class Initialized
DEBUG - 2011-08-06 12:35:19 --> UTF-8 Support Enabled
DEBUG - 2011-08-06 12:35:19 --> URI Class Initialized
DEBUG - 2011-08-06 12:35:19 --> Router Class Initialized
ERROR - 2011-08-06 12:35:19 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-06 12:35:19 --> Config Class Initialized
DEBUG - 2011-08-06 12:35:19 --> Hooks Class Initialized
DEBUG - 2011-08-06 12:35:19 --> Utf8 Class Initialized
DEBUG - 2011-08-06 12:35:19 --> UTF-8 Support Enabled
DEBUG - 2011-08-06 12:35:19 --> URI Class Initialized
DEBUG - 2011-08-06 12:35:19 --> Router Class Initialized
ERROR - 2011-08-06 12:35:19 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-06 12:35:19 --> Config Class Initialized
DEBUG - 2011-08-06 12:35:19 --> Hooks Class Initialized
DEBUG - 2011-08-06 12:35:19 --> Utf8 Class Initialized
DEBUG - 2011-08-06 12:35:19 --> UTF-8 Support Enabled
DEBUG - 2011-08-06 12:35:19 --> URI Class Initialized
DEBUG - 2011-08-06 12:35:19 --> Router Class Initialized
ERROR - 2011-08-06 12:35:19 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-06 12:35:32 --> Config Class Initialized
DEBUG - 2011-08-06 12:35:32 --> Hooks Class Initialized
DEBUG - 2011-08-06 12:35:32 --> Utf8 Class Initialized
DEBUG - 2011-08-06 12:35:32 --> UTF-8 Support Enabled
DEBUG - 2011-08-06 12:35:32 --> URI Class Initialized
DEBUG - 2011-08-06 12:35:32 --> Router Class Initialized
DEBUG - 2011-08-06 12:35:32 --> Output Class Initialized
DEBUG - 2011-08-06 12:35:32 --> Input Class Initialized
DEBUG - 2011-08-06 12:35:32 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-06 12:35:32 --> Language Class Initialized
DEBUG - 2011-08-06 12:35:32 --> Loader Class Initialized
DEBUG - 2011-08-06 12:35:32 --> Controller Class Initialized
ERROR - 2011-08-06 12:35:32 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-06 12:35:32 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-06 12:35:32 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-06 12:35:32 --> Model Class Initialized
DEBUG - 2011-08-06 12:35:32 --> Model Class Initialized
DEBUG - 2011-08-06 12:35:32 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-06 12:35:32 --> Database Driver Class Initialized
DEBUG - 2011-08-06 12:35:32 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-06 12:35:32 --> Helper loaded: url_helper
DEBUG - 2011-08-06 12:35:32 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-06 12:35:32 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-06 12:35:32 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-06 12:35:32 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-06 12:35:32 --> Final output sent to browser
DEBUG - 2011-08-06 12:35:32 --> Total execution time: 0.0294
DEBUG - 2011-08-06 12:35:32 --> Config Class Initialized
DEBUG - 2011-08-06 12:35:32 --> Hooks Class Initialized
DEBUG - 2011-08-06 12:35:32 --> Utf8 Class Initialized
DEBUG - 2011-08-06 12:35:32 --> UTF-8 Support Enabled
DEBUG - 2011-08-06 12:35:32 --> URI Class Initialized
DEBUG - 2011-08-06 12:35:32 --> Router Class Initialized
DEBUG - 2011-08-06 12:35:32 --> Output Class Initialized
DEBUG - 2011-08-06 12:35:32 --> Input Class Initialized
DEBUG - 2011-08-06 12:35:32 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-06 12:35:32 --> Language Class Initialized
DEBUG - 2011-08-06 12:35:32 --> Loader Class Initialized
DEBUG - 2011-08-06 12:35:32 --> Controller Class Initialized
DEBUG - 2011-08-06 12:35:32 --> Model Class Initialized
DEBUG - 2011-08-06 12:35:32 --> Model Class Initialized
DEBUG - 2011-08-06 12:35:32 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-06 12:35:32 --> Database Driver Class Initialized
DEBUG - 2011-08-06 12:35:32 --> Final output sent to browser
DEBUG - 2011-08-06 12:35:32 --> Total execution time: 0.5048
DEBUG - 2011-08-06 12:47:22 --> Config Class Initialized
DEBUG - 2011-08-06 12:47:22 --> Hooks Class Initialized
DEBUG - 2011-08-06 12:47:22 --> Utf8 Class Initialized
DEBUG - 2011-08-06 12:47:22 --> UTF-8 Support Enabled
DEBUG - 2011-08-06 12:47:22 --> URI Class Initialized
DEBUG - 2011-08-06 12:47:22 --> Router Class Initialized
DEBUG - 2011-08-06 12:47:22 --> Output Class Initialized
DEBUG - 2011-08-06 12:47:22 --> Input Class Initialized
DEBUG - 2011-08-06 12:47:22 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-06 12:47:22 --> Language Class Initialized
DEBUG - 2011-08-06 12:47:22 --> Loader Class Initialized
DEBUG - 2011-08-06 12:47:22 --> Controller Class Initialized
ERROR - 2011-08-06 12:47:22 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-06 12:47:22 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-06 12:47:22 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-06 12:47:22 --> Model Class Initialized
DEBUG - 2011-08-06 12:47:22 --> Model Class Initialized
DEBUG - 2011-08-06 12:47:22 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-06 12:47:23 --> Database Driver Class Initialized
DEBUG - 2011-08-06 12:47:23 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-06 12:47:23 --> Helper loaded: url_helper
DEBUG - 2011-08-06 12:47:23 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-06 12:47:23 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-06 12:47:23 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-06 12:47:23 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-06 12:47:23 --> Final output sent to browser
DEBUG - 2011-08-06 12:47:23 --> Total execution time: 0.4243
DEBUG - 2011-08-06 12:47:25 --> Config Class Initialized
DEBUG - 2011-08-06 12:47:25 --> Hooks Class Initialized
DEBUG - 2011-08-06 12:47:25 --> Utf8 Class Initialized
DEBUG - 2011-08-06 12:47:25 --> UTF-8 Support Enabled
DEBUG - 2011-08-06 12:47:25 --> URI Class Initialized
DEBUG - 2011-08-06 12:47:25 --> Router Class Initialized
DEBUG - 2011-08-06 12:47:25 --> Output Class Initialized
DEBUG - 2011-08-06 12:47:25 --> Input Class Initialized
DEBUG - 2011-08-06 12:47:25 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-06 12:47:25 --> Language Class Initialized
DEBUG - 2011-08-06 12:47:25 --> Loader Class Initialized
DEBUG - 2011-08-06 12:47:25 --> Controller Class Initialized
DEBUG - 2011-08-06 12:47:25 --> Model Class Initialized
DEBUG - 2011-08-06 12:47:25 --> Model Class Initialized
DEBUG - 2011-08-06 12:47:25 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-06 12:47:25 --> Database Driver Class Initialized
DEBUG - 2011-08-06 12:47:25 --> Final output sent to browser
DEBUG - 2011-08-06 12:47:25 --> Total execution time: 0.6458
DEBUG - 2011-08-06 12:47:26 --> Config Class Initialized
DEBUG - 2011-08-06 12:47:26 --> Hooks Class Initialized
DEBUG - 2011-08-06 12:47:26 --> Utf8 Class Initialized
DEBUG - 2011-08-06 12:47:26 --> UTF-8 Support Enabled
DEBUG - 2011-08-06 12:47:26 --> URI Class Initialized
DEBUG - 2011-08-06 12:47:26 --> Router Class Initialized
ERROR - 2011-08-06 12:47:26 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-06 12:47:38 --> Config Class Initialized
DEBUG - 2011-08-06 12:47:38 --> Hooks Class Initialized
DEBUG - 2011-08-06 12:47:38 --> Utf8 Class Initialized
DEBUG - 2011-08-06 12:47:38 --> UTF-8 Support Enabled
DEBUG - 2011-08-06 12:47:38 --> URI Class Initialized
DEBUG - 2011-08-06 12:47:38 --> Router Class Initialized
DEBUG - 2011-08-06 12:47:38 --> Output Class Initialized
DEBUG - 2011-08-06 12:47:38 --> Input Class Initialized
DEBUG - 2011-08-06 12:47:38 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-06 12:47:38 --> Language Class Initialized
DEBUG - 2011-08-06 12:47:38 --> Loader Class Initialized
DEBUG - 2011-08-06 12:47:38 --> Controller Class Initialized
DEBUG - 2011-08-06 12:47:38 --> Model Class Initialized
DEBUG - 2011-08-06 12:47:38 --> Model Class Initialized
DEBUG - 2011-08-06 12:47:38 --> Model Class Initialized
DEBUG - 2011-08-06 12:47:38 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-06 12:47:38 --> Database Driver Class Initialized
DEBUG - 2011-08-06 12:47:39 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-06 12:47:39 --> Helper loaded: url_helper
DEBUG - 2011-08-06 12:47:39 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-06 12:47:39 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-06 12:47:39 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-06 12:47:39 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-06 12:47:39 --> Final output sent to browser
DEBUG - 2011-08-06 12:47:39 --> Total execution time: 0.4459
DEBUG - 2011-08-06 12:47:41 --> Config Class Initialized
DEBUG - 2011-08-06 12:47:41 --> Hooks Class Initialized
DEBUG - 2011-08-06 12:47:41 --> Utf8 Class Initialized
DEBUG - 2011-08-06 12:47:41 --> UTF-8 Support Enabled
DEBUG - 2011-08-06 12:47:41 --> URI Class Initialized
DEBUG - 2011-08-06 12:47:41 --> Router Class Initialized
ERROR - 2011-08-06 12:47:41 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-06 13:02:00 --> Config Class Initialized
DEBUG - 2011-08-06 13:02:00 --> Hooks Class Initialized
DEBUG - 2011-08-06 13:02:00 --> Utf8 Class Initialized
DEBUG - 2011-08-06 13:02:00 --> UTF-8 Support Enabled
DEBUG - 2011-08-06 13:02:00 --> URI Class Initialized
DEBUG - 2011-08-06 13:02:00 --> Router Class Initialized
ERROR - 2011-08-06 13:02:00 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-08-06 13:30:33 --> Config Class Initialized
DEBUG - 2011-08-06 13:30:33 --> Hooks Class Initialized
DEBUG - 2011-08-06 13:30:33 --> Utf8 Class Initialized
DEBUG - 2011-08-06 13:30:33 --> UTF-8 Support Enabled
DEBUG - 2011-08-06 13:30:33 --> URI Class Initialized
DEBUG - 2011-08-06 13:30:33 --> Router Class Initialized
ERROR - 2011-08-06 13:30:33 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-08-06 13:30:33 --> Config Class Initialized
DEBUG - 2011-08-06 13:30:33 --> Hooks Class Initialized
DEBUG - 2011-08-06 13:30:33 --> Utf8 Class Initialized
DEBUG - 2011-08-06 13:30:33 --> UTF-8 Support Enabled
DEBUG - 2011-08-06 13:30:33 --> URI Class Initialized
DEBUG - 2011-08-06 13:30:33 --> Router Class Initialized
DEBUG - 2011-08-06 13:30:33 --> Output Class Initialized
DEBUG - 2011-08-06 13:30:33 --> Input Class Initialized
DEBUG - 2011-08-06 13:30:33 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-06 13:30:33 --> Language Class Initialized
DEBUG - 2011-08-06 13:30:33 --> Loader Class Initialized
DEBUG - 2011-08-06 13:30:33 --> Controller Class Initialized
DEBUG - 2011-08-06 13:30:33 --> Model Class Initialized
DEBUG - 2011-08-06 13:30:33 --> Model Class Initialized
DEBUG - 2011-08-06 13:30:33 --> Model Class Initialized
DEBUG - 2011-08-06 13:30:33 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-06 13:30:33 --> Database Driver Class Initialized
DEBUG - 2011-08-06 13:30:33 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-06 13:30:33 --> Helper loaded: url_helper
DEBUG - 2011-08-06 13:30:33 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-06 13:30:33 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-06 13:30:33 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-06 13:30:33 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-06 13:30:33 --> Final output sent to browser
DEBUG - 2011-08-06 13:30:33 --> Total execution time: 0.2938
DEBUG - 2011-08-06 14:27:18 --> Config Class Initialized
DEBUG - 2011-08-06 14:27:18 --> Hooks Class Initialized
DEBUG - 2011-08-06 14:27:18 --> Utf8 Class Initialized
DEBUG - 2011-08-06 14:27:18 --> UTF-8 Support Enabled
DEBUG - 2011-08-06 14:27:18 --> URI Class Initialized
DEBUG - 2011-08-06 14:27:18 --> Router Class Initialized
DEBUG - 2011-08-06 14:27:18 --> Output Class Initialized
DEBUG - 2011-08-06 14:27:18 --> Input Class Initialized
DEBUG - 2011-08-06 14:27:18 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-06 14:27:18 --> Language Class Initialized
DEBUG - 2011-08-06 14:27:18 --> Loader Class Initialized
DEBUG - 2011-08-06 14:27:18 --> Controller Class Initialized
DEBUG - 2011-08-06 14:27:18 --> Model Class Initialized
DEBUG - 2011-08-06 14:27:18 --> Model Class Initialized
DEBUG - 2011-08-06 14:27:18 --> Model Class Initialized
DEBUG - 2011-08-06 14:27:18 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-06 14:27:18 --> Database Driver Class Initialized
DEBUG - 2011-08-06 14:27:18 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-06 14:27:18 --> Helper loaded: url_helper
DEBUG - 2011-08-06 14:27:18 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-06 14:27:18 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-06 14:27:18 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-06 14:27:18 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-06 14:27:18 --> Final output sent to browser
DEBUG - 2011-08-06 14:27:18 --> Total execution time: 0.2382
DEBUG - 2011-08-06 14:27:33 --> Config Class Initialized
DEBUG - 2011-08-06 14:27:33 --> Hooks Class Initialized
DEBUG - 2011-08-06 14:27:33 --> Utf8 Class Initialized
DEBUG - 2011-08-06 14:27:33 --> UTF-8 Support Enabled
DEBUG - 2011-08-06 14:27:33 --> URI Class Initialized
DEBUG - 2011-08-06 14:27:33 --> Router Class Initialized
DEBUG - 2011-08-06 14:27:33 --> Output Class Initialized
DEBUG - 2011-08-06 14:27:33 --> Input Class Initialized
DEBUG - 2011-08-06 14:27:33 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-06 14:27:33 --> Language Class Initialized
DEBUG - 2011-08-06 14:27:33 --> Loader Class Initialized
DEBUG - 2011-08-06 14:27:33 --> Controller Class Initialized
DEBUG - 2011-08-06 14:27:33 --> Model Class Initialized
DEBUG - 2011-08-06 14:27:33 --> Model Class Initialized
DEBUG - 2011-08-06 14:27:33 --> Model Class Initialized
DEBUG - 2011-08-06 14:27:33 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-06 14:27:33 --> Database Driver Class Initialized
DEBUG - 2011-08-06 14:27:33 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-06 14:27:33 --> Helper loaded: url_helper
DEBUG - 2011-08-06 14:27:33 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-06 14:27:33 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-06 14:27:33 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-06 14:27:33 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-06 14:27:33 --> Final output sent to browser
DEBUG - 2011-08-06 14:27:33 --> Total execution time: 0.2704
DEBUG - 2011-08-06 14:27:34 --> Config Class Initialized
DEBUG - 2011-08-06 14:27:34 --> Hooks Class Initialized
DEBUG - 2011-08-06 14:27:34 --> Utf8 Class Initialized
DEBUG - 2011-08-06 14:27:34 --> UTF-8 Support Enabled
DEBUG - 2011-08-06 14:27:34 --> URI Class Initialized
DEBUG - 2011-08-06 14:27:34 --> Router Class Initialized
DEBUG - 2011-08-06 14:27:34 --> Output Class Initialized
DEBUG - 2011-08-06 14:27:34 --> Input Class Initialized
DEBUG - 2011-08-06 14:27:34 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-06 14:27:34 --> Language Class Initialized
DEBUG - 2011-08-06 14:27:34 --> Loader Class Initialized
DEBUG - 2011-08-06 14:27:34 --> Controller Class Initialized
DEBUG - 2011-08-06 14:27:34 --> Model Class Initialized
DEBUG - 2011-08-06 14:27:34 --> Model Class Initialized
DEBUG - 2011-08-06 14:27:34 --> Model Class Initialized
DEBUG - 2011-08-06 14:27:34 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-06 14:27:34 --> Database Driver Class Initialized
DEBUG - 2011-08-06 14:27:35 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-06 14:27:35 --> Helper loaded: url_helper
DEBUG - 2011-08-06 14:27:35 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-06 14:27:35 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-06 14:27:35 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-06 14:27:35 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-06 14:27:35 --> Final output sent to browser
DEBUG - 2011-08-06 14:27:35 --> Total execution time: 0.0894
DEBUG - 2011-08-06 14:27:55 --> Config Class Initialized
DEBUG - 2011-08-06 14:27:55 --> Hooks Class Initialized
DEBUG - 2011-08-06 14:27:55 --> Utf8 Class Initialized
DEBUG - 2011-08-06 14:27:55 --> UTF-8 Support Enabled
DEBUG - 2011-08-06 14:27:55 --> URI Class Initialized
DEBUG - 2011-08-06 14:27:55 --> Router Class Initialized
DEBUG - 2011-08-06 14:27:55 --> Output Class Initialized
DEBUG - 2011-08-06 14:27:55 --> Input Class Initialized
DEBUG - 2011-08-06 14:27:55 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-06 14:27:55 --> Language Class Initialized
DEBUG - 2011-08-06 14:27:55 --> Loader Class Initialized
DEBUG - 2011-08-06 14:27:55 --> Controller Class Initialized
DEBUG - 2011-08-06 14:27:55 --> Model Class Initialized
DEBUG - 2011-08-06 14:27:55 --> Model Class Initialized
DEBUG - 2011-08-06 14:27:55 --> Model Class Initialized
DEBUG - 2011-08-06 14:27:55 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-06 14:27:55 --> Database Driver Class Initialized
DEBUG - 2011-08-06 14:27:55 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-06 14:27:55 --> Helper loaded: url_helper
DEBUG - 2011-08-06 14:27:55 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-06 14:27:55 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-06 14:27:55 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-06 14:27:55 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-06 14:27:55 --> Final output sent to browser
DEBUG - 2011-08-06 14:27:55 --> Total execution time: 0.3150
DEBUG - 2011-08-06 14:27:56 --> Config Class Initialized
DEBUG - 2011-08-06 14:27:56 --> Hooks Class Initialized
DEBUG - 2011-08-06 14:27:56 --> Utf8 Class Initialized
DEBUG - 2011-08-06 14:27:56 --> UTF-8 Support Enabled
DEBUG - 2011-08-06 14:27:56 --> URI Class Initialized
DEBUG - 2011-08-06 14:27:56 --> Router Class Initialized
DEBUG - 2011-08-06 14:27:56 --> Output Class Initialized
DEBUG - 2011-08-06 14:27:56 --> Input Class Initialized
DEBUG - 2011-08-06 14:27:56 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-06 14:27:56 --> Language Class Initialized
DEBUG - 2011-08-06 14:27:56 --> Loader Class Initialized
DEBUG - 2011-08-06 14:27:56 --> Controller Class Initialized
DEBUG - 2011-08-06 14:27:56 --> Model Class Initialized
DEBUG - 2011-08-06 14:27:56 --> Model Class Initialized
DEBUG - 2011-08-06 14:27:56 --> Model Class Initialized
DEBUG - 2011-08-06 14:27:56 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-06 14:27:56 --> Database Driver Class Initialized
DEBUG - 2011-08-06 14:27:56 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-06 14:27:56 --> Helper loaded: url_helper
DEBUG - 2011-08-06 14:27:56 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-06 14:27:56 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-06 14:27:56 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-06 14:27:56 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-06 14:27:56 --> Final output sent to browser
DEBUG - 2011-08-06 14:27:56 --> Total execution time: 0.0436
DEBUG - 2011-08-06 14:28:02 --> Config Class Initialized
DEBUG - 2011-08-06 14:28:02 --> Hooks Class Initialized
DEBUG - 2011-08-06 14:28:02 --> Utf8 Class Initialized
DEBUG - 2011-08-06 14:28:02 --> UTF-8 Support Enabled
DEBUG - 2011-08-06 14:28:02 --> URI Class Initialized
DEBUG - 2011-08-06 14:28:02 --> Router Class Initialized
DEBUG - 2011-08-06 14:28:02 --> Output Class Initialized
DEBUG - 2011-08-06 14:28:02 --> Input Class Initialized
DEBUG - 2011-08-06 14:28:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-06 14:28:02 --> Language Class Initialized
DEBUG - 2011-08-06 14:28:02 --> Loader Class Initialized
DEBUG - 2011-08-06 14:28:02 --> Controller Class Initialized
DEBUG - 2011-08-06 14:28:02 --> Model Class Initialized
DEBUG - 2011-08-06 14:28:02 --> Model Class Initialized
DEBUG - 2011-08-06 14:28:02 --> Model Class Initialized
DEBUG - 2011-08-06 14:28:02 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-06 14:28:02 --> Database Driver Class Initialized
DEBUG - 2011-08-06 14:28:03 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-06 14:28:03 --> Helper loaded: url_helper
DEBUG - 2011-08-06 14:28:03 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-06 14:28:03 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-06 14:28:03 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-06 14:28:03 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-06 14:28:03 --> Final output sent to browser
DEBUG - 2011-08-06 14:28:03 --> Total execution time: 0.1982
DEBUG - 2011-08-06 14:28:04 --> Config Class Initialized
DEBUG - 2011-08-06 14:28:04 --> Hooks Class Initialized
DEBUG - 2011-08-06 14:28:04 --> Utf8 Class Initialized
DEBUG - 2011-08-06 14:28:04 --> UTF-8 Support Enabled
DEBUG - 2011-08-06 14:28:04 --> URI Class Initialized
DEBUG - 2011-08-06 14:28:04 --> Router Class Initialized
DEBUG - 2011-08-06 14:28:04 --> Output Class Initialized
DEBUG - 2011-08-06 14:28:04 --> Input Class Initialized
DEBUG - 2011-08-06 14:28:04 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-06 14:28:04 --> Language Class Initialized
DEBUG - 2011-08-06 14:28:04 --> Loader Class Initialized
DEBUG - 2011-08-06 14:28:04 --> Controller Class Initialized
DEBUG - 2011-08-06 14:28:04 --> Model Class Initialized
DEBUG - 2011-08-06 14:28:04 --> Model Class Initialized
DEBUG - 2011-08-06 14:28:04 --> Model Class Initialized
DEBUG - 2011-08-06 14:28:04 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-06 14:28:04 --> Database Driver Class Initialized
DEBUG - 2011-08-06 14:28:04 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-06 14:28:04 --> Helper loaded: url_helper
DEBUG - 2011-08-06 14:28:04 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-06 14:28:04 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-06 14:28:04 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-06 14:28:04 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-06 14:28:04 --> Final output sent to browser
DEBUG - 2011-08-06 14:28:04 --> Total execution time: 0.0437
DEBUG - 2011-08-06 14:28:11 --> Config Class Initialized
DEBUG - 2011-08-06 14:28:11 --> Hooks Class Initialized
DEBUG - 2011-08-06 14:28:11 --> Utf8 Class Initialized
DEBUG - 2011-08-06 14:28:11 --> UTF-8 Support Enabled
DEBUG - 2011-08-06 14:28:11 --> URI Class Initialized
DEBUG - 2011-08-06 14:28:11 --> Router Class Initialized
DEBUG - 2011-08-06 14:28:11 --> Output Class Initialized
DEBUG - 2011-08-06 14:28:11 --> Input Class Initialized
DEBUG - 2011-08-06 14:28:11 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-06 14:28:11 --> Language Class Initialized
DEBUG - 2011-08-06 14:28:11 --> Loader Class Initialized
DEBUG - 2011-08-06 14:28:11 --> Controller Class Initialized
DEBUG - 2011-08-06 14:28:11 --> Model Class Initialized
DEBUG - 2011-08-06 14:28:11 --> Model Class Initialized
DEBUG - 2011-08-06 14:28:11 --> Model Class Initialized
DEBUG - 2011-08-06 14:28:11 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-06 14:28:11 --> Database Driver Class Initialized
DEBUG - 2011-08-06 14:28:11 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-06 14:28:11 --> Helper loaded: url_helper
DEBUG - 2011-08-06 14:28:11 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-06 14:28:11 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-06 14:28:11 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-06 14:28:11 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-06 14:28:11 --> Final output sent to browser
DEBUG - 2011-08-06 14:28:11 --> Total execution time: 0.3597
DEBUG - 2011-08-06 14:28:13 --> Config Class Initialized
DEBUG - 2011-08-06 14:28:13 --> Hooks Class Initialized
DEBUG - 2011-08-06 14:28:13 --> Utf8 Class Initialized
DEBUG - 2011-08-06 14:28:13 --> UTF-8 Support Enabled
DEBUG - 2011-08-06 14:28:13 --> URI Class Initialized
DEBUG - 2011-08-06 14:28:13 --> Router Class Initialized
DEBUG - 2011-08-06 14:28:13 --> Output Class Initialized
DEBUG - 2011-08-06 14:28:13 --> Input Class Initialized
DEBUG - 2011-08-06 14:28:13 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-06 14:28:13 --> Language Class Initialized
DEBUG - 2011-08-06 14:28:13 --> Loader Class Initialized
DEBUG - 2011-08-06 14:28:13 --> Controller Class Initialized
DEBUG - 2011-08-06 14:28:13 --> Model Class Initialized
DEBUG - 2011-08-06 14:28:13 --> Model Class Initialized
DEBUG - 2011-08-06 14:28:13 --> Model Class Initialized
DEBUG - 2011-08-06 14:28:13 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-06 14:28:13 --> Database Driver Class Initialized
DEBUG - 2011-08-06 14:28:13 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-06 14:28:13 --> Helper loaded: url_helper
DEBUG - 2011-08-06 14:28:13 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-06 14:28:13 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-06 14:28:13 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-06 14:28:13 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-06 14:28:13 --> Final output sent to browser
DEBUG - 2011-08-06 14:28:13 --> Total execution time: 0.0462
DEBUG - 2011-08-06 14:28:19 --> Config Class Initialized
DEBUG - 2011-08-06 14:28:19 --> Hooks Class Initialized
DEBUG - 2011-08-06 14:28:19 --> Utf8 Class Initialized
DEBUG - 2011-08-06 14:28:19 --> UTF-8 Support Enabled
DEBUG - 2011-08-06 14:28:19 --> URI Class Initialized
DEBUG - 2011-08-06 14:28:19 --> Router Class Initialized
DEBUG - 2011-08-06 14:28:19 --> Output Class Initialized
DEBUG - 2011-08-06 14:28:19 --> Input Class Initialized
DEBUG - 2011-08-06 14:28:19 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-06 14:28:19 --> Language Class Initialized
DEBUG - 2011-08-06 14:28:19 --> Loader Class Initialized
DEBUG - 2011-08-06 14:28:19 --> Controller Class Initialized
DEBUG - 2011-08-06 14:28:19 --> Model Class Initialized
DEBUG - 2011-08-06 14:28:19 --> Model Class Initialized
DEBUG - 2011-08-06 14:28:19 --> Model Class Initialized
DEBUG - 2011-08-06 14:28:19 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-06 14:28:19 --> Database Driver Class Initialized
DEBUG - 2011-08-06 14:28:19 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-06 14:28:19 --> Helper loaded: url_helper
DEBUG - 2011-08-06 14:28:19 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-06 14:28:19 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-06 14:28:19 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-06 14:28:19 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-06 14:28:19 --> Final output sent to browser
DEBUG - 2011-08-06 14:28:19 --> Total execution time: 0.2642
DEBUG - 2011-08-06 14:28:20 --> Config Class Initialized
DEBUG - 2011-08-06 14:28:20 --> Hooks Class Initialized
DEBUG - 2011-08-06 14:28:20 --> Utf8 Class Initialized
DEBUG - 2011-08-06 14:28:20 --> UTF-8 Support Enabled
DEBUG - 2011-08-06 14:28:20 --> URI Class Initialized
DEBUG - 2011-08-06 14:28:20 --> Router Class Initialized
DEBUG - 2011-08-06 14:28:20 --> Output Class Initialized
DEBUG - 2011-08-06 14:28:20 --> Input Class Initialized
DEBUG - 2011-08-06 14:28:20 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-06 14:28:20 --> Language Class Initialized
DEBUG - 2011-08-06 14:28:20 --> Loader Class Initialized
DEBUG - 2011-08-06 14:28:20 --> Controller Class Initialized
DEBUG - 2011-08-06 14:28:20 --> Model Class Initialized
DEBUG - 2011-08-06 14:28:20 --> Model Class Initialized
DEBUG - 2011-08-06 14:28:20 --> Model Class Initialized
DEBUG - 2011-08-06 14:28:20 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-06 14:28:20 --> Database Driver Class Initialized
DEBUG - 2011-08-06 14:28:20 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-06 14:28:20 --> Helper loaded: url_helper
DEBUG - 2011-08-06 14:28:20 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-06 14:28:20 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-06 14:28:20 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-06 14:28:20 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-06 14:28:20 --> Final output sent to browser
DEBUG - 2011-08-06 14:28:20 --> Total execution time: 0.0522
DEBUG - 2011-08-06 14:28:20 --> Config Class Initialized
DEBUG - 2011-08-06 14:28:20 --> Hooks Class Initialized
DEBUG - 2011-08-06 14:28:20 --> Utf8 Class Initialized
DEBUG - 2011-08-06 14:28:20 --> UTF-8 Support Enabled
DEBUG - 2011-08-06 14:28:20 --> URI Class Initialized
DEBUG - 2011-08-06 14:28:20 --> Router Class Initialized
DEBUG - 2011-08-06 14:28:20 --> Output Class Initialized
DEBUG - 2011-08-06 14:28:20 --> Input Class Initialized
DEBUG - 2011-08-06 14:28:20 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-06 14:28:20 --> Language Class Initialized
DEBUG - 2011-08-06 14:28:20 --> Loader Class Initialized
DEBUG - 2011-08-06 14:28:20 --> Controller Class Initialized
DEBUG - 2011-08-06 14:28:20 --> Model Class Initialized
DEBUG - 2011-08-06 14:28:20 --> Model Class Initialized
DEBUG - 2011-08-06 14:28:20 --> Model Class Initialized
DEBUG - 2011-08-06 14:28:20 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-06 14:28:20 --> Database Driver Class Initialized
DEBUG - 2011-08-06 14:28:20 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-06 14:28:20 --> Helper loaded: url_helper
DEBUG - 2011-08-06 14:28:20 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-06 14:28:20 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-06 14:28:20 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-06 14:28:20 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-06 14:28:20 --> Final output sent to browser
DEBUG - 2011-08-06 14:28:20 --> Total execution time: 0.0436
DEBUG - 2011-08-06 14:28:26 --> Config Class Initialized
DEBUG - 2011-08-06 14:28:26 --> Hooks Class Initialized
DEBUG - 2011-08-06 14:28:26 --> Utf8 Class Initialized
DEBUG - 2011-08-06 14:28:26 --> UTF-8 Support Enabled
DEBUG - 2011-08-06 14:28:26 --> URI Class Initialized
DEBUG - 2011-08-06 14:28:26 --> Router Class Initialized
DEBUG - 2011-08-06 14:28:26 --> Output Class Initialized
DEBUG - 2011-08-06 14:28:26 --> Input Class Initialized
DEBUG - 2011-08-06 14:28:26 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-06 14:28:26 --> Language Class Initialized
DEBUG - 2011-08-06 14:28:26 --> Loader Class Initialized
DEBUG - 2011-08-06 14:28:26 --> Controller Class Initialized
DEBUG - 2011-08-06 14:28:26 --> Model Class Initialized
DEBUG - 2011-08-06 14:28:26 --> Model Class Initialized
DEBUG - 2011-08-06 14:28:26 --> Model Class Initialized
DEBUG - 2011-08-06 14:28:26 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-06 14:28:26 --> Database Driver Class Initialized
DEBUG - 2011-08-06 14:28:27 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-06 14:28:27 --> Helper loaded: url_helper
DEBUG - 2011-08-06 14:28:27 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-06 14:28:27 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-06 14:28:27 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-06 14:28:27 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-06 14:28:27 --> Final output sent to browser
DEBUG - 2011-08-06 14:28:27 --> Total execution time: 0.3722
DEBUG - 2011-08-06 14:28:28 --> Config Class Initialized
DEBUG - 2011-08-06 14:28:28 --> Hooks Class Initialized
DEBUG - 2011-08-06 14:28:28 --> Utf8 Class Initialized
DEBUG - 2011-08-06 14:28:28 --> UTF-8 Support Enabled
DEBUG - 2011-08-06 14:28:28 --> URI Class Initialized
DEBUG - 2011-08-06 14:28:28 --> Router Class Initialized
DEBUG - 2011-08-06 14:28:28 --> Output Class Initialized
DEBUG - 2011-08-06 14:28:28 --> Input Class Initialized
DEBUG - 2011-08-06 14:28:28 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-06 14:28:28 --> Language Class Initialized
DEBUG - 2011-08-06 14:28:28 --> Loader Class Initialized
DEBUG - 2011-08-06 14:28:28 --> Controller Class Initialized
DEBUG - 2011-08-06 14:28:28 --> Model Class Initialized
DEBUG - 2011-08-06 14:28:28 --> Model Class Initialized
DEBUG - 2011-08-06 14:28:28 --> Model Class Initialized
DEBUG - 2011-08-06 14:28:28 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-06 14:28:28 --> Database Driver Class Initialized
DEBUG - 2011-08-06 14:28:28 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-06 14:28:28 --> Helper loaded: url_helper
DEBUG - 2011-08-06 14:28:28 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-06 14:28:28 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-06 14:28:28 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-06 14:28:28 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-06 14:28:28 --> Final output sent to browser
DEBUG - 2011-08-06 14:28:28 --> Total execution time: 0.0445
DEBUG - 2011-08-06 14:28:45 --> Config Class Initialized
DEBUG - 2011-08-06 14:28:45 --> Hooks Class Initialized
DEBUG - 2011-08-06 14:28:45 --> Utf8 Class Initialized
DEBUG - 2011-08-06 14:28:45 --> UTF-8 Support Enabled
DEBUG - 2011-08-06 14:28:45 --> URI Class Initialized
DEBUG - 2011-08-06 14:28:45 --> Router Class Initialized
DEBUG - 2011-08-06 14:28:45 --> Output Class Initialized
DEBUG - 2011-08-06 14:28:45 --> Input Class Initialized
DEBUG - 2011-08-06 14:28:45 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-06 14:28:45 --> Language Class Initialized
DEBUG - 2011-08-06 14:28:45 --> Loader Class Initialized
DEBUG - 2011-08-06 14:28:45 --> Controller Class Initialized
DEBUG - 2011-08-06 14:28:45 --> Model Class Initialized
DEBUG - 2011-08-06 14:28:45 --> Model Class Initialized
DEBUG - 2011-08-06 14:28:45 --> Model Class Initialized
DEBUG - 2011-08-06 14:28:45 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-06 14:28:45 --> Database Driver Class Initialized
DEBUG - 2011-08-06 14:28:45 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-06 14:28:45 --> Helper loaded: url_helper
DEBUG - 2011-08-06 14:28:45 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-06 14:28:45 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-06 14:28:45 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-06 14:28:45 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-06 14:28:45 --> Final output sent to browser
DEBUG - 2011-08-06 14:28:45 --> Total execution time: 0.2010
DEBUG - 2011-08-06 14:28:46 --> Config Class Initialized
DEBUG - 2011-08-06 14:28:46 --> Hooks Class Initialized
DEBUG - 2011-08-06 14:28:46 --> Utf8 Class Initialized
DEBUG - 2011-08-06 14:28:46 --> UTF-8 Support Enabled
DEBUG - 2011-08-06 14:28:46 --> URI Class Initialized
DEBUG - 2011-08-06 14:28:46 --> Router Class Initialized
DEBUG - 2011-08-06 14:28:46 --> Output Class Initialized
DEBUG - 2011-08-06 14:28:46 --> Input Class Initialized
DEBUG - 2011-08-06 14:28:46 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-06 14:28:46 --> Language Class Initialized
DEBUG - 2011-08-06 14:28:46 --> Loader Class Initialized
DEBUG - 2011-08-06 14:28:46 --> Controller Class Initialized
DEBUG - 2011-08-06 14:28:46 --> Model Class Initialized
DEBUG - 2011-08-06 14:28:46 --> Model Class Initialized
DEBUG - 2011-08-06 14:28:46 --> Model Class Initialized
DEBUG - 2011-08-06 14:28:46 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-06 14:28:46 --> Database Driver Class Initialized
DEBUG - 2011-08-06 14:28:46 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-06 14:28:46 --> Helper loaded: url_helper
DEBUG - 2011-08-06 14:28:46 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-06 14:28:46 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-06 14:28:46 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-06 14:28:46 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-06 14:28:46 --> Final output sent to browser
DEBUG - 2011-08-06 14:28:46 --> Total execution time: 0.0458
DEBUG - 2011-08-06 14:28:52 --> Config Class Initialized
DEBUG - 2011-08-06 14:28:52 --> Hooks Class Initialized
DEBUG - 2011-08-06 14:28:52 --> Utf8 Class Initialized
DEBUG - 2011-08-06 14:28:52 --> UTF-8 Support Enabled
DEBUG - 2011-08-06 14:28:52 --> URI Class Initialized
DEBUG - 2011-08-06 14:28:52 --> Router Class Initialized
DEBUG - 2011-08-06 14:28:52 --> Output Class Initialized
DEBUG - 2011-08-06 14:28:52 --> Input Class Initialized
DEBUG - 2011-08-06 14:28:52 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-06 14:28:52 --> Language Class Initialized
DEBUG - 2011-08-06 14:28:52 --> Loader Class Initialized
DEBUG - 2011-08-06 14:28:52 --> Controller Class Initialized
DEBUG - 2011-08-06 14:28:52 --> Model Class Initialized
DEBUG - 2011-08-06 14:28:52 --> Model Class Initialized
DEBUG - 2011-08-06 14:28:52 --> Model Class Initialized
DEBUG - 2011-08-06 14:28:52 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-06 14:28:52 --> Database Driver Class Initialized
DEBUG - 2011-08-06 14:28:52 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-06 14:28:52 --> Helper loaded: url_helper
DEBUG - 2011-08-06 14:28:52 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-06 14:28:52 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-06 14:28:52 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-06 14:28:52 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-06 14:28:52 --> Final output sent to browser
DEBUG - 2011-08-06 14:28:52 --> Total execution time: 0.4230
DEBUG - 2011-08-06 14:28:53 --> Config Class Initialized
DEBUG - 2011-08-06 14:28:53 --> Hooks Class Initialized
DEBUG - 2011-08-06 14:28:53 --> Utf8 Class Initialized
DEBUG - 2011-08-06 14:28:53 --> UTF-8 Support Enabled
DEBUG - 2011-08-06 14:28:53 --> URI Class Initialized
DEBUG - 2011-08-06 14:28:53 --> Router Class Initialized
DEBUG - 2011-08-06 14:28:53 --> Output Class Initialized
DEBUG - 2011-08-06 14:28:53 --> Input Class Initialized
DEBUG - 2011-08-06 14:28:53 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-06 14:28:53 --> Language Class Initialized
DEBUG - 2011-08-06 14:28:53 --> Loader Class Initialized
DEBUG - 2011-08-06 14:28:53 --> Controller Class Initialized
DEBUG - 2011-08-06 14:28:53 --> Model Class Initialized
DEBUG - 2011-08-06 14:28:53 --> Model Class Initialized
DEBUG - 2011-08-06 14:28:53 --> Model Class Initialized
DEBUG - 2011-08-06 14:28:53 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-06 14:28:53 --> Database Driver Class Initialized
DEBUG - 2011-08-06 14:28:53 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-06 14:28:53 --> Helper loaded: url_helper
DEBUG - 2011-08-06 14:28:53 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-06 14:28:53 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-06 14:28:53 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-06 14:28:53 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-06 14:28:53 --> Final output sent to browser
DEBUG - 2011-08-06 14:28:53 --> Total execution time: 0.0461
DEBUG - 2011-08-06 14:29:01 --> Config Class Initialized
DEBUG - 2011-08-06 14:29:01 --> Hooks Class Initialized
DEBUG - 2011-08-06 14:29:01 --> Utf8 Class Initialized
DEBUG - 2011-08-06 14:29:01 --> UTF-8 Support Enabled
DEBUG - 2011-08-06 14:29:01 --> URI Class Initialized
DEBUG - 2011-08-06 14:29:01 --> Router Class Initialized
DEBUG - 2011-08-06 14:29:01 --> Output Class Initialized
DEBUG - 2011-08-06 14:29:01 --> Input Class Initialized
DEBUG - 2011-08-06 14:29:01 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-06 14:29:01 --> Language Class Initialized
DEBUG - 2011-08-06 14:29:01 --> Loader Class Initialized
DEBUG - 2011-08-06 14:29:01 --> Controller Class Initialized
DEBUG - 2011-08-06 14:29:01 --> Model Class Initialized
DEBUG - 2011-08-06 14:29:01 --> Model Class Initialized
DEBUG - 2011-08-06 14:29:01 --> Model Class Initialized
DEBUG - 2011-08-06 14:29:01 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-06 14:29:01 --> Database Driver Class Initialized
DEBUG - 2011-08-06 14:29:01 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-06 14:29:01 --> Helper loaded: url_helper
DEBUG - 2011-08-06 14:29:01 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-06 14:29:01 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-06 14:29:01 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-06 14:29:01 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-06 14:29:01 --> Final output sent to browser
DEBUG - 2011-08-06 14:29:01 --> Total execution time: 0.2649
DEBUG - 2011-08-06 14:29:02 --> Config Class Initialized
DEBUG - 2011-08-06 14:29:02 --> Hooks Class Initialized
DEBUG - 2011-08-06 14:29:02 --> Utf8 Class Initialized
DEBUG - 2011-08-06 14:29:02 --> UTF-8 Support Enabled
DEBUG - 2011-08-06 14:29:02 --> URI Class Initialized
DEBUG - 2011-08-06 14:29:02 --> Router Class Initialized
DEBUG - 2011-08-06 14:29:02 --> Output Class Initialized
DEBUG - 2011-08-06 14:29:02 --> Input Class Initialized
DEBUG - 2011-08-06 14:29:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-06 14:29:02 --> Language Class Initialized
DEBUG - 2011-08-06 14:29:02 --> Loader Class Initialized
DEBUG - 2011-08-06 14:29:02 --> Controller Class Initialized
DEBUG - 2011-08-06 14:29:02 --> Model Class Initialized
DEBUG - 2011-08-06 14:29:02 --> Model Class Initialized
DEBUG - 2011-08-06 14:29:02 --> Model Class Initialized
DEBUG - 2011-08-06 14:29:02 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-06 14:29:02 --> Database Driver Class Initialized
DEBUG - 2011-08-06 14:29:02 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-06 14:29:02 --> Helper loaded: url_helper
DEBUG - 2011-08-06 14:29:02 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-06 14:29:02 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-06 14:29:02 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-06 14:29:02 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-06 14:29:02 --> Final output sent to browser
DEBUG - 2011-08-06 14:29:02 --> Total execution time: 0.0434
DEBUG - 2011-08-06 14:29:13 --> Config Class Initialized
DEBUG - 2011-08-06 14:29:13 --> Hooks Class Initialized
DEBUG - 2011-08-06 14:29:13 --> Utf8 Class Initialized
DEBUG - 2011-08-06 14:29:13 --> UTF-8 Support Enabled
DEBUG - 2011-08-06 14:29:13 --> URI Class Initialized
DEBUG - 2011-08-06 14:29:13 --> Router Class Initialized
DEBUG - 2011-08-06 14:29:13 --> Output Class Initialized
DEBUG - 2011-08-06 14:29:13 --> Input Class Initialized
DEBUG - 2011-08-06 14:29:13 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-06 14:29:13 --> Language Class Initialized
DEBUG - 2011-08-06 14:29:13 --> Loader Class Initialized
DEBUG - 2011-08-06 14:29:13 --> Controller Class Initialized
DEBUG - 2011-08-06 14:29:13 --> Model Class Initialized
DEBUG - 2011-08-06 14:29:13 --> Model Class Initialized
DEBUG - 2011-08-06 14:29:13 --> Model Class Initialized
DEBUG - 2011-08-06 14:29:13 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-06 14:29:13 --> Database Driver Class Initialized
DEBUG - 2011-08-06 14:29:13 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-06 14:29:13 --> Helper loaded: url_helper
DEBUG - 2011-08-06 14:29:13 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-06 14:29:13 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-06 14:29:13 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-06 14:29:13 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-06 14:29:13 --> Final output sent to browser
DEBUG - 2011-08-06 14:29:13 --> Total execution time: 0.2284
DEBUG - 2011-08-06 14:29:16 --> Config Class Initialized
DEBUG - 2011-08-06 14:29:16 --> Hooks Class Initialized
DEBUG - 2011-08-06 14:29:16 --> Utf8 Class Initialized
DEBUG - 2011-08-06 14:29:16 --> UTF-8 Support Enabled
DEBUG - 2011-08-06 14:29:16 --> URI Class Initialized
DEBUG - 2011-08-06 14:29:16 --> Router Class Initialized
DEBUG - 2011-08-06 14:29:16 --> Output Class Initialized
DEBUG - 2011-08-06 14:29:16 --> Input Class Initialized
DEBUG - 2011-08-06 14:29:16 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-06 14:29:16 --> Language Class Initialized
DEBUG - 2011-08-06 14:29:16 --> Loader Class Initialized
DEBUG - 2011-08-06 14:29:16 --> Controller Class Initialized
DEBUG - 2011-08-06 14:29:16 --> Model Class Initialized
DEBUG - 2011-08-06 14:29:16 --> Model Class Initialized
DEBUG - 2011-08-06 14:29:16 --> Model Class Initialized
DEBUG - 2011-08-06 14:29:16 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-06 14:29:16 --> Database Driver Class Initialized
DEBUG - 2011-08-06 14:29:16 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-06 14:29:16 --> Helper loaded: url_helper
DEBUG - 2011-08-06 14:29:16 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-06 14:29:16 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-06 14:29:16 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-06 14:29:16 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-06 14:29:16 --> Final output sent to browser
DEBUG - 2011-08-06 14:29:16 --> Total execution time: 0.0425
DEBUG - 2011-08-06 14:29:21 --> Config Class Initialized
DEBUG - 2011-08-06 14:29:21 --> Hooks Class Initialized
DEBUG - 2011-08-06 14:29:21 --> Utf8 Class Initialized
DEBUG - 2011-08-06 14:29:21 --> UTF-8 Support Enabled
DEBUG - 2011-08-06 14:29:21 --> URI Class Initialized
DEBUG - 2011-08-06 14:29:21 --> Router Class Initialized
DEBUG - 2011-08-06 14:29:21 --> Output Class Initialized
DEBUG - 2011-08-06 14:29:21 --> Input Class Initialized
DEBUG - 2011-08-06 14:29:21 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-06 14:29:21 --> Language Class Initialized
DEBUG - 2011-08-06 14:29:21 --> Loader Class Initialized
DEBUG - 2011-08-06 14:29:21 --> Controller Class Initialized
DEBUG - 2011-08-06 14:29:21 --> Model Class Initialized
DEBUG - 2011-08-06 14:29:21 --> Model Class Initialized
DEBUG - 2011-08-06 14:29:21 --> Model Class Initialized
DEBUG - 2011-08-06 14:29:21 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-06 14:29:21 --> Database Driver Class Initialized
DEBUG - 2011-08-06 14:29:22 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-06 14:29:22 --> Helper loaded: url_helper
DEBUG - 2011-08-06 14:29:22 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-06 14:29:22 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-06 14:29:22 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-06 14:29:22 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-06 14:29:22 --> Final output sent to browser
DEBUG - 2011-08-06 14:29:22 --> Total execution time: 0.2306
DEBUG - 2011-08-06 14:29:23 --> Config Class Initialized
DEBUG - 2011-08-06 14:29:23 --> Hooks Class Initialized
DEBUG - 2011-08-06 14:29:23 --> Utf8 Class Initialized
DEBUG - 2011-08-06 14:29:23 --> UTF-8 Support Enabled
DEBUG - 2011-08-06 14:29:23 --> URI Class Initialized
DEBUG - 2011-08-06 14:29:23 --> Router Class Initialized
DEBUG - 2011-08-06 14:29:23 --> Output Class Initialized
DEBUG - 2011-08-06 14:29:23 --> Input Class Initialized
DEBUG - 2011-08-06 14:29:23 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-06 14:29:23 --> Language Class Initialized
DEBUG - 2011-08-06 14:29:23 --> Loader Class Initialized
DEBUG - 2011-08-06 14:29:23 --> Controller Class Initialized
DEBUG - 2011-08-06 14:29:23 --> Model Class Initialized
DEBUG - 2011-08-06 14:29:23 --> Model Class Initialized
DEBUG - 2011-08-06 14:29:23 --> Model Class Initialized
DEBUG - 2011-08-06 14:29:23 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-06 14:29:23 --> Database Driver Class Initialized
DEBUG - 2011-08-06 14:29:23 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-06 14:29:23 --> Helper loaded: url_helper
DEBUG - 2011-08-06 14:29:23 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-06 14:29:23 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-06 14:29:23 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-06 14:29:23 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-06 14:29:23 --> Final output sent to browser
DEBUG - 2011-08-06 14:29:23 --> Total execution time: 0.0459
DEBUG - 2011-08-06 14:29:31 --> Config Class Initialized
DEBUG - 2011-08-06 14:29:31 --> Hooks Class Initialized
DEBUG - 2011-08-06 14:29:31 --> Utf8 Class Initialized
DEBUG - 2011-08-06 14:29:31 --> UTF-8 Support Enabled
DEBUG - 2011-08-06 14:29:31 --> URI Class Initialized
DEBUG - 2011-08-06 14:29:31 --> Router Class Initialized
DEBUG - 2011-08-06 14:29:31 --> Output Class Initialized
DEBUG - 2011-08-06 14:29:31 --> Input Class Initialized
DEBUG - 2011-08-06 14:29:31 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-06 14:29:31 --> Language Class Initialized
DEBUG - 2011-08-06 14:29:31 --> Loader Class Initialized
DEBUG - 2011-08-06 14:29:31 --> Controller Class Initialized
DEBUG - 2011-08-06 14:29:31 --> Model Class Initialized
DEBUG - 2011-08-06 14:29:31 --> Model Class Initialized
DEBUG - 2011-08-06 14:29:31 --> Model Class Initialized
DEBUG - 2011-08-06 14:29:31 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-06 14:29:31 --> Database Driver Class Initialized
DEBUG - 2011-08-06 14:29:31 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-06 14:29:31 --> Helper loaded: url_helper
DEBUG - 2011-08-06 14:29:31 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-06 14:29:31 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-06 14:29:31 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-06 14:29:31 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-06 14:29:31 --> Final output sent to browser
DEBUG - 2011-08-06 14:29:31 --> Total execution time: 0.2652
DEBUG - 2011-08-06 14:29:38 --> Config Class Initialized
DEBUG - 2011-08-06 14:29:38 --> Hooks Class Initialized
DEBUG - 2011-08-06 14:29:38 --> Utf8 Class Initialized
DEBUG - 2011-08-06 14:29:38 --> UTF-8 Support Enabled
DEBUG - 2011-08-06 14:29:38 --> URI Class Initialized
DEBUG - 2011-08-06 14:29:38 --> Router Class Initialized
DEBUG - 2011-08-06 14:29:38 --> Output Class Initialized
DEBUG - 2011-08-06 14:29:38 --> Input Class Initialized
DEBUG - 2011-08-06 14:29:38 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-06 14:29:38 --> Language Class Initialized
DEBUG - 2011-08-06 14:29:38 --> Loader Class Initialized
DEBUG - 2011-08-06 14:29:38 --> Controller Class Initialized
DEBUG - 2011-08-06 14:29:38 --> Model Class Initialized
DEBUG - 2011-08-06 14:29:38 --> Model Class Initialized
DEBUG - 2011-08-06 14:29:38 --> Model Class Initialized
DEBUG - 2011-08-06 14:29:38 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-06 14:29:38 --> Database Driver Class Initialized
DEBUG - 2011-08-06 14:29:38 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-06 14:29:38 --> Helper loaded: url_helper
DEBUG - 2011-08-06 14:29:38 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-06 14:29:38 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-06 14:29:38 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-06 14:29:38 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-06 14:29:38 --> Final output sent to browser
DEBUG - 2011-08-06 14:29:38 --> Total execution time: 0.3622
DEBUG - 2011-08-06 14:29:45 --> Config Class Initialized
DEBUG - 2011-08-06 14:29:45 --> Hooks Class Initialized
DEBUG - 2011-08-06 14:29:45 --> Utf8 Class Initialized
DEBUG - 2011-08-06 14:29:45 --> UTF-8 Support Enabled
DEBUG - 2011-08-06 14:29:45 --> URI Class Initialized
DEBUG - 2011-08-06 14:29:45 --> Router Class Initialized
DEBUG - 2011-08-06 14:29:45 --> Output Class Initialized
DEBUG - 2011-08-06 14:29:45 --> Input Class Initialized
DEBUG - 2011-08-06 14:29:45 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-06 14:29:45 --> Language Class Initialized
DEBUG - 2011-08-06 14:29:45 --> Loader Class Initialized
DEBUG - 2011-08-06 14:29:45 --> Controller Class Initialized
DEBUG - 2011-08-06 14:29:45 --> Model Class Initialized
DEBUG - 2011-08-06 14:29:45 --> Model Class Initialized
DEBUG - 2011-08-06 14:29:45 --> Model Class Initialized
DEBUG - 2011-08-06 14:29:45 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-06 14:29:45 --> Database Driver Class Initialized
DEBUG - 2011-08-06 14:29:45 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-06 14:29:45 --> Helper loaded: url_helper
DEBUG - 2011-08-06 14:29:45 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-06 14:29:45 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-06 14:29:45 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-06 14:29:45 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-06 14:29:45 --> Final output sent to browser
DEBUG - 2011-08-06 14:29:45 --> Total execution time: 0.1815
DEBUG - 2011-08-06 14:29:51 --> Config Class Initialized
DEBUG - 2011-08-06 14:29:51 --> Hooks Class Initialized
DEBUG - 2011-08-06 14:29:51 --> Utf8 Class Initialized
DEBUG - 2011-08-06 14:29:51 --> UTF-8 Support Enabled
DEBUG - 2011-08-06 14:29:51 --> URI Class Initialized
DEBUG - 2011-08-06 14:29:51 --> Router Class Initialized
DEBUG - 2011-08-06 14:29:51 --> Output Class Initialized
DEBUG - 2011-08-06 14:29:51 --> Input Class Initialized
DEBUG - 2011-08-06 14:29:51 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-06 14:29:51 --> Language Class Initialized
DEBUG - 2011-08-06 14:29:51 --> Loader Class Initialized
DEBUG - 2011-08-06 14:29:51 --> Controller Class Initialized
DEBUG - 2011-08-06 14:29:51 --> Model Class Initialized
DEBUG - 2011-08-06 14:29:51 --> Model Class Initialized
DEBUG - 2011-08-06 14:29:51 --> Model Class Initialized
DEBUG - 2011-08-06 14:29:51 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-06 14:29:51 --> Database Driver Class Initialized
DEBUG - 2011-08-06 14:29:52 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-06 14:29:52 --> Helper loaded: url_helper
DEBUG - 2011-08-06 14:29:52 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-06 14:29:52 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-06 14:29:52 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-06 14:29:52 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-06 14:29:52 --> Final output sent to browser
DEBUG - 2011-08-06 14:29:52 --> Total execution time: 0.1964
DEBUG - 2011-08-06 14:29:57 --> Config Class Initialized
DEBUG - 2011-08-06 14:29:57 --> Hooks Class Initialized
DEBUG - 2011-08-06 14:29:57 --> Utf8 Class Initialized
DEBUG - 2011-08-06 14:29:57 --> UTF-8 Support Enabled
DEBUG - 2011-08-06 14:29:57 --> URI Class Initialized
DEBUG - 2011-08-06 14:29:57 --> Router Class Initialized
DEBUG - 2011-08-06 14:29:57 --> Output Class Initialized
DEBUG - 2011-08-06 14:29:57 --> Input Class Initialized
DEBUG - 2011-08-06 14:29:57 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-06 14:29:57 --> Language Class Initialized
DEBUG - 2011-08-06 14:29:57 --> Loader Class Initialized
DEBUG - 2011-08-06 14:29:57 --> Controller Class Initialized
DEBUG - 2011-08-06 14:29:57 --> Model Class Initialized
DEBUG - 2011-08-06 14:29:57 --> Model Class Initialized
DEBUG - 2011-08-06 14:29:57 --> Model Class Initialized
DEBUG - 2011-08-06 14:29:57 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-06 14:29:57 --> Database Driver Class Initialized
DEBUG - 2011-08-06 14:29:57 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-06 14:29:57 --> Helper loaded: url_helper
DEBUG - 2011-08-06 14:29:57 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-06 14:29:57 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-06 14:29:57 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-06 14:29:57 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-06 14:29:57 --> Final output sent to browser
DEBUG - 2011-08-06 14:29:57 --> Total execution time: 0.0473
DEBUG - 2011-08-06 14:29:58 --> Config Class Initialized
DEBUG - 2011-08-06 14:29:58 --> Hooks Class Initialized
DEBUG - 2011-08-06 14:29:58 --> Utf8 Class Initialized
DEBUG - 2011-08-06 14:29:58 --> UTF-8 Support Enabled
DEBUG - 2011-08-06 14:29:58 --> URI Class Initialized
DEBUG - 2011-08-06 14:29:58 --> Router Class Initialized
DEBUG - 2011-08-06 14:29:58 --> Output Class Initialized
DEBUG - 2011-08-06 14:29:58 --> Input Class Initialized
DEBUG - 2011-08-06 14:29:58 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-06 14:29:58 --> Language Class Initialized
DEBUG - 2011-08-06 14:29:58 --> Loader Class Initialized
DEBUG - 2011-08-06 14:29:58 --> Controller Class Initialized
DEBUG - 2011-08-06 14:29:58 --> Model Class Initialized
DEBUG - 2011-08-06 14:29:58 --> Model Class Initialized
DEBUG - 2011-08-06 14:29:58 --> Model Class Initialized
DEBUG - 2011-08-06 14:29:58 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-06 14:29:58 --> Database Driver Class Initialized
DEBUG - 2011-08-06 14:29:58 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-06 14:29:58 --> Helper loaded: url_helper
DEBUG - 2011-08-06 14:29:58 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-06 14:29:58 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-06 14:29:58 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-06 14:29:58 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-06 14:29:58 --> Final output sent to browser
DEBUG - 2011-08-06 14:29:58 --> Total execution time: 0.0501
DEBUG - 2011-08-06 14:30:00 --> Config Class Initialized
DEBUG - 2011-08-06 14:30:00 --> Hooks Class Initialized
DEBUG - 2011-08-06 14:30:00 --> Utf8 Class Initialized
DEBUG - 2011-08-06 14:30:00 --> UTF-8 Support Enabled
DEBUG - 2011-08-06 14:30:00 --> URI Class Initialized
DEBUG - 2011-08-06 14:30:00 --> Router Class Initialized
DEBUG - 2011-08-06 14:30:00 --> Output Class Initialized
DEBUG - 2011-08-06 14:30:00 --> Input Class Initialized
DEBUG - 2011-08-06 14:30:00 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-06 14:30:00 --> Language Class Initialized
DEBUG - 2011-08-06 14:30:00 --> Loader Class Initialized
DEBUG - 2011-08-06 14:30:00 --> Controller Class Initialized
DEBUG - 2011-08-06 14:30:00 --> Model Class Initialized
DEBUG - 2011-08-06 14:30:00 --> Model Class Initialized
DEBUG - 2011-08-06 14:30:00 --> Model Class Initialized
DEBUG - 2011-08-06 14:30:00 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-06 14:30:00 --> Database Driver Class Initialized
DEBUG - 2011-08-06 14:30:00 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-06 14:30:00 --> Helper loaded: url_helper
DEBUG - 2011-08-06 14:30:00 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-06 14:30:00 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-06 14:30:00 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-06 14:30:00 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-06 14:30:00 --> Final output sent to browser
DEBUG - 2011-08-06 14:30:00 --> Total execution time: 0.0903
DEBUG - 2011-08-06 14:30:01 --> Config Class Initialized
DEBUG - 2011-08-06 14:30:01 --> Hooks Class Initialized
DEBUG - 2011-08-06 14:30:01 --> Utf8 Class Initialized
DEBUG - 2011-08-06 14:30:01 --> UTF-8 Support Enabled
DEBUG - 2011-08-06 14:30:01 --> URI Class Initialized
DEBUG - 2011-08-06 14:30:01 --> Router Class Initialized
DEBUG - 2011-08-06 14:30:01 --> Output Class Initialized
DEBUG - 2011-08-06 14:30:01 --> Input Class Initialized
DEBUG - 2011-08-06 14:30:01 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-06 14:30:01 --> Language Class Initialized
DEBUG - 2011-08-06 14:30:01 --> Loader Class Initialized
DEBUG - 2011-08-06 14:30:01 --> Controller Class Initialized
DEBUG - 2011-08-06 14:30:01 --> Model Class Initialized
DEBUG - 2011-08-06 14:30:01 --> Model Class Initialized
DEBUG - 2011-08-06 14:30:01 --> Model Class Initialized
DEBUG - 2011-08-06 14:30:01 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-06 14:30:01 --> Database Driver Class Initialized
DEBUG - 2011-08-06 14:30:01 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-06 14:30:01 --> Helper loaded: url_helper
DEBUG - 2011-08-06 14:30:01 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-06 14:30:01 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-06 14:30:01 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-06 14:30:01 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-06 14:30:01 --> Final output sent to browser
DEBUG - 2011-08-06 14:30:01 --> Total execution time: 0.0426
DEBUG - 2011-08-06 14:30:03 --> Config Class Initialized
DEBUG - 2011-08-06 14:30:03 --> Hooks Class Initialized
DEBUG - 2011-08-06 14:30:03 --> Utf8 Class Initialized
DEBUG - 2011-08-06 14:30:03 --> UTF-8 Support Enabled
DEBUG - 2011-08-06 14:30:03 --> URI Class Initialized
DEBUG - 2011-08-06 14:30:03 --> Router Class Initialized
DEBUG - 2011-08-06 14:30:03 --> Output Class Initialized
DEBUG - 2011-08-06 14:30:03 --> Input Class Initialized
DEBUG - 2011-08-06 14:30:03 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-06 14:30:03 --> Language Class Initialized
DEBUG - 2011-08-06 14:30:03 --> Loader Class Initialized
DEBUG - 2011-08-06 14:30:03 --> Controller Class Initialized
DEBUG - 2011-08-06 14:30:03 --> Model Class Initialized
DEBUG - 2011-08-06 14:30:03 --> Model Class Initialized
DEBUG - 2011-08-06 14:30:03 --> Model Class Initialized
DEBUG - 2011-08-06 14:30:03 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-06 14:30:03 --> Database Driver Class Initialized
DEBUG - 2011-08-06 14:30:03 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-06 14:30:03 --> Helper loaded: url_helper
DEBUG - 2011-08-06 14:30:03 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-06 14:30:03 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-06 14:30:03 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-06 14:30:03 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-06 14:30:03 --> Final output sent to browser
DEBUG - 2011-08-06 14:30:03 --> Total execution time: 0.4518
DEBUG - 2011-08-06 14:30:09 --> Config Class Initialized
DEBUG - 2011-08-06 14:30:09 --> Hooks Class Initialized
DEBUG - 2011-08-06 14:30:09 --> Utf8 Class Initialized
DEBUG - 2011-08-06 14:30:09 --> UTF-8 Support Enabled
DEBUG - 2011-08-06 14:30:09 --> URI Class Initialized
DEBUG - 2011-08-06 14:30:09 --> Router Class Initialized
DEBUG - 2011-08-06 14:30:09 --> Output Class Initialized
DEBUG - 2011-08-06 14:30:09 --> Input Class Initialized
DEBUG - 2011-08-06 14:30:09 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-06 14:30:09 --> Language Class Initialized
DEBUG - 2011-08-06 14:30:09 --> Loader Class Initialized
DEBUG - 2011-08-06 14:30:09 --> Controller Class Initialized
DEBUG - 2011-08-06 14:30:09 --> Model Class Initialized
DEBUG - 2011-08-06 14:30:09 --> Model Class Initialized
DEBUG - 2011-08-06 14:30:09 --> Model Class Initialized
DEBUG - 2011-08-06 14:30:09 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-06 14:30:09 --> Database Driver Class Initialized
DEBUG - 2011-08-06 14:30:09 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-06 14:30:09 --> Helper loaded: url_helper
DEBUG - 2011-08-06 14:30:09 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-06 14:30:09 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-06 14:30:09 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-06 14:30:09 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-06 14:30:09 --> Final output sent to browser
DEBUG - 2011-08-06 14:30:09 --> Total execution time: 0.0951
DEBUG - 2011-08-06 14:30:31 --> Config Class Initialized
DEBUG - 2011-08-06 14:30:31 --> Hooks Class Initialized
DEBUG - 2011-08-06 14:30:31 --> Utf8 Class Initialized
DEBUG - 2011-08-06 14:30:31 --> UTF-8 Support Enabled
DEBUG - 2011-08-06 14:30:31 --> URI Class Initialized
DEBUG - 2011-08-06 14:30:31 --> Router Class Initialized
DEBUG - 2011-08-06 14:30:31 --> Output Class Initialized
DEBUG - 2011-08-06 14:30:31 --> Input Class Initialized
DEBUG - 2011-08-06 14:30:31 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-06 14:30:31 --> Language Class Initialized
DEBUG - 2011-08-06 14:30:31 --> Loader Class Initialized
DEBUG - 2011-08-06 14:30:31 --> Controller Class Initialized
DEBUG - 2011-08-06 14:30:31 --> Model Class Initialized
DEBUG - 2011-08-06 14:30:31 --> Model Class Initialized
DEBUG - 2011-08-06 14:30:31 --> Model Class Initialized
DEBUG - 2011-08-06 14:30:31 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-06 14:30:31 --> Database Driver Class Initialized
DEBUG - 2011-08-06 14:30:31 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-06 14:30:31 --> Helper loaded: url_helper
DEBUG - 2011-08-06 14:30:31 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-06 14:30:31 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-06 14:30:31 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-06 14:30:31 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-06 14:30:31 --> Final output sent to browser
DEBUG - 2011-08-06 14:30:31 --> Total execution time: 0.3169
DEBUG - 2011-08-06 14:30:38 --> Config Class Initialized
DEBUG - 2011-08-06 14:30:38 --> Hooks Class Initialized
DEBUG - 2011-08-06 14:30:38 --> Utf8 Class Initialized
DEBUG - 2011-08-06 14:30:38 --> UTF-8 Support Enabled
DEBUG - 2011-08-06 14:30:38 --> URI Class Initialized
DEBUG - 2011-08-06 14:30:38 --> Router Class Initialized
DEBUG - 2011-08-06 14:30:38 --> Output Class Initialized
DEBUG - 2011-08-06 14:30:38 --> Input Class Initialized
DEBUG - 2011-08-06 14:30:38 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-06 14:30:38 --> Language Class Initialized
DEBUG - 2011-08-06 14:30:38 --> Loader Class Initialized
DEBUG - 2011-08-06 14:30:38 --> Controller Class Initialized
DEBUG - 2011-08-06 14:30:38 --> Model Class Initialized
DEBUG - 2011-08-06 14:30:38 --> Model Class Initialized
DEBUG - 2011-08-06 14:30:38 --> Model Class Initialized
DEBUG - 2011-08-06 14:30:38 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-06 14:30:38 --> Database Driver Class Initialized
DEBUG - 2011-08-06 14:30:39 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-06 14:30:39 --> Helper loaded: url_helper
DEBUG - 2011-08-06 14:30:39 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-06 14:30:39 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-06 14:30:39 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-06 14:30:39 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-06 14:30:39 --> Final output sent to browser
DEBUG - 2011-08-06 14:30:39 --> Total execution time: 0.2618
DEBUG - 2011-08-06 14:30:45 --> Config Class Initialized
DEBUG - 2011-08-06 14:30:45 --> Hooks Class Initialized
DEBUG - 2011-08-06 14:30:45 --> Utf8 Class Initialized
DEBUG - 2011-08-06 14:30:45 --> UTF-8 Support Enabled
DEBUG - 2011-08-06 14:30:45 --> URI Class Initialized
DEBUG - 2011-08-06 14:30:45 --> Router Class Initialized
DEBUG - 2011-08-06 14:30:45 --> Output Class Initialized
DEBUG - 2011-08-06 14:30:45 --> Input Class Initialized
DEBUG - 2011-08-06 14:30:45 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-06 14:30:45 --> Language Class Initialized
DEBUG - 2011-08-06 14:30:45 --> Loader Class Initialized
DEBUG - 2011-08-06 14:30:45 --> Controller Class Initialized
DEBUG - 2011-08-06 14:30:45 --> Model Class Initialized
DEBUG - 2011-08-06 14:30:45 --> Model Class Initialized
DEBUG - 2011-08-06 14:30:45 --> Model Class Initialized
DEBUG - 2011-08-06 14:30:45 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-06 14:30:45 --> Database Driver Class Initialized
DEBUG - 2011-08-06 14:30:46 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-06 14:30:46 --> Helper loaded: url_helper
DEBUG - 2011-08-06 14:30:46 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-06 14:30:46 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-06 14:30:46 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-06 14:30:46 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-06 14:30:46 --> Final output sent to browser
DEBUG - 2011-08-06 14:30:46 --> Total execution time: 1.0331
DEBUG - 2011-08-06 14:30:51 --> Config Class Initialized
DEBUG - 2011-08-06 14:30:51 --> Hooks Class Initialized
DEBUG - 2011-08-06 14:30:51 --> Utf8 Class Initialized
DEBUG - 2011-08-06 14:30:51 --> UTF-8 Support Enabled
DEBUG - 2011-08-06 14:30:51 --> URI Class Initialized
DEBUG - 2011-08-06 14:30:51 --> Router Class Initialized
DEBUG - 2011-08-06 14:30:51 --> Output Class Initialized
DEBUG - 2011-08-06 14:30:51 --> Input Class Initialized
DEBUG - 2011-08-06 14:30:51 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-06 14:30:51 --> Language Class Initialized
DEBUG - 2011-08-06 14:30:51 --> Loader Class Initialized
DEBUG - 2011-08-06 14:30:51 --> Controller Class Initialized
DEBUG - 2011-08-06 14:30:51 --> Model Class Initialized
DEBUG - 2011-08-06 14:30:51 --> Model Class Initialized
DEBUG - 2011-08-06 14:30:51 --> Model Class Initialized
DEBUG - 2011-08-06 14:30:51 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-06 14:30:51 --> Database Driver Class Initialized
DEBUG - 2011-08-06 14:30:52 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-06 14:30:52 --> Helper loaded: url_helper
DEBUG - 2011-08-06 14:30:52 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-06 14:30:52 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-06 14:30:52 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-06 14:30:52 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-06 14:30:52 --> Final output sent to browser
DEBUG - 2011-08-06 14:30:52 --> Total execution time: 0.3948
DEBUG - 2011-08-06 14:31:01 --> Config Class Initialized
DEBUG - 2011-08-06 14:31:01 --> Hooks Class Initialized
DEBUG - 2011-08-06 14:31:01 --> Utf8 Class Initialized
DEBUG - 2011-08-06 14:31:01 --> UTF-8 Support Enabled
DEBUG - 2011-08-06 14:31:01 --> URI Class Initialized
DEBUG - 2011-08-06 14:31:01 --> Router Class Initialized
DEBUG - 2011-08-06 14:31:01 --> Output Class Initialized
DEBUG - 2011-08-06 14:31:01 --> Input Class Initialized
DEBUG - 2011-08-06 14:31:01 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-06 14:31:01 --> Language Class Initialized
DEBUG - 2011-08-06 14:31:01 --> Loader Class Initialized
DEBUG - 2011-08-06 14:31:01 --> Controller Class Initialized
DEBUG - 2011-08-06 14:31:01 --> Model Class Initialized
DEBUG - 2011-08-06 14:31:01 --> Model Class Initialized
DEBUG - 2011-08-06 14:31:01 --> Model Class Initialized
DEBUG - 2011-08-06 14:31:01 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-06 14:31:01 --> Database Driver Class Initialized
DEBUG - 2011-08-06 14:31:01 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-06 14:31:01 --> Helper loaded: url_helper
DEBUG - 2011-08-06 14:31:01 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-06 14:31:01 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-06 14:31:01 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-06 14:31:01 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-06 14:31:01 --> Final output sent to browser
DEBUG - 2011-08-06 14:31:01 --> Total execution time: 0.0912
DEBUG - 2011-08-06 14:31:10 --> Config Class Initialized
DEBUG - 2011-08-06 14:31:10 --> Hooks Class Initialized
DEBUG - 2011-08-06 14:31:10 --> Utf8 Class Initialized
DEBUG - 2011-08-06 14:31:10 --> UTF-8 Support Enabled
DEBUG - 2011-08-06 14:31:10 --> URI Class Initialized
DEBUG - 2011-08-06 14:31:10 --> Router Class Initialized
DEBUG - 2011-08-06 14:31:10 --> Output Class Initialized
DEBUG - 2011-08-06 14:31:10 --> Input Class Initialized
DEBUG - 2011-08-06 14:31:10 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-06 14:31:10 --> Language Class Initialized
DEBUG - 2011-08-06 14:31:10 --> Loader Class Initialized
DEBUG - 2011-08-06 14:31:10 --> Controller Class Initialized
DEBUG - 2011-08-06 14:31:10 --> Model Class Initialized
DEBUG - 2011-08-06 14:31:10 --> Model Class Initialized
DEBUG - 2011-08-06 14:31:10 --> Model Class Initialized
DEBUG - 2011-08-06 14:31:10 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-06 14:31:10 --> Database Driver Class Initialized
DEBUG - 2011-08-06 14:31:10 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-06 14:31:10 --> Helper loaded: url_helper
DEBUG - 2011-08-06 14:31:10 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-06 14:31:10 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-06 14:31:10 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-06 14:31:10 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-06 14:31:10 --> Final output sent to browser
DEBUG - 2011-08-06 14:31:10 --> Total execution time: 0.0469
DEBUG - 2011-08-06 14:31:11 --> Config Class Initialized
DEBUG - 2011-08-06 14:31:11 --> Hooks Class Initialized
DEBUG - 2011-08-06 14:31:11 --> Utf8 Class Initialized
DEBUG - 2011-08-06 14:31:11 --> UTF-8 Support Enabled
DEBUG - 2011-08-06 14:31:11 --> URI Class Initialized
DEBUG - 2011-08-06 14:31:11 --> Router Class Initialized
DEBUG - 2011-08-06 14:31:11 --> Output Class Initialized
DEBUG - 2011-08-06 14:31:11 --> Input Class Initialized
DEBUG - 2011-08-06 14:31:11 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-06 14:31:11 --> Language Class Initialized
DEBUG - 2011-08-06 14:31:11 --> Loader Class Initialized
DEBUG - 2011-08-06 14:31:11 --> Controller Class Initialized
DEBUG - 2011-08-06 14:31:11 --> Model Class Initialized
DEBUG - 2011-08-06 14:31:11 --> Model Class Initialized
DEBUG - 2011-08-06 14:31:11 --> Model Class Initialized
DEBUG - 2011-08-06 14:31:11 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-06 14:31:11 --> Database Driver Class Initialized
DEBUG - 2011-08-06 14:31:11 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-06 14:31:11 --> Helper loaded: url_helper
DEBUG - 2011-08-06 14:31:11 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-06 14:31:11 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-06 14:31:11 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-06 14:31:11 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-06 14:31:11 --> Final output sent to browser
DEBUG - 2011-08-06 14:31:11 --> Total execution time: 0.0461
DEBUG - 2011-08-06 14:31:14 --> Config Class Initialized
DEBUG - 2011-08-06 14:31:14 --> Hooks Class Initialized
DEBUG - 2011-08-06 14:31:14 --> Utf8 Class Initialized
DEBUG - 2011-08-06 14:31:14 --> UTF-8 Support Enabled
DEBUG - 2011-08-06 14:31:14 --> URI Class Initialized
DEBUG - 2011-08-06 14:31:14 --> Router Class Initialized
DEBUG - 2011-08-06 14:31:14 --> Output Class Initialized
DEBUG - 2011-08-06 14:31:14 --> Input Class Initialized
DEBUG - 2011-08-06 14:31:14 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-06 14:31:14 --> Language Class Initialized
DEBUG - 2011-08-06 14:31:14 --> Loader Class Initialized
DEBUG - 2011-08-06 14:31:14 --> Controller Class Initialized
DEBUG - 2011-08-06 14:31:14 --> Model Class Initialized
DEBUG - 2011-08-06 14:31:14 --> Model Class Initialized
DEBUG - 2011-08-06 14:31:14 --> Model Class Initialized
DEBUG - 2011-08-06 14:31:14 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-06 14:31:14 --> Database Driver Class Initialized
DEBUG - 2011-08-06 14:31:14 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-06 14:31:14 --> Helper loaded: url_helper
DEBUG - 2011-08-06 14:31:14 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-06 14:31:14 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-06 14:31:14 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-06 14:31:14 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-06 14:31:14 --> Final output sent to browser
DEBUG - 2011-08-06 14:31:14 --> Total execution time: 0.0440
DEBUG - 2011-08-06 14:31:15 --> Config Class Initialized
DEBUG - 2011-08-06 14:31:15 --> Hooks Class Initialized
DEBUG - 2011-08-06 14:31:15 --> Utf8 Class Initialized
DEBUG - 2011-08-06 14:31:15 --> UTF-8 Support Enabled
DEBUG - 2011-08-06 14:31:15 --> URI Class Initialized
DEBUG - 2011-08-06 14:31:15 --> Router Class Initialized
DEBUG - 2011-08-06 14:31:15 --> Output Class Initialized
DEBUG - 2011-08-06 14:31:15 --> Input Class Initialized
DEBUG - 2011-08-06 14:31:15 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-06 14:31:15 --> Language Class Initialized
DEBUG - 2011-08-06 14:31:15 --> Loader Class Initialized
DEBUG - 2011-08-06 14:31:15 --> Controller Class Initialized
DEBUG - 2011-08-06 14:31:15 --> Model Class Initialized
DEBUG - 2011-08-06 14:31:15 --> Model Class Initialized
DEBUG - 2011-08-06 14:31:15 --> Model Class Initialized
DEBUG - 2011-08-06 14:31:15 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-06 14:31:15 --> Database Driver Class Initialized
DEBUG - 2011-08-06 14:31:15 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-06 14:31:15 --> Helper loaded: url_helper
DEBUG - 2011-08-06 14:31:15 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-06 14:31:15 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-06 14:31:15 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-06 14:31:15 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-06 14:31:15 --> Final output sent to browser
DEBUG - 2011-08-06 14:31:15 --> Total execution time: 0.0580
DEBUG - 2011-08-06 14:48:25 --> Config Class Initialized
DEBUG - 2011-08-06 14:48:25 --> Hooks Class Initialized
DEBUG - 2011-08-06 14:48:25 --> Utf8 Class Initialized
DEBUG - 2011-08-06 14:48:25 --> UTF-8 Support Enabled
DEBUG - 2011-08-06 14:48:25 --> URI Class Initialized
DEBUG - 2011-08-06 14:48:25 --> Router Class Initialized
DEBUG - 2011-08-06 14:48:25 --> Output Class Initialized
DEBUG - 2011-08-06 14:48:25 --> Input Class Initialized
DEBUG - 2011-08-06 14:48:25 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-06 14:48:25 --> Language Class Initialized
DEBUG - 2011-08-06 14:48:25 --> Loader Class Initialized
DEBUG - 2011-08-06 14:48:25 --> Controller Class Initialized
ERROR - 2011-08-06 14:48:25 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-06 14:48:25 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-06 14:48:25 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-06 14:48:25 --> Model Class Initialized
DEBUG - 2011-08-06 14:48:25 --> Model Class Initialized
DEBUG - 2011-08-06 14:48:25 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-06 14:48:25 --> Database Driver Class Initialized
DEBUG - 2011-08-06 14:48:25 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-06 14:48:25 --> Helper loaded: url_helper
DEBUG - 2011-08-06 14:48:25 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-06 14:48:25 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-06 14:48:25 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-06 14:48:25 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-06 14:48:25 --> Final output sent to browser
DEBUG - 2011-08-06 14:48:25 --> Total execution time: 0.0360
DEBUG - 2011-08-06 14:48:26 --> Config Class Initialized
DEBUG - 2011-08-06 14:48:26 --> Hooks Class Initialized
DEBUG - 2011-08-06 14:48:26 --> Utf8 Class Initialized
DEBUG - 2011-08-06 14:48:26 --> UTF-8 Support Enabled
DEBUG - 2011-08-06 14:48:26 --> URI Class Initialized
DEBUG - 2011-08-06 14:48:26 --> Router Class Initialized
DEBUG - 2011-08-06 14:48:26 --> Output Class Initialized
DEBUG - 2011-08-06 14:48:26 --> Input Class Initialized
DEBUG - 2011-08-06 14:48:26 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-06 14:48:26 --> Language Class Initialized
DEBUG - 2011-08-06 14:48:26 --> Loader Class Initialized
DEBUG - 2011-08-06 14:48:26 --> Controller Class Initialized
DEBUG - 2011-08-06 14:48:26 --> Model Class Initialized
DEBUG - 2011-08-06 14:48:26 --> Model Class Initialized
DEBUG - 2011-08-06 14:48:26 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-06 14:48:26 --> Database Driver Class Initialized
DEBUG - 2011-08-06 14:48:27 --> Final output sent to browser
DEBUG - 2011-08-06 14:48:27 --> Total execution time: 0.6628
DEBUG - 2011-08-06 14:48:28 --> Config Class Initialized
DEBUG - 2011-08-06 14:48:28 --> Hooks Class Initialized
DEBUG - 2011-08-06 14:48:28 --> Utf8 Class Initialized
DEBUG - 2011-08-06 14:48:28 --> UTF-8 Support Enabled
DEBUG - 2011-08-06 14:48:28 --> URI Class Initialized
DEBUG - 2011-08-06 14:48:28 --> Router Class Initialized
ERROR - 2011-08-06 14:48:28 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-06 14:48:34 --> Config Class Initialized
DEBUG - 2011-08-06 14:48:34 --> Hooks Class Initialized
DEBUG - 2011-08-06 14:48:34 --> Utf8 Class Initialized
DEBUG - 2011-08-06 14:48:34 --> UTF-8 Support Enabled
DEBUG - 2011-08-06 14:48:34 --> URI Class Initialized
DEBUG - 2011-08-06 14:48:34 --> Router Class Initialized
DEBUG - 2011-08-06 14:48:34 --> Output Class Initialized
DEBUG - 2011-08-06 14:48:34 --> Input Class Initialized
DEBUG - 2011-08-06 14:48:34 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-06 14:48:34 --> Language Class Initialized
DEBUG - 2011-08-06 14:48:34 --> Loader Class Initialized
DEBUG - 2011-08-06 14:48:34 --> Controller Class Initialized
ERROR - 2011-08-06 14:48:34 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-06 14:48:34 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-06 14:48:34 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-06 14:48:34 --> Model Class Initialized
DEBUG - 2011-08-06 14:48:34 --> Model Class Initialized
DEBUG - 2011-08-06 14:48:34 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-06 14:48:34 --> Database Driver Class Initialized
DEBUG - 2011-08-06 14:48:34 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-06 14:48:34 --> Helper loaded: url_helper
DEBUG - 2011-08-06 14:48:34 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-06 14:48:34 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-06 14:48:34 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-06 14:48:34 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-06 14:48:34 --> Final output sent to browser
DEBUG - 2011-08-06 14:48:34 --> Total execution time: 0.0281
DEBUG - 2011-08-06 14:48:35 --> Config Class Initialized
DEBUG - 2011-08-06 14:48:35 --> Hooks Class Initialized
DEBUG - 2011-08-06 14:48:35 --> Utf8 Class Initialized
DEBUG - 2011-08-06 14:48:35 --> UTF-8 Support Enabled
DEBUG - 2011-08-06 14:48:35 --> URI Class Initialized
DEBUG - 2011-08-06 14:48:35 --> Router Class Initialized
DEBUG - 2011-08-06 14:48:35 --> Output Class Initialized
DEBUG - 2011-08-06 14:48:35 --> Input Class Initialized
DEBUG - 2011-08-06 14:48:35 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-06 14:48:35 --> Language Class Initialized
DEBUG - 2011-08-06 14:48:35 --> Loader Class Initialized
DEBUG - 2011-08-06 14:48:35 --> Controller Class Initialized
DEBUG - 2011-08-06 14:48:35 --> Model Class Initialized
DEBUG - 2011-08-06 14:48:35 --> Model Class Initialized
DEBUG - 2011-08-06 14:48:35 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-06 14:48:35 --> Database Driver Class Initialized
DEBUG - 2011-08-06 14:48:36 --> Config Class Initialized
DEBUG - 2011-08-06 14:48:36 --> Hooks Class Initialized
DEBUG - 2011-08-06 14:48:36 --> Utf8 Class Initialized
DEBUG - 2011-08-06 14:48:36 --> UTF-8 Support Enabled
DEBUG - 2011-08-06 14:48:36 --> URI Class Initialized
DEBUG - 2011-08-06 14:48:36 --> Router Class Initialized
DEBUG - 2011-08-06 14:48:36 --> Output Class Initialized
DEBUG - 2011-08-06 14:48:36 --> Input Class Initialized
DEBUG - 2011-08-06 14:48:36 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-06 14:48:36 --> Language Class Initialized
DEBUG - 2011-08-06 14:48:36 --> Loader Class Initialized
DEBUG - 2011-08-06 14:48:36 --> Controller Class Initialized
ERROR - 2011-08-06 14:48:36 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-06 14:48:36 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-06 14:48:36 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-06 14:48:36 --> Model Class Initialized
DEBUG - 2011-08-06 14:48:36 --> Model Class Initialized
DEBUG - 2011-08-06 14:48:36 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-06 14:48:36 --> Database Driver Class Initialized
DEBUG - 2011-08-06 14:48:36 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-06 14:48:36 --> Helper loaded: url_helper
DEBUG - 2011-08-06 14:48:36 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-06 14:48:36 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-06 14:48:36 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-06 14:48:36 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-06 14:48:36 --> Final output sent to browser
DEBUG - 2011-08-06 14:48:36 --> Total execution time: 0.0318
DEBUG - 2011-08-06 14:48:36 --> Final output sent to browser
DEBUG - 2011-08-06 14:48:36 --> Total execution time: 0.9770
DEBUG - 2011-08-06 14:49:59 --> Config Class Initialized
DEBUG - 2011-08-06 14:49:59 --> Hooks Class Initialized
DEBUG - 2011-08-06 14:49:59 --> Utf8 Class Initialized
DEBUG - 2011-08-06 14:49:59 --> UTF-8 Support Enabled
DEBUG - 2011-08-06 14:49:59 --> URI Class Initialized
DEBUG - 2011-08-06 14:49:59 --> Router Class Initialized
DEBUG - 2011-08-06 14:49:59 --> Output Class Initialized
DEBUG - 2011-08-06 14:49:59 --> Input Class Initialized
DEBUG - 2011-08-06 14:49:59 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-06 14:49:59 --> Language Class Initialized
DEBUG - 2011-08-06 14:49:59 --> Loader Class Initialized
DEBUG - 2011-08-06 14:49:59 --> Controller Class Initialized
DEBUG - 2011-08-06 14:49:59 --> Model Class Initialized
DEBUG - 2011-08-06 14:49:59 --> Model Class Initialized
DEBUG - 2011-08-06 14:49:59 --> Model Class Initialized
DEBUG - 2011-08-06 14:49:59 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-06 14:49:59 --> Database Driver Class Initialized
DEBUG - 2011-08-06 14:49:59 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-06 14:49:59 --> Helper loaded: url_helper
DEBUG - 2011-08-06 14:49:59 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-06 14:49:59 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-06 14:49:59 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-06 14:49:59 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-06 14:49:59 --> Final output sent to browser
DEBUG - 2011-08-06 14:49:59 --> Total execution time: 0.1060
DEBUG - 2011-08-06 14:50:02 --> Config Class Initialized
DEBUG - 2011-08-06 14:50:02 --> Hooks Class Initialized
DEBUG - 2011-08-06 14:50:02 --> Utf8 Class Initialized
DEBUG - 2011-08-06 14:50:02 --> UTF-8 Support Enabled
DEBUG - 2011-08-06 14:50:02 --> URI Class Initialized
DEBUG - 2011-08-06 14:50:02 --> Router Class Initialized
ERROR - 2011-08-06 14:50:02 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-06 14:50:25 --> Config Class Initialized
DEBUG - 2011-08-06 14:50:25 --> Hooks Class Initialized
DEBUG - 2011-08-06 14:50:25 --> Utf8 Class Initialized
DEBUG - 2011-08-06 14:50:25 --> UTF-8 Support Enabled
DEBUG - 2011-08-06 14:50:25 --> URI Class Initialized
DEBUG - 2011-08-06 14:50:25 --> Router Class Initialized
DEBUG - 2011-08-06 14:50:25 --> Output Class Initialized
DEBUG - 2011-08-06 14:50:25 --> Input Class Initialized
DEBUG - 2011-08-06 14:50:25 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-06 14:50:25 --> Language Class Initialized
DEBUG - 2011-08-06 14:50:25 --> Loader Class Initialized
DEBUG - 2011-08-06 14:50:25 --> Controller Class Initialized
DEBUG - 2011-08-06 14:50:25 --> Model Class Initialized
DEBUG - 2011-08-06 14:50:25 --> Model Class Initialized
DEBUG - 2011-08-06 14:50:25 --> Model Class Initialized
DEBUG - 2011-08-06 14:50:25 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-06 14:50:25 --> Database Driver Class Initialized
DEBUG - 2011-08-06 14:50:26 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-06 14:50:26 --> Helper loaded: url_helper
DEBUG - 2011-08-06 14:50:26 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-06 14:50:26 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-06 14:50:26 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-06 14:50:26 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-06 14:50:26 --> Final output sent to browser
DEBUG - 2011-08-06 14:50:26 --> Total execution time: 0.2034
DEBUG - 2011-08-06 14:50:27 --> Config Class Initialized
DEBUG - 2011-08-06 14:50:27 --> Hooks Class Initialized
DEBUG - 2011-08-06 14:50:27 --> Utf8 Class Initialized
DEBUG - 2011-08-06 14:50:27 --> UTF-8 Support Enabled
DEBUG - 2011-08-06 14:50:27 --> URI Class Initialized
DEBUG - 2011-08-06 14:50:27 --> Router Class Initialized
DEBUG - 2011-08-06 14:50:27 --> Output Class Initialized
DEBUG - 2011-08-06 14:50:27 --> Input Class Initialized
DEBUG - 2011-08-06 14:50:27 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-06 14:50:27 --> Language Class Initialized
DEBUG - 2011-08-06 14:50:27 --> Loader Class Initialized
DEBUG - 2011-08-06 14:50:27 --> Controller Class Initialized
DEBUG - 2011-08-06 14:50:27 --> Model Class Initialized
DEBUG - 2011-08-06 14:50:27 --> Model Class Initialized
DEBUG - 2011-08-06 14:50:27 --> Model Class Initialized
DEBUG - 2011-08-06 14:50:27 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-06 14:50:27 --> Database Driver Class Initialized
DEBUG - 2011-08-06 14:50:27 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-06 14:50:27 --> Helper loaded: url_helper
DEBUG - 2011-08-06 14:50:27 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-06 14:50:27 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-06 14:50:27 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-06 14:50:27 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-06 14:50:27 --> Final output sent to browser
DEBUG - 2011-08-06 14:50:27 --> Total execution time: 0.0821
DEBUG - 2011-08-06 14:50:37 --> Config Class Initialized
DEBUG - 2011-08-06 14:50:37 --> Hooks Class Initialized
DEBUG - 2011-08-06 14:50:37 --> Utf8 Class Initialized
DEBUG - 2011-08-06 14:50:37 --> UTF-8 Support Enabled
DEBUG - 2011-08-06 14:50:37 --> URI Class Initialized
DEBUG - 2011-08-06 14:50:37 --> Router Class Initialized
DEBUG - 2011-08-06 14:50:37 --> Output Class Initialized
DEBUG - 2011-08-06 14:50:37 --> Input Class Initialized
DEBUG - 2011-08-06 14:50:37 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-06 14:50:37 --> Language Class Initialized
DEBUG - 2011-08-06 14:50:37 --> Loader Class Initialized
DEBUG - 2011-08-06 14:50:37 --> Controller Class Initialized
DEBUG - 2011-08-06 14:50:37 --> Model Class Initialized
DEBUG - 2011-08-06 14:50:37 --> Model Class Initialized
DEBUG - 2011-08-06 14:50:37 --> Model Class Initialized
DEBUG - 2011-08-06 14:50:37 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-06 14:50:37 --> Database Driver Class Initialized
DEBUG - 2011-08-06 14:50:37 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-06 14:50:37 --> Helper loaded: url_helper
DEBUG - 2011-08-06 14:50:37 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-06 14:50:37 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-06 14:50:37 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-06 14:50:37 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-06 14:50:37 --> Final output sent to browser
DEBUG - 2011-08-06 14:50:37 --> Total execution time: 0.2104
DEBUG - 2011-08-06 14:50:39 --> Config Class Initialized
DEBUG - 2011-08-06 14:50:39 --> Hooks Class Initialized
DEBUG - 2011-08-06 14:50:39 --> Utf8 Class Initialized
DEBUG - 2011-08-06 14:50:39 --> UTF-8 Support Enabled
DEBUG - 2011-08-06 14:50:39 --> URI Class Initialized
DEBUG - 2011-08-06 14:50:39 --> Router Class Initialized
DEBUG - 2011-08-06 14:50:39 --> Output Class Initialized
DEBUG - 2011-08-06 14:50:39 --> Input Class Initialized
DEBUG - 2011-08-06 14:50:39 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-06 14:50:39 --> Language Class Initialized
DEBUG - 2011-08-06 14:50:39 --> Loader Class Initialized
DEBUG - 2011-08-06 14:50:39 --> Controller Class Initialized
DEBUG - 2011-08-06 14:50:39 --> Model Class Initialized
DEBUG - 2011-08-06 14:50:39 --> Model Class Initialized
DEBUG - 2011-08-06 14:50:39 --> Model Class Initialized
DEBUG - 2011-08-06 14:50:39 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-06 14:50:39 --> Database Driver Class Initialized
DEBUG - 2011-08-06 14:50:39 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-06 14:50:39 --> Helper loaded: url_helper
DEBUG - 2011-08-06 14:50:39 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-06 14:50:39 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-06 14:50:39 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-06 14:50:39 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-06 14:50:39 --> Final output sent to browser
DEBUG - 2011-08-06 14:50:39 --> Total execution time: 0.0617
DEBUG - 2011-08-06 14:50:48 --> Config Class Initialized
DEBUG - 2011-08-06 14:50:48 --> Hooks Class Initialized
DEBUG - 2011-08-06 14:50:48 --> Utf8 Class Initialized
DEBUG - 2011-08-06 14:50:48 --> UTF-8 Support Enabled
DEBUG - 2011-08-06 14:50:48 --> URI Class Initialized
DEBUG - 2011-08-06 14:50:48 --> Router Class Initialized
DEBUG - 2011-08-06 14:50:48 --> Output Class Initialized
DEBUG - 2011-08-06 14:50:48 --> Input Class Initialized
DEBUG - 2011-08-06 14:50:48 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-06 14:50:48 --> Language Class Initialized
DEBUG - 2011-08-06 14:50:48 --> Loader Class Initialized
DEBUG - 2011-08-06 14:50:48 --> Controller Class Initialized
DEBUG - 2011-08-06 14:50:48 --> Model Class Initialized
DEBUG - 2011-08-06 14:50:48 --> Model Class Initialized
DEBUG - 2011-08-06 14:50:48 --> Model Class Initialized
DEBUG - 2011-08-06 14:50:48 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-06 14:50:48 --> Database Driver Class Initialized
DEBUG - 2011-08-06 14:50:48 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-06 14:50:48 --> Helper loaded: url_helper
DEBUG - 2011-08-06 14:50:48 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-06 14:50:48 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-06 14:50:48 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-06 14:50:48 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-06 14:50:48 --> Final output sent to browser
DEBUG - 2011-08-06 14:50:48 --> Total execution time: 0.2438
DEBUG - 2011-08-06 14:50:49 --> Config Class Initialized
DEBUG - 2011-08-06 14:50:49 --> Hooks Class Initialized
DEBUG - 2011-08-06 14:50:49 --> Utf8 Class Initialized
DEBUG - 2011-08-06 14:50:49 --> UTF-8 Support Enabled
DEBUG - 2011-08-06 14:50:49 --> URI Class Initialized
DEBUG - 2011-08-06 14:50:49 --> Router Class Initialized
DEBUG - 2011-08-06 14:50:49 --> Output Class Initialized
DEBUG - 2011-08-06 14:50:49 --> Input Class Initialized
DEBUG - 2011-08-06 14:50:49 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-06 14:50:49 --> Language Class Initialized
DEBUG - 2011-08-06 14:50:49 --> Loader Class Initialized
DEBUG - 2011-08-06 14:50:49 --> Controller Class Initialized
DEBUG - 2011-08-06 14:50:49 --> Model Class Initialized
DEBUG - 2011-08-06 14:50:49 --> Model Class Initialized
DEBUG - 2011-08-06 14:50:49 --> Model Class Initialized
DEBUG - 2011-08-06 14:50:49 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-06 14:50:49 --> Database Driver Class Initialized
DEBUG - 2011-08-06 14:50:49 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-06 14:50:49 --> Helper loaded: url_helper
DEBUG - 2011-08-06 14:50:49 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-06 14:50:49 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-06 14:50:49 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-06 14:50:49 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-06 14:50:49 --> Final output sent to browser
DEBUG - 2011-08-06 14:50:49 --> Total execution time: 0.0475
DEBUG - 2011-08-06 14:50:49 --> Config Class Initialized
DEBUG - 2011-08-06 14:50:49 --> Hooks Class Initialized
DEBUG - 2011-08-06 14:50:49 --> Utf8 Class Initialized
DEBUG - 2011-08-06 14:50:49 --> UTF-8 Support Enabled
DEBUG - 2011-08-06 14:50:49 --> URI Class Initialized
DEBUG - 2011-08-06 14:50:49 --> Router Class Initialized
DEBUG - 2011-08-06 14:50:49 --> Output Class Initialized
DEBUG - 2011-08-06 14:50:49 --> Input Class Initialized
DEBUG - 2011-08-06 14:50:49 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-06 14:50:49 --> Language Class Initialized
DEBUG - 2011-08-06 14:50:49 --> Loader Class Initialized
DEBUG - 2011-08-06 14:50:49 --> Controller Class Initialized
DEBUG - 2011-08-06 14:50:49 --> Model Class Initialized
DEBUG - 2011-08-06 14:50:49 --> Model Class Initialized
DEBUG - 2011-08-06 14:50:49 --> Model Class Initialized
DEBUG - 2011-08-06 14:50:49 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-06 14:50:49 --> Database Driver Class Initialized
DEBUG - 2011-08-06 14:50:49 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-06 14:50:49 --> Helper loaded: url_helper
DEBUG - 2011-08-06 14:50:49 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-06 14:50:49 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-06 14:50:49 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-06 14:50:49 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-06 14:50:49 --> Final output sent to browser
DEBUG - 2011-08-06 14:50:49 --> Total execution time: 0.0452
DEBUG - 2011-08-06 14:51:00 --> Config Class Initialized
DEBUG - 2011-08-06 14:51:00 --> Hooks Class Initialized
DEBUG - 2011-08-06 14:51:00 --> Utf8 Class Initialized
DEBUG - 2011-08-06 14:51:00 --> UTF-8 Support Enabled
DEBUG - 2011-08-06 14:51:00 --> URI Class Initialized
DEBUG - 2011-08-06 14:51:00 --> Router Class Initialized
DEBUG - 2011-08-06 14:51:00 --> Output Class Initialized
DEBUG - 2011-08-06 14:51:00 --> Input Class Initialized
DEBUG - 2011-08-06 14:51:00 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-06 14:51:00 --> Language Class Initialized
DEBUG - 2011-08-06 14:51:00 --> Loader Class Initialized
DEBUG - 2011-08-06 14:51:00 --> Controller Class Initialized
DEBUG - 2011-08-06 14:51:00 --> Model Class Initialized
DEBUG - 2011-08-06 14:51:00 --> Model Class Initialized
DEBUG - 2011-08-06 14:51:00 --> Model Class Initialized
DEBUG - 2011-08-06 14:51:00 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-06 14:51:00 --> Database Driver Class Initialized
DEBUG - 2011-08-06 14:51:00 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-06 14:51:00 --> Helper loaded: url_helper
DEBUG - 2011-08-06 14:51:00 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-06 14:51:00 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-06 14:51:00 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-06 14:51:00 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-06 14:51:00 --> Final output sent to browser
DEBUG - 2011-08-06 14:51:00 --> Total execution time: 0.1900
DEBUG - 2011-08-06 14:51:02 --> Config Class Initialized
DEBUG - 2011-08-06 14:51:02 --> Hooks Class Initialized
DEBUG - 2011-08-06 14:51:02 --> Utf8 Class Initialized
DEBUG - 2011-08-06 14:51:02 --> UTF-8 Support Enabled
DEBUG - 2011-08-06 14:51:02 --> URI Class Initialized
DEBUG - 2011-08-06 14:51:02 --> Router Class Initialized
DEBUG - 2011-08-06 14:51:02 --> Output Class Initialized
DEBUG - 2011-08-06 14:51:02 --> Input Class Initialized
DEBUG - 2011-08-06 14:51:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-06 14:51:02 --> Language Class Initialized
DEBUG - 2011-08-06 14:51:02 --> Loader Class Initialized
DEBUG - 2011-08-06 14:51:02 --> Controller Class Initialized
DEBUG - 2011-08-06 14:51:02 --> Model Class Initialized
DEBUG - 2011-08-06 14:51:02 --> Model Class Initialized
DEBUG - 2011-08-06 14:51:02 --> Model Class Initialized
DEBUG - 2011-08-06 14:51:02 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-06 14:51:02 --> Database Driver Class Initialized
DEBUG - 2011-08-06 14:51:02 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-06 14:51:02 --> Helper loaded: url_helper
DEBUG - 2011-08-06 14:51:02 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-06 14:51:02 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-06 14:51:02 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-06 14:51:02 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-06 14:51:02 --> Final output sent to browser
DEBUG - 2011-08-06 14:51:02 --> Total execution time: 0.1009
DEBUG - 2011-08-06 14:51:13 --> Config Class Initialized
DEBUG - 2011-08-06 14:51:13 --> Hooks Class Initialized
DEBUG - 2011-08-06 14:51:13 --> Utf8 Class Initialized
DEBUG - 2011-08-06 14:51:13 --> UTF-8 Support Enabled
DEBUG - 2011-08-06 14:51:13 --> URI Class Initialized
DEBUG - 2011-08-06 14:51:13 --> Router Class Initialized
DEBUG - 2011-08-06 14:51:13 --> Output Class Initialized
DEBUG - 2011-08-06 14:51:13 --> Input Class Initialized
DEBUG - 2011-08-06 14:51:13 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-06 14:51:13 --> Language Class Initialized
DEBUG - 2011-08-06 14:51:13 --> Loader Class Initialized
DEBUG - 2011-08-06 14:51:13 --> Controller Class Initialized
DEBUG - 2011-08-06 14:51:13 --> Model Class Initialized
DEBUG - 2011-08-06 14:51:13 --> Model Class Initialized
DEBUG - 2011-08-06 14:51:13 --> Model Class Initialized
DEBUG - 2011-08-06 14:51:13 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-06 14:51:13 --> Database Driver Class Initialized
DEBUG - 2011-08-06 14:51:13 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-06 14:51:13 --> Helper loaded: url_helper
DEBUG - 2011-08-06 14:51:13 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-06 14:51:13 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-06 14:51:13 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-06 14:51:13 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-06 14:51:13 --> Final output sent to browser
DEBUG - 2011-08-06 14:51:13 --> Total execution time: 0.2253
DEBUG - 2011-08-06 14:51:15 --> Config Class Initialized
DEBUG - 2011-08-06 14:51:15 --> Hooks Class Initialized
DEBUG - 2011-08-06 14:51:15 --> Utf8 Class Initialized
DEBUG - 2011-08-06 14:51:15 --> UTF-8 Support Enabled
DEBUG - 2011-08-06 14:51:15 --> URI Class Initialized
DEBUG - 2011-08-06 14:51:15 --> Router Class Initialized
DEBUG - 2011-08-06 14:51:15 --> Output Class Initialized
DEBUG - 2011-08-06 14:51:15 --> Input Class Initialized
DEBUG - 2011-08-06 14:51:15 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-06 14:51:15 --> Language Class Initialized
DEBUG - 2011-08-06 14:51:15 --> Loader Class Initialized
DEBUG - 2011-08-06 14:51:15 --> Controller Class Initialized
DEBUG - 2011-08-06 14:51:15 --> Model Class Initialized
DEBUG - 2011-08-06 14:51:15 --> Model Class Initialized
DEBUG - 2011-08-06 14:51:15 --> Model Class Initialized
DEBUG - 2011-08-06 14:51:15 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-06 14:51:15 --> Database Driver Class Initialized
DEBUG - 2011-08-06 14:51:15 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-06 14:51:15 --> Helper loaded: url_helper
DEBUG - 2011-08-06 14:51:15 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-06 14:51:15 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-06 14:51:15 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-06 14:51:15 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-06 14:51:15 --> Final output sent to browser
DEBUG - 2011-08-06 14:51:15 --> Total execution time: 0.0625
DEBUG - 2011-08-06 14:51:21 --> Config Class Initialized
DEBUG - 2011-08-06 14:51:21 --> Hooks Class Initialized
DEBUG - 2011-08-06 14:51:21 --> Utf8 Class Initialized
DEBUG - 2011-08-06 14:51:21 --> UTF-8 Support Enabled
DEBUG - 2011-08-06 14:51:21 --> URI Class Initialized
DEBUG - 2011-08-06 14:51:21 --> Router Class Initialized
DEBUG - 2011-08-06 14:51:21 --> Output Class Initialized
DEBUG - 2011-08-06 14:51:21 --> Input Class Initialized
DEBUG - 2011-08-06 14:51:21 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-06 14:51:21 --> Language Class Initialized
DEBUG - 2011-08-06 14:51:21 --> Loader Class Initialized
DEBUG - 2011-08-06 14:51:21 --> Controller Class Initialized
DEBUG - 2011-08-06 14:51:21 --> Model Class Initialized
DEBUG - 2011-08-06 14:51:21 --> Model Class Initialized
DEBUG - 2011-08-06 14:51:21 --> Model Class Initialized
DEBUG - 2011-08-06 14:51:21 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-06 14:51:21 --> Database Driver Class Initialized
DEBUG - 2011-08-06 14:51:21 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-06 14:51:21 --> Helper loaded: url_helper
DEBUG - 2011-08-06 14:51:21 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-06 14:51:21 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-06 14:51:21 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-06 14:51:21 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-06 14:51:21 --> Final output sent to browser
DEBUG - 2011-08-06 14:51:21 --> Total execution time: 0.3184
DEBUG - 2011-08-06 14:51:22 --> Config Class Initialized
DEBUG - 2011-08-06 14:51:22 --> Hooks Class Initialized
DEBUG - 2011-08-06 14:51:22 --> Utf8 Class Initialized
DEBUG - 2011-08-06 14:51:22 --> UTF-8 Support Enabled
DEBUG - 2011-08-06 14:51:22 --> URI Class Initialized
DEBUG - 2011-08-06 14:51:22 --> Router Class Initialized
DEBUG - 2011-08-06 14:51:22 --> Output Class Initialized
DEBUG - 2011-08-06 14:51:22 --> Input Class Initialized
DEBUG - 2011-08-06 14:51:22 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-06 14:51:22 --> Language Class Initialized
DEBUG - 2011-08-06 14:51:22 --> Loader Class Initialized
DEBUG - 2011-08-06 14:51:22 --> Controller Class Initialized
DEBUG - 2011-08-06 14:51:22 --> Model Class Initialized
DEBUG - 2011-08-06 14:51:22 --> Model Class Initialized
DEBUG - 2011-08-06 14:51:22 --> Model Class Initialized
DEBUG - 2011-08-06 14:51:22 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-06 14:51:22 --> Database Driver Class Initialized
DEBUG - 2011-08-06 14:51:23 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-06 14:51:23 --> Helper loaded: url_helper
DEBUG - 2011-08-06 14:51:23 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-06 14:51:23 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-06 14:51:23 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-06 14:51:23 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-06 14:51:23 --> Final output sent to browser
DEBUG - 2011-08-06 14:51:23 --> Total execution time: 0.0445
DEBUG - 2011-08-06 14:51:32 --> Config Class Initialized
DEBUG - 2011-08-06 14:51:32 --> Hooks Class Initialized
DEBUG - 2011-08-06 14:51:32 --> Utf8 Class Initialized
DEBUG - 2011-08-06 14:51:32 --> UTF-8 Support Enabled
DEBUG - 2011-08-06 14:51:32 --> URI Class Initialized
DEBUG - 2011-08-06 14:51:32 --> Router Class Initialized
DEBUG - 2011-08-06 14:51:32 --> Output Class Initialized
DEBUG - 2011-08-06 14:51:32 --> Input Class Initialized
DEBUG - 2011-08-06 14:51:32 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-06 14:51:32 --> Language Class Initialized
DEBUG - 2011-08-06 14:51:32 --> Loader Class Initialized
DEBUG - 2011-08-06 14:51:32 --> Controller Class Initialized
DEBUG - 2011-08-06 14:51:32 --> Model Class Initialized
DEBUG - 2011-08-06 14:51:32 --> Model Class Initialized
DEBUG - 2011-08-06 14:51:32 --> Model Class Initialized
DEBUG - 2011-08-06 14:51:32 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-06 14:51:32 --> Database Driver Class Initialized
DEBUG - 2011-08-06 14:51:32 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-06 14:51:32 --> Helper loaded: url_helper
DEBUG - 2011-08-06 14:51:32 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-06 14:51:32 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-06 14:51:32 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-06 14:51:32 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-06 14:51:32 --> Final output sent to browser
DEBUG - 2011-08-06 14:51:32 --> Total execution time: 0.2205
DEBUG - 2011-08-06 14:51:33 --> Config Class Initialized
DEBUG - 2011-08-06 14:51:33 --> Hooks Class Initialized
DEBUG - 2011-08-06 14:51:33 --> Utf8 Class Initialized
DEBUG - 2011-08-06 14:51:33 --> UTF-8 Support Enabled
DEBUG - 2011-08-06 14:51:33 --> URI Class Initialized
DEBUG - 2011-08-06 14:51:33 --> Router Class Initialized
DEBUG - 2011-08-06 14:51:33 --> Output Class Initialized
DEBUG - 2011-08-06 14:51:33 --> Input Class Initialized
DEBUG - 2011-08-06 14:51:33 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-06 14:51:33 --> Language Class Initialized
DEBUG - 2011-08-06 14:51:33 --> Loader Class Initialized
DEBUG - 2011-08-06 14:51:33 --> Controller Class Initialized
DEBUG - 2011-08-06 14:51:33 --> Model Class Initialized
DEBUG - 2011-08-06 14:51:33 --> Model Class Initialized
DEBUG - 2011-08-06 14:51:33 --> Model Class Initialized
DEBUG - 2011-08-06 14:51:33 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-06 14:51:33 --> Database Driver Class Initialized
DEBUG - 2011-08-06 14:51:33 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-06 14:51:33 --> Helper loaded: url_helper
DEBUG - 2011-08-06 14:51:33 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-06 14:51:33 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-06 14:51:33 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-06 14:51:33 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-06 14:51:33 --> Final output sent to browser
DEBUG - 2011-08-06 14:51:33 --> Total execution time: 0.0743
DEBUG - 2011-08-06 14:52:05 --> Config Class Initialized
DEBUG - 2011-08-06 14:52:05 --> Hooks Class Initialized
DEBUG - 2011-08-06 14:52:05 --> Utf8 Class Initialized
DEBUG - 2011-08-06 14:52:05 --> UTF-8 Support Enabled
DEBUG - 2011-08-06 14:52:05 --> URI Class Initialized
DEBUG - 2011-08-06 14:52:05 --> Router Class Initialized
DEBUG - 2011-08-06 14:52:05 --> Output Class Initialized
DEBUG - 2011-08-06 14:52:05 --> Input Class Initialized
DEBUG - 2011-08-06 14:52:05 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-06 14:52:05 --> Language Class Initialized
DEBUG - 2011-08-06 14:52:05 --> Loader Class Initialized
DEBUG - 2011-08-06 14:52:05 --> Controller Class Initialized
DEBUG - 2011-08-06 14:52:05 --> Model Class Initialized
DEBUG - 2011-08-06 14:52:05 --> Model Class Initialized
DEBUG - 2011-08-06 14:52:05 --> Model Class Initialized
DEBUG - 2011-08-06 14:52:05 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-06 14:52:05 --> Database Driver Class Initialized
DEBUG - 2011-08-06 14:52:06 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-06 14:52:06 --> Helper loaded: url_helper
DEBUG - 2011-08-06 14:52:06 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-06 14:52:06 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-06 14:52:06 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-06 14:52:06 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-06 14:52:06 --> Final output sent to browser
DEBUG - 2011-08-06 14:52:06 --> Total execution time: 0.6566
DEBUG - 2011-08-06 14:52:14 --> Config Class Initialized
DEBUG - 2011-08-06 14:52:14 --> Hooks Class Initialized
DEBUG - 2011-08-06 14:52:14 --> Utf8 Class Initialized
DEBUG - 2011-08-06 14:52:14 --> UTF-8 Support Enabled
DEBUG - 2011-08-06 14:52:14 --> URI Class Initialized
DEBUG - 2011-08-06 14:52:14 --> Router Class Initialized
DEBUG - 2011-08-06 14:52:14 --> Output Class Initialized
DEBUG - 2011-08-06 14:52:14 --> Input Class Initialized
DEBUG - 2011-08-06 14:52:14 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-06 14:52:14 --> Language Class Initialized
DEBUG - 2011-08-06 14:52:14 --> Loader Class Initialized
DEBUG - 2011-08-06 14:52:14 --> Controller Class Initialized
DEBUG - 2011-08-06 14:52:14 --> Model Class Initialized
DEBUG - 2011-08-06 14:52:14 --> Model Class Initialized
DEBUG - 2011-08-06 14:52:14 --> Model Class Initialized
DEBUG - 2011-08-06 14:52:14 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-06 14:52:14 --> Database Driver Class Initialized
DEBUG - 2011-08-06 14:52:14 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-06 14:52:14 --> Helper loaded: url_helper
DEBUG - 2011-08-06 14:52:14 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-06 14:52:14 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-06 14:52:14 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-06 14:52:14 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-06 14:52:14 --> Final output sent to browser
DEBUG - 2011-08-06 14:52:14 --> Total execution time: 0.0676
DEBUG - 2011-08-06 14:52:16 --> Config Class Initialized
DEBUG - 2011-08-06 14:52:16 --> Hooks Class Initialized
DEBUG - 2011-08-06 14:52:16 --> Utf8 Class Initialized
DEBUG - 2011-08-06 14:52:16 --> UTF-8 Support Enabled
DEBUG - 2011-08-06 14:52:16 --> URI Class Initialized
DEBUG - 2011-08-06 14:52:16 --> Router Class Initialized
DEBUG - 2011-08-06 14:52:16 --> Output Class Initialized
DEBUG - 2011-08-06 14:52:16 --> Input Class Initialized
DEBUG - 2011-08-06 14:52:16 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-06 14:52:16 --> Language Class Initialized
DEBUG - 2011-08-06 14:52:16 --> Loader Class Initialized
DEBUG - 2011-08-06 14:52:16 --> Controller Class Initialized
DEBUG - 2011-08-06 14:52:16 --> Model Class Initialized
DEBUG - 2011-08-06 14:52:16 --> Model Class Initialized
DEBUG - 2011-08-06 14:52:16 --> Model Class Initialized
DEBUG - 2011-08-06 14:52:16 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-06 14:52:16 --> Database Driver Class Initialized
DEBUG - 2011-08-06 14:52:16 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-06 14:52:16 --> Helper loaded: url_helper
DEBUG - 2011-08-06 14:52:16 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-06 14:52:16 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-06 14:52:16 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-06 14:52:16 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-06 14:52:16 --> Final output sent to browser
DEBUG - 2011-08-06 14:52:16 --> Total execution time: 0.0489
DEBUG - 2011-08-06 14:55:17 --> Config Class Initialized
DEBUG - 2011-08-06 14:55:17 --> Hooks Class Initialized
DEBUG - 2011-08-06 14:55:17 --> Utf8 Class Initialized
DEBUG - 2011-08-06 14:55:17 --> UTF-8 Support Enabled
DEBUG - 2011-08-06 14:55:17 --> URI Class Initialized
DEBUG - 2011-08-06 14:55:17 --> Router Class Initialized
DEBUG - 2011-08-06 14:55:17 --> Output Class Initialized
DEBUG - 2011-08-06 14:55:17 --> Input Class Initialized
DEBUG - 2011-08-06 14:55:17 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-06 14:55:17 --> Language Class Initialized
DEBUG - 2011-08-06 14:55:17 --> Loader Class Initialized
DEBUG - 2011-08-06 14:55:17 --> Controller Class Initialized
DEBUG - 2011-08-06 14:55:17 --> Model Class Initialized
DEBUG - 2011-08-06 14:55:17 --> Model Class Initialized
DEBUG - 2011-08-06 14:55:17 --> Model Class Initialized
DEBUG - 2011-08-06 14:55:17 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-06 14:55:17 --> Database Driver Class Initialized
DEBUG - 2011-08-06 14:55:17 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-06 14:55:17 --> Helper loaded: url_helper
DEBUG - 2011-08-06 14:55:17 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-06 14:55:17 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-06 14:55:17 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-06 14:55:17 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-06 14:55:17 --> Final output sent to browser
DEBUG - 2011-08-06 14:55:17 --> Total execution time: 0.0925
DEBUG - 2011-08-06 14:55:22 --> Config Class Initialized
DEBUG - 2011-08-06 14:55:22 --> Hooks Class Initialized
DEBUG - 2011-08-06 14:55:22 --> Utf8 Class Initialized
DEBUG - 2011-08-06 14:55:22 --> UTF-8 Support Enabled
DEBUG - 2011-08-06 14:55:22 --> URI Class Initialized
DEBUG - 2011-08-06 14:55:22 --> Router Class Initialized
ERROR - 2011-08-06 14:55:22 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-06 14:55:41 --> Config Class Initialized
DEBUG - 2011-08-06 14:55:41 --> Hooks Class Initialized
DEBUG - 2011-08-06 14:55:41 --> Utf8 Class Initialized
DEBUG - 2011-08-06 14:55:41 --> UTF-8 Support Enabled
DEBUG - 2011-08-06 14:55:41 --> URI Class Initialized
DEBUG - 2011-08-06 14:55:41 --> Router Class Initialized
DEBUG - 2011-08-06 14:55:41 --> Output Class Initialized
DEBUG - 2011-08-06 14:55:41 --> Input Class Initialized
DEBUG - 2011-08-06 14:55:41 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-06 14:55:41 --> Language Class Initialized
DEBUG - 2011-08-06 14:55:41 --> Loader Class Initialized
DEBUG - 2011-08-06 14:55:41 --> Controller Class Initialized
DEBUG - 2011-08-06 14:55:41 --> Model Class Initialized
DEBUG - 2011-08-06 14:55:41 --> Model Class Initialized
DEBUG - 2011-08-06 14:55:41 --> Model Class Initialized
DEBUG - 2011-08-06 14:55:41 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-06 14:55:41 --> Database Driver Class Initialized
DEBUG - 2011-08-06 14:55:42 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-06 14:55:42 --> Helper loaded: url_helper
DEBUG - 2011-08-06 14:55:42 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-06 14:55:42 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-06 14:55:42 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-06 14:55:42 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-06 14:55:42 --> Final output sent to browser
DEBUG - 2011-08-06 14:55:42 --> Total execution time: 0.7475
DEBUG - 2011-08-06 14:55:44 --> Config Class Initialized
DEBUG - 2011-08-06 14:55:44 --> Hooks Class Initialized
DEBUG - 2011-08-06 14:55:44 --> Utf8 Class Initialized
DEBUG - 2011-08-06 14:55:44 --> UTF-8 Support Enabled
DEBUG - 2011-08-06 14:55:44 --> URI Class Initialized
DEBUG - 2011-08-06 14:55:44 --> Router Class Initialized
DEBUG - 2011-08-06 14:55:44 --> Output Class Initialized
DEBUG - 2011-08-06 14:55:44 --> Input Class Initialized
DEBUG - 2011-08-06 14:55:44 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-06 14:55:44 --> Language Class Initialized
DEBUG - 2011-08-06 14:55:44 --> Loader Class Initialized
DEBUG - 2011-08-06 14:55:44 --> Controller Class Initialized
DEBUG - 2011-08-06 14:55:44 --> Model Class Initialized
DEBUG - 2011-08-06 14:55:44 --> Model Class Initialized
DEBUG - 2011-08-06 14:55:44 --> Model Class Initialized
DEBUG - 2011-08-06 14:55:44 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-06 14:55:44 --> Database Driver Class Initialized
DEBUG - 2011-08-06 14:55:44 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-06 14:55:44 --> Helper loaded: url_helper
DEBUG - 2011-08-06 14:55:44 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-06 14:55:44 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-06 14:55:44 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-06 14:55:44 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-06 14:55:44 --> Final output sent to browser
DEBUG - 2011-08-06 14:55:44 --> Total execution time: 0.0599
DEBUG - 2011-08-06 15:29:18 --> Config Class Initialized
DEBUG - 2011-08-06 15:29:18 --> Hooks Class Initialized
DEBUG - 2011-08-06 15:29:18 --> Utf8 Class Initialized
DEBUG - 2011-08-06 15:29:18 --> UTF-8 Support Enabled
DEBUG - 2011-08-06 15:29:18 --> URI Class Initialized
DEBUG - 2011-08-06 15:29:18 --> Router Class Initialized
DEBUG - 2011-08-06 15:29:18 --> No URI present. Default controller set.
DEBUG - 2011-08-06 15:29:18 --> Output Class Initialized
DEBUG - 2011-08-06 15:29:18 --> Input Class Initialized
DEBUG - 2011-08-06 15:29:18 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-06 15:29:18 --> Language Class Initialized
DEBUG - 2011-08-06 15:29:18 --> Loader Class Initialized
DEBUG - 2011-08-06 15:29:18 --> Controller Class Initialized
DEBUG - 2011-08-06 15:29:18 --> File loaded: application/views/splash/main.php
DEBUG - 2011-08-06 15:29:18 --> Helper loaded: url_helper
DEBUG - 2011-08-06 15:29:18 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-06 15:29:18 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-06 15:29:18 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-06 15:29:18 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-06 15:29:18 --> Final output sent to browser
DEBUG - 2011-08-06 15:29:18 --> Total execution time: 0.0664
DEBUG - 2011-08-06 15:29:20 --> Config Class Initialized
DEBUG - 2011-08-06 15:29:20 --> Hooks Class Initialized
DEBUG - 2011-08-06 15:29:20 --> Utf8 Class Initialized
DEBUG - 2011-08-06 15:29:20 --> UTF-8 Support Enabled
DEBUG - 2011-08-06 15:29:20 --> URI Class Initialized
DEBUG - 2011-08-06 15:29:20 --> Router Class Initialized
ERROR - 2011-08-06 15:29:20 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-06 15:29:26 --> Config Class Initialized
DEBUG - 2011-08-06 15:29:26 --> Hooks Class Initialized
DEBUG - 2011-08-06 15:29:26 --> Utf8 Class Initialized
DEBUG - 2011-08-06 15:29:26 --> UTF-8 Support Enabled
DEBUG - 2011-08-06 15:29:26 --> URI Class Initialized
DEBUG - 2011-08-06 15:29:26 --> Router Class Initialized
DEBUG - 2011-08-06 15:29:26 --> Output Class Initialized
DEBUG - 2011-08-06 15:29:26 --> Input Class Initialized
DEBUG - 2011-08-06 15:29:26 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-06 15:29:26 --> Language Class Initialized
DEBUG - 2011-08-06 15:29:26 --> Loader Class Initialized
DEBUG - 2011-08-06 15:29:26 --> Controller Class Initialized
DEBUG - 2011-08-06 15:29:26 --> Model Class Initialized
DEBUG - 2011-08-06 15:29:26 --> Model Class Initialized
DEBUG - 2011-08-06 15:29:26 --> Model Class Initialized
DEBUG - 2011-08-06 15:29:26 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-06 15:29:26 --> Database Driver Class Initialized
DEBUG - 2011-08-06 15:29:26 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-06 15:29:26 --> Helper loaded: url_helper
DEBUG - 2011-08-06 15:29:26 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-06 15:29:26 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-06 15:29:26 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-06 15:29:26 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-06 15:29:26 --> Final output sent to browser
DEBUG - 2011-08-06 15:29:26 --> Total execution time: 0.2936
DEBUG - 2011-08-06 15:29:27 --> Config Class Initialized
DEBUG - 2011-08-06 15:29:27 --> Hooks Class Initialized
DEBUG - 2011-08-06 15:29:27 --> Utf8 Class Initialized
DEBUG - 2011-08-06 15:29:27 --> UTF-8 Support Enabled
DEBUG - 2011-08-06 15:29:27 --> URI Class Initialized
DEBUG - 2011-08-06 15:29:27 --> Router Class Initialized
ERROR - 2011-08-06 15:29:27 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-06 15:29:45 --> Config Class Initialized
DEBUG - 2011-08-06 15:29:45 --> Hooks Class Initialized
DEBUG - 2011-08-06 15:29:45 --> Utf8 Class Initialized
DEBUG - 2011-08-06 15:29:45 --> UTF-8 Support Enabled
DEBUG - 2011-08-06 15:29:45 --> URI Class Initialized
DEBUG - 2011-08-06 15:29:45 --> Router Class Initialized
DEBUG - 2011-08-06 15:29:45 --> Output Class Initialized
DEBUG - 2011-08-06 15:29:45 --> Input Class Initialized
DEBUG - 2011-08-06 15:29:45 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-06 15:29:45 --> Language Class Initialized
DEBUG - 2011-08-06 15:29:45 --> Loader Class Initialized
DEBUG - 2011-08-06 15:29:45 --> Controller Class Initialized
DEBUG - 2011-08-06 15:29:45 --> Model Class Initialized
DEBUG - 2011-08-06 15:29:45 --> Model Class Initialized
DEBUG - 2011-08-06 15:29:45 --> Model Class Initialized
DEBUG - 2011-08-06 15:29:45 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-06 15:29:45 --> Database Driver Class Initialized
DEBUG - 2011-08-06 15:29:45 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-06 15:29:45 --> Helper loaded: url_helper
DEBUG - 2011-08-06 15:29:45 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-06 15:29:45 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-06 15:29:45 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-06 15:29:45 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-06 15:29:45 --> Final output sent to browser
DEBUG - 2011-08-06 15:29:45 --> Total execution time: 0.2589
DEBUG - 2011-08-06 15:29:46 --> Config Class Initialized
DEBUG - 2011-08-06 15:29:46 --> Hooks Class Initialized
DEBUG - 2011-08-06 15:29:46 --> Utf8 Class Initialized
DEBUG - 2011-08-06 15:29:46 --> UTF-8 Support Enabled
DEBUG - 2011-08-06 15:29:46 --> URI Class Initialized
DEBUG - 2011-08-06 15:29:46 --> Router Class Initialized
DEBUG - 2011-08-06 15:29:46 --> Output Class Initialized
DEBUG - 2011-08-06 15:29:46 --> Input Class Initialized
DEBUG - 2011-08-06 15:29:46 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-06 15:29:46 --> Language Class Initialized
DEBUG - 2011-08-06 15:29:46 --> Loader Class Initialized
DEBUG - 2011-08-06 15:29:46 --> Controller Class Initialized
DEBUG - 2011-08-06 15:29:46 --> Model Class Initialized
DEBUG - 2011-08-06 15:29:46 --> Model Class Initialized
DEBUG - 2011-08-06 15:29:46 --> Model Class Initialized
DEBUG - 2011-08-06 15:29:46 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-06 15:29:46 --> Database Driver Class Initialized
DEBUG - 2011-08-06 15:29:46 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-06 15:29:46 --> Helper loaded: url_helper
DEBUG - 2011-08-06 15:29:46 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-06 15:29:46 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-06 15:29:46 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-06 15:29:46 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-06 15:29:46 --> Final output sent to browser
DEBUG - 2011-08-06 15:29:46 --> Total execution time: 0.0499
DEBUG - 2011-08-06 15:29:46 --> Config Class Initialized
DEBUG - 2011-08-06 15:29:46 --> Hooks Class Initialized
DEBUG - 2011-08-06 15:29:46 --> Utf8 Class Initialized
DEBUG - 2011-08-06 15:29:46 --> UTF-8 Support Enabled
DEBUG - 2011-08-06 15:29:46 --> URI Class Initialized
DEBUG - 2011-08-06 15:29:46 --> Router Class Initialized
ERROR - 2011-08-06 15:29:46 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-06 15:29:59 --> Config Class Initialized
DEBUG - 2011-08-06 15:29:59 --> Hooks Class Initialized
DEBUG - 2011-08-06 15:29:59 --> Utf8 Class Initialized
DEBUG - 2011-08-06 15:29:59 --> UTF-8 Support Enabled
DEBUG - 2011-08-06 15:29:59 --> URI Class Initialized
DEBUG - 2011-08-06 15:29:59 --> Router Class Initialized
DEBUG - 2011-08-06 15:29:59 --> Output Class Initialized
DEBUG - 2011-08-06 15:29:59 --> Input Class Initialized
DEBUG - 2011-08-06 15:29:59 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-06 15:29:59 --> Language Class Initialized
DEBUG - 2011-08-06 15:29:59 --> Loader Class Initialized
DEBUG - 2011-08-06 15:29:59 --> Controller Class Initialized
DEBUG - 2011-08-06 15:29:59 --> Model Class Initialized
DEBUG - 2011-08-06 15:29:59 --> Model Class Initialized
DEBUG - 2011-08-06 15:29:59 --> Model Class Initialized
DEBUG - 2011-08-06 15:29:59 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-06 15:29:59 --> Database Driver Class Initialized
DEBUG - 2011-08-06 15:29:59 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-06 15:29:59 --> Helper loaded: url_helper
DEBUG - 2011-08-06 15:29:59 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-06 15:29:59 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-06 15:29:59 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-06 15:29:59 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-06 15:29:59 --> Final output sent to browser
DEBUG - 2011-08-06 15:29:59 --> Total execution time: 0.2917
DEBUG - 2011-08-06 15:30:01 --> Config Class Initialized
DEBUG - 2011-08-06 15:30:01 --> Hooks Class Initialized
DEBUG - 2011-08-06 15:30:01 --> Utf8 Class Initialized
DEBUG - 2011-08-06 15:30:01 --> UTF-8 Support Enabled
DEBUG - 2011-08-06 15:30:01 --> URI Class Initialized
DEBUG - 2011-08-06 15:30:01 --> Router Class Initialized
ERROR - 2011-08-06 15:30:01 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-06 15:30:03 --> Config Class Initialized
DEBUG - 2011-08-06 15:30:03 --> Hooks Class Initialized
DEBUG - 2011-08-06 15:30:03 --> Utf8 Class Initialized
DEBUG - 2011-08-06 15:30:03 --> UTF-8 Support Enabled
DEBUG - 2011-08-06 15:30:03 --> URI Class Initialized
DEBUG - 2011-08-06 15:30:03 --> Router Class Initialized
DEBUG - 2011-08-06 15:30:03 --> Output Class Initialized
DEBUG - 2011-08-06 15:30:03 --> Input Class Initialized
DEBUG - 2011-08-06 15:30:03 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-06 15:30:03 --> Language Class Initialized
DEBUG - 2011-08-06 15:30:03 --> Loader Class Initialized
DEBUG - 2011-08-06 15:30:03 --> Controller Class Initialized
DEBUG - 2011-08-06 15:30:03 --> Model Class Initialized
DEBUG - 2011-08-06 15:30:03 --> Model Class Initialized
DEBUG - 2011-08-06 15:30:03 --> Model Class Initialized
DEBUG - 2011-08-06 15:30:03 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-06 15:30:03 --> Database Driver Class Initialized
DEBUG - 2011-08-06 15:30:03 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-06 15:30:03 --> Helper loaded: url_helper
DEBUG - 2011-08-06 15:30:03 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-06 15:30:03 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-06 15:30:03 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-06 15:30:03 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-06 15:30:03 --> Final output sent to browser
DEBUG - 2011-08-06 15:30:03 --> Total execution time: 0.3455
DEBUG - 2011-08-06 16:05:25 --> Config Class Initialized
DEBUG - 2011-08-06 16:05:25 --> Hooks Class Initialized
DEBUG - 2011-08-06 16:05:25 --> Utf8 Class Initialized
DEBUG - 2011-08-06 16:05:25 --> UTF-8 Support Enabled
DEBUG - 2011-08-06 16:05:25 --> URI Class Initialized
DEBUG - 2011-08-06 16:05:25 --> Router Class Initialized
DEBUG - 2011-08-06 16:05:25 --> No URI present. Default controller set.
DEBUG - 2011-08-06 16:05:25 --> Output Class Initialized
DEBUG - 2011-08-06 16:05:25 --> Input Class Initialized
DEBUG - 2011-08-06 16:05:25 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-06 16:05:25 --> Language Class Initialized
DEBUG - 2011-08-06 16:05:25 --> Loader Class Initialized
DEBUG - 2011-08-06 16:05:25 --> Controller Class Initialized
DEBUG - 2011-08-06 16:05:25 --> File loaded: application/views/splash/main.php
DEBUG - 2011-08-06 16:05:25 --> Helper loaded: url_helper
DEBUG - 2011-08-06 16:05:25 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-06 16:05:25 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-06 16:05:25 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-06 16:05:25 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-06 16:05:25 --> Final output sent to browser
DEBUG - 2011-08-06 16:05:25 --> Total execution time: 0.0137
DEBUG - 2011-08-06 16:05:25 --> Config Class Initialized
DEBUG - 2011-08-06 16:05:25 --> Hooks Class Initialized
DEBUG - 2011-08-06 16:05:25 --> Utf8 Class Initialized
DEBUG - 2011-08-06 16:05:25 --> UTF-8 Support Enabled
DEBUG - 2011-08-06 16:05:25 --> URI Class Initialized
DEBUG - 2011-08-06 16:05:25 --> Router Class Initialized
ERROR - 2011-08-06 16:05:25 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-06 16:15:46 --> Config Class Initialized
DEBUG - 2011-08-06 16:15:46 --> Hooks Class Initialized
DEBUG - 2011-08-06 16:15:46 --> Utf8 Class Initialized
DEBUG - 2011-08-06 16:15:46 --> UTF-8 Support Enabled
DEBUG - 2011-08-06 16:15:46 --> URI Class Initialized
DEBUG - 2011-08-06 16:15:46 --> Router Class Initialized
DEBUG - 2011-08-06 16:15:46 --> Output Class Initialized
DEBUG - 2011-08-06 16:15:46 --> Input Class Initialized
DEBUG - 2011-08-06 16:15:46 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-06 16:15:46 --> Language Class Initialized
DEBUG - 2011-08-06 16:15:46 --> Loader Class Initialized
DEBUG - 2011-08-06 16:15:46 --> Controller Class Initialized
DEBUG - 2011-08-06 16:15:46 --> Model Class Initialized
DEBUG - 2011-08-06 16:15:46 --> Model Class Initialized
DEBUG - 2011-08-06 16:15:46 --> Model Class Initialized
DEBUG - 2011-08-06 16:15:46 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-06 16:15:46 --> Database Driver Class Initialized
DEBUG - 2011-08-06 16:15:46 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-06 16:15:46 --> Helper loaded: url_helper
DEBUG - 2011-08-06 16:15:46 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-06 16:15:46 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-06 16:15:46 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-06 16:15:46 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-06 16:15:46 --> Final output sent to browser
DEBUG - 2011-08-06 16:15:46 --> Total execution time: 0.2002
DEBUG - 2011-08-06 17:04:25 --> Config Class Initialized
DEBUG - 2011-08-06 17:04:25 --> Hooks Class Initialized
DEBUG - 2011-08-06 17:04:25 --> Utf8 Class Initialized
DEBUG - 2011-08-06 17:04:25 --> UTF-8 Support Enabled
DEBUG - 2011-08-06 17:04:25 --> URI Class Initialized
DEBUG - 2011-08-06 17:04:25 --> Router Class Initialized
DEBUG - 2011-08-06 17:04:25 --> Output Class Initialized
DEBUG - 2011-08-06 17:04:25 --> Input Class Initialized
DEBUG - 2011-08-06 17:04:25 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-06 17:04:25 --> Language Class Initialized
DEBUG - 2011-08-06 17:04:25 --> Loader Class Initialized
DEBUG - 2011-08-06 17:04:25 --> Controller Class Initialized
ERROR - 2011-08-06 17:04:25 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-06 17:04:25 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-06 17:04:25 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-06 17:04:25 --> Model Class Initialized
DEBUG - 2011-08-06 17:04:25 --> Model Class Initialized
DEBUG - 2011-08-06 17:04:25 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-06 17:04:25 --> Database Driver Class Initialized
DEBUG - 2011-08-06 17:04:25 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-06 17:04:25 --> Helper loaded: url_helper
DEBUG - 2011-08-06 17:04:25 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-06 17:04:25 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-06 17:04:25 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-06 17:04:25 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-06 17:04:25 --> Final output sent to browser
DEBUG - 2011-08-06 17:04:25 --> Total execution time: 0.0460
DEBUG - 2011-08-06 17:04:27 --> Config Class Initialized
DEBUG - 2011-08-06 17:04:27 --> Hooks Class Initialized
DEBUG - 2011-08-06 17:04:27 --> Utf8 Class Initialized
DEBUG - 2011-08-06 17:04:27 --> UTF-8 Support Enabled
DEBUG - 2011-08-06 17:04:27 --> URI Class Initialized
DEBUG - 2011-08-06 17:04:27 --> Router Class Initialized
DEBUG - 2011-08-06 17:04:27 --> Output Class Initialized
DEBUG - 2011-08-06 17:04:27 --> Input Class Initialized
DEBUG - 2011-08-06 17:04:27 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-06 17:04:27 --> Language Class Initialized
DEBUG - 2011-08-06 17:04:27 --> Loader Class Initialized
DEBUG - 2011-08-06 17:04:27 --> Controller Class Initialized
DEBUG - 2011-08-06 17:04:27 --> Model Class Initialized
DEBUG - 2011-08-06 17:04:27 --> Model Class Initialized
DEBUG - 2011-08-06 17:04:27 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-06 17:04:27 --> Database Driver Class Initialized
DEBUG - 2011-08-06 17:04:28 --> Final output sent to browser
DEBUG - 2011-08-06 17:04:28 --> Total execution time: 0.5561
DEBUG - 2011-08-06 17:04:30 --> Config Class Initialized
DEBUG - 2011-08-06 17:04:30 --> Hooks Class Initialized
DEBUG - 2011-08-06 17:04:30 --> Utf8 Class Initialized
DEBUG - 2011-08-06 17:04:30 --> UTF-8 Support Enabled
DEBUG - 2011-08-06 17:04:30 --> URI Class Initialized
DEBUG - 2011-08-06 17:04:30 --> Router Class Initialized
ERROR - 2011-08-06 17:04:30 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-06 17:05:51 --> Config Class Initialized
DEBUG - 2011-08-06 17:05:51 --> Hooks Class Initialized
DEBUG - 2011-08-06 17:05:51 --> Utf8 Class Initialized
DEBUG - 2011-08-06 17:05:51 --> UTF-8 Support Enabled
DEBUG - 2011-08-06 17:05:51 --> URI Class Initialized
DEBUG - 2011-08-06 17:05:51 --> Router Class Initialized
DEBUG - 2011-08-06 17:05:51 --> Output Class Initialized
DEBUG - 2011-08-06 17:05:51 --> Input Class Initialized
DEBUG - 2011-08-06 17:05:51 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-06 17:05:51 --> Language Class Initialized
DEBUG - 2011-08-06 17:05:51 --> Loader Class Initialized
DEBUG - 2011-08-06 17:05:51 --> Controller Class Initialized
ERROR - 2011-08-06 17:05:51 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-06 17:05:51 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-06 17:05:51 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-06 17:05:51 --> Model Class Initialized
DEBUG - 2011-08-06 17:05:51 --> Model Class Initialized
DEBUG - 2011-08-06 17:05:51 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-06 17:05:51 --> Database Driver Class Initialized
DEBUG - 2011-08-06 17:05:51 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-06 17:05:51 --> Helper loaded: url_helper
DEBUG - 2011-08-06 17:05:51 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-06 17:05:51 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-06 17:05:51 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-06 17:05:51 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-06 17:05:51 --> Final output sent to browser
DEBUG - 2011-08-06 17:05:51 --> Total execution time: 0.0292
DEBUG - 2011-08-06 17:05:52 --> Config Class Initialized
DEBUG - 2011-08-06 17:05:52 --> Hooks Class Initialized
DEBUG - 2011-08-06 17:05:52 --> Utf8 Class Initialized
DEBUG - 2011-08-06 17:05:52 --> UTF-8 Support Enabled
DEBUG - 2011-08-06 17:05:52 --> URI Class Initialized
DEBUG - 2011-08-06 17:05:52 --> Router Class Initialized
DEBUG - 2011-08-06 17:05:52 --> Output Class Initialized
DEBUG - 2011-08-06 17:05:52 --> Input Class Initialized
DEBUG - 2011-08-06 17:05:52 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-06 17:05:52 --> Language Class Initialized
DEBUG - 2011-08-06 17:05:52 --> Loader Class Initialized
DEBUG - 2011-08-06 17:05:52 --> Controller Class Initialized
DEBUG - 2011-08-06 17:05:52 --> Model Class Initialized
DEBUG - 2011-08-06 17:05:52 --> Model Class Initialized
DEBUG - 2011-08-06 17:05:52 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-06 17:05:52 --> Database Driver Class Initialized
DEBUG - 2011-08-06 17:05:53 --> Final output sent to browser
DEBUG - 2011-08-06 17:05:53 --> Total execution time: 0.6752
DEBUG - 2011-08-06 17:05:53 --> Config Class Initialized
DEBUG - 2011-08-06 17:05:53 --> Hooks Class Initialized
DEBUG - 2011-08-06 17:05:53 --> Utf8 Class Initialized
DEBUG - 2011-08-06 17:05:53 --> UTF-8 Support Enabled
DEBUG - 2011-08-06 17:05:53 --> URI Class Initialized
DEBUG - 2011-08-06 17:05:53 --> Router Class Initialized
ERROR - 2011-08-06 17:05:53 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-06 17:06:12 --> Config Class Initialized
DEBUG - 2011-08-06 17:06:12 --> Hooks Class Initialized
DEBUG - 2011-08-06 17:06:12 --> Utf8 Class Initialized
DEBUG - 2011-08-06 17:06:12 --> UTF-8 Support Enabled
DEBUG - 2011-08-06 17:06:12 --> URI Class Initialized
DEBUG - 2011-08-06 17:06:12 --> Router Class Initialized
DEBUG - 2011-08-06 17:06:12 --> Output Class Initialized
DEBUG - 2011-08-06 17:06:12 --> Input Class Initialized
DEBUG - 2011-08-06 17:06:12 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-06 17:06:12 --> Language Class Initialized
DEBUG - 2011-08-06 17:06:12 --> Loader Class Initialized
DEBUG - 2011-08-06 17:06:12 --> Controller Class Initialized
ERROR - 2011-08-06 17:06:12 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-06 17:06:12 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-06 17:06:12 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-06 17:06:12 --> Model Class Initialized
DEBUG - 2011-08-06 17:06:12 --> Model Class Initialized
DEBUG - 2011-08-06 17:06:12 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-06 17:06:12 --> Database Driver Class Initialized
DEBUG - 2011-08-06 17:06:12 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-06 17:06:12 --> Helper loaded: url_helper
DEBUG - 2011-08-06 17:06:12 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-06 17:06:12 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-06 17:06:12 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-06 17:06:12 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-06 17:06:12 --> Final output sent to browser
DEBUG - 2011-08-06 17:06:12 --> Total execution time: 0.0269
DEBUG - 2011-08-06 17:06:13 --> Config Class Initialized
DEBUG - 2011-08-06 17:06:13 --> Hooks Class Initialized
DEBUG - 2011-08-06 17:06:13 --> Utf8 Class Initialized
DEBUG - 2011-08-06 17:06:13 --> UTF-8 Support Enabled
DEBUG - 2011-08-06 17:06:13 --> URI Class Initialized
DEBUG - 2011-08-06 17:06:13 --> Router Class Initialized
DEBUG - 2011-08-06 17:06:13 --> Output Class Initialized
DEBUG - 2011-08-06 17:06:13 --> Input Class Initialized
DEBUG - 2011-08-06 17:06:13 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-06 17:06:13 --> Language Class Initialized
DEBUG - 2011-08-06 17:06:13 --> Loader Class Initialized
DEBUG - 2011-08-06 17:06:13 --> Controller Class Initialized
DEBUG - 2011-08-06 17:06:13 --> Model Class Initialized
DEBUG - 2011-08-06 17:06:13 --> Model Class Initialized
DEBUG - 2011-08-06 17:06:13 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-06 17:06:13 --> Database Driver Class Initialized
DEBUG - 2011-08-06 17:06:13 --> Final output sent to browser
DEBUG - 2011-08-06 17:06:13 --> Total execution time: 0.6149
DEBUG - 2011-08-06 17:06:13 --> Config Class Initialized
DEBUG - 2011-08-06 17:06:13 --> Hooks Class Initialized
DEBUG - 2011-08-06 17:06:13 --> Utf8 Class Initialized
DEBUG - 2011-08-06 17:06:13 --> UTF-8 Support Enabled
DEBUG - 2011-08-06 17:06:13 --> URI Class Initialized
DEBUG - 2011-08-06 17:06:13 --> Router Class Initialized
ERROR - 2011-08-06 17:06:13 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-06 17:06:22 --> Config Class Initialized
DEBUG - 2011-08-06 17:06:22 --> Hooks Class Initialized
DEBUG - 2011-08-06 17:06:22 --> Utf8 Class Initialized
DEBUG - 2011-08-06 17:06:22 --> UTF-8 Support Enabled
DEBUG - 2011-08-06 17:06:22 --> URI Class Initialized
DEBUG - 2011-08-06 17:06:22 --> Router Class Initialized
DEBUG - 2011-08-06 17:06:22 --> Output Class Initialized
DEBUG - 2011-08-06 17:06:22 --> Input Class Initialized
DEBUG - 2011-08-06 17:06:22 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-06 17:06:22 --> Language Class Initialized
DEBUG - 2011-08-06 17:06:22 --> Loader Class Initialized
DEBUG - 2011-08-06 17:06:22 --> Controller Class Initialized
ERROR - 2011-08-06 17:06:22 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-06 17:06:22 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-06 17:06:22 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-06 17:06:22 --> Model Class Initialized
DEBUG - 2011-08-06 17:06:22 --> Model Class Initialized
DEBUG - 2011-08-06 17:06:22 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-06 17:06:22 --> Database Driver Class Initialized
DEBUG - 2011-08-06 17:06:22 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-06 17:06:22 --> Helper loaded: url_helper
DEBUG - 2011-08-06 17:06:22 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-06 17:06:22 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-06 17:06:22 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-06 17:06:22 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-06 17:06:22 --> Final output sent to browser
DEBUG - 2011-08-06 17:06:22 --> Total execution time: 0.0305
DEBUG - 2011-08-06 17:06:23 --> Config Class Initialized
DEBUG - 2011-08-06 17:06:23 --> Hooks Class Initialized
DEBUG - 2011-08-06 17:06:23 --> Utf8 Class Initialized
DEBUG - 2011-08-06 17:06:23 --> UTF-8 Support Enabled
DEBUG - 2011-08-06 17:06:23 --> URI Class Initialized
DEBUG - 2011-08-06 17:06:23 --> Router Class Initialized
DEBUG - 2011-08-06 17:06:23 --> Output Class Initialized
DEBUG - 2011-08-06 17:06:23 --> Input Class Initialized
DEBUG - 2011-08-06 17:06:23 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-06 17:06:23 --> Language Class Initialized
DEBUG - 2011-08-06 17:06:23 --> Loader Class Initialized
DEBUG - 2011-08-06 17:06:23 --> Controller Class Initialized
DEBUG - 2011-08-06 17:06:23 --> Model Class Initialized
DEBUG - 2011-08-06 17:06:23 --> Model Class Initialized
DEBUG - 2011-08-06 17:06:23 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-06 17:06:23 --> Database Driver Class Initialized
DEBUG - 2011-08-06 17:06:24 --> Final output sent to browser
DEBUG - 2011-08-06 17:06:24 --> Total execution time: 0.4979
DEBUG - 2011-08-06 17:06:24 --> Config Class Initialized
DEBUG - 2011-08-06 17:06:24 --> Hooks Class Initialized
DEBUG - 2011-08-06 17:06:24 --> Utf8 Class Initialized
DEBUG - 2011-08-06 17:06:24 --> UTF-8 Support Enabled
DEBUG - 2011-08-06 17:06:24 --> URI Class Initialized
DEBUG - 2011-08-06 17:06:24 --> Router Class Initialized
ERROR - 2011-08-06 17:06:24 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-06 17:06:33 --> Config Class Initialized
DEBUG - 2011-08-06 17:06:33 --> Hooks Class Initialized
DEBUG - 2011-08-06 17:06:33 --> Utf8 Class Initialized
DEBUG - 2011-08-06 17:06:33 --> UTF-8 Support Enabled
DEBUG - 2011-08-06 17:06:33 --> URI Class Initialized
DEBUG - 2011-08-06 17:06:33 --> Router Class Initialized
DEBUG - 2011-08-06 17:06:33 --> Output Class Initialized
DEBUG - 2011-08-06 17:06:33 --> Input Class Initialized
DEBUG - 2011-08-06 17:06:33 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-06 17:06:33 --> Language Class Initialized
DEBUG - 2011-08-06 17:06:33 --> Loader Class Initialized
DEBUG - 2011-08-06 17:06:33 --> Controller Class Initialized
ERROR - 2011-08-06 17:06:33 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-06 17:06:33 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-06 17:06:33 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-06 17:06:33 --> Model Class Initialized
DEBUG - 2011-08-06 17:06:33 --> Model Class Initialized
DEBUG - 2011-08-06 17:06:33 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-06 17:06:33 --> Database Driver Class Initialized
DEBUG - 2011-08-06 17:06:33 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-06 17:06:33 --> Helper loaded: url_helper
DEBUG - 2011-08-06 17:06:33 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-06 17:06:33 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-06 17:06:33 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-06 17:06:33 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-06 17:06:33 --> Final output sent to browser
DEBUG - 2011-08-06 17:06:33 --> Total execution time: 0.0306
DEBUG - 2011-08-06 17:06:34 --> Config Class Initialized
DEBUG - 2011-08-06 17:06:34 --> Hooks Class Initialized
DEBUG - 2011-08-06 17:06:34 --> Utf8 Class Initialized
DEBUG - 2011-08-06 17:06:34 --> UTF-8 Support Enabled
DEBUG - 2011-08-06 17:06:34 --> URI Class Initialized
DEBUG - 2011-08-06 17:06:34 --> Router Class Initialized
DEBUG - 2011-08-06 17:06:34 --> Output Class Initialized
DEBUG - 2011-08-06 17:06:34 --> Input Class Initialized
DEBUG - 2011-08-06 17:06:34 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-06 17:06:34 --> Language Class Initialized
DEBUG - 2011-08-06 17:06:34 --> Loader Class Initialized
DEBUG - 2011-08-06 17:06:34 --> Controller Class Initialized
DEBUG - 2011-08-06 17:06:34 --> Model Class Initialized
DEBUG - 2011-08-06 17:06:34 --> Model Class Initialized
DEBUG - 2011-08-06 17:06:34 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-06 17:06:34 --> Database Driver Class Initialized
DEBUG - 2011-08-06 17:06:35 --> Final output sent to browser
DEBUG - 2011-08-06 17:06:35 --> Total execution time: 0.6143
DEBUG - 2011-08-06 17:06:35 --> Config Class Initialized
DEBUG - 2011-08-06 17:06:35 --> Hooks Class Initialized
DEBUG - 2011-08-06 17:06:35 --> Utf8 Class Initialized
DEBUG - 2011-08-06 17:06:35 --> UTF-8 Support Enabled
DEBUG - 2011-08-06 17:06:35 --> URI Class Initialized
DEBUG - 2011-08-06 17:06:35 --> Router Class Initialized
ERROR - 2011-08-06 17:06:35 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-06 17:06:39 --> Config Class Initialized
DEBUG - 2011-08-06 17:06:39 --> Hooks Class Initialized
DEBUG - 2011-08-06 17:06:39 --> Utf8 Class Initialized
DEBUG - 2011-08-06 17:06:39 --> UTF-8 Support Enabled
DEBUG - 2011-08-06 17:06:39 --> URI Class Initialized
DEBUG - 2011-08-06 17:06:39 --> Router Class Initialized
DEBUG - 2011-08-06 17:06:39 --> Output Class Initialized
DEBUG - 2011-08-06 17:06:39 --> Input Class Initialized
DEBUG - 2011-08-06 17:06:39 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-06 17:06:39 --> Language Class Initialized
DEBUG - 2011-08-06 17:06:39 --> Loader Class Initialized
DEBUG - 2011-08-06 17:06:39 --> Controller Class Initialized
ERROR - 2011-08-06 17:06:39 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-06 17:06:39 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-06 17:06:39 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-06 17:06:39 --> Model Class Initialized
DEBUG - 2011-08-06 17:06:39 --> Model Class Initialized
DEBUG - 2011-08-06 17:06:39 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-06 17:06:39 --> Database Driver Class Initialized
DEBUG - 2011-08-06 17:06:39 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-06 17:06:39 --> Helper loaded: url_helper
DEBUG - 2011-08-06 17:06:39 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-06 17:06:39 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-06 17:06:39 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-06 17:06:39 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-06 17:06:39 --> Final output sent to browser
DEBUG - 2011-08-06 17:06:39 --> Total execution time: 0.0483
DEBUG - 2011-08-06 17:06:47 --> Config Class Initialized
DEBUG - 2011-08-06 17:06:47 --> Hooks Class Initialized
DEBUG - 2011-08-06 17:06:47 --> Utf8 Class Initialized
DEBUG - 2011-08-06 17:06:47 --> UTF-8 Support Enabled
DEBUG - 2011-08-06 17:06:47 --> URI Class Initialized
DEBUG - 2011-08-06 17:06:47 --> Router Class Initialized
DEBUG - 2011-08-06 17:06:47 --> Output Class Initialized
DEBUG - 2011-08-06 17:06:47 --> Input Class Initialized
DEBUG - 2011-08-06 17:06:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-06 17:06:47 --> Language Class Initialized
DEBUG - 2011-08-06 17:06:47 --> Loader Class Initialized
DEBUG - 2011-08-06 17:06:47 --> Controller Class Initialized
DEBUG - 2011-08-06 17:06:47 --> Model Class Initialized
DEBUG - 2011-08-06 17:06:47 --> Model Class Initialized
DEBUG - 2011-08-06 17:06:47 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-06 17:06:47 --> Database Driver Class Initialized
DEBUG - 2011-08-06 17:06:48 --> Final output sent to browser
DEBUG - 2011-08-06 17:06:48 --> Total execution time: 0.9197
DEBUG - 2011-08-06 17:06:49 --> Config Class Initialized
DEBUG - 2011-08-06 17:06:49 --> Hooks Class Initialized
DEBUG - 2011-08-06 17:06:49 --> Utf8 Class Initialized
DEBUG - 2011-08-06 17:06:49 --> UTF-8 Support Enabled
DEBUG - 2011-08-06 17:06:49 --> URI Class Initialized
DEBUG - 2011-08-06 17:06:49 --> Router Class Initialized
ERROR - 2011-08-06 17:06:49 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-06 17:07:00 --> Config Class Initialized
DEBUG - 2011-08-06 17:07:00 --> Hooks Class Initialized
DEBUG - 2011-08-06 17:07:00 --> Utf8 Class Initialized
DEBUG - 2011-08-06 17:07:00 --> UTF-8 Support Enabled
DEBUG - 2011-08-06 17:07:00 --> URI Class Initialized
DEBUG - 2011-08-06 17:07:00 --> Router Class Initialized
DEBUG - 2011-08-06 17:07:00 --> Output Class Initialized
DEBUG - 2011-08-06 17:07:00 --> Input Class Initialized
DEBUG - 2011-08-06 17:07:00 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-06 17:07:00 --> Language Class Initialized
DEBUG - 2011-08-06 17:07:00 --> Loader Class Initialized
DEBUG - 2011-08-06 17:07:00 --> Controller Class Initialized
ERROR - 2011-08-06 17:07:00 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-06 17:07:00 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-06 17:07:00 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-06 17:07:00 --> Model Class Initialized
DEBUG - 2011-08-06 17:07:00 --> Model Class Initialized
DEBUG - 2011-08-06 17:07:00 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-06 17:07:00 --> Database Driver Class Initialized
DEBUG - 2011-08-06 17:07:00 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-06 17:07:00 --> Helper loaded: url_helper
DEBUG - 2011-08-06 17:07:00 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-06 17:07:00 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-06 17:07:00 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-06 17:07:00 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-06 17:07:00 --> Final output sent to browser
DEBUG - 2011-08-06 17:07:00 --> Total execution time: 0.0591
DEBUG - 2011-08-06 17:07:01 --> Config Class Initialized
DEBUG - 2011-08-06 17:07:01 --> Hooks Class Initialized
DEBUG - 2011-08-06 17:07:01 --> Utf8 Class Initialized
DEBUG - 2011-08-06 17:07:01 --> UTF-8 Support Enabled
DEBUG - 2011-08-06 17:07:01 --> URI Class Initialized
DEBUG - 2011-08-06 17:07:01 --> Router Class Initialized
DEBUG - 2011-08-06 17:07:01 --> Output Class Initialized
DEBUG - 2011-08-06 17:07:01 --> Input Class Initialized
DEBUG - 2011-08-06 17:07:01 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-06 17:07:01 --> Language Class Initialized
DEBUG - 2011-08-06 17:07:01 --> Loader Class Initialized
DEBUG - 2011-08-06 17:07:01 --> Controller Class Initialized
DEBUG - 2011-08-06 17:07:01 --> Model Class Initialized
DEBUG - 2011-08-06 17:07:01 --> Model Class Initialized
DEBUG - 2011-08-06 17:07:01 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-06 17:07:01 --> Database Driver Class Initialized
DEBUG - 2011-08-06 17:07:02 --> Final output sent to browser
DEBUG - 2011-08-06 17:07:02 --> Total execution time: 0.5540
DEBUG - 2011-08-06 17:07:02 --> Config Class Initialized
DEBUG - 2011-08-06 17:07:02 --> Hooks Class Initialized
DEBUG - 2011-08-06 17:07:02 --> Utf8 Class Initialized
DEBUG - 2011-08-06 17:07:02 --> UTF-8 Support Enabled
DEBUG - 2011-08-06 17:07:02 --> URI Class Initialized
DEBUG - 2011-08-06 17:07:02 --> Router Class Initialized
ERROR - 2011-08-06 17:07:02 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-06 17:07:07 --> Config Class Initialized
DEBUG - 2011-08-06 17:07:07 --> Hooks Class Initialized
DEBUG - 2011-08-06 17:07:07 --> Utf8 Class Initialized
DEBUG - 2011-08-06 17:07:07 --> UTF-8 Support Enabled
DEBUG - 2011-08-06 17:07:07 --> URI Class Initialized
DEBUG - 2011-08-06 17:07:07 --> Router Class Initialized
DEBUG - 2011-08-06 17:07:07 --> Output Class Initialized
DEBUG - 2011-08-06 17:07:07 --> Input Class Initialized
DEBUG - 2011-08-06 17:07:07 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-06 17:07:07 --> Language Class Initialized
DEBUG - 2011-08-06 17:07:07 --> Loader Class Initialized
DEBUG - 2011-08-06 17:07:07 --> Controller Class Initialized
ERROR - 2011-08-06 17:07:07 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-06 17:07:07 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-06 17:07:07 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-06 17:07:07 --> Model Class Initialized
DEBUG - 2011-08-06 17:07:07 --> Model Class Initialized
DEBUG - 2011-08-06 17:07:07 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-06 17:07:07 --> Database Driver Class Initialized
DEBUG - 2011-08-06 17:07:07 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-06 17:07:07 --> Helper loaded: url_helper
DEBUG - 2011-08-06 17:07:07 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-06 17:07:07 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-06 17:07:07 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-06 17:07:07 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-06 17:07:07 --> Final output sent to browser
DEBUG - 2011-08-06 17:07:07 --> Total execution time: 0.0304
DEBUG - 2011-08-06 17:07:08 --> Config Class Initialized
DEBUG - 2011-08-06 17:07:08 --> Hooks Class Initialized
DEBUG - 2011-08-06 17:07:08 --> Utf8 Class Initialized
DEBUG - 2011-08-06 17:07:08 --> UTF-8 Support Enabled
DEBUG - 2011-08-06 17:07:08 --> URI Class Initialized
DEBUG - 2011-08-06 17:07:08 --> Router Class Initialized
DEBUG - 2011-08-06 17:07:08 --> Output Class Initialized
DEBUG - 2011-08-06 17:07:08 --> Input Class Initialized
DEBUG - 2011-08-06 17:07:08 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-06 17:07:08 --> Language Class Initialized
DEBUG - 2011-08-06 17:07:08 --> Loader Class Initialized
DEBUG - 2011-08-06 17:07:08 --> Controller Class Initialized
DEBUG - 2011-08-06 17:07:08 --> Model Class Initialized
DEBUG - 2011-08-06 17:07:08 --> Model Class Initialized
DEBUG - 2011-08-06 17:07:08 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-06 17:07:08 --> Database Driver Class Initialized
DEBUG - 2011-08-06 17:07:09 --> Final output sent to browser
DEBUG - 2011-08-06 17:07:09 --> Total execution time: 0.5500
DEBUG - 2011-08-06 17:07:09 --> Config Class Initialized
DEBUG - 2011-08-06 17:07:09 --> Hooks Class Initialized
DEBUG - 2011-08-06 17:07:09 --> Utf8 Class Initialized
DEBUG - 2011-08-06 17:07:09 --> UTF-8 Support Enabled
DEBUG - 2011-08-06 17:07:09 --> URI Class Initialized
DEBUG - 2011-08-06 17:07:09 --> Router Class Initialized
ERROR - 2011-08-06 17:07:09 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-06 17:07:16 --> Config Class Initialized
DEBUG - 2011-08-06 17:07:16 --> Hooks Class Initialized
DEBUG - 2011-08-06 17:07:16 --> Utf8 Class Initialized
DEBUG - 2011-08-06 17:07:16 --> UTF-8 Support Enabled
DEBUG - 2011-08-06 17:07:16 --> URI Class Initialized
DEBUG - 2011-08-06 17:07:16 --> Router Class Initialized
DEBUG - 2011-08-06 17:07:16 --> Output Class Initialized
DEBUG - 2011-08-06 17:07:16 --> Input Class Initialized
DEBUG - 2011-08-06 17:07:16 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-06 17:07:16 --> Language Class Initialized
DEBUG - 2011-08-06 17:07:16 --> Loader Class Initialized
DEBUG - 2011-08-06 17:07:16 --> Controller Class Initialized
ERROR - 2011-08-06 17:07:16 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-06 17:07:16 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-06 17:07:16 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-06 17:07:16 --> Model Class Initialized
DEBUG - 2011-08-06 17:07:16 --> Model Class Initialized
DEBUG - 2011-08-06 17:07:16 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-06 17:07:16 --> Database Driver Class Initialized
DEBUG - 2011-08-06 17:07:16 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-06 17:07:16 --> Helper loaded: url_helper
DEBUG - 2011-08-06 17:07:16 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-06 17:07:16 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-06 17:07:16 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-06 17:07:16 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-06 17:07:16 --> Final output sent to browser
DEBUG - 2011-08-06 17:07:16 --> Total execution time: 0.0271
DEBUG - 2011-08-06 17:07:17 --> Config Class Initialized
DEBUG - 2011-08-06 17:07:17 --> Hooks Class Initialized
DEBUG - 2011-08-06 17:07:17 --> Utf8 Class Initialized
DEBUG - 2011-08-06 17:07:17 --> UTF-8 Support Enabled
DEBUG - 2011-08-06 17:07:17 --> URI Class Initialized
DEBUG - 2011-08-06 17:07:17 --> Router Class Initialized
DEBUG - 2011-08-06 17:07:17 --> Output Class Initialized
DEBUG - 2011-08-06 17:07:17 --> Input Class Initialized
DEBUG - 2011-08-06 17:07:17 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-06 17:07:17 --> Language Class Initialized
DEBUG - 2011-08-06 17:07:17 --> Loader Class Initialized
DEBUG - 2011-08-06 17:07:17 --> Controller Class Initialized
DEBUG - 2011-08-06 17:07:17 --> Model Class Initialized
DEBUG - 2011-08-06 17:07:17 --> Model Class Initialized
DEBUG - 2011-08-06 17:07:17 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-06 17:07:17 --> Database Driver Class Initialized
DEBUG - 2011-08-06 17:07:18 --> Final output sent to browser
DEBUG - 2011-08-06 17:07:18 --> Total execution time: 0.4933
DEBUG - 2011-08-06 17:07:18 --> Config Class Initialized
DEBUG - 2011-08-06 17:07:18 --> Hooks Class Initialized
DEBUG - 2011-08-06 17:07:18 --> Utf8 Class Initialized
DEBUG - 2011-08-06 17:07:18 --> UTF-8 Support Enabled
DEBUG - 2011-08-06 17:07:18 --> URI Class Initialized
DEBUG - 2011-08-06 17:07:18 --> Router Class Initialized
ERROR - 2011-08-06 17:07:18 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-06 17:07:29 --> Config Class Initialized
DEBUG - 2011-08-06 17:07:29 --> Hooks Class Initialized
DEBUG - 2011-08-06 17:07:29 --> Utf8 Class Initialized
DEBUG - 2011-08-06 17:07:29 --> UTF-8 Support Enabled
DEBUG - 2011-08-06 17:07:29 --> URI Class Initialized
DEBUG - 2011-08-06 17:07:29 --> Router Class Initialized
DEBUG - 2011-08-06 17:07:29 --> Output Class Initialized
DEBUG - 2011-08-06 17:07:29 --> Input Class Initialized
DEBUG - 2011-08-06 17:07:29 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-06 17:07:29 --> Language Class Initialized
DEBUG - 2011-08-06 17:07:29 --> Loader Class Initialized
DEBUG - 2011-08-06 17:07:29 --> Controller Class Initialized
ERROR - 2011-08-06 17:07:29 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-06 17:07:29 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-06 17:07:29 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-06 17:07:29 --> Model Class Initialized
DEBUG - 2011-08-06 17:07:29 --> Model Class Initialized
DEBUG - 2011-08-06 17:07:29 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-06 17:07:29 --> Database Driver Class Initialized
DEBUG - 2011-08-06 17:07:29 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-06 17:07:29 --> Helper loaded: url_helper
DEBUG - 2011-08-06 17:07:29 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-06 17:07:29 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-06 17:07:29 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-06 17:07:29 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-06 17:07:29 --> Final output sent to browser
DEBUG - 2011-08-06 17:07:29 --> Total execution time: 0.0278
DEBUG - 2011-08-06 17:07:30 --> Config Class Initialized
DEBUG - 2011-08-06 17:07:30 --> Hooks Class Initialized
DEBUG - 2011-08-06 17:07:30 --> Utf8 Class Initialized
DEBUG - 2011-08-06 17:07:30 --> UTF-8 Support Enabled
DEBUG - 2011-08-06 17:07:30 --> URI Class Initialized
DEBUG - 2011-08-06 17:07:30 --> Router Class Initialized
DEBUG - 2011-08-06 17:07:30 --> Output Class Initialized
DEBUG - 2011-08-06 17:07:30 --> Input Class Initialized
DEBUG - 2011-08-06 17:07:30 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-06 17:07:30 --> Language Class Initialized
DEBUG - 2011-08-06 17:07:30 --> Loader Class Initialized
DEBUG - 2011-08-06 17:07:30 --> Controller Class Initialized
DEBUG - 2011-08-06 17:07:30 --> Model Class Initialized
DEBUG - 2011-08-06 17:07:30 --> Model Class Initialized
DEBUG - 2011-08-06 17:07:30 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-06 17:07:30 --> Database Driver Class Initialized
DEBUG - 2011-08-06 17:07:31 --> Final output sent to browser
DEBUG - 2011-08-06 17:07:31 --> Total execution time: 0.6156
DEBUG - 2011-08-06 17:07:31 --> Config Class Initialized
DEBUG - 2011-08-06 17:07:31 --> Hooks Class Initialized
DEBUG - 2011-08-06 17:07:31 --> Utf8 Class Initialized
DEBUG - 2011-08-06 17:07:31 --> UTF-8 Support Enabled
DEBUG - 2011-08-06 17:07:31 --> URI Class Initialized
DEBUG - 2011-08-06 17:07:31 --> Router Class Initialized
ERROR - 2011-08-06 17:07:31 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-06 17:07:42 --> Config Class Initialized
DEBUG - 2011-08-06 17:07:42 --> Hooks Class Initialized
DEBUG - 2011-08-06 17:07:42 --> Utf8 Class Initialized
DEBUG - 2011-08-06 17:07:42 --> UTF-8 Support Enabled
DEBUG - 2011-08-06 17:07:42 --> URI Class Initialized
DEBUG - 2011-08-06 17:07:42 --> Router Class Initialized
DEBUG - 2011-08-06 17:07:42 --> Output Class Initialized
DEBUG - 2011-08-06 17:07:42 --> Input Class Initialized
DEBUG - 2011-08-06 17:07:42 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-06 17:07:42 --> Language Class Initialized
DEBUG - 2011-08-06 17:07:42 --> Loader Class Initialized
DEBUG - 2011-08-06 17:07:42 --> Controller Class Initialized
ERROR - 2011-08-06 17:07:42 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-06 17:07:42 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-06 17:07:42 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-06 17:07:42 --> Model Class Initialized
DEBUG - 2011-08-06 17:07:42 --> Model Class Initialized
DEBUG - 2011-08-06 17:07:42 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-06 17:07:42 --> Database Driver Class Initialized
DEBUG - 2011-08-06 17:07:42 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-06 17:07:42 --> Helper loaded: url_helper
DEBUG - 2011-08-06 17:07:42 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-06 17:07:42 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-06 17:07:42 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-06 17:07:42 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-06 17:07:42 --> Final output sent to browser
DEBUG - 2011-08-06 17:07:42 --> Total execution time: 0.0293
DEBUG - 2011-08-06 17:07:43 --> Config Class Initialized
DEBUG - 2011-08-06 17:07:43 --> Hooks Class Initialized
DEBUG - 2011-08-06 17:07:43 --> Utf8 Class Initialized
DEBUG - 2011-08-06 17:07:43 --> UTF-8 Support Enabled
DEBUG - 2011-08-06 17:07:43 --> URI Class Initialized
DEBUG - 2011-08-06 17:07:43 --> Router Class Initialized
DEBUG - 2011-08-06 17:07:43 --> Output Class Initialized
DEBUG - 2011-08-06 17:07:43 --> Input Class Initialized
DEBUG - 2011-08-06 17:07:43 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-06 17:07:43 --> Language Class Initialized
DEBUG - 2011-08-06 17:07:43 --> Loader Class Initialized
DEBUG - 2011-08-06 17:07:43 --> Controller Class Initialized
DEBUG - 2011-08-06 17:07:43 --> Model Class Initialized
DEBUG - 2011-08-06 17:07:43 --> Model Class Initialized
DEBUG - 2011-08-06 17:07:43 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-06 17:07:43 --> Database Driver Class Initialized
DEBUG - 2011-08-06 17:07:44 --> Final output sent to browser
DEBUG - 2011-08-06 17:07:44 --> Total execution time: 0.5450
DEBUG - 2011-08-06 17:07:44 --> Config Class Initialized
DEBUG - 2011-08-06 17:07:44 --> Hooks Class Initialized
DEBUG - 2011-08-06 17:07:44 --> Utf8 Class Initialized
DEBUG - 2011-08-06 17:07:44 --> UTF-8 Support Enabled
DEBUG - 2011-08-06 17:07:44 --> URI Class Initialized
DEBUG - 2011-08-06 17:07:44 --> Router Class Initialized
ERROR - 2011-08-06 17:07:44 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-06 17:07:48 --> Config Class Initialized
DEBUG - 2011-08-06 17:07:48 --> Hooks Class Initialized
DEBUG - 2011-08-06 17:07:48 --> Utf8 Class Initialized
DEBUG - 2011-08-06 17:07:48 --> UTF-8 Support Enabled
DEBUG - 2011-08-06 17:07:48 --> URI Class Initialized
DEBUG - 2011-08-06 17:07:48 --> Router Class Initialized
DEBUG - 2011-08-06 17:07:48 --> Output Class Initialized
DEBUG - 2011-08-06 17:07:48 --> Input Class Initialized
DEBUG - 2011-08-06 17:07:48 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-06 17:07:48 --> Language Class Initialized
DEBUG - 2011-08-06 17:07:48 --> Loader Class Initialized
DEBUG - 2011-08-06 17:07:48 --> Controller Class Initialized
ERROR - 2011-08-06 17:07:48 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-06 17:07:48 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-06 17:07:48 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-06 17:07:48 --> Model Class Initialized
DEBUG - 2011-08-06 17:07:48 --> Model Class Initialized
DEBUG - 2011-08-06 17:07:48 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-06 17:07:48 --> Database Driver Class Initialized
DEBUG - 2011-08-06 17:07:48 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-06 17:07:48 --> Helper loaded: url_helper
DEBUG - 2011-08-06 17:07:48 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-06 17:07:48 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-06 17:07:48 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-06 17:07:48 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-06 17:07:48 --> Final output sent to browser
DEBUG - 2011-08-06 17:07:48 --> Total execution time: 0.0550
DEBUG - 2011-08-06 17:07:49 --> Config Class Initialized
DEBUG - 2011-08-06 17:07:49 --> Hooks Class Initialized
DEBUG - 2011-08-06 17:07:49 --> Utf8 Class Initialized
DEBUG - 2011-08-06 17:07:49 --> UTF-8 Support Enabled
DEBUG - 2011-08-06 17:07:49 --> URI Class Initialized
DEBUG - 2011-08-06 17:07:49 --> Router Class Initialized
DEBUG - 2011-08-06 17:07:49 --> Output Class Initialized
DEBUG - 2011-08-06 17:07:49 --> Input Class Initialized
DEBUG - 2011-08-06 17:07:49 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-06 17:07:49 --> Language Class Initialized
DEBUG - 2011-08-06 17:07:49 --> Loader Class Initialized
DEBUG - 2011-08-06 17:07:49 --> Controller Class Initialized
DEBUG - 2011-08-06 17:07:49 --> Model Class Initialized
DEBUG - 2011-08-06 17:07:49 --> Model Class Initialized
DEBUG - 2011-08-06 17:07:49 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-06 17:07:49 --> Database Driver Class Initialized
DEBUG - 2011-08-06 17:07:50 --> Final output sent to browser
DEBUG - 2011-08-06 17:07:50 --> Total execution time: 0.5721
DEBUG - 2011-08-06 17:07:50 --> Config Class Initialized
DEBUG - 2011-08-06 17:07:50 --> Hooks Class Initialized
DEBUG - 2011-08-06 17:07:50 --> Utf8 Class Initialized
DEBUG - 2011-08-06 17:07:50 --> UTF-8 Support Enabled
DEBUG - 2011-08-06 17:07:50 --> URI Class Initialized
DEBUG - 2011-08-06 17:07:50 --> Router Class Initialized
ERROR - 2011-08-06 17:07:50 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-06 17:20:05 --> Config Class Initialized
DEBUG - 2011-08-06 17:20:05 --> Hooks Class Initialized
DEBUG - 2011-08-06 17:20:05 --> Utf8 Class Initialized
DEBUG - 2011-08-06 17:20:05 --> UTF-8 Support Enabled
DEBUG - 2011-08-06 17:20:05 --> URI Class Initialized
DEBUG - 2011-08-06 17:20:05 --> Router Class Initialized
DEBUG - 2011-08-06 17:20:05 --> Output Class Initialized
DEBUG - 2011-08-06 17:20:05 --> Input Class Initialized
DEBUG - 2011-08-06 17:20:05 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-06 17:20:05 --> Language Class Initialized
DEBUG - 2011-08-06 17:20:05 --> Loader Class Initialized
DEBUG - 2011-08-06 17:20:05 --> Controller Class Initialized
ERROR - 2011-08-06 17:20:06 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-06 17:20:06 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-06 17:20:06 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-06 17:20:06 --> Model Class Initialized
DEBUG - 2011-08-06 17:20:06 --> Model Class Initialized
DEBUG - 2011-08-06 17:20:06 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-06 17:20:06 --> Database Driver Class Initialized
DEBUG - 2011-08-06 17:20:06 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-06 17:20:06 --> Helper loaded: url_helper
DEBUG - 2011-08-06 17:20:06 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-06 17:20:06 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-06 17:20:06 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-06 17:20:06 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-06 17:20:06 --> Final output sent to browser
DEBUG - 2011-08-06 17:20:06 --> Total execution time: 0.2413
DEBUG - 2011-08-06 17:20:07 --> Config Class Initialized
DEBUG - 2011-08-06 17:20:07 --> Hooks Class Initialized
DEBUG - 2011-08-06 17:20:07 --> Utf8 Class Initialized
DEBUG - 2011-08-06 17:20:07 --> UTF-8 Support Enabled
DEBUG - 2011-08-06 17:20:07 --> URI Class Initialized
DEBUG - 2011-08-06 17:20:07 --> Router Class Initialized
DEBUG - 2011-08-06 17:20:07 --> Output Class Initialized
DEBUG - 2011-08-06 17:20:07 --> Input Class Initialized
DEBUG - 2011-08-06 17:20:07 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-06 17:20:07 --> Language Class Initialized
DEBUG - 2011-08-06 17:20:07 --> Loader Class Initialized
DEBUG - 2011-08-06 17:20:07 --> Controller Class Initialized
DEBUG - 2011-08-06 17:20:07 --> Model Class Initialized
DEBUG - 2011-08-06 17:20:07 --> Model Class Initialized
DEBUG - 2011-08-06 17:20:07 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-06 17:20:07 --> Database Driver Class Initialized
DEBUG - 2011-08-06 17:20:07 --> Final output sent to browser
DEBUG - 2011-08-06 17:20:07 --> Total execution time: 0.5544
DEBUG - 2011-08-06 17:20:09 --> Config Class Initialized
DEBUG - 2011-08-06 17:20:09 --> Hooks Class Initialized
DEBUG - 2011-08-06 17:20:09 --> Utf8 Class Initialized
DEBUG - 2011-08-06 17:20:09 --> UTF-8 Support Enabled
DEBUG - 2011-08-06 17:20:09 --> URI Class Initialized
DEBUG - 2011-08-06 17:20:09 --> Router Class Initialized
ERROR - 2011-08-06 17:20:09 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-06 17:20:10 --> Config Class Initialized
DEBUG - 2011-08-06 17:20:10 --> Hooks Class Initialized
DEBUG - 2011-08-06 17:20:10 --> Utf8 Class Initialized
DEBUG - 2011-08-06 17:20:10 --> UTF-8 Support Enabled
DEBUG - 2011-08-06 17:20:10 --> URI Class Initialized
DEBUG - 2011-08-06 17:20:10 --> Router Class Initialized
ERROR - 2011-08-06 17:20:10 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-06 17:20:10 --> Config Class Initialized
DEBUG - 2011-08-06 17:20:10 --> Hooks Class Initialized
DEBUG - 2011-08-06 17:20:10 --> Utf8 Class Initialized
DEBUG - 2011-08-06 17:20:10 --> UTF-8 Support Enabled
DEBUG - 2011-08-06 17:20:10 --> URI Class Initialized
DEBUG - 2011-08-06 17:20:10 --> Router Class Initialized
ERROR - 2011-08-06 17:20:10 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-06 17:39:30 --> Config Class Initialized
DEBUG - 2011-08-06 17:39:30 --> Hooks Class Initialized
DEBUG - 2011-08-06 17:39:30 --> Utf8 Class Initialized
DEBUG - 2011-08-06 17:39:30 --> UTF-8 Support Enabled
DEBUG - 2011-08-06 17:39:30 --> URI Class Initialized
DEBUG - 2011-08-06 17:39:30 --> Router Class Initialized
ERROR - 2011-08-06 17:39:30 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-08-06 19:10:35 --> Config Class Initialized
DEBUG - 2011-08-06 19:10:35 --> Hooks Class Initialized
DEBUG - 2011-08-06 19:10:35 --> Utf8 Class Initialized
DEBUG - 2011-08-06 19:10:35 --> UTF-8 Support Enabled
DEBUG - 2011-08-06 19:10:35 --> URI Class Initialized
DEBUG - 2011-08-06 19:10:35 --> Router Class Initialized
DEBUG - 2011-08-06 19:10:35 --> Output Class Initialized
DEBUG - 2011-08-06 19:10:35 --> Input Class Initialized
DEBUG - 2011-08-06 19:10:35 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-06 19:10:35 --> Language Class Initialized
DEBUG - 2011-08-06 19:10:35 --> Loader Class Initialized
DEBUG - 2011-08-06 19:10:35 --> Controller Class Initialized
ERROR - 2011-08-06 19:10:35 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-06 19:10:35 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-06 19:10:35 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-06 19:10:35 --> Model Class Initialized
DEBUG - 2011-08-06 19:10:35 --> Model Class Initialized
DEBUG - 2011-08-06 19:10:36 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-06 19:10:36 --> Database Driver Class Initialized
DEBUG - 2011-08-06 19:10:36 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-06 19:10:36 --> Helper loaded: url_helper
DEBUG - 2011-08-06 19:10:36 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-06 19:10:36 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-06 19:10:36 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-06 19:10:36 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-06 19:10:36 --> Final output sent to browser
DEBUG - 2011-08-06 19:10:36 --> Total execution time: 0.1168
DEBUG - 2011-08-06 19:10:37 --> Config Class Initialized
DEBUG - 2011-08-06 19:10:37 --> Hooks Class Initialized
DEBUG - 2011-08-06 19:10:37 --> Utf8 Class Initialized
DEBUG - 2011-08-06 19:10:37 --> UTF-8 Support Enabled
DEBUG - 2011-08-06 19:10:37 --> URI Class Initialized
DEBUG - 2011-08-06 19:10:37 --> Router Class Initialized
DEBUG - 2011-08-06 19:10:37 --> Output Class Initialized
DEBUG - 2011-08-06 19:10:37 --> Input Class Initialized
DEBUG - 2011-08-06 19:10:37 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-06 19:10:37 --> Language Class Initialized
DEBUG - 2011-08-06 19:10:37 --> Loader Class Initialized
DEBUG - 2011-08-06 19:10:37 --> Controller Class Initialized
DEBUG - 2011-08-06 19:10:37 --> Model Class Initialized
DEBUG - 2011-08-06 19:10:37 --> Model Class Initialized
DEBUG - 2011-08-06 19:10:37 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-06 19:10:37 --> Database Driver Class Initialized
DEBUG - 2011-08-06 19:10:38 --> Final output sent to browser
DEBUG - 2011-08-06 19:10:38 --> Total execution time: 1.0440
DEBUG - 2011-08-06 19:10:39 --> Config Class Initialized
DEBUG - 2011-08-06 19:10:39 --> Hooks Class Initialized
DEBUG - 2011-08-06 19:10:39 --> Utf8 Class Initialized
DEBUG - 2011-08-06 19:10:39 --> UTF-8 Support Enabled
DEBUG - 2011-08-06 19:10:39 --> URI Class Initialized
DEBUG - 2011-08-06 19:10:39 --> Router Class Initialized
ERROR - 2011-08-06 19:10:39 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-06 19:11:16 --> Config Class Initialized
DEBUG - 2011-08-06 19:11:16 --> Hooks Class Initialized
DEBUG - 2011-08-06 19:11:16 --> Utf8 Class Initialized
DEBUG - 2011-08-06 19:11:16 --> UTF-8 Support Enabled
DEBUG - 2011-08-06 19:11:16 --> URI Class Initialized
DEBUG - 2011-08-06 19:11:16 --> Router Class Initialized
DEBUG - 2011-08-06 19:11:16 --> Output Class Initialized
DEBUG - 2011-08-06 19:11:16 --> Input Class Initialized
DEBUG - 2011-08-06 19:11:16 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-06 19:11:16 --> Language Class Initialized
DEBUG - 2011-08-06 19:11:16 --> Loader Class Initialized
DEBUG - 2011-08-06 19:11:16 --> Controller Class Initialized
DEBUG - 2011-08-06 19:11:16 --> Model Class Initialized
DEBUG - 2011-08-06 19:11:16 --> Model Class Initialized
DEBUG - 2011-08-06 19:11:16 --> Model Class Initialized
DEBUG - 2011-08-06 19:11:16 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-06 19:11:16 --> Database Driver Class Initialized
DEBUG - 2011-08-06 19:11:17 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-06 19:11:17 --> Helper loaded: url_helper
DEBUG - 2011-08-06 19:11:17 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-06 19:11:17 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-06 19:11:17 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-06 19:11:17 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-06 19:11:17 --> Final output sent to browser
DEBUG - 2011-08-06 19:11:17 --> Total execution time: 0.3460
DEBUG - 2011-08-06 19:11:18 --> Config Class Initialized
DEBUG - 2011-08-06 19:11:18 --> Hooks Class Initialized
DEBUG - 2011-08-06 19:11:18 --> Utf8 Class Initialized
DEBUG - 2011-08-06 19:11:18 --> UTF-8 Support Enabled
DEBUG - 2011-08-06 19:11:18 --> URI Class Initialized
DEBUG - 2011-08-06 19:11:18 --> Router Class Initialized
ERROR - 2011-08-06 19:11:18 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-06 19:11:32 --> Config Class Initialized
DEBUG - 2011-08-06 19:11:32 --> Hooks Class Initialized
DEBUG - 2011-08-06 19:11:32 --> Utf8 Class Initialized
DEBUG - 2011-08-06 19:11:32 --> UTF-8 Support Enabled
DEBUG - 2011-08-06 19:11:32 --> URI Class Initialized
DEBUG - 2011-08-06 19:11:32 --> Router Class Initialized
DEBUG - 2011-08-06 19:11:32 --> Output Class Initialized
DEBUG - 2011-08-06 19:11:32 --> Input Class Initialized
DEBUG - 2011-08-06 19:11:32 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-06 19:11:32 --> Language Class Initialized
DEBUG - 2011-08-06 19:11:32 --> Loader Class Initialized
DEBUG - 2011-08-06 19:11:32 --> Controller Class Initialized
DEBUG - 2011-08-06 19:11:32 --> Model Class Initialized
DEBUG - 2011-08-06 19:11:32 --> Model Class Initialized
DEBUG - 2011-08-06 19:11:32 --> Model Class Initialized
DEBUG - 2011-08-06 19:11:32 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-06 19:11:32 --> Database Driver Class Initialized
DEBUG - 2011-08-06 19:11:32 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-06 19:11:32 --> Helper loaded: url_helper
DEBUG - 2011-08-06 19:11:32 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-06 19:11:32 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-06 19:11:32 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-06 19:11:32 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-06 19:11:32 --> Final output sent to browser
DEBUG - 2011-08-06 19:11:32 --> Total execution time: 0.2592
DEBUG - 2011-08-06 19:11:33 --> Config Class Initialized
DEBUG - 2011-08-06 19:11:33 --> Hooks Class Initialized
DEBUG - 2011-08-06 19:11:33 --> Utf8 Class Initialized
DEBUG - 2011-08-06 19:11:33 --> UTF-8 Support Enabled
DEBUG - 2011-08-06 19:11:33 --> URI Class Initialized
DEBUG - 2011-08-06 19:11:33 --> Router Class Initialized
ERROR - 2011-08-06 19:11:33 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-06 19:11:36 --> Config Class Initialized
DEBUG - 2011-08-06 19:11:36 --> Hooks Class Initialized
DEBUG - 2011-08-06 19:11:36 --> Utf8 Class Initialized
DEBUG - 2011-08-06 19:11:36 --> UTF-8 Support Enabled
DEBUG - 2011-08-06 19:11:36 --> URI Class Initialized
DEBUG - 2011-08-06 19:11:36 --> Router Class Initialized
ERROR - 2011-08-06 19:11:36 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-06 19:11:47 --> Config Class Initialized
DEBUG - 2011-08-06 19:11:47 --> Hooks Class Initialized
DEBUG - 2011-08-06 19:11:47 --> Utf8 Class Initialized
DEBUG - 2011-08-06 19:11:47 --> UTF-8 Support Enabled
DEBUG - 2011-08-06 19:11:47 --> URI Class Initialized
DEBUG - 2011-08-06 19:11:47 --> Router Class Initialized
DEBUG - 2011-08-06 19:11:47 --> Output Class Initialized
DEBUG - 2011-08-06 19:11:47 --> Input Class Initialized
DEBUG - 2011-08-06 19:11:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-06 19:11:47 --> Language Class Initialized
DEBUG - 2011-08-06 19:11:47 --> Loader Class Initialized
DEBUG - 2011-08-06 19:11:47 --> Controller Class Initialized
DEBUG - 2011-08-06 19:11:47 --> Model Class Initialized
DEBUG - 2011-08-06 19:11:47 --> Model Class Initialized
DEBUG - 2011-08-06 19:11:47 --> Model Class Initialized
DEBUG - 2011-08-06 19:11:47 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-06 19:11:47 --> Database Driver Class Initialized
DEBUG - 2011-08-06 19:11:48 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-06 19:11:48 --> Helper loaded: url_helper
DEBUG - 2011-08-06 19:11:48 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-06 19:11:48 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-06 19:11:48 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-06 19:11:48 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-06 19:11:48 --> Final output sent to browser
DEBUG - 2011-08-06 19:11:48 --> Total execution time: 0.2479
DEBUG - 2011-08-06 19:11:50 --> Config Class Initialized
DEBUG - 2011-08-06 19:11:50 --> Hooks Class Initialized
DEBUG - 2011-08-06 19:11:50 --> Utf8 Class Initialized
DEBUG - 2011-08-06 19:11:50 --> UTF-8 Support Enabled
DEBUG - 2011-08-06 19:11:50 --> URI Class Initialized
DEBUG - 2011-08-06 19:11:50 --> Router Class Initialized
ERROR - 2011-08-06 19:11:50 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-06 19:12:06 --> Config Class Initialized
DEBUG - 2011-08-06 19:12:06 --> Hooks Class Initialized
DEBUG - 2011-08-06 19:12:06 --> Utf8 Class Initialized
DEBUG - 2011-08-06 19:12:06 --> UTF-8 Support Enabled
DEBUG - 2011-08-06 19:12:06 --> URI Class Initialized
DEBUG - 2011-08-06 19:12:06 --> Router Class Initialized
DEBUG - 2011-08-06 19:12:06 --> Output Class Initialized
DEBUG - 2011-08-06 19:12:06 --> Input Class Initialized
DEBUG - 2011-08-06 19:12:06 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-06 19:12:06 --> Language Class Initialized
DEBUG - 2011-08-06 19:12:06 --> Loader Class Initialized
DEBUG - 2011-08-06 19:12:06 --> Controller Class Initialized
DEBUG - 2011-08-06 19:12:06 --> Model Class Initialized
DEBUG - 2011-08-06 19:12:06 --> Model Class Initialized
DEBUG - 2011-08-06 19:12:06 --> Model Class Initialized
DEBUG - 2011-08-06 19:12:06 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-06 19:12:06 --> Database Driver Class Initialized
DEBUG - 2011-08-06 19:12:06 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-06 19:12:06 --> Helper loaded: url_helper
DEBUG - 2011-08-06 19:12:06 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-06 19:12:06 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-06 19:12:06 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-06 19:12:06 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-06 19:12:06 --> Final output sent to browser
DEBUG - 2011-08-06 19:12:06 --> Total execution time: 0.2292
DEBUG - 2011-08-06 19:12:07 --> Config Class Initialized
DEBUG - 2011-08-06 19:12:07 --> Hooks Class Initialized
DEBUG - 2011-08-06 19:12:07 --> Utf8 Class Initialized
DEBUG - 2011-08-06 19:12:07 --> UTF-8 Support Enabled
DEBUG - 2011-08-06 19:12:07 --> URI Class Initialized
DEBUG - 2011-08-06 19:12:07 --> Router Class Initialized
ERROR - 2011-08-06 19:12:07 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-06 19:12:24 --> Config Class Initialized
DEBUG - 2011-08-06 19:12:24 --> Hooks Class Initialized
DEBUG - 2011-08-06 19:12:24 --> Utf8 Class Initialized
DEBUG - 2011-08-06 19:12:24 --> UTF-8 Support Enabled
DEBUG - 2011-08-06 19:12:24 --> URI Class Initialized
DEBUG - 2011-08-06 19:12:24 --> Router Class Initialized
DEBUG - 2011-08-06 19:12:24 --> Output Class Initialized
DEBUG - 2011-08-06 19:12:24 --> Input Class Initialized
DEBUG - 2011-08-06 19:12:24 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-06 19:12:24 --> Language Class Initialized
DEBUG - 2011-08-06 19:12:24 --> Loader Class Initialized
DEBUG - 2011-08-06 19:12:24 --> Controller Class Initialized
DEBUG - 2011-08-06 19:12:24 --> Model Class Initialized
DEBUG - 2011-08-06 19:12:24 --> Model Class Initialized
DEBUG - 2011-08-06 19:12:24 --> Model Class Initialized
DEBUG - 2011-08-06 19:12:24 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-06 19:12:24 --> Database Driver Class Initialized
DEBUG - 2011-08-06 19:12:25 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-06 19:12:25 --> Helper loaded: url_helper
DEBUG - 2011-08-06 19:12:25 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-06 19:12:25 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-06 19:12:25 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-06 19:12:25 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-06 19:12:25 --> Final output sent to browser
DEBUG - 2011-08-06 19:12:25 --> Total execution time: 0.0645
DEBUG - 2011-08-06 19:12:27 --> Config Class Initialized
DEBUG - 2011-08-06 19:12:27 --> Hooks Class Initialized
DEBUG - 2011-08-06 19:12:27 --> Utf8 Class Initialized
DEBUG - 2011-08-06 19:12:27 --> UTF-8 Support Enabled
DEBUG - 2011-08-06 19:12:27 --> URI Class Initialized
DEBUG - 2011-08-06 19:12:27 --> Router Class Initialized
ERROR - 2011-08-06 19:12:27 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-06 19:12:35 --> Config Class Initialized
DEBUG - 2011-08-06 19:12:35 --> Hooks Class Initialized
DEBUG - 2011-08-06 19:12:35 --> Utf8 Class Initialized
DEBUG - 2011-08-06 19:12:35 --> UTF-8 Support Enabled
DEBUG - 2011-08-06 19:12:35 --> URI Class Initialized
DEBUG - 2011-08-06 19:12:35 --> Router Class Initialized
DEBUG - 2011-08-06 19:12:35 --> Output Class Initialized
DEBUG - 2011-08-06 19:12:35 --> Input Class Initialized
DEBUG - 2011-08-06 19:12:35 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-06 19:12:35 --> Language Class Initialized
DEBUG - 2011-08-06 19:12:35 --> Loader Class Initialized
DEBUG - 2011-08-06 19:12:35 --> Controller Class Initialized
DEBUG - 2011-08-06 19:12:35 --> Model Class Initialized
DEBUG - 2011-08-06 19:12:35 --> Model Class Initialized
DEBUG - 2011-08-06 19:12:35 --> Model Class Initialized
DEBUG - 2011-08-06 19:12:35 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-06 19:12:35 --> Database Driver Class Initialized
DEBUG - 2011-08-06 19:12:35 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-06 19:12:35 --> Helper loaded: url_helper
DEBUG - 2011-08-06 19:12:35 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-06 19:12:35 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-06 19:12:35 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-06 19:12:35 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-06 19:12:35 --> Final output sent to browser
DEBUG - 2011-08-06 19:12:35 --> Total execution time: 0.0436
DEBUG - 2011-08-06 19:12:38 --> Config Class Initialized
DEBUG - 2011-08-06 19:12:38 --> Hooks Class Initialized
DEBUG - 2011-08-06 19:12:38 --> Utf8 Class Initialized
DEBUG - 2011-08-06 19:12:38 --> UTF-8 Support Enabled
DEBUG - 2011-08-06 19:12:38 --> URI Class Initialized
DEBUG - 2011-08-06 19:12:38 --> Router Class Initialized
ERROR - 2011-08-06 19:12:38 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-06 19:12:44 --> Config Class Initialized
DEBUG - 2011-08-06 19:12:44 --> Hooks Class Initialized
DEBUG - 2011-08-06 19:12:44 --> Utf8 Class Initialized
DEBUG - 2011-08-06 19:12:44 --> UTF-8 Support Enabled
DEBUG - 2011-08-06 19:12:44 --> URI Class Initialized
DEBUG - 2011-08-06 19:12:44 --> Router Class Initialized
DEBUG - 2011-08-06 19:12:44 --> Output Class Initialized
DEBUG - 2011-08-06 19:12:44 --> Input Class Initialized
DEBUG - 2011-08-06 19:12:44 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-06 19:12:44 --> Language Class Initialized
DEBUG - 2011-08-06 19:12:44 --> Loader Class Initialized
DEBUG - 2011-08-06 19:12:44 --> Controller Class Initialized
DEBUG - 2011-08-06 19:12:44 --> Model Class Initialized
DEBUG - 2011-08-06 19:12:44 --> Model Class Initialized
DEBUG - 2011-08-06 19:12:44 --> Model Class Initialized
DEBUG - 2011-08-06 19:12:44 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-06 19:12:44 --> Database Driver Class Initialized
DEBUG - 2011-08-06 19:12:44 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-06 19:12:44 --> Helper loaded: url_helper
DEBUG - 2011-08-06 19:12:44 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-06 19:12:44 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-06 19:12:44 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-06 19:12:44 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-06 19:12:44 --> Final output sent to browser
DEBUG - 2011-08-06 19:12:44 --> Total execution time: 0.3015
DEBUG - 2011-08-06 19:12:46 --> Config Class Initialized
DEBUG - 2011-08-06 19:12:46 --> Hooks Class Initialized
DEBUG - 2011-08-06 19:12:46 --> Utf8 Class Initialized
DEBUG - 2011-08-06 19:12:46 --> UTF-8 Support Enabled
DEBUG - 2011-08-06 19:12:46 --> URI Class Initialized
DEBUG - 2011-08-06 19:12:46 --> Router Class Initialized
ERROR - 2011-08-06 19:12:46 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-06 19:12:52 --> Config Class Initialized
DEBUG - 2011-08-06 19:12:52 --> Hooks Class Initialized
DEBUG - 2011-08-06 19:12:52 --> Utf8 Class Initialized
DEBUG - 2011-08-06 19:12:52 --> UTF-8 Support Enabled
DEBUG - 2011-08-06 19:12:52 --> URI Class Initialized
DEBUG - 2011-08-06 19:12:52 --> Router Class Initialized
DEBUG - 2011-08-06 19:12:52 --> Output Class Initialized
DEBUG - 2011-08-06 19:12:52 --> Input Class Initialized
DEBUG - 2011-08-06 19:12:52 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-06 19:12:52 --> Language Class Initialized
DEBUG - 2011-08-06 19:12:52 --> Loader Class Initialized
DEBUG - 2011-08-06 19:12:52 --> Controller Class Initialized
DEBUG - 2011-08-06 19:12:52 --> Model Class Initialized
DEBUG - 2011-08-06 19:12:52 --> Model Class Initialized
DEBUG - 2011-08-06 19:12:52 --> Model Class Initialized
DEBUG - 2011-08-06 19:12:52 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-06 19:12:52 --> Database Driver Class Initialized
DEBUG - 2011-08-06 19:12:53 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-06 19:12:53 --> Helper loaded: url_helper
DEBUG - 2011-08-06 19:12:53 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-06 19:12:53 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-06 19:12:53 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-06 19:12:53 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-06 19:12:53 --> Final output sent to browser
DEBUG - 2011-08-06 19:12:53 --> Total execution time: 0.2439
DEBUG - 2011-08-06 19:12:54 --> Config Class Initialized
DEBUG - 2011-08-06 19:12:54 --> Hooks Class Initialized
DEBUG - 2011-08-06 19:12:54 --> Utf8 Class Initialized
DEBUG - 2011-08-06 19:12:54 --> UTF-8 Support Enabled
DEBUG - 2011-08-06 19:12:54 --> URI Class Initialized
DEBUG - 2011-08-06 19:12:54 --> Router Class Initialized
ERROR - 2011-08-06 19:12:54 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-06 19:59:43 --> Config Class Initialized
DEBUG - 2011-08-06 19:59:43 --> Hooks Class Initialized
DEBUG - 2011-08-06 19:59:43 --> Utf8 Class Initialized
DEBUG - 2011-08-06 19:59:43 --> UTF-8 Support Enabled
DEBUG - 2011-08-06 19:59:43 --> URI Class Initialized
DEBUG - 2011-08-06 19:59:43 --> Router Class Initialized
DEBUG - 2011-08-06 19:59:43 --> Output Class Initialized
DEBUG - 2011-08-06 19:59:43 --> Input Class Initialized
DEBUG - 2011-08-06 19:59:43 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-06 19:59:43 --> Language Class Initialized
DEBUG - 2011-08-06 19:59:43 --> Loader Class Initialized
DEBUG - 2011-08-06 19:59:43 --> Controller Class Initialized
ERROR - 2011-08-06 19:59:43 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-06 19:59:43 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-06 19:59:43 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-06 19:59:43 --> Model Class Initialized
DEBUG - 2011-08-06 19:59:43 --> Model Class Initialized
DEBUG - 2011-08-06 19:59:43 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-06 19:59:43 --> Database Driver Class Initialized
DEBUG - 2011-08-06 19:59:43 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-06 19:59:43 --> Helper loaded: url_helper
DEBUG - 2011-08-06 19:59:43 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-06 19:59:43 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-06 19:59:43 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-06 19:59:43 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-06 19:59:43 --> Final output sent to browser
DEBUG - 2011-08-06 19:59:43 --> Total execution time: 0.0734
DEBUG - 2011-08-06 19:59:45 --> Config Class Initialized
DEBUG - 2011-08-06 19:59:45 --> Hooks Class Initialized
DEBUG - 2011-08-06 19:59:45 --> Utf8 Class Initialized
DEBUG - 2011-08-06 19:59:45 --> UTF-8 Support Enabled
DEBUG - 2011-08-06 19:59:45 --> URI Class Initialized
DEBUG - 2011-08-06 19:59:45 --> Router Class Initialized
DEBUG - 2011-08-06 19:59:45 --> Output Class Initialized
DEBUG - 2011-08-06 19:59:45 --> Input Class Initialized
DEBUG - 2011-08-06 19:59:45 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-06 19:59:45 --> Language Class Initialized
DEBUG - 2011-08-06 19:59:45 --> Loader Class Initialized
DEBUG - 2011-08-06 19:59:45 --> Controller Class Initialized
DEBUG - 2011-08-06 19:59:45 --> Model Class Initialized
DEBUG - 2011-08-06 19:59:45 --> Model Class Initialized
DEBUG - 2011-08-06 19:59:45 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-06 19:59:45 --> Database Driver Class Initialized
DEBUG - 2011-08-06 19:59:45 --> Final output sent to browser
DEBUG - 2011-08-06 19:59:45 --> Total execution time: 0.7422
DEBUG - 2011-08-06 19:59:58 --> Config Class Initialized
DEBUG - 2011-08-06 19:59:58 --> Hooks Class Initialized
DEBUG - 2011-08-06 19:59:58 --> Utf8 Class Initialized
DEBUG - 2011-08-06 19:59:58 --> UTF-8 Support Enabled
DEBUG - 2011-08-06 19:59:58 --> URI Class Initialized
DEBUG - 2011-08-06 19:59:58 --> Router Class Initialized
DEBUG - 2011-08-06 19:59:58 --> Output Class Initialized
DEBUG - 2011-08-06 19:59:58 --> Input Class Initialized
DEBUG - 2011-08-06 19:59:58 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-06 19:59:58 --> Language Class Initialized
DEBUG - 2011-08-06 19:59:58 --> Loader Class Initialized
DEBUG - 2011-08-06 19:59:58 --> Controller Class Initialized
ERROR - 2011-08-06 19:59:58 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-06 19:59:58 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-06 19:59:58 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-06 19:59:58 --> Model Class Initialized
DEBUG - 2011-08-06 19:59:58 --> Model Class Initialized
DEBUG - 2011-08-06 19:59:58 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-06 19:59:58 --> Database Driver Class Initialized
DEBUG - 2011-08-06 19:59:58 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-06 19:59:58 --> Helper loaded: url_helper
DEBUG - 2011-08-06 19:59:58 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-06 19:59:58 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-06 19:59:58 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-06 19:59:58 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-06 19:59:58 --> Final output sent to browser
DEBUG - 2011-08-06 19:59:58 --> Total execution time: 0.0276
DEBUG - 2011-08-06 20:00:00 --> Config Class Initialized
DEBUG - 2011-08-06 20:00:00 --> Hooks Class Initialized
DEBUG - 2011-08-06 20:00:00 --> Utf8 Class Initialized
DEBUG - 2011-08-06 20:00:00 --> UTF-8 Support Enabled
DEBUG - 2011-08-06 20:00:00 --> URI Class Initialized
DEBUG - 2011-08-06 20:00:00 --> Router Class Initialized
DEBUG - 2011-08-06 20:00:00 --> Output Class Initialized
DEBUG - 2011-08-06 20:00:00 --> Input Class Initialized
DEBUG - 2011-08-06 20:00:00 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-06 20:00:00 --> Language Class Initialized
DEBUG - 2011-08-06 20:00:00 --> Loader Class Initialized
DEBUG - 2011-08-06 20:00:00 --> Controller Class Initialized
DEBUG - 2011-08-06 20:00:00 --> Model Class Initialized
DEBUG - 2011-08-06 20:00:00 --> Model Class Initialized
DEBUG - 2011-08-06 20:00:00 --> Model Class Initialized
DEBUG - 2011-08-06 20:00:00 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-06 20:00:00 --> Database Driver Class Initialized
DEBUG - 2011-08-06 20:00:00 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-06 20:00:00 --> Helper loaded: url_helper
DEBUG - 2011-08-06 20:00:00 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-06 20:00:00 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-06 20:00:00 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-06 20:00:00 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-06 20:00:00 --> Final output sent to browser
DEBUG - 2011-08-06 20:00:00 --> Total execution time: 0.2303
DEBUG - 2011-08-06 20:00:01 --> Config Class Initialized
DEBUG - 2011-08-06 20:00:02 --> Hooks Class Initialized
DEBUG - 2011-08-06 20:00:02 --> Utf8 Class Initialized
DEBUG - 2011-08-06 20:00:02 --> UTF-8 Support Enabled
DEBUG - 2011-08-06 20:00:02 --> URI Class Initialized
DEBUG - 2011-08-06 20:00:02 --> Router Class Initialized
DEBUG - 2011-08-06 20:00:02 --> Output Class Initialized
DEBUG - 2011-08-06 20:00:02 --> Input Class Initialized
DEBUG - 2011-08-06 20:00:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-06 20:00:02 --> Language Class Initialized
DEBUG - 2011-08-06 20:00:02 --> Loader Class Initialized
DEBUG - 2011-08-06 20:00:02 --> Controller Class Initialized
DEBUG - 2011-08-06 20:00:02 --> Model Class Initialized
DEBUG - 2011-08-06 20:00:02 --> Model Class Initialized
DEBUG - 2011-08-06 20:00:02 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-06 20:00:02 --> Database Driver Class Initialized
DEBUG - 2011-08-06 20:00:02 --> Final output sent to browser
DEBUG - 2011-08-06 20:00:02 --> Total execution time: 0.9567
DEBUG - 2011-08-06 20:00:05 --> Config Class Initialized
DEBUG - 2011-08-06 20:00:05 --> Hooks Class Initialized
DEBUG - 2011-08-06 20:00:05 --> Utf8 Class Initialized
DEBUG - 2011-08-06 20:00:05 --> UTF-8 Support Enabled
DEBUG - 2011-08-06 20:00:05 --> URI Class Initialized
DEBUG - 2011-08-06 20:00:05 --> Router Class Initialized
ERROR - 2011-08-06 20:00:05 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-06 20:00:09 --> Config Class Initialized
DEBUG - 2011-08-06 20:00:09 --> Hooks Class Initialized
DEBUG - 2011-08-06 20:00:09 --> Utf8 Class Initialized
DEBUG - 2011-08-06 20:00:09 --> UTF-8 Support Enabled
DEBUG - 2011-08-06 20:00:09 --> URI Class Initialized
DEBUG - 2011-08-06 20:00:09 --> Router Class Initialized
ERROR - 2011-08-06 20:00:09 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-06 20:00:10 --> Config Class Initialized
DEBUG - 2011-08-06 20:00:10 --> Hooks Class Initialized
DEBUG - 2011-08-06 20:00:10 --> Utf8 Class Initialized
DEBUG - 2011-08-06 20:00:10 --> UTF-8 Support Enabled
DEBUG - 2011-08-06 20:00:10 --> URI Class Initialized
DEBUG - 2011-08-06 20:00:10 --> Router Class Initialized
ERROR - 2011-08-06 20:00:10 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-06 20:47:26 --> Config Class Initialized
DEBUG - 2011-08-06 20:47:26 --> Hooks Class Initialized
DEBUG - 2011-08-06 20:47:26 --> Utf8 Class Initialized
DEBUG - 2011-08-06 20:47:26 --> UTF-8 Support Enabled
DEBUG - 2011-08-06 20:47:26 --> URI Class Initialized
DEBUG - 2011-08-06 20:47:26 --> Router Class Initialized
DEBUG - 2011-08-06 20:47:26 --> Output Class Initialized
DEBUG - 2011-08-06 20:47:26 --> Input Class Initialized
DEBUG - 2011-08-06 20:47:26 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-06 20:47:26 --> Language Class Initialized
DEBUG - 2011-08-06 20:47:26 --> Loader Class Initialized
DEBUG - 2011-08-06 20:47:26 --> Controller Class Initialized
DEBUG - 2011-08-06 20:47:26 --> Model Class Initialized
DEBUG - 2011-08-06 20:47:26 --> Model Class Initialized
DEBUG - 2011-08-06 20:47:26 --> Model Class Initialized
DEBUG - 2011-08-06 20:47:26 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-06 20:47:26 --> Database Driver Class Initialized
DEBUG - 2011-08-06 20:47:26 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-06 20:47:26 --> Helper loaded: url_helper
DEBUG - 2011-08-06 20:47:26 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-06 20:47:26 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-06 20:47:26 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-06 20:47:26 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-06 20:47:26 --> Final output sent to browser
DEBUG - 2011-08-06 20:47:26 --> Total execution time: 0.3109
DEBUG - 2011-08-06 21:34:40 --> Config Class Initialized
DEBUG - 2011-08-06 21:34:40 --> Hooks Class Initialized
DEBUG - 2011-08-06 21:34:40 --> Utf8 Class Initialized
DEBUG - 2011-08-06 21:34:40 --> UTF-8 Support Enabled
DEBUG - 2011-08-06 21:34:40 --> URI Class Initialized
DEBUG - 2011-08-06 21:34:40 --> Router Class Initialized
ERROR - 2011-08-06 21:34:40 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-08-06 21:34:42 --> Config Class Initialized
DEBUG - 2011-08-06 21:34:42 --> Hooks Class Initialized
DEBUG - 2011-08-06 21:34:42 --> Utf8 Class Initialized
DEBUG - 2011-08-06 21:34:42 --> UTF-8 Support Enabled
DEBUG - 2011-08-06 21:34:42 --> URI Class Initialized
DEBUG - 2011-08-06 21:34:42 --> Router Class Initialized
DEBUG - 2011-08-06 21:34:42 --> No URI present. Default controller set.
DEBUG - 2011-08-06 21:34:42 --> Output Class Initialized
DEBUG - 2011-08-06 21:34:42 --> Input Class Initialized
DEBUG - 2011-08-06 21:34:42 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-06 21:34:42 --> Language Class Initialized
DEBUG - 2011-08-06 21:34:42 --> Loader Class Initialized
DEBUG - 2011-08-06 21:34:42 --> Controller Class Initialized
DEBUG - 2011-08-06 21:34:42 --> File loaded: application/views/splash/main.php
DEBUG - 2011-08-06 21:34:42 --> Helper loaded: url_helper
DEBUG - 2011-08-06 21:34:42 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-06 21:34:42 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-06 21:34:42 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-06 21:34:42 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-06 21:34:42 --> Final output sent to browser
DEBUG - 2011-08-06 21:34:42 --> Total execution time: 0.0809
DEBUG - 2011-08-06 21:59:30 --> Config Class Initialized
DEBUG - 2011-08-06 21:59:30 --> Hooks Class Initialized
DEBUG - 2011-08-06 21:59:30 --> Utf8 Class Initialized
DEBUG - 2011-08-06 21:59:30 --> UTF-8 Support Enabled
DEBUG - 2011-08-06 21:59:30 --> URI Class Initialized
DEBUG - 2011-08-06 21:59:30 --> Router Class Initialized
ERROR - 2011-08-06 21:59:30 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-08-06 23:23:21 --> Config Class Initialized
DEBUG - 2011-08-06 23:23:21 --> Hooks Class Initialized
DEBUG - 2011-08-06 23:23:21 --> Utf8 Class Initialized
DEBUG - 2011-08-06 23:23:21 --> UTF-8 Support Enabled
DEBUG - 2011-08-06 23:23:21 --> URI Class Initialized
DEBUG - 2011-08-06 23:23:21 --> Router Class Initialized
ERROR - 2011-08-06 23:23:21 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-08-06 23:23:21 --> Config Class Initialized
DEBUG - 2011-08-06 23:23:21 --> Hooks Class Initialized
DEBUG - 2011-08-06 23:23:21 --> Utf8 Class Initialized
DEBUG - 2011-08-06 23:23:21 --> UTF-8 Support Enabled
DEBUG - 2011-08-06 23:23:21 --> URI Class Initialized
DEBUG - 2011-08-06 23:23:21 --> Router Class Initialized
DEBUG - 2011-08-06 23:23:21 --> Output Class Initialized
DEBUG - 2011-08-06 23:23:21 --> Input Class Initialized
DEBUG - 2011-08-06 23:23:21 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-06 23:23:21 --> Language Class Initialized
DEBUG - 2011-08-06 23:23:21 --> Loader Class Initialized
DEBUG - 2011-08-06 23:23:21 --> Controller Class Initialized
DEBUG - 2011-08-06 23:23:21 --> Model Class Initialized
DEBUG - 2011-08-06 23:23:21 --> Model Class Initialized
DEBUG - 2011-08-06 23:23:21 --> Model Class Initialized
DEBUG - 2011-08-06 23:23:21 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-06 23:23:21 --> Database Driver Class Initialized
DEBUG - 2011-08-06 23:23:22 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-06 23:23:22 --> Helper loaded: url_helper
DEBUG - 2011-08-06 23:23:22 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-06 23:23:22 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-06 23:23:22 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-06 23:23:22 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-06 23:23:22 --> Final output sent to browser
DEBUG - 2011-08-06 23:23:22 --> Total execution time: 0.2812

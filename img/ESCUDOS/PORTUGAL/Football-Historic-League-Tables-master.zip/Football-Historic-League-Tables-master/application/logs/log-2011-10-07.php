<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2011-10-07 00:19:52 --> Config Class Initialized
DEBUG - 2011-10-07 00:19:52 --> Hooks Class Initialized
DEBUG - 2011-10-07 00:19:52 --> Utf8 Class Initialized
DEBUG - 2011-10-07 00:19:52 --> UTF-8 Support Enabled
DEBUG - 2011-10-07 00:19:52 --> URI Class Initialized
DEBUG - 2011-10-07 00:19:52 --> Router Class Initialized
ERROR - 2011-10-07 00:19:52 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-10-07 00:20:36 --> Config Class Initialized
DEBUG - 2011-10-07 00:20:36 --> Hooks Class Initialized
DEBUG - 2011-10-07 00:20:36 --> Utf8 Class Initialized
DEBUG - 2011-10-07 00:20:36 --> UTF-8 Support Enabled
DEBUG - 2011-10-07 00:20:36 --> URI Class Initialized
DEBUG - 2011-10-07 00:20:36 --> Router Class Initialized
DEBUG - 2011-10-07 00:20:36 --> Output Class Initialized
DEBUG - 2011-10-07 00:20:36 --> Input Class Initialized
DEBUG - 2011-10-07 00:20:36 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-07 00:20:36 --> Language Class Initialized
DEBUG - 2011-10-07 00:20:36 --> Loader Class Initialized
DEBUG - 2011-10-07 00:20:36 --> Controller Class Initialized
ERROR - 2011-10-07 00:20:36 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-10-07 00:20:36 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-10-07 00:20:36 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-07 00:20:36 --> Model Class Initialized
DEBUG - 2011-10-07 00:20:36 --> Model Class Initialized
DEBUG - 2011-10-07 00:20:36 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-07 00:20:36 --> Database Driver Class Initialized
DEBUG - 2011-10-07 00:20:36 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-07 00:20:36 --> Helper loaded: url_helper
DEBUG - 2011-10-07 00:20:36 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-07 00:20:36 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-07 00:20:36 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-07 00:20:36 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-07 00:20:36 --> Final output sent to browser
DEBUG - 2011-10-07 00:20:36 --> Total execution time: 0.6099
DEBUG - 2011-10-07 00:34:45 --> Config Class Initialized
DEBUG - 2011-10-07 00:34:45 --> Hooks Class Initialized
DEBUG - 2011-10-07 00:34:45 --> Utf8 Class Initialized
DEBUG - 2011-10-07 00:34:45 --> UTF-8 Support Enabled
DEBUG - 2011-10-07 00:34:45 --> URI Class Initialized
DEBUG - 2011-10-07 00:34:45 --> Router Class Initialized
DEBUG - 2011-10-07 00:34:45 --> Output Class Initialized
DEBUG - 2011-10-07 00:34:45 --> Input Class Initialized
DEBUG - 2011-10-07 00:34:45 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-07 00:34:45 --> Language Class Initialized
DEBUG - 2011-10-07 00:34:45 --> Loader Class Initialized
DEBUG - 2011-10-07 00:34:45 --> Controller Class Initialized
ERROR - 2011-10-07 00:34:45 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-10-07 00:34:45 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-10-07 00:34:45 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-07 00:34:45 --> Model Class Initialized
DEBUG - 2011-10-07 00:34:45 --> Model Class Initialized
DEBUG - 2011-10-07 00:34:45 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-07 00:34:45 --> Database Driver Class Initialized
DEBUG - 2011-10-07 00:34:45 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-07 00:34:45 --> Helper loaded: url_helper
DEBUG - 2011-10-07 00:34:45 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-07 00:34:45 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-07 00:34:45 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-07 00:34:45 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-07 00:34:45 --> Final output sent to browser
DEBUG - 2011-10-07 00:34:45 --> Total execution time: 0.1532
DEBUG - 2011-10-07 00:34:46 --> Config Class Initialized
DEBUG - 2011-10-07 00:34:46 --> Hooks Class Initialized
DEBUG - 2011-10-07 00:34:46 --> Utf8 Class Initialized
DEBUG - 2011-10-07 00:34:46 --> UTF-8 Support Enabled
DEBUG - 2011-10-07 00:34:46 --> URI Class Initialized
DEBUG - 2011-10-07 00:34:46 --> Router Class Initialized
DEBUG - 2011-10-07 00:34:46 --> Output Class Initialized
DEBUG - 2011-10-07 00:34:46 --> Input Class Initialized
DEBUG - 2011-10-07 00:34:46 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-07 00:34:46 --> Language Class Initialized
DEBUG - 2011-10-07 00:34:46 --> Loader Class Initialized
DEBUG - 2011-10-07 00:34:46 --> Controller Class Initialized
DEBUG - 2011-10-07 00:34:46 --> Model Class Initialized
DEBUG - 2011-10-07 00:34:46 --> Model Class Initialized
DEBUG - 2011-10-07 00:34:46 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-07 00:34:46 --> Database Driver Class Initialized
DEBUG - 2011-10-07 00:34:47 --> Final output sent to browser
DEBUG - 2011-10-07 00:34:47 --> Total execution time: 0.8498
DEBUG - 2011-10-07 00:34:48 --> Config Class Initialized
DEBUG - 2011-10-07 00:34:48 --> Hooks Class Initialized
DEBUG - 2011-10-07 00:34:48 --> Utf8 Class Initialized
DEBUG - 2011-10-07 00:34:48 --> UTF-8 Support Enabled
DEBUG - 2011-10-07 00:34:48 --> URI Class Initialized
DEBUG - 2011-10-07 00:34:48 --> Router Class Initialized
ERROR - 2011-10-07 00:34:48 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-07 00:35:23 --> Config Class Initialized
DEBUG - 2011-10-07 00:35:23 --> Hooks Class Initialized
DEBUG - 2011-10-07 00:35:23 --> Utf8 Class Initialized
DEBUG - 2011-10-07 00:35:23 --> UTF-8 Support Enabled
DEBUG - 2011-10-07 00:35:23 --> URI Class Initialized
DEBUG - 2011-10-07 00:35:23 --> Router Class Initialized
DEBUG - 2011-10-07 00:35:23 --> Output Class Initialized
DEBUG - 2011-10-07 00:35:23 --> Input Class Initialized
DEBUG - 2011-10-07 00:35:23 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-07 00:35:23 --> Language Class Initialized
DEBUG - 2011-10-07 00:35:23 --> Loader Class Initialized
DEBUG - 2011-10-07 00:35:23 --> Controller Class Initialized
ERROR - 2011-10-07 00:35:23 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-10-07 00:35:23 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-10-07 00:35:23 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-07 00:35:23 --> Model Class Initialized
DEBUG - 2011-10-07 00:35:23 --> Model Class Initialized
DEBUG - 2011-10-07 00:35:23 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-07 00:35:23 --> Database Driver Class Initialized
DEBUG - 2011-10-07 00:35:23 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-07 00:35:23 --> Helper loaded: url_helper
DEBUG - 2011-10-07 00:35:23 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-07 00:35:23 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-07 00:35:23 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-07 00:35:23 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-07 00:35:23 --> Final output sent to browser
DEBUG - 2011-10-07 00:35:23 --> Total execution time: 0.0347
DEBUG - 2011-10-07 00:35:23 --> Config Class Initialized
DEBUG - 2011-10-07 00:35:23 --> Hooks Class Initialized
DEBUG - 2011-10-07 00:35:23 --> Utf8 Class Initialized
DEBUG - 2011-10-07 00:35:23 --> UTF-8 Support Enabled
DEBUG - 2011-10-07 00:35:23 --> URI Class Initialized
DEBUG - 2011-10-07 00:35:23 --> Router Class Initialized
DEBUG - 2011-10-07 00:35:23 --> Output Class Initialized
DEBUG - 2011-10-07 00:35:23 --> Input Class Initialized
DEBUG - 2011-10-07 00:35:23 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-07 00:35:23 --> Language Class Initialized
DEBUG - 2011-10-07 00:35:23 --> Loader Class Initialized
DEBUG - 2011-10-07 00:35:23 --> Controller Class Initialized
DEBUG - 2011-10-07 00:35:23 --> Model Class Initialized
DEBUG - 2011-10-07 00:35:23 --> Model Class Initialized
DEBUG - 2011-10-07 00:35:23 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-07 00:35:23 --> Database Driver Class Initialized
DEBUG - 2011-10-07 00:35:24 --> Config Class Initialized
DEBUG - 2011-10-07 00:35:24 --> Hooks Class Initialized
DEBUG - 2011-10-07 00:35:24 --> Utf8 Class Initialized
DEBUG - 2011-10-07 00:35:24 --> UTF-8 Support Enabled
DEBUG - 2011-10-07 00:35:24 --> URI Class Initialized
DEBUG - 2011-10-07 00:35:24 --> Final output sent to browser
DEBUG - 2011-10-07 00:35:24 --> Router Class Initialized
DEBUG - 2011-10-07 00:35:24 --> Total execution time: 0.6109
ERROR - 2011-10-07 00:35:24 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-10-07 00:35:24 --> Config Class Initialized
DEBUG - 2011-10-07 00:35:24 --> Hooks Class Initialized
DEBUG - 2011-10-07 00:35:24 --> Utf8 Class Initialized
DEBUG - 2011-10-07 00:35:24 --> UTF-8 Support Enabled
DEBUG - 2011-10-07 00:35:24 --> URI Class Initialized
DEBUG - 2011-10-07 00:35:24 --> Router Class Initialized
DEBUG - 2011-10-07 00:35:24 --> Output Class Initialized
DEBUG - 2011-10-07 00:35:24 --> Input Class Initialized
DEBUG - 2011-10-07 00:35:24 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-07 00:35:24 --> Language Class Initialized
DEBUG - 2011-10-07 00:35:24 --> Loader Class Initialized
DEBUG - 2011-10-07 00:35:24 --> Controller Class Initialized
ERROR - 2011-10-07 00:35:24 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-10-07 00:35:24 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-10-07 00:35:24 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-07 00:35:24 --> Model Class Initialized
DEBUG - 2011-10-07 00:35:24 --> Model Class Initialized
DEBUG - 2011-10-07 00:35:24 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-07 00:35:24 --> Database Driver Class Initialized
DEBUG - 2011-10-07 00:35:24 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-07 00:35:24 --> Helper loaded: url_helper
DEBUG - 2011-10-07 00:35:24 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-07 00:35:24 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-07 00:35:24 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-07 00:35:24 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-07 00:35:24 --> Final output sent to browser
DEBUG - 2011-10-07 00:35:24 --> Total execution time: 0.0442
DEBUG - 2011-10-07 00:35:25 --> Config Class Initialized
DEBUG - 2011-10-07 00:35:25 --> Hooks Class Initialized
DEBUG - 2011-10-07 00:35:25 --> Utf8 Class Initialized
DEBUG - 2011-10-07 00:35:25 --> UTF-8 Support Enabled
DEBUG - 2011-10-07 00:35:25 --> URI Class Initialized
DEBUG - 2011-10-07 00:35:25 --> Router Class Initialized
ERROR - 2011-10-07 00:35:25 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-07 00:35:50 --> Config Class Initialized
DEBUG - 2011-10-07 00:35:50 --> Hooks Class Initialized
DEBUG - 2011-10-07 00:35:50 --> Utf8 Class Initialized
DEBUG - 2011-10-07 00:35:50 --> UTF-8 Support Enabled
DEBUG - 2011-10-07 00:35:50 --> URI Class Initialized
DEBUG - 2011-10-07 00:35:50 --> Router Class Initialized
DEBUG - 2011-10-07 00:35:50 --> Output Class Initialized
DEBUG - 2011-10-07 00:35:50 --> Input Class Initialized
DEBUG - 2011-10-07 00:35:50 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-07 00:35:50 --> Language Class Initialized
DEBUG - 2011-10-07 00:35:50 --> Loader Class Initialized
DEBUG - 2011-10-07 00:35:50 --> Controller Class Initialized
ERROR - 2011-10-07 00:35:50 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-10-07 00:35:50 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-10-07 00:35:50 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-07 00:35:50 --> Model Class Initialized
DEBUG - 2011-10-07 00:35:50 --> Model Class Initialized
DEBUG - 2011-10-07 00:35:50 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-07 00:35:50 --> Database Driver Class Initialized
DEBUG - 2011-10-07 00:35:50 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-07 00:35:50 --> Helper loaded: url_helper
DEBUG - 2011-10-07 00:35:50 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-07 00:35:50 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-07 00:35:50 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-07 00:35:50 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-07 00:35:50 --> Final output sent to browser
DEBUG - 2011-10-07 00:35:50 --> Total execution time: 0.0316
DEBUG - 2011-10-07 00:35:50 --> Config Class Initialized
DEBUG - 2011-10-07 00:35:50 --> Hooks Class Initialized
DEBUG - 2011-10-07 00:35:50 --> Utf8 Class Initialized
DEBUG - 2011-10-07 00:35:50 --> UTF-8 Support Enabled
DEBUG - 2011-10-07 00:35:50 --> URI Class Initialized
DEBUG - 2011-10-07 00:35:50 --> Router Class Initialized
DEBUG - 2011-10-07 00:35:50 --> Output Class Initialized
DEBUG - 2011-10-07 00:35:50 --> Input Class Initialized
DEBUG - 2011-10-07 00:35:50 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-07 00:35:50 --> Language Class Initialized
DEBUG - 2011-10-07 00:35:50 --> Loader Class Initialized
DEBUG - 2011-10-07 00:35:50 --> Controller Class Initialized
DEBUG - 2011-10-07 00:35:50 --> Model Class Initialized
DEBUG - 2011-10-07 00:35:50 --> Model Class Initialized
DEBUG - 2011-10-07 00:35:50 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-07 00:35:50 --> Database Driver Class Initialized
DEBUG - 2011-10-07 00:35:51 --> Final output sent to browser
DEBUG - 2011-10-07 00:35:51 --> Total execution time: 0.8947
DEBUG - 2011-10-07 00:35:52 --> Config Class Initialized
DEBUG - 2011-10-07 00:35:52 --> Hooks Class Initialized
DEBUG - 2011-10-07 00:35:52 --> Utf8 Class Initialized
DEBUG - 2011-10-07 00:35:52 --> UTF-8 Support Enabled
DEBUG - 2011-10-07 00:35:52 --> URI Class Initialized
DEBUG - 2011-10-07 00:35:52 --> Router Class Initialized
ERROR - 2011-10-07 00:35:52 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-07 00:36:41 --> Config Class Initialized
DEBUG - 2011-10-07 00:36:41 --> Hooks Class Initialized
DEBUG - 2011-10-07 00:36:41 --> Utf8 Class Initialized
DEBUG - 2011-10-07 00:36:41 --> UTF-8 Support Enabled
DEBUG - 2011-10-07 00:36:41 --> URI Class Initialized
DEBUG - 2011-10-07 00:36:41 --> Router Class Initialized
DEBUG - 2011-10-07 00:36:41 --> Output Class Initialized
DEBUG - 2011-10-07 00:36:41 --> Input Class Initialized
DEBUG - 2011-10-07 00:36:41 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-07 00:36:41 --> Language Class Initialized
DEBUG - 2011-10-07 00:36:41 --> Loader Class Initialized
DEBUG - 2011-10-07 00:36:41 --> Controller Class Initialized
ERROR - 2011-10-07 00:36:41 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-10-07 00:36:41 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-10-07 00:36:41 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-07 00:36:41 --> Model Class Initialized
DEBUG - 2011-10-07 00:36:41 --> Model Class Initialized
DEBUG - 2011-10-07 00:36:41 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-07 00:36:41 --> Database Driver Class Initialized
DEBUG - 2011-10-07 00:36:41 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-07 00:36:41 --> Helper loaded: url_helper
DEBUG - 2011-10-07 00:36:41 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-07 00:36:41 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-07 00:36:41 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-07 00:36:41 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-07 00:36:41 --> Final output sent to browser
DEBUG - 2011-10-07 00:36:41 --> Total execution time: 0.0370
DEBUG - 2011-10-07 00:36:41 --> Config Class Initialized
DEBUG - 2011-10-07 00:36:41 --> Hooks Class Initialized
DEBUG - 2011-10-07 00:36:41 --> Utf8 Class Initialized
DEBUG - 2011-10-07 00:36:41 --> UTF-8 Support Enabled
DEBUG - 2011-10-07 00:36:41 --> URI Class Initialized
DEBUG - 2011-10-07 00:36:41 --> Router Class Initialized
DEBUG - 2011-10-07 00:36:41 --> Output Class Initialized
DEBUG - 2011-10-07 00:36:41 --> Input Class Initialized
DEBUG - 2011-10-07 00:36:41 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-07 00:36:41 --> Language Class Initialized
DEBUG - 2011-10-07 00:36:41 --> Loader Class Initialized
DEBUG - 2011-10-07 00:36:41 --> Controller Class Initialized
ERROR - 2011-10-07 00:36:41 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-10-07 00:36:41 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-10-07 00:36:41 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-07 00:36:41 --> Model Class Initialized
DEBUG - 2011-10-07 00:36:41 --> Model Class Initialized
DEBUG - 2011-10-07 00:36:41 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-07 00:36:41 --> Database Driver Class Initialized
DEBUG - 2011-10-07 00:36:41 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-07 00:36:41 --> Helper loaded: url_helper
DEBUG - 2011-10-07 00:36:41 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-07 00:36:41 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-07 00:36:41 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-07 00:36:41 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-07 00:36:41 --> Final output sent to browser
DEBUG - 2011-10-07 00:36:41 --> Total execution time: 0.0665
DEBUG - 2011-10-07 00:36:41 --> Config Class Initialized
DEBUG - 2011-10-07 00:36:41 --> Hooks Class Initialized
DEBUG - 2011-10-07 00:36:41 --> Utf8 Class Initialized
DEBUG - 2011-10-07 00:36:41 --> UTF-8 Support Enabled
DEBUG - 2011-10-07 00:36:41 --> URI Class Initialized
DEBUG - 2011-10-07 00:36:41 --> Router Class Initialized
DEBUG - 2011-10-07 00:36:42 --> Output Class Initialized
DEBUG - 2011-10-07 00:36:42 --> Input Class Initialized
DEBUG - 2011-10-07 00:36:42 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-07 00:36:42 --> Language Class Initialized
DEBUG - 2011-10-07 00:36:42 --> Loader Class Initialized
DEBUG - 2011-10-07 00:36:42 --> Controller Class Initialized
DEBUG - 2011-10-07 00:36:42 --> Model Class Initialized
DEBUG - 2011-10-07 00:36:42 --> Model Class Initialized
DEBUG - 2011-10-07 00:36:42 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-07 00:36:42 --> Database Driver Class Initialized
DEBUG - 2011-10-07 00:36:43 --> Final output sent to browser
DEBUG - 2011-10-07 00:36:43 --> Total execution time: 1.0462
DEBUG - 2011-10-07 00:36:44 --> Config Class Initialized
DEBUG - 2011-10-07 00:36:44 --> Hooks Class Initialized
DEBUG - 2011-10-07 00:36:44 --> Utf8 Class Initialized
DEBUG - 2011-10-07 00:36:44 --> UTF-8 Support Enabled
DEBUG - 2011-10-07 00:36:44 --> URI Class Initialized
DEBUG - 2011-10-07 00:36:44 --> Router Class Initialized
ERROR - 2011-10-07 00:36:44 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-07 00:37:03 --> Config Class Initialized
DEBUG - 2011-10-07 00:37:03 --> Hooks Class Initialized
DEBUG - 2011-10-07 00:37:03 --> Utf8 Class Initialized
DEBUG - 2011-10-07 00:37:03 --> UTF-8 Support Enabled
DEBUG - 2011-10-07 00:37:03 --> URI Class Initialized
DEBUG - 2011-10-07 00:37:03 --> Router Class Initialized
DEBUG - 2011-10-07 00:37:03 --> Output Class Initialized
DEBUG - 2011-10-07 00:37:03 --> Input Class Initialized
DEBUG - 2011-10-07 00:37:03 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-07 00:37:03 --> Language Class Initialized
DEBUG - 2011-10-07 00:37:03 --> Loader Class Initialized
DEBUG - 2011-10-07 00:37:03 --> Controller Class Initialized
ERROR - 2011-10-07 00:37:03 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-10-07 00:37:03 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-10-07 00:37:03 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-07 00:37:03 --> Model Class Initialized
DEBUG - 2011-10-07 00:37:03 --> Model Class Initialized
DEBUG - 2011-10-07 00:37:03 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-07 00:37:03 --> Database Driver Class Initialized
DEBUG - 2011-10-07 00:37:03 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-07 00:37:03 --> Helper loaded: url_helper
DEBUG - 2011-10-07 00:37:03 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-07 00:37:03 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-07 00:37:03 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-07 00:37:03 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-07 00:37:03 --> Final output sent to browser
DEBUG - 2011-10-07 00:37:03 --> Total execution time: 0.0498
DEBUG - 2011-10-07 00:37:04 --> Config Class Initialized
DEBUG - 2011-10-07 00:37:04 --> Hooks Class Initialized
DEBUG - 2011-10-07 00:37:04 --> Utf8 Class Initialized
DEBUG - 2011-10-07 00:37:04 --> UTF-8 Support Enabled
DEBUG - 2011-10-07 00:37:04 --> URI Class Initialized
DEBUG - 2011-10-07 00:37:04 --> Router Class Initialized
DEBUG - 2011-10-07 00:37:04 --> Output Class Initialized
DEBUG - 2011-10-07 00:37:04 --> Input Class Initialized
DEBUG - 2011-10-07 00:37:04 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-07 00:37:04 --> Language Class Initialized
DEBUG - 2011-10-07 00:37:04 --> Loader Class Initialized
DEBUG - 2011-10-07 00:37:04 --> Controller Class Initialized
DEBUG - 2011-10-07 00:37:04 --> Model Class Initialized
DEBUG - 2011-10-07 00:37:04 --> Model Class Initialized
DEBUG - 2011-10-07 00:37:04 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-07 00:37:04 --> Database Driver Class Initialized
DEBUG - 2011-10-07 00:37:04 --> Final output sent to browser
DEBUG - 2011-10-07 00:37:04 --> Total execution time: 0.7719
DEBUG - 2011-10-07 00:37:05 --> Config Class Initialized
DEBUG - 2011-10-07 00:37:05 --> Hooks Class Initialized
DEBUG - 2011-10-07 00:37:05 --> Utf8 Class Initialized
DEBUG - 2011-10-07 00:37:05 --> UTF-8 Support Enabled
DEBUG - 2011-10-07 00:37:05 --> URI Class Initialized
DEBUG - 2011-10-07 00:37:05 --> Router Class Initialized
ERROR - 2011-10-07 00:37:05 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-07 00:37:22 --> Config Class Initialized
DEBUG - 2011-10-07 00:37:22 --> Hooks Class Initialized
DEBUG - 2011-10-07 00:37:22 --> Utf8 Class Initialized
DEBUG - 2011-10-07 00:37:22 --> UTF-8 Support Enabled
DEBUG - 2011-10-07 00:37:22 --> URI Class Initialized
DEBUG - 2011-10-07 00:37:22 --> Router Class Initialized
DEBUG - 2011-10-07 00:37:22 --> Output Class Initialized
DEBUG - 2011-10-07 00:37:22 --> Input Class Initialized
DEBUG - 2011-10-07 00:37:22 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-07 00:37:22 --> Language Class Initialized
DEBUG - 2011-10-07 00:37:22 --> Loader Class Initialized
DEBUG - 2011-10-07 00:37:22 --> Controller Class Initialized
ERROR - 2011-10-07 00:37:22 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-10-07 00:37:22 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-10-07 00:37:22 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-07 00:37:22 --> Model Class Initialized
DEBUG - 2011-10-07 00:37:22 --> Model Class Initialized
DEBUG - 2011-10-07 00:37:22 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-07 00:37:22 --> Database Driver Class Initialized
DEBUG - 2011-10-07 00:37:22 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-07 00:37:22 --> Helper loaded: url_helper
DEBUG - 2011-10-07 00:37:22 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-07 00:37:22 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-07 00:37:22 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-07 00:37:22 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-07 00:37:22 --> Final output sent to browser
DEBUG - 2011-10-07 00:37:22 --> Total execution time: 0.0345
DEBUG - 2011-10-07 00:37:22 --> Config Class Initialized
DEBUG - 2011-10-07 00:37:22 --> Hooks Class Initialized
DEBUG - 2011-10-07 00:37:22 --> Utf8 Class Initialized
DEBUG - 2011-10-07 00:37:22 --> UTF-8 Support Enabled
DEBUG - 2011-10-07 00:37:22 --> URI Class Initialized
DEBUG - 2011-10-07 00:37:22 --> Router Class Initialized
DEBUG - 2011-10-07 00:37:22 --> Output Class Initialized
DEBUG - 2011-10-07 00:37:22 --> Input Class Initialized
DEBUG - 2011-10-07 00:37:22 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-07 00:37:22 --> Language Class Initialized
DEBUG - 2011-10-07 00:37:22 --> Loader Class Initialized
DEBUG - 2011-10-07 00:37:22 --> Controller Class Initialized
DEBUG - 2011-10-07 00:37:22 --> Model Class Initialized
DEBUG - 2011-10-07 00:37:22 --> Model Class Initialized
DEBUG - 2011-10-07 00:37:22 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-07 00:37:22 --> Database Driver Class Initialized
DEBUG - 2011-10-07 00:37:23 --> Final output sent to browser
DEBUG - 2011-10-07 00:37:23 --> Total execution time: 0.6504
DEBUG - 2011-10-07 00:37:24 --> Config Class Initialized
DEBUG - 2011-10-07 00:37:24 --> Hooks Class Initialized
DEBUG - 2011-10-07 00:37:24 --> Utf8 Class Initialized
DEBUG - 2011-10-07 00:37:24 --> UTF-8 Support Enabled
DEBUG - 2011-10-07 00:37:24 --> URI Class Initialized
DEBUG - 2011-10-07 00:37:24 --> Router Class Initialized
ERROR - 2011-10-07 00:37:24 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-07 00:37:24 --> Config Class Initialized
DEBUG - 2011-10-07 00:37:24 --> Hooks Class Initialized
DEBUG - 2011-10-07 00:37:24 --> Utf8 Class Initialized
DEBUG - 2011-10-07 00:37:24 --> UTF-8 Support Enabled
DEBUG - 2011-10-07 00:37:24 --> URI Class Initialized
DEBUG - 2011-10-07 00:37:24 --> Router Class Initialized
DEBUG - 2011-10-07 00:37:24 --> Output Class Initialized
DEBUG - 2011-10-07 00:37:24 --> Input Class Initialized
DEBUG - 2011-10-07 00:37:24 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-07 00:37:24 --> Language Class Initialized
DEBUG - 2011-10-07 00:37:24 --> Loader Class Initialized
DEBUG - 2011-10-07 00:37:24 --> Controller Class Initialized
ERROR - 2011-10-07 00:37:24 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-10-07 00:37:24 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-10-07 00:37:24 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-07 00:37:24 --> Model Class Initialized
DEBUG - 2011-10-07 00:37:24 --> Model Class Initialized
DEBUG - 2011-10-07 00:37:24 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-07 00:37:24 --> Database Driver Class Initialized
DEBUG - 2011-10-07 00:37:24 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-07 00:37:24 --> Helper loaded: url_helper
DEBUG - 2011-10-07 00:37:24 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-07 00:37:24 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-07 00:37:24 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-07 00:37:24 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-07 00:37:24 --> Final output sent to browser
DEBUG - 2011-10-07 00:37:24 --> Total execution time: 0.0311
DEBUG - 2011-10-07 00:37:39 --> Config Class Initialized
DEBUG - 2011-10-07 00:37:39 --> Hooks Class Initialized
DEBUG - 2011-10-07 00:37:39 --> Utf8 Class Initialized
DEBUG - 2011-10-07 00:37:39 --> UTF-8 Support Enabled
DEBUG - 2011-10-07 00:37:39 --> URI Class Initialized
DEBUG - 2011-10-07 00:37:39 --> Router Class Initialized
DEBUG - 2011-10-07 00:37:39 --> Output Class Initialized
DEBUG - 2011-10-07 00:37:39 --> Input Class Initialized
DEBUG - 2011-10-07 00:37:39 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-07 00:37:39 --> Language Class Initialized
DEBUG - 2011-10-07 00:37:39 --> Loader Class Initialized
DEBUG - 2011-10-07 00:37:39 --> Controller Class Initialized
ERROR - 2011-10-07 00:37:39 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-10-07 00:37:39 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-10-07 00:37:39 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-07 00:37:39 --> Model Class Initialized
DEBUG - 2011-10-07 00:37:39 --> Model Class Initialized
DEBUG - 2011-10-07 00:37:39 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-07 00:37:39 --> Database Driver Class Initialized
DEBUG - 2011-10-07 00:37:39 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-07 00:37:39 --> Helper loaded: url_helper
DEBUG - 2011-10-07 00:37:39 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-07 00:37:39 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-07 00:37:39 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-07 00:37:39 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-07 00:37:39 --> Final output sent to browser
DEBUG - 2011-10-07 00:37:39 --> Total execution time: 0.0490
DEBUG - 2011-10-07 00:37:41 --> Config Class Initialized
DEBUG - 2011-10-07 00:37:41 --> Hooks Class Initialized
DEBUG - 2011-10-07 00:37:41 --> Utf8 Class Initialized
DEBUG - 2011-10-07 00:37:41 --> UTF-8 Support Enabled
DEBUG - 2011-10-07 00:37:41 --> URI Class Initialized
DEBUG - 2011-10-07 00:37:41 --> Router Class Initialized
DEBUG - 2011-10-07 00:37:41 --> Output Class Initialized
DEBUG - 2011-10-07 00:37:41 --> Input Class Initialized
DEBUG - 2011-10-07 00:37:41 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-07 00:37:41 --> Language Class Initialized
DEBUG - 2011-10-07 00:37:41 --> Loader Class Initialized
DEBUG - 2011-10-07 00:37:41 --> Controller Class Initialized
DEBUG - 2011-10-07 00:37:41 --> Model Class Initialized
DEBUG - 2011-10-07 00:37:41 --> Model Class Initialized
DEBUG - 2011-10-07 00:37:41 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-07 00:37:41 --> Database Driver Class Initialized
DEBUG - 2011-10-07 00:37:42 --> Final output sent to browser
DEBUG - 2011-10-07 00:37:42 --> Total execution time: 0.5469
DEBUG - 2011-10-07 00:37:47 --> Config Class Initialized
DEBUG - 2011-10-07 00:37:47 --> Hooks Class Initialized
DEBUG - 2011-10-07 00:37:47 --> Utf8 Class Initialized
DEBUG - 2011-10-07 00:37:47 --> UTF-8 Support Enabled
DEBUG - 2011-10-07 00:37:47 --> URI Class Initialized
DEBUG - 2011-10-07 00:37:47 --> Router Class Initialized
ERROR - 2011-10-07 00:37:47 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-07 00:37:55 --> Config Class Initialized
DEBUG - 2011-10-07 00:37:55 --> Hooks Class Initialized
DEBUG - 2011-10-07 00:37:55 --> Utf8 Class Initialized
DEBUG - 2011-10-07 00:37:55 --> UTF-8 Support Enabled
DEBUG - 2011-10-07 00:37:55 --> URI Class Initialized
DEBUG - 2011-10-07 00:37:55 --> Router Class Initialized
DEBUG - 2011-10-07 00:37:55 --> Output Class Initialized
DEBUG - 2011-10-07 00:37:55 --> Input Class Initialized
DEBUG - 2011-10-07 00:37:55 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-07 00:37:55 --> Language Class Initialized
DEBUG - 2011-10-07 00:37:55 --> Loader Class Initialized
DEBUG - 2011-10-07 00:37:55 --> Controller Class Initialized
ERROR - 2011-10-07 00:37:55 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-10-07 00:37:55 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-10-07 00:37:55 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-07 00:37:55 --> Model Class Initialized
DEBUG - 2011-10-07 00:37:55 --> Model Class Initialized
DEBUG - 2011-10-07 00:37:55 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-07 00:37:55 --> Database Driver Class Initialized
DEBUG - 2011-10-07 00:37:55 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-07 00:37:55 --> Helper loaded: url_helper
DEBUG - 2011-10-07 00:37:55 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-07 00:37:55 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-07 00:37:55 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-07 00:37:55 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-07 00:37:55 --> Final output sent to browser
DEBUG - 2011-10-07 00:37:55 --> Total execution time: 0.1637
DEBUG - 2011-10-07 00:37:56 --> Config Class Initialized
DEBUG - 2011-10-07 00:37:56 --> Hooks Class Initialized
DEBUG - 2011-10-07 00:37:56 --> Utf8 Class Initialized
DEBUG - 2011-10-07 00:37:56 --> UTF-8 Support Enabled
DEBUG - 2011-10-07 00:37:56 --> URI Class Initialized
DEBUG - 2011-10-07 00:37:56 --> Router Class Initialized
DEBUG - 2011-10-07 00:37:56 --> Output Class Initialized
DEBUG - 2011-10-07 00:37:56 --> Input Class Initialized
DEBUG - 2011-10-07 00:37:56 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-07 00:37:56 --> Language Class Initialized
DEBUG - 2011-10-07 00:37:56 --> Loader Class Initialized
DEBUG - 2011-10-07 00:37:56 --> Controller Class Initialized
DEBUG - 2011-10-07 00:37:56 --> Model Class Initialized
DEBUG - 2011-10-07 00:37:56 --> Model Class Initialized
DEBUG - 2011-10-07 00:37:56 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-07 00:37:56 --> Database Driver Class Initialized
DEBUG - 2011-10-07 00:37:58 --> Final output sent to browser
DEBUG - 2011-10-07 00:37:58 --> Total execution time: 1.4279
DEBUG - 2011-10-07 00:37:58 --> Config Class Initialized
DEBUG - 2011-10-07 00:37:58 --> Hooks Class Initialized
DEBUG - 2011-10-07 00:37:58 --> Utf8 Class Initialized
DEBUG - 2011-10-07 00:37:58 --> UTF-8 Support Enabled
DEBUG - 2011-10-07 00:37:58 --> URI Class Initialized
DEBUG - 2011-10-07 00:37:58 --> Router Class Initialized
DEBUG - 2011-10-07 00:37:58 --> Output Class Initialized
DEBUG - 2011-10-07 00:37:58 --> Input Class Initialized
DEBUG - 2011-10-07 00:37:58 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-07 00:37:58 --> Language Class Initialized
DEBUG - 2011-10-07 00:37:58 --> Loader Class Initialized
DEBUG - 2011-10-07 00:37:58 --> Controller Class Initialized
ERROR - 2011-10-07 00:37:58 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-10-07 00:37:58 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-10-07 00:37:58 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-07 00:37:58 --> Model Class Initialized
DEBUG - 2011-10-07 00:37:58 --> Model Class Initialized
DEBUG - 2011-10-07 00:37:58 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-07 00:37:58 --> Database Driver Class Initialized
DEBUG - 2011-10-07 00:37:58 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-07 00:37:58 --> Helper loaded: url_helper
DEBUG - 2011-10-07 00:37:58 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-07 00:37:58 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-07 00:37:58 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-07 00:37:58 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-07 00:37:58 --> Final output sent to browser
DEBUG - 2011-10-07 00:37:58 --> Total execution time: 0.1347
DEBUG - 2011-10-07 00:38:00 --> Config Class Initialized
DEBUG - 2011-10-07 00:38:00 --> Hooks Class Initialized
DEBUG - 2011-10-07 00:38:00 --> Utf8 Class Initialized
DEBUG - 2011-10-07 00:38:00 --> UTF-8 Support Enabled
DEBUG - 2011-10-07 00:38:00 --> URI Class Initialized
DEBUG - 2011-10-07 00:38:00 --> Router Class Initialized
ERROR - 2011-10-07 00:38:00 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-07 00:38:13 --> Config Class Initialized
DEBUG - 2011-10-07 00:38:13 --> Hooks Class Initialized
DEBUG - 2011-10-07 00:38:13 --> Utf8 Class Initialized
DEBUG - 2011-10-07 00:38:13 --> UTF-8 Support Enabled
DEBUG - 2011-10-07 00:38:13 --> URI Class Initialized
DEBUG - 2011-10-07 00:38:13 --> Router Class Initialized
DEBUG - 2011-10-07 00:38:13 --> Output Class Initialized
DEBUG - 2011-10-07 00:38:13 --> Input Class Initialized
DEBUG - 2011-10-07 00:38:13 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-07 00:38:13 --> Language Class Initialized
DEBUG - 2011-10-07 00:38:13 --> Loader Class Initialized
DEBUG - 2011-10-07 00:38:13 --> Controller Class Initialized
ERROR - 2011-10-07 00:38:13 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-10-07 00:38:13 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-10-07 00:38:13 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-07 00:38:13 --> Model Class Initialized
DEBUG - 2011-10-07 00:38:13 --> Model Class Initialized
DEBUG - 2011-10-07 00:38:13 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-07 00:38:13 --> Database Driver Class Initialized
DEBUG - 2011-10-07 00:38:13 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-07 00:38:13 --> Helper loaded: url_helper
DEBUG - 2011-10-07 00:38:13 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-07 00:38:13 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-07 00:38:13 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-07 00:38:13 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-07 00:38:13 --> Final output sent to browser
DEBUG - 2011-10-07 00:38:13 --> Total execution time: 0.0729
DEBUG - 2011-10-07 00:38:14 --> Config Class Initialized
DEBUG - 2011-10-07 00:38:14 --> Hooks Class Initialized
DEBUG - 2011-10-07 00:38:14 --> Utf8 Class Initialized
DEBUG - 2011-10-07 00:38:14 --> UTF-8 Support Enabled
DEBUG - 2011-10-07 00:38:14 --> URI Class Initialized
DEBUG - 2011-10-07 00:38:14 --> Router Class Initialized
DEBUG - 2011-10-07 00:38:14 --> Output Class Initialized
DEBUG - 2011-10-07 00:38:14 --> Input Class Initialized
DEBUG - 2011-10-07 00:38:14 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-07 00:38:14 --> Language Class Initialized
DEBUG - 2011-10-07 00:38:14 --> Loader Class Initialized
DEBUG - 2011-10-07 00:38:14 --> Controller Class Initialized
DEBUG - 2011-10-07 00:38:14 --> Model Class Initialized
DEBUG - 2011-10-07 00:38:14 --> Model Class Initialized
DEBUG - 2011-10-07 00:38:14 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-07 00:38:14 --> Database Driver Class Initialized
DEBUG - 2011-10-07 00:38:15 --> Final output sent to browser
DEBUG - 2011-10-07 00:38:15 --> Total execution time: 0.5723
DEBUG - 2011-10-07 00:38:16 --> Config Class Initialized
DEBUG - 2011-10-07 00:38:16 --> Hooks Class Initialized
DEBUG - 2011-10-07 00:38:16 --> Utf8 Class Initialized
DEBUG - 2011-10-07 00:38:16 --> UTF-8 Support Enabled
DEBUG - 2011-10-07 00:38:16 --> URI Class Initialized
DEBUG - 2011-10-07 00:38:16 --> Router Class Initialized
ERROR - 2011-10-07 00:38:16 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-07 00:38:17 --> Config Class Initialized
DEBUG - 2011-10-07 00:38:17 --> Hooks Class Initialized
DEBUG - 2011-10-07 00:38:17 --> Utf8 Class Initialized
DEBUG - 2011-10-07 00:38:17 --> UTF-8 Support Enabled
DEBUG - 2011-10-07 00:38:17 --> URI Class Initialized
DEBUG - 2011-10-07 00:38:17 --> Router Class Initialized
DEBUG - 2011-10-07 00:38:17 --> Output Class Initialized
DEBUG - 2011-10-07 00:38:17 --> Input Class Initialized
DEBUG - 2011-10-07 00:38:17 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-07 00:38:17 --> Language Class Initialized
DEBUG - 2011-10-07 00:38:17 --> Loader Class Initialized
DEBUG - 2011-10-07 00:38:17 --> Controller Class Initialized
ERROR - 2011-10-07 00:38:17 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-10-07 00:38:17 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-10-07 00:38:17 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-07 00:38:17 --> Model Class Initialized
DEBUG - 2011-10-07 00:38:17 --> Model Class Initialized
DEBUG - 2011-10-07 00:38:17 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-07 00:38:17 --> Database Driver Class Initialized
DEBUG - 2011-10-07 00:38:17 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-07 00:38:17 --> Helper loaded: url_helper
DEBUG - 2011-10-07 00:38:17 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-07 00:38:17 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-07 00:38:17 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-07 00:38:17 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-07 00:38:17 --> Final output sent to browser
DEBUG - 2011-10-07 00:38:17 --> Total execution time: 0.0381
DEBUG - 2011-10-07 00:38:28 --> Config Class Initialized
DEBUG - 2011-10-07 00:38:28 --> Hooks Class Initialized
DEBUG - 2011-10-07 00:38:28 --> Utf8 Class Initialized
DEBUG - 2011-10-07 00:38:28 --> UTF-8 Support Enabled
DEBUG - 2011-10-07 00:38:28 --> URI Class Initialized
DEBUG - 2011-10-07 00:38:28 --> Router Class Initialized
DEBUG - 2011-10-07 00:38:28 --> Output Class Initialized
DEBUG - 2011-10-07 00:38:28 --> Input Class Initialized
DEBUG - 2011-10-07 00:38:28 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-07 00:38:28 --> Language Class Initialized
DEBUG - 2011-10-07 00:38:28 --> Loader Class Initialized
DEBUG - 2011-10-07 00:38:28 --> Controller Class Initialized
ERROR - 2011-10-07 00:38:28 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-10-07 00:38:28 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-10-07 00:38:28 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-07 00:38:28 --> Model Class Initialized
DEBUG - 2011-10-07 00:38:28 --> Model Class Initialized
DEBUG - 2011-10-07 00:38:28 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-07 00:38:28 --> Database Driver Class Initialized
DEBUG - 2011-10-07 00:38:28 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-07 00:38:28 --> Helper loaded: url_helper
DEBUG - 2011-10-07 00:38:28 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-07 00:38:28 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-07 00:38:28 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-07 00:38:28 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-07 00:38:28 --> Final output sent to browser
DEBUG - 2011-10-07 00:38:28 --> Total execution time: 0.0345
DEBUG - 2011-10-07 00:38:28 --> Config Class Initialized
DEBUG - 2011-10-07 00:38:28 --> Hooks Class Initialized
DEBUG - 2011-10-07 00:38:28 --> Utf8 Class Initialized
DEBUG - 2011-10-07 00:38:28 --> UTF-8 Support Enabled
DEBUG - 2011-10-07 00:38:28 --> URI Class Initialized
DEBUG - 2011-10-07 00:38:28 --> Router Class Initialized
DEBUG - 2011-10-07 00:38:28 --> Output Class Initialized
DEBUG - 2011-10-07 00:38:28 --> Input Class Initialized
DEBUG - 2011-10-07 00:38:28 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-07 00:38:28 --> Language Class Initialized
DEBUG - 2011-10-07 00:38:28 --> Loader Class Initialized
DEBUG - 2011-10-07 00:38:28 --> Controller Class Initialized
DEBUG - 2011-10-07 00:38:28 --> Model Class Initialized
DEBUG - 2011-10-07 00:38:28 --> Model Class Initialized
DEBUG - 2011-10-07 00:38:28 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-07 00:38:28 --> Database Driver Class Initialized
DEBUG - 2011-10-07 00:38:29 --> Final output sent to browser
DEBUG - 2011-10-07 00:38:29 --> Total execution time: 0.5707
DEBUG - 2011-10-07 00:38:31 --> Config Class Initialized
DEBUG - 2011-10-07 00:38:31 --> Hooks Class Initialized
DEBUG - 2011-10-07 00:38:31 --> Utf8 Class Initialized
DEBUG - 2011-10-07 00:38:31 --> UTF-8 Support Enabled
DEBUG - 2011-10-07 00:38:31 --> URI Class Initialized
DEBUG - 2011-10-07 00:38:31 --> Router Class Initialized
ERROR - 2011-10-07 00:38:31 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-07 00:38:42 --> Config Class Initialized
DEBUG - 2011-10-07 00:38:42 --> Hooks Class Initialized
DEBUG - 2011-10-07 00:38:42 --> Utf8 Class Initialized
DEBUG - 2011-10-07 00:38:42 --> UTF-8 Support Enabled
DEBUG - 2011-10-07 00:38:42 --> URI Class Initialized
DEBUG - 2011-10-07 00:38:42 --> Router Class Initialized
DEBUG - 2011-10-07 00:38:42 --> Output Class Initialized
DEBUG - 2011-10-07 00:38:42 --> Input Class Initialized
DEBUG - 2011-10-07 00:38:42 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-07 00:38:42 --> Language Class Initialized
DEBUG - 2011-10-07 00:38:42 --> Loader Class Initialized
DEBUG - 2011-10-07 00:38:42 --> Controller Class Initialized
ERROR - 2011-10-07 00:38:42 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-10-07 00:38:42 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-10-07 00:38:42 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-07 00:38:42 --> Model Class Initialized
DEBUG - 2011-10-07 00:38:42 --> Model Class Initialized
DEBUG - 2011-10-07 00:38:42 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-07 00:38:42 --> Database Driver Class Initialized
DEBUG - 2011-10-07 00:38:42 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-07 00:38:42 --> Helper loaded: url_helper
DEBUG - 2011-10-07 00:38:42 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-07 00:38:42 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-07 00:38:42 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-07 00:38:42 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-07 00:38:42 --> Final output sent to browser
DEBUG - 2011-10-07 00:38:42 --> Total execution time: 0.0338
DEBUG - 2011-10-07 00:38:43 --> Config Class Initialized
DEBUG - 2011-10-07 00:38:43 --> Hooks Class Initialized
DEBUG - 2011-10-07 00:38:43 --> Utf8 Class Initialized
DEBUG - 2011-10-07 00:38:43 --> UTF-8 Support Enabled
DEBUG - 2011-10-07 00:38:43 --> URI Class Initialized
DEBUG - 2011-10-07 00:38:43 --> Router Class Initialized
DEBUG - 2011-10-07 00:38:43 --> Output Class Initialized
DEBUG - 2011-10-07 00:38:43 --> Input Class Initialized
DEBUG - 2011-10-07 00:38:43 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-07 00:38:43 --> Language Class Initialized
DEBUG - 2011-10-07 00:38:43 --> Loader Class Initialized
DEBUG - 2011-10-07 00:38:43 --> Controller Class Initialized
DEBUG - 2011-10-07 00:38:43 --> Model Class Initialized
DEBUG - 2011-10-07 00:38:43 --> Model Class Initialized
DEBUG - 2011-10-07 00:38:43 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-07 00:38:43 --> Database Driver Class Initialized
DEBUG - 2011-10-07 00:38:43 --> Final output sent to browser
DEBUG - 2011-10-07 00:38:43 --> Total execution time: 0.5872
DEBUG - 2011-10-07 00:38:45 --> Config Class Initialized
DEBUG - 2011-10-07 00:38:45 --> Hooks Class Initialized
DEBUG - 2011-10-07 00:38:45 --> Utf8 Class Initialized
DEBUG - 2011-10-07 00:38:45 --> UTF-8 Support Enabled
DEBUG - 2011-10-07 00:38:45 --> URI Class Initialized
DEBUG - 2011-10-07 00:38:45 --> Router Class Initialized
ERROR - 2011-10-07 00:38:45 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-07 00:38:56 --> Config Class Initialized
DEBUG - 2011-10-07 00:38:56 --> Hooks Class Initialized
DEBUG - 2011-10-07 00:38:56 --> Utf8 Class Initialized
DEBUG - 2011-10-07 00:38:56 --> UTF-8 Support Enabled
DEBUG - 2011-10-07 00:38:56 --> URI Class Initialized
DEBUG - 2011-10-07 00:38:56 --> Router Class Initialized
DEBUG - 2011-10-07 00:38:56 --> Output Class Initialized
DEBUG - 2011-10-07 00:38:56 --> Input Class Initialized
DEBUG - 2011-10-07 00:38:56 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-07 00:38:56 --> Language Class Initialized
DEBUG - 2011-10-07 00:38:56 --> Loader Class Initialized
DEBUG - 2011-10-07 00:38:56 --> Controller Class Initialized
ERROR - 2011-10-07 00:38:56 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-10-07 00:38:56 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-10-07 00:38:56 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-07 00:38:56 --> Model Class Initialized
DEBUG - 2011-10-07 00:38:56 --> Model Class Initialized
DEBUG - 2011-10-07 00:38:56 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-07 00:38:56 --> Database Driver Class Initialized
DEBUG - 2011-10-07 00:38:56 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-07 00:38:56 --> Helper loaded: url_helper
DEBUG - 2011-10-07 00:38:56 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-07 00:38:56 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-07 00:38:56 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-07 00:38:56 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-07 00:38:56 --> Final output sent to browser
DEBUG - 2011-10-07 00:38:56 --> Total execution time: 0.0647
DEBUG - 2011-10-07 00:38:56 --> Config Class Initialized
DEBUG - 2011-10-07 00:38:56 --> Hooks Class Initialized
DEBUG - 2011-10-07 00:38:56 --> Utf8 Class Initialized
DEBUG - 2011-10-07 00:38:56 --> UTF-8 Support Enabled
DEBUG - 2011-10-07 00:38:56 --> URI Class Initialized
DEBUG - 2011-10-07 00:38:56 --> Router Class Initialized
DEBUG - 2011-10-07 00:38:56 --> Output Class Initialized
DEBUG - 2011-10-07 00:38:56 --> Input Class Initialized
DEBUG - 2011-10-07 00:38:56 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-07 00:38:56 --> Language Class Initialized
DEBUG - 2011-10-07 00:38:56 --> Loader Class Initialized
DEBUG - 2011-10-07 00:38:56 --> Controller Class Initialized
DEBUG - 2011-10-07 00:38:56 --> Model Class Initialized
DEBUG - 2011-10-07 00:38:56 --> Model Class Initialized
DEBUG - 2011-10-07 00:38:56 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-07 00:38:56 --> Database Driver Class Initialized
DEBUG - 2011-10-07 00:38:57 --> Config Class Initialized
DEBUG - 2011-10-07 00:38:57 --> Hooks Class Initialized
DEBUG - 2011-10-07 00:38:57 --> Utf8 Class Initialized
DEBUG - 2011-10-07 00:38:57 --> UTF-8 Support Enabled
DEBUG - 2011-10-07 00:38:57 --> URI Class Initialized
DEBUG - 2011-10-07 00:38:57 --> Router Class Initialized
DEBUG - 2011-10-07 00:38:57 --> Output Class Initialized
DEBUG - 2011-10-07 00:38:57 --> Input Class Initialized
DEBUG - 2011-10-07 00:38:57 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-07 00:38:57 --> Language Class Initialized
DEBUG - 2011-10-07 00:38:57 --> Loader Class Initialized
DEBUG - 2011-10-07 00:38:57 --> Controller Class Initialized
ERROR - 2011-10-07 00:38:57 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-10-07 00:38:57 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-10-07 00:38:57 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-07 00:38:57 --> Model Class Initialized
DEBUG - 2011-10-07 00:38:57 --> Model Class Initialized
DEBUG - 2011-10-07 00:38:57 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-07 00:38:57 --> Database Driver Class Initialized
DEBUG - 2011-10-07 00:38:57 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-07 00:38:57 --> Helper loaded: url_helper
DEBUG - 2011-10-07 00:38:57 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-07 00:38:57 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-07 00:38:57 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-07 00:38:57 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-07 00:38:57 --> Final output sent to browser
DEBUG - 2011-10-07 00:38:57 --> Total execution time: 0.0453
DEBUG - 2011-10-07 00:38:57 --> Final output sent to browser
DEBUG - 2011-10-07 00:38:57 --> Total execution time: 0.5981
DEBUG - 2011-10-07 00:38:59 --> Config Class Initialized
DEBUG - 2011-10-07 00:38:59 --> Hooks Class Initialized
DEBUG - 2011-10-07 00:38:59 --> Utf8 Class Initialized
DEBUG - 2011-10-07 00:38:59 --> UTF-8 Support Enabled
DEBUG - 2011-10-07 00:38:59 --> URI Class Initialized
DEBUG - 2011-10-07 00:38:59 --> Router Class Initialized
ERROR - 2011-10-07 00:38:59 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-07 00:39:08 --> Config Class Initialized
DEBUG - 2011-10-07 00:39:08 --> Hooks Class Initialized
DEBUG - 2011-10-07 00:39:08 --> Utf8 Class Initialized
DEBUG - 2011-10-07 00:39:08 --> UTF-8 Support Enabled
DEBUG - 2011-10-07 00:39:08 --> URI Class Initialized
DEBUG - 2011-10-07 00:39:08 --> Router Class Initialized
DEBUG - 2011-10-07 00:39:08 --> Output Class Initialized
DEBUG - 2011-10-07 00:39:08 --> Input Class Initialized
DEBUG - 2011-10-07 00:39:08 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-07 00:39:08 --> Language Class Initialized
DEBUG - 2011-10-07 00:39:08 --> Loader Class Initialized
DEBUG - 2011-10-07 00:39:08 --> Controller Class Initialized
ERROR - 2011-10-07 00:39:08 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-10-07 00:39:08 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-10-07 00:39:08 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-07 00:39:08 --> Model Class Initialized
DEBUG - 2011-10-07 00:39:08 --> Model Class Initialized
DEBUG - 2011-10-07 00:39:08 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-07 00:39:08 --> Database Driver Class Initialized
DEBUG - 2011-10-07 00:39:08 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-07 00:39:08 --> Helper loaded: url_helper
DEBUG - 2011-10-07 00:39:08 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-07 00:39:08 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-07 00:39:08 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-07 00:39:08 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-07 00:39:08 --> Final output sent to browser
DEBUG - 2011-10-07 00:39:08 --> Total execution time: 0.0397
DEBUG - 2011-10-07 00:39:09 --> Config Class Initialized
DEBUG - 2011-10-07 00:39:09 --> Hooks Class Initialized
DEBUG - 2011-10-07 00:39:09 --> Utf8 Class Initialized
DEBUG - 2011-10-07 00:39:09 --> UTF-8 Support Enabled
DEBUG - 2011-10-07 00:39:09 --> URI Class Initialized
DEBUG - 2011-10-07 00:39:09 --> Router Class Initialized
DEBUG - 2011-10-07 00:39:09 --> Output Class Initialized
DEBUG - 2011-10-07 00:39:09 --> Input Class Initialized
DEBUG - 2011-10-07 00:39:09 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-07 00:39:09 --> Language Class Initialized
DEBUG - 2011-10-07 00:39:09 --> Loader Class Initialized
DEBUG - 2011-10-07 00:39:09 --> Controller Class Initialized
DEBUG - 2011-10-07 00:39:09 --> Model Class Initialized
DEBUG - 2011-10-07 00:39:09 --> Model Class Initialized
DEBUG - 2011-10-07 00:39:09 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-07 00:39:09 --> Database Driver Class Initialized
DEBUG - 2011-10-07 00:39:10 --> Final output sent to browser
DEBUG - 2011-10-07 00:39:10 --> Total execution time: 0.7842
DEBUG - 2011-10-07 00:39:12 --> Config Class Initialized
DEBUG - 2011-10-07 00:39:12 --> Hooks Class Initialized
DEBUG - 2011-10-07 00:39:12 --> Utf8 Class Initialized
DEBUG - 2011-10-07 00:39:12 --> UTF-8 Support Enabled
DEBUG - 2011-10-07 00:39:12 --> URI Class Initialized
DEBUG - 2011-10-07 00:39:12 --> Router Class Initialized
ERROR - 2011-10-07 00:39:12 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-07 00:39:20 --> Config Class Initialized
DEBUG - 2011-10-07 00:39:20 --> Hooks Class Initialized
DEBUG - 2011-10-07 00:39:20 --> Utf8 Class Initialized
DEBUG - 2011-10-07 00:39:20 --> UTF-8 Support Enabled
DEBUG - 2011-10-07 00:39:20 --> URI Class Initialized
DEBUG - 2011-10-07 00:39:20 --> Router Class Initialized
DEBUG - 2011-10-07 00:39:20 --> Output Class Initialized
DEBUG - 2011-10-07 00:39:20 --> Input Class Initialized
DEBUG - 2011-10-07 00:39:20 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-07 00:39:20 --> Language Class Initialized
DEBUG - 2011-10-07 00:39:20 --> Loader Class Initialized
DEBUG - 2011-10-07 00:39:20 --> Controller Class Initialized
ERROR - 2011-10-07 00:39:20 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-10-07 00:39:20 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-10-07 00:39:20 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-07 00:39:20 --> Model Class Initialized
DEBUG - 2011-10-07 00:39:20 --> Model Class Initialized
DEBUG - 2011-10-07 00:39:20 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-07 00:39:20 --> Database Driver Class Initialized
DEBUG - 2011-10-07 00:39:20 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-07 00:39:20 --> Helper loaded: url_helper
DEBUG - 2011-10-07 00:39:20 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-07 00:39:20 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-07 00:39:20 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-07 00:39:20 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-07 00:39:20 --> Final output sent to browser
DEBUG - 2011-10-07 00:39:20 --> Total execution time: 0.0567
DEBUG - 2011-10-07 00:39:21 --> Config Class Initialized
DEBUG - 2011-10-07 00:39:21 --> Hooks Class Initialized
DEBUG - 2011-10-07 00:39:21 --> Utf8 Class Initialized
DEBUG - 2011-10-07 00:39:21 --> UTF-8 Support Enabled
DEBUG - 2011-10-07 00:39:21 --> URI Class Initialized
DEBUG - 2011-10-07 00:39:21 --> Router Class Initialized
DEBUG - 2011-10-07 00:39:21 --> Output Class Initialized
DEBUG - 2011-10-07 00:39:21 --> Input Class Initialized
DEBUG - 2011-10-07 00:39:21 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-07 00:39:21 --> Language Class Initialized
DEBUG - 2011-10-07 00:39:21 --> Loader Class Initialized
DEBUG - 2011-10-07 00:39:21 --> Controller Class Initialized
DEBUG - 2011-10-07 00:39:21 --> Model Class Initialized
DEBUG - 2011-10-07 00:39:21 --> Model Class Initialized
DEBUG - 2011-10-07 00:39:21 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-07 00:39:21 --> Database Driver Class Initialized
DEBUG - 2011-10-07 00:39:21 --> Final output sent to browser
DEBUG - 2011-10-07 00:39:21 --> Total execution time: 0.6082
DEBUG - 2011-10-07 00:39:23 --> Config Class Initialized
DEBUG - 2011-10-07 00:39:23 --> Hooks Class Initialized
DEBUG - 2011-10-07 00:39:23 --> Utf8 Class Initialized
DEBUG - 2011-10-07 00:39:23 --> UTF-8 Support Enabled
DEBUG - 2011-10-07 00:39:23 --> URI Class Initialized
DEBUG - 2011-10-07 00:39:23 --> Router Class Initialized
ERROR - 2011-10-07 00:39:23 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-07 00:39:31 --> Config Class Initialized
DEBUG - 2011-10-07 00:39:31 --> Hooks Class Initialized
DEBUG - 2011-10-07 00:39:31 --> Utf8 Class Initialized
DEBUG - 2011-10-07 00:39:31 --> UTF-8 Support Enabled
DEBUG - 2011-10-07 00:39:31 --> URI Class Initialized
DEBUG - 2011-10-07 00:39:31 --> Router Class Initialized
DEBUG - 2011-10-07 00:39:31 --> Output Class Initialized
DEBUG - 2011-10-07 00:39:31 --> Input Class Initialized
DEBUG - 2011-10-07 00:39:31 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-07 00:39:31 --> Language Class Initialized
DEBUG - 2011-10-07 00:39:31 --> Loader Class Initialized
DEBUG - 2011-10-07 00:39:31 --> Controller Class Initialized
ERROR - 2011-10-07 00:39:31 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-10-07 00:39:31 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-10-07 00:39:31 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-07 00:39:31 --> Model Class Initialized
DEBUG - 2011-10-07 00:39:31 --> Model Class Initialized
DEBUG - 2011-10-07 00:39:31 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-07 00:39:31 --> Database Driver Class Initialized
DEBUG - 2011-10-07 00:39:31 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-07 00:39:31 --> Helper loaded: url_helper
DEBUG - 2011-10-07 00:39:31 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-07 00:39:31 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-07 00:39:31 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-07 00:39:31 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-07 00:39:31 --> Final output sent to browser
DEBUG - 2011-10-07 00:39:31 --> Total execution time: 0.0659
DEBUG - 2011-10-07 00:39:32 --> Config Class Initialized
DEBUG - 2011-10-07 00:39:32 --> Hooks Class Initialized
DEBUG - 2011-10-07 00:39:32 --> Utf8 Class Initialized
DEBUG - 2011-10-07 00:39:32 --> UTF-8 Support Enabled
DEBUG - 2011-10-07 00:39:32 --> URI Class Initialized
DEBUG - 2011-10-07 00:39:32 --> Router Class Initialized
DEBUG - 2011-10-07 00:39:32 --> Output Class Initialized
DEBUG - 2011-10-07 00:39:32 --> Input Class Initialized
DEBUG - 2011-10-07 00:39:32 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-07 00:39:32 --> Language Class Initialized
DEBUG - 2011-10-07 00:39:32 --> Loader Class Initialized
DEBUG - 2011-10-07 00:39:32 --> Controller Class Initialized
DEBUG - 2011-10-07 00:39:32 --> Model Class Initialized
DEBUG - 2011-10-07 00:39:32 --> Model Class Initialized
DEBUG - 2011-10-07 00:39:32 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-07 00:39:32 --> Database Driver Class Initialized
DEBUG - 2011-10-07 00:39:33 --> Final output sent to browser
DEBUG - 2011-10-07 00:39:33 --> Total execution time: 1.5877
DEBUG - 2011-10-07 00:39:35 --> Config Class Initialized
DEBUG - 2011-10-07 00:39:35 --> Hooks Class Initialized
DEBUG - 2011-10-07 00:39:35 --> Utf8 Class Initialized
DEBUG - 2011-10-07 00:39:35 --> UTF-8 Support Enabled
DEBUG - 2011-10-07 00:39:35 --> URI Class Initialized
DEBUG - 2011-10-07 00:39:35 --> Router Class Initialized
ERROR - 2011-10-07 00:39:35 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-07 00:39:41 --> Config Class Initialized
DEBUG - 2011-10-07 00:39:41 --> Hooks Class Initialized
DEBUG - 2011-10-07 00:39:41 --> Utf8 Class Initialized
DEBUG - 2011-10-07 00:39:41 --> UTF-8 Support Enabled
DEBUG - 2011-10-07 00:39:41 --> URI Class Initialized
DEBUG - 2011-10-07 00:39:41 --> Router Class Initialized
DEBUG - 2011-10-07 00:39:41 --> Output Class Initialized
DEBUG - 2011-10-07 00:39:41 --> Input Class Initialized
DEBUG - 2011-10-07 00:39:41 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-07 00:39:41 --> Language Class Initialized
DEBUG - 2011-10-07 00:39:41 --> Loader Class Initialized
DEBUG - 2011-10-07 00:39:41 --> Controller Class Initialized
ERROR - 2011-10-07 00:39:41 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-10-07 00:39:41 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-10-07 00:39:41 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-07 00:39:41 --> Model Class Initialized
DEBUG - 2011-10-07 00:39:41 --> Model Class Initialized
DEBUG - 2011-10-07 00:39:41 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-07 00:39:41 --> Database Driver Class Initialized
DEBUG - 2011-10-07 00:39:41 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-07 00:39:41 --> Helper loaded: url_helper
DEBUG - 2011-10-07 00:39:41 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-07 00:39:41 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-07 00:39:41 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-07 00:39:41 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-07 00:39:41 --> Final output sent to browser
DEBUG - 2011-10-07 00:39:41 --> Total execution time: 0.1698
DEBUG - 2011-10-07 00:39:42 --> Config Class Initialized
DEBUG - 2011-10-07 00:39:42 --> Hooks Class Initialized
DEBUG - 2011-10-07 00:39:42 --> Utf8 Class Initialized
DEBUG - 2011-10-07 00:39:42 --> UTF-8 Support Enabled
DEBUG - 2011-10-07 00:39:42 --> URI Class Initialized
DEBUG - 2011-10-07 00:39:42 --> Router Class Initialized
DEBUG - 2011-10-07 00:39:42 --> Output Class Initialized
DEBUG - 2011-10-07 00:39:42 --> Input Class Initialized
DEBUG - 2011-10-07 00:39:42 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-07 00:39:42 --> Language Class Initialized
DEBUG - 2011-10-07 00:39:42 --> Loader Class Initialized
DEBUG - 2011-10-07 00:39:42 --> Controller Class Initialized
DEBUG - 2011-10-07 00:39:42 --> Model Class Initialized
DEBUG - 2011-10-07 00:39:42 --> Model Class Initialized
DEBUG - 2011-10-07 00:39:42 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-07 00:39:42 --> Database Driver Class Initialized
DEBUG - 2011-10-07 00:39:42 --> Config Class Initialized
DEBUG - 2011-10-07 00:39:42 --> Hooks Class Initialized
DEBUG - 2011-10-07 00:39:42 --> Utf8 Class Initialized
DEBUG - 2011-10-07 00:39:42 --> UTF-8 Support Enabled
DEBUG - 2011-10-07 00:39:42 --> URI Class Initialized
DEBUG - 2011-10-07 00:39:42 --> Router Class Initialized
DEBUG - 2011-10-07 00:39:42 --> Output Class Initialized
DEBUG - 2011-10-07 00:39:42 --> Input Class Initialized
DEBUG - 2011-10-07 00:39:42 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-07 00:39:42 --> Language Class Initialized
DEBUG - 2011-10-07 00:39:42 --> Loader Class Initialized
DEBUG - 2011-10-07 00:39:42 --> Controller Class Initialized
ERROR - 2011-10-07 00:39:42 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-10-07 00:39:42 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-10-07 00:39:42 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-07 00:39:42 --> Model Class Initialized
DEBUG - 2011-10-07 00:39:42 --> Model Class Initialized
DEBUG - 2011-10-07 00:39:42 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-07 00:39:42 --> Database Driver Class Initialized
DEBUG - 2011-10-07 00:39:42 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-07 00:39:42 --> Helper loaded: url_helper
DEBUG - 2011-10-07 00:39:42 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-07 00:39:42 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-07 00:39:42 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-07 00:39:42 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-07 00:39:42 --> Final output sent to browser
DEBUG - 2011-10-07 00:39:42 --> Total execution time: 0.0295
DEBUG - 2011-10-07 00:39:43 --> Final output sent to browser
DEBUG - 2011-10-07 00:39:43 --> Total execution time: 0.6231
DEBUG - 2011-10-07 00:39:43 --> Config Class Initialized
DEBUG - 2011-10-07 00:39:43 --> Hooks Class Initialized
DEBUG - 2011-10-07 00:39:43 --> Utf8 Class Initialized
DEBUG - 2011-10-07 00:39:43 --> UTF-8 Support Enabled
DEBUG - 2011-10-07 00:39:43 --> URI Class Initialized
DEBUG - 2011-10-07 00:39:43 --> Router Class Initialized
ERROR - 2011-10-07 00:39:43 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-07 00:39:55 --> Config Class Initialized
DEBUG - 2011-10-07 00:39:55 --> Hooks Class Initialized
DEBUG - 2011-10-07 00:39:55 --> Utf8 Class Initialized
DEBUG - 2011-10-07 00:39:55 --> UTF-8 Support Enabled
DEBUG - 2011-10-07 00:39:55 --> URI Class Initialized
DEBUG - 2011-10-07 00:39:55 --> Router Class Initialized
DEBUG - 2011-10-07 00:39:55 --> Output Class Initialized
DEBUG - 2011-10-07 00:39:55 --> Input Class Initialized
DEBUG - 2011-10-07 00:39:55 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-07 00:39:55 --> Language Class Initialized
DEBUG - 2011-10-07 00:39:55 --> Loader Class Initialized
DEBUG - 2011-10-07 00:39:55 --> Controller Class Initialized
ERROR - 2011-10-07 00:39:55 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-10-07 00:39:55 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-10-07 00:39:55 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-07 00:39:55 --> Model Class Initialized
DEBUG - 2011-10-07 00:39:55 --> Model Class Initialized
DEBUG - 2011-10-07 00:39:55 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-07 00:39:55 --> Database Driver Class Initialized
DEBUG - 2011-10-07 00:39:55 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-07 00:39:55 --> Helper loaded: url_helper
DEBUG - 2011-10-07 00:39:55 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-07 00:39:55 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-07 00:39:55 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-07 00:39:55 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-07 00:39:55 --> Final output sent to browser
DEBUG - 2011-10-07 00:39:55 --> Total execution time: 0.0376
DEBUG - 2011-10-07 00:39:56 --> Config Class Initialized
DEBUG - 2011-10-07 00:39:56 --> Hooks Class Initialized
DEBUG - 2011-10-07 00:39:56 --> Utf8 Class Initialized
DEBUG - 2011-10-07 00:39:56 --> UTF-8 Support Enabled
DEBUG - 2011-10-07 00:39:56 --> URI Class Initialized
DEBUG - 2011-10-07 00:39:56 --> Router Class Initialized
DEBUG - 2011-10-07 00:39:56 --> Output Class Initialized
DEBUG - 2011-10-07 00:39:56 --> Input Class Initialized
DEBUG - 2011-10-07 00:39:56 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-07 00:39:56 --> Language Class Initialized
DEBUG - 2011-10-07 00:39:56 --> Loader Class Initialized
DEBUG - 2011-10-07 00:39:56 --> Controller Class Initialized
DEBUG - 2011-10-07 00:39:56 --> Model Class Initialized
DEBUG - 2011-10-07 00:39:56 --> Model Class Initialized
DEBUG - 2011-10-07 00:39:56 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-07 00:39:56 --> Database Driver Class Initialized
DEBUG - 2011-10-07 00:39:57 --> Final output sent to browser
DEBUG - 2011-10-07 00:39:57 --> Total execution time: 0.5829
DEBUG - 2011-10-07 00:39:58 --> Config Class Initialized
DEBUG - 2011-10-07 00:39:58 --> Hooks Class Initialized
DEBUG - 2011-10-07 00:39:58 --> Utf8 Class Initialized
DEBUG - 2011-10-07 00:39:58 --> UTF-8 Support Enabled
DEBUG - 2011-10-07 00:39:58 --> URI Class Initialized
DEBUG - 2011-10-07 00:39:58 --> Router Class Initialized
ERROR - 2011-10-07 00:39:58 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-07 00:40:32 --> Config Class Initialized
DEBUG - 2011-10-07 00:40:32 --> Hooks Class Initialized
DEBUG - 2011-10-07 00:40:32 --> Utf8 Class Initialized
DEBUG - 2011-10-07 00:40:32 --> UTF-8 Support Enabled
DEBUG - 2011-10-07 00:40:32 --> URI Class Initialized
DEBUG - 2011-10-07 00:40:32 --> Router Class Initialized
DEBUG - 2011-10-07 00:40:32 --> Output Class Initialized
DEBUG - 2011-10-07 00:40:32 --> Input Class Initialized
DEBUG - 2011-10-07 00:40:32 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-07 00:40:32 --> Language Class Initialized
DEBUG - 2011-10-07 00:40:32 --> Loader Class Initialized
DEBUG - 2011-10-07 00:40:32 --> Controller Class Initialized
ERROR - 2011-10-07 00:40:32 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-10-07 00:40:32 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-10-07 00:40:32 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-07 00:40:32 --> Model Class Initialized
DEBUG - 2011-10-07 00:40:32 --> Model Class Initialized
DEBUG - 2011-10-07 00:40:32 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-07 00:40:32 --> Database Driver Class Initialized
DEBUG - 2011-10-07 00:40:32 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-07 00:40:32 --> Helper loaded: url_helper
DEBUG - 2011-10-07 00:40:32 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-07 00:40:32 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-07 00:40:32 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-07 00:40:32 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-07 00:40:32 --> Final output sent to browser
DEBUG - 2011-10-07 00:40:32 --> Total execution time: 0.0615
DEBUG - 2011-10-07 00:40:33 --> Config Class Initialized
DEBUG - 2011-10-07 00:40:33 --> Hooks Class Initialized
DEBUG - 2011-10-07 00:40:33 --> Utf8 Class Initialized
DEBUG - 2011-10-07 00:40:33 --> UTF-8 Support Enabled
DEBUG - 2011-10-07 00:40:33 --> URI Class Initialized
DEBUG - 2011-10-07 00:40:33 --> Router Class Initialized
DEBUG - 2011-10-07 00:40:33 --> Output Class Initialized
DEBUG - 2011-10-07 00:40:33 --> Input Class Initialized
DEBUG - 2011-10-07 00:40:33 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-07 00:40:33 --> Language Class Initialized
DEBUG - 2011-10-07 00:40:33 --> Loader Class Initialized
DEBUG - 2011-10-07 00:40:33 --> Controller Class Initialized
DEBUG - 2011-10-07 00:40:33 --> Model Class Initialized
DEBUG - 2011-10-07 00:40:33 --> Model Class Initialized
DEBUG - 2011-10-07 00:40:33 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-07 00:40:33 --> Database Driver Class Initialized
DEBUG - 2011-10-07 00:40:33 --> Final output sent to browser
DEBUG - 2011-10-07 00:40:33 --> Total execution time: 0.5724
DEBUG - 2011-10-07 00:40:34 --> Config Class Initialized
DEBUG - 2011-10-07 00:40:34 --> Hooks Class Initialized
DEBUG - 2011-10-07 00:40:34 --> Utf8 Class Initialized
DEBUG - 2011-10-07 00:40:34 --> UTF-8 Support Enabled
DEBUG - 2011-10-07 00:40:34 --> URI Class Initialized
DEBUG - 2011-10-07 00:40:34 --> Router Class Initialized
ERROR - 2011-10-07 00:40:34 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-07 00:40:39 --> Config Class Initialized
DEBUG - 2011-10-07 00:40:39 --> Hooks Class Initialized
DEBUG - 2011-10-07 00:40:39 --> Utf8 Class Initialized
DEBUG - 2011-10-07 00:40:39 --> UTF-8 Support Enabled
DEBUG - 2011-10-07 00:40:39 --> URI Class Initialized
DEBUG - 2011-10-07 00:40:39 --> Router Class Initialized
DEBUG - 2011-10-07 00:40:39 --> Output Class Initialized
DEBUG - 2011-10-07 00:40:39 --> Input Class Initialized
DEBUG - 2011-10-07 00:40:39 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-07 00:40:39 --> Language Class Initialized
DEBUG - 2011-10-07 00:40:39 --> Loader Class Initialized
DEBUG - 2011-10-07 00:40:39 --> Controller Class Initialized
ERROR - 2011-10-07 00:40:39 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-10-07 00:40:39 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-10-07 00:40:39 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-07 00:40:39 --> Model Class Initialized
DEBUG - 2011-10-07 00:40:39 --> Model Class Initialized
DEBUG - 2011-10-07 00:40:39 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-07 00:40:39 --> Database Driver Class Initialized
DEBUG - 2011-10-07 00:40:39 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-07 00:40:39 --> Helper loaded: url_helper
DEBUG - 2011-10-07 00:40:39 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-07 00:40:39 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-07 00:40:39 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-07 00:40:39 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-07 00:40:39 --> Final output sent to browser
DEBUG - 2011-10-07 00:40:39 --> Total execution time: 0.0594
DEBUG - 2011-10-07 00:40:40 --> Config Class Initialized
DEBUG - 2011-10-07 00:40:40 --> Hooks Class Initialized
DEBUG - 2011-10-07 00:40:40 --> Utf8 Class Initialized
DEBUG - 2011-10-07 00:40:40 --> UTF-8 Support Enabled
DEBUG - 2011-10-07 00:40:40 --> URI Class Initialized
DEBUG - 2011-10-07 00:40:40 --> Router Class Initialized
DEBUG - 2011-10-07 00:40:40 --> Output Class Initialized
DEBUG - 2011-10-07 00:40:40 --> Input Class Initialized
DEBUG - 2011-10-07 00:40:40 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-07 00:40:40 --> Language Class Initialized
DEBUG - 2011-10-07 00:40:40 --> Loader Class Initialized
DEBUG - 2011-10-07 00:40:40 --> Controller Class Initialized
DEBUG - 2011-10-07 00:40:40 --> Model Class Initialized
DEBUG - 2011-10-07 00:40:40 --> Model Class Initialized
DEBUG - 2011-10-07 00:40:40 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-07 00:40:40 --> Database Driver Class Initialized
DEBUG - 2011-10-07 00:40:41 --> Final output sent to browser
DEBUG - 2011-10-07 00:40:41 --> Total execution time: 0.7349
DEBUG - 2011-10-07 00:40:42 --> Config Class Initialized
DEBUG - 2011-10-07 00:40:42 --> Hooks Class Initialized
DEBUG - 2011-10-07 00:40:42 --> Utf8 Class Initialized
DEBUG - 2011-10-07 00:40:42 --> UTF-8 Support Enabled
DEBUG - 2011-10-07 00:40:42 --> URI Class Initialized
DEBUG - 2011-10-07 00:40:42 --> Router Class Initialized
ERROR - 2011-10-07 00:40:42 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-07 00:41:06 --> Config Class Initialized
DEBUG - 2011-10-07 00:41:06 --> Hooks Class Initialized
DEBUG - 2011-10-07 00:41:06 --> Utf8 Class Initialized
DEBUG - 2011-10-07 00:41:06 --> UTF-8 Support Enabled
DEBUG - 2011-10-07 00:41:06 --> URI Class Initialized
DEBUG - 2011-10-07 00:41:06 --> Router Class Initialized
DEBUG - 2011-10-07 00:41:06 --> Output Class Initialized
DEBUG - 2011-10-07 00:41:06 --> Input Class Initialized
DEBUG - 2011-10-07 00:41:06 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-07 00:41:06 --> Language Class Initialized
DEBUG - 2011-10-07 00:41:06 --> Loader Class Initialized
DEBUG - 2011-10-07 00:41:06 --> Controller Class Initialized
ERROR - 2011-10-07 00:41:06 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-10-07 00:41:06 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-10-07 00:41:06 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-07 00:41:06 --> Model Class Initialized
DEBUG - 2011-10-07 00:41:06 --> Model Class Initialized
DEBUG - 2011-10-07 00:41:06 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-07 00:41:06 --> Database Driver Class Initialized
DEBUG - 2011-10-07 00:41:06 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-07 00:41:06 --> Helper loaded: url_helper
DEBUG - 2011-10-07 00:41:06 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-07 00:41:06 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-07 00:41:06 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-07 00:41:06 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-07 00:41:06 --> Final output sent to browser
DEBUG - 2011-10-07 00:41:07 --> Total execution time: 0.0843
DEBUG - 2011-10-07 00:41:07 --> Config Class Initialized
DEBUG - 2011-10-07 00:41:07 --> Hooks Class Initialized
DEBUG - 2011-10-07 00:41:07 --> Utf8 Class Initialized
DEBUG - 2011-10-07 00:41:07 --> UTF-8 Support Enabled
DEBUG - 2011-10-07 00:41:07 --> URI Class Initialized
DEBUG - 2011-10-07 00:41:07 --> Router Class Initialized
DEBUG - 2011-10-07 00:41:07 --> Output Class Initialized
DEBUG - 2011-10-07 00:41:07 --> Input Class Initialized
DEBUG - 2011-10-07 00:41:07 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-07 00:41:07 --> Language Class Initialized
DEBUG - 2011-10-07 00:41:07 --> Loader Class Initialized
DEBUG - 2011-10-07 00:41:07 --> Controller Class Initialized
DEBUG - 2011-10-07 00:41:07 --> Model Class Initialized
DEBUG - 2011-10-07 00:41:07 --> Model Class Initialized
DEBUG - 2011-10-07 00:41:07 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-07 00:41:07 --> Database Driver Class Initialized
DEBUG - 2011-10-07 00:41:08 --> Final output sent to browser
DEBUG - 2011-10-07 00:41:08 --> Total execution time: 0.4801
DEBUG - 2011-10-07 00:41:09 --> Config Class Initialized
DEBUG - 2011-10-07 00:41:09 --> Hooks Class Initialized
DEBUG - 2011-10-07 00:41:09 --> Utf8 Class Initialized
DEBUG - 2011-10-07 00:41:09 --> UTF-8 Support Enabled
DEBUG - 2011-10-07 00:41:09 --> URI Class Initialized
DEBUG - 2011-10-07 00:41:09 --> Router Class Initialized
ERROR - 2011-10-07 00:41:09 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-07 00:41:16 --> Config Class Initialized
DEBUG - 2011-10-07 00:41:16 --> Hooks Class Initialized
DEBUG - 2011-10-07 00:41:16 --> Utf8 Class Initialized
DEBUG - 2011-10-07 00:41:16 --> UTF-8 Support Enabled
DEBUG - 2011-10-07 00:41:16 --> URI Class Initialized
DEBUG - 2011-10-07 00:41:16 --> Router Class Initialized
DEBUG - 2011-10-07 00:41:16 --> Output Class Initialized
DEBUG - 2011-10-07 00:41:16 --> Input Class Initialized
DEBUG - 2011-10-07 00:41:16 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-07 00:41:16 --> Language Class Initialized
DEBUG - 2011-10-07 00:41:16 --> Loader Class Initialized
DEBUG - 2011-10-07 00:41:16 --> Controller Class Initialized
ERROR - 2011-10-07 00:41:16 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-10-07 00:41:16 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-10-07 00:41:16 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-07 00:41:16 --> Model Class Initialized
DEBUG - 2011-10-07 00:41:16 --> Model Class Initialized
DEBUG - 2011-10-07 00:41:16 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-07 00:41:16 --> Database Driver Class Initialized
DEBUG - 2011-10-07 00:41:16 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-07 00:41:16 --> Helper loaded: url_helper
DEBUG - 2011-10-07 00:41:16 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-07 00:41:16 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-07 00:41:16 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-07 00:41:16 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-07 00:41:16 --> Final output sent to browser
DEBUG - 2011-10-07 00:41:16 --> Total execution time: 0.0320
DEBUG - 2011-10-07 00:41:17 --> Config Class Initialized
DEBUG - 2011-10-07 00:41:17 --> Hooks Class Initialized
DEBUG - 2011-10-07 00:41:17 --> Utf8 Class Initialized
DEBUG - 2011-10-07 00:41:17 --> UTF-8 Support Enabled
DEBUG - 2011-10-07 00:41:17 --> URI Class Initialized
DEBUG - 2011-10-07 00:41:17 --> Router Class Initialized
DEBUG - 2011-10-07 00:41:17 --> Output Class Initialized
DEBUG - 2011-10-07 00:41:17 --> Input Class Initialized
DEBUG - 2011-10-07 00:41:17 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-07 00:41:17 --> Language Class Initialized
DEBUG - 2011-10-07 00:41:17 --> Loader Class Initialized
DEBUG - 2011-10-07 00:41:17 --> Controller Class Initialized
DEBUG - 2011-10-07 00:41:17 --> Model Class Initialized
DEBUG - 2011-10-07 00:41:17 --> Model Class Initialized
DEBUG - 2011-10-07 00:41:17 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-07 00:41:17 --> Database Driver Class Initialized
DEBUG - 2011-10-07 00:41:18 --> Final output sent to browser
DEBUG - 2011-10-07 00:41:18 --> Total execution time: 0.5443
DEBUG - 2011-10-07 00:41:19 --> Config Class Initialized
DEBUG - 2011-10-07 00:41:19 --> Hooks Class Initialized
DEBUG - 2011-10-07 00:41:19 --> Utf8 Class Initialized
DEBUG - 2011-10-07 00:41:19 --> UTF-8 Support Enabled
DEBUG - 2011-10-07 00:41:19 --> URI Class Initialized
DEBUG - 2011-10-07 00:41:19 --> Router Class Initialized
ERROR - 2011-10-07 00:41:19 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-07 00:41:30 --> Config Class Initialized
DEBUG - 2011-10-07 00:41:30 --> Hooks Class Initialized
DEBUG - 2011-10-07 00:41:30 --> Utf8 Class Initialized
DEBUG - 2011-10-07 00:41:30 --> UTF-8 Support Enabled
DEBUG - 2011-10-07 00:41:30 --> URI Class Initialized
DEBUG - 2011-10-07 00:41:30 --> Router Class Initialized
DEBUG - 2011-10-07 00:41:30 --> Output Class Initialized
DEBUG - 2011-10-07 00:41:30 --> Input Class Initialized
DEBUG - 2011-10-07 00:41:30 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-07 00:41:30 --> Language Class Initialized
DEBUG - 2011-10-07 00:41:30 --> Loader Class Initialized
DEBUG - 2011-10-07 00:41:30 --> Controller Class Initialized
ERROR - 2011-10-07 00:41:30 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-10-07 00:41:30 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-10-07 00:41:30 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-07 00:41:30 --> Model Class Initialized
DEBUG - 2011-10-07 00:41:30 --> Model Class Initialized
DEBUG - 2011-10-07 00:41:30 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-07 00:41:30 --> Database Driver Class Initialized
DEBUG - 2011-10-07 00:41:30 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-07 00:41:30 --> Helper loaded: url_helper
DEBUG - 2011-10-07 00:41:30 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-07 00:41:30 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-07 00:41:30 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-07 00:41:30 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-07 00:41:30 --> Final output sent to browser
DEBUG - 2011-10-07 00:41:30 --> Total execution time: 0.0764
DEBUG - 2011-10-07 00:41:31 --> Config Class Initialized
DEBUG - 2011-10-07 00:41:31 --> Hooks Class Initialized
DEBUG - 2011-10-07 00:41:31 --> Utf8 Class Initialized
DEBUG - 2011-10-07 00:41:31 --> UTF-8 Support Enabled
DEBUG - 2011-10-07 00:41:31 --> URI Class Initialized
DEBUG - 2011-10-07 00:41:31 --> Router Class Initialized
DEBUG - 2011-10-07 00:41:31 --> Output Class Initialized
DEBUG - 2011-10-07 00:41:31 --> Input Class Initialized
DEBUG - 2011-10-07 00:41:31 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-07 00:41:31 --> Language Class Initialized
DEBUG - 2011-10-07 00:41:31 --> Loader Class Initialized
DEBUG - 2011-10-07 00:41:31 --> Controller Class Initialized
DEBUG - 2011-10-07 00:41:31 --> Model Class Initialized
DEBUG - 2011-10-07 00:41:31 --> Model Class Initialized
DEBUG - 2011-10-07 00:41:31 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-07 00:41:31 --> Database Driver Class Initialized
DEBUG - 2011-10-07 00:41:31 --> Final output sent to browser
DEBUG - 2011-10-07 00:41:31 --> Total execution time: 0.6829
DEBUG - 2011-10-07 00:41:32 --> Config Class Initialized
DEBUG - 2011-10-07 00:41:32 --> Hooks Class Initialized
DEBUG - 2011-10-07 00:41:32 --> Utf8 Class Initialized
DEBUG - 2011-10-07 00:41:32 --> UTF-8 Support Enabled
DEBUG - 2011-10-07 00:41:32 --> URI Class Initialized
DEBUG - 2011-10-07 00:41:32 --> Router Class Initialized
ERROR - 2011-10-07 00:41:32 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-07 02:30:23 --> Config Class Initialized
DEBUG - 2011-10-07 02:30:23 --> Hooks Class Initialized
DEBUG - 2011-10-07 02:30:23 --> Utf8 Class Initialized
DEBUG - 2011-10-07 02:30:23 --> UTF-8 Support Enabled
DEBUG - 2011-10-07 02:30:23 --> URI Class Initialized
DEBUG - 2011-10-07 02:30:23 --> Router Class Initialized
DEBUG - 2011-10-07 02:30:23 --> Output Class Initialized
DEBUG - 2011-10-07 02:30:23 --> Input Class Initialized
DEBUG - 2011-10-07 02:30:23 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-07 02:30:23 --> Language Class Initialized
DEBUG - 2011-10-07 02:30:23 --> Loader Class Initialized
DEBUG - 2011-10-07 02:30:23 --> Controller Class Initialized
ERROR - 2011-10-07 02:30:23 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-10-07 02:30:23 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-10-07 02:30:23 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-07 02:30:23 --> Model Class Initialized
DEBUG - 2011-10-07 02:30:23 --> Model Class Initialized
DEBUG - 2011-10-07 02:30:23 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-07 02:30:23 --> Database Driver Class Initialized
DEBUG - 2011-10-07 02:30:24 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-07 02:30:24 --> Helper loaded: url_helper
DEBUG - 2011-10-07 02:30:24 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-07 02:30:24 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-07 02:30:24 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-07 02:30:24 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-07 02:30:24 --> Final output sent to browser
DEBUG - 2011-10-07 02:30:24 --> Total execution time: 0.9095
DEBUG - 2011-10-07 02:30:26 --> Config Class Initialized
DEBUG - 2011-10-07 02:30:26 --> Hooks Class Initialized
DEBUG - 2011-10-07 02:30:26 --> Utf8 Class Initialized
DEBUG - 2011-10-07 02:30:26 --> UTF-8 Support Enabled
DEBUG - 2011-10-07 02:30:26 --> URI Class Initialized
DEBUG - 2011-10-07 02:30:26 --> Router Class Initialized
DEBUG - 2011-10-07 02:30:26 --> Output Class Initialized
DEBUG - 2011-10-07 02:30:26 --> Input Class Initialized
DEBUG - 2011-10-07 02:30:26 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-07 02:30:26 --> Language Class Initialized
DEBUG - 2011-10-07 02:30:26 --> Loader Class Initialized
DEBUG - 2011-10-07 02:30:26 --> Controller Class Initialized
DEBUG - 2011-10-07 02:30:26 --> Model Class Initialized
DEBUG - 2011-10-07 02:30:26 --> Model Class Initialized
DEBUG - 2011-10-07 02:30:26 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-07 02:30:26 --> Database Driver Class Initialized
DEBUG - 2011-10-07 02:30:28 --> Final output sent to browser
DEBUG - 2011-10-07 02:30:28 --> Total execution time: 2.1397
DEBUG - 2011-10-07 02:30:30 --> Config Class Initialized
DEBUG - 2011-10-07 02:30:30 --> Hooks Class Initialized
DEBUG - 2011-10-07 02:30:30 --> Utf8 Class Initialized
DEBUG - 2011-10-07 02:30:30 --> UTF-8 Support Enabled
DEBUG - 2011-10-07 02:30:30 --> URI Class Initialized
DEBUG - 2011-10-07 02:30:30 --> Router Class Initialized
ERROR - 2011-10-07 02:30:30 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-07 05:02:30 --> Config Class Initialized
DEBUG - 2011-10-07 05:02:30 --> Hooks Class Initialized
DEBUG - 2011-10-07 05:02:30 --> Utf8 Class Initialized
DEBUG - 2011-10-07 05:02:30 --> UTF-8 Support Enabled
DEBUG - 2011-10-07 05:02:30 --> URI Class Initialized
DEBUG - 2011-10-07 05:02:30 --> Router Class Initialized
DEBUG - 2011-10-07 05:02:30 --> Output Class Initialized
DEBUG - 2011-10-07 05:02:30 --> Input Class Initialized
DEBUG - 2011-10-07 05:02:30 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-07 05:02:30 --> Language Class Initialized
DEBUG - 2011-10-07 05:02:30 --> Loader Class Initialized
DEBUG - 2011-10-07 05:02:30 --> Controller Class Initialized
DEBUG - 2011-10-07 05:02:30 --> Model Class Initialized
DEBUG - 2011-10-07 05:02:30 --> Model Class Initialized
DEBUG - 2011-10-07 05:02:30 --> Model Class Initialized
DEBUG - 2011-10-07 05:02:30 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-07 05:02:30 --> Database Driver Class Initialized
DEBUG - 2011-10-07 05:02:32 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-07 05:02:32 --> Helper loaded: url_helper
DEBUG - 2011-10-07 05:02:32 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-07 05:02:32 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-07 05:02:32 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-07 05:02:32 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-07 05:02:32 --> Final output sent to browser
DEBUG - 2011-10-07 05:02:32 --> Total execution time: 1.6396
DEBUG - 2011-10-07 05:02:33 --> Config Class Initialized
DEBUG - 2011-10-07 05:02:33 --> Hooks Class Initialized
DEBUG - 2011-10-07 05:02:33 --> Utf8 Class Initialized
DEBUG - 2011-10-07 05:02:33 --> UTF-8 Support Enabled
DEBUG - 2011-10-07 05:02:33 --> URI Class Initialized
DEBUG - 2011-10-07 05:02:33 --> Router Class Initialized
DEBUG - 2011-10-07 05:02:33 --> Output Class Initialized
DEBUG - 2011-10-07 05:02:33 --> Input Class Initialized
DEBUG - 2011-10-07 05:02:33 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-07 05:02:33 --> Language Class Initialized
DEBUG - 2011-10-07 05:02:33 --> Loader Class Initialized
DEBUG - 2011-10-07 05:02:33 --> Controller Class Initialized
ERROR - 2011-10-07 05:02:33 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-10-07 05:02:33 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-10-07 05:02:33 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-07 05:02:33 --> Model Class Initialized
DEBUG - 2011-10-07 05:02:33 --> Model Class Initialized
DEBUG - 2011-10-07 05:02:33 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-07 05:02:33 --> Database Driver Class Initialized
DEBUG - 2011-10-07 05:02:33 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-07 05:02:33 --> Helper loaded: url_helper
DEBUG - 2011-10-07 05:02:33 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-07 05:02:33 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-07 05:02:33 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-07 05:02:33 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-07 05:02:33 --> Final output sent to browser
DEBUG - 2011-10-07 05:02:33 --> Total execution time: 0.0932
DEBUG - 2011-10-07 05:31:36 --> Config Class Initialized
DEBUG - 2011-10-07 05:31:36 --> Hooks Class Initialized
DEBUG - 2011-10-07 05:31:36 --> Utf8 Class Initialized
DEBUG - 2011-10-07 05:31:36 --> UTF-8 Support Enabled
DEBUG - 2011-10-07 05:31:36 --> URI Class Initialized
DEBUG - 2011-10-07 05:31:36 --> Router Class Initialized
DEBUG - 2011-10-07 05:31:36 --> Output Class Initialized
DEBUG - 2011-10-07 05:31:36 --> Input Class Initialized
DEBUG - 2011-10-07 05:31:36 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-07 05:31:36 --> Language Class Initialized
DEBUG - 2011-10-07 05:31:36 --> Loader Class Initialized
DEBUG - 2011-10-07 05:31:36 --> Controller Class Initialized
DEBUG - 2011-10-07 05:31:36 --> Model Class Initialized
DEBUG - 2011-10-07 05:31:36 --> Model Class Initialized
DEBUG - 2011-10-07 05:31:36 --> Model Class Initialized
DEBUG - 2011-10-07 05:31:36 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-07 05:31:36 --> Database Driver Class Initialized
DEBUG - 2011-10-07 05:31:53 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-07 05:31:53 --> Helper loaded: url_helper
DEBUG - 2011-10-07 05:31:53 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-07 05:31:53 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-07 05:31:53 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-07 05:31:53 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-07 05:31:53 --> Final output sent to browser
DEBUG - 2011-10-07 05:31:53 --> Total execution time: 16.3485
DEBUG - 2011-10-07 05:46:06 --> Config Class Initialized
DEBUG - 2011-10-07 05:46:06 --> Hooks Class Initialized
DEBUG - 2011-10-07 05:46:06 --> Utf8 Class Initialized
DEBUG - 2011-10-07 05:46:06 --> UTF-8 Support Enabled
DEBUG - 2011-10-07 05:46:06 --> URI Class Initialized
DEBUG - 2011-10-07 05:46:06 --> Router Class Initialized
DEBUG - 2011-10-07 05:46:06 --> Output Class Initialized
DEBUG - 2011-10-07 05:46:06 --> Input Class Initialized
DEBUG - 2011-10-07 05:46:06 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-07 05:46:06 --> Language Class Initialized
DEBUG - 2011-10-07 05:46:06 --> Loader Class Initialized
DEBUG - 2011-10-07 05:46:06 --> Controller Class Initialized
ERROR - 2011-10-07 05:46:06 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-10-07 05:46:06 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-10-07 05:46:06 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-07 05:46:06 --> Model Class Initialized
DEBUG - 2011-10-07 05:46:06 --> Model Class Initialized
DEBUG - 2011-10-07 05:46:06 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-07 05:46:06 --> Database Driver Class Initialized
DEBUG - 2011-10-07 05:46:06 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-07 05:46:06 --> Helper loaded: url_helper
DEBUG - 2011-10-07 05:46:06 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-07 05:46:06 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-07 05:46:06 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-07 05:46:06 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-07 05:46:06 --> Final output sent to browser
DEBUG - 2011-10-07 05:46:06 --> Total execution time: 0.1349
DEBUG - 2011-10-07 05:46:09 --> Config Class Initialized
DEBUG - 2011-10-07 05:46:09 --> Hooks Class Initialized
DEBUG - 2011-10-07 05:46:09 --> Utf8 Class Initialized
DEBUG - 2011-10-07 05:46:09 --> UTF-8 Support Enabled
DEBUG - 2011-10-07 05:46:09 --> URI Class Initialized
DEBUG - 2011-10-07 05:46:09 --> Router Class Initialized
DEBUG - 2011-10-07 05:46:09 --> Output Class Initialized
DEBUG - 2011-10-07 05:46:09 --> Input Class Initialized
DEBUG - 2011-10-07 05:46:09 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-07 05:46:09 --> Language Class Initialized
DEBUG - 2011-10-07 05:46:09 --> Loader Class Initialized
DEBUG - 2011-10-07 05:46:09 --> Controller Class Initialized
DEBUG - 2011-10-07 05:46:09 --> Model Class Initialized
DEBUG - 2011-10-07 05:46:09 --> Model Class Initialized
DEBUG - 2011-10-07 05:46:09 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-07 05:46:09 --> Database Driver Class Initialized
DEBUG - 2011-10-07 05:46:10 --> Final output sent to browser
DEBUG - 2011-10-07 05:46:10 --> Total execution time: 0.6368
DEBUG - 2011-10-07 05:46:13 --> Config Class Initialized
DEBUG - 2011-10-07 05:46:13 --> Hooks Class Initialized
DEBUG - 2011-10-07 05:46:13 --> Utf8 Class Initialized
DEBUG - 2011-10-07 05:46:13 --> UTF-8 Support Enabled
DEBUG - 2011-10-07 05:46:13 --> URI Class Initialized
DEBUG - 2011-10-07 05:46:13 --> Router Class Initialized
ERROR - 2011-10-07 05:46:13 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-07 05:46:14 --> Config Class Initialized
DEBUG - 2011-10-07 05:46:14 --> Hooks Class Initialized
DEBUG - 2011-10-07 05:46:14 --> Utf8 Class Initialized
DEBUG - 2011-10-07 05:46:14 --> UTF-8 Support Enabled
DEBUG - 2011-10-07 05:46:14 --> URI Class Initialized
DEBUG - 2011-10-07 05:46:14 --> Router Class Initialized
ERROR - 2011-10-07 05:46:14 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-07 05:46:39 --> Config Class Initialized
DEBUG - 2011-10-07 05:46:39 --> Hooks Class Initialized
DEBUG - 2011-10-07 05:46:39 --> Utf8 Class Initialized
DEBUG - 2011-10-07 05:46:39 --> UTF-8 Support Enabled
DEBUG - 2011-10-07 05:46:39 --> URI Class Initialized
DEBUG - 2011-10-07 05:46:39 --> Router Class Initialized
DEBUG - 2011-10-07 05:46:39 --> Output Class Initialized
DEBUG - 2011-10-07 05:46:39 --> Input Class Initialized
DEBUG - 2011-10-07 05:46:39 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-07 05:46:39 --> Language Class Initialized
DEBUG - 2011-10-07 05:46:39 --> Loader Class Initialized
DEBUG - 2011-10-07 05:46:39 --> Controller Class Initialized
ERROR - 2011-10-07 05:46:39 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-10-07 05:46:39 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-10-07 05:46:39 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-07 05:46:39 --> Model Class Initialized
DEBUG - 2011-10-07 05:46:39 --> Model Class Initialized
DEBUG - 2011-10-07 05:46:39 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-07 05:46:39 --> Database Driver Class Initialized
DEBUG - 2011-10-07 05:46:39 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-07 05:46:39 --> Helper loaded: url_helper
DEBUG - 2011-10-07 05:46:39 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-07 05:46:39 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-07 05:46:39 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-07 05:46:39 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-07 05:46:39 --> Final output sent to browser
DEBUG - 2011-10-07 05:46:39 --> Total execution time: 0.0340
DEBUG - 2011-10-07 05:46:40 --> Config Class Initialized
DEBUG - 2011-10-07 05:46:40 --> Hooks Class Initialized
DEBUG - 2011-10-07 05:46:40 --> Utf8 Class Initialized
DEBUG - 2011-10-07 05:46:40 --> UTF-8 Support Enabled
DEBUG - 2011-10-07 05:46:40 --> URI Class Initialized
DEBUG - 2011-10-07 05:46:40 --> Router Class Initialized
DEBUG - 2011-10-07 05:46:40 --> Output Class Initialized
DEBUG - 2011-10-07 05:46:40 --> Input Class Initialized
DEBUG - 2011-10-07 05:46:40 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-07 05:46:40 --> Language Class Initialized
DEBUG - 2011-10-07 05:46:40 --> Loader Class Initialized
DEBUG - 2011-10-07 05:46:40 --> Controller Class Initialized
DEBUG - 2011-10-07 05:46:40 --> Model Class Initialized
DEBUG - 2011-10-07 05:46:40 --> Model Class Initialized
DEBUG - 2011-10-07 05:46:40 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-07 05:46:40 --> Database Driver Class Initialized
DEBUG - 2011-10-07 05:46:40 --> Config Class Initialized
DEBUG - 2011-10-07 05:46:40 --> Hooks Class Initialized
DEBUG - 2011-10-07 05:46:40 --> Utf8 Class Initialized
DEBUG - 2011-10-07 05:46:40 --> UTF-8 Support Enabled
DEBUG - 2011-10-07 05:46:40 --> URI Class Initialized
DEBUG - 2011-10-07 05:46:40 --> Router Class Initialized
DEBUG - 2011-10-07 05:46:40 --> Output Class Initialized
DEBUG - 2011-10-07 05:46:40 --> Input Class Initialized
DEBUG - 2011-10-07 05:46:40 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-07 05:46:40 --> Language Class Initialized
DEBUG - 2011-10-07 05:46:40 --> Loader Class Initialized
DEBUG - 2011-10-07 05:46:40 --> Controller Class Initialized
ERROR - 2011-10-07 05:46:40 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-10-07 05:46:40 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-10-07 05:46:40 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-07 05:46:40 --> Model Class Initialized
DEBUG - 2011-10-07 05:46:40 --> Model Class Initialized
DEBUG - 2011-10-07 05:46:40 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-07 05:46:40 --> Database Driver Class Initialized
DEBUG - 2011-10-07 05:46:40 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-07 05:46:40 --> Helper loaded: url_helper
DEBUG - 2011-10-07 05:46:40 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-07 05:46:40 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-07 05:46:40 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-07 05:46:40 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-07 05:46:40 --> Final output sent to browser
DEBUG - 2011-10-07 05:46:40 --> Total execution time: 0.0322
DEBUG - 2011-10-07 05:46:41 --> Final output sent to browser
DEBUG - 2011-10-07 05:46:41 --> Total execution time: 0.9484
DEBUG - 2011-10-07 05:46:43 --> Config Class Initialized
DEBUG - 2011-10-07 05:46:43 --> Hooks Class Initialized
DEBUG - 2011-10-07 05:46:43 --> Utf8 Class Initialized
DEBUG - 2011-10-07 05:46:43 --> UTF-8 Support Enabled
DEBUG - 2011-10-07 05:46:43 --> URI Class Initialized
DEBUG - 2011-10-07 05:46:43 --> Router Class Initialized
ERROR - 2011-10-07 05:46:43 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-07 05:47:00 --> Config Class Initialized
DEBUG - 2011-10-07 05:47:00 --> Hooks Class Initialized
DEBUG - 2011-10-07 05:47:00 --> Utf8 Class Initialized
DEBUG - 2011-10-07 05:47:00 --> UTF-8 Support Enabled
DEBUG - 2011-10-07 05:47:00 --> URI Class Initialized
DEBUG - 2011-10-07 05:47:00 --> Router Class Initialized
DEBUG - 2011-10-07 05:47:00 --> Output Class Initialized
DEBUG - 2011-10-07 05:47:00 --> Input Class Initialized
DEBUG - 2011-10-07 05:47:00 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-07 05:47:00 --> Language Class Initialized
DEBUG - 2011-10-07 05:47:00 --> Loader Class Initialized
DEBUG - 2011-10-07 05:47:00 --> Controller Class Initialized
ERROR - 2011-10-07 05:47:00 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-10-07 05:47:00 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-10-07 05:47:00 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-07 05:47:00 --> Model Class Initialized
DEBUG - 2011-10-07 05:47:00 --> Model Class Initialized
DEBUG - 2011-10-07 05:47:00 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-07 05:47:00 --> Database Driver Class Initialized
DEBUG - 2011-10-07 05:47:00 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-07 05:47:00 --> Helper loaded: url_helper
DEBUG - 2011-10-07 05:47:00 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-07 05:47:00 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-07 05:47:00 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-07 05:47:00 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-07 05:47:00 --> Final output sent to browser
DEBUG - 2011-10-07 05:47:00 --> Total execution time: 0.0317
DEBUG - 2011-10-07 05:47:02 --> Config Class Initialized
DEBUG - 2011-10-07 05:47:02 --> Hooks Class Initialized
DEBUG - 2011-10-07 05:47:02 --> Utf8 Class Initialized
DEBUG - 2011-10-07 05:47:02 --> UTF-8 Support Enabled
DEBUG - 2011-10-07 05:47:02 --> URI Class Initialized
DEBUG - 2011-10-07 05:47:02 --> Router Class Initialized
DEBUG - 2011-10-07 05:47:02 --> Output Class Initialized
DEBUG - 2011-10-07 05:47:02 --> Input Class Initialized
DEBUG - 2011-10-07 05:47:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-07 05:47:02 --> Language Class Initialized
DEBUG - 2011-10-07 05:47:02 --> Loader Class Initialized
DEBUG - 2011-10-07 05:47:02 --> Controller Class Initialized
DEBUG - 2011-10-07 05:47:02 --> Model Class Initialized
DEBUG - 2011-10-07 05:47:02 --> Model Class Initialized
DEBUG - 2011-10-07 05:47:02 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-07 05:47:02 --> Database Driver Class Initialized
DEBUG - 2011-10-07 05:47:02 --> Config Class Initialized
DEBUG - 2011-10-07 05:47:02 --> Hooks Class Initialized
DEBUG - 2011-10-07 05:47:02 --> Utf8 Class Initialized
DEBUG - 2011-10-07 05:47:02 --> UTF-8 Support Enabled
DEBUG - 2011-10-07 05:47:02 --> URI Class Initialized
DEBUG - 2011-10-07 05:47:02 --> Router Class Initialized
DEBUG - 2011-10-07 05:47:02 --> Output Class Initialized
DEBUG - 2011-10-07 05:47:02 --> Input Class Initialized
DEBUG - 2011-10-07 05:47:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-07 05:47:02 --> Language Class Initialized
DEBUG - 2011-10-07 05:47:02 --> Loader Class Initialized
DEBUG - 2011-10-07 05:47:02 --> Controller Class Initialized
ERROR - 2011-10-07 05:47:02 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-10-07 05:47:02 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-10-07 05:47:02 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-07 05:47:02 --> Model Class Initialized
DEBUG - 2011-10-07 05:47:02 --> Model Class Initialized
DEBUG - 2011-10-07 05:47:02 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-07 05:47:02 --> Database Driver Class Initialized
DEBUG - 2011-10-07 05:47:02 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-07 05:47:02 --> Helper loaded: url_helper
DEBUG - 2011-10-07 05:47:02 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-07 05:47:02 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-07 05:47:02 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-07 05:47:02 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-07 05:47:02 --> Final output sent to browser
DEBUG - 2011-10-07 05:47:02 --> Total execution time: 0.0423
DEBUG - 2011-10-07 05:47:03 --> Final output sent to browser
DEBUG - 2011-10-07 05:47:03 --> Total execution time: 0.6369
DEBUG - 2011-10-07 05:47:04 --> Config Class Initialized
DEBUG - 2011-10-07 05:47:04 --> Hooks Class Initialized
DEBUG - 2011-10-07 05:47:04 --> Utf8 Class Initialized
DEBUG - 2011-10-07 05:47:04 --> UTF-8 Support Enabled
DEBUG - 2011-10-07 05:47:04 --> URI Class Initialized
DEBUG - 2011-10-07 05:47:04 --> Router Class Initialized
ERROR - 2011-10-07 05:47:04 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-07 05:47:09 --> Config Class Initialized
DEBUG - 2011-10-07 05:47:09 --> Hooks Class Initialized
DEBUG - 2011-10-07 05:47:09 --> Utf8 Class Initialized
DEBUG - 2011-10-07 05:47:09 --> UTF-8 Support Enabled
DEBUG - 2011-10-07 05:47:09 --> URI Class Initialized
DEBUG - 2011-10-07 05:47:09 --> Router Class Initialized
DEBUG - 2011-10-07 05:47:09 --> Output Class Initialized
DEBUG - 2011-10-07 05:47:09 --> Input Class Initialized
DEBUG - 2011-10-07 05:47:09 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-07 05:47:09 --> Language Class Initialized
DEBUG - 2011-10-07 05:47:09 --> Loader Class Initialized
DEBUG - 2011-10-07 05:47:09 --> Controller Class Initialized
ERROR - 2011-10-07 05:47:09 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-10-07 05:47:09 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-10-07 05:47:09 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-07 05:47:09 --> Model Class Initialized
DEBUG - 2011-10-07 05:47:09 --> Model Class Initialized
DEBUG - 2011-10-07 05:47:09 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-07 05:47:09 --> Database Driver Class Initialized
DEBUG - 2011-10-07 05:47:09 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-07 05:47:09 --> Helper loaded: url_helper
DEBUG - 2011-10-07 05:47:09 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-07 05:47:09 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-07 05:47:09 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-07 05:47:09 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-07 05:47:09 --> Final output sent to browser
DEBUG - 2011-10-07 05:47:09 --> Total execution time: 0.0354
DEBUG - 2011-10-07 05:47:10 --> Config Class Initialized
DEBUG - 2011-10-07 05:47:10 --> Hooks Class Initialized
DEBUG - 2011-10-07 05:47:10 --> Utf8 Class Initialized
DEBUG - 2011-10-07 05:47:10 --> UTF-8 Support Enabled
DEBUG - 2011-10-07 05:47:10 --> URI Class Initialized
DEBUG - 2011-10-07 05:47:10 --> Router Class Initialized
DEBUG - 2011-10-07 05:47:10 --> Output Class Initialized
DEBUG - 2011-10-07 05:47:10 --> Input Class Initialized
DEBUG - 2011-10-07 05:47:10 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-07 05:47:10 --> Language Class Initialized
DEBUG - 2011-10-07 05:47:10 --> Loader Class Initialized
DEBUG - 2011-10-07 05:47:10 --> Controller Class Initialized
DEBUG - 2011-10-07 05:47:10 --> Model Class Initialized
DEBUG - 2011-10-07 05:47:10 --> Model Class Initialized
DEBUG - 2011-10-07 05:47:10 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-07 05:47:10 --> Database Driver Class Initialized
DEBUG - 2011-10-07 05:47:12 --> Final output sent to browser
DEBUG - 2011-10-07 05:47:12 --> Total execution time: 1.3166
DEBUG - 2011-10-07 05:47:13 --> Config Class Initialized
DEBUG - 2011-10-07 05:47:13 --> Hooks Class Initialized
DEBUG - 2011-10-07 05:47:13 --> Utf8 Class Initialized
DEBUG - 2011-10-07 05:47:13 --> UTF-8 Support Enabled
DEBUG - 2011-10-07 05:47:13 --> URI Class Initialized
DEBUG - 2011-10-07 05:47:13 --> Router Class Initialized
ERROR - 2011-10-07 05:47:13 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-07 05:47:22 --> Config Class Initialized
DEBUG - 2011-10-07 05:47:22 --> Hooks Class Initialized
DEBUG - 2011-10-07 05:47:22 --> Utf8 Class Initialized
DEBUG - 2011-10-07 05:47:22 --> UTF-8 Support Enabled
DEBUG - 2011-10-07 05:47:22 --> URI Class Initialized
DEBUG - 2011-10-07 05:47:22 --> Router Class Initialized
DEBUG - 2011-10-07 05:47:22 --> Output Class Initialized
DEBUG - 2011-10-07 05:47:22 --> Input Class Initialized
DEBUG - 2011-10-07 05:47:22 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-07 05:47:22 --> Language Class Initialized
DEBUG - 2011-10-07 05:47:22 --> Loader Class Initialized
DEBUG - 2011-10-07 05:47:22 --> Controller Class Initialized
ERROR - 2011-10-07 05:47:22 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-10-07 05:47:22 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-10-07 05:47:22 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-07 05:47:22 --> Model Class Initialized
DEBUG - 2011-10-07 05:47:22 --> Model Class Initialized
DEBUG - 2011-10-07 05:47:22 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-07 05:47:22 --> Database Driver Class Initialized
DEBUG - 2011-10-07 05:47:22 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-07 05:47:22 --> Helper loaded: url_helper
DEBUG - 2011-10-07 05:47:22 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-07 05:47:22 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-07 05:47:22 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-07 05:47:22 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-07 05:47:22 --> Final output sent to browser
DEBUG - 2011-10-07 05:47:22 --> Total execution time: 0.0362
DEBUG - 2011-10-07 05:47:23 --> Config Class Initialized
DEBUG - 2011-10-07 05:47:23 --> Hooks Class Initialized
DEBUG - 2011-10-07 05:47:23 --> Utf8 Class Initialized
DEBUG - 2011-10-07 05:47:23 --> UTF-8 Support Enabled
DEBUG - 2011-10-07 05:47:23 --> URI Class Initialized
DEBUG - 2011-10-07 05:47:23 --> Router Class Initialized
DEBUG - 2011-10-07 05:47:23 --> Output Class Initialized
DEBUG - 2011-10-07 05:47:23 --> Input Class Initialized
DEBUG - 2011-10-07 05:47:23 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-07 05:47:23 --> Language Class Initialized
DEBUG - 2011-10-07 05:47:23 --> Loader Class Initialized
DEBUG - 2011-10-07 05:47:23 --> Controller Class Initialized
DEBUG - 2011-10-07 05:47:23 --> Model Class Initialized
DEBUG - 2011-10-07 05:47:23 --> Model Class Initialized
DEBUG - 2011-10-07 05:47:23 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-07 05:47:23 --> Database Driver Class Initialized
DEBUG - 2011-10-07 05:47:23 --> Final output sent to browser
DEBUG - 2011-10-07 05:47:23 --> Total execution time: 0.5467
DEBUG - 2011-10-07 05:47:25 --> Config Class Initialized
DEBUG - 2011-10-07 05:47:25 --> Hooks Class Initialized
DEBUG - 2011-10-07 05:47:25 --> Utf8 Class Initialized
DEBUG - 2011-10-07 05:47:25 --> UTF-8 Support Enabled
DEBUG - 2011-10-07 05:47:25 --> URI Class Initialized
DEBUG - 2011-10-07 05:47:25 --> Router Class Initialized
ERROR - 2011-10-07 05:47:25 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-07 05:47:47 --> Config Class Initialized
DEBUG - 2011-10-07 05:47:47 --> Hooks Class Initialized
DEBUG - 2011-10-07 05:47:47 --> Utf8 Class Initialized
DEBUG - 2011-10-07 05:47:47 --> UTF-8 Support Enabled
DEBUG - 2011-10-07 05:47:47 --> URI Class Initialized
DEBUG - 2011-10-07 05:47:47 --> Router Class Initialized
DEBUG - 2011-10-07 05:47:47 --> Output Class Initialized
DEBUG - 2011-10-07 05:47:47 --> Input Class Initialized
DEBUG - 2011-10-07 05:47:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-07 05:47:47 --> Language Class Initialized
DEBUG - 2011-10-07 05:47:47 --> Loader Class Initialized
DEBUG - 2011-10-07 05:47:47 --> Controller Class Initialized
ERROR - 2011-10-07 05:47:47 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-10-07 05:47:47 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-10-07 05:47:47 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-07 05:47:47 --> Model Class Initialized
DEBUG - 2011-10-07 05:47:47 --> Model Class Initialized
DEBUG - 2011-10-07 05:47:47 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-07 05:47:47 --> Database Driver Class Initialized
DEBUG - 2011-10-07 05:47:47 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-07 05:47:47 --> Helper loaded: url_helper
DEBUG - 2011-10-07 05:47:47 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-07 05:47:47 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-07 05:47:47 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-07 05:47:47 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-07 05:47:47 --> Final output sent to browser
DEBUG - 2011-10-07 05:47:47 --> Total execution time: 0.0313
DEBUG - 2011-10-07 05:47:48 --> Config Class Initialized
DEBUG - 2011-10-07 05:47:48 --> Hooks Class Initialized
DEBUG - 2011-10-07 05:47:48 --> Utf8 Class Initialized
DEBUG - 2011-10-07 05:47:48 --> UTF-8 Support Enabled
DEBUG - 2011-10-07 05:47:48 --> URI Class Initialized
DEBUG - 2011-10-07 05:47:48 --> Router Class Initialized
DEBUG - 2011-10-07 05:47:48 --> Output Class Initialized
DEBUG - 2011-10-07 05:47:48 --> Input Class Initialized
DEBUG - 2011-10-07 05:47:48 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-07 05:47:48 --> Language Class Initialized
DEBUG - 2011-10-07 05:47:48 --> Loader Class Initialized
DEBUG - 2011-10-07 05:47:48 --> Controller Class Initialized
DEBUG - 2011-10-07 05:47:48 --> Model Class Initialized
DEBUG - 2011-10-07 05:47:48 --> Model Class Initialized
DEBUG - 2011-10-07 05:47:48 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-07 05:47:48 --> Database Driver Class Initialized
DEBUG - 2011-10-07 05:47:49 --> Final output sent to browser
DEBUG - 2011-10-07 05:47:49 --> Total execution time: 0.6142
DEBUG - 2011-10-07 05:47:50 --> Config Class Initialized
DEBUG - 2011-10-07 05:47:50 --> Hooks Class Initialized
DEBUG - 2011-10-07 05:47:50 --> Utf8 Class Initialized
DEBUG - 2011-10-07 05:47:50 --> UTF-8 Support Enabled
DEBUG - 2011-10-07 05:47:50 --> URI Class Initialized
DEBUG - 2011-10-07 05:47:50 --> Router Class Initialized
ERROR - 2011-10-07 05:47:50 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-07 05:48:37 --> Config Class Initialized
DEBUG - 2011-10-07 05:48:37 --> Hooks Class Initialized
DEBUG - 2011-10-07 05:48:37 --> Utf8 Class Initialized
DEBUG - 2011-10-07 05:48:37 --> UTF-8 Support Enabled
DEBUG - 2011-10-07 05:48:37 --> URI Class Initialized
DEBUG - 2011-10-07 05:48:37 --> Router Class Initialized
DEBUG - 2011-10-07 05:48:37 --> Output Class Initialized
DEBUG - 2011-10-07 05:48:37 --> Input Class Initialized
DEBUG - 2011-10-07 05:48:37 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-07 05:48:37 --> Language Class Initialized
DEBUG - 2011-10-07 05:48:37 --> Loader Class Initialized
DEBUG - 2011-10-07 05:48:37 --> Controller Class Initialized
ERROR - 2011-10-07 05:48:37 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-10-07 05:48:37 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-10-07 05:48:37 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-07 05:48:37 --> Model Class Initialized
DEBUG - 2011-10-07 05:48:37 --> Model Class Initialized
DEBUG - 2011-10-07 05:48:37 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-07 05:48:37 --> Database Driver Class Initialized
DEBUG - 2011-10-07 05:48:37 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-07 05:48:37 --> Helper loaded: url_helper
DEBUG - 2011-10-07 05:48:37 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-07 05:48:37 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-07 05:48:37 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-07 05:48:37 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-07 05:48:37 --> Final output sent to browser
DEBUG - 2011-10-07 05:48:37 --> Total execution time: 0.0320
DEBUG - 2011-10-07 05:48:41 --> Config Class Initialized
DEBUG - 2011-10-07 05:48:41 --> Hooks Class Initialized
DEBUG - 2011-10-07 05:48:41 --> Utf8 Class Initialized
DEBUG - 2011-10-07 05:48:41 --> UTF-8 Support Enabled
DEBUG - 2011-10-07 05:48:41 --> URI Class Initialized
DEBUG - 2011-10-07 05:48:41 --> Router Class Initialized
DEBUG - 2011-10-07 05:48:41 --> Output Class Initialized
DEBUG - 2011-10-07 05:48:41 --> Input Class Initialized
DEBUG - 2011-10-07 05:48:41 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-07 05:48:41 --> Language Class Initialized
DEBUG - 2011-10-07 05:48:41 --> Loader Class Initialized
DEBUG - 2011-10-07 05:48:41 --> Controller Class Initialized
DEBUG - 2011-10-07 05:48:41 --> Model Class Initialized
DEBUG - 2011-10-07 05:48:41 --> Model Class Initialized
DEBUG - 2011-10-07 05:48:41 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-07 05:48:41 --> Database Driver Class Initialized
DEBUG - 2011-10-07 05:48:41 --> Final output sent to browser
DEBUG - 2011-10-07 05:48:41 --> Total execution time: 0.6375
DEBUG - 2011-10-07 05:49:55 --> Config Class Initialized
DEBUG - 2011-10-07 05:49:55 --> Hooks Class Initialized
DEBUG - 2011-10-07 05:49:55 --> Utf8 Class Initialized
DEBUG - 2011-10-07 05:49:55 --> UTF-8 Support Enabled
DEBUG - 2011-10-07 05:49:55 --> URI Class Initialized
DEBUG - 2011-10-07 05:49:55 --> Router Class Initialized
DEBUG - 2011-10-07 05:49:55 --> Output Class Initialized
DEBUG - 2011-10-07 05:49:55 --> Input Class Initialized
DEBUG - 2011-10-07 05:49:55 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-07 05:49:55 --> Language Class Initialized
DEBUG - 2011-10-07 05:49:55 --> Loader Class Initialized
DEBUG - 2011-10-07 05:49:55 --> Controller Class Initialized
DEBUG - 2011-10-07 05:49:55 --> Model Class Initialized
DEBUG - 2011-10-07 05:49:55 --> Model Class Initialized
DEBUG - 2011-10-07 05:49:55 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-07 05:49:55 --> Database Driver Class Initialized
DEBUG - 2011-10-07 05:49:56 --> Final output sent to browser
DEBUG - 2011-10-07 05:49:56 --> Total execution time: 0.6966
DEBUG - 2011-10-07 05:50:03 --> Config Class Initialized
DEBUG - 2011-10-07 05:50:03 --> Hooks Class Initialized
DEBUG - 2011-10-07 05:50:03 --> Utf8 Class Initialized
DEBUG - 2011-10-07 05:50:03 --> UTF-8 Support Enabled
DEBUG - 2011-10-07 05:50:03 --> URI Class Initialized
DEBUG - 2011-10-07 05:50:03 --> Router Class Initialized
DEBUG - 2011-10-07 05:50:03 --> Output Class Initialized
DEBUG - 2011-10-07 05:50:03 --> Input Class Initialized
DEBUG - 2011-10-07 05:50:03 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-07 05:50:03 --> Language Class Initialized
DEBUG - 2011-10-07 05:50:03 --> Loader Class Initialized
DEBUG - 2011-10-07 05:50:03 --> Controller Class Initialized
ERROR - 2011-10-07 05:50:03 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-10-07 05:50:03 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-10-07 05:50:03 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-07 05:50:03 --> Model Class Initialized
DEBUG - 2011-10-07 05:50:03 --> Model Class Initialized
DEBUG - 2011-10-07 05:50:03 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-07 05:50:03 --> Database Driver Class Initialized
DEBUG - 2011-10-07 05:50:04 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-07 05:50:04 --> Helper loaded: url_helper
DEBUG - 2011-10-07 05:50:04 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-07 05:50:04 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-07 05:50:04 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-07 05:50:04 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-07 05:50:04 --> Final output sent to browser
DEBUG - 2011-10-07 05:50:04 --> Total execution time: 0.2547
DEBUG - 2011-10-07 05:50:07 --> Config Class Initialized
DEBUG - 2011-10-07 05:50:07 --> Hooks Class Initialized
DEBUG - 2011-10-07 05:50:07 --> Utf8 Class Initialized
DEBUG - 2011-10-07 05:50:07 --> UTF-8 Support Enabled
DEBUG - 2011-10-07 05:50:07 --> URI Class Initialized
DEBUG - 2011-10-07 05:50:07 --> Router Class Initialized
DEBUG - 2011-10-07 05:50:07 --> Output Class Initialized
DEBUG - 2011-10-07 05:50:07 --> Input Class Initialized
DEBUG - 2011-10-07 05:50:07 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-07 05:50:07 --> Language Class Initialized
DEBUG - 2011-10-07 05:50:07 --> Loader Class Initialized
DEBUG - 2011-10-07 05:50:07 --> Controller Class Initialized
DEBUG - 2011-10-07 05:50:07 --> Model Class Initialized
DEBUG - 2011-10-07 05:50:07 --> Model Class Initialized
DEBUG - 2011-10-07 05:50:07 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-07 05:50:07 --> Database Driver Class Initialized
DEBUG - 2011-10-07 05:50:08 --> Final output sent to browser
DEBUG - 2011-10-07 05:50:08 --> Total execution time: 0.8357
DEBUG - 2011-10-07 05:50:36 --> Config Class Initialized
DEBUG - 2011-10-07 05:50:36 --> Hooks Class Initialized
DEBUG - 2011-10-07 05:50:36 --> Utf8 Class Initialized
DEBUG - 2011-10-07 05:50:36 --> UTF-8 Support Enabled
DEBUG - 2011-10-07 05:50:36 --> URI Class Initialized
DEBUG - 2011-10-07 05:50:36 --> Router Class Initialized
DEBUG - 2011-10-07 05:50:36 --> Output Class Initialized
DEBUG - 2011-10-07 05:50:36 --> Input Class Initialized
DEBUG - 2011-10-07 05:50:36 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-07 05:50:36 --> Language Class Initialized
DEBUG - 2011-10-07 05:50:36 --> Loader Class Initialized
DEBUG - 2011-10-07 05:50:36 --> Controller Class Initialized
ERROR - 2011-10-07 05:50:36 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-10-07 05:50:36 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-10-07 05:50:36 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-07 05:50:36 --> Model Class Initialized
DEBUG - 2011-10-07 05:50:36 --> Model Class Initialized
DEBUG - 2011-10-07 05:50:36 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-07 05:50:36 --> Database Driver Class Initialized
DEBUG - 2011-10-07 05:50:36 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-07 05:50:36 --> Helper loaded: url_helper
DEBUG - 2011-10-07 05:50:36 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-07 05:50:36 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-07 05:50:36 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-07 05:50:36 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-07 05:50:36 --> Final output sent to browser
DEBUG - 2011-10-07 05:50:36 --> Total execution time: 0.0300
DEBUG - 2011-10-07 05:50:41 --> Config Class Initialized
DEBUG - 2011-10-07 05:50:41 --> Hooks Class Initialized
DEBUG - 2011-10-07 05:50:41 --> Utf8 Class Initialized
DEBUG - 2011-10-07 05:50:41 --> UTF-8 Support Enabled
DEBUG - 2011-10-07 05:50:41 --> URI Class Initialized
DEBUG - 2011-10-07 05:50:41 --> Router Class Initialized
DEBUG - 2011-10-07 05:50:41 --> Output Class Initialized
DEBUG - 2011-10-07 05:50:41 --> Input Class Initialized
DEBUG - 2011-10-07 05:50:41 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-07 05:50:41 --> Language Class Initialized
DEBUG - 2011-10-07 05:50:41 --> Loader Class Initialized
DEBUG - 2011-10-07 05:50:41 --> Controller Class Initialized
DEBUG - 2011-10-07 05:50:41 --> Model Class Initialized
DEBUG - 2011-10-07 05:50:41 --> Model Class Initialized
DEBUG - 2011-10-07 05:50:41 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-07 05:50:41 --> Database Driver Class Initialized
DEBUG - 2011-10-07 05:50:41 --> Final output sent to browser
DEBUG - 2011-10-07 05:50:41 --> Total execution time: 0.5042
DEBUG - 2011-10-07 05:56:18 --> Config Class Initialized
DEBUG - 2011-10-07 05:56:18 --> Hooks Class Initialized
DEBUG - 2011-10-07 05:56:18 --> Utf8 Class Initialized
DEBUG - 2011-10-07 05:56:18 --> UTF-8 Support Enabled
DEBUG - 2011-10-07 05:56:18 --> URI Class Initialized
DEBUG - 2011-10-07 05:56:18 --> Router Class Initialized
DEBUG - 2011-10-07 05:56:18 --> Output Class Initialized
DEBUG - 2011-10-07 05:56:18 --> Input Class Initialized
DEBUG - 2011-10-07 05:56:18 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-07 05:56:18 --> Language Class Initialized
DEBUG - 2011-10-07 05:56:18 --> Loader Class Initialized
DEBUG - 2011-10-07 05:56:18 --> Controller Class Initialized
ERROR - 2011-10-07 05:56:18 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-10-07 05:56:18 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-10-07 05:56:18 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-07 05:56:18 --> Model Class Initialized
DEBUG - 2011-10-07 05:56:18 --> Model Class Initialized
DEBUG - 2011-10-07 05:56:18 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-07 05:56:18 --> Database Driver Class Initialized
DEBUG - 2011-10-07 05:56:18 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-07 05:56:18 --> Helper loaded: url_helper
DEBUG - 2011-10-07 05:56:18 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-07 05:56:18 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-07 05:56:18 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-07 05:56:18 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-07 05:56:18 --> Final output sent to browser
DEBUG - 2011-10-07 05:56:18 --> Total execution time: 0.0642
DEBUG - 2011-10-07 05:56:37 --> Config Class Initialized
DEBUG - 2011-10-07 05:56:37 --> Hooks Class Initialized
DEBUG - 2011-10-07 05:56:37 --> Utf8 Class Initialized
DEBUG - 2011-10-07 05:56:37 --> UTF-8 Support Enabled
DEBUG - 2011-10-07 05:56:37 --> URI Class Initialized
DEBUG - 2011-10-07 05:56:37 --> Router Class Initialized
DEBUG - 2011-10-07 05:56:37 --> Output Class Initialized
DEBUG - 2011-10-07 05:56:37 --> Input Class Initialized
DEBUG - 2011-10-07 05:56:37 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-07 05:56:37 --> Language Class Initialized
DEBUG - 2011-10-07 05:56:37 --> Loader Class Initialized
DEBUG - 2011-10-07 05:56:37 --> Controller Class Initialized
DEBUG - 2011-10-07 05:56:37 --> Model Class Initialized
DEBUG - 2011-10-07 05:56:37 --> Model Class Initialized
DEBUG - 2011-10-07 05:56:37 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-07 05:56:37 --> Database Driver Class Initialized
DEBUG - 2011-10-07 05:56:39 --> Final output sent to browser
DEBUG - 2011-10-07 05:56:39 --> Total execution time: 1.9204
DEBUG - 2011-10-07 06:10:14 --> Config Class Initialized
DEBUG - 2011-10-07 06:10:14 --> Hooks Class Initialized
DEBUG - 2011-10-07 06:10:14 --> Utf8 Class Initialized
DEBUG - 2011-10-07 06:10:14 --> UTF-8 Support Enabled
DEBUG - 2011-10-07 06:10:14 --> URI Class Initialized
DEBUG - 2011-10-07 06:10:14 --> Router Class Initialized
DEBUG - 2011-10-07 06:10:14 --> No URI present. Default controller set.
DEBUG - 2011-10-07 06:10:14 --> Output Class Initialized
DEBUG - 2011-10-07 06:10:14 --> Input Class Initialized
DEBUG - 2011-10-07 06:10:14 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-07 06:10:14 --> Language Class Initialized
DEBUG - 2011-10-07 06:10:14 --> Loader Class Initialized
DEBUG - 2011-10-07 06:10:14 --> Controller Class Initialized
DEBUG - 2011-10-07 06:10:15 --> File loaded: application/views/splash/main.php
DEBUG - 2011-10-07 06:10:15 --> Helper loaded: url_helper
DEBUG - 2011-10-07 06:10:15 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-07 06:10:15 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-07 06:10:15 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-07 06:10:15 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-07 06:10:15 --> Final output sent to browser
DEBUG - 2011-10-07 06:10:15 --> Total execution time: 0.1177
DEBUG - 2011-10-07 06:31:28 --> Config Class Initialized
DEBUG - 2011-10-07 06:31:28 --> Hooks Class Initialized
DEBUG - 2011-10-07 06:31:28 --> Utf8 Class Initialized
DEBUG - 2011-10-07 06:31:28 --> UTF-8 Support Enabled
DEBUG - 2011-10-07 06:31:28 --> URI Class Initialized
DEBUG - 2011-10-07 06:31:28 --> Router Class Initialized
DEBUG - 2011-10-07 06:31:28 --> Output Class Initialized
DEBUG - 2011-10-07 06:31:28 --> Input Class Initialized
DEBUG - 2011-10-07 06:31:28 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-07 06:31:28 --> Language Class Initialized
DEBUG - 2011-10-07 06:31:28 --> Loader Class Initialized
DEBUG - 2011-10-07 06:31:28 --> Controller Class Initialized
DEBUG - 2011-10-07 06:31:28 --> Model Class Initialized
DEBUG - 2011-10-07 06:31:28 --> Model Class Initialized
DEBUG - 2011-10-07 06:31:28 --> Model Class Initialized
DEBUG - 2011-10-07 06:31:28 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-07 06:31:28 --> Database Driver Class Initialized
DEBUG - 2011-10-07 06:31:30 --> Config Class Initialized
DEBUG - 2011-10-07 06:31:30 --> Hooks Class Initialized
DEBUG - 2011-10-07 06:31:30 --> Utf8 Class Initialized
DEBUG - 2011-10-07 06:31:30 --> UTF-8 Support Enabled
DEBUG - 2011-10-07 06:31:30 --> URI Class Initialized
DEBUG - 2011-10-07 06:31:30 --> Router Class Initialized
DEBUG - 2011-10-07 06:31:30 --> Output Class Initialized
DEBUG - 2011-10-07 06:31:30 --> Input Class Initialized
DEBUG - 2011-10-07 06:31:30 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-07 06:31:30 --> Language Class Initialized
DEBUG - 2011-10-07 06:31:30 --> Loader Class Initialized
DEBUG - 2011-10-07 06:31:30 --> Controller Class Initialized
ERROR - 2011-10-07 06:31:30 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-10-07 06:31:30 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-10-07 06:31:30 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-07 06:31:30 --> Model Class Initialized
DEBUG - 2011-10-07 06:31:30 --> Model Class Initialized
DEBUG - 2011-10-07 06:31:30 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-07 06:31:30 --> Database Driver Class Initialized
DEBUG - 2011-10-07 06:31:31 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-07 06:31:31 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-07 06:31:31 --> Helper loaded: url_helper
DEBUG - 2011-10-07 06:31:31 --> Helper loaded: url_helper
DEBUG - 2011-10-07 06:31:31 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-07 06:31:31 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-07 06:31:31 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-07 06:31:31 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-07 06:31:31 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-07 06:31:31 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-07 06:31:31 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-07 06:31:31 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-07 06:31:31 --> Final output sent to browser
DEBUG - 2011-10-07 06:31:31 --> Final output sent to browser
DEBUG - 2011-10-07 06:31:31 --> Total execution time: 3.1049
DEBUG - 2011-10-07 06:31:31 --> Total execution time: 1.1448
DEBUG - 2011-10-07 06:31:32 --> Config Class Initialized
DEBUG - 2011-10-07 06:31:32 --> Hooks Class Initialized
DEBUG - 2011-10-07 06:31:32 --> Utf8 Class Initialized
DEBUG - 2011-10-07 06:31:32 --> UTF-8 Support Enabled
DEBUG - 2011-10-07 06:31:32 --> URI Class Initialized
DEBUG - 2011-10-07 06:31:32 --> Router Class Initialized
DEBUG - 2011-10-07 06:31:32 --> Output Class Initialized
DEBUG - 2011-10-07 06:31:32 --> Input Class Initialized
DEBUG - 2011-10-07 06:31:32 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-07 06:31:32 --> Language Class Initialized
DEBUG - 2011-10-07 06:31:32 --> Loader Class Initialized
DEBUG - 2011-10-07 06:31:32 --> Controller Class Initialized
DEBUG - 2011-10-07 06:31:32 --> Model Class Initialized
DEBUG - 2011-10-07 06:31:32 --> Model Class Initialized
DEBUG - 2011-10-07 06:31:32 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-07 06:31:32 --> Database Driver Class Initialized
DEBUG - 2011-10-07 06:31:33 --> Final output sent to browser
DEBUG - 2011-10-07 06:31:33 --> Total execution time: 0.6273
DEBUG - 2011-10-07 07:40:48 --> Config Class Initialized
DEBUG - 2011-10-07 07:40:48 --> Hooks Class Initialized
DEBUG - 2011-10-07 07:40:48 --> Utf8 Class Initialized
DEBUG - 2011-10-07 07:40:48 --> UTF-8 Support Enabled
DEBUG - 2011-10-07 07:40:48 --> URI Class Initialized
DEBUG - 2011-10-07 07:40:48 --> Router Class Initialized
DEBUG - 2011-10-07 07:40:48 --> Output Class Initialized
DEBUG - 2011-10-07 07:40:48 --> Input Class Initialized
DEBUG - 2011-10-07 07:40:48 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-07 07:40:48 --> Language Class Initialized
DEBUG - 2011-10-07 07:40:48 --> Loader Class Initialized
DEBUG - 2011-10-07 07:40:48 --> Controller Class Initialized
DEBUG - 2011-10-07 07:40:48 --> Model Class Initialized
DEBUG - 2011-10-07 07:40:48 --> Model Class Initialized
DEBUG - 2011-10-07 07:40:48 --> Model Class Initialized
DEBUG - 2011-10-07 07:40:48 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-07 07:40:48 --> Database Driver Class Initialized
DEBUG - 2011-10-07 07:40:49 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-07 07:40:49 --> Helper loaded: url_helper
DEBUG - 2011-10-07 07:40:49 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-07 07:40:49 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-07 07:40:49 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-07 07:40:49 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-07 07:40:49 --> Final output sent to browser
DEBUG - 2011-10-07 07:40:49 --> Total execution time: 1.3141
DEBUG - 2011-10-07 07:48:27 --> Config Class Initialized
DEBUG - 2011-10-07 07:48:27 --> Hooks Class Initialized
DEBUG - 2011-10-07 07:48:27 --> Utf8 Class Initialized
DEBUG - 2011-10-07 07:48:27 --> UTF-8 Support Enabled
DEBUG - 2011-10-07 07:48:27 --> URI Class Initialized
DEBUG - 2011-10-07 07:48:27 --> Router Class Initialized
DEBUG - 2011-10-07 07:48:27 --> Output Class Initialized
DEBUG - 2011-10-07 07:48:27 --> Input Class Initialized
DEBUG - 2011-10-07 07:48:27 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-07 07:48:27 --> Language Class Initialized
DEBUG - 2011-10-07 07:48:27 --> Loader Class Initialized
DEBUG - 2011-10-07 07:48:27 --> Controller Class Initialized
ERROR - 2011-10-07 07:48:27 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-10-07 07:48:27 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-10-07 07:48:27 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-07 07:48:27 --> Model Class Initialized
DEBUG - 2011-10-07 07:48:27 --> Model Class Initialized
DEBUG - 2011-10-07 07:48:27 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-07 07:48:27 --> Database Driver Class Initialized
DEBUG - 2011-10-07 07:48:27 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-07 07:48:27 --> Helper loaded: url_helper
DEBUG - 2011-10-07 07:48:27 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-07 07:48:27 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-07 07:48:27 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-07 07:48:27 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-07 07:48:27 --> Final output sent to browser
DEBUG - 2011-10-07 07:48:27 --> Total execution time: 0.3936
DEBUG - 2011-10-07 07:48:28 --> Config Class Initialized
DEBUG - 2011-10-07 07:48:28 --> Hooks Class Initialized
DEBUG - 2011-10-07 07:48:28 --> Utf8 Class Initialized
DEBUG - 2011-10-07 07:48:28 --> UTF-8 Support Enabled
DEBUG - 2011-10-07 07:48:28 --> URI Class Initialized
DEBUG - 2011-10-07 07:48:28 --> Router Class Initialized
DEBUG - 2011-10-07 07:48:28 --> Output Class Initialized
DEBUG - 2011-10-07 07:48:28 --> Input Class Initialized
DEBUG - 2011-10-07 07:48:28 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-07 07:48:28 --> Language Class Initialized
DEBUG - 2011-10-07 07:48:28 --> Loader Class Initialized
DEBUG - 2011-10-07 07:48:28 --> Controller Class Initialized
DEBUG - 2011-10-07 07:48:28 --> Model Class Initialized
DEBUG - 2011-10-07 07:48:28 --> Model Class Initialized
DEBUG - 2011-10-07 07:48:28 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-07 07:48:28 --> Database Driver Class Initialized
DEBUG - 2011-10-07 07:48:29 --> Final output sent to browser
DEBUG - 2011-10-07 07:48:29 --> Total execution time: 0.6316
DEBUG - 2011-10-07 07:48:30 --> Config Class Initialized
DEBUG - 2011-10-07 07:48:30 --> Hooks Class Initialized
DEBUG - 2011-10-07 07:48:30 --> Utf8 Class Initialized
DEBUG - 2011-10-07 07:48:30 --> UTF-8 Support Enabled
DEBUG - 2011-10-07 07:48:30 --> URI Class Initialized
DEBUG - 2011-10-07 07:48:30 --> Router Class Initialized
ERROR - 2011-10-07 07:48:30 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-07 07:48:30 --> Config Class Initialized
DEBUG - 2011-10-07 07:48:30 --> Hooks Class Initialized
DEBUG - 2011-10-07 07:48:30 --> Utf8 Class Initialized
DEBUG - 2011-10-07 07:48:30 --> UTF-8 Support Enabled
DEBUG - 2011-10-07 07:48:30 --> URI Class Initialized
DEBUG - 2011-10-07 07:48:30 --> Router Class Initialized
ERROR - 2011-10-07 07:48:30 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-07 07:48:41 --> Config Class Initialized
DEBUG - 2011-10-07 07:48:41 --> Hooks Class Initialized
DEBUG - 2011-10-07 07:48:41 --> Utf8 Class Initialized
DEBUG - 2011-10-07 07:48:41 --> UTF-8 Support Enabled
DEBUG - 2011-10-07 07:48:41 --> URI Class Initialized
DEBUG - 2011-10-07 07:48:41 --> Router Class Initialized
DEBUG - 2011-10-07 07:48:41 --> Output Class Initialized
DEBUG - 2011-10-07 07:48:41 --> Input Class Initialized
DEBUG - 2011-10-07 07:48:41 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-07 07:48:41 --> Language Class Initialized
DEBUG - 2011-10-07 07:48:41 --> Loader Class Initialized
DEBUG - 2011-10-07 07:48:41 --> Controller Class Initialized
ERROR - 2011-10-07 07:48:41 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-10-07 07:48:41 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-10-07 07:48:41 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-07 07:48:41 --> Model Class Initialized
DEBUG - 2011-10-07 07:48:41 --> Model Class Initialized
DEBUG - 2011-10-07 07:48:41 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-07 07:48:41 --> Database Driver Class Initialized
DEBUG - 2011-10-07 07:48:41 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-07 07:48:41 --> Helper loaded: url_helper
DEBUG - 2011-10-07 07:48:41 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-07 07:48:41 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-07 07:48:41 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-07 07:48:41 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-07 07:48:41 --> Final output sent to browser
DEBUG - 2011-10-07 07:48:41 --> Total execution time: 0.1521
DEBUG - 2011-10-07 07:48:42 --> Config Class Initialized
DEBUG - 2011-10-07 07:48:42 --> Hooks Class Initialized
DEBUG - 2011-10-07 07:48:42 --> Utf8 Class Initialized
DEBUG - 2011-10-07 07:48:42 --> UTF-8 Support Enabled
DEBUG - 2011-10-07 07:48:42 --> URI Class Initialized
DEBUG - 2011-10-07 07:48:42 --> Router Class Initialized
DEBUG - 2011-10-07 07:48:42 --> Output Class Initialized
DEBUG - 2011-10-07 07:48:42 --> Input Class Initialized
DEBUG - 2011-10-07 07:48:42 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-07 07:48:42 --> Language Class Initialized
DEBUG - 2011-10-07 07:48:42 --> Loader Class Initialized
DEBUG - 2011-10-07 07:48:42 --> Controller Class Initialized
DEBUG - 2011-10-07 07:48:42 --> Model Class Initialized
DEBUG - 2011-10-07 07:48:42 --> Model Class Initialized
DEBUG - 2011-10-07 07:48:42 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-07 07:48:42 --> Database Driver Class Initialized
DEBUG - 2011-10-07 07:48:43 --> Final output sent to browser
DEBUG - 2011-10-07 07:48:43 --> Total execution time: 0.6769
DEBUG - 2011-10-07 07:48:58 --> Config Class Initialized
DEBUG - 2011-10-07 07:48:58 --> Hooks Class Initialized
DEBUG - 2011-10-07 07:48:58 --> Utf8 Class Initialized
DEBUG - 2011-10-07 07:48:58 --> UTF-8 Support Enabled
DEBUG - 2011-10-07 07:48:58 --> URI Class Initialized
DEBUG - 2011-10-07 07:48:58 --> Router Class Initialized
DEBUG - 2011-10-07 07:48:58 --> Output Class Initialized
DEBUG - 2011-10-07 07:48:58 --> Input Class Initialized
DEBUG - 2011-10-07 07:48:58 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-07 07:48:58 --> Language Class Initialized
DEBUG - 2011-10-07 07:48:58 --> Loader Class Initialized
DEBUG - 2011-10-07 07:48:58 --> Controller Class Initialized
ERROR - 2011-10-07 07:48:58 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-10-07 07:48:58 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-10-07 07:48:58 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-07 07:48:58 --> Model Class Initialized
DEBUG - 2011-10-07 07:48:58 --> Model Class Initialized
DEBUG - 2011-10-07 07:48:58 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-07 07:48:58 --> Database Driver Class Initialized
DEBUG - 2011-10-07 07:48:58 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-07 07:48:58 --> Helper loaded: url_helper
DEBUG - 2011-10-07 07:48:58 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-07 07:48:58 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-07 07:48:58 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-07 07:48:58 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-07 07:48:58 --> Final output sent to browser
DEBUG - 2011-10-07 07:48:58 --> Total execution time: 0.0444
DEBUG - 2011-10-07 07:49:18 --> Config Class Initialized
DEBUG - 2011-10-07 07:49:18 --> Hooks Class Initialized
DEBUG - 2011-10-07 07:49:18 --> Utf8 Class Initialized
DEBUG - 2011-10-07 07:49:18 --> UTF-8 Support Enabled
DEBUG - 2011-10-07 07:49:18 --> URI Class Initialized
DEBUG - 2011-10-07 07:49:18 --> Router Class Initialized
DEBUG - 2011-10-07 07:49:18 --> Output Class Initialized
DEBUG - 2011-10-07 07:49:18 --> Input Class Initialized
DEBUG - 2011-10-07 07:49:18 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-07 07:49:18 --> Language Class Initialized
DEBUG - 2011-10-07 07:49:18 --> Loader Class Initialized
DEBUG - 2011-10-07 07:49:18 --> Controller Class Initialized
DEBUG - 2011-10-07 07:49:18 --> Model Class Initialized
DEBUG - 2011-10-07 07:49:18 --> Model Class Initialized
DEBUG - 2011-10-07 07:49:18 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-07 07:49:18 --> Database Driver Class Initialized
DEBUG - 2011-10-07 07:49:19 --> Final output sent to browser
DEBUG - 2011-10-07 07:49:19 --> Total execution time: 0.3806
DEBUG - 2011-10-07 08:28:23 --> Config Class Initialized
DEBUG - 2011-10-07 08:28:23 --> Hooks Class Initialized
DEBUG - 2011-10-07 08:28:23 --> Utf8 Class Initialized
DEBUG - 2011-10-07 08:28:23 --> UTF-8 Support Enabled
DEBUG - 2011-10-07 08:28:24 --> URI Class Initialized
DEBUG - 2011-10-07 08:28:24 --> Router Class Initialized
DEBUG - 2011-10-07 08:28:24 --> No URI present. Default controller set.
DEBUG - 2011-10-07 08:28:24 --> Output Class Initialized
DEBUG - 2011-10-07 08:28:24 --> Input Class Initialized
DEBUG - 2011-10-07 08:28:24 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-07 08:28:24 --> Language Class Initialized
DEBUG - 2011-10-07 08:28:24 --> Loader Class Initialized
DEBUG - 2011-10-07 08:28:24 --> Controller Class Initialized
DEBUG - 2011-10-07 08:28:24 --> File loaded: application/views/splash/main.php
DEBUG - 2011-10-07 08:28:24 --> Helper loaded: url_helper
DEBUG - 2011-10-07 08:28:24 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-07 08:28:24 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-07 08:28:24 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-07 08:28:24 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-07 08:28:24 --> Final output sent to browser
DEBUG - 2011-10-07 08:28:24 --> Total execution time: 0.2345
DEBUG - 2011-10-07 08:45:53 --> Config Class Initialized
DEBUG - 2011-10-07 08:45:53 --> Hooks Class Initialized
DEBUG - 2011-10-07 08:45:53 --> Utf8 Class Initialized
DEBUG - 2011-10-07 08:45:53 --> UTF-8 Support Enabled
DEBUG - 2011-10-07 08:45:53 --> URI Class Initialized
DEBUG - 2011-10-07 08:45:53 --> Router Class Initialized
ERROR - 2011-10-07 08:45:53 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-10-07 10:32:33 --> Config Class Initialized
DEBUG - 2011-10-07 10:32:33 --> Hooks Class Initialized
DEBUG - 2011-10-07 10:32:33 --> Utf8 Class Initialized
DEBUG - 2011-10-07 10:32:33 --> UTF-8 Support Enabled
DEBUG - 2011-10-07 10:32:33 --> URI Class Initialized
DEBUG - 2011-10-07 10:32:33 --> Router Class Initialized
DEBUG - 2011-10-07 10:32:33 --> Output Class Initialized
DEBUG - 2011-10-07 10:32:33 --> Input Class Initialized
DEBUG - 2011-10-07 10:32:33 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-07 10:32:33 --> Language Class Initialized
DEBUG - 2011-10-07 10:32:33 --> Loader Class Initialized
DEBUG - 2011-10-07 10:32:33 --> Controller Class Initialized
DEBUG - 2011-10-07 10:32:33 --> Model Class Initialized
DEBUG - 2011-10-07 10:32:33 --> Model Class Initialized
DEBUG - 2011-10-07 10:32:33 --> Model Class Initialized
DEBUG - 2011-10-07 10:32:33 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-07 10:32:33 --> Database Driver Class Initialized
DEBUG - 2011-10-07 10:32:34 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-07 10:32:34 --> Helper loaded: url_helper
DEBUG - 2011-10-07 10:32:34 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-07 10:32:34 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-07 10:32:34 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-07 10:32:34 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-07 10:32:34 --> Final output sent to browser
DEBUG - 2011-10-07 10:32:34 --> Total execution time: 1.2099
DEBUG - 2011-10-07 10:32:44 --> Config Class Initialized
DEBUG - 2011-10-07 10:32:44 --> Hooks Class Initialized
DEBUG - 2011-10-07 10:32:44 --> Utf8 Class Initialized
DEBUG - 2011-10-07 10:32:44 --> UTF-8 Support Enabled
DEBUG - 2011-10-07 10:32:44 --> URI Class Initialized
DEBUG - 2011-10-07 10:32:44 --> Router Class Initialized
ERROR - 2011-10-07 10:32:44 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-07 10:32:44 --> Config Class Initialized
DEBUG - 2011-10-07 10:32:44 --> Hooks Class Initialized
DEBUG - 2011-10-07 10:32:44 --> Utf8 Class Initialized
DEBUG - 2011-10-07 10:32:44 --> UTF-8 Support Enabled
DEBUG - 2011-10-07 10:32:44 --> URI Class Initialized
DEBUG - 2011-10-07 10:32:44 --> Router Class Initialized
ERROR - 2011-10-07 10:32:44 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-07 10:33:21 --> Config Class Initialized
DEBUG - 2011-10-07 10:33:21 --> Hooks Class Initialized
DEBUG - 2011-10-07 10:33:21 --> Utf8 Class Initialized
DEBUG - 2011-10-07 10:33:21 --> UTF-8 Support Enabled
DEBUG - 2011-10-07 10:33:21 --> URI Class Initialized
DEBUG - 2011-10-07 10:33:21 --> Router Class Initialized
DEBUG - 2011-10-07 10:33:21 --> Output Class Initialized
DEBUG - 2011-10-07 10:33:21 --> Input Class Initialized
DEBUG - 2011-10-07 10:33:21 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-07 10:33:21 --> Language Class Initialized
DEBUG - 2011-10-07 10:33:21 --> Loader Class Initialized
DEBUG - 2011-10-07 10:33:21 --> Controller Class Initialized
DEBUG - 2011-10-07 10:33:21 --> Model Class Initialized
DEBUG - 2011-10-07 10:33:21 --> Model Class Initialized
DEBUG - 2011-10-07 10:33:21 --> Model Class Initialized
DEBUG - 2011-10-07 10:33:21 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-07 10:33:21 --> Database Driver Class Initialized
DEBUG - 2011-10-07 10:33:21 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-07 10:33:21 --> Helper loaded: url_helper
DEBUG - 2011-10-07 10:33:21 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-07 10:33:21 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-07 10:33:21 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-07 10:33:21 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-07 10:33:21 --> Final output sent to browser
DEBUG - 2011-10-07 10:33:21 --> Total execution time: 0.0631
DEBUG - 2011-10-07 10:33:24 --> Config Class Initialized
DEBUG - 2011-10-07 10:33:24 --> Hooks Class Initialized
DEBUG - 2011-10-07 10:33:24 --> Utf8 Class Initialized
DEBUG - 2011-10-07 10:33:24 --> UTF-8 Support Enabled
DEBUG - 2011-10-07 10:33:24 --> URI Class Initialized
DEBUG - 2011-10-07 10:33:24 --> Router Class Initialized
DEBUG - 2011-10-07 10:33:24 --> Output Class Initialized
DEBUG - 2011-10-07 10:33:24 --> Input Class Initialized
DEBUG - 2011-10-07 10:33:24 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-07 10:33:24 --> Language Class Initialized
DEBUG - 2011-10-07 10:33:24 --> Loader Class Initialized
DEBUG - 2011-10-07 10:33:24 --> Controller Class Initialized
DEBUG - 2011-10-07 10:33:24 --> Model Class Initialized
DEBUG - 2011-10-07 10:33:24 --> Model Class Initialized
DEBUG - 2011-10-07 10:33:24 --> Model Class Initialized
DEBUG - 2011-10-07 10:33:24 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-07 10:33:24 --> Database Driver Class Initialized
DEBUG - 2011-10-07 10:33:24 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-07 10:33:24 --> Helper loaded: url_helper
DEBUG - 2011-10-07 10:33:24 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-07 10:33:24 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-07 10:33:24 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-07 10:33:24 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-07 10:33:24 --> Final output sent to browser
DEBUG - 2011-10-07 10:33:24 --> Total execution time: 0.0514
DEBUG - 2011-10-07 10:33:33 --> Config Class Initialized
DEBUG - 2011-10-07 10:33:33 --> Hooks Class Initialized
DEBUG - 2011-10-07 10:33:33 --> Utf8 Class Initialized
DEBUG - 2011-10-07 10:33:33 --> UTF-8 Support Enabled
DEBUG - 2011-10-07 10:33:33 --> URI Class Initialized
DEBUG - 2011-10-07 10:33:33 --> Router Class Initialized
DEBUG - 2011-10-07 10:33:33 --> Output Class Initialized
DEBUG - 2011-10-07 10:33:33 --> Input Class Initialized
DEBUG - 2011-10-07 10:33:33 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-07 10:33:33 --> Language Class Initialized
DEBUG - 2011-10-07 10:33:33 --> Loader Class Initialized
DEBUG - 2011-10-07 10:33:33 --> Controller Class Initialized
DEBUG - 2011-10-07 10:33:33 --> Model Class Initialized
DEBUG - 2011-10-07 10:33:33 --> Model Class Initialized
DEBUG - 2011-10-07 10:33:33 --> Model Class Initialized
DEBUG - 2011-10-07 10:33:33 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-07 10:33:33 --> Database Driver Class Initialized
DEBUG - 2011-10-07 10:33:33 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-07 10:33:33 --> Helper loaded: url_helper
DEBUG - 2011-10-07 10:33:33 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-07 10:33:33 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-07 10:33:33 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-07 10:33:33 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-07 10:33:33 --> Final output sent to browser
DEBUG - 2011-10-07 10:33:33 --> Total execution time: 0.1972
DEBUG - 2011-10-07 10:33:36 --> Config Class Initialized
DEBUG - 2011-10-07 10:33:36 --> Hooks Class Initialized
DEBUG - 2011-10-07 10:33:36 --> Utf8 Class Initialized
DEBUG - 2011-10-07 10:33:36 --> UTF-8 Support Enabled
DEBUG - 2011-10-07 10:33:36 --> URI Class Initialized
DEBUG - 2011-10-07 10:33:36 --> Router Class Initialized
DEBUG - 2011-10-07 10:33:36 --> Output Class Initialized
DEBUG - 2011-10-07 10:33:36 --> Input Class Initialized
DEBUG - 2011-10-07 10:33:36 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-07 10:33:36 --> Language Class Initialized
DEBUG - 2011-10-07 10:33:36 --> Loader Class Initialized
DEBUG - 2011-10-07 10:33:36 --> Controller Class Initialized
DEBUG - 2011-10-07 10:33:36 --> Model Class Initialized
DEBUG - 2011-10-07 10:33:36 --> Model Class Initialized
DEBUG - 2011-10-07 10:33:36 --> Model Class Initialized
DEBUG - 2011-10-07 10:33:36 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-07 10:33:36 --> Database Driver Class Initialized
DEBUG - 2011-10-07 10:33:36 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-07 10:33:36 --> Helper loaded: url_helper
DEBUG - 2011-10-07 10:33:36 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-07 10:33:36 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-07 10:33:36 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-07 10:33:36 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-07 10:33:36 --> Final output sent to browser
DEBUG - 2011-10-07 10:33:36 --> Total execution time: 0.0492
DEBUG - 2011-10-07 10:33:57 --> Config Class Initialized
DEBUG - 2011-10-07 10:33:57 --> Hooks Class Initialized
DEBUG - 2011-10-07 10:33:57 --> Utf8 Class Initialized
DEBUG - 2011-10-07 10:33:57 --> UTF-8 Support Enabled
DEBUG - 2011-10-07 10:33:57 --> URI Class Initialized
DEBUG - 2011-10-07 10:33:57 --> Router Class Initialized
DEBUG - 2011-10-07 10:33:57 --> Output Class Initialized
DEBUG - 2011-10-07 10:33:57 --> Input Class Initialized
DEBUG - 2011-10-07 10:33:57 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-07 10:33:57 --> Language Class Initialized
DEBUG - 2011-10-07 10:33:57 --> Loader Class Initialized
DEBUG - 2011-10-07 10:33:57 --> Controller Class Initialized
ERROR - 2011-10-07 10:33:57 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-10-07 10:33:57 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-10-07 10:33:57 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-07 10:33:57 --> Model Class Initialized
DEBUG - 2011-10-07 10:33:57 --> Model Class Initialized
DEBUG - 2011-10-07 10:33:57 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-07 10:33:57 --> Database Driver Class Initialized
DEBUG - 2011-10-07 10:33:57 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-07 10:33:57 --> Helper loaded: url_helper
DEBUG - 2011-10-07 10:33:57 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-07 10:33:57 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-07 10:33:57 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-07 10:33:57 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-07 10:33:57 --> Final output sent to browser
DEBUG - 2011-10-07 10:33:57 --> Total execution time: 0.0811
DEBUG - 2011-10-07 10:34:00 --> Config Class Initialized
DEBUG - 2011-10-07 10:34:00 --> Hooks Class Initialized
DEBUG - 2011-10-07 10:34:00 --> Utf8 Class Initialized
DEBUG - 2011-10-07 10:34:00 --> UTF-8 Support Enabled
DEBUG - 2011-10-07 10:34:00 --> URI Class Initialized
DEBUG - 2011-10-07 10:34:00 --> Router Class Initialized
DEBUG - 2011-10-07 10:34:00 --> Output Class Initialized
DEBUG - 2011-10-07 10:34:00 --> Input Class Initialized
DEBUG - 2011-10-07 10:34:00 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-07 10:34:00 --> Language Class Initialized
DEBUG - 2011-10-07 10:34:00 --> Loader Class Initialized
DEBUG - 2011-10-07 10:34:00 --> Controller Class Initialized
DEBUG - 2011-10-07 10:34:00 --> Model Class Initialized
DEBUG - 2011-10-07 10:34:00 --> Model Class Initialized
DEBUG - 2011-10-07 10:34:00 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-07 10:34:00 --> Database Driver Class Initialized
DEBUG - 2011-10-07 10:34:01 --> Final output sent to browser
DEBUG - 2011-10-07 10:34:01 --> Total execution time: 0.9568
DEBUG - 2011-10-07 10:34:20 --> Config Class Initialized
DEBUG - 2011-10-07 10:34:20 --> Hooks Class Initialized
DEBUG - 2011-10-07 10:34:20 --> Utf8 Class Initialized
DEBUG - 2011-10-07 10:34:20 --> UTF-8 Support Enabled
DEBUG - 2011-10-07 10:34:20 --> URI Class Initialized
DEBUG - 2011-10-07 10:34:20 --> Router Class Initialized
DEBUG - 2011-10-07 10:34:20 --> Output Class Initialized
DEBUG - 2011-10-07 10:34:20 --> Input Class Initialized
DEBUG - 2011-10-07 10:34:20 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-07 10:34:20 --> Language Class Initialized
DEBUG - 2011-10-07 10:34:20 --> Loader Class Initialized
DEBUG - 2011-10-07 10:34:20 --> Controller Class Initialized
ERROR - 2011-10-07 10:34:20 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-10-07 10:34:20 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-10-07 10:34:20 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-07 10:34:20 --> Model Class Initialized
DEBUG - 2011-10-07 10:34:20 --> Model Class Initialized
DEBUG - 2011-10-07 10:34:20 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-07 10:34:20 --> Database Driver Class Initialized
DEBUG - 2011-10-07 10:34:20 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-07 10:34:20 --> Helper loaded: url_helper
DEBUG - 2011-10-07 10:34:20 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-07 10:34:20 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-07 10:34:20 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-07 10:34:20 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-07 10:34:20 --> Final output sent to browser
DEBUG - 2011-10-07 10:34:20 --> Total execution time: 0.0370
DEBUG - 2011-10-07 10:34:20 --> Config Class Initialized
DEBUG - 2011-10-07 10:34:20 --> Hooks Class Initialized
DEBUG - 2011-10-07 10:34:20 --> Utf8 Class Initialized
DEBUG - 2011-10-07 10:34:20 --> UTF-8 Support Enabled
DEBUG - 2011-10-07 10:34:20 --> URI Class Initialized
DEBUG - 2011-10-07 10:34:20 --> Router Class Initialized
DEBUG - 2011-10-07 10:34:20 --> Output Class Initialized
DEBUG - 2011-10-07 10:34:20 --> Input Class Initialized
DEBUG - 2011-10-07 10:34:20 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-07 10:34:20 --> Language Class Initialized
DEBUG - 2011-10-07 10:34:20 --> Loader Class Initialized
DEBUG - 2011-10-07 10:34:20 --> Controller Class Initialized
DEBUG - 2011-10-07 10:34:20 --> Model Class Initialized
DEBUG - 2011-10-07 10:34:20 --> Model Class Initialized
DEBUG - 2011-10-07 10:34:20 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-07 10:34:20 --> Database Driver Class Initialized
DEBUG - 2011-10-07 10:34:21 --> Final output sent to browser
DEBUG - 2011-10-07 10:34:21 --> Total execution time: 0.6263
DEBUG - 2011-10-07 10:34:35 --> Config Class Initialized
DEBUG - 2011-10-07 10:34:35 --> Hooks Class Initialized
DEBUG - 2011-10-07 10:34:35 --> Utf8 Class Initialized
DEBUG - 2011-10-07 10:34:35 --> UTF-8 Support Enabled
DEBUG - 2011-10-07 10:34:35 --> URI Class Initialized
DEBUG - 2011-10-07 10:34:35 --> Router Class Initialized
DEBUG - 2011-10-07 10:34:35 --> Output Class Initialized
DEBUG - 2011-10-07 10:34:35 --> Input Class Initialized
DEBUG - 2011-10-07 10:34:35 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-07 10:34:35 --> Language Class Initialized
DEBUG - 2011-10-07 10:34:35 --> Loader Class Initialized
DEBUG - 2011-10-07 10:34:35 --> Controller Class Initialized
ERROR - 2011-10-07 10:34:35 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-10-07 10:34:35 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-10-07 10:34:35 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-07 10:34:35 --> Model Class Initialized
DEBUG - 2011-10-07 10:34:35 --> Model Class Initialized
DEBUG - 2011-10-07 10:34:35 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-07 10:34:35 --> Database Driver Class Initialized
DEBUG - 2011-10-07 10:34:35 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-07 10:34:35 --> Helper loaded: url_helper
DEBUG - 2011-10-07 10:34:35 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-07 10:34:35 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-07 10:34:35 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-07 10:34:35 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-07 10:34:35 --> Final output sent to browser
DEBUG - 2011-10-07 10:34:35 --> Total execution time: 0.0334
DEBUG - 2011-10-07 10:34:35 --> Config Class Initialized
DEBUG - 2011-10-07 10:34:35 --> Hooks Class Initialized
DEBUG - 2011-10-07 10:34:35 --> Utf8 Class Initialized
DEBUG - 2011-10-07 10:34:35 --> UTF-8 Support Enabled
DEBUG - 2011-10-07 10:34:35 --> URI Class Initialized
DEBUG - 2011-10-07 10:34:35 --> Router Class Initialized
DEBUG - 2011-10-07 10:34:35 --> Output Class Initialized
DEBUG - 2011-10-07 10:34:35 --> Input Class Initialized
DEBUG - 2011-10-07 10:34:35 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-07 10:34:35 --> Language Class Initialized
DEBUG - 2011-10-07 10:34:35 --> Loader Class Initialized
DEBUG - 2011-10-07 10:34:35 --> Controller Class Initialized
DEBUG - 2011-10-07 10:34:35 --> Model Class Initialized
DEBUG - 2011-10-07 10:34:35 --> Model Class Initialized
DEBUG - 2011-10-07 10:34:35 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-07 10:34:35 --> Database Driver Class Initialized
DEBUG - 2011-10-07 10:34:36 --> Final output sent to browser
DEBUG - 2011-10-07 10:34:36 --> Total execution time: 0.5830
DEBUG - 2011-10-07 10:34:38 --> Config Class Initialized
DEBUG - 2011-10-07 10:34:38 --> Hooks Class Initialized
DEBUG - 2011-10-07 10:34:38 --> Utf8 Class Initialized
DEBUG - 2011-10-07 10:34:38 --> UTF-8 Support Enabled
DEBUG - 2011-10-07 10:34:38 --> URI Class Initialized
DEBUG - 2011-10-07 10:34:38 --> Router Class Initialized
DEBUG - 2011-10-07 10:34:38 --> Output Class Initialized
DEBUG - 2011-10-07 10:34:38 --> Input Class Initialized
DEBUG - 2011-10-07 10:34:38 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-07 10:34:38 --> Language Class Initialized
DEBUG - 2011-10-07 10:34:38 --> Loader Class Initialized
DEBUG - 2011-10-07 10:34:38 --> Controller Class Initialized
ERROR - 2011-10-07 10:34:38 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-10-07 10:34:38 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-10-07 10:34:38 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-07 10:34:38 --> Model Class Initialized
DEBUG - 2011-10-07 10:34:38 --> Model Class Initialized
DEBUG - 2011-10-07 10:34:38 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-07 10:34:38 --> Database Driver Class Initialized
DEBUG - 2011-10-07 10:34:38 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-07 10:34:38 --> Helper loaded: url_helper
DEBUG - 2011-10-07 10:34:38 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-07 10:34:38 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-07 10:34:38 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-07 10:34:38 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-07 10:34:38 --> Final output sent to browser
DEBUG - 2011-10-07 10:34:38 --> Total execution time: 0.0304
DEBUG - 2011-10-07 11:01:39 --> Config Class Initialized
DEBUG - 2011-10-07 11:01:39 --> Hooks Class Initialized
DEBUG - 2011-10-07 11:01:39 --> Utf8 Class Initialized
DEBUG - 2011-10-07 11:01:39 --> UTF-8 Support Enabled
DEBUG - 2011-10-07 11:01:39 --> URI Class Initialized
DEBUG - 2011-10-07 11:01:39 --> Router Class Initialized
DEBUG - 2011-10-07 11:01:39 --> Output Class Initialized
DEBUG - 2011-10-07 11:01:39 --> Input Class Initialized
DEBUG - 2011-10-07 11:01:39 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-07 11:01:39 --> Language Class Initialized
DEBUG - 2011-10-07 11:01:39 --> Loader Class Initialized
DEBUG - 2011-10-07 11:01:39 --> Controller Class Initialized
ERROR - 2011-10-07 11:01:39 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-10-07 11:01:39 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-10-07 11:01:39 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-07 11:01:39 --> Model Class Initialized
DEBUG - 2011-10-07 11:01:39 --> Model Class Initialized
DEBUG - 2011-10-07 11:01:39 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-07 11:01:39 --> Database Driver Class Initialized
DEBUG - 2011-10-07 11:01:40 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-07 11:01:40 --> Helper loaded: url_helper
DEBUG - 2011-10-07 11:01:40 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-07 11:01:40 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-07 11:01:40 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-07 11:01:40 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-07 11:01:40 --> Final output sent to browser
DEBUG - 2011-10-07 11:01:40 --> Total execution time: 0.7385
DEBUG - 2011-10-07 11:01:41 --> Config Class Initialized
DEBUG - 2011-10-07 11:01:41 --> Hooks Class Initialized
DEBUG - 2011-10-07 11:01:41 --> Utf8 Class Initialized
DEBUG - 2011-10-07 11:01:41 --> UTF-8 Support Enabled
DEBUG - 2011-10-07 11:01:41 --> URI Class Initialized
DEBUG - 2011-10-07 11:01:41 --> Router Class Initialized
DEBUG - 2011-10-07 11:01:41 --> Output Class Initialized
DEBUG - 2011-10-07 11:01:41 --> Input Class Initialized
DEBUG - 2011-10-07 11:01:41 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-07 11:01:41 --> Language Class Initialized
DEBUG - 2011-10-07 11:01:41 --> Loader Class Initialized
DEBUG - 2011-10-07 11:01:41 --> Controller Class Initialized
DEBUG - 2011-10-07 11:01:41 --> Model Class Initialized
DEBUG - 2011-10-07 11:01:41 --> Model Class Initialized
DEBUG - 2011-10-07 11:01:41 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-07 11:01:41 --> Database Driver Class Initialized
DEBUG - 2011-10-07 11:01:42 --> Final output sent to browser
DEBUG - 2011-10-07 11:01:42 --> Total execution time: 0.9120
DEBUG - 2011-10-07 11:01:44 --> Config Class Initialized
DEBUG - 2011-10-07 11:01:44 --> Hooks Class Initialized
DEBUG - 2011-10-07 11:01:44 --> Utf8 Class Initialized
DEBUG - 2011-10-07 11:01:44 --> UTF-8 Support Enabled
DEBUG - 2011-10-07 11:01:44 --> URI Class Initialized
DEBUG - 2011-10-07 11:01:44 --> Router Class Initialized
ERROR - 2011-10-07 11:01:44 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-07 11:48:50 --> Config Class Initialized
DEBUG - 2011-10-07 11:48:50 --> Hooks Class Initialized
DEBUG - 2011-10-07 11:48:50 --> Utf8 Class Initialized
DEBUG - 2011-10-07 11:48:50 --> UTF-8 Support Enabled
DEBUG - 2011-10-07 11:48:50 --> URI Class Initialized
DEBUG - 2011-10-07 11:48:50 --> Router Class Initialized
DEBUG - 2011-10-07 11:48:50 --> Output Class Initialized
DEBUG - 2011-10-07 11:48:50 --> Input Class Initialized
DEBUG - 2011-10-07 11:48:50 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-07 11:48:50 --> Language Class Initialized
DEBUG - 2011-10-07 11:48:50 --> Loader Class Initialized
DEBUG - 2011-10-07 11:48:50 --> Controller Class Initialized
ERROR - 2011-10-07 11:48:50 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-10-07 11:48:50 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-10-07 11:48:50 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-07 11:48:50 --> Model Class Initialized
DEBUG - 2011-10-07 11:48:50 --> Model Class Initialized
DEBUG - 2011-10-07 11:48:50 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-07 11:48:50 --> Database Driver Class Initialized
DEBUG - 2011-10-07 11:48:50 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-07 11:48:50 --> Helper loaded: url_helper
DEBUG - 2011-10-07 11:48:50 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-07 11:48:50 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-07 11:48:50 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-07 11:48:50 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-07 11:48:50 --> Final output sent to browser
DEBUG - 2011-10-07 11:48:50 --> Total execution time: 0.3046
DEBUG - 2011-10-07 11:48:52 --> Config Class Initialized
DEBUG - 2011-10-07 11:48:52 --> Hooks Class Initialized
DEBUG - 2011-10-07 11:48:52 --> Utf8 Class Initialized
DEBUG - 2011-10-07 11:48:52 --> UTF-8 Support Enabled
DEBUG - 2011-10-07 11:48:52 --> URI Class Initialized
DEBUG - 2011-10-07 11:48:52 --> Router Class Initialized
DEBUG - 2011-10-07 11:48:52 --> Output Class Initialized
DEBUG - 2011-10-07 11:48:52 --> Input Class Initialized
DEBUG - 2011-10-07 11:48:52 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-07 11:48:52 --> Language Class Initialized
DEBUG - 2011-10-07 11:48:52 --> Loader Class Initialized
DEBUG - 2011-10-07 11:48:52 --> Controller Class Initialized
DEBUG - 2011-10-07 11:48:52 --> Model Class Initialized
DEBUG - 2011-10-07 11:48:52 --> Model Class Initialized
DEBUG - 2011-10-07 11:48:52 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-07 11:48:52 --> Database Driver Class Initialized
DEBUG - 2011-10-07 11:48:53 --> Final output sent to browser
DEBUG - 2011-10-07 11:48:53 --> Total execution time: 0.7803
DEBUG - 2011-10-07 11:48:56 --> Config Class Initialized
DEBUG - 2011-10-07 11:48:56 --> Hooks Class Initialized
DEBUG - 2011-10-07 11:48:56 --> Utf8 Class Initialized
DEBUG - 2011-10-07 11:48:56 --> UTF-8 Support Enabled
DEBUG - 2011-10-07 11:48:56 --> URI Class Initialized
DEBUG - 2011-10-07 11:48:56 --> Router Class Initialized
ERROR - 2011-10-07 11:48:56 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-07 11:49:48 --> Config Class Initialized
DEBUG - 2011-10-07 11:49:48 --> Hooks Class Initialized
DEBUG - 2011-10-07 11:49:48 --> Utf8 Class Initialized
DEBUG - 2011-10-07 11:49:48 --> UTF-8 Support Enabled
DEBUG - 2011-10-07 11:49:48 --> URI Class Initialized
DEBUG - 2011-10-07 11:49:48 --> Router Class Initialized
DEBUG - 2011-10-07 11:49:48 --> Output Class Initialized
DEBUG - 2011-10-07 11:49:48 --> Input Class Initialized
DEBUG - 2011-10-07 11:49:48 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-07 11:49:48 --> Language Class Initialized
DEBUG - 2011-10-07 11:49:48 --> Loader Class Initialized
DEBUG - 2011-10-07 11:49:48 --> Controller Class Initialized
ERROR - 2011-10-07 11:49:48 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-10-07 11:49:48 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-10-07 11:49:48 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-07 11:49:48 --> Model Class Initialized
DEBUG - 2011-10-07 11:49:48 --> Model Class Initialized
DEBUG - 2011-10-07 11:49:48 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-07 11:49:48 --> Database Driver Class Initialized
DEBUG - 2011-10-07 11:49:48 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-07 11:49:48 --> Helper loaded: url_helper
DEBUG - 2011-10-07 11:49:48 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-07 11:49:48 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-07 11:49:48 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-07 11:49:48 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-07 11:49:48 --> Final output sent to browser
DEBUG - 2011-10-07 11:49:48 --> Total execution time: 0.2059
DEBUG - 2011-10-07 11:49:49 --> Config Class Initialized
DEBUG - 2011-10-07 11:49:49 --> Hooks Class Initialized
DEBUG - 2011-10-07 11:49:49 --> Utf8 Class Initialized
DEBUG - 2011-10-07 11:49:49 --> UTF-8 Support Enabled
DEBUG - 2011-10-07 11:49:49 --> URI Class Initialized
DEBUG - 2011-10-07 11:49:49 --> Router Class Initialized
DEBUG - 2011-10-07 11:49:49 --> Output Class Initialized
DEBUG - 2011-10-07 11:49:49 --> Input Class Initialized
DEBUG - 2011-10-07 11:49:49 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-07 11:49:49 --> Language Class Initialized
DEBUG - 2011-10-07 11:49:49 --> Loader Class Initialized
DEBUG - 2011-10-07 11:49:49 --> Controller Class Initialized
DEBUG - 2011-10-07 11:49:49 --> Model Class Initialized
DEBUG - 2011-10-07 11:49:49 --> Model Class Initialized
DEBUG - 2011-10-07 11:49:49 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-07 11:49:49 --> Database Driver Class Initialized
DEBUG - 2011-10-07 11:49:50 --> Final output sent to browser
DEBUG - 2011-10-07 11:49:50 --> Total execution time: 0.7198
DEBUG - 2011-10-07 11:49:52 --> Config Class Initialized
DEBUG - 2011-10-07 11:49:52 --> Hooks Class Initialized
DEBUG - 2011-10-07 11:49:52 --> Utf8 Class Initialized
DEBUG - 2011-10-07 11:49:52 --> UTF-8 Support Enabled
DEBUG - 2011-10-07 11:49:52 --> URI Class Initialized
DEBUG - 2011-10-07 11:49:52 --> Router Class Initialized
ERROR - 2011-10-07 11:49:52 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-07 11:49:59 --> Config Class Initialized
DEBUG - 2011-10-07 11:49:59 --> Hooks Class Initialized
DEBUG - 2011-10-07 11:49:59 --> Utf8 Class Initialized
DEBUG - 2011-10-07 11:49:59 --> UTF-8 Support Enabled
DEBUG - 2011-10-07 11:49:59 --> URI Class Initialized
DEBUG - 2011-10-07 11:49:59 --> Router Class Initialized
DEBUG - 2011-10-07 11:49:59 --> Output Class Initialized
DEBUG - 2011-10-07 11:49:59 --> Input Class Initialized
DEBUG - 2011-10-07 11:49:59 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-07 11:49:59 --> Language Class Initialized
DEBUG - 2011-10-07 11:49:59 --> Loader Class Initialized
DEBUG - 2011-10-07 11:49:59 --> Controller Class Initialized
ERROR - 2011-10-07 11:49:59 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-10-07 11:49:59 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-10-07 11:49:59 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-07 11:49:59 --> Model Class Initialized
DEBUG - 2011-10-07 11:49:59 --> Model Class Initialized
DEBUG - 2011-10-07 11:49:59 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-07 11:49:59 --> Database Driver Class Initialized
DEBUG - 2011-10-07 11:49:59 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-07 11:49:59 --> Helper loaded: url_helper
DEBUG - 2011-10-07 11:49:59 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-07 11:49:59 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-07 11:49:59 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-07 11:49:59 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-07 11:49:59 --> Final output sent to browser
DEBUG - 2011-10-07 11:49:59 --> Total execution time: 0.0308
DEBUG - 2011-10-07 11:50:00 --> Config Class Initialized
DEBUG - 2011-10-07 11:50:00 --> Hooks Class Initialized
DEBUG - 2011-10-07 11:50:00 --> Utf8 Class Initialized
DEBUG - 2011-10-07 11:50:00 --> UTF-8 Support Enabled
DEBUG - 2011-10-07 11:50:00 --> URI Class Initialized
DEBUG - 2011-10-07 11:50:00 --> Router Class Initialized
DEBUG - 2011-10-07 11:50:00 --> Output Class Initialized
DEBUG - 2011-10-07 11:50:00 --> Input Class Initialized
DEBUG - 2011-10-07 11:50:00 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-07 11:50:00 --> Language Class Initialized
DEBUG - 2011-10-07 11:50:00 --> Loader Class Initialized
DEBUG - 2011-10-07 11:50:00 --> Controller Class Initialized
DEBUG - 2011-10-07 11:50:00 --> Model Class Initialized
DEBUG - 2011-10-07 11:50:00 --> Model Class Initialized
DEBUG - 2011-10-07 11:50:00 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-07 11:50:00 --> Database Driver Class Initialized
DEBUG - 2011-10-07 11:50:01 --> Final output sent to browser
DEBUG - 2011-10-07 11:50:01 --> Total execution time: 0.9188
DEBUG - 2011-10-07 11:50:02 --> Config Class Initialized
DEBUG - 2011-10-07 11:50:02 --> Hooks Class Initialized
DEBUG - 2011-10-07 11:50:02 --> Utf8 Class Initialized
DEBUG - 2011-10-07 11:50:02 --> UTF-8 Support Enabled
DEBUG - 2011-10-07 11:50:02 --> URI Class Initialized
DEBUG - 2011-10-07 11:50:02 --> Router Class Initialized
ERROR - 2011-10-07 11:50:02 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-07 11:50:19 --> Config Class Initialized
DEBUG - 2011-10-07 11:50:19 --> Hooks Class Initialized
DEBUG - 2011-10-07 11:50:19 --> Utf8 Class Initialized
DEBUG - 2011-10-07 11:50:19 --> UTF-8 Support Enabled
DEBUG - 2011-10-07 11:50:19 --> URI Class Initialized
DEBUG - 2011-10-07 11:50:19 --> Router Class Initialized
DEBUG - 2011-10-07 11:50:19 --> Output Class Initialized
DEBUG - 2011-10-07 11:50:19 --> Input Class Initialized
DEBUG - 2011-10-07 11:50:19 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-07 11:50:19 --> Language Class Initialized
DEBUG - 2011-10-07 11:50:19 --> Loader Class Initialized
DEBUG - 2011-10-07 11:50:19 --> Controller Class Initialized
ERROR - 2011-10-07 11:50:19 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-10-07 11:50:19 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-10-07 11:50:19 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-07 11:50:19 --> Model Class Initialized
DEBUG - 2011-10-07 11:50:19 --> Model Class Initialized
DEBUG - 2011-10-07 11:50:19 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-07 11:50:19 --> Database Driver Class Initialized
DEBUG - 2011-10-07 11:50:19 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-07 11:50:19 --> Helper loaded: url_helper
DEBUG - 2011-10-07 11:50:19 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-07 11:50:19 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-07 11:50:19 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-07 11:50:19 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-07 11:50:19 --> Final output sent to browser
DEBUG - 2011-10-07 11:50:19 --> Total execution time: 0.0388
DEBUG - 2011-10-07 11:50:20 --> Config Class Initialized
DEBUG - 2011-10-07 11:50:20 --> Hooks Class Initialized
DEBUG - 2011-10-07 11:50:20 --> Utf8 Class Initialized
DEBUG - 2011-10-07 11:50:20 --> UTF-8 Support Enabled
DEBUG - 2011-10-07 11:50:20 --> URI Class Initialized
DEBUG - 2011-10-07 11:50:20 --> Router Class Initialized
DEBUG - 2011-10-07 11:50:20 --> Output Class Initialized
DEBUG - 2011-10-07 11:50:20 --> Input Class Initialized
DEBUG - 2011-10-07 11:50:20 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-07 11:50:20 --> Language Class Initialized
DEBUG - 2011-10-07 11:50:20 --> Loader Class Initialized
DEBUG - 2011-10-07 11:50:20 --> Controller Class Initialized
DEBUG - 2011-10-07 11:50:20 --> Model Class Initialized
DEBUG - 2011-10-07 11:50:20 --> Model Class Initialized
DEBUG - 2011-10-07 11:50:20 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-07 11:50:20 --> Database Driver Class Initialized
DEBUG - 2011-10-07 11:50:21 --> Final output sent to browser
DEBUG - 2011-10-07 11:50:21 --> Total execution time: 0.6200
DEBUG - 2011-10-07 11:50:23 --> Config Class Initialized
DEBUG - 2011-10-07 11:50:23 --> Hooks Class Initialized
DEBUG - 2011-10-07 11:50:23 --> Utf8 Class Initialized
DEBUG - 2011-10-07 11:50:23 --> UTF-8 Support Enabled
DEBUG - 2011-10-07 11:50:23 --> URI Class Initialized
DEBUG - 2011-10-07 11:50:23 --> Router Class Initialized
ERROR - 2011-10-07 11:50:23 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-07 11:50:49 --> Config Class Initialized
DEBUG - 2011-10-07 11:50:49 --> Hooks Class Initialized
DEBUG - 2011-10-07 11:50:49 --> Utf8 Class Initialized
DEBUG - 2011-10-07 11:50:49 --> UTF-8 Support Enabled
DEBUG - 2011-10-07 11:50:49 --> URI Class Initialized
DEBUG - 2011-10-07 11:50:49 --> Router Class Initialized
DEBUG - 2011-10-07 11:50:49 --> Output Class Initialized
DEBUG - 2011-10-07 11:50:49 --> Input Class Initialized
DEBUG - 2011-10-07 11:50:49 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-07 11:50:49 --> Language Class Initialized
DEBUG - 2011-10-07 11:50:49 --> Loader Class Initialized
DEBUG - 2011-10-07 11:50:49 --> Controller Class Initialized
ERROR - 2011-10-07 11:50:49 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-10-07 11:50:49 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-10-07 11:50:49 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-07 11:50:49 --> Model Class Initialized
DEBUG - 2011-10-07 11:50:49 --> Model Class Initialized
DEBUG - 2011-10-07 11:50:49 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-07 11:50:49 --> Database Driver Class Initialized
DEBUG - 2011-10-07 11:50:49 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-07 11:50:49 --> Helper loaded: url_helper
DEBUG - 2011-10-07 11:50:49 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-07 11:50:49 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-07 11:50:49 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-07 11:50:49 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-07 11:50:49 --> Final output sent to browser
DEBUG - 2011-10-07 11:50:49 --> Total execution time: 0.0396
DEBUG - 2011-10-07 11:50:50 --> Config Class Initialized
DEBUG - 2011-10-07 11:50:50 --> Hooks Class Initialized
DEBUG - 2011-10-07 11:50:50 --> Utf8 Class Initialized
DEBUG - 2011-10-07 11:50:50 --> UTF-8 Support Enabled
DEBUG - 2011-10-07 11:50:50 --> URI Class Initialized
DEBUG - 2011-10-07 11:50:50 --> Router Class Initialized
DEBUG - 2011-10-07 11:50:50 --> Output Class Initialized
DEBUG - 2011-10-07 11:50:50 --> Input Class Initialized
DEBUG - 2011-10-07 11:50:50 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-07 11:50:50 --> Language Class Initialized
DEBUG - 2011-10-07 11:50:50 --> Loader Class Initialized
DEBUG - 2011-10-07 11:50:50 --> Controller Class Initialized
ERROR - 2011-10-07 11:50:50 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-10-07 11:50:50 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-10-07 11:50:50 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-07 11:50:50 --> Model Class Initialized
DEBUG - 2011-10-07 11:50:50 --> Model Class Initialized
DEBUG - 2011-10-07 11:50:50 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-07 11:50:50 --> Database Driver Class Initialized
DEBUG - 2011-10-07 11:50:50 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-07 11:50:50 --> Helper loaded: url_helper
DEBUG - 2011-10-07 11:50:50 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-07 11:50:50 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-07 11:50:50 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-07 11:50:50 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-07 11:50:50 --> Final output sent to browser
DEBUG - 2011-10-07 11:50:50 --> Total execution time: 0.0447
DEBUG - 2011-10-07 11:50:50 --> Config Class Initialized
DEBUG - 2011-10-07 11:50:50 --> Hooks Class Initialized
DEBUG - 2011-10-07 11:50:50 --> Utf8 Class Initialized
DEBUG - 2011-10-07 11:50:50 --> UTF-8 Support Enabled
DEBUG - 2011-10-07 11:50:50 --> URI Class Initialized
DEBUG - 2011-10-07 11:50:50 --> Router Class Initialized
DEBUG - 2011-10-07 11:50:50 --> Output Class Initialized
DEBUG - 2011-10-07 11:50:50 --> Input Class Initialized
DEBUG - 2011-10-07 11:50:50 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-07 11:50:50 --> Language Class Initialized
DEBUG - 2011-10-07 11:50:50 --> Loader Class Initialized
DEBUG - 2011-10-07 11:50:50 --> Controller Class Initialized
DEBUG - 2011-10-07 11:50:50 --> Model Class Initialized
DEBUG - 2011-10-07 11:50:50 --> Model Class Initialized
DEBUG - 2011-10-07 11:50:50 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-07 11:50:50 --> Database Driver Class Initialized
DEBUG - 2011-10-07 11:50:50 --> Final output sent to browser
DEBUG - 2011-10-07 11:50:50 --> Total execution time: 0.5163
DEBUG - 2011-10-07 11:50:54 --> Config Class Initialized
DEBUG - 2011-10-07 11:50:54 --> Hooks Class Initialized
DEBUG - 2011-10-07 11:50:54 --> Utf8 Class Initialized
DEBUG - 2011-10-07 11:50:54 --> UTF-8 Support Enabled
DEBUG - 2011-10-07 11:50:54 --> URI Class Initialized
DEBUG - 2011-10-07 11:50:54 --> Router Class Initialized
ERROR - 2011-10-07 11:50:54 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-07 11:51:05 --> Config Class Initialized
DEBUG - 2011-10-07 11:51:05 --> Hooks Class Initialized
DEBUG - 2011-10-07 11:51:05 --> Utf8 Class Initialized
DEBUG - 2011-10-07 11:51:05 --> UTF-8 Support Enabled
DEBUG - 2011-10-07 11:51:05 --> URI Class Initialized
DEBUG - 2011-10-07 11:51:05 --> Router Class Initialized
DEBUG - 2011-10-07 11:51:05 --> Output Class Initialized
DEBUG - 2011-10-07 11:51:05 --> Input Class Initialized
DEBUG - 2011-10-07 11:51:05 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-07 11:51:05 --> Language Class Initialized
DEBUG - 2011-10-07 11:51:05 --> Loader Class Initialized
DEBUG - 2011-10-07 11:51:05 --> Controller Class Initialized
ERROR - 2011-10-07 11:51:05 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-10-07 11:51:05 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-10-07 11:51:05 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-07 11:51:05 --> Model Class Initialized
DEBUG - 2011-10-07 11:51:05 --> Model Class Initialized
DEBUG - 2011-10-07 11:51:05 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-07 11:51:05 --> Database Driver Class Initialized
DEBUG - 2011-10-07 11:51:05 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-07 11:51:05 --> Helper loaded: url_helper
DEBUG - 2011-10-07 11:51:05 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-07 11:51:05 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-07 11:51:05 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-07 11:51:05 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-07 11:51:05 --> Final output sent to browser
DEBUG - 2011-10-07 11:51:05 --> Total execution time: 0.0335
DEBUG - 2011-10-07 11:51:07 --> Config Class Initialized
DEBUG - 2011-10-07 11:51:07 --> Hooks Class Initialized
DEBUG - 2011-10-07 11:51:07 --> Utf8 Class Initialized
DEBUG - 2011-10-07 11:51:07 --> UTF-8 Support Enabled
DEBUG - 2011-10-07 11:51:07 --> URI Class Initialized
DEBUG - 2011-10-07 11:51:07 --> Router Class Initialized
DEBUG - 2011-10-07 11:51:07 --> Output Class Initialized
DEBUG - 2011-10-07 11:51:07 --> Input Class Initialized
DEBUG - 2011-10-07 11:51:07 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-07 11:51:07 --> Language Class Initialized
DEBUG - 2011-10-07 11:51:07 --> Loader Class Initialized
DEBUG - 2011-10-07 11:51:07 --> Controller Class Initialized
DEBUG - 2011-10-07 11:51:07 --> Model Class Initialized
DEBUG - 2011-10-07 11:51:07 --> Model Class Initialized
DEBUG - 2011-10-07 11:51:07 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-07 11:51:07 --> Database Driver Class Initialized
DEBUG - 2011-10-07 11:51:07 --> Final output sent to browser
DEBUG - 2011-10-07 11:51:07 --> Total execution time: 0.5528
DEBUG - 2011-10-07 11:51:09 --> Config Class Initialized
DEBUG - 2011-10-07 11:51:09 --> Hooks Class Initialized
DEBUG - 2011-10-07 11:51:09 --> Utf8 Class Initialized
DEBUG - 2011-10-07 11:51:09 --> UTF-8 Support Enabled
DEBUG - 2011-10-07 11:51:09 --> URI Class Initialized
DEBUG - 2011-10-07 11:51:09 --> Router Class Initialized
ERROR - 2011-10-07 11:51:09 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-07 11:51:26 --> Config Class Initialized
DEBUG - 2011-10-07 11:51:26 --> Hooks Class Initialized
DEBUG - 2011-10-07 11:51:26 --> Utf8 Class Initialized
DEBUG - 2011-10-07 11:51:26 --> UTF-8 Support Enabled
DEBUG - 2011-10-07 11:51:26 --> URI Class Initialized
DEBUG - 2011-10-07 11:51:26 --> Router Class Initialized
DEBUG - 2011-10-07 11:51:26 --> Output Class Initialized
DEBUG - 2011-10-07 11:51:26 --> Input Class Initialized
DEBUG - 2011-10-07 11:51:26 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-07 11:51:26 --> Language Class Initialized
DEBUG - 2011-10-07 11:51:26 --> Loader Class Initialized
DEBUG - 2011-10-07 11:51:26 --> Controller Class Initialized
ERROR - 2011-10-07 11:51:26 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-10-07 11:51:26 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-10-07 11:51:26 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-07 11:51:26 --> Model Class Initialized
DEBUG - 2011-10-07 11:51:26 --> Model Class Initialized
DEBUG - 2011-10-07 11:51:26 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-07 11:51:26 --> Database Driver Class Initialized
DEBUG - 2011-10-07 11:51:26 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-07 11:51:26 --> Helper loaded: url_helper
DEBUG - 2011-10-07 11:51:26 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-07 11:51:26 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-07 11:51:26 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-07 11:51:26 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-07 11:51:26 --> Final output sent to browser
DEBUG - 2011-10-07 11:51:26 --> Total execution time: 0.0426
DEBUG - 2011-10-07 11:51:27 --> Config Class Initialized
DEBUG - 2011-10-07 11:51:27 --> Hooks Class Initialized
DEBUG - 2011-10-07 11:51:27 --> Utf8 Class Initialized
DEBUG - 2011-10-07 11:51:27 --> UTF-8 Support Enabled
DEBUG - 2011-10-07 11:51:27 --> URI Class Initialized
DEBUG - 2011-10-07 11:51:27 --> Router Class Initialized
DEBUG - 2011-10-07 11:51:27 --> Output Class Initialized
DEBUG - 2011-10-07 11:51:27 --> Input Class Initialized
DEBUG - 2011-10-07 11:51:27 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-07 11:51:27 --> Language Class Initialized
DEBUG - 2011-10-07 11:51:27 --> Loader Class Initialized
DEBUG - 2011-10-07 11:51:27 --> Controller Class Initialized
DEBUG - 2011-10-07 11:51:27 --> Model Class Initialized
DEBUG - 2011-10-07 11:51:27 --> Model Class Initialized
DEBUG - 2011-10-07 11:51:27 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-07 11:51:27 --> Database Driver Class Initialized
DEBUG - 2011-10-07 11:51:27 --> Final output sent to browser
DEBUG - 2011-10-07 11:51:27 --> Total execution time: 0.6016
DEBUG - 2011-10-07 11:51:29 --> Config Class Initialized
DEBUG - 2011-10-07 11:51:29 --> Hooks Class Initialized
DEBUG - 2011-10-07 11:51:29 --> Utf8 Class Initialized
DEBUG - 2011-10-07 11:51:29 --> UTF-8 Support Enabled
DEBUG - 2011-10-07 11:51:29 --> URI Class Initialized
DEBUG - 2011-10-07 11:51:29 --> Router Class Initialized
ERROR - 2011-10-07 11:51:29 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-07 11:51:35 --> Config Class Initialized
DEBUG - 2011-10-07 11:51:35 --> Hooks Class Initialized
DEBUG - 2011-10-07 11:51:35 --> Utf8 Class Initialized
DEBUG - 2011-10-07 11:51:35 --> UTF-8 Support Enabled
DEBUG - 2011-10-07 11:51:35 --> URI Class Initialized
DEBUG - 2011-10-07 11:51:35 --> Router Class Initialized
DEBUG - 2011-10-07 11:51:35 --> Output Class Initialized
DEBUG - 2011-10-07 11:51:35 --> Input Class Initialized
DEBUG - 2011-10-07 11:51:35 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-07 11:51:35 --> Language Class Initialized
DEBUG - 2011-10-07 11:51:35 --> Loader Class Initialized
DEBUG - 2011-10-07 11:51:35 --> Controller Class Initialized
ERROR - 2011-10-07 11:51:35 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-10-07 11:51:35 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-10-07 11:51:35 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-07 11:51:35 --> Model Class Initialized
DEBUG - 2011-10-07 11:51:35 --> Model Class Initialized
DEBUG - 2011-10-07 11:51:35 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-07 11:51:35 --> Database Driver Class Initialized
DEBUG - 2011-10-07 11:51:35 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-07 11:51:35 --> Helper loaded: url_helper
DEBUG - 2011-10-07 11:51:35 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-07 11:51:35 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-07 11:51:35 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-07 11:51:35 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-07 11:51:35 --> Final output sent to browser
DEBUG - 2011-10-07 11:51:35 --> Total execution time: 0.0322
DEBUG - 2011-10-07 11:51:36 --> Config Class Initialized
DEBUG - 2011-10-07 11:51:36 --> Hooks Class Initialized
DEBUG - 2011-10-07 11:51:36 --> Utf8 Class Initialized
DEBUG - 2011-10-07 11:51:36 --> UTF-8 Support Enabled
DEBUG - 2011-10-07 11:51:36 --> URI Class Initialized
DEBUG - 2011-10-07 11:51:36 --> Router Class Initialized
DEBUG - 2011-10-07 11:51:36 --> Output Class Initialized
DEBUG - 2011-10-07 11:51:36 --> Input Class Initialized
DEBUG - 2011-10-07 11:51:36 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-07 11:51:36 --> Language Class Initialized
DEBUG - 2011-10-07 11:51:36 --> Loader Class Initialized
DEBUG - 2011-10-07 11:51:36 --> Controller Class Initialized
DEBUG - 2011-10-07 11:51:36 --> Model Class Initialized
DEBUG - 2011-10-07 11:51:36 --> Model Class Initialized
DEBUG - 2011-10-07 11:51:36 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-07 11:51:36 --> Database Driver Class Initialized
DEBUG - 2011-10-07 11:51:37 --> Final output sent to browser
DEBUG - 2011-10-07 11:51:37 --> Total execution time: 0.7948
DEBUG - 2011-10-07 11:51:39 --> Config Class Initialized
DEBUG - 2011-10-07 11:51:39 --> Hooks Class Initialized
DEBUG - 2011-10-07 11:51:39 --> Utf8 Class Initialized
DEBUG - 2011-10-07 11:51:39 --> UTF-8 Support Enabled
DEBUG - 2011-10-07 11:51:39 --> URI Class Initialized
DEBUG - 2011-10-07 11:51:39 --> Router Class Initialized
ERROR - 2011-10-07 11:51:39 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-07 11:51:44 --> Config Class Initialized
DEBUG - 2011-10-07 11:51:44 --> Hooks Class Initialized
DEBUG - 2011-10-07 11:51:44 --> Utf8 Class Initialized
DEBUG - 2011-10-07 11:51:44 --> UTF-8 Support Enabled
DEBUG - 2011-10-07 11:51:44 --> URI Class Initialized
DEBUG - 2011-10-07 11:51:44 --> Router Class Initialized
DEBUG - 2011-10-07 11:51:44 --> Output Class Initialized
DEBUG - 2011-10-07 11:51:44 --> Input Class Initialized
DEBUG - 2011-10-07 11:51:44 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-07 11:51:44 --> Language Class Initialized
DEBUG - 2011-10-07 11:51:44 --> Loader Class Initialized
DEBUG - 2011-10-07 11:51:44 --> Controller Class Initialized
ERROR - 2011-10-07 11:51:44 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-10-07 11:51:44 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-10-07 11:51:44 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-07 11:51:44 --> Model Class Initialized
DEBUG - 2011-10-07 11:51:44 --> Model Class Initialized
DEBUG - 2011-10-07 11:51:44 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-07 11:51:44 --> Database Driver Class Initialized
DEBUG - 2011-10-07 11:51:44 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-07 11:51:44 --> Helper loaded: url_helper
DEBUG - 2011-10-07 11:51:44 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-07 11:51:44 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-07 11:51:44 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-07 11:51:44 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-07 11:51:44 --> Final output sent to browser
DEBUG - 2011-10-07 11:51:44 --> Total execution time: 0.1098
DEBUG - 2011-10-07 11:51:44 --> Config Class Initialized
DEBUG - 2011-10-07 11:51:44 --> Hooks Class Initialized
DEBUG - 2011-10-07 11:51:44 --> Utf8 Class Initialized
DEBUG - 2011-10-07 11:51:44 --> UTF-8 Support Enabled
DEBUG - 2011-10-07 11:51:44 --> URI Class Initialized
DEBUG - 2011-10-07 11:51:44 --> Router Class Initialized
DEBUG - 2011-10-07 11:51:44 --> Output Class Initialized
DEBUG - 2011-10-07 11:51:44 --> Input Class Initialized
DEBUG - 2011-10-07 11:51:44 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-07 11:51:44 --> Language Class Initialized
DEBUG - 2011-10-07 11:51:44 --> Loader Class Initialized
DEBUG - 2011-10-07 11:51:44 --> Controller Class Initialized
DEBUG - 2011-10-07 11:51:44 --> Model Class Initialized
DEBUG - 2011-10-07 11:51:44 --> Model Class Initialized
DEBUG - 2011-10-07 11:51:44 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-07 11:51:44 --> Database Driver Class Initialized
DEBUG - 2011-10-07 11:51:45 --> Final output sent to browser
DEBUG - 2011-10-07 11:51:45 --> Total execution time: 0.7554
DEBUG - 2011-10-07 11:51:47 --> Config Class Initialized
DEBUG - 2011-10-07 11:51:47 --> Hooks Class Initialized
DEBUG - 2011-10-07 11:51:47 --> Utf8 Class Initialized
DEBUG - 2011-10-07 11:51:47 --> UTF-8 Support Enabled
DEBUG - 2011-10-07 11:51:47 --> URI Class Initialized
DEBUG - 2011-10-07 11:51:47 --> Router Class Initialized
ERROR - 2011-10-07 11:51:47 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-07 11:52:08 --> Config Class Initialized
DEBUG - 2011-10-07 11:52:08 --> Hooks Class Initialized
DEBUG - 2011-10-07 11:52:08 --> Utf8 Class Initialized
DEBUG - 2011-10-07 11:52:08 --> UTF-8 Support Enabled
DEBUG - 2011-10-07 11:52:08 --> URI Class Initialized
DEBUG - 2011-10-07 11:52:08 --> Router Class Initialized
DEBUG - 2011-10-07 11:52:08 --> Output Class Initialized
DEBUG - 2011-10-07 11:52:08 --> Input Class Initialized
DEBUG - 2011-10-07 11:52:08 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-07 11:52:08 --> Language Class Initialized
DEBUG - 2011-10-07 11:52:08 --> Loader Class Initialized
DEBUG - 2011-10-07 11:52:08 --> Controller Class Initialized
ERROR - 2011-10-07 11:52:08 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-10-07 11:52:08 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-10-07 11:52:08 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-07 11:52:08 --> Model Class Initialized
DEBUG - 2011-10-07 11:52:08 --> Model Class Initialized
DEBUG - 2011-10-07 11:52:08 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-07 11:52:08 --> Database Driver Class Initialized
DEBUG - 2011-10-07 11:52:08 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-07 11:52:08 --> Helper loaded: url_helper
DEBUG - 2011-10-07 11:52:08 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-07 11:52:08 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-07 11:52:08 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-07 11:52:08 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-07 11:52:08 --> Final output sent to browser
DEBUG - 2011-10-07 11:52:08 --> Total execution time: 0.0403
DEBUG - 2011-10-07 11:52:21 --> Config Class Initialized
DEBUG - 2011-10-07 11:52:21 --> Hooks Class Initialized
DEBUG - 2011-10-07 11:52:21 --> Utf8 Class Initialized
DEBUG - 2011-10-07 11:52:21 --> UTF-8 Support Enabled
DEBUG - 2011-10-07 11:52:21 --> URI Class Initialized
DEBUG - 2011-10-07 11:52:21 --> Router Class Initialized
DEBUG - 2011-10-07 11:52:21 --> Output Class Initialized
DEBUG - 2011-10-07 11:52:21 --> Input Class Initialized
DEBUG - 2011-10-07 11:52:21 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-07 11:52:21 --> Language Class Initialized
DEBUG - 2011-10-07 11:52:21 --> Loader Class Initialized
DEBUG - 2011-10-07 11:52:21 --> Controller Class Initialized
ERROR - 2011-10-07 11:52:21 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-10-07 11:52:21 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-10-07 11:52:21 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-07 11:52:21 --> Model Class Initialized
DEBUG - 2011-10-07 11:52:21 --> Model Class Initialized
DEBUG - 2011-10-07 11:52:21 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-07 11:52:21 --> Database Driver Class Initialized
DEBUG - 2011-10-07 11:52:22 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-07 11:52:22 --> Helper loaded: url_helper
DEBUG - 2011-10-07 11:52:22 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-07 11:52:22 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-07 11:52:22 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-07 11:52:22 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-07 11:52:22 --> Final output sent to browser
DEBUG - 2011-10-07 11:52:22 --> Total execution time: 0.0340
DEBUG - 2011-10-07 11:52:31 --> Config Class Initialized
DEBUG - 2011-10-07 11:52:31 --> Hooks Class Initialized
DEBUG - 2011-10-07 11:52:31 --> Utf8 Class Initialized
DEBUG - 2011-10-07 11:52:31 --> UTF-8 Support Enabled
DEBUG - 2011-10-07 11:52:31 --> URI Class Initialized
DEBUG - 2011-10-07 11:52:31 --> Router Class Initialized
DEBUG - 2011-10-07 11:52:31 --> Output Class Initialized
DEBUG - 2011-10-07 11:52:31 --> Input Class Initialized
DEBUG - 2011-10-07 11:52:31 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-07 11:52:31 --> Language Class Initialized
DEBUG - 2011-10-07 11:52:31 --> Loader Class Initialized
DEBUG - 2011-10-07 11:52:31 --> Controller Class Initialized
DEBUG - 2011-10-07 11:52:31 --> Model Class Initialized
DEBUG - 2011-10-07 11:52:31 --> Model Class Initialized
DEBUG - 2011-10-07 11:52:31 --> Model Class Initialized
DEBUG - 2011-10-07 11:52:31 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-07 11:52:31 --> Database Driver Class Initialized
DEBUG - 2011-10-07 11:52:32 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-07 11:52:32 --> Helper loaded: url_helper
DEBUG - 2011-10-07 11:52:32 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-07 11:52:32 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-07 11:52:32 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-07 11:52:32 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-07 11:52:32 --> Final output sent to browser
DEBUG - 2011-10-07 11:52:32 --> Total execution time: 0.7202
DEBUG - 2011-10-07 11:52:33 --> Config Class Initialized
DEBUG - 2011-10-07 11:52:33 --> Hooks Class Initialized
DEBUG - 2011-10-07 11:52:33 --> Utf8 Class Initialized
DEBUG - 2011-10-07 11:52:33 --> UTF-8 Support Enabled
DEBUG - 2011-10-07 11:52:33 --> URI Class Initialized
DEBUG - 2011-10-07 11:52:33 --> Router Class Initialized
ERROR - 2011-10-07 11:52:33 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-07 12:09:29 --> Config Class Initialized
DEBUG - 2011-10-07 12:09:29 --> Hooks Class Initialized
DEBUG - 2011-10-07 12:09:29 --> Utf8 Class Initialized
DEBUG - 2011-10-07 12:09:29 --> UTF-8 Support Enabled
DEBUG - 2011-10-07 12:09:29 --> URI Class Initialized
DEBUG - 2011-10-07 12:09:29 --> Router Class Initialized
DEBUG - 2011-10-07 12:09:29 --> No URI present. Default controller set.
DEBUG - 2011-10-07 12:09:29 --> Output Class Initialized
DEBUG - 2011-10-07 12:09:29 --> Input Class Initialized
DEBUG - 2011-10-07 12:09:29 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-07 12:09:29 --> Language Class Initialized
DEBUG - 2011-10-07 12:09:29 --> Loader Class Initialized
DEBUG - 2011-10-07 12:09:29 --> Controller Class Initialized
DEBUG - 2011-10-07 12:09:29 --> File loaded: application/views/splash/main.php
DEBUG - 2011-10-07 12:09:29 --> Helper loaded: url_helper
DEBUG - 2011-10-07 12:09:29 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-07 12:09:29 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-07 12:09:29 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-07 12:09:29 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-07 12:09:29 --> Final output sent to browser
DEBUG - 2011-10-07 12:09:29 --> Total execution time: 0.1284
DEBUG - 2011-10-07 12:09:29 --> Config Class Initialized
DEBUG - 2011-10-07 12:09:29 --> Hooks Class Initialized
DEBUG - 2011-10-07 12:09:29 --> Utf8 Class Initialized
DEBUG - 2011-10-07 12:09:29 --> UTF-8 Support Enabled
DEBUG - 2011-10-07 12:09:29 --> URI Class Initialized
DEBUG - 2011-10-07 12:09:29 --> Router Class Initialized
ERROR - 2011-10-07 12:09:29 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-07 12:15:25 --> Config Class Initialized
DEBUG - 2011-10-07 12:15:25 --> Hooks Class Initialized
DEBUG - 2011-10-07 12:15:25 --> Utf8 Class Initialized
DEBUG - 2011-10-07 12:15:25 --> UTF-8 Support Enabled
DEBUG - 2011-10-07 12:15:25 --> URI Class Initialized
DEBUG - 2011-10-07 12:15:25 --> Router Class Initialized
ERROR - 2011-10-07 12:15:25 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-10-07 12:24:36 --> Config Class Initialized
DEBUG - 2011-10-07 12:24:36 --> Hooks Class Initialized
DEBUG - 2011-10-07 12:24:36 --> Utf8 Class Initialized
DEBUG - 2011-10-07 12:24:36 --> UTF-8 Support Enabled
DEBUG - 2011-10-07 12:24:36 --> URI Class Initialized
DEBUG - 2011-10-07 12:24:36 --> Router Class Initialized
DEBUG - 2011-10-07 12:24:36 --> Output Class Initialized
DEBUG - 2011-10-07 12:24:36 --> Input Class Initialized
DEBUG - 2011-10-07 12:24:36 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-07 12:24:36 --> Language Class Initialized
DEBUG - 2011-10-07 12:24:36 --> Loader Class Initialized
DEBUG - 2011-10-07 12:24:36 --> Controller Class Initialized
ERROR - 2011-10-07 12:24:36 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-10-07 12:24:36 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-10-07 12:24:36 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-07 12:24:36 --> Model Class Initialized
DEBUG - 2011-10-07 12:24:36 --> Model Class Initialized
DEBUG - 2011-10-07 12:24:36 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-07 12:24:36 --> Database Driver Class Initialized
DEBUG - 2011-10-07 12:24:37 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-07 12:24:37 --> Helper loaded: url_helper
DEBUG - 2011-10-07 12:24:37 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-07 12:24:37 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-07 12:24:37 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-07 12:24:37 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-07 12:24:37 --> Final output sent to browser
DEBUG - 2011-10-07 12:24:37 --> Total execution time: 0.4477
DEBUG - 2011-10-07 12:24:39 --> Config Class Initialized
DEBUG - 2011-10-07 12:24:39 --> Hooks Class Initialized
DEBUG - 2011-10-07 12:24:39 --> Utf8 Class Initialized
DEBUG - 2011-10-07 12:24:39 --> UTF-8 Support Enabled
DEBUG - 2011-10-07 12:24:39 --> URI Class Initialized
DEBUG - 2011-10-07 12:24:39 --> Router Class Initialized
DEBUG - 2011-10-07 12:24:39 --> Output Class Initialized
DEBUG - 2011-10-07 12:24:39 --> Input Class Initialized
DEBUG - 2011-10-07 12:24:39 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-07 12:24:39 --> Language Class Initialized
DEBUG - 2011-10-07 12:24:39 --> Loader Class Initialized
DEBUG - 2011-10-07 12:24:39 --> Controller Class Initialized
DEBUG - 2011-10-07 12:24:39 --> Model Class Initialized
DEBUG - 2011-10-07 12:24:39 --> Model Class Initialized
DEBUG - 2011-10-07 12:24:39 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-07 12:24:39 --> Database Driver Class Initialized
DEBUG - 2011-10-07 12:24:39 --> Final output sent to browser
DEBUG - 2011-10-07 12:24:39 --> Total execution time: 0.6755
DEBUG - 2011-10-07 13:16:50 --> Config Class Initialized
DEBUG - 2011-10-07 13:16:50 --> Hooks Class Initialized
DEBUG - 2011-10-07 13:16:50 --> Utf8 Class Initialized
DEBUG - 2011-10-07 13:16:50 --> UTF-8 Support Enabled
DEBUG - 2011-10-07 13:16:50 --> URI Class Initialized
DEBUG - 2011-10-07 13:16:50 --> Router Class Initialized
ERROR - 2011-10-07 13:16:50 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-10-07 13:16:50 --> Config Class Initialized
DEBUG - 2011-10-07 13:16:50 --> Hooks Class Initialized
DEBUG - 2011-10-07 13:16:50 --> Utf8 Class Initialized
DEBUG - 2011-10-07 13:16:50 --> UTF-8 Support Enabled
DEBUG - 2011-10-07 13:16:50 --> URI Class Initialized
DEBUG - 2011-10-07 13:16:50 --> Router Class Initialized
DEBUG - 2011-10-07 13:16:50 --> Output Class Initialized
DEBUG - 2011-10-07 13:16:50 --> Input Class Initialized
DEBUG - 2011-10-07 13:16:50 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-07 13:16:50 --> Language Class Initialized
DEBUG - 2011-10-07 13:16:50 --> Loader Class Initialized
DEBUG - 2011-10-07 13:16:50 --> Controller Class Initialized
DEBUG - 2011-10-07 13:16:50 --> Model Class Initialized
DEBUG - 2011-10-07 13:16:50 --> Model Class Initialized
DEBUG - 2011-10-07 13:16:50 --> Model Class Initialized
DEBUG - 2011-10-07 13:16:50 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-07 13:16:50 --> Database Driver Class Initialized
DEBUG - 2011-10-07 13:16:51 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-07 13:16:51 --> Helper loaded: url_helper
DEBUG - 2011-10-07 13:16:51 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-07 13:16:51 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-07 13:16:51 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-07 13:16:51 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-07 13:16:51 --> Final output sent to browser
DEBUG - 2011-10-07 13:16:51 --> Total execution time: 1.0742
DEBUG - 2011-10-07 13:43:52 --> Config Class Initialized
DEBUG - 2011-10-07 13:43:52 --> Hooks Class Initialized
DEBUG - 2011-10-07 13:43:52 --> Utf8 Class Initialized
DEBUG - 2011-10-07 13:43:52 --> UTF-8 Support Enabled
DEBUG - 2011-10-07 13:43:52 --> URI Class Initialized
DEBUG - 2011-10-07 13:43:52 --> Router Class Initialized
DEBUG - 2011-10-07 13:43:52 --> Output Class Initialized
DEBUG - 2011-10-07 13:43:52 --> Input Class Initialized
DEBUG - 2011-10-07 13:43:52 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-07 13:43:52 --> Language Class Initialized
DEBUG - 2011-10-07 13:43:52 --> Loader Class Initialized
DEBUG - 2011-10-07 13:43:52 --> Controller Class Initialized
DEBUG - 2011-10-07 13:43:52 --> Model Class Initialized
DEBUG - 2011-10-07 13:43:52 --> Model Class Initialized
DEBUG - 2011-10-07 13:43:52 --> Model Class Initialized
DEBUG - 2011-10-07 13:43:52 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-07 13:43:52 --> Database Driver Class Initialized
DEBUG - 2011-10-07 13:43:53 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-07 13:43:53 --> Helper loaded: url_helper
DEBUG - 2011-10-07 13:43:53 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-07 13:43:53 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-07 13:43:53 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-07 13:43:53 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-07 13:43:53 --> Final output sent to browser
DEBUG - 2011-10-07 13:43:53 --> Total execution time: 0.7200
DEBUG - 2011-10-07 13:43:55 --> Config Class Initialized
DEBUG - 2011-10-07 13:43:55 --> Hooks Class Initialized
DEBUG - 2011-10-07 13:43:55 --> Utf8 Class Initialized
DEBUG - 2011-10-07 13:43:55 --> UTF-8 Support Enabled
DEBUG - 2011-10-07 13:43:55 --> URI Class Initialized
DEBUG - 2011-10-07 13:43:55 --> Router Class Initialized
DEBUG - 2011-10-07 13:43:55 --> Output Class Initialized
DEBUG - 2011-10-07 13:43:55 --> Input Class Initialized
DEBUG - 2011-10-07 13:43:55 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-07 13:43:55 --> Language Class Initialized
DEBUG - 2011-10-07 13:43:55 --> Loader Class Initialized
DEBUG - 2011-10-07 13:43:55 --> Controller Class Initialized
ERROR - 2011-10-07 13:43:55 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-10-07 13:43:55 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-10-07 13:43:55 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-07 13:43:55 --> Model Class Initialized
DEBUG - 2011-10-07 13:43:55 --> Model Class Initialized
DEBUG - 2011-10-07 13:43:55 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-07 13:43:55 --> Database Driver Class Initialized
DEBUG - 2011-10-07 13:43:55 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-07 13:43:55 --> Helper loaded: url_helper
DEBUG - 2011-10-07 13:43:55 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-07 13:43:55 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-07 13:43:55 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-07 13:43:55 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-07 13:43:55 --> Final output sent to browser
DEBUG - 2011-10-07 13:43:55 --> Total execution time: 0.0336
DEBUG - 2011-10-07 14:56:33 --> Config Class Initialized
DEBUG - 2011-10-07 14:56:33 --> Hooks Class Initialized
DEBUG - 2011-10-07 14:56:33 --> Utf8 Class Initialized
DEBUG - 2011-10-07 14:56:33 --> UTF-8 Support Enabled
DEBUG - 2011-10-07 14:56:33 --> URI Class Initialized
DEBUG - 2011-10-07 14:56:33 --> Router Class Initialized
ERROR - 2011-10-07 14:56:33 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-10-07 14:56:33 --> Config Class Initialized
DEBUG - 2011-10-07 14:56:33 --> Hooks Class Initialized
DEBUG - 2011-10-07 14:56:33 --> Utf8 Class Initialized
DEBUG - 2011-10-07 14:56:33 --> UTF-8 Support Enabled
DEBUG - 2011-10-07 14:56:33 --> URI Class Initialized
DEBUG - 2011-10-07 14:56:33 --> Router Class Initialized
DEBUG - 2011-10-07 14:56:33 --> No URI present. Default controller set.
DEBUG - 2011-10-07 14:56:33 --> Output Class Initialized
DEBUG - 2011-10-07 14:56:33 --> Input Class Initialized
DEBUG - 2011-10-07 14:56:33 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-07 14:56:33 --> Language Class Initialized
DEBUG - 2011-10-07 14:56:33 --> Loader Class Initialized
DEBUG - 2011-10-07 14:56:33 --> Controller Class Initialized
DEBUG - 2011-10-07 14:56:33 --> File loaded: application/views/splash/main.php
DEBUG - 2011-10-07 14:56:33 --> Helper loaded: url_helper
DEBUG - 2011-10-07 14:56:33 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-07 14:56:33 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-07 14:56:33 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-07 14:56:33 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-07 14:56:33 --> Final output sent to browser
DEBUG - 2011-10-07 14:56:33 --> Total execution time: 0.1042
DEBUG - 2011-10-07 16:38:10 --> Config Class Initialized
DEBUG - 2011-10-07 16:38:10 --> Hooks Class Initialized
DEBUG - 2011-10-07 16:38:10 --> Utf8 Class Initialized
DEBUG - 2011-10-07 16:38:10 --> UTF-8 Support Enabled
DEBUG - 2011-10-07 16:38:10 --> URI Class Initialized
DEBUG - 2011-10-07 16:38:10 --> Router Class Initialized
DEBUG - 2011-10-07 16:38:10 --> Output Class Initialized
DEBUG - 2011-10-07 16:38:10 --> Input Class Initialized
DEBUG - 2011-10-07 16:38:10 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-07 16:38:10 --> Language Class Initialized
DEBUG - 2011-10-07 16:38:10 --> Loader Class Initialized
DEBUG - 2011-10-07 16:38:10 --> Controller Class Initialized
ERROR - 2011-10-07 16:38:10 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-10-07 16:38:10 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-10-07 16:38:10 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-07 16:38:10 --> Model Class Initialized
DEBUG - 2011-10-07 16:38:10 --> Model Class Initialized
DEBUG - 2011-10-07 16:38:10 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-07 16:38:10 --> Database Driver Class Initialized
DEBUG - 2011-10-07 16:38:11 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-07 16:38:11 --> Helper loaded: url_helper
DEBUG - 2011-10-07 16:38:11 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-07 16:38:11 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-07 16:38:11 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-07 16:38:11 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-07 16:38:11 --> Final output sent to browser
DEBUG - 2011-10-07 16:38:11 --> Total execution time: 0.7560
DEBUG - 2011-10-07 16:38:16 --> Config Class Initialized
DEBUG - 2011-10-07 16:38:16 --> Hooks Class Initialized
DEBUG - 2011-10-07 16:38:16 --> Utf8 Class Initialized
DEBUG - 2011-10-07 16:38:16 --> UTF-8 Support Enabled
DEBUG - 2011-10-07 16:38:16 --> URI Class Initialized
DEBUG - 2011-10-07 16:38:16 --> Router Class Initialized
DEBUG - 2011-10-07 16:38:16 --> Output Class Initialized
DEBUG - 2011-10-07 16:38:16 --> Input Class Initialized
DEBUG - 2011-10-07 16:38:16 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-07 16:38:16 --> Language Class Initialized
DEBUG - 2011-10-07 16:38:16 --> Loader Class Initialized
DEBUG - 2011-10-07 16:38:16 --> Controller Class Initialized
DEBUG - 2011-10-07 16:38:16 --> Model Class Initialized
DEBUG - 2011-10-07 16:38:16 --> Model Class Initialized
DEBUG - 2011-10-07 16:38:16 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-07 16:38:16 --> Database Driver Class Initialized
DEBUG - 2011-10-07 16:38:17 --> Final output sent to browser
DEBUG - 2011-10-07 16:38:17 --> Total execution time: 0.8243
DEBUG - 2011-10-07 16:43:11 --> Config Class Initialized
DEBUG - 2011-10-07 16:43:11 --> Hooks Class Initialized
DEBUG - 2011-10-07 16:43:11 --> Utf8 Class Initialized
DEBUG - 2011-10-07 16:43:11 --> UTF-8 Support Enabled
DEBUG - 2011-10-07 16:43:11 --> URI Class Initialized
DEBUG - 2011-10-07 16:43:11 --> Router Class Initialized
DEBUG - 2011-10-07 16:43:11 --> Output Class Initialized
DEBUG - 2011-10-07 16:43:11 --> Input Class Initialized
DEBUG - 2011-10-07 16:43:11 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-07 16:43:11 --> Language Class Initialized
DEBUG - 2011-10-07 16:43:11 --> Loader Class Initialized
DEBUG - 2011-10-07 16:43:11 --> Controller Class Initialized
DEBUG - 2011-10-07 16:43:11 --> Model Class Initialized
DEBUG - 2011-10-07 16:43:11 --> Model Class Initialized
DEBUG - 2011-10-07 16:43:11 --> Model Class Initialized
DEBUG - 2011-10-07 16:43:11 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-07 16:43:11 --> Database Driver Class Initialized
DEBUG - 2011-10-07 16:43:12 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-07 16:43:12 --> Helper loaded: url_helper
DEBUG - 2011-10-07 16:43:12 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-07 16:43:12 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-07 16:43:12 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-07 16:43:12 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-07 16:43:12 --> Final output sent to browser
DEBUG - 2011-10-07 16:43:12 --> Total execution time: 0.6369
DEBUG - 2011-10-07 16:43:14 --> Config Class Initialized
DEBUG - 2011-10-07 16:43:14 --> Hooks Class Initialized
DEBUG - 2011-10-07 16:43:14 --> Utf8 Class Initialized
DEBUG - 2011-10-07 16:43:14 --> UTF-8 Support Enabled
DEBUG - 2011-10-07 16:43:14 --> URI Class Initialized
DEBUG - 2011-10-07 16:43:14 --> Router Class Initialized
ERROR - 2011-10-07 16:43:14 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-07 16:43:15 --> Config Class Initialized
DEBUG - 2011-10-07 16:43:15 --> Hooks Class Initialized
DEBUG - 2011-10-07 16:43:15 --> Utf8 Class Initialized
DEBUG - 2011-10-07 16:43:15 --> UTF-8 Support Enabled
DEBUG - 2011-10-07 16:43:15 --> URI Class Initialized
DEBUG - 2011-10-07 16:43:15 --> Router Class Initialized
ERROR - 2011-10-07 16:43:15 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-07 16:43:15 --> Config Class Initialized
DEBUG - 2011-10-07 16:43:15 --> Hooks Class Initialized
DEBUG - 2011-10-07 16:43:15 --> Utf8 Class Initialized
DEBUG - 2011-10-07 16:43:15 --> UTF-8 Support Enabled
DEBUG - 2011-10-07 16:43:15 --> URI Class Initialized
DEBUG - 2011-10-07 16:43:15 --> Router Class Initialized
ERROR - 2011-10-07 16:43:15 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-07 16:43:16 --> Config Class Initialized
DEBUG - 2011-10-07 16:43:16 --> Hooks Class Initialized
DEBUG - 2011-10-07 16:43:16 --> Utf8 Class Initialized
DEBUG - 2011-10-07 16:43:16 --> UTF-8 Support Enabled
DEBUG - 2011-10-07 16:43:16 --> URI Class Initialized
DEBUG - 2011-10-07 16:43:16 --> Router Class Initialized
ERROR - 2011-10-07 16:43:16 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-07 16:43:20 --> Config Class Initialized
DEBUG - 2011-10-07 16:43:20 --> Hooks Class Initialized
DEBUG - 2011-10-07 16:43:20 --> Utf8 Class Initialized
DEBUG - 2011-10-07 16:43:20 --> UTF-8 Support Enabled
DEBUG - 2011-10-07 16:43:20 --> URI Class Initialized
DEBUG - 2011-10-07 16:43:20 --> Router Class Initialized
ERROR - 2011-10-07 16:43:20 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-07 19:32:23 --> Config Class Initialized
DEBUG - 2011-10-07 19:32:23 --> Hooks Class Initialized
DEBUG - 2011-10-07 19:32:23 --> Utf8 Class Initialized
DEBUG - 2011-10-07 19:32:23 --> UTF-8 Support Enabled
DEBUG - 2011-10-07 19:32:23 --> URI Class Initialized
DEBUG - 2011-10-07 19:32:23 --> Router Class Initialized
ERROR - 2011-10-07 19:32:23 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-10-07 19:32:23 --> Config Class Initialized
DEBUG - 2011-10-07 19:32:23 --> Hooks Class Initialized
DEBUG - 2011-10-07 19:32:23 --> Utf8 Class Initialized
DEBUG - 2011-10-07 19:32:23 --> UTF-8 Support Enabled
DEBUG - 2011-10-07 19:32:23 --> URI Class Initialized
DEBUG - 2011-10-07 19:32:23 --> Router Class Initialized
DEBUG - 2011-10-07 19:32:23 --> Output Class Initialized
DEBUG - 2011-10-07 19:32:23 --> Input Class Initialized
DEBUG - 2011-10-07 19:32:23 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-07 19:32:23 --> Language Class Initialized
DEBUG - 2011-10-07 19:32:23 --> Loader Class Initialized
DEBUG - 2011-10-07 19:32:23 --> Controller Class Initialized
ERROR - 2011-10-07 19:32:23 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-10-07 19:32:23 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-10-07 19:32:23 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-07 19:32:23 --> Model Class Initialized
DEBUG - 2011-10-07 19:32:23 --> Model Class Initialized
DEBUG - 2011-10-07 19:32:23 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-07 19:32:23 --> Database Driver Class Initialized
DEBUG - 2011-10-07 19:32:24 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-07 19:32:24 --> Helper loaded: url_helper
DEBUG - 2011-10-07 19:32:24 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-07 19:32:24 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-07 19:32:24 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-07 19:32:24 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-07 19:32:24 --> Final output sent to browser
DEBUG - 2011-10-07 19:32:24 --> Total execution time: 0.6565
DEBUG - 2011-10-07 20:34:23 --> Config Class Initialized
DEBUG - 2011-10-07 20:34:23 --> Hooks Class Initialized
DEBUG - 2011-10-07 20:34:23 --> Utf8 Class Initialized
DEBUG - 2011-10-07 20:34:23 --> UTF-8 Support Enabled
DEBUG - 2011-10-07 20:34:23 --> URI Class Initialized
DEBUG - 2011-10-07 20:34:23 --> Router Class Initialized
DEBUG - 2011-10-07 20:34:23 --> Output Class Initialized
DEBUG - 2011-10-07 20:34:23 --> Input Class Initialized
DEBUG - 2011-10-07 20:34:23 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-07 20:34:23 --> Language Class Initialized
DEBUG - 2011-10-07 20:34:23 --> Loader Class Initialized
DEBUG - 2011-10-07 20:34:23 --> Controller Class Initialized
DEBUG - 2011-10-07 20:34:23 --> Model Class Initialized
DEBUG - 2011-10-07 20:34:23 --> Model Class Initialized
DEBUG - 2011-10-07 20:34:23 --> Model Class Initialized
DEBUG - 2011-10-07 20:34:23 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-07 20:34:23 --> Database Driver Class Initialized
DEBUG - 2011-10-07 20:34:24 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-07 20:34:24 --> Helper loaded: url_helper
DEBUG - 2011-10-07 20:34:24 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-07 20:34:24 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-07 20:34:24 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-07 20:34:24 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-07 20:34:24 --> Final output sent to browser
DEBUG - 2011-10-07 20:34:24 --> Total execution time: 1.2744
DEBUG - 2011-10-07 22:05:40 --> Config Class Initialized
DEBUG - 2011-10-07 22:05:40 --> Hooks Class Initialized
DEBUG - 2011-10-07 22:05:40 --> Utf8 Class Initialized
DEBUG - 2011-10-07 22:05:40 --> UTF-8 Support Enabled
DEBUG - 2011-10-07 22:05:40 --> URI Class Initialized
DEBUG - 2011-10-07 22:05:40 --> Router Class Initialized
DEBUG - 2011-10-07 22:05:40 --> No URI present. Default controller set.
DEBUG - 2011-10-07 22:05:40 --> Output Class Initialized
DEBUG - 2011-10-07 22:05:40 --> Input Class Initialized
DEBUG - 2011-10-07 22:05:40 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-07 22:05:40 --> Language Class Initialized
DEBUG - 2011-10-07 22:05:40 --> Loader Class Initialized
DEBUG - 2011-10-07 22:05:40 --> Controller Class Initialized
DEBUG - 2011-10-07 22:05:40 --> File loaded: application/views/splash/main.php
DEBUG - 2011-10-07 22:05:40 --> Helper loaded: url_helper
DEBUG - 2011-10-07 22:05:40 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-07 22:05:40 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-07 22:05:40 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-07 22:05:40 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-07 22:05:40 --> Final output sent to browser
DEBUG - 2011-10-07 22:05:40 --> Total execution time: 0.1512
DEBUG - 2011-10-07 22:40:58 --> Config Class Initialized
DEBUG - 2011-10-07 22:40:58 --> Hooks Class Initialized
DEBUG - 2011-10-07 22:40:58 --> Utf8 Class Initialized
DEBUG - 2011-10-07 22:40:58 --> UTF-8 Support Enabled
DEBUG - 2011-10-07 22:40:58 --> URI Class Initialized
DEBUG - 2011-10-07 22:40:58 --> Router Class Initialized
DEBUG - 2011-10-07 22:40:58 --> Output Class Initialized
DEBUG - 2011-10-07 22:40:58 --> Input Class Initialized
DEBUG - 2011-10-07 22:40:58 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-07 22:40:58 --> Language Class Initialized
DEBUG - 2011-10-07 22:40:58 --> Loader Class Initialized
DEBUG - 2011-10-07 22:40:58 --> Controller Class Initialized
DEBUG - 2011-10-07 22:40:58 --> Model Class Initialized
DEBUG - 2011-10-07 22:40:58 --> Model Class Initialized
DEBUG - 2011-10-07 22:40:58 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-07 22:40:58 --> Database Driver Class Initialized
DEBUG - 2011-10-07 22:40:59 --> Final output sent to browser
DEBUG - 2011-10-07 22:40:59 --> Total execution time: 0.9371

<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2011-05-11 00:48:29 --> Config Class Initialized
DEBUG - 2011-05-11 00:48:29 --> Hooks Class Initialized
DEBUG - 2011-05-11 00:48:29 --> Utf8 Class Initialized
DEBUG - 2011-05-11 00:48:29 --> UTF-8 Support Enabled
DEBUG - 2011-05-11 00:48:29 --> URI Class Initialized
DEBUG - 2011-05-11 00:48:29 --> Router Class Initialized
DEBUG - 2011-05-11 00:48:29 --> Output Class Initialized
DEBUG - 2011-05-11 00:48:29 --> Input Class Initialized
DEBUG - 2011-05-11 00:48:29 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-11 00:48:29 --> Language Class Initialized
DEBUG - 2011-05-11 00:48:29 --> Loader Class Initialized
DEBUG - 2011-05-11 00:48:29 --> Controller Class Initialized
ERROR - 2011-05-11 00:48:29 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-11 00:48:29 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-11 00:48:29 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-11 00:48:29 --> Model Class Initialized
DEBUG - 2011-05-11 00:48:29 --> Model Class Initialized
DEBUG - 2011-05-11 00:48:29 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-11 00:48:29 --> Database Driver Class Initialized
DEBUG - 2011-05-11 00:48:29 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-11 00:48:29 --> Helper loaded: url_helper
DEBUG - 2011-05-11 00:48:29 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-11 00:48:29 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-11 00:48:29 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-11 00:48:29 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-11 00:48:29 --> Final output sent to browser
DEBUG - 2011-05-11 00:48:29 --> Total execution time: 0.3907
DEBUG - 2011-05-11 01:11:33 --> Config Class Initialized
DEBUG - 2011-05-11 01:11:33 --> Hooks Class Initialized
DEBUG - 2011-05-11 01:11:33 --> Utf8 Class Initialized
DEBUG - 2011-05-11 01:11:33 --> UTF-8 Support Enabled
DEBUG - 2011-05-11 01:11:33 --> URI Class Initialized
DEBUG - 2011-05-11 01:11:33 --> Router Class Initialized
ERROR - 2011-05-11 01:11:33 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-05-11 01:12:19 --> Config Class Initialized
DEBUG - 2011-05-11 01:12:19 --> Hooks Class Initialized
DEBUG - 2011-05-11 01:12:19 --> Utf8 Class Initialized
DEBUG - 2011-05-11 01:12:19 --> UTF-8 Support Enabled
DEBUG - 2011-05-11 01:12:19 --> URI Class Initialized
DEBUG - 2011-05-11 01:12:19 --> Router Class Initialized
DEBUG - 2011-05-11 01:12:20 --> Output Class Initialized
DEBUG - 2011-05-11 01:12:20 --> Input Class Initialized
DEBUG - 2011-05-11 01:12:20 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-11 01:12:20 --> Language Class Initialized
DEBUG - 2011-05-11 01:12:20 --> Loader Class Initialized
DEBUG - 2011-05-11 01:12:20 --> Controller Class Initialized
DEBUG - 2011-05-11 01:12:20 --> Model Class Initialized
DEBUG - 2011-05-11 01:12:20 --> Model Class Initialized
DEBUG - 2011-05-11 01:12:20 --> Model Class Initialized
DEBUG - 2011-05-11 01:12:20 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-11 01:12:21 --> Database Driver Class Initialized
DEBUG - 2011-05-11 01:12:21 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-11 01:12:21 --> Helper loaded: url_helper
DEBUG - 2011-05-11 01:12:21 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-11 01:12:21 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-11 01:12:21 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-11 01:12:21 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-11 01:12:21 --> Final output sent to browser
DEBUG - 2011-05-11 01:12:21 --> Total execution time: 1.6173
DEBUG - 2011-05-11 01:37:46 --> Config Class Initialized
DEBUG - 2011-05-11 01:37:46 --> Hooks Class Initialized
DEBUG - 2011-05-11 01:37:46 --> Utf8 Class Initialized
DEBUG - 2011-05-11 01:37:46 --> UTF-8 Support Enabled
DEBUG - 2011-05-11 01:37:46 --> URI Class Initialized
DEBUG - 2011-05-11 01:37:46 --> Router Class Initialized
DEBUG - 2011-05-11 01:37:46 --> Output Class Initialized
DEBUG - 2011-05-11 01:37:46 --> Input Class Initialized
DEBUG - 2011-05-11 01:37:46 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-11 01:37:46 --> Language Class Initialized
DEBUG - 2011-05-11 01:37:46 --> Loader Class Initialized
DEBUG - 2011-05-11 01:37:46 --> Controller Class Initialized
ERROR - 2011-05-11 01:37:47 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-11 01:37:47 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-11 01:37:47 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-11 01:37:47 --> Model Class Initialized
DEBUG - 2011-05-11 01:37:47 --> Model Class Initialized
DEBUG - 2011-05-11 01:37:47 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-11 01:37:47 --> Database Driver Class Initialized
DEBUG - 2011-05-11 01:37:47 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-11 01:37:47 --> Helper loaded: url_helper
DEBUG - 2011-05-11 01:37:47 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-11 01:37:47 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-11 01:37:47 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-11 01:37:47 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-11 01:37:47 --> Final output sent to browser
DEBUG - 2011-05-11 01:37:47 --> Total execution time: 0.3249
DEBUG - 2011-05-11 01:37:47 --> Config Class Initialized
DEBUG - 2011-05-11 01:37:47 --> Hooks Class Initialized
DEBUG - 2011-05-11 01:37:47 --> Utf8 Class Initialized
DEBUG - 2011-05-11 01:37:47 --> UTF-8 Support Enabled
DEBUG - 2011-05-11 01:37:47 --> URI Class Initialized
DEBUG - 2011-05-11 01:37:47 --> Router Class Initialized
DEBUG - 2011-05-11 01:37:47 --> Output Class Initialized
DEBUG - 2011-05-11 01:37:47 --> Input Class Initialized
DEBUG - 2011-05-11 01:37:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-11 01:37:47 --> Language Class Initialized
DEBUG - 2011-05-11 01:37:47 --> Loader Class Initialized
DEBUG - 2011-05-11 01:37:47 --> Controller Class Initialized
DEBUG - 2011-05-11 01:37:47 --> Model Class Initialized
DEBUG - 2011-05-11 01:37:47 --> Model Class Initialized
DEBUG - 2011-05-11 01:37:47 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-11 01:37:47 --> Database Driver Class Initialized
DEBUG - 2011-05-11 01:37:48 --> Final output sent to browser
DEBUG - 2011-05-11 01:37:48 --> Total execution time: 0.8168
DEBUG - 2011-05-11 01:37:49 --> Config Class Initialized
DEBUG - 2011-05-11 01:37:49 --> Hooks Class Initialized
DEBUG - 2011-05-11 01:37:49 --> Utf8 Class Initialized
DEBUG - 2011-05-11 01:37:49 --> UTF-8 Support Enabled
DEBUG - 2011-05-11 01:37:49 --> URI Class Initialized
DEBUG - 2011-05-11 01:37:49 --> Router Class Initialized
ERROR - 2011-05-11 01:37:49 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-11 01:37:49 --> Config Class Initialized
DEBUG - 2011-05-11 01:37:49 --> Hooks Class Initialized
DEBUG - 2011-05-11 01:37:49 --> Utf8 Class Initialized
DEBUG - 2011-05-11 01:37:49 --> UTF-8 Support Enabled
DEBUG - 2011-05-11 01:37:49 --> URI Class Initialized
DEBUG - 2011-05-11 01:37:49 --> Router Class Initialized
ERROR - 2011-05-11 01:37:49 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-11 01:38:36 --> Config Class Initialized
DEBUG - 2011-05-11 01:38:36 --> Hooks Class Initialized
DEBUG - 2011-05-11 01:38:36 --> Utf8 Class Initialized
DEBUG - 2011-05-11 01:38:36 --> UTF-8 Support Enabled
DEBUG - 2011-05-11 01:38:36 --> URI Class Initialized
DEBUG - 2011-05-11 01:38:36 --> Router Class Initialized
DEBUG - 2011-05-11 01:38:36 --> Output Class Initialized
DEBUG - 2011-05-11 01:38:36 --> Input Class Initialized
DEBUG - 2011-05-11 01:38:36 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-11 01:38:36 --> Language Class Initialized
DEBUG - 2011-05-11 01:38:36 --> Loader Class Initialized
DEBUG - 2011-05-11 01:38:36 --> Controller Class Initialized
ERROR - 2011-05-11 01:38:36 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-11 01:38:36 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-11 01:38:36 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-11 01:38:36 --> Model Class Initialized
DEBUG - 2011-05-11 01:38:36 --> Model Class Initialized
DEBUG - 2011-05-11 01:38:36 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-11 01:38:36 --> Database Driver Class Initialized
DEBUG - 2011-05-11 01:38:36 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-11 01:38:36 --> Helper loaded: url_helper
DEBUG - 2011-05-11 01:38:36 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-11 01:38:36 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-11 01:38:36 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-11 01:38:36 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-11 01:38:36 --> Final output sent to browser
DEBUG - 2011-05-11 01:38:36 --> Total execution time: 0.0396
DEBUG - 2011-05-11 01:38:36 --> Config Class Initialized
DEBUG - 2011-05-11 01:38:36 --> Hooks Class Initialized
DEBUG - 2011-05-11 01:38:36 --> Utf8 Class Initialized
DEBUG - 2011-05-11 01:38:36 --> UTF-8 Support Enabled
DEBUG - 2011-05-11 01:38:36 --> URI Class Initialized
DEBUG - 2011-05-11 01:38:36 --> Router Class Initialized
DEBUG - 2011-05-11 01:38:36 --> Output Class Initialized
DEBUG - 2011-05-11 01:38:36 --> Input Class Initialized
DEBUG - 2011-05-11 01:38:36 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-11 01:38:36 --> Language Class Initialized
DEBUG - 2011-05-11 01:38:36 --> Loader Class Initialized
DEBUG - 2011-05-11 01:38:36 --> Controller Class Initialized
DEBUG - 2011-05-11 01:38:36 --> Model Class Initialized
DEBUG - 2011-05-11 01:38:36 --> Model Class Initialized
DEBUG - 2011-05-11 01:38:36 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-11 01:38:36 --> Database Driver Class Initialized
DEBUG - 2011-05-11 01:38:37 --> Final output sent to browser
DEBUG - 2011-05-11 01:38:37 --> Total execution time: 0.5667
DEBUG - 2011-05-11 01:38:49 --> Config Class Initialized
DEBUG - 2011-05-11 01:38:49 --> Hooks Class Initialized
DEBUG - 2011-05-11 01:38:49 --> Utf8 Class Initialized
DEBUG - 2011-05-11 01:38:49 --> UTF-8 Support Enabled
DEBUG - 2011-05-11 01:38:49 --> URI Class Initialized
DEBUG - 2011-05-11 01:38:49 --> Router Class Initialized
DEBUG - 2011-05-11 01:38:49 --> Output Class Initialized
DEBUG - 2011-05-11 01:38:49 --> Input Class Initialized
DEBUG - 2011-05-11 01:38:49 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-11 01:38:49 --> Language Class Initialized
DEBUG - 2011-05-11 01:38:49 --> Loader Class Initialized
DEBUG - 2011-05-11 01:38:49 --> Controller Class Initialized
ERROR - 2011-05-11 01:38:49 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-11 01:38:49 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-11 01:38:49 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-11 01:38:49 --> Model Class Initialized
DEBUG - 2011-05-11 01:38:49 --> Model Class Initialized
DEBUG - 2011-05-11 01:38:49 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-11 01:38:49 --> Database Driver Class Initialized
DEBUG - 2011-05-11 01:38:49 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-11 01:38:49 --> Helper loaded: url_helper
DEBUG - 2011-05-11 01:38:49 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-11 01:38:49 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-11 01:38:49 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-11 01:38:49 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-11 01:38:49 --> Final output sent to browser
DEBUG - 2011-05-11 01:38:49 --> Total execution time: 0.2023
DEBUG - 2011-05-11 01:38:50 --> Config Class Initialized
DEBUG - 2011-05-11 01:38:50 --> Hooks Class Initialized
DEBUG - 2011-05-11 01:38:50 --> Utf8 Class Initialized
DEBUG - 2011-05-11 01:38:50 --> UTF-8 Support Enabled
DEBUG - 2011-05-11 01:38:50 --> URI Class Initialized
DEBUG - 2011-05-11 01:38:50 --> Router Class Initialized
DEBUG - 2011-05-11 01:38:50 --> Output Class Initialized
DEBUG - 2011-05-11 01:38:50 --> Input Class Initialized
DEBUG - 2011-05-11 01:38:50 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-11 01:38:50 --> Language Class Initialized
DEBUG - 2011-05-11 01:38:50 --> Loader Class Initialized
DEBUG - 2011-05-11 01:38:50 --> Controller Class Initialized
DEBUG - 2011-05-11 01:38:50 --> Model Class Initialized
DEBUG - 2011-05-11 01:38:50 --> Model Class Initialized
DEBUG - 2011-05-11 01:38:50 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-11 01:38:50 --> Database Driver Class Initialized
DEBUG - 2011-05-11 01:38:52 --> Final output sent to browser
DEBUG - 2011-05-11 01:38:52 --> Total execution time: 2.2891
DEBUG - 2011-05-11 01:40:11 --> Config Class Initialized
DEBUG - 2011-05-11 01:40:11 --> Hooks Class Initialized
DEBUG - 2011-05-11 01:40:11 --> Utf8 Class Initialized
DEBUG - 2011-05-11 01:40:11 --> UTF-8 Support Enabled
DEBUG - 2011-05-11 01:40:11 --> URI Class Initialized
DEBUG - 2011-05-11 01:40:11 --> Router Class Initialized
DEBUG - 2011-05-11 01:40:11 --> Output Class Initialized
DEBUG - 2011-05-11 01:40:11 --> Input Class Initialized
DEBUG - 2011-05-11 01:40:11 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-11 01:40:11 --> Language Class Initialized
DEBUG - 2011-05-11 01:40:11 --> Loader Class Initialized
DEBUG - 2011-05-11 01:40:11 --> Controller Class Initialized
ERROR - 2011-05-11 01:40:11 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-11 01:40:11 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-11 01:40:11 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-11 01:40:11 --> Model Class Initialized
DEBUG - 2011-05-11 01:40:11 --> Model Class Initialized
DEBUG - 2011-05-11 01:40:11 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-11 01:40:11 --> Database Driver Class Initialized
DEBUG - 2011-05-11 01:40:11 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-11 01:40:11 --> Helper loaded: url_helper
DEBUG - 2011-05-11 01:40:11 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-11 01:40:11 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-11 01:40:11 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-11 01:40:11 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-11 01:40:11 --> Final output sent to browser
DEBUG - 2011-05-11 01:40:11 --> Total execution time: 0.0341
DEBUG - 2011-05-11 01:40:12 --> Config Class Initialized
DEBUG - 2011-05-11 01:40:12 --> Hooks Class Initialized
DEBUG - 2011-05-11 01:40:12 --> Utf8 Class Initialized
DEBUG - 2011-05-11 01:40:12 --> UTF-8 Support Enabled
DEBUG - 2011-05-11 01:40:12 --> URI Class Initialized
DEBUG - 2011-05-11 01:40:12 --> Router Class Initialized
DEBUG - 2011-05-11 01:40:12 --> Output Class Initialized
DEBUG - 2011-05-11 01:40:12 --> Input Class Initialized
DEBUG - 2011-05-11 01:40:12 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-11 01:40:12 --> Language Class Initialized
DEBUG - 2011-05-11 01:40:12 --> Loader Class Initialized
DEBUG - 2011-05-11 01:40:12 --> Controller Class Initialized
DEBUG - 2011-05-11 01:40:12 --> Model Class Initialized
DEBUG - 2011-05-11 01:40:12 --> Model Class Initialized
DEBUG - 2011-05-11 01:40:12 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-11 01:40:12 --> Database Driver Class Initialized
DEBUG - 2011-05-11 01:40:14 --> Final output sent to browser
DEBUG - 2011-05-11 01:40:14 --> Total execution time: 1.6445
DEBUG - 2011-05-11 01:49:22 --> Config Class Initialized
DEBUG - 2011-05-11 01:49:22 --> Hooks Class Initialized
DEBUG - 2011-05-11 01:49:22 --> Utf8 Class Initialized
DEBUG - 2011-05-11 01:49:22 --> UTF-8 Support Enabled
DEBUG - 2011-05-11 01:49:22 --> URI Class Initialized
DEBUG - 2011-05-11 01:49:22 --> Router Class Initialized
DEBUG - 2011-05-11 01:49:22 --> Output Class Initialized
DEBUG - 2011-05-11 01:49:22 --> Input Class Initialized
DEBUG - 2011-05-11 01:49:22 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-11 01:49:22 --> Language Class Initialized
DEBUG - 2011-05-11 01:49:22 --> Loader Class Initialized
DEBUG - 2011-05-11 01:49:22 --> Controller Class Initialized
DEBUG - 2011-05-11 01:49:22 --> Model Class Initialized
DEBUG - 2011-05-11 01:49:22 --> Model Class Initialized
DEBUG - 2011-05-11 01:49:22 --> Model Class Initialized
DEBUG - 2011-05-11 01:49:22 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-11 01:49:22 --> Database Driver Class Initialized
DEBUG - 2011-05-11 01:49:26 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-11 01:49:26 --> Helper loaded: url_helper
DEBUG - 2011-05-11 01:49:26 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-11 01:49:26 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-11 01:49:26 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-11 01:49:26 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-11 01:49:26 --> Final output sent to browser
DEBUG - 2011-05-11 01:49:26 --> Total execution time: 4.0852
DEBUG - 2011-05-11 01:49:58 --> Config Class Initialized
DEBUG - 2011-05-11 01:49:58 --> Hooks Class Initialized
DEBUG - 2011-05-11 01:49:58 --> Utf8 Class Initialized
DEBUG - 2011-05-11 01:49:58 --> UTF-8 Support Enabled
DEBUG - 2011-05-11 01:49:58 --> URI Class Initialized
DEBUG - 2011-05-11 01:49:58 --> Router Class Initialized
DEBUG - 2011-05-11 01:49:58 --> Output Class Initialized
DEBUG - 2011-05-11 01:49:58 --> Input Class Initialized
DEBUG - 2011-05-11 01:49:58 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-11 01:49:58 --> Language Class Initialized
DEBUG - 2011-05-11 01:49:58 --> Loader Class Initialized
DEBUG - 2011-05-11 01:49:58 --> Controller Class Initialized
ERROR - 2011-05-11 01:49:58 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-11 01:49:58 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-11 01:49:58 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-11 01:49:58 --> Model Class Initialized
DEBUG - 2011-05-11 01:49:58 --> Model Class Initialized
DEBUG - 2011-05-11 01:49:58 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-11 01:49:58 --> Database Driver Class Initialized
DEBUG - 2011-05-11 01:49:58 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-11 01:49:58 --> Helper loaded: url_helper
DEBUG - 2011-05-11 01:49:58 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-11 01:49:58 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-11 01:49:58 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-11 01:49:58 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-11 01:49:58 --> Final output sent to browser
DEBUG - 2011-05-11 01:49:58 --> Total execution time: 0.0956
DEBUG - 2011-05-11 01:49:59 --> Config Class Initialized
DEBUG - 2011-05-11 01:49:59 --> Hooks Class Initialized
DEBUG - 2011-05-11 01:49:59 --> Utf8 Class Initialized
DEBUG - 2011-05-11 01:49:59 --> UTF-8 Support Enabled
DEBUG - 2011-05-11 01:49:59 --> URI Class Initialized
DEBUG - 2011-05-11 01:49:59 --> Router Class Initialized
DEBUG - 2011-05-11 01:49:59 --> Output Class Initialized
DEBUG - 2011-05-11 01:49:59 --> Input Class Initialized
DEBUG - 2011-05-11 01:49:59 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-11 01:49:59 --> Language Class Initialized
DEBUG - 2011-05-11 01:49:59 --> Loader Class Initialized
DEBUG - 2011-05-11 01:49:59 --> Controller Class Initialized
DEBUG - 2011-05-11 01:49:59 --> Model Class Initialized
DEBUG - 2011-05-11 01:49:59 --> Model Class Initialized
DEBUG - 2011-05-11 01:49:59 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-11 01:49:59 --> Database Driver Class Initialized
DEBUG - 2011-05-11 01:49:59 --> Final output sent to browser
DEBUG - 2011-05-11 01:49:59 --> Total execution time: 0.5870
DEBUG - 2011-05-11 04:05:21 --> Config Class Initialized
DEBUG - 2011-05-11 04:05:22 --> Hooks Class Initialized
DEBUG - 2011-05-11 04:05:22 --> Utf8 Class Initialized
DEBUG - 2011-05-11 04:05:22 --> UTF-8 Support Enabled
DEBUG - 2011-05-11 04:05:22 --> URI Class Initialized
DEBUG - 2011-05-11 04:05:22 --> Router Class Initialized
DEBUG - 2011-05-11 04:05:23 --> Output Class Initialized
DEBUG - 2011-05-11 04:05:24 --> Input Class Initialized
DEBUG - 2011-05-11 04:05:24 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-11 04:05:24 --> Language Class Initialized
DEBUG - 2011-05-11 04:05:24 --> Loader Class Initialized
DEBUG - 2011-05-11 04:05:24 --> Controller Class Initialized
DEBUG - 2011-05-11 04:05:25 --> Model Class Initialized
DEBUG - 2011-05-11 04:05:25 --> Model Class Initialized
DEBUG - 2011-05-11 04:05:25 --> Model Class Initialized
DEBUG - 2011-05-11 04:05:25 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-11 04:05:25 --> Database Driver Class Initialized
DEBUG - 2011-05-11 04:05:30 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-11 04:05:31 --> Helper loaded: url_helper
DEBUG - 2011-05-11 04:05:31 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-11 04:05:31 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-11 04:05:31 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-11 04:05:31 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-11 04:05:31 --> Final output sent to browser
DEBUG - 2011-05-11 04:05:31 --> Total execution time: 11.6557
DEBUG - 2011-05-11 04:05:34 --> Config Class Initialized
DEBUG - 2011-05-11 04:05:34 --> Hooks Class Initialized
DEBUG - 2011-05-11 04:05:34 --> Utf8 Class Initialized
DEBUG - 2011-05-11 04:05:34 --> UTF-8 Support Enabled
DEBUG - 2011-05-11 04:05:34 --> URI Class Initialized
DEBUG - 2011-05-11 04:05:34 --> Router Class Initialized
ERROR - 2011-05-11 04:05:34 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-11 04:05:35 --> Config Class Initialized
DEBUG - 2011-05-11 04:05:35 --> Hooks Class Initialized
DEBUG - 2011-05-11 04:05:35 --> Utf8 Class Initialized
DEBUG - 2011-05-11 04:05:35 --> UTF-8 Support Enabled
DEBUG - 2011-05-11 04:05:35 --> URI Class Initialized
DEBUG - 2011-05-11 04:05:35 --> Router Class Initialized
ERROR - 2011-05-11 04:05:35 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-11 04:05:46 --> Config Class Initialized
DEBUG - 2011-05-11 04:05:46 --> Hooks Class Initialized
DEBUG - 2011-05-11 04:05:46 --> Utf8 Class Initialized
DEBUG - 2011-05-11 04:05:46 --> UTF-8 Support Enabled
DEBUG - 2011-05-11 04:05:46 --> URI Class Initialized
DEBUG - 2011-05-11 04:05:46 --> Router Class Initialized
DEBUG - 2011-05-11 04:05:46 --> Output Class Initialized
DEBUG - 2011-05-11 04:05:46 --> Input Class Initialized
DEBUG - 2011-05-11 04:05:46 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-11 04:05:46 --> Language Class Initialized
DEBUG - 2011-05-11 04:05:46 --> Loader Class Initialized
DEBUG - 2011-05-11 04:05:46 --> Controller Class Initialized
DEBUG - 2011-05-11 04:05:46 --> Model Class Initialized
DEBUG - 2011-05-11 04:05:46 --> Model Class Initialized
DEBUG - 2011-05-11 04:05:46 --> Model Class Initialized
DEBUG - 2011-05-11 04:05:46 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-11 04:05:46 --> Database Driver Class Initialized
DEBUG - 2011-05-11 04:05:51 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-11 04:05:51 --> Helper loaded: url_helper
DEBUG - 2011-05-11 04:05:51 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-11 04:05:51 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-11 04:05:51 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-11 04:05:51 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-11 04:05:51 --> Final output sent to browser
DEBUG - 2011-05-11 04:05:51 --> Total execution time: 5.1985
DEBUG - 2011-05-11 04:05:52 --> Config Class Initialized
DEBUG - 2011-05-11 04:05:52 --> Hooks Class Initialized
DEBUG - 2011-05-11 04:05:52 --> Utf8 Class Initialized
DEBUG - 2011-05-11 04:05:52 --> UTF-8 Support Enabled
DEBUG - 2011-05-11 04:05:52 --> URI Class Initialized
DEBUG - 2011-05-11 04:05:52 --> Router Class Initialized
ERROR - 2011-05-11 04:05:52 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-05-11 04:05:53 --> Config Class Initialized
DEBUG - 2011-05-11 04:05:53 --> Hooks Class Initialized
DEBUG - 2011-05-11 04:05:53 --> Utf8 Class Initialized
DEBUG - 2011-05-11 04:05:53 --> UTF-8 Support Enabled
DEBUG - 2011-05-11 04:05:53 --> URI Class Initialized
DEBUG - 2011-05-11 04:05:53 --> Router Class Initialized
DEBUG - 2011-05-11 04:05:53 --> Output Class Initialized
DEBUG - 2011-05-11 04:05:53 --> Input Class Initialized
DEBUG - 2011-05-11 04:05:53 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-11 04:05:53 --> Language Class Initialized
DEBUG - 2011-05-11 04:05:53 --> Loader Class Initialized
DEBUG - 2011-05-11 04:05:53 --> Controller Class Initialized
DEBUG - 2011-05-11 04:05:53 --> Model Class Initialized
DEBUG - 2011-05-11 04:05:53 --> Model Class Initialized
DEBUG - 2011-05-11 04:05:53 --> Model Class Initialized
DEBUG - 2011-05-11 04:05:53 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-11 04:05:53 --> Database Driver Class Initialized
DEBUG - 2011-05-11 04:05:53 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-11 04:05:53 --> Helper loaded: url_helper
DEBUG - 2011-05-11 04:05:53 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-11 04:05:53 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-11 04:05:53 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-11 04:05:53 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-11 04:05:53 --> Final output sent to browser
DEBUG - 2011-05-11 04:05:53 --> Total execution time: 0.0650
DEBUG - 2011-05-11 07:38:13 --> Config Class Initialized
DEBUG - 2011-05-11 07:38:13 --> Hooks Class Initialized
DEBUG - 2011-05-11 07:38:13 --> Utf8 Class Initialized
DEBUG - 2011-05-11 07:38:13 --> UTF-8 Support Enabled
DEBUG - 2011-05-11 07:38:13 --> URI Class Initialized
DEBUG - 2011-05-11 07:38:13 --> Router Class Initialized
DEBUG - 2011-05-11 07:38:13 --> Output Class Initialized
DEBUG - 2011-05-11 07:38:13 --> Input Class Initialized
DEBUG - 2011-05-11 07:38:13 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-11 07:38:13 --> Language Class Initialized
DEBUG - 2011-05-11 07:38:13 --> Loader Class Initialized
DEBUG - 2011-05-11 07:38:13 --> Controller Class Initialized
DEBUG - 2011-05-11 07:38:13 --> Model Class Initialized
DEBUG - 2011-05-11 07:38:13 --> Model Class Initialized
DEBUG - 2011-05-11 07:38:13 --> Model Class Initialized
DEBUG - 2011-05-11 07:38:13 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-11 07:38:13 --> Database Driver Class Initialized
DEBUG - 2011-05-11 07:38:14 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-11 07:38:14 --> Helper loaded: url_helper
DEBUG - 2011-05-11 07:38:14 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-11 07:38:14 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-11 07:38:14 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-11 07:38:14 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-11 07:38:14 --> Final output sent to browser
DEBUG - 2011-05-11 07:38:14 --> Total execution time: 1.4221
DEBUG - 2011-05-11 07:38:16 --> Config Class Initialized
DEBUG - 2011-05-11 07:38:16 --> Hooks Class Initialized
DEBUG - 2011-05-11 07:38:16 --> Utf8 Class Initialized
DEBUG - 2011-05-11 07:38:16 --> UTF-8 Support Enabled
DEBUG - 2011-05-11 07:38:16 --> URI Class Initialized
DEBUG - 2011-05-11 07:38:16 --> Router Class Initialized
DEBUG - 2011-05-11 07:38:16 --> Output Class Initialized
DEBUG - 2011-05-11 07:38:16 --> Input Class Initialized
DEBUG - 2011-05-11 07:38:16 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-11 07:38:16 --> Language Class Initialized
DEBUG - 2011-05-11 07:38:16 --> Loader Class Initialized
DEBUG - 2011-05-11 07:38:16 --> Controller Class Initialized
ERROR - 2011-05-11 07:38:16 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-11 07:38:16 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-11 07:38:16 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-11 07:38:16 --> Model Class Initialized
DEBUG - 2011-05-11 07:38:16 --> Model Class Initialized
DEBUG - 2011-05-11 07:38:16 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-11 07:38:16 --> Database Driver Class Initialized
DEBUG - 2011-05-11 07:38:16 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-11 07:38:16 --> Helper loaded: url_helper
DEBUG - 2011-05-11 07:38:16 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-11 07:38:16 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-11 07:38:16 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-11 07:38:16 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-11 07:38:16 --> Final output sent to browser
DEBUG - 2011-05-11 07:38:16 --> Total execution time: 0.3074
DEBUG - 2011-05-11 12:43:26 --> Config Class Initialized
DEBUG - 2011-05-11 12:43:26 --> Hooks Class Initialized
DEBUG - 2011-05-11 12:43:26 --> Utf8 Class Initialized
DEBUG - 2011-05-11 12:43:26 --> UTF-8 Support Enabled
DEBUG - 2011-05-11 12:43:26 --> URI Class Initialized
DEBUG - 2011-05-11 12:43:26 --> Router Class Initialized
DEBUG - 2011-05-11 12:43:26 --> Output Class Initialized
DEBUG - 2011-05-11 12:43:26 --> Input Class Initialized
DEBUG - 2011-05-11 12:43:26 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-11 12:43:26 --> Language Class Initialized
DEBUG - 2011-05-11 12:43:26 --> Loader Class Initialized
DEBUG - 2011-05-11 12:43:26 --> Controller Class Initialized
ERROR - 2011-05-11 12:43:26 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-11 12:43:26 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-11 12:43:26 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-11 12:43:26 --> Model Class Initialized
DEBUG - 2011-05-11 12:43:26 --> Model Class Initialized
DEBUG - 2011-05-11 12:43:26 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-11 12:43:27 --> Database Driver Class Initialized
DEBUG - 2011-05-11 12:43:27 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-11 12:43:27 --> Helper loaded: url_helper
DEBUG - 2011-05-11 12:43:27 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-11 12:43:27 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-11 12:43:27 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-11 12:43:27 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-11 12:43:27 --> Final output sent to browser
DEBUG - 2011-05-11 12:43:27 --> Total execution time: 0.5501
DEBUG - 2011-05-11 12:44:51 --> Config Class Initialized
DEBUG - 2011-05-11 12:44:51 --> Hooks Class Initialized
DEBUG - 2011-05-11 12:44:51 --> Utf8 Class Initialized
DEBUG - 2011-05-11 12:44:51 --> UTF-8 Support Enabled
DEBUG - 2011-05-11 12:44:51 --> URI Class Initialized
DEBUG - 2011-05-11 12:44:51 --> Router Class Initialized
DEBUG - 2011-05-11 12:44:51 --> Output Class Initialized
DEBUG - 2011-05-11 12:44:51 --> Input Class Initialized
DEBUG - 2011-05-11 12:44:51 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-11 12:44:51 --> Language Class Initialized
DEBUG - 2011-05-11 12:44:51 --> Loader Class Initialized
DEBUG - 2011-05-11 12:44:51 --> Controller Class Initialized
ERROR - 2011-05-11 12:44:51 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-11 12:44:51 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-11 12:44:51 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-11 12:44:51 --> Model Class Initialized
DEBUG - 2011-05-11 12:44:51 --> Model Class Initialized
DEBUG - 2011-05-11 12:44:51 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-11 12:44:51 --> Database Driver Class Initialized
DEBUG - 2011-05-11 12:44:51 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-11 12:44:51 --> Helper loaded: url_helper
DEBUG - 2011-05-11 12:44:51 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-11 12:44:51 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-11 12:44:51 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-11 12:44:51 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-11 12:44:51 --> Final output sent to browser
DEBUG - 2011-05-11 12:44:51 --> Total execution time: 0.0553
DEBUG - 2011-05-11 12:44:53 --> Config Class Initialized
DEBUG - 2011-05-11 12:44:53 --> Hooks Class Initialized
DEBUG - 2011-05-11 12:44:53 --> Utf8 Class Initialized
DEBUG - 2011-05-11 12:44:53 --> UTF-8 Support Enabled
DEBUG - 2011-05-11 12:44:53 --> URI Class Initialized
DEBUG - 2011-05-11 12:44:53 --> Router Class Initialized
DEBUG - 2011-05-11 12:44:53 --> Output Class Initialized
DEBUG - 2011-05-11 12:44:53 --> Input Class Initialized
DEBUG - 2011-05-11 12:44:53 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-11 12:44:53 --> Language Class Initialized
DEBUG - 2011-05-11 12:44:53 --> Loader Class Initialized
DEBUG - 2011-05-11 12:44:53 --> Controller Class Initialized
DEBUG - 2011-05-11 12:44:53 --> Model Class Initialized
DEBUG - 2011-05-11 12:44:53 --> Model Class Initialized
DEBUG - 2011-05-11 12:44:53 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-11 12:44:53 --> Database Driver Class Initialized
DEBUG - 2011-05-11 12:44:54 --> Final output sent to browser
DEBUG - 2011-05-11 12:44:54 --> Total execution time: 0.6970
DEBUG - 2011-05-11 12:44:57 --> Config Class Initialized
DEBUG - 2011-05-11 12:44:57 --> Hooks Class Initialized
DEBUG - 2011-05-11 12:44:57 --> Utf8 Class Initialized
DEBUG - 2011-05-11 12:44:57 --> UTF-8 Support Enabled
DEBUG - 2011-05-11 12:44:57 --> URI Class Initialized
DEBUG - 2011-05-11 12:44:57 --> Router Class Initialized
ERROR - 2011-05-11 12:44:57 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-11 13:08:47 --> Config Class Initialized
DEBUG - 2011-05-11 13:08:47 --> Hooks Class Initialized
DEBUG - 2011-05-11 13:08:47 --> Utf8 Class Initialized
DEBUG - 2011-05-11 13:08:47 --> UTF-8 Support Enabled
DEBUG - 2011-05-11 13:08:47 --> URI Class Initialized
DEBUG - 2011-05-11 13:08:47 --> Router Class Initialized
DEBUG - 2011-05-11 13:08:47 --> Output Class Initialized
DEBUG - 2011-05-11 13:08:47 --> Input Class Initialized
DEBUG - 2011-05-11 13:08:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-11 13:08:47 --> Language Class Initialized
DEBUG - 2011-05-11 13:08:47 --> Loader Class Initialized
DEBUG - 2011-05-11 13:08:47 --> Controller Class Initialized
DEBUG - 2011-05-11 13:08:47 --> Model Class Initialized
DEBUG - 2011-05-11 13:08:47 --> Model Class Initialized
DEBUG - 2011-05-11 13:08:47 --> Model Class Initialized
DEBUG - 2011-05-11 13:08:47 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-11 13:08:47 --> Database Driver Class Initialized
DEBUG - 2011-05-11 13:08:48 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-11 13:08:48 --> Helper loaded: url_helper
DEBUG - 2011-05-11 13:08:48 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-11 13:08:48 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-11 13:08:48 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-11 13:08:48 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-11 13:08:48 --> Final output sent to browser
DEBUG - 2011-05-11 13:08:48 --> Total execution time: 0.5354
DEBUG - 2011-05-11 13:17:11 --> Config Class Initialized
DEBUG - 2011-05-11 13:17:11 --> Hooks Class Initialized
DEBUG - 2011-05-11 13:17:11 --> Utf8 Class Initialized
DEBUG - 2011-05-11 13:17:11 --> UTF-8 Support Enabled
DEBUG - 2011-05-11 13:17:11 --> URI Class Initialized
DEBUG - 2011-05-11 13:17:11 --> Router Class Initialized
ERROR - 2011-05-11 13:17:11 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-05-11 13:17:12 --> Config Class Initialized
DEBUG - 2011-05-11 13:17:12 --> Hooks Class Initialized
DEBUG - 2011-05-11 13:17:12 --> Utf8 Class Initialized
DEBUG - 2011-05-11 13:17:12 --> UTF-8 Support Enabled
DEBUG - 2011-05-11 13:17:12 --> URI Class Initialized
DEBUG - 2011-05-11 13:17:12 --> Router Class Initialized
DEBUG - 2011-05-11 13:17:12 --> No URI present. Default controller set.
DEBUG - 2011-05-11 13:17:12 --> Output Class Initialized
DEBUG - 2011-05-11 13:17:12 --> Input Class Initialized
DEBUG - 2011-05-11 13:17:12 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-11 13:17:12 --> Language Class Initialized
DEBUG - 2011-05-11 13:17:12 --> Loader Class Initialized
DEBUG - 2011-05-11 13:17:12 --> Controller Class Initialized
DEBUG - 2011-05-11 13:17:12 --> File loaded: application/views/splash/main.php
DEBUG - 2011-05-11 13:17:12 --> Helper loaded: url_helper
DEBUG - 2011-05-11 13:17:12 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-11 13:17:12 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-11 13:17:12 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-11 13:17:12 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-11 13:17:12 --> Final output sent to browser
DEBUG - 2011-05-11 13:17:12 --> Total execution time: 0.2162
DEBUG - 2011-05-11 14:54:49 --> Config Class Initialized
DEBUG - 2011-05-11 14:54:49 --> Hooks Class Initialized
DEBUG - 2011-05-11 14:54:49 --> Utf8 Class Initialized
DEBUG - 2011-05-11 14:54:49 --> UTF-8 Support Enabled
DEBUG - 2011-05-11 14:54:49 --> URI Class Initialized
DEBUG - 2011-05-11 14:54:49 --> Router Class Initialized
DEBUG - 2011-05-11 14:54:49 --> No URI present. Default controller set.
DEBUG - 2011-05-11 14:54:49 --> Output Class Initialized
DEBUG - 2011-05-11 14:54:49 --> Input Class Initialized
DEBUG - 2011-05-11 14:54:49 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-11 14:54:49 --> Language Class Initialized
DEBUG - 2011-05-11 14:54:49 --> Loader Class Initialized
DEBUG - 2011-05-11 14:54:49 --> Controller Class Initialized
DEBUG - 2011-05-11 14:54:49 --> File loaded: application/views/splash/main.php
DEBUG - 2011-05-11 14:54:50 --> Helper loaded: url_helper
DEBUG - 2011-05-11 14:54:50 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-11 14:54:50 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-11 14:54:50 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-11 14:54:50 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-11 14:54:50 --> Final output sent to browser
DEBUG - 2011-05-11 14:54:50 --> Total execution time: 0.2808
DEBUG - 2011-05-11 14:54:50 --> Config Class Initialized
DEBUG - 2011-05-11 14:54:50 --> Hooks Class Initialized
DEBUG - 2011-05-11 14:54:50 --> Utf8 Class Initialized
DEBUG - 2011-05-11 14:54:50 --> UTF-8 Support Enabled
DEBUG - 2011-05-11 14:54:50 --> URI Class Initialized
DEBUG - 2011-05-11 14:54:50 --> Router Class Initialized
ERROR - 2011-05-11 14:54:50 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-11 14:54:51 --> Config Class Initialized
DEBUG - 2011-05-11 14:54:51 --> Hooks Class Initialized
DEBUG - 2011-05-11 14:54:51 --> Utf8 Class Initialized
DEBUG - 2011-05-11 14:54:51 --> UTF-8 Support Enabled
DEBUG - 2011-05-11 14:54:51 --> URI Class Initialized
DEBUG - 2011-05-11 14:54:51 --> Router Class Initialized
ERROR - 2011-05-11 14:54:51 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-11 14:54:52 --> Config Class Initialized
DEBUG - 2011-05-11 14:54:52 --> Hooks Class Initialized
DEBUG - 2011-05-11 14:54:52 --> Utf8 Class Initialized
DEBUG - 2011-05-11 14:54:52 --> UTF-8 Support Enabled
DEBUG - 2011-05-11 14:54:52 --> URI Class Initialized
DEBUG - 2011-05-11 14:54:52 --> Router Class Initialized
DEBUG - 2011-05-11 14:54:52 --> No URI present. Default controller set.
DEBUG - 2011-05-11 14:54:52 --> Output Class Initialized
DEBUG - 2011-05-11 14:54:52 --> Input Class Initialized
DEBUG - 2011-05-11 14:54:52 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-11 14:54:52 --> Language Class Initialized
DEBUG - 2011-05-11 14:54:52 --> Loader Class Initialized
DEBUG - 2011-05-11 14:54:52 --> Controller Class Initialized
DEBUG - 2011-05-11 14:54:52 --> File loaded: application/views/splash/main.php
DEBUG - 2011-05-11 14:54:52 --> Helper loaded: url_helper
DEBUG - 2011-05-11 14:54:52 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-11 14:54:52 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-11 14:54:52 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-11 14:54:52 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-11 14:54:52 --> Final output sent to browser
DEBUG - 2011-05-11 14:54:52 --> Total execution time: 0.0134
DEBUG - 2011-05-11 14:54:52 --> Config Class Initialized
DEBUG - 2011-05-11 14:54:52 --> Hooks Class Initialized
DEBUG - 2011-05-11 14:54:52 --> Utf8 Class Initialized
DEBUG - 2011-05-11 14:54:52 --> UTF-8 Support Enabled
DEBUG - 2011-05-11 14:54:52 --> URI Class Initialized
DEBUG - 2011-05-11 14:54:52 --> Router Class Initialized
DEBUG - 2011-05-11 14:54:52 --> Output Class Initialized
DEBUG - 2011-05-11 14:54:52 --> Input Class Initialized
DEBUG - 2011-05-11 14:54:52 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-11 14:54:52 --> Language Class Initialized
DEBUG - 2011-05-11 14:54:52 --> Loader Class Initialized
DEBUG - 2011-05-11 14:54:52 --> Controller Class Initialized
DEBUG - 2011-05-11 14:54:52 --> Model Class Initialized
DEBUG - 2011-05-11 14:54:52 --> Model Class Initialized
DEBUG - 2011-05-11 14:54:52 --> Model Class Initialized
DEBUG - 2011-05-11 14:54:52 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-11 14:54:52 --> Database Driver Class Initialized
DEBUG - 2011-05-11 14:54:53 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-11 14:54:53 --> Helper loaded: url_helper
DEBUG - 2011-05-11 14:54:53 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-11 14:54:53 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-11 14:54:53 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-11 14:54:53 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-11 14:54:53 --> Final output sent to browser
DEBUG - 2011-05-11 14:54:53 --> Total execution time: 0.5481
DEBUG - 2011-05-11 14:54:54 --> Config Class Initialized
DEBUG - 2011-05-11 14:54:54 --> Hooks Class Initialized
DEBUG - 2011-05-11 14:54:54 --> Utf8 Class Initialized
DEBUG - 2011-05-11 14:54:54 --> UTF-8 Support Enabled
DEBUG - 2011-05-11 14:54:54 --> URI Class Initialized
DEBUG - 2011-05-11 14:54:54 --> Router Class Initialized
ERROR - 2011-05-11 14:54:54 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-11 15:01:56 --> Config Class Initialized
DEBUG - 2011-05-11 15:01:56 --> Hooks Class Initialized
DEBUG - 2011-05-11 15:01:56 --> Utf8 Class Initialized
DEBUG - 2011-05-11 15:01:56 --> UTF-8 Support Enabled
DEBUG - 2011-05-11 15:01:56 --> URI Class Initialized
DEBUG - 2011-05-11 15:01:56 --> Router Class Initialized
DEBUG - 2011-05-11 15:01:56 --> Output Class Initialized
DEBUG - 2011-05-11 15:01:56 --> Input Class Initialized
DEBUG - 2011-05-11 15:01:56 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-11 15:01:56 --> Language Class Initialized
DEBUG - 2011-05-11 15:01:56 --> Loader Class Initialized
DEBUG - 2011-05-11 15:01:56 --> Controller Class Initialized
DEBUG - 2011-05-11 15:01:56 --> Model Class Initialized
DEBUG - 2011-05-11 15:01:56 --> Model Class Initialized
DEBUG - 2011-05-11 15:01:56 --> Model Class Initialized
DEBUG - 2011-05-11 15:01:56 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-11 15:01:56 --> Database Driver Class Initialized
DEBUG - 2011-05-11 15:01:56 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-11 15:01:56 --> Helper loaded: url_helper
DEBUG - 2011-05-11 15:01:56 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-11 15:01:56 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-11 15:01:56 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-11 15:01:56 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-11 15:01:56 --> Final output sent to browser
DEBUG - 2011-05-11 15:01:56 --> Total execution time: 0.2042
DEBUG - 2011-05-11 15:01:57 --> Config Class Initialized
DEBUG - 2011-05-11 15:01:57 --> Hooks Class Initialized
DEBUG - 2011-05-11 15:01:57 --> Utf8 Class Initialized
DEBUG - 2011-05-11 15:01:57 --> UTF-8 Support Enabled
DEBUG - 2011-05-11 15:01:57 --> URI Class Initialized
DEBUG - 2011-05-11 15:01:57 --> Router Class Initialized
DEBUG - 2011-05-11 15:01:57 --> Output Class Initialized
DEBUG - 2011-05-11 15:01:57 --> Input Class Initialized
DEBUG - 2011-05-11 15:01:57 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-11 15:01:57 --> Language Class Initialized
DEBUG - 2011-05-11 15:01:57 --> Loader Class Initialized
DEBUG - 2011-05-11 15:01:57 --> Controller Class Initialized
ERROR - 2011-05-11 15:01:57 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-11 15:01:57 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-11 15:01:57 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-11 15:01:57 --> Model Class Initialized
DEBUG - 2011-05-11 15:01:57 --> Model Class Initialized
DEBUG - 2011-05-11 15:01:57 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-11 15:01:57 --> Database Driver Class Initialized
DEBUG - 2011-05-11 15:01:57 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-11 15:01:57 --> Helper loaded: url_helper
DEBUG - 2011-05-11 15:01:57 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-11 15:01:57 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-11 15:01:57 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-11 15:01:57 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-11 15:01:57 --> Final output sent to browser
DEBUG - 2011-05-11 15:01:57 --> Total execution time: 0.0843
DEBUG - 2011-05-11 15:10:00 --> Config Class Initialized
DEBUG - 2011-05-11 15:10:00 --> Hooks Class Initialized
DEBUG - 2011-05-11 15:10:00 --> Utf8 Class Initialized
DEBUG - 2011-05-11 15:10:00 --> UTF-8 Support Enabled
DEBUG - 2011-05-11 15:10:00 --> URI Class Initialized
DEBUG - 2011-05-11 15:10:00 --> Router Class Initialized
DEBUG - 2011-05-11 15:10:00 --> No URI present. Default controller set.
DEBUG - 2011-05-11 15:10:00 --> Output Class Initialized
DEBUG - 2011-05-11 15:10:00 --> Input Class Initialized
DEBUG - 2011-05-11 15:10:00 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-11 15:10:00 --> Language Class Initialized
DEBUG - 2011-05-11 15:10:00 --> Loader Class Initialized
DEBUG - 2011-05-11 15:10:00 --> Controller Class Initialized
DEBUG - 2011-05-11 15:10:00 --> File loaded: application/views/splash/main.php
DEBUG - 2011-05-11 15:10:00 --> Helper loaded: url_helper
DEBUG - 2011-05-11 15:10:00 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-11 15:10:00 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-11 15:10:00 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-11 15:10:00 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-11 15:10:00 --> Final output sent to browser
DEBUG - 2011-05-11 15:10:00 --> Total execution time: 0.0343
DEBUG - 2011-05-11 15:10:01 --> Config Class Initialized
DEBUG - 2011-05-11 15:10:01 --> Hooks Class Initialized
DEBUG - 2011-05-11 15:10:01 --> Utf8 Class Initialized
DEBUG - 2011-05-11 15:10:01 --> UTF-8 Support Enabled
DEBUG - 2011-05-11 15:10:01 --> URI Class Initialized
DEBUG - 2011-05-11 15:10:01 --> Router Class Initialized
ERROR - 2011-05-11 15:10:01 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-11 15:10:02 --> Config Class Initialized
DEBUG - 2011-05-11 15:10:02 --> Hooks Class Initialized
DEBUG - 2011-05-11 15:10:02 --> Utf8 Class Initialized
DEBUG - 2011-05-11 15:10:02 --> UTF-8 Support Enabled
DEBUG - 2011-05-11 15:10:02 --> URI Class Initialized
DEBUG - 2011-05-11 15:10:02 --> Router Class Initialized
ERROR - 2011-05-11 15:10:02 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-11 15:10:03 --> Config Class Initialized
DEBUG - 2011-05-11 15:10:03 --> Hooks Class Initialized
DEBUG - 2011-05-11 15:10:03 --> Utf8 Class Initialized
DEBUG - 2011-05-11 15:10:03 --> UTF-8 Support Enabled
DEBUG - 2011-05-11 15:10:03 --> URI Class Initialized
DEBUG - 2011-05-11 15:10:03 --> Router Class Initialized
DEBUG - 2011-05-11 15:10:03 --> Output Class Initialized
DEBUG - 2011-05-11 15:10:03 --> Input Class Initialized
DEBUG - 2011-05-11 15:10:03 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-11 15:10:03 --> Language Class Initialized
DEBUG - 2011-05-11 15:10:03 --> Loader Class Initialized
DEBUG - 2011-05-11 15:10:03 --> Controller Class Initialized
DEBUG - 2011-05-11 15:10:03 --> Model Class Initialized
DEBUG - 2011-05-11 15:10:03 --> Model Class Initialized
DEBUG - 2011-05-11 15:10:03 --> Model Class Initialized
DEBUG - 2011-05-11 15:10:03 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-11 15:10:03 --> Database Driver Class Initialized
DEBUG - 2011-05-11 15:10:04 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-11 15:10:04 --> Helper loaded: url_helper
DEBUG - 2011-05-11 15:10:04 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-11 15:10:04 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-11 15:10:04 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-11 15:10:04 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-11 15:10:04 --> Final output sent to browser
DEBUG - 2011-05-11 15:10:04 --> Total execution time: 1.3437
DEBUG - 2011-05-11 15:10:05 --> Config Class Initialized
DEBUG - 2011-05-11 15:10:05 --> Hooks Class Initialized
DEBUG - 2011-05-11 15:10:05 --> Utf8 Class Initialized
DEBUG - 2011-05-11 15:10:05 --> UTF-8 Support Enabled
DEBUG - 2011-05-11 15:10:05 --> URI Class Initialized
DEBUG - 2011-05-11 15:10:05 --> Router Class Initialized
ERROR - 2011-05-11 15:10:05 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-11 16:47:08 --> Config Class Initialized
DEBUG - 2011-05-11 16:47:08 --> Hooks Class Initialized
DEBUG - 2011-05-11 16:47:08 --> Utf8 Class Initialized
DEBUG - 2011-05-11 16:47:08 --> UTF-8 Support Enabled
DEBUG - 2011-05-11 16:47:08 --> URI Class Initialized
DEBUG - 2011-05-11 16:47:08 --> Router Class Initialized
DEBUG - 2011-05-11 16:47:08 --> No URI present. Default controller set.
DEBUG - 2011-05-11 16:47:08 --> Output Class Initialized
DEBUG - 2011-05-11 16:47:08 --> Input Class Initialized
DEBUG - 2011-05-11 16:47:08 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-11 16:47:08 --> Language Class Initialized
DEBUG - 2011-05-11 16:47:08 --> Loader Class Initialized
DEBUG - 2011-05-11 16:47:08 --> Controller Class Initialized
DEBUG - 2011-05-11 16:47:09 --> File loaded: application/views/splash/main.php
DEBUG - 2011-05-11 16:47:09 --> Helper loaded: url_helper
DEBUG - 2011-05-11 16:47:09 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-11 16:47:09 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-11 16:47:09 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-11 16:47:09 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-11 16:47:09 --> Final output sent to browser
DEBUG - 2011-05-11 16:47:09 --> Total execution time: 1.0786
DEBUG - 2011-05-11 16:47:13 --> Config Class Initialized
DEBUG - 2011-05-11 16:47:13 --> Hooks Class Initialized
DEBUG - 2011-05-11 16:47:13 --> Utf8 Class Initialized
DEBUG - 2011-05-11 16:47:13 --> UTF-8 Support Enabled
DEBUG - 2011-05-11 16:47:13 --> URI Class Initialized
DEBUG - 2011-05-11 16:47:13 --> Router Class Initialized
ERROR - 2011-05-11 16:47:14 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-11 16:47:14 --> Config Class Initialized
DEBUG - 2011-05-11 16:47:14 --> Hooks Class Initialized
DEBUG - 2011-05-11 16:47:14 --> Utf8 Class Initialized
DEBUG - 2011-05-11 16:47:14 --> UTF-8 Support Enabled
DEBUG - 2011-05-11 16:47:14 --> URI Class Initialized
DEBUG - 2011-05-11 16:47:14 --> Router Class Initialized
ERROR - 2011-05-11 16:47:14 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-11 16:47:17 --> Config Class Initialized
DEBUG - 2011-05-11 16:47:17 --> Hooks Class Initialized
DEBUG - 2011-05-11 16:47:17 --> Utf8 Class Initialized
DEBUG - 2011-05-11 16:47:17 --> UTF-8 Support Enabled
DEBUG - 2011-05-11 16:47:17 --> URI Class Initialized
DEBUG - 2011-05-11 16:47:17 --> Router Class Initialized
DEBUG - 2011-05-11 16:47:17 --> Output Class Initialized
DEBUG - 2011-05-11 16:47:17 --> Input Class Initialized
DEBUG - 2011-05-11 16:47:17 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-11 16:47:17 --> Language Class Initialized
DEBUG - 2011-05-11 16:47:17 --> Loader Class Initialized
DEBUG - 2011-05-11 16:47:17 --> Controller Class Initialized
DEBUG - 2011-05-11 16:47:17 --> Model Class Initialized
DEBUG - 2011-05-11 16:47:17 --> Model Class Initialized
DEBUG - 2011-05-11 16:47:17 --> Model Class Initialized
DEBUG - 2011-05-11 16:47:17 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-11 16:47:18 --> Database Driver Class Initialized
DEBUG - 2011-05-11 16:47:20 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-11 16:47:20 --> Helper loaded: url_helper
DEBUG - 2011-05-11 16:47:20 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-11 16:47:20 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-11 16:47:20 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-11 16:47:20 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-11 16:47:20 --> Final output sent to browser
DEBUG - 2011-05-11 16:47:20 --> Total execution time: 3.1372
DEBUG - 2011-05-11 16:47:32 --> Config Class Initialized
DEBUG - 2011-05-11 16:47:32 --> Hooks Class Initialized
DEBUG - 2011-05-11 16:47:32 --> Utf8 Class Initialized
DEBUG - 2011-05-11 16:47:32 --> UTF-8 Support Enabled
DEBUG - 2011-05-11 16:47:32 --> URI Class Initialized
DEBUG - 2011-05-11 16:47:32 --> Router Class Initialized
DEBUG - 2011-05-11 16:47:32 --> Output Class Initialized
DEBUG - 2011-05-11 16:47:32 --> Input Class Initialized
DEBUG - 2011-05-11 16:47:32 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-11 16:47:32 --> Language Class Initialized
DEBUG - 2011-05-11 16:47:32 --> Loader Class Initialized
DEBUG - 2011-05-11 16:47:32 --> Controller Class Initialized
DEBUG - 2011-05-11 16:47:32 --> Model Class Initialized
DEBUG - 2011-05-11 16:47:32 --> Model Class Initialized
DEBUG - 2011-05-11 16:47:32 --> Model Class Initialized
DEBUG - 2011-05-11 16:47:32 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-11 16:47:32 --> Database Driver Class Initialized
DEBUG - 2011-05-11 16:47:33 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-11 16:47:33 --> Helper loaded: url_helper
DEBUG - 2011-05-11 16:47:33 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-11 16:47:33 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-11 16:47:33 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-11 16:47:33 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-11 16:47:33 --> Final output sent to browser
DEBUG - 2011-05-11 16:47:33 --> Total execution time: 0.4518
DEBUG - 2011-05-11 16:47:38 --> Config Class Initialized
DEBUG - 2011-05-11 16:47:38 --> Hooks Class Initialized
DEBUG - 2011-05-11 16:47:38 --> Utf8 Class Initialized
DEBUG - 2011-05-11 16:47:38 --> UTF-8 Support Enabled
DEBUG - 2011-05-11 16:47:38 --> URI Class Initialized
DEBUG - 2011-05-11 16:47:38 --> Router Class Initialized
ERROR - 2011-05-11 16:47:38 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-05-11 16:47:38 --> Config Class Initialized
DEBUG - 2011-05-11 16:47:38 --> Hooks Class Initialized
DEBUG - 2011-05-11 16:47:38 --> Utf8 Class Initialized
DEBUG - 2011-05-11 16:47:38 --> UTF-8 Support Enabled
DEBUG - 2011-05-11 16:47:38 --> URI Class Initialized
DEBUG - 2011-05-11 16:47:38 --> Router Class Initialized
DEBUG - 2011-05-11 16:47:38 --> Output Class Initialized
DEBUG - 2011-05-11 16:47:38 --> Input Class Initialized
DEBUG - 2011-05-11 16:47:38 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-11 16:47:38 --> Language Class Initialized
DEBUG - 2011-05-11 16:47:38 --> Loader Class Initialized
DEBUG - 2011-05-11 16:47:38 --> Controller Class Initialized
DEBUG - 2011-05-11 16:47:38 --> Model Class Initialized
DEBUG - 2011-05-11 16:47:38 --> Model Class Initialized
DEBUG - 2011-05-11 16:47:38 --> Model Class Initialized
DEBUG - 2011-05-11 16:47:38 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-11 16:47:38 --> Database Driver Class Initialized
DEBUG - 2011-05-11 16:47:38 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-11 16:47:38 --> Helper loaded: url_helper
DEBUG - 2011-05-11 16:47:38 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-11 16:47:38 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-11 16:47:38 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-11 16:47:38 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-11 16:47:38 --> Final output sent to browser
DEBUG - 2011-05-11 16:47:38 --> Total execution time: 0.0692
DEBUG - 2011-05-11 20:15:13 --> Config Class Initialized
DEBUG - 2011-05-11 20:15:13 --> Hooks Class Initialized
DEBUG - 2011-05-11 20:15:13 --> Utf8 Class Initialized
DEBUG - 2011-05-11 20:15:13 --> UTF-8 Support Enabled
DEBUG - 2011-05-11 20:15:13 --> URI Class Initialized
DEBUG - 2011-05-11 20:15:13 --> Router Class Initialized
DEBUG - 2011-05-11 20:15:13 --> Output Class Initialized
DEBUG - 2011-05-11 20:15:13 --> Input Class Initialized
DEBUG - 2011-05-11 20:15:13 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-11 20:15:13 --> Language Class Initialized
DEBUG - 2011-05-11 20:15:13 --> Loader Class Initialized
DEBUG - 2011-05-11 20:15:13 --> Controller Class Initialized
DEBUG - 2011-05-11 20:15:13 --> Model Class Initialized
DEBUG - 2011-05-11 20:15:13 --> Model Class Initialized
DEBUG - 2011-05-11 20:15:13 --> Model Class Initialized
DEBUG - 2011-05-11 20:15:13 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-11 20:15:13 --> Database Driver Class Initialized
DEBUG - 2011-05-11 20:15:14 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-11 20:15:14 --> Helper loaded: url_helper
DEBUG - 2011-05-11 20:15:14 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-11 20:15:14 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-11 20:15:14 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-11 20:15:14 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-11 20:15:14 --> Final output sent to browser
DEBUG - 2011-05-11 20:15:14 --> Total execution time: 1.4866
DEBUG - 2011-05-11 20:15:15 --> Config Class Initialized
DEBUG - 2011-05-11 20:15:15 --> Hooks Class Initialized
DEBUG - 2011-05-11 20:15:15 --> Utf8 Class Initialized
DEBUG - 2011-05-11 20:15:15 --> UTF-8 Support Enabled
DEBUG - 2011-05-11 20:15:15 --> URI Class Initialized
DEBUG - 2011-05-11 20:15:15 --> Router Class Initialized
ERROR - 2011-05-11 20:15:15 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-11 20:15:16 --> Config Class Initialized
DEBUG - 2011-05-11 20:15:16 --> Hooks Class Initialized
DEBUG - 2011-05-11 20:15:16 --> Utf8 Class Initialized
DEBUG - 2011-05-11 20:15:16 --> UTF-8 Support Enabled
DEBUG - 2011-05-11 20:15:16 --> URI Class Initialized
DEBUG - 2011-05-11 20:15:16 --> Router Class Initialized
ERROR - 2011-05-11 20:15:16 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-11 20:15:16 --> Config Class Initialized
DEBUG - 2011-05-11 20:15:16 --> Hooks Class Initialized
DEBUG - 2011-05-11 20:15:16 --> Utf8 Class Initialized
DEBUG - 2011-05-11 20:15:16 --> UTF-8 Support Enabled
DEBUG - 2011-05-11 20:15:16 --> URI Class Initialized
DEBUG - 2011-05-11 20:15:16 --> Router Class Initialized
ERROR - 2011-05-11 20:15:16 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-11 20:15:42 --> Config Class Initialized
DEBUG - 2011-05-11 20:15:42 --> Hooks Class Initialized
DEBUG - 2011-05-11 20:15:42 --> Utf8 Class Initialized
DEBUG - 2011-05-11 20:15:42 --> UTF-8 Support Enabled
DEBUG - 2011-05-11 20:15:42 --> URI Class Initialized
DEBUG - 2011-05-11 20:15:42 --> Router Class Initialized
DEBUG - 2011-05-11 20:15:42 --> Output Class Initialized
DEBUG - 2011-05-11 20:15:42 --> Input Class Initialized
DEBUG - 2011-05-11 20:15:42 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-11 20:15:42 --> Language Class Initialized
DEBUG - 2011-05-11 20:15:42 --> Loader Class Initialized
DEBUG - 2011-05-11 20:15:42 --> Controller Class Initialized
DEBUG - 2011-05-11 20:15:42 --> Model Class Initialized
DEBUG - 2011-05-11 20:15:42 --> Model Class Initialized
DEBUG - 2011-05-11 20:15:42 --> Model Class Initialized
DEBUG - 2011-05-11 20:15:42 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-11 20:15:42 --> Database Driver Class Initialized
DEBUG - 2011-05-11 20:15:42 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-11 20:15:42 --> Helper loaded: url_helper
DEBUG - 2011-05-11 20:15:42 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-11 20:15:42 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-11 20:15:42 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-11 20:15:42 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-11 20:15:42 --> Final output sent to browser
DEBUG - 2011-05-11 20:15:42 --> Total execution time: 0.5031
DEBUG - 2011-05-11 20:16:05 --> Config Class Initialized
DEBUG - 2011-05-11 20:16:05 --> Hooks Class Initialized
DEBUG - 2011-05-11 20:16:05 --> Utf8 Class Initialized
DEBUG - 2011-05-11 20:16:05 --> UTF-8 Support Enabled
DEBUG - 2011-05-11 20:16:05 --> URI Class Initialized
DEBUG - 2011-05-11 20:16:05 --> Router Class Initialized
DEBUG - 2011-05-11 20:16:05 --> Output Class Initialized
DEBUG - 2011-05-11 20:16:05 --> Input Class Initialized
DEBUG - 2011-05-11 20:16:05 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-11 20:16:05 --> Language Class Initialized
DEBUG - 2011-05-11 20:16:05 --> Loader Class Initialized
DEBUG - 2011-05-11 20:16:05 --> Controller Class Initialized
DEBUG - 2011-05-11 20:16:05 --> Model Class Initialized
DEBUG - 2011-05-11 20:16:05 --> Model Class Initialized
DEBUG - 2011-05-11 20:16:05 --> Model Class Initialized
DEBUG - 2011-05-11 20:16:05 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-11 20:16:05 --> Database Driver Class Initialized
DEBUG - 2011-05-11 20:16:05 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-11 20:16:05 --> Helper loaded: url_helper
DEBUG - 2011-05-11 20:16:05 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-11 20:16:05 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-11 20:16:05 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-11 20:16:05 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-11 20:16:05 --> Final output sent to browser
DEBUG - 2011-05-11 20:16:05 --> Total execution time: 0.2327
DEBUG - 2011-05-11 20:16:06 --> Config Class Initialized
DEBUG - 2011-05-11 20:16:06 --> Hooks Class Initialized
DEBUG - 2011-05-11 20:16:06 --> Utf8 Class Initialized
DEBUG - 2011-05-11 20:16:06 --> UTF-8 Support Enabled
DEBUG - 2011-05-11 20:16:06 --> URI Class Initialized
DEBUG - 2011-05-11 20:16:06 --> Router Class Initialized
DEBUG - 2011-05-11 20:16:06 --> Output Class Initialized
DEBUG - 2011-05-11 20:16:06 --> Input Class Initialized
DEBUG - 2011-05-11 20:16:06 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-11 20:16:06 --> Language Class Initialized
DEBUG - 2011-05-11 20:16:06 --> Loader Class Initialized
DEBUG - 2011-05-11 20:16:06 --> Controller Class Initialized
DEBUG - 2011-05-11 20:16:06 --> Model Class Initialized
DEBUG - 2011-05-11 20:16:06 --> Model Class Initialized
DEBUG - 2011-05-11 20:16:06 --> Model Class Initialized
DEBUG - 2011-05-11 20:16:06 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-11 20:16:06 --> Database Driver Class Initialized
DEBUG - 2011-05-11 20:16:07 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-11 20:16:07 --> Helper loaded: url_helper
DEBUG - 2011-05-11 20:16:07 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-11 20:16:07 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-11 20:16:07 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-11 20:16:07 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-11 20:16:07 --> Final output sent to browser
DEBUG - 2011-05-11 20:16:07 --> Total execution time: 0.1113
DEBUG - 2011-05-11 20:16:20 --> Config Class Initialized
DEBUG - 2011-05-11 20:16:20 --> Hooks Class Initialized
DEBUG - 2011-05-11 20:16:20 --> Utf8 Class Initialized
DEBUG - 2011-05-11 20:16:20 --> UTF-8 Support Enabled
DEBUG - 2011-05-11 20:16:20 --> URI Class Initialized
DEBUG - 2011-05-11 20:16:20 --> Router Class Initialized
DEBUG - 2011-05-11 20:16:20 --> Output Class Initialized
DEBUG - 2011-05-11 20:16:20 --> Input Class Initialized
DEBUG - 2011-05-11 20:16:20 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-11 20:16:20 --> Language Class Initialized
DEBUG - 2011-05-11 20:16:20 --> Loader Class Initialized
DEBUG - 2011-05-11 20:16:20 --> Controller Class Initialized
DEBUG - 2011-05-11 20:16:20 --> Model Class Initialized
DEBUG - 2011-05-11 20:16:20 --> Model Class Initialized
DEBUG - 2011-05-11 20:16:20 --> Model Class Initialized
DEBUG - 2011-05-11 20:16:20 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-11 20:16:20 --> Database Driver Class Initialized
DEBUG - 2011-05-11 20:16:20 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-11 20:16:20 --> Helper loaded: url_helper
DEBUG - 2011-05-11 20:16:20 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-11 20:16:20 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-11 20:16:20 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-11 20:16:20 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-11 20:16:20 --> Final output sent to browser
DEBUG - 2011-05-11 20:16:20 --> Total execution time: 0.3600
DEBUG - 2011-05-11 20:16:36 --> Config Class Initialized
DEBUG - 2011-05-11 20:16:36 --> Hooks Class Initialized
DEBUG - 2011-05-11 20:16:36 --> Utf8 Class Initialized
DEBUG - 2011-05-11 20:16:36 --> UTF-8 Support Enabled
DEBUG - 2011-05-11 20:16:36 --> URI Class Initialized
DEBUG - 2011-05-11 20:16:36 --> Router Class Initialized
DEBUG - 2011-05-11 20:16:36 --> Output Class Initialized
DEBUG - 2011-05-11 20:16:36 --> Input Class Initialized
DEBUG - 2011-05-11 20:16:36 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-11 20:16:36 --> Language Class Initialized
DEBUG - 2011-05-11 20:16:36 --> Loader Class Initialized
DEBUG - 2011-05-11 20:16:36 --> Controller Class Initialized
DEBUG - 2011-05-11 20:16:36 --> Model Class Initialized
DEBUG - 2011-05-11 20:16:36 --> Model Class Initialized
DEBUG - 2011-05-11 20:16:36 --> Model Class Initialized
DEBUG - 2011-05-11 20:16:36 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-11 20:16:36 --> Database Driver Class Initialized
DEBUG - 2011-05-11 20:16:37 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-11 20:16:37 --> Helper loaded: url_helper
DEBUG - 2011-05-11 20:16:37 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-11 20:16:37 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-11 20:16:37 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-11 20:16:37 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-11 20:16:37 --> Final output sent to browser
DEBUG - 2011-05-11 20:16:37 --> Total execution time: 0.4500
DEBUG - 2011-05-11 20:16:38 --> Config Class Initialized
DEBUG - 2011-05-11 20:16:38 --> Hooks Class Initialized
DEBUG - 2011-05-11 20:16:38 --> Utf8 Class Initialized
DEBUG - 2011-05-11 20:16:38 --> UTF-8 Support Enabled
DEBUG - 2011-05-11 20:16:38 --> URI Class Initialized
DEBUG - 2011-05-11 20:16:38 --> Router Class Initialized
DEBUG - 2011-05-11 20:16:38 --> Output Class Initialized
DEBUG - 2011-05-11 20:16:38 --> Input Class Initialized
DEBUG - 2011-05-11 20:16:38 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-11 20:16:38 --> Language Class Initialized
DEBUG - 2011-05-11 20:16:38 --> Loader Class Initialized
DEBUG - 2011-05-11 20:16:38 --> Controller Class Initialized
DEBUG - 2011-05-11 20:16:38 --> Model Class Initialized
DEBUG - 2011-05-11 20:16:38 --> Model Class Initialized
DEBUG - 2011-05-11 20:16:38 --> Model Class Initialized
DEBUG - 2011-05-11 20:16:38 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-11 20:16:38 --> Database Driver Class Initialized
DEBUG - 2011-05-11 20:16:38 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-11 20:16:38 --> Helper loaded: url_helper
DEBUG - 2011-05-11 20:16:38 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-11 20:16:38 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-11 20:16:38 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-11 20:16:38 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-11 20:16:38 --> Final output sent to browser
DEBUG - 2011-05-11 20:16:38 --> Total execution time: 0.2107
DEBUG - 2011-05-11 20:16:56 --> Config Class Initialized
DEBUG - 2011-05-11 20:16:56 --> Hooks Class Initialized
DEBUG - 2011-05-11 20:16:56 --> Utf8 Class Initialized
DEBUG - 2011-05-11 20:16:56 --> UTF-8 Support Enabled
DEBUG - 2011-05-11 20:16:56 --> URI Class Initialized
DEBUG - 2011-05-11 20:16:56 --> Router Class Initialized
DEBUG - 2011-05-11 20:16:56 --> Output Class Initialized
DEBUG - 2011-05-11 20:16:56 --> Input Class Initialized
DEBUG - 2011-05-11 20:16:56 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-11 20:16:56 --> Language Class Initialized
DEBUG - 2011-05-11 20:16:56 --> Loader Class Initialized
DEBUG - 2011-05-11 20:16:56 --> Controller Class Initialized
DEBUG - 2011-05-11 20:16:56 --> Model Class Initialized
DEBUG - 2011-05-11 20:16:56 --> Model Class Initialized
DEBUG - 2011-05-11 20:16:56 --> Model Class Initialized
DEBUG - 2011-05-11 20:16:56 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-11 20:16:56 --> Database Driver Class Initialized
DEBUG - 2011-05-11 20:16:56 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-11 20:16:56 --> Helper loaded: url_helper
DEBUG - 2011-05-11 20:16:56 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-11 20:16:56 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-11 20:16:56 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-11 20:16:56 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-11 20:16:56 --> Final output sent to browser
DEBUG - 2011-05-11 20:16:56 --> Total execution time: 0.2443
DEBUG - 2011-05-11 20:16:57 --> Config Class Initialized
DEBUG - 2011-05-11 20:16:57 --> Hooks Class Initialized
DEBUG - 2011-05-11 20:16:57 --> Utf8 Class Initialized
DEBUG - 2011-05-11 20:16:57 --> UTF-8 Support Enabled
DEBUG - 2011-05-11 20:16:57 --> URI Class Initialized
DEBUG - 2011-05-11 20:16:57 --> Router Class Initialized
DEBUG - 2011-05-11 20:16:57 --> Output Class Initialized
DEBUG - 2011-05-11 20:16:57 --> Input Class Initialized
DEBUG - 2011-05-11 20:16:57 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-11 20:16:57 --> Language Class Initialized
DEBUG - 2011-05-11 20:16:57 --> Loader Class Initialized
DEBUG - 2011-05-11 20:16:57 --> Controller Class Initialized
DEBUG - 2011-05-11 20:16:57 --> Model Class Initialized
DEBUG - 2011-05-11 20:16:57 --> Model Class Initialized
DEBUG - 2011-05-11 20:16:57 --> Model Class Initialized
DEBUG - 2011-05-11 20:16:57 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-11 20:16:57 --> Database Driver Class Initialized
DEBUG - 2011-05-11 20:16:57 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-11 20:16:57 --> Helper loaded: url_helper
DEBUG - 2011-05-11 20:16:57 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-11 20:16:57 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-11 20:16:57 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-11 20:16:57 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-11 20:16:57 --> Final output sent to browser
DEBUG - 2011-05-11 20:16:57 --> Total execution time: 0.0554
DEBUG - 2011-05-11 20:17:05 --> Config Class Initialized
DEBUG - 2011-05-11 20:17:05 --> Hooks Class Initialized
DEBUG - 2011-05-11 20:17:05 --> Utf8 Class Initialized
DEBUG - 2011-05-11 20:17:05 --> UTF-8 Support Enabled
DEBUG - 2011-05-11 20:17:05 --> URI Class Initialized
DEBUG - 2011-05-11 20:17:05 --> Router Class Initialized
DEBUG - 2011-05-11 20:17:05 --> Output Class Initialized
DEBUG - 2011-05-11 20:17:05 --> Input Class Initialized
DEBUG - 2011-05-11 20:17:05 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-11 20:17:05 --> Language Class Initialized
DEBUG - 2011-05-11 20:17:05 --> Loader Class Initialized
DEBUG - 2011-05-11 20:17:05 --> Controller Class Initialized
DEBUG - 2011-05-11 20:17:05 --> Model Class Initialized
DEBUG - 2011-05-11 20:17:05 --> Model Class Initialized
DEBUG - 2011-05-11 20:17:05 --> Model Class Initialized
DEBUG - 2011-05-11 20:17:05 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-11 20:17:05 --> Database Driver Class Initialized
DEBUG - 2011-05-11 20:17:05 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-11 20:17:05 --> Helper loaded: url_helper
DEBUG - 2011-05-11 20:17:05 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-11 20:17:05 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-11 20:17:05 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-11 20:17:05 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-11 20:17:05 --> Final output sent to browser
DEBUG - 2011-05-11 20:17:05 --> Total execution time: 0.2169
DEBUG - 2011-05-11 20:17:08 --> Config Class Initialized
DEBUG - 2011-05-11 20:17:08 --> Hooks Class Initialized
DEBUG - 2011-05-11 20:17:08 --> Utf8 Class Initialized
DEBUG - 2011-05-11 20:17:08 --> UTF-8 Support Enabled
DEBUG - 2011-05-11 20:17:08 --> URI Class Initialized
DEBUG - 2011-05-11 20:17:08 --> Router Class Initialized
DEBUG - 2011-05-11 20:17:08 --> Output Class Initialized
DEBUG - 2011-05-11 20:17:08 --> Input Class Initialized
DEBUG - 2011-05-11 20:17:08 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-11 20:17:08 --> Language Class Initialized
DEBUG - 2011-05-11 20:17:08 --> Loader Class Initialized
DEBUG - 2011-05-11 20:17:08 --> Controller Class Initialized
DEBUG - 2011-05-11 20:17:08 --> Model Class Initialized
DEBUG - 2011-05-11 20:17:08 --> Model Class Initialized
DEBUG - 2011-05-11 20:17:08 --> Model Class Initialized
DEBUG - 2011-05-11 20:17:08 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-11 20:17:08 --> Database Driver Class Initialized
DEBUG - 2011-05-11 20:17:08 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-11 20:17:08 --> Helper loaded: url_helper
DEBUG - 2011-05-11 20:17:08 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-11 20:17:08 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-11 20:17:08 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-11 20:17:08 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-11 20:17:08 --> Final output sent to browser
DEBUG - 2011-05-11 20:17:08 --> Total execution time: 0.0515
DEBUG - 2011-05-11 22:19:42 --> Config Class Initialized
DEBUG - 2011-05-11 22:19:42 --> Hooks Class Initialized
DEBUG - 2011-05-11 22:19:42 --> Utf8 Class Initialized
DEBUG - 2011-05-11 22:19:42 --> UTF-8 Support Enabled
DEBUG - 2011-05-11 22:19:42 --> URI Class Initialized
DEBUG - 2011-05-11 22:19:42 --> Router Class Initialized
DEBUG - 2011-05-11 22:19:42 --> No URI present. Default controller set.
DEBUG - 2011-05-11 22:19:42 --> Output Class Initialized
DEBUG - 2011-05-11 22:19:42 --> Input Class Initialized
DEBUG - 2011-05-11 22:19:42 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-11 22:19:42 --> Language Class Initialized
DEBUG - 2011-05-11 22:19:42 --> Loader Class Initialized
DEBUG - 2011-05-11 22:19:42 --> Controller Class Initialized
DEBUG - 2011-05-11 22:19:42 --> File loaded: application/views/splash/main.php
DEBUG - 2011-05-11 22:19:42 --> Helper loaded: url_helper
DEBUG - 2011-05-11 22:19:42 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-11 22:19:42 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-11 22:19:42 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-11 22:19:42 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-11 22:19:42 --> Final output sent to browser
DEBUG - 2011-05-11 22:19:42 --> Total execution time: 0.2906
DEBUG - 2011-05-11 22:42:39 --> Config Class Initialized
DEBUG - 2011-05-11 22:42:39 --> Hooks Class Initialized
DEBUG - 2011-05-11 22:42:39 --> Utf8 Class Initialized
DEBUG - 2011-05-11 22:42:39 --> UTF-8 Support Enabled
DEBUG - 2011-05-11 22:42:39 --> URI Class Initialized
DEBUG - 2011-05-11 22:42:39 --> Router Class Initialized
DEBUG - 2011-05-11 22:42:39 --> No URI present. Default controller set.
DEBUG - 2011-05-11 22:42:39 --> Output Class Initialized
DEBUG - 2011-05-11 22:42:39 --> Input Class Initialized
DEBUG - 2011-05-11 22:42:39 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-11 22:42:39 --> Language Class Initialized
DEBUG - 2011-05-11 22:42:39 --> Loader Class Initialized
DEBUG - 2011-05-11 22:42:39 --> Controller Class Initialized
DEBUG - 2011-05-11 22:42:39 --> File loaded: application/views/splash/main.php
DEBUG - 2011-05-11 22:42:39 --> Helper loaded: url_helper
DEBUG - 2011-05-11 22:42:39 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-11 22:42:39 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-11 22:42:39 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-11 22:42:39 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-11 22:42:39 --> Final output sent to browser
DEBUG - 2011-05-11 22:42:39 --> Total execution time: 0.6233
DEBUG - 2011-05-11 22:42:41 --> Config Class Initialized
DEBUG - 2011-05-11 22:42:41 --> Hooks Class Initialized
DEBUG - 2011-05-11 22:42:41 --> Utf8 Class Initialized
DEBUG - 2011-05-11 22:42:41 --> UTF-8 Support Enabled
DEBUG - 2011-05-11 22:42:41 --> URI Class Initialized
DEBUG - 2011-05-11 22:42:41 --> Router Class Initialized
ERROR - 2011-05-11 22:42:41 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-11 23:36:17 --> Config Class Initialized
DEBUG - 2011-05-11 23:36:17 --> Hooks Class Initialized
DEBUG - 2011-05-11 23:36:17 --> Utf8 Class Initialized
DEBUG - 2011-05-11 23:36:17 --> UTF-8 Support Enabled
DEBUG - 2011-05-11 23:36:17 --> URI Class Initialized
DEBUG - 2011-05-11 23:36:17 --> Router Class Initialized
ERROR - 2011-05-11 23:36:17 --> 404 Page Not Found --> robots.txt

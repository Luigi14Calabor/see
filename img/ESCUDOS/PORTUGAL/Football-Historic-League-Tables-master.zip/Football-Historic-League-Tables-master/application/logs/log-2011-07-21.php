<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2011-07-21 03:00:33 --> Config Class Initialized
DEBUG - 2011-07-21 03:00:33 --> Hooks Class Initialized
DEBUG - 2011-07-21 03:00:33 --> Utf8 Class Initialized
DEBUG - 2011-07-21 03:00:33 --> UTF-8 Support Enabled
DEBUG - 2011-07-21 03:00:33 --> URI Class Initialized
DEBUG - 2011-07-21 03:00:33 --> Router Class Initialized
ERROR - 2011-07-21 03:00:33 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-07-21 03:01:29 --> Config Class Initialized
DEBUG - 2011-07-21 03:01:29 --> Hooks Class Initialized
DEBUG - 2011-07-21 03:01:29 --> Utf8 Class Initialized
DEBUG - 2011-07-21 03:01:29 --> UTF-8 Support Enabled
DEBUG - 2011-07-21 03:01:29 --> URI Class Initialized
DEBUG - 2011-07-21 03:01:29 --> Router Class Initialized
DEBUG - 2011-07-21 03:01:29 --> Output Class Initialized
DEBUG - 2011-07-21 03:01:29 --> Input Class Initialized
DEBUG - 2011-07-21 03:01:29 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-21 03:01:29 --> Language Class Initialized
DEBUG - 2011-07-21 03:01:29 --> Loader Class Initialized
DEBUG - 2011-07-21 03:01:29 --> Controller Class Initialized
DEBUG - 2011-07-21 03:01:29 --> Model Class Initialized
DEBUG - 2011-07-21 03:01:29 --> Model Class Initialized
DEBUG - 2011-07-21 03:01:29 --> Model Class Initialized
DEBUG - 2011-07-21 03:01:29 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-21 03:01:29 --> Database Driver Class Initialized
DEBUG - 2011-07-21 03:01:30 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-21 03:01:30 --> Helper loaded: url_helper
DEBUG - 2011-07-21 03:01:30 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-21 03:01:30 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-21 03:01:30 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-21 03:01:30 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-21 03:01:30 --> Final output sent to browser
DEBUG - 2011-07-21 03:01:30 --> Total execution time: 0.7594
DEBUG - 2011-07-21 06:25:30 --> Config Class Initialized
DEBUG - 2011-07-21 06:25:30 --> Hooks Class Initialized
DEBUG - 2011-07-21 06:25:30 --> Utf8 Class Initialized
DEBUG - 2011-07-21 06:25:30 --> UTF-8 Support Enabled
DEBUG - 2011-07-21 06:25:30 --> URI Class Initialized
DEBUG - 2011-07-21 06:25:30 --> Router Class Initialized
ERROR - 2011-07-21 06:25:30 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-07-21 06:25:31 --> Config Class Initialized
DEBUG - 2011-07-21 06:25:31 --> Hooks Class Initialized
DEBUG - 2011-07-21 06:25:31 --> Utf8 Class Initialized
DEBUG - 2011-07-21 06:25:31 --> UTF-8 Support Enabled
DEBUG - 2011-07-21 06:25:31 --> URI Class Initialized
DEBUG - 2011-07-21 06:25:31 --> Router Class Initialized
DEBUG - 2011-07-21 06:25:31 --> Output Class Initialized
DEBUG - 2011-07-21 06:25:31 --> Input Class Initialized
DEBUG - 2011-07-21 06:25:31 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-21 06:25:31 --> Language Class Initialized
DEBUG - 2011-07-21 06:25:31 --> Loader Class Initialized
DEBUG - 2011-07-21 06:25:31 --> Controller Class Initialized
ERROR - 2011-07-21 06:25:31 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-21 06:25:31 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-21 06:25:31 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-21 06:25:31 --> Model Class Initialized
DEBUG - 2011-07-21 06:25:31 --> Model Class Initialized
DEBUG - 2011-07-21 06:25:31 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-21 06:25:31 --> Database Driver Class Initialized
DEBUG - 2011-07-21 06:25:31 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-21 06:25:31 --> Helper loaded: url_helper
DEBUG - 2011-07-21 06:25:31 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-21 06:25:31 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-21 06:25:31 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-21 06:25:31 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-21 06:25:31 --> Final output sent to browser
DEBUG - 2011-07-21 06:25:31 --> Total execution time: 0.3189
DEBUG - 2011-07-21 08:48:16 --> Config Class Initialized
DEBUG - 2011-07-21 08:48:16 --> Hooks Class Initialized
DEBUG - 2011-07-21 08:48:16 --> Utf8 Class Initialized
DEBUG - 2011-07-21 08:48:16 --> UTF-8 Support Enabled
DEBUG - 2011-07-21 08:48:16 --> URI Class Initialized
DEBUG - 2011-07-21 08:48:16 --> Router Class Initialized
DEBUG - 2011-07-21 08:48:16 --> Output Class Initialized
DEBUG - 2011-07-21 08:48:16 --> Input Class Initialized
DEBUG - 2011-07-21 08:48:16 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-21 08:48:16 --> Language Class Initialized
DEBUG - 2011-07-21 08:48:16 --> Loader Class Initialized
DEBUG - 2011-07-21 08:48:16 --> Controller Class Initialized
DEBUG - 2011-07-21 08:48:16 --> Model Class Initialized
DEBUG - 2011-07-21 08:48:16 --> Model Class Initialized
DEBUG - 2011-07-21 08:48:16 --> Model Class Initialized
DEBUG - 2011-07-21 08:48:16 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-21 08:48:16 --> Database Driver Class Initialized
DEBUG - 2011-07-21 08:48:16 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-21 08:48:16 --> Helper loaded: url_helper
DEBUG - 2011-07-21 08:48:16 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-21 08:48:16 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-21 08:48:16 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-21 08:48:16 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-21 08:48:16 --> Final output sent to browser
DEBUG - 2011-07-21 08:48:16 --> Total execution time: 0.6154
DEBUG - 2011-07-21 08:48:22 --> Config Class Initialized
DEBUG - 2011-07-21 08:48:22 --> Hooks Class Initialized
DEBUG - 2011-07-21 08:48:22 --> Utf8 Class Initialized
DEBUG - 2011-07-21 08:48:22 --> UTF-8 Support Enabled
DEBUG - 2011-07-21 08:48:22 --> URI Class Initialized
DEBUG - 2011-07-21 08:48:22 --> Router Class Initialized
ERROR - 2011-07-21 08:48:22 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-21 08:48:23 --> Config Class Initialized
DEBUG - 2011-07-21 08:48:23 --> Hooks Class Initialized
DEBUG - 2011-07-21 08:48:23 --> Utf8 Class Initialized
DEBUG - 2011-07-21 08:48:23 --> UTF-8 Support Enabled
DEBUG - 2011-07-21 08:48:23 --> URI Class Initialized
DEBUG - 2011-07-21 08:48:23 --> Router Class Initialized
ERROR - 2011-07-21 08:48:23 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-21 08:48:23 --> Config Class Initialized
DEBUG - 2011-07-21 08:48:23 --> Hooks Class Initialized
DEBUG - 2011-07-21 08:48:23 --> Utf8 Class Initialized
DEBUG - 2011-07-21 08:48:23 --> UTF-8 Support Enabled
DEBUG - 2011-07-21 08:48:23 --> URI Class Initialized
DEBUG - 2011-07-21 08:48:23 --> Router Class Initialized
ERROR - 2011-07-21 08:48:23 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-21 08:48:42 --> Config Class Initialized
DEBUG - 2011-07-21 08:48:42 --> Hooks Class Initialized
DEBUG - 2011-07-21 08:48:42 --> Utf8 Class Initialized
DEBUG - 2011-07-21 08:48:42 --> UTF-8 Support Enabled
DEBUG - 2011-07-21 08:48:42 --> URI Class Initialized
DEBUG - 2011-07-21 08:48:42 --> Router Class Initialized
DEBUG - 2011-07-21 08:48:42 --> Output Class Initialized
DEBUG - 2011-07-21 08:48:42 --> Input Class Initialized
DEBUG - 2011-07-21 08:48:42 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-21 08:48:42 --> Language Class Initialized
DEBUG - 2011-07-21 08:48:42 --> Loader Class Initialized
DEBUG - 2011-07-21 08:48:42 --> Controller Class Initialized
DEBUG - 2011-07-21 08:48:42 --> Model Class Initialized
DEBUG - 2011-07-21 08:48:42 --> Model Class Initialized
DEBUG - 2011-07-21 08:48:42 --> Model Class Initialized
DEBUG - 2011-07-21 08:48:42 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-21 08:48:42 --> Database Driver Class Initialized
DEBUG - 2011-07-21 08:48:43 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-21 08:48:43 --> Helper loaded: url_helper
DEBUG - 2011-07-21 08:48:43 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-21 08:48:43 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-21 08:48:43 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-21 08:48:43 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-21 08:48:43 --> Final output sent to browser
DEBUG - 2011-07-21 08:48:43 --> Total execution time: 0.9578
DEBUG - 2011-07-21 08:48:54 --> Config Class Initialized
DEBUG - 2011-07-21 08:48:54 --> Hooks Class Initialized
DEBUG - 2011-07-21 08:48:54 --> Utf8 Class Initialized
DEBUG - 2011-07-21 08:48:54 --> UTF-8 Support Enabled
DEBUG - 2011-07-21 08:48:54 --> URI Class Initialized
DEBUG - 2011-07-21 08:48:54 --> Router Class Initialized
DEBUG - 2011-07-21 08:48:54 --> Output Class Initialized
DEBUG - 2011-07-21 08:48:54 --> Input Class Initialized
DEBUG - 2011-07-21 08:48:54 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-21 08:48:54 --> Language Class Initialized
DEBUG - 2011-07-21 08:48:54 --> Loader Class Initialized
DEBUG - 2011-07-21 08:48:54 --> Controller Class Initialized
DEBUG - 2011-07-21 08:48:54 --> Model Class Initialized
DEBUG - 2011-07-21 08:48:54 --> Model Class Initialized
DEBUG - 2011-07-21 08:48:54 --> Model Class Initialized
DEBUG - 2011-07-21 08:48:54 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-21 08:48:54 --> Database Driver Class Initialized
DEBUG - 2011-07-21 08:48:55 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-21 08:48:55 --> Helper loaded: url_helper
DEBUG - 2011-07-21 08:48:55 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-21 08:48:55 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-21 08:48:55 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-21 08:48:55 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-21 08:48:55 --> Final output sent to browser
DEBUG - 2011-07-21 08:48:55 --> Total execution time: 0.9465
DEBUG - 2011-07-21 08:49:02 --> Config Class Initialized
DEBUG - 2011-07-21 08:49:02 --> Hooks Class Initialized
DEBUG - 2011-07-21 08:49:02 --> Utf8 Class Initialized
DEBUG - 2011-07-21 08:49:02 --> UTF-8 Support Enabled
DEBUG - 2011-07-21 08:49:02 --> URI Class Initialized
DEBUG - 2011-07-21 08:49:02 --> Router Class Initialized
DEBUG - 2011-07-21 08:49:02 --> Output Class Initialized
DEBUG - 2011-07-21 08:49:02 --> Input Class Initialized
DEBUG - 2011-07-21 08:49:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-21 08:49:02 --> Language Class Initialized
DEBUG - 2011-07-21 08:49:02 --> Loader Class Initialized
DEBUG - 2011-07-21 08:49:02 --> Controller Class Initialized
DEBUG - 2011-07-21 08:49:02 --> Model Class Initialized
DEBUG - 2011-07-21 08:49:02 --> Model Class Initialized
DEBUG - 2011-07-21 08:49:02 --> Model Class Initialized
DEBUG - 2011-07-21 08:49:02 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-21 08:49:02 --> Database Driver Class Initialized
DEBUG - 2011-07-21 08:49:03 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-21 08:49:03 --> Helper loaded: url_helper
DEBUG - 2011-07-21 08:49:03 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-21 08:49:03 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-21 08:49:03 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-21 08:49:03 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-21 08:49:03 --> Final output sent to browser
DEBUG - 2011-07-21 08:49:03 --> Total execution time: 0.8210
DEBUG - 2011-07-21 08:49:13 --> Config Class Initialized
DEBUG - 2011-07-21 08:49:13 --> Hooks Class Initialized
DEBUG - 2011-07-21 08:49:13 --> Utf8 Class Initialized
DEBUG - 2011-07-21 08:49:13 --> UTF-8 Support Enabled
DEBUG - 2011-07-21 08:49:13 --> URI Class Initialized
DEBUG - 2011-07-21 08:49:13 --> Router Class Initialized
DEBUG - 2011-07-21 08:49:13 --> Output Class Initialized
DEBUG - 2011-07-21 08:49:13 --> Input Class Initialized
DEBUG - 2011-07-21 08:49:13 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-21 08:49:13 --> Language Class Initialized
DEBUG - 2011-07-21 08:49:13 --> Loader Class Initialized
DEBUG - 2011-07-21 08:49:13 --> Controller Class Initialized
DEBUG - 2011-07-21 08:49:13 --> Model Class Initialized
DEBUG - 2011-07-21 08:49:13 --> Model Class Initialized
DEBUG - 2011-07-21 08:49:13 --> Model Class Initialized
DEBUG - 2011-07-21 08:49:13 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-21 08:49:13 --> Database Driver Class Initialized
DEBUG - 2011-07-21 08:49:13 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-21 08:49:13 --> Helper loaded: url_helper
DEBUG - 2011-07-21 08:49:13 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-21 08:49:13 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-21 08:49:13 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-21 08:49:13 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-21 08:49:13 --> Final output sent to browser
DEBUG - 2011-07-21 08:49:13 --> Total execution time: 0.6477
DEBUG - 2011-07-21 08:49:26 --> Config Class Initialized
DEBUG - 2011-07-21 08:49:26 --> Hooks Class Initialized
DEBUG - 2011-07-21 08:49:26 --> Utf8 Class Initialized
DEBUG - 2011-07-21 08:49:26 --> UTF-8 Support Enabled
DEBUG - 2011-07-21 08:49:26 --> URI Class Initialized
DEBUG - 2011-07-21 08:49:26 --> Router Class Initialized
DEBUG - 2011-07-21 08:49:26 --> Output Class Initialized
DEBUG - 2011-07-21 08:49:26 --> Input Class Initialized
DEBUG - 2011-07-21 08:49:26 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-21 08:49:26 --> Language Class Initialized
DEBUG - 2011-07-21 08:49:26 --> Loader Class Initialized
DEBUG - 2011-07-21 08:49:26 --> Controller Class Initialized
DEBUG - 2011-07-21 08:49:26 --> Model Class Initialized
DEBUG - 2011-07-21 08:49:26 --> Model Class Initialized
DEBUG - 2011-07-21 08:49:26 --> Model Class Initialized
DEBUG - 2011-07-21 08:49:26 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-21 08:49:26 --> Database Driver Class Initialized
DEBUG - 2011-07-21 08:49:26 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-21 08:49:26 --> Helper loaded: url_helper
DEBUG - 2011-07-21 08:49:26 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-21 08:49:26 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-21 08:49:26 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-21 08:49:26 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-21 08:49:26 --> Final output sent to browser
DEBUG - 2011-07-21 08:49:26 --> Total execution time: 0.2285
DEBUG - 2011-07-21 08:49:43 --> Config Class Initialized
DEBUG - 2011-07-21 08:49:43 --> Hooks Class Initialized
DEBUG - 2011-07-21 08:49:43 --> Utf8 Class Initialized
DEBUG - 2011-07-21 08:49:43 --> UTF-8 Support Enabled
DEBUG - 2011-07-21 08:49:43 --> URI Class Initialized
DEBUG - 2011-07-21 08:49:43 --> Router Class Initialized
DEBUG - 2011-07-21 08:49:43 --> Output Class Initialized
DEBUG - 2011-07-21 08:49:43 --> Input Class Initialized
DEBUG - 2011-07-21 08:49:43 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-21 08:49:43 --> Language Class Initialized
DEBUG - 2011-07-21 08:49:43 --> Loader Class Initialized
DEBUG - 2011-07-21 08:49:43 --> Controller Class Initialized
DEBUG - 2011-07-21 08:49:43 --> Model Class Initialized
DEBUG - 2011-07-21 08:49:43 --> Model Class Initialized
DEBUG - 2011-07-21 08:49:43 --> Model Class Initialized
DEBUG - 2011-07-21 08:49:43 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-21 08:49:43 --> Database Driver Class Initialized
DEBUG - 2011-07-21 08:49:43 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-21 08:49:43 --> Helper loaded: url_helper
DEBUG - 2011-07-21 08:49:43 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-21 08:49:43 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-21 08:49:43 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-21 08:49:43 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-21 08:49:43 --> Final output sent to browser
DEBUG - 2011-07-21 08:49:43 --> Total execution time: 0.4864
DEBUG - 2011-07-21 08:49:58 --> Config Class Initialized
DEBUG - 2011-07-21 08:49:58 --> Hooks Class Initialized
DEBUG - 2011-07-21 08:49:58 --> Utf8 Class Initialized
DEBUG - 2011-07-21 08:49:58 --> UTF-8 Support Enabled
DEBUG - 2011-07-21 08:49:58 --> URI Class Initialized
DEBUG - 2011-07-21 08:49:58 --> Router Class Initialized
DEBUG - 2011-07-21 08:49:58 --> Output Class Initialized
DEBUG - 2011-07-21 08:49:58 --> Input Class Initialized
DEBUG - 2011-07-21 08:49:58 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-21 08:49:58 --> Language Class Initialized
DEBUG - 2011-07-21 08:49:58 --> Loader Class Initialized
DEBUG - 2011-07-21 08:49:58 --> Controller Class Initialized
DEBUG - 2011-07-21 08:49:58 --> Model Class Initialized
DEBUG - 2011-07-21 08:49:58 --> Model Class Initialized
DEBUG - 2011-07-21 08:49:58 --> Model Class Initialized
DEBUG - 2011-07-21 08:49:58 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-21 08:49:58 --> Database Driver Class Initialized
DEBUG - 2011-07-21 08:49:59 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-21 08:49:59 --> Helper loaded: url_helper
DEBUG - 2011-07-21 08:49:59 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-21 08:49:59 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-21 08:49:59 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-21 08:49:59 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-21 08:49:59 --> Final output sent to browser
DEBUG - 2011-07-21 08:49:59 --> Total execution time: 0.4278
DEBUG - 2011-07-21 08:50:15 --> Config Class Initialized
DEBUG - 2011-07-21 08:50:15 --> Hooks Class Initialized
DEBUG - 2011-07-21 08:50:15 --> Utf8 Class Initialized
DEBUG - 2011-07-21 08:50:15 --> UTF-8 Support Enabled
DEBUG - 2011-07-21 08:50:15 --> URI Class Initialized
DEBUG - 2011-07-21 08:50:15 --> Router Class Initialized
DEBUG - 2011-07-21 08:50:15 --> Output Class Initialized
DEBUG - 2011-07-21 08:50:15 --> Input Class Initialized
DEBUG - 2011-07-21 08:50:15 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-21 08:50:15 --> Language Class Initialized
DEBUG - 2011-07-21 08:50:15 --> Loader Class Initialized
DEBUG - 2011-07-21 08:50:15 --> Controller Class Initialized
DEBUG - 2011-07-21 08:50:15 --> Model Class Initialized
DEBUG - 2011-07-21 08:50:15 --> Model Class Initialized
DEBUG - 2011-07-21 08:50:15 --> Model Class Initialized
DEBUG - 2011-07-21 08:50:15 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-21 08:50:15 --> Database Driver Class Initialized
DEBUG - 2011-07-21 08:50:15 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-21 08:50:15 --> Helper loaded: url_helper
DEBUG - 2011-07-21 08:50:15 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-21 08:50:15 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-21 08:50:15 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-21 08:50:15 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-21 08:50:15 --> Final output sent to browser
DEBUG - 2011-07-21 08:50:15 --> Total execution time: 0.2590
DEBUG - 2011-07-21 08:50:27 --> Config Class Initialized
DEBUG - 2011-07-21 08:50:27 --> Hooks Class Initialized
DEBUG - 2011-07-21 08:50:27 --> Utf8 Class Initialized
DEBUG - 2011-07-21 08:50:27 --> UTF-8 Support Enabled
DEBUG - 2011-07-21 08:50:27 --> URI Class Initialized
DEBUG - 2011-07-21 08:50:27 --> Router Class Initialized
DEBUG - 2011-07-21 08:50:27 --> Output Class Initialized
DEBUG - 2011-07-21 08:50:27 --> Input Class Initialized
DEBUG - 2011-07-21 08:50:27 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-21 08:50:27 --> Language Class Initialized
DEBUG - 2011-07-21 08:50:27 --> Loader Class Initialized
DEBUG - 2011-07-21 08:50:27 --> Controller Class Initialized
DEBUG - 2011-07-21 08:50:27 --> Model Class Initialized
DEBUG - 2011-07-21 08:50:27 --> Model Class Initialized
DEBUG - 2011-07-21 08:50:27 --> Model Class Initialized
DEBUG - 2011-07-21 08:50:27 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-21 08:50:27 --> Database Driver Class Initialized
DEBUG - 2011-07-21 08:50:27 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-21 08:50:27 --> Helper loaded: url_helper
DEBUG - 2011-07-21 08:50:27 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-21 08:50:27 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-21 08:50:27 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-21 08:50:27 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-21 08:50:27 --> Final output sent to browser
DEBUG - 2011-07-21 08:50:27 --> Total execution time: 0.4810
DEBUG - 2011-07-21 08:50:45 --> Config Class Initialized
DEBUG - 2011-07-21 08:50:45 --> Hooks Class Initialized
DEBUG - 2011-07-21 08:50:45 --> Utf8 Class Initialized
DEBUG - 2011-07-21 08:50:45 --> UTF-8 Support Enabled
DEBUG - 2011-07-21 08:50:45 --> URI Class Initialized
DEBUG - 2011-07-21 08:50:45 --> Router Class Initialized
DEBUG - 2011-07-21 08:50:45 --> Output Class Initialized
DEBUG - 2011-07-21 08:50:45 --> Input Class Initialized
DEBUG - 2011-07-21 08:50:45 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-21 08:50:45 --> Language Class Initialized
DEBUG - 2011-07-21 08:50:45 --> Loader Class Initialized
DEBUG - 2011-07-21 08:50:45 --> Controller Class Initialized
DEBUG - 2011-07-21 08:50:45 --> Model Class Initialized
DEBUG - 2011-07-21 08:50:45 --> Model Class Initialized
DEBUG - 2011-07-21 08:50:45 --> Model Class Initialized
DEBUG - 2011-07-21 08:50:45 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-21 08:50:45 --> Database Driver Class Initialized
DEBUG - 2011-07-21 08:50:46 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-21 08:50:46 --> Helper loaded: url_helper
DEBUG - 2011-07-21 08:50:46 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-21 08:50:46 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-21 08:50:46 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-21 08:50:46 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-21 08:50:46 --> Final output sent to browser
DEBUG - 2011-07-21 08:50:46 --> Total execution time: 1.1780
DEBUG - 2011-07-21 08:50:54 --> Config Class Initialized
DEBUG - 2011-07-21 08:50:54 --> Hooks Class Initialized
DEBUG - 2011-07-21 08:50:54 --> Utf8 Class Initialized
DEBUG - 2011-07-21 08:50:54 --> UTF-8 Support Enabled
DEBUG - 2011-07-21 08:50:54 --> URI Class Initialized
DEBUG - 2011-07-21 08:50:54 --> Router Class Initialized
DEBUG - 2011-07-21 08:50:54 --> Output Class Initialized
DEBUG - 2011-07-21 08:50:54 --> Input Class Initialized
DEBUG - 2011-07-21 08:50:54 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-21 08:50:54 --> Language Class Initialized
DEBUG - 2011-07-21 08:50:54 --> Loader Class Initialized
DEBUG - 2011-07-21 08:50:54 --> Controller Class Initialized
DEBUG - 2011-07-21 08:50:54 --> Model Class Initialized
DEBUG - 2011-07-21 08:50:54 --> Model Class Initialized
DEBUG - 2011-07-21 08:50:54 --> Model Class Initialized
DEBUG - 2011-07-21 08:50:54 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-21 08:50:54 --> Database Driver Class Initialized
DEBUG - 2011-07-21 08:50:54 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-21 08:50:54 --> Helper loaded: url_helper
DEBUG - 2011-07-21 08:50:54 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-21 08:50:54 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-21 08:50:54 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-21 08:50:54 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-21 08:50:54 --> Final output sent to browser
DEBUG - 2011-07-21 08:50:54 --> Total execution time: 0.3404
DEBUG - 2011-07-21 10:57:28 --> Config Class Initialized
DEBUG - 2011-07-21 10:57:28 --> Hooks Class Initialized
DEBUG - 2011-07-21 10:57:28 --> Utf8 Class Initialized
DEBUG - 2011-07-21 10:57:28 --> UTF-8 Support Enabled
DEBUG - 2011-07-21 10:57:28 --> URI Class Initialized
DEBUG - 2011-07-21 10:57:28 --> Router Class Initialized
DEBUG - 2011-07-21 10:57:28 --> No URI present. Default controller set.
DEBUG - 2011-07-21 10:57:28 --> Output Class Initialized
DEBUG - 2011-07-21 10:57:28 --> Input Class Initialized
DEBUG - 2011-07-21 10:57:28 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-21 10:57:28 --> Language Class Initialized
DEBUG - 2011-07-21 10:57:28 --> Loader Class Initialized
DEBUG - 2011-07-21 10:57:28 --> Controller Class Initialized
DEBUG - 2011-07-21 10:57:28 --> File loaded: application/views/splash/main.php
DEBUG - 2011-07-21 10:57:28 --> Helper loaded: url_helper
DEBUG - 2011-07-21 10:57:28 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-21 10:57:28 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-21 10:57:28 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-21 10:57:28 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-21 10:57:28 --> Final output sent to browser
DEBUG - 2011-07-21 10:57:28 --> Total execution time: 0.2875
DEBUG - 2011-07-21 11:05:12 --> Config Class Initialized
DEBUG - 2011-07-21 11:05:12 --> Hooks Class Initialized
DEBUG - 2011-07-21 11:05:12 --> Utf8 Class Initialized
DEBUG - 2011-07-21 11:05:12 --> UTF-8 Support Enabled
DEBUG - 2011-07-21 11:05:12 --> URI Class Initialized
DEBUG - 2011-07-21 11:05:12 --> Router Class Initialized
DEBUG - 2011-07-21 11:05:12 --> Output Class Initialized
DEBUG - 2011-07-21 11:05:12 --> Input Class Initialized
DEBUG - 2011-07-21 11:05:12 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-21 11:05:12 --> Language Class Initialized
DEBUG - 2011-07-21 11:05:12 --> Loader Class Initialized
DEBUG - 2011-07-21 11:05:12 --> Controller Class Initialized
ERROR - 2011-07-21 11:05:12 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-21 11:05:12 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-21 11:05:12 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-21 11:05:12 --> Model Class Initialized
DEBUG - 2011-07-21 11:05:12 --> Model Class Initialized
DEBUG - 2011-07-21 11:05:12 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-21 11:05:12 --> Database Driver Class Initialized
DEBUG - 2011-07-21 11:05:12 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-21 11:05:12 --> Helper loaded: url_helper
DEBUG - 2011-07-21 11:05:12 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-21 11:05:12 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-21 11:05:12 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-21 11:05:12 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-21 11:05:12 --> Final output sent to browser
DEBUG - 2011-07-21 11:05:12 --> Total execution time: 0.2753
DEBUG - 2011-07-21 11:06:48 --> Config Class Initialized
DEBUG - 2011-07-21 11:06:48 --> Hooks Class Initialized
DEBUG - 2011-07-21 11:06:48 --> Utf8 Class Initialized
DEBUG - 2011-07-21 11:06:48 --> UTF-8 Support Enabled
DEBUG - 2011-07-21 11:06:48 --> URI Class Initialized
DEBUG - 2011-07-21 11:06:48 --> Router Class Initialized
DEBUG - 2011-07-21 11:06:48 --> Output Class Initialized
DEBUG - 2011-07-21 11:06:48 --> Input Class Initialized
DEBUG - 2011-07-21 11:06:48 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-21 11:06:48 --> Language Class Initialized
DEBUG - 2011-07-21 11:06:48 --> Loader Class Initialized
DEBUG - 2011-07-21 11:06:48 --> Controller Class Initialized
DEBUG - 2011-07-21 11:06:48 --> Model Class Initialized
DEBUG - 2011-07-21 11:06:48 --> Model Class Initialized
DEBUG - 2011-07-21 11:06:48 --> Model Class Initialized
DEBUG - 2011-07-21 11:06:48 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-21 11:06:48 --> Database Driver Class Initialized
DEBUG - 2011-07-21 11:06:49 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-21 11:06:49 --> Helper loaded: url_helper
DEBUG - 2011-07-21 11:06:49 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-21 11:06:49 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-21 11:06:49 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-21 11:06:49 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-21 11:06:49 --> Final output sent to browser
DEBUG - 2011-07-21 11:06:49 --> Total execution time: 1.4868
DEBUG - 2011-07-21 11:52:35 --> Config Class Initialized
DEBUG - 2011-07-21 11:52:35 --> Hooks Class Initialized
DEBUG - 2011-07-21 11:52:35 --> Utf8 Class Initialized
DEBUG - 2011-07-21 11:52:35 --> UTF-8 Support Enabled
DEBUG - 2011-07-21 11:52:35 --> URI Class Initialized
DEBUG - 2011-07-21 11:52:35 --> Router Class Initialized
DEBUG - 2011-07-21 11:52:35 --> Output Class Initialized
DEBUG - 2011-07-21 11:52:35 --> Input Class Initialized
DEBUG - 2011-07-21 11:52:35 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-21 11:52:35 --> Language Class Initialized
DEBUG - 2011-07-21 11:52:35 --> Loader Class Initialized
DEBUG - 2011-07-21 11:52:35 --> Controller Class Initialized
DEBUG - 2011-07-21 11:52:35 --> Model Class Initialized
DEBUG - 2011-07-21 11:52:35 --> Model Class Initialized
DEBUG - 2011-07-21 11:52:35 --> Model Class Initialized
DEBUG - 2011-07-21 11:52:35 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-21 11:52:35 --> Database Driver Class Initialized
DEBUG - 2011-07-21 11:52:36 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-21 11:52:36 --> Helper loaded: url_helper
DEBUG - 2011-07-21 11:52:36 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-21 11:52:36 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-21 11:52:36 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-21 11:52:36 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-21 11:52:36 --> Final output sent to browser
DEBUG - 2011-07-21 11:52:36 --> Total execution time: 0.8944
DEBUG - 2011-07-21 11:52:39 --> Config Class Initialized
DEBUG - 2011-07-21 11:52:39 --> Hooks Class Initialized
DEBUG - 2011-07-21 11:52:39 --> Utf8 Class Initialized
DEBUG - 2011-07-21 11:52:39 --> UTF-8 Support Enabled
DEBUG - 2011-07-21 11:52:39 --> URI Class Initialized
DEBUG - 2011-07-21 11:52:39 --> Router Class Initialized
ERROR - 2011-07-21 11:52:39 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-21 13:22:30 --> Config Class Initialized
DEBUG - 2011-07-21 13:22:30 --> Hooks Class Initialized
DEBUG - 2011-07-21 13:22:31 --> Utf8 Class Initialized
DEBUG - 2011-07-21 13:22:31 --> UTF-8 Support Enabled
DEBUG - 2011-07-21 13:22:31 --> URI Class Initialized
DEBUG - 2011-07-21 13:22:31 --> Router Class Initialized
DEBUG - 2011-07-21 13:22:31 --> No URI present. Default controller set.
DEBUG - 2011-07-21 13:22:31 --> Output Class Initialized
DEBUG - 2011-07-21 13:22:31 --> Input Class Initialized
DEBUG - 2011-07-21 13:22:31 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-21 13:22:31 --> Language Class Initialized
DEBUG - 2011-07-21 13:22:31 --> Loader Class Initialized
DEBUG - 2011-07-21 13:22:31 --> Controller Class Initialized
DEBUG - 2011-07-21 13:22:31 --> File loaded: application/views/splash/main.php
DEBUG - 2011-07-21 13:22:31 --> Helper loaded: url_helper
DEBUG - 2011-07-21 13:22:31 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-21 13:22:31 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-21 13:22:31 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-21 13:22:31 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-21 13:22:31 --> Final output sent to browser
DEBUG - 2011-07-21 13:22:31 --> Total execution time: 0.4481
DEBUG - 2011-07-21 13:22:39 --> Config Class Initialized
DEBUG - 2011-07-21 13:22:39 --> Hooks Class Initialized
DEBUG - 2011-07-21 13:22:39 --> Utf8 Class Initialized
DEBUG - 2011-07-21 13:22:39 --> UTF-8 Support Enabled
DEBUG - 2011-07-21 13:22:39 --> URI Class Initialized
DEBUG - 2011-07-21 13:22:39 --> Router Class Initialized
ERROR - 2011-07-21 13:22:39 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-21 13:22:40 --> Config Class Initialized
DEBUG - 2011-07-21 13:22:40 --> Hooks Class Initialized
DEBUG - 2011-07-21 13:22:40 --> Utf8 Class Initialized
DEBUG - 2011-07-21 13:22:40 --> UTF-8 Support Enabled
DEBUG - 2011-07-21 13:22:40 --> URI Class Initialized
DEBUG - 2011-07-21 13:22:40 --> Router Class Initialized
ERROR - 2011-07-21 13:22:40 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-21 13:24:57 --> Config Class Initialized
DEBUG - 2011-07-21 13:24:57 --> Hooks Class Initialized
DEBUG - 2011-07-21 13:24:57 --> Utf8 Class Initialized
DEBUG - 2011-07-21 13:24:57 --> UTF-8 Support Enabled
DEBUG - 2011-07-21 13:24:57 --> URI Class Initialized
DEBUG - 2011-07-21 13:24:57 --> Router Class Initialized
DEBUG - 2011-07-21 13:24:57 --> Output Class Initialized
DEBUG - 2011-07-21 13:24:57 --> Input Class Initialized
DEBUG - 2011-07-21 13:24:57 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-21 13:24:57 --> Language Class Initialized
DEBUG - 2011-07-21 13:24:57 --> Loader Class Initialized
DEBUG - 2011-07-21 13:24:57 --> Controller Class Initialized
DEBUG - 2011-07-21 13:24:57 --> Model Class Initialized
DEBUG - 2011-07-21 13:24:57 --> Model Class Initialized
DEBUG - 2011-07-21 13:24:57 --> Model Class Initialized
DEBUG - 2011-07-21 13:24:57 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-21 13:24:57 --> Database Driver Class Initialized
DEBUG - 2011-07-21 13:24:58 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-21 13:24:58 --> Helper loaded: url_helper
DEBUG - 2011-07-21 13:24:58 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-21 13:24:58 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-21 13:24:58 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-21 13:24:58 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-21 13:24:58 --> Final output sent to browser
DEBUG - 2011-07-21 13:24:58 --> Total execution time: 0.5064
DEBUG - 2011-07-21 13:27:10 --> Config Class Initialized
DEBUG - 2011-07-21 13:27:10 --> Hooks Class Initialized
DEBUG - 2011-07-21 13:27:10 --> Utf8 Class Initialized
DEBUG - 2011-07-21 13:27:10 --> UTF-8 Support Enabled
DEBUG - 2011-07-21 13:27:10 --> URI Class Initialized
DEBUG - 2011-07-21 13:27:10 --> Router Class Initialized
DEBUG - 2011-07-21 13:27:10 --> Output Class Initialized
DEBUG - 2011-07-21 13:27:10 --> Input Class Initialized
DEBUG - 2011-07-21 13:27:10 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-21 13:27:10 --> Language Class Initialized
DEBUG - 2011-07-21 13:27:10 --> Loader Class Initialized
DEBUG - 2011-07-21 13:27:10 --> Controller Class Initialized
DEBUG - 2011-07-21 13:27:10 --> Model Class Initialized
DEBUG - 2011-07-21 13:27:10 --> Model Class Initialized
DEBUG - 2011-07-21 13:27:10 --> Model Class Initialized
DEBUG - 2011-07-21 13:27:10 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-21 13:27:10 --> Database Driver Class Initialized
DEBUG - 2011-07-21 13:27:11 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-21 13:27:11 --> Helper loaded: url_helper
DEBUG - 2011-07-21 13:27:11 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-21 13:27:11 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-21 13:27:11 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-21 13:27:11 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-21 13:27:11 --> Final output sent to browser
DEBUG - 2011-07-21 13:27:11 --> Total execution time: 0.3843
DEBUG - 2011-07-21 13:27:13 --> Config Class Initialized
DEBUG - 2011-07-21 13:27:13 --> Hooks Class Initialized
DEBUG - 2011-07-21 13:27:13 --> Utf8 Class Initialized
DEBUG - 2011-07-21 13:27:13 --> UTF-8 Support Enabled
DEBUG - 2011-07-21 13:27:13 --> URI Class Initialized
DEBUG - 2011-07-21 13:27:13 --> Router Class Initialized
ERROR - 2011-07-21 13:27:13 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-07-21 13:27:13 --> Config Class Initialized
DEBUG - 2011-07-21 13:27:13 --> Hooks Class Initialized
DEBUG - 2011-07-21 13:27:13 --> Utf8 Class Initialized
DEBUG - 2011-07-21 13:27:13 --> UTF-8 Support Enabled
DEBUG - 2011-07-21 13:27:13 --> URI Class Initialized
DEBUG - 2011-07-21 13:27:13 --> Router Class Initialized
DEBUG - 2011-07-21 13:27:13 --> Output Class Initialized
DEBUG - 2011-07-21 13:27:13 --> Input Class Initialized
DEBUG - 2011-07-21 13:27:13 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-21 13:27:13 --> Language Class Initialized
DEBUG - 2011-07-21 13:27:13 --> Loader Class Initialized
DEBUG - 2011-07-21 13:27:13 --> Controller Class Initialized
DEBUG - 2011-07-21 13:27:13 --> Model Class Initialized
DEBUG - 2011-07-21 13:27:13 --> Model Class Initialized
DEBUG - 2011-07-21 13:27:13 --> Model Class Initialized
DEBUG - 2011-07-21 13:27:13 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-21 13:27:13 --> Database Driver Class Initialized
DEBUG - 2011-07-21 13:27:13 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-21 13:27:13 --> Helper loaded: url_helper
DEBUG - 2011-07-21 13:27:13 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-21 13:27:13 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-21 13:27:13 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-21 13:27:13 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-21 13:27:13 --> Final output sent to browser
DEBUG - 2011-07-21 13:27:13 --> Total execution time: 0.1012
DEBUG - 2011-07-21 13:27:34 --> Config Class Initialized
DEBUG - 2011-07-21 13:27:34 --> Hooks Class Initialized
DEBUG - 2011-07-21 13:27:34 --> Utf8 Class Initialized
DEBUG - 2011-07-21 13:27:34 --> UTF-8 Support Enabled
DEBUG - 2011-07-21 13:27:34 --> URI Class Initialized
DEBUG - 2011-07-21 13:27:34 --> Router Class Initialized
DEBUG - 2011-07-21 13:27:34 --> Output Class Initialized
DEBUG - 2011-07-21 13:27:34 --> Input Class Initialized
DEBUG - 2011-07-21 13:27:34 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-21 13:27:34 --> Language Class Initialized
DEBUG - 2011-07-21 13:27:34 --> Loader Class Initialized
DEBUG - 2011-07-21 13:27:34 --> Controller Class Initialized
DEBUG - 2011-07-21 13:27:34 --> Model Class Initialized
DEBUG - 2011-07-21 13:27:34 --> Model Class Initialized
DEBUG - 2011-07-21 13:27:34 --> Model Class Initialized
DEBUG - 2011-07-21 13:27:34 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-21 13:27:34 --> Database Driver Class Initialized
DEBUG - 2011-07-21 13:27:34 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-21 13:27:34 --> Helper loaded: url_helper
DEBUG - 2011-07-21 13:27:34 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-21 13:27:34 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-21 13:27:34 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-21 13:27:34 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-21 13:27:34 --> Final output sent to browser
DEBUG - 2011-07-21 13:27:34 --> Total execution time: 0.7241
DEBUG - 2011-07-21 13:27:37 --> Config Class Initialized
DEBUG - 2011-07-21 13:27:37 --> Hooks Class Initialized
DEBUG - 2011-07-21 13:27:37 --> Utf8 Class Initialized
DEBUG - 2011-07-21 13:27:37 --> UTF-8 Support Enabled
DEBUG - 2011-07-21 13:27:37 --> URI Class Initialized
DEBUG - 2011-07-21 13:27:37 --> Router Class Initialized
DEBUG - 2011-07-21 13:27:37 --> Output Class Initialized
DEBUG - 2011-07-21 13:27:37 --> Input Class Initialized
DEBUG - 2011-07-21 13:27:37 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-21 13:27:37 --> Language Class Initialized
DEBUG - 2011-07-21 13:27:37 --> Loader Class Initialized
DEBUG - 2011-07-21 13:27:37 --> Controller Class Initialized
DEBUG - 2011-07-21 13:27:37 --> Model Class Initialized
DEBUG - 2011-07-21 13:27:37 --> Model Class Initialized
DEBUG - 2011-07-21 13:27:37 --> Model Class Initialized
DEBUG - 2011-07-21 13:27:37 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-21 13:27:37 --> Database Driver Class Initialized
DEBUG - 2011-07-21 13:27:37 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-21 13:27:37 --> Helper loaded: url_helper
DEBUG - 2011-07-21 13:27:37 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-21 13:27:37 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-21 13:27:37 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-21 13:27:37 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-21 13:27:37 --> Final output sent to browser
DEBUG - 2011-07-21 13:27:37 --> Total execution time: 0.0844
DEBUG - 2011-07-21 13:27:49 --> Config Class Initialized
DEBUG - 2011-07-21 13:27:49 --> Hooks Class Initialized
DEBUG - 2011-07-21 13:27:49 --> Utf8 Class Initialized
DEBUG - 2011-07-21 13:27:49 --> UTF-8 Support Enabled
DEBUG - 2011-07-21 13:27:49 --> URI Class Initialized
DEBUG - 2011-07-21 13:27:49 --> Router Class Initialized
DEBUG - 2011-07-21 13:27:49 --> Output Class Initialized
DEBUG - 2011-07-21 13:27:49 --> Input Class Initialized
DEBUG - 2011-07-21 13:27:49 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-21 13:27:49 --> Language Class Initialized
DEBUG - 2011-07-21 13:27:49 --> Loader Class Initialized
DEBUG - 2011-07-21 13:27:49 --> Controller Class Initialized
DEBUG - 2011-07-21 13:27:49 --> Model Class Initialized
DEBUG - 2011-07-21 13:27:49 --> Model Class Initialized
DEBUG - 2011-07-21 13:27:49 --> Model Class Initialized
DEBUG - 2011-07-21 13:27:49 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-21 13:27:49 --> Database Driver Class Initialized
DEBUG - 2011-07-21 13:27:49 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-21 13:27:49 --> Helper loaded: url_helper
DEBUG - 2011-07-21 13:27:49 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-21 13:27:49 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-21 13:27:49 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-21 13:27:49 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-21 13:27:49 --> Final output sent to browser
DEBUG - 2011-07-21 13:27:49 --> Total execution time: 0.3186
DEBUG - 2011-07-21 13:27:58 --> Config Class Initialized
DEBUG - 2011-07-21 13:27:58 --> Hooks Class Initialized
DEBUG - 2011-07-21 13:27:58 --> Utf8 Class Initialized
DEBUG - 2011-07-21 13:27:58 --> UTF-8 Support Enabled
DEBUG - 2011-07-21 13:27:58 --> URI Class Initialized
DEBUG - 2011-07-21 13:27:58 --> Router Class Initialized
DEBUG - 2011-07-21 13:27:58 --> Output Class Initialized
DEBUG - 2011-07-21 13:27:58 --> Input Class Initialized
DEBUG - 2011-07-21 13:27:58 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-21 13:27:58 --> Language Class Initialized
DEBUG - 2011-07-21 13:27:58 --> Loader Class Initialized
DEBUG - 2011-07-21 13:27:58 --> Controller Class Initialized
DEBUG - 2011-07-21 13:27:58 --> Model Class Initialized
DEBUG - 2011-07-21 13:27:58 --> Model Class Initialized
DEBUG - 2011-07-21 13:27:58 --> Model Class Initialized
DEBUG - 2011-07-21 13:27:58 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-21 13:27:58 --> Database Driver Class Initialized
DEBUG - 2011-07-21 13:27:58 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-21 13:27:58 --> Helper loaded: url_helper
DEBUG - 2011-07-21 13:27:58 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-21 13:27:58 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-21 13:27:58 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-21 13:27:58 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-21 13:27:58 --> Final output sent to browser
DEBUG - 2011-07-21 13:27:58 --> Total execution time: 0.1392
DEBUG - 2011-07-21 13:28:17 --> Config Class Initialized
DEBUG - 2011-07-21 13:28:17 --> Hooks Class Initialized
DEBUG - 2011-07-21 13:28:17 --> Utf8 Class Initialized
DEBUG - 2011-07-21 13:28:17 --> UTF-8 Support Enabled
DEBUG - 2011-07-21 13:28:17 --> URI Class Initialized
DEBUG - 2011-07-21 13:28:17 --> Router Class Initialized
DEBUG - 2011-07-21 13:28:17 --> Output Class Initialized
DEBUG - 2011-07-21 13:28:17 --> Input Class Initialized
DEBUG - 2011-07-21 13:28:17 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-21 13:28:17 --> Language Class Initialized
DEBUG - 2011-07-21 13:28:17 --> Loader Class Initialized
DEBUG - 2011-07-21 13:28:17 --> Controller Class Initialized
DEBUG - 2011-07-21 13:28:17 --> Model Class Initialized
DEBUG - 2011-07-21 13:28:17 --> Model Class Initialized
DEBUG - 2011-07-21 13:28:17 --> Model Class Initialized
DEBUG - 2011-07-21 13:28:17 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-21 13:28:17 --> Database Driver Class Initialized
DEBUG - 2011-07-21 13:28:17 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-21 13:28:17 --> Helper loaded: url_helper
DEBUG - 2011-07-21 13:28:17 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-21 13:28:17 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-21 13:28:17 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-21 13:28:17 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-21 13:28:17 --> Final output sent to browser
DEBUG - 2011-07-21 13:28:17 --> Total execution time: 0.3075
DEBUG - 2011-07-21 13:28:21 --> Config Class Initialized
DEBUG - 2011-07-21 13:28:21 --> Hooks Class Initialized
DEBUG - 2011-07-21 13:28:21 --> Utf8 Class Initialized
DEBUG - 2011-07-21 13:28:21 --> UTF-8 Support Enabled
DEBUG - 2011-07-21 13:28:21 --> URI Class Initialized
DEBUG - 2011-07-21 13:28:21 --> Router Class Initialized
DEBUG - 2011-07-21 13:28:21 --> Output Class Initialized
DEBUG - 2011-07-21 13:28:21 --> Input Class Initialized
DEBUG - 2011-07-21 13:28:21 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-21 13:28:21 --> Language Class Initialized
DEBUG - 2011-07-21 13:28:21 --> Loader Class Initialized
DEBUG - 2011-07-21 13:28:21 --> Controller Class Initialized
DEBUG - 2011-07-21 13:28:21 --> Model Class Initialized
DEBUG - 2011-07-21 13:28:21 --> Model Class Initialized
DEBUG - 2011-07-21 13:28:21 --> Model Class Initialized
DEBUG - 2011-07-21 13:28:21 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-21 13:28:21 --> Database Driver Class Initialized
DEBUG - 2011-07-21 13:28:21 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-21 13:28:21 --> Helper loaded: url_helper
DEBUG - 2011-07-21 13:28:21 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-21 13:28:21 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-21 13:28:21 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-21 13:28:21 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-21 13:28:21 --> Final output sent to browser
DEBUG - 2011-07-21 13:28:21 --> Total execution time: 0.0797
DEBUG - 2011-07-21 14:06:07 --> Config Class Initialized
DEBUG - 2011-07-21 14:06:07 --> Hooks Class Initialized
DEBUG - 2011-07-21 14:06:07 --> Utf8 Class Initialized
DEBUG - 2011-07-21 14:06:07 --> UTF-8 Support Enabled
DEBUG - 2011-07-21 14:06:07 --> URI Class Initialized
DEBUG - 2011-07-21 14:06:07 --> Router Class Initialized
DEBUG - 2011-07-21 14:06:07 --> Output Class Initialized
DEBUG - 2011-07-21 14:06:07 --> Input Class Initialized
DEBUG - 2011-07-21 14:06:07 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-21 14:06:07 --> Language Class Initialized
DEBUG - 2011-07-21 14:06:07 --> Loader Class Initialized
DEBUG - 2011-07-21 14:06:07 --> Controller Class Initialized
DEBUG - 2011-07-21 14:06:07 --> Model Class Initialized
DEBUG - 2011-07-21 14:06:07 --> Model Class Initialized
DEBUG - 2011-07-21 14:06:07 --> Model Class Initialized
DEBUG - 2011-07-21 14:06:07 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-21 14:06:07 --> Database Driver Class Initialized
DEBUG - 2011-07-21 14:06:08 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-21 14:06:08 --> Helper loaded: url_helper
DEBUG - 2011-07-21 14:06:08 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-21 14:06:08 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-21 14:06:08 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-21 14:06:08 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-21 14:06:08 --> Final output sent to browser
DEBUG - 2011-07-21 14:06:08 --> Total execution time: 1.6069
DEBUG - 2011-07-21 18:37:10 --> Config Class Initialized
DEBUG - 2011-07-21 18:37:10 --> Hooks Class Initialized
DEBUG - 2011-07-21 18:37:10 --> Utf8 Class Initialized
DEBUG - 2011-07-21 18:37:10 --> UTF-8 Support Enabled
DEBUG - 2011-07-21 18:37:10 --> URI Class Initialized
DEBUG - 2011-07-21 18:37:10 --> Router Class Initialized
DEBUG - 2011-07-21 18:37:10 --> Output Class Initialized
DEBUG - 2011-07-21 18:37:10 --> Input Class Initialized
DEBUG - 2011-07-21 18:37:10 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-21 18:37:10 --> Language Class Initialized
DEBUG - 2011-07-21 18:37:10 --> Loader Class Initialized
DEBUG - 2011-07-21 18:37:10 --> Controller Class Initialized
DEBUG - 2011-07-21 18:37:10 --> Model Class Initialized
DEBUG - 2011-07-21 18:37:10 --> Model Class Initialized
DEBUG - 2011-07-21 18:37:10 --> Model Class Initialized
DEBUG - 2011-07-21 18:37:10 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-21 18:37:10 --> Database Driver Class Initialized
DEBUG - 2011-07-21 18:37:11 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-21 18:37:11 --> Helper loaded: url_helper
DEBUG - 2011-07-21 18:37:11 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-21 18:37:11 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-21 18:37:11 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-21 18:37:11 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-21 18:37:11 --> Final output sent to browser
DEBUG - 2011-07-21 18:37:11 --> Total execution time: 0.6642
DEBUG - 2011-07-21 18:37:14 --> Config Class Initialized
DEBUG - 2011-07-21 18:37:14 --> Hooks Class Initialized
DEBUG - 2011-07-21 18:37:14 --> Utf8 Class Initialized
DEBUG - 2011-07-21 18:37:14 --> UTF-8 Support Enabled
DEBUG - 2011-07-21 18:37:14 --> URI Class Initialized
DEBUG - 2011-07-21 18:37:14 --> Router Class Initialized
ERROR - 2011-07-21 18:37:14 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-21 18:37:40 --> Config Class Initialized
DEBUG - 2011-07-21 18:37:40 --> Hooks Class Initialized
DEBUG - 2011-07-21 18:37:40 --> Utf8 Class Initialized
DEBUG - 2011-07-21 18:37:40 --> UTF-8 Support Enabled
DEBUG - 2011-07-21 18:37:40 --> URI Class Initialized
DEBUG - 2011-07-21 18:37:40 --> Router Class Initialized
DEBUG - 2011-07-21 18:37:40 --> Output Class Initialized
DEBUG - 2011-07-21 18:37:40 --> Input Class Initialized
DEBUG - 2011-07-21 18:37:40 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-21 18:37:40 --> Language Class Initialized
DEBUG - 2011-07-21 18:37:40 --> Loader Class Initialized
DEBUG - 2011-07-21 18:37:40 --> Controller Class Initialized
DEBUG - 2011-07-21 18:37:40 --> Model Class Initialized
DEBUG - 2011-07-21 18:37:40 --> Model Class Initialized
DEBUG - 2011-07-21 18:37:40 --> Model Class Initialized
DEBUG - 2011-07-21 18:37:40 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-21 18:37:40 --> Database Driver Class Initialized
DEBUG - 2011-07-21 18:37:40 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-21 18:37:40 --> Helper loaded: url_helper
DEBUG - 2011-07-21 18:37:40 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-21 18:37:40 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-21 18:37:40 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-21 18:37:40 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-21 18:37:40 --> Final output sent to browser
DEBUG - 2011-07-21 18:37:40 --> Total execution time: 0.2828
DEBUG - 2011-07-21 18:37:42 --> Config Class Initialized
DEBUG - 2011-07-21 18:37:42 --> Hooks Class Initialized
DEBUG - 2011-07-21 18:37:42 --> Utf8 Class Initialized
DEBUG - 2011-07-21 18:37:42 --> UTF-8 Support Enabled
DEBUG - 2011-07-21 18:37:42 --> URI Class Initialized
DEBUG - 2011-07-21 18:37:42 --> Router Class Initialized
ERROR - 2011-07-21 18:37:42 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-21 18:38:17 --> Config Class Initialized
DEBUG - 2011-07-21 18:38:17 --> Hooks Class Initialized
DEBUG - 2011-07-21 18:38:17 --> Utf8 Class Initialized
DEBUG - 2011-07-21 18:38:17 --> UTF-8 Support Enabled
DEBUG - 2011-07-21 18:38:17 --> URI Class Initialized
DEBUG - 2011-07-21 18:38:17 --> Router Class Initialized
DEBUG - 2011-07-21 18:38:17 --> Output Class Initialized
DEBUG - 2011-07-21 18:38:17 --> Input Class Initialized
DEBUG - 2011-07-21 18:38:17 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-21 18:38:17 --> Language Class Initialized
DEBUG - 2011-07-21 18:38:17 --> Loader Class Initialized
DEBUG - 2011-07-21 18:38:17 --> Controller Class Initialized
DEBUG - 2011-07-21 18:38:17 --> Model Class Initialized
DEBUG - 2011-07-21 18:38:17 --> Model Class Initialized
DEBUG - 2011-07-21 18:38:17 --> Model Class Initialized
DEBUG - 2011-07-21 18:38:17 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-21 18:38:17 --> Database Driver Class Initialized
DEBUG - 2011-07-21 18:38:17 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-21 18:38:17 --> Helper loaded: url_helper
DEBUG - 2011-07-21 18:38:17 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-21 18:38:17 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-21 18:38:17 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-21 18:38:17 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-21 18:38:17 --> Final output sent to browser
DEBUG - 2011-07-21 18:38:17 --> Total execution time: 0.2326
DEBUG - 2011-07-21 18:38:19 --> Config Class Initialized
DEBUG - 2011-07-21 18:38:19 --> Hooks Class Initialized
DEBUG - 2011-07-21 18:38:19 --> Utf8 Class Initialized
DEBUG - 2011-07-21 18:38:19 --> UTF-8 Support Enabled
DEBUG - 2011-07-21 18:38:19 --> URI Class Initialized
DEBUG - 2011-07-21 18:38:19 --> Router Class Initialized
ERROR - 2011-07-21 18:38:19 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-21 18:39:11 --> Config Class Initialized
DEBUG - 2011-07-21 18:39:11 --> Hooks Class Initialized
DEBUG - 2011-07-21 18:39:11 --> Utf8 Class Initialized
DEBUG - 2011-07-21 18:39:11 --> UTF-8 Support Enabled
DEBUG - 2011-07-21 18:39:11 --> URI Class Initialized
DEBUG - 2011-07-21 18:39:11 --> Router Class Initialized
DEBUG - 2011-07-21 18:39:11 --> Output Class Initialized
DEBUG - 2011-07-21 18:39:11 --> Input Class Initialized
DEBUG - 2011-07-21 18:39:11 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-21 18:39:11 --> Language Class Initialized
DEBUG - 2011-07-21 18:39:11 --> Loader Class Initialized
DEBUG - 2011-07-21 18:39:11 --> Controller Class Initialized
DEBUG - 2011-07-21 18:39:11 --> Model Class Initialized
DEBUG - 2011-07-21 18:39:11 --> Model Class Initialized
DEBUG - 2011-07-21 18:39:11 --> Model Class Initialized
DEBUG - 2011-07-21 18:39:11 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-21 18:39:11 --> Database Driver Class Initialized
DEBUG - 2011-07-21 18:39:11 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-21 18:39:11 --> Helper loaded: url_helper
DEBUG - 2011-07-21 18:39:11 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-21 18:39:11 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-21 18:39:11 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-21 18:39:11 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-21 18:39:11 --> Final output sent to browser
DEBUG - 2011-07-21 18:39:11 --> Total execution time: 0.2391
DEBUG - 2011-07-21 18:39:12 --> Config Class Initialized
DEBUG - 2011-07-21 18:39:12 --> Hooks Class Initialized
DEBUG - 2011-07-21 18:39:12 --> Utf8 Class Initialized
DEBUG - 2011-07-21 18:39:12 --> UTF-8 Support Enabled
DEBUG - 2011-07-21 18:39:12 --> Config Class Initialized
DEBUG - 2011-07-21 18:39:12 --> Hooks Class Initialized
DEBUG - 2011-07-21 18:39:12 --> Utf8 Class Initialized
DEBUG - 2011-07-21 18:39:12 --> UTF-8 Support Enabled
DEBUG - 2011-07-21 18:39:12 --> URI Class Initialized
DEBUG - 2011-07-21 18:39:12 --> URI Class Initialized
DEBUG - 2011-07-21 18:39:12 --> Router Class Initialized
ERROR - 2011-07-21 18:39:12 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-21 18:39:12 --> Router Class Initialized
DEBUG - 2011-07-21 18:39:12 --> Output Class Initialized
DEBUG - 2011-07-21 18:39:12 --> Input Class Initialized
DEBUG - 2011-07-21 18:39:12 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-21 18:39:12 --> Language Class Initialized
DEBUG - 2011-07-21 18:39:12 --> Loader Class Initialized
DEBUG - 2011-07-21 18:39:12 --> Controller Class Initialized
DEBUG - 2011-07-21 18:39:12 --> Model Class Initialized
DEBUG - 2011-07-21 18:39:12 --> Model Class Initialized
DEBUG - 2011-07-21 18:39:12 --> Model Class Initialized
DEBUG - 2011-07-21 18:39:12 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-21 18:39:12 --> Database Driver Class Initialized
DEBUG - 2011-07-21 18:39:12 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-21 18:39:12 --> Helper loaded: url_helper
DEBUG - 2011-07-21 18:39:12 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-21 18:39:12 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-21 18:39:12 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-21 18:39:12 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-21 18:39:12 --> Final output sent to browser
DEBUG - 2011-07-21 18:39:12 --> Total execution time: 0.0443
DEBUG - 2011-07-21 18:39:41 --> Config Class Initialized
DEBUG - 2011-07-21 18:39:41 --> Hooks Class Initialized
DEBUG - 2011-07-21 18:39:41 --> Utf8 Class Initialized
DEBUG - 2011-07-21 18:39:41 --> UTF-8 Support Enabled
DEBUG - 2011-07-21 18:39:41 --> URI Class Initialized
DEBUG - 2011-07-21 18:39:41 --> Router Class Initialized
DEBUG - 2011-07-21 18:39:41 --> Output Class Initialized
DEBUG - 2011-07-21 18:39:41 --> Input Class Initialized
DEBUG - 2011-07-21 18:39:41 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-21 18:39:41 --> Language Class Initialized
DEBUG - 2011-07-21 18:39:41 --> Loader Class Initialized
DEBUG - 2011-07-21 18:39:41 --> Controller Class Initialized
DEBUG - 2011-07-21 18:39:41 --> Model Class Initialized
DEBUG - 2011-07-21 18:39:41 --> Model Class Initialized
DEBUG - 2011-07-21 18:39:41 --> Model Class Initialized
DEBUG - 2011-07-21 18:39:41 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-21 18:39:41 --> Database Driver Class Initialized
DEBUG - 2011-07-21 18:39:42 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-21 18:39:42 --> Helper loaded: url_helper
DEBUG - 2011-07-21 18:39:42 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-21 18:39:42 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-21 18:39:42 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-21 18:39:42 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-21 18:39:42 --> Final output sent to browser
DEBUG - 2011-07-21 18:39:42 --> Total execution time: 0.6926
DEBUG - 2011-07-21 18:39:43 --> Config Class Initialized
DEBUG - 2011-07-21 18:39:43 --> Hooks Class Initialized
DEBUG - 2011-07-21 18:39:43 --> Utf8 Class Initialized
DEBUG - 2011-07-21 18:39:43 --> UTF-8 Support Enabled
DEBUG - 2011-07-21 18:39:43 --> URI Class Initialized
DEBUG - 2011-07-21 18:39:43 --> Router Class Initialized
DEBUG - 2011-07-21 18:39:43 --> Output Class Initialized
DEBUG - 2011-07-21 18:39:43 --> Input Class Initialized
DEBUG - 2011-07-21 18:39:43 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-21 18:39:43 --> Language Class Initialized
DEBUG - 2011-07-21 18:39:43 --> Loader Class Initialized
DEBUG - 2011-07-21 18:39:43 --> Controller Class Initialized
DEBUG - 2011-07-21 18:39:43 --> Model Class Initialized
DEBUG - 2011-07-21 18:39:43 --> Model Class Initialized
DEBUG - 2011-07-21 18:39:43 --> Model Class Initialized
DEBUG - 2011-07-21 18:39:43 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-21 18:39:43 --> Database Driver Class Initialized
DEBUG - 2011-07-21 18:39:43 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-21 18:39:43 --> Helper loaded: url_helper
DEBUG - 2011-07-21 18:39:43 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-21 18:39:43 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-21 18:39:43 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-21 18:39:43 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-21 18:39:43 --> Final output sent to browser
DEBUG - 2011-07-21 18:39:43 --> Total execution time: 0.0754
DEBUG - 2011-07-21 18:39:49 --> Config Class Initialized
DEBUG - 2011-07-21 18:39:49 --> Hooks Class Initialized
DEBUG - 2011-07-21 18:39:49 --> Utf8 Class Initialized
DEBUG - 2011-07-21 18:39:49 --> UTF-8 Support Enabled
DEBUG - 2011-07-21 18:39:49 --> URI Class Initialized
DEBUG - 2011-07-21 18:39:49 --> Router Class Initialized
ERROR - 2011-07-21 18:39:49 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-21 18:39:53 --> Config Class Initialized
DEBUG - 2011-07-21 18:39:53 --> Hooks Class Initialized
DEBUG - 2011-07-21 18:39:53 --> Utf8 Class Initialized
DEBUG - 2011-07-21 18:39:53 --> UTF-8 Support Enabled
DEBUG - 2011-07-21 18:39:53 --> URI Class Initialized
DEBUG - 2011-07-21 18:39:53 --> Router Class Initialized
DEBUG - 2011-07-21 18:39:53 --> Output Class Initialized
DEBUG - 2011-07-21 18:39:53 --> Input Class Initialized
DEBUG - 2011-07-21 18:39:53 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-21 18:39:53 --> Language Class Initialized
DEBUG - 2011-07-21 18:39:53 --> Loader Class Initialized
DEBUG - 2011-07-21 18:39:53 --> Controller Class Initialized
DEBUG - 2011-07-21 18:39:53 --> Model Class Initialized
DEBUG - 2011-07-21 18:39:53 --> Model Class Initialized
DEBUG - 2011-07-21 18:39:53 --> Model Class Initialized
DEBUG - 2011-07-21 18:39:53 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-21 18:39:53 --> Database Driver Class Initialized
DEBUG - 2011-07-21 18:39:53 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-21 18:39:53 --> Helper loaded: url_helper
DEBUG - 2011-07-21 18:39:53 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-21 18:39:53 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-21 18:39:53 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-21 18:39:53 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-21 18:39:53 --> Final output sent to browser
DEBUG - 2011-07-21 18:39:53 --> Total execution time: 0.5136
DEBUG - 2011-07-21 18:39:54 --> Config Class Initialized
DEBUG - 2011-07-21 18:39:54 --> Hooks Class Initialized
DEBUG - 2011-07-21 18:39:54 --> Utf8 Class Initialized
DEBUG - 2011-07-21 18:39:54 --> UTF-8 Support Enabled
DEBUG - 2011-07-21 18:39:54 --> URI Class Initialized
DEBUG - 2011-07-21 18:39:54 --> Router Class Initialized
DEBUG - 2011-07-21 18:39:54 --> Output Class Initialized
DEBUG - 2011-07-21 18:39:54 --> Input Class Initialized
DEBUG - 2011-07-21 18:39:54 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-21 18:39:54 --> Language Class Initialized
DEBUG - 2011-07-21 18:39:54 --> Loader Class Initialized
DEBUG - 2011-07-21 18:39:54 --> Controller Class Initialized
DEBUG - 2011-07-21 18:39:54 --> Model Class Initialized
DEBUG - 2011-07-21 18:39:54 --> Model Class Initialized
DEBUG - 2011-07-21 18:39:54 --> Model Class Initialized
DEBUG - 2011-07-21 18:39:54 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-21 18:39:54 --> Database Driver Class Initialized
DEBUG - 2011-07-21 18:39:54 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-21 18:39:54 --> Helper loaded: url_helper
DEBUG - 2011-07-21 18:39:54 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-21 18:39:54 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-21 18:39:54 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-21 18:39:54 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-21 18:39:54 --> Final output sent to browser
DEBUG - 2011-07-21 18:39:54 --> Total execution time: 0.1047
DEBUG - 2011-07-21 18:39:54 --> Config Class Initialized
DEBUG - 2011-07-21 18:39:54 --> Hooks Class Initialized
DEBUG - 2011-07-21 18:39:54 --> Utf8 Class Initialized
DEBUG - 2011-07-21 18:39:54 --> UTF-8 Support Enabled
DEBUG - 2011-07-21 18:39:54 --> URI Class Initialized
DEBUG - 2011-07-21 18:39:54 --> Router Class Initialized
ERROR - 2011-07-21 18:39:54 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-21 18:39:59 --> Config Class Initialized
DEBUG - 2011-07-21 18:39:59 --> Hooks Class Initialized
DEBUG - 2011-07-21 18:39:59 --> Utf8 Class Initialized
DEBUG - 2011-07-21 18:39:59 --> UTF-8 Support Enabled
DEBUG - 2011-07-21 18:39:59 --> URI Class Initialized
DEBUG - 2011-07-21 18:39:59 --> Router Class Initialized
DEBUG - 2011-07-21 18:39:59 --> Output Class Initialized
DEBUG - 2011-07-21 18:39:59 --> Input Class Initialized
DEBUG - 2011-07-21 18:39:59 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-21 18:39:59 --> Language Class Initialized
DEBUG - 2011-07-21 18:39:59 --> Loader Class Initialized
DEBUG - 2011-07-21 18:39:59 --> Controller Class Initialized
DEBUG - 2011-07-21 18:39:59 --> Model Class Initialized
DEBUG - 2011-07-21 18:39:59 --> Model Class Initialized
DEBUG - 2011-07-21 18:39:59 --> Model Class Initialized
DEBUG - 2011-07-21 18:39:59 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-21 18:39:59 --> Database Driver Class Initialized
DEBUG - 2011-07-21 18:39:59 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-21 18:39:59 --> Helper loaded: url_helper
DEBUG - 2011-07-21 18:39:59 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-21 18:39:59 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-21 18:39:59 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-21 18:39:59 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-21 18:39:59 --> Final output sent to browser
DEBUG - 2011-07-21 18:39:59 --> Total execution time: 0.2341
DEBUG - 2011-07-21 18:40:02 --> Config Class Initialized
DEBUG - 2011-07-21 18:40:02 --> Hooks Class Initialized
DEBUG - 2011-07-21 18:40:02 --> Utf8 Class Initialized
DEBUG - 2011-07-21 18:40:02 --> UTF-8 Support Enabled
DEBUG - 2011-07-21 18:40:02 --> URI Class Initialized
DEBUG - 2011-07-21 18:40:02 --> Router Class Initialized
DEBUG - 2011-07-21 18:40:02 --> Output Class Initialized
DEBUG - 2011-07-21 18:40:02 --> Input Class Initialized
DEBUG - 2011-07-21 18:40:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-21 18:40:02 --> Language Class Initialized
DEBUG - 2011-07-21 18:40:02 --> Loader Class Initialized
DEBUG - 2011-07-21 18:40:02 --> Controller Class Initialized
DEBUG - 2011-07-21 18:40:02 --> Model Class Initialized
DEBUG - 2011-07-21 18:40:02 --> Model Class Initialized
DEBUG - 2011-07-21 18:40:02 --> Model Class Initialized
DEBUG - 2011-07-21 18:40:02 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-21 18:40:02 --> Database Driver Class Initialized
DEBUG - 2011-07-21 18:40:02 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-21 18:40:02 --> Helper loaded: url_helper
DEBUG - 2011-07-21 18:40:02 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-21 18:40:02 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-21 18:40:02 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-21 18:40:02 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-21 18:40:02 --> Final output sent to browser
DEBUG - 2011-07-21 18:40:02 --> Total execution time: 0.2113
DEBUG - 2011-07-21 18:40:03 --> Config Class Initialized
DEBUG - 2011-07-21 18:40:03 --> Hooks Class Initialized
DEBUG - 2011-07-21 18:40:03 --> Utf8 Class Initialized
DEBUG - 2011-07-21 18:40:03 --> UTF-8 Support Enabled
DEBUG - 2011-07-21 18:40:03 --> URI Class Initialized
DEBUG - 2011-07-21 18:40:03 --> Router Class Initialized
ERROR - 2011-07-21 18:40:03 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-21 18:40:05 --> Config Class Initialized
DEBUG - 2011-07-21 18:40:05 --> Hooks Class Initialized
DEBUG - 2011-07-21 18:40:05 --> Utf8 Class Initialized
DEBUG - 2011-07-21 18:40:05 --> UTF-8 Support Enabled
DEBUG - 2011-07-21 18:40:05 --> URI Class Initialized
DEBUG - 2011-07-21 18:40:05 --> Router Class Initialized
DEBUG - 2011-07-21 18:40:05 --> Output Class Initialized
DEBUG - 2011-07-21 18:40:05 --> Input Class Initialized
DEBUG - 2011-07-21 18:40:05 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-21 18:40:05 --> Language Class Initialized
DEBUG - 2011-07-21 18:40:05 --> Loader Class Initialized
DEBUG - 2011-07-21 18:40:05 --> Controller Class Initialized
DEBUG - 2011-07-21 18:40:05 --> Model Class Initialized
DEBUG - 2011-07-21 18:40:05 --> Model Class Initialized
DEBUG - 2011-07-21 18:40:05 --> Model Class Initialized
DEBUG - 2011-07-21 18:40:05 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-21 18:40:05 --> Database Driver Class Initialized
DEBUG - 2011-07-21 18:40:06 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-21 18:40:06 --> Helper loaded: url_helper
DEBUG - 2011-07-21 18:40:06 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-21 18:40:06 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-21 18:40:06 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-21 18:40:06 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-21 18:40:06 --> Final output sent to browser
DEBUG - 2011-07-21 18:40:06 --> Total execution time: 1.1187
DEBUG - 2011-07-21 18:40:07 --> Config Class Initialized
DEBUG - 2011-07-21 18:40:07 --> Hooks Class Initialized
DEBUG - 2011-07-21 18:40:07 --> Utf8 Class Initialized
DEBUG - 2011-07-21 18:40:07 --> UTF-8 Support Enabled
DEBUG - 2011-07-21 18:40:07 --> URI Class Initialized
DEBUG - 2011-07-21 18:40:07 --> Router Class Initialized
ERROR - 2011-07-21 18:40:07 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-21 18:40:10 --> Config Class Initialized
DEBUG - 2011-07-21 18:40:10 --> Hooks Class Initialized
DEBUG - 2011-07-21 18:40:10 --> Utf8 Class Initialized
DEBUG - 2011-07-21 18:40:10 --> UTF-8 Support Enabled
DEBUG - 2011-07-21 18:40:10 --> URI Class Initialized
DEBUG - 2011-07-21 18:40:10 --> Router Class Initialized
DEBUG - 2011-07-21 18:40:10 --> Output Class Initialized
DEBUG - 2011-07-21 18:40:10 --> Input Class Initialized
DEBUG - 2011-07-21 18:40:10 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-21 18:40:10 --> Language Class Initialized
DEBUG - 2011-07-21 18:40:10 --> Loader Class Initialized
DEBUG - 2011-07-21 18:40:10 --> Controller Class Initialized
DEBUG - 2011-07-21 18:40:10 --> Model Class Initialized
DEBUG - 2011-07-21 18:40:10 --> Model Class Initialized
DEBUG - 2011-07-21 18:40:10 --> Model Class Initialized
DEBUG - 2011-07-21 18:40:10 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-21 18:40:10 --> Database Driver Class Initialized
DEBUG - 2011-07-21 18:40:10 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-21 18:40:10 --> Helper loaded: url_helper
DEBUG - 2011-07-21 18:40:10 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-21 18:40:10 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-21 18:40:10 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-21 18:40:10 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-21 18:40:10 --> Final output sent to browser
DEBUG - 2011-07-21 18:40:10 --> Total execution time: 0.0519
DEBUG - 2011-07-21 18:40:11 --> Config Class Initialized
DEBUG - 2011-07-21 18:40:11 --> Hooks Class Initialized
DEBUG - 2011-07-21 18:40:11 --> Utf8 Class Initialized
DEBUG - 2011-07-21 18:40:11 --> UTF-8 Support Enabled
DEBUG - 2011-07-21 18:40:11 --> URI Class Initialized
DEBUG - 2011-07-21 18:40:11 --> Router Class Initialized
ERROR - 2011-07-21 18:40:11 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-21 18:40:12 --> Config Class Initialized
DEBUG - 2011-07-21 18:40:12 --> Hooks Class Initialized
DEBUG - 2011-07-21 18:40:12 --> Utf8 Class Initialized
DEBUG - 2011-07-21 18:40:12 --> UTF-8 Support Enabled
DEBUG - 2011-07-21 18:40:12 --> URI Class Initialized
DEBUG - 2011-07-21 18:40:12 --> Router Class Initialized
DEBUG - 2011-07-21 18:40:12 --> Output Class Initialized
DEBUG - 2011-07-21 18:40:12 --> Input Class Initialized
DEBUG - 2011-07-21 18:40:12 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-21 18:40:12 --> Language Class Initialized
DEBUG - 2011-07-21 18:40:12 --> Loader Class Initialized
DEBUG - 2011-07-21 18:40:12 --> Controller Class Initialized
DEBUG - 2011-07-21 18:40:12 --> Model Class Initialized
DEBUG - 2011-07-21 18:40:12 --> Model Class Initialized
DEBUG - 2011-07-21 18:40:12 --> Model Class Initialized
DEBUG - 2011-07-21 18:40:12 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-21 18:40:12 --> Database Driver Class Initialized
DEBUG - 2011-07-21 18:40:12 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-21 18:40:12 --> Helper loaded: url_helper
DEBUG - 2011-07-21 18:40:12 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-21 18:40:12 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-21 18:40:12 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-21 18:40:12 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-21 18:40:12 --> Final output sent to browser
DEBUG - 2011-07-21 18:40:12 --> Total execution time: 0.0799
DEBUG - 2011-07-21 18:40:12 --> Config Class Initialized
DEBUG - 2011-07-21 18:40:12 --> Hooks Class Initialized
DEBUG - 2011-07-21 18:40:12 --> Utf8 Class Initialized
DEBUG - 2011-07-21 18:40:12 --> UTF-8 Support Enabled
DEBUG - 2011-07-21 18:40:12 --> URI Class Initialized
DEBUG - 2011-07-21 18:40:12 --> Router Class Initialized
DEBUG - 2011-07-21 18:40:12 --> Output Class Initialized
DEBUG - 2011-07-21 18:40:12 --> Input Class Initialized
DEBUG - 2011-07-21 18:40:12 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-21 18:40:12 --> Language Class Initialized
DEBUG - 2011-07-21 18:40:12 --> Loader Class Initialized
DEBUG - 2011-07-21 18:40:12 --> Controller Class Initialized
DEBUG - 2011-07-21 18:40:12 --> Model Class Initialized
DEBUG - 2011-07-21 18:40:12 --> Model Class Initialized
DEBUG - 2011-07-21 18:40:12 --> Model Class Initialized
DEBUG - 2011-07-21 18:40:12 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-21 18:40:12 --> Database Driver Class Initialized
DEBUG - 2011-07-21 18:40:13 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-21 18:40:13 --> Helper loaded: url_helper
DEBUG - 2011-07-21 18:40:13 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-21 18:40:13 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-21 18:40:13 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-21 18:40:13 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-21 18:40:13 --> Final output sent to browser
DEBUG - 2011-07-21 18:40:13 --> Total execution time: 0.0648
DEBUG - 2011-07-21 18:40:22 --> Config Class Initialized
DEBUG - 2011-07-21 18:40:22 --> Hooks Class Initialized
DEBUG - 2011-07-21 18:40:22 --> Utf8 Class Initialized
DEBUG - 2011-07-21 18:40:22 --> UTF-8 Support Enabled
DEBUG - 2011-07-21 18:40:22 --> URI Class Initialized
DEBUG - 2011-07-21 18:40:22 --> Router Class Initialized
DEBUG - 2011-07-21 18:40:22 --> Output Class Initialized
DEBUG - 2011-07-21 18:40:22 --> Input Class Initialized
DEBUG - 2011-07-21 18:40:22 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-21 18:40:22 --> Language Class Initialized
DEBUG - 2011-07-21 18:40:22 --> Loader Class Initialized
DEBUG - 2011-07-21 18:40:22 --> Controller Class Initialized
DEBUG - 2011-07-21 18:40:22 --> Model Class Initialized
DEBUG - 2011-07-21 18:40:22 --> Model Class Initialized
DEBUG - 2011-07-21 18:40:22 --> Model Class Initialized
DEBUG - 2011-07-21 18:40:22 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-21 18:40:22 --> Database Driver Class Initialized
DEBUG - 2011-07-21 18:40:22 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-21 18:40:22 --> Helper loaded: url_helper
DEBUG - 2011-07-21 18:40:22 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-21 18:40:22 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-21 18:40:22 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-21 18:40:22 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-21 18:40:22 --> Final output sent to browser
DEBUG - 2011-07-21 18:40:22 --> Total execution time: 0.0613
DEBUG - 2011-07-21 18:40:23 --> Config Class Initialized
DEBUG - 2011-07-21 18:40:23 --> Hooks Class Initialized
DEBUG - 2011-07-21 18:40:23 --> Utf8 Class Initialized
DEBUG - 2011-07-21 18:40:23 --> UTF-8 Support Enabled
DEBUG - 2011-07-21 18:40:23 --> URI Class Initialized
DEBUG - 2011-07-21 18:40:23 --> Router Class Initialized
ERROR - 2011-07-21 18:40:23 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-21 18:40:25 --> Config Class Initialized
DEBUG - 2011-07-21 18:40:25 --> Hooks Class Initialized
DEBUG - 2011-07-21 18:40:25 --> Utf8 Class Initialized
DEBUG - 2011-07-21 18:40:25 --> UTF-8 Support Enabled
DEBUG - 2011-07-21 18:40:25 --> URI Class Initialized
DEBUG - 2011-07-21 18:40:25 --> Router Class Initialized
DEBUG - 2011-07-21 18:40:25 --> Output Class Initialized
DEBUG - 2011-07-21 18:40:25 --> Input Class Initialized
DEBUG - 2011-07-21 18:40:25 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-21 18:40:26 --> Language Class Initialized
DEBUG - 2011-07-21 18:40:26 --> Loader Class Initialized
DEBUG - 2011-07-21 18:40:26 --> Controller Class Initialized
DEBUG - 2011-07-21 18:40:26 --> Model Class Initialized
DEBUG - 2011-07-21 18:40:26 --> Model Class Initialized
DEBUG - 2011-07-21 18:40:26 --> Model Class Initialized
DEBUG - 2011-07-21 18:40:26 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-21 18:40:26 --> Database Driver Class Initialized
DEBUG - 2011-07-21 18:40:26 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-21 18:40:26 --> Helper loaded: url_helper
DEBUG - 2011-07-21 18:40:26 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-21 18:40:26 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-21 18:40:26 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-21 18:40:26 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-21 18:40:26 --> Final output sent to browser
DEBUG - 2011-07-21 18:40:26 --> Total execution time: 0.0575
DEBUG - 2011-07-21 18:40:26 --> Config Class Initialized
DEBUG - 2011-07-21 18:40:26 --> Hooks Class Initialized
DEBUG - 2011-07-21 18:40:26 --> Utf8 Class Initialized
DEBUG - 2011-07-21 18:40:26 --> UTF-8 Support Enabled
DEBUG - 2011-07-21 18:40:26 --> URI Class Initialized
DEBUG - 2011-07-21 18:40:26 --> Router Class Initialized
ERROR - 2011-07-21 18:40:26 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-21 18:40:29 --> Config Class Initialized
DEBUG - 2011-07-21 18:40:29 --> Hooks Class Initialized
DEBUG - 2011-07-21 18:40:29 --> Utf8 Class Initialized
DEBUG - 2011-07-21 18:40:29 --> UTF-8 Support Enabled
DEBUG - 2011-07-21 18:40:29 --> URI Class Initialized
DEBUG - 2011-07-21 18:40:29 --> Router Class Initialized
DEBUG - 2011-07-21 18:40:29 --> Output Class Initialized
DEBUG - 2011-07-21 18:40:29 --> Input Class Initialized
DEBUG - 2011-07-21 18:40:29 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-21 18:40:29 --> Language Class Initialized
DEBUG - 2011-07-21 18:40:29 --> Loader Class Initialized
DEBUG - 2011-07-21 18:40:29 --> Controller Class Initialized
DEBUG - 2011-07-21 18:40:29 --> Model Class Initialized
DEBUG - 2011-07-21 18:40:29 --> Model Class Initialized
DEBUG - 2011-07-21 18:40:29 --> Model Class Initialized
DEBUG - 2011-07-21 18:40:29 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-21 18:40:29 --> Database Driver Class Initialized
DEBUG - 2011-07-21 18:40:29 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-21 18:40:29 --> Helper loaded: url_helper
DEBUG - 2011-07-21 18:40:29 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-21 18:40:29 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-21 18:40:29 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-21 18:40:29 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-21 18:40:29 --> Final output sent to browser
DEBUG - 2011-07-21 18:40:29 --> Total execution time: 0.0432
DEBUG - 2011-07-21 18:40:29 --> Config Class Initialized
DEBUG - 2011-07-21 18:40:29 --> Hooks Class Initialized
DEBUG - 2011-07-21 18:40:29 --> Utf8 Class Initialized
DEBUG - 2011-07-21 18:40:29 --> UTF-8 Support Enabled
DEBUG - 2011-07-21 18:40:29 --> URI Class Initialized
DEBUG - 2011-07-21 18:40:29 --> Router Class Initialized
ERROR - 2011-07-21 18:40:29 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-21 18:40:32 --> Config Class Initialized
DEBUG - 2011-07-21 18:40:32 --> Hooks Class Initialized
DEBUG - 2011-07-21 18:40:32 --> Utf8 Class Initialized
DEBUG - 2011-07-21 18:40:32 --> UTF-8 Support Enabled
DEBUG - 2011-07-21 18:40:32 --> URI Class Initialized
DEBUG - 2011-07-21 18:40:32 --> Router Class Initialized
DEBUG - 2011-07-21 18:40:32 --> Output Class Initialized
DEBUG - 2011-07-21 18:40:32 --> Input Class Initialized
DEBUG - 2011-07-21 18:40:32 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-21 18:40:32 --> Language Class Initialized
DEBUG - 2011-07-21 18:40:32 --> Loader Class Initialized
DEBUG - 2011-07-21 18:40:32 --> Controller Class Initialized
DEBUG - 2011-07-21 18:40:32 --> Model Class Initialized
DEBUG - 2011-07-21 18:40:32 --> Model Class Initialized
DEBUG - 2011-07-21 18:40:32 --> Model Class Initialized
DEBUG - 2011-07-21 18:40:32 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-21 18:40:32 --> Database Driver Class Initialized
DEBUG - 2011-07-21 18:40:32 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-21 18:40:32 --> Helper loaded: url_helper
DEBUG - 2011-07-21 18:40:32 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-21 18:40:32 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-21 18:40:32 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-21 18:40:32 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-21 18:40:32 --> Final output sent to browser
DEBUG - 2011-07-21 18:40:32 --> Total execution time: 0.1790
DEBUG - 2011-07-21 18:40:34 --> Config Class Initialized
DEBUG - 2011-07-21 18:40:34 --> Hooks Class Initialized
DEBUG - 2011-07-21 18:40:34 --> Utf8 Class Initialized
DEBUG - 2011-07-21 18:40:34 --> UTF-8 Support Enabled
DEBUG - 2011-07-21 18:40:34 --> URI Class Initialized
DEBUG - 2011-07-21 18:40:34 --> Router Class Initialized
ERROR - 2011-07-21 18:40:34 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-21 18:40:36 --> Config Class Initialized
DEBUG - 2011-07-21 18:40:36 --> Hooks Class Initialized
DEBUG - 2011-07-21 18:40:36 --> Utf8 Class Initialized
DEBUG - 2011-07-21 18:40:36 --> UTF-8 Support Enabled
DEBUG - 2011-07-21 18:40:36 --> URI Class Initialized
DEBUG - 2011-07-21 18:40:36 --> Router Class Initialized
DEBUG - 2011-07-21 18:40:36 --> Output Class Initialized
DEBUG - 2011-07-21 18:40:36 --> Input Class Initialized
DEBUG - 2011-07-21 18:40:36 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-21 18:40:36 --> Language Class Initialized
DEBUG - 2011-07-21 18:40:36 --> Loader Class Initialized
DEBUG - 2011-07-21 18:40:36 --> Controller Class Initialized
DEBUG - 2011-07-21 18:40:36 --> Model Class Initialized
DEBUG - 2011-07-21 18:40:36 --> Model Class Initialized
DEBUG - 2011-07-21 18:40:36 --> Model Class Initialized
DEBUG - 2011-07-21 18:40:36 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-21 18:40:36 --> Database Driver Class Initialized
DEBUG - 2011-07-21 18:40:36 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-21 18:40:36 --> Helper loaded: url_helper
DEBUG - 2011-07-21 18:40:36 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-21 18:40:36 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-21 18:40:36 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-21 18:40:36 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-21 18:40:36 --> Final output sent to browser
DEBUG - 2011-07-21 18:40:36 --> Total execution time: 0.0727
DEBUG - 2011-07-21 18:40:37 --> Config Class Initialized
DEBUG - 2011-07-21 18:40:37 --> Hooks Class Initialized
DEBUG - 2011-07-21 18:40:37 --> Utf8 Class Initialized
DEBUG - 2011-07-21 18:40:37 --> UTF-8 Support Enabled
DEBUG - 2011-07-21 18:40:37 --> URI Class Initialized
DEBUG - 2011-07-21 18:40:37 --> Router Class Initialized
ERROR - 2011-07-21 18:40:37 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-21 18:40:39 --> Config Class Initialized
DEBUG - 2011-07-21 18:40:39 --> Hooks Class Initialized
DEBUG - 2011-07-21 18:40:39 --> Utf8 Class Initialized
DEBUG - 2011-07-21 18:40:39 --> UTF-8 Support Enabled
DEBUG - 2011-07-21 18:40:39 --> URI Class Initialized
DEBUG - 2011-07-21 18:40:39 --> Router Class Initialized
DEBUG - 2011-07-21 18:40:39 --> Output Class Initialized
DEBUG - 2011-07-21 18:40:39 --> Input Class Initialized
DEBUG - 2011-07-21 18:40:39 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-21 18:40:39 --> Language Class Initialized
DEBUG - 2011-07-21 18:40:39 --> Loader Class Initialized
DEBUG - 2011-07-21 18:40:39 --> Controller Class Initialized
DEBUG - 2011-07-21 18:40:39 --> Model Class Initialized
DEBUG - 2011-07-21 18:40:39 --> Model Class Initialized
DEBUG - 2011-07-21 18:40:39 --> Model Class Initialized
DEBUG - 2011-07-21 18:40:39 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-21 18:40:39 --> Database Driver Class Initialized
DEBUG - 2011-07-21 18:40:39 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-21 18:40:39 --> Helper loaded: url_helper
DEBUG - 2011-07-21 18:40:39 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-21 18:40:39 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-21 18:40:39 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-21 18:40:39 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-21 18:40:39 --> Final output sent to browser
DEBUG - 2011-07-21 18:40:39 --> Total execution time: 0.0463
DEBUG - 2011-07-21 18:40:40 --> Config Class Initialized
DEBUG - 2011-07-21 18:40:40 --> Hooks Class Initialized
DEBUG - 2011-07-21 18:40:40 --> Utf8 Class Initialized
DEBUG - 2011-07-21 18:40:40 --> UTF-8 Support Enabled
DEBUG - 2011-07-21 18:40:40 --> URI Class Initialized
DEBUG - 2011-07-21 18:40:40 --> Router Class Initialized
ERROR - 2011-07-21 18:40:40 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-21 18:40:43 --> Config Class Initialized
DEBUG - 2011-07-21 18:40:43 --> Hooks Class Initialized
DEBUG - 2011-07-21 18:40:43 --> Utf8 Class Initialized
DEBUG - 2011-07-21 18:40:43 --> UTF-8 Support Enabled
DEBUG - 2011-07-21 18:40:43 --> URI Class Initialized
DEBUG - 2011-07-21 18:40:43 --> Router Class Initialized
DEBUG - 2011-07-21 18:40:43 --> Output Class Initialized
DEBUG - 2011-07-21 18:40:43 --> Input Class Initialized
DEBUG - 2011-07-21 18:40:43 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-21 18:40:43 --> Language Class Initialized
DEBUG - 2011-07-21 18:40:43 --> Loader Class Initialized
DEBUG - 2011-07-21 18:40:43 --> Controller Class Initialized
DEBUG - 2011-07-21 18:40:43 --> Model Class Initialized
DEBUG - 2011-07-21 18:40:43 --> Model Class Initialized
DEBUG - 2011-07-21 18:40:43 --> Model Class Initialized
DEBUG - 2011-07-21 18:40:43 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-21 18:40:43 --> Database Driver Class Initialized
DEBUG - 2011-07-21 18:40:43 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-21 18:40:43 --> Helper loaded: url_helper
DEBUG - 2011-07-21 18:40:43 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-21 18:40:43 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-21 18:40:43 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-21 18:40:43 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-21 18:40:43 --> Final output sent to browser
DEBUG - 2011-07-21 18:40:43 --> Total execution time: 0.2204
DEBUG - 2011-07-21 18:40:44 --> Config Class Initialized
DEBUG - 2011-07-21 18:40:44 --> Hooks Class Initialized
DEBUG - 2011-07-21 18:40:44 --> Utf8 Class Initialized
DEBUG - 2011-07-21 18:40:44 --> UTF-8 Support Enabled
DEBUG - 2011-07-21 18:40:44 --> URI Class Initialized
DEBUG - 2011-07-21 18:40:44 --> Router Class Initialized
ERROR - 2011-07-21 18:40:44 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-21 18:40:47 --> Config Class Initialized
DEBUG - 2011-07-21 18:40:47 --> Hooks Class Initialized
DEBUG - 2011-07-21 18:40:47 --> Utf8 Class Initialized
DEBUG - 2011-07-21 18:40:47 --> UTF-8 Support Enabled
DEBUG - 2011-07-21 18:40:47 --> URI Class Initialized
DEBUG - 2011-07-21 18:40:47 --> Router Class Initialized
DEBUG - 2011-07-21 18:40:47 --> Output Class Initialized
DEBUG - 2011-07-21 18:40:47 --> Input Class Initialized
DEBUG - 2011-07-21 18:40:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-21 18:40:47 --> Language Class Initialized
DEBUG - 2011-07-21 18:40:47 --> Loader Class Initialized
DEBUG - 2011-07-21 18:40:47 --> Controller Class Initialized
DEBUG - 2011-07-21 18:40:47 --> Model Class Initialized
DEBUG - 2011-07-21 18:40:47 --> Model Class Initialized
DEBUG - 2011-07-21 18:40:47 --> Model Class Initialized
DEBUG - 2011-07-21 18:40:47 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-21 18:40:47 --> Database Driver Class Initialized
DEBUG - 2011-07-21 18:40:47 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-21 18:40:47 --> Helper loaded: url_helper
DEBUG - 2011-07-21 18:40:47 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-21 18:40:47 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-21 18:40:47 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-21 18:40:47 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-21 18:40:47 --> Final output sent to browser
DEBUG - 2011-07-21 18:40:47 --> Total execution time: 0.2754
DEBUG - 2011-07-21 18:40:48 --> Config Class Initialized
DEBUG - 2011-07-21 18:40:48 --> Hooks Class Initialized
DEBUG - 2011-07-21 18:40:48 --> Utf8 Class Initialized
DEBUG - 2011-07-21 18:40:48 --> UTF-8 Support Enabled
DEBUG - 2011-07-21 18:40:48 --> URI Class Initialized
DEBUG - 2011-07-21 18:40:48 --> Router Class Initialized
DEBUG - 2011-07-21 18:40:48 --> Output Class Initialized
DEBUG - 2011-07-21 18:40:48 --> Input Class Initialized
DEBUG - 2011-07-21 18:40:48 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-21 18:40:48 --> Language Class Initialized
DEBUG - 2011-07-21 18:40:48 --> Loader Class Initialized
DEBUG - 2011-07-21 18:40:48 --> Controller Class Initialized
DEBUG - 2011-07-21 18:40:48 --> Model Class Initialized
DEBUG - 2011-07-21 18:40:48 --> Model Class Initialized
DEBUG - 2011-07-21 18:40:48 --> Model Class Initialized
DEBUG - 2011-07-21 18:40:48 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-21 18:40:48 --> Database Driver Class Initialized
DEBUG - 2011-07-21 18:40:48 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-21 18:40:48 --> Helper loaded: url_helper
DEBUG - 2011-07-21 18:40:48 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-21 18:40:48 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-21 18:40:48 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-21 18:40:48 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-21 18:40:48 --> Final output sent to browser
DEBUG - 2011-07-21 18:40:48 --> Total execution time: 0.0811
DEBUG - 2011-07-21 18:40:50 --> Config Class Initialized
DEBUG - 2011-07-21 18:40:50 --> Hooks Class Initialized
DEBUG - 2011-07-21 18:40:50 --> Utf8 Class Initialized
DEBUG - 2011-07-21 18:40:50 --> UTF-8 Support Enabled
DEBUG - 2011-07-21 18:40:50 --> URI Class Initialized
DEBUG - 2011-07-21 18:40:50 --> Router Class Initialized
ERROR - 2011-07-21 18:40:50 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-21 18:40:52 --> Config Class Initialized
DEBUG - 2011-07-21 18:40:52 --> Hooks Class Initialized
DEBUG - 2011-07-21 18:40:52 --> Utf8 Class Initialized
DEBUG - 2011-07-21 18:40:52 --> UTF-8 Support Enabled
DEBUG - 2011-07-21 18:40:52 --> URI Class Initialized
DEBUG - 2011-07-21 18:40:52 --> Router Class Initialized
DEBUG - 2011-07-21 18:40:52 --> Output Class Initialized
DEBUG - 2011-07-21 18:40:52 --> Input Class Initialized
DEBUG - 2011-07-21 18:40:52 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-21 18:40:52 --> Language Class Initialized
DEBUG - 2011-07-21 18:40:52 --> Loader Class Initialized
DEBUG - 2011-07-21 18:40:52 --> Controller Class Initialized
DEBUG - 2011-07-21 18:40:52 --> Model Class Initialized
DEBUG - 2011-07-21 18:40:52 --> Model Class Initialized
DEBUG - 2011-07-21 18:40:52 --> Model Class Initialized
DEBUG - 2011-07-21 18:40:52 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-21 18:40:52 --> Database Driver Class Initialized
DEBUG - 2011-07-21 18:40:52 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-21 18:40:52 --> Helper loaded: url_helper
DEBUG - 2011-07-21 18:40:52 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-21 18:40:52 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-21 18:40:52 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-21 18:40:52 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-21 18:40:52 --> Final output sent to browser
DEBUG - 2011-07-21 18:40:52 --> Total execution time: 0.2920
DEBUG - 2011-07-21 18:40:53 --> Config Class Initialized
DEBUG - 2011-07-21 18:40:53 --> Hooks Class Initialized
DEBUG - 2011-07-21 18:40:53 --> Utf8 Class Initialized
DEBUG - 2011-07-21 18:40:53 --> UTF-8 Support Enabled
DEBUG - 2011-07-21 18:40:53 --> URI Class Initialized
DEBUG - 2011-07-21 18:40:53 --> Router Class Initialized
ERROR - 2011-07-21 18:40:53 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-21 18:40:54 --> Config Class Initialized
DEBUG - 2011-07-21 18:40:54 --> Hooks Class Initialized
DEBUG - 2011-07-21 18:40:54 --> Utf8 Class Initialized
DEBUG - 2011-07-21 18:40:54 --> UTF-8 Support Enabled
DEBUG - 2011-07-21 18:40:54 --> URI Class Initialized
DEBUG - 2011-07-21 18:40:54 --> Router Class Initialized
DEBUG - 2011-07-21 18:40:54 --> Output Class Initialized
DEBUG - 2011-07-21 18:40:54 --> Input Class Initialized
DEBUG - 2011-07-21 18:40:54 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-21 18:40:54 --> Language Class Initialized
DEBUG - 2011-07-21 18:40:54 --> Loader Class Initialized
DEBUG - 2011-07-21 18:40:54 --> Controller Class Initialized
DEBUG - 2011-07-21 18:40:54 --> Model Class Initialized
DEBUG - 2011-07-21 18:40:54 --> Model Class Initialized
DEBUG - 2011-07-21 18:40:54 --> Model Class Initialized
DEBUG - 2011-07-21 18:40:54 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-21 18:40:54 --> Database Driver Class Initialized
DEBUG - 2011-07-21 18:40:54 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-21 18:40:54 --> Helper loaded: url_helper
DEBUG - 2011-07-21 18:40:54 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-21 18:40:54 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-21 18:40:54 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-21 18:40:54 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-21 18:40:54 --> Final output sent to browser
DEBUG - 2011-07-21 18:40:54 --> Total execution time: 0.0483
DEBUG - 2011-07-21 18:40:59 --> Config Class Initialized
DEBUG - 2011-07-21 18:40:59 --> Hooks Class Initialized
DEBUG - 2011-07-21 18:40:59 --> Utf8 Class Initialized
DEBUG - 2011-07-21 18:40:59 --> UTF-8 Support Enabled
DEBUG - 2011-07-21 18:40:59 --> URI Class Initialized
DEBUG - 2011-07-21 18:40:59 --> Router Class Initialized
DEBUG - 2011-07-21 18:40:59 --> Output Class Initialized
DEBUG - 2011-07-21 18:40:59 --> Input Class Initialized
DEBUG - 2011-07-21 18:40:59 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-21 18:40:59 --> Language Class Initialized
DEBUG - 2011-07-21 18:40:59 --> Loader Class Initialized
DEBUG - 2011-07-21 18:40:59 --> Controller Class Initialized
DEBUG - 2011-07-21 18:40:59 --> Model Class Initialized
DEBUG - 2011-07-21 18:40:59 --> Model Class Initialized
DEBUG - 2011-07-21 18:40:59 --> Model Class Initialized
DEBUG - 2011-07-21 18:40:59 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-21 18:40:59 --> Database Driver Class Initialized
DEBUG - 2011-07-21 18:40:59 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-21 18:40:59 --> Helper loaded: url_helper
DEBUG - 2011-07-21 18:40:59 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-21 18:40:59 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-21 18:40:59 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-21 18:40:59 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-21 18:40:59 --> Final output sent to browser
DEBUG - 2011-07-21 18:40:59 --> Total execution time: 0.2030
DEBUG - 2011-07-21 18:41:00 --> Config Class Initialized
DEBUG - 2011-07-21 18:41:00 --> Hooks Class Initialized
DEBUG - 2011-07-21 18:41:00 --> Utf8 Class Initialized
DEBUG - 2011-07-21 18:41:00 --> UTF-8 Support Enabled
DEBUG - 2011-07-21 18:41:00 --> URI Class Initialized
DEBUG - 2011-07-21 18:41:00 --> Router Class Initialized
DEBUG - 2011-07-21 18:41:00 --> Output Class Initialized
DEBUG - 2011-07-21 18:41:00 --> Input Class Initialized
DEBUG - 2011-07-21 18:41:00 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-21 18:41:00 --> Language Class Initialized
DEBUG - 2011-07-21 18:41:00 --> Loader Class Initialized
DEBUG - 2011-07-21 18:41:00 --> Controller Class Initialized
DEBUG - 2011-07-21 18:41:00 --> Model Class Initialized
DEBUG - 2011-07-21 18:41:00 --> Model Class Initialized
DEBUG - 2011-07-21 18:41:00 --> Model Class Initialized
DEBUG - 2011-07-21 18:41:00 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-21 18:41:00 --> Database Driver Class Initialized
DEBUG - 2011-07-21 18:41:00 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-21 18:41:00 --> Helper loaded: url_helper
DEBUG - 2011-07-21 18:41:00 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-21 18:41:00 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-21 18:41:00 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-21 18:41:00 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-21 18:41:00 --> Final output sent to browser
DEBUG - 2011-07-21 18:41:00 --> Total execution time: 0.0489
DEBUG - 2011-07-21 18:41:00 --> Config Class Initialized
DEBUG - 2011-07-21 18:41:00 --> Hooks Class Initialized
DEBUG - 2011-07-21 18:41:00 --> Utf8 Class Initialized
DEBUG - 2011-07-21 18:41:00 --> UTF-8 Support Enabled
DEBUG - 2011-07-21 18:41:00 --> URI Class Initialized
DEBUG - 2011-07-21 18:41:00 --> Router Class Initialized
ERROR - 2011-07-21 18:41:00 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-21 18:41:03 --> Config Class Initialized
DEBUG - 2011-07-21 18:41:03 --> Hooks Class Initialized
DEBUG - 2011-07-21 18:41:03 --> Utf8 Class Initialized
DEBUG - 2011-07-21 18:41:03 --> UTF-8 Support Enabled
DEBUG - 2011-07-21 18:41:03 --> URI Class Initialized
DEBUG - 2011-07-21 18:41:03 --> Router Class Initialized
DEBUG - 2011-07-21 18:41:03 --> Output Class Initialized
DEBUG - 2011-07-21 18:41:03 --> Input Class Initialized
DEBUG - 2011-07-21 18:41:03 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-21 18:41:03 --> Language Class Initialized
DEBUG - 2011-07-21 18:41:03 --> Loader Class Initialized
DEBUG - 2011-07-21 18:41:03 --> Controller Class Initialized
DEBUG - 2011-07-21 18:41:03 --> Model Class Initialized
DEBUG - 2011-07-21 18:41:03 --> Model Class Initialized
DEBUG - 2011-07-21 18:41:03 --> Model Class Initialized
DEBUG - 2011-07-21 18:41:03 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-21 18:41:03 --> Database Driver Class Initialized
DEBUG - 2011-07-21 18:41:04 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-21 18:41:04 --> Helper loaded: url_helper
DEBUG - 2011-07-21 18:41:04 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-21 18:41:04 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-21 18:41:04 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-21 18:41:04 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-21 18:41:04 --> Final output sent to browser
DEBUG - 2011-07-21 18:41:04 --> Total execution time: 0.4224
DEBUG - 2011-07-21 18:41:05 --> Config Class Initialized
DEBUG - 2011-07-21 18:41:05 --> Hooks Class Initialized
DEBUG - 2011-07-21 18:41:05 --> Utf8 Class Initialized
DEBUG - 2011-07-21 18:41:05 --> UTF-8 Support Enabled
DEBUG - 2011-07-21 18:41:05 --> URI Class Initialized
DEBUG - 2011-07-21 18:41:05 --> Router Class Initialized
ERROR - 2011-07-21 18:41:05 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-21 18:41:07 --> Config Class Initialized
DEBUG - 2011-07-21 18:41:07 --> Hooks Class Initialized
DEBUG - 2011-07-21 18:41:07 --> Utf8 Class Initialized
DEBUG - 2011-07-21 18:41:07 --> UTF-8 Support Enabled
DEBUG - 2011-07-21 18:41:07 --> URI Class Initialized
DEBUG - 2011-07-21 18:41:07 --> Router Class Initialized
DEBUG - 2011-07-21 18:41:07 --> Output Class Initialized
DEBUG - 2011-07-21 18:41:07 --> Input Class Initialized
DEBUG - 2011-07-21 18:41:07 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-21 18:41:07 --> Language Class Initialized
DEBUG - 2011-07-21 18:41:07 --> Loader Class Initialized
DEBUG - 2011-07-21 18:41:07 --> Controller Class Initialized
DEBUG - 2011-07-21 18:41:07 --> Model Class Initialized
DEBUG - 2011-07-21 18:41:07 --> Model Class Initialized
DEBUG - 2011-07-21 18:41:07 --> Model Class Initialized
DEBUG - 2011-07-21 18:41:07 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-21 18:41:07 --> Database Driver Class Initialized
DEBUG - 2011-07-21 18:41:07 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-21 18:41:07 --> Helper loaded: url_helper
DEBUG - 2011-07-21 18:41:07 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-21 18:41:07 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-21 18:41:07 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-21 18:41:07 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-21 18:41:07 --> Final output sent to browser
DEBUG - 2011-07-21 18:41:07 --> Total execution time: 0.0824
DEBUG - 2011-07-21 18:41:10 --> Config Class Initialized
DEBUG - 2011-07-21 18:41:10 --> Hooks Class Initialized
DEBUG - 2011-07-21 18:41:10 --> Utf8 Class Initialized
DEBUG - 2011-07-21 18:41:10 --> UTF-8 Support Enabled
DEBUG - 2011-07-21 18:41:10 --> URI Class Initialized
DEBUG - 2011-07-21 18:41:10 --> Router Class Initialized
DEBUG - 2011-07-21 18:41:10 --> Output Class Initialized
DEBUG - 2011-07-21 18:41:10 --> Input Class Initialized
DEBUG - 2011-07-21 18:41:10 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-21 18:41:10 --> Language Class Initialized
DEBUG - 2011-07-21 18:41:10 --> Loader Class Initialized
DEBUG - 2011-07-21 18:41:10 --> Controller Class Initialized
DEBUG - 2011-07-21 18:41:10 --> Model Class Initialized
DEBUG - 2011-07-21 18:41:10 --> Model Class Initialized
DEBUG - 2011-07-21 18:41:10 --> Model Class Initialized
DEBUG - 2011-07-21 18:41:10 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-21 18:41:10 --> Database Driver Class Initialized
DEBUG - 2011-07-21 18:41:10 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-21 18:41:10 --> Helper loaded: url_helper
DEBUG - 2011-07-21 18:41:10 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-21 18:41:10 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-21 18:41:10 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-21 18:41:10 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-21 18:41:10 --> Final output sent to browser
DEBUG - 2011-07-21 18:41:10 --> Total execution time: 0.3238
DEBUG - 2011-07-21 18:41:11 --> Config Class Initialized
DEBUG - 2011-07-21 18:41:11 --> Hooks Class Initialized
DEBUG - 2011-07-21 18:41:11 --> Utf8 Class Initialized
DEBUG - 2011-07-21 18:41:11 --> UTF-8 Support Enabled
DEBUG - 2011-07-21 18:41:11 --> URI Class Initialized
DEBUG - 2011-07-21 18:41:11 --> Router Class Initialized
DEBUG - 2011-07-21 18:41:11 --> Output Class Initialized
DEBUG - 2011-07-21 18:41:11 --> Input Class Initialized
DEBUG - 2011-07-21 18:41:11 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-21 18:41:11 --> Language Class Initialized
DEBUG - 2011-07-21 18:41:11 --> Loader Class Initialized
DEBUG - 2011-07-21 18:41:11 --> Controller Class Initialized
DEBUG - 2011-07-21 18:41:11 --> Model Class Initialized
DEBUG - 2011-07-21 18:41:11 --> Model Class Initialized
DEBUG - 2011-07-21 18:41:11 --> Model Class Initialized
DEBUG - 2011-07-21 18:41:11 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-21 18:41:11 --> Database Driver Class Initialized
DEBUG - 2011-07-21 18:41:11 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-21 18:41:11 --> Helper loaded: url_helper
DEBUG - 2011-07-21 18:41:11 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-21 18:41:11 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-21 18:41:11 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-21 18:41:11 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-21 18:41:11 --> Final output sent to browser
DEBUG - 2011-07-21 18:41:11 --> Total execution time: 0.0896
DEBUG - 2011-07-21 18:41:11 --> Config Class Initialized
DEBUG - 2011-07-21 18:41:11 --> Hooks Class Initialized
DEBUG - 2011-07-21 18:41:11 --> Utf8 Class Initialized
DEBUG - 2011-07-21 18:41:11 --> UTF-8 Support Enabled
DEBUG - 2011-07-21 18:41:11 --> URI Class Initialized
DEBUG - 2011-07-21 18:41:11 --> Router Class Initialized
ERROR - 2011-07-21 18:41:11 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-21 18:41:15 --> Config Class Initialized
DEBUG - 2011-07-21 18:41:15 --> Hooks Class Initialized
DEBUG - 2011-07-21 18:41:15 --> Utf8 Class Initialized
DEBUG - 2011-07-21 18:41:15 --> UTF-8 Support Enabled
DEBUG - 2011-07-21 18:41:15 --> URI Class Initialized
DEBUG - 2011-07-21 18:41:15 --> Router Class Initialized
DEBUG - 2011-07-21 18:41:15 --> Output Class Initialized
DEBUG - 2011-07-21 18:41:15 --> Input Class Initialized
DEBUG - 2011-07-21 18:41:15 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-21 18:41:15 --> Language Class Initialized
DEBUG - 2011-07-21 18:41:15 --> Loader Class Initialized
DEBUG - 2011-07-21 18:41:15 --> Controller Class Initialized
DEBUG - 2011-07-21 18:41:15 --> Model Class Initialized
DEBUG - 2011-07-21 18:41:15 --> Model Class Initialized
DEBUG - 2011-07-21 18:41:15 --> Model Class Initialized
DEBUG - 2011-07-21 18:41:15 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-21 18:41:15 --> Database Driver Class Initialized
DEBUG - 2011-07-21 18:41:16 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-21 18:41:16 --> Helper loaded: url_helper
DEBUG - 2011-07-21 18:41:16 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-21 18:41:16 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-21 18:41:16 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-21 18:41:16 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-21 18:41:16 --> Final output sent to browser
DEBUG - 2011-07-21 18:41:16 --> Total execution time: 0.4567
DEBUG - 2011-07-21 18:41:17 --> Config Class Initialized
DEBUG - 2011-07-21 18:41:17 --> Hooks Class Initialized
DEBUG - 2011-07-21 18:41:17 --> Utf8 Class Initialized
DEBUG - 2011-07-21 18:41:17 --> UTF-8 Support Enabled
DEBUG - 2011-07-21 18:41:17 --> URI Class Initialized
DEBUG - 2011-07-21 18:41:17 --> Router Class Initialized
DEBUG - 2011-07-21 18:41:17 --> Output Class Initialized
DEBUG - 2011-07-21 18:41:17 --> Input Class Initialized
DEBUG - 2011-07-21 18:41:17 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-21 18:41:17 --> Language Class Initialized
DEBUG - 2011-07-21 18:41:17 --> Loader Class Initialized
DEBUG - 2011-07-21 18:41:17 --> Controller Class Initialized
DEBUG - 2011-07-21 18:41:17 --> Model Class Initialized
DEBUG - 2011-07-21 18:41:17 --> Model Class Initialized
DEBUG - 2011-07-21 18:41:17 --> Model Class Initialized
DEBUG - 2011-07-21 18:41:17 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-21 18:41:17 --> Database Driver Class Initialized
DEBUG - 2011-07-21 18:41:17 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-21 18:41:17 --> Helper loaded: url_helper
DEBUG - 2011-07-21 18:41:17 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-21 18:41:17 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-21 18:41:17 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-21 18:41:17 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-21 18:41:17 --> Final output sent to browser
DEBUG - 2011-07-21 18:41:17 --> Total execution time: 0.0509
DEBUG - 2011-07-21 18:41:17 --> Config Class Initialized
DEBUG - 2011-07-21 18:41:17 --> Hooks Class Initialized
DEBUG - 2011-07-21 18:41:17 --> Utf8 Class Initialized
DEBUG - 2011-07-21 18:41:17 --> UTF-8 Support Enabled
DEBUG - 2011-07-21 18:41:17 --> URI Class Initialized
DEBUG - 2011-07-21 18:41:17 --> Router Class Initialized
ERROR - 2011-07-21 18:41:17 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-21 18:41:23 --> Config Class Initialized
DEBUG - 2011-07-21 18:41:23 --> Hooks Class Initialized
DEBUG - 2011-07-21 18:41:23 --> Utf8 Class Initialized
DEBUG - 2011-07-21 18:41:23 --> UTF-8 Support Enabled
DEBUG - 2011-07-21 18:41:23 --> URI Class Initialized
DEBUG - 2011-07-21 18:41:23 --> Router Class Initialized
DEBUG - 2011-07-21 18:41:23 --> Output Class Initialized
DEBUG - 2011-07-21 18:41:23 --> Input Class Initialized
DEBUG - 2011-07-21 18:41:23 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-21 18:41:23 --> Language Class Initialized
DEBUG - 2011-07-21 18:41:23 --> Loader Class Initialized
DEBUG - 2011-07-21 18:41:23 --> Controller Class Initialized
DEBUG - 2011-07-21 18:41:23 --> Model Class Initialized
DEBUG - 2011-07-21 18:41:23 --> Model Class Initialized
DEBUG - 2011-07-21 18:41:23 --> Model Class Initialized
DEBUG - 2011-07-21 18:41:23 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-21 18:41:23 --> Database Driver Class Initialized
DEBUG - 2011-07-21 18:41:23 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-21 18:41:23 --> Helper loaded: url_helper
DEBUG - 2011-07-21 18:41:23 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-21 18:41:23 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-21 18:41:23 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-21 18:41:23 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-21 18:41:23 --> Final output sent to browser
DEBUG - 2011-07-21 18:41:23 --> Total execution time: 0.2430
DEBUG - 2011-07-21 18:41:24 --> Config Class Initialized
DEBUG - 2011-07-21 18:41:24 --> Hooks Class Initialized
DEBUG - 2011-07-21 18:41:24 --> Utf8 Class Initialized
DEBUG - 2011-07-21 18:41:24 --> UTF-8 Support Enabled
DEBUG - 2011-07-21 18:41:24 --> URI Class Initialized
DEBUG - 2011-07-21 18:41:24 --> Router Class Initialized
DEBUG - 2011-07-21 18:41:24 --> Output Class Initialized
DEBUG - 2011-07-21 18:41:24 --> Input Class Initialized
DEBUG - 2011-07-21 18:41:24 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-21 18:41:24 --> Language Class Initialized
DEBUG - 2011-07-21 18:41:24 --> Loader Class Initialized
DEBUG - 2011-07-21 18:41:24 --> Controller Class Initialized
DEBUG - 2011-07-21 18:41:24 --> Model Class Initialized
DEBUG - 2011-07-21 18:41:24 --> Model Class Initialized
DEBUG - 2011-07-21 18:41:24 --> Model Class Initialized
DEBUG - 2011-07-21 18:41:24 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-21 18:41:24 --> Database Driver Class Initialized
DEBUG - 2011-07-21 18:41:24 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-21 18:41:24 --> Helper loaded: url_helper
DEBUG - 2011-07-21 18:41:24 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-21 18:41:24 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-21 18:41:24 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-21 18:41:24 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-21 18:41:24 --> Final output sent to browser
DEBUG - 2011-07-21 18:41:24 --> Total execution time: 0.0752
DEBUG - 2011-07-21 18:41:25 --> Config Class Initialized
DEBUG - 2011-07-21 18:41:25 --> Hooks Class Initialized
DEBUG - 2011-07-21 18:41:25 --> Utf8 Class Initialized
DEBUG - 2011-07-21 18:41:25 --> UTF-8 Support Enabled
DEBUG - 2011-07-21 18:41:25 --> URI Class Initialized
DEBUG - 2011-07-21 18:41:25 --> Router Class Initialized
ERROR - 2011-07-21 18:41:25 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-21 18:41:30 --> Config Class Initialized
DEBUG - 2011-07-21 18:41:30 --> Hooks Class Initialized
DEBUG - 2011-07-21 18:41:30 --> Utf8 Class Initialized
DEBUG - 2011-07-21 18:41:30 --> UTF-8 Support Enabled
DEBUG - 2011-07-21 18:41:30 --> URI Class Initialized
DEBUG - 2011-07-21 18:41:30 --> Router Class Initialized
DEBUG - 2011-07-21 18:41:30 --> Output Class Initialized
DEBUG - 2011-07-21 18:41:30 --> Input Class Initialized
DEBUG - 2011-07-21 18:41:30 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-21 18:41:30 --> Language Class Initialized
DEBUG - 2011-07-21 18:41:30 --> Loader Class Initialized
DEBUG - 2011-07-21 18:41:30 --> Controller Class Initialized
DEBUG - 2011-07-21 18:41:30 --> Model Class Initialized
DEBUG - 2011-07-21 18:41:30 --> Model Class Initialized
DEBUG - 2011-07-21 18:41:30 --> Model Class Initialized
DEBUG - 2011-07-21 18:41:30 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-21 18:41:30 --> Database Driver Class Initialized
DEBUG - 2011-07-21 18:41:30 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-21 18:41:30 --> Helper loaded: url_helper
DEBUG - 2011-07-21 18:41:30 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-21 18:41:30 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-21 18:41:30 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-21 18:41:30 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-21 18:41:30 --> Final output sent to browser
DEBUG - 2011-07-21 18:41:30 --> Total execution time: 0.2583
DEBUG - 2011-07-21 18:41:33 --> Config Class Initialized
DEBUG - 2011-07-21 18:41:33 --> Hooks Class Initialized
DEBUG - 2011-07-21 18:41:33 --> Utf8 Class Initialized
DEBUG - 2011-07-21 18:41:33 --> UTF-8 Support Enabled
DEBUG - 2011-07-21 18:41:33 --> URI Class Initialized
DEBUG - 2011-07-21 18:41:33 --> Router Class Initialized
ERROR - 2011-07-21 18:41:33 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-21 18:41:35 --> Config Class Initialized
DEBUG - 2011-07-21 18:41:35 --> Hooks Class Initialized
DEBUG - 2011-07-21 18:41:35 --> Utf8 Class Initialized
DEBUG - 2011-07-21 18:41:35 --> UTF-8 Support Enabled
DEBUG - 2011-07-21 18:41:35 --> URI Class Initialized
DEBUG - 2011-07-21 18:41:35 --> Router Class Initialized
DEBUG - 2011-07-21 18:41:35 --> Output Class Initialized
DEBUG - 2011-07-21 18:41:35 --> Input Class Initialized
DEBUG - 2011-07-21 18:41:35 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-21 18:41:35 --> Language Class Initialized
DEBUG - 2011-07-21 18:41:35 --> Loader Class Initialized
DEBUG - 2011-07-21 18:41:35 --> Controller Class Initialized
DEBUG - 2011-07-21 18:41:35 --> Model Class Initialized
DEBUG - 2011-07-21 18:41:35 --> Model Class Initialized
DEBUG - 2011-07-21 18:41:35 --> Model Class Initialized
DEBUG - 2011-07-21 18:41:35 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-21 18:41:35 --> Database Driver Class Initialized
DEBUG - 2011-07-21 18:41:35 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-21 18:41:35 --> Helper loaded: url_helper
DEBUG - 2011-07-21 18:41:35 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-21 18:41:35 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-21 18:41:35 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-21 18:41:35 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-21 18:41:35 --> Final output sent to browser
DEBUG - 2011-07-21 18:41:35 --> Total execution time: 0.2908
DEBUG - 2011-07-21 18:41:38 --> Config Class Initialized
DEBUG - 2011-07-21 18:41:38 --> Hooks Class Initialized
DEBUG - 2011-07-21 18:41:38 --> Utf8 Class Initialized
DEBUG - 2011-07-21 18:41:38 --> UTF-8 Support Enabled
DEBUG - 2011-07-21 18:41:38 --> URI Class Initialized
DEBUG - 2011-07-21 18:41:38 --> Router Class Initialized
ERROR - 2011-07-21 18:41:38 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-21 18:41:55 --> Config Class Initialized
DEBUG - 2011-07-21 18:41:55 --> Hooks Class Initialized
DEBUG - 2011-07-21 18:41:55 --> Utf8 Class Initialized
DEBUG - 2011-07-21 18:41:55 --> UTF-8 Support Enabled
DEBUG - 2011-07-21 18:41:55 --> URI Class Initialized
DEBUG - 2011-07-21 18:41:55 --> Router Class Initialized
DEBUG - 2011-07-21 18:41:55 --> Output Class Initialized
DEBUG - 2011-07-21 18:41:55 --> Input Class Initialized
DEBUG - 2011-07-21 18:41:55 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-21 18:41:55 --> Language Class Initialized
DEBUG - 2011-07-21 18:41:55 --> Loader Class Initialized
DEBUG - 2011-07-21 18:41:55 --> Controller Class Initialized
DEBUG - 2011-07-21 18:41:55 --> Model Class Initialized
DEBUG - 2011-07-21 18:41:55 --> Model Class Initialized
DEBUG - 2011-07-21 18:41:55 --> Model Class Initialized
DEBUG - 2011-07-21 18:41:55 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-21 18:41:55 --> Database Driver Class Initialized
DEBUG - 2011-07-21 18:41:55 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-21 18:41:55 --> Helper loaded: url_helper
DEBUG - 2011-07-21 18:41:55 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-21 18:41:55 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-21 18:41:55 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-21 18:41:55 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-21 18:41:55 --> Final output sent to browser
DEBUG - 2011-07-21 18:41:55 --> Total execution time: 0.2770
DEBUG - 2011-07-21 18:41:57 --> Config Class Initialized
DEBUG - 2011-07-21 18:41:57 --> Hooks Class Initialized
DEBUG - 2011-07-21 18:41:57 --> Utf8 Class Initialized
DEBUG - 2011-07-21 18:41:57 --> UTF-8 Support Enabled
DEBUG - 2011-07-21 18:41:57 --> URI Class Initialized
DEBUG - 2011-07-21 18:41:57 --> Router Class Initialized
ERROR - 2011-07-21 18:41:57 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-21 18:42:35 --> Config Class Initialized
DEBUG - 2011-07-21 18:42:35 --> Hooks Class Initialized
DEBUG - 2011-07-21 18:42:35 --> Utf8 Class Initialized
DEBUG - 2011-07-21 18:42:35 --> UTF-8 Support Enabled
DEBUG - 2011-07-21 18:42:35 --> URI Class Initialized
DEBUG - 2011-07-21 18:42:35 --> Router Class Initialized
DEBUG - 2011-07-21 18:42:35 --> Output Class Initialized
DEBUG - 2011-07-21 18:42:35 --> Input Class Initialized
DEBUG - 2011-07-21 18:42:35 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-21 18:42:35 --> Language Class Initialized
DEBUG - 2011-07-21 18:42:35 --> Loader Class Initialized
DEBUG - 2011-07-21 18:42:35 --> Controller Class Initialized
DEBUG - 2011-07-21 18:42:35 --> Model Class Initialized
DEBUG - 2011-07-21 18:42:35 --> Model Class Initialized
DEBUG - 2011-07-21 18:42:35 --> Model Class Initialized
DEBUG - 2011-07-21 18:42:35 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-21 18:42:35 --> Database Driver Class Initialized
DEBUG - 2011-07-21 18:42:35 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-21 18:42:35 --> Helper loaded: url_helper
DEBUG - 2011-07-21 18:42:35 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-21 18:42:35 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-21 18:42:35 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-21 18:42:35 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-21 18:42:35 --> Final output sent to browser
DEBUG - 2011-07-21 18:42:35 --> Total execution time: 0.0590
DEBUG - 2011-07-21 18:42:49 --> Config Class Initialized
DEBUG - 2011-07-21 18:42:49 --> Hooks Class Initialized
DEBUG - 2011-07-21 18:42:49 --> Utf8 Class Initialized
DEBUG - 2011-07-21 18:42:49 --> UTF-8 Support Enabled
DEBUG - 2011-07-21 18:42:49 --> URI Class Initialized
DEBUG - 2011-07-21 18:42:49 --> Router Class Initialized
DEBUG - 2011-07-21 18:42:49 --> Output Class Initialized
DEBUG - 2011-07-21 18:42:49 --> Input Class Initialized
DEBUG - 2011-07-21 18:42:49 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-21 18:42:49 --> Language Class Initialized
DEBUG - 2011-07-21 18:42:49 --> Loader Class Initialized
DEBUG - 2011-07-21 18:42:49 --> Controller Class Initialized
DEBUG - 2011-07-21 18:42:49 --> Model Class Initialized
DEBUG - 2011-07-21 18:42:49 --> Model Class Initialized
DEBUG - 2011-07-21 18:42:49 --> Model Class Initialized
DEBUG - 2011-07-21 18:42:49 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-21 18:42:49 --> Database Driver Class Initialized
DEBUG - 2011-07-21 18:42:49 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-21 18:42:49 --> Helper loaded: url_helper
DEBUG - 2011-07-21 18:42:49 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-21 18:42:49 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-21 18:42:49 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-21 18:42:49 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-21 18:42:49 --> Final output sent to browser
DEBUG - 2011-07-21 18:42:49 --> Total execution time: 0.0541
DEBUG - 2011-07-21 18:43:00 --> Config Class Initialized
DEBUG - 2011-07-21 18:43:00 --> Hooks Class Initialized
DEBUG - 2011-07-21 18:43:00 --> Utf8 Class Initialized
DEBUG - 2011-07-21 18:43:00 --> UTF-8 Support Enabled
DEBUG - 2011-07-21 18:43:00 --> URI Class Initialized
DEBUG - 2011-07-21 18:43:00 --> Router Class Initialized
DEBUG - 2011-07-21 18:43:00 --> Output Class Initialized
DEBUG - 2011-07-21 18:43:00 --> Input Class Initialized
DEBUG - 2011-07-21 18:43:00 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-21 18:43:00 --> Language Class Initialized
DEBUG - 2011-07-21 18:43:00 --> Loader Class Initialized
DEBUG - 2011-07-21 18:43:00 --> Controller Class Initialized
DEBUG - 2011-07-21 18:43:00 --> Model Class Initialized
DEBUG - 2011-07-21 18:43:00 --> Model Class Initialized
DEBUG - 2011-07-21 18:43:00 --> Model Class Initialized
DEBUG - 2011-07-21 18:43:00 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-21 18:43:00 --> Database Driver Class Initialized
DEBUG - 2011-07-21 18:43:00 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-21 18:43:00 --> Helper loaded: url_helper
DEBUG - 2011-07-21 18:43:00 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-21 18:43:00 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-21 18:43:00 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-21 18:43:00 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-21 18:43:00 --> Final output sent to browser
DEBUG - 2011-07-21 18:43:00 --> Total execution time: 0.0892
DEBUG - 2011-07-21 18:45:07 --> Config Class Initialized
DEBUG - 2011-07-21 18:45:07 --> Hooks Class Initialized
DEBUG - 2011-07-21 18:45:07 --> Utf8 Class Initialized
DEBUG - 2011-07-21 18:45:07 --> UTF-8 Support Enabled
DEBUG - 2011-07-21 18:45:07 --> URI Class Initialized
DEBUG - 2011-07-21 18:45:07 --> Router Class Initialized
DEBUG - 2011-07-21 18:45:07 --> Output Class Initialized
DEBUG - 2011-07-21 18:45:07 --> Input Class Initialized
DEBUG - 2011-07-21 18:45:07 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-21 18:45:07 --> Language Class Initialized
DEBUG - 2011-07-21 18:45:07 --> Loader Class Initialized
DEBUG - 2011-07-21 18:45:07 --> Controller Class Initialized
DEBUG - 2011-07-21 18:45:07 --> Model Class Initialized
DEBUG - 2011-07-21 18:45:07 --> Model Class Initialized
DEBUG - 2011-07-21 18:45:07 --> Model Class Initialized
DEBUG - 2011-07-21 18:45:07 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-21 18:45:07 --> Database Driver Class Initialized
DEBUG - 2011-07-21 18:45:07 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-21 18:45:07 --> Helper loaded: url_helper
DEBUG - 2011-07-21 18:45:07 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-21 18:45:07 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-21 18:45:07 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-21 18:45:07 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-21 18:45:07 --> Final output sent to browser
DEBUG - 2011-07-21 18:45:07 --> Total execution time: 0.1541
DEBUG - 2011-07-21 18:45:09 --> Config Class Initialized
DEBUG - 2011-07-21 18:45:09 --> Hooks Class Initialized
DEBUG - 2011-07-21 18:45:09 --> Utf8 Class Initialized
DEBUG - 2011-07-21 18:45:09 --> UTF-8 Support Enabled
DEBUG - 2011-07-21 18:45:09 --> URI Class Initialized
DEBUG - 2011-07-21 18:45:09 --> Router Class Initialized
ERROR - 2011-07-21 18:45:09 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-21 18:55:33 --> Config Class Initialized
DEBUG - 2011-07-21 18:55:33 --> Hooks Class Initialized
DEBUG - 2011-07-21 18:55:33 --> Utf8 Class Initialized
DEBUG - 2011-07-21 18:55:33 --> UTF-8 Support Enabled
DEBUG - 2011-07-21 18:55:33 --> URI Class Initialized
DEBUG - 2011-07-21 18:55:33 --> Router Class Initialized
DEBUG - 2011-07-21 18:55:33 --> Output Class Initialized
DEBUG - 2011-07-21 18:55:33 --> Input Class Initialized
DEBUG - 2011-07-21 18:55:33 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-21 18:55:33 --> Language Class Initialized
DEBUG - 2011-07-21 18:55:33 --> Loader Class Initialized
DEBUG - 2011-07-21 18:55:33 --> Controller Class Initialized
DEBUG - 2011-07-21 18:55:33 --> Model Class Initialized
DEBUG - 2011-07-21 18:55:33 --> Model Class Initialized
DEBUG - 2011-07-21 18:55:33 --> Model Class Initialized
DEBUG - 2011-07-21 18:55:33 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-21 18:55:33 --> Database Driver Class Initialized
DEBUG - 2011-07-21 18:55:33 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-21 18:55:33 --> Helper loaded: url_helper
DEBUG - 2011-07-21 18:55:33 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-21 18:55:33 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-21 18:55:33 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-21 18:55:33 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-21 18:55:33 --> Final output sent to browser
DEBUG - 2011-07-21 18:55:33 --> Total execution time: 0.0879
DEBUG - 2011-07-21 20:03:23 --> Config Class Initialized
DEBUG - 2011-07-21 20:03:23 --> Hooks Class Initialized
DEBUG - 2011-07-21 20:03:23 --> Utf8 Class Initialized
DEBUG - 2011-07-21 20:03:23 --> UTF-8 Support Enabled
DEBUG - 2011-07-21 20:03:23 --> URI Class Initialized
DEBUG - 2011-07-21 20:03:23 --> Router Class Initialized
DEBUG - 2011-07-21 20:03:23 --> Output Class Initialized
DEBUG - 2011-07-21 20:03:23 --> Input Class Initialized
DEBUG - 2011-07-21 20:03:23 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-21 20:03:23 --> Language Class Initialized
DEBUG - 2011-07-21 20:03:23 --> Loader Class Initialized
DEBUG - 2011-07-21 20:03:23 --> Controller Class Initialized
ERROR - 2011-07-21 20:03:23 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-21 20:03:23 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-21 20:03:23 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-21 20:03:23 --> Model Class Initialized
DEBUG - 2011-07-21 20:03:23 --> Model Class Initialized
DEBUG - 2011-07-21 20:03:23 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-21 20:03:23 --> Database Driver Class Initialized
DEBUG - 2011-07-21 20:03:23 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-21 20:03:23 --> Helper loaded: url_helper
DEBUG - 2011-07-21 20:03:23 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-21 20:03:23 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-21 20:03:23 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-21 20:03:23 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-21 20:03:23 --> Final output sent to browser
DEBUG - 2011-07-21 20:03:23 --> Total execution time: 0.3150
DEBUG - 2011-07-21 20:03:25 --> Config Class Initialized
DEBUG - 2011-07-21 20:03:25 --> Hooks Class Initialized
DEBUG - 2011-07-21 20:03:25 --> Utf8 Class Initialized
DEBUG - 2011-07-21 20:03:25 --> UTF-8 Support Enabled
DEBUG - 2011-07-21 20:03:25 --> URI Class Initialized
DEBUG - 2011-07-21 20:03:25 --> Router Class Initialized
DEBUG - 2011-07-21 20:03:25 --> Output Class Initialized
DEBUG - 2011-07-21 20:03:25 --> Input Class Initialized
DEBUG - 2011-07-21 20:03:25 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-21 20:03:25 --> Language Class Initialized
DEBUG - 2011-07-21 20:03:25 --> Loader Class Initialized
DEBUG - 2011-07-21 20:03:25 --> Controller Class Initialized
DEBUG - 2011-07-21 20:03:25 --> Model Class Initialized
DEBUG - 2011-07-21 20:03:25 --> Model Class Initialized
DEBUG - 2011-07-21 20:03:25 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-21 20:03:25 --> Database Driver Class Initialized
DEBUG - 2011-07-21 20:03:25 --> Final output sent to browser
DEBUG - 2011-07-21 20:03:25 --> Total execution time: 0.7138
DEBUG - 2011-07-21 20:03:26 --> Config Class Initialized
DEBUG - 2011-07-21 20:03:26 --> Hooks Class Initialized
DEBUG - 2011-07-21 20:03:26 --> Utf8 Class Initialized
DEBUG - 2011-07-21 20:03:26 --> UTF-8 Support Enabled
DEBUG - 2011-07-21 20:03:26 --> URI Class Initialized
DEBUG - 2011-07-21 20:03:26 --> Router Class Initialized
DEBUG - 2011-07-21 20:03:26 --> Output Class Initialized
DEBUG - 2011-07-21 20:03:26 --> Input Class Initialized
DEBUG - 2011-07-21 20:03:26 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-21 20:03:26 --> Language Class Initialized
DEBUG - 2011-07-21 20:03:26 --> Loader Class Initialized
DEBUG - 2011-07-21 20:03:26 --> Controller Class Initialized
DEBUG - 2011-07-21 20:03:26 --> Model Class Initialized
DEBUG - 2011-07-21 20:03:26 --> Model Class Initialized
DEBUG - 2011-07-21 20:03:26 --> Model Class Initialized
DEBUG - 2011-07-21 20:03:26 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-21 20:03:26 --> Database Driver Class Initialized
DEBUG - 2011-07-21 20:03:26 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-21 20:03:26 --> Helper loaded: url_helper
DEBUG - 2011-07-21 20:03:26 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-21 20:03:26 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-21 20:03:26 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-21 20:03:26 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-21 20:03:26 --> Final output sent to browser
DEBUG - 2011-07-21 20:03:26 --> Total execution time: 0.3602
DEBUG - 2011-07-21 20:03:29 --> Config Class Initialized
DEBUG - 2011-07-21 20:03:29 --> Hooks Class Initialized
DEBUG - 2011-07-21 20:03:29 --> Utf8 Class Initialized
DEBUG - 2011-07-21 20:03:29 --> UTF-8 Support Enabled
DEBUG - 2011-07-21 20:03:29 --> URI Class Initialized
DEBUG - 2011-07-21 20:03:29 --> Router Class Initialized
ERROR - 2011-07-21 20:03:29 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-21 20:03:29 --> Config Class Initialized
DEBUG - 2011-07-21 20:03:29 --> Hooks Class Initialized
DEBUG - 2011-07-21 20:03:29 --> Utf8 Class Initialized
DEBUG - 2011-07-21 20:03:29 --> UTF-8 Support Enabled
DEBUG - 2011-07-21 20:03:29 --> URI Class Initialized
DEBUG - 2011-07-21 20:03:29 --> Router Class Initialized
ERROR - 2011-07-21 20:03:29 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-21 20:05:30 --> Config Class Initialized
DEBUG - 2011-07-21 20:05:30 --> Hooks Class Initialized
DEBUG - 2011-07-21 20:05:30 --> Utf8 Class Initialized
DEBUG - 2011-07-21 20:05:30 --> UTF-8 Support Enabled
DEBUG - 2011-07-21 20:05:30 --> URI Class Initialized
DEBUG - 2011-07-21 20:05:30 --> Router Class Initialized
DEBUG - 2011-07-21 20:05:30 --> Output Class Initialized
DEBUG - 2011-07-21 20:05:30 --> Input Class Initialized
DEBUG - 2011-07-21 20:05:30 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-21 20:05:30 --> Language Class Initialized
DEBUG - 2011-07-21 20:05:30 --> Loader Class Initialized
DEBUG - 2011-07-21 20:05:30 --> Controller Class Initialized
ERROR - 2011-07-21 20:05:30 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-21 20:05:30 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-21 20:05:30 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-21 20:05:30 --> Model Class Initialized
DEBUG - 2011-07-21 20:05:30 --> Model Class Initialized
DEBUG - 2011-07-21 20:05:30 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-21 20:05:30 --> Database Driver Class Initialized
DEBUG - 2011-07-21 20:05:30 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-21 20:05:30 --> Helper loaded: url_helper
DEBUG - 2011-07-21 20:05:30 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-21 20:05:30 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-21 20:05:30 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-21 20:05:30 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-21 20:05:30 --> Final output sent to browser
DEBUG - 2011-07-21 20:05:30 --> Total execution time: 0.1479
DEBUG - 2011-07-21 20:05:32 --> Config Class Initialized
DEBUG - 2011-07-21 20:05:32 --> Hooks Class Initialized
DEBUG - 2011-07-21 20:05:32 --> Utf8 Class Initialized
DEBUG - 2011-07-21 20:05:32 --> UTF-8 Support Enabled
DEBUG - 2011-07-21 20:05:32 --> URI Class Initialized
DEBUG - 2011-07-21 20:05:32 --> Router Class Initialized
DEBUG - 2011-07-21 20:05:32 --> Output Class Initialized
DEBUG - 2011-07-21 20:05:32 --> Input Class Initialized
DEBUG - 2011-07-21 20:05:32 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-21 20:05:32 --> Language Class Initialized
DEBUG - 2011-07-21 20:05:32 --> Loader Class Initialized
DEBUG - 2011-07-21 20:05:32 --> Controller Class Initialized
DEBUG - 2011-07-21 20:05:32 --> Model Class Initialized
DEBUG - 2011-07-21 20:05:32 --> Model Class Initialized
DEBUG - 2011-07-21 20:05:32 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-21 20:05:32 --> Database Driver Class Initialized
DEBUG - 2011-07-21 20:05:33 --> Final output sent to browser
DEBUG - 2011-07-21 20:05:33 --> Total execution time: 1.1192
DEBUG - 2011-07-21 20:05:35 --> Config Class Initialized
DEBUG - 2011-07-21 20:05:35 --> Hooks Class Initialized
DEBUG - 2011-07-21 20:05:35 --> Utf8 Class Initialized
DEBUG - 2011-07-21 20:05:35 --> UTF-8 Support Enabled
DEBUG - 2011-07-21 20:05:35 --> URI Class Initialized
DEBUG - 2011-07-21 20:05:35 --> Router Class Initialized
ERROR - 2011-07-21 20:05:35 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-21 20:05:42 --> Config Class Initialized
DEBUG - 2011-07-21 20:05:42 --> Hooks Class Initialized
DEBUG - 2011-07-21 20:05:42 --> Utf8 Class Initialized
DEBUG - 2011-07-21 20:05:42 --> UTF-8 Support Enabled
DEBUG - 2011-07-21 20:05:42 --> URI Class Initialized
DEBUG - 2011-07-21 20:05:42 --> Router Class Initialized
DEBUG - 2011-07-21 20:05:42 --> Output Class Initialized
DEBUG - 2011-07-21 20:05:42 --> Input Class Initialized
DEBUG - 2011-07-21 20:05:42 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-21 20:05:42 --> Language Class Initialized
DEBUG - 2011-07-21 20:05:42 --> Loader Class Initialized
DEBUG - 2011-07-21 20:05:42 --> Controller Class Initialized
ERROR - 2011-07-21 20:05:42 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-21 20:05:42 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-21 20:05:42 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-21 20:05:42 --> Model Class Initialized
DEBUG - 2011-07-21 20:05:42 --> Model Class Initialized
DEBUG - 2011-07-21 20:05:42 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-21 20:05:42 --> Database Driver Class Initialized
DEBUG - 2011-07-21 20:05:42 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-21 20:05:42 --> Helper loaded: url_helper
DEBUG - 2011-07-21 20:05:42 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-21 20:05:42 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-21 20:05:42 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-21 20:05:42 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-21 20:05:42 --> Final output sent to browser
DEBUG - 2011-07-21 20:05:42 --> Total execution time: 0.1077
DEBUG - 2011-07-21 20:05:43 --> Config Class Initialized
DEBUG - 2011-07-21 20:05:43 --> Hooks Class Initialized
DEBUG - 2011-07-21 20:05:43 --> Utf8 Class Initialized
DEBUG - 2011-07-21 20:05:43 --> UTF-8 Support Enabled
DEBUG - 2011-07-21 20:05:43 --> URI Class Initialized
DEBUG - 2011-07-21 20:05:43 --> Router Class Initialized
DEBUG - 2011-07-21 20:05:43 --> Output Class Initialized
DEBUG - 2011-07-21 20:05:43 --> Input Class Initialized
DEBUG - 2011-07-21 20:05:43 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-21 20:05:43 --> Language Class Initialized
DEBUG - 2011-07-21 20:05:43 --> Loader Class Initialized
DEBUG - 2011-07-21 20:05:43 --> Controller Class Initialized
ERROR - 2011-07-21 20:05:43 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-21 20:05:43 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-21 20:05:43 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-21 20:05:43 --> Model Class Initialized
DEBUG - 2011-07-21 20:05:43 --> Model Class Initialized
DEBUG - 2011-07-21 20:05:43 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-21 20:05:43 --> Database Driver Class Initialized
DEBUG - 2011-07-21 20:05:43 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-21 20:05:43 --> Helper loaded: url_helper
DEBUG - 2011-07-21 20:05:43 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-21 20:05:43 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-21 20:05:43 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-21 20:05:43 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-21 20:05:43 --> Final output sent to browser
DEBUG - 2011-07-21 20:05:43 --> Total execution time: 0.0462
DEBUG - 2011-07-21 20:05:44 --> Config Class Initialized
DEBUG - 2011-07-21 20:05:44 --> Hooks Class Initialized
DEBUG - 2011-07-21 20:05:44 --> Utf8 Class Initialized
DEBUG - 2011-07-21 20:05:44 --> UTF-8 Support Enabled
DEBUG - 2011-07-21 20:05:44 --> URI Class Initialized
DEBUG - 2011-07-21 20:05:44 --> Router Class Initialized
DEBUG - 2011-07-21 20:05:44 --> Output Class Initialized
DEBUG - 2011-07-21 20:05:44 --> Input Class Initialized
DEBUG - 2011-07-21 20:05:44 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-21 20:05:44 --> Language Class Initialized
DEBUG - 2011-07-21 20:05:44 --> Loader Class Initialized
DEBUG - 2011-07-21 20:05:44 --> Controller Class Initialized
DEBUG - 2011-07-21 20:05:44 --> Model Class Initialized
DEBUG - 2011-07-21 20:05:44 --> Model Class Initialized
DEBUG - 2011-07-21 20:05:44 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-21 20:05:44 --> Database Driver Class Initialized
DEBUG - 2011-07-21 20:05:45 --> Final output sent to browser
DEBUG - 2011-07-21 20:05:45 --> Total execution time: 1.0646
DEBUG - 2011-07-21 20:05:47 --> Config Class Initialized
DEBUG - 2011-07-21 20:05:47 --> Hooks Class Initialized
DEBUG - 2011-07-21 20:05:47 --> Utf8 Class Initialized
DEBUG - 2011-07-21 20:05:47 --> UTF-8 Support Enabled
DEBUG - 2011-07-21 20:05:47 --> URI Class Initialized
DEBUG - 2011-07-21 20:05:47 --> Router Class Initialized
ERROR - 2011-07-21 20:05:47 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-21 20:05:54 --> Config Class Initialized
DEBUG - 2011-07-21 20:05:54 --> Hooks Class Initialized
DEBUG - 2011-07-21 20:05:54 --> Utf8 Class Initialized
DEBUG - 2011-07-21 20:05:54 --> UTF-8 Support Enabled
DEBUG - 2011-07-21 20:05:54 --> URI Class Initialized
DEBUG - 2011-07-21 20:05:54 --> Router Class Initialized
DEBUG - 2011-07-21 20:05:54 --> Output Class Initialized
DEBUG - 2011-07-21 20:05:54 --> Input Class Initialized
DEBUG - 2011-07-21 20:05:54 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-21 20:05:54 --> Language Class Initialized
DEBUG - 2011-07-21 20:05:54 --> Loader Class Initialized
DEBUG - 2011-07-21 20:05:54 --> Controller Class Initialized
ERROR - 2011-07-21 20:05:54 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-21 20:05:54 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-21 20:05:54 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-21 20:05:54 --> Model Class Initialized
DEBUG - 2011-07-21 20:05:54 --> Model Class Initialized
DEBUG - 2011-07-21 20:05:54 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-21 20:05:54 --> Database Driver Class Initialized
DEBUG - 2011-07-21 20:05:54 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-21 20:05:54 --> Helper loaded: url_helper
DEBUG - 2011-07-21 20:05:54 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-21 20:05:54 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-21 20:05:54 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-21 20:05:54 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-21 20:05:54 --> Final output sent to browser
DEBUG - 2011-07-21 20:05:54 --> Total execution time: 0.0459
DEBUG - 2011-07-21 20:05:55 --> Config Class Initialized
DEBUG - 2011-07-21 20:05:55 --> Hooks Class Initialized
DEBUG - 2011-07-21 20:05:55 --> Utf8 Class Initialized
DEBUG - 2011-07-21 20:05:55 --> UTF-8 Support Enabled
DEBUG - 2011-07-21 20:05:55 --> URI Class Initialized
DEBUG - 2011-07-21 20:05:55 --> Router Class Initialized
DEBUG - 2011-07-21 20:05:55 --> Output Class Initialized
DEBUG - 2011-07-21 20:05:55 --> Input Class Initialized
DEBUG - 2011-07-21 20:05:55 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-21 20:05:55 --> Language Class Initialized
DEBUG - 2011-07-21 20:05:55 --> Loader Class Initialized
DEBUG - 2011-07-21 20:05:55 --> Controller Class Initialized
DEBUG - 2011-07-21 20:05:55 --> Model Class Initialized
DEBUG - 2011-07-21 20:05:55 --> Model Class Initialized
DEBUG - 2011-07-21 20:05:55 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-21 20:05:55 --> Database Driver Class Initialized
DEBUG - 2011-07-21 20:05:55 --> Config Class Initialized
DEBUG - 2011-07-21 20:05:55 --> Hooks Class Initialized
DEBUG - 2011-07-21 20:05:55 --> Utf8 Class Initialized
DEBUG - 2011-07-21 20:05:55 --> UTF-8 Support Enabled
DEBUG - 2011-07-21 20:05:55 --> URI Class Initialized
DEBUG - 2011-07-21 20:05:55 --> Router Class Initialized
DEBUG - 2011-07-21 20:05:55 --> Output Class Initialized
DEBUG - 2011-07-21 20:05:55 --> Input Class Initialized
DEBUG - 2011-07-21 20:05:55 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-21 20:05:55 --> Language Class Initialized
DEBUG - 2011-07-21 20:05:55 --> Loader Class Initialized
DEBUG - 2011-07-21 20:05:55 --> Controller Class Initialized
ERROR - 2011-07-21 20:05:55 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-21 20:05:55 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-21 20:05:55 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-21 20:05:55 --> Model Class Initialized
DEBUG - 2011-07-21 20:05:55 --> Model Class Initialized
DEBUG - 2011-07-21 20:05:55 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-21 20:05:55 --> Database Driver Class Initialized
DEBUG - 2011-07-21 20:05:55 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-21 20:05:55 --> Helper loaded: url_helper
DEBUG - 2011-07-21 20:05:55 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-21 20:05:55 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-21 20:05:55 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-21 20:05:55 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-21 20:05:55 --> Final output sent to browser
DEBUG - 2011-07-21 20:05:55 --> Total execution time: 0.0418
DEBUG - 2011-07-21 20:05:56 --> Final output sent to browser
DEBUG - 2011-07-21 20:05:56 --> Total execution time: 0.6642
DEBUG - 2011-07-21 20:05:58 --> Config Class Initialized
DEBUG - 2011-07-21 20:05:58 --> Hooks Class Initialized
DEBUG - 2011-07-21 20:05:58 --> Utf8 Class Initialized
DEBUG - 2011-07-21 20:05:58 --> UTF-8 Support Enabled
DEBUG - 2011-07-21 20:05:58 --> URI Class Initialized
DEBUG - 2011-07-21 20:05:58 --> Router Class Initialized
ERROR - 2011-07-21 20:05:58 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-21 20:06:07 --> Config Class Initialized
DEBUG - 2011-07-21 20:06:07 --> Hooks Class Initialized
DEBUG - 2011-07-21 20:06:07 --> Utf8 Class Initialized
DEBUG - 2011-07-21 20:06:07 --> UTF-8 Support Enabled
DEBUG - 2011-07-21 20:06:07 --> URI Class Initialized
DEBUG - 2011-07-21 20:06:07 --> Router Class Initialized
DEBUG - 2011-07-21 20:06:07 --> Output Class Initialized
DEBUG - 2011-07-21 20:06:07 --> Input Class Initialized
DEBUG - 2011-07-21 20:06:07 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-21 20:06:07 --> Language Class Initialized
DEBUG - 2011-07-21 20:06:07 --> Loader Class Initialized
DEBUG - 2011-07-21 20:06:07 --> Controller Class Initialized
ERROR - 2011-07-21 20:06:07 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-21 20:06:07 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-21 20:06:07 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-21 20:06:07 --> Model Class Initialized
DEBUG - 2011-07-21 20:06:07 --> Model Class Initialized
DEBUG - 2011-07-21 20:06:07 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-21 20:06:07 --> Database Driver Class Initialized
DEBUG - 2011-07-21 20:06:07 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-21 20:06:07 --> Helper loaded: url_helper
DEBUG - 2011-07-21 20:06:07 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-21 20:06:07 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-21 20:06:07 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-21 20:06:07 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-21 20:06:07 --> Final output sent to browser
DEBUG - 2011-07-21 20:06:07 --> Total execution time: 0.0326
DEBUG - 2011-07-21 20:06:08 --> Config Class Initialized
DEBUG - 2011-07-21 20:06:08 --> Hooks Class Initialized
DEBUG - 2011-07-21 20:06:08 --> Utf8 Class Initialized
DEBUG - 2011-07-21 20:06:08 --> UTF-8 Support Enabled
DEBUG - 2011-07-21 20:06:08 --> URI Class Initialized
DEBUG - 2011-07-21 20:06:08 --> Router Class Initialized
DEBUG - 2011-07-21 20:06:08 --> Output Class Initialized
DEBUG - 2011-07-21 20:06:08 --> Input Class Initialized
DEBUG - 2011-07-21 20:06:08 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-21 20:06:08 --> Language Class Initialized
DEBUG - 2011-07-21 20:06:08 --> Loader Class Initialized
DEBUG - 2011-07-21 20:06:08 --> Controller Class Initialized
DEBUG - 2011-07-21 20:06:08 --> Model Class Initialized
DEBUG - 2011-07-21 20:06:08 --> Model Class Initialized
DEBUG - 2011-07-21 20:06:08 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-21 20:06:08 --> Config Class Initialized
DEBUG - 2011-07-21 20:06:08 --> Hooks Class Initialized
DEBUG - 2011-07-21 20:06:08 --> Utf8 Class Initialized
DEBUG - 2011-07-21 20:06:08 --> UTF-8 Support Enabled
DEBUG - 2011-07-21 20:06:08 --> URI Class Initialized
DEBUG - 2011-07-21 20:06:08 --> Router Class Initialized
DEBUG - 2011-07-21 20:06:08 --> Output Class Initialized
DEBUG - 2011-07-21 20:06:08 --> Input Class Initialized
DEBUG - 2011-07-21 20:06:08 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-21 20:06:08 --> Language Class Initialized
DEBUG - 2011-07-21 20:06:08 --> Database Driver Class Initialized
DEBUG - 2011-07-21 20:06:08 --> Loader Class Initialized
DEBUG - 2011-07-21 20:06:08 --> Controller Class Initialized
ERROR - 2011-07-21 20:06:08 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-21 20:06:08 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-21 20:06:08 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-21 20:06:08 --> Model Class Initialized
DEBUG - 2011-07-21 20:06:08 --> Model Class Initialized
DEBUG - 2011-07-21 20:06:08 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-21 20:06:08 --> Database Driver Class Initialized
DEBUG - 2011-07-21 20:06:08 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-21 20:06:08 --> Helper loaded: url_helper
DEBUG - 2011-07-21 20:06:08 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-21 20:06:08 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-21 20:06:08 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-21 20:06:08 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-21 20:06:08 --> Final output sent to browser
DEBUG - 2011-07-21 20:06:08 --> Total execution time: 0.0300
DEBUG - 2011-07-21 20:06:09 --> Final output sent to browser
DEBUG - 2011-07-21 20:06:09 --> Total execution time: 0.6745
DEBUG - 2011-07-21 20:06:11 --> Config Class Initialized
DEBUG - 2011-07-21 20:06:11 --> Hooks Class Initialized
DEBUG - 2011-07-21 20:06:11 --> Utf8 Class Initialized
DEBUG - 2011-07-21 20:06:11 --> UTF-8 Support Enabled
DEBUG - 2011-07-21 20:06:11 --> URI Class Initialized
DEBUG - 2011-07-21 20:06:11 --> Router Class Initialized
ERROR - 2011-07-21 20:06:11 --> 404 Page Not Found --> favicon.ico

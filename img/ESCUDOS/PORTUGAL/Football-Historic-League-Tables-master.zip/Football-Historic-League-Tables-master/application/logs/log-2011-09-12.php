<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2011-09-12 00:19:50 --> Config Class Initialized
DEBUG - 2011-09-12 00:19:50 --> Hooks Class Initialized
DEBUG - 2011-09-12 00:19:50 --> Utf8 Class Initialized
DEBUG - 2011-09-12 00:19:50 --> UTF-8 Support Enabled
DEBUG - 2011-09-12 00:19:50 --> URI Class Initialized
DEBUG - 2011-09-12 00:19:50 --> Router Class Initialized
DEBUG - 2011-09-12 00:19:50 --> Output Class Initialized
DEBUG - 2011-09-12 00:19:50 --> Input Class Initialized
DEBUG - 2011-09-12 00:19:50 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-12 00:19:50 --> Language Class Initialized
DEBUG - 2011-09-12 00:19:50 --> Loader Class Initialized
DEBUG - 2011-09-12 00:19:50 --> Controller Class Initialized
DEBUG - 2011-09-12 00:19:50 --> Model Class Initialized
DEBUG - 2011-09-12 00:19:50 --> Model Class Initialized
DEBUG - 2011-09-12 00:19:50 --> Model Class Initialized
DEBUG - 2011-09-12 00:19:50 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-12 00:19:50 --> Database Driver Class Initialized
DEBUG - 2011-09-12 00:19:50 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-12 00:19:50 --> Helper loaded: url_helper
DEBUG - 2011-09-12 00:19:50 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-12 00:19:50 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-12 00:19:50 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-12 00:19:50 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-12 00:19:50 --> Final output sent to browser
DEBUG - 2011-09-12 00:19:50 --> Total execution time: 0.2379
DEBUG - 2011-09-12 00:19:56 --> Config Class Initialized
DEBUG - 2011-09-12 00:19:56 --> Hooks Class Initialized
DEBUG - 2011-09-12 00:19:56 --> Utf8 Class Initialized
DEBUG - 2011-09-12 00:19:56 --> UTF-8 Support Enabled
DEBUG - 2011-09-12 00:19:56 --> URI Class Initialized
DEBUG - 2011-09-12 00:19:56 --> Router Class Initialized
ERROR - 2011-09-12 00:19:56 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-12 00:20:18 --> Config Class Initialized
DEBUG - 2011-09-12 00:20:18 --> Hooks Class Initialized
DEBUG - 2011-09-12 00:20:18 --> Utf8 Class Initialized
DEBUG - 2011-09-12 00:20:18 --> UTF-8 Support Enabled
DEBUG - 2011-09-12 00:20:18 --> URI Class Initialized
DEBUG - 2011-09-12 00:20:18 --> Router Class Initialized
DEBUG - 2011-09-12 00:20:18 --> Output Class Initialized
DEBUG - 2011-09-12 00:20:18 --> Input Class Initialized
DEBUG - 2011-09-12 00:20:18 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-12 00:20:18 --> Language Class Initialized
DEBUG - 2011-09-12 00:20:18 --> Loader Class Initialized
DEBUG - 2011-09-12 00:20:18 --> Controller Class Initialized
DEBUG - 2011-09-12 00:20:18 --> Model Class Initialized
DEBUG - 2011-09-12 00:20:18 --> Model Class Initialized
DEBUG - 2011-09-12 00:20:18 --> Model Class Initialized
DEBUG - 2011-09-12 00:20:18 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-12 00:20:18 --> Database Driver Class Initialized
DEBUG - 2011-09-12 00:20:19 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-12 00:20:19 --> Helper loaded: url_helper
DEBUG - 2011-09-12 00:20:19 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-12 00:20:19 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-12 00:20:19 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-12 00:20:19 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-12 00:20:19 --> Final output sent to browser
DEBUG - 2011-09-12 00:20:19 --> Total execution time: 0.4139
DEBUG - 2011-09-12 00:20:20 --> Config Class Initialized
DEBUG - 2011-09-12 00:20:20 --> Hooks Class Initialized
DEBUG - 2011-09-12 00:20:20 --> Utf8 Class Initialized
DEBUG - 2011-09-12 00:20:20 --> UTF-8 Support Enabled
DEBUG - 2011-09-12 00:20:20 --> URI Class Initialized
DEBUG - 2011-09-12 00:20:20 --> Router Class Initialized
DEBUG - 2011-09-12 00:20:20 --> Output Class Initialized
DEBUG - 2011-09-12 00:20:20 --> Input Class Initialized
DEBUG - 2011-09-12 00:20:20 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-12 00:20:20 --> Language Class Initialized
DEBUG - 2011-09-12 00:20:20 --> Loader Class Initialized
DEBUG - 2011-09-12 00:20:20 --> Controller Class Initialized
DEBUG - 2011-09-12 00:20:20 --> Model Class Initialized
DEBUG - 2011-09-12 00:20:20 --> Model Class Initialized
DEBUG - 2011-09-12 00:20:20 --> Model Class Initialized
DEBUG - 2011-09-12 00:20:20 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-12 00:20:20 --> Database Driver Class Initialized
DEBUG - 2011-09-12 00:20:20 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-12 00:20:20 --> Helper loaded: url_helper
DEBUG - 2011-09-12 00:20:20 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-12 00:20:20 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-12 00:20:20 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-12 00:20:20 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-12 00:20:20 --> Final output sent to browser
DEBUG - 2011-09-12 00:20:20 --> Total execution time: 0.0440
DEBUG - 2011-09-12 00:20:21 --> Config Class Initialized
DEBUG - 2011-09-12 00:20:21 --> Hooks Class Initialized
DEBUG - 2011-09-12 00:20:21 --> Utf8 Class Initialized
DEBUG - 2011-09-12 00:20:21 --> UTF-8 Support Enabled
DEBUG - 2011-09-12 00:20:21 --> URI Class Initialized
DEBUG - 2011-09-12 00:20:21 --> Router Class Initialized
ERROR - 2011-09-12 00:20:21 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-12 00:20:35 --> Config Class Initialized
DEBUG - 2011-09-12 00:20:35 --> Hooks Class Initialized
DEBUG - 2011-09-12 00:20:35 --> Utf8 Class Initialized
DEBUG - 2011-09-12 00:20:35 --> UTF-8 Support Enabled
DEBUG - 2011-09-12 00:20:35 --> URI Class Initialized
DEBUG - 2011-09-12 00:20:35 --> Router Class Initialized
DEBUG - 2011-09-12 00:20:35 --> Output Class Initialized
DEBUG - 2011-09-12 00:20:35 --> Input Class Initialized
DEBUG - 2011-09-12 00:20:35 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-12 00:20:35 --> Language Class Initialized
DEBUG - 2011-09-12 00:20:35 --> Loader Class Initialized
DEBUG - 2011-09-12 00:20:35 --> Controller Class Initialized
DEBUG - 2011-09-12 00:20:35 --> Model Class Initialized
DEBUG - 2011-09-12 00:20:35 --> Model Class Initialized
DEBUG - 2011-09-12 00:20:35 --> Model Class Initialized
DEBUG - 2011-09-12 00:20:35 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-12 00:20:35 --> Database Driver Class Initialized
DEBUG - 2011-09-12 00:20:35 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-12 00:20:35 --> Helper loaded: url_helper
DEBUG - 2011-09-12 00:20:35 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-12 00:20:35 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-12 00:20:35 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-12 00:20:35 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-12 00:20:35 --> Final output sent to browser
DEBUG - 2011-09-12 00:20:35 --> Total execution time: 0.3137
DEBUG - 2011-09-12 00:20:36 --> Config Class Initialized
DEBUG - 2011-09-12 00:20:36 --> Hooks Class Initialized
DEBUG - 2011-09-12 00:20:36 --> Utf8 Class Initialized
DEBUG - 2011-09-12 00:20:36 --> UTF-8 Support Enabled
DEBUG - 2011-09-12 00:20:36 --> URI Class Initialized
DEBUG - 2011-09-12 00:20:36 --> Router Class Initialized
DEBUG - 2011-09-12 00:20:36 --> Output Class Initialized
DEBUG - 2011-09-12 00:20:36 --> Input Class Initialized
DEBUG - 2011-09-12 00:20:36 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-12 00:20:36 --> Language Class Initialized
DEBUG - 2011-09-12 00:20:36 --> Loader Class Initialized
DEBUG - 2011-09-12 00:20:36 --> Controller Class Initialized
DEBUG - 2011-09-12 00:20:36 --> Model Class Initialized
DEBUG - 2011-09-12 00:20:36 --> Model Class Initialized
DEBUG - 2011-09-12 00:20:36 --> Model Class Initialized
DEBUG - 2011-09-12 00:20:36 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-12 00:20:36 --> Database Driver Class Initialized
DEBUG - 2011-09-12 00:20:36 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-12 00:20:36 --> Helper loaded: url_helper
DEBUG - 2011-09-12 00:20:36 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-12 00:20:36 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-12 00:20:36 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-12 00:20:36 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-12 00:20:36 --> Final output sent to browser
DEBUG - 2011-09-12 00:20:36 --> Total execution time: 0.0461
DEBUG - 2011-09-12 00:20:37 --> Config Class Initialized
DEBUG - 2011-09-12 00:20:37 --> Hooks Class Initialized
DEBUG - 2011-09-12 00:20:37 --> Utf8 Class Initialized
DEBUG - 2011-09-12 00:20:37 --> UTF-8 Support Enabled
DEBUG - 2011-09-12 00:20:37 --> URI Class Initialized
DEBUG - 2011-09-12 00:20:37 --> Router Class Initialized
ERROR - 2011-09-12 00:20:37 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-12 00:20:44 --> Config Class Initialized
DEBUG - 2011-09-12 00:20:44 --> Hooks Class Initialized
DEBUG - 2011-09-12 00:20:44 --> Utf8 Class Initialized
DEBUG - 2011-09-12 00:20:44 --> UTF-8 Support Enabled
DEBUG - 2011-09-12 00:20:44 --> URI Class Initialized
DEBUG - 2011-09-12 00:20:44 --> Router Class Initialized
DEBUG - 2011-09-12 00:20:44 --> Output Class Initialized
DEBUG - 2011-09-12 00:20:44 --> Input Class Initialized
DEBUG - 2011-09-12 00:20:44 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-12 00:20:44 --> Language Class Initialized
DEBUG - 2011-09-12 00:20:44 --> Loader Class Initialized
DEBUG - 2011-09-12 00:20:44 --> Controller Class Initialized
DEBUG - 2011-09-12 00:20:44 --> Model Class Initialized
DEBUG - 2011-09-12 00:20:44 --> Model Class Initialized
DEBUG - 2011-09-12 00:20:44 --> Model Class Initialized
DEBUG - 2011-09-12 00:20:44 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-12 00:20:44 --> Database Driver Class Initialized
DEBUG - 2011-09-12 00:20:45 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-12 00:20:45 --> Helper loaded: url_helper
DEBUG - 2011-09-12 00:20:45 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-12 00:20:45 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-12 00:20:45 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-12 00:20:45 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-12 00:20:45 --> Final output sent to browser
DEBUG - 2011-09-12 00:20:45 --> Total execution time: 0.2875
DEBUG - 2011-09-12 00:20:46 --> Config Class Initialized
DEBUG - 2011-09-12 00:20:46 --> Hooks Class Initialized
DEBUG - 2011-09-12 00:20:46 --> Utf8 Class Initialized
DEBUG - 2011-09-12 00:20:46 --> UTF-8 Support Enabled
DEBUG - 2011-09-12 00:20:46 --> URI Class Initialized
DEBUG - 2011-09-12 00:20:46 --> Router Class Initialized
DEBUG - 2011-09-12 00:20:46 --> Output Class Initialized
DEBUG - 2011-09-12 00:20:46 --> Input Class Initialized
DEBUG - 2011-09-12 00:20:46 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-12 00:20:46 --> Language Class Initialized
DEBUG - 2011-09-12 00:20:46 --> Loader Class Initialized
DEBUG - 2011-09-12 00:20:46 --> Controller Class Initialized
DEBUG - 2011-09-12 00:20:46 --> Model Class Initialized
DEBUG - 2011-09-12 00:20:46 --> Model Class Initialized
DEBUG - 2011-09-12 00:20:46 --> Model Class Initialized
DEBUG - 2011-09-12 00:20:46 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-12 00:20:46 --> Database Driver Class Initialized
DEBUG - 2011-09-12 00:20:47 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-12 00:20:47 --> Helper loaded: url_helper
DEBUG - 2011-09-12 00:20:47 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-12 00:20:47 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-12 00:20:47 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-12 00:20:47 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-12 00:20:47 --> Final output sent to browser
DEBUG - 2011-09-12 00:20:47 --> Total execution time: 0.0427
DEBUG - 2011-09-12 00:20:47 --> Config Class Initialized
DEBUG - 2011-09-12 00:20:47 --> Hooks Class Initialized
DEBUG - 2011-09-12 00:20:47 --> Utf8 Class Initialized
DEBUG - 2011-09-12 00:20:47 --> UTF-8 Support Enabled
DEBUG - 2011-09-12 00:20:47 --> URI Class Initialized
DEBUG - 2011-09-12 00:20:47 --> Router Class Initialized
ERROR - 2011-09-12 00:20:47 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-12 00:20:56 --> Config Class Initialized
DEBUG - 2011-09-12 00:20:56 --> Hooks Class Initialized
DEBUG - 2011-09-12 00:20:56 --> Utf8 Class Initialized
DEBUG - 2011-09-12 00:20:56 --> UTF-8 Support Enabled
DEBUG - 2011-09-12 00:20:56 --> URI Class Initialized
DEBUG - 2011-09-12 00:20:56 --> Router Class Initialized
DEBUG - 2011-09-12 00:20:56 --> Output Class Initialized
DEBUG - 2011-09-12 00:20:56 --> Input Class Initialized
DEBUG - 2011-09-12 00:20:56 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-12 00:20:56 --> Language Class Initialized
DEBUG - 2011-09-12 00:20:56 --> Loader Class Initialized
DEBUG - 2011-09-12 00:20:56 --> Controller Class Initialized
DEBUG - 2011-09-12 00:20:56 --> Model Class Initialized
DEBUG - 2011-09-12 00:20:56 --> Model Class Initialized
DEBUG - 2011-09-12 00:20:56 --> Model Class Initialized
DEBUG - 2011-09-12 00:20:56 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-12 00:20:56 --> Database Driver Class Initialized
DEBUG - 2011-09-12 00:20:56 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-12 00:20:56 --> Helper loaded: url_helper
DEBUG - 2011-09-12 00:20:56 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-12 00:20:56 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-12 00:20:56 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-12 00:20:56 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-12 00:20:56 --> Final output sent to browser
DEBUG - 2011-09-12 00:20:56 --> Total execution time: 0.1981
DEBUG - 2011-09-12 00:20:57 --> Config Class Initialized
DEBUG - 2011-09-12 00:20:57 --> Hooks Class Initialized
DEBUG - 2011-09-12 00:20:57 --> Utf8 Class Initialized
DEBUG - 2011-09-12 00:20:57 --> UTF-8 Support Enabled
DEBUG - 2011-09-12 00:20:57 --> URI Class Initialized
DEBUG - 2011-09-12 00:20:57 --> Router Class Initialized
DEBUG - 2011-09-12 00:20:57 --> Output Class Initialized
DEBUG - 2011-09-12 00:20:57 --> Input Class Initialized
DEBUG - 2011-09-12 00:20:57 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-12 00:20:57 --> Language Class Initialized
DEBUG - 2011-09-12 00:20:57 --> Loader Class Initialized
DEBUG - 2011-09-12 00:20:57 --> Controller Class Initialized
DEBUG - 2011-09-12 00:20:57 --> Model Class Initialized
DEBUG - 2011-09-12 00:20:57 --> Model Class Initialized
DEBUG - 2011-09-12 00:20:57 --> Model Class Initialized
DEBUG - 2011-09-12 00:20:57 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-12 00:20:57 --> Database Driver Class Initialized
DEBUG - 2011-09-12 00:20:57 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-12 00:20:57 --> Helper loaded: url_helper
DEBUG - 2011-09-12 00:20:57 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-12 00:20:57 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-12 00:20:57 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-12 00:20:57 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-12 00:20:57 --> Final output sent to browser
DEBUG - 2011-09-12 00:20:57 --> Total execution time: 0.0649
DEBUG - 2011-09-12 00:20:59 --> Config Class Initialized
DEBUG - 2011-09-12 00:20:59 --> Hooks Class Initialized
DEBUG - 2011-09-12 00:20:59 --> Utf8 Class Initialized
DEBUG - 2011-09-12 00:20:59 --> UTF-8 Support Enabled
DEBUG - 2011-09-12 00:20:59 --> URI Class Initialized
DEBUG - 2011-09-12 00:20:59 --> Router Class Initialized
ERROR - 2011-09-12 00:20:59 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-12 00:21:07 --> Config Class Initialized
DEBUG - 2011-09-12 00:21:07 --> Hooks Class Initialized
DEBUG - 2011-09-12 00:21:07 --> Utf8 Class Initialized
DEBUG - 2011-09-12 00:21:07 --> UTF-8 Support Enabled
DEBUG - 2011-09-12 00:21:07 --> URI Class Initialized
DEBUG - 2011-09-12 00:21:07 --> Router Class Initialized
DEBUG - 2011-09-12 00:21:07 --> Output Class Initialized
DEBUG - 2011-09-12 00:21:07 --> Input Class Initialized
DEBUG - 2011-09-12 00:21:07 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-12 00:21:07 --> Language Class Initialized
DEBUG - 2011-09-12 00:21:07 --> Loader Class Initialized
DEBUG - 2011-09-12 00:21:07 --> Controller Class Initialized
DEBUG - 2011-09-12 00:21:07 --> Model Class Initialized
DEBUG - 2011-09-12 00:21:07 --> Model Class Initialized
DEBUG - 2011-09-12 00:21:07 --> Model Class Initialized
DEBUG - 2011-09-12 00:21:07 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-12 00:21:07 --> Database Driver Class Initialized
DEBUG - 2011-09-12 00:21:07 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-12 00:21:07 --> Helper loaded: url_helper
DEBUG - 2011-09-12 00:21:07 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-12 00:21:07 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-12 00:21:07 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-12 00:21:07 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-12 00:21:07 --> Final output sent to browser
DEBUG - 2011-09-12 00:21:07 --> Total execution time: 0.2931
DEBUG - 2011-09-12 00:21:08 --> Config Class Initialized
DEBUG - 2011-09-12 00:21:08 --> Hooks Class Initialized
DEBUG - 2011-09-12 00:21:08 --> Utf8 Class Initialized
DEBUG - 2011-09-12 00:21:08 --> UTF-8 Support Enabled
DEBUG - 2011-09-12 00:21:08 --> URI Class Initialized
DEBUG - 2011-09-12 00:21:08 --> Router Class Initialized
DEBUG - 2011-09-12 00:21:08 --> Output Class Initialized
DEBUG - 2011-09-12 00:21:08 --> Input Class Initialized
DEBUG - 2011-09-12 00:21:08 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-12 00:21:08 --> Language Class Initialized
DEBUG - 2011-09-12 00:21:08 --> Loader Class Initialized
DEBUG - 2011-09-12 00:21:08 --> Controller Class Initialized
DEBUG - 2011-09-12 00:21:08 --> Model Class Initialized
DEBUG - 2011-09-12 00:21:08 --> Model Class Initialized
DEBUG - 2011-09-12 00:21:08 --> Model Class Initialized
DEBUG - 2011-09-12 00:21:08 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-12 00:21:08 --> Database Driver Class Initialized
DEBUG - 2011-09-12 00:21:08 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-12 00:21:08 --> Helper loaded: url_helper
DEBUG - 2011-09-12 00:21:08 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-12 00:21:08 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-12 00:21:08 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-12 00:21:08 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-12 00:21:08 --> Final output sent to browser
DEBUG - 2011-09-12 00:21:08 --> Total execution time: 0.0772
DEBUG - 2011-09-12 00:21:11 --> Config Class Initialized
DEBUG - 2011-09-12 00:21:11 --> Hooks Class Initialized
DEBUG - 2011-09-12 00:21:11 --> Utf8 Class Initialized
DEBUG - 2011-09-12 00:21:11 --> UTF-8 Support Enabled
DEBUG - 2011-09-12 00:21:11 --> URI Class Initialized
DEBUG - 2011-09-12 00:21:11 --> Router Class Initialized
ERROR - 2011-09-12 00:21:11 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-12 00:21:17 --> Config Class Initialized
DEBUG - 2011-09-12 00:21:17 --> Hooks Class Initialized
DEBUG - 2011-09-12 00:21:17 --> Utf8 Class Initialized
DEBUG - 2011-09-12 00:21:17 --> UTF-8 Support Enabled
DEBUG - 2011-09-12 00:21:17 --> URI Class Initialized
DEBUG - 2011-09-12 00:21:17 --> Router Class Initialized
DEBUG - 2011-09-12 00:21:17 --> Output Class Initialized
DEBUG - 2011-09-12 00:21:17 --> Input Class Initialized
DEBUG - 2011-09-12 00:21:17 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-12 00:21:17 --> Language Class Initialized
DEBUG - 2011-09-12 00:21:17 --> Loader Class Initialized
DEBUG - 2011-09-12 00:21:17 --> Controller Class Initialized
DEBUG - 2011-09-12 00:21:17 --> Model Class Initialized
DEBUG - 2011-09-12 00:21:17 --> Model Class Initialized
DEBUG - 2011-09-12 00:21:17 --> Model Class Initialized
DEBUG - 2011-09-12 00:21:17 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-12 00:21:17 --> Database Driver Class Initialized
DEBUG - 2011-09-12 00:21:17 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-12 00:21:17 --> Helper loaded: url_helper
DEBUG - 2011-09-12 00:21:17 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-12 00:21:17 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-12 00:21:17 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-12 00:21:17 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-12 00:21:17 --> Final output sent to browser
DEBUG - 2011-09-12 00:21:17 --> Total execution time: 0.2088
DEBUG - 2011-09-12 00:21:19 --> Config Class Initialized
DEBUG - 2011-09-12 00:21:19 --> Hooks Class Initialized
DEBUG - 2011-09-12 00:21:19 --> Utf8 Class Initialized
DEBUG - 2011-09-12 00:21:19 --> UTF-8 Support Enabled
DEBUG - 2011-09-12 00:21:19 --> URI Class Initialized
DEBUG - 2011-09-12 00:21:19 --> Router Class Initialized
DEBUG - 2011-09-12 00:21:19 --> Output Class Initialized
DEBUG - 2011-09-12 00:21:19 --> Input Class Initialized
DEBUG - 2011-09-12 00:21:19 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-12 00:21:19 --> Language Class Initialized
DEBUG - 2011-09-12 00:21:19 --> Loader Class Initialized
DEBUG - 2011-09-12 00:21:19 --> Controller Class Initialized
DEBUG - 2011-09-12 00:21:19 --> Model Class Initialized
DEBUG - 2011-09-12 00:21:19 --> Model Class Initialized
DEBUG - 2011-09-12 00:21:19 --> Model Class Initialized
DEBUG - 2011-09-12 00:21:19 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-12 00:21:19 --> Database Driver Class Initialized
DEBUG - 2011-09-12 00:21:19 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-12 00:21:19 --> Helper loaded: url_helper
DEBUG - 2011-09-12 00:21:19 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-12 00:21:19 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-12 00:21:19 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-12 00:21:19 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-12 00:21:19 --> Final output sent to browser
DEBUG - 2011-09-12 00:21:19 --> Total execution time: 0.0465
DEBUG - 2011-09-12 00:21:21 --> Config Class Initialized
DEBUG - 2011-09-12 00:21:21 --> Hooks Class Initialized
DEBUG - 2011-09-12 00:21:21 --> Utf8 Class Initialized
DEBUG - 2011-09-12 00:21:21 --> UTF-8 Support Enabled
DEBUG - 2011-09-12 00:21:21 --> URI Class Initialized
DEBUG - 2011-09-12 00:21:21 --> Router Class Initialized
ERROR - 2011-09-12 00:21:21 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-12 00:21:33 --> Config Class Initialized
DEBUG - 2011-09-12 00:21:33 --> Hooks Class Initialized
DEBUG - 2011-09-12 00:21:33 --> Utf8 Class Initialized
DEBUG - 2011-09-12 00:21:33 --> UTF-8 Support Enabled
DEBUG - 2011-09-12 00:21:33 --> URI Class Initialized
DEBUG - 2011-09-12 00:21:33 --> Router Class Initialized
DEBUG - 2011-09-12 00:21:33 --> Output Class Initialized
DEBUG - 2011-09-12 00:21:33 --> Input Class Initialized
DEBUG - 2011-09-12 00:21:33 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-12 00:21:33 --> Language Class Initialized
DEBUG - 2011-09-12 00:21:33 --> Loader Class Initialized
DEBUG - 2011-09-12 00:21:33 --> Controller Class Initialized
DEBUG - 2011-09-12 00:21:33 --> Model Class Initialized
DEBUG - 2011-09-12 00:21:33 --> Model Class Initialized
DEBUG - 2011-09-12 00:21:33 --> Model Class Initialized
DEBUG - 2011-09-12 00:21:33 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-12 00:21:33 --> Database Driver Class Initialized
DEBUG - 2011-09-12 00:21:33 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-12 00:21:33 --> Helper loaded: url_helper
DEBUG - 2011-09-12 00:21:33 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-12 00:21:33 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-12 00:21:33 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-12 00:21:33 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-12 00:21:33 --> Final output sent to browser
DEBUG - 2011-09-12 00:21:33 --> Total execution time: 0.2285
DEBUG - 2011-09-12 00:21:34 --> Config Class Initialized
DEBUG - 2011-09-12 00:21:34 --> Hooks Class Initialized
DEBUG - 2011-09-12 00:21:34 --> Utf8 Class Initialized
DEBUG - 2011-09-12 00:21:34 --> UTF-8 Support Enabled
DEBUG - 2011-09-12 00:21:34 --> URI Class Initialized
DEBUG - 2011-09-12 00:21:34 --> Router Class Initialized
DEBUG - 2011-09-12 00:21:34 --> Output Class Initialized
DEBUG - 2011-09-12 00:21:34 --> Input Class Initialized
DEBUG - 2011-09-12 00:21:34 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-12 00:21:34 --> Language Class Initialized
DEBUG - 2011-09-12 00:21:34 --> Loader Class Initialized
DEBUG - 2011-09-12 00:21:34 --> Controller Class Initialized
DEBUG - 2011-09-12 00:21:34 --> Model Class Initialized
DEBUG - 2011-09-12 00:21:34 --> Model Class Initialized
DEBUG - 2011-09-12 00:21:34 --> Model Class Initialized
DEBUG - 2011-09-12 00:21:34 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-12 00:21:34 --> Database Driver Class Initialized
DEBUG - 2011-09-12 00:21:34 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-12 00:21:34 --> Helper loaded: url_helper
DEBUG - 2011-09-12 00:21:34 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-12 00:21:34 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-12 00:21:34 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-12 00:21:34 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-12 00:21:34 --> Final output sent to browser
DEBUG - 2011-09-12 00:21:34 --> Total execution time: 0.0457
DEBUG - 2011-09-12 00:21:35 --> Config Class Initialized
DEBUG - 2011-09-12 00:21:35 --> Hooks Class Initialized
DEBUG - 2011-09-12 00:21:35 --> Utf8 Class Initialized
DEBUG - 2011-09-12 00:21:35 --> UTF-8 Support Enabled
DEBUG - 2011-09-12 00:21:35 --> URI Class Initialized
DEBUG - 2011-09-12 00:21:35 --> Router Class Initialized
ERROR - 2011-09-12 00:21:35 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-12 00:21:44 --> Config Class Initialized
DEBUG - 2011-09-12 00:21:44 --> Hooks Class Initialized
DEBUG - 2011-09-12 00:21:44 --> Utf8 Class Initialized
DEBUG - 2011-09-12 00:21:44 --> UTF-8 Support Enabled
DEBUG - 2011-09-12 00:21:44 --> URI Class Initialized
DEBUG - 2011-09-12 00:21:44 --> Router Class Initialized
DEBUG - 2011-09-12 00:21:44 --> Output Class Initialized
DEBUG - 2011-09-12 00:21:44 --> Input Class Initialized
DEBUG - 2011-09-12 00:21:44 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-12 00:21:44 --> Language Class Initialized
DEBUG - 2011-09-12 00:21:44 --> Loader Class Initialized
DEBUG - 2011-09-12 00:21:44 --> Controller Class Initialized
DEBUG - 2011-09-12 00:21:44 --> Model Class Initialized
DEBUG - 2011-09-12 00:21:44 --> Model Class Initialized
DEBUG - 2011-09-12 00:21:44 --> Model Class Initialized
DEBUG - 2011-09-12 00:21:44 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-12 00:21:44 --> Database Driver Class Initialized
DEBUG - 2011-09-12 00:21:45 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-12 00:21:45 --> Helper loaded: url_helper
DEBUG - 2011-09-12 00:21:45 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-12 00:21:45 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-12 00:21:45 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-12 00:21:45 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-12 00:21:45 --> Final output sent to browser
DEBUG - 2011-09-12 00:21:45 --> Total execution time: 0.2563
DEBUG - 2011-09-12 00:21:46 --> Config Class Initialized
DEBUG - 2011-09-12 00:21:46 --> Hooks Class Initialized
DEBUG - 2011-09-12 00:21:46 --> Utf8 Class Initialized
DEBUG - 2011-09-12 00:21:46 --> UTF-8 Support Enabled
DEBUG - 2011-09-12 00:21:46 --> URI Class Initialized
DEBUG - 2011-09-12 00:21:46 --> Router Class Initialized
DEBUG - 2011-09-12 00:21:46 --> Output Class Initialized
DEBUG - 2011-09-12 00:21:46 --> Input Class Initialized
DEBUG - 2011-09-12 00:21:46 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-12 00:21:46 --> Language Class Initialized
DEBUG - 2011-09-12 00:21:46 --> Loader Class Initialized
DEBUG - 2011-09-12 00:21:46 --> Controller Class Initialized
DEBUG - 2011-09-12 00:21:46 --> Model Class Initialized
DEBUG - 2011-09-12 00:21:46 --> Model Class Initialized
DEBUG - 2011-09-12 00:21:46 --> Model Class Initialized
DEBUG - 2011-09-12 00:21:46 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-12 00:21:46 --> Database Driver Class Initialized
DEBUG - 2011-09-12 00:21:46 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-12 00:21:46 --> Helper loaded: url_helper
DEBUG - 2011-09-12 00:21:46 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-12 00:21:46 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-12 00:21:46 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-12 00:21:46 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-12 00:21:46 --> Final output sent to browser
DEBUG - 2011-09-12 00:21:46 --> Total execution time: 0.0422
DEBUG - 2011-09-12 00:21:47 --> Config Class Initialized
DEBUG - 2011-09-12 00:21:47 --> Hooks Class Initialized
DEBUG - 2011-09-12 00:21:47 --> Utf8 Class Initialized
DEBUG - 2011-09-12 00:21:47 --> UTF-8 Support Enabled
DEBUG - 2011-09-12 00:21:47 --> URI Class Initialized
DEBUG - 2011-09-12 00:21:47 --> Router Class Initialized
ERROR - 2011-09-12 00:21:47 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-12 00:21:57 --> Config Class Initialized
DEBUG - 2011-09-12 00:21:57 --> Hooks Class Initialized
DEBUG - 2011-09-12 00:21:57 --> Utf8 Class Initialized
DEBUG - 2011-09-12 00:21:57 --> UTF-8 Support Enabled
DEBUG - 2011-09-12 00:21:57 --> URI Class Initialized
DEBUG - 2011-09-12 00:21:57 --> Router Class Initialized
DEBUG - 2011-09-12 00:21:57 --> Output Class Initialized
DEBUG - 2011-09-12 00:21:57 --> Input Class Initialized
DEBUG - 2011-09-12 00:21:57 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-12 00:21:57 --> Language Class Initialized
DEBUG - 2011-09-12 00:21:57 --> Loader Class Initialized
DEBUG - 2011-09-12 00:21:57 --> Controller Class Initialized
DEBUG - 2011-09-12 00:21:57 --> Model Class Initialized
DEBUG - 2011-09-12 00:21:57 --> Model Class Initialized
DEBUG - 2011-09-12 00:21:57 --> Model Class Initialized
DEBUG - 2011-09-12 00:21:57 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-12 00:21:57 --> Database Driver Class Initialized
DEBUG - 2011-09-12 00:21:57 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-12 00:21:57 --> Helper loaded: url_helper
DEBUG - 2011-09-12 00:21:57 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-12 00:21:57 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-12 00:21:57 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-12 00:21:57 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-12 00:21:57 --> Final output sent to browser
DEBUG - 2011-09-12 00:21:57 --> Total execution time: 0.3309
DEBUG - 2011-09-12 00:21:59 --> Config Class Initialized
DEBUG - 2011-09-12 00:21:59 --> Hooks Class Initialized
DEBUG - 2011-09-12 00:21:59 --> Utf8 Class Initialized
DEBUG - 2011-09-12 00:21:59 --> UTF-8 Support Enabled
DEBUG - 2011-09-12 00:21:59 --> URI Class Initialized
DEBUG - 2011-09-12 00:21:59 --> Router Class Initialized
DEBUG - 2011-09-12 00:21:59 --> Output Class Initialized
DEBUG - 2011-09-12 00:21:59 --> Input Class Initialized
DEBUG - 2011-09-12 00:21:59 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-12 00:21:59 --> Language Class Initialized
DEBUG - 2011-09-12 00:21:59 --> Loader Class Initialized
DEBUG - 2011-09-12 00:21:59 --> Controller Class Initialized
DEBUG - 2011-09-12 00:21:59 --> Model Class Initialized
DEBUG - 2011-09-12 00:21:59 --> Model Class Initialized
DEBUG - 2011-09-12 00:21:59 --> Model Class Initialized
DEBUG - 2011-09-12 00:21:59 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-12 00:21:59 --> Database Driver Class Initialized
DEBUG - 2011-09-12 00:21:59 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-12 00:21:59 --> Helper loaded: url_helper
DEBUG - 2011-09-12 00:21:59 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-12 00:21:59 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-12 00:21:59 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-12 00:21:59 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-12 00:21:59 --> Final output sent to browser
DEBUG - 2011-09-12 00:21:59 --> Total execution time: 0.0420
DEBUG - 2011-09-12 00:22:00 --> Config Class Initialized
DEBUG - 2011-09-12 00:22:00 --> Hooks Class Initialized
DEBUG - 2011-09-12 00:22:00 --> Utf8 Class Initialized
DEBUG - 2011-09-12 00:22:00 --> UTF-8 Support Enabled
DEBUG - 2011-09-12 00:22:00 --> URI Class Initialized
DEBUG - 2011-09-12 00:22:00 --> Router Class Initialized
ERROR - 2011-09-12 00:22:00 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-12 00:22:12 --> Config Class Initialized
DEBUG - 2011-09-12 00:22:12 --> Hooks Class Initialized
DEBUG - 2011-09-12 00:22:12 --> Utf8 Class Initialized
DEBUG - 2011-09-12 00:22:12 --> UTF-8 Support Enabled
DEBUG - 2011-09-12 00:22:12 --> URI Class Initialized
DEBUG - 2011-09-12 00:22:12 --> Router Class Initialized
DEBUG - 2011-09-12 00:22:12 --> Output Class Initialized
DEBUG - 2011-09-12 00:22:12 --> Input Class Initialized
DEBUG - 2011-09-12 00:22:12 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-12 00:22:12 --> Language Class Initialized
DEBUG - 2011-09-12 00:22:12 --> Loader Class Initialized
DEBUG - 2011-09-12 00:22:12 --> Controller Class Initialized
DEBUG - 2011-09-12 00:22:12 --> Model Class Initialized
DEBUG - 2011-09-12 00:22:12 --> Model Class Initialized
DEBUG - 2011-09-12 00:22:12 --> Model Class Initialized
DEBUG - 2011-09-12 00:22:12 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-12 00:22:12 --> Database Driver Class Initialized
DEBUG - 2011-09-12 00:22:13 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-12 00:22:13 --> Helper loaded: url_helper
DEBUG - 2011-09-12 00:22:13 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-12 00:22:13 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-12 00:22:13 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-12 00:22:13 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-12 00:22:13 --> Final output sent to browser
DEBUG - 2011-09-12 00:22:13 --> Total execution time: 0.3198
DEBUG - 2011-09-12 00:22:14 --> Config Class Initialized
DEBUG - 2011-09-12 00:22:14 --> Hooks Class Initialized
DEBUG - 2011-09-12 00:22:14 --> Utf8 Class Initialized
DEBUG - 2011-09-12 00:22:14 --> UTF-8 Support Enabled
DEBUG - 2011-09-12 00:22:14 --> URI Class Initialized
DEBUG - 2011-09-12 00:22:14 --> Router Class Initialized
DEBUG - 2011-09-12 00:22:14 --> Output Class Initialized
DEBUG - 2011-09-12 00:22:14 --> Input Class Initialized
DEBUG - 2011-09-12 00:22:14 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-12 00:22:14 --> Language Class Initialized
DEBUG - 2011-09-12 00:22:14 --> Loader Class Initialized
DEBUG - 2011-09-12 00:22:14 --> Controller Class Initialized
DEBUG - 2011-09-12 00:22:14 --> Model Class Initialized
DEBUG - 2011-09-12 00:22:14 --> Model Class Initialized
DEBUG - 2011-09-12 00:22:14 --> Model Class Initialized
DEBUG - 2011-09-12 00:22:14 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-12 00:22:14 --> Database Driver Class Initialized
DEBUG - 2011-09-12 00:22:14 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-12 00:22:14 --> Helper loaded: url_helper
DEBUG - 2011-09-12 00:22:14 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-12 00:22:14 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-12 00:22:14 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-12 00:22:14 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-12 00:22:14 --> Final output sent to browser
DEBUG - 2011-09-12 00:22:14 --> Total execution time: 0.1386
DEBUG - 2011-09-12 00:22:15 --> Config Class Initialized
DEBUG - 2011-09-12 00:22:15 --> Hooks Class Initialized
DEBUG - 2011-09-12 00:22:15 --> Utf8 Class Initialized
DEBUG - 2011-09-12 00:22:15 --> UTF-8 Support Enabled
DEBUG - 2011-09-12 00:22:15 --> URI Class Initialized
DEBUG - 2011-09-12 00:22:15 --> Router Class Initialized
ERROR - 2011-09-12 00:22:15 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-12 00:22:22 --> Config Class Initialized
DEBUG - 2011-09-12 00:22:22 --> Hooks Class Initialized
DEBUG - 2011-09-12 00:22:22 --> Utf8 Class Initialized
DEBUG - 2011-09-12 00:22:22 --> UTF-8 Support Enabled
DEBUG - 2011-09-12 00:22:22 --> URI Class Initialized
DEBUG - 2011-09-12 00:22:22 --> Router Class Initialized
DEBUG - 2011-09-12 00:22:22 --> Output Class Initialized
DEBUG - 2011-09-12 00:22:22 --> Input Class Initialized
DEBUG - 2011-09-12 00:22:22 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-12 00:22:22 --> Language Class Initialized
DEBUG - 2011-09-12 00:22:22 --> Loader Class Initialized
DEBUG - 2011-09-12 00:22:22 --> Controller Class Initialized
DEBUG - 2011-09-12 00:22:22 --> Model Class Initialized
DEBUG - 2011-09-12 00:22:22 --> Model Class Initialized
DEBUG - 2011-09-12 00:22:22 --> Model Class Initialized
DEBUG - 2011-09-12 00:22:22 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-12 00:22:22 --> Database Driver Class Initialized
DEBUG - 2011-09-12 00:22:22 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-12 00:22:22 --> Helper loaded: url_helper
DEBUG - 2011-09-12 00:22:22 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-12 00:22:22 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-12 00:22:22 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-12 00:22:22 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-12 00:22:22 --> Final output sent to browser
DEBUG - 2011-09-12 00:22:22 --> Total execution time: 0.2228
DEBUG - 2011-09-12 00:22:23 --> Config Class Initialized
DEBUG - 2011-09-12 00:22:23 --> Hooks Class Initialized
DEBUG - 2011-09-12 00:22:23 --> Utf8 Class Initialized
DEBUG - 2011-09-12 00:22:23 --> UTF-8 Support Enabled
DEBUG - 2011-09-12 00:22:23 --> URI Class Initialized
DEBUG - 2011-09-12 00:22:23 --> Router Class Initialized
DEBUG - 2011-09-12 00:22:23 --> Output Class Initialized
DEBUG - 2011-09-12 00:22:23 --> Input Class Initialized
DEBUG - 2011-09-12 00:22:23 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-12 00:22:23 --> Language Class Initialized
DEBUG - 2011-09-12 00:22:23 --> Loader Class Initialized
DEBUG - 2011-09-12 00:22:23 --> Controller Class Initialized
DEBUG - 2011-09-12 00:22:23 --> Model Class Initialized
DEBUG - 2011-09-12 00:22:23 --> Model Class Initialized
DEBUG - 2011-09-12 00:22:23 --> Model Class Initialized
DEBUG - 2011-09-12 00:22:23 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-12 00:22:23 --> Database Driver Class Initialized
DEBUG - 2011-09-12 00:22:23 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-12 00:22:23 --> Helper loaded: url_helper
DEBUG - 2011-09-12 00:22:23 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-12 00:22:23 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-12 00:22:23 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-12 00:22:23 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-12 00:22:23 --> Final output sent to browser
DEBUG - 2011-09-12 00:22:23 --> Total execution time: 0.0414
DEBUG - 2011-09-12 00:22:27 --> Config Class Initialized
DEBUG - 2011-09-12 00:22:27 --> Hooks Class Initialized
DEBUG - 2011-09-12 00:22:27 --> Utf8 Class Initialized
DEBUG - 2011-09-12 00:22:27 --> UTF-8 Support Enabled
DEBUG - 2011-09-12 00:22:27 --> URI Class Initialized
DEBUG - 2011-09-12 00:22:27 --> Router Class Initialized
ERROR - 2011-09-12 00:22:27 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-12 00:22:32 --> Config Class Initialized
DEBUG - 2011-09-12 00:22:32 --> Hooks Class Initialized
DEBUG - 2011-09-12 00:22:32 --> Utf8 Class Initialized
DEBUG - 2011-09-12 00:22:32 --> UTF-8 Support Enabled
DEBUG - 2011-09-12 00:22:32 --> URI Class Initialized
DEBUG - 2011-09-12 00:22:32 --> Router Class Initialized
DEBUG - 2011-09-12 00:22:32 --> Output Class Initialized
DEBUG - 2011-09-12 00:22:32 --> Input Class Initialized
DEBUG - 2011-09-12 00:22:32 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-12 00:22:32 --> Language Class Initialized
DEBUG - 2011-09-12 00:22:32 --> Loader Class Initialized
DEBUG - 2011-09-12 00:22:32 --> Controller Class Initialized
DEBUG - 2011-09-12 00:22:32 --> Model Class Initialized
DEBUG - 2011-09-12 00:22:32 --> Model Class Initialized
DEBUG - 2011-09-12 00:22:32 --> Model Class Initialized
DEBUG - 2011-09-12 00:22:32 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-12 00:22:32 --> Database Driver Class Initialized
DEBUG - 2011-09-12 00:22:32 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-12 00:22:32 --> Helper loaded: url_helper
DEBUG - 2011-09-12 00:22:32 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-12 00:22:32 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-12 00:22:32 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-12 00:22:32 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-12 00:22:32 --> Final output sent to browser
DEBUG - 2011-09-12 00:22:32 --> Total execution time: 0.0500
DEBUG - 2011-09-12 00:22:33 --> Config Class Initialized
DEBUG - 2011-09-12 00:22:33 --> Hooks Class Initialized
DEBUG - 2011-09-12 00:22:33 --> Utf8 Class Initialized
DEBUG - 2011-09-12 00:22:33 --> UTF-8 Support Enabled
DEBUG - 2011-09-12 00:22:33 --> URI Class Initialized
DEBUG - 2011-09-12 00:22:33 --> Router Class Initialized
DEBUG - 2011-09-12 00:22:33 --> Output Class Initialized
DEBUG - 2011-09-12 00:22:33 --> Input Class Initialized
DEBUG - 2011-09-12 00:22:33 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-12 00:22:33 --> Language Class Initialized
DEBUG - 2011-09-12 00:22:33 --> Loader Class Initialized
DEBUG - 2011-09-12 00:22:33 --> Controller Class Initialized
DEBUG - 2011-09-12 00:22:33 --> Model Class Initialized
DEBUG - 2011-09-12 00:22:33 --> Model Class Initialized
DEBUG - 2011-09-12 00:22:33 --> Model Class Initialized
DEBUG - 2011-09-12 00:22:33 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-12 00:22:33 --> Database Driver Class Initialized
DEBUG - 2011-09-12 00:22:33 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-12 00:22:33 --> Helper loaded: url_helper
DEBUG - 2011-09-12 00:22:33 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-12 00:22:33 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-12 00:22:33 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-12 00:22:33 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-12 00:22:33 --> Final output sent to browser
DEBUG - 2011-09-12 00:22:33 --> Total execution time: 0.0439
DEBUG - 2011-09-12 00:22:34 --> Config Class Initialized
DEBUG - 2011-09-12 00:22:34 --> Hooks Class Initialized
DEBUG - 2011-09-12 00:22:34 --> Utf8 Class Initialized
DEBUG - 2011-09-12 00:22:34 --> UTF-8 Support Enabled
DEBUG - 2011-09-12 00:22:34 --> URI Class Initialized
DEBUG - 2011-09-12 00:22:34 --> Router Class Initialized
ERROR - 2011-09-12 00:22:34 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-12 00:22:45 --> Config Class Initialized
DEBUG - 2011-09-12 00:22:45 --> Hooks Class Initialized
DEBUG - 2011-09-12 00:22:45 --> Utf8 Class Initialized
DEBUG - 2011-09-12 00:22:45 --> UTF-8 Support Enabled
DEBUG - 2011-09-12 00:22:45 --> URI Class Initialized
DEBUG - 2011-09-12 00:22:45 --> Router Class Initialized
DEBUG - 2011-09-12 00:22:45 --> Output Class Initialized
DEBUG - 2011-09-12 00:22:45 --> Input Class Initialized
DEBUG - 2011-09-12 00:22:45 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-12 00:22:45 --> Language Class Initialized
DEBUG - 2011-09-12 00:22:45 --> Loader Class Initialized
DEBUG - 2011-09-12 00:22:45 --> Controller Class Initialized
DEBUG - 2011-09-12 00:22:45 --> Model Class Initialized
DEBUG - 2011-09-12 00:22:45 --> Model Class Initialized
DEBUG - 2011-09-12 00:22:45 --> Model Class Initialized
DEBUG - 2011-09-12 00:22:45 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-12 00:22:45 --> Database Driver Class Initialized
DEBUG - 2011-09-12 00:22:45 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-12 00:22:45 --> Helper loaded: url_helper
DEBUG - 2011-09-12 00:22:45 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-12 00:22:45 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-12 00:22:45 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-12 00:22:45 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-12 00:22:45 --> Final output sent to browser
DEBUG - 2011-09-12 00:22:45 --> Total execution time: 0.1080
DEBUG - 2011-09-12 00:22:46 --> Config Class Initialized
DEBUG - 2011-09-12 00:22:46 --> Hooks Class Initialized
DEBUG - 2011-09-12 00:22:46 --> Utf8 Class Initialized
DEBUG - 2011-09-12 00:22:46 --> UTF-8 Support Enabled
DEBUG - 2011-09-12 00:22:46 --> URI Class Initialized
DEBUG - 2011-09-12 00:22:46 --> Router Class Initialized
DEBUG - 2011-09-12 00:22:46 --> Output Class Initialized
DEBUG - 2011-09-12 00:22:46 --> Input Class Initialized
DEBUG - 2011-09-12 00:22:46 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-12 00:22:46 --> Language Class Initialized
DEBUG - 2011-09-12 00:22:46 --> Loader Class Initialized
DEBUG - 2011-09-12 00:22:46 --> Controller Class Initialized
DEBUG - 2011-09-12 00:22:46 --> Model Class Initialized
DEBUG - 2011-09-12 00:22:46 --> Model Class Initialized
DEBUG - 2011-09-12 00:22:46 --> Model Class Initialized
DEBUG - 2011-09-12 00:22:46 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-12 00:22:46 --> Database Driver Class Initialized
DEBUG - 2011-09-12 00:22:46 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-12 00:22:46 --> Helper loaded: url_helper
DEBUG - 2011-09-12 00:22:46 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-12 00:22:46 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-12 00:22:46 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-12 00:22:46 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-12 00:22:46 --> Final output sent to browser
DEBUG - 2011-09-12 00:22:46 --> Total execution time: 0.0428
DEBUG - 2011-09-12 00:22:48 --> Config Class Initialized
DEBUG - 2011-09-12 00:22:48 --> Hooks Class Initialized
DEBUG - 2011-09-12 00:22:48 --> Utf8 Class Initialized
DEBUG - 2011-09-12 00:22:48 --> UTF-8 Support Enabled
DEBUG - 2011-09-12 00:22:48 --> URI Class Initialized
DEBUG - 2011-09-12 00:22:48 --> Router Class Initialized
ERROR - 2011-09-12 00:22:48 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-12 00:31:14 --> Config Class Initialized
DEBUG - 2011-09-12 00:31:14 --> Hooks Class Initialized
DEBUG - 2011-09-12 00:31:14 --> Utf8 Class Initialized
DEBUG - 2011-09-12 00:31:14 --> UTF-8 Support Enabled
DEBUG - 2011-09-12 00:31:14 --> URI Class Initialized
DEBUG - 2011-09-12 00:31:14 --> Router Class Initialized
DEBUG - 2011-09-12 00:31:14 --> Output Class Initialized
DEBUG - 2011-09-12 00:31:14 --> Input Class Initialized
DEBUG - 2011-09-12 00:31:14 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-12 00:31:14 --> Language Class Initialized
DEBUG - 2011-09-12 00:31:14 --> Loader Class Initialized
DEBUG - 2011-09-12 00:31:14 --> Controller Class Initialized
ERROR - 2011-09-12 00:31:14 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-12 00:31:14 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-12 00:31:14 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-12 00:31:14 --> Model Class Initialized
DEBUG - 2011-09-12 00:31:14 --> Model Class Initialized
DEBUG - 2011-09-12 00:31:14 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-12 00:31:14 --> Database Driver Class Initialized
DEBUG - 2011-09-12 00:31:14 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-12 00:31:14 --> Helper loaded: url_helper
DEBUG - 2011-09-12 00:31:14 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-12 00:31:14 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-12 00:31:14 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-12 00:31:14 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-12 00:31:14 --> Final output sent to browser
DEBUG - 2011-09-12 00:31:14 --> Total execution time: 0.0576
DEBUG - 2011-09-12 00:31:15 --> Config Class Initialized
DEBUG - 2011-09-12 00:31:15 --> Hooks Class Initialized
DEBUG - 2011-09-12 00:31:15 --> Utf8 Class Initialized
DEBUG - 2011-09-12 00:31:15 --> UTF-8 Support Enabled
DEBUG - 2011-09-12 00:31:15 --> URI Class Initialized
DEBUG - 2011-09-12 00:31:15 --> Router Class Initialized
DEBUG - 2011-09-12 00:31:15 --> Output Class Initialized
DEBUG - 2011-09-12 00:31:15 --> Input Class Initialized
DEBUG - 2011-09-12 00:31:15 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-12 00:31:15 --> Language Class Initialized
DEBUG - 2011-09-12 00:31:15 --> Loader Class Initialized
DEBUG - 2011-09-12 00:31:15 --> Controller Class Initialized
DEBUG - 2011-09-12 00:31:15 --> Model Class Initialized
DEBUG - 2011-09-12 00:31:15 --> Model Class Initialized
DEBUG - 2011-09-12 00:31:15 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-12 00:31:15 --> Database Driver Class Initialized
DEBUG - 2011-09-12 00:31:17 --> Final output sent to browser
DEBUG - 2011-09-12 00:31:17 --> Total execution time: 1.3658
DEBUG - 2011-09-12 00:31:18 --> Config Class Initialized
DEBUG - 2011-09-12 00:31:18 --> Hooks Class Initialized
DEBUG - 2011-09-12 00:31:18 --> Utf8 Class Initialized
DEBUG - 2011-09-12 00:31:18 --> UTF-8 Support Enabled
DEBUG - 2011-09-12 00:31:18 --> URI Class Initialized
DEBUG - 2011-09-12 00:31:18 --> Router Class Initialized
ERROR - 2011-09-12 00:31:18 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-12 00:31:30 --> Config Class Initialized
DEBUG - 2011-09-12 00:31:30 --> Hooks Class Initialized
DEBUG - 2011-09-12 00:31:30 --> Utf8 Class Initialized
DEBUG - 2011-09-12 00:31:30 --> UTF-8 Support Enabled
DEBUG - 2011-09-12 00:31:30 --> URI Class Initialized
DEBUG - 2011-09-12 00:31:30 --> Router Class Initialized
DEBUG - 2011-09-12 00:31:30 --> Output Class Initialized
DEBUG - 2011-09-12 00:31:30 --> Input Class Initialized
DEBUG - 2011-09-12 00:31:30 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-12 00:31:30 --> Language Class Initialized
DEBUG - 2011-09-12 00:31:30 --> Loader Class Initialized
DEBUG - 2011-09-12 00:31:30 --> Controller Class Initialized
ERROR - 2011-09-12 00:31:30 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-12 00:31:30 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-12 00:31:30 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-12 00:31:30 --> Model Class Initialized
DEBUG - 2011-09-12 00:31:30 --> Model Class Initialized
DEBUG - 2011-09-12 00:31:30 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-12 00:31:30 --> Database Driver Class Initialized
DEBUG - 2011-09-12 00:31:30 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-12 00:31:30 --> Helper loaded: url_helper
DEBUG - 2011-09-12 00:31:30 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-12 00:31:30 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-12 00:31:30 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-12 00:31:30 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-12 00:31:30 --> Final output sent to browser
DEBUG - 2011-09-12 00:31:30 --> Total execution time: 0.0269
DEBUG - 2011-09-12 00:31:31 --> Config Class Initialized
DEBUG - 2011-09-12 00:31:31 --> Hooks Class Initialized
DEBUG - 2011-09-12 00:31:31 --> Utf8 Class Initialized
DEBUG - 2011-09-12 00:31:31 --> UTF-8 Support Enabled
DEBUG - 2011-09-12 00:31:31 --> URI Class Initialized
DEBUG - 2011-09-12 00:31:31 --> Router Class Initialized
DEBUG - 2011-09-12 00:31:31 --> Output Class Initialized
DEBUG - 2011-09-12 00:31:31 --> Input Class Initialized
DEBUG - 2011-09-12 00:31:31 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-12 00:31:31 --> Language Class Initialized
DEBUG - 2011-09-12 00:31:31 --> Loader Class Initialized
DEBUG - 2011-09-12 00:31:31 --> Controller Class Initialized
DEBUG - 2011-09-12 00:31:31 --> Model Class Initialized
DEBUG - 2011-09-12 00:31:31 --> Model Class Initialized
DEBUG - 2011-09-12 00:31:31 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-12 00:31:31 --> Database Driver Class Initialized
DEBUG - 2011-09-12 00:31:31 --> Config Class Initialized
DEBUG - 2011-09-12 00:31:31 --> Hooks Class Initialized
DEBUG - 2011-09-12 00:31:31 --> Utf8 Class Initialized
DEBUG - 2011-09-12 00:31:31 --> UTF-8 Support Enabled
DEBUG - 2011-09-12 00:31:31 --> URI Class Initialized
DEBUG - 2011-09-12 00:31:31 --> Router Class Initialized
DEBUG - 2011-09-12 00:31:31 --> Output Class Initialized
DEBUG - 2011-09-12 00:31:31 --> Input Class Initialized
DEBUG - 2011-09-12 00:31:31 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-12 00:31:31 --> Language Class Initialized
DEBUG - 2011-09-12 00:31:31 --> Loader Class Initialized
DEBUG - 2011-09-12 00:31:31 --> Controller Class Initialized
ERROR - 2011-09-12 00:31:31 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-12 00:31:31 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-12 00:31:31 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-12 00:31:31 --> Model Class Initialized
DEBUG - 2011-09-12 00:31:31 --> Model Class Initialized
DEBUG - 2011-09-12 00:31:31 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-12 00:31:31 --> Database Driver Class Initialized
DEBUG - 2011-09-12 00:31:31 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-12 00:31:31 --> Helper loaded: url_helper
DEBUG - 2011-09-12 00:31:31 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-12 00:31:31 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-12 00:31:31 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-12 00:31:31 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-12 00:31:31 --> Final output sent to browser
DEBUG - 2011-09-12 00:31:31 --> Total execution time: 0.0291
DEBUG - 2011-09-12 00:31:32 --> Final output sent to browser
DEBUG - 2011-09-12 00:31:32 --> Total execution time: 1.5253
DEBUG - 2011-09-12 00:31:33 --> Config Class Initialized
DEBUG - 2011-09-12 00:31:33 --> Hooks Class Initialized
DEBUG - 2011-09-12 00:31:33 --> Utf8 Class Initialized
DEBUG - 2011-09-12 00:31:33 --> UTF-8 Support Enabled
DEBUG - 2011-09-12 00:31:33 --> URI Class Initialized
DEBUG - 2011-09-12 00:31:33 --> Router Class Initialized
ERROR - 2011-09-12 00:31:33 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-12 00:31:45 --> Config Class Initialized
DEBUG - 2011-09-12 00:31:45 --> Hooks Class Initialized
DEBUG - 2011-09-12 00:31:45 --> Utf8 Class Initialized
DEBUG - 2011-09-12 00:31:45 --> UTF-8 Support Enabled
DEBUG - 2011-09-12 00:31:45 --> URI Class Initialized
DEBUG - 2011-09-12 00:31:45 --> Router Class Initialized
DEBUG - 2011-09-12 00:31:45 --> Output Class Initialized
DEBUG - 2011-09-12 00:31:45 --> Input Class Initialized
DEBUG - 2011-09-12 00:31:45 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-12 00:31:45 --> Language Class Initialized
DEBUG - 2011-09-12 00:31:45 --> Loader Class Initialized
DEBUG - 2011-09-12 00:31:45 --> Controller Class Initialized
ERROR - 2011-09-12 00:31:45 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-12 00:31:45 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-12 00:31:45 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-12 00:31:45 --> Model Class Initialized
DEBUG - 2011-09-12 00:31:45 --> Model Class Initialized
DEBUG - 2011-09-12 00:31:45 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-12 00:31:45 --> Database Driver Class Initialized
DEBUG - 2011-09-12 00:31:45 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-12 00:31:45 --> Helper loaded: url_helper
DEBUG - 2011-09-12 00:31:45 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-12 00:31:45 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-12 00:31:45 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-12 00:31:45 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-12 00:31:45 --> Final output sent to browser
DEBUG - 2011-09-12 00:31:45 --> Total execution time: 0.0368
DEBUG - 2011-09-12 00:31:46 --> Config Class Initialized
DEBUG - 2011-09-12 00:31:46 --> Hooks Class Initialized
DEBUG - 2011-09-12 00:31:46 --> Utf8 Class Initialized
DEBUG - 2011-09-12 00:31:46 --> UTF-8 Support Enabled
DEBUG - 2011-09-12 00:31:46 --> URI Class Initialized
DEBUG - 2011-09-12 00:31:46 --> Router Class Initialized
DEBUG - 2011-09-12 00:31:46 --> Output Class Initialized
DEBUG - 2011-09-12 00:31:46 --> Input Class Initialized
DEBUG - 2011-09-12 00:31:46 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-12 00:31:46 --> Language Class Initialized
DEBUG - 2011-09-12 00:31:46 --> Loader Class Initialized
DEBUG - 2011-09-12 00:31:46 --> Controller Class Initialized
DEBUG - 2011-09-12 00:31:46 --> Model Class Initialized
DEBUG - 2011-09-12 00:31:46 --> Model Class Initialized
DEBUG - 2011-09-12 00:31:46 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-12 00:31:46 --> Database Driver Class Initialized
DEBUG - 2011-09-12 00:31:47 --> Final output sent to browser
DEBUG - 2011-09-12 00:31:47 --> Total execution time: 1.6614
DEBUG - 2011-09-12 00:31:49 --> Config Class Initialized
DEBUG - 2011-09-12 00:31:49 --> Hooks Class Initialized
DEBUG - 2011-09-12 00:31:49 --> Utf8 Class Initialized
DEBUG - 2011-09-12 00:31:49 --> UTF-8 Support Enabled
DEBUG - 2011-09-12 00:31:49 --> URI Class Initialized
DEBUG - 2011-09-12 00:31:49 --> Router Class Initialized
ERROR - 2011-09-12 00:31:49 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-12 00:31:56 --> Config Class Initialized
DEBUG - 2011-09-12 00:31:56 --> Hooks Class Initialized
DEBUG - 2011-09-12 00:31:56 --> Utf8 Class Initialized
DEBUG - 2011-09-12 00:31:56 --> UTF-8 Support Enabled
DEBUG - 2011-09-12 00:31:56 --> URI Class Initialized
DEBUG - 2011-09-12 00:31:56 --> Router Class Initialized
DEBUG - 2011-09-12 00:31:56 --> Output Class Initialized
DEBUG - 2011-09-12 00:31:56 --> Input Class Initialized
DEBUG - 2011-09-12 00:31:56 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-12 00:31:56 --> Language Class Initialized
DEBUG - 2011-09-12 00:31:56 --> Loader Class Initialized
DEBUG - 2011-09-12 00:31:56 --> Controller Class Initialized
ERROR - 2011-09-12 00:31:56 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-12 00:31:56 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-12 00:31:56 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-12 00:31:56 --> Model Class Initialized
DEBUG - 2011-09-12 00:31:56 --> Model Class Initialized
DEBUG - 2011-09-12 00:31:56 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-12 00:31:56 --> Database Driver Class Initialized
DEBUG - 2011-09-12 00:31:56 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-12 00:31:56 --> Helper loaded: url_helper
DEBUG - 2011-09-12 00:31:56 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-12 00:31:56 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-12 00:31:56 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-12 00:31:56 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-12 00:31:56 --> Final output sent to browser
DEBUG - 2011-09-12 00:31:56 --> Total execution time: 0.0336
DEBUG - 2011-09-12 00:31:57 --> Config Class Initialized
DEBUG - 2011-09-12 00:31:57 --> Hooks Class Initialized
DEBUG - 2011-09-12 00:31:57 --> Utf8 Class Initialized
DEBUG - 2011-09-12 00:31:57 --> UTF-8 Support Enabled
DEBUG - 2011-09-12 00:31:57 --> URI Class Initialized
DEBUG - 2011-09-12 00:31:57 --> Router Class Initialized
DEBUG - 2011-09-12 00:31:57 --> Output Class Initialized
DEBUG - 2011-09-12 00:31:57 --> Input Class Initialized
DEBUG - 2011-09-12 00:31:57 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-12 00:31:57 --> Language Class Initialized
DEBUG - 2011-09-12 00:31:57 --> Loader Class Initialized
DEBUG - 2011-09-12 00:31:57 --> Controller Class Initialized
DEBUG - 2011-09-12 00:31:57 --> Model Class Initialized
DEBUG - 2011-09-12 00:31:57 --> Model Class Initialized
DEBUG - 2011-09-12 00:31:57 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-12 00:31:57 --> Database Driver Class Initialized
DEBUG - 2011-09-12 00:31:58 --> Final output sent to browser
DEBUG - 2011-09-12 00:31:58 --> Total execution time: 1.4506
DEBUG - 2011-09-12 00:31:59 --> Config Class Initialized
DEBUG - 2011-09-12 00:31:59 --> Hooks Class Initialized
DEBUG - 2011-09-12 00:31:59 --> Utf8 Class Initialized
DEBUG - 2011-09-12 00:31:59 --> UTF-8 Support Enabled
DEBUG - 2011-09-12 00:31:59 --> URI Class Initialized
DEBUG - 2011-09-12 00:31:59 --> Router Class Initialized
ERROR - 2011-09-12 00:31:59 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-12 00:32:08 --> Config Class Initialized
DEBUG - 2011-09-12 00:32:08 --> Hooks Class Initialized
DEBUG - 2011-09-12 00:32:08 --> Utf8 Class Initialized
DEBUG - 2011-09-12 00:32:08 --> UTF-8 Support Enabled
DEBUG - 2011-09-12 00:32:08 --> URI Class Initialized
DEBUG - 2011-09-12 00:32:08 --> Router Class Initialized
DEBUG - 2011-09-12 00:32:08 --> Output Class Initialized
DEBUG - 2011-09-12 00:32:08 --> Input Class Initialized
DEBUG - 2011-09-12 00:32:08 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-12 00:32:08 --> Language Class Initialized
DEBUG - 2011-09-12 00:32:08 --> Loader Class Initialized
DEBUG - 2011-09-12 00:32:08 --> Controller Class Initialized
ERROR - 2011-09-12 00:32:08 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-12 00:32:08 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-12 00:32:08 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-12 00:32:08 --> Model Class Initialized
DEBUG - 2011-09-12 00:32:08 --> Model Class Initialized
DEBUG - 2011-09-12 00:32:08 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-12 00:32:08 --> Database Driver Class Initialized
DEBUG - 2011-09-12 00:32:08 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-12 00:32:08 --> Helper loaded: url_helper
DEBUG - 2011-09-12 00:32:08 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-12 00:32:08 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-12 00:32:08 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-12 00:32:08 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-12 00:32:08 --> Final output sent to browser
DEBUG - 2011-09-12 00:32:08 --> Total execution time: 0.0277
DEBUG - 2011-09-12 00:32:08 --> Config Class Initialized
DEBUG - 2011-09-12 00:32:08 --> Hooks Class Initialized
DEBUG - 2011-09-12 00:32:08 --> Utf8 Class Initialized
DEBUG - 2011-09-12 00:32:08 --> UTF-8 Support Enabled
DEBUG - 2011-09-12 00:32:08 --> URI Class Initialized
DEBUG - 2011-09-12 00:32:08 --> Router Class Initialized
DEBUG - 2011-09-12 00:32:08 --> Output Class Initialized
DEBUG - 2011-09-12 00:32:08 --> Input Class Initialized
DEBUG - 2011-09-12 00:32:08 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-12 00:32:08 --> Language Class Initialized
DEBUG - 2011-09-12 00:32:08 --> Loader Class Initialized
DEBUG - 2011-09-12 00:32:08 --> Controller Class Initialized
DEBUG - 2011-09-12 00:32:08 --> Model Class Initialized
DEBUG - 2011-09-12 00:32:08 --> Model Class Initialized
DEBUG - 2011-09-12 00:32:08 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-12 00:32:08 --> Database Driver Class Initialized
DEBUG - 2011-09-12 00:32:09 --> Final output sent to browser
DEBUG - 2011-09-12 00:32:09 --> Total execution time: 1.3546
DEBUG - 2011-09-12 00:32:11 --> Config Class Initialized
DEBUG - 2011-09-12 00:32:11 --> Hooks Class Initialized
DEBUG - 2011-09-12 00:32:11 --> Utf8 Class Initialized
DEBUG - 2011-09-12 00:32:11 --> UTF-8 Support Enabled
DEBUG - 2011-09-12 00:32:11 --> URI Class Initialized
DEBUG - 2011-09-12 00:32:11 --> Router Class Initialized
ERROR - 2011-09-12 00:32:11 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-12 00:32:19 --> Config Class Initialized
DEBUG - 2011-09-12 00:32:19 --> Hooks Class Initialized
DEBUG - 2011-09-12 00:32:19 --> Utf8 Class Initialized
DEBUG - 2011-09-12 00:32:19 --> UTF-8 Support Enabled
DEBUG - 2011-09-12 00:32:19 --> URI Class Initialized
DEBUG - 2011-09-12 00:32:19 --> Router Class Initialized
DEBUG - 2011-09-12 00:32:19 --> Output Class Initialized
DEBUG - 2011-09-12 00:32:19 --> Input Class Initialized
DEBUG - 2011-09-12 00:32:19 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-12 00:32:19 --> Language Class Initialized
DEBUG - 2011-09-12 00:32:19 --> Loader Class Initialized
DEBUG - 2011-09-12 00:32:19 --> Controller Class Initialized
ERROR - 2011-09-12 00:32:19 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-12 00:32:19 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-12 00:32:19 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-12 00:32:19 --> Model Class Initialized
DEBUG - 2011-09-12 00:32:19 --> Model Class Initialized
DEBUG - 2011-09-12 00:32:19 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-12 00:32:19 --> Database Driver Class Initialized
DEBUG - 2011-09-12 00:32:19 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-12 00:32:19 --> Helper loaded: url_helper
DEBUG - 2011-09-12 00:32:19 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-12 00:32:19 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-12 00:32:19 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-12 00:32:19 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-12 00:32:19 --> Final output sent to browser
DEBUG - 2011-09-12 00:32:19 --> Total execution time: 0.0316
DEBUG - 2011-09-12 00:32:20 --> Config Class Initialized
DEBUG - 2011-09-12 00:32:20 --> Hooks Class Initialized
DEBUG - 2011-09-12 00:32:20 --> Utf8 Class Initialized
DEBUG - 2011-09-12 00:32:20 --> UTF-8 Support Enabled
DEBUG - 2011-09-12 00:32:20 --> URI Class Initialized
DEBUG - 2011-09-12 00:32:20 --> Router Class Initialized
DEBUG - 2011-09-12 00:32:20 --> Output Class Initialized
DEBUG - 2011-09-12 00:32:20 --> Input Class Initialized
DEBUG - 2011-09-12 00:32:20 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-12 00:32:20 --> Language Class Initialized
DEBUG - 2011-09-12 00:32:20 --> Loader Class Initialized
DEBUG - 2011-09-12 00:32:20 --> Controller Class Initialized
DEBUG - 2011-09-12 00:32:20 --> Model Class Initialized
DEBUG - 2011-09-12 00:32:20 --> Model Class Initialized
DEBUG - 2011-09-12 00:32:20 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-12 00:32:20 --> Database Driver Class Initialized
DEBUG - 2011-09-12 00:32:21 --> Final output sent to browser
DEBUG - 2011-09-12 00:32:21 --> Total execution time: 1.4819
DEBUG - 2011-09-12 00:32:22 --> Config Class Initialized
DEBUG - 2011-09-12 00:32:22 --> Hooks Class Initialized
DEBUG - 2011-09-12 00:32:22 --> Utf8 Class Initialized
DEBUG - 2011-09-12 00:32:22 --> UTF-8 Support Enabled
DEBUG - 2011-09-12 00:32:22 --> URI Class Initialized
DEBUG - 2011-09-12 00:32:22 --> Router Class Initialized
ERROR - 2011-09-12 00:32:22 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-12 00:32:35 --> Config Class Initialized
DEBUG - 2011-09-12 00:32:35 --> Hooks Class Initialized
DEBUG - 2011-09-12 00:32:35 --> Utf8 Class Initialized
DEBUG - 2011-09-12 00:32:35 --> UTF-8 Support Enabled
DEBUG - 2011-09-12 00:32:35 --> URI Class Initialized
DEBUG - 2011-09-12 00:32:35 --> Router Class Initialized
DEBUG - 2011-09-12 00:32:35 --> Output Class Initialized
DEBUG - 2011-09-12 00:32:35 --> Input Class Initialized
DEBUG - 2011-09-12 00:32:35 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-12 00:32:35 --> Language Class Initialized
DEBUG - 2011-09-12 00:32:35 --> Loader Class Initialized
DEBUG - 2011-09-12 00:32:35 --> Controller Class Initialized
ERROR - 2011-09-12 00:32:35 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-12 00:32:35 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-12 00:32:35 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-12 00:32:35 --> Model Class Initialized
DEBUG - 2011-09-12 00:32:35 --> Model Class Initialized
DEBUG - 2011-09-12 00:32:35 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-12 00:32:35 --> Database Driver Class Initialized
DEBUG - 2011-09-12 00:32:35 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-12 00:32:35 --> Helper loaded: url_helper
DEBUG - 2011-09-12 00:32:35 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-12 00:32:35 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-12 00:32:35 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-12 00:32:35 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-12 00:32:35 --> Final output sent to browser
DEBUG - 2011-09-12 00:32:35 --> Total execution time: 0.0290
DEBUG - 2011-09-12 00:32:36 --> Config Class Initialized
DEBUG - 2011-09-12 00:32:36 --> Hooks Class Initialized
DEBUG - 2011-09-12 00:32:36 --> Utf8 Class Initialized
DEBUG - 2011-09-12 00:32:36 --> UTF-8 Support Enabled
DEBUG - 2011-09-12 00:32:36 --> URI Class Initialized
DEBUG - 2011-09-12 00:32:36 --> Router Class Initialized
DEBUG - 2011-09-12 00:32:36 --> Output Class Initialized
DEBUG - 2011-09-12 00:32:36 --> Input Class Initialized
DEBUG - 2011-09-12 00:32:36 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-12 00:32:36 --> Language Class Initialized
DEBUG - 2011-09-12 00:32:36 --> Loader Class Initialized
DEBUG - 2011-09-12 00:32:36 --> Controller Class Initialized
DEBUG - 2011-09-12 00:32:36 --> Model Class Initialized
DEBUG - 2011-09-12 00:32:36 --> Model Class Initialized
DEBUG - 2011-09-12 00:32:36 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-12 00:32:36 --> Database Driver Class Initialized
DEBUG - 2011-09-12 00:32:37 --> Final output sent to browser
DEBUG - 2011-09-12 00:32:37 --> Total execution time: 1.4473
DEBUG - 2011-09-12 00:32:38 --> Config Class Initialized
DEBUG - 2011-09-12 00:32:38 --> Hooks Class Initialized
DEBUG - 2011-09-12 00:32:38 --> Utf8 Class Initialized
DEBUG - 2011-09-12 00:32:38 --> UTF-8 Support Enabled
DEBUG - 2011-09-12 00:32:38 --> URI Class Initialized
DEBUG - 2011-09-12 00:32:38 --> Router Class Initialized
ERROR - 2011-09-12 00:32:38 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-12 00:32:48 --> Config Class Initialized
DEBUG - 2011-09-12 00:32:48 --> Hooks Class Initialized
DEBUG - 2011-09-12 00:32:48 --> Utf8 Class Initialized
DEBUG - 2011-09-12 00:32:48 --> UTF-8 Support Enabled
DEBUG - 2011-09-12 00:32:48 --> URI Class Initialized
DEBUG - 2011-09-12 00:32:48 --> Router Class Initialized
DEBUG - 2011-09-12 00:32:48 --> Output Class Initialized
DEBUG - 2011-09-12 00:32:48 --> Input Class Initialized
DEBUG - 2011-09-12 00:32:48 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-12 00:32:48 --> Language Class Initialized
DEBUG - 2011-09-12 00:32:48 --> Loader Class Initialized
DEBUG - 2011-09-12 00:32:48 --> Controller Class Initialized
ERROR - 2011-09-12 00:32:48 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-12 00:32:48 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-12 00:32:48 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-12 00:32:48 --> Model Class Initialized
DEBUG - 2011-09-12 00:32:48 --> Model Class Initialized
DEBUG - 2011-09-12 00:32:48 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-12 00:32:48 --> Database Driver Class Initialized
DEBUG - 2011-09-12 00:32:48 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-12 00:32:48 --> Helper loaded: url_helper
DEBUG - 2011-09-12 00:32:48 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-12 00:32:48 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-12 00:32:48 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-12 00:32:48 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-12 00:32:48 --> Final output sent to browser
DEBUG - 2011-09-12 00:32:48 --> Total execution time: 0.0312
DEBUG - 2011-09-12 00:32:49 --> Config Class Initialized
DEBUG - 2011-09-12 00:32:49 --> Hooks Class Initialized
DEBUG - 2011-09-12 00:32:49 --> Utf8 Class Initialized
DEBUG - 2011-09-12 00:32:49 --> UTF-8 Support Enabled
DEBUG - 2011-09-12 00:32:49 --> URI Class Initialized
DEBUG - 2011-09-12 00:32:49 --> Router Class Initialized
DEBUG - 2011-09-12 00:32:49 --> Output Class Initialized
DEBUG - 2011-09-12 00:32:49 --> Input Class Initialized
DEBUG - 2011-09-12 00:32:49 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-12 00:32:49 --> Language Class Initialized
DEBUG - 2011-09-12 00:32:49 --> Loader Class Initialized
DEBUG - 2011-09-12 00:32:49 --> Controller Class Initialized
DEBUG - 2011-09-12 00:32:49 --> Model Class Initialized
DEBUG - 2011-09-12 00:32:49 --> Model Class Initialized
DEBUG - 2011-09-12 00:32:49 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-12 00:32:49 --> Database Driver Class Initialized
DEBUG - 2011-09-12 00:32:51 --> Final output sent to browser
DEBUG - 2011-09-12 00:32:51 --> Total execution time: 1.4977
DEBUG - 2011-09-12 00:32:52 --> Config Class Initialized
DEBUG - 2011-09-12 00:32:52 --> Hooks Class Initialized
DEBUG - 2011-09-12 00:32:52 --> Utf8 Class Initialized
DEBUG - 2011-09-12 00:32:52 --> UTF-8 Support Enabled
DEBUG - 2011-09-12 00:32:52 --> URI Class Initialized
DEBUG - 2011-09-12 00:32:52 --> Router Class Initialized
ERROR - 2011-09-12 00:32:52 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-12 00:32:59 --> Config Class Initialized
DEBUG - 2011-09-12 00:32:59 --> Hooks Class Initialized
DEBUG - 2011-09-12 00:32:59 --> Utf8 Class Initialized
DEBUG - 2011-09-12 00:32:59 --> UTF-8 Support Enabled
DEBUG - 2011-09-12 00:32:59 --> URI Class Initialized
DEBUG - 2011-09-12 00:32:59 --> Router Class Initialized
DEBUG - 2011-09-12 00:32:59 --> Output Class Initialized
DEBUG - 2011-09-12 00:32:59 --> Input Class Initialized
DEBUG - 2011-09-12 00:32:59 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-12 00:32:59 --> Language Class Initialized
DEBUG - 2011-09-12 00:32:59 --> Loader Class Initialized
DEBUG - 2011-09-12 00:32:59 --> Controller Class Initialized
ERROR - 2011-09-12 00:32:59 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-12 00:32:59 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-12 00:32:59 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-12 00:32:59 --> Model Class Initialized
DEBUG - 2011-09-12 00:32:59 --> Model Class Initialized
DEBUG - 2011-09-12 00:32:59 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-12 00:32:59 --> Database Driver Class Initialized
DEBUG - 2011-09-12 00:32:59 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-12 00:32:59 --> Helper loaded: url_helper
DEBUG - 2011-09-12 00:32:59 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-12 00:32:59 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-12 00:32:59 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-12 00:32:59 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-12 00:32:59 --> Final output sent to browser
DEBUG - 2011-09-12 00:32:59 --> Total execution time: 0.0278
DEBUG - 2011-09-12 00:33:00 --> Config Class Initialized
DEBUG - 2011-09-12 00:33:00 --> Hooks Class Initialized
DEBUG - 2011-09-12 00:33:00 --> Utf8 Class Initialized
DEBUG - 2011-09-12 00:33:00 --> UTF-8 Support Enabled
DEBUG - 2011-09-12 00:33:00 --> URI Class Initialized
DEBUG - 2011-09-12 00:33:00 --> Router Class Initialized
DEBUG - 2011-09-12 00:33:00 --> Output Class Initialized
DEBUG - 2011-09-12 00:33:00 --> Input Class Initialized
DEBUG - 2011-09-12 00:33:00 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-12 00:33:00 --> Language Class Initialized
DEBUG - 2011-09-12 00:33:00 --> Loader Class Initialized
DEBUG - 2011-09-12 00:33:00 --> Controller Class Initialized
DEBUG - 2011-09-12 00:33:00 --> Model Class Initialized
DEBUG - 2011-09-12 00:33:00 --> Model Class Initialized
DEBUG - 2011-09-12 00:33:00 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-12 00:33:00 --> Database Driver Class Initialized
DEBUG - 2011-09-12 00:33:01 --> Final output sent to browser
DEBUG - 2011-09-12 00:33:01 --> Total execution time: 1.4101
DEBUG - 2011-09-12 00:33:03 --> Config Class Initialized
DEBUG - 2011-09-12 00:33:03 --> Hooks Class Initialized
DEBUG - 2011-09-12 00:33:03 --> Utf8 Class Initialized
DEBUG - 2011-09-12 00:33:03 --> UTF-8 Support Enabled
DEBUG - 2011-09-12 00:33:03 --> URI Class Initialized
DEBUG - 2011-09-12 00:33:03 --> Router Class Initialized
ERROR - 2011-09-12 00:33:03 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-12 00:33:07 --> Config Class Initialized
DEBUG - 2011-09-12 00:33:07 --> Hooks Class Initialized
DEBUG - 2011-09-12 00:33:07 --> Utf8 Class Initialized
DEBUG - 2011-09-12 00:33:07 --> UTF-8 Support Enabled
DEBUG - 2011-09-12 00:33:07 --> URI Class Initialized
DEBUG - 2011-09-12 00:33:07 --> Router Class Initialized
DEBUG - 2011-09-12 00:33:07 --> Output Class Initialized
DEBUG - 2011-09-12 00:33:07 --> Input Class Initialized
DEBUG - 2011-09-12 00:33:07 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-12 00:33:07 --> Language Class Initialized
DEBUG - 2011-09-12 00:33:07 --> Loader Class Initialized
DEBUG - 2011-09-12 00:33:07 --> Controller Class Initialized
ERROR - 2011-09-12 00:33:07 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-12 00:33:07 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-12 00:33:07 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-12 00:33:07 --> Model Class Initialized
DEBUG - 2011-09-12 00:33:07 --> Model Class Initialized
DEBUG - 2011-09-12 00:33:07 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-12 00:33:07 --> Database Driver Class Initialized
DEBUG - 2011-09-12 00:33:07 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-12 00:33:07 --> Helper loaded: url_helper
DEBUG - 2011-09-12 00:33:07 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-12 00:33:07 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-12 00:33:07 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-12 00:33:07 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-12 00:33:07 --> Final output sent to browser
DEBUG - 2011-09-12 00:33:07 --> Total execution time: 0.0292
DEBUG - 2011-09-12 00:33:07 --> Config Class Initialized
DEBUG - 2011-09-12 00:33:07 --> Hooks Class Initialized
DEBUG - 2011-09-12 00:33:07 --> Utf8 Class Initialized
DEBUG - 2011-09-12 00:33:07 --> UTF-8 Support Enabled
DEBUG - 2011-09-12 00:33:07 --> URI Class Initialized
DEBUG - 2011-09-12 00:33:07 --> Router Class Initialized
DEBUG - 2011-09-12 00:33:07 --> Output Class Initialized
DEBUG - 2011-09-12 00:33:07 --> Input Class Initialized
DEBUG - 2011-09-12 00:33:07 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-12 00:33:07 --> Language Class Initialized
DEBUG - 2011-09-12 00:33:07 --> Loader Class Initialized
DEBUG - 2011-09-12 00:33:07 --> Controller Class Initialized
DEBUG - 2011-09-12 00:33:07 --> Model Class Initialized
DEBUG - 2011-09-12 00:33:07 --> Model Class Initialized
DEBUG - 2011-09-12 00:33:07 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-12 00:33:07 --> Database Driver Class Initialized
DEBUG - 2011-09-12 00:33:09 --> Final output sent to browser
DEBUG - 2011-09-12 00:33:09 --> Total execution time: 1.3512
DEBUG - 2011-09-12 00:33:11 --> Config Class Initialized
DEBUG - 2011-09-12 00:33:11 --> Hooks Class Initialized
DEBUG - 2011-09-12 00:33:11 --> Utf8 Class Initialized
DEBUG - 2011-09-12 00:33:11 --> UTF-8 Support Enabled
DEBUG - 2011-09-12 00:33:11 --> URI Class Initialized
DEBUG - 2011-09-12 00:33:11 --> Router Class Initialized
ERROR - 2011-09-12 00:33:11 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-12 00:33:18 --> Config Class Initialized
DEBUG - 2011-09-12 00:33:18 --> Hooks Class Initialized
DEBUG - 2011-09-12 00:33:18 --> Utf8 Class Initialized
DEBUG - 2011-09-12 00:33:18 --> UTF-8 Support Enabled
DEBUG - 2011-09-12 00:33:18 --> URI Class Initialized
DEBUG - 2011-09-12 00:33:18 --> Router Class Initialized
DEBUG - 2011-09-12 00:33:18 --> Output Class Initialized
DEBUG - 2011-09-12 00:33:18 --> Input Class Initialized
DEBUG - 2011-09-12 00:33:18 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-12 00:33:18 --> Language Class Initialized
DEBUG - 2011-09-12 00:33:18 --> Loader Class Initialized
DEBUG - 2011-09-12 00:33:18 --> Controller Class Initialized
ERROR - 2011-09-12 00:33:18 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-12 00:33:18 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-12 00:33:18 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-12 00:33:18 --> Model Class Initialized
DEBUG - 2011-09-12 00:33:18 --> Model Class Initialized
DEBUG - 2011-09-12 00:33:18 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-12 00:33:18 --> Database Driver Class Initialized
DEBUG - 2011-09-12 00:33:18 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-12 00:33:18 --> Helper loaded: url_helper
DEBUG - 2011-09-12 00:33:18 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-12 00:33:18 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-12 00:33:18 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-12 00:33:18 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-12 00:33:18 --> Final output sent to browser
DEBUG - 2011-09-12 00:33:18 --> Total execution time: 0.0320
DEBUG - 2011-09-12 00:33:19 --> Config Class Initialized
DEBUG - 2011-09-12 00:33:19 --> Hooks Class Initialized
DEBUG - 2011-09-12 00:33:19 --> Utf8 Class Initialized
DEBUG - 2011-09-12 00:33:19 --> UTF-8 Support Enabled
DEBUG - 2011-09-12 00:33:19 --> URI Class Initialized
DEBUG - 2011-09-12 00:33:19 --> Router Class Initialized
DEBUG - 2011-09-12 00:33:19 --> Output Class Initialized
DEBUG - 2011-09-12 00:33:19 --> Input Class Initialized
DEBUG - 2011-09-12 00:33:19 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-12 00:33:19 --> Language Class Initialized
DEBUG - 2011-09-12 00:33:19 --> Loader Class Initialized
DEBUG - 2011-09-12 00:33:19 --> Controller Class Initialized
DEBUG - 2011-09-12 00:33:19 --> Model Class Initialized
DEBUG - 2011-09-12 00:33:19 --> Model Class Initialized
DEBUG - 2011-09-12 00:33:19 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-12 00:33:19 --> Database Driver Class Initialized
DEBUG - 2011-09-12 00:33:20 --> Final output sent to browser
DEBUG - 2011-09-12 00:33:20 --> Total execution time: 1.3170
DEBUG - 2011-09-12 00:33:25 --> Config Class Initialized
DEBUG - 2011-09-12 00:33:25 --> Hooks Class Initialized
DEBUG - 2011-09-12 00:33:25 --> Utf8 Class Initialized
DEBUG - 2011-09-12 00:33:25 --> UTF-8 Support Enabled
DEBUG - 2011-09-12 00:33:25 --> URI Class Initialized
DEBUG - 2011-09-12 00:33:25 --> Router Class Initialized
ERROR - 2011-09-12 00:33:25 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-12 00:33:27 --> Config Class Initialized
DEBUG - 2011-09-12 00:33:27 --> Hooks Class Initialized
DEBUG - 2011-09-12 00:33:27 --> Utf8 Class Initialized
DEBUG - 2011-09-12 00:33:27 --> UTF-8 Support Enabled
DEBUG - 2011-09-12 00:33:27 --> URI Class Initialized
DEBUG - 2011-09-12 00:33:27 --> Router Class Initialized
DEBUG - 2011-09-12 00:33:27 --> Output Class Initialized
DEBUG - 2011-09-12 00:33:27 --> Input Class Initialized
DEBUG - 2011-09-12 00:33:27 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-12 00:33:27 --> Language Class Initialized
DEBUG - 2011-09-12 00:33:27 --> Loader Class Initialized
DEBUG - 2011-09-12 00:33:27 --> Controller Class Initialized
ERROR - 2011-09-12 00:33:27 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-12 00:33:27 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-12 00:33:27 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-12 00:33:27 --> Model Class Initialized
DEBUG - 2011-09-12 00:33:27 --> Model Class Initialized
DEBUG - 2011-09-12 00:33:27 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-12 00:33:27 --> Database Driver Class Initialized
DEBUG - 2011-09-12 00:33:27 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-12 00:33:27 --> Helper loaded: url_helper
DEBUG - 2011-09-12 00:33:27 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-12 00:33:27 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-12 00:33:27 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-12 00:33:27 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-12 00:33:27 --> Final output sent to browser
DEBUG - 2011-09-12 00:33:27 --> Total execution time: 0.0287
DEBUG - 2011-09-12 00:33:28 --> Config Class Initialized
DEBUG - 2011-09-12 00:33:28 --> Hooks Class Initialized
DEBUG - 2011-09-12 00:33:28 --> Utf8 Class Initialized
DEBUG - 2011-09-12 00:33:28 --> UTF-8 Support Enabled
DEBUG - 2011-09-12 00:33:28 --> URI Class Initialized
DEBUG - 2011-09-12 00:33:28 --> Router Class Initialized
DEBUG - 2011-09-12 00:33:28 --> Output Class Initialized
DEBUG - 2011-09-12 00:33:28 --> Input Class Initialized
DEBUG - 2011-09-12 00:33:28 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-12 00:33:28 --> Language Class Initialized
DEBUG - 2011-09-12 00:33:28 --> Loader Class Initialized
DEBUG - 2011-09-12 00:33:28 --> Controller Class Initialized
DEBUG - 2011-09-12 00:33:28 --> Model Class Initialized
DEBUG - 2011-09-12 00:33:28 --> Model Class Initialized
DEBUG - 2011-09-12 00:33:28 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-12 00:33:28 --> Database Driver Class Initialized
DEBUG - 2011-09-12 00:33:29 --> Final output sent to browser
DEBUG - 2011-09-12 00:33:29 --> Total execution time: 1.4998
DEBUG - 2011-09-12 00:33:31 --> Config Class Initialized
DEBUG - 2011-09-12 00:33:31 --> Hooks Class Initialized
DEBUG - 2011-09-12 00:33:31 --> Utf8 Class Initialized
DEBUG - 2011-09-12 00:33:31 --> UTF-8 Support Enabled
DEBUG - 2011-09-12 00:33:31 --> URI Class Initialized
DEBUG - 2011-09-12 00:33:31 --> Router Class Initialized
ERROR - 2011-09-12 00:33:31 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-12 01:03:28 --> Config Class Initialized
DEBUG - 2011-09-12 01:03:28 --> Hooks Class Initialized
DEBUG - 2011-09-12 01:03:28 --> Utf8 Class Initialized
DEBUG - 2011-09-12 01:03:28 --> UTF-8 Support Enabled
DEBUG - 2011-09-12 01:03:28 --> URI Class Initialized
DEBUG - 2011-09-12 01:03:28 --> Router Class Initialized
DEBUG - 2011-09-12 01:03:28 --> Output Class Initialized
DEBUG - 2011-09-12 01:03:28 --> Input Class Initialized
DEBUG - 2011-09-12 01:03:28 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-12 01:03:28 --> Language Class Initialized
DEBUG - 2011-09-12 01:03:28 --> Loader Class Initialized
DEBUG - 2011-09-12 01:03:28 --> Controller Class Initialized
ERROR - 2011-09-12 01:03:28 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-12 01:03:28 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-12 01:03:28 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-12 01:03:28 --> Model Class Initialized
DEBUG - 2011-09-12 01:03:28 --> Model Class Initialized
DEBUG - 2011-09-12 01:03:28 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-12 01:03:28 --> Database Driver Class Initialized
DEBUG - 2011-09-12 01:03:28 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-12 01:03:28 --> Helper loaded: url_helper
DEBUG - 2011-09-12 01:03:28 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-12 01:03:28 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-12 01:03:28 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-12 01:03:28 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-12 01:03:28 --> Final output sent to browser
DEBUG - 2011-09-12 01:03:28 --> Total execution time: 0.0506
DEBUG - 2011-09-12 01:03:29 --> Config Class Initialized
DEBUG - 2011-09-12 01:03:29 --> Hooks Class Initialized
DEBUG - 2011-09-12 01:03:29 --> Utf8 Class Initialized
DEBUG - 2011-09-12 01:03:29 --> UTF-8 Support Enabled
DEBUG - 2011-09-12 01:03:29 --> URI Class Initialized
DEBUG - 2011-09-12 01:03:29 --> Router Class Initialized
DEBUG - 2011-09-12 01:03:29 --> Output Class Initialized
DEBUG - 2011-09-12 01:03:29 --> Input Class Initialized
DEBUG - 2011-09-12 01:03:29 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-12 01:03:29 --> Language Class Initialized
DEBUG - 2011-09-12 01:03:29 --> Loader Class Initialized
DEBUG - 2011-09-12 01:03:29 --> Controller Class Initialized
DEBUG - 2011-09-12 01:03:29 --> Model Class Initialized
DEBUG - 2011-09-12 01:03:29 --> Model Class Initialized
DEBUG - 2011-09-12 01:03:29 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-12 01:03:29 --> Database Driver Class Initialized
DEBUG - 2011-09-12 01:03:31 --> Final output sent to browser
DEBUG - 2011-09-12 01:03:31 --> Total execution time: 1.6071
DEBUG - 2011-09-12 01:03:32 --> Config Class Initialized
DEBUG - 2011-09-12 01:03:32 --> Hooks Class Initialized
DEBUG - 2011-09-12 01:03:32 --> Utf8 Class Initialized
DEBUG - 2011-09-12 01:03:32 --> UTF-8 Support Enabled
DEBUG - 2011-09-12 01:03:32 --> URI Class Initialized
DEBUG - 2011-09-12 01:03:32 --> Router Class Initialized
ERROR - 2011-09-12 01:03:32 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-12 01:03:33 --> Config Class Initialized
DEBUG - 2011-09-12 01:03:33 --> Hooks Class Initialized
DEBUG - 2011-09-12 01:03:33 --> Utf8 Class Initialized
DEBUG - 2011-09-12 01:03:33 --> UTF-8 Support Enabled
DEBUG - 2011-09-12 01:03:33 --> URI Class Initialized
DEBUG - 2011-09-12 01:03:33 --> Router Class Initialized
ERROR - 2011-09-12 01:03:33 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-12 01:48:30 --> Config Class Initialized
DEBUG - 2011-09-12 01:48:30 --> Hooks Class Initialized
DEBUG - 2011-09-12 01:48:30 --> Utf8 Class Initialized
DEBUG - 2011-09-12 01:48:30 --> UTF-8 Support Enabled
DEBUG - 2011-09-12 01:48:30 --> URI Class Initialized
DEBUG - 2011-09-12 01:48:30 --> Router Class Initialized
DEBUG - 2011-09-12 01:48:30 --> Output Class Initialized
DEBUG - 2011-09-12 01:48:30 --> Input Class Initialized
DEBUG - 2011-09-12 01:48:30 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-12 01:48:30 --> Language Class Initialized
DEBUG - 2011-09-12 01:48:30 --> Loader Class Initialized
DEBUG - 2011-09-12 01:48:30 --> Controller Class Initialized
ERROR - 2011-09-12 01:48:30 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-12 01:48:30 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-12 01:48:30 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-12 01:48:30 --> Model Class Initialized
DEBUG - 2011-09-12 01:48:30 --> Model Class Initialized
DEBUG - 2011-09-12 01:48:30 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-12 01:48:30 --> Database Driver Class Initialized
DEBUG - 2011-09-12 01:48:31 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-12 01:48:31 --> Helper loaded: url_helper
DEBUG - 2011-09-12 01:48:31 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-12 01:48:31 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-12 01:48:31 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-12 01:48:31 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-12 01:48:31 --> Final output sent to browser
DEBUG - 2011-09-12 01:48:31 --> Total execution time: 1.2686
DEBUG - 2011-09-12 01:48:32 --> Config Class Initialized
DEBUG - 2011-09-12 01:48:32 --> Hooks Class Initialized
DEBUG - 2011-09-12 01:48:32 --> Utf8 Class Initialized
DEBUG - 2011-09-12 01:48:32 --> UTF-8 Support Enabled
DEBUG - 2011-09-12 01:48:32 --> URI Class Initialized
DEBUG - 2011-09-12 01:48:32 --> Router Class Initialized
DEBUG - 2011-09-12 01:48:32 --> Output Class Initialized
DEBUG - 2011-09-12 01:48:32 --> Input Class Initialized
DEBUG - 2011-09-12 01:48:32 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-12 01:48:32 --> Language Class Initialized
DEBUG - 2011-09-12 01:48:32 --> Loader Class Initialized
DEBUG - 2011-09-12 01:48:32 --> Controller Class Initialized
DEBUG - 2011-09-12 01:48:32 --> Model Class Initialized
DEBUG - 2011-09-12 01:48:32 --> Model Class Initialized
DEBUG - 2011-09-12 01:48:32 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-12 01:48:32 --> Database Driver Class Initialized
DEBUG - 2011-09-12 01:48:34 --> Final output sent to browser
DEBUG - 2011-09-12 01:48:34 --> Total execution time: 1.5030
DEBUG - 2011-09-12 01:48:35 --> Config Class Initialized
DEBUG - 2011-09-12 01:48:35 --> Hooks Class Initialized
DEBUG - 2011-09-12 01:48:35 --> Utf8 Class Initialized
DEBUG - 2011-09-12 01:48:35 --> UTF-8 Support Enabled
DEBUG - 2011-09-12 01:48:35 --> URI Class Initialized
DEBUG - 2011-09-12 01:48:35 --> Router Class Initialized
ERROR - 2011-09-12 01:48:35 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-12 01:48:35 --> Config Class Initialized
DEBUG - 2011-09-12 01:48:35 --> Hooks Class Initialized
DEBUG - 2011-09-12 01:48:35 --> Utf8 Class Initialized
DEBUG - 2011-09-12 01:48:35 --> UTF-8 Support Enabled
DEBUG - 2011-09-12 01:48:35 --> URI Class Initialized
DEBUG - 2011-09-12 01:48:35 --> Router Class Initialized
ERROR - 2011-09-12 01:48:35 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-12 01:48:39 --> Config Class Initialized
DEBUG - 2011-09-12 01:48:39 --> Hooks Class Initialized
DEBUG - 2011-09-12 01:48:39 --> Utf8 Class Initialized
DEBUG - 2011-09-12 01:48:39 --> UTF-8 Support Enabled
DEBUG - 2011-09-12 01:48:39 --> URI Class Initialized
DEBUG - 2011-09-12 01:48:39 --> Router Class Initialized
ERROR - 2011-09-12 01:48:39 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-12 01:49:01 --> Config Class Initialized
DEBUG - 2011-09-12 01:49:01 --> Hooks Class Initialized
DEBUG - 2011-09-12 01:49:01 --> Utf8 Class Initialized
DEBUG - 2011-09-12 01:49:01 --> UTF-8 Support Enabled
DEBUG - 2011-09-12 01:49:01 --> URI Class Initialized
DEBUG - 2011-09-12 01:49:01 --> Router Class Initialized
DEBUG - 2011-09-12 01:49:01 --> Output Class Initialized
DEBUG - 2011-09-12 01:49:01 --> Input Class Initialized
DEBUG - 2011-09-12 01:49:01 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-12 01:49:01 --> Language Class Initialized
DEBUG - 2011-09-12 01:49:01 --> Loader Class Initialized
DEBUG - 2011-09-12 01:49:01 --> Controller Class Initialized
ERROR - 2011-09-12 01:49:01 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-12 01:49:01 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-12 01:49:01 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-12 01:49:01 --> Model Class Initialized
DEBUG - 2011-09-12 01:49:01 --> Model Class Initialized
DEBUG - 2011-09-12 01:49:01 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-12 01:49:01 --> Database Driver Class Initialized
DEBUG - 2011-09-12 01:49:01 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-12 01:49:01 --> Helper loaded: url_helper
DEBUG - 2011-09-12 01:49:01 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-12 01:49:01 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-12 01:49:01 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-12 01:49:01 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-12 01:49:01 --> Final output sent to browser
DEBUG - 2011-09-12 01:49:01 --> Total execution time: 0.0333
DEBUG - 2011-09-12 01:49:01 --> Config Class Initialized
DEBUG - 2011-09-12 01:49:01 --> Hooks Class Initialized
DEBUG - 2011-09-12 01:49:01 --> Utf8 Class Initialized
DEBUG - 2011-09-12 01:49:01 --> UTF-8 Support Enabled
DEBUG - 2011-09-12 01:49:01 --> URI Class Initialized
DEBUG - 2011-09-12 01:49:01 --> Router Class Initialized
DEBUG - 2011-09-12 01:49:01 --> Output Class Initialized
DEBUG - 2011-09-12 01:49:01 --> Input Class Initialized
DEBUG - 2011-09-12 01:49:01 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-12 01:49:01 --> Language Class Initialized
DEBUG - 2011-09-12 01:49:01 --> Loader Class Initialized
DEBUG - 2011-09-12 01:49:01 --> Controller Class Initialized
DEBUG - 2011-09-12 01:49:01 --> Model Class Initialized
DEBUG - 2011-09-12 01:49:01 --> Model Class Initialized
DEBUG - 2011-09-12 01:49:01 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-12 01:49:01 --> Database Driver Class Initialized
DEBUG - 2011-09-12 01:49:03 --> Final output sent to browser
DEBUG - 2011-09-12 01:49:03 --> Total execution time: 1.8857
DEBUG - 2011-09-12 01:49:17 --> Config Class Initialized
DEBUG - 2011-09-12 01:49:17 --> Hooks Class Initialized
DEBUG - 2011-09-12 01:49:17 --> Utf8 Class Initialized
DEBUG - 2011-09-12 01:49:17 --> UTF-8 Support Enabled
DEBUG - 2011-09-12 01:49:17 --> URI Class Initialized
DEBUG - 2011-09-12 01:49:17 --> Router Class Initialized
DEBUG - 2011-09-12 01:49:17 --> Output Class Initialized
DEBUG - 2011-09-12 01:49:17 --> Input Class Initialized
DEBUG - 2011-09-12 01:49:17 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-12 01:49:17 --> Language Class Initialized
DEBUG - 2011-09-12 01:49:17 --> Loader Class Initialized
DEBUG - 2011-09-12 01:49:17 --> Controller Class Initialized
ERROR - 2011-09-12 01:49:17 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-12 01:49:17 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-12 01:49:17 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-12 01:49:17 --> Model Class Initialized
DEBUG - 2011-09-12 01:49:17 --> Model Class Initialized
DEBUG - 2011-09-12 01:49:17 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-12 01:49:17 --> Database Driver Class Initialized
DEBUG - 2011-09-12 01:49:17 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-12 01:49:17 --> Helper loaded: url_helper
DEBUG - 2011-09-12 01:49:17 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-12 01:49:17 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-12 01:49:17 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-12 01:49:17 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-12 01:49:17 --> Final output sent to browser
DEBUG - 2011-09-12 01:49:17 --> Total execution time: 0.0308
DEBUG - 2011-09-12 01:49:18 --> Config Class Initialized
DEBUG - 2011-09-12 01:49:18 --> Hooks Class Initialized
DEBUG - 2011-09-12 01:49:18 --> Utf8 Class Initialized
DEBUG - 2011-09-12 01:49:18 --> UTF-8 Support Enabled
DEBUG - 2011-09-12 01:49:18 --> URI Class Initialized
DEBUG - 2011-09-12 01:49:18 --> Router Class Initialized
DEBUG - 2011-09-12 01:49:18 --> Output Class Initialized
DEBUG - 2011-09-12 01:49:18 --> Input Class Initialized
DEBUG - 2011-09-12 01:49:18 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-12 01:49:18 --> Language Class Initialized
DEBUG - 2011-09-12 01:49:18 --> Loader Class Initialized
DEBUG - 2011-09-12 01:49:18 --> Controller Class Initialized
DEBUG - 2011-09-12 01:49:18 --> Model Class Initialized
DEBUG - 2011-09-12 01:49:18 --> Model Class Initialized
DEBUG - 2011-09-12 01:49:18 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-12 01:49:18 --> Database Driver Class Initialized
DEBUG - 2011-09-12 01:49:19 --> Final output sent to browser
DEBUG - 2011-09-12 01:49:19 --> Total execution time: 1.5488
DEBUG - 2011-09-12 02:50:49 --> Config Class Initialized
DEBUG - 2011-09-12 02:50:49 --> Hooks Class Initialized
DEBUG - 2011-09-12 02:50:49 --> Utf8 Class Initialized
DEBUG - 2011-09-12 02:50:49 --> UTF-8 Support Enabled
DEBUG - 2011-09-12 02:50:49 --> URI Class Initialized
DEBUG - 2011-09-12 02:50:49 --> Router Class Initialized
ERROR - 2011-09-12 02:50:49 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-09-12 03:34:46 --> Config Class Initialized
DEBUG - 2011-09-12 03:34:46 --> Hooks Class Initialized
DEBUG - 2011-09-12 03:34:46 --> Utf8 Class Initialized
DEBUG - 2011-09-12 03:34:46 --> UTF-8 Support Enabled
DEBUG - 2011-09-12 03:34:46 --> URI Class Initialized
DEBUG - 2011-09-12 03:34:46 --> Router Class Initialized
DEBUG - 2011-09-12 03:34:47 --> Output Class Initialized
DEBUG - 2011-09-12 03:34:47 --> Input Class Initialized
DEBUG - 2011-09-12 03:34:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-12 03:34:47 --> Language Class Initialized
DEBUG - 2011-09-12 03:34:47 --> Loader Class Initialized
DEBUG - 2011-09-12 03:34:47 --> Controller Class Initialized
ERROR - 2011-09-12 03:34:47 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-12 03:34:47 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-12 03:34:47 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-12 03:34:47 --> Model Class Initialized
DEBUG - 2011-09-12 03:34:47 --> Model Class Initialized
DEBUG - 2011-09-12 03:34:47 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-12 03:34:47 --> Database Driver Class Initialized
DEBUG - 2011-09-12 03:34:47 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-12 03:34:47 --> Helper loaded: url_helper
DEBUG - 2011-09-12 03:34:47 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-12 03:34:47 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-12 03:34:47 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-12 03:34:47 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-12 03:34:47 --> Final output sent to browser
DEBUG - 2011-09-12 03:34:47 --> Total execution time: 0.5974
DEBUG - 2011-09-12 03:34:49 --> Config Class Initialized
DEBUG - 2011-09-12 03:34:49 --> Hooks Class Initialized
DEBUG - 2011-09-12 03:34:49 --> Utf8 Class Initialized
DEBUG - 2011-09-12 03:34:49 --> UTF-8 Support Enabled
DEBUG - 2011-09-12 03:34:49 --> URI Class Initialized
DEBUG - 2011-09-12 03:34:49 --> Router Class Initialized
DEBUG - 2011-09-12 03:34:49 --> Output Class Initialized
DEBUG - 2011-09-12 03:34:49 --> Input Class Initialized
DEBUG - 2011-09-12 03:34:49 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-12 03:34:49 --> Language Class Initialized
DEBUG - 2011-09-12 03:34:49 --> Loader Class Initialized
DEBUG - 2011-09-12 03:34:49 --> Controller Class Initialized
DEBUG - 2011-09-12 03:34:49 --> Model Class Initialized
DEBUG - 2011-09-12 03:34:49 --> Model Class Initialized
DEBUG - 2011-09-12 03:34:49 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-12 03:34:49 --> Database Driver Class Initialized
DEBUG - 2011-09-12 03:34:50 --> Final output sent to browser
DEBUG - 2011-09-12 03:34:50 --> Total execution time: 1.8188
DEBUG - 2011-09-12 03:34:53 --> Config Class Initialized
DEBUG - 2011-09-12 03:34:53 --> Hooks Class Initialized
DEBUG - 2011-09-12 03:34:53 --> Utf8 Class Initialized
DEBUG - 2011-09-12 03:34:53 --> UTF-8 Support Enabled
DEBUG - 2011-09-12 03:34:53 --> URI Class Initialized
DEBUG - 2011-09-12 03:34:53 --> Router Class Initialized
ERROR - 2011-09-12 03:34:53 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-12 03:34:57 --> Config Class Initialized
DEBUG - 2011-09-12 03:34:57 --> Hooks Class Initialized
DEBUG - 2011-09-12 03:34:57 --> Utf8 Class Initialized
DEBUG - 2011-09-12 03:34:57 --> UTF-8 Support Enabled
DEBUG - 2011-09-12 03:34:57 --> URI Class Initialized
DEBUG - 2011-09-12 03:34:57 --> Router Class Initialized
ERROR - 2011-09-12 03:34:57 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-12 03:59:57 --> Config Class Initialized
DEBUG - 2011-09-12 03:59:57 --> Hooks Class Initialized
DEBUG - 2011-09-12 03:59:57 --> Utf8 Class Initialized
DEBUG - 2011-09-12 03:59:57 --> UTF-8 Support Enabled
DEBUG - 2011-09-12 03:59:57 --> URI Class Initialized
DEBUG - 2011-09-12 03:59:57 --> Router Class Initialized
DEBUG - 2011-09-12 03:59:57 --> Output Class Initialized
DEBUG - 2011-09-12 03:59:57 --> Input Class Initialized
DEBUG - 2011-09-12 03:59:57 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-12 03:59:57 --> Language Class Initialized
DEBUG - 2011-09-12 03:59:57 --> Loader Class Initialized
DEBUG - 2011-09-12 03:59:57 --> Controller Class Initialized
DEBUG - 2011-09-12 03:59:57 --> Model Class Initialized
DEBUG - 2011-09-12 03:59:57 --> Model Class Initialized
DEBUG - 2011-09-12 03:59:57 --> Model Class Initialized
DEBUG - 2011-09-12 03:59:57 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-12 03:59:57 --> Database Driver Class Initialized
DEBUG - 2011-09-12 04:00:00 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-12 04:00:00 --> Helper loaded: url_helper
DEBUG - 2011-09-12 04:00:00 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-12 04:00:00 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-12 04:00:00 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-12 04:00:00 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-12 04:00:00 --> Final output sent to browser
DEBUG - 2011-09-12 04:00:00 --> Total execution time: 3.0523
DEBUG - 2011-09-12 04:00:32 --> Config Class Initialized
DEBUG - 2011-09-12 04:00:32 --> Hooks Class Initialized
DEBUG - 2011-09-12 04:00:32 --> Utf8 Class Initialized
DEBUG - 2011-09-12 04:00:32 --> UTF-8 Support Enabled
DEBUG - 2011-09-12 04:00:32 --> URI Class Initialized
DEBUG - 2011-09-12 04:00:32 --> Router Class Initialized
DEBUG - 2011-09-12 04:00:32 --> Output Class Initialized
DEBUG - 2011-09-12 04:00:32 --> Input Class Initialized
DEBUG - 2011-09-12 04:00:32 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-12 04:00:32 --> Language Class Initialized
DEBUG - 2011-09-12 04:00:32 --> Loader Class Initialized
DEBUG - 2011-09-12 04:00:32 --> Controller Class Initialized
DEBUG - 2011-09-12 04:00:32 --> Model Class Initialized
DEBUG - 2011-09-12 04:00:32 --> Model Class Initialized
DEBUG - 2011-09-12 04:00:32 --> Model Class Initialized
DEBUG - 2011-09-12 04:00:32 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-12 04:00:32 --> Database Driver Class Initialized
DEBUG - 2011-09-12 04:00:34 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-12 04:00:34 --> Helper loaded: url_helper
DEBUG - 2011-09-12 04:00:34 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-12 04:00:34 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-12 04:00:34 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-12 04:00:34 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-12 04:00:34 --> Final output sent to browser
DEBUG - 2011-09-12 04:00:34 --> Total execution time: 1.7989
DEBUG - 2011-09-12 04:00:54 --> Config Class Initialized
DEBUG - 2011-09-12 04:00:54 --> Hooks Class Initialized
DEBUG - 2011-09-12 04:00:54 --> Utf8 Class Initialized
DEBUG - 2011-09-12 04:00:54 --> UTF-8 Support Enabled
DEBUG - 2011-09-12 04:00:54 --> URI Class Initialized
DEBUG - 2011-09-12 04:00:54 --> Router Class Initialized
DEBUG - 2011-09-12 04:00:54 --> Output Class Initialized
DEBUG - 2011-09-12 04:00:54 --> Input Class Initialized
DEBUG - 2011-09-12 04:00:54 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-12 04:00:54 --> Language Class Initialized
DEBUG - 2011-09-12 04:00:54 --> Loader Class Initialized
DEBUG - 2011-09-12 04:00:54 --> Controller Class Initialized
DEBUG - 2011-09-12 04:00:54 --> Model Class Initialized
DEBUG - 2011-09-12 04:00:54 --> Model Class Initialized
DEBUG - 2011-09-12 04:00:54 --> Model Class Initialized
DEBUG - 2011-09-12 04:00:54 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-12 04:00:54 --> Database Driver Class Initialized
DEBUG - 2011-09-12 04:00:54 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-12 04:00:54 --> Helper loaded: url_helper
DEBUG - 2011-09-12 04:00:54 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-12 04:00:54 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-12 04:00:54 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-12 04:00:54 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-12 04:00:54 --> Final output sent to browser
DEBUG - 2011-09-12 04:00:54 --> Total execution time: 0.3868
DEBUG - 2011-09-12 04:02:31 --> Config Class Initialized
DEBUG - 2011-09-12 04:02:31 --> Hooks Class Initialized
DEBUG - 2011-09-12 04:02:31 --> Utf8 Class Initialized
DEBUG - 2011-09-12 04:02:31 --> UTF-8 Support Enabled
DEBUG - 2011-09-12 04:02:31 --> URI Class Initialized
DEBUG - 2011-09-12 04:02:31 --> Router Class Initialized
ERROR - 2011-09-12 04:02:31 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-09-12 04:02:31 --> Config Class Initialized
DEBUG - 2011-09-12 04:02:31 --> Hooks Class Initialized
DEBUG - 2011-09-12 04:02:31 --> Utf8 Class Initialized
DEBUG - 2011-09-12 04:02:31 --> UTF-8 Support Enabled
DEBUG - 2011-09-12 04:02:31 --> URI Class Initialized
DEBUG - 2011-09-12 04:02:31 --> Router Class Initialized
DEBUG - 2011-09-12 04:02:31 --> Output Class Initialized
DEBUG - 2011-09-12 04:02:31 --> Input Class Initialized
DEBUG - 2011-09-12 04:02:31 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-12 04:02:31 --> Language Class Initialized
DEBUG - 2011-09-12 04:02:31 --> Loader Class Initialized
DEBUG - 2011-09-12 04:02:31 --> Controller Class Initialized
DEBUG - 2011-09-12 04:02:31 --> Model Class Initialized
DEBUG - 2011-09-12 04:02:31 --> Model Class Initialized
DEBUG - 2011-09-12 04:02:31 --> Model Class Initialized
DEBUG - 2011-09-12 04:02:31 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-12 04:02:31 --> Database Driver Class Initialized
DEBUG - 2011-09-12 04:02:31 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-12 04:02:31 --> Helper loaded: url_helper
DEBUG - 2011-09-12 04:02:31 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-12 04:02:31 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-12 04:02:31 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-12 04:02:31 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-12 04:02:31 --> Final output sent to browser
DEBUG - 2011-09-12 04:02:31 --> Total execution time: 0.1455
DEBUG - 2011-09-12 04:02:37 --> Config Class Initialized
DEBUG - 2011-09-12 04:02:37 --> Hooks Class Initialized
DEBUG - 2011-09-12 04:02:37 --> Utf8 Class Initialized
DEBUG - 2011-09-12 04:02:37 --> UTF-8 Support Enabled
DEBUG - 2011-09-12 04:02:37 --> URI Class Initialized
DEBUG - 2011-09-12 04:02:37 --> Router Class Initialized
DEBUG - 2011-09-12 04:02:37 --> Output Class Initialized
DEBUG - 2011-09-12 04:02:37 --> Input Class Initialized
DEBUG - 2011-09-12 04:02:37 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-12 04:02:37 --> Language Class Initialized
DEBUG - 2011-09-12 04:02:37 --> Loader Class Initialized
DEBUG - 2011-09-12 04:02:37 --> Controller Class Initialized
DEBUG - 2011-09-12 04:02:37 --> Model Class Initialized
DEBUG - 2011-09-12 04:02:37 --> Model Class Initialized
DEBUG - 2011-09-12 04:02:37 --> Model Class Initialized
DEBUG - 2011-09-12 04:02:37 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-12 04:02:37 --> Database Driver Class Initialized
DEBUG - 2011-09-12 04:02:37 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-12 04:02:37 --> Helper loaded: url_helper
DEBUG - 2011-09-12 04:02:37 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-12 04:02:37 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-12 04:02:37 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-12 04:02:37 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-12 04:02:37 --> Final output sent to browser
DEBUG - 2011-09-12 04:02:37 --> Total execution time: 0.1637
DEBUG - 2011-09-12 04:12:50 --> Config Class Initialized
DEBUG - 2011-09-12 04:12:50 --> Hooks Class Initialized
DEBUG - 2011-09-12 04:12:50 --> Utf8 Class Initialized
DEBUG - 2011-09-12 04:12:50 --> UTF-8 Support Enabled
DEBUG - 2011-09-12 04:12:50 --> URI Class Initialized
DEBUG - 2011-09-12 04:12:50 --> Router Class Initialized
DEBUG - 2011-09-12 04:12:50 --> Output Class Initialized
DEBUG - 2011-09-12 04:12:50 --> Input Class Initialized
DEBUG - 2011-09-12 04:12:50 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-12 04:12:50 --> Language Class Initialized
DEBUG - 2011-09-12 04:12:50 --> Loader Class Initialized
DEBUG - 2011-09-12 04:12:50 --> Controller Class Initialized
ERROR - 2011-09-12 04:12:50 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-12 04:12:50 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-12 04:12:50 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-12 04:12:50 --> Model Class Initialized
DEBUG - 2011-09-12 04:12:50 --> Model Class Initialized
DEBUG - 2011-09-12 04:12:50 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-12 04:12:50 --> Database Driver Class Initialized
DEBUG - 2011-09-12 04:12:50 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-12 04:12:50 --> Helper loaded: url_helper
DEBUG - 2011-09-12 04:12:50 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-12 04:12:50 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-12 04:12:50 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-12 04:12:50 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-12 04:12:50 --> Final output sent to browser
DEBUG - 2011-09-12 04:12:50 --> Total execution time: 0.0838
DEBUG - 2011-09-12 04:12:51 --> Config Class Initialized
DEBUG - 2011-09-12 04:12:51 --> Hooks Class Initialized
DEBUG - 2011-09-12 04:12:51 --> Utf8 Class Initialized
DEBUG - 2011-09-12 04:12:51 --> UTF-8 Support Enabled
DEBUG - 2011-09-12 04:12:51 --> URI Class Initialized
DEBUG - 2011-09-12 04:12:51 --> Router Class Initialized
DEBUG - 2011-09-12 04:12:51 --> Output Class Initialized
DEBUG - 2011-09-12 04:12:51 --> Input Class Initialized
DEBUG - 2011-09-12 04:12:51 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-12 04:12:51 --> Language Class Initialized
DEBUG - 2011-09-12 04:12:51 --> Loader Class Initialized
DEBUG - 2011-09-12 04:12:51 --> Controller Class Initialized
DEBUG - 2011-09-12 04:12:51 --> Model Class Initialized
DEBUG - 2011-09-12 04:12:51 --> Model Class Initialized
DEBUG - 2011-09-12 04:12:51 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-12 04:12:51 --> Database Driver Class Initialized
DEBUG - 2011-09-12 04:12:53 --> Final output sent to browser
DEBUG - 2011-09-12 04:12:53 --> Total execution time: 1.4323
DEBUG - 2011-09-12 04:28:32 --> Config Class Initialized
DEBUG - 2011-09-12 04:28:32 --> Hooks Class Initialized
DEBUG - 2011-09-12 04:28:32 --> Utf8 Class Initialized
DEBUG - 2011-09-12 04:28:32 --> UTF-8 Support Enabled
DEBUG - 2011-09-12 04:28:32 --> URI Class Initialized
DEBUG - 2011-09-12 04:28:32 --> Router Class Initialized
DEBUG - 2011-09-12 04:28:32 --> Output Class Initialized
DEBUG - 2011-09-12 04:28:32 --> Input Class Initialized
DEBUG - 2011-09-12 04:28:32 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-12 04:28:32 --> Language Class Initialized
DEBUG - 2011-09-12 04:28:32 --> Loader Class Initialized
DEBUG - 2011-09-12 04:28:32 --> Controller Class Initialized
ERROR - 2011-09-12 04:28:32 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-12 04:28:32 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-12 04:28:32 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-12 04:28:32 --> Model Class Initialized
DEBUG - 2011-09-12 04:28:32 --> Model Class Initialized
DEBUG - 2011-09-12 04:28:32 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-12 04:28:32 --> Database Driver Class Initialized
DEBUG - 2011-09-12 04:28:32 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-12 04:28:32 --> Helper loaded: url_helper
DEBUG - 2011-09-12 04:28:32 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-12 04:28:32 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-12 04:28:32 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-12 04:28:32 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-12 04:28:32 --> Final output sent to browser
DEBUG - 2011-09-12 04:28:32 --> Total execution time: 0.2977
DEBUG - 2011-09-12 04:28:34 --> Config Class Initialized
DEBUG - 2011-09-12 04:28:34 --> Hooks Class Initialized
DEBUG - 2011-09-12 04:28:34 --> Utf8 Class Initialized
DEBUG - 2011-09-12 04:28:34 --> UTF-8 Support Enabled
DEBUG - 2011-09-12 04:28:34 --> URI Class Initialized
DEBUG - 2011-09-12 04:28:34 --> Router Class Initialized
DEBUG - 2011-09-12 04:28:34 --> Output Class Initialized
DEBUG - 2011-09-12 04:28:34 --> Input Class Initialized
DEBUG - 2011-09-12 04:28:34 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-12 04:28:34 --> Language Class Initialized
DEBUG - 2011-09-12 04:28:34 --> Loader Class Initialized
DEBUG - 2011-09-12 04:28:34 --> Controller Class Initialized
DEBUG - 2011-09-12 04:28:34 --> Model Class Initialized
DEBUG - 2011-09-12 04:28:34 --> Model Class Initialized
DEBUG - 2011-09-12 04:28:34 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-12 04:28:34 --> Database Driver Class Initialized
DEBUG - 2011-09-12 04:29:03 --> Config Class Initialized
DEBUG - 2011-09-12 04:29:03 --> Hooks Class Initialized
DEBUG - 2011-09-12 04:29:03 --> Utf8 Class Initialized
DEBUG - 2011-09-12 04:29:03 --> UTF-8 Support Enabled
DEBUG - 2011-09-12 04:29:03 --> URI Class Initialized
DEBUG - 2011-09-12 04:29:03 --> Router Class Initialized
ERROR - 2011-09-12 04:29:03 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-09-12 04:29:03 --> Config Class Initialized
DEBUG - 2011-09-12 04:29:03 --> Hooks Class Initialized
DEBUG - 2011-09-12 04:29:03 --> Utf8 Class Initialized
DEBUG - 2011-09-12 04:29:03 --> UTF-8 Support Enabled
DEBUG - 2011-09-12 04:29:03 --> URI Class Initialized
DEBUG - 2011-09-12 04:29:03 --> Router Class Initialized
DEBUG - 2011-09-12 04:29:03 --> Output Class Initialized
DEBUG - 2011-09-12 04:29:03 --> Input Class Initialized
DEBUG - 2011-09-12 04:29:03 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-12 04:29:03 --> Language Class Initialized
DEBUG - 2011-09-12 04:29:03 --> Loader Class Initialized
DEBUG - 2011-09-12 04:29:03 --> Controller Class Initialized
ERROR - 2011-09-12 04:29:03 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-12 04:29:03 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-12 04:29:03 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-12 04:29:03 --> Model Class Initialized
DEBUG - 2011-09-12 04:29:03 --> Model Class Initialized
DEBUG - 2011-09-12 04:29:03 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-12 04:29:03 --> Database Driver Class Initialized
DEBUG - 2011-09-12 04:29:03 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-12 04:29:03 --> Helper loaded: url_helper
DEBUG - 2011-09-12 04:29:03 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-12 04:29:03 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-12 04:29:03 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-12 04:29:03 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-12 04:29:03 --> Final output sent to browser
DEBUG - 2011-09-12 04:29:03 --> Total execution time: 0.0562
DEBUG - 2011-09-12 04:29:04 --> Config Class Initialized
DEBUG - 2011-09-12 04:29:04 --> Hooks Class Initialized
DEBUG - 2011-09-12 04:29:04 --> Utf8 Class Initialized
DEBUG - 2011-09-12 04:29:04 --> UTF-8 Support Enabled
DEBUG - 2011-09-12 04:29:04 --> URI Class Initialized
DEBUG - 2011-09-12 04:29:04 --> Router Class Initialized
DEBUG - 2011-09-12 04:29:04 --> Output Class Initialized
DEBUG - 2011-09-12 04:29:04 --> Input Class Initialized
DEBUG - 2011-09-12 04:29:04 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-12 04:29:04 --> Language Class Initialized
DEBUG - 2011-09-12 04:29:04 --> Loader Class Initialized
DEBUG - 2011-09-12 04:29:04 --> Controller Class Initialized
DEBUG - 2011-09-12 04:29:04 --> Model Class Initialized
DEBUG - 2011-09-12 04:29:04 --> Model Class Initialized
DEBUG - 2011-09-12 04:29:04 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-12 04:29:04 --> Database Driver Class Initialized
DEBUG - 2011-09-12 04:29:05 --> Final output sent to browser
DEBUG - 2011-09-12 04:29:05 --> Total execution time: 1.0903
DEBUG - 2011-09-12 05:05:42 --> Config Class Initialized
DEBUG - 2011-09-12 05:05:42 --> Hooks Class Initialized
DEBUG - 2011-09-12 05:05:42 --> Utf8 Class Initialized
DEBUG - 2011-09-12 05:05:42 --> UTF-8 Support Enabled
DEBUG - 2011-09-12 05:05:42 --> URI Class Initialized
DEBUG - 2011-09-12 05:05:42 --> Router Class Initialized
DEBUG - 2011-09-12 05:05:42 --> Output Class Initialized
DEBUG - 2011-09-12 05:05:42 --> Input Class Initialized
DEBUG - 2011-09-12 05:05:42 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-12 05:05:42 --> Language Class Initialized
DEBUG - 2011-09-12 05:05:42 --> Loader Class Initialized
DEBUG - 2011-09-12 05:05:42 --> Controller Class Initialized
DEBUG - 2011-09-12 05:05:42 --> Model Class Initialized
DEBUG - 2011-09-12 05:05:42 --> Model Class Initialized
DEBUG - 2011-09-12 05:05:42 --> Model Class Initialized
DEBUG - 2011-09-12 05:05:42 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-12 05:05:42 --> Database Driver Class Initialized
DEBUG - 2011-09-12 05:05:44 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-12 05:05:44 --> Helper loaded: url_helper
DEBUG - 2011-09-12 05:05:44 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-12 05:05:44 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-12 05:05:44 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-12 05:05:44 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-12 05:05:44 --> Final output sent to browser
DEBUG - 2011-09-12 05:05:44 --> Total execution time: 2.6988
DEBUG - 2011-09-12 05:21:29 --> Config Class Initialized
DEBUG - 2011-09-12 05:21:29 --> Hooks Class Initialized
DEBUG - 2011-09-12 05:21:29 --> Utf8 Class Initialized
DEBUG - 2011-09-12 05:21:29 --> UTF-8 Support Enabled
DEBUG - 2011-09-12 05:21:29 --> URI Class Initialized
DEBUG - 2011-09-12 05:21:29 --> Router Class Initialized
DEBUG - 2011-09-12 05:21:29 --> No URI present. Default controller set.
DEBUG - 2011-09-12 05:21:29 --> Output Class Initialized
DEBUG - 2011-09-12 05:21:29 --> Input Class Initialized
DEBUG - 2011-09-12 05:21:29 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-12 05:21:29 --> Language Class Initialized
DEBUG - 2011-09-12 05:21:30 --> Loader Class Initialized
DEBUG - 2011-09-12 05:21:30 --> Controller Class Initialized
DEBUG - 2011-09-12 05:21:30 --> File loaded: application/views/splash/main.php
DEBUG - 2011-09-12 05:21:30 --> Helper loaded: url_helper
DEBUG - 2011-09-12 05:21:30 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-12 05:21:30 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-12 05:21:30 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-12 05:21:30 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-12 05:21:30 --> Final output sent to browser
DEBUG - 2011-09-12 05:21:30 --> Total execution time: 0.1495
DEBUG - 2011-09-12 05:22:25 --> Config Class Initialized
DEBUG - 2011-09-12 05:22:25 --> Hooks Class Initialized
DEBUG - 2011-09-12 05:22:25 --> Utf8 Class Initialized
DEBUG - 2011-09-12 05:22:25 --> UTF-8 Support Enabled
DEBUG - 2011-09-12 05:22:25 --> URI Class Initialized
DEBUG - 2011-09-12 05:22:25 --> Router Class Initialized
DEBUG - 2011-09-12 05:22:25 --> Output Class Initialized
DEBUG - 2011-09-12 05:22:25 --> Input Class Initialized
DEBUG - 2011-09-12 05:22:25 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-12 05:22:25 --> Language Class Initialized
DEBUG - 2011-09-12 05:22:25 --> Loader Class Initialized
DEBUG - 2011-09-12 05:22:25 --> Controller Class Initialized
DEBUG - 2011-09-12 05:22:25 --> Model Class Initialized
DEBUG - 2011-09-12 05:22:25 --> Model Class Initialized
DEBUG - 2011-09-12 05:22:25 --> Model Class Initialized
DEBUG - 2011-09-12 05:22:25 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-12 05:22:25 --> Database Driver Class Initialized
DEBUG - 2011-09-12 05:22:25 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-12 05:22:25 --> Helper loaded: url_helper
DEBUG - 2011-09-12 05:22:25 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-12 05:22:25 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-12 05:22:25 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-12 05:22:25 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-12 05:22:25 --> Final output sent to browser
DEBUG - 2011-09-12 05:22:25 --> Total execution time: 0.1385
DEBUG - 2011-09-12 05:22:27 --> Config Class Initialized
DEBUG - 2011-09-12 05:22:27 --> Hooks Class Initialized
DEBUG - 2011-09-12 05:22:27 --> Utf8 Class Initialized
DEBUG - 2011-09-12 05:22:27 --> UTF-8 Support Enabled
DEBUG - 2011-09-12 05:22:27 --> URI Class Initialized
DEBUG - 2011-09-12 05:22:27 --> Router Class Initialized
ERROR - 2011-09-12 05:22:27 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-12 05:22:34 --> Config Class Initialized
DEBUG - 2011-09-12 05:22:34 --> Hooks Class Initialized
DEBUG - 2011-09-12 05:22:34 --> Utf8 Class Initialized
DEBUG - 2011-09-12 05:22:34 --> UTF-8 Support Enabled
DEBUG - 2011-09-12 05:22:34 --> URI Class Initialized
DEBUG - 2011-09-12 05:22:34 --> Router Class Initialized
DEBUG - 2011-09-12 05:22:34 --> Output Class Initialized
DEBUG - 2011-09-12 05:22:34 --> Input Class Initialized
DEBUG - 2011-09-12 05:22:34 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-12 05:22:34 --> Language Class Initialized
DEBUG - 2011-09-12 05:22:34 --> Loader Class Initialized
DEBUG - 2011-09-12 05:22:34 --> Controller Class Initialized
ERROR - 2011-09-12 05:22:34 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-12 05:22:34 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-12 05:22:34 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-12 05:22:34 --> Model Class Initialized
DEBUG - 2011-09-12 05:22:34 --> Model Class Initialized
DEBUG - 2011-09-12 05:22:34 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-12 05:22:34 --> Database Driver Class Initialized
DEBUG - 2011-09-12 05:22:34 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-12 05:22:34 --> Helper loaded: url_helper
DEBUG - 2011-09-12 05:22:34 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-12 05:22:34 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-12 05:22:34 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-12 05:22:34 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-12 05:22:34 --> Final output sent to browser
DEBUG - 2011-09-12 05:22:34 --> Total execution time: 0.0658
DEBUG - 2011-09-12 05:22:34 --> Config Class Initialized
DEBUG - 2011-09-12 05:22:34 --> Hooks Class Initialized
DEBUG - 2011-09-12 05:22:34 --> Utf8 Class Initialized
DEBUG - 2011-09-12 05:22:34 --> UTF-8 Support Enabled
DEBUG - 2011-09-12 05:22:34 --> URI Class Initialized
DEBUG - 2011-09-12 05:22:34 --> Router Class Initialized
DEBUG - 2011-09-12 05:22:34 --> Output Class Initialized
DEBUG - 2011-09-12 05:22:34 --> Input Class Initialized
DEBUG - 2011-09-12 05:22:34 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-12 05:22:34 --> Language Class Initialized
DEBUG - 2011-09-12 05:22:34 --> Loader Class Initialized
DEBUG - 2011-09-12 05:22:34 --> Controller Class Initialized
DEBUG - 2011-09-12 05:22:34 --> Model Class Initialized
DEBUG - 2011-09-12 05:22:34 --> Model Class Initialized
DEBUG - 2011-09-12 05:22:34 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-12 05:22:34 --> Database Driver Class Initialized
DEBUG - 2011-09-12 05:22:36 --> Final output sent to browser
DEBUG - 2011-09-12 05:22:36 --> Total execution time: 1.4609
DEBUG - 2011-09-12 05:22:49 --> Config Class Initialized
DEBUG - 2011-09-12 05:22:49 --> Hooks Class Initialized
DEBUG - 2011-09-12 05:22:49 --> Utf8 Class Initialized
DEBUG - 2011-09-12 05:22:49 --> UTF-8 Support Enabled
DEBUG - 2011-09-12 05:22:49 --> URI Class Initialized
DEBUG - 2011-09-12 05:22:49 --> Router Class Initialized
DEBUG - 2011-09-12 05:22:49 --> Output Class Initialized
DEBUG - 2011-09-12 05:22:49 --> Input Class Initialized
DEBUG - 2011-09-12 05:22:49 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-12 05:22:49 --> Language Class Initialized
DEBUG - 2011-09-12 05:22:49 --> Loader Class Initialized
DEBUG - 2011-09-12 05:22:49 --> Controller Class Initialized
ERROR - 2011-09-12 05:22:49 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-12 05:22:49 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-12 05:22:49 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-12 05:22:49 --> Model Class Initialized
DEBUG - 2011-09-12 05:22:49 --> Model Class Initialized
DEBUG - 2011-09-12 05:22:49 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-12 05:22:49 --> Database Driver Class Initialized
DEBUG - 2011-09-12 05:22:49 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-12 05:22:49 --> Helper loaded: url_helper
DEBUG - 2011-09-12 05:22:49 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-12 05:22:49 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-12 05:22:49 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-12 05:22:49 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-12 05:22:49 --> Final output sent to browser
DEBUG - 2011-09-12 05:22:49 --> Total execution time: 0.1398
DEBUG - 2011-09-12 05:22:50 --> Config Class Initialized
DEBUG - 2011-09-12 05:22:50 --> Hooks Class Initialized
DEBUG - 2011-09-12 05:22:50 --> Utf8 Class Initialized
DEBUG - 2011-09-12 05:22:50 --> UTF-8 Support Enabled
DEBUG - 2011-09-12 05:22:50 --> URI Class Initialized
DEBUG - 2011-09-12 05:22:50 --> Router Class Initialized
DEBUG - 2011-09-12 05:22:50 --> Output Class Initialized
DEBUG - 2011-09-12 05:22:50 --> Input Class Initialized
DEBUG - 2011-09-12 05:22:50 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-12 05:22:50 --> Language Class Initialized
DEBUG - 2011-09-12 05:22:50 --> Loader Class Initialized
DEBUG - 2011-09-12 05:22:50 --> Controller Class Initialized
DEBUG - 2011-09-12 05:22:50 --> Model Class Initialized
DEBUG - 2011-09-12 05:22:50 --> Model Class Initialized
DEBUG - 2011-09-12 05:22:50 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-12 05:22:50 --> Database Driver Class Initialized
DEBUG - 2011-09-12 05:22:51 --> Final output sent to browser
DEBUG - 2011-09-12 05:22:51 --> Total execution time: 1.6742
DEBUG - 2011-09-12 05:22:52 --> Config Class Initialized
DEBUG - 2011-09-12 05:22:52 --> Hooks Class Initialized
DEBUG - 2011-09-12 05:22:52 --> Utf8 Class Initialized
DEBUG - 2011-09-12 05:22:52 --> UTF-8 Support Enabled
DEBUG - 2011-09-12 05:22:52 --> URI Class Initialized
DEBUG - 2011-09-12 05:22:52 --> Router Class Initialized
ERROR - 2011-09-12 05:22:52 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-12 05:22:55 --> Config Class Initialized
DEBUG - 2011-09-12 05:22:55 --> Hooks Class Initialized
DEBUG - 2011-09-12 05:22:55 --> Utf8 Class Initialized
DEBUG - 2011-09-12 05:22:55 --> UTF-8 Support Enabled
DEBUG - 2011-09-12 05:22:55 --> URI Class Initialized
DEBUG - 2011-09-12 05:22:55 --> Router Class Initialized
DEBUG - 2011-09-12 05:22:55 --> Output Class Initialized
DEBUG - 2011-09-12 05:22:55 --> Input Class Initialized
DEBUG - 2011-09-12 05:22:55 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-12 05:22:55 --> Language Class Initialized
DEBUG - 2011-09-12 05:22:55 --> Loader Class Initialized
DEBUG - 2011-09-12 05:22:55 --> Controller Class Initialized
ERROR - 2011-09-12 05:22:55 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-12 05:22:55 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-12 05:22:55 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-12 05:22:55 --> Model Class Initialized
DEBUG - 2011-09-12 05:22:55 --> Model Class Initialized
DEBUG - 2011-09-12 05:22:55 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-12 05:22:55 --> Database Driver Class Initialized
DEBUG - 2011-09-12 05:22:55 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-12 05:22:55 --> Helper loaded: url_helper
DEBUG - 2011-09-12 05:22:55 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-12 05:22:55 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-12 05:22:55 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-12 05:22:55 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-12 05:22:55 --> Final output sent to browser
DEBUG - 2011-09-12 05:22:55 --> Total execution time: 0.0314
DEBUG - 2011-09-12 05:22:56 --> Config Class Initialized
DEBUG - 2011-09-12 05:22:56 --> Hooks Class Initialized
DEBUG - 2011-09-12 05:22:56 --> Utf8 Class Initialized
DEBUG - 2011-09-12 05:22:56 --> UTF-8 Support Enabled
DEBUG - 2011-09-12 05:22:56 --> URI Class Initialized
DEBUG - 2011-09-12 05:22:56 --> Router Class Initialized
DEBUG - 2011-09-12 05:22:56 --> Output Class Initialized
DEBUG - 2011-09-12 05:22:56 --> Input Class Initialized
DEBUG - 2011-09-12 05:22:56 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-12 05:22:56 --> Language Class Initialized
DEBUG - 2011-09-12 05:22:56 --> Loader Class Initialized
DEBUG - 2011-09-12 05:22:56 --> Controller Class Initialized
DEBUG - 2011-09-12 05:22:56 --> Model Class Initialized
DEBUG - 2011-09-12 05:22:56 --> Model Class Initialized
DEBUG - 2011-09-12 05:22:56 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-12 05:22:56 --> Database Driver Class Initialized
DEBUG - 2011-09-12 05:22:56 --> Config Class Initialized
DEBUG - 2011-09-12 05:22:56 --> Hooks Class Initialized
DEBUG - 2011-09-12 05:22:56 --> Utf8 Class Initialized
DEBUG - 2011-09-12 05:22:56 --> UTF-8 Support Enabled
DEBUG - 2011-09-12 05:22:56 --> URI Class Initialized
DEBUG - 2011-09-12 05:22:56 --> Router Class Initialized
DEBUG - 2011-09-12 05:22:56 --> Output Class Initialized
DEBUG - 2011-09-12 05:22:56 --> Input Class Initialized
DEBUG - 2011-09-12 05:22:56 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-12 05:22:56 --> Language Class Initialized
DEBUG - 2011-09-12 05:22:56 --> Loader Class Initialized
DEBUG - 2011-09-12 05:22:56 --> Controller Class Initialized
ERROR - 2011-09-12 05:22:56 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-12 05:22:56 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-12 05:22:56 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-12 05:22:56 --> Model Class Initialized
DEBUG - 2011-09-12 05:22:56 --> Model Class Initialized
DEBUG - 2011-09-12 05:22:56 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-12 05:22:56 --> Database Driver Class Initialized
DEBUG - 2011-09-12 05:22:56 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-12 05:22:56 --> Helper loaded: url_helper
DEBUG - 2011-09-12 05:22:56 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-12 05:22:56 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-12 05:22:56 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-12 05:22:56 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-12 05:22:56 --> Final output sent to browser
DEBUG - 2011-09-12 05:22:56 --> Total execution time: 0.0339
DEBUG - 2011-09-12 05:22:57 --> Final output sent to browser
DEBUG - 2011-09-12 05:22:57 --> Total execution time: 1.4442
DEBUG - 2011-09-12 05:22:58 --> Config Class Initialized
DEBUG - 2011-09-12 05:22:58 --> Hooks Class Initialized
DEBUG - 2011-09-12 05:22:58 --> Utf8 Class Initialized
DEBUG - 2011-09-12 05:22:58 --> UTF-8 Support Enabled
DEBUG - 2011-09-12 05:22:58 --> URI Class Initialized
DEBUG - 2011-09-12 05:22:58 --> Router Class Initialized
ERROR - 2011-09-12 05:22:58 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-12 05:22:59 --> Config Class Initialized
DEBUG - 2011-09-12 05:22:59 --> Hooks Class Initialized
DEBUG - 2011-09-12 05:22:59 --> Utf8 Class Initialized
DEBUG - 2011-09-12 05:22:59 --> UTF-8 Support Enabled
DEBUG - 2011-09-12 05:22:59 --> URI Class Initialized
DEBUG - 2011-09-12 05:22:59 --> Router Class Initialized
DEBUG - 2011-09-12 05:22:59 --> Output Class Initialized
DEBUG - 2011-09-12 05:22:59 --> Input Class Initialized
DEBUG - 2011-09-12 05:22:59 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-12 05:22:59 --> Language Class Initialized
DEBUG - 2011-09-12 05:22:59 --> Loader Class Initialized
DEBUG - 2011-09-12 05:22:59 --> Controller Class Initialized
ERROR - 2011-09-12 05:22:59 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-12 05:22:59 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-12 05:22:59 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-12 05:22:59 --> Model Class Initialized
DEBUG - 2011-09-12 05:22:59 --> Model Class Initialized
DEBUG - 2011-09-12 05:22:59 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-12 05:22:59 --> Database Driver Class Initialized
DEBUG - 2011-09-12 05:22:59 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-12 05:22:59 --> Helper loaded: url_helper
DEBUG - 2011-09-12 05:22:59 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-12 05:22:59 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-12 05:22:59 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-12 05:22:59 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-12 05:22:59 --> Final output sent to browser
DEBUG - 2011-09-12 05:22:59 --> Total execution time: 0.0293
DEBUG - 2011-09-12 06:12:06 --> Config Class Initialized
DEBUG - 2011-09-12 06:12:06 --> Hooks Class Initialized
DEBUG - 2011-09-12 06:12:06 --> Utf8 Class Initialized
DEBUG - 2011-09-12 06:12:06 --> UTF-8 Support Enabled
DEBUG - 2011-09-12 06:12:06 --> URI Class Initialized
DEBUG - 2011-09-12 06:12:06 --> Router Class Initialized
ERROR - 2011-09-12 06:12:06 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-09-12 06:12:06 --> Config Class Initialized
DEBUG - 2011-09-12 06:12:06 --> Hooks Class Initialized
DEBUG - 2011-09-12 06:12:06 --> Utf8 Class Initialized
DEBUG - 2011-09-12 06:12:06 --> UTF-8 Support Enabled
DEBUG - 2011-09-12 06:12:06 --> URI Class Initialized
DEBUG - 2011-09-12 06:12:06 --> Router Class Initialized
DEBUG - 2011-09-12 06:12:06 --> Output Class Initialized
DEBUG - 2011-09-12 06:12:06 --> Input Class Initialized
DEBUG - 2011-09-12 06:12:06 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-12 06:12:06 --> Language Class Initialized
DEBUG - 2011-09-12 06:12:06 --> Loader Class Initialized
DEBUG - 2011-09-12 06:12:07 --> Controller Class Initialized
DEBUG - 2011-09-12 06:12:07 --> Model Class Initialized
DEBUG - 2011-09-12 06:12:07 --> Model Class Initialized
DEBUG - 2011-09-12 06:12:07 --> Model Class Initialized
DEBUG - 2011-09-12 06:12:07 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-12 06:12:07 --> Database Driver Class Initialized
DEBUG - 2011-09-12 06:12:07 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-12 06:12:07 --> Helper loaded: url_helper
DEBUG - 2011-09-12 06:12:07 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-12 06:12:07 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-12 06:12:07 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-12 06:12:07 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-12 06:12:07 --> Final output sent to browser
DEBUG - 2011-09-12 06:12:07 --> Total execution time: 0.3843
DEBUG - 2011-09-12 06:42:37 --> Config Class Initialized
DEBUG - 2011-09-12 06:42:37 --> Config Class Initialized
DEBUG - 2011-09-12 06:42:37 --> Hooks Class Initialized
DEBUG - 2011-09-12 06:42:37 --> Hooks Class Initialized
DEBUG - 2011-09-12 06:42:37 --> Utf8 Class Initialized
DEBUG - 2011-09-12 06:42:37 --> Utf8 Class Initialized
DEBUG - 2011-09-12 06:42:37 --> UTF-8 Support Enabled
DEBUG - 2011-09-12 06:42:37 --> UTF-8 Support Enabled
DEBUG - 2011-09-12 06:42:37 --> URI Class Initialized
DEBUG - 2011-09-12 06:42:37 --> URI Class Initialized
DEBUG - 2011-09-12 06:42:37 --> Router Class Initialized
DEBUG - 2011-09-12 06:42:37 --> Router Class Initialized
DEBUG - 2011-09-12 06:42:37 --> Output Class Initialized
DEBUG - 2011-09-12 06:42:37 --> Output Class Initialized
DEBUG - 2011-09-12 06:42:37 --> Input Class Initialized
DEBUG - 2011-09-12 06:42:37 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-12 06:42:37 --> Input Class Initialized
DEBUG - 2011-09-12 06:42:37 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-12 06:42:37 --> Language Class Initialized
DEBUG - 2011-09-12 06:42:37 --> Language Class Initialized
DEBUG - 2011-09-12 06:42:37 --> Loader Class Initialized
DEBUG - 2011-09-12 06:42:37 --> Loader Class Initialized
DEBUG - 2011-09-12 06:42:37 --> Controller Class Initialized
DEBUG - 2011-09-12 06:42:37 --> Controller Class Initialized
DEBUG - 2011-09-12 06:42:37 --> Model Class Initialized
ERROR - 2011-09-12 06:42:37 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-12 06:42:37 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-12 06:42:37 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-12 06:42:37 --> Model Class Initialized
DEBUG - 2011-09-12 06:42:37 --> Model Class Initialized
DEBUG - 2011-09-12 06:42:37 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-12 06:42:37 --> Model Class Initialized
DEBUG - 2011-09-12 06:42:37 --> Model Class Initialized
DEBUG - 2011-09-12 06:42:37 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-12 06:42:37 --> Database Driver Class Initialized
DEBUG - 2011-09-12 06:42:37 --> Database Driver Class Initialized
DEBUG - 2011-09-12 06:42:37 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-12 06:42:37 --> Helper loaded: url_helper
DEBUG - 2011-09-12 06:42:37 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-12 06:42:37 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-12 06:42:37 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-12 06:42:37 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-12 06:42:37 --> Final output sent to browser
DEBUG - 2011-09-12 06:42:37 --> Total execution time: 0.2942
DEBUG - 2011-09-12 06:42:38 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-12 06:42:38 --> Helper loaded: url_helper
DEBUG - 2011-09-12 06:42:38 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-12 06:42:38 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-12 06:42:38 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-12 06:42:38 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-12 06:42:38 --> Final output sent to browser
DEBUG - 2011-09-12 06:42:38 --> Total execution time: 0.6697
DEBUG - 2011-09-12 06:42:39 --> Config Class Initialized
DEBUG - 2011-09-12 06:42:39 --> Hooks Class Initialized
DEBUG - 2011-09-12 06:42:39 --> Utf8 Class Initialized
DEBUG - 2011-09-12 06:42:39 --> UTF-8 Support Enabled
DEBUG - 2011-09-12 06:42:39 --> URI Class Initialized
DEBUG - 2011-09-12 06:42:39 --> Router Class Initialized
DEBUG - 2011-09-12 06:42:39 --> Output Class Initialized
DEBUG - 2011-09-12 06:42:39 --> Input Class Initialized
DEBUG - 2011-09-12 06:42:39 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-12 06:42:39 --> Language Class Initialized
DEBUG - 2011-09-12 06:42:39 --> Loader Class Initialized
DEBUG - 2011-09-12 06:42:39 --> Controller Class Initialized
DEBUG - 2011-09-12 06:42:39 --> Model Class Initialized
DEBUG - 2011-09-12 06:42:39 --> Model Class Initialized
DEBUG - 2011-09-12 06:42:39 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-12 06:42:39 --> Database Driver Class Initialized
DEBUG - 2011-09-12 06:42:40 --> Final output sent to browser
DEBUG - 2011-09-12 06:42:40 --> Total execution time: 1.6557
DEBUG - 2011-09-12 06:42:42 --> Config Class Initialized
DEBUG - 2011-09-12 06:42:42 --> Hooks Class Initialized
DEBUG - 2011-09-12 06:42:42 --> Utf8 Class Initialized
DEBUG - 2011-09-12 06:42:42 --> UTF-8 Support Enabled
DEBUG - 2011-09-12 06:42:42 --> URI Class Initialized
DEBUG - 2011-09-12 06:42:42 --> Router Class Initialized
ERROR - 2011-09-12 06:42:42 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-12 06:42:43 --> Config Class Initialized
DEBUG - 2011-09-12 06:42:43 --> Hooks Class Initialized
DEBUG - 2011-09-12 06:42:43 --> Utf8 Class Initialized
DEBUG - 2011-09-12 06:42:43 --> UTF-8 Support Enabled
DEBUG - 2011-09-12 06:42:43 --> URI Class Initialized
DEBUG - 2011-09-12 06:42:43 --> Router Class Initialized
ERROR - 2011-09-12 06:42:43 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-12 06:42:43 --> Config Class Initialized
DEBUG - 2011-09-12 06:42:43 --> Hooks Class Initialized
DEBUG - 2011-09-12 06:42:43 --> Utf8 Class Initialized
DEBUG - 2011-09-12 06:42:43 --> UTF-8 Support Enabled
DEBUG - 2011-09-12 06:42:43 --> URI Class Initialized
DEBUG - 2011-09-12 06:42:43 --> Router Class Initialized
ERROR - 2011-09-12 06:42:43 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-12 06:54:32 --> Config Class Initialized
DEBUG - 2011-09-12 06:54:32 --> Hooks Class Initialized
DEBUG - 2011-09-12 06:54:32 --> Utf8 Class Initialized
DEBUG - 2011-09-12 06:54:32 --> UTF-8 Support Enabled
DEBUG - 2011-09-12 06:54:32 --> URI Class Initialized
DEBUG - 2011-09-12 06:54:32 --> Router Class Initialized
DEBUG - 2011-09-12 06:54:32 --> Output Class Initialized
DEBUG - 2011-09-12 06:54:32 --> Input Class Initialized
DEBUG - 2011-09-12 06:54:32 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-12 06:54:32 --> Language Class Initialized
DEBUG - 2011-09-12 06:54:32 --> Loader Class Initialized
DEBUG - 2011-09-12 06:54:32 --> Controller Class Initialized
ERROR - 2011-09-12 06:54:32 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-12 06:54:32 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-12 06:54:32 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-12 06:54:32 --> Model Class Initialized
DEBUG - 2011-09-12 06:54:32 --> Model Class Initialized
DEBUG - 2011-09-12 06:54:32 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-12 06:54:32 --> Database Driver Class Initialized
DEBUG - 2011-09-12 06:54:32 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-12 06:54:32 --> Helper loaded: url_helper
DEBUG - 2011-09-12 06:54:32 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-12 06:54:32 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-12 06:54:32 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-12 06:54:32 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-12 06:54:32 --> Final output sent to browser
DEBUG - 2011-09-12 06:54:32 --> Total execution time: 0.0507
DEBUG - 2011-09-12 06:54:33 --> Config Class Initialized
DEBUG - 2011-09-12 06:54:33 --> Hooks Class Initialized
DEBUG - 2011-09-12 06:54:33 --> Utf8 Class Initialized
DEBUG - 2011-09-12 06:54:33 --> UTF-8 Support Enabled
DEBUG - 2011-09-12 06:54:33 --> URI Class Initialized
DEBUG - 2011-09-12 06:54:33 --> Router Class Initialized
DEBUG - 2011-09-12 06:54:33 --> Output Class Initialized
DEBUG - 2011-09-12 06:54:33 --> Input Class Initialized
DEBUG - 2011-09-12 06:54:33 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-12 06:54:33 --> Language Class Initialized
DEBUG - 2011-09-12 06:54:33 --> Loader Class Initialized
DEBUG - 2011-09-12 06:54:33 --> Controller Class Initialized
DEBUG - 2011-09-12 06:54:33 --> Model Class Initialized
DEBUG - 2011-09-12 06:54:33 --> Model Class Initialized
DEBUG - 2011-09-12 06:54:33 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-12 06:54:33 --> Database Driver Class Initialized
DEBUG - 2011-09-12 06:54:33 --> Config Class Initialized
DEBUG - 2011-09-12 06:54:33 --> Hooks Class Initialized
DEBUG - 2011-09-12 06:54:33 --> Utf8 Class Initialized
DEBUG - 2011-09-12 06:54:33 --> UTF-8 Support Enabled
DEBUG - 2011-09-12 06:54:33 --> URI Class Initialized
DEBUG - 2011-09-12 06:54:33 --> Router Class Initialized
DEBUG - 2011-09-12 06:54:33 --> Output Class Initialized
DEBUG - 2011-09-12 06:54:33 --> Input Class Initialized
DEBUG - 2011-09-12 06:54:33 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-12 06:54:33 --> Language Class Initialized
DEBUG - 2011-09-12 06:54:33 --> Loader Class Initialized
DEBUG - 2011-09-12 06:54:33 --> Controller Class Initialized
ERROR - 2011-09-12 06:54:33 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-12 06:54:33 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-12 06:54:33 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-12 06:54:33 --> Model Class Initialized
DEBUG - 2011-09-12 06:54:33 --> Model Class Initialized
DEBUG - 2011-09-12 06:54:33 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-12 06:54:33 --> Database Driver Class Initialized
DEBUG - 2011-09-12 06:54:33 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-12 06:54:33 --> Helper loaded: url_helper
DEBUG - 2011-09-12 06:54:33 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-12 06:54:33 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-12 06:54:33 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-12 06:54:33 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-12 06:54:33 --> Final output sent to browser
DEBUG - 2011-09-12 06:54:33 --> Total execution time: 0.0311
DEBUG - 2011-09-12 06:54:35 --> Final output sent to browser
DEBUG - 2011-09-12 06:54:35 --> Total execution time: 1.7718
DEBUG - 2011-09-12 06:56:31 --> Config Class Initialized
DEBUG - 2011-09-12 06:56:31 --> Hooks Class Initialized
DEBUG - 2011-09-12 06:56:31 --> Utf8 Class Initialized
DEBUG - 2011-09-12 06:56:31 --> UTF-8 Support Enabled
DEBUG - 2011-09-12 06:56:31 --> URI Class Initialized
DEBUG - 2011-09-12 06:56:31 --> Router Class Initialized
DEBUG - 2011-09-12 06:56:31 --> No URI present. Default controller set.
DEBUG - 2011-09-12 06:56:31 --> Output Class Initialized
DEBUG - 2011-09-12 06:56:31 --> Input Class Initialized
DEBUG - 2011-09-12 06:56:31 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-12 06:56:31 --> Language Class Initialized
DEBUG - 2011-09-12 06:56:31 --> Loader Class Initialized
DEBUG - 2011-09-12 06:56:31 --> Controller Class Initialized
DEBUG - 2011-09-12 06:56:31 --> File loaded: application/views/splash/main.php
DEBUG - 2011-09-12 06:56:31 --> Helper loaded: url_helper
DEBUG - 2011-09-12 06:56:31 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-12 06:56:31 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-12 06:56:31 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-12 06:56:31 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-12 06:56:31 --> Final output sent to browser
DEBUG - 2011-09-12 06:56:31 --> Total execution time: 0.0688
DEBUG - 2011-09-12 08:42:22 --> Config Class Initialized
DEBUG - 2011-09-12 08:42:22 --> Hooks Class Initialized
DEBUG - 2011-09-12 08:42:22 --> Utf8 Class Initialized
DEBUG - 2011-09-12 08:42:22 --> UTF-8 Support Enabled
DEBUG - 2011-09-12 08:42:22 --> URI Class Initialized
DEBUG - 2011-09-12 08:42:22 --> Router Class Initialized
DEBUG - 2011-09-12 08:42:23 --> Output Class Initialized
DEBUG - 2011-09-12 08:42:23 --> Input Class Initialized
DEBUG - 2011-09-12 08:42:23 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-12 08:42:23 --> Language Class Initialized
DEBUG - 2011-09-12 08:42:23 --> Loader Class Initialized
DEBUG - 2011-09-12 08:42:23 --> Controller Class Initialized
ERROR - 2011-09-12 08:42:23 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-12 08:42:23 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-12 08:42:23 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-12 08:42:23 --> Model Class Initialized
DEBUG - 2011-09-12 08:42:23 --> Model Class Initialized
DEBUG - 2011-09-12 08:42:23 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-12 08:42:23 --> Database Driver Class Initialized
DEBUG - 2011-09-12 08:42:23 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-12 08:42:23 --> Helper loaded: url_helper
DEBUG - 2011-09-12 08:42:23 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-12 08:42:23 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-12 08:42:23 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-12 08:42:23 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-12 08:42:23 --> Final output sent to browser
DEBUG - 2011-09-12 08:42:23 --> Total execution time: 0.6243
DEBUG - 2011-09-12 08:42:29 --> Config Class Initialized
DEBUG - 2011-09-12 08:42:29 --> Hooks Class Initialized
DEBUG - 2011-09-12 08:42:29 --> Utf8 Class Initialized
DEBUG - 2011-09-12 08:42:29 --> UTF-8 Support Enabled
DEBUG - 2011-09-12 08:42:29 --> URI Class Initialized
DEBUG - 2011-09-12 08:42:29 --> Router Class Initialized
DEBUG - 2011-09-12 08:42:29 --> Output Class Initialized
DEBUG - 2011-09-12 08:42:29 --> Input Class Initialized
DEBUG - 2011-09-12 08:42:29 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-12 08:42:29 --> Language Class Initialized
DEBUG - 2011-09-12 08:42:29 --> Loader Class Initialized
DEBUG - 2011-09-12 08:42:29 --> Controller Class Initialized
DEBUG - 2011-09-12 08:42:29 --> Model Class Initialized
DEBUG - 2011-09-12 08:42:29 --> Model Class Initialized
DEBUG - 2011-09-12 08:42:29 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-12 08:42:29 --> Database Driver Class Initialized
DEBUG - 2011-09-12 08:42:31 --> Final output sent to browser
DEBUG - 2011-09-12 08:42:31 --> Total execution time: 2.4359
DEBUG - 2011-09-12 08:42:34 --> Config Class Initialized
DEBUG - 2011-09-12 08:42:34 --> Hooks Class Initialized
DEBUG - 2011-09-12 08:42:34 --> Utf8 Class Initialized
DEBUG - 2011-09-12 08:42:34 --> UTF-8 Support Enabled
DEBUG - 2011-09-12 08:42:34 --> URI Class Initialized
DEBUG - 2011-09-12 08:42:34 --> Router Class Initialized
ERROR - 2011-09-12 08:42:34 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-12 08:53:45 --> Config Class Initialized
DEBUG - 2011-09-12 08:53:45 --> Hooks Class Initialized
DEBUG - 2011-09-12 08:53:45 --> Utf8 Class Initialized
DEBUG - 2011-09-12 08:53:45 --> UTF-8 Support Enabled
DEBUG - 2011-09-12 08:53:45 --> URI Class Initialized
DEBUG - 2011-09-12 08:53:45 --> Router Class Initialized
ERROR - 2011-09-12 08:53:45 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-09-12 09:05:46 --> Config Class Initialized
DEBUG - 2011-09-12 09:05:46 --> Hooks Class Initialized
DEBUG - 2011-09-12 09:05:46 --> Utf8 Class Initialized
DEBUG - 2011-09-12 09:05:46 --> UTF-8 Support Enabled
DEBUG - 2011-09-12 09:05:46 --> URI Class Initialized
DEBUG - 2011-09-12 09:05:46 --> Router Class Initialized
DEBUG - 2011-09-12 09:05:46 --> Output Class Initialized
DEBUG - 2011-09-12 09:05:46 --> Input Class Initialized
DEBUG - 2011-09-12 09:05:46 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-12 09:05:46 --> Language Class Initialized
DEBUG - 2011-09-12 09:05:46 --> Loader Class Initialized
DEBUG - 2011-09-12 09:05:46 --> Controller Class Initialized
DEBUG - 2011-09-12 09:05:46 --> Model Class Initialized
DEBUG - 2011-09-12 09:05:46 --> Model Class Initialized
DEBUG - 2011-09-12 09:05:46 --> Model Class Initialized
DEBUG - 2011-09-12 09:05:46 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-12 09:05:46 --> Database Driver Class Initialized
DEBUG - 2011-09-12 09:05:47 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-12 09:05:47 --> Helper loaded: url_helper
DEBUG - 2011-09-12 09:05:47 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-12 09:05:47 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-12 09:05:47 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-12 09:05:47 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-12 09:05:47 --> Final output sent to browser
DEBUG - 2011-09-12 09:05:47 --> Total execution time: 1.3395
DEBUG - 2011-09-12 09:05:51 --> Config Class Initialized
DEBUG - 2011-09-12 09:05:51 --> Hooks Class Initialized
DEBUG - 2011-09-12 09:05:51 --> Utf8 Class Initialized
DEBUG - 2011-09-12 09:05:51 --> UTF-8 Support Enabled
DEBUG - 2011-09-12 09:05:51 --> URI Class Initialized
DEBUG - 2011-09-12 09:05:51 --> Router Class Initialized
ERROR - 2011-09-12 09:05:51 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-12 09:05:52 --> Config Class Initialized
DEBUG - 2011-09-12 09:05:52 --> Hooks Class Initialized
DEBUG - 2011-09-12 09:05:52 --> Utf8 Class Initialized
DEBUG - 2011-09-12 09:05:52 --> UTF-8 Support Enabled
DEBUG - 2011-09-12 09:05:52 --> URI Class Initialized
DEBUG - 2011-09-12 09:05:52 --> Router Class Initialized
ERROR - 2011-09-12 09:05:52 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-12 09:44:47 --> Config Class Initialized
DEBUG - 2011-09-12 09:44:47 --> Hooks Class Initialized
DEBUG - 2011-09-12 09:44:47 --> Utf8 Class Initialized
DEBUG - 2011-09-12 09:44:47 --> UTF-8 Support Enabled
DEBUG - 2011-09-12 09:44:47 --> URI Class Initialized
DEBUG - 2011-09-12 09:44:47 --> Router Class Initialized
DEBUG - 2011-09-12 09:44:47 --> Output Class Initialized
DEBUG - 2011-09-12 09:44:47 --> Input Class Initialized
DEBUG - 2011-09-12 09:44:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-12 09:44:47 --> Language Class Initialized
DEBUG - 2011-09-12 09:44:47 --> Loader Class Initialized
DEBUG - 2011-09-12 09:44:47 --> Controller Class Initialized
ERROR - 2011-09-12 09:44:47 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-12 09:44:47 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-12 09:44:47 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-12 09:44:47 --> Model Class Initialized
DEBUG - 2011-09-12 09:44:47 --> Model Class Initialized
DEBUG - 2011-09-12 09:44:47 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-12 09:44:47 --> Database Driver Class Initialized
DEBUG - 2011-09-12 09:44:47 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-12 09:44:47 --> Helper loaded: url_helper
DEBUG - 2011-09-12 09:44:47 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-12 09:44:47 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-12 09:44:47 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-12 09:44:47 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-12 09:44:47 --> Final output sent to browser
DEBUG - 2011-09-12 09:44:47 --> Total execution time: 0.1131
DEBUG - 2011-09-12 09:44:50 --> Config Class Initialized
DEBUG - 2011-09-12 09:44:50 --> Hooks Class Initialized
DEBUG - 2011-09-12 09:44:50 --> Utf8 Class Initialized
DEBUG - 2011-09-12 09:44:50 --> UTF-8 Support Enabled
DEBUG - 2011-09-12 09:44:50 --> URI Class Initialized
DEBUG - 2011-09-12 09:44:50 --> Router Class Initialized
DEBUG - 2011-09-12 09:44:50 --> Output Class Initialized
DEBUG - 2011-09-12 09:44:50 --> Input Class Initialized
DEBUG - 2011-09-12 09:44:50 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-12 09:44:50 --> Language Class Initialized
DEBUG - 2011-09-12 09:44:50 --> Loader Class Initialized
DEBUG - 2011-09-12 09:44:50 --> Controller Class Initialized
DEBUG - 2011-09-12 09:44:50 --> Model Class Initialized
DEBUG - 2011-09-12 09:44:50 --> Model Class Initialized
DEBUG - 2011-09-12 09:44:50 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-12 09:44:50 --> Database Driver Class Initialized
DEBUG - 2011-09-12 09:44:52 --> Final output sent to browser
DEBUG - 2011-09-12 09:44:52 --> Total execution time: 2.0433
DEBUG - 2011-09-12 09:44:57 --> Config Class Initialized
DEBUG - 2011-09-12 09:44:57 --> Hooks Class Initialized
DEBUG - 2011-09-12 09:44:57 --> Utf8 Class Initialized
DEBUG - 2011-09-12 09:44:57 --> UTF-8 Support Enabled
DEBUG - 2011-09-12 09:44:57 --> URI Class Initialized
DEBUG - 2011-09-12 09:44:57 --> Router Class Initialized
ERROR - 2011-09-12 09:44:57 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-12 09:46:04 --> Config Class Initialized
DEBUG - 2011-09-12 09:46:04 --> Hooks Class Initialized
DEBUG - 2011-09-12 09:46:04 --> Utf8 Class Initialized
DEBUG - 2011-09-12 09:46:04 --> UTF-8 Support Enabled
DEBUG - 2011-09-12 09:46:04 --> URI Class Initialized
DEBUG - 2011-09-12 09:46:04 --> Router Class Initialized
DEBUG - 2011-09-12 09:46:04 --> Output Class Initialized
DEBUG - 2011-09-12 09:46:04 --> Input Class Initialized
DEBUG - 2011-09-12 09:46:04 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-12 09:46:04 --> Language Class Initialized
DEBUG - 2011-09-12 09:46:04 --> Loader Class Initialized
DEBUG - 2011-09-12 09:46:04 --> Controller Class Initialized
ERROR - 2011-09-12 09:46:04 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-12 09:46:04 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-12 09:46:04 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-12 09:46:04 --> Model Class Initialized
DEBUG - 2011-09-12 09:46:04 --> Model Class Initialized
DEBUG - 2011-09-12 09:46:04 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-12 09:46:04 --> Database Driver Class Initialized
DEBUG - 2011-09-12 09:46:04 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-12 09:46:04 --> Helper loaded: url_helper
DEBUG - 2011-09-12 09:46:04 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-12 09:46:04 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-12 09:46:04 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-12 09:46:04 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-12 09:46:04 --> Final output sent to browser
DEBUG - 2011-09-12 09:46:04 --> Total execution time: 0.0290
DEBUG - 2011-09-12 09:46:06 --> Config Class Initialized
DEBUG - 2011-09-12 09:46:06 --> Hooks Class Initialized
DEBUG - 2011-09-12 09:46:06 --> Utf8 Class Initialized
DEBUG - 2011-09-12 09:46:06 --> UTF-8 Support Enabled
DEBUG - 2011-09-12 09:46:06 --> URI Class Initialized
DEBUG - 2011-09-12 09:46:06 --> Router Class Initialized
DEBUG - 2011-09-12 09:46:06 --> Output Class Initialized
DEBUG - 2011-09-12 09:46:06 --> Input Class Initialized
DEBUG - 2011-09-12 09:46:06 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-12 09:46:06 --> Language Class Initialized
DEBUG - 2011-09-12 09:46:06 --> Loader Class Initialized
DEBUG - 2011-09-12 09:46:06 --> Controller Class Initialized
DEBUG - 2011-09-12 09:46:06 --> Model Class Initialized
DEBUG - 2011-09-12 09:46:06 --> Model Class Initialized
DEBUG - 2011-09-12 09:46:06 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-12 09:46:06 --> Database Driver Class Initialized
DEBUG - 2011-09-12 09:46:07 --> Final output sent to browser
DEBUG - 2011-09-12 09:46:07 --> Total execution time: 1.6701
DEBUG - 2011-09-12 09:46:11 --> Config Class Initialized
DEBUG - 2011-09-12 09:46:11 --> Hooks Class Initialized
DEBUG - 2011-09-12 09:46:11 --> Utf8 Class Initialized
DEBUG - 2011-09-12 09:46:11 --> UTF-8 Support Enabled
DEBUG - 2011-09-12 09:46:11 --> URI Class Initialized
DEBUG - 2011-09-12 09:46:11 --> Router Class Initialized
ERROR - 2011-09-12 09:46:11 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-12 09:46:37 --> Config Class Initialized
DEBUG - 2011-09-12 09:46:37 --> Hooks Class Initialized
DEBUG - 2011-09-12 09:46:37 --> Utf8 Class Initialized
DEBUG - 2011-09-12 09:46:37 --> UTF-8 Support Enabled
DEBUG - 2011-09-12 09:46:37 --> URI Class Initialized
DEBUG - 2011-09-12 09:46:37 --> Router Class Initialized
DEBUG - 2011-09-12 09:46:37 --> Output Class Initialized
DEBUG - 2011-09-12 09:46:37 --> Input Class Initialized
DEBUG - 2011-09-12 09:46:37 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-12 09:46:37 --> Language Class Initialized
DEBUG - 2011-09-12 09:46:37 --> Loader Class Initialized
DEBUG - 2011-09-12 09:46:37 --> Controller Class Initialized
DEBUG - 2011-09-12 09:46:37 --> Model Class Initialized
DEBUG - 2011-09-12 09:46:37 --> Model Class Initialized
DEBUG - 2011-09-12 09:46:37 --> Model Class Initialized
DEBUG - 2011-09-12 09:46:37 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-12 09:46:37 --> Database Driver Class Initialized
DEBUG - 2011-09-12 09:46:38 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-12 09:46:38 --> Helper loaded: url_helper
DEBUG - 2011-09-12 09:46:38 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-12 09:46:38 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-12 09:46:38 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-12 09:46:38 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-12 09:46:38 --> Final output sent to browser
DEBUG - 2011-09-12 09:46:38 --> Total execution time: 0.9470
DEBUG - 2011-09-12 09:46:42 --> Config Class Initialized
DEBUG - 2011-09-12 09:46:42 --> Hooks Class Initialized
DEBUG - 2011-09-12 09:46:42 --> Utf8 Class Initialized
DEBUG - 2011-09-12 09:46:42 --> UTF-8 Support Enabled
DEBUG - 2011-09-12 09:46:42 --> URI Class Initialized
DEBUG - 2011-09-12 09:46:42 --> Router Class Initialized
ERROR - 2011-09-12 09:46:42 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-12 10:23:08 --> Config Class Initialized
DEBUG - 2011-09-12 10:23:08 --> Hooks Class Initialized
DEBUG - 2011-09-12 10:23:08 --> Utf8 Class Initialized
DEBUG - 2011-09-12 10:23:08 --> UTF-8 Support Enabled
DEBUG - 2011-09-12 10:23:08 --> URI Class Initialized
DEBUG - 2011-09-12 10:23:08 --> Router Class Initialized
DEBUG - 2011-09-12 10:23:08 --> Output Class Initialized
DEBUG - 2011-09-12 10:23:08 --> Input Class Initialized
DEBUG - 2011-09-12 10:23:08 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-12 10:23:08 --> Language Class Initialized
DEBUG - 2011-09-12 10:23:08 --> Loader Class Initialized
DEBUG - 2011-09-12 10:23:08 --> Controller Class Initialized
ERROR - 2011-09-12 10:23:08 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-12 10:23:08 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-12 10:23:08 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-12 10:23:08 --> Model Class Initialized
DEBUG - 2011-09-12 10:23:08 --> Model Class Initialized
DEBUG - 2011-09-12 10:23:08 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-12 10:23:08 --> Database Driver Class Initialized
DEBUG - 2011-09-12 10:23:08 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-12 10:23:08 --> Helper loaded: url_helper
DEBUG - 2011-09-12 10:23:08 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-12 10:23:08 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-12 10:23:08 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-12 10:23:08 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-12 10:23:08 --> Final output sent to browser
DEBUG - 2011-09-12 10:23:08 --> Total execution time: 0.0784
DEBUG - 2011-09-12 10:23:09 --> Config Class Initialized
DEBUG - 2011-09-12 10:23:09 --> Hooks Class Initialized
DEBUG - 2011-09-12 10:23:09 --> Utf8 Class Initialized
DEBUG - 2011-09-12 10:23:09 --> UTF-8 Support Enabled
DEBUG - 2011-09-12 10:23:09 --> URI Class Initialized
DEBUG - 2011-09-12 10:23:09 --> Router Class Initialized
DEBUG - 2011-09-12 10:23:09 --> Output Class Initialized
DEBUG - 2011-09-12 10:23:09 --> Input Class Initialized
DEBUG - 2011-09-12 10:23:09 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-12 10:23:09 --> Language Class Initialized
DEBUG - 2011-09-12 10:23:09 --> Loader Class Initialized
DEBUG - 2011-09-12 10:23:09 --> Controller Class Initialized
DEBUG - 2011-09-12 10:23:09 --> Model Class Initialized
DEBUG - 2011-09-12 10:23:09 --> Model Class Initialized
DEBUG - 2011-09-12 10:23:09 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-12 10:23:09 --> Database Driver Class Initialized
DEBUG - 2011-09-12 10:23:10 --> Final output sent to browser
DEBUG - 2011-09-12 10:23:10 --> Total execution time: 1.4588
DEBUG - 2011-09-12 10:23:11 --> Config Class Initialized
DEBUG - 2011-09-12 10:23:11 --> Hooks Class Initialized
DEBUG - 2011-09-12 10:23:11 --> Utf8 Class Initialized
DEBUG - 2011-09-12 10:23:11 --> UTF-8 Support Enabled
DEBUG - 2011-09-12 10:23:11 --> URI Class Initialized
DEBUG - 2011-09-12 10:23:11 --> Router Class Initialized
ERROR - 2011-09-12 10:23:11 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-12 10:23:11 --> Config Class Initialized
DEBUG - 2011-09-12 10:23:11 --> Hooks Class Initialized
DEBUG - 2011-09-12 10:23:11 --> Utf8 Class Initialized
DEBUG - 2011-09-12 10:23:11 --> UTF-8 Support Enabled
DEBUG - 2011-09-12 10:23:11 --> URI Class Initialized
DEBUG - 2011-09-12 10:23:11 --> Router Class Initialized
ERROR - 2011-09-12 10:23:11 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-12 10:23:19 --> Config Class Initialized
DEBUG - 2011-09-12 10:23:19 --> Hooks Class Initialized
DEBUG - 2011-09-12 10:23:19 --> Utf8 Class Initialized
DEBUG - 2011-09-12 10:23:19 --> UTF-8 Support Enabled
DEBUG - 2011-09-12 10:23:19 --> URI Class Initialized
DEBUG - 2011-09-12 10:23:19 --> Router Class Initialized
DEBUG - 2011-09-12 10:23:19 --> Output Class Initialized
DEBUG - 2011-09-12 10:23:19 --> Input Class Initialized
DEBUG - 2011-09-12 10:23:19 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-12 10:23:19 --> Language Class Initialized
DEBUG - 2011-09-12 10:23:19 --> Loader Class Initialized
DEBUG - 2011-09-12 10:23:19 --> Controller Class Initialized
ERROR - 2011-09-12 10:23:19 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-12 10:23:19 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-12 10:23:19 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-12 10:23:20 --> Model Class Initialized
DEBUG - 2011-09-12 10:23:20 --> Model Class Initialized
DEBUG - 2011-09-12 10:23:20 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-12 10:23:20 --> Database Driver Class Initialized
DEBUG - 2011-09-12 10:23:20 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-12 10:23:20 --> Helper loaded: url_helper
DEBUG - 2011-09-12 10:23:20 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-12 10:23:20 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-12 10:23:20 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-12 10:23:20 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-12 10:23:20 --> Final output sent to browser
DEBUG - 2011-09-12 10:23:20 --> Total execution time: 0.0606
DEBUG - 2011-09-12 10:23:21 --> Config Class Initialized
DEBUG - 2011-09-12 10:23:21 --> Hooks Class Initialized
DEBUG - 2011-09-12 10:23:21 --> Utf8 Class Initialized
DEBUG - 2011-09-12 10:23:21 --> UTF-8 Support Enabled
DEBUG - 2011-09-12 10:23:21 --> URI Class Initialized
DEBUG - 2011-09-12 10:23:21 --> Router Class Initialized
DEBUG - 2011-09-12 10:23:21 --> Output Class Initialized
DEBUG - 2011-09-12 10:23:21 --> Input Class Initialized
DEBUG - 2011-09-12 10:23:21 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-12 10:23:21 --> Language Class Initialized
DEBUG - 2011-09-12 10:23:21 --> Loader Class Initialized
DEBUG - 2011-09-12 10:23:21 --> Controller Class Initialized
DEBUG - 2011-09-12 10:23:21 --> Model Class Initialized
DEBUG - 2011-09-12 10:23:21 --> Model Class Initialized
DEBUG - 2011-09-12 10:23:21 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-12 10:23:21 --> Database Driver Class Initialized
DEBUG - 2011-09-12 10:23:22 --> Final output sent to browser
DEBUG - 2011-09-12 10:23:22 --> Total execution time: 1.3330
DEBUG - 2011-09-12 10:28:24 --> Config Class Initialized
DEBUG - 2011-09-12 10:28:24 --> Hooks Class Initialized
DEBUG - 2011-09-12 10:28:24 --> Utf8 Class Initialized
DEBUG - 2011-09-12 10:28:24 --> UTF-8 Support Enabled
DEBUG - 2011-09-12 10:28:24 --> URI Class Initialized
DEBUG - 2011-09-12 10:28:24 --> Router Class Initialized
DEBUG - 2011-09-12 10:28:24 --> Output Class Initialized
DEBUG - 2011-09-12 10:28:24 --> Input Class Initialized
DEBUG - 2011-09-12 10:28:24 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-12 10:28:24 --> Language Class Initialized
DEBUG - 2011-09-12 10:28:24 --> Loader Class Initialized
DEBUG - 2011-09-12 10:28:24 --> Controller Class Initialized
ERROR - 2011-09-12 10:28:24 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-12 10:28:24 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-12 10:28:24 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-12 10:28:24 --> Model Class Initialized
DEBUG - 2011-09-12 10:28:24 --> Model Class Initialized
DEBUG - 2011-09-12 10:28:24 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-12 10:28:24 --> Database Driver Class Initialized
DEBUG - 2011-09-12 10:28:24 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-12 10:28:24 --> Helper loaded: url_helper
DEBUG - 2011-09-12 10:28:24 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-12 10:28:24 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-12 10:28:24 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-12 10:28:24 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-12 10:28:24 --> Final output sent to browser
DEBUG - 2011-09-12 10:28:24 --> Total execution time: 0.0601
DEBUG - 2011-09-12 10:28:26 --> Config Class Initialized
DEBUG - 2011-09-12 10:28:26 --> Hooks Class Initialized
DEBUG - 2011-09-12 10:28:26 --> Utf8 Class Initialized
DEBUG - 2011-09-12 10:28:26 --> UTF-8 Support Enabled
DEBUG - 2011-09-12 10:28:26 --> URI Class Initialized
DEBUG - 2011-09-12 10:28:26 --> Router Class Initialized
DEBUG - 2011-09-12 10:28:26 --> Output Class Initialized
DEBUG - 2011-09-12 10:28:26 --> Input Class Initialized
DEBUG - 2011-09-12 10:28:26 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-12 10:28:26 --> Language Class Initialized
DEBUG - 2011-09-12 10:28:26 --> Loader Class Initialized
DEBUG - 2011-09-12 10:28:26 --> Controller Class Initialized
DEBUG - 2011-09-12 10:28:26 --> Model Class Initialized
DEBUG - 2011-09-12 10:28:26 --> Model Class Initialized
DEBUG - 2011-09-12 10:28:26 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-12 10:28:26 --> Database Driver Class Initialized
DEBUG - 2011-09-12 10:28:27 --> Final output sent to browser
DEBUG - 2011-09-12 10:28:27 --> Total execution time: 1.4768
DEBUG - 2011-09-12 10:28:28 --> Config Class Initialized
DEBUG - 2011-09-12 10:28:28 --> Hooks Class Initialized
DEBUG - 2011-09-12 10:28:28 --> Utf8 Class Initialized
DEBUG - 2011-09-12 10:28:28 --> UTF-8 Support Enabled
DEBUG - 2011-09-12 10:28:28 --> URI Class Initialized
DEBUG - 2011-09-12 10:28:28 --> Router Class Initialized
ERROR - 2011-09-12 10:28:28 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-12 11:31:31 --> Config Class Initialized
DEBUG - 2011-09-12 11:31:31 --> Hooks Class Initialized
DEBUG - 2011-09-12 11:31:31 --> Utf8 Class Initialized
DEBUG - 2011-09-12 11:31:31 --> UTF-8 Support Enabled
DEBUG - 2011-09-12 11:31:31 --> URI Class Initialized
DEBUG - 2011-09-12 11:31:31 --> Router Class Initialized
DEBUG - 2011-09-12 11:31:31 --> Output Class Initialized
DEBUG - 2011-09-12 11:31:31 --> Input Class Initialized
DEBUG - 2011-09-12 11:31:31 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-12 11:31:31 --> Language Class Initialized
DEBUG - 2011-09-12 11:31:31 --> Loader Class Initialized
DEBUG - 2011-09-12 11:31:31 --> Controller Class Initialized
DEBUG - 2011-09-12 11:31:31 --> Model Class Initialized
DEBUG - 2011-09-12 11:31:31 --> Model Class Initialized
DEBUG - 2011-09-12 11:31:31 --> Model Class Initialized
DEBUG - 2011-09-12 11:31:31 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-12 11:31:31 --> Database Driver Class Initialized
DEBUG - 2011-09-12 11:31:32 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-12 11:31:32 --> Helper loaded: url_helper
DEBUG - 2011-09-12 11:31:32 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-12 11:31:32 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-12 11:31:32 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-12 11:31:32 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-12 11:31:32 --> Final output sent to browser
DEBUG - 2011-09-12 11:31:32 --> Total execution time: 1.0270
DEBUG - 2011-09-12 11:31:34 --> Config Class Initialized
DEBUG - 2011-09-12 11:31:34 --> Hooks Class Initialized
DEBUG - 2011-09-12 11:31:34 --> Utf8 Class Initialized
DEBUG - 2011-09-12 11:31:34 --> UTF-8 Support Enabled
DEBUG - 2011-09-12 11:31:34 --> URI Class Initialized
DEBUG - 2011-09-12 11:31:34 --> Router Class Initialized
ERROR - 2011-09-12 11:31:34 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-12 11:31:34 --> Config Class Initialized
DEBUG - 2011-09-12 11:31:34 --> Hooks Class Initialized
DEBUG - 2011-09-12 11:31:34 --> Utf8 Class Initialized
DEBUG - 2011-09-12 11:31:34 --> UTF-8 Support Enabled
DEBUG - 2011-09-12 11:31:34 --> URI Class Initialized
DEBUG - 2011-09-12 11:31:34 --> Router Class Initialized
ERROR - 2011-09-12 11:31:34 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-12 11:40:44 --> Config Class Initialized
DEBUG - 2011-09-12 11:40:44 --> Hooks Class Initialized
DEBUG - 2011-09-12 11:40:44 --> Utf8 Class Initialized
DEBUG - 2011-09-12 11:40:44 --> UTF-8 Support Enabled
DEBUG - 2011-09-12 11:40:44 --> URI Class Initialized
DEBUG - 2011-09-12 11:40:44 --> Router Class Initialized
DEBUG - 2011-09-12 11:40:44 --> Output Class Initialized
DEBUG - 2011-09-12 11:40:44 --> Input Class Initialized
DEBUG - 2011-09-12 11:40:44 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-12 11:40:44 --> Language Class Initialized
DEBUG - 2011-09-12 11:40:44 --> Loader Class Initialized
DEBUG - 2011-09-12 11:40:44 --> Controller Class Initialized
ERROR - 2011-09-12 11:40:44 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-12 11:40:44 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-12 11:40:44 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-12 11:40:44 --> Model Class Initialized
DEBUG - 2011-09-12 11:40:44 --> Model Class Initialized
DEBUG - 2011-09-12 11:40:44 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-12 11:40:44 --> Database Driver Class Initialized
DEBUG - 2011-09-12 11:40:44 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-12 11:40:44 --> Helper loaded: url_helper
DEBUG - 2011-09-12 11:40:44 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-12 11:40:44 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-12 11:40:44 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-12 11:40:44 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-12 11:40:44 --> Final output sent to browser
DEBUG - 2011-09-12 11:40:44 --> Total execution time: 0.0417
DEBUG - 2011-09-12 11:40:45 --> Config Class Initialized
DEBUG - 2011-09-12 11:40:45 --> Hooks Class Initialized
DEBUG - 2011-09-12 11:40:45 --> Utf8 Class Initialized
DEBUG - 2011-09-12 11:40:45 --> UTF-8 Support Enabled
DEBUG - 2011-09-12 11:40:45 --> URI Class Initialized
DEBUG - 2011-09-12 11:40:45 --> Router Class Initialized
DEBUG - 2011-09-12 11:40:45 --> Output Class Initialized
DEBUG - 2011-09-12 11:40:45 --> Input Class Initialized
DEBUG - 2011-09-12 11:40:45 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-12 11:40:45 --> Language Class Initialized
DEBUG - 2011-09-12 11:40:45 --> Loader Class Initialized
DEBUG - 2011-09-12 11:40:45 --> Controller Class Initialized
DEBUG - 2011-09-12 11:40:45 --> Model Class Initialized
DEBUG - 2011-09-12 11:40:45 --> Model Class Initialized
DEBUG - 2011-09-12 11:40:45 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-12 11:40:45 --> Database Driver Class Initialized
DEBUG - 2011-09-12 11:40:45 --> Final output sent to browser
DEBUG - 2011-09-12 11:40:45 --> Total execution time: 0.6232
DEBUG - 2011-09-12 11:40:47 --> Config Class Initialized
DEBUG - 2011-09-12 11:40:47 --> Hooks Class Initialized
DEBUG - 2011-09-12 11:40:47 --> Utf8 Class Initialized
DEBUG - 2011-09-12 11:40:47 --> UTF-8 Support Enabled
DEBUG - 2011-09-12 11:40:47 --> URI Class Initialized
DEBUG - 2011-09-12 11:40:47 --> Router Class Initialized
ERROR - 2011-09-12 11:40:47 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-12 11:41:14 --> Config Class Initialized
DEBUG - 2011-09-12 11:41:14 --> Hooks Class Initialized
DEBUG - 2011-09-12 11:41:14 --> Utf8 Class Initialized
DEBUG - 2011-09-12 11:41:14 --> UTF-8 Support Enabled
DEBUG - 2011-09-12 11:41:14 --> URI Class Initialized
DEBUG - 2011-09-12 11:41:14 --> Router Class Initialized
DEBUG - 2011-09-12 11:41:14 --> Output Class Initialized
DEBUG - 2011-09-12 11:41:14 --> Input Class Initialized
DEBUG - 2011-09-12 11:41:14 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-12 11:41:14 --> Language Class Initialized
DEBUG - 2011-09-12 11:41:14 --> Loader Class Initialized
DEBUG - 2011-09-12 11:41:14 --> Controller Class Initialized
ERROR - 2011-09-12 11:41:14 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-12 11:41:14 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-12 11:41:14 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-12 11:41:14 --> Model Class Initialized
DEBUG - 2011-09-12 11:41:14 --> Model Class Initialized
DEBUG - 2011-09-12 11:41:14 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-12 11:41:14 --> Database Driver Class Initialized
DEBUG - 2011-09-12 11:41:14 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-12 11:41:14 --> Helper loaded: url_helper
DEBUG - 2011-09-12 11:41:14 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-12 11:41:14 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-12 11:41:14 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-12 11:41:14 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-12 11:41:14 --> Final output sent to browser
DEBUG - 2011-09-12 11:41:14 --> Total execution time: 0.0304
DEBUG - 2011-09-12 11:41:15 --> Config Class Initialized
DEBUG - 2011-09-12 11:41:15 --> Hooks Class Initialized
DEBUG - 2011-09-12 11:41:15 --> Utf8 Class Initialized
DEBUG - 2011-09-12 11:41:15 --> UTF-8 Support Enabled
DEBUG - 2011-09-12 11:41:15 --> URI Class Initialized
DEBUG - 2011-09-12 11:41:15 --> Router Class Initialized
DEBUG - 2011-09-12 11:41:15 --> Output Class Initialized
DEBUG - 2011-09-12 11:41:15 --> Input Class Initialized
DEBUG - 2011-09-12 11:41:15 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-12 11:41:15 --> Language Class Initialized
DEBUG - 2011-09-12 11:41:15 --> Loader Class Initialized
DEBUG - 2011-09-12 11:41:15 --> Controller Class Initialized
DEBUG - 2011-09-12 11:41:15 --> Model Class Initialized
DEBUG - 2011-09-12 11:41:15 --> Model Class Initialized
DEBUG - 2011-09-12 11:41:15 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-12 11:41:15 --> Database Driver Class Initialized
DEBUG - 2011-09-12 11:41:16 --> Final output sent to browser
DEBUG - 2011-09-12 11:41:16 --> Total execution time: 0.6475
DEBUG - 2011-09-12 11:41:17 --> Config Class Initialized
DEBUG - 2011-09-12 11:41:17 --> Hooks Class Initialized
DEBUG - 2011-09-12 11:41:17 --> Utf8 Class Initialized
DEBUG - 2011-09-12 11:41:17 --> UTF-8 Support Enabled
DEBUG - 2011-09-12 11:41:17 --> URI Class Initialized
DEBUG - 2011-09-12 11:41:17 --> Router Class Initialized
ERROR - 2011-09-12 11:41:17 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-12 12:41:35 --> Config Class Initialized
DEBUG - 2011-09-12 12:41:35 --> Hooks Class Initialized
DEBUG - 2011-09-12 12:41:35 --> Utf8 Class Initialized
DEBUG - 2011-09-12 12:41:35 --> UTF-8 Support Enabled
DEBUG - 2011-09-12 12:41:35 --> URI Class Initialized
DEBUG - 2011-09-12 12:41:35 --> Router Class Initialized
DEBUG - 2011-09-12 12:41:35 --> No URI present. Default controller set.
DEBUG - 2011-09-12 12:41:35 --> Output Class Initialized
DEBUG - 2011-09-12 12:41:35 --> Input Class Initialized
DEBUG - 2011-09-12 12:41:35 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-12 12:41:35 --> Language Class Initialized
DEBUG - 2011-09-12 12:41:35 --> Loader Class Initialized
DEBUG - 2011-09-12 12:41:35 --> Controller Class Initialized
DEBUG - 2011-09-12 12:41:35 --> File loaded: application/views/splash/main.php
DEBUG - 2011-09-12 12:41:35 --> Helper loaded: url_helper
DEBUG - 2011-09-12 12:41:35 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-12 12:41:35 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-12 12:41:35 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-12 12:41:35 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-12 12:41:35 --> Final output sent to browser
DEBUG - 2011-09-12 12:41:35 --> Total execution time: 0.2115
DEBUG - 2011-09-12 12:43:16 --> Config Class Initialized
DEBUG - 2011-09-12 12:43:16 --> Hooks Class Initialized
DEBUG - 2011-09-12 12:43:16 --> Utf8 Class Initialized
DEBUG - 2011-09-12 12:43:16 --> UTF-8 Support Enabled
DEBUG - 2011-09-12 12:43:16 --> URI Class Initialized
DEBUG - 2011-09-12 12:43:16 --> Router Class Initialized
DEBUG - 2011-09-12 12:43:16 --> Output Class Initialized
DEBUG - 2011-09-12 12:43:16 --> Input Class Initialized
DEBUG - 2011-09-12 12:43:16 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-12 12:43:16 --> Language Class Initialized
DEBUG - 2011-09-12 12:43:16 --> Loader Class Initialized
DEBUG - 2011-09-12 12:43:16 --> Controller Class Initialized
ERROR - 2011-09-12 12:43:16 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-12 12:43:16 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-12 12:43:16 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-12 12:43:16 --> Model Class Initialized
DEBUG - 2011-09-12 12:43:16 --> Model Class Initialized
DEBUG - 2011-09-12 12:43:16 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-12 12:43:16 --> Database Driver Class Initialized
DEBUG - 2011-09-12 12:43:16 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-12 12:43:16 --> Helper loaded: url_helper
DEBUG - 2011-09-12 12:43:16 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-12 12:43:16 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-12 12:43:16 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-12 12:43:16 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-12 12:43:16 --> Final output sent to browser
DEBUG - 2011-09-12 12:43:16 --> Total execution time: 0.0297
DEBUG - 2011-09-12 12:43:17 --> Config Class Initialized
DEBUG - 2011-09-12 12:43:17 --> Hooks Class Initialized
DEBUG - 2011-09-12 12:43:17 --> Utf8 Class Initialized
DEBUG - 2011-09-12 12:43:17 --> UTF-8 Support Enabled
DEBUG - 2011-09-12 12:43:17 --> URI Class Initialized
DEBUG - 2011-09-12 12:43:17 --> Router Class Initialized
DEBUG - 2011-09-12 12:43:17 --> Output Class Initialized
DEBUG - 2011-09-12 12:43:17 --> Input Class Initialized
DEBUG - 2011-09-12 12:43:17 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-12 12:43:17 --> Language Class Initialized
DEBUG - 2011-09-12 12:43:17 --> Loader Class Initialized
DEBUG - 2011-09-12 12:43:17 --> Controller Class Initialized
DEBUG - 2011-09-12 12:43:17 --> Model Class Initialized
DEBUG - 2011-09-12 12:43:17 --> Model Class Initialized
DEBUG - 2011-09-12 12:43:17 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-12 12:43:17 --> Database Driver Class Initialized
DEBUG - 2011-09-12 12:43:17 --> Final output sent to browser
DEBUG - 2011-09-12 12:43:17 --> Total execution time: 0.7393
DEBUG - 2011-09-12 12:43:19 --> Config Class Initialized
DEBUG - 2011-09-12 12:43:19 --> Hooks Class Initialized
DEBUG - 2011-09-12 12:43:19 --> Utf8 Class Initialized
DEBUG - 2011-09-12 12:43:19 --> UTF-8 Support Enabled
DEBUG - 2011-09-12 12:43:19 --> URI Class Initialized
DEBUG - 2011-09-12 12:43:19 --> Router Class Initialized
ERROR - 2011-09-12 12:43:19 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-12 12:43:19 --> Config Class Initialized
DEBUG - 2011-09-12 12:43:19 --> Hooks Class Initialized
DEBUG - 2011-09-12 12:43:19 --> Utf8 Class Initialized
DEBUG - 2011-09-12 12:43:19 --> UTF-8 Support Enabled
DEBUG - 2011-09-12 12:43:19 --> URI Class Initialized
DEBUG - 2011-09-12 12:43:19 --> Router Class Initialized
ERROR - 2011-09-12 12:43:19 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-12 12:43:39 --> Config Class Initialized
DEBUG - 2011-09-12 12:43:39 --> Hooks Class Initialized
DEBUG - 2011-09-12 12:43:39 --> Utf8 Class Initialized
DEBUG - 2011-09-12 12:43:39 --> UTF-8 Support Enabled
DEBUG - 2011-09-12 12:43:39 --> URI Class Initialized
DEBUG - 2011-09-12 12:43:39 --> Router Class Initialized
DEBUG - 2011-09-12 12:43:39 --> Output Class Initialized
DEBUG - 2011-09-12 12:43:39 --> Input Class Initialized
DEBUG - 2011-09-12 12:43:39 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-12 12:43:39 --> Language Class Initialized
DEBUG - 2011-09-12 12:43:39 --> Loader Class Initialized
DEBUG - 2011-09-12 12:43:39 --> Controller Class Initialized
ERROR - 2011-09-12 12:43:39 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-12 12:43:39 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-12 12:43:39 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-12 12:43:39 --> Model Class Initialized
DEBUG - 2011-09-12 12:43:39 --> Model Class Initialized
DEBUG - 2011-09-12 12:43:39 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-12 12:43:39 --> Database Driver Class Initialized
DEBUG - 2011-09-12 12:43:39 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-12 12:43:39 --> Helper loaded: url_helper
DEBUG - 2011-09-12 12:43:39 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-12 12:43:39 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-12 12:43:39 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-12 12:43:39 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-12 12:43:39 --> Final output sent to browser
DEBUG - 2011-09-12 12:43:39 --> Total execution time: 0.0299
DEBUG - 2011-09-12 12:43:39 --> Config Class Initialized
DEBUG - 2011-09-12 12:43:39 --> Hooks Class Initialized
DEBUG - 2011-09-12 12:43:39 --> Utf8 Class Initialized
DEBUG - 2011-09-12 12:43:39 --> UTF-8 Support Enabled
DEBUG - 2011-09-12 12:43:39 --> URI Class Initialized
DEBUG - 2011-09-12 12:43:39 --> Router Class Initialized
DEBUG - 2011-09-12 12:43:39 --> Output Class Initialized
DEBUG - 2011-09-12 12:43:39 --> Input Class Initialized
DEBUG - 2011-09-12 12:43:39 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-12 12:43:39 --> Language Class Initialized
DEBUG - 2011-09-12 12:43:39 --> Loader Class Initialized
DEBUG - 2011-09-12 12:43:39 --> Controller Class Initialized
DEBUG - 2011-09-12 12:43:39 --> Model Class Initialized
DEBUG - 2011-09-12 12:43:39 --> Model Class Initialized
DEBUG - 2011-09-12 12:43:39 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-12 12:43:39 --> Database Driver Class Initialized
DEBUG - 2011-09-12 12:43:40 --> Final output sent to browser
DEBUG - 2011-09-12 12:43:40 --> Total execution time: 0.5753
DEBUG - 2011-09-12 12:43:49 --> Config Class Initialized
DEBUG - 2011-09-12 12:43:49 --> Hooks Class Initialized
DEBUG - 2011-09-12 12:43:49 --> Utf8 Class Initialized
DEBUG - 2011-09-12 12:43:49 --> UTF-8 Support Enabled
DEBUG - 2011-09-12 12:43:49 --> URI Class Initialized
DEBUG - 2011-09-12 12:43:49 --> Router Class Initialized
DEBUG - 2011-09-12 12:43:49 --> Output Class Initialized
DEBUG - 2011-09-12 12:43:49 --> Input Class Initialized
DEBUG - 2011-09-12 12:43:49 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-12 12:43:49 --> Language Class Initialized
DEBUG - 2011-09-12 12:43:49 --> Loader Class Initialized
DEBUG - 2011-09-12 12:43:49 --> Controller Class Initialized
ERROR - 2011-09-12 12:43:49 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-12 12:43:49 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-12 12:43:49 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-12 12:43:49 --> Model Class Initialized
DEBUG - 2011-09-12 12:43:49 --> Model Class Initialized
DEBUG - 2011-09-12 12:43:49 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-12 12:43:49 --> Database Driver Class Initialized
DEBUG - 2011-09-12 12:43:49 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-12 12:43:49 --> Helper loaded: url_helper
DEBUG - 2011-09-12 12:43:49 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-12 12:43:49 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-12 12:43:49 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-12 12:43:49 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-12 12:43:49 --> Final output sent to browser
DEBUG - 2011-09-12 12:43:49 --> Total execution time: 0.0334
DEBUG - 2011-09-12 12:43:50 --> Config Class Initialized
DEBUG - 2011-09-12 12:43:50 --> Hooks Class Initialized
DEBUG - 2011-09-12 12:43:50 --> Utf8 Class Initialized
DEBUG - 2011-09-12 12:43:50 --> UTF-8 Support Enabled
DEBUG - 2011-09-12 12:43:50 --> URI Class Initialized
DEBUG - 2011-09-12 12:43:50 --> Router Class Initialized
DEBUG - 2011-09-12 12:43:50 --> Output Class Initialized
DEBUG - 2011-09-12 12:43:50 --> Input Class Initialized
DEBUG - 2011-09-12 12:43:50 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-12 12:43:50 --> Language Class Initialized
DEBUG - 2011-09-12 12:43:50 --> Loader Class Initialized
DEBUG - 2011-09-12 12:43:50 --> Controller Class Initialized
DEBUG - 2011-09-12 12:43:50 --> Model Class Initialized
DEBUG - 2011-09-12 12:43:50 --> Model Class Initialized
DEBUG - 2011-09-12 12:43:50 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-12 12:43:50 --> Database Driver Class Initialized
DEBUG - 2011-09-12 12:43:51 --> Final output sent to browser
DEBUG - 2011-09-12 12:43:51 --> Total execution time: 0.8141
DEBUG - 2011-09-12 13:11:37 --> Config Class Initialized
DEBUG - 2011-09-12 13:11:37 --> Hooks Class Initialized
DEBUG - 2011-09-12 13:11:37 --> Utf8 Class Initialized
DEBUG - 2011-09-12 13:11:37 --> UTF-8 Support Enabled
DEBUG - 2011-09-12 13:11:37 --> URI Class Initialized
DEBUG - 2011-09-12 13:11:37 --> Router Class Initialized
DEBUG - 2011-09-12 13:11:37 --> Output Class Initialized
DEBUG - 2011-09-12 13:11:37 --> Input Class Initialized
DEBUG - 2011-09-12 13:11:37 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-12 13:11:37 --> Language Class Initialized
DEBUG - 2011-09-12 13:11:37 --> Loader Class Initialized
DEBUG - 2011-09-12 13:11:37 --> Controller Class Initialized
DEBUG - 2011-09-12 13:11:37 --> Model Class Initialized
DEBUG - 2011-09-12 13:11:37 --> Model Class Initialized
DEBUG - 2011-09-12 13:11:37 --> Model Class Initialized
DEBUG - 2011-09-12 13:11:37 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-12 13:11:37 --> Database Driver Class Initialized
DEBUG - 2011-09-12 13:11:37 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-12 13:11:37 --> Helper loaded: url_helper
DEBUG - 2011-09-12 13:11:37 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-12 13:11:37 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-12 13:11:37 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-12 13:11:37 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-12 13:11:37 --> Final output sent to browser
DEBUG - 2011-09-12 13:11:37 --> Total execution time: 0.2546
DEBUG - 2011-09-12 13:11:40 --> Config Class Initialized
DEBUG - 2011-09-12 13:11:40 --> Hooks Class Initialized
DEBUG - 2011-09-12 13:11:40 --> Utf8 Class Initialized
DEBUG - 2011-09-12 13:11:40 --> UTF-8 Support Enabled
DEBUG - 2011-09-12 13:11:40 --> URI Class Initialized
DEBUG - 2011-09-12 13:11:40 --> Router Class Initialized
ERROR - 2011-09-12 13:11:40 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-12 13:47:54 --> Config Class Initialized
DEBUG - 2011-09-12 13:47:54 --> Hooks Class Initialized
DEBUG - 2011-09-12 13:47:54 --> Utf8 Class Initialized
DEBUG - 2011-09-12 13:47:54 --> UTF-8 Support Enabled
DEBUG - 2011-09-12 13:47:54 --> URI Class Initialized
DEBUG - 2011-09-12 13:47:54 --> Router Class Initialized
DEBUG - 2011-09-12 13:47:54 --> Output Class Initialized
DEBUG - 2011-09-12 13:47:54 --> Input Class Initialized
DEBUG - 2011-09-12 13:47:54 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-12 13:47:54 --> Language Class Initialized
DEBUG - 2011-09-12 13:47:54 --> Loader Class Initialized
DEBUG - 2011-09-12 13:47:54 --> Controller Class Initialized
ERROR - 2011-09-12 13:47:54 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-12 13:47:54 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-12 13:47:54 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-12 13:47:54 --> Model Class Initialized
DEBUG - 2011-09-12 13:47:54 --> Model Class Initialized
DEBUG - 2011-09-12 13:47:54 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-12 13:47:54 --> Database Driver Class Initialized
DEBUG - 2011-09-12 13:47:54 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-12 13:47:54 --> Helper loaded: url_helper
DEBUG - 2011-09-12 13:47:54 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-12 13:47:54 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-12 13:47:54 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-12 13:47:54 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-12 13:47:54 --> Final output sent to browser
DEBUG - 2011-09-12 13:47:54 --> Total execution time: 0.0309
DEBUG - 2011-09-12 13:47:55 --> Config Class Initialized
DEBUG - 2011-09-12 13:47:55 --> Hooks Class Initialized
DEBUG - 2011-09-12 13:47:55 --> Utf8 Class Initialized
DEBUG - 2011-09-12 13:47:55 --> UTF-8 Support Enabled
DEBUG - 2011-09-12 13:47:55 --> URI Class Initialized
DEBUG - 2011-09-12 13:47:55 --> Router Class Initialized
DEBUG - 2011-09-12 13:47:55 --> Output Class Initialized
DEBUG - 2011-09-12 13:47:55 --> Input Class Initialized
DEBUG - 2011-09-12 13:47:55 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-12 13:47:55 --> Language Class Initialized
DEBUG - 2011-09-12 13:47:55 --> Loader Class Initialized
DEBUG - 2011-09-12 13:47:55 --> Controller Class Initialized
DEBUG - 2011-09-12 13:47:55 --> Model Class Initialized
DEBUG - 2011-09-12 13:47:55 --> Model Class Initialized
DEBUG - 2011-09-12 13:47:55 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-12 13:47:55 --> Database Driver Class Initialized
DEBUG - 2011-09-12 13:47:56 --> Final output sent to browser
DEBUG - 2011-09-12 13:47:56 --> Total execution time: 0.7854
DEBUG - 2011-09-12 13:48:24 --> Config Class Initialized
DEBUG - 2011-09-12 13:48:24 --> Hooks Class Initialized
DEBUG - 2011-09-12 13:48:24 --> Utf8 Class Initialized
DEBUG - 2011-09-12 13:48:24 --> UTF-8 Support Enabled
DEBUG - 2011-09-12 13:48:24 --> URI Class Initialized
DEBUG - 2011-09-12 13:48:24 --> Router Class Initialized
DEBUG - 2011-09-12 13:48:24 --> Output Class Initialized
DEBUG - 2011-09-12 13:48:24 --> Input Class Initialized
DEBUG - 2011-09-12 13:48:24 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-12 13:48:24 --> Language Class Initialized
DEBUG - 2011-09-12 13:48:24 --> Loader Class Initialized
DEBUG - 2011-09-12 13:48:24 --> Controller Class Initialized
ERROR - 2011-09-12 13:48:24 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-12 13:48:24 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-12 13:48:24 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-12 13:48:24 --> Model Class Initialized
DEBUG - 2011-09-12 13:48:24 --> Model Class Initialized
DEBUG - 2011-09-12 13:48:24 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-12 13:48:24 --> Database Driver Class Initialized
DEBUG - 2011-09-12 13:48:24 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-12 13:48:24 --> Helper loaded: url_helper
DEBUG - 2011-09-12 13:48:24 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-12 13:48:24 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-12 13:48:24 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-12 13:48:24 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-12 13:48:24 --> Final output sent to browser
DEBUG - 2011-09-12 13:48:24 --> Total execution time: 0.0354
DEBUG - 2011-09-12 13:48:27 --> Config Class Initialized
DEBUG - 2011-09-12 13:48:27 --> Hooks Class Initialized
DEBUG - 2011-09-12 13:48:27 --> Utf8 Class Initialized
DEBUG - 2011-09-12 13:48:27 --> UTF-8 Support Enabled
DEBUG - 2011-09-12 13:48:27 --> URI Class Initialized
DEBUG - 2011-09-12 13:48:27 --> Router Class Initialized
DEBUG - 2011-09-12 13:48:27 --> Output Class Initialized
DEBUG - 2011-09-12 13:48:27 --> Input Class Initialized
DEBUG - 2011-09-12 13:48:27 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-12 13:48:27 --> Language Class Initialized
DEBUG - 2011-09-12 13:48:27 --> Loader Class Initialized
DEBUG - 2011-09-12 13:48:27 --> Controller Class Initialized
DEBUG - 2011-09-12 13:48:27 --> Model Class Initialized
DEBUG - 2011-09-12 13:48:27 --> Model Class Initialized
DEBUG - 2011-09-12 13:48:27 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-12 13:48:27 --> Database Driver Class Initialized
DEBUG - 2011-09-12 13:48:28 --> Final output sent to browser
DEBUG - 2011-09-12 13:48:28 --> Total execution time: 0.4625
DEBUG - 2011-09-12 13:59:07 --> Config Class Initialized
DEBUG - 2011-09-12 13:59:07 --> Hooks Class Initialized
DEBUG - 2011-09-12 13:59:07 --> Utf8 Class Initialized
DEBUG - 2011-09-12 13:59:07 --> UTF-8 Support Enabled
DEBUG - 2011-09-12 13:59:07 --> URI Class Initialized
DEBUG - 2011-09-12 13:59:07 --> Router Class Initialized
DEBUG - 2011-09-12 13:59:07 --> No URI present. Default controller set.
DEBUG - 2011-09-12 13:59:07 --> Output Class Initialized
DEBUG - 2011-09-12 13:59:07 --> Input Class Initialized
DEBUG - 2011-09-12 13:59:07 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-12 13:59:07 --> Language Class Initialized
DEBUG - 2011-09-12 13:59:07 --> Loader Class Initialized
DEBUG - 2011-09-12 13:59:07 --> Controller Class Initialized
DEBUG - 2011-09-12 13:59:07 --> File loaded: application/views/splash/main.php
DEBUG - 2011-09-12 13:59:07 --> Helper loaded: url_helper
DEBUG - 2011-09-12 13:59:07 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-12 13:59:07 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-12 13:59:07 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-12 13:59:07 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-12 13:59:07 --> Final output sent to browser
DEBUG - 2011-09-12 13:59:07 --> Total execution time: 0.0322
DEBUG - 2011-09-12 14:39:19 --> Config Class Initialized
DEBUG - 2011-09-12 14:39:19 --> Hooks Class Initialized
DEBUG - 2011-09-12 14:39:19 --> Utf8 Class Initialized
DEBUG - 2011-09-12 14:39:19 --> UTF-8 Support Enabled
DEBUG - 2011-09-12 14:39:19 --> URI Class Initialized
DEBUG - 2011-09-12 14:39:19 --> Router Class Initialized
DEBUG - 2011-09-12 14:39:19 --> Output Class Initialized
DEBUG - 2011-09-12 14:39:19 --> Input Class Initialized
DEBUG - 2011-09-12 14:39:19 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-12 14:39:19 --> Language Class Initialized
DEBUG - 2011-09-12 14:39:19 --> Loader Class Initialized
DEBUG - 2011-09-12 14:39:19 --> Controller Class Initialized
DEBUG - 2011-09-12 14:39:19 --> Model Class Initialized
DEBUG - 2011-09-12 14:39:19 --> Model Class Initialized
DEBUG - 2011-09-12 14:39:19 --> Model Class Initialized
DEBUG - 2011-09-12 14:39:19 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-12 14:39:19 --> Database Driver Class Initialized
DEBUG - 2011-09-12 14:39:19 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-12 14:39:19 --> Helper loaded: url_helper
DEBUG - 2011-09-12 14:39:19 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-12 14:39:19 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-12 14:39:19 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-12 14:39:19 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-12 14:39:19 --> Final output sent to browser
DEBUG - 2011-09-12 14:39:19 --> Total execution time: 0.5798
DEBUG - 2011-09-12 14:39:26 --> Config Class Initialized
DEBUG - 2011-09-12 14:39:26 --> Hooks Class Initialized
DEBUG - 2011-09-12 14:39:26 --> Utf8 Class Initialized
DEBUG - 2011-09-12 14:39:26 --> UTF-8 Support Enabled
DEBUG - 2011-09-12 14:39:26 --> URI Class Initialized
DEBUG - 2011-09-12 14:39:26 --> Router Class Initialized
ERROR - 2011-09-12 14:39:26 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-12 14:39:28 --> Config Class Initialized
DEBUG - 2011-09-12 14:39:28 --> Hooks Class Initialized
DEBUG - 2011-09-12 14:39:28 --> Utf8 Class Initialized
DEBUG - 2011-09-12 14:39:28 --> UTF-8 Support Enabled
DEBUG - 2011-09-12 14:39:28 --> URI Class Initialized
DEBUG - 2011-09-12 14:39:28 --> Router Class Initialized
DEBUG - 2011-09-12 14:39:28 --> Output Class Initialized
DEBUG - 2011-09-12 14:39:28 --> Input Class Initialized
DEBUG - 2011-09-12 14:39:28 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-12 14:39:28 --> Language Class Initialized
DEBUG - 2011-09-12 14:39:28 --> Loader Class Initialized
DEBUG - 2011-09-12 14:39:28 --> Controller Class Initialized
DEBUG - 2011-09-12 14:39:28 --> Model Class Initialized
DEBUG - 2011-09-12 14:39:28 --> Model Class Initialized
DEBUG - 2011-09-12 14:39:28 --> Model Class Initialized
DEBUG - 2011-09-12 14:39:28 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-12 14:39:28 --> Database Driver Class Initialized
DEBUG - 2011-09-12 14:39:28 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-12 14:39:28 --> Helper loaded: url_helper
DEBUG - 2011-09-12 14:39:28 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-12 14:39:28 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-12 14:39:28 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-12 14:39:28 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-12 14:39:28 --> Final output sent to browser
DEBUG - 2011-09-12 14:39:28 --> Total execution time: 0.0962
DEBUG - 2011-09-12 14:39:30 --> Config Class Initialized
DEBUG - 2011-09-12 14:39:30 --> Hooks Class Initialized
DEBUG - 2011-09-12 14:39:30 --> Utf8 Class Initialized
DEBUG - 2011-09-12 14:39:30 --> UTF-8 Support Enabled
DEBUG - 2011-09-12 14:39:30 --> URI Class Initialized
DEBUG - 2011-09-12 14:39:30 --> Router Class Initialized
ERROR - 2011-09-12 14:39:30 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-12 14:39:43 --> Config Class Initialized
DEBUG - 2011-09-12 14:39:43 --> Hooks Class Initialized
DEBUG - 2011-09-12 14:39:43 --> Utf8 Class Initialized
DEBUG - 2011-09-12 14:39:43 --> UTF-8 Support Enabled
DEBUG - 2011-09-12 14:39:43 --> URI Class Initialized
DEBUG - 2011-09-12 14:39:43 --> Router Class Initialized
DEBUG - 2011-09-12 14:39:43 --> Output Class Initialized
DEBUG - 2011-09-12 14:39:43 --> Input Class Initialized
DEBUG - 2011-09-12 14:39:43 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-12 14:39:43 --> Language Class Initialized
DEBUG - 2011-09-12 14:39:43 --> Loader Class Initialized
DEBUG - 2011-09-12 14:39:43 --> Controller Class Initialized
DEBUG - 2011-09-12 14:39:43 --> Model Class Initialized
DEBUG - 2011-09-12 14:39:43 --> Model Class Initialized
DEBUG - 2011-09-12 14:39:43 --> Model Class Initialized
DEBUG - 2011-09-12 14:39:43 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-12 14:39:43 --> Database Driver Class Initialized
DEBUG - 2011-09-12 14:39:45 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-12 14:39:45 --> Helper loaded: url_helper
DEBUG - 2011-09-12 14:39:45 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-12 14:39:45 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-12 14:39:45 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-12 14:39:45 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-12 14:39:45 --> Final output sent to browser
DEBUG - 2011-09-12 14:39:45 --> Total execution time: 1.9903
DEBUG - 2011-09-12 14:39:47 --> Config Class Initialized
DEBUG - 2011-09-12 14:39:47 --> Hooks Class Initialized
DEBUG - 2011-09-12 14:39:47 --> Utf8 Class Initialized
DEBUG - 2011-09-12 14:39:47 --> UTF-8 Support Enabled
DEBUG - 2011-09-12 14:39:47 --> URI Class Initialized
DEBUG - 2011-09-12 14:39:47 --> Router Class Initialized
ERROR - 2011-09-12 14:39:47 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-12 14:40:20 --> Config Class Initialized
DEBUG - 2011-09-12 14:40:20 --> Hooks Class Initialized
DEBUG - 2011-09-12 14:40:20 --> Utf8 Class Initialized
DEBUG - 2011-09-12 14:40:20 --> UTF-8 Support Enabled
DEBUG - 2011-09-12 14:40:20 --> URI Class Initialized
DEBUG - 2011-09-12 14:40:20 --> Router Class Initialized
DEBUG - 2011-09-12 14:40:20 --> Output Class Initialized
DEBUG - 2011-09-12 14:40:20 --> Input Class Initialized
DEBUG - 2011-09-12 14:40:20 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-12 14:40:20 --> Language Class Initialized
DEBUG - 2011-09-12 14:40:20 --> Loader Class Initialized
DEBUG - 2011-09-12 14:40:20 --> Controller Class Initialized
DEBUG - 2011-09-12 14:40:20 --> Model Class Initialized
DEBUG - 2011-09-12 14:40:20 --> Model Class Initialized
DEBUG - 2011-09-12 14:40:20 --> Model Class Initialized
DEBUG - 2011-09-12 14:40:20 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-12 14:40:20 --> Database Driver Class Initialized
DEBUG - 2011-09-12 14:40:20 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-12 14:40:20 --> Helper loaded: url_helper
DEBUG - 2011-09-12 14:40:20 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-12 14:40:20 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-12 14:40:20 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-12 14:40:20 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-12 14:40:20 --> Final output sent to browser
DEBUG - 2011-09-12 14:40:20 --> Total execution time: 0.2030
DEBUG - 2011-09-12 15:25:12 --> Config Class Initialized
DEBUG - 2011-09-12 15:25:12 --> Hooks Class Initialized
DEBUG - 2011-09-12 15:25:12 --> Utf8 Class Initialized
DEBUG - 2011-09-12 15:25:12 --> UTF-8 Support Enabled
DEBUG - 2011-09-12 15:25:12 --> URI Class Initialized
DEBUG - 2011-09-12 15:25:12 --> Router Class Initialized
DEBUG - 2011-09-12 15:25:12 --> Output Class Initialized
DEBUG - 2011-09-12 15:25:12 --> Input Class Initialized
DEBUG - 2011-09-12 15:25:12 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-12 15:25:12 --> Language Class Initialized
DEBUG - 2011-09-12 15:25:12 --> Loader Class Initialized
DEBUG - 2011-09-12 15:25:12 --> Controller Class Initialized
DEBUG - 2011-09-12 15:25:12 --> Model Class Initialized
DEBUG - 2011-09-12 15:25:12 --> Model Class Initialized
DEBUG - 2011-09-12 15:25:12 --> Model Class Initialized
DEBUG - 2011-09-12 15:25:12 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-12 15:25:12 --> Database Driver Class Initialized
DEBUG - 2011-09-12 15:25:12 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-12 15:25:12 --> Helper loaded: url_helper
DEBUG - 2011-09-12 15:25:12 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-12 15:25:12 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-12 15:25:12 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-12 15:25:12 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-12 15:25:12 --> Final output sent to browser
DEBUG - 2011-09-12 15:25:12 --> Total execution time: 0.2304
DEBUG - 2011-09-12 16:52:07 --> Config Class Initialized
DEBUG - 2011-09-12 16:52:07 --> Hooks Class Initialized
DEBUG - 2011-09-12 16:52:07 --> Utf8 Class Initialized
DEBUG - 2011-09-12 16:52:07 --> UTF-8 Support Enabled
DEBUG - 2011-09-12 16:52:07 --> URI Class Initialized
DEBUG - 2011-09-12 16:52:07 --> Router Class Initialized
DEBUG - 2011-09-12 16:52:07 --> Output Class Initialized
DEBUG - 2011-09-12 16:52:07 --> Input Class Initialized
DEBUG - 2011-09-12 16:52:07 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-12 16:52:07 --> Language Class Initialized
DEBUG - 2011-09-12 16:52:07 --> Loader Class Initialized
DEBUG - 2011-09-12 16:52:07 --> Controller Class Initialized
ERROR - 2011-09-12 16:52:07 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-12 16:52:07 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-12 16:52:07 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-12 16:52:07 --> Model Class Initialized
DEBUG - 2011-09-12 16:52:07 --> Model Class Initialized
DEBUG - 2011-09-12 16:52:07 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-12 16:52:07 --> Database Driver Class Initialized
DEBUG - 2011-09-12 16:52:07 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-12 16:52:07 --> Helper loaded: url_helper
DEBUG - 2011-09-12 16:52:07 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-12 16:52:07 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-12 16:52:07 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-12 16:52:07 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-12 16:52:07 --> Final output sent to browser
DEBUG - 2011-09-12 16:52:07 --> Total execution time: 0.1620
DEBUG - 2011-09-12 16:52:08 --> Config Class Initialized
DEBUG - 2011-09-12 16:52:08 --> Hooks Class Initialized
DEBUG - 2011-09-12 16:52:08 --> Utf8 Class Initialized
DEBUG - 2011-09-12 16:52:08 --> UTF-8 Support Enabled
DEBUG - 2011-09-12 16:52:08 --> URI Class Initialized
DEBUG - 2011-09-12 16:52:08 --> Router Class Initialized
DEBUG - 2011-09-12 16:52:08 --> Output Class Initialized
DEBUG - 2011-09-12 16:52:08 --> Input Class Initialized
DEBUG - 2011-09-12 16:52:08 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-12 16:52:08 --> Language Class Initialized
DEBUG - 2011-09-12 16:52:08 --> Loader Class Initialized
DEBUG - 2011-09-12 16:52:08 --> Controller Class Initialized
DEBUG - 2011-09-12 16:52:08 --> Model Class Initialized
DEBUG - 2011-09-12 16:52:08 --> Model Class Initialized
DEBUG - 2011-09-12 16:52:08 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-12 16:52:08 --> Database Driver Class Initialized
DEBUG - 2011-09-12 16:52:09 --> Final output sent to browser
DEBUG - 2011-09-12 16:52:09 --> Total execution time: 0.6892
DEBUG - 2011-09-12 16:52:11 --> Config Class Initialized
DEBUG - 2011-09-12 16:52:11 --> Hooks Class Initialized
DEBUG - 2011-09-12 16:52:11 --> Utf8 Class Initialized
DEBUG - 2011-09-12 16:52:11 --> UTF-8 Support Enabled
DEBUG - 2011-09-12 16:52:11 --> URI Class Initialized
DEBUG - 2011-09-12 16:52:11 --> Router Class Initialized
ERROR - 2011-09-12 16:52:11 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-12 17:06:20 --> Config Class Initialized
DEBUG - 2011-09-12 17:06:20 --> Hooks Class Initialized
DEBUG - 2011-09-12 17:06:20 --> Utf8 Class Initialized
DEBUG - 2011-09-12 17:06:20 --> UTF-8 Support Enabled
DEBUG - 2011-09-12 17:06:20 --> URI Class Initialized
DEBUG - 2011-09-12 17:06:20 --> Router Class Initialized
DEBUG - 2011-09-12 17:06:20 --> Output Class Initialized
DEBUG - 2011-09-12 17:06:20 --> Input Class Initialized
DEBUG - 2011-09-12 17:06:20 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-12 17:06:20 --> Language Class Initialized
DEBUG - 2011-09-12 17:06:20 --> Loader Class Initialized
DEBUG - 2011-09-12 17:06:20 --> Controller Class Initialized
DEBUG - 2011-09-12 17:06:20 --> Model Class Initialized
DEBUG - 2011-09-12 17:06:20 --> Model Class Initialized
DEBUG - 2011-09-12 17:06:20 --> Model Class Initialized
DEBUG - 2011-09-12 17:06:20 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-12 17:06:20 --> Database Driver Class Initialized
DEBUG - 2011-09-12 17:06:20 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-12 17:06:20 --> Helper loaded: url_helper
DEBUG - 2011-09-12 17:06:20 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-12 17:06:20 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-12 17:06:20 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-12 17:06:20 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-12 17:06:20 --> Final output sent to browser
DEBUG - 2011-09-12 17:06:20 --> Total execution time: 0.2501
DEBUG - 2011-09-12 17:06:25 --> Config Class Initialized
DEBUG - 2011-09-12 17:06:25 --> Hooks Class Initialized
DEBUG - 2011-09-12 17:06:25 --> Utf8 Class Initialized
DEBUG - 2011-09-12 17:06:25 --> UTF-8 Support Enabled
DEBUG - 2011-09-12 17:06:25 --> URI Class Initialized
DEBUG - 2011-09-12 17:06:25 --> Router Class Initialized
ERROR - 2011-09-12 17:06:25 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-12 17:22:26 --> Config Class Initialized
DEBUG - 2011-09-12 17:22:26 --> Hooks Class Initialized
DEBUG - 2011-09-12 17:22:26 --> Utf8 Class Initialized
DEBUG - 2011-09-12 17:22:26 --> UTF-8 Support Enabled
DEBUG - 2011-09-12 17:22:26 --> URI Class Initialized
DEBUG - 2011-09-12 17:22:26 --> Router Class Initialized
ERROR - 2011-09-12 17:22:26 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-09-12 17:22:26 --> Config Class Initialized
DEBUG - 2011-09-12 17:22:26 --> Hooks Class Initialized
DEBUG - 2011-09-12 17:22:26 --> Utf8 Class Initialized
DEBUG - 2011-09-12 17:22:26 --> UTF-8 Support Enabled
DEBUG - 2011-09-12 17:22:26 --> URI Class Initialized
DEBUG - 2011-09-12 17:22:26 --> Router Class Initialized
DEBUG - 2011-09-12 17:22:26 --> Output Class Initialized
DEBUG - 2011-09-12 17:22:26 --> Input Class Initialized
DEBUG - 2011-09-12 17:22:26 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-12 17:22:26 --> Language Class Initialized
DEBUG - 2011-09-12 17:22:26 --> Loader Class Initialized
DEBUG - 2011-09-12 17:22:26 --> Controller Class Initialized
ERROR - 2011-09-12 17:22:26 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-12 17:22:26 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-12 17:22:26 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-12 17:22:26 --> Model Class Initialized
DEBUG - 2011-09-12 17:22:26 --> Model Class Initialized
DEBUG - 2011-09-12 17:22:26 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-12 17:22:26 --> Database Driver Class Initialized
DEBUG - 2011-09-12 17:22:26 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-12 17:22:26 --> Helper loaded: url_helper
DEBUG - 2011-09-12 17:22:26 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-12 17:22:26 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-12 17:22:26 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-12 17:22:26 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-12 17:22:26 --> Final output sent to browser
DEBUG - 2011-09-12 17:22:26 --> Total execution time: 0.0287
DEBUG - 2011-09-12 18:03:18 --> Config Class Initialized
DEBUG - 2011-09-12 18:03:18 --> Hooks Class Initialized
DEBUG - 2011-09-12 18:03:18 --> Utf8 Class Initialized
DEBUG - 2011-09-12 18:03:18 --> UTF-8 Support Enabled
DEBUG - 2011-09-12 18:03:18 --> URI Class Initialized
DEBUG - 2011-09-12 18:03:18 --> Router Class Initialized
DEBUG - 2011-09-12 18:03:18 --> Output Class Initialized
DEBUG - 2011-09-12 18:03:18 --> Input Class Initialized
DEBUG - 2011-09-12 18:03:18 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-12 18:03:18 --> Language Class Initialized
DEBUG - 2011-09-12 18:03:18 --> Loader Class Initialized
DEBUG - 2011-09-12 18:03:18 --> Controller Class Initialized
ERROR - 2011-09-12 18:03:18 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-12 18:03:18 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-12 18:03:18 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-12 18:03:18 --> Model Class Initialized
DEBUG - 2011-09-12 18:03:18 --> Model Class Initialized
DEBUG - 2011-09-12 18:03:18 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-12 18:03:18 --> Database Driver Class Initialized
DEBUG - 2011-09-12 18:03:18 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-12 18:03:18 --> Helper loaded: url_helper
DEBUG - 2011-09-12 18:03:18 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-12 18:03:18 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-12 18:03:18 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-12 18:03:18 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-12 18:03:18 --> Final output sent to browser
DEBUG - 2011-09-12 18:03:18 --> Total execution time: 0.0510
DEBUG - 2011-09-12 18:03:20 --> Config Class Initialized
DEBUG - 2011-09-12 18:03:20 --> Hooks Class Initialized
DEBUG - 2011-09-12 18:03:20 --> Utf8 Class Initialized
DEBUG - 2011-09-12 18:03:20 --> UTF-8 Support Enabled
DEBUG - 2011-09-12 18:03:20 --> URI Class Initialized
DEBUG - 2011-09-12 18:03:20 --> Router Class Initialized
DEBUG - 2011-09-12 18:03:20 --> Output Class Initialized
DEBUG - 2011-09-12 18:03:20 --> Input Class Initialized
DEBUG - 2011-09-12 18:03:20 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-12 18:03:20 --> Language Class Initialized
DEBUG - 2011-09-12 18:03:20 --> Loader Class Initialized
DEBUG - 2011-09-12 18:03:20 --> Controller Class Initialized
DEBUG - 2011-09-12 18:03:20 --> Model Class Initialized
DEBUG - 2011-09-12 18:03:20 --> Model Class Initialized
DEBUG - 2011-09-12 18:03:20 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-12 18:03:20 --> Database Driver Class Initialized
DEBUG - 2011-09-12 18:03:20 --> Final output sent to browser
DEBUG - 2011-09-12 18:03:21 --> Total execution time: 0.7185
DEBUG - 2011-09-12 18:03:22 --> Config Class Initialized
DEBUG - 2011-09-12 18:03:22 --> Hooks Class Initialized
DEBUG - 2011-09-12 18:03:22 --> Utf8 Class Initialized
DEBUG - 2011-09-12 18:03:22 --> UTF-8 Support Enabled
DEBUG - 2011-09-12 18:03:22 --> URI Class Initialized
DEBUG - 2011-09-12 18:03:22 --> Router Class Initialized
ERROR - 2011-09-12 18:03:22 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-12 18:03:50 --> Config Class Initialized
DEBUG - 2011-09-12 18:03:50 --> Hooks Class Initialized
DEBUG - 2011-09-12 18:03:50 --> Utf8 Class Initialized
DEBUG - 2011-09-12 18:03:50 --> UTF-8 Support Enabled
DEBUG - 2011-09-12 18:03:50 --> URI Class Initialized
DEBUG - 2011-09-12 18:03:50 --> Router Class Initialized
DEBUG - 2011-09-12 18:03:50 --> Output Class Initialized
DEBUG - 2011-09-12 18:03:50 --> Input Class Initialized
DEBUG - 2011-09-12 18:03:50 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-12 18:03:50 --> Language Class Initialized
DEBUG - 2011-09-12 18:03:50 --> Loader Class Initialized
DEBUG - 2011-09-12 18:03:50 --> Controller Class Initialized
ERROR - 2011-09-12 18:03:50 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-12 18:03:50 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-12 18:03:50 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-12 18:03:50 --> Model Class Initialized
DEBUG - 2011-09-12 18:03:50 --> Model Class Initialized
DEBUG - 2011-09-12 18:03:50 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-12 18:03:50 --> Database Driver Class Initialized
DEBUG - 2011-09-12 18:03:50 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-12 18:03:50 --> Helper loaded: url_helper
DEBUG - 2011-09-12 18:03:50 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-12 18:03:50 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-12 18:03:50 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-12 18:03:50 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-12 18:03:50 --> Final output sent to browser
DEBUG - 2011-09-12 18:03:50 --> Total execution time: 0.0342
DEBUG - 2011-09-12 18:03:51 --> Config Class Initialized
DEBUG - 2011-09-12 18:03:51 --> Hooks Class Initialized
DEBUG - 2011-09-12 18:03:51 --> Utf8 Class Initialized
DEBUG - 2011-09-12 18:03:51 --> UTF-8 Support Enabled
DEBUG - 2011-09-12 18:03:51 --> URI Class Initialized
DEBUG - 2011-09-12 18:03:51 --> Router Class Initialized
DEBUG - 2011-09-12 18:03:51 --> Output Class Initialized
DEBUG - 2011-09-12 18:03:51 --> Input Class Initialized
DEBUG - 2011-09-12 18:03:51 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-12 18:03:51 --> Language Class Initialized
DEBUG - 2011-09-12 18:03:51 --> Loader Class Initialized
DEBUG - 2011-09-12 18:03:51 --> Controller Class Initialized
DEBUG - 2011-09-12 18:03:51 --> Model Class Initialized
DEBUG - 2011-09-12 18:03:51 --> Model Class Initialized
DEBUG - 2011-09-12 18:03:51 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-12 18:03:51 --> Database Driver Class Initialized
DEBUG - 2011-09-12 18:03:51 --> Final output sent to browser
DEBUG - 2011-09-12 18:03:51 --> Total execution time: 0.7850
DEBUG - 2011-09-12 18:03:52 --> Config Class Initialized
DEBUG - 2011-09-12 18:03:52 --> Hooks Class Initialized
DEBUG - 2011-09-12 18:03:52 --> Utf8 Class Initialized
DEBUG - 2011-09-12 18:03:52 --> UTF-8 Support Enabled
DEBUG - 2011-09-12 18:03:52 --> URI Class Initialized
DEBUG - 2011-09-12 18:03:52 --> Router Class Initialized
ERROR - 2011-09-12 18:03:52 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-12 18:04:01 --> Config Class Initialized
DEBUG - 2011-09-12 18:04:01 --> Hooks Class Initialized
DEBUG - 2011-09-12 18:04:01 --> Utf8 Class Initialized
DEBUG - 2011-09-12 18:04:01 --> UTF-8 Support Enabled
DEBUG - 2011-09-12 18:04:01 --> URI Class Initialized
DEBUG - 2011-09-12 18:04:01 --> Router Class Initialized
DEBUG - 2011-09-12 18:04:01 --> Output Class Initialized
DEBUG - 2011-09-12 18:04:01 --> Input Class Initialized
DEBUG - 2011-09-12 18:04:01 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-12 18:04:01 --> Language Class Initialized
DEBUG - 2011-09-12 18:04:01 --> Loader Class Initialized
DEBUG - 2011-09-12 18:04:01 --> Controller Class Initialized
ERROR - 2011-09-12 18:04:01 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-12 18:04:01 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-12 18:04:01 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-12 18:04:01 --> Model Class Initialized
DEBUG - 2011-09-12 18:04:01 --> Model Class Initialized
DEBUG - 2011-09-12 18:04:01 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-12 18:04:01 --> Database Driver Class Initialized
DEBUG - 2011-09-12 18:04:01 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-12 18:04:01 --> Helper loaded: url_helper
DEBUG - 2011-09-12 18:04:01 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-12 18:04:01 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-12 18:04:01 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-12 18:04:01 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-12 18:04:01 --> Final output sent to browser
DEBUG - 2011-09-12 18:04:01 --> Total execution time: 0.0598
DEBUG - 2011-09-12 18:04:02 --> Config Class Initialized
DEBUG - 2011-09-12 18:04:02 --> Hooks Class Initialized
DEBUG - 2011-09-12 18:04:02 --> Utf8 Class Initialized
DEBUG - 2011-09-12 18:04:02 --> UTF-8 Support Enabled
DEBUG - 2011-09-12 18:04:02 --> URI Class Initialized
DEBUG - 2011-09-12 18:04:02 --> Router Class Initialized
DEBUG - 2011-09-12 18:04:02 --> Output Class Initialized
DEBUG - 2011-09-12 18:04:02 --> Input Class Initialized
DEBUG - 2011-09-12 18:04:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-12 18:04:02 --> Language Class Initialized
DEBUG - 2011-09-12 18:04:02 --> Loader Class Initialized
DEBUG - 2011-09-12 18:04:02 --> Controller Class Initialized
DEBUG - 2011-09-12 18:04:02 --> Model Class Initialized
DEBUG - 2011-09-12 18:04:02 --> Model Class Initialized
DEBUG - 2011-09-12 18:04:02 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-12 18:04:02 --> Database Driver Class Initialized
DEBUG - 2011-09-12 18:04:02 --> Final output sent to browser
DEBUG - 2011-09-12 18:04:02 --> Total execution time: 0.7267
DEBUG - 2011-09-12 18:04:03 --> Config Class Initialized
DEBUG - 2011-09-12 18:04:03 --> Hooks Class Initialized
DEBUG - 2011-09-12 18:04:03 --> Utf8 Class Initialized
DEBUG - 2011-09-12 18:04:03 --> UTF-8 Support Enabled
DEBUG - 2011-09-12 18:04:03 --> URI Class Initialized
DEBUG - 2011-09-12 18:04:03 --> Router Class Initialized
ERROR - 2011-09-12 18:04:03 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-12 18:04:09 --> Config Class Initialized
DEBUG - 2011-09-12 18:04:09 --> Hooks Class Initialized
DEBUG - 2011-09-12 18:04:09 --> Utf8 Class Initialized
DEBUG - 2011-09-12 18:04:09 --> UTF-8 Support Enabled
DEBUG - 2011-09-12 18:04:09 --> URI Class Initialized
DEBUG - 2011-09-12 18:04:09 --> Router Class Initialized
DEBUG - 2011-09-12 18:04:09 --> Output Class Initialized
DEBUG - 2011-09-12 18:04:09 --> Input Class Initialized
DEBUG - 2011-09-12 18:04:09 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-12 18:04:09 --> Language Class Initialized
DEBUG - 2011-09-12 18:04:09 --> Loader Class Initialized
DEBUG - 2011-09-12 18:04:09 --> Controller Class Initialized
ERROR - 2011-09-12 18:04:09 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-12 18:04:09 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-12 18:04:09 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-12 18:04:09 --> Model Class Initialized
DEBUG - 2011-09-12 18:04:09 --> Model Class Initialized
DEBUG - 2011-09-12 18:04:09 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-12 18:04:09 --> Database Driver Class Initialized
DEBUG - 2011-09-12 18:04:09 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-12 18:04:09 --> Helper loaded: url_helper
DEBUG - 2011-09-12 18:04:09 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-12 18:04:09 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-12 18:04:09 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-12 18:04:09 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-12 18:04:09 --> Final output sent to browser
DEBUG - 2011-09-12 18:04:09 --> Total execution time: 0.0317
DEBUG - 2011-09-12 18:04:10 --> Config Class Initialized
DEBUG - 2011-09-12 18:04:10 --> Hooks Class Initialized
DEBUG - 2011-09-12 18:04:10 --> Utf8 Class Initialized
DEBUG - 2011-09-12 18:04:10 --> UTF-8 Support Enabled
DEBUG - 2011-09-12 18:04:10 --> URI Class Initialized
DEBUG - 2011-09-12 18:04:10 --> Router Class Initialized
DEBUG - 2011-09-12 18:04:10 --> Output Class Initialized
DEBUG - 2011-09-12 18:04:10 --> Input Class Initialized
DEBUG - 2011-09-12 18:04:10 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-12 18:04:10 --> Language Class Initialized
DEBUG - 2011-09-12 18:04:10 --> Loader Class Initialized
DEBUG - 2011-09-12 18:04:10 --> Controller Class Initialized
DEBUG - 2011-09-12 18:04:10 --> Model Class Initialized
DEBUG - 2011-09-12 18:04:10 --> Model Class Initialized
DEBUG - 2011-09-12 18:04:10 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-12 18:04:10 --> Database Driver Class Initialized
DEBUG - 2011-09-12 18:04:11 --> Final output sent to browser
DEBUG - 2011-09-12 18:04:11 --> Total execution time: 0.8108
DEBUG - 2011-09-12 18:04:12 --> Config Class Initialized
DEBUG - 2011-09-12 18:04:12 --> Hooks Class Initialized
DEBUG - 2011-09-12 18:04:12 --> Utf8 Class Initialized
DEBUG - 2011-09-12 18:04:12 --> UTF-8 Support Enabled
DEBUG - 2011-09-12 18:04:12 --> URI Class Initialized
DEBUG - 2011-09-12 18:04:12 --> Router Class Initialized
ERROR - 2011-09-12 18:04:12 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-12 18:13:39 --> Config Class Initialized
DEBUG - 2011-09-12 18:13:39 --> Hooks Class Initialized
DEBUG - 2011-09-12 18:13:39 --> Utf8 Class Initialized
DEBUG - 2011-09-12 18:13:39 --> UTF-8 Support Enabled
DEBUG - 2011-09-12 18:13:39 --> URI Class Initialized
DEBUG - 2011-09-12 18:13:39 --> Router Class Initialized
DEBUG - 2011-09-12 18:13:39 --> Output Class Initialized
DEBUG - 2011-09-12 18:13:39 --> Input Class Initialized
DEBUG - 2011-09-12 18:13:39 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-12 18:13:39 --> Language Class Initialized
DEBUG - 2011-09-12 18:13:39 --> Loader Class Initialized
DEBUG - 2011-09-12 18:13:39 --> Controller Class Initialized
ERROR - 2011-09-12 18:13:39 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-12 18:13:39 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-12 18:13:39 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-12 18:13:39 --> Model Class Initialized
DEBUG - 2011-09-12 18:13:39 --> Model Class Initialized
DEBUG - 2011-09-12 18:13:39 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-12 18:13:39 --> Database Driver Class Initialized
DEBUG - 2011-09-12 18:13:39 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-12 18:13:39 --> Helper loaded: url_helper
DEBUG - 2011-09-12 18:13:39 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-12 18:13:39 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-12 18:13:39 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-12 18:13:39 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-12 18:13:39 --> Final output sent to browser
DEBUG - 2011-09-12 18:13:39 --> Total execution time: 0.0311
DEBUG - 2011-09-12 20:55:08 --> Config Class Initialized
DEBUG - 2011-09-12 20:55:08 --> Hooks Class Initialized
DEBUG - 2011-09-12 20:55:08 --> Utf8 Class Initialized
DEBUG - 2011-09-12 20:55:08 --> UTF-8 Support Enabled
DEBUG - 2011-09-12 20:55:08 --> URI Class Initialized
DEBUG - 2011-09-12 20:55:08 --> Router Class Initialized
DEBUG - 2011-09-12 20:55:08 --> No URI present. Default controller set.
DEBUG - 2011-09-12 20:55:08 --> Output Class Initialized
DEBUG - 2011-09-12 20:55:08 --> Input Class Initialized
DEBUG - 2011-09-12 20:55:08 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-12 20:55:08 --> Language Class Initialized
DEBUG - 2011-09-12 20:55:08 --> Loader Class Initialized
DEBUG - 2011-09-12 20:55:08 --> Controller Class Initialized
DEBUG - 2011-09-12 20:55:08 --> File loaded: application/views/splash/main.php
DEBUG - 2011-09-12 20:55:08 --> Helper loaded: url_helper
DEBUG - 2011-09-12 20:55:08 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-12 20:55:08 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-12 20:55:08 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-12 20:55:08 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-12 20:55:08 --> Final output sent to browser
DEBUG - 2011-09-12 20:55:08 --> Total execution time: 0.5404
DEBUG - 2011-09-12 21:55:04 --> Config Class Initialized
DEBUG - 2011-09-12 21:55:04 --> Hooks Class Initialized
DEBUG - 2011-09-12 21:55:04 --> Utf8 Class Initialized
DEBUG - 2011-09-12 21:55:04 --> UTF-8 Support Enabled
DEBUG - 2011-09-12 21:55:04 --> URI Class Initialized
DEBUG - 2011-09-12 21:55:04 --> Router Class Initialized
DEBUG - 2011-09-12 21:55:04 --> Output Class Initialized
DEBUG - 2011-09-12 21:55:04 --> Input Class Initialized
DEBUG - 2011-09-12 21:55:04 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-12 21:55:04 --> Language Class Initialized
DEBUG - 2011-09-12 21:55:04 --> Loader Class Initialized
DEBUG - 2011-09-12 21:55:04 --> Controller Class Initialized
ERROR - 2011-09-12 21:55:04 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-12 21:55:04 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-12 21:55:04 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-12 21:55:04 --> Model Class Initialized
DEBUG - 2011-09-12 21:55:04 --> Model Class Initialized
DEBUG - 2011-09-12 21:55:04 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-12 21:55:05 --> Database Driver Class Initialized
DEBUG - 2011-09-12 21:55:06 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-12 21:55:06 --> Helper loaded: url_helper
DEBUG - 2011-09-12 21:55:06 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-12 21:55:06 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-12 21:55:06 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-12 21:55:06 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-12 21:55:06 --> Final output sent to browser
DEBUG - 2011-09-12 21:55:06 --> Total execution time: 2.0138
DEBUG - 2011-09-12 21:55:07 --> Config Class Initialized
DEBUG - 2011-09-12 21:55:07 --> Hooks Class Initialized
DEBUG - 2011-09-12 21:55:07 --> Utf8 Class Initialized
DEBUG - 2011-09-12 21:55:07 --> UTF-8 Support Enabled
DEBUG - 2011-09-12 21:55:07 --> URI Class Initialized
DEBUG - 2011-09-12 21:55:07 --> Router Class Initialized
DEBUG - 2011-09-12 21:55:07 --> Output Class Initialized
DEBUG - 2011-09-12 21:55:07 --> Input Class Initialized
DEBUG - 2011-09-12 21:55:07 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-12 21:55:07 --> Language Class Initialized
DEBUG - 2011-09-12 21:55:07 --> Loader Class Initialized
DEBUG - 2011-09-12 21:55:07 --> Controller Class Initialized
DEBUG - 2011-09-12 21:55:07 --> Model Class Initialized
DEBUG - 2011-09-12 21:55:07 --> Model Class Initialized
DEBUG - 2011-09-12 21:55:07 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-12 21:55:07 --> Database Driver Class Initialized
DEBUG - 2011-09-12 21:55:08 --> Final output sent to browser
DEBUG - 2011-09-12 21:55:08 --> Total execution time: 0.8137
DEBUG - 2011-09-12 21:55:10 --> Config Class Initialized
DEBUG - 2011-09-12 21:55:10 --> Hooks Class Initialized
DEBUG - 2011-09-12 21:55:10 --> Utf8 Class Initialized
DEBUG - 2011-09-12 21:55:10 --> UTF-8 Support Enabled
DEBUG - 2011-09-12 21:55:10 --> URI Class Initialized
DEBUG - 2011-09-12 21:55:10 --> Router Class Initialized
ERROR - 2011-09-12 21:55:10 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-12 22:44:06 --> Config Class Initialized
DEBUG - 2011-09-12 22:44:06 --> Hooks Class Initialized
DEBUG - 2011-09-12 22:44:06 --> Utf8 Class Initialized
DEBUG - 2011-09-12 22:44:06 --> UTF-8 Support Enabled
DEBUG - 2011-09-12 22:44:06 --> URI Class Initialized
DEBUG - 2011-09-12 22:44:06 --> Router Class Initialized
DEBUG - 2011-09-12 22:44:06 --> Output Class Initialized
DEBUG - 2011-09-12 22:44:06 --> Input Class Initialized
DEBUG - 2011-09-12 22:44:06 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-12 22:44:06 --> Language Class Initialized
DEBUG - 2011-09-12 22:44:06 --> Loader Class Initialized
DEBUG - 2011-09-12 22:44:06 --> Controller Class Initialized
DEBUG - 2011-09-12 22:44:06 --> Model Class Initialized
DEBUG - 2011-09-12 22:44:06 --> Model Class Initialized
DEBUG - 2011-09-12 22:44:06 --> Model Class Initialized
DEBUG - 2011-09-12 22:44:06 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-12 22:44:06 --> Database Driver Class Initialized
DEBUG - 2011-09-12 22:44:07 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-12 22:44:07 --> Helper loaded: url_helper
DEBUG - 2011-09-12 22:44:07 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-12 22:44:07 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-12 22:44:07 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-12 22:44:07 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-12 22:44:07 --> Final output sent to browser
DEBUG - 2011-09-12 22:44:07 --> Total execution time: 0.5222
DEBUG - 2011-09-12 22:44:08 --> Config Class Initialized
DEBUG - 2011-09-12 22:44:08 --> Hooks Class Initialized
DEBUG - 2011-09-12 22:44:08 --> Utf8 Class Initialized
DEBUG - 2011-09-12 22:44:08 --> UTF-8 Support Enabled
DEBUG - 2011-09-12 22:44:08 --> URI Class Initialized
DEBUG - 2011-09-12 22:44:08 --> Router Class Initialized
ERROR - 2011-09-12 22:44:08 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-12 22:44:19 --> Config Class Initialized
DEBUG - 2011-09-12 22:44:19 --> Hooks Class Initialized
DEBUG - 2011-09-12 22:44:19 --> Utf8 Class Initialized
DEBUG - 2011-09-12 22:44:19 --> UTF-8 Support Enabled
DEBUG - 2011-09-12 22:44:19 --> URI Class Initialized
DEBUG - 2011-09-12 22:44:19 --> Router Class Initialized
DEBUG - 2011-09-12 22:44:19 --> Output Class Initialized
DEBUG - 2011-09-12 22:44:19 --> Input Class Initialized
DEBUG - 2011-09-12 22:44:19 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-12 22:44:19 --> Language Class Initialized
DEBUG - 2011-09-12 22:44:19 --> Loader Class Initialized
DEBUG - 2011-09-12 22:44:19 --> Controller Class Initialized
DEBUG - 2011-09-12 22:44:19 --> Model Class Initialized
DEBUG - 2011-09-12 22:44:19 --> Model Class Initialized
DEBUG - 2011-09-12 22:44:19 --> Model Class Initialized
DEBUG - 2011-09-12 22:44:19 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-12 22:44:19 --> Database Driver Class Initialized
DEBUG - 2011-09-12 22:44:19 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-12 22:44:19 --> Helper loaded: url_helper
DEBUG - 2011-09-12 22:44:19 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-12 22:44:19 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-12 22:44:19 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-12 22:44:19 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-12 22:44:19 --> Final output sent to browser
DEBUG - 2011-09-12 22:44:19 --> Total execution time: 0.3484
DEBUG - 2011-09-12 22:44:21 --> Config Class Initialized
DEBUG - 2011-09-12 22:44:21 --> Hooks Class Initialized
DEBUG - 2011-09-12 22:44:21 --> Utf8 Class Initialized
DEBUG - 2011-09-12 22:44:21 --> UTF-8 Support Enabled
DEBUG - 2011-09-12 22:44:21 --> URI Class Initialized
DEBUG - 2011-09-12 22:44:21 --> Router Class Initialized
DEBUG - 2011-09-12 22:44:21 --> Output Class Initialized
DEBUG - 2011-09-12 22:44:21 --> Input Class Initialized
DEBUG - 2011-09-12 22:44:21 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-12 22:44:21 --> Language Class Initialized
DEBUG - 2011-09-12 22:44:21 --> Loader Class Initialized
DEBUG - 2011-09-12 22:44:21 --> Controller Class Initialized
DEBUG - 2011-09-12 22:44:21 --> Model Class Initialized
DEBUG - 2011-09-12 22:44:21 --> Model Class Initialized
DEBUG - 2011-09-12 22:44:21 --> Model Class Initialized
DEBUG - 2011-09-12 22:44:21 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-12 22:44:21 --> Database Driver Class Initialized
DEBUG - 2011-09-12 22:44:21 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-12 22:44:21 --> Helper loaded: url_helper
DEBUG - 2011-09-12 22:44:21 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-12 22:44:21 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-12 22:44:21 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-12 22:44:21 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-12 22:44:21 --> Final output sent to browser
DEBUG - 2011-09-12 22:44:21 --> Config Class Initialized
DEBUG - 2011-09-12 22:44:21 --> Hooks Class Initialized
DEBUG - 2011-09-12 22:44:21 --> Utf8 Class Initialized
DEBUG - 2011-09-12 22:44:21 --> UTF-8 Support Enabled
DEBUG - 2011-09-12 22:44:21 --> URI Class Initialized
DEBUG - 2011-09-12 22:44:21 --> Router Class Initialized
DEBUG - 2011-09-12 22:44:21 --> Total execution time: 0.1595
ERROR - 2011-09-12 22:44:21 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-12 22:44:38 --> Config Class Initialized
DEBUG - 2011-09-12 22:44:38 --> Hooks Class Initialized
DEBUG - 2011-09-12 22:44:38 --> Utf8 Class Initialized
DEBUG - 2011-09-12 22:44:38 --> UTF-8 Support Enabled
DEBUG - 2011-09-12 22:44:38 --> URI Class Initialized
DEBUG - 2011-09-12 22:44:38 --> Router Class Initialized
DEBUG - 2011-09-12 22:44:38 --> Output Class Initialized
DEBUG - 2011-09-12 22:44:38 --> Input Class Initialized
DEBUG - 2011-09-12 22:44:38 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-12 22:44:38 --> Language Class Initialized
DEBUG - 2011-09-12 22:44:38 --> Loader Class Initialized
DEBUG - 2011-09-12 22:44:38 --> Controller Class Initialized
DEBUG - 2011-09-12 22:44:38 --> Model Class Initialized
DEBUG - 2011-09-12 22:44:38 --> Model Class Initialized
DEBUG - 2011-09-12 22:44:38 --> Model Class Initialized
DEBUG - 2011-09-12 22:44:38 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-12 22:44:38 --> Database Driver Class Initialized
DEBUG - 2011-09-12 22:44:39 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-12 22:44:39 --> Helper loaded: url_helper
DEBUG - 2011-09-12 22:44:39 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-12 22:44:39 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-12 22:44:39 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-12 22:44:39 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-12 22:44:39 --> Final output sent to browser
DEBUG - 2011-09-12 22:44:39 --> Total execution time: 0.6814
DEBUG - 2011-09-12 22:44:40 --> Config Class Initialized
DEBUG - 2011-09-12 22:44:40 --> Hooks Class Initialized
DEBUG - 2011-09-12 22:44:40 --> Utf8 Class Initialized
DEBUG - 2011-09-12 22:44:40 --> UTF-8 Support Enabled
DEBUG - 2011-09-12 22:44:40 --> URI Class Initialized
DEBUG - 2011-09-12 22:44:40 --> Router Class Initialized
ERROR - 2011-09-12 22:44:40 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-12 22:44:40 --> Config Class Initialized
DEBUG - 2011-09-12 22:44:40 --> Hooks Class Initialized
DEBUG - 2011-09-12 22:44:40 --> Utf8 Class Initialized
DEBUG - 2011-09-12 22:44:40 --> UTF-8 Support Enabled
DEBUG - 2011-09-12 22:44:40 --> URI Class Initialized
DEBUG - 2011-09-12 22:44:40 --> Router Class Initialized
ERROR - 2011-09-12 22:44:40 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-12 22:44:54 --> Config Class Initialized
DEBUG - 2011-09-12 22:44:54 --> Hooks Class Initialized
DEBUG - 2011-09-12 22:44:54 --> Utf8 Class Initialized
DEBUG - 2011-09-12 22:44:54 --> UTF-8 Support Enabled
DEBUG - 2011-09-12 22:44:54 --> URI Class Initialized
DEBUG - 2011-09-12 22:44:54 --> Router Class Initialized
DEBUG - 2011-09-12 22:44:54 --> Output Class Initialized
DEBUG - 2011-09-12 22:44:54 --> Input Class Initialized
DEBUG - 2011-09-12 22:44:54 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-12 22:44:54 --> Language Class Initialized
DEBUG - 2011-09-12 22:44:54 --> Loader Class Initialized
DEBUG - 2011-09-12 22:44:54 --> Controller Class Initialized
DEBUG - 2011-09-12 22:44:54 --> Model Class Initialized
DEBUG - 2011-09-12 22:44:54 --> Model Class Initialized
DEBUG - 2011-09-12 22:44:54 --> Model Class Initialized
DEBUG - 2011-09-12 22:44:54 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-12 22:44:54 --> Database Driver Class Initialized
DEBUG - 2011-09-12 22:44:55 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-12 22:44:55 --> Helper loaded: url_helper
DEBUG - 2011-09-12 22:44:55 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-12 22:44:55 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-12 22:44:55 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-12 22:44:55 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-12 22:44:55 --> Final output sent to browser
DEBUG - 2011-09-12 22:44:55 --> Total execution time: 0.3676
DEBUG - 2011-09-12 22:44:55 --> Config Class Initialized
DEBUG - 2011-09-12 22:44:55 --> Hooks Class Initialized
DEBUG - 2011-09-12 22:44:55 --> Utf8 Class Initialized
DEBUG - 2011-09-12 22:44:55 --> UTF-8 Support Enabled
DEBUG - 2011-09-12 22:44:55 --> URI Class Initialized
DEBUG - 2011-09-12 22:44:55 --> Router Class Initialized
DEBUG - 2011-09-12 22:44:55 --> Output Class Initialized
DEBUG - 2011-09-12 22:44:55 --> Input Class Initialized
DEBUG - 2011-09-12 22:44:55 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-12 22:44:55 --> Language Class Initialized
DEBUG - 2011-09-12 22:44:55 --> Loader Class Initialized
DEBUG - 2011-09-12 22:44:55 --> Controller Class Initialized
DEBUG - 2011-09-12 22:44:55 --> Model Class Initialized
DEBUG - 2011-09-12 22:44:55 --> Model Class Initialized
DEBUG - 2011-09-12 22:44:55 --> Model Class Initialized
DEBUG - 2011-09-12 22:44:55 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-12 22:44:55 --> Database Driver Class Initialized
DEBUG - 2011-09-12 22:44:55 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-12 22:44:55 --> Helper loaded: url_helper
DEBUG - 2011-09-12 22:44:55 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-12 22:44:55 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-12 22:44:55 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-12 22:44:55 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-12 22:44:55 --> Final output sent to browser
DEBUG - 2011-09-12 22:44:55 --> Total execution time: 0.0444
DEBUG - 2011-09-12 22:44:56 --> Config Class Initialized
DEBUG - 2011-09-12 22:44:56 --> Hooks Class Initialized
DEBUG - 2011-09-12 22:44:56 --> Utf8 Class Initialized
DEBUG - 2011-09-12 22:44:56 --> UTF-8 Support Enabled
DEBUG - 2011-09-12 22:44:56 --> URI Class Initialized
DEBUG - 2011-09-12 22:44:56 --> Router Class Initialized
ERROR - 2011-09-12 22:44:56 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-12 22:45:02 --> Config Class Initialized
DEBUG - 2011-09-12 22:45:02 --> Hooks Class Initialized
DEBUG - 2011-09-12 22:45:02 --> Utf8 Class Initialized
DEBUG - 2011-09-12 22:45:02 --> UTF-8 Support Enabled
DEBUG - 2011-09-12 22:45:02 --> URI Class Initialized
DEBUG - 2011-09-12 22:45:02 --> Router Class Initialized
DEBUG - 2011-09-12 22:45:02 --> Output Class Initialized
DEBUG - 2011-09-12 22:45:02 --> Input Class Initialized
DEBUG - 2011-09-12 22:45:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-12 22:45:02 --> Language Class Initialized
DEBUG - 2011-09-12 22:45:02 --> Loader Class Initialized
DEBUG - 2011-09-12 22:45:02 --> Controller Class Initialized
DEBUG - 2011-09-12 22:45:02 --> Model Class Initialized
DEBUG - 2011-09-12 22:45:02 --> Model Class Initialized
DEBUG - 2011-09-12 22:45:02 --> Model Class Initialized
DEBUG - 2011-09-12 22:45:02 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-12 22:45:03 --> Database Driver Class Initialized
DEBUG - 2011-09-12 22:45:04 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-12 22:45:04 --> Helper loaded: url_helper
DEBUG - 2011-09-12 22:45:04 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-12 22:45:04 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-12 22:45:04 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-12 22:45:04 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-12 22:45:04 --> Final output sent to browser
DEBUG - 2011-09-12 22:45:04 --> Total execution time: 1.4553
DEBUG - 2011-09-12 22:45:05 --> Config Class Initialized
DEBUG - 2011-09-12 22:45:05 --> Hooks Class Initialized
DEBUG - 2011-09-12 22:45:05 --> Utf8 Class Initialized
DEBUG - 2011-09-12 22:45:05 --> UTF-8 Support Enabled
DEBUG - 2011-09-12 22:45:05 --> URI Class Initialized
DEBUG - 2011-09-12 22:45:05 --> Router Class Initialized
ERROR - 2011-09-12 22:45:05 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-12 22:45:23 --> Config Class Initialized
DEBUG - 2011-09-12 22:45:23 --> Hooks Class Initialized
DEBUG - 2011-09-12 22:45:23 --> Utf8 Class Initialized
DEBUG - 2011-09-12 22:45:23 --> UTF-8 Support Enabled
DEBUG - 2011-09-12 22:45:23 --> URI Class Initialized
DEBUG - 2011-09-12 22:45:23 --> Router Class Initialized
DEBUG - 2011-09-12 22:45:23 --> Output Class Initialized
DEBUG - 2011-09-12 22:45:23 --> Input Class Initialized
DEBUG - 2011-09-12 22:45:23 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-12 22:45:23 --> Language Class Initialized
DEBUG - 2011-09-12 22:45:23 --> Loader Class Initialized
DEBUG - 2011-09-12 22:45:23 --> Controller Class Initialized
DEBUG - 2011-09-12 22:45:23 --> Model Class Initialized
DEBUG - 2011-09-12 22:45:23 --> Model Class Initialized
DEBUG - 2011-09-12 22:45:23 --> Model Class Initialized
DEBUG - 2011-09-12 22:45:23 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-12 22:45:23 --> Database Driver Class Initialized
DEBUG - 2011-09-12 22:45:23 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-12 22:45:23 --> Helper loaded: url_helper
DEBUG - 2011-09-12 22:45:23 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-12 22:45:23 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-12 22:45:23 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-12 22:45:23 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-12 22:45:23 --> Final output sent to browser
DEBUG - 2011-09-12 22:45:23 --> Total execution time: 0.7425
DEBUG - 2011-09-12 22:45:24 --> Config Class Initialized
DEBUG - 2011-09-12 22:45:24 --> Hooks Class Initialized
DEBUG - 2011-09-12 22:45:24 --> Utf8 Class Initialized
DEBUG - 2011-09-12 22:45:24 --> UTF-8 Support Enabled
DEBUG - 2011-09-12 22:45:24 --> URI Class Initialized
DEBUG - 2011-09-12 22:45:24 --> Router Class Initialized
ERROR - 2011-09-12 22:45:24 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-12 22:45:25 --> Config Class Initialized
DEBUG - 2011-09-12 22:45:25 --> Hooks Class Initialized
DEBUG - 2011-09-12 22:45:25 --> Utf8 Class Initialized
DEBUG - 2011-09-12 22:45:25 --> UTF-8 Support Enabled
DEBUG - 2011-09-12 22:45:25 --> URI Class Initialized
DEBUG - 2011-09-12 22:45:25 --> Router Class Initialized
ERROR - 2011-09-12 22:45:25 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-12 22:45:32 --> Config Class Initialized
DEBUG - 2011-09-12 22:45:32 --> Hooks Class Initialized
DEBUG - 2011-09-12 22:45:32 --> Utf8 Class Initialized
DEBUG - 2011-09-12 22:45:32 --> UTF-8 Support Enabled
DEBUG - 2011-09-12 22:45:32 --> URI Class Initialized
DEBUG - 2011-09-12 22:45:32 --> Router Class Initialized
DEBUG - 2011-09-12 22:45:32 --> Output Class Initialized
DEBUG - 2011-09-12 22:45:32 --> Input Class Initialized
DEBUG - 2011-09-12 22:45:32 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-12 22:45:32 --> Language Class Initialized
DEBUG - 2011-09-12 22:45:32 --> Loader Class Initialized
DEBUG - 2011-09-12 22:45:32 --> Controller Class Initialized
DEBUG - 2011-09-12 22:45:32 --> Model Class Initialized
DEBUG - 2011-09-12 22:45:32 --> Model Class Initialized
DEBUG - 2011-09-12 22:45:32 --> Model Class Initialized
DEBUG - 2011-09-12 22:45:32 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-12 22:45:32 --> Database Driver Class Initialized
DEBUG - 2011-09-12 22:45:32 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-12 22:45:32 --> Helper loaded: url_helper
DEBUG - 2011-09-12 22:45:32 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-12 22:45:32 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-12 22:45:32 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-12 22:45:32 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-12 22:45:32 --> Final output sent to browser
DEBUG - 2011-09-12 22:45:32 --> Total execution time: 0.2353
DEBUG - 2011-09-12 22:45:33 --> Config Class Initialized
DEBUG - 2011-09-12 22:45:33 --> Hooks Class Initialized
DEBUG - 2011-09-12 22:45:33 --> Utf8 Class Initialized
DEBUG - 2011-09-12 22:45:33 --> UTF-8 Support Enabled
DEBUG - 2011-09-12 22:45:33 --> URI Class Initialized
DEBUG - 2011-09-12 22:45:33 --> Router Class Initialized
ERROR - 2011-09-12 22:45:33 --> 404 Page Not Found --> favicon.ico

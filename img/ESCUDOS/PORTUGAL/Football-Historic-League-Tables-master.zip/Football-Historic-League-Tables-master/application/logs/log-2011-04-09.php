<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2011-04-09 02:09:48 --> Config Class Initialized
DEBUG - 2011-04-09 02:09:48 --> Hooks Class Initialized
DEBUG - 2011-04-09 02:09:48 --> Utf8 Class Initialized
DEBUG - 2011-04-09 02:09:48 --> UTF-8 Support Enabled
DEBUG - 2011-04-09 02:09:48 --> URI Class Initialized
DEBUG - 2011-04-09 02:09:48 --> Router Class Initialized
DEBUG - 2011-04-09 02:09:49 --> Output Class Initialized
DEBUG - 2011-04-09 02:09:49 --> Input Class Initialized
DEBUG - 2011-04-09 02:09:49 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-09 02:09:49 --> Language Class Initialized
DEBUG - 2011-04-09 02:09:49 --> Loader Class Initialized
DEBUG - 2011-04-09 02:09:49 --> Controller Class Initialized
DEBUG - 2011-04-09 02:09:49 --> Model Class Initialized
DEBUG - 2011-04-09 02:09:49 --> Model Class Initialized
DEBUG - 2011-04-09 02:09:49 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-09 02:09:49 --> Database Driver Class Initialized
DEBUG - 2011-04-09 02:09:50 --> Final output sent to browser
DEBUG - 2011-04-09 02:09:50 --> Total execution time: 1.4766
DEBUG - 2011-04-09 04:37:01 --> Config Class Initialized
DEBUG - 2011-04-09 04:37:01 --> Hooks Class Initialized
DEBUG - 2011-04-09 04:37:01 --> Utf8 Class Initialized
DEBUG - 2011-04-09 04:37:01 --> UTF-8 Support Enabled
DEBUG - 2011-04-09 04:37:01 --> URI Class Initialized
DEBUG - 2011-04-09 04:37:01 --> Router Class Initialized
DEBUG - 2011-04-09 04:37:01 --> No URI present. Default controller set.
DEBUG - 2011-04-09 04:37:01 --> Output Class Initialized
DEBUG - 2011-04-09 04:37:01 --> Input Class Initialized
DEBUG - 2011-04-09 04:37:01 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-09 04:37:01 --> Language Class Initialized
DEBUG - 2011-04-09 04:37:01 --> Loader Class Initialized
DEBUG - 2011-04-09 04:37:01 --> Controller Class Initialized
DEBUG - 2011-04-09 04:37:01 --> File loaded: application/views/splash/main.php
DEBUG - 2011-04-09 04:37:01 --> Helper loaded: url_helper
DEBUG - 2011-04-09 04:37:01 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-09 04:37:01 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-09 04:37:01 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-09 04:37:01 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-09 04:37:01 --> Final output sent to browser
DEBUG - 2011-04-09 04:37:01 --> Total execution time: 0.3107
DEBUG - 2011-04-09 04:37:02 --> Config Class Initialized
DEBUG - 2011-04-09 04:37:02 --> Hooks Class Initialized
DEBUG - 2011-04-09 04:37:02 --> Utf8 Class Initialized
DEBUG - 2011-04-09 04:37:02 --> UTF-8 Support Enabled
DEBUG - 2011-04-09 04:37:02 --> URI Class Initialized
DEBUG - 2011-04-09 04:37:02 --> Router Class Initialized
ERROR - 2011-04-09 04:37:02 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-09 04:37:03 --> Config Class Initialized
DEBUG - 2011-04-09 04:37:03 --> Hooks Class Initialized
DEBUG - 2011-04-09 04:37:03 --> Utf8 Class Initialized
DEBUG - 2011-04-09 04:37:03 --> UTF-8 Support Enabled
DEBUG - 2011-04-09 04:37:03 --> URI Class Initialized
DEBUG - 2011-04-09 04:37:03 --> Router Class Initialized
ERROR - 2011-04-09 04:37:03 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-09 04:37:08 --> Config Class Initialized
DEBUG - 2011-04-09 04:37:08 --> Hooks Class Initialized
DEBUG - 2011-04-09 04:37:08 --> Utf8 Class Initialized
DEBUG - 2011-04-09 04:37:08 --> UTF-8 Support Enabled
DEBUG - 2011-04-09 04:37:08 --> URI Class Initialized
DEBUG - 2011-04-09 04:37:08 --> Router Class Initialized
DEBUG - 2011-04-09 04:37:08 --> Output Class Initialized
DEBUG - 2011-04-09 04:37:08 --> Input Class Initialized
DEBUG - 2011-04-09 04:37:08 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-09 04:37:08 --> Language Class Initialized
DEBUG - 2011-04-09 04:37:08 --> Loader Class Initialized
DEBUG - 2011-04-09 04:37:08 --> Controller Class Initialized
DEBUG - 2011-04-09 04:37:08 --> Model Class Initialized
DEBUG - 2011-04-09 04:37:08 --> Model Class Initialized
DEBUG - 2011-04-09 04:37:08 --> Model Class Initialized
DEBUG - 2011-04-09 04:37:08 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-09 04:37:08 --> Database Driver Class Initialized
DEBUG - 2011-04-09 04:37:14 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-09 04:37:14 --> Helper loaded: url_helper
DEBUG - 2011-04-09 04:37:14 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-09 04:37:14 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-09 04:37:14 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-09 04:37:14 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-09 04:37:14 --> Final output sent to browser
DEBUG - 2011-04-09 04:37:14 --> Total execution time: 6.5318
DEBUG - 2011-04-09 04:37:18 --> Config Class Initialized
DEBUG - 2011-04-09 04:37:18 --> Hooks Class Initialized
DEBUG - 2011-04-09 04:37:18 --> Utf8 Class Initialized
DEBUG - 2011-04-09 04:37:18 --> UTF-8 Support Enabled
DEBUG - 2011-04-09 04:37:18 --> URI Class Initialized
DEBUG - 2011-04-09 04:37:18 --> Router Class Initialized
DEBUG - 2011-04-09 04:37:18 --> Output Class Initialized
DEBUG - 2011-04-09 04:37:18 --> Input Class Initialized
DEBUG - 2011-04-09 04:37:18 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-09 04:37:18 --> Language Class Initialized
DEBUG - 2011-04-09 04:37:18 --> Loader Class Initialized
DEBUG - 2011-04-09 04:37:18 --> Controller Class Initialized
DEBUG - 2011-04-09 04:37:18 --> Model Class Initialized
DEBUG - 2011-04-09 04:37:18 --> Model Class Initialized
DEBUG - 2011-04-09 04:37:18 --> Model Class Initialized
DEBUG - 2011-04-09 04:37:18 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-09 04:37:18 --> Database Driver Class Initialized
DEBUG - 2011-04-09 04:37:18 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-09 04:37:18 --> Helper loaded: url_helper
DEBUG - 2011-04-09 04:37:18 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-09 04:37:18 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-09 04:37:18 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-09 04:37:18 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-09 04:37:18 --> Final output sent to browser
DEBUG - 2011-04-09 04:37:18 --> Total execution time: 0.0480
DEBUG - 2011-04-09 04:37:20 --> Config Class Initialized
DEBUG - 2011-04-09 04:37:20 --> Hooks Class Initialized
DEBUG - 2011-04-09 04:37:20 --> Utf8 Class Initialized
DEBUG - 2011-04-09 04:37:20 --> UTF-8 Support Enabled
DEBUG - 2011-04-09 04:37:20 --> URI Class Initialized
DEBUG - 2011-04-09 04:37:20 --> Router Class Initialized
ERROR - 2011-04-09 04:37:20 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-09 04:37:32 --> Config Class Initialized
DEBUG - 2011-04-09 04:37:32 --> Hooks Class Initialized
DEBUG - 2011-04-09 04:37:32 --> Utf8 Class Initialized
DEBUG - 2011-04-09 04:37:32 --> UTF-8 Support Enabled
DEBUG - 2011-04-09 04:37:32 --> URI Class Initialized
DEBUG - 2011-04-09 04:37:32 --> Router Class Initialized
DEBUG - 2011-04-09 04:37:32 --> Output Class Initialized
DEBUG - 2011-04-09 04:37:32 --> Input Class Initialized
DEBUG - 2011-04-09 04:37:32 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-09 04:37:32 --> Language Class Initialized
DEBUG - 2011-04-09 04:37:32 --> Loader Class Initialized
DEBUG - 2011-04-09 04:37:32 --> Controller Class Initialized
DEBUG - 2011-04-09 04:37:32 --> Model Class Initialized
DEBUG - 2011-04-09 04:37:32 --> Model Class Initialized
DEBUG - 2011-04-09 04:37:32 --> Model Class Initialized
DEBUG - 2011-04-09 04:37:32 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-09 04:37:32 --> Database Driver Class Initialized
DEBUG - 2011-04-09 04:37:33 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-09 04:37:33 --> Helper loaded: url_helper
DEBUG - 2011-04-09 04:37:33 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-09 04:37:33 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-09 04:37:33 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-09 04:37:33 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-09 04:37:33 --> Final output sent to browser
DEBUG - 2011-04-09 04:37:33 --> Total execution time: 0.1979
DEBUG - 2011-04-09 04:37:34 --> Config Class Initialized
DEBUG - 2011-04-09 04:37:34 --> Hooks Class Initialized
DEBUG - 2011-04-09 04:37:34 --> Utf8 Class Initialized
DEBUG - 2011-04-09 04:37:34 --> UTF-8 Support Enabled
DEBUG - 2011-04-09 04:37:34 --> URI Class Initialized
DEBUG - 2011-04-09 04:37:34 --> Router Class Initialized
ERROR - 2011-04-09 04:37:34 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-04-09 04:37:35 --> Config Class Initialized
DEBUG - 2011-04-09 04:37:35 --> Hooks Class Initialized
DEBUG - 2011-04-09 04:37:35 --> Utf8 Class Initialized
DEBUG - 2011-04-09 04:37:35 --> UTF-8 Support Enabled
DEBUG - 2011-04-09 04:37:35 --> URI Class Initialized
DEBUG - 2011-04-09 04:37:35 --> Router Class Initialized
DEBUG - 2011-04-09 04:37:35 --> Output Class Initialized
DEBUG - 2011-04-09 04:37:35 --> Input Class Initialized
DEBUG - 2011-04-09 04:37:35 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-09 04:37:35 --> Language Class Initialized
DEBUG - 2011-04-09 04:37:35 --> Loader Class Initialized
DEBUG - 2011-04-09 04:37:35 --> Controller Class Initialized
DEBUG - 2011-04-09 04:37:35 --> Model Class Initialized
DEBUG - 2011-04-09 04:37:35 --> Model Class Initialized
DEBUG - 2011-04-09 04:37:35 --> Model Class Initialized
DEBUG - 2011-04-09 04:37:35 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-09 04:37:35 --> Database Driver Class Initialized
DEBUG - 2011-04-09 04:37:35 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-09 04:37:35 --> Helper loaded: url_helper
DEBUG - 2011-04-09 04:37:35 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-09 04:37:35 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-09 04:37:35 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-09 04:37:35 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-09 04:37:35 --> Final output sent to browser
DEBUG - 2011-04-09 04:37:35 --> Total execution time: 0.1317
DEBUG - 2011-04-09 04:37:35 --> Config Class Initialized
DEBUG - 2011-04-09 04:37:35 --> Hooks Class Initialized
DEBUG - 2011-04-09 04:37:35 --> Utf8 Class Initialized
DEBUG - 2011-04-09 04:37:35 --> UTF-8 Support Enabled
DEBUG - 2011-04-09 04:37:35 --> URI Class Initialized
DEBUG - 2011-04-09 04:37:35 --> Router Class Initialized
ERROR - 2011-04-09 04:37:35 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-09 04:37:40 --> Config Class Initialized
DEBUG - 2011-04-09 04:37:40 --> Hooks Class Initialized
DEBUG - 2011-04-09 04:37:40 --> Utf8 Class Initialized
DEBUG - 2011-04-09 04:37:40 --> UTF-8 Support Enabled
DEBUG - 2011-04-09 04:37:40 --> URI Class Initialized
DEBUG - 2011-04-09 04:37:40 --> Router Class Initialized
DEBUG - 2011-04-09 04:37:40 --> Output Class Initialized
DEBUG - 2011-04-09 04:37:40 --> Input Class Initialized
DEBUG - 2011-04-09 04:37:40 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-09 04:37:40 --> Language Class Initialized
DEBUG - 2011-04-09 04:37:40 --> Loader Class Initialized
DEBUG - 2011-04-09 04:37:40 --> Controller Class Initialized
DEBUG - 2011-04-09 04:37:40 --> Model Class Initialized
DEBUG - 2011-04-09 04:37:40 --> Model Class Initialized
DEBUG - 2011-04-09 04:37:40 --> Model Class Initialized
DEBUG - 2011-04-09 04:37:40 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-09 04:37:40 --> Database Driver Class Initialized
DEBUG - 2011-04-09 04:37:44 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-09 04:37:44 --> Helper loaded: url_helper
DEBUG - 2011-04-09 04:37:44 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-09 04:37:44 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-09 04:37:44 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-09 04:37:44 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-09 04:37:44 --> Final output sent to browser
DEBUG - 2011-04-09 04:37:44 --> Total execution time: 3.8612
DEBUG - 2011-04-09 04:37:45 --> Config Class Initialized
DEBUG - 2011-04-09 04:37:45 --> Hooks Class Initialized
DEBUG - 2011-04-09 04:37:45 --> Utf8 Class Initialized
DEBUG - 2011-04-09 04:37:45 --> UTF-8 Support Enabled
DEBUG - 2011-04-09 04:37:45 --> URI Class Initialized
DEBUG - 2011-04-09 04:37:45 --> Router Class Initialized
DEBUG - 2011-04-09 04:37:45 --> Output Class Initialized
DEBUG - 2011-04-09 04:37:45 --> Input Class Initialized
DEBUG - 2011-04-09 04:37:45 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-09 04:37:45 --> Language Class Initialized
DEBUG - 2011-04-09 04:37:45 --> Loader Class Initialized
DEBUG - 2011-04-09 04:37:45 --> Controller Class Initialized
DEBUG - 2011-04-09 04:37:45 --> Model Class Initialized
DEBUG - 2011-04-09 04:37:45 --> Model Class Initialized
DEBUG - 2011-04-09 04:37:45 --> Model Class Initialized
DEBUG - 2011-04-09 04:37:45 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-09 04:37:45 --> Database Driver Class Initialized
DEBUG - 2011-04-09 04:37:46 --> Config Class Initialized
DEBUG - 2011-04-09 04:37:46 --> Hooks Class Initialized
DEBUG - 2011-04-09 04:37:46 --> Utf8 Class Initialized
DEBUG - 2011-04-09 04:37:46 --> UTF-8 Support Enabled
DEBUG - 2011-04-09 04:37:46 --> URI Class Initialized
DEBUG - 2011-04-09 04:37:46 --> Router Class Initialized
ERROR - 2011-04-09 04:37:46 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-09 04:37:49 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-09 04:37:49 --> Helper loaded: url_helper
DEBUG - 2011-04-09 04:37:49 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-09 04:37:49 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-09 04:37:49 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-09 04:37:49 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-09 04:37:49 --> Final output sent to browser
DEBUG - 2011-04-09 04:37:49 --> Total execution time: 4.2920
DEBUG - 2011-04-09 04:37:51 --> Config Class Initialized
DEBUG - 2011-04-09 04:37:51 --> Hooks Class Initialized
DEBUG - 2011-04-09 04:37:51 --> Utf8 Class Initialized
DEBUG - 2011-04-09 04:37:51 --> UTF-8 Support Enabled
DEBUG - 2011-04-09 04:37:51 --> URI Class Initialized
DEBUG - 2011-04-09 04:37:51 --> Router Class Initialized
DEBUG - 2011-04-09 04:37:51 --> Output Class Initialized
DEBUG - 2011-04-09 04:37:51 --> Input Class Initialized
DEBUG - 2011-04-09 04:37:51 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-09 04:37:51 --> Language Class Initialized
DEBUG - 2011-04-09 04:37:51 --> Loader Class Initialized
DEBUG - 2011-04-09 04:37:51 --> Controller Class Initialized
DEBUG - 2011-04-09 04:37:51 --> Model Class Initialized
DEBUG - 2011-04-09 04:37:51 --> Model Class Initialized
DEBUG - 2011-04-09 04:37:51 --> Model Class Initialized
DEBUG - 2011-04-09 04:37:51 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-09 04:37:51 --> Database Driver Class Initialized
DEBUG - 2011-04-09 04:37:52 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-09 04:37:52 --> Helper loaded: url_helper
DEBUG - 2011-04-09 04:37:52 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-09 04:37:52 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-09 04:37:52 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-09 04:37:52 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-09 04:37:52 --> Final output sent to browser
DEBUG - 2011-04-09 04:37:52 --> Total execution time: 1.6672
DEBUG - 2011-04-09 04:37:54 --> Config Class Initialized
DEBUG - 2011-04-09 04:37:54 --> Hooks Class Initialized
DEBUG - 2011-04-09 04:37:54 --> Utf8 Class Initialized
DEBUG - 2011-04-09 04:37:54 --> UTF-8 Support Enabled
DEBUG - 2011-04-09 04:37:54 --> URI Class Initialized
DEBUG - 2011-04-09 04:37:54 --> Router Class Initialized
DEBUG - 2011-04-09 04:37:54 --> Output Class Initialized
DEBUG - 2011-04-09 04:37:54 --> Input Class Initialized
DEBUG - 2011-04-09 04:37:54 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-09 04:37:54 --> Language Class Initialized
DEBUG - 2011-04-09 04:37:54 --> Loader Class Initialized
DEBUG - 2011-04-09 04:37:54 --> Controller Class Initialized
DEBUG - 2011-04-09 04:37:54 --> Model Class Initialized
DEBUG - 2011-04-09 04:37:54 --> Model Class Initialized
DEBUG - 2011-04-09 04:37:54 --> Model Class Initialized
DEBUG - 2011-04-09 04:37:54 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-09 04:37:54 --> Database Driver Class Initialized
DEBUG - 2011-04-09 04:37:55 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-09 04:37:55 --> Helper loaded: url_helper
DEBUG - 2011-04-09 04:37:55 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-09 04:37:55 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-09 04:37:55 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-09 04:37:55 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-09 04:37:55 --> Final output sent to browser
DEBUG - 2011-04-09 04:37:55 --> Total execution time: 0.9310
DEBUG - 2011-04-09 04:37:57 --> Config Class Initialized
DEBUG - 2011-04-09 04:37:57 --> Hooks Class Initialized
DEBUG - 2011-04-09 04:37:57 --> Utf8 Class Initialized
DEBUG - 2011-04-09 04:37:57 --> UTF-8 Support Enabled
DEBUG - 2011-04-09 04:37:57 --> URI Class Initialized
DEBUG - 2011-04-09 04:37:57 --> Router Class Initialized
ERROR - 2011-04-09 04:37:57 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-09 04:37:57 --> Config Class Initialized
DEBUG - 2011-04-09 04:37:57 --> Hooks Class Initialized
DEBUG - 2011-04-09 04:37:57 --> Utf8 Class Initialized
DEBUG - 2011-04-09 04:37:57 --> UTF-8 Support Enabled
DEBUG - 2011-04-09 04:37:57 --> URI Class Initialized
DEBUG - 2011-04-09 04:37:57 --> Router Class Initialized
DEBUG - 2011-04-09 04:37:57 --> Output Class Initialized
DEBUG - 2011-04-09 04:37:57 --> Input Class Initialized
DEBUG - 2011-04-09 04:37:57 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-09 04:37:57 --> Language Class Initialized
DEBUG - 2011-04-09 04:37:57 --> Loader Class Initialized
DEBUG - 2011-04-09 04:37:57 --> Controller Class Initialized
DEBUG - 2011-04-09 04:37:57 --> Model Class Initialized
DEBUG - 2011-04-09 04:37:57 --> Model Class Initialized
DEBUG - 2011-04-09 04:37:57 --> Model Class Initialized
DEBUG - 2011-04-09 04:37:57 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-09 04:37:57 --> Database Driver Class Initialized
DEBUG - 2011-04-09 04:37:57 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-09 04:37:57 --> Helper loaded: url_helper
DEBUG - 2011-04-09 04:37:57 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-09 04:37:57 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-09 04:37:57 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-09 04:37:57 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-09 04:37:57 --> Final output sent to browser
DEBUG - 2011-04-09 04:37:57 --> Total execution time: 0.1350
DEBUG - 2011-04-09 04:38:02 --> Config Class Initialized
DEBUG - 2011-04-09 04:38:02 --> Hooks Class Initialized
DEBUG - 2011-04-09 04:38:02 --> Utf8 Class Initialized
DEBUG - 2011-04-09 04:38:02 --> UTF-8 Support Enabled
DEBUG - 2011-04-09 04:38:02 --> URI Class Initialized
DEBUG - 2011-04-09 04:38:02 --> Router Class Initialized
DEBUG - 2011-04-09 04:38:02 --> Output Class Initialized
DEBUG - 2011-04-09 04:38:02 --> Input Class Initialized
DEBUG - 2011-04-09 04:38:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-09 04:38:02 --> Language Class Initialized
DEBUG - 2011-04-09 04:38:02 --> Loader Class Initialized
DEBUG - 2011-04-09 04:38:02 --> Controller Class Initialized
DEBUG - 2011-04-09 04:38:02 --> Model Class Initialized
DEBUG - 2011-04-09 04:38:02 --> Model Class Initialized
DEBUG - 2011-04-09 04:38:02 --> Model Class Initialized
DEBUG - 2011-04-09 04:38:02 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-09 04:38:02 --> Database Driver Class Initialized
DEBUG - 2011-04-09 04:38:08 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-09 04:38:08 --> Helper loaded: url_helper
DEBUG - 2011-04-09 04:38:08 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-09 04:38:08 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-09 04:38:08 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-09 04:38:08 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-09 04:38:08 --> Final output sent to browser
DEBUG - 2011-04-09 04:38:08 --> Total execution time: 6.0942
DEBUG - 2011-04-09 04:38:09 --> Config Class Initialized
DEBUG - 2011-04-09 04:38:09 --> Hooks Class Initialized
DEBUG - 2011-04-09 04:38:09 --> Utf8 Class Initialized
DEBUG - 2011-04-09 04:38:09 --> UTF-8 Support Enabled
DEBUG - 2011-04-09 04:38:09 --> URI Class Initialized
DEBUG - 2011-04-09 04:38:09 --> Router Class Initialized
DEBUG - 2011-04-09 04:38:09 --> Output Class Initialized
DEBUG - 2011-04-09 04:38:09 --> Input Class Initialized
DEBUG - 2011-04-09 04:38:09 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-09 04:38:09 --> Language Class Initialized
DEBUG - 2011-04-09 04:38:09 --> Loader Class Initialized
DEBUG - 2011-04-09 04:38:09 --> Controller Class Initialized
DEBUG - 2011-04-09 04:38:09 --> Model Class Initialized
DEBUG - 2011-04-09 04:38:09 --> Model Class Initialized
DEBUG - 2011-04-09 04:38:09 --> Model Class Initialized
DEBUG - 2011-04-09 04:38:09 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-09 04:38:09 --> Database Driver Class Initialized
DEBUG - 2011-04-09 04:38:10 --> Config Class Initialized
DEBUG - 2011-04-09 04:38:10 --> Hooks Class Initialized
DEBUG - 2011-04-09 04:38:10 --> Utf8 Class Initialized
DEBUG - 2011-04-09 04:38:10 --> UTF-8 Support Enabled
DEBUG - 2011-04-09 04:38:10 --> URI Class Initialized
DEBUG - 2011-04-09 04:38:10 --> Router Class Initialized
ERROR - 2011-04-09 04:38:10 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-09 04:38:11 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-09 04:38:11 --> Helper loaded: url_helper
DEBUG - 2011-04-09 04:38:11 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-09 04:38:11 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-09 04:38:11 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-09 04:38:11 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-09 04:38:11 --> Final output sent to browser
DEBUG - 2011-04-09 04:38:11 --> Total execution time: 1.6129
DEBUG - 2011-04-09 04:38:19 --> Config Class Initialized
DEBUG - 2011-04-09 04:38:19 --> Hooks Class Initialized
DEBUG - 2011-04-09 04:38:19 --> Utf8 Class Initialized
DEBUG - 2011-04-09 04:38:19 --> UTF-8 Support Enabled
DEBUG - 2011-04-09 04:38:19 --> URI Class Initialized
DEBUG - 2011-04-09 04:38:19 --> Router Class Initialized
DEBUG - 2011-04-09 04:38:19 --> Output Class Initialized
DEBUG - 2011-04-09 04:38:19 --> Input Class Initialized
DEBUG - 2011-04-09 04:38:19 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-09 04:38:19 --> Language Class Initialized
DEBUG - 2011-04-09 04:38:19 --> Loader Class Initialized
DEBUG - 2011-04-09 04:38:19 --> Controller Class Initialized
DEBUG - 2011-04-09 04:38:19 --> Model Class Initialized
DEBUG - 2011-04-09 04:38:19 --> Model Class Initialized
DEBUG - 2011-04-09 04:38:19 --> Model Class Initialized
DEBUG - 2011-04-09 04:38:19 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-09 04:38:19 --> Database Driver Class Initialized
DEBUG - 2011-04-09 04:38:22 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-09 04:38:22 --> Helper loaded: url_helper
DEBUG - 2011-04-09 04:38:22 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-09 04:38:22 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-09 04:38:22 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-09 04:38:22 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-09 04:38:22 --> Final output sent to browser
DEBUG - 2011-04-09 04:38:22 --> Total execution time: 3.3306
DEBUG - 2011-04-09 04:38:23 --> Config Class Initialized
DEBUG - 2011-04-09 04:38:23 --> Hooks Class Initialized
DEBUG - 2011-04-09 04:38:23 --> Utf8 Class Initialized
DEBUG - 2011-04-09 04:38:23 --> UTF-8 Support Enabled
DEBUG - 2011-04-09 04:38:23 --> URI Class Initialized
DEBUG - 2011-04-09 04:38:23 --> Router Class Initialized
ERROR - 2011-04-09 04:38:23 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-09 04:38:28 --> Config Class Initialized
DEBUG - 2011-04-09 04:38:28 --> Hooks Class Initialized
DEBUG - 2011-04-09 04:38:28 --> Utf8 Class Initialized
DEBUG - 2011-04-09 04:38:28 --> UTF-8 Support Enabled
DEBUG - 2011-04-09 04:38:28 --> URI Class Initialized
DEBUG - 2011-04-09 04:38:28 --> Router Class Initialized
DEBUG - 2011-04-09 04:38:28 --> Output Class Initialized
DEBUG - 2011-04-09 04:38:28 --> Input Class Initialized
DEBUG - 2011-04-09 04:38:28 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-09 04:38:28 --> Language Class Initialized
DEBUG - 2011-04-09 04:38:28 --> Loader Class Initialized
DEBUG - 2011-04-09 04:38:28 --> Controller Class Initialized
DEBUG - 2011-04-09 04:38:28 --> Model Class Initialized
DEBUG - 2011-04-09 04:38:28 --> Model Class Initialized
DEBUG - 2011-04-09 04:38:28 --> Model Class Initialized
DEBUG - 2011-04-09 04:38:28 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-09 04:38:28 --> Database Driver Class Initialized
DEBUG - 2011-04-09 04:38:28 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-09 04:38:28 --> Helper loaded: url_helper
DEBUG - 2011-04-09 04:38:28 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-09 04:38:28 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-09 04:38:28 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-09 04:38:28 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-09 04:38:28 --> Final output sent to browser
DEBUG - 2011-04-09 04:38:28 --> Total execution time: 0.1126
DEBUG - 2011-04-09 04:38:31 --> Config Class Initialized
DEBUG - 2011-04-09 04:38:31 --> Hooks Class Initialized
DEBUG - 2011-04-09 04:38:31 --> Utf8 Class Initialized
DEBUG - 2011-04-09 04:38:31 --> UTF-8 Support Enabled
DEBUG - 2011-04-09 04:38:31 --> URI Class Initialized
DEBUG - 2011-04-09 04:38:31 --> Router Class Initialized
DEBUG - 2011-04-09 04:38:31 --> Output Class Initialized
DEBUG - 2011-04-09 04:38:31 --> Input Class Initialized
DEBUG - 2011-04-09 04:38:31 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-09 04:38:31 --> Language Class Initialized
DEBUG - 2011-04-09 04:38:31 --> Loader Class Initialized
DEBUG - 2011-04-09 04:38:31 --> Controller Class Initialized
DEBUG - 2011-04-09 04:38:31 --> Model Class Initialized
DEBUG - 2011-04-09 04:38:31 --> Model Class Initialized
DEBUG - 2011-04-09 04:38:31 --> Model Class Initialized
DEBUG - 2011-04-09 04:38:31 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-09 04:38:31 --> Database Driver Class Initialized
DEBUG - 2011-04-09 04:38:32 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-09 04:38:32 --> Helper loaded: url_helper
DEBUG - 2011-04-09 04:38:32 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-09 04:38:32 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-09 04:38:32 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-09 04:38:32 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-09 04:38:32 --> Final output sent to browser
DEBUG - 2011-04-09 04:38:32 --> Total execution time: 0.4418
DEBUG - 2011-04-09 04:38:34 --> Config Class Initialized
DEBUG - 2011-04-09 04:38:34 --> Hooks Class Initialized
DEBUG - 2011-04-09 04:38:34 --> Utf8 Class Initialized
DEBUG - 2011-04-09 04:38:34 --> UTF-8 Support Enabled
DEBUG - 2011-04-09 04:38:34 --> URI Class Initialized
DEBUG - 2011-04-09 04:38:34 --> Router Class Initialized
ERROR - 2011-04-09 04:38:34 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-09 04:38:35 --> Config Class Initialized
DEBUG - 2011-04-09 04:38:35 --> Hooks Class Initialized
DEBUG - 2011-04-09 04:38:35 --> Utf8 Class Initialized
DEBUG - 2011-04-09 04:38:35 --> UTF-8 Support Enabled
DEBUG - 2011-04-09 04:38:35 --> URI Class Initialized
DEBUG - 2011-04-09 04:38:35 --> Router Class Initialized
DEBUG - 2011-04-09 04:38:35 --> Output Class Initialized
DEBUG - 2011-04-09 04:38:35 --> Input Class Initialized
DEBUG - 2011-04-09 04:38:35 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-09 04:38:35 --> Language Class Initialized
DEBUG - 2011-04-09 04:38:35 --> Loader Class Initialized
DEBUG - 2011-04-09 04:38:35 --> Controller Class Initialized
DEBUG - 2011-04-09 04:38:35 --> Model Class Initialized
DEBUG - 2011-04-09 04:38:35 --> Model Class Initialized
DEBUG - 2011-04-09 04:38:35 --> Model Class Initialized
DEBUG - 2011-04-09 04:38:35 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-09 04:38:35 --> Database Driver Class Initialized
DEBUG - 2011-04-09 04:38:35 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-09 04:38:35 --> Helper loaded: url_helper
DEBUG - 2011-04-09 04:38:35 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-09 04:38:35 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-09 04:38:35 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-09 04:38:35 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-09 04:38:35 --> Final output sent to browser
DEBUG - 2011-04-09 04:38:35 --> Total execution time: 0.0587
DEBUG - 2011-04-09 04:38:40 --> Config Class Initialized
DEBUG - 2011-04-09 04:38:40 --> Hooks Class Initialized
DEBUG - 2011-04-09 04:38:40 --> Utf8 Class Initialized
DEBUG - 2011-04-09 04:38:40 --> UTF-8 Support Enabled
DEBUG - 2011-04-09 04:38:40 --> URI Class Initialized
DEBUG - 2011-04-09 04:38:40 --> Router Class Initialized
DEBUG - 2011-04-09 04:38:40 --> Output Class Initialized
DEBUG - 2011-04-09 04:38:40 --> Input Class Initialized
DEBUG - 2011-04-09 04:38:40 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-09 04:38:40 --> Language Class Initialized
DEBUG - 2011-04-09 04:38:40 --> Loader Class Initialized
DEBUG - 2011-04-09 04:38:40 --> Controller Class Initialized
DEBUG - 2011-04-09 04:38:40 --> Model Class Initialized
DEBUG - 2011-04-09 04:38:40 --> Model Class Initialized
DEBUG - 2011-04-09 04:38:40 --> Model Class Initialized
DEBUG - 2011-04-09 04:38:40 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-09 04:38:40 --> Database Driver Class Initialized
DEBUG - 2011-04-09 04:38:40 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-09 04:38:40 --> Helper loaded: url_helper
DEBUG - 2011-04-09 04:38:40 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-09 04:38:40 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-09 04:38:40 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-09 04:38:40 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-09 04:38:40 --> Final output sent to browser
DEBUG - 2011-04-09 04:38:40 --> Total execution time: 0.2858
DEBUG - 2011-04-09 04:38:41 --> Config Class Initialized
DEBUG - 2011-04-09 04:38:41 --> Hooks Class Initialized
DEBUG - 2011-04-09 04:38:41 --> Utf8 Class Initialized
DEBUG - 2011-04-09 04:38:41 --> UTF-8 Support Enabled
DEBUG - 2011-04-09 04:38:41 --> URI Class Initialized
DEBUG - 2011-04-09 04:38:41 --> Router Class Initialized
DEBUG - 2011-04-09 04:38:41 --> Output Class Initialized
DEBUG - 2011-04-09 04:38:41 --> Input Class Initialized
DEBUG - 2011-04-09 04:38:41 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-09 04:38:41 --> Language Class Initialized
DEBUG - 2011-04-09 04:38:41 --> Loader Class Initialized
DEBUG - 2011-04-09 04:38:41 --> Controller Class Initialized
DEBUG - 2011-04-09 04:38:41 --> Model Class Initialized
DEBUG - 2011-04-09 04:38:41 --> Model Class Initialized
DEBUG - 2011-04-09 04:38:41 --> Model Class Initialized
DEBUG - 2011-04-09 04:38:41 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-09 04:38:41 --> Database Driver Class Initialized
DEBUG - 2011-04-09 04:38:41 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-09 04:38:41 --> Helper loaded: url_helper
DEBUG - 2011-04-09 04:38:41 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-09 04:38:41 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-09 04:38:41 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-09 04:38:41 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-09 04:38:41 --> Final output sent to browser
DEBUG - 2011-04-09 04:38:41 --> Total execution time: 0.0455
DEBUG - 2011-04-09 04:38:41 --> Config Class Initialized
DEBUG - 2011-04-09 04:38:41 --> Hooks Class Initialized
DEBUG - 2011-04-09 04:38:41 --> Utf8 Class Initialized
DEBUG - 2011-04-09 04:38:41 --> UTF-8 Support Enabled
DEBUG - 2011-04-09 04:38:41 --> URI Class Initialized
DEBUG - 2011-04-09 04:38:41 --> Router Class Initialized
ERROR - 2011-04-09 04:38:41 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-09 04:38:45 --> Config Class Initialized
DEBUG - 2011-04-09 04:38:45 --> Hooks Class Initialized
DEBUG - 2011-04-09 04:38:45 --> Utf8 Class Initialized
DEBUG - 2011-04-09 04:38:45 --> UTF-8 Support Enabled
DEBUG - 2011-04-09 04:38:45 --> URI Class Initialized
DEBUG - 2011-04-09 04:38:45 --> Router Class Initialized
DEBUG - 2011-04-09 04:38:45 --> Output Class Initialized
DEBUG - 2011-04-09 04:38:45 --> Input Class Initialized
DEBUG - 2011-04-09 04:38:45 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-09 04:38:45 --> Language Class Initialized
DEBUG - 2011-04-09 04:38:45 --> Loader Class Initialized
DEBUG - 2011-04-09 04:38:45 --> Controller Class Initialized
DEBUG - 2011-04-09 04:38:45 --> Model Class Initialized
DEBUG - 2011-04-09 04:38:45 --> Model Class Initialized
DEBUG - 2011-04-09 04:38:45 --> Model Class Initialized
DEBUG - 2011-04-09 04:38:45 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-09 04:38:45 --> Database Driver Class Initialized
DEBUG - 2011-04-09 04:38:45 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-09 04:38:45 --> Helper loaded: url_helper
DEBUG - 2011-04-09 04:38:45 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-09 04:38:45 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-09 04:38:45 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-09 04:38:45 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-09 04:38:45 --> Final output sent to browser
DEBUG - 2011-04-09 04:38:45 --> Total execution time: 0.2587
DEBUG - 2011-04-09 04:38:46 --> Config Class Initialized
DEBUG - 2011-04-09 04:38:46 --> Hooks Class Initialized
DEBUG - 2011-04-09 04:38:46 --> Utf8 Class Initialized
DEBUG - 2011-04-09 04:38:46 --> UTF-8 Support Enabled
DEBUG - 2011-04-09 04:38:46 --> URI Class Initialized
DEBUG - 2011-04-09 04:38:46 --> Router Class Initialized
ERROR - 2011-04-09 04:38:46 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-09 04:38:49 --> Config Class Initialized
DEBUG - 2011-04-09 04:38:49 --> Hooks Class Initialized
DEBUG - 2011-04-09 04:38:49 --> Utf8 Class Initialized
DEBUG - 2011-04-09 04:38:49 --> UTF-8 Support Enabled
DEBUG - 2011-04-09 04:38:49 --> URI Class Initialized
DEBUG - 2011-04-09 04:38:49 --> Router Class Initialized
DEBUG - 2011-04-09 04:38:49 --> Output Class Initialized
DEBUG - 2011-04-09 04:38:49 --> Input Class Initialized
DEBUG - 2011-04-09 04:38:49 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-09 04:38:49 --> Language Class Initialized
DEBUG - 2011-04-09 04:38:49 --> Loader Class Initialized
DEBUG - 2011-04-09 04:38:49 --> Controller Class Initialized
DEBUG - 2011-04-09 04:38:49 --> Model Class Initialized
DEBUG - 2011-04-09 04:38:49 --> Model Class Initialized
DEBUG - 2011-04-09 04:38:49 --> Model Class Initialized
DEBUG - 2011-04-09 04:38:49 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-09 04:38:50 --> Database Driver Class Initialized
DEBUG - 2011-04-09 04:38:50 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-09 04:38:50 --> Helper loaded: url_helper
DEBUG - 2011-04-09 04:38:50 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-09 04:38:50 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-09 04:38:50 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-09 04:38:50 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-09 04:38:50 --> Final output sent to browser
DEBUG - 2011-04-09 04:38:50 --> Total execution time: 0.0473
DEBUG - 2011-04-09 05:24:20 --> Config Class Initialized
DEBUG - 2011-04-09 05:24:20 --> Hooks Class Initialized
DEBUG - 2011-04-09 05:24:21 --> Utf8 Class Initialized
DEBUG - 2011-04-09 05:24:21 --> UTF-8 Support Enabled
DEBUG - 2011-04-09 05:24:21 --> URI Class Initialized
DEBUG - 2011-04-09 05:24:21 --> Router Class Initialized
DEBUG - 2011-04-09 05:24:21 --> Output Class Initialized
DEBUG - 2011-04-09 05:24:21 --> Input Class Initialized
DEBUG - 2011-04-09 05:24:21 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-09 05:24:21 --> Language Class Initialized
DEBUG - 2011-04-09 05:24:21 --> Loader Class Initialized
DEBUG - 2011-04-09 05:24:21 --> Controller Class Initialized
DEBUG - 2011-04-09 05:24:21 --> Model Class Initialized
DEBUG - 2011-04-09 05:24:22 --> Model Class Initialized
DEBUG - 2011-04-09 05:24:22 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-09 05:24:23 --> Database Driver Class Initialized
DEBUG - 2011-04-09 05:24:25 --> Final output sent to browser
DEBUG - 2011-04-09 05:24:25 --> Total execution time: 4.9519
DEBUG - 2011-04-09 05:56:55 --> Config Class Initialized
DEBUG - 2011-04-09 05:56:55 --> Hooks Class Initialized
DEBUG - 2011-04-09 05:56:55 --> Utf8 Class Initialized
DEBUG - 2011-04-09 05:56:55 --> UTF-8 Support Enabled
DEBUG - 2011-04-09 05:56:55 --> URI Class Initialized
DEBUG - 2011-04-09 05:56:55 --> Router Class Initialized
DEBUG - 2011-04-09 05:56:55 --> No URI present. Default controller set.
DEBUG - 2011-04-09 05:56:55 --> Output Class Initialized
DEBUG - 2011-04-09 05:56:55 --> Input Class Initialized
DEBUG - 2011-04-09 05:56:55 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-09 05:56:55 --> Language Class Initialized
DEBUG - 2011-04-09 05:56:55 --> Loader Class Initialized
DEBUG - 2011-04-09 05:56:55 --> Controller Class Initialized
DEBUG - 2011-04-09 05:56:55 --> File loaded: application/views/splash/main.php
DEBUG - 2011-04-09 05:56:55 --> Helper loaded: url_helper
DEBUG - 2011-04-09 05:56:55 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-09 05:56:55 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-09 05:56:55 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-09 05:56:55 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-09 05:56:55 --> Final output sent to browser
DEBUG - 2011-04-09 05:56:55 --> Total execution time: 0.2069
DEBUG - 2011-04-09 05:56:58 --> Config Class Initialized
DEBUG - 2011-04-09 05:56:58 --> Hooks Class Initialized
DEBUG - 2011-04-09 05:56:58 --> Utf8 Class Initialized
DEBUG - 2011-04-09 05:56:58 --> UTF-8 Support Enabled
DEBUG - 2011-04-09 05:56:58 --> URI Class Initialized
DEBUG - 2011-04-09 05:56:58 --> Router Class Initialized
ERROR - 2011-04-09 05:56:58 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-09 05:56:59 --> Config Class Initialized
DEBUG - 2011-04-09 05:56:59 --> Hooks Class Initialized
DEBUG - 2011-04-09 05:56:59 --> Utf8 Class Initialized
DEBUG - 2011-04-09 05:56:59 --> UTF-8 Support Enabled
DEBUG - 2011-04-09 05:56:59 --> URI Class Initialized
DEBUG - 2011-04-09 05:56:59 --> Router Class Initialized
ERROR - 2011-04-09 05:56:59 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-09 05:57:05 --> Config Class Initialized
DEBUG - 2011-04-09 05:57:05 --> Hooks Class Initialized
DEBUG - 2011-04-09 05:57:05 --> Utf8 Class Initialized
DEBUG - 2011-04-09 05:57:05 --> UTF-8 Support Enabled
DEBUG - 2011-04-09 05:57:05 --> URI Class Initialized
DEBUG - 2011-04-09 05:57:05 --> Router Class Initialized
DEBUG - 2011-04-09 05:57:05 --> Output Class Initialized
DEBUG - 2011-04-09 05:57:05 --> Input Class Initialized
DEBUG - 2011-04-09 05:57:05 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-09 05:57:05 --> Language Class Initialized
DEBUG - 2011-04-09 05:57:05 --> Loader Class Initialized
DEBUG - 2011-04-09 05:57:05 --> Controller Class Initialized
DEBUG - 2011-04-09 05:57:05 --> Model Class Initialized
DEBUG - 2011-04-09 05:57:05 --> Model Class Initialized
DEBUG - 2011-04-09 05:57:05 --> Model Class Initialized
DEBUG - 2011-04-09 05:57:05 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-09 05:57:05 --> Database Driver Class Initialized
DEBUG - 2011-04-09 05:57:05 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-09 05:57:05 --> Helper loaded: url_helper
DEBUG - 2011-04-09 05:57:05 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-09 05:57:05 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-09 05:57:05 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-09 05:57:05 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-09 05:57:05 --> Final output sent to browser
DEBUG - 2011-04-09 05:57:05 --> Total execution time: 0.3554
DEBUG - 2011-04-09 05:57:28 --> Config Class Initialized
DEBUG - 2011-04-09 05:57:28 --> Hooks Class Initialized
DEBUG - 2011-04-09 05:57:28 --> Utf8 Class Initialized
DEBUG - 2011-04-09 05:57:28 --> UTF-8 Support Enabled
DEBUG - 2011-04-09 05:57:28 --> URI Class Initialized
DEBUG - 2011-04-09 05:57:28 --> Router Class Initialized
DEBUG - 2011-04-09 05:57:28 --> Output Class Initialized
DEBUG - 2011-04-09 05:57:28 --> Input Class Initialized
DEBUG - 2011-04-09 05:57:28 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-09 05:57:28 --> Language Class Initialized
DEBUG - 2011-04-09 05:57:28 --> Loader Class Initialized
DEBUG - 2011-04-09 05:57:28 --> Controller Class Initialized
DEBUG - 2011-04-09 05:57:28 --> Model Class Initialized
DEBUG - 2011-04-09 05:57:28 --> Model Class Initialized
DEBUG - 2011-04-09 05:57:28 --> Model Class Initialized
DEBUG - 2011-04-09 05:57:28 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-09 05:57:28 --> Database Driver Class Initialized
DEBUG - 2011-04-09 05:57:28 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-09 05:57:28 --> Helper loaded: url_helper
DEBUG - 2011-04-09 05:57:28 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-09 05:57:28 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-09 05:57:28 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-09 05:57:28 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-09 05:57:28 --> Final output sent to browser
DEBUG - 2011-04-09 05:57:28 --> Total execution time: 0.1777
DEBUG - 2011-04-09 05:57:30 --> Config Class Initialized
DEBUG - 2011-04-09 05:57:30 --> Hooks Class Initialized
DEBUG - 2011-04-09 05:57:30 --> Utf8 Class Initialized
DEBUG - 2011-04-09 05:57:30 --> UTF-8 Support Enabled
DEBUG - 2011-04-09 05:57:30 --> URI Class Initialized
DEBUG - 2011-04-09 05:57:30 --> Router Class Initialized
DEBUG - 2011-04-09 05:57:30 --> Output Class Initialized
DEBUG - 2011-04-09 05:57:30 --> Input Class Initialized
DEBUG - 2011-04-09 05:57:30 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-09 05:57:30 --> Language Class Initialized
DEBUG - 2011-04-09 05:57:30 --> Loader Class Initialized
DEBUG - 2011-04-09 05:57:30 --> Controller Class Initialized
DEBUG - 2011-04-09 05:57:30 --> Model Class Initialized
DEBUG - 2011-04-09 05:57:30 --> Model Class Initialized
DEBUG - 2011-04-09 05:57:30 --> Model Class Initialized
DEBUG - 2011-04-09 05:57:30 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-09 05:57:30 --> Database Driver Class Initialized
DEBUG - 2011-04-09 05:57:30 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-09 05:57:30 --> Helper loaded: url_helper
DEBUG - 2011-04-09 05:57:30 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-09 05:57:30 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-09 05:57:30 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-09 05:57:30 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-09 05:57:30 --> Final output sent to browser
DEBUG - 2011-04-09 05:57:30 --> Total execution time: 0.0410
DEBUG - 2011-04-09 07:20:12 --> Config Class Initialized
DEBUG - 2011-04-09 07:20:12 --> Hooks Class Initialized
DEBUG - 2011-04-09 07:20:12 --> Utf8 Class Initialized
DEBUG - 2011-04-09 07:20:12 --> UTF-8 Support Enabled
DEBUG - 2011-04-09 07:20:12 --> URI Class Initialized
DEBUG - 2011-04-09 07:20:12 --> Router Class Initialized
DEBUG - 2011-04-09 07:20:12 --> Output Class Initialized
DEBUG - 2011-04-09 07:20:12 --> Input Class Initialized
DEBUG - 2011-04-09 07:20:12 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-09 07:20:12 --> Language Class Initialized
DEBUG - 2011-04-09 07:20:12 --> Loader Class Initialized
DEBUG - 2011-04-09 07:20:13 --> Controller Class Initialized
DEBUG - 2011-04-09 07:20:13 --> Model Class Initialized
DEBUG - 2011-04-09 07:20:13 --> Model Class Initialized
DEBUG - 2011-04-09 07:20:13 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-09 07:20:13 --> Database Driver Class Initialized
DEBUG - 2011-04-09 07:20:13 --> Final output sent to browser
DEBUG - 2011-04-09 07:20:13 --> Total execution time: 0.9743
DEBUG - 2011-04-09 07:36:00 --> Config Class Initialized
DEBUG - 2011-04-09 07:36:00 --> Hooks Class Initialized
DEBUG - 2011-04-09 07:36:00 --> Utf8 Class Initialized
DEBUG - 2011-04-09 07:36:00 --> UTF-8 Support Enabled
DEBUG - 2011-04-09 07:36:00 --> URI Class Initialized
DEBUG - 2011-04-09 07:36:00 --> Router Class Initialized
DEBUG - 2011-04-09 07:36:00 --> Output Class Initialized
DEBUG - 2011-04-09 07:36:00 --> Input Class Initialized
DEBUG - 2011-04-09 07:36:00 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-09 07:36:00 --> Language Class Initialized
DEBUG - 2011-04-09 07:36:00 --> Loader Class Initialized
DEBUG - 2011-04-09 07:36:00 --> Controller Class Initialized
DEBUG - 2011-04-09 07:36:00 --> Model Class Initialized
DEBUG - 2011-04-09 07:36:00 --> Model Class Initialized
DEBUG - 2011-04-09 07:36:00 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-09 07:36:00 --> Database Driver Class Initialized
DEBUG - 2011-04-09 07:36:00 --> Final output sent to browser
DEBUG - 2011-04-09 07:36:00 --> Total execution time: 0.6869
DEBUG - 2011-04-09 11:16:06 --> Config Class Initialized
DEBUG - 2011-04-09 11:16:06 --> Hooks Class Initialized
DEBUG - 2011-04-09 11:16:06 --> Utf8 Class Initialized
DEBUG - 2011-04-09 11:16:06 --> UTF-8 Support Enabled
DEBUG - 2011-04-09 11:16:06 --> URI Class Initialized
DEBUG - 2011-04-09 11:16:06 --> Router Class Initialized
ERROR - 2011-04-09 11:16:07 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-04-09 11:16:07 --> Config Class Initialized
DEBUG - 2011-04-09 11:16:07 --> Hooks Class Initialized
DEBUG - 2011-04-09 11:16:07 --> Utf8 Class Initialized
DEBUG - 2011-04-09 11:16:07 --> UTF-8 Support Enabled
DEBUG - 2011-04-09 11:16:07 --> URI Class Initialized
DEBUG - 2011-04-09 11:16:07 --> Router Class Initialized
DEBUG - 2011-04-09 11:16:08 --> Output Class Initialized
DEBUG - 2011-04-09 11:16:08 --> Input Class Initialized
DEBUG - 2011-04-09 11:16:08 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-09 11:16:08 --> Language Class Initialized
DEBUG - 2011-04-09 11:16:08 --> Loader Class Initialized
DEBUG - 2011-04-09 11:16:08 --> Controller Class Initialized
ERROR - 2011-04-09 11:16:08 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-09 11:16:08 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-09 11:16:08 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-09 11:16:08 --> Model Class Initialized
DEBUG - 2011-04-09 11:16:08 --> Model Class Initialized
DEBUG - 2011-04-09 11:16:09 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-09 11:16:09 --> Database Driver Class Initialized
DEBUG - 2011-04-09 11:16:09 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-09 11:16:10 --> Helper loaded: url_helper
DEBUG - 2011-04-09 11:16:10 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-09 11:16:10 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-09 11:16:10 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-09 11:16:10 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-09 11:16:10 --> Final output sent to browser
DEBUG - 2011-04-09 11:16:10 --> Total execution time: 2.5088
DEBUG - 2011-04-09 11:16:40 --> Config Class Initialized
DEBUG - 2011-04-09 11:16:40 --> Hooks Class Initialized
DEBUG - 2011-04-09 11:16:40 --> Utf8 Class Initialized
DEBUG - 2011-04-09 11:16:40 --> UTF-8 Support Enabled
DEBUG - 2011-04-09 11:16:40 --> URI Class Initialized
DEBUG - 2011-04-09 11:16:40 --> Router Class Initialized
DEBUG - 2011-04-09 11:16:40 --> Output Class Initialized
DEBUG - 2011-04-09 11:16:40 --> Input Class Initialized
DEBUG - 2011-04-09 11:16:40 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-09 11:16:40 --> Language Class Initialized
DEBUG - 2011-04-09 11:16:40 --> Loader Class Initialized
DEBUG - 2011-04-09 11:16:40 --> Controller Class Initialized
DEBUG - 2011-04-09 11:16:40 --> Model Class Initialized
DEBUG - 2011-04-09 11:16:40 --> Model Class Initialized
DEBUG - 2011-04-09 11:16:40 --> Model Class Initialized
DEBUG - 2011-04-09 11:16:40 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-09 11:16:40 --> Database Driver Class Initialized
DEBUG - 2011-04-09 11:16:41 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-09 11:16:41 --> Helper loaded: url_helper
DEBUG - 2011-04-09 11:16:41 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-09 11:16:41 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-09 11:16:41 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-09 11:16:41 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-09 11:16:41 --> Final output sent to browser
DEBUG - 2011-04-09 11:16:41 --> Total execution time: 0.3085
DEBUG - 2011-04-09 11:18:13 --> Config Class Initialized
DEBUG - 2011-04-09 11:18:13 --> Hooks Class Initialized
DEBUG - 2011-04-09 11:18:13 --> Utf8 Class Initialized
DEBUG - 2011-04-09 11:18:13 --> UTF-8 Support Enabled
DEBUG - 2011-04-09 11:18:13 --> URI Class Initialized
DEBUG - 2011-04-09 11:18:13 --> Router Class Initialized
DEBUG - 2011-04-09 11:18:13 --> No URI present. Default controller set.
DEBUG - 2011-04-09 11:18:13 --> Output Class Initialized
DEBUG - 2011-04-09 11:18:13 --> Input Class Initialized
DEBUG - 2011-04-09 11:18:13 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-09 11:18:13 --> Language Class Initialized
DEBUG - 2011-04-09 11:18:13 --> Loader Class Initialized
DEBUG - 2011-04-09 11:18:13 --> Controller Class Initialized
DEBUG - 2011-04-09 11:18:13 --> File loaded: application/views/splash/main.php
DEBUG - 2011-04-09 11:18:13 --> Helper loaded: url_helper
DEBUG - 2011-04-09 11:18:13 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-09 11:18:13 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-09 11:18:13 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-09 11:18:13 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-09 11:18:13 --> Final output sent to browser
DEBUG - 2011-04-09 11:18:13 --> Total execution time: 0.0503
DEBUG - 2011-04-09 11:58:54 --> Config Class Initialized
DEBUG - 2011-04-09 11:58:54 --> Hooks Class Initialized
DEBUG - 2011-04-09 11:58:54 --> Utf8 Class Initialized
DEBUG - 2011-04-09 11:58:54 --> UTF-8 Support Enabled
DEBUG - 2011-04-09 11:58:54 --> URI Class Initialized
DEBUG - 2011-04-09 11:58:54 --> Router Class Initialized
DEBUG - 2011-04-09 11:58:54 --> Output Class Initialized
DEBUG - 2011-04-09 11:58:54 --> Input Class Initialized
DEBUG - 2011-04-09 11:58:54 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-09 11:58:54 --> Language Class Initialized
DEBUG - 2011-04-09 11:58:54 --> Loader Class Initialized
DEBUG - 2011-04-09 11:58:54 --> Controller Class Initialized
ERROR - 2011-04-09 11:58:54 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-09 11:58:54 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-09 11:58:54 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-09 11:58:54 --> Model Class Initialized
DEBUG - 2011-04-09 11:58:54 --> Model Class Initialized
DEBUG - 2011-04-09 11:58:54 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-09 11:58:54 --> Database Driver Class Initialized
DEBUG - 2011-04-09 11:58:54 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-09 11:58:54 --> Helper loaded: url_helper
DEBUG - 2011-04-09 11:58:54 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-09 11:58:54 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-09 11:58:54 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-09 11:58:54 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-09 11:58:54 --> Final output sent to browser
DEBUG - 2011-04-09 11:58:54 --> Total execution time: 0.3935
DEBUG - 2011-04-09 11:58:56 --> Config Class Initialized
DEBUG - 2011-04-09 11:58:56 --> Hooks Class Initialized
DEBUG - 2011-04-09 11:58:56 --> Utf8 Class Initialized
DEBUG - 2011-04-09 11:58:56 --> UTF-8 Support Enabled
DEBUG - 2011-04-09 11:58:56 --> URI Class Initialized
DEBUG - 2011-04-09 11:58:56 --> Router Class Initialized
DEBUG - 2011-04-09 11:58:56 --> Output Class Initialized
DEBUG - 2011-04-09 11:58:56 --> Input Class Initialized
DEBUG - 2011-04-09 11:58:56 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-09 11:58:56 --> Language Class Initialized
DEBUG - 2011-04-09 11:58:56 --> Loader Class Initialized
DEBUG - 2011-04-09 11:58:56 --> Controller Class Initialized
DEBUG - 2011-04-09 11:58:56 --> Model Class Initialized
DEBUG - 2011-04-09 11:58:56 --> Model Class Initialized
DEBUG - 2011-04-09 11:58:56 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-09 11:58:56 --> Database Driver Class Initialized
DEBUG - 2011-04-09 11:58:56 --> Final output sent to browser
DEBUG - 2011-04-09 11:58:56 --> Total execution time: 0.9173
DEBUG - 2011-04-09 11:58:58 --> Config Class Initialized
DEBUG - 2011-04-09 11:58:58 --> Hooks Class Initialized
DEBUG - 2011-04-09 11:58:58 --> Utf8 Class Initialized
DEBUG - 2011-04-09 11:58:58 --> UTF-8 Support Enabled
DEBUG - 2011-04-09 11:58:58 --> URI Class Initialized
DEBUG - 2011-04-09 11:58:58 --> Router Class Initialized
ERROR - 2011-04-09 11:58:58 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-09 11:59:06 --> Config Class Initialized
DEBUG - 2011-04-09 11:59:06 --> Hooks Class Initialized
DEBUG - 2011-04-09 11:59:06 --> Utf8 Class Initialized
DEBUG - 2011-04-09 11:59:06 --> UTF-8 Support Enabled
DEBUG - 2011-04-09 11:59:06 --> URI Class Initialized
DEBUG - 2011-04-09 11:59:06 --> Router Class Initialized
DEBUG - 2011-04-09 11:59:06 --> Output Class Initialized
DEBUG - 2011-04-09 11:59:06 --> Input Class Initialized
DEBUG - 2011-04-09 11:59:06 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-09 11:59:06 --> Language Class Initialized
DEBUG - 2011-04-09 11:59:06 --> Loader Class Initialized
DEBUG - 2011-04-09 11:59:06 --> Controller Class Initialized
DEBUG - 2011-04-09 11:59:06 --> Model Class Initialized
DEBUG - 2011-04-09 11:59:06 --> Model Class Initialized
DEBUG - 2011-04-09 11:59:06 --> Model Class Initialized
DEBUG - 2011-04-09 11:59:06 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-09 11:59:06 --> Database Driver Class Initialized
DEBUG - 2011-04-09 11:59:06 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-09 11:59:06 --> Helper loaded: url_helper
DEBUG - 2011-04-09 11:59:06 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-09 11:59:06 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-09 11:59:06 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-09 11:59:06 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-09 11:59:06 --> Final output sent to browser
DEBUG - 2011-04-09 11:59:06 --> Total execution time: 0.3384
DEBUG - 2011-04-09 11:59:08 --> Config Class Initialized
DEBUG - 2011-04-09 11:59:08 --> Hooks Class Initialized
DEBUG - 2011-04-09 11:59:08 --> Utf8 Class Initialized
DEBUG - 2011-04-09 11:59:08 --> UTF-8 Support Enabled
DEBUG - 2011-04-09 11:59:08 --> URI Class Initialized
DEBUG - 2011-04-09 11:59:08 --> Router Class Initialized
ERROR - 2011-04-09 11:59:08 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-09 11:59:08 --> Config Class Initialized
DEBUG - 2011-04-09 11:59:08 --> Hooks Class Initialized
DEBUG - 2011-04-09 11:59:08 --> Utf8 Class Initialized
DEBUG - 2011-04-09 11:59:08 --> UTF-8 Support Enabled
DEBUG - 2011-04-09 11:59:08 --> URI Class Initialized
DEBUG - 2011-04-09 11:59:08 --> Router Class Initialized
ERROR - 2011-04-09 11:59:08 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-09 11:59:20 --> Config Class Initialized
DEBUG - 2011-04-09 11:59:20 --> Hooks Class Initialized
DEBUG - 2011-04-09 11:59:20 --> Utf8 Class Initialized
DEBUG - 2011-04-09 11:59:20 --> UTF-8 Support Enabled
DEBUG - 2011-04-09 11:59:20 --> URI Class Initialized
DEBUG - 2011-04-09 11:59:20 --> Router Class Initialized
DEBUG - 2011-04-09 11:59:20 --> Output Class Initialized
DEBUG - 2011-04-09 11:59:20 --> Input Class Initialized
DEBUG - 2011-04-09 11:59:20 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-09 11:59:20 --> Language Class Initialized
DEBUG - 2011-04-09 11:59:20 --> Loader Class Initialized
DEBUG - 2011-04-09 11:59:20 --> Controller Class Initialized
DEBUG - 2011-04-09 11:59:20 --> Model Class Initialized
DEBUG - 2011-04-09 11:59:20 --> Model Class Initialized
DEBUG - 2011-04-09 11:59:20 --> Model Class Initialized
DEBUG - 2011-04-09 11:59:20 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-09 11:59:20 --> Database Driver Class Initialized
DEBUG - 2011-04-09 11:59:21 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-09 11:59:21 --> Helper loaded: url_helper
DEBUG - 2011-04-09 11:59:21 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-09 11:59:21 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-09 11:59:21 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-09 11:59:21 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-09 11:59:21 --> Final output sent to browser
DEBUG - 2011-04-09 11:59:21 --> Total execution time: 0.1913
DEBUG - 2011-04-09 11:59:22 --> Config Class Initialized
DEBUG - 2011-04-09 11:59:22 --> Hooks Class Initialized
DEBUG - 2011-04-09 11:59:22 --> Utf8 Class Initialized
DEBUG - 2011-04-09 11:59:22 --> UTF-8 Support Enabled
DEBUG - 2011-04-09 11:59:22 --> URI Class Initialized
DEBUG - 2011-04-09 11:59:22 --> Router Class Initialized
DEBUG - 2011-04-09 11:59:22 --> Output Class Initialized
DEBUG - 2011-04-09 11:59:22 --> Input Class Initialized
DEBUG - 2011-04-09 11:59:22 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-09 11:59:22 --> Language Class Initialized
DEBUG - 2011-04-09 11:59:22 --> Loader Class Initialized
DEBUG - 2011-04-09 11:59:22 --> Controller Class Initialized
DEBUG - 2011-04-09 11:59:22 --> Model Class Initialized
DEBUG - 2011-04-09 11:59:22 --> Model Class Initialized
DEBUG - 2011-04-09 11:59:22 --> Model Class Initialized
DEBUG - 2011-04-09 11:59:22 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-09 11:59:22 --> Database Driver Class Initialized
DEBUG - 2011-04-09 11:59:22 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-09 11:59:22 --> Helper loaded: url_helper
DEBUG - 2011-04-09 11:59:22 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-09 11:59:22 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-09 11:59:22 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-09 11:59:22 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-09 11:59:22 --> Final output sent to browser
DEBUG - 2011-04-09 11:59:22 --> Total execution time: 0.0423
DEBUG - 2011-04-09 11:59:22 --> Config Class Initialized
DEBUG - 2011-04-09 11:59:22 --> Hooks Class Initialized
DEBUG - 2011-04-09 11:59:22 --> Utf8 Class Initialized
DEBUG - 2011-04-09 11:59:22 --> UTF-8 Support Enabled
DEBUG - 2011-04-09 11:59:22 --> URI Class Initialized
DEBUG - 2011-04-09 11:59:22 --> Router Class Initialized
ERROR - 2011-04-09 11:59:22 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-09 11:59:38 --> Config Class Initialized
DEBUG - 2011-04-09 11:59:38 --> Hooks Class Initialized
DEBUG - 2011-04-09 11:59:38 --> Utf8 Class Initialized
DEBUG - 2011-04-09 11:59:38 --> UTF-8 Support Enabled
DEBUG - 2011-04-09 11:59:38 --> URI Class Initialized
DEBUG - 2011-04-09 11:59:38 --> Router Class Initialized
DEBUG - 2011-04-09 11:59:38 --> Output Class Initialized
DEBUG - 2011-04-09 11:59:38 --> Input Class Initialized
DEBUG - 2011-04-09 11:59:38 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-09 11:59:38 --> Language Class Initialized
DEBUG - 2011-04-09 11:59:38 --> Loader Class Initialized
DEBUG - 2011-04-09 11:59:38 --> Controller Class Initialized
DEBUG - 2011-04-09 11:59:38 --> Model Class Initialized
DEBUG - 2011-04-09 11:59:38 --> Model Class Initialized
DEBUG - 2011-04-09 11:59:38 --> Model Class Initialized
DEBUG - 2011-04-09 11:59:38 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-09 11:59:38 --> Database Driver Class Initialized
DEBUG - 2011-04-09 11:59:39 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-09 11:59:39 --> Helper loaded: url_helper
DEBUG - 2011-04-09 11:59:39 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-09 11:59:39 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-09 11:59:39 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-09 11:59:39 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-09 11:59:39 --> Final output sent to browser
DEBUG - 2011-04-09 11:59:39 --> Total execution time: 0.5540
DEBUG - 2011-04-09 11:59:40 --> Config Class Initialized
DEBUG - 2011-04-09 11:59:40 --> Hooks Class Initialized
DEBUG - 2011-04-09 11:59:40 --> Utf8 Class Initialized
DEBUG - 2011-04-09 11:59:40 --> UTF-8 Support Enabled
DEBUG - 2011-04-09 11:59:40 --> URI Class Initialized
DEBUG - 2011-04-09 11:59:40 --> Router Class Initialized
ERROR - 2011-04-09 11:59:40 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-09 11:59:42 --> Config Class Initialized
DEBUG - 2011-04-09 11:59:42 --> Hooks Class Initialized
DEBUG - 2011-04-09 11:59:42 --> Utf8 Class Initialized
DEBUG - 2011-04-09 11:59:42 --> UTF-8 Support Enabled
DEBUG - 2011-04-09 11:59:42 --> URI Class Initialized
DEBUG - 2011-04-09 11:59:42 --> Router Class Initialized
DEBUG - 2011-04-09 11:59:42 --> Output Class Initialized
DEBUG - 2011-04-09 11:59:42 --> Input Class Initialized
DEBUG - 2011-04-09 11:59:42 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-09 11:59:42 --> Language Class Initialized
DEBUG - 2011-04-09 11:59:42 --> Loader Class Initialized
DEBUG - 2011-04-09 11:59:42 --> Controller Class Initialized
DEBUG - 2011-04-09 11:59:42 --> Model Class Initialized
DEBUG - 2011-04-09 11:59:42 --> Model Class Initialized
DEBUG - 2011-04-09 11:59:42 --> Model Class Initialized
DEBUG - 2011-04-09 11:59:42 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-09 11:59:42 --> Database Driver Class Initialized
DEBUG - 2011-04-09 11:59:42 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-09 11:59:42 --> Helper loaded: url_helper
DEBUG - 2011-04-09 11:59:42 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-09 11:59:42 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-09 11:59:42 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-09 11:59:42 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-09 11:59:42 --> Final output sent to browser
DEBUG - 2011-04-09 11:59:42 --> Total execution time: 0.0472
DEBUG - 2011-04-09 12:00:12 --> Config Class Initialized
DEBUG - 2011-04-09 12:00:12 --> Hooks Class Initialized
DEBUG - 2011-04-09 12:00:12 --> Utf8 Class Initialized
DEBUG - 2011-04-09 12:00:12 --> UTF-8 Support Enabled
DEBUG - 2011-04-09 12:00:12 --> URI Class Initialized
DEBUG - 2011-04-09 12:00:12 --> Router Class Initialized
DEBUG - 2011-04-09 12:00:12 --> Output Class Initialized
DEBUG - 2011-04-09 12:00:12 --> Input Class Initialized
DEBUG - 2011-04-09 12:00:12 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-09 12:00:12 --> Language Class Initialized
DEBUG - 2011-04-09 12:00:12 --> Loader Class Initialized
DEBUG - 2011-04-09 12:00:12 --> Controller Class Initialized
DEBUG - 2011-04-09 12:00:12 --> Model Class Initialized
DEBUG - 2011-04-09 12:00:12 --> Model Class Initialized
DEBUG - 2011-04-09 12:00:12 --> Model Class Initialized
DEBUG - 2011-04-09 12:00:12 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-09 12:00:12 --> Database Driver Class Initialized
DEBUG - 2011-04-09 12:00:14 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-09 12:00:14 --> Helper loaded: url_helper
DEBUG - 2011-04-09 12:00:14 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-09 12:00:14 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-09 12:00:14 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-09 12:00:14 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-09 12:00:14 --> Final output sent to browser
DEBUG - 2011-04-09 12:00:14 --> Total execution time: 2.0253
DEBUG - 2011-04-09 12:00:16 --> Config Class Initialized
DEBUG - 2011-04-09 12:00:16 --> Hooks Class Initialized
DEBUG - 2011-04-09 12:00:16 --> Utf8 Class Initialized
DEBUG - 2011-04-09 12:00:16 --> UTF-8 Support Enabled
DEBUG - 2011-04-09 12:00:16 --> URI Class Initialized
DEBUG - 2011-04-09 12:00:16 --> Router Class Initialized
ERROR - 2011-04-09 12:00:16 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-09 12:00:17 --> Config Class Initialized
DEBUG - 2011-04-09 12:00:17 --> Hooks Class Initialized
DEBUG - 2011-04-09 12:00:17 --> Utf8 Class Initialized
DEBUG - 2011-04-09 12:00:17 --> UTF-8 Support Enabled
DEBUG - 2011-04-09 12:00:17 --> URI Class Initialized
DEBUG - 2011-04-09 12:00:17 --> Router Class Initialized
DEBUG - 2011-04-09 12:00:17 --> Output Class Initialized
DEBUG - 2011-04-09 12:00:17 --> Input Class Initialized
DEBUG - 2011-04-09 12:00:17 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-09 12:00:17 --> Language Class Initialized
DEBUG - 2011-04-09 12:00:17 --> Loader Class Initialized
DEBUG - 2011-04-09 12:00:17 --> Controller Class Initialized
DEBUG - 2011-04-09 12:00:17 --> Model Class Initialized
DEBUG - 2011-04-09 12:00:17 --> Model Class Initialized
DEBUG - 2011-04-09 12:00:17 --> Model Class Initialized
DEBUG - 2011-04-09 12:00:17 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-09 12:00:17 --> Database Driver Class Initialized
DEBUG - 2011-04-09 12:00:17 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-09 12:00:17 --> Helper loaded: url_helper
DEBUG - 2011-04-09 12:00:17 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-09 12:00:17 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-09 12:00:17 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-09 12:00:17 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-09 12:00:17 --> Final output sent to browser
DEBUG - 2011-04-09 12:00:17 --> Total execution time: 0.0495
DEBUG - 2011-04-09 12:30:48 --> Config Class Initialized
DEBUG - 2011-04-09 12:30:48 --> Hooks Class Initialized
DEBUG - 2011-04-09 12:30:48 --> Utf8 Class Initialized
DEBUG - 2011-04-09 12:30:48 --> UTF-8 Support Enabled
DEBUG - 2011-04-09 12:30:48 --> URI Class Initialized
DEBUG - 2011-04-09 12:30:48 --> Router Class Initialized
ERROR - 2011-04-09 12:30:48 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-04-09 12:55:24 --> Config Class Initialized
DEBUG - 2011-04-09 12:55:24 --> Hooks Class Initialized
DEBUG - 2011-04-09 12:55:24 --> Utf8 Class Initialized
DEBUG - 2011-04-09 12:55:24 --> UTF-8 Support Enabled
DEBUG - 2011-04-09 12:55:24 --> URI Class Initialized
DEBUG - 2011-04-09 12:55:24 --> Router Class Initialized
DEBUG - 2011-04-09 12:55:24 --> Output Class Initialized
DEBUG - 2011-04-09 12:55:24 --> Input Class Initialized
DEBUG - 2011-04-09 12:55:24 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-09 12:55:24 --> Language Class Initialized
DEBUG - 2011-04-09 12:55:24 --> Loader Class Initialized
DEBUG - 2011-04-09 12:55:24 --> Controller Class Initialized
DEBUG - 2011-04-09 12:55:24 --> Model Class Initialized
DEBUG - 2011-04-09 12:55:24 --> Model Class Initialized
DEBUG - 2011-04-09 12:55:24 --> Model Class Initialized
DEBUG - 2011-04-09 12:55:24 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-09 12:55:24 --> Database Driver Class Initialized
DEBUG - 2011-04-09 12:55:24 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-09 12:55:24 --> Helper loaded: url_helper
DEBUG - 2011-04-09 12:55:24 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-09 12:55:24 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-09 12:55:24 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-09 12:55:24 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-09 12:55:24 --> Final output sent to browser
DEBUG - 2011-04-09 12:55:24 --> Total execution time: 0.8334
DEBUG - 2011-04-09 15:27:57 --> Config Class Initialized
DEBUG - 2011-04-09 15:27:57 --> Hooks Class Initialized
DEBUG - 2011-04-09 15:27:57 --> Utf8 Class Initialized
DEBUG - 2011-04-09 15:27:57 --> UTF-8 Support Enabled
DEBUG - 2011-04-09 15:27:57 --> URI Class Initialized
DEBUG - 2011-04-09 15:27:57 --> Router Class Initialized
DEBUG - 2011-04-09 15:27:57 --> No URI present. Default controller set.
DEBUG - 2011-04-09 15:27:57 --> Output Class Initialized
DEBUG - 2011-04-09 15:27:57 --> Input Class Initialized
DEBUG - 2011-04-09 15:27:57 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-09 15:27:57 --> Language Class Initialized
DEBUG - 2011-04-09 15:27:57 --> Loader Class Initialized
DEBUG - 2011-04-09 15:27:57 --> Controller Class Initialized
DEBUG - 2011-04-09 15:27:57 --> File loaded: application/views/splash/main.php
DEBUG - 2011-04-09 15:27:57 --> Helper loaded: url_helper
DEBUG - 2011-04-09 15:27:57 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-09 15:27:57 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-09 15:27:57 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-09 15:27:57 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-09 15:27:57 --> Final output sent to browser
DEBUG - 2011-04-09 15:27:57 --> Total execution time: 0.2691
DEBUG - 2011-04-09 15:30:00 --> Config Class Initialized
DEBUG - 2011-04-09 15:30:00 --> Hooks Class Initialized
DEBUG - 2011-04-09 15:30:00 --> Utf8 Class Initialized
DEBUG - 2011-04-09 15:30:00 --> UTF-8 Support Enabled
DEBUG - 2011-04-09 15:30:00 --> URI Class Initialized
DEBUG - 2011-04-09 15:30:00 --> Router Class Initialized
DEBUG - 2011-04-09 15:30:00 --> Output Class Initialized
DEBUG - 2011-04-09 15:30:00 --> Input Class Initialized
DEBUG - 2011-04-09 15:30:00 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-09 15:30:00 --> Language Class Initialized
DEBUG - 2011-04-09 15:30:00 --> Loader Class Initialized
DEBUG - 2011-04-09 15:30:00 --> Controller Class Initialized
ERROR - 2011-04-09 15:30:00 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-09 15:30:00 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-09 15:30:00 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-09 15:30:00 --> Model Class Initialized
DEBUG - 2011-04-09 15:30:00 --> Model Class Initialized
DEBUG - 2011-04-09 15:30:00 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-09 15:30:00 --> Database Driver Class Initialized
DEBUG - 2011-04-09 15:30:00 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-09 15:30:00 --> Helper loaded: url_helper
DEBUG - 2011-04-09 15:30:00 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-09 15:30:00 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-09 15:30:00 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-09 15:30:00 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-09 15:30:00 --> Final output sent to browser
DEBUG - 2011-04-09 15:30:00 --> Total execution time: 0.1726
DEBUG - 2011-04-09 15:30:02 --> Config Class Initialized
DEBUG - 2011-04-09 15:30:02 --> Hooks Class Initialized
DEBUG - 2011-04-09 15:30:02 --> Utf8 Class Initialized
DEBUG - 2011-04-09 15:30:02 --> UTF-8 Support Enabled
DEBUG - 2011-04-09 15:30:03 --> URI Class Initialized
DEBUG - 2011-04-09 15:30:03 --> Router Class Initialized
DEBUG - 2011-04-09 15:30:03 --> Output Class Initialized
DEBUG - 2011-04-09 15:30:03 --> Input Class Initialized
DEBUG - 2011-04-09 15:30:03 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-09 15:30:03 --> Language Class Initialized
DEBUG - 2011-04-09 15:30:03 --> Loader Class Initialized
DEBUG - 2011-04-09 15:30:03 --> Controller Class Initialized
DEBUG - 2011-04-09 15:30:03 --> Model Class Initialized
DEBUG - 2011-04-09 15:30:03 --> Model Class Initialized
DEBUG - 2011-04-09 15:30:03 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-09 15:30:03 --> Database Driver Class Initialized
DEBUG - 2011-04-09 15:30:04 --> Final output sent to browser
DEBUG - 2011-04-09 15:30:04 --> Total execution time: 1.0789
DEBUG - 2011-04-09 16:09:11 --> Config Class Initialized
DEBUG - 2011-04-09 16:09:11 --> Hooks Class Initialized
DEBUG - 2011-04-09 16:09:11 --> Utf8 Class Initialized
DEBUG - 2011-04-09 16:09:11 --> UTF-8 Support Enabled
DEBUG - 2011-04-09 16:09:11 --> URI Class Initialized
DEBUG - 2011-04-09 16:09:11 --> Router Class Initialized
DEBUG - 2011-04-09 16:09:11 --> Output Class Initialized
DEBUG - 2011-04-09 16:09:11 --> Input Class Initialized
DEBUG - 2011-04-09 16:09:11 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-09 16:09:11 --> Language Class Initialized
DEBUG - 2011-04-09 16:09:11 --> Loader Class Initialized
DEBUG - 2011-04-09 16:09:11 --> Controller Class Initialized
ERROR - 2011-04-09 16:09:11 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-09 16:09:11 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-09 16:09:11 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-09 16:09:11 --> Model Class Initialized
DEBUG - 2011-04-09 16:09:11 --> Model Class Initialized
DEBUG - 2011-04-09 16:09:11 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-09 16:09:11 --> Database Driver Class Initialized
DEBUG - 2011-04-09 16:09:11 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-09 16:09:11 --> Helper loaded: url_helper
DEBUG - 2011-04-09 16:09:11 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-09 16:09:11 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-09 16:09:11 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-09 16:09:11 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-09 16:09:11 --> Final output sent to browser
DEBUG - 2011-04-09 16:09:11 --> Total execution time: 0.1132
DEBUG - 2011-04-09 16:09:16 --> Config Class Initialized
DEBUG - 2011-04-09 16:09:16 --> Hooks Class Initialized
DEBUG - 2011-04-09 16:09:16 --> Utf8 Class Initialized
DEBUG - 2011-04-09 16:09:16 --> UTF-8 Support Enabled
DEBUG - 2011-04-09 16:09:16 --> URI Class Initialized
DEBUG - 2011-04-09 16:09:16 --> Router Class Initialized
DEBUG - 2011-04-09 16:09:16 --> Output Class Initialized
DEBUG - 2011-04-09 16:09:16 --> Input Class Initialized
DEBUG - 2011-04-09 16:09:16 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-09 16:09:16 --> Language Class Initialized
DEBUG - 2011-04-09 16:09:16 --> Loader Class Initialized
DEBUG - 2011-04-09 16:09:16 --> Controller Class Initialized
DEBUG - 2011-04-09 16:09:16 --> Model Class Initialized
DEBUG - 2011-04-09 16:09:17 --> Model Class Initialized
DEBUG - 2011-04-09 16:09:17 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-09 16:09:17 --> Database Driver Class Initialized
DEBUG - 2011-04-09 16:09:18 --> Final output sent to browser
DEBUG - 2011-04-09 16:09:18 --> Total execution time: 1.4558
DEBUG - 2011-04-09 16:10:23 --> Config Class Initialized
DEBUG - 2011-04-09 16:10:23 --> Hooks Class Initialized
DEBUG - 2011-04-09 16:10:23 --> Utf8 Class Initialized
DEBUG - 2011-04-09 16:10:23 --> UTF-8 Support Enabled
DEBUG - 2011-04-09 16:10:23 --> URI Class Initialized
DEBUG - 2011-04-09 16:10:23 --> Router Class Initialized
DEBUG - 2011-04-09 16:10:23 --> Output Class Initialized
DEBUG - 2011-04-09 16:10:23 --> Input Class Initialized
DEBUG - 2011-04-09 16:10:23 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-09 16:10:23 --> Language Class Initialized
DEBUG - 2011-04-09 16:10:23 --> Loader Class Initialized
DEBUG - 2011-04-09 16:10:23 --> Controller Class Initialized
ERROR - 2011-04-09 16:10:23 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-09 16:10:23 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-09 16:10:23 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-09 16:10:23 --> Model Class Initialized
DEBUG - 2011-04-09 16:10:23 --> Model Class Initialized
DEBUG - 2011-04-09 16:10:23 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-09 16:10:23 --> Database Driver Class Initialized
DEBUG - 2011-04-09 16:10:23 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-09 16:10:23 --> Helper loaded: url_helper
DEBUG - 2011-04-09 16:10:23 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-09 16:10:23 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-09 16:10:23 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-09 16:10:23 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-09 16:10:23 --> Final output sent to browser
DEBUG - 2011-04-09 16:10:23 --> Total execution time: 0.0299
DEBUG - 2011-04-09 16:10:24 --> Config Class Initialized
DEBUG - 2011-04-09 16:10:24 --> Hooks Class Initialized
DEBUG - 2011-04-09 16:10:24 --> Utf8 Class Initialized
DEBUG - 2011-04-09 16:10:24 --> UTF-8 Support Enabled
DEBUG - 2011-04-09 16:10:24 --> URI Class Initialized
DEBUG - 2011-04-09 16:10:24 --> Router Class Initialized
DEBUG - 2011-04-09 16:10:24 --> Output Class Initialized
DEBUG - 2011-04-09 16:10:24 --> Input Class Initialized
DEBUG - 2011-04-09 16:10:24 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-09 16:10:24 --> Language Class Initialized
DEBUG - 2011-04-09 16:10:24 --> Loader Class Initialized
DEBUG - 2011-04-09 16:10:24 --> Controller Class Initialized
DEBUG - 2011-04-09 16:10:24 --> Model Class Initialized
DEBUG - 2011-04-09 16:10:24 --> Model Class Initialized
DEBUG - 2011-04-09 16:10:24 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-09 16:10:24 --> Database Driver Class Initialized
DEBUG - 2011-04-09 16:10:25 --> Final output sent to browser
DEBUG - 2011-04-09 16:10:25 --> Total execution time: 0.5110
DEBUG - 2011-04-09 16:11:09 --> Config Class Initialized
DEBUG - 2011-04-09 16:11:09 --> Hooks Class Initialized
DEBUG - 2011-04-09 16:11:09 --> Utf8 Class Initialized
DEBUG - 2011-04-09 16:11:09 --> UTF-8 Support Enabled
DEBUG - 2011-04-09 16:11:09 --> URI Class Initialized
DEBUG - 2011-04-09 16:11:09 --> Router Class Initialized
DEBUG - 2011-04-09 16:11:09 --> Output Class Initialized
DEBUG - 2011-04-09 16:11:09 --> Input Class Initialized
DEBUG - 2011-04-09 16:11:09 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-09 16:11:09 --> Language Class Initialized
DEBUG - 2011-04-09 16:11:09 --> Loader Class Initialized
DEBUG - 2011-04-09 16:11:09 --> Controller Class Initialized
ERROR - 2011-04-09 16:11:09 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-09 16:11:09 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-09 16:11:09 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-09 16:11:09 --> Model Class Initialized
DEBUG - 2011-04-09 16:11:09 --> Model Class Initialized
DEBUG - 2011-04-09 16:11:09 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-09 16:11:09 --> Database Driver Class Initialized
DEBUG - 2011-04-09 16:11:09 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-09 16:11:09 --> Helper loaded: url_helper
DEBUG - 2011-04-09 16:11:09 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-09 16:11:09 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-09 16:11:09 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-09 16:11:09 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-09 16:11:09 --> Final output sent to browser
DEBUG - 2011-04-09 16:11:09 --> Total execution time: 0.0293
DEBUG - 2011-04-09 16:11:13 --> Config Class Initialized
DEBUG - 2011-04-09 16:11:13 --> Hooks Class Initialized
DEBUG - 2011-04-09 16:11:13 --> Utf8 Class Initialized
DEBUG - 2011-04-09 16:11:13 --> UTF-8 Support Enabled
DEBUG - 2011-04-09 16:11:13 --> URI Class Initialized
DEBUG - 2011-04-09 16:11:13 --> Router Class Initialized
DEBUG - 2011-04-09 16:11:13 --> Output Class Initialized
DEBUG - 2011-04-09 16:11:13 --> Input Class Initialized
DEBUG - 2011-04-09 16:11:13 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-09 16:11:13 --> Language Class Initialized
DEBUG - 2011-04-09 16:11:13 --> Loader Class Initialized
DEBUG - 2011-04-09 16:11:13 --> Controller Class Initialized
DEBUG - 2011-04-09 16:11:13 --> Model Class Initialized
DEBUG - 2011-04-09 16:11:13 --> Model Class Initialized
DEBUG - 2011-04-09 16:11:13 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-09 16:11:13 --> Database Driver Class Initialized
DEBUG - 2011-04-09 16:11:14 --> Final output sent to browser
DEBUG - 2011-04-09 16:11:14 --> Total execution time: 0.6604
DEBUG - 2011-04-09 16:11:39 --> Config Class Initialized
DEBUG - 2011-04-09 16:11:39 --> Hooks Class Initialized
DEBUG - 2011-04-09 16:11:39 --> Utf8 Class Initialized
DEBUG - 2011-04-09 16:11:39 --> UTF-8 Support Enabled
DEBUG - 2011-04-09 16:11:39 --> URI Class Initialized
DEBUG - 2011-04-09 16:11:39 --> Router Class Initialized
DEBUG - 2011-04-09 16:11:39 --> Output Class Initialized
DEBUG - 2011-04-09 16:11:39 --> Input Class Initialized
DEBUG - 2011-04-09 16:11:39 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-09 16:11:39 --> Language Class Initialized
DEBUG - 2011-04-09 16:11:39 --> Loader Class Initialized
DEBUG - 2011-04-09 16:11:39 --> Controller Class Initialized
ERROR - 2011-04-09 16:11:39 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-09 16:11:39 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-09 16:11:39 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-09 16:11:39 --> Model Class Initialized
DEBUG - 2011-04-09 16:11:39 --> Model Class Initialized
DEBUG - 2011-04-09 16:11:39 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-09 16:11:39 --> Database Driver Class Initialized
DEBUG - 2011-04-09 16:11:39 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-09 16:11:39 --> Helper loaded: url_helper
DEBUG - 2011-04-09 16:11:39 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-09 16:11:39 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-09 16:11:39 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-09 16:11:39 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-09 16:11:39 --> Final output sent to browser
DEBUG - 2011-04-09 16:11:39 --> Total execution time: 0.0279
DEBUG - 2011-04-09 16:11:40 --> Config Class Initialized
DEBUG - 2011-04-09 16:11:40 --> Hooks Class Initialized
DEBUG - 2011-04-09 16:11:40 --> Utf8 Class Initialized
DEBUG - 2011-04-09 16:11:40 --> UTF-8 Support Enabled
DEBUG - 2011-04-09 16:11:40 --> URI Class Initialized
DEBUG - 2011-04-09 16:11:40 --> Router Class Initialized
DEBUG - 2011-04-09 16:11:40 --> Output Class Initialized
DEBUG - 2011-04-09 16:11:40 --> Input Class Initialized
DEBUG - 2011-04-09 16:11:40 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-09 16:11:40 --> Language Class Initialized
DEBUG - 2011-04-09 16:11:40 --> Loader Class Initialized
DEBUG - 2011-04-09 16:11:40 --> Controller Class Initialized
DEBUG - 2011-04-09 16:11:40 --> Model Class Initialized
DEBUG - 2011-04-09 16:11:40 --> Model Class Initialized
DEBUG - 2011-04-09 16:11:40 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-09 16:11:40 --> Database Driver Class Initialized
DEBUG - 2011-04-09 16:11:40 --> Final output sent to browser
DEBUG - 2011-04-09 16:11:40 --> Total execution time: 0.4997
DEBUG - 2011-04-09 16:11:55 --> Config Class Initialized
DEBUG - 2011-04-09 16:11:55 --> Hooks Class Initialized
DEBUG - 2011-04-09 16:11:55 --> Utf8 Class Initialized
DEBUG - 2011-04-09 16:11:55 --> UTF-8 Support Enabled
DEBUG - 2011-04-09 16:11:55 --> URI Class Initialized
DEBUG - 2011-04-09 16:11:55 --> Router Class Initialized
DEBUG - 2011-04-09 16:11:55 --> Output Class Initialized
DEBUG - 2011-04-09 16:11:55 --> Input Class Initialized
DEBUG - 2011-04-09 16:11:55 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-09 16:11:55 --> Language Class Initialized
DEBUG - 2011-04-09 16:11:55 --> Loader Class Initialized
DEBUG - 2011-04-09 16:11:55 --> Controller Class Initialized
ERROR - 2011-04-09 16:11:55 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-09 16:11:55 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-09 16:11:55 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-09 16:11:55 --> Model Class Initialized
DEBUG - 2011-04-09 16:11:55 --> Model Class Initialized
DEBUG - 2011-04-09 16:11:55 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-09 16:11:55 --> Database Driver Class Initialized
DEBUG - 2011-04-09 16:11:55 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-09 16:11:55 --> Helper loaded: url_helper
DEBUG - 2011-04-09 16:11:55 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-09 16:11:55 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-09 16:11:55 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-09 16:11:55 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-09 16:11:55 --> Final output sent to browser
DEBUG - 2011-04-09 16:11:55 --> Total execution time: 0.0337
DEBUG - 2011-04-09 16:11:56 --> Config Class Initialized
DEBUG - 2011-04-09 16:11:56 --> Hooks Class Initialized
DEBUG - 2011-04-09 16:11:56 --> Utf8 Class Initialized
DEBUG - 2011-04-09 16:11:56 --> UTF-8 Support Enabled
DEBUG - 2011-04-09 16:11:56 --> URI Class Initialized
DEBUG - 2011-04-09 16:11:56 --> Router Class Initialized
DEBUG - 2011-04-09 16:11:56 --> Output Class Initialized
DEBUG - 2011-04-09 16:11:56 --> Input Class Initialized
DEBUG - 2011-04-09 16:11:56 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-09 16:11:56 --> Language Class Initialized
DEBUG - 2011-04-09 16:11:56 --> Loader Class Initialized
DEBUG - 2011-04-09 16:11:56 --> Controller Class Initialized
DEBUG - 2011-04-09 16:11:56 --> Model Class Initialized
DEBUG - 2011-04-09 16:11:56 --> Model Class Initialized
DEBUG - 2011-04-09 16:11:56 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-09 16:11:56 --> Database Driver Class Initialized
DEBUG - 2011-04-09 16:11:57 --> Config Class Initialized
DEBUG - 2011-04-09 16:11:57 --> Hooks Class Initialized
DEBUG - 2011-04-09 16:11:57 --> Utf8 Class Initialized
DEBUG - 2011-04-09 16:11:57 --> UTF-8 Support Enabled
DEBUG - 2011-04-09 16:11:57 --> URI Class Initialized
DEBUG - 2011-04-09 16:11:57 --> Router Class Initialized
DEBUG - 2011-04-09 16:11:57 --> Output Class Initialized
DEBUG - 2011-04-09 16:11:57 --> Input Class Initialized
DEBUG - 2011-04-09 16:11:57 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-09 16:11:57 --> Language Class Initialized
DEBUG - 2011-04-09 16:11:57 --> Loader Class Initialized
DEBUG - 2011-04-09 16:11:57 --> Controller Class Initialized
ERROR - 2011-04-09 16:11:57 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-09 16:11:57 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-09 16:11:57 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-09 16:11:57 --> Model Class Initialized
DEBUG - 2011-04-09 16:11:57 --> Model Class Initialized
DEBUG - 2011-04-09 16:11:57 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-09 16:11:57 --> Database Driver Class Initialized
DEBUG - 2011-04-09 16:11:57 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-09 16:11:57 --> Helper loaded: url_helper
DEBUG - 2011-04-09 16:11:57 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-09 16:11:57 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-09 16:11:57 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-09 16:11:57 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-09 16:11:57 --> Final output sent to browser
DEBUG - 2011-04-09 16:11:57 --> Total execution time: 0.0284
DEBUG - 2011-04-09 16:11:57 --> Final output sent to browser
DEBUG - 2011-04-09 16:11:57 --> Total execution time: 0.5888
DEBUG - 2011-04-09 16:12:08 --> Config Class Initialized
DEBUG - 2011-04-09 16:12:08 --> Hooks Class Initialized
DEBUG - 2011-04-09 16:12:08 --> Utf8 Class Initialized
DEBUG - 2011-04-09 16:12:08 --> UTF-8 Support Enabled
DEBUG - 2011-04-09 16:12:08 --> URI Class Initialized
DEBUG - 2011-04-09 16:12:08 --> Router Class Initialized
DEBUG - 2011-04-09 16:12:08 --> Output Class Initialized
DEBUG - 2011-04-09 16:12:08 --> Input Class Initialized
DEBUG - 2011-04-09 16:12:08 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-09 16:12:08 --> Language Class Initialized
DEBUG - 2011-04-09 16:12:08 --> Loader Class Initialized
DEBUG - 2011-04-09 16:12:08 --> Controller Class Initialized
ERROR - 2011-04-09 16:12:08 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-09 16:12:08 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-09 16:12:08 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-09 16:12:08 --> Model Class Initialized
DEBUG - 2011-04-09 16:12:08 --> Model Class Initialized
DEBUG - 2011-04-09 16:12:08 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-09 16:12:08 --> Database Driver Class Initialized
DEBUG - 2011-04-09 16:12:08 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-09 16:12:08 --> Helper loaded: url_helper
DEBUG - 2011-04-09 16:12:08 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-09 16:12:08 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-09 16:12:08 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-09 16:12:08 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-09 16:12:08 --> Final output sent to browser
DEBUG - 2011-04-09 16:12:08 --> Total execution time: 0.0281
DEBUG - 2011-04-09 16:12:09 --> Config Class Initialized
DEBUG - 2011-04-09 16:12:09 --> Hooks Class Initialized
DEBUG - 2011-04-09 16:12:09 --> Utf8 Class Initialized
DEBUG - 2011-04-09 16:12:09 --> UTF-8 Support Enabled
DEBUG - 2011-04-09 16:12:09 --> URI Class Initialized
DEBUG - 2011-04-09 16:12:09 --> Router Class Initialized
DEBUG - 2011-04-09 16:12:09 --> Output Class Initialized
DEBUG - 2011-04-09 16:12:09 --> Input Class Initialized
DEBUG - 2011-04-09 16:12:09 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-09 16:12:09 --> Language Class Initialized
DEBUG - 2011-04-09 16:12:09 --> Loader Class Initialized
DEBUG - 2011-04-09 16:12:09 --> Controller Class Initialized
DEBUG - 2011-04-09 16:12:09 --> Model Class Initialized
DEBUG - 2011-04-09 16:12:09 --> Model Class Initialized
DEBUG - 2011-04-09 16:12:09 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-09 16:12:09 --> Database Driver Class Initialized
DEBUG - 2011-04-09 16:12:09 --> Final output sent to browser
DEBUG - 2011-04-09 16:12:09 --> Total execution time: 0.4710
DEBUG - 2011-04-09 16:12:11 --> Config Class Initialized
DEBUG - 2011-04-09 16:12:11 --> Hooks Class Initialized
DEBUG - 2011-04-09 16:12:11 --> Utf8 Class Initialized
DEBUG - 2011-04-09 16:12:11 --> UTF-8 Support Enabled
DEBUG - 2011-04-09 16:12:11 --> URI Class Initialized
DEBUG - 2011-04-09 16:12:11 --> Router Class Initialized
ERROR - 2011-04-09 16:12:11 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-09 18:59:36 --> Config Class Initialized
DEBUG - 2011-04-09 18:59:36 --> Hooks Class Initialized
DEBUG - 2011-04-09 18:59:36 --> Utf8 Class Initialized
DEBUG - 2011-04-09 18:59:36 --> UTF-8 Support Enabled
DEBUG - 2011-04-09 18:59:36 --> URI Class Initialized
DEBUG - 2011-04-09 18:59:36 --> Router Class Initialized
DEBUG - 2011-04-09 18:59:36 --> No URI present. Default controller set.
DEBUG - 2011-04-09 18:59:36 --> Output Class Initialized
DEBUG - 2011-04-09 18:59:36 --> Input Class Initialized
DEBUG - 2011-04-09 18:59:36 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-09 18:59:36 --> Language Class Initialized
DEBUG - 2011-04-09 18:59:36 --> Loader Class Initialized
DEBUG - 2011-04-09 18:59:36 --> Controller Class Initialized
DEBUG - 2011-04-09 18:59:36 --> File loaded: application/views/splash/main.php
DEBUG - 2011-04-09 18:59:36 --> Helper loaded: url_helper
DEBUG - 2011-04-09 18:59:36 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-09 18:59:36 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-09 18:59:36 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-09 18:59:36 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-09 18:59:36 --> Final output sent to browser
DEBUG - 2011-04-09 18:59:36 --> Total execution time: 0.5135
DEBUG - 2011-04-09 19:01:02 --> Config Class Initialized
DEBUG - 2011-04-09 19:01:02 --> Hooks Class Initialized
DEBUG - 2011-04-09 19:01:02 --> Utf8 Class Initialized
DEBUG - 2011-04-09 19:01:02 --> UTF-8 Support Enabled
DEBUG - 2011-04-09 19:01:02 --> URI Class Initialized
DEBUG - 2011-04-09 19:01:02 --> Router Class Initialized
DEBUG - 2011-04-09 19:01:02 --> No URI present. Default controller set.
DEBUG - 2011-04-09 19:01:02 --> Output Class Initialized
DEBUG - 2011-04-09 19:01:02 --> Input Class Initialized
DEBUG - 2011-04-09 19:01:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-09 19:01:02 --> Language Class Initialized
DEBUG - 2011-04-09 19:01:02 --> Loader Class Initialized
DEBUG - 2011-04-09 19:01:02 --> Controller Class Initialized
DEBUG - 2011-04-09 19:01:02 --> File loaded: application/views/splash/main.php
DEBUG - 2011-04-09 19:01:02 --> Helper loaded: url_helper
DEBUG - 2011-04-09 19:01:02 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-09 19:01:02 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-09 19:01:02 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-09 19:01:02 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-09 19:01:02 --> Final output sent to browser
DEBUG - 2011-04-09 19:01:02 --> Total execution time: 0.0447
DEBUG - 2011-04-09 19:01:03 --> Config Class Initialized
DEBUG - 2011-04-09 19:01:03 --> Hooks Class Initialized
DEBUG - 2011-04-09 19:01:03 --> Utf8 Class Initialized
DEBUG - 2011-04-09 19:01:03 --> UTF-8 Support Enabled
DEBUG - 2011-04-09 19:01:03 --> URI Class Initialized
DEBUG - 2011-04-09 19:01:03 --> Router Class Initialized
ERROR - 2011-04-09 19:01:03 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-09 19:10:48 --> Config Class Initialized
DEBUG - 2011-04-09 19:10:48 --> Hooks Class Initialized
DEBUG - 2011-04-09 19:10:48 --> Utf8 Class Initialized
DEBUG - 2011-04-09 19:10:48 --> UTF-8 Support Enabled
DEBUG - 2011-04-09 19:10:48 --> URI Class Initialized
DEBUG - 2011-04-09 19:10:48 --> Router Class Initialized
DEBUG - 2011-04-09 19:10:48 --> Output Class Initialized
DEBUG - 2011-04-09 19:10:48 --> Input Class Initialized
DEBUG - 2011-04-09 19:10:48 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-09 19:10:48 --> Language Class Initialized
DEBUG - 2011-04-09 19:10:48 --> Loader Class Initialized
DEBUG - 2011-04-09 19:10:48 --> Controller Class Initialized
ERROR - 2011-04-09 19:10:48 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-09 19:10:48 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-09 19:10:48 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-09 19:10:48 --> Model Class Initialized
DEBUG - 2011-04-09 19:10:48 --> Model Class Initialized
DEBUG - 2011-04-09 19:10:48 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-09 19:10:48 --> Database Driver Class Initialized
DEBUG - 2011-04-09 19:10:48 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-09 19:10:48 --> Helper loaded: url_helper
DEBUG - 2011-04-09 19:10:48 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-09 19:10:48 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-09 19:10:48 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-09 19:10:48 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-09 19:10:48 --> Final output sent to browser
DEBUG - 2011-04-09 19:10:48 --> Total execution time: 0.3858
DEBUG - 2011-04-09 19:10:54 --> Config Class Initialized
DEBUG - 2011-04-09 19:10:54 --> Hooks Class Initialized
DEBUG - 2011-04-09 19:10:54 --> Utf8 Class Initialized
DEBUG - 2011-04-09 19:10:54 --> UTF-8 Support Enabled
DEBUG - 2011-04-09 19:10:54 --> URI Class Initialized
DEBUG - 2011-04-09 19:10:54 --> Router Class Initialized
DEBUG - 2011-04-09 19:10:54 --> Output Class Initialized
DEBUG - 2011-04-09 19:10:54 --> Input Class Initialized
DEBUG - 2011-04-09 19:10:54 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-09 19:10:54 --> Language Class Initialized
DEBUG - 2011-04-09 19:10:54 --> Loader Class Initialized
DEBUG - 2011-04-09 19:10:54 --> Controller Class Initialized
DEBUG - 2011-04-09 19:10:54 --> Model Class Initialized
DEBUG - 2011-04-09 19:10:54 --> Model Class Initialized
DEBUG - 2011-04-09 19:10:54 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-09 19:10:54 --> Database Driver Class Initialized
DEBUG - 2011-04-09 19:10:54 --> Final output sent to browser
DEBUG - 2011-04-09 19:10:54 --> Total execution time: 0.7116
DEBUG - 2011-04-09 19:10:58 --> Config Class Initialized
DEBUG - 2011-04-09 19:10:58 --> Hooks Class Initialized
DEBUG - 2011-04-09 19:10:58 --> Utf8 Class Initialized
DEBUG - 2011-04-09 19:10:58 --> UTF-8 Support Enabled
DEBUG - 2011-04-09 19:10:58 --> URI Class Initialized
DEBUG - 2011-04-09 19:10:58 --> Router Class Initialized
ERROR - 2011-04-09 19:10:58 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-09 19:14:09 --> Config Class Initialized
DEBUG - 2011-04-09 19:14:09 --> Hooks Class Initialized
DEBUG - 2011-04-09 19:14:09 --> Utf8 Class Initialized
DEBUG - 2011-04-09 19:14:09 --> UTF-8 Support Enabled
DEBUG - 2011-04-09 19:14:09 --> URI Class Initialized
DEBUG - 2011-04-09 19:14:09 --> Router Class Initialized
DEBUG - 2011-04-09 19:14:09 --> Output Class Initialized
DEBUG - 2011-04-09 19:14:09 --> Input Class Initialized
DEBUG - 2011-04-09 19:14:09 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-09 19:14:09 --> Language Class Initialized
DEBUG - 2011-04-09 19:14:09 --> Loader Class Initialized
DEBUG - 2011-04-09 19:14:09 --> Controller Class Initialized
ERROR - 2011-04-09 19:14:09 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-09 19:14:09 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-09 19:14:09 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-09 19:14:09 --> Model Class Initialized
DEBUG - 2011-04-09 19:14:09 --> Model Class Initialized
DEBUG - 2011-04-09 19:14:09 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-09 19:14:09 --> Database Driver Class Initialized
DEBUG - 2011-04-09 19:14:09 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-09 19:14:09 --> Helper loaded: url_helper
DEBUG - 2011-04-09 19:14:09 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-09 19:14:09 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-09 19:14:09 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-09 19:14:09 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-09 19:14:09 --> Final output sent to browser
DEBUG - 2011-04-09 19:14:09 --> Total execution time: 0.0417
DEBUG - 2011-04-09 19:14:38 --> Config Class Initialized
DEBUG - 2011-04-09 19:14:38 --> Hooks Class Initialized
DEBUG - 2011-04-09 19:14:38 --> Utf8 Class Initialized
DEBUG - 2011-04-09 19:14:38 --> UTF-8 Support Enabled
DEBUG - 2011-04-09 19:14:38 --> URI Class Initialized
DEBUG - 2011-04-09 19:14:38 --> Router Class Initialized
DEBUG - 2011-04-09 19:14:38 --> Output Class Initialized
DEBUG - 2011-04-09 19:14:38 --> Input Class Initialized
DEBUG - 2011-04-09 19:14:38 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-09 19:14:38 --> Language Class Initialized
DEBUG - 2011-04-09 19:14:38 --> Loader Class Initialized
DEBUG - 2011-04-09 19:14:38 --> Controller Class Initialized
DEBUG - 2011-04-09 19:14:38 --> Model Class Initialized
DEBUG - 2011-04-09 19:14:38 --> Model Class Initialized
DEBUG - 2011-04-09 19:14:38 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-09 19:14:38 --> Database Driver Class Initialized
DEBUG - 2011-04-09 19:14:39 --> Final output sent to browser
DEBUG - 2011-04-09 19:14:39 --> Total execution time: 0.5614
DEBUG - 2011-04-09 19:14:43 --> Config Class Initialized
DEBUG - 2011-04-09 19:14:43 --> Hooks Class Initialized
DEBUG - 2011-04-09 19:14:43 --> Utf8 Class Initialized
DEBUG - 2011-04-09 19:14:43 --> UTF-8 Support Enabled
DEBUG - 2011-04-09 19:14:43 --> URI Class Initialized
DEBUG - 2011-04-09 19:14:43 --> Router Class Initialized
ERROR - 2011-04-09 19:14:43 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-09 19:49:51 --> Config Class Initialized
DEBUG - 2011-04-09 19:49:51 --> Hooks Class Initialized
DEBUG - 2011-04-09 19:49:51 --> Utf8 Class Initialized
DEBUG - 2011-04-09 19:49:51 --> UTF-8 Support Enabled
DEBUG - 2011-04-09 19:49:51 --> URI Class Initialized
DEBUG - 2011-04-09 19:49:51 --> Router Class Initialized
DEBUG - 2011-04-09 19:49:51 --> Output Class Initialized
DEBUG - 2011-04-09 19:49:51 --> Input Class Initialized
DEBUG - 2011-04-09 19:49:51 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-09 19:49:51 --> Language Class Initialized
DEBUG - 2011-04-09 19:49:51 --> Loader Class Initialized
DEBUG - 2011-04-09 19:49:51 --> Controller Class Initialized
DEBUG - 2011-04-09 19:49:51 --> Model Class Initialized
DEBUG - 2011-04-09 19:49:51 --> Model Class Initialized
DEBUG - 2011-04-09 19:49:51 --> Model Class Initialized
DEBUG - 2011-04-09 19:49:51 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-09 19:49:51 --> Database Driver Class Initialized
DEBUG - 2011-04-09 19:49:52 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-09 19:49:52 --> Helper loaded: url_helper
DEBUG - 2011-04-09 19:49:52 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-09 19:49:52 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-09 19:49:52 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-09 19:49:52 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-09 19:49:52 --> Final output sent to browser
DEBUG - 2011-04-09 19:49:52 --> Total execution time: 0.2605
DEBUG - 2011-04-09 19:49:54 --> Config Class Initialized
DEBUG - 2011-04-09 19:49:54 --> Hooks Class Initialized
DEBUG - 2011-04-09 19:49:54 --> Utf8 Class Initialized
DEBUG - 2011-04-09 19:49:54 --> UTF-8 Support Enabled
DEBUG - 2011-04-09 19:49:54 --> URI Class Initialized
DEBUG - 2011-04-09 19:49:54 --> Router Class Initialized
ERROR - 2011-04-09 19:49:54 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-09 19:51:28 --> Config Class Initialized
DEBUG - 2011-04-09 19:51:28 --> Hooks Class Initialized
DEBUG - 2011-04-09 19:51:28 --> Utf8 Class Initialized
DEBUG - 2011-04-09 19:51:28 --> UTF-8 Support Enabled
DEBUG - 2011-04-09 19:51:28 --> URI Class Initialized
DEBUG - 2011-04-09 19:51:28 --> Router Class Initialized
DEBUG - 2011-04-09 19:51:28 --> No URI present. Default controller set.
DEBUG - 2011-04-09 19:51:28 --> Output Class Initialized
DEBUG - 2011-04-09 19:51:28 --> Input Class Initialized
DEBUG - 2011-04-09 19:51:28 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-09 19:51:28 --> Language Class Initialized
DEBUG - 2011-04-09 19:51:28 --> Loader Class Initialized
DEBUG - 2011-04-09 19:51:28 --> Controller Class Initialized
DEBUG - 2011-04-09 19:51:28 --> File loaded: application/views/splash/main.php
DEBUG - 2011-04-09 19:51:28 --> Helper loaded: url_helper
DEBUG - 2011-04-09 19:51:28 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-09 19:51:28 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-09 19:51:28 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-09 19:51:28 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-09 19:51:28 --> Final output sent to browser
DEBUG - 2011-04-09 19:51:28 --> Total execution time: 0.0121
DEBUG - 2011-04-09 19:51:29 --> Config Class Initialized
DEBUG - 2011-04-09 19:51:29 --> Hooks Class Initialized
DEBUG - 2011-04-09 19:51:29 --> Utf8 Class Initialized
DEBUG - 2011-04-09 19:51:29 --> UTF-8 Support Enabled
DEBUG - 2011-04-09 19:51:29 --> URI Class Initialized
DEBUG - 2011-04-09 19:51:29 --> Router Class Initialized
ERROR - 2011-04-09 19:51:29 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-09 19:51:29 --> Config Class Initialized
DEBUG - 2011-04-09 19:51:29 --> Hooks Class Initialized
DEBUG - 2011-04-09 19:51:29 --> Utf8 Class Initialized
DEBUG - 2011-04-09 19:51:29 --> UTF-8 Support Enabled
DEBUG - 2011-04-09 19:51:29 --> URI Class Initialized
DEBUG - 2011-04-09 19:51:29 --> Router Class Initialized
ERROR - 2011-04-09 19:51:29 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-09 19:51:31 --> Config Class Initialized
DEBUG - 2011-04-09 19:51:31 --> Hooks Class Initialized
DEBUG - 2011-04-09 19:51:31 --> Utf8 Class Initialized
DEBUG - 2011-04-09 19:51:31 --> UTF-8 Support Enabled
DEBUG - 2011-04-09 19:51:31 --> URI Class Initialized
DEBUG - 2011-04-09 19:51:31 --> Router Class Initialized
DEBUG - 2011-04-09 19:51:31 --> Output Class Initialized
DEBUG - 2011-04-09 19:51:31 --> Input Class Initialized
DEBUG - 2011-04-09 19:51:31 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-09 19:51:31 --> Language Class Initialized
DEBUG - 2011-04-09 19:51:31 --> Loader Class Initialized
DEBUG - 2011-04-09 19:51:31 --> Controller Class Initialized
DEBUG - 2011-04-09 19:51:31 --> Model Class Initialized
DEBUG - 2011-04-09 19:51:31 --> Model Class Initialized
DEBUG - 2011-04-09 19:51:31 --> Model Class Initialized
DEBUG - 2011-04-09 19:51:31 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-09 19:51:31 --> Database Driver Class Initialized
DEBUG - 2011-04-09 19:51:31 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-09 19:51:31 --> Helper loaded: url_helper
DEBUG - 2011-04-09 19:51:31 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-09 19:51:31 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-09 19:51:31 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-09 19:51:31 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-09 19:51:31 --> Final output sent to browser
DEBUG - 2011-04-09 19:51:31 --> Total execution time: 0.0427
DEBUG - 2011-04-09 19:51:55 --> Config Class Initialized
DEBUG - 2011-04-09 19:51:55 --> Hooks Class Initialized
DEBUG - 2011-04-09 19:51:55 --> Utf8 Class Initialized
DEBUG - 2011-04-09 19:51:55 --> UTF-8 Support Enabled
DEBUG - 2011-04-09 19:51:55 --> URI Class Initialized
DEBUG - 2011-04-09 19:51:55 --> Router Class Initialized
DEBUG - 2011-04-09 19:51:55 --> Output Class Initialized
DEBUG - 2011-04-09 19:51:55 --> Input Class Initialized
DEBUG - 2011-04-09 19:51:55 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-09 19:51:55 --> Language Class Initialized
DEBUG - 2011-04-09 19:51:55 --> Loader Class Initialized
DEBUG - 2011-04-09 19:51:55 --> Controller Class Initialized
DEBUG - 2011-04-09 19:51:55 --> Model Class Initialized
DEBUG - 2011-04-09 19:51:55 --> Model Class Initialized
DEBUG - 2011-04-09 19:51:55 --> Model Class Initialized
DEBUG - 2011-04-09 19:51:55 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-09 19:51:55 --> Database Driver Class Initialized
DEBUG - 2011-04-09 19:51:55 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-09 19:51:55 --> Helper loaded: url_helper
DEBUG - 2011-04-09 19:51:55 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-09 19:51:55 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-09 19:51:55 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-09 19:51:55 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-09 19:51:55 --> Final output sent to browser
DEBUG - 2011-04-09 19:51:55 --> Total execution time: 0.1793
DEBUG - 2011-04-09 19:52:02 --> Config Class Initialized
DEBUG - 2011-04-09 19:52:02 --> Hooks Class Initialized
DEBUG - 2011-04-09 19:52:02 --> Utf8 Class Initialized
DEBUG - 2011-04-09 19:52:02 --> UTF-8 Support Enabled
DEBUG - 2011-04-09 19:52:02 --> URI Class Initialized
DEBUG - 2011-04-09 19:52:02 --> Router Class Initialized
DEBUG - 2011-04-09 19:52:02 --> Output Class Initialized
DEBUG - 2011-04-09 19:52:02 --> Input Class Initialized
DEBUG - 2011-04-09 19:52:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-09 19:52:02 --> Language Class Initialized
DEBUG - 2011-04-09 19:52:02 --> Loader Class Initialized
DEBUG - 2011-04-09 19:52:02 --> Controller Class Initialized
DEBUG - 2011-04-09 19:52:02 --> Model Class Initialized
DEBUG - 2011-04-09 19:52:02 --> Model Class Initialized
DEBUG - 2011-04-09 19:52:02 --> Model Class Initialized
DEBUG - 2011-04-09 19:52:02 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-09 19:52:02 --> Database Driver Class Initialized
DEBUG - 2011-04-09 19:52:02 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-09 19:52:02 --> Helper loaded: url_helper
DEBUG - 2011-04-09 19:52:02 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-09 19:52:02 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-09 19:52:02 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-09 19:52:02 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-09 19:52:02 --> Final output sent to browser
DEBUG - 2011-04-09 19:52:02 --> Total execution time: 0.0408
DEBUG - 2011-04-09 19:52:06 --> Config Class Initialized
DEBUG - 2011-04-09 19:52:06 --> Hooks Class Initialized
DEBUG - 2011-04-09 19:52:06 --> Utf8 Class Initialized
DEBUG - 2011-04-09 19:52:06 --> UTF-8 Support Enabled
DEBUG - 2011-04-09 19:52:06 --> URI Class Initialized
DEBUG - 2011-04-09 19:52:06 --> Router Class Initialized
DEBUG - 2011-04-09 19:52:06 --> No URI present. Default controller set.
DEBUG - 2011-04-09 19:52:06 --> Output Class Initialized
DEBUG - 2011-04-09 19:52:06 --> Input Class Initialized
DEBUG - 2011-04-09 19:52:06 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-09 19:52:06 --> Language Class Initialized
DEBUG - 2011-04-09 19:52:06 --> Loader Class Initialized
DEBUG - 2011-04-09 19:52:06 --> Controller Class Initialized
DEBUG - 2011-04-09 19:52:06 --> File loaded: application/views/splash/main.php
DEBUG - 2011-04-09 19:52:06 --> Helper loaded: url_helper
DEBUG - 2011-04-09 19:52:06 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-09 19:52:06 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-09 19:52:06 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-09 19:52:06 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-09 19:52:06 --> Final output sent to browser
DEBUG - 2011-04-09 19:52:06 --> Total execution time: 0.0132
DEBUG - 2011-04-09 19:52:06 --> Config Class Initialized
DEBUG - 2011-04-09 19:52:06 --> Hooks Class Initialized
DEBUG - 2011-04-09 19:52:06 --> Utf8 Class Initialized
DEBUG - 2011-04-09 19:52:06 --> UTF-8 Support Enabled
DEBUG - 2011-04-09 19:52:06 --> URI Class Initialized
DEBUG - 2011-04-09 19:52:06 --> Router Class Initialized
DEBUG - 2011-04-09 19:52:06 --> Output Class Initialized
DEBUG - 2011-04-09 19:52:06 --> Input Class Initialized
DEBUG - 2011-04-09 19:52:06 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-09 19:52:06 --> Language Class Initialized
DEBUG - 2011-04-09 19:52:06 --> Loader Class Initialized
DEBUG - 2011-04-09 19:52:06 --> Controller Class Initialized
DEBUG - 2011-04-09 19:52:06 --> Model Class Initialized
DEBUG - 2011-04-09 19:52:06 --> Model Class Initialized
DEBUG - 2011-04-09 19:52:06 --> Model Class Initialized
DEBUG - 2011-04-09 19:52:06 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-09 19:52:06 --> Database Driver Class Initialized
DEBUG - 2011-04-09 19:52:06 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-09 19:52:06 --> Helper loaded: url_helper
DEBUG - 2011-04-09 19:52:06 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-09 19:52:06 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-09 19:52:06 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-09 19:52:06 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-09 19:52:06 --> Final output sent to browser
DEBUG - 2011-04-09 19:52:06 --> Total execution time: 0.0517
DEBUG - 2011-04-09 19:52:23 --> Config Class Initialized
DEBUG - 2011-04-09 19:52:23 --> Hooks Class Initialized
DEBUG - 2011-04-09 19:52:23 --> Utf8 Class Initialized
DEBUG - 2011-04-09 19:52:23 --> UTF-8 Support Enabled
DEBUG - 2011-04-09 19:52:23 --> URI Class Initialized
DEBUG - 2011-04-09 19:52:23 --> Router Class Initialized
DEBUG - 2011-04-09 19:52:23 --> Output Class Initialized
DEBUG - 2011-04-09 19:52:23 --> Input Class Initialized
DEBUG - 2011-04-09 19:52:23 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-09 19:52:23 --> Language Class Initialized
DEBUG - 2011-04-09 19:52:23 --> Loader Class Initialized
DEBUG - 2011-04-09 19:52:23 --> Controller Class Initialized
DEBUG - 2011-04-09 19:52:23 --> Model Class Initialized
DEBUG - 2011-04-09 19:52:23 --> Model Class Initialized
DEBUG - 2011-04-09 19:52:23 --> Model Class Initialized
DEBUG - 2011-04-09 19:52:23 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-09 19:52:23 --> Database Driver Class Initialized
DEBUG - 2011-04-09 19:52:23 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-09 19:52:23 --> Helper loaded: url_helper
DEBUG - 2011-04-09 19:52:23 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-09 19:52:23 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-09 19:52:23 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-09 19:52:23 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-09 19:52:23 --> Final output sent to browser
DEBUG - 2011-04-09 19:52:23 --> Total execution time: 0.3331
DEBUG - 2011-04-09 22:07:42 --> Config Class Initialized
DEBUG - 2011-04-09 22:07:42 --> Hooks Class Initialized
DEBUG - 2011-04-09 22:07:42 --> Utf8 Class Initialized
DEBUG - 2011-04-09 22:07:42 --> UTF-8 Support Enabled
DEBUG - 2011-04-09 22:07:42 --> URI Class Initialized
DEBUG - 2011-04-09 22:07:42 --> Router Class Initialized
DEBUG - 2011-04-09 22:07:42 --> No URI present. Default controller set.
DEBUG - 2011-04-09 22:07:42 --> Output Class Initialized
DEBUG - 2011-04-09 22:07:42 --> Input Class Initialized
DEBUG - 2011-04-09 22:07:42 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-09 22:07:42 --> Language Class Initialized
DEBUG - 2011-04-09 22:07:42 --> Loader Class Initialized
DEBUG - 2011-04-09 22:07:42 --> Controller Class Initialized
DEBUG - 2011-04-09 22:07:42 --> File loaded: application/views/splash/main.php
DEBUG - 2011-04-09 22:07:42 --> Helper loaded: url_helper
DEBUG - 2011-04-09 22:07:42 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-09 22:07:42 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-09 22:07:42 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-09 22:07:42 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-09 22:07:42 --> Final output sent to browser
DEBUG - 2011-04-09 22:07:42 --> Total execution time: 0.2270
DEBUG - 2011-04-09 22:07:43 --> Config Class Initialized
DEBUG - 2011-04-09 22:07:43 --> Hooks Class Initialized
DEBUG - 2011-04-09 22:07:43 --> Utf8 Class Initialized
DEBUG - 2011-04-09 22:07:43 --> UTF-8 Support Enabled
DEBUG - 2011-04-09 22:07:43 --> URI Class Initialized
DEBUG - 2011-04-09 22:07:43 --> Router Class Initialized
ERROR - 2011-04-09 22:07:43 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-09 22:07:43 --> Config Class Initialized
DEBUG - 2011-04-09 22:07:43 --> Hooks Class Initialized
DEBUG - 2011-04-09 22:07:43 --> Utf8 Class Initialized
DEBUG - 2011-04-09 22:07:43 --> UTF-8 Support Enabled
DEBUG - 2011-04-09 22:07:43 --> URI Class Initialized
DEBUG - 2011-04-09 22:07:43 --> Router Class Initialized
ERROR - 2011-04-09 22:07:43 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-09 22:07:43 --> Config Class Initialized
DEBUG - 2011-04-09 22:07:43 --> Hooks Class Initialized
DEBUG - 2011-04-09 22:07:43 --> Utf8 Class Initialized
DEBUG - 2011-04-09 22:07:43 --> UTF-8 Support Enabled
DEBUG - 2011-04-09 22:07:43 --> URI Class Initialized
DEBUG - 2011-04-09 22:07:43 --> Router Class Initialized
ERROR - 2011-04-09 22:07:43 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-09 22:07:46 --> Config Class Initialized
DEBUG - 2011-04-09 22:07:46 --> Hooks Class Initialized
DEBUG - 2011-04-09 22:07:46 --> Utf8 Class Initialized
DEBUG - 2011-04-09 22:07:46 --> UTF-8 Support Enabled
DEBUG - 2011-04-09 22:07:46 --> URI Class Initialized
DEBUG - 2011-04-09 22:07:46 --> Router Class Initialized
DEBUG - 2011-04-09 22:07:46 --> Output Class Initialized
DEBUG - 2011-04-09 22:07:46 --> Input Class Initialized
DEBUG - 2011-04-09 22:07:46 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-09 22:07:46 --> Language Class Initialized
DEBUG - 2011-04-09 22:07:46 --> Loader Class Initialized
DEBUG - 2011-04-09 22:07:46 --> Controller Class Initialized
DEBUG - 2011-04-09 22:07:46 --> Model Class Initialized
DEBUG - 2011-04-09 22:07:46 --> Model Class Initialized
DEBUG - 2011-04-09 22:07:46 --> Model Class Initialized
DEBUG - 2011-04-09 22:07:46 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-09 22:07:46 --> Database Driver Class Initialized
DEBUG - 2011-04-09 22:07:46 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-09 22:07:46 --> Helper loaded: url_helper
DEBUG - 2011-04-09 22:07:46 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-09 22:07:46 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-09 22:07:46 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-09 22:07:46 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-09 22:07:46 --> Final output sent to browser
DEBUG - 2011-04-09 22:07:46 --> Total execution time: 0.3086
DEBUG - 2011-04-09 22:07:55 --> Config Class Initialized
DEBUG - 2011-04-09 22:07:55 --> Hooks Class Initialized
DEBUG - 2011-04-09 22:07:55 --> Utf8 Class Initialized
DEBUG - 2011-04-09 22:07:55 --> UTF-8 Support Enabled
DEBUG - 2011-04-09 22:07:55 --> URI Class Initialized
DEBUG - 2011-04-09 22:07:55 --> Router Class Initialized
DEBUG - 2011-04-09 22:07:55 --> Output Class Initialized
DEBUG - 2011-04-09 22:07:55 --> Input Class Initialized
DEBUG - 2011-04-09 22:07:55 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-09 22:07:55 --> Language Class Initialized
DEBUG - 2011-04-09 22:07:55 --> Loader Class Initialized
DEBUG - 2011-04-09 22:07:56 --> Controller Class Initialized
DEBUG - 2011-04-09 22:07:56 --> Model Class Initialized
DEBUG - 2011-04-09 22:07:56 --> Model Class Initialized
DEBUG - 2011-04-09 22:07:56 --> Model Class Initialized
DEBUG - 2011-04-09 22:07:56 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-09 22:07:56 --> Database Driver Class Initialized
DEBUG - 2011-04-09 22:07:56 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-09 22:07:56 --> Helper loaded: url_helper
DEBUG - 2011-04-09 22:07:56 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-09 22:07:56 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-09 22:07:56 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-09 22:07:56 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-09 22:07:56 --> Final output sent to browser
DEBUG - 2011-04-09 22:07:56 --> Total execution time: 0.2282
DEBUG - 2011-04-09 22:32:38 --> Config Class Initialized
DEBUG - 2011-04-09 22:32:38 --> Hooks Class Initialized
DEBUG - 2011-04-09 22:32:38 --> Utf8 Class Initialized
DEBUG - 2011-04-09 22:32:38 --> UTF-8 Support Enabled
DEBUG - 2011-04-09 22:32:38 --> URI Class Initialized
DEBUG - 2011-04-09 22:32:38 --> Router Class Initialized
DEBUG - 2011-04-09 22:32:38 --> No URI present. Default controller set.
DEBUG - 2011-04-09 22:32:38 --> Output Class Initialized
DEBUG - 2011-04-09 22:32:38 --> Input Class Initialized
DEBUG - 2011-04-09 22:32:38 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-09 22:32:38 --> Language Class Initialized
DEBUG - 2011-04-09 22:32:38 --> Loader Class Initialized
DEBUG - 2011-04-09 22:32:38 --> Controller Class Initialized
DEBUG - 2011-04-09 22:32:38 --> File loaded: application/views/splash/main.php
DEBUG - 2011-04-09 22:32:38 --> Helper loaded: url_helper
DEBUG - 2011-04-09 22:32:38 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-09 22:32:38 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-09 22:32:38 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-09 22:32:38 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-09 22:32:38 --> Final output sent to browser
DEBUG - 2011-04-09 22:32:38 --> Total execution time: 0.0282
DEBUG - 2011-04-09 22:32:39 --> Config Class Initialized
DEBUG - 2011-04-09 22:32:39 --> Hooks Class Initialized
DEBUG - 2011-04-09 22:32:39 --> Utf8 Class Initialized
DEBUG - 2011-04-09 22:32:39 --> UTF-8 Support Enabled
DEBUG - 2011-04-09 22:32:39 --> URI Class Initialized
DEBUG - 2011-04-09 22:32:39 --> Router Class Initialized
DEBUG - 2011-04-09 22:32:39 --> Output Class Initialized
DEBUG - 2011-04-09 22:32:39 --> Input Class Initialized
DEBUG - 2011-04-09 22:32:39 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-09 22:32:39 --> Language Class Initialized
DEBUG - 2011-04-09 22:32:39 --> Loader Class Initialized
DEBUG - 2011-04-09 22:32:39 --> Controller Class Initialized
DEBUG - 2011-04-09 22:32:39 --> Model Class Initialized
DEBUG - 2011-04-09 22:32:39 --> Model Class Initialized
DEBUG - 2011-04-09 22:32:39 --> Model Class Initialized
DEBUG - 2011-04-09 22:32:39 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-09 22:32:39 --> Database Driver Class Initialized
DEBUG - 2011-04-09 22:32:40 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-09 22:32:40 --> Helper loaded: url_helper
DEBUG - 2011-04-09 22:32:40 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-09 22:32:40 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-09 22:32:40 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-09 22:32:40 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-09 22:32:40 --> Final output sent to browser
DEBUG - 2011-04-09 22:32:40 --> Total execution time: 0.4359
DEBUG - 2011-04-09 22:32:54 --> Config Class Initialized
DEBUG - 2011-04-09 22:32:54 --> Hooks Class Initialized
DEBUG - 2011-04-09 22:32:54 --> Utf8 Class Initialized
DEBUG - 2011-04-09 22:32:54 --> UTF-8 Support Enabled
DEBUG - 2011-04-09 22:32:54 --> URI Class Initialized
DEBUG - 2011-04-09 22:32:54 --> Router Class Initialized
DEBUG - 2011-04-09 22:32:54 --> Output Class Initialized
DEBUG - 2011-04-09 22:32:54 --> Input Class Initialized
DEBUG - 2011-04-09 22:32:54 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-09 22:32:54 --> Language Class Initialized
DEBUG - 2011-04-09 22:32:54 --> Loader Class Initialized
DEBUG - 2011-04-09 22:32:54 --> Controller Class Initialized
DEBUG - 2011-04-09 22:32:54 --> Model Class Initialized
DEBUG - 2011-04-09 22:32:54 --> Model Class Initialized
DEBUG - 2011-04-09 22:32:54 --> Model Class Initialized
DEBUG - 2011-04-09 22:32:54 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-09 22:32:54 --> Database Driver Class Initialized
DEBUG - 2011-04-09 22:32:54 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-09 22:32:54 --> Helper loaded: url_helper
DEBUG - 2011-04-09 22:32:54 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-09 22:32:54 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-09 22:32:54 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-09 22:32:54 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-09 22:32:54 --> Final output sent to browser
DEBUG - 2011-04-09 22:32:54 --> Total execution time: 0.2409
DEBUG - 2011-04-09 22:33:02 --> Config Class Initialized
DEBUG - 2011-04-09 22:33:02 --> Hooks Class Initialized
DEBUG - 2011-04-09 22:33:02 --> Utf8 Class Initialized
DEBUG - 2011-04-09 22:33:02 --> UTF-8 Support Enabled
DEBUG - 2011-04-09 22:33:02 --> URI Class Initialized
DEBUG - 2011-04-09 22:33:02 --> Router Class Initialized
DEBUG - 2011-04-09 22:33:02 --> Output Class Initialized
DEBUG - 2011-04-09 22:33:02 --> Input Class Initialized
DEBUG - 2011-04-09 22:33:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-09 22:33:02 --> Language Class Initialized
DEBUG - 2011-04-09 22:33:02 --> Loader Class Initialized
DEBUG - 2011-04-09 22:33:02 --> Controller Class Initialized
DEBUG - 2011-04-09 22:33:02 --> Model Class Initialized
DEBUG - 2011-04-09 22:33:02 --> Model Class Initialized
DEBUG - 2011-04-09 22:33:02 --> Model Class Initialized
DEBUG - 2011-04-09 22:33:02 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-09 22:33:02 --> Database Driver Class Initialized
DEBUG - 2011-04-09 22:33:03 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-09 22:33:03 --> Helper loaded: url_helper
DEBUG - 2011-04-09 22:33:03 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-09 22:33:03 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-09 22:33:03 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-09 22:33:03 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-09 22:33:03 --> Final output sent to browser
DEBUG - 2011-04-09 22:33:03 --> Total execution time: 0.5531

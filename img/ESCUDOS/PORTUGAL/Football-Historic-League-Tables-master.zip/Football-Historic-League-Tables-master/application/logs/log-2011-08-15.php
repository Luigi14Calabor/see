<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2011-08-15 00:16:54 --> Config Class Initialized
DEBUG - 2011-08-15 00:16:54 --> Hooks Class Initialized
DEBUG - 2011-08-15 00:16:54 --> Utf8 Class Initialized
DEBUG - 2011-08-15 00:16:54 --> UTF-8 Support Enabled
DEBUG - 2011-08-15 00:16:54 --> URI Class Initialized
DEBUG - 2011-08-15 00:16:54 --> Router Class Initialized
DEBUG - 2011-08-15 00:16:54 --> No URI present. Default controller set.
DEBUG - 2011-08-15 00:16:54 --> Output Class Initialized
DEBUG - 2011-08-15 00:16:54 --> Input Class Initialized
DEBUG - 2011-08-15 00:16:54 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-15 00:16:54 --> Language Class Initialized
DEBUG - 2011-08-15 00:16:54 --> Loader Class Initialized
DEBUG - 2011-08-15 00:16:54 --> Controller Class Initialized
DEBUG - 2011-08-15 00:16:54 --> File loaded: application/views/splash/main.php
DEBUG - 2011-08-15 00:16:54 --> Helper loaded: url_helper
DEBUG - 2011-08-15 00:16:54 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-15 00:16:54 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-15 00:16:54 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-15 00:16:54 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-15 00:16:54 --> Final output sent to browser
DEBUG - 2011-08-15 00:16:54 --> Total execution time: 0.0609
DEBUG - 2011-08-15 01:30:21 --> Config Class Initialized
DEBUG - 2011-08-15 01:30:21 --> Hooks Class Initialized
DEBUG - 2011-08-15 01:30:21 --> Utf8 Class Initialized
DEBUG - 2011-08-15 01:30:21 --> UTF-8 Support Enabled
DEBUG - 2011-08-15 01:30:21 --> URI Class Initialized
DEBUG - 2011-08-15 01:30:21 --> Router Class Initialized
ERROR - 2011-08-15 01:30:21 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-08-15 01:31:21 --> Config Class Initialized
DEBUG - 2011-08-15 01:31:21 --> Hooks Class Initialized
DEBUG - 2011-08-15 01:31:21 --> Utf8 Class Initialized
DEBUG - 2011-08-15 01:31:21 --> UTF-8 Support Enabled
DEBUG - 2011-08-15 01:31:21 --> URI Class Initialized
DEBUG - 2011-08-15 01:31:21 --> Router Class Initialized
DEBUG - 2011-08-15 01:31:21 --> Output Class Initialized
DEBUG - 2011-08-15 01:31:21 --> Input Class Initialized
DEBUG - 2011-08-15 01:31:21 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-15 01:31:21 --> Language Class Initialized
DEBUG - 2011-08-15 01:31:21 --> Loader Class Initialized
DEBUG - 2011-08-15 01:31:21 --> Controller Class Initialized
ERROR - 2011-08-15 01:31:21 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-15 01:31:21 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-15 01:31:21 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-15 01:31:21 --> Model Class Initialized
DEBUG - 2011-08-15 01:31:21 --> Model Class Initialized
DEBUG - 2011-08-15 01:31:21 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-15 01:31:21 --> Database Driver Class Initialized
DEBUG - 2011-08-15 01:31:21 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-15 01:31:21 --> Helper loaded: url_helper
DEBUG - 2011-08-15 01:31:21 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-15 01:31:21 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-15 01:31:21 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-15 01:31:21 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-15 01:31:21 --> Final output sent to browser
DEBUG - 2011-08-15 01:31:21 --> Total execution time: 0.0894
DEBUG - 2011-08-15 03:03:54 --> Config Class Initialized
DEBUG - 2011-08-15 03:03:54 --> Hooks Class Initialized
DEBUG - 2011-08-15 03:03:54 --> Utf8 Class Initialized
DEBUG - 2011-08-15 03:03:54 --> UTF-8 Support Enabled
DEBUG - 2011-08-15 03:03:54 --> URI Class Initialized
DEBUG - 2011-08-15 03:03:54 --> Router Class Initialized
DEBUG - 2011-08-15 03:03:54 --> Output Class Initialized
DEBUG - 2011-08-15 03:03:54 --> Input Class Initialized
DEBUG - 2011-08-15 03:03:54 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-15 03:03:54 --> Language Class Initialized
DEBUG - 2011-08-15 03:03:54 --> Loader Class Initialized
DEBUG - 2011-08-15 03:03:54 --> Controller Class Initialized
DEBUG - 2011-08-15 03:03:54 --> Model Class Initialized
DEBUG - 2011-08-15 03:03:54 --> Model Class Initialized
DEBUG - 2011-08-15 03:03:54 --> Model Class Initialized
DEBUG - 2011-08-15 03:03:54 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-15 03:03:54 --> Database Driver Class Initialized
DEBUG - 2011-08-15 03:03:58 --> Config Class Initialized
DEBUG - 2011-08-15 03:03:58 --> Hooks Class Initialized
DEBUG - 2011-08-15 03:03:58 --> Utf8 Class Initialized
DEBUG - 2011-08-15 03:03:58 --> UTF-8 Support Enabled
DEBUG - 2011-08-15 03:03:58 --> URI Class Initialized
DEBUG - 2011-08-15 03:03:58 --> Router Class Initialized
DEBUG - 2011-08-15 03:03:58 --> Output Class Initialized
DEBUG - 2011-08-15 03:03:58 --> Input Class Initialized
DEBUG - 2011-08-15 03:03:58 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-15 03:03:58 --> Language Class Initialized
DEBUG - 2011-08-15 03:03:58 --> Loader Class Initialized
DEBUG - 2011-08-15 03:03:58 --> Controller Class Initialized
ERROR - 2011-08-15 03:03:58 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-15 03:03:58 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-15 03:03:58 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-15 03:03:58 --> Model Class Initialized
DEBUG - 2011-08-15 03:03:58 --> Model Class Initialized
DEBUG - 2011-08-15 03:03:58 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-15 03:03:58 --> Database Driver Class Initialized
DEBUG - 2011-08-15 03:03:59 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-15 03:03:59 --> Helper loaded: url_helper
DEBUG - 2011-08-15 03:03:59 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-15 03:03:59 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-15 03:03:59 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-15 03:03:59 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-15 03:03:59 --> Final output sent to browser
DEBUG - 2011-08-15 03:03:59 --> Total execution time: 1.0234
DEBUG - 2011-08-15 03:04:00 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-15 03:04:00 --> Helper loaded: url_helper
DEBUG - 2011-08-15 03:04:00 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-15 03:04:00 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-15 03:04:00 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-15 03:04:00 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-15 03:04:00 --> Final output sent to browser
DEBUG - 2011-08-15 03:04:00 --> Total execution time: 5.7720
DEBUG - 2011-08-15 03:04:04 --> Config Class Initialized
DEBUG - 2011-08-15 03:04:04 --> Hooks Class Initialized
DEBUG - 2011-08-15 03:04:04 --> Utf8 Class Initialized
DEBUG - 2011-08-15 03:04:04 --> UTF-8 Support Enabled
DEBUG - 2011-08-15 03:04:04 --> URI Class Initialized
DEBUG - 2011-08-15 03:04:04 --> Router Class Initialized
DEBUG - 2011-08-15 03:04:04 --> Output Class Initialized
DEBUG - 2011-08-15 03:04:04 --> Input Class Initialized
DEBUG - 2011-08-15 03:04:04 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-15 03:04:04 --> Language Class Initialized
DEBUG - 2011-08-15 03:04:04 --> Loader Class Initialized
DEBUG - 2011-08-15 03:04:04 --> Controller Class Initialized
DEBUG - 2011-08-15 03:04:04 --> Model Class Initialized
DEBUG - 2011-08-15 03:04:04 --> Model Class Initialized
DEBUG - 2011-08-15 03:04:04 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-15 03:04:04 --> Database Driver Class Initialized
DEBUG - 2011-08-15 03:04:11 --> Final output sent to browser
DEBUG - 2011-08-15 03:04:11 --> Total execution time: 6.8868
DEBUG - 2011-08-15 03:04:15 --> Config Class Initialized
DEBUG - 2011-08-15 03:04:15 --> Hooks Class Initialized
DEBUG - 2011-08-15 03:04:15 --> Utf8 Class Initialized
DEBUG - 2011-08-15 03:04:15 --> UTF-8 Support Enabled
DEBUG - 2011-08-15 03:04:15 --> URI Class Initialized
DEBUG - 2011-08-15 03:04:15 --> Router Class Initialized
ERROR - 2011-08-15 03:04:15 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-15 03:04:17 --> Config Class Initialized
DEBUG - 2011-08-15 03:04:17 --> Hooks Class Initialized
DEBUG - 2011-08-15 03:04:17 --> Utf8 Class Initialized
DEBUG - 2011-08-15 03:04:17 --> UTF-8 Support Enabled
DEBUG - 2011-08-15 03:04:17 --> URI Class Initialized
DEBUG - 2011-08-15 03:04:17 --> Router Class Initialized
ERROR - 2011-08-15 03:04:17 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-15 03:37:28 --> Config Class Initialized
DEBUG - 2011-08-15 03:37:28 --> Hooks Class Initialized
DEBUG - 2011-08-15 03:37:28 --> Utf8 Class Initialized
DEBUG - 2011-08-15 03:37:28 --> UTF-8 Support Enabled
DEBUG - 2011-08-15 03:37:28 --> URI Class Initialized
DEBUG - 2011-08-15 03:37:28 --> Router Class Initialized
DEBUG - 2011-08-15 03:37:29 --> Output Class Initialized
DEBUG - 2011-08-15 03:37:29 --> Input Class Initialized
DEBUG - 2011-08-15 03:37:29 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-15 03:37:29 --> Language Class Initialized
DEBUG - 2011-08-15 03:37:29 --> Loader Class Initialized
DEBUG - 2011-08-15 03:37:30 --> Controller Class Initialized
DEBUG - 2011-08-15 03:37:30 --> Model Class Initialized
DEBUG - 2011-08-15 03:37:30 --> Model Class Initialized
DEBUG - 2011-08-15 03:37:30 --> Model Class Initialized
DEBUG - 2011-08-15 03:37:30 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-15 03:37:31 --> Database Driver Class Initialized
DEBUG - 2011-08-15 03:37:42 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-15 03:37:42 --> Helper loaded: url_helper
DEBUG - 2011-08-15 03:37:42 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-15 03:37:42 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-15 03:37:42 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-15 03:37:42 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-15 03:37:42 --> Final output sent to browser
DEBUG - 2011-08-15 03:37:42 --> Total execution time: 14.3597
DEBUG - 2011-08-15 03:44:01 --> Config Class Initialized
DEBUG - 2011-08-15 03:44:01 --> Hooks Class Initialized
DEBUG - 2011-08-15 03:44:01 --> Utf8 Class Initialized
DEBUG - 2011-08-15 03:44:01 --> UTF-8 Support Enabled
DEBUG - 2011-08-15 03:44:01 --> URI Class Initialized
DEBUG - 2011-08-15 03:44:01 --> Router Class Initialized
DEBUG - 2011-08-15 03:44:01 --> Output Class Initialized
DEBUG - 2011-08-15 03:44:01 --> Input Class Initialized
DEBUG - 2011-08-15 03:44:01 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-15 03:44:01 --> Language Class Initialized
DEBUG - 2011-08-15 03:44:01 --> Loader Class Initialized
DEBUG - 2011-08-15 03:44:01 --> Controller Class Initialized
ERROR - 2011-08-15 03:44:01 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-15 03:44:01 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-15 03:44:01 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-15 03:44:01 --> Model Class Initialized
DEBUG - 2011-08-15 03:44:01 --> Model Class Initialized
DEBUG - 2011-08-15 03:44:01 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-15 03:44:01 --> Database Driver Class Initialized
DEBUG - 2011-08-15 03:44:01 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-15 03:44:01 --> Helper loaded: url_helper
DEBUG - 2011-08-15 03:44:01 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-15 03:44:01 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-15 03:44:01 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-15 03:44:01 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-15 03:44:01 --> Final output sent to browser
DEBUG - 2011-08-15 03:44:01 --> Total execution time: 0.1726
DEBUG - 2011-08-15 03:44:02 --> Config Class Initialized
DEBUG - 2011-08-15 03:44:02 --> Hooks Class Initialized
DEBUG - 2011-08-15 03:44:02 --> Utf8 Class Initialized
DEBUG - 2011-08-15 03:44:02 --> UTF-8 Support Enabled
DEBUG - 2011-08-15 03:44:02 --> URI Class Initialized
DEBUG - 2011-08-15 03:44:02 --> Router Class Initialized
DEBUG - 2011-08-15 03:44:02 --> Output Class Initialized
DEBUG - 2011-08-15 03:44:02 --> Input Class Initialized
DEBUG - 2011-08-15 03:44:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-15 03:44:02 --> Language Class Initialized
DEBUG - 2011-08-15 03:44:02 --> Loader Class Initialized
DEBUG - 2011-08-15 03:44:02 --> Controller Class Initialized
DEBUG - 2011-08-15 03:44:02 --> Model Class Initialized
DEBUG - 2011-08-15 03:44:03 --> Model Class Initialized
DEBUG - 2011-08-15 03:44:03 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-15 03:44:03 --> Database Driver Class Initialized
DEBUG - 2011-08-15 03:44:04 --> Final output sent to browser
DEBUG - 2011-08-15 03:44:04 --> Total execution time: 1.4217
DEBUG - 2011-08-15 03:44:05 --> Config Class Initialized
DEBUG - 2011-08-15 03:44:05 --> Hooks Class Initialized
DEBUG - 2011-08-15 03:44:05 --> Utf8 Class Initialized
DEBUG - 2011-08-15 03:44:05 --> UTF-8 Support Enabled
DEBUG - 2011-08-15 03:44:05 --> URI Class Initialized
DEBUG - 2011-08-15 03:44:05 --> Router Class Initialized
ERROR - 2011-08-15 03:44:05 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-15 03:44:46 --> Config Class Initialized
DEBUG - 2011-08-15 03:44:46 --> Hooks Class Initialized
DEBUG - 2011-08-15 03:44:46 --> Utf8 Class Initialized
DEBUG - 2011-08-15 03:44:46 --> UTF-8 Support Enabled
DEBUG - 2011-08-15 03:44:46 --> URI Class Initialized
DEBUG - 2011-08-15 03:44:46 --> Router Class Initialized
DEBUG - 2011-08-15 03:44:46 --> Output Class Initialized
DEBUG - 2011-08-15 03:44:46 --> Input Class Initialized
DEBUG - 2011-08-15 03:44:46 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-15 03:44:46 --> Language Class Initialized
DEBUG - 2011-08-15 03:44:46 --> Loader Class Initialized
DEBUG - 2011-08-15 03:44:46 --> Controller Class Initialized
ERROR - 2011-08-15 03:44:46 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-15 03:44:46 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-15 03:44:46 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-15 03:44:46 --> Model Class Initialized
DEBUG - 2011-08-15 03:44:46 --> Model Class Initialized
DEBUG - 2011-08-15 03:44:46 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-15 03:44:46 --> Database Driver Class Initialized
DEBUG - 2011-08-15 03:44:47 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-15 03:44:47 --> Helper loaded: url_helper
DEBUG - 2011-08-15 03:44:47 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-15 03:44:47 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-15 03:44:47 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-15 03:44:47 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-15 03:44:47 --> Final output sent to browser
DEBUG - 2011-08-15 03:44:47 --> Total execution time: 0.1057
DEBUG - 2011-08-15 03:44:48 --> Config Class Initialized
DEBUG - 2011-08-15 03:44:48 --> Hooks Class Initialized
DEBUG - 2011-08-15 03:44:48 --> Utf8 Class Initialized
DEBUG - 2011-08-15 03:44:48 --> UTF-8 Support Enabled
DEBUG - 2011-08-15 03:44:48 --> URI Class Initialized
DEBUG - 2011-08-15 03:44:48 --> Router Class Initialized
DEBUG - 2011-08-15 03:44:48 --> Output Class Initialized
DEBUG - 2011-08-15 03:44:48 --> Input Class Initialized
DEBUG - 2011-08-15 03:44:48 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-15 03:44:48 --> Language Class Initialized
DEBUG - 2011-08-15 03:44:48 --> Loader Class Initialized
DEBUG - 2011-08-15 03:44:48 --> Controller Class Initialized
DEBUG - 2011-08-15 03:44:48 --> Model Class Initialized
DEBUG - 2011-08-15 03:44:48 --> Model Class Initialized
DEBUG - 2011-08-15 03:44:48 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-15 03:44:48 --> Database Driver Class Initialized
DEBUG - 2011-08-15 03:44:48 --> Config Class Initialized
DEBUG - 2011-08-15 03:44:48 --> Hooks Class Initialized
DEBUG - 2011-08-15 03:44:48 --> Utf8 Class Initialized
DEBUG - 2011-08-15 03:44:48 --> UTF-8 Support Enabled
DEBUG - 2011-08-15 03:44:48 --> URI Class Initialized
DEBUG - 2011-08-15 03:44:48 --> Router Class Initialized
DEBUG - 2011-08-15 03:44:48 --> Output Class Initialized
DEBUG - 2011-08-15 03:44:48 --> Input Class Initialized
DEBUG - 2011-08-15 03:44:48 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-15 03:44:48 --> Language Class Initialized
DEBUG - 2011-08-15 03:44:48 --> Loader Class Initialized
DEBUG - 2011-08-15 03:44:48 --> Controller Class Initialized
ERROR - 2011-08-15 03:44:48 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-15 03:44:48 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-15 03:44:48 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-15 03:44:48 --> Model Class Initialized
DEBUG - 2011-08-15 03:44:48 --> Model Class Initialized
DEBUG - 2011-08-15 03:44:48 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-15 03:44:48 --> Database Driver Class Initialized
DEBUG - 2011-08-15 03:44:48 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-15 03:44:48 --> Helper loaded: url_helper
DEBUG - 2011-08-15 03:44:48 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-15 03:44:48 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-15 03:44:48 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-15 03:44:48 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-15 03:44:48 --> Final output sent to browser
DEBUG - 2011-08-15 03:44:48 --> Total execution time: 0.0353
DEBUG - 2011-08-15 03:44:48 --> Final output sent to browser
DEBUG - 2011-08-15 03:44:48 --> Total execution time: 0.5958
DEBUG - 2011-08-15 03:44:49 --> Config Class Initialized
DEBUG - 2011-08-15 03:44:49 --> Hooks Class Initialized
DEBUG - 2011-08-15 03:44:49 --> Utf8 Class Initialized
DEBUG - 2011-08-15 03:44:49 --> UTF-8 Support Enabled
DEBUG - 2011-08-15 03:44:49 --> URI Class Initialized
DEBUG - 2011-08-15 03:44:49 --> Router Class Initialized
ERROR - 2011-08-15 03:44:49 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-15 03:45:03 --> Config Class Initialized
DEBUG - 2011-08-15 03:45:03 --> Hooks Class Initialized
DEBUG - 2011-08-15 03:45:03 --> Utf8 Class Initialized
DEBUG - 2011-08-15 03:45:03 --> UTF-8 Support Enabled
DEBUG - 2011-08-15 03:45:03 --> URI Class Initialized
DEBUG - 2011-08-15 03:45:03 --> Router Class Initialized
DEBUG - 2011-08-15 03:45:03 --> Output Class Initialized
DEBUG - 2011-08-15 03:45:03 --> Input Class Initialized
DEBUG - 2011-08-15 03:45:03 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-15 03:45:03 --> Language Class Initialized
DEBUG - 2011-08-15 03:45:03 --> Loader Class Initialized
DEBUG - 2011-08-15 03:45:03 --> Controller Class Initialized
ERROR - 2011-08-15 03:45:03 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-15 03:45:03 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-15 03:45:03 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-15 03:45:03 --> Model Class Initialized
DEBUG - 2011-08-15 03:45:03 --> Model Class Initialized
DEBUG - 2011-08-15 03:45:03 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-15 03:45:03 --> Database Driver Class Initialized
DEBUG - 2011-08-15 03:45:03 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-15 03:45:03 --> Helper loaded: url_helper
DEBUG - 2011-08-15 03:45:03 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-15 03:45:03 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-15 03:45:03 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-15 03:45:03 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-15 03:45:03 --> Final output sent to browser
DEBUG - 2011-08-15 03:45:03 --> Total execution time: 0.2067
DEBUG - 2011-08-15 03:45:04 --> Config Class Initialized
DEBUG - 2011-08-15 03:45:04 --> Hooks Class Initialized
DEBUG - 2011-08-15 03:45:04 --> Utf8 Class Initialized
DEBUG - 2011-08-15 03:45:04 --> UTF-8 Support Enabled
DEBUG - 2011-08-15 03:45:04 --> URI Class Initialized
DEBUG - 2011-08-15 03:45:04 --> Router Class Initialized
DEBUG - 2011-08-15 03:45:04 --> Output Class Initialized
DEBUG - 2011-08-15 03:45:04 --> Input Class Initialized
DEBUG - 2011-08-15 03:45:04 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-15 03:45:04 --> Language Class Initialized
DEBUG - 2011-08-15 03:45:04 --> Loader Class Initialized
DEBUG - 2011-08-15 03:45:04 --> Controller Class Initialized
DEBUG - 2011-08-15 03:45:04 --> Model Class Initialized
DEBUG - 2011-08-15 03:45:04 --> Model Class Initialized
DEBUG - 2011-08-15 03:45:04 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-15 03:45:04 --> Database Driver Class Initialized
DEBUG - 2011-08-15 03:45:05 --> Final output sent to browser
DEBUG - 2011-08-15 03:45:05 --> Total execution time: 0.6239
DEBUG - 2011-08-15 03:45:06 --> Config Class Initialized
DEBUG - 2011-08-15 03:45:06 --> Hooks Class Initialized
DEBUG - 2011-08-15 03:45:06 --> Utf8 Class Initialized
DEBUG - 2011-08-15 03:45:06 --> UTF-8 Support Enabled
DEBUG - 2011-08-15 03:45:06 --> URI Class Initialized
DEBUG - 2011-08-15 03:45:06 --> Router Class Initialized
ERROR - 2011-08-15 03:45:06 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-15 03:45:20 --> Config Class Initialized
DEBUG - 2011-08-15 03:45:20 --> Hooks Class Initialized
DEBUG - 2011-08-15 03:45:20 --> Utf8 Class Initialized
DEBUG - 2011-08-15 03:45:20 --> UTF-8 Support Enabled
DEBUG - 2011-08-15 03:45:20 --> URI Class Initialized
DEBUG - 2011-08-15 03:45:20 --> Router Class Initialized
DEBUG - 2011-08-15 03:45:20 --> Output Class Initialized
DEBUG - 2011-08-15 03:45:20 --> Input Class Initialized
DEBUG - 2011-08-15 03:45:20 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-15 03:45:20 --> Language Class Initialized
DEBUG - 2011-08-15 03:45:20 --> Loader Class Initialized
DEBUG - 2011-08-15 03:45:20 --> Controller Class Initialized
ERROR - 2011-08-15 03:45:20 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-15 03:45:20 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-15 03:45:20 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-15 03:45:20 --> Model Class Initialized
DEBUG - 2011-08-15 03:45:20 --> Model Class Initialized
DEBUG - 2011-08-15 03:45:20 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-15 03:45:20 --> Database Driver Class Initialized
DEBUG - 2011-08-15 03:45:20 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-15 03:45:20 --> Helper loaded: url_helper
DEBUG - 2011-08-15 03:45:20 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-15 03:45:20 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-15 03:45:20 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-15 03:45:20 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-15 03:45:20 --> Final output sent to browser
DEBUG - 2011-08-15 03:45:20 --> Total execution time: 0.0428
DEBUG - 2011-08-15 03:45:21 --> Config Class Initialized
DEBUG - 2011-08-15 03:45:21 --> Hooks Class Initialized
DEBUG - 2011-08-15 03:45:21 --> Utf8 Class Initialized
DEBUG - 2011-08-15 03:45:21 --> UTF-8 Support Enabled
DEBUG - 2011-08-15 03:45:21 --> URI Class Initialized
DEBUG - 2011-08-15 03:45:21 --> Router Class Initialized
DEBUG - 2011-08-15 03:45:21 --> Output Class Initialized
DEBUG - 2011-08-15 03:45:21 --> Input Class Initialized
DEBUG - 2011-08-15 03:45:21 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-15 03:45:21 --> Language Class Initialized
DEBUG - 2011-08-15 03:45:21 --> Loader Class Initialized
DEBUG - 2011-08-15 03:45:21 --> Controller Class Initialized
DEBUG - 2011-08-15 03:45:21 --> Model Class Initialized
DEBUG - 2011-08-15 03:45:21 --> Model Class Initialized
DEBUG - 2011-08-15 03:45:21 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-15 03:45:21 --> Database Driver Class Initialized
DEBUG - 2011-08-15 03:45:23 --> Final output sent to browser
DEBUG - 2011-08-15 03:45:23 --> Total execution time: 1.2775
DEBUG - 2011-08-15 03:45:24 --> Config Class Initialized
DEBUG - 2011-08-15 03:45:24 --> Hooks Class Initialized
DEBUG - 2011-08-15 03:45:24 --> Utf8 Class Initialized
DEBUG - 2011-08-15 03:45:24 --> UTF-8 Support Enabled
DEBUG - 2011-08-15 03:45:24 --> URI Class Initialized
DEBUG - 2011-08-15 03:45:24 --> Router Class Initialized
ERROR - 2011-08-15 03:45:24 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-15 03:45:24 --> Config Class Initialized
DEBUG - 2011-08-15 03:45:24 --> Hooks Class Initialized
DEBUG - 2011-08-15 03:45:24 --> Utf8 Class Initialized
DEBUG - 2011-08-15 03:45:24 --> UTF-8 Support Enabled
DEBUG - 2011-08-15 03:45:24 --> URI Class Initialized
DEBUG - 2011-08-15 03:45:24 --> Router Class Initialized
DEBUG - 2011-08-15 03:45:24 --> Output Class Initialized
DEBUG - 2011-08-15 03:45:24 --> Input Class Initialized
DEBUG - 2011-08-15 03:45:24 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-15 03:45:24 --> Language Class Initialized
DEBUG - 2011-08-15 03:45:24 --> Loader Class Initialized
DEBUG - 2011-08-15 03:45:24 --> Controller Class Initialized
ERROR - 2011-08-15 03:45:24 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-15 03:45:24 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-15 03:45:24 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-15 03:45:24 --> Model Class Initialized
DEBUG - 2011-08-15 03:45:24 --> Model Class Initialized
DEBUG - 2011-08-15 03:45:24 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-15 03:45:24 --> Database Driver Class Initialized
DEBUG - 2011-08-15 03:45:24 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-15 03:45:24 --> Helper loaded: url_helper
DEBUG - 2011-08-15 03:45:24 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-15 03:45:24 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-15 03:45:24 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-15 03:45:24 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-15 03:45:24 --> Final output sent to browser
DEBUG - 2011-08-15 03:45:24 --> Total execution time: 0.0705
DEBUG - 2011-08-15 03:45:33 --> Config Class Initialized
DEBUG - 2011-08-15 03:45:33 --> Hooks Class Initialized
DEBUG - 2011-08-15 03:45:33 --> Utf8 Class Initialized
DEBUG - 2011-08-15 03:45:33 --> UTF-8 Support Enabled
DEBUG - 2011-08-15 03:45:33 --> URI Class Initialized
DEBUG - 2011-08-15 03:45:33 --> Router Class Initialized
DEBUG - 2011-08-15 03:45:33 --> Output Class Initialized
DEBUG - 2011-08-15 03:45:33 --> Input Class Initialized
DEBUG - 2011-08-15 03:45:33 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-15 03:45:33 --> Language Class Initialized
DEBUG - 2011-08-15 03:45:33 --> Loader Class Initialized
DEBUG - 2011-08-15 03:45:33 --> Controller Class Initialized
ERROR - 2011-08-15 03:45:33 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-15 03:45:33 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-15 03:45:33 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-15 03:45:33 --> Model Class Initialized
DEBUG - 2011-08-15 03:45:33 --> Model Class Initialized
DEBUG - 2011-08-15 03:45:33 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-15 03:45:33 --> Database Driver Class Initialized
DEBUG - 2011-08-15 03:45:33 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-15 03:45:33 --> Helper loaded: url_helper
DEBUG - 2011-08-15 03:45:33 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-15 03:45:33 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-15 03:45:33 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-15 03:45:33 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-15 03:45:33 --> Final output sent to browser
DEBUG - 2011-08-15 03:45:33 --> Total execution time: 0.0298
DEBUG - 2011-08-15 03:45:33 --> Config Class Initialized
DEBUG - 2011-08-15 03:45:33 --> Hooks Class Initialized
DEBUG - 2011-08-15 03:45:33 --> Utf8 Class Initialized
DEBUG - 2011-08-15 03:45:33 --> UTF-8 Support Enabled
DEBUG - 2011-08-15 03:45:33 --> URI Class Initialized
DEBUG - 2011-08-15 03:45:33 --> Router Class Initialized
DEBUG - 2011-08-15 03:45:33 --> Output Class Initialized
DEBUG - 2011-08-15 03:45:33 --> Input Class Initialized
DEBUG - 2011-08-15 03:45:33 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-15 03:45:33 --> Language Class Initialized
DEBUG - 2011-08-15 03:45:33 --> Loader Class Initialized
DEBUG - 2011-08-15 03:45:33 --> Controller Class Initialized
DEBUG - 2011-08-15 03:45:33 --> Model Class Initialized
DEBUG - 2011-08-15 03:45:33 --> Model Class Initialized
DEBUG - 2011-08-15 03:45:33 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-15 03:45:33 --> Database Driver Class Initialized
DEBUG - 2011-08-15 03:45:35 --> Final output sent to browser
DEBUG - 2011-08-15 03:45:35 --> Total execution time: 2.0824
DEBUG - 2011-08-15 03:45:36 --> Config Class Initialized
DEBUG - 2011-08-15 03:45:36 --> Hooks Class Initialized
DEBUG - 2011-08-15 03:45:36 --> Utf8 Class Initialized
DEBUG - 2011-08-15 03:45:36 --> UTF-8 Support Enabled
DEBUG - 2011-08-15 03:45:36 --> URI Class Initialized
DEBUG - 2011-08-15 03:45:36 --> Router Class Initialized
ERROR - 2011-08-15 03:45:36 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-15 03:45:44 --> Config Class Initialized
DEBUG - 2011-08-15 03:45:44 --> Hooks Class Initialized
DEBUG - 2011-08-15 03:45:44 --> Utf8 Class Initialized
DEBUG - 2011-08-15 03:45:44 --> UTF-8 Support Enabled
DEBUG - 2011-08-15 03:45:44 --> URI Class Initialized
DEBUG - 2011-08-15 03:45:44 --> Router Class Initialized
DEBUG - 2011-08-15 03:45:44 --> Output Class Initialized
DEBUG - 2011-08-15 03:45:44 --> Input Class Initialized
DEBUG - 2011-08-15 03:45:44 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-15 03:45:44 --> Language Class Initialized
DEBUG - 2011-08-15 03:45:44 --> Loader Class Initialized
DEBUG - 2011-08-15 03:45:44 --> Controller Class Initialized
ERROR - 2011-08-15 03:45:44 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-15 03:45:44 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-15 03:45:44 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-15 03:45:44 --> Model Class Initialized
DEBUG - 2011-08-15 03:45:44 --> Model Class Initialized
DEBUG - 2011-08-15 03:45:44 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-15 03:45:44 --> Database Driver Class Initialized
DEBUG - 2011-08-15 03:45:44 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-15 03:45:44 --> Helper loaded: url_helper
DEBUG - 2011-08-15 03:45:44 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-15 03:45:44 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-15 03:45:44 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-15 03:45:44 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-15 03:45:44 --> Final output sent to browser
DEBUG - 2011-08-15 03:45:44 --> Total execution time: 0.0661
DEBUG - 2011-08-15 03:45:45 --> Config Class Initialized
DEBUG - 2011-08-15 03:45:45 --> Hooks Class Initialized
DEBUG - 2011-08-15 03:45:45 --> Utf8 Class Initialized
DEBUG - 2011-08-15 03:45:45 --> UTF-8 Support Enabled
DEBUG - 2011-08-15 03:45:45 --> URI Class Initialized
DEBUG - 2011-08-15 03:45:45 --> Router Class Initialized
DEBUG - 2011-08-15 03:45:45 --> Output Class Initialized
DEBUG - 2011-08-15 03:45:45 --> Input Class Initialized
DEBUG - 2011-08-15 03:45:45 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-15 03:45:45 --> Language Class Initialized
DEBUG - 2011-08-15 03:45:45 --> Loader Class Initialized
DEBUG - 2011-08-15 03:45:45 --> Controller Class Initialized
DEBUG - 2011-08-15 03:45:45 --> Model Class Initialized
DEBUG - 2011-08-15 03:45:45 --> Model Class Initialized
DEBUG - 2011-08-15 03:45:45 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-15 03:45:45 --> Database Driver Class Initialized
DEBUG - 2011-08-15 03:45:46 --> Final output sent to browser
DEBUG - 2011-08-15 03:45:46 --> Total execution time: 0.7127
DEBUG - 2011-08-15 03:45:47 --> Config Class Initialized
DEBUG - 2011-08-15 03:45:47 --> Hooks Class Initialized
DEBUG - 2011-08-15 03:45:47 --> Utf8 Class Initialized
DEBUG - 2011-08-15 03:45:47 --> UTF-8 Support Enabled
DEBUG - 2011-08-15 03:45:47 --> URI Class Initialized
DEBUG - 2011-08-15 03:45:47 --> Router Class Initialized
ERROR - 2011-08-15 03:45:47 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-15 03:46:22 --> Config Class Initialized
DEBUG - 2011-08-15 03:46:22 --> Hooks Class Initialized
DEBUG - 2011-08-15 03:46:22 --> Utf8 Class Initialized
DEBUG - 2011-08-15 03:46:22 --> UTF-8 Support Enabled
DEBUG - 2011-08-15 03:46:22 --> URI Class Initialized
DEBUG - 2011-08-15 03:46:22 --> Router Class Initialized
DEBUG - 2011-08-15 03:46:22 --> Output Class Initialized
DEBUG - 2011-08-15 03:46:22 --> Input Class Initialized
DEBUG - 2011-08-15 03:46:22 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-15 03:46:22 --> Language Class Initialized
DEBUG - 2011-08-15 03:46:22 --> Loader Class Initialized
DEBUG - 2011-08-15 03:46:22 --> Controller Class Initialized
ERROR - 2011-08-15 03:46:22 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-15 03:46:22 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-15 03:46:22 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-15 03:46:22 --> Model Class Initialized
DEBUG - 2011-08-15 03:46:22 --> Model Class Initialized
DEBUG - 2011-08-15 03:46:22 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-15 03:46:22 --> Database Driver Class Initialized
DEBUG - 2011-08-15 03:46:22 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-15 03:46:22 --> Helper loaded: url_helper
DEBUG - 2011-08-15 03:46:22 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-15 03:46:22 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-15 03:46:22 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-15 03:46:22 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-15 03:46:22 --> Final output sent to browser
DEBUG - 2011-08-15 03:46:22 --> Total execution time: 0.0286
DEBUG - 2011-08-15 03:46:23 --> Config Class Initialized
DEBUG - 2011-08-15 03:46:23 --> Hooks Class Initialized
DEBUG - 2011-08-15 03:46:23 --> Utf8 Class Initialized
DEBUG - 2011-08-15 03:46:23 --> UTF-8 Support Enabled
DEBUG - 2011-08-15 03:46:23 --> URI Class Initialized
DEBUG - 2011-08-15 03:46:23 --> Router Class Initialized
DEBUG - 2011-08-15 03:46:23 --> Output Class Initialized
DEBUG - 2011-08-15 03:46:23 --> Input Class Initialized
DEBUG - 2011-08-15 03:46:23 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-15 03:46:23 --> Language Class Initialized
DEBUG - 2011-08-15 03:46:23 --> Loader Class Initialized
DEBUG - 2011-08-15 03:46:23 --> Controller Class Initialized
DEBUG - 2011-08-15 03:46:23 --> Model Class Initialized
DEBUG - 2011-08-15 03:46:23 --> Model Class Initialized
DEBUG - 2011-08-15 03:46:23 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-15 03:46:23 --> Database Driver Class Initialized
DEBUG - 2011-08-15 03:46:24 --> Final output sent to browser
DEBUG - 2011-08-15 03:46:24 --> Total execution time: 0.8605
DEBUG - 2011-08-15 03:46:25 --> Config Class Initialized
DEBUG - 2011-08-15 03:46:25 --> Hooks Class Initialized
DEBUG - 2011-08-15 03:46:25 --> Utf8 Class Initialized
DEBUG - 2011-08-15 03:46:25 --> UTF-8 Support Enabled
DEBUG - 2011-08-15 03:46:25 --> URI Class Initialized
DEBUG - 2011-08-15 03:46:25 --> Router Class Initialized
ERROR - 2011-08-15 03:46:25 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-15 03:46:30 --> Config Class Initialized
DEBUG - 2011-08-15 03:46:30 --> Hooks Class Initialized
DEBUG - 2011-08-15 03:46:30 --> Utf8 Class Initialized
DEBUG - 2011-08-15 03:46:30 --> UTF-8 Support Enabled
DEBUG - 2011-08-15 03:46:30 --> URI Class Initialized
DEBUG - 2011-08-15 03:46:30 --> Router Class Initialized
DEBUG - 2011-08-15 03:46:30 --> Output Class Initialized
DEBUG - 2011-08-15 03:46:30 --> Input Class Initialized
DEBUG - 2011-08-15 03:46:30 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-15 03:46:30 --> Language Class Initialized
DEBUG - 2011-08-15 03:46:30 --> Loader Class Initialized
DEBUG - 2011-08-15 03:46:30 --> Controller Class Initialized
ERROR - 2011-08-15 03:46:30 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-15 03:46:30 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-15 03:46:30 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-15 03:46:30 --> Model Class Initialized
DEBUG - 2011-08-15 03:46:30 --> Model Class Initialized
DEBUG - 2011-08-15 03:46:30 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-15 03:46:30 --> Database Driver Class Initialized
DEBUG - 2011-08-15 03:46:30 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-15 03:46:30 --> Helper loaded: url_helper
DEBUG - 2011-08-15 03:46:30 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-15 03:46:30 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-15 03:46:30 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-15 03:46:30 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-15 03:46:30 --> Final output sent to browser
DEBUG - 2011-08-15 03:46:30 --> Total execution time: 0.0284
DEBUG - 2011-08-15 03:46:31 --> Config Class Initialized
DEBUG - 2011-08-15 03:46:31 --> Hooks Class Initialized
DEBUG - 2011-08-15 03:46:31 --> Utf8 Class Initialized
DEBUG - 2011-08-15 03:46:31 --> UTF-8 Support Enabled
DEBUG - 2011-08-15 03:46:31 --> URI Class Initialized
DEBUG - 2011-08-15 03:46:31 --> Router Class Initialized
DEBUG - 2011-08-15 03:46:31 --> Output Class Initialized
DEBUG - 2011-08-15 03:46:31 --> Input Class Initialized
DEBUG - 2011-08-15 03:46:31 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-15 03:46:31 --> Language Class Initialized
DEBUG - 2011-08-15 03:46:31 --> Loader Class Initialized
DEBUG - 2011-08-15 03:46:31 --> Controller Class Initialized
DEBUG - 2011-08-15 03:46:31 --> Model Class Initialized
DEBUG - 2011-08-15 03:46:31 --> Model Class Initialized
DEBUG - 2011-08-15 03:46:31 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-15 03:46:31 --> Database Driver Class Initialized
DEBUG - 2011-08-15 03:46:32 --> Final output sent to browser
DEBUG - 2011-08-15 03:46:32 --> Total execution time: 0.5475
DEBUG - 2011-08-15 03:46:33 --> Config Class Initialized
DEBUG - 2011-08-15 03:46:33 --> Hooks Class Initialized
DEBUG - 2011-08-15 03:46:33 --> Utf8 Class Initialized
DEBUG - 2011-08-15 03:46:33 --> UTF-8 Support Enabled
DEBUG - 2011-08-15 03:46:33 --> URI Class Initialized
DEBUG - 2011-08-15 03:46:33 --> Router Class Initialized
ERROR - 2011-08-15 03:46:33 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-15 03:46:36 --> Config Class Initialized
DEBUG - 2011-08-15 03:46:36 --> Hooks Class Initialized
DEBUG - 2011-08-15 03:46:36 --> Utf8 Class Initialized
DEBUG - 2011-08-15 03:46:36 --> UTF-8 Support Enabled
DEBUG - 2011-08-15 03:46:36 --> URI Class Initialized
DEBUG - 2011-08-15 03:46:36 --> Router Class Initialized
DEBUG - 2011-08-15 03:46:36 --> Output Class Initialized
DEBUG - 2011-08-15 03:46:36 --> Input Class Initialized
DEBUG - 2011-08-15 03:46:36 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-15 03:46:36 --> Language Class Initialized
DEBUG - 2011-08-15 03:46:36 --> Loader Class Initialized
DEBUG - 2011-08-15 03:46:36 --> Controller Class Initialized
ERROR - 2011-08-15 03:46:36 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-15 03:46:36 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-15 03:46:36 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-15 03:46:36 --> Model Class Initialized
DEBUG - 2011-08-15 03:46:36 --> Model Class Initialized
DEBUG - 2011-08-15 03:46:36 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-15 03:46:36 --> Database Driver Class Initialized
DEBUG - 2011-08-15 03:46:36 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-15 03:46:36 --> Helper loaded: url_helper
DEBUG - 2011-08-15 03:46:36 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-15 03:46:36 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-15 03:46:36 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-15 03:46:36 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-15 03:46:36 --> Final output sent to browser
DEBUG - 2011-08-15 03:46:36 --> Total execution time: 0.0273
DEBUG - 2011-08-15 03:46:37 --> Config Class Initialized
DEBUG - 2011-08-15 03:46:37 --> Hooks Class Initialized
DEBUG - 2011-08-15 03:46:37 --> Utf8 Class Initialized
DEBUG - 2011-08-15 03:46:37 --> UTF-8 Support Enabled
DEBUG - 2011-08-15 03:46:37 --> URI Class Initialized
DEBUG - 2011-08-15 03:46:37 --> Router Class Initialized
DEBUG - 2011-08-15 03:46:37 --> Output Class Initialized
DEBUG - 2011-08-15 03:46:37 --> Input Class Initialized
DEBUG - 2011-08-15 03:46:37 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-15 03:46:37 --> Language Class Initialized
DEBUG - 2011-08-15 03:46:37 --> Loader Class Initialized
DEBUG - 2011-08-15 03:46:37 --> Controller Class Initialized
DEBUG - 2011-08-15 03:46:37 --> Model Class Initialized
DEBUG - 2011-08-15 03:46:37 --> Model Class Initialized
DEBUG - 2011-08-15 03:46:37 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-15 03:46:37 --> Database Driver Class Initialized
DEBUG - 2011-08-15 03:46:38 --> Final output sent to browser
DEBUG - 2011-08-15 03:46:38 --> Total execution time: 1.0974
DEBUG - 2011-08-15 03:46:39 --> Config Class Initialized
DEBUG - 2011-08-15 03:46:39 --> Hooks Class Initialized
DEBUG - 2011-08-15 03:46:39 --> Utf8 Class Initialized
DEBUG - 2011-08-15 03:46:39 --> UTF-8 Support Enabled
DEBUG - 2011-08-15 03:46:39 --> URI Class Initialized
DEBUG - 2011-08-15 03:46:39 --> Router Class Initialized
ERROR - 2011-08-15 03:46:39 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-15 03:46:48 --> Config Class Initialized
DEBUG - 2011-08-15 03:46:48 --> Hooks Class Initialized
DEBUG - 2011-08-15 03:46:48 --> Utf8 Class Initialized
DEBUG - 2011-08-15 03:46:48 --> UTF-8 Support Enabled
DEBUG - 2011-08-15 03:46:48 --> URI Class Initialized
DEBUG - 2011-08-15 03:46:48 --> Router Class Initialized
DEBUG - 2011-08-15 03:46:48 --> Output Class Initialized
DEBUG - 2011-08-15 03:46:48 --> Input Class Initialized
DEBUG - 2011-08-15 03:46:48 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-15 03:46:48 --> Language Class Initialized
DEBUG - 2011-08-15 03:46:48 --> Loader Class Initialized
DEBUG - 2011-08-15 03:46:48 --> Controller Class Initialized
ERROR - 2011-08-15 03:46:48 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-15 03:46:48 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-15 03:46:48 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-15 03:46:48 --> Model Class Initialized
DEBUG - 2011-08-15 03:46:48 --> Model Class Initialized
DEBUG - 2011-08-15 03:46:48 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-15 03:46:48 --> Database Driver Class Initialized
DEBUG - 2011-08-15 03:46:48 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-15 03:46:48 --> Helper loaded: url_helper
DEBUG - 2011-08-15 03:46:48 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-15 03:46:48 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-15 03:46:48 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-15 03:46:48 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-15 03:46:48 --> Final output sent to browser
DEBUG - 2011-08-15 03:46:48 --> Total execution time: 0.0351
DEBUG - 2011-08-15 03:46:48 --> Config Class Initialized
DEBUG - 2011-08-15 03:46:48 --> Hooks Class Initialized
DEBUG - 2011-08-15 03:46:48 --> Utf8 Class Initialized
DEBUG - 2011-08-15 03:46:48 --> UTF-8 Support Enabled
DEBUG - 2011-08-15 03:46:48 --> URI Class Initialized
DEBUG - 2011-08-15 03:46:48 --> Router Class Initialized
DEBUG - 2011-08-15 03:46:48 --> Output Class Initialized
DEBUG - 2011-08-15 03:46:48 --> Input Class Initialized
DEBUG - 2011-08-15 03:46:48 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-15 03:46:48 --> Language Class Initialized
DEBUG - 2011-08-15 03:46:48 --> Loader Class Initialized
DEBUG - 2011-08-15 03:46:48 --> Controller Class Initialized
DEBUG - 2011-08-15 03:46:48 --> Model Class Initialized
DEBUG - 2011-08-15 03:46:48 --> Model Class Initialized
DEBUG - 2011-08-15 03:46:48 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-15 03:46:48 --> Database Driver Class Initialized
DEBUG - 2011-08-15 03:46:50 --> Final output sent to browser
DEBUG - 2011-08-15 03:46:50 --> Total execution time: 1.9406
DEBUG - 2011-08-15 03:46:51 --> Config Class Initialized
DEBUG - 2011-08-15 03:46:51 --> Hooks Class Initialized
DEBUG - 2011-08-15 03:46:51 --> Utf8 Class Initialized
DEBUG - 2011-08-15 03:46:51 --> UTF-8 Support Enabled
DEBUG - 2011-08-15 03:46:51 --> URI Class Initialized
DEBUG - 2011-08-15 03:46:51 --> Router Class Initialized
ERROR - 2011-08-15 03:46:51 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-15 03:47:28 --> Config Class Initialized
DEBUG - 2011-08-15 03:47:28 --> Hooks Class Initialized
DEBUG - 2011-08-15 03:47:28 --> Utf8 Class Initialized
DEBUG - 2011-08-15 03:47:28 --> UTF-8 Support Enabled
DEBUG - 2011-08-15 03:47:28 --> URI Class Initialized
DEBUG - 2011-08-15 03:47:28 --> Router Class Initialized
DEBUG - 2011-08-15 03:47:28 --> Output Class Initialized
DEBUG - 2011-08-15 03:47:28 --> Input Class Initialized
DEBUG - 2011-08-15 03:47:28 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-15 03:47:28 --> Language Class Initialized
DEBUG - 2011-08-15 03:47:28 --> Loader Class Initialized
DEBUG - 2011-08-15 03:47:28 --> Controller Class Initialized
ERROR - 2011-08-15 03:47:28 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-15 03:47:28 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-15 03:47:28 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-15 03:47:28 --> Model Class Initialized
DEBUG - 2011-08-15 03:47:28 --> Model Class Initialized
DEBUG - 2011-08-15 03:47:28 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-15 03:47:28 --> Database Driver Class Initialized
DEBUG - 2011-08-15 03:47:28 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-15 03:47:28 --> Helper loaded: url_helper
DEBUG - 2011-08-15 03:47:28 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-15 03:47:28 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-15 03:47:28 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-15 03:47:28 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-15 03:47:28 --> Final output sent to browser
DEBUG - 2011-08-15 03:47:28 --> Total execution time: 0.0404
DEBUG - 2011-08-15 03:47:29 --> Config Class Initialized
DEBUG - 2011-08-15 03:47:29 --> Hooks Class Initialized
DEBUG - 2011-08-15 03:47:29 --> Utf8 Class Initialized
DEBUG - 2011-08-15 03:47:29 --> UTF-8 Support Enabled
DEBUG - 2011-08-15 03:47:29 --> URI Class Initialized
DEBUG - 2011-08-15 03:47:29 --> Router Class Initialized
DEBUG - 2011-08-15 03:47:29 --> Output Class Initialized
DEBUG - 2011-08-15 03:47:29 --> Input Class Initialized
DEBUG - 2011-08-15 03:47:29 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-15 03:47:29 --> Language Class Initialized
DEBUG - 2011-08-15 03:47:29 --> Loader Class Initialized
DEBUG - 2011-08-15 03:47:29 --> Controller Class Initialized
DEBUG - 2011-08-15 03:47:29 --> Model Class Initialized
DEBUG - 2011-08-15 03:47:29 --> Model Class Initialized
DEBUG - 2011-08-15 03:47:29 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-15 03:47:29 --> Database Driver Class Initialized
DEBUG - 2011-08-15 03:47:31 --> Final output sent to browser
DEBUG - 2011-08-15 03:47:31 --> Total execution time: 1.9367
DEBUG - 2011-08-15 03:47:32 --> Config Class Initialized
DEBUG - 2011-08-15 03:47:32 --> Hooks Class Initialized
DEBUG - 2011-08-15 03:47:32 --> Utf8 Class Initialized
DEBUG - 2011-08-15 03:47:32 --> UTF-8 Support Enabled
DEBUG - 2011-08-15 03:47:32 --> URI Class Initialized
DEBUG - 2011-08-15 03:47:32 --> Router Class Initialized
ERROR - 2011-08-15 03:47:32 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-15 03:47:38 --> Config Class Initialized
DEBUG - 2011-08-15 03:47:38 --> Hooks Class Initialized
DEBUG - 2011-08-15 03:47:38 --> Utf8 Class Initialized
DEBUG - 2011-08-15 03:47:38 --> UTF-8 Support Enabled
DEBUG - 2011-08-15 03:47:38 --> URI Class Initialized
DEBUG - 2011-08-15 03:47:38 --> Router Class Initialized
DEBUG - 2011-08-15 03:47:38 --> Output Class Initialized
DEBUG - 2011-08-15 03:47:38 --> Input Class Initialized
DEBUG - 2011-08-15 03:47:38 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-15 03:47:38 --> Language Class Initialized
DEBUG - 2011-08-15 03:47:38 --> Loader Class Initialized
DEBUG - 2011-08-15 03:47:38 --> Controller Class Initialized
ERROR - 2011-08-15 03:47:38 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-15 03:47:38 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-15 03:47:38 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-15 03:47:38 --> Model Class Initialized
DEBUG - 2011-08-15 03:47:38 --> Model Class Initialized
DEBUG - 2011-08-15 03:47:38 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-15 03:47:38 --> Database Driver Class Initialized
DEBUG - 2011-08-15 03:47:38 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-15 03:47:38 --> Helper loaded: url_helper
DEBUG - 2011-08-15 03:47:38 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-15 03:47:38 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-15 03:47:38 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-15 03:47:38 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-15 03:47:38 --> Final output sent to browser
DEBUG - 2011-08-15 03:47:38 --> Total execution time: 0.0610
DEBUG - 2011-08-15 03:47:39 --> Config Class Initialized
DEBUG - 2011-08-15 03:47:39 --> Hooks Class Initialized
DEBUG - 2011-08-15 03:47:39 --> Utf8 Class Initialized
DEBUG - 2011-08-15 03:47:39 --> UTF-8 Support Enabled
DEBUG - 2011-08-15 03:47:39 --> URI Class Initialized
DEBUG - 2011-08-15 03:47:39 --> Router Class Initialized
DEBUG - 2011-08-15 03:47:39 --> Output Class Initialized
DEBUG - 2011-08-15 03:47:39 --> Input Class Initialized
DEBUG - 2011-08-15 03:47:39 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-15 03:47:39 --> Language Class Initialized
DEBUG - 2011-08-15 03:47:39 --> Loader Class Initialized
DEBUG - 2011-08-15 03:47:39 --> Controller Class Initialized
ERROR - 2011-08-15 03:47:39 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-15 03:47:39 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-15 03:47:39 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-15 03:47:39 --> Model Class Initialized
DEBUG - 2011-08-15 03:47:39 --> Model Class Initialized
DEBUG - 2011-08-15 03:47:39 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-15 03:47:39 --> Database Driver Class Initialized
DEBUG - 2011-08-15 03:47:39 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-15 03:47:39 --> Helper loaded: url_helper
DEBUG - 2011-08-15 03:47:39 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-15 03:47:39 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-15 03:47:39 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-15 03:47:39 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-15 03:47:39 --> Final output sent to browser
DEBUG - 2011-08-15 03:47:39 --> Total execution time: 0.2036
DEBUG - 2011-08-15 03:47:40 --> Config Class Initialized
DEBUG - 2011-08-15 03:47:40 --> Hooks Class Initialized
DEBUG - 2011-08-15 03:47:40 --> Utf8 Class Initialized
DEBUG - 2011-08-15 03:47:40 --> UTF-8 Support Enabled
DEBUG - 2011-08-15 03:47:40 --> URI Class Initialized
DEBUG - 2011-08-15 03:47:40 --> Router Class Initialized
DEBUG - 2011-08-15 03:47:40 --> Output Class Initialized
DEBUG - 2011-08-15 03:47:40 --> Input Class Initialized
DEBUG - 2011-08-15 03:47:40 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-15 03:47:40 --> Language Class Initialized
DEBUG - 2011-08-15 03:47:40 --> Loader Class Initialized
DEBUG - 2011-08-15 03:47:40 --> Controller Class Initialized
DEBUG - 2011-08-15 03:47:40 --> Model Class Initialized
DEBUG - 2011-08-15 03:47:40 --> Model Class Initialized
DEBUG - 2011-08-15 03:47:40 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-15 03:47:40 --> Database Driver Class Initialized
DEBUG - 2011-08-15 03:47:41 --> Final output sent to browser
DEBUG - 2011-08-15 03:47:41 --> Total execution time: 1.2203
DEBUG - 2011-08-15 03:47:41 --> Config Class Initialized
DEBUG - 2011-08-15 03:47:41 --> Hooks Class Initialized
DEBUG - 2011-08-15 03:47:41 --> Utf8 Class Initialized
DEBUG - 2011-08-15 03:47:41 --> UTF-8 Support Enabled
DEBUG - 2011-08-15 03:47:41 --> URI Class Initialized
DEBUG - 2011-08-15 03:47:41 --> Router Class Initialized
DEBUG - 2011-08-15 03:47:41 --> Output Class Initialized
DEBUG - 2011-08-15 03:47:41 --> Input Class Initialized
DEBUG - 2011-08-15 03:47:41 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-15 03:47:41 --> Language Class Initialized
DEBUG - 2011-08-15 03:47:41 --> Loader Class Initialized
DEBUG - 2011-08-15 03:47:41 --> Controller Class Initialized
ERROR - 2011-08-15 03:47:41 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-15 03:47:41 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-15 03:47:41 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-15 03:47:41 --> Model Class Initialized
DEBUG - 2011-08-15 03:47:41 --> Model Class Initialized
DEBUG - 2011-08-15 03:47:41 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-15 03:47:41 --> Database Driver Class Initialized
DEBUG - 2011-08-15 03:47:41 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-15 03:47:41 --> Helper loaded: url_helper
DEBUG - 2011-08-15 03:47:41 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-15 03:47:41 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-15 03:47:41 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-15 03:47:41 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-15 03:47:41 --> Final output sent to browser
DEBUG - 2011-08-15 03:47:41 --> Total execution time: 0.1336
DEBUG - 2011-08-15 03:47:43 --> Config Class Initialized
DEBUG - 2011-08-15 03:47:43 --> Hooks Class Initialized
DEBUG - 2011-08-15 03:47:43 --> Utf8 Class Initialized
DEBUG - 2011-08-15 03:47:43 --> UTF-8 Support Enabled
DEBUG - 2011-08-15 03:47:43 --> URI Class Initialized
DEBUG - 2011-08-15 03:47:43 --> Router Class Initialized
ERROR - 2011-08-15 03:47:43 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-15 03:47:49 --> Config Class Initialized
DEBUG - 2011-08-15 03:47:49 --> Hooks Class Initialized
DEBUG - 2011-08-15 03:47:49 --> Utf8 Class Initialized
DEBUG - 2011-08-15 03:47:49 --> UTF-8 Support Enabled
DEBUG - 2011-08-15 03:47:49 --> URI Class Initialized
DEBUG - 2011-08-15 03:47:49 --> Router Class Initialized
DEBUG - 2011-08-15 03:47:49 --> Output Class Initialized
DEBUG - 2011-08-15 03:47:49 --> Input Class Initialized
DEBUG - 2011-08-15 03:47:49 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-15 03:47:49 --> Language Class Initialized
DEBUG - 2011-08-15 03:47:49 --> Loader Class Initialized
DEBUG - 2011-08-15 03:47:49 --> Controller Class Initialized
ERROR - 2011-08-15 03:47:49 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-15 03:47:49 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-15 03:47:49 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-15 03:47:49 --> Model Class Initialized
DEBUG - 2011-08-15 03:47:49 --> Model Class Initialized
DEBUG - 2011-08-15 03:47:49 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-15 03:47:49 --> Database Driver Class Initialized
DEBUG - 2011-08-15 03:47:49 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-15 03:47:49 --> Helper loaded: url_helper
DEBUG - 2011-08-15 03:47:49 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-15 03:47:49 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-15 03:47:49 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-15 03:47:49 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-15 03:47:49 --> Final output sent to browser
DEBUG - 2011-08-15 03:47:49 --> Total execution time: 0.0979
DEBUG - 2011-08-15 03:47:50 --> Config Class Initialized
DEBUG - 2011-08-15 03:47:50 --> Hooks Class Initialized
DEBUG - 2011-08-15 03:47:50 --> Utf8 Class Initialized
DEBUG - 2011-08-15 03:47:50 --> UTF-8 Support Enabled
DEBUG - 2011-08-15 03:47:50 --> URI Class Initialized
DEBUG - 2011-08-15 03:47:50 --> Router Class Initialized
DEBUG - 2011-08-15 03:47:50 --> Output Class Initialized
DEBUG - 2011-08-15 03:47:50 --> Input Class Initialized
DEBUG - 2011-08-15 03:47:50 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-15 03:47:50 --> Language Class Initialized
DEBUG - 2011-08-15 03:47:50 --> Loader Class Initialized
DEBUG - 2011-08-15 03:47:50 --> Controller Class Initialized
DEBUG - 2011-08-15 03:47:50 --> Model Class Initialized
DEBUG - 2011-08-15 03:47:50 --> Model Class Initialized
DEBUG - 2011-08-15 03:47:50 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-15 03:47:50 --> Database Driver Class Initialized
DEBUG - 2011-08-15 03:47:52 --> Final output sent to browser
DEBUG - 2011-08-15 03:47:52 --> Total execution time: 1.6433
DEBUG - 2011-08-15 03:47:53 --> Config Class Initialized
DEBUG - 2011-08-15 03:47:53 --> Hooks Class Initialized
DEBUG - 2011-08-15 03:47:53 --> Utf8 Class Initialized
DEBUG - 2011-08-15 03:47:53 --> UTF-8 Support Enabled
DEBUG - 2011-08-15 03:47:53 --> URI Class Initialized
DEBUG - 2011-08-15 03:47:53 --> Router Class Initialized
ERROR - 2011-08-15 03:47:53 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-15 03:47:57 --> Config Class Initialized
DEBUG - 2011-08-15 03:47:57 --> Hooks Class Initialized
DEBUG - 2011-08-15 03:47:57 --> Utf8 Class Initialized
DEBUG - 2011-08-15 03:47:57 --> UTF-8 Support Enabled
DEBUG - 2011-08-15 03:47:57 --> URI Class Initialized
DEBUG - 2011-08-15 03:47:57 --> Router Class Initialized
DEBUG - 2011-08-15 03:47:57 --> Output Class Initialized
DEBUG - 2011-08-15 03:47:58 --> Input Class Initialized
DEBUG - 2011-08-15 03:47:58 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-15 03:47:58 --> Language Class Initialized
DEBUG - 2011-08-15 03:47:58 --> Loader Class Initialized
DEBUG - 2011-08-15 03:47:58 --> Controller Class Initialized
ERROR - 2011-08-15 03:47:58 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-15 03:47:58 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-15 03:47:58 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-15 03:47:58 --> Model Class Initialized
DEBUG - 2011-08-15 03:47:58 --> Model Class Initialized
DEBUG - 2011-08-15 03:47:58 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-15 03:47:58 --> Database Driver Class Initialized
DEBUG - 2011-08-15 03:47:58 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-15 03:47:58 --> Helper loaded: url_helper
DEBUG - 2011-08-15 03:47:58 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-15 03:47:58 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-15 03:47:58 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-15 03:47:58 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-15 03:47:58 --> Final output sent to browser
DEBUG - 2011-08-15 03:47:58 --> Total execution time: 0.1661
DEBUG - 2011-08-15 03:47:58 --> Config Class Initialized
DEBUG - 2011-08-15 03:47:58 --> Hooks Class Initialized
DEBUG - 2011-08-15 03:47:58 --> Utf8 Class Initialized
DEBUG - 2011-08-15 03:47:58 --> UTF-8 Support Enabled
DEBUG - 2011-08-15 03:47:58 --> URI Class Initialized
DEBUG - 2011-08-15 03:47:58 --> Router Class Initialized
DEBUG - 2011-08-15 03:47:58 --> Output Class Initialized
DEBUG - 2011-08-15 03:47:58 --> Input Class Initialized
DEBUG - 2011-08-15 03:47:58 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-15 03:47:58 --> Language Class Initialized
DEBUG - 2011-08-15 03:47:58 --> Loader Class Initialized
DEBUG - 2011-08-15 03:47:58 --> Controller Class Initialized
DEBUG - 2011-08-15 03:47:58 --> Model Class Initialized
DEBUG - 2011-08-15 03:47:58 --> Model Class Initialized
DEBUG - 2011-08-15 03:47:58 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-15 03:47:58 --> Database Driver Class Initialized
DEBUG - 2011-08-15 03:48:00 --> Final output sent to browser
DEBUG - 2011-08-15 03:48:00 --> Total execution time: 1.4309
DEBUG - 2011-08-15 03:48:01 --> Config Class Initialized
DEBUG - 2011-08-15 03:48:01 --> Hooks Class Initialized
DEBUG - 2011-08-15 03:48:01 --> Utf8 Class Initialized
DEBUG - 2011-08-15 03:48:01 --> UTF-8 Support Enabled
DEBUG - 2011-08-15 03:48:01 --> URI Class Initialized
DEBUG - 2011-08-15 03:48:01 --> Router Class Initialized
ERROR - 2011-08-15 03:48:01 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-15 03:48:08 --> Config Class Initialized
DEBUG - 2011-08-15 03:48:08 --> Hooks Class Initialized
DEBUG - 2011-08-15 03:48:08 --> Utf8 Class Initialized
DEBUG - 2011-08-15 03:48:08 --> UTF-8 Support Enabled
DEBUG - 2011-08-15 03:48:08 --> URI Class Initialized
DEBUG - 2011-08-15 03:48:08 --> Router Class Initialized
DEBUG - 2011-08-15 03:48:08 --> Output Class Initialized
DEBUG - 2011-08-15 03:48:08 --> Input Class Initialized
DEBUG - 2011-08-15 03:48:08 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-15 03:48:08 --> Language Class Initialized
DEBUG - 2011-08-15 03:48:08 --> Loader Class Initialized
DEBUG - 2011-08-15 03:48:08 --> Controller Class Initialized
ERROR - 2011-08-15 03:48:08 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-15 03:48:08 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-15 03:48:08 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-15 03:48:08 --> Model Class Initialized
DEBUG - 2011-08-15 03:48:08 --> Model Class Initialized
DEBUG - 2011-08-15 03:48:08 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-15 03:48:08 --> Database Driver Class Initialized
DEBUG - 2011-08-15 03:48:08 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-15 03:48:08 --> Helper loaded: url_helper
DEBUG - 2011-08-15 03:48:08 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-15 03:48:08 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-15 03:48:08 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-15 03:48:08 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-15 03:48:08 --> Final output sent to browser
DEBUG - 2011-08-15 03:48:08 --> Total execution time: 0.0720
DEBUG - 2011-08-15 03:48:09 --> Config Class Initialized
DEBUG - 2011-08-15 03:48:09 --> Hooks Class Initialized
DEBUG - 2011-08-15 03:48:09 --> Utf8 Class Initialized
DEBUG - 2011-08-15 03:48:09 --> UTF-8 Support Enabled
DEBUG - 2011-08-15 03:48:09 --> URI Class Initialized
DEBUG - 2011-08-15 03:48:09 --> Router Class Initialized
DEBUG - 2011-08-15 03:48:09 --> Output Class Initialized
DEBUG - 2011-08-15 03:48:09 --> Input Class Initialized
DEBUG - 2011-08-15 03:48:09 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-15 03:48:09 --> Language Class Initialized
DEBUG - 2011-08-15 03:48:09 --> Loader Class Initialized
DEBUG - 2011-08-15 03:48:09 --> Controller Class Initialized
DEBUG - 2011-08-15 03:48:09 --> Model Class Initialized
DEBUG - 2011-08-15 03:48:09 --> Model Class Initialized
DEBUG - 2011-08-15 03:48:09 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-15 03:48:09 --> Database Driver Class Initialized
DEBUG - 2011-08-15 03:48:10 --> Config Class Initialized
DEBUG - 2011-08-15 03:48:10 --> Hooks Class Initialized
DEBUG - 2011-08-15 03:48:10 --> Utf8 Class Initialized
DEBUG - 2011-08-15 03:48:10 --> UTF-8 Support Enabled
DEBUG - 2011-08-15 03:48:10 --> URI Class Initialized
DEBUG - 2011-08-15 03:48:10 --> Router Class Initialized
DEBUG - 2011-08-15 03:48:10 --> Output Class Initialized
DEBUG - 2011-08-15 03:48:10 --> Input Class Initialized
DEBUG - 2011-08-15 03:48:10 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-15 03:48:10 --> Language Class Initialized
DEBUG - 2011-08-15 03:48:10 --> Loader Class Initialized
DEBUG - 2011-08-15 03:48:10 --> Controller Class Initialized
ERROR - 2011-08-15 03:48:10 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-15 03:48:10 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-15 03:48:10 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-15 03:48:10 --> Model Class Initialized
DEBUG - 2011-08-15 03:48:10 --> Model Class Initialized
DEBUG - 2011-08-15 03:48:10 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-15 03:48:10 --> Database Driver Class Initialized
DEBUG - 2011-08-15 03:48:10 --> Final output sent to browser
DEBUG - 2011-08-15 03:48:10 --> Total execution time: 0.6078
DEBUG - 2011-08-15 03:48:10 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-15 03:48:10 --> Helper loaded: url_helper
DEBUG - 2011-08-15 03:48:10 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-15 03:48:10 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-15 03:48:10 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-15 03:48:10 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-15 03:48:10 --> Final output sent to browser
DEBUG - 2011-08-15 03:48:10 --> Total execution time: 0.0557
DEBUG - 2011-08-15 03:48:11 --> Config Class Initialized
DEBUG - 2011-08-15 03:48:11 --> Hooks Class Initialized
DEBUG - 2011-08-15 03:48:11 --> Utf8 Class Initialized
DEBUG - 2011-08-15 03:48:11 --> UTF-8 Support Enabled
DEBUG - 2011-08-15 03:48:11 --> URI Class Initialized
DEBUG - 2011-08-15 03:48:11 --> Router Class Initialized
ERROR - 2011-08-15 03:48:11 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-15 03:48:18 --> Config Class Initialized
DEBUG - 2011-08-15 03:48:18 --> Hooks Class Initialized
DEBUG - 2011-08-15 03:48:18 --> Utf8 Class Initialized
DEBUG - 2011-08-15 03:48:18 --> UTF-8 Support Enabled
DEBUG - 2011-08-15 03:48:18 --> URI Class Initialized
DEBUG - 2011-08-15 03:48:18 --> Router Class Initialized
DEBUG - 2011-08-15 03:48:18 --> Output Class Initialized
DEBUG - 2011-08-15 03:48:18 --> Input Class Initialized
DEBUG - 2011-08-15 03:48:18 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-15 03:48:18 --> Language Class Initialized
DEBUG - 2011-08-15 03:48:18 --> Loader Class Initialized
DEBUG - 2011-08-15 03:48:18 --> Controller Class Initialized
ERROR - 2011-08-15 03:48:18 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-15 03:48:18 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-15 03:48:18 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-15 03:48:18 --> Model Class Initialized
DEBUG - 2011-08-15 03:48:18 --> Model Class Initialized
DEBUG - 2011-08-15 03:48:18 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-15 03:48:18 --> Database Driver Class Initialized
DEBUG - 2011-08-15 03:48:18 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-15 03:48:18 --> Helper loaded: url_helper
DEBUG - 2011-08-15 03:48:18 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-15 03:48:18 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-15 03:48:18 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-15 03:48:18 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-15 03:48:18 --> Final output sent to browser
DEBUG - 2011-08-15 03:48:18 --> Total execution time: 0.0291
DEBUG - 2011-08-15 03:48:19 --> Config Class Initialized
DEBUG - 2011-08-15 03:48:19 --> Hooks Class Initialized
DEBUG - 2011-08-15 03:48:19 --> Utf8 Class Initialized
DEBUG - 2011-08-15 03:48:19 --> UTF-8 Support Enabled
DEBUG - 2011-08-15 03:48:19 --> URI Class Initialized
DEBUG - 2011-08-15 03:48:19 --> Router Class Initialized
DEBUG - 2011-08-15 03:48:19 --> Output Class Initialized
DEBUG - 2011-08-15 03:48:19 --> Input Class Initialized
DEBUG - 2011-08-15 03:48:19 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-15 03:48:19 --> Language Class Initialized
DEBUG - 2011-08-15 03:48:19 --> Loader Class Initialized
DEBUG - 2011-08-15 03:48:19 --> Controller Class Initialized
DEBUG - 2011-08-15 03:48:19 --> Model Class Initialized
DEBUG - 2011-08-15 03:48:19 --> Model Class Initialized
DEBUG - 2011-08-15 03:48:19 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-15 03:48:19 --> Database Driver Class Initialized
DEBUG - 2011-08-15 03:48:20 --> Final output sent to browser
DEBUG - 2011-08-15 03:48:20 --> Total execution time: 1.1126
DEBUG - 2011-08-15 03:48:21 --> Config Class Initialized
DEBUG - 2011-08-15 03:48:21 --> Hooks Class Initialized
DEBUG - 2011-08-15 03:48:21 --> Utf8 Class Initialized
DEBUG - 2011-08-15 03:48:21 --> UTF-8 Support Enabled
DEBUG - 2011-08-15 03:48:21 --> URI Class Initialized
DEBUG - 2011-08-15 03:48:21 --> Router Class Initialized
ERROR - 2011-08-15 03:48:21 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-15 03:48:29 --> Config Class Initialized
DEBUG - 2011-08-15 03:48:29 --> Hooks Class Initialized
DEBUG - 2011-08-15 03:48:29 --> Utf8 Class Initialized
DEBUG - 2011-08-15 03:48:29 --> UTF-8 Support Enabled
DEBUG - 2011-08-15 03:48:29 --> URI Class Initialized
DEBUG - 2011-08-15 03:48:29 --> Router Class Initialized
DEBUG - 2011-08-15 03:48:29 --> Output Class Initialized
DEBUG - 2011-08-15 03:48:29 --> Input Class Initialized
DEBUG - 2011-08-15 03:48:29 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-15 03:48:29 --> Language Class Initialized
DEBUG - 2011-08-15 03:48:29 --> Loader Class Initialized
DEBUG - 2011-08-15 03:48:29 --> Controller Class Initialized
ERROR - 2011-08-15 03:48:29 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-15 03:48:29 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-15 03:48:29 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-15 03:48:29 --> Model Class Initialized
DEBUG - 2011-08-15 03:48:29 --> Model Class Initialized
DEBUG - 2011-08-15 03:48:29 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-15 03:48:29 --> Database Driver Class Initialized
DEBUG - 2011-08-15 03:48:29 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-15 03:48:29 --> Helper loaded: url_helper
DEBUG - 2011-08-15 03:48:29 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-15 03:48:29 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-15 03:48:29 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-15 03:48:29 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-15 03:48:29 --> Final output sent to browser
DEBUG - 2011-08-15 03:48:29 --> Total execution time: 0.0390
DEBUG - 2011-08-15 03:48:29 --> Config Class Initialized
DEBUG - 2011-08-15 03:48:29 --> Hooks Class Initialized
DEBUG - 2011-08-15 03:48:29 --> Utf8 Class Initialized
DEBUG - 2011-08-15 03:48:29 --> UTF-8 Support Enabled
DEBUG - 2011-08-15 03:48:29 --> URI Class Initialized
DEBUG - 2011-08-15 03:48:29 --> Router Class Initialized
DEBUG - 2011-08-15 03:48:29 --> Output Class Initialized
DEBUG - 2011-08-15 03:48:29 --> Input Class Initialized
DEBUG - 2011-08-15 03:48:29 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-15 03:48:29 --> Language Class Initialized
DEBUG - 2011-08-15 03:48:29 --> Loader Class Initialized
DEBUG - 2011-08-15 03:48:29 --> Controller Class Initialized
DEBUG - 2011-08-15 03:48:29 --> Model Class Initialized
DEBUG - 2011-08-15 03:48:29 --> Model Class Initialized
DEBUG - 2011-08-15 03:48:29 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-15 03:48:29 --> Database Driver Class Initialized
DEBUG - 2011-08-15 03:48:30 --> Final output sent to browser
DEBUG - 2011-08-15 03:48:30 --> Total execution time: 1.0714
DEBUG - 2011-08-15 03:48:31 --> Config Class Initialized
DEBUG - 2011-08-15 03:48:31 --> Hooks Class Initialized
DEBUG - 2011-08-15 03:48:31 --> Utf8 Class Initialized
DEBUG - 2011-08-15 03:48:31 --> UTF-8 Support Enabled
DEBUG - 2011-08-15 03:48:31 --> URI Class Initialized
DEBUG - 2011-08-15 03:48:31 --> Router Class Initialized
ERROR - 2011-08-15 03:48:31 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-15 03:48:35 --> Config Class Initialized
DEBUG - 2011-08-15 03:48:35 --> Hooks Class Initialized
DEBUG - 2011-08-15 03:48:35 --> Utf8 Class Initialized
DEBUG - 2011-08-15 03:48:35 --> UTF-8 Support Enabled
DEBUG - 2011-08-15 03:48:35 --> URI Class Initialized
DEBUG - 2011-08-15 03:48:35 --> Router Class Initialized
DEBUG - 2011-08-15 03:48:35 --> Output Class Initialized
DEBUG - 2011-08-15 03:48:35 --> Input Class Initialized
DEBUG - 2011-08-15 03:48:35 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-15 03:48:35 --> Language Class Initialized
DEBUG - 2011-08-15 03:48:35 --> Loader Class Initialized
DEBUG - 2011-08-15 03:48:35 --> Controller Class Initialized
ERROR - 2011-08-15 03:48:35 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-15 03:48:35 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-15 03:48:35 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-15 03:48:35 --> Model Class Initialized
DEBUG - 2011-08-15 03:48:35 --> Model Class Initialized
DEBUG - 2011-08-15 03:48:35 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-15 03:48:35 --> Database Driver Class Initialized
DEBUG - 2011-08-15 03:48:35 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-15 03:48:35 --> Helper loaded: url_helper
DEBUG - 2011-08-15 03:48:35 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-15 03:48:35 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-15 03:48:35 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-15 03:48:35 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-15 03:48:35 --> Final output sent to browser
DEBUG - 2011-08-15 03:48:35 --> Total execution time: 0.0346
DEBUG - 2011-08-15 03:48:36 --> Config Class Initialized
DEBUG - 2011-08-15 03:48:36 --> Hooks Class Initialized
DEBUG - 2011-08-15 03:48:36 --> Utf8 Class Initialized
DEBUG - 2011-08-15 03:48:36 --> UTF-8 Support Enabled
DEBUG - 2011-08-15 03:48:36 --> URI Class Initialized
DEBUG - 2011-08-15 03:48:36 --> Router Class Initialized
DEBUG - 2011-08-15 03:48:36 --> Output Class Initialized
DEBUG - 2011-08-15 03:48:36 --> Input Class Initialized
DEBUG - 2011-08-15 03:48:36 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-15 03:48:36 --> Language Class Initialized
DEBUG - 2011-08-15 03:48:36 --> Loader Class Initialized
DEBUG - 2011-08-15 03:48:36 --> Controller Class Initialized
DEBUG - 2011-08-15 03:48:36 --> Model Class Initialized
DEBUG - 2011-08-15 03:48:36 --> Model Class Initialized
DEBUG - 2011-08-15 03:48:36 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-15 03:48:36 --> Database Driver Class Initialized
DEBUG - 2011-08-15 03:48:37 --> Final output sent to browser
DEBUG - 2011-08-15 03:48:37 --> Total execution time: 0.4551
DEBUG - 2011-08-15 03:48:38 --> Config Class Initialized
DEBUG - 2011-08-15 03:48:38 --> Hooks Class Initialized
DEBUG - 2011-08-15 03:48:38 --> Utf8 Class Initialized
DEBUG - 2011-08-15 03:48:38 --> UTF-8 Support Enabled
DEBUG - 2011-08-15 03:48:38 --> URI Class Initialized
DEBUG - 2011-08-15 03:48:38 --> Router Class Initialized
ERROR - 2011-08-15 03:48:38 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-15 03:48:42 --> Config Class Initialized
DEBUG - 2011-08-15 03:48:42 --> Hooks Class Initialized
DEBUG - 2011-08-15 03:48:42 --> Utf8 Class Initialized
DEBUG - 2011-08-15 03:48:42 --> UTF-8 Support Enabled
DEBUG - 2011-08-15 03:48:42 --> URI Class Initialized
DEBUG - 2011-08-15 03:48:42 --> Router Class Initialized
DEBUG - 2011-08-15 03:48:42 --> Output Class Initialized
DEBUG - 2011-08-15 03:48:42 --> Input Class Initialized
DEBUG - 2011-08-15 03:48:42 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-15 03:48:42 --> Language Class Initialized
DEBUG - 2011-08-15 03:48:42 --> Loader Class Initialized
DEBUG - 2011-08-15 03:48:42 --> Controller Class Initialized
ERROR - 2011-08-15 03:48:42 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-15 03:48:42 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-15 03:48:42 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-15 03:48:42 --> Model Class Initialized
DEBUG - 2011-08-15 03:48:42 --> Model Class Initialized
DEBUG - 2011-08-15 03:48:42 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-15 03:48:42 --> Database Driver Class Initialized
DEBUG - 2011-08-15 03:48:42 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-15 03:48:42 --> Helper loaded: url_helper
DEBUG - 2011-08-15 03:48:42 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-15 03:48:42 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-15 03:48:42 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-15 03:48:42 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-15 03:48:42 --> Final output sent to browser
DEBUG - 2011-08-15 03:48:42 --> Total execution time: 0.0301
DEBUG - 2011-08-15 03:48:43 --> Config Class Initialized
DEBUG - 2011-08-15 03:48:43 --> Hooks Class Initialized
DEBUG - 2011-08-15 03:48:43 --> Utf8 Class Initialized
DEBUG - 2011-08-15 03:48:43 --> UTF-8 Support Enabled
DEBUG - 2011-08-15 03:48:43 --> URI Class Initialized
DEBUG - 2011-08-15 03:48:43 --> Router Class Initialized
DEBUG - 2011-08-15 03:48:43 --> Output Class Initialized
DEBUG - 2011-08-15 03:48:43 --> Input Class Initialized
DEBUG - 2011-08-15 03:48:43 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-15 03:48:43 --> Language Class Initialized
DEBUG - 2011-08-15 03:48:43 --> Loader Class Initialized
DEBUG - 2011-08-15 03:48:43 --> Controller Class Initialized
DEBUG - 2011-08-15 03:48:43 --> Model Class Initialized
DEBUG - 2011-08-15 03:48:43 --> Model Class Initialized
DEBUG - 2011-08-15 03:48:43 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-15 03:48:43 --> Database Driver Class Initialized
DEBUG - 2011-08-15 03:48:44 --> Final output sent to browser
DEBUG - 2011-08-15 03:48:44 --> Total execution time: 0.8831
DEBUG - 2011-08-15 03:48:45 --> Config Class Initialized
DEBUG - 2011-08-15 03:48:45 --> Hooks Class Initialized
DEBUG - 2011-08-15 03:48:45 --> Utf8 Class Initialized
DEBUG - 2011-08-15 03:48:45 --> UTF-8 Support Enabled
DEBUG - 2011-08-15 03:48:45 --> URI Class Initialized
DEBUG - 2011-08-15 03:48:45 --> Router Class Initialized
ERROR - 2011-08-15 03:48:45 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-15 03:48:52 --> Config Class Initialized
DEBUG - 2011-08-15 03:48:52 --> Hooks Class Initialized
DEBUG - 2011-08-15 03:48:52 --> Utf8 Class Initialized
DEBUG - 2011-08-15 03:48:52 --> UTF-8 Support Enabled
DEBUG - 2011-08-15 03:48:52 --> URI Class Initialized
DEBUG - 2011-08-15 03:48:52 --> Router Class Initialized
DEBUG - 2011-08-15 03:48:52 --> Output Class Initialized
DEBUG - 2011-08-15 03:48:52 --> Input Class Initialized
DEBUG - 2011-08-15 03:48:52 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-15 03:48:52 --> Language Class Initialized
DEBUG - 2011-08-15 03:48:52 --> Loader Class Initialized
DEBUG - 2011-08-15 03:48:52 --> Controller Class Initialized
ERROR - 2011-08-15 03:48:52 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-15 03:48:52 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-15 03:48:52 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-15 03:48:52 --> Model Class Initialized
DEBUG - 2011-08-15 03:48:52 --> Model Class Initialized
DEBUG - 2011-08-15 03:48:52 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-15 03:48:52 --> Database Driver Class Initialized
DEBUG - 2011-08-15 03:48:52 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-15 03:48:52 --> Helper loaded: url_helper
DEBUG - 2011-08-15 03:48:52 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-15 03:48:52 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-15 03:48:52 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-15 03:48:52 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-15 03:48:52 --> Final output sent to browser
DEBUG - 2011-08-15 03:48:52 --> Total execution time: 0.0289
DEBUG - 2011-08-15 03:48:52 --> Config Class Initialized
DEBUG - 2011-08-15 03:48:52 --> Hooks Class Initialized
DEBUG - 2011-08-15 03:48:52 --> Utf8 Class Initialized
DEBUG - 2011-08-15 03:48:52 --> UTF-8 Support Enabled
DEBUG - 2011-08-15 03:48:52 --> URI Class Initialized
DEBUG - 2011-08-15 03:48:52 --> Router Class Initialized
DEBUG - 2011-08-15 03:48:52 --> Output Class Initialized
DEBUG - 2011-08-15 03:48:52 --> Input Class Initialized
DEBUG - 2011-08-15 03:48:52 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-15 03:48:52 --> Language Class Initialized
DEBUG - 2011-08-15 03:48:52 --> Loader Class Initialized
DEBUG - 2011-08-15 03:48:52 --> Controller Class Initialized
DEBUG - 2011-08-15 03:48:52 --> Model Class Initialized
DEBUG - 2011-08-15 03:48:52 --> Model Class Initialized
DEBUG - 2011-08-15 03:48:52 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-15 03:48:52 --> Database Driver Class Initialized
DEBUG - 2011-08-15 03:48:53 --> Final output sent to browser
DEBUG - 2011-08-15 03:48:53 --> Total execution time: 0.4903
DEBUG - 2011-08-15 03:48:55 --> Config Class Initialized
DEBUG - 2011-08-15 03:48:55 --> Hooks Class Initialized
DEBUG - 2011-08-15 03:48:55 --> Utf8 Class Initialized
DEBUG - 2011-08-15 03:48:55 --> UTF-8 Support Enabled
DEBUG - 2011-08-15 03:48:55 --> URI Class Initialized
DEBUG - 2011-08-15 03:48:55 --> Router Class Initialized
ERROR - 2011-08-15 03:48:55 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-15 03:48:57 --> Config Class Initialized
DEBUG - 2011-08-15 03:48:57 --> Hooks Class Initialized
DEBUG - 2011-08-15 03:48:57 --> Utf8 Class Initialized
DEBUG - 2011-08-15 03:48:57 --> UTF-8 Support Enabled
DEBUG - 2011-08-15 03:48:57 --> URI Class Initialized
DEBUG - 2011-08-15 03:48:57 --> Router Class Initialized
DEBUG - 2011-08-15 03:48:57 --> Output Class Initialized
DEBUG - 2011-08-15 03:48:57 --> Input Class Initialized
DEBUG - 2011-08-15 03:48:57 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-15 03:48:57 --> Language Class Initialized
DEBUG - 2011-08-15 03:48:57 --> Loader Class Initialized
DEBUG - 2011-08-15 03:48:57 --> Controller Class Initialized
ERROR - 2011-08-15 03:48:57 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-15 03:48:57 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-15 03:48:57 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-15 03:48:57 --> Model Class Initialized
DEBUG - 2011-08-15 03:48:57 --> Model Class Initialized
DEBUG - 2011-08-15 03:48:57 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-15 03:48:57 --> Database Driver Class Initialized
DEBUG - 2011-08-15 03:48:57 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-15 03:48:57 --> Helper loaded: url_helper
DEBUG - 2011-08-15 03:48:57 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-15 03:48:57 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-15 03:48:57 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-15 03:48:57 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-15 03:48:57 --> Final output sent to browser
DEBUG - 2011-08-15 03:48:57 --> Total execution time: 0.0469
DEBUG - 2011-08-15 03:48:58 --> Config Class Initialized
DEBUG - 2011-08-15 03:48:58 --> Hooks Class Initialized
DEBUG - 2011-08-15 03:48:58 --> Utf8 Class Initialized
DEBUG - 2011-08-15 03:48:58 --> UTF-8 Support Enabled
DEBUG - 2011-08-15 03:48:58 --> URI Class Initialized
DEBUG - 2011-08-15 03:48:58 --> Router Class Initialized
DEBUG - 2011-08-15 03:48:58 --> Output Class Initialized
DEBUG - 2011-08-15 03:48:58 --> Input Class Initialized
DEBUG - 2011-08-15 03:48:58 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-15 03:48:58 --> Language Class Initialized
DEBUG - 2011-08-15 03:48:58 --> Loader Class Initialized
DEBUG - 2011-08-15 03:48:58 --> Controller Class Initialized
DEBUG - 2011-08-15 03:48:58 --> Model Class Initialized
DEBUG - 2011-08-15 03:48:58 --> Model Class Initialized
DEBUG - 2011-08-15 03:48:58 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-15 03:48:58 --> Database Driver Class Initialized
DEBUG - 2011-08-15 03:48:59 --> Final output sent to browser
DEBUG - 2011-08-15 03:48:59 --> Total execution time: 0.6184
DEBUG - 2011-08-15 03:49:00 --> Config Class Initialized
DEBUG - 2011-08-15 03:49:00 --> Hooks Class Initialized
DEBUG - 2011-08-15 03:49:00 --> Utf8 Class Initialized
DEBUG - 2011-08-15 03:49:00 --> UTF-8 Support Enabled
DEBUG - 2011-08-15 03:49:00 --> URI Class Initialized
DEBUG - 2011-08-15 03:49:00 --> Router Class Initialized
ERROR - 2011-08-15 03:49:00 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-15 03:49:08 --> Config Class Initialized
DEBUG - 2011-08-15 03:49:08 --> Hooks Class Initialized
DEBUG - 2011-08-15 03:49:08 --> Utf8 Class Initialized
DEBUG - 2011-08-15 03:49:08 --> UTF-8 Support Enabled
DEBUG - 2011-08-15 03:49:08 --> URI Class Initialized
DEBUG - 2011-08-15 03:49:08 --> Router Class Initialized
DEBUG - 2011-08-15 03:49:08 --> Output Class Initialized
DEBUG - 2011-08-15 03:49:08 --> Input Class Initialized
DEBUG - 2011-08-15 03:49:08 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-15 03:49:08 --> Language Class Initialized
DEBUG - 2011-08-15 03:49:08 --> Loader Class Initialized
DEBUG - 2011-08-15 03:49:08 --> Controller Class Initialized
ERROR - 2011-08-15 03:49:08 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-15 03:49:08 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-15 03:49:08 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-15 03:49:08 --> Model Class Initialized
DEBUG - 2011-08-15 03:49:08 --> Model Class Initialized
DEBUG - 2011-08-15 03:49:08 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-15 03:49:08 --> Database Driver Class Initialized
DEBUG - 2011-08-15 03:49:08 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-15 03:49:08 --> Helper loaded: url_helper
DEBUG - 2011-08-15 03:49:08 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-15 03:49:08 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-15 03:49:08 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-15 03:49:08 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-15 03:49:08 --> Final output sent to browser
DEBUG - 2011-08-15 03:49:08 --> Total execution time: 0.0361
DEBUG - 2011-08-15 03:49:09 --> Config Class Initialized
DEBUG - 2011-08-15 03:49:09 --> Hooks Class Initialized
DEBUG - 2011-08-15 03:49:09 --> Utf8 Class Initialized
DEBUG - 2011-08-15 03:49:09 --> UTF-8 Support Enabled
DEBUG - 2011-08-15 03:49:09 --> URI Class Initialized
DEBUG - 2011-08-15 03:49:09 --> Router Class Initialized
DEBUG - 2011-08-15 03:49:09 --> Output Class Initialized
DEBUG - 2011-08-15 03:49:09 --> Input Class Initialized
DEBUG - 2011-08-15 03:49:09 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-15 03:49:09 --> Language Class Initialized
DEBUG - 2011-08-15 03:49:09 --> Loader Class Initialized
DEBUG - 2011-08-15 03:49:09 --> Controller Class Initialized
DEBUG - 2011-08-15 03:49:09 --> Model Class Initialized
DEBUG - 2011-08-15 03:49:09 --> Model Class Initialized
DEBUG - 2011-08-15 03:49:09 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-15 03:49:09 --> Database Driver Class Initialized
DEBUG - 2011-08-15 03:49:10 --> Final output sent to browser
DEBUG - 2011-08-15 03:49:10 --> Total execution time: 1.0382
DEBUG - 2011-08-15 03:49:11 --> Config Class Initialized
DEBUG - 2011-08-15 03:49:11 --> Hooks Class Initialized
DEBUG - 2011-08-15 03:49:11 --> Utf8 Class Initialized
DEBUG - 2011-08-15 03:49:11 --> UTF-8 Support Enabled
DEBUG - 2011-08-15 03:49:11 --> URI Class Initialized
DEBUG - 2011-08-15 03:49:11 --> Router Class Initialized
ERROR - 2011-08-15 03:49:11 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-15 03:49:14 --> Config Class Initialized
DEBUG - 2011-08-15 03:49:14 --> Hooks Class Initialized
DEBUG - 2011-08-15 03:49:14 --> Utf8 Class Initialized
DEBUG - 2011-08-15 03:49:14 --> UTF-8 Support Enabled
DEBUG - 2011-08-15 03:49:14 --> URI Class Initialized
DEBUG - 2011-08-15 03:49:14 --> Router Class Initialized
DEBUG - 2011-08-15 03:49:14 --> Output Class Initialized
DEBUG - 2011-08-15 03:49:14 --> Input Class Initialized
DEBUG - 2011-08-15 03:49:14 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-15 03:49:14 --> Language Class Initialized
DEBUG - 2011-08-15 03:49:14 --> Loader Class Initialized
DEBUG - 2011-08-15 03:49:14 --> Controller Class Initialized
ERROR - 2011-08-15 03:49:14 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-15 03:49:14 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-15 03:49:14 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-15 03:49:14 --> Model Class Initialized
DEBUG - 2011-08-15 03:49:14 --> Model Class Initialized
DEBUG - 2011-08-15 03:49:14 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-15 03:49:14 --> Database Driver Class Initialized
DEBUG - 2011-08-15 03:49:14 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-15 03:49:14 --> Helper loaded: url_helper
DEBUG - 2011-08-15 03:49:14 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-15 03:49:14 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-15 03:49:14 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-15 03:49:14 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-15 03:49:14 --> Final output sent to browser
DEBUG - 2011-08-15 03:49:14 --> Total execution time: 0.0285
DEBUG - 2011-08-15 03:49:14 --> Config Class Initialized
DEBUG - 2011-08-15 03:49:14 --> Hooks Class Initialized
DEBUG - 2011-08-15 03:49:14 --> Utf8 Class Initialized
DEBUG - 2011-08-15 03:49:14 --> UTF-8 Support Enabled
DEBUG - 2011-08-15 03:49:14 --> URI Class Initialized
DEBUG - 2011-08-15 03:49:14 --> Router Class Initialized
DEBUG - 2011-08-15 03:49:14 --> Output Class Initialized
DEBUG - 2011-08-15 03:49:14 --> Input Class Initialized
DEBUG - 2011-08-15 03:49:14 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-15 03:49:14 --> Language Class Initialized
DEBUG - 2011-08-15 03:49:14 --> Loader Class Initialized
DEBUG - 2011-08-15 03:49:14 --> Controller Class Initialized
DEBUG - 2011-08-15 03:49:14 --> Model Class Initialized
DEBUG - 2011-08-15 03:49:14 --> Model Class Initialized
DEBUG - 2011-08-15 03:49:14 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-15 03:49:14 --> Database Driver Class Initialized
DEBUG - 2011-08-15 03:49:15 --> Final output sent to browser
DEBUG - 2011-08-15 03:49:15 --> Total execution time: 0.9405
DEBUG - 2011-08-15 03:49:16 --> Config Class Initialized
DEBUG - 2011-08-15 03:49:16 --> Hooks Class Initialized
DEBUG - 2011-08-15 03:49:16 --> Utf8 Class Initialized
DEBUG - 2011-08-15 03:49:16 --> UTF-8 Support Enabled
DEBUG - 2011-08-15 03:49:16 --> URI Class Initialized
DEBUG - 2011-08-15 03:49:16 --> Router Class Initialized
ERROR - 2011-08-15 03:49:16 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-15 03:49:26 --> Config Class Initialized
DEBUG - 2011-08-15 03:49:26 --> Hooks Class Initialized
DEBUG - 2011-08-15 03:49:26 --> Utf8 Class Initialized
DEBUG - 2011-08-15 03:49:26 --> UTF-8 Support Enabled
DEBUG - 2011-08-15 03:49:26 --> URI Class Initialized
DEBUG - 2011-08-15 03:49:26 --> Router Class Initialized
DEBUG - 2011-08-15 03:49:26 --> Output Class Initialized
DEBUG - 2011-08-15 03:49:26 --> Input Class Initialized
DEBUG - 2011-08-15 03:49:26 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-15 03:49:26 --> Language Class Initialized
DEBUG - 2011-08-15 03:49:26 --> Loader Class Initialized
DEBUG - 2011-08-15 03:49:26 --> Controller Class Initialized
ERROR - 2011-08-15 03:49:26 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-15 03:49:26 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-15 03:49:26 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-15 03:49:26 --> Model Class Initialized
DEBUG - 2011-08-15 03:49:26 --> Model Class Initialized
DEBUG - 2011-08-15 03:49:26 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-15 03:49:26 --> Database Driver Class Initialized
DEBUG - 2011-08-15 03:49:26 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-15 03:49:26 --> Helper loaded: url_helper
DEBUG - 2011-08-15 03:49:26 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-15 03:49:26 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-15 03:49:26 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-15 03:49:26 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-15 03:49:26 --> Final output sent to browser
DEBUG - 2011-08-15 03:49:26 --> Total execution time: 0.1154
DEBUG - 2011-08-15 03:49:27 --> Config Class Initialized
DEBUG - 2011-08-15 03:49:27 --> Hooks Class Initialized
DEBUG - 2011-08-15 03:49:27 --> Utf8 Class Initialized
DEBUG - 2011-08-15 03:49:27 --> UTF-8 Support Enabled
DEBUG - 2011-08-15 03:49:27 --> URI Class Initialized
DEBUG - 2011-08-15 03:49:27 --> Router Class Initialized
DEBUG - 2011-08-15 03:49:27 --> Output Class Initialized
DEBUG - 2011-08-15 03:49:27 --> Input Class Initialized
DEBUG - 2011-08-15 03:49:27 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-15 03:49:27 --> Language Class Initialized
DEBUG - 2011-08-15 03:49:27 --> Loader Class Initialized
DEBUG - 2011-08-15 03:49:27 --> Controller Class Initialized
DEBUG - 2011-08-15 03:49:27 --> Model Class Initialized
DEBUG - 2011-08-15 03:49:27 --> Model Class Initialized
DEBUG - 2011-08-15 03:49:27 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-15 03:49:27 --> Database Driver Class Initialized
DEBUG - 2011-08-15 03:49:28 --> Final output sent to browser
DEBUG - 2011-08-15 03:49:28 --> Total execution time: 1.0272
DEBUG - 2011-08-15 03:49:29 --> Config Class Initialized
DEBUG - 2011-08-15 03:49:29 --> Hooks Class Initialized
DEBUG - 2011-08-15 03:49:29 --> Utf8 Class Initialized
DEBUG - 2011-08-15 03:49:29 --> UTF-8 Support Enabled
DEBUG - 2011-08-15 03:49:29 --> URI Class Initialized
DEBUG - 2011-08-15 03:49:29 --> Router Class Initialized
ERROR - 2011-08-15 03:49:29 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-15 04:39:59 --> Config Class Initialized
DEBUG - 2011-08-15 04:39:59 --> Hooks Class Initialized
DEBUG - 2011-08-15 04:39:59 --> Utf8 Class Initialized
DEBUG - 2011-08-15 04:39:59 --> UTF-8 Support Enabled
DEBUG - 2011-08-15 04:39:59 --> URI Class Initialized
DEBUG - 2011-08-15 04:39:59 --> Router Class Initialized
ERROR - 2011-08-15 04:39:59 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-08-15 05:49:29 --> Config Class Initialized
DEBUG - 2011-08-15 05:49:29 --> Hooks Class Initialized
DEBUG - 2011-08-15 05:49:29 --> Utf8 Class Initialized
DEBUG - 2011-08-15 05:49:29 --> UTF-8 Support Enabled
DEBUG - 2011-08-15 05:49:29 --> URI Class Initialized
DEBUG - 2011-08-15 05:49:29 --> Router Class Initialized
DEBUG - 2011-08-15 05:49:29 --> Output Class Initialized
DEBUG - 2011-08-15 05:49:29 --> Input Class Initialized
DEBUG - 2011-08-15 05:49:29 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-15 05:49:30 --> Language Class Initialized
DEBUG - 2011-08-15 05:49:30 --> Loader Class Initialized
DEBUG - 2011-08-15 05:49:30 --> Controller Class Initialized
ERROR - 2011-08-15 05:49:30 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-15 05:49:30 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-15 05:49:30 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-15 05:49:30 --> Model Class Initialized
DEBUG - 2011-08-15 05:49:30 --> Model Class Initialized
DEBUG - 2011-08-15 05:49:30 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-15 05:49:30 --> Database Driver Class Initialized
DEBUG - 2011-08-15 05:49:30 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-15 05:49:30 --> Helper loaded: url_helper
DEBUG - 2011-08-15 05:49:30 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-15 05:49:30 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-15 05:49:30 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-15 05:49:30 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-15 05:49:30 --> Final output sent to browser
DEBUG - 2011-08-15 05:49:30 --> Total execution time: 0.6583
DEBUG - 2011-08-15 05:49:31 --> Config Class Initialized
DEBUG - 2011-08-15 05:49:31 --> Hooks Class Initialized
DEBUG - 2011-08-15 05:49:31 --> Utf8 Class Initialized
DEBUG - 2011-08-15 05:49:31 --> UTF-8 Support Enabled
DEBUG - 2011-08-15 05:49:31 --> URI Class Initialized
DEBUG - 2011-08-15 05:49:31 --> Router Class Initialized
DEBUG - 2011-08-15 05:49:31 --> Output Class Initialized
DEBUG - 2011-08-15 05:49:31 --> Input Class Initialized
DEBUG - 2011-08-15 05:49:31 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-15 05:49:31 --> Language Class Initialized
DEBUG - 2011-08-15 05:49:31 --> Loader Class Initialized
DEBUG - 2011-08-15 05:49:31 --> Controller Class Initialized
DEBUG - 2011-08-15 05:49:31 --> Model Class Initialized
DEBUG - 2011-08-15 05:49:31 --> Model Class Initialized
DEBUG - 2011-08-15 05:49:31 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-15 05:49:31 --> Database Driver Class Initialized
DEBUG - 2011-08-15 05:49:31 --> Config Class Initialized
DEBUG - 2011-08-15 05:49:31 --> Hooks Class Initialized
DEBUG - 2011-08-15 05:49:31 --> Utf8 Class Initialized
DEBUG - 2011-08-15 05:49:31 --> UTF-8 Support Enabled
DEBUG - 2011-08-15 05:49:31 --> URI Class Initialized
DEBUG - 2011-08-15 05:49:31 --> Router Class Initialized
ERROR - 2011-08-15 05:49:31 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-15 05:49:32 --> Config Class Initialized
DEBUG - 2011-08-15 05:49:32 --> Hooks Class Initialized
DEBUG - 2011-08-15 05:49:32 --> Utf8 Class Initialized
DEBUG - 2011-08-15 05:49:32 --> UTF-8 Support Enabled
DEBUG - 2011-08-15 05:49:32 --> URI Class Initialized
DEBUG - 2011-08-15 05:49:32 --> Router Class Initialized
DEBUG - 2011-08-15 05:49:32 --> Output Class Initialized
DEBUG - 2011-08-15 05:49:32 --> Input Class Initialized
DEBUG - 2011-08-15 05:49:32 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-15 05:49:32 --> Language Class Initialized
DEBUG - 2011-08-15 05:49:32 --> Final output sent to browser
DEBUG - 2011-08-15 05:49:32 --> Total execution time: 0.5501
DEBUG - 2011-08-15 05:49:32 --> Loader Class Initialized
DEBUG - 2011-08-15 05:49:32 --> Controller Class Initialized
DEBUG - 2011-08-15 05:49:32 --> Model Class Initialized
DEBUG - 2011-08-15 05:49:32 --> Model Class Initialized
DEBUG - 2011-08-15 05:49:32 --> Model Class Initialized
DEBUG - 2011-08-15 05:49:32 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-15 05:49:32 --> Database Driver Class Initialized
DEBUG - 2011-08-15 05:49:32 --> Config Class Initialized
DEBUG - 2011-08-15 05:49:32 --> Hooks Class Initialized
DEBUG - 2011-08-15 05:49:32 --> Utf8 Class Initialized
DEBUG - 2011-08-15 05:49:32 --> UTF-8 Support Enabled
DEBUG - 2011-08-15 05:49:32 --> URI Class Initialized
DEBUG - 2011-08-15 05:49:32 --> Router Class Initialized
ERROR - 2011-08-15 05:49:32 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-15 05:49:32 --> Config Class Initialized
DEBUG - 2011-08-15 05:49:32 --> Hooks Class Initialized
DEBUG - 2011-08-15 05:49:32 --> Utf8 Class Initialized
DEBUG - 2011-08-15 05:49:32 --> UTF-8 Support Enabled
DEBUG - 2011-08-15 05:49:32 --> URI Class Initialized
DEBUG - 2011-08-15 05:49:32 --> Router Class Initialized
ERROR - 2011-08-15 05:49:32 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-15 05:49:32 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-15 05:49:32 --> Helper loaded: url_helper
DEBUG - 2011-08-15 05:49:32 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-15 05:49:32 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-15 05:49:32 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-15 05:49:32 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-15 05:49:32 --> Final output sent to browser
DEBUG - 2011-08-15 05:49:32 --> Total execution time: 0.6600
DEBUG - 2011-08-15 05:57:47 --> Config Class Initialized
DEBUG - 2011-08-15 05:57:47 --> Hooks Class Initialized
DEBUG - 2011-08-15 05:57:47 --> Utf8 Class Initialized
DEBUG - 2011-08-15 05:57:47 --> UTF-8 Support Enabled
DEBUG - 2011-08-15 05:57:47 --> URI Class Initialized
DEBUG - 2011-08-15 05:57:47 --> Router Class Initialized
DEBUG - 2011-08-15 05:57:47 --> No URI present. Default controller set.
DEBUG - 2011-08-15 05:57:47 --> Output Class Initialized
DEBUG - 2011-08-15 05:57:47 --> Input Class Initialized
DEBUG - 2011-08-15 05:57:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-15 05:57:47 --> Language Class Initialized
DEBUG - 2011-08-15 05:57:47 --> Loader Class Initialized
DEBUG - 2011-08-15 05:57:47 --> Controller Class Initialized
DEBUG - 2011-08-15 05:57:47 --> File loaded: application/views/splash/main.php
DEBUG - 2011-08-15 05:57:47 --> Helper loaded: url_helper
DEBUG - 2011-08-15 05:57:47 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-15 05:57:47 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-15 05:57:47 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-15 05:57:47 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-15 05:57:47 --> Final output sent to browser
DEBUG - 2011-08-15 05:57:47 --> Total execution time: 0.0584
DEBUG - 2011-08-15 06:03:45 --> Config Class Initialized
DEBUG - 2011-08-15 06:03:45 --> Hooks Class Initialized
DEBUG - 2011-08-15 06:03:45 --> Utf8 Class Initialized
DEBUG - 2011-08-15 06:03:45 --> UTF-8 Support Enabled
DEBUG - 2011-08-15 06:03:45 --> URI Class Initialized
DEBUG - 2011-08-15 06:03:45 --> Router Class Initialized
DEBUG - 2011-08-15 06:03:45 --> Output Class Initialized
DEBUG - 2011-08-15 06:03:45 --> Input Class Initialized
DEBUG - 2011-08-15 06:03:45 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-15 06:03:45 --> Language Class Initialized
DEBUG - 2011-08-15 06:03:45 --> Loader Class Initialized
DEBUG - 2011-08-15 06:03:45 --> Controller Class Initialized
ERROR - 2011-08-15 06:03:45 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-15 06:03:45 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-15 06:03:45 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-15 06:03:45 --> Model Class Initialized
DEBUG - 2011-08-15 06:03:45 --> Model Class Initialized
DEBUG - 2011-08-15 06:03:45 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-15 06:03:45 --> Database Driver Class Initialized
DEBUG - 2011-08-15 06:03:45 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-15 06:03:45 --> Helper loaded: url_helper
DEBUG - 2011-08-15 06:03:45 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-15 06:03:45 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-15 06:03:45 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-15 06:03:45 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-15 06:03:45 --> Final output sent to browser
DEBUG - 2011-08-15 06:03:45 --> Total execution time: 0.0287
DEBUG - 2011-08-15 06:04:50 --> Config Class Initialized
DEBUG - 2011-08-15 06:04:50 --> Hooks Class Initialized
DEBUG - 2011-08-15 06:04:50 --> Utf8 Class Initialized
DEBUG - 2011-08-15 06:04:50 --> UTF-8 Support Enabled
DEBUG - 2011-08-15 06:04:50 --> URI Class Initialized
DEBUG - 2011-08-15 06:04:50 --> Router Class Initialized
DEBUG - 2011-08-15 06:04:50 --> Output Class Initialized
DEBUG - 2011-08-15 06:04:50 --> Input Class Initialized
DEBUG - 2011-08-15 06:04:50 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-15 06:04:50 --> Language Class Initialized
DEBUG - 2011-08-15 06:04:50 --> Loader Class Initialized
DEBUG - 2011-08-15 06:04:50 --> Controller Class Initialized
DEBUG - 2011-08-15 06:04:50 --> Model Class Initialized
DEBUG - 2011-08-15 06:04:50 --> Model Class Initialized
DEBUG - 2011-08-15 06:04:50 --> Model Class Initialized
DEBUG - 2011-08-15 06:04:50 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-15 06:04:50 --> Database Driver Class Initialized
DEBUG - 2011-08-15 06:04:50 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-15 06:04:50 --> Helper loaded: url_helper
DEBUG - 2011-08-15 06:04:50 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-15 06:04:50 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-15 06:04:50 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-15 06:04:50 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-15 06:04:50 --> Final output sent to browser
DEBUG - 2011-08-15 06:04:50 --> Total execution time: 0.0531
DEBUG - 2011-08-15 06:12:58 --> Config Class Initialized
DEBUG - 2011-08-15 06:12:58 --> Hooks Class Initialized
DEBUG - 2011-08-15 06:12:58 --> Utf8 Class Initialized
DEBUG - 2011-08-15 06:12:58 --> UTF-8 Support Enabled
DEBUG - 2011-08-15 06:12:58 --> URI Class Initialized
DEBUG - 2011-08-15 06:12:58 --> Router Class Initialized
DEBUG - 2011-08-15 06:12:58 --> Output Class Initialized
DEBUG - 2011-08-15 06:12:58 --> Input Class Initialized
DEBUG - 2011-08-15 06:12:58 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-15 06:12:58 --> Language Class Initialized
DEBUG - 2011-08-15 06:12:58 --> Loader Class Initialized
DEBUG - 2011-08-15 06:12:58 --> Controller Class Initialized
ERROR - 2011-08-15 06:12:58 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-15 06:12:58 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-15 06:12:58 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-15 06:12:58 --> Model Class Initialized
DEBUG - 2011-08-15 06:12:58 --> Model Class Initialized
DEBUG - 2011-08-15 06:12:58 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-15 06:12:58 --> Database Driver Class Initialized
DEBUG - 2011-08-15 06:12:58 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-15 06:12:58 --> Helper loaded: url_helper
DEBUG - 2011-08-15 06:12:58 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-15 06:12:58 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-15 06:12:58 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-15 06:12:58 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-15 06:12:58 --> Final output sent to browser
DEBUG - 2011-08-15 06:12:58 --> Total execution time: 0.3644
DEBUG - 2011-08-15 06:13:00 --> Config Class Initialized
DEBUG - 2011-08-15 06:13:00 --> Hooks Class Initialized
DEBUG - 2011-08-15 06:13:00 --> Utf8 Class Initialized
DEBUG - 2011-08-15 06:13:00 --> UTF-8 Support Enabled
DEBUG - 2011-08-15 06:13:00 --> URI Class Initialized
DEBUG - 2011-08-15 06:13:00 --> Router Class Initialized
DEBUG - 2011-08-15 06:13:00 --> Output Class Initialized
DEBUG - 2011-08-15 06:13:00 --> Input Class Initialized
DEBUG - 2011-08-15 06:13:00 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-15 06:13:00 --> Language Class Initialized
DEBUG - 2011-08-15 06:13:00 --> Loader Class Initialized
DEBUG - 2011-08-15 06:13:00 --> Controller Class Initialized
DEBUG - 2011-08-15 06:13:00 --> Model Class Initialized
DEBUG - 2011-08-15 06:13:00 --> Model Class Initialized
DEBUG - 2011-08-15 06:13:00 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-15 06:13:00 --> Database Driver Class Initialized
DEBUG - 2011-08-15 06:13:01 --> Final output sent to browser
DEBUG - 2011-08-15 06:13:01 --> Total execution time: 1.2874
DEBUG - 2011-08-15 06:13:04 --> Config Class Initialized
DEBUG - 2011-08-15 06:13:04 --> Hooks Class Initialized
DEBUG - 2011-08-15 06:13:04 --> Utf8 Class Initialized
DEBUG - 2011-08-15 06:13:04 --> UTF-8 Support Enabled
DEBUG - 2011-08-15 06:13:04 --> URI Class Initialized
DEBUG - 2011-08-15 06:13:04 --> Router Class Initialized
ERROR - 2011-08-15 06:13:04 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-15 06:50:12 --> Config Class Initialized
DEBUG - 2011-08-15 06:50:12 --> Hooks Class Initialized
DEBUG - 2011-08-15 06:50:12 --> Utf8 Class Initialized
DEBUG - 2011-08-15 06:50:12 --> UTF-8 Support Enabled
DEBUG - 2011-08-15 06:50:12 --> URI Class Initialized
DEBUG - 2011-08-15 06:50:12 --> Router Class Initialized
DEBUG - 2011-08-15 06:50:12 --> Output Class Initialized
DEBUG - 2011-08-15 06:50:12 --> Input Class Initialized
DEBUG - 2011-08-15 06:50:12 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-15 06:50:12 --> Language Class Initialized
DEBUG - 2011-08-15 06:50:12 --> Loader Class Initialized
DEBUG - 2011-08-15 06:50:12 --> Controller Class Initialized
ERROR - 2011-08-15 06:50:12 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-15 06:50:12 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-15 06:50:12 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-15 06:50:12 --> Model Class Initialized
DEBUG - 2011-08-15 06:50:12 --> Model Class Initialized
DEBUG - 2011-08-15 06:50:12 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-15 06:50:12 --> Database Driver Class Initialized
DEBUG - 2011-08-15 06:50:12 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-15 06:50:12 --> Helper loaded: url_helper
DEBUG - 2011-08-15 06:50:12 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-15 06:50:12 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-15 06:50:12 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-15 06:50:12 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-15 06:50:12 --> Final output sent to browser
DEBUG - 2011-08-15 06:50:12 --> Total execution time: 0.3518
DEBUG - 2011-08-15 06:50:13 --> Config Class Initialized
DEBUG - 2011-08-15 06:50:13 --> Hooks Class Initialized
DEBUG - 2011-08-15 06:50:13 --> Utf8 Class Initialized
DEBUG - 2011-08-15 06:50:13 --> UTF-8 Support Enabled
DEBUG - 2011-08-15 06:50:13 --> URI Class Initialized
DEBUG - 2011-08-15 06:50:13 --> Router Class Initialized
DEBUG - 2011-08-15 06:50:13 --> Output Class Initialized
DEBUG - 2011-08-15 06:50:13 --> Input Class Initialized
DEBUG - 2011-08-15 06:50:13 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-15 06:50:13 --> Language Class Initialized
DEBUG - 2011-08-15 06:50:13 --> Loader Class Initialized
DEBUG - 2011-08-15 06:50:13 --> Controller Class Initialized
DEBUG - 2011-08-15 06:50:13 --> Model Class Initialized
DEBUG - 2011-08-15 06:50:13 --> Model Class Initialized
DEBUG - 2011-08-15 06:50:13 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-15 06:50:13 --> Database Driver Class Initialized
DEBUG - 2011-08-15 06:50:14 --> Final output sent to browser
DEBUG - 2011-08-15 06:50:14 --> Total execution time: 1.0491
DEBUG - 2011-08-15 06:50:15 --> Config Class Initialized
DEBUG - 2011-08-15 06:50:15 --> Hooks Class Initialized
DEBUG - 2011-08-15 06:50:15 --> Utf8 Class Initialized
DEBUG - 2011-08-15 06:50:15 --> UTF-8 Support Enabled
DEBUG - 2011-08-15 06:50:15 --> URI Class Initialized
DEBUG - 2011-08-15 06:50:15 --> Router Class Initialized
ERROR - 2011-08-15 06:50:15 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-15 06:50:28 --> Config Class Initialized
DEBUG - 2011-08-15 06:50:28 --> Hooks Class Initialized
DEBUG - 2011-08-15 06:50:28 --> Utf8 Class Initialized
DEBUG - 2011-08-15 06:50:28 --> UTF-8 Support Enabled
DEBUG - 2011-08-15 06:50:28 --> URI Class Initialized
DEBUG - 2011-08-15 06:50:28 --> Router Class Initialized
DEBUG - 2011-08-15 06:50:28 --> Output Class Initialized
DEBUG - 2011-08-15 06:50:28 --> Input Class Initialized
DEBUG - 2011-08-15 06:50:28 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-15 06:50:28 --> Language Class Initialized
DEBUG - 2011-08-15 06:50:28 --> Loader Class Initialized
DEBUG - 2011-08-15 06:50:28 --> Controller Class Initialized
ERROR - 2011-08-15 06:50:28 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-15 06:50:28 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-15 06:50:28 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-15 06:50:28 --> Model Class Initialized
DEBUG - 2011-08-15 06:50:28 --> Model Class Initialized
DEBUG - 2011-08-15 06:50:28 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-15 06:50:28 --> Database Driver Class Initialized
DEBUG - 2011-08-15 06:50:28 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-15 06:50:28 --> Helper loaded: url_helper
DEBUG - 2011-08-15 06:50:28 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-15 06:50:28 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-15 06:50:28 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-15 06:50:28 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-15 06:50:28 --> Final output sent to browser
DEBUG - 2011-08-15 06:50:28 --> Total execution time: 0.0353
DEBUG - 2011-08-15 06:50:28 --> Config Class Initialized
DEBUG - 2011-08-15 06:50:28 --> Hooks Class Initialized
DEBUG - 2011-08-15 06:50:28 --> Utf8 Class Initialized
DEBUG - 2011-08-15 06:50:28 --> UTF-8 Support Enabled
DEBUG - 2011-08-15 06:50:28 --> URI Class Initialized
DEBUG - 2011-08-15 06:50:28 --> Router Class Initialized
DEBUG - 2011-08-15 06:50:28 --> Output Class Initialized
DEBUG - 2011-08-15 06:50:28 --> Input Class Initialized
DEBUG - 2011-08-15 06:50:28 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-15 06:50:28 --> Language Class Initialized
DEBUG - 2011-08-15 06:50:28 --> Loader Class Initialized
DEBUG - 2011-08-15 06:50:28 --> Controller Class Initialized
DEBUG - 2011-08-15 06:50:28 --> Model Class Initialized
DEBUG - 2011-08-15 06:50:28 --> Model Class Initialized
DEBUG - 2011-08-15 06:50:28 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-15 06:50:28 --> Database Driver Class Initialized
DEBUG - 2011-08-15 06:50:29 --> Final output sent to browser
DEBUG - 2011-08-15 06:50:29 --> Total execution time: 0.5994
DEBUG - 2011-08-15 06:50:30 --> Config Class Initialized
DEBUG - 2011-08-15 06:50:30 --> Hooks Class Initialized
DEBUG - 2011-08-15 06:50:30 --> Utf8 Class Initialized
DEBUG - 2011-08-15 06:50:30 --> UTF-8 Support Enabled
DEBUG - 2011-08-15 06:50:30 --> URI Class Initialized
DEBUG - 2011-08-15 06:50:30 --> Router Class Initialized
ERROR - 2011-08-15 06:50:30 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-15 06:50:52 --> Config Class Initialized
DEBUG - 2011-08-15 06:50:52 --> Hooks Class Initialized
DEBUG - 2011-08-15 06:50:52 --> Utf8 Class Initialized
DEBUG - 2011-08-15 06:50:52 --> UTF-8 Support Enabled
DEBUG - 2011-08-15 06:50:52 --> URI Class Initialized
DEBUG - 2011-08-15 06:50:52 --> Router Class Initialized
DEBUG - 2011-08-15 06:50:52 --> Output Class Initialized
DEBUG - 2011-08-15 06:50:52 --> Input Class Initialized
DEBUG - 2011-08-15 06:50:52 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-15 06:50:52 --> Language Class Initialized
DEBUG - 2011-08-15 06:50:52 --> Loader Class Initialized
DEBUG - 2011-08-15 06:50:52 --> Controller Class Initialized
ERROR - 2011-08-15 06:50:52 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-15 06:50:52 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-15 06:50:52 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-15 06:50:52 --> Model Class Initialized
DEBUG - 2011-08-15 06:50:52 --> Model Class Initialized
DEBUG - 2011-08-15 06:50:52 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-15 06:50:52 --> Database Driver Class Initialized
DEBUG - 2011-08-15 06:50:52 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-15 06:50:52 --> Helper loaded: url_helper
DEBUG - 2011-08-15 06:50:52 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-15 06:50:52 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-15 06:50:52 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-15 06:50:52 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-15 06:50:52 --> Final output sent to browser
DEBUG - 2011-08-15 06:50:52 --> Total execution time: 0.0881
DEBUG - 2011-08-15 06:50:53 --> Config Class Initialized
DEBUG - 2011-08-15 06:50:53 --> Hooks Class Initialized
DEBUG - 2011-08-15 06:50:53 --> Utf8 Class Initialized
DEBUG - 2011-08-15 06:50:53 --> UTF-8 Support Enabled
DEBUG - 2011-08-15 06:50:53 --> URI Class Initialized
DEBUG - 2011-08-15 06:50:53 --> Router Class Initialized
DEBUG - 2011-08-15 06:50:53 --> Output Class Initialized
DEBUG - 2011-08-15 06:50:53 --> Input Class Initialized
DEBUG - 2011-08-15 06:50:53 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-15 06:50:53 --> Language Class Initialized
DEBUG - 2011-08-15 06:50:53 --> Loader Class Initialized
DEBUG - 2011-08-15 06:50:53 --> Controller Class Initialized
DEBUG - 2011-08-15 06:50:53 --> Model Class Initialized
DEBUG - 2011-08-15 06:50:53 --> Model Class Initialized
DEBUG - 2011-08-15 06:50:53 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-15 06:50:53 --> Database Driver Class Initialized
DEBUG - 2011-08-15 06:50:54 --> Final output sent to browser
DEBUG - 2011-08-15 06:50:54 --> Total execution time: 0.7083
DEBUG - 2011-08-15 06:50:55 --> Config Class Initialized
DEBUG - 2011-08-15 06:50:55 --> Hooks Class Initialized
DEBUG - 2011-08-15 06:50:55 --> Utf8 Class Initialized
DEBUG - 2011-08-15 06:50:55 --> UTF-8 Support Enabled
DEBUG - 2011-08-15 06:50:55 --> URI Class Initialized
DEBUG - 2011-08-15 06:50:55 --> Router Class Initialized
ERROR - 2011-08-15 06:50:55 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-15 07:29:09 --> Config Class Initialized
DEBUG - 2011-08-15 07:29:09 --> Hooks Class Initialized
DEBUG - 2011-08-15 07:29:09 --> Utf8 Class Initialized
DEBUG - 2011-08-15 07:29:09 --> UTF-8 Support Enabled
DEBUG - 2011-08-15 07:29:09 --> URI Class Initialized
DEBUG - 2011-08-15 07:29:09 --> Router Class Initialized
ERROR - 2011-08-15 07:29:09 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-08-15 07:48:58 --> Config Class Initialized
DEBUG - 2011-08-15 07:48:58 --> Hooks Class Initialized
DEBUG - 2011-08-15 07:48:58 --> Utf8 Class Initialized
DEBUG - 2011-08-15 07:48:58 --> UTF-8 Support Enabled
DEBUG - 2011-08-15 07:48:58 --> URI Class Initialized
DEBUG - 2011-08-15 07:48:58 --> Router Class Initialized
DEBUG - 2011-08-15 07:48:58 --> No URI present. Default controller set.
DEBUG - 2011-08-15 07:48:58 --> Output Class Initialized
DEBUG - 2011-08-15 07:48:58 --> Input Class Initialized
DEBUG - 2011-08-15 07:48:58 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-15 07:48:58 --> Language Class Initialized
DEBUG - 2011-08-15 07:48:58 --> Loader Class Initialized
DEBUG - 2011-08-15 07:48:58 --> Controller Class Initialized
DEBUG - 2011-08-15 07:48:58 --> File loaded: application/views/splash/main.php
DEBUG - 2011-08-15 07:48:58 --> Helper loaded: url_helper
DEBUG - 2011-08-15 07:48:58 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-15 07:48:58 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-15 07:48:58 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-15 07:48:58 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-15 07:48:58 --> Final output sent to browser
DEBUG - 2011-08-15 07:48:58 --> Total execution time: 0.2247
DEBUG - 2011-08-15 08:30:22 --> Config Class Initialized
DEBUG - 2011-08-15 08:30:22 --> Hooks Class Initialized
DEBUG - 2011-08-15 08:30:22 --> Utf8 Class Initialized
DEBUG - 2011-08-15 08:30:22 --> UTF-8 Support Enabled
DEBUG - 2011-08-15 08:30:22 --> URI Class Initialized
DEBUG - 2011-08-15 08:30:22 --> Router Class Initialized
DEBUG - 2011-08-15 08:30:22 --> Output Class Initialized
DEBUG - 2011-08-15 08:30:22 --> Input Class Initialized
DEBUG - 2011-08-15 08:30:22 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-15 08:30:22 --> Language Class Initialized
DEBUG - 2011-08-15 08:30:22 --> Loader Class Initialized
DEBUG - 2011-08-15 08:30:22 --> Controller Class Initialized
DEBUG - 2011-08-15 08:30:22 --> Model Class Initialized
DEBUG - 2011-08-15 08:30:22 --> Model Class Initialized
DEBUG - 2011-08-15 08:30:22 --> Model Class Initialized
DEBUG - 2011-08-15 08:30:22 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-15 08:30:22 --> Database Driver Class Initialized
DEBUG - 2011-08-15 08:30:22 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-15 08:30:22 --> Helper loaded: url_helper
DEBUG - 2011-08-15 08:30:22 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-15 08:30:22 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-15 08:30:22 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-15 08:30:22 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-15 08:30:22 --> Final output sent to browser
DEBUG - 2011-08-15 08:30:22 --> Total execution time: 0.7578
DEBUG - 2011-08-15 08:30:23 --> Config Class Initialized
DEBUG - 2011-08-15 08:30:23 --> Hooks Class Initialized
DEBUG - 2011-08-15 08:30:23 --> Utf8 Class Initialized
DEBUG - 2011-08-15 08:30:23 --> UTF-8 Support Enabled
DEBUG - 2011-08-15 08:30:23 --> URI Class Initialized
DEBUG - 2011-08-15 08:30:23 --> Router Class Initialized
DEBUG - 2011-08-15 08:30:23 --> Output Class Initialized
DEBUG - 2011-08-15 08:30:23 --> Input Class Initialized
DEBUG - 2011-08-15 08:30:23 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-15 08:30:23 --> Language Class Initialized
DEBUG - 2011-08-15 08:30:23 --> Loader Class Initialized
DEBUG - 2011-08-15 08:30:23 --> Controller Class Initialized
ERROR - 2011-08-15 08:30:23 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-15 08:30:23 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-15 08:30:23 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-15 08:30:23 --> Model Class Initialized
DEBUG - 2011-08-15 08:30:23 --> Model Class Initialized
DEBUG - 2011-08-15 08:30:23 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-15 08:30:23 --> Database Driver Class Initialized
DEBUG - 2011-08-15 08:30:23 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-15 08:30:23 --> Helper loaded: url_helper
DEBUG - 2011-08-15 08:30:23 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-15 08:30:23 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-15 08:30:23 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-15 08:30:23 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-15 08:30:23 --> Final output sent to browser
DEBUG - 2011-08-15 08:30:23 --> Total execution time: 0.0924
DEBUG - 2011-08-15 08:30:24 --> Config Class Initialized
DEBUG - 2011-08-15 08:30:24 --> Hooks Class Initialized
DEBUG - 2011-08-15 08:30:24 --> Utf8 Class Initialized
DEBUG - 2011-08-15 08:30:24 --> UTF-8 Support Enabled
DEBUG - 2011-08-15 08:30:24 --> URI Class Initialized
DEBUG - 2011-08-15 08:30:24 --> Router Class Initialized
DEBUG - 2011-08-15 08:30:24 --> Output Class Initialized
DEBUG - 2011-08-15 08:30:24 --> Input Class Initialized
DEBUG - 2011-08-15 08:30:24 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-15 08:30:24 --> Language Class Initialized
DEBUG - 2011-08-15 08:30:24 --> Loader Class Initialized
DEBUG - 2011-08-15 08:30:24 --> Controller Class Initialized
DEBUG - 2011-08-15 08:30:24 --> Model Class Initialized
DEBUG - 2011-08-15 08:30:24 --> Model Class Initialized
DEBUG - 2011-08-15 08:30:24 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-15 08:30:24 --> Database Driver Class Initialized
DEBUG - 2011-08-15 08:30:25 --> Final output sent to browser
DEBUG - 2011-08-15 08:30:25 --> Total execution time: 0.7667
DEBUG - 2011-08-15 08:30:26 --> Config Class Initialized
DEBUG - 2011-08-15 08:30:26 --> Hooks Class Initialized
DEBUG - 2011-08-15 08:30:26 --> Utf8 Class Initialized
DEBUG - 2011-08-15 08:30:26 --> UTF-8 Support Enabled
DEBUG - 2011-08-15 08:30:26 --> URI Class Initialized
DEBUG - 2011-08-15 08:30:26 --> Router Class Initialized
ERROR - 2011-08-15 08:30:26 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-15 08:30:26 --> Config Class Initialized
DEBUG - 2011-08-15 08:30:26 --> Hooks Class Initialized
DEBUG - 2011-08-15 08:30:26 --> Utf8 Class Initialized
DEBUG - 2011-08-15 08:30:26 --> UTF-8 Support Enabled
DEBUG - 2011-08-15 08:30:26 --> URI Class Initialized
DEBUG - 2011-08-15 08:30:26 --> Router Class Initialized
ERROR - 2011-08-15 08:30:26 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-15 08:30:27 --> Config Class Initialized
DEBUG - 2011-08-15 08:30:27 --> Hooks Class Initialized
DEBUG - 2011-08-15 08:30:27 --> Utf8 Class Initialized
DEBUG - 2011-08-15 08:30:27 --> UTF-8 Support Enabled
DEBUG - 2011-08-15 08:30:27 --> URI Class Initialized
DEBUG - 2011-08-15 08:30:27 --> Router Class Initialized
ERROR - 2011-08-15 08:30:27 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-15 08:30:38 --> Config Class Initialized
DEBUG - 2011-08-15 08:30:38 --> Hooks Class Initialized
DEBUG - 2011-08-15 08:30:38 --> Utf8 Class Initialized
DEBUG - 2011-08-15 08:30:38 --> UTF-8 Support Enabled
DEBUG - 2011-08-15 08:30:38 --> URI Class Initialized
DEBUG - 2011-08-15 08:30:38 --> Router Class Initialized
DEBUG - 2011-08-15 08:30:38 --> Output Class Initialized
DEBUG - 2011-08-15 08:30:38 --> Input Class Initialized
DEBUG - 2011-08-15 08:30:38 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-15 08:30:38 --> Language Class Initialized
DEBUG - 2011-08-15 08:30:38 --> Loader Class Initialized
DEBUG - 2011-08-15 08:30:38 --> Controller Class Initialized
ERROR - 2011-08-15 08:30:38 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-15 08:30:38 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-15 08:30:38 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-15 08:30:38 --> Model Class Initialized
DEBUG - 2011-08-15 08:30:38 --> Model Class Initialized
DEBUG - 2011-08-15 08:30:38 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-15 08:30:38 --> Database Driver Class Initialized
DEBUG - 2011-08-15 08:30:38 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-15 08:30:38 --> Helper loaded: url_helper
DEBUG - 2011-08-15 08:30:38 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-15 08:30:38 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-15 08:30:38 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-15 08:30:38 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-15 08:30:38 --> Final output sent to browser
DEBUG - 2011-08-15 08:30:38 --> Total execution time: 0.0286
DEBUG - 2011-08-15 08:30:39 --> Config Class Initialized
DEBUG - 2011-08-15 08:30:39 --> Hooks Class Initialized
DEBUG - 2011-08-15 08:30:39 --> Utf8 Class Initialized
DEBUG - 2011-08-15 08:30:39 --> UTF-8 Support Enabled
DEBUG - 2011-08-15 08:30:39 --> URI Class Initialized
DEBUG - 2011-08-15 08:30:39 --> Router Class Initialized
DEBUG - 2011-08-15 08:30:39 --> Output Class Initialized
DEBUG - 2011-08-15 08:30:39 --> Input Class Initialized
DEBUG - 2011-08-15 08:30:39 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-15 08:30:39 --> Language Class Initialized
DEBUG - 2011-08-15 08:30:39 --> Loader Class Initialized
DEBUG - 2011-08-15 08:30:39 --> Controller Class Initialized
DEBUG - 2011-08-15 08:30:39 --> Model Class Initialized
DEBUG - 2011-08-15 08:30:39 --> Model Class Initialized
DEBUG - 2011-08-15 08:30:39 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-15 08:30:39 --> Database Driver Class Initialized
DEBUG - 2011-08-15 08:30:40 --> Final output sent to browser
DEBUG - 2011-08-15 08:30:40 --> Total execution time: 0.5745
DEBUG - 2011-08-15 08:30:46 --> Config Class Initialized
DEBUG - 2011-08-15 08:30:46 --> Hooks Class Initialized
DEBUG - 2011-08-15 08:30:46 --> Utf8 Class Initialized
DEBUG - 2011-08-15 08:30:46 --> UTF-8 Support Enabled
DEBUG - 2011-08-15 08:30:46 --> URI Class Initialized
DEBUG - 2011-08-15 08:30:46 --> Router Class Initialized
DEBUG - 2011-08-15 08:30:46 --> Output Class Initialized
DEBUG - 2011-08-15 08:30:46 --> Input Class Initialized
DEBUG - 2011-08-15 08:30:46 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-15 08:30:46 --> Language Class Initialized
DEBUG - 2011-08-15 08:30:46 --> Loader Class Initialized
DEBUG - 2011-08-15 08:30:46 --> Controller Class Initialized
ERROR - 2011-08-15 08:30:46 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-15 08:30:46 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-15 08:30:46 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-15 08:30:46 --> Model Class Initialized
DEBUG - 2011-08-15 08:30:46 --> Model Class Initialized
DEBUG - 2011-08-15 08:30:46 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-15 08:30:46 --> Database Driver Class Initialized
DEBUG - 2011-08-15 08:30:46 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-15 08:30:46 --> Helper loaded: url_helper
DEBUG - 2011-08-15 08:30:46 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-15 08:30:46 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-15 08:30:46 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-15 08:30:46 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-15 08:30:46 --> Final output sent to browser
DEBUG - 2011-08-15 08:30:46 --> Total execution time: 0.0481
DEBUG - 2011-08-15 08:30:47 --> Config Class Initialized
DEBUG - 2011-08-15 08:30:47 --> Hooks Class Initialized
DEBUG - 2011-08-15 08:30:47 --> Utf8 Class Initialized
DEBUG - 2011-08-15 08:30:47 --> UTF-8 Support Enabled
DEBUG - 2011-08-15 08:30:47 --> URI Class Initialized
DEBUG - 2011-08-15 08:30:47 --> Router Class Initialized
DEBUG - 2011-08-15 08:30:47 --> Output Class Initialized
DEBUG - 2011-08-15 08:30:47 --> Input Class Initialized
DEBUG - 2011-08-15 08:30:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-15 08:30:47 --> Language Class Initialized
DEBUG - 2011-08-15 08:30:47 --> Loader Class Initialized
DEBUG - 2011-08-15 08:30:47 --> Controller Class Initialized
DEBUG - 2011-08-15 08:30:47 --> Model Class Initialized
DEBUG - 2011-08-15 08:30:47 --> Model Class Initialized
DEBUG - 2011-08-15 08:30:47 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-15 08:30:48 --> Database Driver Class Initialized
DEBUG - 2011-08-15 08:30:48 --> Final output sent to browser
DEBUG - 2011-08-15 08:30:48 --> Total execution time: 0.9483
DEBUG - 2011-08-15 08:30:58 --> Config Class Initialized
DEBUG - 2011-08-15 08:30:58 --> Hooks Class Initialized
DEBUG - 2011-08-15 08:30:58 --> Utf8 Class Initialized
DEBUG - 2011-08-15 08:30:58 --> UTF-8 Support Enabled
DEBUG - 2011-08-15 08:30:58 --> URI Class Initialized
DEBUG - 2011-08-15 08:30:58 --> Router Class Initialized
DEBUG - 2011-08-15 08:30:58 --> Output Class Initialized
DEBUG - 2011-08-15 08:30:58 --> Input Class Initialized
DEBUG - 2011-08-15 08:30:58 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-15 08:30:58 --> Language Class Initialized
DEBUG - 2011-08-15 08:30:58 --> Loader Class Initialized
DEBUG - 2011-08-15 08:30:58 --> Controller Class Initialized
ERROR - 2011-08-15 08:30:58 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-15 08:30:58 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-15 08:30:58 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-15 08:30:58 --> Model Class Initialized
DEBUG - 2011-08-15 08:30:58 --> Model Class Initialized
DEBUG - 2011-08-15 08:30:58 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-15 08:30:58 --> Database Driver Class Initialized
DEBUG - 2011-08-15 08:30:58 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-15 08:30:58 --> Helper loaded: url_helper
DEBUG - 2011-08-15 08:30:58 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-15 08:30:58 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-15 08:30:58 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-15 08:30:58 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-15 08:30:58 --> Final output sent to browser
DEBUG - 2011-08-15 08:30:58 --> Total execution time: 0.0463
DEBUG - 2011-08-15 08:30:59 --> Config Class Initialized
DEBUG - 2011-08-15 08:30:59 --> Hooks Class Initialized
DEBUG - 2011-08-15 08:30:59 --> Utf8 Class Initialized
DEBUG - 2011-08-15 08:30:59 --> UTF-8 Support Enabled
DEBUG - 2011-08-15 08:30:59 --> URI Class Initialized
DEBUG - 2011-08-15 08:30:59 --> Router Class Initialized
DEBUG - 2011-08-15 08:30:59 --> Output Class Initialized
DEBUG - 2011-08-15 08:30:59 --> Input Class Initialized
DEBUG - 2011-08-15 08:30:59 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-15 08:30:59 --> Language Class Initialized
DEBUG - 2011-08-15 08:30:59 --> Loader Class Initialized
DEBUG - 2011-08-15 08:30:59 --> Controller Class Initialized
DEBUG - 2011-08-15 08:30:59 --> Model Class Initialized
DEBUG - 2011-08-15 08:30:59 --> Model Class Initialized
DEBUG - 2011-08-15 08:30:59 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-15 08:30:59 --> Database Driver Class Initialized
DEBUG - 2011-08-15 08:31:00 --> Final output sent to browser
DEBUG - 2011-08-15 08:31:00 --> Total execution time: 0.6153
DEBUG - 2011-08-15 08:31:31 --> Config Class Initialized
DEBUG - 2011-08-15 08:31:31 --> Hooks Class Initialized
DEBUG - 2011-08-15 08:31:31 --> Utf8 Class Initialized
DEBUG - 2011-08-15 08:31:31 --> UTF-8 Support Enabled
DEBUG - 2011-08-15 08:31:31 --> URI Class Initialized
DEBUG - 2011-08-15 08:31:31 --> Router Class Initialized
ERROR - 2011-08-15 08:31:31 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-08-15 08:31:31 --> Config Class Initialized
DEBUG - 2011-08-15 08:31:31 --> Hooks Class Initialized
DEBUG - 2011-08-15 08:31:31 --> Utf8 Class Initialized
DEBUG - 2011-08-15 08:31:31 --> UTF-8 Support Enabled
DEBUG - 2011-08-15 08:31:31 --> URI Class Initialized
DEBUG - 2011-08-15 08:31:31 --> Router Class Initialized
DEBUG - 2011-08-15 08:31:31 --> Output Class Initialized
DEBUG - 2011-08-15 08:31:31 --> Input Class Initialized
DEBUG - 2011-08-15 08:31:31 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-15 08:31:31 --> Language Class Initialized
DEBUG - 2011-08-15 08:31:31 --> Loader Class Initialized
DEBUG - 2011-08-15 08:31:31 --> Controller Class Initialized
ERROR - 2011-08-15 08:31:31 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-15 08:31:31 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-15 08:31:31 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-15 08:31:31 --> Model Class Initialized
DEBUG - 2011-08-15 08:31:31 --> Model Class Initialized
DEBUG - 2011-08-15 08:31:31 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-15 08:31:31 --> Database Driver Class Initialized
DEBUG - 2011-08-15 08:31:31 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-15 08:31:31 --> Helper loaded: url_helper
DEBUG - 2011-08-15 08:31:31 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-15 08:31:31 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-15 08:31:31 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-15 08:31:31 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-15 08:31:31 --> Final output sent to browser
DEBUG - 2011-08-15 08:31:31 --> Total execution time: 0.0408
DEBUG - 2011-08-15 09:12:13 --> Config Class Initialized
DEBUG - 2011-08-15 09:12:13 --> Hooks Class Initialized
DEBUG - 2011-08-15 09:12:13 --> Utf8 Class Initialized
DEBUG - 2011-08-15 09:12:13 --> UTF-8 Support Enabled
DEBUG - 2011-08-15 09:12:13 --> URI Class Initialized
DEBUG - 2011-08-15 09:12:13 --> Router Class Initialized
DEBUG - 2011-08-15 09:12:13 --> Output Class Initialized
DEBUG - 2011-08-15 09:12:13 --> Input Class Initialized
DEBUG - 2011-08-15 09:12:13 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-15 09:12:13 --> Language Class Initialized
DEBUG - 2011-08-15 09:12:13 --> Loader Class Initialized
DEBUG - 2011-08-15 09:12:13 --> Controller Class Initialized
DEBUG - 2011-08-15 09:12:13 --> Model Class Initialized
DEBUG - 2011-08-15 09:12:13 --> Model Class Initialized
DEBUG - 2011-08-15 09:12:13 --> Model Class Initialized
DEBUG - 2011-08-15 09:12:13 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-15 09:12:13 --> Database Driver Class Initialized
DEBUG - 2011-08-15 09:12:13 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-15 09:12:13 --> Helper loaded: url_helper
DEBUG - 2011-08-15 09:12:13 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-15 09:12:13 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-15 09:12:13 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-15 09:12:13 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-15 09:12:13 --> Final output sent to browser
DEBUG - 2011-08-15 09:12:13 --> Total execution time: 0.5320
DEBUG - 2011-08-15 09:12:14 --> Config Class Initialized
DEBUG - 2011-08-15 09:12:14 --> Hooks Class Initialized
DEBUG - 2011-08-15 09:12:14 --> Utf8 Class Initialized
DEBUG - 2011-08-15 09:12:14 --> UTF-8 Support Enabled
DEBUG - 2011-08-15 09:12:14 --> URI Class Initialized
DEBUG - 2011-08-15 09:12:14 --> Router Class Initialized
ERROR - 2011-08-15 09:12:14 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-15 09:47:13 --> Config Class Initialized
DEBUG - 2011-08-15 09:47:13 --> Hooks Class Initialized
DEBUG - 2011-08-15 09:47:13 --> Utf8 Class Initialized
DEBUG - 2011-08-15 09:47:13 --> UTF-8 Support Enabled
DEBUG - 2011-08-15 09:47:13 --> URI Class Initialized
DEBUG - 2011-08-15 09:47:13 --> Router Class Initialized
DEBUG - 2011-08-15 09:47:13 --> Output Class Initialized
DEBUG - 2011-08-15 09:47:13 --> Input Class Initialized
DEBUG - 2011-08-15 09:47:13 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-15 09:47:13 --> Language Class Initialized
DEBUG - 2011-08-15 09:47:13 --> Loader Class Initialized
DEBUG - 2011-08-15 09:47:13 --> Controller Class Initialized
ERROR - 2011-08-15 09:47:13 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-15 09:47:13 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-15 09:47:13 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-15 09:47:13 --> Model Class Initialized
DEBUG - 2011-08-15 09:47:13 --> Model Class Initialized
DEBUG - 2011-08-15 09:47:13 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-15 09:47:13 --> Database Driver Class Initialized
DEBUG - 2011-08-15 09:47:13 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-15 09:47:13 --> Helper loaded: url_helper
DEBUG - 2011-08-15 09:47:13 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-15 09:47:13 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-15 09:47:13 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-15 09:47:13 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-15 09:47:13 --> Final output sent to browser
DEBUG - 2011-08-15 09:47:13 --> Total execution time: 0.3017
DEBUG - 2011-08-15 09:47:14 --> Config Class Initialized
DEBUG - 2011-08-15 09:47:14 --> Hooks Class Initialized
DEBUG - 2011-08-15 09:47:14 --> Utf8 Class Initialized
DEBUG - 2011-08-15 09:47:14 --> UTF-8 Support Enabled
DEBUG - 2011-08-15 09:47:14 --> URI Class Initialized
DEBUG - 2011-08-15 09:47:14 --> Router Class Initialized
DEBUG - 2011-08-15 09:47:14 --> Output Class Initialized
DEBUG - 2011-08-15 09:47:14 --> Input Class Initialized
DEBUG - 2011-08-15 09:47:14 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-15 09:47:14 --> Language Class Initialized
DEBUG - 2011-08-15 09:47:14 --> Loader Class Initialized
DEBUG - 2011-08-15 09:47:14 --> Controller Class Initialized
DEBUG - 2011-08-15 09:47:14 --> Model Class Initialized
DEBUG - 2011-08-15 09:47:14 --> Model Class Initialized
DEBUG - 2011-08-15 09:47:14 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-15 09:47:14 --> Database Driver Class Initialized
DEBUG - 2011-08-15 09:47:15 --> Final output sent to browser
DEBUG - 2011-08-15 09:47:15 --> Total execution time: 0.6687
DEBUG - 2011-08-15 09:47:16 --> Config Class Initialized
DEBUG - 2011-08-15 09:47:16 --> Hooks Class Initialized
DEBUG - 2011-08-15 09:47:16 --> Utf8 Class Initialized
DEBUG - 2011-08-15 09:47:16 --> UTF-8 Support Enabled
DEBUG - 2011-08-15 09:47:16 --> URI Class Initialized
DEBUG - 2011-08-15 09:47:16 --> Router Class Initialized
ERROR - 2011-08-15 09:47:16 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-15 09:47:17 --> Config Class Initialized
DEBUG - 2011-08-15 09:47:17 --> Hooks Class Initialized
DEBUG - 2011-08-15 09:47:17 --> Utf8 Class Initialized
DEBUG - 2011-08-15 09:47:17 --> UTF-8 Support Enabled
DEBUG - 2011-08-15 09:47:17 --> URI Class Initialized
DEBUG - 2011-08-15 09:47:17 --> Router Class Initialized
ERROR - 2011-08-15 09:47:17 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-15 10:12:02 --> Config Class Initialized
DEBUG - 2011-08-15 10:12:02 --> Hooks Class Initialized
DEBUG - 2011-08-15 10:12:02 --> Utf8 Class Initialized
DEBUG - 2011-08-15 10:12:02 --> UTF-8 Support Enabled
DEBUG - 2011-08-15 10:12:02 --> URI Class Initialized
DEBUG - 2011-08-15 10:12:02 --> Router Class Initialized
ERROR - 2011-08-15 10:12:02 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-08-15 12:05:03 --> Config Class Initialized
DEBUG - 2011-08-15 12:05:03 --> Hooks Class Initialized
DEBUG - 2011-08-15 12:05:03 --> Utf8 Class Initialized
DEBUG - 2011-08-15 12:05:03 --> UTF-8 Support Enabled
DEBUG - 2011-08-15 12:05:03 --> URI Class Initialized
DEBUG - 2011-08-15 12:05:03 --> Router Class Initialized
DEBUG - 2011-08-15 12:05:03 --> Output Class Initialized
DEBUG - 2011-08-15 12:05:03 --> Input Class Initialized
DEBUG - 2011-08-15 12:05:03 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-15 12:05:03 --> Language Class Initialized
DEBUG - 2011-08-15 12:05:03 --> Loader Class Initialized
DEBUG - 2011-08-15 12:05:03 --> Controller Class Initialized
ERROR - 2011-08-15 12:05:03 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-15 12:05:03 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-15 12:05:03 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-15 12:05:03 --> Model Class Initialized
DEBUG - 2011-08-15 12:05:03 --> Model Class Initialized
DEBUG - 2011-08-15 12:05:03 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-15 12:05:03 --> Database Driver Class Initialized
DEBUG - 2011-08-15 12:05:03 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-15 12:05:03 --> Helper loaded: url_helper
DEBUG - 2011-08-15 12:05:03 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-15 12:05:03 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-15 12:05:03 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-15 12:05:03 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-15 12:05:03 --> Final output sent to browser
DEBUG - 2011-08-15 12:05:03 --> Total execution time: 0.2652
DEBUG - 2011-08-15 12:05:04 --> Config Class Initialized
DEBUG - 2011-08-15 12:05:04 --> Hooks Class Initialized
DEBUG - 2011-08-15 12:05:04 --> Utf8 Class Initialized
DEBUG - 2011-08-15 12:05:04 --> UTF-8 Support Enabled
DEBUG - 2011-08-15 12:05:04 --> URI Class Initialized
DEBUG - 2011-08-15 12:05:04 --> Router Class Initialized
DEBUG - 2011-08-15 12:05:04 --> Output Class Initialized
DEBUG - 2011-08-15 12:05:04 --> Input Class Initialized
DEBUG - 2011-08-15 12:05:04 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-15 12:05:04 --> Language Class Initialized
DEBUG - 2011-08-15 12:05:04 --> Loader Class Initialized
DEBUG - 2011-08-15 12:05:04 --> Controller Class Initialized
DEBUG - 2011-08-15 12:05:04 --> Model Class Initialized
DEBUG - 2011-08-15 12:05:04 --> Model Class Initialized
DEBUG - 2011-08-15 12:05:04 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-15 12:05:04 --> Database Driver Class Initialized
DEBUG - 2011-08-15 12:05:04 --> Final output sent to browser
DEBUG - 2011-08-15 12:05:04 --> Total execution time: 0.8435
DEBUG - 2011-08-15 12:05:05 --> Config Class Initialized
DEBUG - 2011-08-15 12:05:05 --> Hooks Class Initialized
DEBUG - 2011-08-15 12:05:05 --> Utf8 Class Initialized
DEBUG - 2011-08-15 12:05:05 --> UTF-8 Support Enabled
DEBUG - 2011-08-15 12:05:05 --> URI Class Initialized
DEBUG - 2011-08-15 12:05:05 --> Router Class Initialized
ERROR - 2011-08-15 12:05:05 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-15 12:06:39 --> Config Class Initialized
DEBUG - 2011-08-15 12:06:39 --> Hooks Class Initialized
DEBUG - 2011-08-15 12:06:39 --> Utf8 Class Initialized
DEBUG - 2011-08-15 12:06:39 --> UTF-8 Support Enabled
DEBUG - 2011-08-15 12:06:39 --> URI Class Initialized
DEBUG - 2011-08-15 12:06:39 --> Router Class Initialized
DEBUG - 2011-08-15 12:06:39 --> Output Class Initialized
DEBUG - 2011-08-15 12:06:39 --> Input Class Initialized
DEBUG - 2011-08-15 12:06:39 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-15 12:06:39 --> Language Class Initialized
DEBUG - 2011-08-15 12:06:39 --> Loader Class Initialized
DEBUG - 2011-08-15 12:06:39 --> Controller Class Initialized
DEBUG - 2011-08-15 12:06:39 --> Model Class Initialized
DEBUG - 2011-08-15 12:06:39 --> Model Class Initialized
DEBUG - 2011-08-15 12:06:39 --> Model Class Initialized
DEBUG - 2011-08-15 12:06:39 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-15 12:06:39 --> Database Driver Class Initialized
DEBUG - 2011-08-15 12:06:40 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-15 12:06:40 --> Helper loaded: url_helper
DEBUG - 2011-08-15 12:06:40 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-15 12:06:40 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-15 12:06:40 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-15 12:06:40 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-15 12:06:40 --> Final output sent to browser
DEBUG - 2011-08-15 12:06:40 --> Total execution time: 0.4754
DEBUG - 2011-08-15 12:06:42 --> Config Class Initialized
DEBUG - 2011-08-15 12:06:42 --> Hooks Class Initialized
DEBUG - 2011-08-15 12:06:42 --> Utf8 Class Initialized
DEBUG - 2011-08-15 12:06:42 --> UTF-8 Support Enabled
DEBUG - 2011-08-15 12:06:42 --> URI Class Initialized
DEBUG - 2011-08-15 12:06:42 --> Router Class Initialized
ERROR - 2011-08-15 12:06:42 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-15 12:06:42 --> Config Class Initialized
DEBUG - 2011-08-15 12:06:42 --> Hooks Class Initialized
DEBUG - 2011-08-15 12:06:42 --> Utf8 Class Initialized
DEBUG - 2011-08-15 12:06:42 --> UTF-8 Support Enabled
DEBUG - 2011-08-15 12:06:42 --> URI Class Initialized
DEBUG - 2011-08-15 12:06:42 --> Router Class Initialized
ERROR - 2011-08-15 12:06:42 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-15 12:06:42 --> Config Class Initialized
DEBUG - 2011-08-15 12:06:42 --> Hooks Class Initialized
DEBUG - 2011-08-15 12:06:42 --> Utf8 Class Initialized
DEBUG - 2011-08-15 12:06:42 --> UTF-8 Support Enabled
DEBUG - 2011-08-15 12:06:42 --> URI Class Initialized
DEBUG - 2011-08-15 12:06:42 --> Router Class Initialized
ERROR - 2011-08-15 12:06:42 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-15 12:07:01 --> Config Class Initialized
DEBUG - 2011-08-15 12:07:01 --> Hooks Class Initialized
DEBUG - 2011-08-15 12:07:01 --> Utf8 Class Initialized
DEBUG - 2011-08-15 12:07:01 --> UTF-8 Support Enabled
DEBUG - 2011-08-15 12:07:01 --> URI Class Initialized
DEBUG - 2011-08-15 12:07:01 --> Router Class Initialized
DEBUG - 2011-08-15 12:07:01 --> Output Class Initialized
DEBUG - 2011-08-15 12:07:01 --> Input Class Initialized
DEBUG - 2011-08-15 12:07:01 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-15 12:07:01 --> Language Class Initialized
DEBUG - 2011-08-15 12:07:01 --> Loader Class Initialized
DEBUG - 2011-08-15 12:07:01 --> Controller Class Initialized
DEBUG - 2011-08-15 12:07:01 --> Model Class Initialized
DEBUG - 2011-08-15 12:07:01 --> Model Class Initialized
DEBUG - 2011-08-15 12:07:01 --> Model Class Initialized
DEBUG - 2011-08-15 12:07:01 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-15 12:07:01 --> Database Driver Class Initialized
DEBUG - 2011-08-15 12:07:01 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-15 12:07:01 --> Helper loaded: url_helper
DEBUG - 2011-08-15 12:07:01 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-15 12:07:01 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-15 12:07:01 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-15 12:07:01 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-15 12:07:01 --> Final output sent to browser
DEBUG - 2011-08-15 12:07:01 --> Total execution time: 0.0822
DEBUG - 2011-08-15 12:07:20 --> Config Class Initialized
DEBUG - 2011-08-15 12:07:20 --> Hooks Class Initialized
DEBUG - 2011-08-15 12:07:20 --> Utf8 Class Initialized
DEBUG - 2011-08-15 12:07:20 --> UTF-8 Support Enabled
DEBUG - 2011-08-15 12:07:20 --> URI Class Initialized
DEBUG - 2011-08-15 12:07:20 --> Router Class Initialized
DEBUG - 2011-08-15 12:07:20 --> Output Class Initialized
DEBUG - 2011-08-15 12:07:20 --> Input Class Initialized
DEBUG - 2011-08-15 12:07:20 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-15 12:07:20 --> Language Class Initialized
DEBUG - 2011-08-15 12:07:20 --> Loader Class Initialized
DEBUG - 2011-08-15 12:07:20 --> Controller Class Initialized
DEBUG - 2011-08-15 12:07:20 --> Model Class Initialized
DEBUG - 2011-08-15 12:07:20 --> Model Class Initialized
DEBUG - 2011-08-15 12:07:20 --> Model Class Initialized
DEBUG - 2011-08-15 12:07:20 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-15 12:07:20 --> Database Driver Class Initialized
DEBUG - 2011-08-15 12:07:22 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-15 12:07:22 --> Helper loaded: url_helper
DEBUG - 2011-08-15 12:07:22 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-15 12:07:22 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-15 12:07:22 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-15 12:07:22 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-15 12:07:22 --> Final output sent to browser
DEBUG - 2011-08-15 12:07:22 --> Total execution time: 2.0188
DEBUG - 2011-08-15 12:07:36 --> Config Class Initialized
DEBUG - 2011-08-15 12:07:36 --> Hooks Class Initialized
DEBUG - 2011-08-15 12:07:36 --> Utf8 Class Initialized
DEBUG - 2011-08-15 12:07:36 --> UTF-8 Support Enabled
DEBUG - 2011-08-15 12:07:36 --> URI Class Initialized
DEBUG - 2011-08-15 12:07:36 --> Router Class Initialized
DEBUG - 2011-08-15 12:07:36 --> Output Class Initialized
DEBUG - 2011-08-15 12:07:36 --> Input Class Initialized
DEBUG - 2011-08-15 12:07:36 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-15 12:07:36 --> Language Class Initialized
DEBUG - 2011-08-15 12:07:36 --> Loader Class Initialized
DEBUG - 2011-08-15 12:07:36 --> Controller Class Initialized
DEBUG - 2011-08-15 12:07:36 --> Model Class Initialized
DEBUG - 2011-08-15 12:07:36 --> Model Class Initialized
DEBUG - 2011-08-15 12:07:36 --> Model Class Initialized
DEBUG - 2011-08-15 12:07:36 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-15 12:07:36 --> Database Driver Class Initialized
DEBUG - 2011-08-15 12:07:37 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-15 12:07:37 --> Helper loaded: url_helper
DEBUG - 2011-08-15 12:07:37 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-15 12:07:37 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-15 12:07:37 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-15 12:07:37 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-15 12:07:37 --> Final output sent to browser
DEBUG - 2011-08-15 12:07:37 --> Total execution time: 0.8441
DEBUG - 2011-08-15 12:07:53 --> Config Class Initialized
DEBUG - 2011-08-15 12:07:53 --> Hooks Class Initialized
DEBUG - 2011-08-15 12:07:53 --> Utf8 Class Initialized
DEBUG - 2011-08-15 12:07:53 --> UTF-8 Support Enabled
DEBUG - 2011-08-15 12:07:53 --> URI Class Initialized
DEBUG - 2011-08-15 12:07:53 --> Router Class Initialized
DEBUG - 2011-08-15 12:07:53 --> Output Class Initialized
DEBUG - 2011-08-15 12:07:53 --> Input Class Initialized
DEBUG - 2011-08-15 12:07:53 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-15 12:07:53 --> Language Class Initialized
DEBUG - 2011-08-15 12:07:53 --> Loader Class Initialized
DEBUG - 2011-08-15 12:07:53 --> Controller Class Initialized
DEBUG - 2011-08-15 12:07:53 --> Model Class Initialized
DEBUG - 2011-08-15 12:07:53 --> Model Class Initialized
DEBUG - 2011-08-15 12:07:53 --> Model Class Initialized
DEBUG - 2011-08-15 12:07:53 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-15 12:07:53 --> Database Driver Class Initialized
DEBUG - 2011-08-15 12:07:54 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-15 12:07:54 --> Helper loaded: url_helper
DEBUG - 2011-08-15 12:07:54 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-15 12:07:54 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-15 12:07:54 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-15 12:07:54 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-15 12:07:54 --> Final output sent to browser
DEBUG - 2011-08-15 12:07:54 --> Total execution time: 0.7524
DEBUG - 2011-08-15 12:08:04 --> Config Class Initialized
DEBUG - 2011-08-15 12:08:04 --> Hooks Class Initialized
DEBUG - 2011-08-15 12:08:04 --> Utf8 Class Initialized
DEBUG - 2011-08-15 12:08:04 --> UTF-8 Support Enabled
DEBUG - 2011-08-15 12:08:04 --> URI Class Initialized
DEBUG - 2011-08-15 12:08:04 --> Router Class Initialized
DEBUG - 2011-08-15 12:08:04 --> Output Class Initialized
DEBUG - 2011-08-15 12:08:04 --> Input Class Initialized
DEBUG - 2011-08-15 12:08:04 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-15 12:08:04 --> Language Class Initialized
DEBUG - 2011-08-15 12:08:04 --> Loader Class Initialized
DEBUG - 2011-08-15 12:08:04 --> Controller Class Initialized
DEBUG - 2011-08-15 12:08:04 --> Model Class Initialized
DEBUG - 2011-08-15 12:08:04 --> Model Class Initialized
DEBUG - 2011-08-15 12:08:04 --> Model Class Initialized
DEBUG - 2011-08-15 12:08:04 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-15 12:08:04 --> Database Driver Class Initialized
DEBUG - 2011-08-15 12:08:05 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-15 12:08:05 --> Helper loaded: url_helper
DEBUG - 2011-08-15 12:08:05 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-15 12:08:05 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-15 12:08:05 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-15 12:08:05 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-15 12:08:05 --> Final output sent to browser
DEBUG - 2011-08-15 12:08:05 --> Total execution time: 0.7895
DEBUG - 2011-08-15 12:20:07 --> Config Class Initialized
DEBUG - 2011-08-15 12:20:07 --> Hooks Class Initialized
DEBUG - 2011-08-15 12:20:07 --> Utf8 Class Initialized
DEBUG - 2011-08-15 12:20:07 --> UTF-8 Support Enabled
DEBUG - 2011-08-15 12:20:07 --> URI Class Initialized
DEBUG - 2011-08-15 12:20:07 --> Router Class Initialized
DEBUG - 2011-08-15 12:20:07 --> Output Class Initialized
DEBUG - 2011-08-15 12:20:07 --> Input Class Initialized
DEBUG - 2011-08-15 12:20:07 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-15 12:20:07 --> Language Class Initialized
DEBUG - 2011-08-15 12:20:07 --> Loader Class Initialized
DEBUG - 2011-08-15 12:20:07 --> Controller Class Initialized
ERROR - 2011-08-15 12:20:07 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-15 12:20:07 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-15 12:20:07 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-15 12:20:07 --> Model Class Initialized
DEBUG - 2011-08-15 12:20:07 --> Model Class Initialized
DEBUG - 2011-08-15 12:20:07 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-15 12:20:07 --> Database Driver Class Initialized
DEBUG - 2011-08-15 12:20:07 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-15 12:20:07 --> Helper loaded: url_helper
DEBUG - 2011-08-15 12:20:07 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-15 12:20:07 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-15 12:20:07 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-15 12:20:07 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-15 12:20:07 --> Final output sent to browser
DEBUG - 2011-08-15 12:20:07 --> Total execution time: 0.1696
DEBUG - 2011-08-15 12:20:08 --> Config Class Initialized
DEBUG - 2011-08-15 12:20:08 --> Hooks Class Initialized
DEBUG - 2011-08-15 12:20:08 --> Utf8 Class Initialized
DEBUG - 2011-08-15 12:20:08 --> UTF-8 Support Enabled
DEBUG - 2011-08-15 12:20:08 --> URI Class Initialized
DEBUG - 2011-08-15 12:20:08 --> Router Class Initialized
DEBUG - 2011-08-15 12:20:08 --> Output Class Initialized
DEBUG - 2011-08-15 12:20:08 --> Input Class Initialized
DEBUG - 2011-08-15 12:20:08 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-15 12:20:08 --> Language Class Initialized
DEBUG - 2011-08-15 12:20:08 --> Loader Class Initialized
DEBUG - 2011-08-15 12:20:08 --> Controller Class Initialized
DEBUG - 2011-08-15 12:20:08 --> Model Class Initialized
DEBUG - 2011-08-15 12:20:08 --> Model Class Initialized
DEBUG - 2011-08-15 12:20:08 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-15 12:20:08 --> Database Driver Class Initialized
DEBUG - 2011-08-15 12:20:09 --> Final output sent to browser
DEBUG - 2011-08-15 12:20:09 --> Total execution time: 0.6296
DEBUG - 2011-08-15 12:20:11 --> Config Class Initialized
DEBUG - 2011-08-15 12:20:11 --> Hooks Class Initialized
DEBUG - 2011-08-15 12:20:11 --> Utf8 Class Initialized
DEBUG - 2011-08-15 12:20:11 --> UTF-8 Support Enabled
DEBUG - 2011-08-15 12:20:11 --> URI Class Initialized
DEBUG - 2011-08-15 12:20:11 --> Router Class Initialized
ERROR - 2011-08-15 12:20:11 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-15 12:20:11 --> Config Class Initialized
DEBUG - 2011-08-15 12:20:11 --> Hooks Class Initialized
DEBUG - 2011-08-15 12:20:11 --> Utf8 Class Initialized
DEBUG - 2011-08-15 12:20:11 --> UTF-8 Support Enabled
DEBUG - 2011-08-15 12:20:11 --> URI Class Initialized
DEBUG - 2011-08-15 12:20:11 --> Router Class Initialized
ERROR - 2011-08-15 12:20:11 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-15 12:20:11 --> Config Class Initialized
DEBUG - 2011-08-15 12:20:11 --> Hooks Class Initialized
DEBUG - 2011-08-15 12:20:11 --> Utf8 Class Initialized
DEBUG - 2011-08-15 12:20:11 --> UTF-8 Support Enabled
DEBUG - 2011-08-15 12:20:11 --> URI Class Initialized
DEBUG - 2011-08-15 12:20:11 --> Router Class Initialized
ERROR - 2011-08-15 12:20:11 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-15 12:20:26 --> Config Class Initialized
DEBUG - 2011-08-15 12:20:26 --> Hooks Class Initialized
DEBUG - 2011-08-15 12:20:26 --> Utf8 Class Initialized
DEBUG - 2011-08-15 12:20:26 --> UTF-8 Support Enabled
DEBUG - 2011-08-15 12:20:26 --> URI Class Initialized
DEBUG - 2011-08-15 12:20:26 --> Router Class Initialized
DEBUG - 2011-08-15 12:20:26 --> Output Class Initialized
DEBUG - 2011-08-15 12:20:26 --> Input Class Initialized
DEBUG - 2011-08-15 12:20:26 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-15 12:20:26 --> Language Class Initialized
DEBUG - 2011-08-15 12:20:26 --> Loader Class Initialized
DEBUG - 2011-08-15 12:20:26 --> Controller Class Initialized
ERROR - 2011-08-15 12:20:26 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-15 12:20:26 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-15 12:20:26 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-15 12:20:26 --> Model Class Initialized
DEBUG - 2011-08-15 12:20:26 --> Model Class Initialized
DEBUG - 2011-08-15 12:20:26 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-15 12:20:26 --> Database Driver Class Initialized
DEBUG - 2011-08-15 12:20:26 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-15 12:20:26 --> Helper loaded: url_helper
DEBUG - 2011-08-15 12:20:26 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-15 12:20:26 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-15 12:20:26 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-15 12:20:26 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-15 12:20:26 --> Final output sent to browser
DEBUG - 2011-08-15 12:20:26 --> Total execution time: 0.0727
DEBUG - 2011-08-15 12:20:26 --> Config Class Initialized
DEBUG - 2011-08-15 12:20:26 --> Hooks Class Initialized
DEBUG - 2011-08-15 12:20:26 --> Utf8 Class Initialized
DEBUG - 2011-08-15 12:20:26 --> UTF-8 Support Enabled
DEBUG - 2011-08-15 12:20:26 --> URI Class Initialized
DEBUG - 2011-08-15 12:20:26 --> Router Class Initialized
DEBUG - 2011-08-15 12:20:26 --> Output Class Initialized
DEBUG - 2011-08-15 12:20:26 --> Input Class Initialized
DEBUG - 2011-08-15 12:20:26 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-15 12:20:26 --> Language Class Initialized
DEBUG - 2011-08-15 12:20:26 --> Loader Class Initialized
DEBUG - 2011-08-15 12:20:26 --> Controller Class Initialized
DEBUG - 2011-08-15 12:20:26 --> Model Class Initialized
DEBUG - 2011-08-15 12:20:26 --> Model Class Initialized
DEBUG - 2011-08-15 12:20:26 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-15 12:20:26 --> Database Driver Class Initialized
DEBUG - 2011-08-15 12:20:27 --> Final output sent to browser
DEBUG - 2011-08-15 12:20:27 --> Total execution time: 0.4996
DEBUG - 2011-08-15 12:20:38 --> Config Class Initialized
DEBUG - 2011-08-15 12:20:38 --> Hooks Class Initialized
DEBUG - 2011-08-15 12:20:38 --> Utf8 Class Initialized
DEBUG - 2011-08-15 12:20:38 --> UTF-8 Support Enabled
DEBUG - 2011-08-15 12:20:38 --> URI Class Initialized
DEBUG - 2011-08-15 12:20:38 --> Router Class Initialized
DEBUG - 2011-08-15 12:20:38 --> Output Class Initialized
DEBUG - 2011-08-15 12:20:38 --> Input Class Initialized
DEBUG - 2011-08-15 12:20:38 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-15 12:20:38 --> Language Class Initialized
DEBUG - 2011-08-15 12:20:38 --> Loader Class Initialized
DEBUG - 2011-08-15 12:20:38 --> Controller Class Initialized
ERROR - 2011-08-15 12:20:38 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-15 12:20:38 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-15 12:20:38 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-15 12:20:38 --> Model Class Initialized
DEBUG - 2011-08-15 12:20:38 --> Model Class Initialized
DEBUG - 2011-08-15 12:20:38 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-15 12:20:38 --> Database Driver Class Initialized
DEBUG - 2011-08-15 12:20:38 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-15 12:20:38 --> Helper loaded: url_helper
DEBUG - 2011-08-15 12:20:38 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-15 12:20:38 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-15 12:20:38 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-15 12:20:38 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-15 12:20:38 --> Final output sent to browser
DEBUG - 2011-08-15 12:20:38 --> Total execution time: 0.0378
DEBUG - 2011-08-15 12:20:39 --> Config Class Initialized
DEBUG - 2011-08-15 12:20:39 --> Hooks Class Initialized
DEBUG - 2011-08-15 12:20:39 --> Utf8 Class Initialized
DEBUG - 2011-08-15 12:20:39 --> UTF-8 Support Enabled
DEBUG - 2011-08-15 12:20:39 --> URI Class Initialized
DEBUG - 2011-08-15 12:20:39 --> Router Class Initialized
DEBUG - 2011-08-15 12:20:39 --> Output Class Initialized
DEBUG - 2011-08-15 12:20:39 --> Input Class Initialized
DEBUG - 2011-08-15 12:20:39 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-15 12:20:39 --> Language Class Initialized
DEBUG - 2011-08-15 12:20:39 --> Loader Class Initialized
DEBUG - 2011-08-15 12:20:39 --> Controller Class Initialized
ERROR - 2011-08-15 12:20:39 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-15 12:20:39 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-15 12:20:39 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-15 12:20:39 --> Model Class Initialized
DEBUG - 2011-08-15 12:20:39 --> Model Class Initialized
DEBUG - 2011-08-15 12:20:39 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-15 12:20:39 --> Database Driver Class Initialized
DEBUG - 2011-08-15 12:20:39 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-15 12:20:39 --> Helper loaded: url_helper
DEBUG - 2011-08-15 12:20:39 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-15 12:20:39 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-15 12:20:39 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-15 12:20:39 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-15 12:20:39 --> Final output sent to browser
DEBUG - 2011-08-15 12:20:39 --> Total execution time: 0.0749
DEBUG - 2011-08-15 12:20:39 --> Config Class Initialized
DEBUG - 2011-08-15 12:20:39 --> Hooks Class Initialized
DEBUG - 2011-08-15 12:20:39 --> Utf8 Class Initialized
DEBUG - 2011-08-15 12:20:39 --> UTF-8 Support Enabled
DEBUG - 2011-08-15 12:20:39 --> URI Class Initialized
DEBUG - 2011-08-15 12:20:39 --> Router Class Initialized
DEBUG - 2011-08-15 12:20:39 --> Output Class Initialized
DEBUG - 2011-08-15 12:20:39 --> Input Class Initialized
DEBUG - 2011-08-15 12:20:39 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-15 12:20:39 --> Language Class Initialized
DEBUG - 2011-08-15 12:20:39 --> Loader Class Initialized
DEBUG - 2011-08-15 12:20:39 --> Controller Class Initialized
DEBUG - 2011-08-15 12:20:39 --> Model Class Initialized
DEBUG - 2011-08-15 12:20:39 --> Model Class Initialized
DEBUG - 2011-08-15 12:20:39 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-15 12:20:39 --> Database Driver Class Initialized
DEBUG - 2011-08-15 12:20:40 --> Final output sent to browser
DEBUG - 2011-08-15 12:20:40 --> Total execution time: 0.5737
DEBUG - 2011-08-15 12:20:40 --> Config Class Initialized
DEBUG - 2011-08-15 12:20:40 --> Hooks Class Initialized
DEBUG - 2011-08-15 12:20:40 --> Utf8 Class Initialized
DEBUG - 2011-08-15 12:20:40 --> UTF-8 Support Enabled
DEBUG - 2011-08-15 12:20:40 --> URI Class Initialized
DEBUG - 2011-08-15 12:20:40 --> Router Class Initialized
ERROR - 2011-08-15 12:20:40 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-08-15 12:20:41 --> Config Class Initialized
DEBUG - 2011-08-15 12:20:41 --> Hooks Class Initialized
DEBUG - 2011-08-15 12:20:41 --> Utf8 Class Initialized
DEBUG - 2011-08-15 12:20:41 --> UTF-8 Support Enabled
DEBUG - 2011-08-15 12:20:41 --> URI Class Initialized
DEBUG - 2011-08-15 12:20:41 --> Router Class Initialized
DEBUG - 2011-08-15 12:20:41 --> Output Class Initialized
DEBUG - 2011-08-15 12:20:41 --> Input Class Initialized
DEBUG - 2011-08-15 12:20:41 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-15 12:20:41 --> Language Class Initialized
DEBUG - 2011-08-15 12:20:41 --> Loader Class Initialized
DEBUG - 2011-08-15 12:20:41 --> Controller Class Initialized
DEBUG - 2011-08-15 12:20:41 --> Model Class Initialized
DEBUG - 2011-08-15 12:20:41 --> Model Class Initialized
DEBUG - 2011-08-15 12:20:41 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-15 12:20:41 --> Database Driver Class Initialized
DEBUG - 2011-08-15 12:20:41 --> Final output sent to browser
DEBUG - 2011-08-15 12:20:41 --> Total execution time: 0.3903
DEBUG - 2011-08-15 12:20:59 --> Config Class Initialized
DEBUG - 2011-08-15 12:20:59 --> Hooks Class Initialized
DEBUG - 2011-08-15 12:20:59 --> Utf8 Class Initialized
DEBUG - 2011-08-15 12:20:59 --> UTF-8 Support Enabled
DEBUG - 2011-08-15 12:20:59 --> URI Class Initialized
DEBUG - 2011-08-15 12:20:59 --> Router Class Initialized
DEBUG - 2011-08-15 12:20:59 --> Output Class Initialized
DEBUG - 2011-08-15 12:20:59 --> Input Class Initialized
DEBUG - 2011-08-15 12:20:59 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-15 12:20:59 --> Language Class Initialized
DEBUG - 2011-08-15 12:20:59 --> Loader Class Initialized
DEBUG - 2011-08-15 12:20:59 --> Controller Class Initialized
ERROR - 2011-08-15 12:20:59 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-15 12:20:59 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-15 12:20:59 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-15 12:20:59 --> Model Class Initialized
DEBUG - 2011-08-15 12:20:59 --> Model Class Initialized
DEBUG - 2011-08-15 12:20:59 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-15 12:20:59 --> Database Driver Class Initialized
DEBUG - 2011-08-15 12:20:59 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-15 12:20:59 --> Helper loaded: url_helper
DEBUG - 2011-08-15 12:20:59 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-15 12:20:59 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-15 12:20:59 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-15 12:20:59 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-15 12:20:59 --> Final output sent to browser
DEBUG - 2011-08-15 12:20:59 --> Total execution time: 0.0316
DEBUG - 2011-08-15 12:21:00 --> Config Class Initialized
DEBUG - 2011-08-15 12:21:00 --> Hooks Class Initialized
DEBUG - 2011-08-15 12:21:00 --> Utf8 Class Initialized
DEBUG - 2011-08-15 12:21:00 --> UTF-8 Support Enabled
DEBUG - 2011-08-15 12:21:00 --> URI Class Initialized
DEBUG - 2011-08-15 12:21:00 --> Router Class Initialized
DEBUG - 2011-08-15 12:21:00 --> Output Class Initialized
DEBUG - 2011-08-15 12:21:00 --> Input Class Initialized
DEBUG - 2011-08-15 12:21:00 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-15 12:21:00 --> Language Class Initialized
DEBUG - 2011-08-15 12:21:00 --> Loader Class Initialized
DEBUG - 2011-08-15 12:21:00 --> Controller Class Initialized
DEBUG - 2011-08-15 12:21:00 --> Model Class Initialized
DEBUG - 2011-08-15 12:21:00 --> Model Class Initialized
DEBUG - 2011-08-15 12:21:00 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-15 12:21:00 --> Database Driver Class Initialized
DEBUG - 2011-08-15 12:21:01 --> Final output sent to browser
DEBUG - 2011-08-15 12:21:01 --> Total execution time: 0.5805
DEBUG - 2011-08-15 12:21:31 --> Config Class Initialized
DEBUG - 2011-08-15 12:21:31 --> Hooks Class Initialized
DEBUG - 2011-08-15 12:21:31 --> Utf8 Class Initialized
DEBUG - 2011-08-15 12:21:31 --> UTF-8 Support Enabled
DEBUG - 2011-08-15 12:21:31 --> URI Class Initialized
DEBUG - 2011-08-15 12:21:31 --> Router Class Initialized
DEBUG - 2011-08-15 12:21:31 --> Output Class Initialized
DEBUG - 2011-08-15 12:21:31 --> Input Class Initialized
DEBUG - 2011-08-15 12:21:31 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-15 12:21:31 --> Language Class Initialized
DEBUG - 2011-08-15 12:21:31 --> Loader Class Initialized
DEBUG - 2011-08-15 12:21:31 --> Controller Class Initialized
ERROR - 2011-08-15 12:21:31 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-15 12:21:31 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-15 12:21:31 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-15 12:21:31 --> Model Class Initialized
DEBUG - 2011-08-15 12:21:31 --> Model Class Initialized
DEBUG - 2011-08-15 12:21:31 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-15 12:21:31 --> Database Driver Class Initialized
DEBUG - 2011-08-15 12:21:31 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-15 12:21:31 --> Helper loaded: url_helper
DEBUG - 2011-08-15 12:21:31 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-15 12:21:31 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-15 12:21:31 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-15 12:21:31 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-15 12:21:31 --> Final output sent to browser
DEBUG - 2011-08-15 12:21:31 --> Total execution time: 0.0441
DEBUG - 2011-08-15 12:21:32 --> Config Class Initialized
DEBUG - 2011-08-15 12:21:32 --> Hooks Class Initialized
DEBUG - 2011-08-15 12:21:32 --> Utf8 Class Initialized
DEBUG - 2011-08-15 12:21:32 --> UTF-8 Support Enabled
DEBUG - 2011-08-15 12:21:32 --> URI Class Initialized
DEBUG - 2011-08-15 12:21:32 --> Router Class Initialized
DEBUG - 2011-08-15 12:21:32 --> Output Class Initialized
DEBUG - 2011-08-15 12:21:32 --> Input Class Initialized
DEBUG - 2011-08-15 12:21:32 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-15 12:21:32 --> Language Class Initialized
DEBUG - 2011-08-15 12:21:32 --> Loader Class Initialized
DEBUG - 2011-08-15 12:21:32 --> Controller Class Initialized
DEBUG - 2011-08-15 12:21:32 --> Model Class Initialized
DEBUG - 2011-08-15 12:21:32 --> Model Class Initialized
DEBUG - 2011-08-15 12:21:32 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-15 12:21:32 --> Database Driver Class Initialized
DEBUG - 2011-08-15 12:21:32 --> Final output sent to browser
DEBUG - 2011-08-15 12:21:32 --> Total execution time: 0.6464
DEBUG - 2011-08-15 12:21:47 --> Config Class Initialized
DEBUG - 2011-08-15 12:21:47 --> Hooks Class Initialized
DEBUG - 2011-08-15 12:21:47 --> Utf8 Class Initialized
DEBUG - 2011-08-15 12:21:47 --> UTF-8 Support Enabled
DEBUG - 2011-08-15 12:21:47 --> URI Class Initialized
DEBUG - 2011-08-15 12:21:47 --> Router Class Initialized
DEBUG - 2011-08-15 12:21:47 --> Output Class Initialized
DEBUG - 2011-08-15 12:21:47 --> Input Class Initialized
DEBUG - 2011-08-15 12:21:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-15 12:21:47 --> Language Class Initialized
DEBUG - 2011-08-15 12:21:47 --> Loader Class Initialized
DEBUG - 2011-08-15 12:21:47 --> Controller Class Initialized
ERROR - 2011-08-15 12:21:47 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-15 12:21:47 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-15 12:21:47 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-15 12:21:47 --> Model Class Initialized
DEBUG - 2011-08-15 12:21:47 --> Model Class Initialized
DEBUG - 2011-08-15 12:21:47 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-15 12:21:47 --> Database Driver Class Initialized
DEBUG - 2011-08-15 12:21:47 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-15 12:21:47 --> Helper loaded: url_helper
DEBUG - 2011-08-15 12:21:47 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-15 12:21:47 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-15 12:21:47 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-15 12:21:47 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-15 12:21:47 --> Final output sent to browser
DEBUG - 2011-08-15 12:21:47 --> Total execution time: 0.1469
DEBUG - 2011-08-15 12:21:48 --> Config Class Initialized
DEBUG - 2011-08-15 12:21:48 --> Hooks Class Initialized
DEBUG - 2011-08-15 12:21:48 --> Utf8 Class Initialized
DEBUG - 2011-08-15 12:21:48 --> UTF-8 Support Enabled
DEBUG - 2011-08-15 12:21:48 --> URI Class Initialized
DEBUG - 2011-08-15 12:21:48 --> Router Class Initialized
DEBUG - 2011-08-15 12:21:48 --> Output Class Initialized
DEBUG - 2011-08-15 12:21:48 --> Input Class Initialized
DEBUG - 2011-08-15 12:21:48 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-15 12:21:48 --> Language Class Initialized
DEBUG - 2011-08-15 12:21:48 --> Loader Class Initialized
DEBUG - 2011-08-15 12:21:48 --> Controller Class Initialized
DEBUG - 2011-08-15 12:21:48 --> Model Class Initialized
DEBUG - 2011-08-15 12:21:48 --> Model Class Initialized
DEBUG - 2011-08-15 12:21:48 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-15 12:21:48 --> Database Driver Class Initialized
DEBUG - 2011-08-15 12:21:49 --> Final output sent to browser
DEBUG - 2011-08-15 12:21:49 --> Total execution time: 0.5186
DEBUG - 2011-08-15 12:22:27 --> Config Class Initialized
DEBUG - 2011-08-15 12:22:27 --> Hooks Class Initialized
DEBUG - 2011-08-15 12:22:27 --> Utf8 Class Initialized
DEBUG - 2011-08-15 12:22:27 --> UTF-8 Support Enabled
DEBUG - 2011-08-15 12:22:27 --> URI Class Initialized
DEBUG - 2011-08-15 12:22:27 --> Router Class Initialized
DEBUG - 2011-08-15 12:22:27 --> Output Class Initialized
DEBUG - 2011-08-15 12:22:27 --> Input Class Initialized
DEBUG - 2011-08-15 12:22:27 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-15 12:22:27 --> Language Class Initialized
DEBUG - 2011-08-15 12:22:27 --> Loader Class Initialized
DEBUG - 2011-08-15 12:22:27 --> Controller Class Initialized
ERROR - 2011-08-15 12:22:27 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-15 12:22:27 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-15 12:22:27 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-15 12:22:27 --> Model Class Initialized
DEBUG - 2011-08-15 12:22:27 --> Model Class Initialized
DEBUG - 2011-08-15 12:22:27 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-15 12:22:27 --> Database Driver Class Initialized
DEBUG - 2011-08-15 12:22:27 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-15 12:22:27 --> Helper loaded: url_helper
DEBUG - 2011-08-15 12:22:27 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-15 12:22:27 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-15 12:22:27 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-15 12:22:27 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-15 12:22:27 --> Final output sent to browser
DEBUG - 2011-08-15 12:22:27 --> Total execution time: 0.0327
DEBUG - 2011-08-15 12:22:28 --> Config Class Initialized
DEBUG - 2011-08-15 12:22:28 --> Hooks Class Initialized
DEBUG - 2011-08-15 12:22:28 --> Utf8 Class Initialized
DEBUG - 2011-08-15 12:22:28 --> UTF-8 Support Enabled
DEBUG - 2011-08-15 12:22:28 --> URI Class Initialized
DEBUG - 2011-08-15 12:22:28 --> Router Class Initialized
DEBUG - 2011-08-15 12:22:28 --> Output Class Initialized
DEBUG - 2011-08-15 12:22:28 --> Input Class Initialized
DEBUG - 2011-08-15 12:22:28 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-15 12:22:28 --> Language Class Initialized
DEBUG - 2011-08-15 12:22:28 --> Loader Class Initialized
DEBUG - 2011-08-15 12:22:28 --> Controller Class Initialized
DEBUG - 2011-08-15 12:22:28 --> Model Class Initialized
DEBUG - 2011-08-15 12:22:28 --> Model Class Initialized
DEBUG - 2011-08-15 12:22:28 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-15 12:22:28 --> Database Driver Class Initialized
DEBUG - 2011-08-15 12:22:28 --> Final output sent to browser
DEBUG - 2011-08-15 12:22:28 --> Total execution time: 0.5241
DEBUG - 2011-08-15 12:22:47 --> Config Class Initialized
DEBUG - 2011-08-15 12:22:47 --> Hooks Class Initialized
DEBUG - 2011-08-15 12:22:47 --> Utf8 Class Initialized
DEBUG - 2011-08-15 12:22:47 --> UTF-8 Support Enabled
DEBUG - 2011-08-15 12:22:47 --> URI Class Initialized
DEBUG - 2011-08-15 12:22:47 --> Router Class Initialized
DEBUG - 2011-08-15 12:22:47 --> Output Class Initialized
DEBUG - 2011-08-15 12:22:47 --> Input Class Initialized
DEBUG - 2011-08-15 12:22:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-15 12:22:47 --> Language Class Initialized
DEBUG - 2011-08-15 12:22:47 --> Loader Class Initialized
DEBUG - 2011-08-15 12:22:47 --> Controller Class Initialized
ERROR - 2011-08-15 12:22:47 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-15 12:22:47 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-15 12:22:47 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-15 12:22:47 --> Model Class Initialized
DEBUG - 2011-08-15 12:22:47 --> Model Class Initialized
DEBUG - 2011-08-15 12:22:47 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-15 12:22:47 --> Database Driver Class Initialized
DEBUG - 2011-08-15 12:22:47 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-15 12:22:47 --> Helper loaded: url_helper
DEBUG - 2011-08-15 12:22:47 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-15 12:22:47 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-15 12:22:47 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-15 12:22:47 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-15 12:22:47 --> Final output sent to browser
DEBUG - 2011-08-15 12:22:47 --> Total execution time: 0.0282
DEBUG - 2011-08-15 12:22:48 --> Config Class Initialized
DEBUG - 2011-08-15 12:22:48 --> Hooks Class Initialized
DEBUG - 2011-08-15 12:22:48 --> Utf8 Class Initialized
DEBUG - 2011-08-15 12:22:48 --> UTF-8 Support Enabled
DEBUG - 2011-08-15 12:22:48 --> URI Class Initialized
DEBUG - 2011-08-15 12:22:48 --> Router Class Initialized
DEBUG - 2011-08-15 12:22:48 --> Output Class Initialized
DEBUG - 2011-08-15 12:22:48 --> Input Class Initialized
DEBUG - 2011-08-15 12:22:48 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-15 12:22:48 --> Language Class Initialized
DEBUG - 2011-08-15 12:22:48 --> Loader Class Initialized
DEBUG - 2011-08-15 12:22:48 --> Controller Class Initialized
DEBUG - 2011-08-15 12:22:48 --> Model Class Initialized
DEBUG - 2011-08-15 12:22:48 --> Model Class Initialized
DEBUG - 2011-08-15 12:22:48 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-15 12:22:48 --> Database Driver Class Initialized
DEBUG - 2011-08-15 12:22:48 --> Final output sent to browser
DEBUG - 2011-08-15 12:22:48 --> Total execution time: 0.5330
DEBUG - 2011-08-15 12:23:07 --> Config Class Initialized
DEBUG - 2011-08-15 12:23:07 --> Hooks Class Initialized
DEBUG - 2011-08-15 12:23:07 --> Utf8 Class Initialized
DEBUG - 2011-08-15 12:23:07 --> UTF-8 Support Enabled
DEBUG - 2011-08-15 12:23:07 --> URI Class Initialized
DEBUG - 2011-08-15 12:23:07 --> Router Class Initialized
DEBUG - 2011-08-15 12:23:07 --> Output Class Initialized
DEBUG - 2011-08-15 12:23:07 --> Input Class Initialized
DEBUG - 2011-08-15 12:23:07 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-15 12:23:07 --> Language Class Initialized
DEBUG - 2011-08-15 12:23:07 --> Loader Class Initialized
DEBUG - 2011-08-15 12:23:07 --> Controller Class Initialized
DEBUG - 2011-08-15 12:23:07 --> Model Class Initialized
DEBUG - 2011-08-15 12:23:07 --> Model Class Initialized
DEBUG - 2011-08-15 12:23:07 --> Model Class Initialized
DEBUG - 2011-08-15 12:23:07 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-15 12:23:07 --> Database Driver Class Initialized
DEBUG - 2011-08-15 12:23:07 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-15 12:23:07 --> Helper loaded: url_helper
DEBUG - 2011-08-15 12:23:07 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-15 12:23:07 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-15 12:23:07 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-15 12:23:07 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-15 12:23:07 --> Final output sent to browser
DEBUG - 2011-08-15 12:23:07 --> Total execution time: 0.4124
DEBUG - 2011-08-15 12:23:15 --> Config Class Initialized
DEBUG - 2011-08-15 12:23:15 --> Hooks Class Initialized
DEBUG - 2011-08-15 12:23:15 --> Utf8 Class Initialized
DEBUG - 2011-08-15 12:23:15 --> UTF-8 Support Enabled
DEBUG - 2011-08-15 12:23:15 --> URI Class Initialized
DEBUG - 2011-08-15 12:23:15 --> Router Class Initialized
DEBUG - 2011-08-15 12:23:15 --> Output Class Initialized
DEBUG - 2011-08-15 12:23:15 --> Input Class Initialized
DEBUG - 2011-08-15 12:23:15 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-15 12:23:15 --> Language Class Initialized
DEBUG - 2011-08-15 12:23:15 --> Loader Class Initialized
DEBUG - 2011-08-15 12:23:15 --> Controller Class Initialized
DEBUG - 2011-08-15 12:23:15 --> Model Class Initialized
DEBUG - 2011-08-15 12:23:15 --> Model Class Initialized
DEBUG - 2011-08-15 12:23:15 --> Model Class Initialized
DEBUG - 2011-08-15 12:23:15 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-15 12:23:15 --> Database Driver Class Initialized
DEBUG - 2011-08-15 12:23:16 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-15 12:23:16 --> Helper loaded: url_helper
DEBUG - 2011-08-15 12:23:16 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-15 12:23:16 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-15 12:23:16 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-15 12:23:16 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-15 12:23:16 --> Final output sent to browser
DEBUG - 2011-08-15 12:23:16 --> Total execution time: 0.4537
DEBUG - 2011-08-15 12:23:36 --> Config Class Initialized
DEBUG - 2011-08-15 12:23:36 --> Hooks Class Initialized
DEBUG - 2011-08-15 12:23:36 --> Utf8 Class Initialized
DEBUG - 2011-08-15 12:23:36 --> UTF-8 Support Enabled
DEBUG - 2011-08-15 12:23:36 --> URI Class Initialized
DEBUG - 2011-08-15 12:23:36 --> Router Class Initialized
DEBUG - 2011-08-15 12:23:36 --> Output Class Initialized
DEBUG - 2011-08-15 12:23:36 --> Input Class Initialized
DEBUG - 2011-08-15 12:23:36 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-15 12:23:36 --> Language Class Initialized
DEBUG - 2011-08-15 12:23:36 --> Loader Class Initialized
DEBUG - 2011-08-15 12:23:36 --> Controller Class Initialized
ERROR - 2011-08-15 12:23:36 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-15 12:23:36 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-15 12:23:36 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-15 12:23:36 --> Model Class Initialized
DEBUG - 2011-08-15 12:23:36 --> Model Class Initialized
DEBUG - 2011-08-15 12:23:36 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-15 12:23:36 --> Database Driver Class Initialized
DEBUG - 2011-08-15 12:23:36 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-15 12:23:36 --> Helper loaded: url_helper
DEBUG - 2011-08-15 12:23:36 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-15 12:23:36 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-15 12:23:36 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-15 12:23:36 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-15 12:23:36 --> Final output sent to browser
DEBUG - 2011-08-15 12:23:36 --> Total execution time: 0.0337
DEBUG - 2011-08-15 12:23:37 --> Config Class Initialized
DEBUG - 2011-08-15 12:23:37 --> Hooks Class Initialized
DEBUG - 2011-08-15 12:23:37 --> Utf8 Class Initialized
DEBUG - 2011-08-15 12:23:37 --> UTF-8 Support Enabled
DEBUG - 2011-08-15 12:23:37 --> URI Class Initialized
DEBUG - 2011-08-15 12:23:37 --> Router Class Initialized
DEBUG - 2011-08-15 12:23:37 --> Output Class Initialized
DEBUG - 2011-08-15 12:23:37 --> Input Class Initialized
DEBUG - 2011-08-15 12:23:37 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-15 12:23:37 --> Language Class Initialized
DEBUG - 2011-08-15 12:23:37 --> Loader Class Initialized
DEBUG - 2011-08-15 12:23:37 --> Controller Class Initialized
DEBUG - 2011-08-15 12:23:37 --> Model Class Initialized
DEBUG - 2011-08-15 12:23:37 --> Model Class Initialized
DEBUG - 2011-08-15 12:23:37 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-15 12:23:37 --> Database Driver Class Initialized
DEBUG - 2011-08-15 12:23:38 --> Final output sent to browser
DEBUG - 2011-08-15 12:23:38 --> Total execution time: 0.5625
DEBUG - 2011-08-15 12:23:39 --> Config Class Initialized
DEBUG - 2011-08-15 12:23:39 --> Hooks Class Initialized
DEBUG - 2011-08-15 12:23:39 --> Utf8 Class Initialized
DEBUG - 2011-08-15 12:23:39 --> UTF-8 Support Enabled
DEBUG - 2011-08-15 12:23:39 --> URI Class Initialized
DEBUG - 2011-08-15 12:23:39 --> Router Class Initialized
DEBUG - 2011-08-15 12:23:39 --> Output Class Initialized
DEBUG - 2011-08-15 12:23:39 --> Input Class Initialized
DEBUG - 2011-08-15 12:23:39 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-15 12:23:39 --> Language Class Initialized
DEBUG - 2011-08-15 12:23:39 --> Loader Class Initialized
DEBUG - 2011-08-15 12:23:39 --> Controller Class Initialized
DEBUG - 2011-08-15 12:23:39 --> Model Class Initialized
DEBUG - 2011-08-15 12:23:39 --> Model Class Initialized
DEBUG - 2011-08-15 12:23:39 --> Model Class Initialized
DEBUG - 2011-08-15 12:23:39 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-15 12:23:39 --> Database Driver Class Initialized
DEBUG - 2011-08-15 12:23:39 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-15 12:23:39 --> Helper loaded: url_helper
DEBUG - 2011-08-15 12:23:39 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-15 12:23:39 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-15 12:23:39 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-15 12:23:39 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-15 12:23:39 --> Final output sent to browser
DEBUG - 2011-08-15 12:23:39 --> Total execution time: 0.0490
DEBUG - 2011-08-15 12:23:55 --> Config Class Initialized
DEBUG - 2011-08-15 12:23:55 --> Hooks Class Initialized
DEBUG - 2011-08-15 12:23:55 --> Utf8 Class Initialized
DEBUG - 2011-08-15 12:23:55 --> UTF-8 Support Enabled
DEBUG - 2011-08-15 12:23:55 --> URI Class Initialized
DEBUG - 2011-08-15 12:23:55 --> Router Class Initialized
DEBUG - 2011-08-15 12:23:55 --> Output Class Initialized
DEBUG - 2011-08-15 12:23:55 --> Input Class Initialized
DEBUG - 2011-08-15 12:23:55 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-15 12:23:55 --> Language Class Initialized
DEBUG - 2011-08-15 12:23:55 --> Loader Class Initialized
DEBUG - 2011-08-15 12:23:55 --> Controller Class Initialized
ERROR - 2011-08-15 12:23:55 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-15 12:23:55 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-15 12:23:55 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-15 12:23:55 --> Model Class Initialized
DEBUG - 2011-08-15 12:23:55 --> Model Class Initialized
DEBUG - 2011-08-15 12:23:55 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-15 12:23:55 --> Database Driver Class Initialized
DEBUG - 2011-08-15 12:23:55 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-15 12:23:55 --> Helper loaded: url_helper
DEBUG - 2011-08-15 12:23:55 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-15 12:23:55 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-15 12:23:55 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-15 12:23:55 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-15 12:23:55 --> Final output sent to browser
DEBUG - 2011-08-15 12:23:55 --> Total execution time: 0.0273
DEBUG - 2011-08-15 12:23:56 --> Config Class Initialized
DEBUG - 2011-08-15 12:23:56 --> Hooks Class Initialized
DEBUG - 2011-08-15 12:23:56 --> Utf8 Class Initialized
DEBUG - 2011-08-15 12:23:56 --> UTF-8 Support Enabled
DEBUG - 2011-08-15 12:23:56 --> URI Class Initialized
DEBUG - 2011-08-15 12:23:56 --> Router Class Initialized
DEBUG - 2011-08-15 12:23:56 --> Output Class Initialized
DEBUG - 2011-08-15 12:23:56 --> Input Class Initialized
DEBUG - 2011-08-15 12:23:56 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-15 12:23:56 --> Language Class Initialized
DEBUG - 2011-08-15 12:23:56 --> Loader Class Initialized
DEBUG - 2011-08-15 12:23:56 --> Controller Class Initialized
DEBUG - 2011-08-15 12:23:56 --> Model Class Initialized
DEBUG - 2011-08-15 12:23:56 --> Model Class Initialized
DEBUG - 2011-08-15 12:23:56 --> Model Class Initialized
DEBUG - 2011-08-15 12:23:56 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-15 12:23:56 --> Database Driver Class Initialized
DEBUG - 2011-08-15 12:23:56 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-15 12:23:56 --> Helper loaded: url_helper
DEBUG - 2011-08-15 12:23:56 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-15 12:23:56 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-15 12:23:56 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-15 12:23:56 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-15 12:23:56 --> Final output sent to browser
DEBUG - 2011-08-15 12:23:56 --> Total execution time: 0.0745
DEBUG - 2011-08-15 12:23:56 --> Config Class Initialized
DEBUG - 2011-08-15 12:23:56 --> Hooks Class Initialized
DEBUG - 2011-08-15 12:23:56 --> Utf8 Class Initialized
DEBUG - 2011-08-15 12:23:56 --> UTF-8 Support Enabled
DEBUG - 2011-08-15 12:23:56 --> URI Class Initialized
DEBUG - 2011-08-15 12:23:57 --> Router Class Initialized
DEBUG - 2011-08-15 12:23:57 --> Output Class Initialized
DEBUG - 2011-08-15 12:23:57 --> Input Class Initialized
DEBUG - 2011-08-15 12:23:57 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-15 12:23:57 --> Language Class Initialized
DEBUG - 2011-08-15 12:23:57 --> Loader Class Initialized
DEBUG - 2011-08-15 12:23:57 --> Controller Class Initialized
DEBUG - 2011-08-15 12:23:57 --> Model Class Initialized
DEBUG - 2011-08-15 12:23:57 --> Model Class Initialized
DEBUG - 2011-08-15 12:23:57 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-15 12:23:57 --> Database Driver Class Initialized
DEBUG - 2011-08-15 12:23:57 --> Final output sent to browser
DEBUG - 2011-08-15 12:23:57 --> Total execution time: 0.6292
DEBUG - 2011-08-15 12:24:15 --> Config Class Initialized
DEBUG - 2011-08-15 12:24:15 --> Hooks Class Initialized
DEBUG - 2011-08-15 12:24:15 --> Utf8 Class Initialized
DEBUG - 2011-08-15 12:24:15 --> UTF-8 Support Enabled
DEBUG - 2011-08-15 12:24:15 --> URI Class Initialized
DEBUG - 2011-08-15 12:24:15 --> Router Class Initialized
DEBUG - 2011-08-15 12:24:15 --> Output Class Initialized
DEBUG - 2011-08-15 12:24:15 --> Input Class Initialized
DEBUG - 2011-08-15 12:24:15 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-15 12:24:15 --> Language Class Initialized
DEBUG - 2011-08-15 12:24:15 --> Loader Class Initialized
DEBUG - 2011-08-15 12:24:15 --> Controller Class Initialized
ERROR - 2011-08-15 12:24:15 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-15 12:24:15 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-15 12:24:15 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-15 12:24:15 --> Model Class Initialized
DEBUG - 2011-08-15 12:24:15 --> Model Class Initialized
DEBUG - 2011-08-15 12:24:15 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-15 12:24:15 --> Database Driver Class Initialized
DEBUG - 2011-08-15 12:24:15 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-15 12:24:15 --> Helper loaded: url_helper
DEBUG - 2011-08-15 12:24:15 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-15 12:24:15 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-15 12:24:15 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-15 12:24:15 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-15 12:24:15 --> Final output sent to browser
DEBUG - 2011-08-15 12:24:15 --> Total execution time: 0.0421
DEBUG - 2011-08-15 12:24:16 --> Config Class Initialized
DEBUG - 2011-08-15 12:24:16 --> Hooks Class Initialized
DEBUG - 2011-08-15 12:24:16 --> Utf8 Class Initialized
DEBUG - 2011-08-15 12:24:16 --> UTF-8 Support Enabled
DEBUG - 2011-08-15 12:24:16 --> URI Class Initialized
DEBUG - 2011-08-15 12:24:16 --> Router Class Initialized
DEBUG - 2011-08-15 12:24:16 --> Output Class Initialized
DEBUG - 2011-08-15 12:24:16 --> Input Class Initialized
DEBUG - 2011-08-15 12:24:16 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-15 12:24:16 --> Language Class Initialized
DEBUG - 2011-08-15 12:24:16 --> Loader Class Initialized
DEBUG - 2011-08-15 12:24:16 --> Controller Class Initialized
DEBUG - 2011-08-15 12:24:16 --> Model Class Initialized
DEBUG - 2011-08-15 12:24:16 --> Model Class Initialized
DEBUG - 2011-08-15 12:24:16 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-15 12:24:16 --> Database Driver Class Initialized
DEBUG - 2011-08-15 12:24:17 --> Final output sent to browser
DEBUG - 2011-08-15 12:24:17 --> Total execution time: 0.5928
DEBUG - 2011-08-15 12:24:44 --> Config Class Initialized
DEBUG - 2011-08-15 12:24:44 --> Hooks Class Initialized
DEBUG - 2011-08-15 12:24:44 --> Utf8 Class Initialized
DEBUG - 2011-08-15 12:24:44 --> UTF-8 Support Enabled
DEBUG - 2011-08-15 12:24:44 --> URI Class Initialized
DEBUG - 2011-08-15 12:24:44 --> Router Class Initialized
DEBUG - 2011-08-15 12:24:44 --> Output Class Initialized
DEBUG - 2011-08-15 12:24:44 --> Input Class Initialized
DEBUG - 2011-08-15 12:24:44 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-15 12:24:44 --> Language Class Initialized
DEBUG - 2011-08-15 12:24:44 --> Loader Class Initialized
DEBUG - 2011-08-15 12:24:44 --> Controller Class Initialized
ERROR - 2011-08-15 12:24:44 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-15 12:24:44 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-15 12:24:44 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-15 12:24:44 --> Model Class Initialized
DEBUG - 2011-08-15 12:24:44 --> Model Class Initialized
DEBUG - 2011-08-15 12:24:44 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-15 12:24:44 --> Database Driver Class Initialized
DEBUG - 2011-08-15 12:24:44 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-15 12:24:44 --> Helper loaded: url_helper
DEBUG - 2011-08-15 12:24:44 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-15 12:24:44 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-15 12:24:44 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-15 12:24:44 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-15 12:24:44 --> Final output sent to browser
DEBUG - 2011-08-15 12:24:44 --> Total execution time: 0.0321
DEBUG - 2011-08-15 12:24:45 --> Config Class Initialized
DEBUG - 2011-08-15 12:24:45 --> Hooks Class Initialized
DEBUG - 2011-08-15 12:24:45 --> Utf8 Class Initialized
DEBUG - 2011-08-15 12:24:45 --> UTF-8 Support Enabled
DEBUG - 2011-08-15 12:24:45 --> URI Class Initialized
DEBUG - 2011-08-15 12:24:45 --> Router Class Initialized
DEBUG - 2011-08-15 12:24:45 --> Output Class Initialized
DEBUG - 2011-08-15 12:24:45 --> Input Class Initialized
DEBUG - 2011-08-15 12:24:45 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-15 12:24:45 --> Language Class Initialized
DEBUG - 2011-08-15 12:24:45 --> Loader Class Initialized
DEBUG - 2011-08-15 12:24:45 --> Controller Class Initialized
DEBUG - 2011-08-15 12:24:45 --> Model Class Initialized
DEBUG - 2011-08-15 12:24:45 --> Model Class Initialized
DEBUG - 2011-08-15 12:24:45 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-15 12:24:45 --> Database Driver Class Initialized
DEBUG - 2011-08-15 12:24:46 --> Final output sent to browser
DEBUG - 2011-08-15 12:24:46 --> Total execution time: 0.6162
DEBUG - 2011-08-15 12:25:05 --> Config Class Initialized
DEBUG - 2011-08-15 12:25:05 --> Hooks Class Initialized
DEBUG - 2011-08-15 12:25:05 --> Utf8 Class Initialized
DEBUG - 2011-08-15 12:25:05 --> UTF-8 Support Enabled
DEBUG - 2011-08-15 12:25:05 --> URI Class Initialized
DEBUG - 2011-08-15 12:25:05 --> Router Class Initialized
DEBUG - 2011-08-15 12:25:05 --> Output Class Initialized
DEBUG - 2011-08-15 12:25:05 --> Input Class Initialized
DEBUG - 2011-08-15 12:25:05 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-15 12:25:05 --> Language Class Initialized
DEBUG - 2011-08-15 12:25:05 --> Loader Class Initialized
DEBUG - 2011-08-15 12:25:05 --> Controller Class Initialized
ERROR - 2011-08-15 12:25:05 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-15 12:25:05 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-15 12:25:05 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-15 12:25:05 --> Model Class Initialized
DEBUG - 2011-08-15 12:25:05 --> Model Class Initialized
DEBUG - 2011-08-15 12:25:05 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-15 12:25:05 --> Database Driver Class Initialized
DEBUG - 2011-08-15 12:25:05 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-15 12:25:05 --> Helper loaded: url_helper
DEBUG - 2011-08-15 12:25:05 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-15 12:25:05 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-15 12:25:05 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-15 12:25:05 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-15 12:25:05 --> Final output sent to browser
DEBUG - 2011-08-15 12:25:05 --> Total execution time: 0.1147
DEBUG - 2011-08-15 12:25:06 --> Config Class Initialized
DEBUG - 2011-08-15 12:25:06 --> Hooks Class Initialized
DEBUG - 2011-08-15 12:25:06 --> Utf8 Class Initialized
DEBUG - 2011-08-15 12:25:06 --> UTF-8 Support Enabled
DEBUG - 2011-08-15 12:25:06 --> URI Class Initialized
DEBUG - 2011-08-15 12:25:06 --> Router Class Initialized
DEBUG - 2011-08-15 12:25:06 --> Output Class Initialized
DEBUG - 2011-08-15 12:25:06 --> Input Class Initialized
DEBUG - 2011-08-15 12:25:06 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-15 12:25:06 --> Language Class Initialized
DEBUG - 2011-08-15 12:25:06 --> Loader Class Initialized
DEBUG - 2011-08-15 12:25:06 --> Controller Class Initialized
DEBUG - 2011-08-15 12:25:06 --> Model Class Initialized
DEBUG - 2011-08-15 12:25:06 --> Model Class Initialized
DEBUG - 2011-08-15 12:25:06 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-15 12:25:06 --> Database Driver Class Initialized
DEBUG - 2011-08-15 12:25:07 --> Final output sent to browser
DEBUG - 2011-08-15 12:25:07 --> Total execution time: 0.5840
DEBUG - 2011-08-15 12:32:27 --> Config Class Initialized
DEBUG - 2011-08-15 12:32:27 --> Hooks Class Initialized
DEBUG - 2011-08-15 12:32:27 --> Utf8 Class Initialized
DEBUG - 2011-08-15 12:32:27 --> UTF-8 Support Enabled
DEBUG - 2011-08-15 12:32:27 --> URI Class Initialized
DEBUG - 2011-08-15 12:32:27 --> Router Class Initialized
DEBUG - 2011-08-15 12:32:27 --> Output Class Initialized
DEBUG - 2011-08-15 12:32:27 --> Input Class Initialized
DEBUG - 2011-08-15 12:32:27 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-15 12:32:27 --> Language Class Initialized
DEBUG - 2011-08-15 12:32:27 --> Loader Class Initialized
DEBUG - 2011-08-15 12:32:27 --> Controller Class Initialized
ERROR - 2011-08-15 12:32:27 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-15 12:32:27 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-15 12:32:27 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-15 12:32:27 --> Model Class Initialized
DEBUG - 2011-08-15 12:32:27 --> Model Class Initialized
DEBUG - 2011-08-15 12:32:27 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-15 12:32:27 --> Database Driver Class Initialized
DEBUG - 2011-08-15 12:32:27 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-15 12:32:27 --> Helper loaded: url_helper
DEBUG - 2011-08-15 12:32:27 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-15 12:32:27 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-15 12:32:27 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-15 12:32:27 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-15 12:32:27 --> Final output sent to browser
DEBUG - 2011-08-15 12:32:27 --> Total execution time: 0.0410
DEBUG - 2011-08-15 12:32:28 --> Config Class Initialized
DEBUG - 2011-08-15 12:32:28 --> Hooks Class Initialized
DEBUG - 2011-08-15 12:32:28 --> Utf8 Class Initialized
DEBUG - 2011-08-15 12:32:28 --> UTF-8 Support Enabled
DEBUG - 2011-08-15 12:32:28 --> URI Class Initialized
DEBUG - 2011-08-15 12:32:28 --> Router Class Initialized
DEBUG - 2011-08-15 12:32:28 --> Output Class Initialized
DEBUG - 2011-08-15 12:32:28 --> Input Class Initialized
DEBUG - 2011-08-15 12:32:28 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-15 12:32:28 --> Language Class Initialized
DEBUG - 2011-08-15 12:32:28 --> Loader Class Initialized
DEBUG - 2011-08-15 12:32:28 --> Controller Class Initialized
DEBUG - 2011-08-15 12:32:28 --> Model Class Initialized
DEBUG - 2011-08-15 12:32:28 --> Model Class Initialized
DEBUG - 2011-08-15 12:32:28 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-15 12:32:28 --> Database Driver Class Initialized
DEBUG - 2011-08-15 12:32:28 --> Final output sent to browser
DEBUG - 2011-08-15 12:32:28 --> Total execution time: 0.4936
DEBUG - 2011-08-15 12:32:33 --> Config Class Initialized
DEBUG - 2011-08-15 12:32:33 --> Hooks Class Initialized
DEBUG - 2011-08-15 12:32:33 --> Utf8 Class Initialized
DEBUG - 2011-08-15 12:32:33 --> UTF-8 Support Enabled
DEBUG - 2011-08-15 12:32:33 --> URI Class Initialized
DEBUG - 2011-08-15 12:32:33 --> Router Class Initialized
DEBUG - 2011-08-15 12:32:33 --> Output Class Initialized
DEBUG - 2011-08-15 12:32:33 --> Input Class Initialized
DEBUG - 2011-08-15 12:32:33 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-15 12:32:33 --> Language Class Initialized
DEBUG - 2011-08-15 12:32:33 --> Loader Class Initialized
DEBUG - 2011-08-15 12:32:33 --> Controller Class Initialized
DEBUG - 2011-08-15 12:32:33 --> Model Class Initialized
DEBUG - 2011-08-15 12:32:33 --> Model Class Initialized
DEBUG - 2011-08-15 12:32:33 --> Model Class Initialized
DEBUG - 2011-08-15 12:32:33 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-15 12:32:33 --> Database Driver Class Initialized
DEBUG - 2011-08-15 12:32:34 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-15 12:32:34 --> Helper loaded: url_helper
DEBUG - 2011-08-15 12:32:34 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-15 12:32:34 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-15 12:32:34 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-15 12:32:34 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-15 12:32:34 --> Final output sent to browser
DEBUG - 2011-08-15 12:32:34 --> Total execution time: 0.2121
DEBUG - 2011-08-15 12:32:38 --> Config Class Initialized
DEBUG - 2011-08-15 12:32:38 --> Hooks Class Initialized
DEBUG - 2011-08-15 12:32:38 --> Utf8 Class Initialized
DEBUG - 2011-08-15 12:32:38 --> UTF-8 Support Enabled
DEBUG - 2011-08-15 12:32:38 --> URI Class Initialized
DEBUG - 2011-08-15 12:32:38 --> Router Class Initialized
DEBUG - 2011-08-15 12:32:38 --> Output Class Initialized
DEBUG - 2011-08-15 12:32:38 --> Input Class Initialized
DEBUG - 2011-08-15 12:32:38 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-15 12:32:38 --> Language Class Initialized
DEBUG - 2011-08-15 12:32:38 --> Loader Class Initialized
DEBUG - 2011-08-15 12:32:38 --> Controller Class Initialized
DEBUG - 2011-08-15 12:32:38 --> Model Class Initialized
DEBUG - 2011-08-15 12:32:38 --> Model Class Initialized
DEBUG - 2011-08-15 12:32:38 --> Model Class Initialized
DEBUG - 2011-08-15 12:32:38 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-15 12:32:38 --> Database Driver Class Initialized
DEBUG - 2011-08-15 12:32:38 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-15 12:32:38 --> Helper loaded: url_helper
DEBUG - 2011-08-15 12:32:38 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-15 12:32:38 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-15 12:32:38 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-15 12:32:38 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-15 12:32:38 --> Final output sent to browser
DEBUG - 2011-08-15 12:32:38 --> Total execution time: 0.1051
DEBUG - 2011-08-15 12:32:57 --> Config Class Initialized
DEBUG - 2011-08-15 12:32:57 --> Hooks Class Initialized
DEBUG - 2011-08-15 12:32:57 --> Utf8 Class Initialized
DEBUG - 2011-08-15 12:32:57 --> UTF-8 Support Enabled
DEBUG - 2011-08-15 12:32:57 --> URI Class Initialized
DEBUG - 2011-08-15 12:32:57 --> Router Class Initialized
DEBUG - 2011-08-15 12:32:57 --> Output Class Initialized
DEBUG - 2011-08-15 12:32:57 --> Input Class Initialized
DEBUG - 2011-08-15 12:32:57 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-15 12:32:57 --> Language Class Initialized
DEBUG - 2011-08-15 12:32:57 --> Loader Class Initialized
DEBUG - 2011-08-15 12:32:57 --> Controller Class Initialized
ERROR - 2011-08-15 12:32:57 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-15 12:32:57 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-15 12:32:57 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-15 12:32:57 --> Model Class Initialized
DEBUG - 2011-08-15 12:32:57 --> Model Class Initialized
DEBUG - 2011-08-15 12:32:57 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-15 12:32:57 --> Database Driver Class Initialized
DEBUG - 2011-08-15 12:32:57 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-15 12:32:57 --> Helper loaded: url_helper
DEBUG - 2011-08-15 12:32:57 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-15 12:32:57 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-15 12:32:57 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-15 12:32:57 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-15 12:32:57 --> Final output sent to browser
DEBUG - 2011-08-15 12:32:57 --> Total execution time: 0.0523
DEBUG - 2011-08-15 12:32:58 --> Config Class Initialized
DEBUG - 2011-08-15 12:32:58 --> Hooks Class Initialized
DEBUG - 2011-08-15 12:32:58 --> Utf8 Class Initialized
DEBUG - 2011-08-15 12:32:58 --> UTF-8 Support Enabled
DEBUG - 2011-08-15 12:32:58 --> URI Class Initialized
DEBUG - 2011-08-15 12:32:58 --> Router Class Initialized
DEBUG - 2011-08-15 12:32:58 --> Output Class Initialized
DEBUG - 2011-08-15 12:32:58 --> Input Class Initialized
DEBUG - 2011-08-15 12:32:58 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-15 12:32:58 --> Language Class Initialized
DEBUG - 2011-08-15 12:32:58 --> Loader Class Initialized
DEBUG - 2011-08-15 12:32:58 --> Controller Class Initialized
DEBUG - 2011-08-15 12:32:58 --> Model Class Initialized
DEBUG - 2011-08-15 12:32:58 --> Model Class Initialized
DEBUG - 2011-08-15 12:32:58 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-15 12:32:58 --> Database Driver Class Initialized
DEBUG - 2011-08-15 12:32:59 --> Final output sent to browser
DEBUG - 2011-08-15 12:32:59 --> Total execution time: 0.9525
DEBUG - 2011-08-15 12:33:23 --> Config Class Initialized
DEBUG - 2011-08-15 12:33:23 --> Hooks Class Initialized
DEBUG - 2011-08-15 12:33:23 --> Utf8 Class Initialized
DEBUG - 2011-08-15 12:33:23 --> UTF-8 Support Enabled
DEBUG - 2011-08-15 12:33:23 --> URI Class Initialized
DEBUG - 2011-08-15 12:33:23 --> Router Class Initialized
DEBUG - 2011-08-15 12:33:23 --> Output Class Initialized
DEBUG - 2011-08-15 12:33:23 --> Input Class Initialized
DEBUG - 2011-08-15 12:33:23 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-15 12:33:23 --> Language Class Initialized
DEBUG - 2011-08-15 12:33:23 --> Loader Class Initialized
DEBUG - 2011-08-15 12:33:23 --> Controller Class Initialized
DEBUG - 2011-08-15 12:33:23 --> Model Class Initialized
DEBUG - 2011-08-15 12:33:23 --> Model Class Initialized
DEBUG - 2011-08-15 12:33:23 --> Model Class Initialized
DEBUG - 2011-08-15 12:33:23 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-15 12:33:23 --> Database Driver Class Initialized
DEBUG - 2011-08-15 12:33:23 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-15 12:33:23 --> Helper loaded: url_helper
DEBUG - 2011-08-15 12:33:23 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-15 12:33:23 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-15 12:33:23 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-15 12:33:23 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-15 12:33:23 --> Final output sent to browser
DEBUG - 2011-08-15 12:33:23 --> Total execution time: 0.3894
DEBUG - 2011-08-15 12:33:47 --> Config Class Initialized
DEBUG - 2011-08-15 12:33:47 --> Hooks Class Initialized
DEBUG - 2011-08-15 12:33:47 --> Utf8 Class Initialized
DEBUG - 2011-08-15 12:33:47 --> UTF-8 Support Enabled
DEBUG - 2011-08-15 12:33:47 --> URI Class Initialized
DEBUG - 2011-08-15 12:33:47 --> Router Class Initialized
DEBUG - 2011-08-15 12:33:47 --> Output Class Initialized
DEBUG - 2011-08-15 12:33:47 --> Input Class Initialized
DEBUG - 2011-08-15 12:33:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-15 12:33:47 --> Language Class Initialized
DEBUG - 2011-08-15 12:33:47 --> Loader Class Initialized
DEBUG - 2011-08-15 12:33:47 --> Controller Class Initialized
DEBUG - 2011-08-15 12:33:47 --> Model Class Initialized
DEBUG - 2011-08-15 12:33:47 --> Model Class Initialized
DEBUG - 2011-08-15 12:33:47 --> Model Class Initialized
DEBUG - 2011-08-15 12:33:47 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-15 12:33:47 --> Database Driver Class Initialized
DEBUG - 2011-08-15 12:33:47 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-15 12:33:47 --> Helper loaded: url_helper
DEBUG - 2011-08-15 12:33:47 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-15 12:33:47 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-15 12:33:47 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-15 12:33:47 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-15 12:33:47 --> Final output sent to browser
DEBUG - 2011-08-15 12:33:47 --> Total execution time: 0.4003
DEBUG - 2011-08-15 12:33:50 --> Config Class Initialized
DEBUG - 2011-08-15 12:33:50 --> Hooks Class Initialized
DEBUG - 2011-08-15 12:33:50 --> Utf8 Class Initialized
DEBUG - 2011-08-15 12:33:50 --> UTF-8 Support Enabled
DEBUG - 2011-08-15 12:33:50 --> URI Class Initialized
DEBUG - 2011-08-15 12:33:50 --> Router Class Initialized
DEBUG - 2011-08-15 12:33:50 --> Output Class Initialized
DEBUG - 2011-08-15 12:33:50 --> Input Class Initialized
DEBUG - 2011-08-15 12:33:50 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-15 12:33:50 --> Language Class Initialized
DEBUG - 2011-08-15 12:33:50 --> Loader Class Initialized
DEBUG - 2011-08-15 12:33:50 --> Controller Class Initialized
DEBUG - 2011-08-15 12:33:50 --> Model Class Initialized
DEBUG - 2011-08-15 12:33:50 --> Model Class Initialized
DEBUG - 2011-08-15 12:33:50 --> Model Class Initialized
DEBUG - 2011-08-15 12:33:50 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-15 12:33:50 --> Database Driver Class Initialized
DEBUG - 2011-08-15 12:33:50 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-15 12:33:50 --> Helper loaded: url_helper
DEBUG - 2011-08-15 12:33:50 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-15 12:33:50 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-15 12:33:50 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-15 12:33:50 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-15 12:33:50 --> Final output sent to browser
DEBUG - 2011-08-15 12:33:50 --> Total execution time: 0.1025
DEBUG - 2011-08-15 12:33:55 --> Config Class Initialized
DEBUG - 2011-08-15 12:33:55 --> Hooks Class Initialized
DEBUG - 2011-08-15 12:33:55 --> Utf8 Class Initialized
DEBUG - 2011-08-15 12:33:55 --> UTF-8 Support Enabled
DEBUG - 2011-08-15 12:33:55 --> URI Class Initialized
DEBUG - 2011-08-15 12:33:55 --> Router Class Initialized
DEBUG - 2011-08-15 12:33:55 --> Output Class Initialized
DEBUG - 2011-08-15 12:33:55 --> Input Class Initialized
DEBUG - 2011-08-15 12:33:55 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-15 12:33:55 --> Language Class Initialized
DEBUG - 2011-08-15 12:33:55 --> Loader Class Initialized
DEBUG - 2011-08-15 12:33:55 --> Controller Class Initialized
ERROR - 2011-08-15 12:33:55 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-15 12:33:55 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-15 12:33:55 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-15 12:33:55 --> Model Class Initialized
DEBUG - 2011-08-15 12:33:55 --> Model Class Initialized
DEBUG - 2011-08-15 12:33:55 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-15 12:33:55 --> Database Driver Class Initialized
DEBUG - 2011-08-15 12:33:55 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-15 12:33:55 --> Helper loaded: url_helper
DEBUG - 2011-08-15 12:33:55 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-15 12:33:55 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-15 12:33:55 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-15 12:33:55 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-15 12:33:55 --> Final output sent to browser
DEBUG - 2011-08-15 12:33:55 --> Total execution time: 0.0333
DEBUG - 2011-08-15 12:33:56 --> Config Class Initialized
DEBUG - 2011-08-15 12:33:56 --> Hooks Class Initialized
DEBUG - 2011-08-15 12:33:56 --> Utf8 Class Initialized
DEBUG - 2011-08-15 12:33:56 --> UTF-8 Support Enabled
DEBUG - 2011-08-15 12:33:56 --> URI Class Initialized
DEBUG - 2011-08-15 12:33:56 --> Router Class Initialized
DEBUG - 2011-08-15 12:33:56 --> Output Class Initialized
DEBUG - 2011-08-15 12:33:56 --> Input Class Initialized
DEBUG - 2011-08-15 12:33:56 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-15 12:33:56 --> Language Class Initialized
DEBUG - 2011-08-15 12:33:56 --> Loader Class Initialized
DEBUG - 2011-08-15 12:33:56 --> Controller Class Initialized
DEBUG - 2011-08-15 12:33:56 --> Model Class Initialized
DEBUG - 2011-08-15 12:33:56 --> Model Class Initialized
DEBUG - 2011-08-15 12:33:56 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-15 12:33:56 --> Database Driver Class Initialized
DEBUG - 2011-08-15 12:33:56 --> Final output sent to browser
DEBUG - 2011-08-15 12:33:56 --> Total execution time: 0.5085
DEBUG - 2011-08-15 12:38:03 --> Config Class Initialized
DEBUG - 2011-08-15 12:38:03 --> Hooks Class Initialized
DEBUG - 2011-08-15 12:38:03 --> Utf8 Class Initialized
DEBUG - 2011-08-15 12:38:03 --> UTF-8 Support Enabled
DEBUG - 2011-08-15 12:38:03 --> URI Class Initialized
DEBUG - 2011-08-15 12:38:03 --> Router Class Initialized
DEBUG - 2011-08-15 12:38:03 --> Output Class Initialized
DEBUG - 2011-08-15 12:38:03 --> Input Class Initialized
DEBUG - 2011-08-15 12:38:03 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-15 12:38:03 --> Language Class Initialized
DEBUG - 2011-08-15 12:38:03 --> Loader Class Initialized
DEBUG - 2011-08-15 12:38:03 --> Controller Class Initialized
DEBUG - 2011-08-15 12:38:03 --> Model Class Initialized
DEBUG - 2011-08-15 12:38:03 --> Model Class Initialized
DEBUG - 2011-08-15 12:38:03 --> Model Class Initialized
DEBUG - 2011-08-15 12:38:03 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-15 12:38:03 --> Database Driver Class Initialized
DEBUG - 2011-08-15 12:38:04 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-15 12:38:04 --> Helper loaded: url_helper
DEBUG - 2011-08-15 12:38:04 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-15 12:38:04 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-15 12:38:04 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-15 12:38:04 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-15 12:38:04 --> Final output sent to browser
DEBUG - 2011-08-15 12:38:04 --> Total execution time: 0.1871
DEBUG - 2011-08-15 12:38:06 --> Config Class Initialized
DEBUG - 2011-08-15 12:38:06 --> Hooks Class Initialized
DEBUG - 2011-08-15 12:38:06 --> Utf8 Class Initialized
DEBUG - 2011-08-15 12:38:06 --> UTF-8 Support Enabled
DEBUG - 2011-08-15 12:38:06 --> URI Class Initialized
DEBUG - 2011-08-15 12:38:06 --> Router Class Initialized
ERROR - 2011-08-15 12:38:06 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-15 12:38:16 --> Config Class Initialized
DEBUG - 2011-08-15 12:38:16 --> Hooks Class Initialized
DEBUG - 2011-08-15 12:38:16 --> Utf8 Class Initialized
DEBUG - 2011-08-15 12:38:16 --> UTF-8 Support Enabled
DEBUG - 2011-08-15 12:38:16 --> URI Class Initialized
DEBUG - 2011-08-15 12:38:16 --> Router Class Initialized
DEBUG - 2011-08-15 12:38:16 --> Output Class Initialized
DEBUG - 2011-08-15 12:38:16 --> Input Class Initialized
DEBUG - 2011-08-15 12:38:16 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-15 12:38:16 --> Language Class Initialized
DEBUG - 2011-08-15 12:38:16 --> Loader Class Initialized
DEBUG - 2011-08-15 12:38:16 --> Controller Class Initialized
DEBUG - 2011-08-15 12:38:16 --> Model Class Initialized
DEBUG - 2011-08-15 12:38:16 --> Model Class Initialized
DEBUG - 2011-08-15 12:38:16 --> Model Class Initialized
DEBUG - 2011-08-15 12:38:16 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-15 12:38:16 --> Database Driver Class Initialized
DEBUG - 2011-08-15 12:38:16 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-15 12:38:16 --> Helper loaded: url_helper
DEBUG - 2011-08-15 12:38:16 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-15 12:38:16 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-15 12:38:16 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-15 12:38:16 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-15 12:38:16 --> Final output sent to browser
DEBUG - 2011-08-15 12:38:16 --> Total execution time: 0.2883
DEBUG - 2011-08-15 12:38:17 --> Config Class Initialized
DEBUG - 2011-08-15 12:38:17 --> Hooks Class Initialized
DEBUG - 2011-08-15 12:38:17 --> Utf8 Class Initialized
DEBUG - 2011-08-15 12:38:17 --> UTF-8 Support Enabled
DEBUG - 2011-08-15 12:38:17 --> URI Class Initialized
DEBUG - 2011-08-15 12:38:17 --> Router Class Initialized
DEBUG - 2011-08-15 12:38:17 --> Output Class Initialized
DEBUG - 2011-08-15 12:38:17 --> Input Class Initialized
DEBUG - 2011-08-15 12:38:17 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-15 12:38:17 --> Language Class Initialized
DEBUG - 2011-08-15 12:38:17 --> Loader Class Initialized
DEBUG - 2011-08-15 12:38:17 --> Controller Class Initialized
DEBUG - 2011-08-15 12:38:17 --> Model Class Initialized
DEBUG - 2011-08-15 12:38:17 --> Model Class Initialized
DEBUG - 2011-08-15 12:38:17 --> Model Class Initialized
DEBUG - 2011-08-15 12:38:17 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-15 12:38:17 --> Database Driver Class Initialized
DEBUG - 2011-08-15 12:38:18 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-15 12:38:18 --> Helper loaded: url_helper
DEBUG - 2011-08-15 12:38:18 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-15 12:38:18 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-15 12:38:18 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-15 12:38:18 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-15 12:38:18 --> Final output sent to browser
DEBUG - 2011-08-15 12:38:18 --> Total execution time: 0.0389
DEBUG - 2011-08-15 12:38:18 --> Config Class Initialized
DEBUG - 2011-08-15 12:38:18 --> Hooks Class Initialized
DEBUG - 2011-08-15 12:38:18 --> Utf8 Class Initialized
DEBUG - 2011-08-15 12:38:18 --> UTF-8 Support Enabled
DEBUG - 2011-08-15 12:38:18 --> URI Class Initialized
DEBUG - 2011-08-15 12:38:18 --> Router Class Initialized
ERROR - 2011-08-15 12:38:18 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-15 12:38:23 --> Config Class Initialized
DEBUG - 2011-08-15 12:38:23 --> Hooks Class Initialized
DEBUG - 2011-08-15 12:38:23 --> Utf8 Class Initialized
DEBUG - 2011-08-15 12:38:23 --> UTF-8 Support Enabled
DEBUG - 2011-08-15 12:38:23 --> URI Class Initialized
DEBUG - 2011-08-15 12:38:23 --> Router Class Initialized
DEBUG - 2011-08-15 12:38:23 --> Output Class Initialized
DEBUG - 2011-08-15 12:38:23 --> Input Class Initialized
DEBUG - 2011-08-15 12:38:23 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-15 12:38:23 --> Language Class Initialized
DEBUG - 2011-08-15 12:38:23 --> Loader Class Initialized
DEBUG - 2011-08-15 12:38:23 --> Controller Class Initialized
DEBUG - 2011-08-15 12:38:23 --> Model Class Initialized
DEBUG - 2011-08-15 12:38:23 --> Model Class Initialized
DEBUG - 2011-08-15 12:38:23 --> Model Class Initialized
DEBUG - 2011-08-15 12:38:23 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-15 12:38:23 --> Database Driver Class Initialized
DEBUG - 2011-08-15 12:38:23 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-15 12:38:23 --> Helper loaded: url_helper
DEBUG - 2011-08-15 12:38:23 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-15 12:38:23 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-15 12:38:23 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-15 12:38:23 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-15 12:38:23 --> Final output sent to browser
DEBUG - 2011-08-15 12:38:23 --> Total execution time: 0.3437
DEBUG - 2011-08-15 12:38:24 --> Config Class Initialized
DEBUG - 2011-08-15 12:38:24 --> Hooks Class Initialized
DEBUG - 2011-08-15 12:38:24 --> Utf8 Class Initialized
DEBUG - 2011-08-15 12:38:24 --> UTF-8 Support Enabled
DEBUG - 2011-08-15 12:38:24 --> URI Class Initialized
DEBUG - 2011-08-15 12:38:24 --> Router Class Initialized
DEBUG - 2011-08-15 12:38:24 --> Output Class Initialized
DEBUG - 2011-08-15 12:38:24 --> Input Class Initialized
DEBUG - 2011-08-15 12:38:24 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-15 12:38:24 --> Language Class Initialized
DEBUG - 2011-08-15 12:38:24 --> Loader Class Initialized
DEBUG - 2011-08-15 12:38:24 --> Controller Class Initialized
DEBUG - 2011-08-15 12:38:24 --> Model Class Initialized
DEBUG - 2011-08-15 12:38:24 --> Model Class Initialized
DEBUG - 2011-08-15 12:38:24 --> Model Class Initialized
DEBUG - 2011-08-15 12:38:24 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-15 12:38:24 --> Database Driver Class Initialized
DEBUG - 2011-08-15 12:38:24 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-15 12:38:24 --> Helper loaded: url_helper
DEBUG - 2011-08-15 12:38:24 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-15 12:38:24 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-15 12:38:24 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-15 12:38:24 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-15 12:38:24 --> Final output sent to browser
DEBUG - 2011-08-15 12:38:24 --> Total execution time: 0.0399
DEBUG - 2011-08-15 12:38:25 --> Config Class Initialized
DEBUG - 2011-08-15 12:38:25 --> Hooks Class Initialized
DEBUG - 2011-08-15 12:38:25 --> Utf8 Class Initialized
DEBUG - 2011-08-15 12:38:25 --> UTF-8 Support Enabled
DEBUG - 2011-08-15 12:38:25 --> URI Class Initialized
DEBUG - 2011-08-15 12:38:25 --> Router Class Initialized
ERROR - 2011-08-15 12:38:25 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-15 12:38:39 --> Config Class Initialized
DEBUG - 2011-08-15 12:38:39 --> Hooks Class Initialized
DEBUG - 2011-08-15 12:38:39 --> Utf8 Class Initialized
DEBUG - 2011-08-15 12:38:39 --> UTF-8 Support Enabled
DEBUG - 2011-08-15 12:38:39 --> URI Class Initialized
DEBUG - 2011-08-15 12:38:39 --> Router Class Initialized
DEBUG - 2011-08-15 12:38:39 --> Output Class Initialized
DEBUG - 2011-08-15 12:38:39 --> Input Class Initialized
DEBUG - 2011-08-15 12:38:39 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-15 12:38:39 --> Language Class Initialized
DEBUG - 2011-08-15 12:38:39 --> Loader Class Initialized
DEBUG - 2011-08-15 12:38:39 --> Controller Class Initialized
DEBUG - 2011-08-15 12:38:39 --> Model Class Initialized
DEBUG - 2011-08-15 12:38:39 --> Model Class Initialized
DEBUG - 2011-08-15 12:38:39 --> Model Class Initialized
DEBUG - 2011-08-15 12:38:39 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-15 12:38:39 --> Database Driver Class Initialized
DEBUG - 2011-08-15 12:38:39 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-15 12:38:39 --> Helper loaded: url_helper
DEBUG - 2011-08-15 12:38:39 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-15 12:38:39 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-15 12:38:39 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-15 12:38:39 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-15 12:38:39 --> Final output sent to browser
DEBUG - 2011-08-15 12:38:39 --> Total execution time: 0.0489
DEBUG - 2011-08-15 12:38:40 --> Config Class Initialized
DEBUG - 2011-08-15 12:38:40 --> Hooks Class Initialized
DEBUG - 2011-08-15 12:38:40 --> Utf8 Class Initialized
DEBUG - 2011-08-15 12:38:40 --> UTF-8 Support Enabled
DEBUG - 2011-08-15 12:38:40 --> URI Class Initialized
DEBUG - 2011-08-15 12:38:40 --> Router Class Initialized
ERROR - 2011-08-15 12:38:40 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-15 12:38:58 --> Config Class Initialized
DEBUG - 2011-08-15 12:38:58 --> Hooks Class Initialized
DEBUG - 2011-08-15 12:38:58 --> Utf8 Class Initialized
DEBUG - 2011-08-15 12:38:58 --> UTF-8 Support Enabled
DEBUG - 2011-08-15 12:38:58 --> URI Class Initialized
DEBUG - 2011-08-15 12:38:58 --> Router Class Initialized
DEBUG - 2011-08-15 12:38:58 --> Output Class Initialized
DEBUG - 2011-08-15 12:38:58 --> Input Class Initialized
DEBUG - 2011-08-15 12:38:58 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-15 12:38:58 --> Language Class Initialized
DEBUG - 2011-08-15 12:38:58 --> Loader Class Initialized
DEBUG - 2011-08-15 12:38:58 --> Controller Class Initialized
DEBUG - 2011-08-15 12:38:58 --> Model Class Initialized
DEBUG - 2011-08-15 12:38:58 --> Model Class Initialized
DEBUG - 2011-08-15 12:38:58 --> Model Class Initialized
DEBUG - 2011-08-15 12:38:58 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-15 12:38:58 --> Database Driver Class Initialized
DEBUG - 2011-08-15 12:38:58 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-15 12:38:58 --> Helper loaded: url_helper
DEBUG - 2011-08-15 12:38:58 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-15 12:38:58 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-15 12:38:58 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-15 12:38:58 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-15 12:38:58 --> Final output sent to browser
DEBUG - 2011-08-15 12:38:58 --> Total execution time: 0.0461
DEBUG - 2011-08-15 12:39:00 --> Config Class Initialized
DEBUG - 2011-08-15 12:39:00 --> Hooks Class Initialized
DEBUG - 2011-08-15 12:39:00 --> Utf8 Class Initialized
DEBUG - 2011-08-15 12:39:00 --> UTF-8 Support Enabled
DEBUG - 2011-08-15 12:39:00 --> URI Class Initialized
DEBUG - 2011-08-15 12:39:00 --> Router Class Initialized
ERROR - 2011-08-15 12:39:00 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-15 12:39:15 --> Config Class Initialized
DEBUG - 2011-08-15 12:39:15 --> Hooks Class Initialized
DEBUG - 2011-08-15 12:39:15 --> Utf8 Class Initialized
DEBUG - 2011-08-15 12:39:15 --> UTF-8 Support Enabled
DEBUG - 2011-08-15 12:39:15 --> URI Class Initialized
DEBUG - 2011-08-15 12:39:15 --> Router Class Initialized
DEBUG - 2011-08-15 12:39:15 --> Output Class Initialized
DEBUG - 2011-08-15 12:39:15 --> Input Class Initialized
DEBUG - 2011-08-15 12:39:15 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-15 12:39:15 --> Language Class Initialized
DEBUG - 2011-08-15 12:39:15 --> Loader Class Initialized
DEBUG - 2011-08-15 12:39:15 --> Controller Class Initialized
DEBUG - 2011-08-15 12:39:15 --> Model Class Initialized
DEBUG - 2011-08-15 12:39:15 --> Model Class Initialized
DEBUG - 2011-08-15 12:39:15 --> Model Class Initialized
DEBUG - 2011-08-15 12:39:15 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-15 12:39:15 --> Database Driver Class Initialized
DEBUG - 2011-08-15 12:39:16 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-15 12:39:16 --> Helper loaded: url_helper
DEBUG - 2011-08-15 12:39:16 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-15 12:39:16 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-15 12:39:16 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-15 12:39:16 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-15 12:39:16 --> Final output sent to browser
DEBUG - 2011-08-15 12:39:16 --> Total execution time: 0.3773
DEBUG - 2011-08-15 12:39:17 --> Config Class Initialized
DEBUG - 2011-08-15 12:39:17 --> Hooks Class Initialized
DEBUG - 2011-08-15 12:39:17 --> Utf8 Class Initialized
DEBUG - 2011-08-15 12:39:17 --> UTF-8 Support Enabled
DEBUG - 2011-08-15 12:39:17 --> URI Class Initialized
DEBUG - 2011-08-15 12:39:17 --> Router Class Initialized
DEBUG - 2011-08-15 12:39:17 --> Output Class Initialized
DEBUG - 2011-08-15 12:39:17 --> Input Class Initialized
DEBUG - 2011-08-15 12:39:17 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-15 12:39:17 --> Language Class Initialized
DEBUG - 2011-08-15 12:39:17 --> Loader Class Initialized
DEBUG - 2011-08-15 12:39:17 --> Controller Class Initialized
DEBUG - 2011-08-15 12:39:17 --> Model Class Initialized
DEBUG - 2011-08-15 12:39:17 --> Model Class Initialized
DEBUG - 2011-08-15 12:39:17 --> Model Class Initialized
DEBUG - 2011-08-15 12:39:17 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-15 12:39:17 --> Database Driver Class Initialized
DEBUG - 2011-08-15 12:39:17 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-15 12:39:17 --> Helper loaded: url_helper
DEBUG - 2011-08-15 12:39:17 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-15 12:39:17 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-15 12:39:17 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-15 12:39:17 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-15 12:39:17 --> Final output sent to browser
DEBUG - 2011-08-15 12:39:17 --> Total execution time: 0.0580
DEBUG - 2011-08-15 12:39:17 --> Config Class Initialized
DEBUG - 2011-08-15 12:39:17 --> Hooks Class Initialized
DEBUG - 2011-08-15 12:39:17 --> Utf8 Class Initialized
DEBUG - 2011-08-15 12:39:17 --> UTF-8 Support Enabled
DEBUG - 2011-08-15 12:39:17 --> URI Class Initialized
DEBUG - 2011-08-15 12:39:17 --> Router Class Initialized
ERROR - 2011-08-15 12:39:17 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-15 12:39:27 --> Config Class Initialized
DEBUG - 2011-08-15 12:39:27 --> Hooks Class Initialized
DEBUG - 2011-08-15 12:39:27 --> Utf8 Class Initialized
DEBUG - 2011-08-15 12:39:27 --> UTF-8 Support Enabled
DEBUG - 2011-08-15 12:39:27 --> URI Class Initialized
DEBUG - 2011-08-15 12:39:27 --> Router Class Initialized
DEBUG - 2011-08-15 12:39:27 --> Output Class Initialized
DEBUG - 2011-08-15 12:39:27 --> Input Class Initialized
DEBUG - 2011-08-15 12:39:27 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-15 12:39:27 --> Language Class Initialized
DEBUG - 2011-08-15 12:39:27 --> Loader Class Initialized
DEBUG - 2011-08-15 12:39:27 --> Controller Class Initialized
DEBUG - 2011-08-15 12:39:27 --> Model Class Initialized
DEBUG - 2011-08-15 12:39:27 --> Model Class Initialized
DEBUG - 2011-08-15 12:39:27 --> Model Class Initialized
DEBUG - 2011-08-15 12:39:27 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-15 12:39:27 --> Database Driver Class Initialized
DEBUG - 2011-08-15 12:39:27 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-15 12:39:27 --> Helper loaded: url_helper
DEBUG - 2011-08-15 12:39:27 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-15 12:39:27 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-15 12:39:27 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-15 12:39:27 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-15 12:39:27 --> Final output sent to browser
DEBUG - 2011-08-15 12:39:27 --> Total execution time: 0.2325
DEBUG - 2011-08-15 12:39:29 --> Config Class Initialized
DEBUG - 2011-08-15 12:39:29 --> Hooks Class Initialized
DEBUG - 2011-08-15 12:39:29 --> Utf8 Class Initialized
DEBUG - 2011-08-15 12:39:29 --> UTF-8 Support Enabled
DEBUG - 2011-08-15 12:39:29 --> URI Class Initialized
DEBUG - 2011-08-15 12:39:29 --> Router Class Initialized
ERROR - 2011-08-15 12:39:29 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-15 12:39:29 --> Config Class Initialized
DEBUG - 2011-08-15 12:39:29 --> Hooks Class Initialized
DEBUG - 2011-08-15 12:39:29 --> Utf8 Class Initialized
DEBUG - 2011-08-15 12:39:29 --> UTF-8 Support Enabled
DEBUG - 2011-08-15 12:39:29 --> URI Class Initialized
DEBUG - 2011-08-15 12:39:29 --> Router Class Initialized
DEBUG - 2011-08-15 12:39:29 --> Output Class Initialized
DEBUG - 2011-08-15 12:39:29 --> Input Class Initialized
DEBUG - 2011-08-15 12:39:29 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-15 12:39:29 --> Language Class Initialized
DEBUG - 2011-08-15 12:39:29 --> Loader Class Initialized
DEBUG - 2011-08-15 12:39:29 --> Controller Class Initialized
DEBUG - 2011-08-15 12:39:29 --> Model Class Initialized
DEBUG - 2011-08-15 12:39:29 --> Model Class Initialized
DEBUG - 2011-08-15 12:39:29 --> Model Class Initialized
DEBUG - 2011-08-15 12:39:29 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-15 12:39:29 --> Database Driver Class Initialized
DEBUG - 2011-08-15 12:39:29 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-15 12:39:29 --> Helper loaded: url_helper
DEBUG - 2011-08-15 12:39:29 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-15 12:39:29 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-15 12:39:29 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-15 12:39:29 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-15 12:39:29 --> Final output sent to browser
DEBUG - 2011-08-15 12:39:29 --> Total execution time: 0.0659
DEBUG - 2011-08-15 12:39:38 --> Config Class Initialized
DEBUG - 2011-08-15 12:39:38 --> Hooks Class Initialized
DEBUG - 2011-08-15 12:39:38 --> Utf8 Class Initialized
DEBUG - 2011-08-15 12:39:38 --> UTF-8 Support Enabled
DEBUG - 2011-08-15 12:39:38 --> URI Class Initialized
DEBUG - 2011-08-15 12:39:38 --> Router Class Initialized
DEBUG - 2011-08-15 12:39:38 --> Output Class Initialized
DEBUG - 2011-08-15 12:39:38 --> Input Class Initialized
DEBUG - 2011-08-15 12:39:38 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-15 12:39:38 --> Language Class Initialized
DEBUG - 2011-08-15 12:39:38 --> Loader Class Initialized
DEBUG - 2011-08-15 12:39:38 --> Controller Class Initialized
DEBUG - 2011-08-15 12:39:38 --> Model Class Initialized
DEBUG - 2011-08-15 12:39:38 --> Model Class Initialized
DEBUG - 2011-08-15 12:39:38 --> Model Class Initialized
DEBUG - 2011-08-15 12:39:38 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-15 12:39:38 --> Database Driver Class Initialized
DEBUG - 2011-08-15 12:39:38 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-15 12:39:38 --> Helper loaded: url_helper
DEBUG - 2011-08-15 12:39:38 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-15 12:39:38 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-15 12:39:38 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-15 12:39:38 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-15 12:39:38 --> Final output sent to browser
DEBUG - 2011-08-15 12:39:38 --> Total execution time: 0.0468
DEBUG - 2011-08-15 12:39:39 --> Config Class Initialized
DEBUG - 2011-08-15 12:39:39 --> Hooks Class Initialized
DEBUG - 2011-08-15 12:39:39 --> Utf8 Class Initialized
DEBUG - 2011-08-15 12:39:39 --> UTF-8 Support Enabled
DEBUG - 2011-08-15 12:39:39 --> URI Class Initialized
DEBUG - 2011-08-15 12:39:39 --> Router Class Initialized
ERROR - 2011-08-15 12:39:39 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-15 12:39:47 --> Config Class Initialized
DEBUG - 2011-08-15 12:39:47 --> Hooks Class Initialized
DEBUG - 2011-08-15 12:39:47 --> Utf8 Class Initialized
DEBUG - 2011-08-15 12:39:47 --> UTF-8 Support Enabled
DEBUG - 2011-08-15 12:39:47 --> URI Class Initialized
DEBUG - 2011-08-15 12:39:47 --> Router Class Initialized
DEBUG - 2011-08-15 12:39:47 --> Output Class Initialized
DEBUG - 2011-08-15 12:39:47 --> Input Class Initialized
DEBUG - 2011-08-15 12:39:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-15 12:39:47 --> Language Class Initialized
DEBUG - 2011-08-15 12:39:47 --> Loader Class Initialized
DEBUG - 2011-08-15 12:39:47 --> Controller Class Initialized
ERROR - 2011-08-15 12:39:47 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-15 12:39:47 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-15 12:39:47 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-15 12:39:47 --> Model Class Initialized
DEBUG - 2011-08-15 12:39:47 --> Model Class Initialized
DEBUG - 2011-08-15 12:39:47 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-15 12:39:47 --> Database Driver Class Initialized
DEBUG - 2011-08-15 12:39:47 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-15 12:39:47 --> Helper loaded: url_helper
DEBUG - 2011-08-15 12:39:47 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-15 12:39:47 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-15 12:39:47 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-15 12:39:47 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-15 12:39:47 --> Final output sent to browser
DEBUG - 2011-08-15 12:39:47 --> Total execution time: 0.0285
DEBUG - 2011-08-15 12:39:48 --> Config Class Initialized
DEBUG - 2011-08-15 12:39:48 --> Hooks Class Initialized
DEBUG - 2011-08-15 12:39:48 --> Utf8 Class Initialized
DEBUG - 2011-08-15 12:39:48 --> UTF-8 Support Enabled
DEBUG - 2011-08-15 12:39:48 --> URI Class Initialized
DEBUG - 2011-08-15 12:39:48 --> Router Class Initialized
DEBUG - 2011-08-15 12:39:48 --> Output Class Initialized
DEBUG - 2011-08-15 12:39:48 --> Input Class Initialized
DEBUG - 2011-08-15 12:39:48 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-15 12:39:48 --> Language Class Initialized
DEBUG - 2011-08-15 12:39:48 --> Loader Class Initialized
DEBUG - 2011-08-15 12:39:48 --> Controller Class Initialized
DEBUG - 2011-08-15 12:39:48 --> Model Class Initialized
DEBUG - 2011-08-15 12:39:48 --> Model Class Initialized
DEBUG - 2011-08-15 12:39:48 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-15 12:39:48 --> Database Driver Class Initialized
DEBUG - 2011-08-15 12:39:49 --> Final output sent to browser
DEBUG - 2011-08-15 12:39:49 --> Total execution time: 0.4967
DEBUG - 2011-08-15 12:39:50 --> Config Class Initialized
DEBUG - 2011-08-15 12:39:50 --> Hooks Class Initialized
DEBUG - 2011-08-15 12:39:50 --> Utf8 Class Initialized
DEBUG - 2011-08-15 12:39:50 --> UTF-8 Support Enabled
DEBUG - 2011-08-15 12:39:50 --> URI Class Initialized
DEBUG - 2011-08-15 12:39:50 --> Router Class Initialized
ERROR - 2011-08-15 12:39:50 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-15 12:39:51 --> Config Class Initialized
DEBUG - 2011-08-15 12:39:51 --> Hooks Class Initialized
DEBUG - 2011-08-15 12:39:51 --> Utf8 Class Initialized
DEBUG - 2011-08-15 12:39:51 --> UTF-8 Support Enabled
DEBUG - 2011-08-15 12:39:51 --> URI Class Initialized
DEBUG - 2011-08-15 12:39:51 --> Router Class Initialized
ERROR - 2011-08-15 12:39:51 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-15 12:39:57 --> Config Class Initialized
DEBUG - 2011-08-15 12:39:57 --> Hooks Class Initialized
DEBUG - 2011-08-15 12:39:57 --> Utf8 Class Initialized
DEBUG - 2011-08-15 12:39:57 --> UTF-8 Support Enabled
DEBUG - 2011-08-15 12:39:57 --> URI Class Initialized
DEBUG - 2011-08-15 12:39:57 --> Router Class Initialized
DEBUG - 2011-08-15 12:39:57 --> Output Class Initialized
DEBUG - 2011-08-15 12:39:57 --> Input Class Initialized
DEBUG - 2011-08-15 12:39:57 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-15 12:39:57 --> Language Class Initialized
DEBUG - 2011-08-15 12:39:57 --> Loader Class Initialized
DEBUG - 2011-08-15 12:39:57 --> Controller Class Initialized
ERROR - 2011-08-15 12:39:57 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-15 12:39:57 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-15 12:39:57 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-15 12:39:57 --> Model Class Initialized
DEBUG - 2011-08-15 12:39:57 --> Model Class Initialized
DEBUG - 2011-08-15 12:39:57 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-15 12:39:57 --> Database Driver Class Initialized
DEBUG - 2011-08-15 12:39:57 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-15 12:39:57 --> Helper loaded: url_helper
DEBUG - 2011-08-15 12:39:57 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-15 12:39:57 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-15 12:39:57 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-15 12:39:57 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-15 12:39:57 --> Final output sent to browser
DEBUG - 2011-08-15 12:39:57 --> Total execution time: 0.0283
DEBUG - 2011-08-15 12:39:58 --> Config Class Initialized
DEBUG - 2011-08-15 12:39:58 --> Hooks Class Initialized
DEBUG - 2011-08-15 12:39:58 --> Utf8 Class Initialized
DEBUG - 2011-08-15 12:39:58 --> UTF-8 Support Enabled
DEBUG - 2011-08-15 12:39:58 --> URI Class Initialized
DEBUG - 2011-08-15 12:39:58 --> Router Class Initialized
DEBUG - 2011-08-15 12:39:58 --> Output Class Initialized
DEBUG - 2011-08-15 12:39:58 --> Input Class Initialized
DEBUG - 2011-08-15 12:39:58 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-15 12:39:58 --> Language Class Initialized
DEBUG - 2011-08-15 12:39:58 --> Loader Class Initialized
DEBUG - 2011-08-15 12:39:58 --> Controller Class Initialized
DEBUG - 2011-08-15 12:39:58 --> Model Class Initialized
DEBUG - 2011-08-15 12:39:58 --> Model Class Initialized
DEBUG - 2011-08-15 12:39:58 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-15 12:39:58 --> Database Driver Class Initialized
DEBUG - 2011-08-15 12:39:58 --> Final output sent to browser
DEBUG - 2011-08-15 12:39:58 --> Total execution time: 0.4610
DEBUG - 2011-08-15 12:40:03 --> Config Class Initialized
DEBUG - 2011-08-15 12:40:03 --> Hooks Class Initialized
DEBUG - 2011-08-15 12:40:03 --> Utf8 Class Initialized
DEBUG - 2011-08-15 12:40:03 --> UTF-8 Support Enabled
DEBUG - 2011-08-15 12:40:03 --> URI Class Initialized
DEBUG - 2011-08-15 12:40:03 --> Router Class Initialized
DEBUG - 2011-08-15 12:40:03 --> Output Class Initialized
DEBUG - 2011-08-15 12:40:03 --> Input Class Initialized
DEBUG - 2011-08-15 12:40:03 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-15 12:40:03 --> Language Class Initialized
DEBUG - 2011-08-15 12:40:03 --> Loader Class Initialized
DEBUG - 2011-08-15 12:40:03 --> Controller Class Initialized
ERROR - 2011-08-15 12:40:03 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-15 12:40:03 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-15 12:40:03 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-15 12:40:03 --> Model Class Initialized
DEBUG - 2011-08-15 12:40:03 --> Model Class Initialized
DEBUG - 2011-08-15 12:40:03 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-15 12:40:03 --> Database Driver Class Initialized
DEBUG - 2011-08-15 12:40:03 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-15 12:40:03 --> Helper loaded: url_helper
DEBUG - 2011-08-15 12:40:03 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-15 12:40:03 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-15 12:40:03 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-15 12:40:03 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-15 12:40:03 --> Final output sent to browser
DEBUG - 2011-08-15 12:40:03 --> Total execution time: 0.1366
DEBUG - 2011-08-15 12:40:04 --> Config Class Initialized
DEBUG - 2011-08-15 12:40:04 --> Hooks Class Initialized
DEBUG - 2011-08-15 12:40:04 --> Utf8 Class Initialized
DEBUG - 2011-08-15 12:40:04 --> UTF-8 Support Enabled
DEBUG - 2011-08-15 12:40:04 --> URI Class Initialized
DEBUG - 2011-08-15 12:40:04 --> Router Class Initialized
DEBUG - 2011-08-15 12:40:04 --> Output Class Initialized
DEBUG - 2011-08-15 12:40:04 --> Input Class Initialized
DEBUG - 2011-08-15 12:40:04 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-15 12:40:04 --> Language Class Initialized
DEBUG - 2011-08-15 12:40:04 --> Loader Class Initialized
DEBUG - 2011-08-15 12:40:04 --> Controller Class Initialized
DEBUG - 2011-08-15 12:40:04 --> Model Class Initialized
DEBUG - 2011-08-15 12:40:04 --> Model Class Initialized
DEBUG - 2011-08-15 12:40:04 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-15 12:40:04 --> Database Driver Class Initialized
DEBUG - 2011-08-15 12:40:04 --> Final output sent to browser
DEBUG - 2011-08-15 12:40:04 --> Total execution time: 0.5947
DEBUG - 2011-08-15 12:40:08 --> Config Class Initialized
DEBUG - 2011-08-15 12:40:08 --> Hooks Class Initialized
DEBUG - 2011-08-15 12:40:08 --> Utf8 Class Initialized
DEBUG - 2011-08-15 12:40:08 --> UTF-8 Support Enabled
DEBUG - 2011-08-15 12:40:08 --> URI Class Initialized
DEBUG - 2011-08-15 12:40:08 --> Router Class Initialized
DEBUG - 2011-08-15 12:40:08 --> Output Class Initialized
DEBUG - 2011-08-15 12:40:08 --> Input Class Initialized
DEBUG - 2011-08-15 12:40:08 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-15 12:40:08 --> Language Class Initialized
DEBUG - 2011-08-15 12:40:08 --> Loader Class Initialized
DEBUG - 2011-08-15 12:40:08 --> Controller Class Initialized
ERROR - 2011-08-15 12:40:08 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-15 12:40:08 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-15 12:40:08 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-15 12:40:08 --> Model Class Initialized
DEBUG - 2011-08-15 12:40:08 --> Model Class Initialized
DEBUG - 2011-08-15 12:40:08 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-15 12:40:08 --> Database Driver Class Initialized
DEBUG - 2011-08-15 12:40:08 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-15 12:40:08 --> Helper loaded: url_helper
DEBUG - 2011-08-15 12:40:08 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-15 12:40:08 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-15 12:40:08 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-15 12:40:08 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-15 12:40:08 --> Final output sent to browser
DEBUG - 2011-08-15 12:40:08 --> Total execution time: 0.0362
DEBUG - 2011-08-15 12:40:08 --> Config Class Initialized
DEBUG - 2011-08-15 12:40:08 --> Hooks Class Initialized
DEBUG - 2011-08-15 12:40:08 --> Utf8 Class Initialized
DEBUG - 2011-08-15 12:40:08 --> UTF-8 Support Enabled
DEBUG - 2011-08-15 12:40:08 --> URI Class Initialized
DEBUG - 2011-08-15 12:40:08 --> Router Class Initialized
DEBUG - 2011-08-15 12:40:08 --> Output Class Initialized
DEBUG - 2011-08-15 12:40:08 --> Input Class Initialized
DEBUG - 2011-08-15 12:40:08 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-15 12:40:08 --> Language Class Initialized
DEBUG - 2011-08-15 12:40:08 --> Loader Class Initialized
DEBUG - 2011-08-15 12:40:08 --> Controller Class Initialized
DEBUG - 2011-08-15 12:40:08 --> Model Class Initialized
DEBUG - 2011-08-15 12:40:08 --> Model Class Initialized
DEBUG - 2011-08-15 12:40:08 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-15 12:40:08 --> Database Driver Class Initialized
DEBUG - 2011-08-15 12:40:09 --> Final output sent to browser
DEBUG - 2011-08-15 12:40:09 --> Total execution time: 0.5219
DEBUG - 2011-08-15 12:40:15 --> Config Class Initialized
DEBUG - 2011-08-15 12:40:15 --> Hooks Class Initialized
DEBUG - 2011-08-15 12:40:15 --> Utf8 Class Initialized
DEBUG - 2011-08-15 12:40:15 --> UTF-8 Support Enabled
DEBUG - 2011-08-15 12:40:15 --> URI Class Initialized
DEBUG - 2011-08-15 12:40:15 --> Router Class Initialized
DEBUG - 2011-08-15 12:40:15 --> Output Class Initialized
DEBUG - 2011-08-15 12:40:15 --> Input Class Initialized
DEBUG - 2011-08-15 12:40:15 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-15 12:40:15 --> Language Class Initialized
DEBUG - 2011-08-15 12:40:15 --> Loader Class Initialized
DEBUG - 2011-08-15 12:40:15 --> Controller Class Initialized
ERROR - 2011-08-15 12:40:15 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-15 12:40:15 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-15 12:40:15 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-15 12:40:15 --> Model Class Initialized
DEBUG - 2011-08-15 12:40:15 --> Model Class Initialized
DEBUG - 2011-08-15 12:40:15 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-15 12:40:15 --> Database Driver Class Initialized
DEBUG - 2011-08-15 12:40:15 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-15 12:40:15 --> Helper loaded: url_helper
DEBUG - 2011-08-15 12:40:15 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-15 12:40:15 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-15 12:40:15 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-15 12:40:15 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-15 12:40:15 --> Final output sent to browser
DEBUG - 2011-08-15 12:40:15 --> Total execution time: 0.0750
DEBUG - 2011-08-15 12:40:16 --> Config Class Initialized
DEBUG - 2011-08-15 12:40:16 --> Hooks Class Initialized
DEBUG - 2011-08-15 12:40:16 --> Utf8 Class Initialized
DEBUG - 2011-08-15 12:40:16 --> UTF-8 Support Enabled
DEBUG - 2011-08-15 12:40:16 --> URI Class Initialized
DEBUG - 2011-08-15 12:40:16 --> Router Class Initialized
DEBUG - 2011-08-15 12:40:16 --> Output Class Initialized
DEBUG - 2011-08-15 12:40:16 --> Input Class Initialized
DEBUG - 2011-08-15 12:40:16 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-15 12:40:16 --> Language Class Initialized
DEBUG - 2011-08-15 12:40:16 --> Loader Class Initialized
DEBUG - 2011-08-15 12:40:16 --> Controller Class Initialized
DEBUG - 2011-08-15 12:40:16 --> Model Class Initialized
DEBUG - 2011-08-15 12:40:16 --> Model Class Initialized
DEBUG - 2011-08-15 12:40:16 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-15 12:40:16 --> Database Driver Class Initialized
DEBUG - 2011-08-15 12:40:17 --> Final output sent to browser
DEBUG - 2011-08-15 12:40:17 --> Total execution time: 0.5249
DEBUG - 2011-08-15 12:40:22 --> Config Class Initialized
DEBUG - 2011-08-15 12:40:22 --> Hooks Class Initialized
DEBUG - 2011-08-15 12:40:22 --> Utf8 Class Initialized
DEBUG - 2011-08-15 12:40:22 --> UTF-8 Support Enabled
DEBUG - 2011-08-15 12:40:22 --> URI Class Initialized
DEBUG - 2011-08-15 12:40:22 --> Router Class Initialized
DEBUG - 2011-08-15 12:40:22 --> Output Class Initialized
DEBUG - 2011-08-15 12:40:22 --> Input Class Initialized
DEBUG - 2011-08-15 12:40:22 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-15 12:40:22 --> Language Class Initialized
DEBUG - 2011-08-15 12:40:22 --> Loader Class Initialized
DEBUG - 2011-08-15 12:40:22 --> Controller Class Initialized
ERROR - 2011-08-15 12:40:22 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-15 12:40:22 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-15 12:40:22 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-15 12:40:22 --> Model Class Initialized
DEBUG - 2011-08-15 12:40:22 --> Model Class Initialized
DEBUG - 2011-08-15 12:40:22 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-15 12:40:22 --> Database Driver Class Initialized
DEBUG - 2011-08-15 12:40:22 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-15 12:40:22 --> Helper loaded: url_helper
DEBUG - 2011-08-15 12:40:22 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-15 12:40:22 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-15 12:40:22 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-15 12:40:22 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-15 12:40:22 --> Final output sent to browser
DEBUG - 2011-08-15 12:40:22 --> Total execution time: 0.0400
DEBUG - 2011-08-15 12:40:22 --> Config Class Initialized
DEBUG - 2011-08-15 12:40:22 --> Hooks Class Initialized
DEBUG - 2011-08-15 12:40:22 --> Utf8 Class Initialized
DEBUG - 2011-08-15 12:40:22 --> UTF-8 Support Enabled
DEBUG - 2011-08-15 12:40:22 --> URI Class Initialized
DEBUG - 2011-08-15 12:40:22 --> Router Class Initialized
DEBUG - 2011-08-15 12:40:22 --> Output Class Initialized
DEBUG - 2011-08-15 12:40:22 --> Input Class Initialized
DEBUG - 2011-08-15 12:40:22 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-15 12:40:22 --> Language Class Initialized
DEBUG - 2011-08-15 12:40:22 --> Loader Class Initialized
DEBUG - 2011-08-15 12:40:22 --> Controller Class Initialized
DEBUG - 2011-08-15 12:40:22 --> Model Class Initialized
DEBUG - 2011-08-15 12:40:22 --> Model Class Initialized
DEBUG - 2011-08-15 12:40:22 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-15 12:40:22 --> Database Driver Class Initialized
DEBUG - 2011-08-15 12:40:23 --> Final output sent to browser
DEBUG - 2011-08-15 12:40:23 --> Total execution time: 0.5193
DEBUG - 2011-08-15 12:40:26 --> Config Class Initialized
DEBUG - 2011-08-15 12:40:26 --> Hooks Class Initialized
DEBUG - 2011-08-15 12:40:26 --> Utf8 Class Initialized
DEBUG - 2011-08-15 12:40:26 --> UTF-8 Support Enabled
DEBUG - 2011-08-15 12:40:26 --> URI Class Initialized
DEBUG - 2011-08-15 12:40:26 --> Router Class Initialized
DEBUG - 2011-08-15 12:40:26 --> Output Class Initialized
DEBUG - 2011-08-15 12:40:26 --> Input Class Initialized
DEBUG - 2011-08-15 12:40:26 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-15 12:40:26 --> Language Class Initialized
DEBUG - 2011-08-15 12:40:26 --> Loader Class Initialized
DEBUG - 2011-08-15 12:40:26 --> Controller Class Initialized
ERROR - 2011-08-15 12:40:26 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-15 12:40:26 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-15 12:40:26 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-15 12:40:26 --> Model Class Initialized
DEBUG - 2011-08-15 12:40:26 --> Model Class Initialized
DEBUG - 2011-08-15 12:40:26 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-15 12:40:26 --> Database Driver Class Initialized
DEBUG - 2011-08-15 12:40:26 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-15 12:40:26 --> Helper loaded: url_helper
DEBUG - 2011-08-15 12:40:26 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-15 12:40:26 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-15 12:40:26 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-15 12:40:26 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-15 12:40:26 --> Final output sent to browser
DEBUG - 2011-08-15 12:40:26 --> Total execution time: 0.1176
DEBUG - 2011-08-15 12:40:27 --> Config Class Initialized
DEBUG - 2011-08-15 12:40:27 --> Hooks Class Initialized
DEBUG - 2011-08-15 12:40:27 --> Utf8 Class Initialized
DEBUG - 2011-08-15 12:40:27 --> UTF-8 Support Enabled
DEBUG - 2011-08-15 12:40:27 --> URI Class Initialized
DEBUG - 2011-08-15 12:40:27 --> Router Class Initialized
DEBUG - 2011-08-15 12:40:27 --> Output Class Initialized
DEBUG - 2011-08-15 12:40:27 --> Input Class Initialized
DEBUG - 2011-08-15 12:40:27 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-15 12:40:27 --> Language Class Initialized
DEBUG - 2011-08-15 12:40:27 --> Loader Class Initialized
DEBUG - 2011-08-15 12:40:27 --> Controller Class Initialized
DEBUG - 2011-08-15 12:40:27 --> Model Class Initialized
DEBUG - 2011-08-15 12:40:27 --> Model Class Initialized
DEBUG - 2011-08-15 12:40:27 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-15 12:40:27 --> Database Driver Class Initialized
DEBUG - 2011-08-15 12:40:27 --> Final output sent to browser
DEBUG - 2011-08-15 12:40:27 --> Total execution time: 0.5265
DEBUG - 2011-08-15 12:40:32 --> Config Class Initialized
DEBUG - 2011-08-15 12:40:32 --> Hooks Class Initialized
DEBUG - 2011-08-15 12:40:32 --> Utf8 Class Initialized
DEBUG - 2011-08-15 12:40:32 --> UTF-8 Support Enabled
DEBUG - 2011-08-15 12:40:32 --> URI Class Initialized
DEBUG - 2011-08-15 12:40:32 --> Router Class Initialized
DEBUG - 2011-08-15 12:40:32 --> Output Class Initialized
DEBUG - 2011-08-15 12:40:32 --> Input Class Initialized
DEBUG - 2011-08-15 12:40:32 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-15 12:40:32 --> Language Class Initialized
DEBUG - 2011-08-15 12:40:32 --> Loader Class Initialized
DEBUG - 2011-08-15 12:40:32 --> Controller Class Initialized
ERROR - 2011-08-15 12:40:32 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-15 12:40:32 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-15 12:40:32 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-15 12:40:32 --> Model Class Initialized
DEBUG - 2011-08-15 12:40:32 --> Model Class Initialized
DEBUG - 2011-08-15 12:40:32 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-15 12:40:32 --> Database Driver Class Initialized
DEBUG - 2011-08-15 12:40:32 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-15 12:40:32 --> Helper loaded: url_helper
DEBUG - 2011-08-15 12:40:32 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-15 12:40:32 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-15 12:40:32 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-15 12:40:32 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-15 12:40:32 --> Final output sent to browser
DEBUG - 2011-08-15 12:40:32 --> Total execution time: 0.0556
DEBUG - 2011-08-15 12:40:32 --> Config Class Initialized
DEBUG - 2011-08-15 12:40:32 --> Hooks Class Initialized
DEBUG - 2011-08-15 12:40:32 --> Utf8 Class Initialized
DEBUG - 2011-08-15 12:40:32 --> UTF-8 Support Enabled
DEBUG - 2011-08-15 12:40:32 --> URI Class Initialized
DEBUG - 2011-08-15 12:40:32 --> Router Class Initialized
DEBUG - 2011-08-15 12:40:32 --> Output Class Initialized
DEBUG - 2011-08-15 12:40:32 --> Input Class Initialized
DEBUG - 2011-08-15 12:40:32 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-15 12:40:32 --> Language Class Initialized
DEBUG - 2011-08-15 12:40:32 --> Loader Class Initialized
DEBUG - 2011-08-15 12:40:32 --> Controller Class Initialized
DEBUG - 2011-08-15 12:40:32 --> Model Class Initialized
DEBUG - 2011-08-15 12:40:32 --> Model Class Initialized
DEBUG - 2011-08-15 12:40:32 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-15 12:40:32 --> Database Driver Class Initialized
DEBUG - 2011-08-15 12:40:33 --> Final output sent to browser
DEBUG - 2011-08-15 12:40:33 --> Total execution time: 0.4991
DEBUG - 2011-08-15 12:40:39 --> Config Class Initialized
DEBUG - 2011-08-15 12:40:39 --> Hooks Class Initialized
DEBUG - 2011-08-15 12:40:39 --> Utf8 Class Initialized
DEBUG - 2011-08-15 12:40:39 --> UTF-8 Support Enabled
DEBUG - 2011-08-15 12:40:39 --> URI Class Initialized
DEBUG - 2011-08-15 12:40:39 --> Router Class Initialized
DEBUG - 2011-08-15 12:40:39 --> Output Class Initialized
DEBUG - 2011-08-15 12:40:39 --> Input Class Initialized
DEBUG - 2011-08-15 12:40:39 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-15 12:40:39 --> Language Class Initialized
DEBUG - 2011-08-15 12:40:39 --> Loader Class Initialized
DEBUG - 2011-08-15 12:40:39 --> Controller Class Initialized
DEBUG - 2011-08-15 12:40:39 --> Model Class Initialized
DEBUG - 2011-08-15 12:40:39 --> Model Class Initialized
DEBUG - 2011-08-15 12:40:39 --> Model Class Initialized
DEBUG - 2011-08-15 12:40:39 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-15 12:40:39 --> Database Driver Class Initialized
DEBUG - 2011-08-15 12:40:39 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-15 12:40:39 --> Helper loaded: url_helper
DEBUG - 2011-08-15 12:40:39 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-15 12:40:39 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-15 12:40:39 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-15 12:40:39 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-15 12:40:39 --> Final output sent to browser
DEBUG - 2011-08-15 12:40:39 --> Total execution time: 0.2107
DEBUG - 2011-08-15 12:40:41 --> Config Class Initialized
DEBUG - 2011-08-15 12:40:41 --> Hooks Class Initialized
DEBUG - 2011-08-15 12:40:41 --> Utf8 Class Initialized
DEBUG - 2011-08-15 12:40:41 --> UTF-8 Support Enabled
DEBUG - 2011-08-15 12:40:41 --> URI Class Initialized
DEBUG - 2011-08-15 12:40:41 --> Router Class Initialized
ERROR - 2011-08-15 12:40:41 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-15 12:40:42 --> Config Class Initialized
DEBUG - 2011-08-15 12:40:42 --> Hooks Class Initialized
DEBUG - 2011-08-15 12:40:42 --> Utf8 Class Initialized
DEBUG - 2011-08-15 12:40:42 --> UTF-8 Support Enabled
DEBUG - 2011-08-15 12:40:42 --> URI Class Initialized
DEBUG - 2011-08-15 12:40:42 --> Router Class Initialized
DEBUG - 2011-08-15 12:40:42 --> Output Class Initialized
DEBUG - 2011-08-15 12:40:42 --> Input Class Initialized
DEBUG - 2011-08-15 12:40:42 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-15 12:40:42 --> Language Class Initialized
DEBUG - 2011-08-15 12:40:42 --> Loader Class Initialized
DEBUG - 2011-08-15 12:40:42 --> Controller Class Initialized
DEBUG - 2011-08-15 12:40:42 --> Model Class Initialized
DEBUG - 2011-08-15 12:40:42 --> Model Class Initialized
DEBUG - 2011-08-15 12:40:42 --> Model Class Initialized
DEBUG - 2011-08-15 12:40:42 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-15 12:40:42 --> Database Driver Class Initialized
DEBUG - 2011-08-15 12:40:42 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-15 12:40:42 --> Helper loaded: url_helper
DEBUG - 2011-08-15 12:40:42 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-15 12:40:42 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-15 12:40:42 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-15 12:40:42 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-15 12:40:42 --> Final output sent to browser
DEBUG - 2011-08-15 12:40:42 --> Total execution time: 0.2183
DEBUG - 2011-08-15 12:40:50 --> Config Class Initialized
DEBUG - 2011-08-15 12:40:50 --> Hooks Class Initialized
DEBUG - 2011-08-15 12:40:50 --> Utf8 Class Initialized
DEBUG - 2011-08-15 12:40:50 --> UTF-8 Support Enabled
DEBUG - 2011-08-15 12:40:50 --> URI Class Initialized
DEBUG - 2011-08-15 12:40:50 --> Router Class Initialized
DEBUG - 2011-08-15 12:40:50 --> Output Class Initialized
DEBUG - 2011-08-15 12:40:50 --> Input Class Initialized
DEBUG - 2011-08-15 12:40:50 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-15 12:40:50 --> Language Class Initialized
DEBUG - 2011-08-15 12:40:50 --> Loader Class Initialized
DEBUG - 2011-08-15 12:40:50 --> Controller Class Initialized
DEBUG - 2011-08-15 12:40:50 --> Model Class Initialized
DEBUG - 2011-08-15 12:40:50 --> Model Class Initialized
DEBUG - 2011-08-15 12:40:50 --> Model Class Initialized
DEBUG - 2011-08-15 12:40:50 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-15 12:40:50 --> Database Driver Class Initialized
DEBUG - 2011-08-15 12:40:51 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-15 12:40:51 --> Helper loaded: url_helper
DEBUG - 2011-08-15 12:40:51 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-15 12:40:51 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-15 12:40:51 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-15 12:40:51 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-15 12:40:51 --> Final output sent to browser
DEBUG - 2011-08-15 12:40:51 --> Total execution time: 0.5323
DEBUG - 2011-08-15 12:40:52 --> Config Class Initialized
DEBUG - 2011-08-15 12:40:52 --> Hooks Class Initialized
DEBUG - 2011-08-15 12:40:52 --> Utf8 Class Initialized
DEBUG - 2011-08-15 12:40:52 --> UTF-8 Support Enabled
DEBUG - 2011-08-15 12:40:52 --> URI Class Initialized
DEBUG - 2011-08-15 12:40:52 --> Router Class Initialized
DEBUG - 2011-08-15 12:40:52 --> Output Class Initialized
DEBUG - 2011-08-15 12:40:52 --> Input Class Initialized
DEBUG - 2011-08-15 12:40:52 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-15 12:40:52 --> Language Class Initialized
DEBUG - 2011-08-15 12:40:52 --> Loader Class Initialized
DEBUG - 2011-08-15 12:40:52 --> Controller Class Initialized
DEBUG - 2011-08-15 12:40:52 --> Model Class Initialized
DEBUG - 2011-08-15 12:40:52 --> Model Class Initialized
DEBUG - 2011-08-15 12:40:52 --> Model Class Initialized
DEBUG - 2011-08-15 12:40:52 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-15 12:40:52 --> Database Driver Class Initialized
DEBUG - 2011-08-15 12:40:52 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-15 12:40:52 --> Helper loaded: url_helper
DEBUG - 2011-08-15 12:40:52 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-15 12:40:52 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-15 12:40:52 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-15 12:40:52 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-15 12:40:52 --> Final output sent to browser
DEBUG - 2011-08-15 12:40:52 --> Total execution time: 0.0416
DEBUG - 2011-08-15 12:40:52 --> Config Class Initialized
DEBUG - 2011-08-15 12:40:52 --> Hooks Class Initialized
DEBUG - 2011-08-15 12:40:52 --> Utf8 Class Initialized
DEBUG - 2011-08-15 12:40:52 --> UTF-8 Support Enabled
DEBUG - 2011-08-15 12:40:52 --> URI Class Initialized
DEBUG - 2011-08-15 12:40:52 --> Router Class Initialized
ERROR - 2011-08-15 12:40:52 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-15 12:41:06 --> Config Class Initialized
DEBUG - 2011-08-15 12:41:06 --> Hooks Class Initialized
DEBUG - 2011-08-15 12:41:06 --> Utf8 Class Initialized
DEBUG - 2011-08-15 12:41:06 --> UTF-8 Support Enabled
DEBUG - 2011-08-15 12:41:06 --> URI Class Initialized
DEBUG - 2011-08-15 12:41:06 --> Router Class Initialized
DEBUG - 2011-08-15 12:41:06 --> Output Class Initialized
DEBUG - 2011-08-15 12:41:06 --> Input Class Initialized
DEBUG - 2011-08-15 12:41:06 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-15 12:41:06 --> Language Class Initialized
DEBUG - 2011-08-15 12:41:06 --> Loader Class Initialized
DEBUG - 2011-08-15 12:41:06 --> Controller Class Initialized
ERROR - 2011-08-15 12:41:06 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-15 12:41:06 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-15 12:41:06 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-15 12:41:06 --> Model Class Initialized
DEBUG - 2011-08-15 12:41:06 --> Model Class Initialized
DEBUG - 2011-08-15 12:41:06 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-15 12:41:06 --> Database Driver Class Initialized
DEBUG - 2011-08-15 12:41:06 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-15 12:41:06 --> Helper loaded: url_helper
DEBUG - 2011-08-15 12:41:06 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-15 12:41:06 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-15 12:41:06 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-15 12:41:06 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-15 12:41:06 --> Final output sent to browser
DEBUG - 2011-08-15 12:41:06 --> Total execution time: 0.0371
DEBUG - 2011-08-15 12:41:07 --> Config Class Initialized
DEBUG - 2011-08-15 12:41:07 --> Hooks Class Initialized
DEBUG - 2011-08-15 12:41:07 --> Utf8 Class Initialized
DEBUG - 2011-08-15 12:41:07 --> UTF-8 Support Enabled
DEBUG - 2011-08-15 12:41:07 --> URI Class Initialized
DEBUG - 2011-08-15 12:41:07 --> Router Class Initialized
DEBUG - 2011-08-15 12:41:07 --> Output Class Initialized
DEBUG - 2011-08-15 12:41:07 --> Input Class Initialized
DEBUG - 2011-08-15 12:41:07 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-15 12:41:07 --> Language Class Initialized
DEBUG - 2011-08-15 12:41:07 --> Loader Class Initialized
DEBUG - 2011-08-15 12:41:07 --> Controller Class Initialized
DEBUG - 2011-08-15 12:41:07 --> Model Class Initialized
DEBUG - 2011-08-15 12:41:07 --> Model Class Initialized
DEBUG - 2011-08-15 12:41:07 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-15 12:41:07 --> Database Driver Class Initialized
DEBUG - 2011-08-15 12:41:08 --> Final output sent to browser
DEBUG - 2011-08-15 12:41:08 --> Total execution time: 0.4499
DEBUG - 2011-08-15 12:41:09 --> Config Class Initialized
DEBUG - 2011-08-15 12:41:09 --> Hooks Class Initialized
DEBUG - 2011-08-15 12:41:09 --> Utf8 Class Initialized
DEBUG - 2011-08-15 12:41:09 --> UTF-8 Support Enabled
DEBUG - 2011-08-15 12:41:09 --> URI Class Initialized
DEBUG - 2011-08-15 12:41:09 --> Router Class Initialized
ERROR - 2011-08-15 12:41:09 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-15 12:41:47 --> Config Class Initialized
DEBUG - 2011-08-15 12:41:47 --> Hooks Class Initialized
DEBUG - 2011-08-15 12:41:47 --> Utf8 Class Initialized
DEBUG - 2011-08-15 12:41:47 --> UTF-8 Support Enabled
DEBUG - 2011-08-15 12:41:47 --> URI Class Initialized
DEBUG - 2011-08-15 12:41:47 --> Router Class Initialized
DEBUG - 2011-08-15 12:41:47 --> Output Class Initialized
DEBUG - 2011-08-15 12:41:47 --> Input Class Initialized
DEBUG - 2011-08-15 12:41:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-15 12:41:47 --> Language Class Initialized
DEBUG - 2011-08-15 12:41:47 --> Loader Class Initialized
DEBUG - 2011-08-15 12:41:47 --> Controller Class Initialized
ERROR - 2011-08-15 12:41:47 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-15 12:41:47 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-15 12:41:47 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-15 12:41:47 --> Model Class Initialized
DEBUG - 2011-08-15 12:41:47 --> Model Class Initialized
DEBUG - 2011-08-15 12:41:47 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-15 12:41:47 --> Database Driver Class Initialized
DEBUG - 2011-08-15 12:41:47 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-15 12:41:47 --> Helper loaded: url_helper
DEBUG - 2011-08-15 12:41:47 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-15 12:41:47 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-15 12:41:47 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-15 12:41:47 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-15 12:41:47 --> Final output sent to browser
DEBUG - 2011-08-15 12:41:47 --> Total execution time: 0.1183
DEBUG - 2011-08-15 12:41:48 --> Config Class Initialized
DEBUG - 2011-08-15 12:41:48 --> Hooks Class Initialized
DEBUG - 2011-08-15 12:41:48 --> Utf8 Class Initialized
DEBUG - 2011-08-15 12:41:48 --> UTF-8 Support Enabled
DEBUG - 2011-08-15 12:41:48 --> URI Class Initialized
DEBUG - 2011-08-15 12:41:48 --> Router Class Initialized
DEBUG - 2011-08-15 12:41:48 --> Output Class Initialized
DEBUG - 2011-08-15 12:41:48 --> Input Class Initialized
DEBUG - 2011-08-15 12:41:48 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-15 12:41:48 --> Language Class Initialized
DEBUG - 2011-08-15 12:41:48 --> Loader Class Initialized
DEBUG - 2011-08-15 12:41:48 --> Controller Class Initialized
DEBUG - 2011-08-15 12:41:48 --> Model Class Initialized
DEBUG - 2011-08-15 12:41:48 --> Model Class Initialized
DEBUG - 2011-08-15 12:41:48 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-15 12:41:48 --> Database Driver Class Initialized
DEBUG - 2011-08-15 12:41:49 --> Final output sent to browser
DEBUG - 2011-08-15 12:41:49 --> Total execution time: 0.6434
DEBUG - 2011-08-15 12:41:52 --> Config Class Initialized
DEBUG - 2011-08-15 12:41:52 --> Hooks Class Initialized
DEBUG - 2011-08-15 12:41:52 --> Utf8 Class Initialized
DEBUG - 2011-08-15 12:41:52 --> UTF-8 Support Enabled
DEBUG - 2011-08-15 12:41:52 --> URI Class Initialized
DEBUG - 2011-08-15 12:41:52 --> Router Class Initialized
ERROR - 2011-08-15 12:41:52 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-15 12:42:09 --> Config Class Initialized
DEBUG - 2011-08-15 12:42:09 --> Hooks Class Initialized
DEBUG - 2011-08-15 12:42:09 --> Utf8 Class Initialized
DEBUG - 2011-08-15 12:42:09 --> UTF-8 Support Enabled
DEBUG - 2011-08-15 12:42:09 --> URI Class Initialized
DEBUG - 2011-08-15 12:42:09 --> Router Class Initialized
DEBUG - 2011-08-15 12:42:09 --> Output Class Initialized
DEBUG - 2011-08-15 12:42:09 --> Input Class Initialized
DEBUG - 2011-08-15 12:42:09 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-15 12:42:09 --> Language Class Initialized
DEBUG - 2011-08-15 12:42:09 --> Loader Class Initialized
DEBUG - 2011-08-15 12:42:09 --> Controller Class Initialized
ERROR - 2011-08-15 12:42:09 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-15 12:42:09 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-15 12:42:09 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-15 12:42:09 --> Model Class Initialized
DEBUG - 2011-08-15 12:42:09 --> Model Class Initialized
DEBUG - 2011-08-15 12:42:09 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-15 12:42:09 --> Database Driver Class Initialized
DEBUG - 2011-08-15 12:42:09 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-15 12:42:09 --> Helper loaded: url_helper
DEBUG - 2011-08-15 12:42:09 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-15 12:42:09 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-15 12:42:09 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-15 12:42:09 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-15 12:42:09 --> Final output sent to browser
DEBUG - 2011-08-15 12:42:09 --> Total execution time: 0.0390
DEBUG - 2011-08-15 12:42:10 --> Config Class Initialized
DEBUG - 2011-08-15 12:42:10 --> Hooks Class Initialized
DEBUG - 2011-08-15 12:42:10 --> Utf8 Class Initialized
DEBUG - 2011-08-15 12:42:10 --> UTF-8 Support Enabled
DEBUG - 2011-08-15 12:42:10 --> URI Class Initialized
DEBUG - 2011-08-15 12:42:10 --> Router Class Initialized
DEBUG - 2011-08-15 12:42:10 --> Output Class Initialized
DEBUG - 2011-08-15 12:42:10 --> Input Class Initialized
DEBUG - 2011-08-15 12:42:10 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-15 12:42:10 --> Language Class Initialized
DEBUG - 2011-08-15 12:42:10 --> Loader Class Initialized
DEBUG - 2011-08-15 12:42:10 --> Controller Class Initialized
DEBUG - 2011-08-15 12:42:10 --> Model Class Initialized
DEBUG - 2011-08-15 12:42:10 --> Model Class Initialized
DEBUG - 2011-08-15 12:42:10 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-15 12:42:10 --> Database Driver Class Initialized
DEBUG - 2011-08-15 12:42:10 --> Final output sent to browser
DEBUG - 2011-08-15 12:42:10 --> Total execution time: 0.5058
DEBUG - 2011-08-15 12:42:16 --> Config Class Initialized
DEBUG - 2011-08-15 12:42:16 --> Hooks Class Initialized
DEBUG - 2011-08-15 12:42:16 --> Utf8 Class Initialized
DEBUG - 2011-08-15 12:42:16 --> UTF-8 Support Enabled
DEBUG - 2011-08-15 12:42:16 --> URI Class Initialized
DEBUG - 2011-08-15 12:42:16 --> Router Class Initialized
ERROR - 2011-08-15 12:42:16 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-15 12:42:21 --> Config Class Initialized
DEBUG - 2011-08-15 12:42:21 --> Hooks Class Initialized
DEBUG - 2011-08-15 12:42:21 --> Utf8 Class Initialized
DEBUG - 2011-08-15 12:42:21 --> UTF-8 Support Enabled
DEBUG - 2011-08-15 12:42:21 --> URI Class Initialized
DEBUG - 2011-08-15 12:42:21 --> Router Class Initialized
DEBUG - 2011-08-15 12:42:21 --> Output Class Initialized
DEBUG - 2011-08-15 12:42:21 --> Input Class Initialized
DEBUG - 2011-08-15 12:42:21 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-15 12:42:21 --> Language Class Initialized
DEBUG - 2011-08-15 12:42:21 --> Loader Class Initialized
DEBUG - 2011-08-15 12:42:21 --> Controller Class Initialized
ERROR - 2011-08-15 12:42:21 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-15 12:42:21 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-15 12:42:21 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-15 12:42:21 --> Model Class Initialized
DEBUG - 2011-08-15 12:42:21 --> Model Class Initialized
DEBUG - 2011-08-15 12:42:21 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-15 12:42:21 --> Database Driver Class Initialized
DEBUG - 2011-08-15 12:42:21 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-15 12:42:21 --> Helper loaded: url_helper
DEBUG - 2011-08-15 12:42:21 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-15 12:42:21 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-15 12:42:21 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-15 12:42:21 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-15 12:42:21 --> Final output sent to browser
DEBUG - 2011-08-15 12:42:21 --> Total execution time: 0.0270
DEBUG - 2011-08-15 12:42:22 --> Config Class Initialized
DEBUG - 2011-08-15 12:42:22 --> Hooks Class Initialized
DEBUG - 2011-08-15 12:42:22 --> Utf8 Class Initialized
DEBUG - 2011-08-15 12:42:22 --> UTF-8 Support Enabled
DEBUG - 2011-08-15 12:42:22 --> URI Class Initialized
DEBUG - 2011-08-15 12:42:22 --> Router Class Initialized
DEBUG - 2011-08-15 12:42:22 --> Output Class Initialized
DEBUG - 2011-08-15 12:42:22 --> Input Class Initialized
DEBUG - 2011-08-15 12:42:22 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-15 12:42:22 --> Language Class Initialized
DEBUG - 2011-08-15 12:42:22 --> Loader Class Initialized
DEBUG - 2011-08-15 12:42:22 --> Controller Class Initialized
DEBUG - 2011-08-15 12:42:22 --> Model Class Initialized
DEBUG - 2011-08-15 12:42:22 --> Model Class Initialized
DEBUG - 2011-08-15 12:42:22 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-15 12:42:22 --> Database Driver Class Initialized
DEBUG - 2011-08-15 12:42:23 --> Final output sent to browser
DEBUG - 2011-08-15 12:42:23 --> Total execution time: 0.5907
DEBUG - 2011-08-15 12:42:25 --> Config Class Initialized
DEBUG - 2011-08-15 12:42:25 --> Hooks Class Initialized
DEBUG - 2011-08-15 12:42:25 --> Utf8 Class Initialized
DEBUG - 2011-08-15 12:42:25 --> UTF-8 Support Enabled
DEBUG - 2011-08-15 12:42:25 --> URI Class Initialized
DEBUG - 2011-08-15 12:42:25 --> Router Class Initialized
ERROR - 2011-08-15 12:42:25 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-15 12:42:32 --> Config Class Initialized
DEBUG - 2011-08-15 12:42:32 --> Hooks Class Initialized
DEBUG - 2011-08-15 12:42:32 --> Utf8 Class Initialized
DEBUG - 2011-08-15 12:42:32 --> UTF-8 Support Enabled
DEBUG - 2011-08-15 12:42:32 --> URI Class Initialized
DEBUG - 2011-08-15 12:42:32 --> Router Class Initialized
DEBUG - 2011-08-15 12:42:32 --> Output Class Initialized
DEBUG - 2011-08-15 12:42:32 --> Input Class Initialized
DEBUG - 2011-08-15 12:42:32 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-15 12:42:32 --> Language Class Initialized
DEBUG - 2011-08-15 12:42:32 --> Loader Class Initialized
DEBUG - 2011-08-15 12:42:32 --> Controller Class Initialized
ERROR - 2011-08-15 12:42:32 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-15 12:42:32 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-15 12:42:32 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-15 12:42:32 --> Model Class Initialized
DEBUG - 2011-08-15 12:42:32 --> Model Class Initialized
DEBUG - 2011-08-15 12:42:32 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-15 12:42:32 --> Database Driver Class Initialized
DEBUG - 2011-08-15 12:42:32 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-15 12:42:32 --> Helper loaded: url_helper
DEBUG - 2011-08-15 12:42:32 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-15 12:42:32 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-15 12:42:32 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-15 12:42:32 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-15 12:42:32 --> Final output sent to browser
DEBUG - 2011-08-15 12:42:32 --> Total execution time: 0.0309
DEBUG - 2011-08-15 12:42:33 --> Config Class Initialized
DEBUG - 2011-08-15 12:42:33 --> Hooks Class Initialized
DEBUG - 2011-08-15 12:42:33 --> Utf8 Class Initialized
DEBUG - 2011-08-15 12:42:33 --> UTF-8 Support Enabled
DEBUG - 2011-08-15 12:42:33 --> URI Class Initialized
DEBUG - 2011-08-15 12:42:33 --> Router Class Initialized
DEBUG - 2011-08-15 12:42:33 --> Output Class Initialized
DEBUG - 2011-08-15 12:42:33 --> Input Class Initialized
DEBUG - 2011-08-15 12:42:33 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-15 12:42:33 --> Language Class Initialized
DEBUG - 2011-08-15 12:42:33 --> Loader Class Initialized
DEBUG - 2011-08-15 12:42:33 --> Controller Class Initialized
DEBUG - 2011-08-15 12:42:33 --> Model Class Initialized
DEBUG - 2011-08-15 12:42:33 --> Model Class Initialized
DEBUG - 2011-08-15 12:42:33 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-15 12:42:33 --> Database Driver Class Initialized
DEBUG - 2011-08-15 12:42:33 --> Final output sent to browser
DEBUG - 2011-08-15 12:42:33 --> Total execution time: 0.4546
DEBUG - 2011-08-15 12:42:53 --> Config Class Initialized
DEBUG - 2011-08-15 12:42:53 --> Hooks Class Initialized
DEBUG - 2011-08-15 12:42:53 --> Utf8 Class Initialized
DEBUG - 2011-08-15 12:42:53 --> UTF-8 Support Enabled
DEBUG - 2011-08-15 12:42:53 --> URI Class Initialized
DEBUG - 2011-08-15 12:42:53 --> Router Class Initialized
ERROR - 2011-08-15 12:42:53 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-15 12:46:35 --> Config Class Initialized
DEBUG - 2011-08-15 12:46:35 --> Hooks Class Initialized
DEBUG - 2011-08-15 12:46:35 --> Utf8 Class Initialized
DEBUG - 2011-08-15 12:46:35 --> UTF-8 Support Enabled
DEBUG - 2011-08-15 12:46:35 --> URI Class Initialized
DEBUG - 2011-08-15 12:46:35 --> Router Class Initialized
DEBUG - 2011-08-15 12:46:35 --> Output Class Initialized
DEBUG - 2011-08-15 12:46:35 --> Input Class Initialized
DEBUG - 2011-08-15 12:46:35 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-15 12:46:35 --> Language Class Initialized
DEBUG - 2011-08-15 12:46:35 --> Loader Class Initialized
DEBUG - 2011-08-15 12:46:35 --> Controller Class Initialized
DEBUG - 2011-08-15 12:46:35 --> Model Class Initialized
DEBUG - 2011-08-15 12:46:35 --> Model Class Initialized
DEBUG - 2011-08-15 12:46:35 --> Model Class Initialized
DEBUG - 2011-08-15 12:46:35 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-15 12:46:35 --> Database Driver Class Initialized
DEBUG - 2011-08-15 12:46:35 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-15 12:46:35 --> Helper loaded: url_helper
DEBUG - 2011-08-15 12:46:35 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-15 12:46:35 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-15 12:46:35 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-15 12:46:35 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-15 12:46:35 --> Final output sent to browser
DEBUG - 2011-08-15 12:46:35 --> Total execution time: 0.1136
DEBUG - 2011-08-15 12:46:38 --> Config Class Initialized
DEBUG - 2011-08-15 12:46:38 --> Hooks Class Initialized
DEBUG - 2011-08-15 12:46:38 --> Utf8 Class Initialized
DEBUG - 2011-08-15 12:46:38 --> UTF-8 Support Enabled
DEBUG - 2011-08-15 12:46:38 --> URI Class Initialized
DEBUG - 2011-08-15 12:46:38 --> Router Class Initialized
ERROR - 2011-08-15 12:46:38 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-15 12:46:54 --> Config Class Initialized
DEBUG - 2011-08-15 12:46:54 --> Hooks Class Initialized
DEBUG - 2011-08-15 12:46:54 --> Utf8 Class Initialized
DEBUG - 2011-08-15 12:46:54 --> UTF-8 Support Enabled
DEBUG - 2011-08-15 12:46:54 --> URI Class Initialized
DEBUG - 2011-08-15 12:46:54 --> Router Class Initialized
DEBUG - 2011-08-15 12:46:54 --> Output Class Initialized
DEBUG - 2011-08-15 12:46:54 --> Input Class Initialized
DEBUG - 2011-08-15 12:46:54 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-15 12:46:54 --> Language Class Initialized
DEBUG - 2011-08-15 12:46:54 --> Loader Class Initialized
DEBUG - 2011-08-15 12:46:54 --> Controller Class Initialized
DEBUG - 2011-08-15 12:46:54 --> Model Class Initialized
DEBUG - 2011-08-15 12:46:54 --> Model Class Initialized
DEBUG - 2011-08-15 12:46:54 --> Model Class Initialized
DEBUG - 2011-08-15 12:46:54 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-15 12:46:54 --> Database Driver Class Initialized
DEBUG - 2011-08-15 12:46:55 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-15 12:46:55 --> Helper loaded: url_helper
DEBUG - 2011-08-15 12:46:55 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-15 12:46:55 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-15 12:46:55 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-15 12:46:55 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-15 12:46:55 --> Final output sent to browser
DEBUG - 2011-08-15 12:46:55 --> Total execution time: 0.3991
DEBUG - 2011-08-15 12:46:57 --> Config Class Initialized
DEBUG - 2011-08-15 12:46:57 --> Hooks Class Initialized
DEBUG - 2011-08-15 12:46:57 --> Utf8 Class Initialized
DEBUG - 2011-08-15 12:46:57 --> UTF-8 Support Enabled
DEBUG - 2011-08-15 12:46:57 --> URI Class Initialized
DEBUG - 2011-08-15 12:46:57 --> Router Class Initialized
DEBUG - 2011-08-15 12:46:57 --> Output Class Initialized
DEBUG - 2011-08-15 12:46:57 --> Input Class Initialized
DEBUG - 2011-08-15 12:46:57 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-15 12:46:57 --> Language Class Initialized
DEBUG - 2011-08-15 12:46:57 --> Loader Class Initialized
DEBUG - 2011-08-15 12:46:57 --> Controller Class Initialized
DEBUG - 2011-08-15 12:46:57 --> Model Class Initialized
DEBUG - 2011-08-15 12:46:57 --> Model Class Initialized
DEBUG - 2011-08-15 12:46:57 --> Model Class Initialized
DEBUG - 2011-08-15 12:46:57 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-15 12:46:57 --> Database Driver Class Initialized
DEBUG - 2011-08-15 12:46:57 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-15 12:46:57 --> Helper loaded: url_helper
DEBUG - 2011-08-15 12:46:57 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-15 12:46:57 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-15 12:46:57 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-15 12:46:57 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-15 12:46:57 --> Final output sent to browser
DEBUG - 2011-08-15 12:46:57 --> Total execution time: 0.0629
DEBUG - 2011-08-15 12:46:57 --> Config Class Initialized
DEBUG - 2011-08-15 12:46:57 --> Hooks Class Initialized
DEBUG - 2011-08-15 12:46:57 --> Utf8 Class Initialized
DEBUG - 2011-08-15 12:46:57 --> UTF-8 Support Enabled
DEBUG - 2011-08-15 12:46:57 --> URI Class Initialized
DEBUG - 2011-08-15 12:46:57 --> Router Class Initialized
ERROR - 2011-08-15 12:46:57 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-15 12:47:14 --> Config Class Initialized
DEBUG - 2011-08-15 12:47:14 --> Hooks Class Initialized
DEBUG - 2011-08-15 12:47:14 --> Utf8 Class Initialized
DEBUG - 2011-08-15 12:47:14 --> UTF-8 Support Enabled
DEBUG - 2011-08-15 12:47:14 --> URI Class Initialized
DEBUG - 2011-08-15 12:47:14 --> Router Class Initialized
DEBUG - 2011-08-15 12:47:14 --> Output Class Initialized
DEBUG - 2011-08-15 12:47:14 --> Input Class Initialized
DEBUG - 2011-08-15 12:47:14 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-15 12:47:14 --> Language Class Initialized
DEBUG - 2011-08-15 12:47:14 --> Loader Class Initialized
DEBUG - 2011-08-15 12:47:14 --> Controller Class Initialized
DEBUG - 2011-08-15 12:47:14 --> Model Class Initialized
DEBUG - 2011-08-15 12:47:14 --> Model Class Initialized
DEBUG - 2011-08-15 12:47:14 --> Model Class Initialized
DEBUG - 2011-08-15 12:47:14 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-15 12:47:14 --> Database Driver Class Initialized
DEBUG - 2011-08-15 12:47:14 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-15 12:47:14 --> Helper loaded: url_helper
DEBUG - 2011-08-15 12:47:14 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-15 12:47:14 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-15 12:47:14 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-15 12:47:14 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-15 12:47:14 --> Final output sent to browser
DEBUG - 2011-08-15 12:47:14 --> Total execution time: 0.7491
DEBUG - 2011-08-15 12:47:17 --> Config Class Initialized
DEBUG - 2011-08-15 12:47:17 --> Hooks Class Initialized
DEBUG - 2011-08-15 12:47:17 --> Utf8 Class Initialized
DEBUG - 2011-08-15 12:47:17 --> UTF-8 Support Enabled
DEBUG - 2011-08-15 12:47:17 --> URI Class Initialized
DEBUG - 2011-08-15 12:47:17 --> Router Class Initialized
ERROR - 2011-08-15 12:47:17 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-15 12:47:18 --> Config Class Initialized
DEBUG - 2011-08-15 12:47:18 --> Hooks Class Initialized
DEBUG - 2011-08-15 12:47:18 --> Utf8 Class Initialized
DEBUG - 2011-08-15 12:47:18 --> UTF-8 Support Enabled
DEBUG - 2011-08-15 12:47:18 --> URI Class Initialized
DEBUG - 2011-08-15 12:47:18 --> Router Class Initialized
DEBUG - 2011-08-15 12:47:18 --> Output Class Initialized
DEBUG - 2011-08-15 12:47:18 --> Input Class Initialized
DEBUG - 2011-08-15 12:47:18 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-15 12:47:18 --> Language Class Initialized
DEBUG - 2011-08-15 12:47:18 --> Loader Class Initialized
DEBUG - 2011-08-15 12:47:18 --> Controller Class Initialized
DEBUG - 2011-08-15 12:47:18 --> Model Class Initialized
DEBUG - 2011-08-15 12:47:18 --> Model Class Initialized
DEBUG - 2011-08-15 12:47:18 --> Model Class Initialized
DEBUG - 2011-08-15 12:47:18 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-15 12:47:18 --> Database Driver Class Initialized
DEBUG - 2011-08-15 12:47:18 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-15 12:47:18 --> Helper loaded: url_helper
DEBUG - 2011-08-15 12:47:18 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-15 12:47:18 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-15 12:47:18 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-15 12:47:18 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-15 12:47:18 --> Final output sent to browser
DEBUG - 2011-08-15 12:47:18 --> Total execution time: 0.0633
DEBUG - 2011-08-15 12:50:06 --> Config Class Initialized
DEBUG - 2011-08-15 12:50:06 --> Hooks Class Initialized
DEBUG - 2011-08-15 12:50:06 --> Utf8 Class Initialized
DEBUG - 2011-08-15 12:50:06 --> UTF-8 Support Enabled
DEBUG - 2011-08-15 12:50:06 --> URI Class Initialized
DEBUG - 2011-08-15 12:50:06 --> Router Class Initialized
DEBUG - 2011-08-15 12:50:06 --> Output Class Initialized
DEBUG - 2011-08-15 12:50:06 --> Input Class Initialized
DEBUG - 2011-08-15 12:50:06 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-15 12:50:06 --> Language Class Initialized
DEBUG - 2011-08-15 12:50:06 --> Loader Class Initialized
DEBUG - 2011-08-15 12:50:06 --> Controller Class Initialized
ERROR - 2011-08-15 12:50:06 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-15 12:50:06 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-15 12:50:06 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-15 12:50:06 --> Model Class Initialized
DEBUG - 2011-08-15 12:50:06 --> Model Class Initialized
DEBUG - 2011-08-15 12:50:06 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-15 12:50:06 --> Database Driver Class Initialized
DEBUG - 2011-08-15 12:50:06 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-15 12:50:06 --> Helper loaded: url_helper
DEBUG - 2011-08-15 12:50:06 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-15 12:50:06 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-15 12:50:06 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-15 12:50:06 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-15 12:50:06 --> Final output sent to browser
DEBUG - 2011-08-15 12:50:06 --> Total execution time: 0.0452
DEBUG - 2011-08-15 12:50:07 --> Config Class Initialized
DEBUG - 2011-08-15 12:50:07 --> Hooks Class Initialized
DEBUG - 2011-08-15 12:50:07 --> Utf8 Class Initialized
DEBUG - 2011-08-15 12:50:07 --> UTF-8 Support Enabled
DEBUG - 2011-08-15 12:50:07 --> URI Class Initialized
DEBUG - 2011-08-15 12:50:07 --> Router Class Initialized
DEBUG - 2011-08-15 12:50:07 --> Output Class Initialized
DEBUG - 2011-08-15 12:50:07 --> Input Class Initialized
DEBUG - 2011-08-15 12:50:07 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-15 12:50:07 --> Language Class Initialized
DEBUG - 2011-08-15 12:50:07 --> Loader Class Initialized
DEBUG - 2011-08-15 12:50:07 --> Controller Class Initialized
DEBUG - 2011-08-15 12:50:07 --> Model Class Initialized
DEBUG - 2011-08-15 12:50:07 --> Model Class Initialized
DEBUG - 2011-08-15 12:50:07 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-15 12:50:07 --> Database Driver Class Initialized
DEBUG - 2011-08-15 12:50:08 --> Final output sent to browser
DEBUG - 2011-08-15 12:50:08 --> Total execution time: 0.4604
DEBUG - 2011-08-15 12:50:09 --> Config Class Initialized
DEBUG - 2011-08-15 12:50:09 --> Hooks Class Initialized
DEBUG - 2011-08-15 12:50:09 --> Utf8 Class Initialized
DEBUG - 2011-08-15 12:50:09 --> UTF-8 Support Enabled
DEBUG - 2011-08-15 12:50:09 --> URI Class Initialized
DEBUG - 2011-08-15 12:50:09 --> Router Class Initialized
ERROR - 2011-08-15 12:50:09 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-15 12:50:18 --> Config Class Initialized
DEBUG - 2011-08-15 12:50:18 --> Hooks Class Initialized
DEBUG - 2011-08-15 12:50:18 --> Utf8 Class Initialized
DEBUG - 2011-08-15 12:50:18 --> UTF-8 Support Enabled
DEBUG - 2011-08-15 12:50:18 --> URI Class Initialized
DEBUG - 2011-08-15 12:50:18 --> Router Class Initialized
DEBUG - 2011-08-15 12:50:18 --> Output Class Initialized
DEBUG - 2011-08-15 12:50:18 --> Input Class Initialized
DEBUG - 2011-08-15 12:50:18 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-15 12:50:18 --> Language Class Initialized
DEBUG - 2011-08-15 12:50:18 --> Loader Class Initialized
DEBUG - 2011-08-15 12:50:18 --> Controller Class Initialized
ERROR - 2011-08-15 12:50:18 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-15 12:50:18 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-15 12:50:18 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-15 12:50:18 --> Model Class Initialized
DEBUG - 2011-08-15 12:50:18 --> Model Class Initialized
DEBUG - 2011-08-15 12:50:18 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-15 12:50:18 --> Database Driver Class Initialized
DEBUG - 2011-08-15 12:50:18 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-15 12:50:18 --> Helper loaded: url_helper
DEBUG - 2011-08-15 12:50:18 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-15 12:50:18 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-15 12:50:18 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-15 12:50:18 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-15 12:50:18 --> Final output sent to browser
DEBUG - 2011-08-15 12:50:18 --> Total execution time: 0.0721
DEBUG - 2011-08-15 12:50:19 --> Config Class Initialized
DEBUG - 2011-08-15 12:50:19 --> Hooks Class Initialized
DEBUG - 2011-08-15 12:50:19 --> Utf8 Class Initialized
DEBUG - 2011-08-15 12:50:19 --> UTF-8 Support Enabled
DEBUG - 2011-08-15 12:50:19 --> URI Class Initialized
DEBUG - 2011-08-15 12:50:19 --> Router Class Initialized
DEBUG - 2011-08-15 12:50:19 --> Output Class Initialized
DEBUG - 2011-08-15 12:50:19 --> Input Class Initialized
DEBUG - 2011-08-15 12:50:19 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-15 12:50:19 --> Language Class Initialized
DEBUG - 2011-08-15 12:50:19 --> Loader Class Initialized
DEBUG - 2011-08-15 12:50:19 --> Controller Class Initialized
DEBUG - 2011-08-15 12:50:19 --> Model Class Initialized
DEBUG - 2011-08-15 12:50:19 --> Model Class Initialized
DEBUG - 2011-08-15 12:50:19 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-15 12:50:19 --> Database Driver Class Initialized
DEBUG - 2011-08-15 12:50:20 --> Final output sent to browser
DEBUG - 2011-08-15 12:50:20 --> Total execution time: 0.3983
DEBUG - 2011-08-15 12:50:20 --> Config Class Initialized
DEBUG - 2011-08-15 12:50:20 --> Hooks Class Initialized
DEBUG - 2011-08-15 12:50:20 --> Utf8 Class Initialized
DEBUG - 2011-08-15 12:50:20 --> UTF-8 Support Enabled
DEBUG - 2011-08-15 12:50:20 --> URI Class Initialized
DEBUG - 2011-08-15 12:50:20 --> Router Class Initialized
ERROR - 2011-08-15 12:50:20 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-15 12:50:42 --> Config Class Initialized
DEBUG - 2011-08-15 12:50:42 --> Hooks Class Initialized
DEBUG - 2011-08-15 12:50:42 --> Utf8 Class Initialized
DEBUG - 2011-08-15 12:50:42 --> UTF-8 Support Enabled
DEBUG - 2011-08-15 12:50:42 --> URI Class Initialized
DEBUG - 2011-08-15 12:50:42 --> Router Class Initialized
DEBUG - 2011-08-15 12:50:42 --> Output Class Initialized
DEBUG - 2011-08-15 12:50:42 --> Input Class Initialized
DEBUG - 2011-08-15 12:50:42 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-15 12:50:42 --> Language Class Initialized
DEBUG - 2011-08-15 12:50:42 --> Loader Class Initialized
DEBUG - 2011-08-15 12:50:42 --> Controller Class Initialized
ERROR - 2011-08-15 12:50:42 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-15 12:50:42 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-15 12:50:42 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-15 12:50:42 --> Model Class Initialized
DEBUG - 2011-08-15 12:50:42 --> Model Class Initialized
DEBUG - 2011-08-15 12:50:42 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-15 12:50:42 --> Database Driver Class Initialized
DEBUG - 2011-08-15 12:50:42 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-15 12:50:42 --> Helper loaded: url_helper
DEBUG - 2011-08-15 12:50:42 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-15 12:50:42 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-15 12:50:42 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-15 12:50:42 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-15 12:50:42 --> Final output sent to browser
DEBUG - 2011-08-15 12:50:42 --> Total execution time: 0.0399
DEBUG - 2011-08-15 12:52:44 --> Config Class Initialized
DEBUG - 2011-08-15 12:52:44 --> Hooks Class Initialized
DEBUG - 2011-08-15 12:52:44 --> Utf8 Class Initialized
DEBUG - 2011-08-15 12:52:44 --> UTF-8 Support Enabled
DEBUG - 2011-08-15 12:52:44 --> URI Class Initialized
DEBUG - 2011-08-15 12:52:44 --> Router Class Initialized
DEBUG - 2011-08-15 12:52:44 --> Output Class Initialized
DEBUG - 2011-08-15 12:52:44 --> Input Class Initialized
DEBUG - 2011-08-15 12:52:44 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-15 12:52:44 --> Language Class Initialized
DEBUG - 2011-08-15 12:52:44 --> Loader Class Initialized
DEBUG - 2011-08-15 12:52:44 --> Controller Class Initialized
DEBUG - 2011-08-15 12:52:44 --> Model Class Initialized
DEBUG - 2011-08-15 12:52:44 --> Model Class Initialized
DEBUG - 2011-08-15 12:52:44 --> Model Class Initialized
DEBUG - 2011-08-15 12:52:44 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-15 12:52:44 --> Database Driver Class Initialized
DEBUG - 2011-08-15 12:52:44 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-15 12:52:44 --> Helper loaded: url_helper
DEBUG - 2011-08-15 12:52:44 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-15 12:52:44 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-15 12:52:44 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-15 12:52:44 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-15 12:52:44 --> Final output sent to browser
DEBUG - 2011-08-15 12:52:44 --> Total execution time: 0.0527
DEBUG - 2011-08-15 12:52:47 --> Config Class Initialized
DEBUG - 2011-08-15 12:52:47 --> Hooks Class Initialized
DEBUG - 2011-08-15 12:52:47 --> Utf8 Class Initialized
DEBUG - 2011-08-15 12:52:47 --> UTF-8 Support Enabled
DEBUG - 2011-08-15 12:52:47 --> URI Class Initialized
DEBUG - 2011-08-15 12:52:47 --> Router Class Initialized
ERROR - 2011-08-15 12:52:47 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-15 13:30:32 --> Config Class Initialized
DEBUG - 2011-08-15 13:30:32 --> Hooks Class Initialized
DEBUG - 2011-08-15 13:30:32 --> Utf8 Class Initialized
DEBUG - 2011-08-15 13:30:32 --> UTF-8 Support Enabled
DEBUG - 2011-08-15 13:30:32 --> URI Class Initialized
DEBUG - 2011-08-15 13:30:32 --> Router Class Initialized
ERROR - 2011-08-15 13:30:32 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-08-15 14:31:49 --> Config Class Initialized
DEBUG - 2011-08-15 14:31:49 --> Hooks Class Initialized
DEBUG - 2011-08-15 14:31:49 --> Utf8 Class Initialized
DEBUG - 2011-08-15 14:31:49 --> UTF-8 Support Enabled
DEBUG - 2011-08-15 14:31:49 --> URI Class Initialized
DEBUG - 2011-08-15 14:31:49 --> Router Class Initialized
DEBUG - 2011-08-15 14:31:49 --> No URI present. Default controller set.
DEBUG - 2011-08-15 14:31:49 --> Output Class Initialized
DEBUG - 2011-08-15 14:31:49 --> Input Class Initialized
DEBUG - 2011-08-15 14:31:49 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-15 14:31:49 --> Language Class Initialized
DEBUG - 2011-08-15 14:31:49 --> Loader Class Initialized
DEBUG - 2011-08-15 14:31:49 --> Controller Class Initialized
DEBUG - 2011-08-15 14:31:49 --> File loaded: application/views/splash/main.php
DEBUG - 2011-08-15 14:31:49 --> Helper loaded: url_helper
DEBUG - 2011-08-15 14:31:49 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-15 14:31:49 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-15 14:31:49 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-15 14:31:49 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-15 14:31:49 --> Final output sent to browser
DEBUG - 2011-08-15 14:31:49 --> Total execution time: 0.2695
DEBUG - 2011-08-15 15:19:30 --> Config Class Initialized
DEBUG - 2011-08-15 15:19:30 --> Hooks Class Initialized
DEBUG - 2011-08-15 15:19:30 --> Utf8 Class Initialized
DEBUG - 2011-08-15 15:19:30 --> UTF-8 Support Enabled
DEBUG - 2011-08-15 15:19:30 --> URI Class Initialized
DEBUG - 2011-08-15 15:19:30 --> Router Class Initialized
DEBUG - 2011-08-15 15:19:30 --> Output Class Initialized
DEBUG - 2011-08-15 15:19:30 --> Input Class Initialized
DEBUG - 2011-08-15 15:19:30 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-15 15:19:30 --> Language Class Initialized
DEBUG - 2011-08-15 15:19:30 --> Loader Class Initialized
DEBUG - 2011-08-15 15:19:30 --> Controller Class Initialized
DEBUG - 2011-08-15 15:19:30 --> Model Class Initialized
DEBUG - 2011-08-15 15:19:30 --> Model Class Initialized
DEBUG - 2011-08-15 15:19:30 --> Model Class Initialized
DEBUG - 2011-08-15 15:19:30 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-15 15:19:30 --> Database Driver Class Initialized
DEBUG - 2011-08-15 15:19:31 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-15 15:19:31 --> Helper loaded: url_helper
DEBUG - 2011-08-15 15:19:31 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-15 15:19:31 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-15 15:19:31 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-15 15:19:31 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-15 15:19:31 --> Final output sent to browser
DEBUG - 2011-08-15 15:19:31 --> Total execution time: 0.4909
DEBUG - 2011-08-15 15:19:32 --> Config Class Initialized
DEBUG - 2011-08-15 15:19:32 --> Hooks Class Initialized
DEBUG - 2011-08-15 15:19:32 --> Utf8 Class Initialized
DEBUG - 2011-08-15 15:19:32 --> UTF-8 Support Enabled
DEBUG - 2011-08-15 15:19:32 --> URI Class Initialized
DEBUG - 2011-08-15 15:19:32 --> Router Class Initialized
ERROR - 2011-08-15 15:19:32 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-15 15:32:58 --> Config Class Initialized
DEBUG - 2011-08-15 15:32:58 --> Hooks Class Initialized
DEBUG - 2011-08-15 15:32:58 --> Utf8 Class Initialized
DEBUG - 2011-08-15 15:32:58 --> UTF-8 Support Enabled
DEBUG - 2011-08-15 15:32:58 --> URI Class Initialized
DEBUG - 2011-08-15 15:32:58 --> Router Class Initialized
DEBUG - 2011-08-15 15:32:58 --> Output Class Initialized
DEBUG - 2011-08-15 15:32:58 --> Input Class Initialized
DEBUG - 2011-08-15 15:32:58 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-15 15:32:58 --> Language Class Initialized
DEBUG - 2011-08-15 15:32:58 --> Loader Class Initialized
DEBUG - 2011-08-15 15:32:58 --> Controller Class Initialized
ERROR - 2011-08-15 15:32:58 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-15 15:32:58 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-15 15:32:58 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-15 15:32:58 --> Model Class Initialized
DEBUG - 2011-08-15 15:32:58 --> Model Class Initialized
DEBUG - 2011-08-15 15:32:58 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-15 15:32:58 --> Database Driver Class Initialized
DEBUG - 2011-08-15 15:32:58 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-15 15:32:58 --> Helper loaded: url_helper
DEBUG - 2011-08-15 15:32:58 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-15 15:32:58 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-15 15:32:58 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-15 15:32:58 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-15 15:32:58 --> Final output sent to browser
DEBUG - 2011-08-15 15:32:58 --> Total execution time: 0.1169
DEBUG - 2011-08-15 15:44:16 --> Config Class Initialized
DEBUG - 2011-08-15 15:44:16 --> Hooks Class Initialized
DEBUG - 2011-08-15 15:44:16 --> Utf8 Class Initialized
DEBUG - 2011-08-15 15:44:16 --> UTF-8 Support Enabled
DEBUG - 2011-08-15 15:44:16 --> URI Class Initialized
DEBUG - 2011-08-15 15:44:16 --> Router Class Initialized
ERROR - 2011-08-15 15:44:16 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-08-15 16:27:27 --> Config Class Initialized
DEBUG - 2011-08-15 16:27:27 --> Hooks Class Initialized
DEBUG - 2011-08-15 16:27:27 --> Utf8 Class Initialized
DEBUG - 2011-08-15 16:27:27 --> UTF-8 Support Enabled
DEBUG - 2011-08-15 16:27:27 --> URI Class Initialized
DEBUG - 2011-08-15 16:27:27 --> Router Class Initialized
DEBUG - 2011-08-15 16:27:27 --> Output Class Initialized
DEBUG - 2011-08-15 16:27:27 --> Input Class Initialized
DEBUG - 2011-08-15 16:27:27 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-15 16:27:27 --> Language Class Initialized
DEBUG - 2011-08-15 16:27:27 --> Loader Class Initialized
DEBUG - 2011-08-15 16:27:27 --> Controller Class Initialized
ERROR - 2011-08-15 16:27:27 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-15 16:27:27 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-15 16:27:27 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-15 16:27:27 --> Model Class Initialized
DEBUG - 2011-08-15 16:27:27 --> Model Class Initialized
DEBUG - 2011-08-15 16:27:27 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-15 16:27:27 --> Database Driver Class Initialized
DEBUG - 2011-08-15 16:27:27 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-15 16:27:27 --> Helper loaded: url_helper
DEBUG - 2011-08-15 16:27:27 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-15 16:27:27 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-15 16:27:27 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-15 16:27:27 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-15 16:27:27 --> Final output sent to browser
DEBUG - 2011-08-15 16:27:27 --> Total execution time: 0.2936
DEBUG - 2011-08-15 16:27:28 --> Config Class Initialized
DEBUG - 2011-08-15 16:27:28 --> Hooks Class Initialized
DEBUG - 2011-08-15 16:27:28 --> Utf8 Class Initialized
DEBUG - 2011-08-15 16:27:28 --> UTF-8 Support Enabled
DEBUG - 2011-08-15 16:27:28 --> URI Class Initialized
DEBUG - 2011-08-15 16:27:28 --> Router Class Initialized
DEBUG - 2011-08-15 16:27:28 --> Output Class Initialized
DEBUG - 2011-08-15 16:27:28 --> Input Class Initialized
DEBUG - 2011-08-15 16:27:28 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-15 16:27:28 --> Language Class Initialized
DEBUG - 2011-08-15 16:27:28 --> Loader Class Initialized
DEBUG - 2011-08-15 16:27:28 --> Controller Class Initialized
DEBUG - 2011-08-15 16:27:29 --> Model Class Initialized
DEBUG - 2011-08-15 16:27:29 --> Model Class Initialized
DEBUG - 2011-08-15 16:27:29 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-15 16:27:29 --> Database Driver Class Initialized
DEBUG - 2011-08-15 16:27:29 --> Final output sent to browser
DEBUG - 2011-08-15 16:27:29 --> Total execution time: 0.7329
DEBUG - 2011-08-15 16:27:30 --> Config Class Initialized
DEBUG - 2011-08-15 16:27:30 --> Hooks Class Initialized
DEBUG - 2011-08-15 16:27:30 --> Utf8 Class Initialized
DEBUG - 2011-08-15 16:27:30 --> UTF-8 Support Enabled
DEBUG - 2011-08-15 16:27:30 --> URI Class Initialized
DEBUG - 2011-08-15 16:27:30 --> Router Class Initialized
ERROR - 2011-08-15 16:27:30 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-15 16:27:52 --> Config Class Initialized
DEBUG - 2011-08-15 16:27:52 --> Hooks Class Initialized
DEBUG - 2011-08-15 16:27:52 --> Utf8 Class Initialized
DEBUG - 2011-08-15 16:27:52 --> UTF-8 Support Enabled
DEBUG - 2011-08-15 16:27:52 --> URI Class Initialized
DEBUG - 2011-08-15 16:27:52 --> Router Class Initialized
DEBUG - 2011-08-15 16:27:52 --> Output Class Initialized
DEBUG - 2011-08-15 16:27:52 --> Input Class Initialized
DEBUG - 2011-08-15 16:27:52 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-15 16:27:52 --> Language Class Initialized
DEBUG - 2011-08-15 16:27:52 --> Loader Class Initialized
DEBUG - 2011-08-15 16:27:52 --> Controller Class Initialized
ERROR - 2011-08-15 16:27:52 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-15 16:27:52 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-15 16:27:52 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-15 16:27:52 --> Model Class Initialized
DEBUG - 2011-08-15 16:27:52 --> Model Class Initialized
DEBUG - 2011-08-15 16:27:52 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-15 16:27:52 --> Database Driver Class Initialized
DEBUG - 2011-08-15 16:27:52 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-15 16:27:52 --> Helper loaded: url_helper
DEBUG - 2011-08-15 16:27:52 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-15 16:27:52 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-15 16:27:52 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-15 16:27:52 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-15 16:27:52 --> Final output sent to browser
DEBUG - 2011-08-15 16:27:52 --> Total execution time: 0.0284
DEBUG - 2011-08-15 16:27:52 --> Config Class Initialized
DEBUG - 2011-08-15 16:27:52 --> Hooks Class Initialized
DEBUG - 2011-08-15 16:27:52 --> Utf8 Class Initialized
DEBUG - 2011-08-15 16:27:52 --> UTF-8 Support Enabled
DEBUG - 2011-08-15 16:27:52 --> URI Class Initialized
DEBUG - 2011-08-15 16:27:52 --> Router Class Initialized
DEBUG - 2011-08-15 16:27:52 --> Output Class Initialized
DEBUG - 2011-08-15 16:27:52 --> Input Class Initialized
DEBUG - 2011-08-15 16:27:52 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-15 16:27:52 --> Language Class Initialized
DEBUG - 2011-08-15 16:27:52 --> Loader Class Initialized
DEBUG - 2011-08-15 16:27:52 --> Controller Class Initialized
DEBUG - 2011-08-15 16:27:52 --> Model Class Initialized
DEBUG - 2011-08-15 16:27:52 --> Model Class Initialized
DEBUG - 2011-08-15 16:27:52 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-15 16:27:52 --> Database Driver Class Initialized
DEBUG - 2011-08-15 16:27:53 --> Final output sent to browser
DEBUG - 2011-08-15 16:27:53 --> Total execution time: 0.5885
DEBUG - 2011-08-15 16:28:02 --> Config Class Initialized
DEBUG - 2011-08-15 16:28:02 --> Hooks Class Initialized
DEBUG - 2011-08-15 16:28:02 --> Utf8 Class Initialized
DEBUG - 2011-08-15 16:28:02 --> UTF-8 Support Enabled
DEBUG - 2011-08-15 16:28:02 --> URI Class Initialized
DEBUG - 2011-08-15 16:28:02 --> Router Class Initialized
DEBUG - 2011-08-15 16:28:02 --> Output Class Initialized
DEBUG - 2011-08-15 16:28:02 --> Input Class Initialized
DEBUG - 2011-08-15 16:28:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-15 16:28:02 --> Language Class Initialized
DEBUG - 2011-08-15 16:28:02 --> Loader Class Initialized
DEBUG - 2011-08-15 16:28:02 --> Controller Class Initialized
ERROR - 2011-08-15 16:28:02 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-15 16:28:02 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-15 16:28:02 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-15 16:28:02 --> Model Class Initialized
DEBUG - 2011-08-15 16:28:02 --> Model Class Initialized
DEBUG - 2011-08-15 16:28:02 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-15 16:28:02 --> Database Driver Class Initialized
DEBUG - 2011-08-15 16:28:02 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-15 16:28:02 --> Helper loaded: url_helper
DEBUG - 2011-08-15 16:28:02 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-15 16:28:02 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-15 16:28:02 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-15 16:28:02 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-15 16:28:02 --> Final output sent to browser
DEBUG - 2011-08-15 16:28:02 --> Total execution time: 0.0309
DEBUG - 2011-08-15 16:28:03 --> Config Class Initialized
DEBUG - 2011-08-15 16:28:03 --> Hooks Class Initialized
DEBUG - 2011-08-15 16:28:03 --> Utf8 Class Initialized
DEBUG - 2011-08-15 16:28:03 --> UTF-8 Support Enabled
DEBUG - 2011-08-15 16:28:03 --> URI Class Initialized
DEBUG - 2011-08-15 16:28:03 --> Router Class Initialized
DEBUG - 2011-08-15 16:28:03 --> Output Class Initialized
DEBUG - 2011-08-15 16:28:03 --> Input Class Initialized
DEBUG - 2011-08-15 16:28:03 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-15 16:28:03 --> Language Class Initialized
DEBUG - 2011-08-15 16:28:03 --> Loader Class Initialized
DEBUG - 2011-08-15 16:28:03 --> Controller Class Initialized
DEBUG - 2011-08-15 16:28:03 --> Model Class Initialized
DEBUG - 2011-08-15 16:28:03 --> Model Class Initialized
DEBUG - 2011-08-15 16:28:03 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-15 16:28:03 --> Database Driver Class Initialized
DEBUG - 2011-08-15 16:28:03 --> Final output sent to browser
DEBUG - 2011-08-15 16:28:03 --> Total execution time: 0.5646
DEBUG - 2011-08-15 16:28:10 --> Config Class Initialized
DEBUG - 2011-08-15 16:28:10 --> Hooks Class Initialized
DEBUG - 2011-08-15 16:28:10 --> Utf8 Class Initialized
DEBUG - 2011-08-15 16:28:10 --> UTF-8 Support Enabled
DEBUG - 2011-08-15 16:28:10 --> URI Class Initialized
DEBUG - 2011-08-15 16:28:10 --> Router Class Initialized
DEBUG - 2011-08-15 16:28:10 --> Output Class Initialized
DEBUG - 2011-08-15 16:28:10 --> Input Class Initialized
DEBUG - 2011-08-15 16:28:10 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-15 16:28:10 --> Language Class Initialized
DEBUG - 2011-08-15 16:28:10 --> Loader Class Initialized
DEBUG - 2011-08-15 16:28:10 --> Controller Class Initialized
ERROR - 2011-08-15 16:28:10 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-15 16:28:10 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-15 16:28:10 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-15 16:28:10 --> Model Class Initialized
DEBUG - 2011-08-15 16:28:10 --> Model Class Initialized
DEBUG - 2011-08-15 16:28:10 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-15 16:28:10 --> Database Driver Class Initialized
DEBUG - 2011-08-15 16:28:10 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-15 16:28:10 --> Helper loaded: url_helper
DEBUG - 2011-08-15 16:28:10 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-15 16:28:10 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-15 16:28:10 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-15 16:28:10 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-15 16:28:10 --> Final output sent to browser
DEBUG - 2011-08-15 16:28:10 --> Total execution time: 0.0418
DEBUG - 2011-08-15 16:28:11 --> Config Class Initialized
DEBUG - 2011-08-15 16:28:11 --> Hooks Class Initialized
DEBUG - 2011-08-15 16:28:11 --> Utf8 Class Initialized
DEBUG - 2011-08-15 16:28:11 --> UTF-8 Support Enabled
DEBUG - 2011-08-15 16:28:11 --> URI Class Initialized
DEBUG - 2011-08-15 16:28:11 --> Router Class Initialized
DEBUG - 2011-08-15 16:28:11 --> Output Class Initialized
DEBUG - 2011-08-15 16:28:11 --> Input Class Initialized
DEBUG - 2011-08-15 16:28:11 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-15 16:28:11 --> Language Class Initialized
DEBUG - 2011-08-15 16:28:11 --> Loader Class Initialized
DEBUG - 2011-08-15 16:28:11 --> Controller Class Initialized
DEBUG - 2011-08-15 16:28:11 --> Model Class Initialized
DEBUG - 2011-08-15 16:28:11 --> Model Class Initialized
DEBUG - 2011-08-15 16:28:11 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-15 16:28:11 --> Database Driver Class Initialized
DEBUG - 2011-08-15 16:28:16 --> Final output sent to browser
DEBUG - 2011-08-15 16:28:16 --> Total execution time: 5.7976
DEBUG - 2011-08-15 16:28:27 --> Config Class Initialized
DEBUG - 2011-08-15 16:28:27 --> Hooks Class Initialized
DEBUG - 2011-08-15 16:28:27 --> Utf8 Class Initialized
DEBUG - 2011-08-15 16:28:27 --> UTF-8 Support Enabled
DEBUG - 2011-08-15 16:28:27 --> URI Class Initialized
DEBUG - 2011-08-15 16:28:27 --> Router Class Initialized
DEBUG - 2011-08-15 16:28:27 --> Output Class Initialized
DEBUG - 2011-08-15 16:28:27 --> Input Class Initialized
DEBUG - 2011-08-15 16:28:27 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-15 16:28:27 --> Language Class Initialized
DEBUG - 2011-08-15 16:28:27 --> Loader Class Initialized
DEBUG - 2011-08-15 16:28:27 --> Controller Class Initialized
ERROR - 2011-08-15 16:28:27 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-15 16:28:27 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-15 16:28:27 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-15 16:28:27 --> Model Class Initialized
DEBUG - 2011-08-15 16:28:27 --> Model Class Initialized
DEBUG - 2011-08-15 16:28:27 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-15 16:28:27 --> Database Driver Class Initialized
DEBUG - 2011-08-15 16:28:27 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-15 16:28:27 --> Helper loaded: url_helper
DEBUG - 2011-08-15 16:28:27 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-15 16:28:27 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-15 16:28:27 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-15 16:28:27 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-15 16:28:27 --> Final output sent to browser
DEBUG - 2011-08-15 16:28:27 --> Total execution time: 0.0273
DEBUG - 2011-08-15 16:28:28 --> Config Class Initialized
DEBUG - 2011-08-15 16:28:28 --> Hooks Class Initialized
DEBUG - 2011-08-15 16:28:28 --> Utf8 Class Initialized
DEBUG - 2011-08-15 16:28:28 --> UTF-8 Support Enabled
DEBUG - 2011-08-15 16:28:28 --> URI Class Initialized
DEBUG - 2011-08-15 16:28:28 --> Router Class Initialized
DEBUG - 2011-08-15 16:28:28 --> Output Class Initialized
DEBUG - 2011-08-15 16:28:28 --> Input Class Initialized
DEBUG - 2011-08-15 16:28:28 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-15 16:28:28 --> Language Class Initialized
DEBUG - 2011-08-15 16:28:28 --> Loader Class Initialized
DEBUG - 2011-08-15 16:28:28 --> Controller Class Initialized
DEBUG - 2011-08-15 16:28:28 --> Model Class Initialized
DEBUG - 2011-08-15 16:28:28 --> Model Class Initialized
DEBUG - 2011-08-15 16:28:28 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-15 16:28:28 --> Database Driver Class Initialized
DEBUG - 2011-08-15 16:28:28 --> Final output sent to browser
DEBUG - 2011-08-15 16:28:28 --> Total execution time: 0.5088
DEBUG - 2011-08-15 16:28:34 --> Config Class Initialized
DEBUG - 2011-08-15 16:28:34 --> Hooks Class Initialized
DEBUG - 2011-08-15 16:28:34 --> Utf8 Class Initialized
DEBUG - 2011-08-15 16:28:34 --> UTF-8 Support Enabled
DEBUG - 2011-08-15 16:28:34 --> URI Class Initialized
DEBUG - 2011-08-15 16:28:34 --> Router Class Initialized
DEBUG - 2011-08-15 16:28:34 --> Output Class Initialized
DEBUG - 2011-08-15 16:28:34 --> Input Class Initialized
DEBUG - 2011-08-15 16:28:34 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-15 16:28:34 --> Language Class Initialized
DEBUG - 2011-08-15 16:28:34 --> Loader Class Initialized
DEBUG - 2011-08-15 16:28:34 --> Controller Class Initialized
ERROR - 2011-08-15 16:28:34 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-15 16:28:34 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-15 16:28:34 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-15 16:28:34 --> Model Class Initialized
DEBUG - 2011-08-15 16:28:34 --> Model Class Initialized
DEBUG - 2011-08-15 16:28:34 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-15 16:28:34 --> Database Driver Class Initialized
DEBUG - 2011-08-15 16:28:34 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-15 16:28:34 --> Helper loaded: url_helper
DEBUG - 2011-08-15 16:28:34 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-15 16:28:34 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-15 16:28:34 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-15 16:28:34 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-15 16:28:34 --> Final output sent to browser
DEBUG - 2011-08-15 16:28:34 --> Total execution time: 0.0715
DEBUG - 2011-08-15 16:28:35 --> Config Class Initialized
DEBUG - 2011-08-15 16:28:35 --> Hooks Class Initialized
DEBUG - 2011-08-15 16:28:35 --> Utf8 Class Initialized
DEBUG - 2011-08-15 16:28:35 --> UTF-8 Support Enabled
DEBUG - 2011-08-15 16:28:35 --> URI Class Initialized
DEBUG - 2011-08-15 16:28:35 --> Router Class Initialized
DEBUG - 2011-08-15 16:28:35 --> Output Class Initialized
DEBUG - 2011-08-15 16:28:35 --> Input Class Initialized
DEBUG - 2011-08-15 16:28:35 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-15 16:28:35 --> Language Class Initialized
DEBUG - 2011-08-15 16:28:35 --> Loader Class Initialized
DEBUG - 2011-08-15 16:28:35 --> Controller Class Initialized
DEBUG - 2011-08-15 16:28:35 --> Model Class Initialized
DEBUG - 2011-08-15 16:28:35 --> Model Class Initialized
DEBUG - 2011-08-15 16:28:35 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-15 16:28:35 --> Database Driver Class Initialized
DEBUG - 2011-08-15 16:28:35 --> Final output sent to browser
DEBUG - 2011-08-15 16:28:35 --> Total execution time: 0.7553
DEBUG - 2011-08-15 16:28:45 --> Config Class Initialized
DEBUG - 2011-08-15 16:28:45 --> Hooks Class Initialized
DEBUG - 2011-08-15 16:28:45 --> Utf8 Class Initialized
DEBUG - 2011-08-15 16:28:45 --> UTF-8 Support Enabled
DEBUG - 2011-08-15 16:28:45 --> URI Class Initialized
DEBUG - 2011-08-15 16:28:45 --> Router Class Initialized
DEBUG - 2011-08-15 16:28:45 --> Output Class Initialized
DEBUG - 2011-08-15 16:28:45 --> Input Class Initialized
DEBUG - 2011-08-15 16:28:45 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-15 16:28:45 --> Language Class Initialized
DEBUG - 2011-08-15 16:28:45 --> Loader Class Initialized
DEBUG - 2011-08-15 16:28:45 --> Controller Class Initialized
ERROR - 2011-08-15 16:28:45 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-15 16:28:45 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-15 16:28:45 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-15 16:28:45 --> Model Class Initialized
DEBUG - 2011-08-15 16:28:45 --> Model Class Initialized
DEBUG - 2011-08-15 16:28:45 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-15 16:28:45 --> Database Driver Class Initialized
DEBUG - 2011-08-15 16:28:45 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-15 16:28:45 --> Helper loaded: url_helper
DEBUG - 2011-08-15 16:28:45 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-15 16:28:45 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-15 16:28:45 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-15 16:28:45 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-15 16:28:45 --> Final output sent to browser
DEBUG - 2011-08-15 16:28:45 --> Total execution time: 0.0297
DEBUG - 2011-08-15 16:28:45 --> Config Class Initialized
DEBUG - 2011-08-15 16:28:45 --> Hooks Class Initialized
DEBUG - 2011-08-15 16:28:45 --> Utf8 Class Initialized
DEBUG - 2011-08-15 16:28:45 --> UTF-8 Support Enabled
DEBUG - 2011-08-15 16:28:45 --> URI Class Initialized
DEBUG - 2011-08-15 16:28:45 --> Router Class Initialized
DEBUG - 2011-08-15 16:28:45 --> Output Class Initialized
DEBUG - 2011-08-15 16:28:45 --> Input Class Initialized
DEBUG - 2011-08-15 16:28:45 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-15 16:28:45 --> Language Class Initialized
DEBUG - 2011-08-15 16:28:45 --> Loader Class Initialized
DEBUG - 2011-08-15 16:28:45 --> Controller Class Initialized
DEBUG - 2011-08-15 16:28:45 --> Model Class Initialized
DEBUG - 2011-08-15 16:28:45 --> Model Class Initialized
DEBUG - 2011-08-15 16:28:45 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-15 16:28:45 --> Database Driver Class Initialized
DEBUG - 2011-08-15 16:28:46 --> Final output sent to browser
DEBUG - 2011-08-15 16:28:46 --> Total execution time: 0.7231
DEBUG - 2011-08-15 16:28:59 --> Config Class Initialized
DEBUG - 2011-08-15 16:28:59 --> Hooks Class Initialized
DEBUG - 2011-08-15 16:28:59 --> Utf8 Class Initialized
DEBUG - 2011-08-15 16:28:59 --> UTF-8 Support Enabled
DEBUG - 2011-08-15 16:28:59 --> URI Class Initialized
DEBUG - 2011-08-15 16:28:59 --> Router Class Initialized
DEBUG - 2011-08-15 16:28:59 --> Output Class Initialized
DEBUG - 2011-08-15 16:28:59 --> Input Class Initialized
DEBUG - 2011-08-15 16:28:59 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-15 16:28:59 --> Language Class Initialized
DEBUG - 2011-08-15 16:28:59 --> Loader Class Initialized
DEBUG - 2011-08-15 16:28:59 --> Controller Class Initialized
ERROR - 2011-08-15 16:28:59 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-15 16:28:59 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-15 16:28:59 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-15 16:28:59 --> Model Class Initialized
DEBUG - 2011-08-15 16:28:59 --> Model Class Initialized
DEBUG - 2011-08-15 16:28:59 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-15 16:28:59 --> Database Driver Class Initialized
DEBUG - 2011-08-15 16:28:59 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-15 16:28:59 --> Helper loaded: url_helper
DEBUG - 2011-08-15 16:28:59 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-15 16:28:59 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-15 16:28:59 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-15 16:28:59 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-15 16:28:59 --> Final output sent to browser
DEBUG - 2011-08-15 16:28:59 --> Total execution time: 0.0279
DEBUG - 2011-08-15 16:29:00 --> Config Class Initialized
DEBUG - 2011-08-15 16:29:00 --> Hooks Class Initialized
DEBUG - 2011-08-15 16:29:00 --> Utf8 Class Initialized
DEBUG - 2011-08-15 16:29:00 --> UTF-8 Support Enabled
DEBUG - 2011-08-15 16:29:00 --> URI Class Initialized
DEBUG - 2011-08-15 16:29:00 --> Router Class Initialized
DEBUG - 2011-08-15 16:29:00 --> Output Class Initialized
DEBUG - 2011-08-15 16:29:00 --> Input Class Initialized
DEBUG - 2011-08-15 16:29:00 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-15 16:29:00 --> Language Class Initialized
DEBUG - 2011-08-15 16:29:00 --> Loader Class Initialized
DEBUG - 2011-08-15 16:29:00 --> Controller Class Initialized
DEBUG - 2011-08-15 16:29:00 --> Model Class Initialized
DEBUG - 2011-08-15 16:29:00 --> Model Class Initialized
DEBUG - 2011-08-15 16:29:00 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-15 16:29:00 --> Database Driver Class Initialized
DEBUG - 2011-08-15 16:29:00 --> Final output sent to browser
DEBUG - 2011-08-15 16:29:00 --> Total execution time: 0.5500
DEBUG - 2011-08-15 16:29:08 --> Config Class Initialized
DEBUG - 2011-08-15 16:29:08 --> Hooks Class Initialized
DEBUG - 2011-08-15 16:29:08 --> Utf8 Class Initialized
DEBUG - 2011-08-15 16:29:08 --> UTF-8 Support Enabled
DEBUG - 2011-08-15 16:29:08 --> URI Class Initialized
DEBUG - 2011-08-15 16:29:08 --> Router Class Initialized
DEBUG - 2011-08-15 16:29:08 --> Output Class Initialized
DEBUG - 2011-08-15 16:29:08 --> Input Class Initialized
DEBUG - 2011-08-15 16:29:08 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-15 16:29:08 --> Language Class Initialized
DEBUG - 2011-08-15 16:29:08 --> Loader Class Initialized
DEBUG - 2011-08-15 16:29:08 --> Controller Class Initialized
ERROR - 2011-08-15 16:29:08 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-15 16:29:08 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-15 16:29:08 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-15 16:29:08 --> Model Class Initialized
DEBUG - 2011-08-15 16:29:08 --> Model Class Initialized
DEBUG - 2011-08-15 16:29:08 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-15 16:29:08 --> Database Driver Class Initialized
DEBUG - 2011-08-15 16:29:08 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-15 16:29:08 --> Helper loaded: url_helper
DEBUG - 2011-08-15 16:29:08 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-15 16:29:08 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-15 16:29:08 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-15 16:29:08 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-15 16:29:08 --> Final output sent to browser
DEBUG - 2011-08-15 16:29:08 --> Total execution time: 0.0304
DEBUG - 2011-08-15 16:29:08 --> Config Class Initialized
DEBUG - 2011-08-15 16:29:08 --> Hooks Class Initialized
DEBUG - 2011-08-15 16:29:08 --> Utf8 Class Initialized
DEBUG - 2011-08-15 16:29:08 --> UTF-8 Support Enabled
DEBUG - 2011-08-15 16:29:08 --> URI Class Initialized
DEBUG - 2011-08-15 16:29:08 --> Router Class Initialized
DEBUG - 2011-08-15 16:29:08 --> Output Class Initialized
DEBUG - 2011-08-15 16:29:08 --> Input Class Initialized
DEBUG - 2011-08-15 16:29:08 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-15 16:29:08 --> Language Class Initialized
DEBUG - 2011-08-15 16:29:08 --> Loader Class Initialized
DEBUG - 2011-08-15 16:29:08 --> Controller Class Initialized
DEBUG - 2011-08-15 16:29:08 --> Model Class Initialized
DEBUG - 2011-08-15 16:29:08 --> Model Class Initialized
DEBUG - 2011-08-15 16:29:08 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-15 16:29:08 --> Database Driver Class Initialized
DEBUG - 2011-08-15 16:29:09 --> Final output sent to browser
DEBUG - 2011-08-15 16:29:09 --> Total execution time: 0.5072
DEBUG - 2011-08-15 16:39:46 --> Config Class Initialized
DEBUG - 2011-08-15 16:39:46 --> Hooks Class Initialized
DEBUG - 2011-08-15 16:39:46 --> Utf8 Class Initialized
DEBUG - 2011-08-15 16:39:46 --> UTF-8 Support Enabled
DEBUG - 2011-08-15 16:39:46 --> URI Class Initialized
DEBUG - 2011-08-15 16:39:46 --> Router Class Initialized
DEBUG - 2011-08-15 16:39:46 --> Output Class Initialized
DEBUG - 2011-08-15 16:39:46 --> Input Class Initialized
DEBUG - 2011-08-15 16:39:46 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-15 16:39:46 --> Language Class Initialized
DEBUG - 2011-08-15 16:39:46 --> Loader Class Initialized
DEBUG - 2011-08-15 16:39:46 --> Controller Class Initialized
ERROR - 2011-08-15 16:39:46 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-15 16:39:46 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-15 16:39:46 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-15 16:39:46 --> Model Class Initialized
DEBUG - 2011-08-15 16:39:46 --> Model Class Initialized
DEBUG - 2011-08-15 16:39:46 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-15 16:39:46 --> Database Driver Class Initialized
DEBUG - 2011-08-15 16:39:46 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-15 16:39:46 --> Helper loaded: url_helper
DEBUG - 2011-08-15 16:39:46 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-15 16:39:46 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-15 16:39:46 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-15 16:39:46 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-15 16:39:46 --> Final output sent to browser
DEBUG - 2011-08-15 16:39:46 --> Total execution time: 0.0573
DEBUG - 2011-08-15 16:39:48 --> Config Class Initialized
DEBUG - 2011-08-15 16:39:48 --> Hooks Class Initialized
DEBUG - 2011-08-15 16:39:48 --> Utf8 Class Initialized
DEBUG - 2011-08-15 16:39:48 --> UTF-8 Support Enabled
DEBUG - 2011-08-15 16:39:48 --> URI Class Initialized
DEBUG - 2011-08-15 16:39:48 --> Router Class Initialized
DEBUG - 2011-08-15 16:39:48 --> Output Class Initialized
DEBUG - 2011-08-15 16:39:48 --> Input Class Initialized
DEBUG - 2011-08-15 16:39:48 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-15 16:39:48 --> Language Class Initialized
DEBUG - 2011-08-15 16:39:48 --> Loader Class Initialized
DEBUG - 2011-08-15 16:39:48 --> Controller Class Initialized
DEBUG - 2011-08-15 16:39:48 --> Model Class Initialized
DEBUG - 2011-08-15 16:39:48 --> Model Class Initialized
DEBUG - 2011-08-15 16:39:48 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-15 16:39:48 --> Database Driver Class Initialized
DEBUG - 2011-08-15 16:39:49 --> Final output sent to browser
DEBUG - 2011-08-15 16:39:49 --> Total execution time: 0.5390
DEBUG - 2011-08-15 17:45:59 --> Config Class Initialized
DEBUG - 2011-08-15 17:45:59 --> Hooks Class Initialized
DEBUG - 2011-08-15 17:45:59 --> Utf8 Class Initialized
DEBUG - 2011-08-15 17:45:59 --> UTF-8 Support Enabled
DEBUG - 2011-08-15 17:45:59 --> URI Class Initialized
DEBUG - 2011-08-15 17:45:59 --> Router Class Initialized
DEBUG - 2011-08-15 17:45:59 --> Output Class Initialized
DEBUG - 2011-08-15 17:45:59 --> Input Class Initialized
DEBUG - 2011-08-15 17:45:59 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-15 17:45:59 --> Language Class Initialized
DEBUG - 2011-08-15 17:45:59 --> Loader Class Initialized
DEBUG - 2011-08-15 17:45:59 --> Controller Class Initialized
DEBUG - 2011-08-15 17:45:59 --> Model Class Initialized
DEBUG - 2011-08-15 17:45:59 --> Model Class Initialized
DEBUG - 2011-08-15 17:45:59 --> Model Class Initialized
DEBUG - 2011-08-15 17:45:59 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-15 17:45:59 --> Database Driver Class Initialized
DEBUG - 2011-08-15 17:46:00 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-15 17:46:00 --> Helper loaded: url_helper
DEBUG - 2011-08-15 17:46:00 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-15 17:46:00 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-15 17:46:00 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-15 17:46:00 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-15 17:46:00 --> Final output sent to browser
DEBUG - 2011-08-15 17:46:00 --> Total execution time: 0.3010
DEBUG - 2011-08-15 17:46:02 --> Config Class Initialized
DEBUG - 2011-08-15 17:46:02 --> Hooks Class Initialized
DEBUG - 2011-08-15 17:46:02 --> Utf8 Class Initialized
DEBUG - 2011-08-15 17:46:02 --> UTF-8 Support Enabled
DEBUG - 2011-08-15 17:46:02 --> URI Class Initialized
DEBUG - 2011-08-15 17:46:02 --> Router Class Initialized
ERROR - 2011-08-15 17:46:02 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-15 18:04:24 --> Config Class Initialized
DEBUG - 2011-08-15 18:04:24 --> Hooks Class Initialized
DEBUG - 2011-08-15 18:04:24 --> Utf8 Class Initialized
DEBUG - 2011-08-15 18:04:24 --> UTF-8 Support Enabled
DEBUG - 2011-08-15 18:04:24 --> URI Class Initialized
DEBUG - 2011-08-15 18:04:24 --> Router Class Initialized
DEBUG - 2011-08-15 18:04:24 --> Output Class Initialized
DEBUG - 2011-08-15 18:04:24 --> Input Class Initialized
DEBUG - 2011-08-15 18:04:24 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-15 18:04:24 --> Language Class Initialized
DEBUG - 2011-08-15 18:04:24 --> Loader Class Initialized
DEBUG - 2011-08-15 18:04:24 --> Controller Class Initialized
DEBUG - 2011-08-15 18:04:24 --> Model Class Initialized
DEBUG - 2011-08-15 18:04:24 --> Model Class Initialized
DEBUG - 2011-08-15 18:04:24 --> Model Class Initialized
DEBUG - 2011-08-15 18:04:24 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-15 18:04:24 --> Database Driver Class Initialized
DEBUG - 2011-08-15 18:04:24 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-15 18:04:24 --> Helper loaded: url_helper
DEBUG - 2011-08-15 18:04:24 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-15 18:04:24 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-15 18:04:24 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-15 18:04:24 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-15 18:04:24 --> Final output sent to browser
DEBUG - 2011-08-15 18:04:24 --> Total execution time: 0.0601
DEBUG - 2011-08-15 18:04:26 --> Config Class Initialized
DEBUG - 2011-08-15 18:04:26 --> Hooks Class Initialized
DEBUG - 2011-08-15 18:04:26 --> Utf8 Class Initialized
DEBUG - 2011-08-15 18:04:26 --> UTF-8 Support Enabled
DEBUG - 2011-08-15 18:04:26 --> URI Class Initialized
DEBUG - 2011-08-15 18:04:26 --> Router Class Initialized
ERROR - 2011-08-15 18:04:26 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-15 18:20:16 --> Config Class Initialized
DEBUG - 2011-08-15 18:20:16 --> Hooks Class Initialized
DEBUG - 2011-08-15 18:20:16 --> Utf8 Class Initialized
DEBUG - 2011-08-15 18:20:16 --> UTF-8 Support Enabled
DEBUG - 2011-08-15 18:20:16 --> URI Class Initialized
DEBUG - 2011-08-15 18:20:16 --> Router Class Initialized
DEBUG - 2011-08-15 18:20:16 --> Output Class Initialized
DEBUG - 2011-08-15 18:20:16 --> Input Class Initialized
DEBUG - 2011-08-15 18:20:16 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-15 18:20:16 --> Language Class Initialized
DEBUG - 2011-08-15 18:20:16 --> Loader Class Initialized
DEBUG - 2011-08-15 18:20:16 --> Controller Class Initialized
DEBUG - 2011-08-15 18:20:16 --> Model Class Initialized
DEBUG - 2011-08-15 18:20:16 --> Model Class Initialized
DEBUG - 2011-08-15 18:20:16 --> Model Class Initialized
DEBUG - 2011-08-15 18:20:16 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-15 18:20:16 --> Database Driver Class Initialized
DEBUG - 2011-08-15 18:20:16 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-15 18:20:16 --> Helper loaded: url_helper
DEBUG - 2011-08-15 18:20:16 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-15 18:20:16 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-15 18:20:16 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-15 18:20:16 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-15 18:20:16 --> Final output sent to browser
DEBUG - 2011-08-15 18:20:16 --> Total execution time: 0.0430
DEBUG - 2011-08-15 18:20:17 --> Config Class Initialized
DEBUG - 2011-08-15 18:20:17 --> Hooks Class Initialized
DEBUG - 2011-08-15 18:20:17 --> Utf8 Class Initialized
DEBUG - 2011-08-15 18:20:17 --> UTF-8 Support Enabled
DEBUG - 2011-08-15 18:20:17 --> URI Class Initialized
DEBUG - 2011-08-15 18:20:17 --> Router Class Initialized
ERROR - 2011-08-15 18:20:17 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-15 18:21:32 --> Config Class Initialized
DEBUG - 2011-08-15 18:21:32 --> Hooks Class Initialized
DEBUG - 2011-08-15 18:21:32 --> Utf8 Class Initialized
DEBUG - 2011-08-15 18:21:32 --> UTF-8 Support Enabled
DEBUG - 2011-08-15 18:21:32 --> URI Class Initialized
DEBUG - 2011-08-15 18:21:32 --> Router Class Initialized
DEBUG - 2011-08-15 18:21:32 --> Output Class Initialized
DEBUG - 2011-08-15 18:21:32 --> Input Class Initialized
DEBUG - 2011-08-15 18:21:32 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-15 18:21:32 --> Language Class Initialized
DEBUG - 2011-08-15 18:21:32 --> Loader Class Initialized
DEBUG - 2011-08-15 18:21:32 --> Controller Class Initialized
ERROR - 2011-08-15 18:21:32 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-15 18:21:32 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-15 18:21:32 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-15 18:21:32 --> Model Class Initialized
DEBUG - 2011-08-15 18:21:32 --> Model Class Initialized
DEBUG - 2011-08-15 18:21:32 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-15 18:21:33 --> Database Driver Class Initialized
DEBUG - 2011-08-15 18:21:33 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-15 18:21:33 --> Helper loaded: url_helper
DEBUG - 2011-08-15 18:21:33 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-15 18:21:33 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-15 18:21:33 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-15 18:21:33 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-15 18:21:33 --> Final output sent to browser
DEBUG - 2011-08-15 18:21:33 --> Total execution time: 0.0430
DEBUG - 2011-08-15 18:21:33 --> Config Class Initialized
DEBUG - 2011-08-15 18:21:33 --> Hooks Class Initialized
DEBUG - 2011-08-15 18:21:33 --> Utf8 Class Initialized
DEBUG - 2011-08-15 18:21:33 --> UTF-8 Support Enabled
DEBUG - 2011-08-15 18:21:33 --> URI Class Initialized
DEBUG - 2011-08-15 18:21:33 --> Router Class Initialized
DEBUG - 2011-08-15 18:21:33 --> Output Class Initialized
DEBUG - 2011-08-15 18:21:33 --> Input Class Initialized
DEBUG - 2011-08-15 18:21:33 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-15 18:21:33 --> Language Class Initialized
DEBUG - 2011-08-15 18:21:33 --> Loader Class Initialized
DEBUG - 2011-08-15 18:21:33 --> Controller Class Initialized
DEBUG - 2011-08-15 18:21:33 --> Model Class Initialized
DEBUG - 2011-08-15 18:21:33 --> Model Class Initialized
DEBUG - 2011-08-15 18:21:33 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-15 18:21:33 --> Database Driver Class Initialized
DEBUG - 2011-08-15 18:21:34 --> Final output sent to browser
DEBUG - 2011-08-15 18:21:34 --> Total execution time: 0.5351
DEBUG - 2011-08-15 18:21:34 --> Config Class Initialized
DEBUG - 2011-08-15 18:21:34 --> Hooks Class Initialized
DEBUG - 2011-08-15 18:21:34 --> Utf8 Class Initialized
DEBUG - 2011-08-15 18:21:34 --> UTF-8 Support Enabled
DEBUG - 2011-08-15 18:21:34 --> URI Class Initialized
DEBUG - 2011-08-15 18:21:34 --> Router Class Initialized
ERROR - 2011-08-15 18:21:34 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-15 18:22:02 --> Config Class Initialized
DEBUG - 2011-08-15 18:22:02 --> Hooks Class Initialized
DEBUG - 2011-08-15 18:22:02 --> Utf8 Class Initialized
DEBUG - 2011-08-15 18:22:02 --> UTF-8 Support Enabled
DEBUG - 2011-08-15 18:22:02 --> URI Class Initialized
DEBUG - 2011-08-15 18:22:02 --> Router Class Initialized
DEBUG - 2011-08-15 18:22:02 --> Output Class Initialized
DEBUG - 2011-08-15 18:22:02 --> Input Class Initialized
DEBUG - 2011-08-15 18:22:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-15 18:22:02 --> Language Class Initialized
DEBUG - 2011-08-15 18:22:02 --> Loader Class Initialized
DEBUG - 2011-08-15 18:22:02 --> Controller Class Initialized
ERROR - 2011-08-15 18:22:02 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-15 18:22:02 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-15 18:22:02 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-15 18:22:02 --> Model Class Initialized
DEBUG - 2011-08-15 18:22:02 --> Model Class Initialized
DEBUG - 2011-08-15 18:22:02 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-15 18:22:02 --> Database Driver Class Initialized
DEBUG - 2011-08-15 18:22:02 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-15 18:22:02 --> Helper loaded: url_helper
DEBUG - 2011-08-15 18:22:02 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-15 18:22:02 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-15 18:22:02 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-15 18:22:02 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-15 18:22:02 --> Final output sent to browser
DEBUG - 2011-08-15 18:22:02 --> Total execution time: 0.0627
DEBUG - 2011-08-15 18:22:02 --> Config Class Initialized
DEBUG - 2011-08-15 18:22:02 --> Hooks Class Initialized
DEBUG - 2011-08-15 18:22:02 --> Utf8 Class Initialized
DEBUG - 2011-08-15 18:22:02 --> UTF-8 Support Enabled
DEBUG - 2011-08-15 18:22:02 --> URI Class Initialized
DEBUG - 2011-08-15 18:22:02 --> Router Class Initialized
DEBUG - 2011-08-15 18:22:02 --> Output Class Initialized
DEBUG - 2011-08-15 18:22:02 --> Input Class Initialized
DEBUG - 2011-08-15 18:22:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-15 18:22:02 --> Language Class Initialized
DEBUG - 2011-08-15 18:22:02 --> Loader Class Initialized
DEBUG - 2011-08-15 18:22:02 --> Controller Class Initialized
DEBUG - 2011-08-15 18:22:02 --> Model Class Initialized
DEBUG - 2011-08-15 18:22:02 --> Model Class Initialized
DEBUG - 2011-08-15 18:22:02 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-15 18:22:02 --> Database Driver Class Initialized
DEBUG - 2011-08-15 18:22:03 --> Final output sent to browser
DEBUG - 2011-08-15 18:22:03 --> Total execution time: 0.5238
DEBUG - 2011-08-15 18:22:03 --> Config Class Initialized
DEBUG - 2011-08-15 18:22:03 --> Hooks Class Initialized
DEBUG - 2011-08-15 18:22:03 --> Utf8 Class Initialized
DEBUG - 2011-08-15 18:22:03 --> UTF-8 Support Enabled
DEBUG - 2011-08-15 18:22:03 --> URI Class Initialized
DEBUG - 2011-08-15 18:22:03 --> Router Class Initialized
DEBUG - 2011-08-15 18:22:03 --> Output Class Initialized
DEBUG - 2011-08-15 18:22:03 --> Input Class Initialized
DEBUG - 2011-08-15 18:22:03 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-15 18:22:03 --> Language Class Initialized
DEBUG - 2011-08-15 18:22:03 --> Loader Class Initialized
DEBUG - 2011-08-15 18:22:03 --> Controller Class Initialized
ERROR - 2011-08-15 18:22:03 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-15 18:22:03 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-15 18:22:03 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-15 18:22:03 --> Model Class Initialized
DEBUG - 2011-08-15 18:22:03 --> Model Class Initialized
DEBUG - 2011-08-15 18:22:03 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-15 18:22:03 --> Database Driver Class Initialized
DEBUG - 2011-08-15 18:22:03 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-15 18:22:03 --> Helper loaded: url_helper
DEBUG - 2011-08-15 18:22:03 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-15 18:22:03 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-15 18:22:03 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-15 18:22:03 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-15 18:22:03 --> Final output sent to browser
DEBUG - 2011-08-15 18:22:03 --> Total execution time: 0.0348
DEBUG - 2011-08-15 18:22:03 --> Config Class Initialized
DEBUG - 2011-08-15 18:22:03 --> Hooks Class Initialized
DEBUG - 2011-08-15 18:22:03 --> Utf8 Class Initialized
DEBUG - 2011-08-15 18:22:03 --> UTF-8 Support Enabled
DEBUG - 2011-08-15 18:22:03 --> URI Class Initialized
DEBUG - 2011-08-15 18:22:03 --> Router Class Initialized
ERROR - 2011-08-15 18:22:03 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-15 18:22:18 --> Config Class Initialized
DEBUG - 2011-08-15 18:22:18 --> Hooks Class Initialized
DEBUG - 2011-08-15 18:22:18 --> Utf8 Class Initialized
DEBUG - 2011-08-15 18:22:18 --> UTF-8 Support Enabled
DEBUG - 2011-08-15 18:22:18 --> URI Class Initialized
DEBUG - 2011-08-15 18:22:18 --> Router Class Initialized
DEBUG - 2011-08-15 18:22:18 --> Output Class Initialized
DEBUG - 2011-08-15 18:22:18 --> Input Class Initialized
DEBUG - 2011-08-15 18:22:18 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-15 18:22:18 --> Language Class Initialized
DEBUG - 2011-08-15 18:22:18 --> Loader Class Initialized
DEBUG - 2011-08-15 18:22:18 --> Controller Class Initialized
ERROR - 2011-08-15 18:22:18 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-15 18:22:18 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-15 18:22:18 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-15 18:22:18 --> Model Class Initialized
DEBUG - 2011-08-15 18:22:18 --> Model Class Initialized
DEBUG - 2011-08-15 18:22:18 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-15 18:22:18 --> Database Driver Class Initialized
DEBUG - 2011-08-15 18:22:18 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-15 18:22:18 --> Helper loaded: url_helper
DEBUG - 2011-08-15 18:22:18 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-15 18:22:18 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-15 18:22:18 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-15 18:22:18 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-15 18:22:18 --> Final output sent to browser
DEBUG - 2011-08-15 18:22:18 --> Total execution time: 0.0278
DEBUG - 2011-08-15 18:22:18 --> Config Class Initialized
DEBUG - 2011-08-15 18:22:18 --> Hooks Class Initialized
DEBUG - 2011-08-15 18:22:18 --> Utf8 Class Initialized
DEBUG - 2011-08-15 18:22:18 --> UTF-8 Support Enabled
DEBUG - 2011-08-15 18:22:18 --> URI Class Initialized
DEBUG - 2011-08-15 18:22:18 --> Router Class Initialized
DEBUG - 2011-08-15 18:22:18 --> Output Class Initialized
DEBUG - 2011-08-15 18:22:18 --> Input Class Initialized
DEBUG - 2011-08-15 18:22:18 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-15 18:22:18 --> Language Class Initialized
DEBUG - 2011-08-15 18:22:18 --> Loader Class Initialized
DEBUG - 2011-08-15 18:22:18 --> Controller Class Initialized
DEBUG - 2011-08-15 18:22:18 --> Model Class Initialized
DEBUG - 2011-08-15 18:22:18 --> Model Class Initialized
DEBUG - 2011-08-15 18:22:18 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-15 18:22:18 --> Database Driver Class Initialized
DEBUG - 2011-08-15 18:22:19 --> Final output sent to browser
DEBUG - 2011-08-15 18:22:19 --> Total execution time: 0.5433
DEBUG - 2011-08-15 18:22:19 --> Config Class Initialized
DEBUG - 2011-08-15 18:22:19 --> Hooks Class Initialized
DEBUG - 2011-08-15 18:22:19 --> Utf8 Class Initialized
DEBUG - 2011-08-15 18:22:19 --> UTF-8 Support Enabled
DEBUG - 2011-08-15 18:22:19 --> URI Class Initialized
DEBUG - 2011-08-15 18:22:19 --> Router Class Initialized
ERROR - 2011-08-15 18:22:19 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-15 18:22:33 --> Config Class Initialized
DEBUG - 2011-08-15 18:22:33 --> Hooks Class Initialized
DEBUG - 2011-08-15 18:22:33 --> Utf8 Class Initialized
DEBUG - 2011-08-15 18:22:33 --> UTF-8 Support Enabled
DEBUG - 2011-08-15 18:22:33 --> URI Class Initialized
DEBUG - 2011-08-15 18:22:33 --> Router Class Initialized
DEBUG - 2011-08-15 18:22:33 --> Output Class Initialized
DEBUG - 2011-08-15 18:22:33 --> Input Class Initialized
DEBUG - 2011-08-15 18:22:33 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-15 18:22:33 --> Language Class Initialized
DEBUG - 2011-08-15 18:22:33 --> Loader Class Initialized
DEBUG - 2011-08-15 18:22:33 --> Controller Class Initialized
ERROR - 2011-08-15 18:22:33 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-15 18:22:33 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-15 18:22:33 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-15 18:22:33 --> Model Class Initialized
DEBUG - 2011-08-15 18:22:33 --> Model Class Initialized
DEBUG - 2011-08-15 18:22:33 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-15 18:22:33 --> Database Driver Class Initialized
DEBUG - 2011-08-15 18:22:33 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-15 18:22:33 --> Helper loaded: url_helper
DEBUG - 2011-08-15 18:22:33 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-15 18:22:33 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-15 18:22:33 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-15 18:22:33 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-15 18:22:33 --> Final output sent to browser
DEBUG - 2011-08-15 18:22:33 --> Total execution time: 0.0279
DEBUG - 2011-08-15 18:22:34 --> Config Class Initialized
DEBUG - 2011-08-15 18:22:34 --> Hooks Class Initialized
DEBUG - 2011-08-15 18:22:34 --> Utf8 Class Initialized
DEBUG - 2011-08-15 18:22:34 --> UTF-8 Support Enabled
DEBUG - 2011-08-15 18:22:34 --> URI Class Initialized
DEBUG - 2011-08-15 18:22:34 --> Router Class Initialized
DEBUG - 2011-08-15 18:22:34 --> Output Class Initialized
DEBUG - 2011-08-15 18:22:34 --> Input Class Initialized
DEBUG - 2011-08-15 18:22:34 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-15 18:22:34 --> Language Class Initialized
DEBUG - 2011-08-15 18:22:34 --> Loader Class Initialized
DEBUG - 2011-08-15 18:22:34 --> Controller Class Initialized
DEBUG - 2011-08-15 18:22:34 --> Model Class Initialized
DEBUG - 2011-08-15 18:22:34 --> Model Class Initialized
DEBUG - 2011-08-15 18:22:34 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-15 18:22:34 --> Database Driver Class Initialized
DEBUG - 2011-08-15 18:22:34 --> Final output sent to browser
DEBUG - 2011-08-15 18:22:34 --> Total execution time: 0.5785
DEBUG - 2011-08-15 18:22:35 --> Config Class Initialized
DEBUG - 2011-08-15 18:22:35 --> Hooks Class Initialized
DEBUG - 2011-08-15 18:22:35 --> Utf8 Class Initialized
DEBUG - 2011-08-15 18:22:35 --> UTF-8 Support Enabled
DEBUG - 2011-08-15 18:22:35 --> URI Class Initialized
DEBUG - 2011-08-15 18:22:35 --> Router Class Initialized
ERROR - 2011-08-15 18:22:35 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-15 18:22:40 --> Config Class Initialized
DEBUG - 2011-08-15 18:22:40 --> Hooks Class Initialized
DEBUG - 2011-08-15 18:22:40 --> Utf8 Class Initialized
DEBUG - 2011-08-15 18:22:40 --> UTF-8 Support Enabled
DEBUG - 2011-08-15 18:22:40 --> URI Class Initialized
DEBUG - 2011-08-15 18:22:40 --> Router Class Initialized
DEBUG - 2011-08-15 18:22:40 --> Output Class Initialized
DEBUG - 2011-08-15 18:22:40 --> Input Class Initialized
DEBUG - 2011-08-15 18:22:40 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-15 18:22:40 --> Language Class Initialized
DEBUG - 2011-08-15 18:22:40 --> Loader Class Initialized
DEBUG - 2011-08-15 18:22:40 --> Controller Class Initialized
ERROR - 2011-08-15 18:22:40 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-15 18:22:40 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-15 18:22:40 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-15 18:22:40 --> Model Class Initialized
DEBUG - 2011-08-15 18:22:40 --> Model Class Initialized
DEBUG - 2011-08-15 18:22:40 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-15 18:22:40 --> Database Driver Class Initialized
DEBUG - 2011-08-15 18:22:40 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-15 18:22:40 --> Helper loaded: url_helper
DEBUG - 2011-08-15 18:22:40 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-15 18:22:40 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-15 18:22:40 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-15 18:22:40 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-15 18:22:40 --> Final output sent to browser
DEBUG - 2011-08-15 18:22:40 --> Total execution time: 0.0296
DEBUG - 2011-08-15 18:22:40 --> Config Class Initialized
DEBUG - 2011-08-15 18:22:40 --> Hooks Class Initialized
DEBUG - 2011-08-15 18:22:40 --> Utf8 Class Initialized
DEBUG - 2011-08-15 18:22:40 --> UTF-8 Support Enabled
DEBUG - 2011-08-15 18:22:40 --> URI Class Initialized
DEBUG - 2011-08-15 18:22:40 --> Router Class Initialized
DEBUG - 2011-08-15 18:22:40 --> Output Class Initialized
DEBUG - 2011-08-15 18:22:40 --> Input Class Initialized
DEBUG - 2011-08-15 18:22:40 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-15 18:22:40 --> Language Class Initialized
DEBUG - 2011-08-15 18:22:41 --> Loader Class Initialized
DEBUG - 2011-08-15 18:22:41 --> Controller Class Initialized
DEBUG - 2011-08-15 18:22:41 --> Model Class Initialized
DEBUG - 2011-08-15 18:22:41 --> Model Class Initialized
DEBUG - 2011-08-15 18:22:41 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-15 18:22:41 --> Database Driver Class Initialized
DEBUG - 2011-08-15 18:22:41 --> Final output sent to browser
DEBUG - 2011-08-15 18:22:41 --> Total execution time: 0.6408
DEBUG - 2011-08-15 18:22:42 --> Config Class Initialized
DEBUG - 2011-08-15 18:22:42 --> Hooks Class Initialized
DEBUG - 2011-08-15 18:22:42 --> Utf8 Class Initialized
DEBUG - 2011-08-15 18:22:42 --> UTF-8 Support Enabled
DEBUG - 2011-08-15 18:22:42 --> URI Class Initialized
DEBUG - 2011-08-15 18:22:42 --> Router Class Initialized
ERROR - 2011-08-15 18:22:42 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-15 18:22:49 --> Config Class Initialized
DEBUG - 2011-08-15 18:22:49 --> Hooks Class Initialized
DEBUG - 2011-08-15 18:22:49 --> Utf8 Class Initialized
DEBUG - 2011-08-15 18:22:49 --> UTF-8 Support Enabled
DEBUG - 2011-08-15 18:22:49 --> URI Class Initialized
DEBUG - 2011-08-15 18:22:49 --> Router Class Initialized
DEBUG - 2011-08-15 18:22:49 --> Output Class Initialized
DEBUG - 2011-08-15 18:22:49 --> Input Class Initialized
DEBUG - 2011-08-15 18:22:49 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-15 18:22:49 --> Language Class Initialized
DEBUG - 2011-08-15 18:22:49 --> Loader Class Initialized
DEBUG - 2011-08-15 18:22:49 --> Controller Class Initialized
ERROR - 2011-08-15 18:22:49 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-15 18:22:49 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-15 18:22:49 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-15 18:22:49 --> Model Class Initialized
DEBUG - 2011-08-15 18:22:49 --> Model Class Initialized
DEBUG - 2011-08-15 18:22:49 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-15 18:22:49 --> Database Driver Class Initialized
DEBUG - 2011-08-15 18:22:49 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-15 18:22:49 --> Helper loaded: url_helper
DEBUG - 2011-08-15 18:22:49 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-15 18:22:49 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-15 18:22:49 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-15 18:22:49 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-15 18:22:49 --> Final output sent to browser
DEBUG - 2011-08-15 18:22:49 --> Total execution time: 0.0350
DEBUG - 2011-08-15 18:22:49 --> Config Class Initialized
DEBUG - 2011-08-15 18:22:49 --> Hooks Class Initialized
DEBUG - 2011-08-15 18:22:49 --> Utf8 Class Initialized
DEBUG - 2011-08-15 18:22:49 --> UTF-8 Support Enabled
DEBUG - 2011-08-15 18:22:49 --> URI Class Initialized
DEBUG - 2011-08-15 18:22:49 --> Router Class Initialized
DEBUG - 2011-08-15 18:22:49 --> Output Class Initialized
DEBUG - 2011-08-15 18:22:49 --> Input Class Initialized
DEBUG - 2011-08-15 18:22:49 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-15 18:22:49 --> Language Class Initialized
DEBUG - 2011-08-15 18:22:49 --> Loader Class Initialized
DEBUG - 2011-08-15 18:22:49 --> Controller Class Initialized
DEBUG - 2011-08-15 18:22:49 --> Model Class Initialized
DEBUG - 2011-08-15 18:22:49 --> Model Class Initialized
DEBUG - 2011-08-15 18:22:49 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-15 18:22:49 --> Database Driver Class Initialized
DEBUG - 2011-08-15 18:22:50 --> Final output sent to browser
DEBUG - 2011-08-15 18:22:50 --> Total execution time: 0.4929
DEBUG - 2011-08-15 18:22:50 --> Config Class Initialized
DEBUG - 2011-08-15 18:22:50 --> Hooks Class Initialized
DEBUG - 2011-08-15 18:22:50 --> Utf8 Class Initialized
DEBUG - 2011-08-15 18:22:50 --> UTF-8 Support Enabled
DEBUG - 2011-08-15 18:22:50 --> URI Class Initialized
DEBUG - 2011-08-15 18:22:50 --> Router Class Initialized
ERROR - 2011-08-15 18:22:50 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-15 19:54:14 --> Config Class Initialized
DEBUG - 2011-08-15 19:54:14 --> Hooks Class Initialized
DEBUG - 2011-08-15 19:54:14 --> Utf8 Class Initialized
DEBUG - 2011-08-15 19:54:14 --> UTF-8 Support Enabled
DEBUG - 2011-08-15 19:54:14 --> URI Class Initialized
DEBUG - 2011-08-15 19:54:14 --> Router Class Initialized
ERROR - 2011-08-15 19:54:14 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-08-15 19:54:15 --> Config Class Initialized
DEBUG - 2011-08-15 19:54:15 --> Hooks Class Initialized
DEBUG - 2011-08-15 19:54:15 --> Utf8 Class Initialized
DEBUG - 2011-08-15 19:54:15 --> UTF-8 Support Enabled
DEBUG - 2011-08-15 19:54:15 --> URI Class Initialized
DEBUG - 2011-08-15 19:54:15 --> Router Class Initialized
DEBUG - 2011-08-15 19:54:15 --> Output Class Initialized
DEBUG - 2011-08-15 19:54:15 --> Input Class Initialized
DEBUG - 2011-08-15 19:54:15 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-15 19:54:15 --> Language Class Initialized
DEBUG - 2011-08-15 19:54:15 --> Loader Class Initialized
DEBUG - 2011-08-15 19:54:15 --> Controller Class Initialized
ERROR - 2011-08-15 19:54:15 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-15 19:54:15 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-15 19:54:15 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-15 19:54:15 --> Model Class Initialized
DEBUG - 2011-08-15 19:54:15 --> Model Class Initialized
DEBUG - 2011-08-15 19:54:15 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-15 19:54:15 --> Database Driver Class Initialized
DEBUG - 2011-08-15 19:54:15 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-15 19:54:15 --> Helper loaded: url_helper
DEBUG - 2011-08-15 19:54:15 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-15 19:54:15 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-15 19:54:15 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-15 19:54:15 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-15 19:54:15 --> Final output sent to browser
DEBUG - 2011-08-15 19:54:15 --> Total execution time: 0.0847
DEBUG - 2011-08-15 20:20:27 --> Config Class Initialized
DEBUG - 2011-08-15 20:20:27 --> Hooks Class Initialized
DEBUG - 2011-08-15 20:20:27 --> Utf8 Class Initialized
DEBUG - 2011-08-15 20:20:27 --> UTF-8 Support Enabled
DEBUG - 2011-08-15 20:20:27 --> URI Class Initialized
DEBUG - 2011-08-15 20:20:27 --> Router Class Initialized
DEBUG - 2011-08-15 20:20:27 --> Output Class Initialized
DEBUG - 2011-08-15 20:20:27 --> Input Class Initialized
DEBUG - 2011-08-15 20:20:27 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-15 20:20:27 --> Language Class Initialized
DEBUG - 2011-08-15 20:20:27 --> Loader Class Initialized
DEBUG - 2011-08-15 20:20:27 --> Controller Class Initialized
ERROR - 2011-08-15 20:20:27 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-15 20:20:27 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-15 20:20:27 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-15 20:20:27 --> Model Class Initialized
DEBUG - 2011-08-15 20:20:27 --> Model Class Initialized
DEBUG - 2011-08-15 20:20:27 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-15 20:20:27 --> Database Driver Class Initialized
DEBUG - 2011-08-15 20:20:27 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-15 20:20:27 --> Helper loaded: url_helper
DEBUG - 2011-08-15 20:20:27 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-15 20:20:27 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-15 20:20:27 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-15 20:20:27 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-15 20:20:27 --> Final output sent to browser
DEBUG - 2011-08-15 20:20:27 --> Total execution time: 0.0768
DEBUG - 2011-08-15 20:20:27 --> Config Class Initialized
DEBUG - 2011-08-15 20:20:27 --> Hooks Class Initialized
DEBUG - 2011-08-15 20:20:27 --> Utf8 Class Initialized
DEBUG - 2011-08-15 20:20:27 --> UTF-8 Support Enabled
DEBUG - 2011-08-15 20:20:27 --> URI Class Initialized
DEBUG - 2011-08-15 20:20:27 --> Router Class Initialized
DEBUG - 2011-08-15 20:20:27 --> Output Class Initialized
DEBUG - 2011-08-15 20:20:27 --> Input Class Initialized
DEBUG - 2011-08-15 20:20:27 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-15 20:20:27 --> Language Class Initialized
DEBUG - 2011-08-15 20:20:27 --> Loader Class Initialized
DEBUG - 2011-08-15 20:20:27 --> Controller Class Initialized
DEBUG - 2011-08-15 20:20:27 --> Model Class Initialized
DEBUG - 2011-08-15 20:20:27 --> Model Class Initialized
DEBUG - 2011-08-15 20:20:27 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-15 20:20:27 --> Database Driver Class Initialized
DEBUG - 2011-08-15 20:20:28 --> Final output sent to browser
DEBUG - 2011-08-15 20:20:28 --> Total execution time: 0.8497
DEBUG - 2011-08-15 20:20:29 --> Config Class Initialized
DEBUG - 2011-08-15 20:20:29 --> Hooks Class Initialized
DEBUG - 2011-08-15 20:20:29 --> Utf8 Class Initialized
DEBUG - 2011-08-15 20:20:29 --> UTF-8 Support Enabled
DEBUG - 2011-08-15 20:20:29 --> URI Class Initialized
DEBUG - 2011-08-15 20:20:29 --> Router Class Initialized
ERROR - 2011-08-15 20:20:29 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-15 20:20:29 --> Config Class Initialized
DEBUG - 2011-08-15 20:20:29 --> Hooks Class Initialized
DEBUG - 2011-08-15 20:20:29 --> Utf8 Class Initialized
DEBUG - 2011-08-15 20:20:29 --> UTF-8 Support Enabled
DEBUG - 2011-08-15 20:20:29 --> URI Class Initialized
DEBUG - 2011-08-15 20:20:29 --> Router Class Initialized
ERROR - 2011-08-15 20:20:29 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-15 20:20:39 --> Config Class Initialized
DEBUG - 2011-08-15 20:20:39 --> Hooks Class Initialized
DEBUG - 2011-08-15 20:20:39 --> Utf8 Class Initialized
DEBUG - 2011-08-15 20:20:39 --> UTF-8 Support Enabled
DEBUG - 2011-08-15 20:20:39 --> URI Class Initialized
DEBUG - 2011-08-15 20:20:39 --> Router Class Initialized
DEBUG - 2011-08-15 20:20:39 --> Output Class Initialized
DEBUG - 2011-08-15 20:20:39 --> Input Class Initialized
DEBUG - 2011-08-15 20:20:39 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-15 20:20:39 --> Language Class Initialized
DEBUG - 2011-08-15 20:20:39 --> Loader Class Initialized
DEBUG - 2011-08-15 20:20:39 --> Controller Class Initialized
ERROR - 2011-08-15 20:20:39 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-15 20:20:39 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-15 20:20:39 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-15 20:20:39 --> Model Class Initialized
DEBUG - 2011-08-15 20:20:39 --> Model Class Initialized
DEBUG - 2011-08-15 20:20:39 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-15 20:20:39 --> Database Driver Class Initialized
DEBUG - 2011-08-15 20:20:39 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-15 20:20:39 --> Helper loaded: url_helper
DEBUG - 2011-08-15 20:20:39 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-15 20:20:39 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-15 20:20:39 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-15 20:20:39 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-15 20:20:39 --> Final output sent to browser
DEBUG - 2011-08-15 20:20:39 --> Total execution time: 0.0297
DEBUG - 2011-08-15 20:20:39 --> Config Class Initialized
DEBUG - 2011-08-15 20:20:39 --> Hooks Class Initialized
DEBUG - 2011-08-15 20:20:39 --> Utf8 Class Initialized
DEBUG - 2011-08-15 20:20:39 --> UTF-8 Support Enabled
DEBUG - 2011-08-15 20:20:39 --> URI Class Initialized
DEBUG - 2011-08-15 20:20:39 --> Router Class Initialized
DEBUG - 2011-08-15 20:20:39 --> Output Class Initialized
DEBUG - 2011-08-15 20:20:39 --> Input Class Initialized
DEBUG - 2011-08-15 20:20:39 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-15 20:20:39 --> Language Class Initialized
DEBUG - 2011-08-15 20:20:39 --> Loader Class Initialized
DEBUG - 2011-08-15 20:20:39 --> Controller Class Initialized
DEBUG - 2011-08-15 20:20:39 --> Model Class Initialized
DEBUG - 2011-08-15 20:20:39 --> Model Class Initialized
DEBUG - 2011-08-15 20:20:39 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-15 20:20:39 --> Database Driver Class Initialized
DEBUG - 2011-08-15 20:20:40 --> Config Class Initialized
DEBUG - 2011-08-15 20:20:40 --> Hooks Class Initialized
DEBUG - 2011-08-15 20:20:40 --> Utf8 Class Initialized
DEBUG - 2011-08-15 20:20:40 --> UTF-8 Support Enabled
DEBUG - 2011-08-15 20:20:40 --> URI Class Initialized
DEBUG - 2011-08-15 20:20:40 --> Router Class Initialized
DEBUG - 2011-08-15 20:20:40 --> Output Class Initialized
DEBUG - 2011-08-15 20:20:40 --> Input Class Initialized
DEBUG - 2011-08-15 20:20:40 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-15 20:20:40 --> Language Class Initialized
DEBUG - 2011-08-15 20:20:40 --> Loader Class Initialized
DEBUG - 2011-08-15 20:20:40 --> Controller Class Initialized
ERROR - 2011-08-15 20:20:40 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-15 20:20:40 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-15 20:20:40 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-15 20:20:40 --> Model Class Initialized
DEBUG - 2011-08-15 20:20:40 --> Model Class Initialized
DEBUG - 2011-08-15 20:20:40 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-15 20:20:40 --> Database Driver Class Initialized
DEBUG - 2011-08-15 20:20:40 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-15 20:20:40 --> Helper loaded: url_helper
DEBUG - 2011-08-15 20:20:40 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-15 20:20:40 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-15 20:20:40 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-15 20:20:40 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-15 20:20:40 --> Final output sent to browser
DEBUG - 2011-08-15 20:20:40 --> Total execution time: 0.0281
DEBUG - 2011-08-15 20:20:40 --> Final output sent to browser
DEBUG - 2011-08-15 20:20:40 --> Total execution time: 0.9539
DEBUG - 2011-08-15 20:20:46 --> Config Class Initialized
DEBUG - 2011-08-15 20:20:46 --> Hooks Class Initialized
DEBUG - 2011-08-15 20:20:46 --> Utf8 Class Initialized
DEBUG - 2011-08-15 20:20:46 --> UTF-8 Support Enabled
DEBUG - 2011-08-15 20:20:46 --> URI Class Initialized
DEBUG - 2011-08-15 20:20:46 --> Router Class Initialized
DEBUG - 2011-08-15 20:20:46 --> Output Class Initialized
DEBUG - 2011-08-15 20:20:46 --> Input Class Initialized
DEBUG - 2011-08-15 20:20:46 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-15 20:20:46 --> Language Class Initialized
DEBUG - 2011-08-15 20:20:46 --> Loader Class Initialized
DEBUG - 2011-08-15 20:20:46 --> Controller Class Initialized
ERROR - 2011-08-15 20:20:46 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-15 20:20:46 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-15 20:20:46 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-15 20:20:46 --> Model Class Initialized
DEBUG - 2011-08-15 20:20:46 --> Model Class Initialized
DEBUG - 2011-08-15 20:20:46 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-15 20:20:46 --> Database Driver Class Initialized
DEBUG - 2011-08-15 20:20:46 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-15 20:20:46 --> Helper loaded: url_helper
DEBUG - 2011-08-15 20:20:46 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-15 20:20:46 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-15 20:20:46 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-15 20:20:46 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-15 20:20:46 --> Final output sent to browser
DEBUG - 2011-08-15 20:20:46 --> Total execution time: 0.0400
DEBUG - 2011-08-15 20:20:46 --> Config Class Initialized
DEBUG - 2011-08-15 20:20:46 --> Hooks Class Initialized
DEBUG - 2011-08-15 20:20:46 --> Utf8 Class Initialized
DEBUG - 2011-08-15 20:20:46 --> UTF-8 Support Enabled
DEBUG - 2011-08-15 20:20:46 --> URI Class Initialized
DEBUG - 2011-08-15 20:20:46 --> Router Class Initialized
DEBUG - 2011-08-15 20:20:46 --> Output Class Initialized
DEBUG - 2011-08-15 20:20:46 --> Input Class Initialized
DEBUG - 2011-08-15 20:20:46 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-15 20:20:46 --> Language Class Initialized
DEBUG - 2011-08-15 20:20:46 --> Loader Class Initialized
DEBUG - 2011-08-15 20:20:46 --> Controller Class Initialized
DEBUG - 2011-08-15 20:20:46 --> Model Class Initialized
DEBUG - 2011-08-15 20:20:46 --> Model Class Initialized
DEBUG - 2011-08-15 20:20:46 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-15 20:20:46 --> Database Driver Class Initialized
DEBUG - 2011-08-15 20:20:47 --> Final output sent to browser
DEBUG - 2011-08-15 20:20:47 --> Total execution time: 0.5879
DEBUG - 2011-08-15 20:20:50 --> Config Class Initialized
DEBUG - 2011-08-15 20:20:50 --> Hooks Class Initialized
DEBUG - 2011-08-15 20:20:50 --> Utf8 Class Initialized
DEBUG - 2011-08-15 20:20:50 --> UTF-8 Support Enabled
DEBUG - 2011-08-15 20:20:50 --> URI Class Initialized
DEBUG - 2011-08-15 20:20:50 --> Router Class Initialized
DEBUG - 2011-08-15 20:20:50 --> Output Class Initialized
DEBUG - 2011-08-15 20:20:50 --> Input Class Initialized
DEBUG - 2011-08-15 20:20:50 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-15 20:20:50 --> Language Class Initialized
DEBUG - 2011-08-15 20:20:50 --> Loader Class Initialized
DEBUG - 2011-08-15 20:20:50 --> Controller Class Initialized
ERROR - 2011-08-15 20:20:50 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-15 20:20:50 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-15 20:20:50 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-15 20:20:50 --> Model Class Initialized
DEBUG - 2011-08-15 20:20:50 --> Model Class Initialized
DEBUG - 2011-08-15 20:20:50 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-15 20:20:50 --> Database Driver Class Initialized
DEBUG - 2011-08-15 20:20:50 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-15 20:20:50 --> Helper loaded: url_helper
DEBUG - 2011-08-15 20:20:50 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-15 20:20:50 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-15 20:20:50 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-15 20:20:50 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-15 20:20:50 --> Final output sent to browser
DEBUG - 2011-08-15 20:20:50 --> Total execution time: 0.0366
DEBUG - 2011-08-15 20:21:00 --> Config Class Initialized
DEBUG - 2011-08-15 20:21:00 --> Hooks Class Initialized
DEBUG - 2011-08-15 20:21:00 --> Utf8 Class Initialized
DEBUG - 2011-08-15 20:21:00 --> UTF-8 Support Enabled
DEBUG - 2011-08-15 20:21:00 --> URI Class Initialized
DEBUG - 2011-08-15 20:21:00 --> Router Class Initialized
DEBUG - 2011-08-15 20:21:00 --> Output Class Initialized
DEBUG - 2011-08-15 20:21:00 --> Input Class Initialized
DEBUG - 2011-08-15 20:21:00 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-15 20:21:00 --> Language Class Initialized
DEBUG - 2011-08-15 20:21:00 --> Loader Class Initialized
DEBUG - 2011-08-15 20:21:00 --> Controller Class Initialized
ERROR - 2011-08-15 20:21:00 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-15 20:21:00 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-15 20:21:00 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-15 20:21:00 --> Model Class Initialized
DEBUG - 2011-08-15 20:21:00 --> Model Class Initialized
DEBUG - 2011-08-15 20:21:00 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-15 20:21:00 --> Database Driver Class Initialized
DEBUG - 2011-08-15 20:21:00 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-15 20:21:00 --> Helper loaded: url_helper
DEBUG - 2011-08-15 20:21:00 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-15 20:21:00 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-15 20:21:00 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-15 20:21:00 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-15 20:21:00 --> Final output sent to browser
DEBUG - 2011-08-15 20:21:00 --> Total execution time: 0.0446
DEBUG - 2011-08-15 20:21:00 --> Config Class Initialized
DEBUG - 2011-08-15 20:21:00 --> Hooks Class Initialized
DEBUG - 2011-08-15 20:21:00 --> Utf8 Class Initialized
DEBUG - 2011-08-15 20:21:00 --> UTF-8 Support Enabled
DEBUG - 2011-08-15 20:21:00 --> URI Class Initialized
DEBUG - 2011-08-15 20:21:00 --> Router Class Initialized
DEBUG - 2011-08-15 20:21:00 --> Output Class Initialized
DEBUG - 2011-08-15 20:21:00 --> Input Class Initialized
DEBUG - 2011-08-15 20:21:00 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-15 20:21:00 --> Language Class Initialized
DEBUG - 2011-08-15 20:21:00 --> Loader Class Initialized
DEBUG - 2011-08-15 20:21:00 --> Controller Class Initialized
DEBUG - 2011-08-15 20:21:00 --> Model Class Initialized
DEBUG - 2011-08-15 20:21:00 --> Model Class Initialized
DEBUG - 2011-08-15 20:21:00 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-15 20:21:00 --> Database Driver Class Initialized
DEBUG - 2011-08-15 20:21:01 --> Config Class Initialized
DEBUG - 2011-08-15 20:21:01 --> Hooks Class Initialized
DEBUG - 2011-08-15 20:21:01 --> Utf8 Class Initialized
DEBUG - 2011-08-15 20:21:01 --> UTF-8 Support Enabled
DEBUG - 2011-08-15 20:21:01 --> URI Class Initialized
DEBUG - 2011-08-15 20:21:01 --> Router Class Initialized
DEBUG - 2011-08-15 20:21:01 --> Output Class Initialized
DEBUG - 2011-08-15 20:21:01 --> Input Class Initialized
DEBUG - 2011-08-15 20:21:01 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-15 20:21:01 --> Language Class Initialized
DEBUG - 2011-08-15 20:21:01 --> Loader Class Initialized
DEBUG - 2011-08-15 20:21:01 --> Controller Class Initialized
ERROR - 2011-08-15 20:21:01 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-15 20:21:01 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-15 20:21:01 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-15 20:21:01 --> Model Class Initialized
DEBUG - 2011-08-15 20:21:01 --> Model Class Initialized
DEBUG - 2011-08-15 20:21:01 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-15 20:21:01 --> Database Driver Class Initialized
DEBUG - 2011-08-15 20:21:01 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-15 20:21:01 --> Helper loaded: url_helper
DEBUG - 2011-08-15 20:21:01 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-15 20:21:01 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-15 20:21:01 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-15 20:21:01 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-15 20:21:01 --> Final output sent to browser
DEBUG - 2011-08-15 20:21:01 --> Total execution time: 0.0439
DEBUG - 2011-08-15 20:21:01 --> Final output sent to browser
DEBUG - 2011-08-15 20:21:01 --> Total execution time: 1.0390
DEBUG - 2011-08-15 20:21:07 --> Config Class Initialized
DEBUG - 2011-08-15 20:21:07 --> Hooks Class Initialized
DEBUG - 2011-08-15 20:21:07 --> Utf8 Class Initialized
DEBUG - 2011-08-15 20:21:07 --> UTF-8 Support Enabled
DEBUG - 2011-08-15 20:21:07 --> URI Class Initialized
DEBUG - 2011-08-15 20:21:07 --> Router Class Initialized
DEBUG - 2011-08-15 20:21:07 --> Output Class Initialized
DEBUG - 2011-08-15 20:21:07 --> Input Class Initialized
DEBUG - 2011-08-15 20:21:07 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-15 20:21:07 --> Language Class Initialized
DEBUG - 2011-08-15 20:21:07 --> Loader Class Initialized
DEBUG - 2011-08-15 20:21:07 --> Controller Class Initialized
ERROR - 2011-08-15 20:21:07 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-15 20:21:07 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-15 20:21:07 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-15 20:21:07 --> Model Class Initialized
DEBUG - 2011-08-15 20:21:07 --> Model Class Initialized
DEBUG - 2011-08-15 20:21:07 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-15 20:21:07 --> Database Driver Class Initialized
DEBUG - 2011-08-15 20:21:07 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-15 20:21:07 --> Helper loaded: url_helper
DEBUG - 2011-08-15 20:21:07 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-15 20:21:07 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-15 20:21:07 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-15 20:21:07 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-15 20:21:07 --> Final output sent to browser
DEBUG - 2011-08-15 20:21:07 --> Total execution time: 0.0293
DEBUG - 2011-08-15 20:21:08 --> Config Class Initialized
DEBUG - 2011-08-15 20:21:08 --> Hooks Class Initialized
DEBUG - 2011-08-15 20:21:08 --> Utf8 Class Initialized
DEBUG - 2011-08-15 20:21:08 --> UTF-8 Support Enabled
DEBUG - 2011-08-15 20:21:08 --> URI Class Initialized
DEBUG - 2011-08-15 20:21:08 --> Router Class Initialized
DEBUG - 2011-08-15 20:21:08 --> Output Class Initialized
DEBUG - 2011-08-15 20:21:08 --> Input Class Initialized
DEBUG - 2011-08-15 20:21:08 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-15 20:21:08 --> Language Class Initialized
DEBUG - 2011-08-15 20:21:08 --> Loader Class Initialized
DEBUG - 2011-08-15 20:21:08 --> Controller Class Initialized
DEBUG - 2011-08-15 20:21:08 --> Model Class Initialized
DEBUG - 2011-08-15 20:21:08 --> Model Class Initialized
DEBUG - 2011-08-15 20:21:08 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-15 20:21:08 --> Database Driver Class Initialized
DEBUG - 2011-08-15 20:21:08 --> Final output sent to browser
DEBUG - 2011-08-15 20:21:08 --> Total execution time: 0.5040
DEBUG - 2011-08-15 20:21:09 --> Config Class Initialized
DEBUG - 2011-08-15 20:21:09 --> Hooks Class Initialized
DEBUG - 2011-08-15 20:21:09 --> Utf8 Class Initialized
DEBUG - 2011-08-15 20:21:09 --> UTF-8 Support Enabled
DEBUG - 2011-08-15 20:21:09 --> URI Class Initialized
DEBUG - 2011-08-15 20:21:09 --> Router Class Initialized
DEBUG - 2011-08-15 20:21:09 --> Output Class Initialized
DEBUG - 2011-08-15 20:21:09 --> Input Class Initialized
DEBUG - 2011-08-15 20:21:09 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-15 20:21:09 --> Language Class Initialized
DEBUG - 2011-08-15 20:21:09 --> Loader Class Initialized
DEBUG - 2011-08-15 20:21:09 --> Controller Class Initialized
ERROR - 2011-08-15 20:21:09 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-15 20:21:09 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-15 20:21:09 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-15 20:21:09 --> Model Class Initialized
DEBUG - 2011-08-15 20:21:09 --> Model Class Initialized
DEBUG - 2011-08-15 20:21:09 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-15 20:21:09 --> Database Driver Class Initialized
DEBUG - 2011-08-15 20:21:09 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-15 20:21:09 --> Helper loaded: url_helper
DEBUG - 2011-08-15 20:21:09 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-15 20:21:09 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-15 20:21:09 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-15 20:21:09 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-15 20:21:09 --> Final output sent to browser
DEBUG - 2011-08-15 20:21:09 --> Total execution time: 0.0321
DEBUG - 2011-08-15 20:21:13 --> Config Class Initialized
DEBUG - 2011-08-15 20:21:13 --> Hooks Class Initialized
DEBUG - 2011-08-15 20:21:13 --> Utf8 Class Initialized
DEBUG - 2011-08-15 20:21:13 --> UTF-8 Support Enabled
DEBUG - 2011-08-15 20:21:13 --> URI Class Initialized
DEBUG - 2011-08-15 20:21:13 --> Router Class Initialized
DEBUG - 2011-08-15 20:21:13 --> Output Class Initialized
DEBUG - 2011-08-15 20:21:13 --> Input Class Initialized
DEBUG - 2011-08-15 20:21:13 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-15 20:21:13 --> Language Class Initialized
DEBUG - 2011-08-15 20:21:13 --> Loader Class Initialized
DEBUG - 2011-08-15 20:21:13 --> Controller Class Initialized
ERROR - 2011-08-15 20:21:13 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-15 20:21:13 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-15 20:21:13 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-15 20:21:13 --> Model Class Initialized
DEBUG - 2011-08-15 20:21:13 --> Model Class Initialized
DEBUG - 2011-08-15 20:21:13 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-15 20:21:13 --> Database Driver Class Initialized
DEBUG - 2011-08-15 20:21:13 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-15 20:21:13 --> Helper loaded: url_helper
DEBUG - 2011-08-15 20:21:13 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-15 20:21:13 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-15 20:21:13 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-15 20:21:13 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-15 20:21:13 --> Final output sent to browser
DEBUG - 2011-08-15 20:21:13 --> Total execution time: 0.0438
DEBUG - 2011-08-15 20:21:13 --> Config Class Initialized
DEBUG - 2011-08-15 20:21:13 --> Hooks Class Initialized
DEBUG - 2011-08-15 20:21:13 --> Utf8 Class Initialized
DEBUG - 2011-08-15 20:21:13 --> UTF-8 Support Enabled
DEBUG - 2011-08-15 20:21:13 --> URI Class Initialized
DEBUG - 2011-08-15 20:21:13 --> Router Class Initialized
DEBUG - 2011-08-15 20:21:13 --> Output Class Initialized
DEBUG - 2011-08-15 20:21:13 --> Input Class Initialized
DEBUG - 2011-08-15 20:21:13 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-15 20:21:13 --> Language Class Initialized
DEBUG - 2011-08-15 20:21:13 --> Loader Class Initialized
DEBUG - 2011-08-15 20:21:13 --> Controller Class Initialized
DEBUG - 2011-08-15 20:21:13 --> Model Class Initialized
DEBUG - 2011-08-15 20:21:13 --> Model Class Initialized
DEBUG - 2011-08-15 20:21:13 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-15 20:21:13 --> Database Driver Class Initialized
DEBUG - 2011-08-15 20:21:14 --> Final output sent to browser
DEBUG - 2011-08-15 20:21:14 --> Total execution time: 0.4984
DEBUG - 2011-08-15 20:21:14 --> Config Class Initialized
DEBUG - 2011-08-15 20:21:14 --> Hooks Class Initialized
DEBUG - 2011-08-15 20:21:14 --> Utf8 Class Initialized
DEBUG - 2011-08-15 20:21:14 --> UTF-8 Support Enabled
DEBUG - 2011-08-15 20:21:14 --> URI Class Initialized
DEBUG - 2011-08-15 20:21:14 --> Router Class Initialized
DEBUG - 2011-08-15 20:21:14 --> Output Class Initialized
DEBUG - 2011-08-15 20:21:14 --> Input Class Initialized
DEBUG - 2011-08-15 20:21:14 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-15 20:21:14 --> Language Class Initialized
DEBUG - 2011-08-15 20:21:14 --> Loader Class Initialized
DEBUG - 2011-08-15 20:21:14 --> Controller Class Initialized
ERROR - 2011-08-15 20:21:14 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-15 20:21:14 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-15 20:21:14 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-15 20:21:14 --> Model Class Initialized
DEBUG - 2011-08-15 20:21:14 --> Model Class Initialized
DEBUG - 2011-08-15 20:21:14 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-15 20:21:14 --> Database Driver Class Initialized
DEBUG - 2011-08-15 20:21:14 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-15 20:21:14 --> Helper loaded: url_helper
DEBUG - 2011-08-15 20:21:14 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-15 20:21:14 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-15 20:21:14 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-15 20:21:14 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-15 20:21:14 --> Final output sent to browser
DEBUG - 2011-08-15 20:21:14 --> Total execution time: 0.0295
DEBUG - 2011-08-15 20:21:18 --> Config Class Initialized
DEBUG - 2011-08-15 20:21:18 --> Hooks Class Initialized
DEBUG - 2011-08-15 20:21:18 --> Utf8 Class Initialized
DEBUG - 2011-08-15 20:21:18 --> UTF-8 Support Enabled
DEBUG - 2011-08-15 20:21:18 --> URI Class Initialized
DEBUG - 2011-08-15 20:21:18 --> Router Class Initialized
DEBUG - 2011-08-15 20:21:18 --> Output Class Initialized
DEBUG - 2011-08-15 20:21:18 --> Input Class Initialized
DEBUG - 2011-08-15 20:21:18 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-15 20:21:18 --> Language Class Initialized
DEBUG - 2011-08-15 20:21:18 --> Loader Class Initialized
DEBUG - 2011-08-15 20:21:18 --> Controller Class Initialized
ERROR - 2011-08-15 20:21:18 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-15 20:21:18 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-15 20:21:18 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-15 20:21:18 --> Model Class Initialized
DEBUG - 2011-08-15 20:21:18 --> Model Class Initialized
DEBUG - 2011-08-15 20:21:18 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-15 20:21:18 --> Database Driver Class Initialized
DEBUG - 2011-08-15 20:21:18 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-15 20:21:18 --> Helper loaded: url_helper
DEBUG - 2011-08-15 20:21:18 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-15 20:21:18 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-15 20:21:18 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-15 20:21:18 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-15 20:21:18 --> Final output sent to browser
DEBUG - 2011-08-15 20:21:18 --> Total execution time: 0.0307
DEBUG - 2011-08-15 20:21:18 --> Config Class Initialized
DEBUG - 2011-08-15 20:21:18 --> Hooks Class Initialized
DEBUG - 2011-08-15 20:21:18 --> Utf8 Class Initialized
DEBUG - 2011-08-15 20:21:18 --> UTF-8 Support Enabled
DEBUG - 2011-08-15 20:21:18 --> URI Class Initialized
DEBUG - 2011-08-15 20:21:18 --> Router Class Initialized
DEBUG - 2011-08-15 20:21:18 --> Output Class Initialized
DEBUG - 2011-08-15 20:21:18 --> Input Class Initialized
DEBUG - 2011-08-15 20:21:18 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-15 20:21:18 --> Language Class Initialized
DEBUG - 2011-08-15 20:21:18 --> Loader Class Initialized
DEBUG - 2011-08-15 20:21:18 --> Controller Class Initialized
DEBUG - 2011-08-15 20:21:18 --> Model Class Initialized
DEBUG - 2011-08-15 20:21:18 --> Model Class Initialized
DEBUG - 2011-08-15 20:21:18 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-15 20:21:18 --> Database Driver Class Initialized
DEBUG - 2011-08-15 20:21:18 --> Final output sent to browser
DEBUG - 2011-08-15 20:21:18 --> Total execution time: 0.5017
DEBUG - 2011-08-15 20:21:19 --> Config Class Initialized
DEBUG - 2011-08-15 20:21:19 --> Hooks Class Initialized
DEBUG - 2011-08-15 20:21:19 --> Utf8 Class Initialized
DEBUG - 2011-08-15 20:21:19 --> UTF-8 Support Enabled
DEBUG - 2011-08-15 20:21:19 --> URI Class Initialized
DEBUG - 2011-08-15 20:21:19 --> Router Class Initialized
DEBUG - 2011-08-15 20:21:19 --> Output Class Initialized
DEBUG - 2011-08-15 20:21:19 --> Input Class Initialized
DEBUG - 2011-08-15 20:21:19 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-15 20:21:19 --> Language Class Initialized
DEBUG - 2011-08-15 20:21:19 --> Loader Class Initialized
DEBUG - 2011-08-15 20:21:19 --> Controller Class Initialized
ERROR - 2011-08-15 20:21:19 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-15 20:21:19 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-15 20:21:19 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-15 20:21:19 --> Model Class Initialized
DEBUG - 2011-08-15 20:21:19 --> Model Class Initialized
DEBUG - 2011-08-15 20:21:19 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-15 20:21:19 --> Database Driver Class Initialized
DEBUG - 2011-08-15 20:21:19 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-15 20:21:19 --> Helper loaded: url_helper
DEBUG - 2011-08-15 20:21:19 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-15 20:21:19 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-15 20:21:19 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-15 20:21:19 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-15 20:21:19 --> Final output sent to browser
DEBUG - 2011-08-15 20:21:19 --> Total execution time: 0.0289
DEBUG - 2011-08-15 20:21:26 --> Config Class Initialized
DEBUG - 2011-08-15 20:21:26 --> Hooks Class Initialized
DEBUG - 2011-08-15 20:21:26 --> Utf8 Class Initialized
DEBUG - 2011-08-15 20:21:26 --> UTF-8 Support Enabled
DEBUG - 2011-08-15 20:21:26 --> URI Class Initialized
DEBUG - 2011-08-15 20:21:26 --> Router Class Initialized
DEBUG - 2011-08-15 20:21:26 --> Output Class Initialized
DEBUG - 2011-08-15 20:21:26 --> Input Class Initialized
DEBUG - 2011-08-15 20:21:26 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-15 20:21:26 --> Language Class Initialized
DEBUG - 2011-08-15 20:21:26 --> Loader Class Initialized
DEBUG - 2011-08-15 20:21:26 --> Controller Class Initialized
ERROR - 2011-08-15 20:21:26 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-15 20:21:26 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-15 20:21:26 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-15 20:21:26 --> Model Class Initialized
DEBUG - 2011-08-15 20:21:26 --> Model Class Initialized
DEBUG - 2011-08-15 20:21:26 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-15 20:21:26 --> Database Driver Class Initialized
DEBUG - 2011-08-15 20:21:26 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-15 20:21:26 --> Helper loaded: url_helper
DEBUG - 2011-08-15 20:21:26 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-15 20:21:26 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-15 20:21:26 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-15 20:21:26 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-15 20:21:26 --> Final output sent to browser
DEBUG - 2011-08-15 20:21:26 --> Total execution time: 0.0302
DEBUG - 2011-08-15 20:21:26 --> Config Class Initialized
DEBUG - 2011-08-15 20:21:26 --> Hooks Class Initialized
DEBUG - 2011-08-15 20:21:26 --> Utf8 Class Initialized
DEBUG - 2011-08-15 20:21:26 --> UTF-8 Support Enabled
DEBUG - 2011-08-15 20:21:26 --> URI Class Initialized
DEBUG - 2011-08-15 20:21:26 --> Router Class Initialized
DEBUG - 2011-08-15 20:21:26 --> Output Class Initialized
DEBUG - 2011-08-15 20:21:26 --> Input Class Initialized
DEBUG - 2011-08-15 20:21:26 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-15 20:21:26 --> Language Class Initialized
DEBUG - 2011-08-15 20:21:26 --> Loader Class Initialized
DEBUG - 2011-08-15 20:21:26 --> Controller Class Initialized
DEBUG - 2011-08-15 20:21:26 --> Model Class Initialized
DEBUG - 2011-08-15 20:21:26 --> Model Class Initialized
DEBUG - 2011-08-15 20:21:26 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-15 20:21:26 --> Database Driver Class Initialized
DEBUG - 2011-08-15 20:21:26 --> Final output sent to browser
DEBUG - 2011-08-15 20:21:26 --> Total execution time: 0.5694
DEBUG - 2011-08-15 20:21:27 --> Config Class Initialized
DEBUG - 2011-08-15 20:21:27 --> Hooks Class Initialized
DEBUG - 2011-08-15 20:21:27 --> Utf8 Class Initialized
DEBUG - 2011-08-15 20:21:27 --> UTF-8 Support Enabled
DEBUG - 2011-08-15 20:21:27 --> URI Class Initialized
DEBUG - 2011-08-15 20:21:27 --> Router Class Initialized
DEBUG - 2011-08-15 20:21:27 --> Output Class Initialized
DEBUG - 2011-08-15 20:21:27 --> Input Class Initialized
DEBUG - 2011-08-15 20:21:27 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-15 20:21:27 --> Language Class Initialized
DEBUG - 2011-08-15 20:21:27 --> Loader Class Initialized
DEBUG - 2011-08-15 20:21:27 --> Controller Class Initialized
ERROR - 2011-08-15 20:21:27 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-15 20:21:27 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-15 20:21:27 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-15 20:21:27 --> Model Class Initialized
DEBUG - 2011-08-15 20:21:27 --> Model Class Initialized
DEBUG - 2011-08-15 20:21:27 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-15 20:21:27 --> Database Driver Class Initialized
DEBUG - 2011-08-15 20:21:27 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-15 20:21:27 --> Helper loaded: url_helper
DEBUG - 2011-08-15 20:21:27 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-15 20:21:27 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-15 20:21:27 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-15 20:21:27 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-15 20:21:27 --> Final output sent to browser
DEBUG - 2011-08-15 20:21:27 --> Total execution time: 0.0602
DEBUG - 2011-08-15 20:21:31 --> Config Class Initialized
DEBUG - 2011-08-15 20:21:31 --> Hooks Class Initialized
DEBUG - 2011-08-15 20:21:31 --> Utf8 Class Initialized
DEBUG - 2011-08-15 20:21:31 --> UTF-8 Support Enabled
DEBUG - 2011-08-15 20:21:31 --> URI Class Initialized
DEBUG - 2011-08-15 20:21:31 --> Router Class Initialized
DEBUG - 2011-08-15 20:21:31 --> Output Class Initialized
DEBUG - 2011-08-15 20:21:31 --> Input Class Initialized
DEBUG - 2011-08-15 20:21:31 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-15 20:21:31 --> Language Class Initialized
DEBUG - 2011-08-15 20:21:31 --> Loader Class Initialized
DEBUG - 2011-08-15 20:21:31 --> Controller Class Initialized
ERROR - 2011-08-15 20:21:31 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-15 20:21:31 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-15 20:21:31 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-15 20:21:31 --> Model Class Initialized
DEBUG - 2011-08-15 20:21:31 --> Model Class Initialized
DEBUG - 2011-08-15 20:21:31 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-15 20:21:31 --> Database Driver Class Initialized
DEBUG - 2011-08-15 20:21:31 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-15 20:21:31 --> Helper loaded: url_helper
DEBUG - 2011-08-15 20:21:31 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-15 20:21:31 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-15 20:21:31 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-15 20:21:31 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-15 20:21:31 --> Final output sent to browser
DEBUG - 2011-08-15 20:21:31 --> Total execution time: 0.0287
DEBUG - 2011-08-15 20:21:31 --> Config Class Initialized
DEBUG - 2011-08-15 20:21:31 --> Hooks Class Initialized
DEBUG - 2011-08-15 20:21:31 --> Utf8 Class Initialized
DEBUG - 2011-08-15 20:21:31 --> UTF-8 Support Enabled
DEBUG - 2011-08-15 20:21:31 --> URI Class Initialized
DEBUG - 2011-08-15 20:21:31 --> Router Class Initialized
DEBUG - 2011-08-15 20:21:31 --> Output Class Initialized
DEBUG - 2011-08-15 20:21:31 --> Input Class Initialized
DEBUG - 2011-08-15 20:21:31 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-15 20:21:31 --> Language Class Initialized
DEBUG - 2011-08-15 20:21:31 --> Loader Class Initialized
DEBUG - 2011-08-15 20:21:31 --> Controller Class Initialized
DEBUG - 2011-08-15 20:21:31 --> Model Class Initialized
DEBUG - 2011-08-15 20:21:31 --> Model Class Initialized
DEBUG - 2011-08-15 20:21:31 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-15 20:21:31 --> Database Driver Class Initialized
DEBUG - 2011-08-15 20:21:32 --> Final output sent to browser
DEBUG - 2011-08-15 20:21:32 --> Total execution time: 0.5918
DEBUG - 2011-08-15 20:21:32 --> Config Class Initialized
DEBUG - 2011-08-15 20:21:32 --> Hooks Class Initialized
DEBUG - 2011-08-15 20:21:32 --> Utf8 Class Initialized
DEBUG - 2011-08-15 20:21:32 --> UTF-8 Support Enabled
DEBUG - 2011-08-15 20:21:32 --> URI Class Initialized
DEBUG - 2011-08-15 20:21:32 --> Router Class Initialized
DEBUG - 2011-08-15 20:21:32 --> Output Class Initialized
DEBUG - 2011-08-15 20:21:32 --> Input Class Initialized
DEBUG - 2011-08-15 20:21:32 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-15 20:21:32 --> Language Class Initialized
DEBUG - 2011-08-15 20:21:32 --> Loader Class Initialized
DEBUG - 2011-08-15 20:21:32 --> Controller Class Initialized
ERROR - 2011-08-15 20:21:32 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-15 20:21:32 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-15 20:21:32 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-15 20:21:32 --> Model Class Initialized
DEBUG - 2011-08-15 20:21:32 --> Model Class Initialized
DEBUG - 2011-08-15 20:21:32 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-15 20:21:32 --> Database Driver Class Initialized
DEBUG - 2011-08-15 20:21:32 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-15 20:21:32 --> Helper loaded: url_helper
DEBUG - 2011-08-15 20:21:32 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-15 20:21:32 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-15 20:21:32 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-15 20:21:32 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-15 20:21:32 --> Final output sent to browser
DEBUG - 2011-08-15 20:21:32 --> Total execution time: 0.0955
DEBUG - 2011-08-15 20:21:37 --> Config Class Initialized
DEBUG - 2011-08-15 20:21:37 --> Hooks Class Initialized
DEBUG - 2011-08-15 20:21:37 --> Utf8 Class Initialized
DEBUG - 2011-08-15 20:21:37 --> UTF-8 Support Enabled
DEBUG - 2011-08-15 20:21:37 --> URI Class Initialized
DEBUG - 2011-08-15 20:21:37 --> Router Class Initialized
DEBUG - 2011-08-15 20:21:37 --> Output Class Initialized
DEBUG - 2011-08-15 20:21:37 --> Input Class Initialized
DEBUG - 2011-08-15 20:21:37 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-15 20:21:37 --> Language Class Initialized
DEBUG - 2011-08-15 20:21:37 --> Loader Class Initialized
DEBUG - 2011-08-15 20:21:37 --> Controller Class Initialized
ERROR - 2011-08-15 20:21:37 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-15 20:21:37 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-15 20:21:37 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-15 20:21:37 --> Model Class Initialized
DEBUG - 2011-08-15 20:21:37 --> Model Class Initialized
DEBUG - 2011-08-15 20:21:37 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-15 20:21:37 --> Database Driver Class Initialized
DEBUG - 2011-08-15 20:21:37 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-15 20:21:37 --> Helper loaded: url_helper
DEBUG - 2011-08-15 20:21:37 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-15 20:21:37 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-15 20:21:37 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-15 20:21:37 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-15 20:21:37 --> Final output sent to browser
DEBUG - 2011-08-15 20:21:37 --> Total execution time: 0.0288
DEBUG - 2011-08-15 20:21:40 --> Config Class Initialized
DEBUG - 2011-08-15 20:21:40 --> Hooks Class Initialized
DEBUG - 2011-08-15 20:21:40 --> Utf8 Class Initialized
DEBUG - 2011-08-15 20:21:40 --> UTF-8 Support Enabled
DEBUG - 2011-08-15 20:21:40 --> URI Class Initialized
DEBUG - 2011-08-15 20:21:40 --> Router Class Initialized
DEBUG - 2011-08-15 20:21:40 --> Output Class Initialized
DEBUG - 2011-08-15 20:21:40 --> Input Class Initialized
DEBUG - 2011-08-15 20:21:40 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-15 20:21:40 --> Language Class Initialized
DEBUG - 2011-08-15 20:21:40 --> Loader Class Initialized
DEBUG - 2011-08-15 20:21:40 --> Controller Class Initialized
DEBUG - 2011-08-15 20:21:40 --> Model Class Initialized
DEBUG - 2011-08-15 20:21:40 --> Model Class Initialized
DEBUG - 2011-08-15 20:21:40 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-15 20:21:40 --> Database Driver Class Initialized
DEBUG - 2011-08-15 20:21:40 --> Final output sent to browser
DEBUG - 2011-08-15 20:21:40 --> Total execution time: 0.5016
DEBUG - 2011-08-15 20:21:41 --> Config Class Initialized
DEBUG - 2011-08-15 20:21:41 --> Hooks Class Initialized
DEBUG - 2011-08-15 20:21:41 --> Utf8 Class Initialized
DEBUG - 2011-08-15 20:21:41 --> UTF-8 Support Enabled
DEBUG - 2011-08-15 20:21:41 --> URI Class Initialized
DEBUG - 2011-08-15 20:21:41 --> Router Class Initialized
DEBUG - 2011-08-15 20:21:41 --> Output Class Initialized
DEBUG - 2011-08-15 20:21:41 --> Input Class Initialized
DEBUG - 2011-08-15 20:21:41 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-15 20:21:41 --> Language Class Initialized
DEBUG - 2011-08-15 20:21:41 --> Loader Class Initialized
DEBUG - 2011-08-15 20:21:41 --> Controller Class Initialized
ERROR - 2011-08-15 20:21:41 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-15 20:21:41 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-15 20:21:41 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-15 20:21:41 --> Model Class Initialized
DEBUG - 2011-08-15 20:21:41 --> Model Class Initialized
DEBUG - 2011-08-15 20:21:41 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-15 20:21:41 --> Database Driver Class Initialized
DEBUG - 2011-08-15 20:21:41 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-15 20:21:41 --> Helper loaded: url_helper
DEBUG - 2011-08-15 20:21:41 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-15 20:21:41 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-15 20:21:41 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-15 20:21:41 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-15 20:21:41 --> Final output sent to browser
DEBUG - 2011-08-15 20:21:41 --> Total execution time: 0.0303
DEBUG - 2011-08-15 20:21:48 --> Config Class Initialized
DEBUG - 2011-08-15 20:21:48 --> Hooks Class Initialized
DEBUG - 2011-08-15 20:21:48 --> Utf8 Class Initialized
DEBUG - 2011-08-15 20:21:48 --> UTF-8 Support Enabled
DEBUG - 2011-08-15 20:21:48 --> URI Class Initialized
DEBUG - 2011-08-15 20:21:48 --> Router Class Initialized
DEBUG - 2011-08-15 20:21:48 --> Output Class Initialized
DEBUG - 2011-08-15 20:21:48 --> Input Class Initialized
DEBUG - 2011-08-15 20:21:48 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-15 20:21:48 --> Language Class Initialized
DEBUG - 2011-08-15 20:21:48 --> Loader Class Initialized
DEBUG - 2011-08-15 20:21:48 --> Controller Class Initialized
ERROR - 2011-08-15 20:21:48 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-15 20:21:48 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-15 20:21:48 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-15 20:21:48 --> Model Class Initialized
DEBUG - 2011-08-15 20:21:48 --> Model Class Initialized
DEBUG - 2011-08-15 20:21:48 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-15 20:21:48 --> Database Driver Class Initialized
DEBUG - 2011-08-15 20:21:48 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-15 20:21:48 --> Helper loaded: url_helper
DEBUG - 2011-08-15 20:21:48 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-15 20:21:48 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-15 20:21:48 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-15 20:21:48 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-15 20:21:48 --> Final output sent to browser
DEBUG - 2011-08-15 20:21:48 --> Total execution time: 0.0296
DEBUG - 2011-08-15 20:21:48 --> Config Class Initialized
DEBUG - 2011-08-15 20:21:48 --> Hooks Class Initialized
DEBUG - 2011-08-15 20:21:48 --> Utf8 Class Initialized
DEBUG - 2011-08-15 20:21:48 --> UTF-8 Support Enabled
DEBUG - 2011-08-15 20:21:48 --> URI Class Initialized
DEBUG - 2011-08-15 20:21:48 --> Router Class Initialized
DEBUG - 2011-08-15 20:21:48 --> Output Class Initialized
DEBUG - 2011-08-15 20:21:48 --> Input Class Initialized
DEBUG - 2011-08-15 20:21:48 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-15 20:21:48 --> Language Class Initialized
DEBUG - 2011-08-15 20:21:48 --> Loader Class Initialized
DEBUG - 2011-08-15 20:21:48 --> Controller Class Initialized
DEBUG - 2011-08-15 20:21:48 --> Model Class Initialized
DEBUG - 2011-08-15 20:21:48 --> Model Class Initialized
DEBUG - 2011-08-15 20:21:48 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-15 20:21:48 --> Database Driver Class Initialized
DEBUG - 2011-08-15 20:21:49 --> Final output sent to browser
DEBUG - 2011-08-15 20:21:49 --> Total execution time: 0.6490
DEBUG - 2011-08-15 20:21:49 --> Config Class Initialized
DEBUG - 2011-08-15 20:21:49 --> Hooks Class Initialized
DEBUG - 2011-08-15 20:21:49 --> Utf8 Class Initialized
DEBUG - 2011-08-15 20:21:49 --> UTF-8 Support Enabled
DEBUG - 2011-08-15 20:21:49 --> URI Class Initialized
DEBUG - 2011-08-15 20:21:49 --> Router Class Initialized
DEBUG - 2011-08-15 20:21:49 --> Output Class Initialized
DEBUG - 2011-08-15 20:21:49 --> Input Class Initialized
DEBUG - 2011-08-15 20:21:49 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-15 20:21:49 --> Language Class Initialized
DEBUG - 2011-08-15 20:21:49 --> Loader Class Initialized
DEBUG - 2011-08-15 20:21:49 --> Controller Class Initialized
ERROR - 2011-08-15 20:21:49 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-15 20:21:49 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-15 20:21:49 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-15 20:21:49 --> Model Class Initialized
DEBUG - 2011-08-15 20:21:49 --> Model Class Initialized
DEBUG - 2011-08-15 20:21:49 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-15 20:21:49 --> Database Driver Class Initialized
DEBUG - 2011-08-15 20:21:49 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-15 20:21:49 --> Helper loaded: url_helper
DEBUG - 2011-08-15 20:21:49 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-15 20:21:49 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-15 20:21:49 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-15 20:21:49 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-15 20:21:49 --> Final output sent to browser
DEBUG - 2011-08-15 20:21:49 --> Total execution time: 0.0346
DEBUG - 2011-08-15 20:22:10 --> Config Class Initialized
DEBUG - 2011-08-15 20:22:10 --> Hooks Class Initialized
DEBUG - 2011-08-15 20:22:10 --> Utf8 Class Initialized
DEBUG - 2011-08-15 20:22:10 --> UTF-8 Support Enabled
DEBUG - 2011-08-15 20:22:10 --> URI Class Initialized
DEBUG - 2011-08-15 20:22:10 --> Router Class Initialized
DEBUG - 2011-08-15 20:22:10 --> Output Class Initialized
DEBUG - 2011-08-15 20:22:10 --> Input Class Initialized
DEBUG - 2011-08-15 20:22:10 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-15 20:22:10 --> Language Class Initialized
DEBUG - 2011-08-15 20:22:10 --> Loader Class Initialized
DEBUG - 2011-08-15 20:22:10 --> Controller Class Initialized
ERROR - 2011-08-15 20:22:10 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-15 20:22:10 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-15 20:22:10 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-15 20:22:10 --> Model Class Initialized
DEBUG - 2011-08-15 20:22:10 --> Model Class Initialized
DEBUG - 2011-08-15 20:22:10 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-15 20:22:10 --> Database Driver Class Initialized
DEBUG - 2011-08-15 20:22:10 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-15 20:22:10 --> Helper loaded: url_helper
DEBUG - 2011-08-15 20:22:10 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-15 20:22:10 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-15 20:22:10 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-15 20:22:10 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-15 20:22:10 --> Final output sent to browser
DEBUG - 2011-08-15 20:22:10 --> Total execution time: 0.0328
DEBUG - 2011-08-15 20:22:10 --> Config Class Initialized
DEBUG - 2011-08-15 20:22:10 --> Hooks Class Initialized
DEBUG - 2011-08-15 20:22:10 --> Utf8 Class Initialized
DEBUG - 2011-08-15 20:22:10 --> UTF-8 Support Enabled
DEBUG - 2011-08-15 20:22:10 --> URI Class Initialized
DEBUG - 2011-08-15 20:22:10 --> Router Class Initialized
DEBUG - 2011-08-15 20:22:10 --> Output Class Initialized
DEBUG - 2011-08-15 20:22:10 --> Input Class Initialized
DEBUG - 2011-08-15 20:22:10 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-15 20:22:10 --> Language Class Initialized
DEBUG - 2011-08-15 20:22:10 --> Loader Class Initialized
DEBUG - 2011-08-15 20:22:10 --> Controller Class Initialized
DEBUG - 2011-08-15 20:22:10 --> Model Class Initialized
DEBUG - 2011-08-15 20:22:10 --> Model Class Initialized
DEBUG - 2011-08-15 20:22:10 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-15 20:22:10 --> Database Driver Class Initialized
DEBUG - 2011-08-15 20:22:11 --> Final output sent to browser
DEBUG - 2011-08-15 20:22:11 --> Total execution time: 0.6452
DEBUG - 2011-08-15 20:22:11 --> Config Class Initialized
DEBUG - 2011-08-15 20:22:11 --> Hooks Class Initialized
DEBUG - 2011-08-15 20:22:11 --> Utf8 Class Initialized
DEBUG - 2011-08-15 20:22:11 --> UTF-8 Support Enabled
DEBUG - 2011-08-15 20:22:11 --> URI Class Initialized
DEBUG - 2011-08-15 20:22:11 --> Router Class Initialized
DEBUG - 2011-08-15 20:22:11 --> Output Class Initialized
DEBUG - 2011-08-15 20:22:11 --> Input Class Initialized
DEBUG - 2011-08-15 20:22:11 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-15 20:22:11 --> Language Class Initialized
DEBUG - 2011-08-15 20:22:11 --> Loader Class Initialized
DEBUG - 2011-08-15 20:22:11 --> Controller Class Initialized
ERROR - 2011-08-15 20:22:11 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-15 20:22:11 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-15 20:22:11 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-15 20:22:11 --> Model Class Initialized
DEBUG - 2011-08-15 20:22:11 --> Model Class Initialized
DEBUG - 2011-08-15 20:22:11 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-15 20:22:11 --> Database Driver Class Initialized
DEBUG - 2011-08-15 20:22:12 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-15 20:22:12 --> Helper loaded: url_helper
DEBUG - 2011-08-15 20:22:12 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-15 20:22:12 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-15 20:22:12 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-15 20:22:12 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-15 20:22:12 --> Final output sent to browser
DEBUG - 2011-08-15 20:22:12 --> Total execution time: 0.0298
DEBUG - 2011-08-15 20:22:18 --> Config Class Initialized
DEBUG - 2011-08-15 20:22:18 --> Hooks Class Initialized
DEBUG - 2011-08-15 20:22:18 --> Utf8 Class Initialized
DEBUG - 2011-08-15 20:22:18 --> UTF-8 Support Enabled
DEBUG - 2011-08-15 20:22:18 --> URI Class Initialized
DEBUG - 2011-08-15 20:22:18 --> Router Class Initialized
DEBUG - 2011-08-15 20:22:18 --> Output Class Initialized
DEBUG - 2011-08-15 20:22:18 --> Input Class Initialized
DEBUG - 2011-08-15 20:22:18 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-15 20:22:18 --> Language Class Initialized
DEBUG - 2011-08-15 20:22:18 --> Loader Class Initialized
DEBUG - 2011-08-15 20:22:18 --> Controller Class Initialized
ERROR - 2011-08-15 20:22:18 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-15 20:22:18 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-15 20:22:18 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-15 20:22:18 --> Model Class Initialized
DEBUG - 2011-08-15 20:22:18 --> Model Class Initialized
DEBUG - 2011-08-15 20:22:18 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-15 20:22:18 --> Database Driver Class Initialized
DEBUG - 2011-08-15 20:22:18 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-15 20:22:18 --> Helper loaded: url_helper
DEBUG - 2011-08-15 20:22:18 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-15 20:22:18 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-15 20:22:18 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-15 20:22:18 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-15 20:22:18 --> Final output sent to browser
DEBUG - 2011-08-15 20:22:18 --> Total execution time: 0.0333
DEBUG - 2011-08-15 20:22:18 --> Config Class Initialized
DEBUG - 2011-08-15 20:22:18 --> Hooks Class Initialized
DEBUG - 2011-08-15 20:22:18 --> Utf8 Class Initialized
DEBUG - 2011-08-15 20:22:18 --> UTF-8 Support Enabled
DEBUG - 2011-08-15 20:22:18 --> URI Class Initialized
DEBUG - 2011-08-15 20:22:18 --> Router Class Initialized
DEBUG - 2011-08-15 20:22:18 --> Output Class Initialized
DEBUG - 2011-08-15 20:22:18 --> Input Class Initialized
DEBUG - 2011-08-15 20:22:18 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-15 20:22:18 --> Language Class Initialized
DEBUG - 2011-08-15 20:22:18 --> Loader Class Initialized
DEBUG - 2011-08-15 20:22:18 --> Controller Class Initialized
DEBUG - 2011-08-15 20:22:18 --> Model Class Initialized
DEBUG - 2011-08-15 20:22:18 --> Model Class Initialized
DEBUG - 2011-08-15 20:22:18 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-15 20:22:18 --> Database Driver Class Initialized
DEBUG - 2011-08-15 20:22:19 --> Final output sent to browser
DEBUG - 2011-08-15 20:22:19 --> Total execution time: 0.6039
DEBUG - 2011-08-15 20:23:05 --> Config Class Initialized
DEBUG - 2011-08-15 20:23:05 --> Hooks Class Initialized
DEBUG - 2011-08-15 20:23:05 --> Utf8 Class Initialized
DEBUG - 2011-08-15 20:23:05 --> UTF-8 Support Enabled
DEBUG - 2011-08-15 20:23:05 --> URI Class Initialized
DEBUG - 2011-08-15 20:23:05 --> Router Class Initialized
DEBUG - 2011-08-15 20:23:05 --> Output Class Initialized
DEBUG - 2011-08-15 20:23:05 --> Input Class Initialized
DEBUG - 2011-08-15 20:23:05 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-15 20:23:05 --> Language Class Initialized
DEBUG - 2011-08-15 20:23:05 --> Loader Class Initialized
DEBUG - 2011-08-15 20:23:05 --> Controller Class Initialized
ERROR - 2011-08-15 20:23:05 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-15 20:23:05 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-15 20:23:05 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-15 20:23:05 --> Model Class Initialized
DEBUG - 2011-08-15 20:23:05 --> Model Class Initialized
DEBUG - 2011-08-15 20:23:05 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-15 20:23:05 --> Database Driver Class Initialized
DEBUG - 2011-08-15 20:23:05 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-15 20:23:05 --> Helper loaded: url_helper
DEBUG - 2011-08-15 20:23:05 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-15 20:23:05 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-15 20:23:05 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-15 20:23:05 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-15 20:23:05 --> Final output sent to browser
DEBUG - 2011-08-15 20:23:05 --> Total execution time: 0.0315
DEBUG - 2011-08-15 20:23:35 --> Config Class Initialized
DEBUG - 2011-08-15 20:23:35 --> Hooks Class Initialized
DEBUG - 2011-08-15 20:23:35 --> Utf8 Class Initialized
DEBUG - 2011-08-15 20:23:35 --> UTF-8 Support Enabled
DEBUG - 2011-08-15 20:23:35 --> URI Class Initialized
DEBUG - 2011-08-15 20:23:35 --> Router Class Initialized
DEBUG - 2011-08-15 20:23:35 --> Output Class Initialized
DEBUG - 2011-08-15 20:23:35 --> Input Class Initialized
DEBUG - 2011-08-15 20:23:35 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-15 20:23:35 --> Language Class Initialized
DEBUG - 2011-08-15 20:23:35 --> Loader Class Initialized
DEBUG - 2011-08-15 20:23:35 --> Controller Class Initialized
ERROR - 2011-08-15 20:23:35 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-15 20:23:35 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-15 20:23:35 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-15 20:23:35 --> Model Class Initialized
DEBUG - 2011-08-15 20:23:35 --> Model Class Initialized
DEBUG - 2011-08-15 20:23:35 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-15 20:23:35 --> Database Driver Class Initialized
DEBUG - 2011-08-15 20:23:35 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-15 20:23:35 --> Helper loaded: url_helper
DEBUG - 2011-08-15 20:23:35 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-15 20:23:35 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-15 20:23:35 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-15 20:23:35 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-15 20:23:35 --> Final output sent to browser
DEBUG - 2011-08-15 20:23:35 --> Total execution time: 0.0615
DEBUG - 2011-08-15 20:23:35 --> Config Class Initialized
DEBUG - 2011-08-15 20:23:35 --> Hooks Class Initialized
DEBUG - 2011-08-15 20:23:35 --> Utf8 Class Initialized
DEBUG - 2011-08-15 20:23:35 --> UTF-8 Support Enabled
DEBUG - 2011-08-15 20:23:35 --> URI Class Initialized
DEBUG - 2011-08-15 20:23:35 --> Router Class Initialized
DEBUG - 2011-08-15 20:23:35 --> Output Class Initialized
DEBUG - 2011-08-15 20:23:35 --> Input Class Initialized
DEBUG - 2011-08-15 20:23:35 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-15 20:23:35 --> Language Class Initialized
DEBUG - 2011-08-15 20:23:35 --> Loader Class Initialized
DEBUG - 2011-08-15 20:23:35 --> Controller Class Initialized
DEBUG - 2011-08-15 20:23:35 --> Model Class Initialized
DEBUG - 2011-08-15 20:23:35 --> Model Class Initialized
DEBUG - 2011-08-15 20:23:35 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-15 20:23:35 --> Database Driver Class Initialized
DEBUG - 2011-08-15 20:23:36 --> Final output sent to browser
DEBUG - 2011-08-15 20:23:36 --> Total execution time: 0.4964
DEBUG - 2011-08-15 20:23:37 --> Config Class Initialized
DEBUG - 2011-08-15 20:23:37 --> Hooks Class Initialized
DEBUG - 2011-08-15 20:23:37 --> Utf8 Class Initialized
DEBUG - 2011-08-15 20:23:37 --> UTF-8 Support Enabled
DEBUG - 2011-08-15 20:23:37 --> URI Class Initialized
DEBUG - 2011-08-15 20:23:37 --> Router Class Initialized
DEBUG - 2011-08-15 20:23:37 --> Output Class Initialized
DEBUG - 2011-08-15 20:23:37 --> Input Class Initialized
DEBUG - 2011-08-15 20:23:37 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-15 20:23:37 --> Language Class Initialized
DEBUG - 2011-08-15 20:23:37 --> Loader Class Initialized
DEBUG - 2011-08-15 20:23:37 --> Controller Class Initialized
ERROR - 2011-08-15 20:23:37 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-15 20:23:37 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-15 20:23:37 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-15 20:23:37 --> Model Class Initialized
DEBUG - 2011-08-15 20:23:37 --> Model Class Initialized
DEBUG - 2011-08-15 20:23:37 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-15 20:23:37 --> Database Driver Class Initialized
DEBUG - 2011-08-15 20:23:37 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-15 20:23:37 --> Helper loaded: url_helper
DEBUG - 2011-08-15 20:23:37 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-15 20:23:37 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-15 20:23:37 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-15 20:23:37 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-15 20:23:37 --> Final output sent to browser
DEBUG - 2011-08-15 20:23:37 --> Total execution time: 0.0327
DEBUG - 2011-08-15 20:23:47 --> Config Class Initialized
DEBUG - 2011-08-15 20:23:47 --> Hooks Class Initialized
DEBUG - 2011-08-15 20:23:47 --> Utf8 Class Initialized
DEBUG - 2011-08-15 20:23:47 --> UTF-8 Support Enabled
DEBUG - 2011-08-15 20:23:47 --> URI Class Initialized
DEBUG - 2011-08-15 20:23:47 --> Router Class Initialized
DEBUG - 2011-08-15 20:23:47 --> Output Class Initialized
DEBUG - 2011-08-15 20:23:47 --> Input Class Initialized
DEBUG - 2011-08-15 20:23:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-15 20:23:47 --> Language Class Initialized
DEBUG - 2011-08-15 20:23:47 --> Loader Class Initialized
DEBUG - 2011-08-15 20:23:47 --> Controller Class Initialized
ERROR - 2011-08-15 20:23:47 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-15 20:23:47 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-15 20:23:47 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-15 20:23:47 --> Model Class Initialized
DEBUG - 2011-08-15 20:23:47 --> Model Class Initialized
DEBUG - 2011-08-15 20:23:47 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-15 20:23:47 --> Database Driver Class Initialized
DEBUG - 2011-08-15 20:23:47 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-15 20:23:47 --> Helper loaded: url_helper
DEBUG - 2011-08-15 20:23:47 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-15 20:23:47 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-15 20:23:47 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-15 20:23:47 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-15 20:23:47 --> Final output sent to browser
DEBUG - 2011-08-15 20:23:47 --> Total execution time: 0.0336
DEBUG - 2011-08-15 20:23:47 --> Config Class Initialized
DEBUG - 2011-08-15 20:23:47 --> Hooks Class Initialized
DEBUG - 2011-08-15 20:23:47 --> Utf8 Class Initialized
DEBUG - 2011-08-15 20:23:47 --> UTF-8 Support Enabled
DEBUG - 2011-08-15 20:23:47 --> URI Class Initialized
DEBUG - 2011-08-15 20:23:47 --> Router Class Initialized
DEBUG - 2011-08-15 20:23:47 --> Output Class Initialized
DEBUG - 2011-08-15 20:23:47 --> Input Class Initialized
DEBUG - 2011-08-15 20:23:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-15 20:23:47 --> Language Class Initialized
DEBUG - 2011-08-15 20:23:47 --> Loader Class Initialized
DEBUG - 2011-08-15 20:23:47 --> Controller Class Initialized
DEBUG - 2011-08-15 20:23:47 --> Model Class Initialized
DEBUG - 2011-08-15 20:23:47 --> Model Class Initialized
DEBUG - 2011-08-15 20:23:47 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-15 20:23:47 --> Database Driver Class Initialized
DEBUG - 2011-08-15 20:23:48 --> Final output sent to browser
DEBUG - 2011-08-15 20:23:48 --> Total execution time: 0.7614
DEBUG - 2011-08-15 20:23:57 --> Config Class Initialized
DEBUG - 2011-08-15 20:23:57 --> Hooks Class Initialized
DEBUG - 2011-08-15 20:23:57 --> Utf8 Class Initialized
DEBUG - 2011-08-15 20:23:57 --> UTF-8 Support Enabled
DEBUG - 2011-08-15 20:23:57 --> URI Class Initialized
DEBUG - 2011-08-15 20:23:57 --> Router Class Initialized
DEBUG - 2011-08-15 20:23:57 --> Output Class Initialized
DEBUG - 2011-08-15 20:23:57 --> Input Class Initialized
DEBUG - 2011-08-15 20:23:57 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-15 20:23:57 --> Language Class Initialized
DEBUG - 2011-08-15 20:23:57 --> Loader Class Initialized
DEBUG - 2011-08-15 20:23:57 --> Controller Class Initialized
ERROR - 2011-08-15 20:23:57 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-15 20:23:57 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-15 20:23:57 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-15 20:23:57 --> Model Class Initialized
DEBUG - 2011-08-15 20:23:57 --> Model Class Initialized
DEBUG - 2011-08-15 20:23:57 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-15 20:23:57 --> Database Driver Class Initialized
DEBUG - 2011-08-15 20:23:57 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-15 20:23:57 --> Helper loaded: url_helper
DEBUG - 2011-08-15 20:23:57 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-15 20:23:57 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-15 20:23:57 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-15 20:23:57 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-15 20:23:57 --> Final output sent to browser
DEBUG - 2011-08-15 20:23:57 --> Total execution time: 0.0386
DEBUG - 2011-08-15 20:23:58 --> Config Class Initialized
DEBUG - 2011-08-15 20:23:58 --> Hooks Class Initialized
DEBUG - 2011-08-15 20:23:58 --> Utf8 Class Initialized
DEBUG - 2011-08-15 20:23:58 --> UTF-8 Support Enabled
DEBUG - 2011-08-15 20:23:58 --> URI Class Initialized
DEBUG - 2011-08-15 20:23:58 --> Router Class Initialized
DEBUG - 2011-08-15 20:23:58 --> Output Class Initialized
DEBUG - 2011-08-15 20:23:58 --> Input Class Initialized
DEBUG - 2011-08-15 20:23:58 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-15 20:23:58 --> Language Class Initialized
DEBUG - 2011-08-15 20:23:58 --> Loader Class Initialized
DEBUG - 2011-08-15 20:23:58 --> Controller Class Initialized
DEBUG - 2011-08-15 20:23:58 --> Model Class Initialized
DEBUG - 2011-08-15 20:23:58 --> Model Class Initialized
DEBUG - 2011-08-15 20:23:58 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-15 20:23:58 --> Database Driver Class Initialized
DEBUG - 2011-08-15 20:23:58 --> Final output sent to browser
DEBUG - 2011-08-15 20:23:58 --> Total execution time: 0.7062
DEBUG - 2011-08-15 20:24:00 --> Config Class Initialized
DEBUG - 2011-08-15 20:24:00 --> Hooks Class Initialized
DEBUG - 2011-08-15 20:24:00 --> Utf8 Class Initialized
DEBUG - 2011-08-15 20:24:00 --> UTF-8 Support Enabled
DEBUG - 2011-08-15 20:24:00 --> URI Class Initialized
DEBUG - 2011-08-15 20:24:00 --> Router Class Initialized
DEBUG - 2011-08-15 20:24:00 --> Output Class Initialized
DEBUG - 2011-08-15 20:24:00 --> Input Class Initialized
DEBUG - 2011-08-15 20:24:00 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-15 20:24:00 --> Language Class Initialized
DEBUG - 2011-08-15 20:24:00 --> Loader Class Initialized
DEBUG - 2011-08-15 20:24:00 --> Controller Class Initialized
ERROR - 2011-08-15 20:24:00 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-15 20:24:00 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-15 20:24:00 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-15 20:24:00 --> Model Class Initialized
DEBUG - 2011-08-15 20:24:00 --> Model Class Initialized
DEBUG - 2011-08-15 20:24:00 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-15 20:24:00 --> Database Driver Class Initialized
DEBUG - 2011-08-15 20:24:00 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-15 20:24:00 --> Helper loaded: url_helper
DEBUG - 2011-08-15 20:24:00 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-15 20:24:00 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-15 20:24:00 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-15 20:24:00 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-15 20:24:00 --> Final output sent to browser
DEBUG - 2011-08-15 20:24:00 --> Total execution time: 0.0298
DEBUG - 2011-08-15 20:24:14 --> Config Class Initialized
DEBUG - 2011-08-15 20:24:14 --> Hooks Class Initialized
DEBUG - 2011-08-15 20:24:14 --> Utf8 Class Initialized
DEBUG - 2011-08-15 20:24:14 --> UTF-8 Support Enabled
DEBUG - 2011-08-15 20:24:14 --> URI Class Initialized
DEBUG - 2011-08-15 20:24:14 --> Router Class Initialized
DEBUG - 2011-08-15 20:24:14 --> Output Class Initialized
DEBUG - 2011-08-15 20:24:14 --> Input Class Initialized
DEBUG - 2011-08-15 20:24:14 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-15 20:24:14 --> Language Class Initialized
DEBUG - 2011-08-15 20:24:14 --> Loader Class Initialized
DEBUG - 2011-08-15 20:24:14 --> Controller Class Initialized
ERROR - 2011-08-15 20:24:14 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-15 20:24:14 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-15 20:24:14 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-15 20:24:14 --> Model Class Initialized
DEBUG - 2011-08-15 20:24:14 --> Model Class Initialized
DEBUG - 2011-08-15 20:24:14 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-15 20:24:14 --> Database Driver Class Initialized
DEBUG - 2011-08-15 20:24:14 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-15 20:24:14 --> Helper loaded: url_helper
DEBUG - 2011-08-15 20:24:14 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-15 20:24:14 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-15 20:24:14 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-15 20:24:14 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-15 20:24:14 --> Final output sent to browser
DEBUG - 2011-08-15 20:24:14 --> Total execution time: 0.0294
DEBUG - 2011-08-15 20:24:15 --> Config Class Initialized
DEBUG - 2011-08-15 20:24:15 --> Hooks Class Initialized
DEBUG - 2011-08-15 20:24:15 --> Utf8 Class Initialized
DEBUG - 2011-08-15 20:24:15 --> UTF-8 Support Enabled
DEBUG - 2011-08-15 20:24:15 --> URI Class Initialized
DEBUG - 2011-08-15 20:24:15 --> Router Class Initialized
DEBUG - 2011-08-15 20:24:15 --> Output Class Initialized
DEBUG - 2011-08-15 20:24:15 --> Input Class Initialized
DEBUG - 2011-08-15 20:24:15 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-15 20:24:15 --> Language Class Initialized
DEBUG - 2011-08-15 20:24:15 --> Loader Class Initialized
DEBUG - 2011-08-15 20:24:15 --> Controller Class Initialized
DEBUG - 2011-08-15 20:24:15 --> Model Class Initialized
DEBUG - 2011-08-15 20:24:15 --> Model Class Initialized
DEBUG - 2011-08-15 20:24:15 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-15 20:24:15 --> Database Driver Class Initialized
DEBUG - 2011-08-15 20:24:16 --> Final output sent to browser
DEBUG - 2011-08-15 20:24:16 --> Total execution time: 0.5011
DEBUG - 2011-08-15 20:24:21 --> Config Class Initialized
DEBUG - 2011-08-15 20:24:21 --> Hooks Class Initialized
DEBUG - 2011-08-15 20:24:21 --> Utf8 Class Initialized
DEBUG - 2011-08-15 20:24:21 --> UTF-8 Support Enabled
DEBUG - 2011-08-15 20:24:21 --> URI Class Initialized
DEBUG - 2011-08-15 20:24:21 --> Router Class Initialized
DEBUG - 2011-08-15 20:24:21 --> Output Class Initialized
DEBUG - 2011-08-15 20:24:21 --> Input Class Initialized
DEBUG - 2011-08-15 20:24:21 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-15 20:24:21 --> Language Class Initialized
DEBUG - 2011-08-15 20:24:21 --> Loader Class Initialized
DEBUG - 2011-08-15 20:24:21 --> Controller Class Initialized
ERROR - 2011-08-15 20:24:21 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-15 20:24:21 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-15 20:24:21 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-15 20:24:21 --> Model Class Initialized
DEBUG - 2011-08-15 20:24:21 --> Model Class Initialized
DEBUG - 2011-08-15 20:24:21 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-15 20:24:21 --> Database Driver Class Initialized
DEBUG - 2011-08-15 20:24:21 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-15 20:24:21 --> Helper loaded: url_helper
DEBUG - 2011-08-15 20:24:21 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-15 20:24:21 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-15 20:24:21 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-15 20:24:21 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-15 20:24:21 --> Final output sent to browser
DEBUG - 2011-08-15 20:24:21 --> Total execution time: 0.0312
DEBUG - 2011-08-15 20:24:22 --> Config Class Initialized
DEBUG - 2011-08-15 20:24:22 --> Hooks Class Initialized
DEBUG - 2011-08-15 20:24:22 --> Utf8 Class Initialized
DEBUG - 2011-08-15 20:24:22 --> UTF-8 Support Enabled
DEBUG - 2011-08-15 20:24:22 --> URI Class Initialized
DEBUG - 2011-08-15 20:24:22 --> Router Class Initialized
DEBUG - 2011-08-15 20:24:22 --> Output Class Initialized
DEBUG - 2011-08-15 20:24:22 --> Input Class Initialized
DEBUG - 2011-08-15 20:24:22 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-15 20:24:22 --> Language Class Initialized
DEBUG - 2011-08-15 20:24:22 --> Loader Class Initialized
DEBUG - 2011-08-15 20:24:22 --> Controller Class Initialized
DEBUG - 2011-08-15 20:24:22 --> Model Class Initialized
DEBUG - 2011-08-15 20:24:22 --> Model Class Initialized
DEBUG - 2011-08-15 20:24:22 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-15 20:24:22 --> Database Driver Class Initialized
DEBUG - 2011-08-15 20:24:22 --> Final output sent to browser
DEBUG - 2011-08-15 20:24:22 --> Total execution time: 0.6062
DEBUG - 2011-08-15 20:24:28 --> Config Class Initialized
DEBUG - 2011-08-15 20:24:28 --> Hooks Class Initialized
DEBUG - 2011-08-15 20:24:28 --> Utf8 Class Initialized
DEBUG - 2011-08-15 20:24:28 --> UTF-8 Support Enabled
DEBUG - 2011-08-15 20:24:28 --> URI Class Initialized
DEBUG - 2011-08-15 20:24:28 --> Router Class Initialized
DEBUG - 2011-08-15 20:24:28 --> Output Class Initialized
DEBUG - 2011-08-15 20:24:28 --> Input Class Initialized
DEBUG - 2011-08-15 20:24:28 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-15 20:24:28 --> Language Class Initialized
DEBUG - 2011-08-15 20:24:28 --> Loader Class Initialized
DEBUG - 2011-08-15 20:24:28 --> Controller Class Initialized
ERROR - 2011-08-15 20:24:28 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-15 20:24:28 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-15 20:24:28 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-15 20:24:28 --> Model Class Initialized
DEBUG - 2011-08-15 20:24:28 --> Model Class Initialized
DEBUG - 2011-08-15 20:24:28 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-15 20:24:28 --> Database Driver Class Initialized
DEBUG - 2011-08-15 20:24:28 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-15 20:24:28 --> Helper loaded: url_helper
DEBUG - 2011-08-15 20:24:28 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-15 20:24:28 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-15 20:24:28 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-15 20:24:28 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-15 20:24:28 --> Final output sent to browser
DEBUG - 2011-08-15 20:24:28 --> Total execution time: 0.0274
DEBUG - 2011-08-15 20:24:28 --> Config Class Initialized
DEBUG - 2011-08-15 20:24:28 --> Hooks Class Initialized
DEBUG - 2011-08-15 20:24:28 --> Utf8 Class Initialized
DEBUG - 2011-08-15 20:24:28 --> UTF-8 Support Enabled
DEBUG - 2011-08-15 20:24:28 --> URI Class Initialized
DEBUG - 2011-08-15 20:24:28 --> Router Class Initialized
DEBUG - 2011-08-15 20:24:28 --> Output Class Initialized
DEBUG - 2011-08-15 20:24:28 --> Input Class Initialized
DEBUG - 2011-08-15 20:24:28 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-15 20:24:28 --> Language Class Initialized
DEBUG - 2011-08-15 20:24:28 --> Loader Class Initialized
DEBUG - 2011-08-15 20:24:28 --> Controller Class Initialized
DEBUG - 2011-08-15 20:24:28 --> Model Class Initialized
DEBUG - 2011-08-15 20:24:28 --> Model Class Initialized
DEBUG - 2011-08-15 20:24:28 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-15 20:24:28 --> Database Driver Class Initialized
DEBUG - 2011-08-15 20:24:29 --> Final output sent to browser
DEBUG - 2011-08-15 20:24:29 --> Total execution time: 0.5208
DEBUG - 2011-08-15 20:24:29 --> Config Class Initialized
DEBUG - 2011-08-15 20:24:29 --> Hooks Class Initialized
DEBUG - 2011-08-15 20:24:29 --> Utf8 Class Initialized
DEBUG - 2011-08-15 20:24:29 --> UTF-8 Support Enabled
DEBUG - 2011-08-15 20:24:29 --> URI Class Initialized
DEBUG - 2011-08-15 20:24:29 --> Router Class Initialized
DEBUG - 2011-08-15 20:24:29 --> Output Class Initialized
DEBUG - 2011-08-15 20:24:29 --> Input Class Initialized
DEBUG - 2011-08-15 20:24:29 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-15 20:24:29 --> Language Class Initialized
DEBUG - 2011-08-15 20:24:29 --> Loader Class Initialized
DEBUG - 2011-08-15 20:24:29 --> Controller Class Initialized
ERROR - 2011-08-15 20:24:29 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-15 20:24:29 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-15 20:24:29 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-15 20:24:29 --> Model Class Initialized
DEBUG - 2011-08-15 20:24:29 --> Model Class Initialized
DEBUG - 2011-08-15 20:24:29 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-15 20:24:29 --> Database Driver Class Initialized
DEBUG - 2011-08-15 20:24:29 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-15 20:24:29 --> Helper loaded: url_helper
DEBUG - 2011-08-15 20:24:29 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-15 20:24:29 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-15 20:24:29 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-15 20:24:29 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-15 20:24:29 --> Final output sent to browser
DEBUG - 2011-08-15 20:24:29 --> Total execution time: 0.0332
DEBUG - 2011-08-15 20:33:22 --> Config Class Initialized
DEBUG - 2011-08-15 20:33:22 --> Hooks Class Initialized
DEBUG - 2011-08-15 20:33:22 --> Utf8 Class Initialized
DEBUG - 2011-08-15 20:33:22 --> UTF-8 Support Enabled
DEBUG - 2011-08-15 20:33:22 --> URI Class Initialized
DEBUG - 2011-08-15 20:33:22 --> Router Class Initialized
DEBUG - 2011-08-15 20:33:22 --> Output Class Initialized
DEBUG - 2011-08-15 20:33:22 --> Input Class Initialized
DEBUG - 2011-08-15 20:33:22 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-15 20:33:22 --> Language Class Initialized
DEBUG - 2011-08-15 20:33:22 --> Loader Class Initialized
DEBUG - 2011-08-15 20:33:22 --> Controller Class Initialized
ERROR - 2011-08-15 20:33:22 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-15 20:33:22 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-15 20:33:22 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-15 20:33:22 --> Model Class Initialized
DEBUG - 2011-08-15 20:33:22 --> Model Class Initialized
DEBUG - 2011-08-15 20:33:22 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-15 20:33:22 --> Database Driver Class Initialized
DEBUG - 2011-08-15 20:33:22 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-15 20:33:22 --> Helper loaded: url_helper
DEBUG - 2011-08-15 20:33:22 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-15 20:33:22 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-15 20:33:22 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-15 20:33:22 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-15 20:33:22 --> Final output sent to browser
DEBUG - 2011-08-15 20:33:22 --> Total execution time: 0.0305
DEBUG - 2011-08-15 20:33:23 --> Config Class Initialized
DEBUG - 2011-08-15 20:33:23 --> Hooks Class Initialized
DEBUG - 2011-08-15 20:33:23 --> Utf8 Class Initialized
DEBUG - 2011-08-15 20:33:23 --> UTF-8 Support Enabled
DEBUG - 2011-08-15 20:33:23 --> URI Class Initialized
DEBUG - 2011-08-15 20:33:23 --> Router Class Initialized
DEBUG - 2011-08-15 20:33:23 --> Output Class Initialized
DEBUG - 2011-08-15 20:33:23 --> Input Class Initialized
DEBUG - 2011-08-15 20:33:23 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-15 20:33:23 --> Language Class Initialized
DEBUG - 2011-08-15 20:33:23 --> Loader Class Initialized
DEBUG - 2011-08-15 20:33:23 --> Controller Class Initialized
DEBUG - 2011-08-15 20:33:23 --> Model Class Initialized
DEBUG - 2011-08-15 20:33:23 --> Model Class Initialized
DEBUG - 2011-08-15 20:33:23 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-15 20:33:23 --> Database Driver Class Initialized
DEBUG - 2011-08-15 20:33:23 --> Final output sent to browser
DEBUG - 2011-08-15 20:33:23 --> Total execution time: 0.5438
DEBUG - 2011-08-15 21:03:16 --> Config Class Initialized
DEBUG - 2011-08-15 21:03:16 --> Hooks Class Initialized
DEBUG - 2011-08-15 21:03:16 --> Utf8 Class Initialized
DEBUG - 2011-08-15 21:03:16 --> UTF-8 Support Enabled
DEBUG - 2011-08-15 21:03:16 --> URI Class Initialized
DEBUG - 2011-08-15 21:03:16 --> Router Class Initialized
DEBUG - 2011-08-15 21:03:16 --> No URI present. Default controller set.
DEBUG - 2011-08-15 21:03:16 --> Output Class Initialized
DEBUG - 2011-08-15 21:03:16 --> Input Class Initialized
DEBUG - 2011-08-15 21:03:16 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-15 21:03:16 --> Language Class Initialized
DEBUG - 2011-08-15 21:03:16 --> Loader Class Initialized
DEBUG - 2011-08-15 21:03:16 --> Controller Class Initialized
DEBUG - 2011-08-15 21:03:16 --> File loaded: application/views/splash/main.php
DEBUG - 2011-08-15 21:03:16 --> Helper loaded: url_helper
DEBUG - 2011-08-15 21:03:16 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-15 21:03:16 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-15 21:03:16 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-15 21:03:16 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-15 21:03:16 --> Final output sent to browser
DEBUG - 2011-08-15 21:03:16 --> Total execution time: 0.0601
DEBUG - 2011-08-15 21:23:34 --> Config Class Initialized
DEBUG - 2011-08-15 21:23:34 --> Hooks Class Initialized
DEBUG - 2011-08-15 21:23:34 --> Utf8 Class Initialized
DEBUG - 2011-08-15 21:23:34 --> UTF-8 Support Enabled
DEBUG - 2011-08-15 21:23:34 --> URI Class Initialized
DEBUG - 2011-08-15 21:23:34 --> Router Class Initialized
ERROR - 2011-08-15 21:23:34 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-08-15 21:23:35 --> Config Class Initialized
DEBUG - 2011-08-15 21:23:35 --> Hooks Class Initialized
DEBUG - 2011-08-15 21:23:35 --> Utf8 Class Initialized
DEBUG - 2011-08-15 21:23:35 --> UTF-8 Support Enabled
DEBUG - 2011-08-15 21:23:35 --> URI Class Initialized
DEBUG - 2011-08-15 21:23:35 --> Router Class Initialized
DEBUG - 2011-08-15 21:23:35 --> Output Class Initialized
DEBUG - 2011-08-15 21:23:35 --> Input Class Initialized
DEBUG - 2011-08-15 21:23:35 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-15 21:23:35 --> Language Class Initialized
DEBUG - 2011-08-15 21:23:35 --> Loader Class Initialized
DEBUG - 2011-08-15 21:23:35 --> Controller Class Initialized
ERROR - 2011-08-15 21:23:35 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-15 21:23:35 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-15 21:23:35 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-15 21:23:35 --> Model Class Initialized
DEBUG - 2011-08-15 21:23:35 --> Model Class Initialized
DEBUG - 2011-08-15 21:23:35 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-15 21:23:35 --> Database Driver Class Initialized
DEBUG - 2011-08-15 21:23:35 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-15 21:23:35 --> Helper loaded: url_helper
DEBUG - 2011-08-15 21:23:35 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-15 21:23:35 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-15 21:23:35 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-15 21:23:35 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-15 21:23:35 --> Final output sent to browser
DEBUG - 2011-08-15 21:23:35 --> Total execution time: 0.0607
DEBUG - 2011-08-15 22:12:09 --> Config Class Initialized
DEBUG - 2011-08-15 22:12:09 --> Hooks Class Initialized
DEBUG - 2011-08-15 22:12:09 --> Utf8 Class Initialized
DEBUG - 2011-08-15 22:12:09 --> UTF-8 Support Enabled
DEBUG - 2011-08-15 22:12:09 --> URI Class Initialized
DEBUG - 2011-08-15 22:12:09 --> Router Class Initialized
DEBUG - 2011-08-15 22:12:09 --> Output Class Initialized
DEBUG - 2011-08-15 22:12:09 --> Input Class Initialized
DEBUG - 2011-08-15 22:12:09 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-15 22:12:09 --> Language Class Initialized
DEBUG - 2011-08-15 22:12:09 --> Loader Class Initialized
DEBUG - 2011-08-15 22:12:09 --> Controller Class Initialized
DEBUG - 2011-08-15 22:12:09 --> Model Class Initialized
DEBUG - 2011-08-15 22:12:09 --> Model Class Initialized
DEBUG - 2011-08-15 22:12:09 --> Model Class Initialized
DEBUG - 2011-08-15 22:12:09 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-15 22:12:09 --> Database Driver Class Initialized
DEBUG - 2011-08-15 22:12:09 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-15 22:12:09 --> Helper loaded: url_helper
DEBUG - 2011-08-15 22:12:09 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-15 22:12:09 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-15 22:12:09 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-15 22:12:09 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-15 22:12:09 --> Final output sent to browser
DEBUG - 2011-08-15 22:12:09 --> Total execution time: 0.3974
DEBUG - 2011-08-15 22:12:11 --> Config Class Initialized
DEBUG - 2011-08-15 22:12:11 --> Hooks Class Initialized
DEBUG - 2011-08-15 22:12:11 --> Utf8 Class Initialized
DEBUG - 2011-08-15 22:12:11 --> UTF-8 Support Enabled
DEBUG - 2011-08-15 22:12:11 --> URI Class Initialized
DEBUG - 2011-08-15 22:12:11 --> Router Class Initialized
ERROR - 2011-08-15 22:12:11 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-15 22:12:11 --> Config Class Initialized
DEBUG - 2011-08-15 22:12:11 --> Hooks Class Initialized
DEBUG - 2011-08-15 22:12:11 --> Utf8 Class Initialized
DEBUG - 2011-08-15 22:12:11 --> UTF-8 Support Enabled
DEBUG - 2011-08-15 22:12:11 --> URI Class Initialized
DEBUG - 2011-08-15 22:12:11 --> Router Class Initialized
ERROR - 2011-08-15 22:12:11 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-15 22:12:11 --> Config Class Initialized
DEBUG - 2011-08-15 22:12:11 --> Hooks Class Initialized
DEBUG - 2011-08-15 22:12:11 --> Utf8 Class Initialized
DEBUG - 2011-08-15 22:12:11 --> UTF-8 Support Enabled
DEBUG - 2011-08-15 22:12:11 --> URI Class Initialized
DEBUG - 2011-08-15 22:12:11 --> Router Class Initialized
ERROR - 2011-08-15 22:12:11 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-15 22:14:30 --> Config Class Initialized
DEBUG - 2011-08-15 22:14:30 --> Hooks Class Initialized
DEBUG - 2011-08-15 22:14:30 --> Utf8 Class Initialized
DEBUG - 2011-08-15 22:14:30 --> UTF-8 Support Enabled
DEBUG - 2011-08-15 22:14:30 --> URI Class Initialized
DEBUG - 2011-08-15 22:14:30 --> Router Class Initialized
DEBUG - 2011-08-15 22:14:30 --> Output Class Initialized
DEBUG - 2011-08-15 22:14:30 --> Input Class Initialized
DEBUG - 2011-08-15 22:14:30 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-15 22:14:30 --> Language Class Initialized
DEBUG - 2011-08-15 22:14:30 --> Loader Class Initialized
DEBUG - 2011-08-15 22:14:30 --> Controller Class Initialized
DEBUG - 2011-08-15 22:14:30 --> Model Class Initialized
DEBUG - 2011-08-15 22:14:30 --> Model Class Initialized
DEBUG - 2011-08-15 22:14:30 --> Model Class Initialized
DEBUG - 2011-08-15 22:14:30 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-15 22:14:30 --> Database Driver Class Initialized
DEBUG - 2011-08-15 22:14:30 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-15 22:14:30 --> Helper loaded: url_helper
DEBUG - 2011-08-15 22:14:30 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-15 22:14:30 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-15 22:14:30 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-15 22:14:30 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-15 22:14:30 --> Final output sent to browser
DEBUG - 2011-08-15 22:14:30 --> Total execution time: 0.0530
DEBUG - 2011-08-15 22:14:34 --> Config Class Initialized
DEBUG - 2011-08-15 22:14:34 --> Hooks Class Initialized
DEBUG - 2011-08-15 22:14:34 --> Utf8 Class Initialized
DEBUG - 2011-08-15 22:14:34 --> UTF-8 Support Enabled
DEBUG - 2011-08-15 22:14:34 --> URI Class Initialized
DEBUG - 2011-08-15 22:14:34 --> Router Class Initialized
ERROR - 2011-08-15 22:14:34 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-15 22:14:34 --> Config Class Initialized
DEBUG - 2011-08-15 22:14:34 --> Hooks Class Initialized
DEBUG - 2011-08-15 22:14:34 --> Utf8 Class Initialized
DEBUG - 2011-08-15 22:14:34 --> UTF-8 Support Enabled
DEBUG - 2011-08-15 22:14:34 --> URI Class Initialized
DEBUG - 2011-08-15 22:14:34 --> Router Class Initialized
ERROR - 2011-08-15 22:14:34 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-15 22:15:29 --> Config Class Initialized
DEBUG - 2011-08-15 22:15:29 --> Hooks Class Initialized
DEBUG - 2011-08-15 22:15:29 --> Utf8 Class Initialized
DEBUG - 2011-08-15 22:15:29 --> UTF-8 Support Enabled
DEBUG - 2011-08-15 22:15:29 --> URI Class Initialized
DEBUG - 2011-08-15 22:15:29 --> Router Class Initialized
DEBUG - 2011-08-15 22:15:29 --> Output Class Initialized
DEBUG - 2011-08-15 22:15:29 --> Input Class Initialized
DEBUG - 2011-08-15 22:15:29 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-15 22:15:29 --> Language Class Initialized
DEBUG - 2011-08-15 22:15:29 --> Loader Class Initialized
DEBUG - 2011-08-15 22:15:29 --> Controller Class Initialized
DEBUG - 2011-08-15 22:15:29 --> Model Class Initialized
DEBUG - 2011-08-15 22:15:29 --> Model Class Initialized
DEBUG - 2011-08-15 22:15:29 --> Model Class Initialized
DEBUG - 2011-08-15 22:15:29 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-15 22:15:29 --> Database Driver Class Initialized
DEBUG - 2011-08-15 22:15:29 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-15 22:15:29 --> Helper loaded: url_helper
DEBUG - 2011-08-15 22:15:29 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-15 22:15:29 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-15 22:15:29 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-15 22:15:29 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-15 22:15:29 --> Final output sent to browser
DEBUG - 2011-08-15 22:15:29 --> Total execution time: 0.2484
DEBUG - 2011-08-15 22:15:30 --> Config Class Initialized
DEBUG - 2011-08-15 22:15:30 --> Hooks Class Initialized
DEBUG - 2011-08-15 22:15:30 --> Utf8 Class Initialized
DEBUG - 2011-08-15 22:15:30 --> UTF-8 Support Enabled
DEBUG - 2011-08-15 22:15:30 --> URI Class Initialized
DEBUG - 2011-08-15 22:15:30 --> Router Class Initialized
ERROR - 2011-08-15 22:15:30 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-08-15 22:15:30 --> Config Class Initialized
DEBUG - 2011-08-15 22:15:30 --> Hooks Class Initialized
DEBUG - 2011-08-15 22:15:30 --> Utf8 Class Initialized
DEBUG - 2011-08-15 22:15:30 --> UTF-8 Support Enabled
DEBUG - 2011-08-15 22:15:30 --> URI Class Initialized
DEBUG - 2011-08-15 22:15:30 --> Router Class Initialized
DEBUG - 2011-08-15 22:15:30 --> Output Class Initialized
DEBUG - 2011-08-15 22:15:30 --> Input Class Initialized
DEBUG - 2011-08-15 22:15:30 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-15 22:15:30 --> Language Class Initialized
DEBUG - 2011-08-15 22:15:30 --> Loader Class Initialized
DEBUG - 2011-08-15 22:15:30 --> Controller Class Initialized
DEBUG - 2011-08-15 22:15:30 --> Model Class Initialized
DEBUG - 2011-08-15 22:15:30 --> Model Class Initialized
DEBUG - 2011-08-15 22:15:30 --> Model Class Initialized
DEBUG - 2011-08-15 22:15:30 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-15 22:15:30 --> Database Driver Class Initialized
DEBUG - 2011-08-15 22:15:30 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-15 22:15:30 --> Helper loaded: url_helper
DEBUG - 2011-08-15 22:15:30 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-15 22:15:30 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-15 22:15:30 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-15 22:15:30 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-15 22:15:30 --> Final output sent to browser
DEBUG - 2011-08-15 22:15:30 --> Total execution time: 0.0492
DEBUG - 2011-08-15 22:16:11 --> Config Class Initialized
DEBUG - 2011-08-15 22:16:11 --> Hooks Class Initialized
DEBUG - 2011-08-15 22:16:11 --> Utf8 Class Initialized
DEBUG - 2011-08-15 22:16:11 --> UTF-8 Support Enabled
DEBUG - 2011-08-15 22:16:11 --> URI Class Initialized
DEBUG - 2011-08-15 22:16:11 --> Router Class Initialized
DEBUG - 2011-08-15 22:16:11 --> Output Class Initialized
DEBUG - 2011-08-15 22:16:11 --> Input Class Initialized
DEBUG - 2011-08-15 22:16:11 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-15 22:16:11 --> Language Class Initialized
DEBUG - 2011-08-15 22:16:11 --> Loader Class Initialized
DEBUG - 2011-08-15 22:16:11 --> Controller Class Initialized
ERROR - 2011-08-15 22:16:11 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-15 22:16:11 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-15 22:16:11 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-15 22:16:11 --> Model Class Initialized
DEBUG - 2011-08-15 22:16:11 --> Model Class Initialized
DEBUG - 2011-08-15 22:16:11 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-15 22:16:11 --> Database Driver Class Initialized
DEBUG - 2011-08-15 22:16:11 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-15 22:16:11 --> Helper loaded: url_helper
DEBUG - 2011-08-15 22:16:11 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-15 22:16:11 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-15 22:16:11 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-15 22:16:11 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-15 22:16:11 --> Final output sent to browser
DEBUG - 2011-08-15 22:16:11 --> Total execution time: 0.0581
DEBUG - 2011-08-15 22:16:13 --> Config Class Initialized
DEBUG - 2011-08-15 22:16:13 --> Hooks Class Initialized
DEBUG - 2011-08-15 22:16:13 --> Utf8 Class Initialized
DEBUG - 2011-08-15 22:16:13 --> UTF-8 Support Enabled
DEBUG - 2011-08-15 22:16:13 --> URI Class Initialized
DEBUG - 2011-08-15 22:16:13 --> Router Class Initialized
DEBUG - 2011-08-15 22:16:13 --> Output Class Initialized
DEBUG - 2011-08-15 22:16:13 --> Input Class Initialized
DEBUG - 2011-08-15 22:16:13 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-15 22:16:13 --> Language Class Initialized
DEBUG - 2011-08-15 22:16:13 --> Loader Class Initialized
DEBUG - 2011-08-15 22:16:13 --> Controller Class Initialized
DEBUG - 2011-08-15 22:16:13 --> Model Class Initialized
DEBUG - 2011-08-15 22:16:13 --> Model Class Initialized
DEBUG - 2011-08-15 22:16:13 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-15 22:16:13 --> Database Driver Class Initialized
DEBUG - 2011-08-15 22:16:14 --> Final output sent to browser
DEBUG - 2011-08-15 22:16:14 --> Total execution time: 0.5442
DEBUG - 2011-08-15 22:26:49 --> Config Class Initialized
DEBUG - 2011-08-15 22:26:49 --> Hooks Class Initialized
DEBUG - 2011-08-15 22:26:49 --> Utf8 Class Initialized
DEBUG - 2011-08-15 22:26:49 --> UTF-8 Support Enabled
DEBUG - 2011-08-15 22:26:49 --> URI Class Initialized
DEBUG - 2011-08-15 22:26:49 --> Router Class Initialized
DEBUG - 2011-08-15 22:26:49 --> Output Class Initialized
DEBUG - 2011-08-15 22:26:49 --> Input Class Initialized
DEBUG - 2011-08-15 22:26:49 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-15 22:26:49 --> Language Class Initialized
DEBUG - 2011-08-15 22:26:49 --> Loader Class Initialized
DEBUG - 2011-08-15 22:26:49 --> Controller Class Initialized
DEBUG - 2011-08-15 22:26:49 --> Model Class Initialized
DEBUG - 2011-08-15 22:26:49 --> Model Class Initialized
DEBUG - 2011-08-15 22:26:49 --> Model Class Initialized
DEBUG - 2011-08-15 22:26:49 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-15 22:26:49 --> Database Driver Class Initialized
DEBUG - 2011-08-15 22:26:49 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-15 22:26:49 --> Helper loaded: url_helper
DEBUG - 2011-08-15 22:26:49 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-15 22:26:49 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-15 22:26:49 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-15 22:26:49 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-15 22:26:49 --> Final output sent to browser
DEBUG - 2011-08-15 22:26:49 --> Total execution time: 0.0600
DEBUG - 2011-08-15 23:07:04 --> Config Class Initialized
DEBUG - 2011-08-15 23:07:04 --> Hooks Class Initialized
DEBUG - 2011-08-15 23:07:04 --> Utf8 Class Initialized
DEBUG - 2011-08-15 23:07:04 --> UTF-8 Support Enabled
DEBUG - 2011-08-15 23:07:04 --> URI Class Initialized
DEBUG - 2011-08-15 23:07:04 --> Router Class Initialized
DEBUG - 2011-08-15 23:07:04 --> No URI present. Default controller set.
DEBUG - 2011-08-15 23:07:04 --> Output Class Initialized
DEBUG - 2011-08-15 23:07:04 --> Input Class Initialized
DEBUG - 2011-08-15 23:07:04 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-15 23:07:04 --> Language Class Initialized
DEBUG - 2011-08-15 23:07:04 --> Loader Class Initialized
DEBUG - 2011-08-15 23:07:04 --> Controller Class Initialized
DEBUG - 2011-08-15 23:07:04 --> File loaded: application/views/splash/main.php
DEBUG - 2011-08-15 23:07:04 --> Helper loaded: url_helper
DEBUG - 2011-08-15 23:07:04 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-15 23:07:04 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-15 23:07:04 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-15 23:07:04 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-15 23:07:04 --> Final output sent to browser
DEBUG - 2011-08-15 23:07:04 --> Total execution time: 0.0325
DEBUG - 2011-08-15 23:51:35 --> Config Class Initialized
DEBUG - 2011-08-15 23:51:35 --> Hooks Class Initialized
DEBUG - 2011-08-15 23:51:35 --> Utf8 Class Initialized
DEBUG - 2011-08-15 23:51:35 --> UTF-8 Support Enabled
DEBUG - 2011-08-15 23:51:35 --> URI Class Initialized
DEBUG - 2011-08-15 23:51:35 --> Router Class Initialized
DEBUG - 2011-08-15 23:51:35 --> No URI present. Default controller set.
DEBUG - 2011-08-15 23:51:35 --> Output Class Initialized
DEBUG - 2011-08-15 23:51:35 --> Input Class Initialized
DEBUG - 2011-08-15 23:51:35 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-15 23:51:35 --> Language Class Initialized
DEBUG - 2011-08-15 23:51:35 --> Loader Class Initialized
DEBUG - 2011-08-15 23:51:35 --> Controller Class Initialized
DEBUG - 2011-08-15 23:51:35 --> File loaded: application/views/splash/main.php
DEBUG - 2011-08-15 23:51:35 --> Helper loaded: url_helper
DEBUG - 2011-08-15 23:51:35 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-15 23:51:35 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-15 23:51:35 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-15 23:51:35 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-15 23:51:35 --> Final output sent to browser
DEBUG - 2011-08-15 23:51:35 --> Total execution time: 0.1591
DEBUG - 2011-08-15 23:51:35 --> Config Class Initialized
DEBUG - 2011-08-15 23:51:35 --> Hooks Class Initialized
DEBUG - 2011-08-15 23:51:35 --> Utf8 Class Initialized
DEBUG - 2011-08-15 23:51:35 --> UTF-8 Support Enabled
DEBUG - 2011-08-15 23:51:35 --> URI Class Initialized
DEBUG - 2011-08-15 23:51:35 --> Router Class Initialized
ERROR - 2011-08-15 23:51:35 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-08-15 23:56:24 --> Config Class Initialized
DEBUG - 2011-08-15 23:56:24 --> Hooks Class Initialized
DEBUG - 2011-08-15 23:56:24 --> Utf8 Class Initialized
DEBUG - 2011-08-15 23:56:24 --> UTF-8 Support Enabled
DEBUG - 2011-08-15 23:56:24 --> URI Class Initialized
DEBUG - 2011-08-15 23:56:24 --> Router Class Initialized
ERROR - 2011-08-15 23:56:24 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-08-15 23:59:31 --> Config Class Initialized
DEBUG - 2011-08-15 23:59:31 --> Hooks Class Initialized
DEBUG - 2011-08-15 23:59:31 --> Utf8 Class Initialized
DEBUG - 2011-08-15 23:59:31 --> UTF-8 Support Enabled
DEBUG - 2011-08-15 23:59:31 --> URI Class Initialized
DEBUG - 2011-08-15 23:59:31 --> Router Class Initialized
DEBUG - 2011-08-15 23:59:31 --> Output Class Initialized
DEBUG - 2011-08-15 23:59:31 --> Input Class Initialized
DEBUG - 2011-08-15 23:59:31 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-15 23:59:31 --> Language Class Initialized
DEBUG - 2011-08-15 23:59:31 --> Loader Class Initialized
DEBUG - 2011-08-15 23:59:31 --> Controller Class Initialized
ERROR - 2011-08-15 23:59:31 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-15 23:59:31 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-15 23:59:31 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-15 23:59:31 --> Model Class Initialized
DEBUG - 2011-08-15 23:59:31 --> Model Class Initialized
DEBUG - 2011-08-15 23:59:31 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-15 23:59:31 --> Database Driver Class Initialized
DEBUG - 2011-08-15 23:59:31 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-15 23:59:31 --> Helper loaded: url_helper
DEBUG - 2011-08-15 23:59:31 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-15 23:59:31 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-15 23:59:31 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-15 23:59:31 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-15 23:59:31 --> Final output sent to browser
DEBUG - 2011-08-15 23:59:31 --> Total execution time: 0.1234

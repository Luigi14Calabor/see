<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2011-09-15 00:33:16 --> Config Class Initialized
DEBUG - 2011-09-15 00:33:16 --> Hooks Class Initialized
DEBUG - 2011-09-15 00:33:16 --> Utf8 Class Initialized
DEBUG - 2011-09-15 00:33:16 --> UTF-8 Support Enabled
DEBUG - 2011-09-15 00:33:16 --> URI Class Initialized
DEBUG - 2011-09-15 00:33:16 --> Router Class Initialized
DEBUG - 2011-09-15 00:33:16 --> Output Class Initialized
DEBUG - 2011-09-15 00:33:16 --> Input Class Initialized
DEBUG - 2011-09-15 00:33:16 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-15 00:33:16 --> Language Class Initialized
DEBUG - 2011-09-15 00:33:16 --> Loader Class Initialized
DEBUG - 2011-09-15 00:33:16 --> Controller Class Initialized
ERROR - 2011-09-15 00:33:16 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-15 00:33:16 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-15 00:33:16 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-15 00:33:16 --> Model Class Initialized
DEBUG - 2011-09-15 00:33:16 --> Model Class Initialized
DEBUG - 2011-09-15 00:33:16 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-15 00:33:16 --> Database Driver Class Initialized
DEBUG - 2011-09-15 00:33:16 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-15 00:33:16 --> Helper loaded: url_helper
DEBUG - 2011-09-15 00:33:16 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-15 00:33:16 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-15 00:33:16 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-15 00:33:16 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-15 00:33:16 --> Final output sent to browser
DEBUG - 2011-09-15 00:33:16 --> Total execution time: 0.0442
DEBUG - 2011-09-15 00:33:17 --> Config Class Initialized
DEBUG - 2011-09-15 00:33:17 --> Hooks Class Initialized
DEBUG - 2011-09-15 00:33:17 --> Utf8 Class Initialized
DEBUG - 2011-09-15 00:33:17 --> UTF-8 Support Enabled
DEBUG - 2011-09-15 00:33:17 --> URI Class Initialized
DEBUG - 2011-09-15 00:33:17 --> Router Class Initialized
DEBUG - 2011-09-15 00:33:17 --> Output Class Initialized
DEBUG - 2011-09-15 00:33:17 --> Input Class Initialized
DEBUG - 2011-09-15 00:33:17 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-15 00:33:17 --> Language Class Initialized
DEBUG - 2011-09-15 00:33:17 --> Loader Class Initialized
DEBUG - 2011-09-15 00:33:17 --> Controller Class Initialized
DEBUG - 2011-09-15 00:33:17 --> Model Class Initialized
DEBUG - 2011-09-15 00:33:17 --> Model Class Initialized
DEBUG - 2011-09-15 00:33:17 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-15 00:33:17 --> Database Driver Class Initialized
DEBUG - 2011-09-15 00:33:18 --> Final output sent to browser
DEBUG - 2011-09-15 00:33:18 --> Total execution time: 0.7031
DEBUG - 2011-09-15 01:36:49 --> Config Class Initialized
DEBUG - 2011-09-15 01:36:49 --> Hooks Class Initialized
DEBUG - 2011-09-15 01:36:49 --> Utf8 Class Initialized
DEBUG - 2011-09-15 01:36:49 --> UTF-8 Support Enabled
DEBUG - 2011-09-15 01:36:49 --> URI Class Initialized
DEBUG - 2011-09-15 01:36:49 --> Router Class Initialized
DEBUG - 2011-09-15 01:36:49 --> Output Class Initialized
DEBUG - 2011-09-15 01:36:49 --> Input Class Initialized
DEBUG - 2011-09-15 01:36:49 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-15 01:36:49 --> Language Class Initialized
DEBUG - 2011-09-15 01:36:49 --> Loader Class Initialized
DEBUG - 2011-09-15 01:36:49 --> Controller Class Initialized
DEBUG - 2011-09-15 01:36:49 --> Model Class Initialized
DEBUG - 2011-09-15 01:36:49 --> Model Class Initialized
DEBUG - 2011-09-15 01:36:49 --> Model Class Initialized
DEBUG - 2011-09-15 01:36:49 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-15 01:36:50 --> Database Driver Class Initialized
DEBUG - 2011-09-15 01:36:50 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-15 01:36:50 --> Helper loaded: url_helper
DEBUG - 2011-09-15 01:36:50 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-15 01:36:50 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-15 01:36:50 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-15 01:36:50 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-15 01:36:50 --> Final output sent to browser
DEBUG - 2011-09-15 01:36:50 --> Total execution time: 0.8078
DEBUG - 2011-09-15 01:37:21 --> Config Class Initialized
DEBUG - 2011-09-15 01:37:21 --> Hooks Class Initialized
DEBUG - 2011-09-15 01:37:21 --> Utf8 Class Initialized
DEBUG - 2011-09-15 01:37:21 --> UTF-8 Support Enabled
DEBUG - 2011-09-15 01:37:21 --> URI Class Initialized
DEBUG - 2011-09-15 01:37:21 --> Router Class Initialized
DEBUG - 2011-09-15 01:37:21 --> Output Class Initialized
DEBUG - 2011-09-15 01:37:21 --> Input Class Initialized
DEBUG - 2011-09-15 01:37:21 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-15 01:37:21 --> Language Class Initialized
DEBUG - 2011-09-15 01:37:21 --> Loader Class Initialized
DEBUG - 2011-09-15 01:37:21 --> Controller Class Initialized
DEBUG - 2011-09-15 01:37:21 --> Model Class Initialized
DEBUG - 2011-09-15 01:37:21 --> Model Class Initialized
DEBUG - 2011-09-15 01:37:21 --> Model Class Initialized
DEBUG - 2011-09-15 01:37:21 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-15 01:37:21 --> Database Driver Class Initialized
DEBUG - 2011-09-15 01:37:22 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-15 01:37:22 --> Helper loaded: url_helper
DEBUG - 2011-09-15 01:37:22 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-15 01:37:22 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-15 01:37:22 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-15 01:37:22 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-15 01:37:22 --> Final output sent to browser
DEBUG - 2011-09-15 01:37:22 --> Total execution time: 0.6654
DEBUG - 2011-09-15 01:37:28 --> Config Class Initialized
DEBUG - 2011-09-15 01:37:28 --> Hooks Class Initialized
DEBUG - 2011-09-15 01:37:28 --> Utf8 Class Initialized
DEBUG - 2011-09-15 01:37:28 --> UTF-8 Support Enabled
DEBUG - 2011-09-15 01:37:28 --> URI Class Initialized
DEBUG - 2011-09-15 01:37:28 --> Router Class Initialized
ERROR - 2011-09-15 01:37:28 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-09-15 01:37:29 --> Config Class Initialized
DEBUG - 2011-09-15 01:37:29 --> Hooks Class Initialized
DEBUG - 2011-09-15 01:37:29 --> Utf8 Class Initialized
DEBUG - 2011-09-15 01:37:29 --> UTF-8 Support Enabled
DEBUG - 2011-09-15 01:37:29 --> URI Class Initialized
DEBUG - 2011-09-15 01:37:29 --> Router Class Initialized
DEBUG - 2011-09-15 01:37:29 --> Output Class Initialized
DEBUG - 2011-09-15 01:37:29 --> Input Class Initialized
DEBUG - 2011-09-15 01:37:29 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-15 01:37:29 --> Language Class Initialized
DEBUG - 2011-09-15 01:37:29 --> Loader Class Initialized
DEBUG - 2011-09-15 01:37:29 --> Controller Class Initialized
DEBUG - 2011-09-15 01:37:29 --> Model Class Initialized
DEBUG - 2011-09-15 01:37:29 --> Model Class Initialized
DEBUG - 2011-09-15 01:37:29 --> Model Class Initialized
DEBUG - 2011-09-15 01:37:29 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-15 01:37:29 --> Database Driver Class Initialized
DEBUG - 2011-09-15 01:37:29 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-15 01:37:29 --> Helper loaded: url_helper
DEBUG - 2011-09-15 01:37:29 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-15 01:37:29 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-15 01:37:29 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-15 01:37:29 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-15 01:37:29 --> Final output sent to browser
DEBUG - 2011-09-15 01:37:29 --> Total execution time: 0.0699
DEBUG - 2011-09-15 01:46:40 --> Config Class Initialized
DEBUG - 2011-09-15 01:46:40 --> Hooks Class Initialized
DEBUG - 2011-09-15 01:46:40 --> Utf8 Class Initialized
DEBUG - 2011-09-15 01:46:40 --> UTF-8 Support Enabled
DEBUG - 2011-09-15 01:46:40 --> URI Class Initialized
DEBUG - 2011-09-15 01:46:40 --> Router Class Initialized
DEBUG - 2011-09-15 01:46:40 --> Output Class Initialized
DEBUG - 2011-09-15 01:46:40 --> Input Class Initialized
DEBUG - 2011-09-15 01:46:40 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-15 01:46:40 --> Language Class Initialized
DEBUG - 2011-09-15 01:46:40 --> Loader Class Initialized
DEBUG - 2011-09-15 01:46:40 --> Controller Class Initialized
ERROR - 2011-09-15 01:46:40 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-15 01:46:40 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-15 01:46:40 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-15 01:46:40 --> Model Class Initialized
DEBUG - 2011-09-15 01:46:40 --> Model Class Initialized
DEBUG - 2011-09-15 01:46:40 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-15 01:46:40 --> Database Driver Class Initialized
DEBUG - 2011-09-15 01:46:40 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-15 01:46:40 --> Helper loaded: url_helper
DEBUG - 2011-09-15 01:46:40 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-15 01:46:40 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-15 01:46:40 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-15 01:46:40 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-15 01:46:40 --> Final output sent to browser
DEBUG - 2011-09-15 01:46:40 --> Total execution time: 0.3594
DEBUG - 2011-09-15 01:46:42 --> Config Class Initialized
DEBUG - 2011-09-15 01:46:42 --> Hooks Class Initialized
DEBUG - 2011-09-15 01:46:42 --> Utf8 Class Initialized
DEBUG - 2011-09-15 01:46:42 --> UTF-8 Support Enabled
DEBUG - 2011-09-15 01:46:42 --> URI Class Initialized
DEBUG - 2011-09-15 01:46:42 --> Router Class Initialized
DEBUG - 2011-09-15 01:46:42 --> Output Class Initialized
DEBUG - 2011-09-15 01:46:42 --> Input Class Initialized
DEBUG - 2011-09-15 01:46:42 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-15 01:46:42 --> Language Class Initialized
DEBUG - 2011-09-15 01:46:42 --> Loader Class Initialized
DEBUG - 2011-09-15 01:46:42 --> Controller Class Initialized
DEBUG - 2011-09-15 01:46:42 --> Model Class Initialized
DEBUG - 2011-09-15 01:46:42 --> Model Class Initialized
DEBUG - 2011-09-15 01:46:42 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-15 01:46:42 --> Database Driver Class Initialized
DEBUG - 2011-09-15 01:46:42 --> Final output sent to browser
DEBUG - 2011-09-15 01:46:42 --> Total execution time: 0.8835
DEBUG - 2011-09-15 01:46:58 --> Config Class Initialized
DEBUG - 2011-09-15 01:46:58 --> Hooks Class Initialized
DEBUG - 2011-09-15 01:46:58 --> Utf8 Class Initialized
DEBUG - 2011-09-15 01:46:58 --> UTF-8 Support Enabled
DEBUG - 2011-09-15 01:46:58 --> URI Class Initialized
DEBUG - 2011-09-15 01:46:58 --> Router Class Initialized
DEBUG - 2011-09-15 01:46:58 --> Output Class Initialized
DEBUG - 2011-09-15 01:46:58 --> Input Class Initialized
DEBUG - 2011-09-15 01:46:58 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-15 01:46:58 --> Language Class Initialized
DEBUG - 2011-09-15 01:46:58 --> Loader Class Initialized
DEBUG - 2011-09-15 01:46:58 --> Controller Class Initialized
ERROR - 2011-09-15 01:46:58 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-15 01:46:58 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-15 01:46:58 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-15 01:46:58 --> Model Class Initialized
DEBUG - 2011-09-15 01:46:58 --> Model Class Initialized
DEBUG - 2011-09-15 01:46:58 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-15 01:46:58 --> Database Driver Class Initialized
DEBUG - 2011-09-15 01:46:58 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-15 01:46:58 --> Helper loaded: url_helper
DEBUG - 2011-09-15 01:46:58 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-15 01:46:58 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-15 01:46:58 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-15 01:46:58 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-15 01:46:58 --> Final output sent to browser
DEBUG - 2011-09-15 01:46:58 --> Total execution time: 0.0927
DEBUG - 2011-09-15 01:46:59 --> Config Class Initialized
DEBUG - 2011-09-15 01:46:59 --> Hooks Class Initialized
DEBUG - 2011-09-15 01:46:59 --> Utf8 Class Initialized
DEBUG - 2011-09-15 01:46:59 --> UTF-8 Support Enabled
DEBUG - 2011-09-15 01:46:59 --> URI Class Initialized
DEBUG - 2011-09-15 01:46:59 --> Router Class Initialized
DEBUG - 2011-09-15 01:46:59 --> Output Class Initialized
DEBUG - 2011-09-15 01:46:59 --> Input Class Initialized
DEBUG - 2011-09-15 01:46:59 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-15 01:46:59 --> Language Class Initialized
DEBUG - 2011-09-15 01:46:59 --> Loader Class Initialized
DEBUG - 2011-09-15 01:46:59 --> Controller Class Initialized
DEBUG - 2011-09-15 01:46:59 --> Model Class Initialized
DEBUG - 2011-09-15 01:46:59 --> Model Class Initialized
DEBUG - 2011-09-15 01:46:59 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-15 01:46:59 --> Database Driver Class Initialized
DEBUG - 2011-09-15 01:47:00 --> Final output sent to browser
DEBUG - 2011-09-15 01:47:00 --> Total execution time: 0.6522
DEBUG - 2011-09-15 01:47:20 --> Config Class Initialized
DEBUG - 2011-09-15 01:47:20 --> Hooks Class Initialized
DEBUG - 2011-09-15 01:47:20 --> Utf8 Class Initialized
DEBUG - 2011-09-15 01:47:20 --> UTF-8 Support Enabled
DEBUG - 2011-09-15 01:47:20 --> URI Class Initialized
DEBUG - 2011-09-15 01:47:20 --> Router Class Initialized
DEBUG - 2011-09-15 01:47:20 --> Output Class Initialized
DEBUG - 2011-09-15 01:47:20 --> Input Class Initialized
DEBUG - 2011-09-15 01:47:20 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-15 01:47:20 --> Language Class Initialized
DEBUG - 2011-09-15 01:47:20 --> Loader Class Initialized
DEBUG - 2011-09-15 01:47:20 --> Controller Class Initialized
DEBUG - 2011-09-15 01:47:20 --> Model Class Initialized
DEBUG - 2011-09-15 01:47:20 --> Model Class Initialized
DEBUG - 2011-09-15 01:47:20 --> Model Class Initialized
DEBUG - 2011-09-15 01:47:20 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-15 01:47:20 --> Database Driver Class Initialized
DEBUG - 2011-09-15 01:47:20 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-15 01:47:20 --> Helper loaded: url_helper
DEBUG - 2011-09-15 01:47:20 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-15 01:47:20 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-15 01:47:20 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-15 01:47:20 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-15 01:47:20 --> Final output sent to browser
DEBUG - 2011-09-15 01:47:20 --> Total execution time: 0.0486
DEBUG - 2011-09-15 03:08:08 --> Config Class Initialized
DEBUG - 2011-09-15 03:08:08 --> Hooks Class Initialized
DEBUG - 2011-09-15 03:08:08 --> Utf8 Class Initialized
DEBUG - 2011-09-15 03:08:08 --> UTF-8 Support Enabled
DEBUG - 2011-09-15 03:08:08 --> URI Class Initialized
DEBUG - 2011-09-15 03:08:08 --> Router Class Initialized
DEBUG - 2011-09-15 03:08:08 --> Output Class Initialized
DEBUG - 2011-09-15 03:08:08 --> Input Class Initialized
DEBUG - 2011-09-15 03:08:08 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-15 03:08:08 --> Language Class Initialized
DEBUG - 2011-09-15 03:08:08 --> Loader Class Initialized
DEBUG - 2011-09-15 03:08:08 --> Controller Class Initialized
ERROR - 2011-09-15 03:08:08 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-15 03:08:08 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-15 03:08:08 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-15 03:08:08 --> Model Class Initialized
DEBUG - 2011-09-15 03:08:08 --> Model Class Initialized
DEBUG - 2011-09-15 03:08:08 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-15 03:08:08 --> Database Driver Class Initialized
DEBUG - 2011-09-15 03:08:08 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-15 03:08:08 --> Helper loaded: url_helper
DEBUG - 2011-09-15 03:08:08 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-15 03:08:08 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-15 03:08:08 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-15 03:08:08 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-15 03:08:08 --> Final output sent to browser
DEBUG - 2011-09-15 03:08:08 --> Total execution time: 0.4381
DEBUG - 2011-09-15 03:08:10 --> Config Class Initialized
DEBUG - 2011-09-15 03:08:10 --> Hooks Class Initialized
DEBUG - 2011-09-15 03:08:10 --> Utf8 Class Initialized
DEBUG - 2011-09-15 03:08:10 --> UTF-8 Support Enabled
DEBUG - 2011-09-15 03:08:10 --> URI Class Initialized
DEBUG - 2011-09-15 03:08:10 --> Router Class Initialized
ERROR - 2011-09-15 03:08:10 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-15 03:08:11 --> Config Class Initialized
DEBUG - 2011-09-15 03:08:11 --> Hooks Class Initialized
DEBUG - 2011-09-15 03:08:11 --> Utf8 Class Initialized
DEBUG - 2011-09-15 03:08:11 --> UTF-8 Support Enabled
DEBUG - 2011-09-15 03:08:11 --> URI Class Initialized
DEBUG - 2011-09-15 03:08:11 --> Router Class Initialized
DEBUG - 2011-09-15 03:08:11 --> Output Class Initialized
DEBUG - 2011-09-15 03:08:11 --> Input Class Initialized
DEBUG - 2011-09-15 03:08:11 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-15 03:08:11 --> Language Class Initialized
DEBUG - 2011-09-15 03:08:11 --> Loader Class Initialized
DEBUG - 2011-09-15 03:08:11 --> Controller Class Initialized
DEBUG - 2011-09-15 03:08:11 --> Model Class Initialized
DEBUG - 2011-09-15 03:08:11 --> Model Class Initialized
DEBUG - 2011-09-15 03:08:11 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-15 03:08:11 --> Database Driver Class Initialized
DEBUG - 2011-09-15 03:08:12 --> Final output sent to browser
DEBUG - 2011-09-15 03:08:12 --> Total execution time: 0.8668
DEBUG - 2011-09-15 03:08:28 --> Config Class Initialized
DEBUG - 2011-09-15 03:08:28 --> Hooks Class Initialized
DEBUG - 2011-09-15 03:08:28 --> Utf8 Class Initialized
DEBUG - 2011-09-15 03:08:28 --> UTF-8 Support Enabled
DEBUG - 2011-09-15 03:08:28 --> URI Class Initialized
DEBUG - 2011-09-15 03:08:28 --> Router Class Initialized
DEBUG - 2011-09-15 03:08:28 --> Output Class Initialized
DEBUG - 2011-09-15 03:08:28 --> Input Class Initialized
DEBUG - 2011-09-15 03:08:28 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-15 03:08:28 --> Language Class Initialized
DEBUG - 2011-09-15 03:08:28 --> Loader Class Initialized
DEBUG - 2011-09-15 03:08:28 --> Controller Class Initialized
ERROR - 2011-09-15 03:08:28 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-15 03:08:28 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-15 03:08:28 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-15 03:08:28 --> Model Class Initialized
DEBUG - 2011-09-15 03:08:28 --> Model Class Initialized
DEBUG - 2011-09-15 03:08:28 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-15 03:08:28 --> Database Driver Class Initialized
DEBUG - 2011-09-15 03:08:28 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-15 03:08:28 --> Helper loaded: url_helper
DEBUG - 2011-09-15 03:08:28 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-15 03:08:28 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-15 03:08:28 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-15 03:08:28 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-15 03:08:28 --> Final output sent to browser
DEBUG - 2011-09-15 03:08:28 --> Total execution time: 0.0766
DEBUG - 2011-09-15 03:08:29 --> Config Class Initialized
DEBUG - 2011-09-15 03:08:29 --> Hooks Class Initialized
DEBUG - 2011-09-15 03:08:29 --> Utf8 Class Initialized
DEBUG - 2011-09-15 03:08:29 --> UTF-8 Support Enabled
DEBUG - 2011-09-15 03:08:29 --> URI Class Initialized
DEBUG - 2011-09-15 03:08:29 --> Router Class Initialized
DEBUG - 2011-09-15 03:08:29 --> Output Class Initialized
DEBUG - 2011-09-15 03:08:29 --> Input Class Initialized
DEBUG - 2011-09-15 03:08:29 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-15 03:08:29 --> Language Class Initialized
DEBUG - 2011-09-15 03:08:29 --> Loader Class Initialized
DEBUG - 2011-09-15 03:08:29 --> Controller Class Initialized
DEBUG - 2011-09-15 03:08:29 --> Model Class Initialized
DEBUG - 2011-09-15 03:08:29 --> Model Class Initialized
DEBUG - 2011-09-15 03:08:29 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-15 03:08:29 --> Database Driver Class Initialized
DEBUG - 2011-09-15 03:08:31 --> Final output sent to browser
DEBUG - 2011-09-15 03:08:31 --> Total execution time: 1.5476
DEBUG - 2011-09-15 03:36:45 --> Config Class Initialized
DEBUG - 2011-09-15 03:36:45 --> Hooks Class Initialized
DEBUG - 2011-09-15 03:36:45 --> Utf8 Class Initialized
DEBUG - 2011-09-15 03:36:45 --> UTF-8 Support Enabled
DEBUG - 2011-09-15 03:36:45 --> URI Class Initialized
DEBUG - 2011-09-15 03:36:45 --> Router Class Initialized
ERROR - 2011-09-15 03:36:45 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-09-15 03:36:46 --> Config Class Initialized
DEBUG - 2011-09-15 03:36:46 --> Hooks Class Initialized
DEBUG - 2011-09-15 03:36:46 --> Utf8 Class Initialized
DEBUG - 2011-09-15 03:36:46 --> UTF-8 Support Enabled
DEBUG - 2011-09-15 03:36:46 --> URI Class Initialized
DEBUG - 2011-09-15 03:36:46 --> Router Class Initialized
DEBUG - 2011-09-15 03:36:46 --> Output Class Initialized
DEBUG - 2011-09-15 03:36:46 --> Input Class Initialized
DEBUG - 2011-09-15 03:36:46 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-15 03:36:46 --> Language Class Initialized
DEBUG - 2011-09-15 03:36:46 --> Loader Class Initialized
DEBUG - 2011-09-15 03:36:46 --> Controller Class Initialized
ERROR - 2011-09-15 03:36:46 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-15 03:36:46 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-15 03:36:46 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-15 03:36:46 --> Model Class Initialized
DEBUG - 2011-09-15 03:36:46 --> Model Class Initialized
DEBUG - 2011-09-15 03:36:46 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-15 03:36:46 --> Database Driver Class Initialized
DEBUG - 2011-09-15 03:36:46 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-15 03:36:46 --> Helper loaded: url_helper
DEBUG - 2011-09-15 03:36:46 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-15 03:36:46 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-15 03:36:46 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-15 03:36:46 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-15 03:36:46 --> Final output sent to browser
DEBUG - 2011-09-15 03:36:46 --> Total execution time: 0.4302
DEBUG - 2011-09-15 04:54:46 --> Config Class Initialized
DEBUG - 2011-09-15 04:54:46 --> Hooks Class Initialized
DEBUG - 2011-09-15 04:54:46 --> Utf8 Class Initialized
DEBUG - 2011-09-15 04:54:46 --> UTF-8 Support Enabled
DEBUG - 2011-09-15 04:54:46 --> URI Class Initialized
DEBUG - 2011-09-15 04:54:46 --> Router Class Initialized
DEBUG - 2011-09-15 04:54:46 --> Output Class Initialized
DEBUG - 2011-09-15 04:54:46 --> Input Class Initialized
DEBUG - 2011-09-15 04:54:46 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-15 04:54:46 --> Language Class Initialized
DEBUG - 2011-09-15 04:54:46 --> Loader Class Initialized
DEBUG - 2011-09-15 04:54:46 --> Controller Class Initialized
ERROR - 2011-09-15 04:54:46 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-15 04:54:46 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-15 04:54:46 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-15 04:54:46 --> Model Class Initialized
DEBUG - 2011-09-15 04:54:46 --> Model Class Initialized
DEBUG - 2011-09-15 04:54:46 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-15 04:54:46 --> Database Driver Class Initialized
DEBUG - 2011-09-15 04:54:47 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-15 04:54:47 --> Helper loaded: url_helper
DEBUG - 2011-09-15 04:54:47 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-15 04:54:47 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-15 04:54:47 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-15 04:54:47 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-15 04:54:47 --> Final output sent to browser
DEBUG - 2011-09-15 04:54:47 --> Total execution time: 0.9455
DEBUG - 2011-09-15 04:54:48 --> Config Class Initialized
DEBUG - 2011-09-15 04:54:48 --> Hooks Class Initialized
DEBUG - 2011-09-15 04:54:48 --> Utf8 Class Initialized
DEBUG - 2011-09-15 04:54:48 --> UTF-8 Support Enabled
DEBUG - 2011-09-15 04:54:48 --> URI Class Initialized
DEBUG - 2011-09-15 04:54:48 --> Router Class Initialized
DEBUG - 2011-09-15 04:54:48 --> Output Class Initialized
DEBUG - 2011-09-15 04:54:48 --> Input Class Initialized
DEBUG - 2011-09-15 04:54:48 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-15 04:54:48 --> Language Class Initialized
DEBUG - 2011-09-15 04:54:48 --> Loader Class Initialized
DEBUG - 2011-09-15 04:54:48 --> Controller Class Initialized
DEBUG - 2011-09-15 04:54:48 --> Model Class Initialized
DEBUG - 2011-09-15 04:54:48 --> Model Class Initialized
DEBUG - 2011-09-15 04:54:48 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-15 04:54:48 --> Database Driver Class Initialized
DEBUG - 2011-09-15 04:54:49 --> Final output sent to browser
DEBUG - 2011-09-15 04:54:49 --> Total execution time: 1.0203
DEBUG - 2011-09-15 06:16:54 --> Config Class Initialized
DEBUG - 2011-09-15 06:16:54 --> Hooks Class Initialized
DEBUG - 2011-09-15 06:16:54 --> Utf8 Class Initialized
DEBUG - 2011-09-15 06:16:54 --> UTF-8 Support Enabled
DEBUG - 2011-09-15 06:16:54 --> URI Class Initialized
DEBUG - 2011-09-15 06:16:54 --> Router Class Initialized
DEBUG - 2011-09-15 06:16:54 --> Output Class Initialized
DEBUG - 2011-09-15 06:16:54 --> Input Class Initialized
DEBUG - 2011-09-15 06:16:54 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-15 06:16:54 --> Language Class Initialized
DEBUG - 2011-09-15 06:16:54 --> Loader Class Initialized
DEBUG - 2011-09-15 06:16:54 --> Controller Class Initialized
DEBUG - 2011-09-15 06:16:54 --> Model Class Initialized
DEBUG - 2011-09-15 06:16:54 --> Model Class Initialized
DEBUG - 2011-09-15 06:16:54 --> Model Class Initialized
DEBUG - 2011-09-15 06:16:54 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-15 06:16:54 --> Database Driver Class Initialized
DEBUG - 2011-09-15 06:16:55 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-15 06:16:55 --> Helper loaded: url_helper
DEBUG - 2011-09-15 06:16:55 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-15 06:16:55 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-15 06:16:55 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-15 06:16:55 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-15 06:16:55 --> Final output sent to browser
DEBUG - 2011-09-15 06:16:55 --> Total execution time: 1.0248
DEBUG - 2011-09-15 06:16:57 --> Config Class Initialized
DEBUG - 2011-09-15 06:16:57 --> Hooks Class Initialized
DEBUG - 2011-09-15 06:16:57 --> Utf8 Class Initialized
DEBUG - 2011-09-15 06:16:57 --> UTF-8 Support Enabled
DEBUG - 2011-09-15 06:16:57 --> URI Class Initialized
DEBUG - 2011-09-15 06:16:57 --> Router Class Initialized
ERROR - 2011-09-15 06:16:57 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-15 06:16:57 --> Config Class Initialized
DEBUG - 2011-09-15 06:16:57 --> Hooks Class Initialized
DEBUG - 2011-09-15 06:16:57 --> Utf8 Class Initialized
DEBUG - 2011-09-15 06:16:57 --> UTF-8 Support Enabled
DEBUG - 2011-09-15 06:16:57 --> URI Class Initialized
DEBUG - 2011-09-15 06:16:57 --> Router Class Initialized
ERROR - 2011-09-15 06:16:57 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-15 06:16:57 --> Config Class Initialized
DEBUG - 2011-09-15 06:16:57 --> Hooks Class Initialized
DEBUG - 2011-09-15 06:16:57 --> Utf8 Class Initialized
DEBUG - 2011-09-15 06:16:57 --> UTF-8 Support Enabled
DEBUG - 2011-09-15 06:16:57 --> URI Class Initialized
DEBUG - 2011-09-15 06:16:57 --> Router Class Initialized
ERROR - 2011-09-15 06:16:57 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-15 06:17:09 --> Config Class Initialized
DEBUG - 2011-09-15 06:17:09 --> Hooks Class Initialized
DEBUG - 2011-09-15 06:17:09 --> Utf8 Class Initialized
DEBUG - 2011-09-15 06:17:09 --> UTF-8 Support Enabled
DEBUG - 2011-09-15 06:17:09 --> URI Class Initialized
DEBUG - 2011-09-15 06:17:09 --> Router Class Initialized
DEBUG - 2011-09-15 06:17:09 --> Output Class Initialized
DEBUG - 2011-09-15 06:17:09 --> Input Class Initialized
DEBUG - 2011-09-15 06:17:09 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-15 06:17:09 --> Language Class Initialized
DEBUG - 2011-09-15 06:17:09 --> Loader Class Initialized
DEBUG - 2011-09-15 06:17:09 --> Controller Class Initialized
DEBUG - 2011-09-15 06:17:09 --> Model Class Initialized
DEBUG - 2011-09-15 06:17:09 --> Model Class Initialized
DEBUG - 2011-09-15 06:17:09 --> Model Class Initialized
DEBUG - 2011-09-15 06:17:09 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-15 06:17:09 --> Database Driver Class Initialized
DEBUG - 2011-09-15 06:17:09 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-15 06:17:09 --> Helper loaded: url_helper
DEBUG - 2011-09-15 06:17:09 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-15 06:17:09 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-15 06:17:09 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-15 06:17:09 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-15 06:17:09 --> Final output sent to browser
DEBUG - 2011-09-15 06:17:09 --> Total execution time: 0.1022
DEBUG - 2011-09-15 06:17:22 --> Config Class Initialized
DEBUG - 2011-09-15 06:17:22 --> Hooks Class Initialized
DEBUG - 2011-09-15 06:17:22 --> Utf8 Class Initialized
DEBUG - 2011-09-15 06:17:22 --> UTF-8 Support Enabled
DEBUG - 2011-09-15 06:17:22 --> URI Class Initialized
DEBUG - 2011-09-15 06:17:22 --> Router Class Initialized
DEBUG - 2011-09-15 06:17:22 --> Output Class Initialized
DEBUG - 2011-09-15 06:17:22 --> Input Class Initialized
DEBUG - 2011-09-15 06:17:22 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-15 06:17:22 --> Language Class Initialized
DEBUG - 2011-09-15 06:17:22 --> Loader Class Initialized
DEBUG - 2011-09-15 06:17:22 --> Controller Class Initialized
DEBUG - 2011-09-15 06:17:22 --> Model Class Initialized
DEBUG - 2011-09-15 06:17:22 --> Model Class Initialized
DEBUG - 2011-09-15 06:17:22 --> Model Class Initialized
DEBUG - 2011-09-15 06:17:22 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-15 06:17:22 --> Database Driver Class Initialized
DEBUG - 2011-09-15 06:17:23 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-15 06:17:23 --> Helper loaded: url_helper
DEBUG - 2011-09-15 06:17:23 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-15 06:17:23 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-15 06:17:23 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-15 06:17:23 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-15 06:17:23 --> Final output sent to browser
DEBUG - 2011-09-15 06:17:23 --> Total execution time: 0.4052
DEBUG - 2011-09-15 07:07:46 --> Config Class Initialized
DEBUG - 2011-09-15 07:07:46 --> Hooks Class Initialized
DEBUG - 2011-09-15 07:07:46 --> Utf8 Class Initialized
DEBUG - 2011-09-15 07:07:46 --> UTF-8 Support Enabled
DEBUG - 2011-09-15 07:07:46 --> URI Class Initialized
DEBUG - 2011-09-15 07:07:46 --> Router Class Initialized
DEBUG - 2011-09-15 07:07:46 --> Output Class Initialized
DEBUG - 2011-09-15 07:07:46 --> Input Class Initialized
DEBUG - 2011-09-15 07:07:46 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-15 07:07:46 --> Language Class Initialized
DEBUG - 2011-09-15 07:07:46 --> Loader Class Initialized
DEBUG - 2011-09-15 07:07:46 --> Controller Class Initialized
DEBUG - 2011-09-15 07:07:46 --> Model Class Initialized
DEBUG - 2011-09-15 07:07:46 --> Model Class Initialized
DEBUG - 2011-09-15 07:07:46 --> Model Class Initialized
DEBUG - 2011-09-15 07:07:46 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-15 07:07:46 --> Database Driver Class Initialized
DEBUG - 2011-09-15 07:07:47 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-15 07:07:47 --> Helper loaded: url_helper
DEBUG - 2011-09-15 07:07:47 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-15 07:07:47 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-15 07:07:47 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-15 07:07:47 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-15 07:07:47 --> Final output sent to browser
DEBUG - 2011-09-15 07:07:47 --> Total execution time: 0.6816
DEBUG - 2011-09-15 07:07:49 --> Config Class Initialized
DEBUG - 2011-09-15 07:07:49 --> Hooks Class Initialized
DEBUG - 2011-09-15 07:07:49 --> Utf8 Class Initialized
DEBUG - 2011-09-15 07:07:49 --> UTF-8 Support Enabled
DEBUG - 2011-09-15 07:07:49 --> URI Class Initialized
DEBUG - 2011-09-15 07:07:49 --> Router Class Initialized
ERROR - 2011-09-15 07:07:49 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-15 07:07:49 --> Config Class Initialized
DEBUG - 2011-09-15 07:07:49 --> Hooks Class Initialized
DEBUG - 2011-09-15 07:07:49 --> Utf8 Class Initialized
DEBUG - 2011-09-15 07:07:49 --> UTF-8 Support Enabled
DEBUG - 2011-09-15 07:07:49 --> URI Class Initialized
DEBUG - 2011-09-15 07:07:49 --> Router Class Initialized
ERROR - 2011-09-15 07:07:49 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-15 07:30:31 --> Config Class Initialized
DEBUG - 2011-09-15 07:30:31 --> Hooks Class Initialized
DEBUG - 2011-09-15 07:30:31 --> Utf8 Class Initialized
DEBUG - 2011-09-15 07:30:31 --> UTF-8 Support Enabled
DEBUG - 2011-09-15 07:30:31 --> URI Class Initialized
DEBUG - 2011-09-15 07:30:31 --> Router Class Initialized
DEBUG - 2011-09-15 07:30:31 --> No URI present. Default controller set.
DEBUG - 2011-09-15 07:30:31 --> Output Class Initialized
DEBUG - 2011-09-15 07:30:31 --> Input Class Initialized
DEBUG - 2011-09-15 07:30:31 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-15 07:30:31 --> Language Class Initialized
DEBUG - 2011-09-15 07:30:31 --> Loader Class Initialized
DEBUG - 2011-09-15 07:30:31 --> Controller Class Initialized
DEBUG - 2011-09-15 07:30:32 --> File loaded: application/views/splash/main.php
DEBUG - 2011-09-15 07:30:32 --> Helper loaded: url_helper
DEBUG - 2011-09-15 07:30:32 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-15 07:30:32 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-15 07:30:32 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-15 07:30:32 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-15 07:30:32 --> Final output sent to browser
DEBUG - 2011-09-15 07:30:32 --> Total execution time: 0.1300
DEBUG - 2011-09-15 09:03:17 --> Config Class Initialized
DEBUG - 2011-09-15 09:03:17 --> Hooks Class Initialized
DEBUG - 2011-09-15 09:03:17 --> Utf8 Class Initialized
DEBUG - 2011-09-15 09:03:17 --> UTF-8 Support Enabled
DEBUG - 2011-09-15 09:03:17 --> URI Class Initialized
DEBUG - 2011-09-15 09:03:17 --> Router Class Initialized
DEBUG - 2011-09-15 09:03:17 --> No URI present. Default controller set.
DEBUG - 2011-09-15 09:03:17 --> Output Class Initialized
DEBUG - 2011-09-15 09:03:17 --> Input Class Initialized
DEBUG - 2011-09-15 09:03:17 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-15 09:03:17 --> Language Class Initialized
DEBUG - 2011-09-15 09:03:17 --> Loader Class Initialized
DEBUG - 2011-09-15 09:03:17 --> Controller Class Initialized
DEBUG - 2011-09-15 09:03:17 --> File loaded: application/views/splash/main.php
DEBUG - 2011-09-15 09:03:18 --> Helper loaded: url_helper
DEBUG - 2011-09-15 09:03:18 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-15 09:03:18 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-15 09:03:18 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-15 09:03:18 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-15 09:03:18 --> Final output sent to browser
DEBUG - 2011-09-15 09:03:18 --> Total execution time: 0.1985
DEBUG - 2011-09-15 09:33:25 --> Config Class Initialized
DEBUG - 2011-09-15 09:33:25 --> Hooks Class Initialized
DEBUG - 2011-09-15 09:33:25 --> Utf8 Class Initialized
DEBUG - 2011-09-15 09:33:25 --> UTF-8 Support Enabled
DEBUG - 2011-09-15 09:33:25 --> URI Class Initialized
DEBUG - 2011-09-15 09:33:25 --> Router Class Initialized
ERROR - 2011-09-15 09:33:25 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-09-15 09:49:15 --> Config Class Initialized
DEBUG - 2011-09-15 09:49:15 --> Hooks Class Initialized
DEBUG - 2011-09-15 09:49:15 --> Utf8 Class Initialized
DEBUG - 2011-09-15 09:49:15 --> UTF-8 Support Enabled
DEBUG - 2011-09-15 09:49:15 --> URI Class Initialized
DEBUG - 2011-09-15 09:49:15 --> Router Class Initialized
DEBUG - 2011-09-15 09:49:16 --> Output Class Initialized
DEBUG - 2011-09-15 09:49:16 --> Input Class Initialized
DEBUG - 2011-09-15 09:49:16 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-15 09:49:16 --> Language Class Initialized
DEBUG - 2011-09-15 09:49:16 --> Loader Class Initialized
DEBUG - 2011-09-15 09:49:16 --> Controller Class Initialized
DEBUG - 2011-09-15 09:49:16 --> Model Class Initialized
DEBUG - 2011-09-15 09:49:16 --> Model Class Initialized
DEBUG - 2011-09-15 09:49:16 --> Model Class Initialized
DEBUG - 2011-09-15 09:49:16 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-15 09:49:16 --> Database Driver Class Initialized
DEBUG - 2011-09-15 09:49:17 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-15 09:49:17 --> Helper loaded: url_helper
DEBUG - 2011-09-15 09:49:17 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-15 09:49:17 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-15 09:49:17 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-15 09:49:17 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-15 09:49:17 --> Final output sent to browser
DEBUG - 2011-09-15 09:49:17 --> Total execution time: 1.6874
DEBUG - 2011-09-15 09:49:19 --> Config Class Initialized
DEBUG - 2011-09-15 09:49:19 --> Hooks Class Initialized
DEBUG - 2011-09-15 09:49:19 --> Utf8 Class Initialized
DEBUG - 2011-09-15 09:49:19 --> UTF-8 Support Enabled
DEBUG - 2011-09-15 09:49:19 --> URI Class Initialized
DEBUG - 2011-09-15 09:49:19 --> Router Class Initialized
ERROR - 2011-09-15 09:49:19 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-15 09:49:19 --> Config Class Initialized
DEBUG - 2011-09-15 09:49:19 --> Hooks Class Initialized
DEBUG - 2011-09-15 09:49:19 --> Utf8 Class Initialized
DEBUG - 2011-09-15 09:49:19 --> UTF-8 Support Enabled
DEBUG - 2011-09-15 09:49:19 --> URI Class Initialized
DEBUG - 2011-09-15 09:49:19 --> Router Class Initialized
ERROR - 2011-09-15 09:49:19 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-15 09:49:20 --> Config Class Initialized
DEBUG - 2011-09-15 09:49:20 --> Hooks Class Initialized
DEBUG - 2011-09-15 09:49:20 --> Utf8 Class Initialized
DEBUG - 2011-09-15 09:49:20 --> UTF-8 Support Enabled
DEBUG - 2011-09-15 09:49:20 --> URI Class Initialized
DEBUG - 2011-09-15 09:49:20 --> Router Class Initialized
ERROR - 2011-09-15 09:49:20 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-15 10:25:43 --> Config Class Initialized
DEBUG - 2011-09-15 10:25:43 --> Hooks Class Initialized
DEBUG - 2011-09-15 10:25:43 --> Utf8 Class Initialized
DEBUG - 2011-09-15 10:25:43 --> UTF-8 Support Enabled
DEBUG - 2011-09-15 10:25:43 --> URI Class Initialized
DEBUG - 2011-09-15 10:25:43 --> Router Class Initialized
DEBUG - 2011-09-15 10:25:43 --> Output Class Initialized
DEBUG - 2011-09-15 10:25:43 --> Input Class Initialized
DEBUG - 2011-09-15 10:25:43 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-15 10:25:43 --> Language Class Initialized
DEBUG - 2011-09-15 10:25:43 --> Loader Class Initialized
DEBUG - 2011-09-15 10:25:43 --> Controller Class Initialized
DEBUG - 2011-09-15 10:25:43 --> Model Class Initialized
DEBUG - 2011-09-15 10:25:43 --> Model Class Initialized
DEBUG - 2011-09-15 10:25:43 --> Model Class Initialized
DEBUG - 2011-09-15 10:25:43 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-15 10:25:43 --> Database Driver Class Initialized
DEBUG - 2011-09-15 10:25:44 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-15 10:25:44 --> Helper loaded: url_helper
DEBUG - 2011-09-15 10:25:44 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-15 10:25:44 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-15 10:25:44 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-15 10:25:44 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-15 10:25:44 --> Final output sent to browser
DEBUG - 2011-09-15 10:25:44 --> Total execution time: 0.5086
DEBUG - 2011-09-15 10:25:46 --> Config Class Initialized
DEBUG - 2011-09-15 10:25:46 --> Hooks Class Initialized
DEBUG - 2011-09-15 10:25:46 --> Utf8 Class Initialized
DEBUG - 2011-09-15 10:25:46 --> UTF-8 Support Enabled
DEBUG - 2011-09-15 10:25:46 --> URI Class Initialized
DEBUG - 2011-09-15 10:25:46 --> Router Class Initialized
DEBUG - 2011-09-15 10:25:46 --> Output Class Initialized
DEBUG - 2011-09-15 10:25:46 --> Input Class Initialized
DEBUG - 2011-09-15 10:25:46 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-15 10:25:46 --> Language Class Initialized
DEBUG - 2011-09-15 10:25:46 --> Loader Class Initialized
DEBUG - 2011-09-15 10:25:46 --> Controller Class Initialized
DEBUG - 2011-09-15 10:25:46 --> Model Class Initialized
DEBUG - 2011-09-15 10:25:46 --> Model Class Initialized
DEBUG - 2011-09-15 10:25:46 --> Model Class Initialized
DEBUG - 2011-09-15 10:25:46 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-15 10:25:46 --> Database Driver Class Initialized
DEBUG - 2011-09-15 10:25:46 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-15 10:25:46 --> Helper loaded: url_helper
DEBUG - 2011-09-15 10:25:46 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-15 10:25:46 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-15 10:25:46 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-15 10:25:46 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-15 10:25:46 --> Final output sent to browser
DEBUG - 2011-09-15 10:25:46 --> Total execution time: 0.0538
DEBUG - 2011-09-15 10:25:46 --> Config Class Initialized
DEBUG - 2011-09-15 10:25:46 --> Hooks Class Initialized
DEBUG - 2011-09-15 10:25:46 --> Utf8 Class Initialized
DEBUG - 2011-09-15 10:25:46 --> UTF-8 Support Enabled
DEBUG - 2011-09-15 10:25:46 --> URI Class Initialized
DEBUG - 2011-09-15 10:25:46 --> Router Class Initialized
ERROR - 2011-09-15 10:25:46 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-15 10:25:46 --> Config Class Initialized
DEBUG - 2011-09-15 10:25:46 --> Hooks Class Initialized
DEBUG - 2011-09-15 10:25:46 --> Utf8 Class Initialized
DEBUG - 2011-09-15 10:25:46 --> UTF-8 Support Enabled
DEBUG - 2011-09-15 10:25:46 --> URI Class Initialized
DEBUG - 2011-09-15 10:25:46 --> Router Class Initialized
ERROR - 2011-09-15 10:25:46 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-15 10:25:47 --> Config Class Initialized
DEBUG - 2011-09-15 10:25:47 --> Hooks Class Initialized
DEBUG - 2011-09-15 10:25:47 --> Utf8 Class Initialized
DEBUG - 2011-09-15 10:25:47 --> UTF-8 Support Enabled
DEBUG - 2011-09-15 10:25:47 --> URI Class Initialized
DEBUG - 2011-09-15 10:25:47 --> Router Class Initialized
ERROR - 2011-09-15 10:25:47 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-15 10:34:58 --> Config Class Initialized
DEBUG - 2011-09-15 10:34:58 --> Hooks Class Initialized
DEBUG - 2011-09-15 10:34:58 --> Utf8 Class Initialized
DEBUG - 2011-09-15 10:34:58 --> UTF-8 Support Enabled
DEBUG - 2011-09-15 10:34:58 --> URI Class Initialized
DEBUG - 2011-09-15 10:34:58 --> Router Class Initialized
DEBUG - 2011-09-15 10:34:58 --> Output Class Initialized
DEBUG - 2011-09-15 10:34:58 --> Input Class Initialized
DEBUG - 2011-09-15 10:34:58 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-15 10:34:58 --> Language Class Initialized
DEBUG - 2011-09-15 10:34:58 --> Loader Class Initialized
DEBUG - 2011-09-15 10:34:58 --> Controller Class Initialized
DEBUG - 2011-09-15 10:34:58 --> Model Class Initialized
DEBUG - 2011-09-15 10:34:58 --> Model Class Initialized
DEBUG - 2011-09-15 10:34:58 --> Model Class Initialized
DEBUG - 2011-09-15 10:34:58 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-15 10:34:58 --> Database Driver Class Initialized
DEBUG - 2011-09-15 10:34:58 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-15 10:34:58 --> Helper loaded: url_helper
DEBUG - 2011-09-15 10:34:58 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-15 10:34:58 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-15 10:34:58 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-15 10:34:58 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-15 10:34:58 --> Final output sent to browser
DEBUG - 2011-09-15 10:34:58 --> Total execution time: 0.0472
DEBUG - 2011-09-15 10:35:27 --> Config Class Initialized
DEBUG - 2011-09-15 10:35:27 --> Hooks Class Initialized
DEBUG - 2011-09-15 10:35:27 --> Utf8 Class Initialized
DEBUG - 2011-09-15 10:35:27 --> UTF-8 Support Enabled
DEBUG - 2011-09-15 10:35:27 --> URI Class Initialized
DEBUG - 2011-09-15 10:35:27 --> Router Class Initialized
DEBUG - 2011-09-15 10:35:27 --> Output Class Initialized
DEBUG - 2011-09-15 10:35:27 --> Input Class Initialized
DEBUG - 2011-09-15 10:35:27 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-15 10:35:27 --> Language Class Initialized
DEBUG - 2011-09-15 10:35:27 --> Loader Class Initialized
DEBUG - 2011-09-15 10:35:27 --> Controller Class Initialized
DEBUG - 2011-09-15 10:35:27 --> Model Class Initialized
DEBUG - 2011-09-15 10:35:27 --> Model Class Initialized
DEBUG - 2011-09-15 10:35:27 --> Model Class Initialized
DEBUG - 2011-09-15 10:35:27 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-15 10:35:27 --> Database Driver Class Initialized
DEBUG - 2011-09-15 10:35:30 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-15 10:35:30 --> Helper loaded: url_helper
DEBUG - 2011-09-15 10:35:30 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-15 10:35:30 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-15 10:35:30 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-15 10:35:30 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-15 10:35:30 --> Final output sent to browser
DEBUG - 2011-09-15 10:35:30 --> Total execution time: 2.9428
DEBUG - 2011-09-15 10:35:37 --> Config Class Initialized
DEBUG - 2011-09-15 10:35:37 --> Hooks Class Initialized
DEBUG - 2011-09-15 10:35:37 --> Utf8 Class Initialized
DEBUG - 2011-09-15 10:35:37 --> UTF-8 Support Enabled
DEBUG - 2011-09-15 10:35:37 --> URI Class Initialized
DEBUG - 2011-09-15 10:35:37 --> Router Class Initialized
DEBUG - 2011-09-15 10:35:37 --> Output Class Initialized
DEBUG - 2011-09-15 10:35:37 --> Input Class Initialized
DEBUG - 2011-09-15 10:35:37 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-15 10:35:37 --> Language Class Initialized
DEBUG - 2011-09-15 10:35:37 --> Loader Class Initialized
DEBUG - 2011-09-15 10:35:37 --> Controller Class Initialized
DEBUG - 2011-09-15 10:35:37 --> Model Class Initialized
DEBUG - 2011-09-15 10:35:37 --> Model Class Initialized
DEBUG - 2011-09-15 10:35:37 --> Model Class Initialized
DEBUG - 2011-09-15 10:35:37 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-15 10:35:37 --> Database Driver Class Initialized
DEBUG - 2011-09-15 10:35:37 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-15 10:35:37 --> Helper loaded: url_helper
DEBUG - 2011-09-15 10:35:37 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-15 10:35:37 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-15 10:35:37 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-15 10:35:37 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-15 10:35:37 --> Final output sent to browser
DEBUG - 2011-09-15 10:35:37 --> Total execution time: 0.0406
DEBUG - 2011-09-15 10:35:53 --> Config Class Initialized
DEBUG - 2011-09-15 10:35:53 --> Hooks Class Initialized
DEBUG - 2011-09-15 10:35:53 --> Utf8 Class Initialized
DEBUG - 2011-09-15 10:35:53 --> UTF-8 Support Enabled
DEBUG - 2011-09-15 10:35:53 --> URI Class Initialized
DEBUG - 2011-09-15 10:35:53 --> Router Class Initialized
DEBUG - 2011-09-15 10:35:53 --> Output Class Initialized
DEBUG - 2011-09-15 10:35:53 --> Input Class Initialized
DEBUG - 2011-09-15 10:35:53 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-15 10:35:53 --> Language Class Initialized
DEBUG - 2011-09-15 10:35:53 --> Loader Class Initialized
DEBUG - 2011-09-15 10:35:53 --> Controller Class Initialized
DEBUG - 2011-09-15 10:35:53 --> Model Class Initialized
DEBUG - 2011-09-15 10:35:53 --> Model Class Initialized
DEBUG - 2011-09-15 10:35:53 --> Model Class Initialized
DEBUG - 2011-09-15 10:35:53 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-15 10:35:53 --> Database Driver Class Initialized
DEBUG - 2011-09-15 10:35:54 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-15 10:35:54 --> Helper loaded: url_helper
DEBUG - 2011-09-15 10:35:54 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-15 10:35:54 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-15 10:35:54 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-15 10:35:54 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-15 10:35:54 --> Final output sent to browser
DEBUG - 2011-09-15 10:35:54 --> Total execution time: 0.5574
DEBUG - 2011-09-15 10:36:02 --> Config Class Initialized
DEBUG - 2011-09-15 10:36:02 --> Hooks Class Initialized
DEBUG - 2011-09-15 10:36:02 --> Utf8 Class Initialized
DEBUG - 2011-09-15 10:36:02 --> UTF-8 Support Enabled
DEBUG - 2011-09-15 10:36:02 --> URI Class Initialized
DEBUG - 2011-09-15 10:36:02 --> Router Class Initialized
DEBUG - 2011-09-15 10:36:02 --> Output Class Initialized
DEBUG - 2011-09-15 10:36:02 --> Input Class Initialized
DEBUG - 2011-09-15 10:36:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-15 10:36:02 --> Language Class Initialized
DEBUG - 2011-09-15 10:36:02 --> Loader Class Initialized
DEBUG - 2011-09-15 10:36:02 --> Controller Class Initialized
DEBUG - 2011-09-15 10:36:02 --> Model Class Initialized
DEBUG - 2011-09-15 10:36:02 --> Model Class Initialized
DEBUG - 2011-09-15 10:36:02 --> Model Class Initialized
DEBUG - 2011-09-15 10:36:02 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-15 10:36:02 --> Database Driver Class Initialized
DEBUG - 2011-09-15 10:36:03 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-15 10:36:03 --> Helper loaded: url_helper
DEBUG - 2011-09-15 10:36:03 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-15 10:36:03 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-15 10:36:03 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-15 10:36:03 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-15 10:36:03 --> Final output sent to browser
DEBUG - 2011-09-15 10:36:03 --> Total execution time: 0.1011
DEBUG - 2011-09-15 11:25:58 --> Config Class Initialized
DEBUG - 2011-09-15 11:25:58 --> Hooks Class Initialized
DEBUG - 2011-09-15 11:25:58 --> Utf8 Class Initialized
DEBUG - 2011-09-15 11:25:58 --> UTF-8 Support Enabled
DEBUG - 2011-09-15 11:25:58 --> URI Class Initialized
DEBUG - 2011-09-15 11:25:58 --> Router Class Initialized
DEBUG - 2011-09-15 11:25:58 --> No URI present. Default controller set.
DEBUG - 2011-09-15 11:25:58 --> Output Class Initialized
DEBUG - 2011-09-15 11:25:58 --> Input Class Initialized
DEBUG - 2011-09-15 11:25:58 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-15 11:25:58 --> Language Class Initialized
DEBUG - 2011-09-15 11:25:58 --> Loader Class Initialized
DEBUG - 2011-09-15 11:25:58 --> Controller Class Initialized
DEBUG - 2011-09-15 11:25:58 --> File loaded: application/views/splash/main.php
DEBUG - 2011-09-15 11:25:58 --> Helper loaded: url_helper
DEBUG - 2011-09-15 11:25:58 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-15 11:25:58 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-15 11:25:58 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-15 11:25:58 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-15 11:25:58 --> Final output sent to browser
DEBUG - 2011-09-15 11:25:58 --> Total execution time: 0.1073
DEBUG - 2011-09-15 11:30:44 --> Config Class Initialized
DEBUG - 2011-09-15 11:30:44 --> Hooks Class Initialized
DEBUG - 2011-09-15 11:30:44 --> Utf8 Class Initialized
DEBUG - 2011-09-15 11:30:44 --> UTF-8 Support Enabled
DEBUG - 2011-09-15 11:30:44 --> URI Class Initialized
DEBUG - 2011-09-15 11:30:44 --> Router Class Initialized
DEBUG - 2011-09-15 11:30:44 --> Output Class Initialized
DEBUG - 2011-09-15 11:30:44 --> Input Class Initialized
DEBUG - 2011-09-15 11:30:44 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-15 11:30:44 --> Language Class Initialized
DEBUG - 2011-09-15 11:30:44 --> Loader Class Initialized
DEBUG - 2011-09-15 11:30:44 --> Controller Class Initialized
ERROR - 2011-09-15 11:30:44 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-15 11:30:44 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-15 11:30:44 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-15 11:30:44 --> Model Class Initialized
DEBUG - 2011-09-15 11:30:44 --> Model Class Initialized
DEBUG - 2011-09-15 11:30:44 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-15 11:30:44 --> Database Driver Class Initialized
DEBUG - 2011-09-15 11:30:44 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-15 11:30:44 --> Helper loaded: url_helper
DEBUG - 2011-09-15 11:30:44 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-15 11:30:44 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-15 11:30:44 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-15 11:30:44 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-15 11:30:44 --> Final output sent to browser
DEBUG - 2011-09-15 11:30:44 --> Total execution time: 0.5104
DEBUG - 2011-09-15 12:46:28 --> Config Class Initialized
DEBUG - 2011-09-15 12:46:28 --> Hooks Class Initialized
DEBUG - 2011-09-15 12:46:28 --> Utf8 Class Initialized
DEBUG - 2011-09-15 12:46:28 --> UTF-8 Support Enabled
DEBUG - 2011-09-15 12:46:28 --> URI Class Initialized
DEBUG - 2011-09-15 12:46:28 --> Router Class Initialized
ERROR - 2011-09-15 12:46:28 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-09-15 13:41:17 --> Config Class Initialized
DEBUG - 2011-09-15 13:41:17 --> Hooks Class Initialized
DEBUG - 2011-09-15 13:41:17 --> Utf8 Class Initialized
DEBUG - 2011-09-15 13:41:17 --> UTF-8 Support Enabled
DEBUG - 2011-09-15 13:41:17 --> URI Class Initialized
DEBUG - 2011-09-15 13:41:17 --> Router Class Initialized
ERROR - 2011-09-15 13:41:17 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-09-15 16:58:56 --> Config Class Initialized
DEBUG - 2011-09-15 16:58:56 --> Hooks Class Initialized
DEBUG - 2011-09-15 16:58:56 --> Utf8 Class Initialized
DEBUG - 2011-09-15 16:58:56 --> UTF-8 Support Enabled
DEBUG - 2011-09-15 16:58:56 --> URI Class Initialized
DEBUG - 2011-09-15 16:58:56 --> Router Class Initialized
DEBUG - 2011-09-15 16:58:56 --> Output Class Initialized
DEBUG - 2011-09-15 16:58:56 --> Input Class Initialized
DEBUG - 2011-09-15 16:58:56 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-15 16:58:56 --> Language Class Initialized
DEBUG - 2011-09-15 16:58:56 --> Loader Class Initialized
DEBUG - 2011-09-15 16:58:56 --> Controller Class Initialized
ERROR - 2011-09-15 16:58:56 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-15 16:58:56 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-15 16:58:56 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-15 16:58:56 --> Model Class Initialized
DEBUG - 2011-09-15 16:58:56 --> Model Class Initialized
DEBUG - 2011-09-15 16:58:56 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-15 16:58:56 --> Database Driver Class Initialized
DEBUG - 2011-09-15 16:58:56 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-15 16:58:56 --> Helper loaded: url_helper
DEBUG - 2011-09-15 16:58:56 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-15 16:58:56 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-15 16:58:56 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-15 16:58:56 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-15 16:58:56 --> Final output sent to browser
DEBUG - 2011-09-15 16:58:56 --> Total execution time: 0.6345
DEBUG - 2011-09-15 16:58:57 --> Config Class Initialized
DEBUG - 2011-09-15 16:58:57 --> Hooks Class Initialized
DEBUG - 2011-09-15 16:58:57 --> Utf8 Class Initialized
DEBUG - 2011-09-15 16:58:57 --> UTF-8 Support Enabled
DEBUG - 2011-09-15 16:58:57 --> URI Class Initialized
DEBUG - 2011-09-15 16:58:57 --> Router Class Initialized
DEBUG - 2011-09-15 16:58:57 --> Output Class Initialized
DEBUG - 2011-09-15 16:58:57 --> Input Class Initialized
DEBUG - 2011-09-15 16:58:57 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-15 16:58:57 --> Language Class Initialized
DEBUG - 2011-09-15 16:58:57 --> Loader Class Initialized
DEBUG - 2011-09-15 16:58:57 --> Controller Class Initialized
DEBUG - 2011-09-15 16:58:57 --> Model Class Initialized
DEBUG - 2011-09-15 16:58:57 --> Model Class Initialized
DEBUG - 2011-09-15 16:58:57 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-15 16:58:57 --> Database Driver Class Initialized
DEBUG - 2011-09-15 16:58:58 --> Final output sent to browser
DEBUG - 2011-09-15 16:58:58 --> Total execution time: 0.7475
DEBUG - 2011-09-15 16:58:59 --> Config Class Initialized
DEBUG - 2011-09-15 16:58:59 --> Hooks Class Initialized
DEBUG - 2011-09-15 16:58:59 --> Utf8 Class Initialized
DEBUG - 2011-09-15 16:58:59 --> UTF-8 Support Enabled
DEBUG - 2011-09-15 16:58:59 --> URI Class Initialized
DEBUG - 2011-09-15 16:58:59 --> Router Class Initialized
ERROR - 2011-09-15 16:58:59 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-15 16:59:00 --> Config Class Initialized
DEBUG - 2011-09-15 16:59:00 --> Hooks Class Initialized
DEBUG - 2011-09-15 16:59:00 --> Utf8 Class Initialized
DEBUG - 2011-09-15 16:59:00 --> UTF-8 Support Enabled
DEBUG - 2011-09-15 16:59:00 --> URI Class Initialized
DEBUG - 2011-09-15 16:59:00 --> Router Class Initialized
ERROR - 2011-09-15 16:59:00 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-15 16:59:17 --> Config Class Initialized
DEBUG - 2011-09-15 16:59:17 --> Hooks Class Initialized
DEBUG - 2011-09-15 16:59:17 --> Utf8 Class Initialized
DEBUG - 2011-09-15 16:59:17 --> UTF-8 Support Enabled
DEBUG - 2011-09-15 16:59:17 --> URI Class Initialized
DEBUG - 2011-09-15 16:59:17 --> Router Class Initialized
DEBUG - 2011-09-15 16:59:17 --> Output Class Initialized
DEBUG - 2011-09-15 16:59:17 --> Input Class Initialized
DEBUG - 2011-09-15 16:59:17 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-15 16:59:17 --> Language Class Initialized
DEBUG - 2011-09-15 16:59:17 --> Loader Class Initialized
DEBUG - 2011-09-15 16:59:17 --> Controller Class Initialized
ERROR - 2011-09-15 16:59:17 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-15 16:59:17 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-15 16:59:17 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-15 16:59:17 --> Model Class Initialized
DEBUG - 2011-09-15 16:59:17 --> Model Class Initialized
DEBUG - 2011-09-15 16:59:17 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-15 16:59:17 --> Database Driver Class Initialized
DEBUG - 2011-09-15 16:59:17 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-15 16:59:17 --> Helper loaded: url_helper
DEBUG - 2011-09-15 16:59:17 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-15 16:59:17 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-15 16:59:17 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-15 16:59:17 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-15 16:59:17 --> Final output sent to browser
DEBUG - 2011-09-15 16:59:17 --> Total execution time: 0.0283
DEBUG - 2011-09-15 16:59:17 --> Config Class Initialized
DEBUG - 2011-09-15 16:59:17 --> Hooks Class Initialized
DEBUG - 2011-09-15 16:59:17 --> Utf8 Class Initialized
DEBUG - 2011-09-15 16:59:17 --> UTF-8 Support Enabled
DEBUG - 2011-09-15 16:59:17 --> URI Class Initialized
DEBUG - 2011-09-15 16:59:17 --> Router Class Initialized
DEBUG - 2011-09-15 16:59:17 --> Output Class Initialized
DEBUG - 2011-09-15 16:59:17 --> Input Class Initialized
DEBUG - 2011-09-15 16:59:17 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-15 16:59:17 --> Language Class Initialized
DEBUG - 2011-09-15 16:59:17 --> Loader Class Initialized
DEBUG - 2011-09-15 16:59:17 --> Controller Class Initialized
DEBUG - 2011-09-15 16:59:17 --> Model Class Initialized
DEBUG - 2011-09-15 16:59:17 --> Model Class Initialized
DEBUG - 2011-09-15 16:59:17 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-15 16:59:17 --> Database Driver Class Initialized
DEBUG - 2011-09-15 16:59:18 --> Final output sent to browser
DEBUG - 2011-09-15 16:59:18 --> Total execution time: 0.6022
DEBUG - 2011-09-15 16:59:38 --> Config Class Initialized
DEBUG - 2011-09-15 16:59:38 --> Hooks Class Initialized
DEBUG - 2011-09-15 16:59:38 --> Utf8 Class Initialized
DEBUG - 2011-09-15 16:59:38 --> UTF-8 Support Enabled
DEBUG - 2011-09-15 16:59:38 --> URI Class Initialized
DEBUG - 2011-09-15 16:59:38 --> Router Class Initialized
DEBUG - 2011-09-15 16:59:38 --> Output Class Initialized
DEBUG - 2011-09-15 16:59:38 --> Input Class Initialized
DEBUG - 2011-09-15 16:59:38 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-15 16:59:38 --> Language Class Initialized
DEBUG - 2011-09-15 16:59:38 --> Loader Class Initialized
DEBUG - 2011-09-15 16:59:38 --> Controller Class Initialized
ERROR - 2011-09-15 16:59:38 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-15 16:59:38 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-15 16:59:38 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-15 16:59:38 --> Model Class Initialized
DEBUG - 2011-09-15 16:59:38 --> Model Class Initialized
DEBUG - 2011-09-15 16:59:38 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-15 16:59:38 --> Database Driver Class Initialized
DEBUG - 2011-09-15 16:59:38 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-15 16:59:38 --> Helper loaded: url_helper
DEBUG - 2011-09-15 16:59:38 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-15 16:59:38 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-15 16:59:38 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-15 16:59:38 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-15 16:59:38 --> Final output sent to browser
DEBUG - 2011-09-15 16:59:38 --> Total execution time: 0.0391
DEBUG - 2011-09-15 16:59:38 --> Config Class Initialized
DEBUG - 2011-09-15 16:59:38 --> Hooks Class Initialized
DEBUG - 2011-09-15 16:59:38 --> Utf8 Class Initialized
DEBUG - 2011-09-15 16:59:38 --> UTF-8 Support Enabled
DEBUG - 2011-09-15 16:59:38 --> URI Class Initialized
DEBUG - 2011-09-15 16:59:38 --> Router Class Initialized
DEBUG - 2011-09-15 16:59:38 --> Output Class Initialized
DEBUG - 2011-09-15 16:59:38 --> Input Class Initialized
DEBUG - 2011-09-15 16:59:38 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-15 16:59:38 --> Language Class Initialized
DEBUG - 2011-09-15 16:59:38 --> Loader Class Initialized
DEBUG - 2011-09-15 16:59:38 --> Controller Class Initialized
DEBUG - 2011-09-15 16:59:38 --> Model Class Initialized
DEBUG - 2011-09-15 16:59:38 --> Model Class Initialized
DEBUG - 2011-09-15 16:59:38 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-15 16:59:38 --> Database Driver Class Initialized
DEBUG - 2011-09-15 16:59:39 --> Final output sent to browser
DEBUG - 2011-09-15 16:59:39 --> Total execution time: 0.6379
DEBUG - 2011-09-15 17:14:52 --> Config Class Initialized
DEBUG - 2011-09-15 17:14:52 --> Hooks Class Initialized
DEBUG - 2011-09-15 17:14:52 --> Utf8 Class Initialized
DEBUG - 2011-09-15 17:14:52 --> UTF-8 Support Enabled
DEBUG - 2011-09-15 17:14:52 --> URI Class Initialized
DEBUG - 2011-09-15 17:14:52 --> Router Class Initialized
ERROR - 2011-09-15 17:14:52 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-09-15 17:14:52 --> Config Class Initialized
DEBUG - 2011-09-15 17:14:52 --> Hooks Class Initialized
DEBUG - 2011-09-15 17:14:52 --> Utf8 Class Initialized
DEBUG - 2011-09-15 17:14:52 --> UTF-8 Support Enabled
DEBUG - 2011-09-15 17:14:52 --> URI Class Initialized
DEBUG - 2011-09-15 17:14:52 --> Router Class Initialized
DEBUG - 2011-09-15 17:14:52 --> Output Class Initialized
DEBUG - 2011-09-15 17:14:52 --> Input Class Initialized
DEBUG - 2011-09-15 17:14:52 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-15 17:14:52 --> Language Class Initialized
DEBUG - 2011-09-15 17:14:52 --> Loader Class Initialized
DEBUG - 2011-09-15 17:14:52 --> Controller Class Initialized
ERROR - 2011-09-15 17:14:52 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-15 17:14:52 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-15 17:14:52 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-15 17:14:52 --> Model Class Initialized
DEBUG - 2011-09-15 17:14:52 --> Model Class Initialized
DEBUG - 2011-09-15 17:14:52 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-15 17:14:52 --> Database Driver Class Initialized
DEBUG - 2011-09-15 17:14:52 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-15 17:14:52 --> Helper loaded: url_helper
DEBUG - 2011-09-15 17:14:52 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-15 17:14:52 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-15 17:14:52 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-15 17:14:52 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-15 17:14:52 --> Final output sent to browser
DEBUG - 2011-09-15 17:14:52 --> Total execution time: 0.0285
DEBUG - 2011-09-15 18:40:03 --> Config Class Initialized
DEBUG - 2011-09-15 18:40:03 --> Hooks Class Initialized
DEBUG - 2011-09-15 18:40:03 --> Utf8 Class Initialized
DEBUG - 2011-09-15 18:40:03 --> UTF-8 Support Enabled
DEBUG - 2011-09-15 18:40:03 --> URI Class Initialized
DEBUG - 2011-09-15 18:40:03 --> Router Class Initialized
DEBUG - 2011-09-15 18:40:03 --> Output Class Initialized
DEBUG - 2011-09-15 18:40:03 --> Input Class Initialized
DEBUG - 2011-09-15 18:40:03 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-15 18:40:03 --> Language Class Initialized
DEBUG - 2011-09-15 18:40:03 --> Loader Class Initialized
DEBUG - 2011-09-15 18:40:03 --> Controller Class Initialized
ERROR - 2011-09-15 18:40:03 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-15 18:40:03 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-15 18:40:03 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-15 18:40:03 --> Model Class Initialized
DEBUG - 2011-09-15 18:40:03 --> Model Class Initialized
DEBUG - 2011-09-15 18:40:03 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-15 18:40:03 --> Database Driver Class Initialized
DEBUG - 2011-09-15 18:40:04 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-15 18:40:04 --> Helper loaded: url_helper
DEBUG - 2011-09-15 18:40:04 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-15 18:40:04 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-15 18:40:04 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-15 18:40:04 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-15 18:40:04 --> Final output sent to browser
DEBUG - 2011-09-15 18:40:04 --> Total execution time: 0.7745
DEBUG - 2011-09-15 18:40:05 --> Config Class Initialized
DEBUG - 2011-09-15 18:40:05 --> Hooks Class Initialized
DEBUG - 2011-09-15 18:40:05 --> Utf8 Class Initialized
DEBUG - 2011-09-15 18:40:05 --> UTF-8 Support Enabled
DEBUG - 2011-09-15 18:40:05 --> URI Class Initialized
DEBUG - 2011-09-15 18:40:05 --> Router Class Initialized
DEBUG - 2011-09-15 18:40:05 --> Output Class Initialized
DEBUG - 2011-09-15 18:40:05 --> Input Class Initialized
DEBUG - 2011-09-15 18:40:05 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-15 18:40:05 --> Language Class Initialized
DEBUG - 2011-09-15 18:40:05 --> Loader Class Initialized
DEBUG - 2011-09-15 18:40:05 --> Controller Class Initialized
DEBUG - 2011-09-15 18:40:05 --> Model Class Initialized
DEBUG - 2011-09-15 18:40:05 --> Model Class Initialized
DEBUG - 2011-09-15 18:40:05 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-15 18:40:05 --> Database Driver Class Initialized
DEBUG - 2011-09-15 18:40:06 --> Final output sent to browser
DEBUG - 2011-09-15 18:40:06 --> Total execution time: 0.7087
DEBUG - 2011-09-15 18:40:07 --> Config Class Initialized
DEBUG - 2011-09-15 18:40:07 --> Hooks Class Initialized
DEBUG - 2011-09-15 18:40:07 --> Utf8 Class Initialized
DEBUG - 2011-09-15 18:40:07 --> UTF-8 Support Enabled
DEBUG - 2011-09-15 18:40:07 --> URI Class Initialized
DEBUG - 2011-09-15 18:40:07 --> Router Class Initialized
ERROR - 2011-09-15 18:40:07 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-15 18:40:07 --> Config Class Initialized
DEBUG - 2011-09-15 18:40:07 --> Hooks Class Initialized
DEBUG - 2011-09-15 18:40:07 --> Utf8 Class Initialized
DEBUG - 2011-09-15 18:40:07 --> UTF-8 Support Enabled
DEBUG - 2011-09-15 18:40:07 --> URI Class Initialized
DEBUG - 2011-09-15 18:40:07 --> Router Class Initialized
ERROR - 2011-09-15 18:40:07 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-15 18:40:08 --> Config Class Initialized
DEBUG - 2011-09-15 18:40:08 --> Hooks Class Initialized
DEBUG - 2011-09-15 18:40:08 --> Utf8 Class Initialized
DEBUG - 2011-09-15 18:40:08 --> UTF-8 Support Enabled
DEBUG - 2011-09-15 18:40:08 --> URI Class Initialized
DEBUG - 2011-09-15 18:40:08 --> Router Class Initialized
ERROR - 2011-09-15 18:40:08 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-15 18:41:22 --> Config Class Initialized
DEBUG - 2011-09-15 18:41:22 --> Hooks Class Initialized
DEBUG - 2011-09-15 18:41:22 --> Utf8 Class Initialized
DEBUG - 2011-09-15 18:41:22 --> UTF-8 Support Enabled
DEBUG - 2011-09-15 18:41:22 --> URI Class Initialized
DEBUG - 2011-09-15 18:41:22 --> Router Class Initialized
DEBUG - 2011-09-15 18:41:22 --> Output Class Initialized
DEBUG - 2011-09-15 18:41:22 --> Input Class Initialized
DEBUG - 2011-09-15 18:41:22 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-15 18:41:22 --> Language Class Initialized
DEBUG - 2011-09-15 18:41:22 --> Loader Class Initialized
DEBUG - 2011-09-15 18:41:22 --> Controller Class Initialized
ERROR - 2011-09-15 18:41:22 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-15 18:41:22 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-15 18:41:22 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-15 18:41:22 --> Model Class Initialized
DEBUG - 2011-09-15 18:41:22 --> Model Class Initialized
DEBUG - 2011-09-15 18:41:22 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-15 18:41:22 --> Database Driver Class Initialized
DEBUG - 2011-09-15 18:41:22 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-15 18:41:22 --> Helper loaded: url_helper
DEBUG - 2011-09-15 18:41:22 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-15 18:41:22 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-15 18:41:22 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-15 18:41:22 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-15 18:41:22 --> Final output sent to browser
DEBUG - 2011-09-15 18:41:22 --> Total execution time: 0.0324
DEBUG - 2011-09-15 18:41:23 --> Config Class Initialized
DEBUG - 2011-09-15 18:41:23 --> Hooks Class Initialized
DEBUG - 2011-09-15 18:41:23 --> Utf8 Class Initialized
DEBUG - 2011-09-15 18:41:23 --> UTF-8 Support Enabled
DEBUG - 2011-09-15 18:41:23 --> URI Class Initialized
DEBUG - 2011-09-15 18:41:23 --> Router Class Initialized
DEBUG - 2011-09-15 18:41:23 --> Output Class Initialized
DEBUG - 2011-09-15 18:41:23 --> Input Class Initialized
DEBUG - 2011-09-15 18:41:23 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-15 18:41:23 --> Language Class Initialized
DEBUG - 2011-09-15 18:41:23 --> Loader Class Initialized
DEBUG - 2011-09-15 18:41:23 --> Controller Class Initialized
DEBUG - 2011-09-15 18:41:23 --> Model Class Initialized
DEBUG - 2011-09-15 18:41:23 --> Model Class Initialized
DEBUG - 2011-09-15 18:41:23 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-15 18:41:23 --> Database Driver Class Initialized
DEBUG - 2011-09-15 18:41:23 --> Config Class Initialized
DEBUG - 2011-09-15 18:41:23 --> Hooks Class Initialized
DEBUG - 2011-09-15 18:41:23 --> Utf8 Class Initialized
DEBUG - 2011-09-15 18:41:23 --> UTF-8 Support Enabled
DEBUG - 2011-09-15 18:41:23 --> URI Class Initialized
DEBUG - 2011-09-15 18:41:23 --> Router Class Initialized
DEBUG - 2011-09-15 18:41:23 --> Output Class Initialized
DEBUG - 2011-09-15 18:41:23 --> Input Class Initialized
DEBUG - 2011-09-15 18:41:23 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-15 18:41:23 --> Language Class Initialized
DEBUG - 2011-09-15 18:41:23 --> Loader Class Initialized
DEBUG - 2011-09-15 18:41:23 --> Controller Class Initialized
ERROR - 2011-09-15 18:41:23 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-15 18:41:23 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-15 18:41:23 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-15 18:41:23 --> Model Class Initialized
DEBUG - 2011-09-15 18:41:23 --> Model Class Initialized
DEBUG - 2011-09-15 18:41:23 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-15 18:41:23 --> Database Driver Class Initialized
DEBUG - 2011-09-15 18:41:23 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-15 18:41:23 --> Helper loaded: url_helper
DEBUG - 2011-09-15 18:41:23 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-15 18:41:23 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-15 18:41:23 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-15 18:41:23 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-15 18:41:23 --> Final output sent to browser
DEBUG - 2011-09-15 18:41:23 --> Total execution time: 0.0281
DEBUG - 2011-09-15 18:41:24 --> Final output sent to browser
DEBUG - 2011-09-15 18:41:24 --> Total execution time: 0.6424
DEBUG - 2011-09-15 18:41:30 --> Config Class Initialized
DEBUG - 2011-09-15 18:41:30 --> Hooks Class Initialized
DEBUG - 2011-09-15 18:41:30 --> Utf8 Class Initialized
DEBUG - 2011-09-15 18:41:30 --> UTF-8 Support Enabled
DEBUG - 2011-09-15 18:41:30 --> URI Class Initialized
DEBUG - 2011-09-15 18:41:30 --> Router Class Initialized
DEBUG - 2011-09-15 18:41:30 --> Output Class Initialized
DEBUG - 2011-09-15 18:41:30 --> Input Class Initialized
DEBUG - 2011-09-15 18:41:30 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-15 18:41:30 --> Language Class Initialized
DEBUG - 2011-09-15 18:41:30 --> Loader Class Initialized
DEBUG - 2011-09-15 18:41:30 --> Controller Class Initialized
ERROR - 2011-09-15 18:41:30 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-15 18:41:30 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-15 18:41:30 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-15 18:41:30 --> Model Class Initialized
DEBUG - 2011-09-15 18:41:30 --> Model Class Initialized
DEBUG - 2011-09-15 18:41:30 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-15 18:41:30 --> Database Driver Class Initialized
DEBUG - 2011-09-15 18:41:30 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-15 18:41:30 --> Helper loaded: url_helper
DEBUG - 2011-09-15 18:41:30 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-15 18:41:30 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-15 18:41:30 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-15 18:41:30 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-15 18:41:30 --> Final output sent to browser
DEBUG - 2011-09-15 18:41:30 --> Total execution time: 0.0344
DEBUG - 2011-09-15 18:41:31 --> Config Class Initialized
DEBUG - 2011-09-15 18:41:31 --> Hooks Class Initialized
DEBUG - 2011-09-15 18:41:31 --> Utf8 Class Initialized
DEBUG - 2011-09-15 18:41:31 --> UTF-8 Support Enabled
DEBUG - 2011-09-15 18:41:31 --> URI Class Initialized
DEBUG - 2011-09-15 18:41:31 --> Router Class Initialized
DEBUG - 2011-09-15 18:41:31 --> Output Class Initialized
DEBUG - 2011-09-15 18:41:31 --> Input Class Initialized
DEBUG - 2011-09-15 18:41:31 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-15 18:41:31 --> Language Class Initialized
DEBUG - 2011-09-15 18:41:31 --> Loader Class Initialized
DEBUG - 2011-09-15 18:41:31 --> Controller Class Initialized
DEBUG - 2011-09-15 18:41:31 --> Model Class Initialized
DEBUG - 2011-09-15 18:41:31 --> Model Class Initialized
DEBUG - 2011-09-15 18:41:31 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-15 18:41:31 --> Database Driver Class Initialized
DEBUG - 2011-09-15 18:41:32 --> Final output sent to browser
DEBUG - 2011-09-15 18:41:32 --> Total execution time: 0.6547
DEBUG - 2011-09-15 18:47:51 --> Config Class Initialized
DEBUG - 2011-09-15 18:47:51 --> Hooks Class Initialized
DEBUG - 2011-09-15 18:47:51 --> Utf8 Class Initialized
DEBUG - 2011-09-15 18:47:51 --> UTF-8 Support Enabled
DEBUG - 2011-09-15 18:47:51 --> URI Class Initialized
DEBUG - 2011-09-15 18:47:51 --> Router Class Initialized
DEBUG - 2011-09-15 18:47:52 --> No URI present. Default controller set.
DEBUG - 2011-09-15 18:47:52 --> Output Class Initialized
DEBUG - 2011-09-15 18:47:52 --> Input Class Initialized
DEBUG - 2011-09-15 18:47:52 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-15 18:47:52 --> Language Class Initialized
DEBUG - 2011-09-15 18:47:52 --> Loader Class Initialized
DEBUG - 2011-09-15 18:47:52 --> Controller Class Initialized
DEBUG - 2011-09-15 18:47:52 --> File loaded: application/views/splash/main.php
DEBUG - 2011-09-15 18:47:52 --> Helper loaded: url_helper
DEBUG - 2011-09-15 18:47:52 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-15 18:47:52 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-15 18:47:52 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-15 18:47:52 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-15 18:47:52 --> Final output sent to browser
DEBUG - 2011-09-15 18:47:52 --> Total execution time: 0.0892
DEBUG - 2011-09-15 19:00:57 --> Config Class Initialized
DEBUG - 2011-09-15 19:00:57 --> Hooks Class Initialized
DEBUG - 2011-09-15 19:00:57 --> Utf8 Class Initialized
DEBUG - 2011-09-15 19:00:57 --> UTF-8 Support Enabled
DEBUG - 2011-09-15 19:00:57 --> URI Class Initialized
DEBUG - 2011-09-15 19:00:57 --> Router Class Initialized
DEBUG - 2011-09-15 19:00:57 --> Output Class Initialized
DEBUG - 2011-09-15 19:00:57 --> Input Class Initialized
DEBUG - 2011-09-15 19:00:57 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-15 19:00:57 --> Language Class Initialized
DEBUG - 2011-09-15 19:00:57 --> Loader Class Initialized
DEBUG - 2011-09-15 19:00:58 --> Controller Class Initialized
ERROR - 2011-09-15 19:00:58 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-15 19:00:58 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-15 19:00:58 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-15 19:00:58 --> Model Class Initialized
DEBUG - 2011-09-15 19:00:58 --> Model Class Initialized
DEBUG - 2011-09-15 19:00:58 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-15 19:00:58 --> Database Driver Class Initialized
DEBUG - 2011-09-15 19:00:58 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-15 19:00:58 --> Helper loaded: url_helper
DEBUG - 2011-09-15 19:00:58 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-15 19:00:58 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-15 19:00:58 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-15 19:00:58 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-15 19:00:58 --> Final output sent to browser
DEBUG - 2011-09-15 19:00:58 --> Total execution time: 0.0901
DEBUG - 2011-09-15 19:00:58 --> Config Class Initialized
DEBUG - 2011-09-15 19:00:58 --> Hooks Class Initialized
DEBUG - 2011-09-15 19:00:58 --> Utf8 Class Initialized
DEBUG - 2011-09-15 19:00:58 --> UTF-8 Support Enabled
DEBUG - 2011-09-15 19:00:58 --> URI Class Initialized
DEBUG - 2011-09-15 19:00:58 --> Router Class Initialized
DEBUG - 2011-09-15 19:00:58 --> Output Class Initialized
DEBUG - 2011-09-15 19:00:58 --> Input Class Initialized
DEBUG - 2011-09-15 19:00:58 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-15 19:00:58 --> Language Class Initialized
DEBUG - 2011-09-15 19:00:58 --> Loader Class Initialized
DEBUG - 2011-09-15 19:00:58 --> Controller Class Initialized
DEBUG - 2011-09-15 19:00:58 --> Model Class Initialized
DEBUG - 2011-09-15 19:00:58 --> Model Class Initialized
DEBUG - 2011-09-15 19:00:58 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-15 19:00:58 --> Database Driver Class Initialized
DEBUG - 2011-09-15 19:00:59 --> Config Class Initialized
DEBUG - 2011-09-15 19:00:59 --> Hooks Class Initialized
DEBUG - 2011-09-15 19:00:59 --> Utf8 Class Initialized
DEBUG - 2011-09-15 19:00:59 --> UTF-8 Support Enabled
DEBUG - 2011-09-15 19:00:59 --> URI Class Initialized
DEBUG - 2011-09-15 19:00:59 --> Router Class Initialized
DEBUG - 2011-09-15 19:00:59 --> Output Class Initialized
DEBUG - 2011-09-15 19:00:59 --> Input Class Initialized
DEBUG - 2011-09-15 19:00:59 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-15 19:00:59 --> Language Class Initialized
DEBUG - 2011-09-15 19:00:59 --> Loader Class Initialized
DEBUG - 2011-09-15 19:00:59 --> Controller Class Initialized
DEBUG - 2011-09-15 19:00:59 --> Model Class Initialized
DEBUG - 2011-09-15 19:00:59 --> Model Class Initialized
DEBUG - 2011-09-15 19:00:59 --> Model Class Initialized
DEBUG - 2011-09-15 19:00:59 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-15 19:00:59 --> Database Driver Class Initialized
DEBUG - 2011-09-15 19:00:59 --> Final output sent to browser
DEBUG - 2011-09-15 19:00:59 --> Total execution time: 0.7803
DEBUG - 2011-09-15 19:01:00 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-15 19:01:00 --> Helper loaded: url_helper
DEBUG - 2011-09-15 19:01:00 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-15 19:01:00 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-15 19:01:00 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-15 19:01:00 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-15 19:01:00 --> Final output sent to browser
DEBUG - 2011-09-15 19:01:00 --> Total execution time: 0.7856
DEBUG - 2011-09-15 19:01:01 --> Config Class Initialized
DEBUG - 2011-09-15 19:01:01 --> Hooks Class Initialized
DEBUG - 2011-09-15 19:01:01 --> Utf8 Class Initialized
DEBUG - 2011-09-15 19:01:01 --> UTF-8 Support Enabled
DEBUG - 2011-09-15 19:01:01 --> URI Class Initialized
DEBUG - 2011-09-15 19:01:01 --> Router Class Initialized
ERROR - 2011-09-15 19:01:01 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-15 19:01:01 --> Config Class Initialized
DEBUG - 2011-09-15 19:01:01 --> Hooks Class Initialized
DEBUG - 2011-09-15 19:01:01 --> Utf8 Class Initialized
DEBUG - 2011-09-15 19:01:01 --> UTF-8 Support Enabled
DEBUG - 2011-09-15 19:01:01 --> URI Class Initialized
DEBUG - 2011-09-15 19:01:01 --> Router Class Initialized
ERROR - 2011-09-15 19:01:01 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-15 19:01:19 --> Config Class Initialized
DEBUG - 2011-09-15 19:01:19 --> Hooks Class Initialized
DEBUG - 2011-09-15 19:01:19 --> Utf8 Class Initialized
DEBUG - 2011-09-15 19:01:19 --> UTF-8 Support Enabled
DEBUG - 2011-09-15 19:01:19 --> URI Class Initialized
DEBUG - 2011-09-15 19:01:19 --> Router Class Initialized
DEBUG - 2011-09-15 19:01:19 --> Output Class Initialized
DEBUG - 2011-09-15 19:01:19 --> Input Class Initialized
DEBUG - 2011-09-15 19:01:19 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-15 19:01:19 --> Language Class Initialized
DEBUG - 2011-09-15 19:01:19 --> Loader Class Initialized
DEBUG - 2011-09-15 19:01:19 --> Controller Class Initialized
ERROR - 2011-09-15 19:01:19 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-15 19:01:19 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-15 19:01:19 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-15 19:01:19 --> Model Class Initialized
DEBUG - 2011-09-15 19:01:19 --> Model Class Initialized
DEBUG - 2011-09-15 19:01:19 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-15 19:01:19 --> Database Driver Class Initialized
DEBUG - 2011-09-15 19:01:19 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-15 19:01:19 --> Helper loaded: url_helper
DEBUG - 2011-09-15 19:01:19 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-15 19:01:19 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-15 19:01:19 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-15 19:01:19 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-15 19:01:19 --> Final output sent to browser
DEBUG - 2011-09-15 19:01:19 --> Total execution time: 0.0286
DEBUG - 2011-09-15 19:01:20 --> Config Class Initialized
DEBUG - 2011-09-15 19:01:20 --> Hooks Class Initialized
DEBUG - 2011-09-15 19:01:20 --> Utf8 Class Initialized
DEBUG - 2011-09-15 19:01:20 --> UTF-8 Support Enabled
DEBUG - 2011-09-15 19:01:20 --> URI Class Initialized
DEBUG - 2011-09-15 19:01:20 --> Router Class Initialized
DEBUG - 2011-09-15 19:01:20 --> Output Class Initialized
DEBUG - 2011-09-15 19:01:20 --> Input Class Initialized
DEBUG - 2011-09-15 19:01:20 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-15 19:01:20 --> Language Class Initialized
DEBUG - 2011-09-15 19:01:20 --> Loader Class Initialized
DEBUG - 2011-09-15 19:01:20 --> Controller Class Initialized
DEBUG - 2011-09-15 19:01:20 --> Model Class Initialized
DEBUG - 2011-09-15 19:01:20 --> Model Class Initialized
DEBUG - 2011-09-15 19:01:20 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-15 19:01:20 --> Database Driver Class Initialized
DEBUG - 2011-09-15 19:01:21 --> Final output sent to browser
DEBUG - 2011-09-15 19:01:21 --> Total execution time: 0.5935
DEBUG - 2011-09-15 19:01:21 --> Config Class Initialized
DEBUG - 2011-09-15 19:01:21 --> Hooks Class Initialized
DEBUG - 2011-09-15 19:01:21 --> Utf8 Class Initialized
DEBUG - 2011-09-15 19:01:21 --> UTF-8 Support Enabled
DEBUG - 2011-09-15 19:01:21 --> URI Class Initialized
DEBUG - 2011-09-15 19:01:21 --> Router Class Initialized
DEBUG - 2011-09-15 19:01:21 --> Output Class Initialized
DEBUG - 2011-09-15 19:01:21 --> Input Class Initialized
DEBUG - 2011-09-15 19:01:21 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-15 19:01:21 --> Language Class Initialized
DEBUG - 2011-09-15 19:01:21 --> Loader Class Initialized
DEBUG - 2011-09-15 19:01:21 --> Controller Class Initialized
ERROR - 2011-09-15 19:01:21 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-15 19:01:21 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-15 19:01:21 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-15 19:01:21 --> Model Class Initialized
DEBUG - 2011-09-15 19:01:21 --> Model Class Initialized
DEBUG - 2011-09-15 19:01:21 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-15 19:01:21 --> Database Driver Class Initialized
DEBUG - 2011-09-15 19:01:21 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-15 19:01:21 --> Helper loaded: url_helper
DEBUG - 2011-09-15 19:01:21 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-15 19:01:21 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-15 19:01:21 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-15 19:01:21 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-15 19:01:21 --> Final output sent to browser
DEBUG - 2011-09-15 19:01:21 --> Total execution time: 0.0272
DEBUG - 2011-09-15 19:01:21 --> Config Class Initialized
DEBUG - 2011-09-15 19:01:21 --> Hooks Class Initialized
DEBUG - 2011-09-15 19:01:21 --> Utf8 Class Initialized
DEBUG - 2011-09-15 19:01:21 --> UTF-8 Support Enabled
DEBUG - 2011-09-15 19:01:21 --> URI Class Initialized
DEBUG - 2011-09-15 19:01:21 --> Router Class Initialized
ERROR - 2011-09-15 19:01:21 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-15 19:01:53 --> Config Class Initialized
DEBUG - 2011-09-15 19:01:53 --> Hooks Class Initialized
DEBUG - 2011-09-15 19:01:53 --> Utf8 Class Initialized
DEBUG - 2011-09-15 19:01:53 --> UTF-8 Support Enabled
DEBUG - 2011-09-15 19:01:53 --> URI Class Initialized
DEBUG - 2011-09-15 19:01:53 --> Router Class Initialized
DEBUG - 2011-09-15 19:01:53 --> Output Class Initialized
DEBUG - 2011-09-15 19:01:53 --> Input Class Initialized
DEBUG - 2011-09-15 19:01:53 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-15 19:01:53 --> Language Class Initialized
DEBUG - 2011-09-15 19:01:53 --> Loader Class Initialized
DEBUG - 2011-09-15 19:01:53 --> Controller Class Initialized
DEBUG - 2011-09-15 19:01:53 --> Model Class Initialized
DEBUG - 2011-09-15 19:01:53 --> Model Class Initialized
DEBUG - 2011-09-15 19:01:53 --> Model Class Initialized
DEBUG - 2011-09-15 19:01:53 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-15 19:01:53 --> Database Driver Class Initialized
DEBUG - 2011-09-15 19:01:53 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-15 19:01:53 --> Helper loaded: url_helper
DEBUG - 2011-09-15 19:01:53 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-15 19:01:53 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-15 19:01:53 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-15 19:01:53 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-15 19:01:53 --> Final output sent to browser
DEBUG - 2011-09-15 19:01:53 --> Total execution time: 0.2531
DEBUG - 2011-09-15 19:01:54 --> Config Class Initialized
DEBUG - 2011-09-15 19:01:54 --> Hooks Class Initialized
DEBUG - 2011-09-15 19:01:54 --> Utf8 Class Initialized
DEBUG - 2011-09-15 19:01:54 --> UTF-8 Support Enabled
DEBUG - 2011-09-15 19:01:54 --> URI Class Initialized
DEBUG - 2011-09-15 19:01:54 --> Router Class Initialized
DEBUG - 2011-09-15 19:01:54 --> Output Class Initialized
DEBUG - 2011-09-15 19:01:54 --> Input Class Initialized
DEBUG - 2011-09-15 19:01:54 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-15 19:01:54 --> Language Class Initialized
DEBUG - 2011-09-15 19:01:54 --> Loader Class Initialized
DEBUG - 2011-09-15 19:01:54 --> Controller Class Initialized
DEBUG - 2011-09-15 19:01:54 --> Model Class Initialized
DEBUG - 2011-09-15 19:01:54 --> Model Class Initialized
DEBUG - 2011-09-15 19:01:54 --> Model Class Initialized
DEBUG - 2011-09-15 19:01:54 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-15 19:01:54 --> Database Driver Class Initialized
DEBUG - 2011-09-15 19:01:54 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-15 19:01:54 --> Helper loaded: url_helper
DEBUG - 2011-09-15 19:01:54 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-15 19:01:54 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-15 19:01:54 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-15 19:01:54 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-15 19:01:54 --> Final output sent to browser
DEBUG - 2011-09-15 19:01:54 --> Total execution time: 0.0441
DEBUG - 2011-09-15 19:01:55 --> Config Class Initialized
DEBUG - 2011-09-15 19:01:55 --> Hooks Class Initialized
DEBUG - 2011-09-15 19:01:55 --> Utf8 Class Initialized
DEBUG - 2011-09-15 19:01:55 --> UTF-8 Support Enabled
DEBUG - 2011-09-15 19:01:55 --> URI Class Initialized
DEBUG - 2011-09-15 19:01:55 --> Router Class Initialized
ERROR - 2011-09-15 19:01:55 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-15 19:02:07 --> Config Class Initialized
DEBUG - 2011-09-15 19:02:07 --> Hooks Class Initialized
DEBUG - 2011-09-15 19:02:07 --> Utf8 Class Initialized
DEBUG - 2011-09-15 19:02:07 --> UTF-8 Support Enabled
DEBUG - 2011-09-15 19:02:07 --> URI Class Initialized
DEBUG - 2011-09-15 19:02:07 --> Router Class Initialized
DEBUG - 2011-09-15 19:02:07 --> Output Class Initialized
DEBUG - 2011-09-15 19:02:07 --> Input Class Initialized
DEBUG - 2011-09-15 19:02:07 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-15 19:02:07 --> Language Class Initialized
DEBUG - 2011-09-15 19:02:07 --> Loader Class Initialized
DEBUG - 2011-09-15 19:02:07 --> Controller Class Initialized
DEBUG - 2011-09-15 19:02:07 --> Model Class Initialized
DEBUG - 2011-09-15 19:02:07 --> Model Class Initialized
DEBUG - 2011-09-15 19:02:07 --> Model Class Initialized
DEBUG - 2011-09-15 19:02:07 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-15 19:02:07 --> Database Driver Class Initialized
DEBUG - 2011-09-15 19:02:08 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-15 19:02:08 --> Helper loaded: url_helper
DEBUG - 2011-09-15 19:02:08 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-15 19:02:08 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-15 19:02:08 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-15 19:02:08 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-15 19:02:08 --> Final output sent to browser
DEBUG - 2011-09-15 19:02:08 --> Total execution time: 0.5578
DEBUG - 2011-09-15 19:02:09 --> Config Class Initialized
DEBUG - 2011-09-15 19:02:09 --> Hooks Class Initialized
DEBUG - 2011-09-15 19:02:09 --> Utf8 Class Initialized
DEBUG - 2011-09-15 19:02:09 --> UTF-8 Support Enabled
DEBUG - 2011-09-15 19:02:09 --> URI Class Initialized
DEBUG - 2011-09-15 19:02:09 --> Router Class Initialized
ERROR - 2011-09-15 19:02:09 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-15 19:02:13 --> Config Class Initialized
DEBUG - 2011-09-15 19:02:13 --> Hooks Class Initialized
DEBUG - 2011-09-15 19:02:13 --> Utf8 Class Initialized
DEBUG - 2011-09-15 19:02:13 --> UTF-8 Support Enabled
DEBUG - 2011-09-15 19:02:13 --> URI Class Initialized
DEBUG - 2011-09-15 19:02:13 --> Router Class Initialized
DEBUG - 2011-09-15 19:02:13 --> Output Class Initialized
DEBUG - 2011-09-15 19:02:13 --> Input Class Initialized
DEBUG - 2011-09-15 19:02:13 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-15 19:02:13 --> Language Class Initialized
DEBUG - 2011-09-15 19:02:13 --> Loader Class Initialized
DEBUG - 2011-09-15 19:02:13 --> Controller Class Initialized
DEBUG - 2011-09-15 19:02:13 --> Model Class Initialized
DEBUG - 2011-09-15 19:02:13 --> Model Class Initialized
DEBUG - 2011-09-15 19:02:13 --> Model Class Initialized
DEBUG - 2011-09-15 19:02:13 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-15 19:02:13 --> Database Driver Class Initialized
DEBUG - 2011-09-15 19:02:13 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-15 19:02:13 --> Helper loaded: url_helper
DEBUG - 2011-09-15 19:02:13 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-15 19:02:13 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-15 19:02:13 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-15 19:02:13 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-15 19:02:13 --> Final output sent to browser
DEBUG - 2011-09-15 19:02:13 --> Total execution time: 0.0947
DEBUG - 2011-09-15 19:02:15 --> Config Class Initialized
DEBUG - 2011-09-15 19:02:15 --> Hooks Class Initialized
DEBUG - 2011-09-15 19:02:15 --> Utf8 Class Initialized
DEBUG - 2011-09-15 19:02:15 --> UTF-8 Support Enabled
DEBUG - 2011-09-15 19:02:15 --> URI Class Initialized
DEBUG - 2011-09-15 19:02:15 --> Router Class Initialized
DEBUG - 2011-09-15 19:02:15 --> Output Class Initialized
DEBUG - 2011-09-15 19:02:15 --> Input Class Initialized
DEBUG - 2011-09-15 19:02:15 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-15 19:02:15 --> Language Class Initialized
DEBUG - 2011-09-15 19:02:15 --> Loader Class Initialized
DEBUG - 2011-09-15 19:02:15 --> Controller Class Initialized
DEBUG - 2011-09-15 19:02:15 --> Model Class Initialized
DEBUG - 2011-09-15 19:02:15 --> Model Class Initialized
DEBUG - 2011-09-15 19:02:15 --> Model Class Initialized
DEBUG - 2011-09-15 19:02:15 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-15 19:02:15 --> Database Driver Class Initialized
DEBUG - 2011-09-15 19:02:15 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-15 19:02:15 --> Helper loaded: url_helper
DEBUG - 2011-09-15 19:02:15 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-15 19:02:15 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-15 19:02:15 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-15 19:02:15 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-15 19:02:15 --> Final output sent to browser
DEBUG - 2011-09-15 19:02:15 --> Total execution time: 0.4677
DEBUG - 2011-09-15 19:02:16 --> Config Class Initialized
DEBUG - 2011-09-15 19:02:16 --> Hooks Class Initialized
DEBUG - 2011-09-15 19:02:16 --> Utf8 Class Initialized
DEBUG - 2011-09-15 19:02:16 --> UTF-8 Support Enabled
DEBUG - 2011-09-15 19:02:16 --> URI Class Initialized
DEBUG - 2011-09-15 19:02:16 --> Router Class Initialized
DEBUG - 2011-09-15 19:02:16 --> Output Class Initialized
DEBUG - 2011-09-15 19:02:16 --> Input Class Initialized
DEBUG - 2011-09-15 19:02:16 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-15 19:02:16 --> Language Class Initialized
DEBUG - 2011-09-15 19:02:16 --> Loader Class Initialized
DEBUG - 2011-09-15 19:02:16 --> Controller Class Initialized
DEBUG - 2011-09-15 19:02:16 --> Model Class Initialized
DEBUG - 2011-09-15 19:02:16 --> Model Class Initialized
DEBUG - 2011-09-15 19:02:16 --> Model Class Initialized
DEBUG - 2011-09-15 19:02:16 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-15 19:02:16 --> Database Driver Class Initialized
DEBUG - 2011-09-15 19:02:16 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-15 19:02:16 --> Helper loaded: url_helper
DEBUG - 2011-09-15 19:02:16 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-15 19:02:16 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-15 19:02:16 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-15 19:02:16 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-15 19:02:16 --> Final output sent to browser
DEBUG - 2011-09-15 19:02:16 --> Total execution time: 0.2030
DEBUG - 2011-09-15 19:02:17 --> Config Class Initialized
DEBUG - 2011-09-15 19:02:17 --> Hooks Class Initialized
DEBUG - 2011-09-15 19:02:17 --> Utf8 Class Initialized
DEBUG - 2011-09-15 19:02:17 --> UTF-8 Support Enabled
DEBUG - 2011-09-15 19:02:17 --> URI Class Initialized
DEBUG - 2011-09-15 19:02:17 --> Router Class Initialized
ERROR - 2011-09-15 19:02:17 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-15 19:02:21 --> Config Class Initialized
DEBUG - 2011-09-15 19:02:21 --> Hooks Class Initialized
DEBUG - 2011-09-15 19:02:21 --> Utf8 Class Initialized
DEBUG - 2011-09-15 19:02:21 --> UTF-8 Support Enabled
DEBUG - 2011-09-15 19:02:21 --> URI Class Initialized
DEBUG - 2011-09-15 19:02:21 --> Router Class Initialized
DEBUG - 2011-09-15 19:02:21 --> Output Class Initialized
DEBUG - 2011-09-15 19:02:21 --> Input Class Initialized
DEBUG - 2011-09-15 19:02:21 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-15 19:02:21 --> Language Class Initialized
DEBUG - 2011-09-15 19:02:21 --> Loader Class Initialized
DEBUG - 2011-09-15 19:02:21 --> Controller Class Initialized
DEBUG - 2011-09-15 19:02:21 --> Model Class Initialized
DEBUG - 2011-09-15 19:02:21 --> Model Class Initialized
DEBUG - 2011-09-15 19:02:21 --> Model Class Initialized
DEBUG - 2011-09-15 19:02:21 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-15 19:02:21 --> Database Driver Class Initialized
DEBUG - 2011-09-15 19:02:21 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-15 19:02:21 --> Helper loaded: url_helper
DEBUG - 2011-09-15 19:02:21 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-15 19:02:21 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-15 19:02:21 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-15 19:02:21 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-15 19:02:21 --> Final output sent to browser
DEBUG - 2011-09-15 19:02:21 --> Total execution time: 0.5253
DEBUG - 2011-09-15 19:02:22 --> Config Class Initialized
DEBUG - 2011-09-15 19:02:22 --> Hooks Class Initialized
DEBUG - 2011-09-15 19:02:22 --> Utf8 Class Initialized
DEBUG - 2011-09-15 19:02:22 --> UTF-8 Support Enabled
DEBUG - 2011-09-15 19:02:22 --> URI Class Initialized
DEBUG - 2011-09-15 19:02:22 --> Router Class Initialized
DEBUG - 2011-09-15 19:02:22 --> Output Class Initialized
DEBUG - 2011-09-15 19:02:22 --> Input Class Initialized
DEBUG - 2011-09-15 19:02:22 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-15 19:02:22 --> Language Class Initialized
DEBUG - 2011-09-15 19:02:22 --> Loader Class Initialized
DEBUG - 2011-09-15 19:02:22 --> Controller Class Initialized
DEBUG - 2011-09-15 19:02:22 --> Model Class Initialized
DEBUG - 2011-09-15 19:02:22 --> Model Class Initialized
DEBUG - 2011-09-15 19:02:22 --> Model Class Initialized
DEBUG - 2011-09-15 19:02:22 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-15 19:02:22 --> Database Driver Class Initialized
DEBUG - 2011-09-15 19:02:22 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-15 19:02:22 --> Helper loaded: url_helper
DEBUG - 2011-09-15 19:02:22 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-15 19:02:22 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-15 19:02:22 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-15 19:02:22 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-15 19:02:22 --> Final output sent to browser
DEBUG - 2011-09-15 19:02:22 --> Total execution time: 0.0520
DEBUG - 2011-09-15 19:02:22 --> Config Class Initialized
DEBUG - 2011-09-15 19:02:22 --> Hooks Class Initialized
DEBUG - 2011-09-15 19:02:22 --> Utf8 Class Initialized
DEBUG - 2011-09-15 19:02:22 --> UTF-8 Support Enabled
DEBUG - 2011-09-15 19:02:22 --> URI Class Initialized
DEBUG - 2011-09-15 19:02:22 --> Router Class Initialized
ERROR - 2011-09-15 19:02:22 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-15 19:02:27 --> Config Class Initialized
DEBUG - 2011-09-15 19:02:27 --> Hooks Class Initialized
DEBUG - 2011-09-15 19:02:27 --> Utf8 Class Initialized
DEBUG - 2011-09-15 19:02:27 --> UTF-8 Support Enabled
DEBUG - 2011-09-15 19:02:27 --> URI Class Initialized
DEBUG - 2011-09-15 19:02:27 --> Router Class Initialized
DEBUG - 2011-09-15 19:02:27 --> Output Class Initialized
DEBUG - 2011-09-15 19:02:27 --> Input Class Initialized
DEBUG - 2011-09-15 19:02:27 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-15 19:02:27 --> Language Class Initialized
DEBUG - 2011-09-15 19:02:27 --> Loader Class Initialized
DEBUG - 2011-09-15 19:02:27 --> Controller Class Initialized
DEBUG - 2011-09-15 19:02:27 --> Model Class Initialized
DEBUG - 2011-09-15 19:02:27 --> Model Class Initialized
DEBUG - 2011-09-15 19:02:27 --> Model Class Initialized
DEBUG - 2011-09-15 19:02:27 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-15 19:02:27 --> Database Driver Class Initialized
DEBUG - 2011-09-15 19:02:27 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-15 19:02:27 --> Helper loaded: url_helper
DEBUG - 2011-09-15 19:02:27 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-15 19:02:27 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-15 19:02:27 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-15 19:02:27 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-15 19:02:27 --> Final output sent to browser
DEBUG - 2011-09-15 19:02:27 --> Total execution time: 0.3769
DEBUG - 2011-09-15 19:02:28 --> Config Class Initialized
DEBUG - 2011-09-15 19:02:28 --> Hooks Class Initialized
DEBUG - 2011-09-15 19:02:28 --> Utf8 Class Initialized
DEBUG - 2011-09-15 19:02:28 --> UTF-8 Support Enabled
DEBUG - 2011-09-15 19:02:28 --> URI Class Initialized
DEBUG - 2011-09-15 19:02:28 --> Router Class Initialized
ERROR - 2011-09-15 19:02:28 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-15 19:02:29 --> Config Class Initialized
DEBUG - 2011-09-15 19:02:29 --> Hooks Class Initialized
DEBUG - 2011-09-15 19:02:29 --> Utf8 Class Initialized
DEBUG - 2011-09-15 19:02:29 --> UTF-8 Support Enabled
DEBUG - 2011-09-15 19:02:29 --> URI Class Initialized
DEBUG - 2011-09-15 19:02:29 --> Router Class Initialized
DEBUG - 2011-09-15 19:02:29 --> Output Class Initialized
DEBUG - 2011-09-15 19:02:29 --> Input Class Initialized
DEBUG - 2011-09-15 19:02:29 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-15 19:02:29 --> Language Class Initialized
DEBUG - 2011-09-15 19:02:29 --> Loader Class Initialized
DEBUG - 2011-09-15 19:02:29 --> Controller Class Initialized
DEBUG - 2011-09-15 19:02:29 --> Model Class Initialized
DEBUG - 2011-09-15 19:02:29 --> Model Class Initialized
DEBUG - 2011-09-15 19:02:29 --> Model Class Initialized
DEBUG - 2011-09-15 19:02:29 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-15 19:02:29 --> Database Driver Class Initialized
DEBUG - 2011-09-15 19:02:29 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-15 19:02:29 --> Helper loaded: url_helper
DEBUG - 2011-09-15 19:02:29 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-15 19:02:29 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-15 19:02:29 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-15 19:02:29 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-15 19:02:29 --> Final output sent to browser
DEBUG - 2011-09-15 19:02:29 --> Total execution time: 0.0536
DEBUG - 2011-09-15 19:02:38 --> Config Class Initialized
DEBUG - 2011-09-15 19:02:38 --> Hooks Class Initialized
DEBUG - 2011-09-15 19:02:38 --> Utf8 Class Initialized
DEBUG - 2011-09-15 19:02:38 --> UTF-8 Support Enabled
DEBUG - 2011-09-15 19:02:38 --> URI Class Initialized
DEBUG - 2011-09-15 19:02:38 --> Router Class Initialized
DEBUG - 2011-09-15 19:02:38 --> Output Class Initialized
DEBUG - 2011-09-15 19:02:38 --> Input Class Initialized
DEBUG - 2011-09-15 19:02:38 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-15 19:02:38 --> Language Class Initialized
DEBUG - 2011-09-15 19:02:38 --> Loader Class Initialized
DEBUG - 2011-09-15 19:02:38 --> Controller Class Initialized
DEBUG - 2011-09-15 19:02:38 --> Model Class Initialized
DEBUG - 2011-09-15 19:02:38 --> Model Class Initialized
DEBUG - 2011-09-15 19:02:38 --> Model Class Initialized
DEBUG - 2011-09-15 19:02:38 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-15 19:02:38 --> Database Driver Class Initialized
DEBUG - 2011-09-15 19:02:38 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-15 19:02:38 --> Helper loaded: url_helper
DEBUG - 2011-09-15 19:02:38 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-15 19:02:38 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-15 19:02:38 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-15 19:02:38 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-15 19:02:38 --> Final output sent to browser
DEBUG - 2011-09-15 19:02:38 --> Total execution time: 0.0464
DEBUG - 2011-09-15 19:02:39 --> Config Class Initialized
DEBUG - 2011-09-15 19:02:39 --> Hooks Class Initialized
DEBUG - 2011-09-15 19:02:39 --> Utf8 Class Initialized
DEBUG - 2011-09-15 19:02:39 --> UTF-8 Support Enabled
DEBUG - 2011-09-15 19:02:39 --> URI Class Initialized
DEBUG - 2011-09-15 19:02:39 --> Router Class Initialized
ERROR - 2011-09-15 19:02:39 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-15 19:02:57 --> Config Class Initialized
DEBUG - 2011-09-15 19:02:57 --> Hooks Class Initialized
DEBUG - 2011-09-15 19:02:57 --> Utf8 Class Initialized
DEBUG - 2011-09-15 19:02:57 --> UTF-8 Support Enabled
DEBUG - 2011-09-15 19:02:57 --> URI Class Initialized
DEBUG - 2011-09-15 19:02:57 --> Router Class Initialized
DEBUG - 2011-09-15 19:02:57 --> Output Class Initialized
DEBUG - 2011-09-15 19:02:57 --> Input Class Initialized
DEBUG - 2011-09-15 19:02:57 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-15 19:02:57 --> Language Class Initialized
DEBUG - 2011-09-15 19:02:57 --> Loader Class Initialized
DEBUG - 2011-09-15 19:02:57 --> Controller Class Initialized
DEBUG - 2011-09-15 19:02:57 --> Model Class Initialized
DEBUG - 2011-09-15 19:02:57 --> Model Class Initialized
DEBUG - 2011-09-15 19:02:57 --> Model Class Initialized
DEBUG - 2011-09-15 19:02:57 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-15 19:02:57 --> Database Driver Class Initialized
DEBUG - 2011-09-15 19:02:57 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-15 19:02:57 --> Helper loaded: url_helper
DEBUG - 2011-09-15 19:02:57 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-15 19:02:57 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-15 19:02:57 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-15 19:02:57 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-15 19:02:57 --> Final output sent to browser
DEBUG - 2011-09-15 19:02:57 --> Total execution time: 0.3590
DEBUG - 2011-09-15 19:02:57 --> Config Class Initialized
DEBUG - 2011-09-15 19:02:57 --> Hooks Class Initialized
DEBUG - 2011-09-15 19:02:57 --> Utf8 Class Initialized
DEBUG - 2011-09-15 19:02:57 --> UTF-8 Support Enabled
DEBUG - 2011-09-15 19:02:57 --> URI Class Initialized
DEBUG - 2011-09-15 19:02:57 --> Router Class Initialized
DEBUG - 2011-09-15 19:02:57 --> Output Class Initialized
DEBUG - 2011-09-15 19:02:57 --> Input Class Initialized
DEBUG - 2011-09-15 19:02:57 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-15 19:02:57 --> Language Class Initialized
DEBUG - 2011-09-15 19:02:57 --> Loader Class Initialized
DEBUG - 2011-09-15 19:02:57 --> Controller Class Initialized
DEBUG - 2011-09-15 19:02:57 --> Model Class Initialized
DEBUG - 2011-09-15 19:02:57 --> Model Class Initialized
DEBUG - 2011-09-15 19:02:57 --> Model Class Initialized
DEBUG - 2011-09-15 19:02:57 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-15 19:02:57 --> Database Driver Class Initialized
DEBUG - 2011-09-15 19:02:57 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-15 19:02:57 --> Helper loaded: url_helper
DEBUG - 2011-09-15 19:02:57 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-15 19:02:57 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-15 19:02:57 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-15 19:02:57 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-15 19:02:57 --> Final output sent to browser
DEBUG - 2011-09-15 19:02:57 --> Total execution time: 0.0680
DEBUG - 2011-09-15 19:02:59 --> Config Class Initialized
DEBUG - 2011-09-15 19:02:59 --> Hooks Class Initialized
DEBUG - 2011-09-15 19:02:59 --> Utf8 Class Initialized
DEBUG - 2011-09-15 19:02:59 --> UTF-8 Support Enabled
DEBUG - 2011-09-15 19:02:59 --> URI Class Initialized
DEBUG - 2011-09-15 19:02:59 --> Router Class Initialized
ERROR - 2011-09-15 19:02:59 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-15 19:03:00 --> Config Class Initialized
DEBUG - 2011-09-15 19:03:00 --> Hooks Class Initialized
DEBUG - 2011-09-15 19:03:00 --> Utf8 Class Initialized
DEBUG - 2011-09-15 19:03:00 --> UTF-8 Support Enabled
DEBUG - 2011-09-15 19:03:00 --> URI Class Initialized
DEBUG - 2011-09-15 19:03:00 --> Router Class Initialized
DEBUG - 2011-09-15 19:03:00 --> Output Class Initialized
DEBUG - 2011-09-15 19:03:00 --> Input Class Initialized
DEBUG - 2011-09-15 19:03:00 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-15 19:03:00 --> Language Class Initialized
DEBUG - 2011-09-15 19:03:00 --> Loader Class Initialized
DEBUG - 2011-09-15 19:03:00 --> Controller Class Initialized
DEBUG - 2011-09-15 19:03:00 --> Model Class Initialized
DEBUG - 2011-09-15 19:03:00 --> Model Class Initialized
DEBUG - 2011-09-15 19:03:00 --> Model Class Initialized
DEBUG - 2011-09-15 19:03:00 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-15 19:03:00 --> Database Driver Class Initialized
DEBUG - 2011-09-15 19:03:00 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-15 19:03:00 --> Helper loaded: url_helper
DEBUG - 2011-09-15 19:03:00 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-15 19:03:00 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-15 19:03:00 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-15 19:03:00 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-15 19:03:00 --> Final output sent to browser
DEBUG - 2011-09-15 19:03:00 --> Total execution time: 0.0527
DEBUG - 2011-09-15 19:03:04 --> Config Class Initialized
DEBUG - 2011-09-15 19:03:04 --> Hooks Class Initialized
DEBUG - 2011-09-15 19:03:04 --> Utf8 Class Initialized
DEBUG - 2011-09-15 19:03:04 --> UTF-8 Support Enabled
DEBUG - 2011-09-15 19:03:04 --> URI Class Initialized
DEBUG - 2011-09-15 19:03:04 --> Router Class Initialized
DEBUG - 2011-09-15 19:03:04 --> Output Class Initialized
DEBUG - 2011-09-15 19:03:04 --> Input Class Initialized
DEBUG - 2011-09-15 19:03:04 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-15 19:03:04 --> Language Class Initialized
DEBUG - 2011-09-15 19:03:04 --> Loader Class Initialized
DEBUG - 2011-09-15 19:03:04 --> Controller Class Initialized
DEBUG - 2011-09-15 19:03:04 --> Model Class Initialized
DEBUG - 2011-09-15 19:03:04 --> Model Class Initialized
DEBUG - 2011-09-15 19:03:04 --> Model Class Initialized
DEBUG - 2011-09-15 19:03:04 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-15 19:03:04 --> Database Driver Class Initialized
DEBUG - 2011-09-15 19:03:04 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-15 19:03:04 --> Helper loaded: url_helper
DEBUG - 2011-09-15 19:03:04 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-15 19:03:04 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-15 19:03:04 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-15 19:03:04 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-15 19:03:04 --> Final output sent to browser
DEBUG - 2011-09-15 19:03:04 --> Total execution time: 0.2784
DEBUG - 2011-09-15 19:03:06 --> Config Class Initialized
DEBUG - 2011-09-15 19:03:06 --> Hooks Class Initialized
DEBUG - 2011-09-15 19:03:06 --> Utf8 Class Initialized
DEBUG - 2011-09-15 19:03:06 --> UTF-8 Support Enabled
DEBUG - 2011-09-15 19:03:06 --> URI Class Initialized
DEBUG - 2011-09-15 19:03:06 --> Router Class Initialized
ERROR - 2011-09-15 19:03:06 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-15 19:03:09 --> Config Class Initialized
DEBUG - 2011-09-15 19:03:09 --> Hooks Class Initialized
DEBUG - 2011-09-15 19:03:09 --> Utf8 Class Initialized
DEBUG - 2011-09-15 19:03:09 --> UTF-8 Support Enabled
DEBUG - 2011-09-15 19:03:09 --> URI Class Initialized
DEBUG - 2011-09-15 19:03:09 --> Router Class Initialized
DEBUG - 2011-09-15 19:03:09 --> Output Class Initialized
DEBUG - 2011-09-15 19:03:09 --> Input Class Initialized
DEBUG - 2011-09-15 19:03:09 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-15 19:03:09 --> Language Class Initialized
DEBUG - 2011-09-15 19:03:09 --> Loader Class Initialized
DEBUG - 2011-09-15 19:03:09 --> Controller Class Initialized
DEBUG - 2011-09-15 19:03:09 --> Model Class Initialized
DEBUG - 2011-09-15 19:03:09 --> Model Class Initialized
DEBUG - 2011-09-15 19:03:09 --> Model Class Initialized
DEBUG - 2011-09-15 19:03:09 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-15 19:03:09 --> Database Driver Class Initialized
DEBUG - 2011-09-15 19:03:09 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-15 19:03:09 --> Helper loaded: url_helper
DEBUG - 2011-09-15 19:03:09 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-15 19:03:09 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-15 19:03:09 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-15 19:03:09 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-15 19:03:09 --> Final output sent to browser
DEBUG - 2011-09-15 19:03:09 --> Total execution time: 0.0440
DEBUG - 2011-09-15 20:23:00 --> Config Class Initialized
DEBUG - 2011-09-15 20:23:00 --> Hooks Class Initialized
DEBUG - 2011-09-15 20:23:00 --> Utf8 Class Initialized
DEBUG - 2011-09-15 20:23:00 --> UTF-8 Support Enabled
DEBUG - 2011-09-15 20:23:00 --> URI Class Initialized
DEBUG - 2011-09-15 20:23:00 --> Router Class Initialized
DEBUG - 2011-09-15 20:23:00 --> Output Class Initialized
DEBUG - 2011-09-15 20:23:00 --> Input Class Initialized
DEBUG - 2011-09-15 20:23:00 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-15 20:23:00 --> Language Class Initialized
DEBUG - 2011-09-15 20:23:00 --> Loader Class Initialized
DEBUG - 2011-09-15 20:23:00 --> Controller Class Initialized
ERROR - 2011-09-15 20:23:00 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-15 20:23:00 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-15 20:23:00 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-15 20:23:00 --> Model Class Initialized
DEBUG - 2011-09-15 20:23:00 --> Model Class Initialized
DEBUG - 2011-09-15 20:23:00 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-15 20:23:00 --> Database Driver Class Initialized
DEBUG - 2011-09-15 20:23:00 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-15 20:23:00 --> Helper loaded: url_helper
DEBUG - 2011-09-15 20:23:00 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-15 20:23:00 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-15 20:23:00 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-15 20:23:00 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-15 20:23:00 --> Final output sent to browser
DEBUG - 2011-09-15 20:23:00 --> Total execution time: 0.3173
DEBUG - 2011-09-15 20:32:20 --> Config Class Initialized
DEBUG - 2011-09-15 20:32:20 --> Hooks Class Initialized
DEBUG - 2011-09-15 20:32:20 --> Utf8 Class Initialized
DEBUG - 2011-09-15 20:32:20 --> UTF-8 Support Enabled
DEBUG - 2011-09-15 20:32:20 --> URI Class Initialized
DEBUG - 2011-09-15 20:32:20 --> Router Class Initialized
DEBUG - 2011-09-15 20:32:20 --> Output Class Initialized
DEBUG - 2011-09-15 20:32:20 --> Input Class Initialized
DEBUG - 2011-09-15 20:32:20 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-15 20:32:20 --> Language Class Initialized
DEBUG - 2011-09-15 20:32:20 --> Loader Class Initialized
DEBUG - 2011-09-15 20:32:20 --> Controller Class Initialized
ERROR - 2011-09-15 20:32:20 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-15 20:32:20 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-15 20:32:20 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-15 20:32:20 --> Model Class Initialized
DEBUG - 2011-09-15 20:32:20 --> Model Class Initialized
DEBUG - 2011-09-15 20:32:20 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-15 20:32:20 --> Database Driver Class Initialized
DEBUG - 2011-09-15 20:32:20 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-15 20:32:20 --> Helper loaded: url_helper
DEBUG - 2011-09-15 20:32:20 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-15 20:32:20 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-15 20:32:20 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-15 20:32:20 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-15 20:32:20 --> Final output sent to browser
DEBUG - 2011-09-15 20:32:20 --> Total execution time: 0.0310
DEBUG - 2011-09-15 21:06:17 --> Config Class Initialized
DEBUG - 2011-09-15 21:06:17 --> Hooks Class Initialized
DEBUG - 2011-09-15 21:06:17 --> Utf8 Class Initialized
DEBUG - 2011-09-15 21:06:17 --> UTF-8 Support Enabled
DEBUG - 2011-09-15 21:06:17 --> URI Class Initialized
DEBUG - 2011-09-15 21:06:17 --> Router Class Initialized
DEBUG - 2011-09-15 21:06:17 --> Output Class Initialized
DEBUG - 2011-09-15 21:06:17 --> Input Class Initialized
DEBUG - 2011-09-15 21:06:17 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-15 21:06:17 --> Language Class Initialized
DEBUG - 2011-09-15 21:06:17 --> Loader Class Initialized
DEBUG - 2011-09-15 21:06:17 --> Controller Class Initialized
ERROR - 2011-09-15 21:06:17 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-15 21:06:17 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-15 21:06:17 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-15 21:06:17 --> Model Class Initialized
DEBUG - 2011-09-15 21:06:17 --> Model Class Initialized
DEBUG - 2011-09-15 21:06:17 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-15 21:06:17 --> Database Driver Class Initialized
DEBUG - 2011-09-15 21:06:17 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-15 21:06:17 --> Helper loaded: url_helper
DEBUG - 2011-09-15 21:06:17 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-15 21:06:17 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-15 21:06:17 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-15 21:06:17 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-15 21:06:17 --> Final output sent to browser
DEBUG - 2011-09-15 21:06:17 --> Total execution time: 0.0425
DEBUG - 2011-09-15 21:06:17 --> Config Class Initialized
DEBUG - 2011-09-15 21:06:17 --> Hooks Class Initialized
DEBUG - 2011-09-15 21:06:17 --> Utf8 Class Initialized
DEBUG - 2011-09-15 21:06:17 --> UTF-8 Support Enabled
DEBUG - 2011-09-15 21:06:17 --> URI Class Initialized
DEBUG - 2011-09-15 21:06:17 --> Router Class Initialized
DEBUG - 2011-09-15 21:06:17 --> Output Class Initialized
DEBUG - 2011-09-15 21:06:17 --> Input Class Initialized
DEBUG - 2011-09-15 21:06:17 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-15 21:06:17 --> Language Class Initialized
DEBUG - 2011-09-15 21:06:17 --> Loader Class Initialized
DEBUG - 2011-09-15 21:06:17 --> Controller Class Initialized
DEBUG - 2011-09-15 21:06:17 --> Model Class Initialized
DEBUG - 2011-09-15 21:06:17 --> Model Class Initialized
DEBUG - 2011-09-15 21:06:17 --> Model Class Initialized
DEBUG - 2011-09-15 21:06:17 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-15 21:06:17 --> Database Driver Class Initialized
DEBUG - 2011-09-15 21:06:18 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-15 21:06:18 --> Helper loaded: url_helper
DEBUG - 2011-09-15 21:06:18 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-15 21:06:18 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-15 21:06:18 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-15 21:06:18 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-15 21:06:18 --> Final output sent to browser
DEBUG - 2011-09-15 21:06:18 --> Total execution time: 0.4524
DEBUG - 2011-09-15 22:39:16 --> Config Class Initialized
DEBUG - 2011-09-15 22:39:16 --> Hooks Class Initialized
DEBUG - 2011-09-15 22:39:16 --> Utf8 Class Initialized
DEBUG - 2011-09-15 22:39:16 --> UTF-8 Support Enabled
DEBUG - 2011-09-15 22:39:16 --> URI Class Initialized
DEBUG - 2011-09-15 22:39:16 --> Router Class Initialized
DEBUG - 2011-09-15 22:39:16 --> Output Class Initialized
DEBUG - 2011-09-15 22:39:16 --> Input Class Initialized
DEBUG - 2011-09-15 22:39:16 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-15 22:39:16 --> Language Class Initialized
DEBUG - 2011-09-15 22:39:16 --> Loader Class Initialized
DEBUG - 2011-09-15 22:39:16 --> Controller Class Initialized
DEBUG - 2011-09-15 22:39:16 --> Model Class Initialized
DEBUG - 2011-09-15 22:39:16 --> Model Class Initialized
DEBUG - 2011-09-15 22:39:16 --> Model Class Initialized
DEBUG - 2011-09-15 22:39:16 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-15 22:39:16 --> Database Driver Class Initialized
DEBUG - 2011-09-15 22:39:17 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-15 22:39:17 --> Helper loaded: url_helper
DEBUG - 2011-09-15 22:39:17 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-15 22:39:17 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-15 22:39:17 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-15 22:39:17 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-15 22:39:17 --> Final output sent to browser
DEBUG - 2011-09-15 22:39:17 --> Total execution time: 0.8493
DEBUG - 2011-09-15 22:39:28 --> Config Class Initialized
DEBUG - 2011-09-15 22:39:28 --> Hooks Class Initialized
DEBUG - 2011-09-15 22:39:28 --> Utf8 Class Initialized
DEBUG - 2011-09-15 22:39:28 --> UTF-8 Support Enabled
DEBUG - 2011-09-15 22:39:28 --> URI Class Initialized
DEBUG - 2011-09-15 22:39:28 --> Router Class Initialized
ERROR - 2011-09-15 22:39:28 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-15 22:39:31 --> Config Class Initialized
DEBUG - 2011-09-15 22:39:31 --> Hooks Class Initialized
DEBUG - 2011-09-15 22:39:31 --> Utf8 Class Initialized
DEBUG - 2011-09-15 22:39:31 --> UTF-8 Support Enabled
DEBUG - 2011-09-15 22:39:31 --> URI Class Initialized
DEBUG - 2011-09-15 22:39:31 --> Router Class Initialized
ERROR - 2011-09-15 22:39:31 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-15 22:40:24 --> Config Class Initialized
DEBUG - 2011-09-15 22:40:24 --> Hooks Class Initialized
DEBUG - 2011-09-15 22:40:24 --> Utf8 Class Initialized
DEBUG - 2011-09-15 22:40:24 --> UTF-8 Support Enabled
DEBUG - 2011-09-15 22:40:24 --> URI Class Initialized
DEBUG - 2011-09-15 22:40:24 --> Router Class Initialized
DEBUG - 2011-09-15 22:40:24 --> Output Class Initialized
DEBUG - 2011-09-15 22:40:24 --> Input Class Initialized
DEBUG - 2011-09-15 22:40:24 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-15 22:40:24 --> Language Class Initialized
DEBUG - 2011-09-15 22:40:24 --> Loader Class Initialized
DEBUG - 2011-09-15 22:40:24 --> Controller Class Initialized
ERROR - 2011-09-15 22:40:24 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-15 22:40:24 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-15 22:40:24 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-15 22:40:24 --> Model Class Initialized
DEBUG - 2011-09-15 22:40:24 --> Model Class Initialized
DEBUG - 2011-09-15 22:40:24 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-15 22:40:24 --> Database Driver Class Initialized
DEBUG - 2011-09-15 22:40:24 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-15 22:40:24 --> Helper loaded: url_helper
DEBUG - 2011-09-15 22:40:24 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-15 22:40:24 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-15 22:40:24 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-15 22:40:24 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-15 22:40:24 --> Final output sent to browser
DEBUG - 2011-09-15 22:40:24 --> Total execution time: 0.0303
DEBUG - 2011-09-15 22:40:26 --> Config Class Initialized
DEBUG - 2011-09-15 22:40:26 --> Hooks Class Initialized
DEBUG - 2011-09-15 22:40:26 --> Utf8 Class Initialized
DEBUG - 2011-09-15 22:40:26 --> UTF-8 Support Enabled
DEBUG - 2011-09-15 22:40:26 --> URI Class Initialized
DEBUG - 2011-09-15 22:40:26 --> Router Class Initialized
DEBUG - 2011-09-15 22:40:26 --> Output Class Initialized
DEBUG - 2011-09-15 22:40:26 --> Input Class Initialized
DEBUG - 2011-09-15 22:40:26 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-15 22:40:26 --> Language Class Initialized
DEBUG - 2011-09-15 22:40:26 --> Loader Class Initialized
DEBUG - 2011-09-15 22:40:26 --> Controller Class Initialized
DEBUG - 2011-09-15 22:40:26 --> Model Class Initialized
DEBUG - 2011-09-15 22:40:26 --> Model Class Initialized
DEBUG - 2011-09-15 22:40:26 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-15 22:40:26 --> Database Driver Class Initialized
DEBUG - 2011-09-15 22:40:26 --> Final output sent to browser
DEBUG - 2011-09-15 22:40:26 --> Total execution time: 0.7462

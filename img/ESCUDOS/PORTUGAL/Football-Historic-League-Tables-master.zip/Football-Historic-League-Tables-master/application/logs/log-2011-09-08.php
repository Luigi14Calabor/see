<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2011-09-08 00:25:54 --> Config Class Initialized
DEBUG - 2011-09-08 00:25:54 --> Hooks Class Initialized
DEBUG - 2011-09-08 00:25:54 --> Utf8 Class Initialized
DEBUG - 2011-09-08 00:25:54 --> UTF-8 Support Enabled
DEBUG - 2011-09-08 00:25:54 --> URI Class Initialized
DEBUG - 2011-09-08 00:25:54 --> Router Class Initialized
ERROR - 2011-09-08 00:25:54 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-09-08 00:26:22 --> Config Class Initialized
DEBUG - 2011-09-08 00:26:22 --> Hooks Class Initialized
DEBUG - 2011-09-08 00:26:22 --> Utf8 Class Initialized
DEBUG - 2011-09-08 00:26:22 --> UTF-8 Support Enabled
DEBUG - 2011-09-08 00:26:22 --> URI Class Initialized
DEBUG - 2011-09-08 00:26:22 --> Router Class Initialized
DEBUG - 2011-09-08 00:26:22 --> No URI present. Default controller set.
DEBUG - 2011-09-08 00:26:22 --> Output Class Initialized
DEBUG - 2011-09-08 00:26:22 --> Input Class Initialized
DEBUG - 2011-09-08 00:26:22 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-08 00:26:22 --> Language Class Initialized
DEBUG - 2011-09-08 00:26:22 --> Loader Class Initialized
DEBUG - 2011-09-08 00:26:22 --> Controller Class Initialized
DEBUG - 2011-09-08 00:26:22 --> File loaded: application/views/splash/main.php
DEBUG - 2011-09-08 00:26:22 --> Helper loaded: url_helper
DEBUG - 2011-09-08 00:26:22 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-08 00:26:22 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-08 00:26:22 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-08 00:26:22 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-08 00:26:22 --> Final output sent to browser
DEBUG - 2011-09-08 00:26:22 --> Total execution time: 0.0473
DEBUG - 2011-09-08 00:45:08 --> Config Class Initialized
DEBUG - 2011-09-08 00:45:08 --> Hooks Class Initialized
DEBUG - 2011-09-08 00:45:08 --> Utf8 Class Initialized
DEBUG - 2011-09-08 00:45:08 --> UTF-8 Support Enabled
DEBUG - 2011-09-08 00:45:08 --> URI Class Initialized
DEBUG - 2011-09-08 00:45:08 --> Router Class Initialized
DEBUG - 2011-09-08 00:45:08 --> Output Class Initialized
DEBUG - 2011-09-08 00:45:08 --> Input Class Initialized
DEBUG - 2011-09-08 00:45:08 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-08 00:45:08 --> Language Class Initialized
DEBUG - 2011-09-08 00:45:08 --> Loader Class Initialized
DEBUG - 2011-09-08 00:45:08 --> Controller Class Initialized
ERROR - 2011-09-08 00:45:08 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-08 00:45:08 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-08 00:45:08 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-08 00:45:08 --> Model Class Initialized
DEBUG - 2011-09-08 00:45:08 --> Model Class Initialized
DEBUG - 2011-09-08 00:45:08 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-08 00:45:09 --> Database Driver Class Initialized
DEBUG - 2011-09-08 00:45:09 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-08 00:45:09 --> Helper loaded: url_helper
DEBUG - 2011-09-08 00:45:09 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-08 00:45:09 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-08 00:45:09 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-08 00:45:09 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-08 00:45:09 --> Final output sent to browser
DEBUG - 2011-09-08 00:45:09 --> Total execution time: 0.5207
DEBUG - 2011-09-08 00:57:08 --> Config Class Initialized
DEBUG - 2011-09-08 00:57:08 --> Hooks Class Initialized
DEBUG - 2011-09-08 00:57:08 --> Utf8 Class Initialized
DEBUG - 2011-09-08 00:57:08 --> UTF-8 Support Enabled
DEBUG - 2011-09-08 00:57:08 --> URI Class Initialized
DEBUG - 2011-09-08 00:57:08 --> Router Class Initialized
DEBUG - 2011-09-08 00:57:08 --> Output Class Initialized
DEBUG - 2011-09-08 00:57:08 --> Input Class Initialized
DEBUG - 2011-09-08 00:57:08 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-08 00:57:08 --> Language Class Initialized
DEBUG - 2011-09-08 00:57:08 --> Loader Class Initialized
DEBUG - 2011-09-08 00:57:08 --> Controller Class Initialized
DEBUG - 2011-09-08 00:57:08 --> Model Class Initialized
DEBUG - 2011-09-08 00:57:08 --> Model Class Initialized
DEBUG - 2011-09-08 00:57:08 --> Model Class Initialized
DEBUG - 2011-09-08 00:57:08 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-08 00:57:08 --> Database Driver Class Initialized
DEBUG - 2011-09-08 00:57:08 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-08 00:57:08 --> Helper loaded: url_helper
DEBUG - 2011-09-08 00:57:08 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-08 00:57:08 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-08 00:57:08 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-08 00:57:08 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-08 00:57:08 --> Final output sent to browser
DEBUG - 2011-09-08 00:57:08 --> Total execution time: 0.7192
DEBUG - 2011-09-08 00:57:09 --> Config Class Initialized
DEBUG - 2011-09-08 00:57:09 --> Hooks Class Initialized
DEBUG - 2011-09-08 00:57:09 --> Utf8 Class Initialized
DEBUG - 2011-09-08 00:57:09 --> UTF-8 Support Enabled
DEBUG - 2011-09-08 00:57:09 --> URI Class Initialized
DEBUG - 2011-09-08 00:57:09 --> Router Class Initialized
DEBUG - 2011-09-08 00:57:09 --> Output Class Initialized
DEBUG - 2011-09-08 00:57:09 --> Input Class Initialized
DEBUG - 2011-09-08 00:57:09 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-08 00:57:09 --> Language Class Initialized
DEBUG - 2011-09-08 00:57:09 --> Loader Class Initialized
DEBUG - 2011-09-08 00:57:09 --> Controller Class Initialized
ERROR - 2011-09-08 00:57:09 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-08 00:57:09 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-08 00:57:09 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-08 00:57:09 --> Model Class Initialized
DEBUG - 2011-09-08 00:57:09 --> Model Class Initialized
DEBUG - 2011-09-08 00:57:09 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-08 00:57:09 --> Database Driver Class Initialized
DEBUG - 2011-09-08 00:57:10 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-08 00:57:10 --> Helper loaded: url_helper
DEBUG - 2011-09-08 00:57:10 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-08 00:57:10 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-08 00:57:10 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-08 00:57:10 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-08 00:57:10 --> Final output sent to browser
DEBUG - 2011-09-08 00:57:10 --> Total execution time: 0.0390
DEBUG - 2011-09-08 00:57:18 --> Config Class Initialized
DEBUG - 2011-09-08 00:57:18 --> Hooks Class Initialized
DEBUG - 2011-09-08 00:57:18 --> Utf8 Class Initialized
DEBUG - 2011-09-08 00:57:18 --> UTF-8 Support Enabled
DEBUG - 2011-09-08 00:57:18 --> URI Class Initialized
DEBUG - 2011-09-08 00:57:18 --> Router Class Initialized
DEBUG - 2011-09-08 00:57:18 --> Output Class Initialized
DEBUG - 2011-09-08 00:57:18 --> Input Class Initialized
DEBUG - 2011-09-08 00:57:18 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-08 00:57:18 --> Language Class Initialized
DEBUG - 2011-09-08 00:57:18 --> Loader Class Initialized
DEBUG - 2011-09-08 00:57:18 --> Controller Class Initialized
ERROR - 2011-09-08 00:57:18 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-08 00:57:18 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-08 00:57:18 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-08 00:57:18 --> Model Class Initialized
DEBUG - 2011-09-08 00:57:18 --> Model Class Initialized
DEBUG - 2011-09-08 00:57:18 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-08 00:57:18 --> Database Driver Class Initialized
DEBUG - 2011-09-08 00:57:18 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-08 00:57:18 --> Helper loaded: url_helper
DEBUG - 2011-09-08 00:57:18 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-08 00:57:18 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-08 00:57:18 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-08 00:57:18 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-08 00:57:18 --> Final output sent to browser
DEBUG - 2011-09-08 00:57:18 --> Total execution time: 0.0285
DEBUG - 2011-09-08 02:14:57 --> Config Class Initialized
DEBUG - 2011-09-08 02:14:57 --> Hooks Class Initialized
DEBUG - 2011-09-08 02:14:57 --> Utf8 Class Initialized
DEBUG - 2011-09-08 02:14:57 --> UTF-8 Support Enabled
DEBUG - 2011-09-08 02:14:57 --> URI Class Initialized
DEBUG - 2011-09-08 02:14:57 --> Router Class Initialized
ERROR - 2011-09-08 02:14:57 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-09-08 02:14:57 --> Config Class Initialized
DEBUG - 2011-09-08 02:14:57 --> Hooks Class Initialized
DEBUG - 2011-09-08 02:14:57 --> Utf8 Class Initialized
DEBUG - 2011-09-08 02:14:57 --> UTF-8 Support Enabled
DEBUG - 2011-09-08 02:14:57 --> URI Class Initialized
DEBUG - 2011-09-08 02:14:57 --> Router Class Initialized
DEBUG - 2011-09-08 02:14:57 --> Output Class Initialized
DEBUG - 2011-09-08 02:14:57 --> Input Class Initialized
DEBUG - 2011-09-08 02:14:57 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-08 02:14:57 --> Language Class Initialized
DEBUG - 2011-09-08 02:14:57 --> Loader Class Initialized
DEBUG - 2011-09-08 02:14:57 --> Controller Class Initialized
ERROR - 2011-09-08 02:14:57 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-08 02:14:57 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-08 02:14:57 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-08 02:14:57 --> Model Class Initialized
DEBUG - 2011-09-08 02:14:57 --> Model Class Initialized
DEBUG - 2011-09-08 02:14:57 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-08 02:14:58 --> Database Driver Class Initialized
DEBUG - 2011-09-08 02:14:59 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-08 02:14:59 --> Helper loaded: url_helper
DEBUG - 2011-09-08 02:14:59 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-08 02:14:59 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-08 02:14:59 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-08 02:14:59 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-08 02:14:59 --> Final output sent to browser
DEBUG - 2011-09-08 02:14:59 --> Total execution time: 1.7808
DEBUG - 2011-09-08 02:41:35 --> Config Class Initialized
DEBUG - 2011-09-08 02:41:35 --> Hooks Class Initialized
DEBUG - 2011-09-08 02:41:35 --> Utf8 Class Initialized
DEBUG - 2011-09-08 02:41:35 --> UTF-8 Support Enabled
DEBUG - 2011-09-08 02:41:35 --> URI Class Initialized
DEBUG - 2011-09-08 02:41:35 --> Router Class Initialized
ERROR - 2011-09-08 02:41:35 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-09-08 02:41:38 --> Config Class Initialized
DEBUG - 2011-09-08 02:41:38 --> Hooks Class Initialized
DEBUG - 2011-09-08 02:41:38 --> Utf8 Class Initialized
DEBUG - 2011-09-08 02:41:38 --> UTF-8 Support Enabled
DEBUG - 2011-09-08 02:41:38 --> URI Class Initialized
DEBUG - 2011-09-08 02:41:38 --> Router Class Initialized
DEBUG - 2011-09-08 02:41:38 --> No URI present. Default controller set.
DEBUG - 2011-09-08 02:41:38 --> Output Class Initialized
DEBUG - 2011-09-08 02:41:38 --> Input Class Initialized
DEBUG - 2011-09-08 02:41:38 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-08 02:41:38 --> Language Class Initialized
DEBUG - 2011-09-08 02:41:38 --> Loader Class Initialized
DEBUG - 2011-09-08 02:41:38 --> Controller Class Initialized
DEBUG - 2011-09-08 02:41:38 --> File loaded: application/views/splash/main.php
DEBUG - 2011-09-08 02:41:38 --> Helper loaded: url_helper
DEBUG - 2011-09-08 02:41:38 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-08 02:41:38 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-08 02:41:38 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-08 02:41:38 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-08 02:41:38 --> Final output sent to browser
DEBUG - 2011-09-08 02:41:38 --> Total execution time: 0.2067
DEBUG - 2011-09-08 03:21:51 --> Config Class Initialized
DEBUG - 2011-09-08 03:21:51 --> Hooks Class Initialized
DEBUG - 2011-09-08 03:21:51 --> Utf8 Class Initialized
DEBUG - 2011-09-08 03:21:51 --> UTF-8 Support Enabled
DEBUG - 2011-09-08 03:21:51 --> URI Class Initialized
DEBUG - 2011-09-08 03:21:51 --> Router Class Initialized
DEBUG - 2011-09-08 03:21:51 --> No URI present. Default controller set.
DEBUG - 2011-09-08 03:21:51 --> Output Class Initialized
DEBUG - 2011-09-08 03:21:51 --> Input Class Initialized
DEBUG - 2011-09-08 03:21:51 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-08 03:21:51 --> Language Class Initialized
DEBUG - 2011-09-08 03:21:51 --> Loader Class Initialized
DEBUG - 2011-09-08 03:21:51 --> Controller Class Initialized
DEBUG - 2011-09-08 03:21:51 --> File loaded: application/views/splash/main.php
DEBUG - 2011-09-08 03:21:51 --> Helper loaded: url_helper
DEBUG - 2011-09-08 03:21:51 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-08 03:21:51 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-08 03:21:51 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-08 03:21:51 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-08 03:21:51 --> Final output sent to browser
DEBUG - 2011-09-08 03:21:51 --> Total execution time: 0.1744
DEBUG - 2011-09-08 03:32:49 --> Config Class Initialized
DEBUG - 2011-09-08 03:32:49 --> Hooks Class Initialized
DEBUG - 2011-09-08 03:32:49 --> Utf8 Class Initialized
DEBUG - 2011-09-08 03:32:49 --> UTF-8 Support Enabled
DEBUG - 2011-09-08 03:32:49 --> URI Class Initialized
DEBUG - 2011-09-08 03:32:49 --> Router Class Initialized
DEBUG - 2011-09-08 03:32:49 --> Output Class Initialized
DEBUG - 2011-09-08 03:32:49 --> Input Class Initialized
DEBUG - 2011-09-08 03:32:49 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-08 03:32:49 --> Language Class Initialized
DEBUG - 2011-09-08 03:32:49 --> Loader Class Initialized
DEBUG - 2011-09-08 03:32:49 --> Controller Class Initialized
DEBUG - 2011-09-08 03:32:49 --> Model Class Initialized
DEBUG - 2011-09-08 03:32:49 --> Model Class Initialized
DEBUG - 2011-09-08 03:32:49 --> Model Class Initialized
DEBUG - 2011-09-08 03:32:49 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-08 03:32:49 --> Database Driver Class Initialized
DEBUG - 2011-09-08 03:32:50 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-08 03:32:50 --> Helper loaded: url_helper
DEBUG - 2011-09-08 03:32:50 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-08 03:32:50 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-08 03:32:50 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-08 03:32:50 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-08 03:32:50 --> Final output sent to browser
DEBUG - 2011-09-08 03:32:50 --> Total execution time: 1.1373
DEBUG - 2011-09-08 03:32:51 --> Config Class Initialized
DEBUG - 2011-09-08 03:32:51 --> Hooks Class Initialized
DEBUG - 2011-09-08 03:32:51 --> Utf8 Class Initialized
DEBUG - 2011-09-08 03:32:51 --> UTF-8 Support Enabled
DEBUG - 2011-09-08 03:32:51 --> URI Class Initialized
DEBUG - 2011-09-08 03:32:51 --> Router Class Initialized
DEBUG - 2011-09-08 03:32:51 --> Output Class Initialized
DEBUG - 2011-09-08 03:32:51 --> Input Class Initialized
DEBUG - 2011-09-08 03:32:51 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-08 03:32:51 --> Language Class Initialized
DEBUG - 2011-09-08 03:32:51 --> Loader Class Initialized
DEBUG - 2011-09-08 03:32:51 --> Controller Class Initialized
ERROR - 2011-09-08 03:32:51 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-08 03:32:51 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-08 03:32:51 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-08 03:32:51 --> Model Class Initialized
DEBUG - 2011-09-08 03:32:51 --> Model Class Initialized
DEBUG - 2011-09-08 03:32:51 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-08 03:32:51 --> Database Driver Class Initialized
DEBUG - 2011-09-08 03:32:51 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-08 03:32:51 --> Helper loaded: url_helper
DEBUG - 2011-09-08 03:32:51 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-08 03:32:51 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-08 03:32:51 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-08 03:32:51 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-08 03:32:51 --> Final output sent to browser
DEBUG - 2011-09-08 03:32:51 --> Total execution time: 0.1212
DEBUG - 2011-09-08 03:33:09 --> Config Class Initialized
DEBUG - 2011-09-08 03:33:09 --> Hooks Class Initialized
DEBUG - 2011-09-08 03:33:09 --> Utf8 Class Initialized
DEBUG - 2011-09-08 03:33:09 --> UTF-8 Support Enabled
DEBUG - 2011-09-08 03:33:09 --> URI Class Initialized
DEBUG - 2011-09-08 03:33:09 --> Router Class Initialized
DEBUG - 2011-09-08 03:33:09 --> Output Class Initialized
DEBUG - 2011-09-08 03:33:09 --> Input Class Initialized
DEBUG - 2011-09-08 03:33:09 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-08 03:33:09 --> Language Class Initialized
DEBUG - 2011-09-08 03:33:09 --> Loader Class Initialized
DEBUG - 2011-09-08 03:33:09 --> Controller Class Initialized
DEBUG - 2011-09-08 03:33:09 --> Model Class Initialized
DEBUG - 2011-09-08 03:33:09 --> Model Class Initialized
DEBUG - 2011-09-08 03:33:09 --> Model Class Initialized
DEBUG - 2011-09-08 03:33:09 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-08 03:33:09 --> Database Driver Class Initialized
DEBUG - 2011-09-08 03:33:09 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-08 03:33:09 --> Helper loaded: url_helper
DEBUG - 2011-09-08 03:33:09 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-08 03:33:09 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-08 03:33:09 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-08 03:33:09 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-08 03:33:09 --> Final output sent to browser
DEBUG - 2011-09-08 03:33:09 --> Total execution time: 0.0787
DEBUG - 2011-09-08 03:33:11 --> Config Class Initialized
DEBUG - 2011-09-08 03:33:11 --> Hooks Class Initialized
DEBUG - 2011-09-08 03:33:11 --> Utf8 Class Initialized
DEBUG - 2011-09-08 03:33:11 --> UTF-8 Support Enabled
DEBUG - 2011-09-08 03:33:11 --> URI Class Initialized
DEBUG - 2011-09-08 03:33:11 --> Router Class Initialized
DEBUG - 2011-09-08 03:33:11 --> Output Class Initialized
DEBUG - 2011-09-08 03:33:11 --> Input Class Initialized
DEBUG - 2011-09-08 03:33:11 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-08 03:33:11 --> Language Class Initialized
DEBUG - 2011-09-08 03:33:11 --> Loader Class Initialized
DEBUG - 2011-09-08 03:33:11 --> Controller Class Initialized
ERROR - 2011-09-08 03:33:11 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-08 03:33:11 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-08 03:33:11 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-08 03:33:11 --> Model Class Initialized
DEBUG - 2011-09-08 03:33:11 --> Model Class Initialized
DEBUG - 2011-09-08 03:33:11 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-08 03:33:11 --> Database Driver Class Initialized
DEBUG - 2011-09-08 03:33:11 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-08 03:33:11 --> Helper loaded: url_helper
DEBUG - 2011-09-08 03:33:11 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-08 03:33:11 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-08 03:33:11 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-08 03:33:11 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-08 03:33:11 --> Final output sent to browser
DEBUG - 2011-09-08 03:33:11 --> Total execution time: 0.0511
DEBUG - 2011-09-08 06:49:43 --> Config Class Initialized
DEBUG - 2011-09-08 06:49:43 --> Hooks Class Initialized
DEBUG - 2011-09-08 06:49:43 --> Utf8 Class Initialized
DEBUG - 2011-09-08 06:49:43 --> UTF-8 Support Enabled
DEBUG - 2011-09-08 06:49:43 --> URI Class Initialized
DEBUG - 2011-09-08 06:49:43 --> Router Class Initialized
DEBUG - 2011-09-08 06:49:43 --> Output Class Initialized
DEBUG - 2011-09-08 06:49:43 --> Input Class Initialized
DEBUG - 2011-09-08 06:49:43 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-08 06:49:43 --> Language Class Initialized
DEBUG - 2011-09-08 06:49:43 --> Loader Class Initialized
DEBUG - 2011-09-08 06:49:43 --> Controller Class Initialized
DEBUG - 2011-09-08 06:49:43 --> Model Class Initialized
DEBUG - 2011-09-08 06:49:43 --> Model Class Initialized
DEBUG - 2011-09-08 06:49:43 --> Model Class Initialized
DEBUG - 2011-09-08 06:49:43 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-08 06:49:43 --> Database Driver Class Initialized
DEBUG - 2011-09-08 06:49:44 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-08 06:49:44 --> Helper loaded: url_helper
DEBUG - 2011-09-08 06:49:44 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-08 06:49:44 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-08 06:49:44 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-08 06:49:44 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-08 06:49:44 --> Final output sent to browser
DEBUG - 2011-09-08 06:49:44 --> Total execution time: 1.5096
DEBUG - 2011-09-08 07:06:23 --> Config Class Initialized
DEBUG - 2011-09-08 07:06:23 --> Hooks Class Initialized
DEBUG - 2011-09-08 07:06:23 --> Utf8 Class Initialized
DEBUG - 2011-09-08 07:06:23 --> UTF-8 Support Enabled
DEBUG - 2011-09-08 07:06:23 --> URI Class Initialized
DEBUG - 2011-09-08 07:06:23 --> Router Class Initialized
DEBUG - 2011-09-08 07:06:23 --> Output Class Initialized
DEBUG - 2011-09-08 07:06:23 --> Input Class Initialized
DEBUG - 2011-09-08 07:06:23 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-08 07:06:23 --> Language Class Initialized
DEBUG - 2011-09-08 07:06:23 --> Loader Class Initialized
DEBUG - 2011-09-08 07:06:23 --> Controller Class Initialized
ERROR - 2011-09-08 07:06:23 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-08 07:06:23 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-08 07:06:23 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-08 07:06:23 --> Model Class Initialized
DEBUG - 2011-09-08 07:06:23 --> Model Class Initialized
DEBUG - 2011-09-08 07:06:23 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-08 07:06:23 --> Database Driver Class Initialized
DEBUG - 2011-09-08 07:06:23 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-08 07:06:23 --> Helper loaded: url_helper
DEBUG - 2011-09-08 07:06:23 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-08 07:06:23 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-08 07:06:23 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-08 07:06:23 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-08 07:06:23 --> Final output sent to browser
DEBUG - 2011-09-08 07:06:23 --> Total execution time: 0.1347
DEBUG - 2011-09-08 07:06:25 --> Config Class Initialized
DEBUG - 2011-09-08 07:06:25 --> Hooks Class Initialized
DEBUG - 2011-09-08 07:06:25 --> Utf8 Class Initialized
DEBUG - 2011-09-08 07:06:25 --> UTF-8 Support Enabled
DEBUG - 2011-09-08 07:06:25 --> URI Class Initialized
DEBUG - 2011-09-08 07:06:25 --> Router Class Initialized
ERROR - 2011-09-08 07:06:25 --> 404 Page Not Found --> _vti_bin
DEBUG - 2011-09-08 07:06:26 --> Config Class Initialized
DEBUG - 2011-09-08 07:06:26 --> Hooks Class Initialized
DEBUG - 2011-09-08 07:06:26 --> Utf8 Class Initialized
DEBUG - 2011-09-08 07:06:26 --> UTF-8 Support Enabled
DEBUG - 2011-09-08 07:06:26 --> URI Class Initialized
DEBUG - 2011-09-08 07:06:26 --> Router Class Initialized
ERROR - 2011-09-08 07:06:26 --> 404 Page Not Found --> MSOffice
DEBUG - 2011-09-08 07:06:28 --> Config Class Initialized
DEBUG - 2011-09-08 07:06:28 --> Hooks Class Initialized
DEBUG - 2011-09-08 07:06:28 --> Utf8 Class Initialized
DEBUG - 2011-09-08 07:06:28 --> UTF-8 Support Enabled
DEBUG - 2011-09-08 07:06:28 --> URI Class Initialized
DEBUG - 2011-09-08 07:06:28 --> Router Class Initialized
DEBUG - 2011-09-08 07:06:28 --> Output Class Initialized
DEBUG - 2011-09-08 07:06:28 --> Input Class Initialized
DEBUG - 2011-09-08 07:06:28 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-08 07:06:28 --> Language Class Initialized
DEBUG - 2011-09-08 07:06:28 --> Loader Class Initialized
DEBUG - 2011-09-08 07:06:28 --> Controller Class Initialized
DEBUG - 2011-09-08 07:06:28 --> Model Class Initialized
DEBUG - 2011-09-08 07:06:28 --> Model Class Initialized
DEBUG - 2011-09-08 07:06:28 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-08 07:06:28 --> Database Driver Class Initialized
DEBUG - 2011-09-08 07:06:28 --> Final output sent to browser
DEBUG - 2011-09-08 07:06:28 --> Total execution time: 0.5157
DEBUG - 2011-09-08 07:06:34 --> Config Class Initialized
DEBUG - 2011-09-08 07:06:34 --> Hooks Class Initialized
DEBUG - 2011-09-08 07:06:34 --> Utf8 Class Initialized
DEBUG - 2011-09-08 07:06:34 --> UTF-8 Support Enabled
DEBUG - 2011-09-08 07:06:34 --> URI Class Initialized
DEBUG - 2011-09-08 07:06:34 --> Router Class Initialized
ERROR - 2011-09-08 07:06:34 --> 404 Page Not Found --> _vti_bin
DEBUG - 2011-09-08 07:06:35 --> Config Class Initialized
DEBUG - 2011-09-08 07:06:35 --> Hooks Class Initialized
DEBUG - 2011-09-08 07:06:35 --> Utf8 Class Initialized
DEBUG - 2011-09-08 07:06:35 --> UTF-8 Support Enabled
DEBUG - 2011-09-08 07:06:35 --> URI Class Initialized
DEBUG - 2011-09-08 07:06:35 --> Router Class Initialized
ERROR - 2011-09-08 07:06:35 --> 404 Page Not Found --> MSOffice
DEBUG - 2011-09-08 07:29:18 --> Config Class Initialized
DEBUG - 2011-09-08 07:29:18 --> Hooks Class Initialized
DEBUG - 2011-09-08 07:29:18 --> Utf8 Class Initialized
DEBUG - 2011-09-08 07:29:18 --> UTF-8 Support Enabled
DEBUG - 2011-09-08 07:29:18 --> URI Class Initialized
DEBUG - 2011-09-08 07:29:18 --> Router Class Initialized
ERROR - 2011-09-08 07:29:18 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-09-08 07:29:19 --> Config Class Initialized
DEBUG - 2011-09-08 07:29:19 --> Hooks Class Initialized
DEBUG - 2011-09-08 07:29:19 --> Utf8 Class Initialized
DEBUG - 2011-09-08 07:29:19 --> UTF-8 Support Enabled
DEBUG - 2011-09-08 07:29:19 --> URI Class Initialized
DEBUG - 2011-09-08 07:29:19 --> Router Class Initialized
DEBUG - 2011-09-08 07:29:19 --> No URI present. Default controller set.
DEBUG - 2011-09-08 07:29:19 --> Output Class Initialized
DEBUG - 2011-09-08 07:29:19 --> Input Class Initialized
DEBUG - 2011-09-08 07:29:19 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-08 07:29:19 --> Language Class Initialized
DEBUG - 2011-09-08 07:29:19 --> Loader Class Initialized
DEBUG - 2011-09-08 07:29:19 --> Controller Class Initialized
DEBUG - 2011-09-08 07:29:19 --> File loaded: application/views/splash/main.php
DEBUG - 2011-09-08 07:29:19 --> Helper loaded: url_helper
DEBUG - 2011-09-08 07:29:19 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-08 07:29:19 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-08 07:29:19 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-08 07:29:19 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-08 07:29:19 --> Final output sent to browser
DEBUG - 2011-09-08 07:29:19 --> Total execution time: 0.2191
DEBUG - 2011-09-08 10:25:40 --> Config Class Initialized
DEBUG - 2011-09-08 10:25:40 --> Hooks Class Initialized
DEBUG - 2011-09-08 10:25:40 --> Utf8 Class Initialized
DEBUG - 2011-09-08 10:25:40 --> UTF-8 Support Enabled
DEBUG - 2011-09-08 10:25:40 --> URI Class Initialized
DEBUG - 2011-09-08 10:25:40 --> Router Class Initialized
DEBUG - 2011-09-08 10:25:40 --> Output Class Initialized
DEBUG - 2011-09-08 10:25:40 --> Input Class Initialized
DEBUG - 2011-09-08 10:25:40 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-08 10:25:40 --> Language Class Initialized
DEBUG - 2011-09-08 10:25:40 --> Loader Class Initialized
DEBUG - 2011-09-08 10:25:40 --> Controller Class Initialized
DEBUG - 2011-09-08 10:25:40 --> Model Class Initialized
DEBUG - 2011-09-08 10:25:40 --> Model Class Initialized
DEBUG - 2011-09-08 10:25:40 --> Model Class Initialized
DEBUG - 2011-09-08 10:25:40 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-08 10:25:40 --> Database Driver Class Initialized
DEBUG - 2011-09-08 10:25:41 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-08 10:25:41 --> Helper loaded: url_helper
DEBUG - 2011-09-08 10:25:41 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-08 10:25:41 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-08 10:25:41 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-08 10:25:41 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-08 10:25:41 --> Final output sent to browser
DEBUG - 2011-09-08 10:25:41 --> Total execution time: 0.9240
DEBUG - 2011-09-08 10:31:06 --> Config Class Initialized
DEBUG - 2011-09-08 10:31:06 --> Hooks Class Initialized
DEBUG - 2011-09-08 10:31:06 --> Utf8 Class Initialized
DEBUG - 2011-09-08 10:31:06 --> UTF-8 Support Enabled
DEBUG - 2011-09-08 10:31:06 --> URI Class Initialized
DEBUG - 2011-09-08 10:31:06 --> Router Class Initialized
DEBUG - 2011-09-08 10:31:06 --> No URI present. Default controller set.
DEBUG - 2011-09-08 10:31:06 --> Output Class Initialized
DEBUG - 2011-09-08 10:31:06 --> Input Class Initialized
DEBUG - 2011-09-08 10:31:06 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-08 10:31:06 --> Language Class Initialized
DEBUG - 2011-09-08 10:31:06 --> Loader Class Initialized
DEBUG - 2011-09-08 10:31:06 --> Controller Class Initialized
DEBUG - 2011-09-08 10:31:06 --> File loaded: application/views/splash/main.php
DEBUG - 2011-09-08 10:31:06 --> Helper loaded: url_helper
DEBUG - 2011-09-08 10:31:06 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-08 10:31:06 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-08 10:31:06 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-08 10:31:06 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-08 10:31:06 --> Final output sent to browser
DEBUG - 2011-09-08 10:31:06 --> Total execution time: 0.0732
DEBUG - 2011-09-08 13:51:51 --> Config Class Initialized
DEBUG - 2011-09-08 13:51:51 --> Hooks Class Initialized
DEBUG - 2011-09-08 13:51:51 --> Utf8 Class Initialized
DEBUG - 2011-09-08 13:51:51 --> UTF-8 Support Enabled
DEBUG - 2011-09-08 13:51:51 --> URI Class Initialized
DEBUG - 2011-09-08 13:51:51 --> Router Class Initialized
DEBUG - 2011-09-08 13:51:51 --> Output Class Initialized
DEBUG - 2011-09-08 13:51:51 --> Input Class Initialized
DEBUG - 2011-09-08 13:51:51 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-08 13:51:51 --> Language Class Initialized
DEBUG - 2011-09-08 13:51:51 --> Loader Class Initialized
DEBUG - 2011-09-08 13:51:51 --> Controller Class Initialized
DEBUG - 2011-09-08 13:51:51 --> Model Class Initialized
DEBUG - 2011-09-08 13:51:51 --> Model Class Initialized
DEBUG - 2011-09-08 13:51:51 --> Model Class Initialized
DEBUG - 2011-09-08 13:51:51 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-08 13:51:51 --> Database Driver Class Initialized
DEBUG - 2011-09-08 13:51:51 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-08 13:51:51 --> Helper loaded: url_helper
DEBUG - 2011-09-08 13:51:51 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-08 13:51:51 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-08 13:51:51 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-08 13:51:51 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-08 13:51:51 --> Final output sent to browser
DEBUG - 2011-09-08 13:51:51 --> Total execution time: 0.6987
DEBUG - 2011-09-08 15:04:12 --> Config Class Initialized
DEBUG - 2011-09-08 15:04:12 --> Hooks Class Initialized
DEBUG - 2011-09-08 15:04:12 --> Utf8 Class Initialized
DEBUG - 2011-09-08 15:04:12 --> UTF-8 Support Enabled
DEBUG - 2011-09-08 15:04:12 --> URI Class Initialized
DEBUG - 2011-09-08 15:04:12 --> Router Class Initialized
ERROR - 2011-09-08 15:04:12 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-09-08 15:58:29 --> Config Class Initialized
DEBUG - 2011-09-08 15:58:29 --> Hooks Class Initialized
DEBUG - 2011-09-08 15:58:29 --> Utf8 Class Initialized
DEBUG - 2011-09-08 15:58:29 --> UTF-8 Support Enabled
DEBUG - 2011-09-08 15:58:29 --> URI Class Initialized
DEBUG - 2011-09-08 15:58:29 --> Router Class Initialized
DEBUG - 2011-09-08 15:58:29 --> Output Class Initialized
DEBUG - 2011-09-08 15:58:29 --> Input Class Initialized
DEBUG - 2011-09-08 15:58:29 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-08 15:58:29 --> Language Class Initialized
DEBUG - 2011-09-08 15:58:29 --> Loader Class Initialized
DEBUG - 2011-09-08 15:58:29 --> Controller Class Initialized
DEBUG - 2011-09-08 15:58:29 --> Model Class Initialized
DEBUG - 2011-09-08 15:58:29 --> Model Class Initialized
DEBUG - 2011-09-08 15:58:29 --> Model Class Initialized
DEBUG - 2011-09-08 15:58:29 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-08 15:58:29 --> Database Driver Class Initialized
DEBUG - 2011-09-08 15:58:29 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-08 15:58:29 --> Helper loaded: url_helper
DEBUG - 2011-09-08 15:58:29 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-08 15:58:29 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-08 15:58:29 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-08 15:58:29 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-08 15:58:29 --> Final output sent to browser
DEBUG - 2011-09-08 15:58:29 --> Total execution time: 0.4253
DEBUG - 2011-09-08 16:06:58 --> Config Class Initialized
DEBUG - 2011-09-08 16:06:58 --> Hooks Class Initialized
DEBUG - 2011-09-08 16:06:58 --> Utf8 Class Initialized
DEBUG - 2011-09-08 16:06:58 --> UTF-8 Support Enabled
DEBUG - 2011-09-08 16:06:58 --> URI Class Initialized
DEBUG - 2011-09-08 16:06:58 --> Router Class Initialized
ERROR - 2011-09-08 16:06:58 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-09-08 16:06:59 --> Config Class Initialized
DEBUG - 2011-09-08 16:06:59 --> Hooks Class Initialized
DEBUG - 2011-09-08 16:06:59 --> Utf8 Class Initialized
DEBUG - 2011-09-08 16:06:59 --> UTF-8 Support Enabled
DEBUG - 2011-09-08 16:06:59 --> URI Class Initialized
DEBUG - 2011-09-08 16:06:59 --> Router Class Initialized
DEBUG - 2011-09-08 16:06:59 --> Output Class Initialized
DEBUG - 2011-09-08 16:06:59 --> Input Class Initialized
DEBUG - 2011-09-08 16:06:59 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-08 16:07:00 --> Language Class Initialized
DEBUG - 2011-09-08 16:07:00 --> Loader Class Initialized
DEBUG - 2011-09-08 16:07:00 --> Controller Class Initialized
ERROR - 2011-09-08 16:07:00 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-08 16:07:00 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-08 16:07:00 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-08 16:07:00 --> Model Class Initialized
DEBUG - 2011-09-08 16:07:00 --> Model Class Initialized
DEBUG - 2011-09-08 16:07:00 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-08 16:07:00 --> Database Driver Class Initialized
DEBUG - 2011-09-08 16:07:00 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-08 16:07:00 --> Helper loaded: url_helper
DEBUG - 2011-09-08 16:07:00 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-08 16:07:00 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-08 16:07:00 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-08 16:07:00 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-08 16:07:00 --> Final output sent to browser
DEBUG - 2011-09-08 16:07:00 --> Total execution time: 0.1252
DEBUG - 2011-09-08 17:20:45 --> Config Class Initialized
DEBUG - 2011-09-08 17:20:45 --> Hooks Class Initialized
DEBUG - 2011-09-08 17:20:45 --> Utf8 Class Initialized
DEBUG - 2011-09-08 17:20:45 --> UTF-8 Support Enabled
DEBUG - 2011-09-08 17:20:45 --> URI Class Initialized
DEBUG - 2011-09-08 17:20:45 --> Router Class Initialized
DEBUG - 2011-09-08 17:20:45 --> Output Class Initialized
DEBUG - 2011-09-08 17:20:45 --> Input Class Initialized
DEBUG - 2011-09-08 17:20:45 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-08 17:20:45 --> Language Class Initialized
DEBUG - 2011-09-08 17:20:45 --> Loader Class Initialized
DEBUG - 2011-09-08 17:20:45 --> Controller Class Initialized
DEBUG - 2011-09-08 17:20:45 --> Model Class Initialized
DEBUG - 2011-09-08 17:20:45 --> Model Class Initialized
DEBUG - 2011-09-08 17:20:45 --> Model Class Initialized
DEBUG - 2011-09-08 17:20:45 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-08 17:20:45 --> Database Driver Class Initialized
DEBUG - 2011-09-08 17:20:46 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-08 17:20:46 --> Helper loaded: url_helper
DEBUG - 2011-09-08 17:20:46 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-08 17:20:46 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-08 17:20:46 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-08 17:20:46 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-08 17:20:46 --> Final output sent to browser
DEBUG - 2011-09-08 17:20:46 --> Total execution time: 0.2287
DEBUG - 2011-09-08 17:20:57 --> Config Class Initialized
DEBUG - 2011-09-08 17:20:57 --> Hooks Class Initialized
DEBUG - 2011-09-08 17:20:57 --> Utf8 Class Initialized
DEBUG - 2011-09-08 17:20:57 --> UTF-8 Support Enabled
DEBUG - 2011-09-08 17:20:57 --> URI Class Initialized
DEBUG - 2011-09-08 17:20:57 --> Router Class Initialized
ERROR - 2011-09-08 17:20:57 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-08 17:36:17 --> Config Class Initialized
DEBUG - 2011-09-08 17:36:17 --> Hooks Class Initialized
DEBUG - 2011-09-08 17:36:17 --> Utf8 Class Initialized
DEBUG - 2011-09-08 17:36:17 --> UTF-8 Support Enabled
DEBUG - 2011-09-08 17:36:17 --> URI Class Initialized
DEBUG - 2011-09-08 17:36:17 --> Router Class Initialized
DEBUG - 2011-09-08 17:36:17 --> No URI present. Default controller set.
DEBUG - 2011-09-08 17:36:17 --> Output Class Initialized
DEBUG - 2011-09-08 17:36:17 --> Input Class Initialized
DEBUG - 2011-09-08 17:36:17 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-08 17:36:17 --> Language Class Initialized
DEBUG - 2011-09-08 17:36:17 --> Loader Class Initialized
DEBUG - 2011-09-08 17:36:17 --> Controller Class Initialized
DEBUG - 2011-09-08 17:36:17 --> File loaded: application/views/splash/main.php
DEBUG - 2011-09-08 17:36:17 --> Helper loaded: url_helper
DEBUG - 2011-09-08 17:36:17 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-08 17:36:17 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-08 17:36:17 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-08 17:36:17 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-08 17:36:17 --> Final output sent to browser
DEBUG - 2011-09-08 17:36:17 --> Total execution time: 0.0745
DEBUG - 2011-09-08 17:37:39 --> Config Class Initialized
DEBUG - 2011-09-08 17:37:39 --> Hooks Class Initialized
DEBUG - 2011-09-08 17:37:39 --> Utf8 Class Initialized
DEBUG - 2011-09-08 17:37:39 --> UTF-8 Support Enabled
DEBUG - 2011-09-08 17:37:39 --> URI Class Initialized
DEBUG - 2011-09-08 17:37:39 --> Router Class Initialized
DEBUG - 2011-09-08 17:37:39 --> Output Class Initialized
DEBUG - 2011-09-08 17:37:39 --> Input Class Initialized
DEBUG - 2011-09-08 17:37:39 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-08 17:37:39 --> Language Class Initialized
DEBUG - 2011-09-08 17:37:39 --> Loader Class Initialized
DEBUG - 2011-09-08 17:37:39 --> Controller Class Initialized
DEBUG - 2011-09-08 17:37:39 --> Model Class Initialized
DEBUG - 2011-09-08 17:37:39 --> Model Class Initialized
DEBUG - 2011-09-08 17:37:39 --> Model Class Initialized
DEBUG - 2011-09-08 17:37:39 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-08 17:37:39 --> Database Driver Class Initialized
DEBUG - 2011-09-08 17:37:39 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-08 17:37:39 --> Helper loaded: url_helper
DEBUG - 2011-09-08 17:37:39 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-08 17:37:39 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-08 17:37:39 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-08 17:37:39 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-08 17:37:39 --> Final output sent to browser
DEBUG - 2011-09-08 17:37:39 --> Total execution time: 0.0547
DEBUG - 2011-09-08 17:37:41 --> Config Class Initialized
DEBUG - 2011-09-08 17:37:41 --> Hooks Class Initialized
DEBUG - 2011-09-08 17:37:41 --> Utf8 Class Initialized
DEBUG - 2011-09-08 17:37:41 --> UTF-8 Support Enabled
DEBUG - 2011-09-08 17:37:41 --> URI Class Initialized
DEBUG - 2011-09-08 17:37:41 --> Router Class Initialized
ERROR - 2011-09-08 17:37:41 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-08 17:37:52 --> Config Class Initialized
DEBUG - 2011-09-08 17:37:52 --> Hooks Class Initialized
DEBUG - 2011-09-08 17:37:52 --> Utf8 Class Initialized
DEBUG - 2011-09-08 17:37:52 --> UTF-8 Support Enabled
DEBUG - 2011-09-08 17:37:52 --> URI Class Initialized
DEBUG - 2011-09-08 17:37:52 --> Router Class Initialized
DEBUG - 2011-09-08 17:37:52 --> Output Class Initialized
DEBUG - 2011-09-08 17:37:52 --> Input Class Initialized
DEBUG - 2011-09-08 17:37:52 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-08 17:37:52 --> Language Class Initialized
DEBUG - 2011-09-08 17:37:52 --> Loader Class Initialized
DEBUG - 2011-09-08 17:37:52 --> Controller Class Initialized
DEBUG - 2011-09-08 17:37:52 --> Model Class Initialized
DEBUG - 2011-09-08 17:37:52 --> Model Class Initialized
DEBUG - 2011-09-08 17:37:52 --> Model Class Initialized
DEBUG - 2011-09-08 17:37:52 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-08 17:37:52 --> Database Driver Class Initialized
DEBUG - 2011-09-08 17:37:52 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-08 17:37:52 --> Helper loaded: url_helper
DEBUG - 2011-09-08 17:37:52 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-08 17:37:52 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-08 17:37:52 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-08 17:37:52 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-08 17:37:52 --> Final output sent to browser
DEBUG - 2011-09-08 17:37:52 --> Total execution time: 0.5364
DEBUG - 2011-09-08 17:37:55 --> Config Class Initialized
DEBUG - 2011-09-08 17:37:55 --> Hooks Class Initialized
DEBUG - 2011-09-08 17:37:55 --> Utf8 Class Initialized
DEBUG - 2011-09-08 17:37:55 --> UTF-8 Support Enabled
DEBUG - 2011-09-08 17:37:55 --> URI Class Initialized
DEBUG - 2011-09-08 17:37:55 --> Router Class Initialized
DEBUG - 2011-09-08 17:37:55 --> Output Class Initialized
DEBUG - 2011-09-08 17:37:55 --> Input Class Initialized
DEBUG - 2011-09-08 17:37:55 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-08 17:37:55 --> Language Class Initialized
DEBUG - 2011-09-08 17:37:55 --> Loader Class Initialized
DEBUG - 2011-09-08 17:37:55 --> Controller Class Initialized
DEBUG - 2011-09-08 17:37:55 --> Model Class Initialized
DEBUG - 2011-09-08 17:37:55 --> Model Class Initialized
DEBUG - 2011-09-08 17:37:55 --> Model Class Initialized
DEBUG - 2011-09-08 17:37:55 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-08 17:37:55 --> Database Driver Class Initialized
DEBUG - 2011-09-08 17:37:55 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-08 17:37:55 --> Helper loaded: url_helper
DEBUG - 2011-09-08 17:37:55 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-08 17:37:55 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-08 17:37:55 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-08 17:37:55 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-08 17:37:55 --> Final output sent to browser
DEBUG - 2011-09-08 17:37:55 --> Total execution time: 0.0461
DEBUG - 2011-09-08 17:53:30 --> Config Class Initialized
DEBUG - 2011-09-08 17:53:30 --> Hooks Class Initialized
DEBUG - 2011-09-08 17:53:30 --> Utf8 Class Initialized
DEBUG - 2011-09-08 17:53:30 --> UTF-8 Support Enabled
DEBUG - 2011-09-08 17:53:30 --> URI Class Initialized
DEBUG - 2011-09-08 17:53:30 --> Router Class Initialized
DEBUG - 2011-09-08 17:53:30 --> Output Class Initialized
DEBUG - 2011-09-08 17:53:30 --> Input Class Initialized
DEBUG - 2011-09-08 17:53:30 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-08 17:53:30 --> Language Class Initialized
DEBUG - 2011-09-08 17:53:30 --> Loader Class Initialized
DEBUG - 2011-09-08 17:53:30 --> Controller Class Initialized
DEBUG - 2011-09-08 17:53:30 --> Model Class Initialized
DEBUG - 2011-09-08 17:53:30 --> Model Class Initialized
DEBUG - 2011-09-08 17:53:30 --> Model Class Initialized
DEBUG - 2011-09-08 17:53:30 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-08 17:53:30 --> Database Driver Class Initialized
DEBUG - 2011-09-08 17:53:30 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-08 17:53:30 --> Helper loaded: url_helper
DEBUG - 2011-09-08 17:53:30 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-08 17:53:30 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-08 17:53:30 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-08 17:53:30 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-08 17:53:30 --> Final output sent to browser
DEBUG - 2011-09-08 17:53:30 --> Total execution time: 0.0709
DEBUG - 2011-09-08 17:53:45 --> Config Class Initialized
DEBUG - 2011-09-08 17:53:45 --> Hooks Class Initialized
DEBUG - 2011-09-08 17:53:45 --> Utf8 Class Initialized
DEBUG - 2011-09-08 17:53:45 --> UTF-8 Support Enabled
DEBUG - 2011-09-08 17:53:45 --> URI Class Initialized
DEBUG - 2011-09-08 17:53:45 --> Router Class Initialized
DEBUG - 2011-09-08 17:53:45 --> Output Class Initialized
DEBUG - 2011-09-08 17:53:45 --> Input Class Initialized
DEBUG - 2011-09-08 17:53:45 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-08 17:53:45 --> Language Class Initialized
DEBUG - 2011-09-08 17:53:46 --> Loader Class Initialized
DEBUG - 2011-09-08 17:53:46 --> Controller Class Initialized
ERROR - 2011-09-08 17:53:46 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-08 17:53:46 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-08 17:53:46 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-08 17:53:46 --> Model Class Initialized
DEBUG - 2011-09-08 17:53:46 --> Model Class Initialized
DEBUG - 2011-09-08 17:53:46 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-08 17:53:46 --> Database Driver Class Initialized
DEBUG - 2011-09-08 17:53:46 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-08 17:53:46 --> Helper loaded: url_helper
DEBUG - 2011-09-08 17:53:46 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-08 17:53:46 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-08 17:53:46 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-08 17:53:46 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-08 17:53:46 --> Final output sent to browser
DEBUG - 2011-09-08 17:53:46 --> Total execution time: 0.1647
DEBUG - 2011-09-08 17:53:47 --> Config Class Initialized
DEBUG - 2011-09-08 17:53:47 --> Hooks Class Initialized
DEBUG - 2011-09-08 17:53:47 --> Utf8 Class Initialized
DEBUG - 2011-09-08 17:53:47 --> UTF-8 Support Enabled
DEBUG - 2011-09-08 17:53:47 --> URI Class Initialized
DEBUG - 2011-09-08 17:53:47 --> Router Class Initialized
DEBUG - 2011-09-08 17:53:47 --> Output Class Initialized
DEBUG - 2011-09-08 17:53:47 --> Input Class Initialized
DEBUG - 2011-09-08 17:53:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-08 17:53:47 --> Language Class Initialized
DEBUG - 2011-09-08 17:53:47 --> Loader Class Initialized
DEBUG - 2011-09-08 17:53:47 --> Controller Class Initialized
DEBUG - 2011-09-08 17:53:47 --> Model Class Initialized
DEBUG - 2011-09-08 17:53:47 --> Model Class Initialized
DEBUG - 2011-09-08 17:53:47 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-08 17:53:47 --> Database Driver Class Initialized
DEBUG - 2011-09-08 17:53:47 --> Final output sent to browser
DEBUG - 2011-09-08 17:53:47 --> Total execution time: 0.5250
DEBUG - 2011-09-08 19:47:46 --> Config Class Initialized
DEBUG - 2011-09-08 19:47:46 --> Hooks Class Initialized
DEBUG - 2011-09-08 19:47:46 --> Utf8 Class Initialized
DEBUG - 2011-09-08 19:47:46 --> UTF-8 Support Enabled
DEBUG - 2011-09-08 19:47:46 --> URI Class Initialized
DEBUG - 2011-09-08 19:47:46 --> Router Class Initialized
DEBUG - 2011-09-08 19:47:46 --> Output Class Initialized
DEBUG - 2011-09-08 19:47:46 --> Input Class Initialized
DEBUG - 2011-09-08 19:47:46 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-08 19:47:46 --> Language Class Initialized
DEBUG - 2011-09-08 19:47:46 --> Loader Class Initialized
DEBUG - 2011-09-08 19:47:46 --> Controller Class Initialized
ERROR - 2011-09-08 19:47:46 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-08 19:47:46 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-08 19:47:46 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-08 19:47:46 --> Model Class Initialized
DEBUG - 2011-09-08 19:47:46 --> Model Class Initialized
DEBUG - 2011-09-08 19:47:46 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-08 19:47:46 --> Database Driver Class Initialized
DEBUG - 2011-09-08 19:47:46 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-08 19:47:46 --> Helper loaded: url_helper
DEBUG - 2011-09-08 19:47:46 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-08 19:47:46 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-08 19:47:46 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-08 19:47:46 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-08 19:47:46 --> Final output sent to browser
DEBUG - 2011-09-08 19:47:46 --> Total execution time: 0.2941
DEBUG - 2011-09-08 19:54:09 --> Config Class Initialized
DEBUG - 2011-09-08 19:54:09 --> Hooks Class Initialized
DEBUG - 2011-09-08 19:54:09 --> Utf8 Class Initialized
DEBUG - 2011-09-08 19:54:09 --> UTF-8 Support Enabled
DEBUG - 2011-09-08 19:54:09 --> URI Class Initialized
DEBUG - 2011-09-08 19:54:09 --> Router Class Initialized
ERROR - 2011-09-08 19:54:09 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-09-08 20:59:21 --> Config Class Initialized
DEBUG - 2011-09-08 20:59:21 --> Hooks Class Initialized
DEBUG - 2011-09-08 20:59:21 --> Utf8 Class Initialized
DEBUG - 2011-09-08 20:59:21 --> UTF-8 Support Enabled
DEBUG - 2011-09-08 20:59:21 --> URI Class Initialized
DEBUG - 2011-09-08 20:59:21 --> Router Class Initialized
DEBUG - 2011-09-08 20:59:21 --> Output Class Initialized
DEBUG - 2011-09-08 20:59:21 --> Input Class Initialized
DEBUG - 2011-09-08 20:59:21 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-08 20:59:21 --> Language Class Initialized
DEBUG - 2011-09-08 20:59:21 --> Loader Class Initialized
DEBUG - 2011-09-08 20:59:21 --> Controller Class Initialized
DEBUG - 2011-09-08 20:59:21 --> Model Class Initialized
DEBUG - 2011-09-08 20:59:21 --> Model Class Initialized
DEBUG - 2011-09-08 20:59:21 --> Model Class Initialized
DEBUG - 2011-09-08 20:59:21 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-08 20:59:22 --> Database Driver Class Initialized
DEBUG - 2011-09-08 20:59:22 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-08 20:59:22 --> Helper loaded: url_helper
DEBUG - 2011-09-08 20:59:22 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-08 20:59:22 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-08 20:59:22 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-08 20:59:22 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-08 20:59:22 --> Final output sent to browser
DEBUG - 2011-09-08 20:59:22 --> Total execution time: 0.9732
DEBUG - 2011-09-08 20:59:24 --> Config Class Initialized
DEBUG - 2011-09-08 20:59:24 --> Hooks Class Initialized
DEBUG - 2011-09-08 20:59:24 --> Utf8 Class Initialized
DEBUG - 2011-09-08 20:59:24 --> UTF-8 Support Enabled
DEBUG - 2011-09-08 20:59:24 --> URI Class Initialized
DEBUG - 2011-09-08 20:59:24 --> Router Class Initialized
DEBUG - 2011-09-08 20:59:24 --> Output Class Initialized
DEBUG - 2011-09-08 20:59:24 --> Input Class Initialized
DEBUG - 2011-09-08 20:59:24 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-08 20:59:24 --> Language Class Initialized
DEBUG - 2011-09-08 20:59:24 --> Loader Class Initialized
DEBUG - 2011-09-08 20:59:24 --> Controller Class Initialized
ERROR - 2011-09-08 20:59:24 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-08 20:59:24 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-08 20:59:24 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-08 20:59:24 --> Model Class Initialized
DEBUG - 2011-09-08 20:59:24 --> Model Class Initialized
DEBUG - 2011-09-08 20:59:24 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-08 20:59:24 --> Database Driver Class Initialized
DEBUG - 2011-09-08 20:59:24 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-08 20:59:24 --> Helper loaded: url_helper
DEBUG - 2011-09-08 20:59:24 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-08 20:59:24 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-08 20:59:24 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-08 20:59:24 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-08 20:59:24 --> Final output sent to browser
DEBUG - 2011-09-08 20:59:24 --> Total execution time: 0.0619
DEBUG - 2011-09-08 23:48:33 --> Config Class Initialized
DEBUG - 2011-09-08 23:48:33 --> Hooks Class Initialized
DEBUG - 2011-09-08 23:48:33 --> Utf8 Class Initialized
DEBUG - 2011-09-08 23:48:33 --> UTF-8 Support Enabled
DEBUG - 2011-09-08 23:48:33 --> URI Class Initialized
DEBUG - 2011-09-08 23:48:33 --> Router Class Initialized
DEBUG - 2011-09-08 23:48:33 --> Output Class Initialized
DEBUG - 2011-09-08 23:48:33 --> Input Class Initialized
DEBUG - 2011-09-08 23:48:33 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-08 23:48:33 --> Language Class Initialized
DEBUG - 2011-09-08 23:48:33 --> Loader Class Initialized
DEBUG - 2011-09-08 23:48:33 --> Controller Class Initialized
DEBUG - 2011-09-08 23:48:33 --> Model Class Initialized
DEBUG - 2011-09-08 23:48:33 --> Model Class Initialized
DEBUG - 2011-09-08 23:48:33 --> Model Class Initialized
DEBUG - 2011-09-08 23:48:33 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-08 23:48:33 --> Database Driver Class Initialized
DEBUG - 2011-09-08 23:48:33 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-08 23:48:33 --> Helper loaded: url_helper
DEBUG - 2011-09-08 23:48:33 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-08 23:48:33 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-08 23:48:33 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-08 23:48:33 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-08 23:48:33 --> Final output sent to browser
DEBUG - 2011-09-08 23:48:33 --> Total execution time: 0.4141
DEBUG - 2011-09-08 23:48:35 --> Config Class Initialized
DEBUG - 2011-09-08 23:48:35 --> Hooks Class Initialized
DEBUG - 2011-09-08 23:48:35 --> Utf8 Class Initialized
DEBUG - 2011-09-08 23:48:35 --> UTF-8 Support Enabled
DEBUG - 2011-09-08 23:48:35 --> URI Class Initialized
DEBUG - 2011-09-08 23:48:35 --> Router Class Initialized
DEBUG - 2011-09-08 23:48:35 --> Output Class Initialized
DEBUG - 2011-09-08 23:48:35 --> Input Class Initialized
DEBUG - 2011-09-08 23:48:35 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-08 23:48:35 --> Language Class Initialized
DEBUG - 2011-09-08 23:48:35 --> Loader Class Initialized
DEBUG - 2011-09-08 23:48:35 --> Controller Class Initialized
ERROR - 2011-09-08 23:48:35 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-08 23:48:35 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-08 23:48:35 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-08 23:48:35 --> Model Class Initialized
DEBUG - 2011-09-08 23:48:35 --> Model Class Initialized
DEBUG - 2011-09-08 23:48:35 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-08 23:48:35 --> Database Driver Class Initialized
DEBUG - 2011-09-08 23:48:35 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-08 23:48:35 --> Helper loaded: url_helper
DEBUG - 2011-09-08 23:48:35 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-08 23:48:35 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-08 23:48:35 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-08 23:48:35 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-08 23:48:35 --> Final output sent to browser
DEBUG - 2011-09-08 23:48:35 --> Total execution time: 0.2131
DEBUG - 2011-09-08 23:49:36 --> Config Class Initialized
DEBUG - 2011-09-08 23:49:36 --> Hooks Class Initialized
DEBUG - 2011-09-08 23:49:36 --> Utf8 Class Initialized
DEBUG - 2011-09-08 23:49:36 --> UTF-8 Support Enabled
DEBUG - 2011-09-08 23:49:36 --> URI Class Initialized
DEBUG - 2011-09-08 23:49:36 --> Router Class Initialized
DEBUG - 2011-09-08 23:49:36 --> Output Class Initialized
DEBUG - 2011-09-08 23:49:36 --> Input Class Initialized
DEBUG - 2011-09-08 23:49:36 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-08 23:49:36 --> Language Class Initialized
DEBUG - 2011-09-08 23:49:36 --> Loader Class Initialized
DEBUG - 2011-09-08 23:49:36 --> Controller Class Initialized
DEBUG - 2011-09-08 23:49:36 --> Model Class Initialized
DEBUG - 2011-09-08 23:49:36 --> Model Class Initialized
DEBUG - 2011-09-08 23:49:36 --> Model Class Initialized
DEBUG - 2011-09-08 23:49:36 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-08 23:49:36 --> Database Driver Class Initialized
DEBUG - 2011-09-08 23:49:36 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-08 23:49:36 --> Helper loaded: url_helper
DEBUG - 2011-09-08 23:49:36 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-08 23:49:36 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-08 23:49:36 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-08 23:49:36 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-08 23:49:36 --> Final output sent to browser
DEBUG - 2011-09-08 23:49:36 --> Total execution time: 0.0624
DEBUG - 2011-09-08 23:49:37 --> Config Class Initialized
DEBUG - 2011-09-08 23:49:37 --> Hooks Class Initialized
DEBUG - 2011-09-08 23:49:37 --> Utf8 Class Initialized
DEBUG - 2011-09-08 23:49:37 --> UTF-8 Support Enabled
DEBUG - 2011-09-08 23:49:37 --> URI Class Initialized
DEBUG - 2011-09-08 23:49:37 --> Router Class Initialized
DEBUG - 2011-09-08 23:49:37 --> Output Class Initialized
DEBUG - 2011-09-08 23:49:37 --> Input Class Initialized
DEBUG - 2011-09-08 23:49:37 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-08 23:49:37 --> Language Class Initialized
DEBUG - 2011-09-08 23:49:37 --> Loader Class Initialized
DEBUG - 2011-09-08 23:49:37 --> Controller Class Initialized
ERROR - 2011-09-08 23:49:37 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-08 23:49:37 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-08 23:49:37 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-08 23:49:37 --> Model Class Initialized
DEBUG - 2011-09-08 23:49:37 --> Model Class Initialized
DEBUG - 2011-09-08 23:49:37 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-08 23:49:37 --> Database Driver Class Initialized
DEBUG - 2011-09-08 23:49:37 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-08 23:49:37 --> Helper loaded: url_helper
DEBUG - 2011-09-08 23:49:37 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-08 23:49:37 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-08 23:49:37 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-08 23:49:37 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-08 23:49:37 --> Final output sent to browser
DEBUG - 2011-09-08 23:49:37 --> Total execution time: 0.1013

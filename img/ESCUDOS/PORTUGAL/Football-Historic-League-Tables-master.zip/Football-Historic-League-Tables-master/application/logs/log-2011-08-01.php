<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2011-08-01 00:03:20 --> Config Class Initialized
DEBUG - 2011-08-01 00:03:20 --> Hooks Class Initialized
DEBUG - 2011-08-01 00:03:20 --> Utf8 Class Initialized
DEBUG - 2011-08-01 00:03:20 --> UTF-8 Support Enabled
DEBUG - 2011-08-01 00:03:20 --> URI Class Initialized
DEBUG - 2011-08-01 00:03:20 --> Router Class Initialized
DEBUG - 2011-08-01 00:03:20 --> Output Class Initialized
DEBUG - 2011-08-01 00:03:20 --> Input Class Initialized
DEBUG - 2011-08-01 00:03:20 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-01 00:03:20 --> Language Class Initialized
DEBUG - 2011-08-01 00:03:20 --> Loader Class Initialized
DEBUG - 2011-08-01 00:03:20 --> Controller Class Initialized
DEBUG - 2011-08-01 00:03:20 --> Model Class Initialized
DEBUG - 2011-08-01 00:03:20 --> Model Class Initialized
DEBUG - 2011-08-01 00:03:20 --> Model Class Initialized
DEBUG - 2011-08-01 00:03:20 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-01 00:03:20 --> Database Driver Class Initialized
DEBUG - 2011-08-01 00:03:21 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-01 00:03:21 --> Helper loaded: url_helper
DEBUG - 2011-08-01 00:03:21 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-01 00:03:21 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-01 00:03:21 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-01 00:03:21 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-01 00:03:21 --> Final output sent to browser
DEBUG - 2011-08-01 00:03:21 --> Total execution time: 0.8830
DEBUG - 2011-08-01 00:03:23 --> Config Class Initialized
DEBUG - 2011-08-01 00:03:23 --> Hooks Class Initialized
DEBUG - 2011-08-01 00:03:23 --> Utf8 Class Initialized
DEBUG - 2011-08-01 00:03:23 --> UTF-8 Support Enabled
DEBUG - 2011-08-01 00:03:23 --> URI Class Initialized
DEBUG - 2011-08-01 00:03:23 --> Router Class Initialized
ERROR - 2011-08-01 00:03:23 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-01 00:03:43 --> Config Class Initialized
DEBUG - 2011-08-01 00:03:43 --> Hooks Class Initialized
DEBUG - 2011-08-01 00:03:43 --> Utf8 Class Initialized
DEBUG - 2011-08-01 00:03:43 --> UTF-8 Support Enabled
DEBUG - 2011-08-01 00:03:43 --> URI Class Initialized
DEBUG - 2011-08-01 00:03:43 --> Router Class Initialized
DEBUG - 2011-08-01 00:03:43 --> Output Class Initialized
DEBUG - 2011-08-01 00:03:43 --> Input Class Initialized
DEBUG - 2011-08-01 00:03:43 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-01 00:03:43 --> Language Class Initialized
DEBUG - 2011-08-01 00:03:43 --> Loader Class Initialized
DEBUG - 2011-08-01 00:03:43 --> Controller Class Initialized
DEBUG - 2011-08-01 00:03:43 --> Model Class Initialized
DEBUG - 2011-08-01 00:03:43 --> Model Class Initialized
DEBUG - 2011-08-01 00:03:43 --> Model Class Initialized
DEBUG - 2011-08-01 00:03:43 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-01 00:03:43 --> Database Driver Class Initialized
DEBUG - 2011-08-01 00:03:43 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-01 00:03:43 --> Helper loaded: url_helper
DEBUG - 2011-08-01 00:03:43 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-01 00:03:43 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-01 00:03:43 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-01 00:03:43 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-01 00:03:43 --> Final output sent to browser
DEBUG - 2011-08-01 00:03:43 --> Total execution time: 0.3159
DEBUG - 2011-08-01 00:03:45 --> Config Class Initialized
DEBUG - 2011-08-01 00:03:45 --> Hooks Class Initialized
DEBUG - 2011-08-01 00:03:45 --> Utf8 Class Initialized
DEBUG - 2011-08-01 00:03:45 --> UTF-8 Support Enabled
DEBUG - 2011-08-01 00:03:45 --> URI Class Initialized
DEBUG - 2011-08-01 00:03:45 --> Router Class Initialized
ERROR - 2011-08-01 00:03:45 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-01 00:03:45 --> Config Class Initialized
DEBUG - 2011-08-01 00:03:45 --> Hooks Class Initialized
DEBUG - 2011-08-01 00:03:45 --> Utf8 Class Initialized
DEBUG - 2011-08-01 00:03:45 --> UTF-8 Support Enabled
DEBUG - 2011-08-01 00:03:45 --> URI Class Initialized
DEBUG - 2011-08-01 00:03:45 --> Router Class Initialized
ERROR - 2011-08-01 00:03:45 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-08-01 00:03:45 --> Config Class Initialized
DEBUG - 2011-08-01 00:03:45 --> Hooks Class Initialized
DEBUG - 2011-08-01 00:03:45 --> Utf8 Class Initialized
DEBUG - 2011-08-01 00:03:45 --> UTF-8 Support Enabled
DEBUG - 2011-08-01 00:03:45 --> URI Class Initialized
DEBUG - 2011-08-01 00:03:45 --> Router Class Initialized
DEBUG - 2011-08-01 00:03:45 --> Output Class Initialized
DEBUG - 2011-08-01 00:03:45 --> Input Class Initialized
DEBUG - 2011-08-01 00:03:45 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-01 00:03:45 --> Language Class Initialized
DEBUG - 2011-08-01 00:03:45 --> Loader Class Initialized
DEBUG - 2011-08-01 00:03:45 --> Controller Class Initialized
DEBUG - 2011-08-01 00:03:45 --> Model Class Initialized
DEBUG - 2011-08-01 00:03:45 --> Model Class Initialized
DEBUG - 2011-08-01 00:03:45 --> Model Class Initialized
DEBUG - 2011-08-01 00:03:45 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-01 00:03:45 --> Database Driver Class Initialized
DEBUG - 2011-08-01 00:03:45 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-01 00:03:45 --> Helper loaded: url_helper
DEBUG - 2011-08-01 00:03:45 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-01 00:03:45 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-01 00:03:45 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-01 00:03:45 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-01 00:03:45 --> Final output sent to browser
DEBUG - 2011-08-01 00:03:45 --> Total execution time: 0.0600
DEBUG - 2011-08-01 00:05:18 --> Config Class Initialized
DEBUG - 2011-08-01 00:05:18 --> Hooks Class Initialized
DEBUG - 2011-08-01 00:05:18 --> Utf8 Class Initialized
DEBUG - 2011-08-01 00:05:18 --> UTF-8 Support Enabled
DEBUG - 2011-08-01 00:05:18 --> URI Class Initialized
DEBUG - 2011-08-01 00:05:18 --> Router Class Initialized
ERROR - 2011-08-01 00:05:18 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-01 00:05:35 --> Config Class Initialized
DEBUG - 2011-08-01 00:05:35 --> Hooks Class Initialized
DEBUG - 2011-08-01 00:05:35 --> Utf8 Class Initialized
DEBUG - 2011-08-01 00:05:35 --> UTF-8 Support Enabled
DEBUG - 2011-08-01 00:05:35 --> URI Class Initialized
DEBUG - 2011-08-01 00:05:35 --> Router Class Initialized
DEBUG - 2011-08-01 00:05:35 --> Output Class Initialized
DEBUG - 2011-08-01 00:05:35 --> Input Class Initialized
DEBUG - 2011-08-01 00:05:35 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-01 00:05:35 --> Language Class Initialized
DEBUG - 2011-08-01 00:05:35 --> Loader Class Initialized
DEBUG - 2011-08-01 00:05:35 --> Controller Class Initialized
ERROR - 2011-08-01 00:05:35 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-01 00:05:35 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-01 00:05:35 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-01 00:05:35 --> Model Class Initialized
DEBUG - 2011-08-01 00:05:35 --> Model Class Initialized
DEBUG - 2011-08-01 00:05:35 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-01 00:05:35 --> Database Driver Class Initialized
DEBUG - 2011-08-01 00:05:35 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-01 00:05:35 --> Helper loaded: url_helper
DEBUG - 2011-08-01 00:05:35 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-01 00:05:35 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-01 00:05:35 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-01 00:05:35 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-01 00:05:35 --> Final output sent to browser
DEBUG - 2011-08-01 00:05:35 --> Total execution time: 0.0618
DEBUG - 2011-08-01 00:05:36 --> Config Class Initialized
DEBUG - 2011-08-01 00:05:36 --> Hooks Class Initialized
DEBUG - 2011-08-01 00:05:36 --> Utf8 Class Initialized
DEBUG - 2011-08-01 00:05:36 --> UTF-8 Support Enabled
DEBUG - 2011-08-01 00:05:36 --> URI Class Initialized
DEBUG - 2011-08-01 00:05:36 --> Router Class Initialized
DEBUG - 2011-08-01 00:05:36 --> Output Class Initialized
DEBUG - 2011-08-01 00:05:36 --> Input Class Initialized
DEBUG - 2011-08-01 00:05:36 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-01 00:05:36 --> Language Class Initialized
DEBUG - 2011-08-01 00:05:36 --> Loader Class Initialized
DEBUG - 2011-08-01 00:05:36 --> Controller Class Initialized
DEBUG - 2011-08-01 00:05:36 --> Model Class Initialized
DEBUG - 2011-08-01 00:05:36 --> Model Class Initialized
DEBUG - 2011-08-01 00:05:36 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-01 00:05:36 --> Database Driver Class Initialized
DEBUG - 2011-08-01 00:05:37 --> Final output sent to browser
DEBUG - 2011-08-01 00:05:37 --> Total execution time: 0.7977
DEBUG - 2011-08-01 00:05:37 --> Config Class Initialized
DEBUG - 2011-08-01 00:05:37 --> Hooks Class Initialized
DEBUG - 2011-08-01 00:05:37 --> Utf8 Class Initialized
DEBUG - 2011-08-01 00:05:37 --> UTF-8 Support Enabled
DEBUG - 2011-08-01 00:05:37 --> URI Class Initialized
DEBUG - 2011-08-01 00:05:37 --> Router Class Initialized
ERROR - 2011-08-01 00:05:37 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-01 00:06:34 --> Config Class Initialized
DEBUG - 2011-08-01 00:06:34 --> Hooks Class Initialized
DEBUG - 2011-08-01 00:06:34 --> Utf8 Class Initialized
DEBUG - 2011-08-01 00:06:34 --> UTF-8 Support Enabled
DEBUG - 2011-08-01 00:06:34 --> URI Class Initialized
DEBUG - 2011-08-01 00:06:34 --> Router Class Initialized
DEBUG - 2011-08-01 00:06:34 --> Output Class Initialized
DEBUG - 2011-08-01 00:06:34 --> Input Class Initialized
DEBUG - 2011-08-01 00:06:34 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-01 00:06:34 --> Language Class Initialized
DEBUG - 2011-08-01 00:06:34 --> Loader Class Initialized
DEBUG - 2011-08-01 00:06:34 --> Controller Class Initialized
ERROR - 2011-08-01 00:06:34 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-01 00:06:34 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-01 00:06:34 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-01 00:06:34 --> Model Class Initialized
DEBUG - 2011-08-01 00:06:34 --> Model Class Initialized
DEBUG - 2011-08-01 00:06:34 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-01 00:06:34 --> Database Driver Class Initialized
DEBUG - 2011-08-01 00:06:34 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-01 00:06:34 --> Helper loaded: url_helper
DEBUG - 2011-08-01 00:06:34 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-01 00:06:34 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-01 00:06:34 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-01 00:06:34 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-01 00:06:34 --> Final output sent to browser
DEBUG - 2011-08-01 00:06:34 --> Total execution time: 0.1154
DEBUG - 2011-08-01 00:06:34 --> Config Class Initialized
DEBUG - 2011-08-01 00:06:34 --> Hooks Class Initialized
DEBUG - 2011-08-01 00:06:34 --> Utf8 Class Initialized
DEBUG - 2011-08-01 00:06:34 --> UTF-8 Support Enabled
DEBUG - 2011-08-01 00:06:34 --> URI Class Initialized
DEBUG - 2011-08-01 00:06:34 --> Router Class Initialized
DEBUG - 2011-08-01 00:06:34 --> Output Class Initialized
DEBUG - 2011-08-01 00:06:34 --> Input Class Initialized
DEBUG - 2011-08-01 00:06:34 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-01 00:06:34 --> Language Class Initialized
DEBUG - 2011-08-01 00:06:34 --> Loader Class Initialized
DEBUG - 2011-08-01 00:06:34 --> Controller Class Initialized
DEBUG - 2011-08-01 00:06:34 --> Model Class Initialized
DEBUG - 2011-08-01 00:06:34 --> Model Class Initialized
DEBUG - 2011-08-01 00:06:34 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-01 00:06:34 --> Database Driver Class Initialized
DEBUG - 2011-08-01 00:06:35 --> Final output sent to browser
DEBUG - 2011-08-01 00:06:35 --> Total execution time: 0.5571
DEBUG - 2011-08-01 00:06:35 --> Config Class Initialized
DEBUG - 2011-08-01 00:06:35 --> Hooks Class Initialized
DEBUG - 2011-08-01 00:06:35 --> Utf8 Class Initialized
DEBUG - 2011-08-01 00:06:35 --> UTF-8 Support Enabled
DEBUG - 2011-08-01 00:06:35 --> URI Class Initialized
DEBUG - 2011-08-01 00:06:35 --> Router Class Initialized
DEBUG - 2011-08-01 00:06:35 --> Output Class Initialized
DEBUG - 2011-08-01 00:06:35 --> Input Class Initialized
DEBUG - 2011-08-01 00:06:35 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-01 00:06:35 --> Language Class Initialized
DEBUG - 2011-08-01 00:06:35 --> Loader Class Initialized
DEBUG - 2011-08-01 00:06:35 --> Controller Class Initialized
ERROR - 2011-08-01 00:06:35 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-01 00:06:35 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-01 00:06:35 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-01 00:06:35 --> Model Class Initialized
DEBUG - 2011-08-01 00:06:35 --> Model Class Initialized
DEBUG - 2011-08-01 00:06:35 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-01 00:06:35 --> Database Driver Class Initialized
DEBUG - 2011-08-01 00:06:35 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-01 00:06:35 --> Helper loaded: url_helper
DEBUG - 2011-08-01 00:06:35 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-01 00:06:35 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-01 00:06:35 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-01 00:06:35 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-01 00:06:35 --> Final output sent to browser
DEBUG - 2011-08-01 00:06:35 --> Total execution time: 0.0306
DEBUG - 2011-08-01 00:06:36 --> Config Class Initialized
DEBUG - 2011-08-01 00:06:36 --> Hooks Class Initialized
DEBUG - 2011-08-01 00:06:36 --> Utf8 Class Initialized
DEBUG - 2011-08-01 00:06:36 --> UTF-8 Support Enabled
DEBUG - 2011-08-01 00:06:36 --> URI Class Initialized
DEBUG - 2011-08-01 00:06:36 --> Router Class Initialized
ERROR - 2011-08-01 00:06:36 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-01 00:56:28 --> Config Class Initialized
DEBUG - 2011-08-01 00:56:28 --> Hooks Class Initialized
DEBUG - 2011-08-01 00:56:28 --> Utf8 Class Initialized
DEBUG - 2011-08-01 00:56:28 --> UTF-8 Support Enabled
DEBUG - 2011-08-01 00:56:28 --> URI Class Initialized
DEBUG - 2011-08-01 00:56:28 --> Router Class Initialized
DEBUG - 2011-08-01 00:56:28 --> Output Class Initialized
DEBUG - 2011-08-01 00:56:28 --> Input Class Initialized
DEBUG - 2011-08-01 00:56:28 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-01 00:56:28 --> Language Class Initialized
DEBUG - 2011-08-01 00:56:28 --> Loader Class Initialized
DEBUG - 2011-08-01 00:56:28 --> Controller Class Initialized
ERROR - 2011-08-01 00:56:28 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-01 00:56:28 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-01 00:56:28 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-01 00:56:28 --> Model Class Initialized
DEBUG - 2011-08-01 00:56:28 --> Model Class Initialized
DEBUG - 2011-08-01 00:56:28 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-01 00:56:28 --> Database Driver Class Initialized
DEBUG - 2011-08-01 00:56:28 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-01 00:56:28 --> Helper loaded: url_helper
DEBUG - 2011-08-01 00:56:28 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-01 00:56:28 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-01 00:56:28 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-01 00:56:28 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-01 00:56:28 --> Final output sent to browser
DEBUG - 2011-08-01 00:56:28 --> Total execution time: 0.0504
DEBUG - 2011-08-01 00:56:28 --> Config Class Initialized
DEBUG - 2011-08-01 00:56:28 --> Hooks Class Initialized
DEBUG - 2011-08-01 00:56:28 --> Utf8 Class Initialized
DEBUG - 2011-08-01 00:56:28 --> UTF-8 Support Enabled
DEBUG - 2011-08-01 00:56:28 --> URI Class Initialized
DEBUG - 2011-08-01 00:56:28 --> Router Class Initialized
DEBUG - 2011-08-01 00:56:28 --> Output Class Initialized
DEBUG - 2011-08-01 00:56:28 --> Input Class Initialized
DEBUG - 2011-08-01 00:56:28 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-01 00:56:28 --> Language Class Initialized
DEBUG - 2011-08-01 00:56:28 --> Loader Class Initialized
DEBUG - 2011-08-01 00:56:28 --> Controller Class Initialized
DEBUG - 2011-08-01 00:56:28 --> Model Class Initialized
DEBUG - 2011-08-01 00:56:28 --> Model Class Initialized
DEBUG - 2011-08-01 00:56:28 --> Model Class Initialized
DEBUG - 2011-08-01 00:56:28 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-01 00:56:28 --> Database Driver Class Initialized
DEBUG - 2011-08-01 00:56:28 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-01 00:56:28 --> Helper loaded: url_helper
DEBUG - 2011-08-01 00:56:28 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-01 00:56:28 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-01 00:56:28 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-01 00:56:28 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-01 00:56:28 --> Final output sent to browser
DEBUG - 2011-08-01 00:56:28 --> Total execution time: 0.5608
DEBUG - 2011-08-01 00:56:29 --> Config Class Initialized
DEBUG - 2011-08-01 00:56:29 --> Hooks Class Initialized
DEBUG - 2011-08-01 00:56:29 --> Utf8 Class Initialized
DEBUG - 2011-08-01 00:56:29 --> UTF-8 Support Enabled
DEBUG - 2011-08-01 00:56:29 --> URI Class Initialized
DEBUG - 2011-08-01 00:56:29 --> Router Class Initialized
ERROR - 2011-08-01 00:56:29 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-01 00:56:32 --> Config Class Initialized
DEBUG - 2011-08-01 00:56:32 --> Hooks Class Initialized
DEBUG - 2011-08-01 00:56:32 --> Utf8 Class Initialized
DEBUG - 2011-08-01 00:56:32 --> UTF-8 Support Enabled
DEBUG - 2011-08-01 00:56:32 --> URI Class Initialized
DEBUG - 2011-08-01 00:56:32 --> Router Class Initialized
DEBUG - 2011-08-01 00:56:32 --> Output Class Initialized
DEBUG - 2011-08-01 00:56:32 --> Input Class Initialized
DEBUG - 2011-08-01 00:56:32 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-01 00:56:32 --> Language Class Initialized
DEBUG - 2011-08-01 00:56:32 --> Loader Class Initialized
DEBUG - 2011-08-01 00:56:32 --> Controller Class Initialized
DEBUG - 2011-08-01 00:56:32 --> Model Class Initialized
DEBUG - 2011-08-01 00:56:32 --> Model Class Initialized
DEBUG - 2011-08-01 00:56:32 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-01 00:56:32 --> Database Driver Class Initialized
DEBUG - 2011-08-01 00:56:32 --> Config Class Initialized
DEBUG - 2011-08-01 00:56:32 --> Hooks Class Initialized
DEBUG - 2011-08-01 00:56:32 --> Utf8 Class Initialized
DEBUG - 2011-08-01 00:56:32 --> UTF-8 Support Enabled
DEBUG - 2011-08-01 00:56:32 --> URI Class Initialized
DEBUG - 2011-08-01 00:56:32 --> Router Class Initialized
ERROR - 2011-08-01 00:56:32 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-01 00:56:33 --> Final output sent to browser
DEBUG - 2011-08-01 00:56:33 --> Total execution time: 0.6617
DEBUG - 2011-08-01 00:56:33 --> Config Class Initialized
DEBUG - 2011-08-01 00:56:33 --> Hooks Class Initialized
DEBUG - 2011-08-01 00:56:33 --> Utf8 Class Initialized
DEBUG - 2011-08-01 00:56:33 --> UTF-8 Support Enabled
DEBUG - 2011-08-01 00:56:33 --> URI Class Initialized
DEBUG - 2011-08-01 00:56:33 --> Router Class Initialized
ERROR - 2011-08-01 00:56:33 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-01 00:56:35 --> Config Class Initialized
DEBUG - 2011-08-01 00:56:35 --> Hooks Class Initialized
DEBUG - 2011-08-01 00:56:35 --> Utf8 Class Initialized
DEBUG - 2011-08-01 00:56:35 --> UTF-8 Support Enabled
DEBUG - 2011-08-01 00:56:35 --> URI Class Initialized
DEBUG - 2011-08-01 00:56:35 --> Router Class Initialized
ERROR - 2011-08-01 00:56:35 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-01 01:07:33 --> Config Class Initialized
DEBUG - 2011-08-01 01:07:33 --> Hooks Class Initialized
DEBUG - 2011-08-01 01:07:33 --> Utf8 Class Initialized
DEBUG - 2011-08-01 01:07:33 --> UTF-8 Support Enabled
DEBUG - 2011-08-01 01:07:33 --> URI Class Initialized
DEBUG - 2011-08-01 01:07:33 --> Router Class Initialized
DEBUG - 2011-08-01 01:07:33 --> Output Class Initialized
DEBUG - 2011-08-01 01:07:33 --> Input Class Initialized
DEBUG - 2011-08-01 01:07:33 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-01 01:07:33 --> Language Class Initialized
DEBUG - 2011-08-01 01:07:33 --> Loader Class Initialized
DEBUG - 2011-08-01 01:07:33 --> Controller Class Initialized
ERROR - 2011-08-01 01:07:33 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-01 01:07:33 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-01 01:07:33 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-01 01:07:33 --> Model Class Initialized
DEBUG - 2011-08-01 01:07:33 --> Model Class Initialized
DEBUG - 2011-08-01 01:07:33 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-01 01:07:33 --> Database Driver Class Initialized
DEBUG - 2011-08-01 01:07:33 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-01 01:07:33 --> Helper loaded: url_helper
DEBUG - 2011-08-01 01:07:33 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-01 01:07:33 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-01 01:07:33 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-01 01:07:33 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-01 01:07:33 --> Final output sent to browser
DEBUG - 2011-08-01 01:07:33 --> Total execution time: 0.1148
DEBUG - 2011-08-01 01:07:36 --> Config Class Initialized
DEBUG - 2011-08-01 01:07:36 --> Hooks Class Initialized
DEBUG - 2011-08-01 01:07:36 --> Utf8 Class Initialized
DEBUG - 2011-08-01 01:07:36 --> UTF-8 Support Enabled
DEBUG - 2011-08-01 01:07:36 --> URI Class Initialized
DEBUG - 2011-08-01 01:07:36 --> Router Class Initialized
DEBUG - 2011-08-01 01:07:36 --> Output Class Initialized
DEBUG - 2011-08-01 01:07:36 --> Input Class Initialized
DEBUG - 2011-08-01 01:07:36 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-01 01:07:36 --> Language Class Initialized
DEBUG - 2011-08-01 01:07:36 --> Loader Class Initialized
DEBUG - 2011-08-01 01:07:36 --> Controller Class Initialized
DEBUG - 2011-08-01 01:07:36 --> Model Class Initialized
DEBUG - 2011-08-01 01:07:36 --> Model Class Initialized
DEBUG - 2011-08-01 01:07:36 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-01 01:07:36 --> Database Driver Class Initialized
DEBUG - 2011-08-01 01:07:36 --> Final output sent to browser
DEBUG - 2011-08-01 01:07:36 --> Total execution time: 0.5672
DEBUG - 2011-08-01 03:03:44 --> Config Class Initialized
DEBUG - 2011-08-01 03:03:44 --> Hooks Class Initialized
DEBUG - 2011-08-01 03:03:44 --> Utf8 Class Initialized
DEBUG - 2011-08-01 03:03:44 --> UTF-8 Support Enabled
DEBUG - 2011-08-01 03:03:44 --> URI Class Initialized
DEBUG - 2011-08-01 03:03:44 --> Router Class Initialized
DEBUG - 2011-08-01 03:03:44 --> Output Class Initialized
DEBUG - 2011-08-01 03:03:44 --> Input Class Initialized
DEBUG - 2011-08-01 03:03:44 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-01 03:03:44 --> Language Class Initialized
DEBUG - 2011-08-01 03:03:44 --> Loader Class Initialized
DEBUG - 2011-08-01 03:03:44 --> Controller Class Initialized
DEBUG - 2011-08-01 03:03:44 --> Model Class Initialized
DEBUG - 2011-08-01 03:03:44 --> Model Class Initialized
DEBUG - 2011-08-01 03:03:44 --> Model Class Initialized
DEBUG - 2011-08-01 03:03:44 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-01 03:03:44 --> Database Driver Class Initialized
DEBUG - 2011-08-01 03:03:48 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-01 03:03:48 --> Helper loaded: url_helper
DEBUG - 2011-08-01 03:03:48 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-01 03:03:48 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-01 03:03:48 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-01 03:03:48 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-01 03:03:48 --> Final output sent to browser
DEBUG - 2011-08-01 03:03:48 --> Total execution time: 3.8085
DEBUG - 2011-08-01 03:03:51 --> Config Class Initialized
DEBUG - 2011-08-01 03:03:51 --> Hooks Class Initialized
DEBUG - 2011-08-01 03:03:51 --> Utf8 Class Initialized
DEBUG - 2011-08-01 03:03:51 --> UTF-8 Support Enabled
DEBUG - 2011-08-01 03:03:51 --> URI Class Initialized
DEBUG - 2011-08-01 03:03:51 --> Router Class Initialized
ERROR - 2011-08-01 03:03:51 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-01 03:04:14 --> Config Class Initialized
DEBUG - 2011-08-01 03:04:14 --> Hooks Class Initialized
DEBUG - 2011-08-01 03:04:14 --> Utf8 Class Initialized
DEBUG - 2011-08-01 03:04:14 --> UTF-8 Support Enabled
DEBUG - 2011-08-01 03:04:14 --> URI Class Initialized
DEBUG - 2011-08-01 03:04:14 --> Router Class Initialized
DEBUG - 2011-08-01 03:04:14 --> Output Class Initialized
DEBUG - 2011-08-01 03:04:14 --> Input Class Initialized
DEBUG - 2011-08-01 03:04:14 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-01 03:04:14 --> Language Class Initialized
DEBUG - 2011-08-01 03:04:14 --> Loader Class Initialized
DEBUG - 2011-08-01 03:04:14 --> Controller Class Initialized
DEBUG - 2011-08-01 03:04:14 --> Model Class Initialized
DEBUG - 2011-08-01 03:04:14 --> Model Class Initialized
DEBUG - 2011-08-01 03:04:14 --> Model Class Initialized
DEBUG - 2011-08-01 03:04:14 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-01 03:04:14 --> Database Driver Class Initialized
DEBUG - 2011-08-01 03:04:17 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-01 03:04:17 --> Helper loaded: url_helper
DEBUG - 2011-08-01 03:04:17 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-01 03:04:17 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-01 03:04:17 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-01 03:04:17 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-01 03:04:17 --> Final output sent to browser
DEBUG - 2011-08-01 03:04:17 --> Total execution time: 2.6807
DEBUG - 2011-08-01 03:04:19 --> Config Class Initialized
DEBUG - 2011-08-01 03:04:19 --> Hooks Class Initialized
DEBUG - 2011-08-01 03:04:19 --> Utf8 Class Initialized
DEBUG - 2011-08-01 03:04:19 --> UTF-8 Support Enabled
DEBUG - 2011-08-01 03:04:19 --> URI Class Initialized
DEBUG - 2011-08-01 03:04:19 --> Router Class Initialized
ERROR - 2011-08-01 03:04:19 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-01 03:04:22 --> Config Class Initialized
DEBUG - 2011-08-01 03:04:22 --> Hooks Class Initialized
DEBUG - 2011-08-01 03:04:22 --> Utf8 Class Initialized
DEBUG - 2011-08-01 03:04:22 --> UTF-8 Support Enabled
DEBUG - 2011-08-01 03:04:22 --> URI Class Initialized
DEBUG - 2011-08-01 03:04:22 --> Router Class Initialized
DEBUG - 2011-08-01 03:04:22 --> Output Class Initialized
DEBUG - 2011-08-01 03:04:22 --> Input Class Initialized
DEBUG - 2011-08-01 03:04:22 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-01 03:04:22 --> Language Class Initialized
DEBUG - 2011-08-01 03:04:22 --> Loader Class Initialized
DEBUG - 2011-08-01 03:04:22 --> Controller Class Initialized
DEBUG - 2011-08-01 03:04:22 --> Model Class Initialized
DEBUG - 2011-08-01 03:04:22 --> Model Class Initialized
DEBUG - 2011-08-01 03:04:22 --> Model Class Initialized
DEBUG - 2011-08-01 03:04:22 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-01 03:04:22 --> Database Driver Class Initialized
DEBUG - 2011-08-01 03:04:22 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-01 03:04:22 --> Helper loaded: url_helper
DEBUG - 2011-08-01 03:04:22 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-01 03:04:22 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-01 03:04:22 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-01 03:04:22 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-01 03:04:22 --> Final output sent to browser
DEBUG - 2011-08-01 03:04:22 --> Total execution time: 0.0476
DEBUG - 2011-08-01 03:04:24 --> Config Class Initialized
DEBUG - 2011-08-01 03:04:24 --> Hooks Class Initialized
DEBUG - 2011-08-01 03:04:24 --> Utf8 Class Initialized
DEBUG - 2011-08-01 03:04:24 --> UTF-8 Support Enabled
DEBUG - 2011-08-01 03:04:24 --> URI Class Initialized
DEBUG - 2011-08-01 03:04:24 --> Router Class Initialized
ERROR - 2011-08-01 03:04:24 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-01 03:27:35 --> Config Class Initialized
DEBUG - 2011-08-01 03:27:35 --> Hooks Class Initialized
DEBUG - 2011-08-01 03:27:35 --> Utf8 Class Initialized
DEBUG - 2011-08-01 03:27:35 --> UTF-8 Support Enabled
DEBUG - 2011-08-01 03:27:35 --> URI Class Initialized
DEBUG - 2011-08-01 03:27:35 --> Router Class Initialized
DEBUG - 2011-08-01 03:27:35 --> Output Class Initialized
DEBUG - 2011-08-01 03:27:35 --> Input Class Initialized
DEBUG - 2011-08-01 03:27:35 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-01 03:27:35 --> Language Class Initialized
DEBUG - 2011-08-01 03:27:35 --> Loader Class Initialized
DEBUG - 2011-08-01 03:27:35 --> Controller Class Initialized
DEBUG - 2011-08-01 03:27:35 --> Model Class Initialized
DEBUG - 2011-08-01 03:27:35 --> Model Class Initialized
DEBUG - 2011-08-01 03:27:35 --> Model Class Initialized
DEBUG - 2011-08-01 03:27:35 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-01 03:27:35 --> Database Driver Class Initialized
DEBUG - 2011-08-01 03:27:36 --> Config Class Initialized
DEBUG - 2011-08-01 03:27:36 --> Hooks Class Initialized
DEBUG - 2011-08-01 03:27:36 --> Utf8 Class Initialized
DEBUG - 2011-08-01 03:27:36 --> UTF-8 Support Enabled
DEBUG - 2011-08-01 03:27:36 --> URI Class Initialized
DEBUG - 2011-08-01 03:27:36 --> Router Class Initialized
DEBUG - 2011-08-01 03:27:36 --> Output Class Initialized
DEBUG - 2011-08-01 03:27:36 --> Input Class Initialized
DEBUG - 2011-08-01 03:27:36 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-01 03:27:36 --> Language Class Initialized
DEBUG - 2011-08-01 03:27:36 --> Loader Class Initialized
DEBUG - 2011-08-01 03:27:36 --> Controller Class Initialized
DEBUG - 2011-08-01 03:27:36 --> Model Class Initialized
DEBUG - 2011-08-01 03:27:36 --> Model Class Initialized
DEBUG - 2011-08-01 03:27:36 --> Model Class Initialized
DEBUG - 2011-08-01 03:27:36 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-01 03:27:36 --> Database Driver Class Initialized
DEBUG - 2011-08-01 03:27:37 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-01 03:27:37 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-01 03:27:37 --> Helper loaded: url_helper
DEBUG - 2011-08-01 03:27:37 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-01 03:27:37 --> Helper loaded: url_helper
DEBUG - 2011-08-01 03:27:37 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-01 03:27:37 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-01 03:27:37 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-01 03:27:37 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-01 03:27:37 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-01 03:27:37 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-01 03:27:37 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-01 03:27:37 --> Final output sent to browser
DEBUG - 2011-08-01 03:27:37 --> Final output sent to browser
DEBUG - 2011-08-01 03:27:37 --> Total execution time: 0.6379
DEBUG - 2011-08-01 03:27:37 --> Total execution time: 2.4665
DEBUG - 2011-08-01 03:27:42 --> Config Class Initialized
DEBUG - 2011-08-01 03:27:42 --> Hooks Class Initialized
DEBUG - 2011-08-01 03:27:42 --> Utf8 Class Initialized
DEBUG - 2011-08-01 03:27:42 --> UTF-8 Support Enabled
DEBUG - 2011-08-01 03:27:42 --> URI Class Initialized
DEBUG - 2011-08-01 03:27:42 --> Router Class Initialized
ERROR - 2011-08-01 03:27:42 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-01 03:27:44 --> Config Class Initialized
DEBUG - 2011-08-01 03:27:44 --> Hooks Class Initialized
DEBUG - 2011-08-01 03:27:44 --> Utf8 Class Initialized
DEBUG - 2011-08-01 03:27:44 --> UTF-8 Support Enabled
DEBUG - 2011-08-01 03:27:44 --> URI Class Initialized
DEBUG - 2011-08-01 03:27:44 --> Router Class Initialized
ERROR - 2011-08-01 03:27:44 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-01 03:27:44 --> Config Class Initialized
DEBUG - 2011-08-01 03:27:44 --> Hooks Class Initialized
DEBUG - 2011-08-01 03:27:44 --> Utf8 Class Initialized
DEBUG - 2011-08-01 03:27:44 --> UTF-8 Support Enabled
DEBUG - 2011-08-01 03:27:44 --> URI Class Initialized
DEBUG - 2011-08-01 03:27:44 --> Router Class Initialized
ERROR - 2011-08-01 03:27:44 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-01 05:47:02 --> Config Class Initialized
DEBUG - 2011-08-01 05:47:02 --> Hooks Class Initialized
DEBUG - 2011-08-01 05:47:02 --> Utf8 Class Initialized
DEBUG - 2011-08-01 05:47:02 --> UTF-8 Support Enabled
DEBUG - 2011-08-01 05:47:02 --> URI Class Initialized
DEBUG - 2011-08-01 05:47:02 --> Router Class Initialized
DEBUG - 2011-08-01 05:47:02 --> No URI present. Default controller set.
DEBUG - 2011-08-01 05:47:02 --> Output Class Initialized
DEBUG - 2011-08-01 05:47:02 --> Input Class Initialized
DEBUG - 2011-08-01 05:47:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-01 05:47:03 --> Language Class Initialized
DEBUG - 2011-08-01 05:47:03 --> Loader Class Initialized
DEBUG - 2011-08-01 05:47:03 --> Controller Class Initialized
DEBUG - 2011-08-01 05:47:03 --> File loaded: application/views/splash/main.php
DEBUG - 2011-08-01 05:47:03 --> Helper loaded: url_helper
DEBUG - 2011-08-01 05:47:03 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-01 05:47:03 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-01 05:47:03 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-01 05:47:03 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-01 05:47:03 --> Final output sent to browser
DEBUG - 2011-08-01 05:47:03 --> Total execution time: 0.2564
DEBUG - 2011-08-01 06:13:15 --> Config Class Initialized
DEBUG - 2011-08-01 06:13:15 --> Hooks Class Initialized
DEBUG - 2011-08-01 06:13:15 --> Utf8 Class Initialized
DEBUG - 2011-08-01 06:13:15 --> UTF-8 Support Enabled
DEBUG - 2011-08-01 06:13:15 --> URI Class Initialized
DEBUG - 2011-08-01 06:13:15 --> Router Class Initialized
DEBUG - 2011-08-01 06:13:15 --> Output Class Initialized
DEBUG - 2011-08-01 06:13:15 --> Input Class Initialized
DEBUG - 2011-08-01 06:13:15 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-01 06:13:15 --> Language Class Initialized
DEBUG - 2011-08-01 06:13:15 --> Loader Class Initialized
DEBUG - 2011-08-01 06:13:15 --> Controller Class Initialized
ERROR - 2011-08-01 06:13:15 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-01 06:13:15 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-01 06:13:15 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-01 06:13:15 --> Model Class Initialized
DEBUG - 2011-08-01 06:13:15 --> Model Class Initialized
DEBUG - 2011-08-01 06:13:15 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-01 06:13:15 --> Database Driver Class Initialized
DEBUG - 2011-08-01 06:13:16 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-01 06:13:16 --> Helper loaded: url_helper
DEBUG - 2011-08-01 06:13:16 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-01 06:13:16 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-01 06:13:16 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-01 06:13:16 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-01 06:13:16 --> Final output sent to browser
DEBUG - 2011-08-01 06:13:16 --> Total execution time: 1.2581
DEBUG - 2011-08-01 06:13:18 --> Config Class Initialized
DEBUG - 2011-08-01 06:13:18 --> Hooks Class Initialized
DEBUG - 2011-08-01 06:13:18 --> Utf8 Class Initialized
DEBUG - 2011-08-01 06:13:18 --> UTF-8 Support Enabled
DEBUG - 2011-08-01 06:13:18 --> URI Class Initialized
DEBUG - 2011-08-01 06:13:18 --> Router Class Initialized
DEBUG - 2011-08-01 06:13:18 --> Output Class Initialized
DEBUG - 2011-08-01 06:13:18 --> Input Class Initialized
DEBUG - 2011-08-01 06:13:18 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-01 06:13:18 --> Language Class Initialized
DEBUG - 2011-08-01 06:13:18 --> Loader Class Initialized
DEBUG - 2011-08-01 06:13:18 --> Controller Class Initialized
DEBUG - 2011-08-01 06:13:18 --> Model Class Initialized
DEBUG - 2011-08-01 06:13:18 --> Model Class Initialized
DEBUG - 2011-08-01 06:13:18 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-01 06:13:18 --> Database Driver Class Initialized
DEBUG - 2011-08-01 06:13:19 --> Final output sent to browser
DEBUG - 2011-08-01 06:13:19 --> Total execution time: 0.7446
DEBUG - 2011-08-01 06:13:20 --> Config Class Initialized
DEBUG - 2011-08-01 06:13:20 --> Hooks Class Initialized
DEBUG - 2011-08-01 06:13:20 --> Utf8 Class Initialized
DEBUG - 2011-08-01 06:13:20 --> UTF-8 Support Enabled
DEBUG - 2011-08-01 06:13:20 --> URI Class Initialized
DEBUG - 2011-08-01 06:13:20 --> Router Class Initialized
ERROR - 2011-08-01 06:13:20 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-01 06:13:59 --> Config Class Initialized
DEBUG - 2011-08-01 06:13:59 --> Hooks Class Initialized
DEBUG - 2011-08-01 06:13:59 --> Utf8 Class Initialized
DEBUG - 2011-08-01 06:13:59 --> UTF-8 Support Enabled
DEBUG - 2011-08-01 06:13:59 --> URI Class Initialized
DEBUG - 2011-08-01 06:13:59 --> Router Class Initialized
DEBUG - 2011-08-01 06:13:59 --> Output Class Initialized
DEBUG - 2011-08-01 06:13:59 --> Input Class Initialized
DEBUG - 2011-08-01 06:13:59 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-01 06:13:59 --> Language Class Initialized
DEBUG - 2011-08-01 06:13:59 --> Loader Class Initialized
DEBUG - 2011-08-01 06:13:59 --> Controller Class Initialized
ERROR - 2011-08-01 06:13:59 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-01 06:13:59 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-01 06:13:59 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-01 06:13:59 --> Model Class Initialized
DEBUG - 2011-08-01 06:13:59 --> Model Class Initialized
DEBUG - 2011-08-01 06:13:59 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-01 06:13:59 --> Database Driver Class Initialized
DEBUG - 2011-08-01 06:13:59 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-01 06:13:59 --> Helper loaded: url_helper
DEBUG - 2011-08-01 06:13:59 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-01 06:13:59 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-01 06:13:59 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-01 06:13:59 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-01 06:13:59 --> Final output sent to browser
DEBUG - 2011-08-01 06:13:59 --> Total execution time: 0.0440
DEBUG - 2011-08-01 06:13:59 --> Config Class Initialized
DEBUG - 2011-08-01 06:13:59 --> Hooks Class Initialized
DEBUG - 2011-08-01 06:13:59 --> Utf8 Class Initialized
DEBUG - 2011-08-01 06:13:59 --> UTF-8 Support Enabled
DEBUG - 2011-08-01 06:13:59 --> URI Class Initialized
DEBUG - 2011-08-01 06:13:59 --> Router Class Initialized
DEBUG - 2011-08-01 06:13:59 --> Output Class Initialized
DEBUG - 2011-08-01 06:13:59 --> Input Class Initialized
DEBUG - 2011-08-01 06:13:59 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-01 06:13:59 --> Language Class Initialized
DEBUG - 2011-08-01 06:13:59 --> Loader Class Initialized
DEBUG - 2011-08-01 06:13:59 --> Controller Class Initialized
DEBUG - 2011-08-01 06:13:59 --> Model Class Initialized
DEBUG - 2011-08-01 06:13:59 --> Model Class Initialized
DEBUG - 2011-08-01 06:13:59 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-01 06:13:59 --> Database Driver Class Initialized
DEBUG - 2011-08-01 06:14:00 --> Final output sent to browser
DEBUG - 2011-08-01 06:14:00 --> Total execution time: 0.6730
DEBUG - 2011-08-01 06:14:02 --> Config Class Initialized
DEBUG - 2011-08-01 06:14:02 --> Hooks Class Initialized
DEBUG - 2011-08-01 06:14:02 --> Utf8 Class Initialized
DEBUG - 2011-08-01 06:14:02 --> UTF-8 Support Enabled
DEBUG - 2011-08-01 06:14:02 --> URI Class Initialized
DEBUG - 2011-08-01 06:14:02 --> Router Class Initialized
ERROR - 2011-08-01 06:14:02 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-01 06:14:04 --> Config Class Initialized
DEBUG - 2011-08-01 06:14:04 --> Hooks Class Initialized
DEBUG - 2011-08-01 06:14:04 --> Utf8 Class Initialized
DEBUG - 2011-08-01 06:14:04 --> UTF-8 Support Enabled
DEBUG - 2011-08-01 06:14:04 --> URI Class Initialized
DEBUG - 2011-08-01 06:14:04 --> Router Class Initialized
DEBUG - 2011-08-01 06:14:04 --> Output Class Initialized
DEBUG - 2011-08-01 06:14:04 --> Input Class Initialized
DEBUG - 2011-08-01 06:14:04 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-01 06:14:04 --> Language Class Initialized
DEBUG - 2011-08-01 06:14:04 --> Loader Class Initialized
DEBUG - 2011-08-01 06:14:04 --> Controller Class Initialized
ERROR - 2011-08-01 06:14:04 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-01 06:14:04 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-01 06:14:04 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-01 06:14:04 --> Model Class Initialized
DEBUG - 2011-08-01 06:14:04 --> Model Class Initialized
DEBUG - 2011-08-01 06:14:04 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-01 06:14:04 --> Database Driver Class Initialized
DEBUG - 2011-08-01 06:14:04 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-01 06:14:04 --> Helper loaded: url_helper
DEBUG - 2011-08-01 06:14:04 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-01 06:14:04 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-01 06:14:04 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-01 06:14:04 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-01 06:14:04 --> Final output sent to browser
DEBUG - 2011-08-01 06:14:04 --> Total execution time: 0.0285
DEBUG - 2011-08-01 06:14:05 --> Config Class Initialized
DEBUG - 2011-08-01 06:14:05 --> Hooks Class Initialized
DEBUG - 2011-08-01 06:14:05 --> Utf8 Class Initialized
DEBUG - 2011-08-01 06:14:05 --> UTF-8 Support Enabled
DEBUG - 2011-08-01 06:14:05 --> URI Class Initialized
DEBUG - 2011-08-01 06:14:05 --> Router Class Initialized
DEBUG - 2011-08-01 06:14:05 --> Output Class Initialized
DEBUG - 2011-08-01 06:14:05 --> Input Class Initialized
DEBUG - 2011-08-01 06:14:05 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-01 06:14:05 --> Language Class Initialized
DEBUG - 2011-08-01 06:14:05 --> Loader Class Initialized
DEBUG - 2011-08-01 06:14:05 --> Controller Class Initialized
DEBUG - 2011-08-01 06:14:05 --> Model Class Initialized
DEBUG - 2011-08-01 06:14:05 --> Model Class Initialized
DEBUG - 2011-08-01 06:14:05 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-01 06:14:05 --> Database Driver Class Initialized
DEBUG - 2011-08-01 06:14:06 --> Config Class Initialized
DEBUG - 2011-08-01 06:14:06 --> Hooks Class Initialized
DEBUG - 2011-08-01 06:14:06 --> Utf8 Class Initialized
DEBUG - 2011-08-01 06:14:06 --> UTF-8 Support Enabled
DEBUG - 2011-08-01 06:14:06 --> URI Class Initialized
DEBUG - 2011-08-01 06:14:06 --> Router Class Initialized
DEBUG - 2011-08-01 06:14:06 --> Output Class Initialized
DEBUG - 2011-08-01 06:14:06 --> Input Class Initialized
DEBUG - 2011-08-01 06:14:06 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-01 06:14:06 --> Language Class Initialized
DEBUG - 2011-08-01 06:14:06 --> Loader Class Initialized
DEBUG - 2011-08-01 06:14:06 --> Controller Class Initialized
ERROR - 2011-08-01 06:14:06 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-01 06:14:06 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-01 06:14:06 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-01 06:14:06 --> Model Class Initialized
DEBUG - 2011-08-01 06:14:06 --> Model Class Initialized
DEBUG - 2011-08-01 06:14:06 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-01 06:14:06 --> Database Driver Class Initialized
DEBUG - 2011-08-01 06:14:06 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-01 06:14:06 --> Helper loaded: url_helper
DEBUG - 2011-08-01 06:14:06 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-01 06:14:06 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-01 06:14:06 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-01 06:14:06 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-01 06:14:06 --> Final output sent to browser
DEBUG - 2011-08-01 06:14:06 --> Total execution time: 0.0415
DEBUG - 2011-08-01 06:14:06 --> Final output sent to browser
DEBUG - 2011-08-01 06:14:06 --> Total execution time: 0.7234
DEBUG - 2011-08-01 06:14:07 --> Config Class Initialized
DEBUG - 2011-08-01 06:14:07 --> Hooks Class Initialized
DEBUG - 2011-08-01 06:14:07 --> Utf8 Class Initialized
DEBUG - 2011-08-01 06:14:07 --> UTF-8 Support Enabled
DEBUG - 2011-08-01 06:14:07 --> URI Class Initialized
DEBUG - 2011-08-01 06:14:07 --> Router Class Initialized
ERROR - 2011-08-01 06:14:07 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-01 06:14:15 --> Config Class Initialized
DEBUG - 2011-08-01 06:14:15 --> Hooks Class Initialized
DEBUG - 2011-08-01 06:14:15 --> Utf8 Class Initialized
DEBUG - 2011-08-01 06:14:15 --> UTF-8 Support Enabled
DEBUG - 2011-08-01 06:14:15 --> URI Class Initialized
DEBUG - 2011-08-01 06:14:15 --> Router Class Initialized
DEBUG - 2011-08-01 06:14:15 --> Output Class Initialized
DEBUG - 2011-08-01 06:14:15 --> Input Class Initialized
DEBUG - 2011-08-01 06:14:15 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-01 06:14:15 --> Language Class Initialized
DEBUG - 2011-08-01 06:14:15 --> Loader Class Initialized
DEBUG - 2011-08-01 06:14:15 --> Controller Class Initialized
ERROR - 2011-08-01 06:14:15 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-01 06:14:15 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-01 06:14:15 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-01 06:14:15 --> Model Class Initialized
DEBUG - 2011-08-01 06:14:15 --> Model Class Initialized
DEBUG - 2011-08-01 06:14:15 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-01 06:14:15 --> Database Driver Class Initialized
DEBUG - 2011-08-01 06:14:15 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-01 06:14:15 --> Helper loaded: url_helper
DEBUG - 2011-08-01 06:14:15 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-01 06:14:15 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-01 06:14:15 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-01 06:14:15 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-01 06:14:15 --> Final output sent to browser
DEBUG - 2011-08-01 06:14:15 --> Total execution time: 0.0298
DEBUG - 2011-08-01 06:14:16 --> Config Class Initialized
DEBUG - 2011-08-01 06:14:16 --> Hooks Class Initialized
DEBUG - 2011-08-01 06:14:16 --> Utf8 Class Initialized
DEBUG - 2011-08-01 06:14:16 --> UTF-8 Support Enabled
DEBUG - 2011-08-01 06:14:16 --> URI Class Initialized
DEBUG - 2011-08-01 06:14:16 --> Router Class Initialized
DEBUG - 2011-08-01 06:14:16 --> Output Class Initialized
DEBUG - 2011-08-01 06:14:16 --> Input Class Initialized
DEBUG - 2011-08-01 06:14:16 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-01 06:14:16 --> Language Class Initialized
DEBUG - 2011-08-01 06:14:16 --> Loader Class Initialized
DEBUG - 2011-08-01 06:14:16 --> Controller Class Initialized
DEBUG - 2011-08-01 06:14:16 --> Model Class Initialized
DEBUG - 2011-08-01 06:14:16 --> Model Class Initialized
DEBUG - 2011-08-01 06:14:16 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-01 06:14:16 --> Database Driver Class Initialized
DEBUG - 2011-08-01 06:14:16 --> Final output sent to browser
DEBUG - 2011-08-01 06:14:16 --> Total execution time: 0.5458
DEBUG - 2011-08-01 06:14:18 --> Config Class Initialized
DEBUG - 2011-08-01 06:14:18 --> Hooks Class Initialized
DEBUG - 2011-08-01 06:14:18 --> Utf8 Class Initialized
DEBUG - 2011-08-01 06:14:18 --> UTF-8 Support Enabled
DEBUG - 2011-08-01 06:14:18 --> URI Class Initialized
DEBUG - 2011-08-01 06:14:18 --> Router Class Initialized
ERROR - 2011-08-01 06:14:18 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-01 06:14:20 --> Config Class Initialized
DEBUG - 2011-08-01 06:14:20 --> Hooks Class Initialized
DEBUG - 2011-08-01 06:14:20 --> Utf8 Class Initialized
DEBUG - 2011-08-01 06:14:20 --> UTF-8 Support Enabled
DEBUG - 2011-08-01 06:14:20 --> URI Class Initialized
DEBUG - 2011-08-01 06:14:20 --> Router Class Initialized
DEBUG - 2011-08-01 06:14:20 --> Output Class Initialized
DEBUG - 2011-08-01 06:14:20 --> Input Class Initialized
DEBUG - 2011-08-01 06:14:20 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-01 06:14:20 --> Language Class Initialized
DEBUG - 2011-08-01 06:14:20 --> Loader Class Initialized
DEBUG - 2011-08-01 06:14:20 --> Controller Class Initialized
ERROR - 2011-08-01 06:14:20 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-01 06:14:20 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-01 06:14:20 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-01 06:14:20 --> Model Class Initialized
DEBUG - 2011-08-01 06:14:20 --> Model Class Initialized
DEBUG - 2011-08-01 06:14:20 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-01 06:14:20 --> Database Driver Class Initialized
DEBUG - 2011-08-01 06:14:20 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-01 06:14:20 --> Helper loaded: url_helper
DEBUG - 2011-08-01 06:14:20 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-01 06:14:20 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-01 06:14:20 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-01 06:14:20 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-01 06:14:20 --> Final output sent to browser
DEBUG - 2011-08-01 06:14:20 --> Total execution time: 0.0617
DEBUG - 2011-08-01 06:14:21 --> Config Class Initialized
DEBUG - 2011-08-01 06:14:21 --> Hooks Class Initialized
DEBUG - 2011-08-01 06:14:21 --> Utf8 Class Initialized
DEBUG - 2011-08-01 06:14:21 --> UTF-8 Support Enabled
DEBUG - 2011-08-01 06:14:21 --> URI Class Initialized
DEBUG - 2011-08-01 06:14:21 --> Router Class Initialized
DEBUG - 2011-08-01 06:14:21 --> Output Class Initialized
DEBUG - 2011-08-01 06:14:21 --> Input Class Initialized
DEBUG - 2011-08-01 06:14:21 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-01 06:14:21 --> Language Class Initialized
DEBUG - 2011-08-01 06:14:21 --> Loader Class Initialized
DEBUG - 2011-08-01 06:14:21 --> Controller Class Initialized
DEBUG - 2011-08-01 06:14:21 --> Model Class Initialized
DEBUG - 2011-08-01 06:14:21 --> Model Class Initialized
DEBUG - 2011-08-01 06:14:21 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-01 06:14:21 --> Database Driver Class Initialized
DEBUG - 2011-08-01 06:14:21 --> Config Class Initialized
DEBUG - 2011-08-01 06:14:21 --> Hooks Class Initialized
DEBUG - 2011-08-01 06:14:21 --> Utf8 Class Initialized
DEBUG - 2011-08-01 06:14:21 --> UTF-8 Support Enabled
DEBUG - 2011-08-01 06:14:21 --> URI Class Initialized
DEBUG - 2011-08-01 06:14:21 --> Router Class Initialized
DEBUG - 2011-08-01 06:14:21 --> Output Class Initialized
DEBUG - 2011-08-01 06:14:21 --> Input Class Initialized
DEBUG - 2011-08-01 06:14:21 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-01 06:14:21 --> Final output sent to browser
DEBUG - 2011-08-01 06:14:21 --> Total execution time: 0.7783
DEBUG - 2011-08-01 06:14:21 --> Language Class Initialized
DEBUG - 2011-08-01 06:14:21 --> Loader Class Initialized
DEBUG - 2011-08-01 06:14:21 --> Controller Class Initialized
ERROR - 2011-08-01 06:14:21 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-01 06:14:21 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-01 06:14:21 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-01 06:14:21 --> Model Class Initialized
DEBUG - 2011-08-01 06:14:21 --> Model Class Initialized
DEBUG - 2011-08-01 06:14:21 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-01 06:14:21 --> Database Driver Class Initialized
DEBUG - 2011-08-01 06:14:21 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-01 06:14:21 --> Helper loaded: url_helper
DEBUG - 2011-08-01 06:14:21 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-01 06:14:21 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-01 06:14:21 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-01 06:14:21 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-01 06:14:21 --> Final output sent to browser
DEBUG - 2011-08-01 06:14:21 --> Total execution time: 0.0815
DEBUG - 2011-08-01 06:14:23 --> Config Class Initialized
DEBUG - 2011-08-01 06:14:23 --> Hooks Class Initialized
DEBUG - 2011-08-01 06:14:23 --> Utf8 Class Initialized
DEBUG - 2011-08-01 06:14:23 --> UTF-8 Support Enabled
DEBUG - 2011-08-01 06:14:23 --> URI Class Initialized
DEBUG - 2011-08-01 06:14:23 --> Router Class Initialized
ERROR - 2011-08-01 06:14:23 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-01 06:14:29 --> Config Class Initialized
DEBUG - 2011-08-01 06:14:29 --> Hooks Class Initialized
DEBUG - 2011-08-01 06:14:29 --> Utf8 Class Initialized
DEBUG - 2011-08-01 06:14:29 --> UTF-8 Support Enabled
DEBUG - 2011-08-01 06:14:29 --> URI Class Initialized
DEBUG - 2011-08-01 06:14:29 --> Router Class Initialized
DEBUG - 2011-08-01 06:14:29 --> Output Class Initialized
DEBUG - 2011-08-01 06:14:29 --> Input Class Initialized
DEBUG - 2011-08-01 06:14:29 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-01 06:14:29 --> Language Class Initialized
DEBUG - 2011-08-01 06:14:29 --> Loader Class Initialized
DEBUG - 2011-08-01 06:14:29 --> Controller Class Initialized
ERROR - 2011-08-01 06:14:29 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-01 06:14:29 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-01 06:14:29 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-01 06:14:29 --> Model Class Initialized
DEBUG - 2011-08-01 06:14:29 --> Model Class Initialized
DEBUG - 2011-08-01 06:14:29 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-01 06:14:29 --> Database Driver Class Initialized
DEBUG - 2011-08-01 06:14:29 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-01 06:14:29 --> Helper loaded: url_helper
DEBUG - 2011-08-01 06:14:29 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-01 06:14:29 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-01 06:14:29 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-01 06:14:29 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-01 06:14:29 --> Final output sent to browser
DEBUG - 2011-08-01 06:14:29 --> Total execution time: 0.0313
DEBUG - 2011-08-01 06:14:30 --> Config Class Initialized
DEBUG - 2011-08-01 06:14:30 --> Hooks Class Initialized
DEBUG - 2011-08-01 06:14:30 --> Utf8 Class Initialized
DEBUG - 2011-08-01 06:14:30 --> UTF-8 Support Enabled
DEBUG - 2011-08-01 06:14:30 --> URI Class Initialized
DEBUG - 2011-08-01 06:14:30 --> Router Class Initialized
DEBUG - 2011-08-01 06:14:30 --> Output Class Initialized
DEBUG - 2011-08-01 06:14:30 --> Input Class Initialized
DEBUG - 2011-08-01 06:14:30 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-01 06:14:30 --> Language Class Initialized
DEBUG - 2011-08-01 06:14:30 --> Loader Class Initialized
DEBUG - 2011-08-01 06:14:30 --> Controller Class Initialized
DEBUG - 2011-08-01 06:14:30 --> Model Class Initialized
DEBUG - 2011-08-01 06:14:30 --> Model Class Initialized
DEBUG - 2011-08-01 06:14:30 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-01 06:14:30 --> Database Driver Class Initialized
DEBUG - 2011-08-01 06:14:31 --> Final output sent to browser
DEBUG - 2011-08-01 06:14:31 --> Total execution time: 0.5988
DEBUG - 2011-08-01 06:14:32 --> Config Class Initialized
DEBUG - 2011-08-01 06:14:32 --> Hooks Class Initialized
DEBUG - 2011-08-01 06:14:32 --> Utf8 Class Initialized
DEBUG - 2011-08-01 06:14:32 --> UTF-8 Support Enabled
DEBUG - 2011-08-01 06:14:32 --> URI Class Initialized
DEBUG - 2011-08-01 06:14:32 --> Router Class Initialized
ERROR - 2011-08-01 06:14:32 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-01 06:14:40 --> Config Class Initialized
DEBUG - 2011-08-01 06:14:40 --> Hooks Class Initialized
DEBUG - 2011-08-01 06:14:40 --> Utf8 Class Initialized
DEBUG - 2011-08-01 06:14:40 --> UTF-8 Support Enabled
DEBUG - 2011-08-01 06:14:40 --> URI Class Initialized
DEBUG - 2011-08-01 06:14:40 --> Router Class Initialized
DEBUG - 2011-08-01 06:14:40 --> Output Class Initialized
DEBUG - 2011-08-01 06:14:40 --> Input Class Initialized
DEBUG - 2011-08-01 06:14:40 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-01 06:14:40 --> Language Class Initialized
DEBUG - 2011-08-01 06:14:40 --> Loader Class Initialized
DEBUG - 2011-08-01 06:14:40 --> Controller Class Initialized
ERROR - 2011-08-01 06:14:40 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-01 06:14:40 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-01 06:14:40 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-01 06:14:40 --> Model Class Initialized
DEBUG - 2011-08-01 06:14:40 --> Model Class Initialized
DEBUG - 2011-08-01 06:14:40 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-01 06:14:40 --> Database Driver Class Initialized
DEBUG - 2011-08-01 06:14:40 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-01 06:14:40 --> Helper loaded: url_helper
DEBUG - 2011-08-01 06:14:40 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-01 06:14:40 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-01 06:14:40 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-01 06:14:40 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-01 06:14:40 --> Final output sent to browser
DEBUG - 2011-08-01 06:14:40 --> Total execution time: 0.0344
DEBUG - 2011-08-01 06:14:40 --> Config Class Initialized
DEBUG - 2011-08-01 06:14:40 --> Hooks Class Initialized
DEBUG - 2011-08-01 06:14:40 --> Utf8 Class Initialized
DEBUG - 2011-08-01 06:14:40 --> UTF-8 Support Enabled
DEBUG - 2011-08-01 06:14:40 --> URI Class Initialized
DEBUG - 2011-08-01 06:14:40 --> Router Class Initialized
DEBUG - 2011-08-01 06:14:40 --> Output Class Initialized
DEBUG - 2011-08-01 06:14:40 --> Input Class Initialized
DEBUG - 2011-08-01 06:14:40 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-01 06:14:40 --> Language Class Initialized
DEBUG - 2011-08-01 06:14:40 --> Loader Class Initialized
DEBUG - 2011-08-01 06:14:40 --> Controller Class Initialized
DEBUG - 2011-08-01 06:14:40 --> Model Class Initialized
DEBUG - 2011-08-01 06:14:40 --> Model Class Initialized
DEBUG - 2011-08-01 06:14:40 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-01 06:14:40 --> Database Driver Class Initialized
DEBUG - 2011-08-01 06:14:41 --> Final output sent to browser
DEBUG - 2011-08-01 06:14:41 --> Total execution time: 0.8222
DEBUG - 2011-08-01 06:14:43 --> Config Class Initialized
DEBUG - 2011-08-01 06:14:43 --> Hooks Class Initialized
DEBUG - 2011-08-01 06:14:43 --> Utf8 Class Initialized
DEBUG - 2011-08-01 06:14:43 --> UTF-8 Support Enabled
DEBUG - 2011-08-01 06:14:43 --> URI Class Initialized
DEBUG - 2011-08-01 06:14:43 --> Router Class Initialized
ERROR - 2011-08-01 06:14:43 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-01 06:14:51 --> Config Class Initialized
DEBUG - 2011-08-01 06:14:51 --> Hooks Class Initialized
DEBUG - 2011-08-01 06:14:51 --> Utf8 Class Initialized
DEBUG - 2011-08-01 06:14:51 --> UTF-8 Support Enabled
DEBUG - 2011-08-01 06:14:51 --> URI Class Initialized
DEBUG - 2011-08-01 06:14:51 --> Router Class Initialized
DEBUG - 2011-08-01 06:14:51 --> Output Class Initialized
DEBUG - 2011-08-01 06:14:51 --> Input Class Initialized
DEBUG - 2011-08-01 06:14:51 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-01 06:14:51 --> Language Class Initialized
DEBUG - 2011-08-01 06:14:51 --> Loader Class Initialized
DEBUG - 2011-08-01 06:14:51 --> Controller Class Initialized
ERROR - 2011-08-01 06:14:51 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-01 06:14:51 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-01 06:14:51 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-01 06:14:51 --> Model Class Initialized
DEBUG - 2011-08-01 06:14:51 --> Model Class Initialized
DEBUG - 2011-08-01 06:14:51 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-01 06:14:51 --> Database Driver Class Initialized
DEBUG - 2011-08-01 06:14:51 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-01 06:14:51 --> Helper loaded: url_helper
DEBUG - 2011-08-01 06:14:51 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-01 06:14:51 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-01 06:14:51 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-01 06:14:51 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-01 06:14:51 --> Final output sent to browser
DEBUG - 2011-08-01 06:14:51 --> Total execution time: 0.0304
DEBUG - 2011-08-01 06:14:52 --> Config Class Initialized
DEBUG - 2011-08-01 06:14:52 --> Hooks Class Initialized
DEBUG - 2011-08-01 06:14:52 --> Utf8 Class Initialized
DEBUG - 2011-08-01 06:14:52 --> UTF-8 Support Enabled
DEBUG - 2011-08-01 06:14:52 --> URI Class Initialized
DEBUG - 2011-08-01 06:14:52 --> Router Class Initialized
DEBUG - 2011-08-01 06:14:52 --> Output Class Initialized
DEBUG - 2011-08-01 06:14:52 --> Input Class Initialized
DEBUG - 2011-08-01 06:14:52 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-01 06:14:52 --> Language Class Initialized
DEBUG - 2011-08-01 06:14:52 --> Loader Class Initialized
DEBUG - 2011-08-01 06:14:52 --> Controller Class Initialized
DEBUG - 2011-08-01 06:14:52 --> Model Class Initialized
DEBUG - 2011-08-01 06:14:52 --> Model Class Initialized
DEBUG - 2011-08-01 06:14:52 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-01 06:14:52 --> Database Driver Class Initialized
DEBUG - 2011-08-01 06:14:52 --> Final output sent to browser
DEBUG - 2011-08-01 06:14:52 --> Total execution time: 0.4945
DEBUG - 2011-08-01 06:14:54 --> Config Class Initialized
DEBUG - 2011-08-01 06:14:54 --> Hooks Class Initialized
DEBUG - 2011-08-01 06:14:54 --> Utf8 Class Initialized
DEBUG - 2011-08-01 06:14:54 --> UTF-8 Support Enabled
DEBUG - 2011-08-01 06:14:54 --> URI Class Initialized
DEBUG - 2011-08-01 06:14:54 --> Router Class Initialized
ERROR - 2011-08-01 06:14:54 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-01 06:14:58 --> Config Class Initialized
DEBUG - 2011-08-01 06:14:58 --> Hooks Class Initialized
DEBUG - 2011-08-01 06:14:58 --> Utf8 Class Initialized
DEBUG - 2011-08-01 06:14:58 --> UTF-8 Support Enabled
DEBUG - 2011-08-01 06:14:58 --> URI Class Initialized
DEBUG - 2011-08-01 06:14:58 --> Router Class Initialized
DEBUG - 2011-08-01 06:14:58 --> Output Class Initialized
DEBUG - 2011-08-01 06:14:58 --> Input Class Initialized
DEBUG - 2011-08-01 06:14:58 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-01 06:14:58 --> Language Class Initialized
DEBUG - 2011-08-01 06:14:58 --> Loader Class Initialized
DEBUG - 2011-08-01 06:14:58 --> Controller Class Initialized
ERROR - 2011-08-01 06:14:58 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-01 06:14:58 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-01 06:14:58 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-01 06:14:58 --> Model Class Initialized
DEBUG - 2011-08-01 06:14:58 --> Model Class Initialized
DEBUG - 2011-08-01 06:14:58 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-01 06:14:58 --> Database Driver Class Initialized
DEBUG - 2011-08-01 06:14:58 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-01 06:14:58 --> Helper loaded: url_helper
DEBUG - 2011-08-01 06:14:58 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-01 06:14:58 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-01 06:14:58 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-01 06:14:58 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-01 06:14:58 --> Final output sent to browser
DEBUG - 2011-08-01 06:14:58 --> Total execution time: 0.0353
DEBUG - 2011-08-01 06:14:59 --> Config Class Initialized
DEBUG - 2011-08-01 06:14:59 --> Hooks Class Initialized
DEBUG - 2011-08-01 06:14:59 --> Utf8 Class Initialized
DEBUG - 2011-08-01 06:14:59 --> UTF-8 Support Enabled
DEBUG - 2011-08-01 06:14:59 --> URI Class Initialized
DEBUG - 2011-08-01 06:14:59 --> Router Class Initialized
DEBUG - 2011-08-01 06:14:59 --> Output Class Initialized
DEBUG - 2011-08-01 06:14:59 --> Input Class Initialized
DEBUG - 2011-08-01 06:14:59 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-01 06:14:59 --> Language Class Initialized
DEBUG - 2011-08-01 06:14:59 --> Loader Class Initialized
DEBUG - 2011-08-01 06:14:59 --> Controller Class Initialized
DEBUG - 2011-08-01 06:14:59 --> Model Class Initialized
DEBUG - 2011-08-01 06:14:59 --> Model Class Initialized
DEBUG - 2011-08-01 06:14:59 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-01 06:14:59 --> Database Driver Class Initialized
DEBUG - 2011-08-01 06:14:59 --> Final output sent to browser
DEBUG - 2011-08-01 06:14:59 --> Total execution time: 0.6140
DEBUG - 2011-08-01 06:15:01 --> Config Class Initialized
DEBUG - 2011-08-01 06:15:01 --> Hooks Class Initialized
DEBUG - 2011-08-01 06:15:01 --> Utf8 Class Initialized
DEBUG - 2011-08-01 06:15:01 --> UTF-8 Support Enabled
DEBUG - 2011-08-01 06:15:01 --> URI Class Initialized
DEBUG - 2011-08-01 06:15:01 --> Router Class Initialized
ERROR - 2011-08-01 06:15:01 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-01 06:15:07 --> Config Class Initialized
DEBUG - 2011-08-01 06:15:07 --> Hooks Class Initialized
DEBUG - 2011-08-01 06:15:07 --> Utf8 Class Initialized
DEBUG - 2011-08-01 06:15:07 --> UTF-8 Support Enabled
DEBUG - 2011-08-01 06:15:07 --> URI Class Initialized
DEBUG - 2011-08-01 06:15:07 --> Router Class Initialized
DEBUG - 2011-08-01 06:15:07 --> Output Class Initialized
DEBUG - 2011-08-01 06:15:07 --> Input Class Initialized
DEBUG - 2011-08-01 06:15:07 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-01 06:15:07 --> Language Class Initialized
DEBUG - 2011-08-01 06:15:07 --> Loader Class Initialized
DEBUG - 2011-08-01 06:15:07 --> Controller Class Initialized
ERROR - 2011-08-01 06:15:07 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-01 06:15:07 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-01 06:15:07 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-01 06:15:07 --> Model Class Initialized
DEBUG - 2011-08-01 06:15:07 --> Model Class Initialized
DEBUG - 2011-08-01 06:15:07 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-01 06:15:07 --> Database Driver Class Initialized
DEBUG - 2011-08-01 06:15:07 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-01 06:15:07 --> Helper loaded: url_helper
DEBUG - 2011-08-01 06:15:07 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-01 06:15:07 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-01 06:15:07 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-01 06:15:07 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-01 06:15:07 --> Final output sent to browser
DEBUG - 2011-08-01 06:15:07 --> Total execution time: 0.0837
DEBUG - 2011-08-01 06:15:09 --> Config Class Initialized
DEBUG - 2011-08-01 06:15:09 --> Hooks Class Initialized
DEBUG - 2011-08-01 06:15:09 --> Utf8 Class Initialized
DEBUG - 2011-08-01 06:15:09 --> UTF-8 Support Enabled
DEBUG - 2011-08-01 06:15:09 --> URI Class Initialized
DEBUG - 2011-08-01 06:15:09 --> Router Class Initialized
DEBUG - 2011-08-01 06:15:09 --> Output Class Initialized
DEBUG - 2011-08-01 06:15:09 --> Input Class Initialized
DEBUG - 2011-08-01 06:15:09 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-01 06:15:09 --> Language Class Initialized
DEBUG - 2011-08-01 06:15:09 --> Loader Class Initialized
DEBUG - 2011-08-01 06:15:09 --> Controller Class Initialized
DEBUG - 2011-08-01 06:15:09 --> Model Class Initialized
DEBUG - 2011-08-01 06:15:09 --> Model Class Initialized
DEBUG - 2011-08-01 06:15:09 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-01 06:15:09 --> Database Driver Class Initialized
DEBUG - 2011-08-01 06:15:10 --> Final output sent to browser
DEBUG - 2011-08-01 06:15:10 --> Total execution time: 1.0512
DEBUG - 2011-08-01 06:15:11 --> Config Class Initialized
DEBUG - 2011-08-01 06:15:11 --> Hooks Class Initialized
DEBUG - 2011-08-01 06:15:11 --> Utf8 Class Initialized
DEBUG - 2011-08-01 06:15:11 --> UTF-8 Support Enabled
DEBUG - 2011-08-01 06:15:11 --> URI Class Initialized
DEBUG - 2011-08-01 06:15:11 --> Router Class Initialized
ERROR - 2011-08-01 06:15:11 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-01 06:56:29 --> Config Class Initialized
DEBUG - 2011-08-01 06:56:29 --> Hooks Class Initialized
DEBUG - 2011-08-01 06:56:29 --> Utf8 Class Initialized
DEBUG - 2011-08-01 06:56:29 --> UTF-8 Support Enabled
DEBUG - 2011-08-01 06:56:29 --> URI Class Initialized
DEBUG - 2011-08-01 06:56:29 --> Router Class Initialized
DEBUG - 2011-08-01 06:56:29 --> Output Class Initialized
DEBUG - 2011-08-01 06:56:29 --> Input Class Initialized
DEBUG - 2011-08-01 06:56:29 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-01 06:56:29 --> Language Class Initialized
DEBUG - 2011-08-01 06:56:29 --> Loader Class Initialized
DEBUG - 2011-08-01 06:56:29 --> Controller Class Initialized
DEBUG - 2011-08-01 06:56:29 --> Model Class Initialized
DEBUG - 2011-08-01 06:56:29 --> Model Class Initialized
DEBUG - 2011-08-01 06:56:29 --> Model Class Initialized
DEBUG - 2011-08-01 06:56:29 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-01 06:56:29 --> Database Driver Class Initialized
DEBUG - 2011-08-01 06:56:30 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-01 06:56:30 --> Helper loaded: url_helper
DEBUG - 2011-08-01 06:56:30 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-01 06:56:30 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-01 06:56:30 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-01 06:56:30 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-01 06:56:30 --> Final output sent to browser
DEBUG - 2011-08-01 06:56:30 --> Total execution time: 0.8562
DEBUG - 2011-08-01 06:56:41 --> Config Class Initialized
DEBUG - 2011-08-01 06:56:41 --> Hooks Class Initialized
DEBUG - 2011-08-01 06:56:41 --> Utf8 Class Initialized
DEBUG - 2011-08-01 06:56:41 --> UTF-8 Support Enabled
DEBUG - 2011-08-01 06:56:41 --> URI Class Initialized
DEBUG - 2011-08-01 06:56:41 --> Router Class Initialized
ERROR - 2011-08-01 06:56:41 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-01 07:08:58 --> Config Class Initialized
DEBUG - 2011-08-01 07:08:58 --> Hooks Class Initialized
DEBUG - 2011-08-01 07:08:58 --> Utf8 Class Initialized
DEBUG - 2011-08-01 07:08:58 --> UTF-8 Support Enabled
DEBUG - 2011-08-01 07:08:58 --> URI Class Initialized
DEBUG - 2011-08-01 07:08:58 --> Router Class Initialized
DEBUG - 2011-08-01 07:08:58 --> Output Class Initialized
DEBUG - 2011-08-01 07:08:58 --> Input Class Initialized
DEBUG - 2011-08-01 07:08:58 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-01 07:08:58 --> Language Class Initialized
DEBUG - 2011-08-01 07:08:58 --> Loader Class Initialized
DEBUG - 2011-08-01 07:08:58 --> Controller Class Initialized
DEBUG - 2011-08-01 07:08:58 --> Model Class Initialized
DEBUG - 2011-08-01 07:08:58 --> Model Class Initialized
DEBUG - 2011-08-01 07:08:58 --> Model Class Initialized
DEBUG - 2011-08-01 07:08:58 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-01 07:08:58 --> Database Driver Class Initialized
DEBUG - 2011-08-01 07:08:58 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-01 07:08:58 --> Helper loaded: url_helper
DEBUG - 2011-08-01 07:08:58 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-01 07:08:58 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-01 07:08:58 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-01 07:08:58 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-01 07:08:58 --> Final output sent to browser
DEBUG - 2011-08-01 07:08:58 --> Total execution time: 0.2531
DEBUG - 2011-08-01 07:09:03 --> Config Class Initialized
DEBUG - 2011-08-01 07:09:03 --> Hooks Class Initialized
DEBUG - 2011-08-01 07:09:03 --> Utf8 Class Initialized
DEBUG - 2011-08-01 07:09:03 --> UTF-8 Support Enabled
DEBUG - 2011-08-01 07:09:03 --> URI Class Initialized
DEBUG - 2011-08-01 07:09:03 --> Router Class Initialized
ERROR - 2011-08-01 07:09:03 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-01 07:09:17 --> Config Class Initialized
DEBUG - 2011-08-01 07:09:17 --> Hooks Class Initialized
DEBUG - 2011-08-01 07:09:17 --> Utf8 Class Initialized
DEBUG - 2011-08-01 07:09:17 --> UTF-8 Support Enabled
DEBUG - 2011-08-01 07:09:17 --> URI Class Initialized
DEBUG - 2011-08-01 07:09:17 --> Router Class Initialized
DEBUG - 2011-08-01 07:09:17 --> Output Class Initialized
DEBUG - 2011-08-01 07:09:17 --> Input Class Initialized
DEBUG - 2011-08-01 07:09:17 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-01 07:09:17 --> Language Class Initialized
DEBUG - 2011-08-01 07:09:17 --> Loader Class Initialized
DEBUG - 2011-08-01 07:09:17 --> Controller Class Initialized
DEBUG - 2011-08-01 07:09:17 --> Model Class Initialized
DEBUG - 2011-08-01 07:09:17 --> Model Class Initialized
DEBUG - 2011-08-01 07:09:17 --> Model Class Initialized
DEBUG - 2011-08-01 07:09:17 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-01 07:09:17 --> Database Driver Class Initialized
DEBUG - 2011-08-01 07:09:17 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-01 07:09:17 --> Helper loaded: url_helper
DEBUG - 2011-08-01 07:09:17 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-01 07:09:17 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-01 07:09:17 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-01 07:09:17 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-01 07:09:17 --> Final output sent to browser
DEBUG - 2011-08-01 07:09:17 --> Total execution time: 0.3248
DEBUG - 2011-08-01 07:09:21 --> Config Class Initialized
DEBUG - 2011-08-01 07:09:21 --> Hooks Class Initialized
DEBUG - 2011-08-01 07:09:21 --> Utf8 Class Initialized
DEBUG - 2011-08-01 07:09:21 --> UTF-8 Support Enabled
DEBUG - 2011-08-01 07:09:21 --> URI Class Initialized
DEBUG - 2011-08-01 07:09:22 --> Router Class Initialized
ERROR - 2011-08-01 07:09:22 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-01 07:10:06 --> Config Class Initialized
DEBUG - 2011-08-01 07:10:06 --> Hooks Class Initialized
DEBUG - 2011-08-01 07:10:06 --> Utf8 Class Initialized
DEBUG - 2011-08-01 07:10:06 --> UTF-8 Support Enabled
DEBUG - 2011-08-01 07:10:06 --> URI Class Initialized
DEBUG - 2011-08-01 07:10:06 --> Router Class Initialized
DEBUG - 2011-08-01 07:10:06 --> Output Class Initialized
DEBUG - 2011-08-01 07:10:06 --> Input Class Initialized
DEBUG - 2011-08-01 07:10:06 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-01 07:10:06 --> Language Class Initialized
DEBUG - 2011-08-01 07:10:06 --> Loader Class Initialized
DEBUG - 2011-08-01 07:10:06 --> Controller Class Initialized
DEBUG - 2011-08-01 07:10:06 --> Model Class Initialized
DEBUG - 2011-08-01 07:10:06 --> Model Class Initialized
DEBUG - 2011-08-01 07:10:06 --> Model Class Initialized
DEBUG - 2011-08-01 07:10:06 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-01 07:10:06 --> Database Driver Class Initialized
DEBUG - 2011-08-01 07:10:06 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-01 07:10:06 --> Helper loaded: url_helper
DEBUG - 2011-08-01 07:10:06 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-01 07:10:06 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-01 07:10:06 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-01 07:10:06 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-01 07:10:06 --> Final output sent to browser
DEBUG - 2011-08-01 07:10:06 --> Total execution time: 0.0525
DEBUG - 2011-08-01 07:10:14 --> Config Class Initialized
DEBUG - 2011-08-01 07:10:14 --> Hooks Class Initialized
DEBUG - 2011-08-01 07:10:14 --> Utf8 Class Initialized
DEBUG - 2011-08-01 07:10:14 --> UTF-8 Support Enabled
DEBUG - 2011-08-01 07:10:14 --> URI Class Initialized
DEBUG - 2011-08-01 07:10:14 --> Router Class Initialized
DEBUG - 2011-08-01 07:10:14 --> Output Class Initialized
DEBUG - 2011-08-01 07:10:14 --> Input Class Initialized
DEBUG - 2011-08-01 07:10:14 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-01 07:10:14 --> Language Class Initialized
DEBUG - 2011-08-01 07:10:14 --> Loader Class Initialized
DEBUG - 2011-08-01 07:10:14 --> Controller Class Initialized
DEBUG - 2011-08-01 07:10:14 --> Model Class Initialized
DEBUG - 2011-08-01 07:10:14 --> Model Class Initialized
DEBUG - 2011-08-01 07:10:14 --> Model Class Initialized
DEBUG - 2011-08-01 07:10:14 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-01 07:10:14 --> Database Driver Class Initialized
DEBUG - 2011-08-01 07:10:14 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-01 07:10:14 --> Helper loaded: url_helper
DEBUG - 2011-08-01 07:10:14 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-01 07:10:14 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-01 07:10:14 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-01 07:10:14 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-01 07:10:14 --> Final output sent to browser
DEBUG - 2011-08-01 07:10:14 --> Total execution time: 0.0512
DEBUG - 2011-08-01 07:29:16 --> Config Class Initialized
DEBUG - 2011-08-01 07:29:16 --> Hooks Class Initialized
DEBUG - 2011-08-01 07:29:16 --> Utf8 Class Initialized
DEBUG - 2011-08-01 07:29:16 --> UTF-8 Support Enabled
DEBUG - 2011-08-01 07:29:16 --> URI Class Initialized
DEBUG - 2011-08-01 07:29:16 --> Router Class Initialized
DEBUG - 2011-08-01 07:29:16 --> Output Class Initialized
DEBUG - 2011-08-01 07:29:16 --> Input Class Initialized
DEBUG - 2011-08-01 07:29:16 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-01 07:29:16 --> Language Class Initialized
DEBUG - 2011-08-01 07:29:16 --> Loader Class Initialized
DEBUG - 2011-08-01 07:29:16 --> Controller Class Initialized
ERROR - 2011-08-01 07:29:16 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-01 07:29:16 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-01 07:29:16 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-01 07:29:16 --> Model Class Initialized
DEBUG - 2011-08-01 07:29:16 --> Model Class Initialized
DEBUG - 2011-08-01 07:29:16 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-01 07:29:16 --> Database Driver Class Initialized
DEBUG - 2011-08-01 07:29:16 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-01 07:29:16 --> Helper loaded: url_helper
DEBUG - 2011-08-01 07:29:16 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-01 07:29:16 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-01 07:29:16 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-01 07:29:16 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-01 07:29:16 --> Final output sent to browser
DEBUG - 2011-08-01 07:29:16 --> Total execution time: 0.1273
DEBUG - 2011-08-01 07:29:18 --> Config Class Initialized
DEBUG - 2011-08-01 07:29:18 --> Hooks Class Initialized
DEBUG - 2011-08-01 07:29:18 --> Utf8 Class Initialized
DEBUG - 2011-08-01 07:29:18 --> UTF-8 Support Enabled
DEBUG - 2011-08-01 07:29:18 --> URI Class Initialized
DEBUG - 2011-08-01 07:29:18 --> Router Class Initialized
DEBUG - 2011-08-01 07:29:18 --> Output Class Initialized
DEBUG - 2011-08-01 07:29:18 --> Input Class Initialized
DEBUG - 2011-08-01 07:29:18 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-01 07:29:18 --> Language Class Initialized
DEBUG - 2011-08-01 07:29:18 --> Loader Class Initialized
DEBUG - 2011-08-01 07:29:18 --> Controller Class Initialized
DEBUG - 2011-08-01 07:29:18 --> Model Class Initialized
DEBUG - 2011-08-01 07:29:18 --> Model Class Initialized
DEBUG - 2011-08-01 07:29:18 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-01 07:29:18 --> Database Driver Class Initialized
DEBUG - 2011-08-01 07:29:19 --> Final output sent to browser
DEBUG - 2011-08-01 07:29:19 --> Total execution time: 0.8036
DEBUG - 2011-08-01 07:29:19 --> Config Class Initialized
DEBUG - 2011-08-01 07:29:19 --> Hooks Class Initialized
DEBUG - 2011-08-01 07:29:19 --> Utf8 Class Initialized
DEBUG - 2011-08-01 07:29:19 --> UTF-8 Support Enabled
DEBUG - 2011-08-01 07:29:19 --> URI Class Initialized
DEBUG - 2011-08-01 07:29:19 --> Router Class Initialized
DEBUG - 2011-08-01 07:29:19 --> Output Class Initialized
DEBUG - 2011-08-01 07:29:19 --> Input Class Initialized
DEBUG - 2011-08-01 07:29:19 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-01 07:29:19 --> Language Class Initialized
DEBUG - 2011-08-01 07:29:19 --> Loader Class Initialized
DEBUG - 2011-08-01 07:29:19 --> Controller Class Initialized
DEBUG - 2011-08-01 07:29:19 --> Model Class Initialized
DEBUG - 2011-08-01 07:29:19 --> Model Class Initialized
DEBUG - 2011-08-01 07:29:19 --> Model Class Initialized
DEBUG - 2011-08-01 07:29:19 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-01 07:29:19 --> Database Driver Class Initialized
DEBUG - 2011-08-01 07:29:20 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-01 07:29:20 --> Helper loaded: url_helper
DEBUG - 2011-08-01 07:29:20 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-01 07:29:20 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-01 07:29:20 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-01 07:29:20 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-01 07:29:20 --> Final output sent to browser
DEBUG - 2011-08-01 07:29:20 --> Total execution time: 0.6142
DEBUG - 2011-08-01 07:29:37 --> Config Class Initialized
DEBUG - 2011-08-01 07:29:37 --> Hooks Class Initialized
DEBUG - 2011-08-01 07:29:37 --> Utf8 Class Initialized
DEBUG - 2011-08-01 07:29:37 --> UTF-8 Support Enabled
DEBUG - 2011-08-01 07:29:37 --> URI Class Initialized
DEBUG - 2011-08-01 07:29:37 --> Router Class Initialized
ERROR - 2011-08-01 07:29:37 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-01 07:30:33 --> Config Class Initialized
DEBUG - 2011-08-01 07:30:33 --> Hooks Class Initialized
DEBUG - 2011-08-01 07:30:33 --> Utf8 Class Initialized
DEBUG - 2011-08-01 07:30:33 --> UTF-8 Support Enabled
DEBUG - 2011-08-01 07:30:33 --> URI Class Initialized
DEBUG - 2011-08-01 07:30:33 --> Router Class Initialized
DEBUG - 2011-08-01 07:30:33 --> Output Class Initialized
DEBUG - 2011-08-01 07:30:33 --> Input Class Initialized
DEBUG - 2011-08-01 07:30:33 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-01 07:30:33 --> Language Class Initialized
DEBUG - 2011-08-01 07:30:33 --> Loader Class Initialized
DEBUG - 2011-08-01 07:30:33 --> Controller Class Initialized
DEBUG - 2011-08-01 07:30:33 --> Model Class Initialized
DEBUG - 2011-08-01 07:30:33 --> Model Class Initialized
DEBUG - 2011-08-01 07:30:33 --> Model Class Initialized
DEBUG - 2011-08-01 07:30:33 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-01 07:30:33 --> Database Driver Class Initialized
DEBUG - 2011-08-01 07:30:34 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-01 07:30:34 --> Helper loaded: url_helper
DEBUG - 2011-08-01 07:30:34 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-01 07:30:34 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-01 07:30:34 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-01 07:30:34 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-01 07:30:34 --> Final output sent to browser
DEBUG - 2011-08-01 07:30:34 --> Total execution time: 0.5802
DEBUG - 2011-08-01 07:30:43 --> Config Class Initialized
DEBUG - 2011-08-01 07:30:43 --> Hooks Class Initialized
DEBUG - 2011-08-01 07:30:43 --> Utf8 Class Initialized
DEBUG - 2011-08-01 07:30:43 --> UTF-8 Support Enabled
DEBUG - 2011-08-01 07:30:43 --> URI Class Initialized
DEBUG - 2011-08-01 07:30:43 --> Router Class Initialized
DEBUG - 2011-08-01 07:30:43 --> Output Class Initialized
DEBUG - 2011-08-01 07:30:43 --> Input Class Initialized
DEBUG - 2011-08-01 07:30:43 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-01 07:30:43 --> Language Class Initialized
DEBUG - 2011-08-01 07:30:43 --> Loader Class Initialized
DEBUG - 2011-08-01 07:30:43 --> Controller Class Initialized
DEBUG - 2011-08-01 07:30:43 --> Model Class Initialized
DEBUG - 2011-08-01 07:30:43 --> Model Class Initialized
DEBUG - 2011-08-01 07:30:43 --> Model Class Initialized
DEBUG - 2011-08-01 07:30:43 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-01 07:30:43 --> Database Driver Class Initialized
DEBUG - 2011-08-01 07:30:43 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-01 07:30:43 --> Helper loaded: url_helper
DEBUG - 2011-08-01 07:30:43 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-01 07:30:43 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-01 07:30:43 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-01 07:30:43 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-01 07:30:43 --> Final output sent to browser
DEBUG - 2011-08-01 07:30:43 --> Total execution time: 0.0497
DEBUG - 2011-08-01 08:15:58 --> Config Class Initialized
DEBUG - 2011-08-01 08:15:58 --> Hooks Class Initialized
DEBUG - 2011-08-01 08:15:58 --> Utf8 Class Initialized
DEBUG - 2011-08-01 08:15:58 --> UTF-8 Support Enabled
DEBUG - 2011-08-01 08:15:58 --> URI Class Initialized
DEBUG - 2011-08-01 08:15:58 --> Router Class Initialized
DEBUG - 2011-08-01 08:15:58 --> Output Class Initialized
DEBUG - 2011-08-01 08:15:58 --> Input Class Initialized
DEBUG - 2011-08-01 08:15:58 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-01 08:15:58 --> Language Class Initialized
DEBUG - 2011-08-01 08:15:58 --> Loader Class Initialized
DEBUG - 2011-08-01 08:15:58 --> Controller Class Initialized
ERROR - 2011-08-01 08:15:58 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-01 08:15:58 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-01 08:15:58 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-01 08:15:58 --> Model Class Initialized
DEBUG - 2011-08-01 08:15:58 --> Model Class Initialized
DEBUG - 2011-08-01 08:15:58 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-01 08:15:58 --> Database Driver Class Initialized
DEBUG - 2011-08-01 08:15:58 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-01 08:15:58 --> Helper loaded: url_helper
DEBUG - 2011-08-01 08:15:58 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-01 08:15:58 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-01 08:15:58 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-01 08:15:58 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-01 08:15:58 --> Final output sent to browser
DEBUG - 2011-08-01 08:15:58 --> Total execution time: 0.8414
DEBUG - 2011-08-01 08:16:04 --> Config Class Initialized
DEBUG - 2011-08-01 08:16:04 --> Hooks Class Initialized
DEBUG - 2011-08-01 08:16:04 --> Utf8 Class Initialized
DEBUG - 2011-08-01 08:16:04 --> UTF-8 Support Enabled
DEBUG - 2011-08-01 08:16:04 --> URI Class Initialized
DEBUG - 2011-08-01 08:16:04 --> Router Class Initialized
DEBUG - 2011-08-01 08:16:04 --> Output Class Initialized
DEBUG - 2011-08-01 08:16:04 --> Input Class Initialized
DEBUG - 2011-08-01 08:16:04 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-01 08:16:04 --> Language Class Initialized
DEBUG - 2011-08-01 08:16:04 --> Loader Class Initialized
DEBUG - 2011-08-01 08:16:04 --> Controller Class Initialized
DEBUG - 2011-08-01 08:16:04 --> Model Class Initialized
DEBUG - 2011-08-01 08:16:04 --> Model Class Initialized
DEBUG - 2011-08-01 08:16:04 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-01 08:16:04 --> Database Driver Class Initialized
DEBUG - 2011-08-01 08:16:05 --> Final output sent to browser
DEBUG - 2011-08-01 08:16:05 --> Total execution time: 0.6664
DEBUG - 2011-08-01 08:47:21 --> Config Class Initialized
DEBUG - 2011-08-01 08:47:21 --> Hooks Class Initialized
DEBUG - 2011-08-01 08:47:21 --> Utf8 Class Initialized
DEBUG - 2011-08-01 08:47:21 --> UTF-8 Support Enabled
DEBUG - 2011-08-01 08:47:21 --> URI Class Initialized
DEBUG - 2011-08-01 08:47:21 --> Router Class Initialized
DEBUG - 2011-08-01 08:47:21 --> No URI present. Default controller set.
DEBUG - 2011-08-01 08:47:21 --> Output Class Initialized
DEBUG - 2011-08-01 08:47:21 --> Input Class Initialized
DEBUG - 2011-08-01 08:47:21 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-01 08:47:21 --> Language Class Initialized
DEBUG - 2011-08-01 08:47:21 --> Loader Class Initialized
DEBUG - 2011-08-01 08:47:21 --> Controller Class Initialized
DEBUG - 2011-08-01 08:47:21 --> File loaded: application/views/splash/main.php
DEBUG - 2011-08-01 08:47:21 --> Helper loaded: url_helper
DEBUG - 2011-08-01 08:47:21 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-01 08:47:21 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-01 08:47:21 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-01 08:47:21 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-01 08:47:21 --> Final output sent to browser
DEBUG - 2011-08-01 08:47:21 --> Total execution time: 0.0893
DEBUG - 2011-08-01 08:47:23 --> Config Class Initialized
DEBUG - 2011-08-01 08:47:23 --> Hooks Class Initialized
DEBUG - 2011-08-01 08:47:23 --> Utf8 Class Initialized
DEBUG - 2011-08-01 08:47:23 --> UTF-8 Support Enabled
DEBUG - 2011-08-01 08:47:23 --> URI Class Initialized
DEBUG - 2011-08-01 08:47:23 --> Router Class Initialized
ERROR - 2011-08-01 08:47:23 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-01 08:47:23 --> Config Class Initialized
DEBUG - 2011-08-01 08:47:23 --> Hooks Class Initialized
DEBUG - 2011-08-01 08:47:23 --> Utf8 Class Initialized
DEBUG - 2011-08-01 08:47:23 --> UTF-8 Support Enabled
DEBUG - 2011-08-01 08:47:23 --> URI Class Initialized
DEBUG - 2011-08-01 08:47:23 --> Router Class Initialized
ERROR - 2011-08-01 08:47:23 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-01 08:47:25 --> Config Class Initialized
DEBUG - 2011-08-01 08:47:25 --> Hooks Class Initialized
DEBUG - 2011-08-01 08:47:25 --> Utf8 Class Initialized
DEBUG - 2011-08-01 08:47:25 --> UTF-8 Support Enabled
DEBUG - 2011-08-01 08:47:25 --> URI Class Initialized
DEBUG - 2011-08-01 08:47:25 --> Router Class Initialized
ERROR - 2011-08-01 08:47:25 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-01 08:59:15 --> Config Class Initialized
DEBUG - 2011-08-01 08:59:15 --> Hooks Class Initialized
DEBUG - 2011-08-01 08:59:15 --> Utf8 Class Initialized
DEBUG - 2011-08-01 08:59:15 --> UTF-8 Support Enabled
DEBUG - 2011-08-01 08:59:15 --> URI Class Initialized
DEBUG - 2011-08-01 08:59:15 --> Router Class Initialized
DEBUG - 2011-08-01 08:59:15 --> Output Class Initialized
DEBUG - 2011-08-01 08:59:15 --> Input Class Initialized
DEBUG - 2011-08-01 08:59:15 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-01 08:59:15 --> Language Class Initialized
DEBUG - 2011-08-01 08:59:15 --> Loader Class Initialized
DEBUG - 2011-08-01 08:59:15 --> Controller Class Initialized
DEBUG - 2011-08-01 08:59:15 --> Model Class Initialized
DEBUG - 2011-08-01 08:59:15 --> Model Class Initialized
DEBUG - 2011-08-01 08:59:15 --> Model Class Initialized
DEBUG - 2011-08-01 08:59:15 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-01 08:59:15 --> Database Driver Class Initialized
DEBUG - 2011-08-01 08:59:15 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-01 08:59:15 --> Helper loaded: url_helper
DEBUG - 2011-08-01 08:59:15 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-01 08:59:15 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-01 08:59:15 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-01 08:59:15 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-01 08:59:15 --> Final output sent to browser
DEBUG - 2011-08-01 08:59:15 --> Total execution time: 0.3961
DEBUG - 2011-08-01 09:03:57 --> Config Class Initialized
DEBUG - 2011-08-01 09:03:57 --> Hooks Class Initialized
DEBUG - 2011-08-01 09:03:57 --> Utf8 Class Initialized
DEBUG - 2011-08-01 09:03:57 --> UTF-8 Support Enabled
DEBUG - 2011-08-01 09:03:57 --> URI Class Initialized
DEBUG - 2011-08-01 09:03:57 --> Router Class Initialized
DEBUG - 2011-08-01 09:03:57 --> Output Class Initialized
DEBUG - 2011-08-01 09:03:57 --> Input Class Initialized
DEBUG - 2011-08-01 09:03:57 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-01 09:03:57 --> Language Class Initialized
DEBUG - 2011-08-01 09:03:57 --> Loader Class Initialized
DEBUG - 2011-08-01 09:03:57 --> Controller Class Initialized
DEBUG - 2011-08-01 09:03:57 --> Model Class Initialized
DEBUG - 2011-08-01 09:03:57 --> Model Class Initialized
DEBUG - 2011-08-01 09:03:57 --> Model Class Initialized
DEBUG - 2011-08-01 09:03:57 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-01 09:03:57 --> Database Driver Class Initialized
DEBUG - 2011-08-01 09:03:57 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-01 09:03:57 --> Helper loaded: url_helper
DEBUG - 2011-08-01 09:03:57 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-01 09:03:57 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-01 09:03:57 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-01 09:03:57 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-01 09:03:57 --> Final output sent to browser
DEBUG - 2011-08-01 09:03:57 --> Total execution time: 0.0608
DEBUG - 2011-08-01 09:04:00 --> Config Class Initialized
DEBUG - 2011-08-01 09:04:00 --> Hooks Class Initialized
DEBUG - 2011-08-01 09:04:00 --> Utf8 Class Initialized
DEBUG - 2011-08-01 09:04:00 --> UTF-8 Support Enabled
DEBUG - 2011-08-01 09:04:00 --> URI Class Initialized
DEBUG - 2011-08-01 09:04:00 --> Router Class Initialized
ERROR - 2011-08-01 09:04:00 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-01 12:05:42 --> Config Class Initialized
DEBUG - 2011-08-01 12:05:42 --> Hooks Class Initialized
DEBUG - 2011-08-01 12:05:42 --> Utf8 Class Initialized
DEBUG - 2011-08-01 12:05:42 --> UTF-8 Support Enabled
DEBUG - 2011-08-01 12:05:42 --> URI Class Initialized
DEBUG - 2011-08-01 12:05:42 --> Router Class Initialized
ERROR - 2011-08-01 12:05:42 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-08-01 12:13:16 --> Config Class Initialized
DEBUG - 2011-08-01 12:13:16 --> Hooks Class Initialized
DEBUG - 2011-08-01 12:13:16 --> Utf8 Class Initialized
DEBUG - 2011-08-01 12:13:16 --> UTF-8 Support Enabled
DEBUG - 2011-08-01 12:13:16 --> URI Class Initialized
DEBUG - 2011-08-01 12:13:16 --> Router Class Initialized
DEBUG - 2011-08-01 12:13:16 --> Output Class Initialized
DEBUG - 2011-08-01 12:13:16 --> Input Class Initialized
DEBUG - 2011-08-01 12:13:16 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-01 12:13:16 --> Language Class Initialized
DEBUG - 2011-08-01 12:13:16 --> Loader Class Initialized
DEBUG - 2011-08-01 12:13:16 --> Controller Class Initialized
DEBUG - 2011-08-01 12:13:16 --> Model Class Initialized
DEBUG - 2011-08-01 12:13:16 --> Model Class Initialized
DEBUG - 2011-08-01 12:13:16 --> Model Class Initialized
DEBUG - 2011-08-01 12:13:16 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-01 12:13:16 --> Database Driver Class Initialized
DEBUG - 2011-08-01 12:13:16 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-01 12:13:16 --> Helper loaded: url_helper
DEBUG - 2011-08-01 12:13:16 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-01 12:13:16 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-01 12:13:16 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-01 12:13:16 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-01 12:13:16 --> Final output sent to browser
DEBUG - 2011-08-01 12:13:16 --> Total execution time: 0.5278
DEBUG - 2011-08-01 12:13:40 --> Config Class Initialized
DEBUG - 2011-08-01 12:13:40 --> Hooks Class Initialized
DEBUG - 2011-08-01 12:13:40 --> Utf8 Class Initialized
DEBUG - 2011-08-01 12:13:40 --> UTF-8 Support Enabled
DEBUG - 2011-08-01 12:13:40 --> URI Class Initialized
DEBUG - 2011-08-01 12:13:40 --> Router Class Initialized
ERROR - 2011-08-01 12:13:40 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-08-01 12:22:24 --> Config Class Initialized
DEBUG - 2011-08-01 12:22:24 --> Hooks Class Initialized
DEBUG - 2011-08-01 12:22:24 --> Utf8 Class Initialized
DEBUG - 2011-08-01 12:22:24 --> UTF-8 Support Enabled
DEBUG - 2011-08-01 12:22:24 --> URI Class Initialized
DEBUG - 2011-08-01 12:22:24 --> Router Class Initialized
DEBUG - 2011-08-01 12:22:24 --> Output Class Initialized
DEBUG - 2011-08-01 12:22:24 --> Input Class Initialized
DEBUG - 2011-08-01 12:22:24 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-01 12:22:24 --> Language Class Initialized
DEBUG - 2011-08-01 12:22:24 --> Loader Class Initialized
DEBUG - 2011-08-01 12:22:24 --> Controller Class Initialized
ERROR - 2011-08-01 12:22:24 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-01 12:22:24 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-01 12:22:24 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-01 12:22:24 --> Model Class Initialized
DEBUG - 2011-08-01 12:22:24 --> Model Class Initialized
DEBUG - 2011-08-01 12:22:24 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-01 12:22:24 --> Database Driver Class Initialized
DEBUG - 2011-08-01 12:22:24 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-01 12:22:24 --> Helper loaded: url_helper
DEBUG - 2011-08-01 12:22:24 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-01 12:22:24 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-01 12:22:24 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-01 12:22:24 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-01 12:22:24 --> Final output sent to browser
DEBUG - 2011-08-01 12:22:24 --> Total execution time: 0.0863
DEBUG - 2011-08-01 12:47:55 --> Config Class Initialized
DEBUG - 2011-08-01 12:47:55 --> Hooks Class Initialized
DEBUG - 2011-08-01 12:47:55 --> Utf8 Class Initialized
DEBUG - 2011-08-01 12:47:55 --> UTF-8 Support Enabled
DEBUG - 2011-08-01 12:47:55 --> URI Class Initialized
DEBUG - 2011-08-01 12:47:55 --> Router Class Initialized
DEBUG - 2011-08-01 12:47:55 --> Output Class Initialized
DEBUG - 2011-08-01 12:47:55 --> Input Class Initialized
DEBUG - 2011-08-01 12:47:55 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-01 12:47:55 --> Language Class Initialized
DEBUG - 2011-08-01 12:47:55 --> Loader Class Initialized
DEBUG - 2011-08-01 12:47:55 --> Controller Class Initialized
DEBUG - 2011-08-01 12:47:55 --> Model Class Initialized
DEBUG - 2011-08-01 12:47:55 --> Model Class Initialized
DEBUG - 2011-08-01 12:47:55 --> Model Class Initialized
DEBUG - 2011-08-01 12:47:55 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-01 12:47:55 --> Database Driver Class Initialized
DEBUG - 2011-08-01 12:47:55 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-01 12:47:55 --> Helper loaded: url_helper
DEBUG - 2011-08-01 12:47:55 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-01 12:47:55 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-01 12:47:55 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-01 12:47:55 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-01 12:47:55 --> Final output sent to browser
DEBUG - 2011-08-01 12:47:55 --> Total execution time: 0.2536
DEBUG - 2011-08-01 12:47:57 --> Config Class Initialized
DEBUG - 2011-08-01 12:47:57 --> Hooks Class Initialized
DEBUG - 2011-08-01 12:47:57 --> Utf8 Class Initialized
DEBUG - 2011-08-01 12:47:57 --> UTF-8 Support Enabled
DEBUG - 2011-08-01 12:47:57 --> URI Class Initialized
DEBUG - 2011-08-01 12:47:57 --> Router Class Initialized
ERROR - 2011-08-01 12:47:57 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-01 12:47:57 --> Config Class Initialized
DEBUG - 2011-08-01 12:47:57 --> Hooks Class Initialized
DEBUG - 2011-08-01 12:47:57 --> Utf8 Class Initialized
DEBUG - 2011-08-01 12:47:57 --> UTF-8 Support Enabled
DEBUG - 2011-08-01 12:47:57 --> URI Class Initialized
DEBUG - 2011-08-01 12:47:57 --> Router Class Initialized
ERROR - 2011-08-01 12:47:57 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-01 12:48:14 --> Config Class Initialized
DEBUG - 2011-08-01 12:48:14 --> Hooks Class Initialized
DEBUG - 2011-08-01 12:48:14 --> Utf8 Class Initialized
DEBUG - 2011-08-01 12:48:14 --> UTF-8 Support Enabled
DEBUG - 2011-08-01 12:48:14 --> URI Class Initialized
DEBUG - 2011-08-01 12:48:14 --> Router Class Initialized
DEBUG - 2011-08-01 12:48:14 --> Output Class Initialized
DEBUG - 2011-08-01 12:48:14 --> Input Class Initialized
DEBUG - 2011-08-01 12:48:14 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-01 12:48:14 --> Language Class Initialized
DEBUG - 2011-08-01 12:48:14 --> Loader Class Initialized
DEBUG - 2011-08-01 12:48:14 --> Controller Class Initialized
DEBUG - 2011-08-01 12:48:14 --> Model Class Initialized
DEBUG - 2011-08-01 12:48:14 --> Model Class Initialized
DEBUG - 2011-08-01 12:48:14 --> Model Class Initialized
DEBUG - 2011-08-01 12:48:14 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-01 12:48:14 --> Database Driver Class Initialized
DEBUG - 2011-08-01 12:48:14 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-01 12:48:14 --> Helper loaded: url_helper
DEBUG - 2011-08-01 12:48:14 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-01 12:48:14 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-01 12:48:14 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-01 12:48:14 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-01 12:48:14 --> Final output sent to browser
DEBUG - 2011-08-01 12:48:14 --> Total execution time: 0.0443
DEBUG - 2011-08-01 12:48:15 --> Config Class Initialized
DEBUG - 2011-08-01 12:48:15 --> Hooks Class Initialized
DEBUG - 2011-08-01 12:48:15 --> Utf8 Class Initialized
DEBUG - 2011-08-01 12:48:15 --> UTF-8 Support Enabled
DEBUG - 2011-08-01 12:48:15 --> URI Class Initialized
DEBUG - 2011-08-01 12:48:15 --> Router Class Initialized
ERROR - 2011-08-01 12:48:15 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-01 13:15:41 --> Config Class Initialized
DEBUG - 2011-08-01 13:15:41 --> Hooks Class Initialized
DEBUG - 2011-08-01 13:15:41 --> Utf8 Class Initialized
DEBUG - 2011-08-01 13:15:41 --> UTF-8 Support Enabled
DEBUG - 2011-08-01 13:15:41 --> URI Class Initialized
DEBUG - 2011-08-01 13:15:41 --> Router Class Initialized
DEBUG - 2011-08-01 13:15:41 --> Output Class Initialized
DEBUG - 2011-08-01 13:15:41 --> Input Class Initialized
DEBUG - 2011-08-01 13:15:41 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-01 13:15:41 --> Language Class Initialized
DEBUG - 2011-08-01 13:15:41 --> Loader Class Initialized
DEBUG - 2011-08-01 13:15:41 --> Controller Class Initialized
ERROR - 2011-08-01 13:15:41 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-01 13:15:41 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-01 13:15:41 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-01 13:15:41 --> Model Class Initialized
DEBUG - 2011-08-01 13:15:41 --> Model Class Initialized
DEBUG - 2011-08-01 13:15:41 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-01 13:15:41 --> Database Driver Class Initialized
DEBUG - 2011-08-01 13:15:41 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-01 13:15:41 --> Helper loaded: url_helper
DEBUG - 2011-08-01 13:15:41 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-01 13:15:41 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-01 13:15:41 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-01 13:15:41 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-01 13:15:41 --> Final output sent to browser
DEBUG - 2011-08-01 13:15:41 --> Total execution time: 0.0303
DEBUG - 2011-08-01 13:15:42 --> Config Class Initialized
DEBUG - 2011-08-01 13:15:42 --> Hooks Class Initialized
DEBUG - 2011-08-01 13:15:42 --> Utf8 Class Initialized
DEBUG - 2011-08-01 13:15:42 --> UTF-8 Support Enabled
DEBUG - 2011-08-01 13:15:42 --> URI Class Initialized
DEBUG - 2011-08-01 13:15:42 --> Router Class Initialized
DEBUG - 2011-08-01 13:15:42 --> Output Class Initialized
DEBUG - 2011-08-01 13:15:42 --> Input Class Initialized
DEBUG - 2011-08-01 13:15:42 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-01 13:15:42 --> Language Class Initialized
DEBUG - 2011-08-01 13:15:42 --> Loader Class Initialized
DEBUG - 2011-08-01 13:15:42 --> Controller Class Initialized
DEBUG - 2011-08-01 13:15:42 --> Model Class Initialized
DEBUG - 2011-08-01 13:15:42 --> Model Class Initialized
DEBUG - 2011-08-01 13:15:42 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-01 13:15:42 --> Database Driver Class Initialized
DEBUG - 2011-08-01 13:15:48 --> Final output sent to browser
DEBUG - 2011-08-01 13:15:48 --> Total execution time: 5.6296
DEBUG - 2011-08-01 13:15:51 --> Config Class Initialized
DEBUG - 2011-08-01 13:15:51 --> Hooks Class Initialized
DEBUG - 2011-08-01 13:15:51 --> Utf8 Class Initialized
DEBUG - 2011-08-01 13:15:51 --> UTF-8 Support Enabled
DEBUG - 2011-08-01 13:15:51 --> URI Class Initialized
DEBUG - 2011-08-01 13:15:51 --> Router Class Initialized
DEBUG - 2011-08-01 13:15:51 --> Output Class Initialized
DEBUG - 2011-08-01 13:15:51 --> Input Class Initialized
DEBUG - 2011-08-01 13:15:51 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-01 13:15:51 --> Language Class Initialized
DEBUG - 2011-08-01 13:15:51 --> Loader Class Initialized
DEBUG - 2011-08-01 13:15:51 --> Controller Class Initialized
DEBUG - 2011-08-01 13:15:51 --> Model Class Initialized
DEBUG - 2011-08-01 13:15:51 --> Model Class Initialized
DEBUG - 2011-08-01 13:15:51 --> Model Class Initialized
DEBUG - 2011-08-01 13:15:51 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-01 13:15:51 --> Database Driver Class Initialized
DEBUG - 2011-08-01 13:15:51 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-01 13:15:51 --> Helper loaded: url_helper
DEBUG - 2011-08-01 13:15:51 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-01 13:15:51 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-01 13:15:51 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-01 13:15:51 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-01 13:15:51 --> Final output sent to browser
DEBUG - 2011-08-01 13:15:51 --> Total execution time: 0.2661
DEBUG - 2011-08-01 13:15:52 --> Config Class Initialized
DEBUG - 2011-08-01 13:15:52 --> Hooks Class Initialized
DEBUG - 2011-08-01 13:15:52 --> Utf8 Class Initialized
DEBUG - 2011-08-01 13:15:52 --> UTF-8 Support Enabled
DEBUG - 2011-08-01 13:15:52 --> URI Class Initialized
DEBUG - 2011-08-01 13:15:52 --> Router Class Initialized
ERROR - 2011-08-01 13:15:52 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-01 15:44:34 --> Config Class Initialized
DEBUG - 2011-08-01 15:44:34 --> Hooks Class Initialized
DEBUG - 2011-08-01 15:44:34 --> Utf8 Class Initialized
DEBUG - 2011-08-01 15:44:34 --> UTF-8 Support Enabled
DEBUG - 2011-08-01 15:44:34 --> URI Class Initialized
DEBUG - 2011-08-01 15:44:34 --> Router Class Initialized
DEBUG - 2011-08-01 15:44:34 --> Output Class Initialized
DEBUG - 2011-08-01 15:44:34 --> Input Class Initialized
DEBUG - 2011-08-01 15:44:34 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-01 15:44:34 --> Language Class Initialized
DEBUG - 2011-08-01 15:44:34 --> Loader Class Initialized
DEBUG - 2011-08-01 15:44:34 --> Controller Class Initialized
DEBUG - 2011-08-01 15:44:34 --> Model Class Initialized
DEBUG - 2011-08-01 15:44:34 --> Model Class Initialized
DEBUG - 2011-08-01 15:44:34 --> Model Class Initialized
DEBUG - 2011-08-01 15:44:34 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-01 15:44:34 --> Database Driver Class Initialized
DEBUG - 2011-08-01 15:44:34 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-01 15:44:34 --> Helper loaded: url_helper
DEBUG - 2011-08-01 15:44:34 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-01 15:44:34 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-01 15:44:34 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-01 15:44:34 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-01 15:44:34 --> Final output sent to browser
DEBUG - 2011-08-01 15:44:34 --> Total execution time: 0.5669
DEBUG - 2011-08-01 15:44:36 --> Config Class Initialized
DEBUG - 2011-08-01 15:44:36 --> Hooks Class Initialized
DEBUG - 2011-08-01 15:44:36 --> Utf8 Class Initialized
DEBUG - 2011-08-01 15:44:36 --> UTF-8 Support Enabled
DEBUG - 2011-08-01 15:44:36 --> URI Class Initialized
DEBUG - 2011-08-01 15:44:36 --> Router Class Initialized
ERROR - 2011-08-01 15:44:36 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-01 15:44:37 --> Config Class Initialized
DEBUG - 2011-08-01 15:44:37 --> Hooks Class Initialized
DEBUG - 2011-08-01 15:44:37 --> Utf8 Class Initialized
DEBUG - 2011-08-01 15:44:37 --> UTF-8 Support Enabled
DEBUG - 2011-08-01 15:44:37 --> URI Class Initialized
DEBUG - 2011-08-01 15:44:37 --> Router Class Initialized
DEBUG - 2011-08-01 15:44:37 --> Output Class Initialized
DEBUG - 2011-08-01 15:44:37 --> Input Class Initialized
DEBUG - 2011-08-01 15:44:37 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-01 15:44:37 --> Language Class Initialized
DEBUG - 2011-08-01 15:44:37 --> Loader Class Initialized
DEBUG - 2011-08-01 15:44:37 --> Controller Class Initialized
ERROR - 2011-08-01 15:44:37 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-01 15:44:37 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-01 15:44:37 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-01 15:44:37 --> Model Class Initialized
DEBUG - 2011-08-01 15:44:37 --> Model Class Initialized
DEBUG - 2011-08-01 15:44:37 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-01 15:44:37 --> Database Driver Class Initialized
DEBUG - 2011-08-01 15:44:37 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-01 15:44:37 --> Helper loaded: url_helper
DEBUG - 2011-08-01 15:44:37 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-01 15:44:37 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-01 15:44:37 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-01 15:44:37 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-01 15:44:37 --> Final output sent to browser
DEBUG - 2011-08-01 15:44:37 --> Total execution time: 0.0845
DEBUG - 2011-08-01 15:44:37 --> Config Class Initialized
DEBUG - 2011-08-01 15:44:37 --> Hooks Class Initialized
DEBUG - 2011-08-01 15:44:37 --> Utf8 Class Initialized
DEBUG - 2011-08-01 15:44:37 --> UTF-8 Support Enabled
DEBUG - 2011-08-01 15:44:37 --> URI Class Initialized
DEBUG - 2011-08-01 15:44:37 --> Router Class Initialized
DEBUG - 2011-08-01 15:44:37 --> Output Class Initialized
DEBUG - 2011-08-01 15:44:37 --> Input Class Initialized
DEBUG - 2011-08-01 15:44:37 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-01 15:44:37 --> Language Class Initialized
DEBUG - 2011-08-01 15:44:37 --> Loader Class Initialized
DEBUG - 2011-08-01 15:44:37 --> Controller Class Initialized
DEBUG - 2011-08-01 15:44:37 --> Model Class Initialized
DEBUG - 2011-08-01 15:44:37 --> Model Class Initialized
DEBUG - 2011-08-01 15:44:37 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-01 15:44:37 --> Database Driver Class Initialized
DEBUG - 2011-08-01 15:44:38 --> Final output sent to browser
DEBUG - 2011-08-01 15:44:38 --> Total execution time: 0.5221
DEBUG - 2011-08-01 15:44:38 --> Config Class Initialized
DEBUG - 2011-08-01 15:44:38 --> Hooks Class Initialized
DEBUG - 2011-08-01 15:44:38 --> Utf8 Class Initialized
DEBUG - 2011-08-01 15:44:38 --> UTF-8 Support Enabled
DEBUG - 2011-08-01 15:44:38 --> URI Class Initialized
DEBUG - 2011-08-01 15:44:38 --> Router Class Initialized
ERROR - 2011-08-01 15:44:38 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-01 15:45:03 --> Config Class Initialized
DEBUG - 2011-08-01 15:45:03 --> Hooks Class Initialized
DEBUG - 2011-08-01 15:45:03 --> Utf8 Class Initialized
DEBUG - 2011-08-01 15:45:03 --> UTF-8 Support Enabled
DEBUG - 2011-08-01 15:45:03 --> URI Class Initialized
DEBUG - 2011-08-01 15:45:03 --> Router Class Initialized
DEBUG - 2011-08-01 15:45:03 --> Output Class Initialized
DEBUG - 2011-08-01 15:45:03 --> Input Class Initialized
DEBUG - 2011-08-01 15:45:03 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-01 15:45:03 --> Language Class Initialized
DEBUG - 2011-08-01 15:45:03 --> Loader Class Initialized
DEBUG - 2011-08-01 15:45:03 --> Controller Class Initialized
DEBUG - 2011-08-01 15:45:03 --> Model Class Initialized
DEBUG - 2011-08-01 15:45:03 --> Model Class Initialized
DEBUG - 2011-08-01 15:45:03 --> Model Class Initialized
DEBUG - 2011-08-01 15:45:03 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-01 15:45:03 --> Database Driver Class Initialized
DEBUG - 2011-08-01 15:45:04 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-01 15:45:04 --> Helper loaded: url_helper
DEBUG - 2011-08-01 15:45:04 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-01 15:45:04 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-01 15:45:04 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-01 15:45:04 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-01 15:45:04 --> Final output sent to browser
DEBUG - 2011-08-01 15:45:04 --> Total execution time: 0.9375
DEBUG - 2011-08-01 15:45:18 --> Config Class Initialized
DEBUG - 2011-08-01 15:45:18 --> Hooks Class Initialized
DEBUG - 2011-08-01 15:45:18 --> Utf8 Class Initialized
DEBUG - 2011-08-01 15:45:18 --> UTF-8 Support Enabled
DEBUG - 2011-08-01 15:45:18 --> URI Class Initialized
DEBUG - 2011-08-01 15:45:18 --> Router Class Initialized
DEBUG - 2011-08-01 15:45:18 --> Output Class Initialized
DEBUG - 2011-08-01 15:45:18 --> Input Class Initialized
DEBUG - 2011-08-01 15:45:18 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-01 15:45:18 --> Language Class Initialized
DEBUG - 2011-08-01 15:45:18 --> Loader Class Initialized
DEBUG - 2011-08-01 15:45:18 --> Controller Class Initialized
DEBUG - 2011-08-01 15:45:18 --> Model Class Initialized
DEBUG - 2011-08-01 15:45:18 --> Model Class Initialized
DEBUG - 2011-08-01 15:45:18 --> Model Class Initialized
DEBUG - 2011-08-01 15:45:18 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-01 15:45:18 --> Database Driver Class Initialized
DEBUG - 2011-08-01 15:45:18 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-01 15:45:18 --> Helper loaded: url_helper
DEBUG - 2011-08-01 15:45:18 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-01 15:45:18 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-01 15:45:18 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-01 15:45:18 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-01 15:45:18 --> Final output sent to browser
DEBUG - 2011-08-01 15:45:18 --> Total execution time: 0.3249
DEBUG - 2011-08-01 15:45:19 --> Config Class Initialized
DEBUG - 2011-08-01 15:45:19 --> Hooks Class Initialized
DEBUG - 2011-08-01 15:45:19 --> Utf8 Class Initialized
DEBUG - 2011-08-01 15:45:19 --> UTF-8 Support Enabled
DEBUG - 2011-08-01 15:45:19 --> URI Class Initialized
DEBUG - 2011-08-01 15:45:19 --> Router Class Initialized
ERROR - 2011-08-01 15:45:19 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-08-01 15:45:19 --> Config Class Initialized
DEBUG - 2011-08-01 15:45:19 --> Hooks Class Initialized
DEBUG - 2011-08-01 15:45:19 --> Utf8 Class Initialized
DEBUG - 2011-08-01 15:45:19 --> UTF-8 Support Enabled
DEBUG - 2011-08-01 15:45:19 --> URI Class Initialized
DEBUG - 2011-08-01 15:45:19 --> Router Class Initialized
DEBUG - 2011-08-01 15:45:19 --> Output Class Initialized
DEBUG - 2011-08-01 15:45:19 --> Input Class Initialized
DEBUG - 2011-08-01 15:45:19 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-01 15:45:19 --> Language Class Initialized
DEBUG - 2011-08-01 15:45:19 --> Loader Class Initialized
DEBUG - 2011-08-01 15:45:19 --> Controller Class Initialized
DEBUG - 2011-08-01 15:45:19 --> Model Class Initialized
DEBUG - 2011-08-01 15:45:19 --> Model Class Initialized
DEBUG - 2011-08-01 15:45:19 --> Model Class Initialized
DEBUG - 2011-08-01 15:45:19 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-01 15:45:19 --> Database Driver Class Initialized
DEBUG - 2011-08-01 15:45:19 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-01 15:45:19 --> Helper loaded: url_helper
DEBUG - 2011-08-01 15:45:19 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-01 15:45:19 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-01 15:45:19 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-01 15:45:19 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-01 15:45:19 --> Final output sent to browser
DEBUG - 2011-08-01 15:45:19 --> Total execution time: 0.0445
DEBUG - 2011-08-01 15:45:23 --> Config Class Initialized
DEBUG - 2011-08-01 15:45:23 --> Hooks Class Initialized
DEBUG - 2011-08-01 15:45:23 --> Utf8 Class Initialized
DEBUG - 2011-08-01 15:45:23 --> UTF-8 Support Enabled
DEBUG - 2011-08-01 15:45:23 --> URI Class Initialized
DEBUG - 2011-08-01 15:45:23 --> Router Class Initialized
DEBUG - 2011-08-01 15:45:23 --> Output Class Initialized
DEBUG - 2011-08-01 15:45:23 --> Input Class Initialized
DEBUG - 2011-08-01 15:45:23 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-01 15:45:23 --> Language Class Initialized
DEBUG - 2011-08-01 15:45:23 --> Loader Class Initialized
DEBUG - 2011-08-01 15:45:23 --> Controller Class Initialized
DEBUG - 2011-08-01 15:45:23 --> Model Class Initialized
DEBUG - 2011-08-01 15:45:23 --> Model Class Initialized
DEBUG - 2011-08-01 15:45:23 --> Model Class Initialized
DEBUG - 2011-08-01 15:45:23 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-01 15:45:23 --> Database Driver Class Initialized
DEBUG - 2011-08-01 15:45:23 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-01 15:45:23 --> Helper loaded: url_helper
DEBUG - 2011-08-01 15:45:23 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-01 15:45:23 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-01 15:45:23 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-01 15:45:23 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-01 15:45:23 --> Final output sent to browser
DEBUG - 2011-08-01 15:45:23 --> Total execution time: 0.2399
DEBUG - 2011-08-01 15:45:25 --> Config Class Initialized
DEBUG - 2011-08-01 15:45:25 --> Hooks Class Initialized
DEBUG - 2011-08-01 15:45:25 --> Utf8 Class Initialized
DEBUG - 2011-08-01 15:45:25 --> UTF-8 Support Enabled
DEBUG - 2011-08-01 15:45:25 --> URI Class Initialized
DEBUG - 2011-08-01 15:45:25 --> Router Class Initialized
DEBUG - 2011-08-01 15:45:25 --> Output Class Initialized
DEBUG - 2011-08-01 15:45:25 --> Input Class Initialized
DEBUG - 2011-08-01 15:45:25 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-01 15:45:25 --> Language Class Initialized
DEBUG - 2011-08-01 15:45:25 --> Loader Class Initialized
DEBUG - 2011-08-01 15:45:25 --> Controller Class Initialized
DEBUG - 2011-08-01 15:45:25 --> Model Class Initialized
DEBUG - 2011-08-01 15:45:25 --> Model Class Initialized
DEBUG - 2011-08-01 15:45:25 --> Model Class Initialized
DEBUG - 2011-08-01 15:45:25 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-01 15:45:25 --> Database Driver Class Initialized
DEBUG - 2011-08-01 15:45:25 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-01 15:45:25 --> Helper loaded: url_helper
DEBUG - 2011-08-01 15:45:25 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-01 15:45:25 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-01 15:45:25 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-01 15:45:25 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-01 15:45:25 --> Final output sent to browser
DEBUG - 2011-08-01 15:45:25 --> Total execution time: 0.0847
DEBUG - 2011-08-01 15:45:30 --> Config Class Initialized
DEBUG - 2011-08-01 15:45:30 --> Hooks Class Initialized
DEBUG - 2011-08-01 15:45:30 --> Utf8 Class Initialized
DEBUG - 2011-08-01 15:45:30 --> UTF-8 Support Enabled
DEBUG - 2011-08-01 15:45:30 --> URI Class Initialized
DEBUG - 2011-08-01 15:45:30 --> Router Class Initialized
DEBUG - 2011-08-01 15:45:30 --> Output Class Initialized
DEBUG - 2011-08-01 15:45:30 --> Input Class Initialized
DEBUG - 2011-08-01 15:45:30 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-01 15:45:30 --> Language Class Initialized
DEBUG - 2011-08-01 15:45:30 --> Loader Class Initialized
DEBUG - 2011-08-01 15:45:30 --> Controller Class Initialized
DEBUG - 2011-08-01 15:45:30 --> Model Class Initialized
DEBUG - 2011-08-01 15:45:30 --> Model Class Initialized
DEBUG - 2011-08-01 15:45:30 --> Model Class Initialized
DEBUG - 2011-08-01 15:45:30 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-01 15:45:30 --> Database Driver Class Initialized
DEBUG - 2011-08-01 15:45:31 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-01 15:45:31 --> Helper loaded: url_helper
DEBUG - 2011-08-01 15:45:31 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-01 15:45:31 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-01 15:45:31 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-01 15:45:31 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-01 15:45:31 --> Final output sent to browser
DEBUG - 2011-08-01 15:45:31 --> Total execution time: 0.2043
DEBUG - 2011-08-01 15:45:38 --> Config Class Initialized
DEBUG - 2011-08-01 15:45:38 --> Hooks Class Initialized
DEBUG - 2011-08-01 15:45:38 --> Utf8 Class Initialized
DEBUG - 2011-08-01 15:45:38 --> UTF-8 Support Enabled
DEBUG - 2011-08-01 15:45:38 --> URI Class Initialized
DEBUG - 2011-08-01 15:45:38 --> Router Class Initialized
DEBUG - 2011-08-01 15:45:38 --> Output Class Initialized
DEBUG - 2011-08-01 15:45:38 --> Input Class Initialized
DEBUG - 2011-08-01 15:45:38 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-01 15:45:38 --> Language Class Initialized
DEBUG - 2011-08-01 15:45:38 --> Loader Class Initialized
DEBUG - 2011-08-01 15:45:38 --> Controller Class Initialized
DEBUG - 2011-08-01 15:45:38 --> Model Class Initialized
DEBUG - 2011-08-01 15:45:38 --> Model Class Initialized
DEBUG - 2011-08-01 15:45:38 --> Model Class Initialized
DEBUG - 2011-08-01 15:45:38 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-01 15:45:38 --> Database Driver Class Initialized
DEBUG - 2011-08-01 15:45:38 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-01 15:45:38 --> Helper loaded: url_helper
DEBUG - 2011-08-01 15:45:38 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-01 15:45:38 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-01 15:45:38 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-01 15:45:38 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-01 15:45:38 --> Final output sent to browser
DEBUG - 2011-08-01 15:45:38 --> Total execution time: 0.2447
DEBUG - 2011-08-01 15:45:39 --> Config Class Initialized
DEBUG - 2011-08-01 15:45:39 --> Hooks Class Initialized
DEBUG - 2011-08-01 15:45:39 --> Utf8 Class Initialized
DEBUG - 2011-08-01 15:45:39 --> UTF-8 Support Enabled
DEBUG - 2011-08-01 15:45:39 --> URI Class Initialized
DEBUG - 2011-08-01 15:45:39 --> Router Class Initialized
DEBUG - 2011-08-01 15:45:39 --> Output Class Initialized
DEBUG - 2011-08-01 15:45:39 --> Input Class Initialized
DEBUG - 2011-08-01 15:45:39 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-01 15:45:39 --> Language Class Initialized
DEBUG - 2011-08-01 15:45:39 --> Loader Class Initialized
DEBUG - 2011-08-01 15:45:39 --> Controller Class Initialized
DEBUG - 2011-08-01 15:45:39 --> Model Class Initialized
DEBUG - 2011-08-01 15:45:39 --> Model Class Initialized
DEBUG - 2011-08-01 15:45:39 --> Model Class Initialized
DEBUG - 2011-08-01 15:45:39 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-01 15:45:39 --> Database Driver Class Initialized
DEBUG - 2011-08-01 15:45:39 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-01 15:45:39 --> Helper loaded: url_helper
DEBUG - 2011-08-01 15:45:39 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-01 15:45:39 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-01 15:45:39 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-01 15:45:39 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-01 15:45:39 --> Final output sent to browser
DEBUG - 2011-08-01 15:45:39 --> Total execution time: 0.0433
DEBUG - 2011-08-01 15:45:43 --> Config Class Initialized
DEBUG - 2011-08-01 15:45:43 --> Hooks Class Initialized
DEBUG - 2011-08-01 15:45:43 --> Utf8 Class Initialized
DEBUG - 2011-08-01 15:45:43 --> UTF-8 Support Enabled
DEBUG - 2011-08-01 15:45:43 --> URI Class Initialized
DEBUG - 2011-08-01 15:45:43 --> Router Class Initialized
DEBUG - 2011-08-01 15:45:43 --> Output Class Initialized
DEBUG - 2011-08-01 15:45:43 --> Input Class Initialized
DEBUG - 2011-08-01 15:45:43 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-01 15:45:43 --> Language Class Initialized
DEBUG - 2011-08-01 15:45:43 --> Loader Class Initialized
DEBUG - 2011-08-01 15:45:43 --> Controller Class Initialized
DEBUG - 2011-08-01 15:45:43 --> Model Class Initialized
DEBUG - 2011-08-01 15:45:43 --> Model Class Initialized
DEBUG - 2011-08-01 15:45:43 --> Model Class Initialized
DEBUG - 2011-08-01 15:45:43 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-01 15:45:43 --> Database Driver Class Initialized
DEBUG - 2011-08-01 15:45:43 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-01 15:45:43 --> Helper loaded: url_helper
DEBUG - 2011-08-01 15:45:43 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-01 15:45:43 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-01 15:45:43 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-01 15:45:43 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-01 15:45:43 --> Final output sent to browser
DEBUG - 2011-08-01 15:45:43 --> Total execution time: 0.2433
DEBUG - 2011-08-01 15:45:44 --> Config Class Initialized
DEBUG - 2011-08-01 15:45:44 --> Hooks Class Initialized
DEBUG - 2011-08-01 15:45:44 --> Utf8 Class Initialized
DEBUG - 2011-08-01 15:45:44 --> UTF-8 Support Enabled
DEBUG - 2011-08-01 15:45:44 --> URI Class Initialized
DEBUG - 2011-08-01 15:45:44 --> Router Class Initialized
DEBUG - 2011-08-01 15:45:44 --> Output Class Initialized
DEBUG - 2011-08-01 15:45:44 --> Input Class Initialized
DEBUG - 2011-08-01 15:45:44 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-01 15:45:44 --> Language Class Initialized
DEBUG - 2011-08-01 15:45:44 --> Loader Class Initialized
DEBUG - 2011-08-01 15:45:44 --> Controller Class Initialized
DEBUG - 2011-08-01 15:45:44 --> Model Class Initialized
DEBUG - 2011-08-01 15:45:44 --> Model Class Initialized
DEBUG - 2011-08-01 15:45:44 --> Model Class Initialized
DEBUG - 2011-08-01 15:45:44 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-01 15:45:44 --> Database Driver Class Initialized
DEBUG - 2011-08-01 15:45:44 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-01 15:45:44 --> Helper loaded: url_helper
DEBUG - 2011-08-01 15:45:44 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-01 15:45:44 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-01 15:45:44 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-01 15:45:44 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-01 15:45:44 --> Final output sent to browser
DEBUG - 2011-08-01 15:45:44 --> Total execution time: 0.0421
DEBUG - 2011-08-01 15:45:50 --> Config Class Initialized
DEBUG - 2011-08-01 15:45:50 --> Hooks Class Initialized
DEBUG - 2011-08-01 15:45:50 --> Utf8 Class Initialized
DEBUG - 2011-08-01 15:45:50 --> UTF-8 Support Enabled
DEBUG - 2011-08-01 15:45:50 --> URI Class Initialized
DEBUG - 2011-08-01 15:45:50 --> Router Class Initialized
DEBUG - 2011-08-01 15:45:50 --> Output Class Initialized
DEBUG - 2011-08-01 15:45:50 --> Input Class Initialized
DEBUG - 2011-08-01 15:45:50 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-01 15:45:50 --> Language Class Initialized
DEBUG - 2011-08-01 15:45:50 --> Loader Class Initialized
DEBUG - 2011-08-01 15:45:50 --> Controller Class Initialized
DEBUG - 2011-08-01 15:45:50 --> Model Class Initialized
DEBUG - 2011-08-01 15:45:50 --> Model Class Initialized
DEBUG - 2011-08-01 15:45:50 --> Model Class Initialized
DEBUG - 2011-08-01 15:45:50 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-01 15:45:51 --> Database Driver Class Initialized
DEBUG - 2011-08-01 15:45:51 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-01 15:45:51 --> Helper loaded: url_helper
DEBUG - 2011-08-01 15:45:51 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-01 15:45:51 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-01 15:45:51 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-01 15:45:51 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-01 15:45:51 --> Final output sent to browser
DEBUG - 2011-08-01 15:45:51 --> Total execution time: 0.0427
DEBUG - 2011-08-01 15:45:54 --> Config Class Initialized
DEBUG - 2011-08-01 15:45:54 --> Hooks Class Initialized
DEBUG - 2011-08-01 15:45:54 --> Utf8 Class Initialized
DEBUG - 2011-08-01 15:45:54 --> UTF-8 Support Enabled
DEBUG - 2011-08-01 15:45:54 --> URI Class Initialized
DEBUG - 2011-08-01 15:45:54 --> Router Class Initialized
DEBUG - 2011-08-01 15:45:54 --> Output Class Initialized
DEBUG - 2011-08-01 15:45:54 --> Input Class Initialized
DEBUG - 2011-08-01 15:45:54 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-01 15:45:54 --> Language Class Initialized
DEBUG - 2011-08-01 15:45:54 --> Loader Class Initialized
DEBUG - 2011-08-01 15:45:54 --> Controller Class Initialized
DEBUG - 2011-08-01 15:45:54 --> Model Class Initialized
DEBUG - 2011-08-01 15:45:54 --> Model Class Initialized
DEBUG - 2011-08-01 15:45:54 --> Model Class Initialized
DEBUG - 2011-08-01 15:45:54 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-01 15:45:54 --> Database Driver Class Initialized
DEBUG - 2011-08-01 15:45:55 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-01 15:45:55 --> Helper loaded: url_helper
DEBUG - 2011-08-01 15:45:55 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-01 15:45:55 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-01 15:45:55 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-01 15:45:55 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-01 15:45:55 --> Final output sent to browser
DEBUG - 2011-08-01 15:45:55 --> Total execution time: 0.2349
DEBUG - 2011-08-01 15:45:55 --> Config Class Initialized
DEBUG - 2011-08-01 15:45:55 --> Hooks Class Initialized
DEBUG - 2011-08-01 15:45:55 --> Utf8 Class Initialized
DEBUG - 2011-08-01 15:45:55 --> UTF-8 Support Enabled
DEBUG - 2011-08-01 15:45:55 --> URI Class Initialized
DEBUG - 2011-08-01 15:45:55 --> Router Class Initialized
DEBUG - 2011-08-01 15:45:55 --> Output Class Initialized
DEBUG - 2011-08-01 15:45:55 --> Input Class Initialized
DEBUG - 2011-08-01 15:45:55 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-01 15:45:55 --> Language Class Initialized
DEBUG - 2011-08-01 15:45:55 --> Loader Class Initialized
DEBUG - 2011-08-01 15:45:55 --> Controller Class Initialized
DEBUG - 2011-08-01 15:45:55 --> Model Class Initialized
DEBUG - 2011-08-01 15:45:55 --> Model Class Initialized
DEBUG - 2011-08-01 15:45:55 --> Model Class Initialized
DEBUG - 2011-08-01 15:45:55 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-01 15:45:55 --> Database Driver Class Initialized
DEBUG - 2011-08-01 15:45:55 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-01 15:45:55 --> Helper loaded: url_helper
DEBUG - 2011-08-01 15:45:55 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-01 15:45:55 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-01 15:45:55 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-01 15:45:55 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-01 15:45:55 --> Final output sent to browser
DEBUG - 2011-08-01 15:45:55 --> Total execution time: 0.1432
DEBUG - 2011-08-01 15:46:04 --> Config Class Initialized
DEBUG - 2011-08-01 15:46:04 --> Hooks Class Initialized
DEBUG - 2011-08-01 15:46:04 --> Utf8 Class Initialized
DEBUG - 2011-08-01 15:46:04 --> UTF-8 Support Enabled
DEBUG - 2011-08-01 15:46:04 --> URI Class Initialized
DEBUG - 2011-08-01 15:46:04 --> Router Class Initialized
DEBUG - 2011-08-01 15:46:04 --> Output Class Initialized
DEBUG - 2011-08-01 15:46:04 --> Input Class Initialized
DEBUG - 2011-08-01 15:46:04 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-01 15:46:04 --> Language Class Initialized
DEBUG - 2011-08-01 15:46:04 --> Loader Class Initialized
DEBUG - 2011-08-01 15:46:04 --> Controller Class Initialized
DEBUG - 2011-08-01 15:46:04 --> Model Class Initialized
DEBUG - 2011-08-01 15:46:04 --> Model Class Initialized
DEBUG - 2011-08-01 15:46:04 --> Model Class Initialized
DEBUG - 2011-08-01 15:46:04 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-01 15:46:04 --> Database Driver Class Initialized
DEBUG - 2011-08-01 15:46:05 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-01 15:46:05 --> Helper loaded: url_helper
DEBUG - 2011-08-01 15:46:05 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-01 15:46:05 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-01 15:46:05 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-01 15:46:05 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-01 15:46:05 --> Final output sent to browser
DEBUG - 2011-08-01 15:46:05 --> Total execution time: 0.4429
DEBUG - 2011-08-01 15:46:06 --> Config Class Initialized
DEBUG - 2011-08-01 15:46:06 --> Hooks Class Initialized
DEBUG - 2011-08-01 15:46:06 --> Utf8 Class Initialized
DEBUG - 2011-08-01 15:46:06 --> UTF-8 Support Enabled
DEBUG - 2011-08-01 15:46:06 --> URI Class Initialized
DEBUG - 2011-08-01 15:46:06 --> Router Class Initialized
DEBUG - 2011-08-01 15:46:06 --> Output Class Initialized
DEBUG - 2011-08-01 15:46:06 --> Input Class Initialized
DEBUG - 2011-08-01 15:46:06 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-01 15:46:06 --> Language Class Initialized
DEBUG - 2011-08-01 15:46:06 --> Loader Class Initialized
DEBUG - 2011-08-01 15:46:06 --> Controller Class Initialized
DEBUG - 2011-08-01 15:46:06 --> Model Class Initialized
DEBUG - 2011-08-01 15:46:06 --> Model Class Initialized
DEBUG - 2011-08-01 15:46:06 --> Model Class Initialized
DEBUG - 2011-08-01 15:46:06 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-01 15:46:06 --> Database Driver Class Initialized
DEBUG - 2011-08-01 15:46:06 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-01 15:46:06 --> Helper loaded: url_helper
DEBUG - 2011-08-01 15:46:06 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-01 15:46:06 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-01 15:46:06 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-01 15:46:06 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-01 15:46:06 --> Final output sent to browser
DEBUG - 2011-08-01 15:46:06 --> Total execution time: 0.0643
DEBUG - 2011-08-01 15:46:12 --> Config Class Initialized
DEBUG - 2011-08-01 15:46:12 --> Hooks Class Initialized
DEBUG - 2011-08-01 15:46:12 --> Utf8 Class Initialized
DEBUG - 2011-08-01 15:46:12 --> UTF-8 Support Enabled
DEBUG - 2011-08-01 15:46:12 --> URI Class Initialized
DEBUG - 2011-08-01 15:46:12 --> Router Class Initialized
DEBUG - 2011-08-01 15:46:12 --> Output Class Initialized
DEBUG - 2011-08-01 15:46:12 --> Input Class Initialized
DEBUG - 2011-08-01 15:46:12 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-01 15:46:12 --> Language Class Initialized
DEBUG - 2011-08-01 15:46:12 --> Loader Class Initialized
DEBUG - 2011-08-01 15:46:12 --> Controller Class Initialized
DEBUG - 2011-08-01 15:46:12 --> Model Class Initialized
DEBUG - 2011-08-01 15:46:12 --> Model Class Initialized
DEBUG - 2011-08-01 15:46:12 --> Model Class Initialized
DEBUG - 2011-08-01 15:46:12 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-01 15:46:12 --> Database Driver Class Initialized
DEBUG - 2011-08-01 15:46:12 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-01 15:46:12 --> Helper loaded: url_helper
DEBUG - 2011-08-01 15:46:12 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-01 15:46:12 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-01 15:46:12 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-01 15:46:12 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-01 15:46:12 --> Final output sent to browser
DEBUG - 2011-08-01 15:46:12 --> Total execution time: 0.3984
DEBUG - 2011-08-01 15:46:13 --> Config Class Initialized
DEBUG - 2011-08-01 15:46:13 --> Hooks Class Initialized
DEBUG - 2011-08-01 15:46:13 --> Utf8 Class Initialized
DEBUG - 2011-08-01 15:46:13 --> UTF-8 Support Enabled
DEBUG - 2011-08-01 15:46:13 --> URI Class Initialized
DEBUG - 2011-08-01 15:46:13 --> Router Class Initialized
DEBUG - 2011-08-01 15:46:13 --> Output Class Initialized
DEBUG - 2011-08-01 15:46:13 --> Input Class Initialized
DEBUG - 2011-08-01 15:46:13 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-01 15:46:13 --> Language Class Initialized
DEBUG - 2011-08-01 15:46:13 --> Loader Class Initialized
DEBUG - 2011-08-01 15:46:13 --> Controller Class Initialized
DEBUG - 2011-08-01 15:46:13 --> Model Class Initialized
DEBUG - 2011-08-01 15:46:13 --> Model Class Initialized
DEBUG - 2011-08-01 15:46:13 --> Model Class Initialized
DEBUG - 2011-08-01 15:46:13 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-01 15:46:13 --> Database Driver Class Initialized
DEBUG - 2011-08-01 15:46:13 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-01 15:46:13 --> Helper loaded: url_helper
DEBUG - 2011-08-01 15:46:13 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-01 15:46:13 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-01 15:46:13 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-01 15:46:13 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-01 15:46:13 --> Final output sent to browser
DEBUG - 2011-08-01 15:46:13 --> Total execution time: 0.0655
DEBUG - 2011-08-01 15:46:17 --> Config Class Initialized
DEBUG - 2011-08-01 15:46:17 --> Hooks Class Initialized
DEBUG - 2011-08-01 15:46:17 --> Utf8 Class Initialized
DEBUG - 2011-08-01 15:46:17 --> UTF-8 Support Enabled
DEBUG - 2011-08-01 15:46:17 --> URI Class Initialized
DEBUG - 2011-08-01 15:46:17 --> Router Class Initialized
DEBUG - 2011-08-01 15:46:17 --> Output Class Initialized
DEBUG - 2011-08-01 15:46:17 --> Input Class Initialized
DEBUG - 2011-08-01 15:46:17 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-01 15:46:17 --> Language Class Initialized
DEBUG - 2011-08-01 15:46:17 --> Loader Class Initialized
DEBUG - 2011-08-01 15:46:17 --> Controller Class Initialized
DEBUG - 2011-08-01 15:46:17 --> Model Class Initialized
DEBUG - 2011-08-01 15:46:17 --> Model Class Initialized
DEBUG - 2011-08-01 15:46:17 --> Model Class Initialized
DEBUG - 2011-08-01 15:46:17 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-01 15:46:17 --> Database Driver Class Initialized
DEBUG - 2011-08-01 15:46:17 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-01 15:46:17 --> Helper loaded: url_helper
DEBUG - 2011-08-01 15:46:17 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-01 15:46:17 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-01 15:46:17 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-01 15:46:17 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-01 15:46:17 --> Final output sent to browser
DEBUG - 2011-08-01 15:46:17 --> Total execution time: 0.2835
DEBUG - 2011-08-01 15:46:18 --> Config Class Initialized
DEBUG - 2011-08-01 15:46:18 --> Hooks Class Initialized
DEBUG - 2011-08-01 15:46:18 --> Utf8 Class Initialized
DEBUG - 2011-08-01 15:46:18 --> UTF-8 Support Enabled
DEBUG - 2011-08-01 15:46:18 --> URI Class Initialized
DEBUG - 2011-08-01 15:46:18 --> Router Class Initialized
DEBUG - 2011-08-01 15:46:18 --> Output Class Initialized
DEBUG - 2011-08-01 15:46:18 --> Input Class Initialized
DEBUG - 2011-08-01 15:46:18 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-01 15:46:18 --> Language Class Initialized
DEBUG - 2011-08-01 15:46:18 --> Loader Class Initialized
DEBUG - 2011-08-01 15:46:18 --> Controller Class Initialized
DEBUG - 2011-08-01 15:46:18 --> Model Class Initialized
DEBUG - 2011-08-01 15:46:18 --> Model Class Initialized
DEBUG - 2011-08-01 15:46:18 --> Model Class Initialized
DEBUG - 2011-08-01 15:46:18 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-01 15:46:18 --> Database Driver Class Initialized
DEBUG - 2011-08-01 15:46:18 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-01 15:46:18 --> Helper loaded: url_helper
DEBUG - 2011-08-01 15:46:18 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-01 15:46:18 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-01 15:46:18 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-01 15:46:18 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-01 15:46:18 --> Final output sent to browser
DEBUG - 2011-08-01 15:46:18 --> Total execution time: 0.0736
DEBUG - 2011-08-01 15:46:26 --> Config Class Initialized
DEBUG - 2011-08-01 15:46:26 --> Hooks Class Initialized
DEBUG - 2011-08-01 15:46:26 --> Utf8 Class Initialized
DEBUG - 2011-08-01 15:46:26 --> UTF-8 Support Enabled
DEBUG - 2011-08-01 15:46:26 --> URI Class Initialized
DEBUG - 2011-08-01 15:46:26 --> Router Class Initialized
DEBUG - 2011-08-01 15:46:26 --> Output Class Initialized
DEBUG - 2011-08-01 15:46:26 --> Input Class Initialized
DEBUG - 2011-08-01 15:46:26 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-01 15:46:26 --> Language Class Initialized
DEBUG - 2011-08-01 15:46:26 --> Loader Class Initialized
DEBUG - 2011-08-01 15:46:26 --> Controller Class Initialized
DEBUG - 2011-08-01 15:46:26 --> Model Class Initialized
DEBUG - 2011-08-01 15:46:26 --> Model Class Initialized
DEBUG - 2011-08-01 15:46:26 --> Model Class Initialized
DEBUG - 2011-08-01 15:46:26 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-01 15:46:26 --> Database Driver Class Initialized
DEBUG - 2011-08-01 15:46:26 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-01 15:46:26 --> Helper loaded: url_helper
DEBUG - 2011-08-01 15:46:26 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-01 15:46:26 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-01 15:46:26 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-01 15:46:26 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-01 15:46:26 --> Final output sent to browser
DEBUG - 2011-08-01 15:46:26 --> Total execution time: 0.5104
DEBUG - 2011-08-01 15:46:27 --> Config Class Initialized
DEBUG - 2011-08-01 15:46:27 --> Hooks Class Initialized
DEBUG - 2011-08-01 15:46:27 --> Utf8 Class Initialized
DEBUG - 2011-08-01 15:46:27 --> UTF-8 Support Enabled
DEBUG - 2011-08-01 15:46:27 --> URI Class Initialized
DEBUG - 2011-08-01 15:46:27 --> Router Class Initialized
DEBUG - 2011-08-01 15:46:27 --> Output Class Initialized
DEBUG - 2011-08-01 15:46:27 --> Input Class Initialized
DEBUG - 2011-08-01 15:46:27 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-01 15:46:27 --> Language Class Initialized
DEBUG - 2011-08-01 15:46:27 --> Loader Class Initialized
DEBUG - 2011-08-01 15:46:27 --> Controller Class Initialized
DEBUG - 2011-08-01 15:46:27 --> Model Class Initialized
DEBUG - 2011-08-01 15:46:27 --> Model Class Initialized
DEBUG - 2011-08-01 15:46:27 --> Model Class Initialized
DEBUG - 2011-08-01 15:46:27 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-01 15:46:27 --> Database Driver Class Initialized
DEBUG - 2011-08-01 15:46:27 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-01 15:46:27 --> Helper loaded: url_helper
DEBUG - 2011-08-01 15:46:27 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-01 15:46:27 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-01 15:46:27 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-01 15:46:27 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-01 15:46:27 --> Final output sent to browser
DEBUG - 2011-08-01 15:46:27 --> Total execution time: 0.0419
DEBUG - 2011-08-01 15:46:32 --> Config Class Initialized
DEBUG - 2011-08-01 15:46:32 --> Hooks Class Initialized
DEBUG - 2011-08-01 15:46:32 --> Utf8 Class Initialized
DEBUG - 2011-08-01 15:46:32 --> UTF-8 Support Enabled
DEBUG - 2011-08-01 15:46:32 --> URI Class Initialized
DEBUG - 2011-08-01 15:46:32 --> Router Class Initialized
DEBUG - 2011-08-01 15:46:32 --> Output Class Initialized
DEBUG - 2011-08-01 15:46:32 --> Input Class Initialized
DEBUG - 2011-08-01 15:46:32 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-01 15:46:32 --> Language Class Initialized
DEBUG - 2011-08-01 15:46:32 --> Loader Class Initialized
DEBUG - 2011-08-01 15:46:32 --> Controller Class Initialized
DEBUG - 2011-08-01 15:46:32 --> Model Class Initialized
DEBUG - 2011-08-01 15:46:32 --> Model Class Initialized
DEBUG - 2011-08-01 15:46:32 --> Model Class Initialized
DEBUG - 2011-08-01 15:46:32 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-01 15:46:32 --> Database Driver Class Initialized
DEBUG - 2011-08-01 15:46:32 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-01 15:46:32 --> Helper loaded: url_helper
DEBUG - 2011-08-01 15:46:32 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-01 15:46:32 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-01 15:46:32 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-01 15:46:32 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-01 15:46:32 --> Final output sent to browser
DEBUG - 2011-08-01 15:46:32 --> Total execution time: 0.2898
DEBUG - 2011-08-01 15:46:35 --> Config Class Initialized
DEBUG - 2011-08-01 15:46:35 --> Hooks Class Initialized
DEBUG - 2011-08-01 15:46:35 --> Utf8 Class Initialized
DEBUG - 2011-08-01 15:46:35 --> UTF-8 Support Enabled
DEBUG - 2011-08-01 15:46:35 --> URI Class Initialized
DEBUG - 2011-08-01 15:46:35 --> Router Class Initialized
DEBUG - 2011-08-01 15:46:35 --> Output Class Initialized
DEBUG - 2011-08-01 15:46:35 --> Input Class Initialized
DEBUG - 2011-08-01 15:46:35 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-01 15:46:35 --> Language Class Initialized
DEBUG - 2011-08-01 15:46:35 --> Loader Class Initialized
DEBUG - 2011-08-01 15:46:35 --> Controller Class Initialized
DEBUG - 2011-08-01 15:46:35 --> Model Class Initialized
DEBUG - 2011-08-01 15:46:35 --> Model Class Initialized
DEBUG - 2011-08-01 15:46:35 --> Model Class Initialized
DEBUG - 2011-08-01 15:46:35 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-01 15:46:35 --> Database Driver Class Initialized
DEBUG - 2011-08-01 15:46:35 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-01 15:46:35 --> Helper loaded: url_helper
DEBUG - 2011-08-01 15:46:35 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-01 15:46:35 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-01 15:46:35 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-01 15:46:35 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-01 15:46:35 --> Final output sent to browser
DEBUG - 2011-08-01 15:46:35 --> Total execution time: 0.0797
DEBUG - 2011-08-01 15:46:38 --> Config Class Initialized
DEBUG - 2011-08-01 15:46:38 --> Hooks Class Initialized
DEBUG - 2011-08-01 15:46:38 --> Utf8 Class Initialized
DEBUG - 2011-08-01 15:46:38 --> UTF-8 Support Enabled
DEBUG - 2011-08-01 15:46:38 --> URI Class Initialized
DEBUG - 2011-08-01 15:46:38 --> Router Class Initialized
DEBUG - 2011-08-01 15:46:38 --> Output Class Initialized
DEBUG - 2011-08-01 15:46:38 --> Input Class Initialized
DEBUG - 2011-08-01 15:46:38 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-01 15:46:38 --> Language Class Initialized
DEBUG - 2011-08-01 15:46:38 --> Loader Class Initialized
DEBUG - 2011-08-01 15:46:38 --> Controller Class Initialized
DEBUG - 2011-08-01 15:46:38 --> Model Class Initialized
DEBUG - 2011-08-01 15:46:38 --> Model Class Initialized
DEBUG - 2011-08-01 15:46:38 --> Model Class Initialized
DEBUG - 2011-08-01 15:46:38 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-01 15:46:38 --> Database Driver Class Initialized
DEBUG - 2011-08-01 15:46:39 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-01 15:46:39 --> Helper loaded: url_helper
DEBUG - 2011-08-01 15:46:39 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-01 15:46:39 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-01 15:46:39 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-01 15:46:39 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-01 15:46:39 --> Final output sent to browser
DEBUG - 2011-08-01 15:46:39 --> Total execution time: 0.7467
DEBUG - 2011-08-01 15:46:43 --> Config Class Initialized
DEBUG - 2011-08-01 15:46:43 --> Hooks Class Initialized
DEBUG - 2011-08-01 15:46:43 --> Utf8 Class Initialized
DEBUG - 2011-08-01 15:46:43 --> UTF-8 Support Enabled
DEBUG - 2011-08-01 15:46:43 --> URI Class Initialized
DEBUG - 2011-08-01 15:46:43 --> Router Class Initialized
DEBUG - 2011-08-01 15:46:43 --> Output Class Initialized
DEBUG - 2011-08-01 15:46:43 --> Input Class Initialized
DEBUG - 2011-08-01 15:46:43 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-01 15:46:43 --> Language Class Initialized
DEBUG - 2011-08-01 15:46:43 --> Loader Class Initialized
DEBUG - 2011-08-01 15:46:43 --> Controller Class Initialized
DEBUG - 2011-08-01 15:46:43 --> Model Class Initialized
DEBUG - 2011-08-01 15:46:43 --> Model Class Initialized
DEBUG - 2011-08-01 15:46:43 --> Model Class Initialized
DEBUG - 2011-08-01 15:46:43 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-01 15:46:43 --> Database Driver Class Initialized
DEBUG - 2011-08-01 15:46:43 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-01 15:46:43 --> Helper loaded: url_helper
DEBUG - 2011-08-01 15:46:43 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-01 15:46:43 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-01 15:46:43 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-01 15:46:43 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-01 15:46:43 --> Final output sent to browser
DEBUG - 2011-08-01 15:46:43 --> Total execution time: 0.0526
DEBUG - 2011-08-01 15:46:44 --> Config Class Initialized
DEBUG - 2011-08-01 15:46:44 --> Hooks Class Initialized
DEBUG - 2011-08-01 15:46:44 --> Utf8 Class Initialized
DEBUG - 2011-08-01 15:46:44 --> UTF-8 Support Enabled
DEBUG - 2011-08-01 15:46:44 --> URI Class Initialized
DEBUG - 2011-08-01 15:46:44 --> Router Class Initialized
DEBUG - 2011-08-01 15:46:44 --> Output Class Initialized
DEBUG - 2011-08-01 15:46:44 --> Input Class Initialized
DEBUG - 2011-08-01 15:46:44 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-01 15:46:44 --> Language Class Initialized
DEBUG - 2011-08-01 15:46:44 --> Loader Class Initialized
DEBUG - 2011-08-01 15:46:44 --> Controller Class Initialized
DEBUG - 2011-08-01 15:46:44 --> Model Class Initialized
DEBUG - 2011-08-01 15:46:44 --> Model Class Initialized
DEBUG - 2011-08-01 15:46:44 --> Model Class Initialized
DEBUG - 2011-08-01 15:46:44 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-01 15:46:44 --> Database Driver Class Initialized
DEBUG - 2011-08-01 15:46:44 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-01 15:46:44 --> Helper loaded: url_helper
DEBUG - 2011-08-01 15:46:44 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-01 15:46:44 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-01 15:46:44 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-01 15:46:44 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-01 15:46:44 --> Final output sent to browser
DEBUG - 2011-08-01 15:46:44 --> Total execution time: 0.1857
DEBUG - 2011-08-01 15:46:58 --> Config Class Initialized
DEBUG - 2011-08-01 15:46:58 --> Hooks Class Initialized
DEBUG - 2011-08-01 15:46:58 --> Utf8 Class Initialized
DEBUG - 2011-08-01 15:46:58 --> UTF-8 Support Enabled
DEBUG - 2011-08-01 15:46:58 --> URI Class Initialized
DEBUG - 2011-08-01 15:46:58 --> Router Class Initialized
DEBUG - 2011-08-01 15:46:58 --> Output Class Initialized
DEBUG - 2011-08-01 15:46:58 --> Input Class Initialized
DEBUG - 2011-08-01 15:46:58 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-01 15:46:58 --> Language Class Initialized
DEBUG - 2011-08-01 15:46:58 --> Loader Class Initialized
DEBUG - 2011-08-01 15:46:58 --> Controller Class Initialized
DEBUG - 2011-08-01 15:46:58 --> Model Class Initialized
DEBUG - 2011-08-01 15:46:58 --> Model Class Initialized
DEBUG - 2011-08-01 15:46:58 --> Model Class Initialized
DEBUG - 2011-08-01 15:46:58 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-01 15:46:58 --> Database Driver Class Initialized
DEBUG - 2011-08-01 15:46:58 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-01 15:46:58 --> Helper loaded: url_helper
DEBUG - 2011-08-01 15:46:58 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-01 15:46:58 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-01 15:46:58 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-01 15:46:58 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-01 15:46:58 --> Final output sent to browser
DEBUG - 2011-08-01 15:46:58 --> Total execution time: 0.0464
DEBUG - 2011-08-01 16:37:25 --> Config Class Initialized
DEBUG - 2011-08-01 16:37:25 --> Hooks Class Initialized
DEBUG - 2011-08-01 16:37:25 --> Utf8 Class Initialized
DEBUG - 2011-08-01 16:37:25 --> UTF-8 Support Enabled
DEBUG - 2011-08-01 16:37:25 --> URI Class Initialized
DEBUG - 2011-08-01 16:37:25 --> Router Class Initialized
DEBUG - 2011-08-01 16:37:25 --> Output Class Initialized
DEBUG - 2011-08-01 16:37:25 --> Input Class Initialized
DEBUG - 2011-08-01 16:37:25 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-01 16:37:25 --> Language Class Initialized
DEBUG - 2011-08-01 16:37:25 --> Loader Class Initialized
DEBUG - 2011-08-01 16:37:25 --> Controller Class Initialized
ERROR - 2011-08-01 16:37:25 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-01 16:37:25 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-01 16:37:25 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-01 16:37:25 --> Model Class Initialized
DEBUG - 2011-08-01 16:37:25 --> Model Class Initialized
DEBUG - 2011-08-01 16:37:25 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-01 16:37:25 --> Database Driver Class Initialized
DEBUG - 2011-08-01 16:37:25 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-01 16:37:25 --> Helper loaded: url_helper
DEBUG - 2011-08-01 16:37:25 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-01 16:37:25 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-01 16:37:25 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-01 16:37:25 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-01 16:37:25 --> Final output sent to browser
DEBUG - 2011-08-01 16:37:25 --> Total execution time: 0.0460
DEBUG - 2011-08-01 17:00:13 --> Config Class Initialized
DEBUG - 2011-08-01 17:00:13 --> Hooks Class Initialized
DEBUG - 2011-08-01 17:00:13 --> Utf8 Class Initialized
DEBUG - 2011-08-01 17:00:13 --> UTF-8 Support Enabled
DEBUG - 2011-08-01 17:00:13 --> URI Class Initialized
DEBUG - 2011-08-01 17:00:13 --> Router Class Initialized
DEBUG - 2011-08-01 17:00:13 --> Output Class Initialized
DEBUG - 2011-08-01 17:00:13 --> Input Class Initialized
DEBUG - 2011-08-01 17:00:13 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-01 17:00:13 --> Language Class Initialized
DEBUG - 2011-08-01 17:00:13 --> Loader Class Initialized
DEBUG - 2011-08-01 17:00:13 --> Controller Class Initialized
ERROR - 2011-08-01 17:00:13 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-01 17:00:13 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-01 17:00:13 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-01 17:00:13 --> Model Class Initialized
DEBUG - 2011-08-01 17:00:13 --> Model Class Initialized
DEBUG - 2011-08-01 17:00:13 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-01 17:00:13 --> Database Driver Class Initialized
DEBUG - 2011-08-01 17:00:13 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-01 17:00:13 --> Helper loaded: url_helper
DEBUG - 2011-08-01 17:00:13 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-01 17:00:13 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-01 17:00:13 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-01 17:00:13 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-01 17:00:14 --> Config Class Initialized
DEBUG - 2011-08-01 17:00:14 --> Hooks Class Initialized
DEBUG - 2011-08-01 17:00:14 --> Utf8 Class Initialized
DEBUG - 2011-08-01 17:00:14 --> UTF-8 Support Enabled
DEBUG - 2011-08-01 17:00:14 --> URI Class Initialized
DEBUG - 2011-08-01 17:00:14 --> Router Class Initialized
DEBUG - 2011-08-01 17:00:14 --> Output Class Initialized
DEBUG - 2011-08-01 17:00:14 --> Input Class Initialized
DEBUG - 2011-08-01 17:00:14 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-01 17:00:14 --> Language Class Initialized
DEBUG - 2011-08-01 17:00:14 --> Loader Class Initialized
DEBUG - 2011-08-01 17:00:14 --> Controller Class Initialized
ERROR - 2011-08-01 17:00:14 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-01 17:00:14 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-01 17:00:14 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-01 17:00:14 --> Model Class Initialized
DEBUG - 2011-08-01 17:00:14 --> Model Class Initialized
DEBUG - 2011-08-01 17:00:14 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-01 17:00:14 --> Database Driver Class Initialized
DEBUG - 2011-08-01 17:00:14 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-01 17:00:14 --> Helper loaded: url_helper
DEBUG - 2011-08-01 17:00:14 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-01 17:00:14 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-01 17:00:14 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-01 17:00:14 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-01 17:00:14 --> Final output sent to browser
DEBUG - 2011-08-01 17:00:14 --> Total execution time: 0.0550
DEBUG - 2011-08-01 17:00:14 --> Config Class Initialized
DEBUG - 2011-08-01 17:00:14 --> Hooks Class Initialized
DEBUG - 2011-08-01 17:00:14 --> Utf8 Class Initialized
DEBUG - 2011-08-01 17:00:14 --> UTF-8 Support Enabled
DEBUG - 2011-08-01 17:00:14 --> URI Class Initialized
DEBUG - 2011-08-01 17:00:14 --> Router Class Initialized
DEBUG - 2011-08-01 17:00:14 --> Output Class Initialized
DEBUG - 2011-08-01 17:00:14 --> Input Class Initialized
DEBUG - 2011-08-01 17:00:14 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-01 17:00:14 --> Language Class Initialized
DEBUG - 2011-08-01 17:00:14 --> Loader Class Initialized
DEBUG - 2011-08-01 17:00:14 --> Controller Class Initialized
DEBUG - 2011-08-01 17:00:14 --> Model Class Initialized
DEBUG - 2011-08-01 17:00:14 --> Model Class Initialized
DEBUG - 2011-08-01 17:00:14 --> Model Class Initialized
DEBUG - 2011-08-01 17:00:14 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-01 17:00:14 --> Database Driver Class Initialized
DEBUG - 2011-08-01 17:00:14 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-01 17:00:14 --> Helper loaded: url_helper
DEBUG - 2011-08-01 17:00:14 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-01 17:00:14 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-01 17:00:14 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-01 17:00:14 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-01 17:00:14 --> Config Class Initialized
DEBUG - 2011-08-01 17:00:14 --> Hooks Class Initialized
DEBUG - 2011-08-01 17:00:14 --> Utf8 Class Initialized
DEBUG - 2011-08-01 17:00:14 --> UTF-8 Support Enabled
DEBUG - 2011-08-01 17:00:14 --> URI Class Initialized
DEBUG - 2011-08-01 17:00:14 --> Router Class Initialized
DEBUG - 2011-08-01 17:00:14 --> Output Class Initialized
DEBUG - 2011-08-01 17:00:14 --> Input Class Initialized
DEBUG - 2011-08-01 17:00:14 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-01 17:00:14 --> Language Class Initialized
DEBUG - 2011-08-01 17:00:14 --> Loader Class Initialized
DEBUG - 2011-08-01 17:00:14 --> Controller Class Initialized
DEBUG - 2011-08-01 17:00:14 --> Model Class Initialized
DEBUG - 2011-08-01 17:00:14 --> Model Class Initialized
DEBUG - 2011-08-01 17:00:14 --> Model Class Initialized
DEBUG - 2011-08-01 17:00:14 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-01 17:00:14 --> Database Driver Class Initialized
DEBUG - 2011-08-01 17:00:14 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-01 17:00:14 --> Helper loaded: url_helper
DEBUG - 2011-08-01 17:00:14 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-01 17:00:14 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-01 17:00:14 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-01 17:00:14 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-01 17:00:14 --> Final output sent to browser
DEBUG - 2011-08-01 17:00:14 --> Total execution time: 0.0472
DEBUG - 2011-08-01 17:05:26 --> Config Class Initialized
DEBUG - 2011-08-01 17:05:26 --> Hooks Class Initialized
DEBUG - 2011-08-01 17:05:26 --> Utf8 Class Initialized
DEBUG - 2011-08-01 17:05:26 --> UTF-8 Support Enabled
DEBUG - 2011-08-01 17:05:26 --> URI Class Initialized
DEBUG - 2011-08-01 17:05:26 --> Router Class Initialized
DEBUG - 2011-08-01 17:05:26 --> Output Class Initialized
DEBUG - 2011-08-01 17:05:26 --> Input Class Initialized
DEBUG - 2011-08-01 17:05:26 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-01 17:05:26 --> Language Class Initialized
DEBUG - 2011-08-01 17:05:26 --> Loader Class Initialized
DEBUG - 2011-08-01 17:05:26 --> Controller Class Initialized
DEBUG - 2011-08-01 17:05:26 --> Model Class Initialized
DEBUG - 2011-08-01 17:05:26 --> Model Class Initialized
DEBUG - 2011-08-01 17:05:26 --> Model Class Initialized
DEBUG - 2011-08-01 17:05:26 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-01 17:05:26 --> Database Driver Class Initialized
DEBUG - 2011-08-01 17:05:26 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-01 17:05:26 --> Helper loaded: url_helper
DEBUG - 2011-08-01 17:05:26 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-01 17:05:26 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-01 17:05:26 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-01 17:05:26 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-01 17:05:26 --> Final output sent to browser
DEBUG - 2011-08-01 17:05:26 --> Total execution time: 0.0921
DEBUG - 2011-08-01 17:05:29 --> Config Class Initialized
DEBUG - 2011-08-01 17:05:29 --> Hooks Class Initialized
DEBUG - 2011-08-01 17:05:29 --> Utf8 Class Initialized
DEBUG - 2011-08-01 17:05:29 --> UTF-8 Support Enabled
DEBUG - 2011-08-01 17:05:29 --> URI Class Initialized
DEBUG - 2011-08-01 17:05:29 --> Router Class Initialized
ERROR - 2011-08-01 17:05:29 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-01 17:05:36 --> Config Class Initialized
DEBUG - 2011-08-01 17:05:36 --> Hooks Class Initialized
DEBUG - 2011-08-01 17:05:36 --> Utf8 Class Initialized
DEBUG - 2011-08-01 17:05:36 --> UTF-8 Support Enabled
DEBUG - 2011-08-01 17:05:36 --> URI Class Initialized
DEBUG - 2011-08-01 17:05:36 --> Router Class Initialized
DEBUG - 2011-08-01 17:05:36 --> Output Class Initialized
DEBUG - 2011-08-01 17:05:36 --> Input Class Initialized
DEBUG - 2011-08-01 17:05:36 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-01 17:05:36 --> Language Class Initialized
DEBUG - 2011-08-01 17:05:36 --> Loader Class Initialized
DEBUG - 2011-08-01 17:05:36 --> Controller Class Initialized
DEBUG - 2011-08-01 17:05:36 --> Model Class Initialized
DEBUG - 2011-08-01 17:05:36 --> Model Class Initialized
DEBUG - 2011-08-01 17:05:36 --> Model Class Initialized
DEBUG - 2011-08-01 17:05:36 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-01 17:05:36 --> Database Driver Class Initialized
DEBUG - 2011-08-01 17:05:36 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-01 17:05:36 --> Helper loaded: url_helper
DEBUG - 2011-08-01 17:05:36 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-01 17:05:36 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-01 17:05:36 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-01 17:05:36 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-01 17:05:36 --> Final output sent to browser
DEBUG - 2011-08-01 17:05:36 --> Total execution time: 0.2377
DEBUG - 2011-08-01 17:05:40 --> Config Class Initialized
DEBUG - 2011-08-01 17:05:40 --> Hooks Class Initialized
DEBUG - 2011-08-01 17:05:40 --> Utf8 Class Initialized
DEBUG - 2011-08-01 17:05:40 --> UTF-8 Support Enabled
DEBUG - 2011-08-01 17:05:40 --> URI Class Initialized
DEBUG - 2011-08-01 17:05:40 --> Router Class Initialized
DEBUG - 2011-08-01 17:05:40 --> Output Class Initialized
DEBUG - 2011-08-01 17:05:40 --> Input Class Initialized
DEBUG - 2011-08-01 17:05:40 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-01 17:05:40 --> Language Class Initialized
DEBUG - 2011-08-01 17:05:40 --> Loader Class Initialized
DEBUG - 2011-08-01 17:05:40 --> Controller Class Initialized
DEBUG - 2011-08-01 17:05:40 --> Model Class Initialized
DEBUG - 2011-08-01 17:05:40 --> Model Class Initialized
DEBUG - 2011-08-01 17:05:40 --> Model Class Initialized
DEBUG - 2011-08-01 17:05:40 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-01 17:05:40 --> Database Driver Class Initialized
DEBUG - 2011-08-01 17:05:40 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-01 17:05:40 --> Helper loaded: url_helper
DEBUG - 2011-08-01 17:05:40 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-01 17:05:40 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-01 17:05:40 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-01 17:05:40 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-01 17:05:40 --> Final output sent to browser
DEBUG - 2011-08-01 17:05:40 --> Total execution time: 0.0450
DEBUG - 2011-08-01 17:05:43 --> Config Class Initialized
DEBUG - 2011-08-01 17:05:43 --> Hooks Class Initialized
DEBUG - 2011-08-01 17:05:43 --> Utf8 Class Initialized
DEBUG - 2011-08-01 17:05:43 --> UTF-8 Support Enabled
DEBUG - 2011-08-01 17:05:43 --> URI Class Initialized
DEBUG - 2011-08-01 17:05:43 --> Router Class Initialized
DEBUG - 2011-08-01 17:05:43 --> Output Class Initialized
DEBUG - 2011-08-01 17:05:43 --> Input Class Initialized
DEBUG - 2011-08-01 17:05:43 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-01 17:05:43 --> Language Class Initialized
DEBUG - 2011-08-01 17:05:43 --> Loader Class Initialized
DEBUG - 2011-08-01 17:05:43 --> Controller Class Initialized
DEBUG - 2011-08-01 17:05:43 --> Model Class Initialized
DEBUG - 2011-08-01 17:05:43 --> Model Class Initialized
DEBUG - 2011-08-01 17:05:43 --> Model Class Initialized
DEBUG - 2011-08-01 17:05:43 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-01 17:05:43 --> Database Driver Class Initialized
DEBUG - 2011-08-01 17:05:43 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-01 17:05:43 --> Helper loaded: url_helper
DEBUG - 2011-08-01 17:05:43 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-01 17:05:43 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-01 17:05:43 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-01 17:05:43 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-01 17:05:43 --> Final output sent to browser
DEBUG - 2011-08-01 17:05:43 --> Total execution time: 0.2896
DEBUG - 2011-08-01 17:05:44 --> Config Class Initialized
DEBUG - 2011-08-01 17:05:44 --> Hooks Class Initialized
DEBUG - 2011-08-01 17:05:44 --> Utf8 Class Initialized
DEBUG - 2011-08-01 17:05:44 --> UTF-8 Support Enabled
DEBUG - 2011-08-01 17:05:44 --> URI Class Initialized
DEBUG - 2011-08-01 17:05:44 --> Router Class Initialized
DEBUG - 2011-08-01 17:05:44 --> Output Class Initialized
DEBUG - 2011-08-01 17:05:44 --> Input Class Initialized
DEBUG - 2011-08-01 17:05:44 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-01 17:05:44 --> Language Class Initialized
DEBUG - 2011-08-01 17:05:44 --> Loader Class Initialized
DEBUG - 2011-08-01 17:05:44 --> Controller Class Initialized
DEBUG - 2011-08-01 17:05:44 --> Model Class Initialized
DEBUG - 2011-08-01 17:05:44 --> Model Class Initialized
DEBUG - 2011-08-01 17:05:44 --> Model Class Initialized
DEBUG - 2011-08-01 17:05:44 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-01 17:05:44 --> Database Driver Class Initialized
DEBUG - 2011-08-01 17:05:44 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-01 17:05:44 --> Helper loaded: url_helper
DEBUG - 2011-08-01 17:05:44 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-01 17:05:44 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-01 17:05:44 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-01 17:05:44 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-01 17:05:44 --> Final output sent to browser
DEBUG - 2011-08-01 17:05:44 --> Total execution time: 0.0442
DEBUG - 2011-08-01 17:05:53 --> Config Class Initialized
DEBUG - 2011-08-01 17:05:53 --> Hooks Class Initialized
DEBUG - 2011-08-01 17:05:53 --> Utf8 Class Initialized
DEBUG - 2011-08-01 17:05:53 --> UTF-8 Support Enabled
DEBUG - 2011-08-01 17:05:53 --> URI Class Initialized
DEBUG - 2011-08-01 17:05:53 --> Router Class Initialized
DEBUG - 2011-08-01 17:05:53 --> Output Class Initialized
DEBUG - 2011-08-01 17:05:53 --> Input Class Initialized
DEBUG - 2011-08-01 17:05:53 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-01 17:05:53 --> Language Class Initialized
DEBUG - 2011-08-01 17:05:53 --> Loader Class Initialized
DEBUG - 2011-08-01 17:05:53 --> Controller Class Initialized
DEBUG - 2011-08-01 17:05:53 --> Model Class Initialized
DEBUG - 2011-08-01 17:05:53 --> Model Class Initialized
DEBUG - 2011-08-01 17:05:53 --> Model Class Initialized
DEBUG - 2011-08-01 17:05:53 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-01 17:05:53 --> Database Driver Class Initialized
DEBUG - 2011-08-01 17:05:54 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-01 17:05:54 --> Helper loaded: url_helper
DEBUG - 2011-08-01 17:05:54 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-01 17:05:54 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-01 17:05:54 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-01 17:05:54 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-01 17:05:54 --> Final output sent to browser
DEBUG - 2011-08-01 17:05:54 --> Total execution time: 0.2248
DEBUG - 2011-08-01 17:05:56 --> Config Class Initialized
DEBUG - 2011-08-01 17:05:56 --> Hooks Class Initialized
DEBUG - 2011-08-01 17:05:56 --> Utf8 Class Initialized
DEBUG - 2011-08-01 17:05:56 --> UTF-8 Support Enabled
DEBUG - 2011-08-01 17:05:56 --> URI Class Initialized
DEBUG - 2011-08-01 17:05:56 --> Router Class Initialized
DEBUG - 2011-08-01 17:05:56 --> Output Class Initialized
DEBUG - 2011-08-01 17:05:56 --> Input Class Initialized
DEBUG - 2011-08-01 17:05:56 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-01 17:05:56 --> Language Class Initialized
DEBUG - 2011-08-01 17:05:56 --> Loader Class Initialized
DEBUG - 2011-08-01 17:05:56 --> Controller Class Initialized
DEBUG - 2011-08-01 17:05:56 --> Model Class Initialized
DEBUG - 2011-08-01 17:05:56 --> Model Class Initialized
DEBUG - 2011-08-01 17:05:56 --> Model Class Initialized
DEBUG - 2011-08-01 17:05:56 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-01 17:05:56 --> Database Driver Class Initialized
DEBUG - 2011-08-01 17:05:56 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-01 17:05:56 --> Helper loaded: url_helper
DEBUG - 2011-08-01 17:05:56 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-01 17:05:56 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-01 17:05:56 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-01 17:05:56 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-01 17:05:56 --> Final output sent to browser
DEBUG - 2011-08-01 17:05:56 --> Total execution time: 0.0435
DEBUG - 2011-08-01 17:06:02 --> Config Class Initialized
DEBUG - 2011-08-01 17:06:02 --> Hooks Class Initialized
DEBUG - 2011-08-01 17:06:02 --> Utf8 Class Initialized
DEBUG - 2011-08-01 17:06:02 --> UTF-8 Support Enabled
DEBUG - 2011-08-01 17:06:02 --> URI Class Initialized
DEBUG - 2011-08-01 17:06:02 --> Router Class Initialized
DEBUG - 2011-08-01 17:06:02 --> Output Class Initialized
DEBUG - 2011-08-01 17:06:02 --> Input Class Initialized
DEBUG - 2011-08-01 17:06:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-01 17:06:02 --> Language Class Initialized
DEBUG - 2011-08-01 17:06:02 --> Loader Class Initialized
DEBUG - 2011-08-01 17:06:02 --> Controller Class Initialized
DEBUG - 2011-08-01 17:06:02 --> Model Class Initialized
DEBUG - 2011-08-01 17:06:02 --> Model Class Initialized
DEBUG - 2011-08-01 17:06:02 --> Model Class Initialized
DEBUG - 2011-08-01 17:06:02 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-01 17:06:02 --> Database Driver Class Initialized
DEBUG - 2011-08-01 17:06:02 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-01 17:06:02 --> Helper loaded: url_helper
DEBUG - 2011-08-01 17:06:02 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-01 17:06:02 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-01 17:06:02 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-01 17:06:02 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-01 17:06:02 --> Final output sent to browser
DEBUG - 2011-08-01 17:06:02 --> Total execution time: 0.3083
DEBUG - 2011-08-01 17:06:12 --> Config Class Initialized
DEBUG - 2011-08-01 17:06:12 --> Hooks Class Initialized
DEBUG - 2011-08-01 17:06:12 --> Utf8 Class Initialized
DEBUG - 2011-08-01 17:06:12 --> UTF-8 Support Enabled
DEBUG - 2011-08-01 17:06:12 --> URI Class Initialized
DEBUG - 2011-08-01 17:06:12 --> Router Class Initialized
DEBUG - 2011-08-01 17:06:12 --> Output Class Initialized
DEBUG - 2011-08-01 17:06:12 --> Input Class Initialized
DEBUG - 2011-08-01 17:06:12 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-01 17:06:12 --> Language Class Initialized
DEBUG - 2011-08-01 17:06:12 --> Loader Class Initialized
DEBUG - 2011-08-01 17:06:12 --> Controller Class Initialized
DEBUG - 2011-08-01 17:06:12 --> Model Class Initialized
DEBUG - 2011-08-01 17:06:12 --> Model Class Initialized
DEBUG - 2011-08-01 17:06:12 --> Model Class Initialized
DEBUG - 2011-08-01 17:06:12 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-01 17:06:12 --> Database Driver Class Initialized
DEBUG - 2011-08-01 17:06:12 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-01 17:06:12 --> Helper loaded: url_helper
DEBUG - 2011-08-01 17:06:12 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-01 17:06:12 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-01 17:06:12 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-01 17:06:12 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-01 17:06:12 --> Final output sent to browser
DEBUG - 2011-08-01 17:06:12 --> Total execution time: 0.2064
DEBUG - 2011-08-01 17:06:19 --> Config Class Initialized
DEBUG - 2011-08-01 17:06:19 --> Hooks Class Initialized
DEBUG - 2011-08-01 17:06:19 --> Utf8 Class Initialized
DEBUG - 2011-08-01 17:06:19 --> UTF-8 Support Enabled
DEBUG - 2011-08-01 17:06:19 --> URI Class Initialized
DEBUG - 2011-08-01 17:06:19 --> Router Class Initialized
DEBUG - 2011-08-01 17:06:19 --> Output Class Initialized
DEBUG - 2011-08-01 17:06:19 --> Input Class Initialized
DEBUG - 2011-08-01 17:06:19 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-01 17:06:19 --> Language Class Initialized
DEBUG - 2011-08-01 17:06:19 --> Loader Class Initialized
DEBUG - 2011-08-01 17:06:19 --> Controller Class Initialized
DEBUG - 2011-08-01 17:06:19 --> Model Class Initialized
DEBUG - 2011-08-01 17:06:19 --> Model Class Initialized
DEBUG - 2011-08-01 17:06:19 --> Model Class Initialized
DEBUG - 2011-08-01 17:06:19 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-01 17:06:19 --> Database Driver Class Initialized
DEBUG - 2011-08-01 17:06:19 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-01 17:06:19 --> Helper loaded: url_helper
DEBUG - 2011-08-01 17:06:19 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-01 17:06:19 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-01 17:06:19 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-01 17:06:19 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-01 17:06:19 --> Final output sent to browser
DEBUG - 2011-08-01 17:06:19 --> Total execution time: 0.5222
DEBUG - 2011-08-01 17:06:33 --> Config Class Initialized
DEBUG - 2011-08-01 17:06:33 --> Hooks Class Initialized
DEBUG - 2011-08-01 17:06:33 --> Utf8 Class Initialized
DEBUG - 2011-08-01 17:06:33 --> UTF-8 Support Enabled
DEBUG - 2011-08-01 17:06:33 --> URI Class Initialized
DEBUG - 2011-08-01 17:06:33 --> Router Class Initialized
DEBUG - 2011-08-01 17:06:33 --> Output Class Initialized
DEBUG - 2011-08-01 17:06:33 --> Input Class Initialized
DEBUG - 2011-08-01 17:06:33 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-01 17:06:33 --> Language Class Initialized
DEBUG - 2011-08-01 17:06:33 --> Loader Class Initialized
DEBUG - 2011-08-01 17:06:33 --> Controller Class Initialized
DEBUG - 2011-08-01 17:06:33 --> Model Class Initialized
DEBUG - 2011-08-01 17:06:33 --> Model Class Initialized
DEBUG - 2011-08-01 17:06:33 --> Model Class Initialized
DEBUG - 2011-08-01 17:06:33 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-01 17:06:33 --> Database Driver Class Initialized
DEBUG - 2011-08-01 17:06:33 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-01 17:06:33 --> Helper loaded: url_helper
DEBUG - 2011-08-01 17:06:33 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-01 17:06:33 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-01 17:06:33 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-01 17:06:33 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-01 17:06:33 --> Final output sent to browser
DEBUG - 2011-08-01 17:06:33 --> Total execution time: 0.4884
DEBUG - 2011-08-01 17:06:49 --> Config Class Initialized
DEBUG - 2011-08-01 17:06:49 --> Hooks Class Initialized
DEBUG - 2011-08-01 17:06:49 --> Utf8 Class Initialized
DEBUG - 2011-08-01 17:06:49 --> UTF-8 Support Enabled
DEBUG - 2011-08-01 17:06:49 --> URI Class Initialized
DEBUG - 2011-08-01 17:06:49 --> Router Class Initialized
DEBUG - 2011-08-01 17:06:49 --> Output Class Initialized
DEBUG - 2011-08-01 17:06:49 --> Input Class Initialized
DEBUG - 2011-08-01 17:06:49 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-01 17:06:49 --> Language Class Initialized
DEBUG - 2011-08-01 17:06:49 --> Loader Class Initialized
DEBUG - 2011-08-01 17:06:49 --> Controller Class Initialized
DEBUG - 2011-08-01 17:06:49 --> Model Class Initialized
DEBUG - 2011-08-01 17:06:49 --> Model Class Initialized
DEBUG - 2011-08-01 17:06:49 --> Model Class Initialized
DEBUG - 2011-08-01 17:06:49 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-01 17:06:49 --> Database Driver Class Initialized
DEBUG - 2011-08-01 17:06:50 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-01 17:06:50 --> Helper loaded: url_helper
DEBUG - 2011-08-01 17:06:50 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-01 17:06:50 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-01 17:06:50 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-01 17:06:50 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-01 17:06:50 --> Final output sent to browser
DEBUG - 2011-08-01 17:06:50 --> Total execution time: 0.5552
DEBUG - 2011-08-01 17:06:57 --> Config Class Initialized
DEBUG - 2011-08-01 17:06:57 --> Hooks Class Initialized
DEBUG - 2011-08-01 17:06:57 --> Utf8 Class Initialized
DEBUG - 2011-08-01 17:06:57 --> UTF-8 Support Enabled
DEBUG - 2011-08-01 17:06:57 --> URI Class Initialized
DEBUG - 2011-08-01 17:06:57 --> Router Class Initialized
DEBUG - 2011-08-01 17:06:57 --> Output Class Initialized
DEBUG - 2011-08-01 17:06:57 --> Input Class Initialized
DEBUG - 2011-08-01 17:06:57 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-01 17:06:57 --> Language Class Initialized
DEBUG - 2011-08-01 17:06:57 --> Loader Class Initialized
DEBUG - 2011-08-01 17:06:57 --> Controller Class Initialized
DEBUG - 2011-08-01 17:06:57 --> Model Class Initialized
DEBUG - 2011-08-01 17:06:57 --> Model Class Initialized
DEBUG - 2011-08-01 17:06:57 --> Model Class Initialized
DEBUG - 2011-08-01 17:06:57 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-01 17:06:57 --> Database Driver Class Initialized
DEBUG - 2011-08-01 17:06:57 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-01 17:06:57 --> Helper loaded: url_helper
DEBUG - 2011-08-01 17:06:57 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-01 17:06:57 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-01 17:06:57 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-01 17:06:57 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-01 17:06:57 --> Final output sent to browser
DEBUG - 2011-08-01 17:06:57 --> Total execution time: 0.2092
DEBUG - 2011-08-01 17:07:14 --> Config Class Initialized
DEBUG - 2011-08-01 17:07:14 --> Hooks Class Initialized
DEBUG - 2011-08-01 17:07:14 --> Utf8 Class Initialized
DEBUG - 2011-08-01 17:07:14 --> UTF-8 Support Enabled
DEBUG - 2011-08-01 17:07:14 --> URI Class Initialized
DEBUG - 2011-08-01 17:07:14 --> Router Class Initialized
DEBUG - 2011-08-01 17:07:14 --> Output Class Initialized
DEBUG - 2011-08-01 17:07:14 --> Input Class Initialized
DEBUG - 2011-08-01 17:07:14 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-01 17:07:14 --> Language Class Initialized
DEBUG - 2011-08-01 17:07:14 --> Loader Class Initialized
DEBUG - 2011-08-01 17:07:14 --> Controller Class Initialized
DEBUG - 2011-08-01 17:07:14 --> Model Class Initialized
DEBUG - 2011-08-01 17:07:14 --> Model Class Initialized
DEBUG - 2011-08-01 17:07:14 --> Model Class Initialized
DEBUG - 2011-08-01 17:07:14 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-01 17:07:14 --> Database Driver Class Initialized
DEBUG - 2011-08-01 17:07:15 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-01 17:07:15 --> Helper loaded: url_helper
DEBUG - 2011-08-01 17:07:15 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-01 17:07:15 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-01 17:07:15 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-01 17:07:15 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-01 17:07:15 --> Final output sent to browser
DEBUG - 2011-08-01 17:07:15 --> Total execution time: 0.2606
DEBUG - 2011-08-01 17:07:33 --> Config Class Initialized
DEBUG - 2011-08-01 17:07:33 --> Hooks Class Initialized
DEBUG - 2011-08-01 17:07:33 --> Utf8 Class Initialized
DEBUG - 2011-08-01 17:07:33 --> UTF-8 Support Enabled
DEBUG - 2011-08-01 17:07:33 --> URI Class Initialized
DEBUG - 2011-08-01 17:07:33 --> Router Class Initialized
DEBUG - 2011-08-01 17:07:33 --> Output Class Initialized
DEBUG - 2011-08-01 17:07:33 --> Input Class Initialized
DEBUG - 2011-08-01 17:07:33 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-01 17:07:33 --> Language Class Initialized
DEBUG - 2011-08-01 17:07:33 --> Loader Class Initialized
DEBUG - 2011-08-01 17:07:33 --> Controller Class Initialized
DEBUG - 2011-08-01 17:07:33 --> Model Class Initialized
DEBUG - 2011-08-01 17:07:33 --> Model Class Initialized
DEBUG - 2011-08-01 17:07:33 --> Model Class Initialized
DEBUG - 2011-08-01 17:07:33 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-01 17:07:33 --> Database Driver Class Initialized
DEBUG - 2011-08-01 17:07:34 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-01 17:07:34 --> Helper loaded: url_helper
DEBUG - 2011-08-01 17:07:34 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-01 17:07:34 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-01 17:07:34 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-01 17:07:34 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-01 17:07:34 --> Final output sent to browser
DEBUG - 2011-08-01 17:07:34 --> Total execution time: 0.3465
DEBUG - 2011-08-01 17:07:40 --> Config Class Initialized
DEBUG - 2011-08-01 17:07:40 --> Hooks Class Initialized
DEBUG - 2011-08-01 17:07:40 --> Utf8 Class Initialized
DEBUG - 2011-08-01 17:07:40 --> UTF-8 Support Enabled
DEBUG - 2011-08-01 17:07:40 --> URI Class Initialized
DEBUG - 2011-08-01 17:07:40 --> Router Class Initialized
DEBUG - 2011-08-01 17:07:40 --> Output Class Initialized
DEBUG - 2011-08-01 17:07:40 --> Input Class Initialized
DEBUG - 2011-08-01 17:07:40 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-01 17:07:40 --> Language Class Initialized
DEBUG - 2011-08-01 17:07:40 --> Loader Class Initialized
DEBUG - 2011-08-01 17:07:40 --> Controller Class Initialized
DEBUG - 2011-08-01 17:07:40 --> Model Class Initialized
DEBUG - 2011-08-01 17:07:40 --> Model Class Initialized
DEBUG - 2011-08-01 17:07:40 --> Model Class Initialized
DEBUG - 2011-08-01 17:07:40 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-01 17:07:40 --> Database Driver Class Initialized
DEBUG - 2011-08-01 17:07:40 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-01 17:07:40 --> Helper loaded: url_helper
DEBUG - 2011-08-01 17:07:40 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-01 17:07:40 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-01 17:07:40 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-01 17:07:40 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-01 17:07:40 --> Final output sent to browser
DEBUG - 2011-08-01 17:07:40 --> Total execution time: 0.3688
DEBUG - 2011-08-01 17:07:45 --> Config Class Initialized
DEBUG - 2011-08-01 17:07:45 --> Hooks Class Initialized
DEBUG - 2011-08-01 17:07:45 --> Utf8 Class Initialized
DEBUG - 2011-08-01 17:07:45 --> UTF-8 Support Enabled
DEBUG - 2011-08-01 17:07:45 --> URI Class Initialized
DEBUG - 2011-08-01 17:07:45 --> Router Class Initialized
DEBUG - 2011-08-01 17:07:45 --> Output Class Initialized
DEBUG - 2011-08-01 17:07:45 --> Input Class Initialized
DEBUG - 2011-08-01 17:07:45 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-01 17:07:45 --> Language Class Initialized
DEBUG - 2011-08-01 17:07:45 --> Loader Class Initialized
DEBUG - 2011-08-01 17:07:45 --> Controller Class Initialized
DEBUG - 2011-08-01 17:07:45 --> Model Class Initialized
DEBUG - 2011-08-01 17:07:45 --> Model Class Initialized
DEBUG - 2011-08-01 17:07:45 --> Model Class Initialized
DEBUG - 2011-08-01 17:07:45 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-01 17:07:45 --> Database Driver Class Initialized
DEBUG - 2011-08-01 17:07:45 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-01 17:07:45 --> Helper loaded: url_helper
DEBUG - 2011-08-01 17:07:45 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-01 17:07:45 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-01 17:07:45 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-01 17:07:45 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-01 17:07:45 --> Final output sent to browser
DEBUG - 2011-08-01 17:07:45 --> Total execution time: 0.2369
DEBUG - 2011-08-01 17:07:58 --> Config Class Initialized
DEBUG - 2011-08-01 17:07:58 --> Hooks Class Initialized
DEBUG - 2011-08-01 17:07:58 --> Utf8 Class Initialized
DEBUG - 2011-08-01 17:07:58 --> UTF-8 Support Enabled
DEBUG - 2011-08-01 17:07:58 --> URI Class Initialized
DEBUG - 2011-08-01 17:07:58 --> Router Class Initialized
DEBUG - 2011-08-01 17:07:58 --> Output Class Initialized
DEBUG - 2011-08-01 17:07:58 --> Input Class Initialized
DEBUG - 2011-08-01 17:07:58 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-01 17:07:58 --> Language Class Initialized
DEBUG - 2011-08-01 17:07:58 --> Loader Class Initialized
DEBUG - 2011-08-01 17:07:58 --> Controller Class Initialized
DEBUG - 2011-08-01 17:07:58 --> Model Class Initialized
DEBUG - 2011-08-01 17:07:58 --> Model Class Initialized
DEBUG - 2011-08-01 17:07:58 --> Model Class Initialized
DEBUG - 2011-08-01 17:07:58 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-01 17:07:58 --> Database Driver Class Initialized
DEBUG - 2011-08-01 17:07:59 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-01 17:07:59 --> Helper loaded: url_helper
DEBUG - 2011-08-01 17:07:59 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-01 17:07:59 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-01 17:07:59 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-01 17:07:59 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-01 17:07:59 --> Final output sent to browser
DEBUG - 2011-08-01 17:07:59 --> Total execution time: 0.4404
DEBUG - 2011-08-01 17:08:04 --> Config Class Initialized
DEBUG - 2011-08-01 17:08:04 --> Hooks Class Initialized
DEBUG - 2011-08-01 17:08:04 --> Utf8 Class Initialized
DEBUG - 2011-08-01 17:08:04 --> UTF-8 Support Enabled
DEBUG - 2011-08-01 17:08:04 --> URI Class Initialized
DEBUG - 2011-08-01 17:08:04 --> Router Class Initialized
DEBUG - 2011-08-01 17:08:04 --> Output Class Initialized
DEBUG - 2011-08-01 17:08:04 --> Input Class Initialized
DEBUG - 2011-08-01 17:08:04 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-01 17:08:04 --> Language Class Initialized
DEBUG - 2011-08-01 17:08:04 --> Loader Class Initialized
DEBUG - 2011-08-01 17:08:04 --> Controller Class Initialized
DEBUG - 2011-08-01 17:08:04 --> Model Class Initialized
DEBUG - 2011-08-01 17:08:04 --> Model Class Initialized
DEBUG - 2011-08-01 17:08:04 --> Model Class Initialized
DEBUG - 2011-08-01 17:08:04 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-01 17:08:04 --> Database Driver Class Initialized
DEBUG - 2011-08-01 17:08:05 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-01 17:08:05 --> Helper loaded: url_helper
DEBUG - 2011-08-01 17:08:05 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-01 17:08:05 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-01 17:08:05 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-01 17:08:05 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-01 17:08:05 --> Final output sent to browser
DEBUG - 2011-08-01 17:08:05 --> Total execution time: 0.2462
DEBUG - 2011-08-01 17:08:08 --> Config Class Initialized
DEBUG - 2011-08-01 17:08:08 --> Hooks Class Initialized
DEBUG - 2011-08-01 17:08:08 --> Utf8 Class Initialized
DEBUG - 2011-08-01 17:08:08 --> UTF-8 Support Enabled
DEBUG - 2011-08-01 17:08:08 --> URI Class Initialized
DEBUG - 2011-08-01 17:08:08 --> Router Class Initialized
DEBUG - 2011-08-01 17:08:08 --> Output Class Initialized
DEBUG - 2011-08-01 17:08:08 --> Input Class Initialized
DEBUG - 2011-08-01 17:08:08 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-01 17:08:08 --> Language Class Initialized
DEBUG - 2011-08-01 17:08:08 --> Loader Class Initialized
DEBUG - 2011-08-01 17:08:08 --> Controller Class Initialized
DEBUG - 2011-08-01 17:08:08 --> Model Class Initialized
DEBUG - 2011-08-01 17:08:08 --> Model Class Initialized
DEBUG - 2011-08-01 17:08:08 --> Model Class Initialized
DEBUG - 2011-08-01 17:08:08 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-01 17:08:08 --> Database Driver Class Initialized
DEBUG - 2011-08-01 17:08:08 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-01 17:08:08 --> Helper loaded: url_helper
DEBUG - 2011-08-01 17:08:08 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-01 17:08:08 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-01 17:08:08 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-01 17:08:08 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-01 17:08:08 --> Final output sent to browser
DEBUG - 2011-08-01 17:08:08 --> Total execution time: 0.0451
DEBUG - 2011-08-01 17:08:20 --> Config Class Initialized
DEBUG - 2011-08-01 17:08:20 --> Hooks Class Initialized
DEBUG - 2011-08-01 17:08:20 --> Utf8 Class Initialized
DEBUG - 2011-08-01 17:08:20 --> UTF-8 Support Enabled
DEBUG - 2011-08-01 17:08:20 --> URI Class Initialized
DEBUG - 2011-08-01 17:08:20 --> Router Class Initialized
DEBUG - 2011-08-01 17:08:20 --> Output Class Initialized
DEBUG - 2011-08-01 17:08:20 --> Input Class Initialized
DEBUG - 2011-08-01 17:08:20 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-01 17:08:20 --> Language Class Initialized
DEBUG - 2011-08-01 17:08:20 --> Loader Class Initialized
DEBUG - 2011-08-01 17:08:20 --> Controller Class Initialized
DEBUG - 2011-08-01 17:08:20 --> Model Class Initialized
DEBUG - 2011-08-01 17:08:20 --> Model Class Initialized
DEBUG - 2011-08-01 17:08:20 --> Model Class Initialized
DEBUG - 2011-08-01 17:08:20 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-01 17:08:20 --> Database Driver Class Initialized
DEBUG - 2011-08-01 17:08:20 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-01 17:08:20 --> Helper loaded: url_helper
DEBUG - 2011-08-01 17:08:20 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-01 17:08:20 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-01 17:08:20 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-01 17:08:20 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-01 17:08:20 --> Final output sent to browser
DEBUG - 2011-08-01 17:08:20 --> Total execution time: 0.2499
DEBUG - 2011-08-01 17:08:32 --> Config Class Initialized
DEBUG - 2011-08-01 17:08:32 --> Hooks Class Initialized
DEBUG - 2011-08-01 17:08:32 --> Utf8 Class Initialized
DEBUG - 2011-08-01 17:08:32 --> UTF-8 Support Enabled
DEBUG - 2011-08-01 17:08:32 --> URI Class Initialized
DEBUG - 2011-08-01 17:08:32 --> Router Class Initialized
DEBUG - 2011-08-01 17:08:32 --> Output Class Initialized
DEBUG - 2011-08-01 17:08:32 --> Input Class Initialized
DEBUG - 2011-08-01 17:08:32 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-01 17:08:32 --> Language Class Initialized
DEBUG - 2011-08-01 17:08:32 --> Loader Class Initialized
DEBUG - 2011-08-01 17:08:32 --> Controller Class Initialized
DEBUG - 2011-08-01 17:08:32 --> Model Class Initialized
DEBUG - 2011-08-01 17:08:32 --> Model Class Initialized
DEBUG - 2011-08-01 17:08:32 --> Model Class Initialized
DEBUG - 2011-08-01 17:08:32 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-01 17:08:32 --> Database Driver Class Initialized
DEBUG - 2011-08-01 17:08:32 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-01 17:08:32 --> Helper loaded: url_helper
DEBUG - 2011-08-01 17:08:32 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-01 17:08:32 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-01 17:08:32 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-01 17:08:32 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-01 17:08:32 --> Final output sent to browser
DEBUG - 2011-08-01 17:08:32 --> Total execution time: 0.3851
DEBUG - 2011-08-01 20:04:18 --> Config Class Initialized
DEBUG - 2011-08-01 20:04:18 --> Hooks Class Initialized
DEBUG - 2011-08-01 20:04:18 --> Utf8 Class Initialized
DEBUG - 2011-08-01 20:04:18 --> UTF-8 Support Enabled
DEBUG - 2011-08-01 20:04:18 --> URI Class Initialized
DEBUG - 2011-08-01 20:04:18 --> Router Class Initialized
DEBUG - 2011-08-01 20:04:18 --> No URI present. Default controller set.
DEBUG - 2011-08-01 20:04:18 --> Output Class Initialized
DEBUG - 2011-08-01 20:04:18 --> Input Class Initialized
DEBUG - 2011-08-01 20:04:18 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-01 20:04:18 --> Language Class Initialized
DEBUG - 2011-08-01 20:04:18 --> Loader Class Initialized
DEBUG - 2011-08-01 20:04:18 --> Controller Class Initialized
DEBUG - 2011-08-01 20:04:18 --> File loaded: application/views/splash/main.php
DEBUG - 2011-08-01 20:04:18 --> Helper loaded: url_helper
DEBUG - 2011-08-01 20:04:18 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-01 20:04:18 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-01 20:04:18 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-01 20:04:18 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-01 20:04:18 --> Final output sent to browser
DEBUG - 2011-08-01 20:04:18 --> Total execution time: 0.2246
DEBUG - 2011-08-01 20:04:30 --> Config Class Initialized
DEBUG - 2011-08-01 20:04:30 --> Hooks Class Initialized
DEBUG - 2011-08-01 20:04:30 --> Utf8 Class Initialized
DEBUG - 2011-08-01 20:04:30 --> UTF-8 Support Enabled
DEBUG - 2011-08-01 20:04:30 --> URI Class Initialized
DEBUG - 2011-08-01 20:04:30 --> Router Class Initialized
DEBUG - 2011-08-01 20:04:30 --> Output Class Initialized
DEBUG - 2011-08-01 20:04:30 --> Input Class Initialized
DEBUG - 2011-08-01 20:04:30 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-01 20:04:30 --> Language Class Initialized
DEBUG - 2011-08-01 20:04:30 --> Loader Class Initialized
DEBUG - 2011-08-01 20:04:30 --> Controller Class Initialized
DEBUG - 2011-08-01 20:04:30 --> Model Class Initialized
DEBUG - 2011-08-01 20:04:30 --> Model Class Initialized
DEBUG - 2011-08-01 20:04:30 --> Model Class Initialized
DEBUG - 2011-08-01 20:04:30 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-01 20:04:30 --> Database Driver Class Initialized
DEBUG - 2011-08-01 20:04:30 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-01 20:04:30 --> Helper loaded: url_helper
DEBUG - 2011-08-01 20:04:30 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-01 20:04:30 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-01 20:04:30 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-01 20:04:30 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-01 20:04:30 --> Final output sent to browser
DEBUG - 2011-08-01 20:04:30 --> Total execution time: 0.3802
DEBUG - 2011-08-01 20:04:46 --> Config Class Initialized
DEBUG - 2011-08-01 20:04:46 --> Hooks Class Initialized
DEBUG - 2011-08-01 20:04:46 --> Utf8 Class Initialized
DEBUG - 2011-08-01 20:04:46 --> UTF-8 Support Enabled
DEBUG - 2011-08-01 20:04:46 --> URI Class Initialized
DEBUG - 2011-08-01 20:04:46 --> Router Class Initialized
DEBUG - 2011-08-01 20:04:46 --> Output Class Initialized
DEBUG - 2011-08-01 20:04:46 --> Input Class Initialized
DEBUG - 2011-08-01 20:04:46 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-01 20:04:46 --> Language Class Initialized
DEBUG - 2011-08-01 20:04:46 --> Loader Class Initialized
DEBUG - 2011-08-01 20:04:46 --> Controller Class Initialized
DEBUG - 2011-08-01 20:04:46 --> Model Class Initialized
DEBUG - 2011-08-01 20:04:46 --> Model Class Initialized
DEBUG - 2011-08-01 20:04:46 --> Model Class Initialized
DEBUG - 2011-08-01 20:04:46 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-01 20:04:46 --> Database Driver Class Initialized
DEBUG - 2011-08-01 20:04:46 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-01 20:04:46 --> Helper loaded: url_helper
DEBUG - 2011-08-01 20:04:46 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-01 20:04:46 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-01 20:04:46 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-01 20:04:46 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-01 20:04:46 --> Final output sent to browser
DEBUG - 2011-08-01 20:04:46 --> Total execution time: 0.2089
DEBUG - 2011-08-01 20:04:59 --> Config Class Initialized
DEBUG - 2011-08-01 20:04:59 --> Hooks Class Initialized
DEBUG - 2011-08-01 20:04:59 --> Utf8 Class Initialized
DEBUG - 2011-08-01 20:04:59 --> UTF-8 Support Enabled
DEBUG - 2011-08-01 20:04:59 --> URI Class Initialized
DEBUG - 2011-08-01 20:04:59 --> Router Class Initialized
DEBUG - 2011-08-01 20:04:59 --> Output Class Initialized
DEBUG - 2011-08-01 20:04:59 --> Input Class Initialized
DEBUG - 2011-08-01 20:04:59 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-01 20:04:59 --> Language Class Initialized
DEBUG - 2011-08-01 20:04:59 --> Loader Class Initialized
DEBUG - 2011-08-01 20:04:59 --> Controller Class Initialized
DEBUG - 2011-08-01 20:04:59 --> Model Class Initialized
DEBUG - 2011-08-01 20:04:59 --> Model Class Initialized
DEBUG - 2011-08-01 20:04:59 --> Model Class Initialized
DEBUG - 2011-08-01 20:04:59 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-01 20:05:00 --> Database Driver Class Initialized
DEBUG - 2011-08-01 20:05:00 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-01 20:05:00 --> Helper loaded: url_helper
DEBUG - 2011-08-01 20:05:00 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-01 20:05:00 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-01 20:05:00 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-01 20:05:00 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-01 20:05:00 --> Final output sent to browser
DEBUG - 2011-08-01 20:05:00 --> Total execution time: 0.0416
DEBUG - 2011-08-01 20:05:09 --> Config Class Initialized
DEBUG - 2011-08-01 20:05:09 --> Hooks Class Initialized
DEBUG - 2011-08-01 20:05:09 --> Utf8 Class Initialized
DEBUG - 2011-08-01 20:05:09 --> UTF-8 Support Enabled
DEBUG - 2011-08-01 20:05:09 --> URI Class Initialized
DEBUG - 2011-08-01 20:05:09 --> Router Class Initialized
DEBUG - 2011-08-01 20:05:09 --> Output Class Initialized
DEBUG - 2011-08-01 20:05:09 --> Input Class Initialized
DEBUG - 2011-08-01 20:05:09 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-01 20:05:09 --> Language Class Initialized
DEBUG - 2011-08-01 20:05:09 --> Loader Class Initialized
DEBUG - 2011-08-01 20:05:09 --> Controller Class Initialized
DEBUG - 2011-08-01 20:05:09 --> Model Class Initialized
DEBUG - 2011-08-01 20:05:09 --> Model Class Initialized
DEBUG - 2011-08-01 20:05:09 --> Model Class Initialized
DEBUG - 2011-08-01 20:05:09 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-01 20:05:09 --> Database Driver Class Initialized
DEBUG - 2011-08-01 20:05:09 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-01 20:05:09 --> Helper loaded: url_helper
DEBUG - 2011-08-01 20:05:09 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-01 20:05:09 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-01 20:05:09 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-01 20:05:09 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-01 20:05:09 --> Final output sent to browser
DEBUG - 2011-08-01 20:05:09 --> Total execution time: 0.2154
DEBUG - 2011-08-01 20:05:11 --> Config Class Initialized
DEBUG - 2011-08-01 20:05:11 --> Hooks Class Initialized
DEBUG - 2011-08-01 20:05:11 --> Utf8 Class Initialized
DEBUG - 2011-08-01 20:05:11 --> UTF-8 Support Enabled
DEBUG - 2011-08-01 20:05:11 --> URI Class Initialized
DEBUG - 2011-08-01 20:05:11 --> Router Class Initialized
DEBUG - 2011-08-01 20:05:11 --> Output Class Initialized
DEBUG - 2011-08-01 20:05:11 --> Input Class Initialized
DEBUG - 2011-08-01 20:05:11 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-01 20:05:11 --> Language Class Initialized
DEBUG - 2011-08-01 20:05:11 --> Loader Class Initialized
DEBUG - 2011-08-01 20:05:11 --> Controller Class Initialized
DEBUG - 2011-08-01 20:05:11 --> Model Class Initialized
DEBUG - 2011-08-01 20:05:11 --> Model Class Initialized
DEBUG - 2011-08-01 20:05:11 --> Model Class Initialized
DEBUG - 2011-08-01 20:05:11 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-01 20:05:11 --> Database Driver Class Initialized
DEBUG - 2011-08-01 20:05:11 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-01 20:05:11 --> Helper loaded: url_helper
DEBUG - 2011-08-01 20:05:11 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-01 20:05:11 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-01 20:05:11 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-01 20:05:11 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-01 20:05:11 --> Final output sent to browser
DEBUG - 2011-08-01 20:05:11 --> Total execution time: 0.0525
DEBUG - 2011-08-01 20:05:22 --> Config Class Initialized
DEBUG - 2011-08-01 20:05:22 --> Hooks Class Initialized
DEBUG - 2011-08-01 20:05:22 --> Utf8 Class Initialized
DEBUG - 2011-08-01 20:05:22 --> UTF-8 Support Enabled
DEBUG - 2011-08-01 20:05:22 --> URI Class Initialized
DEBUG - 2011-08-01 20:05:22 --> Router Class Initialized
DEBUG - 2011-08-01 20:05:22 --> Output Class Initialized
DEBUG - 2011-08-01 20:05:22 --> Input Class Initialized
DEBUG - 2011-08-01 20:05:22 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-01 20:05:22 --> Language Class Initialized
DEBUG - 2011-08-01 20:05:22 --> Loader Class Initialized
DEBUG - 2011-08-01 20:05:22 --> Controller Class Initialized
DEBUG - 2011-08-01 20:05:22 --> Model Class Initialized
DEBUG - 2011-08-01 20:05:22 --> Model Class Initialized
DEBUG - 2011-08-01 20:05:22 --> Model Class Initialized
DEBUG - 2011-08-01 20:05:22 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-01 20:05:22 --> Database Driver Class Initialized
DEBUG - 2011-08-01 20:05:22 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-01 20:05:22 --> Helper loaded: url_helper
DEBUG - 2011-08-01 20:05:22 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-01 20:05:22 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-01 20:05:22 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-01 20:05:22 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-01 20:05:22 --> Final output sent to browser
DEBUG - 2011-08-01 20:05:22 --> Total execution time: 0.2844
DEBUG - 2011-08-01 20:05:23 --> Config Class Initialized
DEBUG - 2011-08-01 20:05:23 --> Hooks Class Initialized
DEBUG - 2011-08-01 20:05:23 --> Utf8 Class Initialized
DEBUG - 2011-08-01 20:05:23 --> UTF-8 Support Enabled
DEBUG - 2011-08-01 20:05:23 --> URI Class Initialized
DEBUG - 2011-08-01 20:05:23 --> Router Class Initialized
DEBUG - 2011-08-01 20:05:23 --> Output Class Initialized
DEBUG - 2011-08-01 20:05:23 --> Input Class Initialized
DEBUG - 2011-08-01 20:05:23 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-01 20:05:23 --> Language Class Initialized
DEBUG - 2011-08-01 20:05:23 --> Loader Class Initialized
DEBUG - 2011-08-01 20:05:23 --> Controller Class Initialized
DEBUG - 2011-08-01 20:05:23 --> Model Class Initialized
DEBUG - 2011-08-01 20:05:23 --> Model Class Initialized
DEBUG - 2011-08-01 20:05:23 --> Model Class Initialized
DEBUG - 2011-08-01 20:05:23 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-01 20:05:23 --> Database Driver Class Initialized
DEBUG - 2011-08-01 20:05:23 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-01 20:05:23 --> Helper loaded: url_helper
DEBUG - 2011-08-01 20:05:23 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-01 20:05:23 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-01 20:05:23 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-01 20:05:23 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-01 20:05:23 --> Final output sent to browser
DEBUG - 2011-08-01 20:05:23 --> Total execution time: 0.1334
DEBUG - 2011-08-01 20:05:43 --> Config Class Initialized
DEBUG - 2011-08-01 20:05:43 --> Hooks Class Initialized
DEBUG - 2011-08-01 20:05:43 --> Utf8 Class Initialized
DEBUG - 2011-08-01 20:05:43 --> UTF-8 Support Enabled
DEBUG - 2011-08-01 20:05:43 --> URI Class Initialized
DEBUG - 2011-08-01 20:05:43 --> Router Class Initialized
DEBUG - 2011-08-01 20:05:43 --> Output Class Initialized
DEBUG - 2011-08-01 20:05:43 --> Input Class Initialized
DEBUG - 2011-08-01 20:05:43 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-01 20:05:43 --> Language Class Initialized
DEBUG - 2011-08-01 20:05:43 --> Loader Class Initialized
DEBUG - 2011-08-01 20:05:43 --> Controller Class Initialized
DEBUG - 2011-08-01 20:05:43 --> Model Class Initialized
DEBUG - 2011-08-01 20:05:43 --> Model Class Initialized
DEBUG - 2011-08-01 20:05:43 --> Model Class Initialized
DEBUG - 2011-08-01 20:05:43 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-01 20:05:43 --> Database Driver Class Initialized
DEBUG - 2011-08-01 20:05:44 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-01 20:05:44 --> Helper loaded: url_helper
DEBUG - 2011-08-01 20:05:44 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-01 20:05:44 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-01 20:05:44 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-01 20:05:44 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-01 20:05:44 --> Final output sent to browser
DEBUG - 2011-08-01 20:05:44 --> Total execution time: 0.1947
DEBUG - 2011-08-01 20:05:44 --> Config Class Initialized
DEBUG - 2011-08-01 20:05:44 --> Hooks Class Initialized
DEBUG - 2011-08-01 20:05:44 --> Utf8 Class Initialized
DEBUG - 2011-08-01 20:05:44 --> UTF-8 Support Enabled
DEBUG - 2011-08-01 20:05:44 --> URI Class Initialized
DEBUG - 2011-08-01 20:05:44 --> Router Class Initialized
DEBUG - 2011-08-01 20:05:44 --> Output Class Initialized
DEBUG - 2011-08-01 20:05:44 --> Input Class Initialized
DEBUG - 2011-08-01 20:05:44 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-01 20:05:44 --> Language Class Initialized
DEBUG - 2011-08-01 20:05:44 --> Loader Class Initialized
DEBUG - 2011-08-01 20:05:44 --> Controller Class Initialized
DEBUG - 2011-08-01 20:05:44 --> Model Class Initialized
DEBUG - 2011-08-01 20:05:44 --> Model Class Initialized
DEBUG - 2011-08-01 20:05:44 --> Model Class Initialized
DEBUG - 2011-08-01 20:05:44 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-01 20:05:44 --> Database Driver Class Initialized
DEBUG - 2011-08-01 20:05:44 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-01 20:05:44 --> Helper loaded: url_helper
DEBUG - 2011-08-01 20:05:44 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-01 20:05:44 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-01 20:05:44 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-01 20:05:44 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-01 20:05:44 --> Final output sent to browser
DEBUG - 2011-08-01 20:05:44 --> Total execution time: 0.0447
DEBUG - 2011-08-01 20:06:06 --> Config Class Initialized
DEBUG - 2011-08-01 20:06:06 --> Hooks Class Initialized
DEBUG - 2011-08-01 20:06:06 --> Utf8 Class Initialized
DEBUG - 2011-08-01 20:06:06 --> UTF-8 Support Enabled
DEBUG - 2011-08-01 20:06:06 --> URI Class Initialized
DEBUG - 2011-08-01 20:06:06 --> Router Class Initialized
DEBUG - 2011-08-01 20:06:06 --> Output Class Initialized
DEBUG - 2011-08-01 20:06:06 --> Input Class Initialized
DEBUG - 2011-08-01 20:06:06 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-01 20:06:06 --> Language Class Initialized
DEBUG - 2011-08-01 20:06:06 --> Loader Class Initialized
DEBUG - 2011-08-01 20:06:06 --> Controller Class Initialized
DEBUG - 2011-08-01 20:06:06 --> Model Class Initialized
DEBUG - 2011-08-01 20:06:06 --> Model Class Initialized
DEBUG - 2011-08-01 20:06:06 --> Model Class Initialized
DEBUG - 2011-08-01 20:06:06 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-01 20:06:06 --> Database Driver Class Initialized
DEBUG - 2011-08-01 20:06:06 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-01 20:06:06 --> Helper loaded: url_helper
DEBUG - 2011-08-01 20:06:06 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-01 20:06:06 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-01 20:06:06 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-01 20:06:06 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-01 20:06:06 --> Final output sent to browser
DEBUG - 2011-08-01 20:06:06 --> Total execution time: 0.1858
DEBUG - 2011-08-01 20:06:07 --> Config Class Initialized
DEBUG - 2011-08-01 20:06:07 --> Hooks Class Initialized
DEBUG - 2011-08-01 20:06:07 --> Utf8 Class Initialized
DEBUG - 2011-08-01 20:06:07 --> UTF-8 Support Enabled
DEBUG - 2011-08-01 20:06:07 --> URI Class Initialized
DEBUG - 2011-08-01 20:06:07 --> Router Class Initialized
DEBUG - 2011-08-01 20:06:07 --> Output Class Initialized
DEBUG - 2011-08-01 20:06:07 --> Input Class Initialized
DEBUG - 2011-08-01 20:06:07 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-01 20:06:07 --> Language Class Initialized
DEBUG - 2011-08-01 20:06:07 --> Loader Class Initialized
DEBUG - 2011-08-01 20:06:07 --> Controller Class Initialized
DEBUG - 2011-08-01 20:06:07 --> Model Class Initialized
DEBUG - 2011-08-01 20:06:07 --> Model Class Initialized
DEBUG - 2011-08-01 20:06:07 --> Model Class Initialized
DEBUG - 2011-08-01 20:06:07 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-01 20:06:07 --> Database Driver Class Initialized
DEBUG - 2011-08-01 20:06:07 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-01 20:06:07 --> Helper loaded: url_helper
DEBUG - 2011-08-01 20:06:07 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-01 20:06:07 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-01 20:06:07 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-01 20:06:07 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-01 20:06:07 --> Final output sent to browser
DEBUG - 2011-08-01 20:06:07 --> Total execution time: 0.0435
DEBUG - 2011-08-01 20:06:15 --> Config Class Initialized
DEBUG - 2011-08-01 20:06:15 --> Hooks Class Initialized
DEBUG - 2011-08-01 20:06:15 --> Utf8 Class Initialized
DEBUG - 2011-08-01 20:06:15 --> UTF-8 Support Enabled
DEBUG - 2011-08-01 20:06:15 --> URI Class Initialized
DEBUG - 2011-08-01 20:06:15 --> Router Class Initialized
DEBUG - 2011-08-01 20:06:15 --> Output Class Initialized
DEBUG - 2011-08-01 20:06:15 --> Input Class Initialized
DEBUG - 2011-08-01 20:06:15 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-01 20:06:15 --> Language Class Initialized
DEBUG - 2011-08-01 20:06:15 --> Loader Class Initialized
DEBUG - 2011-08-01 20:06:15 --> Controller Class Initialized
DEBUG - 2011-08-01 20:06:15 --> Model Class Initialized
DEBUG - 2011-08-01 20:06:15 --> Model Class Initialized
DEBUG - 2011-08-01 20:06:15 --> Model Class Initialized
DEBUG - 2011-08-01 20:06:15 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-01 20:06:15 --> Database Driver Class Initialized
DEBUG - 2011-08-01 20:06:15 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-01 20:06:15 --> Helper loaded: url_helper
DEBUG - 2011-08-01 20:06:15 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-01 20:06:15 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-01 20:06:15 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-01 20:06:15 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-01 20:06:15 --> Final output sent to browser
DEBUG - 2011-08-01 20:06:15 --> Total execution time: 0.2961
DEBUG - 2011-08-01 20:06:16 --> Config Class Initialized
DEBUG - 2011-08-01 20:06:16 --> Hooks Class Initialized
DEBUG - 2011-08-01 20:06:16 --> Utf8 Class Initialized
DEBUG - 2011-08-01 20:06:16 --> UTF-8 Support Enabled
DEBUG - 2011-08-01 20:06:16 --> URI Class Initialized
DEBUG - 2011-08-01 20:06:16 --> Router Class Initialized
DEBUG - 2011-08-01 20:06:16 --> Output Class Initialized
DEBUG - 2011-08-01 20:06:16 --> Input Class Initialized
DEBUG - 2011-08-01 20:06:16 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-01 20:06:16 --> Language Class Initialized
DEBUG - 2011-08-01 20:06:16 --> Loader Class Initialized
DEBUG - 2011-08-01 20:06:16 --> Controller Class Initialized
DEBUG - 2011-08-01 20:06:16 --> Model Class Initialized
DEBUG - 2011-08-01 20:06:16 --> Model Class Initialized
DEBUG - 2011-08-01 20:06:16 --> Model Class Initialized
DEBUG - 2011-08-01 20:06:16 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-01 20:06:16 --> Database Driver Class Initialized
DEBUG - 2011-08-01 20:06:16 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-01 20:06:16 --> Helper loaded: url_helper
DEBUG - 2011-08-01 20:06:16 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-01 20:06:16 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-01 20:06:16 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-01 20:06:16 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-01 20:06:16 --> Final output sent to browser
DEBUG - 2011-08-01 20:06:16 --> Total execution time: 0.0771
DEBUG - 2011-08-01 20:06:26 --> Config Class Initialized
DEBUG - 2011-08-01 20:06:26 --> Hooks Class Initialized
DEBUG - 2011-08-01 20:06:26 --> Utf8 Class Initialized
DEBUG - 2011-08-01 20:06:26 --> UTF-8 Support Enabled
DEBUG - 2011-08-01 20:06:26 --> URI Class Initialized
DEBUG - 2011-08-01 20:06:26 --> Router Class Initialized
DEBUG - 2011-08-01 20:06:26 --> Output Class Initialized
DEBUG - 2011-08-01 20:06:26 --> Input Class Initialized
DEBUG - 2011-08-01 20:06:26 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-01 20:06:26 --> Language Class Initialized
DEBUG - 2011-08-01 20:06:26 --> Loader Class Initialized
DEBUG - 2011-08-01 20:06:26 --> Controller Class Initialized
DEBUG - 2011-08-01 20:06:26 --> Model Class Initialized
DEBUG - 2011-08-01 20:06:26 --> Model Class Initialized
DEBUG - 2011-08-01 20:06:26 --> Model Class Initialized
DEBUG - 2011-08-01 20:06:26 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-01 20:06:26 --> Database Driver Class Initialized
DEBUG - 2011-08-01 20:06:26 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-01 20:06:26 --> Helper loaded: url_helper
DEBUG - 2011-08-01 20:06:26 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-01 20:06:26 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-01 20:06:26 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-01 20:06:26 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-01 20:06:26 --> Final output sent to browser
DEBUG - 2011-08-01 20:06:26 --> Total execution time: 0.2592
DEBUG - 2011-08-01 20:06:27 --> Config Class Initialized
DEBUG - 2011-08-01 20:06:27 --> Hooks Class Initialized
DEBUG - 2011-08-01 20:06:27 --> Utf8 Class Initialized
DEBUG - 2011-08-01 20:06:27 --> UTF-8 Support Enabled
DEBUG - 2011-08-01 20:06:27 --> URI Class Initialized
DEBUG - 2011-08-01 20:06:27 --> Router Class Initialized
DEBUG - 2011-08-01 20:06:27 --> Output Class Initialized
DEBUG - 2011-08-01 20:06:27 --> Input Class Initialized
DEBUG - 2011-08-01 20:06:27 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-01 20:06:27 --> Language Class Initialized
DEBUG - 2011-08-01 20:06:27 --> Loader Class Initialized
DEBUG - 2011-08-01 20:06:27 --> Controller Class Initialized
DEBUG - 2011-08-01 20:06:27 --> Model Class Initialized
DEBUG - 2011-08-01 20:06:27 --> Model Class Initialized
DEBUG - 2011-08-01 20:06:27 --> Model Class Initialized
DEBUG - 2011-08-01 20:06:27 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-01 20:06:27 --> Database Driver Class Initialized
DEBUG - 2011-08-01 20:06:27 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-01 20:06:27 --> Helper loaded: url_helper
DEBUG - 2011-08-01 20:06:27 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-01 20:06:27 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-01 20:06:27 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-01 20:06:27 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-01 20:06:27 --> Final output sent to browser
DEBUG - 2011-08-01 20:06:27 --> Total execution time: 0.0582
DEBUG - 2011-08-01 20:06:32 --> Config Class Initialized
DEBUG - 2011-08-01 20:06:32 --> Hooks Class Initialized
DEBUG - 2011-08-01 20:06:32 --> Utf8 Class Initialized
DEBUG - 2011-08-01 20:06:32 --> UTF-8 Support Enabled
DEBUG - 2011-08-01 20:06:32 --> URI Class Initialized
DEBUG - 2011-08-01 20:06:32 --> Router Class Initialized
DEBUG - 2011-08-01 20:06:32 --> Output Class Initialized
DEBUG - 2011-08-01 20:06:32 --> Input Class Initialized
DEBUG - 2011-08-01 20:06:32 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-01 20:06:32 --> Language Class Initialized
DEBUG - 2011-08-01 20:06:32 --> Loader Class Initialized
DEBUG - 2011-08-01 20:06:32 --> Controller Class Initialized
DEBUG - 2011-08-01 20:06:32 --> Model Class Initialized
DEBUG - 2011-08-01 20:06:32 --> Model Class Initialized
DEBUG - 2011-08-01 20:06:32 --> Model Class Initialized
DEBUG - 2011-08-01 20:06:32 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-01 20:06:32 --> Database Driver Class Initialized
DEBUG - 2011-08-01 20:06:32 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-01 20:06:32 --> Helper loaded: url_helper
DEBUG - 2011-08-01 20:06:32 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-01 20:06:32 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-01 20:06:32 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-01 20:06:32 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-01 20:06:32 --> Final output sent to browser
DEBUG - 2011-08-01 20:06:32 --> Total execution time: 0.2085
DEBUG - 2011-08-01 20:06:34 --> Config Class Initialized
DEBUG - 2011-08-01 20:06:34 --> Hooks Class Initialized
DEBUG - 2011-08-01 20:06:34 --> Utf8 Class Initialized
DEBUG - 2011-08-01 20:06:34 --> UTF-8 Support Enabled
DEBUG - 2011-08-01 20:06:34 --> URI Class Initialized
DEBUG - 2011-08-01 20:06:34 --> Router Class Initialized
DEBUG - 2011-08-01 20:06:34 --> Output Class Initialized
DEBUG - 2011-08-01 20:06:34 --> Input Class Initialized
DEBUG - 2011-08-01 20:06:34 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-01 20:06:34 --> Language Class Initialized
DEBUG - 2011-08-01 20:06:34 --> Loader Class Initialized
DEBUG - 2011-08-01 20:06:34 --> Controller Class Initialized
DEBUG - 2011-08-01 20:06:34 --> Model Class Initialized
DEBUG - 2011-08-01 20:06:34 --> Model Class Initialized
DEBUG - 2011-08-01 20:06:34 --> Model Class Initialized
DEBUG - 2011-08-01 20:06:34 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-01 20:06:34 --> Database Driver Class Initialized
DEBUG - 2011-08-01 20:06:34 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-01 20:06:34 --> Helper loaded: url_helper
DEBUG - 2011-08-01 20:06:34 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-01 20:06:34 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-01 20:06:34 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-01 20:06:34 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-01 20:06:34 --> Final output sent to browser
DEBUG - 2011-08-01 20:06:34 --> Total execution time: 0.0702
DEBUG - 2011-08-01 20:06:40 --> Config Class Initialized
DEBUG - 2011-08-01 20:06:40 --> Hooks Class Initialized
DEBUG - 2011-08-01 20:06:40 --> Utf8 Class Initialized
DEBUG - 2011-08-01 20:06:40 --> UTF-8 Support Enabled
DEBUG - 2011-08-01 20:06:40 --> URI Class Initialized
DEBUG - 2011-08-01 20:06:40 --> Router Class Initialized
DEBUG - 2011-08-01 20:06:40 --> Output Class Initialized
DEBUG - 2011-08-01 20:06:40 --> Input Class Initialized
DEBUG - 2011-08-01 20:06:40 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-01 20:06:40 --> Language Class Initialized
DEBUG - 2011-08-01 20:06:40 --> Loader Class Initialized
DEBUG - 2011-08-01 20:06:40 --> Controller Class Initialized
DEBUG - 2011-08-01 20:06:40 --> Model Class Initialized
DEBUG - 2011-08-01 20:06:40 --> Model Class Initialized
DEBUG - 2011-08-01 20:06:40 --> Model Class Initialized
DEBUG - 2011-08-01 20:06:40 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-01 20:06:40 --> Database Driver Class Initialized
DEBUG - 2011-08-01 20:06:41 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-01 20:06:41 --> Helper loaded: url_helper
DEBUG - 2011-08-01 20:06:41 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-01 20:06:41 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-01 20:06:41 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-01 20:06:41 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-01 20:06:41 --> Final output sent to browser
DEBUG - 2011-08-01 20:06:41 --> Total execution time: 0.2906
DEBUG - 2011-08-01 20:06:42 --> Config Class Initialized
DEBUG - 2011-08-01 20:06:42 --> Hooks Class Initialized
DEBUG - 2011-08-01 20:06:42 --> Utf8 Class Initialized
DEBUG - 2011-08-01 20:06:42 --> UTF-8 Support Enabled
DEBUG - 2011-08-01 20:06:42 --> URI Class Initialized
DEBUG - 2011-08-01 20:06:42 --> Router Class Initialized
DEBUG - 2011-08-01 20:06:42 --> Output Class Initialized
DEBUG - 2011-08-01 20:06:42 --> Input Class Initialized
DEBUG - 2011-08-01 20:06:42 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-01 20:06:42 --> Language Class Initialized
DEBUG - 2011-08-01 20:06:42 --> Loader Class Initialized
DEBUG - 2011-08-01 20:06:42 --> Controller Class Initialized
DEBUG - 2011-08-01 20:06:42 --> Model Class Initialized
DEBUG - 2011-08-01 20:06:42 --> Model Class Initialized
DEBUG - 2011-08-01 20:06:42 --> Model Class Initialized
DEBUG - 2011-08-01 20:06:42 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-01 20:06:42 --> Database Driver Class Initialized
DEBUG - 2011-08-01 20:06:42 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-01 20:06:42 --> Helper loaded: url_helper
DEBUG - 2011-08-01 20:06:42 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-01 20:06:42 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-01 20:06:42 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-01 20:06:42 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-01 20:06:42 --> Final output sent to browser
DEBUG - 2011-08-01 20:06:42 --> Total execution time: 0.0444
DEBUG - 2011-08-01 20:06:48 --> Config Class Initialized
DEBUG - 2011-08-01 20:06:48 --> Hooks Class Initialized
DEBUG - 2011-08-01 20:06:48 --> Utf8 Class Initialized
DEBUG - 2011-08-01 20:06:48 --> UTF-8 Support Enabled
DEBUG - 2011-08-01 20:06:48 --> URI Class Initialized
DEBUG - 2011-08-01 20:06:48 --> Router Class Initialized
DEBUG - 2011-08-01 20:06:48 --> Output Class Initialized
DEBUG - 2011-08-01 20:06:48 --> Input Class Initialized
DEBUG - 2011-08-01 20:06:48 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-01 20:06:48 --> Language Class Initialized
DEBUG - 2011-08-01 20:06:48 --> Loader Class Initialized
DEBUG - 2011-08-01 20:06:48 --> Controller Class Initialized
DEBUG - 2011-08-01 20:06:48 --> Model Class Initialized
DEBUG - 2011-08-01 20:06:48 --> Model Class Initialized
DEBUG - 2011-08-01 20:06:48 --> Model Class Initialized
DEBUG - 2011-08-01 20:06:48 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-01 20:06:48 --> Database Driver Class Initialized
DEBUG - 2011-08-01 20:06:48 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-01 20:06:48 --> Helper loaded: url_helper
DEBUG - 2011-08-01 20:06:48 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-01 20:06:48 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-01 20:06:48 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-01 20:06:48 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-01 20:06:48 --> Final output sent to browser
DEBUG - 2011-08-01 20:06:48 --> Total execution time: 0.2334
DEBUG - 2011-08-01 20:06:49 --> Config Class Initialized
DEBUG - 2011-08-01 20:06:49 --> Hooks Class Initialized
DEBUG - 2011-08-01 20:06:49 --> Utf8 Class Initialized
DEBUG - 2011-08-01 20:06:49 --> UTF-8 Support Enabled
DEBUG - 2011-08-01 20:06:49 --> URI Class Initialized
DEBUG - 2011-08-01 20:06:49 --> Router Class Initialized
DEBUG - 2011-08-01 20:06:49 --> Output Class Initialized
DEBUG - 2011-08-01 20:06:49 --> Input Class Initialized
DEBUG - 2011-08-01 20:06:49 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-01 20:06:49 --> Language Class Initialized
DEBUG - 2011-08-01 20:06:49 --> Loader Class Initialized
DEBUG - 2011-08-01 20:06:49 --> Controller Class Initialized
DEBUG - 2011-08-01 20:06:49 --> Model Class Initialized
DEBUG - 2011-08-01 20:06:49 --> Model Class Initialized
DEBUG - 2011-08-01 20:06:49 --> Model Class Initialized
DEBUG - 2011-08-01 20:06:49 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-01 20:06:49 --> Database Driver Class Initialized
DEBUG - 2011-08-01 20:06:49 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-01 20:06:49 --> Helper loaded: url_helper
DEBUG - 2011-08-01 20:06:49 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-01 20:06:49 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-01 20:06:49 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-01 20:06:49 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-01 20:06:49 --> Final output sent to browser
DEBUG - 2011-08-01 20:06:49 --> Total execution time: 0.0641
DEBUG - 2011-08-01 20:06:55 --> Config Class Initialized
DEBUG - 2011-08-01 20:06:55 --> Hooks Class Initialized
DEBUG - 2011-08-01 20:06:55 --> Utf8 Class Initialized
DEBUG - 2011-08-01 20:06:55 --> UTF-8 Support Enabled
DEBUG - 2011-08-01 20:06:55 --> URI Class Initialized
DEBUG - 2011-08-01 20:06:55 --> Router Class Initialized
DEBUG - 2011-08-01 20:06:55 --> Output Class Initialized
DEBUG - 2011-08-01 20:06:55 --> Input Class Initialized
DEBUG - 2011-08-01 20:06:55 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-01 20:06:55 --> Language Class Initialized
DEBUG - 2011-08-01 20:06:55 --> Loader Class Initialized
DEBUG - 2011-08-01 20:06:55 --> Controller Class Initialized
DEBUG - 2011-08-01 20:06:55 --> Model Class Initialized
DEBUG - 2011-08-01 20:06:55 --> Model Class Initialized
DEBUG - 2011-08-01 20:06:55 --> Model Class Initialized
DEBUG - 2011-08-01 20:06:55 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-01 20:06:55 --> Database Driver Class Initialized
DEBUG - 2011-08-01 20:06:55 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-01 20:06:55 --> Helper loaded: url_helper
DEBUG - 2011-08-01 20:06:55 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-01 20:06:55 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-01 20:06:55 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-01 20:06:55 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-01 20:06:55 --> Final output sent to browser
DEBUG - 2011-08-01 20:06:55 --> Total execution time: 0.2396
DEBUG - 2011-08-01 20:06:56 --> Config Class Initialized
DEBUG - 2011-08-01 20:06:56 --> Hooks Class Initialized
DEBUG - 2011-08-01 20:06:56 --> Utf8 Class Initialized
DEBUG - 2011-08-01 20:06:56 --> UTF-8 Support Enabled
DEBUG - 2011-08-01 20:06:56 --> URI Class Initialized
DEBUG - 2011-08-01 20:06:56 --> Router Class Initialized
DEBUG - 2011-08-01 20:06:56 --> Output Class Initialized
DEBUG - 2011-08-01 20:06:56 --> Input Class Initialized
DEBUG - 2011-08-01 20:06:56 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-01 20:06:56 --> Language Class Initialized
DEBUG - 2011-08-01 20:06:56 --> Loader Class Initialized
DEBUG - 2011-08-01 20:06:56 --> Controller Class Initialized
DEBUG - 2011-08-01 20:06:56 --> Model Class Initialized
DEBUG - 2011-08-01 20:06:56 --> Model Class Initialized
DEBUG - 2011-08-01 20:06:56 --> Model Class Initialized
DEBUG - 2011-08-01 20:06:56 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-01 20:06:56 --> Database Driver Class Initialized
DEBUG - 2011-08-01 20:06:56 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-01 20:06:56 --> Helper loaded: url_helper
DEBUG - 2011-08-01 20:06:56 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-01 20:06:56 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-01 20:06:56 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-01 20:06:56 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-01 20:06:56 --> Final output sent to browser
DEBUG - 2011-08-01 20:06:56 --> Total execution time: 0.0431
DEBUG - 2011-08-01 20:07:02 --> Config Class Initialized
DEBUG - 2011-08-01 20:07:02 --> Hooks Class Initialized
DEBUG - 2011-08-01 20:07:02 --> Utf8 Class Initialized
DEBUG - 2011-08-01 20:07:02 --> UTF-8 Support Enabled
DEBUG - 2011-08-01 20:07:02 --> URI Class Initialized
DEBUG - 2011-08-01 20:07:02 --> Router Class Initialized
DEBUG - 2011-08-01 20:07:02 --> Output Class Initialized
DEBUG - 2011-08-01 20:07:02 --> Input Class Initialized
DEBUG - 2011-08-01 20:07:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-01 20:07:02 --> Language Class Initialized
DEBUG - 2011-08-01 20:07:02 --> Loader Class Initialized
DEBUG - 2011-08-01 20:07:02 --> Controller Class Initialized
DEBUG - 2011-08-01 20:07:02 --> Model Class Initialized
DEBUG - 2011-08-01 20:07:02 --> Model Class Initialized
DEBUG - 2011-08-01 20:07:02 --> Model Class Initialized
DEBUG - 2011-08-01 20:07:02 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-01 20:07:02 --> Database Driver Class Initialized
DEBUG - 2011-08-01 20:07:02 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-01 20:07:02 --> Helper loaded: url_helper
DEBUG - 2011-08-01 20:07:02 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-01 20:07:02 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-01 20:07:02 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-01 20:07:02 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-01 20:07:02 --> Final output sent to browser
DEBUG - 2011-08-01 20:07:02 --> Total execution time: 0.4925
DEBUG - 2011-08-01 20:07:03 --> Config Class Initialized
DEBUG - 2011-08-01 20:07:03 --> Hooks Class Initialized
DEBUG - 2011-08-01 20:07:03 --> Utf8 Class Initialized
DEBUG - 2011-08-01 20:07:03 --> UTF-8 Support Enabled
DEBUG - 2011-08-01 20:07:03 --> URI Class Initialized
DEBUG - 2011-08-01 20:07:03 --> Router Class Initialized
DEBUG - 2011-08-01 20:07:03 --> Output Class Initialized
DEBUG - 2011-08-01 20:07:03 --> Input Class Initialized
DEBUG - 2011-08-01 20:07:03 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-01 20:07:03 --> Language Class Initialized
DEBUG - 2011-08-01 20:07:03 --> Loader Class Initialized
DEBUG - 2011-08-01 20:07:03 --> Controller Class Initialized
DEBUG - 2011-08-01 20:07:03 --> Model Class Initialized
DEBUG - 2011-08-01 20:07:03 --> Model Class Initialized
DEBUG - 2011-08-01 20:07:03 --> Model Class Initialized
DEBUG - 2011-08-01 20:07:03 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-01 20:07:03 --> Database Driver Class Initialized
DEBUG - 2011-08-01 20:07:03 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-01 20:07:03 --> Helper loaded: url_helper
DEBUG - 2011-08-01 20:07:03 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-01 20:07:03 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-01 20:07:03 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-01 20:07:03 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-01 20:07:03 --> Final output sent to browser
DEBUG - 2011-08-01 20:07:03 --> Total execution time: 0.0482
DEBUG - 2011-08-01 20:07:10 --> Config Class Initialized
DEBUG - 2011-08-01 20:07:10 --> Hooks Class Initialized
DEBUG - 2011-08-01 20:07:10 --> Utf8 Class Initialized
DEBUG - 2011-08-01 20:07:10 --> UTF-8 Support Enabled
DEBUG - 2011-08-01 20:07:10 --> URI Class Initialized
DEBUG - 2011-08-01 20:07:10 --> Router Class Initialized
DEBUG - 2011-08-01 20:07:10 --> Output Class Initialized
DEBUG - 2011-08-01 20:07:10 --> Input Class Initialized
DEBUG - 2011-08-01 20:07:10 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-01 20:07:10 --> Language Class Initialized
DEBUG - 2011-08-01 20:07:10 --> Loader Class Initialized
DEBUG - 2011-08-01 20:07:10 --> Controller Class Initialized
DEBUG - 2011-08-01 20:07:10 --> Model Class Initialized
DEBUG - 2011-08-01 20:07:10 --> Model Class Initialized
DEBUG - 2011-08-01 20:07:10 --> Model Class Initialized
DEBUG - 2011-08-01 20:07:10 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-01 20:07:10 --> Database Driver Class Initialized
DEBUG - 2011-08-01 20:07:10 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-01 20:07:10 --> Helper loaded: url_helper
DEBUG - 2011-08-01 20:07:10 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-01 20:07:10 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-01 20:07:10 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-01 20:07:10 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-01 20:07:10 --> Final output sent to browser
DEBUG - 2011-08-01 20:07:10 --> Total execution time: 0.2364
DEBUG - 2011-08-01 20:07:11 --> Config Class Initialized
DEBUG - 2011-08-01 20:07:11 --> Hooks Class Initialized
DEBUG - 2011-08-01 20:07:11 --> Utf8 Class Initialized
DEBUG - 2011-08-01 20:07:11 --> UTF-8 Support Enabled
DEBUG - 2011-08-01 20:07:11 --> URI Class Initialized
DEBUG - 2011-08-01 20:07:11 --> Router Class Initialized
DEBUG - 2011-08-01 20:07:11 --> Output Class Initialized
DEBUG - 2011-08-01 20:07:11 --> Input Class Initialized
DEBUG - 2011-08-01 20:07:11 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-01 20:07:11 --> Language Class Initialized
DEBUG - 2011-08-01 20:07:11 --> Loader Class Initialized
DEBUG - 2011-08-01 20:07:11 --> Controller Class Initialized
DEBUG - 2011-08-01 20:07:11 --> Model Class Initialized
DEBUG - 2011-08-01 20:07:11 --> Model Class Initialized
DEBUG - 2011-08-01 20:07:11 --> Model Class Initialized
DEBUG - 2011-08-01 20:07:11 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-01 20:07:11 --> Database Driver Class Initialized
DEBUG - 2011-08-01 20:07:11 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-01 20:07:11 --> Helper loaded: url_helper
DEBUG - 2011-08-01 20:07:11 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-01 20:07:11 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-01 20:07:11 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-01 20:07:11 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-01 20:07:11 --> Final output sent to browser
DEBUG - 2011-08-01 20:07:11 --> Total execution time: 0.0539
DEBUG - 2011-08-01 20:07:17 --> Config Class Initialized
DEBUG - 2011-08-01 20:07:17 --> Hooks Class Initialized
DEBUG - 2011-08-01 20:07:17 --> Utf8 Class Initialized
DEBUG - 2011-08-01 20:07:17 --> UTF-8 Support Enabled
DEBUG - 2011-08-01 20:07:17 --> URI Class Initialized
DEBUG - 2011-08-01 20:07:17 --> Router Class Initialized
DEBUG - 2011-08-01 20:07:17 --> Output Class Initialized
DEBUG - 2011-08-01 20:07:17 --> Input Class Initialized
DEBUG - 2011-08-01 20:07:17 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-01 20:07:17 --> Language Class Initialized
DEBUG - 2011-08-01 20:07:17 --> Loader Class Initialized
DEBUG - 2011-08-01 20:07:17 --> Controller Class Initialized
DEBUG - 2011-08-01 20:07:17 --> Model Class Initialized
DEBUG - 2011-08-01 20:07:17 --> Model Class Initialized
DEBUG - 2011-08-01 20:07:17 --> Model Class Initialized
DEBUG - 2011-08-01 20:07:17 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-01 20:07:17 --> Database Driver Class Initialized
DEBUG - 2011-08-01 20:07:17 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-01 20:07:17 --> Helper loaded: url_helper
DEBUG - 2011-08-01 20:07:17 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-01 20:07:17 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-01 20:07:17 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-01 20:07:17 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-01 20:07:17 --> Final output sent to browser
DEBUG - 2011-08-01 20:07:17 --> Total execution time: 0.2682
DEBUG - 2011-08-01 20:07:18 --> Config Class Initialized
DEBUG - 2011-08-01 20:07:18 --> Hooks Class Initialized
DEBUG - 2011-08-01 20:07:18 --> Utf8 Class Initialized
DEBUG - 2011-08-01 20:07:18 --> UTF-8 Support Enabled
DEBUG - 2011-08-01 20:07:18 --> URI Class Initialized
DEBUG - 2011-08-01 20:07:18 --> Router Class Initialized
DEBUG - 2011-08-01 20:07:18 --> Output Class Initialized
DEBUG - 2011-08-01 20:07:18 --> Input Class Initialized
DEBUG - 2011-08-01 20:07:18 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-01 20:07:18 --> Language Class Initialized
DEBUG - 2011-08-01 20:07:18 --> Loader Class Initialized
DEBUG - 2011-08-01 20:07:18 --> Controller Class Initialized
DEBUG - 2011-08-01 20:07:18 --> Model Class Initialized
DEBUG - 2011-08-01 20:07:18 --> Model Class Initialized
DEBUG - 2011-08-01 20:07:18 --> Model Class Initialized
DEBUG - 2011-08-01 20:07:18 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-01 20:07:18 --> Database Driver Class Initialized
DEBUG - 2011-08-01 20:07:18 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-01 20:07:18 --> Helper loaded: url_helper
DEBUG - 2011-08-01 20:07:18 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-01 20:07:18 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-01 20:07:18 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-01 20:07:18 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-01 20:07:18 --> Final output sent to browser
DEBUG - 2011-08-01 20:07:18 --> Total execution time: 0.1573
DEBUG - 2011-08-01 20:07:27 --> Config Class Initialized
DEBUG - 2011-08-01 20:07:27 --> Hooks Class Initialized
DEBUG - 2011-08-01 20:07:27 --> Utf8 Class Initialized
DEBUG - 2011-08-01 20:07:27 --> UTF-8 Support Enabled
DEBUG - 2011-08-01 20:07:27 --> URI Class Initialized
DEBUG - 2011-08-01 20:07:27 --> Router Class Initialized
DEBUG - 2011-08-01 20:07:27 --> Output Class Initialized
DEBUG - 2011-08-01 20:07:27 --> Input Class Initialized
DEBUG - 2011-08-01 20:07:27 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-01 20:07:27 --> Language Class Initialized
DEBUG - 2011-08-01 20:07:27 --> Loader Class Initialized
DEBUG - 2011-08-01 20:07:27 --> Controller Class Initialized
DEBUG - 2011-08-01 20:07:27 --> Model Class Initialized
DEBUG - 2011-08-01 20:07:27 --> Model Class Initialized
DEBUG - 2011-08-01 20:07:27 --> Model Class Initialized
DEBUG - 2011-08-01 20:07:27 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-01 20:07:27 --> Database Driver Class Initialized
DEBUG - 2011-08-01 20:07:28 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-01 20:07:28 --> Helper loaded: url_helper
DEBUG - 2011-08-01 20:07:28 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-01 20:07:28 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-01 20:07:28 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-01 20:07:28 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-01 20:07:28 --> Final output sent to browser
DEBUG - 2011-08-01 20:07:28 --> Total execution time: 0.2483
DEBUG - 2011-08-01 20:07:28 --> Config Class Initialized
DEBUG - 2011-08-01 20:07:28 --> Hooks Class Initialized
DEBUG - 2011-08-01 20:07:28 --> Utf8 Class Initialized
DEBUG - 2011-08-01 20:07:28 --> UTF-8 Support Enabled
DEBUG - 2011-08-01 20:07:28 --> URI Class Initialized
DEBUG - 2011-08-01 20:07:28 --> Router Class Initialized
DEBUG - 2011-08-01 20:07:28 --> Output Class Initialized
DEBUG - 2011-08-01 20:07:28 --> Input Class Initialized
DEBUG - 2011-08-01 20:07:28 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-01 20:07:28 --> Language Class Initialized
DEBUG - 2011-08-01 20:07:28 --> Loader Class Initialized
DEBUG - 2011-08-01 20:07:28 --> Controller Class Initialized
DEBUG - 2011-08-01 20:07:28 --> Model Class Initialized
DEBUG - 2011-08-01 20:07:28 --> Model Class Initialized
DEBUG - 2011-08-01 20:07:28 --> Model Class Initialized
DEBUG - 2011-08-01 20:07:29 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-01 20:07:29 --> Database Driver Class Initialized
DEBUG - 2011-08-01 20:07:29 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-01 20:07:29 --> Helper loaded: url_helper
DEBUG - 2011-08-01 20:07:29 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-01 20:07:29 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-01 20:07:29 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-01 20:07:29 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-01 20:07:29 --> Final output sent to browser
DEBUG - 2011-08-01 20:07:29 --> Total execution time: 0.0497
DEBUG - 2011-08-01 20:07:39 --> Config Class Initialized
DEBUG - 2011-08-01 20:07:39 --> Hooks Class Initialized
DEBUG - 2011-08-01 20:07:39 --> Utf8 Class Initialized
DEBUG - 2011-08-01 20:07:39 --> UTF-8 Support Enabled
DEBUG - 2011-08-01 20:07:39 --> URI Class Initialized
DEBUG - 2011-08-01 20:07:39 --> Router Class Initialized
DEBUG - 2011-08-01 20:07:39 --> Output Class Initialized
DEBUG - 2011-08-01 20:07:39 --> Input Class Initialized
DEBUG - 2011-08-01 20:07:39 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-01 20:07:39 --> Language Class Initialized
DEBUG - 2011-08-01 20:07:39 --> Loader Class Initialized
DEBUG - 2011-08-01 20:07:39 --> Controller Class Initialized
DEBUG - 2011-08-01 20:07:39 --> Model Class Initialized
DEBUG - 2011-08-01 20:07:39 --> Model Class Initialized
DEBUG - 2011-08-01 20:07:39 --> Model Class Initialized
DEBUG - 2011-08-01 20:07:39 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-01 20:07:39 --> Database Driver Class Initialized
DEBUG - 2011-08-01 20:07:39 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-01 20:07:39 --> Helper loaded: url_helper
DEBUG - 2011-08-01 20:07:39 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-01 20:07:39 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-01 20:07:39 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-01 20:07:39 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-01 20:07:39 --> Final output sent to browser
DEBUG - 2011-08-01 20:07:39 --> Total execution time: 0.3126
DEBUG - 2011-08-01 20:07:47 --> Config Class Initialized
DEBUG - 2011-08-01 20:07:47 --> Hooks Class Initialized
DEBUG - 2011-08-01 20:07:47 --> Utf8 Class Initialized
DEBUG - 2011-08-01 20:07:47 --> UTF-8 Support Enabled
DEBUG - 2011-08-01 20:07:47 --> URI Class Initialized
DEBUG - 2011-08-01 20:07:47 --> Router Class Initialized
DEBUG - 2011-08-01 20:07:47 --> Output Class Initialized
DEBUG - 2011-08-01 20:07:47 --> Input Class Initialized
DEBUG - 2011-08-01 20:07:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-01 20:07:47 --> Language Class Initialized
DEBUG - 2011-08-01 20:07:47 --> Loader Class Initialized
DEBUG - 2011-08-01 20:07:47 --> Controller Class Initialized
DEBUG - 2011-08-01 20:07:47 --> Model Class Initialized
DEBUG - 2011-08-01 20:07:47 --> Model Class Initialized
DEBUG - 2011-08-01 20:07:47 --> Model Class Initialized
DEBUG - 2011-08-01 20:07:47 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-01 20:07:47 --> Database Driver Class Initialized
DEBUG - 2011-08-01 20:07:47 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-01 20:07:47 --> Helper loaded: url_helper
DEBUG - 2011-08-01 20:07:47 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-01 20:07:47 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-01 20:07:47 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-01 20:07:47 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-01 20:07:47 --> Final output sent to browser
DEBUG - 2011-08-01 20:07:47 --> Total execution time: 0.2150
DEBUG - 2011-08-01 20:07:51 --> Config Class Initialized
DEBUG - 2011-08-01 20:07:51 --> Hooks Class Initialized
DEBUG - 2011-08-01 20:07:51 --> Utf8 Class Initialized
DEBUG - 2011-08-01 20:07:51 --> UTF-8 Support Enabled
DEBUG - 2011-08-01 20:07:51 --> URI Class Initialized
DEBUG - 2011-08-01 20:07:51 --> Router Class Initialized
DEBUG - 2011-08-01 20:07:51 --> Output Class Initialized
DEBUG - 2011-08-01 20:07:51 --> Input Class Initialized
DEBUG - 2011-08-01 20:07:51 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-01 20:07:51 --> Language Class Initialized
DEBUG - 2011-08-01 20:07:51 --> Loader Class Initialized
DEBUG - 2011-08-01 20:07:51 --> Controller Class Initialized
DEBUG - 2011-08-01 20:07:51 --> Model Class Initialized
DEBUG - 2011-08-01 20:07:51 --> Model Class Initialized
DEBUG - 2011-08-01 20:07:51 --> Model Class Initialized
DEBUG - 2011-08-01 20:07:51 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-01 20:07:51 --> Database Driver Class Initialized
DEBUG - 2011-08-01 20:07:51 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-01 20:07:51 --> Helper loaded: url_helper
DEBUG - 2011-08-01 20:07:51 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-01 20:07:51 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-01 20:07:51 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-01 20:07:51 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-01 20:07:51 --> Final output sent to browser
DEBUG - 2011-08-01 20:07:51 --> Total execution time: 0.0468
DEBUG - 2011-08-01 20:07:52 --> Config Class Initialized
DEBUG - 2011-08-01 20:07:52 --> Hooks Class Initialized
DEBUG - 2011-08-01 20:07:52 --> Utf8 Class Initialized
DEBUG - 2011-08-01 20:07:52 --> UTF-8 Support Enabled
DEBUG - 2011-08-01 20:07:52 --> URI Class Initialized
DEBUG - 2011-08-01 20:07:52 --> Router Class Initialized
DEBUG - 2011-08-01 20:07:52 --> Output Class Initialized
DEBUG - 2011-08-01 20:07:52 --> Input Class Initialized
DEBUG - 2011-08-01 20:07:52 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-01 20:07:52 --> Language Class Initialized
DEBUG - 2011-08-01 20:07:52 --> Loader Class Initialized
DEBUG - 2011-08-01 20:07:52 --> Controller Class Initialized
DEBUG - 2011-08-01 20:07:52 --> Model Class Initialized
DEBUG - 2011-08-01 20:07:52 --> Model Class Initialized
DEBUG - 2011-08-01 20:07:52 --> Model Class Initialized
DEBUG - 2011-08-01 20:07:52 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-01 20:07:52 --> Database Driver Class Initialized
DEBUG - 2011-08-01 20:07:52 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-01 20:07:52 --> Helper loaded: url_helper
DEBUG - 2011-08-01 20:07:52 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-01 20:07:52 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-01 20:07:52 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-01 20:07:52 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-01 20:07:52 --> Final output sent to browser
DEBUG - 2011-08-01 20:07:52 --> Total execution time: 0.0488
DEBUG - 2011-08-01 20:08:00 --> Config Class Initialized
DEBUG - 2011-08-01 20:08:00 --> Hooks Class Initialized
DEBUG - 2011-08-01 20:08:00 --> Utf8 Class Initialized
DEBUG - 2011-08-01 20:08:00 --> UTF-8 Support Enabled
DEBUG - 2011-08-01 20:08:00 --> URI Class Initialized
DEBUG - 2011-08-01 20:08:00 --> Router Class Initialized
DEBUG - 2011-08-01 20:08:00 --> Output Class Initialized
DEBUG - 2011-08-01 20:08:00 --> Input Class Initialized
DEBUG - 2011-08-01 20:08:00 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-01 20:08:00 --> Language Class Initialized
DEBUG - 2011-08-01 20:08:00 --> Loader Class Initialized
DEBUG - 2011-08-01 20:08:00 --> Controller Class Initialized
DEBUG - 2011-08-01 20:08:00 --> Model Class Initialized
DEBUG - 2011-08-01 20:08:00 --> Model Class Initialized
DEBUG - 2011-08-01 20:08:00 --> Model Class Initialized
DEBUG - 2011-08-01 20:08:00 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-01 20:08:00 --> Database Driver Class Initialized
DEBUG - 2011-08-01 20:08:00 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-01 20:08:00 --> Helper loaded: url_helper
DEBUG - 2011-08-01 20:08:00 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-01 20:08:00 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-01 20:08:00 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-01 20:08:00 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-01 20:08:00 --> Final output sent to browser
DEBUG - 2011-08-01 20:08:00 --> Total execution time: 0.2488
DEBUG - 2011-08-01 20:08:01 --> Config Class Initialized
DEBUG - 2011-08-01 20:08:01 --> Hooks Class Initialized
DEBUG - 2011-08-01 20:08:01 --> Utf8 Class Initialized
DEBUG - 2011-08-01 20:08:01 --> UTF-8 Support Enabled
DEBUG - 2011-08-01 20:08:01 --> URI Class Initialized
DEBUG - 2011-08-01 20:08:01 --> Router Class Initialized
DEBUG - 2011-08-01 20:08:01 --> Output Class Initialized
DEBUG - 2011-08-01 20:08:01 --> Input Class Initialized
DEBUG - 2011-08-01 20:08:01 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-01 20:08:01 --> Language Class Initialized
DEBUG - 2011-08-01 20:08:01 --> Loader Class Initialized
DEBUG - 2011-08-01 20:08:01 --> Controller Class Initialized
DEBUG - 2011-08-01 20:08:01 --> Model Class Initialized
DEBUG - 2011-08-01 20:08:01 --> Model Class Initialized
DEBUG - 2011-08-01 20:08:01 --> Model Class Initialized
DEBUG - 2011-08-01 20:08:01 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-01 20:08:01 --> Database Driver Class Initialized
DEBUG - 2011-08-01 20:08:01 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-01 20:08:01 --> Helper loaded: url_helper
DEBUG - 2011-08-01 20:08:01 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-01 20:08:01 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-01 20:08:01 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-01 20:08:01 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-01 20:08:01 --> Final output sent to browser
DEBUG - 2011-08-01 20:08:01 --> Total execution time: 0.0810
DEBUG - 2011-08-01 20:08:11 --> Config Class Initialized
DEBUG - 2011-08-01 20:08:11 --> Hooks Class Initialized
DEBUG - 2011-08-01 20:08:11 --> Utf8 Class Initialized
DEBUG - 2011-08-01 20:08:11 --> UTF-8 Support Enabled
DEBUG - 2011-08-01 20:08:11 --> URI Class Initialized
DEBUG - 2011-08-01 20:08:11 --> Router Class Initialized
DEBUG - 2011-08-01 20:08:11 --> Output Class Initialized
DEBUG - 2011-08-01 20:08:11 --> Input Class Initialized
DEBUG - 2011-08-01 20:08:11 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-01 20:08:11 --> Language Class Initialized
DEBUG - 2011-08-01 20:08:11 --> Loader Class Initialized
DEBUG - 2011-08-01 20:08:11 --> Controller Class Initialized
DEBUG - 2011-08-01 20:08:11 --> Model Class Initialized
DEBUG - 2011-08-01 20:08:11 --> Model Class Initialized
DEBUG - 2011-08-01 20:08:11 --> Model Class Initialized
DEBUG - 2011-08-01 20:08:11 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-01 20:08:11 --> Database Driver Class Initialized
DEBUG - 2011-08-01 20:08:12 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-01 20:08:12 --> Helper loaded: url_helper
DEBUG - 2011-08-01 20:08:12 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-01 20:08:12 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-01 20:08:12 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-01 20:08:12 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-01 20:08:12 --> Final output sent to browser
DEBUG - 2011-08-01 20:08:12 --> Total execution time: 0.5611
DEBUG - 2011-08-01 20:08:13 --> Config Class Initialized
DEBUG - 2011-08-01 20:08:13 --> Hooks Class Initialized
DEBUG - 2011-08-01 20:08:13 --> Utf8 Class Initialized
DEBUG - 2011-08-01 20:08:13 --> UTF-8 Support Enabled
DEBUG - 2011-08-01 20:08:13 --> URI Class Initialized
DEBUG - 2011-08-01 20:08:13 --> Router Class Initialized
DEBUG - 2011-08-01 20:08:13 --> Output Class Initialized
DEBUG - 2011-08-01 20:08:13 --> Input Class Initialized
DEBUG - 2011-08-01 20:08:13 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-01 20:08:13 --> Language Class Initialized
DEBUG - 2011-08-01 20:08:13 --> Loader Class Initialized
DEBUG - 2011-08-01 20:08:13 --> Controller Class Initialized
DEBUG - 2011-08-01 20:08:13 --> Model Class Initialized
DEBUG - 2011-08-01 20:08:13 --> Model Class Initialized
DEBUG - 2011-08-01 20:08:13 --> Model Class Initialized
DEBUG - 2011-08-01 20:08:13 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-01 20:08:13 --> Database Driver Class Initialized
DEBUG - 2011-08-01 20:08:13 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-01 20:08:13 --> Helper loaded: url_helper
DEBUG - 2011-08-01 20:08:13 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-01 20:08:13 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-01 20:08:13 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-01 20:08:13 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-01 20:08:13 --> Final output sent to browser
DEBUG - 2011-08-01 20:08:13 --> Total execution time: 0.0445
DEBUG - 2011-08-01 20:08:18 --> Config Class Initialized
DEBUG - 2011-08-01 20:08:18 --> Hooks Class Initialized
DEBUG - 2011-08-01 20:08:18 --> Utf8 Class Initialized
DEBUG - 2011-08-01 20:08:18 --> UTF-8 Support Enabled
DEBUG - 2011-08-01 20:08:18 --> URI Class Initialized
DEBUG - 2011-08-01 20:08:18 --> Router Class Initialized
DEBUG - 2011-08-01 20:08:18 --> Output Class Initialized
DEBUG - 2011-08-01 20:08:18 --> Input Class Initialized
DEBUG - 2011-08-01 20:08:18 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-01 20:08:18 --> Language Class Initialized
DEBUG - 2011-08-01 20:08:18 --> Loader Class Initialized
DEBUG - 2011-08-01 20:08:18 --> Controller Class Initialized
DEBUG - 2011-08-01 20:08:18 --> Model Class Initialized
DEBUG - 2011-08-01 20:08:18 --> Model Class Initialized
DEBUG - 2011-08-01 20:08:18 --> Model Class Initialized
DEBUG - 2011-08-01 20:08:18 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-01 20:08:18 --> Database Driver Class Initialized
DEBUG - 2011-08-01 20:08:18 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-01 20:08:18 --> Helper loaded: url_helper
DEBUG - 2011-08-01 20:08:18 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-01 20:08:18 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-01 20:08:18 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-01 20:08:18 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-01 20:08:18 --> Final output sent to browser
DEBUG - 2011-08-01 20:08:18 --> Total execution time: 0.1981
DEBUG - 2011-08-01 20:08:21 --> Config Class Initialized
DEBUG - 2011-08-01 20:08:21 --> Hooks Class Initialized
DEBUG - 2011-08-01 20:08:21 --> Utf8 Class Initialized
DEBUG - 2011-08-01 20:08:21 --> UTF-8 Support Enabled
DEBUG - 2011-08-01 20:08:21 --> URI Class Initialized
DEBUG - 2011-08-01 20:08:21 --> Router Class Initialized
DEBUG - 2011-08-01 20:08:21 --> Output Class Initialized
DEBUG - 2011-08-01 20:08:21 --> Input Class Initialized
DEBUG - 2011-08-01 20:08:21 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-01 20:08:21 --> Language Class Initialized
DEBUG - 2011-08-01 20:08:21 --> Loader Class Initialized
DEBUG - 2011-08-01 20:08:21 --> Controller Class Initialized
DEBUG - 2011-08-01 20:08:21 --> Model Class Initialized
DEBUG - 2011-08-01 20:08:21 --> Model Class Initialized
DEBUG - 2011-08-01 20:08:21 --> Model Class Initialized
DEBUG - 2011-08-01 20:08:21 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-01 20:08:21 --> Database Driver Class Initialized
DEBUG - 2011-08-01 20:08:21 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-01 20:08:21 --> Helper loaded: url_helper
DEBUG - 2011-08-01 20:08:21 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-01 20:08:21 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-01 20:08:21 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-01 20:08:21 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-01 20:08:21 --> Final output sent to browser
DEBUG - 2011-08-01 20:08:21 --> Total execution time: 0.0454
DEBUG - 2011-08-01 20:08:29 --> Config Class Initialized
DEBUG - 2011-08-01 20:08:29 --> Hooks Class Initialized
DEBUG - 2011-08-01 20:08:29 --> Utf8 Class Initialized
DEBUG - 2011-08-01 20:08:29 --> UTF-8 Support Enabled
DEBUG - 2011-08-01 20:08:29 --> URI Class Initialized
DEBUG - 2011-08-01 20:08:29 --> Router Class Initialized
DEBUG - 2011-08-01 20:08:29 --> Output Class Initialized
DEBUG - 2011-08-01 20:08:29 --> Input Class Initialized
DEBUG - 2011-08-01 20:08:29 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-01 20:08:29 --> Language Class Initialized
DEBUG - 2011-08-01 20:08:29 --> Loader Class Initialized
DEBUG - 2011-08-01 20:08:29 --> Controller Class Initialized
DEBUG - 2011-08-01 20:08:29 --> Model Class Initialized
DEBUG - 2011-08-01 20:08:29 --> Model Class Initialized
DEBUG - 2011-08-01 20:08:29 --> Model Class Initialized
DEBUG - 2011-08-01 20:08:29 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-01 20:08:29 --> Database Driver Class Initialized
DEBUG - 2011-08-01 20:08:29 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-01 20:08:29 --> Helper loaded: url_helper
DEBUG - 2011-08-01 20:08:29 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-01 20:08:29 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-01 20:08:29 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-01 20:08:29 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-01 20:08:29 --> Final output sent to browser
DEBUG - 2011-08-01 20:08:29 --> Total execution time: 0.2396
DEBUG - 2011-08-01 20:08:31 --> Config Class Initialized
DEBUG - 2011-08-01 20:08:31 --> Hooks Class Initialized
DEBUG - 2011-08-01 20:08:31 --> Utf8 Class Initialized
DEBUG - 2011-08-01 20:08:31 --> UTF-8 Support Enabled
DEBUG - 2011-08-01 20:08:31 --> URI Class Initialized
DEBUG - 2011-08-01 20:08:31 --> Router Class Initialized
DEBUG - 2011-08-01 20:08:31 --> Output Class Initialized
DEBUG - 2011-08-01 20:08:31 --> Input Class Initialized
DEBUG - 2011-08-01 20:08:31 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-01 20:08:31 --> Language Class Initialized
DEBUG - 2011-08-01 20:08:31 --> Loader Class Initialized
DEBUG - 2011-08-01 20:08:31 --> Controller Class Initialized
DEBUG - 2011-08-01 20:08:31 --> Model Class Initialized
DEBUG - 2011-08-01 20:08:31 --> Model Class Initialized
DEBUG - 2011-08-01 20:08:31 --> Model Class Initialized
DEBUG - 2011-08-01 20:08:31 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-01 20:08:31 --> Database Driver Class Initialized
DEBUG - 2011-08-01 20:08:31 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-01 20:08:31 --> Helper loaded: url_helper
DEBUG - 2011-08-01 20:08:31 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-01 20:08:31 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-01 20:08:31 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-01 20:08:31 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-01 20:08:31 --> Final output sent to browser
DEBUG - 2011-08-01 20:08:31 --> Total execution time: 0.0505
DEBUG - 2011-08-01 20:08:35 --> Config Class Initialized
DEBUG - 2011-08-01 20:08:35 --> Hooks Class Initialized
DEBUG - 2011-08-01 20:08:35 --> Utf8 Class Initialized
DEBUG - 2011-08-01 20:08:35 --> UTF-8 Support Enabled
DEBUG - 2011-08-01 20:08:35 --> URI Class Initialized
DEBUG - 2011-08-01 20:08:35 --> Router Class Initialized
DEBUG - 2011-08-01 20:08:35 --> Output Class Initialized
DEBUG - 2011-08-01 20:08:35 --> Input Class Initialized
DEBUG - 2011-08-01 20:08:35 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-01 20:08:35 --> Language Class Initialized
DEBUG - 2011-08-01 20:08:35 --> Loader Class Initialized
DEBUG - 2011-08-01 20:08:35 --> Controller Class Initialized
DEBUG - 2011-08-01 20:08:35 --> Model Class Initialized
DEBUG - 2011-08-01 20:08:35 --> Model Class Initialized
DEBUG - 2011-08-01 20:08:35 --> Model Class Initialized
DEBUG - 2011-08-01 20:08:35 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-01 20:08:35 --> Database Driver Class Initialized
DEBUG - 2011-08-01 20:08:35 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-01 20:08:35 --> Helper loaded: url_helper
DEBUG - 2011-08-01 20:08:35 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-01 20:08:35 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-01 20:08:35 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-01 20:08:35 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-01 20:08:35 --> Final output sent to browser
DEBUG - 2011-08-01 20:08:35 --> Total execution time: 0.1898
DEBUG - 2011-08-01 20:08:37 --> Config Class Initialized
DEBUG - 2011-08-01 20:08:37 --> Hooks Class Initialized
DEBUG - 2011-08-01 20:08:37 --> Utf8 Class Initialized
DEBUG - 2011-08-01 20:08:37 --> UTF-8 Support Enabled
DEBUG - 2011-08-01 20:08:37 --> URI Class Initialized
DEBUG - 2011-08-01 20:08:37 --> Router Class Initialized
DEBUG - 2011-08-01 20:08:37 --> Output Class Initialized
DEBUG - 2011-08-01 20:08:37 --> Input Class Initialized
DEBUG - 2011-08-01 20:08:37 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-01 20:08:37 --> Language Class Initialized
DEBUG - 2011-08-01 20:08:37 --> Loader Class Initialized
DEBUG - 2011-08-01 20:08:37 --> Controller Class Initialized
DEBUG - 2011-08-01 20:08:37 --> Model Class Initialized
DEBUG - 2011-08-01 20:08:37 --> Model Class Initialized
DEBUG - 2011-08-01 20:08:37 --> Model Class Initialized
DEBUG - 2011-08-01 20:08:37 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-01 20:08:37 --> Database Driver Class Initialized
DEBUG - 2011-08-01 20:08:37 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-01 20:08:37 --> Helper loaded: url_helper
DEBUG - 2011-08-01 20:08:37 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-01 20:08:37 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-01 20:08:37 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-01 20:08:37 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-01 20:08:37 --> Final output sent to browser
DEBUG - 2011-08-01 20:08:37 --> Total execution time: 0.0455
DEBUG - 2011-08-01 20:08:41 --> Config Class Initialized
DEBUG - 2011-08-01 20:08:41 --> Hooks Class Initialized
DEBUG - 2011-08-01 20:08:41 --> Utf8 Class Initialized
DEBUG - 2011-08-01 20:08:41 --> UTF-8 Support Enabled
DEBUG - 2011-08-01 20:08:41 --> URI Class Initialized
DEBUG - 2011-08-01 20:08:41 --> Router Class Initialized
DEBUG - 2011-08-01 20:08:41 --> Output Class Initialized
DEBUG - 2011-08-01 20:08:41 --> Input Class Initialized
DEBUG - 2011-08-01 20:08:41 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-01 20:08:41 --> Language Class Initialized
DEBUG - 2011-08-01 20:08:41 --> Loader Class Initialized
DEBUG - 2011-08-01 20:08:41 --> Controller Class Initialized
DEBUG - 2011-08-01 20:08:41 --> Model Class Initialized
DEBUG - 2011-08-01 20:08:41 --> Model Class Initialized
DEBUG - 2011-08-01 20:08:41 --> Model Class Initialized
DEBUG - 2011-08-01 20:08:41 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-01 20:08:41 --> Database Driver Class Initialized
DEBUG - 2011-08-01 20:08:41 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-01 20:08:41 --> Helper loaded: url_helper
DEBUG - 2011-08-01 20:08:41 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-01 20:08:41 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-01 20:08:41 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-01 20:08:41 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-01 20:08:41 --> Final output sent to browser
DEBUG - 2011-08-01 20:08:41 --> Total execution time: 0.2028
DEBUG - 2011-08-01 20:08:46 --> Config Class Initialized
DEBUG - 2011-08-01 20:08:46 --> Hooks Class Initialized
DEBUG - 2011-08-01 20:08:46 --> Utf8 Class Initialized
DEBUG - 2011-08-01 20:08:46 --> UTF-8 Support Enabled
DEBUG - 2011-08-01 20:08:46 --> URI Class Initialized
DEBUG - 2011-08-01 20:08:46 --> Router Class Initialized
DEBUG - 2011-08-01 20:08:46 --> Output Class Initialized
DEBUG - 2011-08-01 20:08:46 --> Input Class Initialized
DEBUG - 2011-08-01 20:08:46 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-01 20:08:46 --> Language Class Initialized
DEBUG - 2011-08-01 20:08:46 --> Loader Class Initialized
DEBUG - 2011-08-01 20:08:46 --> Controller Class Initialized
DEBUG - 2011-08-01 20:08:46 --> Model Class Initialized
DEBUG - 2011-08-01 20:08:46 --> Model Class Initialized
DEBUG - 2011-08-01 20:08:46 --> Model Class Initialized
DEBUG - 2011-08-01 20:08:46 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-01 20:08:46 --> Database Driver Class Initialized
DEBUG - 2011-08-01 20:08:46 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-01 20:08:46 --> Helper loaded: url_helper
DEBUG - 2011-08-01 20:08:46 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-01 20:08:46 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-01 20:08:46 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-01 20:08:46 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-01 20:08:46 --> Final output sent to browser
DEBUG - 2011-08-01 20:08:46 --> Total execution time: 0.0440
DEBUG - 2011-08-01 20:08:48 --> Config Class Initialized
DEBUG - 2011-08-01 20:08:48 --> Hooks Class Initialized
DEBUG - 2011-08-01 20:08:48 --> Utf8 Class Initialized
DEBUG - 2011-08-01 20:08:48 --> UTF-8 Support Enabled
DEBUG - 2011-08-01 20:08:48 --> URI Class Initialized
DEBUG - 2011-08-01 20:08:48 --> Router Class Initialized
DEBUG - 2011-08-01 20:08:48 --> Output Class Initialized
DEBUG - 2011-08-01 20:08:48 --> Input Class Initialized
DEBUG - 2011-08-01 20:08:48 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-01 20:08:48 --> Language Class Initialized
DEBUG - 2011-08-01 20:08:48 --> Loader Class Initialized
DEBUG - 2011-08-01 20:08:48 --> Controller Class Initialized
DEBUG - 2011-08-01 20:08:48 --> Model Class Initialized
DEBUG - 2011-08-01 20:08:48 --> Model Class Initialized
DEBUG - 2011-08-01 20:08:48 --> Model Class Initialized
DEBUG - 2011-08-01 20:08:48 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-01 20:08:48 --> Database Driver Class Initialized
DEBUG - 2011-08-01 20:08:49 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-01 20:08:49 --> Helper loaded: url_helper
DEBUG - 2011-08-01 20:08:49 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-01 20:08:49 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-01 20:08:49 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-01 20:08:49 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-01 20:08:49 --> Final output sent to browser
DEBUG - 2011-08-01 20:08:49 --> Total execution time: 0.2323
DEBUG - 2011-08-01 20:08:51 --> Config Class Initialized
DEBUG - 2011-08-01 20:08:51 --> Hooks Class Initialized
DEBUG - 2011-08-01 20:08:51 --> Utf8 Class Initialized
DEBUG - 2011-08-01 20:08:51 --> UTF-8 Support Enabled
DEBUG - 2011-08-01 20:08:51 --> URI Class Initialized
DEBUG - 2011-08-01 20:08:51 --> Router Class Initialized
DEBUG - 2011-08-01 20:08:51 --> Output Class Initialized
DEBUG - 2011-08-01 20:08:51 --> Input Class Initialized
DEBUG - 2011-08-01 20:08:51 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-01 20:08:51 --> Language Class Initialized
DEBUG - 2011-08-01 20:08:51 --> Loader Class Initialized
DEBUG - 2011-08-01 20:08:51 --> Controller Class Initialized
DEBUG - 2011-08-01 20:08:51 --> Model Class Initialized
DEBUG - 2011-08-01 20:08:51 --> Model Class Initialized
DEBUG - 2011-08-01 20:08:51 --> Model Class Initialized
DEBUG - 2011-08-01 20:08:51 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-01 20:08:51 --> Database Driver Class Initialized
DEBUG - 2011-08-01 20:08:51 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-01 20:08:51 --> Helper loaded: url_helper
DEBUG - 2011-08-01 20:08:51 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-01 20:08:51 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-01 20:08:51 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-01 20:08:51 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-01 20:08:51 --> Final output sent to browser
DEBUG - 2011-08-01 20:08:51 --> Total execution time: 0.0799
DEBUG - 2011-08-01 20:08:57 --> Config Class Initialized
DEBUG - 2011-08-01 20:08:57 --> Hooks Class Initialized
DEBUG - 2011-08-01 20:08:57 --> Utf8 Class Initialized
DEBUG - 2011-08-01 20:08:57 --> UTF-8 Support Enabled
DEBUG - 2011-08-01 20:08:57 --> URI Class Initialized
DEBUG - 2011-08-01 20:08:57 --> Router Class Initialized
DEBUG - 2011-08-01 20:08:57 --> Output Class Initialized
DEBUG - 2011-08-01 20:08:57 --> Input Class Initialized
DEBUG - 2011-08-01 20:08:57 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-01 20:08:57 --> Language Class Initialized
DEBUG - 2011-08-01 20:08:57 --> Loader Class Initialized
DEBUG - 2011-08-01 20:08:57 --> Controller Class Initialized
DEBUG - 2011-08-01 20:08:57 --> Model Class Initialized
DEBUG - 2011-08-01 20:08:57 --> Model Class Initialized
DEBUG - 2011-08-01 20:08:57 --> Model Class Initialized
DEBUG - 2011-08-01 20:08:57 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-01 20:08:57 --> Database Driver Class Initialized
DEBUG - 2011-08-01 20:08:58 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-01 20:08:58 --> Helper loaded: url_helper
DEBUG - 2011-08-01 20:08:58 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-01 20:08:58 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-01 20:08:58 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-01 20:08:58 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-01 20:08:58 --> Final output sent to browser
DEBUG - 2011-08-01 20:08:58 --> Total execution time: 0.1852
DEBUG - 2011-08-01 20:08:59 --> Config Class Initialized
DEBUG - 2011-08-01 20:08:59 --> Hooks Class Initialized
DEBUG - 2011-08-01 20:08:59 --> Utf8 Class Initialized
DEBUG - 2011-08-01 20:08:59 --> UTF-8 Support Enabled
DEBUG - 2011-08-01 20:08:59 --> URI Class Initialized
DEBUG - 2011-08-01 20:08:59 --> Router Class Initialized
DEBUG - 2011-08-01 20:08:59 --> Output Class Initialized
DEBUG - 2011-08-01 20:08:59 --> Input Class Initialized
DEBUG - 2011-08-01 20:08:59 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-01 20:08:59 --> Language Class Initialized
DEBUG - 2011-08-01 20:08:59 --> Loader Class Initialized
DEBUG - 2011-08-01 20:08:59 --> Controller Class Initialized
DEBUG - 2011-08-01 20:08:59 --> Model Class Initialized
DEBUG - 2011-08-01 20:08:59 --> Model Class Initialized
DEBUG - 2011-08-01 20:08:59 --> Model Class Initialized
DEBUG - 2011-08-01 20:08:59 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-01 20:08:59 --> Database Driver Class Initialized
DEBUG - 2011-08-01 20:08:59 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-01 20:08:59 --> Helper loaded: url_helper
DEBUG - 2011-08-01 20:08:59 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-01 20:08:59 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-01 20:08:59 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-01 20:08:59 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-01 20:08:59 --> Final output sent to browser
DEBUG - 2011-08-01 20:08:59 --> Total execution time: 0.0459
DEBUG - 2011-08-01 20:09:02 --> Config Class Initialized
DEBUG - 2011-08-01 20:09:02 --> Hooks Class Initialized
DEBUG - 2011-08-01 20:09:02 --> Utf8 Class Initialized
DEBUG - 2011-08-01 20:09:02 --> UTF-8 Support Enabled
DEBUG - 2011-08-01 20:09:02 --> URI Class Initialized
DEBUG - 2011-08-01 20:09:02 --> Router Class Initialized
DEBUG - 2011-08-01 20:09:02 --> Output Class Initialized
DEBUG - 2011-08-01 20:09:02 --> Input Class Initialized
DEBUG - 2011-08-01 20:09:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-01 20:09:02 --> Language Class Initialized
DEBUG - 2011-08-01 20:09:02 --> Loader Class Initialized
DEBUG - 2011-08-01 20:09:02 --> Controller Class Initialized
DEBUG - 2011-08-01 20:09:02 --> Model Class Initialized
DEBUG - 2011-08-01 20:09:02 --> Model Class Initialized
DEBUG - 2011-08-01 20:09:02 --> Model Class Initialized
DEBUG - 2011-08-01 20:09:02 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-01 20:09:02 --> Database Driver Class Initialized
DEBUG - 2011-08-01 20:09:02 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-01 20:09:02 --> Helper loaded: url_helper
DEBUG - 2011-08-01 20:09:02 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-01 20:09:02 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-01 20:09:02 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-01 20:09:02 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-01 20:09:02 --> Final output sent to browser
DEBUG - 2011-08-01 20:09:02 --> Total execution time: 0.3431
DEBUG - 2011-08-01 20:09:05 --> Config Class Initialized
DEBUG - 2011-08-01 20:09:05 --> Hooks Class Initialized
DEBUG - 2011-08-01 20:09:05 --> Utf8 Class Initialized
DEBUG - 2011-08-01 20:09:05 --> UTF-8 Support Enabled
DEBUG - 2011-08-01 20:09:05 --> URI Class Initialized
DEBUG - 2011-08-01 20:09:05 --> Router Class Initialized
DEBUG - 2011-08-01 20:09:05 --> Output Class Initialized
DEBUG - 2011-08-01 20:09:05 --> Input Class Initialized
DEBUG - 2011-08-01 20:09:05 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-01 20:09:05 --> Language Class Initialized
DEBUG - 2011-08-01 20:09:05 --> Loader Class Initialized
DEBUG - 2011-08-01 20:09:05 --> Controller Class Initialized
DEBUG - 2011-08-01 20:09:05 --> Model Class Initialized
DEBUG - 2011-08-01 20:09:05 --> Model Class Initialized
DEBUG - 2011-08-01 20:09:05 --> Model Class Initialized
DEBUG - 2011-08-01 20:09:05 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-01 20:09:05 --> Database Driver Class Initialized
DEBUG - 2011-08-01 20:09:05 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-01 20:09:05 --> Helper loaded: url_helper
DEBUG - 2011-08-01 20:09:05 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-01 20:09:05 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-01 20:09:05 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-01 20:09:05 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-01 20:09:05 --> Final output sent to browser
DEBUG - 2011-08-01 20:09:05 --> Total execution time: 0.0516
DEBUG - 2011-08-01 20:09:07 --> Config Class Initialized
DEBUG - 2011-08-01 20:09:07 --> Hooks Class Initialized
DEBUG - 2011-08-01 20:09:07 --> Utf8 Class Initialized
DEBUG - 2011-08-01 20:09:07 --> UTF-8 Support Enabled
DEBUG - 2011-08-01 20:09:07 --> URI Class Initialized
DEBUG - 2011-08-01 20:09:07 --> Router Class Initialized
DEBUG - 2011-08-01 20:09:07 --> Output Class Initialized
DEBUG - 2011-08-01 20:09:07 --> Input Class Initialized
DEBUG - 2011-08-01 20:09:07 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-01 20:09:07 --> Language Class Initialized
DEBUG - 2011-08-01 20:09:07 --> Loader Class Initialized
DEBUG - 2011-08-01 20:09:07 --> Controller Class Initialized
DEBUG - 2011-08-01 20:09:07 --> Model Class Initialized
DEBUG - 2011-08-01 20:09:07 --> Model Class Initialized
DEBUG - 2011-08-01 20:09:07 --> Model Class Initialized
DEBUG - 2011-08-01 20:09:07 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-01 20:09:07 --> Database Driver Class Initialized
DEBUG - 2011-08-01 20:09:07 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-01 20:09:07 --> Helper loaded: url_helper
DEBUG - 2011-08-01 20:09:07 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-01 20:09:07 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-01 20:09:07 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-01 20:09:07 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-01 20:09:07 --> Final output sent to browser
DEBUG - 2011-08-01 20:09:07 --> Total execution time: 0.3185
DEBUG - 2011-08-01 20:09:09 --> Config Class Initialized
DEBUG - 2011-08-01 20:09:09 --> Hooks Class Initialized
DEBUG - 2011-08-01 20:09:09 --> Utf8 Class Initialized
DEBUG - 2011-08-01 20:09:09 --> UTF-8 Support Enabled
DEBUG - 2011-08-01 20:09:09 --> URI Class Initialized
DEBUG - 2011-08-01 20:09:09 --> Router Class Initialized
DEBUG - 2011-08-01 20:09:09 --> Output Class Initialized
DEBUG - 2011-08-01 20:09:09 --> Input Class Initialized
DEBUG - 2011-08-01 20:09:09 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-01 20:09:09 --> Language Class Initialized
DEBUG - 2011-08-01 20:09:09 --> Loader Class Initialized
DEBUG - 2011-08-01 20:09:09 --> Controller Class Initialized
DEBUG - 2011-08-01 20:09:09 --> Model Class Initialized
DEBUG - 2011-08-01 20:09:09 --> Model Class Initialized
DEBUG - 2011-08-01 20:09:09 --> Model Class Initialized
DEBUG - 2011-08-01 20:09:09 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-01 20:09:09 --> Database Driver Class Initialized
DEBUG - 2011-08-01 20:09:09 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-01 20:09:09 --> Helper loaded: url_helper
DEBUG - 2011-08-01 20:09:09 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-01 20:09:09 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-01 20:09:09 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-01 20:09:09 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-01 20:09:09 --> Final output sent to browser
DEBUG - 2011-08-01 20:09:09 --> Total execution time: 0.1091
DEBUG - 2011-08-01 20:09:12 --> Config Class Initialized
DEBUG - 2011-08-01 20:09:12 --> Hooks Class Initialized
DEBUG - 2011-08-01 20:09:12 --> Utf8 Class Initialized
DEBUG - 2011-08-01 20:09:12 --> UTF-8 Support Enabled
DEBUG - 2011-08-01 20:09:12 --> URI Class Initialized
DEBUG - 2011-08-01 20:09:12 --> Router Class Initialized
DEBUG - 2011-08-01 20:09:12 --> Output Class Initialized
DEBUG - 2011-08-01 20:09:12 --> Input Class Initialized
DEBUG - 2011-08-01 20:09:12 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-01 20:09:12 --> Language Class Initialized
DEBUG - 2011-08-01 20:09:12 --> Loader Class Initialized
DEBUG - 2011-08-01 20:09:12 --> Controller Class Initialized
DEBUG - 2011-08-01 20:09:12 --> Model Class Initialized
DEBUG - 2011-08-01 20:09:12 --> Model Class Initialized
DEBUG - 2011-08-01 20:09:12 --> Model Class Initialized
DEBUG - 2011-08-01 20:09:12 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-01 20:09:12 --> Database Driver Class Initialized
DEBUG - 2011-08-01 20:09:13 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-01 20:09:13 --> Helper loaded: url_helper
DEBUG - 2011-08-01 20:09:13 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-01 20:09:13 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-01 20:09:13 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-01 20:09:13 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-01 20:09:13 --> Final output sent to browser
DEBUG - 2011-08-01 20:09:13 --> Total execution time: 0.2794
DEBUG - 2011-08-01 20:09:14 --> Config Class Initialized
DEBUG - 2011-08-01 20:09:14 --> Hooks Class Initialized
DEBUG - 2011-08-01 20:09:14 --> Utf8 Class Initialized
DEBUG - 2011-08-01 20:09:14 --> UTF-8 Support Enabled
DEBUG - 2011-08-01 20:09:14 --> URI Class Initialized
DEBUG - 2011-08-01 20:09:14 --> Router Class Initialized
DEBUG - 2011-08-01 20:09:14 --> Output Class Initialized
DEBUG - 2011-08-01 20:09:14 --> Input Class Initialized
DEBUG - 2011-08-01 20:09:14 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-01 20:09:14 --> Language Class Initialized
DEBUG - 2011-08-01 20:09:14 --> Loader Class Initialized
DEBUG - 2011-08-01 20:09:14 --> Controller Class Initialized
DEBUG - 2011-08-01 20:09:14 --> Model Class Initialized
DEBUG - 2011-08-01 20:09:14 --> Model Class Initialized
DEBUG - 2011-08-01 20:09:14 --> Model Class Initialized
DEBUG - 2011-08-01 20:09:14 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-01 20:09:14 --> Database Driver Class Initialized
DEBUG - 2011-08-01 20:09:14 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-01 20:09:14 --> Helper loaded: url_helper
DEBUG - 2011-08-01 20:09:14 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-01 20:09:14 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-01 20:09:14 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-01 20:09:14 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-01 20:09:14 --> Final output sent to browser
DEBUG - 2011-08-01 20:09:14 --> Total execution time: 0.0679
DEBUG - 2011-08-01 20:09:21 --> Config Class Initialized
DEBUG - 2011-08-01 20:09:21 --> Hooks Class Initialized
DEBUG - 2011-08-01 20:09:21 --> Utf8 Class Initialized
DEBUG - 2011-08-01 20:09:21 --> UTF-8 Support Enabled
DEBUG - 2011-08-01 20:09:21 --> URI Class Initialized
DEBUG - 2011-08-01 20:09:21 --> Router Class Initialized
DEBUG - 2011-08-01 20:09:21 --> Output Class Initialized
DEBUG - 2011-08-01 20:09:21 --> Input Class Initialized
DEBUG - 2011-08-01 20:09:21 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-01 20:09:21 --> Language Class Initialized
DEBUG - 2011-08-01 20:09:21 --> Loader Class Initialized
DEBUG - 2011-08-01 20:09:21 --> Controller Class Initialized
DEBUG - 2011-08-01 20:09:21 --> Model Class Initialized
DEBUG - 2011-08-01 20:09:21 --> Model Class Initialized
DEBUG - 2011-08-01 20:09:21 --> Model Class Initialized
DEBUG - 2011-08-01 20:09:21 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-01 20:09:21 --> Database Driver Class Initialized
DEBUG - 2011-08-01 20:09:21 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-01 20:09:21 --> Helper loaded: url_helper
DEBUG - 2011-08-01 20:09:21 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-01 20:09:21 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-01 20:09:21 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-01 20:09:21 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-01 20:09:21 --> Final output sent to browser
DEBUG - 2011-08-01 20:09:21 --> Total execution time: 0.2503
DEBUG - 2011-08-01 20:09:23 --> Config Class Initialized
DEBUG - 2011-08-01 20:09:23 --> Hooks Class Initialized
DEBUG - 2011-08-01 20:09:23 --> Utf8 Class Initialized
DEBUG - 2011-08-01 20:09:23 --> UTF-8 Support Enabled
DEBUG - 2011-08-01 20:09:23 --> URI Class Initialized
DEBUG - 2011-08-01 20:09:23 --> Router Class Initialized
DEBUG - 2011-08-01 20:09:23 --> Output Class Initialized
DEBUG - 2011-08-01 20:09:23 --> Input Class Initialized
DEBUG - 2011-08-01 20:09:23 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-01 20:09:23 --> Language Class Initialized
DEBUG - 2011-08-01 20:09:23 --> Loader Class Initialized
DEBUG - 2011-08-01 20:09:23 --> Controller Class Initialized
DEBUG - 2011-08-01 20:09:23 --> Model Class Initialized
DEBUG - 2011-08-01 20:09:23 --> Model Class Initialized
DEBUG - 2011-08-01 20:09:23 --> Model Class Initialized
DEBUG - 2011-08-01 20:09:23 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-01 20:09:23 --> Database Driver Class Initialized
DEBUG - 2011-08-01 20:09:23 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-01 20:09:23 --> Helper loaded: url_helper
DEBUG - 2011-08-01 20:09:23 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-01 20:09:23 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-01 20:09:23 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-01 20:09:23 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-01 20:09:23 --> Final output sent to browser
DEBUG - 2011-08-01 20:09:23 --> Total execution time: 0.0428
DEBUG - 2011-08-01 20:09:30 --> Config Class Initialized
DEBUG - 2011-08-01 20:09:30 --> Hooks Class Initialized
DEBUG - 2011-08-01 20:09:30 --> Utf8 Class Initialized
DEBUG - 2011-08-01 20:09:30 --> UTF-8 Support Enabled
DEBUG - 2011-08-01 20:09:30 --> URI Class Initialized
DEBUG - 2011-08-01 20:09:30 --> Router Class Initialized
DEBUG - 2011-08-01 20:09:30 --> Output Class Initialized
DEBUG - 2011-08-01 20:09:30 --> Input Class Initialized
DEBUG - 2011-08-01 20:09:30 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-01 20:09:30 --> Language Class Initialized
DEBUG - 2011-08-01 20:09:30 --> Loader Class Initialized
DEBUG - 2011-08-01 20:09:30 --> Controller Class Initialized
DEBUG - 2011-08-01 20:09:30 --> Model Class Initialized
DEBUG - 2011-08-01 20:09:30 --> Model Class Initialized
DEBUG - 2011-08-01 20:09:30 --> Model Class Initialized
DEBUG - 2011-08-01 20:09:30 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-01 20:09:30 --> Database Driver Class Initialized
DEBUG - 2011-08-01 20:09:31 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-01 20:09:31 --> Helper loaded: url_helper
DEBUG - 2011-08-01 20:09:31 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-01 20:09:31 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-01 20:09:31 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-01 20:09:31 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-01 20:09:31 --> Final output sent to browser
DEBUG - 2011-08-01 20:09:31 --> Total execution time: 0.2395
DEBUG - 2011-08-01 20:09:32 --> Config Class Initialized
DEBUG - 2011-08-01 20:09:32 --> Hooks Class Initialized
DEBUG - 2011-08-01 20:09:32 --> Utf8 Class Initialized
DEBUG - 2011-08-01 20:09:32 --> UTF-8 Support Enabled
DEBUG - 2011-08-01 20:09:32 --> URI Class Initialized
DEBUG - 2011-08-01 20:09:32 --> Router Class Initialized
DEBUG - 2011-08-01 20:09:32 --> Output Class Initialized
DEBUG - 2011-08-01 20:09:32 --> Input Class Initialized
DEBUG - 2011-08-01 20:09:32 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-01 20:09:32 --> Language Class Initialized
DEBUG - 2011-08-01 20:09:32 --> Loader Class Initialized
DEBUG - 2011-08-01 20:09:32 --> Controller Class Initialized
DEBUG - 2011-08-01 20:09:32 --> Model Class Initialized
DEBUG - 2011-08-01 20:09:32 --> Model Class Initialized
DEBUG - 2011-08-01 20:09:32 --> Model Class Initialized
DEBUG - 2011-08-01 20:09:32 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-01 20:09:32 --> Database Driver Class Initialized
DEBUG - 2011-08-01 20:09:32 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-01 20:09:32 --> Helper loaded: url_helper
DEBUG - 2011-08-01 20:09:32 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-01 20:09:32 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-01 20:09:32 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-01 20:09:32 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-01 20:09:32 --> Final output sent to browser
DEBUG - 2011-08-01 20:09:32 --> Total execution time: 0.0492
DEBUG - 2011-08-01 20:09:37 --> Config Class Initialized
DEBUG - 2011-08-01 20:09:37 --> Hooks Class Initialized
DEBUG - 2011-08-01 20:09:37 --> Utf8 Class Initialized
DEBUG - 2011-08-01 20:09:37 --> UTF-8 Support Enabled
DEBUG - 2011-08-01 20:09:37 --> URI Class Initialized
DEBUG - 2011-08-01 20:09:37 --> Router Class Initialized
DEBUG - 2011-08-01 20:09:37 --> Output Class Initialized
DEBUG - 2011-08-01 20:09:37 --> Input Class Initialized
DEBUG - 2011-08-01 20:09:37 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-01 20:09:37 --> Language Class Initialized
DEBUG - 2011-08-01 20:09:37 --> Loader Class Initialized
DEBUG - 2011-08-01 20:09:37 --> Controller Class Initialized
DEBUG - 2011-08-01 20:09:37 --> Model Class Initialized
DEBUG - 2011-08-01 20:09:37 --> Model Class Initialized
DEBUG - 2011-08-01 20:09:37 --> Model Class Initialized
DEBUG - 2011-08-01 20:09:37 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-01 20:09:37 --> Database Driver Class Initialized
DEBUG - 2011-08-01 20:09:37 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-01 20:09:37 --> Helper loaded: url_helper
DEBUG - 2011-08-01 20:09:37 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-01 20:09:37 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-01 20:09:37 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-01 20:09:37 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-01 20:09:37 --> Final output sent to browser
DEBUG - 2011-08-01 20:09:37 --> Total execution time: 0.2368
DEBUG - 2011-08-01 20:09:38 --> Config Class Initialized
DEBUG - 2011-08-01 20:09:38 --> Hooks Class Initialized
DEBUG - 2011-08-01 20:09:38 --> Utf8 Class Initialized
DEBUG - 2011-08-01 20:09:38 --> UTF-8 Support Enabled
DEBUG - 2011-08-01 20:09:38 --> URI Class Initialized
DEBUG - 2011-08-01 20:09:38 --> Router Class Initialized
DEBUG - 2011-08-01 20:09:38 --> Output Class Initialized
DEBUG - 2011-08-01 20:09:38 --> Input Class Initialized
DEBUG - 2011-08-01 20:09:38 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-01 20:09:38 --> Language Class Initialized
DEBUG - 2011-08-01 20:09:38 --> Loader Class Initialized
DEBUG - 2011-08-01 20:09:38 --> Controller Class Initialized
DEBUG - 2011-08-01 20:09:38 --> Model Class Initialized
DEBUG - 2011-08-01 20:09:38 --> Model Class Initialized
DEBUG - 2011-08-01 20:09:38 --> Model Class Initialized
DEBUG - 2011-08-01 20:09:38 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-01 20:09:38 --> Database Driver Class Initialized
DEBUG - 2011-08-01 20:09:38 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-01 20:09:38 --> Helper loaded: url_helper
DEBUG - 2011-08-01 20:09:38 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-01 20:09:38 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-01 20:09:38 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-01 20:09:38 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-01 20:09:38 --> Final output sent to browser
DEBUG - 2011-08-01 20:09:38 --> Total execution time: 0.0429
DEBUG - 2011-08-01 20:09:42 --> Config Class Initialized
DEBUG - 2011-08-01 20:09:42 --> Hooks Class Initialized
DEBUG - 2011-08-01 20:09:42 --> Utf8 Class Initialized
DEBUG - 2011-08-01 20:09:42 --> UTF-8 Support Enabled
DEBUG - 2011-08-01 20:09:42 --> URI Class Initialized
DEBUG - 2011-08-01 20:09:42 --> Router Class Initialized
DEBUG - 2011-08-01 20:09:42 --> Output Class Initialized
DEBUG - 2011-08-01 20:09:42 --> Input Class Initialized
DEBUG - 2011-08-01 20:09:42 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-01 20:09:42 --> Language Class Initialized
DEBUG - 2011-08-01 20:09:42 --> Loader Class Initialized
DEBUG - 2011-08-01 20:09:42 --> Controller Class Initialized
DEBUG - 2011-08-01 20:09:42 --> Model Class Initialized
DEBUG - 2011-08-01 20:09:42 --> Model Class Initialized
DEBUG - 2011-08-01 20:09:42 --> Model Class Initialized
DEBUG - 2011-08-01 20:09:42 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-01 20:09:42 --> Database Driver Class Initialized
DEBUG - 2011-08-01 20:09:42 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-01 20:09:42 --> Helper loaded: url_helper
DEBUG - 2011-08-01 20:09:42 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-01 20:09:42 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-01 20:09:42 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-01 20:09:42 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-01 20:09:42 --> Final output sent to browser
DEBUG - 2011-08-01 20:09:42 --> Total execution time: 0.2232
DEBUG - 2011-08-01 20:09:43 --> Config Class Initialized
DEBUG - 2011-08-01 20:09:43 --> Hooks Class Initialized
DEBUG - 2011-08-01 20:09:43 --> Utf8 Class Initialized
DEBUG - 2011-08-01 20:09:43 --> UTF-8 Support Enabled
DEBUG - 2011-08-01 20:09:43 --> URI Class Initialized
DEBUG - 2011-08-01 20:09:43 --> Router Class Initialized
DEBUG - 2011-08-01 20:09:43 --> Output Class Initialized
DEBUG - 2011-08-01 20:09:43 --> Input Class Initialized
DEBUG - 2011-08-01 20:09:43 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-01 20:09:43 --> Language Class Initialized
DEBUG - 2011-08-01 20:09:43 --> Loader Class Initialized
DEBUG - 2011-08-01 20:09:43 --> Controller Class Initialized
DEBUG - 2011-08-01 20:09:43 --> Model Class Initialized
DEBUG - 2011-08-01 20:09:43 --> Model Class Initialized
DEBUG - 2011-08-01 20:09:43 --> Model Class Initialized
DEBUG - 2011-08-01 20:09:43 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-01 20:09:43 --> Database Driver Class Initialized
DEBUG - 2011-08-01 20:09:43 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-01 20:09:43 --> Helper loaded: url_helper
DEBUG - 2011-08-01 20:09:43 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-01 20:09:43 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-01 20:09:43 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-01 20:09:43 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-01 20:09:43 --> Final output sent to browser
DEBUG - 2011-08-01 20:09:43 --> Total execution time: 0.0946
DEBUG - 2011-08-01 20:09:47 --> Config Class Initialized
DEBUG - 2011-08-01 20:09:47 --> Hooks Class Initialized
DEBUG - 2011-08-01 20:09:47 --> Utf8 Class Initialized
DEBUG - 2011-08-01 20:09:47 --> UTF-8 Support Enabled
DEBUG - 2011-08-01 20:09:47 --> URI Class Initialized
DEBUG - 2011-08-01 20:09:47 --> Router Class Initialized
DEBUG - 2011-08-01 20:09:47 --> Output Class Initialized
DEBUG - 2011-08-01 20:09:47 --> Input Class Initialized
DEBUG - 2011-08-01 20:09:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-01 20:09:47 --> Language Class Initialized
DEBUG - 2011-08-01 20:09:47 --> Loader Class Initialized
DEBUG - 2011-08-01 20:09:47 --> Controller Class Initialized
DEBUG - 2011-08-01 20:09:47 --> Model Class Initialized
DEBUG - 2011-08-01 20:09:47 --> Model Class Initialized
DEBUG - 2011-08-01 20:09:47 --> Model Class Initialized
DEBUG - 2011-08-01 20:09:47 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-01 20:09:47 --> Database Driver Class Initialized
DEBUG - 2011-08-01 20:09:47 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-01 20:09:47 --> Helper loaded: url_helper
DEBUG - 2011-08-01 20:09:47 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-01 20:09:47 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-01 20:09:47 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-01 20:09:47 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-01 20:09:47 --> Final output sent to browser
DEBUG - 2011-08-01 20:09:47 --> Total execution time: 0.5047
DEBUG - 2011-08-01 20:09:50 --> Config Class Initialized
DEBUG - 2011-08-01 20:09:50 --> Hooks Class Initialized
DEBUG - 2011-08-01 20:09:50 --> Utf8 Class Initialized
DEBUG - 2011-08-01 20:09:50 --> UTF-8 Support Enabled
DEBUG - 2011-08-01 20:09:50 --> URI Class Initialized
DEBUG - 2011-08-01 20:09:50 --> Router Class Initialized
DEBUG - 2011-08-01 20:09:50 --> Output Class Initialized
DEBUG - 2011-08-01 20:09:50 --> Input Class Initialized
DEBUG - 2011-08-01 20:09:50 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-01 20:09:50 --> Language Class Initialized
DEBUG - 2011-08-01 20:09:50 --> Loader Class Initialized
DEBUG - 2011-08-01 20:09:50 --> Controller Class Initialized
DEBUG - 2011-08-01 20:09:50 --> Model Class Initialized
DEBUG - 2011-08-01 20:09:50 --> Model Class Initialized
DEBUG - 2011-08-01 20:09:50 --> Model Class Initialized
DEBUG - 2011-08-01 20:09:50 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-01 20:09:50 --> Database Driver Class Initialized
DEBUG - 2011-08-01 20:09:50 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-01 20:09:50 --> Helper loaded: url_helper
DEBUG - 2011-08-01 20:09:50 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-01 20:09:50 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-01 20:09:50 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-01 20:09:50 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-01 20:09:50 --> Final output sent to browser
DEBUG - 2011-08-01 20:09:50 --> Total execution time: 0.0479
DEBUG - 2011-08-01 20:09:55 --> Config Class Initialized
DEBUG - 2011-08-01 20:09:55 --> Hooks Class Initialized
DEBUG - 2011-08-01 20:09:55 --> Utf8 Class Initialized
DEBUG - 2011-08-01 20:09:55 --> UTF-8 Support Enabled
DEBUG - 2011-08-01 20:09:55 --> URI Class Initialized
DEBUG - 2011-08-01 20:09:55 --> Router Class Initialized
DEBUG - 2011-08-01 20:09:55 --> Output Class Initialized
DEBUG - 2011-08-01 20:09:55 --> Input Class Initialized
DEBUG - 2011-08-01 20:09:55 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-01 20:09:55 --> Language Class Initialized
DEBUG - 2011-08-01 20:09:55 --> Loader Class Initialized
DEBUG - 2011-08-01 20:09:55 --> Controller Class Initialized
DEBUG - 2011-08-01 20:09:55 --> Model Class Initialized
DEBUG - 2011-08-01 20:09:55 --> Model Class Initialized
DEBUG - 2011-08-01 20:09:55 --> Model Class Initialized
DEBUG - 2011-08-01 20:09:55 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-01 20:09:55 --> Database Driver Class Initialized
DEBUG - 2011-08-01 20:09:55 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-01 20:09:55 --> Helper loaded: url_helper
DEBUG - 2011-08-01 20:09:55 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-01 20:09:55 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-01 20:09:55 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-01 20:09:55 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-01 20:09:55 --> Final output sent to browser
DEBUG - 2011-08-01 20:09:55 --> Total execution time: 0.2837
DEBUG - 2011-08-01 20:09:56 --> Config Class Initialized
DEBUG - 2011-08-01 20:09:56 --> Hooks Class Initialized
DEBUG - 2011-08-01 20:09:56 --> Utf8 Class Initialized
DEBUG - 2011-08-01 20:09:56 --> UTF-8 Support Enabled
DEBUG - 2011-08-01 20:09:56 --> URI Class Initialized
DEBUG - 2011-08-01 20:09:56 --> Router Class Initialized
DEBUG - 2011-08-01 20:09:56 --> Output Class Initialized
DEBUG - 2011-08-01 20:09:56 --> Input Class Initialized
DEBUG - 2011-08-01 20:09:56 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-01 20:09:56 --> Language Class Initialized
DEBUG - 2011-08-01 20:09:56 --> Loader Class Initialized
DEBUG - 2011-08-01 20:09:56 --> Controller Class Initialized
DEBUG - 2011-08-01 20:09:56 --> Model Class Initialized
DEBUG - 2011-08-01 20:09:56 --> Model Class Initialized
DEBUG - 2011-08-01 20:09:56 --> Model Class Initialized
DEBUG - 2011-08-01 20:09:56 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-01 20:09:56 --> Database Driver Class Initialized
DEBUG - 2011-08-01 20:09:56 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-01 20:09:56 --> Helper loaded: url_helper
DEBUG - 2011-08-01 20:09:56 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-01 20:09:56 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-01 20:09:56 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-01 20:09:56 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-01 20:09:56 --> Final output sent to browser
DEBUG - 2011-08-01 20:09:56 --> Total execution time: 0.0596
DEBUG - 2011-08-01 20:10:01 --> Config Class Initialized
DEBUG - 2011-08-01 20:10:01 --> Hooks Class Initialized
DEBUG - 2011-08-01 20:10:01 --> Utf8 Class Initialized
DEBUG - 2011-08-01 20:10:01 --> UTF-8 Support Enabled
DEBUG - 2011-08-01 20:10:01 --> URI Class Initialized
DEBUG - 2011-08-01 20:10:01 --> Router Class Initialized
DEBUG - 2011-08-01 20:10:01 --> Output Class Initialized
DEBUG - 2011-08-01 20:10:01 --> Input Class Initialized
DEBUG - 2011-08-01 20:10:01 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-01 20:10:01 --> Language Class Initialized
DEBUG - 2011-08-01 20:10:01 --> Loader Class Initialized
DEBUG - 2011-08-01 20:10:01 --> Controller Class Initialized
DEBUG - 2011-08-01 20:10:01 --> Model Class Initialized
DEBUG - 2011-08-01 20:10:01 --> Model Class Initialized
DEBUG - 2011-08-01 20:10:01 --> Model Class Initialized
DEBUG - 2011-08-01 20:10:01 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-01 20:10:01 --> Database Driver Class Initialized
DEBUG - 2011-08-01 20:10:01 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-01 20:10:01 --> Helper loaded: url_helper
DEBUG - 2011-08-01 20:10:01 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-01 20:10:01 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-01 20:10:01 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-01 20:10:01 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-01 20:10:01 --> Final output sent to browser
DEBUG - 2011-08-01 20:10:01 --> Total execution time: 0.2029
DEBUG - 2011-08-01 20:10:02 --> Config Class Initialized
DEBUG - 2011-08-01 20:10:02 --> Hooks Class Initialized
DEBUG - 2011-08-01 20:10:02 --> Utf8 Class Initialized
DEBUG - 2011-08-01 20:10:02 --> UTF-8 Support Enabled
DEBUG - 2011-08-01 20:10:02 --> URI Class Initialized
DEBUG - 2011-08-01 20:10:02 --> Router Class Initialized
DEBUG - 2011-08-01 20:10:02 --> Output Class Initialized
DEBUG - 2011-08-01 20:10:02 --> Input Class Initialized
DEBUG - 2011-08-01 20:10:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-01 20:10:02 --> Language Class Initialized
DEBUG - 2011-08-01 20:10:02 --> Loader Class Initialized
DEBUG - 2011-08-01 20:10:02 --> Controller Class Initialized
DEBUG - 2011-08-01 20:10:02 --> Model Class Initialized
DEBUG - 2011-08-01 20:10:02 --> Model Class Initialized
DEBUG - 2011-08-01 20:10:02 --> Model Class Initialized
DEBUG - 2011-08-01 20:10:02 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-01 20:10:02 --> Database Driver Class Initialized
DEBUG - 2011-08-01 20:10:02 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-01 20:10:02 --> Helper loaded: url_helper
DEBUG - 2011-08-01 20:10:02 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-01 20:10:02 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-01 20:10:02 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-01 20:10:02 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-01 20:10:02 --> Final output sent to browser
DEBUG - 2011-08-01 20:10:02 --> Total execution time: 0.1395
DEBUG - 2011-08-01 20:10:15 --> Config Class Initialized
DEBUG - 2011-08-01 20:10:15 --> Hooks Class Initialized
DEBUG - 2011-08-01 20:10:15 --> Utf8 Class Initialized
DEBUG - 2011-08-01 20:10:15 --> UTF-8 Support Enabled
DEBUG - 2011-08-01 20:10:15 --> URI Class Initialized
DEBUG - 2011-08-01 20:10:15 --> Router Class Initialized
DEBUG - 2011-08-01 20:10:15 --> Output Class Initialized
DEBUG - 2011-08-01 20:10:15 --> Input Class Initialized
DEBUG - 2011-08-01 20:10:15 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-01 20:10:15 --> Language Class Initialized
DEBUG - 2011-08-01 20:10:15 --> Loader Class Initialized
DEBUG - 2011-08-01 20:10:15 --> Controller Class Initialized
DEBUG - 2011-08-01 20:10:15 --> Model Class Initialized
DEBUG - 2011-08-01 20:10:15 --> Model Class Initialized
DEBUG - 2011-08-01 20:10:15 --> Model Class Initialized
DEBUG - 2011-08-01 20:10:15 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-01 20:10:15 --> Database Driver Class Initialized
DEBUG - 2011-08-01 20:10:16 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-01 20:10:16 --> Helper loaded: url_helper
DEBUG - 2011-08-01 20:10:16 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-01 20:10:16 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-01 20:10:16 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-01 20:10:16 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-01 20:10:16 --> Final output sent to browser
DEBUG - 2011-08-01 20:10:16 --> Total execution time: 0.0471
DEBUG - 2011-08-01 20:10:24 --> Config Class Initialized
DEBUG - 2011-08-01 20:10:24 --> Hooks Class Initialized
DEBUG - 2011-08-01 20:10:24 --> Utf8 Class Initialized
DEBUG - 2011-08-01 20:10:24 --> UTF-8 Support Enabled
DEBUG - 2011-08-01 20:10:24 --> URI Class Initialized
DEBUG - 2011-08-01 20:10:24 --> Router Class Initialized
DEBUG - 2011-08-01 20:10:24 --> Output Class Initialized
DEBUG - 2011-08-01 20:10:24 --> Input Class Initialized
DEBUG - 2011-08-01 20:10:24 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-01 20:10:24 --> Language Class Initialized
DEBUG - 2011-08-01 20:10:24 --> Loader Class Initialized
DEBUG - 2011-08-01 20:10:24 --> Controller Class Initialized
DEBUG - 2011-08-01 20:10:24 --> Model Class Initialized
DEBUG - 2011-08-01 20:10:24 --> Model Class Initialized
DEBUG - 2011-08-01 20:10:24 --> Model Class Initialized
DEBUG - 2011-08-01 20:10:24 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-01 20:10:24 --> Database Driver Class Initialized
DEBUG - 2011-08-01 20:10:24 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-01 20:10:24 --> Helper loaded: url_helper
DEBUG - 2011-08-01 20:10:24 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-01 20:10:24 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-01 20:10:24 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-01 20:10:24 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-01 20:10:24 --> Final output sent to browser
DEBUG - 2011-08-01 20:10:24 --> Total execution time: 0.6852
DEBUG - 2011-08-01 20:10:25 --> Config Class Initialized
DEBUG - 2011-08-01 20:10:25 --> Hooks Class Initialized
DEBUG - 2011-08-01 20:10:25 --> Utf8 Class Initialized
DEBUG - 2011-08-01 20:10:25 --> UTF-8 Support Enabled
DEBUG - 2011-08-01 20:10:25 --> URI Class Initialized
DEBUG - 2011-08-01 20:10:25 --> Router Class Initialized
DEBUG - 2011-08-01 20:10:25 --> Output Class Initialized
DEBUG - 2011-08-01 20:10:25 --> Input Class Initialized
DEBUG - 2011-08-01 20:10:25 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-01 20:10:25 --> Language Class Initialized
DEBUG - 2011-08-01 20:10:25 --> Loader Class Initialized
DEBUG - 2011-08-01 20:10:25 --> Controller Class Initialized
DEBUG - 2011-08-01 20:10:25 --> Model Class Initialized
DEBUG - 2011-08-01 20:10:25 --> Model Class Initialized
DEBUG - 2011-08-01 20:10:25 --> Model Class Initialized
DEBUG - 2011-08-01 20:10:25 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-01 20:10:25 --> Database Driver Class Initialized
DEBUG - 2011-08-01 20:10:25 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-01 20:10:25 --> Helper loaded: url_helper
DEBUG - 2011-08-01 20:10:25 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-01 20:10:25 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-01 20:10:25 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-01 20:10:25 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-01 20:10:25 --> Final output sent to browser
DEBUG - 2011-08-01 20:10:25 --> Total execution time: 0.0533
DEBUG - 2011-08-01 20:10:35 --> Config Class Initialized
DEBUG - 2011-08-01 20:10:35 --> Hooks Class Initialized
DEBUG - 2011-08-01 20:10:35 --> Utf8 Class Initialized
DEBUG - 2011-08-01 20:10:35 --> UTF-8 Support Enabled
DEBUG - 2011-08-01 20:10:35 --> URI Class Initialized
DEBUG - 2011-08-01 20:10:35 --> Router Class Initialized
DEBUG - 2011-08-01 20:10:35 --> Output Class Initialized
DEBUG - 2011-08-01 20:10:35 --> Input Class Initialized
DEBUG - 2011-08-01 20:10:35 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-01 20:10:35 --> Language Class Initialized
DEBUG - 2011-08-01 20:10:35 --> Loader Class Initialized
DEBUG - 2011-08-01 20:10:35 --> Controller Class Initialized
DEBUG - 2011-08-01 20:10:35 --> Model Class Initialized
DEBUG - 2011-08-01 20:10:35 --> Model Class Initialized
DEBUG - 2011-08-01 20:10:35 --> Model Class Initialized
DEBUG - 2011-08-01 20:10:35 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-01 20:10:35 --> Database Driver Class Initialized
DEBUG - 2011-08-01 20:10:35 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-01 20:10:35 --> Helper loaded: url_helper
DEBUG - 2011-08-01 20:10:35 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-01 20:10:35 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-01 20:10:35 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-01 20:10:35 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-01 20:10:35 --> Final output sent to browser
DEBUG - 2011-08-01 20:10:35 --> Total execution time: 0.3201
DEBUG - 2011-08-01 20:10:55 --> Config Class Initialized
DEBUG - 2011-08-01 20:10:55 --> Hooks Class Initialized
DEBUG - 2011-08-01 20:10:55 --> Utf8 Class Initialized
DEBUG - 2011-08-01 20:10:55 --> UTF-8 Support Enabled
DEBUG - 2011-08-01 20:10:55 --> URI Class Initialized
DEBUG - 2011-08-01 20:10:55 --> Router Class Initialized
DEBUG - 2011-08-01 20:10:55 --> Output Class Initialized
DEBUG - 2011-08-01 20:10:55 --> Input Class Initialized
DEBUG - 2011-08-01 20:10:55 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-01 20:10:55 --> Language Class Initialized
DEBUG - 2011-08-01 20:10:55 --> Loader Class Initialized
DEBUG - 2011-08-01 20:10:55 --> Controller Class Initialized
DEBUG - 2011-08-01 20:10:55 --> Model Class Initialized
DEBUG - 2011-08-01 20:10:55 --> Model Class Initialized
DEBUG - 2011-08-01 20:10:55 --> Model Class Initialized
DEBUG - 2011-08-01 20:10:55 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-01 20:10:55 --> Database Driver Class Initialized
DEBUG - 2011-08-01 20:10:55 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-01 20:10:55 --> Helper loaded: url_helper
DEBUG - 2011-08-01 20:10:55 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-01 20:10:55 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-01 20:10:55 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-01 20:10:55 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-01 20:10:55 --> Final output sent to browser
DEBUG - 2011-08-01 20:10:55 --> Total execution time: 0.2827
DEBUG - 2011-08-01 20:11:03 --> Config Class Initialized
DEBUG - 2011-08-01 20:11:03 --> Hooks Class Initialized
DEBUG - 2011-08-01 20:11:03 --> Utf8 Class Initialized
DEBUG - 2011-08-01 20:11:03 --> UTF-8 Support Enabled
DEBUG - 2011-08-01 20:11:03 --> URI Class Initialized
DEBUG - 2011-08-01 20:11:03 --> Router Class Initialized
DEBUG - 2011-08-01 20:11:03 --> Output Class Initialized
DEBUG - 2011-08-01 20:11:03 --> Input Class Initialized
DEBUG - 2011-08-01 20:11:03 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-01 20:11:03 --> Language Class Initialized
DEBUG - 2011-08-01 20:11:03 --> Loader Class Initialized
DEBUG - 2011-08-01 20:11:03 --> Controller Class Initialized
DEBUG - 2011-08-01 20:11:03 --> Model Class Initialized
DEBUG - 2011-08-01 20:11:03 --> Model Class Initialized
DEBUG - 2011-08-01 20:11:03 --> Model Class Initialized
DEBUG - 2011-08-01 20:11:03 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-01 20:11:03 --> Database Driver Class Initialized
DEBUG - 2011-08-01 20:11:04 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-01 20:11:04 --> Helper loaded: url_helper
DEBUG - 2011-08-01 20:11:04 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-01 20:11:04 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-01 20:11:04 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-01 20:11:04 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-01 20:11:04 --> Final output sent to browser
DEBUG - 2011-08-01 20:11:04 --> Total execution time: 0.2687
DEBUG - 2011-08-01 20:11:07 --> Config Class Initialized
DEBUG - 2011-08-01 20:11:07 --> Hooks Class Initialized
DEBUG - 2011-08-01 20:11:07 --> Utf8 Class Initialized
DEBUG - 2011-08-01 20:11:07 --> UTF-8 Support Enabled
DEBUG - 2011-08-01 20:11:07 --> URI Class Initialized
DEBUG - 2011-08-01 20:11:07 --> Router Class Initialized
DEBUG - 2011-08-01 20:11:07 --> Output Class Initialized
DEBUG - 2011-08-01 20:11:07 --> Input Class Initialized
DEBUG - 2011-08-01 20:11:07 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-01 20:11:07 --> Language Class Initialized
DEBUG - 2011-08-01 20:11:07 --> Loader Class Initialized
DEBUG - 2011-08-01 20:11:07 --> Controller Class Initialized
DEBUG - 2011-08-01 20:11:07 --> Model Class Initialized
DEBUG - 2011-08-01 20:11:07 --> Model Class Initialized
DEBUG - 2011-08-01 20:11:07 --> Model Class Initialized
DEBUG - 2011-08-01 20:11:07 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-01 20:11:07 --> Database Driver Class Initialized
DEBUG - 2011-08-01 20:11:07 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-01 20:11:07 --> Helper loaded: url_helper
DEBUG - 2011-08-01 20:11:07 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-01 20:11:07 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-01 20:11:07 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-01 20:11:07 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-01 20:11:07 --> Final output sent to browser
DEBUG - 2011-08-01 20:11:07 --> Total execution time: 0.0748
DEBUG - 2011-08-01 20:11:13 --> Config Class Initialized
DEBUG - 2011-08-01 20:11:13 --> Hooks Class Initialized
DEBUG - 2011-08-01 20:11:13 --> Utf8 Class Initialized
DEBUG - 2011-08-01 20:11:13 --> UTF-8 Support Enabled
DEBUG - 2011-08-01 20:11:13 --> URI Class Initialized
DEBUG - 2011-08-01 20:11:13 --> Router Class Initialized
DEBUG - 2011-08-01 20:11:13 --> Output Class Initialized
DEBUG - 2011-08-01 20:11:13 --> Input Class Initialized
DEBUG - 2011-08-01 20:11:13 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-01 20:11:13 --> Language Class Initialized
DEBUG - 2011-08-01 20:11:13 --> Loader Class Initialized
DEBUG - 2011-08-01 20:11:13 --> Controller Class Initialized
DEBUG - 2011-08-01 20:11:13 --> Model Class Initialized
DEBUG - 2011-08-01 20:11:13 --> Model Class Initialized
DEBUG - 2011-08-01 20:11:13 --> Model Class Initialized
DEBUG - 2011-08-01 20:11:13 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-01 20:11:13 --> Database Driver Class Initialized
DEBUG - 2011-08-01 20:11:13 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-01 20:11:13 --> Helper loaded: url_helper
DEBUG - 2011-08-01 20:11:13 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-01 20:11:13 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-01 20:11:13 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-01 20:11:13 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-01 20:11:13 --> Final output sent to browser
DEBUG - 2011-08-01 20:11:13 --> Total execution time: 0.3151
DEBUG - 2011-08-01 20:11:22 --> Config Class Initialized
DEBUG - 2011-08-01 20:11:22 --> Hooks Class Initialized
DEBUG - 2011-08-01 20:11:22 --> Utf8 Class Initialized
DEBUG - 2011-08-01 20:11:22 --> UTF-8 Support Enabled
DEBUG - 2011-08-01 20:11:22 --> URI Class Initialized
DEBUG - 2011-08-01 20:11:22 --> Router Class Initialized
DEBUG - 2011-08-01 20:11:22 --> Output Class Initialized
DEBUG - 2011-08-01 20:11:22 --> Input Class Initialized
DEBUG - 2011-08-01 20:11:22 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-01 20:11:22 --> Language Class Initialized
DEBUG - 2011-08-01 20:11:22 --> Loader Class Initialized
DEBUG - 2011-08-01 20:11:22 --> Controller Class Initialized
DEBUG - 2011-08-01 20:11:22 --> Model Class Initialized
DEBUG - 2011-08-01 20:11:22 --> Model Class Initialized
DEBUG - 2011-08-01 20:11:22 --> Model Class Initialized
DEBUG - 2011-08-01 20:11:22 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-01 20:11:22 --> Database Driver Class Initialized
DEBUG - 2011-08-01 20:11:22 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-01 20:11:22 --> Helper loaded: url_helper
DEBUG - 2011-08-01 20:11:22 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-01 20:11:22 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-01 20:11:22 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-01 20:11:22 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-01 20:11:22 --> Final output sent to browser
DEBUG - 2011-08-01 20:11:22 --> Total execution time: 0.2151
DEBUG - 2011-08-01 20:11:25 --> Config Class Initialized
DEBUG - 2011-08-01 20:11:25 --> Hooks Class Initialized
DEBUG - 2011-08-01 20:11:25 --> Utf8 Class Initialized
DEBUG - 2011-08-01 20:11:25 --> UTF-8 Support Enabled
DEBUG - 2011-08-01 20:11:25 --> URI Class Initialized
DEBUG - 2011-08-01 20:11:25 --> Router Class Initialized
DEBUG - 2011-08-01 20:11:25 --> Output Class Initialized
DEBUG - 2011-08-01 20:11:25 --> Input Class Initialized
DEBUG - 2011-08-01 20:11:25 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-01 20:11:25 --> Language Class Initialized
DEBUG - 2011-08-01 20:11:25 --> Loader Class Initialized
DEBUG - 2011-08-01 20:11:25 --> Controller Class Initialized
DEBUG - 2011-08-01 20:11:25 --> Model Class Initialized
DEBUG - 2011-08-01 20:11:25 --> Model Class Initialized
DEBUG - 2011-08-01 20:11:25 --> Model Class Initialized
DEBUG - 2011-08-01 20:11:25 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-01 20:11:25 --> Database Driver Class Initialized
DEBUG - 2011-08-01 20:11:25 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-01 20:11:25 --> Helper loaded: url_helper
DEBUG - 2011-08-01 20:11:25 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-01 20:11:25 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-01 20:11:25 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-01 20:11:25 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-01 20:11:25 --> Final output sent to browser
DEBUG - 2011-08-01 20:11:25 --> Total execution time: 0.0434
DEBUG - 2011-08-01 20:11:25 --> Config Class Initialized
DEBUG - 2011-08-01 20:11:25 --> Hooks Class Initialized
DEBUG - 2011-08-01 20:11:25 --> Utf8 Class Initialized
DEBUG - 2011-08-01 20:11:25 --> UTF-8 Support Enabled
DEBUG - 2011-08-01 20:11:25 --> URI Class Initialized
DEBUG - 2011-08-01 20:11:25 --> Router Class Initialized
DEBUG - 2011-08-01 20:11:25 --> Output Class Initialized
DEBUG - 2011-08-01 20:11:25 --> Input Class Initialized
DEBUG - 2011-08-01 20:11:25 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-01 20:11:25 --> Language Class Initialized
DEBUG - 2011-08-01 20:11:25 --> Loader Class Initialized
DEBUG - 2011-08-01 20:11:25 --> Controller Class Initialized
DEBUG - 2011-08-01 20:11:25 --> Model Class Initialized
DEBUG - 2011-08-01 20:11:25 --> Model Class Initialized
DEBUG - 2011-08-01 20:11:25 --> Model Class Initialized
DEBUG - 2011-08-01 20:11:25 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-01 20:11:25 --> Database Driver Class Initialized
DEBUG - 2011-08-01 20:11:25 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-01 20:11:25 --> Helper loaded: url_helper
DEBUG - 2011-08-01 20:11:25 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-01 20:11:25 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-01 20:11:25 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-01 20:11:25 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-01 20:11:25 --> Final output sent to browser
DEBUG - 2011-08-01 20:11:25 --> Total execution time: 0.0463
DEBUG - 2011-08-01 20:11:26 --> Config Class Initialized
DEBUG - 2011-08-01 20:11:26 --> Hooks Class Initialized
DEBUG - 2011-08-01 20:11:26 --> Utf8 Class Initialized
DEBUG - 2011-08-01 20:11:26 --> UTF-8 Support Enabled
DEBUG - 2011-08-01 20:11:26 --> URI Class Initialized
DEBUG - 2011-08-01 20:11:26 --> Router Class Initialized
DEBUG - 2011-08-01 20:11:26 --> Output Class Initialized
DEBUG - 2011-08-01 20:11:26 --> Input Class Initialized
DEBUG - 2011-08-01 20:11:26 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-01 20:11:26 --> Language Class Initialized
DEBUG - 2011-08-01 20:11:26 --> Loader Class Initialized
DEBUG - 2011-08-01 20:11:26 --> Controller Class Initialized
DEBUG - 2011-08-01 20:11:26 --> Model Class Initialized
DEBUG - 2011-08-01 20:11:26 --> Model Class Initialized
DEBUG - 2011-08-01 20:11:26 --> Model Class Initialized
DEBUG - 2011-08-01 20:11:26 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-01 20:11:26 --> Database Driver Class Initialized
DEBUG - 2011-08-01 20:11:26 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-01 20:11:26 --> Helper loaded: url_helper
DEBUG - 2011-08-01 20:11:26 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-01 20:11:26 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-01 20:11:26 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-01 20:11:26 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-01 20:11:26 --> Final output sent to browser
DEBUG - 2011-08-01 20:11:26 --> Total execution time: 0.0428
DEBUG - 2011-08-01 20:11:27 --> Config Class Initialized
DEBUG - 2011-08-01 20:11:27 --> Hooks Class Initialized
DEBUG - 2011-08-01 20:11:27 --> Utf8 Class Initialized
DEBUG - 2011-08-01 20:11:27 --> UTF-8 Support Enabled
DEBUG - 2011-08-01 20:11:27 --> URI Class Initialized
DEBUG - 2011-08-01 20:11:27 --> Router Class Initialized
DEBUG - 2011-08-01 20:11:27 --> Output Class Initialized
DEBUG - 2011-08-01 20:11:27 --> Input Class Initialized
DEBUG - 2011-08-01 20:11:27 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-01 20:11:27 --> Language Class Initialized
DEBUG - 2011-08-01 20:11:27 --> Loader Class Initialized
DEBUG - 2011-08-01 20:11:27 --> Controller Class Initialized
DEBUG - 2011-08-01 20:11:27 --> Model Class Initialized
DEBUG - 2011-08-01 20:11:27 --> Model Class Initialized
DEBUG - 2011-08-01 20:11:27 --> Model Class Initialized
DEBUG - 2011-08-01 20:11:27 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-01 20:11:27 --> Database Driver Class Initialized
DEBUG - 2011-08-01 20:11:27 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-01 20:11:27 --> Helper loaded: url_helper
DEBUG - 2011-08-01 20:11:27 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-01 20:11:27 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-01 20:11:27 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-01 20:11:27 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-01 20:11:27 --> Final output sent to browser
DEBUG - 2011-08-01 20:11:27 --> Total execution time: 0.0452
DEBUG - 2011-08-01 20:11:30 --> Config Class Initialized
DEBUG - 2011-08-01 20:11:30 --> Hooks Class Initialized
DEBUG - 2011-08-01 20:11:30 --> Utf8 Class Initialized
DEBUG - 2011-08-01 20:11:30 --> UTF-8 Support Enabled
DEBUG - 2011-08-01 20:11:30 --> URI Class Initialized
DEBUG - 2011-08-01 20:11:30 --> Router Class Initialized
DEBUG - 2011-08-01 20:11:30 --> Output Class Initialized
DEBUG - 2011-08-01 20:11:30 --> Input Class Initialized
DEBUG - 2011-08-01 20:11:30 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-01 20:11:30 --> Language Class Initialized
DEBUG - 2011-08-01 20:11:30 --> Loader Class Initialized
DEBUG - 2011-08-01 20:11:30 --> Controller Class Initialized
DEBUG - 2011-08-01 20:11:30 --> Model Class Initialized
DEBUG - 2011-08-01 20:11:30 --> Model Class Initialized
DEBUG - 2011-08-01 20:11:30 --> Model Class Initialized
DEBUG - 2011-08-01 20:11:30 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-01 20:11:30 --> Database Driver Class Initialized
DEBUG - 2011-08-01 20:11:30 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-01 20:11:30 --> Helper loaded: url_helper
DEBUG - 2011-08-01 20:11:30 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-01 20:11:30 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-01 20:11:30 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-01 20:11:30 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-01 20:11:30 --> Final output sent to browser
DEBUG - 2011-08-01 20:11:30 --> Total execution time: 0.2576
DEBUG - 2011-08-01 20:11:36 --> Config Class Initialized
DEBUG - 2011-08-01 20:11:36 --> Hooks Class Initialized
DEBUG - 2011-08-01 20:11:36 --> Utf8 Class Initialized
DEBUG - 2011-08-01 20:11:36 --> UTF-8 Support Enabled
DEBUG - 2011-08-01 20:11:36 --> URI Class Initialized
DEBUG - 2011-08-01 20:11:36 --> Router Class Initialized
DEBUG - 2011-08-01 20:11:36 --> Output Class Initialized
DEBUG - 2011-08-01 20:11:36 --> Input Class Initialized
DEBUG - 2011-08-01 20:11:36 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-01 20:11:36 --> Language Class Initialized
DEBUG - 2011-08-01 20:11:36 --> Loader Class Initialized
DEBUG - 2011-08-01 20:11:36 --> Controller Class Initialized
DEBUG - 2011-08-01 20:11:36 --> Model Class Initialized
DEBUG - 2011-08-01 20:11:36 --> Model Class Initialized
DEBUG - 2011-08-01 20:11:36 --> Model Class Initialized
DEBUG - 2011-08-01 20:11:36 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-01 20:11:36 --> Database Driver Class Initialized
DEBUG - 2011-08-01 20:11:36 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-01 20:11:36 --> Helper loaded: url_helper
DEBUG - 2011-08-01 20:11:36 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-01 20:11:36 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-01 20:11:36 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-01 20:11:36 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-01 20:11:36 --> Final output sent to browser
DEBUG - 2011-08-01 20:11:36 --> Total execution time: 0.3655
DEBUG - 2011-08-01 20:12:03 --> Config Class Initialized
DEBUG - 2011-08-01 20:12:03 --> Hooks Class Initialized
DEBUG - 2011-08-01 20:12:03 --> Utf8 Class Initialized
DEBUG - 2011-08-01 20:12:03 --> UTF-8 Support Enabled
DEBUG - 2011-08-01 20:12:03 --> URI Class Initialized
DEBUG - 2011-08-01 20:12:03 --> Router Class Initialized
DEBUG - 2011-08-01 20:12:03 --> Output Class Initialized
DEBUG - 2011-08-01 20:12:03 --> Input Class Initialized
DEBUG - 2011-08-01 20:12:03 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-01 20:12:03 --> Language Class Initialized
DEBUG - 2011-08-01 20:12:03 --> Loader Class Initialized
DEBUG - 2011-08-01 20:12:03 --> Controller Class Initialized
DEBUG - 2011-08-01 20:12:03 --> Model Class Initialized
DEBUG - 2011-08-01 20:12:03 --> Model Class Initialized
DEBUG - 2011-08-01 20:12:03 --> Model Class Initialized
DEBUG - 2011-08-01 20:12:03 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-01 20:12:03 --> Database Driver Class Initialized
DEBUG - 2011-08-01 20:12:03 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-01 20:12:03 --> Helper loaded: url_helper
DEBUG - 2011-08-01 20:12:03 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-01 20:12:03 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-01 20:12:03 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-01 20:12:03 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-01 20:12:03 --> Final output sent to browser
DEBUG - 2011-08-01 20:12:03 --> Total execution time: 0.1435
DEBUG - 2011-08-01 20:12:08 --> Config Class Initialized
DEBUG - 2011-08-01 20:12:08 --> Hooks Class Initialized
DEBUG - 2011-08-01 20:12:08 --> Utf8 Class Initialized
DEBUG - 2011-08-01 20:12:08 --> UTF-8 Support Enabled
DEBUG - 2011-08-01 20:12:08 --> URI Class Initialized
DEBUG - 2011-08-01 20:12:08 --> Router Class Initialized
DEBUG - 2011-08-01 20:12:08 --> Output Class Initialized
DEBUG - 2011-08-01 20:12:08 --> Input Class Initialized
DEBUG - 2011-08-01 20:12:08 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-01 20:12:08 --> Language Class Initialized
DEBUG - 2011-08-01 20:12:08 --> Loader Class Initialized
DEBUG - 2011-08-01 20:12:08 --> Controller Class Initialized
DEBUG - 2011-08-01 20:12:08 --> Model Class Initialized
DEBUG - 2011-08-01 20:12:08 --> Model Class Initialized
DEBUG - 2011-08-01 20:12:08 --> Model Class Initialized
DEBUG - 2011-08-01 20:12:08 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-01 20:12:08 --> Database Driver Class Initialized
DEBUG - 2011-08-01 20:12:09 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-01 20:12:09 --> Helper loaded: url_helper
DEBUG - 2011-08-01 20:12:09 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-01 20:12:09 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-01 20:12:09 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-01 20:12:09 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-01 20:12:09 --> Final output sent to browser
DEBUG - 2011-08-01 20:12:09 --> Total execution time: 0.9884
DEBUG - 2011-08-01 20:12:21 --> Config Class Initialized
DEBUG - 2011-08-01 20:12:21 --> Hooks Class Initialized
DEBUG - 2011-08-01 20:12:21 --> Utf8 Class Initialized
DEBUG - 2011-08-01 20:12:21 --> UTF-8 Support Enabled
DEBUG - 2011-08-01 20:12:21 --> URI Class Initialized
DEBUG - 2011-08-01 20:12:21 --> Router Class Initialized
DEBUG - 2011-08-01 20:12:21 --> Output Class Initialized
DEBUG - 2011-08-01 20:12:21 --> Input Class Initialized
DEBUG - 2011-08-01 20:12:21 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-01 20:12:21 --> Language Class Initialized
DEBUG - 2011-08-01 20:12:21 --> Loader Class Initialized
DEBUG - 2011-08-01 20:12:21 --> Controller Class Initialized
DEBUG - 2011-08-01 20:12:21 --> Model Class Initialized
DEBUG - 2011-08-01 20:12:21 --> Model Class Initialized
DEBUG - 2011-08-01 20:12:21 --> Model Class Initialized
DEBUG - 2011-08-01 20:12:21 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-01 20:12:21 --> Database Driver Class Initialized
DEBUG - 2011-08-01 20:12:22 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-01 20:12:22 --> Helper loaded: url_helper
DEBUG - 2011-08-01 20:12:22 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-01 20:12:22 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-01 20:12:22 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-01 20:12:22 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-01 20:12:22 --> Final output sent to browser
DEBUG - 2011-08-01 20:12:22 --> Total execution time: 0.2292
DEBUG - 2011-08-01 20:12:30 --> Config Class Initialized
DEBUG - 2011-08-01 20:12:30 --> Hooks Class Initialized
DEBUG - 2011-08-01 20:12:30 --> Utf8 Class Initialized
DEBUG - 2011-08-01 20:12:30 --> UTF-8 Support Enabled
DEBUG - 2011-08-01 20:12:30 --> URI Class Initialized
DEBUG - 2011-08-01 20:12:30 --> Router Class Initialized
DEBUG - 2011-08-01 20:12:30 --> Output Class Initialized
DEBUG - 2011-08-01 20:12:30 --> Input Class Initialized
DEBUG - 2011-08-01 20:12:30 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-01 20:12:30 --> Language Class Initialized
DEBUG - 2011-08-01 20:12:30 --> Loader Class Initialized
DEBUG - 2011-08-01 20:12:30 --> Controller Class Initialized
DEBUG - 2011-08-01 20:12:30 --> Model Class Initialized
DEBUG - 2011-08-01 20:12:30 --> Model Class Initialized
DEBUG - 2011-08-01 20:12:30 --> Model Class Initialized
DEBUG - 2011-08-01 20:12:30 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-01 20:12:30 --> Database Driver Class Initialized
DEBUG - 2011-08-01 20:12:30 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-01 20:12:30 --> Helper loaded: url_helper
DEBUG - 2011-08-01 20:12:30 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-01 20:12:30 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-01 20:12:30 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-01 20:12:30 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-01 20:12:30 --> Final output sent to browser
DEBUG - 2011-08-01 20:12:30 --> Total execution time: 0.0417
DEBUG - 2011-08-01 20:12:32 --> Config Class Initialized
DEBUG - 2011-08-01 20:12:32 --> Hooks Class Initialized
DEBUG - 2011-08-01 20:12:32 --> Utf8 Class Initialized
DEBUG - 2011-08-01 20:12:32 --> UTF-8 Support Enabled
DEBUG - 2011-08-01 20:12:32 --> URI Class Initialized
DEBUG - 2011-08-01 20:12:32 --> Router Class Initialized
DEBUG - 2011-08-01 20:12:32 --> Output Class Initialized
DEBUG - 2011-08-01 20:12:32 --> Input Class Initialized
DEBUG - 2011-08-01 20:12:32 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-01 20:12:32 --> Language Class Initialized
DEBUG - 2011-08-01 20:12:32 --> Loader Class Initialized
DEBUG - 2011-08-01 20:12:32 --> Controller Class Initialized
DEBUG - 2011-08-01 20:12:32 --> Model Class Initialized
DEBUG - 2011-08-01 20:12:32 --> Model Class Initialized
DEBUG - 2011-08-01 20:12:32 --> Model Class Initialized
DEBUG - 2011-08-01 20:12:32 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-01 20:12:32 --> Database Driver Class Initialized
DEBUG - 2011-08-01 20:12:32 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-01 20:12:32 --> Helper loaded: url_helper
DEBUG - 2011-08-01 20:12:32 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-01 20:12:32 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-01 20:12:32 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-01 20:12:32 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-01 20:12:32 --> Final output sent to browser
DEBUG - 2011-08-01 20:12:32 --> Total execution time: 0.2214
DEBUG - 2011-08-01 20:12:40 --> Config Class Initialized
DEBUG - 2011-08-01 20:12:40 --> Hooks Class Initialized
DEBUG - 2011-08-01 20:12:40 --> Utf8 Class Initialized
DEBUG - 2011-08-01 20:12:40 --> UTF-8 Support Enabled
DEBUG - 2011-08-01 20:12:40 --> URI Class Initialized
DEBUG - 2011-08-01 20:12:40 --> Router Class Initialized
DEBUG - 2011-08-01 20:12:40 --> Output Class Initialized
DEBUG - 2011-08-01 20:12:40 --> Input Class Initialized
DEBUG - 2011-08-01 20:12:40 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-01 20:12:40 --> Language Class Initialized
DEBUG - 2011-08-01 20:12:40 --> Loader Class Initialized
DEBUG - 2011-08-01 20:12:40 --> Controller Class Initialized
DEBUG - 2011-08-01 20:12:40 --> Model Class Initialized
DEBUG - 2011-08-01 20:12:40 --> Model Class Initialized
DEBUG - 2011-08-01 20:12:40 --> Model Class Initialized
DEBUG - 2011-08-01 20:12:40 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-01 20:12:40 --> Database Driver Class Initialized
DEBUG - 2011-08-01 20:12:41 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-01 20:12:41 --> Helper loaded: url_helper
DEBUG - 2011-08-01 20:12:41 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-01 20:12:41 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-01 20:12:41 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-01 20:12:41 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-01 20:12:41 --> Final output sent to browser
DEBUG - 2011-08-01 20:12:41 --> Total execution time: 0.3688
DEBUG - 2011-08-01 20:12:42 --> Config Class Initialized
DEBUG - 2011-08-01 20:12:42 --> Hooks Class Initialized
DEBUG - 2011-08-01 20:12:42 --> Utf8 Class Initialized
DEBUG - 2011-08-01 20:12:42 --> UTF-8 Support Enabled
DEBUG - 2011-08-01 20:12:42 --> URI Class Initialized
DEBUG - 2011-08-01 20:12:42 --> Router Class Initialized
DEBUG - 2011-08-01 20:12:42 --> Output Class Initialized
DEBUG - 2011-08-01 20:12:42 --> Input Class Initialized
DEBUG - 2011-08-01 20:12:42 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-01 20:12:42 --> Language Class Initialized
DEBUG - 2011-08-01 20:12:42 --> Loader Class Initialized
DEBUG - 2011-08-01 20:12:42 --> Controller Class Initialized
DEBUG - 2011-08-01 20:12:42 --> Model Class Initialized
DEBUG - 2011-08-01 20:12:42 --> Model Class Initialized
DEBUG - 2011-08-01 20:12:42 --> Model Class Initialized
DEBUG - 2011-08-01 20:12:42 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-01 20:12:42 --> Database Driver Class Initialized
DEBUG - 2011-08-01 20:12:42 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-01 20:12:42 --> Helper loaded: url_helper
DEBUG - 2011-08-01 20:12:42 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-01 20:12:42 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-01 20:12:42 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-01 20:12:42 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-01 20:12:42 --> Final output sent to browser
DEBUG - 2011-08-01 20:12:42 --> Total execution time: 0.0550
DEBUG - 2011-08-01 20:12:48 --> Config Class Initialized
DEBUG - 2011-08-01 20:12:48 --> Hooks Class Initialized
DEBUG - 2011-08-01 20:12:48 --> Utf8 Class Initialized
DEBUG - 2011-08-01 20:12:48 --> UTF-8 Support Enabled
DEBUG - 2011-08-01 20:12:48 --> URI Class Initialized
DEBUG - 2011-08-01 20:12:48 --> Router Class Initialized
DEBUG - 2011-08-01 20:12:48 --> Output Class Initialized
DEBUG - 2011-08-01 20:12:48 --> Input Class Initialized
DEBUG - 2011-08-01 20:12:48 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-01 20:12:48 --> Language Class Initialized
DEBUG - 2011-08-01 20:12:48 --> Loader Class Initialized
DEBUG - 2011-08-01 20:12:48 --> Controller Class Initialized
DEBUG - 2011-08-01 20:12:48 --> Model Class Initialized
DEBUG - 2011-08-01 20:12:48 --> Model Class Initialized
DEBUG - 2011-08-01 20:12:48 --> Model Class Initialized
DEBUG - 2011-08-01 20:12:48 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-01 20:12:48 --> Database Driver Class Initialized
DEBUG - 2011-08-01 20:12:48 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-01 20:12:48 --> Helper loaded: url_helper
DEBUG - 2011-08-01 20:12:48 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-01 20:12:48 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-01 20:12:48 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-01 20:12:48 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-01 20:12:48 --> Final output sent to browser
DEBUG - 2011-08-01 20:12:48 --> Total execution time: 0.4801
DEBUG - 2011-08-01 20:12:48 --> Config Class Initialized
DEBUG - 2011-08-01 20:12:48 --> Hooks Class Initialized
DEBUG - 2011-08-01 20:12:48 --> Utf8 Class Initialized
DEBUG - 2011-08-01 20:12:48 --> UTF-8 Support Enabled
DEBUG - 2011-08-01 20:12:48 --> URI Class Initialized
DEBUG - 2011-08-01 20:12:48 --> Router Class Initialized
DEBUG - 2011-08-01 20:12:48 --> Output Class Initialized
DEBUG - 2011-08-01 20:12:48 --> Input Class Initialized
DEBUG - 2011-08-01 20:12:48 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-01 20:12:48 --> Language Class Initialized
DEBUG - 2011-08-01 20:12:48 --> Loader Class Initialized
DEBUG - 2011-08-01 20:12:48 --> Controller Class Initialized
DEBUG - 2011-08-01 20:12:48 --> Model Class Initialized
DEBUG - 2011-08-01 20:12:48 --> Model Class Initialized
DEBUG - 2011-08-01 20:12:48 --> Model Class Initialized
DEBUG - 2011-08-01 20:12:48 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-01 20:12:48 --> Database Driver Class Initialized
DEBUG - 2011-08-01 20:12:48 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-01 20:12:48 --> Helper loaded: url_helper
DEBUG - 2011-08-01 20:12:48 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-01 20:12:48 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-01 20:12:48 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-01 20:12:48 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-01 20:12:48 --> Final output sent to browser
DEBUG - 2011-08-01 20:12:48 --> Total execution time: 0.1117
DEBUG - 2011-08-01 20:12:54 --> Config Class Initialized
DEBUG - 2011-08-01 20:12:54 --> Hooks Class Initialized
DEBUG - 2011-08-01 20:12:54 --> Utf8 Class Initialized
DEBUG - 2011-08-01 20:12:54 --> UTF-8 Support Enabled
DEBUG - 2011-08-01 20:12:54 --> URI Class Initialized
DEBUG - 2011-08-01 20:12:54 --> Router Class Initialized
DEBUG - 2011-08-01 20:12:54 --> Output Class Initialized
DEBUG - 2011-08-01 20:12:54 --> Input Class Initialized
DEBUG - 2011-08-01 20:12:54 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-01 20:12:54 --> Language Class Initialized
DEBUG - 2011-08-01 20:12:54 --> Loader Class Initialized
DEBUG - 2011-08-01 20:12:54 --> Controller Class Initialized
DEBUG - 2011-08-01 20:12:54 --> Model Class Initialized
DEBUG - 2011-08-01 20:12:54 --> Model Class Initialized
DEBUG - 2011-08-01 20:12:54 --> Model Class Initialized
DEBUG - 2011-08-01 20:12:54 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-01 20:12:54 --> Database Driver Class Initialized
DEBUG - 2011-08-01 20:12:54 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-01 20:12:54 --> Helper loaded: url_helper
DEBUG - 2011-08-01 20:12:54 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-01 20:12:54 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-01 20:12:54 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-01 20:12:54 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-01 20:12:54 --> Final output sent to browser
DEBUG - 2011-08-01 20:12:54 --> Total execution time: 0.0895
DEBUG - 2011-08-01 20:12:58 --> Config Class Initialized
DEBUG - 2011-08-01 20:12:58 --> Hooks Class Initialized
DEBUG - 2011-08-01 20:12:58 --> Utf8 Class Initialized
DEBUG - 2011-08-01 20:12:58 --> UTF-8 Support Enabled
DEBUG - 2011-08-01 20:12:58 --> URI Class Initialized
DEBUG - 2011-08-01 20:12:58 --> Router Class Initialized
DEBUG - 2011-08-01 20:12:58 --> Output Class Initialized
DEBUG - 2011-08-01 20:12:58 --> Input Class Initialized
DEBUG - 2011-08-01 20:12:58 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-01 20:12:58 --> Language Class Initialized
DEBUG - 2011-08-01 20:12:58 --> Loader Class Initialized
DEBUG - 2011-08-01 20:12:58 --> Controller Class Initialized
DEBUG - 2011-08-01 20:12:58 --> Model Class Initialized
DEBUG - 2011-08-01 20:12:58 --> Model Class Initialized
DEBUG - 2011-08-01 20:12:58 --> Model Class Initialized
DEBUG - 2011-08-01 20:12:58 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-01 20:12:58 --> Database Driver Class Initialized
DEBUG - 2011-08-01 20:12:58 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-01 20:12:58 --> Helper loaded: url_helper
DEBUG - 2011-08-01 20:12:58 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-01 20:12:58 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-01 20:12:58 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-01 20:12:58 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-01 20:12:58 --> Final output sent to browser
DEBUG - 2011-08-01 20:12:58 --> Total execution time: 0.2448
DEBUG - 2011-08-01 21:34:31 --> Config Class Initialized
DEBUG - 2011-08-01 21:34:31 --> Hooks Class Initialized
DEBUG - 2011-08-01 21:34:31 --> Utf8 Class Initialized
DEBUG - 2011-08-01 21:34:31 --> UTF-8 Support Enabled
DEBUG - 2011-08-01 21:34:31 --> URI Class Initialized
DEBUG - 2011-08-01 21:34:31 --> Router Class Initialized
DEBUG - 2011-08-01 21:34:31 --> Output Class Initialized
DEBUG - 2011-08-01 21:34:31 --> Input Class Initialized
DEBUG - 2011-08-01 21:34:31 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-01 21:34:31 --> Language Class Initialized
DEBUG - 2011-08-01 21:34:31 --> Loader Class Initialized
DEBUG - 2011-08-01 21:34:31 --> Controller Class Initialized
DEBUG - 2011-08-01 21:34:31 --> Model Class Initialized
DEBUG - 2011-08-01 21:34:31 --> Model Class Initialized
DEBUG - 2011-08-01 21:34:31 --> Model Class Initialized
DEBUG - 2011-08-01 21:34:31 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-01 21:34:31 --> Database Driver Class Initialized
DEBUG - 2011-08-01 21:34:31 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-01 21:34:31 --> Helper loaded: url_helper
DEBUG - 2011-08-01 21:34:31 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-01 21:34:31 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-01 21:34:31 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-01 21:34:31 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-01 21:34:31 --> Final output sent to browser
DEBUG - 2011-08-01 21:34:31 --> Total execution time: 0.3253
DEBUG - 2011-08-01 21:34:34 --> Config Class Initialized
DEBUG - 2011-08-01 21:34:34 --> Hooks Class Initialized
DEBUG - 2011-08-01 21:34:34 --> Utf8 Class Initialized
DEBUG - 2011-08-01 21:34:34 --> UTF-8 Support Enabled
DEBUG - 2011-08-01 21:34:34 --> URI Class Initialized
DEBUG - 2011-08-01 21:34:34 --> Router Class Initialized
ERROR - 2011-08-01 21:34:34 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-01 23:18:03 --> Config Class Initialized
DEBUG - 2011-08-01 23:18:03 --> Hooks Class Initialized
DEBUG - 2011-08-01 23:18:03 --> Utf8 Class Initialized
DEBUG - 2011-08-01 23:18:03 --> UTF-8 Support Enabled
DEBUG - 2011-08-01 23:18:03 --> URI Class Initialized
DEBUG - 2011-08-01 23:18:03 --> Router Class Initialized
ERROR - 2011-08-01 23:18:03 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-08-01 23:18:03 --> Config Class Initialized
DEBUG - 2011-08-01 23:18:03 --> Hooks Class Initialized
DEBUG - 2011-08-01 23:18:03 --> Utf8 Class Initialized
DEBUG - 2011-08-01 23:18:03 --> UTF-8 Support Enabled
DEBUG - 2011-08-01 23:18:03 --> URI Class Initialized
DEBUG - 2011-08-01 23:18:03 --> Router Class Initialized
DEBUG - 2011-08-01 23:18:03 --> Output Class Initialized
DEBUG - 2011-08-01 23:18:03 --> Input Class Initialized
DEBUG - 2011-08-01 23:18:03 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-01 23:18:03 --> Language Class Initialized
DEBUG - 2011-08-01 23:18:03 --> Loader Class Initialized
DEBUG - 2011-08-01 23:18:03 --> Controller Class Initialized
ERROR - 2011-08-01 23:18:03 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-01 23:18:03 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-01 23:18:03 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-01 23:18:03 --> Model Class Initialized
DEBUG - 2011-08-01 23:18:03 --> Model Class Initialized
DEBUG - 2011-08-01 23:18:03 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-01 23:18:03 --> Database Driver Class Initialized
DEBUG - 2011-08-01 23:18:03 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-01 23:18:03 --> Helper loaded: url_helper
DEBUG - 2011-08-01 23:18:03 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-01 23:18:03 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-01 23:18:03 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-01 23:18:03 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-01 23:18:03 --> Final output sent to browser
DEBUG - 2011-08-01 23:18:03 --> Total execution time: 0.0881

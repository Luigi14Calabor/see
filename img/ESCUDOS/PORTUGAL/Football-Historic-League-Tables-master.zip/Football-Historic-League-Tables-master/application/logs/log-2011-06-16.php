<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2011-06-16 02:15:32 --> Config Class Initialized
DEBUG - 2011-06-16 02:15:32 --> Hooks Class Initialized
DEBUG - 2011-06-16 02:15:32 --> Utf8 Class Initialized
DEBUG - 2011-06-16 02:15:32 --> UTF-8 Support Enabled
DEBUG - 2011-06-16 02:15:32 --> URI Class Initialized
DEBUG - 2011-06-16 02:15:32 --> Router Class Initialized
DEBUG - 2011-06-16 02:15:32 --> Output Class Initialized
DEBUG - 2011-06-16 02:15:32 --> Input Class Initialized
DEBUG - 2011-06-16 02:15:32 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-16 02:15:32 --> Language Class Initialized
DEBUG - 2011-06-16 02:15:32 --> Loader Class Initialized
DEBUG - 2011-06-16 02:15:33 --> Controller Class Initialized
DEBUG - 2011-06-16 02:15:33 --> Model Class Initialized
DEBUG - 2011-06-16 02:15:33 --> Model Class Initialized
DEBUG - 2011-06-16 02:15:33 --> Model Class Initialized
DEBUG - 2011-06-16 02:15:33 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-16 02:15:33 --> Database Driver Class Initialized
DEBUG - 2011-06-16 02:15:46 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-16 02:15:46 --> Helper loaded: url_helper
DEBUG - 2011-06-16 02:15:46 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-16 02:15:46 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-16 02:15:46 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-16 02:15:46 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-16 02:15:46 --> Final output sent to browser
DEBUG - 2011-06-16 02:15:46 --> Total execution time: 14.0760
DEBUG - 2011-06-16 02:15:50 --> Config Class Initialized
DEBUG - 2011-06-16 02:15:50 --> Hooks Class Initialized
DEBUG - 2011-06-16 02:15:50 --> Utf8 Class Initialized
DEBUG - 2011-06-16 02:15:50 --> UTF-8 Support Enabled
DEBUG - 2011-06-16 02:15:50 --> URI Class Initialized
DEBUG - 2011-06-16 02:15:50 --> Router Class Initialized
DEBUG - 2011-06-16 02:15:50 --> Output Class Initialized
DEBUG - 2011-06-16 02:15:50 --> Input Class Initialized
DEBUG - 2011-06-16 02:15:50 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-16 02:15:50 --> Language Class Initialized
DEBUG - 2011-06-16 02:15:50 --> Loader Class Initialized
DEBUG - 2011-06-16 02:15:50 --> Controller Class Initialized
ERROR - 2011-06-16 02:15:50 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-16 02:15:50 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-16 02:15:50 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-16 02:15:50 --> Model Class Initialized
DEBUG - 2011-06-16 02:15:50 --> Model Class Initialized
DEBUG - 2011-06-16 02:15:50 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-16 02:15:50 --> Database Driver Class Initialized
DEBUG - 2011-06-16 02:15:50 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-16 02:15:50 --> Helper loaded: url_helper
DEBUG - 2011-06-16 02:15:50 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-16 02:15:50 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-16 02:15:50 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-16 02:15:50 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-16 02:15:50 --> Final output sent to browser
DEBUG - 2011-06-16 02:15:50 --> Total execution time: 0.1049
DEBUG - 2011-06-16 04:52:57 --> Config Class Initialized
DEBUG - 2011-06-16 04:52:57 --> Hooks Class Initialized
DEBUG - 2011-06-16 04:52:57 --> Utf8 Class Initialized
DEBUG - 2011-06-16 04:52:57 --> UTF-8 Support Enabled
DEBUG - 2011-06-16 04:52:57 --> URI Class Initialized
DEBUG - 2011-06-16 04:52:57 --> Router Class Initialized
DEBUG - 2011-06-16 04:52:57 --> Output Class Initialized
DEBUG - 2011-06-16 04:52:57 --> Input Class Initialized
DEBUG - 2011-06-16 04:52:57 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-16 04:52:57 --> Language Class Initialized
DEBUG - 2011-06-16 04:52:57 --> Loader Class Initialized
DEBUG - 2011-06-16 04:52:57 --> Controller Class Initialized
DEBUG - 2011-06-16 04:52:57 --> Model Class Initialized
DEBUG - 2011-06-16 04:52:57 --> Model Class Initialized
DEBUG - 2011-06-16 04:52:57 --> Model Class Initialized
DEBUG - 2011-06-16 04:52:57 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-16 04:52:57 --> Database Driver Class Initialized
DEBUG - 2011-06-16 04:52:58 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-16 04:52:58 --> Helper loaded: url_helper
DEBUG - 2011-06-16 04:52:58 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-16 04:52:58 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-16 04:52:58 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-16 04:52:58 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-16 04:52:58 --> Final output sent to browser
DEBUG - 2011-06-16 04:52:58 --> Total execution time: 1.9569
DEBUG - 2011-06-16 04:52:59 --> Config Class Initialized
DEBUG - 2011-06-16 04:52:59 --> Hooks Class Initialized
DEBUG - 2011-06-16 04:52:59 --> Utf8 Class Initialized
DEBUG - 2011-06-16 04:52:59 --> UTF-8 Support Enabled
DEBUG - 2011-06-16 04:52:59 --> URI Class Initialized
DEBUG - 2011-06-16 04:52:59 --> Router Class Initialized
DEBUG - 2011-06-16 04:52:59 --> Output Class Initialized
DEBUG - 2011-06-16 04:52:59 --> Input Class Initialized
DEBUG - 2011-06-16 04:52:59 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-16 04:52:59 --> Language Class Initialized
DEBUG - 2011-06-16 04:52:59 --> Loader Class Initialized
DEBUG - 2011-06-16 04:52:59 --> Controller Class Initialized
ERROR - 2011-06-16 04:52:59 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-16 04:52:59 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-16 04:52:59 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-16 04:52:59 --> Model Class Initialized
DEBUG - 2011-06-16 04:52:59 --> Model Class Initialized
DEBUG - 2011-06-16 04:52:59 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-16 04:52:59 --> Database Driver Class Initialized
DEBUG - 2011-06-16 04:52:59 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-16 04:52:59 --> Helper loaded: url_helper
DEBUG - 2011-06-16 04:52:59 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-16 04:52:59 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-16 04:52:59 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-16 04:52:59 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-16 04:52:59 --> Final output sent to browser
DEBUG - 2011-06-16 04:52:59 --> Total execution time: 0.1390
DEBUG - 2011-06-16 05:41:43 --> Config Class Initialized
DEBUG - 2011-06-16 05:41:43 --> Hooks Class Initialized
DEBUG - 2011-06-16 05:41:43 --> Utf8 Class Initialized
DEBUG - 2011-06-16 05:41:43 --> UTF-8 Support Enabled
DEBUG - 2011-06-16 05:41:43 --> URI Class Initialized
DEBUG - 2011-06-16 05:41:43 --> Router Class Initialized
DEBUG - 2011-06-16 05:41:43 --> Output Class Initialized
DEBUG - 2011-06-16 05:41:43 --> Input Class Initialized
DEBUG - 2011-06-16 05:41:43 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-16 05:41:43 --> Language Class Initialized
DEBUG - 2011-06-16 05:41:44 --> Loader Class Initialized
DEBUG - 2011-06-16 05:41:44 --> Controller Class Initialized
DEBUG - 2011-06-16 05:41:44 --> Model Class Initialized
DEBUG - 2011-06-16 05:41:44 --> Model Class Initialized
DEBUG - 2011-06-16 05:41:44 --> Model Class Initialized
DEBUG - 2011-06-16 05:41:44 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-16 05:41:44 --> Database Driver Class Initialized
DEBUG - 2011-06-16 05:41:45 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-16 05:41:45 --> Helper loaded: url_helper
DEBUG - 2011-06-16 05:41:45 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-16 05:41:45 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-16 05:41:46 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-16 05:41:46 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-16 05:41:46 --> Final output sent to browser
DEBUG - 2011-06-16 05:41:46 --> Total execution time: 2.7014
DEBUG - 2011-06-16 06:33:16 --> Config Class Initialized
DEBUG - 2011-06-16 06:33:16 --> Hooks Class Initialized
DEBUG - 2011-06-16 06:33:16 --> Utf8 Class Initialized
DEBUG - 2011-06-16 06:33:16 --> UTF-8 Support Enabled
DEBUG - 2011-06-16 06:33:16 --> URI Class Initialized
DEBUG - 2011-06-16 06:33:16 --> Router Class Initialized
ERROR - 2011-06-16 06:33:16 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-06-16 06:53:02 --> Config Class Initialized
DEBUG - 2011-06-16 06:53:02 --> Hooks Class Initialized
DEBUG - 2011-06-16 06:53:02 --> Utf8 Class Initialized
DEBUG - 2011-06-16 06:53:02 --> UTF-8 Support Enabled
DEBUG - 2011-06-16 06:53:02 --> URI Class Initialized
DEBUG - 2011-06-16 06:53:02 --> Router Class Initialized
DEBUG - 2011-06-16 06:53:02 --> Output Class Initialized
DEBUG - 2011-06-16 06:53:02 --> Input Class Initialized
DEBUG - 2011-06-16 06:53:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-16 06:53:02 --> Language Class Initialized
DEBUG - 2011-06-16 06:53:02 --> Loader Class Initialized
DEBUG - 2011-06-16 06:53:02 --> Controller Class Initialized
ERROR - 2011-06-16 06:53:02 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-16 06:53:02 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-16 06:53:02 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-16 06:53:02 --> Model Class Initialized
DEBUG - 2011-06-16 06:53:02 --> Model Class Initialized
DEBUG - 2011-06-16 06:53:02 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-16 06:53:02 --> Database Driver Class Initialized
DEBUG - 2011-06-16 06:53:02 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-16 06:53:02 --> Helper loaded: url_helper
DEBUG - 2011-06-16 06:53:02 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-16 06:53:02 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-16 06:53:02 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-16 06:53:02 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-16 06:53:02 --> Final output sent to browser
DEBUG - 2011-06-16 06:53:02 --> Total execution time: 0.4741
DEBUG - 2011-06-16 06:53:04 --> Config Class Initialized
DEBUG - 2011-06-16 06:53:04 --> Hooks Class Initialized
DEBUG - 2011-06-16 06:53:04 --> Utf8 Class Initialized
DEBUG - 2011-06-16 06:53:04 --> UTF-8 Support Enabled
DEBUG - 2011-06-16 06:53:04 --> URI Class Initialized
DEBUG - 2011-06-16 06:53:04 --> Router Class Initialized
DEBUG - 2011-06-16 06:53:04 --> Output Class Initialized
DEBUG - 2011-06-16 06:53:04 --> Input Class Initialized
DEBUG - 2011-06-16 06:53:04 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-16 06:53:04 --> Language Class Initialized
DEBUG - 2011-06-16 06:53:04 --> Loader Class Initialized
DEBUG - 2011-06-16 06:53:04 --> Controller Class Initialized
DEBUG - 2011-06-16 06:53:04 --> Model Class Initialized
DEBUG - 2011-06-16 06:53:04 --> Model Class Initialized
DEBUG - 2011-06-16 06:53:04 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-16 06:53:04 --> Database Driver Class Initialized
DEBUG - 2011-06-16 06:53:04 --> Final output sent to browser
DEBUG - 2011-06-16 06:53:04 --> Total execution time: 0.6828
DEBUG - 2011-06-16 06:53:12 --> Config Class Initialized
DEBUG - 2011-06-16 06:53:12 --> Hooks Class Initialized
DEBUG - 2011-06-16 06:53:12 --> Utf8 Class Initialized
DEBUG - 2011-06-16 06:53:12 --> UTF-8 Support Enabled
DEBUG - 2011-06-16 06:53:12 --> URI Class Initialized
DEBUG - 2011-06-16 06:53:12 --> Router Class Initialized
ERROR - 2011-06-16 06:53:12 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-16 06:53:13 --> Config Class Initialized
DEBUG - 2011-06-16 06:53:13 --> Hooks Class Initialized
DEBUG - 2011-06-16 06:53:13 --> Utf8 Class Initialized
DEBUG - 2011-06-16 06:53:13 --> UTF-8 Support Enabled
DEBUG - 2011-06-16 06:53:13 --> URI Class Initialized
DEBUG - 2011-06-16 06:53:13 --> Router Class Initialized
ERROR - 2011-06-16 06:53:13 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-16 07:36:10 --> Config Class Initialized
DEBUG - 2011-06-16 07:36:10 --> Hooks Class Initialized
DEBUG - 2011-06-16 07:36:10 --> Utf8 Class Initialized
DEBUG - 2011-06-16 07:36:10 --> UTF-8 Support Enabled
DEBUG - 2011-06-16 07:36:10 --> URI Class Initialized
DEBUG - 2011-06-16 07:36:10 --> Router Class Initialized
DEBUG - 2011-06-16 07:36:10 --> Output Class Initialized
DEBUG - 2011-06-16 07:36:10 --> Input Class Initialized
DEBUG - 2011-06-16 07:36:10 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-16 07:36:11 --> Language Class Initialized
DEBUG - 2011-06-16 07:36:11 --> Loader Class Initialized
DEBUG - 2011-06-16 07:36:11 --> Controller Class Initialized
DEBUG - 2011-06-16 07:36:11 --> Model Class Initialized
DEBUG - 2011-06-16 07:36:11 --> Model Class Initialized
DEBUG - 2011-06-16 07:36:11 --> Model Class Initialized
DEBUG - 2011-06-16 07:36:11 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-16 07:36:12 --> Database Driver Class Initialized
DEBUG - 2011-06-16 07:36:14 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-16 07:36:14 --> Helper loaded: url_helper
DEBUG - 2011-06-16 07:36:14 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-16 07:36:14 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-16 07:36:14 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-16 07:36:14 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-16 07:36:14 --> Final output sent to browser
DEBUG - 2011-06-16 07:36:14 --> Total execution time: 4.2097
DEBUG - 2011-06-16 07:36:15 --> Config Class Initialized
DEBUG - 2011-06-16 07:36:15 --> Hooks Class Initialized
DEBUG - 2011-06-16 07:36:15 --> Utf8 Class Initialized
DEBUG - 2011-06-16 07:36:15 --> UTF-8 Support Enabled
DEBUG - 2011-06-16 07:36:15 --> URI Class Initialized
DEBUG - 2011-06-16 07:36:15 --> Router Class Initialized
DEBUG - 2011-06-16 07:36:15 --> Output Class Initialized
DEBUG - 2011-06-16 07:36:15 --> Input Class Initialized
DEBUG - 2011-06-16 07:36:15 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-16 07:36:15 --> Language Class Initialized
DEBUG - 2011-06-16 07:36:15 --> Loader Class Initialized
DEBUG - 2011-06-16 07:36:15 --> Controller Class Initialized
ERROR - 2011-06-16 07:36:15 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-16 07:36:15 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-16 07:36:15 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-16 07:36:15 --> Model Class Initialized
DEBUG - 2011-06-16 07:36:15 --> Model Class Initialized
DEBUG - 2011-06-16 07:36:15 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-16 07:36:15 --> Database Driver Class Initialized
DEBUG - 2011-06-16 07:36:15 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-16 07:36:15 --> Helper loaded: url_helper
DEBUG - 2011-06-16 07:36:15 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-16 07:36:15 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-16 07:36:15 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-16 07:36:15 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-16 07:36:15 --> Final output sent to browser
DEBUG - 2011-06-16 07:36:15 --> Total execution time: 0.6068
DEBUG - 2011-06-16 08:31:00 --> Config Class Initialized
DEBUG - 2011-06-16 08:31:00 --> Hooks Class Initialized
DEBUG - 2011-06-16 08:31:00 --> Utf8 Class Initialized
DEBUG - 2011-06-16 08:31:00 --> UTF-8 Support Enabled
DEBUG - 2011-06-16 08:31:00 --> URI Class Initialized
DEBUG - 2011-06-16 08:31:00 --> Router Class Initialized
DEBUG - 2011-06-16 08:31:00 --> Output Class Initialized
DEBUG - 2011-06-16 08:31:01 --> Input Class Initialized
DEBUG - 2011-06-16 08:31:01 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-16 08:31:01 --> Language Class Initialized
DEBUG - 2011-06-16 08:31:01 --> Loader Class Initialized
DEBUG - 2011-06-16 08:31:01 --> Controller Class Initialized
DEBUG - 2011-06-16 08:31:01 --> Model Class Initialized
DEBUG - 2011-06-16 08:31:01 --> Model Class Initialized
DEBUG - 2011-06-16 08:31:01 --> Model Class Initialized
DEBUG - 2011-06-16 08:31:01 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-16 08:31:01 --> Database Driver Class Initialized
DEBUG - 2011-06-16 08:31:02 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-16 08:31:03 --> Helper loaded: url_helper
DEBUG - 2011-06-16 08:31:03 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-16 08:31:03 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-16 08:31:03 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-16 08:31:03 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-16 08:31:03 --> Final output sent to browser
DEBUG - 2011-06-16 08:31:03 --> Total execution time: 3.0467
DEBUG - 2011-06-16 08:45:53 --> Config Class Initialized
DEBUG - 2011-06-16 08:45:53 --> Hooks Class Initialized
DEBUG - 2011-06-16 08:45:53 --> Utf8 Class Initialized
DEBUG - 2011-06-16 08:45:53 --> UTF-8 Support Enabled
DEBUG - 2011-06-16 08:45:53 --> URI Class Initialized
DEBUG - 2011-06-16 08:45:53 --> Router Class Initialized
DEBUG - 2011-06-16 08:45:53 --> Output Class Initialized
DEBUG - 2011-06-16 08:45:53 --> Input Class Initialized
DEBUG - 2011-06-16 08:45:53 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-16 08:45:53 --> Language Class Initialized
DEBUG - 2011-06-16 08:45:53 --> Loader Class Initialized
DEBUG - 2011-06-16 08:45:53 --> Controller Class Initialized
DEBUG - 2011-06-16 08:45:53 --> Model Class Initialized
DEBUG - 2011-06-16 08:45:53 --> Model Class Initialized
DEBUG - 2011-06-16 08:45:53 --> Model Class Initialized
DEBUG - 2011-06-16 08:45:53 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-16 08:45:53 --> Database Driver Class Initialized
DEBUG - 2011-06-16 08:45:53 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-16 08:45:53 --> Helper loaded: url_helper
DEBUG - 2011-06-16 08:45:53 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-16 08:45:53 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-16 08:45:54 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-16 08:45:54 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-16 08:45:54 --> Final output sent to browser
DEBUG - 2011-06-16 08:45:54 --> Total execution time: 0.2981
DEBUG - 2011-06-16 08:45:54 --> Config Class Initialized
DEBUG - 2011-06-16 08:45:54 --> Hooks Class Initialized
DEBUG - 2011-06-16 08:45:54 --> Utf8 Class Initialized
DEBUG - 2011-06-16 08:45:54 --> UTF-8 Support Enabled
DEBUG - 2011-06-16 08:45:54 --> URI Class Initialized
DEBUG - 2011-06-16 08:45:54 --> Router Class Initialized
DEBUG - 2011-06-16 08:45:54 --> Output Class Initialized
DEBUG - 2011-06-16 08:45:54 --> Input Class Initialized
DEBUG - 2011-06-16 08:45:54 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-16 08:45:54 --> Language Class Initialized
DEBUG - 2011-06-16 08:45:54 --> Loader Class Initialized
DEBUG - 2011-06-16 08:45:54 --> Controller Class Initialized
ERROR - 2011-06-16 08:45:54 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-16 08:45:54 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-16 08:45:54 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-16 08:45:54 --> Model Class Initialized
DEBUG - 2011-06-16 08:45:54 --> Model Class Initialized
DEBUG - 2011-06-16 08:45:54 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-16 08:45:54 --> Database Driver Class Initialized
DEBUG - 2011-06-16 08:45:54 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-16 08:45:54 --> Helper loaded: url_helper
DEBUG - 2011-06-16 08:45:54 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-16 08:45:54 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-16 08:45:54 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-16 08:45:54 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-16 08:45:54 --> Final output sent to browser
DEBUG - 2011-06-16 08:45:54 --> Total execution time: 0.1138
DEBUG - 2011-06-16 09:08:47 --> Config Class Initialized
DEBUG - 2011-06-16 09:08:47 --> Hooks Class Initialized
DEBUG - 2011-06-16 09:08:47 --> Utf8 Class Initialized
DEBUG - 2011-06-16 09:08:47 --> UTF-8 Support Enabled
DEBUG - 2011-06-16 09:08:47 --> URI Class Initialized
DEBUG - 2011-06-16 09:08:47 --> Router Class Initialized
DEBUG - 2011-06-16 09:08:47 --> Output Class Initialized
DEBUG - 2011-06-16 09:08:47 --> Input Class Initialized
DEBUG - 2011-06-16 09:08:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-16 09:08:47 --> Language Class Initialized
DEBUG - 2011-06-16 09:08:47 --> Loader Class Initialized
DEBUG - 2011-06-16 09:08:47 --> Controller Class Initialized
DEBUG - 2011-06-16 09:08:47 --> Model Class Initialized
DEBUG - 2011-06-16 09:08:47 --> Model Class Initialized
DEBUG - 2011-06-16 09:08:47 --> Model Class Initialized
DEBUG - 2011-06-16 09:08:47 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-16 09:08:47 --> Database Driver Class Initialized
DEBUG - 2011-06-16 09:08:47 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-16 09:08:47 --> Helper loaded: url_helper
DEBUG - 2011-06-16 09:08:47 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-16 09:08:47 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-16 09:08:47 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-16 09:08:47 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-16 09:08:47 --> Final output sent to browser
DEBUG - 2011-06-16 09:08:47 --> Total execution time: 0.6216
DEBUG - 2011-06-16 09:09:33 --> Config Class Initialized
DEBUG - 2011-06-16 09:09:33 --> Hooks Class Initialized
DEBUG - 2011-06-16 09:09:33 --> Utf8 Class Initialized
DEBUG - 2011-06-16 09:09:33 --> UTF-8 Support Enabled
DEBUG - 2011-06-16 09:09:33 --> URI Class Initialized
DEBUG - 2011-06-16 09:09:33 --> Router Class Initialized
DEBUG - 2011-06-16 09:09:33 --> Output Class Initialized
DEBUG - 2011-06-16 09:09:33 --> Input Class Initialized
DEBUG - 2011-06-16 09:09:33 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-16 09:09:33 --> Language Class Initialized
DEBUG - 2011-06-16 09:09:33 --> Loader Class Initialized
DEBUG - 2011-06-16 09:09:33 --> Controller Class Initialized
ERROR - 2011-06-16 09:09:33 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-16 09:09:33 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-16 09:09:33 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-16 09:09:33 --> Model Class Initialized
DEBUG - 2011-06-16 09:09:33 --> Model Class Initialized
DEBUG - 2011-06-16 09:09:33 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-16 09:09:33 --> Database Driver Class Initialized
DEBUG - 2011-06-16 09:09:33 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-16 09:09:33 --> Helper loaded: url_helper
DEBUG - 2011-06-16 09:09:33 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-16 09:09:33 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-16 09:09:33 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-16 09:09:33 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-16 09:09:33 --> Final output sent to browser
DEBUG - 2011-06-16 09:09:33 --> Total execution time: 0.1380
DEBUG - 2011-06-16 12:55:08 --> Config Class Initialized
DEBUG - 2011-06-16 12:55:08 --> Hooks Class Initialized
DEBUG - 2011-06-16 12:55:08 --> Utf8 Class Initialized
DEBUG - 2011-06-16 12:55:08 --> UTF-8 Support Enabled
DEBUG - 2011-06-16 12:55:08 --> URI Class Initialized
DEBUG - 2011-06-16 12:55:08 --> Router Class Initialized
DEBUG - 2011-06-16 12:55:08 --> Output Class Initialized
DEBUG - 2011-06-16 12:55:08 --> Input Class Initialized
DEBUG - 2011-06-16 12:55:08 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-16 12:55:08 --> Language Class Initialized
DEBUG - 2011-06-16 12:55:08 --> Loader Class Initialized
DEBUG - 2011-06-16 12:55:08 --> Controller Class Initialized
DEBUG - 2011-06-16 12:55:08 --> Model Class Initialized
DEBUG - 2011-06-16 12:55:08 --> Model Class Initialized
DEBUG - 2011-06-16 12:55:08 --> Model Class Initialized
DEBUG - 2011-06-16 12:55:08 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-16 12:55:08 --> Database Driver Class Initialized
DEBUG - 2011-06-16 12:55:09 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-16 12:55:09 --> Helper loaded: url_helper
DEBUG - 2011-06-16 12:55:09 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-16 12:55:09 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-16 12:55:09 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-16 12:55:09 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-16 12:55:09 --> Final output sent to browser
DEBUG - 2011-06-16 12:55:09 --> Total execution time: 0.7474
DEBUG - 2011-06-16 12:55:10 --> Config Class Initialized
DEBUG - 2011-06-16 12:55:10 --> Hooks Class Initialized
DEBUG - 2011-06-16 12:55:10 --> Utf8 Class Initialized
DEBUG - 2011-06-16 12:55:10 --> UTF-8 Support Enabled
DEBUG - 2011-06-16 12:55:10 --> URI Class Initialized
DEBUG - 2011-06-16 12:55:10 --> Router Class Initialized
DEBUG - 2011-06-16 12:55:10 --> Output Class Initialized
DEBUG - 2011-06-16 12:55:10 --> Input Class Initialized
DEBUG - 2011-06-16 12:55:10 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-16 12:55:10 --> Language Class Initialized
DEBUG - 2011-06-16 12:55:10 --> Loader Class Initialized
DEBUG - 2011-06-16 12:55:10 --> Controller Class Initialized
ERROR - 2011-06-16 12:55:10 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-16 12:55:10 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-16 12:55:10 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-16 12:55:10 --> Model Class Initialized
DEBUG - 2011-06-16 12:55:10 --> Model Class Initialized
DEBUG - 2011-06-16 12:55:10 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-16 12:55:10 --> Database Driver Class Initialized
DEBUG - 2011-06-16 12:55:10 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-16 12:55:10 --> Helper loaded: url_helper
DEBUG - 2011-06-16 12:55:10 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-16 12:55:10 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-16 12:55:10 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-16 12:55:10 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-16 12:55:10 --> Final output sent to browser
DEBUG - 2011-06-16 12:55:10 --> Total execution time: 0.0674
DEBUG - 2011-06-16 14:23:20 --> Config Class Initialized
DEBUG - 2011-06-16 14:23:20 --> Hooks Class Initialized
DEBUG - 2011-06-16 14:23:20 --> Utf8 Class Initialized
DEBUG - 2011-06-16 14:23:20 --> UTF-8 Support Enabled
DEBUG - 2011-06-16 14:23:20 --> URI Class Initialized
DEBUG - 2011-06-16 14:23:20 --> Router Class Initialized
ERROR - 2011-06-16 14:23:20 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-06-16 14:23:20 --> Config Class Initialized
DEBUG - 2011-06-16 14:23:20 --> Hooks Class Initialized
DEBUG - 2011-06-16 14:23:20 --> Utf8 Class Initialized
DEBUG - 2011-06-16 14:23:20 --> UTF-8 Support Enabled
DEBUG - 2011-06-16 14:23:20 --> URI Class Initialized
DEBUG - 2011-06-16 14:23:20 --> Router Class Initialized
DEBUG - 2011-06-16 14:23:20 --> No URI present. Default controller set.
DEBUG - 2011-06-16 14:23:20 --> Output Class Initialized
DEBUG - 2011-06-16 14:23:20 --> Input Class Initialized
DEBUG - 2011-06-16 14:23:20 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-16 14:23:20 --> Language Class Initialized
DEBUG - 2011-06-16 14:23:20 --> Loader Class Initialized
DEBUG - 2011-06-16 14:23:20 --> Controller Class Initialized
DEBUG - 2011-06-16 14:23:20 --> File loaded: application/views/splash/main.php
DEBUG - 2011-06-16 14:23:20 --> Helper loaded: url_helper
DEBUG - 2011-06-16 14:23:20 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-16 14:23:20 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-16 14:23:20 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-16 14:23:20 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-16 14:23:20 --> Final output sent to browser
DEBUG - 2011-06-16 14:23:20 --> Total execution time: 0.1920
DEBUG - 2011-06-16 14:24:01 --> Config Class Initialized
DEBUG - 2011-06-16 14:24:01 --> Hooks Class Initialized
DEBUG - 2011-06-16 14:24:01 --> Utf8 Class Initialized
DEBUG - 2011-06-16 14:24:01 --> UTF-8 Support Enabled
DEBUG - 2011-06-16 14:24:01 --> URI Class Initialized
DEBUG - 2011-06-16 14:24:01 --> Router Class Initialized
DEBUG - 2011-06-16 14:24:01 --> Output Class Initialized
DEBUG - 2011-06-16 14:24:01 --> Input Class Initialized
DEBUG - 2011-06-16 14:24:01 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-16 14:24:01 --> Language Class Initialized
DEBUG - 2011-06-16 14:24:01 --> Loader Class Initialized
DEBUG - 2011-06-16 14:24:01 --> Controller Class Initialized
DEBUG - 2011-06-16 14:24:01 --> Model Class Initialized
DEBUG - 2011-06-16 14:24:01 --> Model Class Initialized
DEBUG - 2011-06-16 14:24:01 --> Model Class Initialized
DEBUG - 2011-06-16 14:24:01 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-16 14:24:01 --> Database Driver Class Initialized
DEBUG - 2011-06-16 14:24:01 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-16 14:24:01 --> Helper loaded: url_helper
DEBUG - 2011-06-16 14:24:01 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-16 14:24:01 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-16 14:24:01 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-16 14:24:01 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-16 14:24:01 --> Final output sent to browser
DEBUG - 2011-06-16 14:24:01 --> Total execution time: 0.5088
DEBUG - 2011-06-16 14:24:04 --> Config Class Initialized
DEBUG - 2011-06-16 14:24:04 --> Hooks Class Initialized
DEBUG - 2011-06-16 14:24:04 --> Utf8 Class Initialized
DEBUG - 2011-06-16 14:24:04 --> UTF-8 Support Enabled
DEBUG - 2011-06-16 14:24:04 --> URI Class Initialized
DEBUG - 2011-06-16 14:24:04 --> Router Class Initialized
ERROR - 2011-06-16 14:24:04 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-16 14:24:06 --> Config Class Initialized
DEBUG - 2011-06-16 14:24:06 --> Hooks Class Initialized
DEBUG - 2011-06-16 14:24:06 --> Utf8 Class Initialized
DEBUG - 2011-06-16 14:24:06 --> UTF-8 Support Enabled
DEBUG - 2011-06-16 14:24:06 --> URI Class Initialized
DEBUG - 2011-06-16 14:24:06 --> Router Class Initialized
ERROR - 2011-06-16 14:24:06 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-16 14:24:10 --> Config Class Initialized
DEBUG - 2011-06-16 14:24:10 --> Hooks Class Initialized
DEBUG - 2011-06-16 14:24:10 --> Utf8 Class Initialized
DEBUG - 2011-06-16 14:24:10 --> UTF-8 Support Enabled
DEBUG - 2011-06-16 14:24:10 --> URI Class Initialized
DEBUG - 2011-06-16 14:24:10 --> Router Class Initialized
DEBUG - 2011-06-16 14:24:10 --> Output Class Initialized
DEBUG - 2011-06-16 14:24:10 --> Input Class Initialized
DEBUG - 2011-06-16 14:24:10 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-16 14:24:10 --> Language Class Initialized
DEBUG - 2011-06-16 14:24:10 --> Loader Class Initialized
DEBUG - 2011-06-16 14:24:10 --> Controller Class Initialized
DEBUG - 2011-06-16 14:24:10 --> Model Class Initialized
DEBUG - 2011-06-16 14:24:10 --> Model Class Initialized
DEBUG - 2011-06-16 14:24:10 --> Model Class Initialized
DEBUG - 2011-06-16 14:24:10 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-16 14:24:10 --> Database Driver Class Initialized
DEBUG - 2011-06-16 14:24:10 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-16 14:24:10 --> Helper loaded: url_helper
DEBUG - 2011-06-16 14:24:10 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-16 14:24:10 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-16 14:24:10 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-16 14:24:10 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-16 14:24:10 --> Final output sent to browser
DEBUG - 2011-06-16 14:24:10 --> Total execution time: 0.6811
DEBUG - 2011-06-16 14:24:12 --> Config Class Initialized
DEBUG - 2011-06-16 14:24:12 --> Hooks Class Initialized
DEBUG - 2011-06-16 14:24:12 --> Utf8 Class Initialized
DEBUG - 2011-06-16 14:24:12 --> UTF-8 Support Enabled
DEBUG - 2011-06-16 14:24:12 --> URI Class Initialized
DEBUG - 2011-06-16 14:24:12 --> Router Class Initialized
ERROR - 2011-06-16 14:24:12 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-06-16 14:24:12 --> Config Class Initialized
DEBUG - 2011-06-16 14:24:12 --> Hooks Class Initialized
DEBUG - 2011-06-16 14:24:12 --> Utf8 Class Initialized
DEBUG - 2011-06-16 14:24:12 --> UTF-8 Support Enabled
DEBUG - 2011-06-16 14:24:12 --> URI Class Initialized
DEBUG - 2011-06-16 14:24:12 --> Router Class Initialized
DEBUG - 2011-06-16 14:24:12 --> Output Class Initialized
DEBUG - 2011-06-16 14:24:12 --> Input Class Initialized
DEBUG - 2011-06-16 14:24:12 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-16 14:24:12 --> Language Class Initialized
DEBUG - 2011-06-16 14:24:12 --> Loader Class Initialized
DEBUG - 2011-06-16 14:24:13 --> Controller Class Initialized
DEBUG - 2011-06-16 14:24:13 --> Model Class Initialized
DEBUG - 2011-06-16 14:24:13 --> Model Class Initialized
DEBUG - 2011-06-16 14:24:13 --> Model Class Initialized
DEBUG - 2011-06-16 14:24:13 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-16 14:24:13 --> Database Driver Class Initialized
DEBUG - 2011-06-16 14:24:13 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-16 14:24:13 --> Helper loaded: url_helper
DEBUG - 2011-06-16 14:24:13 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-16 14:24:13 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-16 14:24:13 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-16 14:24:13 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-16 14:24:13 --> Final output sent to browser
DEBUG - 2011-06-16 14:24:13 --> Total execution time: 0.0560
DEBUG - 2011-06-16 14:24:24 --> Config Class Initialized
DEBUG - 2011-06-16 14:24:24 --> Hooks Class Initialized
DEBUG - 2011-06-16 14:24:24 --> Utf8 Class Initialized
DEBUG - 2011-06-16 14:24:24 --> UTF-8 Support Enabled
DEBUG - 2011-06-16 14:24:24 --> URI Class Initialized
DEBUG - 2011-06-16 14:24:24 --> Router Class Initialized
DEBUG - 2011-06-16 14:24:24 --> Output Class Initialized
DEBUG - 2011-06-16 14:24:24 --> Input Class Initialized
DEBUG - 2011-06-16 14:24:24 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-16 14:24:24 --> Language Class Initialized
DEBUG - 2011-06-16 14:24:24 --> Loader Class Initialized
DEBUG - 2011-06-16 14:24:24 --> Controller Class Initialized
DEBUG - 2011-06-16 14:24:24 --> Model Class Initialized
DEBUG - 2011-06-16 14:24:24 --> Model Class Initialized
DEBUG - 2011-06-16 14:24:24 --> Model Class Initialized
DEBUG - 2011-06-16 14:24:24 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-16 14:24:24 --> Database Driver Class Initialized
DEBUG - 2011-06-16 14:24:25 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-16 14:24:25 --> Helper loaded: url_helper
DEBUG - 2011-06-16 14:24:25 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-16 14:24:25 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-16 14:24:25 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-16 14:24:25 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-16 14:24:25 --> Final output sent to browser
DEBUG - 2011-06-16 14:24:25 --> Total execution time: 0.6378
DEBUG - 2011-06-16 14:24:26 --> Config Class Initialized
DEBUG - 2011-06-16 14:24:26 --> Hooks Class Initialized
DEBUG - 2011-06-16 14:24:26 --> Utf8 Class Initialized
DEBUG - 2011-06-16 14:24:26 --> UTF-8 Support Enabled
DEBUG - 2011-06-16 14:24:26 --> URI Class Initialized
DEBUG - 2011-06-16 14:24:26 --> Router Class Initialized
DEBUG - 2011-06-16 14:24:26 --> Output Class Initialized
DEBUG - 2011-06-16 14:24:26 --> Input Class Initialized
DEBUG - 2011-06-16 14:24:26 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-16 14:24:26 --> Language Class Initialized
DEBUG - 2011-06-16 14:24:26 --> Loader Class Initialized
DEBUG - 2011-06-16 14:24:26 --> Controller Class Initialized
DEBUG - 2011-06-16 14:24:26 --> Model Class Initialized
DEBUG - 2011-06-16 14:24:26 --> Model Class Initialized
DEBUG - 2011-06-16 14:24:26 --> Model Class Initialized
DEBUG - 2011-06-16 14:24:26 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-16 14:24:26 --> Database Driver Class Initialized
DEBUG - 2011-06-16 14:24:26 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-16 14:24:26 --> Helper loaded: url_helper
DEBUG - 2011-06-16 14:24:26 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-16 14:24:26 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-16 14:24:26 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-16 14:24:26 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-16 14:24:26 --> Final output sent to browser
DEBUG - 2011-06-16 14:24:26 --> Total execution time: 0.0490
DEBUG - 2011-06-16 14:24:27 --> Config Class Initialized
DEBUG - 2011-06-16 14:24:27 --> Hooks Class Initialized
DEBUG - 2011-06-16 14:24:27 --> Utf8 Class Initialized
DEBUG - 2011-06-16 14:24:27 --> UTF-8 Support Enabled
DEBUG - 2011-06-16 14:24:27 --> URI Class Initialized
DEBUG - 2011-06-16 14:24:27 --> Router Class Initialized
DEBUG - 2011-06-16 14:24:27 --> Output Class Initialized
DEBUG - 2011-06-16 14:24:27 --> Input Class Initialized
DEBUG - 2011-06-16 14:24:27 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-16 14:24:27 --> Language Class Initialized
DEBUG - 2011-06-16 14:24:27 --> Loader Class Initialized
DEBUG - 2011-06-16 14:24:27 --> Controller Class Initialized
DEBUG - 2011-06-16 14:24:27 --> Model Class Initialized
DEBUG - 2011-06-16 14:24:27 --> Model Class Initialized
DEBUG - 2011-06-16 14:24:27 --> Model Class Initialized
DEBUG - 2011-06-16 14:24:27 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-16 14:24:27 --> Database Driver Class Initialized
DEBUG - 2011-06-16 14:24:27 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-16 14:24:27 --> Helper loaded: url_helper
DEBUG - 2011-06-16 14:24:27 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-16 14:24:27 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-16 14:24:27 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-16 14:24:27 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-16 14:24:27 --> Final output sent to browser
DEBUG - 2011-06-16 14:24:27 --> Total execution time: 0.0587
DEBUG - 2011-06-16 14:24:32 --> Config Class Initialized
DEBUG - 2011-06-16 14:24:32 --> Hooks Class Initialized
DEBUG - 2011-06-16 14:24:32 --> Utf8 Class Initialized
DEBUG - 2011-06-16 14:24:32 --> UTF-8 Support Enabled
DEBUG - 2011-06-16 14:24:32 --> URI Class Initialized
DEBUG - 2011-06-16 14:24:32 --> Router Class Initialized
DEBUG - 2011-06-16 14:24:32 --> Output Class Initialized
DEBUG - 2011-06-16 14:24:32 --> Input Class Initialized
DEBUG - 2011-06-16 14:24:32 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-16 14:24:32 --> Language Class Initialized
DEBUG - 2011-06-16 14:24:32 --> Loader Class Initialized
DEBUG - 2011-06-16 14:24:32 --> Controller Class Initialized
DEBUG - 2011-06-16 14:24:32 --> Model Class Initialized
DEBUG - 2011-06-16 14:24:32 --> Model Class Initialized
DEBUG - 2011-06-16 14:24:32 --> Model Class Initialized
DEBUG - 2011-06-16 14:24:32 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-16 14:24:32 --> Database Driver Class Initialized
DEBUG - 2011-06-16 14:24:33 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-16 14:24:33 --> Helper loaded: url_helper
DEBUG - 2011-06-16 14:24:33 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-16 14:24:33 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-16 14:24:33 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-16 14:24:33 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-16 14:24:33 --> Final output sent to browser
DEBUG - 2011-06-16 14:24:33 --> Total execution time: 0.4534
DEBUG - 2011-06-16 14:24:42 --> Config Class Initialized
DEBUG - 2011-06-16 14:24:42 --> Hooks Class Initialized
DEBUG - 2011-06-16 14:24:42 --> Utf8 Class Initialized
DEBUG - 2011-06-16 14:24:42 --> UTF-8 Support Enabled
DEBUG - 2011-06-16 14:24:42 --> URI Class Initialized
DEBUG - 2011-06-16 14:24:42 --> Router Class Initialized
DEBUG - 2011-06-16 14:24:42 --> Output Class Initialized
DEBUG - 2011-06-16 14:24:42 --> Input Class Initialized
DEBUG - 2011-06-16 14:24:42 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-16 14:24:42 --> Language Class Initialized
DEBUG - 2011-06-16 14:24:42 --> Loader Class Initialized
DEBUG - 2011-06-16 14:24:42 --> Controller Class Initialized
DEBUG - 2011-06-16 14:24:42 --> Model Class Initialized
DEBUG - 2011-06-16 14:24:42 --> Model Class Initialized
DEBUG - 2011-06-16 14:24:42 --> Model Class Initialized
DEBUG - 2011-06-16 14:24:42 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-16 14:24:42 --> Database Driver Class Initialized
DEBUG - 2011-06-16 14:24:43 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-16 14:24:43 --> Helper loaded: url_helper
DEBUG - 2011-06-16 14:24:43 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-16 14:24:43 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-16 14:24:43 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-16 14:24:43 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-16 14:24:43 --> Final output sent to browser
DEBUG - 2011-06-16 14:24:43 --> Total execution time: 0.6620
DEBUG - 2011-06-16 14:24:46 --> Config Class Initialized
DEBUG - 2011-06-16 14:24:46 --> Hooks Class Initialized
DEBUG - 2011-06-16 14:24:46 --> Utf8 Class Initialized
DEBUG - 2011-06-16 14:24:46 --> UTF-8 Support Enabled
DEBUG - 2011-06-16 14:24:46 --> URI Class Initialized
DEBUG - 2011-06-16 14:24:46 --> Router Class Initialized
DEBUG - 2011-06-16 14:24:46 --> Output Class Initialized
DEBUG - 2011-06-16 14:24:46 --> Input Class Initialized
DEBUG - 2011-06-16 14:24:46 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-16 14:24:46 --> Language Class Initialized
DEBUG - 2011-06-16 14:24:46 --> Loader Class Initialized
DEBUG - 2011-06-16 14:24:46 --> Controller Class Initialized
DEBUG - 2011-06-16 14:24:46 --> Model Class Initialized
DEBUG - 2011-06-16 14:24:46 --> Model Class Initialized
DEBUG - 2011-06-16 14:24:46 --> Model Class Initialized
DEBUG - 2011-06-16 14:24:46 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-16 14:24:46 --> Database Driver Class Initialized
DEBUG - 2011-06-16 14:24:46 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-16 14:24:46 --> Helper loaded: url_helper
DEBUG - 2011-06-16 14:24:46 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-16 14:24:46 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-16 14:24:46 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-16 14:24:46 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-16 14:24:46 --> Final output sent to browser
DEBUG - 2011-06-16 14:24:46 --> Total execution time: 0.0634
DEBUG - 2011-06-16 14:24:47 --> Config Class Initialized
DEBUG - 2011-06-16 14:24:47 --> Hooks Class Initialized
DEBUG - 2011-06-16 14:24:47 --> Utf8 Class Initialized
DEBUG - 2011-06-16 14:24:47 --> UTF-8 Support Enabled
DEBUG - 2011-06-16 14:24:47 --> URI Class Initialized
DEBUG - 2011-06-16 14:24:47 --> Router Class Initialized
DEBUG - 2011-06-16 14:24:47 --> Output Class Initialized
DEBUG - 2011-06-16 14:24:47 --> Input Class Initialized
DEBUG - 2011-06-16 14:24:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-16 14:24:47 --> Language Class Initialized
DEBUG - 2011-06-16 14:24:47 --> Loader Class Initialized
DEBUG - 2011-06-16 14:24:47 --> Controller Class Initialized
DEBUG - 2011-06-16 14:24:47 --> Model Class Initialized
DEBUG - 2011-06-16 14:24:47 --> Model Class Initialized
DEBUG - 2011-06-16 14:24:47 --> Model Class Initialized
DEBUG - 2011-06-16 14:24:47 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-16 14:24:47 --> Database Driver Class Initialized
DEBUG - 2011-06-16 14:24:47 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-16 14:24:47 --> Helper loaded: url_helper
DEBUG - 2011-06-16 14:24:47 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-16 14:24:47 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-16 14:24:47 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-16 14:24:47 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-16 14:24:47 --> Final output sent to browser
DEBUG - 2011-06-16 14:24:47 --> Total execution time: 0.0566
DEBUG - 2011-06-16 14:24:50 --> Config Class Initialized
DEBUG - 2011-06-16 14:24:50 --> Hooks Class Initialized
DEBUG - 2011-06-16 14:24:50 --> Utf8 Class Initialized
DEBUG - 2011-06-16 14:24:50 --> UTF-8 Support Enabled
DEBUG - 2011-06-16 14:24:50 --> URI Class Initialized
DEBUG - 2011-06-16 14:24:50 --> Router Class Initialized
DEBUG - 2011-06-16 14:24:50 --> Output Class Initialized
DEBUG - 2011-06-16 14:24:50 --> Input Class Initialized
DEBUG - 2011-06-16 14:24:50 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-16 14:24:50 --> Language Class Initialized
DEBUG - 2011-06-16 14:24:50 --> Loader Class Initialized
DEBUG - 2011-06-16 14:24:50 --> Controller Class Initialized
DEBUG - 2011-06-16 14:24:50 --> Model Class Initialized
DEBUG - 2011-06-16 14:24:50 --> Model Class Initialized
DEBUG - 2011-06-16 14:24:50 --> Model Class Initialized
DEBUG - 2011-06-16 14:24:50 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-16 14:24:50 --> Database Driver Class Initialized
DEBUG - 2011-06-16 14:24:51 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-16 14:24:51 --> Helper loaded: url_helper
DEBUG - 2011-06-16 14:24:51 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-16 14:24:51 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-16 14:24:51 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-16 14:24:51 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-16 14:24:51 --> Final output sent to browser
DEBUG - 2011-06-16 14:24:51 --> Total execution time: 0.5894
DEBUG - 2011-06-16 14:24:52 --> Config Class Initialized
DEBUG - 2011-06-16 14:24:52 --> Hooks Class Initialized
DEBUG - 2011-06-16 14:24:52 --> Utf8 Class Initialized
DEBUG - 2011-06-16 14:24:52 --> UTF-8 Support Enabled
DEBUG - 2011-06-16 14:24:52 --> URI Class Initialized
DEBUG - 2011-06-16 14:24:52 --> Router Class Initialized
DEBUG - 2011-06-16 14:24:52 --> Output Class Initialized
DEBUG - 2011-06-16 14:24:52 --> Input Class Initialized
DEBUG - 2011-06-16 14:24:52 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-16 14:24:52 --> Language Class Initialized
DEBUG - 2011-06-16 14:24:52 --> Loader Class Initialized
DEBUG - 2011-06-16 14:24:52 --> Controller Class Initialized
DEBUG - 2011-06-16 14:24:52 --> Model Class Initialized
DEBUG - 2011-06-16 14:24:52 --> Model Class Initialized
DEBUG - 2011-06-16 14:24:52 --> Model Class Initialized
DEBUG - 2011-06-16 14:24:52 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-16 14:24:52 --> Database Driver Class Initialized
DEBUG - 2011-06-16 14:24:52 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-16 14:24:52 --> Helper loaded: url_helper
DEBUG - 2011-06-16 14:24:52 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-16 14:24:52 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-16 14:24:52 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-16 14:24:52 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-16 14:24:52 --> Final output sent to browser
DEBUG - 2011-06-16 14:24:52 --> Total execution time: 0.0678
DEBUG - 2011-06-16 14:24:52 --> Config Class Initialized
DEBUG - 2011-06-16 14:24:52 --> Hooks Class Initialized
DEBUG - 2011-06-16 14:24:52 --> Utf8 Class Initialized
DEBUG - 2011-06-16 14:24:52 --> UTF-8 Support Enabled
DEBUG - 2011-06-16 14:24:52 --> URI Class Initialized
DEBUG - 2011-06-16 14:24:52 --> Router Class Initialized
DEBUG - 2011-06-16 14:24:52 --> Output Class Initialized
DEBUG - 2011-06-16 14:24:52 --> Input Class Initialized
DEBUG - 2011-06-16 14:24:52 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-16 14:24:52 --> Language Class Initialized
DEBUG - 2011-06-16 14:24:52 --> Loader Class Initialized
DEBUG - 2011-06-16 14:24:52 --> Controller Class Initialized
DEBUG - 2011-06-16 14:24:52 --> Model Class Initialized
DEBUG - 2011-06-16 14:24:52 --> Model Class Initialized
DEBUG - 2011-06-16 14:24:52 --> Model Class Initialized
DEBUG - 2011-06-16 14:24:52 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-16 14:24:52 --> Database Driver Class Initialized
DEBUG - 2011-06-16 14:24:52 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-16 14:24:52 --> Helper loaded: url_helper
DEBUG - 2011-06-16 14:24:52 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-16 14:24:52 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-16 14:24:52 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-16 14:24:52 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-16 14:24:52 --> Final output sent to browser
DEBUG - 2011-06-16 14:24:52 --> Total execution time: 0.0540
DEBUG - 2011-06-16 14:25:00 --> Config Class Initialized
DEBUG - 2011-06-16 14:25:00 --> Hooks Class Initialized
DEBUG - 2011-06-16 14:25:00 --> Utf8 Class Initialized
DEBUG - 2011-06-16 14:25:00 --> UTF-8 Support Enabled
DEBUG - 2011-06-16 14:25:00 --> URI Class Initialized
DEBUG - 2011-06-16 14:25:00 --> Router Class Initialized
DEBUG - 2011-06-16 14:25:00 --> Output Class Initialized
DEBUG - 2011-06-16 14:25:00 --> Input Class Initialized
DEBUG - 2011-06-16 14:25:00 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-16 14:25:00 --> Language Class Initialized
DEBUG - 2011-06-16 14:25:00 --> Loader Class Initialized
DEBUG - 2011-06-16 14:25:00 --> Controller Class Initialized
DEBUG - 2011-06-16 14:25:00 --> Model Class Initialized
DEBUG - 2011-06-16 14:25:00 --> Model Class Initialized
DEBUG - 2011-06-16 14:25:00 --> Model Class Initialized
DEBUG - 2011-06-16 14:25:00 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-16 14:25:00 --> Database Driver Class Initialized
DEBUG - 2011-06-16 14:25:00 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-16 14:25:00 --> Helper loaded: url_helper
DEBUG - 2011-06-16 14:25:00 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-16 14:25:00 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-16 14:25:00 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-16 14:25:00 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-16 14:25:00 --> Final output sent to browser
DEBUG - 2011-06-16 14:25:00 --> Total execution time: 0.4386
DEBUG - 2011-06-16 14:25:03 --> Config Class Initialized
DEBUG - 2011-06-16 14:25:03 --> Hooks Class Initialized
DEBUG - 2011-06-16 14:25:03 --> Utf8 Class Initialized
DEBUG - 2011-06-16 14:25:03 --> UTF-8 Support Enabled
DEBUG - 2011-06-16 14:25:03 --> URI Class Initialized
DEBUG - 2011-06-16 14:25:03 --> Router Class Initialized
DEBUG - 2011-06-16 14:25:03 --> Output Class Initialized
DEBUG - 2011-06-16 14:25:03 --> Input Class Initialized
DEBUG - 2011-06-16 14:25:03 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-16 14:25:03 --> Language Class Initialized
DEBUG - 2011-06-16 14:25:03 --> Loader Class Initialized
DEBUG - 2011-06-16 14:25:03 --> Controller Class Initialized
DEBUG - 2011-06-16 14:25:03 --> Model Class Initialized
DEBUG - 2011-06-16 14:25:03 --> Model Class Initialized
DEBUG - 2011-06-16 14:25:03 --> Model Class Initialized
DEBUG - 2011-06-16 14:25:03 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-16 14:25:03 --> Database Driver Class Initialized
DEBUG - 2011-06-16 14:25:03 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-16 14:25:03 --> Helper loaded: url_helper
DEBUG - 2011-06-16 14:25:03 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-16 14:25:03 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-16 14:25:03 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-16 14:25:03 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-16 14:25:03 --> Final output sent to browser
DEBUG - 2011-06-16 14:25:03 --> Total execution time: 0.1027
DEBUG - 2011-06-16 14:25:07 --> Config Class Initialized
DEBUG - 2011-06-16 14:25:07 --> Hooks Class Initialized
DEBUG - 2011-06-16 14:25:07 --> Utf8 Class Initialized
DEBUG - 2011-06-16 14:25:07 --> UTF-8 Support Enabled
DEBUG - 2011-06-16 14:25:07 --> URI Class Initialized
DEBUG - 2011-06-16 14:25:07 --> Router Class Initialized
DEBUG - 2011-06-16 14:25:07 --> Output Class Initialized
DEBUG - 2011-06-16 14:25:07 --> Input Class Initialized
DEBUG - 2011-06-16 14:25:07 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-16 14:25:07 --> Language Class Initialized
DEBUG - 2011-06-16 14:25:07 --> Loader Class Initialized
DEBUG - 2011-06-16 14:25:07 --> Controller Class Initialized
DEBUG - 2011-06-16 14:25:07 --> Model Class Initialized
DEBUG - 2011-06-16 14:25:07 --> Model Class Initialized
DEBUG - 2011-06-16 14:25:07 --> Model Class Initialized
DEBUG - 2011-06-16 14:25:07 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-16 14:25:07 --> Database Driver Class Initialized
DEBUG - 2011-06-16 14:25:07 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-16 14:25:07 --> Helper loaded: url_helper
DEBUG - 2011-06-16 14:25:07 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-16 14:25:07 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-16 14:25:07 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-16 14:25:07 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-16 14:25:07 --> Final output sent to browser
DEBUG - 2011-06-16 14:25:07 --> Total execution time: 0.4660
DEBUG - 2011-06-16 14:25:08 --> Config Class Initialized
DEBUG - 2011-06-16 14:25:08 --> Hooks Class Initialized
DEBUG - 2011-06-16 14:25:08 --> Utf8 Class Initialized
DEBUG - 2011-06-16 14:25:08 --> UTF-8 Support Enabled
DEBUG - 2011-06-16 14:25:08 --> URI Class Initialized
DEBUG - 2011-06-16 14:25:08 --> Router Class Initialized
DEBUG - 2011-06-16 14:25:08 --> Output Class Initialized
DEBUG - 2011-06-16 14:25:08 --> Input Class Initialized
DEBUG - 2011-06-16 14:25:08 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-16 14:25:08 --> Language Class Initialized
DEBUG - 2011-06-16 14:25:08 --> Loader Class Initialized
DEBUG - 2011-06-16 14:25:08 --> Controller Class Initialized
DEBUG - 2011-06-16 14:25:08 --> Model Class Initialized
DEBUG - 2011-06-16 14:25:08 --> Model Class Initialized
DEBUG - 2011-06-16 14:25:08 --> Model Class Initialized
DEBUG - 2011-06-16 14:25:08 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-16 14:25:08 --> Database Driver Class Initialized
DEBUG - 2011-06-16 14:25:08 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-16 14:25:08 --> Helper loaded: url_helper
DEBUG - 2011-06-16 14:25:08 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-16 14:25:08 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-16 14:25:08 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-16 14:25:08 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-16 14:25:08 --> Final output sent to browser
DEBUG - 2011-06-16 14:25:08 --> Total execution time: 0.0756
DEBUG - 2011-06-16 14:25:09 --> Config Class Initialized
DEBUG - 2011-06-16 14:25:09 --> Hooks Class Initialized
DEBUG - 2011-06-16 14:25:09 --> Utf8 Class Initialized
DEBUG - 2011-06-16 14:25:09 --> UTF-8 Support Enabled
DEBUG - 2011-06-16 14:25:09 --> URI Class Initialized
DEBUG - 2011-06-16 14:25:09 --> Router Class Initialized
DEBUG - 2011-06-16 14:25:09 --> Output Class Initialized
DEBUG - 2011-06-16 14:25:09 --> Input Class Initialized
DEBUG - 2011-06-16 14:25:09 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-16 14:25:09 --> Language Class Initialized
DEBUG - 2011-06-16 14:25:09 --> Loader Class Initialized
DEBUG - 2011-06-16 14:25:09 --> Controller Class Initialized
DEBUG - 2011-06-16 14:25:09 --> Model Class Initialized
DEBUG - 2011-06-16 14:25:09 --> Model Class Initialized
DEBUG - 2011-06-16 14:25:09 --> Model Class Initialized
DEBUG - 2011-06-16 14:25:09 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-16 14:25:09 --> Database Driver Class Initialized
DEBUG - 2011-06-16 14:25:09 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-16 14:25:09 --> Helper loaded: url_helper
DEBUG - 2011-06-16 14:25:09 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-16 14:25:09 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-16 14:25:09 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-16 14:25:09 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-16 14:25:09 --> Final output sent to browser
DEBUG - 2011-06-16 14:25:09 --> Total execution time: 0.1643
DEBUG - 2011-06-16 14:25:38 --> Config Class Initialized
DEBUG - 2011-06-16 14:25:38 --> Hooks Class Initialized
DEBUG - 2011-06-16 14:25:38 --> Utf8 Class Initialized
DEBUG - 2011-06-16 14:25:38 --> UTF-8 Support Enabled
DEBUG - 2011-06-16 14:25:38 --> URI Class Initialized
DEBUG - 2011-06-16 14:25:38 --> Router Class Initialized
DEBUG - 2011-06-16 14:25:38 --> Output Class Initialized
DEBUG - 2011-06-16 14:25:38 --> Input Class Initialized
DEBUG - 2011-06-16 14:25:38 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-16 14:25:38 --> Language Class Initialized
DEBUG - 2011-06-16 14:25:38 --> Loader Class Initialized
DEBUG - 2011-06-16 14:25:38 --> Controller Class Initialized
DEBUG - 2011-06-16 14:25:38 --> Model Class Initialized
DEBUG - 2011-06-16 14:25:38 --> Model Class Initialized
DEBUG - 2011-06-16 14:25:38 --> Model Class Initialized
DEBUG - 2011-06-16 14:25:38 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-16 14:25:38 --> Database Driver Class Initialized
DEBUG - 2011-06-16 14:25:38 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-16 14:25:38 --> Helper loaded: url_helper
DEBUG - 2011-06-16 14:25:38 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-16 14:25:38 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-16 14:25:38 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-16 14:25:38 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-16 14:25:38 --> Final output sent to browser
DEBUG - 2011-06-16 14:25:38 --> Total execution time: 0.0523
DEBUG - 2011-06-16 14:25:45 --> Config Class Initialized
DEBUG - 2011-06-16 14:25:45 --> Hooks Class Initialized
DEBUG - 2011-06-16 14:25:45 --> Utf8 Class Initialized
DEBUG - 2011-06-16 14:25:45 --> UTF-8 Support Enabled
DEBUG - 2011-06-16 14:25:45 --> URI Class Initialized
DEBUG - 2011-06-16 14:25:45 --> Router Class Initialized
DEBUG - 2011-06-16 14:25:45 --> Output Class Initialized
DEBUG - 2011-06-16 14:25:45 --> Input Class Initialized
DEBUG - 2011-06-16 14:25:45 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-16 14:25:45 --> Language Class Initialized
DEBUG - 2011-06-16 14:25:45 --> Loader Class Initialized
DEBUG - 2011-06-16 14:25:45 --> Controller Class Initialized
DEBUG - 2011-06-16 14:25:45 --> Model Class Initialized
DEBUG - 2011-06-16 14:25:45 --> Model Class Initialized
DEBUG - 2011-06-16 14:25:45 --> Model Class Initialized
DEBUG - 2011-06-16 14:25:45 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-16 14:25:45 --> Database Driver Class Initialized
DEBUG - 2011-06-16 14:25:45 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-16 14:25:45 --> Helper loaded: url_helper
DEBUG - 2011-06-16 14:25:45 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-16 14:25:45 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-16 14:25:45 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-16 14:25:45 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-16 14:25:45 --> Final output sent to browser
DEBUG - 2011-06-16 14:25:45 --> Total execution time: 0.0598
DEBUG - 2011-06-16 14:25:50 --> Config Class Initialized
DEBUG - 2011-06-16 14:25:50 --> Hooks Class Initialized
DEBUG - 2011-06-16 14:25:50 --> Utf8 Class Initialized
DEBUG - 2011-06-16 14:25:50 --> UTF-8 Support Enabled
DEBUG - 2011-06-16 14:25:50 --> URI Class Initialized
DEBUG - 2011-06-16 14:25:50 --> Router Class Initialized
DEBUG - 2011-06-16 14:25:50 --> Output Class Initialized
DEBUG - 2011-06-16 14:25:50 --> Input Class Initialized
DEBUG - 2011-06-16 14:25:50 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-16 14:25:50 --> Language Class Initialized
DEBUG - 2011-06-16 14:25:50 --> Loader Class Initialized
DEBUG - 2011-06-16 14:25:50 --> Controller Class Initialized
DEBUG - 2011-06-16 14:25:50 --> Model Class Initialized
DEBUG - 2011-06-16 14:25:50 --> Model Class Initialized
DEBUG - 2011-06-16 14:25:50 --> Model Class Initialized
DEBUG - 2011-06-16 14:25:50 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-16 14:25:50 --> Database Driver Class Initialized
DEBUG - 2011-06-16 14:25:51 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-16 14:25:51 --> Helper loaded: url_helper
DEBUG - 2011-06-16 14:25:51 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-16 14:25:51 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-16 14:25:51 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-16 14:25:51 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-16 14:25:51 --> Final output sent to browser
DEBUG - 2011-06-16 14:25:51 --> Total execution time: 0.6354
DEBUG - 2011-06-16 14:25:56 --> Config Class Initialized
DEBUG - 2011-06-16 14:25:56 --> Hooks Class Initialized
DEBUG - 2011-06-16 14:25:56 --> Utf8 Class Initialized
DEBUG - 2011-06-16 14:25:56 --> UTF-8 Support Enabled
DEBUG - 2011-06-16 14:25:56 --> URI Class Initialized
DEBUG - 2011-06-16 14:25:56 --> Router Class Initialized
DEBUG - 2011-06-16 14:25:56 --> Output Class Initialized
DEBUG - 2011-06-16 14:25:56 --> Input Class Initialized
DEBUG - 2011-06-16 14:25:56 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-16 14:25:56 --> Language Class Initialized
DEBUG - 2011-06-16 14:25:56 --> Loader Class Initialized
DEBUG - 2011-06-16 14:25:56 --> Controller Class Initialized
DEBUG - 2011-06-16 14:25:56 --> Model Class Initialized
DEBUG - 2011-06-16 14:25:56 --> Model Class Initialized
DEBUG - 2011-06-16 14:25:56 --> Model Class Initialized
DEBUG - 2011-06-16 14:25:56 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-16 14:25:56 --> Database Driver Class Initialized
DEBUG - 2011-06-16 14:25:56 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-16 14:25:56 --> Helper loaded: url_helper
DEBUG - 2011-06-16 14:25:56 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-16 14:25:56 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-16 14:25:56 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-16 14:25:56 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-16 14:25:56 --> Final output sent to browser
DEBUG - 2011-06-16 14:25:56 --> Total execution time: 0.0528
DEBUG - 2011-06-16 14:25:57 --> Config Class Initialized
DEBUG - 2011-06-16 14:25:57 --> Hooks Class Initialized
DEBUG - 2011-06-16 14:25:57 --> Utf8 Class Initialized
DEBUG - 2011-06-16 14:25:57 --> UTF-8 Support Enabled
DEBUG - 2011-06-16 14:25:57 --> URI Class Initialized
DEBUG - 2011-06-16 14:25:57 --> Router Class Initialized
DEBUG - 2011-06-16 14:25:57 --> Output Class Initialized
DEBUG - 2011-06-16 14:25:57 --> Input Class Initialized
DEBUG - 2011-06-16 14:25:57 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-16 14:25:57 --> Language Class Initialized
DEBUG - 2011-06-16 14:25:57 --> Loader Class Initialized
DEBUG - 2011-06-16 14:25:57 --> Controller Class Initialized
DEBUG - 2011-06-16 14:25:57 --> Model Class Initialized
DEBUG - 2011-06-16 14:25:57 --> Model Class Initialized
DEBUG - 2011-06-16 14:25:57 --> Model Class Initialized
DEBUG - 2011-06-16 14:25:57 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-16 14:25:57 --> Database Driver Class Initialized
DEBUG - 2011-06-16 14:25:57 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-16 14:25:57 --> Helper loaded: url_helper
DEBUG - 2011-06-16 14:25:57 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-16 14:25:57 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-16 14:25:57 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-16 14:25:57 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-16 14:25:57 --> Final output sent to browser
DEBUG - 2011-06-16 14:25:57 --> Total execution time: 0.6952
DEBUG - 2011-06-16 14:26:04 --> Config Class Initialized
DEBUG - 2011-06-16 14:26:04 --> Hooks Class Initialized
DEBUG - 2011-06-16 14:26:04 --> Utf8 Class Initialized
DEBUG - 2011-06-16 14:26:04 --> UTF-8 Support Enabled
DEBUG - 2011-06-16 14:26:04 --> URI Class Initialized
DEBUG - 2011-06-16 14:26:04 --> Router Class Initialized
DEBUG - 2011-06-16 14:26:04 --> Output Class Initialized
DEBUG - 2011-06-16 14:26:04 --> Input Class Initialized
DEBUG - 2011-06-16 14:26:04 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-16 14:26:04 --> Language Class Initialized
DEBUG - 2011-06-16 14:26:04 --> Loader Class Initialized
DEBUG - 2011-06-16 14:26:04 --> Controller Class Initialized
DEBUG - 2011-06-16 14:26:04 --> Model Class Initialized
DEBUG - 2011-06-16 14:26:04 --> Model Class Initialized
DEBUG - 2011-06-16 14:26:04 --> Model Class Initialized
DEBUG - 2011-06-16 14:26:04 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-16 14:26:04 --> Database Driver Class Initialized
DEBUG - 2011-06-16 14:26:04 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-16 14:26:04 --> Helper loaded: url_helper
DEBUG - 2011-06-16 14:26:04 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-16 14:26:04 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-16 14:26:04 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-16 14:26:04 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-16 14:26:04 --> Final output sent to browser
DEBUG - 2011-06-16 14:26:04 --> Total execution time: 0.5497
DEBUG - 2011-06-16 14:26:11 --> Config Class Initialized
DEBUG - 2011-06-16 14:26:11 --> Hooks Class Initialized
DEBUG - 2011-06-16 14:26:11 --> Utf8 Class Initialized
DEBUG - 2011-06-16 14:26:11 --> UTF-8 Support Enabled
DEBUG - 2011-06-16 14:26:11 --> URI Class Initialized
DEBUG - 2011-06-16 14:26:11 --> Router Class Initialized
DEBUG - 2011-06-16 14:26:11 --> Output Class Initialized
DEBUG - 2011-06-16 14:26:11 --> Input Class Initialized
DEBUG - 2011-06-16 14:26:11 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-16 14:26:11 --> Language Class Initialized
DEBUG - 2011-06-16 14:26:11 --> Loader Class Initialized
DEBUG - 2011-06-16 14:26:11 --> Controller Class Initialized
DEBUG - 2011-06-16 14:26:11 --> Model Class Initialized
DEBUG - 2011-06-16 14:26:11 --> Model Class Initialized
DEBUG - 2011-06-16 14:26:11 --> Model Class Initialized
DEBUG - 2011-06-16 14:26:11 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-16 14:26:11 --> Database Driver Class Initialized
DEBUG - 2011-06-16 14:26:11 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-16 14:26:11 --> Helper loaded: url_helper
DEBUG - 2011-06-16 14:26:11 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-16 14:26:11 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-16 14:26:11 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-16 14:26:11 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-16 14:26:11 --> Final output sent to browser
DEBUG - 2011-06-16 14:26:11 --> Total execution time: 0.1203
DEBUG - 2011-06-16 14:26:12 --> Config Class Initialized
DEBUG - 2011-06-16 14:26:12 --> Hooks Class Initialized
DEBUG - 2011-06-16 14:26:12 --> Utf8 Class Initialized
DEBUG - 2011-06-16 14:26:12 --> UTF-8 Support Enabled
DEBUG - 2011-06-16 14:26:12 --> URI Class Initialized
DEBUG - 2011-06-16 14:26:12 --> Router Class Initialized
DEBUG - 2011-06-16 14:26:12 --> Output Class Initialized
DEBUG - 2011-06-16 14:26:12 --> Input Class Initialized
DEBUG - 2011-06-16 14:26:12 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-16 14:26:12 --> Language Class Initialized
DEBUG - 2011-06-16 14:26:12 --> Loader Class Initialized
DEBUG - 2011-06-16 14:26:12 --> Controller Class Initialized
DEBUG - 2011-06-16 14:26:12 --> Model Class Initialized
DEBUG - 2011-06-16 14:26:12 --> Model Class Initialized
DEBUG - 2011-06-16 14:26:12 --> Model Class Initialized
DEBUG - 2011-06-16 14:26:12 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-16 14:26:12 --> Database Driver Class Initialized
DEBUG - 2011-06-16 14:26:12 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-16 14:26:12 --> Helper loaded: url_helper
DEBUG - 2011-06-16 14:26:12 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-16 14:26:12 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-16 14:26:12 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-16 14:26:12 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-16 14:26:12 --> Final output sent to browser
DEBUG - 2011-06-16 14:26:12 --> Total execution time: 0.1128
DEBUG - 2011-06-16 15:00:07 --> Config Class Initialized
DEBUG - 2011-06-16 15:00:07 --> Hooks Class Initialized
DEBUG - 2011-06-16 15:00:07 --> Utf8 Class Initialized
DEBUG - 2011-06-16 15:00:07 --> UTF-8 Support Enabled
DEBUG - 2011-06-16 15:00:07 --> URI Class Initialized
DEBUG - 2011-06-16 15:00:07 --> Router Class Initialized
DEBUG - 2011-06-16 15:00:07 --> Output Class Initialized
DEBUG - 2011-06-16 15:00:07 --> Input Class Initialized
DEBUG - 2011-06-16 15:00:07 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-16 15:00:07 --> Language Class Initialized
DEBUG - 2011-06-16 15:00:07 --> Loader Class Initialized
DEBUG - 2011-06-16 15:00:07 --> Controller Class Initialized
ERROR - 2011-06-16 15:00:07 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-16 15:00:07 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-16 15:00:07 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-16 15:00:07 --> Model Class Initialized
DEBUG - 2011-06-16 15:00:07 --> Model Class Initialized
DEBUG - 2011-06-16 15:00:07 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-16 15:00:07 --> Database Driver Class Initialized
DEBUG - 2011-06-16 15:00:07 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-16 15:00:07 --> Helper loaded: url_helper
DEBUG - 2011-06-16 15:00:07 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-16 15:00:07 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-16 15:00:07 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-16 15:00:07 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-16 15:00:07 --> Final output sent to browser
DEBUG - 2011-06-16 15:00:07 --> Total execution time: 0.7424
DEBUG - 2011-06-16 15:00:09 --> Config Class Initialized
DEBUG - 2011-06-16 15:00:09 --> Hooks Class Initialized
DEBUG - 2011-06-16 15:00:09 --> Utf8 Class Initialized
DEBUG - 2011-06-16 15:00:09 --> UTF-8 Support Enabled
DEBUG - 2011-06-16 15:00:09 --> URI Class Initialized
DEBUG - 2011-06-16 15:00:09 --> Router Class Initialized
DEBUG - 2011-06-16 15:00:09 --> Output Class Initialized
DEBUG - 2011-06-16 15:00:09 --> Input Class Initialized
DEBUG - 2011-06-16 15:00:09 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-16 15:00:09 --> Language Class Initialized
DEBUG - 2011-06-16 15:00:09 --> Loader Class Initialized
DEBUG - 2011-06-16 15:00:09 --> Controller Class Initialized
DEBUG - 2011-06-16 15:00:10 --> Model Class Initialized
DEBUG - 2011-06-16 15:00:10 --> Model Class Initialized
DEBUG - 2011-06-16 15:00:10 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-16 15:00:10 --> Database Driver Class Initialized
DEBUG - 2011-06-16 15:00:11 --> Final output sent to browser
DEBUG - 2011-06-16 15:00:11 --> Total execution time: 1.1103
DEBUG - 2011-06-16 15:00:12 --> Config Class Initialized
DEBUG - 2011-06-16 15:00:12 --> Hooks Class Initialized
DEBUG - 2011-06-16 15:00:12 --> Utf8 Class Initialized
DEBUG - 2011-06-16 15:00:12 --> UTF-8 Support Enabled
DEBUG - 2011-06-16 15:00:12 --> URI Class Initialized
DEBUG - 2011-06-16 15:00:12 --> Router Class Initialized
ERROR - 2011-06-16 15:00:12 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-16 15:35:05 --> Config Class Initialized
DEBUG - 2011-06-16 15:35:05 --> Hooks Class Initialized
DEBUG - 2011-06-16 15:35:05 --> Utf8 Class Initialized
DEBUG - 2011-06-16 15:35:05 --> UTF-8 Support Enabled
DEBUG - 2011-06-16 15:35:05 --> URI Class Initialized
DEBUG - 2011-06-16 15:35:05 --> Router Class Initialized
DEBUG - 2011-06-16 15:35:06 --> Output Class Initialized
DEBUG - 2011-06-16 15:35:06 --> Input Class Initialized
DEBUG - 2011-06-16 15:35:06 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-16 15:35:06 --> Language Class Initialized
DEBUG - 2011-06-16 15:35:06 --> Loader Class Initialized
DEBUG - 2011-06-16 15:35:06 --> Controller Class Initialized
DEBUG - 2011-06-16 15:35:06 --> Model Class Initialized
DEBUG - 2011-06-16 15:35:06 --> Model Class Initialized
DEBUG - 2011-06-16 15:35:06 --> Model Class Initialized
DEBUG - 2011-06-16 15:35:06 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-16 15:35:06 --> Database Driver Class Initialized
DEBUG - 2011-06-16 15:35:06 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-16 15:35:06 --> Helper loaded: url_helper
DEBUG - 2011-06-16 15:35:06 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-16 15:35:06 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-16 15:35:06 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-16 15:35:06 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-16 15:35:06 --> Final output sent to browser
DEBUG - 2011-06-16 15:35:06 --> Total execution time: 0.9401
DEBUG - 2011-06-16 15:35:08 --> Config Class Initialized
DEBUG - 2011-06-16 15:35:08 --> Hooks Class Initialized
DEBUG - 2011-06-16 15:35:08 --> Utf8 Class Initialized
DEBUG - 2011-06-16 15:35:08 --> UTF-8 Support Enabled
DEBUG - 2011-06-16 15:35:08 --> URI Class Initialized
DEBUG - 2011-06-16 15:35:08 --> Router Class Initialized
DEBUG - 2011-06-16 15:35:08 --> Output Class Initialized
DEBUG - 2011-06-16 15:35:08 --> Input Class Initialized
DEBUG - 2011-06-16 15:35:08 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-16 15:35:08 --> Language Class Initialized
DEBUG - 2011-06-16 15:35:08 --> Loader Class Initialized
DEBUG - 2011-06-16 15:35:08 --> Controller Class Initialized
ERROR - 2011-06-16 15:35:08 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-16 15:35:08 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-16 15:35:08 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-16 15:35:08 --> Model Class Initialized
DEBUG - 2011-06-16 15:35:08 --> Model Class Initialized
DEBUG - 2011-06-16 15:35:08 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-16 15:35:08 --> Database Driver Class Initialized
DEBUG - 2011-06-16 15:35:09 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-16 15:35:09 --> Helper loaded: url_helper
DEBUG - 2011-06-16 15:35:09 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-16 15:35:09 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-16 15:35:09 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-16 15:35:09 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-16 15:35:09 --> Final output sent to browser
DEBUG - 2011-06-16 15:35:09 --> Total execution time: 0.0819
DEBUG - 2011-06-16 15:37:05 --> Config Class Initialized
DEBUG - 2011-06-16 15:37:05 --> Hooks Class Initialized
DEBUG - 2011-06-16 15:37:05 --> Utf8 Class Initialized
DEBUG - 2011-06-16 15:37:05 --> UTF-8 Support Enabled
DEBUG - 2011-06-16 15:37:05 --> URI Class Initialized
DEBUG - 2011-06-16 15:37:05 --> Router Class Initialized
DEBUG - 2011-06-16 15:37:05 --> Output Class Initialized
DEBUG - 2011-06-16 15:37:05 --> Input Class Initialized
DEBUG - 2011-06-16 15:37:05 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-16 15:37:05 --> Language Class Initialized
DEBUG - 2011-06-16 15:37:05 --> Loader Class Initialized
DEBUG - 2011-06-16 15:37:05 --> Controller Class Initialized
DEBUG - 2011-06-16 15:37:05 --> Model Class Initialized
DEBUG - 2011-06-16 15:37:05 --> Model Class Initialized
DEBUG - 2011-06-16 15:37:05 --> Model Class Initialized
DEBUG - 2011-06-16 15:37:05 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-16 15:37:05 --> Database Driver Class Initialized
DEBUG - 2011-06-16 15:37:05 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-16 15:37:05 --> Helper loaded: url_helper
DEBUG - 2011-06-16 15:37:05 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-16 15:37:05 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-16 15:37:05 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-16 15:37:05 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-16 15:37:05 --> Final output sent to browser
DEBUG - 2011-06-16 15:37:05 --> Total execution time: 0.0510
DEBUG - 2011-06-16 15:53:07 --> Config Class Initialized
DEBUG - 2011-06-16 15:53:07 --> Hooks Class Initialized
DEBUG - 2011-06-16 15:53:07 --> Utf8 Class Initialized
DEBUG - 2011-06-16 15:53:07 --> UTF-8 Support Enabled
DEBUG - 2011-06-16 15:53:07 --> URI Class Initialized
DEBUG - 2011-06-16 15:53:07 --> Router Class Initialized
ERROR - 2011-06-16 15:53:07 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-06-16 15:53:23 --> Config Class Initialized
DEBUG - 2011-06-16 15:53:23 --> Hooks Class Initialized
DEBUG - 2011-06-16 15:53:23 --> Utf8 Class Initialized
DEBUG - 2011-06-16 15:53:23 --> UTF-8 Support Enabled
DEBUG - 2011-06-16 15:53:23 --> URI Class Initialized
DEBUG - 2011-06-16 15:53:23 --> Router Class Initialized
DEBUG - 2011-06-16 15:53:23 --> Output Class Initialized
DEBUG - 2011-06-16 15:53:23 --> Input Class Initialized
DEBUG - 2011-06-16 15:53:23 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-16 15:53:23 --> Language Class Initialized
DEBUG - 2011-06-16 15:53:23 --> Loader Class Initialized
DEBUG - 2011-06-16 15:53:23 --> Controller Class Initialized
DEBUG - 2011-06-16 15:53:23 --> Model Class Initialized
DEBUG - 2011-06-16 15:53:23 --> Model Class Initialized
DEBUG - 2011-06-16 15:53:23 --> Model Class Initialized
DEBUG - 2011-06-16 15:53:23 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-16 15:53:23 --> Database Driver Class Initialized
DEBUG - 2011-06-16 15:53:23 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-16 15:53:23 --> Helper loaded: url_helper
DEBUG - 2011-06-16 15:53:23 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-16 15:53:23 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-16 15:53:23 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-16 15:53:23 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-16 15:53:23 --> Final output sent to browser
DEBUG - 2011-06-16 15:53:23 --> Total execution time: 0.0526
DEBUG - 2011-06-16 15:53:28 --> Config Class Initialized
DEBUG - 2011-06-16 15:53:28 --> Hooks Class Initialized
DEBUG - 2011-06-16 15:53:28 --> Utf8 Class Initialized
DEBUG - 2011-06-16 15:53:28 --> UTF-8 Support Enabled
DEBUG - 2011-06-16 15:53:28 --> URI Class Initialized
DEBUG - 2011-06-16 15:53:28 --> Router Class Initialized
DEBUG - 2011-06-16 15:53:28 --> Output Class Initialized
DEBUG - 2011-06-16 15:53:28 --> Input Class Initialized
DEBUG - 2011-06-16 15:53:28 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-16 15:53:28 --> Language Class Initialized
DEBUG - 2011-06-16 15:53:28 --> Loader Class Initialized
DEBUG - 2011-06-16 15:53:28 --> Controller Class Initialized
ERROR - 2011-06-16 15:53:28 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-16 15:53:28 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-16 15:53:28 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-16 15:53:28 --> Model Class Initialized
DEBUG - 2011-06-16 15:53:28 --> Model Class Initialized
DEBUG - 2011-06-16 15:53:28 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-16 15:53:28 --> Database Driver Class Initialized
DEBUG - 2011-06-16 15:53:28 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-16 15:53:28 --> Helper loaded: url_helper
DEBUG - 2011-06-16 15:53:28 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-16 15:53:28 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-16 15:53:28 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-16 15:53:28 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-16 15:53:28 --> Final output sent to browser
DEBUG - 2011-06-16 15:53:28 --> Total execution time: 0.0431
DEBUG - 2011-06-16 17:58:28 --> Config Class Initialized
DEBUG - 2011-06-16 17:58:28 --> Hooks Class Initialized
DEBUG - 2011-06-16 17:58:28 --> Utf8 Class Initialized
DEBUG - 2011-06-16 17:58:28 --> UTF-8 Support Enabled
DEBUG - 2011-06-16 17:58:28 --> URI Class Initialized
DEBUG - 2011-06-16 17:58:28 --> Router Class Initialized
ERROR - 2011-06-16 17:58:28 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-06-16 17:58:28 --> Config Class Initialized
DEBUG - 2011-06-16 17:58:28 --> Hooks Class Initialized
DEBUG - 2011-06-16 17:58:28 --> Utf8 Class Initialized
DEBUG - 2011-06-16 17:58:28 --> UTF-8 Support Enabled
DEBUG - 2011-06-16 17:58:28 --> URI Class Initialized
DEBUG - 2011-06-16 17:58:28 --> Router Class Initialized
DEBUG - 2011-06-16 17:58:28 --> Output Class Initialized
DEBUG - 2011-06-16 17:58:28 --> Input Class Initialized
DEBUG - 2011-06-16 17:58:28 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-16 17:58:28 --> Language Class Initialized
DEBUG - 2011-06-16 17:58:28 --> Loader Class Initialized
DEBUG - 2011-06-16 17:58:28 --> Controller Class Initialized
DEBUG - 2011-06-16 17:58:28 --> Model Class Initialized
DEBUG - 2011-06-16 17:58:28 --> Model Class Initialized
DEBUG - 2011-06-16 17:58:28 --> Model Class Initialized
DEBUG - 2011-06-16 17:58:28 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-16 17:58:28 --> Database Driver Class Initialized
DEBUG - 2011-06-16 17:58:28 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-16 17:58:28 --> Helper loaded: url_helper
DEBUG - 2011-06-16 17:58:28 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-16 17:58:28 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-16 17:58:28 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-16 17:58:28 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-16 17:58:28 --> Final output sent to browser
DEBUG - 2011-06-16 17:58:28 --> Total execution time: 0.5171
DEBUG - 2011-06-16 17:58:59 --> Config Class Initialized
DEBUG - 2011-06-16 17:58:59 --> Hooks Class Initialized
DEBUG - 2011-06-16 17:58:59 --> Utf8 Class Initialized
DEBUG - 2011-06-16 17:58:59 --> UTF-8 Support Enabled
DEBUG - 2011-06-16 17:58:59 --> URI Class Initialized
DEBUG - 2011-06-16 17:58:59 --> Router Class Initialized
DEBUG - 2011-06-16 17:58:59 --> Output Class Initialized
DEBUG - 2011-06-16 17:58:59 --> Input Class Initialized
DEBUG - 2011-06-16 17:58:59 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-16 17:58:59 --> Language Class Initialized
DEBUG - 2011-06-16 17:58:59 --> Loader Class Initialized
DEBUG - 2011-06-16 17:58:59 --> Controller Class Initialized
ERROR - 2011-06-16 17:58:59 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-16 17:58:59 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-16 17:58:59 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-16 17:58:59 --> Model Class Initialized
DEBUG - 2011-06-16 17:58:59 --> Model Class Initialized
DEBUG - 2011-06-16 17:58:59 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-16 17:58:59 --> Database Driver Class Initialized
DEBUG - 2011-06-16 17:58:59 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-16 17:58:59 --> Helper loaded: url_helper
DEBUG - 2011-06-16 17:58:59 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-16 17:58:59 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-16 17:58:59 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-16 17:58:59 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-16 17:58:59 --> Final output sent to browser
DEBUG - 2011-06-16 17:58:59 --> Total execution time: 0.1004
DEBUG - 2011-06-16 18:14:36 --> Config Class Initialized
DEBUG - 2011-06-16 18:14:36 --> Hooks Class Initialized
DEBUG - 2011-06-16 18:14:36 --> Utf8 Class Initialized
DEBUG - 2011-06-16 18:14:36 --> UTF-8 Support Enabled
DEBUG - 2011-06-16 18:14:36 --> URI Class Initialized
DEBUG - 2011-06-16 18:14:36 --> Router Class Initialized
DEBUG - 2011-06-16 18:14:36 --> Output Class Initialized
DEBUG - 2011-06-16 18:14:36 --> Input Class Initialized
DEBUG - 2011-06-16 18:14:36 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-16 18:14:36 --> Language Class Initialized
DEBUG - 2011-06-16 18:14:36 --> Loader Class Initialized
DEBUG - 2011-06-16 18:14:36 --> Controller Class Initialized
DEBUG - 2011-06-16 18:14:36 --> Model Class Initialized
DEBUG - 2011-06-16 18:14:36 --> Model Class Initialized
DEBUG - 2011-06-16 18:14:36 --> Model Class Initialized
DEBUG - 2011-06-16 18:14:36 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-16 18:14:36 --> Database Driver Class Initialized
DEBUG - 2011-06-16 18:14:36 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-16 18:14:36 --> Helper loaded: url_helper
DEBUG - 2011-06-16 18:14:36 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-16 18:14:36 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-16 18:14:36 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-16 18:14:36 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-16 18:14:36 --> Final output sent to browser
DEBUG - 2011-06-16 18:14:36 --> Total execution time: 0.0946
DEBUG - 2011-06-16 18:14:37 --> Config Class Initialized
DEBUG - 2011-06-16 18:14:37 --> Hooks Class Initialized
DEBUG - 2011-06-16 18:14:37 --> Utf8 Class Initialized
DEBUG - 2011-06-16 18:14:37 --> UTF-8 Support Enabled
DEBUG - 2011-06-16 18:14:37 --> URI Class Initialized
DEBUG - 2011-06-16 18:14:37 --> Router Class Initialized
DEBUG - 2011-06-16 18:14:37 --> Output Class Initialized
DEBUG - 2011-06-16 18:14:37 --> Input Class Initialized
DEBUG - 2011-06-16 18:14:37 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-16 18:14:37 --> Language Class Initialized
DEBUG - 2011-06-16 18:14:37 --> Loader Class Initialized
DEBUG - 2011-06-16 18:14:37 --> Controller Class Initialized
ERROR - 2011-06-16 18:14:37 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-16 18:14:37 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-16 18:14:37 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-16 18:14:37 --> Model Class Initialized
DEBUG - 2011-06-16 18:14:37 --> Model Class Initialized
DEBUG - 2011-06-16 18:14:37 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-16 18:14:37 --> Database Driver Class Initialized
DEBUG - 2011-06-16 18:14:37 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-16 18:14:37 --> Helper loaded: url_helper
DEBUG - 2011-06-16 18:14:37 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-16 18:14:37 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-16 18:14:37 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-16 18:14:37 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-16 18:14:37 --> Final output sent to browser
DEBUG - 2011-06-16 18:14:37 --> Total execution time: 0.0399
DEBUG - 2011-06-16 18:29:36 --> Config Class Initialized
DEBUG - 2011-06-16 18:29:36 --> Hooks Class Initialized
DEBUG - 2011-06-16 18:29:36 --> Utf8 Class Initialized
DEBUG - 2011-06-16 18:29:36 --> UTF-8 Support Enabled
DEBUG - 2011-06-16 18:29:36 --> URI Class Initialized
DEBUG - 2011-06-16 18:29:36 --> Router Class Initialized
ERROR - 2011-06-16 18:29:36 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-06-16 19:11:38 --> Config Class Initialized
DEBUG - 2011-06-16 19:11:39 --> Hooks Class Initialized
DEBUG - 2011-06-16 19:11:39 --> Utf8 Class Initialized
DEBUG - 2011-06-16 19:11:39 --> UTF-8 Support Enabled
DEBUG - 2011-06-16 19:11:39 --> URI Class Initialized
DEBUG - 2011-06-16 19:11:39 --> Router Class Initialized
DEBUG - 2011-06-16 19:11:39 --> Output Class Initialized
DEBUG - 2011-06-16 19:11:39 --> Input Class Initialized
DEBUG - 2011-06-16 19:11:39 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-16 19:11:39 --> Language Class Initialized
DEBUG - 2011-06-16 19:11:39 --> Loader Class Initialized
DEBUG - 2011-06-16 19:11:39 --> Controller Class Initialized
ERROR - 2011-06-16 19:11:39 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-16 19:11:39 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-16 19:11:39 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-16 19:11:39 --> Model Class Initialized
DEBUG - 2011-06-16 19:11:39 --> Model Class Initialized
DEBUG - 2011-06-16 19:11:39 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-16 19:11:39 --> Database Driver Class Initialized
DEBUG - 2011-06-16 19:11:39 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-16 19:11:39 --> Helper loaded: url_helper
DEBUG - 2011-06-16 19:11:39 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-16 19:11:39 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-16 19:11:39 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-16 19:11:39 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-16 19:11:39 --> Final output sent to browser
DEBUG - 2011-06-16 19:11:39 --> Total execution time: 0.9935
DEBUG - 2011-06-16 19:11:40 --> Config Class Initialized
DEBUG - 2011-06-16 19:11:40 --> Hooks Class Initialized
DEBUG - 2011-06-16 19:11:40 --> Utf8 Class Initialized
DEBUG - 2011-06-16 19:11:40 --> UTF-8 Support Enabled
DEBUG - 2011-06-16 19:11:40 --> URI Class Initialized
DEBUG - 2011-06-16 19:11:40 --> Router Class Initialized
DEBUG - 2011-06-16 19:11:40 --> Output Class Initialized
DEBUG - 2011-06-16 19:11:40 --> Input Class Initialized
DEBUG - 2011-06-16 19:11:40 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-16 19:11:40 --> Language Class Initialized
DEBUG - 2011-06-16 19:11:40 --> Loader Class Initialized
DEBUG - 2011-06-16 19:11:40 --> Controller Class Initialized
DEBUG - 2011-06-16 19:11:40 --> Model Class Initialized
DEBUG - 2011-06-16 19:11:40 --> Model Class Initialized
DEBUG - 2011-06-16 19:11:40 --> Model Class Initialized
DEBUG - 2011-06-16 19:11:40 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-16 19:11:40 --> Database Driver Class Initialized
DEBUG - 2011-06-16 19:11:41 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-16 19:11:41 --> Helper loaded: url_helper
DEBUG - 2011-06-16 19:11:41 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-16 19:11:41 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-16 19:11:41 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-16 19:11:41 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-16 19:11:41 --> Final output sent to browser
DEBUG - 2011-06-16 19:11:41 --> Total execution time: 0.7198
DEBUG - 2011-06-16 19:51:35 --> Config Class Initialized
DEBUG - 2011-06-16 19:51:35 --> Hooks Class Initialized
DEBUG - 2011-06-16 19:51:35 --> Utf8 Class Initialized
DEBUG - 2011-06-16 19:51:35 --> UTF-8 Support Enabled
DEBUG - 2011-06-16 19:51:35 --> URI Class Initialized
DEBUG - 2011-06-16 19:51:35 --> Router Class Initialized
DEBUG - 2011-06-16 19:51:35 --> No URI present. Default controller set.
DEBUG - 2011-06-16 19:51:35 --> Output Class Initialized
DEBUG - 2011-06-16 19:51:35 --> Input Class Initialized
DEBUG - 2011-06-16 19:51:35 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-16 19:51:35 --> Language Class Initialized
DEBUG - 2011-06-16 19:51:35 --> Loader Class Initialized
DEBUG - 2011-06-16 19:51:35 --> Controller Class Initialized
DEBUG - 2011-06-16 19:51:35 --> File loaded: application/views/splash/main.php
DEBUG - 2011-06-16 19:51:35 --> Helper loaded: url_helper
DEBUG - 2011-06-16 19:51:35 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-16 19:51:35 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-16 19:51:35 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-16 19:51:35 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-16 19:51:35 --> Final output sent to browser
DEBUG - 2011-06-16 19:51:35 --> Total execution time: 0.1662
DEBUG - 2011-06-16 20:48:23 --> Config Class Initialized
DEBUG - 2011-06-16 20:48:23 --> Hooks Class Initialized
DEBUG - 2011-06-16 20:48:23 --> Utf8 Class Initialized
DEBUG - 2011-06-16 20:48:23 --> UTF-8 Support Enabled
DEBUG - 2011-06-16 20:48:23 --> URI Class Initialized
DEBUG - 2011-06-16 20:48:23 --> Router Class Initialized
DEBUG - 2011-06-16 20:48:23 --> Output Class Initialized
DEBUG - 2011-06-16 20:48:23 --> Input Class Initialized
DEBUG - 2011-06-16 20:48:23 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-16 20:48:23 --> Language Class Initialized
DEBUG - 2011-06-16 20:48:23 --> Loader Class Initialized
DEBUG - 2011-06-16 20:48:23 --> Controller Class Initialized
ERROR - 2011-06-16 20:48:23 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-16 20:48:23 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-16 20:48:23 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-16 20:48:23 --> Model Class Initialized
DEBUG - 2011-06-16 20:48:23 --> Model Class Initialized
DEBUG - 2011-06-16 20:48:23 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-16 20:48:23 --> Database Driver Class Initialized
DEBUG - 2011-06-16 20:48:23 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-16 20:48:23 --> Helper loaded: url_helper
DEBUG - 2011-06-16 20:48:23 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-16 20:48:23 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-16 20:48:23 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-16 20:48:23 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-16 20:48:23 --> Final output sent to browser
DEBUG - 2011-06-16 20:48:23 --> Total execution time: 0.4829
DEBUG - 2011-06-16 20:48:23 --> Config Class Initialized
DEBUG - 2011-06-16 20:48:23 --> Hooks Class Initialized
DEBUG - 2011-06-16 20:48:23 --> Utf8 Class Initialized
DEBUG - 2011-06-16 20:48:23 --> UTF-8 Support Enabled
DEBUG - 2011-06-16 20:48:23 --> URI Class Initialized
DEBUG - 2011-06-16 20:48:23 --> Router Class Initialized
DEBUG - 2011-06-16 20:48:23 --> Output Class Initialized
DEBUG - 2011-06-16 20:48:23 --> Input Class Initialized
DEBUG - 2011-06-16 20:48:23 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-16 20:48:23 --> Language Class Initialized
DEBUG - 2011-06-16 20:48:23 --> Loader Class Initialized
DEBUG - 2011-06-16 20:48:23 --> Controller Class Initialized
ERROR - 2011-06-16 20:48:23 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-16 20:48:23 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-16 20:48:23 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-16 20:48:23 --> Model Class Initialized
DEBUG - 2011-06-16 20:48:23 --> Model Class Initialized
DEBUG - 2011-06-16 20:48:23 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-16 20:48:23 --> Database Driver Class Initialized
DEBUG - 2011-06-16 20:48:23 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-16 20:48:23 --> Helper loaded: url_helper
DEBUG - 2011-06-16 20:48:23 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-16 20:48:23 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-16 20:48:23 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-16 20:48:23 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-16 20:48:23 --> Final output sent to browser
DEBUG - 2011-06-16 20:48:23 --> Total execution time: 0.0297
DEBUG - 2011-06-16 20:48:26 --> Config Class Initialized
DEBUG - 2011-06-16 20:48:26 --> Hooks Class Initialized
DEBUG - 2011-06-16 20:48:26 --> Utf8 Class Initialized
DEBUG - 2011-06-16 20:48:26 --> UTF-8 Support Enabled
DEBUG - 2011-06-16 20:48:26 --> URI Class Initialized
DEBUG - 2011-06-16 20:48:26 --> Router Class Initialized
DEBUG - 2011-06-16 20:48:26 --> Output Class Initialized
DEBUG - 2011-06-16 20:48:26 --> Input Class Initialized
DEBUG - 2011-06-16 20:48:26 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-16 20:48:26 --> Language Class Initialized
DEBUG - 2011-06-16 20:48:26 --> Loader Class Initialized
DEBUG - 2011-06-16 20:48:26 --> Controller Class Initialized
DEBUG - 2011-06-16 20:48:26 --> Model Class Initialized
DEBUG - 2011-06-16 20:48:26 --> Model Class Initialized
DEBUG - 2011-06-16 20:48:26 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-16 20:48:26 --> Database Driver Class Initialized
DEBUG - 2011-06-16 20:48:27 --> Final output sent to browser
DEBUG - 2011-06-16 20:48:27 --> Total execution time: 0.9726
DEBUG - 2011-06-16 20:48:29 --> Config Class Initialized
DEBUG - 2011-06-16 20:48:29 --> Hooks Class Initialized
DEBUG - 2011-06-16 20:48:29 --> Utf8 Class Initialized
DEBUG - 2011-06-16 20:48:29 --> UTF-8 Support Enabled
DEBUG - 2011-06-16 20:48:29 --> URI Class Initialized
DEBUG - 2011-06-16 20:48:29 --> Router Class Initialized
ERROR - 2011-06-16 20:48:29 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-16 20:55:06 --> Config Class Initialized
DEBUG - 2011-06-16 20:55:06 --> Hooks Class Initialized
DEBUG - 2011-06-16 20:55:06 --> Utf8 Class Initialized
DEBUG - 2011-06-16 20:55:06 --> UTF-8 Support Enabled
DEBUG - 2011-06-16 20:55:06 --> URI Class Initialized
DEBUG - 2011-06-16 20:55:06 --> Router Class Initialized
DEBUG - 2011-06-16 20:55:06 --> Output Class Initialized
DEBUG - 2011-06-16 20:55:06 --> Input Class Initialized
DEBUG - 2011-06-16 20:55:06 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-16 20:55:06 --> Language Class Initialized
DEBUG - 2011-06-16 20:55:06 --> Loader Class Initialized
DEBUG - 2011-06-16 20:55:06 --> Controller Class Initialized
DEBUG - 2011-06-16 20:55:06 --> Model Class Initialized
DEBUG - 2011-06-16 20:55:06 --> Model Class Initialized
DEBUG - 2011-06-16 20:55:06 --> Model Class Initialized
DEBUG - 2011-06-16 20:55:06 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-16 20:55:06 --> Database Driver Class Initialized
DEBUG - 2011-06-16 20:55:07 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-16 20:55:07 --> Helper loaded: url_helper
DEBUG - 2011-06-16 20:55:07 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-16 20:55:07 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-16 20:55:07 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-16 20:55:07 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-16 20:55:07 --> Final output sent to browser
DEBUG - 2011-06-16 20:55:07 --> Total execution time: 0.3157
DEBUG - 2011-06-16 20:55:07 --> Config Class Initialized
DEBUG - 2011-06-16 20:55:07 --> Hooks Class Initialized
DEBUG - 2011-06-16 20:55:07 --> Utf8 Class Initialized
DEBUG - 2011-06-16 20:55:07 --> UTF-8 Support Enabled
DEBUG - 2011-06-16 20:55:07 --> URI Class Initialized
DEBUG - 2011-06-16 20:55:07 --> Router Class Initialized
DEBUG - 2011-06-16 20:55:07 --> Output Class Initialized
DEBUG - 2011-06-16 20:55:07 --> Input Class Initialized
DEBUG - 2011-06-16 20:55:07 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-16 20:55:07 --> Language Class Initialized
DEBUG - 2011-06-16 20:55:07 --> Loader Class Initialized
DEBUG - 2011-06-16 20:55:07 --> Controller Class Initialized
ERROR - 2011-06-16 20:55:07 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-16 20:55:07 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-16 20:55:07 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-16 20:55:07 --> Model Class Initialized
DEBUG - 2011-06-16 20:55:07 --> Model Class Initialized
DEBUG - 2011-06-16 20:55:07 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-16 20:55:07 --> Database Driver Class Initialized
DEBUG - 2011-06-16 20:55:07 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-16 20:55:07 --> Helper loaded: url_helper
DEBUG - 2011-06-16 20:55:07 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-16 20:55:07 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-16 20:55:07 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-16 20:55:07 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-16 20:55:07 --> Final output sent to browser
DEBUG - 2011-06-16 20:55:07 --> Total execution time: 0.0262
DEBUG - 2011-06-16 22:52:17 --> Config Class Initialized
DEBUG - 2011-06-16 22:52:17 --> Hooks Class Initialized
DEBUG - 2011-06-16 22:52:17 --> Utf8 Class Initialized
DEBUG - 2011-06-16 22:52:17 --> UTF-8 Support Enabled
DEBUG - 2011-06-16 22:52:17 --> URI Class Initialized
DEBUG - 2011-06-16 22:52:17 --> Router Class Initialized
DEBUG - 2011-06-16 22:52:17 --> Output Class Initialized
DEBUG - 2011-06-16 22:52:17 --> Input Class Initialized
DEBUG - 2011-06-16 22:52:17 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-16 22:52:17 --> Language Class Initialized
DEBUG - 2011-06-16 22:52:17 --> Loader Class Initialized
DEBUG - 2011-06-16 22:52:18 --> Controller Class Initialized
ERROR - 2011-06-16 22:52:18 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-16 22:52:18 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-16 22:52:18 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-16 22:52:18 --> Model Class Initialized
DEBUG - 2011-06-16 22:52:18 --> Model Class Initialized
DEBUG - 2011-06-16 22:52:18 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-16 22:52:18 --> Database Driver Class Initialized
DEBUG - 2011-06-16 22:52:18 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-16 22:52:18 --> Helper loaded: url_helper
DEBUG - 2011-06-16 22:52:18 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-16 22:52:18 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-16 22:52:18 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-16 22:52:18 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-16 22:52:18 --> Final output sent to browser
DEBUG - 2011-06-16 22:52:18 --> Total execution time: 0.4331
DEBUG - 2011-06-16 23:32:21 --> Config Class Initialized
DEBUG - 2011-06-16 23:32:21 --> Hooks Class Initialized
DEBUG - 2011-06-16 23:32:21 --> Utf8 Class Initialized
DEBUG - 2011-06-16 23:32:21 --> UTF-8 Support Enabled
DEBUG - 2011-06-16 23:32:21 --> URI Class Initialized
DEBUG - 2011-06-16 23:32:21 --> Router Class Initialized
DEBUG - 2011-06-16 23:32:21 --> Output Class Initialized
DEBUG - 2011-06-16 23:32:21 --> Input Class Initialized
DEBUG - 2011-06-16 23:32:21 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-16 23:32:22 --> Language Class Initialized
DEBUG - 2011-06-16 23:32:22 --> Loader Class Initialized
DEBUG - 2011-06-16 23:32:22 --> Controller Class Initialized
DEBUG - 2011-06-16 23:32:22 --> Model Class Initialized
DEBUG - 2011-06-16 23:32:22 --> Model Class Initialized
DEBUG - 2011-06-16 23:32:22 --> Model Class Initialized
DEBUG - 2011-06-16 23:32:22 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-16 23:32:23 --> Database Driver Class Initialized
DEBUG - 2011-06-16 23:32:24 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-16 23:32:24 --> Helper loaded: url_helper
DEBUG - 2011-06-16 23:32:24 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-16 23:32:24 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-16 23:32:24 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-16 23:32:24 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-16 23:32:24 --> Final output sent to browser
DEBUG - 2011-06-16 23:32:24 --> Total execution time: 3.1809
DEBUG - 2011-06-16 23:32:25 --> Config Class Initialized
DEBUG - 2011-06-16 23:32:25 --> Hooks Class Initialized
DEBUG - 2011-06-16 23:32:25 --> Utf8 Class Initialized
DEBUG - 2011-06-16 23:32:25 --> UTF-8 Support Enabled
DEBUG - 2011-06-16 23:32:25 --> URI Class Initialized
DEBUG - 2011-06-16 23:32:25 --> Router Class Initialized
DEBUG - 2011-06-16 23:32:25 --> Output Class Initialized
DEBUG - 2011-06-16 23:32:25 --> Input Class Initialized
DEBUG - 2011-06-16 23:32:25 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-16 23:32:25 --> Language Class Initialized
DEBUG - 2011-06-16 23:32:26 --> Loader Class Initialized
DEBUG - 2011-06-16 23:32:26 --> Controller Class Initialized
ERROR - 2011-06-16 23:32:26 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-16 23:32:26 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-16 23:32:26 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-16 23:32:26 --> Model Class Initialized
DEBUG - 2011-06-16 23:32:26 --> Model Class Initialized
DEBUG - 2011-06-16 23:32:26 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-16 23:32:26 --> Database Driver Class Initialized
DEBUG - 2011-06-16 23:32:26 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-16 23:32:26 --> Helper loaded: url_helper
DEBUG - 2011-06-16 23:32:26 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-16 23:32:26 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-16 23:32:26 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-16 23:32:26 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-16 23:32:26 --> Final output sent to browser
DEBUG - 2011-06-16 23:32:26 --> Total execution time: 0.7057

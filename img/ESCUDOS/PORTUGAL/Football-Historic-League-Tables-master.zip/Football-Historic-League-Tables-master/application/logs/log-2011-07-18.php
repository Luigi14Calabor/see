<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2011-07-18 00:24:46 --> Config Class Initialized
DEBUG - 2011-07-18 00:24:46 --> Hooks Class Initialized
DEBUG - 2011-07-18 00:24:46 --> Utf8 Class Initialized
DEBUG - 2011-07-18 00:24:46 --> UTF-8 Support Enabled
DEBUG - 2011-07-18 00:24:46 --> URI Class Initialized
DEBUG - 2011-07-18 00:24:46 --> Router Class Initialized
DEBUG - 2011-07-18 00:24:46 --> Output Class Initialized
DEBUG - 2011-07-18 00:24:46 --> Input Class Initialized
DEBUG - 2011-07-18 00:24:46 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-18 00:24:46 --> Language Class Initialized
DEBUG - 2011-07-18 00:24:46 --> Loader Class Initialized
DEBUG - 2011-07-18 00:24:46 --> Controller Class Initialized
DEBUG - 2011-07-18 00:24:46 --> Model Class Initialized
DEBUG - 2011-07-18 00:24:46 --> Model Class Initialized
DEBUG - 2011-07-18 00:24:46 --> Model Class Initialized
DEBUG - 2011-07-18 00:24:46 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-18 00:24:46 --> Database Driver Class Initialized
DEBUG - 2011-07-18 00:24:47 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-18 00:24:47 --> Helper loaded: url_helper
DEBUG - 2011-07-18 00:24:47 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-18 00:24:47 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-18 00:24:47 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-18 00:24:47 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-18 00:24:47 --> Final output sent to browser
DEBUG - 2011-07-18 00:24:47 --> Total execution time: 1.5568
DEBUG - 2011-07-18 00:24:50 --> Config Class Initialized
DEBUG - 2011-07-18 00:24:50 --> Hooks Class Initialized
DEBUG - 2011-07-18 00:24:50 --> Utf8 Class Initialized
DEBUG - 2011-07-18 00:24:50 --> UTF-8 Support Enabled
DEBUG - 2011-07-18 00:24:50 --> URI Class Initialized
DEBUG - 2011-07-18 00:24:50 --> Router Class Initialized
ERROR - 2011-07-18 00:24:50 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-18 00:24:50 --> Config Class Initialized
DEBUG - 2011-07-18 00:24:50 --> Hooks Class Initialized
DEBUG - 2011-07-18 00:24:50 --> Utf8 Class Initialized
DEBUG - 2011-07-18 00:24:50 --> UTF-8 Support Enabled
DEBUG - 2011-07-18 00:24:50 --> URI Class Initialized
DEBUG - 2011-07-18 00:24:50 --> Router Class Initialized
ERROR - 2011-07-18 00:24:50 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-18 00:24:50 --> Config Class Initialized
DEBUG - 2011-07-18 00:24:50 --> Hooks Class Initialized
DEBUG - 2011-07-18 00:24:50 --> Utf8 Class Initialized
DEBUG - 2011-07-18 00:24:50 --> UTF-8 Support Enabled
DEBUG - 2011-07-18 00:24:50 --> URI Class Initialized
DEBUG - 2011-07-18 00:24:50 --> Router Class Initialized
ERROR - 2011-07-18 00:24:50 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-18 02:05:53 --> Config Class Initialized
DEBUG - 2011-07-18 02:05:53 --> Hooks Class Initialized
DEBUG - 2011-07-18 02:05:53 --> Utf8 Class Initialized
DEBUG - 2011-07-18 02:05:53 --> UTF-8 Support Enabled
DEBUG - 2011-07-18 02:05:53 --> URI Class Initialized
DEBUG - 2011-07-18 02:05:53 --> Router Class Initialized
DEBUG - 2011-07-18 02:05:53 --> No URI present. Default controller set.
DEBUG - 2011-07-18 02:05:53 --> Output Class Initialized
DEBUG - 2011-07-18 02:05:53 --> Input Class Initialized
DEBUG - 2011-07-18 02:05:53 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-18 02:05:53 --> Language Class Initialized
DEBUG - 2011-07-18 02:05:53 --> Loader Class Initialized
DEBUG - 2011-07-18 02:05:53 --> Controller Class Initialized
DEBUG - 2011-07-18 02:05:53 --> File loaded: application/views/splash/main.php
DEBUG - 2011-07-18 02:05:53 --> Helper loaded: url_helper
DEBUG - 2011-07-18 02:05:53 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-18 02:05:53 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-18 02:05:53 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-18 02:05:53 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-18 02:05:53 --> Final output sent to browser
DEBUG - 2011-07-18 02:05:53 --> Total execution time: 0.2238
DEBUG - 2011-07-18 03:04:27 --> Config Class Initialized
DEBUG - 2011-07-18 03:04:27 --> Hooks Class Initialized
DEBUG - 2011-07-18 03:04:27 --> Utf8 Class Initialized
DEBUG - 2011-07-18 03:04:27 --> UTF-8 Support Enabled
DEBUG - 2011-07-18 03:04:27 --> URI Class Initialized
DEBUG - 2011-07-18 03:04:27 --> Router Class Initialized
DEBUG - 2011-07-18 03:04:27 --> No URI present. Default controller set.
DEBUG - 2011-07-18 03:04:27 --> Output Class Initialized
DEBUG - 2011-07-18 03:04:27 --> Input Class Initialized
DEBUG - 2011-07-18 03:04:27 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-18 03:04:27 --> Language Class Initialized
DEBUG - 2011-07-18 03:04:27 --> Loader Class Initialized
DEBUG - 2011-07-18 03:04:27 --> Controller Class Initialized
DEBUG - 2011-07-18 03:04:27 --> File loaded: application/views/splash/main.php
DEBUG - 2011-07-18 03:04:27 --> Helper loaded: url_helper
DEBUG - 2011-07-18 03:04:27 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-18 03:04:27 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-18 03:04:27 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-18 03:04:27 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-18 03:04:27 --> Final output sent to browser
DEBUG - 2011-07-18 03:04:27 --> Total execution time: 0.2468
DEBUG - 2011-07-18 03:09:59 --> Config Class Initialized
DEBUG - 2011-07-18 03:09:59 --> Hooks Class Initialized
DEBUG - 2011-07-18 03:09:59 --> Utf8 Class Initialized
DEBUG - 2011-07-18 03:09:59 --> UTF-8 Support Enabled
DEBUG - 2011-07-18 03:09:59 --> URI Class Initialized
DEBUG - 2011-07-18 03:09:59 --> Router Class Initialized
DEBUG - 2011-07-18 03:09:59 --> Output Class Initialized
DEBUG - 2011-07-18 03:09:59 --> Input Class Initialized
DEBUG - 2011-07-18 03:09:59 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-18 03:09:59 --> Language Class Initialized
DEBUG - 2011-07-18 03:09:59 --> Loader Class Initialized
DEBUG - 2011-07-18 03:09:59 --> Controller Class Initialized
DEBUG - 2011-07-18 03:09:59 --> Model Class Initialized
DEBUG - 2011-07-18 03:09:59 --> Model Class Initialized
DEBUG - 2011-07-18 03:09:59 --> Model Class Initialized
DEBUG - 2011-07-18 03:09:59 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-18 03:09:59 --> Database Driver Class Initialized
DEBUG - 2011-07-18 03:10:00 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-18 03:10:00 --> Helper loaded: url_helper
DEBUG - 2011-07-18 03:10:00 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-18 03:10:00 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-18 03:10:00 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-18 03:10:00 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-18 03:10:00 --> Final output sent to browser
DEBUG - 2011-07-18 03:10:00 --> Total execution time: 0.6126
DEBUG - 2011-07-18 03:12:54 --> Config Class Initialized
DEBUG - 2011-07-18 03:12:54 --> Hooks Class Initialized
DEBUG - 2011-07-18 03:12:54 --> Utf8 Class Initialized
DEBUG - 2011-07-18 03:12:54 --> UTF-8 Support Enabled
DEBUG - 2011-07-18 03:12:54 --> URI Class Initialized
DEBUG - 2011-07-18 03:12:54 --> Router Class Initialized
DEBUG - 2011-07-18 03:12:54 --> Output Class Initialized
DEBUG - 2011-07-18 03:12:54 --> Input Class Initialized
DEBUG - 2011-07-18 03:12:54 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-18 03:12:54 --> Language Class Initialized
DEBUG - 2011-07-18 03:12:54 --> Loader Class Initialized
DEBUG - 2011-07-18 03:12:54 --> Controller Class Initialized
ERROR - 2011-07-18 03:12:54 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-18 03:12:54 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-18 03:12:54 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-18 03:12:54 --> Model Class Initialized
DEBUG - 2011-07-18 03:12:54 --> Model Class Initialized
DEBUG - 2011-07-18 03:12:54 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-18 03:12:54 --> Database Driver Class Initialized
DEBUG - 2011-07-18 03:12:54 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-18 03:12:54 --> Helper loaded: url_helper
DEBUG - 2011-07-18 03:12:54 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-18 03:12:54 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-18 03:12:54 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-18 03:12:54 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-18 03:12:54 --> Final output sent to browser
DEBUG - 2011-07-18 03:12:54 --> Total execution time: 0.1000
DEBUG - 2011-07-18 04:09:17 --> Config Class Initialized
DEBUG - 2011-07-18 04:09:17 --> Hooks Class Initialized
DEBUG - 2011-07-18 04:09:18 --> Utf8 Class Initialized
DEBUG - 2011-07-18 04:09:18 --> UTF-8 Support Enabled
DEBUG - 2011-07-18 04:09:18 --> URI Class Initialized
DEBUG - 2011-07-18 04:09:18 --> Router Class Initialized
DEBUG - 2011-07-18 04:09:18 --> No URI present. Default controller set.
DEBUG - 2011-07-18 04:09:18 --> Output Class Initialized
DEBUG - 2011-07-18 04:09:18 --> Input Class Initialized
DEBUG - 2011-07-18 04:09:18 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-18 04:09:18 --> Language Class Initialized
DEBUG - 2011-07-18 04:09:18 --> Loader Class Initialized
DEBUG - 2011-07-18 04:09:18 --> Controller Class Initialized
DEBUG - 2011-07-18 04:09:19 --> File loaded: application/views/splash/main.php
DEBUG - 2011-07-18 04:09:20 --> Helper loaded: url_helper
DEBUG - 2011-07-18 04:09:20 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-18 04:09:20 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-18 04:09:20 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-18 04:09:20 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-18 04:09:20 --> Final output sent to browser
DEBUG - 2011-07-18 04:09:20 --> Total execution time: 3.0820
DEBUG - 2011-07-18 04:09:23 --> Config Class Initialized
DEBUG - 2011-07-18 04:09:23 --> Hooks Class Initialized
DEBUG - 2011-07-18 04:09:23 --> Utf8 Class Initialized
DEBUG - 2011-07-18 04:09:23 --> UTF-8 Support Enabled
DEBUG - 2011-07-18 04:09:23 --> URI Class Initialized
DEBUG - 2011-07-18 04:09:23 --> Router Class Initialized
ERROR - 2011-07-18 04:09:24 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-18 04:09:30 --> Config Class Initialized
DEBUG - 2011-07-18 04:09:30 --> Hooks Class Initialized
DEBUG - 2011-07-18 04:09:30 --> Utf8 Class Initialized
DEBUG - 2011-07-18 04:09:30 --> UTF-8 Support Enabled
DEBUG - 2011-07-18 04:09:30 --> URI Class Initialized
DEBUG - 2011-07-18 04:09:30 --> Router Class Initialized
DEBUG - 2011-07-18 04:09:30 --> Output Class Initialized
DEBUG - 2011-07-18 04:09:30 --> Input Class Initialized
DEBUG - 2011-07-18 04:09:30 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-18 04:09:30 --> Language Class Initialized
DEBUG - 2011-07-18 04:09:31 --> Loader Class Initialized
DEBUG - 2011-07-18 04:09:31 --> Controller Class Initialized
DEBUG - 2011-07-18 04:09:31 --> Model Class Initialized
DEBUG - 2011-07-18 04:09:31 --> Model Class Initialized
DEBUG - 2011-07-18 04:09:31 --> Model Class Initialized
DEBUG - 2011-07-18 04:09:31 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-18 04:09:31 --> Database Driver Class Initialized
DEBUG - 2011-07-18 04:09:31 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-18 04:09:31 --> Helper loaded: url_helper
DEBUG - 2011-07-18 04:09:31 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-18 04:09:31 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-18 04:09:31 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-18 04:09:31 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-18 04:09:31 --> Final output sent to browser
DEBUG - 2011-07-18 04:09:31 --> Total execution time: 0.8127
DEBUG - 2011-07-18 04:10:02 --> Config Class Initialized
DEBUG - 2011-07-18 04:10:02 --> Hooks Class Initialized
DEBUG - 2011-07-18 04:10:03 --> Utf8 Class Initialized
DEBUG - 2011-07-18 04:10:03 --> UTF-8 Support Enabled
DEBUG - 2011-07-18 04:10:03 --> URI Class Initialized
DEBUG - 2011-07-18 04:10:03 --> Router Class Initialized
DEBUG - 2011-07-18 04:10:03 --> No URI present. Default controller set.
DEBUG - 2011-07-18 04:10:03 --> Output Class Initialized
DEBUG - 2011-07-18 04:10:03 --> Input Class Initialized
DEBUG - 2011-07-18 04:10:03 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-18 04:10:03 --> Language Class Initialized
DEBUG - 2011-07-18 04:10:03 --> Loader Class Initialized
DEBUG - 2011-07-18 04:10:03 --> Controller Class Initialized
DEBUG - 2011-07-18 04:10:03 --> File loaded: application/views/splash/main.php
DEBUG - 2011-07-18 04:10:03 --> Helper loaded: url_helper
DEBUG - 2011-07-18 04:10:03 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-18 04:10:03 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-18 04:10:03 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-18 04:10:03 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-18 04:10:03 --> Final output sent to browser
DEBUG - 2011-07-18 04:10:03 --> Total execution time: 0.1142
DEBUG - 2011-07-18 04:10:06 --> Config Class Initialized
DEBUG - 2011-07-18 04:10:06 --> Hooks Class Initialized
DEBUG - 2011-07-18 04:10:06 --> Utf8 Class Initialized
DEBUG - 2011-07-18 04:10:06 --> UTF-8 Support Enabled
DEBUG - 2011-07-18 04:10:06 --> URI Class Initialized
DEBUG - 2011-07-18 04:10:06 --> Router Class Initialized
DEBUG - 2011-07-18 04:10:06 --> Output Class Initialized
DEBUG - 2011-07-18 04:10:06 --> Input Class Initialized
DEBUG - 2011-07-18 04:10:06 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-18 04:10:06 --> Language Class Initialized
DEBUG - 2011-07-18 04:10:06 --> Loader Class Initialized
DEBUG - 2011-07-18 04:10:06 --> Controller Class Initialized
ERROR - 2011-07-18 04:10:06 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-18 04:10:06 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-18 04:10:06 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-18 04:10:06 --> Model Class Initialized
DEBUG - 2011-07-18 04:10:06 --> Model Class Initialized
DEBUG - 2011-07-18 04:10:06 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-18 04:10:06 --> Database Driver Class Initialized
DEBUG - 2011-07-18 04:10:06 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-18 04:10:06 --> Helper loaded: url_helper
DEBUG - 2011-07-18 04:10:06 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-18 04:10:06 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-18 04:10:06 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-18 04:10:06 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-18 04:10:06 --> Final output sent to browser
DEBUG - 2011-07-18 04:10:06 --> Total execution time: 0.7285
DEBUG - 2011-07-18 04:10:09 --> Config Class Initialized
DEBUG - 2011-07-18 04:10:09 --> Hooks Class Initialized
DEBUG - 2011-07-18 04:10:09 --> Utf8 Class Initialized
DEBUG - 2011-07-18 04:10:09 --> UTF-8 Support Enabled
DEBUG - 2011-07-18 04:10:09 --> URI Class Initialized
DEBUG - 2011-07-18 04:10:09 --> Router Class Initialized
DEBUG - 2011-07-18 04:10:09 --> Output Class Initialized
DEBUG - 2011-07-18 04:10:09 --> Input Class Initialized
DEBUG - 2011-07-18 04:10:09 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-18 04:10:09 --> Language Class Initialized
DEBUG - 2011-07-18 04:10:09 --> Loader Class Initialized
DEBUG - 2011-07-18 04:10:09 --> Controller Class Initialized
DEBUG - 2011-07-18 04:10:09 --> Model Class Initialized
DEBUG - 2011-07-18 04:10:09 --> Model Class Initialized
DEBUG - 2011-07-18 04:10:09 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-18 04:10:09 --> Database Driver Class Initialized
DEBUG - 2011-07-18 04:10:10 --> Final output sent to browser
DEBUG - 2011-07-18 04:10:10 --> Total execution time: 0.6768
DEBUG - 2011-07-18 04:10:21 --> Config Class Initialized
DEBUG - 2011-07-18 04:10:21 --> Hooks Class Initialized
DEBUG - 2011-07-18 04:10:21 --> Utf8 Class Initialized
DEBUG - 2011-07-18 04:10:21 --> UTF-8 Support Enabled
DEBUG - 2011-07-18 04:10:21 --> URI Class Initialized
DEBUG - 2011-07-18 04:10:21 --> Router Class Initialized
DEBUG - 2011-07-18 04:10:21 --> Output Class Initialized
DEBUG - 2011-07-18 04:10:21 --> Input Class Initialized
DEBUG - 2011-07-18 04:10:21 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-18 04:10:21 --> Language Class Initialized
DEBUG - 2011-07-18 04:10:21 --> Loader Class Initialized
DEBUG - 2011-07-18 04:10:21 --> Controller Class Initialized
ERROR - 2011-07-18 04:10:21 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-18 04:10:21 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-18 04:10:21 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-18 04:10:21 --> Model Class Initialized
DEBUG - 2011-07-18 04:10:21 --> Model Class Initialized
DEBUG - 2011-07-18 04:10:21 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-18 04:10:21 --> Database Driver Class Initialized
DEBUG - 2011-07-18 04:10:21 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-18 04:10:21 --> Helper loaded: url_helper
DEBUG - 2011-07-18 04:10:21 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-18 04:10:21 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-18 04:10:21 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-18 04:10:21 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-18 04:10:21 --> Final output sent to browser
DEBUG - 2011-07-18 04:10:21 --> Total execution time: 0.0781
DEBUG - 2011-07-18 04:10:22 --> Config Class Initialized
DEBUG - 2011-07-18 04:10:22 --> Hooks Class Initialized
DEBUG - 2011-07-18 04:10:22 --> Utf8 Class Initialized
DEBUG - 2011-07-18 04:10:22 --> UTF-8 Support Enabled
DEBUG - 2011-07-18 04:10:22 --> URI Class Initialized
DEBUG - 2011-07-18 04:10:22 --> Router Class Initialized
DEBUG - 2011-07-18 04:10:22 --> Output Class Initialized
DEBUG - 2011-07-18 04:10:22 --> Input Class Initialized
DEBUG - 2011-07-18 04:10:22 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-18 04:10:22 --> Language Class Initialized
DEBUG - 2011-07-18 04:10:22 --> Loader Class Initialized
DEBUG - 2011-07-18 04:10:22 --> Controller Class Initialized
DEBUG - 2011-07-18 04:10:22 --> Model Class Initialized
DEBUG - 2011-07-18 04:10:22 --> Model Class Initialized
DEBUG - 2011-07-18 04:10:22 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-18 04:10:22 --> Database Driver Class Initialized
DEBUG - 2011-07-18 04:10:23 --> Final output sent to browser
DEBUG - 2011-07-18 04:10:23 --> Total execution time: 0.7939
DEBUG - 2011-07-18 04:10:24 --> Config Class Initialized
DEBUG - 2011-07-18 04:10:24 --> Hooks Class Initialized
DEBUG - 2011-07-18 04:10:24 --> Utf8 Class Initialized
DEBUG - 2011-07-18 04:10:24 --> UTF-8 Support Enabled
DEBUG - 2011-07-18 04:10:24 --> URI Class Initialized
DEBUG - 2011-07-18 04:10:24 --> Router Class Initialized
ERROR - 2011-07-18 04:10:24 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-07-18 04:10:24 --> Config Class Initialized
DEBUG - 2011-07-18 04:10:24 --> Hooks Class Initialized
DEBUG - 2011-07-18 04:10:24 --> Utf8 Class Initialized
DEBUG - 2011-07-18 04:10:24 --> UTF-8 Support Enabled
DEBUG - 2011-07-18 04:10:24 --> URI Class Initialized
DEBUG - 2011-07-18 04:10:24 --> Router Class Initialized
DEBUG - 2011-07-18 04:10:24 --> Output Class Initialized
DEBUG - 2011-07-18 04:10:24 --> Input Class Initialized
DEBUG - 2011-07-18 04:10:24 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-18 04:10:24 --> Language Class Initialized
DEBUG - 2011-07-18 04:10:24 --> Loader Class Initialized
DEBUG - 2011-07-18 04:10:24 --> Controller Class Initialized
ERROR - 2011-07-18 04:10:24 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-18 04:10:24 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-18 04:10:24 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-18 04:10:24 --> Model Class Initialized
DEBUG - 2011-07-18 04:10:24 --> Model Class Initialized
DEBUG - 2011-07-18 04:10:24 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-18 04:10:24 --> Database Driver Class Initialized
DEBUG - 2011-07-18 04:10:24 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-18 04:10:24 --> Helper loaded: url_helper
DEBUG - 2011-07-18 04:10:24 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-18 04:10:24 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-18 04:10:24 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-18 04:10:24 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-18 04:10:24 --> Final output sent to browser
DEBUG - 2011-07-18 04:10:24 --> Total execution time: 0.0298
DEBUG - 2011-07-18 04:42:32 --> Config Class Initialized
DEBUG - 2011-07-18 04:42:32 --> Hooks Class Initialized
DEBUG - 2011-07-18 04:42:32 --> Utf8 Class Initialized
DEBUG - 2011-07-18 04:42:32 --> UTF-8 Support Enabled
DEBUG - 2011-07-18 04:42:32 --> URI Class Initialized
DEBUG - 2011-07-18 04:42:32 --> Router Class Initialized
ERROR - 2011-07-18 04:42:32 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-07-18 04:49:20 --> Config Class Initialized
DEBUG - 2011-07-18 04:49:20 --> Hooks Class Initialized
DEBUG - 2011-07-18 04:49:20 --> Utf8 Class Initialized
DEBUG - 2011-07-18 04:49:20 --> UTF-8 Support Enabled
DEBUG - 2011-07-18 04:49:20 --> URI Class Initialized
DEBUG - 2011-07-18 04:49:20 --> Router Class Initialized
DEBUG - 2011-07-18 04:49:20 --> Output Class Initialized
DEBUG - 2011-07-18 04:49:20 --> Input Class Initialized
DEBUG - 2011-07-18 04:49:20 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-18 04:49:20 --> Language Class Initialized
DEBUG - 2011-07-18 04:49:21 --> Loader Class Initialized
DEBUG - 2011-07-18 04:49:21 --> Controller Class Initialized
ERROR - 2011-07-18 04:49:22 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-18 04:49:22 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-18 04:49:22 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-18 04:49:22 --> Model Class Initialized
DEBUG - 2011-07-18 04:49:22 --> Model Class Initialized
DEBUG - 2011-07-18 04:49:22 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-18 04:49:22 --> Database Driver Class Initialized
DEBUG - 2011-07-18 04:49:22 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-18 04:49:22 --> Helper loaded: url_helper
DEBUG - 2011-07-18 04:49:22 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-18 04:49:22 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-18 04:49:22 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-18 04:49:22 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-18 04:49:22 --> Final output sent to browser
DEBUG - 2011-07-18 04:49:22 --> Total execution time: 1.9268
DEBUG - 2011-07-18 04:52:39 --> Config Class Initialized
DEBUG - 2011-07-18 04:52:39 --> Hooks Class Initialized
DEBUG - 2011-07-18 04:52:39 --> Utf8 Class Initialized
DEBUG - 2011-07-18 04:52:39 --> UTF-8 Support Enabled
DEBUG - 2011-07-18 04:52:39 --> URI Class Initialized
DEBUG - 2011-07-18 04:52:39 --> Router Class Initialized
DEBUG - 2011-07-18 04:52:39 --> Output Class Initialized
DEBUG - 2011-07-18 04:52:39 --> Input Class Initialized
DEBUG - 2011-07-18 04:52:39 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-18 04:52:39 --> Language Class Initialized
DEBUG - 2011-07-18 04:52:39 --> Loader Class Initialized
DEBUG - 2011-07-18 04:52:39 --> Controller Class Initialized
ERROR - 2011-07-18 04:52:39 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-18 04:52:39 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-18 04:52:39 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-18 04:52:39 --> Model Class Initialized
DEBUG - 2011-07-18 04:52:39 --> Model Class Initialized
DEBUG - 2011-07-18 04:52:39 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-18 04:52:39 --> Database Driver Class Initialized
DEBUG - 2011-07-18 04:52:39 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-18 04:52:39 --> Helper loaded: url_helper
DEBUG - 2011-07-18 04:52:39 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-18 04:52:39 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-18 04:52:39 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-18 04:52:39 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-18 04:52:39 --> Final output sent to browser
DEBUG - 2011-07-18 04:52:39 --> Total execution time: 0.1127
DEBUG - 2011-07-18 08:20:28 --> Config Class Initialized
DEBUG - 2011-07-18 08:20:28 --> Hooks Class Initialized
DEBUG - 2011-07-18 08:20:28 --> Utf8 Class Initialized
DEBUG - 2011-07-18 08:20:28 --> UTF-8 Support Enabled
DEBUG - 2011-07-18 08:20:28 --> URI Class Initialized
DEBUG - 2011-07-18 08:20:28 --> Router Class Initialized
ERROR - 2011-07-18 08:20:28 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-07-18 08:24:32 --> Config Class Initialized
DEBUG - 2011-07-18 08:24:32 --> Hooks Class Initialized
DEBUG - 2011-07-18 08:24:32 --> Utf8 Class Initialized
DEBUG - 2011-07-18 08:24:32 --> UTF-8 Support Enabled
DEBUG - 2011-07-18 08:24:32 --> URI Class Initialized
DEBUG - 2011-07-18 08:24:32 --> Router Class Initialized
DEBUG - 2011-07-18 08:24:32 --> Output Class Initialized
DEBUG - 2011-07-18 08:24:32 --> Input Class Initialized
DEBUG - 2011-07-18 08:24:32 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-18 08:24:32 --> Language Class Initialized
DEBUG - 2011-07-18 08:24:32 --> Loader Class Initialized
DEBUG - 2011-07-18 08:24:32 --> Controller Class Initialized
DEBUG - 2011-07-18 08:24:32 --> Model Class Initialized
DEBUG - 2011-07-18 08:24:32 --> Model Class Initialized
DEBUG - 2011-07-18 08:24:32 --> Model Class Initialized
DEBUG - 2011-07-18 08:24:32 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-18 08:24:32 --> Database Driver Class Initialized
DEBUG - 2011-07-18 08:24:33 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-18 08:24:33 --> Helper loaded: url_helper
DEBUG - 2011-07-18 08:24:33 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-18 08:24:33 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-18 08:24:33 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-18 08:24:33 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-18 08:24:33 --> Final output sent to browser
DEBUG - 2011-07-18 08:24:33 --> Total execution time: 1.2969
DEBUG - 2011-07-18 10:11:25 --> Config Class Initialized
DEBUG - 2011-07-18 10:11:25 --> Hooks Class Initialized
DEBUG - 2011-07-18 10:11:25 --> Utf8 Class Initialized
DEBUG - 2011-07-18 10:11:25 --> UTF-8 Support Enabled
DEBUG - 2011-07-18 10:11:25 --> URI Class Initialized
DEBUG - 2011-07-18 10:11:25 --> Router Class Initialized
DEBUG - 2011-07-18 10:11:25 --> Output Class Initialized
DEBUG - 2011-07-18 10:11:25 --> Input Class Initialized
DEBUG - 2011-07-18 10:11:25 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-18 10:11:25 --> Language Class Initialized
DEBUG - 2011-07-18 10:11:25 --> Loader Class Initialized
DEBUG - 2011-07-18 10:11:25 --> Controller Class Initialized
DEBUG - 2011-07-18 10:11:25 --> Model Class Initialized
DEBUG - 2011-07-18 10:11:25 --> Model Class Initialized
DEBUG - 2011-07-18 10:11:25 --> Model Class Initialized
DEBUG - 2011-07-18 10:11:25 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-18 10:11:25 --> Database Driver Class Initialized
DEBUG - 2011-07-18 10:11:25 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-18 10:11:25 --> Helper loaded: url_helper
DEBUG - 2011-07-18 10:11:25 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-18 10:11:25 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-18 10:11:25 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-18 10:11:25 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-18 10:11:25 --> Final output sent to browser
DEBUG - 2011-07-18 10:11:25 --> Total execution time: 0.6646
DEBUG - 2011-07-18 10:11:27 --> Config Class Initialized
DEBUG - 2011-07-18 10:11:27 --> Hooks Class Initialized
DEBUG - 2011-07-18 10:11:27 --> Utf8 Class Initialized
DEBUG - 2011-07-18 10:11:27 --> UTF-8 Support Enabled
DEBUG - 2011-07-18 10:11:27 --> URI Class Initialized
DEBUG - 2011-07-18 10:11:27 --> Router Class Initialized
DEBUG - 2011-07-18 10:11:27 --> Output Class Initialized
DEBUG - 2011-07-18 10:11:27 --> Input Class Initialized
DEBUG - 2011-07-18 10:11:27 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-18 10:11:27 --> Language Class Initialized
DEBUG - 2011-07-18 10:11:27 --> Loader Class Initialized
DEBUG - 2011-07-18 10:11:27 --> Controller Class Initialized
ERROR - 2011-07-18 10:11:27 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-18 10:11:27 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-18 10:11:27 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-18 10:11:27 --> Model Class Initialized
DEBUG - 2011-07-18 10:11:27 --> Model Class Initialized
DEBUG - 2011-07-18 10:11:27 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-18 10:11:27 --> Database Driver Class Initialized
DEBUG - 2011-07-18 10:11:27 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-18 10:11:27 --> Helper loaded: url_helper
DEBUG - 2011-07-18 10:11:27 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-18 10:11:27 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-18 10:11:27 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-18 10:11:27 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-18 10:11:27 --> Final output sent to browser
DEBUG - 2011-07-18 10:11:27 --> Total execution time: 0.1014
DEBUG - 2011-07-18 12:38:51 --> Config Class Initialized
DEBUG - 2011-07-18 12:38:51 --> Hooks Class Initialized
DEBUG - 2011-07-18 12:38:51 --> Utf8 Class Initialized
DEBUG - 2011-07-18 12:38:51 --> UTF-8 Support Enabled
DEBUG - 2011-07-18 12:38:51 --> URI Class Initialized
DEBUG - 2011-07-18 12:38:51 --> Router Class Initialized
DEBUG - 2011-07-18 12:38:51 --> No URI present. Default controller set.
DEBUG - 2011-07-18 12:38:51 --> Output Class Initialized
DEBUG - 2011-07-18 12:38:51 --> Input Class Initialized
DEBUG - 2011-07-18 12:38:51 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-18 12:38:51 --> Language Class Initialized
DEBUG - 2011-07-18 12:38:51 --> Loader Class Initialized
DEBUG - 2011-07-18 12:38:51 --> Controller Class Initialized
DEBUG - 2011-07-18 12:38:51 --> File loaded: application/views/splash/main.php
DEBUG - 2011-07-18 12:38:51 --> Helper loaded: url_helper
DEBUG - 2011-07-18 12:38:51 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-18 12:38:51 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-18 12:38:51 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-18 12:38:51 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-18 12:38:51 --> Final output sent to browser
DEBUG - 2011-07-18 12:38:51 --> Total execution time: 0.2237
DEBUG - 2011-07-18 12:38:53 --> Config Class Initialized
DEBUG - 2011-07-18 12:38:53 --> Hooks Class Initialized
DEBUG - 2011-07-18 12:38:53 --> Utf8 Class Initialized
DEBUG - 2011-07-18 12:38:53 --> UTF-8 Support Enabled
DEBUG - 2011-07-18 12:38:53 --> URI Class Initialized
DEBUG - 2011-07-18 12:38:53 --> Router Class Initialized
ERROR - 2011-07-18 12:38:53 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-18 12:38:55 --> Config Class Initialized
DEBUG - 2011-07-18 12:38:55 --> Hooks Class Initialized
DEBUG - 2011-07-18 12:38:55 --> Utf8 Class Initialized
DEBUG - 2011-07-18 12:38:55 --> UTF-8 Support Enabled
DEBUG - 2011-07-18 12:38:55 --> URI Class Initialized
DEBUG - 2011-07-18 12:38:55 --> Router Class Initialized
DEBUG - 2011-07-18 12:38:55 --> Output Class Initialized
DEBUG - 2011-07-18 12:38:55 --> Input Class Initialized
DEBUG - 2011-07-18 12:38:55 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-18 12:38:55 --> Language Class Initialized
DEBUG - 2011-07-18 12:38:55 --> Loader Class Initialized
DEBUG - 2011-07-18 12:38:55 --> Controller Class Initialized
DEBUG - 2011-07-18 12:38:55 --> Model Class Initialized
DEBUG - 2011-07-18 12:38:55 --> Model Class Initialized
DEBUG - 2011-07-18 12:38:55 --> Model Class Initialized
DEBUG - 2011-07-18 12:38:55 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-18 12:38:55 --> Database Driver Class Initialized
DEBUG - 2011-07-18 12:38:56 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-18 12:38:56 --> Helper loaded: url_helper
DEBUG - 2011-07-18 12:38:56 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-18 12:38:56 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-18 12:38:56 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-18 12:38:56 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-18 12:38:56 --> Final output sent to browser
DEBUG - 2011-07-18 12:38:56 --> Total execution time: 1.1185
DEBUG - 2011-07-18 12:38:57 --> Config Class Initialized
DEBUG - 2011-07-18 12:38:57 --> Hooks Class Initialized
DEBUG - 2011-07-18 12:38:57 --> Utf8 Class Initialized
DEBUG - 2011-07-18 12:38:57 --> UTF-8 Support Enabled
DEBUG - 2011-07-18 12:38:57 --> URI Class Initialized
DEBUG - 2011-07-18 12:38:57 --> Router Class Initialized
ERROR - 2011-07-18 12:38:57 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-18 12:39:12 --> Config Class Initialized
DEBUG - 2011-07-18 12:39:12 --> Hooks Class Initialized
DEBUG - 2011-07-18 12:39:12 --> Utf8 Class Initialized
DEBUG - 2011-07-18 12:39:12 --> UTF-8 Support Enabled
DEBUG - 2011-07-18 12:39:12 --> URI Class Initialized
DEBUG - 2011-07-18 12:39:12 --> Router Class Initialized
DEBUG - 2011-07-18 12:39:12 --> Output Class Initialized
DEBUG - 2011-07-18 12:39:12 --> Input Class Initialized
DEBUG - 2011-07-18 12:39:12 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-18 12:39:12 --> Language Class Initialized
DEBUG - 2011-07-18 12:39:12 --> Loader Class Initialized
DEBUG - 2011-07-18 12:39:12 --> Controller Class Initialized
DEBUG - 2011-07-18 12:39:12 --> Model Class Initialized
DEBUG - 2011-07-18 12:39:12 --> Model Class Initialized
DEBUG - 2011-07-18 12:39:12 --> Model Class Initialized
DEBUG - 2011-07-18 12:39:12 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-18 12:39:12 --> Database Driver Class Initialized
DEBUG - 2011-07-18 12:39:13 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-18 12:39:13 --> Helper loaded: url_helper
DEBUG - 2011-07-18 12:39:13 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-18 12:39:13 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-18 12:39:13 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-18 12:39:13 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-18 12:39:13 --> Final output sent to browser
DEBUG - 2011-07-18 12:39:13 --> Total execution time: 0.8631
DEBUG - 2011-07-18 12:39:15 --> Config Class Initialized
DEBUG - 2011-07-18 12:39:15 --> Hooks Class Initialized
DEBUG - 2011-07-18 12:39:15 --> Utf8 Class Initialized
DEBUG - 2011-07-18 12:39:15 --> UTF-8 Support Enabled
DEBUG - 2011-07-18 12:39:15 --> URI Class Initialized
DEBUG - 2011-07-18 12:39:15 --> Router Class Initialized
ERROR - 2011-07-18 12:39:15 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-18 12:39:17 --> Config Class Initialized
DEBUG - 2011-07-18 12:39:17 --> Hooks Class Initialized
DEBUG - 2011-07-18 12:39:17 --> Utf8 Class Initialized
DEBUG - 2011-07-18 12:39:17 --> UTF-8 Support Enabled
DEBUG - 2011-07-18 12:39:17 --> URI Class Initialized
DEBUG - 2011-07-18 12:39:17 --> Router Class Initialized
DEBUG - 2011-07-18 12:39:17 --> Output Class Initialized
DEBUG - 2011-07-18 12:39:17 --> Input Class Initialized
DEBUG - 2011-07-18 12:39:17 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-18 12:39:17 --> Language Class Initialized
DEBUG - 2011-07-18 12:39:17 --> Loader Class Initialized
DEBUG - 2011-07-18 12:39:17 --> Controller Class Initialized
DEBUG - 2011-07-18 12:39:17 --> Model Class Initialized
DEBUG - 2011-07-18 12:39:17 --> Model Class Initialized
DEBUG - 2011-07-18 12:39:17 --> Model Class Initialized
DEBUG - 2011-07-18 12:39:17 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-18 12:39:17 --> Database Driver Class Initialized
DEBUG - 2011-07-18 12:39:17 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-18 12:39:17 --> Helper loaded: url_helper
DEBUG - 2011-07-18 12:39:17 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-18 12:39:17 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-18 12:39:17 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-18 12:39:17 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-18 12:39:17 --> Final output sent to browser
DEBUG - 2011-07-18 12:39:17 --> Total execution time: 0.0452
DEBUG - 2011-07-18 12:44:04 --> Config Class Initialized
DEBUG - 2011-07-18 12:44:04 --> Hooks Class Initialized
DEBUG - 2011-07-18 12:44:04 --> Utf8 Class Initialized
DEBUG - 2011-07-18 12:44:04 --> UTF-8 Support Enabled
DEBUG - 2011-07-18 12:44:04 --> URI Class Initialized
DEBUG - 2011-07-18 12:44:04 --> Router Class Initialized
DEBUG - 2011-07-18 12:44:04 --> No URI present. Default controller set.
DEBUG - 2011-07-18 12:44:04 --> Output Class Initialized
DEBUG - 2011-07-18 12:44:04 --> Input Class Initialized
DEBUG - 2011-07-18 12:44:04 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-18 12:44:04 --> Language Class Initialized
DEBUG - 2011-07-18 12:44:04 --> Loader Class Initialized
DEBUG - 2011-07-18 12:44:04 --> Controller Class Initialized
DEBUG - 2011-07-18 12:44:04 --> File loaded: application/views/splash/main.php
DEBUG - 2011-07-18 12:44:04 --> Helper loaded: url_helper
DEBUG - 2011-07-18 12:44:04 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-18 12:44:04 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-18 12:44:04 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-18 12:44:04 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-18 12:44:04 --> Final output sent to browser
DEBUG - 2011-07-18 12:44:04 --> Total execution time: 0.1025
DEBUG - 2011-07-18 12:44:05 --> Config Class Initialized
DEBUG - 2011-07-18 12:44:05 --> Hooks Class Initialized
DEBUG - 2011-07-18 12:44:05 --> Utf8 Class Initialized
DEBUG - 2011-07-18 12:44:05 --> UTF-8 Support Enabled
DEBUG - 2011-07-18 12:44:05 --> URI Class Initialized
DEBUG - 2011-07-18 12:44:05 --> Router Class Initialized
ERROR - 2011-07-18 12:44:05 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-18 12:44:08 --> Config Class Initialized
DEBUG - 2011-07-18 12:44:08 --> Hooks Class Initialized
DEBUG - 2011-07-18 12:44:08 --> Utf8 Class Initialized
DEBUG - 2011-07-18 12:44:08 --> UTF-8 Support Enabled
DEBUG - 2011-07-18 12:44:08 --> URI Class Initialized
DEBUG - 2011-07-18 12:44:08 --> Router Class Initialized
DEBUG - 2011-07-18 12:44:08 --> Output Class Initialized
DEBUG - 2011-07-18 12:44:08 --> Input Class Initialized
DEBUG - 2011-07-18 12:44:08 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-18 12:44:08 --> Language Class Initialized
DEBUG - 2011-07-18 12:44:08 --> Loader Class Initialized
DEBUG - 2011-07-18 12:44:08 --> Controller Class Initialized
ERROR - 2011-07-18 12:44:08 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-18 12:44:08 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-18 12:44:08 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-18 12:44:08 --> Model Class Initialized
DEBUG - 2011-07-18 12:44:08 --> Model Class Initialized
DEBUG - 2011-07-18 12:44:08 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-18 12:44:08 --> Database Driver Class Initialized
DEBUG - 2011-07-18 12:44:08 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-18 12:44:08 --> Helper loaded: url_helper
DEBUG - 2011-07-18 12:44:08 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-18 12:44:08 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-18 12:44:08 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-18 12:44:08 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-18 12:44:08 --> Final output sent to browser
DEBUG - 2011-07-18 12:44:08 --> Total execution time: 0.1874
DEBUG - 2011-07-18 12:44:09 --> Config Class Initialized
DEBUG - 2011-07-18 12:44:09 --> Hooks Class Initialized
DEBUG - 2011-07-18 12:44:09 --> Utf8 Class Initialized
DEBUG - 2011-07-18 12:44:09 --> UTF-8 Support Enabled
DEBUG - 2011-07-18 12:44:09 --> URI Class Initialized
DEBUG - 2011-07-18 12:44:09 --> Router Class Initialized
DEBUG - 2011-07-18 12:44:09 --> Output Class Initialized
DEBUG - 2011-07-18 12:44:09 --> Input Class Initialized
DEBUG - 2011-07-18 12:44:09 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-18 12:44:09 --> Language Class Initialized
DEBUG - 2011-07-18 12:44:09 --> Loader Class Initialized
DEBUG - 2011-07-18 12:44:09 --> Controller Class Initialized
DEBUG - 2011-07-18 12:44:09 --> Model Class Initialized
DEBUG - 2011-07-18 12:44:09 --> Model Class Initialized
DEBUG - 2011-07-18 12:44:09 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-18 12:44:09 --> Database Driver Class Initialized
DEBUG - 2011-07-18 12:44:09 --> Final output sent to browser
DEBUG - 2011-07-18 12:44:09 --> Total execution time: 0.8067
DEBUG - 2011-07-18 12:44:10 --> Config Class Initialized
DEBUG - 2011-07-18 12:44:10 --> Hooks Class Initialized
DEBUG - 2011-07-18 12:44:10 --> Utf8 Class Initialized
DEBUG - 2011-07-18 12:44:10 --> UTF-8 Support Enabled
DEBUG - 2011-07-18 12:44:10 --> URI Class Initialized
DEBUG - 2011-07-18 12:44:10 --> Router Class Initialized
ERROR - 2011-07-18 12:44:10 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-18 14:35:37 --> Config Class Initialized
DEBUG - 2011-07-18 14:35:37 --> Hooks Class Initialized
DEBUG - 2011-07-18 14:35:37 --> Utf8 Class Initialized
DEBUG - 2011-07-18 14:35:37 --> UTF-8 Support Enabled
DEBUG - 2011-07-18 14:35:37 --> URI Class Initialized
DEBUG - 2011-07-18 14:35:37 --> Router Class Initialized
DEBUG - 2011-07-18 14:35:37 --> Output Class Initialized
DEBUG - 2011-07-18 14:35:37 --> Input Class Initialized
DEBUG - 2011-07-18 14:35:37 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-18 14:35:37 --> Language Class Initialized
DEBUG - 2011-07-18 14:35:37 --> Loader Class Initialized
DEBUG - 2011-07-18 14:35:37 --> Controller Class Initialized
ERROR - 2011-07-18 14:35:38 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-18 14:35:38 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-18 14:35:38 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-18 14:35:38 --> Model Class Initialized
DEBUG - 2011-07-18 14:35:38 --> Model Class Initialized
DEBUG - 2011-07-18 14:35:38 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-18 14:35:38 --> Database Driver Class Initialized
DEBUG - 2011-07-18 14:35:38 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-18 14:35:38 --> Helper loaded: url_helper
DEBUG - 2011-07-18 14:35:38 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-18 14:35:38 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-18 14:35:38 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-18 14:35:38 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-18 14:35:38 --> Final output sent to browser
DEBUG - 2011-07-18 14:35:38 --> Total execution time: 0.5900
DEBUG - 2011-07-18 14:35:43 --> Config Class Initialized
DEBUG - 2011-07-18 14:35:43 --> Hooks Class Initialized
DEBUG - 2011-07-18 14:35:43 --> Utf8 Class Initialized
DEBUG - 2011-07-18 14:35:43 --> UTF-8 Support Enabled
DEBUG - 2011-07-18 14:35:43 --> URI Class Initialized
DEBUG - 2011-07-18 14:35:43 --> Router Class Initialized
DEBUG - 2011-07-18 14:35:43 --> Output Class Initialized
DEBUG - 2011-07-18 14:35:43 --> Input Class Initialized
DEBUG - 2011-07-18 14:35:43 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-18 14:35:43 --> Language Class Initialized
DEBUG - 2011-07-18 14:35:43 --> Loader Class Initialized
DEBUG - 2011-07-18 14:35:43 --> Controller Class Initialized
DEBUG - 2011-07-18 14:35:43 --> Model Class Initialized
DEBUG - 2011-07-18 14:35:43 --> Model Class Initialized
DEBUG - 2011-07-18 14:35:43 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-18 14:35:43 --> Database Driver Class Initialized
DEBUG - 2011-07-18 14:35:44 --> Final output sent to browser
DEBUG - 2011-07-18 14:35:44 --> Total execution time: 1.7461
DEBUG - 2011-07-18 14:54:18 --> Config Class Initialized
DEBUG - 2011-07-18 14:54:18 --> Hooks Class Initialized
DEBUG - 2011-07-18 14:54:18 --> Utf8 Class Initialized
DEBUG - 2011-07-18 14:54:18 --> UTF-8 Support Enabled
DEBUG - 2011-07-18 14:54:18 --> URI Class Initialized
DEBUG - 2011-07-18 14:54:18 --> Router Class Initialized
DEBUG - 2011-07-18 14:54:18 --> Output Class Initialized
DEBUG - 2011-07-18 14:54:18 --> Input Class Initialized
DEBUG - 2011-07-18 14:54:18 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-18 14:54:18 --> Language Class Initialized
DEBUG - 2011-07-18 14:54:18 --> Loader Class Initialized
DEBUG - 2011-07-18 14:54:18 --> Controller Class Initialized
ERROR - 2011-07-18 14:54:18 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-18 14:54:18 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-18 14:54:18 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-18 14:54:18 --> Model Class Initialized
DEBUG - 2011-07-18 14:54:18 --> Model Class Initialized
DEBUG - 2011-07-18 14:54:18 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-18 14:54:18 --> Database Driver Class Initialized
DEBUG - 2011-07-18 14:54:18 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-18 14:54:18 --> Helper loaded: url_helper
DEBUG - 2011-07-18 14:54:18 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-18 14:54:18 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-18 14:54:18 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-18 14:54:18 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-18 14:54:18 --> Final output sent to browser
DEBUG - 2011-07-18 14:54:18 --> Total execution time: 0.3007
DEBUG - 2011-07-18 14:54:19 --> Config Class Initialized
DEBUG - 2011-07-18 14:54:19 --> Hooks Class Initialized
DEBUG - 2011-07-18 14:54:19 --> Utf8 Class Initialized
DEBUG - 2011-07-18 14:54:19 --> UTF-8 Support Enabled
DEBUG - 2011-07-18 14:54:19 --> URI Class Initialized
DEBUG - 2011-07-18 14:54:19 --> Router Class Initialized
DEBUG - 2011-07-18 14:54:19 --> Output Class Initialized
DEBUG - 2011-07-18 14:54:19 --> Input Class Initialized
DEBUG - 2011-07-18 14:54:19 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-18 14:54:19 --> Language Class Initialized
DEBUG - 2011-07-18 14:54:19 --> Loader Class Initialized
DEBUG - 2011-07-18 14:54:19 --> Controller Class Initialized
DEBUG - 2011-07-18 14:54:19 --> Model Class Initialized
DEBUG - 2011-07-18 14:54:19 --> Model Class Initialized
DEBUG - 2011-07-18 14:54:19 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-18 14:54:19 --> Database Driver Class Initialized
DEBUG - 2011-07-18 14:54:20 --> Final output sent to browser
DEBUG - 2011-07-18 14:54:20 --> Total execution time: 0.5889
DEBUG - 2011-07-18 14:54:21 --> Config Class Initialized
DEBUG - 2011-07-18 14:54:21 --> Hooks Class Initialized
DEBUG - 2011-07-18 14:54:21 --> Utf8 Class Initialized
DEBUG - 2011-07-18 14:54:21 --> UTF-8 Support Enabled
DEBUG - 2011-07-18 14:54:21 --> URI Class Initialized
DEBUG - 2011-07-18 14:54:21 --> Router Class Initialized
ERROR - 2011-07-18 14:54:21 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-18 15:36:46 --> Config Class Initialized
DEBUG - 2011-07-18 15:36:46 --> Hooks Class Initialized
DEBUG - 2011-07-18 15:36:46 --> Utf8 Class Initialized
DEBUG - 2011-07-18 15:36:46 --> UTF-8 Support Enabled
DEBUG - 2011-07-18 15:36:46 --> URI Class Initialized
DEBUG - 2011-07-18 15:36:46 --> Router Class Initialized
DEBUG - 2011-07-18 15:36:46 --> Output Class Initialized
DEBUG - 2011-07-18 15:36:46 --> Input Class Initialized
DEBUG - 2011-07-18 15:36:46 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-18 15:36:46 --> Language Class Initialized
DEBUG - 2011-07-18 15:36:46 --> Loader Class Initialized
DEBUG - 2011-07-18 15:36:46 --> Controller Class Initialized
DEBUG - 2011-07-18 15:36:46 --> Model Class Initialized
DEBUG - 2011-07-18 15:36:46 --> Model Class Initialized
DEBUG - 2011-07-18 15:36:46 --> Model Class Initialized
DEBUG - 2011-07-18 15:36:46 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-18 15:36:46 --> Database Driver Class Initialized
DEBUG - 2011-07-18 15:36:47 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-18 15:36:47 --> Helper loaded: url_helper
DEBUG - 2011-07-18 15:36:47 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-18 15:36:47 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-18 15:36:47 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-18 15:36:47 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-18 15:36:47 --> Final output sent to browser
DEBUG - 2011-07-18 15:36:47 --> Total execution time: 1.3089
DEBUG - 2011-07-18 15:36:50 --> Config Class Initialized
DEBUG - 2011-07-18 15:36:50 --> Hooks Class Initialized
DEBUG - 2011-07-18 15:36:50 --> Utf8 Class Initialized
DEBUG - 2011-07-18 15:36:50 --> UTF-8 Support Enabled
DEBUG - 2011-07-18 15:36:50 --> URI Class Initialized
DEBUG - 2011-07-18 15:36:50 --> Router Class Initialized
ERROR - 2011-07-18 15:36:50 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-18 15:36:54 --> Config Class Initialized
DEBUG - 2011-07-18 15:36:54 --> Hooks Class Initialized
DEBUG - 2011-07-18 15:36:54 --> Utf8 Class Initialized
DEBUG - 2011-07-18 15:36:54 --> UTF-8 Support Enabled
DEBUG - 2011-07-18 15:36:54 --> URI Class Initialized
DEBUG - 2011-07-18 15:36:54 --> Router Class Initialized
DEBUG - 2011-07-18 15:36:54 --> Output Class Initialized
DEBUG - 2011-07-18 15:36:54 --> Input Class Initialized
DEBUG - 2011-07-18 15:36:54 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-18 15:36:54 --> Language Class Initialized
DEBUG - 2011-07-18 15:36:54 --> Loader Class Initialized
DEBUG - 2011-07-18 15:36:54 --> Controller Class Initialized
ERROR - 2011-07-18 15:36:54 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-18 15:36:54 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-18 15:36:54 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-18 15:36:54 --> Model Class Initialized
DEBUG - 2011-07-18 15:36:54 --> Model Class Initialized
DEBUG - 2011-07-18 15:36:54 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-18 15:36:54 --> Database Driver Class Initialized
DEBUG - 2011-07-18 15:36:54 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-18 15:36:54 --> Helper loaded: url_helper
DEBUG - 2011-07-18 15:36:54 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-18 15:36:54 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-18 15:36:54 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-18 15:36:54 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-18 15:36:54 --> Final output sent to browser
DEBUG - 2011-07-18 15:36:54 --> Total execution time: 0.0816
DEBUG - 2011-07-18 15:36:55 --> Config Class Initialized
DEBUG - 2011-07-18 15:36:55 --> Hooks Class Initialized
DEBUG - 2011-07-18 15:36:55 --> Utf8 Class Initialized
DEBUG - 2011-07-18 15:36:55 --> UTF-8 Support Enabled
DEBUG - 2011-07-18 15:36:55 --> URI Class Initialized
DEBUG - 2011-07-18 15:36:55 --> Router Class Initialized
DEBUG - 2011-07-18 15:36:55 --> Output Class Initialized
DEBUG - 2011-07-18 15:36:55 --> Input Class Initialized
DEBUG - 2011-07-18 15:36:55 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-18 15:36:55 --> Language Class Initialized
DEBUG - 2011-07-18 15:36:55 --> Loader Class Initialized
DEBUG - 2011-07-18 15:36:55 --> Controller Class Initialized
DEBUG - 2011-07-18 15:36:55 --> Model Class Initialized
DEBUG - 2011-07-18 15:36:55 --> Model Class Initialized
DEBUG - 2011-07-18 15:36:55 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-18 15:36:55 --> Database Driver Class Initialized
DEBUG - 2011-07-18 15:36:56 --> Final output sent to browser
DEBUG - 2011-07-18 15:36:56 --> Total execution time: 0.6716
DEBUG - 2011-07-18 15:36:57 --> Config Class Initialized
DEBUG - 2011-07-18 15:36:57 --> Hooks Class Initialized
DEBUG - 2011-07-18 15:36:57 --> Utf8 Class Initialized
DEBUG - 2011-07-18 15:36:57 --> UTF-8 Support Enabled
DEBUG - 2011-07-18 15:36:57 --> URI Class Initialized
DEBUG - 2011-07-18 15:36:57 --> Router Class Initialized
ERROR - 2011-07-18 15:36:57 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-18 15:37:16 --> Config Class Initialized
DEBUG - 2011-07-18 15:37:16 --> Hooks Class Initialized
DEBUG - 2011-07-18 15:37:16 --> Utf8 Class Initialized
DEBUG - 2011-07-18 15:37:16 --> UTF-8 Support Enabled
DEBUG - 2011-07-18 15:37:16 --> URI Class Initialized
DEBUG - 2011-07-18 15:37:16 --> Router Class Initialized
DEBUG - 2011-07-18 15:37:16 --> Output Class Initialized
DEBUG - 2011-07-18 15:37:16 --> Input Class Initialized
DEBUG - 2011-07-18 15:37:16 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-18 15:37:16 --> Language Class Initialized
DEBUG - 2011-07-18 15:37:16 --> Loader Class Initialized
DEBUG - 2011-07-18 15:37:16 --> Controller Class Initialized
ERROR - 2011-07-18 15:37:16 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-18 15:37:16 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-18 15:37:16 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-18 15:37:16 --> Model Class Initialized
DEBUG - 2011-07-18 15:37:16 --> Model Class Initialized
DEBUG - 2011-07-18 15:37:16 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-18 15:37:16 --> Database Driver Class Initialized
DEBUG - 2011-07-18 15:37:16 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-18 15:37:16 --> Helper loaded: url_helper
DEBUG - 2011-07-18 15:37:16 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-18 15:37:16 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-18 15:37:16 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-18 15:37:16 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-18 15:37:16 --> Final output sent to browser
DEBUG - 2011-07-18 15:37:16 --> Total execution time: 0.0318
DEBUG - 2011-07-18 15:37:17 --> Config Class Initialized
DEBUG - 2011-07-18 15:37:17 --> Hooks Class Initialized
DEBUG - 2011-07-18 15:37:17 --> Utf8 Class Initialized
DEBUG - 2011-07-18 15:37:17 --> UTF-8 Support Enabled
DEBUG - 2011-07-18 15:37:17 --> URI Class Initialized
DEBUG - 2011-07-18 15:37:17 --> Router Class Initialized
DEBUG - 2011-07-18 15:37:17 --> Output Class Initialized
DEBUG - 2011-07-18 15:37:17 --> Input Class Initialized
DEBUG - 2011-07-18 15:37:17 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-18 15:37:17 --> Language Class Initialized
DEBUG - 2011-07-18 15:37:17 --> Loader Class Initialized
DEBUG - 2011-07-18 15:37:17 --> Controller Class Initialized
DEBUG - 2011-07-18 15:37:17 --> Model Class Initialized
DEBUG - 2011-07-18 15:37:17 --> Model Class Initialized
DEBUG - 2011-07-18 15:37:17 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-18 15:37:17 --> Database Driver Class Initialized
DEBUG - 2011-07-18 15:37:17 --> Final output sent to browser
DEBUG - 2011-07-18 15:37:17 --> Total execution time: 0.6256
DEBUG - 2011-07-18 15:37:19 --> Config Class Initialized
DEBUG - 2011-07-18 15:37:19 --> Hooks Class Initialized
DEBUG - 2011-07-18 15:37:19 --> Utf8 Class Initialized
DEBUG - 2011-07-18 15:37:19 --> UTF-8 Support Enabled
DEBUG - 2011-07-18 15:37:19 --> URI Class Initialized
DEBUG - 2011-07-18 15:37:19 --> Router Class Initialized
ERROR - 2011-07-18 15:37:19 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-18 15:37:25 --> Config Class Initialized
DEBUG - 2011-07-18 15:37:25 --> Hooks Class Initialized
DEBUG - 2011-07-18 15:37:25 --> Utf8 Class Initialized
DEBUG - 2011-07-18 15:37:25 --> UTF-8 Support Enabled
DEBUG - 2011-07-18 15:37:25 --> URI Class Initialized
DEBUG - 2011-07-18 15:37:25 --> Router Class Initialized
DEBUG - 2011-07-18 15:37:25 --> Output Class Initialized
DEBUG - 2011-07-18 15:37:25 --> Input Class Initialized
DEBUG - 2011-07-18 15:37:25 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-18 15:37:25 --> Language Class Initialized
DEBUG - 2011-07-18 15:37:25 --> Loader Class Initialized
DEBUG - 2011-07-18 15:37:25 --> Controller Class Initialized
ERROR - 2011-07-18 15:37:25 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-18 15:37:25 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-18 15:37:25 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-18 15:37:25 --> Model Class Initialized
DEBUG - 2011-07-18 15:37:25 --> Model Class Initialized
DEBUG - 2011-07-18 15:37:25 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-18 15:37:25 --> Database Driver Class Initialized
DEBUG - 2011-07-18 15:37:25 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-18 15:37:25 --> Helper loaded: url_helper
DEBUG - 2011-07-18 15:37:25 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-18 15:37:25 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-18 15:37:25 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-18 15:37:25 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-18 15:37:25 --> Final output sent to browser
DEBUG - 2011-07-18 15:37:25 --> Total execution time: 0.0303
DEBUG - 2011-07-18 15:37:25 --> Config Class Initialized
DEBUG - 2011-07-18 15:37:25 --> Hooks Class Initialized
DEBUG - 2011-07-18 15:37:25 --> Utf8 Class Initialized
DEBUG - 2011-07-18 15:37:25 --> UTF-8 Support Enabled
DEBUG - 2011-07-18 15:37:25 --> URI Class Initialized
DEBUG - 2011-07-18 15:37:25 --> Router Class Initialized
DEBUG - 2011-07-18 15:37:25 --> Output Class Initialized
DEBUG - 2011-07-18 15:37:25 --> Input Class Initialized
DEBUG - 2011-07-18 15:37:25 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-18 15:37:25 --> Language Class Initialized
DEBUG - 2011-07-18 15:37:25 --> Loader Class Initialized
DEBUG - 2011-07-18 15:37:25 --> Controller Class Initialized
DEBUG - 2011-07-18 15:37:25 --> Model Class Initialized
DEBUG - 2011-07-18 15:37:25 --> Model Class Initialized
DEBUG - 2011-07-18 15:37:25 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-18 15:37:25 --> Database Driver Class Initialized
DEBUG - 2011-07-18 15:37:26 --> Final output sent to browser
DEBUG - 2011-07-18 15:37:26 --> Total execution time: 0.5380
DEBUG - 2011-07-18 15:37:27 --> Config Class Initialized
DEBUG - 2011-07-18 15:37:27 --> Hooks Class Initialized
DEBUG - 2011-07-18 15:37:27 --> Utf8 Class Initialized
DEBUG - 2011-07-18 15:37:27 --> UTF-8 Support Enabled
DEBUG - 2011-07-18 15:37:27 --> URI Class Initialized
DEBUG - 2011-07-18 15:37:27 --> Router Class Initialized
DEBUG - 2011-07-18 15:37:27 --> Output Class Initialized
DEBUG - 2011-07-18 15:37:27 --> Input Class Initialized
DEBUG - 2011-07-18 15:37:27 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-18 15:37:27 --> Language Class Initialized
DEBUG - 2011-07-18 15:37:27 --> Loader Class Initialized
DEBUG - 2011-07-18 15:37:27 --> Controller Class Initialized
ERROR - 2011-07-18 15:37:27 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-18 15:37:27 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-18 15:37:27 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-18 15:37:27 --> Model Class Initialized
DEBUG - 2011-07-18 15:37:27 --> Model Class Initialized
DEBUG - 2011-07-18 15:37:27 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-18 15:37:27 --> Database Driver Class Initialized
DEBUG - 2011-07-18 15:37:27 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-18 15:37:27 --> Helper loaded: url_helper
DEBUG - 2011-07-18 15:37:27 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-18 15:37:27 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-18 15:37:27 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-18 15:37:27 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-18 15:37:27 --> Final output sent to browser
DEBUG - 2011-07-18 15:37:27 --> Total execution time: 0.0286
DEBUG - 2011-07-18 15:37:27 --> Config Class Initialized
DEBUG - 2011-07-18 15:37:27 --> Hooks Class Initialized
DEBUG - 2011-07-18 15:37:27 --> Utf8 Class Initialized
DEBUG - 2011-07-18 15:37:27 --> UTF-8 Support Enabled
DEBUG - 2011-07-18 15:37:27 --> URI Class Initialized
DEBUG - 2011-07-18 15:37:27 --> Router Class Initialized
ERROR - 2011-07-18 15:37:27 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-18 15:37:31 --> Config Class Initialized
DEBUG - 2011-07-18 15:37:31 --> Hooks Class Initialized
DEBUG - 2011-07-18 15:37:31 --> Utf8 Class Initialized
DEBUG - 2011-07-18 15:37:31 --> UTF-8 Support Enabled
DEBUG - 2011-07-18 15:37:31 --> URI Class Initialized
DEBUG - 2011-07-18 15:37:31 --> Router Class Initialized
DEBUG - 2011-07-18 15:37:31 --> Output Class Initialized
DEBUG - 2011-07-18 15:37:31 --> Input Class Initialized
DEBUG - 2011-07-18 15:37:31 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-18 15:37:31 --> Language Class Initialized
DEBUG - 2011-07-18 15:37:31 --> Loader Class Initialized
DEBUG - 2011-07-18 15:37:31 --> Controller Class Initialized
ERROR - 2011-07-18 15:37:31 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-18 15:37:31 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-18 15:37:31 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-18 15:37:31 --> Model Class Initialized
DEBUG - 2011-07-18 15:37:31 --> Model Class Initialized
DEBUG - 2011-07-18 15:37:31 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-18 15:37:31 --> Database Driver Class Initialized
DEBUG - 2011-07-18 15:37:31 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-18 15:37:31 --> Helper loaded: url_helper
DEBUG - 2011-07-18 15:37:31 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-18 15:37:31 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-18 15:37:31 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-18 15:37:31 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-18 15:37:31 --> Final output sent to browser
DEBUG - 2011-07-18 15:37:31 --> Total execution time: 0.0405
DEBUG - 2011-07-18 15:37:32 --> Config Class Initialized
DEBUG - 2011-07-18 15:37:32 --> Hooks Class Initialized
DEBUG - 2011-07-18 15:37:32 --> Utf8 Class Initialized
DEBUG - 2011-07-18 15:37:32 --> UTF-8 Support Enabled
DEBUG - 2011-07-18 15:37:32 --> URI Class Initialized
DEBUG - 2011-07-18 15:37:32 --> Router Class Initialized
DEBUG - 2011-07-18 15:37:32 --> Output Class Initialized
DEBUG - 2011-07-18 15:37:32 --> Input Class Initialized
DEBUG - 2011-07-18 15:37:32 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-18 15:37:32 --> Language Class Initialized
DEBUG - 2011-07-18 15:37:32 --> Loader Class Initialized
DEBUG - 2011-07-18 15:37:32 --> Controller Class Initialized
DEBUG - 2011-07-18 15:37:32 --> Model Class Initialized
DEBUG - 2011-07-18 15:37:32 --> Model Class Initialized
DEBUG - 2011-07-18 15:37:32 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-18 15:37:32 --> Database Driver Class Initialized
DEBUG - 2011-07-18 15:37:33 --> Config Class Initialized
DEBUG - 2011-07-18 15:37:33 --> Hooks Class Initialized
DEBUG - 2011-07-18 15:37:33 --> Utf8 Class Initialized
DEBUG - 2011-07-18 15:37:33 --> UTF-8 Support Enabled
DEBUG - 2011-07-18 15:37:33 --> URI Class Initialized
DEBUG - 2011-07-18 15:37:33 --> Router Class Initialized
DEBUG - 2011-07-18 15:37:33 --> Output Class Initialized
DEBUG - 2011-07-18 15:37:33 --> Input Class Initialized
DEBUG - 2011-07-18 15:37:33 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-18 15:37:33 --> Language Class Initialized
DEBUG - 2011-07-18 15:37:33 --> Loader Class Initialized
DEBUG - 2011-07-18 15:37:33 --> Controller Class Initialized
ERROR - 2011-07-18 15:37:33 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-18 15:37:33 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-18 15:37:33 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-18 15:37:33 --> Model Class Initialized
DEBUG - 2011-07-18 15:37:33 --> Model Class Initialized
DEBUG - 2011-07-18 15:37:33 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-18 15:37:33 --> Database Driver Class Initialized
DEBUG - 2011-07-18 15:37:33 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-18 15:37:33 --> Helper loaded: url_helper
DEBUG - 2011-07-18 15:37:33 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-18 15:37:33 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-18 15:37:33 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-18 15:37:33 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-18 15:37:33 --> Final output sent to browser
DEBUG - 2011-07-18 15:37:33 --> Total execution time: 0.0355
DEBUG - 2011-07-18 15:37:33 --> Final output sent to browser
DEBUG - 2011-07-18 15:37:33 --> Total execution time: 0.8364
DEBUG - 2011-07-18 15:37:34 --> Config Class Initialized
DEBUG - 2011-07-18 15:37:34 --> Hooks Class Initialized
DEBUG - 2011-07-18 15:37:34 --> Utf8 Class Initialized
DEBUG - 2011-07-18 15:37:34 --> UTF-8 Support Enabled
DEBUG - 2011-07-18 15:37:34 --> URI Class Initialized
DEBUG - 2011-07-18 15:37:34 --> Router Class Initialized
ERROR - 2011-07-18 15:37:34 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-18 16:01:53 --> Config Class Initialized
DEBUG - 2011-07-18 16:01:53 --> Hooks Class Initialized
DEBUG - 2011-07-18 16:01:53 --> Utf8 Class Initialized
DEBUG - 2011-07-18 16:01:53 --> UTF-8 Support Enabled
DEBUG - 2011-07-18 16:01:53 --> URI Class Initialized
DEBUG - 2011-07-18 16:01:53 --> Router Class Initialized
DEBUG - 2011-07-18 16:01:53 --> Output Class Initialized
DEBUG - 2011-07-18 16:01:53 --> Input Class Initialized
DEBUG - 2011-07-18 16:01:53 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-18 16:01:53 --> Language Class Initialized
DEBUG - 2011-07-18 16:01:53 --> Loader Class Initialized
DEBUG - 2011-07-18 16:01:53 --> Controller Class Initialized
ERROR - 2011-07-18 16:01:53 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-18 16:01:53 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-18 16:01:53 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-18 16:01:53 --> Model Class Initialized
DEBUG - 2011-07-18 16:01:53 --> Model Class Initialized
DEBUG - 2011-07-18 16:01:53 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-18 16:01:53 --> Database Driver Class Initialized
DEBUG - 2011-07-18 16:01:53 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-18 16:01:53 --> Helper loaded: url_helper
DEBUG - 2011-07-18 16:01:53 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-18 16:01:53 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-18 16:01:53 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-18 16:01:53 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-18 16:01:53 --> Final output sent to browser
DEBUG - 2011-07-18 16:01:53 --> Total execution time: 0.3283
DEBUG - 2011-07-18 16:01:54 --> Config Class Initialized
DEBUG - 2011-07-18 16:01:54 --> Hooks Class Initialized
DEBUG - 2011-07-18 16:01:54 --> Utf8 Class Initialized
DEBUG - 2011-07-18 16:01:54 --> UTF-8 Support Enabled
DEBUG - 2011-07-18 16:01:54 --> URI Class Initialized
DEBUG - 2011-07-18 16:01:54 --> Router Class Initialized
DEBUG - 2011-07-18 16:01:54 --> Output Class Initialized
DEBUG - 2011-07-18 16:01:54 --> Input Class Initialized
DEBUG - 2011-07-18 16:01:54 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-18 16:01:54 --> Language Class Initialized
DEBUG - 2011-07-18 16:01:54 --> Loader Class Initialized
DEBUG - 2011-07-18 16:01:54 --> Controller Class Initialized
DEBUG - 2011-07-18 16:01:54 --> Model Class Initialized
DEBUG - 2011-07-18 16:01:54 --> Model Class Initialized
DEBUG - 2011-07-18 16:01:54 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-18 16:01:54 --> Database Driver Class Initialized
DEBUG - 2011-07-18 16:01:56 --> Final output sent to browser
DEBUG - 2011-07-18 16:01:56 --> Total execution time: 1.2911
DEBUG - 2011-07-18 16:01:57 --> Config Class Initialized
DEBUG - 2011-07-18 16:01:57 --> Hooks Class Initialized
DEBUG - 2011-07-18 16:01:57 --> Utf8 Class Initialized
DEBUG - 2011-07-18 16:01:57 --> UTF-8 Support Enabled
DEBUG - 2011-07-18 16:01:57 --> URI Class Initialized
DEBUG - 2011-07-18 16:01:57 --> Router Class Initialized
ERROR - 2011-07-18 16:01:57 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-18 16:02:23 --> Config Class Initialized
DEBUG - 2011-07-18 16:02:23 --> Hooks Class Initialized
DEBUG - 2011-07-18 16:02:23 --> Utf8 Class Initialized
DEBUG - 2011-07-18 16:02:23 --> UTF-8 Support Enabled
DEBUG - 2011-07-18 16:02:23 --> URI Class Initialized
DEBUG - 2011-07-18 16:02:23 --> Router Class Initialized
DEBUG - 2011-07-18 16:02:23 --> Output Class Initialized
DEBUG - 2011-07-18 16:02:23 --> Input Class Initialized
DEBUG - 2011-07-18 16:02:23 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-18 16:02:23 --> Language Class Initialized
DEBUG - 2011-07-18 16:02:23 --> Loader Class Initialized
DEBUG - 2011-07-18 16:02:23 --> Controller Class Initialized
ERROR - 2011-07-18 16:02:23 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-18 16:02:23 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-18 16:02:23 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-18 16:02:23 --> Model Class Initialized
DEBUG - 2011-07-18 16:02:23 --> Model Class Initialized
DEBUG - 2011-07-18 16:02:23 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-18 16:02:23 --> Database Driver Class Initialized
DEBUG - 2011-07-18 16:02:23 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-18 16:02:23 --> Helper loaded: url_helper
DEBUG - 2011-07-18 16:02:23 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-18 16:02:23 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-18 16:02:23 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-18 16:02:23 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-18 16:02:23 --> Final output sent to browser
DEBUG - 2011-07-18 16:02:23 --> Total execution time: 0.0398
DEBUG - 2011-07-18 16:02:24 --> Config Class Initialized
DEBUG - 2011-07-18 16:02:24 --> Hooks Class Initialized
DEBUG - 2011-07-18 16:02:24 --> Utf8 Class Initialized
DEBUG - 2011-07-18 16:02:24 --> UTF-8 Support Enabled
DEBUG - 2011-07-18 16:02:24 --> URI Class Initialized
DEBUG - 2011-07-18 16:02:24 --> Router Class Initialized
DEBUG - 2011-07-18 16:02:24 --> Output Class Initialized
DEBUG - 2011-07-18 16:02:24 --> Input Class Initialized
DEBUG - 2011-07-18 16:02:24 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-18 16:02:24 --> Language Class Initialized
DEBUG - 2011-07-18 16:02:24 --> Loader Class Initialized
DEBUG - 2011-07-18 16:02:24 --> Controller Class Initialized
DEBUG - 2011-07-18 16:02:24 --> Model Class Initialized
DEBUG - 2011-07-18 16:02:24 --> Model Class Initialized
DEBUG - 2011-07-18 16:02:24 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-18 16:02:24 --> Database Driver Class Initialized
DEBUG - 2011-07-18 16:02:25 --> Final output sent to browser
DEBUG - 2011-07-18 16:02:25 --> Total execution time: 0.6613
DEBUG - 2011-07-18 16:02:26 --> Config Class Initialized
DEBUG - 2011-07-18 16:02:26 --> Hooks Class Initialized
DEBUG - 2011-07-18 16:02:26 --> Utf8 Class Initialized
DEBUG - 2011-07-18 16:02:26 --> UTF-8 Support Enabled
DEBUG - 2011-07-18 16:02:26 --> URI Class Initialized
DEBUG - 2011-07-18 16:02:26 --> Router Class Initialized
ERROR - 2011-07-18 16:02:26 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-18 16:02:38 --> Config Class Initialized
DEBUG - 2011-07-18 16:02:38 --> Hooks Class Initialized
DEBUG - 2011-07-18 16:02:38 --> Utf8 Class Initialized
DEBUG - 2011-07-18 16:02:38 --> UTF-8 Support Enabled
DEBUG - 2011-07-18 16:02:38 --> URI Class Initialized
DEBUG - 2011-07-18 16:02:38 --> Router Class Initialized
DEBUG - 2011-07-18 16:02:38 --> Output Class Initialized
DEBUG - 2011-07-18 16:02:38 --> Input Class Initialized
DEBUG - 2011-07-18 16:02:38 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-18 16:02:38 --> Language Class Initialized
DEBUG - 2011-07-18 16:02:38 --> Loader Class Initialized
DEBUG - 2011-07-18 16:02:38 --> Controller Class Initialized
ERROR - 2011-07-18 16:02:38 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-18 16:02:38 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-18 16:02:38 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-18 16:02:38 --> Model Class Initialized
DEBUG - 2011-07-18 16:02:38 --> Model Class Initialized
DEBUG - 2011-07-18 16:02:38 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-18 16:02:38 --> Database Driver Class Initialized
DEBUG - 2011-07-18 16:02:38 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-18 16:02:38 --> Helper loaded: url_helper
DEBUG - 2011-07-18 16:02:38 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-18 16:02:38 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-18 16:02:38 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-18 16:02:38 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-18 16:02:38 --> Final output sent to browser
DEBUG - 2011-07-18 16:02:38 --> Total execution time: 0.0310
DEBUG - 2011-07-18 16:02:39 --> Config Class Initialized
DEBUG - 2011-07-18 16:02:39 --> Hooks Class Initialized
DEBUG - 2011-07-18 16:02:39 --> Utf8 Class Initialized
DEBUG - 2011-07-18 16:02:39 --> UTF-8 Support Enabled
DEBUG - 2011-07-18 16:02:39 --> URI Class Initialized
DEBUG - 2011-07-18 16:02:39 --> Router Class Initialized
DEBUG - 2011-07-18 16:02:39 --> Output Class Initialized
DEBUG - 2011-07-18 16:02:39 --> Input Class Initialized
DEBUG - 2011-07-18 16:02:39 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-18 16:02:39 --> Language Class Initialized
DEBUG - 2011-07-18 16:02:39 --> Loader Class Initialized
DEBUG - 2011-07-18 16:02:39 --> Controller Class Initialized
DEBUG - 2011-07-18 16:02:39 --> Model Class Initialized
DEBUG - 2011-07-18 16:02:39 --> Model Class Initialized
DEBUG - 2011-07-18 16:02:39 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-18 16:02:39 --> Database Driver Class Initialized
DEBUG - 2011-07-18 16:02:40 --> Final output sent to browser
DEBUG - 2011-07-18 16:02:40 --> Total execution time: 0.5716
DEBUG - 2011-07-18 16:02:41 --> Config Class Initialized
DEBUG - 2011-07-18 16:02:41 --> Hooks Class Initialized
DEBUG - 2011-07-18 16:02:41 --> Utf8 Class Initialized
DEBUG - 2011-07-18 16:02:41 --> UTF-8 Support Enabled
DEBUG - 2011-07-18 16:02:41 --> URI Class Initialized
DEBUG - 2011-07-18 16:02:41 --> Router Class Initialized
ERROR - 2011-07-18 16:02:41 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-18 16:02:51 --> Config Class Initialized
DEBUG - 2011-07-18 16:02:51 --> Hooks Class Initialized
DEBUG - 2011-07-18 16:02:51 --> Utf8 Class Initialized
DEBUG - 2011-07-18 16:02:51 --> UTF-8 Support Enabled
DEBUG - 2011-07-18 16:02:51 --> URI Class Initialized
DEBUG - 2011-07-18 16:02:51 --> Router Class Initialized
DEBUG - 2011-07-18 16:02:51 --> Output Class Initialized
DEBUG - 2011-07-18 16:02:51 --> Input Class Initialized
DEBUG - 2011-07-18 16:02:51 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-18 16:02:51 --> Language Class Initialized
DEBUG - 2011-07-18 16:02:51 --> Loader Class Initialized
DEBUG - 2011-07-18 16:02:51 --> Controller Class Initialized
ERROR - 2011-07-18 16:02:51 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-18 16:02:51 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-18 16:02:51 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-18 16:02:52 --> Model Class Initialized
DEBUG - 2011-07-18 16:02:52 --> Model Class Initialized
DEBUG - 2011-07-18 16:02:52 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-18 16:02:52 --> Database Driver Class Initialized
DEBUG - 2011-07-18 16:02:52 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-18 16:02:52 --> Helper loaded: url_helper
DEBUG - 2011-07-18 16:02:52 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-18 16:02:52 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-18 16:02:52 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-18 16:02:52 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-18 16:02:52 --> Final output sent to browser
DEBUG - 2011-07-18 16:02:52 --> Total execution time: 0.0325
DEBUG - 2011-07-18 16:02:52 --> Config Class Initialized
DEBUG - 2011-07-18 16:02:52 --> Hooks Class Initialized
DEBUG - 2011-07-18 16:02:52 --> Utf8 Class Initialized
DEBUG - 2011-07-18 16:02:52 --> UTF-8 Support Enabled
DEBUG - 2011-07-18 16:02:52 --> URI Class Initialized
DEBUG - 2011-07-18 16:02:52 --> Router Class Initialized
DEBUG - 2011-07-18 16:02:52 --> Output Class Initialized
DEBUG - 2011-07-18 16:02:52 --> Input Class Initialized
DEBUG - 2011-07-18 16:02:52 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-18 16:02:52 --> Language Class Initialized
DEBUG - 2011-07-18 16:02:52 --> Loader Class Initialized
DEBUG - 2011-07-18 16:02:52 --> Controller Class Initialized
DEBUG - 2011-07-18 16:02:52 --> Model Class Initialized
DEBUG - 2011-07-18 16:02:52 --> Model Class Initialized
DEBUG - 2011-07-18 16:02:52 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-18 16:02:52 --> Database Driver Class Initialized
DEBUG - 2011-07-18 16:02:53 --> Final output sent to browser
DEBUG - 2011-07-18 16:02:53 --> Total execution time: 0.9702
DEBUG - 2011-07-18 16:02:53 --> Config Class Initialized
DEBUG - 2011-07-18 16:02:53 --> Hooks Class Initialized
DEBUG - 2011-07-18 16:02:53 --> Utf8 Class Initialized
DEBUG - 2011-07-18 16:02:53 --> UTF-8 Support Enabled
DEBUG - 2011-07-18 16:02:53 --> URI Class Initialized
DEBUG - 2011-07-18 16:02:53 --> Router Class Initialized
DEBUG - 2011-07-18 16:02:53 --> Output Class Initialized
DEBUG - 2011-07-18 16:02:53 --> Input Class Initialized
DEBUG - 2011-07-18 16:02:53 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-18 16:02:53 --> Language Class Initialized
DEBUG - 2011-07-18 16:02:53 --> Loader Class Initialized
DEBUG - 2011-07-18 16:02:53 --> Controller Class Initialized
ERROR - 2011-07-18 16:02:53 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-18 16:02:53 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-18 16:02:53 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-18 16:02:53 --> Model Class Initialized
DEBUG - 2011-07-18 16:02:53 --> Model Class Initialized
DEBUG - 2011-07-18 16:02:53 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-18 16:02:53 --> Database Driver Class Initialized
DEBUG - 2011-07-18 16:02:53 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-18 16:02:53 --> Helper loaded: url_helper
DEBUG - 2011-07-18 16:02:53 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-18 16:02:53 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-18 16:02:53 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-18 16:02:53 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-18 16:02:53 --> Final output sent to browser
DEBUG - 2011-07-18 16:02:53 --> Total execution time: 0.0269
DEBUG - 2011-07-18 16:02:55 --> Config Class Initialized
DEBUG - 2011-07-18 16:02:55 --> Hooks Class Initialized
DEBUG - 2011-07-18 16:02:55 --> Utf8 Class Initialized
DEBUG - 2011-07-18 16:02:55 --> UTF-8 Support Enabled
DEBUG - 2011-07-18 16:02:55 --> URI Class Initialized
DEBUG - 2011-07-18 16:02:55 --> Router Class Initialized
ERROR - 2011-07-18 16:02:55 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-18 16:02:56 --> Config Class Initialized
DEBUG - 2011-07-18 16:02:56 --> Hooks Class Initialized
DEBUG - 2011-07-18 16:02:56 --> Utf8 Class Initialized
DEBUG - 2011-07-18 16:02:56 --> UTF-8 Support Enabled
DEBUG - 2011-07-18 16:02:56 --> URI Class Initialized
DEBUG - 2011-07-18 16:02:56 --> Router Class Initialized
DEBUG - 2011-07-18 16:02:56 --> Output Class Initialized
DEBUG - 2011-07-18 16:02:56 --> Input Class Initialized
DEBUG - 2011-07-18 16:02:56 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-18 16:02:56 --> Language Class Initialized
DEBUG - 2011-07-18 16:02:56 --> Loader Class Initialized
DEBUG - 2011-07-18 16:02:56 --> Controller Class Initialized
ERROR - 2011-07-18 16:02:56 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-18 16:02:56 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-18 16:02:56 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-18 16:02:56 --> Model Class Initialized
DEBUG - 2011-07-18 16:02:56 --> Model Class Initialized
DEBUG - 2011-07-18 16:02:56 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-18 16:02:56 --> Database Driver Class Initialized
DEBUG - 2011-07-18 16:02:56 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-18 16:02:56 --> Helper loaded: url_helper
DEBUG - 2011-07-18 16:02:56 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-18 16:02:56 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-18 16:02:56 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-18 16:02:56 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-18 16:02:56 --> Final output sent to browser
DEBUG - 2011-07-18 16:02:56 --> Total execution time: 0.0301
DEBUG - 2011-07-18 16:03:20 --> Config Class Initialized
DEBUG - 2011-07-18 16:03:20 --> Hooks Class Initialized
DEBUG - 2011-07-18 16:03:20 --> Utf8 Class Initialized
DEBUG - 2011-07-18 16:03:20 --> UTF-8 Support Enabled
DEBUG - 2011-07-18 16:03:20 --> URI Class Initialized
DEBUG - 2011-07-18 16:03:20 --> Router Class Initialized
DEBUG - 2011-07-18 16:03:20 --> Output Class Initialized
DEBUG - 2011-07-18 16:03:20 --> Input Class Initialized
DEBUG - 2011-07-18 16:03:20 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-18 16:03:20 --> Language Class Initialized
DEBUG - 2011-07-18 16:03:20 --> Loader Class Initialized
DEBUG - 2011-07-18 16:03:20 --> Controller Class Initialized
ERROR - 2011-07-18 16:03:20 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-18 16:03:20 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-18 16:03:20 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-18 16:03:20 --> Model Class Initialized
DEBUG - 2011-07-18 16:03:20 --> Model Class Initialized
DEBUG - 2011-07-18 16:03:20 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-18 16:03:20 --> Database Driver Class Initialized
DEBUG - 2011-07-18 16:03:20 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-18 16:03:20 --> Helper loaded: url_helper
DEBUG - 2011-07-18 16:03:20 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-18 16:03:20 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-18 16:03:20 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-18 16:03:20 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-18 16:03:20 --> Final output sent to browser
DEBUG - 2011-07-18 16:03:20 --> Total execution time: 0.0772
DEBUG - 2011-07-18 16:03:21 --> Config Class Initialized
DEBUG - 2011-07-18 16:03:21 --> Hooks Class Initialized
DEBUG - 2011-07-18 16:03:21 --> Utf8 Class Initialized
DEBUG - 2011-07-18 16:03:21 --> UTF-8 Support Enabled
DEBUG - 2011-07-18 16:03:21 --> URI Class Initialized
DEBUG - 2011-07-18 16:03:21 --> Router Class Initialized
DEBUG - 2011-07-18 16:03:21 --> Output Class Initialized
DEBUG - 2011-07-18 16:03:21 --> Input Class Initialized
DEBUG - 2011-07-18 16:03:21 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-18 16:03:21 --> Language Class Initialized
DEBUG - 2011-07-18 16:03:21 --> Loader Class Initialized
DEBUG - 2011-07-18 16:03:21 --> Controller Class Initialized
DEBUG - 2011-07-18 16:03:21 --> Model Class Initialized
DEBUG - 2011-07-18 16:03:21 --> Model Class Initialized
DEBUG - 2011-07-18 16:03:21 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-18 16:03:21 --> Database Driver Class Initialized
DEBUG - 2011-07-18 16:03:21 --> Final output sent to browser
DEBUG - 2011-07-18 16:03:21 --> Total execution time: 0.6678
DEBUG - 2011-07-18 16:03:22 --> Config Class Initialized
DEBUG - 2011-07-18 16:03:22 --> Hooks Class Initialized
DEBUG - 2011-07-18 16:03:22 --> Utf8 Class Initialized
DEBUG - 2011-07-18 16:03:22 --> UTF-8 Support Enabled
DEBUG - 2011-07-18 16:03:22 --> URI Class Initialized
DEBUG - 2011-07-18 16:03:22 --> Router Class Initialized
ERROR - 2011-07-18 16:03:22 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-18 16:03:23 --> Config Class Initialized
DEBUG - 2011-07-18 16:03:23 --> Hooks Class Initialized
DEBUG - 2011-07-18 16:03:23 --> Utf8 Class Initialized
DEBUG - 2011-07-18 16:03:23 --> UTF-8 Support Enabled
DEBUG - 2011-07-18 16:03:23 --> URI Class Initialized
DEBUG - 2011-07-18 16:03:23 --> Router Class Initialized
DEBUG - 2011-07-18 16:03:23 --> Output Class Initialized
DEBUG - 2011-07-18 16:03:23 --> Input Class Initialized
DEBUG - 2011-07-18 16:03:23 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-18 16:03:23 --> Language Class Initialized
DEBUG - 2011-07-18 16:03:23 --> Loader Class Initialized
DEBUG - 2011-07-18 16:03:23 --> Controller Class Initialized
ERROR - 2011-07-18 16:03:23 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-18 16:03:23 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-18 16:03:23 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-18 16:03:23 --> Model Class Initialized
DEBUG - 2011-07-18 16:03:23 --> Model Class Initialized
DEBUG - 2011-07-18 16:03:23 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-18 16:03:23 --> Database Driver Class Initialized
DEBUG - 2011-07-18 16:03:23 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-18 16:03:23 --> Helper loaded: url_helper
DEBUG - 2011-07-18 16:03:23 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-18 16:03:23 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-18 16:03:23 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-18 16:03:23 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-18 16:03:23 --> Final output sent to browser
DEBUG - 2011-07-18 16:03:23 --> Total execution time: 0.0451
DEBUG - 2011-07-18 17:46:58 --> Config Class Initialized
DEBUG - 2011-07-18 17:46:58 --> Hooks Class Initialized
DEBUG - 2011-07-18 17:46:58 --> Utf8 Class Initialized
DEBUG - 2011-07-18 17:46:58 --> UTF-8 Support Enabled
DEBUG - 2011-07-18 17:46:58 --> URI Class Initialized
DEBUG - 2011-07-18 17:46:58 --> Router Class Initialized
ERROR - 2011-07-18 17:46:58 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-07-18 17:46:59 --> Config Class Initialized
DEBUG - 2011-07-18 17:46:59 --> Hooks Class Initialized
DEBUG - 2011-07-18 17:46:59 --> Utf8 Class Initialized
DEBUG - 2011-07-18 17:46:59 --> UTF-8 Support Enabled
DEBUG - 2011-07-18 17:46:59 --> URI Class Initialized
DEBUG - 2011-07-18 17:46:59 --> Router Class Initialized
DEBUG - 2011-07-18 17:46:59 --> No URI present. Default controller set.
DEBUG - 2011-07-18 17:46:59 --> Output Class Initialized
DEBUG - 2011-07-18 17:46:59 --> Input Class Initialized
DEBUG - 2011-07-18 17:46:59 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-18 17:46:59 --> Language Class Initialized
DEBUG - 2011-07-18 17:46:59 --> Loader Class Initialized
DEBUG - 2011-07-18 17:46:59 --> Controller Class Initialized
DEBUG - 2011-07-18 17:46:59 --> File loaded: application/views/splash/main.php
DEBUG - 2011-07-18 17:46:59 --> Helper loaded: url_helper
DEBUG - 2011-07-18 17:46:59 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-18 17:46:59 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-18 17:46:59 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-18 17:46:59 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-18 17:46:59 --> Final output sent to browser
DEBUG - 2011-07-18 17:46:59 --> Total execution time: 0.1506
DEBUG - 2011-07-18 18:02:44 --> Config Class Initialized
DEBUG - 2011-07-18 18:02:44 --> Hooks Class Initialized
DEBUG - 2011-07-18 18:02:44 --> Utf8 Class Initialized
DEBUG - 2011-07-18 18:02:44 --> UTF-8 Support Enabled
DEBUG - 2011-07-18 18:02:44 --> URI Class Initialized
DEBUG - 2011-07-18 18:02:45 --> Router Class Initialized
DEBUG - 2011-07-18 18:02:45 --> Output Class Initialized
DEBUG - 2011-07-18 18:02:45 --> Input Class Initialized
DEBUG - 2011-07-18 18:02:45 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-18 18:02:45 --> Language Class Initialized
DEBUG - 2011-07-18 18:02:45 --> Loader Class Initialized
DEBUG - 2011-07-18 18:02:45 --> Controller Class Initialized
DEBUG - 2011-07-18 18:02:45 --> Model Class Initialized
DEBUG - 2011-07-18 18:02:45 --> Model Class Initialized
DEBUG - 2011-07-18 18:02:45 --> Model Class Initialized
DEBUG - 2011-07-18 18:02:45 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-18 18:02:45 --> Database Driver Class Initialized
DEBUG - 2011-07-18 18:02:45 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-18 18:02:45 --> Helper loaded: url_helper
DEBUG - 2011-07-18 18:02:45 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-18 18:02:45 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-18 18:02:45 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-18 18:02:45 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-18 18:02:45 --> Final output sent to browser
DEBUG - 2011-07-18 18:02:45 --> Total execution time: 0.8201
DEBUG - 2011-07-18 18:02:51 --> Config Class Initialized
DEBUG - 2011-07-18 18:02:51 --> Hooks Class Initialized
DEBUG - 2011-07-18 18:02:51 --> Utf8 Class Initialized
DEBUG - 2011-07-18 18:02:51 --> UTF-8 Support Enabled
DEBUG - 2011-07-18 18:02:51 --> URI Class Initialized
DEBUG - 2011-07-18 18:02:51 --> Router Class Initialized
ERROR - 2011-07-18 18:02:51 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-18 18:02:52 --> Config Class Initialized
DEBUG - 2011-07-18 18:02:52 --> Hooks Class Initialized
DEBUG - 2011-07-18 18:02:52 --> Utf8 Class Initialized
DEBUG - 2011-07-18 18:02:52 --> UTF-8 Support Enabled
DEBUG - 2011-07-18 18:02:52 --> URI Class Initialized
DEBUG - 2011-07-18 18:02:52 --> Router Class Initialized
ERROR - 2011-07-18 18:02:52 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-18 18:02:52 --> Config Class Initialized
DEBUG - 2011-07-18 18:02:52 --> Hooks Class Initialized
DEBUG - 2011-07-18 18:02:52 --> Utf8 Class Initialized
DEBUG - 2011-07-18 18:02:52 --> UTF-8 Support Enabled
DEBUG - 2011-07-18 18:02:52 --> URI Class Initialized
DEBUG - 2011-07-18 18:02:52 --> Router Class Initialized
ERROR - 2011-07-18 18:02:52 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-18 18:17:39 --> Config Class Initialized
DEBUG - 2011-07-18 18:17:39 --> Hooks Class Initialized
DEBUG - 2011-07-18 18:17:39 --> Utf8 Class Initialized
DEBUG - 2011-07-18 18:17:39 --> UTF-8 Support Enabled
DEBUG - 2011-07-18 18:17:39 --> URI Class Initialized
DEBUG - 2011-07-18 18:17:39 --> Router Class Initialized
DEBUG - 2011-07-18 18:17:39 --> Output Class Initialized
DEBUG - 2011-07-18 18:17:39 --> Input Class Initialized
DEBUG - 2011-07-18 18:17:39 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-18 18:17:39 --> Language Class Initialized
DEBUG - 2011-07-18 18:17:39 --> Loader Class Initialized
DEBUG - 2011-07-18 18:17:39 --> Controller Class Initialized
ERROR - 2011-07-18 18:17:39 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-18 18:17:39 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-18 18:17:39 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-18 18:17:39 --> Model Class Initialized
DEBUG - 2011-07-18 18:17:39 --> Model Class Initialized
DEBUG - 2011-07-18 18:17:39 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-18 18:17:39 --> Database Driver Class Initialized
DEBUG - 2011-07-18 18:17:39 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-18 18:17:39 --> Helper loaded: url_helper
DEBUG - 2011-07-18 18:17:39 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-18 18:17:39 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-18 18:17:39 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-18 18:17:39 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-18 18:17:39 --> Final output sent to browser
DEBUG - 2011-07-18 18:17:39 --> Total execution time: 0.1783
DEBUG - 2011-07-18 18:56:47 --> Config Class Initialized
DEBUG - 2011-07-18 18:56:47 --> Hooks Class Initialized
DEBUG - 2011-07-18 18:56:47 --> Utf8 Class Initialized
DEBUG - 2011-07-18 18:56:47 --> UTF-8 Support Enabled
DEBUG - 2011-07-18 18:56:47 --> URI Class Initialized
DEBUG - 2011-07-18 18:56:47 --> Router Class Initialized
DEBUG - 2011-07-18 18:56:47 --> No URI present. Default controller set.
DEBUG - 2011-07-18 18:56:47 --> Output Class Initialized
DEBUG - 2011-07-18 18:56:47 --> Input Class Initialized
DEBUG - 2011-07-18 18:56:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-18 18:56:47 --> Language Class Initialized
DEBUG - 2011-07-18 18:56:47 --> Loader Class Initialized
DEBUG - 2011-07-18 18:56:47 --> Controller Class Initialized
DEBUG - 2011-07-18 18:56:47 --> File loaded: application/views/splash/main.php
DEBUG - 2011-07-18 18:56:47 --> Helper loaded: url_helper
DEBUG - 2011-07-18 18:56:47 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-18 18:56:47 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-18 18:56:47 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-18 18:56:47 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-18 18:56:47 --> Final output sent to browser
DEBUG - 2011-07-18 18:56:47 --> Total execution time: 0.2505
DEBUG - 2011-07-18 18:56:49 --> Config Class Initialized
DEBUG - 2011-07-18 18:56:49 --> Hooks Class Initialized
DEBUG - 2011-07-18 18:56:49 --> Utf8 Class Initialized
DEBUG - 2011-07-18 18:56:49 --> UTF-8 Support Enabled
DEBUG - 2011-07-18 18:56:49 --> URI Class Initialized
DEBUG - 2011-07-18 18:56:49 --> Router Class Initialized
ERROR - 2011-07-18 18:56:49 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-18 18:56:50 --> Config Class Initialized
DEBUG - 2011-07-18 18:56:50 --> Hooks Class Initialized
DEBUG - 2011-07-18 18:56:50 --> Utf8 Class Initialized
DEBUG - 2011-07-18 18:56:50 --> UTF-8 Support Enabled
DEBUG - 2011-07-18 18:56:50 --> URI Class Initialized
DEBUG - 2011-07-18 18:56:50 --> Router Class Initialized
ERROR - 2011-07-18 18:56:50 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-18 18:56:50 --> Config Class Initialized
DEBUG - 2011-07-18 18:56:50 --> Hooks Class Initialized
DEBUG - 2011-07-18 18:56:50 --> Utf8 Class Initialized
DEBUG - 2011-07-18 18:56:50 --> UTF-8 Support Enabled
DEBUG - 2011-07-18 18:56:50 --> URI Class Initialized
DEBUG - 2011-07-18 18:56:50 --> Router Class Initialized
ERROR - 2011-07-18 18:56:50 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-18 18:56:54 --> Config Class Initialized
DEBUG - 2011-07-18 18:56:54 --> Hooks Class Initialized
DEBUG - 2011-07-18 18:56:54 --> Utf8 Class Initialized
DEBUG - 2011-07-18 18:56:54 --> UTF-8 Support Enabled
DEBUG - 2011-07-18 18:56:54 --> URI Class Initialized
DEBUG - 2011-07-18 18:56:54 --> Router Class Initialized
DEBUG - 2011-07-18 18:56:54 --> Output Class Initialized
DEBUG - 2011-07-18 18:56:54 --> Input Class Initialized
DEBUG - 2011-07-18 18:56:54 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-18 18:56:54 --> Language Class Initialized
DEBUG - 2011-07-18 18:56:54 --> Loader Class Initialized
DEBUG - 2011-07-18 18:56:54 --> Controller Class Initialized
DEBUG - 2011-07-18 18:56:54 --> Model Class Initialized
DEBUG - 2011-07-18 18:56:54 --> Model Class Initialized
DEBUG - 2011-07-18 18:56:54 --> Model Class Initialized
DEBUG - 2011-07-18 18:56:54 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-18 18:56:54 --> Database Driver Class Initialized
DEBUG - 2011-07-18 18:56:54 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-18 18:56:54 --> Helper loaded: url_helper
DEBUG - 2011-07-18 18:56:54 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-18 18:56:54 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-18 18:56:54 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-18 18:56:54 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-18 18:56:54 --> Final output sent to browser
DEBUG - 2011-07-18 18:56:55 --> Total execution time: 0.5610
DEBUG - 2011-07-18 18:57:09 --> Config Class Initialized
DEBUG - 2011-07-18 18:57:09 --> Hooks Class Initialized
DEBUG - 2011-07-18 18:57:09 --> Utf8 Class Initialized
DEBUG - 2011-07-18 18:57:09 --> UTF-8 Support Enabled
DEBUG - 2011-07-18 18:57:09 --> URI Class Initialized
DEBUG - 2011-07-18 18:57:09 --> Router Class Initialized
DEBUG - 2011-07-18 18:57:09 --> Output Class Initialized
DEBUG - 2011-07-18 18:57:09 --> Input Class Initialized
DEBUG - 2011-07-18 18:57:09 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-18 18:57:09 --> Language Class Initialized
DEBUG - 2011-07-18 18:57:09 --> Loader Class Initialized
DEBUG - 2011-07-18 18:57:09 --> Controller Class Initialized
DEBUG - 2011-07-18 18:57:09 --> Model Class Initialized
DEBUG - 2011-07-18 18:57:09 --> Model Class Initialized
DEBUG - 2011-07-18 18:57:09 --> Model Class Initialized
DEBUG - 2011-07-18 18:57:09 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-18 18:57:09 --> Database Driver Class Initialized
DEBUG - 2011-07-18 18:57:10 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-18 18:57:10 --> Helper loaded: url_helper
DEBUG - 2011-07-18 18:57:10 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-18 18:57:10 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-18 18:57:10 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-18 18:57:10 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-18 18:57:10 --> Final output sent to browser
DEBUG - 2011-07-18 18:57:10 --> Total execution time: 0.5300
DEBUG - 2011-07-18 18:57:11 --> Config Class Initialized
DEBUG - 2011-07-18 18:57:11 --> Hooks Class Initialized
DEBUG - 2011-07-18 18:57:11 --> Utf8 Class Initialized
DEBUG - 2011-07-18 18:57:11 --> UTF-8 Support Enabled
DEBUG - 2011-07-18 18:57:11 --> URI Class Initialized
DEBUG - 2011-07-18 18:57:11 --> Router Class Initialized
DEBUG - 2011-07-18 18:57:11 --> Output Class Initialized
DEBUG - 2011-07-18 18:57:11 --> Input Class Initialized
DEBUG - 2011-07-18 18:57:11 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-18 18:57:11 --> Language Class Initialized
DEBUG - 2011-07-18 18:57:11 --> Loader Class Initialized
DEBUG - 2011-07-18 18:57:11 --> Controller Class Initialized
DEBUG - 2011-07-18 18:57:11 --> Model Class Initialized
DEBUG - 2011-07-18 18:57:11 --> Model Class Initialized
DEBUG - 2011-07-18 18:57:11 --> Model Class Initialized
DEBUG - 2011-07-18 18:57:11 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-18 18:57:11 --> Database Driver Class Initialized
DEBUG - 2011-07-18 18:57:11 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-18 18:57:11 --> Helper loaded: url_helper
DEBUG - 2011-07-18 18:57:11 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-18 18:57:11 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-18 18:57:11 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-18 18:57:11 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-18 18:57:11 --> Final output sent to browser
DEBUG - 2011-07-18 18:57:11 --> Total execution time: 0.0652
DEBUG - 2011-07-18 18:57:35 --> Config Class Initialized
DEBUG - 2011-07-18 18:57:35 --> Hooks Class Initialized
DEBUG - 2011-07-18 18:57:35 --> Utf8 Class Initialized
DEBUG - 2011-07-18 18:57:35 --> UTF-8 Support Enabled
DEBUG - 2011-07-18 18:57:35 --> URI Class Initialized
DEBUG - 2011-07-18 18:57:35 --> Router Class Initialized
DEBUG - 2011-07-18 18:57:35 --> Output Class Initialized
DEBUG - 2011-07-18 18:57:35 --> Input Class Initialized
DEBUG - 2011-07-18 18:57:35 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-18 18:57:35 --> Language Class Initialized
DEBUG - 2011-07-18 18:57:35 --> Loader Class Initialized
DEBUG - 2011-07-18 18:57:35 --> Controller Class Initialized
DEBUG - 2011-07-18 18:57:35 --> Model Class Initialized
DEBUG - 2011-07-18 18:57:35 --> Model Class Initialized
DEBUG - 2011-07-18 18:57:35 --> Model Class Initialized
DEBUG - 2011-07-18 18:57:35 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-18 18:57:35 --> Database Driver Class Initialized
DEBUG - 2011-07-18 18:57:35 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-18 18:57:35 --> Helper loaded: url_helper
DEBUG - 2011-07-18 18:57:35 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-18 18:57:35 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-18 18:57:35 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-18 18:57:35 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-18 18:57:35 --> Final output sent to browser
DEBUG - 2011-07-18 18:57:35 --> Total execution time: 0.2294
DEBUG - 2011-07-18 18:57:36 --> Config Class Initialized
DEBUG - 2011-07-18 18:57:36 --> Hooks Class Initialized
DEBUG - 2011-07-18 18:57:36 --> Utf8 Class Initialized
DEBUG - 2011-07-18 18:57:36 --> UTF-8 Support Enabled
DEBUG - 2011-07-18 18:57:36 --> URI Class Initialized
DEBUG - 2011-07-18 18:57:36 --> Router Class Initialized
DEBUG - 2011-07-18 18:57:36 --> Output Class Initialized
DEBUG - 2011-07-18 18:57:36 --> Input Class Initialized
DEBUG - 2011-07-18 18:57:36 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-18 18:57:36 --> Language Class Initialized
DEBUG - 2011-07-18 18:57:36 --> Loader Class Initialized
DEBUG - 2011-07-18 18:57:36 --> Controller Class Initialized
DEBUG - 2011-07-18 18:57:36 --> Model Class Initialized
DEBUG - 2011-07-18 18:57:36 --> Model Class Initialized
DEBUG - 2011-07-18 18:57:36 --> Model Class Initialized
DEBUG - 2011-07-18 18:57:36 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-18 18:57:36 --> Database Driver Class Initialized
DEBUG - 2011-07-18 18:57:36 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-18 18:57:36 --> Helper loaded: url_helper
DEBUG - 2011-07-18 18:57:36 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-18 18:57:36 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-18 18:57:36 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-18 18:57:36 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-18 18:57:36 --> Final output sent to browser
DEBUG - 2011-07-18 18:57:36 --> Total execution time: 0.0803
DEBUG - 2011-07-18 18:58:03 --> Config Class Initialized
DEBUG - 2011-07-18 18:58:03 --> Hooks Class Initialized
DEBUG - 2011-07-18 18:58:03 --> Utf8 Class Initialized
DEBUG - 2011-07-18 18:58:03 --> UTF-8 Support Enabled
DEBUG - 2011-07-18 18:58:03 --> URI Class Initialized
DEBUG - 2011-07-18 18:58:03 --> Router Class Initialized
DEBUG - 2011-07-18 18:58:03 --> Output Class Initialized
DEBUG - 2011-07-18 18:58:03 --> Input Class Initialized
DEBUG - 2011-07-18 18:58:03 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-18 18:58:03 --> Language Class Initialized
DEBUG - 2011-07-18 18:58:03 --> Loader Class Initialized
DEBUG - 2011-07-18 18:58:03 --> Controller Class Initialized
DEBUG - 2011-07-18 18:58:03 --> Model Class Initialized
DEBUG - 2011-07-18 18:58:03 --> Model Class Initialized
DEBUG - 2011-07-18 18:58:03 --> Model Class Initialized
DEBUG - 2011-07-18 18:58:03 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-18 18:58:03 --> Database Driver Class Initialized
DEBUG - 2011-07-18 18:58:04 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-18 18:58:04 --> Helper loaded: url_helper
DEBUG - 2011-07-18 18:58:04 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-18 18:58:04 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-18 18:58:04 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-18 18:58:04 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-18 18:58:04 --> Final output sent to browser
DEBUG - 2011-07-18 18:58:04 --> Total execution time: 0.8068
DEBUG - 2011-07-18 18:58:05 --> Config Class Initialized
DEBUG - 2011-07-18 18:58:05 --> Hooks Class Initialized
DEBUG - 2011-07-18 18:58:05 --> Utf8 Class Initialized
DEBUG - 2011-07-18 18:58:05 --> UTF-8 Support Enabled
DEBUG - 2011-07-18 18:58:05 --> URI Class Initialized
DEBUG - 2011-07-18 18:58:05 --> Router Class Initialized
DEBUG - 2011-07-18 18:58:05 --> Output Class Initialized
DEBUG - 2011-07-18 18:58:05 --> Input Class Initialized
DEBUG - 2011-07-18 18:58:05 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-18 18:58:05 --> Language Class Initialized
DEBUG - 2011-07-18 18:58:05 --> Loader Class Initialized
DEBUG - 2011-07-18 18:58:05 --> Controller Class Initialized
DEBUG - 2011-07-18 18:58:05 --> Model Class Initialized
DEBUG - 2011-07-18 18:58:05 --> Model Class Initialized
DEBUG - 2011-07-18 18:58:05 --> Model Class Initialized
DEBUG - 2011-07-18 18:58:05 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-18 18:58:05 --> Database Driver Class Initialized
DEBUG - 2011-07-18 18:58:05 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-18 18:58:05 --> Helper loaded: url_helper
DEBUG - 2011-07-18 18:58:05 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-18 18:58:05 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-18 18:58:05 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-18 18:58:05 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-18 18:58:05 --> Final output sent to browser
DEBUG - 2011-07-18 18:58:05 --> Total execution time: 0.1088
DEBUG - 2011-07-18 18:58:11 --> Config Class Initialized
DEBUG - 2011-07-18 18:58:11 --> Hooks Class Initialized
DEBUG - 2011-07-18 18:58:11 --> Utf8 Class Initialized
DEBUG - 2011-07-18 18:58:11 --> UTF-8 Support Enabled
DEBUG - 2011-07-18 18:58:11 --> URI Class Initialized
DEBUG - 2011-07-18 18:58:11 --> Router Class Initialized
DEBUG - 2011-07-18 18:58:11 --> Output Class Initialized
DEBUG - 2011-07-18 18:58:11 --> Input Class Initialized
DEBUG - 2011-07-18 18:58:11 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-18 18:58:11 --> Language Class Initialized
DEBUG - 2011-07-18 18:58:11 --> Loader Class Initialized
DEBUG - 2011-07-18 18:58:11 --> Controller Class Initialized
DEBUG - 2011-07-18 18:58:11 --> Model Class Initialized
DEBUG - 2011-07-18 18:58:11 --> Model Class Initialized
DEBUG - 2011-07-18 18:58:11 --> Model Class Initialized
DEBUG - 2011-07-18 18:58:11 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-18 18:58:11 --> Database Driver Class Initialized
DEBUG - 2011-07-18 18:58:11 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-18 18:58:11 --> Helper loaded: url_helper
DEBUG - 2011-07-18 18:58:11 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-18 18:58:11 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-18 18:58:11 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-18 18:58:11 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-18 18:58:11 --> Final output sent to browser
DEBUG - 2011-07-18 18:58:11 --> Total execution time: 0.0663
DEBUG - 2011-07-18 18:58:20 --> Config Class Initialized
DEBUG - 2011-07-18 18:58:20 --> Hooks Class Initialized
DEBUG - 2011-07-18 18:58:20 --> Utf8 Class Initialized
DEBUG - 2011-07-18 18:58:20 --> UTF-8 Support Enabled
DEBUG - 2011-07-18 18:58:20 --> URI Class Initialized
DEBUG - 2011-07-18 18:58:20 --> Router Class Initialized
DEBUG - 2011-07-18 18:58:20 --> Output Class Initialized
DEBUG - 2011-07-18 18:58:20 --> Input Class Initialized
DEBUG - 2011-07-18 18:58:20 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-18 18:58:20 --> Language Class Initialized
DEBUG - 2011-07-18 18:58:20 --> Loader Class Initialized
DEBUG - 2011-07-18 18:58:20 --> Controller Class Initialized
DEBUG - 2011-07-18 18:58:20 --> Model Class Initialized
DEBUG - 2011-07-18 18:58:20 --> Model Class Initialized
DEBUG - 2011-07-18 18:58:20 --> Model Class Initialized
DEBUG - 2011-07-18 18:58:20 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-18 18:58:20 --> Database Driver Class Initialized
DEBUG - 2011-07-18 18:58:20 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-18 18:58:20 --> Helper loaded: url_helper
DEBUG - 2011-07-18 18:58:20 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-18 18:58:20 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-18 18:58:20 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-18 18:58:20 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-18 18:58:20 --> Final output sent to browser
DEBUG - 2011-07-18 18:58:20 --> Total execution time: 0.2758
DEBUG - 2011-07-18 18:58:21 --> Config Class Initialized
DEBUG - 2011-07-18 18:58:21 --> Hooks Class Initialized
DEBUG - 2011-07-18 18:58:21 --> Utf8 Class Initialized
DEBUG - 2011-07-18 18:58:21 --> UTF-8 Support Enabled
DEBUG - 2011-07-18 18:58:21 --> URI Class Initialized
DEBUG - 2011-07-18 18:58:21 --> Router Class Initialized
DEBUG - 2011-07-18 18:58:21 --> Output Class Initialized
DEBUG - 2011-07-18 18:58:21 --> Input Class Initialized
DEBUG - 2011-07-18 18:58:21 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-18 18:58:21 --> Language Class Initialized
DEBUG - 2011-07-18 18:58:21 --> Loader Class Initialized
DEBUG - 2011-07-18 18:58:21 --> Controller Class Initialized
DEBUG - 2011-07-18 18:58:21 --> Model Class Initialized
DEBUG - 2011-07-18 18:58:21 --> Model Class Initialized
DEBUG - 2011-07-18 18:58:21 --> Model Class Initialized
DEBUG - 2011-07-18 18:58:21 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-18 18:58:21 --> Database Driver Class Initialized
DEBUG - 2011-07-18 18:58:21 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-18 18:58:21 --> Helper loaded: url_helper
DEBUG - 2011-07-18 18:58:21 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-18 18:58:21 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-18 18:58:21 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-18 18:58:21 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-18 18:58:21 --> Final output sent to browser
DEBUG - 2011-07-18 18:58:21 --> Total execution time: 0.0490
DEBUG - 2011-07-18 18:58:35 --> Config Class Initialized
DEBUG - 2011-07-18 18:58:35 --> Hooks Class Initialized
DEBUG - 2011-07-18 18:58:35 --> Utf8 Class Initialized
DEBUG - 2011-07-18 18:58:35 --> UTF-8 Support Enabled
DEBUG - 2011-07-18 18:58:35 --> URI Class Initialized
DEBUG - 2011-07-18 18:58:35 --> Router Class Initialized
DEBUG - 2011-07-18 18:58:36 --> Output Class Initialized
DEBUG - 2011-07-18 18:58:36 --> Input Class Initialized
DEBUG - 2011-07-18 18:58:36 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-18 18:58:36 --> Language Class Initialized
DEBUG - 2011-07-18 18:58:36 --> Loader Class Initialized
DEBUG - 2011-07-18 18:58:36 --> Controller Class Initialized
DEBUG - 2011-07-18 18:58:36 --> Model Class Initialized
DEBUG - 2011-07-18 18:58:36 --> Model Class Initialized
DEBUG - 2011-07-18 18:58:36 --> Model Class Initialized
DEBUG - 2011-07-18 18:58:36 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-18 18:58:36 --> Database Driver Class Initialized
DEBUG - 2011-07-18 18:58:36 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-18 18:58:36 --> Helper loaded: url_helper
DEBUG - 2011-07-18 18:58:36 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-18 18:58:36 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-18 18:58:36 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-18 18:58:36 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-18 18:58:36 --> Final output sent to browser
DEBUG - 2011-07-18 18:58:36 --> Total execution time: 0.3570
DEBUG - 2011-07-18 18:58:37 --> Config Class Initialized
DEBUG - 2011-07-18 18:58:37 --> Hooks Class Initialized
DEBUG - 2011-07-18 18:58:37 --> Utf8 Class Initialized
DEBUG - 2011-07-18 18:58:37 --> UTF-8 Support Enabled
DEBUG - 2011-07-18 18:58:37 --> URI Class Initialized
DEBUG - 2011-07-18 18:58:37 --> Router Class Initialized
DEBUG - 2011-07-18 18:58:37 --> Output Class Initialized
DEBUG - 2011-07-18 18:58:37 --> Input Class Initialized
DEBUG - 2011-07-18 18:58:37 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-18 18:58:37 --> Language Class Initialized
DEBUG - 2011-07-18 18:58:37 --> Loader Class Initialized
DEBUG - 2011-07-18 18:58:37 --> Controller Class Initialized
DEBUG - 2011-07-18 18:58:37 --> Model Class Initialized
DEBUG - 2011-07-18 18:58:37 --> Model Class Initialized
DEBUG - 2011-07-18 18:58:37 --> Model Class Initialized
DEBUG - 2011-07-18 18:58:37 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-18 18:58:37 --> Database Driver Class Initialized
DEBUG - 2011-07-18 18:58:37 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-18 18:58:37 --> Helper loaded: url_helper
DEBUG - 2011-07-18 18:58:37 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-18 18:58:37 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-18 18:58:37 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-18 18:58:37 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-18 18:58:37 --> Final output sent to browser
DEBUG - 2011-07-18 18:58:37 --> Total execution time: 0.0473
DEBUG - 2011-07-18 18:58:47 --> Config Class Initialized
DEBUG - 2011-07-18 18:58:47 --> Hooks Class Initialized
DEBUG - 2011-07-18 18:58:47 --> Utf8 Class Initialized
DEBUG - 2011-07-18 18:58:47 --> UTF-8 Support Enabled
DEBUG - 2011-07-18 18:58:47 --> URI Class Initialized
DEBUG - 2011-07-18 18:58:47 --> Router Class Initialized
DEBUG - 2011-07-18 18:58:47 --> Output Class Initialized
DEBUG - 2011-07-18 18:58:47 --> Input Class Initialized
DEBUG - 2011-07-18 18:58:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-18 18:58:47 --> Language Class Initialized
DEBUG - 2011-07-18 18:58:47 --> Loader Class Initialized
DEBUG - 2011-07-18 18:58:47 --> Controller Class Initialized
DEBUG - 2011-07-18 18:58:47 --> Model Class Initialized
DEBUG - 2011-07-18 18:58:47 --> Model Class Initialized
DEBUG - 2011-07-18 18:58:47 --> Model Class Initialized
DEBUG - 2011-07-18 18:58:48 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-18 18:58:48 --> Database Driver Class Initialized
DEBUG - 2011-07-18 18:58:48 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-18 18:58:48 --> Helper loaded: url_helper
DEBUG - 2011-07-18 18:58:48 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-18 18:58:48 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-18 18:58:48 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-18 18:58:48 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-18 18:58:48 --> Final output sent to browser
DEBUG - 2011-07-18 18:58:48 --> Total execution time: 0.2792
DEBUG - 2011-07-18 18:58:49 --> Config Class Initialized
DEBUG - 2011-07-18 18:58:49 --> Hooks Class Initialized
DEBUG - 2011-07-18 18:58:49 --> Utf8 Class Initialized
DEBUG - 2011-07-18 18:58:49 --> UTF-8 Support Enabled
DEBUG - 2011-07-18 18:58:49 --> URI Class Initialized
DEBUG - 2011-07-18 18:58:49 --> Router Class Initialized
DEBUG - 2011-07-18 18:58:49 --> Output Class Initialized
DEBUG - 2011-07-18 18:58:49 --> Input Class Initialized
DEBUG - 2011-07-18 18:58:49 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-18 18:58:49 --> Language Class Initialized
DEBUG - 2011-07-18 18:58:49 --> Loader Class Initialized
DEBUG - 2011-07-18 18:58:49 --> Controller Class Initialized
DEBUG - 2011-07-18 18:58:49 --> Model Class Initialized
DEBUG - 2011-07-18 18:58:49 --> Model Class Initialized
DEBUG - 2011-07-18 18:58:49 --> Model Class Initialized
DEBUG - 2011-07-18 18:58:49 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-18 18:58:49 --> Database Driver Class Initialized
DEBUG - 2011-07-18 18:58:49 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-18 18:58:49 --> Helper loaded: url_helper
DEBUG - 2011-07-18 18:58:49 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-18 18:58:49 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-18 18:58:49 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-18 18:58:49 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-18 18:58:49 --> Final output sent to browser
DEBUG - 2011-07-18 18:58:49 --> Total execution time: 0.0582
DEBUG - 2011-07-18 18:58:57 --> Config Class Initialized
DEBUG - 2011-07-18 18:58:57 --> Hooks Class Initialized
DEBUG - 2011-07-18 18:58:57 --> Utf8 Class Initialized
DEBUG - 2011-07-18 18:58:57 --> UTF-8 Support Enabled
DEBUG - 2011-07-18 18:58:57 --> URI Class Initialized
DEBUG - 2011-07-18 18:58:57 --> Router Class Initialized
DEBUG - 2011-07-18 18:58:57 --> Output Class Initialized
DEBUG - 2011-07-18 18:58:57 --> Input Class Initialized
DEBUG - 2011-07-18 18:58:57 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-18 18:58:57 --> Language Class Initialized
DEBUG - 2011-07-18 18:58:57 --> Loader Class Initialized
DEBUG - 2011-07-18 18:58:57 --> Controller Class Initialized
DEBUG - 2011-07-18 18:58:57 --> Model Class Initialized
DEBUG - 2011-07-18 18:58:57 --> Model Class Initialized
DEBUG - 2011-07-18 18:58:57 --> Model Class Initialized
DEBUG - 2011-07-18 18:58:57 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-18 18:58:57 --> Database Driver Class Initialized
DEBUG - 2011-07-18 18:58:57 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-18 18:58:57 --> Helper loaded: url_helper
DEBUG - 2011-07-18 18:58:57 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-18 18:58:57 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-18 18:58:57 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-18 18:58:57 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-18 18:58:57 --> Final output sent to browser
DEBUG - 2011-07-18 18:58:57 --> Total execution time: 0.2029
DEBUG - 2011-07-18 18:58:59 --> Config Class Initialized
DEBUG - 2011-07-18 18:58:59 --> Hooks Class Initialized
DEBUG - 2011-07-18 18:58:59 --> Utf8 Class Initialized
DEBUG - 2011-07-18 18:58:59 --> UTF-8 Support Enabled
DEBUG - 2011-07-18 18:58:59 --> URI Class Initialized
DEBUG - 2011-07-18 18:58:59 --> Router Class Initialized
DEBUG - 2011-07-18 18:58:59 --> Output Class Initialized
DEBUG - 2011-07-18 18:58:59 --> Input Class Initialized
DEBUG - 2011-07-18 18:58:59 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-18 18:58:59 --> Language Class Initialized
DEBUG - 2011-07-18 18:58:59 --> Loader Class Initialized
DEBUG - 2011-07-18 18:58:59 --> Controller Class Initialized
DEBUG - 2011-07-18 18:58:59 --> Model Class Initialized
DEBUG - 2011-07-18 18:58:59 --> Model Class Initialized
DEBUG - 2011-07-18 18:58:59 --> Model Class Initialized
DEBUG - 2011-07-18 18:58:59 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-18 18:58:59 --> Database Driver Class Initialized
DEBUG - 2011-07-18 18:58:59 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-18 18:58:59 --> Helper loaded: url_helper
DEBUG - 2011-07-18 18:58:59 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-18 18:58:59 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-18 18:58:59 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-18 18:58:59 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-18 18:58:59 --> Final output sent to browser
DEBUG - 2011-07-18 18:58:59 --> Total execution time: 0.0627
DEBUG - 2011-07-18 18:59:11 --> Config Class Initialized
DEBUG - 2011-07-18 18:59:11 --> Hooks Class Initialized
DEBUG - 2011-07-18 18:59:11 --> Utf8 Class Initialized
DEBUG - 2011-07-18 18:59:11 --> UTF-8 Support Enabled
DEBUG - 2011-07-18 18:59:11 --> URI Class Initialized
DEBUG - 2011-07-18 18:59:11 --> Router Class Initialized
DEBUG - 2011-07-18 18:59:11 --> Output Class Initialized
DEBUG - 2011-07-18 18:59:11 --> Input Class Initialized
DEBUG - 2011-07-18 18:59:11 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-18 18:59:11 --> Language Class Initialized
DEBUG - 2011-07-18 18:59:11 --> Loader Class Initialized
DEBUG - 2011-07-18 18:59:11 --> Controller Class Initialized
DEBUG - 2011-07-18 18:59:11 --> Model Class Initialized
DEBUG - 2011-07-18 18:59:11 --> Model Class Initialized
DEBUG - 2011-07-18 18:59:11 --> Model Class Initialized
DEBUG - 2011-07-18 18:59:11 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-18 18:59:11 --> Database Driver Class Initialized
DEBUG - 2011-07-18 18:59:12 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-18 18:59:12 --> Helper loaded: url_helper
DEBUG - 2011-07-18 18:59:12 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-18 18:59:12 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-18 18:59:12 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-18 18:59:12 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-18 18:59:12 --> Final output sent to browser
DEBUG - 2011-07-18 18:59:12 --> Total execution time: 0.2441
DEBUG - 2011-07-18 18:59:12 --> Config Class Initialized
DEBUG - 2011-07-18 18:59:12 --> Hooks Class Initialized
DEBUG - 2011-07-18 18:59:12 --> Utf8 Class Initialized
DEBUG - 2011-07-18 18:59:12 --> UTF-8 Support Enabled
DEBUG - 2011-07-18 18:59:12 --> URI Class Initialized
DEBUG - 2011-07-18 18:59:12 --> Router Class Initialized
DEBUG - 2011-07-18 18:59:12 --> Output Class Initialized
DEBUG - 2011-07-18 18:59:12 --> Input Class Initialized
DEBUG - 2011-07-18 18:59:12 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-18 18:59:12 --> Language Class Initialized
DEBUG - 2011-07-18 18:59:12 --> Loader Class Initialized
DEBUG - 2011-07-18 18:59:12 --> Controller Class Initialized
DEBUG - 2011-07-18 18:59:12 --> Model Class Initialized
DEBUG - 2011-07-18 18:59:12 --> Model Class Initialized
DEBUG - 2011-07-18 18:59:12 --> Model Class Initialized
DEBUG - 2011-07-18 18:59:12 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-18 18:59:12 --> Database Driver Class Initialized
DEBUG - 2011-07-18 18:59:12 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-18 18:59:12 --> Helper loaded: url_helper
DEBUG - 2011-07-18 18:59:12 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-18 18:59:12 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-18 18:59:12 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-18 18:59:12 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-18 18:59:12 --> Final output sent to browser
DEBUG - 2011-07-18 18:59:12 --> Total execution time: 0.0501
DEBUG - 2011-07-18 18:59:22 --> Config Class Initialized
DEBUG - 2011-07-18 18:59:22 --> Hooks Class Initialized
DEBUG - 2011-07-18 18:59:22 --> Utf8 Class Initialized
DEBUG - 2011-07-18 18:59:22 --> UTF-8 Support Enabled
DEBUG - 2011-07-18 18:59:22 --> URI Class Initialized
DEBUG - 2011-07-18 18:59:22 --> Router Class Initialized
DEBUG - 2011-07-18 18:59:22 --> Output Class Initialized
DEBUG - 2011-07-18 18:59:22 --> Input Class Initialized
DEBUG - 2011-07-18 18:59:22 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-18 18:59:22 --> Language Class Initialized
DEBUG - 2011-07-18 18:59:22 --> Loader Class Initialized
DEBUG - 2011-07-18 18:59:22 --> Controller Class Initialized
DEBUG - 2011-07-18 18:59:22 --> Model Class Initialized
DEBUG - 2011-07-18 18:59:22 --> Model Class Initialized
DEBUG - 2011-07-18 18:59:22 --> Model Class Initialized
DEBUG - 2011-07-18 18:59:22 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-18 18:59:22 --> Database Driver Class Initialized
DEBUG - 2011-07-18 18:59:22 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-18 18:59:22 --> Helper loaded: url_helper
DEBUG - 2011-07-18 18:59:22 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-18 18:59:22 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-18 18:59:22 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-18 18:59:22 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-18 18:59:22 --> Final output sent to browser
DEBUG - 2011-07-18 18:59:22 --> Total execution time: 0.5931
DEBUG - 2011-07-18 18:59:23 --> Config Class Initialized
DEBUG - 2011-07-18 18:59:23 --> Hooks Class Initialized
DEBUG - 2011-07-18 18:59:23 --> Utf8 Class Initialized
DEBUG - 2011-07-18 18:59:23 --> UTF-8 Support Enabled
DEBUG - 2011-07-18 18:59:23 --> URI Class Initialized
DEBUG - 2011-07-18 18:59:23 --> Router Class Initialized
DEBUG - 2011-07-18 18:59:23 --> Output Class Initialized
DEBUG - 2011-07-18 18:59:23 --> Input Class Initialized
DEBUG - 2011-07-18 18:59:23 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-18 18:59:23 --> Language Class Initialized
DEBUG - 2011-07-18 18:59:23 --> Loader Class Initialized
DEBUG - 2011-07-18 18:59:23 --> Controller Class Initialized
DEBUG - 2011-07-18 18:59:23 --> Model Class Initialized
DEBUG - 2011-07-18 18:59:23 --> Model Class Initialized
DEBUG - 2011-07-18 18:59:23 --> Model Class Initialized
DEBUG - 2011-07-18 18:59:23 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-18 18:59:23 --> Database Driver Class Initialized
DEBUG - 2011-07-18 18:59:23 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-18 18:59:23 --> Helper loaded: url_helper
DEBUG - 2011-07-18 18:59:23 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-18 18:59:23 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-18 18:59:23 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-18 18:59:23 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-18 18:59:23 --> Final output sent to browser
DEBUG - 2011-07-18 18:59:23 --> Total execution time: 0.0493
DEBUG - 2011-07-18 18:59:30 --> Config Class Initialized
DEBUG - 2011-07-18 18:59:30 --> Hooks Class Initialized
DEBUG - 2011-07-18 18:59:30 --> Utf8 Class Initialized
DEBUG - 2011-07-18 18:59:30 --> UTF-8 Support Enabled
DEBUG - 2011-07-18 18:59:30 --> URI Class Initialized
DEBUG - 2011-07-18 18:59:30 --> Router Class Initialized
DEBUG - 2011-07-18 18:59:30 --> Output Class Initialized
DEBUG - 2011-07-18 18:59:30 --> Input Class Initialized
DEBUG - 2011-07-18 18:59:30 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-18 18:59:30 --> Language Class Initialized
DEBUG - 2011-07-18 18:59:30 --> Loader Class Initialized
DEBUG - 2011-07-18 18:59:30 --> Controller Class Initialized
DEBUG - 2011-07-18 18:59:30 --> Model Class Initialized
DEBUG - 2011-07-18 18:59:30 --> Model Class Initialized
DEBUG - 2011-07-18 18:59:30 --> Model Class Initialized
DEBUG - 2011-07-18 18:59:30 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-18 18:59:30 --> Database Driver Class Initialized
DEBUG - 2011-07-18 18:59:30 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-18 18:59:30 --> Helper loaded: url_helper
DEBUG - 2011-07-18 18:59:30 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-18 18:59:30 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-18 18:59:30 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-18 18:59:30 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-18 18:59:30 --> Final output sent to browser
DEBUG - 2011-07-18 18:59:30 --> Total execution time: 0.4788
DEBUG - 2011-07-18 18:59:31 --> Config Class Initialized
DEBUG - 2011-07-18 18:59:31 --> Hooks Class Initialized
DEBUG - 2011-07-18 18:59:31 --> Utf8 Class Initialized
DEBUG - 2011-07-18 18:59:31 --> UTF-8 Support Enabled
DEBUG - 2011-07-18 18:59:31 --> URI Class Initialized
DEBUG - 2011-07-18 18:59:31 --> Router Class Initialized
DEBUG - 2011-07-18 18:59:31 --> Output Class Initialized
DEBUG - 2011-07-18 18:59:31 --> Input Class Initialized
DEBUG - 2011-07-18 18:59:31 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-18 18:59:31 --> Language Class Initialized
DEBUG - 2011-07-18 18:59:31 --> Loader Class Initialized
DEBUG - 2011-07-18 18:59:31 --> Controller Class Initialized
DEBUG - 2011-07-18 18:59:31 --> Model Class Initialized
DEBUG - 2011-07-18 18:59:31 --> Model Class Initialized
DEBUG - 2011-07-18 18:59:31 --> Model Class Initialized
DEBUG - 2011-07-18 18:59:31 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-18 18:59:31 --> Database Driver Class Initialized
DEBUG - 2011-07-18 18:59:31 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-18 18:59:31 --> Helper loaded: url_helper
DEBUG - 2011-07-18 18:59:31 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-18 18:59:31 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-18 18:59:31 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-18 18:59:31 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-18 18:59:31 --> Final output sent to browser
DEBUG - 2011-07-18 18:59:31 --> Total execution time: 0.0509
DEBUG - 2011-07-18 19:00:31 --> Config Class Initialized
DEBUG - 2011-07-18 19:00:31 --> Hooks Class Initialized
DEBUG - 2011-07-18 19:00:31 --> Utf8 Class Initialized
DEBUG - 2011-07-18 19:00:31 --> UTF-8 Support Enabled
DEBUG - 2011-07-18 19:00:31 --> URI Class Initialized
DEBUG - 2011-07-18 19:00:31 --> Router Class Initialized
DEBUG - 2011-07-18 19:00:31 --> Output Class Initialized
DEBUG - 2011-07-18 19:00:31 --> Input Class Initialized
DEBUG - 2011-07-18 19:00:31 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-18 19:00:31 --> Language Class Initialized
DEBUG - 2011-07-18 19:00:31 --> Loader Class Initialized
DEBUG - 2011-07-18 19:00:31 --> Controller Class Initialized
DEBUG - 2011-07-18 19:00:31 --> Model Class Initialized
DEBUG - 2011-07-18 19:00:31 --> Model Class Initialized
DEBUG - 2011-07-18 19:00:31 --> Model Class Initialized
DEBUG - 2011-07-18 19:00:31 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-18 19:00:31 --> Database Driver Class Initialized
DEBUG - 2011-07-18 19:00:33 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-18 19:00:33 --> Helper loaded: url_helper
DEBUG - 2011-07-18 19:00:33 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-18 19:00:33 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-18 19:00:33 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-18 19:00:33 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-18 19:00:33 --> Final output sent to browser
DEBUG - 2011-07-18 19:00:33 --> Total execution time: 2.0814
DEBUG - 2011-07-18 19:00:43 --> Config Class Initialized
DEBUG - 2011-07-18 19:00:43 --> Hooks Class Initialized
DEBUG - 2011-07-18 19:00:43 --> Utf8 Class Initialized
DEBUG - 2011-07-18 19:00:43 --> UTF-8 Support Enabled
DEBUG - 2011-07-18 19:00:43 --> URI Class Initialized
DEBUG - 2011-07-18 19:00:43 --> Router Class Initialized
DEBUG - 2011-07-18 19:00:43 --> Output Class Initialized
DEBUG - 2011-07-18 19:00:44 --> Input Class Initialized
DEBUG - 2011-07-18 19:00:44 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-18 19:00:44 --> Language Class Initialized
DEBUG - 2011-07-18 19:00:44 --> Loader Class Initialized
DEBUG - 2011-07-18 19:00:44 --> Controller Class Initialized
DEBUG - 2011-07-18 19:00:44 --> Model Class Initialized
DEBUG - 2011-07-18 19:00:44 --> Model Class Initialized
DEBUG - 2011-07-18 19:00:44 --> Model Class Initialized
DEBUG - 2011-07-18 19:00:44 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-18 19:00:44 --> Database Driver Class Initialized
DEBUG - 2011-07-18 19:00:47 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-18 19:00:47 --> Helper loaded: url_helper
DEBUG - 2011-07-18 19:00:47 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-18 19:00:47 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-18 19:00:47 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-18 19:00:47 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-18 19:00:47 --> Final output sent to browser
DEBUG - 2011-07-18 19:00:47 --> Total execution time: 3.9321
DEBUG - 2011-07-18 19:00:59 --> Config Class Initialized
DEBUG - 2011-07-18 19:00:59 --> Hooks Class Initialized
DEBUG - 2011-07-18 19:00:59 --> Utf8 Class Initialized
DEBUG - 2011-07-18 19:00:59 --> UTF-8 Support Enabled
DEBUG - 2011-07-18 19:00:59 --> URI Class Initialized
DEBUG - 2011-07-18 19:00:59 --> Router Class Initialized
DEBUG - 2011-07-18 19:00:59 --> Output Class Initialized
DEBUG - 2011-07-18 19:00:59 --> Input Class Initialized
DEBUG - 2011-07-18 19:00:59 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-18 19:00:59 --> Language Class Initialized
DEBUG - 2011-07-18 19:00:59 --> Loader Class Initialized
DEBUG - 2011-07-18 19:00:59 --> Controller Class Initialized
DEBUG - 2011-07-18 19:00:59 --> Model Class Initialized
DEBUG - 2011-07-18 19:00:59 --> Model Class Initialized
DEBUG - 2011-07-18 19:00:59 --> Model Class Initialized
DEBUG - 2011-07-18 19:00:59 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-18 19:00:59 --> Database Driver Class Initialized
DEBUG - 2011-07-18 19:01:00 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-18 19:01:00 --> Helper loaded: url_helper
DEBUG - 2011-07-18 19:01:00 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-18 19:01:00 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-18 19:01:00 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-18 19:01:00 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-18 19:01:00 --> Final output sent to browser
DEBUG - 2011-07-18 19:01:00 --> Total execution time: 1.1085
DEBUG - 2011-07-18 19:01:04 --> Config Class Initialized
DEBUG - 2011-07-18 19:01:04 --> Hooks Class Initialized
DEBUG - 2011-07-18 19:01:04 --> Utf8 Class Initialized
DEBUG - 2011-07-18 19:01:04 --> UTF-8 Support Enabled
DEBUG - 2011-07-18 19:01:04 --> URI Class Initialized
DEBUG - 2011-07-18 19:01:04 --> Router Class Initialized
DEBUG - 2011-07-18 19:01:04 --> Output Class Initialized
DEBUG - 2011-07-18 19:01:04 --> Input Class Initialized
DEBUG - 2011-07-18 19:01:04 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-18 19:01:04 --> Language Class Initialized
DEBUG - 2011-07-18 19:01:04 --> Loader Class Initialized
DEBUG - 2011-07-18 19:01:04 --> Controller Class Initialized
DEBUG - 2011-07-18 19:01:04 --> Model Class Initialized
DEBUG - 2011-07-18 19:01:04 --> Model Class Initialized
DEBUG - 2011-07-18 19:01:04 --> Model Class Initialized
DEBUG - 2011-07-18 19:01:04 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-18 19:01:04 --> Database Driver Class Initialized
DEBUG - 2011-07-18 19:01:04 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-18 19:01:04 --> Helper loaded: url_helper
DEBUG - 2011-07-18 19:01:04 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-18 19:01:04 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-18 19:01:04 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-18 19:01:04 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-18 19:01:04 --> Final output sent to browser
DEBUG - 2011-07-18 19:01:04 --> Total execution time: 0.1693
DEBUG - 2011-07-18 19:01:11 --> Config Class Initialized
DEBUG - 2011-07-18 19:01:11 --> Hooks Class Initialized
DEBUG - 2011-07-18 19:01:11 --> Utf8 Class Initialized
DEBUG - 2011-07-18 19:01:11 --> UTF-8 Support Enabled
DEBUG - 2011-07-18 19:01:11 --> URI Class Initialized
DEBUG - 2011-07-18 19:01:11 --> Router Class Initialized
DEBUG - 2011-07-18 19:01:11 --> Output Class Initialized
DEBUG - 2011-07-18 19:01:11 --> Input Class Initialized
DEBUG - 2011-07-18 19:01:11 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-18 19:01:11 --> Language Class Initialized
DEBUG - 2011-07-18 19:01:11 --> Loader Class Initialized
DEBUG - 2011-07-18 19:01:11 --> Controller Class Initialized
DEBUG - 2011-07-18 19:01:11 --> Model Class Initialized
DEBUG - 2011-07-18 19:01:11 --> Model Class Initialized
DEBUG - 2011-07-18 19:01:11 --> Model Class Initialized
DEBUG - 2011-07-18 19:01:11 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-18 19:01:11 --> Database Driver Class Initialized
DEBUG - 2011-07-18 19:01:12 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-18 19:01:12 --> Helper loaded: url_helper
DEBUG - 2011-07-18 19:01:12 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-18 19:01:12 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-18 19:01:12 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-18 19:01:12 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-18 19:01:12 --> Final output sent to browser
DEBUG - 2011-07-18 19:01:12 --> Total execution time: 0.2103
DEBUG - 2011-07-18 19:01:18 --> Config Class Initialized
DEBUG - 2011-07-18 19:01:18 --> Hooks Class Initialized
DEBUG - 2011-07-18 19:01:18 --> Utf8 Class Initialized
DEBUG - 2011-07-18 19:01:18 --> UTF-8 Support Enabled
DEBUG - 2011-07-18 19:01:18 --> URI Class Initialized
DEBUG - 2011-07-18 19:01:18 --> Router Class Initialized
DEBUG - 2011-07-18 19:01:18 --> Output Class Initialized
DEBUG - 2011-07-18 19:01:18 --> Input Class Initialized
DEBUG - 2011-07-18 19:01:18 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-18 19:01:18 --> Language Class Initialized
DEBUG - 2011-07-18 19:01:18 --> Loader Class Initialized
DEBUG - 2011-07-18 19:01:18 --> Controller Class Initialized
DEBUG - 2011-07-18 19:01:18 --> Model Class Initialized
DEBUG - 2011-07-18 19:01:18 --> Model Class Initialized
DEBUG - 2011-07-18 19:01:18 --> Model Class Initialized
DEBUG - 2011-07-18 19:01:18 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-18 19:01:18 --> Database Driver Class Initialized
DEBUG - 2011-07-18 19:01:18 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-18 19:01:18 --> Helper loaded: url_helper
DEBUG - 2011-07-18 19:01:18 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-18 19:01:18 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-18 19:01:18 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-18 19:01:18 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-18 19:01:18 --> Final output sent to browser
DEBUG - 2011-07-18 19:01:18 --> Total execution time: 0.2033
DEBUG - 2011-07-18 19:01:20 --> Config Class Initialized
DEBUG - 2011-07-18 19:01:20 --> Hooks Class Initialized
DEBUG - 2011-07-18 19:01:20 --> Utf8 Class Initialized
DEBUG - 2011-07-18 19:01:20 --> UTF-8 Support Enabled
DEBUG - 2011-07-18 19:01:20 --> URI Class Initialized
DEBUG - 2011-07-18 19:01:20 --> Router Class Initialized
DEBUG - 2011-07-18 19:01:20 --> Output Class Initialized
DEBUG - 2011-07-18 19:01:20 --> Input Class Initialized
DEBUG - 2011-07-18 19:01:20 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-18 19:01:20 --> Language Class Initialized
DEBUG - 2011-07-18 19:01:20 --> Loader Class Initialized
DEBUG - 2011-07-18 19:01:20 --> Controller Class Initialized
DEBUG - 2011-07-18 19:01:20 --> Model Class Initialized
DEBUG - 2011-07-18 19:01:20 --> Model Class Initialized
DEBUG - 2011-07-18 19:01:20 --> Model Class Initialized
DEBUG - 2011-07-18 19:01:20 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-18 19:01:20 --> Database Driver Class Initialized
DEBUG - 2011-07-18 19:01:20 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-18 19:01:20 --> Helper loaded: url_helper
DEBUG - 2011-07-18 19:01:20 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-18 19:01:20 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-18 19:01:20 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-18 19:01:20 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-18 19:01:20 --> Final output sent to browser
DEBUG - 2011-07-18 19:01:20 --> Total execution time: 0.0498
DEBUG - 2011-07-18 19:01:24 --> Config Class Initialized
DEBUG - 2011-07-18 19:01:24 --> Hooks Class Initialized
DEBUG - 2011-07-18 19:01:24 --> Utf8 Class Initialized
DEBUG - 2011-07-18 19:01:24 --> UTF-8 Support Enabled
DEBUG - 2011-07-18 19:01:24 --> URI Class Initialized
DEBUG - 2011-07-18 19:01:24 --> Router Class Initialized
DEBUG - 2011-07-18 19:01:24 --> Output Class Initialized
DEBUG - 2011-07-18 19:01:24 --> Input Class Initialized
DEBUG - 2011-07-18 19:01:24 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-18 19:01:24 --> Language Class Initialized
DEBUG - 2011-07-18 19:01:24 --> Loader Class Initialized
DEBUG - 2011-07-18 19:01:24 --> Controller Class Initialized
DEBUG - 2011-07-18 19:01:24 --> Model Class Initialized
DEBUG - 2011-07-18 19:01:24 --> Model Class Initialized
DEBUG - 2011-07-18 19:01:24 --> Model Class Initialized
DEBUG - 2011-07-18 19:01:24 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-18 19:01:24 --> Database Driver Class Initialized
DEBUG - 2011-07-18 19:01:24 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-18 19:01:24 --> Helper loaded: url_helper
DEBUG - 2011-07-18 19:01:24 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-18 19:01:24 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-18 19:01:24 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-18 19:01:24 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-18 19:01:24 --> Final output sent to browser
DEBUG - 2011-07-18 19:01:24 --> Total execution time: 0.0525
DEBUG - 2011-07-18 19:01:26 --> Config Class Initialized
DEBUG - 2011-07-18 19:01:26 --> Hooks Class Initialized
DEBUG - 2011-07-18 19:01:26 --> Utf8 Class Initialized
DEBUG - 2011-07-18 19:01:26 --> UTF-8 Support Enabled
DEBUG - 2011-07-18 19:01:26 --> URI Class Initialized
DEBUG - 2011-07-18 19:01:26 --> Router Class Initialized
DEBUG - 2011-07-18 19:01:26 --> Output Class Initialized
DEBUG - 2011-07-18 19:01:26 --> Input Class Initialized
DEBUG - 2011-07-18 19:01:26 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-18 19:01:26 --> Language Class Initialized
DEBUG - 2011-07-18 19:01:26 --> Loader Class Initialized
DEBUG - 2011-07-18 19:01:26 --> Controller Class Initialized
DEBUG - 2011-07-18 19:01:26 --> Model Class Initialized
DEBUG - 2011-07-18 19:01:26 --> Model Class Initialized
DEBUG - 2011-07-18 19:01:26 --> Model Class Initialized
DEBUG - 2011-07-18 19:01:26 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-18 19:01:26 --> Database Driver Class Initialized
DEBUG - 2011-07-18 19:01:26 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-18 19:01:26 --> Helper loaded: url_helper
DEBUG - 2011-07-18 19:01:26 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-18 19:01:26 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-18 19:01:26 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-18 19:01:26 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-18 19:01:26 --> Final output sent to browser
DEBUG - 2011-07-18 19:01:26 --> Total execution time: 0.2144
DEBUG - 2011-07-18 19:01:29 --> Config Class Initialized
DEBUG - 2011-07-18 19:01:29 --> Hooks Class Initialized
DEBUG - 2011-07-18 19:01:29 --> Utf8 Class Initialized
DEBUG - 2011-07-18 19:01:29 --> UTF-8 Support Enabled
DEBUG - 2011-07-18 19:01:29 --> URI Class Initialized
DEBUG - 2011-07-18 19:01:29 --> Router Class Initialized
DEBUG - 2011-07-18 19:01:29 --> Output Class Initialized
DEBUG - 2011-07-18 19:01:29 --> Input Class Initialized
DEBUG - 2011-07-18 19:01:29 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-18 19:01:29 --> Language Class Initialized
DEBUG - 2011-07-18 19:01:29 --> Loader Class Initialized
DEBUG - 2011-07-18 19:01:29 --> Controller Class Initialized
DEBUG - 2011-07-18 19:01:29 --> Model Class Initialized
DEBUG - 2011-07-18 19:01:29 --> Model Class Initialized
DEBUG - 2011-07-18 19:01:29 --> Model Class Initialized
DEBUG - 2011-07-18 19:01:29 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-18 19:01:29 --> Database Driver Class Initialized
DEBUG - 2011-07-18 19:01:29 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-18 19:01:29 --> Helper loaded: url_helper
DEBUG - 2011-07-18 19:01:29 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-18 19:01:29 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-18 19:01:29 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-18 19:01:29 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-18 19:01:29 --> Final output sent to browser
DEBUG - 2011-07-18 19:01:29 --> Total execution time: 0.0712
DEBUG - 2011-07-18 19:01:30 --> Config Class Initialized
DEBUG - 2011-07-18 19:01:30 --> Hooks Class Initialized
DEBUG - 2011-07-18 19:01:30 --> Utf8 Class Initialized
DEBUG - 2011-07-18 19:01:30 --> UTF-8 Support Enabled
DEBUG - 2011-07-18 19:01:30 --> URI Class Initialized
DEBUG - 2011-07-18 19:01:30 --> Router Class Initialized
DEBUG - 2011-07-18 19:01:30 --> Output Class Initialized
DEBUG - 2011-07-18 19:01:30 --> Input Class Initialized
DEBUG - 2011-07-18 19:01:30 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-18 19:01:30 --> Language Class Initialized
DEBUG - 2011-07-18 19:01:30 --> Loader Class Initialized
DEBUG - 2011-07-18 19:01:30 --> Controller Class Initialized
DEBUG - 2011-07-18 19:01:30 --> Model Class Initialized
DEBUG - 2011-07-18 19:01:30 --> Model Class Initialized
DEBUG - 2011-07-18 19:01:30 --> Model Class Initialized
DEBUG - 2011-07-18 19:01:30 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-18 19:01:31 --> Database Driver Class Initialized
DEBUG - 2011-07-18 19:01:31 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-18 19:01:31 --> Helper loaded: url_helper
DEBUG - 2011-07-18 19:01:31 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-18 19:01:31 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-18 19:01:31 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-18 19:01:31 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-18 19:01:31 --> Final output sent to browser
DEBUG - 2011-07-18 19:01:31 --> Total execution time: 0.0479
DEBUG - 2011-07-18 19:01:33 --> Config Class Initialized
DEBUG - 2011-07-18 19:01:33 --> Hooks Class Initialized
DEBUG - 2011-07-18 19:01:33 --> Utf8 Class Initialized
DEBUG - 2011-07-18 19:01:33 --> UTF-8 Support Enabled
DEBUG - 2011-07-18 19:01:33 --> URI Class Initialized
DEBUG - 2011-07-18 19:01:33 --> Router Class Initialized
DEBUG - 2011-07-18 19:01:33 --> Output Class Initialized
DEBUG - 2011-07-18 19:01:33 --> Input Class Initialized
DEBUG - 2011-07-18 19:01:33 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-18 19:01:33 --> Language Class Initialized
DEBUG - 2011-07-18 19:01:33 --> Loader Class Initialized
DEBUG - 2011-07-18 19:01:33 --> Controller Class Initialized
DEBUG - 2011-07-18 19:01:33 --> Model Class Initialized
DEBUG - 2011-07-18 19:01:33 --> Model Class Initialized
DEBUG - 2011-07-18 19:01:33 --> Model Class Initialized
DEBUG - 2011-07-18 19:01:33 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-18 19:01:33 --> Database Driver Class Initialized
DEBUG - 2011-07-18 19:01:33 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-18 19:01:33 --> Helper loaded: url_helper
DEBUG - 2011-07-18 19:01:33 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-18 19:01:33 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-18 19:01:33 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-18 19:01:33 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-18 19:01:33 --> Final output sent to browser
DEBUG - 2011-07-18 19:01:33 --> Total execution time: 0.0572
DEBUG - 2011-07-18 19:15:35 --> Config Class Initialized
DEBUG - 2011-07-18 19:15:35 --> Hooks Class Initialized
DEBUG - 2011-07-18 19:15:35 --> Utf8 Class Initialized
DEBUG - 2011-07-18 19:15:35 --> UTF-8 Support Enabled
DEBUG - 2011-07-18 19:15:35 --> URI Class Initialized
DEBUG - 2011-07-18 19:15:35 --> Router Class Initialized
DEBUG - 2011-07-18 19:15:35 --> Output Class Initialized
DEBUG - 2011-07-18 19:15:35 --> Input Class Initialized
DEBUG - 2011-07-18 19:15:35 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-18 19:15:35 --> Language Class Initialized
DEBUG - 2011-07-18 19:15:35 --> Loader Class Initialized
DEBUG - 2011-07-18 19:15:35 --> Controller Class Initialized
DEBUG - 2011-07-18 19:15:35 --> Model Class Initialized
DEBUG - 2011-07-18 19:15:35 --> Model Class Initialized
DEBUG - 2011-07-18 19:15:35 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-18 19:15:35 --> Database Driver Class Initialized
DEBUG - 2011-07-18 19:15:36 --> Final output sent to browser
DEBUG - 2011-07-18 19:15:36 --> Total execution time: 0.6891
DEBUG - 2011-07-18 19:26:12 --> Config Class Initialized
DEBUG - 2011-07-18 19:26:12 --> Hooks Class Initialized
DEBUG - 2011-07-18 19:26:12 --> Utf8 Class Initialized
DEBUG - 2011-07-18 19:26:12 --> UTF-8 Support Enabled
DEBUG - 2011-07-18 19:26:12 --> URI Class Initialized
DEBUG - 2011-07-18 19:26:12 --> Router Class Initialized
DEBUG - 2011-07-18 19:26:12 --> Output Class Initialized
DEBUG - 2011-07-18 19:26:12 --> Input Class Initialized
DEBUG - 2011-07-18 19:26:12 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-18 19:26:12 --> Language Class Initialized
DEBUG - 2011-07-18 19:26:12 --> Loader Class Initialized
DEBUG - 2011-07-18 19:26:12 --> Controller Class Initialized
ERROR - 2011-07-18 19:26:12 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-18 19:26:12 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-18 19:26:12 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-18 19:26:12 --> Model Class Initialized
DEBUG - 2011-07-18 19:26:12 --> Model Class Initialized
DEBUG - 2011-07-18 19:26:12 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-18 19:26:12 --> Database Driver Class Initialized
DEBUG - 2011-07-18 19:26:12 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-18 19:26:12 --> Helper loaded: url_helper
DEBUG - 2011-07-18 19:26:12 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-18 19:26:12 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-18 19:26:12 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-18 19:26:12 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-18 19:26:12 --> Final output sent to browser
DEBUG - 2011-07-18 19:26:12 --> Total execution time: 0.2661
DEBUG - 2011-07-18 21:20:19 --> Config Class Initialized
DEBUG - 2011-07-18 21:20:19 --> Hooks Class Initialized
DEBUG - 2011-07-18 21:20:19 --> Utf8 Class Initialized
DEBUG - 2011-07-18 21:20:19 --> UTF-8 Support Enabled
DEBUG - 2011-07-18 21:20:19 --> URI Class Initialized
DEBUG - 2011-07-18 21:20:19 --> Router Class Initialized
DEBUG - 2011-07-18 21:20:19 --> Output Class Initialized
DEBUG - 2011-07-18 21:20:19 --> Input Class Initialized
DEBUG - 2011-07-18 21:20:19 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-18 21:20:19 --> Language Class Initialized
DEBUG - 2011-07-18 21:20:19 --> Loader Class Initialized
DEBUG - 2011-07-18 21:20:19 --> Controller Class Initialized
DEBUG - 2011-07-18 21:20:19 --> Model Class Initialized
DEBUG - 2011-07-18 21:20:19 --> Model Class Initialized
DEBUG - 2011-07-18 21:20:19 --> Model Class Initialized
DEBUG - 2011-07-18 21:20:19 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-18 21:20:19 --> Database Driver Class Initialized
DEBUG - 2011-07-18 21:20:21 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-18 21:20:21 --> Helper loaded: url_helper
DEBUG - 2011-07-18 21:20:21 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-18 21:20:21 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-18 21:20:21 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-18 21:20:21 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-18 21:20:21 --> Final output sent to browser
DEBUG - 2011-07-18 21:20:21 --> Total execution time: 2.2499
DEBUG - 2011-07-18 21:20:25 --> Config Class Initialized
DEBUG - 2011-07-18 21:20:25 --> Hooks Class Initialized
DEBUG - 2011-07-18 21:20:25 --> Utf8 Class Initialized
DEBUG - 2011-07-18 21:20:25 --> UTF-8 Support Enabled
DEBUG - 2011-07-18 21:20:25 --> URI Class Initialized
DEBUG - 2011-07-18 21:20:25 --> Router Class Initialized
ERROR - 2011-07-18 21:20:25 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-18 21:21:16 --> Config Class Initialized
DEBUG - 2011-07-18 21:21:16 --> Hooks Class Initialized
DEBUG - 2011-07-18 21:21:16 --> Utf8 Class Initialized
DEBUG - 2011-07-18 21:21:16 --> UTF-8 Support Enabled
DEBUG - 2011-07-18 21:21:16 --> URI Class Initialized
DEBUG - 2011-07-18 21:21:16 --> Router Class Initialized
DEBUG - 2011-07-18 21:21:16 --> Output Class Initialized
DEBUG - 2011-07-18 21:21:16 --> Input Class Initialized
DEBUG - 2011-07-18 21:21:16 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-18 21:21:16 --> Language Class Initialized
DEBUG - 2011-07-18 21:21:16 --> Loader Class Initialized
DEBUG - 2011-07-18 21:21:16 --> Controller Class Initialized
DEBUG - 2011-07-18 21:21:16 --> Model Class Initialized
DEBUG - 2011-07-18 21:21:16 --> Model Class Initialized
DEBUG - 2011-07-18 21:21:16 --> Model Class Initialized
DEBUG - 2011-07-18 21:21:16 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-18 21:21:16 --> Database Driver Class Initialized
DEBUG - 2011-07-18 21:21:17 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-18 21:21:17 --> Helper loaded: url_helper
DEBUG - 2011-07-18 21:21:17 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-18 21:21:17 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-18 21:21:17 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-18 21:21:17 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-18 21:21:17 --> Final output sent to browser
DEBUG - 2011-07-18 21:21:17 --> Total execution time: 1.1564
DEBUG - 2011-07-18 21:21:21 --> Config Class Initialized
DEBUG - 2011-07-18 21:21:21 --> Hooks Class Initialized
DEBUG - 2011-07-18 21:21:21 --> Utf8 Class Initialized
DEBUG - 2011-07-18 21:21:21 --> UTF-8 Support Enabled
DEBUG - 2011-07-18 21:21:21 --> URI Class Initialized
DEBUG - 2011-07-18 21:21:21 --> Router Class Initialized
DEBUG - 2011-07-18 21:21:21 --> Output Class Initialized
DEBUG - 2011-07-18 21:21:21 --> Input Class Initialized
DEBUG - 2011-07-18 21:21:21 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-18 21:21:21 --> Language Class Initialized
DEBUG - 2011-07-18 21:21:21 --> Loader Class Initialized
DEBUG - 2011-07-18 21:21:21 --> Controller Class Initialized
DEBUG - 2011-07-18 21:21:21 --> Model Class Initialized
DEBUG - 2011-07-18 21:21:21 --> Model Class Initialized
DEBUG - 2011-07-18 21:21:21 --> Model Class Initialized
DEBUG - 2011-07-18 21:21:21 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-18 21:21:21 --> Database Driver Class Initialized
DEBUG - 2011-07-18 21:21:21 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-18 21:21:21 --> Helper loaded: url_helper
DEBUG - 2011-07-18 21:21:21 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-18 21:21:21 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-18 21:21:21 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-18 21:21:21 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-18 21:21:21 --> Final output sent to browser
DEBUG - 2011-07-18 21:21:21 --> Total execution time: 0.2898
DEBUG - 2011-07-18 21:21:58 --> Config Class Initialized
DEBUG - 2011-07-18 21:21:58 --> Hooks Class Initialized
DEBUG - 2011-07-18 21:21:58 --> Utf8 Class Initialized
DEBUG - 2011-07-18 21:21:58 --> UTF-8 Support Enabled
DEBUG - 2011-07-18 21:21:58 --> URI Class Initialized
DEBUG - 2011-07-18 21:21:58 --> Router Class Initialized
DEBUG - 2011-07-18 21:21:58 --> Output Class Initialized
DEBUG - 2011-07-18 21:21:58 --> Input Class Initialized
DEBUG - 2011-07-18 21:21:58 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-18 21:21:58 --> Language Class Initialized
DEBUG - 2011-07-18 21:21:58 --> Loader Class Initialized
DEBUG - 2011-07-18 21:21:58 --> Controller Class Initialized
DEBUG - 2011-07-18 21:21:58 --> Model Class Initialized
DEBUG - 2011-07-18 21:21:58 --> Model Class Initialized
DEBUG - 2011-07-18 21:21:58 --> Model Class Initialized
DEBUG - 2011-07-18 21:21:58 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-18 21:21:58 --> Database Driver Class Initialized
DEBUG - 2011-07-18 21:21:58 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-18 21:21:58 --> Helper loaded: url_helper
DEBUG - 2011-07-18 21:21:58 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-18 21:21:58 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-18 21:21:58 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-18 21:21:58 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-18 21:21:58 --> Final output sent to browser
DEBUG - 2011-07-18 21:21:58 --> Total execution time: 0.3030
DEBUG - 2011-07-18 21:22:00 --> Config Class Initialized
DEBUG - 2011-07-18 21:22:00 --> Hooks Class Initialized
DEBUG - 2011-07-18 21:22:00 --> Utf8 Class Initialized
DEBUG - 2011-07-18 21:22:00 --> UTF-8 Support Enabled
DEBUG - 2011-07-18 21:22:00 --> URI Class Initialized
DEBUG - 2011-07-18 21:22:00 --> Router Class Initialized
DEBUG - 2011-07-18 21:22:00 --> Output Class Initialized
DEBUG - 2011-07-18 21:22:00 --> Input Class Initialized
DEBUG - 2011-07-18 21:22:00 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-18 21:22:00 --> Language Class Initialized
DEBUG - 2011-07-18 21:22:00 --> Loader Class Initialized
DEBUG - 2011-07-18 21:22:00 --> Controller Class Initialized
DEBUG - 2011-07-18 21:22:00 --> Model Class Initialized
DEBUG - 2011-07-18 21:22:00 --> Model Class Initialized
DEBUG - 2011-07-18 21:22:00 --> Model Class Initialized
DEBUG - 2011-07-18 21:22:00 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-18 21:22:00 --> Database Driver Class Initialized
DEBUG - 2011-07-18 21:22:01 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-18 21:22:01 --> Helper loaded: url_helper
DEBUG - 2011-07-18 21:22:01 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-18 21:22:01 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-18 21:22:01 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-18 21:22:01 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-18 21:22:01 --> Final output sent to browser
DEBUG - 2011-07-18 21:22:01 --> Total execution time: 1.0052
DEBUG - 2011-07-18 21:22:44 --> Config Class Initialized
DEBUG - 2011-07-18 21:22:44 --> Hooks Class Initialized
DEBUG - 2011-07-18 21:22:44 --> Utf8 Class Initialized
DEBUG - 2011-07-18 21:22:44 --> UTF-8 Support Enabled
DEBUG - 2011-07-18 21:22:44 --> URI Class Initialized
DEBUG - 2011-07-18 21:22:44 --> Router Class Initialized
DEBUG - 2011-07-18 21:22:44 --> Output Class Initialized
DEBUG - 2011-07-18 21:22:44 --> Input Class Initialized
DEBUG - 2011-07-18 21:22:44 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-18 21:22:44 --> Language Class Initialized
DEBUG - 2011-07-18 21:22:44 --> Loader Class Initialized
DEBUG - 2011-07-18 21:22:44 --> Controller Class Initialized
DEBUG - 2011-07-18 21:22:44 --> Model Class Initialized
DEBUG - 2011-07-18 21:22:44 --> Model Class Initialized
DEBUG - 2011-07-18 21:22:44 --> Model Class Initialized
DEBUG - 2011-07-18 21:22:44 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-18 21:22:44 --> Database Driver Class Initialized
DEBUG - 2011-07-18 21:22:47 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-18 21:22:47 --> Helper loaded: url_helper
DEBUG - 2011-07-18 21:22:47 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-18 21:22:47 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-18 21:22:47 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-18 21:22:47 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-18 21:22:47 --> Final output sent to browser
DEBUG - 2011-07-18 21:22:47 --> Total execution time: 2.9571
DEBUG - 2011-07-18 21:22:50 --> Config Class Initialized
DEBUG - 2011-07-18 21:22:50 --> Hooks Class Initialized
DEBUG - 2011-07-18 21:22:50 --> Utf8 Class Initialized
DEBUG - 2011-07-18 21:22:50 --> UTF-8 Support Enabled
DEBUG - 2011-07-18 21:22:50 --> URI Class Initialized
DEBUG - 2011-07-18 21:22:50 --> Router Class Initialized
DEBUG - 2011-07-18 21:22:50 --> Output Class Initialized
DEBUG - 2011-07-18 21:22:50 --> Input Class Initialized
DEBUG - 2011-07-18 21:22:50 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-18 21:22:50 --> Language Class Initialized
DEBUG - 2011-07-18 21:22:50 --> Loader Class Initialized
DEBUG - 2011-07-18 21:22:50 --> Controller Class Initialized
DEBUG - 2011-07-18 21:22:50 --> Model Class Initialized
DEBUG - 2011-07-18 21:22:50 --> Model Class Initialized
DEBUG - 2011-07-18 21:22:50 --> Model Class Initialized
DEBUG - 2011-07-18 21:22:50 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-18 21:22:50 --> Database Driver Class Initialized
DEBUG - 2011-07-18 21:22:51 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-18 21:22:51 --> Helper loaded: url_helper
DEBUG - 2011-07-18 21:22:51 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-18 21:22:51 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-18 21:22:51 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-18 21:22:51 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-18 21:22:51 --> Final output sent to browser
DEBUG - 2011-07-18 21:22:51 --> Total execution time: 0.9767
DEBUG - 2011-07-18 21:23:47 --> Config Class Initialized
DEBUG - 2011-07-18 21:23:47 --> Hooks Class Initialized
DEBUG - 2011-07-18 21:23:47 --> Utf8 Class Initialized
DEBUG - 2011-07-18 21:23:47 --> UTF-8 Support Enabled
DEBUG - 2011-07-18 21:23:47 --> URI Class Initialized
DEBUG - 2011-07-18 21:23:47 --> Router Class Initialized
DEBUG - 2011-07-18 21:23:47 --> Output Class Initialized
DEBUG - 2011-07-18 21:23:47 --> Input Class Initialized
DEBUG - 2011-07-18 21:23:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-18 21:23:47 --> Language Class Initialized
DEBUG - 2011-07-18 21:23:47 --> Loader Class Initialized
DEBUG - 2011-07-18 21:23:47 --> Controller Class Initialized
DEBUG - 2011-07-18 21:23:47 --> Model Class Initialized
DEBUG - 2011-07-18 21:23:47 --> Model Class Initialized
DEBUG - 2011-07-18 21:23:47 --> Model Class Initialized
DEBUG - 2011-07-18 21:23:47 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-18 21:23:47 --> Database Driver Class Initialized
DEBUG - 2011-07-18 21:23:48 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-18 21:23:48 --> Helper loaded: url_helper
DEBUG - 2011-07-18 21:23:48 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-18 21:23:48 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-18 21:23:48 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-18 21:23:48 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-18 21:23:48 --> Final output sent to browser
DEBUG - 2011-07-18 21:23:48 --> Total execution time: 0.3421
DEBUG - 2011-07-18 21:23:49 --> Config Class Initialized
DEBUG - 2011-07-18 21:23:49 --> Hooks Class Initialized
DEBUG - 2011-07-18 21:23:49 --> Utf8 Class Initialized
DEBUG - 2011-07-18 21:23:49 --> UTF-8 Support Enabled
DEBUG - 2011-07-18 21:23:49 --> URI Class Initialized
DEBUG - 2011-07-18 21:23:49 --> Router Class Initialized
DEBUG - 2011-07-18 21:23:49 --> Output Class Initialized
DEBUG - 2011-07-18 21:23:49 --> Input Class Initialized
DEBUG - 2011-07-18 21:23:49 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-18 21:23:49 --> Language Class Initialized
DEBUG - 2011-07-18 21:23:49 --> Loader Class Initialized
DEBUG - 2011-07-18 21:23:49 --> Controller Class Initialized
DEBUG - 2011-07-18 21:23:49 --> Model Class Initialized
DEBUG - 2011-07-18 21:23:49 --> Model Class Initialized
DEBUG - 2011-07-18 21:23:49 --> Model Class Initialized
DEBUG - 2011-07-18 21:23:49 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-18 21:23:49 --> Database Driver Class Initialized
DEBUG - 2011-07-18 21:23:49 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-18 21:23:49 --> Helper loaded: url_helper
DEBUG - 2011-07-18 21:23:49 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-18 21:23:49 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-18 21:23:49 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-18 21:23:49 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-18 21:23:49 --> Final output sent to browser
DEBUG - 2011-07-18 21:23:49 --> Total execution time: 0.2431
DEBUG - 2011-07-18 21:23:55 --> Config Class Initialized
DEBUG - 2011-07-18 21:23:55 --> Hooks Class Initialized
DEBUG - 2011-07-18 21:23:55 --> Utf8 Class Initialized
DEBUG - 2011-07-18 21:23:55 --> UTF-8 Support Enabled
DEBUG - 2011-07-18 21:23:55 --> URI Class Initialized
DEBUG - 2011-07-18 21:23:55 --> Router Class Initialized
DEBUG - 2011-07-18 21:23:55 --> Output Class Initialized
DEBUG - 2011-07-18 21:23:55 --> Input Class Initialized
DEBUG - 2011-07-18 21:23:55 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-18 21:23:55 --> Language Class Initialized
DEBUG - 2011-07-18 21:23:55 --> Loader Class Initialized
DEBUG - 2011-07-18 21:23:55 --> Controller Class Initialized
DEBUG - 2011-07-18 21:23:55 --> Model Class Initialized
DEBUG - 2011-07-18 21:23:55 --> Model Class Initialized
DEBUG - 2011-07-18 21:23:55 --> Model Class Initialized
DEBUG - 2011-07-18 21:23:55 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-18 21:23:55 --> Database Driver Class Initialized
DEBUG - 2011-07-18 21:23:55 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-18 21:23:55 --> Helper loaded: url_helper
DEBUG - 2011-07-18 21:23:55 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-18 21:23:55 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-18 21:23:55 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-18 21:23:55 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-18 21:23:55 --> Final output sent to browser
DEBUG - 2011-07-18 21:23:55 --> Total execution time: 0.1983
DEBUG - 2011-07-18 22:59:56 --> Config Class Initialized
DEBUG - 2011-07-18 22:59:56 --> Hooks Class Initialized
DEBUG - 2011-07-18 22:59:56 --> Utf8 Class Initialized
DEBUG - 2011-07-18 22:59:56 --> UTF-8 Support Enabled
DEBUG - 2011-07-18 22:59:56 --> URI Class Initialized
DEBUG - 2011-07-18 22:59:56 --> Router Class Initialized
DEBUG - 2011-07-18 22:59:56 --> No URI present. Default controller set.
DEBUG - 2011-07-18 22:59:57 --> Output Class Initialized
DEBUG - 2011-07-18 22:59:57 --> Input Class Initialized
DEBUG - 2011-07-18 22:59:57 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-18 22:59:57 --> Language Class Initialized
DEBUG - 2011-07-18 22:59:57 --> Loader Class Initialized
DEBUG - 2011-07-18 22:59:57 --> Controller Class Initialized
DEBUG - 2011-07-18 22:59:57 --> File loaded: application/views/splash/main.php
DEBUG - 2011-07-18 22:59:57 --> Helper loaded: url_helper
DEBUG - 2011-07-18 22:59:57 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-18 22:59:57 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-18 22:59:57 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-18 22:59:57 --> File loaded: application/views/layout/main.php

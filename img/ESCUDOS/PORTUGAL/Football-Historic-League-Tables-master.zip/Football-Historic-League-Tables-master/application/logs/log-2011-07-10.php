<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2011-07-10 01:00:30 --> Config Class Initialized
DEBUG - 2011-07-10 01:00:30 --> Hooks Class Initialized
DEBUG - 2011-07-10 01:00:30 --> Utf8 Class Initialized
DEBUG - 2011-07-10 01:00:30 --> UTF-8 Support Enabled
DEBUG - 2011-07-10 01:00:30 --> URI Class Initialized
DEBUG - 2011-07-10 01:00:30 --> Router Class Initialized
DEBUG - 2011-07-10 01:00:30 --> Output Class Initialized
DEBUG - 2011-07-10 01:00:30 --> Input Class Initialized
DEBUG - 2011-07-10 01:00:30 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-10 01:00:30 --> Language Class Initialized
DEBUG - 2011-07-10 01:00:30 --> Loader Class Initialized
DEBUG - 2011-07-10 01:00:30 --> Controller Class Initialized
DEBUG - 2011-07-10 01:00:30 --> Model Class Initialized
DEBUG - 2011-07-10 01:00:30 --> Model Class Initialized
DEBUG - 2011-07-10 01:00:30 --> Model Class Initialized
DEBUG - 2011-07-10 01:00:30 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-10 01:00:30 --> Database Driver Class Initialized
DEBUG - 2011-07-10 01:00:31 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-10 01:00:31 --> Helper loaded: url_helper
DEBUG - 2011-07-10 01:00:31 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-10 01:00:31 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-10 01:00:31 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-10 01:00:31 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-10 01:00:31 --> Final output sent to browser
DEBUG - 2011-07-10 01:00:31 --> Total execution time: 0.6707
DEBUG - 2011-07-10 01:00:31 --> Config Class Initialized
DEBUG - 2011-07-10 01:00:31 --> Hooks Class Initialized
DEBUG - 2011-07-10 01:00:31 --> Utf8 Class Initialized
DEBUG - 2011-07-10 01:00:31 --> UTF-8 Support Enabled
DEBUG - 2011-07-10 01:00:31 --> URI Class Initialized
DEBUG - 2011-07-10 01:00:31 --> Router Class Initialized
DEBUG - 2011-07-10 01:00:31 --> Output Class Initialized
DEBUG - 2011-07-10 01:00:31 --> Input Class Initialized
DEBUG - 2011-07-10 01:00:31 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-10 01:00:31 --> Language Class Initialized
DEBUG - 2011-07-10 01:00:31 --> Loader Class Initialized
DEBUG - 2011-07-10 01:00:31 --> Controller Class Initialized
ERROR - 2011-07-10 01:00:32 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-10 01:00:32 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-10 01:00:32 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-10 01:00:32 --> Model Class Initialized
DEBUG - 2011-07-10 01:00:32 --> Model Class Initialized
DEBUG - 2011-07-10 01:00:32 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-10 01:00:32 --> Database Driver Class Initialized
DEBUG - 2011-07-10 01:00:32 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-10 01:00:32 --> Helper loaded: url_helper
DEBUG - 2011-07-10 01:00:32 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-10 01:00:32 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-10 01:00:32 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-10 01:00:32 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-10 01:00:32 --> Final output sent to browser
DEBUG - 2011-07-10 01:00:32 --> Total execution time: 0.1556
DEBUG - 2011-07-10 02:14:50 --> Config Class Initialized
DEBUG - 2011-07-10 02:14:50 --> Hooks Class Initialized
DEBUG - 2011-07-10 02:14:50 --> Utf8 Class Initialized
DEBUG - 2011-07-10 02:14:50 --> UTF-8 Support Enabled
DEBUG - 2011-07-10 02:14:50 --> URI Class Initialized
DEBUG - 2011-07-10 02:14:50 --> Router Class Initialized
ERROR - 2011-07-10 02:14:50 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-07-10 03:35:49 --> Config Class Initialized
DEBUG - 2011-07-10 03:35:49 --> Hooks Class Initialized
DEBUG - 2011-07-10 03:35:49 --> Utf8 Class Initialized
DEBUG - 2011-07-10 03:35:49 --> UTF-8 Support Enabled
DEBUG - 2011-07-10 03:35:49 --> URI Class Initialized
DEBUG - 2011-07-10 03:35:49 --> Router Class Initialized
DEBUG - 2011-07-10 03:35:49 --> Output Class Initialized
DEBUG - 2011-07-10 03:35:49 --> Input Class Initialized
DEBUG - 2011-07-10 03:35:49 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-10 03:35:49 --> Language Class Initialized
DEBUG - 2011-07-10 03:35:49 --> Loader Class Initialized
DEBUG - 2011-07-10 03:35:49 --> Controller Class Initialized
ERROR - 2011-07-10 03:35:49 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-10 03:35:49 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-10 03:35:49 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-10 03:35:49 --> Model Class Initialized
DEBUG - 2011-07-10 03:35:49 --> Model Class Initialized
DEBUG - 2011-07-10 03:35:49 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-10 03:35:49 --> Database Driver Class Initialized
DEBUG - 2011-07-10 03:35:49 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-10 03:35:49 --> Helper loaded: url_helper
DEBUG - 2011-07-10 03:35:49 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-10 03:35:49 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-10 03:35:49 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-10 03:35:49 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-10 03:35:49 --> Final output sent to browser
DEBUG - 2011-07-10 03:35:49 --> Total execution time: 0.6230
DEBUG - 2011-07-10 03:35:51 --> Config Class Initialized
DEBUG - 2011-07-10 03:35:51 --> Hooks Class Initialized
DEBUG - 2011-07-10 03:35:51 --> Utf8 Class Initialized
DEBUG - 2011-07-10 03:35:51 --> UTF-8 Support Enabled
DEBUG - 2011-07-10 03:35:51 --> URI Class Initialized
DEBUG - 2011-07-10 03:35:51 --> Router Class Initialized
DEBUG - 2011-07-10 03:35:51 --> Output Class Initialized
DEBUG - 2011-07-10 03:35:51 --> Input Class Initialized
DEBUG - 2011-07-10 03:35:51 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-10 03:35:51 --> Language Class Initialized
DEBUG - 2011-07-10 03:35:51 --> Loader Class Initialized
DEBUG - 2011-07-10 03:35:51 --> Controller Class Initialized
DEBUG - 2011-07-10 03:35:51 --> Model Class Initialized
DEBUG - 2011-07-10 03:35:51 --> Model Class Initialized
DEBUG - 2011-07-10 03:35:51 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-10 03:35:51 --> Database Driver Class Initialized
DEBUG - 2011-07-10 03:35:52 --> Final output sent to browser
DEBUG - 2011-07-10 03:35:52 --> Total execution time: 0.8724
DEBUG - 2011-07-10 03:36:02 --> Config Class Initialized
DEBUG - 2011-07-10 03:36:02 --> Hooks Class Initialized
DEBUG - 2011-07-10 03:36:02 --> Utf8 Class Initialized
DEBUG - 2011-07-10 03:36:02 --> UTF-8 Support Enabled
DEBUG - 2011-07-10 03:36:02 --> URI Class Initialized
DEBUG - 2011-07-10 03:36:02 --> Router Class Initialized
ERROR - 2011-07-10 03:36:02 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-10 03:36:03 --> Config Class Initialized
DEBUG - 2011-07-10 03:36:03 --> Hooks Class Initialized
DEBUG - 2011-07-10 03:36:03 --> Utf8 Class Initialized
DEBUG - 2011-07-10 03:36:03 --> UTF-8 Support Enabled
DEBUG - 2011-07-10 03:36:03 --> URI Class Initialized
DEBUG - 2011-07-10 03:36:03 --> Router Class Initialized
ERROR - 2011-07-10 03:36:03 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-10 04:45:20 --> Config Class Initialized
DEBUG - 2011-07-10 04:45:20 --> Hooks Class Initialized
DEBUG - 2011-07-10 04:45:20 --> Utf8 Class Initialized
DEBUG - 2011-07-10 04:45:20 --> UTF-8 Support Enabled
DEBUG - 2011-07-10 04:45:21 --> URI Class Initialized
DEBUG - 2011-07-10 04:45:21 --> Router Class Initialized
DEBUG - 2011-07-10 04:45:21 --> Output Class Initialized
DEBUG - 2011-07-10 04:45:21 --> Input Class Initialized
DEBUG - 2011-07-10 04:45:21 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-10 04:45:21 --> Language Class Initialized
DEBUG - 2011-07-10 04:45:21 --> Loader Class Initialized
DEBUG - 2011-07-10 04:45:21 --> Controller Class Initialized
DEBUG - 2011-07-10 04:45:21 --> Model Class Initialized
DEBUG - 2011-07-10 04:45:22 --> Model Class Initialized
DEBUG - 2011-07-10 04:45:22 --> Model Class Initialized
DEBUG - 2011-07-10 04:45:22 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-10 04:45:22 --> Database Driver Class Initialized
DEBUG - 2011-07-10 04:45:28 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-10 04:45:28 --> Helper loaded: url_helper
DEBUG - 2011-07-10 04:45:28 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-10 04:45:28 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-10 04:45:28 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-10 04:45:28 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-10 04:45:28 --> Final output sent to browser
DEBUG - 2011-07-10 04:45:28 --> Total execution time: 8.3587
DEBUG - 2011-07-10 04:45:39 --> Config Class Initialized
DEBUG - 2011-07-10 04:45:39 --> Hooks Class Initialized
DEBUG - 2011-07-10 04:45:39 --> Utf8 Class Initialized
DEBUG - 2011-07-10 04:45:39 --> UTF-8 Support Enabled
DEBUG - 2011-07-10 04:45:39 --> URI Class Initialized
DEBUG - 2011-07-10 04:45:39 --> Router Class Initialized
ERROR - 2011-07-10 04:45:39 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-10 06:42:12 --> Config Class Initialized
DEBUG - 2011-07-10 06:42:12 --> Hooks Class Initialized
DEBUG - 2011-07-10 06:42:12 --> Utf8 Class Initialized
DEBUG - 2011-07-10 06:42:12 --> UTF-8 Support Enabled
DEBUG - 2011-07-10 06:42:12 --> URI Class Initialized
DEBUG - 2011-07-10 06:42:12 --> Router Class Initialized
DEBUG - 2011-07-10 06:42:12 --> Output Class Initialized
DEBUG - 2011-07-10 06:42:12 --> Input Class Initialized
DEBUG - 2011-07-10 06:42:12 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-10 06:42:12 --> Language Class Initialized
DEBUG - 2011-07-10 06:42:12 --> Loader Class Initialized
DEBUG - 2011-07-10 06:42:12 --> Controller Class Initialized
DEBUG - 2011-07-10 06:42:12 --> Model Class Initialized
DEBUG - 2011-07-10 06:42:12 --> Model Class Initialized
DEBUG - 2011-07-10 06:42:12 --> Model Class Initialized
DEBUG - 2011-07-10 06:42:12 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-10 06:42:12 --> Database Driver Class Initialized
DEBUG - 2011-07-10 06:42:13 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-10 06:42:13 --> Helper loaded: url_helper
DEBUG - 2011-07-10 06:42:13 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-10 06:42:13 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-10 06:42:13 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-10 06:42:13 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-10 06:42:13 --> Final output sent to browser
DEBUG - 2011-07-10 06:42:13 --> Total execution time: 0.8317
DEBUG - 2011-07-10 06:42:17 --> Config Class Initialized
DEBUG - 2011-07-10 06:42:17 --> Hooks Class Initialized
DEBUG - 2011-07-10 06:42:17 --> Utf8 Class Initialized
DEBUG - 2011-07-10 06:42:17 --> UTF-8 Support Enabled
DEBUG - 2011-07-10 06:42:17 --> URI Class Initialized
DEBUG - 2011-07-10 06:42:17 --> Router Class Initialized
ERROR - 2011-07-10 06:42:17 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-10 06:42:33 --> Config Class Initialized
DEBUG - 2011-07-10 06:42:33 --> Hooks Class Initialized
DEBUG - 2011-07-10 06:42:33 --> Utf8 Class Initialized
DEBUG - 2011-07-10 06:42:33 --> UTF-8 Support Enabled
DEBUG - 2011-07-10 06:42:33 --> URI Class Initialized
DEBUG - 2011-07-10 06:42:33 --> Router Class Initialized
DEBUG - 2011-07-10 06:42:33 --> Output Class Initialized
DEBUG - 2011-07-10 06:42:33 --> Input Class Initialized
DEBUG - 2011-07-10 06:42:33 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-10 06:42:33 --> Language Class Initialized
DEBUG - 2011-07-10 06:42:33 --> Loader Class Initialized
DEBUG - 2011-07-10 06:42:33 --> Controller Class Initialized
DEBUG - 2011-07-10 06:42:33 --> Model Class Initialized
DEBUG - 2011-07-10 06:42:33 --> Model Class Initialized
DEBUG - 2011-07-10 06:42:33 --> Model Class Initialized
DEBUG - 2011-07-10 06:42:33 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-10 06:42:33 --> Database Driver Class Initialized
DEBUG - 2011-07-10 06:42:33 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-10 06:42:33 --> Helper loaded: url_helper
DEBUG - 2011-07-10 06:42:33 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-10 06:42:33 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-10 06:42:33 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-10 06:42:33 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-10 06:42:33 --> Final output sent to browser
DEBUG - 2011-07-10 06:42:33 --> Total execution time: 0.4032
DEBUG - 2011-07-10 06:42:37 --> Config Class Initialized
DEBUG - 2011-07-10 06:42:37 --> Hooks Class Initialized
DEBUG - 2011-07-10 06:42:37 --> Utf8 Class Initialized
DEBUG - 2011-07-10 06:42:37 --> UTF-8 Support Enabled
DEBUG - 2011-07-10 06:42:37 --> URI Class Initialized
DEBUG - 2011-07-10 06:42:37 --> Router Class Initialized
ERROR - 2011-07-10 06:42:37 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-10 06:42:52 --> Config Class Initialized
DEBUG - 2011-07-10 06:42:52 --> Hooks Class Initialized
DEBUG - 2011-07-10 06:42:52 --> Utf8 Class Initialized
DEBUG - 2011-07-10 06:42:52 --> UTF-8 Support Enabled
DEBUG - 2011-07-10 06:42:52 --> URI Class Initialized
DEBUG - 2011-07-10 06:42:52 --> Router Class Initialized
DEBUG - 2011-07-10 06:42:52 --> Output Class Initialized
DEBUG - 2011-07-10 06:42:52 --> Input Class Initialized
DEBUG - 2011-07-10 06:42:52 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-10 06:42:52 --> Language Class Initialized
DEBUG - 2011-07-10 06:42:52 --> Loader Class Initialized
DEBUG - 2011-07-10 06:42:52 --> Controller Class Initialized
DEBUG - 2011-07-10 06:42:52 --> Model Class Initialized
DEBUG - 2011-07-10 06:42:52 --> Model Class Initialized
DEBUG - 2011-07-10 06:42:52 --> Model Class Initialized
DEBUG - 2011-07-10 06:42:52 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-10 06:42:52 --> Database Driver Class Initialized
DEBUG - 2011-07-10 06:42:53 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-10 06:42:53 --> Helper loaded: url_helper
DEBUG - 2011-07-10 06:42:53 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-10 06:42:53 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-10 06:42:53 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-10 06:42:53 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-10 06:42:53 --> Final output sent to browser
DEBUG - 2011-07-10 06:42:53 --> Total execution time: 0.2518
DEBUG - 2011-07-10 06:42:53 --> Config Class Initialized
DEBUG - 2011-07-10 06:42:53 --> Hooks Class Initialized
DEBUG - 2011-07-10 06:42:53 --> Utf8 Class Initialized
DEBUG - 2011-07-10 06:42:53 --> UTF-8 Support Enabled
DEBUG - 2011-07-10 06:42:53 --> URI Class Initialized
DEBUG - 2011-07-10 06:42:53 --> Router Class Initialized
DEBUG - 2011-07-10 06:42:53 --> Output Class Initialized
DEBUG - 2011-07-10 06:42:53 --> Input Class Initialized
DEBUG - 2011-07-10 06:42:53 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-10 06:42:53 --> Language Class Initialized
DEBUG - 2011-07-10 06:42:53 --> Loader Class Initialized
DEBUG - 2011-07-10 06:42:53 --> Controller Class Initialized
DEBUG - 2011-07-10 06:42:53 --> Model Class Initialized
DEBUG - 2011-07-10 06:42:53 --> Model Class Initialized
DEBUG - 2011-07-10 06:42:53 --> Model Class Initialized
DEBUG - 2011-07-10 06:42:53 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-10 06:42:53 --> Database Driver Class Initialized
DEBUG - 2011-07-10 06:42:53 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-10 06:42:53 --> Helper loaded: url_helper
DEBUG - 2011-07-10 06:42:53 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-10 06:42:53 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-10 06:42:53 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-10 06:42:53 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-10 06:42:53 --> Final output sent to browser
DEBUG - 2011-07-10 06:42:53 --> Total execution time: 0.0417
DEBUG - 2011-07-10 06:42:56 --> Config Class Initialized
DEBUG - 2011-07-10 06:42:56 --> Hooks Class Initialized
DEBUG - 2011-07-10 06:42:56 --> Utf8 Class Initialized
DEBUG - 2011-07-10 06:42:56 --> UTF-8 Support Enabled
DEBUG - 2011-07-10 06:42:56 --> URI Class Initialized
DEBUG - 2011-07-10 06:42:56 --> Router Class Initialized
ERROR - 2011-07-10 06:42:56 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-10 06:42:56 --> Config Class Initialized
DEBUG - 2011-07-10 06:42:56 --> Hooks Class Initialized
DEBUG - 2011-07-10 06:42:56 --> Utf8 Class Initialized
DEBUG - 2011-07-10 06:42:56 --> UTF-8 Support Enabled
DEBUG - 2011-07-10 06:42:56 --> URI Class Initialized
DEBUG - 2011-07-10 06:42:56 --> Router Class Initialized
DEBUG - 2011-07-10 06:42:56 --> Output Class Initialized
DEBUG - 2011-07-10 06:42:56 --> Input Class Initialized
DEBUG - 2011-07-10 06:42:56 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-10 06:42:56 --> Language Class Initialized
DEBUG - 2011-07-10 06:42:56 --> Loader Class Initialized
DEBUG - 2011-07-10 06:42:56 --> Controller Class Initialized
DEBUG - 2011-07-10 06:42:56 --> Model Class Initialized
DEBUG - 2011-07-10 06:42:56 --> Model Class Initialized
DEBUG - 2011-07-10 06:42:56 --> Model Class Initialized
DEBUG - 2011-07-10 06:42:56 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-10 06:42:56 --> Database Driver Class Initialized
DEBUG - 2011-07-10 06:42:56 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-10 06:42:56 --> Helper loaded: url_helper
DEBUG - 2011-07-10 06:42:56 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-10 06:42:56 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-10 06:42:56 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-10 06:42:56 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-10 06:42:56 --> Final output sent to browser
DEBUG - 2011-07-10 06:42:56 --> Total execution time: 0.0403
DEBUG - 2011-07-10 06:43:10 --> Config Class Initialized
DEBUG - 2011-07-10 06:43:10 --> Hooks Class Initialized
DEBUG - 2011-07-10 06:43:10 --> Utf8 Class Initialized
DEBUG - 2011-07-10 06:43:10 --> UTF-8 Support Enabled
DEBUG - 2011-07-10 06:43:10 --> URI Class Initialized
DEBUG - 2011-07-10 06:43:10 --> Router Class Initialized
DEBUG - 2011-07-10 06:43:10 --> Output Class Initialized
DEBUG - 2011-07-10 06:43:10 --> Input Class Initialized
DEBUG - 2011-07-10 06:43:10 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-10 06:43:10 --> Language Class Initialized
DEBUG - 2011-07-10 06:43:10 --> Loader Class Initialized
DEBUG - 2011-07-10 06:43:10 --> Controller Class Initialized
DEBUG - 2011-07-10 06:43:10 --> Model Class Initialized
DEBUG - 2011-07-10 06:43:10 --> Model Class Initialized
DEBUG - 2011-07-10 06:43:10 --> Model Class Initialized
DEBUG - 2011-07-10 06:43:10 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-10 06:43:10 --> Database Driver Class Initialized
DEBUG - 2011-07-10 06:43:10 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-10 06:43:10 --> Helper loaded: url_helper
DEBUG - 2011-07-10 06:43:10 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-10 06:43:10 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-10 06:43:10 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-10 06:43:10 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-10 06:43:10 --> Final output sent to browser
DEBUG - 2011-07-10 06:43:10 --> Total execution time: 0.2233
DEBUG - 2011-07-10 06:43:14 --> Config Class Initialized
DEBUG - 2011-07-10 06:43:14 --> Hooks Class Initialized
DEBUG - 2011-07-10 06:43:14 --> Utf8 Class Initialized
DEBUG - 2011-07-10 06:43:14 --> UTF-8 Support Enabled
DEBUG - 2011-07-10 06:43:14 --> URI Class Initialized
DEBUG - 2011-07-10 06:43:14 --> Router Class Initialized
DEBUG - 2011-07-10 06:43:14 --> Output Class Initialized
DEBUG - 2011-07-10 06:43:14 --> Input Class Initialized
DEBUG - 2011-07-10 06:43:14 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-10 06:43:14 --> Language Class Initialized
DEBUG - 2011-07-10 06:43:14 --> Loader Class Initialized
DEBUG - 2011-07-10 06:43:14 --> Controller Class Initialized
DEBUG - 2011-07-10 06:43:14 --> Model Class Initialized
DEBUG - 2011-07-10 06:43:14 --> Model Class Initialized
DEBUG - 2011-07-10 06:43:14 --> Model Class Initialized
DEBUG - 2011-07-10 06:43:14 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-10 06:43:14 --> Database Driver Class Initialized
DEBUG - 2011-07-10 06:43:14 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-10 06:43:14 --> Helper loaded: url_helper
DEBUG - 2011-07-10 06:43:14 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-10 06:43:14 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-10 06:43:14 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-10 06:43:14 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-10 06:43:14 --> Final output sent to browser
DEBUG - 2011-07-10 06:43:14 --> Total execution time: 0.0426
DEBUG - 2011-07-10 06:43:19 --> Config Class Initialized
DEBUG - 2011-07-10 06:43:19 --> Hooks Class Initialized
DEBUG - 2011-07-10 06:43:19 --> Utf8 Class Initialized
DEBUG - 2011-07-10 06:43:19 --> UTF-8 Support Enabled
DEBUG - 2011-07-10 06:43:19 --> URI Class Initialized
DEBUG - 2011-07-10 06:43:19 --> Router Class Initialized
ERROR - 2011-07-10 06:43:19 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-10 06:43:34 --> Config Class Initialized
DEBUG - 2011-07-10 06:43:34 --> Hooks Class Initialized
DEBUG - 2011-07-10 06:43:34 --> Utf8 Class Initialized
DEBUG - 2011-07-10 06:43:34 --> UTF-8 Support Enabled
DEBUG - 2011-07-10 06:43:34 --> URI Class Initialized
DEBUG - 2011-07-10 06:43:34 --> Router Class Initialized
DEBUG - 2011-07-10 06:43:34 --> Output Class Initialized
DEBUG - 2011-07-10 06:43:34 --> Input Class Initialized
DEBUG - 2011-07-10 06:43:34 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-10 06:43:34 --> Language Class Initialized
DEBUG - 2011-07-10 06:43:34 --> Loader Class Initialized
DEBUG - 2011-07-10 06:43:34 --> Controller Class Initialized
DEBUG - 2011-07-10 06:43:34 --> Model Class Initialized
DEBUG - 2011-07-10 06:43:34 --> Model Class Initialized
DEBUG - 2011-07-10 06:43:34 --> Model Class Initialized
DEBUG - 2011-07-10 06:43:34 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-10 06:43:35 --> Database Driver Class Initialized
DEBUG - 2011-07-10 06:43:35 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-10 06:43:35 --> Helper loaded: url_helper
DEBUG - 2011-07-10 06:43:35 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-10 06:43:35 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-10 06:43:35 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-10 06:43:35 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-10 06:43:35 --> Final output sent to browser
DEBUG - 2011-07-10 06:43:35 --> Total execution time: 0.2205
DEBUG - 2011-07-10 06:43:36 --> Config Class Initialized
DEBUG - 2011-07-10 06:43:36 --> Hooks Class Initialized
DEBUG - 2011-07-10 06:43:36 --> Utf8 Class Initialized
DEBUG - 2011-07-10 06:43:36 --> UTF-8 Support Enabled
DEBUG - 2011-07-10 06:43:36 --> URI Class Initialized
DEBUG - 2011-07-10 06:43:36 --> Router Class Initialized
DEBUG - 2011-07-10 06:43:36 --> Output Class Initialized
DEBUG - 2011-07-10 06:43:36 --> Input Class Initialized
DEBUG - 2011-07-10 06:43:36 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-10 06:43:36 --> Language Class Initialized
DEBUG - 2011-07-10 06:43:36 --> Loader Class Initialized
DEBUG - 2011-07-10 06:43:36 --> Controller Class Initialized
DEBUG - 2011-07-10 06:43:36 --> Model Class Initialized
DEBUG - 2011-07-10 06:43:36 --> Model Class Initialized
DEBUG - 2011-07-10 06:43:36 --> Model Class Initialized
DEBUG - 2011-07-10 06:43:36 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-10 06:43:36 --> Database Driver Class Initialized
DEBUG - 2011-07-10 06:43:36 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-10 06:43:36 --> Helper loaded: url_helper
DEBUG - 2011-07-10 06:43:36 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-10 06:43:36 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-10 06:43:36 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-10 06:43:36 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-10 06:43:36 --> Final output sent to browser
DEBUG - 2011-07-10 06:43:36 --> Total execution time: 0.0703
DEBUG - 2011-07-10 06:43:37 --> Config Class Initialized
DEBUG - 2011-07-10 06:43:37 --> Hooks Class Initialized
DEBUG - 2011-07-10 06:43:37 --> Utf8 Class Initialized
DEBUG - 2011-07-10 06:43:37 --> UTF-8 Support Enabled
DEBUG - 2011-07-10 06:43:37 --> URI Class Initialized
DEBUG - 2011-07-10 06:43:37 --> Router Class Initialized
ERROR - 2011-07-10 06:43:37 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-10 06:43:48 --> Config Class Initialized
DEBUG - 2011-07-10 06:43:48 --> Hooks Class Initialized
DEBUG - 2011-07-10 06:43:48 --> Utf8 Class Initialized
DEBUG - 2011-07-10 06:43:48 --> UTF-8 Support Enabled
DEBUG - 2011-07-10 06:43:48 --> URI Class Initialized
DEBUG - 2011-07-10 06:43:48 --> Router Class Initialized
DEBUG - 2011-07-10 06:43:48 --> Output Class Initialized
DEBUG - 2011-07-10 06:43:48 --> Input Class Initialized
DEBUG - 2011-07-10 06:43:48 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-10 06:43:48 --> Language Class Initialized
DEBUG - 2011-07-10 06:43:48 --> Loader Class Initialized
DEBUG - 2011-07-10 06:43:48 --> Controller Class Initialized
DEBUG - 2011-07-10 06:43:48 --> Model Class Initialized
DEBUG - 2011-07-10 06:43:48 --> Model Class Initialized
DEBUG - 2011-07-10 06:43:48 --> Model Class Initialized
DEBUG - 2011-07-10 06:43:48 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-10 06:43:48 --> Database Driver Class Initialized
DEBUG - 2011-07-10 06:43:48 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-10 06:43:48 --> Helper loaded: url_helper
DEBUG - 2011-07-10 06:43:48 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-10 06:43:48 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-10 06:43:48 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-10 06:43:48 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-10 06:43:48 --> Final output sent to browser
DEBUG - 2011-07-10 06:43:48 --> Total execution time: 0.2341
DEBUG - 2011-07-10 06:43:49 --> Config Class Initialized
DEBUG - 2011-07-10 06:43:49 --> Hooks Class Initialized
DEBUG - 2011-07-10 06:43:49 --> Utf8 Class Initialized
DEBUG - 2011-07-10 06:43:49 --> UTF-8 Support Enabled
DEBUG - 2011-07-10 06:43:49 --> URI Class Initialized
DEBUG - 2011-07-10 06:43:49 --> Router Class Initialized
DEBUG - 2011-07-10 06:43:49 --> Output Class Initialized
DEBUG - 2011-07-10 06:43:49 --> Input Class Initialized
DEBUG - 2011-07-10 06:43:49 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-10 06:43:49 --> Language Class Initialized
DEBUG - 2011-07-10 06:43:49 --> Loader Class Initialized
DEBUG - 2011-07-10 06:43:49 --> Controller Class Initialized
DEBUG - 2011-07-10 06:43:49 --> Model Class Initialized
DEBUG - 2011-07-10 06:43:49 --> Model Class Initialized
DEBUG - 2011-07-10 06:43:49 --> Model Class Initialized
DEBUG - 2011-07-10 06:43:49 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-10 06:43:49 --> Database Driver Class Initialized
DEBUG - 2011-07-10 06:43:49 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-10 06:43:49 --> Helper loaded: url_helper
DEBUG - 2011-07-10 06:43:49 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-10 06:43:49 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-10 06:43:49 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-10 06:43:49 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-10 06:43:49 --> Final output sent to browser
DEBUG - 2011-07-10 06:43:49 --> Total execution time: 0.0429
DEBUG - 2011-07-10 06:43:50 --> Config Class Initialized
DEBUG - 2011-07-10 06:43:50 --> Hooks Class Initialized
DEBUG - 2011-07-10 06:43:50 --> Utf8 Class Initialized
DEBUG - 2011-07-10 06:43:50 --> UTF-8 Support Enabled
DEBUG - 2011-07-10 06:43:50 --> URI Class Initialized
DEBUG - 2011-07-10 06:43:50 --> Router Class Initialized
ERROR - 2011-07-10 06:43:50 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-10 06:44:06 --> Config Class Initialized
DEBUG - 2011-07-10 06:44:06 --> Hooks Class Initialized
DEBUG - 2011-07-10 06:44:06 --> Utf8 Class Initialized
DEBUG - 2011-07-10 06:44:06 --> UTF-8 Support Enabled
DEBUG - 2011-07-10 06:44:06 --> URI Class Initialized
DEBUG - 2011-07-10 06:44:06 --> Router Class Initialized
DEBUG - 2011-07-10 06:44:06 --> Output Class Initialized
DEBUG - 2011-07-10 06:44:06 --> Input Class Initialized
DEBUG - 2011-07-10 06:44:06 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-10 06:44:06 --> Language Class Initialized
DEBUG - 2011-07-10 06:44:06 --> Loader Class Initialized
DEBUG - 2011-07-10 06:44:06 --> Controller Class Initialized
DEBUG - 2011-07-10 06:44:06 --> Model Class Initialized
DEBUG - 2011-07-10 06:44:06 --> Model Class Initialized
DEBUG - 2011-07-10 06:44:06 --> Model Class Initialized
DEBUG - 2011-07-10 06:44:06 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-10 06:44:06 --> Database Driver Class Initialized
DEBUG - 2011-07-10 06:44:06 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-10 06:44:06 --> Helper loaded: url_helper
DEBUG - 2011-07-10 06:44:06 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-10 06:44:06 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-10 06:44:06 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-10 06:44:06 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-10 06:44:06 --> Final output sent to browser
DEBUG - 2011-07-10 06:44:06 --> Total execution time: 0.1962
DEBUG - 2011-07-10 06:44:07 --> Config Class Initialized
DEBUG - 2011-07-10 06:44:07 --> Hooks Class Initialized
DEBUG - 2011-07-10 06:44:07 --> Utf8 Class Initialized
DEBUG - 2011-07-10 06:44:07 --> UTF-8 Support Enabled
DEBUG - 2011-07-10 06:44:07 --> URI Class Initialized
DEBUG - 2011-07-10 06:44:07 --> Router Class Initialized
DEBUG - 2011-07-10 06:44:07 --> Output Class Initialized
DEBUG - 2011-07-10 06:44:07 --> Input Class Initialized
DEBUG - 2011-07-10 06:44:07 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-10 06:44:07 --> Language Class Initialized
DEBUG - 2011-07-10 06:44:07 --> Loader Class Initialized
DEBUG - 2011-07-10 06:44:07 --> Controller Class Initialized
DEBUG - 2011-07-10 06:44:07 --> Model Class Initialized
DEBUG - 2011-07-10 06:44:07 --> Model Class Initialized
DEBUG - 2011-07-10 06:44:07 --> Model Class Initialized
DEBUG - 2011-07-10 06:44:07 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-10 06:44:07 --> Database Driver Class Initialized
DEBUG - 2011-07-10 06:44:07 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-10 06:44:07 --> Helper loaded: url_helper
DEBUG - 2011-07-10 06:44:07 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-10 06:44:07 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-10 06:44:07 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-10 06:44:07 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-10 06:44:07 --> Final output sent to browser
DEBUG - 2011-07-10 06:44:07 --> Total execution time: 0.0422
DEBUG - 2011-07-10 06:44:09 --> Config Class Initialized
DEBUG - 2011-07-10 06:44:09 --> Hooks Class Initialized
DEBUG - 2011-07-10 06:44:09 --> Utf8 Class Initialized
DEBUG - 2011-07-10 06:44:09 --> UTF-8 Support Enabled
DEBUG - 2011-07-10 06:44:09 --> URI Class Initialized
DEBUG - 2011-07-10 06:44:09 --> Router Class Initialized
ERROR - 2011-07-10 06:44:09 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-10 06:44:26 --> Config Class Initialized
DEBUG - 2011-07-10 06:44:26 --> Hooks Class Initialized
DEBUG - 2011-07-10 06:44:26 --> Utf8 Class Initialized
DEBUG - 2011-07-10 06:44:26 --> UTF-8 Support Enabled
DEBUG - 2011-07-10 06:44:26 --> URI Class Initialized
DEBUG - 2011-07-10 06:44:26 --> Router Class Initialized
DEBUG - 2011-07-10 06:44:26 --> Output Class Initialized
DEBUG - 2011-07-10 06:44:26 --> Input Class Initialized
DEBUG - 2011-07-10 06:44:26 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-10 06:44:26 --> Language Class Initialized
DEBUG - 2011-07-10 06:44:26 --> Loader Class Initialized
DEBUG - 2011-07-10 06:44:26 --> Controller Class Initialized
DEBUG - 2011-07-10 06:44:26 --> Model Class Initialized
DEBUG - 2011-07-10 06:44:26 --> Model Class Initialized
DEBUG - 2011-07-10 06:44:26 --> Model Class Initialized
DEBUG - 2011-07-10 06:44:26 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-10 06:44:26 --> Database Driver Class Initialized
DEBUG - 2011-07-10 06:44:26 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-10 06:44:26 --> Helper loaded: url_helper
DEBUG - 2011-07-10 06:44:26 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-10 06:44:26 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-10 06:44:26 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-10 06:44:26 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-10 06:44:26 --> Final output sent to browser
DEBUG - 2011-07-10 06:44:26 --> Total execution time: 0.2386
DEBUG - 2011-07-10 06:44:27 --> Config Class Initialized
DEBUG - 2011-07-10 06:44:27 --> Hooks Class Initialized
DEBUG - 2011-07-10 06:44:27 --> Utf8 Class Initialized
DEBUG - 2011-07-10 06:44:27 --> UTF-8 Support Enabled
DEBUG - 2011-07-10 06:44:27 --> URI Class Initialized
DEBUG - 2011-07-10 06:44:27 --> Router Class Initialized
DEBUG - 2011-07-10 06:44:27 --> Output Class Initialized
DEBUG - 2011-07-10 06:44:27 --> Input Class Initialized
DEBUG - 2011-07-10 06:44:27 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-10 06:44:27 --> Language Class Initialized
DEBUG - 2011-07-10 06:44:27 --> Loader Class Initialized
DEBUG - 2011-07-10 06:44:27 --> Controller Class Initialized
DEBUG - 2011-07-10 06:44:27 --> Model Class Initialized
DEBUG - 2011-07-10 06:44:27 --> Model Class Initialized
DEBUG - 2011-07-10 06:44:27 --> Model Class Initialized
DEBUG - 2011-07-10 06:44:27 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-10 06:44:27 --> Database Driver Class Initialized
DEBUG - 2011-07-10 06:44:27 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-10 06:44:27 --> Helper loaded: url_helper
DEBUG - 2011-07-10 06:44:27 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-10 06:44:27 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-10 06:44:27 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-10 06:44:27 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-10 06:44:27 --> Final output sent to browser
DEBUG - 2011-07-10 06:44:27 --> Total execution time: 0.0420
DEBUG - 2011-07-10 06:44:30 --> Config Class Initialized
DEBUG - 2011-07-10 06:44:30 --> Hooks Class Initialized
DEBUG - 2011-07-10 06:44:30 --> Utf8 Class Initialized
DEBUG - 2011-07-10 06:44:30 --> UTF-8 Support Enabled
DEBUG - 2011-07-10 06:44:30 --> URI Class Initialized
DEBUG - 2011-07-10 06:44:30 --> Router Class Initialized
ERROR - 2011-07-10 06:44:30 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-10 06:44:34 --> Config Class Initialized
DEBUG - 2011-07-10 06:44:34 --> Hooks Class Initialized
DEBUG - 2011-07-10 06:44:34 --> Utf8 Class Initialized
DEBUG - 2011-07-10 06:44:34 --> UTF-8 Support Enabled
DEBUG - 2011-07-10 06:44:34 --> URI Class Initialized
DEBUG - 2011-07-10 06:44:34 --> Router Class Initialized
DEBUG - 2011-07-10 06:44:34 --> Output Class Initialized
DEBUG - 2011-07-10 06:44:34 --> Input Class Initialized
DEBUG - 2011-07-10 06:44:34 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-10 06:44:34 --> Language Class Initialized
DEBUG - 2011-07-10 06:44:34 --> Loader Class Initialized
DEBUG - 2011-07-10 06:44:34 --> Controller Class Initialized
DEBUG - 2011-07-10 06:44:34 --> Model Class Initialized
DEBUG - 2011-07-10 06:44:34 --> Model Class Initialized
DEBUG - 2011-07-10 06:44:34 --> Model Class Initialized
DEBUG - 2011-07-10 06:44:34 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-10 06:44:34 --> Database Driver Class Initialized
DEBUG - 2011-07-10 06:44:34 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-10 06:44:34 --> Helper loaded: url_helper
DEBUG - 2011-07-10 06:44:34 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-10 06:44:34 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-10 06:44:34 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-10 06:44:34 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-10 06:44:34 --> Final output sent to browser
DEBUG - 2011-07-10 06:44:34 --> Total execution time: 0.0436
DEBUG - 2011-07-10 06:44:38 --> Config Class Initialized
DEBUG - 2011-07-10 06:44:38 --> Hooks Class Initialized
DEBUG - 2011-07-10 06:44:38 --> Utf8 Class Initialized
DEBUG - 2011-07-10 06:44:38 --> UTF-8 Support Enabled
DEBUG - 2011-07-10 06:44:38 --> URI Class Initialized
DEBUG - 2011-07-10 06:44:38 --> Router Class Initialized
DEBUG - 2011-07-10 06:44:38 --> Output Class Initialized
DEBUG - 2011-07-10 06:44:38 --> Input Class Initialized
DEBUG - 2011-07-10 06:44:38 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-10 06:44:38 --> Language Class Initialized
DEBUG - 2011-07-10 06:44:38 --> Loader Class Initialized
DEBUG - 2011-07-10 06:44:38 --> Controller Class Initialized
DEBUG - 2011-07-10 06:44:38 --> Model Class Initialized
DEBUG - 2011-07-10 06:44:38 --> Model Class Initialized
DEBUG - 2011-07-10 06:44:38 --> Model Class Initialized
DEBUG - 2011-07-10 06:44:38 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-10 06:44:38 --> Database Driver Class Initialized
DEBUG - 2011-07-10 06:44:38 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-10 06:44:38 --> Helper loaded: url_helper
DEBUG - 2011-07-10 06:44:38 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-10 06:44:38 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-10 06:44:38 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-10 06:44:38 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-10 06:44:38 --> Final output sent to browser
DEBUG - 2011-07-10 06:44:38 --> Total execution time: 0.3631
DEBUG - 2011-07-10 06:44:41 --> Config Class Initialized
DEBUG - 2011-07-10 06:44:41 --> Hooks Class Initialized
DEBUG - 2011-07-10 06:44:41 --> Utf8 Class Initialized
DEBUG - 2011-07-10 06:44:41 --> UTF-8 Support Enabled
DEBUG - 2011-07-10 06:44:41 --> URI Class Initialized
DEBUG - 2011-07-10 06:44:41 --> Router Class Initialized
ERROR - 2011-07-10 06:44:41 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-10 06:44:41 --> Config Class Initialized
DEBUG - 2011-07-10 06:44:41 --> Hooks Class Initialized
DEBUG - 2011-07-10 06:44:41 --> Utf8 Class Initialized
DEBUG - 2011-07-10 06:44:41 --> UTF-8 Support Enabled
DEBUG - 2011-07-10 06:44:41 --> URI Class Initialized
DEBUG - 2011-07-10 06:44:41 --> Router Class Initialized
DEBUG - 2011-07-10 06:44:41 --> Output Class Initialized
DEBUG - 2011-07-10 06:44:41 --> Input Class Initialized
DEBUG - 2011-07-10 06:44:41 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-10 06:44:41 --> Language Class Initialized
DEBUG - 2011-07-10 06:44:41 --> Loader Class Initialized
DEBUG - 2011-07-10 06:44:41 --> Controller Class Initialized
DEBUG - 2011-07-10 06:44:41 --> Model Class Initialized
DEBUG - 2011-07-10 06:44:41 --> Model Class Initialized
DEBUG - 2011-07-10 06:44:41 --> Model Class Initialized
DEBUG - 2011-07-10 06:44:41 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-10 06:44:41 --> Database Driver Class Initialized
DEBUG - 2011-07-10 06:44:41 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-10 06:44:41 --> Helper loaded: url_helper
DEBUG - 2011-07-10 06:44:41 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-10 06:44:41 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-10 06:44:41 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-10 06:44:41 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-10 06:44:41 --> Final output sent to browser
DEBUG - 2011-07-10 06:44:41 --> Total execution time: 0.0431
DEBUG - 2011-07-10 06:44:56 --> Config Class Initialized
DEBUG - 2011-07-10 06:44:56 --> Hooks Class Initialized
DEBUG - 2011-07-10 06:44:56 --> Utf8 Class Initialized
DEBUG - 2011-07-10 06:44:56 --> UTF-8 Support Enabled
DEBUG - 2011-07-10 06:44:56 --> URI Class Initialized
DEBUG - 2011-07-10 06:44:56 --> Router Class Initialized
DEBUG - 2011-07-10 06:44:56 --> Output Class Initialized
DEBUG - 2011-07-10 06:44:56 --> Input Class Initialized
DEBUG - 2011-07-10 06:44:56 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-10 06:44:56 --> Language Class Initialized
DEBUG - 2011-07-10 06:44:56 --> Loader Class Initialized
DEBUG - 2011-07-10 06:44:56 --> Controller Class Initialized
DEBUG - 2011-07-10 06:44:56 --> Model Class Initialized
DEBUG - 2011-07-10 06:44:56 --> Model Class Initialized
DEBUG - 2011-07-10 06:44:56 --> Model Class Initialized
DEBUG - 2011-07-10 06:44:56 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-10 06:44:56 --> Database Driver Class Initialized
DEBUG - 2011-07-10 06:44:57 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-10 06:44:57 --> Helper loaded: url_helper
DEBUG - 2011-07-10 06:44:57 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-10 06:44:57 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-10 06:44:57 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-10 06:44:57 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-10 06:44:57 --> Final output sent to browser
DEBUG - 2011-07-10 06:44:57 --> Total execution time: 0.5262
DEBUG - 2011-07-10 06:44:58 --> Config Class Initialized
DEBUG - 2011-07-10 06:44:58 --> Hooks Class Initialized
DEBUG - 2011-07-10 06:44:58 --> Utf8 Class Initialized
DEBUG - 2011-07-10 06:44:58 --> UTF-8 Support Enabled
DEBUG - 2011-07-10 06:44:58 --> URI Class Initialized
DEBUG - 2011-07-10 06:44:58 --> Router Class Initialized
DEBUG - 2011-07-10 06:44:58 --> Output Class Initialized
DEBUG - 2011-07-10 06:44:58 --> Input Class Initialized
DEBUG - 2011-07-10 06:44:58 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-10 06:44:58 --> Language Class Initialized
DEBUG - 2011-07-10 06:44:58 --> Loader Class Initialized
DEBUG - 2011-07-10 06:44:58 --> Controller Class Initialized
DEBUG - 2011-07-10 06:44:58 --> Model Class Initialized
DEBUG - 2011-07-10 06:44:58 --> Model Class Initialized
DEBUG - 2011-07-10 06:44:58 --> Model Class Initialized
DEBUG - 2011-07-10 06:44:58 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-10 06:44:58 --> Database Driver Class Initialized
DEBUG - 2011-07-10 06:44:58 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-10 06:44:58 --> Helper loaded: url_helper
DEBUG - 2011-07-10 06:44:58 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-10 06:44:58 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-10 06:44:58 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-10 06:44:58 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-10 06:44:58 --> Final output sent to browser
DEBUG - 2011-07-10 06:44:58 --> Total execution time: 0.0458
DEBUG - 2011-07-10 06:44:59 --> Config Class Initialized
DEBUG - 2011-07-10 06:44:59 --> Hooks Class Initialized
DEBUG - 2011-07-10 06:44:59 --> Utf8 Class Initialized
DEBUG - 2011-07-10 06:44:59 --> UTF-8 Support Enabled
DEBUG - 2011-07-10 06:44:59 --> URI Class Initialized
DEBUG - 2011-07-10 06:44:59 --> Router Class Initialized
ERROR - 2011-07-10 06:44:59 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-10 06:45:32 --> Config Class Initialized
DEBUG - 2011-07-10 06:45:32 --> Hooks Class Initialized
DEBUG - 2011-07-10 06:45:32 --> Utf8 Class Initialized
DEBUG - 2011-07-10 06:45:32 --> UTF-8 Support Enabled
DEBUG - 2011-07-10 06:45:32 --> URI Class Initialized
DEBUG - 2011-07-10 06:45:32 --> Router Class Initialized
DEBUG - 2011-07-10 06:45:32 --> Output Class Initialized
DEBUG - 2011-07-10 06:45:32 --> Input Class Initialized
DEBUG - 2011-07-10 06:45:32 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-10 06:45:32 --> Language Class Initialized
DEBUG - 2011-07-10 06:45:32 --> Loader Class Initialized
DEBUG - 2011-07-10 06:45:32 --> Controller Class Initialized
DEBUG - 2011-07-10 06:45:32 --> Model Class Initialized
DEBUG - 2011-07-10 06:45:32 --> Model Class Initialized
DEBUG - 2011-07-10 06:45:32 --> Model Class Initialized
DEBUG - 2011-07-10 06:45:32 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-10 06:45:32 --> Database Driver Class Initialized
DEBUG - 2011-07-10 06:45:33 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-10 06:45:33 --> Helper loaded: url_helper
DEBUG - 2011-07-10 06:45:33 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-10 06:45:33 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-10 06:45:33 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-10 06:45:33 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-10 06:45:33 --> Final output sent to browser
DEBUG - 2011-07-10 06:45:33 --> Total execution time: 0.7357
DEBUG - 2011-07-10 06:45:35 --> Config Class Initialized
DEBUG - 2011-07-10 06:45:35 --> Hooks Class Initialized
DEBUG - 2011-07-10 06:45:35 --> Utf8 Class Initialized
DEBUG - 2011-07-10 06:45:35 --> UTF-8 Support Enabled
DEBUG - 2011-07-10 06:45:35 --> URI Class Initialized
DEBUG - 2011-07-10 06:45:35 --> Router Class Initialized
ERROR - 2011-07-10 06:45:35 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-10 06:45:42 --> Config Class Initialized
DEBUG - 2011-07-10 06:45:42 --> Hooks Class Initialized
DEBUG - 2011-07-10 06:45:42 --> Utf8 Class Initialized
DEBUG - 2011-07-10 06:45:42 --> UTF-8 Support Enabled
DEBUG - 2011-07-10 06:45:42 --> URI Class Initialized
DEBUG - 2011-07-10 06:45:42 --> Router Class Initialized
DEBUG - 2011-07-10 06:45:42 --> Output Class Initialized
DEBUG - 2011-07-10 06:45:42 --> Input Class Initialized
DEBUG - 2011-07-10 06:45:42 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-10 06:45:42 --> Language Class Initialized
DEBUG - 2011-07-10 06:45:42 --> Loader Class Initialized
DEBUG - 2011-07-10 06:45:42 --> Controller Class Initialized
DEBUG - 2011-07-10 06:45:42 --> Model Class Initialized
DEBUG - 2011-07-10 06:45:42 --> Model Class Initialized
DEBUG - 2011-07-10 06:45:42 --> Model Class Initialized
DEBUG - 2011-07-10 06:45:42 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-10 06:45:42 --> Database Driver Class Initialized
DEBUG - 2011-07-10 06:45:42 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-10 06:45:42 --> Helper loaded: url_helper
DEBUG - 2011-07-10 06:45:42 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-10 06:45:42 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-10 06:45:42 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-10 06:45:42 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-10 06:45:42 --> Final output sent to browser
DEBUG - 2011-07-10 06:45:42 --> Total execution time: 0.0592
DEBUG - 2011-07-10 06:45:47 --> Config Class Initialized
DEBUG - 2011-07-10 06:45:47 --> Hooks Class Initialized
DEBUG - 2011-07-10 06:45:47 --> Utf8 Class Initialized
DEBUG - 2011-07-10 06:45:47 --> UTF-8 Support Enabled
DEBUG - 2011-07-10 06:45:47 --> URI Class Initialized
DEBUG - 2011-07-10 06:45:47 --> Router Class Initialized
DEBUG - 2011-07-10 06:45:47 --> Output Class Initialized
DEBUG - 2011-07-10 06:45:47 --> Input Class Initialized
DEBUG - 2011-07-10 06:45:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-10 06:45:47 --> Language Class Initialized
DEBUG - 2011-07-10 06:45:47 --> Loader Class Initialized
DEBUG - 2011-07-10 06:45:47 --> Controller Class Initialized
DEBUG - 2011-07-10 06:45:47 --> Model Class Initialized
DEBUG - 2011-07-10 06:45:47 --> Model Class Initialized
DEBUG - 2011-07-10 06:45:47 --> Model Class Initialized
DEBUG - 2011-07-10 06:45:47 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-10 06:45:47 --> Database Driver Class Initialized
DEBUG - 2011-07-10 06:45:47 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-10 06:45:47 --> Helper loaded: url_helper
DEBUG - 2011-07-10 06:45:47 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-10 06:45:47 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-10 06:45:47 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-10 06:45:47 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-10 06:45:47 --> Final output sent to browser
DEBUG - 2011-07-10 06:45:47 --> Total execution time: 0.2980
DEBUG - 2011-07-10 06:45:50 --> Config Class Initialized
DEBUG - 2011-07-10 06:45:50 --> Hooks Class Initialized
DEBUG - 2011-07-10 06:45:50 --> Utf8 Class Initialized
DEBUG - 2011-07-10 06:45:50 --> UTF-8 Support Enabled
DEBUG - 2011-07-10 06:45:50 --> URI Class Initialized
DEBUG - 2011-07-10 06:45:50 --> Router Class Initialized
ERROR - 2011-07-10 06:45:50 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-10 06:45:51 --> Config Class Initialized
DEBUG - 2011-07-10 06:45:51 --> Hooks Class Initialized
DEBUG - 2011-07-10 06:45:51 --> Utf8 Class Initialized
DEBUG - 2011-07-10 06:45:51 --> UTF-8 Support Enabled
DEBUG - 2011-07-10 06:45:51 --> URI Class Initialized
DEBUG - 2011-07-10 06:45:51 --> Router Class Initialized
DEBUG - 2011-07-10 06:45:51 --> Output Class Initialized
DEBUG - 2011-07-10 06:45:51 --> Input Class Initialized
DEBUG - 2011-07-10 06:45:51 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-10 06:45:51 --> Language Class Initialized
DEBUG - 2011-07-10 06:45:51 --> Loader Class Initialized
DEBUG - 2011-07-10 06:45:51 --> Controller Class Initialized
DEBUG - 2011-07-10 06:45:51 --> Model Class Initialized
DEBUG - 2011-07-10 06:45:51 --> Model Class Initialized
DEBUG - 2011-07-10 06:45:51 --> Model Class Initialized
DEBUG - 2011-07-10 06:45:51 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-10 06:45:51 --> Database Driver Class Initialized
DEBUG - 2011-07-10 06:45:51 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-10 06:45:51 --> Helper loaded: url_helper
DEBUG - 2011-07-10 06:45:51 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-10 06:45:51 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-10 06:45:51 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-10 06:45:51 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-10 06:45:51 --> Final output sent to browser
DEBUG - 2011-07-10 06:45:51 --> Total execution time: 0.0508
DEBUG - 2011-07-10 06:46:04 --> Config Class Initialized
DEBUG - 2011-07-10 06:46:04 --> Hooks Class Initialized
DEBUG - 2011-07-10 06:46:04 --> Utf8 Class Initialized
DEBUG - 2011-07-10 06:46:04 --> UTF-8 Support Enabled
DEBUG - 2011-07-10 06:46:04 --> URI Class Initialized
DEBUG - 2011-07-10 06:46:04 --> Router Class Initialized
DEBUG - 2011-07-10 06:46:04 --> Output Class Initialized
DEBUG - 2011-07-10 06:46:04 --> Input Class Initialized
DEBUG - 2011-07-10 06:46:04 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-10 06:46:04 --> Language Class Initialized
DEBUG - 2011-07-10 06:46:04 --> Loader Class Initialized
DEBUG - 2011-07-10 06:46:04 --> Controller Class Initialized
DEBUG - 2011-07-10 06:46:04 --> Model Class Initialized
DEBUG - 2011-07-10 06:46:04 --> Model Class Initialized
DEBUG - 2011-07-10 06:46:04 --> Model Class Initialized
DEBUG - 2011-07-10 06:46:04 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-10 06:46:04 --> Database Driver Class Initialized
DEBUG - 2011-07-10 06:46:04 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-10 06:46:04 --> Helper loaded: url_helper
DEBUG - 2011-07-10 06:46:04 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-10 06:46:04 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-10 06:46:04 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-10 06:46:04 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-10 06:46:04 --> Final output sent to browser
DEBUG - 2011-07-10 06:46:04 --> Total execution time: 0.0417
DEBUG - 2011-07-10 06:46:05 --> Config Class Initialized
DEBUG - 2011-07-10 06:46:05 --> Hooks Class Initialized
DEBUG - 2011-07-10 06:46:05 --> Utf8 Class Initialized
DEBUG - 2011-07-10 06:46:05 --> UTF-8 Support Enabled
DEBUG - 2011-07-10 06:46:05 --> URI Class Initialized
DEBUG - 2011-07-10 06:46:05 --> Router Class Initialized
DEBUG - 2011-07-10 06:46:05 --> Output Class Initialized
DEBUG - 2011-07-10 06:46:05 --> Input Class Initialized
DEBUG - 2011-07-10 06:46:05 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-10 06:46:05 --> Language Class Initialized
DEBUG - 2011-07-10 06:46:05 --> Loader Class Initialized
DEBUG - 2011-07-10 06:46:05 --> Controller Class Initialized
DEBUG - 2011-07-10 06:46:05 --> Model Class Initialized
DEBUG - 2011-07-10 06:46:05 --> Model Class Initialized
DEBUG - 2011-07-10 06:46:05 --> Model Class Initialized
DEBUG - 2011-07-10 06:46:05 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-10 06:46:05 --> Database Driver Class Initialized
DEBUG - 2011-07-10 06:46:05 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-10 06:46:05 --> Helper loaded: url_helper
DEBUG - 2011-07-10 06:46:05 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-10 06:46:05 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-10 06:46:05 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-10 06:46:05 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-10 06:46:05 --> Final output sent to browser
DEBUG - 2011-07-10 06:46:05 --> Total execution time: 0.0438
DEBUG - 2011-07-10 06:46:06 --> Config Class Initialized
DEBUG - 2011-07-10 06:46:06 --> Hooks Class Initialized
DEBUG - 2011-07-10 06:46:06 --> Utf8 Class Initialized
DEBUG - 2011-07-10 06:46:06 --> UTF-8 Support Enabled
DEBUG - 2011-07-10 06:46:06 --> URI Class Initialized
DEBUG - 2011-07-10 06:46:06 --> Router Class Initialized
ERROR - 2011-07-10 06:46:06 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-10 09:44:50 --> Config Class Initialized
DEBUG - 2011-07-10 09:44:50 --> Hooks Class Initialized
DEBUG - 2011-07-10 09:44:50 --> Utf8 Class Initialized
DEBUG - 2011-07-10 09:44:50 --> UTF-8 Support Enabled
DEBUG - 2011-07-10 09:44:50 --> URI Class Initialized
DEBUG - 2011-07-10 09:44:50 --> Router Class Initialized
DEBUG - 2011-07-10 09:44:50 --> Output Class Initialized
DEBUG - 2011-07-10 09:44:50 --> Input Class Initialized
DEBUG - 2011-07-10 09:44:50 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-10 09:44:50 --> Language Class Initialized
DEBUG - 2011-07-10 09:44:50 --> Loader Class Initialized
DEBUG - 2011-07-10 09:44:50 --> Controller Class Initialized
ERROR - 2011-07-10 09:44:50 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-10 09:44:50 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-10 09:44:50 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-10 09:44:50 --> Model Class Initialized
DEBUG - 2011-07-10 09:44:50 --> Model Class Initialized
DEBUG - 2011-07-10 09:44:50 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-10 09:44:50 --> Database Driver Class Initialized
DEBUG - 2011-07-10 09:44:50 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-10 09:44:50 --> Helper loaded: url_helper
DEBUG - 2011-07-10 09:44:50 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-10 09:44:50 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-10 09:44:50 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-10 09:44:50 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-10 09:44:50 --> Final output sent to browser
DEBUG - 2011-07-10 09:44:50 --> Total execution time: 0.4578
DEBUG - 2011-07-10 09:44:55 --> Config Class Initialized
DEBUG - 2011-07-10 09:44:55 --> Hooks Class Initialized
DEBUG - 2011-07-10 09:44:55 --> Utf8 Class Initialized
DEBUG - 2011-07-10 09:44:55 --> UTF-8 Support Enabled
DEBUG - 2011-07-10 09:44:55 --> URI Class Initialized
DEBUG - 2011-07-10 09:44:55 --> Router Class Initialized
DEBUG - 2011-07-10 09:44:55 --> Output Class Initialized
DEBUG - 2011-07-10 09:44:55 --> Input Class Initialized
DEBUG - 2011-07-10 09:44:55 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-10 09:44:55 --> Language Class Initialized
DEBUG - 2011-07-10 09:44:55 --> Loader Class Initialized
DEBUG - 2011-07-10 09:44:55 --> Controller Class Initialized
DEBUG - 2011-07-10 09:44:55 --> Model Class Initialized
DEBUG - 2011-07-10 09:44:55 --> Model Class Initialized
DEBUG - 2011-07-10 09:44:55 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-10 09:44:55 --> Database Driver Class Initialized
DEBUG - 2011-07-10 09:44:56 --> Final output sent to browser
DEBUG - 2011-07-10 09:44:56 --> Total execution time: 0.7160
DEBUG - 2011-07-10 09:44:57 --> Config Class Initialized
DEBUG - 2011-07-10 09:44:57 --> Hooks Class Initialized
DEBUG - 2011-07-10 09:44:57 --> Utf8 Class Initialized
DEBUG - 2011-07-10 09:44:57 --> UTF-8 Support Enabled
DEBUG - 2011-07-10 09:44:57 --> URI Class Initialized
DEBUG - 2011-07-10 09:44:57 --> Router Class Initialized
ERROR - 2011-07-10 09:44:57 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-10 09:45:23 --> Config Class Initialized
DEBUG - 2011-07-10 09:45:23 --> Hooks Class Initialized
DEBUG - 2011-07-10 09:45:23 --> Utf8 Class Initialized
DEBUG - 2011-07-10 09:45:23 --> UTF-8 Support Enabled
DEBUG - 2011-07-10 09:45:23 --> URI Class Initialized
DEBUG - 2011-07-10 09:45:23 --> Router Class Initialized
DEBUG - 2011-07-10 09:45:23 --> Output Class Initialized
DEBUG - 2011-07-10 09:45:23 --> Input Class Initialized
DEBUG - 2011-07-10 09:45:23 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-10 09:45:23 --> Language Class Initialized
DEBUG - 2011-07-10 09:45:23 --> Loader Class Initialized
DEBUG - 2011-07-10 09:45:23 --> Controller Class Initialized
ERROR - 2011-07-10 09:45:23 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-10 09:45:23 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-10 09:45:23 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-10 09:45:23 --> Model Class Initialized
DEBUG - 2011-07-10 09:45:23 --> Model Class Initialized
DEBUG - 2011-07-10 09:45:23 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-10 09:45:23 --> Database Driver Class Initialized
DEBUG - 2011-07-10 09:45:23 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-10 09:45:23 --> Helper loaded: url_helper
DEBUG - 2011-07-10 09:45:23 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-10 09:45:23 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-10 09:45:23 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-10 09:45:23 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-10 09:45:23 --> Final output sent to browser
DEBUG - 2011-07-10 09:45:23 --> Total execution time: 0.0455
DEBUG - 2011-07-10 09:45:24 --> Config Class Initialized
DEBUG - 2011-07-10 09:45:24 --> Hooks Class Initialized
DEBUG - 2011-07-10 09:45:24 --> Utf8 Class Initialized
DEBUG - 2011-07-10 09:45:24 --> UTF-8 Support Enabled
DEBUG - 2011-07-10 09:45:24 --> URI Class Initialized
DEBUG - 2011-07-10 09:45:24 --> Router Class Initialized
DEBUG - 2011-07-10 09:45:24 --> Output Class Initialized
DEBUG - 2011-07-10 09:45:24 --> Input Class Initialized
DEBUG - 2011-07-10 09:45:24 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-10 09:45:24 --> Language Class Initialized
DEBUG - 2011-07-10 09:45:24 --> Loader Class Initialized
DEBUG - 2011-07-10 09:45:24 --> Controller Class Initialized
DEBUG - 2011-07-10 09:45:24 --> Model Class Initialized
DEBUG - 2011-07-10 09:45:24 --> Model Class Initialized
DEBUG - 2011-07-10 09:45:24 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-10 09:45:24 --> Database Driver Class Initialized
DEBUG - 2011-07-10 09:45:25 --> Final output sent to browser
DEBUG - 2011-07-10 09:45:25 --> Total execution time: 0.6833
DEBUG - 2011-07-10 09:45:35 --> Config Class Initialized
DEBUG - 2011-07-10 09:45:35 --> Hooks Class Initialized
DEBUG - 2011-07-10 09:45:35 --> Utf8 Class Initialized
DEBUG - 2011-07-10 09:45:35 --> UTF-8 Support Enabled
DEBUG - 2011-07-10 09:45:35 --> URI Class Initialized
DEBUG - 2011-07-10 09:45:35 --> Router Class Initialized
DEBUG - 2011-07-10 09:45:35 --> Output Class Initialized
DEBUG - 2011-07-10 09:45:35 --> Input Class Initialized
DEBUG - 2011-07-10 09:45:35 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-10 09:45:35 --> Language Class Initialized
DEBUG - 2011-07-10 09:45:35 --> Loader Class Initialized
DEBUG - 2011-07-10 09:45:35 --> Controller Class Initialized
ERROR - 2011-07-10 09:45:35 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-10 09:45:35 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-10 09:45:35 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-10 09:45:35 --> Model Class Initialized
DEBUG - 2011-07-10 09:45:35 --> Model Class Initialized
DEBUG - 2011-07-10 09:45:35 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-10 09:45:35 --> Database Driver Class Initialized
DEBUG - 2011-07-10 09:45:35 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-10 09:45:35 --> Helper loaded: url_helper
DEBUG - 2011-07-10 09:45:35 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-10 09:45:35 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-10 09:45:35 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-10 09:45:35 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-10 09:45:35 --> Final output sent to browser
DEBUG - 2011-07-10 09:45:35 --> Total execution time: 0.0301
DEBUG - 2011-07-10 09:45:36 --> Config Class Initialized
DEBUG - 2011-07-10 09:45:36 --> Hooks Class Initialized
DEBUG - 2011-07-10 09:45:36 --> Utf8 Class Initialized
DEBUG - 2011-07-10 09:45:36 --> UTF-8 Support Enabled
DEBUG - 2011-07-10 09:45:36 --> URI Class Initialized
DEBUG - 2011-07-10 09:45:36 --> Router Class Initialized
DEBUG - 2011-07-10 09:45:36 --> Output Class Initialized
DEBUG - 2011-07-10 09:45:36 --> Input Class Initialized
DEBUG - 2011-07-10 09:45:36 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-10 09:45:36 --> Language Class Initialized
DEBUG - 2011-07-10 09:45:36 --> Loader Class Initialized
DEBUG - 2011-07-10 09:45:36 --> Controller Class Initialized
DEBUG - 2011-07-10 09:45:36 --> Model Class Initialized
DEBUG - 2011-07-10 09:45:36 --> Model Class Initialized
DEBUG - 2011-07-10 09:45:36 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-10 09:45:36 --> Database Driver Class Initialized
DEBUG - 2011-07-10 09:45:36 --> Final output sent to browser
DEBUG - 2011-07-10 09:45:36 --> Total execution time: 0.6396
DEBUG - 2011-07-10 09:45:46 --> Config Class Initialized
DEBUG - 2011-07-10 09:45:46 --> Hooks Class Initialized
DEBUG - 2011-07-10 09:45:46 --> Utf8 Class Initialized
DEBUG - 2011-07-10 09:45:46 --> UTF-8 Support Enabled
DEBUG - 2011-07-10 09:45:46 --> URI Class Initialized
DEBUG - 2011-07-10 09:45:46 --> Router Class Initialized
DEBUG - 2011-07-10 09:45:46 --> Output Class Initialized
DEBUG - 2011-07-10 09:45:46 --> Input Class Initialized
DEBUG - 2011-07-10 09:45:46 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-10 09:45:46 --> Language Class Initialized
DEBUG - 2011-07-10 09:45:46 --> Loader Class Initialized
DEBUG - 2011-07-10 09:45:46 --> Controller Class Initialized
ERROR - 2011-07-10 09:45:46 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-10 09:45:46 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-10 09:45:46 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-10 09:45:46 --> Model Class Initialized
DEBUG - 2011-07-10 09:45:46 --> Model Class Initialized
DEBUG - 2011-07-10 09:45:46 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-10 09:45:46 --> Database Driver Class Initialized
DEBUG - 2011-07-10 09:45:46 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-10 09:45:46 --> Helper loaded: url_helper
DEBUG - 2011-07-10 09:45:46 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-10 09:45:46 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-10 09:45:46 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-10 09:45:46 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-10 09:45:46 --> Final output sent to browser
DEBUG - 2011-07-10 09:45:46 --> Total execution time: 0.0288
DEBUG - 2011-07-10 09:45:48 --> Config Class Initialized
DEBUG - 2011-07-10 09:45:48 --> Hooks Class Initialized
DEBUG - 2011-07-10 09:45:48 --> Utf8 Class Initialized
DEBUG - 2011-07-10 09:45:48 --> UTF-8 Support Enabled
DEBUG - 2011-07-10 09:45:48 --> URI Class Initialized
DEBUG - 2011-07-10 09:45:48 --> Router Class Initialized
DEBUG - 2011-07-10 09:45:48 --> Output Class Initialized
DEBUG - 2011-07-10 09:45:48 --> Input Class Initialized
DEBUG - 2011-07-10 09:45:48 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-10 09:45:48 --> Language Class Initialized
DEBUG - 2011-07-10 09:45:48 --> Loader Class Initialized
DEBUG - 2011-07-10 09:45:48 --> Controller Class Initialized
DEBUG - 2011-07-10 09:45:48 --> Model Class Initialized
DEBUG - 2011-07-10 09:45:48 --> Model Class Initialized
DEBUG - 2011-07-10 09:45:48 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-10 09:45:48 --> Database Driver Class Initialized
DEBUG - 2011-07-10 09:45:49 --> Final output sent to browser
DEBUG - 2011-07-10 09:45:49 --> Total execution time: 0.5502
DEBUG - 2011-07-10 09:45:59 --> Config Class Initialized
DEBUG - 2011-07-10 09:45:59 --> Hooks Class Initialized
DEBUG - 2011-07-10 09:45:59 --> Utf8 Class Initialized
DEBUG - 2011-07-10 09:45:59 --> UTF-8 Support Enabled
DEBUG - 2011-07-10 09:45:59 --> URI Class Initialized
DEBUG - 2011-07-10 09:45:59 --> Router Class Initialized
DEBUG - 2011-07-10 09:45:59 --> Output Class Initialized
DEBUG - 2011-07-10 09:45:59 --> Input Class Initialized
DEBUG - 2011-07-10 09:45:59 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-10 09:45:59 --> Language Class Initialized
DEBUG - 2011-07-10 09:45:59 --> Loader Class Initialized
DEBUG - 2011-07-10 09:45:59 --> Controller Class Initialized
ERROR - 2011-07-10 09:45:59 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-10 09:45:59 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-10 09:45:59 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-10 09:45:59 --> Model Class Initialized
DEBUG - 2011-07-10 09:45:59 --> Model Class Initialized
DEBUG - 2011-07-10 09:45:59 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-10 09:45:59 --> Database Driver Class Initialized
DEBUG - 2011-07-10 09:45:59 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-10 09:45:59 --> Helper loaded: url_helper
DEBUG - 2011-07-10 09:45:59 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-10 09:45:59 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-10 09:45:59 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-10 09:45:59 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-10 09:45:59 --> Final output sent to browser
DEBUG - 2011-07-10 09:45:59 --> Total execution time: 0.0355
DEBUG - 2011-07-10 09:46:00 --> Config Class Initialized
DEBUG - 2011-07-10 09:46:00 --> Hooks Class Initialized
DEBUG - 2011-07-10 09:46:00 --> Utf8 Class Initialized
DEBUG - 2011-07-10 09:46:00 --> UTF-8 Support Enabled
DEBUG - 2011-07-10 09:46:00 --> URI Class Initialized
DEBUG - 2011-07-10 09:46:00 --> Router Class Initialized
DEBUG - 2011-07-10 09:46:00 --> Output Class Initialized
DEBUG - 2011-07-10 09:46:00 --> Input Class Initialized
DEBUG - 2011-07-10 09:46:00 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-10 09:46:00 --> Language Class Initialized
DEBUG - 2011-07-10 09:46:00 --> Loader Class Initialized
DEBUG - 2011-07-10 09:46:00 --> Controller Class Initialized
DEBUG - 2011-07-10 09:46:00 --> Model Class Initialized
DEBUG - 2011-07-10 09:46:00 --> Model Class Initialized
DEBUG - 2011-07-10 09:46:00 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-10 09:46:00 --> Database Driver Class Initialized
DEBUG - 2011-07-10 09:46:00 --> Final output sent to browser
DEBUG - 2011-07-10 09:46:00 --> Total execution time: 0.5167
DEBUG - 2011-07-10 09:48:34 --> Config Class Initialized
DEBUG - 2011-07-10 09:48:34 --> Hooks Class Initialized
DEBUG - 2011-07-10 09:48:34 --> Utf8 Class Initialized
DEBUG - 2011-07-10 09:48:34 --> UTF-8 Support Enabled
DEBUG - 2011-07-10 09:48:34 --> URI Class Initialized
DEBUG - 2011-07-10 09:48:34 --> Router Class Initialized
DEBUG - 2011-07-10 09:48:34 --> Output Class Initialized
DEBUG - 2011-07-10 09:48:34 --> Input Class Initialized
DEBUG - 2011-07-10 09:48:34 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-10 09:48:34 --> Language Class Initialized
DEBUG - 2011-07-10 09:48:34 --> Loader Class Initialized
DEBUG - 2011-07-10 09:48:34 --> Controller Class Initialized
ERROR - 2011-07-10 09:48:34 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-10 09:48:34 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-10 09:48:34 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-10 09:48:34 --> Model Class Initialized
DEBUG - 2011-07-10 09:48:34 --> Model Class Initialized
DEBUG - 2011-07-10 09:48:34 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-10 09:48:34 --> Database Driver Class Initialized
DEBUG - 2011-07-10 09:48:34 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-10 09:48:34 --> Helper loaded: url_helper
DEBUG - 2011-07-10 09:48:34 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-10 09:48:34 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-10 09:48:34 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-10 09:48:34 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-10 09:48:34 --> Final output sent to browser
DEBUG - 2011-07-10 09:48:34 --> Total execution time: 0.0276
DEBUG - 2011-07-10 09:48:35 --> Config Class Initialized
DEBUG - 2011-07-10 09:48:35 --> Hooks Class Initialized
DEBUG - 2011-07-10 09:48:35 --> Utf8 Class Initialized
DEBUG - 2011-07-10 09:48:35 --> UTF-8 Support Enabled
DEBUG - 2011-07-10 09:48:35 --> URI Class Initialized
DEBUG - 2011-07-10 09:48:35 --> Router Class Initialized
DEBUG - 2011-07-10 09:48:35 --> Output Class Initialized
DEBUG - 2011-07-10 09:48:35 --> Input Class Initialized
DEBUG - 2011-07-10 09:48:35 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-10 09:48:35 --> Language Class Initialized
DEBUG - 2011-07-10 09:48:35 --> Loader Class Initialized
DEBUG - 2011-07-10 09:48:35 --> Controller Class Initialized
ERROR - 2011-07-10 09:48:35 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-10 09:48:35 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-10 09:48:35 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-10 09:48:35 --> Model Class Initialized
DEBUG - 2011-07-10 09:48:35 --> Model Class Initialized
DEBUG - 2011-07-10 09:48:35 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-10 09:48:35 --> Database Driver Class Initialized
DEBUG - 2011-07-10 09:48:35 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-10 09:48:35 --> Helper loaded: url_helper
DEBUG - 2011-07-10 09:48:35 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-10 09:48:35 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-10 09:48:35 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-10 09:48:35 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-10 09:48:35 --> Final output sent to browser
DEBUG - 2011-07-10 09:48:35 --> Total execution time: 0.0285
DEBUG - 2011-07-10 09:48:37 --> Config Class Initialized
DEBUG - 2011-07-10 09:48:37 --> Hooks Class Initialized
DEBUG - 2011-07-10 09:48:37 --> Utf8 Class Initialized
DEBUG - 2011-07-10 09:48:37 --> UTF-8 Support Enabled
DEBUG - 2011-07-10 09:48:37 --> URI Class Initialized
DEBUG - 2011-07-10 09:48:37 --> Router Class Initialized
DEBUG - 2011-07-10 09:48:37 --> Output Class Initialized
DEBUG - 2011-07-10 09:48:37 --> Input Class Initialized
DEBUG - 2011-07-10 09:48:37 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-10 09:48:37 --> Language Class Initialized
DEBUG - 2011-07-10 09:48:37 --> Loader Class Initialized
DEBUG - 2011-07-10 09:48:37 --> Controller Class Initialized
ERROR - 2011-07-10 09:48:37 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-10 09:48:37 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-10 09:48:37 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-10 09:48:37 --> Model Class Initialized
DEBUG - 2011-07-10 09:48:37 --> Model Class Initialized
DEBUG - 2011-07-10 09:48:37 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-10 09:48:37 --> Database Driver Class Initialized
DEBUG - 2011-07-10 09:48:37 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-10 09:48:37 --> Helper loaded: url_helper
DEBUG - 2011-07-10 09:48:37 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-10 09:48:37 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-10 09:48:37 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-10 09:48:37 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-10 09:48:37 --> Final output sent to browser
DEBUG - 2011-07-10 09:48:37 --> Total execution time: 0.0289
DEBUG - 2011-07-10 09:48:43 --> Config Class Initialized
DEBUG - 2011-07-10 09:48:43 --> Hooks Class Initialized
DEBUG - 2011-07-10 09:48:43 --> Utf8 Class Initialized
DEBUG - 2011-07-10 09:48:43 --> UTF-8 Support Enabled
DEBUG - 2011-07-10 09:48:43 --> URI Class Initialized
DEBUG - 2011-07-10 09:48:43 --> Router Class Initialized
DEBUG - 2011-07-10 09:48:43 --> Output Class Initialized
DEBUG - 2011-07-10 09:48:43 --> Input Class Initialized
DEBUG - 2011-07-10 09:48:43 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-10 09:48:43 --> Language Class Initialized
DEBUG - 2011-07-10 09:48:43 --> Loader Class Initialized
DEBUG - 2011-07-10 09:48:43 --> Controller Class Initialized
ERROR - 2011-07-10 09:48:43 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-10 09:48:43 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-10 09:48:43 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-10 09:48:43 --> Model Class Initialized
DEBUG - 2011-07-10 09:48:43 --> Model Class Initialized
DEBUG - 2011-07-10 09:48:43 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-10 09:48:43 --> Database Driver Class Initialized
DEBUG - 2011-07-10 09:48:43 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-10 09:48:43 --> Helper loaded: url_helper
DEBUG - 2011-07-10 09:48:43 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-10 09:48:43 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-10 09:48:43 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-10 09:48:43 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-10 09:48:43 --> Final output sent to browser
DEBUG - 2011-07-10 09:48:43 --> Total execution time: 0.0288
DEBUG - 2011-07-10 13:16:36 --> Config Class Initialized
DEBUG - 2011-07-10 13:16:36 --> Hooks Class Initialized
DEBUG - 2011-07-10 13:16:36 --> Utf8 Class Initialized
DEBUG - 2011-07-10 13:16:36 --> UTF-8 Support Enabled
DEBUG - 2011-07-10 13:16:36 --> URI Class Initialized
DEBUG - 2011-07-10 13:16:36 --> Router Class Initialized
DEBUG - 2011-07-10 13:16:36 --> Output Class Initialized
DEBUG - 2011-07-10 13:16:36 --> Input Class Initialized
DEBUG - 2011-07-10 13:16:36 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-10 13:16:36 --> Language Class Initialized
DEBUG - 2011-07-10 13:16:36 --> Loader Class Initialized
DEBUG - 2011-07-10 13:16:36 --> Controller Class Initialized
ERROR - 2011-07-10 13:16:36 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-10 13:16:36 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-10 13:16:36 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-10 13:16:36 --> Model Class Initialized
DEBUG - 2011-07-10 13:16:36 --> Model Class Initialized
DEBUG - 2011-07-10 13:16:36 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-10 13:16:36 --> Database Driver Class Initialized
DEBUG - 2011-07-10 13:16:36 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-10 13:16:36 --> Helper loaded: url_helper
DEBUG - 2011-07-10 13:16:36 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-10 13:16:36 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-10 13:16:36 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-10 13:16:36 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-10 13:16:36 --> Final output sent to browser
DEBUG - 2011-07-10 13:16:36 --> Total execution time: 0.3233
DEBUG - 2011-07-10 13:16:37 --> Config Class Initialized
DEBUG - 2011-07-10 13:16:37 --> Hooks Class Initialized
DEBUG - 2011-07-10 13:16:37 --> Utf8 Class Initialized
DEBUG - 2011-07-10 13:16:37 --> UTF-8 Support Enabled
DEBUG - 2011-07-10 13:16:37 --> URI Class Initialized
DEBUG - 2011-07-10 13:16:37 --> Router Class Initialized
DEBUG - 2011-07-10 13:16:37 --> Output Class Initialized
DEBUG - 2011-07-10 13:16:37 --> Input Class Initialized
DEBUG - 2011-07-10 13:16:37 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-10 13:16:37 --> Language Class Initialized
DEBUG - 2011-07-10 13:16:37 --> Loader Class Initialized
DEBUG - 2011-07-10 13:16:37 --> Controller Class Initialized
DEBUG - 2011-07-10 13:16:37 --> Model Class Initialized
DEBUG - 2011-07-10 13:16:37 --> Model Class Initialized
DEBUG - 2011-07-10 13:16:37 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-10 13:16:37 --> Database Driver Class Initialized
DEBUG - 2011-07-10 13:16:38 --> Final output sent to browser
DEBUG - 2011-07-10 13:16:38 --> Total execution time: 0.6277
DEBUG - 2011-07-10 13:16:41 --> Config Class Initialized
DEBUG - 2011-07-10 13:16:41 --> Hooks Class Initialized
DEBUG - 2011-07-10 13:16:41 --> Utf8 Class Initialized
DEBUG - 2011-07-10 13:16:41 --> UTF-8 Support Enabled
DEBUG - 2011-07-10 13:16:41 --> URI Class Initialized
DEBUG - 2011-07-10 13:16:41 --> Router Class Initialized
ERROR - 2011-07-10 13:16:41 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-10 13:16:42 --> Config Class Initialized
DEBUG - 2011-07-10 13:16:42 --> Hooks Class Initialized
DEBUG - 2011-07-10 13:16:42 --> Utf8 Class Initialized
DEBUG - 2011-07-10 13:16:42 --> UTF-8 Support Enabled
DEBUG - 2011-07-10 13:16:42 --> URI Class Initialized
DEBUG - 2011-07-10 13:16:42 --> Router Class Initialized
ERROR - 2011-07-10 13:16:42 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-10 13:17:12 --> Config Class Initialized
DEBUG - 2011-07-10 13:17:12 --> Hooks Class Initialized
DEBUG - 2011-07-10 13:17:12 --> Utf8 Class Initialized
DEBUG - 2011-07-10 13:17:12 --> UTF-8 Support Enabled
DEBUG - 2011-07-10 13:17:12 --> URI Class Initialized
DEBUG - 2011-07-10 13:17:12 --> Router Class Initialized
DEBUG - 2011-07-10 13:17:12 --> Output Class Initialized
DEBUG - 2011-07-10 13:17:12 --> Input Class Initialized
DEBUG - 2011-07-10 13:17:12 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-10 13:17:12 --> Language Class Initialized
DEBUG - 2011-07-10 13:17:12 --> Loader Class Initialized
DEBUG - 2011-07-10 13:17:12 --> Controller Class Initialized
ERROR - 2011-07-10 13:17:12 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-10 13:17:12 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-10 13:17:12 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-10 13:17:12 --> Model Class Initialized
DEBUG - 2011-07-10 13:17:12 --> Model Class Initialized
DEBUG - 2011-07-10 13:17:12 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-10 13:17:12 --> Database Driver Class Initialized
DEBUG - 2011-07-10 13:17:12 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-10 13:17:12 --> Helper loaded: url_helper
DEBUG - 2011-07-10 13:17:12 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-10 13:17:12 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-10 13:17:12 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-10 13:17:12 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-10 13:17:12 --> Final output sent to browser
DEBUG - 2011-07-10 13:17:12 --> Total execution time: 0.0309
DEBUG - 2011-07-10 13:17:13 --> Config Class Initialized
DEBUG - 2011-07-10 13:17:13 --> Hooks Class Initialized
DEBUG - 2011-07-10 13:17:13 --> Utf8 Class Initialized
DEBUG - 2011-07-10 13:17:13 --> UTF-8 Support Enabled
DEBUG - 2011-07-10 13:17:13 --> URI Class Initialized
DEBUG - 2011-07-10 13:17:13 --> Router Class Initialized
DEBUG - 2011-07-10 13:17:13 --> Output Class Initialized
DEBUG - 2011-07-10 13:17:13 --> Input Class Initialized
DEBUG - 2011-07-10 13:17:13 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-10 13:17:13 --> Language Class Initialized
DEBUG - 2011-07-10 13:17:13 --> Loader Class Initialized
DEBUG - 2011-07-10 13:17:13 --> Controller Class Initialized
DEBUG - 2011-07-10 13:17:13 --> Model Class Initialized
DEBUG - 2011-07-10 13:17:13 --> Model Class Initialized
DEBUG - 2011-07-10 13:17:13 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-10 13:17:13 --> Database Driver Class Initialized
DEBUG - 2011-07-10 13:17:14 --> Final output sent to browser
DEBUG - 2011-07-10 13:17:14 --> Total execution time: 0.6367
DEBUG - 2011-07-10 13:17:14 --> Config Class Initialized
DEBUG - 2011-07-10 13:17:14 --> Hooks Class Initialized
DEBUG - 2011-07-10 13:17:14 --> Utf8 Class Initialized
DEBUG - 2011-07-10 13:17:14 --> UTF-8 Support Enabled
DEBUG - 2011-07-10 13:17:14 --> URI Class Initialized
DEBUG - 2011-07-10 13:17:14 --> Router Class Initialized
ERROR - 2011-07-10 13:17:14 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-07-10 13:17:14 --> Config Class Initialized
DEBUG - 2011-07-10 13:17:14 --> Hooks Class Initialized
DEBUG - 2011-07-10 13:17:14 --> Utf8 Class Initialized
DEBUG - 2011-07-10 13:17:14 --> UTF-8 Support Enabled
DEBUG - 2011-07-10 13:17:14 --> URI Class Initialized
DEBUG - 2011-07-10 13:17:14 --> Router Class Initialized
DEBUG - 2011-07-10 13:17:14 --> Output Class Initialized
DEBUG - 2011-07-10 13:17:14 --> Input Class Initialized
DEBUG - 2011-07-10 13:17:14 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-10 13:17:14 --> Language Class Initialized
DEBUG - 2011-07-10 13:17:14 --> Loader Class Initialized
DEBUG - 2011-07-10 13:17:14 --> Controller Class Initialized
ERROR - 2011-07-10 13:17:14 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-10 13:17:14 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-10 13:17:14 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-10 13:17:14 --> Model Class Initialized
DEBUG - 2011-07-10 13:17:14 --> Model Class Initialized
DEBUG - 2011-07-10 13:17:14 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-10 13:17:14 --> Database Driver Class Initialized
DEBUG - 2011-07-10 13:17:14 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-10 13:17:14 --> Helper loaded: url_helper
DEBUG - 2011-07-10 13:17:14 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-10 13:17:14 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-10 13:17:14 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-10 13:17:14 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-10 13:17:14 --> Final output sent to browser
DEBUG - 2011-07-10 13:17:14 --> Total execution time: 0.0319
DEBUG - 2011-07-10 13:17:20 --> Config Class Initialized
DEBUG - 2011-07-10 13:17:20 --> Hooks Class Initialized
DEBUG - 2011-07-10 13:17:20 --> Utf8 Class Initialized
DEBUG - 2011-07-10 13:17:20 --> UTF-8 Support Enabled
DEBUG - 2011-07-10 13:17:20 --> URI Class Initialized
DEBUG - 2011-07-10 13:17:20 --> Router Class Initialized
DEBUG - 2011-07-10 13:17:20 --> Output Class Initialized
DEBUG - 2011-07-10 13:17:20 --> Input Class Initialized
DEBUG - 2011-07-10 13:17:20 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-10 13:17:20 --> Language Class Initialized
DEBUG - 2011-07-10 13:17:20 --> Loader Class Initialized
DEBUG - 2011-07-10 13:17:20 --> Controller Class Initialized
ERROR - 2011-07-10 13:17:20 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-10 13:17:20 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-10 13:17:20 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-10 13:17:20 --> Model Class Initialized
DEBUG - 2011-07-10 13:17:20 --> Model Class Initialized
DEBUG - 2011-07-10 13:17:20 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-10 13:17:20 --> Database Driver Class Initialized
DEBUG - 2011-07-10 13:17:20 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-10 13:17:20 --> Helper loaded: url_helper
DEBUG - 2011-07-10 13:17:20 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-10 13:17:20 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-10 13:17:20 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-10 13:17:20 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-10 13:17:20 --> Final output sent to browser
DEBUG - 2011-07-10 13:17:20 --> Total execution time: 0.0295
DEBUG - 2011-07-10 13:17:21 --> Config Class Initialized
DEBUG - 2011-07-10 13:17:21 --> Hooks Class Initialized
DEBUG - 2011-07-10 13:17:21 --> Utf8 Class Initialized
DEBUG - 2011-07-10 13:17:21 --> UTF-8 Support Enabled
DEBUG - 2011-07-10 13:17:21 --> URI Class Initialized
DEBUG - 2011-07-10 13:17:21 --> Router Class Initialized
DEBUG - 2011-07-10 13:17:21 --> Output Class Initialized
DEBUG - 2011-07-10 13:17:21 --> Input Class Initialized
DEBUG - 2011-07-10 13:17:21 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-10 13:17:21 --> Language Class Initialized
DEBUG - 2011-07-10 13:17:21 --> Loader Class Initialized
DEBUG - 2011-07-10 13:17:21 --> Controller Class Initialized
DEBUG - 2011-07-10 13:17:21 --> Model Class Initialized
DEBUG - 2011-07-10 13:17:21 --> Model Class Initialized
DEBUG - 2011-07-10 13:17:21 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-10 13:17:21 --> Database Driver Class Initialized
DEBUG - 2011-07-10 13:17:21 --> Final output sent to browser
DEBUG - 2011-07-10 13:17:21 --> Total execution time: 0.5792
DEBUG - 2011-07-10 13:17:37 --> Config Class Initialized
DEBUG - 2011-07-10 13:17:37 --> Hooks Class Initialized
DEBUG - 2011-07-10 13:17:37 --> Utf8 Class Initialized
DEBUG - 2011-07-10 13:17:37 --> UTF-8 Support Enabled
DEBUG - 2011-07-10 13:17:37 --> URI Class Initialized
DEBUG - 2011-07-10 13:17:37 --> Router Class Initialized
DEBUG - 2011-07-10 13:17:37 --> Output Class Initialized
DEBUG - 2011-07-10 13:17:37 --> Input Class Initialized
DEBUG - 2011-07-10 13:17:37 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-10 13:17:37 --> Language Class Initialized
DEBUG - 2011-07-10 13:17:37 --> Loader Class Initialized
DEBUG - 2011-07-10 13:17:37 --> Controller Class Initialized
ERROR - 2011-07-10 13:17:37 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-10 13:17:37 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-10 13:17:37 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-10 13:17:37 --> Model Class Initialized
DEBUG - 2011-07-10 13:17:37 --> Model Class Initialized
DEBUG - 2011-07-10 13:17:37 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-10 13:17:37 --> Database Driver Class Initialized
DEBUG - 2011-07-10 13:17:37 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-10 13:17:37 --> Helper loaded: url_helper
DEBUG - 2011-07-10 13:17:37 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-10 13:17:37 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-10 13:17:37 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-10 13:17:37 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-10 13:17:37 --> Final output sent to browser
DEBUG - 2011-07-10 13:17:37 --> Total execution time: 0.0270
DEBUG - 2011-07-10 13:17:38 --> Config Class Initialized
DEBUG - 2011-07-10 13:17:38 --> Hooks Class Initialized
DEBUG - 2011-07-10 13:17:38 --> Utf8 Class Initialized
DEBUG - 2011-07-10 13:17:38 --> UTF-8 Support Enabled
DEBUG - 2011-07-10 13:17:38 --> URI Class Initialized
DEBUG - 2011-07-10 13:17:38 --> Router Class Initialized
DEBUG - 2011-07-10 13:17:38 --> Output Class Initialized
DEBUG - 2011-07-10 13:17:38 --> Input Class Initialized
DEBUG - 2011-07-10 13:17:38 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-10 13:17:38 --> Language Class Initialized
DEBUG - 2011-07-10 13:17:38 --> Loader Class Initialized
DEBUG - 2011-07-10 13:17:38 --> Controller Class Initialized
DEBUG - 2011-07-10 13:17:38 --> Model Class Initialized
DEBUG - 2011-07-10 13:17:38 --> Model Class Initialized
DEBUG - 2011-07-10 13:17:38 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-10 13:17:38 --> Database Driver Class Initialized
DEBUG - 2011-07-10 13:17:39 --> Final output sent to browser
DEBUG - 2011-07-10 13:17:39 --> Total execution time: 0.5625
DEBUG - 2011-07-10 13:17:39 --> Config Class Initialized
DEBUG - 2011-07-10 13:17:39 --> Hooks Class Initialized
DEBUG - 2011-07-10 13:17:39 --> Utf8 Class Initialized
DEBUG - 2011-07-10 13:17:39 --> UTF-8 Support Enabled
DEBUG - 2011-07-10 13:17:39 --> URI Class Initialized
DEBUG - 2011-07-10 13:17:39 --> Router Class Initialized
DEBUG - 2011-07-10 13:17:39 --> Output Class Initialized
DEBUG - 2011-07-10 13:17:39 --> Input Class Initialized
DEBUG - 2011-07-10 13:17:39 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-10 13:17:39 --> Language Class Initialized
DEBUG - 2011-07-10 13:17:39 --> Loader Class Initialized
DEBUG - 2011-07-10 13:17:39 --> Controller Class Initialized
ERROR - 2011-07-10 13:17:39 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-10 13:17:39 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-10 13:17:39 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-10 13:17:39 --> Model Class Initialized
DEBUG - 2011-07-10 13:17:39 --> Model Class Initialized
DEBUG - 2011-07-10 13:17:39 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-10 13:17:39 --> Database Driver Class Initialized
DEBUG - 2011-07-10 13:17:39 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-10 13:17:39 --> Helper loaded: url_helper
DEBUG - 2011-07-10 13:17:39 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-10 13:17:39 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-10 13:17:39 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-10 13:17:39 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-10 13:17:39 --> Final output sent to browser
DEBUG - 2011-07-10 13:17:39 --> Total execution time: 0.0285
DEBUG - 2011-07-10 13:17:40 --> Config Class Initialized
DEBUG - 2011-07-10 13:17:40 --> Hooks Class Initialized
DEBUG - 2011-07-10 13:17:40 --> Utf8 Class Initialized
DEBUG - 2011-07-10 13:17:40 --> UTF-8 Support Enabled
DEBUG - 2011-07-10 13:17:40 --> URI Class Initialized
DEBUG - 2011-07-10 13:17:40 --> Router Class Initialized
DEBUG - 2011-07-10 13:17:40 --> Output Class Initialized
DEBUG - 2011-07-10 13:17:40 --> Input Class Initialized
DEBUG - 2011-07-10 13:17:40 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-10 13:17:40 --> Language Class Initialized
DEBUG - 2011-07-10 13:17:40 --> Loader Class Initialized
DEBUG - 2011-07-10 13:17:40 --> Controller Class Initialized
ERROR - 2011-07-10 13:17:40 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-10 13:17:40 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-10 13:17:40 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-10 13:17:40 --> Model Class Initialized
DEBUG - 2011-07-10 13:17:40 --> Model Class Initialized
DEBUG - 2011-07-10 13:17:40 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-10 13:17:40 --> Database Driver Class Initialized
DEBUG - 2011-07-10 13:17:40 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-10 13:17:40 --> Helper loaded: url_helper
DEBUG - 2011-07-10 13:17:40 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-10 13:17:40 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-10 13:17:40 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-10 13:17:40 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-10 13:17:40 --> Final output sent to browser
DEBUG - 2011-07-10 13:17:40 --> Total execution time: 0.0931
DEBUG - 2011-07-10 13:17:56 --> Config Class Initialized
DEBUG - 2011-07-10 13:17:56 --> Hooks Class Initialized
DEBUG - 2011-07-10 13:17:56 --> Utf8 Class Initialized
DEBUG - 2011-07-10 13:17:56 --> UTF-8 Support Enabled
DEBUG - 2011-07-10 13:17:56 --> URI Class Initialized
DEBUG - 2011-07-10 13:17:56 --> Router Class Initialized
DEBUG - 2011-07-10 13:17:56 --> Output Class Initialized
DEBUG - 2011-07-10 13:17:56 --> Input Class Initialized
DEBUG - 2011-07-10 13:17:56 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-10 13:17:56 --> Language Class Initialized
DEBUG - 2011-07-10 13:17:56 --> Loader Class Initialized
DEBUG - 2011-07-10 13:17:56 --> Controller Class Initialized
ERROR - 2011-07-10 13:17:56 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-10 13:17:56 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-10 13:17:56 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-10 13:17:56 --> Model Class Initialized
DEBUG - 2011-07-10 13:17:56 --> Model Class Initialized
DEBUG - 2011-07-10 13:17:56 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-10 13:17:56 --> Database Driver Class Initialized
DEBUG - 2011-07-10 13:17:56 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-10 13:17:56 --> Helper loaded: url_helper
DEBUG - 2011-07-10 13:17:56 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-10 13:17:56 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-10 13:17:56 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-10 13:17:56 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-10 13:17:56 --> Final output sent to browser
DEBUG - 2011-07-10 13:17:56 --> Total execution time: 0.0454
DEBUG - 2011-07-10 13:17:57 --> Config Class Initialized
DEBUG - 2011-07-10 13:17:57 --> Hooks Class Initialized
DEBUG - 2011-07-10 13:17:57 --> Utf8 Class Initialized
DEBUG - 2011-07-10 13:17:57 --> UTF-8 Support Enabled
DEBUG - 2011-07-10 13:17:57 --> URI Class Initialized
DEBUG - 2011-07-10 13:17:57 --> Router Class Initialized
DEBUG - 2011-07-10 13:17:57 --> Output Class Initialized
DEBUG - 2011-07-10 13:17:57 --> Input Class Initialized
DEBUG - 2011-07-10 13:17:57 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-10 13:17:57 --> Language Class Initialized
DEBUG - 2011-07-10 13:17:57 --> Loader Class Initialized
DEBUG - 2011-07-10 13:17:57 --> Controller Class Initialized
DEBUG - 2011-07-10 13:17:57 --> Model Class Initialized
DEBUG - 2011-07-10 13:17:57 --> Model Class Initialized
DEBUG - 2011-07-10 13:17:57 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-10 13:17:57 --> Database Driver Class Initialized
DEBUG - 2011-07-10 13:17:58 --> Final output sent to browser
DEBUG - 2011-07-10 13:17:58 --> Total execution time: 0.5653
DEBUG - 2011-07-10 13:18:06 --> Config Class Initialized
DEBUG - 2011-07-10 13:18:06 --> Hooks Class Initialized
DEBUG - 2011-07-10 13:18:06 --> Utf8 Class Initialized
DEBUG - 2011-07-10 13:18:06 --> UTF-8 Support Enabled
DEBUG - 2011-07-10 13:18:06 --> URI Class Initialized
DEBUG - 2011-07-10 13:18:06 --> Router Class Initialized
DEBUG - 2011-07-10 13:18:06 --> Output Class Initialized
DEBUG - 2011-07-10 13:18:06 --> Input Class Initialized
DEBUG - 2011-07-10 13:18:06 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-10 13:18:06 --> Language Class Initialized
DEBUG - 2011-07-10 13:18:06 --> Loader Class Initialized
DEBUG - 2011-07-10 13:18:06 --> Controller Class Initialized
ERROR - 2011-07-10 13:18:06 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-10 13:18:06 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-10 13:18:06 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-10 13:18:06 --> Model Class Initialized
DEBUG - 2011-07-10 13:18:06 --> Model Class Initialized
DEBUG - 2011-07-10 13:18:06 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-10 13:18:06 --> Database Driver Class Initialized
DEBUG - 2011-07-10 13:18:06 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-10 13:18:06 --> Helper loaded: url_helper
DEBUG - 2011-07-10 13:18:06 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-10 13:18:06 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-10 13:18:06 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-10 13:18:06 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-10 13:18:06 --> Final output sent to browser
DEBUG - 2011-07-10 13:18:06 --> Total execution time: 0.0318
DEBUG - 2011-07-10 13:18:07 --> Config Class Initialized
DEBUG - 2011-07-10 13:18:07 --> Hooks Class Initialized
DEBUG - 2011-07-10 13:18:07 --> Utf8 Class Initialized
DEBUG - 2011-07-10 13:18:07 --> UTF-8 Support Enabled
DEBUG - 2011-07-10 13:18:07 --> URI Class Initialized
DEBUG - 2011-07-10 13:18:07 --> Router Class Initialized
DEBUG - 2011-07-10 13:18:07 --> Output Class Initialized
DEBUG - 2011-07-10 13:18:07 --> Input Class Initialized
DEBUG - 2011-07-10 13:18:07 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-10 13:18:07 --> Language Class Initialized
DEBUG - 2011-07-10 13:18:07 --> Loader Class Initialized
DEBUG - 2011-07-10 13:18:07 --> Controller Class Initialized
DEBUG - 2011-07-10 13:18:07 --> Model Class Initialized
DEBUG - 2011-07-10 13:18:07 --> Model Class Initialized
DEBUG - 2011-07-10 13:18:07 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-10 13:18:07 --> Database Driver Class Initialized
DEBUG - 2011-07-10 13:18:07 --> Final output sent to browser
DEBUG - 2011-07-10 13:18:07 --> Total execution time: 0.5353
DEBUG - 2011-07-10 13:18:15 --> Config Class Initialized
DEBUG - 2011-07-10 13:18:15 --> Hooks Class Initialized
DEBUG - 2011-07-10 13:18:15 --> Utf8 Class Initialized
DEBUG - 2011-07-10 13:18:15 --> UTF-8 Support Enabled
DEBUG - 2011-07-10 13:18:15 --> URI Class Initialized
DEBUG - 2011-07-10 13:18:15 --> Router Class Initialized
DEBUG - 2011-07-10 13:18:15 --> Output Class Initialized
DEBUG - 2011-07-10 13:18:15 --> Input Class Initialized
DEBUG - 2011-07-10 13:18:15 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-10 13:18:15 --> Language Class Initialized
DEBUG - 2011-07-10 13:18:15 --> Loader Class Initialized
DEBUG - 2011-07-10 13:18:15 --> Controller Class Initialized
ERROR - 2011-07-10 13:18:15 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-10 13:18:15 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-10 13:18:15 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-10 13:18:15 --> Model Class Initialized
DEBUG - 2011-07-10 13:18:15 --> Model Class Initialized
DEBUG - 2011-07-10 13:18:15 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-10 13:18:15 --> Database Driver Class Initialized
DEBUG - 2011-07-10 13:18:15 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-10 13:18:15 --> Helper loaded: url_helper
DEBUG - 2011-07-10 13:18:15 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-10 13:18:15 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-10 13:18:15 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-10 13:18:15 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-10 13:18:15 --> Final output sent to browser
DEBUG - 2011-07-10 13:18:15 --> Total execution time: 0.0285
DEBUG - 2011-07-10 13:18:16 --> Config Class Initialized
DEBUG - 2011-07-10 13:18:16 --> Hooks Class Initialized
DEBUG - 2011-07-10 13:18:16 --> Utf8 Class Initialized
DEBUG - 2011-07-10 13:18:16 --> UTF-8 Support Enabled
DEBUG - 2011-07-10 13:18:16 --> URI Class Initialized
DEBUG - 2011-07-10 13:18:16 --> Router Class Initialized
DEBUG - 2011-07-10 13:18:16 --> Output Class Initialized
DEBUG - 2011-07-10 13:18:16 --> Input Class Initialized
DEBUG - 2011-07-10 13:18:16 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-10 13:18:16 --> Language Class Initialized
DEBUG - 2011-07-10 13:18:16 --> Loader Class Initialized
DEBUG - 2011-07-10 13:18:16 --> Controller Class Initialized
DEBUG - 2011-07-10 13:18:16 --> Model Class Initialized
DEBUG - 2011-07-10 13:18:16 --> Model Class Initialized
DEBUG - 2011-07-10 13:18:16 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-10 13:18:16 --> Database Driver Class Initialized
DEBUG - 2011-07-10 13:18:17 --> Final output sent to browser
DEBUG - 2011-07-10 13:18:17 --> Total execution time: 0.5225
DEBUG - 2011-07-10 13:18:27 --> Config Class Initialized
DEBUG - 2011-07-10 13:18:27 --> Hooks Class Initialized
DEBUG - 2011-07-10 13:18:27 --> Utf8 Class Initialized
DEBUG - 2011-07-10 13:18:27 --> UTF-8 Support Enabled
DEBUG - 2011-07-10 13:18:27 --> URI Class Initialized
DEBUG - 2011-07-10 13:18:27 --> Router Class Initialized
DEBUG - 2011-07-10 13:18:27 --> Output Class Initialized
DEBUG - 2011-07-10 13:18:27 --> Input Class Initialized
DEBUG - 2011-07-10 13:18:27 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-10 13:18:27 --> Language Class Initialized
DEBUG - 2011-07-10 13:18:27 --> Loader Class Initialized
DEBUG - 2011-07-10 13:18:27 --> Controller Class Initialized
ERROR - 2011-07-10 13:18:27 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-10 13:18:27 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-10 13:18:27 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-10 13:18:27 --> Model Class Initialized
DEBUG - 2011-07-10 13:18:27 --> Model Class Initialized
DEBUG - 2011-07-10 13:18:27 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-10 13:18:27 --> Database Driver Class Initialized
DEBUG - 2011-07-10 13:18:27 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-10 13:18:27 --> Helper loaded: url_helper
DEBUG - 2011-07-10 13:18:27 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-10 13:18:27 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-10 13:18:27 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-10 13:18:27 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-10 13:18:27 --> Final output sent to browser
DEBUG - 2011-07-10 13:18:27 --> Total execution time: 0.0288
DEBUG - 2011-07-10 13:18:27 --> Config Class Initialized
DEBUG - 2011-07-10 13:18:27 --> Hooks Class Initialized
DEBUG - 2011-07-10 13:18:27 --> Utf8 Class Initialized
DEBUG - 2011-07-10 13:18:27 --> UTF-8 Support Enabled
DEBUG - 2011-07-10 13:18:27 --> URI Class Initialized
DEBUG - 2011-07-10 13:18:27 --> Router Class Initialized
DEBUG - 2011-07-10 13:18:27 --> Output Class Initialized
DEBUG - 2011-07-10 13:18:27 --> Input Class Initialized
DEBUG - 2011-07-10 13:18:27 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-10 13:18:27 --> Language Class Initialized
DEBUG - 2011-07-10 13:18:27 --> Loader Class Initialized
DEBUG - 2011-07-10 13:18:27 --> Controller Class Initialized
DEBUG - 2011-07-10 13:18:27 --> Model Class Initialized
DEBUG - 2011-07-10 13:18:27 --> Model Class Initialized
DEBUG - 2011-07-10 13:18:27 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-10 13:18:27 --> Database Driver Class Initialized
DEBUG - 2011-07-10 13:18:28 --> Final output sent to browser
DEBUG - 2011-07-10 13:18:28 --> Total execution time: 0.5697
DEBUG - 2011-07-10 13:18:55 --> Config Class Initialized
DEBUG - 2011-07-10 13:18:55 --> Hooks Class Initialized
DEBUG - 2011-07-10 13:18:55 --> Utf8 Class Initialized
DEBUG - 2011-07-10 13:18:55 --> UTF-8 Support Enabled
DEBUG - 2011-07-10 13:18:55 --> URI Class Initialized
DEBUG - 2011-07-10 13:18:55 --> Router Class Initialized
DEBUG - 2011-07-10 13:18:55 --> Output Class Initialized
DEBUG - 2011-07-10 13:18:55 --> Input Class Initialized
DEBUG - 2011-07-10 13:18:55 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-10 13:18:55 --> Language Class Initialized
DEBUG - 2011-07-10 13:18:55 --> Loader Class Initialized
DEBUG - 2011-07-10 13:18:55 --> Controller Class Initialized
ERROR - 2011-07-10 13:18:55 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-10 13:18:55 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-10 13:18:55 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-10 13:18:55 --> Model Class Initialized
DEBUG - 2011-07-10 13:18:55 --> Model Class Initialized
DEBUG - 2011-07-10 13:18:55 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-10 13:18:55 --> Database Driver Class Initialized
DEBUG - 2011-07-10 13:18:55 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-10 13:18:55 --> Helper loaded: url_helper
DEBUG - 2011-07-10 13:18:55 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-10 13:18:55 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-10 13:18:55 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-10 13:18:55 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-10 13:18:55 --> Final output sent to browser
DEBUG - 2011-07-10 13:18:55 --> Total execution time: 0.0273
DEBUG - 2011-07-10 13:18:56 --> Config Class Initialized
DEBUG - 2011-07-10 13:18:56 --> Hooks Class Initialized
DEBUG - 2011-07-10 13:18:56 --> Utf8 Class Initialized
DEBUG - 2011-07-10 13:18:56 --> UTF-8 Support Enabled
DEBUG - 2011-07-10 13:18:56 --> URI Class Initialized
DEBUG - 2011-07-10 13:18:56 --> Router Class Initialized
DEBUG - 2011-07-10 13:18:56 --> Output Class Initialized
DEBUG - 2011-07-10 13:18:56 --> Input Class Initialized
DEBUG - 2011-07-10 13:18:56 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-10 13:18:56 --> Language Class Initialized
DEBUG - 2011-07-10 13:18:56 --> Loader Class Initialized
DEBUG - 2011-07-10 13:18:56 --> Controller Class Initialized
ERROR - 2011-07-10 13:18:56 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-10 13:18:56 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-10 13:18:56 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-10 13:18:56 --> Model Class Initialized
DEBUG - 2011-07-10 13:18:56 --> Model Class Initialized
DEBUG - 2011-07-10 13:18:56 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-10 13:18:56 --> Database Driver Class Initialized
DEBUG - 2011-07-10 13:18:56 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-10 13:18:56 --> Helper loaded: url_helper
DEBUG - 2011-07-10 13:18:56 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-10 13:18:56 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-10 13:18:56 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-10 13:18:56 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-10 13:18:56 --> Final output sent to browser
DEBUG - 2011-07-10 13:18:56 --> Total execution time: 0.0291
DEBUG - 2011-07-10 13:18:57 --> Config Class Initialized
DEBUG - 2011-07-10 13:18:57 --> Hooks Class Initialized
DEBUG - 2011-07-10 13:18:57 --> Utf8 Class Initialized
DEBUG - 2011-07-10 13:18:57 --> UTF-8 Support Enabled
DEBUG - 2011-07-10 13:18:57 --> URI Class Initialized
DEBUG - 2011-07-10 13:18:57 --> Router Class Initialized
DEBUG - 2011-07-10 13:18:57 --> Output Class Initialized
DEBUG - 2011-07-10 13:18:57 --> Input Class Initialized
DEBUG - 2011-07-10 13:18:57 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-10 13:18:57 --> Language Class Initialized
DEBUG - 2011-07-10 13:18:57 --> Loader Class Initialized
DEBUG - 2011-07-10 13:18:57 --> Controller Class Initialized
ERROR - 2011-07-10 13:18:57 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-10 13:18:57 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-10 13:18:57 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-10 13:18:57 --> Model Class Initialized
DEBUG - 2011-07-10 13:18:57 --> Model Class Initialized
DEBUG - 2011-07-10 13:18:57 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-10 13:18:57 --> Database Driver Class Initialized
DEBUG - 2011-07-10 13:18:57 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-10 13:18:57 --> Helper loaded: url_helper
DEBUG - 2011-07-10 13:18:57 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-10 13:18:57 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-10 13:18:57 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-10 13:18:57 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-10 13:18:57 --> Final output sent to browser
DEBUG - 2011-07-10 13:18:57 --> Total execution time: 0.0333
DEBUG - 2011-07-10 13:18:58 --> Config Class Initialized
DEBUG - 2011-07-10 13:18:58 --> Hooks Class Initialized
DEBUG - 2011-07-10 13:18:58 --> Utf8 Class Initialized
DEBUG - 2011-07-10 13:18:58 --> UTF-8 Support Enabled
DEBUG - 2011-07-10 13:18:58 --> URI Class Initialized
DEBUG - 2011-07-10 13:18:58 --> Router Class Initialized
DEBUG - 2011-07-10 13:18:58 --> Output Class Initialized
DEBUG - 2011-07-10 13:18:58 --> Input Class Initialized
DEBUG - 2011-07-10 13:18:58 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-10 13:18:58 --> Language Class Initialized
DEBUG - 2011-07-10 13:18:58 --> Loader Class Initialized
DEBUG - 2011-07-10 13:18:58 --> Controller Class Initialized
ERROR - 2011-07-10 13:18:58 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-10 13:18:58 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-10 13:18:58 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-10 13:18:58 --> Model Class Initialized
DEBUG - 2011-07-10 13:18:58 --> Model Class Initialized
DEBUG - 2011-07-10 13:18:58 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-10 13:18:58 --> Database Driver Class Initialized
DEBUG - 2011-07-10 13:18:58 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-10 13:18:58 --> Helper loaded: url_helper
DEBUG - 2011-07-10 13:18:58 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-10 13:18:58 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-10 13:18:58 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-10 13:18:58 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-10 13:18:58 --> Final output sent to browser
DEBUG - 2011-07-10 13:18:58 --> Total execution time: 0.0282
DEBUG - 2011-07-10 14:32:39 --> Config Class Initialized
DEBUG - 2011-07-10 14:32:39 --> Hooks Class Initialized
DEBUG - 2011-07-10 14:32:39 --> Utf8 Class Initialized
DEBUG - 2011-07-10 14:32:39 --> UTF-8 Support Enabled
DEBUG - 2011-07-10 14:32:39 --> URI Class Initialized
DEBUG - 2011-07-10 14:32:39 --> Router Class Initialized
DEBUG - 2011-07-10 14:32:39 --> Output Class Initialized
DEBUG - 2011-07-10 14:32:39 --> Input Class Initialized
DEBUG - 2011-07-10 14:32:39 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-10 14:32:39 --> Language Class Initialized
DEBUG - 2011-07-10 14:32:39 --> Loader Class Initialized
DEBUG - 2011-07-10 14:32:39 --> Controller Class Initialized
ERROR - 2011-07-10 14:32:39 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-10 14:32:39 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-10 14:32:39 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-10 14:32:39 --> Model Class Initialized
DEBUG - 2011-07-10 14:32:39 --> Model Class Initialized
DEBUG - 2011-07-10 14:32:39 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-10 14:32:39 --> Database Driver Class Initialized
DEBUG - 2011-07-10 14:32:39 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-10 14:32:39 --> Helper loaded: url_helper
DEBUG - 2011-07-10 14:32:39 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-10 14:32:39 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-10 14:32:39 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-10 14:32:39 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-10 14:32:39 --> Final output sent to browser
DEBUG - 2011-07-10 14:32:39 --> Total execution time: 0.3064
DEBUG - 2011-07-10 15:59:24 --> Config Class Initialized
DEBUG - 2011-07-10 15:59:24 --> Hooks Class Initialized
DEBUG - 2011-07-10 15:59:24 --> Utf8 Class Initialized
DEBUG - 2011-07-10 15:59:24 --> UTF-8 Support Enabled
DEBUG - 2011-07-10 15:59:24 --> URI Class Initialized
DEBUG - 2011-07-10 15:59:24 --> Router Class Initialized
DEBUG - 2011-07-10 15:59:24 --> Output Class Initialized
DEBUG - 2011-07-10 15:59:24 --> Input Class Initialized
DEBUG - 2011-07-10 15:59:24 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-10 15:59:24 --> Language Class Initialized
DEBUG - 2011-07-10 15:59:24 --> Loader Class Initialized
DEBUG - 2011-07-10 15:59:24 --> Controller Class Initialized
DEBUG - 2011-07-10 15:59:24 --> Model Class Initialized
DEBUG - 2011-07-10 15:59:24 --> Model Class Initialized
DEBUG - 2011-07-10 15:59:24 --> Model Class Initialized
DEBUG - 2011-07-10 15:59:24 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-10 15:59:24 --> Database Driver Class Initialized
DEBUG - 2011-07-10 15:59:25 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-10 15:59:25 --> Helper loaded: url_helper
DEBUG - 2011-07-10 15:59:25 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-10 15:59:25 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-10 15:59:25 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-10 15:59:25 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-10 15:59:25 --> Final output sent to browser
DEBUG - 2011-07-10 15:59:25 --> Total execution time: 1.4052
DEBUG - 2011-07-10 15:59:30 --> Config Class Initialized
DEBUG - 2011-07-10 15:59:30 --> Hooks Class Initialized
DEBUG - 2011-07-10 15:59:30 --> Utf8 Class Initialized
DEBUG - 2011-07-10 15:59:30 --> UTF-8 Support Enabled
DEBUG - 2011-07-10 15:59:30 --> URI Class Initialized
DEBUG - 2011-07-10 15:59:30 --> Router Class Initialized
ERROR - 2011-07-10 15:59:30 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-10 15:59:55 --> Config Class Initialized
DEBUG - 2011-07-10 15:59:55 --> Hooks Class Initialized
DEBUG - 2011-07-10 15:59:55 --> Utf8 Class Initialized
DEBUG - 2011-07-10 15:59:55 --> UTF-8 Support Enabled
DEBUG - 2011-07-10 15:59:55 --> URI Class Initialized
DEBUG - 2011-07-10 15:59:55 --> Router Class Initialized
DEBUG - 2011-07-10 15:59:55 --> Output Class Initialized
DEBUG - 2011-07-10 15:59:55 --> Input Class Initialized
DEBUG - 2011-07-10 15:59:55 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-10 15:59:55 --> Language Class Initialized
DEBUG - 2011-07-10 15:59:55 --> Loader Class Initialized
DEBUG - 2011-07-10 15:59:55 --> Controller Class Initialized
DEBUG - 2011-07-10 15:59:55 --> Model Class Initialized
DEBUG - 2011-07-10 15:59:55 --> Model Class Initialized
DEBUG - 2011-07-10 15:59:55 --> Model Class Initialized
DEBUG - 2011-07-10 15:59:55 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-10 15:59:55 --> Database Driver Class Initialized
DEBUG - 2011-07-10 15:59:55 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-10 15:59:55 --> Helper loaded: url_helper
DEBUG - 2011-07-10 15:59:55 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-10 15:59:55 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-10 15:59:55 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-10 15:59:55 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-10 15:59:55 --> Final output sent to browser
DEBUG - 2011-07-10 15:59:55 --> Total execution time: 0.0698
DEBUG - 2011-07-10 16:27:06 --> Config Class Initialized
DEBUG - 2011-07-10 16:27:06 --> Hooks Class Initialized
DEBUG - 2011-07-10 16:27:06 --> Utf8 Class Initialized
DEBUG - 2011-07-10 16:27:06 --> UTF-8 Support Enabled
DEBUG - 2011-07-10 16:27:06 --> URI Class Initialized
DEBUG - 2011-07-10 16:27:06 --> Router Class Initialized
ERROR - 2011-07-10 16:27:06 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-07-10 16:28:13 --> Config Class Initialized
DEBUG - 2011-07-10 16:28:13 --> Hooks Class Initialized
DEBUG - 2011-07-10 16:28:13 --> Utf8 Class Initialized
DEBUG - 2011-07-10 16:28:13 --> UTF-8 Support Enabled
DEBUG - 2011-07-10 16:28:13 --> URI Class Initialized
DEBUG - 2011-07-10 16:28:13 --> Router Class Initialized
DEBUG - 2011-07-10 16:28:13 --> No URI present. Default controller set.
DEBUG - 2011-07-10 16:28:13 --> Output Class Initialized
DEBUG - 2011-07-10 16:28:13 --> Input Class Initialized
DEBUG - 2011-07-10 16:28:13 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-10 16:28:13 --> Language Class Initialized
DEBUG - 2011-07-10 16:28:13 --> Loader Class Initialized
DEBUG - 2011-07-10 16:28:13 --> Controller Class Initialized
DEBUG - 2011-07-10 16:28:13 --> File loaded: application/views/splash/main.php
DEBUG - 2011-07-10 16:28:13 --> Helper loaded: url_helper
DEBUG - 2011-07-10 16:28:13 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-10 16:28:13 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-10 16:28:13 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-10 16:28:13 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-10 16:28:13 --> Final output sent to browser
DEBUG - 2011-07-10 16:28:13 --> Total execution time: 0.1755
DEBUG - 2011-07-10 23:47:41 --> Config Class Initialized
DEBUG - 2011-07-10 23:47:41 --> Hooks Class Initialized
DEBUG - 2011-07-10 23:47:41 --> Utf8 Class Initialized
DEBUG - 2011-07-10 23:47:41 --> UTF-8 Support Enabled
DEBUG - 2011-07-10 23:47:41 --> URI Class Initialized
DEBUG - 2011-07-10 23:47:41 --> Router Class Initialized
DEBUG - 2011-07-10 23:47:41 --> Output Class Initialized
DEBUG - 2011-07-10 23:47:41 --> Input Class Initialized
DEBUG - 2011-07-10 23:47:41 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-10 23:47:41 --> Language Class Initialized
DEBUG - 2011-07-10 23:47:41 --> Loader Class Initialized
DEBUG - 2011-07-10 23:47:41 --> Controller Class Initialized
ERROR - 2011-07-10 23:47:41 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-10 23:47:41 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-10 23:47:41 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-10 23:47:41 --> Model Class Initialized
DEBUG - 2011-07-10 23:47:41 --> Model Class Initialized
DEBUG - 2011-07-10 23:47:41 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-10 23:47:41 --> Database Driver Class Initialized
DEBUG - 2011-07-10 23:47:41 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-10 23:47:41 --> Helper loaded: url_helper
DEBUG - 2011-07-10 23:47:41 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-10 23:47:41 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-10 23:47:41 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-10 23:47:41 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-10 23:47:41 --> Final output sent to browser
DEBUG - 2011-07-10 23:47:41 --> Total execution time: 0.3520

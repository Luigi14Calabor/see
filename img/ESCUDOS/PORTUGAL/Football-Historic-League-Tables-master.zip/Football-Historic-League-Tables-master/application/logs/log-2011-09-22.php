<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2011-09-22 00:48:46 --> Config Class Initialized
DEBUG - 2011-09-22 00:48:46 --> Hooks Class Initialized
DEBUG - 2011-09-22 00:48:46 --> Utf8 Class Initialized
DEBUG - 2011-09-22 00:48:46 --> UTF-8 Support Enabled
DEBUG - 2011-09-22 00:48:46 --> URI Class Initialized
DEBUG - 2011-09-22 00:48:46 --> Router Class Initialized
DEBUG - 2011-09-22 00:48:46 --> Output Class Initialized
DEBUG - 2011-09-22 00:48:46 --> Input Class Initialized
DEBUG - 2011-09-22 00:48:46 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-22 00:48:46 --> Language Class Initialized
DEBUG - 2011-09-22 00:48:46 --> Loader Class Initialized
DEBUG - 2011-09-22 00:48:46 --> Controller Class Initialized
DEBUG - 2011-09-22 00:48:46 --> Model Class Initialized
DEBUG - 2011-09-22 00:48:46 --> Model Class Initialized
DEBUG - 2011-09-22 00:48:46 --> Model Class Initialized
DEBUG - 2011-09-22 00:48:46 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-22 00:48:46 --> Database Driver Class Initialized
DEBUG - 2011-09-22 00:48:47 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-22 00:48:47 --> Helper loaded: url_helper
DEBUG - 2011-09-22 00:48:47 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-22 00:48:47 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-22 00:48:47 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-22 00:48:47 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-22 00:48:47 --> Final output sent to browser
DEBUG - 2011-09-22 00:48:47 --> Total execution time: 1.4483
DEBUG - 2011-09-22 00:49:16 --> Config Class Initialized
DEBUG - 2011-09-22 00:49:16 --> Hooks Class Initialized
DEBUG - 2011-09-22 00:49:16 --> Utf8 Class Initialized
DEBUG - 2011-09-22 00:49:16 --> UTF-8 Support Enabled
DEBUG - 2011-09-22 00:49:16 --> URI Class Initialized
DEBUG - 2011-09-22 00:49:16 --> Router Class Initialized
ERROR - 2011-09-22 00:49:16 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-22 00:50:02 --> Config Class Initialized
DEBUG - 2011-09-22 00:50:02 --> Hooks Class Initialized
DEBUG - 2011-09-22 00:50:02 --> Utf8 Class Initialized
DEBUG - 2011-09-22 00:50:02 --> UTF-8 Support Enabled
DEBUG - 2011-09-22 00:50:02 --> URI Class Initialized
DEBUG - 2011-09-22 00:50:02 --> Router Class Initialized
DEBUG - 2011-09-22 00:50:02 --> Output Class Initialized
DEBUG - 2011-09-22 00:50:02 --> Input Class Initialized
DEBUG - 2011-09-22 00:50:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-22 00:50:02 --> Language Class Initialized
DEBUG - 2011-09-22 00:50:02 --> Loader Class Initialized
DEBUG - 2011-09-22 00:50:02 --> Controller Class Initialized
DEBUG - 2011-09-22 00:50:02 --> Model Class Initialized
DEBUG - 2011-09-22 00:50:02 --> Model Class Initialized
DEBUG - 2011-09-22 00:50:02 --> Model Class Initialized
DEBUG - 2011-09-22 00:50:02 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-22 00:50:02 --> Database Driver Class Initialized
DEBUG - 2011-09-22 00:50:03 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-22 00:50:03 --> Helper loaded: url_helper
DEBUG - 2011-09-22 00:50:03 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-22 00:50:03 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-22 00:50:03 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-22 00:50:03 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-22 00:50:03 --> Final output sent to browser
DEBUG - 2011-09-22 00:50:03 --> Total execution time: 0.8127
DEBUG - 2011-09-22 00:50:06 --> Config Class Initialized
DEBUG - 2011-09-22 00:50:06 --> Hooks Class Initialized
DEBUG - 2011-09-22 00:50:06 --> Utf8 Class Initialized
DEBUG - 2011-09-22 00:50:06 --> UTF-8 Support Enabled
DEBUG - 2011-09-22 00:50:06 --> URI Class Initialized
DEBUG - 2011-09-22 00:50:06 --> Router Class Initialized
DEBUG - 2011-09-22 00:50:06 --> Output Class Initialized
DEBUG - 2011-09-22 00:50:06 --> Input Class Initialized
DEBUG - 2011-09-22 00:50:06 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-22 00:50:06 --> Language Class Initialized
DEBUG - 2011-09-22 00:50:06 --> Loader Class Initialized
DEBUG - 2011-09-22 00:50:06 --> Controller Class Initialized
DEBUG - 2011-09-22 00:50:06 --> Model Class Initialized
DEBUG - 2011-09-22 00:50:06 --> Model Class Initialized
DEBUG - 2011-09-22 00:50:06 --> Model Class Initialized
DEBUG - 2011-09-22 00:50:06 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-22 00:50:06 --> Database Driver Class Initialized
DEBUG - 2011-09-22 00:50:06 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-22 00:50:06 --> Helper loaded: url_helper
DEBUG - 2011-09-22 00:50:06 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-22 00:50:06 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-22 00:50:06 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-22 00:50:06 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-22 00:50:06 --> Final output sent to browser
DEBUG - 2011-09-22 00:50:06 --> Total execution time: 0.2268
DEBUG - 2011-09-22 00:50:10 --> Config Class Initialized
DEBUG - 2011-09-22 00:50:10 --> Hooks Class Initialized
DEBUG - 2011-09-22 00:50:10 --> Utf8 Class Initialized
DEBUG - 2011-09-22 00:50:10 --> UTF-8 Support Enabled
DEBUG - 2011-09-22 00:50:10 --> URI Class Initialized
DEBUG - 2011-09-22 00:50:10 --> Router Class Initialized
ERROR - 2011-09-22 00:50:10 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-22 00:50:36 --> Config Class Initialized
DEBUG - 2011-09-22 00:50:36 --> Hooks Class Initialized
DEBUG - 2011-09-22 00:50:36 --> Utf8 Class Initialized
DEBUG - 2011-09-22 00:50:36 --> UTF-8 Support Enabled
DEBUG - 2011-09-22 00:50:36 --> URI Class Initialized
DEBUG - 2011-09-22 00:50:36 --> Router Class Initialized
DEBUG - 2011-09-22 00:50:36 --> Output Class Initialized
DEBUG - 2011-09-22 00:50:36 --> Input Class Initialized
DEBUG - 2011-09-22 00:50:36 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-22 00:50:36 --> Language Class Initialized
DEBUG - 2011-09-22 00:50:36 --> Loader Class Initialized
DEBUG - 2011-09-22 00:50:36 --> Controller Class Initialized
DEBUG - 2011-09-22 00:50:36 --> Model Class Initialized
DEBUG - 2011-09-22 00:50:36 --> Model Class Initialized
DEBUG - 2011-09-22 00:50:36 --> Model Class Initialized
DEBUG - 2011-09-22 00:50:36 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-22 00:50:36 --> Database Driver Class Initialized
DEBUG - 2011-09-22 00:50:36 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-22 00:50:36 --> Helper loaded: url_helper
DEBUG - 2011-09-22 00:50:36 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-22 00:50:36 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-22 00:50:36 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-22 00:50:36 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-22 00:50:36 --> Final output sent to browser
DEBUG - 2011-09-22 00:50:36 --> Total execution time: 0.3994
DEBUG - 2011-09-22 00:50:38 --> Config Class Initialized
DEBUG - 2011-09-22 00:50:38 --> Hooks Class Initialized
DEBUG - 2011-09-22 00:50:38 --> Utf8 Class Initialized
DEBUG - 2011-09-22 00:50:38 --> UTF-8 Support Enabled
DEBUG - 2011-09-22 00:50:38 --> URI Class Initialized
DEBUG - 2011-09-22 00:50:38 --> Router Class Initialized
DEBUG - 2011-09-22 00:50:38 --> Output Class Initialized
DEBUG - 2011-09-22 00:50:38 --> Input Class Initialized
DEBUG - 2011-09-22 00:50:38 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-22 00:50:38 --> Language Class Initialized
DEBUG - 2011-09-22 00:50:38 --> Loader Class Initialized
DEBUG - 2011-09-22 00:50:38 --> Controller Class Initialized
DEBUG - 2011-09-22 00:50:38 --> Model Class Initialized
DEBUG - 2011-09-22 00:50:38 --> Model Class Initialized
DEBUG - 2011-09-22 00:50:38 --> Model Class Initialized
DEBUG - 2011-09-22 00:50:38 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-22 00:50:38 --> Database Driver Class Initialized
DEBUG - 2011-09-22 00:50:38 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-22 00:50:38 --> Helper loaded: url_helper
DEBUG - 2011-09-22 00:50:38 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-22 00:50:38 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-22 00:50:38 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-22 00:50:38 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-22 00:50:38 --> Final output sent to browser
DEBUG - 2011-09-22 00:50:38 --> Total execution time: 0.0566
DEBUG - 2011-09-22 00:50:45 --> Config Class Initialized
DEBUG - 2011-09-22 00:50:45 --> Hooks Class Initialized
DEBUG - 2011-09-22 00:50:45 --> Utf8 Class Initialized
DEBUG - 2011-09-22 00:50:45 --> UTF-8 Support Enabled
DEBUG - 2011-09-22 00:50:45 --> URI Class Initialized
DEBUG - 2011-09-22 00:50:45 --> Router Class Initialized
ERROR - 2011-09-22 00:50:45 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-22 01:44:38 --> Config Class Initialized
DEBUG - 2011-09-22 01:44:38 --> Hooks Class Initialized
DEBUG - 2011-09-22 01:44:38 --> Utf8 Class Initialized
DEBUG - 2011-09-22 01:44:38 --> UTF-8 Support Enabled
DEBUG - 2011-09-22 01:44:38 --> URI Class Initialized
DEBUG - 2011-09-22 01:44:38 --> Router Class Initialized
DEBUG - 2011-09-22 01:44:38 --> Output Class Initialized
DEBUG - 2011-09-22 01:44:38 --> Input Class Initialized
DEBUG - 2011-09-22 01:44:38 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-22 01:44:38 --> Language Class Initialized
DEBUG - 2011-09-22 01:44:38 --> Loader Class Initialized
DEBUG - 2011-09-22 01:44:38 --> Controller Class Initialized
DEBUG - 2011-09-22 01:44:38 --> Model Class Initialized
DEBUG - 2011-09-22 01:44:38 --> Model Class Initialized
DEBUG - 2011-09-22 01:44:38 --> Model Class Initialized
DEBUG - 2011-09-22 01:44:38 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-22 01:44:38 --> Database Driver Class Initialized
DEBUG - 2011-09-22 01:44:41 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-22 01:44:41 --> Helper loaded: url_helper
DEBUG - 2011-09-22 01:44:41 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-22 01:44:41 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-22 01:44:41 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-22 01:44:41 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-22 01:44:41 --> Final output sent to browser
DEBUG - 2011-09-22 01:44:41 --> Total execution time: 3.7333
DEBUG - 2011-09-22 01:44:43 --> Config Class Initialized
DEBUG - 2011-09-22 01:44:43 --> Hooks Class Initialized
DEBUG - 2011-09-22 01:44:43 --> Utf8 Class Initialized
DEBUG - 2011-09-22 01:44:43 --> UTF-8 Support Enabled
DEBUG - 2011-09-22 01:44:43 --> URI Class Initialized
DEBUG - 2011-09-22 01:44:43 --> Router Class Initialized
DEBUG - 2011-09-22 01:44:43 --> Output Class Initialized
DEBUG - 2011-09-22 01:44:43 --> Input Class Initialized
DEBUG - 2011-09-22 01:44:43 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-22 01:44:43 --> Language Class Initialized
DEBUG - 2011-09-22 01:44:43 --> Loader Class Initialized
DEBUG - 2011-09-22 01:44:43 --> Controller Class Initialized
ERROR - 2011-09-22 01:44:43 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-22 01:44:43 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-22 01:44:43 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-22 01:44:43 --> Model Class Initialized
DEBUG - 2011-09-22 01:44:43 --> Model Class Initialized
DEBUG - 2011-09-22 01:44:43 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-22 01:44:43 --> Database Driver Class Initialized
DEBUG - 2011-09-22 01:44:43 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-22 01:44:43 --> Helper loaded: url_helper
DEBUG - 2011-09-22 01:44:43 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-22 01:44:43 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-22 01:44:43 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-22 01:44:43 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-22 01:44:43 --> Final output sent to browser
DEBUG - 2011-09-22 01:44:43 --> Total execution time: 0.2110
DEBUG - 2011-09-22 01:46:55 --> Config Class Initialized
DEBUG - 2011-09-22 01:46:55 --> Hooks Class Initialized
DEBUG - 2011-09-22 01:46:55 --> Utf8 Class Initialized
DEBUG - 2011-09-22 01:46:55 --> UTF-8 Support Enabled
DEBUG - 2011-09-22 01:46:55 --> URI Class Initialized
DEBUG - 2011-09-22 01:46:55 --> Router Class Initialized
ERROR - 2011-09-22 01:46:55 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-09-22 02:20:13 --> Config Class Initialized
DEBUG - 2011-09-22 02:20:13 --> Hooks Class Initialized
DEBUG - 2011-09-22 02:20:13 --> Utf8 Class Initialized
DEBUG - 2011-09-22 02:20:13 --> UTF-8 Support Enabled
DEBUG - 2011-09-22 02:20:13 --> URI Class Initialized
DEBUG - 2011-09-22 02:20:13 --> Router Class Initialized
DEBUG - 2011-09-22 02:20:13 --> Output Class Initialized
DEBUG - 2011-09-22 02:20:13 --> Input Class Initialized
DEBUG - 2011-09-22 02:20:13 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-22 02:20:13 --> Language Class Initialized
DEBUG - 2011-09-22 02:20:13 --> Loader Class Initialized
DEBUG - 2011-09-22 02:20:13 --> Controller Class Initialized
ERROR - 2011-09-22 02:20:13 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-22 02:20:13 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-22 02:20:13 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-22 02:20:14 --> Model Class Initialized
DEBUG - 2011-09-22 02:20:14 --> Model Class Initialized
DEBUG - 2011-09-22 02:20:14 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-22 02:20:14 --> Database Driver Class Initialized
DEBUG - 2011-09-22 02:20:15 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-22 02:20:15 --> Helper loaded: url_helper
DEBUG - 2011-09-22 02:20:15 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-22 02:20:15 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-22 02:20:15 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-22 02:20:15 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-22 02:20:15 --> Final output sent to browser
DEBUG - 2011-09-22 02:20:15 --> Total execution time: 1.2999
DEBUG - 2011-09-22 02:20:16 --> Config Class Initialized
DEBUG - 2011-09-22 02:20:16 --> Hooks Class Initialized
DEBUG - 2011-09-22 02:20:16 --> Utf8 Class Initialized
DEBUG - 2011-09-22 02:20:16 --> UTF-8 Support Enabled
DEBUG - 2011-09-22 02:20:16 --> URI Class Initialized
DEBUG - 2011-09-22 02:20:16 --> Router Class Initialized
DEBUG - 2011-09-22 02:20:16 --> Output Class Initialized
DEBUG - 2011-09-22 02:20:16 --> Input Class Initialized
DEBUG - 2011-09-22 02:20:16 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-22 02:20:16 --> Language Class Initialized
DEBUG - 2011-09-22 02:20:16 --> Loader Class Initialized
DEBUG - 2011-09-22 02:20:16 --> Controller Class Initialized
DEBUG - 2011-09-22 02:20:16 --> Model Class Initialized
DEBUG - 2011-09-22 02:20:16 --> Model Class Initialized
DEBUG - 2011-09-22 02:20:16 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-22 02:20:16 --> Database Driver Class Initialized
DEBUG - 2011-09-22 02:20:17 --> Final output sent to browser
DEBUG - 2011-09-22 02:20:17 --> Total execution time: 1.2224
DEBUG - 2011-09-22 02:20:19 --> Config Class Initialized
DEBUG - 2011-09-22 02:20:19 --> Hooks Class Initialized
DEBUG - 2011-09-22 02:20:19 --> Utf8 Class Initialized
DEBUG - 2011-09-22 02:20:19 --> UTF-8 Support Enabled
DEBUG - 2011-09-22 02:20:19 --> URI Class Initialized
DEBUG - 2011-09-22 02:20:19 --> Router Class Initialized
ERROR - 2011-09-22 02:20:19 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-22 02:20:44 --> Config Class Initialized
DEBUG - 2011-09-22 02:20:44 --> Hooks Class Initialized
DEBUG - 2011-09-22 02:20:44 --> Utf8 Class Initialized
DEBUG - 2011-09-22 02:20:44 --> UTF-8 Support Enabled
DEBUG - 2011-09-22 02:20:44 --> URI Class Initialized
DEBUG - 2011-09-22 02:20:44 --> Router Class Initialized
ERROR - 2011-09-22 02:20:44 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-09-22 02:20:45 --> Config Class Initialized
DEBUG - 2011-09-22 02:20:45 --> Hooks Class Initialized
DEBUG - 2011-09-22 02:20:45 --> Utf8 Class Initialized
DEBUG - 2011-09-22 02:20:45 --> UTF-8 Support Enabled
DEBUG - 2011-09-22 02:20:45 --> URI Class Initialized
DEBUG - 2011-09-22 02:20:45 --> Router Class Initialized
DEBUG - 2011-09-22 02:20:45 --> Output Class Initialized
DEBUG - 2011-09-22 02:20:45 --> Input Class Initialized
DEBUG - 2011-09-22 02:20:45 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-22 02:20:45 --> Language Class Initialized
DEBUG - 2011-09-22 02:20:45 --> Loader Class Initialized
DEBUG - 2011-09-22 02:20:45 --> Controller Class Initialized
ERROR - 2011-09-22 02:20:45 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-22 02:20:45 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-22 02:20:45 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-22 02:20:45 --> Model Class Initialized
DEBUG - 2011-09-22 02:20:45 --> Model Class Initialized
DEBUG - 2011-09-22 02:20:45 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-22 02:20:45 --> Database Driver Class Initialized
DEBUG - 2011-09-22 02:20:45 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-22 02:20:45 --> Helper loaded: url_helper
DEBUG - 2011-09-22 02:20:45 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-22 02:20:45 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-22 02:20:45 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-22 02:20:45 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-22 02:20:45 --> Final output sent to browser
DEBUG - 2011-09-22 02:20:45 --> Total execution time: 0.1716
DEBUG - 2011-09-22 02:20:46 --> Config Class Initialized
DEBUG - 2011-09-22 02:20:46 --> Hooks Class Initialized
DEBUG - 2011-09-22 02:20:46 --> Utf8 Class Initialized
DEBUG - 2011-09-22 02:20:46 --> UTF-8 Support Enabled
DEBUG - 2011-09-22 02:20:46 --> URI Class Initialized
DEBUG - 2011-09-22 02:20:46 --> Router Class Initialized
ERROR - 2011-09-22 02:20:46 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-09-22 02:20:47 --> Config Class Initialized
DEBUG - 2011-09-22 02:20:47 --> Hooks Class Initialized
DEBUG - 2011-09-22 02:20:47 --> Utf8 Class Initialized
DEBUG - 2011-09-22 02:20:47 --> UTF-8 Support Enabled
DEBUG - 2011-09-22 02:20:47 --> URI Class Initialized
DEBUG - 2011-09-22 02:20:47 --> Router Class Initialized
DEBUG - 2011-09-22 02:20:47 --> Output Class Initialized
DEBUG - 2011-09-22 02:20:47 --> Input Class Initialized
DEBUG - 2011-09-22 02:20:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-22 02:20:47 --> Language Class Initialized
DEBUG - 2011-09-22 02:20:47 --> Loader Class Initialized
DEBUG - 2011-09-22 02:20:47 --> Controller Class Initialized
DEBUG - 2011-09-22 02:20:47 --> Model Class Initialized
DEBUG - 2011-09-22 02:20:47 --> Model Class Initialized
DEBUG - 2011-09-22 02:20:47 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-22 02:20:47 --> Database Driver Class Initialized
DEBUG - 2011-09-22 02:20:48 --> Final output sent to browser
DEBUG - 2011-09-22 02:20:48 --> Total execution time: 0.8812
DEBUG - 2011-09-22 02:20:57 --> Config Class Initialized
DEBUG - 2011-09-22 02:20:57 --> Hooks Class Initialized
DEBUG - 2011-09-22 02:20:57 --> Utf8 Class Initialized
DEBUG - 2011-09-22 02:20:57 --> UTF-8 Support Enabled
DEBUG - 2011-09-22 02:20:57 --> URI Class Initialized
DEBUG - 2011-09-22 02:20:57 --> Router Class Initialized
DEBUG - 2011-09-22 02:20:57 --> Output Class Initialized
DEBUG - 2011-09-22 02:20:57 --> Input Class Initialized
DEBUG - 2011-09-22 02:20:57 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-22 02:20:57 --> Language Class Initialized
DEBUG - 2011-09-22 02:20:57 --> Loader Class Initialized
DEBUG - 2011-09-22 02:20:57 --> Controller Class Initialized
ERROR - 2011-09-22 02:20:57 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-22 02:20:57 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-22 02:20:57 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-22 02:20:57 --> Model Class Initialized
DEBUG - 2011-09-22 02:20:57 --> Model Class Initialized
DEBUG - 2011-09-22 02:20:57 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-22 02:20:57 --> Database Driver Class Initialized
DEBUG - 2011-09-22 02:20:57 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-22 02:20:58 --> Helper loaded: url_helper
DEBUG - 2011-09-22 02:20:58 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-22 02:20:58 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-22 02:20:58 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-22 02:20:58 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-22 02:20:58 --> Final output sent to browser
DEBUG - 2011-09-22 02:20:58 --> Total execution time: 0.0813
DEBUG - 2011-09-22 02:20:59 --> Config Class Initialized
DEBUG - 2011-09-22 02:20:59 --> Hooks Class Initialized
DEBUG - 2011-09-22 02:20:59 --> Utf8 Class Initialized
DEBUG - 2011-09-22 02:20:59 --> UTF-8 Support Enabled
DEBUG - 2011-09-22 02:20:59 --> URI Class Initialized
DEBUG - 2011-09-22 02:20:59 --> Router Class Initialized
DEBUG - 2011-09-22 02:20:59 --> Output Class Initialized
DEBUG - 2011-09-22 02:20:59 --> Input Class Initialized
DEBUG - 2011-09-22 02:20:59 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-22 02:20:59 --> Language Class Initialized
DEBUG - 2011-09-22 02:20:59 --> Loader Class Initialized
DEBUG - 2011-09-22 02:20:59 --> Controller Class Initialized
DEBUG - 2011-09-22 02:20:59 --> Model Class Initialized
DEBUG - 2011-09-22 02:20:59 --> Model Class Initialized
DEBUG - 2011-09-22 02:20:59 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-22 02:20:59 --> Database Driver Class Initialized
DEBUG - 2011-09-22 02:20:59 --> Final output sent to browser
DEBUG - 2011-09-22 02:20:59 --> Total execution time: 0.5975
DEBUG - 2011-09-22 02:21:02 --> Config Class Initialized
DEBUG - 2011-09-22 02:21:02 --> Hooks Class Initialized
DEBUG - 2011-09-22 02:21:02 --> Utf8 Class Initialized
DEBUG - 2011-09-22 02:21:02 --> UTF-8 Support Enabled
DEBUG - 2011-09-22 02:21:02 --> URI Class Initialized
DEBUG - 2011-09-22 02:21:02 --> Router Class Initialized
DEBUG - 2011-09-22 02:21:02 --> Output Class Initialized
DEBUG - 2011-09-22 02:21:02 --> Input Class Initialized
DEBUG - 2011-09-22 02:21:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-22 02:21:02 --> Language Class Initialized
DEBUG - 2011-09-22 02:21:02 --> Loader Class Initialized
DEBUG - 2011-09-22 02:21:02 --> Controller Class Initialized
ERROR - 2011-09-22 02:21:02 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-22 02:21:02 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-22 02:21:02 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-22 02:21:02 --> Model Class Initialized
DEBUG - 2011-09-22 02:21:02 --> Model Class Initialized
DEBUG - 2011-09-22 02:21:02 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-22 02:21:02 --> Database Driver Class Initialized
DEBUG - 2011-09-22 02:21:02 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-22 02:21:02 --> Helper loaded: url_helper
DEBUG - 2011-09-22 02:21:02 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-22 02:21:02 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-22 02:21:02 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-22 02:21:02 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-22 02:21:02 --> Final output sent to browser
DEBUG - 2011-09-22 02:21:02 --> Total execution time: 0.2887
DEBUG - 2011-09-22 02:45:58 --> Config Class Initialized
DEBUG - 2011-09-22 02:45:58 --> Hooks Class Initialized
DEBUG - 2011-09-22 02:45:58 --> Utf8 Class Initialized
DEBUG - 2011-09-22 02:45:58 --> UTF-8 Support Enabled
DEBUG - 2011-09-22 02:45:58 --> URI Class Initialized
DEBUG - 2011-09-22 02:45:58 --> Router Class Initialized
ERROR - 2011-09-22 02:45:58 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-09-22 02:45:58 --> Config Class Initialized
DEBUG - 2011-09-22 02:45:58 --> Hooks Class Initialized
DEBUG - 2011-09-22 02:45:58 --> Utf8 Class Initialized
DEBUG - 2011-09-22 02:45:58 --> UTF-8 Support Enabled
DEBUG - 2011-09-22 02:45:58 --> URI Class Initialized
DEBUG - 2011-09-22 02:45:58 --> Router Class Initialized
DEBUG - 2011-09-22 02:45:58 --> Output Class Initialized
DEBUG - 2011-09-22 02:45:58 --> Input Class Initialized
DEBUG - 2011-09-22 02:45:58 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-22 02:45:58 --> Language Class Initialized
DEBUG - 2011-09-22 02:45:58 --> Loader Class Initialized
DEBUG - 2011-09-22 02:45:58 --> Controller Class Initialized
DEBUG - 2011-09-22 02:45:58 --> Model Class Initialized
DEBUG - 2011-09-22 02:45:58 --> Model Class Initialized
DEBUG - 2011-09-22 02:45:58 --> Model Class Initialized
DEBUG - 2011-09-22 02:45:58 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-22 02:45:58 --> Database Driver Class Initialized
DEBUG - 2011-09-22 02:46:00 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-22 02:46:00 --> Helper loaded: url_helper
DEBUG - 2011-09-22 02:46:00 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-22 02:46:00 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-22 02:46:00 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-22 02:46:00 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-22 02:46:00 --> Final output sent to browser
DEBUG - 2011-09-22 02:46:00 --> Total execution time: 1.9559
DEBUG - 2011-09-22 03:24:45 --> Config Class Initialized
DEBUG - 2011-09-22 03:24:45 --> Hooks Class Initialized
DEBUG - 2011-09-22 03:24:45 --> Utf8 Class Initialized
DEBUG - 2011-09-22 03:24:45 --> UTF-8 Support Enabled
DEBUG - 2011-09-22 03:24:45 --> URI Class Initialized
DEBUG - 2011-09-22 03:24:45 --> Router Class Initialized
DEBUG - 2011-09-22 03:24:45 --> Output Class Initialized
DEBUG - 2011-09-22 03:24:45 --> Input Class Initialized
DEBUG - 2011-09-22 03:24:45 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-22 03:24:45 --> Language Class Initialized
DEBUG - 2011-09-22 03:24:45 --> Loader Class Initialized
DEBUG - 2011-09-22 03:24:45 --> Controller Class Initialized
DEBUG - 2011-09-22 03:24:45 --> Model Class Initialized
DEBUG - 2011-09-22 03:24:45 --> Model Class Initialized
DEBUG - 2011-09-22 03:24:45 --> Model Class Initialized
DEBUG - 2011-09-22 03:24:45 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-22 03:24:45 --> Database Driver Class Initialized
DEBUG - 2011-09-22 03:24:48 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-22 03:24:48 --> Helper loaded: url_helper
DEBUG - 2011-09-22 03:24:48 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-22 03:24:48 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-22 03:24:48 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-22 03:24:48 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-22 03:24:48 --> Final output sent to browser
DEBUG - 2011-09-22 03:24:48 --> Total execution time: 3.1643
DEBUG - 2011-09-22 03:24:51 --> Config Class Initialized
DEBUG - 2011-09-22 03:24:51 --> Hooks Class Initialized
DEBUG - 2011-09-22 03:24:51 --> Utf8 Class Initialized
DEBUG - 2011-09-22 03:24:51 --> UTF-8 Support Enabled
DEBUG - 2011-09-22 03:24:51 --> URI Class Initialized
DEBUG - 2011-09-22 03:24:51 --> Router Class Initialized
ERROR - 2011-09-22 03:24:51 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-22 03:24:52 --> Config Class Initialized
DEBUG - 2011-09-22 03:24:52 --> Hooks Class Initialized
DEBUG - 2011-09-22 03:24:52 --> Utf8 Class Initialized
DEBUG - 2011-09-22 03:24:52 --> UTF-8 Support Enabled
DEBUG - 2011-09-22 03:24:52 --> URI Class Initialized
DEBUG - 2011-09-22 03:24:52 --> Router Class Initialized
ERROR - 2011-09-22 03:24:52 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-22 03:25:02 --> Config Class Initialized
DEBUG - 2011-09-22 03:25:02 --> Hooks Class Initialized
DEBUG - 2011-09-22 03:25:02 --> Utf8 Class Initialized
DEBUG - 2011-09-22 03:25:02 --> UTF-8 Support Enabled
DEBUG - 2011-09-22 03:25:02 --> URI Class Initialized
DEBUG - 2011-09-22 03:25:02 --> Router Class Initialized
DEBUG - 2011-09-22 03:25:02 --> Output Class Initialized
DEBUG - 2011-09-22 03:25:02 --> Input Class Initialized
DEBUG - 2011-09-22 03:25:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-22 03:25:02 --> Language Class Initialized
DEBUG - 2011-09-22 03:25:02 --> Loader Class Initialized
DEBUG - 2011-09-22 03:25:02 --> Controller Class Initialized
DEBUG - 2011-09-22 03:25:02 --> Model Class Initialized
DEBUG - 2011-09-22 03:25:02 --> Model Class Initialized
DEBUG - 2011-09-22 03:25:02 --> Model Class Initialized
DEBUG - 2011-09-22 03:25:02 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-22 03:25:02 --> Database Driver Class Initialized
DEBUG - 2011-09-22 03:25:02 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-22 03:25:02 --> Helper loaded: url_helper
DEBUG - 2011-09-22 03:25:02 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-22 03:25:02 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-22 03:25:02 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-22 03:25:02 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-22 03:25:02 --> Final output sent to browser
DEBUG - 2011-09-22 03:25:02 --> Total execution time: 0.5018
DEBUG - 2011-09-22 03:28:58 --> Config Class Initialized
DEBUG - 2011-09-22 03:28:58 --> Hooks Class Initialized
DEBUG - 2011-09-22 03:28:58 --> Utf8 Class Initialized
DEBUG - 2011-09-22 03:28:58 --> UTF-8 Support Enabled
DEBUG - 2011-09-22 03:28:58 --> URI Class Initialized
DEBUG - 2011-09-22 03:28:58 --> Router Class Initialized
DEBUG - 2011-09-22 03:28:58 --> Output Class Initialized
DEBUG - 2011-09-22 03:28:58 --> Input Class Initialized
DEBUG - 2011-09-22 03:28:58 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-22 03:28:58 --> Language Class Initialized
DEBUG - 2011-09-22 03:28:58 --> Loader Class Initialized
DEBUG - 2011-09-22 03:28:58 --> Controller Class Initialized
DEBUG - 2011-09-22 03:28:58 --> Model Class Initialized
DEBUG - 2011-09-22 03:28:58 --> Model Class Initialized
DEBUG - 2011-09-22 03:28:58 --> Model Class Initialized
DEBUG - 2011-09-22 03:28:58 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-22 03:28:58 --> Database Driver Class Initialized
DEBUG - 2011-09-22 03:28:58 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-22 03:28:58 --> Helper loaded: url_helper
DEBUG - 2011-09-22 03:28:58 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-22 03:28:58 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-22 03:28:58 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-22 03:28:58 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-22 03:28:58 --> Final output sent to browser
DEBUG - 2011-09-22 03:28:58 --> Total execution time: 0.0657
DEBUG - 2011-09-22 03:29:14 --> Config Class Initialized
DEBUG - 2011-09-22 03:29:14 --> Hooks Class Initialized
DEBUG - 2011-09-22 03:29:14 --> Utf8 Class Initialized
DEBUG - 2011-09-22 03:29:14 --> UTF-8 Support Enabled
DEBUG - 2011-09-22 03:29:14 --> URI Class Initialized
DEBUG - 2011-09-22 03:29:14 --> Router Class Initialized
DEBUG - 2011-09-22 03:29:14 --> Output Class Initialized
DEBUG - 2011-09-22 03:29:14 --> Input Class Initialized
DEBUG - 2011-09-22 03:29:14 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-22 03:29:14 --> Language Class Initialized
DEBUG - 2011-09-22 03:29:14 --> Loader Class Initialized
DEBUG - 2011-09-22 03:29:14 --> Controller Class Initialized
DEBUG - 2011-09-22 03:29:14 --> Model Class Initialized
DEBUG - 2011-09-22 03:29:14 --> Model Class Initialized
DEBUG - 2011-09-22 03:29:14 --> Model Class Initialized
DEBUG - 2011-09-22 03:29:14 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-22 03:29:14 --> Database Driver Class Initialized
DEBUG - 2011-09-22 03:29:15 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-22 03:29:15 --> Helper loaded: url_helper
DEBUG - 2011-09-22 03:29:15 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-22 03:29:15 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-22 03:29:15 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-22 03:29:15 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-22 03:29:15 --> Final output sent to browser
DEBUG - 2011-09-22 03:29:15 --> Total execution time: 0.9597
DEBUG - 2011-09-22 03:29:17 --> Config Class Initialized
DEBUG - 2011-09-22 03:29:17 --> Hooks Class Initialized
DEBUG - 2011-09-22 03:29:17 --> Utf8 Class Initialized
DEBUG - 2011-09-22 03:29:17 --> UTF-8 Support Enabled
DEBUG - 2011-09-22 03:29:17 --> URI Class Initialized
DEBUG - 2011-09-22 03:29:17 --> Router Class Initialized
DEBUG - 2011-09-22 03:29:17 --> Output Class Initialized
DEBUG - 2011-09-22 03:29:17 --> Input Class Initialized
DEBUG - 2011-09-22 03:29:17 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-22 03:29:17 --> Language Class Initialized
DEBUG - 2011-09-22 03:29:17 --> Loader Class Initialized
DEBUG - 2011-09-22 03:29:17 --> Controller Class Initialized
DEBUG - 2011-09-22 03:29:17 --> Model Class Initialized
DEBUG - 2011-09-22 03:29:17 --> Model Class Initialized
DEBUG - 2011-09-22 03:29:17 --> Model Class Initialized
DEBUG - 2011-09-22 03:29:17 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-22 03:29:17 --> Database Driver Class Initialized
DEBUG - 2011-09-22 03:29:17 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-22 03:29:17 --> Helper loaded: url_helper
DEBUG - 2011-09-22 03:29:17 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-22 03:29:17 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-22 03:29:17 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-22 03:29:17 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-22 03:29:17 --> Final output sent to browser
DEBUG - 2011-09-22 03:29:17 --> Total execution time: 0.6480
DEBUG - 2011-09-22 03:29:19 --> Config Class Initialized
DEBUG - 2011-09-22 03:29:19 --> Hooks Class Initialized
DEBUG - 2011-09-22 03:29:19 --> Utf8 Class Initialized
DEBUG - 2011-09-22 03:29:19 --> UTF-8 Support Enabled
DEBUG - 2011-09-22 03:29:19 --> URI Class Initialized
DEBUG - 2011-09-22 03:29:19 --> Router Class Initialized
DEBUG - 2011-09-22 03:29:19 --> Output Class Initialized
DEBUG - 2011-09-22 03:29:19 --> Input Class Initialized
DEBUG - 2011-09-22 03:29:19 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-22 03:29:19 --> Language Class Initialized
DEBUG - 2011-09-22 03:29:19 --> Loader Class Initialized
DEBUG - 2011-09-22 03:29:19 --> Controller Class Initialized
DEBUG - 2011-09-22 03:29:19 --> Model Class Initialized
DEBUG - 2011-09-22 03:29:19 --> Model Class Initialized
DEBUG - 2011-09-22 03:29:19 --> Model Class Initialized
DEBUG - 2011-09-22 03:29:19 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-22 03:29:19 --> Database Driver Class Initialized
DEBUG - 2011-09-22 03:29:19 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-22 03:29:19 --> Helper loaded: url_helper
DEBUG - 2011-09-22 03:29:19 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-22 03:29:19 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-22 03:29:19 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-22 03:29:19 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-22 03:29:19 --> Final output sent to browser
DEBUG - 2011-09-22 03:29:19 --> Total execution time: 0.0691
DEBUG - 2011-09-22 03:30:48 --> Config Class Initialized
DEBUG - 2011-09-22 03:30:48 --> Hooks Class Initialized
DEBUG - 2011-09-22 03:30:48 --> Utf8 Class Initialized
DEBUG - 2011-09-22 03:30:48 --> UTF-8 Support Enabled
DEBUG - 2011-09-22 03:30:48 --> URI Class Initialized
DEBUG - 2011-09-22 03:30:48 --> Router Class Initialized
DEBUG - 2011-09-22 03:30:48 --> Output Class Initialized
DEBUG - 2011-09-22 03:30:48 --> Input Class Initialized
DEBUG - 2011-09-22 03:30:48 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-22 03:30:48 --> Language Class Initialized
DEBUG - 2011-09-22 03:30:48 --> Loader Class Initialized
DEBUG - 2011-09-22 03:30:48 --> Controller Class Initialized
DEBUG - 2011-09-22 03:30:48 --> Model Class Initialized
DEBUG - 2011-09-22 03:30:48 --> Model Class Initialized
DEBUG - 2011-09-22 03:30:48 --> Model Class Initialized
DEBUG - 2011-09-22 03:30:48 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-22 03:30:48 --> Database Driver Class Initialized
DEBUG - 2011-09-22 03:30:49 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-22 03:30:49 --> Helper loaded: url_helper
DEBUG - 2011-09-22 03:30:49 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-22 03:30:49 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-22 03:30:49 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-22 03:30:49 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-22 03:30:49 --> Final output sent to browser
DEBUG - 2011-09-22 03:30:49 --> Total execution time: 0.0753
DEBUG - 2011-09-22 03:30:52 --> Config Class Initialized
DEBUG - 2011-09-22 03:30:52 --> Hooks Class Initialized
DEBUG - 2011-09-22 03:30:52 --> Utf8 Class Initialized
DEBUG - 2011-09-22 03:30:52 --> UTF-8 Support Enabled
DEBUG - 2011-09-22 03:30:52 --> URI Class Initialized
DEBUG - 2011-09-22 03:30:52 --> Router Class Initialized
DEBUG - 2011-09-22 03:30:52 --> Output Class Initialized
DEBUG - 2011-09-22 03:30:52 --> Input Class Initialized
DEBUG - 2011-09-22 03:30:52 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-22 03:30:52 --> Language Class Initialized
DEBUG - 2011-09-22 03:30:52 --> Loader Class Initialized
DEBUG - 2011-09-22 03:30:52 --> Controller Class Initialized
DEBUG - 2011-09-22 03:30:52 --> Model Class Initialized
DEBUG - 2011-09-22 03:30:52 --> Model Class Initialized
DEBUG - 2011-09-22 03:30:52 --> Model Class Initialized
DEBUG - 2011-09-22 03:30:52 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-22 03:30:52 --> Database Driver Class Initialized
DEBUG - 2011-09-22 03:30:52 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-22 03:30:52 --> Helper loaded: url_helper
DEBUG - 2011-09-22 03:30:52 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-22 03:30:52 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-22 03:30:52 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-22 03:30:52 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-22 03:30:52 --> Final output sent to browser
DEBUG - 2011-09-22 03:30:52 --> Total execution time: 0.0568
DEBUG - 2011-09-22 03:30:55 --> Config Class Initialized
DEBUG - 2011-09-22 03:30:55 --> Hooks Class Initialized
DEBUG - 2011-09-22 03:30:55 --> Utf8 Class Initialized
DEBUG - 2011-09-22 03:30:55 --> UTF-8 Support Enabled
DEBUG - 2011-09-22 03:30:55 --> URI Class Initialized
DEBUG - 2011-09-22 03:30:55 --> Router Class Initialized
DEBUG - 2011-09-22 03:30:55 --> Output Class Initialized
DEBUG - 2011-09-22 03:30:55 --> Input Class Initialized
DEBUG - 2011-09-22 03:30:55 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-22 03:30:55 --> Language Class Initialized
DEBUG - 2011-09-22 03:30:55 --> Loader Class Initialized
DEBUG - 2011-09-22 03:30:55 --> Controller Class Initialized
DEBUG - 2011-09-22 03:30:55 --> Model Class Initialized
DEBUG - 2011-09-22 03:30:55 --> Model Class Initialized
DEBUG - 2011-09-22 03:30:55 --> Model Class Initialized
DEBUG - 2011-09-22 03:30:55 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-22 03:30:55 --> Database Driver Class Initialized
DEBUG - 2011-09-22 03:30:56 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-22 03:30:56 --> Helper loaded: url_helper
DEBUG - 2011-09-22 03:30:56 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-22 03:30:56 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-22 03:30:56 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-22 03:30:56 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-22 03:30:56 --> Final output sent to browser
DEBUG - 2011-09-22 03:30:56 --> Total execution time: 0.5632
DEBUG - 2011-09-22 03:30:59 --> Config Class Initialized
DEBUG - 2011-09-22 03:30:59 --> Hooks Class Initialized
DEBUG - 2011-09-22 03:30:59 --> Utf8 Class Initialized
DEBUG - 2011-09-22 03:30:59 --> UTF-8 Support Enabled
DEBUG - 2011-09-22 03:30:59 --> URI Class Initialized
DEBUG - 2011-09-22 03:30:59 --> Router Class Initialized
DEBUG - 2011-09-22 03:30:59 --> Output Class Initialized
DEBUG - 2011-09-22 03:30:59 --> Input Class Initialized
DEBUG - 2011-09-22 03:30:59 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-22 03:30:59 --> Language Class Initialized
DEBUG - 2011-09-22 03:30:59 --> Loader Class Initialized
DEBUG - 2011-09-22 03:30:59 --> Controller Class Initialized
DEBUG - 2011-09-22 03:30:59 --> Model Class Initialized
DEBUG - 2011-09-22 03:30:59 --> Model Class Initialized
DEBUG - 2011-09-22 03:30:59 --> Model Class Initialized
DEBUG - 2011-09-22 03:30:59 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-22 03:30:59 --> Database Driver Class Initialized
DEBUG - 2011-09-22 03:30:59 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-22 03:30:59 --> Helper loaded: url_helper
DEBUG - 2011-09-22 03:30:59 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-22 03:30:59 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-22 03:30:59 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-22 03:30:59 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-22 03:30:59 --> Final output sent to browser
DEBUG - 2011-09-22 03:30:59 --> Total execution time: 0.0591
DEBUG - 2011-09-22 05:01:11 --> Config Class Initialized
DEBUG - 2011-09-22 05:01:11 --> Hooks Class Initialized
DEBUG - 2011-09-22 05:01:11 --> Utf8 Class Initialized
DEBUG - 2011-09-22 05:01:11 --> UTF-8 Support Enabled
DEBUG - 2011-09-22 05:01:11 --> URI Class Initialized
DEBUG - 2011-09-22 05:01:11 --> Router Class Initialized
DEBUG - 2011-09-22 05:01:11 --> Output Class Initialized
DEBUG - 2011-09-22 05:01:11 --> Input Class Initialized
DEBUG - 2011-09-22 05:01:12 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-22 05:01:12 --> Language Class Initialized
DEBUG - 2011-09-22 05:01:12 --> Loader Class Initialized
DEBUG - 2011-09-22 05:01:12 --> Controller Class Initialized
ERROR - 2011-09-22 05:01:12 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-22 05:01:12 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-22 05:01:12 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-22 05:01:12 --> Model Class Initialized
DEBUG - 2011-09-22 05:01:12 --> Model Class Initialized
DEBUG - 2011-09-22 05:01:12 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-22 05:01:12 --> Database Driver Class Initialized
DEBUG - 2011-09-22 05:01:12 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-22 05:01:12 --> Helper loaded: url_helper
DEBUG - 2011-09-22 05:01:12 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-22 05:01:12 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-22 05:01:12 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-22 05:01:12 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-22 05:01:12 --> Final output sent to browser
DEBUG - 2011-09-22 05:01:12 --> Total execution time: 0.8352
DEBUG - 2011-09-22 05:01:13 --> Config Class Initialized
DEBUG - 2011-09-22 05:01:13 --> Hooks Class Initialized
DEBUG - 2011-09-22 05:01:13 --> Utf8 Class Initialized
DEBUG - 2011-09-22 05:01:13 --> UTF-8 Support Enabled
DEBUG - 2011-09-22 05:01:13 --> URI Class Initialized
DEBUG - 2011-09-22 05:01:13 --> Router Class Initialized
DEBUG - 2011-09-22 05:01:13 --> Output Class Initialized
DEBUG - 2011-09-22 05:01:13 --> Input Class Initialized
DEBUG - 2011-09-22 05:01:13 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-22 05:01:13 --> Language Class Initialized
DEBUG - 2011-09-22 05:01:13 --> Loader Class Initialized
DEBUG - 2011-09-22 05:01:13 --> Controller Class Initialized
DEBUG - 2011-09-22 05:01:13 --> Model Class Initialized
DEBUG - 2011-09-22 05:01:13 --> Model Class Initialized
DEBUG - 2011-09-22 05:01:13 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-22 05:01:13 --> Database Driver Class Initialized
DEBUG - 2011-09-22 05:01:14 --> Final output sent to browser
DEBUG - 2011-09-22 05:01:14 --> Total execution time: 1.0315
DEBUG - 2011-09-22 05:01:14 --> Config Class Initialized
DEBUG - 2011-09-22 05:01:14 --> Hooks Class Initialized
DEBUG - 2011-09-22 05:01:14 --> Utf8 Class Initialized
DEBUG - 2011-09-22 05:01:14 --> UTF-8 Support Enabled
DEBUG - 2011-09-22 05:01:14 --> URI Class Initialized
DEBUG - 2011-09-22 05:01:14 --> Router Class Initialized
ERROR - 2011-09-22 05:01:14 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-22 05:01:14 --> Config Class Initialized
DEBUG - 2011-09-22 05:01:14 --> Hooks Class Initialized
DEBUG - 2011-09-22 05:01:14 --> Utf8 Class Initialized
DEBUG - 2011-09-22 05:01:14 --> UTF-8 Support Enabled
DEBUG - 2011-09-22 05:01:14 --> URI Class Initialized
DEBUG - 2011-09-22 05:01:14 --> Router Class Initialized
ERROR - 2011-09-22 05:01:14 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-22 05:01:18 --> Config Class Initialized
DEBUG - 2011-09-22 05:01:18 --> Hooks Class Initialized
DEBUG - 2011-09-22 05:01:18 --> Utf8 Class Initialized
DEBUG - 2011-09-22 05:01:18 --> UTF-8 Support Enabled
DEBUG - 2011-09-22 05:01:18 --> URI Class Initialized
DEBUG - 2011-09-22 05:01:18 --> Router Class Initialized
DEBUG - 2011-09-22 05:01:18 --> Output Class Initialized
DEBUG - 2011-09-22 05:01:18 --> Input Class Initialized
DEBUG - 2011-09-22 05:01:18 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-22 05:01:18 --> Language Class Initialized
DEBUG - 2011-09-22 05:01:18 --> Loader Class Initialized
DEBUG - 2011-09-22 05:01:18 --> Controller Class Initialized
ERROR - 2011-09-22 05:01:18 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-22 05:01:18 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-22 05:01:18 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-22 05:01:18 --> Model Class Initialized
DEBUG - 2011-09-22 05:01:18 --> Model Class Initialized
DEBUG - 2011-09-22 05:01:18 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-22 05:01:18 --> Database Driver Class Initialized
DEBUG - 2011-09-22 05:01:18 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-22 05:01:18 --> Helper loaded: url_helper
DEBUG - 2011-09-22 05:01:18 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-22 05:01:18 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-22 05:01:18 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-22 05:01:18 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-22 05:01:18 --> Final output sent to browser
DEBUG - 2011-09-22 05:01:18 --> Total execution time: 0.0372
DEBUG - 2011-09-22 05:01:19 --> Config Class Initialized
DEBUG - 2011-09-22 05:01:19 --> Hooks Class Initialized
DEBUG - 2011-09-22 05:01:19 --> Utf8 Class Initialized
DEBUG - 2011-09-22 05:01:19 --> UTF-8 Support Enabled
DEBUG - 2011-09-22 05:01:19 --> URI Class Initialized
DEBUG - 2011-09-22 05:01:19 --> Router Class Initialized
DEBUG - 2011-09-22 05:01:19 --> Output Class Initialized
DEBUG - 2011-09-22 05:01:19 --> Input Class Initialized
DEBUG - 2011-09-22 05:01:19 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-22 05:01:19 --> Language Class Initialized
DEBUG - 2011-09-22 05:01:19 --> Loader Class Initialized
DEBUG - 2011-09-22 05:01:19 --> Controller Class Initialized
DEBUG - 2011-09-22 05:01:19 --> Model Class Initialized
DEBUG - 2011-09-22 05:01:19 --> Model Class Initialized
DEBUG - 2011-09-22 05:01:19 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-22 05:01:19 --> Database Driver Class Initialized
DEBUG - 2011-09-22 05:01:19 --> Final output sent to browser
DEBUG - 2011-09-22 05:01:19 --> Total execution time: 0.8083
DEBUG - 2011-09-22 05:02:20 --> Config Class Initialized
DEBUG - 2011-09-22 05:02:20 --> Hooks Class Initialized
DEBUG - 2011-09-22 05:02:20 --> Utf8 Class Initialized
DEBUG - 2011-09-22 05:02:20 --> UTF-8 Support Enabled
DEBUG - 2011-09-22 05:02:20 --> URI Class Initialized
DEBUG - 2011-09-22 05:02:20 --> Router Class Initialized
DEBUG - 2011-09-22 05:02:20 --> Output Class Initialized
DEBUG - 2011-09-22 05:02:20 --> Input Class Initialized
DEBUG - 2011-09-22 05:02:20 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-22 05:02:20 --> Language Class Initialized
DEBUG - 2011-09-22 05:02:20 --> Loader Class Initialized
DEBUG - 2011-09-22 05:02:20 --> Controller Class Initialized
ERROR - 2011-09-22 05:02:20 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-22 05:02:20 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-22 05:02:20 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-22 05:02:20 --> Model Class Initialized
DEBUG - 2011-09-22 05:02:20 --> Model Class Initialized
DEBUG - 2011-09-22 05:02:20 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-22 05:02:21 --> Database Driver Class Initialized
DEBUG - 2011-09-22 05:02:21 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-22 05:02:21 --> Helper loaded: url_helper
DEBUG - 2011-09-22 05:02:21 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-22 05:02:21 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-22 05:02:21 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-22 05:02:21 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-22 05:02:21 --> Final output sent to browser
DEBUG - 2011-09-22 05:02:21 --> Total execution time: 0.1400
DEBUG - 2011-09-22 05:02:21 --> Config Class Initialized
DEBUG - 2011-09-22 05:02:21 --> Hooks Class Initialized
DEBUG - 2011-09-22 05:02:21 --> Utf8 Class Initialized
DEBUG - 2011-09-22 05:02:21 --> UTF-8 Support Enabled
DEBUG - 2011-09-22 05:02:21 --> URI Class Initialized
DEBUG - 2011-09-22 05:02:21 --> Router Class Initialized
DEBUG - 2011-09-22 05:02:21 --> Output Class Initialized
DEBUG - 2011-09-22 05:02:21 --> Input Class Initialized
DEBUG - 2011-09-22 05:02:21 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-22 05:02:21 --> Language Class Initialized
DEBUG - 2011-09-22 05:02:21 --> Loader Class Initialized
DEBUG - 2011-09-22 05:02:21 --> Controller Class Initialized
DEBUG - 2011-09-22 05:02:21 --> Model Class Initialized
DEBUG - 2011-09-22 05:02:21 --> Model Class Initialized
DEBUG - 2011-09-22 05:02:21 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-22 05:02:21 --> Database Driver Class Initialized
DEBUG - 2011-09-22 05:02:22 --> Final output sent to browser
DEBUG - 2011-09-22 05:02:22 --> Total execution time: 0.7364
DEBUG - 2011-09-22 05:02:53 --> Config Class Initialized
DEBUG - 2011-09-22 05:02:53 --> Hooks Class Initialized
DEBUG - 2011-09-22 05:02:53 --> Utf8 Class Initialized
DEBUG - 2011-09-22 05:02:53 --> UTF-8 Support Enabled
DEBUG - 2011-09-22 05:02:53 --> URI Class Initialized
DEBUG - 2011-09-22 05:02:53 --> Router Class Initialized
DEBUG - 2011-09-22 05:02:53 --> Output Class Initialized
DEBUG - 2011-09-22 05:02:53 --> Input Class Initialized
DEBUG - 2011-09-22 05:02:53 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-22 05:02:53 --> Language Class Initialized
DEBUG - 2011-09-22 05:02:53 --> Loader Class Initialized
DEBUG - 2011-09-22 05:02:53 --> Controller Class Initialized
ERROR - 2011-09-22 05:02:53 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-22 05:02:53 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-22 05:02:53 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-22 05:02:53 --> Model Class Initialized
DEBUG - 2011-09-22 05:02:53 --> Model Class Initialized
DEBUG - 2011-09-22 05:02:53 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-22 05:02:53 --> Database Driver Class Initialized
DEBUG - 2011-09-22 05:02:53 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-22 05:02:53 --> Helper loaded: url_helper
DEBUG - 2011-09-22 05:02:53 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-22 05:02:53 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-22 05:02:53 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-22 05:02:53 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-22 05:02:53 --> Final output sent to browser
DEBUG - 2011-09-22 05:02:53 --> Total execution time: 0.0327
DEBUG - 2011-09-22 05:02:53 --> Config Class Initialized
DEBUG - 2011-09-22 05:02:53 --> Hooks Class Initialized
DEBUG - 2011-09-22 05:02:53 --> Utf8 Class Initialized
DEBUG - 2011-09-22 05:02:53 --> UTF-8 Support Enabled
DEBUG - 2011-09-22 05:02:53 --> URI Class Initialized
DEBUG - 2011-09-22 05:02:53 --> Router Class Initialized
DEBUG - 2011-09-22 05:02:53 --> Output Class Initialized
DEBUG - 2011-09-22 05:02:53 --> Input Class Initialized
DEBUG - 2011-09-22 05:02:53 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-22 05:02:53 --> Language Class Initialized
DEBUG - 2011-09-22 05:02:53 --> Loader Class Initialized
DEBUG - 2011-09-22 05:02:53 --> Controller Class Initialized
DEBUG - 2011-09-22 05:02:53 --> Model Class Initialized
DEBUG - 2011-09-22 05:02:53 --> Model Class Initialized
DEBUG - 2011-09-22 05:02:53 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-22 05:02:53 --> Database Driver Class Initialized
DEBUG - 2011-09-22 05:02:54 --> Final output sent to browser
DEBUG - 2011-09-22 05:02:54 --> Total execution time: 0.5378
DEBUG - 2011-09-22 05:03:01 --> Config Class Initialized
DEBUG - 2011-09-22 05:03:01 --> Hooks Class Initialized
DEBUG - 2011-09-22 05:03:01 --> Utf8 Class Initialized
DEBUG - 2011-09-22 05:03:01 --> UTF-8 Support Enabled
DEBUG - 2011-09-22 05:03:01 --> URI Class Initialized
DEBUG - 2011-09-22 05:03:01 --> Router Class Initialized
DEBUG - 2011-09-22 05:03:01 --> Output Class Initialized
DEBUG - 2011-09-22 05:03:01 --> Input Class Initialized
DEBUG - 2011-09-22 05:03:01 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-22 05:03:01 --> Language Class Initialized
DEBUG - 2011-09-22 05:03:01 --> Loader Class Initialized
DEBUG - 2011-09-22 05:03:01 --> Controller Class Initialized
ERROR - 2011-09-22 05:03:01 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-22 05:03:01 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-22 05:03:01 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-22 05:03:01 --> Model Class Initialized
DEBUG - 2011-09-22 05:03:01 --> Model Class Initialized
DEBUG - 2011-09-22 05:03:01 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-22 05:03:01 --> Database Driver Class Initialized
DEBUG - 2011-09-22 05:03:01 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-22 05:03:01 --> Helper loaded: url_helper
DEBUG - 2011-09-22 05:03:01 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-22 05:03:01 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-22 05:03:01 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-22 05:03:01 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-22 05:03:01 --> Final output sent to browser
DEBUG - 2011-09-22 05:03:01 --> Total execution time: 0.0830
DEBUG - 2011-09-22 05:03:01 --> Config Class Initialized
DEBUG - 2011-09-22 05:03:01 --> Hooks Class Initialized
DEBUG - 2011-09-22 05:03:01 --> Utf8 Class Initialized
DEBUG - 2011-09-22 05:03:01 --> UTF-8 Support Enabled
DEBUG - 2011-09-22 05:03:01 --> URI Class Initialized
DEBUG - 2011-09-22 05:03:01 --> Router Class Initialized
DEBUG - 2011-09-22 05:03:01 --> Output Class Initialized
DEBUG - 2011-09-22 05:03:01 --> Input Class Initialized
DEBUG - 2011-09-22 05:03:01 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-22 05:03:01 --> Language Class Initialized
DEBUG - 2011-09-22 05:03:01 --> Loader Class Initialized
DEBUG - 2011-09-22 05:03:01 --> Controller Class Initialized
DEBUG - 2011-09-22 05:03:01 --> Model Class Initialized
DEBUG - 2011-09-22 05:03:01 --> Model Class Initialized
DEBUG - 2011-09-22 05:03:01 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-22 05:03:01 --> Database Driver Class Initialized
DEBUG - 2011-09-22 05:03:02 --> Final output sent to browser
DEBUG - 2011-09-22 05:03:02 --> Total execution time: 0.6296
DEBUG - 2011-09-22 05:03:07 --> Config Class Initialized
DEBUG - 2011-09-22 05:03:07 --> Hooks Class Initialized
DEBUG - 2011-09-22 05:03:07 --> Utf8 Class Initialized
DEBUG - 2011-09-22 05:03:07 --> UTF-8 Support Enabled
DEBUG - 2011-09-22 05:03:07 --> URI Class Initialized
DEBUG - 2011-09-22 05:03:07 --> Router Class Initialized
DEBUG - 2011-09-22 05:03:07 --> Output Class Initialized
DEBUG - 2011-09-22 05:03:07 --> Input Class Initialized
DEBUG - 2011-09-22 05:03:07 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-22 05:03:07 --> Language Class Initialized
DEBUG - 2011-09-22 05:03:07 --> Loader Class Initialized
DEBUG - 2011-09-22 05:03:07 --> Controller Class Initialized
ERROR - 2011-09-22 05:03:07 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-22 05:03:07 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-22 05:03:07 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-22 05:03:07 --> Model Class Initialized
DEBUG - 2011-09-22 05:03:07 --> Model Class Initialized
DEBUG - 2011-09-22 05:03:07 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-22 05:03:07 --> Database Driver Class Initialized
DEBUG - 2011-09-22 05:03:07 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-22 05:03:07 --> Helper loaded: url_helper
DEBUG - 2011-09-22 05:03:07 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-22 05:03:07 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-22 05:03:07 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-22 05:03:07 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-22 05:03:07 --> Final output sent to browser
DEBUG - 2011-09-22 05:03:07 --> Total execution time: 0.0330
DEBUG - 2011-09-22 05:03:07 --> Config Class Initialized
DEBUG - 2011-09-22 05:03:07 --> Hooks Class Initialized
DEBUG - 2011-09-22 05:03:07 --> Utf8 Class Initialized
DEBUG - 2011-09-22 05:03:07 --> UTF-8 Support Enabled
DEBUG - 2011-09-22 05:03:07 --> URI Class Initialized
DEBUG - 2011-09-22 05:03:07 --> Router Class Initialized
DEBUG - 2011-09-22 05:03:07 --> Output Class Initialized
DEBUG - 2011-09-22 05:03:07 --> Input Class Initialized
DEBUG - 2011-09-22 05:03:07 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-22 05:03:07 --> Language Class Initialized
DEBUG - 2011-09-22 05:03:07 --> Loader Class Initialized
DEBUG - 2011-09-22 05:03:07 --> Controller Class Initialized
DEBUG - 2011-09-22 05:03:07 --> Model Class Initialized
DEBUG - 2011-09-22 05:03:07 --> Model Class Initialized
DEBUG - 2011-09-22 05:03:07 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-22 05:03:07 --> Database Driver Class Initialized
DEBUG - 2011-09-22 05:03:08 --> Final output sent to browser
DEBUG - 2011-09-22 05:03:08 --> Total execution time: 0.5907
DEBUG - 2011-09-22 05:03:16 --> Config Class Initialized
DEBUG - 2011-09-22 05:03:16 --> Hooks Class Initialized
DEBUG - 2011-09-22 05:03:16 --> Utf8 Class Initialized
DEBUG - 2011-09-22 05:03:16 --> UTF-8 Support Enabled
DEBUG - 2011-09-22 05:03:16 --> URI Class Initialized
DEBUG - 2011-09-22 05:03:16 --> Router Class Initialized
DEBUG - 2011-09-22 05:03:16 --> Output Class Initialized
DEBUG - 2011-09-22 05:03:16 --> Input Class Initialized
DEBUG - 2011-09-22 05:03:16 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-22 05:03:16 --> Language Class Initialized
DEBUG - 2011-09-22 05:03:16 --> Loader Class Initialized
DEBUG - 2011-09-22 05:03:16 --> Controller Class Initialized
ERROR - 2011-09-22 05:03:16 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-22 05:03:16 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-22 05:03:16 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-22 05:03:16 --> Model Class Initialized
DEBUG - 2011-09-22 05:03:16 --> Model Class Initialized
DEBUG - 2011-09-22 05:03:16 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-22 05:03:16 --> Database Driver Class Initialized
DEBUG - 2011-09-22 05:03:16 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-22 05:03:16 --> Helper loaded: url_helper
DEBUG - 2011-09-22 05:03:16 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-22 05:03:16 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-22 05:03:16 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-22 05:03:16 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-22 05:03:16 --> Final output sent to browser
DEBUG - 2011-09-22 05:03:16 --> Total execution time: 0.0335
DEBUG - 2011-09-22 05:03:16 --> Config Class Initialized
DEBUG - 2011-09-22 05:03:16 --> Hooks Class Initialized
DEBUG - 2011-09-22 05:03:16 --> Utf8 Class Initialized
DEBUG - 2011-09-22 05:03:16 --> UTF-8 Support Enabled
DEBUG - 2011-09-22 05:03:16 --> URI Class Initialized
DEBUG - 2011-09-22 05:03:16 --> Router Class Initialized
DEBUG - 2011-09-22 05:03:16 --> Output Class Initialized
DEBUG - 2011-09-22 05:03:16 --> Input Class Initialized
DEBUG - 2011-09-22 05:03:16 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-22 05:03:16 --> Language Class Initialized
DEBUG - 2011-09-22 05:03:16 --> Loader Class Initialized
DEBUG - 2011-09-22 05:03:16 --> Controller Class Initialized
DEBUG - 2011-09-22 05:03:16 --> Model Class Initialized
DEBUG - 2011-09-22 05:03:16 --> Model Class Initialized
DEBUG - 2011-09-22 05:03:16 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-22 05:03:16 --> Database Driver Class Initialized
DEBUG - 2011-09-22 05:03:16 --> Final output sent to browser
DEBUG - 2011-09-22 05:03:16 --> Total execution time: 0.5109
DEBUG - 2011-09-22 05:03:25 --> Config Class Initialized
DEBUG - 2011-09-22 05:03:25 --> Hooks Class Initialized
DEBUG - 2011-09-22 05:03:25 --> Utf8 Class Initialized
DEBUG - 2011-09-22 05:03:25 --> UTF-8 Support Enabled
DEBUG - 2011-09-22 05:03:25 --> URI Class Initialized
DEBUG - 2011-09-22 05:03:25 --> Router Class Initialized
DEBUG - 2011-09-22 05:03:25 --> Output Class Initialized
DEBUG - 2011-09-22 05:03:25 --> Input Class Initialized
DEBUG - 2011-09-22 05:03:25 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-22 05:03:25 --> Language Class Initialized
DEBUG - 2011-09-22 05:03:25 --> Loader Class Initialized
DEBUG - 2011-09-22 05:03:25 --> Controller Class Initialized
ERROR - 2011-09-22 05:03:25 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-22 05:03:25 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-22 05:03:25 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-22 05:03:25 --> Model Class Initialized
DEBUG - 2011-09-22 05:03:25 --> Model Class Initialized
DEBUG - 2011-09-22 05:03:25 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-22 05:03:25 --> Database Driver Class Initialized
DEBUG - 2011-09-22 05:03:25 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-22 05:03:25 --> Helper loaded: url_helper
DEBUG - 2011-09-22 05:03:25 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-22 05:03:25 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-22 05:03:25 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-22 05:03:25 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-22 05:03:25 --> Final output sent to browser
DEBUG - 2011-09-22 05:03:25 --> Total execution time: 0.0726
DEBUG - 2011-09-22 05:03:26 --> Config Class Initialized
DEBUG - 2011-09-22 05:03:26 --> Hooks Class Initialized
DEBUG - 2011-09-22 05:03:26 --> Utf8 Class Initialized
DEBUG - 2011-09-22 05:03:26 --> UTF-8 Support Enabled
DEBUG - 2011-09-22 05:03:26 --> URI Class Initialized
DEBUG - 2011-09-22 05:03:26 --> Router Class Initialized
DEBUG - 2011-09-22 05:03:26 --> Output Class Initialized
DEBUG - 2011-09-22 05:03:26 --> Input Class Initialized
DEBUG - 2011-09-22 05:03:26 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-22 05:03:26 --> Language Class Initialized
DEBUG - 2011-09-22 05:03:26 --> Loader Class Initialized
DEBUG - 2011-09-22 05:03:26 --> Controller Class Initialized
DEBUG - 2011-09-22 05:03:26 --> Model Class Initialized
DEBUG - 2011-09-22 05:03:26 --> Model Class Initialized
DEBUG - 2011-09-22 05:03:26 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-22 05:03:26 --> Database Driver Class Initialized
DEBUG - 2011-09-22 05:03:27 --> Final output sent to browser
DEBUG - 2011-09-22 05:03:27 --> Total execution time: 0.6974
DEBUG - 2011-09-22 05:03:27 --> Config Class Initialized
DEBUG - 2011-09-22 05:03:27 --> Hooks Class Initialized
DEBUG - 2011-09-22 05:03:27 --> Utf8 Class Initialized
DEBUG - 2011-09-22 05:03:27 --> UTF-8 Support Enabled
DEBUG - 2011-09-22 05:03:27 --> URI Class Initialized
DEBUG - 2011-09-22 05:03:27 --> Router Class Initialized
ERROR - 2011-09-22 05:03:27 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-09-22 05:03:28 --> Config Class Initialized
DEBUG - 2011-09-22 05:03:28 --> Hooks Class Initialized
DEBUG - 2011-09-22 05:03:28 --> Utf8 Class Initialized
DEBUG - 2011-09-22 05:03:28 --> UTF-8 Support Enabled
DEBUG - 2011-09-22 05:03:28 --> URI Class Initialized
DEBUG - 2011-09-22 05:03:28 --> Router Class Initialized
DEBUG - 2011-09-22 05:03:28 --> Output Class Initialized
DEBUG - 2011-09-22 05:03:28 --> Input Class Initialized
DEBUG - 2011-09-22 05:03:28 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-22 05:03:28 --> Language Class Initialized
DEBUG - 2011-09-22 05:03:28 --> Loader Class Initialized
DEBUG - 2011-09-22 05:03:28 --> Controller Class Initialized
ERROR - 2011-09-22 05:03:28 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-22 05:03:28 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-22 05:03:28 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-22 05:03:28 --> Model Class Initialized
DEBUG - 2011-09-22 05:03:28 --> Model Class Initialized
DEBUG - 2011-09-22 05:03:28 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-22 05:03:28 --> Database Driver Class Initialized
DEBUG - 2011-09-22 05:03:28 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-22 05:03:28 --> Helper loaded: url_helper
DEBUG - 2011-09-22 05:03:28 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-22 05:03:28 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-22 05:03:28 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-22 05:03:28 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-22 05:03:28 --> Final output sent to browser
DEBUG - 2011-09-22 05:03:28 --> Total execution time: 0.0323
DEBUG - 2011-09-22 05:03:32 --> Config Class Initialized
DEBUG - 2011-09-22 05:03:32 --> Hooks Class Initialized
DEBUG - 2011-09-22 05:03:32 --> Utf8 Class Initialized
DEBUG - 2011-09-22 05:03:32 --> UTF-8 Support Enabled
DEBUG - 2011-09-22 05:03:32 --> URI Class Initialized
DEBUG - 2011-09-22 05:03:32 --> Router Class Initialized
DEBUG - 2011-09-22 05:03:32 --> Output Class Initialized
DEBUG - 2011-09-22 05:03:32 --> Input Class Initialized
DEBUG - 2011-09-22 05:03:32 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-22 05:03:32 --> Language Class Initialized
DEBUG - 2011-09-22 05:03:32 --> Loader Class Initialized
DEBUG - 2011-09-22 05:03:32 --> Controller Class Initialized
ERROR - 2011-09-22 05:03:32 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-22 05:03:32 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-22 05:03:32 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-22 05:03:32 --> Model Class Initialized
DEBUG - 2011-09-22 05:03:32 --> Model Class Initialized
DEBUG - 2011-09-22 05:03:32 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-22 05:03:32 --> Database Driver Class Initialized
DEBUG - 2011-09-22 05:03:32 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-22 05:03:32 --> Helper loaded: url_helper
DEBUG - 2011-09-22 05:03:32 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-22 05:03:32 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-22 05:03:32 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-22 05:03:32 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-22 05:03:32 --> Final output sent to browser
DEBUG - 2011-09-22 05:03:32 --> Total execution time: 0.1063
DEBUG - 2011-09-22 05:03:33 --> Config Class Initialized
DEBUG - 2011-09-22 05:03:33 --> Hooks Class Initialized
DEBUG - 2011-09-22 05:03:33 --> Utf8 Class Initialized
DEBUG - 2011-09-22 05:03:33 --> UTF-8 Support Enabled
DEBUG - 2011-09-22 05:03:33 --> URI Class Initialized
DEBUG - 2011-09-22 05:03:33 --> Router Class Initialized
DEBUG - 2011-09-22 05:03:33 --> Output Class Initialized
DEBUG - 2011-09-22 05:03:33 --> Input Class Initialized
DEBUG - 2011-09-22 05:03:33 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-22 05:03:33 --> Language Class Initialized
DEBUG - 2011-09-22 05:03:33 --> Loader Class Initialized
DEBUG - 2011-09-22 05:03:33 --> Controller Class Initialized
DEBUG - 2011-09-22 05:03:33 --> Model Class Initialized
DEBUG - 2011-09-22 05:03:33 --> Model Class Initialized
DEBUG - 2011-09-22 05:03:33 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-22 05:03:33 --> Database Driver Class Initialized
DEBUG - 2011-09-22 05:03:33 --> Final output sent to browser
DEBUG - 2011-09-22 05:03:33 --> Total execution time: 0.6231
DEBUG - 2011-09-22 05:04:29 --> Config Class Initialized
DEBUG - 2011-09-22 05:04:29 --> Hooks Class Initialized
DEBUG - 2011-09-22 05:04:29 --> Utf8 Class Initialized
DEBUG - 2011-09-22 05:04:29 --> UTF-8 Support Enabled
DEBUG - 2011-09-22 05:04:29 --> URI Class Initialized
DEBUG - 2011-09-22 05:04:29 --> Router Class Initialized
DEBUG - 2011-09-22 05:04:29 --> Output Class Initialized
DEBUG - 2011-09-22 05:04:29 --> Input Class Initialized
DEBUG - 2011-09-22 05:04:29 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-22 05:04:29 --> Language Class Initialized
DEBUG - 2011-09-22 05:04:29 --> Loader Class Initialized
DEBUG - 2011-09-22 05:04:29 --> Controller Class Initialized
ERROR - 2011-09-22 05:04:29 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-22 05:04:29 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-22 05:04:29 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-22 05:04:29 --> Model Class Initialized
DEBUG - 2011-09-22 05:04:29 --> Model Class Initialized
DEBUG - 2011-09-22 05:04:29 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-22 05:04:29 --> Database Driver Class Initialized
DEBUG - 2011-09-22 05:04:30 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-22 05:04:30 --> Helper loaded: url_helper
DEBUG - 2011-09-22 05:04:30 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-22 05:04:30 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-22 05:04:30 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-22 05:04:30 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-22 05:04:30 --> Final output sent to browser
DEBUG - 2011-09-22 05:04:30 --> Total execution time: 0.0393
DEBUG - 2011-09-22 05:04:30 --> Config Class Initialized
DEBUG - 2011-09-22 05:04:30 --> Hooks Class Initialized
DEBUG - 2011-09-22 05:04:30 --> Utf8 Class Initialized
DEBUG - 2011-09-22 05:04:30 --> UTF-8 Support Enabled
DEBUG - 2011-09-22 05:04:30 --> URI Class Initialized
DEBUG - 2011-09-22 05:04:30 --> Router Class Initialized
DEBUG - 2011-09-22 05:04:30 --> Output Class Initialized
DEBUG - 2011-09-22 05:04:30 --> Input Class Initialized
DEBUG - 2011-09-22 05:04:30 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-22 05:04:30 --> Language Class Initialized
DEBUG - 2011-09-22 05:04:30 --> Loader Class Initialized
DEBUG - 2011-09-22 05:04:30 --> Controller Class Initialized
DEBUG - 2011-09-22 05:04:30 --> Model Class Initialized
DEBUG - 2011-09-22 05:04:30 --> Model Class Initialized
DEBUG - 2011-09-22 05:04:30 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-22 05:04:30 --> Database Driver Class Initialized
DEBUG - 2011-09-22 05:04:32 --> Final output sent to browser
DEBUG - 2011-09-22 05:04:32 --> Total execution time: 1.7882
DEBUG - 2011-09-22 05:04:43 --> Config Class Initialized
DEBUG - 2011-09-22 05:04:43 --> Hooks Class Initialized
DEBUG - 2011-09-22 05:04:43 --> Utf8 Class Initialized
DEBUG - 2011-09-22 05:04:43 --> UTF-8 Support Enabled
DEBUG - 2011-09-22 05:04:43 --> URI Class Initialized
DEBUG - 2011-09-22 05:04:43 --> Router Class Initialized
DEBUG - 2011-09-22 05:04:43 --> Output Class Initialized
DEBUG - 2011-09-22 05:04:43 --> Input Class Initialized
DEBUG - 2011-09-22 05:04:43 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-22 05:04:43 --> Language Class Initialized
DEBUG - 2011-09-22 05:04:43 --> Loader Class Initialized
DEBUG - 2011-09-22 05:04:43 --> Controller Class Initialized
ERROR - 2011-09-22 05:04:43 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-22 05:04:43 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-22 05:04:43 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-22 05:04:43 --> Model Class Initialized
DEBUG - 2011-09-22 05:04:43 --> Model Class Initialized
DEBUG - 2011-09-22 05:04:43 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-22 05:04:43 --> Database Driver Class Initialized
DEBUG - 2011-09-22 05:04:43 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-22 05:04:43 --> Helper loaded: url_helper
DEBUG - 2011-09-22 05:04:43 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-22 05:04:43 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-22 05:04:43 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-22 05:04:43 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-22 05:04:43 --> Final output sent to browser
DEBUG - 2011-09-22 05:04:43 --> Total execution time: 0.0499
DEBUG - 2011-09-22 05:04:43 --> Config Class Initialized
DEBUG - 2011-09-22 05:04:43 --> Hooks Class Initialized
DEBUG - 2011-09-22 05:04:43 --> Utf8 Class Initialized
DEBUG - 2011-09-22 05:04:43 --> UTF-8 Support Enabled
DEBUG - 2011-09-22 05:04:43 --> URI Class Initialized
DEBUG - 2011-09-22 05:04:43 --> Router Class Initialized
DEBUG - 2011-09-22 05:04:43 --> Output Class Initialized
DEBUG - 2011-09-22 05:04:43 --> Input Class Initialized
DEBUG - 2011-09-22 05:04:43 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-22 05:04:43 --> Language Class Initialized
DEBUG - 2011-09-22 05:04:43 --> Loader Class Initialized
DEBUG - 2011-09-22 05:04:43 --> Controller Class Initialized
DEBUG - 2011-09-22 05:04:43 --> Model Class Initialized
DEBUG - 2011-09-22 05:04:43 --> Model Class Initialized
DEBUG - 2011-09-22 05:04:43 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-22 05:04:43 --> Database Driver Class Initialized
DEBUG - 2011-09-22 05:04:44 --> Final output sent to browser
DEBUG - 2011-09-22 05:04:44 --> Total execution time: 0.5399
DEBUG - 2011-09-22 05:08:40 --> Config Class Initialized
DEBUG - 2011-09-22 05:08:40 --> Hooks Class Initialized
DEBUG - 2011-09-22 05:08:40 --> Utf8 Class Initialized
DEBUG - 2011-09-22 05:08:40 --> UTF-8 Support Enabled
DEBUG - 2011-09-22 05:08:40 --> URI Class Initialized
DEBUG - 2011-09-22 05:08:40 --> Router Class Initialized
DEBUG - 2011-09-22 05:08:40 --> Output Class Initialized
DEBUG - 2011-09-22 05:08:40 --> Input Class Initialized
DEBUG - 2011-09-22 05:08:40 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-22 05:08:40 --> Language Class Initialized
DEBUG - 2011-09-22 05:08:40 --> Loader Class Initialized
DEBUG - 2011-09-22 05:08:40 --> Controller Class Initialized
DEBUG - 2011-09-22 05:08:40 --> Model Class Initialized
DEBUG - 2011-09-22 05:08:40 --> Model Class Initialized
DEBUG - 2011-09-22 05:08:40 --> Model Class Initialized
DEBUG - 2011-09-22 05:08:40 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-22 05:08:40 --> Database Driver Class Initialized
DEBUG - 2011-09-22 05:08:41 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-22 05:08:41 --> Helper loaded: url_helper
DEBUG - 2011-09-22 05:08:41 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-22 05:08:41 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-22 05:08:41 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-22 05:08:41 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-22 05:08:41 --> Final output sent to browser
DEBUG - 2011-09-22 05:08:41 --> Total execution time: 0.9623
DEBUG - 2011-09-22 05:08:42 --> Config Class Initialized
DEBUG - 2011-09-22 05:08:42 --> Hooks Class Initialized
DEBUG - 2011-09-22 05:08:42 --> Utf8 Class Initialized
DEBUG - 2011-09-22 05:08:42 --> UTF-8 Support Enabled
DEBUG - 2011-09-22 05:08:42 --> URI Class Initialized
DEBUG - 2011-09-22 05:08:42 --> Router Class Initialized
DEBUG - 2011-09-22 05:08:42 --> Output Class Initialized
DEBUG - 2011-09-22 05:08:42 --> Input Class Initialized
DEBUG - 2011-09-22 05:08:42 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-22 05:08:42 --> Language Class Initialized
DEBUG - 2011-09-22 05:08:42 --> Loader Class Initialized
DEBUG - 2011-09-22 05:08:42 --> Controller Class Initialized
ERROR - 2011-09-22 05:08:42 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-22 05:08:42 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-22 05:08:42 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-22 05:08:42 --> Model Class Initialized
DEBUG - 2011-09-22 05:08:42 --> Model Class Initialized
DEBUG - 2011-09-22 05:08:42 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-22 05:08:42 --> Database Driver Class Initialized
DEBUG - 2011-09-22 05:08:42 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-22 05:08:42 --> Helper loaded: url_helper
DEBUG - 2011-09-22 05:08:42 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-22 05:08:42 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-22 05:08:42 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-22 05:08:42 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-22 05:08:42 --> Final output sent to browser
DEBUG - 2011-09-22 05:08:42 --> Total execution time: 0.0357
DEBUG - 2011-09-22 05:28:58 --> Config Class Initialized
DEBUG - 2011-09-22 05:28:58 --> Hooks Class Initialized
DEBUG - 2011-09-22 05:28:58 --> Utf8 Class Initialized
DEBUG - 2011-09-22 05:28:58 --> UTF-8 Support Enabled
DEBUG - 2011-09-22 05:28:58 --> URI Class Initialized
DEBUG - 2011-09-22 05:28:58 --> Router Class Initialized
ERROR - 2011-09-22 05:28:58 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-09-22 05:28:59 --> Config Class Initialized
DEBUG - 2011-09-22 05:28:59 --> Hooks Class Initialized
DEBUG - 2011-09-22 05:28:59 --> Utf8 Class Initialized
DEBUG - 2011-09-22 05:28:59 --> UTF-8 Support Enabled
DEBUG - 2011-09-22 05:28:59 --> URI Class Initialized
DEBUG - 2011-09-22 05:28:59 --> Router Class Initialized
DEBUG - 2011-09-22 05:28:59 --> Output Class Initialized
DEBUG - 2011-09-22 05:28:59 --> Input Class Initialized
DEBUG - 2011-09-22 05:28:59 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-22 05:28:59 --> Language Class Initialized
DEBUG - 2011-09-22 05:28:59 --> Loader Class Initialized
DEBUG - 2011-09-22 05:28:59 --> Controller Class Initialized
DEBUG - 2011-09-22 05:28:59 --> Model Class Initialized
DEBUG - 2011-09-22 05:28:59 --> Model Class Initialized
DEBUG - 2011-09-22 05:28:59 --> Model Class Initialized
DEBUG - 2011-09-22 05:28:59 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-22 05:28:59 --> Database Driver Class Initialized
DEBUG - 2011-09-22 05:29:00 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-22 05:29:00 --> Helper loaded: url_helper
DEBUG - 2011-09-22 05:29:00 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-22 05:29:00 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-22 05:29:00 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-22 05:29:00 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-22 05:29:00 --> Final output sent to browser
DEBUG - 2011-09-22 05:29:00 --> Total execution time: 0.8961
DEBUG - 2011-09-22 05:29:03 --> Config Class Initialized
DEBUG - 2011-09-22 05:29:03 --> Hooks Class Initialized
DEBUG - 2011-09-22 05:29:03 --> Utf8 Class Initialized
DEBUG - 2011-09-22 05:29:03 --> UTF-8 Support Enabled
DEBUG - 2011-09-22 05:29:03 --> URI Class Initialized
DEBUG - 2011-09-22 05:29:03 --> Router Class Initialized
DEBUG - 2011-09-22 05:29:03 --> Output Class Initialized
DEBUG - 2011-09-22 05:29:03 --> Input Class Initialized
DEBUG - 2011-09-22 05:29:03 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-22 05:29:03 --> Language Class Initialized
DEBUG - 2011-09-22 05:29:03 --> Loader Class Initialized
DEBUG - 2011-09-22 05:29:03 --> Controller Class Initialized
ERROR - 2011-09-22 05:29:03 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-22 05:29:03 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-22 05:29:03 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-22 05:29:03 --> Model Class Initialized
DEBUG - 2011-09-22 05:29:03 --> Model Class Initialized
DEBUG - 2011-09-22 05:29:03 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-22 05:29:03 --> Database Driver Class Initialized
DEBUG - 2011-09-22 05:29:03 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-22 05:29:03 --> Helper loaded: url_helper
DEBUG - 2011-09-22 05:29:03 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-22 05:29:03 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-22 05:29:03 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-22 05:29:03 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-22 05:29:03 --> Final output sent to browser
DEBUG - 2011-09-22 05:29:03 --> Total execution time: 0.0704
DEBUG - 2011-09-22 05:29:24 --> Config Class Initialized
DEBUG - 2011-09-22 05:29:24 --> Hooks Class Initialized
DEBUG - 2011-09-22 05:29:24 --> Utf8 Class Initialized
DEBUG - 2011-09-22 05:29:24 --> UTF-8 Support Enabled
DEBUG - 2011-09-22 05:29:24 --> URI Class Initialized
DEBUG - 2011-09-22 05:29:24 --> Router Class Initialized
DEBUG - 2011-09-22 05:29:24 --> Output Class Initialized
DEBUG - 2011-09-22 05:29:24 --> Input Class Initialized
DEBUG - 2011-09-22 05:29:24 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-22 05:29:24 --> Language Class Initialized
DEBUG - 2011-09-22 05:29:24 --> Loader Class Initialized
DEBUG - 2011-09-22 05:29:24 --> Controller Class Initialized
ERROR - 2011-09-22 05:29:24 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-22 05:29:24 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-22 05:29:24 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-22 05:29:24 --> Model Class Initialized
DEBUG - 2011-09-22 05:29:24 --> Model Class Initialized
DEBUG - 2011-09-22 05:29:24 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-22 05:29:25 --> Database Driver Class Initialized
DEBUG - 2011-09-22 05:29:25 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-22 05:29:25 --> Helper loaded: url_helper
DEBUG - 2011-09-22 05:29:25 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-22 05:29:25 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-22 05:29:25 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-22 05:29:25 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-22 05:29:25 --> Final output sent to browser
DEBUG - 2011-09-22 05:29:25 --> Total execution time: 0.1433
DEBUG - 2011-09-22 05:29:29 --> Config Class Initialized
DEBUG - 2011-09-22 05:29:29 --> Hooks Class Initialized
DEBUG - 2011-09-22 05:29:29 --> Utf8 Class Initialized
DEBUG - 2011-09-22 05:29:29 --> UTF-8 Support Enabled
DEBUG - 2011-09-22 05:29:29 --> URI Class Initialized
DEBUG - 2011-09-22 05:29:29 --> Router Class Initialized
DEBUG - 2011-09-22 05:29:29 --> Output Class Initialized
DEBUG - 2011-09-22 05:29:29 --> Input Class Initialized
DEBUG - 2011-09-22 05:29:29 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-22 05:29:29 --> Language Class Initialized
DEBUG - 2011-09-22 05:29:29 --> Loader Class Initialized
DEBUG - 2011-09-22 05:29:29 --> Controller Class Initialized
DEBUG - 2011-09-22 05:29:29 --> Model Class Initialized
DEBUG - 2011-09-22 05:29:29 --> Model Class Initialized
DEBUG - 2011-09-22 05:29:29 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-22 05:29:29 --> Database Driver Class Initialized
DEBUG - 2011-09-22 05:29:30 --> Final output sent to browser
DEBUG - 2011-09-22 05:29:30 --> Total execution time: 0.7339
DEBUG - 2011-09-22 05:49:58 --> Config Class Initialized
DEBUG - 2011-09-22 05:49:58 --> Hooks Class Initialized
DEBUG - 2011-09-22 05:49:58 --> Utf8 Class Initialized
DEBUG - 2011-09-22 05:49:58 --> UTF-8 Support Enabled
DEBUG - 2011-09-22 05:49:58 --> URI Class Initialized
DEBUG - 2011-09-22 05:49:58 --> Router Class Initialized
ERROR - 2011-09-22 05:49:58 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-09-22 05:49:59 --> Config Class Initialized
DEBUG - 2011-09-22 05:49:59 --> Hooks Class Initialized
DEBUG - 2011-09-22 05:49:59 --> Utf8 Class Initialized
DEBUG - 2011-09-22 05:49:59 --> UTF-8 Support Enabled
DEBUG - 2011-09-22 05:49:59 --> URI Class Initialized
DEBUG - 2011-09-22 05:49:59 --> Router Class Initialized
DEBUG - 2011-09-22 05:49:59 --> Output Class Initialized
DEBUG - 2011-09-22 05:49:59 --> Input Class Initialized
DEBUG - 2011-09-22 05:49:59 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-22 05:49:59 --> Language Class Initialized
DEBUG - 2011-09-22 05:49:59 --> Loader Class Initialized
DEBUG - 2011-09-22 05:49:59 --> Controller Class Initialized
DEBUG - 2011-09-22 05:49:59 --> Model Class Initialized
DEBUG - 2011-09-22 05:49:59 --> Model Class Initialized
DEBUG - 2011-09-22 05:49:59 --> Model Class Initialized
DEBUG - 2011-09-22 05:49:59 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-22 05:49:59 --> Database Driver Class Initialized
DEBUG - 2011-09-22 05:50:00 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-22 05:50:00 --> Helper loaded: url_helper
DEBUG - 2011-09-22 05:50:00 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-22 05:50:00 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-22 05:50:00 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-22 05:50:00 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-22 05:50:00 --> Final output sent to browser
DEBUG - 2011-09-22 05:50:00 --> Total execution time: 0.3492
DEBUG - 2011-09-22 05:50:03 --> Config Class Initialized
DEBUG - 2011-09-22 05:50:03 --> Hooks Class Initialized
DEBUG - 2011-09-22 05:50:03 --> Utf8 Class Initialized
DEBUG - 2011-09-22 05:50:03 --> UTF-8 Support Enabled
DEBUG - 2011-09-22 05:50:03 --> URI Class Initialized
DEBUG - 2011-09-22 05:50:03 --> Router Class Initialized
DEBUG - 2011-09-22 05:50:03 --> Output Class Initialized
DEBUG - 2011-09-22 05:50:03 --> Input Class Initialized
DEBUG - 2011-09-22 05:50:03 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-22 05:50:03 --> Language Class Initialized
DEBUG - 2011-09-22 05:50:03 --> Loader Class Initialized
DEBUG - 2011-09-22 05:50:03 --> Controller Class Initialized
ERROR - 2011-09-22 05:50:03 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-22 05:50:03 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-22 05:50:03 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-22 05:50:03 --> Model Class Initialized
DEBUG - 2011-09-22 05:50:03 --> Model Class Initialized
DEBUG - 2011-09-22 05:50:03 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-22 05:50:03 --> Database Driver Class Initialized
DEBUG - 2011-09-22 05:50:03 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-22 05:50:03 --> Helper loaded: url_helper
DEBUG - 2011-09-22 05:50:03 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-22 05:50:03 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-22 05:50:03 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-22 05:50:03 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-22 05:50:03 --> Final output sent to browser
DEBUG - 2011-09-22 05:50:03 --> Total execution time: 0.0730
DEBUG - 2011-09-22 05:50:25 --> Config Class Initialized
DEBUG - 2011-09-22 05:50:25 --> Hooks Class Initialized
DEBUG - 2011-09-22 05:50:25 --> Utf8 Class Initialized
DEBUG - 2011-09-22 05:50:25 --> UTF-8 Support Enabled
DEBUG - 2011-09-22 05:50:25 --> URI Class Initialized
DEBUG - 2011-09-22 05:50:25 --> Router Class Initialized
DEBUG - 2011-09-22 05:50:25 --> No URI present. Default controller set.
DEBUG - 2011-09-22 05:50:25 --> Output Class Initialized
DEBUG - 2011-09-22 05:50:25 --> Input Class Initialized
DEBUG - 2011-09-22 05:50:25 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-22 05:50:25 --> Language Class Initialized
DEBUG - 2011-09-22 05:50:25 --> Loader Class Initialized
DEBUG - 2011-09-22 05:50:25 --> Controller Class Initialized
DEBUG - 2011-09-22 05:50:25 --> File loaded: application/views/splash/main.php
DEBUG - 2011-09-22 05:50:25 --> Helper loaded: url_helper
DEBUG - 2011-09-22 05:50:25 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-22 05:50:25 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-22 05:50:25 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-22 05:50:25 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-22 05:50:25 --> Final output sent to browser
DEBUG - 2011-09-22 05:50:25 --> Total execution time: 0.0894
DEBUG - 2011-09-22 07:05:00 --> Config Class Initialized
DEBUG - 2011-09-22 07:05:00 --> Hooks Class Initialized
DEBUG - 2011-09-22 07:05:00 --> Utf8 Class Initialized
DEBUG - 2011-09-22 07:05:00 --> UTF-8 Support Enabled
DEBUG - 2011-09-22 07:05:00 --> URI Class Initialized
DEBUG - 2011-09-22 07:05:00 --> Router Class Initialized
ERROR - 2011-09-22 07:05:00 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-09-22 07:05:01 --> Config Class Initialized
DEBUG - 2011-09-22 07:05:01 --> Hooks Class Initialized
DEBUG - 2011-09-22 07:05:01 --> Utf8 Class Initialized
DEBUG - 2011-09-22 07:05:01 --> UTF-8 Support Enabled
DEBUG - 2011-09-22 07:05:01 --> URI Class Initialized
DEBUG - 2011-09-22 07:05:01 --> Router Class Initialized
DEBUG - 2011-09-22 07:05:01 --> Output Class Initialized
DEBUG - 2011-09-22 07:05:01 --> Input Class Initialized
DEBUG - 2011-09-22 07:05:01 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-22 07:05:01 --> Language Class Initialized
DEBUG - 2011-09-22 07:05:01 --> Loader Class Initialized
DEBUG - 2011-09-22 07:05:01 --> Controller Class Initialized
DEBUG - 2011-09-22 07:05:01 --> Model Class Initialized
DEBUG - 2011-09-22 07:05:01 --> Model Class Initialized
DEBUG - 2011-09-22 07:05:01 --> Model Class Initialized
DEBUG - 2011-09-22 07:05:01 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-22 07:05:01 --> Database Driver Class Initialized
DEBUG - 2011-09-22 07:05:03 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-22 07:05:03 --> Helper loaded: url_helper
DEBUG - 2011-09-22 07:05:03 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-22 07:05:03 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-22 07:05:03 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-22 07:05:03 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-22 07:05:03 --> Final output sent to browser
DEBUG - 2011-09-22 07:05:03 --> Total execution time: 2.7509
DEBUG - 2011-09-22 07:26:28 --> Config Class Initialized
DEBUG - 2011-09-22 07:26:28 --> Hooks Class Initialized
DEBUG - 2011-09-22 07:26:28 --> Utf8 Class Initialized
DEBUG - 2011-09-22 07:26:28 --> UTF-8 Support Enabled
DEBUG - 2011-09-22 07:26:28 --> URI Class Initialized
DEBUG - 2011-09-22 07:26:28 --> Router Class Initialized
DEBUG - 2011-09-22 07:26:28 --> Output Class Initialized
DEBUG - 2011-09-22 07:26:28 --> Input Class Initialized
DEBUG - 2011-09-22 07:26:28 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-22 07:26:28 --> Language Class Initialized
DEBUG - 2011-09-22 07:26:28 --> Loader Class Initialized
DEBUG - 2011-09-22 07:26:28 --> Controller Class Initialized
DEBUG - 2011-09-22 07:26:28 --> Model Class Initialized
DEBUG - 2011-09-22 07:26:28 --> Model Class Initialized
DEBUG - 2011-09-22 07:26:28 --> Model Class Initialized
DEBUG - 2011-09-22 07:26:28 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-22 07:26:28 --> Database Driver Class Initialized
DEBUG - 2011-09-22 07:26:28 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-22 07:26:28 --> Helper loaded: url_helper
DEBUG - 2011-09-22 07:26:28 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-22 07:26:28 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-22 07:26:29 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-22 07:26:29 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-22 07:26:29 --> Final output sent to browser
DEBUG - 2011-09-22 07:26:29 --> Total execution time: 0.3732
DEBUG - 2011-09-22 07:26:32 --> Config Class Initialized
DEBUG - 2011-09-22 07:26:32 --> Hooks Class Initialized
DEBUG - 2011-09-22 07:26:32 --> Utf8 Class Initialized
DEBUG - 2011-09-22 07:26:32 --> UTF-8 Support Enabled
DEBUG - 2011-09-22 07:26:32 --> URI Class Initialized
DEBUG - 2011-09-22 07:26:32 --> Router Class Initialized
ERROR - 2011-09-22 07:26:32 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-22 07:52:11 --> Config Class Initialized
DEBUG - 2011-09-22 07:52:11 --> Hooks Class Initialized
DEBUG - 2011-09-22 07:52:11 --> Utf8 Class Initialized
DEBUG - 2011-09-22 07:52:11 --> UTF-8 Support Enabled
DEBUG - 2011-09-22 07:52:11 --> URI Class Initialized
DEBUG - 2011-09-22 07:52:11 --> Router Class Initialized
DEBUG - 2011-09-22 07:52:11 --> No URI present. Default controller set.
DEBUG - 2011-09-22 07:52:11 --> Output Class Initialized
DEBUG - 2011-09-22 07:52:11 --> Input Class Initialized
DEBUG - 2011-09-22 07:52:11 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-22 07:52:11 --> Language Class Initialized
DEBUG - 2011-09-22 07:52:11 --> Loader Class Initialized
DEBUG - 2011-09-22 07:52:11 --> Controller Class Initialized
DEBUG - 2011-09-22 07:52:11 --> File loaded: application/views/splash/main.php
DEBUG - 2011-09-22 07:52:12 --> Helper loaded: url_helper
DEBUG - 2011-09-22 07:52:12 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-22 07:52:12 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-22 07:52:12 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-22 07:52:12 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-22 07:52:12 --> Final output sent to browser
DEBUG - 2011-09-22 07:52:12 --> Total execution time: 0.2800
DEBUG - 2011-09-22 09:10:41 --> Config Class Initialized
DEBUG - 2011-09-22 09:10:42 --> Hooks Class Initialized
DEBUG - 2011-09-22 09:10:42 --> Utf8 Class Initialized
DEBUG - 2011-09-22 09:10:42 --> UTF-8 Support Enabled
DEBUG - 2011-09-22 09:10:42 --> URI Class Initialized
DEBUG - 2011-09-22 09:10:42 --> Router Class Initialized
DEBUG - 2011-09-22 09:10:42 --> Output Class Initialized
DEBUG - 2011-09-22 09:10:42 --> Input Class Initialized
DEBUG - 2011-09-22 09:10:42 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-22 09:10:42 --> Language Class Initialized
DEBUG - 2011-09-22 09:10:42 --> Loader Class Initialized
DEBUG - 2011-09-22 09:10:42 --> Controller Class Initialized
ERROR - 2011-09-22 09:10:42 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-22 09:10:42 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-22 09:10:42 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-22 09:10:42 --> Model Class Initialized
DEBUG - 2011-09-22 09:10:42 --> Model Class Initialized
DEBUG - 2011-09-22 09:10:42 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-22 09:10:42 --> Database Driver Class Initialized
DEBUG - 2011-09-22 09:10:42 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-22 09:10:42 --> Helper loaded: url_helper
DEBUG - 2011-09-22 09:10:42 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-22 09:10:42 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-22 09:10:42 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-22 09:10:42 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-22 09:10:42 --> Final output sent to browser
DEBUG - 2011-09-22 09:10:42 --> Total execution time: 0.8909
DEBUG - 2011-09-22 09:10:46 --> Config Class Initialized
DEBUG - 2011-09-22 09:10:46 --> Hooks Class Initialized
DEBUG - 2011-09-22 09:10:46 --> Utf8 Class Initialized
DEBUG - 2011-09-22 09:10:46 --> UTF-8 Support Enabled
DEBUG - 2011-09-22 09:10:46 --> URI Class Initialized
DEBUG - 2011-09-22 09:10:46 --> Router Class Initialized
DEBUG - 2011-09-22 09:10:46 --> Output Class Initialized
DEBUG - 2011-09-22 09:10:46 --> Input Class Initialized
DEBUG - 2011-09-22 09:10:46 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-22 09:10:46 --> Language Class Initialized
DEBUG - 2011-09-22 09:10:46 --> Loader Class Initialized
DEBUG - 2011-09-22 09:10:46 --> Controller Class Initialized
DEBUG - 2011-09-22 09:10:46 --> Model Class Initialized
DEBUG - 2011-09-22 09:10:46 --> Model Class Initialized
DEBUG - 2011-09-22 09:10:46 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-22 09:10:46 --> Database Driver Class Initialized
DEBUG - 2011-09-22 09:10:47 --> Final output sent to browser
DEBUG - 2011-09-22 09:10:47 --> Total execution time: 1.1970
DEBUG - 2011-09-22 09:13:53 --> Config Class Initialized
DEBUG - 2011-09-22 09:13:53 --> Hooks Class Initialized
DEBUG - 2011-09-22 09:13:53 --> Utf8 Class Initialized
DEBUG - 2011-09-22 09:13:53 --> UTF-8 Support Enabled
DEBUG - 2011-09-22 09:13:53 --> URI Class Initialized
DEBUG - 2011-09-22 09:13:53 --> Router Class Initialized
DEBUG - 2011-09-22 09:13:53 --> Output Class Initialized
DEBUG - 2011-09-22 09:13:53 --> Input Class Initialized
DEBUG - 2011-09-22 09:13:53 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-22 09:13:53 --> Language Class Initialized
DEBUG - 2011-09-22 09:13:53 --> Loader Class Initialized
DEBUG - 2011-09-22 09:13:53 --> Controller Class Initialized
DEBUG - 2011-09-22 09:13:53 --> Model Class Initialized
DEBUG - 2011-09-22 09:13:53 --> Model Class Initialized
DEBUG - 2011-09-22 09:13:53 --> Model Class Initialized
DEBUG - 2011-09-22 09:13:53 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-22 09:13:53 --> Database Driver Class Initialized
DEBUG - 2011-09-22 09:13:53 --> Config Class Initialized
DEBUG - 2011-09-22 09:13:53 --> Hooks Class Initialized
DEBUG - 2011-09-22 09:13:53 --> Utf8 Class Initialized
DEBUG - 2011-09-22 09:13:53 --> UTF-8 Support Enabled
DEBUG - 2011-09-22 09:13:53 --> URI Class Initialized
DEBUG - 2011-09-22 09:13:53 --> Router Class Initialized
DEBUG - 2011-09-22 09:13:53 --> Output Class Initialized
DEBUG - 2011-09-22 09:13:53 --> Input Class Initialized
DEBUG - 2011-09-22 09:13:53 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-22 09:13:53 --> Language Class Initialized
DEBUG - 2011-09-22 09:13:53 --> Loader Class Initialized
DEBUG - 2011-09-22 09:13:53 --> Controller Class Initialized
ERROR - 2011-09-22 09:13:53 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-22 09:13:53 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-22 09:13:53 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-22 09:13:53 --> Model Class Initialized
DEBUG - 2011-09-22 09:13:53 --> Model Class Initialized
DEBUG - 2011-09-22 09:13:53 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-22 09:13:53 --> Database Driver Class Initialized
DEBUG - 2011-09-22 09:13:53 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-22 09:13:53 --> Helper loaded: url_helper
DEBUG - 2011-09-22 09:13:53 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-22 09:13:53 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-22 09:13:53 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-22 09:13:53 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-22 09:13:53 --> Final output sent to browser
DEBUG - 2011-09-22 09:13:53 --> Total execution time: 0.0512
DEBUG - 2011-09-22 09:13:56 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-22 09:13:56 --> Helper loaded: url_helper
DEBUG - 2011-09-22 09:13:56 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-22 09:13:56 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-22 09:13:56 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-22 09:13:56 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-22 09:13:56 --> Final output sent to browser
DEBUG - 2011-09-22 09:13:56 --> Total execution time: 2.5774
DEBUG - 2011-09-22 09:31:37 --> Config Class Initialized
DEBUG - 2011-09-22 09:31:37 --> Hooks Class Initialized
DEBUG - 2011-09-22 09:31:37 --> Utf8 Class Initialized
DEBUG - 2011-09-22 09:31:37 --> UTF-8 Support Enabled
DEBUG - 2011-09-22 09:31:37 --> URI Class Initialized
DEBUG - 2011-09-22 09:31:37 --> Router Class Initialized
DEBUG - 2011-09-22 09:31:37 --> Output Class Initialized
DEBUG - 2011-09-22 09:31:37 --> Input Class Initialized
DEBUG - 2011-09-22 09:31:37 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-22 09:31:37 --> Language Class Initialized
DEBUG - 2011-09-22 09:31:37 --> Loader Class Initialized
DEBUG - 2011-09-22 09:31:37 --> Controller Class Initialized
ERROR - 2011-09-22 09:31:37 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-22 09:31:37 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-22 09:31:37 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-22 09:31:37 --> Model Class Initialized
DEBUG - 2011-09-22 09:31:37 --> Model Class Initialized
DEBUG - 2011-09-22 09:31:37 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-22 09:31:37 --> Database Driver Class Initialized
DEBUG - 2011-09-22 09:31:37 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-22 09:31:37 --> Helper loaded: url_helper
DEBUG - 2011-09-22 09:31:37 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-22 09:31:37 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-22 09:31:37 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-22 09:31:37 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-22 09:31:37 --> Final output sent to browser
DEBUG - 2011-09-22 09:31:37 --> Total execution time: 0.0749
DEBUG - 2011-09-22 09:31:39 --> Config Class Initialized
DEBUG - 2011-09-22 09:31:39 --> Hooks Class Initialized
DEBUG - 2011-09-22 09:31:39 --> Utf8 Class Initialized
DEBUG - 2011-09-22 09:31:39 --> UTF-8 Support Enabled
DEBUG - 2011-09-22 09:31:39 --> URI Class Initialized
DEBUG - 2011-09-22 09:31:39 --> Router Class Initialized
DEBUG - 2011-09-22 09:31:39 --> Output Class Initialized
DEBUG - 2011-09-22 09:31:39 --> Input Class Initialized
DEBUG - 2011-09-22 09:31:39 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-22 09:31:39 --> Language Class Initialized
DEBUG - 2011-09-22 09:31:39 --> Loader Class Initialized
DEBUG - 2011-09-22 09:31:39 --> Controller Class Initialized
DEBUG - 2011-09-22 09:31:39 --> Model Class Initialized
DEBUG - 2011-09-22 09:31:39 --> Model Class Initialized
DEBUG - 2011-09-22 09:31:39 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-22 09:31:39 --> Database Driver Class Initialized
DEBUG - 2011-09-22 09:31:40 --> Final output sent to browser
DEBUG - 2011-09-22 09:31:40 --> Total execution time: 0.9823
DEBUG - 2011-09-22 09:31:43 --> Config Class Initialized
DEBUG - 2011-09-22 09:31:43 --> Hooks Class Initialized
DEBUG - 2011-09-22 09:31:43 --> Utf8 Class Initialized
DEBUG - 2011-09-22 09:31:43 --> UTF-8 Support Enabled
DEBUG - 2011-09-22 09:31:43 --> URI Class Initialized
DEBUG - 2011-09-22 09:31:43 --> Router Class Initialized
ERROR - 2011-09-22 09:31:43 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-22 09:40:07 --> Config Class Initialized
DEBUG - 2011-09-22 09:40:07 --> Hooks Class Initialized
DEBUG - 2011-09-22 09:40:07 --> Utf8 Class Initialized
DEBUG - 2011-09-22 09:40:07 --> UTF-8 Support Enabled
DEBUG - 2011-09-22 09:40:07 --> URI Class Initialized
DEBUG - 2011-09-22 09:40:07 --> Router Class Initialized
DEBUG - 2011-09-22 09:40:07 --> Output Class Initialized
DEBUG - 2011-09-22 09:40:07 --> Input Class Initialized
DEBUG - 2011-09-22 09:40:07 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-22 09:40:07 --> Language Class Initialized
DEBUG - 2011-09-22 09:40:07 --> Loader Class Initialized
DEBUG - 2011-09-22 09:40:07 --> Controller Class Initialized
ERROR - 2011-09-22 09:40:07 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-22 09:40:07 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-22 09:40:07 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-22 09:40:07 --> Model Class Initialized
DEBUG - 2011-09-22 09:40:07 --> Model Class Initialized
DEBUG - 2011-09-22 09:40:07 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-22 09:40:07 --> Database Driver Class Initialized
DEBUG - 2011-09-22 09:40:07 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-22 09:40:07 --> Helper loaded: url_helper
DEBUG - 2011-09-22 09:40:07 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-22 09:40:07 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-22 09:40:07 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-22 09:40:07 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-22 09:40:07 --> Final output sent to browser
DEBUG - 2011-09-22 09:40:07 --> Total execution time: 0.0423
DEBUG - 2011-09-22 09:40:09 --> Config Class Initialized
DEBUG - 2011-09-22 09:40:09 --> Hooks Class Initialized
DEBUG - 2011-09-22 09:40:09 --> Utf8 Class Initialized
DEBUG - 2011-09-22 09:40:09 --> UTF-8 Support Enabled
DEBUG - 2011-09-22 09:40:09 --> URI Class Initialized
DEBUG - 2011-09-22 09:40:09 --> Router Class Initialized
DEBUG - 2011-09-22 09:40:09 --> Output Class Initialized
DEBUG - 2011-09-22 09:40:09 --> Input Class Initialized
DEBUG - 2011-09-22 09:40:09 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-22 09:40:09 --> Language Class Initialized
DEBUG - 2011-09-22 09:40:09 --> Loader Class Initialized
DEBUG - 2011-09-22 09:40:09 --> Controller Class Initialized
DEBUG - 2011-09-22 09:40:09 --> Model Class Initialized
DEBUG - 2011-09-22 09:40:09 --> Model Class Initialized
DEBUG - 2011-09-22 09:40:09 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-22 09:40:09 --> Database Driver Class Initialized
DEBUG - 2011-09-22 09:40:09 --> Final output sent to browser
DEBUG - 2011-09-22 09:40:09 --> Total execution time: 0.7464
DEBUG - 2011-09-22 09:40:12 --> Config Class Initialized
DEBUG - 2011-09-22 09:40:12 --> Hooks Class Initialized
DEBUG - 2011-09-22 09:40:12 --> Utf8 Class Initialized
DEBUG - 2011-09-22 09:40:12 --> UTF-8 Support Enabled
DEBUG - 2011-09-22 09:40:12 --> URI Class Initialized
DEBUG - 2011-09-22 09:40:12 --> Router Class Initialized
ERROR - 2011-09-22 09:40:12 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-22 09:40:23 --> Config Class Initialized
DEBUG - 2011-09-22 09:40:23 --> Hooks Class Initialized
DEBUG - 2011-09-22 09:40:23 --> Utf8 Class Initialized
DEBUG - 2011-09-22 09:40:23 --> UTF-8 Support Enabled
DEBUG - 2011-09-22 09:40:23 --> URI Class Initialized
DEBUG - 2011-09-22 09:40:23 --> Router Class Initialized
DEBUG - 2011-09-22 09:40:23 --> Output Class Initialized
DEBUG - 2011-09-22 09:40:23 --> Input Class Initialized
DEBUG - 2011-09-22 09:40:23 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-22 09:40:23 --> Language Class Initialized
DEBUG - 2011-09-22 09:40:23 --> Loader Class Initialized
DEBUG - 2011-09-22 09:40:23 --> Controller Class Initialized
ERROR - 2011-09-22 09:40:23 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-22 09:40:23 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-22 09:40:23 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-22 09:40:23 --> Model Class Initialized
DEBUG - 2011-09-22 09:40:23 --> Model Class Initialized
DEBUG - 2011-09-22 09:40:23 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-22 09:40:23 --> Database Driver Class Initialized
DEBUG - 2011-09-22 09:40:23 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-22 09:40:23 --> Helper loaded: url_helper
DEBUG - 2011-09-22 09:40:23 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-22 09:40:23 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-22 09:40:23 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-22 09:40:23 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-22 09:40:23 --> Final output sent to browser
DEBUG - 2011-09-22 09:40:23 --> Total execution time: 0.1040
DEBUG - 2011-09-22 09:40:25 --> Config Class Initialized
DEBUG - 2011-09-22 09:40:25 --> Hooks Class Initialized
DEBUG - 2011-09-22 09:40:25 --> Utf8 Class Initialized
DEBUG - 2011-09-22 09:40:25 --> UTF-8 Support Enabled
DEBUG - 2011-09-22 09:40:25 --> URI Class Initialized
DEBUG - 2011-09-22 09:40:25 --> Router Class Initialized
DEBUG - 2011-09-22 09:40:25 --> Output Class Initialized
DEBUG - 2011-09-22 09:40:25 --> Input Class Initialized
DEBUG - 2011-09-22 09:40:25 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-22 09:40:25 --> Language Class Initialized
DEBUG - 2011-09-22 09:40:25 --> Loader Class Initialized
DEBUG - 2011-09-22 09:40:25 --> Controller Class Initialized
DEBUG - 2011-09-22 09:40:25 --> Model Class Initialized
DEBUG - 2011-09-22 09:40:25 --> Model Class Initialized
DEBUG - 2011-09-22 09:40:25 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-22 09:40:25 --> Database Driver Class Initialized
DEBUG - 2011-09-22 09:40:26 --> Final output sent to browser
DEBUG - 2011-09-22 09:40:26 --> Total execution time: 0.8058
DEBUG - 2011-09-22 09:40:26 --> Config Class Initialized
DEBUG - 2011-09-22 09:40:26 --> Hooks Class Initialized
DEBUG - 2011-09-22 09:40:26 --> Utf8 Class Initialized
DEBUG - 2011-09-22 09:40:26 --> UTF-8 Support Enabled
DEBUG - 2011-09-22 09:40:26 --> URI Class Initialized
DEBUG - 2011-09-22 09:40:26 --> Router Class Initialized
ERROR - 2011-09-22 09:40:26 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-09-22 09:40:27 --> Config Class Initialized
DEBUG - 2011-09-22 09:40:27 --> Hooks Class Initialized
DEBUG - 2011-09-22 09:40:27 --> Utf8 Class Initialized
DEBUG - 2011-09-22 09:40:27 --> UTF-8 Support Enabled
DEBUG - 2011-09-22 09:40:27 --> URI Class Initialized
DEBUG - 2011-09-22 09:40:27 --> Router Class Initialized
DEBUG - 2011-09-22 09:40:27 --> No URI present. Default controller set.
DEBUG - 2011-09-22 09:40:27 --> Output Class Initialized
DEBUG - 2011-09-22 09:40:27 --> Input Class Initialized
DEBUG - 2011-09-22 09:40:27 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-22 09:40:27 --> Language Class Initialized
DEBUG - 2011-09-22 09:40:27 --> Loader Class Initialized
DEBUG - 2011-09-22 09:40:27 --> Controller Class Initialized
DEBUG - 2011-09-22 09:40:27 --> File loaded: application/views/splash/main.php
DEBUG - 2011-09-22 09:40:27 --> Helper loaded: url_helper
DEBUG - 2011-09-22 09:40:27 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-22 09:40:27 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-22 09:40:27 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-22 09:40:27 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-22 09:40:27 --> Final output sent to browser
DEBUG - 2011-09-22 09:40:27 --> Total execution time: 0.0847
DEBUG - 2011-09-22 09:40:27 --> Config Class Initialized
DEBUG - 2011-09-22 09:40:27 --> Hooks Class Initialized
DEBUG - 2011-09-22 09:40:27 --> Utf8 Class Initialized
DEBUG - 2011-09-22 09:40:27 --> UTF-8 Support Enabled
DEBUG - 2011-09-22 09:40:27 --> URI Class Initialized
DEBUG - 2011-09-22 09:40:27 --> Router Class Initialized
ERROR - 2011-09-22 09:40:27 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-22 09:40:28 --> Config Class Initialized
DEBUG - 2011-09-22 09:40:28 --> Hooks Class Initialized
DEBUG - 2011-09-22 09:40:28 --> Utf8 Class Initialized
DEBUG - 2011-09-22 09:40:28 --> UTF-8 Support Enabled
DEBUG - 2011-09-22 09:40:28 --> URI Class Initialized
DEBUG - 2011-09-22 09:40:28 --> Router Class Initialized
DEBUG - 2011-09-22 09:40:28 --> Output Class Initialized
DEBUG - 2011-09-22 09:40:28 --> Input Class Initialized
DEBUG - 2011-09-22 09:40:28 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-22 09:40:28 --> Language Class Initialized
DEBUG - 2011-09-22 09:40:28 --> Loader Class Initialized
DEBUG - 2011-09-22 09:40:28 --> Controller Class Initialized
ERROR - 2011-09-22 09:40:28 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-22 09:40:28 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-22 09:40:28 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-22 09:40:28 --> Model Class Initialized
DEBUG - 2011-09-22 09:40:28 --> Model Class Initialized
DEBUG - 2011-09-22 09:40:28 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-22 09:40:28 --> Database Driver Class Initialized
DEBUG - 2011-09-22 09:40:28 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-22 09:40:28 --> Helper loaded: url_helper
DEBUG - 2011-09-22 09:40:28 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-22 09:40:28 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-22 09:40:28 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-22 09:40:28 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-22 09:40:28 --> Final output sent to browser
DEBUG - 2011-09-22 09:40:28 --> Total execution time: 0.0313
DEBUG - 2011-09-22 09:40:29 --> Config Class Initialized
DEBUG - 2011-09-22 09:40:29 --> Hooks Class Initialized
DEBUG - 2011-09-22 09:40:29 --> Utf8 Class Initialized
DEBUG - 2011-09-22 09:40:29 --> UTF-8 Support Enabled
DEBUG - 2011-09-22 09:40:29 --> URI Class Initialized
DEBUG - 2011-09-22 09:40:29 --> Router Class Initialized
DEBUG - 2011-09-22 09:40:29 --> Output Class Initialized
DEBUG - 2011-09-22 09:40:29 --> Input Class Initialized
DEBUG - 2011-09-22 09:40:29 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-22 09:40:29 --> Language Class Initialized
DEBUG - 2011-09-22 09:40:29 --> Loader Class Initialized
DEBUG - 2011-09-22 09:40:29 --> Controller Class Initialized
DEBUG - 2011-09-22 09:40:29 --> Model Class Initialized
DEBUG - 2011-09-22 09:40:29 --> Model Class Initialized
DEBUG - 2011-09-22 09:40:29 --> Model Class Initialized
DEBUG - 2011-09-22 09:40:29 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-22 09:40:29 --> Database Driver Class Initialized
DEBUG - 2011-09-22 09:40:29 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-22 09:40:29 --> Helper loaded: url_helper
DEBUG - 2011-09-22 09:40:29 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-22 09:40:29 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-22 09:40:29 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-22 09:40:29 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-22 09:40:29 --> Final output sent to browser
DEBUG - 2011-09-22 09:40:29 --> Total execution time: 0.5858
DEBUG - 2011-09-22 09:43:34 --> Config Class Initialized
DEBUG - 2011-09-22 09:43:34 --> Hooks Class Initialized
DEBUG - 2011-09-22 09:43:34 --> Utf8 Class Initialized
DEBUG - 2011-09-22 09:43:34 --> UTF-8 Support Enabled
DEBUG - 2011-09-22 09:43:34 --> URI Class Initialized
DEBUG - 2011-09-22 09:43:34 --> Router Class Initialized
DEBUG - 2011-09-22 09:43:34 --> No URI present. Default controller set.
DEBUG - 2011-09-22 09:43:34 --> Output Class Initialized
DEBUG - 2011-09-22 09:43:34 --> Input Class Initialized
DEBUG - 2011-09-22 09:43:34 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-22 09:43:34 --> Language Class Initialized
DEBUG - 2011-09-22 09:43:34 --> Loader Class Initialized
DEBUG - 2011-09-22 09:43:34 --> Controller Class Initialized
DEBUG - 2011-09-22 09:43:34 --> File loaded: application/views/splash/main.php
DEBUG - 2011-09-22 09:43:34 --> Helper loaded: url_helper
DEBUG - 2011-09-22 09:43:34 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-22 09:43:34 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-22 09:43:34 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-22 09:43:34 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-22 09:43:34 --> Final output sent to browser
DEBUG - 2011-09-22 09:43:34 --> Total execution time: 0.0171
DEBUG - 2011-09-22 09:52:17 --> Config Class Initialized
DEBUG - 2011-09-22 09:52:17 --> Hooks Class Initialized
DEBUG - 2011-09-22 09:52:17 --> Utf8 Class Initialized
DEBUG - 2011-09-22 09:52:17 --> UTF-8 Support Enabled
DEBUG - 2011-09-22 09:52:17 --> URI Class Initialized
DEBUG - 2011-09-22 09:52:17 --> Router Class Initialized
DEBUG - 2011-09-22 09:52:17 --> Output Class Initialized
DEBUG - 2011-09-22 09:52:17 --> Input Class Initialized
DEBUG - 2011-09-22 09:52:17 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-22 09:52:17 --> Language Class Initialized
DEBUG - 2011-09-22 09:52:17 --> Loader Class Initialized
DEBUG - 2011-09-22 09:52:17 --> Controller Class Initialized
ERROR - 2011-09-22 09:52:17 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-22 09:52:17 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-22 09:52:17 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-22 09:52:17 --> Model Class Initialized
DEBUG - 2011-09-22 09:52:17 --> Model Class Initialized
DEBUG - 2011-09-22 09:52:17 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-22 09:52:17 --> Database Driver Class Initialized
DEBUG - 2011-09-22 09:52:17 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-22 09:52:17 --> Helper loaded: url_helper
DEBUG - 2011-09-22 09:52:17 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-22 09:52:17 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-22 09:52:17 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-22 09:52:17 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-22 09:52:17 --> Final output sent to browser
DEBUG - 2011-09-22 09:52:17 --> Total execution time: 0.0350
DEBUG - 2011-09-22 09:56:43 --> Config Class Initialized
DEBUG - 2011-09-22 09:56:43 --> Hooks Class Initialized
DEBUG - 2011-09-22 09:56:43 --> Utf8 Class Initialized
DEBUG - 2011-09-22 09:56:43 --> UTF-8 Support Enabled
DEBUG - 2011-09-22 09:56:43 --> URI Class Initialized
DEBUG - 2011-09-22 09:56:43 --> Router Class Initialized
DEBUG - 2011-09-22 09:56:43 --> Output Class Initialized
DEBUG - 2011-09-22 09:56:43 --> Input Class Initialized
DEBUG - 2011-09-22 09:56:43 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-22 09:56:43 --> Language Class Initialized
DEBUG - 2011-09-22 09:56:43 --> Loader Class Initialized
DEBUG - 2011-09-22 09:56:43 --> Controller Class Initialized
DEBUG - 2011-09-22 09:56:43 --> Model Class Initialized
DEBUG - 2011-09-22 09:56:43 --> Model Class Initialized
DEBUG - 2011-09-22 09:56:43 --> Model Class Initialized
DEBUG - 2011-09-22 09:56:43 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-22 09:56:43 --> Database Driver Class Initialized
DEBUG - 2011-09-22 09:56:43 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-22 09:56:43 --> Helper loaded: url_helper
DEBUG - 2011-09-22 09:56:43 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-22 09:56:43 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-22 09:56:43 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-22 09:56:43 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-22 09:56:43 --> Final output sent to browser
DEBUG - 2011-09-22 09:56:43 --> Total execution time: 0.4961
DEBUG - 2011-09-22 10:04:23 --> Config Class Initialized
DEBUG - 2011-09-22 10:04:23 --> Hooks Class Initialized
DEBUG - 2011-09-22 10:04:23 --> Utf8 Class Initialized
DEBUG - 2011-09-22 10:04:23 --> UTF-8 Support Enabled
DEBUG - 2011-09-22 10:04:23 --> URI Class Initialized
DEBUG - 2011-09-22 10:04:23 --> Router Class Initialized
DEBUG - 2011-09-22 10:04:23 --> Output Class Initialized
DEBUG - 2011-09-22 10:04:23 --> Input Class Initialized
DEBUG - 2011-09-22 10:04:23 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-22 10:04:23 --> Language Class Initialized
DEBUG - 2011-09-22 10:04:23 --> Loader Class Initialized
DEBUG - 2011-09-22 10:04:23 --> Controller Class Initialized
ERROR - 2011-09-22 10:04:23 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-22 10:04:23 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-22 10:04:23 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-22 10:04:23 --> Model Class Initialized
DEBUG - 2011-09-22 10:04:23 --> Model Class Initialized
DEBUG - 2011-09-22 10:04:23 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-22 10:04:23 --> Database Driver Class Initialized
DEBUG - 2011-09-22 10:04:23 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-22 10:04:23 --> Helper loaded: url_helper
DEBUG - 2011-09-22 10:04:23 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-22 10:04:23 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-22 10:04:23 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-22 10:04:23 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-22 10:04:23 --> Final output sent to browser
DEBUG - 2011-09-22 10:04:23 --> Total execution time: 0.0664
DEBUG - 2011-09-22 10:04:24 --> Config Class Initialized
DEBUG - 2011-09-22 10:04:24 --> Hooks Class Initialized
DEBUG - 2011-09-22 10:04:24 --> Utf8 Class Initialized
DEBUG - 2011-09-22 10:04:24 --> UTF-8 Support Enabled
DEBUG - 2011-09-22 10:04:24 --> URI Class Initialized
DEBUG - 2011-09-22 10:04:24 --> Router Class Initialized
DEBUG - 2011-09-22 10:04:24 --> Output Class Initialized
DEBUG - 2011-09-22 10:04:24 --> Input Class Initialized
DEBUG - 2011-09-22 10:04:24 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-22 10:04:24 --> Language Class Initialized
DEBUG - 2011-09-22 10:04:24 --> Loader Class Initialized
DEBUG - 2011-09-22 10:04:24 --> Controller Class Initialized
DEBUG - 2011-09-22 10:04:24 --> Model Class Initialized
DEBUG - 2011-09-22 10:04:24 --> Model Class Initialized
DEBUG - 2011-09-22 10:04:24 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-22 10:04:24 --> Database Driver Class Initialized
DEBUG - 2011-09-22 10:04:24 --> Final output sent to browser
DEBUG - 2011-09-22 10:04:24 --> Total execution time: 0.7830
DEBUG - 2011-09-22 10:04:25 --> Config Class Initialized
DEBUG - 2011-09-22 10:04:25 --> Hooks Class Initialized
DEBUG - 2011-09-22 10:04:25 --> Utf8 Class Initialized
DEBUG - 2011-09-22 10:04:25 --> UTF-8 Support Enabled
DEBUG - 2011-09-22 10:04:25 --> URI Class Initialized
DEBUG - 2011-09-22 10:04:25 --> Router Class Initialized
ERROR - 2011-09-22 10:04:25 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-22 10:04:27 --> Config Class Initialized
DEBUG - 2011-09-22 10:04:27 --> Hooks Class Initialized
DEBUG - 2011-09-22 10:04:27 --> Utf8 Class Initialized
DEBUG - 2011-09-22 10:04:27 --> UTF-8 Support Enabled
DEBUG - 2011-09-22 10:04:27 --> URI Class Initialized
DEBUG - 2011-09-22 10:04:27 --> Router Class Initialized
ERROR - 2011-09-22 10:04:27 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-22 10:04:40 --> Config Class Initialized
DEBUG - 2011-09-22 10:04:40 --> Hooks Class Initialized
DEBUG - 2011-09-22 10:04:40 --> Utf8 Class Initialized
DEBUG - 2011-09-22 10:04:40 --> UTF-8 Support Enabled
DEBUG - 2011-09-22 10:04:40 --> URI Class Initialized
DEBUG - 2011-09-22 10:04:40 --> Router Class Initialized
DEBUG - 2011-09-22 10:04:40 --> Output Class Initialized
DEBUG - 2011-09-22 10:04:40 --> Input Class Initialized
DEBUG - 2011-09-22 10:04:40 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-22 10:04:40 --> Language Class Initialized
DEBUG - 2011-09-22 10:04:40 --> Loader Class Initialized
DEBUG - 2011-09-22 10:04:40 --> Controller Class Initialized
ERROR - 2011-09-22 10:04:40 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-22 10:04:40 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-22 10:04:40 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-22 10:04:40 --> Model Class Initialized
DEBUG - 2011-09-22 10:04:40 --> Model Class Initialized
DEBUG - 2011-09-22 10:04:40 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-22 10:04:40 --> Database Driver Class Initialized
DEBUG - 2011-09-22 10:04:40 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-22 10:04:40 --> Helper loaded: url_helper
DEBUG - 2011-09-22 10:04:40 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-22 10:04:40 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-22 10:04:40 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-22 10:04:40 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-22 10:04:40 --> Final output sent to browser
DEBUG - 2011-09-22 10:04:40 --> Total execution time: 0.0330
DEBUG - 2011-09-22 10:04:41 --> Config Class Initialized
DEBUG - 2011-09-22 10:04:41 --> Hooks Class Initialized
DEBUG - 2011-09-22 10:04:41 --> Utf8 Class Initialized
DEBUG - 2011-09-22 10:04:41 --> UTF-8 Support Enabled
DEBUG - 2011-09-22 10:04:41 --> URI Class Initialized
DEBUG - 2011-09-22 10:04:41 --> Router Class Initialized
DEBUG - 2011-09-22 10:04:41 --> Output Class Initialized
DEBUG - 2011-09-22 10:04:41 --> Input Class Initialized
DEBUG - 2011-09-22 10:04:41 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-22 10:04:41 --> Language Class Initialized
DEBUG - 2011-09-22 10:04:41 --> Loader Class Initialized
DEBUG - 2011-09-22 10:04:41 --> Controller Class Initialized
DEBUG - 2011-09-22 10:04:41 --> Model Class Initialized
DEBUG - 2011-09-22 10:04:41 --> Model Class Initialized
DEBUG - 2011-09-22 10:04:41 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-22 10:04:41 --> Database Driver Class Initialized
DEBUG - 2011-09-22 10:04:42 --> Final output sent to browser
DEBUG - 2011-09-22 10:04:42 --> Total execution time: 0.7910
DEBUG - 2011-09-22 10:59:50 --> Config Class Initialized
DEBUG - 2011-09-22 10:59:50 --> Hooks Class Initialized
DEBUG - 2011-09-22 10:59:50 --> Utf8 Class Initialized
DEBUG - 2011-09-22 10:59:50 --> UTF-8 Support Enabled
DEBUG - 2011-09-22 10:59:50 --> URI Class Initialized
DEBUG - 2011-09-22 10:59:50 --> Router Class Initialized
ERROR - 2011-09-22 10:59:50 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-09-22 10:59:50 --> Config Class Initialized
DEBUG - 2011-09-22 10:59:50 --> Hooks Class Initialized
DEBUG - 2011-09-22 10:59:51 --> Utf8 Class Initialized
DEBUG - 2011-09-22 10:59:51 --> UTF-8 Support Enabled
DEBUG - 2011-09-22 10:59:51 --> URI Class Initialized
DEBUG - 2011-09-22 10:59:51 --> Router Class Initialized
DEBUG - 2011-09-22 10:59:51 --> Output Class Initialized
DEBUG - 2011-09-22 10:59:51 --> Input Class Initialized
DEBUG - 2011-09-22 10:59:51 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-22 10:59:51 --> Language Class Initialized
DEBUG - 2011-09-22 10:59:51 --> Loader Class Initialized
DEBUG - 2011-09-22 10:59:51 --> Controller Class Initialized
DEBUG - 2011-09-22 10:59:51 --> Model Class Initialized
DEBUG - 2011-09-22 10:59:51 --> Model Class Initialized
DEBUG - 2011-09-22 10:59:51 --> Model Class Initialized
DEBUG - 2011-09-22 10:59:51 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-22 10:59:51 --> Database Driver Class Initialized
DEBUG - 2011-09-22 10:59:52 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-22 10:59:52 --> Helper loaded: url_helper
DEBUG - 2011-09-22 10:59:52 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-22 10:59:52 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-22 10:59:52 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-22 10:59:52 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-22 10:59:52 --> Final output sent to browser
DEBUG - 2011-09-22 10:59:52 --> Total execution time: 1.4827
DEBUG - 2011-09-22 11:23:54 --> Config Class Initialized
DEBUG - 2011-09-22 11:23:54 --> Hooks Class Initialized
DEBUG - 2011-09-22 11:23:54 --> Utf8 Class Initialized
DEBUG - 2011-09-22 11:23:54 --> UTF-8 Support Enabled
DEBUG - 2011-09-22 11:23:54 --> URI Class Initialized
DEBUG - 2011-09-22 11:23:54 --> Router Class Initialized
DEBUG - 2011-09-22 11:23:54 --> Output Class Initialized
DEBUG - 2011-09-22 11:23:54 --> Input Class Initialized
DEBUG - 2011-09-22 11:23:54 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-22 11:23:54 --> Language Class Initialized
DEBUG - 2011-09-22 11:23:54 --> Loader Class Initialized
DEBUG - 2011-09-22 11:23:54 --> Controller Class Initialized
DEBUG - 2011-09-22 11:23:54 --> Model Class Initialized
DEBUG - 2011-09-22 11:23:54 --> Model Class Initialized
DEBUG - 2011-09-22 11:23:54 --> Model Class Initialized
DEBUG - 2011-09-22 11:23:54 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-22 11:23:54 --> Database Driver Class Initialized
DEBUG - 2011-09-22 11:23:55 --> Config Class Initialized
DEBUG - 2011-09-22 11:23:55 --> Hooks Class Initialized
DEBUG - 2011-09-22 11:23:55 --> Utf8 Class Initialized
DEBUG - 2011-09-22 11:23:55 --> UTF-8 Support Enabled
DEBUG - 2011-09-22 11:23:55 --> URI Class Initialized
DEBUG - 2011-09-22 11:23:55 --> Router Class Initialized
DEBUG - 2011-09-22 11:23:55 --> Output Class Initialized
DEBUG - 2011-09-22 11:23:55 --> Input Class Initialized
DEBUG - 2011-09-22 11:23:55 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-22 11:23:55 --> Language Class Initialized
DEBUG - 2011-09-22 11:23:55 --> Loader Class Initialized
DEBUG - 2011-09-22 11:23:55 --> Controller Class Initialized
ERROR - 2011-09-22 11:23:55 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-22 11:23:55 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-22 11:23:55 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-22 11:23:55 --> Model Class Initialized
DEBUG - 2011-09-22 11:23:55 --> Model Class Initialized
DEBUG - 2011-09-22 11:23:55 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-22 11:23:55 --> Database Driver Class Initialized
DEBUG - 2011-09-22 11:23:55 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-22 11:23:55 --> Helper loaded: url_helper
DEBUG - 2011-09-22 11:23:55 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-22 11:23:55 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-22 11:23:55 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-22 11:23:55 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-22 11:23:55 --> Final output sent to browser
DEBUG - 2011-09-22 11:23:55 --> Total execution time: 0.0992
DEBUG - 2011-09-22 11:23:55 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-22 11:23:55 --> Helper loaded: url_helper
DEBUG - 2011-09-22 11:23:55 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-22 11:23:55 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-22 11:23:55 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-22 11:23:55 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-22 11:23:55 --> Final output sent to browser
DEBUG - 2011-09-22 11:23:55 --> Total execution time: 1.0031
DEBUG - 2011-09-22 11:24:12 --> Config Class Initialized
DEBUG - 2011-09-22 11:24:12 --> Hooks Class Initialized
DEBUG - 2011-09-22 11:24:12 --> Utf8 Class Initialized
DEBUG - 2011-09-22 11:24:12 --> UTF-8 Support Enabled
DEBUG - 2011-09-22 11:24:12 --> URI Class Initialized
DEBUG - 2011-09-22 11:24:12 --> Router Class Initialized
DEBUG - 2011-09-22 11:24:12 --> Output Class Initialized
DEBUG - 2011-09-22 11:24:12 --> Input Class Initialized
DEBUG - 2011-09-22 11:24:12 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-22 11:24:12 --> Language Class Initialized
DEBUG - 2011-09-22 11:24:12 --> Loader Class Initialized
DEBUG - 2011-09-22 11:24:12 --> Controller Class Initialized
DEBUG - 2011-09-22 11:24:12 --> Model Class Initialized
DEBUG - 2011-09-22 11:24:12 --> Model Class Initialized
DEBUG - 2011-09-22 11:24:12 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-22 11:24:12 --> Database Driver Class Initialized
DEBUG - 2011-09-22 11:24:13 --> Final output sent to browser
DEBUG - 2011-09-22 11:24:13 --> Total execution time: 0.6297
DEBUG - 2011-09-22 11:24:21 --> Config Class Initialized
DEBUG - 2011-09-22 11:24:21 --> Hooks Class Initialized
DEBUG - 2011-09-22 11:24:21 --> Utf8 Class Initialized
DEBUG - 2011-09-22 11:24:21 --> UTF-8 Support Enabled
DEBUG - 2011-09-22 11:24:21 --> URI Class Initialized
DEBUG - 2011-09-22 11:24:21 --> Router Class Initialized
ERROR - 2011-09-22 11:24:21 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-22 11:24:47 --> Config Class Initialized
DEBUG - 2011-09-22 11:24:47 --> Hooks Class Initialized
DEBUG - 2011-09-22 11:24:47 --> Utf8 Class Initialized
DEBUG - 2011-09-22 11:24:47 --> UTF-8 Support Enabled
DEBUG - 2011-09-22 11:24:47 --> URI Class Initialized
DEBUG - 2011-09-22 11:24:47 --> Router Class Initialized
DEBUG - 2011-09-22 11:24:47 --> Output Class Initialized
DEBUG - 2011-09-22 11:24:47 --> Input Class Initialized
DEBUG - 2011-09-22 11:24:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-22 11:24:47 --> Language Class Initialized
DEBUG - 2011-09-22 11:24:47 --> Loader Class Initialized
DEBUG - 2011-09-22 11:24:47 --> Controller Class Initialized
ERROR - 2011-09-22 11:24:47 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-22 11:24:47 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-22 11:24:47 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-22 11:24:47 --> Model Class Initialized
DEBUG - 2011-09-22 11:24:47 --> Model Class Initialized
DEBUG - 2011-09-22 11:24:47 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-22 11:24:47 --> Database Driver Class Initialized
DEBUG - 2011-09-22 11:24:47 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-22 11:24:47 --> Helper loaded: url_helper
DEBUG - 2011-09-22 11:24:47 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-22 11:24:47 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-22 11:24:47 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-22 11:24:47 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-22 11:24:47 --> Final output sent to browser
DEBUG - 2011-09-22 11:24:47 --> Total execution time: 0.0382
DEBUG - 2011-09-22 11:24:49 --> Config Class Initialized
DEBUG - 2011-09-22 11:24:49 --> Hooks Class Initialized
DEBUG - 2011-09-22 11:24:49 --> Utf8 Class Initialized
DEBUG - 2011-09-22 11:24:49 --> UTF-8 Support Enabled
DEBUG - 2011-09-22 11:24:49 --> URI Class Initialized
DEBUG - 2011-09-22 11:24:49 --> Router Class Initialized
DEBUG - 2011-09-22 11:24:49 --> Output Class Initialized
DEBUG - 2011-09-22 11:24:49 --> Input Class Initialized
DEBUG - 2011-09-22 11:24:49 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-22 11:24:49 --> Language Class Initialized
DEBUG - 2011-09-22 11:24:49 --> Loader Class Initialized
DEBUG - 2011-09-22 11:24:49 --> Controller Class Initialized
DEBUG - 2011-09-22 11:24:49 --> Model Class Initialized
DEBUG - 2011-09-22 11:24:49 --> Model Class Initialized
DEBUG - 2011-09-22 11:24:49 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-22 11:24:49 --> Database Driver Class Initialized
DEBUG - 2011-09-22 11:24:49 --> Final output sent to browser
DEBUG - 2011-09-22 11:24:49 --> Total execution time: 0.7165
DEBUG - 2011-09-22 11:24:51 --> Config Class Initialized
DEBUG - 2011-09-22 11:24:51 --> Hooks Class Initialized
DEBUG - 2011-09-22 11:24:51 --> Utf8 Class Initialized
DEBUG - 2011-09-22 11:24:51 --> UTF-8 Support Enabled
DEBUG - 2011-09-22 11:24:51 --> URI Class Initialized
DEBUG - 2011-09-22 11:24:51 --> Router Class Initialized
ERROR - 2011-09-22 11:24:51 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-22 12:40:48 --> Config Class Initialized
DEBUG - 2011-09-22 12:40:48 --> Hooks Class Initialized
DEBUG - 2011-09-22 12:40:48 --> Utf8 Class Initialized
DEBUG - 2011-09-22 12:40:48 --> UTF-8 Support Enabled
DEBUG - 2011-09-22 12:40:48 --> URI Class Initialized
DEBUG - 2011-09-22 12:40:48 --> Router Class Initialized
DEBUG - 2011-09-22 12:40:48 --> Output Class Initialized
DEBUG - 2011-09-22 12:40:48 --> Input Class Initialized
DEBUG - 2011-09-22 12:40:48 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-22 12:40:48 --> Language Class Initialized
DEBUG - 2011-09-22 12:40:48 --> Loader Class Initialized
DEBUG - 2011-09-22 12:40:48 --> Controller Class Initialized
DEBUG - 2011-09-22 12:40:48 --> Model Class Initialized
DEBUG - 2011-09-22 12:40:48 --> Model Class Initialized
DEBUG - 2011-09-22 12:40:48 --> Model Class Initialized
DEBUG - 2011-09-22 12:40:48 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-22 12:40:48 --> Database Driver Class Initialized
DEBUG - 2011-09-22 12:40:49 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-22 12:40:49 --> Helper loaded: url_helper
DEBUG - 2011-09-22 12:40:49 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-22 12:40:49 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-22 12:40:49 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-22 12:40:49 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-22 12:40:49 --> Final output sent to browser
DEBUG - 2011-09-22 12:40:49 --> Total execution time: 0.8853
DEBUG - 2011-09-22 12:40:50 --> Config Class Initialized
DEBUG - 2011-09-22 12:40:50 --> Hooks Class Initialized
DEBUG - 2011-09-22 12:40:50 --> Utf8 Class Initialized
DEBUG - 2011-09-22 12:40:50 --> UTF-8 Support Enabled
DEBUG - 2011-09-22 12:40:50 --> URI Class Initialized
DEBUG - 2011-09-22 12:40:50 --> Router Class Initialized
ERROR - 2011-09-22 12:40:50 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-22 12:42:53 --> Config Class Initialized
DEBUG - 2011-09-22 12:42:53 --> Hooks Class Initialized
DEBUG - 2011-09-22 12:42:53 --> Utf8 Class Initialized
DEBUG - 2011-09-22 12:42:53 --> UTF-8 Support Enabled
DEBUG - 2011-09-22 12:42:53 --> URI Class Initialized
DEBUG - 2011-09-22 12:42:53 --> Router Class Initialized
DEBUG - 2011-09-22 12:42:53 --> Output Class Initialized
DEBUG - 2011-09-22 12:42:53 --> Input Class Initialized
DEBUG - 2011-09-22 12:42:53 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-22 12:42:53 --> Language Class Initialized
DEBUG - 2011-09-22 12:42:53 --> Loader Class Initialized
DEBUG - 2011-09-22 12:42:53 --> Controller Class Initialized
DEBUG - 2011-09-22 12:42:53 --> Model Class Initialized
DEBUG - 2011-09-22 12:42:53 --> Model Class Initialized
DEBUG - 2011-09-22 12:42:53 --> Model Class Initialized
DEBUG - 2011-09-22 12:42:53 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-22 12:42:53 --> Database Driver Class Initialized
DEBUG - 2011-09-22 12:42:53 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-22 12:42:53 --> Helper loaded: url_helper
DEBUG - 2011-09-22 12:42:53 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-22 12:42:53 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-22 12:42:53 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-22 12:42:53 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-22 12:42:53 --> Final output sent to browser
DEBUG - 2011-09-22 12:42:53 --> Total execution time: 0.1436
DEBUG - 2011-09-22 12:43:29 --> Config Class Initialized
DEBUG - 2011-09-22 12:43:29 --> Hooks Class Initialized
DEBUG - 2011-09-22 12:43:29 --> Utf8 Class Initialized
DEBUG - 2011-09-22 12:43:29 --> UTF-8 Support Enabled
DEBUG - 2011-09-22 12:43:29 --> URI Class Initialized
DEBUG - 2011-09-22 12:43:29 --> Router Class Initialized
DEBUG - 2011-09-22 12:43:29 --> Output Class Initialized
DEBUG - 2011-09-22 12:43:29 --> Input Class Initialized
DEBUG - 2011-09-22 12:43:29 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-22 12:43:29 --> Language Class Initialized
DEBUG - 2011-09-22 12:43:29 --> Loader Class Initialized
DEBUG - 2011-09-22 12:43:29 --> Controller Class Initialized
ERROR - 2011-09-22 12:43:29 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-22 12:43:29 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-22 12:43:29 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-22 12:43:29 --> Model Class Initialized
DEBUG - 2011-09-22 12:43:29 --> Model Class Initialized
DEBUG - 2011-09-22 12:43:29 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-22 12:43:29 --> Database Driver Class Initialized
DEBUG - 2011-09-22 12:43:29 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-22 12:43:29 --> Helper loaded: url_helper
DEBUG - 2011-09-22 12:43:29 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-22 12:43:29 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-22 12:43:29 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-22 12:43:29 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-22 12:43:29 --> Final output sent to browser
DEBUG - 2011-09-22 12:43:29 --> Total execution time: 0.0534
DEBUG - 2011-09-22 12:43:32 --> Config Class Initialized
DEBUG - 2011-09-22 12:43:32 --> Hooks Class Initialized
DEBUG - 2011-09-22 12:43:32 --> Utf8 Class Initialized
DEBUG - 2011-09-22 12:43:32 --> UTF-8 Support Enabled
DEBUG - 2011-09-22 12:43:32 --> URI Class Initialized
DEBUG - 2011-09-22 12:43:32 --> Router Class Initialized
DEBUG - 2011-09-22 12:43:32 --> Output Class Initialized
DEBUG - 2011-09-22 12:43:32 --> Input Class Initialized
DEBUG - 2011-09-22 12:43:32 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-22 12:43:32 --> Language Class Initialized
DEBUG - 2011-09-22 12:43:32 --> Loader Class Initialized
DEBUG - 2011-09-22 12:43:32 --> Controller Class Initialized
DEBUG - 2011-09-22 12:43:32 --> Model Class Initialized
DEBUG - 2011-09-22 12:43:32 --> Model Class Initialized
DEBUG - 2011-09-22 12:43:32 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-22 12:43:32 --> Database Driver Class Initialized
DEBUG - 2011-09-22 12:43:32 --> Final output sent to browser
DEBUG - 2011-09-22 12:43:32 --> Total execution time: 0.5946
DEBUG - 2011-09-22 12:44:01 --> Config Class Initialized
DEBUG - 2011-09-22 12:44:01 --> Hooks Class Initialized
DEBUG - 2011-09-22 12:44:01 --> Utf8 Class Initialized
DEBUG - 2011-09-22 12:44:01 --> UTF-8 Support Enabled
DEBUG - 2011-09-22 12:44:01 --> URI Class Initialized
DEBUG - 2011-09-22 12:44:01 --> Router Class Initialized
DEBUG - 2011-09-22 12:44:01 --> Output Class Initialized
DEBUG - 2011-09-22 12:44:01 --> Input Class Initialized
DEBUG - 2011-09-22 12:44:01 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-22 12:44:01 --> Language Class Initialized
DEBUG - 2011-09-22 12:44:01 --> Loader Class Initialized
DEBUG - 2011-09-22 12:44:01 --> Controller Class Initialized
ERROR - 2011-09-22 12:44:01 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-22 12:44:01 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-22 12:44:01 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-22 12:44:01 --> Model Class Initialized
DEBUG - 2011-09-22 12:44:01 --> Model Class Initialized
DEBUG - 2011-09-22 12:44:01 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-22 12:44:01 --> Database Driver Class Initialized
DEBUG - 2011-09-22 12:44:01 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-22 12:44:01 --> Helper loaded: url_helper
DEBUG - 2011-09-22 12:44:01 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-22 12:44:01 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-22 12:44:01 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-22 12:44:01 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-22 12:44:01 --> Final output sent to browser
DEBUG - 2011-09-22 12:44:01 --> Total execution time: 0.0375
DEBUG - 2011-09-22 12:44:02 --> Config Class Initialized
DEBUG - 2011-09-22 12:44:02 --> Hooks Class Initialized
DEBUG - 2011-09-22 12:44:02 --> Utf8 Class Initialized
DEBUG - 2011-09-22 12:44:02 --> UTF-8 Support Enabled
DEBUG - 2011-09-22 12:44:02 --> URI Class Initialized
DEBUG - 2011-09-22 12:44:02 --> Router Class Initialized
DEBUG - 2011-09-22 12:44:02 --> Output Class Initialized
DEBUG - 2011-09-22 12:44:02 --> Input Class Initialized
DEBUG - 2011-09-22 12:44:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-22 12:44:02 --> Language Class Initialized
DEBUG - 2011-09-22 12:44:02 --> Loader Class Initialized
DEBUG - 2011-09-22 12:44:02 --> Controller Class Initialized
DEBUG - 2011-09-22 12:44:02 --> Model Class Initialized
DEBUG - 2011-09-22 12:44:02 --> Model Class Initialized
DEBUG - 2011-09-22 12:44:02 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-22 12:44:02 --> Database Driver Class Initialized
DEBUG - 2011-09-22 12:44:03 --> Final output sent to browser
DEBUG - 2011-09-22 12:44:03 --> Total execution time: 0.6665
DEBUG - 2011-09-22 12:57:09 --> Config Class Initialized
DEBUG - 2011-09-22 12:57:09 --> Hooks Class Initialized
DEBUG - 2011-09-22 12:57:09 --> Utf8 Class Initialized
DEBUG - 2011-09-22 12:57:09 --> UTF-8 Support Enabled
DEBUG - 2011-09-22 12:57:09 --> URI Class Initialized
DEBUG - 2011-09-22 12:57:09 --> Router Class Initialized
DEBUG - 2011-09-22 12:57:09 --> Output Class Initialized
DEBUG - 2011-09-22 12:57:09 --> Input Class Initialized
DEBUG - 2011-09-22 12:57:09 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-22 12:57:09 --> Language Class Initialized
DEBUG - 2011-09-22 12:57:09 --> Loader Class Initialized
DEBUG - 2011-09-22 12:57:09 --> Controller Class Initialized
DEBUG - 2011-09-22 12:57:09 --> Model Class Initialized
DEBUG - 2011-09-22 12:57:09 --> Model Class Initialized
DEBUG - 2011-09-22 12:57:09 --> Model Class Initialized
DEBUG - 2011-09-22 12:57:09 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-22 12:57:09 --> Database Driver Class Initialized
DEBUG - 2011-09-22 12:57:09 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-22 12:57:09 --> Helper loaded: url_helper
DEBUG - 2011-09-22 12:57:09 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-22 12:57:09 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-22 12:57:09 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-22 12:57:09 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-22 12:57:09 --> Final output sent to browser
DEBUG - 2011-09-22 12:57:09 --> Total execution time: 0.0702
DEBUG - 2011-09-22 12:57:11 --> Config Class Initialized
DEBUG - 2011-09-22 12:57:11 --> Hooks Class Initialized
DEBUG - 2011-09-22 12:57:11 --> Utf8 Class Initialized
DEBUG - 2011-09-22 12:57:11 --> UTF-8 Support Enabled
DEBUG - 2011-09-22 12:57:11 --> URI Class Initialized
DEBUG - 2011-09-22 12:57:11 --> Router Class Initialized
DEBUG - 2011-09-22 12:57:11 --> Output Class Initialized
DEBUG - 2011-09-22 12:57:11 --> Input Class Initialized
DEBUG - 2011-09-22 12:57:11 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-22 12:57:11 --> Language Class Initialized
DEBUG - 2011-09-22 12:57:11 --> Loader Class Initialized
DEBUG - 2011-09-22 12:57:11 --> Controller Class Initialized
ERROR - 2011-09-22 12:57:11 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-22 12:57:11 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-22 12:57:11 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-22 12:57:11 --> Model Class Initialized
DEBUG - 2011-09-22 12:57:11 --> Model Class Initialized
DEBUG - 2011-09-22 12:57:11 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-22 12:57:11 --> Database Driver Class Initialized
DEBUG - 2011-09-22 12:57:11 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-22 12:57:11 --> Helper loaded: url_helper
DEBUG - 2011-09-22 12:57:11 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-22 12:57:11 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-22 12:57:11 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-22 12:57:11 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-22 12:57:11 --> Final output sent to browser
DEBUG - 2011-09-22 12:57:11 --> Total execution time: 0.0791
DEBUG - 2011-09-22 13:22:47 --> Config Class Initialized
DEBUG - 2011-09-22 13:22:47 --> Hooks Class Initialized
DEBUG - 2011-09-22 13:22:47 --> Utf8 Class Initialized
DEBUG - 2011-09-22 13:22:47 --> UTF-8 Support Enabled
DEBUG - 2011-09-22 13:22:47 --> URI Class Initialized
DEBUG - 2011-09-22 13:22:47 --> Router Class Initialized
ERROR - 2011-09-22 13:22:47 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-09-22 13:22:48 --> Config Class Initialized
DEBUG - 2011-09-22 13:22:48 --> Hooks Class Initialized
DEBUG - 2011-09-22 13:22:48 --> Utf8 Class Initialized
DEBUG - 2011-09-22 13:22:48 --> UTF-8 Support Enabled
DEBUG - 2011-09-22 13:22:48 --> URI Class Initialized
DEBUG - 2011-09-22 13:22:48 --> Router Class Initialized
DEBUG - 2011-09-22 13:22:48 --> Output Class Initialized
DEBUG - 2011-09-22 13:22:48 --> Input Class Initialized
DEBUG - 2011-09-22 13:22:48 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-22 13:22:48 --> Language Class Initialized
DEBUG - 2011-09-22 13:22:48 --> Loader Class Initialized
DEBUG - 2011-09-22 13:22:48 --> Controller Class Initialized
ERROR - 2011-09-22 13:22:48 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-22 13:22:48 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-22 13:22:48 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-22 13:22:48 --> Model Class Initialized
DEBUG - 2011-09-22 13:22:48 --> Model Class Initialized
DEBUG - 2011-09-22 13:22:48 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-22 13:22:48 --> Database Driver Class Initialized
DEBUG - 2011-09-22 13:22:48 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-22 13:22:48 --> Helper loaded: url_helper
DEBUG - 2011-09-22 13:22:48 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-22 13:22:48 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-22 13:22:48 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-22 13:22:48 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-22 13:22:48 --> Final output sent to browser
DEBUG - 2011-09-22 13:22:48 --> Total execution time: 0.3361
DEBUG - 2011-09-22 13:26:20 --> Config Class Initialized
DEBUG - 2011-09-22 13:26:20 --> Hooks Class Initialized
DEBUG - 2011-09-22 13:26:20 --> Utf8 Class Initialized
DEBUG - 2011-09-22 13:26:20 --> UTF-8 Support Enabled
DEBUG - 2011-09-22 13:26:20 --> URI Class Initialized
DEBUG - 2011-09-22 13:26:20 --> Router Class Initialized
DEBUG - 2011-09-22 13:26:20 --> Output Class Initialized
DEBUG - 2011-09-22 13:26:20 --> Input Class Initialized
DEBUG - 2011-09-22 13:26:20 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-22 13:26:20 --> Language Class Initialized
DEBUG - 2011-09-22 13:26:20 --> Loader Class Initialized
DEBUG - 2011-09-22 13:26:20 --> Controller Class Initialized
DEBUG - 2011-09-22 13:26:20 --> Model Class Initialized
DEBUG - 2011-09-22 13:26:20 --> Model Class Initialized
DEBUG - 2011-09-22 13:26:20 --> Model Class Initialized
DEBUG - 2011-09-22 13:26:20 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-22 13:26:20 --> Database Driver Class Initialized
DEBUG - 2011-09-22 13:26:22 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-22 13:26:22 --> Helper loaded: url_helper
DEBUG - 2011-09-22 13:26:22 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-22 13:26:22 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-22 13:26:22 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-22 13:26:22 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-22 13:26:22 --> Final output sent to browser
DEBUG - 2011-09-22 13:26:22 --> Total execution time: 1.9094
DEBUG - 2011-09-22 13:27:05 --> Config Class Initialized
DEBUG - 2011-09-22 13:27:05 --> Hooks Class Initialized
DEBUG - 2011-09-22 13:27:05 --> Utf8 Class Initialized
DEBUG - 2011-09-22 13:27:05 --> UTF-8 Support Enabled
DEBUG - 2011-09-22 13:27:05 --> URI Class Initialized
DEBUG - 2011-09-22 13:27:05 --> Router Class Initialized
DEBUG - 2011-09-22 13:27:05 --> Output Class Initialized
DEBUG - 2011-09-22 13:27:05 --> Input Class Initialized
DEBUG - 2011-09-22 13:27:05 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-22 13:27:05 --> Language Class Initialized
DEBUG - 2011-09-22 13:27:05 --> Loader Class Initialized
DEBUG - 2011-09-22 13:27:05 --> Controller Class Initialized
DEBUG - 2011-09-22 13:27:05 --> Model Class Initialized
DEBUG - 2011-09-22 13:27:05 --> Model Class Initialized
DEBUG - 2011-09-22 13:27:05 --> Model Class Initialized
DEBUG - 2011-09-22 13:27:05 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-22 13:27:05 --> Database Driver Class Initialized
DEBUG - 2011-09-22 13:27:05 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-22 13:27:05 --> Helper loaded: url_helper
DEBUG - 2011-09-22 13:27:05 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-22 13:27:05 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-22 13:27:05 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-22 13:27:05 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-22 13:27:05 --> Final output sent to browser
DEBUG - 2011-09-22 13:27:05 --> Total execution time: 0.5087
DEBUG - 2011-09-22 13:27:12 --> Config Class Initialized
DEBUG - 2011-09-22 13:27:12 --> Hooks Class Initialized
DEBUG - 2011-09-22 13:27:12 --> Utf8 Class Initialized
DEBUG - 2011-09-22 13:27:12 --> UTF-8 Support Enabled
DEBUG - 2011-09-22 13:27:12 --> URI Class Initialized
DEBUG - 2011-09-22 13:27:12 --> Router Class Initialized
DEBUG - 2011-09-22 13:27:12 --> Output Class Initialized
DEBUG - 2011-09-22 13:27:12 --> Input Class Initialized
DEBUG - 2011-09-22 13:27:12 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-22 13:27:12 --> Language Class Initialized
DEBUG - 2011-09-22 13:27:12 --> Loader Class Initialized
DEBUG - 2011-09-22 13:27:12 --> Controller Class Initialized
DEBUG - 2011-09-22 13:27:12 --> Model Class Initialized
DEBUG - 2011-09-22 13:27:12 --> Model Class Initialized
DEBUG - 2011-09-22 13:27:12 --> Model Class Initialized
DEBUG - 2011-09-22 13:27:12 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-22 13:27:12 --> Database Driver Class Initialized
DEBUG - 2011-09-22 13:27:13 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-22 13:27:13 --> Helper loaded: url_helper
DEBUG - 2011-09-22 13:27:13 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-22 13:27:13 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-22 13:27:13 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-22 13:27:13 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-22 13:27:13 --> Final output sent to browser
DEBUG - 2011-09-22 13:27:13 --> Total execution time: 0.5975
DEBUG - 2011-09-22 13:27:13 --> Config Class Initialized
DEBUG - 2011-09-22 13:27:13 --> Hooks Class Initialized
DEBUG - 2011-09-22 13:27:13 --> Utf8 Class Initialized
DEBUG - 2011-09-22 13:27:13 --> UTF-8 Support Enabled
DEBUG - 2011-09-22 13:27:13 --> URI Class Initialized
DEBUG - 2011-09-22 13:27:13 --> Router Class Initialized
DEBUG - 2011-09-22 13:27:13 --> Output Class Initialized
DEBUG - 2011-09-22 13:27:13 --> Input Class Initialized
DEBUG - 2011-09-22 13:27:13 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-22 13:27:13 --> Language Class Initialized
DEBUG - 2011-09-22 13:27:13 --> Loader Class Initialized
DEBUG - 2011-09-22 13:27:13 --> Controller Class Initialized
DEBUG - 2011-09-22 13:27:13 --> Model Class Initialized
DEBUG - 2011-09-22 13:27:13 --> Model Class Initialized
DEBUG - 2011-09-22 13:27:13 --> Model Class Initialized
DEBUG - 2011-09-22 13:27:13 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-22 13:27:13 --> Database Driver Class Initialized
DEBUG - 2011-09-22 13:27:13 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-22 13:27:13 --> Helper loaded: url_helper
DEBUG - 2011-09-22 13:27:13 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-22 13:27:13 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-22 13:27:13 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-22 13:27:13 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-22 13:27:13 --> Final output sent to browser
DEBUG - 2011-09-22 13:27:13 --> Total execution time: 0.0755
DEBUG - 2011-09-22 13:27:15 --> Config Class Initialized
DEBUG - 2011-09-22 13:27:15 --> Hooks Class Initialized
DEBUG - 2011-09-22 13:27:15 --> Utf8 Class Initialized
DEBUG - 2011-09-22 13:27:15 --> UTF-8 Support Enabled
DEBUG - 2011-09-22 13:27:15 --> URI Class Initialized
DEBUG - 2011-09-22 13:27:15 --> Router Class Initialized
DEBUG - 2011-09-22 13:27:15 --> Output Class Initialized
DEBUG - 2011-09-22 13:27:15 --> Input Class Initialized
DEBUG - 2011-09-22 13:27:15 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-22 13:27:15 --> Language Class Initialized
DEBUG - 2011-09-22 13:27:15 --> Loader Class Initialized
DEBUG - 2011-09-22 13:27:15 --> Controller Class Initialized
DEBUG - 2011-09-22 13:27:15 --> Model Class Initialized
DEBUG - 2011-09-22 13:27:15 --> Model Class Initialized
DEBUG - 2011-09-22 13:27:15 --> Model Class Initialized
DEBUG - 2011-09-22 13:27:15 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-22 13:27:15 --> Database Driver Class Initialized
DEBUG - 2011-09-22 13:27:15 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-22 13:27:15 --> Helper loaded: url_helper
DEBUG - 2011-09-22 13:27:15 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-22 13:27:15 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-22 13:27:15 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-22 13:27:15 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-22 13:27:15 --> Final output sent to browser
DEBUG - 2011-09-22 13:27:15 --> Total execution time: 0.0605
DEBUG - 2011-09-22 13:27:34 --> Config Class Initialized
DEBUG - 2011-09-22 13:27:34 --> Hooks Class Initialized
DEBUG - 2011-09-22 13:27:34 --> Utf8 Class Initialized
DEBUG - 2011-09-22 13:27:34 --> UTF-8 Support Enabled
DEBUG - 2011-09-22 13:27:34 --> URI Class Initialized
DEBUG - 2011-09-22 13:27:34 --> Router Class Initialized
DEBUG - 2011-09-22 13:27:34 --> Output Class Initialized
DEBUG - 2011-09-22 13:27:34 --> Input Class Initialized
DEBUG - 2011-09-22 13:27:34 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-22 13:27:34 --> Language Class Initialized
DEBUG - 2011-09-22 13:27:34 --> Loader Class Initialized
DEBUG - 2011-09-22 13:27:34 --> Controller Class Initialized
DEBUG - 2011-09-22 13:27:34 --> Model Class Initialized
DEBUG - 2011-09-22 13:27:34 --> Model Class Initialized
DEBUG - 2011-09-22 13:27:34 --> Model Class Initialized
DEBUG - 2011-09-22 13:27:34 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-22 13:27:34 --> Database Driver Class Initialized
DEBUG - 2011-09-22 13:27:36 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-22 13:27:36 --> Helper loaded: url_helper
DEBUG - 2011-09-22 13:27:36 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-22 13:27:36 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-22 13:27:36 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-22 13:27:36 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-22 13:27:36 --> Final output sent to browser
DEBUG - 2011-09-22 13:27:36 --> Total execution time: 1.3005
DEBUG - 2011-09-22 13:27:47 --> Config Class Initialized
DEBUG - 2011-09-22 13:27:47 --> Hooks Class Initialized
DEBUG - 2011-09-22 13:27:47 --> Utf8 Class Initialized
DEBUG - 2011-09-22 13:27:47 --> UTF-8 Support Enabled
DEBUG - 2011-09-22 13:27:47 --> URI Class Initialized
DEBUG - 2011-09-22 13:27:47 --> Router Class Initialized
DEBUG - 2011-09-22 13:27:47 --> Output Class Initialized
DEBUG - 2011-09-22 13:27:47 --> Input Class Initialized
DEBUG - 2011-09-22 13:27:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-22 13:27:47 --> Language Class Initialized
DEBUG - 2011-09-22 13:27:47 --> Loader Class Initialized
DEBUG - 2011-09-22 13:27:47 --> Controller Class Initialized
DEBUG - 2011-09-22 13:27:47 --> Model Class Initialized
DEBUG - 2011-09-22 13:27:47 --> Model Class Initialized
DEBUG - 2011-09-22 13:27:47 --> Model Class Initialized
DEBUG - 2011-09-22 13:27:47 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-22 13:27:47 --> Database Driver Class Initialized
DEBUG - 2011-09-22 13:27:47 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-22 13:27:47 --> Helper loaded: url_helper
DEBUG - 2011-09-22 13:27:47 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-22 13:27:47 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-22 13:27:47 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-22 13:27:47 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-22 13:27:47 --> Final output sent to browser
DEBUG - 2011-09-22 13:27:47 --> Total execution time: 0.6556
DEBUG - 2011-09-22 13:27:54 --> Config Class Initialized
DEBUG - 2011-09-22 13:27:54 --> Hooks Class Initialized
DEBUG - 2011-09-22 13:27:54 --> Utf8 Class Initialized
DEBUG - 2011-09-22 13:27:54 --> UTF-8 Support Enabled
DEBUG - 2011-09-22 13:27:54 --> URI Class Initialized
DEBUG - 2011-09-22 13:27:54 --> Router Class Initialized
DEBUG - 2011-09-22 13:27:54 --> Output Class Initialized
DEBUG - 2011-09-22 13:27:54 --> Input Class Initialized
DEBUG - 2011-09-22 13:27:54 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-22 13:27:54 --> Language Class Initialized
DEBUG - 2011-09-22 13:27:54 --> Loader Class Initialized
DEBUG - 2011-09-22 13:27:54 --> Controller Class Initialized
DEBUG - 2011-09-22 13:27:54 --> Model Class Initialized
DEBUG - 2011-09-22 13:27:54 --> Model Class Initialized
DEBUG - 2011-09-22 13:27:54 --> Model Class Initialized
DEBUG - 2011-09-22 13:27:54 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-22 13:27:54 --> Database Driver Class Initialized
DEBUG - 2011-09-22 13:27:54 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-22 13:27:54 --> Helper loaded: url_helper
DEBUG - 2011-09-22 13:27:54 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-22 13:27:54 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-22 13:27:54 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-22 13:27:54 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-22 13:27:54 --> Final output sent to browser
DEBUG - 2011-09-22 13:27:54 --> Total execution time: 0.3133
DEBUG - 2011-09-22 13:28:10 --> Config Class Initialized
DEBUG - 2011-09-22 13:28:10 --> Hooks Class Initialized
DEBUG - 2011-09-22 13:28:10 --> Utf8 Class Initialized
DEBUG - 2011-09-22 13:28:10 --> UTF-8 Support Enabled
DEBUG - 2011-09-22 13:28:10 --> URI Class Initialized
DEBUG - 2011-09-22 13:28:10 --> Router Class Initialized
DEBUG - 2011-09-22 13:28:10 --> Output Class Initialized
DEBUG - 2011-09-22 13:28:10 --> Input Class Initialized
DEBUG - 2011-09-22 13:28:10 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-22 13:28:10 --> Language Class Initialized
DEBUG - 2011-09-22 13:28:10 --> Loader Class Initialized
DEBUG - 2011-09-22 13:28:10 --> Controller Class Initialized
DEBUG - 2011-09-22 13:28:10 --> Model Class Initialized
DEBUG - 2011-09-22 13:28:10 --> Model Class Initialized
DEBUG - 2011-09-22 13:28:10 --> Model Class Initialized
DEBUG - 2011-09-22 13:28:10 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-22 13:28:10 --> Database Driver Class Initialized
DEBUG - 2011-09-22 13:28:11 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-22 13:28:11 --> Helper loaded: url_helper
DEBUG - 2011-09-22 13:28:11 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-22 13:28:11 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-22 13:28:11 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-22 13:28:11 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-22 13:28:11 --> Final output sent to browser
DEBUG - 2011-09-22 13:28:11 --> Total execution time: 0.5018
DEBUG - 2011-09-22 13:28:20 --> Config Class Initialized
DEBUG - 2011-09-22 13:28:20 --> Hooks Class Initialized
DEBUG - 2011-09-22 13:28:20 --> Utf8 Class Initialized
DEBUG - 2011-09-22 13:28:20 --> UTF-8 Support Enabled
DEBUG - 2011-09-22 13:28:20 --> URI Class Initialized
DEBUG - 2011-09-22 13:28:20 --> Router Class Initialized
DEBUG - 2011-09-22 13:28:20 --> Output Class Initialized
DEBUG - 2011-09-22 13:28:20 --> Input Class Initialized
DEBUG - 2011-09-22 13:28:20 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-22 13:28:20 --> Language Class Initialized
DEBUG - 2011-09-22 13:28:20 --> Loader Class Initialized
DEBUG - 2011-09-22 13:28:20 --> Controller Class Initialized
DEBUG - 2011-09-22 13:28:20 --> Model Class Initialized
DEBUG - 2011-09-22 13:28:20 --> Model Class Initialized
DEBUG - 2011-09-22 13:28:20 --> Model Class Initialized
DEBUG - 2011-09-22 13:28:20 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-22 13:28:20 --> Database Driver Class Initialized
DEBUG - 2011-09-22 13:28:22 --> Config Class Initialized
DEBUG - 2011-09-22 13:28:22 --> Hooks Class Initialized
DEBUG - 2011-09-22 13:28:22 --> Utf8 Class Initialized
DEBUG - 2011-09-22 13:28:22 --> UTF-8 Support Enabled
DEBUG - 2011-09-22 13:28:22 --> URI Class Initialized
DEBUG - 2011-09-22 13:28:22 --> Router Class Initialized
DEBUG - 2011-09-22 13:28:22 --> Output Class Initialized
DEBUG - 2011-09-22 13:28:22 --> Input Class Initialized
DEBUG - 2011-09-22 13:28:22 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-22 13:28:22 --> Language Class Initialized
DEBUG - 2011-09-22 13:28:22 --> Loader Class Initialized
DEBUG - 2011-09-22 13:28:22 --> Controller Class Initialized
DEBUG - 2011-09-22 13:28:22 --> Model Class Initialized
DEBUG - 2011-09-22 13:28:22 --> Model Class Initialized
DEBUG - 2011-09-22 13:28:22 --> Model Class Initialized
DEBUG - 2011-09-22 13:28:22 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-22 13:28:22 --> Database Driver Class Initialized
DEBUG - 2011-09-22 13:28:22 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-22 13:28:22 --> Helper loaded: url_helper
DEBUG - 2011-09-22 13:28:22 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-22 13:28:22 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-22 13:28:22 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-22 13:28:22 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-22 13:28:22 --> Final output sent to browser
DEBUG - 2011-09-22 13:28:22 --> Total execution time: 0.1393
DEBUG - 2011-09-22 13:28:22 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-22 13:28:22 --> Helper loaded: url_helper
DEBUG - 2011-09-22 13:28:22 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-22 13:28:22 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-22 13:28:22 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-22 13:28:22 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-22 13:28:22 --> Final output sent to browser
DEBUG - 2011-09-22 13:28:22 --> Total execution time: 1.9854
DEBUG - 2011-09-22 13:28:24 --> Config Class Initialized
DEBUG - 2011-09-22 13:28:24 --> Hooks Class Initialized
DEBUG - 2011-09-22 13:28:24 --> Utf8 Class Initialized
DEBUG - 2011-09-22 13:28:24 --> UTF-8 Support Enabled
DEBUG - 2011-09-22 13:28:24 --> URI Class Initialized
DEBUG - 2011-09-22 13:28:24 --> Router Class Initialized
DEBUG - 2011-09-22 13:28:24 --> Output Class Initialized
DEBUG - 2011-09-22 13:28:24 --> Input Class Initialized
DEBUG - 2011-09-22 13:28:24 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-22 13:28:24 --> Language Class Initialized
DEBUG - 2011-09-22 13:28:24 --> Loader Class Initialized
DEBUG - 2011-09-22 13:28:24 --> Controller Class Initialized
DEBUG - 2011-09-22 13:28:24 --> Model Class Initialized
DEBUG - 2011-09-22 13:28:24 --> Model Class Initialized
DEBUG - 2011-09-22 13:28:24 --> Model Class Initialized
DEBUG - 2011-09-22 13:28:24 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-22 13:28:24 --> Database Driver Class Initialized
DEBUG - 2011-09-22 13:28:24 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-22 13:28:24 --> Helper loaded: url_helper
DEBUG - 2011-09-22 13:28:24 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-22 13:28:24 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-22 13:28:24 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-22 13:28:24 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-22 13:28:24 --> Final output sent to browser
DEBUG - 2011-09-22 13:28:24 --> Total execution time: 0.2784
DEBUG - 2011-09-22 13:28:25 --> Config Class Initialized
DEBUG - 2011-09-22 13:28:25 --> Hooks Class Initialized
DEBUG - 2011-09-22 13:28:25 --> Utf8 Class Initialized
DEBUG - 2011-09-22 13:28:25 --> UTF-8 Support Enabled
DEBUG - 2011-09-22 13:28:25 --> URI Class Initialized
DEBUG - 2011-09-22 13:28:25 --> Router Class Initialized
DEBUG - 2011-09-22 13:28:25 --> Output Class Initialized
DEBUG - 2011-09-22 13:28:25 --> Input Class Initialized
DEBUG - 2011-09-22 13:28:25 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-22 13:28:25 --> Language Class Initialized
DEBUG - 2011-09-22 13:28:25 --> Loader Class Initialized
DEBUG - 2011-09-22 13:28:25 --> Controller Class Initialized
DEBUG - 2011-09-22 13:28:25 --> Model Class Initialized
DEBUG - 2011-09-22 13:28:25 --> Model Class Initialized
DEBUG - 2011-09-22 13:28:25 --> Model Class Initialized
DEBUG - 2011-09-22 13:28:25 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-22 13:28:25 --> Database Driver Class Initialized
DEBUG - 2011-09-22 13:28:25 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-22 13:28:25 --> Helper loaded: url_helper
DEBUG - 2011-09-22 13:28:25 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-22 13:28:25 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-22 13:28:25 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-22 13:28:25 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-22 13:28:25 --> Final output sent to browser
DEBUG - 2011-09-22 13:28:25 --> Total execution time: 0.2037
DEBUG - 2011-09-22 13:28:27 --> Config Class Initialized
DEBUG - 2011-09-22 13:28:27 --> Hooks Class Initialized
DEBUG - 2011-09-22 13:28:27 --> Utf8 Class Initialized
DEBUG - 2011-09-22 13:28:27 --> UTF-8 Support Enabled
DEBUG - 2011-09-22 13:28:27 --> URI Class Initialized
DEBUG - 2011-09-22 13:28:27 --> Router Class Initialized
DEBUG - 2011-09-22 13:28:27 --> Output Class Initialized
DEBUG - 2011-09-22 13:28:27 --> Input Class Initialized
DEBUG - 2011-09-22 13:28:27 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-22 13:28:27 --> Language Class Initialized
DEBUG - 2011-09-22 13:28:27 --> Loader Class Initialized
DEBUG - 2011-09-22 13:28:27 --> Controller Class Initialized
DEBUG - 2011-09-22 13:28:27 --> Model Class Initialized
DEBUG - 2011-09-22 13:28:27 --> Model Class Initialized
DEBUG - 2011-09-22 13:28:27 --> Model Class Initialized
DEBUG - 2011-09-22 13:28:27 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-22 13:28:28 --> Database Driver Class Initialized
DEBUG - 2011-09-22 13:28:28 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-22 13:28:28 --> Helper loaded: url_helper
DEBUG - 2011-09-22 13:28:28 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-22 13:28:28 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-22 13:28:28 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-22 13:28:28 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-22 13:28:28 --> Final output sent to browser
DEBUG - 2011-09-22 13:28:28 --> Total execution time: 0.0921
DEBUG - 2011-09-22 13:28:28 --> Config Class Initialized
DEBUG - 2011-09-22 13:28:28 --> Hooks Class Initialized
DEBUG - 2011-09-22 13:28:28 --> Utf8 Class Initialized
DEBUG - 2011-09-22 13:28:28 --> UTF-8 Support Enabled
DEBUG - 2011-09-22 13:28:28 --> URI Class Initialized
DEBUG - 2011-09-22 13:28:28 --> Router Class Initialized
DEBUG - 2011-09-22 13:28:28 --> Output Class Initialized
DEBUG - 2011-09-22 13:28:28 --> Input Class Initialized
DEBUG - 2011-09-22 13:28:28 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-22 13:28:28 --> Language Class Initialized
DEBUG - 2011-09-22 13:28:28 --> Loader Class Initialized
DEBUG - 2011-09-22 13:28:28 --> Controller Class Initialized
DEBUG - 2011-09-22 13:28:28 --> Model Class Initialized
DEBUG - 2011-09-22 13:28:28 --> Model Class Initialized
DEBUG - 2011-09-22 13:28:28 --> Model Class Initialized
DEBUG - 2011-09-22 13:28:28 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-22 13:28:28 --> Database Driver Class Initialized
DEBUG - 2011-09-22 13:28:28 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-22 13:28:28 --> Helper loaded: url_helper
DEBUG - 2011-09-22 13:28:28 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-22 13:28:28 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-22 13:28:28 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-22 13:28:28 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-22 13:28:28 --> Final output sent to browser
DEBUG - 2011-09-22 13:28:28 --> Total execution time: 0.1311
DEBUG - 2011-09-22 13:28:29 --> Config Class Initialized
DEBUG - 2011-09-22 13:28:29 --> Hooks Class Initialized
DEBUG - 2011-09-22 13:28:29 --> Utf8 Class Initialized
DEBUG - 2011-09-22 13:28:29 --> UTF-8 Support Enabled
DEBUG - 2011-09-22 13:28:29 --> URI Class Initialized
DEBUG - 2011-09-22 13:28:29 --> Router Class Initialized
DEBUG - 2011-09-22 13:28:29 --> Output Class Initialized
DEBUG - 2011-09-22 13:28:29 --> Input Class Initialized
DEBUG - 2011-09-22 13:28:29 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-22 13:28:29 --> Language Class Initialized
DEBUG - 2011-09-22 13:28:29 --> Loader Class Initialized
DEBUG - 2011-09-22 13:28:29 --> Controller Class Initialized
DEBUG - 2011-09-22 13:28:29 --> Model Class Initialized
DEBUG - 2011-09-22 13:28:29 --> Model Class Initialized
DEBUG - 2011-09-22 13:28:29 --> Model Class Initialized
DEBUG - 2011-09-22 13:28:29 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-22 13:28:29 --> Database Driver Class Initialized
DEBUG - 2011-09-22 13:28:29 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-22 13:28:29 --> Helper loaded: url_helper
DEBUG - 2011-09-22 13:28:29 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-22 13:28:29 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-22 13:28:29 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-22 13:28:29 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-22 13:28:29 --> Final output sent to browser
DEBUG - 2011-09-22 13:28:29 --> Total execution time: 0.1502
DEBUG - 2011-09-22 13:28:31 --> Config Class Initialized
DEBUG - 2011-09-22 13:28:31 --> Hooks Class Initialized
DEBUG - 2011-09-22 13:28:31 --> Utf8 Class Initialized
DEBUG - 2011-09-22 13:28:31 --> UTF-8 Support Enabled
DEBUG - 2011-09-22 13:28:31 --> URI Class Initialized
DEBUG - 2011-09-22 13:28:31 --> Router Class Initialized
DEBUG - 2011-09-22 13:28:31 --> Output Class Initialized
DEBUG - 2011-09-22 13:28:31 --> Input Class Initialized
DEBUG - 2011-09-22 13:28:31 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-22 13:28:31 --> Language Class Initialized
DEBUG - 2011-09-22 13:28:31 --> Loader Class Initialized
DEBUG - 2011-09-22 13:28:31 --> Controller Class Initialized
DEBUG - 2011-09-22 13:28:31 --> Model Class Initialized
DEBUG - 2011-09-22 13:28:31 --> Model Class Initialized
DEBUG - 2011-09-22 13:28:31 --> Model Class Initialized
DEBUG - 2011-09-22 13:28:31 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-22 13:28:31 --> Database Driver Class Initialized
DEBUG - 2011-09-22 13:28:31 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-22 13:28:31 --> Helper loaded: url_helper
DEBUG - 2011-09-22 13:28:31 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-22 13:28:31 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-22 13:28:31 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-22 13:28:31 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-22 13:28:31 --> Final output sent to browser
DEBUG - 2011-09-22 13:28:31 --> Total execution time: 0.4264
DEBUG - 2011-09-22 13:28:34 --> Config Class Initialized
DEBUG - 2011-09-22 13:28:34 --> Hooks Class Initialized
DEBUG - 2011-09-22 13:28:34 --> Utf8 Class Initialized
DEBUG - 2011-09-22 13:28:34 --> UTF-8 Support Enabled
DEBUG - 2011-09-22 13:28:34 --> URI Class Initialized
DEBUG - 2011-09-22 13:28:34 --> Router Class Initialized
DEBUG - 2011-09-22 13:28:34 --> Output Class Initialized
DEBUG - 2011-09-22 13:28:34 --> Input Class Initialized
DEBUG - 2011-09-22 13:28:34 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-22 13:28:34 --> Language Class Initialized
DEBUG - 2011-09-22 13:28:34 --> Loader Class Initialized
DEBUG - 2011-09-22 13:28:34 --> Controller Class Initialized
DEBUG - 2011-09-22 13:28:34 --> Model Class Initialized
DEBUG - 2011-09-22 13:28:34 --> Model Class Initialized
DEBUG - 2011-09-22 13:28:34 --> Model Class Initialized
DEBUG - 2011-09-22 13:28:34 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-22 13:28:34 --> Database Driver Class Initialized
DEBUG - 2011-09-22 13:28:34 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-22 13:28:34 --> Helper loaded: url_helper
DEBUG - 2011-09-22 13:28:34 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-22 13:28:34 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-22 13:28:34 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-22 13:28:34 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-22 13:28:34 --> Final output sent to browser
DEBUG - 2011-09-22 13:28:34 --> Total execution time: 0.0526
DEBUG - 2011-09-22 13:28:38 --> Config Class Initialized
DEBUG - 2011-09-22 13:28:38 --> Hooks Class Initialized
DEBUG - 2011-09-22 13:28:38 --> Utf8 Class Initialized
DEBUG - 2011-09-22 13:28:38 --> UTF-8 Support Enabled
DEBUG - 2011-09-22 13:28:38 --> URI Class Initialized
DEBUG - 2011-09-22 13:28:38 --> Router Class Initialized
DEBUG - 2011-09-22 13:28:38 --> Output Class Initialized
DEBUG - 2011-09-22 13:28:38 --> Input Class Initialized
DEBUG - 2011-09-22 13:28:38 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-22 13:28:38 --> Language Class Initialized
DEBUG - 2011-09-22 13:28:38 --> Loader Class Initialized
DEBUG - 2011-09-22 13:28:38 --> Controller Class Initialized
DEBUG - 2011-09-22 13:28:38 --> Model Class Initialized
DEBUG - 2011-09-22 13:28:38 --> Model Class Initialized
DEBUG - 2011-09-22 13:28:38 --> Model Class Initialized
DEBUG - 2011-09-22 13:28:38 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-22 13:28:38 --> Database Driver Class Initialized
DEBUG - 2011-09-22 13:28:38 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-22 13:28:38 --> Helper loaded: url_helper
DEBUG - 2011-09-22 13:28:38 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-22 13:28:38 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-22 13:28:38 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-22 13:28:38 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-22 13:28:38 --> Final output sent to browser
DEBUG - 2011-09-22 13:28:38 --> Total execution time: 0.3516
DEBUG - 2011-09-22 13:28:39 --> Config Class Initialized
DEBUG - 2011-09-22 13:28:39 --> Hooks Class Initialized
DEBUG - 2011-09-22 13:28:39 --> Utf8 Class Initialized
DEBUG - 2011-09-22 13:28:39 --> UTF-8 Support Enabled
DEBUG - 2011-09-22 13:28:39 --> URI Class Initialized
DEBUG - 2011-09-22 13:28:39 --> Router Class Initialized
DEBUG - 2011-09-22 13:28:39 --> Output Class Initialized
DEBUG - 2011-09-22 13:28:39 --> Input Class Initialized
DEBUG - 2011-09-22 13:28:39 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-22 13:28:39 --> Language Class Initialized
DEBUG - 2011-09-22 13:28:39 --> Loader Class Initialized
DEBUG - 2011-09-22 13:28:39 --> Controller Class Initialized
DEBUG - 2011-09-22 13:28:39 --> Model Class Initialized
DEBUG - 2011-09-22 13:28:39 --> Model Class Initialized
DEBUG - 2011-09-22 13:28:39 --> Model Class Initialized
DEBUG - 2011-09-22 13:28:39 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-22 13:28:39 --> Database Driver Class Initialized
DEBUG - 2011-09-22 13:28:39 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-22 13:28:39 --> Helper loaded: url_helper
DEBUG - 2011-09-22 13:28:39 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-22 13:28:39 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-22 13:28:39 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-22 13:28:39 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-22 13:28:39 --> Final output sent to browser
DEBUG - 2011-09-22 13:28:39 --> Total execution time: 0.0786
DEBUG - 2011-09-22 13:28:51 --> Config Class Initialized
DEBUG - 2011-09-22 13:28:51 --> Hooks Class Initialized
DEBUG - 2011-09-22 13:28:51 --> Utf8 Class Initialized
DEBUG - 2011-09-22 13:28:51 --> UTF-8 Support Enabled
DEBUG - 2011-09-22 13:28:51 --> URI Class Initialized
DEBUG - 2011-09-22 13:28:51 --> Router Class Initialized
DEBUG - 2011-09-22 13:28:51 --> Output Class Initialized
DEBUG - 2011-09-22 13:28:51 --> Input Class Initialized
DEBUG - 2011-09-22 13:28:51 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-22 13:28:51 --> Language Class Initialized
DEBUG - 2011-09-22 13:28:51 --> Loader Class Initialized
DEBUG - 2011-09-22 13:28:51 --> Controller Class Initialized
DEBUG - 2011-09-22 13:28:51 --> Model Class Initialized
DEBUG - 2011-09-22 13:28:51 --> Model Class Initialized
DEBUG - 2011-09-22 13:28:51 --> Model Class Initialized
DEBUG - 2011-09-22 13:28:51 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-22 13:28:51 --> Database Driver Class Initialized
DEBUG - 2011-09-22 13:28:52 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-22 13:28:52 --> Helper loaded: url_helper
DEBUG - 2011-09-22 13:28:52 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-22 13:28:52 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-22 13:28:52 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-22 13:28:52 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-22 13:28:52 --> Final output sent to browser
DEBUG - 2011-09-22 13:28:52 --> Total execution time: 0.3694
DEBUG - 2011-09-22 13:28:52 --> Config Class Initialized
DEBUG - 2011-09-22 13:28:52 --> Hooks Class Initialized
DEBUG - 2011-09-22 13:28:52 --> Utf8 Class Initialized
DEBUG - 2011-09-22 13:28:52 --> UTF-8 Support Enabled
DEBUG - 2011-09-22 13:28:52 --> URI Class Initialized
DEBUG - 2011-09-22 13:28:52 --> Router Class Initialized
DEBUG - 2011-09-22 13:28:52 --> Output Class Initialized
DEBUG - 2011-09-22 13:28:52 --> Input Class Initialized
DEBUG - 2011-09-22 13:28:52 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-22 13:28:52 --> Language Class Initialized
DEBUG - 2011-09-22 13:28:52 --> Loader Class Initialized
DEBUG - 2011-09-22 13:28:52 --> Controller Class Initialized
DEBUG - 2011-09-22 13:28:52 --> Model Class Initialized
DEBUG - 2011-09-22 13:28:52 --> Model Class Initialized
DEBUG - 2011-09-22 13:28:52 --> Model Class Initialized
DEBUG - 2011-09-22 13:28:52 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-22 13:28:52 --> Database Driver Class Initialized
DEBUG - 2011-09-22 13:28:52 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-22 13:28:52 --> Helper loaded: url_helper
DEBUG - 2011-09-22 13:28:52 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-22 13:28:52 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-22 13:28:52 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-22 13:28:52 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-22 13:28:52 --> Final output sent to browser
DEBUG - 2011-09-22 13:28:52 --> Total execution time: 0.0798
DEBUG - 2011-09-22 13:28:57 --> Config Class Initialized
DEBUG - 2011-09-22 13:28:57 --> Hooks Class Initialized
DEBUG - 2011-09-22 13:28:57 --> Utf8 Class Initialized
DEBUG - 2011-09-22 13:28:57 --> UTF-8 Support Enabled
DEBUG - 2011-09-22 13:28:57 --> URI Class Initialized
DEBUG - 2011-09-22 13:28:57 --> Router Class Initialized
DEBUG - 2011-09-22 13:28:57 --> Output Class Initialized
DEBUG - 2011-09-22 13:28:57 --> Input Class Initialized
DEBUG - 2011-09-22 13:28:57 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-22 13:28:57 --> Language Class Initialized
DEBUG - 2011-09-22 13:28:57 --> Loader Class Initialized
DEBUG - 2011-09-22 13:28:57 --> Controller Class Initialized
DEBUG - 2011-09-22 13:28:57 --> Model Class Initialized
DEBUG - 2011-09-22 13:28:57 --> Model Class Initialized
DEBUG - 2011-09-22 13:28:57 --> Model Class Initialized
DEBUG - 2011-09-22 13:28:57 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-22 13:28:57 --> Database Driver Class Initialized
DEBUG - 2011-09-22 13:28:57 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-22 13:28:57 --> Helper loaded: url_helper
DEBUG - 2011-09-22 13:28:57 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-22 13:28:57 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-22 13:28:57 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-22 13:28:57 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-22 13:28:57 --> Final output sent to browser
DEBUG - 2011-09-22 13:28:57 --> Total execution time: 0.6474
DEBUG - 2011-09-22 13:50:42 --> Config Class Initialized
DEBUG - 2011-09-22 13:50:42 --> Hooks Class Initialized
DEBUG - 2011-09-22 13:50:42 --> Utf8 Class Initialized
DEBUG - 2011-09-22 13:50:42 --> UTF-8 Support Enabled
DEBUG - 2011-09-22 13:50:42 --> URI Class Initialized
DEBUG - 2011-09-22 13:50:42 --> Router Class Initialized
DEBUG - 2011-09-22 13:50:42 --> Output Class Initialized
DEBUG - 2011-09-22 13:50:42 --> Input Class Initialized
DEBUG - 2011-09-22 13:50:42 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-22 13:50:42 --> Language Class Initialized
DEBUG - 2011-09-22 13:50:42 --> Loader Class Initialized
DEBUG - 2011-09-22 13:50:42 --> Controller Class Initialized
ERROR - 2011-09-22 13:50:42 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-22 13:50:42 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-22 13:50:42 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-22 13:50:42 --> Model Class Initialized
DEBUG - 2011-09-22 13:50:42 --> Model Class Initialized
DEBUG - 2011-09-22 13:50:42 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-22 13:50:42 --> Database Driver Class Initialized
DEBUG - 2011-09-22 13:50:43 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-22 13:50:43 --> Helper loaded: url_helper
DEBUG - 2011-09-22 13:50:43 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-22 13:50:43 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-22 13:50:43 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-22 13:50:43 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-22 13:50:43 --> Final output sent to browser
DEBUG - 2011-09-22 13:50:43 --> Total execution time: 0.6741
DEBUG - 2011-09-22 13:50:45 --> Config Class Initialized
DEBUG - 2011-09-22 13:50:45 --> Hooks Class Initialized
DEBUG - 2011-09-22 13:50:45 --> Utf8 Class Initialized
DEBUG - 2011-09-22 13:50:45 --> UTF-8 Support Enabled
DEBUG - 2011-09-22 13:50:45 --> URI Class Initialized
DEBUG - 2011-09-22 13:50:45 --> Router Class Initialized
DEBUG - 2011-09-22 13:50:45 --> Output Class Initialized
DEBUG - 2011-09-22 13:50:45 --> Input Class Initialized
DEBUG - 2011-09-22 13:50:45 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-22 13:50:45 --> Language Class Initialized
DEBUG - 2011-09-22 13:50:45 --> Loader Class Initialized
DEBUG - 2011-09-22 13:50:45 --> Controller Class Initialized
DEBUG - 2011-09-22 13:50:45 --> Model Class Initialized
DEBUG - 2011-09-22 13:50:45 --> Model Class Initialized
DEBUG - 2011-09-22 13:50:45 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-22 13:50:45 --> Database Driver Class Initialized
DEBUG - 2011-09-22 13:50:47 --> Final output sent to browser
DEBUG - 2011-09-22 13:50:47 --> Total execution time: 1.6884
DEBUG - 2011-09-22 13:50:49 --> Config Class Initialized
DEBUG - 2011-09-22 13:50:49 --> Hooks Class Initialized
DEBUG - 2011-09-22 13:50:49 --> Utf8 Class Initialized
DEBUG - 2011-09-22 13:50:49 --> UTF-8 Support Enabled
DEBUG - 2011-09-22 13:50:49 --> URI Class Initialized
DEBUG - 2011-09-22 13:50:49 --> Router Class Initialized
ERROR - 2011-09-22 13:50:49 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-22 13:51:06 --> Config Class Initialized
DEBUG - 2011-09-22 13:51:06 --> Hooks Class Initialized
DEBUG - 2011-09-22 13:51:06 --> Utf8 Class Initialized
DEBUG - 2011-09-22 13:51:06 --> UTF-8 Support Enabled
DEBUG - 2011-09-22 13:51:06 --> URI Class Initialized
DEBUG - 2011-09-22 13:51:06 --> Router Class Initialized
DEBUG - 2011-09-22 13:51:06 --> Output Class Initialized
DEBUG - 2011-09-22 13:51:06 --> Input Class Initialized
DEBUG - 2011-09-22 13:51:06 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-22 13:51:06 --> Language Class Initialized
DEBUG - 2011-09-22 13:51:06 --> Loader Class Initialized
DEBUG - 2011-09-22 13:51:06 --> Controller Class Initialized
ERROR - 2011-09-22 13:51:06 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-22 13:51:06 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-22 13:51:06 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-22 13:51:06 --> Model Class Initialized
DEBUG - 2011-09-22 13:51:06 --> Model Class Initialized
DEBUG - 2011-09-22 13:51:06 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-22 13:51:06 --> Database Driver Class Initialized
DEBUG - 2011-09-22 13:51:06 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-22 13:51:06 --> Helper loaded: url_helper
DEBUG - 2011-09-22 13:51:06 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-22 13:51:06 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-22 13:51:06 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-22 13:51:06 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-22 13:51:06 --> Final output sent to browser
DEBUG - 2011-09-22 13:51:06 --> Total execution time: 0.1466
DEBUG - 2011-09-22 13:51:08 --> Config Class Initialized
DEBUG - 2011-09-22 13:51:08 --> Hooks Class Initialized
DEBUG - 2011-09-22 13:51:08 --> Utf8 Class Initialized
DEBUG - 2011-09-22 13:51:08 --> UTF-8 Support Enabled
DEBUG - 2011-09-22 13:51:08 --> URI Class Initialized
DEBUG - 2011-09-22 13:51:08 --> Router Class Initialized
DEBUG - 2011-09-22 13:51:08 --> Output Class Initialized
DEBUG - 2011-09-22 13:51:08 --> Input Class Initialized
DEBUG - 2011-09-22 13:51:08 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-22 13:51:08 --> Language Class Initialized
DEBUG - 2011-09-22 13:51:08 --> Loader Class Initialized
DEBUG - 2011-09-22 13:51:08 --> Controller Class Initialized
DEBUG - 2011-09-22 13:51:08 --> Model Class Initialized
DEBUG - 2011-09-22 13:51:08 --> Model Class Initialized
DEBUG - 2011-09-22 13:51:08 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-22 13:51:08 --> Database Driver Class Initialized
DEBUG - 2011-09-22 13:51:09 --> Final output sent to browser
DEBUG - 2011-09-22 13:51:09 --> Total execution time: 1.0965
DEBUG - 2011-09-22 13:51:21 --> Config Class Initialized
DEBUG - 2011-09-22 13:51:21 --> Hooks Class Initialized
DEBUG - 2011-09-22 13:51:21 --> Utf8 Class Initialized
DEBUG - 2011-09-22 13:51:21 --> UTF-8 Support Enabled
DEBUG - 2011-09-22 13:51:21 --> URI Class Initialized
DEBUG - 2011-09-22 13:51:21 --> Router Class Initialized
DEBUG - 2011-09-22 13:51:21 --> Output Class Initialized
DEBUG - 2011-09-22 13:51:21 --> Input Class Initialized
DEBUG - 2011-09-22 13:51:21 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-22 13:51:21 --> Language Class Initialized
DEBUG - 2011-09-22 13:51:21 --> Loader Class Initialized
DEBUG - 2011-09-22 13:51:21 --> Controller Class Initialized
ERROR - 2011-09-22 13:51:21 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-22 13:51:21 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-22 13:51:21 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-22 13:51:21 --> Model Class Initialized
DEBUG - 2011-09-22 13:51:21 --> Model Class Initialized
DEBUG - 2011-09-22 13:51:21 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-22 13:51:21 --> Database Driver Class Initialized
DEBUG - 2011-09-22 13:51:21 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-22 13:51:21 --> Helper loaded: url_helper
DEBUG - 2011-09-22 13:51:21 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-22 13:51:21 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-22 13:51:21 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-22 13:51:21 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-22 13:51:21 --> Final output sent to browser
DEBUG - 2011-09-22 13:51:21 --> Total execution time: 0.2251
DEBUG - 2011-09-22 13:51:22 --> Config Class Initialized
DEBUG - 2011-09-22 13:51:22 --> Hooks Class Initialized
DEBUG - 2011-09-22 13:51:22 --> Utf8 Class Initialized
DEBUG - 2011-09-22 13:51:22 --> UTF-8 Support Enabled
DEBUG - 2011-09-22 13:51:22 --> URI Class Initialized
DEBUG - 2011-09-22 13:51:22 --> Router Class Initialized
DEBUG - 2011-09-22 13:51:22 --> Output Class Initialized
DEBUG - 2011-09-22 13:51:22 --> Input Class Initialized
DEBUG - 2011-09-22 13:51:22 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-22 13:51:22 --> Language Class Initialized
DEBUG - 2011-09-22 13:51:22 --> Loader Class Initialized
DEBUG - 2011-09-22 13:51:22 --> Controller Class Initialized
DEBUG - 2011-09-22 13:51:22 --> Model Class Initialized
DEBUG - 2011-09-22 13:51:22 --> Model Class Initialized
DEBUG - 2011-09-22 13:51:22 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-22 13:51:22 --> Database Driver Class Initialized
DEBUG - 2011-09-22 13:51:23 --> Final output sent to browser
DEBUG - 2011-09-22 13:51:23 --> Total execution time: 1.0180
DEBUG - 2011-09-22 13:51:33 --> Config Class Initialized
DEBUG - 2011-09-22 13:51:33 --> Hooks Class Initialized
DEBUG - 2011-09-22 13:51:33 --> Utf8 Class Initialized
DEBUG - 2011-09-22 13:51:33 --> UTF-8 Support Enabled
DEBUG - 2011-09-22 13:51:33 --> URI Class Initialized
DEBUG - 2011-09-22 13:51:33 --> Router Class Initialized
DEBUG - 2011-09-22 13:51:33 --> Output Class Initialized
DEBUG - 2011-09-22 13:51:33 --> Input Class Initialized
DEBUG - 2011-09-22 13:51:33 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-22 13:51:33 --> Language Class Initialized
DEBUG - 2011-09-22 13:51:33 --> Loader Class Initialized
DEBUG - 2011-09-22 13:51:33 --> Controller Class Initialized
ERROR - 2011-09-22 13:51:33 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-22 13:51:33 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-22 13:51:33 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-22 13:51:33 --> Model Class Initialized
DEBUG - 2011-09-22 13:51:33 --> Model Class Initialized
DEBUG - 2011-09-22 13:51:33 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-22 13:51:33 --> Database Driver Class Initialized
DEBUG - 2011-09-22 13:51:33 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-22 13:51:33 --> Helper loaded: url_helper
DEBUG - 2011-09-22 13:51:33 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-22 13:51:33 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-22 13:51:33 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-22 13:51:33 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-22 13:51:33 --> Final output sent to browser
DEBUG - 2011-09-22 13:51:33 --> Total execution time: 0.1674
DEBUG - 2011-09-22 13:51:34 --> Config Class Initialized
DEBUG - 2011-09-22 13:51:34 --> Hooks Class Initialized
DEBUG - 2011-09-22 13:51:34 --> Utf8 Class Initialized
DEBUG - 2011-09-22 13:51:34 --> UTF-8 Support Enabled
DEBUG - 2011-09-22 13:51:34 --> URI Class Initialized
DEBUG - 2011-09-22 13:51:34 --> Router Class Initialized
DEBUG - 2011-09-22 13:51:34 --> Output Class Initialized
DEBUG - 2011-09-22 13:51:34 --> Input Class Initialized
DEBUG - 2011-09-22 13:51:34 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-22 13:51:34 --> Language Class Initialized
DEBUG - 2011-09-22 13:51:34 --> Loader Class Initialized
DEBUG - 2011-09-22 13:51:34 --> Controller Class Initialized
DEBUG - 2011-09-22 13:51:34 --> Model Class Initialized
DEBUG - 2011-09-22 13:51:34 --> Model Class Initialized
DEBUG - 2011-09-22 13:51:34 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-22 13:51:34 --> Database Driver Class Initialized
DEBUG - 2011-09-22 13:51:35 --> Final output sent to browser
DEBUG - 2011-09-22 13:51:35 --> Total execution time: 0.8319
DEBUG - 2011-09-22 14:10:20 --> Config Class Initialized
DEBUG - 2011-09-22 14:10:20 --> Hooks Class Initialized
DEBUG - 2011-09-22 14:10:20 --> Utf8 Class Initialized
DEBUG - 2011-09-22 14:10:20 --> UTF-8 Support Enabled
DEBUG - 2011-09-22 14:10:20 --> URI Class Initialized
DEBUG - 2011-09-22 14:10:20 --> Router Class Initialized
DEBUG - 2011-09-22 14:10:20 --> Output Class Initialized
DEBUG - 2011-09-22 14:10:20 --> Input Class Initialized
DEBUG - 2011-09-22 14:10:20 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-22 14:10:20 --> Language Class Initialized
DEBUG - 2011-09-22 14:10:20 --> Loader Class Initialized
DEBUG - 2011-09-22 14:10:21 --> Controller Class Initialized
DEBUG - 2011-09-22 14:10:21 --> Model Class Initialized
DEBUG - 2011-09-22 14:10:21 --> Model Class Initialized
DEBUG - 2011-09-22 14:10:21 --> Model Class Initialized
DEBUG - 2011-09-22 14:10:21 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-22 14:10:21 --> Database Driver Class Initialized
DEBUG - 2011-09-22 14:10:22 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-22 14:10:22 --> Helper loaded: url_helper
DEBUG - 2011-09-22 14:10:22 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-22 14:10:22 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-22 14:10:22 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-22 14:10:22 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-22 14:10:22 --> Final output sent to browser
DEBUG - 2011-09-22 14:10:22 --> Total execution time: 1.7674
DEBUG - 2011-09-22 15:45:59 --> Config Class Initialized
DEBUG - 2011-09-22 15:45:59 --> Hooks Class Initialized
DEBUG - 2011-09-22 15:45:59 --> Utf8 Class Initialized
DEBUG - 2011-09-22 15:45:59 --> UTF-8 Support Enabled
DEBUG - 2011-09-22 15:45:59 --> URI Class Initialized
DEBUG - 2011-09-22 15:45:59 --> Router Class Initialized
DEBUG - 2011-09-22 15:45:59 --> Output Class Initialized
DEBUG - 2011-09-22 15:45:59 --> Input Class Initialized
DEBUG - 2011-09-22 15:45:59 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-22 15:45:59 --> Language Class Initialized
DEBUG - 2011-09-22 15:45:59 --> Loader Class Initialized
DEBUG - 2011-09-22 15:45:59 --> Controller Class Initialized
ERROR - 2011-09-22 15:45:59 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-22 15:45:59 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-22 15:45:59 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-22 15:45:59 --> Model Class Initialized
DEBUG - 2011-09-22 15:45:59 --> Model Class Initialized
DEBUG - 2011-09-22 15:45:59 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-22 15:45:59 --> Database Driver Class Initialized
DEBUG - 2011-09-22 15:46:00 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-22 15:46:00 --> Helper loaded: url_helper
DEBUG - 2011-09-22 15:46:00 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-22 15:46:00 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-22 15:46:00 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-22 15:46:00 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-22 15:46:00 --> Final output sent to browser
DEBUG - 2011-09-22 15:46:00 --> Total execution time: 0.3256
DEBUG - 2011-09-22 15:46:00 --> Config Class Initialized
DEBUG - 2011-09-22 15:46:00 --> Hooks Class Initialized
DEBUG - 2011-09-22 15:46:00 --> Utf8 Class Initialized
DEBUG - 2011-09-22 15:46:00 --> UTF-8 Support Enabled
DEBUG - 2011-09-22 15:46:00 --> URI Class Initialized
DEBUG - 2011-09-22 15:46:00 --> Router Class Initialized
DEBUG - 2011-09-22 15:46:00 --> Output Class Initialized
DEBUG - 2011-09-22 15:46:00 --> Input Class Initialized
DEBUG - 2011-09-22 15:46:00 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-22 15:46:00 --> Language Class Initialized
DEBUG - 2011-09-22 15:46:00 --> Loader Class Initialized
DEBUG - 2011-09-22 15:46:00 --> Controller Class Initialized
DEBUG - 2011-09-22 15:46:00 --> Model Class Initialized
DEBUG - 2011-09-22 15:46:00 --> Model Class Initialized
DEBUG - 2011-09-22 15:46:00 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-22 15:46:00 --> Database Driver Class Initialized
DEBUG - 2011-09-22 15:46:01 --> Final output sent to browser
DEBUG - 2011-09-22 15:46:01 --> Total execution time: 0.8568
DEBUG - 2011-09-22 15:46:02 --> Config Class Initialized
DEBUG - 2011-09-22 15:46:02 --> Hooks Class Initialized
DEBUG - 2011-09-22 15:46:02 --> Utf8 Class Initialized
DEBUG - 2011-09-22 15:46:02 --> UTF-8 Support Enabled
DEBUG - 2011-09-22 15:46:02 --> URI Class Initialized
DEBUG - 2011-09-22 15:46:02 --> Router Class Initialized
ERROR - 2011-09-22 15:46:02 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-22 15:46:03 --> Config Class Initialized
DEBUG - 2011-09-22 15:46:03 --> Hooks Class Initialized
DEBUG - 2011-09-22 15:46:03 --> Utf8 Class Initialized
DEBUG - 2011-09-22 15:46:03 --> UTF-8 Support Enabled
DEBUG - 2011-09-22 15:46:03 --> URI Class Initialized
DEBUG - 2011-09-22 15:46:03 --> Router Class Initialized
ERROR - 2011-09-22 15:46:03 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-22 16:01:21 --> Config Class Initialized
DEBUG - 2011-09-22 16:01:21 --> Hooks Class Initialized
DEBUG - 2011-09-22 16:01:21 --> Utf8 Class Initialized
DEBUG - 2011-09-22 16:01:21 --> UTF-8 Support Enabled
DEBUG - 2011-09-22 16:01:21 --> URI Class Initialized
DEBUG - 2011-09-22 16:01:21 --> Router Class Initialized
DEBUG - 2011-09-22 16:01:21 --> No URI present. Default controller set.
DEBUG - 2011-09-22 16:01:21 --> Output Class Initialized
DEBUG - 2011-09-22 16:01:21 --> Input Class Initialized
DEBUG - 2011-09-22 16:01:21 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-22 16:01:21 --> Language Class Initialized
DEBUG - 2011-09-22 16:01:21 --> Loader Class Initialized
DEBUG - 2011-09-22 16:01:21 --> Controller Class Initialized
DEBUG - 2011-09-22 16:01:21 --> File loaded: application/views/splash/main.php
DEBUG - 2011-09-22 16:01:21 --> Helper loaded: url_helper
DEBUG - 2011-09-22 16:01:21 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-22 16:01:21 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-22 16:01:21 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-22 16:01:21 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-22 16:01:21 --> Final output sent to browser
DEBUG - 2011-09-22 16:01:21 --> Total execution time: 0.1409
DEBUG - 2011-09-22 16:10:02 --> Config Class Initialized
DEBUG - 2011-09-22 16:10:02 --> Hooks Class Initialized
DEBUG - 2011-09-22 16:10:02 --> Utf8 Class Initialized
DEBUG - 2011-09-22 16:10:02 --> UTF-8 Support Enabled
DEBUG - 2011-09-22 16:10:02 --> URI Class Initialized
DEBUG - 2011-09-22 16:10:02 --> Router Class Initialized
DEBUG - 2011-09-22 16:10:02 --> Output Class Initialized
DEBUG - 2011-09-22 16:10:02 --> Input Class Initialized
DEBUG - 2011-09-22 16:10:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-22 16:10:02 --> Language Class Initialized
DEBUG - 2011-09-22 16:10:02 --> Loader Class Initialized
DEBUG - 2011-09-22 16:10:02 --> Controller Class Initialized
DEBUG - 2011-09-22 16:10:02 --> Model Class Initialized
DEBUG - 2011-09-22 16:10:02 --> Model Class Initialized
DEBUG - 2011-09-22 16:10:02 --> Model Class Initialized
DEBUG - 2011-09-22 16:10:02 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-22 16:10:02 --> Database Driver Class Initialized
DEBUG - 2011-09-22 16:10:03 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-22 16:10:03 --> Helper loaded: url_helper
DEBUG - 2011-09-22 16:10:03 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-22 16:10:03 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-22 16:10:03 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-22 16:10:03 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-22 16:10:03 --> Final output sent to browser
DEBUG - 2011-09-22 16:10:03 --> Total execution time: 1.5234
DEBUG - 2011-09-22 16:10:05 --> Config Class Initialized
DEBUG - 2011-09-22 16:10:05 --> Hooks Class Initialized
DEBUG - 2011-09-22 16:10:05 --> Utf8 Class Initialized
DEBUG - 2011-09-22 16:10:05 --> UTF-8 Support Enabled
DEBUG - 2011-09-22 16:10:05 --> URI Class Initialized
DEBUG - 2011-09-22 16:10:05 --> Router Class Initialized
ERROR - 2011-09-22 16:10:05 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-22 16:10:20 --> Config Class Initialized
DEBUG - 2011-09-22 16:10:20 --> Hooks Class Initialized
DEBUG - 2011-09-22 16:10:20 --> Utf8 Class Initialized
DEBUG - 2011-09-22 16:10:20 --> UTF-8 Support Enabled
DEBUG - 2011-09-22 16:10:20 --> URI Class Initialized
DEBUG - 2011-09-22 16:10:20 --> Router Class Initialized
DEBUG - 2011-09-22 16:10:20 --> Output Class Initialized
DEBUG - 2011-09-22 16:10:20 --> Input Class Initialized
DEBUG - 2011-09-22 16:10:20 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-22 16:10:20 --> Language Class Initialized
DEBUG - 2011-09-22 16:10:20 --> Loader Class Initialized
DEBUG - 2011-09-22 16:10:20 --> Controller Class Initialized
DEBUG - 2011-09-22 16:10:20 --> Model Class Initialized
DEBUG - 2011-09-22 16:10:20 --> Model Class Initialized
DEBUG - 2011-09-22 16:10:20 --> Model Class Initialized
DEBUG - 2011-09-22 16:10:20 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-22 16:10:20 --> Database Driver Class Initialized
DEBUG - 2011-09-22 16:10:21 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-22 16:10:21 --> Helper loaded: url_helper
DEBUG - 2011-09-22 16:10:21 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-22 16:10:21 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-22 16:10:21 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-22 16:10:21 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-22 16:10:21 --> Final output sent to browser
DEBUG - 2011-09-22 16:10:21 --> Total execution time: 0.2353
DEBUG - 2011-09-22 16:10:32 --> Config Class Initialized
DEBUG - 2011-09-22 16:10:32 --> Hooks Class Initialized
DEBUG - 2011-09-22 16:10:32 --> Utf8 Class Initialized
DEBUG - 2011-09-22 16:10:32 --> UTF-8 Support Enabled
DEBUG - 2011-09-22 16:10:32 --> URI Class Initialized
DEBUG - 2011-09-22 16:10:32 --> Router Class Initialized
DEBUG - 2011-09-22 16:10:32 --> Output Class Initialized
DEBUG - 2011-09-22 16:10:32 --> Input Class Initialized
DEBUG - 2011-09-22 16:10:32 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-22 16:10:32 --> Language Class Initialized
DEBUG - 2011-09-22 16:10:32 --> Loader Class Initialized
DEBUG - 2011-09-22 16:10:32 --> Controller Class Initialized
DEBUG - 2011-09-22 16:10:32 --> Model Class Initialized
DEBUG - 2011-09-22 16:10:32 --> Model Class Initialized
DEBUG - 2011-09-22 16:10:32 --> Model Class Initialized
DEBUG - 2011-09-22 16:10:32 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-22 16:10:32 --> Database Driver Class Initialized
DEBUG - 2011-09-22 16:10:33 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-22 16:10:33 --> Helper loaded: url_helper
DEBUG - 2011-09-22 16:10:33 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-22 16:10:33 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-22 16:10:33 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-22 16:10:33 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-22 16:10:33 --> Final output sent to browser
DEBUG - 2011-09-22 16:10:33 --> Total execution time: 0.2593
DEBUG - 2011-09-22 16:24:40 --> Config Class Initialized
DEBUG - 2011-09-22 16:24:40 --> Hooks Class Initialized
DEBUG - 2011-09-22 16:24:40 --> Utf8 Class Initialized
DEBUG - 2011-09-22 16:24:40 --> UTF-8 Support Enabled
DEBUG - 2011-09-22 16:24:40 --> URI Class Initialized
DEBUG - 2011-09-22 16:24:40 --> Router Class Initialized
DEBUG - 2011-09-22 16:24:40 --> Output Class Initialized
DEBUG - 2011-09-22 16:24:40 --> Input Class Initialized
DEBUG - 2011-09-22 16:24:40 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-22 16:24:40 --> Language Class Initialized
DEBUG - 2011-09-22 16:24:40 --> Loader Class Initialized
DEBUG - 2011-09-22 16:24:40 --> Controller Class Initialized
DEBUG - 2011-09-22 16:24:40 --> Model Class Initialized
DEBUG - 2011-09-22 16:24:40 --> Model Class Initialized
DEBUG - 2011-09-22 16:24:40 --> Model Class Initialized
DEBUG - 2011-09-22 16:24:40 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-22 16:24:40 --> Database Driver Class Initialized
DEBUG - 2011-09-22 16:24:40 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-22 16:24:40 --> Helper loaded: url_helper
DEBUG - 2011-09-22 16:24:40 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-22 16:24:40 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-22 16:24:40 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-22 16:24:40 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-22 16:24:40 --> Final output sent to browser
DEBUG - 2011-09-22 16:24:40 --> Total execution time: 0.0524
DEBUG - 2011-09-22 16:45:32 --> Config Class Initialized
DEBUG - 2011-09-22 16:45:32 --> Hooks Class Initialized
DEBUG - 2011-09-22 16:45:32 --> Utf8 Class Initialized
DEBUG - 2011-09-22 16:45:32 --> UTF-8 Support Enabled
DEBUG - 2011-09-22 16:45:32 --> URI Class Initialized
DEBUG - 2011-09-22 16:45:32 --> Router Class Initialized
DEBUG - 2011-09-22 16:45:32 --> Output Class Initialized
DEBUG - 2011-09-22 16:45:32 --> Input Class Initialized
DEBUG - 2011-09-22 16:45:32 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-22 16:45:32 --> Language Class Initialized
DEBUG - 2011-09-22 16:45:32 --> Loader Class Initialized
DEBUG - 2011-09-22 16:45:32 --> Controller Class Initialized
DEBUG - 2011-09-22 16:45:32 --> Model Class Initialized
DEBUG - 2011-09-22 16:45:32 --> Model Class Initialized
DEBUG - 2011-09-22 16:45:32 --> Model Class Initialized
DEBUG - 2011-09-22 16:45:32 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-22 16:45:32 --> Database Driver Class Initialized
DEBUG - 2011-09-22 16:45:33 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-22 16:45:33 --> Helper loaded: url_helper
DEBUG - 2011-09-22 16:45:33 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-22 16:45:33 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-22 16:45:33 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-22 16:45:33 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-22 16:45:33 --> Final output sent to browser
DEBUG - 2011-09-22 16:45:33 --> Total execution time: 1.0835
DEBUG - 2011-09-22 16:45:34 --> Config Class Initialized
DEBUG - 2011-09-22 16:45:34 --> Hooks Class Initialized
DEBUG - 2011-09-22 16:45:34 --> Utf8 Class Initialized
DEBUG - 2011-09-22 16:45:34 --> UTF-8 Support Enabled
DEBUG - 2011-09-22 16:45:34 --> URI Class Initialized
DEBUG - 2011-09-22 16:45:34 --> Router Class Initialized
DEBUG - 2011-09-22 16:45:34 --> Output Class Initialized
DEBUG - 2011-09-22 16:45:34 --> Input Class Initialized
DEBUG - 2011-09-22 16:45:34 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-22 16:45:34 --> Language Class Initialized
DEBUG - 2011-09-22 16:45:34 --> Loader Class Initialized
DEBUG - 2011-09-22 16:45:34 --> Controller Class Initialized
ERROR - 2011-09-22 16:45:34 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-22 16:45:34 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-22 16:45:34 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-22 16:45:34 --> Model Class Initialized
DEBUG - 2011-09-22 16:45:34 --> Model Class Initialized
DEBUG - 2011-09-22 16:45:34 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-22 16:45:34 --> Database Driver Class Initialized
DEBUG - 2011-09-22 16:45:34 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-22 16:45:34 --> Helper loaded: url_helper
DEBUG - 2011-09-22 16:45:34 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-22 16:45:34 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-22 16:45:34 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-22 16:45:34 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-22 16:45:34 --> Final output sent to browser
DEBUG - 2011-09-22 16:45:34 --> Total execution time: 0.0403
DEBUG - 2011-09-22 17:03:49 --> Config Class Initialized
DEBUG - 2011-09-22 17:03:49 --> Hooks Class Initialized
DEBUG - 2011-09-22 17:03:49 --> Utf8 Class Initialized
DEBUG - 2011-09-22 17:03:49 --> UTF-8 Support Enabled
DEBUG - 2011-09-22 17:03:49 --> URI Class Initialized
DEBUG - 2011-09-22 17:03:49 --> Router Class Initialized
DEBUG - 2011-09-22 17:03:49 --> No URI present. Default controller set.
DEBUG - 2011-09-22 17:03:49 --> Output Class Initialized
DEBUG - 2011-09-22 17:03:49 --> Input Class Initialized
DEBUG - 2011-09-22 17:03:49 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-22 17:03:49 --> Language Class Initialized
DEBUG - 2011-09-22 17:03:49 --> Loader Class Initialized
DEBUG - 2011-09-22 17:03:49 --> Controller Class Initialized
DEBUG - 2011-09-22 17:03:49 --> File loaded: application/views/splash/main.php
DEBUG - 2011-09-22 17:03:49 --> Helper loaded: url_helper
DEBUG - 2011-09-22 17:03:49 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-22 17:03:49 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-22 17:03:49 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-22 17:03:49 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-22 17:03:49 --> Final output sent to browser
DEBUG - 2011-09-22 17:03:49 --> Total execution time: 0.0719
DEBUG - 2011-09-22 17:56:39 --> Config Class Initialized
DEBUG - 2011-09-22 17:56:39 --> Hooks Class Initialized
DEBUG - 2011-09-22 17:56:39 --> Utf8 Class Initialized
DEBUG - 2011-09-22 17:56:39 --> UTF-8 Support Enabled
DEBUG - 2011-09-22 17:56:39 --> URI Class Initialized
DEBUG - 2011-09-22 17:56:39 --> Router Class Initialized
DEBUG - 2011-09-22 17:56:39 --> Output Class Initialized
DEBUG - 2011-09-22 17:56:39 --> Input Class Initialized
DEBUG - 2011-09-22 17:56:39 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-22 17:56:39 --> Language Class Initialized
DEBUG - 2011-09-22 17:56:39 --> Loader Class Initialized
DEBUG - 2011-09-22 17:56:39 --> Controller Class Initialized
DEBUG - 2011-09-22 17:56:39 --> Model Class Initialized
DEBUG - 2011-09-22 17:56:39 --> Model Class Initialized
DEBUG - 2011-09-22 17:56:39 --> Model Class Initialized
DEBUG - 2011-09-22 17:56:39 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-22 17:56:39 --> Database Driver Class Initialized
DEBUG - 2011-09-22 17:56:48 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-22 17:56:48 --> Helper loaded: url_helper
DEBUG - 2011-09-22 17:56:48 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-22 17:56:48 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-22 17:56:48 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-22 17:56:48 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-22 17:56:48 --> Final output sent to browser
DEBUG - 2011-09-22 17:56:48 --> Total execution time: 9.5228
DEBUG - 2011-09-22 17:56:50 --> Config Class Initialized
DEBUG - 2011-09-22 17:56:50 --> Hooks Class Initialized
DEBUG - 2011-09-22 17:56:50 --> Utf8 Class Initialized
DEBUG - 2011-09-22 17:56:50 --> UTF-8 Support Enabled
DEBUG - 2011-09-22 17:56:50 --> URI Class Initialized
DEBUG - 2011-09-22 17:56:50 --> Router Class Initialized
DEBUG - 2011-09-22 17:56:50 --> Output Class Initialized
DEBUG - 2011-09-22 17:56:50 --> Input Class Initialized
DEBUG - 2011-09-22 17:56:50 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-22 17:56:50 --> Language Class Initialized
DEBUG - 2011-09-22 17:56:50 --> Loader Class Initialized
DEBUG - 2011-09-22 17:56:50 --> Controller Class Initialized
ERROR - 2011-09-22 17:56:50 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-22 17:56:50 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-22 17:56:50 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-22 17:56:50 --> Model Class Initialized
DEBUG - 2011-09-22 17:56:50 --> Model Class Initialized
DEBUG - 2011-09-22 17:56:50 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-22 17:56:50 --> Database Driver Class Initialized
DEBUG - 2011-09-22 17:56:50 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-22 17:56:50 --> Helper loaded: url_helper
DEBUG - 2011-09-22 17:56:50 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-22 17:56:50 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-22 17:56:50 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-22 17:56:50 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-22 17:56:50 --> Final output sent to browser
DEBUG - 2011-09-22 17:56:50 --> Total execution time: 0.3408
DEBUG - 2011-09-22 18:08:13 --> Config Class Initialized
DEBUG - 2011-09-22 18:08:13 --> Hooks Class Initialized
DEBUG - 2011-09-22 18:08:13 --> Utf8 Class Initialized
DEBUG - 2011-09-22 18:08:13 --> UTF-8 Support Enabled
DEBUG - 2011-09-22 18:08:13 --> URI Class Initialized
DEBUG - 2011-09-22 18:08:13 --> Router Class Initialized
DEBUG - 2011-09-22 18:08:13 --> Output Class Initialized
DEBUG - 2011-09-22 18:08:13 --> Input Class Initialized
DEBUG - 2011-09-22 18:08:13 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-22 18:08:13 --> Language Class Initialized
DEBUG - 2011-09-22 18:08:13 --> Loader Class Initialized
DEBUG - 2011-09-22 18:08:13 --> Controller Class Initialized
DEBUG - 2011-09-22 18:08:13 --> Model Class Initialized
DEBUG - 2011-09-22 18:08:13 --> Model Class Initialized
DEBUG - 2011-09-22 18:08:13 --> Model Class Initialized
DEBUG - 2011-09-22 18:08:13 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-22 18:08:13 --> Database Driver Class Initialized
DEBUG - 2011-09-22 18:08:13 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-22 18:08:13 --> Helper loaded: url_helper
DEBUG - 2011-09-22 18:08:13 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-22 18:08:13 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-22 18:08:13 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-22 18:08:13 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-22 18:08:13 --> Final output sent to browser
DEBUG - 2011-09-22 18:08:13 --> Total execution time: 0.0919
DEBUG - 2011-09-22 18:08:18 --> Config Class Initialized
DEBUG - 2011-09-22 18:08:18 --> Hooks Class Initialized
DEBUG - 2011-09-22 18:08:18 --> Utf8 Class Initialized
DEBUG - 2011-09-22 18:08:18 --> UTF-8 Support Enabled
DEBUG - 2011-09-22 18:08:18 --> URI Class Initialized
DEBUG - 2011-09-22 18:08:18 --> Router Class Initialized
DEBUG - 2011-09-22 18:08:18 --> Output Class Initialized
DEBUG - 2011-09-22 18:08:18 --> Input Class Initialized
DEBUG - 2011-09-22 18:08:18 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-22 18:08:18 --> Language Class Initialized
DEBUG - 2011-09-22 18:08:18 --> Loader Class Initialized
DEBUG - 2011-09-22 18:08:18 --> Controller Class Initialized
ERROR - 2011-09-22 18:08:18 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-22 18:08:18 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-22 18:08:18 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-22 18:08:18 --> Model Class Initialized
DEBUG - 2011-09-22 18:08:18 --> Model Class Initialized
DEBUG - 2011-09-22 18:08:18 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-22 18:08:18 --> Database Driver Class Initialized
DEBUG - 2011-09-22 18:08:18 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-22 18:08:18 --> Helper loaded: url_helper
DEBUG - 2011-09-22 18:08:18 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-22 18:08:18 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-22 18:08:18 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-22 18:08:18 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-22 18:08:18 --> Final output sent to browser
DEBUG - 2011-09-22 18:08:18 --> Total execution time: 0.0454
DEBUG - 2011-09-22 18:36:14 --> Config Class Initialized
DEBUG - 2011-09-22 18:36:14 --> Hooks Class Initialized
DEBUG - 2011-09-22 18:36:14 --> Utf8 Class Initialized
DEBUG - 2011-09-22 18:36:14 --> UTF-8 Support Enabled
DEBUG - 2011-09-22 18:36:14 --> URI Class Initialized
DEBUG - 2011-09-22 18:36:14 --> Router Class Initialized
DEBUG - 2011-09-22 18:36:14 --> Output Class Initialized
DEBUG - 2011-09-22 18:36:14 --> Input Class Initialized
DEBUG - 2011-09-22 18:36:14 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-22 18:36:14 --> Language Class Initialized
DEBUG - 2011-09-22 18:36:14 --> Loader Class Initialized
DEBUG - 2011-09-22 18:36:14 --> Controller Class Initialized
ERROR - 2011-09-22 18:36:14 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-22 18:36:14 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-22 18:36:14 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-22 18:36:14 --> Model Class Initialized
DEBUG - 2011-09-22 18:36:14 --> Model Class Initialized
DEBUG - 2011-09-22 18:36:14 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-22 18:36:14 --> Database Driver Class Initialized
DEBUG - 2011-09-22 18:36:14 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-22 18:36:14 --> Helper loaded: url_helper
DEBUG - 2011-09-22 18:36:14 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-22 18:36:14 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-22 18:36:14 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-22 18:36:14 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-22 18:36:14 --> Final output sent to browser
DEBUG - 2011-09-22 18:36:14 --> Total execution time: 0.0330
DEBUG - 2011-09-22 18:36:19 --> Config Class Initialized
DEBUG - 2011-09-22 18:36:19 --> Hooks Class Initialized
DEBUG - 2011-09-22 18:36:19 --> Utf8 Class Initialized
DEBUG - 2011-09-22 18:36:19 --> UTF-8 Support Enabled
DEBUG - 2011-09-22 18:36:19 --> URI Class Initialized
DEBUG - 2011-09-22 18:36:19 --> Router Class Initialized
DEBUG - 2011-09-22 18:36:19 --> Output Class Initialized
DEBUG - 2011-09-22 18:36:19 --> Input Class Initialized
DEBUG - 2011-09-22 18:36:19 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-22 18:36:19 --> Language Class Initialized
DEBUG - 2011-09-22 18:36:19 --> Loader Class Initialized
DEBUG - 2011-09-22 18:36:19 --> Controller Class Initialized
DEBUG - 2011-09-22 18:36:19 --> Model Class Initialized
DEBUG - 2011-09-22 18:36:19 --> Model Class Initialized
DEBUG - 2011-09-22 18:36:19 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-22 18:36:19 --> Database Driver Class Initialized
DEBUG - 2011-09-22 18:36:20 --> Final output sent to browser
DEBUG - 2011-09-22 18:36:20 --> Total execution time: 0.8245
DEBUG - 2011-09-22 18:36:25 --> Config Class Initialized
DEBUG - 2011-09-22 18:36:25 --> Hooks Class Initialized
DEBUG - 2011-09-22 18:36:25 --> Utf8 Class Initialized
DEBUG - 2011-09-22 18:36:25 --> UTF-8 Support Enabled
DEBUG - 2011-09-22 18:36:25 --> URI Class Initialized
DEBUG - 2011-09-22 18:36:25 --> Router Class Initialized
ERROR - 2011-09-22 18:36:25 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-22 20:33:23 --> Config Class Initialized
DEBUG - 2011-09-22 20:33:23 --> Hooks Class Initialized
DEBUG - 2011-09-22 20:33:23 --> Utf8 Class Initialized
DEBUG - 2011-09-22 20:33:23 --> UTF-8 Support Enabled
DEBUG - 2011-09-22 20:33:23 --> URI Class Initialized
DEBUG - 2011-09-22 20:33:23 --> Router Class Initialized
DEBUG - 2011-09-22 20:33:23 --> Output Class Initialized
DEBUG - 2011-09-22 20:33:23 --> Input Class Initialized
DEBUG - 2011-09-22 20:33:23 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-22 20:33:23 --> Language Class Initialized
DEBUG - 2011-09-22 20:33:23 --> Loader Class Initialized
DEBUG - 2011-09-22 20:33:23 --> Controller Class Initialized
DEBUG - 2011-09-22 20:33:23 --> Model Class Initialized
DEBUG - 2011-09-22 20:33:23 --> Model Class Initialized
DEBUG - 2011-09-22 20:33:23 --> Model Class Initialized
DEBUG - 2011-09-22 20:33:23 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-22 20:33:23 --> Database Driver Class Initialized
DEBUG - 2011-09-22 20:33:24 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-22 20:33:24 --> Helper loaded: url_helper
DEBUG - 2011-09-22 20:33:24 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-22 20:33:24 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-22 20:33:24 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-22 20:33:24 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-22 20:33:24 --> Final output sent to browser
DEBUG - 2011-09-22 20:33:24 --> Total execution time: 1.4469
DEBUG - 2011-09-22 20:33:33 --> Config Class Initialized
DEBUG - 2011-09-22 20:33:33 --> Hooks Class Initialized
DEBUG - 2011-09-22 20:33:33 --> Utf8 Class Initialized
DEBUG - 2011-09-22 20:33:33 --> UTF-8 Support Enabled
DEBUG - 2011-09-22 20:33:33 --> URI Class Initialized
DEBUG - 2011-09-22 20:33:33 --> Router Class Initialized
ERROR - 2011-09-22 20:33:33 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-22 20:33:36 --> Config Class Initialized
DEBUG - 2011-09-22 20:33:36 --> Hooks Class Initialized
DEBUG - 2011-09-22 20:33:36 --> Utf8 Class Initialized
DEBUG - 2011-09-22 20:33:36 --> UTF-8 Support Enabled
DEBUG - 2011-09-22 20:33:36 --> URI Class Initialized
DEBUG - 2011-09-22 20:33:36 --> Router Class Initialized
ERROR - 2011-09-22 20:33:36 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-22 20:34:12 --> Config Class Initialized
DEBUG - 2011-09-22 20:34:12 --> Hooks Class Initialized
DEBUG - 2011-09-22 20:34:12 --> Utf8 Class Initialized
DEBUG - 2011-09-22 20:34:12 --> UTF-8 Support Enabled
DEBUG - 2011-09-22 20:34:12 --> URI Class Initialized
DEBUG - 2011-09-22 20:34:12 --> Router Class Initialized
DEBUG - 2011-09-22 20:34:12 --> Output Class Initialized
DEBUG - 2011-09-22 20:34:12 --> Input Class Initialized
DEBUG - 2011-09-22 20:34:12 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-22 20:34:12 --> Language Class Initialized
DEBUG - 2011-09-22 20:34:12 --> Loader Class Initialized
DEBUG - 2011-09-22 20:34:12 --> Controller Class Initialized
DEBUG - 2011-09-22 20:34:12 --> Model Class Initialized
DEBUG - 2011-09-22 20:34:12 --> Model Class Initialized
DEBUG - 2011-09-22 20:34:12 --> Model Class Initialized
DEBUG - 2011-09-22 20:34:12 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-22 20:34:12 --> Database Driver Class Initialized
DEBUG - 2011-09-22 20:34:12 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-22 20:34:12 --> Helper loaded: url_helper
DEBUG - 2011-09-22 20:34:12 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-22 20:34:12 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-22 20:34:12 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-22 20:34:12 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-22 20:34:12 --> Final output sent to browser
DEBUG - 2011-09-22 20:34:12 --> Total execution time: 0.2568
DEBUG - 2011-09-22 20:34:14 --> Config Class Initialized
DEBUG - 2011-09-22 20:34:14 --> Hooks Class Initialized
DEBUG - 2011-09-22 20:34:14 --> Utf8 Class Initialized
DEBUG - 2011-09-22 20:34:14 --> UTF-8 Support Enabled
DEBUG - 2011-09-22 20:34:14 --> URI Class Initialized
DEBUG - 2011-09-22 20:34:14 --> Router Class Initialized
ERROR - 2011-09-22 20:34:14 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-09-22 20:34:14 --> Config Class Initialized
DEBUG - 2011-09-22 20:34:14 --> Hooks Class Initialized
DEBUG - 2011-09-22 20:34:14 --> Utf8 Class Initialized
DEBUG - 2011-09-22 20:34:14 --> UTF-8 Support Enabled
DEBUG - 2011-09-22 20:34:14 --> URI Class Initialized
DEBUG - 2011-09-22 20:34:14 --> Router Class Initialized
DEBUG - 2011-09-22 20:34:14 --> Output Class Initialized
DEBUG - 2011-09-22 20:34:14 --> Input Class Initialized
DEBUG - 2011-09-22 20:34:14 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-22 20:34:14 --> Language Class Initialized
DEBUG - 2011-09-22 20:34:14 --> Loader Class Initialized
DEBUG - 2011-09-22 20:34:14 --> Controller Class Initialized
DEBUG - 2011-09-22 20:34:14 --> Model Class Initialized
DEBUG - 2011-09-22 20:34:14 --> Model Class Initialized
DEBUG - 2011-09-22 20:34:14 --> Model Class Initialized
DEBUG - 2011-09-22 20:34:14 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-22 20:34:14 --> Database Driver Class Initialized
DEBUG - 2011-09-22 20:34:14 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-22 20:34:14 --> Helper loaded: url_helper
DEBUG - 2011-09-22 20:34:14 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-22 20:34:14 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-22 20:34:14 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-22 20:34:14 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-22 20:34:14 --> Final output sent to browser
DEBUG - 2011-09-22 20:34:14 --> Total execution time: 0.0477
DEBUG - 2011-09-22 20:34:17 --> Config Class Initialized
DEBUG - 2011-09-22 20:34:17 --> Hooks Class Initialized
DEBUG - 2011-09-22 20:34:17 --> Utf8 Class Initialized
DEBUG - 2011-09-22 20:34:17 --> UTF-8 Support Enabled
DEBUG - 2011-09-22 20:34:17 --> URI Class Initialized
DEBUG - 2011-09-22 20:34:17 --> Router Class Initialized
ERROR - 2011-09-22 20:34:17 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-22 20:34:46 --> Config Class Initialized
DEBUG - 2011-09-22 20:34:46 --> Hooks Class Initialized
DEBUG - 2011-09-22 20:34:46 --> Utf8 Class Initialized
DEBUG - 2011-09-22 20:34:46 --> UTF-8 Support Enabled
DEBUG - 2011-09-22 20:34:46 --> URI Class Initialized
DEBUG - 2011-09-22 20:34:46 --> Router Class Initialized
DEBUG - 2011-09-22 20:34:46 --> Output Class Initialized
DEBUG - 2011-09-22 20:34:46 --> Input Class Initialized
DEBUG - 2011-09-22 20:34:46 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-22 20:34:46 --> Language Class Initialized
DEBUG - 2011-09-22 20:34:46 --> Loader Class Initialized
DEBUG - 2011-09-22 20:34:46 --> Controller Class Initialized
DEBUG - 2011-09-22 20:34:46 --> Model Class Initialized
DEBUG - 2011-09-22 20:34:46 --> Model Class Initialized
DEBUG - 2011-09-22 20:34:46 --> Model Class Initialized
DEBUG - 2011-09-22 20:34:46 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-22 20:34:46 --> Database Driver Class Initialized
DEBUG - 2011-09-22 20:34:46 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-22 20:34:46 --> Helper loaded: url_helper
DEBUG - 2011-09-22 20:34:46 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-22 20:34:46 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-22 20:34:46 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-22 20:34:46 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-22 20:34:46 --> Final output sent to browser
DEBUG - 2011-09-22 20:34:46 --> Total execution time: 0.3931
DEBUG - 2011-09-22 20:34:49 --> Config Class Initialized
DEBUG - 2011-09-22 20:34:49 --> Hooks Class Initialized
DEBUG - 2011-09-22 20:34:49 --> Utf8 Class Initialized
DEBUG - 2011-09-22 20:34:49 --> UTF-8 Support Enabled
DEBUG - 2011-09-22 20:34:49 --> URI Class Initialized
DEBUG - 2011-09-22 20:34:49 --> Router Class Initialized
ERROR - 2011-09-22 20:34:49 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-22 20:34:59 --> Config Class Initialized
DEBUG - 2011-09-22 20:34:59 --> Hooks Class Initialized
DEBUG - 2011-09-22 20:34:59 --> Utf8 Class Initialized
DEBUG - 2011-09-22 20:34:59 --> UTF-8 Support Enabled
DEBUG - 2011-09-22 20:34:59 --> URI Class Initialized
DEBUG - 2011-09-22 20:34:59 --> Router Class Initialized
DEBUG - 2011-09-22 20:34:59 --> Output Class Initialized
DEBUG - 2011-09-22 20:34:59 --> Input Class Initialized
DEBUG - 2011-09-22 20:34:59 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-22 20:34:59 --> Language Class Initialized
DEBUG - 2011-09-22 20:34:59 --> Loader Class Initialized
DEBUG - 2011-09-22 20:34:59 --> Controller Class Initialized
DEBUG - 2011-09-22 20:34:59 --> Model Class Initialized
DEBUG - 2011-09-22 20:34:59 --> Model Class Initialized
DEBUG - 2011-09-22 20:34:59 --> Model Class Initialized
DEBUG - 2011-09-22 20:34:59 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-22 20:34:59 --> Database Driver Class Initialized
DEBUG - 2011-09-22 20:34:59 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-22 20:34:59 --> Helper loaded: url_helper
DEBUG - 2011-09-22 20:34:59 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-22 20:34:59 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-22 20:34:59 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-22 20:34:59 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-22 20:34:59 --> Final output sent to browser
DEBUG - 2011-09-22 20:34:59 --> Total execution time: 0.4829
DEBUG - 2011-09-22 20:35:02 --> Config Class Initialized
DEBUG - 2011-09-22 20:35:02 --> Hooks Class Initialized
DEBUG - 2011-09-22 20:35:03 --> Utf8 Class Initialized
DEBUG - 2011-09-22 20:35:03 --> UTF-8 Support Enabled
DEBUG - 2011-09-22 20:35:03 --> URI Class Initialized
DEBUG - 2011-09-22 20:35:03 --> Router Class Initialized
ERROR - 2011-09-22 20:35:03 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-22 20:35:03 --> Config Class Initialized
DEBUG - 2011-09-22 20:35:03 --> Hooks Class Initialized
DEBUG - 2011-09-22 20:35:03 --> Utf8 Class Initialized
DEBUG - 2011-09-22 20:35:03 --> UTF-8 Support Enabled
DEBUG - 2011-09-22 20:35:03 --> URI Class Initialized
DEBUG - 2011-09-22 20:35:03 --> Router Class Initialized
ERROR - 2011-09-22 20:35:03 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-22 20:35:18 --> Config Class Initialized
DEBUG - 2011-09-22 20:35:18 --> Hooks Class Initialized
DEBUG - 2011-09-22 20:35:18 --> Utf8 Class Initialized
DEBUG - 2011-09-22 20:35:18 --> UTF-8 Support Enabled
DEBUG - 2011-09-22 20:35:18 --> URI Class Initialized
DEBUG - 2011-09-22 20:35:18 --> Router Class Initialized
DEBUG - 2011-09-22 20:35:18 --> Output Class Initialized
DEBUG - 2011-09-22 20:35:18 --> Input Class Initialized
DEBUG - 2011-09-22 20:35:18 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-22 20:35:18 --> Language Class Initialized
DEBUG - 2011-09-22 20:35:18 --> Loader Class Initialized
DEBUG - 2011-09-22 20:35:18 --> Controller Class Initialized
DEBUG - 2011-09-22 20:35:18 --> Model Class Initialized
DEBUG - 2011-09-22 20:35:18 --> Model Class Initialized
DEBUG - 2011-09-22 20:35:18 --> Model Class Initialized
DEBUG - 2011-09-22 20:35:18 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-22 20:35:18 --> Database Driver Class Initialized
DEBUG - 2011-09-22 20:35:18 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-22 20:35:18 --> Helper loaded: url_helper
DEBUG - 2011-09-22 20:35:18 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-22 20:35:18 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-22 20:35:18 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-22 20:35:18 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-22 20:35:18 --> Final output sent to browser
DEBUG - 2011-09-22 20:35:18 --> Total execution time: 0.2324
DEBUG - 2011-09-22 20:35:22 --> Config Class Initialized
DEBUG - 2011-09-22 20:35:22 --> Hooks Class Initialized
DEBUG - 2011-09-22 20:35:22 --> Utf8 Class Initialized
DEBUG - 2011-09-22 20:35:22 --> UTF-8 Support Enabled
DEBUG - 2011-09-22 20:35:22 --> URI Class Initialized
DEBUG - 2011-09-22 20:35:22 --> Router Class Initialized
ERROR - 2011-09-22 20:35:22 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-22 20:35:30 --> Config Class Initialized
DEBUG - 2011-09-22 20:35:30 --> Hooks Class Initialized
DEBUG - 2011-09-22 20:35:30 --> Utf8 Class Initialized
DEBUG - 2011-09-22 20:35:30 --> UTF-8 Support Enabled
DEBUG - 2011-09-22 20:35:30 --> URI Class Initialized
DEBUG - 2011-09-22 20:35:30 --> Router Class Initialized
DEBUG - 2011-09-22 20:35:30 --> Output Class Initialized
DEBUG - 2011-09-22 20:35:30 --> Input Class Initialized
DEBUG - 2011-09-22 20:35:30 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-22 20:35:30 --> Language Class Initialized
DEBUG - 2011-09-22 20:35:30 --> Loader Class Initialized
DEBUG - 2011-09-22 20:35:30 --> Controller Class Initialized
DEBUG - 2011-09-22 20:35:30 --> Model Class Initialized
DEBUG - 2011-09-22 20:35:30 --> Model Class Initialized
DEBUG - 2011-09-22 20:35:30 --> Model Class Initialized
DEBUG - 2011-09-22 20:35:30 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-22 20:35:30 --> Database Driver Class Initialized
DEBUG - 2011-09-22 20:35:30 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-22 20:35:30 --> Helper loaded: url_helper
DEBUG - 2011-09-22 20:35:30 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-22 20:35:30 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-22 20:35:30 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-22 20:35:30 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-22 20:35:30 --> Final output sent to browser
DEBUG - 2011-09-22 20:35:30 --> Total execution time: 0.2957
DEBUG - 2011-09-22 20:35:34 --> Config Class Initialized
DEBUG - 2011-09-22 20:35:34 --> Hooks Class Initialized
DEBUG - 2011-09-22 20:35:34 --> Utf8 Class Initialized
DEBUG - 2011-09-22 20:35:34 --> UTF-8 Support Enabled
DEBUG - 2011-09-22 20:35:34 --> URI Class Initialized
DEBUG - 2011-09-22 20:35:34 --> Router Class Initialized
ERROR - 2011-09-22 20:35:34 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-22 20:35:51 --> Config Class Initialized
DEBUG - 2011-09-22 20:35:51 --> Hooks Class Initialized
DEBUG - 2011-09-22 20:35:51 --> Utf8 Class Initialized
DEBUG - 2011-09-22 20:35:51 --> UTF-8 Support Enabled
DEBUG - 2011-09-22 20:35:51 --> URI Class Initialized
DEBUG - 2011-09-22 20:35:51 --> Router Class Initialized
DEBUG - 2011-09-22 20:35:51 --> Output Class Initialized
DEBUG - 2011-09-22 20:35:51 --> Input Class Initialized
DEBUG - 2011-09-22 20:35:51 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-22 20:35:51 --> Language Class Initialized
DEBUG - 2011-09-22 20:35:51 --> Loader Class Initialized
DEBUG - 2011-09-22 20:35:51 --> Controller Class Initialized
DEBUG - 2011-09-22 20:35:51 --> Model Class Initialized
DEBUG - 2011-09-22 20:35:51 --> Model Class Initialized
DEBUG - 2011-09-22 20:35:51 --> Model Class Initialized
DEBUG - 2011-09-22 20:35:51 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-22 20:35:51 --> Database Driver Class Initialized
DEBUG - 2011-09-22 20:35:51 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-22 20:35:51 --> Helper loaded: url_helper
DEBUG - 2011-09-22 20:35:51 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-22 20:35:51 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-22 20:35:51 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-22 20:35:51 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-22 20:35:51 --> Final output sent to browser
DEBUG - 2011-09-22 20:35:51 --> Total execution time: 0.0471
DEBUG - 2011-09-22 20:35:55 --> Config Class Initialized
DEBUG - 2011-09-22 20:35:55 --> Hooks Class Initialized
DEBUG - 2011-09-22 20:35:55 --> Utf8 Class Initialized
DEBUG - 2011-09-22 20:35:55 --> UTF-8 Support Enabled
DEBUG - 2011-09-22 20:35:55 --> URI Class Initialized
DEBUG - 2011-09-22 20:35:55 --> Router Class Initialized
ERROR - 2011-09-22 20:35:55 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-22 20:35:55 --> Config Class Initialized
DEBUG - 2011-09-22 20:35:55 --> Hooks Class Initialized
DEBUG - 2011-09-22 20:35:55 --> Utf8 Class Initialized
DEBUG - 2011-09-22 20:35:55 --> UTF-8 Support Enabled
DEBUG - 2011-09-22 20:35:55 --> URI Class Initialized
DEBUG - 2011-09-22 20:35:55 --> Router Class Initialized
ERROR - 2011-09-22 20:35:55 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-22 20:35:59 --> Config Class Initialized
DEBUG - 2011-09-22 20:35:59 --> Hooks Class Initialized
DEBUG - 2011-09-22 20:35:59 --> Utf8 Class Initialized
DEBUG - 2011-09-22 20:35:59 --> UTF-8 Support Enabled
DEBUG - 2011-09-22 20:35:59 --> URI Class Initialized
DEBUG - 2011-09-22 20:35:59 --> Router Class Initialized
DEBUG - 2011-09-22 20:35:59 --> Output Class Initialized
DEBUG - 2011-09-22 20:35:59 --> Input Class Initialized
DEBUG - 2011-09-22 20:35:59 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-22 20:35:59 --> Language Class Initialized
DEBUG - 2011-09-22 20:35:59 --> Loader Class Initialized
DEBUG - 2011-09-22 20:35:59 --> Controller Class Initialized
DEBUG - 2011-09-22 20:35:59 --> Model Class Initialized
DEBUG - 2011-09-22 20:35:59 --> Model Class Initialized
DEBUG - 2011-09-22 20:35:59 --> Model Class Initialized
DEBUG - 2011-09-22 20:35:59 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-22 20:36:00 --> Database Driver Class Initialized
DEBUG - 2011-09-22 20:36:00 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-22 20:36:00 --> Helper loaded: url_helper
DEBUG - 2011-09-22 20:36:00 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-22 20:36:00 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-22 20:36:00 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-22 20:36:00 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-22 20:36:00 --> Final output sent to browser
DEBUG - 2011-09-22 20:36:00 --> Total execution time: 0.3761
DEBUG - 2011-09-22 20:36:03 --> Config Class Initialized
DEBUG - 2011-09-22 20:36:03 --> Hooks Class Initialized
DEBUG - 2011-09-22 20:36:03 --> Utf8 Class Initialized
DEBUG - 2011-09-22 20:36:03 --> UTF-8 Support Enabled
DEBUG - 2011-09-22 20:36:03 --> URI Class Initialized
DEBUG - 2011-09-22 20:36:03 --> Router Class Initialized
ERROR - 2011-09-22 20:36:03 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-22 20:36:30 --> Config Class Initialized
DEBUG - 2011-09-22 20:36:30 --> Hooks Class Initialized
DEBUG - 2011-09-22 20:36:30 --> Utf8 Class Initialized
DEBUG - 2011-09-22 20:36:30 --> UTF-8 Support Enabled
DEBUG - 2011-09-22 20:36:30 --> URI Class Initialized
DEBUG - 2011-09-22 20:36:30 --> Router Class Initialized
DEBUG - 2011-09-22 20:36:30 --> Output Class Initialized
DEBUG - 2011-09-22 20:36:30 --> Input Class Initialized
DEBUG - 2011-09-22 20:36:30 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-22 20:36:30 --> Language Class Initialized
DEBUG - 2011-09-22 20:36:30 --> Loader Class Initialized
DEBUG - 2011-09-22 20:36:30 --> Controller Class Initialized
DEBUG - 2011-09-22 20:36:30 --> Model Class Initialized
DEBUG - 2011-09-22 20:36:30 --> Model Class Initialized
DEBUG - 2011-09-22 20:36:30 --> Model Class Initialized
DEBUG - 2011-09-22 20:36:30 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-22 20:36:30 --> Database Driver Class Initialized
DEBUG - 2011-09-22 20:36:31 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-22 20:36:31 --> Helper loaded: url_helper
DEBUG - 2011-09-22 20:36:31 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-22 20:36:31 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-22 20:36:31 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-22 20:36:31 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-22 20:36:31 --> Final output sent to browser
DEBUG - 2011-09-22 20:36:31 --> Total execution time: 0.8958
DEBUG - 2011-09-22 20:36:34 --> Config Class Initialized
DEBUG - 2011-09-22 20:36:34 --> Hooks Class Initialized
DEBUG - 2011-09-22 20:36:34 --> Utf8 Class Initialized
DEBUG - 2011-09-22 20:36:34 --> UTF-8 Support Enabled
DEBUG - 2011-09-22 20:36:34 --> URI Class Initialized
DEBUG - 2011-09-22 20:36:34 --> Router Class Initialized
ERROR - 2011-09-22 20:36:34 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-22 20:36:59 --> Config Class Initialized
DEBUG - 2011-09-22 20:36:59 --> Hooks Class Initialized
DEBUG - 2011-09-22 20:36:59 --> Utf8 Class Initialized
DEBUG - 2011-09-22 20:36:59 --> UTF-8 Support Enabled
DEBUG - 2011-09-22 20:36:59 --> URI Class Initialized
DEBUG - 2011-09-22 20:36:59 --> Router Class Initialized
DEBUG - 2011-09-22 20:36:59 --> Output Class Initialized
DEBUG - 2011-09-22 20:36:59 --> Input Class Initialized
DEBUG - 2011-09-22 20:36:59 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-22 20:36:59 --> Language Class Initialized
DEBUG - 2011-09-22 20:36:59 --> Loader Class Initialized
DEBUG - 2011-09-22 20:36:59 --> Controller Class Initialized
DEBUG - 2011-09-22 20:36:59 --> Model Class Initialized
DEBUG - 2011-09-22 20:36:59 --> Model Class Initialized
DEBUG - 2011-09-22 20:36:59 --> Model Class Initialized
DEBUG - 2011-09-22 20:36:59 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-22 20:36:59 --> Database Driver Class Initialized
DEBUG - 2011-09-22 20:37:00 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-22 20:37:00 --> Helper loaded: url_helper
DEBUG - 2011-09-22 20:37:00 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-22 20:37:00 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-22 20:37:00 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-22 20:37:00 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-22 20:37:00 --> Final output sent to browser
DEBUG - 2011-09-22 20:37:00 --> Total execution time: 1.3359
DEBUG - 2011-09-22 20:37:07 --> Config Class Initialized
DEBUG - 2011-09-22 20:37:07 --> Hooks Class Initialized
DEBUG - 2011-09-22 20:37:07 --> Utf8 Class Initialized
DEBUG - 2011-09-22 20:37:07 --> UTF-8 Support Enabled
DEBUG - 2011-09-22 20:37:07 --> URI Class Initialized
DEBUG - 2011-09-22 20:37:07 --> Router Class Initialized
ERROR - 2011-09-22 20:37:07 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-22 20:37:24 --> Config Class Initialized
DEBUG - 2011-09-22 20:37:24 --> Hooks Class Initialized
DEBUG - 2011-09-22 20:37:24 --> Utf8 Class Initialized
DEBUG - 2011-09-22 20:37:24 --> UTF-8 Support Enabled
DEBUG - 2011-09-22 20:37:24 --> URI Class Initialized
DEBUG - 2011-09-22 20:37:24 --> Router Class Initialized
DEBUG - 2011-09-22 20:37:24 --> Output Class Initialized
DEBUG - 2011-09-22 20:37:24 --> Input Class Initialized
DEBUG - 2011-09-22 20:37:24 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-22 20:37:24 --> Language Class Initialized
DEBUG - 2011-09-22 20:37:24 --> Loader Class Initialized
DEBUG - 2011-09-22 20:37:24 --> Controller Class Initialized
DEBUG - 2011-09-22 20:37:24 --> Model Class Initialized
DEBUG - 2011-09-22 20:37:24 --> Model Class Initialized
DEBUG - 2011-09-22 20:37:24 --> Model Class Initialized
DEBUG - 2011-09-22 20:37:24 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-22 20:37:24 --> Database Driver Class Initialized
DEBUG - 2011-09-22 20:37:24 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-22 20:37:24 --> Helper loaded: url_helper
DEBUG - 2011-09-22 20:37:24 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-22 20:37:24 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-22 20:37:24 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-22 20:37:24 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-22 20:37:24 --> Final output sent to browser
DEBUG - 2011-09-22 20:37:24 --> Total execution time: 0.3223
DEBUG - 2011-09-22 20:37:28 --> Config Class Initialized
DEBUG - 2011-09-22 20:37:28 --> Hooks Class Initialized
DEBUG - 2011-09-22 20:37:28 --> Utf8 Class Initialized
DEBUG - 2011-09-22 20:37:28 --> UTF-8 Support Enabled
DEBUG - 2011-09-22 20:37:28 --> URI Class Initialized
DEBUG - 2011-09-22 20:37:28 --> Router Class Initialized
ERROR - 2011-09-22 20:37:28 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-22 20:37:40 --> Config Class Initialized
DEBUG - 2011-09-22 20:37:40 --> Hooks Class Initialized
DEBUG - 2011-09-22 20:37:40 --> Utf8 Class Initialized
DEBUG - 2011-09-22 20:37:40 --> UTF-8 Support Enabled
DEBUG - 2011-09-22 20:37:40 --> URI Class Initialized
DEBUG - 2011-09-22 20:37:40 --> Router Class Initialized
DEBUG - 2011-09-22 20:37:40 --> Output Class Initialized
DEBUG - 2011-09-22 20:37:40 --> Input Class Initialized
DEBUG - 2011-09-22 20:37:40 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-22 20:37:40 --> Language Class Initialized
DEBUG - 2011-09-22 20:37:40 --> Loader Class Initialized
DEBUG - 2011-09-22 20:37:40 --> Controller Class Initialized
DEBUG - 2011-09-22 20:37:40 --> Model Class Initialized
DEBUG - 2011-09-22 20:37:40 --> Model Class Initialized
DEBUG - 2011-09-22 20:37:40 --> Model Class Initialized
DEBUG - 2011-09-22 20:37:40 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-22 20:37:40 --> Database Driver Class Initialized
DEBUG - 2011-09-22 20:37:41 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-22 20:37:41 --> Helper loaded: url_helper
DEBUG - 2011-09-22 20:37:41 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-22 20:37:41 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-22 20:37:41 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-22 20:37:41 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-22 20:37:41 --> Final output sent to browser
DEBUG - 2011-09-22 20:37:41 --> Total execution time: 0.5023
DEBUG - 2011-09-22 20:37:45 --> Config Class Initialized
DEBUG - 2011-09-22 20:37:45 --> Hooks Class Initialized
DEBUG - 2011-09-22 20:37:45 --> Utf8 Class Initialized
DEBUG - 2011-09-22 20:37:45 --> UTF-8 Support Enabled
DEBUG - 2011-09-22 20:37:45 --> URI Class Initialized
DEBUG - 2011-09-22 20:37:45 --> Router Class Initialized
ERROR - 2011-09-22 20:37:45 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-22 20:38:01 --> Config Class Initialized
DEBUG - 2011-09-22 20:38:01 --> Hooks Class Initialized
DEBUG - 2011-09-22 20:38:01 --> Utf8 Class Initialized
DEBUG - 2011-09-22 20:38:01 --> UTF-8 Support Enabled
DEBUG - 2011-09-22 20:38:01 --> URI Class Initialized
DEBUG - 2011-09-22 20:38:01 --> Router Class Initialized
DEBUG - 2011-09-22 20:38:01 --> Output Class Initialized
DEBUG - 2011-09-22 20:38:01 --> Input Class Initialized
DEBUG - 2011-09-22 20:38:01 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-22 20:38:01 --> Language Class Initialized
DEBUG - 2011-09-22 20:38:01 --> Loader Class Initialized
DEBUG - 2011-09-22 20:38:01 --> Controller Class Initialized
DEBUG - 2011-09-22 20:38:01 --> Model Class Initialized
DEBUG - 2011-09-22 20:38:01 --> Model Class Initialized
DEBUG - 2011-09-22 20:38:01 --> Model Class Initialized
DEBUG - 2011-09-22 20:38:01 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-22 20:38:01 --> Database Driver Class Initialized
DEBUG - 2011-09-22 20:38:02 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-22 20:38:02 --> Helper loaded: url_helper
DEBUG - 2011-09-22 20:38:02 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-22 20:38:02 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-22 20:38:02 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-22 20:38:02 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-22 20:38:02 --> Final output sent to browser
DEBUG - 2011-09-22 20:38:02 --> Total execution time: 0.6258
DEBUG - 2011-09-22 20:38:05 --> Config Class Initialized
DEBUG - 2011-09-22 20:38:05 --> Hooks Class Initialized
DEBUG - 2011-09-22 20:38:05 --> Utf8 Class Initialized
DEBUG - 2011-09-22 20:38:05 --> UTF-8 Support Enabled
DEBUG - 2011-09-22 20:38:05 --> URI Class Initialized
DEBUG - 2011-09-22 20:38:05 --> Router Class Initialized
ERROR - 2011-09-22 20:38:05 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-22 20:38:36 --> Config Class Initialized
DEBUG - 2011-09-22 20:38:36 --> Hooks Class Initialized
DEBUG - 2011-09-22 20:38:36 --> Utf8 Class Initialized
DEBUG - 2011-09-22 20:38:36 --> UTF-8 Support Enabled
DEBUG - 2011-09-22 20:38:36 --> URI Class Initialized
DEBUG - 2011-09-22 20:38:36 --> Router Class Initialized
DEBUG - 2011-09-22 20:38:36 --> Output Class Initialized
DEBUG - 2011-09-22 20:38:36 --> Input Class Initialized
DEBUG - 2011-09-22 20:38:36 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-22 20:38:36 --> Language Class Initialized
DEBUG - 2011-09-22 20:38:36 --> Loader Class Initialized
DEBUG - 2011-09-22 20:38:36 --> Controller Class Initialized
DEBUG - 2011-09-22 20:38:36 --> Model Class Initialized
DEBUG - 2011-09-22 20:38:36 --> Model Class Initialized
DEBUG - 2011-09-22 20:38:36 --> Model Class Initialized
DEBUG - 2011-09-22 20:38:36 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-22 20:38:36 --> Database Driver Class Initialized
DEBUG - 2011-09-22 20:38:37 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-22 20:38:37 --> Helper loaded: url_helper
DEBUG - 2011-09-22 20:38:37 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-22 20:38:37 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-22 20:38:37 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-22 20:38:37 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-22 20:38:37 --> Final output sent to browser
DEBUG - 2011-09-22 20:38:37 --> Total execution time: 1.3450
DEBUG - 2011-09-22 20:38:39 --> Config Class Initialized
DEBUG - 2011-09-22 20:38:39 --> Hooks Class Initialized
DEBUG - 2011-09-22 20:38:39 --> Utf8 Class Initialized
DEBUG - 2011-09-22 20:38:39 --> UTF-8 Support Enabled
DEBUG - 2011-09-22 20:38:39 --> URI Class Initialized
DEBUG - 2011-09-22 20:38:39 --> Router Class Initialized
ERROR - 2011-09-22 20:38:39 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-22 21:22:09 --> Config Class Initialized
DEBUG - 2011-09-22 21:22:09 --> Hooks Class Initialized
DEBUG - 2011-09-22 21:22:09 --> Utf8 Class Initialized
DEBUG - 2011-09-22 21:22:09 --> UTF-8 Support Enabled
DEBUG - 2011-09-22 21:22:09 --> URI Class Initialized
DEBUG - 2011-09-22 21:22:09 --> Router Class Initialized
ERROR - 2011-09-22 21:22:09 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-09-22 21:24:23 --> Config Class Initialized
DEBUG - 2011-09-22 21:24:23 --> Hooks Class Initialized
DEBUG - 2011-09-22 21:24:23 --> Utf8 Class Initialized
DEBUG - 2011-09-22 21:24:23 --> UTF-8 Support Enabled
DEBUG - 2011-09-22 21:24:23 --> URI Class Initialized
DEBUG - 2011-09-22 21:24:23 --> Router Class Initialized
ERROR - 2011-09-22 21:24:23 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-09-22 21:24:24 --> Config Class Initialized
DEBUG - 2011-09-22 21:24:24 --> Hooks Class Initialized
DEBUG - 2011-09-22 21:24:24 --> Utf8 Class Initialized
DEBUG - 2011-09-22 21:24:24 --> UTF-8 Support Enabled
DEBUG - 2011-09-22 21:24:24 --> URI Class Initialized
DEBUG - 2011-09-22 21:24:24 --> Router Class Initialized
DEBUG - 2011-09-22 21:24:24 --> Output Class Initialized
DEBUG - 2011-09-22 21:24:24 --> Input Class Initialized
DEBUG - 2011-09-22 21:24:24 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-22 21:24:24 --> Language Class Initialized
DEBUG - 2011-09-22 21:24:24 --> Loader Class Initialized
DEBUG - 2011-09-22 21:24:24 --> Controller Class Initialized
ERROR - 2011-09-22 21:24:24 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-22 21:24:24 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-22 21:24:24 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-22 21:24:24 --> Model Class Initialized
DEBUG - 2011-09-22 21:24:24 --> Model Class Initialized
DEBUG - 2011-09-22 21:24:24 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-22 21:24:24 --> Database Driver Class Initialized
DEBUG - 2011-09-22 21:24:24 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-22 21:24:24 --> Helper loaded: url_helper
DEBUG - 2011-09-22 21:24:24 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-22 21:24:24 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-22 21:24:24 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-22 21:24:24 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-22 21:24:24 --> Final output sent to browser
DEBUG - 2011-09-22 21:24:24 --> Total execution time: 0.4793
DEBUG - 2011-09-22 21:46:04 --> Config Class Initialized
DEBUG - 2011-09-22 21:46:04 --> Hooks Class Initialized
DEBUG - 2011-09-22 21:46:04 --> Utf8 Class Initialized
DEBUG - 2011-09-22 21:46:04 --> UTF-8 Support Enabled
DEBUG - 2011-09-22 21:46:04 --> URI Class Initialized
DEBUG - 2011-09-22 21:46:04 --> Router Class Initialized
DEBUG - 2011-09-22 21:46:04 --> Output Class Initialized
DEBUG - 2011-09-22 21:46:04 --> Input Class Initialized
DEBUG - 2011-09-22 21:46:04 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-22 21:46:04 --> Language Class Initialized
DEBUG - 2011-09-22 21:46:04 --> Loader Class Initialized
DEBUG - 2011-09-22 21:46:04 --> Controller Class Initialized
ERROR - 2011-09-22 21:46:04 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-22 21:46:04 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-22 21:46:04 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-22 21:46:04 --> Model Class Initialized
DEBUG - 2011-09-22 21:46:04 --> Model Class Initialized
DEBUG - 2011-09-22 21:46:04 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-22 21:46:04 --> Database Driver Class Initialized
DEBUG - 2011-09-22 21:46:04 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-22 21:46:04 --> Helper loaded: url_helper
DEBUG - 2011-09-22 21:46:04 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-22 21:46:04 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-22 21:46:04 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-22 21:46:04 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-22 21:46:04 --> Final output sent to browser
DEBUG - 2011-09-22 21:46:04 --> Total execution time: 0.0340
DEBUG - 2011-09-22 22:05:42 --> Config Class Initialized
DEBUG - 2011-09-22 22:05:42 --> Hooks Class Initialized
DEBUG - 2011-09-22 22:05:42 --> Utf8 Class Initialized
DEBUG - 2011-09-22 22:05:42 --> UTF-8 Support Enabled
DEBUG - 2011-09-22 22:05:42 --> URI Class Initialized
DEBUG - 2011-09-22 22:05:42 --> Router Class Initialized
DEBUG - 2011-09-22 22:05:42 --> Output Class Initialized
DEBUG - 2011-09-22 22:05:42 --> Input Class Initialized
DEBUG - 2011-09-22 22:05:42 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-22 22:05:42 --> Language Class Initialized
DEBUG - 2011-09-22 22:05:42 --> Loader Class Initialized
DEBUG - 2011-09-22 22:05:42 --> Controller Class Initialized
ERROR - 2011-09-22 22:05:42 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-22 22:05:42 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-22 22:05:42 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-22 22:05:42 --> Model Class Initialized
DEBUG - 2011-09-22 22:05:42 --> Model Class Initialized
DEBUG - 2011-09-22 22:05:42 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-22 22:05:42 --> Database Driver Class Initialized
DEBUG - 2011-09-22 22:05:42 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-22 22:05:42 --> Helper loaded: url_helper
DEBUG - 2011-09-22 22:05:42 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-22 22:05:42 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-22 22:05:42 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-22 22:05:42 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-22 22:05:42 --> Final output sent to browser
DEBUG - 2011-09-22 22:05:42 --> Total execution time: 0.1731
DEBUG - 2011-09-22 22:33:32 --> Config Class Initialized
DEBUG - 2011-09-22 22:33:32 --> Hooks Class Initialized
DEBUG - 2011-09-22 22:33:32 --> Utf8 Class Initialized
DEBUG - 2011-09-22 22:33:32 --> UTF-8 Support Enabled
DEBUG - 2011-09-22 22:33:32 --> URI Class Initialized
DEBUG - 2011-09-22 22:33:32 --> Router Class Initialized
DEBUG - 2011-09-22 22:33:32 --> Output Class Initialized
DEBUG - 2011-09-22 22:33:32 --> Input Class Initialized
DEBUG - 2011-09-22 22:33:32 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-22 22:33:32 --> Language Class Initialized
DEBUG - 2011-09-22 22:33:32 --> Loader Class Initialized
DEBUG - 2011-09-22 22:33:32 --> Controller Class Initialized
DEBUG - 2011-09-22 22:33:32 --> Model Class Initialized
DEBUG - 2011-09-22 22:33:32 --> Model Class Initialized
DEBUG - 2011-09-22 22:33:32 --> Model Class Initialized
DEBUG - 2011-09-22 22:33:32 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-22 22:33:32 --> Database Driver Class Initialized
DEBUG - 2011-09-22 22:33:33 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-22 22:33:33 --> Helper loaded: url_helper
DEBUG - 2011-09-22 22:33:33 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-22 22:33:33 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-22 22:33:33 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-22 22:33:33 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-22 22:33:33 --> Final output sent to browser
DEBUG - 2011-09-22 22:33:33 --> Total execution time: 0.7412
DEBUG - 2011-09-22 22:48:54 --> Config Class Initialized
DEBUG - 2011-09-22 22:48:54 --> Hooks Class Initialized
DEBUG - 2011-09-22 22:48:54 --> Utf8 Class Initialized
DEBUG - 2011-09-22 22:48:54 --> UTF-8 Support Enabled
DEBUG - 2011-09-22 22:48:54 --> URI Class Initialized
DEBUG - 2011-09-22 22:48:54 --> Router Class Initialized
DEBUG - 2011-09-22 22:48:54 --> No URI present. Default controller set.
DEBUG - 2011-09-22 22:48:54 --> Output Class Initialized
DEBUG - 2011-09-22 22:48:54 --> Input Class Initialized
DEBUG - 2011-09-22 22:48:54 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-22 22:48:54 --> Language Class Initialized
DEBUG - 2011-09-22 22:48:54 --> Loader Class Initialized
DEBUG - 2011-09-22 22:48:54 --> Controller Class Initialized
DEBUG - 2011-09-22 22:48:54 --> File loaded: application/views/splash/main.php
DEBUG - 2011-09-22 22:48:54 --> Helper loaded: url_helper
DEBUG - 2011-09-22 22:48:54 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-22 22:48:54 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-22 22:48:54 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-22 22:48:54 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-22 22:48:54 --> Final output sent to browser
DEBUG - 2011-09-22 22:48:54 --> Total execution time: 0.0688
DEBUG - 2011-09-22 22:55:04 --> Config Class Initialized
DEBUG - 2011-09-22 22:55:04 --> Hooks Class Initialized
DEBUG - 2011-09-22 22:55:04 --> Utf8 Class Initialized
DEBUG - 2011-09-22 22:55:04 --> UTF-8 Support Enabled
DEBUG - 2011-09-22 22:55:04 --> URI Class Initialized
DEBUG - 2011-09-22 22:55:04 --> Router Class Initialized
DEBUG - 2011-09-22 22:55:04 --> Output Class Initialized
DEBUG - 2011-09-22 22:55:04 --> Input Class Initialized
DEBUG - 2011-09-22 22:55:04 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-22 22:55:04 --> Language Class Initialized
DEBUG - 2011-09-22 22:55:04 --> Loader Class Initialized
DEBUG - 2011-09-22 22:55:04 --> Controller Class Initialized
DEBUG - 2011-09-22 22:55:04 --> Model Class Initialized
DEBUG - 2011-09-22 22:55:04 --> Model Class Initialized
DEBUG - 2011-09-22 22:55:04 --> Model Class Initialized
DEBUG - 2011-09-22 22:55:04 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-22 22:55:04 --> Database Driver Class Initialized
DEBUG - 2011-09-22 22:55:04 --> Config Class Initialized
DEBUG - 2011-09-22 22:55:04 --> Hooks Class Initialized
DEBUG - 2011-09-22 22:55:04 --> Utf8 Class Initialized
DEBUG - 2011-09-22 22:55:04 --> UTF-8 Support Enabled
DEBUG - 2011-09-22 22:55:04 --> URI Class Initialized
DEBUG - 2011-09-22 22:55:04 --> Router Class Initialized
DEBUG - 2011-09-22 22:55:04 --> Output Class Initialized
DEBUG - 2011-09-22 22:55:04 --> Input Class Initialized
DEBUG - 2011-09-22 22:55:04 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-22 22:55:04 --> Language Class Initialized
DEBUG - 2011-09-22 22:55:04 --> Loader Class Initialized
DEBUG - 2011-09-22 22:55:04 --> Controller Class Initialized
ERROR - 2011-09-22 22:55:04 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-22 22:55:04 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-22 22:55:04 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-22 22:55:04 --> Model Class Initialized
DEBUG - 2011-09-22 22:55:04 --> Model Class Initialized
DEBUG - 2011-09-22 22:55:04 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-22 22:55:04 --> Database Driver Class Initialized
DEBUG - 2011-09-22 22:55:04 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-22 22:55:04 --> Helper loaded: url_helper
DEBUG - 2011-09-22 22:55:04 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-22 22:55:04 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-22 22:55:04 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-22 22:55:04 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-22 22:55:04 --> Final output sent to browser
DEBUG - 2011-09-22 22:55:04 --> Total execution time: 0.1604
DEBUG - 2011-09-22 22:55:05 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-22 22:55:05 --> Helper loaded: url_helper
DEBUG - 2011-09-22 22:55:05 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-22 22:55:05 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-22 22:55:05 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-22 22:55:05 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-22 22:55:05 --> Final output sent to browser
DEBUG - 2011-09-22 22:55:05 --> Total execution time: 1.3353
DEBUG - 2011-09-22 23:34:20 --> Config Class Initialized
DEBUG - 2011-09-22 23:34:20 --> Hooks Class Initialized
DEBUG - 2011-09-22 23:34:20 --> Utf8 Class Initialized
DEBUG - 2011-09-22 23:34:20 --> UTF-8 Support Enabled
DEBUG - 2011-09-22 23:34:20 --> URI Class Initialized
DEBUG - 2011-09-22 23:34:20 --> Router Class Initialized
ERROR - 2011-09-22 23:34:20 --> 404 Page Not Found --> robots.txt

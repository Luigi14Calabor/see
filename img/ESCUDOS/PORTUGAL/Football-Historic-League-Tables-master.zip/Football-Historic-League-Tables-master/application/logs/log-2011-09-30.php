<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2011-09-30 00:13:29 --> Config Class Initialized
DEBUG - 2011-09-30 00:13:29 --> Hooks Class Initialized
DEBUG - 2011-09-30 00:13:29 --> Utf8 Class Initialized
DEBUG - 2011-09-30 00:13:29 --> UTF-8 Support Enabled
DEBUG - 2011-09-30 00:13:29 --> URI Class Initialized
DEBUG - 2011-09-30 00:13:29 --> Router Class Initialized
ERROR - 2011-09-30 00:13:29 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-09-30 00:13:29 --> Config Class Initialized
DEBUG - 2011-09-30 00:13:29 --> Hooks Class Initialized
DEBUG - 2011-09-30 00:13:29 --> Utf8 Class Initialized
DEBUG - 2011-09-30 00:13:29 --> UTF-8 Support Enabled
DEBUG - 2011-09-30 00:13:29 --> URI Class Initialized
DEBUG - 2011-09-30 00:13:29 --> Router Class Initialized
DEBUG - 2011-09-30 00:13:29 --> Output Class Initialized
DEBUG - 2011-09-30 00:13:29 --> Input Class Initialized
DEBUG - 2011-09-30 00:13:29 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-30 00:13:29 --> Language Class Initialized
DEBUG - 2011-09-30 00:13:29 --> Loader Class Initialized
DEBUG - 2011-09-30 00:13:29 --> Controller Class Initialized
DEBUG - 2011-09-30 00:13:29 --> Model Class Initialized
DEBUG - 2011-09-30 00:13:29 --> Model Class Initialized
DEBUG - 2011-09-30 00:13:29 --> Model Class Initialized
DEBUG - 2011-09-30 00:13:29 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-30 00:13:29 --> Database Driver Class Initialized
DEBUG - 2011-09-30 00:13:31 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-30 00:13:31 --> Helper loaded: url_helper
DEBUG - 2011-09-30 00:13:31 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-30 00:13:31 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-30 00:13:31 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-30 00:13:31 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-30 00:13:31 --> Final output sent to browser
DEBUG - 2011-09-30 00:13:31 --> Total execution time: 1.5936
DEBUG - 2011-09-30 00:17:57 --> Config Class Initialized
DEBUG - 2011-09-30 00:17:57 --> Hooks Class Initialized
DEBUG - 2011-09-30 00:17:57 --> Utf8 Class Initialized
DEBUG - 2011-09-30 00:17:57 --> UTF-8 Support Enabled
DEBUG - 2011-09-30 00:17:57 --> URI Class Initialized
DEBUG - 2011-09-30 00:17:57 --> Router Class Initialized
DEBUG - 2011-09-30 00:17:57 --> No URI present. Default controller set.
DEBUG - 2011-09-30 00:17:57 --> Output Class Initialized
DEBUG - 2011-09-30 00:17:57 --> Input Class Initialized
DEBUG - 2011-09-30 00:17:57 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-30 00:17:57 --> Language Class Initialized
DEBUG - 2011-09-30 00:17:57 --> Loader Class Initialized
DEBUG - 2011-09-30 00:17:57 --> Controller Class Initialized
DEBUG - 2011-09-30 00:17:57 --> File loaded: application/views/splash/main.php
DEBUG - 2011-09-30 00:17:57 --> Helper loaded: url_helper
DEBUG - 2011-09-30 00:17:57 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-30 00:17:57 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-30 00:17:57 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-30 00:17:57 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-30 00:17:57 --> Final output sent to browser
DEBUG - 2011-09-30 00:17:57 --> Total execution time: 0.0671
DEBUG - 2011-09-30 00:30:12 --> Config Class Initialized
DEBUG - 2011-09-30 00:30:12 --> Hooks Class Initialized
DEBUG - 2011-09-30 00:30:12 --> Utf8 Class Initialized
DEBUG - 2011-09-30 00:30:12 --> UTF-8 Support Enabled
DEBUG - 2011-09-30 00:30:12 --> URI Class Initialized
DEBUG - 2011-09-30 00:30:12 --> Router Class Initialized
DEBUG - 2011-09-30 00:30:12 --> Output Class Initialized
DEBUG - 2011-09-30 00:30:12 --> Input Class Initialized
DEBUG - 2011-09-30 00:30:12 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-30 00:30:12 --> Language Class Initialized
DEBUG - 2011-09-30 00:30:12 --> Loader Class Initialized
DEBUG - 2011-09-30 00:30:12 --> Controller Class Initialized
DEBUG - 2011-09-30 00:30:12 --> Model Class Initialized
DEBUG - 2011-09-30 00:30:12 --> Model Class Initialized
DEBUG - 2011-09-30 00:30:12 --> Model Class Initialized
DEBUG - 2011-09-30 00:30:12 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-30 00:30:12 --> Database Driver Class Initialized
DEBUG - 2011-09-30 00:30:12 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-30 00:30:12 --> Helper loaded: url_helper
DEBUG - 2011-09-30 00:30:12 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-30 00:30:12 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-30 00:30:12 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-30 00:30:12 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-30 00:30:12 --> Final output sent to browser
DEBUG - 2011-09-30 00:30:12 --> Total execution time: 0.1452
DEBUG - 2011-09-30 00:30:13 --> Config Class Initialized
DEBUG - 2011-09-30 00:30:13 --> Hooks Class Initialized
DEBUG - 2011-09-30 00:30:13 --> Utf8 Class Initialized
DEBUG - 2011-09-30 00:30:13 --> UTF-8 Support Enabled
DEBUG - 2011-09-30 00:30:13 --> URI Class Initialized
DEBUG - 2011-09-30 00:30:13 --> Router Class Initialized
DEBUG - 2011-09-30 00:30:13 --> Output Class Initialized
DEBUG - 2011-09-30 00:30:13 --> Input Class Initialized
DEBUG - 2011-09-30 00:30:13 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-30 00:30:13 --> Language Class Initialized
DEBUG - 2011-09-30 00:30:13 --> Loader Class Initialized
DEBUG - 2011-09-30 00:30:13 --> Controller Class Initialized
ERROR - 2011-09-30 00:30:14 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-30 00:30:14 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-30 00:30:14 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-30 00:30:14 --> Model Class Initialized
DEBUG - 2011-09-30 00:30:14 --> Model Class Initialized
DEBUG - 2011-09-30 00:30:14 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-30 00:30:14 --> Database Driver Class Initialized
DEBUG - 2011-09-30 00:30:14 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-30 00:30:14 --> Helper loaded: url_helper
DEBUG - 2011-09-30 00:30:14 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-30 00:30:14 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-30 00:30:14 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-30 00:30:14 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-30 00:30:14 --> Final output sent to browser
DEBUG - 2011-09-30 00:30:14 --> Total execution time: 0.3132
DEBUG - 2011-09-30 00:30:14 --> Config Class Initialized
DEBUG - 2011-09-30 00:30:14 --> Hooks Class Initialized
DEBUG - 2011-09-30 00:30:14 --> Utf8 Class Initialized
DEBUG - 2011-09-30 00:30:14 --> UTF-8 Support Enabled
DEBUG - 2011-09-30 00:30:14 --> URI Class Initialized
DEBUG - 2011-09-30 00:30:14 --> Router Class Initialized
DEBUG - 2011-09-30 00:30:14 --> Output Class Initialized
DEBUG - 2011-09-30 00:30:14 --> Input Class Initialized
DEBUG - 2011-09-30 00:30:14 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-30 00:30:14 --> Language Class Initialized
DEBUG - 2011-09-30 00:30:14 --> Loader Class Initialized
DEBUG - 2011-09-30 00:30:14 --> Controller Class Initialized
DEBUG - 2011-09-30 00:30:14 --> Model Class Initialized
DEBUG - 2011-09-30 00:30:14 --> Model Class Initialized
DEBUG - 2011-09-30 00:30:14 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-30 00:30:14 --> Database Driver Class Initialized
DEBUG - 2011-09-30 00:30:15 --> Final output sent to browser
DEBUG - 2011-09-30 00:30:15 --> Total execution time: 0.7511
DEBUG - 2011-09-30 00:30:16 --> Config Class Initialized
DEBUG - 2011-09-30 00:30:16 --> Hooks Class Initialized
DEBUG - 2011-09-30 00:30:16 --> Utf8 Class Initialized
DEBUG - 2011-09-30 00:30:16 --> UTF-8 Support Enabled
DEBUG - 2011-09-30 00:30:16 --> URI Class Initialized
DEBUG - 2011-09-30 00:30:16 --> Router Class Initialized
ERROR - 2011-09-30 00:30:16 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-30 00:30:16 --> Config Class Initialized
DEBUG - 2011-09-30 00:30:16 --> Hooks Class Initialized
DEBUG - 2011-09-30 00:30:16 --> Utf8 Class Initialized
DEBUG - 2011-09-30 00:30:16 --> UTF-8 Support Enabled
DEBUG - 2011-09-30 00:30:16 --> URI Class Initialized
DEBUG - 2011-09-30 00:30:16 --> Router Class Initialized
ERROR - 2011-09-30 00:30:16 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-30 00:30:35 --> Config Class Initialized
DEBUG - 2011-09-30 00:30:35 --> Hooks Class Initialized
DEBUG - 2011-09-30 00:30:35 --> Utf8 Class Initialized
DEBUG - 2011-09-30 00:30:35 --> UTF-8 Support Enabled
DEBUG - 2011-09-30 00:30:35 --> URI Class Initialized
DEBUG - 2011-09-30 00:30:35 --> Router Class Initialized
DEBUG - 2011-09-30 00:30:35 --> Output Class Initialized
DEBUG - 2011-09-30 00:30:35 --> Input Class Initialized
DEBUG - 2011-09-30 00:30:35 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-30 00:30:35 --> Language Class Initialized
DEBUG - 2011-09-30 00:30:35 --> Loader Class Initialized
DEBUG - 2011-09-30 00:30:35 --> Controller Class Initialized
ERROR - 2011-09-30 00:30:35 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-30 00:30:35 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-30 00:30:35 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-30 00:30:35 --> Model Class Initialized
DEBUG - 2011-09-30 00:30:35 --> Model Class Initialized
DEBUG - 2011-09-30 00:30:35 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-30 00:30:35 --> Database Driver Class Initialized
DEBUG - 2011-09-30 00:30:35 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-30 00:30:35 --> Helper loaded: url_helper
DEBUG - 2011-09-30 00:30:35 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-30 00:30:35 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-30 00:30:35 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-30 00:30:35 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-30 00:30:35 --> Final output sent to browser
DEBUG - 2011-09-30 00:30:35 --> Total execution time: 0.0450
DEBUG - 2011-09-30 00:30:36 --> Config Class Initialized
DEBUG - 2011-09-30 00:30:36 --> Hooks Class Initialized
DEBUG - 2011-09-30 00:30:36 --> Utf8 Class Initialized
DEBUG - 2011-09-30 00:30:36 --> UTF-8 Support Enabled
DEBUG - 2011-09-30 00:30:36 --> URI Class Initialized
DEBUG - 2011-09-30 00:30:36 --> Router Class Initialized
DEBUG - 2011-09-30 00:30:36 --> Output Class Initialized
DEBUG - 2011-09-30 00:30:36 --> Input Class Initialized
DEBUG - 2011-09-30 00:30:36 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-30 00:30:36 --> Language Class Initialized
DEBUG - 2011-09-30 00:30:36 --> Loader Class Initialized
DEBUG - 2011-09-30 00:30:36 --> Controller Class Initialized
DEBUG - 2011-09-30 00:30:36 --> Model Class Initialized
DEBUG - 2011-09-30 00:30:36 --> Model Class Initialized
DEBUG - 2011-09-30 00:30:36 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-30 00:30:36 --> Database Driver Class Initialized
DEBUG - 2011-09-30 00:30:37 --> Final output sent to browser
DEBUG - 2011-09-30 00:30:37 --> Total execution time: 1.0439
DEBUG - 2011-09-30 00:30:46 --> Config Class Initialized
DEBUG - 2011-09-30 00:30:46 --> Hooks Class Initialized
DEBUG - 2011-09-30 00:30:46 --> Utf8 Class Initialized
DEBUG - 2011-09-30 00:30:46 --> UTF-8 Support Enabled
DEBUG - 2011-09-30 00:30:46 --> URI Class Initialized
DEBUG - 2011-09-30 00:30:46 --> Router Class Initialized
DEBUG - 2011-09-30 00:30:46 --> Output Class Initialized
DEBUG - 2011-09-30 00:30:46 --> Input Class Initialized
DEBUG - 2011-09-30 00:30:46 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-30 00:30:46 --> Language Class Initialized
DEBUG - 2011-09-30 00:30:46 --> Loader Class Initialized
DEBUG - 2011-09-30 00:30:46 --> Controller Class Initialized
ERROR - 2011-09-30 00:30:46 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-30 00:30:46 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-30 00:30:46 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-30 00:30:46 --> Model Class Initialized
DEBUG - 2011-09-30 00:30:46 --> Model Class Initialized
DEBUG - 2011-09-30 00:30:46 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-30 00:30:46 --> Database Driver Class Initialized
DEBUG - 2011-09-30 00:30:46 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-30 00:30:46 --> Helper loaded: url_helper
DEBUG - 2011-09-30 00:30:46 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-30 00:30:46 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-30 00:30:46 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-30 00:30:46 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-30 00:30:46 --> Final output sent to browser
DEBUG - 2011-09-30 00:30:46 --> Total execution time: 0.0626
DEBUG - 2011-09-30 00:30:47 --> Config Class Initialized
DEBUG - 2011-09-30 00:30:47 --> Hooks Class Initialized
DEBUG - 2011-09-30 00:30:47 --> Utf8 Class Initialized
DEBUG - 2011-09-30 00:30:47 --> UTF-8 Support Enabled
DEBUG - 2011-09-30 00:30:47 --> URI Class Initialized
DEBUG - 2011-09-30 00:30:47 --> Router Class Initialized
DEBUG - 2011-09-30 00:30:47 --> Output Class Initialized
DEBUG - 2011-09-30 00:30:47 --> Input Class Initialized
DEBUG - 2011-09-30 00:30:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-30 00:30:47 --> Language Class Initialized
DEBUG - 2011-09-30 00:30:47 --> Loader Class Initialized
DEBUG - 2011-09-30 00:30:47 --> Controller Class Initialized
DEBUG - 2011-09-30 00:30:47 --> Model Class Initialized
DEBUG - 2011-09-30 00:30:47 --> Model Class Initialized
DEBUG - 2011-09-30 00:30:47 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-30 00:30:47 --> Database Driver Class Initialized
DEBUG - 2011-09-30 00:30:47 --> Final output sent to browser
DEBUG - 2011-09-30 00:30:47 --> Total execution time: 0.8856
DEBUG - 2011-09-30 00:53:56 --> Config Class Initialized
DEBUG - 2011-09-30 00:53:56 --> Hooks Class Initialized
DEBUG - 2011-09-30 00:53:56 --> Utf8 Class Initialized
DEBUG - 2011-09-30 00:53:56 --> UTF-8 Support Enabled
DEBUG - 2011-09-30 00:53:56 --> URI Class Initialized
DEBUG - 2011-09-30 00:53:56 --> Router Class Initialized
DEBUG - 2011-09-30 00:53:56 --> Output Class Initialized
DEBUG - 2011-09-30 00:53:56 --> Input Class Initialized
DEBUG - 2011-09-30 00:53:56 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-30 00:53:56 --> Language Class Initialized
DEBUG - 2011-09-30 00:53:56 --> Loader Class Initialized
DEBUG - 2011-09-30 00:53:56 --> Controller Class Initialized
ERROR - 2011-09-30 00:53:56 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-30 00:53:56 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-30 00:53:56 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-30 00:53:56 --> Model Class Initialized
DEBUG - 2011-09-30 00:53:56 --> Model Class Initialized
DEBUG - 2011-09-30 00:53:56 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-30 00:53:56 --> Database Driver Class Initialized
DEBUG - 2011-09-30 00:53:56 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-30 00:53:56 --> Helper loaded: url_helper
DEBUG - 2011-09-30 00:53:56 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-30 00:53:56 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-30 00:53:56 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-30 00:53:56 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-30 00:53:56 --> Final output sent to browser
DEBUG - 2011-09-30 00:53:56 --> Total execution time: 0.4967
DEBUG - 2011-09-30 01:53:26 --> Config Class Initialized
DEBUG - 2011-09-30 01:53:26 --> Hooks Class Initialized
DEBUG - 2011-09-30 01:53:26 --> Utf8 Class Initialized
DEBUG - 2011-09-30 01:53:26 --> UTF-8 Support Enabled
DEBUG - 2011-09-30 01:53:26 --> URI Class Initialized
DEBUG - 2011-09-30 01:53:26 --> Router Class Initialized
DEBUG - 2011-09-30 01:53:26 --> Output Class Initialized
DEBUG - 2011-09-30 01:53:26 --> Input Class Initialized
DEBUG - 2011-09-30 01:53:26 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-30 01:53:26 --> Language Class Initialized
DEBUG - 2011-09-30 01:53:26 --> Loader Class Initialized
DEBUG - 2011-09-30 01:53:26 --> Controller Class Initialized
DEBUG - 2011-09-30 01:53:26 --> Model Class Initialized
DEBUG - 2011-09-30 01:53:26 --> Model Class Initialized
DEBUG - 2011-09-30 01:53:26 --> Model Class Initialized
DEBUG - 2011-09-30 01:53:26 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-30 01:53:26 --> Database Driver Class Initialized
DEBUG - 2011-09-30 01:53:28 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-30 01:53:28 --> Helper loaded: url_helper
DEBUG - 2011-09-30 01:53:28 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-30 01:53:28 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-30 01:53:28 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-30 01:53:28 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-30 01:53:28 --> Final output sent to browser
DEBUG - 2011-09-30 01:53:28 --> Total execution time: 2.1731
DEBUG - 2011-09-30 01:53:29 --> Config Class Initialized
DEBUG - 2011-09-30 01:53:29 --> Hooks Class Initialized
DEBUG - 2011-09-30 01:53:29 --> Utf8 Class Initialized
DEBUG - 2011-09-30 01:53:29 --> UTF-8 Support Enabled
DEBUG - 2011-09-30 01:53:29 --> URI Class Initialized
DEBUG - 2011-09-30 01:53:29 --> Router Class Initialized
DEBUG - 2011-09-30 01:53:29 --> Output Class Initialized
DEBUG - 2011-09-30 01:53:29 --> Input Class Initialized
DEBUG - 2011-09-30 01:53:29 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-30 01:53:29 --> Language Class Initialized
DEBUG - 2011-09-30 01:53:29 --> Loader Class Initialized
DEBUG - 2011-09-30 01:53:29 --> Controller Class Initialized
ERROR - 2011-09-30 01:53:29 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-30 01:53:29 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-30 01:53:29 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-30 01:53:29 --> Model Class Initialized
DEBUG - 2011-09-30 01:53:29 --> Model Class Initialized
DEBUG - 2011-09-30 01:53:29 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-30 01:53:29 --> Database Driver Class Initialized
DEBUG - 2011-09-30 01:53:29 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-30 01:53:29 --> Helper loaded: url_helper
DEBUG - 2011-09-30 01:53:29 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-30 01:53:29 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-30 01:53:29 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-30 01:53:29 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-30 01:53:29 --> Final output sent to browser
DEBUG - 2011-09-30 01:53:29 --> Total execution time: 0.1236
DEBUG - 2011-09-30 02:13:28 --> Config Class Initialized
DEBUG - 2011-09-30 02:13:28 --> Hooks Class Initialized
DEBUG - 2011-09-30 02:13:28 --> Utf8 Class Initialized
DEBUG - 2011-09-30 02:13:28 --> UTF-8 Support Enabled
DEBUG - 2011-09-30 02:13:28 --> URI Class Initialized
DEBUG - 2011-09-30 02:13:28 --> Router Class Initialized
ERROR - 2011-09-30 02:13:28 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-09-30 02:13:29 --> Config Class Initialized
DEBUG - 2011-09-30 02:13:29 --> Hooks Class Initialized
DEBUG - 2011-09-30 02:13:29 --> Utf8 Class Initialized
DEBUG - 2011-09-30 02:13:29 --> UTF-8 Support Enabled
DEBUG - 2011-09-30 02:13:29 --> URI Class Initialized
DEBUG - 2011-09-30 02:13:29 --> Router Class Initialized
DEBUG - 2011-09-30 02:13:29 --> Output Class Initialized
DEBUG - 2011-09-30 02:13:29 --> Input Class Initialized
DEBUG - 2011-09-30 02:13:29 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-30 02:13:29 --> Language Class Initialized
DEBUG - 2011-09-30 02:13:29 --> Loader Class Initialized
DEBUG - 2011-09-30 02:13:29 --> Controller Class Initialized
ERROR - 2011-09-30 02:13:29 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-30 02:13:29 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-30 02:13:29 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-30 02:13:29 --> Model Class Initialized
DEBUG - 2011-09-30 02:13:29 --> Model Class Initialized
DEBUG - 2011-09-30 02:13:29 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-30 02:13:29 --> Database Driver Class Initialized
DEBUG - 2011-09-30 02:13:29 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-30 02:13:29 --> Helper loaded: url_helper
DEBUG - 2011-09-30 02:13:29 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-30 02:13:29 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-30 02:13:29 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-30 02:13:29 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-30 02:13:29 --> Final output sent to browser
DEBUG - 2011-09-30 02:13:29 --> Total execution time: 0.1729
DEBUG - 2011-09-30 02:25:41 --> Config Class Initialized
DEBUG - 2011-09-30 02:25:41 --> Hooks Class Initialized
DEBUG - 2011-09-30 02:25:41 --> Utf8 Class Initialized
DEBUG - 2011-09-30 02:25:41 --> UTF-8 Support Enabled
DEBUG - 2011-09-30 02:25:41 --> URI Class Initialized
DEBUG - 2011-09-30 02:25:41 --> Router Class Initialized
ERROR - 2011-09-30 02:25:41 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-09-30 06:08:29 --> Config Class Initialized
DEBUG - 2011-09-30 06:08:29 --> Hooks Class Initialized
DEBUG - 2011-09-30 06:08:29 --> Utf8 Class Initialized
DEBUG - 2011-09-30 06:08:29 --> UTF-8 Support Enabled
DEBUG - 2011-09-30 06:08:29 --> URI Class Initialized
DEBUG - 2011-09-30 06:08:29 --> Router Class Initialized
DEBUG - 2011-09-30 06:08:29 --> Output Class Initialized
DEBUG - 2011-09-30 06:08:29 --> Input Class Initialized
DEBUG - 2011-09-30 06:08:29 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-30 06:08:29 --> Language Class Initialized
DEBUG - 2011-09-30 06:08:29 --> Loader Class Initialized
DEBUG - 2011-09-30 06:08:29 --> Controller Class Initialized
ERROR - 2011-09-30 06:08:29 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-30 06:08:29 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-30 06:08:29 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-30 06:08:29 --> Model Class Initialized
DEBUG - 2011-09-30 06:08:29 --> Model Class Initialized
DEBUG - 2011-09-30 06:08:29 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-30 06:08:29 --> Database Driver Class Initialized
DEBUG - 2011-09-30 06:08:29 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-30 06:08:29 --> Helper loaded: url_helper
DEBUG - 2011-09-30 06:08:29 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-30 06:08:29 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-30 06:08:29 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-30 06:08:29 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-30 06:08:29 --> Final output sent to browser
DEBUG - 2011-09-30 06:08:29 --> Total execution time: 0.6324
DEBUG - 2011-09-30 06:08:30 --> Config Class Initialized
DEBUG - 2011-09-30 06:08:30 --> Hooks Class Initialized
DEBUG - 2011-09-30 06:08:30 --> Utf8 Class Initialized
DEBUG - 2011-09-30 06:08:30 --> UTF-8 Support Enabled
DEBUG - 2011-09-30 06:08:30 --> URI Class Initialized
DEBUG - 2011-09-30 06:08:30 --> Router Class Initialized
DEBUG - 2011-09-30 06:08:30 --> Output Class Initialized
DEBUG - 2011-09-30 06:08:30 --> Input Class Initialized
DEBUG - 2011-09-30 06:08:30 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-30 06:08:30 --> Language Class Initialized
DEBUG - 2011-09-30 06:08:30 --> Loader Class Initialized
DEBUG - 2011-09-30 06:08:30 --> Controller Class Initialized
DEBUG - 2011-09-30 06:08:30 --> Model Class Initialized
DEBUG - 2011-09-30 06:08:30 --> Model Class Initialized
DEBUG - 2011-09-30 06:08:30 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-30 06:08:30 --> Database Driver Class Initialized
DEBUG - 2011-09-30 06:08:31 --> Final output sent to browser
DEBUG - 2011-09-30 06:08:31 --> Total execution time: 0.9756
DEBUG - 2011-09-30 06:08:32 --> Config Class Initialized
DEBUG - 2011-09-30 06:08:32 --> Hooks Class Initialized
DEBUG - 2011-09-30 06:08:32 --> Utf8 Class Initialized
DEBUG - 2011-09-30 06:08:32 --> UTF-8 Support Enabled
DEBUG - 2011-09-30 06:08:32 --> URI Class Initialized
DEBUG - 2011-09-30 06:08:32 --> Router Class Initialized
ERROR - 2011-09-30 06:08:32 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-30 06:09:30 --> Config Class Initialized
DEBUG - 2011-09-30 06:09:30 --> Hooks Class Initialized
DEBUG - 2011-09-30 06:09:30 --> Utf8 Class Initialized
DEBUG - 2011-09-30 06:09:30 --> UTF-8 Support Enabled
DEBUG - 2011-09-30 06:09:30 --> URI Class Initialized
DEBUG - 2011-09-30 06:09:30 --> Router Class Initialized
DEBUG - 2011-09-30 06:09:30 --> Output Class Initialized
DEBUG - 2011-09-30 06:09:30 --> Input Class Initialized
DEBUG - 2011-09-30 06:09:30 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-30 06:09:30 --> Language Class Initialized
DEBUG - 2011-09-30 06:09:30 --> Loader Class Initialized
DEBUG - 2011-09-30 06:09:30 --> Controller Class Initialized
ERROR - 2011-09-30 06:09:30 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-30 06:09:30 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-30 06:09:30 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-30 06:09:30 --> Model Class Initialized
DEBUG - 2011-09-30 06:09:30 --> Model Class Initialized
DEBUG - 2011-09-30 06:09:30 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-30 06:09:30 --> Database Driver Class Initialized
DEBUG - 2011-09-30 06:09:30 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-30 06:09:30 --> Helper loaded: url_helper
DEBUG - 2011-09-30 06:09:30 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-30 06:09:30 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-30 06:09:30 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-30 06:09:30 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-30 06:09:30 --> Final output sent to browser
DEBUG - 2011-09-30 06:09:30 --> Total execution time: 0.0316
DEBUG - 2011-09-30 06:09:31 --> Config Class Initialized
DEBUG - 2011-09-30 06:09:31 --> Hooks Class Initialized
DEBUG - 2011-09-30 06:09:31 --> Utf8 Class Initialized
DEBUG - 2011-09-30 06:09:31 --> UTF-8 Support Enabled
DEBUG - 2011-09-30 06:09:31 --> URI Class Initialized
DEBUG - 2011-09-30 06:09:31 --> Router Class Initialized
DEBUG - 2011-09-30 06:09:31 --> Output Class Initialized
DEBUG - 2011-09-30 06:09:31 --> Input Class Initialized
DEBUG - 2011-09-30 06:09:31 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-30 06:09:31 --> Language Class Initialized
DEBUG - 2011-09-30 06:09:31 --> Loader Class Initialized
DEBUG - 2011-09-30 06:09:31 --> Controller Class Initialized
DEBUG - 2011-09-30 06:09:31 --> Model Class Initialized
DEBUG - 2011-09-30 06:09:31 --> Model Class Initialized
DEBUG - 2011-09-30 06:09:31 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-30 06:09:31 --> Database Driver Class Initialized
DEBUG - 2011-09-30 06:09:32 --> Final output sent to browser
DEBUG - 2011-09-30 06:09:32 --> Total execution time: 0.6846
DEBUG - 2011-09-30 07:41:39 --> Config Class Initialized
DEBUG - 2011-09-30 07:41:39 --> Hooks Class Initialized
DEBUG - 2011-09-30 07:41:39 --> Utf8 Class Initialized
DEBUG - 2011-09-30 07:41:39 --> UTF-8 Support Enabled
DEBUG - 2011-09-30 07:41:39 --> URI Class Initialized
DEBUG - 2011-09-30 07:41:39 --> Router Class Initialized
DEBUG - 2011-09-30 07:41:39 --> No URI present. Default controller set.
DEBUG - 2011-09-30 07:41:39 --> Output Class Initialized
DEBUG - 2011-09-30 07:41:39 --> Input Class Initialized
DEBUG - 2011-09-30 07:41:39 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-30 07:41:39 --> Language Class Initialized
DEBUG - 2011-09-30 07:41:40 --> Loader Class Initialized
DEBUG - 2011-09-30 07:41:40 --> Controller Class Initialized
DEBUG - 2011-09-30 07:41:41 --> File loaded: application/views/splash/main.php
DEBUG - 2011-09-30 07:41:41 --> Helper loaded: url_helper
DEBUG - 2011-09-30 07:41:41 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-30 07:41:41 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-30 07:41:41 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-30 07:41:41 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-30 07:41:41 --> Final output sent to browser
DEBUG - 2011-09-30 07:41:41 --> Total execution time: 2.2256
DEBUG - 2011-09-30 07:52:03 --> Config Class Initialized
DEBUG - 2011-09-30 07:52:03 --> Hooks Class Initialized
DEBUG - 2011-09-30 07:52:03 --> Utf8 Class Initialized
DEBUG - 2011-09-30 07:52:03 --> UTF-8 Support Enabled
DEBUG - 2011-09-30 07:52:03 --> URI Class Initialized
DEBUG - 2011-09-30 07:52:03 --> Router Class Initialized
DEBUG - 2011-09-30 07:52:03 --> Output Class Initialized
DEBUG - 2011-09-30 07:52:03 --> Input Class Initialized
DEBUG - 2011-09-30 07:52:03 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-30 07:52:03 --> Language Class Initialized
DEBUG - 2011-09-30 07:52:03 --> Loader Class Initialized
DEBUG - 2011-09-30 07:52:03 --> Controller Class Initialized
DEBUG - 2011-09-30 07:52:03 --> Model Class Initialized
DEBUG - 2011-09-30 07:52:03 --> Model Class Initialized
DEBUG - 2011-09-30 07:52:03 --> Model Class Initialized
DEBUG - 2011-09-30 07:52:03 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-30 07:52:03 --> Database Driver Class Initialized
DEBUG - 2011-09-30 07:52:05 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-30 07:52:05 --> Helper loaded: url_helper
DEBUG - 2011-09-30 07:52:05 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-30 07:52:05 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-30 07:52:05 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-30 07:52:05 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-30 07:52:05 --> Final output sent to browser
DEBUG - 2011-09-30 07:52:05 --> Total execution time: 2.2312
DEBUG - 2011-09-30 07:52:07 --> Config Class Initialized
DEBUG - 2011-09-30 07:52:07 --> Hooks Class Initialized
DEBUG - 2011-09-30 07:52:07 --> Utf8 Class Initialized
DEBUG - 2011-09-30 07:52:07 --> UTF-8 Support Enabled
DEBUG - 2011-09-30 07:52:07 --> URI Class Initialized
DEBUG - 2011-09-30 07:52:07 --> Router Class Initialized
ERROR - 2011-09-30 07:52:07 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-30 07:52:34 --> Config Class Initialized
DEBUG - 2011-09-30 07:52:34 --> Hooks Class Initialized
DEBUG - 2011-09-30 07:52:34 --> Utf8 Class Initialized
DEBUG - 2011-09-30 07:52:34 --> UTF-8 Support Enabled
DEBUG - 2011-09-30 07:52:34 --> URI Class Initialized
DEBUG - 2011-09-30 07:52:34 --> Router Class Initialized
ERROR - 2011-09-30 07:52:34 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-09-30 07:52:35 --> Config Class Initialized
DEBUG - 2011-09-30 07:52:35 --> Hooks Class Initialized
DEBUG - 2011-09-30 07:52:35 --> Utf8 Class Initialized
DEBUG - 2011-09-30 07:52:35 --> UTF-8 Support Enabled
DEBUG - 2011-09-30 07:52:35 --> URI Class Initialized
DEBUG - 2011-09-30 07:52:35 --> Router Class Initialized
DEBUG - 2011-09-30 07:52:35 --> Output Class Initialized
DEBUG - 2011-09-30 07:52:35 --> Input Class Initialized
DEBUG - 2011-09-30 07:52:35 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-30 07:52:35 --> Language Class Initialized
DEBUG - 2011-09-30 07:52:35 --> Loader Class Initialized
DEBUG - 2011-09-30 07:52:35 --> Controller Class Initialized
DEBUG - 2011-09-30 07:52:35 --> Model Class Initialized
DEBUG - 2011-09-30 07:52:35 --> Model Class Initialized
DEBUG - 2011-09-30 07:52:35 --> Model Class Initialized
DEBUG - 2011-09-30 07:52:35 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-30 07:52:35 --> Database Driver Class Initialized
DEBUG - 2011-09-30 07:52:35 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-30 07:52:35 --> Helper loaded: url_helper
DEBUG - 2011-09-30 07:52:35 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-30 07:52:35 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-30 07:52:35 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-30 07:52:35 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-30 07:52:35 --> Final output sent to browser
DEBUG - 2011-09-30 07:52:35 --> Total execution time: 0.1378
DEBUG - 2011-09-30 07:52:38 --> Config Class Initialized
DEBUG - 2011-09-30 07:52:38 --> Hooks Class Initialized
DEBUG - 2011-09-30 07:52:38 --> Utf8 Class Initialized
DEBUG - 2011-09-30 07:52:38 --> UTF-8 Support Enabled
DEBUG - 2011-09-30 07:52:38 --> URI Class Initialized
DEBUG - 2011-09-30 07:52:38 --> Router Class Initialized
DEBUG - 2011-09-30 07:52:38 --> Output Class Initialized
DEBUG - 2011-09-30 07:52:38 --> Input Class Initialized
DEBUG - 2011-09-30 07:52:38 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-30 07:52:38 --> Language Class Initialized
DEBUG - 2011-09-30 07:52:38 --> Loader Class Initialized
DEBUG - 2011-09-30 07:52:38 --> Controller Class Initialized
DEBUG - 2011-09-30 07:52:38 --> Model Class Initialized
DEBUG - 2011-09-30 07:52:38 --> Model Class Initialized
DEBUG - 2011-09-30 07:52:38 --> Model Class Initialized
DEBUG - 2011-09-30 07:52:38 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-30 07:52:38 --> Database Driver Class Initialized
DEBUG - 2011-09-30 07:52:39 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-30 07:52:39 --> Helper loaded: url_helper
DEBUG - 2011-09-30 07:52:39 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-30 07:52:39 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-30 07:52:39 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-30 07:52:39 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-30 07:52:39 --> Final output sent to browser
DEBUG - 2011-09-30 07:52:39 --> Total execution time: 1.4066
DEBUG - 2011-09-30 07:52:41 --> Config Class Initialized
DEBUG - 2011-09-30 07:52:41 --> Hooks Class Initialized
DEBUG - 2011-09-30 07:52:41 --> Utf8 Class Initialized
DEBUG - 2011-09-30 07:52:41 --> UTF-8 Support Enabled
DEBUG - 2011-09-30 07:52:41 --> URI Class Initialized
DEBUG - 2011-09-30 07:52:41 --> Router Class Initialized
ERROR - 2011-09-30 07:52:41 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-30 07:52:43 --> Config Class Initialized
DEBUG - 2011-09-30 07:52:43 --> Hooks Class Initialized
DEBUG - 2011-09-30 07:52:43 --> Utf8 Class Initialized
DEBUG - 2011-09-30 07:52:43 --> UTF-8 Support Enabled
DEBUG - 2011-09-30 07:52:43 --> URI Class Initialized
DEBUG - 2011-09-30 07:52:43 --> Router Class Initialized
ERROR - 2011-09-30 07:52:43 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-09-30 07:52:44 --> Config Class Initialized
DEBUG - 2011-09-30 07:52:44 --> Hooks Class Initialized
DEBUG - 2011-09-30 07:52:44 --> Utf8 Class Initialized
DEBUG - 2011-09-30 07:52:44 --> UTF-8 Support Enabled
DEBUG - 2011-09-30 07:52:44 --> URI Class Initialized
DEBUG - 2011-09-30 07:52:44 --> Router Class Initialized
DEBUG - 2011-09-30 07:52:44 --> Output Class Initialized
DEBUG - 2011-09-30 07:52:44 --> Input Class Initialized
DEBUG - 2011-09-30 07:52:44 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-30 07:52:44 --> Language Class Initialized
DEBUG - 2011-09-30 07:52:44 --> Loader Class Initialized
DEBUG - 2011-09-30 07:52:44 --> Controller Class Initialized
DEBUG - 2011-09-30 07:52:44 --> Model Class Initialized
DEBUG - 2011-09-30 07:52:44 --> Model Class Initialized
DEBUG - 2011-09-30 07:52:44 --> Model Class Initialized
DEBUG - 2011-09-30 07:52:44 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-30 07:52:44 --> Database Driver Class Initialized
DEBUG - 2011-09-30 07:52:44 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-30 07:52:44 --> Helper loaded: url_helper
DEBUG - 2011-09-30 07:52:44 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-30 07:52:44 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-30 07:52:44 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-30 07:52:44 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-30 07:52:44 --> Final output sent to browser
DEBUG - 2011-09-30 07:52:44 --> Total execution time: 0.0835
DEBUG - 2011-09-30 07:52:57 --> Config Class Initialized
DEBUG - 2011-09-30 07:52:57 --> Hooks Class Initialized
DEBUG - 2011-09-30 07:52:57 --> Utf8 Class Initialized
DEBUG - 2011-09-30 07:52:57 --> UTF-8 Support Enabled
DEBUG - 2011-09-30 07:52:57 --> URI Class Initialized
DEBUG - 2011-09-30 07:52:57 --> Router Class Initialized
DEBUG - 2011-09-30 07:52:57 --> Output Class Initialized
DEBUG - 2011-09-30 07:52:57 --> Input Class Initialized
DEBUG - 2011-09-30 07:52:57 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-30 07:52:57 --> Language Class Initialized
DEBUG - 2011-09-30 07:52:57 --> Loader Class Initialized
DEBUG - 2011-09-30 07:52:57 --> Controller Class Initialized
DEBUG - 2011-09-30 07:52:57 --> Model Class Initialized
DEBUG - 2011-09-30 07:52:57 --> Model Class Initialized
DEBUG - 2011-09-30 07:52:57 --> Model Class Initialized
DEBUG - 2011-09-30 07:52:57 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-30 07:52:57 --> Database Driver Class Initialized
DEBUG - 2011-09-30 07:52:57 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-30 07:52:57 --> Helper loaded: url_helper
DEBUG - 2011-09-30 07:52:57 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-30 07:52:57 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-30 07:52:57 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-30 07:52:57 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-30 07:52:57 --> Final output sent to browser
DEBUG - 2011-09-30 07:52:57 --> Total execution time: 0.4357
DEBUG - 2011-09-30 07:52:58 --> Config Class Initialized
DEBUG - 2011-09-30 07:52:58 --> Hooks Class Initialized
DEBUG - 2011-09-30 07:52:58 --> Utf8 Class Initialized
DEBUG - 2011-09-30 07:52:58 --> UTF-8 Support Enabled
DEBUG - 2011-09-30 07:52:58 --> URI Class Initialized
DEBUG - 2011-09-30 07:52:58 --> Router Class Initialized
DEBUG - 2011-09-30 07:52:58 --> Output Class Initialized
DEBUG - 2011-09-30 07:52:58 --> Input Class Initialized
DEBUG - 2011-09-30 07:52:58 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-30 07:52:58 --> Language Class Initialized
DEBUG - 2011-09-30 07:52:58 --> Loader Class Initialized
DEBUG - 2011-09-30 07:52:58 --> Controller Class Initialized
DEBUG - 2011-09-30 07:52:58 --> Model Class Initialized
DEBUG - 2011-09-30 07:52:58 --> Model Class Initialized
DEBUG - 2011-09-30 07:52:58 --> Model Class Initialized
DEBUG - 2011-09-30 07:52:58 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-30 07:52:58 --> Database Driver Class Initialized
DEBUG - 2011-09-30 07:52:58 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-30 07:52:58 --> Helper loaded: url_helper
DEBUG - 2011-09-30 07:52:58 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-30 07:52:58 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-30 07:52:58 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-30 07:52:58 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-30 07:52:58 --> Final output sent to browser
DEBUG - 2011-09-30 07:52:58 --> Total execution time: 0.0506
DEBUG - 2011-09-30 07:52:59 --> Config Class Initialized
DEBUG - 2011-09-30 07:52:59 --> Hooks Class Initialized
DEBUG - 2011-09-30 07:52:59 --> Utf8 Class Initialized
DEBUG - 2011-09-30 07:52:59 --> UTF-8 Support Enabled
DEBUG - 2011-09-30 07:52:59 --> URI Class Initialized
DEBUG - 2011-09-30 07:52:59 --> Router Class Initialized
ERROR - 2011-09-30 07:52:59 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-30 09:48:33 --> Config Class Initialized
DEBUG - 2011-09-30 09:48:33 --> Hooks Class Initialized
DEBUG - 2011-09-30 09:48:34 --> Utf8 Class Initialized
DEBUG - 2011-09-30 09:48:34 --> UTF-8 Support Enabled
DEBUG - 2011-09-30 09:48:34 --> URI Class Initialized
DEBUG - 2011-09-30 09:48:34 --> Router Class Initialized
DEBUG - 2011-09-30 09:48:34 --> Output Class Initialized
DEBUG - 2011-09-30 09:48:34 --> Input Class Initialized
DEBUG - 2011-09-30 09:48:34 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-30 09:48:34 --> Language Class Initialized
DEBUG - 2011-09-30 09:48:34 --> Loader Class Initialized
DEBUG - 2011-09-30 09:48:34 --> Controller Class Initialized
ERROR - 2011-09-30 09:48:34 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-30 09:48:34 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-30 09:48:34 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-30 09:48:34 --> Model Class Initialized
DEBUG - 2011-09-30 09:48:34 --> Model Class Initialized
DEBUG - 2011-09-30 09:48:34 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-30 09:48:34 --> Database Driver Class Initialized
DEBUG - 2011-09-30 09:48:34 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-30 09:48:34 --> Helper loaded: url_helper
DEBUG - 2011-09-30 09:48:34 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-30 09:48:34 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-30 09:48:34 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-30 09:48:34 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-30 09:48:34 --> Final output sent to browser
DEBUG - 2011-09-30 09:48:34 --> Total execution time: 0.6480
DEBUG - 2011-09-30 09:48:36 --> Config Class Initialized
DEBUG - 2011-09-30 09:48:36 --> Hooks Class Initialized
DEBUG - 2011-09-30 09:48:36 --> Utf8 Class Initialized
DEBUG - 2011-09-30 09:48:36 --> UTF-8 Support Enabled
DEBUG - 2011-09-30 09:48:36 --> URI Class Initialized
DEBUG - 2011-09-30 09:48:36 --> Router Class Initialized
DEBUG - 2011-09-30 09:48:36 --> Output Class Initialized
DEBUG - 2011-09-30 09:48:36 --> Input Class Initialized
DEBUG - 2011-09-30 09:48:36 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-30 09:48:36 --> Language Class Initialized
DEBUG - 2011-09-30 09:48:36 --> Loader Class Initialized
DEBUG - 2011-09-30 09:48:36 --> Controller Class Initialized
DEBUG - 2011-09-30 09:48:36 --> Model Class Initialized
DEBUG - 2011-09-30 09:48:36 --> Model Class Initialized
DEBUG - 2011-09-30 09:48:36 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-30 09:48:36 --> Database Driver Class Initialized
DEBUG - 2011-09-30 09:48:37 --> Final output sent to browser
DEBUG - 2011-09-30 09:48:37 --> Total execution time: 0.8903
DEBUG - 2011-09-30 09:48:39 --> Config Class Initialized
DEBUG - 2011-09-30 09:48:39 --> Hooks Class Initialized
DEBUG - 2011-09-30 09:48:39 --> Utf8 Class Initialized
DEBUG - 2011-09-30 09:48:39 --> UTF-8 Support Enabled
DEBUG - 2011-09-30 09:48:39 --> URI Class Initialized
DEBUG - 2011-09-30 09:48:39 --> Router Class Initialized
ERROR - 2011-09-30 09:48:39 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-30 09:49:17 --> Config Class Initialized
DEBUG - 2011-09-30 09:49:17 --> Hooks Class Initialized
DEBUG - 2011-09-30 09:49:17 --> Utf8 Class Initialized
DEBUG - 2011-09-30 09:49:17 --> UTF-8 Support Enabled
DEBUG - 2011-09-30 09:49:17 --> URI Class Initialized
DEBUG - 2011-09-30 09:49:17 --> Router Class Initialized
DEBUG - 2011-09-30 09:49:17 --> Output Class Initialized
DEBUG - 2011-09-30 09:49:17 --> Input Class Initialized
DEBUG - 2011-09-30 09:49:17 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-30 09:49:17 --> Language Class Initialized
DEBUG - 2011-09-30 09:49:17 --> Loader Class Initialized
DEBUG - 2011-09-30 09:49:17 --> Controller Class Initialized
ERROR - 2011-09-30 09:49:17 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-30 09:49:17 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-30 09:49:17 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-30 09:49:17 --> Model Class Initialized
DEBUG - 2011-09-30 09:49:17 --> Model Class Initialized
DEBUG - 2011-09-30 09:49:17 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-30 09:49:17 --> Database Driver Class Initialized
DEBUG - 2011-09-30 09:49:17 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-30 09:49:17 --> Helper loaded: url_helper
DEBUG - 2011-09-30 09:49:17 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-30 09:49:17 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-30 09:49:17 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-30 09:49:17 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-30 09:49:17 --> Final output sent to browser
DEBUG - 2011-09-30 09:49:17 --> Total execution time: 0.0301
DEBUG - 2011-09-30 09:49:18 --> Config Class Initialized
DEBUG - 2011-09-30 09:49:18 --> Hooks Class Initialized
DEBUG - 2011-09-30 09:49:18 --> Utf8 Class Initialized
DEBUG - 2011-09-30 09:49:18 --> UTF-8 Support Enabled
DEBUG - 2011-09-30 09:49:18 --> URI Class Initialized
DEBUG - 2011-09-30 09:49:18 --> Router Class Initialized
DEBUG - 2011-09-30 09:49:18 --> Output Class Initialized
DEBUG - 2011-09-30 09:49:18 --> Input Class Initialized
DEBUG - 2011-09-30 09:49:18 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-30 09:49:18 --> Language Class Initialized
DEBUG - 2011-09-30 09:49:18 --> Loader Class Initialized
DEBUG - 2011-09-30 09:49:18 --> Controller Class Initialized
DEBUG - 2011-09-30 09:49:18 --> Model Class Initialized
DEBUG - 2011-09-30 09:49:18 --> Model Class Initialized
DEBUG - 2011-09-30 09:49:18 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-30 09:49:18 --> Database Driver Class Initialized
DEBUG - 2011-09-30 09:49:19 --> Final output sent to browser
DEBUG - 2011-09-30 09:49:19 --> Total execution time: 0.7794
DEBUG - 2011-09-30 09:49:20 --> Config Class Initialized
DEBUG - 2011-09-30 09:49:20 --> Hooks Class Initialized
DEBUG - 2011-09-30 09:49:20 --> Utf8 Class Initialized
DEBUG - 2011-09-30 09:49:20 --> UTF-8 Support Enabled
DEBUG - 2011-09-30 09:49:20 --> URI Class Initialized
DEBUG - 2011-09-30 09:49:20 --> Router Class Initialized
ERROR - 2011-09-30 09:49:20 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-30 09:49:42 --> Config Class Initialized
DEBUG - 2011-09-30 09:49:42 --> Hooks Class Initialized
DEBUG - 2011-09-30 09:49:42 --> Utf8 Class Initialized
DEBUG - 2011-09-30 09:49:42 --> UTF-8 Support Enabled
DEBUG - 2011-09-30 09:49:42 --> URI Class Initialized
DEBUG - 2011-09-30 09:49:42 --> Router Class Initialized
DEBUG - 2011-09-30 09:49:42 --> Output Class Initialized
DEBUG - 2011-09-30 09:49:42 --> Input Class Initialized
DEBUG - 2011-09-30 09:49:42 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-30 09:49:42 --> Language Class Initialized
DEBUG - 2011-09-30 09:49:42 --> Loader Class Initialized
DEBUG - 2011-09-30 09:49:42 --> Controller Class Initialized
ERROR - 2011-09-30 09:49:42 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-30 09:49:42 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-30 09:49:42 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-30 09:49:42 --> Model Class Initialized
DEBUG - 2011-09-30 09:49:42 --> Model Class Initialized
DEBUG - 2011-09-30 09:49:42 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-30 09:49:42 --> Database Driver Class Initialized
DEBUG - 2011-09-30 09:49:42 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-30 09:49:42 --> Helper loaded: url_helper
DEBUG - 2011-09-30 09:49:42 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-30 09:49:42 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-30 09:49:42 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-30 09:49:42 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-30 09:49:42 --> Final output sent to browser
DEBUG - 2011-09-30 09:49:42 --> Total execution time: 0.0392
DEBUG - 2011-09-30 09:49:43 --> Config Class Initialized
DEBUG - 2011-09-30 09:49:43 --> Hooks Class Initialized
DEBUG - 2011-09-30 09:49:43 --> Utf8 Class Initialized
DEBUG - 2011-09-30 09:49:43 --> UTF-8 Support Enabled
DEBUG - 2011-09-30 09:49:43 --> URI Class Initialized
DEBUG - 2011-09-30 09:49:43 --> Router Class Initialized
DEBUG - 2011-09-30 09:49:43 --> Output Class Initialized
DEBUG - 2011-09-30 09:49:43 --> Input Class Initialized
DEBUG - 2011-09-30 09:49:43 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-30 09:49:43 --> Language Class Initialized
DEBUG - 2011-09-30 09:49:43 --> Loader Class Initialized
DEBUG - 2011-09-30 09:49:43 --> Controller Class Initialized
DEBUG - 2011-09-30 09:49:43 --> Model Class Initialized
DEBUG - 2011-09-30 09:49:43 --> Model Class Initialized
DEBUG - 2011-09-30 09:49:43 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-30 09:49:43 --> Database Driver Class Initialized
DEBUG - 2011-09-30 09:49:44 --> Final output sent to browser
DEBUG - 2011-09-30 09:49:44 --> Total execution time: 0.6407
DEBUG - 2011-09-30 09:49:45 --> Config Class Initialized
DEBUG - 2011-09-30 09:49:45 --> Hooks Class Initialized
DEBUG - 2011-09-30 09:49:45 --> Utf8 Class Initialized
DEBUG - 2011-09-30 09:49:45 --> UTF-8 Support Enabled
DEBUG - 2011-09-30 09:49:45 --> URI Class Initialized
DEBUG - 2011-09-30 09:49:45 --> Router Class Initialized
ERROR - 2011-09-30 09:49:45 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-30 09:49:50 --> Config Class Initialized
DEBUG - 2011-09-30 09:49:50 --> Hooks Class Initialized
DEBUG - 2011-09-30 09:49:50 --> Utf8 Class Initialized
DEBUG - 2011-09-30 09:49:50 --> UTF-8 Support Enabled
DEBUG - 2011-09-30 09:49:50 --> URI Class Initialized
DEBUG - 2011-09-30 09:49:50 --> Router Class Initialized
DEBUG - 2011-09-30 09:49:50 --> Output Class Initialized
DEBUG - 2011-09-30 09:49:50 --> Input Class Initialized
DEBUG - 2011-09-30 09:49:50 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-30 09:49:50 --> Language Class Initialized
DEBUG - 2011-09-30 09:49:50 --> Loader Class Initialized
DEBUG - 2011-09-30 09:49:50 --> Controller Class Initialized
ERROR - 2011-09-30 09:49:50 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-30 09:49:50 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-30 09:49:50 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-30 09:49:50 --> Model Class Initialized
DEBUG - 2011-09-30 09:49:50 --> Model Class Initialized
DEBUG - 2011-09-30 09:49:50 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-30 09:49:50 --> Database Driver Class Initialized
DEBUG - 2011-09-30 09:49:50 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-30 09:49:50 --> Helper loaded: url_helper
DEBUG - 2011-09-30 09:49:50 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-30 09:49:50 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-30 09:49:50 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-30 09:49:50 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-30 09:49:50 --> Final output sent to browser
DEBUG - 2011-09-30 09:49:50 --> Total execution time: 0.1109
DEBUG - 2011-09-30 09:49:51 --> Config Class Initialized
DEBUG - 2011-09-30 09:49:51 --> Hooks Class Initialized
DEBUG - 2011-09-30 09:49:51 --> Utf8 Class Initialized
DEBUG - 2011-09-30 09:49:51 --> UTF-8 Support Enabled
DEBUG - 2011-09-30 09:49:51 --> URI Class Initialized
DEBUG - 2011-09-30 09:49:51 --> Router Class Initialized
DEBUG - 2011-09-30 09:49:51 --> Output Class Initialized
DEBUG - 2011-09-30 09:49:51 --> Input Class Initialized
DEBUG - 2011-09-30 09:49:51 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-30 09:49:51 --> Language Class Initialized
DEBUG - 2011-09-30 09:49:51 --> Loader Class Initialized
DEBUG - 2011-09-30 09:49:51 --> Controller Class Initialized
DEBUG - 2011-09-30 09:49:51 --> Model Class Initialized
DEBUG - 2011-09-30 09:49:51 --> Model Class Initialized
DEBUG - 2011-09-30 09:49:51 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-30 09:49:51 --> Database Driver Class Initialized
DEBUG - 2011-09-30 09:49:52 --> Final output sent to browser
DEBUG - 2011-09-30 09:49:52 --> Total execution time: 0.9495
DEBUG - 2011-09-30 09:49:54 --> Config Class Initialized
DEBUG - 2011-09-30 09:49:54 --> Hooks Class Initialized
DEBUG - 2011-09-30 09:49:54 --> Utf8 Class Initialized
DEBUG - 2011-09-30 09:49:54 --> UTF-8 Support Enabled
DEBUG - 2011-09-30 09:49:54 --> URI Class Initialized
DEBUG - 2011-09-30 09:49:54 --> Router Class Initialized
ERROR - 2011-09-30 09:49:54 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-30 09:50:04 --> Config Class Initialized
DEBUG - 2011-09-30 09:50:04 --> Hooks Class Initialized
DEBUG - 2011-09-30 09:50:04 --> Utf8 Class Initialized
DEBUG - 2011-09-30 09:50:04 --> UTF-8 Support Enabled
DEBUG - 2011-09-30 09:50:04 --> URI Class Initialized
DEBUG - 2011-09-30 09:50:04 --> Router Class Initialized
DEBUG - 2011-09-30 09:50:04 --> Output Class Initialized
DEBUG - 2011-09-30 09:50:04 --> Input Class Initialized
DEBUG - 2011-09-30 09:50:04 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-30 09:50:04 --> Language Class Initialized
DEBUG - 2011-09-30 09:50:04 --> Loader Class Initialized
DEBUG - 2011-09-30 09:50:04 --> Controller Class Initialized
ERROR - 2011-09-30 09:50:04 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-30 09:50:04 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-30 09:50:04 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-30 09:50:04 --> Model Class Initialized
DEBUG - 2011-09-30 09:50:04 --> Model Class Initialized
DEBUG - 2011-09-30 09:50:04 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-30 09:50:04 --> Database Driver Class Initialized
DEBUG - 2011-09-30 09:50:04 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-30 09:50:04 --> Helper loaded: url_helper
DEBUG - 2011-09-30 09:50:04 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-30 09:50:04 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-30 09:50:04 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-30 09:50:04 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-30 09:50:04 --> Final output sent to browser
DEBUG - 2011-09-30 09:50:04 --> Total execution time: 0.2073
DEBUG - 2011-09-30 09:50:05 --> Config Class Initialized
DEBUG - 2011-09-30 09:50:05 --> Hooks Class Initialized
DEBUG - 2011-09-30 09:50:05 --> Utf8 Class Initialized
DEBUG - 2011-09-30 09:50:05 --> UTF-8 Support Enabled
DEBUG - 2011-09-30 09:50:05 --> URI Class Initialized
DEBUG - 2011-09-30 09:50:05 --> Router Class Initialized
DEBUG - 2011-09-30 09:50:05 --> Output Class Initialized
DEBUG - 2011-09-30 09:50:05 --> Input Class Initialized
DEBUG - 2011-09-30 09:50:05 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-30 09:50:05 --> Language Class Initialized
DEBUG - 2011-09-30 09:50:05 --> Loader Class Initialized
DEBUG - 2011-09-30 09:50:05 --> Controller Class Initialized
DEBUG - 2011-09-30 09:50:05 --> Model Class Initialized
DEBUG - 2011-09-30 09:50:05 --> Model Class Initialized
DEBUG - 2011-09-30 09:50:05 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-30 09:50:05 --> Database Driver Class Initialized
DEBUG - 2011-09-30 09:50:06 --> Final output sent to browser
DEBUG - 2011-09-30 09:50:06 --> Total execution time: 0.6872
DEBUG - 2011-09-30 09:50:08 --> Config Class Initialized
DEBUG - 2011-09-30 09:50:08 --> Hooks Class Initialized
DEBUG - 2011-09-30 09:50:08 --> Utf8 Class Initialized
DEBUG - 2011-09-30 09:50:08 --> UTF-8 Support Enabled
DEBUG - 2011-09-30 09:50:08 --> URI Class Initialized
DEBUG - 2011-09-30 09:50:08 --> Router Class Initialized
ERROR - 2011-09-30 09:50:08 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-30 09:50:14 --> Config Class Initialized
DEBUG - 2011-09-30 09:50:14 --> Hooks Class Initialized
DEBUG - 2011-09-30 09:50:14 --> Utf8 Class Initialized
DEBUG - 2011-09-30 09:50:14 --> UTF-8 Support Enabled
DEBUG - 2011-09-30 09:50:14 --> URI Class Initialized
DEBUG - 2011-09-30 09:50:14 --> Router Class Initialized
DEBUG - 2011-09-30 09:50:14 --> Output Class Initialized
DEBUG - 2011-09-30 09:50:14 --> Input Class Initialized
DEBUG - 2011-09-30 09:50:14 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-30 09:50:14 --> Language Class Initialized
DEBUG - 2011-09-30 09:50:14 --> Loader Class Initialized
DEBUG - 2011-09-30 09:50:14 --> Controller Class Initialized
ERROR - 2011-09-30 09:50:14 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-30 09:50:14 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-30 09:50:14 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-30 09:50:14 --> Model Class Initialized
DEBUG - 2011-09-30 09:50:14 --> Model Class Initialized
DEBUG - 2011-09-30 09:50:14 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-30 09:50:14 --> Database Driver Class Initialized
DEBUG - 2011-09-30 09:50:14 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-30 09:50:14 --> Helper loaded: url_helper
DEBUG - 2011-09-30 09:50:14 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-30 09:50:14 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-30 09:50:14 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-30 09:50:14 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-30 09:50:14 --> Final output sent to browser
DEBUG - 2011-09-30 09:50:14 --> Total execution time: 0.0427
DEBUG - 2011-09-30 09:50:15 --> Config Class Initialized
DEBUG - 2011-09-30 09:50:15 --> Hooks Class Initialized
DEBUG - 2011-09-30 09:50:15 --> Utf8 Class Initialized
DEBUG - 2011-09-30 09:50:15 --> UTF-8 Support Enabled
DEBUG - 2011-09-30 09:50:15 --> URI Class Initialized
DEBUG - 2011-09-30 09:50:15 --> Router Class Initialized
DEBUG - 2011-09-30 09:50:15 --> Output Class Initialized
DEBUG - 2011-09-30 09:50:15 --> Input Class Initialized
DEBUG - 2011-09-30 09:50:15 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-30 09:50:15 --> Language Class Initialized
DEBUG - 2011-09-30 09:50:15 --> Loader Class Initialized
DEBUG - 2011-09-30 09:50:15 --> Controller Class Initialized
DEBUG - 2011-09-30 09:50:15 --> Model Class Initialized
DEBUG - 2011-09-30 09:50:15 --> Model Class Initialized
DEBUG - 2011-09-30 09:50:15 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-30 09:50:15 --> Database Driver Class Initialized
DEBUG - 2011-09-30 09:50:16 --> Final output sent to browser
DEBUG - 2011-09-30 09:50:16 --> Total execution time: 0.6211
DEBUG - 2011-09-30 09:50:18 --> Config Class Initialized
DEBUG - 2011-09-30 09:50:18 --> Hooks Class Initialized
DEBUG - 2011-09-30 09:50:18 --> Utf8 Class Initialized
DEBUG - 2011-09-30 09:50:18 --> UTF-8 Support Enabled
DEBUG - 2011-09-30 09:50:18 --> URI Class Initialized
DEBUG - 2011-09-30 09:50:18 --> Router Class Initialized
ERROR - 2011-09-30 09:50:18 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-30 09:50:31 --> Config Class Initialized
DEBUG - 2011-09-30 09:50:31 --> Hooks Class Initialized
DEBUG - 2011-09-30 09:50:31 --> Utf8 Class Initialized
DEBUG - 2011-09-30 09:50:31 --> UTF-8 Support Enabled
DEBUG - 2011-09-30 09:50:31 --> URI Class Initialized
DEBUG - 2011-09-30 09:50:31 --> Router Class Initialized
DEBUG - 2011-09-30 09:50:31 --> Output Class Initialized
DEBUG - 2011-09-30 09:50:31 --> Input Class Initialized
DEBUG - 2011-09-30 09:50:31 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-30 09:50:31 --> Language Class Initialized
DEBUG - 2011-09-30 09:50:31 --> Loader Class Initialized
DEBUG - 2011-09-30 09:50:31 --> Controller Class Initialized
ERROR - 2011-09-30 09:50:31 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-30 09:50:31 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-30 09:50:31 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-30 09:50:31 --> Model Class Initialized
DEBUG - 2011-09-30 09:50:31 --> Model Class Initialized
DEBUG - 2011-09-30 09:50:31 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-30 09:50:31 --> Database Driver Class Initialized
DEBUG - 2011-09-30 09:50:31 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-30 09:50:31 --> Helper loaded: url_helper
DEBUG - 2011-09-30 09:50:31 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-30 09:50:31 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-30 09:50:31 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-30 09:50:31 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-30 09:50:31 --> Final output sent to browser
DEBUG - 2011-09-30 09:50:31 --> Total execution time: 0.0518
DEBUG - 2011-09-30 09:50:32 --> Config Class Initialized
DEBUG - 2011-09-30 09:50:32 --> Hooks Class Initialized
DEBUG - 2011-09-30 09:50:32 --> Utf8 Class Initialized
DEBUG - 2011-09-30 09:50:32 --> UTF-8 Support Enabled
DEBUG - 2011-09-30 09:50:32 --> URI Class Initialized
DEBUG - 2011-09-30 09:50:32 --> Router Class Initialized
DEBUG - 2011-09-30 09:50:32 --> Output Class Initialized
DEBUG - 2011-09-30 09:50:32 --> Input Class Initialized
DEBUG - 2011-09-30 09:50:32 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-30 09:50:32 --> Language Class Initialized
DEBUG - 2011-09-30 09:50:32 --> Loader Class Initialized
DEBUG - 2011-09-30 09:50:32 --> Controller Class Initialized
DEBUG - 2011-09-30 09:50:32 --> Model Class Initialized
DEBUG - 2011-09-30 09:50:32 --> Model Class Initialized
DEBUG - 2011-09-30 09:50:32 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-30 09:50:32 --> Database Driver Class Initialized
DEBUG - 2011-09-30 09:50:33 --> Final output sent to browser
DEBUG - 2011-09-30 09:50:33 --> Total execution time: 0.8211
DEBUG - 2011-09-30 09:50:35 --> Config Class Initialized
DEBUG - 2011-09-30 09:50:35 --> Hooks Class Initialized
DEBUG - 2011-09-30 09:50:35 --> Utf8 Class Initialized
DEBUG - 2011-09-30 09:50:35 --> UTF-8 Support Enabled
DEBUG - 2011-09-30 09:50:35 --> URI Class Initialized
DEBUG - 2011-09-30 09:50:35 --> Router Class Initialized
ERROR - 2011-09-30 09:50:35 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-30 09:50:42 --> Config Class Initialized
DEBUG - 2011-09-30 09:50:42 --> Hooks Class Initialized
DEBUG - 2011-09-30 09:50:42 --> Utf8 Class Initialized
DEBUG - 2011-09-30 09:50:42 --> UTF-8 Support Enabled
DEBUG - 2011-09-30 09:50:42 --> URI Class Initialized
DEBUG - 2011-09-30 09:50:42 --> Router Class Initialized
DEBUG - 2011-09-30 09:50:42 --> Output Class Initialized
DEBUG - 2011-09-30 09:50:42 --> Input Class Initialized
DEBUG - 2011-09-30 09:50:42 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-30 09:50:42 --> Language Class Initialized
DEBUG - 2011-09-30 09:50:42 --> Loader Class Initialized
DEBUG - 2011-09-30 09:50:42 --> Controller Class Initialized
ERROR - 2011-09-30 09:50:42 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-30 09:50:42 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-30 09:50:42 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-30 09:50:42 --> Model Class Initialized
DEBUG - 2011-09-30 09:50:42 --> Model Class Initialized
DEBUG - 2011-09-30 09:50:42 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-30 09:50:42 --> Database Driver Class Initialized
DEBUG - 2011-09-30 09:50:42 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-30 09:50:42 --> Helper loaded: url_helper
DEBUG - 2011-09-30 09:50:42 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-30 09:50:42 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-30 09:50:42 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-30 09:50:42 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-30 09:50:42 --> Final output sent to browser
DEBUG - 2011-09-30 09:50:42 --> Total execution time: 0.0354
DEBUG - 2011-09-30 09:50:43 --> Config Class Initialized
DEBUG - 2011-09-30 09:50:43 --> Hooks Class Initialized
DEBUG - 2011-09-30 09:50:43 --> Utf8 Class Initialized
DEBUG - 2011-09-30 09:50:43 --> UTF-8 Support Enabled
DEBUG - 2011-09-30 09:50:43 --> URI Class Initialized
DEBUG - 2011-09-30 09:50:43 --> Router Class Initialized
DEBUG - 2011-09-30 09:50:43 --> Output Class Initialized
DEBUG - 2011-09-30 09:50:43 --> Input Class Initialized
DEBUG - 2011-09-30 09:50:43 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-30 09:50:43 --> Language Class Initialized
DEBUG - 2011-09-30 09:50:43 --> Loader Class Initialized
DEBUG - 2011-09-30 09:50:43 --> Controller Class Initialized
DEBUG - 2011-09-30 09:50:43 --> Model Class Initialized
DEBUG - 2011-09-30 09:50:43 --> Model Class Initialized
DEBUG - 2011-09-30 09:50:43 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-30 09:50:43 --> Database Driver Class Initialized
DEBUG - 2011-09-30 09:50:44 --> Final output sent to browser
DEBUG - 2011-09-30 09:50:44 --> Total execution time: 0.7879
DEBUG - 2011-09-30 09:50:46 --> Config Class Initialized
DEBUG - 2011-09-30 09:50:46 --> Hooks Class Initialized
DEBUG - 2011-09-30 09:50:46 --> Utf8 Class Initialized
DEBUG - 2011-09-30 09:50:46 --> UTF-8 Support Enabled
DEBUG - 2011-09-30 09:50:46 --> URI Class Initialized
DEBUG - 2011-09-30 09:50:46 --> Router Class Initialized
ERROR - 2011-09-30 09:50:46 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-30 09:50:48 --> Config Class Initialized
DEBUG - 2011-09-30 09:50:48 --> Hooks Class Initialized
DEBUG - 2011-09-30 09:50:48 --> Utf8 Class Initialized
DEBUG - 2011-09-30 09:50:48 --> UTF-8 Support Enabled
DEBUG - 2011-09-30 09:50:48 --> URI Class Initialized
DEBUG - 2011-09-30 09:50:48 --> Router Class Initialized
ERROR - 2011-09-30 09:50:48 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-30 09:50:49 --> Config Class Initialized
DEBUG - 2011-09-30 09:50:49 --> Hooks Class Initialized
DEBUG - 2011-09-30 09:50:49 --> Utf8 Class Initialized
DEBUG - 2011-09-30 09:50:49 --> UTF-8 Support Enabled
DEBUG - 2011-09-30 09:50:49 --> URI Class Initialized
DEBUG - 2011-09-30 09:50:49 --> Router Class Initialized
ERROR - 2011-09-30 09:50:49 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-30 09:51:05 --> Config Class Initialized
DEBUG - 2011-09-30 09:51:05 --> Hooks Class Initialized
DEBUG - 2011-09-30 09:51:05 --> Utf8 Class Initialized
DEBUG - 2011-09-30 09:51:05 --> UTF-8 Support Enabled
DEBUG - 2011-09-30 09:51:05 --> URI Class Initialized
DEBUG - 2011-09-30 09:51:05 --> Router Class Initialized
ERROR - 2011-09-30 09:51:05 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-30 09:51:26 --> Config Class Initialized
DEBUG - 2011-09-30 09:51:26 --> Hooks Class Initialized
DEBUG - 2011-09-30 09:51:26 --> Utf8 Class Initialized
DEBUG - 2011-09-30 09:51:26 --> UTF-8 Support Enabled
DEBUG - 2011-09-30 09:51:26 --> URI Class Initialized
DEBUG - 2011-09-30 09:51:26 --> Router Class Initialized
DEBUG - 2011-09-30 09:51:26 --> Output Class Initialized
DEBUG - 2011-09-30 09:51:26 --> Input Class Initialized
DEBUG - 2011-09-30 09:51:26 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-30 09:51:26 --> Language Class Initialized
DEBUG - 2011-09-30 09:51:26 --> Loader Class Initialized
DEBUG - 2011-09-30 09:51:26 --> Controller Class Initialized
ERROR - 2011-09-30 09:51:26 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-30 09:51:26 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-30 09:51:26 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-30 09:51:26 --> Model Class Initialized
DEBUG - 2011-09-30 09:51:26 --> Model Class Initialized
DEBUG - 2011-09-30 09:51:26 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-30 09:51:26 --> Database Driver Class Initialized
DEBUG - 2011-09-30 09:51:26 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-30 09:51:26 --> Helper loaded: url_helper
DEBUG - 2011-09-30 09:51:26 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-30 09:51:26 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-30 09:51:26 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-30 09:51:26 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-30 09:51:26 --> Final output sent to browser
DEBUG - 2011-09-30 09:51:26 --> Total execution time: 0.0317
DEBUG - 2011-09-30 09:51:27 --> Config Class Initialized
DEBUG - 2011-09-30 09:51:27 --> Hooks Class Initialized
DEBUG - 2011-09-30 09:51:27 --> Utf8 Class Initialized
DEBUG - 2011-09-30 09:51:27 --> UTF-8 Support Enabled
DEBUG - 2011-09-30 09:51:27 --> URI Class Initialized
DEBUG - 2011-09-30 09:51:27 --> Router Class Initialized
DEBUG - 2011-09-30 09:51:27 --> Output Class Initialized
DEBUG - 2011-09-30 09:51:27 --> Input Class Initialized
DEBUG - 2011-09-30 09:51:27 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-30 09:51:27 --> Language Class Initialized
DEBUG - 2011-09-30 09:51:27 --> Loader Class Initialized
DEBUG - 2011-09-30 09:51:27 --> Controller Class Initialized
DEBUG - 2011-09-30 09:51:27 --> Model Class Initialized
DEBUG - 2011-09-30 09:51:27 --> Model Class Initialized
DEBUG - 2011-09-30 09:51:27 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-30 09:51:27 --> Database Driver Class Initialized
DEBUG - 2011-09-30 09:51:28 --> Final output sent to browser
DEBUG - 2011-09-30 09:51:28 --> Total execution time: 0.5909
DEBUG - 2011-09-30 09:51:29 --> Config Class Initialized
DEBUG - 2011-09-30 09:51:29 --> Hooks Class Initialized
DEBUG - 2011-09-30 09:51:29 --> Utf8 Class Initialized
DEBUG - 2011-09-30 09:51:29 --> UTF-8 Support Enabled
DEBUG - 2011-09-30 09:51:29 --> URI Class Initialized
DEBUG - 2011-09-30 09:51:29 --> Router Class Initialized
ERROR - 2011-09-30 09:51:29 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-30 09:51:46 --> Config Class Initialized
DEBUG - 2011-09-30 09:51:46 --> Hooks Class Initialized
DEBUG - 2011-09-30 09:51:46 --> Utf8 Class Initialized
DEBUG - 2011-09-30 09:51:46 --> UTF-8 Support Enabled
DEBUG - 2011-09-30 09:51:46 --> URI Class Initialized
DEBUG - 2011-09-30 09:51:46 --> Router Class Initialized
DEBUG - 2011-09-30 09:51:46 --> Output Class Initialized
DEBUG - 2011-09-30 09:51:46 --> Input Class Initialized
DEBUG - 2011-09-30 09:51:46 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-30 09:51:46 --> Language Class Initialized
DEBUG - 2011-09-30 09:51:46 --> Loader Class Initialized
DEBUG - 2011-09-30 09:51:46 --> Controller Class Initialized
ERROR - 2011-09-30 09:51:46 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-30 09:51:46 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-30 09:51:46 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-30 09:51:46 --> Model Class Initialized
DEBUG - 2011-09-30 09:51:46 --> Model Class Initialized
DEBUG - 2011-09-30 09:51:46 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-30 09:51:46 --> Database Driver Class Initialized
DEBUG - 2011-09-30 09:51:46 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-30 09:51:46 --> Helper loaded: url_helper
DEBUG - 2011-09-30 09:51:46 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-30 09:51:46 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-30 09:51:46 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-30 09:51:46 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-30 09:51:46 --> Final output sent to browser
DEBUG - 2011-09-30 09:51:46 --> Total execution time: 0.0352
DEBUG - 2011-09-30 09:51:48 --> Config Class Initialized
DEBUG - 2011-09-30 09:51:48 --> Hooks Class Initialized
DEBUG - 2011-09-30 09:51:48 --> Utf8 Class Initialized
DEBUG - 2011-09-30 09:51:48 --> UTF-8 Support Enabled
DEBUG - 2011-09-30 09:51:48 --> URI Class Initialized
DEBUG - 2011-09-30 09:51:48 --> Router Class Initialized
DEBUG - 2011-09-30 09:51:48 --> Output Class Initialized
DEBUG - 2011-09-30 09:51:48 --> Input Class Initialized
DEBUG - 2011-09-30 09:51:48 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-30 09:51:48 --> Language Class Initialized
DEBUG - 2011-09-30 09:51:48 --> Loader Class Initialized
DEBUG - 2011-09-30 09:51:48 --> Controller Class Initialized
DEBUG - 2011-09-30 09:51:48 --> Model Class Initialized
DEBUG - 2011-09-30 09:51:48 --> Model Class Initialized
DEBUG - 2011-09-30 09:51:48 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-30 09:51:48 --> Database Driver Class Initialized
DEBUG - 2011-09-30 09:51:49 --> Final output sent to browser
DEBUG - 2011-09-30 09:51:49 --> Total execution time: 1.0457
DEBUG - 2011-09-30 09:51:50 --> Config Class Initialized
DEBUG - 2011-09-30 09:51:50 --> Hooks Class Initialized
DEBUG - 2011-09-30 09:51:50 --> Utf8 Class Initialized
DEBUG - 2011-09-30 09:51:50 --> UTF-8 Support Enabled
DEBUG - 2011-09-30 09:51:50 --> URI Class Initialized
DEBUG - 2011-09-30 09:51:50 --> Router Class Initialized
ERROR - 2011-09-30 09:51:50 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-30 09:52:02 --> Config Class Initialized
DEBUG - 2011-09-30 09:52:02 --> Hooks Class Initialized
DEBUG - 2011-09-30 09:52:02 --> Utf8 Class Initialized
DEBUG - 2011-09-30 09:52:02 --> UTF-8 Support Enabled
DEBUG - 2011-09-30 09:52:02 --> URI Class Initialized
DEBUG - 2011-09-30 09:52:02 --> Router Class Initialized
DEBUG - 2011-09-30 09:52:02 --> Output Class Initialized
DEBUG - 2011-09-30 09:52:02 --> Input Class Initialized
DEBUG - 2011-09-30 09:52:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-30 09:52:02 --> Language Class Initialized
DEBUG - 2011-09-30 09:52:02 --> Loader Class Initialized
DEBUG - 2011-09-30 09:52:02 --> Controller Class Initialized
ERROR - 2011-09-30 09:52:02 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-30 09:52:02 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-30 09:52:02 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-30 09:52:02 --> Model Class Initialized
DEBUG - 2011-09-30 09:52:02 --> Model Class Initialized
DEBUG - 2011-09-30 09:52:02 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-30 09:52:02 --> Database Driver Class Initialized
DEBUG - 2011-09-30 09:52:02 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-30 09:52:02 --> Helper loaded: url_helper
DEBUG - 2011-09-30 09:52:02 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-30 09:52:02 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-30 09:52:02 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-30 09:52:02 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-30 09:52:02 --> Final output sent to browser
DEBUG - 2011-09-30 09:52:02 --> Total execution time: 0.0718
DEBUG - 2011-09-30 09:52:04 --> Config Class Initialized
DEBUG - 2011-09-30 09:52:04 --> Hooks Class Initialized
DEBUG - 2011-09-30 09:52:04 --> Utf8 Class Initialized
DEBUG - 2011-09-30 09:52:04 --> UTF-8 Support Enabled
DEBUG - 2011-09-30 09:52:04 --> URI Class Initialized
DEBUG - 2011-09-30 09:52:04 --> Router Class Initialized
DEBUG - 2011-09-30 09:52:04 --> Output Class Initialized
DEBUG - 2011-09-30 09:52:04 --> Input Class Initialized
DEBUG - 2011-09-30 09:52:04 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-30 09:52:04 --> Language Class Initialized
DEBUG - 2011-09-30 09:52:04 --> Loader Class Initialized
DEBUG - 2011-09-30 09:52:04 --> Controller Class Initialized
DEBUG - 2011-09-30 09:52:04 --> Model Class Initialized
DEBUG - 2011-09-30 09:52:04 --> Model Class Initialized
DEBUG - 2011-09-30 09:52:04 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-30 09:52:04 --> Database Driver Class Initialized
DEBUG - 2011-09-30 09:52:04 --> Final output sent to browser
DEBUG - 2011-09-30 09:52:04 --> Total execution time: 0.6237
DEBUG - 2011-09-30 09:52:06 --> Config Class Initialized
DEBUG - 2011-09-30 09:52:06 --> Hooks Class Initialized
DEBUG - 2011-09-30 09:52:06 --> Utf8 Class Initialized
DEBUG - 2011-09-30 09:52:06 --> UTF-8 Support Enabled
DEBUG - 2011-09-30 09:52:06 --> URI Class Initialized
DEBUG - 2011-09-30 09:52:06 --> Router Class Initialized
ERROR - 2011-09-30 09:52:06 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-30 09:52:14 --> Config Class Initialized
DEBUG - 2011-09-30 09:52:14 --> Hooks Class Initialized
DEBUG - 2011-09-30 09:52:14 --> Utf8 Class Initialized
DEBUG - 2011-09-30 09:52:14 --> UTF-8 Support Enabled
DEBUG - 2011-09-30 09:52:14 --> URI Class Initialized
DEBUG - 2011-09-30 09:52:14 --> Router Class Initialized
DEBUG - 2011-09-30 09:52:14 --> Output Class Initialized
DEBUG - 2011-09-30 09:52:14 --> Input Class Initialized
DEBUG - 2011-09-30 09:52:14 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-30 09:52:14 --> Language Class Initialized
DEBUG - 2011-09-30 09:52:14 --> Loader Class Initialized
DEBUG - 2011-09-30 09:52:14 --> Controller Class Initialized
ERROR - 2011-09-30 09:52:14 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-30 09:52:14 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-30 09:52:14 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-30 09:52:14 --> Model Class Initialized
DEBUG - 2011-09-30 09:52:14 --> Model Class Initialized
DEBUG - 2011-09-30 09:52:14 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-30 09:52:14 --> Database Driver Class Initialized
DEBUG - 2011-09-30 09:52:14 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-30 09:52:14 --> Helper loaded: url_helper
DEBUG - 2011-09-30 09:52:14 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-30 09:52:14 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-30 09:52:14 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-30 09:52:14 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-30 09:52:14 --> Final output sent to browser
DEBUG - 2011-09-30 09:52:14 --> Total execution time: 0.0299
DEBUG - 2011-09-30 09:52:15 --> Config Class Initialized
DEBUG - 2011-09-30 09:52:15 --> Hooks Class Initialized
DEBUG - 2011-09-30 09:52:15 --> Utf8 Class Initialized
DEBUG - 2011-09-30 09:52:15 --> UTF-8 Support Enabled
DEBUG - 2011-09-30 09:52:15 --> URI Class Initialized
DEBUG - 2011-09-30 09:52:15 --> Router Class Initialized
DEBUG - 2011-09-30 09:52:15 --> Output Class Initialized
DEBUG - 2011-09-30 09:52:15 --> Input Class Initialized
DEBUG - 2011-09-30 09:52:15 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-30 09:52:15 --> Language Class Initialized
DEBUG - 2011-09-30 09:52:15 --> Loader Class Initialized
DEBUG - 2011-09-30 09:52:15 --> Controller Class Initialized
DEBUG - 2011-09-30 09:52:15 --> Model Class Initialized
DEBUG - 2011-09-30 09:52:15 --> Model Class Initialized
DEBUG - 2011-09-30 09:52:15 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-30 09:52:15 --> Database Driver Class Initialized
DEBUG - 2011-09-30 09:52:15 --> Final output sent to browser
DEBUG - 2011-09-30 09:52:15 --> Total execution time: 0.9473
DEBUG - 2011-09-30 09:52:17 --> Config Class Initialized
DEBUG - 2011-09-30 09:52:17 --> Hooks Class Initialized
DEBUG - 2011-09-30 09:52:17 --> Utf8 Class Initialized
DEBUG - 2011-09-30 09:52:17 --> UTF-8 Support Enabled
DEBUG - 2011-09-30 09:52:17 --> URI Class Initialized
DEBUG - 2011-09-30 09:52:17 --> Router Class Initialized
ERROR - 2011-09-30 09:52:17 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-30 09:52:17 --> Config Class Initialized
DEBUG - 2011-09-30 09:52:17 --> Hooks Class Initialized
DEBUG - 2011-09-30 09:52:17 --> Utf8 Class Initialized
DEBUG - 2011-09-30 09:52:17 --> UTF-8 Support Enabled
DEBUG - 2011-09-30 09:52:17 --> URI Class Initialized
DEBUG - 2011-09-30 09:52:17 --> Router Class Initialized
DEBUG - 2011-09-30 09:52:17 --> Output Class Initialized
DEBUG - 2011-09-30 09:52:17 --> Input Class Initialized
DEBUG - 2011-09-30 09:52:17 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-30 09:52:17 --> Language Class Initialized
DEBUG - 2011-09-30 09:52:17 --> Loader Class Initialized
DEBUG - 2011-09-30 09:52:17 --> Controller Class Initialized
ERROR - 2011-09-30 09:52:17 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-30 09:52:17 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-30 09:52:17 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-30 09:52:17 --> Model Class Initialized
DEBUG - 2011-09-30 09:52:17 --> Model Class Initialized
DEBUG - 2011-09-30 09:52:17 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-30 09:52:17 --> Database Driver Class Initialized
DEBUG - 2011-09-30 09:52:17 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-30 09:52:17 --> Helper loaded: url_helper
DEBUG - 2011-09-30 09:52:17 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-30 09:52:17 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-30 09:52:17 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-30 09:52:17 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-30 09:52:17 --> Final output sent to browser
DEBUG - 2011-09-30 09:52:17 --> Total execution time: 0.0339
DEBUG - 2011-09-30 09:52:18 --> Config Class Initialized
DEBUG - 2011-09-30 09:52:18 --> Hooks Class Initialized
DEBUG - 2011-09-30 09:52:18 --> Utf8 Class Initialized
DEBUG - 2011-09-30 09:52:18 --> UTF-8 Support Enabled
DEBUG - 2011-09-30 09:52:18 --> URI Class Initialized
DEBUG - 2011-09-30 09:52:18 --> Router Class Initialized
DEBUG - 2011-09-30 09:52:18 --> Output Class Initialized
DEBUG - 2011-09-30 09:52:18 --> Input Class Initialized
DEBUG - 2011-09-30 09:52:18 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-30 09:52:18 --> Language Class Initialized
DEBUG - 2011-09-30 09:52:18 --> Loader Class Initialized
DEBUG - 2011-09-30 09:52:18 --> Controller Class Initialized
DEBUG - 2011-09-30 09:52:18 --> Model Class Initialized
DEBUG - 2011-09-30 09:52:18 --> Model Class Initialized
DEBUG - 2011-09-30 09:52:18 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-30 09:52:18 --> Database Driver Class Initialized
DEBUG - 2011-09-30 09:52:19 --> Final output sent to browser
DEBUG - 2011-09-30 09:52:19 --> Total execution time: 0.6302
DEBUG - 2011-09-30 09:52:20 --> Config Class Initialized
DEBUG - 2011-09-30 09:52:20 --> Hooks Class Initialized
DEBUG - 2011-09-30 09:52:20 --> Utf8 Class Initialized
DEBUG - 2011-09-30 09:52:20 --> UTF-8 Support Enabled
DEBUG - 2011-09-30 09:52:20 --> URI Class Initialized
DEBUG - 2011-09-30 09:52:20 --> Router Class Initialized
ERROR - 2011-09-30 09:52:20 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-30 09:52:31 --> Config Class Initialized
DEBUG - 2011-09-30 09:52:31 --> Hooks Class Initialized
DEBUG - 2011-09-30 09:52:31 --> Utf8 Class Initialized
DEBUG - 2011-09-30 09:52:31 --> UTF-8 Support Enabled
DEBUG - 2011-09-30 09:52:31 --> URI Class Initialized
DEBUG - 2011-09-30 09:52:31 --> Router Class Initialized
DEBUG - 2011-09-30 09:52:31 --> Output Class Initialized
DEBUG - 2011-09-30 09:52:31 --> Input Class Initialized
DEBUG - 2011-09-30 09:52:31 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-30 09:52:31 --> Language Class Initialized
DEBUG - 2011-09-30 09:52:31 --> Loader Class Initialized
DEBUG - 2011-09-30 09:52:31 --> Controller Class Initialized
DEBUG - 2011-09-30 09:52:31 --> Model Class Initialized
DEBUG - 2011-09-30 09:52:31 --> Model Class Initialized
DEBUG - 2011-09-30 09:52:31 --> Model Class Initialized
DEBUG - 2011-09-30 09:52:31 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-30 09:52:31 --> Database Driver Class Initialized
DEBUG - 2011-09-30 09:52:31 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-30 09:52:31 --> Helper loaded: url_helper
DEBUG - 2011-09-30 09:52:31 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-30 09:52:31 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-30 09:52:31 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-30 09:52:31 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-30 09:52:31 --> Final output sent to browser
DEBUG - 2011-09-30 09:52:31 --> Total execution time: 0.6161
DEBUG - 2011-09-30 09:52:33 --> Config Class Initialized
DEBUG - 2011-09-30 09:52:33 --> Hooks Class Initialized
DEBUG - 2011-09-30 09:52:33 --> Utf8 Class Initialized
DEBUG - 2011-09-30 09:52:33 --> UTF-8 Support Enabled
DEBUG - 2011-09-30 09:52:33 --> URI Class Initialized
DEBUG - 2011-09-30 09:52:33 --> Router Class Initialized
ERROR - 2011-09-30 09:52:33 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-30 09:52:51 --> Config Class Initialized
DEBUG - 2011-09-30 09:52:51 --> Hooks Class Initialized
DEBUG - 2011-09-30 09:52:51 --> Utf8 Class Initialized
DEBUG - 2011-09-30 09:52:51 --> UTF-8 Support Enabled
DEBUG - 2011-09-30 09:52:51 --> URI Class Initialized
DEBUG - 2011-09-30 09:52:51 --> Router Class Initialized
DEBUG - 2011-09-30 09:52:51 --> Output Class Initialized
DEBUG - 2011-09-30 09:52:51 --> Input Class Initialized
DEBUG - 2011-09-30 09:52:51 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-30 09:52:51 --> Language Class Initialized
DEBUG - 2011-09-30 09:52:51 --> Loader Class Initialized
DEBUG - 2011-09-30 09:52:51 --> Controller Class Initialized
DEBUG - 2011-09-30 09:52:51 --> Model Class Initialized
DEBUG - 2011-09-30 09:52:51 --> Model Class Initialized
DEBUG - 2011-09-30 09:52:51 --> Model Class Initialized
DEBUG - 2011-09-30 09:52:51 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-30 09:52:51 --> Database Driver Class Initialized
DEBUG - 2011-09-30 09:52:51 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-30 09:52:51 --> Helper loaded: url_helper
DEBUG - 2011-09-30 09:52:51 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-30 09:52:51 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-30 09:52:51 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-30 09:52:51 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-30 09:52:51 --> Final output sent to browser
DEBUG - 2011-09-30 09:52:51 --> Total execution time: 0.1995
DEBUG - 2011-09-30 09:52:53 --> Config Class Initialized
DEBUG - 2011-09-30 09:52:53 --> Hooks Class Initialized
DEBUG - 2011-09-30 09:52:53 --> Utf8 Class Initialized
DEBUG - 2011-09-30 09:52:53 --> UTF-8 Support Enabled
DEBUG - 2011-09-30 09:52:53 --> URI Class Initialized
DEBUG - 2011-09-30 09:52:53 --> Router Class Initialized
ERROR - 2011-09-30 09:52:53 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-30 09:52:55 --> Config Class Initialized
DEBUG - 2011-09-30 09:52:55 --> Hooks Class Initialized
DEBUG - 2011-09-30 09:52:55 --> Utf8 Class Initialized
DEBUG - 2011-09-30 09:52:55 --> UTF-8 Support Enabled
DEBUG - 2011-09-30 09:52:55 --> URI Class Initialized
DEBUG - 2011-09-30 09:52:55 --> Router Class Initialized
DEBUG - 2011-09-30 09:52:55 --> Output Class Initialized
DEBUG - 2011-09-30 09:52:55 --> Input Class Initialized
DEBUG - 2011-09-30 09:52:55 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-30 09:52:55 --> Language Class Initialized
DEBUG - 2011-09-30 09:52:55 --> Loader Class Initialized
DEBUG - 2011-09-30 09:52:55 --> Controller Class Initialized
DEBUG - 2011-09-30 09:52:55 --> Model Class Initialized
DEBUG - 2011-09-30 09:52:55 --> Model Class Initialized
DEBUG - 2011-09-30 09:52:55 --> Model Class Initialized
DEBUG - 2011-09-30 09:52:55 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-30 09:52:55 --> Database Driver Class Initialized
DEBUG - 2011-09-30 09:52:55 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-30 09:52:55 --> Helper loaded: url_helper
DEBUG - 2011-09-30 09:52:55 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-30 09:52:55 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-30 09:52:55 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-30 09:52:55 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-30 09:52:55 --> Final output sent to browser
DEBUG - 2011-09-30 09:52:55 --> Total execution time: 0.0499
DEBUG - 2011-09-30 10:54:28 --> Config Class Initialized
DEBUG - 2011-09-30 10:54:28 --> Hooks Class Initialized
DEBUG - 2011-09-30 10:54:28 --> Utf8 Class Initialized
DEBUG - 2011-09-30 10:54:28 --> UTF-8 Support Enabled
DEBUG - 2011-09-30 10:54:28 --> URI Class Initialized
DEBUG - 2011-09-30 10:54:28 --> Router Class Initialized
DEBUG - 2011-09-30 10:54:28 --> Output Class Initialized
DEBUG - 2011-09-30 10:54:28 --> Input Class Initialized
DEBUG - 2011-09-30 10:54:28 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-30 10:54:28 --> Language Class Initialized
DEBUG - 2011-09-30 10:54:28 --> Loader Class Initialized
DEBUG - 2011-09-30 10:54:28 --> Controller Class Initialized
ERROR - 2011-09-30 10:54:28 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-30 10:54:28 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-30 10:54:28 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-30 10:54:28 --> Model Class Initialized
DEBUG - 2011-09-30 10:54:28 --> Model Class Initialized
DEBUG - 2011-09-30 10:54:28 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-30 10:54:28 --> Database Driver Class Initialized
DEBUG - 2011-09-30 10:54:28 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-30 10:54:28 --> Helper loaded: url_helper
DEBUG - 2011-09-30 10:54:28 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-30 10:54:28 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-30 10:54:28 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-30 10:54:28 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-30 10:54:28 --> Final output sent to browser
DEBUG - 2011-09-30 10:54:28 --> Total execution time: 0.2496
DEBUG - 2011-09-30 10:54:33 --> Config Class Initialized
DEBUG - 2011-09-30 10:54:33 --> Hooks Class Initialized
DEBUG - 2011-09-30 10:54:33 --> Utf8 Class Initialized
DEBUG - 2011-09-30 10:54:33 --> UTF-8 Support Enabled
DEBUG - 2011-09-30 10:54:33 --> URI Class Initialized
DEBUG - 2011-09-30 10:54:33 --> Router Class Initialized
DEBUG - 2011-09-30 10:54:33 --> Output Class Initialized
DEBUG - 2011-09-30 10:54:33 --> Input Class Initialized
DEBUG - 2011-09-30 10:54:33 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-30 10:54:33 --> Language Class Initialized
DEBUG - 2011-09-30 10:54:33 --> Loader Class Initialized
DEBUG - 2011-09-30 10:54:33 --> Controller Class Initialized
DEBUG - 2011-09-30 10:54:33 --> Model Class Initialized
DEBUG - 2011-09-30 10:54:33 --> Model Class Initialized
DEBUG - 2011-09-30 10:54:33 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-30 10:54:33 --> Database Driver Class Initialized
DEBUG - 2011-09-30 10:54:34 --> Final output sent to browser
DEBUG - 2011-09-30 10:54:34 --> Total execution time: 0.7899
DEBUG - 2011-09-30 12:48:46 --> Config Class Initialized
DEBUG - 2011-09-30 12:48:46 --> Hooks Class Initialized
DEBUG - 2011-09-30 12:48:46 --> Utf8 Class Initialized
DEBUG - 2011-09-30 12:48:46 --> UTF-8 Support Enabled
DEBUG - 2011-09-30 12:48:46 --> URI Class Initialized
DEBUG - 2011-09-30 12:48:46 --> Router Class Initialized
DEBUG - 2011-09-30 12:48:46 --> Output Class Initialized
DEBUG - 2011-09-30 12:48:46 --> Input Class Initialized
DEBUG - 2011-09-30 12:48:46 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-30 12:48:46 --> Language Class Initialized
DEBUG - 2011-09-30 12:48:46 --> Loader Class Initialized
DEBUG - 2011-09-30 12:48:46 --> Controller Class Initialized
DEBUG - 2011-09-30 12:48:46 --> Model Class Initialized
DEBUG - 2011-09-30 12:48:46 --> Model Class Initialized
DEBUG - 2011-09-30 12:48:46 --> Model Class Initialized
DEBUG - 2011-09-30 12:48:46 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-30 12:48:47 --> Database Driver Class Initialized
DEBUG - 2011-09-30 12:48:48 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-30 12:48:48 --> Helper loaded: url_helper
DEBUG - 2011-09-30 12:48:48 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-30 12:48:48 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-30 12:48:48 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-30 12:48:48 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-30 12:48:48 --> Final output sent to browser
DEBUG - 2011-09-30 12:48:48 --> Total execution time: 1.3020
DEBUG - 2011-09-30 12:48:48 --> Config Class Initialized
DEBUG - 2011-09-30 12:48:48 --> Hooks Class Initialized
DEBUG - 2011-09-30 12:48:48 --> Utf8 Class Initialized
DEBUG - 2011-09-30 12:48:48 --> UTF-8 Support Enabled
DEBUG - 2011-09-30 12:48:48 --> URI Class Initialized
DEBUG - 2011-09-30 12:48:48 --> Router Class Initialized
DEBUG - 2011-09-30 12:48:48 --> Output Class Initialized
DEBUG - 2011-09-30 12:48:48 --> Input Class Initialized
DEBUG - 2011-09-30 12:48:48 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-30 12:48:48 --> Language Class Initialized
DEBUG - 2011-09-30 12:48:48 --> Loader Class Initialized
DEBUG - 2011-09-30 12:48:48 --> Controller Class Initialized
ERROR - 2011-09-30 12:48:48 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-30 12:48:48 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-30 12:48:48 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-30 12:48:48 --> Model Class Initialized
DEBUG - 2011-09-30 12:48:48 --> Model Class Initialized
DEBUG - 2011-09-30 12:48:48 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-30 12:48:48 --> Database Driver Class Initialized
DEBUG - 2011-09-30 12:48:48 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-30 12:48:48 --> Helper loaded: url_helper
DEBUG - 2011-09-30 12:48:48 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-30 12:48:48 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-30 12:48:48 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-30 12:48:48 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-30 12:48:48 --> Final output sent to browser
DEBUG - 2011-09-30 12:48:48 --> Total execution time: 0.0490
DEBUG - 2011-09-30 14:07:07 --> Config Class Initialized
DEBUG - 2011-09-30 14:07:07 --> Hooks Class Initialized
DEBUG - 2011-09-30 14:07:07 --> Utf8 Class Initialized
DEBUG - 2011-09-30 14:07:07 --> UTF-8 Support Enabled
DEBUG - 2011-09-30 14:07:07 --> URI Class Initialized
DEBUG - 2011-09-30 14:07:07 --> Router Class Initialized
DEBUG - 2011-09-30 14:07:07 --> Output Class Initialized
DEBUG - 2011-09-30 14:07:07 --> Input Class Initialized
DEBUG - 2011-09-30 14:07:07 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-30 14:07:07 --> Language Class Initialized
DEBUG - 2011-09-30 14:07:07 --> Loader Class Initialized
DEBUG - 2011-09-30 14:07:07 --> Controller Class Initialized
DEBUG - 2011-09-30 14:07:07 --> Model Class Initialized
DEBUG - 2011-09-30 14:07:07 --> Model Class Initialized
DEBUG - 2011-09-30 14:07:07 --> Model Class Initialized
DEBUG - 2011-09-30 14:07:07 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-30 14:07:07 --> Database Driver Class Initialized
DEBUG - 2011-09-30 14:07:09 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-30 14:07:09 --> Helper loaded: url_helper
DEBUG - 2011-09-30 14:07:09 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-30 14:07:09 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-30 14:07:09 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-30 14:07:09 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-30 14:07:09 --> Final output sent to browser
DEBUG - 2011-09-30 14:07:09 --> Total execution time: 2.0619
DEBUG - 2011-09-30 14:07:11 --> Config Class Initialized
DEBUG - 2011-09-30 14:07:11 --> Hooks Class Initialized
DEBUG - 2011-09-30 14:07:11 --> Utf8 Class Initialized
DEBUG - 2011-09-30 14:07:11 --> UTF-8 Support Enabled
DEBUG - 2011-09-30 14:07:11 --> URI Class Initialized
DEBUG - 2011-09-30 14:07:11 --> Router Class Initialized
ERROR - 2011-09-30 14:07:11 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-30 14:18:23 --> Config Class Initialized
DEBUG - 2011-09-30 14:18:23 --> Hooks Class Initialized
DEBUG - 2011-09-30 14:18:23 --> Utf8 Class Initialized
DEBUG - 2011-09-30 14:18:23 --> UTF-8 Support Enabled
DEBUG - 2011-09-30 14:18:23 --> URI Class Initialized
DEBUG - 2011-09-30 14:18:23 --> Router Class Initialized
DEBUG - 2011-09-30 14:18:23 --> Output Class Initialized
DEBUG - 2011-09-30 14:18:23 --> Input Class Initialized
DEBUG - 2011-09-30 14:18:23 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-30 14:18:23 --> Language Class Initialized
DEBUG - 2011-09-30 14:18:23 --> Loader Class Initialized
DEBUG - 2011-09-30 14:18:23 --> Controller Class Initialized
DEBUG - 2011-09-30 14:18:23 --> Model Class Initialized
DEBUG - 2011-09-30 14:18:23 --> Model Class Initialized
DEBUG - 2011-09-30 14:18:23 --> Model Class Initialized
DEBUG - 2011-09-30 14:18:23 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-30 14:18:23 --> Database Driver Class Initialized
DEBUG - 2011-09-30 14:18:23 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-30 14:18:23 --> Helper loaded: url_helper
DEBUG - 2011-09-30 14:18:23 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-30 14:18:23 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-30 14:18:23 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-30 14:18:23 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-30 14:18:23 --> Final output sent to browser
DEBUG - 2011-09-30 14:18:23 --> Total execution time: 0.0592
DEBUG - 2011-09-30 14:44:30 --> Config Class Initialized
DEBUG - 2011-09-30 14:44:30 --> Hooks Class Initialized
DEBUG - 2011-09-30 14:44:30 --> Utf8 Class Initialized
DEBUG - 2011-09-30 14:44:30 --> UTF-8 Support Enabled
DEBUG - 2011-09-30 14:44:30 --> URI Class Initialized
DEBUG - 2011-09-30 14:44:30 --> Router Class Initialized
DEBUG - 2011-09-30 14:44:30 --> No URI present. Default controller set.
DEBUG - 2011-09-30 14:44:30 --> Output Class Initialized
DEBUG - 2011-09-30 14:44:30 --> Input Class Initialized
DEBUG - 2011-09-30 14:44:30 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-30 14:44:30 --> Language Class Initialized
DEBUG - 2011-09-30 14:44:30 --> Loader Class Initialized
DEBUG - 2011-09-30 14:44:30 --> Controller Class Initialized
DEBUG - 2011-09-30 14:44:30 --> File loaded: application/views/splash/main.php
DEBUG - 2011-09-30 14:44:30 --> Helper loaded: url_helper
DEBUG - 2011-09-30 14:44:30 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-30 14:44:30 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-30 14:44:30 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-30 14:44:30 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-30 14:44:30 --> Final output sent to browser
DEBUG - 2011-09-30 14:44:30 --> Total execution time: 0.0946
DEBUG - 2011-09-30 14:55:11 --> Config Class Initialized
DEBUG - 2011-09-30 14:55:11 --> Hooks Class Initialized
DEBUG - 2011-09-30 14:55:11 --> Utf8 Class Initialized
DEBUG - 2011-09-30 14:55:11 --> UTF-8 Support Enabled
DEBUG - 2011-09-30 14:55:11 --> URI Class Initialized
DEBUG - 2011-09-30 14:55:11 --> Router Class Initialized
DEBUG - 2011-09-30 14:55:11 --> Output Class Initialized
DEBUG - 2011-09-30 14:55:11 --> Input Class Initialized
DEBUG - 2011-09-30 14:55:11 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-30 14:55:11 --> Language Class Initialized
DEBUG - 2011-09-30 14:55:11 --> Loader Class Initialized
DEBUG - 2011-09-30 14:55:11 --> Controller Class Initialized
ERROR - 2011-09-30 14:55:11 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-30 14:55:11 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-30 14:55:11 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-30 14:55:11 --> Model Class Initialized
DEBUG - 2011-09-30 14:55:11 --> Model Class Initialized
DEBUG - 2011-09-30 14:55:11 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-30 14:55:11 --> Database Driver Class Initialized
DEBUG - 2011-09-30 14:55:11 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-30 14:55:11 --> Helper loaded: url_helper
DEBUG - 2011-09-30 14:55:11 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-30 14:55:11 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-30 14:55:11 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-30 14:55:11 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-30 14:55:11 --> Final output sent to browser
DEBUG - 2011-09-30 14:55:11 --> Total execution time: 0.2953
DEBUG - 2011-09-30 14:55:16 --> Config Class Initialized
DEBUG - 2011-09-30 14:55:16 --> Hooks Class Initialized
DEBUG - 2011-09-30 14:55:16 --> Utf8 Class Initialized
DEBUG - 2011-09-30 14:55:16 --> UTF-8 Support Enabled
DEBUG - 2011-09-30 14:55:16 --> URI Class Initialized
DEBUG - 2011-09-30 14:55:16 --> Router Class Initialized
DEBUG - 2011-09-30 14:55:16 --> Output Class Initialized
DEBUG - 2011-09-30 14:55:16 --> Input Class Initialized
DEBUG - 2011-09-30 14:55:16 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-30 14:55:16 --> Language Class Initialized
DEBUG - 2011-09-30 14:55:16 --> Loader Class Initialized
DEBUG - 2011-09-30 14:55:16 --> Controller Class Initialized
DEBUG - 2011-09-30 14:55:16 --> Model Class Initialized
DEBUG - 2011-09-30 14:55:16 --> Model Class Initialized
DEBUG - 2011-09-30 14:55:16 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-30 14:55:16 --> Database Driver Class Initialized
DEBUG - 2011-09-30 14:55:17 --> Final output sent to browser
DEBUG - 2011-09-30 14:55:17 --> Total execution time: 0.7735
DEBUG - 2011-09-30 15:13:50 --> Config Class Initialized
DEBUG - 2011-09-30 15:13:50 --> Hooks Class Initialized
DEBUG - 2011-09-30 15:13:50 --> Utf8 Class Initialized
DEBUG - 2011-09-30 15:13:50 --> UTF-8 Support Enabled
DEBUG - 2011-09-30 15:13:50 --> URI Class Initialized
DEBUG - 2011-09-30 15:13:50 --> Router Class Initialized
DEBUG - 2011-09-30 15:13:50 --> Output Class Initialized
DEBUG - 2011-09-30 15:13:50 --> Input Class Initialized
DEBUG - 2011-09-30 15:13:50 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-30 15:13:50 --> Language Class Initialized
DEBUG - 2011-09-30 15:13:50 --> Loader Class Initialized
DEBUG - 2011-09-30 15:13:50 --> Controller Class Initialized
ERROR - 2011-09-30 15:13:50 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-30 15:13:50 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-30 15:13:50 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-30 15:13:50 --> Model Class Initialized
DEBUG - 2011-09-30 15:13:50 --> Model Class Initialized
DEBUG - 2011-09-30 15:13:50 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-30 15:13:50 --> Database Driver Class Initialized
DEBUG - 2011-09-30 15:13:50 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-30 15:13:50 --> Helper loaded: url_helper
DEBUG - 2011-09-30 15:13:50 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-30 15:13:50 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-30 15:13:50 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-30 15:13:50 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-30 15:13:50 --> Final output sent to browser
DEBUG - 2011-09-30 15:13:50 --> Total execution time: 0.0545
DEBUG - 2011-09-30 15:13:52 --> Config Class Initialized
DEBUG - 2011-09-30 15:13:52 --> Hooks Class Initialized
DEBUG - 2011-09-30 15:13:52 --> Utf8 Class Initialized
DEBUG - 2011-09-30 15:13:52 --> UTF-8 Support Enabled
DEBUG - 2011-09-30 15:13:52 --> URI Class Initialized
DEBUG - 2011-09-30 15:13:52 --> Router Class Initialized
DEBUG - 2011-09-30 15:13:52 --> Output Class Initialized
DEBUG - 2011-09-30 15:13:52 --> Input Class Initialized
DEBUG - 2011-09-30 15:13:52 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-30 15:13:52 --> Language Class Initialized
DEBUG - 2011-09-30 15:13:53 --> Loader Class Initialized
DEBUG - 2011-09-30 15:13:53 --> Controller Class Initialized
DEBUG - 2011-09-30 15:13:53 --> Model Class Initialized
DEBUG - 2011-09-30 15:13:53 --> Model Class Initialized
DEBUG - 2011-09-30 15:13:53 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-30 15:13:53 --> Database Driver Class Initialized
DEBUG - 2011-09-30 15:13:53 --> Final output sent to browser
DEBUG - 2011-09-30 15:13:53 --> Total execution time: 0.8283
DEBUG - 2011-09-30 15:13:55 --> Config Class Initialized
DEBUG - 2011-09-30 15:13:55 --> Hooks Class Initialized
DEBUG - 2011-09-30 15:13:55 --> Utf8 Class Initialized
DEBUG - 2011-09-30 15:13:55 --> UTF-8 Support Enabled
DEBUG - 2011-09-30 15:13:55 --> URI Class Initialized
DEBUG - 2011-09-30 15:13:55 --> Router Class Initialized
ERROR - 2011-09-30 15:13:55 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-30 16:01:40 --> Config Class Initialized
DEBUG - 2011-09-30 16:01:40 --> Hooks Class Initialized
DEBUG - 2011-09-30 16:01:40 --> Utf8 Class Initialized
DEBUG - 2011-09-30 16:01:40 --> UTF-8 Support Enabled
DEBUG - 2011-09-30 16:01:40 --> URI Class Initialized
DEBUG - 2011-09-30 16:01:40 --> Router Class Initialized
DEBUG - 2011-09-30 16:01:40 --> Output Class Initialized
DEBUG - 2011-09-30 16:01:40 --> Input Class Initialized
DEBUG - 2011-09-30 16:01:40 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-30 16:01:40 --> Language Class Initialized
DEBUG - 2011-09-30 16:01:40 --> Loader Class Initialized
DEBUG - 2011-09-30 16:01:40 --> Controller Class Initialized
ERROR - 2011-09-30 16:01:40 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-30 16:01:40 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-30 16:01:40 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-30 16:01:40 --> Model Class Initialized
DEBUG - 2011-09-30 16:01:40 --> Model Class Initialized
DEBUG - 2011-09-30 16:01:40 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-30 16:01:41 --> Database Driver Class Initialized
DEBUG - 2011-09-30 16:01:41 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-30 16:01:41 --> Helper loaded: url_helper
DEBUG - 2011-09-30 16:01:41 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-30 16:01:41 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-30 16:01:41 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-30 16:01:41 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-30 16:01:41 --> Final output sent to browser
DEBUG - 2011-09-30 16:01:41 --> Total execution time: 0.7392
DEBUG - 2011-09-30 16:01:42 --> Config Class Initialized
DEBUG - 2011-09-30 16:01:42 --> Hooks Class Initialized
DEBUG - 2011-09-30 16:01:42 --> Utf8 Class Initialized
DEBUG - 2011-09-30 16:01:42 --> UTF-8 Support Enabled
DEBUG - 2011-09-30 16:01:42 --> URI Class Initialized
DEBUG - 2011-09-30 16:01:42 --> Router Class Initialized
DEBUG - 2011-09-30 16:01:42 --> Output Class Initialized
DEBUG - 2011-09-30 16:01:42 --> Input Class Initialized
DEBUG - 2011-09-30 16:01:42 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-30 16:01:42 --> Language Class Initialized
DEBUG - 2011-09-30 16:01:42 --> Loader Class Initialized
DEBUG - 2011-09-30 16:01:42 --> Controller Class Initialized
DEBUG - 2011-09-30 16:01:42 --> Model Class Initialized
DEBUG - 2011-09-30 16:01:42 --> Model Class Initialized
DEBUG - 2011-09-30 16:01:42 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-30 16:01:43 --> Database Driver Class Initialized
DEBUG - 2011-09-30 16:01:43 --> Final output sent to browser
DEBUG - 2011-09-30 16:01:43 --> Total execution time: 0.6286
DEBUG - 2011-09-30 16:01:46 --> Config Class Initialized
DEBUG - 2011-09-30 16:01:46 --> Hooks Class Initialized
DEBUG - 2011-09-30 16:01:46 --> Utf8 Class Initialized
DEBUG - 2011-09-30 16:01:46 --> UTF-8 Support Enabled
DEBUG - 2011-09-30 16:01:46 --> URI Class Initialized
DEBUG - 2011-09-30 16:01:46 --> Router Class Initialized
ERROR - 2011-09-30 16:01:46 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-30 16:02:08 --> Config Class Initialized
DEBUG - 2011-09-30 16:02:08 --> Hooks Class Initialized
DEBUG - 2011-09-30 16:02:08 --> Utf8 Class Initialized
DEBUG - 2011-09-30 16:02:08 --> UTF-8 Support Enabled
DEBUG - 2011-09-30 16:02:08 --> URI Class Initialized
DEBUG - 2011-09-30 16:02:08 --> Router Class Initialized
DEBUG - 2011-09-30 16:02:08 --> Output Class Initialized
DEBUG - 2011-09-30 16:02:08 --> Input Class Initialized
DEBUG - 2011-09-30 16:02:08 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-30 16:02:08 --> Language Class Initialized
DEBUG - 2011-09-30 16:02:08 --> Loader Class Initialized
DEBUG - 2011-09-30 16:02:08 --> Controller Class Initialized
ERROR - 2011-09-30 16:02:08 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-30 16:02:08 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-30 16:02:08 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-30 16:02:08 --> Model Class Initialized
DEBUG - 2011-09-30 16:02:08 --> Model Class Initialized
DEBUG - 2011-09-30 16:02:08 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-30 16:02:08 --> Database Driver Class Initialized
DEBUG - 2011-09-30 16:02:08 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-30 16:02:08 --> Helper loaded: url_helper
DEBUG - 2011-09-30 16:02:08 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-30 16:02:08 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-30 16:02:08 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-30 16:02:08 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-30 16:02:08 --> Final output sent to browser
DEBUG - 2011-09-30 16:02:08 --> Total execution time: 0.0373
DEBUG - 2011-09-30 16:02:09 --> Config Class Initialized
DEBUG - 2011-09-30 16:02:09 --> Hooks Class Initialized
DEBUG - 2011-09-30 16:02:09 --> Utf8 Class Initialized
DEBUG - 2011-09-30 16:02:09 --> UTF-8 Support Enabled
DEBUG - 2011-09-30 16:02:09 --> URI Class Initialized
DEBUG - 2011-09-30 16:02:09 --> Router Class Initialized
DEBUG - 2011-09-30 16:02:09 --> Output Class Initialized
DEBUG - 2011-09-30 16:02:09 --> Input Class Initialized
DEBUG - 2011-09-30 16:02:09 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-30 16:02:09 --> Language Class Initialized
DEBUG - 2011-09-30 16:02:09 --> Loader Class Initialized
DEBUG - 2011-09-30 16:02:09 --> Controller Class Initialized
DEBUG - 2011-09-30 16:02:09 --> Model Class Initialized
DEBUG - 2011-09-30 16:02:09 --> Model Class Initialized
DEBUG - 2011-09-30 16:02:09 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-30 16:02:09 --> Database Driver Class Initialized
DEBUG - 2011-09-30 16:02:09 --> Final output sent to browser
DEBUG - 2011-09-30 16:02:09 --> Total execution time: 0.6577
DEBUG - 2011-09-30 16:02:27 --> Config Class Initialized
DEBUG - 2011-09-30 16:02:27 --> Hooks Class Initialized
DEBUG - 2011-09-30 16:02:27 --> Utf8 Class Initialized
DEBUG - 2011-09-30 16:02:27 --> UTF-8 Support Enabled
DEBUG - 2011-09-30 16:02:27 --> URI Class Initialized
DEBUG - 2011-09-30 16:02:27 --> Router Class Initialized
DEBUG - 2011-09-30 16:02:27 --> Output Class Initialized
DEBUG - 2011-09-30 16:02:27 --> Input Class Initialized
DEBUG - 2011-09-30 16:02:27 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-30 16:02:27 --> Language Class Initialized
DEBUG - 2011-09-30 16:02:27 --> Loader Class Initialized
DEBUG - 2011-09-30 16:02:27 --> Controller Class Initialized
ERROR - 2011-09-30 16:02:27 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-30 16:02:27 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-30 16:02:27 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-30 16:02:27 --> Model Class Initialized
DEBUG - 2011-09-30 16:02:27 --> Model Class Initialized
DEBUG - 2011-09-30 16:02:27 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-30 16:02:27 --> Database Driver Class Initialized
DEBUG - 2011-09-30 16:02:27 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-30 16:02:27 --> Helper loaded: url_helper
DEBUG - 2011-09-30 16:02:27 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-30 16:02:27 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-30 16:02:27 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-30 16:02:27 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-30 16:02:27 --> Final output sent to browser
DEBUG - 2011-09-30 16:02:27 --> Total execution time: 0.1133
DEBUG - 2011-09-30 16:02:29 --> Config Class Initialized
DEBUG - 2011-09-30 16:02:29 --> Hooks Class Initialized
DEBUG - 2011-09-30 16:02:29 --> Utf8 Class Initialized
DEBUG - 2011-09-30 16:02:29 --> UTF-8 Support Enabled
DEBUG - 2011-09-30 16:02:29 --> URI Class Initialized
DEBUG - 2011-09-30 16:02:29 --> Router Class Initialized
DEBUG - 2011-09-30 16:02:29 --> Output Class Initialized
DEBUG - 2011-09-30 16:02:29 --> Input Class Initialized
DEBUG - 2011-09-30 16:02:29 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-30 16:02:29 --> Language Class Initialized
DEBUG - 2011-09-30 16:02:29 --> Loader Class Initialized
DEBUG - 2011-09-30 16:02:29 --> Controller Class Initialized
DEBUG - 2011-09-30 16:02:29 --> Model Class Initialized
DEBUG - 2011-09-30 16:02:29 --> Model Class Initialized
DEBUG - 2011-09-30 16:02:29 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-30 16:02:29 --> Database Driver Class Initialized
DEBUG - 2011-09-30 16:02:30 --> Final output sent to browser
DEBUG - 2011-09-30 16:02:30 --> Total execution time: 0.6687
DEBUG - 2011-09-30 16:02:37 --> Config Class Initialized
DEBUG - 2011-09-30 16:02:37 --> Hooks Class Initialized
DEBUG - 2011-09-30 16:02:37 --> Utf8 Class Initialized
DEBUG - 2011-09-30 16:02:37 --> UTF-8 Support Enabled
DEBUG - 2011-09-30 16:02:37 --> URI Class Initialized
DEBUG - 2011-09-30 16:02:37 --> Router Class Initialized
DEBUG - 2011-09-30 16:02:37 --> Output Class Initialized
DEBUG - 2011-09-30 16:02:37 --> Input Class Initialized
DEBUG - 2011-09-30 16:02:37 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-30 16:02:37 --> Language Class Initialized
DEBUG - 2011-09-30 16:02:37 --> Loader Class Initialized
DEBUG - 2011-09-30 16:02:37 --> Controller Class Initialized
ERROR - 2011-09-30 16:02:37 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-30 16:02:37 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-30 16:02:37 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-30 16:02:37 --> Model Class Initialized
DEBUG - 2011-09-30 16:02:37 --> Model Class Initialized
DEBUG - 2011-09-30 16:02:37 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-30 16:02:37 --> Database Driver Class Initialized
DEBUG - 2011-09-30 16:02:37 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-30 16:02:37 --> Helper loaded: url_helper
DEBUG - 2011-09-30 16:02:37 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-30 16:02:37 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-30 16:02:37 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-30 16:02:37 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-30 16:02:37 --> Final output sent to browser
DEBUG - 2011-09-30 16:02:37 --> Total execution time: 0.0301
DEBUG - 2011-09-30 16:02:38 --> Config Class Initialized
DEBUG - 2011-09-30 16:02:38 --> Hooks Class Initialized
DEBUG - 2011-09-30 16:02:38 --> Utf8 Class Initialized
DEBUG - 2011-09-30 16:02:38 --> UTF-8 Support Enabled
DEBUG - 2011-09-30 16:02:38 --> URI Class Initialized
DEBUG - 2011-09-30 16:02:38 --> Router Class Initialized
DEBUG - 2011-09-30 16:02:38 --> Output Class Initialized
DEBUG - 2011-09-30 16:02:38 --> Input Class Initialized
DEBUG - 2011-09-30 16:02:38 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-30 16:02:38 --> Language Class Initialized
DEBUG - 2011-09-30 16:02:38 --> Loader Class Initialized
DEBUG - 2011-09-30 16:02:38 --> Controller Class Initialized
DEBUG - 2011-09-30 16:02:38 --> Model Class Initialized
DEBUG - 2011-09-30 16:02:38 --> Model Class Initialized
DEBUG - 2011-09-30 16:02:38 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-30 16:02:38 --> Database Driver Class Initialized
DEBUG - 2011-09-30 16:02:39 --> Final output sent to browser
DEBUG - 2011-09-30 16:02:39 --> Total execution time: 0.5614
DEBUG - 2011-09-30 16:02:53 --> Config Class Initialized
DEBUG - 2011-09-30 16:02:53 --> Hooks Class Initialized
DEBUG - 2011-09-30 16:02:53 --> Utf8 Class Initialized
DEBUG - 2011-09-30 16:02:53 --> UTF-8 Support Enabled
DEBUG - 2011-09-30 16:02:53 --> URI Class Initialized
DEBUG - 2011-09-30 16:02:53 --> Router Class Initialized
DEBUG - 2011-09-30 16:02:53 --> Output Class Initialized
DEBUG - 2011-09-30 16:02:53 --> Input Class Initialized
DEBUG - 2011-09-30 16:02:53 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-30 16:02:53 --> Language Class Initialized
DEBUG - 2011-09-30 16:02:53 --> Loader Class Initialized
DEBUG - 2011-09-30 16:02:53 --> Controller Class Initialized
ERROR - 2011-09-30 16:02:53 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-30 16:02:53 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-30 16:02:53 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-30 16:02:53 --> Model Class Initialized
DEBUG - 2011-09-30 16:02:53 --> Model Class Initialized
DEBUG - 2011-09-30 16:02:53 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-30 16:02:53 --> Database Driver Class Initialized
DEBUG - 2011-09-30 16:02:53 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-30 16:02:53 --> Helper loaded: url_helper
DEBUG - 2011-09-30 16:02:53 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-30 16:02:53 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-30 16:02:53 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-30 16:02:53 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-30 16:02:53 --> Final output sent to browser
DEBUG - 2011-09-30 16:02:53 --> Total execution time: 0.0343
DEBUG - 2011-09-30 16:02:53 --> Config Class Initialized
DEBUG - 2011-09-30 16:02:53 --> Hooks Class Initialized
DEBUG - 2011-09-30 16:02:53 --> Utf8 Class Initialized
DEBUG - 2011-09-30 16:02:53 --> UTF-8 Support Enabled
DEBUG - 2011-09-30 16:02:53 --> URI Class Initialized
DEBUG - 2011-09-30 16:02:53 --> Router Class Initialized
DEBUG - 2011-09-30 16:02:53 --> Output Class Initialized
DEBUG - 2011-09-30 16:02:53 --> Input Class Initialized
DEBUG - 2011-09-30 16:02:53 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-30 16:02:53 --> Language Class Initialized
DEBUG - 2011-09-30 16:02:53 --> Loader Class Initialized
DEBUG - 2011-09-30 16:02:53 --> Controller Class Initialized
DEBUG - 2011-09-30 16:02:53 --> Model Class Initialized
DEBUG - 2011-09-30 16:02:53 --> Model Class Initialized
DEBUG - 2011-09-30 16:02:53 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-30 16:02:53 --> Database Driver Class Initialized
DEBUG - 2011-09-30 16:02:54 --> Final output sent to browser
DEBUG - 2011-09-30 16:02:54 --> Total execution time: 0.5550
DEBUG - 2011-09-30 16:03:00 --> Config Class Initialized
DEBUG - 2011-09-30 16:03:00 --> Hooks Class Initialized
DEBUG - 2011-09-30 16:03:00 --> Utf8 Class Initialized
DEBUG - 2011-09-30 16:03:00 --> UTF-8 Support Enabled
DEBUG - 2011-09-30 16:03:00 --> URI Class Initialized
DEBUG - 2011-09-30 16:03:00 --> Router Class Initialized
DEBUG - 2011-09-30 16:03:00 --> Output Class Initialized
DEBUG - 2011-09-30 16:03:00 --> Input Class Initialized
DEBUG - 2011-09-30 16:03:00 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-30 16:03:00 --> Language Class Initialized
DEBUG - 2011-09-30 16:03:00 --> Loader Class Initialized
DEBUG - 2011-09-30 16:03:00 --> Controller Class Initialized
ERROR - 2011-09-30 16:03:00 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-30 16:03:00 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-30 16:03:00 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-30 16:03:00 --> Model Class Initialized
DEBUG - 2011-09-30 16:03:00 --> Model Class Initialized
DEBUG - 2011-09-30 16:03:00 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-30 16:03:00 --> Database Driver Class Initialized
DEBUG - 2011-09-30 16:03:00 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-30 16:03:00 --> Helper loaded: url_helper
DEBUG - 2011-09-30 16:03:00 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-30 16:03:00 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-30 16:03:00 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-30 16:03:00 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-30 16:03:00 --> Final output sent to browser
DEBUG - 2011-09-30 16:03:00 --> Total execution time: 0.0310
DEBUG - 2011-09-30 16:03:01 --> Config Class Initialized
DEBUG - 2011-09-30 16:03:01 --> Hooks Class Initialized
DEBUG - 2011-09-30 16:03:01 --> Utf8 Class Initialized
DEBUG - 2011-09-30 16:03:01 --> UTF-8 Support Enabled
DEBUG - 2011-09-30 16:03:01 --> URI Class Initialized
DEBUG - 2011-09-30 16:03:01 --> Router Class Initialized
DEBUG - 2011-09-30 16:03:01 --> Output Class Initialized
DEBUG - 2011-09-30 16:03:01 --> Input Class Initialized
DEBUG - 2011-09-30 16:03:01 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-30 16:03:01 --> Language Class Initialized
DEBUG - 2011-09-30 16:03:01 --> Loader Class Initialized
DEBUG - 2011-09-30 16:03:01 --> Controller Class Initialized
DEBUG - 2011-09-30 16:03:01 --> Model Class Initialized
DEBUG - 2011-09-30 16:03:01 --> Model Class Initialized
DEBUG - 2011-09-30 16:03:01 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-30 16:03:01 --> Database Driver Class Initialized
DEBUG - 2011-09-30 16:03:01 --> Final output sent to browser
DEBUG - 2011-09-30 16:03:01 --> Total execution time: 0.6265
DEBUG - 2011-09-30 16:03:19 --> Config Class Initialized
DEBUG - 2011-09-30 16:03:19 --> Hooks Class Initialized
DEBUG - 2011-09-30 16:03:19 --> Utf8 Class Initialized
DEBUG - 2011-09-30 16:03:19 --> UTF-8 Support Enabled
DEBUG - 2011-09-30 16:03:19 --> URI Class Initialized
DEBUG - 2011-09-30 16:03:19 --> Router Class Initialized
DEBUG - 2011-09-30 16:03:19 --> Output Class Initialized
DEBUG - 2011-09-30 16:03:19 --> Input Class Initialized
DEBUG - 2011-09-30 16:03:19 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-30 16:03:19 --> Language Class Initialized
DEBUG - 2011-09-30 16:03:19 --> Loader Class Initialized
DEBUG - 2011-09-30 16:03:19 --> Controller Class Initialized
ERROR - 2011-09-30 16:03:19 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-30 16:03:19 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-30 16:03:19 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-30 16:03:19 --> Model Class Initialized
DEBUG - 2011-09-30 16:03:19 --> Model Class Initialized
DEBUG - 2011-09-30 16:03:19 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-30 16:03:19 --> Database Driver Class Initialized
DEBUG - 2011-09-30 16:03:19 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-30 16:03:19 --> Helper loaded: url_helper
DEBUG - 2011-09-30 16:03:19 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-30 16:03:19 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-30 16:03:19 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-30 16:03:19 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-30 16:03:19 --> Final output sent to browser
DEBUG - 2011-09-30 16:03:19 --> Total execution time: 0.0424
DEBUG - 2011-09-30 16:03:20 --> Config Class Initialized
DEBUG - 2011-09-30 16:03:20 --> Hooks Class Initialized
DEBUG - 2011-09-30 16:03:20 --> Utf8 Class Initialized
DEBUG - 2011-09-30 16:03:20 --> UTF-8 Support Enabled
DEBUG - 2011-09-30 16:03:20 --> URI Class Initialized
DEBUG - 2011-09-30 16:03:20 --> Router Class Initialized
DEBUG - 2011-09-30 16:03:20 --> Output Class Initialized
DEBUG - 2011-09-30 16:03:20 --> Input Class Initialized
DEBUG - 2011-09-30 16:03:20 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-30 16:03:20 --> Language Class Initialized
DEBUG - 2011-09-30 16:03:20 --> Loader Class Initialized
DEBUG - 2011-09-30 16:03:20 --> Controller Class Initialized
DEBUG - 2011-09-30 16:03:20 --> Model Class Initialized
DEBUG - 2011-09-30 16:03:20 --> Model Class Initialized
DEBUG - 2011-09-30 16:03:20 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-30 16:03:20 --> Database Driver Class Initialized
DEBUG - 2011-09-30 16:03:21 --> Final output sent to browser
DEBUG - 2011-09-30 16:03:21 --> Total execution time: 0.5490
DEBUG - 2011-09-30 16:03:29 --> Config Class Initialized
DEBUG - 2011-09-30 16:03:29 --> Hooks Class Initialized
DEBUG - 2011-09-30 16:03:29 --> Utf8 Class Initialized
DEBUG - 2011-09-30 16:03:29 --> UTF-8 Support Enabled
DEBUG - 2011-09-30 16:03:29 --> URI Class Initialized
DEBUG - 2011-09-30 16:03:29 --> Router Class Initialized
DEBUG - 2011-09-30 16:03:29 --> Output Class Initialized
DEBUG - 2011-09-30 16:03:29 --> Input Class Initialized
DEBUG - 2011-09-30 16:03:29 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-30 16:03:29 --> Language Class Initialized
DEBUG - 2011-09-30 16:03:29 --> Loader Class Initialized
DEBUG - 2011-09-30 16:03:29 --> Controller Class Initialized
ERROR - 2011-09-30 16:03:29 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-30 16:03:29 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-30 16:03:29 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-30 16:03:29 --> Model Class Initialized
DEBUG - 2011-09-30 16:03:29 --> Model Class Initialized
DEBUG - 2011-09-30 16:03:29 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-30 16:03:29 --> Database Driver Class Initialized
DEBUG - 2011-09-30 16:03:29 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-30 16:03:29 --> Helper loaded: url_helper
DEBUG - 2011-09-30 16:03:29 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-30 16:03:29 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-30 16:03:29 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-30 16:03:29 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-30 16:03:29 --> Final output sent to browser
DEBUG - 2011-09-30 16:03:29 --> Total execution time: 0.0310
DEBUG - 2011-09-30 16:03:30 --> Config Class Initialized
DEBUG - 2011-09-30 16:03:30 --> Hooks Class Initialized
DEBUG - 2011-09-30 16:03:30 --> Utf8 Class Initialized
DEBUG - 2011-09-30 16:03:30 --> UTF-8 Support Enabled
DEBUG - 2011-09-30 16:03:30 --> URI Class Initialized
DEBUG - 2011-09-30 16:03:30 --> Router Class Initialized
DEBUG - 2011-09-30 16:03:30 --> Output Class Initialized
DEBUG - 2011-09-30 16:03:30 --> Input Class Initialized
DEBUG - 2011-09-30 16:03:30 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-30 16:03:30 --> Language Class Initialized
DEBUG - 2011-09-30 16:03:30 --> Loader Class Initialized
DEBUG - 2011-09-30 16:03:30 --> Controller Class Initialized
DEBUG - 2011-09-30 16:03:30 --> Model Class Initialized
DEBUG - 2011-09-30 16:03:30 --> Model Class Initialized
DEBUG - 2011-09-30 16:03:30 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-30 16:03:30 --> Database Driver Class Initialized
DEBUG - 2011-09-30 16:03:30 --> Final output sent to browser
DEBUG - 2011-09-30 16:03:30 --> Total execution time: 0.5623
DEBUG - 2011-09-30 16:03:35 --> Config Class Initialized
DEBUG - 2011-09-30 16:03:35 --> Hooks Class Initialized
DEBUG - 2011-09-30 16:03:35 --> Utf8 Class Initialized
DEBUG - 2011-09-30 16:03:35 --> UTF-8 Support Enabled
DEBUG - 2011-09-30 16:03:35 --> URI Class Initialized
DEBUG - 2011-09-30 16:03:35 --> Router Class Initialized
DEBUG - 2011-09-30 16:03:35 --> Output Class Initialized
DEBUG - 2011-09-30 16:03:35 --> Input Class Initialized
DEBUG - 2011-09-30 16:03:35 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-30 16:03:35 --> Language Class Initialized
DEBUG - 2011-09-30 16:03:35 --> Loader Class Initialized
DEBUG - 2011-09-30 16:03:35 --> Controller Class Initialized
ERROR - 2011-09-30 16:03:35 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-30 16:03:35 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-30 16:03:35 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-30 16:03:35 --> Model Class Initialized
DEBUG - 2011-09-30 16:03:35 --> Model Class Initialized
DEBUG - 2011-09-30 16:03:35 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-30 16:03:35 --> Database Driver Class Initialized
DEBUG - 2011-09-30 16:03:35 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-30 16:03:35 --> Helper loaded: url_helper
DEBUG - 2011-09-30 16:03:35 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-30 16:03:35 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-30 16:03:35 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-30 16:03:35 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-30 16:03:35 --> Final output sent to browser
DEBUG - 2011-09-30 16:03:35 --> Total execution time: 0.0343
DEBUG - 2011-09-30 16:03:36 --> Config Class Initialized
DEBUG - 2011-09-30 16:03:36 --> Hooks Class Initialized
DEBUG - 2011-09-30 16:03:36 --> Utf8 Class Initialized
DEBUG - 2011-09-30 16:03:36 --> UTF-8 Support Enabled
DEBUG - 2011-09-30 16:03:36 --> URI Class Initialized
DEBUG - 2011-09-30 16:03:36 --> Router Class Initialized
DEBUG - 2011-09-30 16:03:36 --> Output Class Initialized
DEBUG - 2011-09-30 16:03:36 --> Input Class Initialized
DEBUG - 2011-09-30 16:03:36 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-30 16:03:36 --> Language Class Initialized
DEBUG - 2011-09-30 16:03:36 --> Loader Class Initialized
DEBUG - 2011-09-30 16:03:36 --> Controller Class Initialized
DEBUG - 2011-09-30 16:03:36 --> Model Class Initialized
DEBUG - 2011-09-30 16:03:36 --> Model Class Initialized
DEBUG - 2011-09-30 16:03:36 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-30 16:03:36 --> Database Driver Class Initialized
DEBUG - 2011-09-30 16:03:36 --> Final output sent to browser
DEBUG - 2011-09-30 16:03:36 --> Total execution time: 0.5500
DEBUG - 2011-09-30 16:03:41 --> Config Class Initialized
DEBUG - 2011-09-30 16:03:41 --> Hooks Class Initialized
DEBUG - 2011-09-30 16:03:41 --> Utf8 Class Initialized
DEBUG - 2011-09-30 16:03:41 --> UTF-8 Support Enabled
DEBUG - 2011-09-30 16:03:41 --> URI Class Initialized
DEBUG - 2011-09-30 16:03:41 --> Router Class Initialized
DEBUG - 2011-09-30 16:03:41 --> Output Class Initialized
DEBUG - 2011-09-30 16:03:41 --> Input Class Initialized
DEBUG - 2011-09-30 16:03:41 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-30 16:03:41 --> Language Class Initialized
DEBUG - 2011-09-30 16:03:41 --> Loader Class Initialized
DEBUG - 2011-09-30 16:03:41 --> Controller Class Initialized
ERROR - 2011-09-30 16:03:41 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-30 16:03:41 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-30 16:03:41 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-30 16:03:41 --> Model Class Initialized
DEBUG - 2011-09-30 16:03:41 --> Model Class Initialized
DEBUG - 2011-09-30 16:03:41 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-30 16:03:41 --> Database Driver Class Initialized
DEBUG - 2011-09-30 16:03:41 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-30 16:03:41 --> Helper loaded: url_helper
DEBUG - 2011-09-30 16:03:41 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-30 16:03:41 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-30 16:03:41 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-30 16:03:41 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-30 16:03:41 --> Final output sent to browser
DEBUG - 2011-09-30 16:03:41 --> Total execution time: 0.0343
DEBUG - 2011-09-30 16:03:42 --> Config Class Initialized
DEBUG - 2011-09-30 16:03:42 --> Hooks Class Initialized
DEBUG - 2011-09-30 16:03:42 --> Utf8 Class Initialized
DEBUG - 2011-09-30 16:03:42 --> UTF-8 Support Enabled
DEBUG - 2011-09-30 16:03:42 --> URI Class Initialized
DEBUG - 2011-09-30 16:03:42 --> Router Class Initialized
DEBUG - 2011-09-30 16:03:42 --> Output Class Initialized
DEBUG - 2011-09-30 16:03:42 --> Input Class Initialized
DEBUG - 2011-09-30 16:03:42 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-30 16:03:42 --> Language Class Initialized
DEBUG - 2011-09-30 16:03:42 --> Loader Class Initialized
DEBUG - 2011-09-30 16:03:42 --> Controller Class Initialized
DEBUG - 2011-09-30 16:03:42 --> Model Class Initialized
DEBUG - 2011-09-30 16:03:42 --> Model Class Initialized
DEBUG - 2011-09-30 16:03:42 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-30 16:03:42 --> Database Driver Class Initialized
DEBUG - 2011-09-30 16:03:43 --> Final output sent to browser
DEBUG - 2011-09-30 16:03:43 --> Total execution time: 0.5146
DEBUG - 2011-09-30 16:03:49 --> Config Class Initialized
DEBUG - 2011-09-30 16:03:49 --> Hooks Class Initialized
DEBUG - 2011-09-30 16:03:49 --> Utf8 Class Initialized
DEBUG - 2011-09-30 16:03:49 --> UTF-8 Support Enabled
DEBUG - 2011-09-30 16:03:49 --> URI Class Initialized
DEBUG - 2011-09-30 16:03:49 --> Router Class Initialized
DEBUG - 2011-09-30 16:03:49 --> Output Class Initialized
DEBUG - 2011-09-30 16:03:49 --> Input Class Initialized
DEBUG - 2011-09-30 16:03:49 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-30 16:03:49 --> Language Class Initialized
DEBUG - 2011-09-30 16:03:49 --> Loader Class Initialized
DEBUG - 2011-09-30 16:03:49 --> Controller Class Initialized
ERROR - 2011-09-30 16:03:49 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-30 16:03:49 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-30 16:03:49 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-30 16:03:49 --> Model Class Initialized
DEBUG - 2011-09-30 16:03:49 --> Model Class Initialized
DEBUG - 2011-09-30 16:03:49 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-30 16:03:49 --> Database Driver Class Initialized
DEBUG - 2011-09-30 16:03:49 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-30 16:03:49 --> Helper loaded: url_helper
DEBUG - 2011-09-30 16:03:49 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-30 16:03:49 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-30 16:03:49 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-30 16:03:49 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-30 16:03:49 --> Final output sent to browser
DEBUG - 2011-09-30 16:03:49 --> Total execution time: 0.0312
DEBUG - 2011-09-30 16:03:49 --> Config Class Initialized
DEBUG - 2011-09-30 16:03:49 --> Hooks Class Initialized
DEBUG - 2011-09-30 16:03:49 --> Utf8 Class Initialized
DEBUG - 2011-09-30 16:03:49 --> UTF-8 Support Enabled
DEBUG - 2011-09-30 16:03:49 --> URI Class Initialized
DEBUG - 2011-09-30 16:03:49 --> Router Class Initialized
DEBUG - 2011-09-30 16:03:49 --> Output Class Initialized
DEBUG - 2011-09-30 16:03:49 --> Input Class Initialized
DEBUG - 2011-09-30 16:03:49 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-30 16:03:49 --> Language Class Initialized
DEBUG - 2011-09-30 16:03:49 --> Loader Class Initialized
DEBUG - 2011-09-30 16:03:49 --> Controller Class Initialized
DEBUG - 2011-09-30 16:03:49 --> Model Class Initialized
DEBUG - 2011-09-30 16:03:49 --> Model Class Initialized
DEBUG - 2011-09-30 16:03:49 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-30 16:03:49 --> Database Driver Class Initialized
DEBUG - 2011-09-30 16:03:50 --> Final output sent to browser
DEBUG - 2011-09-30 16:03:50 --> Total execution time: 0.6160
DEBUG - 2011-09-30 16:04:26 --> Config Class Initialized
DEBUG - 2011-09-30 16:04:26 --> Hooks Class Initialized
DEBUG - 2011-09-30 16:04:26 --> Utf8 Class Initialized
DEBUG - 2011-09-30 16:04:26 --> UTF-8 Support Enabled
DEBUG - 2011-09-30 16:04:26 --> URI Class Initialized
DEBUG - 2011-09-30 16:04:26 --> Router Class Initialized
DEBUG - 2011-09-30 16:04:26 --> Output Class Initialized
DEBUG - 2011-09-30 16:04:26 --> Input Class Initialized
DEBUG - 2011-09-30 16:04:26 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-30 16:04:26 --> Language Class Initialized
DEBUG - 2011-09-30 16:04:26 --> Loader Class Initialized
DEBUG - 2011-09-30 16:04:26 --> Controller Class Initialized
DEBUG - 2011-09-30 16:04:26 --> Model Class Initialized
DEBUG - 2011-09-30 16:04:26 --> Model Class Initialized
DEBUG - 2011-09-30 16:04:26 --> Model Class Initialized
DEBUG - 2011-09-30 16:04:26 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-30 16:04:26 --> Database Driver Class Initialized
DEBUG - 2011-09-30 16:04:26 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-30 16:04:26 --> Helper loaded: url_helper
DEBUG - 2011-09-30 16:04:26 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-30 16:04:26 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-30 16:04:26 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-30 16:04:26 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-30 16:04:26 --> Final output sent to browser
DEBUG - 2011-09-30 16:04:26 --> Total execution time: 0.3756
DEBUG - 2011-09-30 17:00:57 --> Config Class Initialized
DEBUG - 2011-09-30 17:00:57 --> Hooks Class Initialized
DEBUG - 2011-09-30 17:00:57 --> Utf8 Class Initialized
DEBUG - 2011-09-30 17:00:57 --> UTF-8 Support Enabled
DEBUG - 2011-09-30 17:00:57 --> URI Class Initialized
DEBUG - 2011-09-30 17:00:57 --> Router Class Initialized
DEBUG - 2011-09-30 17:00:57 --> No URI present. Default controller set.
DEBUG - 2011-09-30 17:00:57 --> Output Class Initialized
DEBUG - 2011-09-30 17:00:57 --> Input Class Initialized
DEBUG - 2011-09-30 17:00:57 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-30 17:00:57 --> Language Class Initialized
DEBUG - 2011-09-30 17:00:57 --> Loader Class Initialized
DEBUG - 2011-09-30 17:00:57 --> Controller Class Initialized
DEBUG - 2011-09-30 17:00:57 --> File loaded: application/views/splash/main.php
DEBUG - 2011-09-30 17:00:57 --> Helper loaded: url_helper
DEBUG - 2011-09-30 17:00:57 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-30 17:00:57 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-30 17:00:57 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-30 17:00:57 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-30 17:00:57 --> Final output sent to browser
DEBUG - 2011-09-30 17:00:57 --> Total execution time: 0.0181
DEBUG - 2011-09-30 17:04:39 --> Config Class Initialized
DEBUG - 2011-09-30 17:04:39 --> Hooks Class Initialized
DEBUG - 2011-09-30 17:04:39 --> Utf8 Class Initialized
DEBUG - 2011-09-30 17:04:39 --> UTF-8 Support Enabled
DEBUG - 2011-09-30 17:04:39 --> URI Class Initialized
DEBUG - 2011-09-30 17:04:39 --> Router Class Initialized
ERROR - 2011-09-30 17:04:39 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-09-30 17:04:41 --> Config Class Initialized
DEBUG - 2011-09-30 17:04:41 --> Hooks Class Initialized
DEBUG - 2011-09-30 17:04:41 --> Utf8 Class Initialized
DEBUG - 2011-09-30 17:04:41 --> UTF-8 Support Enabled
DEBUG - 2011-09-30 17:04:41 --> URI Class Initialized
DEBUG - 2011-09-30 17:04:41 --> Router Class Initialized
DEBUG - 2011-09-30 17:04:41 --> Output Class Initialized
DEBUG - 2011-09-30 17:04:41 --> Input Class Initialized
DEBUG - 2011-09-30 17:04:41 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-30 17:04:41 --> Language Class Initialized
DEBUG - 2011-09-30 17:04:41 --> Loader Class Initialized
DEBUG - 2011-09-30 17:04:41 --> Controller Class Initialized
DEBUG - 2011-09-30 17:04:41 --> Model Class Initialized
DEBUG - 2011-09-30 17:04:41 --> Model Class Initialized
DEBUG - 2011-09-30 17:04:41 --> Model Class Initialized
DEBUG - 2011-09-30 17:04:41 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-30 17:04:41 --> Database Driver Class Initialized
DEBUG - 2011-09-30 17:04:42 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-30 17:04:42 --> Helper loaded: url_helper
DEBUG - 2011-09-30 17:04:42 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-30 17:04:42 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-30 17:04:42 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-30 17:04:42 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-30 17:04:42 --> Config Class Initialized
DEBUG - 2011-09-30 17:04:42 --> Hooks Class Initialized
DEBUG - 2011-09-30 17:04:42 --> Utf8 Class Initialized
DEBUG - 2011-09-30 17:04:42 --> UTF-8 Support Enabled
DEBUG - 2011-09-30 17:04:42 --> URI Class Initialized
DEBUG - 2011-09-30 17:04:42 --> Router Class Initialized
DEBUG - 2011-09-30 17:04:42 --> Output Class Initialized
DEBUG - 2011-09-30 17:04:42 --> Input Class Initialized
DEBUG - 2011-09-30 17:04:42 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-30 17:04:42 --> Language Class Initialized
DEBUG - 2011-09-30 17:04:42 --> Loader Class Initialized
DEBUG - 2011-09-30 17:04:42 --> Controller Class Initialized
DEBUG - 2011-09-30 17:04:42 --> Model Class Initialized
DEBUG - 2011-09-30 17:04:42 --> Model Class Initialized
DEBUG - 2011-09-30 17:04:42 --> Model Class Initialized
DEBUG - 2011-09-30 17:04:42 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-30 17:04:42 --> Database Driver Class Initialized
DEBUG - 2011-09-30 17:04:42 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-30 17:04:42 --> Helper loaded: url_helper
DEBUG - 2011-09-30 17:04:42 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-30 17:04:42 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-30 17:04:42 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-30 17:04:42 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-30 17:04:42 --> Final output sent to browser
DEBUG - 2011-09-30 17:04:42 --> Total execution time: 0.0473
DEBUG - 2011-09-30 17:44:18 --> Config Class Initialized
DEBUG - 2011-09-30 17:44:18 --> Hooks Class Initialized
DEBUG - 2011-09-30 17:44:18 --> Utf8 Class Initialized
DEBUG - 2011-09-30 17:44:18 --> UTF-8 Support Enabled
DEBUG - 2011-09-30 17:44:18 --> URI Class Initialized
DEBUG - 2011-09-30 17:44:18 --> Router Class Initialized
DEBUG - 2011-09-30 17:44:18 --> Output Class Initialized
DEBUG - 2011-09-30 17:44:18 --> Input Class Initialized
DEBUG - 2011-09-30 17:44:18 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-30 17:44:18 --> Language Class Initialized
DEBUG - 2011-09-30 17:44:18 --> Loader Class Initialized
DEBUG - 2011-09-30 17:44:18 --> Controller Class Initialized
ERROR - 2011-09-30 17:44:18 --> 404 Page Not Found --> snakes/image%3Fcode%3Deng12010
DEBUG - 2011-09-30 17:56:12 --> Config Class Initialized
DEBUG - 2011-09-30 17:56:12 --> Hooks Class Initialized
DEBUG - 2011-09-30 17:56:12 --> Utf8 Class Initialized
DEBUG - 2011-09-30 17:56:12 --> UTF-8 Support Enabled
DEBUG - 2011-09-30 17:56:12 --> URI Class Initialized
DEBUG - 2011-09-30 17:56:12 --> Router Class Initialized
DEBUG - 2011-09-30 17:56:12 --> Output Class Initialized
DEBUG - 2011-09-30 17:56:12 --> Input Class Initialized
DEBUG - 2011-09-30 17:56:12 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-30 17:56:12 --> Language Class Initialized
DEBUG - 2011-09-30 17:56:12 --> Loader Class Initialized
DEBUG - 2011-09-30 17:56:12 --> Controller Class Initialized
DEBUG - 2011-09-30 17:56:12 --> Model Class Initialized
DEBUG - 2011-09-30 17:56:12 --> Model Class Initialized
DEBUG - 2011-09-30 17:56:12 --> Model Class Initialized
DEBUG - 2011-09-30 17:56:12 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-30 17:56:12 --> Database Driver Class Initialized
DEBUG - 2011-09-30 17:56:12 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-30 17:56:12 --> Helper loaded: url_helper
DEBUG - 2011-09-30 17:56:12 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-30 17:56:12 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-30 17:56:12 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-30 17:56:12 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-30 17:56:12 --> Final output sent to browser
DEBUG - 2011-09-30 17:56:12 --> Total execution time: 0.2252
DEBUG - 2011-09-30 17:57:18 --> Config Class Initialized
DEBUG - 2011-09-30 17:57:18 --> Hooks Class Initialized
DEBUG - 2011-09-30 17:57:18 --> Utf8 Class Initialized
DEBUG - 2011-09-30 17:57:18 --> UTF-8 Support Enabled
DEBUG - 2011-09-30 17:57:18 --> URI Class Initialized
DEBUG - 2011-09-30 17:57:18 --> Router Class Initialized
DEBUG - 2011-09-30 17:57:18 --> Output Class Initialized
DEBUG - 2011-09-30 17:57:18 --> Input Class Initialized
DEBUG - 2011-09-30 17:57:18 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-30 17:57:18 --> Language Class Initialized
DEBUG - 2011-09-30 17:57:18 --> Loader Class Initialized
DEBUG - 2011-09-30 17:57:18 --> Controller Class Initialized
ERROR - 2011-09-30 17:57:18 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-30 17:57:18 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-30 17:57:18 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-30 17:57:18 --> Model Class Initialized
DEBUG - 2011-09-30 17:57:18 --> Model Class Initialized
DEBUG - 2011-09-30 17:57:18 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-30 17:57:18 --> Database Driver Class Initialized
DEBUG - 2011-09-30 17:57:18 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-30 17:57:18 --> Helper loaded: url_helper
DEBUG - 2011-09-30 17:57:18 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-30 17:57:18 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-30 17:57:18 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-30 17:57:18 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-30 17:57:18 --> Final output sent to browser
DEBUG - 2011-09-30 17:57:18 --> Total execution time: 0.0307
DEBUG - 2011-09-30 17:57:45 --> Config Class Initialized
DEBUG - 2011-09-30 17:57:45 --> Hooks Class Initialized
DEBUG - 2011-09-30 17:57:45 --> Utf8 Class Initialized
DEBUG - 2011-09-30 17:57:45 --> UTF-8 Support Enabled
DEBUG - 2011-09-30 17:57:45 --> URI Class Initialized
DEBUG - 2011-09-30 17:57:45 --> Router Class Initialized
DEBUG - 2011-09-30 17:57:45 --> Output Class Initialized
DEBUG - 2011-09-30 17:57:45 --> Input Class Initialized
DEBUG - 2011-09-30 17:57:45 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-30 17:57:45 --> Language Class Initialized
DEBUG - 2011-09-30 17:57:45 --> Loader Class Initialized
DEBUG - 2011-09-30 17:57:45 --> Controller Class Initialized
DEBUG - 2011-09-30 17:57:45 --> Model Class Initialized
DEBUG - 2011-09-30 17:57:45 --> Model Class Initialized
DEBUG - 2011-09-30 17:57:45 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-30 17:57:45 --> Database Driver Class Initialized
DEBUG - 2011-09-30 17:57:47 --> Final output sent to browser
DEBUG - 2011-09-30 17:57:47 --> Total execution time: 2.0876
DEBUG - 2011-09-30 17:58:08 --> Config Class Initialized
DEBUG - 2011-09-30 17:58:08 --> Hooks Class Initialized
DEBUG - 2011-09-30 17:58:08 --> Utf8 Class Initialized
DEBUG - 2011-09-30 17:58:08 --> UTF-8 Support Enabled
DEBUG - 2011-09-30 17:58:08 --> URI Class Initialized
DEBUG - 2011-09-30 17:58:08 --> Router Class Initialized
ERROR - 2011-09-30 17:58:08 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-30 17:58:17 --> Config Class Initialized
DEBUG - 2011-09-30 17:58:17 --> Hooks Class Initialized
DEBUG - 2011-09-30 17:58:17 --> Utf8 Class Initialized
DEBUG - 2011-09-30 17:58:17 --> UTF-8 Support Enabled
DEBUG - 2011-09-30 17:58:17 --> URI Class Initialized
DEBUG - 2011-09-30 17:58:17 --> Router Class Initialized
DEBUG - 2011-09-30 17:58:17 --> Output Class Initialized
DEBUG - 2011-09-30 17:58:17 --> Input Class Initialized
DEBUG - 2011-09-30 17:58:17 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-30 17:58:17 --> Language Class Initialized
DEBUG - 2011-09-30 17:58:17 --> Loader Class Initialized
DEBUG - 2011-09-30 17:58:17 --> Controller Class Initialized
DEBUG - 2011-09-30 17:58:17 --> Model Class Initialized
DEBUG - 2011-09-30 17:58:17 --> Model Class Initialized
DEBUG - 2011-09-30 17:58:17 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-30 17:58:17 --> Database Driver Class Initialized
DEBUG - 2011-09-30 17:58:18 --> Final output sent to browser
DEBUG - 2011-09-30 17:58:18 --> Total execution time: 0.6071
DEBUG - 2011-09-30 17:58:18 --> Config Class Initialized
DEBUG - 2011-09-30 17:58:18 --> Hooks Class Initialized
DEBUG - 2011-09-30 17:58:18 --> Utf8 Class Initialized
DEBUG - 2011-09-30 17:58:18 --> UTF-8 Support Enabled
DEBUG - 2011-09-30 17:58:18 --> URI Class Initialized
DEBUG - 2011-09-30 17:58:18 --> Router Class Initialized
ERROR - 2011-09-30 17:58:18 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-30 18:03:02 --> Config Class Initialized
DEBUG - 2011-09-30 18:03:02 --> Hooks Class Initialized
DEBUG - 2011-09-30 18:03:02 --> Utf8 Class Initialized
DEBUG - 2011-09-30 18:03:02 --> UTF-8 Support Enabled
DEBUG - 2011-09-30 18:03:02 --> URI Class Initialized
DEBUG - 2011-09-30 18:03:02 --> Router Class Initialized
DEBUG - 2011-09-30 18:03:02 --> Output Class Initialized
DEBUG - 2011-09-30 18:03:02 --> Input Class Initialized
DEBUG - 2011-09-30 18:03:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-30 18:03:02 --> Language Class Initialized
DEBUG - 2011-09-30 18:03:02 --> Loader Class Initialized
DEBUG - 2011-09-30 18:03:02 --> Controller Class Initialized
DEBUG - 2011-09-30 18:03:02 --> Model Class Initialized
DEBUG - 2011-09-30 18:03:02 --> Model Class Initialized
DEBUG - 2011-09-30 18:03:02 --> Model Class Initialized
DEBUG - 2011-09-30 18:03:02 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-30 18:03:02 --> Database Driver Class Initialized
DEBUG - 2011-09-30 18:03:03 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-30 18:03:03 --> Helper loaded: url_helper
DEBUG - 2011-09-30 18:03:03 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-30 18:03:03 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-30 18:03:03 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-30 18:03:03 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-30 18:03:03 --> Final output sent to browser
DEBUG - 2011-09-30 18:03:03 --> Total execution time: 0.7038
DEBUG - 2011-09-30 18:03:04 --> Config Class Initialized
DEBUG - 2011-09-30 18:03:04 --> Hooks Class Initialized
DEBUG - 2011-09-30 18:03:04 --> Utf8 Class Initialized
DEBUG - 2011-09-30 18:03:04 --> UTF-8 Support Enabled
DEBUG - 2011-09-30 18:03:04 --> URI Class Initialized
DEBUG - 2011-09-30 18:03:04 --> Router Class Initialized
DEBUG - 2011-09-30 18:03:04 --> Output Class Initialized
DEBUG - 2011-09-30 18:03:04 --> Input Class Initialized
DEBUG - 2011-09-30 18:03:04 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-30 18:03:04 --> Language Class Initialized
DEBUG - 2011-09-30 18:03:04 --> Loader Class Initialized
DEBUG - 2011-09-30 18:03:04 --> Controller Class Initialized
DEBUG - 2011-09-30 18:03:04 --> Model Class Initialized
DEBUG - 2011-09-30 18:03:04 --> Model Class Initialized
DEBUG - 2011-09-30 18:03:04 --> Model Class Initialized
DEBUG - 2011-09-30 18:03:04 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-30 18:03:04 --> Database Driver Class Initialized
DEBUG - 2011-09-30 18:03:05 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-30 18:03:05 --> Helper loaded: url_helper
DEBUG - 2011-09-30 18:03:05 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-30 18:03:05 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-30 18:03:05 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-30 18:03:05 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-30 18:03:05 --> Final output sent to browser
DEBUG - 2011-09-30 18:03:05 --> Total execution time: 0.0544
DEBUG - 2011-09-30 18:05:34 --> Config Class Initialized
DEBUG - 2011-09-30 18:05:34 --> Hooks Class Initialized
DEBUG - 2011-09-30 18:05:34 --> Utf8 Class Initialized
DEBUG - 2011-09-30 18:05:34 --> UTF-8 Support Enabled
DEBUG - 2011-09-30 18:05:34 --> URI Class Initialized
DEBUG - 2011-09-30 18:05:34 --> Router Class Initialized
DEBUG - 2011-09-30 18:05:34 --> Output Class Initialized
DEBUG - 2011-09-30 18:05:34 --> Input Class Initialized
DEBUG - 2011-09-30 18:05:34 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-30 18:05:34 --> Language Class Initialized
DEBUG - 2011-09-30 18:05:34 --> Loader Class Initialized
DEBUG - 2011-09-30 18:05:34 --> Controller Class Initialized
ERROR - 2011-09-30 18:05:34 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-30 18:05:34 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-30 18:05:34 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-30 18:05:34 --> Model Class Initialized
DEBUG - 2011-09-30 18:05:34 --> Model Class Initialized
DEBUG - 2011-09-30 18:05:34 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-30 18:05:34 --> Database Driver Class Initialized
DEBUG - 2011-09-30 18:05:34 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-30 18:05:34 --> Helper loaded: url_helper
DEBUG - 2011-09-30 18:05:34 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-30 18:05:34 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-30 18:05:34 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-30 18:05:34 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-30 18:05:34 --> Final output sent to browser
DEBUG - 2011-09-30 18:05:34 --> Total execution time: 0.0310
DEBUG - 2011-09-30 18:56:45 --> Config Class Initialized
DEBUG - 2011-09-30 18:56:45 --> Hooks Class Initialized
DEBUG - 2011-09-30 18:56:45 --> Utf8 Class Initialized
DEBUG - 2011-09-30 18:56:45 --> UTF-8 Support Enabled
DEBUG - 2011-09-30 18:56:45 --> URI Class Initialized
DEBUG - 2011-09-30 18:56:45 --> Router Class Initialized
DEBUG - 2011-09-30 18:56:45 --> Output Class Initialized
DEBUG - 2011-09-30 18:56:45 --> Input Class Initialized
DEBUG - 2011-09-30 18:56:45 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-30 18:56:45 --> Language Class Initialized
DEBUG - 2011-09-30 18:56:45 --> Loader Class Initialized
DEBUG - 2011-09-30 18:56:45 --> Controller Class Initialized
ERROR - 2011-09-30 18:56:45 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-30 18:56:45 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-30 18:56:45 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-30 18:56:45 --> Model Class Initialized
DEBUG - 2011-09-30 18:56:45 --> Model Class Initialized
DEBUG - 2011-09-30 18:56:45 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-30 18:56:45 --> Database Driver Class Initialized
DEBUG - 2011-09-30 18:56:48 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-30 18:56:48 --> Helper loaded: url_helper
DEBUG - 2011-09-30 18:56:48 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-30 18:56:48 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-30 18:56:48 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-30 18:56:48 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-30 18:56:48 --> Final output sent to browser
DEBUG - 2011-09-30 18:56:48 --> Total execution time: 3.6854
DEBUG - 2011-09-30 18:56:50 --> Config Class Initialized
DEBUG - 2011-09-30 18:56:50 --> Hooks Class Initialized
DEBUG - 2011-09-30 18:56:50 --> Utf8 Class Initialized
DEBUG - 2011-09-30 18:56:50 --> UTF-8 Support Enabled
DEBUG - 2011-09-30 18:56:50 --> URI Class Initialized
DEBUG - 2011-09-30 18:56:50 --> Router Class Initialized
DEBUG - 2011-09-30 18:56:50 --> Output Class Initialized
DEBUG - 2011-09-30 18:56:50 --> Input Class Initialized
DEBUG - 2011-09-30 18:56:50 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-30 18:56:50 --> Language Class Initialized
DEBUG - 2011-09-30 18:56:50 --> Loader Class Initialized
DEBUG - 2011-09-30 18:56:50 --> Controller Class Initialized
DEBUG - 2011-09-30 18:56:50 --> Model Class Initialized
DEBUG - 2011-09-30 18:56:50 --> Model Class Initialized
DEBUG - 2011-09-30 18:56:50 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-30 18:56:50 --> Database Driver Class Initialized
DEBUG - 2011-09-30 18:56:50 --> Final output sent to browser
DEBUG - 2011-09-30 18:56:50 --> Total execution time: 0.7425
DEBUG - 2011-09-30 18:56:51 --> Config Class Initialized
DEBUG - 2011-09-30 18:56:51 --> Hooks Class Initialized
DEBUG - 2011-09-30 18:56:51 --> Utf8 Class Initialized
DEBUG - 2011-09-30 18:56:51 --> UTF-8 Support Enabled
DEBUG - 2011-09-30 18:56:51 --> URI Class Initialized
DEBUG - 2011-09-30 18:56:51 --> Router Class Initialized
ERROR - 2011-09-30 18:56:51 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-30 20:20:50 --> Config Class Initialized
DEBUG - 2011-09-30 20:20:50 --> Hooks Class Initialized
DEBUG - 2011-09-30 20:20:50 --> Utf8 Class Initialized
DEBUG - 2011-09-30 20:20:50 --> UTF-8 Support Enabled
DEBUG - 2011-09-30 20:20:50 --> URI Class Initialized
DEBUG - 2011-09-30 20:20:50 --> Router Class Initialized
DEBUG - 2011-09-30 20:20:50 --> Output Class Initialized
DEBUG - 2011-09-30 20:20:50 --> Input Class Initialized
DEBUG - 2011-09-30 20:20:50 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-30 20:20:50 --> Language Class Initialized
DEBUG - 2011-09-30 20:20:50 --> Loader Class Initialized
DEBUG - 2011-09-30 20:20:50 --> Controller Class Initialized
ERROR - 2011-09-30 20:20:50 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-30 20:20:50 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-30 20:20:50 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-30 20:20:50 --> Model Class Initialized
DEBUG - 2011-09-30 20:20:50 --> Model Class Initialized
DEBUG - 2011-09-30 20:20:50 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-30 20:20:50 --> Database Driver Class Initialized
DEBUG - 2011-09-30 20:20:50 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-30 20:20:50 --> Helper loaded: url_helper
DEBUG - 2011-09-30 20:20:50 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-30 20:20:50 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-30 20:20:50 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-30 20:20:50 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-30 20:20:50 --> Final output sent to browser
DEBUG - 2011-09-30 20:20:50 --> Total execution time: 0.1281
DEBUG - 2011-09-30 20:20:51 --> Config Class Initialized
DEBUG - 2011-09-30 20:20:51 --> Hooks Class Initialized
DEBUG - 2011-09-30 20:20:51 --> Utf8 Class Initialized
DEBUG - 2011-09-30 20:20:51 --> UTF-8 Support Enabled
DEBUG - 2011-09-30 20:20:51 --> URI Class Initialized
DEBUG - 2011-09-30 20:20:51 --> Router Class Initialized
DEBUG - 2011-09-30 20:20:51 --> Output Class Initialized
DEBUG - 2011-09-30 20:20:51 --> Input Class Initialized
DEBUG - 2011-09-30 20:20:51 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-30 20:20:51 --> Language Class Initialized
DEBUG - 2011-09-30 20:20:51 --> Loader Class Initialized
DEBUG - 2011-09-30 20:20:51 --> Controller Class Initialized
DEBUG - 2011-09-30 20:20:51 --> Model Class Initialized
DEBUG - 2011-09-30 20:20:51 --> Model Class Initialized
DEBUG - 2011-09-30 20:20:51 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-30 20:20:51 --> Database Driver Class Initialized
DEBUG - 2011-09-30 20:20:52 --> Final output sent to browser
DEBUG - 2011-09-30 20:20:52 --> Total execution time: 0.7507
DEBUG - 2011-09-30 21:37:42 --> Config Class Initialized
DEBUG - 2011-09-30 21:37:42 --> Hooks Class Initialized
DEBUG - 2011-09-30 21:37:42 --> Utf8 Class Initialized
DEBUG - 2011-09-30 21:37:42 --> UTF-8 Support Enabled
DEBUG - 2011-09-30 21:37:42 --> URI Class Initialized
DEBUG - 2011-09-30 21:37:42 --> Router Class Initialized
DEBUG - 2011-09-30 21:37:42 --> No URI present. Default controller set.
DEBUG - 2011-09-30 21:37:42 --> Output Class Initialized
DEBUG - 2011-09-30 21:37:42 --> Input Class Initialized
DEBUG - 2011-09-30 21:37:42 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-30 21:37:42 --> Language Class Initialized
DEBUG - 2011-09-30 21:37:42 --> Loader Class Initialized
DEBUG - 2011-09-30 21:37:42 --> Controller Class Initialized
DEBUG - 2011-09-30 21:37:42 --> File loaded: application/views/splash/main.php
DEBUG - 2011-09-30 21:37:42 --> Helper loaded: url_helper
DEBUG - 2011-09-30 21:37:42 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-30 21:37:42 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-30 21:37:42 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-30 21:37:42 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-30 21:37:42 --> Final output sent to browser
DEBUG - 2011-09-30 21:37:42 --> Total execution time: 0.0583
DEBUG - 2011-09-30 21:58:55 --> Config Class Initialized
DEBUG - 2011-09-30 21:58:55 --> Hooks Class Initialized
DEBUG - 2011-09-30 21:58:55 --> Utf8 Class Initialized
DEBUG - 2011-09-30 21:58:55 --> UTF-8 Support Enabled
DEBUG - 2011-09-30 21:58:55 --> URI Class Initialized
DEBUG - 2011-09-30 21:58:55 --> Router Class Initialized
ERROR - 2011-09-30 21:58:55 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-09-30 21:58:55 --> Config Class Initialized
DEBUG - 2011-09-30 21:58:55 --> Hooks Class Initialized
DEBUG - 2011-09-30 21:58:55 --> Utf8 Class Initialized
DEBUG - 2011-09-30 21:58:55 --> UTF-8 Support Enabled
DEBUG - 2011-09-30 21:58:55 --> URI Class Initialized
DEBUG - 2011-09-30 21:58:55 --> Router Class Initialized
DEBUG - 2011-09-30 21:58:56 --> Output Class Initialized
DEBUG - 2011-09-30 21:58:56 --> Input Class Initialized
DEBUG - 2011-09-30 21:58:56 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-30 21:58:56 --> Language Class Initialized
DEBUG - 2011-09-30 21:58:56 --> Loader Class Initialized
DEBUG - 2011-09-30 21:58:56 --> Controller Class Initialized
DEBUG - 2011-09-30 21:58:56 --> Model Class Initialized
DEBUG - 2011-09-30 21:58:56 --> Model Class Initialized
DEBUG - 2011-09-30 21:58:56 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-30 21:58:56 --> Database Driver Class Initialized
DEBUG - 2011-09-30 21:58:56 --> Final output sent to browser
DEBUG - 2011-09-30 21:58:56 --> Total execution time: 0.7920

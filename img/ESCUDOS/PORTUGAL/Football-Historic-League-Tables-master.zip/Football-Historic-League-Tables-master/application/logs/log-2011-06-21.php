<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2011-06-21 09:08:10 --> Config Class Initialized
DEBUG - 2011-06-21 09:08:10 --> Hooks Class Initialized
DEBUG - 2011-06-21 09:08:10 --> Utf8 Class Initialized
DEBUG - 2011-06-21 09:08:10 --> UTF-8 Support Enabled
DEBUG - 2011-06-21 09:08:10 --> URI Class Initialized
DEBUG - 2011-06-21 09:08:10 --> Router Class Initialized
DEBUG - 2011-06-21 09:08:10 --> Output Class Initialized
DEBUG - 2011-06-21 09:08:10 --> Input Class Initialized
DEBUG - 2011-06-21 09:08:10 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-21 09:08:10 --> Language Class Initialized
DEBUG - 2011-06-21 09:08:10 --> Loader Class Initialized
DEBUG - 2011-06-21 09:08:10 --> Controller Class Initialized
ERROR - 2011-06-21 09:08:10 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-21 09:08:10 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-21 09:08:10 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-21 09:08:10 --> Model Class Initialized
DEBUG - 2011-06-21 09:08:10 --> Model Class Initialized
DEBUG - 2011-06-21 09:08:10 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-21 09:08:10 --> Database Driver Class Initialized
DEBUG - 2011-06-21 09:08:10 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-21 09:08:11 --> Helper loaded: url_helper
DEBUG - 2011-06-21 09:08:11 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-21 09:08:11 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-21 09:08:11 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-21 09:08:11 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-21 09:08:11 --> Final output sent to browser
DEBUG - 2011-06-21 09:08:11 --> Total execution time: 1.1338
DEBUG - 2011-06-21 09:08:12 --> Config Class Initialized
DEBUG - 2011-06-21 09:08:12 --> Hooks Class Initialized
DEBUG - 2011-06-21 09:08:12 --> Utf8 Class Initialized
DEBUG - 2011-06-21 09:08:12 --> UTF-8 Support Enabled
DEBUG - 2011-06-21 09:08:12 --> URI Class Initialized
DEBUG - 2011-06-21 09:08:12 --> Router Class Initialized
DEBUG - 2011-06-21 09:08:12 --> Output Class Initialized
DEBUG - 2011-06-21 09:08:12 --> Input Class Initialized
DEBUG - 2011-06-21 09:08:12 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-21 09:08:12 --> Language Class Initialized
DEBUG - 2011-06-21 09:08:12 --> Loader Class Initialized
DEBUG - 2011-06-21 09:08:12 --> Controller Class Initialized
DEBUG - 2011-06-21 09:08:12 --> Model Class Initialized
DEBUG - 2011-06-21 09:08:12 --> Model Class Initialized
DEBUG - 2011-06-21 09:08:12 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-21 09:08:12 --> Database Driver Class Initialized
DEBUG - 2011-06-21 09:08:13 --> Final output sent to browser
DEBUG - 2011-06-21 09:08:13 --> Total execution time: 0.9769
DEBUG - 2011-06-21 09:08:14 --> Config Class Initialized
DEBUG - 2011-06-21 09:08:14 --> Hooks Class Initialized
DEBUG - 2011-06-21 09:08:14 --> Utf8 Class Initialized
DEBUG - 2011-06-21 09:08:14 --> UTF-8 Support Enabled
DEBUG - 2011-06-21 09:08:14 --> URI Class Initialized
DEBUG - 2011-06-21 09:08:14 --> Router Class Initialized
ERROR - 2011-06-21 09:08:14 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-21 09:08:15 --> Config Class Initialized
DEBUG - 2011-06-21 09:08:15 --> Hooks Class Initialized
DEBUG - 2011-06-21 09:08:15 --> Utf8 Class Initialized
DEBUG - 2011-06-21 09:08:15 --> UTF-8 Support Enabled
DEBUG - 2011-06-21 09:08:15 --> URI Class Initialized
DEBUG - 2011-06-21 09:08:15 --> Router Class Initialized
ERROR - 2011-06-21 09:08:15 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-21 09:08:15 --> Config Class Initialized
DEBUG - 2011-06-21 09:08:15 --> Hooks Class Initialized
DEBUG - 2011-06-21 09:08:15 --> Utf8 Class Initialized
DEBUG - 2011-06-21 09:08:15 --> UTF-8 Support Enabled
DEBUG - 2011-06-21 09:08:15 --> URI Class Initialized
DEBUG - 2011-06-21 09:08:15 --> Router Class Initialized
ERROR - 2011-06-21 09:08:15 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-21 09:08:37 --> Config Class Initialized
DEBUG - 2011-06-21 09:08:37 --> Hooks Class Initialized
DEBUG - 2011-06-21 09:08:37 --> Utf8 Class Initialized
DEBUG - 2011-06-21 09:08:37 --> UTF-8 Support Enabled
DEBUG - 2011-06-21 09:08:37 --> URI Class Initialized
DEBUG - 2011-06-21 09:08:37 --> Router Class Initialized
DEBUG - 2011-06-21 09:08:37 --> Output Class Initialized
DEBUG - 2011-06-21 09:08:37 --> Input Class Initialized
DEBUG - 2011-06-21 09:08:37 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-21 09:08:37 --> Language Class Initialized
DEBUG - 2011-06-21 09:08:37 --> Loader Class Initialized
DEBUG - 2011-06-21 09:08:37 --> Controller Class Initialized
ERROR - 2011-06-21 09:08:37 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-21 09:08:37 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-21 09:08:37 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-21 09:08:37 --> Model Class Initialized
DEBUG - 2011-06-21 09:08:37 --> Model Class Initialized
DEBUG - 2011-06-21 09:08:37 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-21 09:08:37 --> Database Driver Class Initialized
DEBUG - 2011-06-21 09:08:37 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-21 09:08:37 --> Helper loaded: url_helper
DEBUG - 2011-06-21 09:08:37 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-21 09:08:37 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-21 09:08:37 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-21 09:08:37 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-21 09:08:37 --> Final output sent to browser
DEBUG - 2011-06-21 09:08:37 --> Total execution time: 0.0527
DEBUG - 2011-06-21 09:08:38 --> Config Class Initialized
DEBUG - 2011-06-21 09:08:38 --> Hooks Class Initialized
DEBUG - 2011-06-21 09:08:38 --> Utf8 Class Initialized
DEBUG - 2011-06-21 09:08:38 --> UTF-8 Support Enabled
DEBUG - 2011-06-21 09:08:38 --> URI Class Initialized
DEBUG - 2011-06-21 09:08:38 --> Router Class Initialized
DEBUG - 2011-06-21 09:08:38 --> Output Class Initialized
DEBUG - 2011-06-21 09:08:38 --> Input Class Initialized
DEBUG - 2011-06-21 09:08:38 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-21 09:08:38 --> Language Class Initialized
DEBUG - 2011-06-21 09:08:38 --> Loader Class Initialized
DEBUG - 2011-06-21 09:08:38 --> Controller Class Initialized
DEBUG - 2011-06-21 09:08:38 --> Model Class Initialized
DEBUG - 2011-06-21 09:08:38 --> Model Class Initialized
DEBUG - 2011-06-21 09:08:38 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-21 09:08:38 --> Database Driver Class Initialized
DEBUG - 2011-06-21 09:08:39 --> Final output sent to browser
DEBUG - 2011-06-21 09:08:39 --> Total execution time: 0.9478
DEBUG - 2011-06-21 09:08:52 --> Config Class Initialized
DEBUG - 2011-06-21 09:08:52 --> Hooks Class Initialized
DEBUG - 2011-06-21 09:08:52 --> Utf8 Class Initialized
DEBUG - 2011-06-21 09:08:52 --> UTF-8 Support Enabled
DEBUG - 2011-06-21 09:08:52 --> URI Class Initialized
DEBUG - 2011-06-21 09:08:52 --> Router Class Initialized
DEBUG - 2011-06-21 09:08:52 --> Output Class Initialized
DEBUG - 2011-06-21 09:08:52 --> Input Class Initialized
DEBUG - 2011-06-21 09:08:52 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-21 09:08:52 --> Language Class Initialized
DEBUG - 2011-06-21 09:08:52 --> Loader Class Initialized
DEBUG - 2011-06-21 09:08:52 --> Controller Class Initialized
ERROR - 2011-06-21 09:08:52 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-21 09:08:52 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-21 09:08:52 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-21 09:08:52 --> Model Class Initialized
DEBUG - 2011-06-21 09:08:52 --> Model Class Initialized
DEBUG - 2011-06-21 09:08:52 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-21 09:08:52 --> Database Driver Class Initialized
DEBUG - 2011-06-21 09:08:53 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-21 09:08:53 --> Helper loaded: url_helper
DEBUG - 2011-06-21 09:08:53 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-21 09:08:53 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-21 09:08:53 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-21 09:08:53 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-21 09:08:53 --> Final output sent to browser
DEBUG - 2011-06-21 09:08:53 --> Total execution time: 0.0500
DEBUG - 2011-06-21 09:08:53 --> Config Class Initialized
DEBUG - 2011-06-21 09:08:53 --> Hooks Class Initialized
DEBUG - 2011-06-21 09:08:53 --> Utf8 Class Initialized
DEBUG - 2011-06-21 09:08:53 --> UTF-8 Support Enabled
DEBUG - 2011-06-21 09:08:53 --> URI Class Initialized
DEBUG - 2011-06-21 09:08:53 --> Router Class Initialized
DEBUG - 2011-06-21 09:08:53 --> Output Class Initialized
DEBUG - 2011-06-21 09:08:53 --> Input Class Initialized
DEBUG - 2011-06-21 09:08:53 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-21 09:08:53 --> Language Class Initialized
DEBUG - 2011-06-21 09:08:53 --> Loader Class Initialized
DEBUG - 2011-06-21 09:08:53 --> Controller Class Initialized
DEBUG - 2011-06-21 09:08:53 --> Model Class Initialized
DEBUG - 2011-06-21 09:08:53 --> Model Class Initialized
DEBUG - 2011-06-21 09:08:53 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-21 09:08:53 --> Database Driver Class Initialized
DEBUG - 2011-06-21 09:08:54 --> Final output sent to browser
DEBUG - 2011-06-21 09:08:54 --> Total execution time: 1.0421
DEBUG - 2011-06-21 09:09:10 --> Config Class Initialized
DEBUG - 2011-06-21 09:09:10 --> Hooks Class Initialized
DEBUG - 2011-06-21 09:09:10 --> Utf8 Class Initialized
DEBUG - 2011-06-21 09:09:10 --> UTF-8 Support Enabled
DEBUG - 2011-06-21 09:09:10 --> URI Class Initialized
DEBUG - 2011-06-21 09:09:10 --> Router Class Initialized
DEBUG - 2011-06-21 09:09:10 --> Output Class Initialized
DEBUG - 2011-06-21 09:09:10 --> Input Class Initialized
DEBUG - 2011-06-21 09:09:10 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-21 09:09:10 --> Language Class Initialized
DEBUG - 2011-06-21 09:09:10 --> Loader Class Initialized
DEBUG - 2011-06-21 09:09:10 --> Controller Class Initialized
ERROR - 2011-06-21 09:09:10 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-21 09:09:10 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-21 09:09:10 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-21 09:09:10 --> Model Class Initialized
DEBUG - 2011-06-21 09:09:10 --> Model Class Initialized
DEBUG - 2011-06-21 09:09:10 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-21 09:09:10 --> Database Driver Class Initialized
DEBUG - 2011-06-21 09:09:10 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-21 09:09:10 --> Helper loaded: url_helper
DEBUG - 2011-06-21 09:09:10 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-21 09:09:10 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-21 09:09:10 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-21 09:09:10 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-21 09:09:10 --> Final output sent to browser
DEBUG - 2011-06-21 09:09:10 --> Total execution time: 0.0465
DEBUG - 2011-06-21 09:09:10 --> Config Class Initialized
DEBUG - 2011-06-21 09:09:10 --> Hooks Class Initialized
DEBUG - 2011-06-21 09:09:10 --> Utf8 Class Initialized
DEBUG - 2011-06-21 09:09:10 --> UTF-8 Support Enabled
DEBUG - 2011-06-21 09:09:10 --> URI Class Initialized
DEBUG - 2011-06-21 09:09:10 --> Router Class Initialized
DEBUG - 2011-06-21 09:09:10 --> Output Class Initialized
DEBUG - 2011-06-21 09:09:10 --> Input Class Initialized
DEBUG - 2011-06-21 09:09:10 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-21 09:09:10 --> Language Class Initialized
DEBUG - 2011-06-21 09:09:10 --> Loader Class Initialized
DEBUG - 2011-06-21 09:09:10 --> Controller Class Initialized
DEBUG - 2011-06-21 09:09:10 --> Model Class Initialized
DEBUG - 2011-06-21 09:09:10 --> Model Class Initialized
DEBUG - 2011-06-21 09:09:10 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-21 09:09:10 --> Database Driver Class Initialized
DEBUG - 2011-06-21 09:09:11 --> Final output sent to browser
DEBUG - 2011-06-21 09:09:11 --> Total execution time: 0.8601
DEBUG - 2011-06-21 09:09:20 --> Config Class Initialized
DEBUG - 2011-06-21 09:09:20 --> Hooks Class Initialized
DEBUG - 2011-06-21 09:09:20 --> Utf8 Class Initialized
DEBUG - 2011-06-21 09:09:20 --> UTF-8 Support Enabled
DEBUG - 2011-06-21 09:09:20 --> URI Class Initialized
DEBUG - 2011-06-21 09:09:20 --> Router Class Initialized
DEBUG - 2011-06-21 09:09:20 --> Output Class Initialized
DEBUG - 2011-06-21 09:09:20 --> Input Class Initialized
DEBUG - 2011-06-21 09:09:20 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-21 09:09:20 --> Language Class Initialized
DEBUG - 2011-06-21 09:09:20 --> Loader Class Initialized
DEBUG - 2011-06-21 09:09:20 --> Controller Class Initialized
ERROR - 2011-06-21 09:09:20 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-21 09:09:20 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-21 09:09:20 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-21 09:09:20 --> Model Class Initialized
DEBUG - 2011-06-21 09:09:20 --> Model Class Initialized
DEBUG - 2011-06-21 09:09:20 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-21 09:09:20 --> Database Driver Class Initialized
DEBUG - 2011-06-21 09:09:20 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-21 09:09:20 --> Helper loaded: url_helper
DEBUG - 2011-06-21 09:09:20 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-21 09:09:20 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-21 09:09:20 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-21 09:09:20 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-21 09:09:20 --> Final output sent to browser
DEBUG - 2011-06-21 09:09:20 --> Total execution time: 0.0387
DEBUG - 2011-06-21 09:09:21 --> Config Class Initialized
DEBUG - 2011-06-21 09:09:21 --> Hooks Class Initialized
DEBUG - 2011-06-21 09:09:21 --> Utf8 Class Initialized
DEBUG - 2011-06-21 09:09:21 --> UTF-8 Support Enabled
DEBUG - 2011-06-21 09:09:21 --> URI Class Initialized
DEBUG - 2011-06-21 09:09:21 --> Router Class Initialized
DEBUG - 2011-06-21 09:09:21 --> Output Class Initialized
DEBUG - 2011-06-21 09:09:21 --> Input Class Initialized
DEBUG - 2011-06-21 09:09:21 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-21 09:09:21 --> Language Class Initialized
DEBUG - 2011-06-21 09:09:21 --> Loader Class Initialized
DEBUG - 2011-06-21 09:09:21 --> Controller Class Initialized
DEBUG - 2011-06-21 09:09:21 --> Model Class Initialized
DEBUG - 2011-06-21 09:09:21 --> Model Class Initialized
DEBUG - 2011-06-21 09:09:21 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-21 09:09:21 --> Database Driver Class Initialized
DEBUG - 2011-06-21 09:09:21 --> Final output sent to browser
DEBUG - 2011-06-21 09:09:21 --> Total execution time: 0.5710
DEBUG - 2011-06-21 09:09:25 --> Config Class Initialized
DEBUG - 2011-06-21 09:09:25 --> Hooks Class Initialized
DEBUG - 2011-06-21 09:09:25 --> Utf8 Class Initialized
DEBUG - 2011-06-21 09:09:25 --> UTF-8 Support Enabled
DEBUG - 2011-06-21 09:09:25 --> URI Class Initialized
DEBUG - 2011-06-21 09:09:25 --> Router Class Initialized
DEBUG - 2011-06-21 09:09:25 --> Output Class Initialized
DEBUG - 2011-06-21 09:09:25 --> Input Class Initialized
DEBUG - 2011-06-21 09:09:25 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-21 09:09:25 --> Language Class Initialized
DEBUG - 2011-06-21 09:09:25 --> Loader Class Initialized
DEBUG - 2011-06-21 09:09:25 --> Controller Class Initialized
ERROR - 2011-06-21 09:09:25 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-21 09:09:25 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-21 09:09:25 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-21 09:09:25 --> Model Class Initialized
DEBUG - 2011-06-21 09:09:25 --> Model Class Initialized
DEBUG - 2011-06-21 09:09:25 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-21 09:09:25 --> Database Driver Class Initialized
DEBUG - 2011-06-21 09:09:25 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-21 09:09:25 --> Helper loaded: url_helper
DEBUG - 2011-06-21 09:09:25 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-21 09:09:25 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-21 09:09:25 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-21 09:09:25 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-21 09:09:25 --> Final output sent to browser
DEBUG - 2011-06-21 09:09:25 --> Total execution time: 0.0853
DEBUG - 2011-06-21 09:09:25 --> Config Class Initialized
DEBUG - 2011-06-21 09:09:25 --> Hooks Class Initialized
DEBUG - 2011-06-21 09:09:25 --> Utf8 Class Initialized
DEBUG - 2011-06-21 09:09:25 --> UTF-8 Support Enabled
DEBUG - 2011-06-21 09:09:25 --> URI Class Initialized
DEBUG - 2011-06-21 09:09:25 --> Router Class Initialized
DEBUG - 2011-06-21 09:09:25 --> Output Class Initialized
DEBUG - 2011-06-21 09:09:25 --> Input Class Initialized
DEBUG - 2011-06-21 09:09:25 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-21 09:09:25 --> Language Class Initialized
DEBUG - 2011-06-21 09:09:25 --> Loader Class Initialized
DEBUG - 2011-06-21 09:09:25 --> Controller Class Initialized
DEBUG - 2011-06-21 09:09:25 --> Model Class Initialized
DEBUG - 2011-06-21 09:09:25 --> Model Class Initialized
DEBUG - 2011-06-21 09:09:25 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-21 09:09:25 --> Database Driver Class Initialized
DEBUG - 2011-06-21 09:09:26 --> Final output sent to browser
DEBUG - 2011-06-21 09:09:26 --> Total execution time: 0.7441
DEBUG - 2011-06-21 10:21:35 --> Config Class Initialized
DEBUG - 2011-06-21 10:21:35 --> Hooks Class Initialized
DEBUG - 2011-06-21 10:21:35 --> Utf8 Class Initialized
DEBUG - 2011-06-21 10:21:35 --> UTF-8 Support Enabled
DEBUG - 2011-06-21 10:21:35 --> URI Class Initialized
DEBUG - 2011-06-21 10:21:35 --> Router Class Initialized
ERROR - 2011-06-21 10:21:35 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-06-21 10:21:36 --> Config Class Initialized
DEBUG - 2011-06-21 10:21:36 --> Hooks Class Initialized
DEBUG - 2011-06-21 10:21:36 --> Utf8 Class Initialized
DEBUG - 2011-06-21 10:21:36 --> UTF-8 Support Enabled
DEBUG - 2011-06-21 10:21:36 --> URI Class Initialized
DEBUG - 2011-06-21 10:21:36 --> Router Class Initialized
DEBUG - 2011-06-21 10:21:36 --> Output Class Initialized
DEBUG - 2011-06-21 10:21:36 --> Input Class Initialized
DEBUG - 2011-06-21 10:21:36 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-21 10:21:36 --> Language Class Initialized
DEBUG - 2011-06-21 10:21:36 --> Loader Class Initialized
DEBUG - 2011-06-21 10:21:36 --> Controller Class Initialized
ERROR - 2011-06-21 10:21:37 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-21 10:21:37 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-21 10:21:37 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-21 10:21:37 --> Model Class Initialized
DEBUG - 2011-06-21 10:21:37 --> Model Class Initialized
DEBUG - 2011-06-21 10:21:37 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-21 10:21:37 --> Database Driver Class Initialized
DEBUG - 2011-06-21 10:21:37 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-21 10:21:37 --> Helper loaded: url_helper
DEBUG - 2011-06-21 10:21:37 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-21 10:21:37 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-21 10:21:38 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-21 10:21:38 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-21 10:21:38 --> Final output sent to browser
DEBUG - 2011-06-21 10:21:38 --> Total execution time: 1.4395
DEBUG - 2011-06-21 10:21:38 --> Config Class Initialized
DEBUG - 2011-06-21 10:21:38 --> Hooks Class Initialized
DEBUG - 2011-06-21 10:21:38 --> Utf8 Class Initialized
DEBUG - 2011-06-21 10:21:38 --> UTF-8 Support Enabled
DEBUG - 2011-06-21 10:21:38 --> URI Class Initialized
DEBUG - 2011-06-21 10:21:38 --> Router Class Initialized
DEBUG - 2011-06-21 10:21:38 --> Output Class Initialized
DEBUG - 2011-06-21 10:21:38 --> Input Class Initialized
DEBUG - 2011-06-21 10:21:38 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-21 10:21:38 --> Language Class Initialized
DEBUG - 2011-06-21 10:21:38 --> Loader Class Initialized
DEBUG - 2011-06-21 10:21:38 --> Controller Class Initialized
DEBUG - 2011-06-21 10:21:38 --> Model Class Initialized
DEBUG - 2011-06-21 10:21:39 --> Model Class Initialized
DEBUG - 2011-06-21 10:21:39 --> Model Class Initialized
DEBUG - 2011-06-21 10:21:39 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-21 10:21:39 --> Database Driver Class Initialized
DEBUG - 2011-06-21 10:21:40 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-21 10:21:40 --> Helper loaded: url_helper
DEBUG - 2011-06-21 10:21:40 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-21 10:21:40 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-21 10:21:40 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-21 10:21:40 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-21 10:21:40 --> Final output sent to browser
DEBUG - 2011-06-21 10:21:40 --> Total execution time: 1.4574
DEBUG - 2011-06-21 11:11:58 --> Config Class Initialized
DEBUG - 2011-06-21 11:11:58 --> Hooks Class Initialized
DEBUG - 2011-06-21 11:11:59 --> Utf8 Class Initialized
DEBUG - 2011-06-21 11:11:59 --> UTF-8 Support Enabled
DEBUG - 2011-06-21 11:11:59 --> URI Class Initialized
DEBUG - 2011-06-21 11:11:59 --> Router Class Initialized
DEBUG - 2011-06-21 11:11:59 --> Output Class Initialized
DEBUG - 2011-06-21 11:11:59 --> Input Class Initialized
DEBUG - 2011-06-21 11:11:59 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-21 11:11:59 --> Language Class Initialized
DEBUG - 2011-06-21 11:11:59 --> Loader Class Initialized
DEBUG - 2011-06-21 11:11:59 --> Controller Class Initialized
ERROR - 2011-06-21 11:11:59 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-21 11:11:59 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-21 11:11:59 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-21 11:11:59 --> Model Class Initialized
DEBUG - 2011-06-21 11:11:59 --> Model Class Initialized
DEBUG - 2011-06-21 11:11:59 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-21 11:11:59 --> Database Driver Class Initialized
DEBUG - 2011-06-21 11:11:59 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-21 11:11:59 --> Helper loaded: url_helper
DEBUG - 2011-06-21 11:11:59 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-21 11:11:59 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-21 11:11:59 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-21 11:11:59 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-21 11:11:59 --> Final output sent to browser
DEBUG - 2011-06-21 11:11:59 --> Total execution time: 1.2000
DEBUG - 2011-06-21 11:12:00 --> Config Class Initialized
DEBUG - 2011-06-21 11:12:00 --> Hooks Class Initialized
DEBUG - 2011-06-21 11:12:00 --> Utf8 Class Initialized
DEBUG - 2011-06-21 11:12:00 --> UTF-8 Support Enabled
DEBUG - 2011-06-21 11:12:00 --> URI Class Initialized
DEBUG - 2011-06-21 11:12:00 --> Router Class Initialized
DEBUG - 2011-06-21 11:12:00 --> Output Class Initialized
DEBUG - 2011-06-21 11:12:00 --> Input Class Initialized
DEBUG - 2011-06-21 11:12:00 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-21 11:12:00 --> Language Class Initialized
DEBUG - 2011-06-21 11:12:00 --> Loader Class Initialized
DEBUG - 2011-06-21 11:12:00 --> Controller Class Initialized
DEBUG - 2011-06-21 11:12:00 --> Model Class Initialized
DEBUG - 2011-06-21 11:12:00 --> Model Class Initialized
DEBUG - 2011-06-21 11:12:00 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-21 11:12:00 --> Database Driver Class Initialized
DEBUG - 2011-06-21 11:12:01 --> Final output sent to browser
DEBUG - 2011-06-21 11:12:01 --> Total execution time: 0.6133
DEBUG - 2011-06-21 11:12:01 --> Config Class Initialized
DEBUG - 2011-06-21 11:12:01 --> Hooks Class Initialized
DEBUG - 2011-06-21 11:12:01 --> Utf8 Class Initialized
DEBUG - 2011-06-21 11:12:01 --> UTF-8 Support Enabled
DEBUG - 2011-06-21 11:12:01 --> URI Class Initialized
DEBUG - 2011-06-21 11:12:01 --> Router Class Initialized
ERROR - 2011-06-21 11:12:01 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-21 11:12:03 --> Config Class Initialized
DEBUG - 2011-06-21 11:12:03 --> Hooks Class Initialized
DEBUG - 2011-06-21 11:12:03 --> Utf8 Class Initialized
DEBUG - 2011-06-21 11:12:03 --> UTF-8 Support Enabled
DEBUG - 2011-06-21 11:12:03 --> URI Class Initialized
DEBUG - 2011-06-21 11:12:03 --> Router Class Initialized
ERROR - 2011-06-21 11:12:03 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-21 11:57:37 --> Config Class Initialized
DEBUG - 2011-06-21 11:57:37 --> Hooks Class Initialized
DEBUG - 2011-06-21 11:57:37 --> Utf8 Class Initialized
DEBUG - 2011-06-21 11:57:37 --> UTF-8 Support Enabled
DEBUG - 2011-06-21 11:57:37 --> URI Class Initialized
DEBUG - 2011-06-21 11:57:37 --> Router Class Initialized
DEBUG - 2011-06-21 11:57:37 --> Output Class Initialized
DEBUG - 2011-06-21 11:57:37 --> Input Class Initialized
DEBUG - 2011-06-21 11:57:37 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-21 11:57:37 --> Language Class Initialized
DEBUG - 2011-06-21 11:57:37 --> Loader Class Initialized
DEBUG - 2011-06-21 11:57:37 --> Controller Class Initialized
ERROR - 2011-06-21 11:57:37 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-21 11:57:37 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-21 11:57:37 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-21 11:57:37 --> Model Class Initialized
DEBUG - 2011-06-21 11:57:37 --> Model Class Initialized
DEBUG - 2011-06-21 11:57:37 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-21 11:57:37 --> Database Driver Class Initialized
DEBUG - 2011-06-21 11:57:37 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-21 11:57:38 --> Helper loaded: url_helper
DEBUG - 2011-06-21 11:57:38 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-21 11:57:38 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-21 11:57:38 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-21 11:57:38 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-21 11:57:38 --> Final output sent to browser
DEBUG - 2011-06-21 11:57:38 --> Total execution time: 0.9643
DEBUG - 2011-06-21 11:57:39 --> Config Class Initialized
DEBUG - 2011-06-21 11:57:39 --> Hooks Class Initialized
DEBUG - 2011-06-21 11:57:39 --> Utf8 Class Initialized
DEBUG - 2011-06-21 11:57:39 --> UTF-8 Support Enabled
DEBUG - 2011-06-21 11:57:39 --> URI Class Initialized
DEBUG - 2011-06-21 11:57:39 --> Router Class Initialized
DEBUG - 2011-06-21 11:57:39 --> Output Class Initialized
DEBUG - 2011-06-21 11:57:39 --> Input Class Initialized
DEBUG - 2011-06-21 11:57:39 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-21 11:57:39 --> Language Class Initialized
DEBUG - 2011-06-21 11:57:39 --> Loader Class Initialized
DEBUG - 2011-06-21 11:57:39 --> Controller Class Initialized
DEBUG - 2011-06-21 11:57:39 --> Model Class Initialized
DEBUG - 2011-06-21 11:57:39 --> Model Class Initialized
DEBUG - 2011-06-21 11:57:39 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-21 11:57:39 --> Database Driver Class Initialized
DEBUG - 2011-06-21 11:57:39 --> Final output sent to browser
DEBUG - 2011-06-21 11:57:39 --> Total execution time: 0.6911
DEBUG - 2011-06-21 11:57:50 --> Config Class Initialized
DEBUG - 2011-06-21 11:57:50 --> Hooks Class Initialized
DEBUG - 2011-06-21 11:57:50 --> Utf8 Class Initialized
DEBUG - 2011-06-21 11:57:50 --> UTF-8 Support Enabled
DEBUG - 2011-06-21 11:57:50 --> URI Class Initialized
DEBUG - 2011-06-21 11:57:50 --> Router Class Initialized
DEBUG - 2011-06-21 11:57:50 --> Output Class Initialized
DEBUG - 2011-06-21 11:57:50 --> Input Class Initialized
DEBUG - 2011-06-21 11:57:50 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-21 11:57:50 --> Language Class Initialized
DEBUG - 2011-06-21 11:57:50 --> Loader Class Initialized
DEBUG - 2011-06-21 11:57:50 --> Controller Class Initialized
ERROR - 2011-06-21 11:57:50 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-21 11:57:50 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-21 11:57:50 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-21 11:57:50 --> Model Class Initialized
DEBUG - 2011-06-21 11:57:50 --> Model Class Initialized
DEBUG - 2011-06-21 11:57:50 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-21 11:57:50 --> Database Driver Class Initialized
DEBUG - 2011-06-21 11:57:51 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-21 11:57:51 --> Helper loaded: url_helper
DEBUG - 2011-06-21 11:57:51 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-21 11:57:51 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-21 11:57:51 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-21 11:57:51 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-21 11:57:51 --> Final output sent to browser
DEBUG - 2011-06-21 11:57:51 --> Total execution time: 0.0330
DEBUG - 2011-06-21 11:57:51 --> Config Class Initialized
DEBUG - 2011-06-21 11:57:51 --> Hooks Class Initialized
DEBUG - 2011-06-21 11:57:51 --> Utf8 Class Initialized
DEBUG - 2011-06-21 11:57:51 --> UTF-8 Support Enabled
DEBUG - 2011-06-21 11:57:51 --> URI Class Initialized
DEBUG - 2011-06-21 11:57:51 --> Router Class Initialized
DEBUG - 2011-06-21 11:57:51 --> Output Class Initialized
DEBUG - 2011-06-21 11:57:51 --> Input Class Initialized
DEBUG - 2011-06-21 11:57:51 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-21 11:57:51 --> Language Class Initialized
DEBUG - 2011-06-21 11:57:51 --> Loader Class Initialized
DEBUG - 2011-06-21 11:57:51 --> Controller Class Initialized
DEBUG - 2011-06-21 11:57:51 --> Model Class Initialized
DEBUG - 2011-06-21 11:57:51 --> Model Class Initialized
DEBUG - 2011-06-21 11:57:51 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-21 11:57:51 --> Database Driver Class Initialized
DEBUG - 2011-06-21 11:57:52 --> Final output sent to browser
DEBUG - 2011-06-21 11:57:52 --> Total execution time: 0.5019
DEBUG - 2011-06-21 11:58:11 --> Config Class Initialized
DEBUG - 2011-06-21 11:58:11 --> Hooks Class Initialized
DEBUG - 2011-06-21 11:58:11 --> Utf8 Class Initialized
DEBUG - 2011-06-21 11:58:11 --> UTF-8 Support Enabled
DEBUG - 2011-06-21 11:58:11 --> URI Class Initialized
DEBUG - 2011-06-21 11:58:11 --> Router Class Initialized
DEBUG - 2011-06-21 11:58:11 --> Output Class Initialized
DEBUG - 2011-06-21 11:58:11 --> Input Class Initialized
DEBUG - 2011-06-21 11:58:11 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-21 11:58:11 --> Language Class Initialized
DEBUG - 2011-06-21 11:58:11 --> Loader Class Initialized
DEBUG - 2011-06-21 11:58:11 --> Controller Class Initialized
ERROR - 2011-06-21 11:58:11 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-21 11:58:11 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-21 11:58:11 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-21 11:58:11 --> Model Class Initialized
DEBUG - 2011-06-21 11:58:11 --> Model Class Initialized
DEBUG - 2011-06-21 11:58:11 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-21 11:58:11 --> Database Driver Class Initialized
DEBUG - 2011-06-21 11:58:11 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-21 11:58:11 --> Helper loaded: url_helper
DEBUG - 2011-06-21 11:58:11 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-21 11:58:11 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-21 11:58:11 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-21 11:58:11 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-21 11:58:11 --> Final output sent to browser
DEBUG - 2011-06-21 11:58:11 --> Total execution time: 0.0577
DEBUG - 2011-06-21 11:58:12 --> Config Class Initialized
DEBUG - 2011-06-21 11:58:12 --> Hooks Class Initialized
DEBUG - 2011-06-21 11:58:12 --> Utf8 Class Initialized
DEBUG - 2011-06-21 11:58:12 --> UTF-8 Support Enabled
DEBUG - 2011-06-21 11:58:12 --> URI Class Initialized
DEBUG - 2011-06-21 11:58:12 --> Router Class Initialized
DEBUG - 2011-06-21 11:58:12 --> Output Class Initialized
DEBUG - 2011-06-21 11:58:12 --> Input Class Initialized
DEBUG - 2011-06-21 11:58:12 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-21 11:58:12 --> Language Class Initialized
DEBUG - 2011-06-21 11:58:12 --> Loader Class Initialized
DEBUG - 2011-06-21 11:58:12 --> Controller Class Initialized
DEBUG - 2011-06-21 11:58:12 --> Model Class Initialized
DEBUG - 2011-06-21 11:58:12 --> Model Class Initialized
DEBUG - 2011-06-21 11:58:12 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-21 11:58:12 --> Database Driver Class Initialized
DEBUG - 2011-06-21 11:58:13 --> Final output sent to browser
DEBUG - 2011-06-21 11:58:13 --> Total execution time: 0.5618
DEBUG - 2011-06-21 11:58:14 --> Config Class Initialized
DEBUG - 2011-06-21 11:58:14 --> Hooks Class Initialized
DEBUG - 2011-06-21 11:58:14 --> Utf8 Class Initialized
DEBUG - 2011-06-21 11:58:14 --> UTF-8 Support Enabled
DEBUG - 2011-06-21 11:58:14 --> URI Class Initialized
DEBUG - 2011-06-21 11:58:14 --> Router Class Initialized
ERROR - 2011-06-21 11:58:14 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-06-21 11:58:14 --> Config Class Initialized
DEBUG - 2011-06-21 11:58:14 --> Hooks Class Initialized
DEBUG - 2011-06-21 11:58:14 --> Utf8 Class Initialized
DEBUG - 2011-06-21 11:58:14 --> UTF-8 Support Enabled
DEBUG - 2011-06-21 11:58:14 --> URI Class Initialized
DEBUG - 2011-06-21 11:58:14 --> Router Class Initialized
DEBUG - 2011-06-21 11:58:14 --> Output Class Initialized
DEBUG - 2011-06-21 11:58:14 --> Input Class Initialized
DEBUG - 2011-06-21 11:58:14 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-21 11:58:14 --> Language Class Initialized
DEBUG - 2011-06-21 11:58:14 --> Loader Class Initialized
DEBUG - 2011-06-21 11:58:14 --> Controller Class Initialized
ERROR - 2011-06-21 11:58:14 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-21 11:58:14 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-21 11:58:14 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-21 11:58:14 --> Model Class Initialized
DEBUG - 2011-06-21 11:58:14 --> Model Class Initialized
DEBUG - 2011-06-21 11:58:14 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-21 11:58:14 --> Database Driver Class Initialized
DEBUG - 2011-06-21 11:58:14 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-21 11:58:14 --> Helper loaded: url_helper
DEBUG - 2011-06-21 11:58:14 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-21 11:58:14 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-21 11:58:14 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-21 11:58:14 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-21 11:58:14 --> Final output sent to browser
DEBUG - 2011-06-21 11:58:14 --> Total execution time: 0.0522
DEBUG - 2011-06-21 11:58:19 --> Config Class Initialized
DEBUG - 2011-06-21 11:58:19 --> Hooks Class Initialized
DEBUG - 2011-06-21 11:58:19 --> Utf8 Class Initialized
DEBUG - 2011-06-21 11:58:19 --> UTF-8 Support Enabled
DEBUG - 2011-06-21 11:58:19 --> URI Class Initialized
DEBUG - 2011-06-21 11:58:19 --> Router Class Initialized
DEBUG - 2011-06-21 11:58:19 --> Output Class Initialized
DEBUG - 2011-06-21 11:58:19 --> Input Class Initialized
DEBUG - 2011-06-21 11:58:19 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-21 11:58:19 --> Language Class Initialized
DEBUG - 2011-06-21 11:58:19 --> Loader Class Initialized
DEBUG - 2011-06-21 11:58:19 --> Controller Class Initialized
ERROR - 2011-06-21 11:58:19 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-21 11:58:19 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-21 11:58:19 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-21 11:58:19 --> Model Class Initialized
DEBUG - 2011-06-21 11:58:19 --> Model Class Initialized
DEBUG - 2011-06-21 11:58:19 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-21 11:58:19 --> Database Driver Class Initialized
DEBUG - 2011-06-21 11:58:19 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-21 11:58:19 --> Helper loaded: url_helper
DEBUG - 2011-06-21 11:58:19 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-21 11:58:19 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-21 11:58:19 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-21 11:58:19 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-21 11:58:19 --> Final output sent to browser
DEBUG - 2011-06-21 11:58:19 --> Total execution time: 0.0448
DEBUG - 2011-06-21 11:58:19 --> Config Class Initialized
DEBUG - 2011-06-21 11:58:19 --> Hooks Class Initialized
DEBUG - 2011-06-21 11:58:19 --> Utf8 Class Initialized
DEBUG - 2011-06-21 11:58:19 --> UTF-8 Support Enabled
DEBUG - 2011-06-21 11:58:19 --> URI Class Initialized
DEBUG - 2011-06-21 11:58:19 --> Router Class Initialized
DEBUG - 2011-06-21 11:58:19 --> Output Class Initialized
DEBUG - 2011-06-21 11:58:19 --> Input Class Initialized
DEBUG - 2011-06-21 11:58:19 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-21 11:58:19 --> Language Class Initialized
DEBUG - 2011-06-21 11:58:19 --> Loader Class Initialized
DEBUG - 2011-06-21 11:58:19 --> Controller Class Initialized
DEBUG - 2011-06-21 11:58:19 --> Model Class Initialized
DEBUG - 2011-06-21 11:58:19 --> Model Class Initialized
DEBUG - 2011-06-21 11:58:19 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-21 11:58:19 --> Database Driver Class Initialized
DEBUG - 2011-06-21 11:58:20 --> Final output sent to browser
DEBUG - 2011-06-21 11:58:20 --> Total execution time: 0.5391
DEBUG - 2011-06-21 11:58:23 --> Config Class Initialized
DEBUG - 2011-06-21 11:58:23 --> Hooks Class Initialized
DEBUG - 2011-06-21 11:58:23 --> Utf8 Class Initialized
DEBUG - 2011-06-21 11:58:23 --> UTF-8 Support Enabled
DEBUG - 2011-06-21 11:58:23 --> URI Class Initialized
DEBUG - 2011-06-21 11:58:23 --> Router Class Initialized
DEBUG - 2011-06-21 11:58:23 --> Output Class Initialized
DEBUG - 2011-06-21 11:58:23 --> Input Class Initialized
DEBUG - 2011-06-21 11:58:23 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-21 11:58:23 --> Language Class Initialized
DEBUG - 2011-06-21 11:58:23 --> Loader Class Initialized
DEBUG - 2011-06-21 11:58:23 --> Controller Class Initialized
ERROR - 2011-06-21 11:58:23 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-21 11:58:23 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-21 11:58:23 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-21 11:58:23 --> Model Class Initialized
DEBUG - 2011-06-21 11:58:23 --> Model Class Initialized
DEBUG - 2011-06-21 11:58:23 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-21 11:58:23 --> Database Driver Class Initialized
DEBUG - 2011-06-21 11:58:23 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-21 11:58:23 --> Helper loaded: url_helper
DEBUG - 2011-06-21 11:58:23 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-21 11:58:23 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-21 11:58:23 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-21 11:58:23 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-21 11:58:23 --> Final output sent to browser
DEBUG - 2011-06-21 11:58:23 --> Total execution time: 0.0283
DEBUG - 2011-06-21 11:58:24 --> Config Class Initialized
DEBUG - 2011-06-21 11:58:24 --> Hooks Class Initialized
DEBUG - 2011-06-21 11:58:24 --> Utf8 Class Initialized
DEBUG - 2011-06-21 11:58:24 --> UTF-8 Support Enabled
DEBUG - 2011-06-21 11:58:24 --> URI Class Initialized
DEBUG - 2011-06-21 11:58:24 --> Router Class Initialized
DEBUG - 2011-06-21 11:58:24 --> Output Class Initialized
DEBUG - 2011-06-21 11:58:24 --> Input Class Initialized
DEBUG - 2011-06-21 11:58:24 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-21 11:58:24 --> Language Class Initialized
DEBUG - 2011-06-21 11:58:24 --> Loader Class Initialized
DEBUG - 2011-06-21 11:58:24 --> Controller Class Initialized
DEBUG - 2011-06-21 11:58:24 --> Model Class Initialized
DEBUG - 2011-06-21 11:58:24 --> Model Class Initialized
DEBUG - 2011-06-21 11:58:24 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-21 11:58:24 --> Database Driver Class Initialized
DEBUG - 2011-06-21 11:58:24 --> Final output sent to browser
DEBUG - 2011-06-21 11:58:24 --> Total execution time: 0.5209
DEBUG - 2011-06-21 11:58:28 --> Config Class Initialized
DEBUG - 2011-06-21 11:58:28 --> Hooks Class Initialized
DEBUG - 2011-06-21 11:58:28 --> Utf8 Class Initialized
DEBUG - 2011-06-21 11:58:28 --> UTF-8 Support Enabled
DEBUG - 2011-06-21 11:58:28 --> URI Class Initialized
DEBUG - 2011-06-21 11:58:28 --> Router Class Initialized
DEBUG - 2011-06-21 11:58:28 --> Output Class Initialized
DEBUG - 2011-06-21 11:58:28 --> Input Class Initialized
DEBUG - 2011-06-21 11:58:28 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-21 11:58:28 --> Language Class Initialized
DEBUG - 2011-06-21 11:58:28 --> Loader Class Initialized
DEBUG - 2011-06-21 11:58:28 --> Controller Class Initialized
ERROR - 2011-06-21 11:58:28 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-21 11:58:28 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-21 11:58:28 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-21 11:58:28 --> Model Class Initialized
DEBUG - 2011-06-21 11:58:28 --> Model Class Initialized
DEBUG - 2011-06-21 11:58:28 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-21 11:58:28 --> Database Driver Class Initialized
DEBUG - 2011-06-21 11:58:28 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-21 11:58:28 --> Helper loaded: url_helper
DEBUG - 2011-06-21 11:58:28 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-21 11:58:28 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-21 11:58:28 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-21 11:58:28 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-21 11:58:28 --> Final output sent to browser
DEBUG - 2011-06-21 11:58:28 --> Total execution time: 0.0632
DEBUG - 2011-06-21 11:58:29 --> Config Class Initialized
DEBUG - 2011-06-21 11:58:29 --> Hooks Class Initialized
DEBUG - 2011-06-21 11:58:29 --> Utf8 Class Initialized
DEBUG - 2011-06-21 11:58:29 --> UTF-8 Support Enabled
DEBUG - 2011-06-21 11:58:29 --> URI Class Initialized
DEBUG - 2011-06-21 11:58:29 --> Router Class Initialized
DEBUG - 2011-06-21 11:58:29 --> Output Class Initialized
DEBUG - 2011-06-21 11:58:29 --> Input Class Initialized
DEBUG - 2011-06-21 11:58:29 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-21 11:58:29 --> Language Class Initialized
DEBUG - 2011-06-21 11:58:29 --> Loader Class Initialized
DEBUG - 2011-06-21 11:58:29 --> Controller Class Initialized
DEBUG - 2011-06-21 11:58:29 --> Model Class Initialized
DEBUG - 2011-06-21 11:58:29 --> Model Class Initialized
DEBUG - 2011-06-21 11:58:29 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-21 11:58:29 --> Database Driver Class Initialized
DEBUG - 2011-06-21 11:58:29 --> Final output sent to browser
DEBUG - 2011-06-21 11:58:29 --> Total execution time: 0.5276
DEBUG - 2011-06-21 11:58:34 --> Config Class Initialized
DEBUG - 2011-06-21 11:58:34 --> Hooks Class Initialized
DEBUG - 2011-06-21 11:58:34 --> Utf8 Class Initialized
DEBUG - 2011-06-21 11:58:34 --> UTF-8 Support Enabled
DEBUG - 2011-06-21 11:58:34 --> URI Class Initialized
DEBUG - 2011-06-21 11:58:34 --> Router Class Initialized
DEBUG - 2011-06-21 11:58:34 --> Output Class Initialized
DEBUG - 2011-06-21 11:58:34 --> Input Class Initialized
DEBUG - 2011-06-21 11:58:34 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-21 11:58:34 --> Language Class Initialized
DEBUG - 2011-06-21 11:58:34 --> Loader Class Initialized
DEBUG - 2011-06-21 11:58:34 --> Controller Class Initialized
ERROR - 2011-06-21 11:58:34 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-21 11:58:34 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-21 11:58:34 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-21 11:58:34 --> Model Class Initialized
DEBUG - 2011-06-21 11:58:34 --> Model Class Initialized
DEBUG - 2011-06-21 11:58:34 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-21 11:58:34 --> Database Driver Class Initialized
DEBUG - 2011-06-21 11:58:34 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-21 11:58:34 --> Helper loaded: url_helper
DEBUG - 2011-06-21 11:58:34 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-21 11:58:34 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-21 11:58:34 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-21 11:58:34 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-21 11:58:34 --> Final output sent to browser
DEBUG - 2011-06-21 11:58:34 --> Total execution time: 0.0282
DEBUG - 2011-06-21 11:58:35 --> Config Class Initialized
DEBUG - 2011-06-21 11:58:35 --> Hooks Class Initialized
DEBUG - 2011-06-21 11:58:35 --> Utf8 Class Initialized
DEBUG - 2011-06-21 11:58:35 --> UTF-8 Support Enabled
DEBUG - 2011-06-21 11:58:35 --> URI Class Initialized
DEBUG - 2011-06-21 11:58:35 --> Router Class Initialized
DEBUG - 2011-06-21 11:58:35 --> Output Class Initialized
DEBUG - 2011-06-21 11:58:35 --> Input Class Initialized
DEBUG - 2011-06-21 11:58:35 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-21 11:58:35 --> Language Class Initialized
DEBUG - 2011-06-21 11:58:35 --> Loader Class Initialized
DEBUG - 2011-06-21 11:58:35 --> Controller Class Initialized
ERROR - 2011-06-21 11:58:35 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-21 11:58:35 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-21 11:58:35 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-21 11:58:35 --> Model Class Initialized
DEBUG - 2011-06-21 11:58:35 --> Model Class Initialized
DEBUG - 2011-06-21 11:58:35 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-21 11:58:35 --> Database Driver Class Initialized
DEBUG - 2011-06-21 11:58:35 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-21 11:58:35 --> Helper loaded: url_helper
DEBUG - 2011-06-21 11:58:35 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-21 11:58:35 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-21 11:58:35 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-21 11:58:35 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-21 11:58:35 --> Final output sent to browser
DEBUG - 2011-06-21 11:58:35 --> Total execution time: 0.0273
DEBUG - 2011-06-21 11:58:36 --> Config Class Initialized
DEBUG - 2011-06-21 11:58:36 --> Hooks Class Initialized
DEBUG - 2011-06-21 11:58:36 --> Utf8 Class Initialized
DEBUG - 2011-06-21 11:58:36 --> UTF-8 Support Enabled
DEBUG - 2011-06-21 11:58:36 --> URI Class Initialized
DEBUG - 2011-06-21 11:58:36 --> Router Class Initialized
DEBUG - 2011-06-21 11:58:36 --> Output Class Initialized
DEBUG - 2011-06-21 11:58:36 --> Input Class Initialized
DEBUG - 2011-06-21 11:58:36 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-21 11:58:36 --> Language Class Initialized
DEBUG - 2011-06-21 11:58:36 --> Loader Class Initialized
DEBUG - 2011-06-21 11:58:36 --> Controller Class Initialized
DEBUG - 2011-06-21 11:58:36 --> Model Class Initialized
DEBUG - 2011-06-21 11:58:36 --> Model Class Initialized
DEBUG - 2011-06-21 11:58:36 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-21 11:58:36 --> Database Driver Class Initialized
DEBUG - 2011-06-21 11:58:37 --> Final output sent to browser
DEBUG - 2011-06-21 11:58:37 --> Total execution time: 0.5501
DEBUG - 2011-06-21 11:58:43 --> Config Class Initialized
DEBUG - 2011-06-21 11:58:43 --> Hooks Class Initialized
DEBUG - 2011-06-21 11:58:43 --> Utf8 Class Initialized
DEBUG - 2011-06-21 11:58:43 --> UTF-8 Support Enabled
DEBUG - 2011-06-21 11:58:43 --> URI Class Initialized
DEBUG - 2011-06-21 11:58:43 --> Router Class Initialized
DEBUG - 2011-06-21 11:58:43 --> Output Class Initialized
DEBUG - 2011-06-21 11:58:43 --> Input Class Initialized
DEBUG - 2011-06-21 11:58:43 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-21 11:58:43 --> Language Class Initialized
DEBUG - 2011-06-21 11:58:43 --> Loader Class Initialized
DEBUG - 2011-06-21 11:58:43 --> Controller Class Initialized
ERROR - 2011-06-21 11:58:43 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-21 11:58:43 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-21 11:58:43 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-21 11:58:43 --> Model Class Initialized
DEBUG - 2011-06-21 11:58:43 --> Model Class Initialized
DEBUG - 2011-06-21 11:58:43 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-21 11:58:43 --> Database Driver Class Initialized
DEBUG - 2011-06-21 11:58:43 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-21 11:58:43 --> Helper loaded: url_helper
DEBUG - 2011-06-21 11:58:43 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-21 11:58:43 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-21 11:58:43 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-21 11:58:43 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-21 11:58:43 --> Final output sent to browser
DEBUG - 2011-06-21 11:58:43 --> Total execution time: 0.0335
DEBUG - 2011-06-21 11:58:43 --> Config Class Initialized
DEBUG - 2011-06-21 11:58:43 --> Hooks Class Initialized
DEBUG - 2011-06-21 11:58:43 --> Utf8 Class Initialized
DEBUG - 2011-06-21 11:58:43 --> UTF-8 Support Enabled
DEBUG - 2011-06-21 11:58:43 --> URI Class Initialized
DEBUG - 2011-06-21 11:58:43 --> Router Class Initialized
DEBUG - 2011-06-21 11:58:43 --> Config Class Initialized
DEBUG - 2011-06-21 11:58:43 --> Hooks Class Initialized
DEBUG - 2011-06-21 11:58:43 --> Utf8 Class Initialized
DEBUG - 2011-06-21 11:58:43 --> UTF-8 Support Enabled
DEBUG - 2011-06-21 11:58:43 --> Output Class Initialized
DEBUG - 2011-06-21 11:58:43 --> URI Class Initialized
DEBUG - 2011-06-21 11:58:43 --> Input Class Initialized
DEBUG - 2011-06-21 11:58:43 --> Router Class Initialized
DEBUG - 2011-06-21 11:58:43 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-21 11:58:43 --> Language Class Initialized
DEBUG - 2011-06-21 11:58:43 --> Output Class Initialized
DEBUG - 2011-06-21 11:58:43 --> Input Class Initialized
DEBUG - 2011-06-21 11:58:43 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-21 11:58:43 --> Loader Class Initialized
DEBUG - 2011-06-21 11:58:43 --> Language Class Initialized
DEBUG - 2011-06-21 11:58:43 --> Controller Class Initialized
DEBUG - 2011-06-21 11:58:43 --> Model Class Initialized
DEBUG - 2011-06-21 11:58:43 --> Model Class Initialized
DEBUG - 2011-06-21 11:58:43 --> Loader Class Initialized
DEBUG - 2011-06-21 11:58:43 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-21 11:58:43 --> Controller Class Initialized
ERROR - 2011-06-21 11:58:43 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-21 11:58:43 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-21 11:58:43 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-21 11:58:43 --> Model Class Initialized
DEBUG - 2011-06-21 11:58:43 --> Model Class Initialized
DEBUG - 2011-06-21 11:58:43 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-21 11:58:43 --> Database Driver Class Initialized
DEBUG - 2011-06-21 11:58:43 --> Database Driver Class Initialized
DEBUG - 2011-06-21 11:58:43 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-21 11:58:43 --> Helper loaded: url_helper
DEBUG - 2011-06-21 11:58:43 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-21 11:58:43 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-21 11:58:43 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-21 11:58:43 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-21 11:58:43 --> Final output sent to browser
DEBUG - 2011-06-21 11:58:43 --> Total execution time: 0.0305
DEBUG - 2011-06-21 11:58:44 --> Final output sent to browser
DEBUG - 2011-06-21 11:58:44 --> Total execution time: 0.5614
DEBUG - 2011-06-21 11:58:53 --> Config Class Initialized
DEBUG - 2011-06-21 11:58:53 --> Hooks Class Initialized
DEBUG - 2011-06-21 11:58:53 --> Utf8 Class Initialized
DEBUG - 2011-06-21 11:58:53 --> UTF-8 Support Enabled
DEBUG - 2011-06-21 11:58:53 --> URI Class Initialized
DEBUG - 2011-06-21 11:58:53 --> Router Class Initialized
DEBUG - 2011-06-21 11:58:53 --> Output Class Initialized
DEBUG - 2011-06-21 11:58:53 --> Input Class Initialized
DEBUG - 2011-06-21 11:58:53 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-21 11:58:53 --> Language Class Initialized
DEBUG - 2011-06-21 11:58:53 --> Loader Class Initialized
DEBUG - 2011-06-21 11:58:53 --> Controller Class Initialized
ERROR - 2011-06-21 11:58:53 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-21 11:58:53 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-21 11:58:53 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-21 11:58:53 --> Model Class Initialized
DEBUG - 2011-06-21 11:58:53 --> Model Class Initialized
DEBUG - 2011-06-21 11:58:53 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-21 11:58:53 --> Database Driver Class Initialized
DEBUG - 2011-06-21 11:58:53 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-21 11:58:53 --> Helper loaded: url_helper
DEBUG - 2011-06-21 11:58:53 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-21 11:58:53 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-21 11:58:53 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-21 11:58:53 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-21 11:58:53 --> Final output sent to browser
DEBUG - 2011-06-21 11:58:53 --> Total execution time: 0.0609
DEBUG - 2011-06-21 11:58:53 --> Config Class Initialized
DEBUG - 2011-06-21 11:58:53 --> Hooks Class Initialized
DEBUG - 2011-06-21 11:58:53 --> Utf8 Class Initialized
DEBUG - 2011-06-21 11:58:53 --> UTF-8 Support Enabled
DEBUG - 2011-06-21 11:58:53 --> URI Class Initialized
DEBUG - 2011-06-21 11:58:53 --> Router Class Initialized
DEBUG - 2011-06-21 11:58:53 --> Output Class Initialized
DEBUG - 2011-06-21 11:58:53 --> Input Class Initialized
DEBUG - 2011-06-21 11:58:53 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-21 11:58:53 --> Language Class Initialized
DEBUG - 2011-06-21 11:58:53 --> Loader Class Initialized
DEBUG - 2011-06-21 11:58:53 --> Controller Class Initialized
DEBUG - 2011-06-21 11:58:53 --> Model Class Initialized
DEBUG - 2011-06-21 11:58:53 --> Model Class Initialized
DEBUG - 2011-06-21 11:58:53 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-21 11:58:53 --> Database Driver Class Initialized
DEBUG - 2011-06-21 11:58:54 --> Final output sent to browser
DEBUG - 2011-06-21 11:58:54 --> Total execution time: 0.7581
DEBUG - 2011-06-21 11:58:59 --> Config Class Initialized
DEBUG - 2011-06-21 11:58:59 --> Hooks Class Initialized
DEBUG - 2011-06-21 11:58:59 --> Utf8 Class Initialized
DEBUG - 2011-06-21 11:58:59 --> UTF-8 Support Enabled
DEBUG - 2011-06-21 11:58:59 --> URI Class Initialized
DEBUG - 2011-06-21 11:58:59 --> Router Class Initialized
DEBUG - 2011-06-21 11:58:59 --> Output Class Initialized
DEBUG - 2011-06-21 11:58:59 --> Input Class Initialized
DEBUG - 2011-06-21 11:58:59 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-21 11:58:59 --> Language Class Initialized
DEBUG - 2011-06-21 11:58:59 --> Loader Class Initialized
DEBUG - 2011-06-21 11:58:59 --> Controller Class Initialized
ERROR - 2011-06-21 11:58:59 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-21 11:58:59 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-21 11:58:59 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-21 11:58:59 --> Model Class Initialized
DEBUG - 2011-06-21 11:58:59 --> Model Class Initialized
DEBUG - 2011-06-21 11:58:59 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-21 11:58:59 --> Database Driver Class Initialized
DEBUG - 2011-06-21 11:58:59 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-21 11:58:59 --> Helper loaded: url_helper
DEBUG - 2011-06-21 11:58:59 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-21 11:58:59 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-21 11:58:59 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-21 11:58:59 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-21 11:58:59 --> Final output sent to browser
DEBUG - 2011-06-21 11:58:59 --> Total execution time: 0.0312
DEBUG - 2011-06-21 11:59:03 --> Config Class Initialized
DEBUG - 2011-06-21 11:59:03 --> Hooks Class Initialized
DEBUG - 2011-06-21 11:59:03 --> Utf8 Class Initialized
DEBUG - 2011-06-21 11:59:03 --> UTF-8 Support Enabled
DEBUG - 2011-06-21 11:59:03 --> URI Class Initialized
DEBUG - 2011-06-21 11:59:03 --> Router Class Initialized
DEBUG - 2011-06-21 11:59:03 --> Output Class Initialized
DEBUG - 2011-06-21 11:59:03 --> Input Class Initialized
DEBUG - 2011-06-21 11:59:03 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-21 11:59:03 --> Language Class Initialized
DEBUG - 2011-06-21 11:59:03 --> Loader Class Initialized
DEBUG - 2011-06-21 11:59:03 --> Controller Class Initialized
ERROR - 2011-06-21 11:59:03 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-21 11:59:03 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-21 11:59:03 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-21 11:59:03 --> Model Class Initialized
DEBUG - 2011-06-21 11:59:03 --> Model Class Initialized
DEBUG - 2011-06-21 11:59:03 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-21 11:59:03 --> Database Driver Class Initialized
DEBUG - 2011-06-21 11:59:03 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-21 11:59:03 --> Helper loaded: url_helper
DEBUG - 2011-06-21 11:59:03 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-21 11:59:03 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-21 11:59:03 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-21 11:59:03 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-21 11:59:03 --> Final output sent to browser
DEBUG - 2011-06-21 11:59:03 --> Total execution time: 0.0349
DEBUG - 2011-06-21 11:59:04 --> Config Class Initialized
DEBUG - 2011-06-21 11:59:04 --> Hooks Class Initialized
DEBUG - 2011-06-21 11:59:04 --> Utf8 Class Initialized
DEBUG - 2011-06-21 11:59:04 --> UTF-8 Support Enabled
DEBUG - 2011-06-21 11:59:04 --> URI Class Initialized
DEBUG - 2011-06-21 11:59:04 --> Router Class Initialized
DEBUG - 2011-06-21 11:59:04 --> Output Class Initialized
DEBUG - 2011-06-21 11:59:04 --> Input Class Initialized
DEBUG - 2011-06-21 11:59:04 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-21 11:59:04 --> Language Class Initialized
DEBUG - 2011-06-21 11:59:04 --> Loader Class Initialized
DEBUG - 2011-06-21 11:59:04 --> Controller Class Initialized
ERROR - 2011-06-21 11:59:04 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-21 11:59:04 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-21 11:59:04 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-21 11:59:04 --> Model Class Initialized
DEBUG - 2011-06-21 11:59:04 --> Model Class Initialized
DEBUG - 2011-06-21 11:59:04 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-21 11:59:04 --> Database Driver Class Initialized
DEBUG - 2011-06-21 11:59:04 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-21 11:59:04 --> Helper loaded: url_helper
DEBUG - 2011-06-21 11:59:04 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-21 11:59:04 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-21 11:59:04 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-21 11:59:04 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-21 11:59:04 --> Final output sent to browser
DEBUG - 2011-06-21 11:59:04 --> Total execution time: 0.0282
DEBUG - 2011-06-21 11:59:05 --> Config Class Initialized
DEBUG - 2011-06-21 11:59:05 --> Hooks Class Initialized
DEBUG - 2011-06-21 11:59:05 --> Utf8 Class Initialized
DEBUG - 2011-06-21 11:59:05 --> UTF-8 Support Enabled
DEBUG - 2011-06-21 11:59:05 --> URI Class Initialized
DEBUG - 2011-06-21 11:59:05 --> Router Class Initialized
DEBUG - 2011-06-21 11:59:05 --> Output Class Initialized
DEBUG - 2011-06-21 11:59:05 --> Input Class Initialized
DEBUG - 2011-06-21 11:59:05 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-21 11:59:05 --> Language Class Initialized
DEBUG - 2011-06-21 11:59:05 --> Loader Class Initialized
DEBUG - 2011-06-21 11:59:05 --> Controller Class Initialized
ERROR - 2011-06-21 11:59:05 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-21 11:59:05 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-21 11:59:05 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-21 11:59:05 --> Model Class Initialized
DEBUG - 2011-06-21 11:59:05 --> Model Class Initialized
DEBUG - 2011-06-21 11:59:05 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-21 11:59:05 --> Database Driver Class Initialized
DEBUG - 2011-06-21 11:59:05 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-21 11:59:05 --> Helper loaded: url_helper
DEBUG - 2011-06-21 11:59:05 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-21 11:59:05 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-21 11:59:05 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-21 11:59:05 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-21 11:59:05 --> Final output sent to browser
DEBUG - 2011-06-21 11:59:05 --> Total execution time: 0.0331
DEBUG - 2011-06-21 11:59:05 --> Config Class Initialized
DEBUG - 2011-06-21 11:59:05 --> Hooks Class Initialized
DEBUG - 2011-06-21 11:59:05 --> Utf8 Class Initialized
DEBUG - 2011-06-21 11:59:05 --> UTF-8 Support Enabled
DEBUG - 2011-06-21 11:59:05 --> URI Class Initialized
DEBUG - 2011-06-21 11:59:05 --> Router Class Initialized
DEBUG - 2011-06-21 11:59:05 --> Output Class Initialized
DEBUG - 2011-06-21 11:59:05 --> Input Class Initialized
DEBUG - 2011-06-21 11:59:05 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-21 11:59:05 --> Language Class Initialized
DEBUG - 2011-06-21 11:59:05 --> Loader Class Initialized
DEBUG - 2011-06-21 11:59:05 --> Controller Class Initialized
DEBUG - 2011-06-21 11:59:05 --> Model Class Initialized
DEBUG - 2011-06-21 11:59:05 --> Model Class Initialized
DEBUG - 2011-06-21 11:59:05 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-21 11:59:05 --> Database Driver Class Initialized
DEBUG - 2011-06-21 11:59:05 --> Config Class Initialized
DEBUG - 2011-06-21 11:59:05 --> Hooks Class Initialized
DEBUG - 2011-06-21 11:59:05 --> Utf8 Class Initialized
DEBUG - 2011-06-21 11:59:05 --> UTF-8 Support Enabled
DEBUG - 2011-06-21 11:59:05 --> URI Class Initialized
DEBUG - 2011-06-21 11:59:05 --> Router Class Initialized
DEBUG - 2011-06-21 11:59:05 --> Output Class Initialized
DEBUG - 2011-06-21 11:59:05 --> Input Class Initialized
DEBUG - 2011-06-21 11:59:05 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-21 11:59:05 --> Language Class Initialized
DEBUG - 2011-06-21 11:59:05 --> Loader Class Initialized
DEBUG - 2011-06-21 11:59:05 --> Controller Class Initialized
ERROR - 2011-06-21 11:59:05 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-21 11:59:05 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-21 11:59:05 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-21 11:59:05 --> Model Class Initialized
DEBUG - 2011-06-21 11:59:05 --> Model Class Initialized
DEBUG - 2011-06-21 11:59:05 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-21 11:59:05 --> Database Driver Class Initialized
DEBUG - 2011-06-21 11:59:05 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-21 11:59:05 --> Helper loaded: url_helper
DEBUG - 2011-06-21 11:59:05 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-21 11:59:05 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-21 11:59:05 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-21 11:59:05 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-21 11:59:05 --> Final output sent to browser
DEBUG - 2011-06-21 11:59:05 --> Total execution time: 0.0281
DEBUG - 2011-06-21 11:59:05 --> Final output sent to browser
DEBUG - 2011-06-21 11:59:05 --> Total execution time: 0.5632
DEBUG - 2011-06-21 11:59:11 --> Config Class Initialized
DEBUG - 2011-06-21 11:59:11 --> Hooks Class Initialized
DEBUG - 2011-06-21 11:59:11 --> Utf8 Class Initialized
DEBUG - 2011-06-21 11:59:11 --> UTF-8 Support Enabled
DEBUG - 2011-06-21 11:59:11 --> URI Class Initialized
DEBUG - 2011-06-21 11:59:11 --> Router Class Initialized
DEBUG - 2011-06-21 11:59:11 --> Output Class Initialized
DEBUG - 2011-06-21 11:59:11 --> Input Class Initialized
DEBUG - 2011-06-21 11:59:11 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-21 11:59:11 --> Language Class Initialized
DEBUG - 2011-06-21 11:59:11 --> Loader Class Initialized
DEBUG - 2011-06-21 11:59:11 --> Controller Class Initialized
ERROR - 2011-06-21 11:59:11 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-21 11:59:11 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-21 11:59:11 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-21 11:59:11 --> Model Class Initialized
DEBUG - 2011-06-21 11:59:11 --> Model Class Initialized
DEBUG - 2011-06-21 11:59:11 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-21 11:59:11 --> Database Driver Class Initialized
DEBUG - 2011-06-21 11:59:11 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-21 11:59:11 --> Helper loaded: url_helper
DEBUG - 2011-06-21 11:59:11 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-21 11:59:11 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-21 11:59:11 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-21 11:59:11 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-21 11:59:11 --> Final output sent to browser
DEBUG - 2011-06-21 11:59:11 --> Total execution time: 0.0284
DEBUG - 2011-06-21 11:59:11 --> Config Class Initialized
DEBUG - 2011-06-21 11:59:11 --> Hooks Class Initialized
DEBUG - 2011-06-21 11:59:11 --> Utf8 Class Initialized
DEBUG - 2011-06-21 11:59:11 --> UTF-8 Support Enabled
DEBUG - 2011-06-21 11:59:11 --> URI Class Initialized
DEBUG - 2011-06-21 11:59:11 --> Router Class Initialized
DEBUG - 2011-06-21 11:59:12 --> Output Class Initialized
DEBUG - 2011-06-21 11:59:12 --> Input Class Initialized
DEBUG - 2011-06-21 11:59:12 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-21 11:59:12 --> Language Class Initialized
DEBUG - 2011-06-21 11:59:12 --> Loader Class Initialized
DEBUG - 2011-06-21 11:59:12 --> Controller Class Initialized
DEBUG - 2011-06-21 11:59:12 --> Model Class Initialized
DEBUG - 2011-06-21 11:59:12 --> Model Class Initialized
DEBUG - 2011-06-21 11:59:12 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-21 11:59:12 --> Database Driver Class Initialized
DEBUG - 2011-06-21 11:59:12 --> Final output sent to browser
DEBUG - 2011-06-21 11:59:12 --> Total execution time: 0.5915
DEBUG - 2011-06-21 11:59:12 --> Config Class Initialized
DEBUG - 2011-06-21 11:59:12 --> Hooks Class Initialized
DEBUG - 2011-06-21 11:59:12 --> Utf8 Class Initialized
DEBUG - 2011-06-21 11:59:12 --> UTF-8 Support Enabled
DEBUG - 2011-06-21 11:59:12 --> URI Class Initialized
DEBUG - 2011-06-21 11:59:12 --> Router Class Initialized
DEBUG - 2011-06-21 11:59:12 --> Output Class Initialized
DEBUG - 2011-06-21 11:59:12 --> Input Class Initialized
DEBUG - 2011-06-21 11:59:12 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-21 11:59:12 --> Language Class Initialized
DEBUG - 2011-06-21 11:59:12 --> Loader Class Initialized
DEBUG - 2011-06-21 11:59:12 --> Controller Class Initialized
ERROR - 2011-06-21 11:59:12 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-21 11:59:12 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-21 11:59:12 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-21 11:59:12 --> Model Class Initialized
DEBUG - 2011-06-21 11:59:12 --> Model Class Initialized
DEBUG - 2011-06-21 11:59:12 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-21 11:59:12 --> Database Driver Class Initialized
DEBUG - 2011-06-21 11:59:12 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-21 11:59:12 --> Helper loaded: url_helper
DEBUG - 2011-06-21 11:59:12 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-21 11:59:12 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-21 11:59:12 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-21 11:59:12 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-21 11:59:12 --> Final output sent to browser
DEBUG - 2011-06-21 11:59:12 --> Total execution time: 0.0277
DEBUG - 2011-06-21 11:59:15 --> Config Class Initialized
DEBUG - 2011-06-21 11:59:15 --> Hooks Class Initialized
DEBUG - 2011-06-21 11:59:15 --> Utf8 Class Initialized
DEBUG - 2011-06-21 11:59:15 --> UTF-8 Support Enabled
DEBUG - 2011-06-21 11:59:15 --> URI Class Initialized
DEBUG - 2011-06-21 11:59:15 --> Router Class Initialized
DEBUG - 2011-06-21 11:59:15 --> Output Class Initialized
DEBUG - 2011-06-21 11:59:15 --> Input Class Initialized
DEBUG - 2011-06-21 11:59:15 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-21 11:59:15 --> Language Class Initialized
DEBUG - 2011-06-21 11:59:15 --> Loader Class Initialized
DEBUG - 2011-06-21 11:59:15 --> Controller Class Initialized
ERROR - 2011-06-21 11:59:15 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-21 11:59:15 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-21 11:59:15 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-21 11:59:15 --> Model Class Initialized
DEBUG - 2011-06-21 11:59:15 --> Model Class Initialized
DEBUG - 2011-06-21 11:59:15 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-21 11:59:15 --> Database Driver Class Initialized
DEBUG - 2011-06-21 11:59:15 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-21 11:59:15 --> Helper loaded: url_helper
DEBUG - 2011-06-21 11:59:15 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-21 11:59:15 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-21 11:59:15 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-21 11:59:15 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-21 11:59:15 --> Final output sent to browser
DEBUG - 2011-06-21 11:59:15 --> Total execution time: 0.0283
DEBUG - 2011-06-21 11:59:16 --> Config Class Initialized
DEBUG - 2011-06-21 11:59:16 --> Hooks Class Initialized
DEBUG - 2011-06-21 11:59:16 --> Utf8 Class Initialized
DEBUG - 2011-06-21 11:59:16 --> UTF-8 Support Enabled
DEBUG - 2011-06-21 11:59:16 --> URI Class Initialized
DEBUG - 2011-06-21 11:59:16 --> Router Class Initialized
DEBUG - 2011-06-21 11:59:16 --> Output Class Initialized
DEBUG - 2011-06-21 11:59:16 --> Input Class Initialized
DEBUG - 2011-06-21 11:59:16 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-21 11:59:16 --> Language Class Initialized
DEBUG - 2011-06-21 11:59:16 --> Loader Class Initialized
DEBUG - 2011-06-21 11:59:16 --> Controller Class Initialized
ERROR - 2011-06-21 11:59:16 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-21 11:59:16 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-21 11:59:16 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-21 11:59:16 --> Model Class Initialized
DEBUG - 2011-06-21 11:59:16 --> Model Class Initialized
DEBUG - 2011-06-21 11:59:16 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-21 11:59:16 --> Database Driver Class Initialized
DEBUG - 2011-06-21 11:59:16 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-21 11:59:16 --> Helper loaded: url_helper
DEBUG - 2011-06-21 11:59:16 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-21 11:59:16 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-21 11:59:16 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-21 11:59:16 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-21 11:59:16 --> Final output sent to browser
DEBUG - 2011-06-21 11:59:16 --> Total execution time: 0.0575
DEBUG - 2011-06-21 11:59:16 --> Config Class Initialized
DEBUG - 2011-06-21 11:59:16 --> Hooks Class Initialized
DEBUG - 2011-06-21 11:59:16 --> Utf8 Class Initialized
DEBUG - 2011-06-21 11:59:16 --> UTF-8 Support Enabled
DEBUG - 2011-06-21 11:59:16 --> URI Class Initialized
DEBUG - 2011-06-21 11:59:16 --> Router Class Initialized
DEBUG - 2011-06-21 11:59:16 --> Output Class Initialized
DEBUG - 2011-06-21 11:59:16 --> Input Class Initialized
DEBUG - 2011-06-21 11:59:16 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-21 11:59:16 --> Language Class Initialized
DEBUG - 2011-06-21 11:59:16 --> Loader Class Initialized
DEBUG - 2011-06-21 11:59:16 --> Controller Class Initialized
DEBUG - 2011-06-21 11:59:16 --> Model Class Initialized
DEBUG - 2011-06-21 11:59:16 --> Model Class Initialized
DEBUG - 2011-06-21 11:59:16 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-21 11:59:16 --> Database Driver Class Initialized
DEBUG - 2011-06-21 11:59:17 --> Final output sent to browser
DEBUG - 2011-06-21 11:59:17 --> Total execution time: 0.8112
DEBUG - 2011-06-21 11:59:20 --> Config Class Initialized
DEBUG - 2011-06-21 11:59:20 --> Hooks Class Initialized
DEBUG - 2011-06-21 11:59:20 --> Utf8 Class Initialized
DEBUG - 2011-06-21 11:59:20 --> UTF-8 Support Enabled
DEBUG - 2011-06-21 11:59:20 --> URI Class Initialized
DEBUG - 2011-06-21 11:59:20 --> Router Class Initialized
DEBUG - 2011-06-21 11:59:20 --> Output Class Initialized
DEBUG - 2011-06-21 11:59:20 --> Input Class Initialized
DEBUG - 2011-06-21 11:59:20 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-21 11:59:20 --> Language Class Initialized
DEBUG - 2011-06-21 11:59:20 --> Loader Class Initialized
DEBUG - 2011-06-21 11:59:20 --> Controller Class Initialized
ERROR - 2011-06-21 11:59:20 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-21 11:59:20 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-21 11:59:20 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-21 11:59:20 --> Model Class Initialized
DEBUG - 2011-06-21 11:59:20 --> Model Class Initialized
DEBUG - 2011-06-21 11:59:20 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-21 11:59:20 --> Database Driver Class Initialized
DEBUG - 2011-06-21 11:59:20 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-21 11:59:20 --> Helper loaded: url_helper
DEBUG - 2011-06-21 11:59:20 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-21 11:59:20 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-21 11:59:20 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-21 11:59:20 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-21 11:59:20 --> Final output sent to browser
DEBUG - 2011-06-21 11:59:20 --> Total execution time: 0.0315
DEBUG - 2011-06-21 11:59:20 --> Config Class Initialized
DEBUG - 2011-06-21 11:59:20 --> Hooks Class Initialized
DEBUG - 2011-06-21 11:59:20 --> Utf8 Class Initialized
DEBUG - 2011-06-21 11:59:20 --> UTF-8 Support Enabled
DEBUG - 2011-06-21 11:59:20 --> URI Class Initialized
DEBUG - 2011-06-21 11:59:20 --> Router Class Initialized
DEBUG - 2011-06-21 11:59:20 --> Output Class Initialized
DEBUG - 2011-06-21 11:59:20 --> Input Class Initialized
DEBUG - 2011-06-21 11:59:20 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-21 11:59:20 --> Language Class Initialized
DEBUG - 2011-06-21 11:59:20 --> Loader Class Initialized
DEBUG - 2011-06-21 11:59:20 --> Controller Class Initialized
DEBUG - 2011-06-21 11:59:20 --> Model Class Initialized
DEBUG - 2011-06-21 11:59:20 --> Model Class Initialized
DEBUG - 2011-06-21 11:59:20 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-21 11:59:20 --> Database Driver Class Initialized
DEBUG - 2011-06-21 11:59:20 --> Config Class Initialized
DEBUG - 2011-06-21 11:59:20 --> Hooks Class Initialized
DEBUG - 2011-06-21 11:59:20 --> Utf8 Class Initialized
DEBUG - 2011-06-21 11:59:20 --> UTF-8 Support Enabled
DEBUG - 2011-06-21 11:59:20 --> URI Class Initialized
DEBUG - 2011-06-21 11:59:20 --> Router Class Initialized
DEBUG - 2011-06-21 11:59:20 --> Output Class Initialized
DEBUG - 2011-06-21 11:59:20 --> Input Class Initialized
DEBUG - 2011-06-21 11:59:20 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-21 11:59:20 --> Language Class Initialized
DEBUG - 2011-06-21 11:59:20 --> Loader Class Initialized
DEBUG - 2011-06-21 11:59:20 --> Controller Class Initialized
ERROR - 2011-06-21 11:59:20 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-21 11:59:20 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-21 11:59:20 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-21 11:59:20 --> Model Class Initialized
DEBUG - 2011-06-21 11:59:20 --> Model Class Initialized
DEBUG - 2011-06-21 11:59:20 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-21 11:59:20 --> Database Driver Class Initialized
DEBUG - 2011-06-21 11:59:20 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-21 11:59:20 --> Helper loaded: url_helper
DEBUG - 2011-06-21 11:59:20 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-21 11:59:20 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-21 11:59:20 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-21 11:59:20 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-21 11:59:20 --> Final output sent to browser
DEBUG - 2011-06-21 11:59:20 --> Total execution time: 0.0304
DEBUG - 2011-06-21 11:59:21 --> Final output sent to browser
DEBUG - 2011-06-21 11:59:21 --> Total execution time: 0.5535
DEBUG - 2011-06-21 14:26:52 --> Config Class Initialized
DEBUG - 2011-06-21 14:26:52 --> Config Class Initialized
DEBUG - 2011-06-21 14:26:53 --> Hooks Class Initialized
DEBUG - 2011-06-21 14:26:53 --> Hooks Class Initialized
DEBUG - 2011-06-21 14:26:53 --> Utf8 Class Initialized
DEBUG - 2011-06-21 14:26:53 --> Utf8 Class Initialized
DEBUG - 2011-06-21 14:26:53 --> UTF-8 Support Enabled
DEBUG - 2011-06-21 14:26:53 --> UTF-8 Support Enabled
DEBUG - 2011-06-21 14:26:53 --> URI Class Initialized
DEBUG - 2011-06-21 14:26:53 --> URI Class Initialized
DEBUG - 2011-06-21 14:26:53 --> Router Class Initialized
DEBUG - 2011-06-21 14:26:53 --> Router Class Initialized
DEBUG - 2011-06-21 14:26:54 --> Output Class Initialized
DEBUG - 2011-06-21 14:26:54 --> Output Class Initialized
DEBUG - 2011-06-21 14:26:54 --> Input Class Initialized
DEBUG - 2011-06-21 14:26:54 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-21 14:26:54 --> Input Class Initialized
DEBUG - 2011-06-21 14:26:54 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-21 14:26:55 --> Language Class Initialized
DEBUG - 2011-06-21 14:26:55 --> Language Class Initialized
DEBUG - 2011-06-21 14:26:55 --> Loader Class Initialized
DEBUG - 2011-06-21 14:26:55 --> Loader Class Initialized
DEBUG - 2011-06-21 14:26:55 --> Controller Class Initialized
DEBUG - 2011-06-21 14:26:55 --> Controller Class Initialized
DEBUG - 2011-06-21 14:26:56 --> Model Class Initialized
DEBUG - 2011-06-21 14:26:56 --> Model Class Initialized
DEBUG - 2011-06-21 14:26:56 --> Model Class Initialized
DEBUG - 2011-06-21 14:26:56 --> Model Class Initialized
DEBUG - 2011-06-21 14:26:56 --> Model Class Initialized
DEBUG - 2011-06-21 14:26:56 --> Model Class Initialized
DEBUG - 2011-06-21 14:26:56 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-21 14:26:56 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-21 14:26:56 --> Database Driver Class Initialized
DEBUG - 2011-06-21 14:26:56 --> Database Driver Class Initialized
DEBUG - 2011-06-21 14:27:02 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-21 14:27:02 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-21 14:27:02 --> Helper loaded: url_helper
DEBUG - 2011-06-21 14:27:02 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-21 14:27:02 --> Helper loaded: url_helper
DEBUG - 2011-06-21 14:27:02 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-21 14:27:02 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-21 14:27:02 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-21 14:27:02 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-21 14:27:02 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-21 14:27:02 --> Final output sent to browser
DEBUG - 2011-06-21 14:27:02 --> Total execution time: 10.6506
DEBUG - 2011-06-21 14:27:02 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-21 14:27:02 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-21 14:27:02 --> Final output sent to browser
DEBUG - 2011-06-21 14:27:02 --> Total execution time: 10.6531
DEBUG - 2011-06-21 14:27:19 --> Config Class Initialized
DEBUG - 2011-06-21 14:27:19 --> Hooks Class Initialized
DEBUG - 2011-06-21 14:27:19 --> Utf8 Class Initialized
DEBUG - 2011-06-21 14:27:19 --> UTF-8 Support Enabled
DEBUG - 2011-06-21 14:27:19 --> URI Class Initialized
DEBUG - 2011-06-21 14:27:19 --> Router Class Initialized
DEBUG - 2011-06-21 14:27:19 --> Output Class Initialized
DEBUG - 2011-06-21 14:27:19 --> Input Class Initialized
DEBUG - 2011-06-21 14:27:19 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-21 14:27:19 --> Language Class Initialized
DEBUG - 2011-06-21 14:27:19 --> Loader Class Initialized
DEBUG - 2011-06-21 14:27:19 --> Controller Class Initialized
DEBUG - 2011-06-21 14:27:19 --> Model Class Initialized
DEBUG - 2011-06-21 14:27:19 --> Model Class Initialized
DEBUG - 2011-06-21 14:27:19 --> Model Class Initialized
DEBUG - 2011-06-21 14:27:19 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-21 14:27:19 --> Database Driver Class Initialized
DEBUG - 2011-06-21 14:27:19 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-21 14:27:19 --> Helper loaded: url_helper
DEBUG - 2011-06-21 14:27:19 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-21 14:27:19 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-21 14:27:19 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-21 14:27:19 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-21 14:27:19 --> Final output sent to browser
DEBUG - 2011-06-21 14:27:19 --> Total execution time: 0.0463
DEBUG - 2011-06-21 15:01:33 --> Config Class Initialized
DEBUG - 2011-06-21 15:01:33 --> Hooks Class Initialized
DEBUG - 2011-06-21 15:01:33 --> Utf8 Class Initialized
DEBUG - 2011-06-21 15:01:33 --> UTF-8 Support Enabled
DEBUG - 2011-06-21 15:01:33 --> URI Class Initialized
DEBUG - 2011-06-21 15:01:33 --> Router Class Initialized
DEBUG - 2011-06-21 15:01:33 --> Output Class Initialized
DEBUG - 2011-06-21 15:01:33 --> Input Class Initialized
DEBUG - 2011-06-21 15:01:33 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-21 15:01:33 --> Language Class Initialized
DEBUG - 2011-06-21 15:01:34 --> Loader Class Initialized
DEBUG - 2011-06-21 15:01:34 --> Controller Class Initialized
DEBUG - 2011-06-21 15:01:34 --> Model Class Initialized
DEBUG - 2011-06-21 15:01:34 --> Model Class Initialized
DEBUG - 2011-06-21 15:01:34 --> Model Class Initialized
DEBUG - 2011-06-21 15:01:34 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-21 15:01:34 --> Database Driver Class Initialized
DEBUG - 2011-06-21 15:01:34 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-21 15:01:35 --> Helper loaded: url_helper
DEBUG - 2011-06-21 15:01:35 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-21 15:01:35 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-21 15:01:35 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-21 15:01:35 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-21 15:01:35 --> Final output sent to browser
DEBUG - 2011-06-21 15:01:35 --> Total execution time: 2.0764
DEBUG - 2011-06-21 15:01:39 --> Config Class Initialized
DEBUG - 2011-06-21 15:01:39 --> Hooks Class Initialized
DEBUG - 2011-06-21 15:01:39 --> Utf8 Class Initialized
DEBUG - 2011-06-21 15:01:39 --> UTF-8 Support Enabled
DEBUG - 2011-06-21 15:01:39 --> URI Class Initialized
DEBUG - 2011-06-21 15:01:39 --> Router Class Initialized
ERROR - 2011-06-21 15:01:39 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-21 15:12:13 --> Config Class Initialized
DEBUG - 2011-06-21 15:12:13 --> Hooks Class Initialized
DEBUG - 2011-06-21 15:12:13 --> Utf8 Class Initialized
DEBUG - 2011-06-21 15:12:13 --> UTF-8 Support Enabled
DEBUG - 2011-06-21 15:12:13 --> URI Class Initialized
DEBUG - 2011-06-21 15:12:13 --> Router Class Initialized
DEBUG - 2011-06-21 15:12:13 --> Output Class Initialized
DEBUG - 2011-06-21 15:12:13 --> Input Class Initialized
DEBUG - 2011-06-21 15:12:13 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-21 15:12:13 --> Language Class Initialized
DEBUG - 2011-06-21 15:12:13 --> Loader Class Initialized
DEBUG - 2011-06-21 15:12:13 --> Controller Class Initialized
DEBUG - 2011-06-21 15:12:13 --> Model Class Initialized
DEBUG - 2011-06-21 15:12:13 --> Model Class Initialized
DEBUG - 2011-06-21 15:12:13 --> Model Class Initialized
DEBUG - 2011-06-21 15:12:13 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-21 15:12:13 --> Database Driver Class Initialized
DEBUG - 2011-06-21 15:12:13 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-21 15:12:13 --> Helper loaded: url_helper
DEBUG - 2011-06-21 15:12:13 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-21 15:12:13 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-21 15:12:13 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-21 15:12:13 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-21 15:12:13 --> Final output sent to browser
DEBUG - 2011-06-21 15:12:13 --> Total execution time: 0.1016
DEBUG - 2011-06-21 15:12:15 --> Config Class Initialized
DEBUG - 2011-06-21 15:12:15 --> Hooks Class Initialized
DEBUG - 2011-06-21 15:12:15 --> Utf8 Class Initialized
DEBUG - 2011-06-21 15:12:15 --> UTF-8 Support Enabled
DEBUG - 2011-06-21 15:12:15 --> URI Class Initialized
DEBUG - 2011-06-21 15:12:15 --> Router Class Initialized
ERROR - 2011-06-21 15:12:15 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-21 15:12:57 --> Config Class Initialized
DEBUG - 2011-06-21 15:12:57 --> Hooks Class Initialized
DEBUG - 2011-06-21 15:12:57 --> Utf8 Class Initialized
DEBUG - 2011-06-21 15:12:57 --> UTF-8 Support Enabled
DEBUG - 2011-06-21 15:12:57 --> URI Class Initialized
DEBUG - 2011-06-21 15:12:57 --> Router Class Initialized
ERROR - 2011-06-21 15:12:57 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-06-21 15:29:46 --> Config Class Initialized
DEBUG - 2011-06-21 15:29:46 --> Hooks Class Initialized
DEBUG - 2011-06-21 15:29:46 --> Utf8 Class Initialized
DEBUG - 2011-06-21 15:29:46 --> UTF-8 Support Enabled
DEBUG - 2011-06-21 15:29:46 --> URI Class Initialized
DEBUG - 2011-06-21 15:29:46 --> Router Class Initialized
ERROR - 2011-06-21 15:29:46 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-06-21 15:56:47 --> Config Class Initialized
DEBUG - 2011-06-21 15:56:47 --> Hooks Class Initialized
DEBUG - 2011-06-21 15:56:47 --> Utf8 Class Initialized
DEBUG - 2011-06-21 15:56:47 --> UTF-8 Support Enabled
DEBUG - 2011-06-21 15:56:47 --> URI Class Initialized
DEBUG - 2011-06-21 15:56:47 --> Router Class Initialized
DEBUG - 2011-06-21 15:56:47 --> Output Class Initialized
DEBUG - 2011-06-21 15:56:47 --> Input Class Initialized
DEBUG - 2011-06-21 15:56:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-21 15:56:47 --> Language Class Initialized
DEBUG - 2011-06-21 15:56:47 --> Loader Class Initialized
DEBUG - 2011-06-21 15:56:47 --> Controller Class Initialized
ERROR - 2011-06-21 15:56:48 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-21 15:56:48 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-21 15:56:48 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-21 15:56:48 --> Model Class Initialized
DEBUG - 2011-06-21 15:56:48 --> Model Class Initialized
DEBUG - 2011-06-21 15:56:48 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-21 15:56:48 --> Database Driver Class Initialized
DEBUG - 2011-06-21 15:56:48 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-21 15:56:49 --> Config Class Initialized
DEBUG - 2011-06-21 15:56:49 --> Hooks Class Initialized
DEBUG - 2011-06-21 15:56:49 --> Utf8 Class Initialized
DEBUG - 2011-06-21 15:56:49 --> UTF-8 Support Enabled
DEBUG - 2011-06-21 15:56:49 --> URI Class Initialized
DEBUG - 2011-06-21 15:56:49 --> Router Class Initialized
DEBUG - 2011-06-21 15:56:50 --> Output Class Initialized
DEBUG - 2011-06-21 15:56:50 --> Input Class Initialized
DEBUG - 2011-06-21 15:56:50 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-21 15:56:50 --> Language Class Initialized
DEBUG - 2011-06-21 15:56:50 --> Helper loaded: url_helper
DEBUG - 2011-06-21 15:56:50 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-21 15:56:50 --> Loader Class Initialized
DEBUG - 2011-06-21 15:56:50 --> Controller Class Initialized
DEBUG - 2011-06-21 15:56:50 --> Model Class Initialized
DEBUG - 2011-06-21 15:56:50 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-21 15:56:50 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-21 15:56:50 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-21 15:56:50 --> Final output sent to browser
DEBUG - 2011-06-21 15:56:50 --> Total execution time: 3.5335
DEBUG - 2011-06-21 15:56:50 --> Model Class Initialized
DEBUG - 2011-06-21 15:56:50 --> Model Class Initialized
DEBUG - 2011-06-21 15:56:50 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-21 15:56:50 --> Database Driver Class Initialized
DEBUG - 2011-06-21 15:56:51 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-21 15:56:51 --> Helper loaded: url_helper
DEBUG - 2011-06-21 15:56:51 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-21 15:56:51 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-21 15:56:51 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-21 15:56:51 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-21 15:56:51 --> Final output sent to browser
DEBUG - 2011-06-21 15:56:51 --> Total execution time: 1.4926
DEBUG - 2011-06-21 16:43:20 --> Config Class Initialized
DEBUG - 2011-06-21 16:43:20 --> Hooks Class Initialized
DEBUG - 2011-06-21 16:43:20 --> Utf8 Class Initialized
DEBUG - 2011-06-21 16:43:20 --> UTF-8 Support Enabled
DEBUG - 2011-06-21 16:43:20 --> URI Class Initialized
DEBUG - 2011-06-21 16:43:20 --> Router Class Initialized
DEBUG - 2011-06-21 16:43:20 --> No URI present. Default controller set.
DEBUG - 2011-06-21 16:43:20 --> Output Class Initialized
DEBUG - 2011-06-21 16:43:20 --> Input Class Initialized
DEBUG - 2011-06-21 16:43:20 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-21 16:43:20 --> Language Class Initialized
DEBUG - 2011-06-21 16:43:20 --> Loader Class Initialized
DEBUG - 2011-06-21 16:43:20 --> Controller Class Initialized
DEBUG - 2011-06-21 16:43:20 --> File loaded: application/views/splash/main.php
DEBUG - 2011-06-21 16:43:20 --> Helper loaded: url_helper
DEBUG - 2011-06-21 16:43:20 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-21 16:43:20 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-21 16:43:20 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-21 16:43:20 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-21 16:43:20 --> Final output sent to browser
DEBUG - 2011-06-21 16:43:20 --> Total execution time: 0.2898
DEBUG - 2011-06-21 22:15:23 --> Config Class Initialized
DEBUG - 2011-06-21 22:15:23 --> Hooks Class Initialized
DEBUG - 2011-06-21 22:15:23 --> Utf8 Class Initialized
DEBUG - 2011-06-21 22:15:23 --> UTF-8 Support Enabled
DEBUG - 2011-06-21 22:15:23 --> URI Class Initialized
DEBUG - 2011-06-21 22:15:23 --> Router Class Initialized
DEBUG - 2011-06-21 22:15:23 --> No URI present. Default controller set.
DEBUG - 2011-06-21 22:15:23 --> Output Class Initialized
DEBUG - 2011-06-21 22:15:23 --> Input Class Initialized
DEBUG - 2011-06-21 22:15:23 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-21 22:15:23 --> Language Class Initialized
DEBUG - 2011-06-21 22:15:23 --> Loader Class Initialized
DEBUG - 2011-06-21 22:15:23 --> Controller Class Initialized
DEBUG - 2011-06-21 22:15:23 --> File loaded: application/views/splash/main.php
DEBUG - 2011-06-21 22:15:23 --> Helper loaded: url_helper
DEBUG - 2011-06-21 22:15:23 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-21 22:15:23 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-21 22:15:23 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-21 22:15:23 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-21 22:15:23 --> Final output sent to browser
DEBUG - 2011-06-21 22:15:23 --> Total execution time: 0.2478
DEBUG - 2011-06-21 23:17:57 --> Config Class Initialized
DEBUG - 2011-06-21 23:17:57 --> Config Class Initialized
DEBUG - 2011-06-21 23:17:58 --> Hooks Class Initialized
DEBUG - 2011-06-21 23:17:58 --> Hooks Class Initialized
DEBUG - 2011-06-21 23:17:58 --> Utf8 Class Initialized
DEBUG - 2011-06-21 23:17:58 --> Utf8 Class Initialized
DEBUG - 2011-06-21 23:17:58 --> UTF-8 Support Enabled
DEBUG - 2011-06-21 23:17:58 --> UTF-8 Support Enabled
DEBUG - 2011-06-21 23:17:58 --> URI Class Initialized
DEBUG - 2011-06-21 23:17:58 --> URI Class Initialized
DEBUG - 2011-06-21 23:17:58 --> Router Class Initialized
DEBUG - 2011-06-21 23:17:58 --> Router Class Initialized
DEBUG - 2011-06-21 23:17:58 --> Output Class Initialized
DEBUG - 2011-06-21 23:17:58 --> Output Class Initialized
DEBUG - 2011-06-21 23:17:58 --> Input Class Initialized
DEBUG - 2011-06-21 23:17:58 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-21 23:17:58 --> Input Class Initialized
DEBUG - 2011-06-21 23:17:58 --> Language Class Initialized
DEBUG - 2011-06-21 23:17:58 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-21 23:17:58 --> Language Class Initialized
DEBUG - 2011-06-21 23:17:58 --> Loader Class Initialized
DEBUG - 2011-06-21 23:17:58 --> Loader Class Initialized
DEBUG - 2011-06-21 23:17:58 --> Controller Class Initialized
DEBUG - 2011-06-21 23:17:58 --> Controller Class Initialized
ERROR - 2011-06-21 23:17:58 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-21 23:17:58 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-21 23:17:58 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-21 23:17:58 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-21 23:17:58 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-21 23:17:58 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-21 23:17:58 --> Model Class Initialized
DEBUG - 2011-06-21 23:17:58 --> Model Class Initialized
DEBUG - 2011-06-21 23:17:58 --> Model Class Initialized
DEBUG - 2011-06-21 23:17:58 --> Model Class Initialized
DEBUG - 2011-06-21 23:17:58 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-21 23:17:58 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-21 23:17:58 --> Database Driver Class Initialized
DEBUG - 2011-06-21 23:17:58 --> Database Driver Class Initialized
DEBUG - 2011-06-21 23:17:58 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-21 23:17:58 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-21 23:17:58 --> Helper loaded: url_helper
DEBUG - 2011-06-21 23:17:58 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-21 23:17:58 --> Helper loaded: url_helper
DEBUG - 2011-06-21 23:17:58 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-21 23:17:58 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-21 23:17:58 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-21 23:17:58 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-21 23:17:58 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-21 23:17:58 --> Final output sent to browser
DEBUG - 2011-06-21 23:17:58 --> Total execution time: 0.9727
DEBUG - 2011-06-21 23:17:58 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-21 23:17:58 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-21 23:17:58 --> Final output sent to browser
DEBUG - 2011-06-21 23:17:58 --> Total execution time: 0.9738
DEBUG - 2011-06-21 23:18:00 --> Config Class Initialized
DEBUG - 2011-06-21 23:18:00 --> Hooks Class Initialized
DEBUG - 2011-06-21 23:18:00 --> Utf8 Class Initialized
DEBUG - 2011-06-21 23:18:00 --> UTF-8 Support Enabled
DEBUG - 2011-06-21 23:18:00 --> URI Class Initialized
DEBUG - 2011-06-21 23:18:00 --> Router Class Initialized
DEBUG - 2011-06-21 23:18:00 --> Output Class Initialized
DEBUG - 2011-06-21 23:18:00 --> Input Class Initialized
DEBUG - 2011-06-21 23:18:00 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-21 23:18:00 --> Language Class Initialized
DEBUG - 2011-06-21 23:18:00 --> Loader Class Initialized
DEBUG - 2011-06-21 23:18:00 --> Controller Class Initialized
DEBUG - 2011-06-21 23:18:00 --> Model Class Initialized
DEBUG - 2011-06-21 23:18:00 --> Model Class Initialized
DEBUG - 2011-06-21 23:18:00 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-21 23:18:01 --> Database Driver Class Initialized
DEBUG - 2011-06-21 23:18:01 --> Config Class Initialized
DEBUG - 2011-06-21 23:18:01 --> Hooks Class Initialized
DEBUG - 2011-06-21 23:18:01 --> Utf8 Class Initialized
DEBUG - 2011-06-21 23:18:01 --> UTF-8 Support Enabled
DEBUG - 2011-06-21 23:18:01 --> URI Class Initialized
DEBUG - 2011-06-21 23:18:01 --> Router Class Initialized
DEBUG - 2011-06-21 23:18:01 --> Output Class Initialized
DEBUG - 2011-06-21 23:18:01 --> Input Class Initialized
DEBUG - 2011-06-21 23:18:01 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-21 23:18:01 --> Language Class Initialized
DEBUG - 2011-06-21 23:18:01 --> Loader Class Initialized
DEBUG - 2011-06-21 23:18:01 --> Controller Class Initialized
DEBUG - 2011-06-21 23:18:01 --> Model Class Initialized
DEBUG - 2011-06-21 23:18:01 --> Model Class Initialized
DEBUG - 2011-06-21 23:18:01 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-21 23:18:01 --> Database Driver Class Initialized
DEBUG - 2011-06-21 23:18:01 --> Final output sent to browser
DEBUG - 2011-06-21 23:18:01 --> Total execution time: 0.7378
DEBUG - 2011-06-21 23:18:02 --> Config Class Initialized
DEBUG - 2011-06-21 23:18:02 --> Hooks Class Initialized
DEBUG - 2011-06-21 23:18:02 --> Utf8 Class Initialized
DEBUG - 2011-06-21 23:18:02 --> UTF-8 Support Enabled
DEBUG - 2011-06-21 23:18:02 --> URI Class Initialized
DEBUG - 2011-06-21 23:18:02 --> Router Class Initialized
ERROR - 2011-06-21 23:18:02 --> 404 Page Not Found --> favicon.ico

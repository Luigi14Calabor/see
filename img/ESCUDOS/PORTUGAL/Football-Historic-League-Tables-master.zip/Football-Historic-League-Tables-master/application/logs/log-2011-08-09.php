<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2011-08-09 00:00:24 --> Config Class Initialized
DEBUG - 2011-08-09 00:00:24 --> Hooks Class Initialized
DEBUG - 2011-08-09 00:00:24 --> Utf8 Class Initialized
DEBUG - 2011-08-09 00:00:24 --> UTF-8 Support Enabled
DEBUG - 2011-08-09 00:00:24 --> URI Class Initialized
DEBUG - 2011-08-09 00:00:24 --> Router Class Initialized
ERROR - 2011-08-09 00:00:24 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-08-09 01:35:30 --> Config Class Initialized
DEBUG - 2011-08-09 01:35:30 --> Hooks Class Initialized
DEBUG - 2011-08-09 01:35:30 --> Utf8 Class Initialized
DEBUG - 2011-08-09 01:35:30 --> UTF-8 Support Enabled
DEBUG - 2011-08-09 01:35:30 --> URI Class Initialized
DEBUG - 2011-08-09 01:35:30 --> Router Class Initialized
DEBUG - 2011-08-09 01:35:30 --> Output Class Initialized
DEBUG - 2011-08-09 01:35:30 --> Input Class Initialized
DEBUG - 2011-08-09 01:35:30 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-09 01:35:30 --> Language Class Initialized
DEBUG - 2011-08-09 01:35:30 --> Loader Class Initialized
DEBUG - 2011-08-09 01:35:30 --> Controller Class Initialized
DEBUG - 2011-08-09 01:35:30 --> Model Class Initialized
DEBUG - 2011-08-09 01:35:30 --> Model Class Initialized
DEBUG - 2011-08-09 01:35:30 --> Model Class Initialized
DEBUG - 2011-08-09 01:35:30 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-09 01:35:30 --> Database Driver Class Initialized
DEBUG - 2011-08-09 01:35:32 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-09 01:35:32 --> Helper loaded: url_helper
DEBUG - 2011-08-09 01:35:32 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-09 01:35:33 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-09 01:35:33 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-09 01:35:33 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-09 01:35:33 --> Final output sent to browser
DEBUG - 2011-08-09 01:35:33 --> Total execution time: 2.1981
DEBUG - 2011-08-09 01:35:36 --> Config Class Initialized
DEBUG - 2011-08-09 01:35:36 --> Hooks Class Initialized
DEBUG - 2011-08-09 01:35:36 --> Utf8 Class Initialized
DEBUG - 2011-08-09 01:35:36 --> UTF-8 Support Enabled
DEBUG - 2011-08-09 01:35:36 --> URI Class Initialized
DEBUG - 2011-08-09 01:35:36 --> Router Class Initialized
DEBUG - 2011-08-09 01:35:36 --> Output Class Initialized
DEBUG - 2011-08-09 01:35:36 --> Input Class Initialized
DEBUG - 2011-08-09 01:35:36 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-09 01:35:36 --> Language Class Initialized
DEBUG - 2011-08-09 01:35:36 --> Loader Class Initialized
DEBUG - 2011-08-09 01:35:36 --> Controller Class Initialized
ERROR - 2011-08-09 01:35:36 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-09 01:35:36 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-09 01:35:36 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-09 01:35:36 --> Model Class Initialized
DEBUG - 2011-08-09 01:35:36 --> Model Class Initialized
DEBUG - 2011-08-09 01:35:36 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-09 01:35:36 --> Database Driver Class Initialized
DEBUG - 2011-08-09 01:35:36 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-09 01:35:36 --> Helper loaded: url_helper
DEBUG - 2011-08-09 01:35:36 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-09 01:35:36 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-09 01:35:36 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-09 01:35:36 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-09 01:35:36 --> Final output sent to browser
DEBUG - 2011-08-09 01:35:36 --> Total execution time: 0.1444
DEBUG - 2011-08-09 03:51:35 --> Config Class Initialized
DEBUG - 2011-08-09 03:51:35 --> Hooks Class Initialized
DEBUG - 2011-08-09 03:51:35 --> Utf8 Class Initialized
DEBUG - 2011-08-09 03:51:35 --> UTF-8 Support Enabled
DEBUG - 2011-08-09 03:51:35 --> URI Class Initialized
DEBUG - 2011-08-09 03:51:35 --> Router Class Initialized
DEBUG - 2011-08-09 03:51:35 --> Output Class Initialized
DEBUG - 2011-08-09 03:51:35 --> Input Class Initialized
DEBUG - 2011-08-09 03:51:35 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-09 03:51:35 --> Language Class Initialized
DEBUG - 2011-08-09 03:51:35 --> Loader Class Initialized
DEBUG - 2011-08-09 03:51:35 --> Controller Class Initialized
DEBUG - 2011-08-09 03:51:35 --> Model Class Initialized
DEBUG - 2011-08-09 03:51:35 --> Model Class Initialized
DEBUG - 2011-08-09 03:51:35 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-09 03:51:35 --> Database Driver Class Initialized
DEBUG - 2011-08-09 03:51:37 --> Final output sent to browser
DEBUG - 2011-08-09 03:51:37 --> Total execution time: 1.5159
DEBUG - 2011-08-09 04:16:17 --> Config Class Initialized
DEBUG - 2011-08-09 04:16:17 --> Hooks Class Initialized
DEBUG - 2011-08-09 04:16:17 --> Utf8 Class Initialized
DEBUG - 2011-08-09 04:16:17 --> UTF-8 Support Enabled
DEBUG - 2011-08-09 04:16:17 --> URI Class Initialized
DEBUG - 2011-08-09 04:16:17 --> Router Class Initialized
DEBUG - 2011-08-09 04:16:17 --> Output Class Initialized
DEBUG - 2011-08-09 04:16:17 --> Input Class Initialized
DEBUG - 2011-08-09 04:16:17 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-09 04:16:17 --> Language Class Initialized
DEBUG - 2011-08-09 04:16:17 --> Loader Class Initialized
DEBUG - 2011-08-09 04:16:17 --> Controller Class Initialized
ERROR - 2011-08-09 04:16:17 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-09 04:16:17 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-09 04:16:17 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-09 04:16:17 --> Model Class Initialized
DEBUG - 2011-08-09 04:16:17 --> Model Class Initialized
DEBUG - 2011-08-09 04:16:17 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-09 04:16:17 --> Database Driver Class Initialized
DEBUG - 2011-08-09 04:16:18 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-09 04:16:18 --> Helper loaded: url_helper
DEBUG - 2011-08-09 04:16:18 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-09 04:16:18 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-09 04:16:18 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-09 04:16:18 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-09 04:16:18 --> Final output sent to browser
DEBUG - 2011-08-09 04:16:18 --> Total execution time: 0.5908
DEBUG - 2011-08-09 04:16:20 --> Config Class Initialized
DEBUG - 2011-08-09 04:16:20 --> Hooks Class Initialized
DEBUG - 2011-08-09 04:16:20 --> Utf8 Class Initialized
DEBUG - 2011-08-09 04:16:20 --> UTF-8 Support Enabled
DEBUG - 2011-08-09 04:16:20 --> URI Class Initialized
DEBUG - 2011-08-09 04:16:20 --> Router Class Initialized
DEBUG - 2011-08-09 04:16:20 --> Output Class Initialized
DEBUG - 2011-08-09 04:16:20 --> Input Class Initialized
DEBUG - 2011-08-09 04:16:20 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-09 04:16:20 --> Language Class Initialized
DEBUG - 2011-08-09 04:16:20 --> Loader Class Initialized
DEBUG - 2011-08-09 04:16:20 --> Controller Class Initialized
DEBUG - 2011-08-09 04:16:20 --> Model Class Initialized
DEBUG - 2011-08-09 04:16:20 --> Model Class Initialized
DEBUG - 2011-08-09 04:16:20 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-09 04:16:20 --> Database Driver Class Initialized
DEBUG - 2011-08-09 04:16:21 --> Final output sent to browser
DEBUG - 2011-08-09 04:16:21 --> Total execution time: 0.8153
DEBUG - 2011-08-09 04:16:24 --> Config Class Initialized
DEBUG - 2011-08-09 04:16:24 --> Hooks Class Initialized
DEBUG - 2011-08-09 04:16:24 --> Utf8 Class Initialized
DEBUG - 2011-08-09 04:16:24 --> UTF-8 Support Enabled
DEBUG - 2011-08-09 04:16:24 --> URI Class Initialized
DEBUG - 2011-08-09 04:16:24 --> Router Class Initialized
ERROR - 2011-08-09 04:16:24 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-09 04:21:55 --> Config Class Initialized
DEBUG - 2011-08-09 04:21:55 --> Hooks Class Initialized
DEBUG - 2011-08-09 04:21:55 --> Utf8 Class Initialized
DEBUG - 2011-08-09 04:21:55 --> UTF-8 Support Enabled
DEBUG - 2011-08-09 04:21:55 --> URI Class Initialized
DEBUG - 2011-08-09 04:21:55 --> Router Class Initialized
ERROR - 2011-08-09 04:21:55 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-08-09 06:33:27 --> Config Class Initialized
DEBUG - 2011-08-09 06:33:27 --> Hooks Class Initialized
DEBUG - 2011-08-09 06:33:27 --> Utf8 Class Initialized
DEBUG - 2011-08-09 06:33:27 --> UTF-8 Support Enabled
DEBUG - 2011-08-09 06:33:27 --> URI Class Initialized
DEBUG - 2011-08-09 06:33:27 --> Router Class Initialized
ERROR - 2011-08-09 06:33:27 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-08-09 06:33:28 --> Config Class Initialized
DEBUG - 2011-08-09 06:33:28 --> Hooks Class Initialized
DEBUG - 2011-08-09 06:33:28 --> Utf8 Class Initialized
DEBUG - 2011-08-09 06:33:28 --> UTF-8 Support Enabled
DEBUG - 2011-08-09 06:33:28 --> URI Class Initialized
DEBUG - 2011-08-09 06:33:28 --> Router Class Initialized
DEBUG - 2011-08-09 06:33:28 --> Output Class Initialized
DEBUG - 2011-08-09 06:33:28 --> Input Class Initialized
DEBUG - 2011-08-09 06:33:28 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-09 06:33:28 --> Language Class Initialized
DEBUG - 2011-08-09 06:33:28 --> Loader Class Initialized
DEBUG - 2011-08-09 06:33:28 --> Controller Class Initialized
DEBUG - 2011-08-09 06:33:28 --> Model Class Initialized
DEBUG - 2011-08-09 06:33:28 --> Model Class Initialized
DEBUG - 2011-08-09 06:33:28 --> Model Class Initialized
DEBUG - 2011-08-09 06:33:28 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-09 06:33:28 --> Database Driver Class Initialized
DEBUG - 2011-08-09 06:33:29 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-09 06:33:29 --> Helper loaded: url_helper
DEBUG - 2011-08-09 06:33:29 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-09 06:33:29 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-09 06:33:29 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-09 06:33:29 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-09 06:33:29 --> Final output sent to browser
DEBUG - 2011-08-09 06:33:29 --> Total execution time: 1.6145
DEBUG - 2011-08-09 07:19:09 --> Config Class Initialized
DEBUG - 2011-08-09 07:19:09 --> Hooks Class Initialized
DEBUG - 2011-08-09 07:19:09 --> Utf8 Class Initialized
DEBUG - 2011-08-09 07:19:09 --> UTF-8 Support Enabled
DEBUG - 2011-08-09 07:19:09 --> URI Class Initialized
DEBUG - 2011-08-09 07:19:09 --> Router Class Initialized
ERROR - 2011-08-09 07:19:09 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-08-09 07:19:09 --> Config Class Initialized
DEBUG - 2011-08-09 07:19:09 --> Hooks Class Initialized
DEBUG - 2011-08-09 07:19:09 --> Utf8 Class Initialized
DEBUG - 2011-08-09 07:19:09 --> UTF-8 Support Enabled
DEBUG - 2011-08-09 07:19:09 --> URI Class Initialized
DEBUG - 2011-08-09 07:19:09 --> Router Class Initialized
DEBUG - 2011-08-09 07:19:09 --> No URI present. Default controller set.
DEBUG - 2011-08-09 07:19:09 --> Output Class Initialized
DEBUG - 2011-08-09 07:19:09 --> Input Class Initialized
DEBUG - 2011-08-09 07:19:09 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-09 07:19:09 --> Language Class Initialized
DEBUG - 2011-08-09 07:19:09 --> Loader Class Initialized
DEBUG - 2011-08-09 07:19:09 --> Controller Class Initialized
DEBUG - 2011-08-09 07:19:09 --> File loaded: application/views/splash/main.php
DEBUG - 2011-08-09 07:19:09 --> Helper loaded: url_helper
DEBUG - 2011-08-09 07:19:09 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-09 07:19:09 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-09 07:19:09 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-09 07:19:09 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-09 07:19:09 --> Final output sent to browser
DEBUG - 2011-08-09 07:19:09 --> Total execution time: 0.1807
DEBUG - 2011-08-09 08:28:15 --> Config Class Initialized
DEBUG - 2011-08-09 08:28:15 --> Hooks Class Initialized
DEBUG - 2011-08-09 08:28:15 --> Utf8 Class Initialized
DEBUG - 2011-08-09 08:28:15 --> UTF-8 Support Enabled
DEBUG - 2011-08-09 08:28:15 --> URI Class Initialized
DEBUG - 2011-08-09 08:28:15 --> Router Class Initialized
ERROR - 2011-08-09 08:28:15 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-09 08:28:15 --> Config Class Initialized
DEBUG - 2011-08-09 08:28:15 --> Hooks Class Initialized
DEBUG - 2011-08-09 08:28:15 --> Utf8 Class Initialized
DEBUG - 2011-08-09 08:28:15 --> UTF-8 Support Enabled
DEBUG - 2011-08-09 08:28:15 --> URI Class Initialized
DEBUG - 2011-08-09 08:28:15 --> Router Class Initialized
DEBUG - 2011-08-09 08:28:15 --> Output Class Initialized
DEBUG - 2011-08-09 08:28:15 --> Input Class Initialized
DEBUG - 2011-08-09 08:28:15 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-09 08:28:15 --> Language Class Initialized
DEBUG - 2011-08-09 08:28:15 --> Loader Class Initialized
DEBUG - 2011-08-09 08:28:15 --> Controller Class Initialized
ERROR - 2011-08-09 08:28:15 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-09 08:28:15 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-09 08:28:15 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-09 08:28:15 --> Model Class Initialized
DEBUG - 2011-08-09 08:28:15 --> Model Class Initialized
DEBUG - 2011-08-09 08:28:15 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-09 08:28:15 --> Database Driver Class Initialized
DEBUG - 2011-08-09 08:28:15 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-09 08:28:15 --> Helper loaded: url_helper
DEBUG - 2011-08-09 08:28:15 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-09 08:28:15 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-09 08:28:15 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-09 08:28:15 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-09 08:28:15 --> Final output sent to browser
DEBUG - 2011-08-09 08:28:15 --> Total execution time: 0.2773
DEBUG - 2011-08-09 08:28:18 --> Config Class Initialized
DEBUG - 2011-08-09 08:28:18 --> Hooks Class Initialized
DEBUG - 2011-08-09 08:28:18 --> Utf8 Class Initialized
DEBUG - 2011-08-09 08:28:18 --> UTF-8 Support Enabled
DEBUG - 2011-08-09 08:28:18 --> URI Class Initialized
DEBUG - 2011-08-09 08:28:18 --> Router Class Initialized
DEBUG - 2011-08-09 08:28:18 --> Output Class Initialized
DEBUG - 2011-08-09 08:28:18 --> Input Class Initialized
DEBUG - 2011-08-09 08:28:18 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-09 08:28:18 --> Language Class Initialized
DEBUG - 2011-08-09 08:28:18 --> Loader Class Initialized
DEBUG - 2011-08-09 08:28:18 --> Controller Class Initialized
DEBUG - 2011-08-09 08:28:18 --> Model Class Initialized
DEBUG - 2011-08-09 08:28:18 --> Model Class Initialized
DEBUG - 2011-08-09 08:28:18 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-09 08:28:18 --> Database Driver Class Initialized
DEBUG - 2011-08-09 08:28:21 --> Final output sent to browser
DEBUG - 2011-08-09 08:28:21 --> Total execution time: 3.1154
DEBUG - 2011-08-09 08:29:24 --> Config Class Initialized
DEBUG - 2011-08-09 08:29:24 --> Hooks Class Initialized
DEBUG - 2011-08-09 08:29:24 --> Utf8 Class Initialized
DEBUG - 2011-08-09 08:29:24 --> UTF-8 Support Enabled
DEBUG - 2011-08-09 08:29:24 --> URI Class Initialized
DEBUG - 2011-08-09 08:29:24 --> Router Class Initialized
DEBUG - 2011-08-09 08:29:24 --> Output Class Initialized
DEBUG - 2011-08-09 08:29:24 --> Input Class Initialized
DEBUG - 2011-08-09 08:29:24 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-09 08:29:24 --> Language Class Initialized
DEBUG - 2011-08-09 08:29:24 --> Loader Class Initialized
DEBUG - 2011-08-09 08:29:24 --> Controller Class Initialized
ERROR - 2011-08-09 08:29:24 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-09 08:29:24 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-09 08:29:24 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-09 08:29:24 --> Model Class Initialized
DEBUG - 2011-08-09 08:29:24 --> Model Class Initialized
DEBUG - 2011-08-09 08:29:24 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-09 08:29:24 --> Database Driver Class Initialized
DEBUG - 2011-08-09 08:29:24 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-09 08:29:24 --> Helper loaded: url_helper
DEBUG - 2011-08-09 08:29:24 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-09 08:29:24 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-09 08:29:24 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-09 08:29:24 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-09 08:29:24 --> Final output sent to browser
DEBUG - 2011-08-09 08:29:24 --> Total execution time: 0.0304
DEBUG - 2011-08-09 08:29:26 --> Config Class Initialized
DEBUG - 2011-08-09 08:29:26 --> Hooks Class Initialized
DEBUG - 2011-08-09 08:29:26 --> Utf8 Class Initialized
DEBUG - 2011-08-09 08:29:26 --> UTF-8 Support Enabled
DEBUG - 2011-08-09 08:29:26 --> URI Class Initialized
DEBUG - 2011-08-09 08:29:26 --> Router Class Initialized
DEBUG - 2011-08-09 08:29:26 --> Output Class Initialized
DEBUG - 2011-08-09 08:29:26 --> Input Class Initialized
DEBUG - 2011-08-09 08:29:26 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-09 08:29:26 --> Language Class Initialized
DEBUG - 2011-08-09 08:29:26 --> Loader Class Initialized
DEBUG - 2011-08-09 08:29:26 --> Controller Class Initialized
DEBUG - 2011-08-09 08:29:26 --> Model Class Initialized
DEBUG - 2011-08-09 08:29:26 --> Model Class Initialized
DEBUG - 2011-08-09 08:29:26 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-09 08:29:26 --> Database Driver Class Initialized
DEBUG - 2011-08-09 08:29:26 --> Final output sent to browser
DEBUG - 2011-08-09 08:29:26 --> Total execution time: 0.5586
DEBUG - 2011-08-09 08:45:41 --> Config Class Initialized
DEBUG - 2011-08-09 08:45:41 --> Hooks Class Initialized
DEBUG - 2011-08-09 08:45:41 --> Utf8 Class Initialized
DEBUG - 2011-08-09 08:45:41 --> UTF-8 Support Enabled
DEBUG - 2011-08-09 08:45:41 --> URI Class Initialized
DEBUG - 2011-08-09 08:45:41 --> Router Class Initialized
ERROR - 2011-08-09 08:45:41 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-08-09 09:09:30 --> Config Class Initialized
DEBUG - 2011-08-09 09:09:30 --> Hooks Class Initialized
DEBUG - 2011-08-09 09:09:30 --> Utf8 Class Initialized
DEBUG - 2011-08-09 09:09:30 --> UTF-8 Support Enabled
DEBUG - 2011-08-09 09:09:30 --> URI Class Initialized
DEBUG - 2011-08-09 09:09:30 --> Router Class Initialized
DEBUG - 2011-08-09 09:09:30 --> Output Class Initialized
DEBUG - 2011-08-09 09:09:30 --> Input Class Initialized
DEBUG - 2011-08-09 09:09:30 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-09 09:09:30 --> Language Class Initialized
DEBUG - 2011-08-09 09:09:30 --> Loader Class Initialized
DEBUG - 2011-08-09 09:09:30 --> Controller Class Initialized
DEBUG - 2011-08-09 09:09:30 --> Model Class Initialized
DEBUG - 2011-08-09 09:09:30 --> Model Class Initialized
DEBUG - 2011-08-09 09:09:30 --> Model Class Initialized
DEBUG - 2011-08-09 09:09:30 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-09 09:09:30 --> Database Driver Class Initialized
DEBUG - 2011-08-09 09:09:31 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-09 09:09:31 --> Helper loaded: url_helper
DEBUG - 2011-08-09 09:09:31 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-09 09:09:31 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-09 09:09:31 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-09 09:09:31 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-09 09:09:31 --> Final output sent to browser
DEBUG - 2011-08-09 09:09:31 --> Total execution time: 0.7215
DEBUG - 2011-08-09 09:12:02 --> Config Class Initialized
DEBUG - 2011-08-09 09:12:02 --> Hooks Class Initialized
DEBUG - 2011-08-09 09:12:02 --> Utf8 Class Initialized
DEBUG - 2011-08-09 09:12:02 --> UTF-8 Support Enabled
DEBUG - 2011-08-09 09:12:02 --> URI Class Initialized
DEBUG - 2011-08-09 09:12:02 --> Router Class Initialized
DEBUG - 2011-08-09 09:12:02 --> Output Class Initialized
DEBUG - 2011-08-09 09:12:02 --> Input Class Initialized
DEBUG - 2011-08-09 09:12:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-09 09:12:02 --> Language Class Initialized
DEBUG - 2011-08-09 09:12:02 --> Loader Class Initialized
DEBUG - 2011-08-09 09:12:02 --> Controller Class Initialized
DEBUG - 2011-08-09 09:12:02 --> Model Class Initialized
DEBUG - 2011-08-09 09:12:02 --> Model Class Initialized
DEBUG - 2011-08-09 09:12:02 --> Model Class Initialized
DEBUG - 2011-08-09 09:12:02 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-09 09:12:02 --> Database Driver Class Initialized
DEBUG - 2011-08-09 09:12:03 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-09 09:12:03 --> Helper loaded: url_helper
DEBUG - 2011-08-09 09:12:03 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-09 09:12:03 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-09 09:12:03 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-09 09:12:03 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-09 09:12:03 --> Final output sent to browser
DEBUG - 2011-08-09 09:12:03 --> Total execution time: 0.6991
DEBUG - 2011-08-09 09:12:06 --> Config Class Initialized
DEBUG - 2011-08-09 09:12:06 --> Hooks Class Initialized
DEBUG - 2011-08-09 09:12:06 --> Utf8 Class Initialized
DEBUG - 2011-08-09 09:12:06 --> UTF-8 Support Enabled
DEBUG - 2011-08-09 09:12:06 --> URI Class Initialized
DEBUG - 2011-08-09 09:12:06 --> Router Class Initialized
ERROR - 2011-08-09 09:12:06 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-08-09 09:12:06 --> Config Class Initialized
DEBUG - 2011-08-09 09:12:06 --> Hooks Class Initialized
DEBUG - 2011-08-09 09:12:06 --> Utf8 Class Initialized
DEBUG - 2011-08-09 09:12:06 --> UTF-8 Support Enabled
DEBUG - 2011-08-09 09:12:06 --> URI Class Initialized
DEBUG - 2011-08-09 09:12:06 --> Router Class Initialized
DEBUG - 2011-08-09 09:12:06 --> Output Class Initialized
DEBUG - 2011-08-09 09:12:06 --> Input Class Initialized
DEBUG - 2011-08-09 09:12:06 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-09 09:12:06 --> Language Class Initialized
DEBUG - 2011-08-09 09:12:06 --> Loader Class Initialized
DEBUG - 2011-08-09 09:12:06 --> Controller Class Initialized
DEBUG - 2011-08-09 09:12:06 --> Model Class Initialized
DEBUG - 2011-08-09 09:12:06 --> Model Class Initialized
DEBUG - 2011-08-09 09:12:06 --> Model Class Initialized
DEBUG - 2011-08-09 09:12:06 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-09 09:12:06 --> Database Driver Class Initialized
DEBUG - 2011-08-09 09:12:06 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-09 09:12:06 --> Helper loaded: url_helper
DEBUG - 2011-08-09 09:12:06 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-09 09:12:06 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-09 09:12:06 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-09 09:12:06 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-09 09:12:06 --> Final output sent to browser
DEBUG - 2011-08-09 09:12:06 --> Total execution time: 0.0428
DEBUG - 2011-08-09 09:12:40 --> Config Class Initialized
DEBUG - 2011-08-09 09:12:40 --> Hooks Class Initialized
DEBUG - 2011-08-09 09:12:40 --> Utf8 Class Initialized
DEBUG - 2011-08-09 09:12:40 --> UTF-8 Support Enabled
DEBUG - 2011-08-09 09:12:40 --> URI Class Initialized
DEBUG - 2011-08-09 09:12:40 --> Router Class Initialized
DEBUG - 2011-08-09 09:12:40 --> Output Class Initialized
DEBUG - 2011-08-09 09:12:40 --> Input Class Initialized
DEBUG - 2011-08-09 09:12:40 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-09 09:12:40 --> Language Class Initialized
DEBUG - 2011-08-09 09:12:40 --> Loader Class Initialized
DEBUG - 2011-08-09 09:12:40 --> Controller Class Initialized
DEBUG - 2011-08-09 09:12:40 --> Model Class Initialized
DEBUG - 2011-08-09 09:12:40 --> Model Class Initialized
DEBUG - 2011-08-09 09:12:40 --> Model Class Initialized
DEBUG - 2011-08-09 09:12:40 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-09 09:12:40 --> Database Driver Class Initialized
DEBUG - 2011-08-09 09:12:40 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-09 09:12:40 --> Helper loaded: url_helper
DEBUG - 2011-08-09 09:12:40 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-09 09:12:40 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-09 09:12:40 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-09 09:12:40 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-09 09:12:40 --> Final output sent to browser
DEBUG - 2011-08-09 09:12:40 --> Total execution time: 0.3664
DEBUG - 2011-08-09 09:13:10 --> Config Class Initialized
DEBUG - 2011-08-09 09:13:10 --> Hooks Class Initialized
DEBUG - 2011-08-09 09:13:10 --> Utf8 Class Initialized
DEBUG - 2011-08-09 09:13:10 --> UTF-8 Support Enabled
DEBUG - 2011-08-09 09:13:10 --> URI Class Initialized
DEBUG - 2011-08-09 09:13:10 --> Router Class Initialized
DEBUG - 2011-08-09 09:13:10 --> Output Class Initialized
DEBUG - 2011-08-09 09:13:10 --> Input Class Initialized
DEBUG - 2011-08-09 09:13:10 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-09 09:13:10 --> Language Class Initialized
DEBUG - 2011-08-09 09:13:10 --> Loader Class Initialized
DEBUG - 2011-08-09 09:13:10 --> Controller Class Initialized
DEBUG - 2011-08-09 09:13:10 --> Model Class Initialized
DEBUG - 2011-08-09 09:13:10 --> Model Class Initialized
DEBUG - 2011-08-09 09:13:10 --> Model Class Initialized
DEBUG - 2011-08-09 09:13:10 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-09 09:13:10 --> Database Driver Class Initialized
DEBUG - 2011-08-09 09:13:10 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-09 09:13:10 --> Helper loaded: url_helper
DEBUG - 2011-08-09 09:13:10 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-09 09:13:10 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-09 09:13:10 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-09 09:13:10 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-09 09:13:10 --> Final output sent to browser
DEBUG - 2011-08-09 09:13:10 --> Total execution time: 0.2102
DEBUG - 2011-08-09 09:13:20 --> Config Class Initialized
DEBUG - 2011-08-09 09:13:20 --> Hooks Class Initialized
DEBUG - 2011-08-09 09:13:20 --> Utf8 Class Initialized
DEBUG - 2011-08-09 09:13:20 --> UTF-8 Support Enabled
DEBUG - 2011-08-09 09:13:20 --> URI Class Initialized
DEBUG - 2011-08-09 09:13:20 --> Router Class Initialized
DEBUG - 2011-08-09 09:13:20 --> Output Class Initialized
DEBUG - 2011-08-09 09:13:20 --> Input Class Initialized
DEBUG - 2011-08-09 09:13:20 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-09 09:13:20 --> Language Class Initialized
DEBUG - 2011-08-09 09:13:20 --> Loader Class Initialized
DEBUG - 2011-08-09 09:13:20 --> Controller Class Initialized
DEBUG - 2011-08-09 09:13:20 --> Model Class Initialized
DEBUG - 2011-08-09 09:13:20 --> Model Class Initialized
DEBUG - 2011-08-09 09:13:20 --> Model Class Initialized
DEBUG - 2011-08-09 09:13:20 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-09 09:13:20 --> Database Driver Class Initialized
DEBUG - 2011-08-09 09:13:20 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-09 09:13:20 --> Helper loaded: url_helper
DEBUG - 2011-08-09 09:13:20 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-09 09:13:20 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-09 09:13:20 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-09 09:13:20 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-09 09:13:20 --> Final output sent to browser
DEBUG - 2011-08-09 09:13:20 --> Total execution time: 0.4005
DEBUG - 2011-08-09 09:13:23 --> Config Class Initialized
DEBUG - 2011-08-09 09:13:23 --> Hooks Class Initialized
DEBUG - 2011-08-09 09:13:23 --> Utf8 Class Initialized
DEBUG - 2011-08-09 09:13:23 --> UTF-8 Support Enabled
DEBUG - 2011-08-09 09:13:23 --> URI Class Initialized
DEBUG - 2011-08-09 09:13:23 --> Router Class Initialized
DEBUG - 2011-08-09 09:13:23 --> Output Class Initialized
DEBUG - 2011-08-09 09:13:23 --> Input Class Initialized
DEBUG - 2011-08-09 09:13:23 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-09 09:13:23 --> Language Class Initialized
DEBUG - 2011-08-09 09:13:23 --> Loader Class Initialized
DEBUG - 2011-08-09 09:13:23 --> Controller Class Initialized
DEBUG - 2011-08-09 09:13:23 --> Model Class Initialized
DEBUG - 2011-08-09 09:13:23 --> Model Class Initialized
DEBUG - 2011-08-09 09:13:23 --> Model Class Initialized
DEBUG - 2011-08-09 09:13:23 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-09 09:13:23 --> Database Driver Class Initialized
DEBUG - 2011-08-09 09:13:24 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-09 09:13:24 --> Helper loaded: url_helper
DEBUG - 2011-08-09 09:13:24 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-09 09:13:24 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-09 09:13:24 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-09 09:13:24 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-09 09:13:24 --> Final output sent to browser
DEBUG - 2011-08-09 09:13:24 --> Total execution time: 0.0969
DEBUG - 2011-08-09 09:14:06 --> Config Class Initialized
DEBUG - 2011-08-09 09:14:06 --> Hooks Class Initialized
DEBUG - 2011-08-09 09:14:06 --> Utf8 Class Initialized
DEBUG - 2011-08-09 09:14:06 --> UTF-8 Support Enabled
DEBUG - 2011-08-09 09:14:06 --> URI Class Initialized
DEBUG - 2011-08-09 09:14:06 --> Router Class Initialized
DEBUG - 2011-08-09 09:14:06 --> Output Class Initialized
DEBUG - 2011-08-09 09:14:06 --> Input Class Initialized
DEBUG - 2011-08-09 09:14:06 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-09 09:14:06 --> Language Class Initialized
DEBUG - 2011-08-09 09:14:06 --> Loader Class Initialized
DEBUG - 2011-08-09 09:14:06 --> Controller Class Initialized
DEBUG - 2011-08-09 09:14:06 --> Model Class Initialized
DEBUG - 2011-08-09 09:14:06 --> Model Class Initialized
DEBUG - 2011-08-09 09:14:06 --> Model Class Initialized
DEBUG - 2011-08-09 09:14:06 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-09 09:14:06 --> Database Driver Class Initialized
DEBUG - 2011-08-09 09:14:06 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-09 09:14:06 --> Helper loaded: url_helper
DEBUG - 2011-08-09 09:14:06 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-09 09:14:06 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-09 09:14:06 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-09 09:14:06 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-09 09:14:06 --> Final output sent to browser
DEBUG - 2011-08-09 09:14:06 --> Total execution time: 0.5777
DEBUG - 2011-08-09 09:14:26 --> Config Class Initialized
DEBUG - 2011-08-09 09:14:26 --> Hooks Class Initialized
DEBUG - 2011-08-09 09:14:26 --> Utf8 Class Initialized
DEBUG - 2011-08-09 09:14:26 --> UTF-8 Support Enabled
DEBUG - 2011-08-09 09:14:26 --> URI Class Initialized
DEBUG - 2011-08-09 09:14:26 --> Router Class Initialized
DEBUG - 2011-08-09 09:14:26 --> Output Class Initialized
DEBUG - 2011-08-09 09:14:26 --> Input Class Initialized
DEBUG - 2011-08-09 09:14:26 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-09 09:14:27 --> Language Class Initialized
DEBUG - 2011-08-09 09:14:27 --> Loader Class Initialized
DEBUG - 2011-08-09 09:14:27 --> Controller Class Initialized
DEBUG - 2011-08-09 09:14:27 --> Model Class Initialized
DEBUG - 2011-08-09 09:14:27 --> Model Class Initialized
DEBUG - 2011-08-09 09:14:27 --> Model Class Initialized
DEBUG - 2011-08-09 09:14:27 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-09 09:14:27 --> Database Driver Class Initialized
DEBUG - 2011-08-09 09:14:27 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-09 09:14:27 --> Helper loaded: url_helper
DEBUG - 2011-08-09 09:14:27 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-09 09:14:27 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-09 09:14:27 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-09 09:14:27 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-09 09:14:27 --> Final output sent to browser
DEBUG - 2011-08-09 09:14:27 --> Total execution time: 0.2723
DEBUG - 2011-08-09 09:14:56 --> Config Class Initialized
DEBUG - 2011-08-09 09:14:56 --> Hooks Class Initialized
DEBUG - 2011-08-09 09:14:56 --> Utf8 Class Initialized
DEBUG - 2011-08-09 09:14:56 --> UTF-8 Support Enabled
DEBUG - 2011-08-09 09:14:56 --> URI Class Initialized
DEBUG - 2011-08-09 09:14:56 --> Router Class Initialized
DEBUG - 2011-08-09 09:14:56 --> Output Class Initialized
DEBUG - 2011-08-09 09:14:56 --> Input Class Initialized
DEBUG - 2011-08-09 09:14:56 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-09 09:14:56 --> Language Class Initialized
DEBUG - 2011-08-09 09:14:56 --> Loader Class Initialized
DEBUG - 2011-08-09 09:14:56 --> Controller Class Initialized
DEBUG - 2011-08-09 09:14:56 --> Model Class Initialized
DEBUG - 2011-08-09 09:14:56 --> Model Class Initialized
DEBUG - 2011-08-09 09:14:56 --> Model Class Initialized
DEBUG - 2011-08-09 09:14:56 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-09 09:14:56 --> Database Driver Class Initialized
DEBUG - 2011-08-09 09:14:56 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-09 09:14:56 --> Helper loaded: url_helper
DEBUG - 2011-08-09 09:14:56 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-09 09:14:56 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-09 09:14:56 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-09 09:14:56 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-09 09:14:56 --> Final output sent to browser
DEBUG - 2011-08-09 09:14:56 --> Total execution time: 0.0552
DEBUG - 2011-08-09 09:15:05 --> Config Class Initialized
DEBUG - 2011-08-09 09:15:05 --> Hooks Class Initialized
DEBUG - 2011-08-09 09:15:05 --> Utf8 Class Initialized
DEBUG - 2011-08-09 09:15:05 --> UTF-8 Support Enabled
DEBUG - 2011-08-09 09:15:05 --> URI Class Initialized
DEBUG - 2011-08-09 09:15:05 --> Router Class Initialized
DEBUG - 2011-08-09 09:15:05 --> Output Class Initialized
DEBUG - 2011-08-09 09:15:05 --> Input Class Initialized
DEBUG - 2011-08-09 09:15:05 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-09 09:15:05 --> Language Class Initialized
DEBUG - 2011-08-09 09:15:05 --> Loader Class Initialized
DEBUG - 2011-08-09 09:15:05 --> Controller Class Initialized
DEBUG - 2011-08-09 09:15:05 --> Model Class Initialized
DEBUG - 2011-08-09 09:15:05 --> Model Class Initialized
DEBUG - 2011-08-09 09:15:05 --> Model Class Initialized
DEBUG - 2011-08-09 09:15:05 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-09 09:15:05 --> Database Driver Class Initialized
DEBUG - 2011-08-09 09:15:06 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-09 09:15:06 --> Helper loaded: url_helper
DEBUG - 2011-08-09 09:15:06 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-09 09:15:06 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-09 09:15:06 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-09 09:15:06 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-09 09:15:06 --> Final output sent to browser
DEBUG - 2011-08-09 09:15:06 --> Total execution time: 0.5363
DEBUG - 2011-08-09 09:15:08 --> Config Class Initialized
DEBUG - 2011-08-09 09:15:08 --> Hooks Class Initialized
DEBUG - 2011-08-09 09:15:08 --> Utf8 Class Initialized
DEBUG - 2011-08-09 09:15:08 --> UTF-8 Support Enabled
DEBUG - 2011-08-09 09:15:08 --> URI Class Initialized
DEBUG - 2011-08-09 09:15:08 --> Router Class Initialized
DEBUG - 2011-08-09 09:15:08 --> Output Class Initialized
DEBUG - 2011-08-09 09:15:08 --> Input Class Initialized
DEBUG - 2011-08-09 09:15:08 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-09 09:15:08 --> Language Class Initialized
DEBUG - 2011-08-09 09:15:08 --> Loader Class Initialized
DEBUG - 2011-08-09 09:15:08 --> Controller Class Initialized
DEBUG - 2011-08-09 09:15:08 --> Model Class Initialized
DEBUG - 2011-08-09 09:15:08 --> Model Class Initialized
DEBUG - 2011-08-09 09:15:08 --> Model Class Initialized
DEBUG - 2011-08-09 09:15:08 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-09 09:15:08 --> Database Driver Class Initialized
DEBUG - 2011-08-09 09:15:08 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-09 09:15:08 --> Helper loaded: url_helper
DEBUG - 2011-08-09 09:15:08 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-09 09:15:08 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-09 09:15:08 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-09 09:15:08 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-09 09:15:08 --> Final output sent to browser
DEBUG - 2011-08-09 09:15:08 --> Total execution time: 0.0519
DEBUG - 2011-08-09 09:15:17 --> Config Class Initialized
DEBUG - 2011-08-09 09:15:17 --> Hooks Class Initialized
DEBUG - 2011-08-09 09:15:17 --> Utf8 Class Initialized
DEBUG - 2011-08-09 09:15:17 --> UTF-8 Support Enabled
DEBUG - 2011-08-09 09:15:17 --> URI Class Initialized
DEBUG - 2011-08-09 09:15:17 --> Router Class Initialized
DEBUG - 2011-08-09 09:15:17 --> Output Class Initialized
DEBUG - 2011-08-09 09:15:17 --> Input Class Initialized
DEBUG - 2011-08-09 09:15:17 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-09 09:15:17 --> Language Class Initialized
DEBUG - 2011-08-09 09:15:17 --> Loader Class Initialized
DEBUG - 2011-08-09 09:15:17 --> Controller Class Initialized
DEBUG - 2011-08-09 09:15:17 --> Model Class Initialized
DEBUG - 2011-08-09 09:15:17 --> Model Class Initialized
DEBUG - 2011-08-09 09:15:17 --> Model Class Initialized
DEBUG - 2011-08-09 09:15:17 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-09 09:15:17 --> Database Driver Class Initialized
DEBUG - 2011-08-09 09:15:17 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-09 09:15:17 --> Helper loaded: url_helper
DEBUG - 2011-08-09 09:15:17 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-09 09:15:17 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-09 09:15:17 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-09 09:15:17 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-09 09:15:17 --> Final output sent to browser
DEBUG - 2011-08-09 09:15:17 --> Total execution time: 0.0656
DEBUG - 2011-08-09 09:15:39 --> Config Class Initialized
DEBUG - 2011-08-09 09:15:39 --> Hooks Class Initialized
DEBUG - 2011-08-09 09:15:39 --> Utf8 Class Initialized
DEBUG - 2011-08-09 09:15:39 --> UTF-8 Support Enabled
DEBUG - 2011-08-09 09:15:39 --> URI Class Initialized
DEBUG - 2011-08-09 09:15:39 --> Router Class Initialized
DEBUG - 2011-08-09 09:15:39 --> Output Class Initialized
DEBUG - 2011-08-09 09:15:39 --> Input Class Initialized
DEBUG - 2011-08-09 09:15:39 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-09 09:15:39 --> Language Class Initialized
DEBUG - 2011-08-09 09:15:39 --> Loader Class Initialized
DEBUG - 2011-08-09 09:15:39 --> Controller Class Initialized
DEBUG - 2011-08-09 09:15:39 --> Model Class Initialized
DEBUG - 2011-08-09 09:15:39 --> Model Class Initialized
DEBUG - 2011-08-09 09:15:39 --> Model Class Initialized
DEBUG - 2011-08-09 09:15:39 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-09 09:15:39 --> Database Driver Class Initialized
DEBUG - 2011-08-09 09:15:39 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-09 09:15:39 --> Helper loaded: url_helper
DEBUG - 2011-08-09 09:15:39 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-09 09:15:39 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-09 09:15:39 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-09 09:15:39 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-09 09:15:39 --> Final output sent to browser
DEBUG - 2011-08-09 09:15:39 --> Total execution time: 0.2289
DEBUG - 2011-08-09 09:15:42 --> Config Class Initialized
DEBUG - 2011-08-09 09:15:42 --> Hooks Class Initialized
DEBUG - 2011-08-09 09:15:42 --> Utf8 Class Initialized
DEBUG - 2011-08-09 09:15:42 --> UTF-8 Support Enabled
DEBUG - 2011-08-09 09:15:42 --> URI Class Initialized
DEBUG - 2011-08-09 09:15:42 --> Router Class Initialized
DEBUG - 2011-08-09 09:15:42 --> Output Class Initialized
DEBUG - 2011-08-09 09:15:42 --> Input Class Initialized
DEBUG - 2011-08-09 09:15:42 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-09 09:15:42 --> Language Class Initialized
DEBUG - 2011-08-09 09:15:42 --> Loader Class Initialized
DEBUG - 2011-08-09 09:15:42 --> Controller Class Initialized
DEBUG - 2011-08-09 09:15:42 --> Model Class Initialized
DEBUG - 2011-08-09 09:15:42 --> Model Class Initialized
DEBUG - 2011-08-09 09:15:42 --> Model Class Initialized
DEBUG - 2011-08-09 09:15:42 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-09 09:15:42 --> Database Driver Class Initialized
DEBUG - 2011-08-09 09:15:42 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-09 09:15:42 --> Helper loaded: url_helper
DEBUG - 2011-08-09 09:15:42 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-09 09:15:42 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-09 09:15:42 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-09 09:15:42 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-09 09:15:42 --> Final output sent to browser
DEBUG - 2011-08-09 09:15:42 --> Total execution time: 0.1119
DEBUG - 2011-08-09 09:16:00 --> Config Class Initialized
DEBUG - 2011-08-09 09:16:00 --> Hooks Class Initialized
DEBUG - 2011-08-09 09:16:00 --> Utf8 Class Initialized
DEBUG - 2011-08-09 09:16:00 --> UTF-8 Support Enabled
DEBUG - 2011-08-09 09:16:00 --> URI Class Initialized
DEBUG - 2011-08-09 09:16:00 --> Router Class Initialized
DEBUG - 2011-08-09 09:16:00 --> Output Class Initialized
DEBUG - 2011-08-09 09:16:00 --> Input Class Initialized
DEBUG - 2011-08-09 09:16:00 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-09 09:16:00 --> Language Class Initialized
DEBUG - 2011-08-09 09:16:00 --> Loader Class Initialized
DEBUG - 2011-08-09 09:16:00 --> Controller Class Initialized
DEBUG - 2011-08-09 09:16:00 --> Model Class Initialized
DEBUG - 2011-08-09 09:16:00 --> Model Class Initialized
DEBUG - 2011-08-09 09:16:00 --> Model Class Initialized
DEBUG - 2011-08-09 09:16:00 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-09 09:16:00 --> Database Driver Class Initialized
DEBUG - 2011-08-09 09:16:00 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-09 09:16:00 --> Helper loaded: url_helper
DEBUG - 2011-08-09 09:16:00 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-09 09:16:00 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-09 09:16:00 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-09 09:16:00 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-09 09:16:00 --> Final output sent to browser
DEBUG - 2011-08-09 09:16:00 --> Total execution time: 0.2547
DEBUG - 2011-08-09 09:16:06 --> Config Class Initialized
DEBUG - 2011-08-09 09:16:06 --> Hooks Class Initialized
DEBUG - 2011-08-09 09:16:06 --> Utf8 Class Initialized
DEBUG - 2011-08-09 09:16:06 --> UTF-8 Support Enabled
DEBUG - 2011-08-09 09:16:06 --> URI Class Initialized
DEBUG - 2011-08-09 09:16:06 --> Router Class Initialized
DEBUG - 2011-08-09 09:16:06 --> Output Class Initialized
DEBUG - 2011-08-09 09:16:06 --> Input Class Initialized
DEBUG - 2011-08-09 09:16:06 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-09 09:16:06 --> Language Class Initialized
DEBUG - 2011-08-09 09:16:06 --> Loader Class Initialized
DEBUG - 2011-08-09 09:16:06 --> Controller Class Initialized
DEBUG - 2011-08-09 09:16:06 --> Model Class Initialized
DEBUG - 2011-08-09 09:16:06 --> Model Class Initialized
DEBUG - 2011-08-09 09:16:06 --> Model Class Initialized
DEBUG - 2011-08-09 09:16:06 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-09 09:16:06 --> Database Driver Class Initialized
DEBUG - 2011-08-09 09:16:06 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-09 09:16:06 --> Helper loaded: url_helper
DEBUG - 2011-08-09 09:16:06 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-09 09:16:06 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-09 09:16:06 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-09 09:16:06 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-09 09:16:06 --> Final output sent to browser
DEBUG - 2011-08-09 09:16:06 --> Total execution time: 0.0981
DEBUG - 2011-08-09 09:16:23 --> Config Class Initialized
DEBUG - 2011-08-09 09:16:23 --> Hooks Class Initialized
DEBUG - 2011-08-09 09:16:23 --> Utf8 Class Initialized
DEBUG - 2011-08-09 09:16:23 --> UTF-8 Support Enabled
DEBUG - 2011-08-09 09:16:23 --> URI Class Initialized
DEBUG - 2011-08-09 09:16:23 --> Router Class Initialized
DEBUG - 2011-08-09 09:16:23 --> Output Class Initialized
DEBUG - 2011-08-09 09:16:23 --> Input Class Initialized
DEBUG - 2011-08-09 09:16:23 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-09 09:16:23 --> Language Class Initialized
DEBUG - 2011-08-09 09:16:23 --> Loader Class Initialized
DEBUG - 2011-08-09 09:16:23 --> Controller Class Initialized
DEBUG - 2011-08-09 09:16:23 --> Model Class Initialized
DEBUG - 2011-08-09 09:16:23 --> Model Class Initialized
DEBUG - 2011-08-09 09:16:23 --> Model Class Initialized
DEBUG - 2011-08-09 09:16:23 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-09 09:16:23 --> Database Driver Class Initialized
DEBUG - 2011-08-09 09:16:23 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-09 09:16:23 --> Helper loaded: url_helper
DEBUG - 2011-08-09 09:16:23 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-09 09:16:23 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-09 09:16:23 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-09 09:16:23 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-09 09:16:23 --> Final output sent to browser
DEBUG - 2011-08-09 09:16:23 --> Total execution time: 0.4734
DEBUG - 2011-08-09 09:16:41 --> Config Class Initialized
DEBUG - 2011-08-09 09:16:41 --> Hooks Class Initialized
DEBUG - 2011-08-09 09:16:41 --> Utf8 Class Initialized
DEBUG - 2011-08-09 09:16:41 --> UTF-8 Support Enabled
DEBUG - 2011-08-09 09:16:41 --> URI Class Initialized
DEBUG - 2011-08-09 09:16:41 --> Router Class Initialized
DEBUG - 2011-08-09 09:16:41 --> Output Class Initialized
DEBUG - 2011-08-09 09:16:41 --> Input Class Initialized
DEBUG - 2011-08-09 09:16:41 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-09 09:16:41 --> Language Class Initialized
DEBUG - 2011-08-09 09:16:41 --> Loader Class Initialized
DEBUG - 2011-08-09 09:16:41 --> Controller Class Initialized
DEBUG - 2011-08-09 09:16:41 --> Model Class Initialized
DEBUG - 2011-08-09 09:16:41 --> Model Class Initialized
DEBUG - 2011-08-09 09:16:41 --> Model Class Initialized
DEBUG - 2011-08-09 09:16:41 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-09 09:16:41 --> Database Driver Class Initialized
DEBUG - 2011-08-09 09:16:42 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-09 09:16:42 --> Helper loaded: url_helper
DEBUG - 2011-08-09 09:16:42 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-09 09:16:42 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-09 09:16:42 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-09 09:16:42 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-09 09:16:42 --> Final output sent to browser
DEBUG - 2011-08-09 09:16:42 --> Total execution time: 0.3823
DEBUG - 2011-08-09 09:17:13 --> Config Class Initialized
DEBUG - 2011-08-09 09:17:13 --> Hooks Class Initialized
DEBUG - 2011-08-09 09:17:13 --> Utf8 Class Initialized
DEBUG - 2011-08-09 09:17:13 --> UTF-8 Support Enabled
DEBUG - 2011-08-09 09:17:13 --> URI Class Initialized
DEBUG - 2011-08-09 09:17:13 --> Router Class Initialized
DEBUG - 2011-08-09 09:17:13 --> Output Class Initialized
DEBUG - 2011-08-09 09:17:13 --> Input Class Initialized
DEBUG - 2011-08-09 09:17:13 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-09 09:17:13 --> Language Class Initialized
DEBUG - 2011-08-09 09:17:13 --> Loader Class Initialized
DEBUG - 2011-08-09 09:17:13 --> Controller Class Initialized
DEBUG - 2011-08-09 09:17:13 --> Model Class Initialized
DEBUG - 2011-08-09 09:17:13 --> Model Class Initialized
DEBUG - 2011-08-09 09:17:13 --> Model Class Initialized
DEBUG - 2011-08-09 09:17:13 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-09 09:17:13 --> Database Driver Class Initialized
DEBUG - 2011-08-09 09:17:13 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-09 09:17:13 --> Helper loaded: url_helper
DEBUG - 2011-08-09 09:17:13 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-09 09:17:13 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-09 09:17:13 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-09 09:17:13 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-09 09:17:13 --> Final output sent to browser
DEBUG - 2011-08-09 09:17:13 --> Total execution time: 0.0456
DEBUG - 2011-08-09 09:17:25 --> Config Class Initialized
DEBUG - 2011-08-09 09:17:25 --> Hooks Class Initialized
DEBUG - 2011-08-09 09:17:25 --> Utf8 Class Initialized
DEBUG - 2011-08-09 09:17:25 --> UTF-8 Support Enabled
DEBUG - 2011-08-09 09:17:25 --> URI Class Initialized
DEBUG - 2011-08-09 09:17:25 --> Router Class Initialized
DEBUG - 2011-08-09 09:17:25 --> Output Class Initialized
DEBUG - 2011-08-09 09:17:25 --> Input Class Initialized
DEBUG - 2011-08-09 09:17:25 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-09 09:17:25 --> Language Class Initialized
DEBUG - 2011-08-09 09:17:25 --> Loader Class Initialized
DEBUG - 2011-08-09 09:17:25 --> Controller Class Initialized
DEBUG - 2011-08-09 09:17:25 --> Model Class Initialized
DEBUG - 2011-08-09 09:17:25 --> Model Class Initialized
DEBUG - 2011-08-09 09:17:25 --> Model Class Initialized
DEBUG - 2011-08-09 09:17:25 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-09 09:17:25 --> Database Driver Class Initialized
DEBUG - 2011-08-09 09:17:25 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-09 09:17:25 --> Helper loaded: url_helper
DEBUG - 2011-08-09 09:17:25 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-09 09:17:25 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-09 09:17:25 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-09 09:17:25 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-09 09:17:25 --> Final output sent to browser
DEBUG - 2011-08-09 09:17:25 --> Total execution time: 0.9778
DEBUG - 2011-08-09 09:17:50 --> Config Class Initialized
DEBUG - 2011-08-09 09:17:50 --> Hooks Class Initialized
DEBUG - 2011-08-09 09:17:50 --> Utf8 Class Initialized
DEBUG - 2011-08-09 09:17:50 --> UTF-8 Support Enabled
DEBUG - 2011-08-09 09:17:50 --> URI Class Initialized
DEBUG - 2011-08-09 09:17:50 --> Router Class Initialized
DEBUG - 2011-08-09 09:17:50 --> Output Class Initialized
DEBUG - 2011-08-09 09:17:50 --> Input Class Initialized
DEBUG - 2011-08-09 09:17:50 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-09 09:17:50 --> Language Class Initialized
DEBUG - 2011-08-09 09:17:50 --> Loader Class Initialized
DEBUG - 2011-08-09 09:17:50 --> Controller Class Initialized
DEBUG - 2011-08-09 09:17:50 --> Model Class Initialized
DEBUG - 2011-08-09 09:17:50 --> Model Class Initialized
DEBUG - 2011-08-09 09:17:50 --> Model Class Initialized
DEBUG - 2011-08-09 09:17:50 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-09 09:17:50 --> Database Driver Class Initialized
DEBUG - 2011-08-09 09:17:50 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-09 09:17:50 --> Helper loaded: url_helper
DEBUG - 2011-08-09 09:17:50 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-09 09:17:50 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-09 09:17:50 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-09 09:17:50 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-09 09:17:50 --> Final output sent to browser
DEBUG - 2011-08-09 09:17:50 --> Total execution time: 0.7236
DEBUG - 2011-08-09 09:18:12 --> Config Class Initialized
DEBUG - 2011-08-09 09:18:12 --> Hooks Class Initialized
DEBUG - 2011-08-09 09:18:12 --> Utf8 Class Initialized
DEBUG - 2011-08-09 09:18:12 --> UTF-8 Support Enabled
DEBUG - 2011-08-09 09:18:12 --> URI Class Initialized
DEBUG - 2011-08-09 09:18:12 --> Router Class Initialized
DEBUG - 2011-08-09 09:18:12 --> Output Class Initialized
DEBUG - 2011-08-09 09:18:12 --> Input Class Initialized
DEBUG - 2011-08-09 09:18:12 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-09 09:18:12 --> Language Class Initialized
DEBUG - 2011-08-09 09:18:12 --> Loader Class Initialized
DEBUG - 2011-08-09 09:18:12 --> Controller Class Initialized
DEBUG - 2011-08-09 09:18:12 --> Model Class Initialized
DEBUG - 2011-08-09 09:18:12 --> Model Class Initialized
DEBUG - 2011-08-09 09:18:12 --> Model Class Initialized
DEBUG - 2011-08-09 09:18:12 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-09 09:18:12 --> Database Driver Class Initialized
DEBUG - 2011-08-09 09:18:12 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-09 09:18:12 --> Helper loaded: url_helper
DEBUG - 2011-08-09 09:18:12 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-09 09:18:12 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-09 09:18:12 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-09 09:18:12 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-09 09:18:12 --> Final output sent to browser
DEBUG - 2011-08-09 09:18:12 --> Total execution time: 0.3667
DEBUG - 2011-08-09 09:18:32 --> Config Class Initialized
DEBUG - 2011-08-09 09:18:32 --> Hooks Class Initialized
DEBUG - 2011-08-09 09:18:32 --> Utf8 Class Initialized
DEBUG - 2011-08-09 09:18:32 --> UTF-8 Support Enabled
DEBUG - 2011-08-09 09:18:32 --> URI Class Initialized
DEBUG - 2011-08-09 09:18:32 --> Router Class Initialized
DEBUG - 2011-08-09 09:18:32 --> Output Class Initialized
DEBUG - 2011-08-09 09:18:32 --> Input Class Initialized
DEBUG - 2011-08-09 09:18:32 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-09 09:18:32 --> Language Class Initialized
DEBUG - 2011-08-09 09:18:32 --> Loader Class Initialized
DEBUG - 2011-08-09 09:18:32 --> Controller Class Initialized
DEBUG - 2011-08-09 09:18:32 --> Model Class Initialized
DEBUG - 2011-08-09 09:18:32 --> Model Class Initialized
DEBUG - 2011-08-09 09:18:32 --> Model Class Initialized
DEBUG - 2011-08-09 09:18:32 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-09 09:18:32 --> Database Driver Class Initialized
DEBUG - 2011-08-09 09:18:32 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-09 09:18:32 --> Helper loaded: url_helper
DEBUG - 2011-08-09 09:18:32 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-09 09:18:32 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-09 09:18:32 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-09 09:18:32 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-09 09:18:32 --> Final output sent to browser
DEBUG - 2011-08-09 09:18:32 --> Total execution time: 0.1494
DEBUG - 2011-08-09 09:20:35 --> Config Class Initialized
DEBUG - 2011-08-09 09:20:35 --> Hooks Class Initialized
DEBUG - 2011-08-09 09:20:35 --> Utf8 Class Initialized
DEBUG - 2011-08-09 09:20:35 --> UTF-8 Support Enabled
DEBUG - 2011-08-09 09:20:35 --> URI Class Initialized
DEBUG - 2011-08-09 09:20:35 --> Router Class Initialized
DEBUG - 2011-08-09 09:20:35 --> Output Class Initialized
DEBUG - 2011-08-09 09:20:35 --> Input Class Initialized
DEBUG - 2011-08-09 09:20:35 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-09 09:20:35 --> Language Class Initialized
DEBUG - 2011-08-09 09:20:35 --> Loader Class Initialized
DEBUG - 2011-08-09 09:20:35 --> Controller Class Initialized
DEBUG - 2011-08-09 09:20:35 --> Model Class Initialized
DEBUG - 2011-08-09 09:20:35 --> Model Class Initialized
DEBUG - 2011-08-09 09:20:35 --> Model Class Initialized
DEBUG - 2011-08-09 09:20:35 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-09 09:20:35 --> Database Driver Class Initialized
DEBUG - 2011-08-09 09:20:35 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-09 09:20:35 --> Helper loaded: url_helper
DEBUG - 2011-08-09 09:20:35 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-09 09:20:35 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-09 09:20:35 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-09 09:20:35 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-09 09:20:35 --> Final output sent to browser
DEBUG - 2011-08-09 09:20:35 --> Total execution time: 0.0499
DEBUG - 2011-08-09 09:20:47 --> Config Class Initialized
DEBUG - 2011-08-09 09:20:47 --> Hooks Class Initialized
DEBUG - 2011-08-09 09:20:47 --> Utf8 Class Initialized
DEBUG - 2011-08-09 09:20:47 --> UTF-8 Support Enabled
DEBUG - 2011-08-09 09:20:47 --> URI Class Initialized
DEBUG - 2011-08-09 09:20:47 --> Router Class Initialized
DEBUG - 2011-08-09 09:20:47 --> Output Class Initialized
DEBUG - 2011-08-09 09:20:47 --> Input Class Initialized
DEBUG - 2011-08-09 09:20:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-09 09:20:47 --> Language Class Initialized
DEBUG - 2011-08-09 09:20:47 --> Loader Class Initialized
DEBUG - 2011-08-09 09:20:47 --> Controller Class Initialized
DEBUG - 2011-08-09 09:20:47 --> Model Class Initialized
DEBUG - 2011-08-09 09:20:47 --> Model Class Initialized
DEBUG - 2011-08-09 09:20:47 --> Model Class Initialized
DEBUG - 2011-08-09 09:20:47 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-09 09:20:47 --> Database Driver Class Initialized
DEBUG - 2011-08-09 09:20:47 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-09 09:20:47 --> Helper loaded: url_helper
DEBUG - 2011-08-09 09:20:47 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-09 09:20:47 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-09 09:20:47 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-09 09:20:47 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-09 09:20:47 --> Final output sent to browser
DEBUG - 2011-08-09 09:20:47 --> Total execution time: 0.1415
DEBUG - 2011-08-09 09:20:48 --> Config Class Initialized
DEBUG - 2011-08-09 09:20:48 --> Hooks Class Initialized
DEBUG - 2011-08-09 09:20:48 --> Utf8 Class Initialized
DEBUG - 2011-08-09 09:20:48 --> UTF-8 Support Enabled
DEBUG - 2011-08-09 09:20:48 --> URI Class Initialized
DEBUG - 2011-08-09 09:20:48 --> Router Class Initialized
DEBUG - 2011-08-09 09:20:48 --> Output Class Initialized
DEBUG - 2011-08-09 09:20:48 --> Input Class Initialized
DEBUG - 2011-08-09 09:20:48 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-09 09:20:48 --> Language Class Initialized
DEBUG - 2011-08-09 09:20:48 --> Loader Class Initialized
DEBUG - 2011-08-09 09:20:48 --> Controller Class Initialized
DEBUG - 2011-08-09 09:20:48 --> Model Class Initialized
DEBUG - 2011-08-09 09:20:48 --> Model Class Initialized
DEBUG - 2011-08-09 09:20:48 --> Model Class Initialized
DEBUG - 2011-08-09 09:20:48 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-09 09:20:48 --> Database Driver Class Initialized
DEBUG - 2011-08-09 09:20:48 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-09 09:20:48 --> Helper loaded: url_helper
DEBUG - 2011-08-09 09:20:48 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-09 09:20:48 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-09 09:20:48 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-09 09:20:48 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-09 09:20:48 --> Final output sent to browser
DEBUG - 2011-08-09 09:20:48 --> Total execution time: 0.0479
DEBUG - 2011-08-09 09:20:54 --> Config Class Initialized
DEBUG - 2011-08-09 09:20:54 --> Hooks Class Initialized
DEBUG - 2011-08-09 09:20:54 --> Utf8 Class Initialized
DEBUG - 2011-08-09 09:20:54 --> UTF-8 Support Enabled
DEBUG - 2011-08-09 09:20:54 --> URI Class Initialized
DEBUG - 2011-08-09 09:20:54 --> Router Class Initialized
DEBUG - 2011-08-09 09:20:54 --> Output Class Initialized
DEBUG - 2011-08-09 09:20:54 --> Input Class Initialized
DEBUG - 2011-08-09 09:20:54 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-09 09:20:54 --> Language Class Initialized
DEBUG - 2011-08-09 09:20:54 --> Loader Class Initialized
DEBUG - 2011-08-09 09:20:54 --> Controller Class Initialized
DEBUG - 2011-08-09 09:20:54 --> Model Class Initialized
DEBUG - 2011-08-09 09:20:54 --> Model Class Initialized
DEBUG - 2011-08-09 09:20:54 --> Model Class Initialized
DEBUG - 2011-08-09 09:20:54 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-09 09:20:54 --> Database Driver Class Initialized
DEBUG - 2011-08-09 09:20:54 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-09 09:20:54 --> Helper loaded: url_helper
DEBUG - 2011-08-09 09:20:54 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-09 09:20:54 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-09 09:20:54 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-09 09:20:54 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-09 09:20:54 --> Final output sent to browser
DEBUG - 2011-08-09 09:20:54 --> Total execution time: 0.1575
DEBUG - 2011-08-09 09:20:58 --> Config Class Initialized
DEBUG - 2011-08-09 09:20:58 --> Hooks Class Initialized
DEBUG - 2011-08-09 09:20:58 --> Utf8 Class Initialized
DEBUG - 2011-08-09 09:20:58 --> UTF-8 Support Enabled
DEBUG - 2011-08-09 09:20:58 --> URI Class Initialized
DEBUG - 2011-08-09 09:20:58 --> Router Class Initialized
DEBUG - 2011-08-09 09:20:58 --> Output Class Initialized
DEBUG - 2011-08-09 09:20:58 --> Input Class Initialized
DEBUG - 2011-08-09 09:20:58 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-09 09:20:58 --> Language Class Initialized
DEBUG - 2011-08-09 09:20:58 --> Loader Class Initialized
DEBUG - 2011-08-09 09:20:58 --> Controller Class Initialized
DEBUG - 2011-08-09 09:20:58 --> Model Class Initialized
DEBUG - 2011-08-09 09:20:58 --> Model Class Initialized
DEBUG - 2011-08-09 09:20:58 --> Model Class Initialized
DEBUG - 2011-08-09 09:20:58 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-09 09:20:58 --> Database Driver Class Initialized
DEBUG - 2011-08-09 09:20:58 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-09 09:20:58 --> Helper loaded: url_helper
DEBUG - 2011-08-09 09:20:58 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-09 09:20:58 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-09 09:20:58 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-09 09:20:58 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-09 09:20:58 --> Final output sent to browser
DEBUG - 2011-08-09 09:20:58 --> Total execution time: 0.0527
DEBUG - 2011-08-09 09:23:26 --> Config Class Initialized
DEBUG - 2011-08-09 09:23:26 --> Hooks Class Initialized
DEBUG - 2011-08-09 09:23:26 --> Utf8 Class Initialized
DEBUG - 2011-08-09 09:23:26 --> UTF-8 Support Enabled
DEBUG - 2011-08-09 09:23:26 --> URI Class Initialized
DEBUG - 2011-08-09 09:23:26 --> Router Class Initialized
DEBUG - 2011-08-09 09:23:26 --> Output Class Initialized
DEBUG - 2011-08-09 09:23:26 --> Input Class Initialized
DEBUG - 2011-08-09 09:23:26 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-09 09:23:26 --> Language Class Initialized
DEBUG - 2011-08-09 09:23:26 --> Loader Class Initialized
DEBUG - 2011-08-09 09:23:26 --> Controller Class Initialized
ERROR - 2011-08-09 09:23:26 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-09 09:23:26 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-09 09:23:26 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-09 09:23:26 --> Model Class Initialized
DEBUG - 2011-08-09 09:23:26 --> Model Class Initialized
DEBUG - 2011-08-09 09:23:26 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-09 09:23:26 --> Database Driver Class Initialized
DEBUG - 2011-08-09 09:23:26 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-09 09:23:26 --> Helper loaded: url_helper
DEBUG - 2011-08-09 09:23:26 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-09 09:23:26 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-09 09:23:26 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-09 09:23:26 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-09 09:23:26 --> Final output sent to browser
DEBUG - 2011-08-09 09:23:26 --> Total execution time: 0.0449
DEBUG - 2011-08-09 09:23:43 --> Config Class Initialized
DEBUG - 2011-08-09 09:23:43 --> Hooks Class Initialized
DEBUG - 2011-08-09 09:23:43 --> Utf8 Class Initialized
DEBUG - 2011-08-09 09:23:43 --> UTF-8 Support Enabled
DEBUG - 2011-08-09 09:23:43 --> URI Class Initialized
DEBUG - 2011-08-09 09:23:43 --> Router Class Initialized
DEBUG - 2011-08-09 09:23:43 --> Output Class Initialized
DEBUG - 2011-08-09 09:23:43 --> Input Class Initialized
DEBUG - 2011-08-09 09:23:43 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-09 09:23:43 --> Language Class Initialized
DEBUG - 2011-08-09 09:23:43 --> Loader Class Initialized
DEBUG - 2011-08-09 09:23:43 --> Controller Class Initialized
DEBUG - 2011-08-09 09:23:43 --> Model Class Initialized
DEBUG - 2011-08-09 09:23:43 --> Model Class Initialized
DEBUG - 2011-08-09 09:23:43 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-09 09:23:43 --> Database Driver Class Initialized
DEBUG - 2011-08-09 09:23:45 --> Final output sent to browser
DEBUG - 2011-08-09 09:23:45 --> Total execution time: 2.0558
DEBUG - 2011-08-09 09:24:12 --> Config Class Initialized
DEBUG - 2011-08-09 09:24:12 --> Hooks Class Initialized
DEBUG - 2011-08-09 09:24:12 --> Utf8 Class Initialized
DEBUG - 2011-08-09 09:24:12 --> UTF-8 Support Enabled
DEBUG - 2011-08-09 09:24:12 --> URI Class Initialized
DEBUG - 2011-08-09 09:24:12 --> Router Class Initialized
ERROR - 2011-08-09 09:24:12 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-09 09:24:50 --> Config Class Initialized
DEBUG - 2011-08-09 09:24:50 --> Hooks Class Initialized
DEBUG - 2011-08-09 09:24:50 --> Utf8 Class Initialized
DEBUG - 2011-08-09 09:24:50 --> UTF-8 Support Enabled
DEBUG - 2011-08-09 09:24:50 --> URI Class Initialized
DEBUG - 2011-08-09 09:24:50 --> Router Class Initialized
ERROR - 2011-08-09 09:24:50 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-09 09:32:26 --> Config Class Initialized
DEBUG - 2011-08-09 09:32:26 --> Hooks Class Initialized
DEBUG - 2011-08-09 09:32:26 --> Utf8 Class Initialized
DEBUG - 2011-08-09 09:32:26 --> UTF-8 Support Enabled
DEBUG - 2011-08-09 09:32:26 --> URI Class Initialized
DEBUG - 2011-08-09 09:32:26 --> Router Class Initialized
ERROR - 2011-08-09 09:32:26 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-09 09:35:51 --> Config Class Initialized
DEBUG - 2011-08-09 09:35:51 --> Hooks Class Initialized
DEBUG - 2011-08-09 09:35:51 --> Utf8 Class Initialized
DEBUG - 2011-08-09 09:35:51 --> UTF-8 Support Enabled
DEBUG - 2011-08-09 09:35:51 --> URI Class Initialized
DEBUG - 2011-08-09 09:35:51 --> Router Class Initialized
DEBUG - 2011-08-09 09:35:51 --> Output Class Initialized
DEBUG - 2011-08-09 09:35:51 --> Input Class Initialized
DEBUG - 2011-08-09 09:35:51 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-09 09:35:51 --> Language Class Initialized
DEBUG - 2011-08-09 09:35:51 --> Loader Class Initialized
DEBUG - 2011-08-09 09:35:51 --> Controller Class Initialized
DEBUG - 2011-08-09 09:35:51 --> Model Class Initialized
DEBUG - 2011-08-09 09:35:51 --> Model Class Initialized
DEBUG - 2011-08-09 09:35:51 --> Model Class Initialized
DEBUG - 2011-08-09 09:35:51 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-09 09:35:51 --> Database Driver Class Initialized
DEBUG - 2011-08-09 09:35:51 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-09 09:35:51 --> Helper loaded: url_helper
DEBUG - 2011-08-09 09:35:51 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-09 09:35:51 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-09 09:35:51 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-09 09:35:51 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-09 09:35:51 --> Final output sent to browser
DEBUG - 2011-08-09 09:35:51 --> Total execution time: 0.0451
DEBUG - 2011-08-09 09:35:53 --> Config Class Initialized
DEBUG - 2011-08-09 09:35:53 --> Hooks Class Initialized
DEBUG - 2011-08-09 09:35:53 --> Utf8 Class Initialized
DEBUG - 2011-08-09 09:35:53 --> UTF-8 Support Enabled
DEBUG - 2011-08-09 09:35:53 --> URI Class Initialized
DEBUG - 2011-08-09 09:35:53 --> Router Class Initialized
ERROR - 2011-08-09 09:35:53 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-09 09:35:53 --> Config Class Initialized
DEBUG - 2011-08-09 09:35:53 --> Hooks Class Initialized
DEBUG - 2011-08-09 09:35:53 --> Utf8 Class Initialized
DEBUG - 2011-08-09 09:35:53 --> UTF-8 Support Enabled
DEBUG - 2011-08-09 09:35:53 --> URI Class Initialized
DEBUG - 2011-08-09 09:35:53 --> Router Class Initialized
ERROR - 2011-08-09 09:35:53 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-09 09:36:11 --> Config Class Initialized
DEBUG - 2011-08-09 09:36:11 --> Hooks Class Initialized
DEBUG - 2011-08-09 09:36:11 --> Utf8 Class Initialized
DEBUG - 2011-08-09 09:36:11 --> UTF-8 Support Enabled
DEBUG - 2011-08-09 09:36:11 --> URI Class Initialized
DEBUG - 2011-08-09 09:36:11 --> Router Class Initialized
DEBUG - 2011-08-09 09:36:11 --> Output Class Initialized
DEBUG - 2011-08-09 09:36:11 --> Input Class Initialized
DEBUG - 2011-08-09 09:36:11 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-09 09:36:11 --> Language Class Initialized
DEBUG - 2011-08-09 09:36:11 --> Loader Class Initialized
DEBUG - 2011-08-09 09:36:11 --> Controller Class Initialized
ERROR - 2011-08-09 09:36:11 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-09 09:36:11 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-09 09:36:11 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-09 09:36:11 --> Model Class Initialized
DEBUG - 2011-08-09 09:36:11 --> Model Class Initialized
DEBUG - 2011-08-09 09:36:11 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-09 09:36:11 --> Database Driver Class Initialized
DEBUG - 2011-08-09 09:36:11 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-09 09:36:11 --> Helper loaded: url_helper
DEBUG - 2011-08-09 09:36:11 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-09 09:36:11 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-09 09:36:11 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-09 09:36:11 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-09 09:36:11 --> Final output sent to browser
DEBUG - 2011-08-09 09:36:11 --> Total execution time: 0.0294
DEBUG - 2011-08-09 09:36:12 --> Config Class Initialized
DEBUG - 2011-08-09 09:36:12 --> Hooks Class Initialized
DEBUG - 2011-08-09 09:36:12 --> Utf8 Class Initialized
DEBUG - 2011-08-09 09:36:12 --> UTF-8 Support Enabled
DEBUG - 2011-08-09 09:36:12 --> URI Class Initialized
DEBUG - 2011-08-09 09:36:12 --> Router Class Initialized
DEBUG - 2011-08-09 09:36:12 --> Output Class Initialized
DEBUG - 2011-08-09 09:36:12 --> Input Class Initialized
DEBUG - 2011-08-09 09:36:12 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-09 09:36:12 --> Language Class Initialized
DEBUG - 2011-08-09 09:36:12 --> Loader Class Initialized
DEBUG - 2011-08-09 09:36:12 --> Controller Class Initialized
DEBUG - 2011-08-09 09:36:12 --> Model Class Initialized
DEBUG - 2011-08-09 09:36:12 --> Model Class Initialized
DEBUG - 2011-08-09 09:36:12 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-09 09:36:12 --> Database Driver Class Initialized
DEBUG - 2011-08-09 09:36:13 --> Final output sent to browser
DEBUG - 2011-08-09 09:36:13 --> Total execution time: 1.5123
DEBUG - 2011-08-09 09:45:54 --> Config Class Initialized
DEBUG - 2011-08-09 09:45:54 --> Hooks Class Initialized
DEBUG - 2011-08-09 09:45:54 --> Utf8 Class Initialized
DEBUG - 2011-08-09 09:45:54 --> UTF-8 Support Enabled
DEBUG - 2011-08-09 09:45:54 --> URI Class Initialized
DEBUG - 2011-08-09 09:45:54 --> Router Class Initialized
DEBUG - 2011-08-09 09:45:54 --> Output Class Initialized
DEBUG - 2011-08-09 09:45:54 --> Input Class Initialized
DEBUG - 2011-08-09 09:45:54 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-09 09:45:54 --> Language Class Initialized
DEBUG - 2011-08-09 09:45:54 --> Loader Class Initialized
DEBUG - 2011-08-09 09:45:54 --> Controller Class Initialized
ERROR - 2011-08-09 09:45:54 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-09 09:45:54 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-09 09:45:54 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-09 09:45:54 --> Model Class Initialized
DEBUG - 2011-08-09 09:45:54 --> Model Class Initialized
DEBUG - 2011-08-09 09:45:54 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-09 09:45:54 --> Database Driver Class Initialized
DEBUG - 2011-08-09 09:45:54 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-09 09:45:54 --> Helper loaded: url_helper
DEBUG - 2011-08-09 09:45:54 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-09 09:45:54 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-09 09:45:54 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-09 09:45:54 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-09 09:45:54 --> Final output sent to browser
DEBUG - 2011-08-09 09:45:54 --> Total execution time: 0.0716
DEBUG - 2011-08-09 09:45:55 --> Config Class Initialized
DEBUG - 2011-08-09 09:45:55 --> Hooks Class Initialized
DEBUG - 2011-08-09 09:45:55 --> Utf8 Class Initialized
DEBUG - 2011-08-09 09:45:55 --> UTF-8 Support Enabled
DEBUG - 2011-08-09 09:45:55 --> URI Class Initialized
DEBUG - 2011-08-09 09:45:55 --> Router Class Initialized
DEBUG - 2011-08-09 09:45:55 --> Output Class Initialized
DEBUG - 2011-08-09 09:45:55 --> Input Class Initialized
DEBUG - 2011-08-09 09:45:55 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-09 09:45:55 --> Language Class Initialized
DEBUG - 2011-08-09 09:45:55 --> Loader Class Initialized
DEBUG - 2011-08-09 09:45:55 --> Controller Class Initialized
DEBUG - 2011-08-09 09:45:55 --> Model Class Initialized
DEBUG - 2011-08-09 09:45:55 --> Model Class Initialized
DEBUG - 2011-08-09 09:45:55 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-09 09:45:55 --> Database Driver Class Initialized
DEBUG - 2011-08-09 09:45:56 --> Final output sent to browser
DEBUG - 2011-08-09 09:45:56 --> Total execution time: 0.7129
DEBUG - 2011-08-09 09:45:58 --> Config Class Initialized
DEBUG - 2011-08-09 09:45:58 --> Hooks Class Initialized
DEBUG - 2011-08-09 09:45:58 --> Utf8 Class Initialized
DEBUG - 2011-08-09 09:45:58 --> UTF-8 Support Enabled
DEBUG - 2011-08-09 09:45:58 --> URI Class Initialized
DEBUG - 2011-08-09 09:45:58 --> Router Class Initialized
DEBUG - 2011-08-09 09:45:58 --> Output Class Initialized
DEBUG - 2011-08-09 09:45:58 --> Input Class Initialized
DEBUG - 2011-08-09 09:45:58 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-09 09:45:58 --> Language Class Initialized
DEBUG - 2011-08-09 09:45:58 --> Loader Class Initialized
DEBUG - 2011-08-09 09:45:58 --> Controller Class Initialized
ERROR - 2011-08-09 09:45:58 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-09 09:45:58 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-09 09:45:58 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-09 09:45:58 --> Model Class Initialized
DEBUG - 2011-08-09 09:45:58 --> Model Class Initialized
DEBUG - 2011-08-09 09:45:58 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-09 09:45:58 --> Database Driver Class Initialized
DEBUG - 2011-08-09 09:45:58 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-09 09:45:58 --> Helper loaded: url_helper
DEBUG - 2011-08-09 09:45:58 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-09 09:45:58 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-09 09:45:58 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-09 09:45:58 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-09 09:45:58 --> Final output sent to browser
DEBUG - 2011-08-09 09:45:58 --> Total execution time: 0.0295
DEBUG - 2011-08-09 09:46:07 --> Config Class Initialized
DEBUG - 2011-08-09 09:46:07 --> Hooks Class Initialized
DEBUG - 2011-08-09 09:46:07 --> Utf8 Class Initialized
DEBUG - 2011-08-09 09:46:07 --> UTF-8 Support Enabled
DEBUG - 2011-08-09 09:46:07 --> URI Class Initialized
DEBUG - 2011-08-09 09:46:07 --> Router Class Initialized
DEBUG - 2011-08-09 09:46:07 --> Output Class Initialized
DEBUG - 2011-08-09 09:46:07 --> Input Class Initialized
DEBUG - 2011-08-09 09:46:07 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-09 09:46:07 --> Language Class Initialized
DEBUG - 2011-08-09 09:46:07 --> Loader Class Initialized
DEBUG - 2011-08-09 09:46:07 --> Controller Class Initialized
ERROR - 2011-08-09 09:46:07 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-09 09:46:07 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-09 09:46:07 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-09 09:46:07 --> Model Class Initialized
DEBUG - 2011-08-09 09:46:07 --> Model Class Initialized
DEBUG - 2011-08-09 09:46:07 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-09 09:46:07 --> Database Driver Class Initialized
DEBUG - 2011-08-09 09:46:07 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-09 09:46:07 --> Helper loaded: url_helper
DEBUG - 2011-08-09 09:46:07 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-09 09:46:07 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-09 09:46:07 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-09 09:46:07 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-09 09:46:07 --> Final output sent to browser
DEBUG - 2011-08-09 09:46:07 --> Total execution time: 0.0271
DEBUG - 2011-08-09 09:46:08 --> Config Class Initialized
DEBUG - 2011-08-09 09:46:08 --> Hooks Class Initialized
DEBUG - 2011-08-09 09:46:08 --> Utf8 Class Initialized
DEBUG - 2011-08-09 09:46:08 --> UTF-8 Support Enabled
DEBUG - 2011-08-09 09:46:08 --> URI Class Initialized
DEBUG - 2011-08-09 09:46:08 --> Router Class Initialized
DEBUG - 2011-08-09 09:46:08 --> Output Class Initialized
DEBUG - 2011-08-09 09:46:08 --> Input Class Initialized
DEBUG - 2011-08-09 09:46:08 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-09 09:46:08 --> Language Class Initialized
DEBUG - 2011-08-09 09:46:08 --> Loader Class Initialized
DEBUG - 2011-08-09 09:46:08 --> Controller Class Initialized
DEBUG - 2011-08-09 09:46:08 --> Model Class Initialized
DEBUG - 2011-08-09 09:46:08 --> Model Class Initialized
DEBUG - 2011-08-09 09:46:08 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-09 09:46:08 --> Database Driver Class Initialized
DEBUG - 2011-08-09 09:46:09 --> Final output sent to browser
DEBUG - 2011-08-09 09:46:09 --> Total execution time: 0.7409
DEBUG - 2011-08-09 09:46:27 --> Config Class Initialized
DEBUG - 2011-08-09 09:46:27 --> Hooks Class Initialized
DEBUG - 2011-08-09 09:46:27 --> Utf8 Class Initialized
DEBUG - 2011-08-09 09:46:27 --> UTF-8 Support Enabled
DEBUG - 2011-08-09 09:46:27 --> URI Class Initialized
DEBUG - 2011-08-09 09:46:27 --> Router Class Initialized
DEBUG - 2011-08-09 09:46:27 --> Output Class Initialized
DEBUG - 2011-08-09 09:46:27 --> Input Class Initialized
DEBUG - 2011-08-09 09:46:27 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-09 09:46:27 --> Language Class Initialized
DEBUG - 2011-08-09 09:46:27 --> Loader Class Initialized
DEBUG - 2011-08-09 09:46:27 --> Controller Class Initialized
ERROR - 2011-08-09 09:46:27 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-09 09:46:27 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-09 09:46:27 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-09 09:46:27 --> Model Class Initialized
DEBUG - 2011-08-09 09:46:27 --> Model Class Initialized
DEBUG - 2011-08-09 09:46:27 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-09 09:46:27 --> Database Driver Class Initialized
DEBUG - 2011-08-09 09:46:27 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-09 09:46:27 --> Helper loaded: url_helper
DEBUG - 2011-08-09 09:46:27 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-09 09:46:27 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-09 09:46:27 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-09 09:46:27 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-09 09:46:27 --> Final output sent to browser
DEBUG - 2011-08-09 09:46:27 --> Total execution time: 0.0345
DEBUG - 2011-08-09 09:46:27 --> Config Class Initialized
DEBUG - 2011-08-09 09:46:27 --> Hooks Class Initialized
DEBUG - 2011-08-09 09:46:27 --> Utf8 Class Initialized
DEBUG - 2011-08-09 09:46:27 --> UTF-8 Support Enabled
DEBUG - 2011-08-09 09:46:27 --> URI Class Initialized
DEBUG - 2011-08-09 09:46:27 --> Router Class Initialized
DEBUG - 2011-08-09 09:46:27 --> Output Class Initialized
DEBUG - 2011-08-09 09:46:27 --> Input Class Initialized
DEBUG - 2011-08-09 09:46:27 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-09 09:46:27 --> Language Class Initialized
DEBUG - 2011-08-09 09:46:27 --> Loader Class Initialized
DEBUG - 2011-08-09 09:46:27 --> Controller Class Initialized
DEBUG - 2011-08-09 09:46:27 --> Model Class Initialized
DEBUG - 2011-08-09 09:46:27 --> Model Class Initialized
DEBUG - 2011-08-09 09:46:27 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-09 09:46:27 --> Database Driver Class Initialized
DEBUG - 2011-08-09 09:46:28 --> Final output sent to browser
DEBUG - 2011-08-09 09:46:28 --> Total execution time: 0.8247
DEBUG - 2011-08-09 09:46:31 --> Config Class Initialized
DEBUG - 2011-08-09 09:46:31 --> Hooks Class Initialized
DEBUG - 2011-08-09 09:46:31 --> Utf8 Class Initialized
DEBUG - 2011-08-09 09:46:31 --> UTF-8 Support Enabled
DEBUG - 2011-08-09 09:46:31 --> URI Class Initialized
DEBUG - 2011-08-09 09:46:31 --> Router Class Initialized
DEBUG - 2011-08-09 09:46:31 --> Output Class Initialized
DEBUG - 2011-08-09 09:46:31 --> Input Class Initialized
DEBUG - 2011-08-09 09:46:31 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-09 09:46:31 --> Language Class Initialized
DEBUG - 2011-08-09 09:46:31 --> Loader Class Initialized
DEBUG - 2011-08-09 09:46:31 --> Controller Class Initialized
ERROR - 2011-08-09 09:46:31 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-09 09:46:31 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-09 09:46:31 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-09 09:46:31 --> Model Class Initialized
DEBUG - 2011-08-09 09:46:31 --> Model Class Initialized
DEBUG - 2011-08-09 09:46:31 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-09 09:46:31 --> Database Driver Class Initialized
DEBUG - 2011-08-09 09:46:31 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-09 09:46:31 --> Helper loaded: url_helper
DEBUG - 2011-08-09 09:46:31 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-09 09:46:31 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-09 09:46:31 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-09 09:46:31 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-09 09:46:31 --> Final output sent to browser
DEBUG - 2011-08-09 09:46:31 --> Total execution time: 0.0434
DEBUG - 2011-08-09 09:46:37 --> Config Class Initialized
DEBUG - 2011-08-09 09:46:37 --> Hooks Class Initialized
DEBUG - 2011-08-09 09:46:37 --> Utf8 Class Initialized
DEBUG - 2011-08-09 09:46:37 --> UTF-8 Support Enabled
DEBUG - 2011-08-09 09:46:37 --> URI Class Initialized
DEBUG - 2011-08-09 09:46:37 --> Router Class Initialized
DEBUG - 2011-08-09 09:46:37 --> Output Class Initialized
DEBUG - 2011-08-09 09:46:37 --> Input Class Initialized
DEBUG - 2011-08-09 09:46:37 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-09 09:46:37 --> Language Class Initialized
DEBUG - 2011-08-09 09:46:37 --> Loader Class Initialized
DEBUG - 2011-08-09 09:46:37 --> Controller Class Initialized
ERROR - 2011-08-09 09:46:37 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-09 09:46:37 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-09 09:46:37 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-09 09:46:37 --> Model Class Initialized
DEBUG - 2011-08-09 09:46:37 --> Model Class Initialized
DEBUG - 2011-08-09 09:46:37 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-09 09:46:37 --> Database Driver Class Initialized
DEBUG - 2011-08-09 09:46:37 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-09 09:46:37 --> Helper loaded: url_helper
DEBUG - 2011-08-09 09:46:37 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-09 09:46:37 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-09 09:46:37 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-09 09:46:37 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-09 09:46:37 --> Final output sent to browser
DEBUG - 2011-08-09 09:46:37 --> Total execution time: 0.0422
DEBUG - 2011-08-09 09:46:37 --> Config Class Initialized
DEBUG - 2011-08-09 09:46:37 --> Hooks Class Initialized
DEBUG - 2011-08-09 09:46:37 --> Utf8 Class Initialized
DEBUG - 2011-08-09 09:46:37 --> UTF-8 Support Enabled
DEBUG - 2011-08-09 09:46:37 --> URI Class Initialized
DEBUG - 2011-08-09 09:46:37 --> Router Class Initialized
DEBUG - 2011-08-09 09:46:37 --> Output Class Initialized
DEBUG - 2011-08-09 09:46:37 --> Input Class Initialized
DEBUG - 2011-08-09 09:46:37 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-09 09:46:37 --> Language Class Initialized
DEBUG - 2011-08-09 09:46:37 --> Loader Class Initialized
DEBUG - 2011-08-09 09:46:37 --> Controller Class Initialized
DEBUG - 2011-08-09 09:46:37 --> Model Class Initialized
DEBUG - 2011-08-09 09:46:37 --> Model Class Initialized
DEBUG - 2011-08-09 09:46:37 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-09 09:46:37 --> Database Driver Class Initialized
DEBUG - 2011-08-09 09:46:38 --> Final output sent to browser
DEBUG - 2011-08-09 09:46:38 --> Total execution time: 0.6943
DEBUG - 2011-08-09 09:46:41 --> Config Class Initialized
DEBUG - 2011-08-09 09:46:41 --> Hooks Class Initialized
DEBUG - 2011-08-09 09:46:41 --> Utf8 Class Initialized
DEBUG - 2011-08-09 09:46:41 --> UTF-8 Support Enabled
DEBUG - 2011-08-09 09:46:41 --> URI Class Initialized
DEBUG - 2011-08-09 09:46:41 --> Router Class Initialized
DEBUG - 2011-08-09 09:46:41 --> Output Class Initialized
DEBUG - 2011-08-09 09:46:41 --> Input Class Initialized
DEBUG - 2011-08-09 09:46:41 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-09 09:46:41 --> Language Class Initialized
DEBUG - 2011-08-09 09:46:41 --> Loader Class Initialized
DEBUG - 2011-08-09 09:46:41 --> Controller Class Initialized
ERROR - 2011-08-09 09:46:41 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-09 09:46:41 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-09 09:46:41 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-09 09:46:41 --> Model Class Initialized
DEBUG - 2011-08-09 09:46:41 --> Model Class Initialized
DEBUG - 2011-08-09 09:46:41 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-09 09:46:41 --> Database Driver Class Initialized
DEBUG - 2011-08-09 09:46:41 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-09 09:46:41 --> Helper loaded: url_helper
DEBUG - 2011-08-09 09:46:41 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-09 09:46:41 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-09 09:46:41 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-09 09:46:41 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-09 09:46:41 --> Final output sent to browser
DEBUG - 2011-08-09 09:46:41 --> Total execution time: 0.0355
DEBUG - 2011-08-09 09:46:56 --> Config Class Initialized
DEBUG - 2011-08-09 09:46:56 --> Hooks Class Initialized
DEBUG - 2011-08-09 09:46:56 --> Utf8 Class Initialized
DEBUG - 2011-08-09 09:46:56 --> UTF-8 Support Enabled
DEBUG - 2011-08-09 09:46:56 --> URI Class Initialized
DEBUG - 2011-08-09 09:46:56 --> Router Class Initialized
DEBUG - 2011-08-09 09:46:56 --> Output Class Initialized
DEBUG - 2011-08-09 09:46:56 --> Input Class Initialized
DEBUG - 2011-08-09 09:46:56 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-09 09:46:56 --> Language Class Initialized
DEBUG - 2011-08-09 09:46:56 --> Loader Class Initialized
DEBUG - 2011-08-09 09:46:56 --> Controller Class Initialized
ERROR - 2011-08-09 09:46:56 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-09 09:46:56 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-09 09:46:56 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-09 09:46:56 --> Model Class Initialized
DEBUG - 2011-08-09 09:46:56 --> Model Class Initialized
DEBUG - 2011-08-09 09:46:56 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-09 09:46:56 --> Database Driver Class Initialized
DEBUG - 2011-08-09 09:46:56 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-09 09:46:56 --> Helper loaded: url_helper
DEBUG - 2011-08-09 09:46:56 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-09 09:46:56 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-09 09:46:56 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-09 09:46:56 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-09 09:46:56 --> Final output sent to browser
DEBUG - 2011-08-09 09:46:56 --> Total execution time: 0.0363
DEBUG - 2011-08-09 09:46:57 --> Config Class Initialized
DEBUG - 2011-08-09 09:46:57 --> Hooks Class Initialized
DEBUG - 2011-08-09 09:46:57 --> Utf8 Class Initialized
DEBUG - 2011-08-09 09:46:57 --> UTF-8 Support Enabled
DEBUG - 2011-08-09 09:46:57 --> URI Class Initialized
DEBUG - 2011-08-09 09:46:57 --> Router Class Initialized
DEBUG - 2011-08-09 09:46:57 --> Output Class Initialized
DEBUG - 2011-08-09 09:46:57 --> Input Class Initialized
DEBUG - 2011-08-09 09:46:57 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-09 09:46:57 --> Language Class Initialized
DEBUG - 2011-08-09 09:46:57 --> Loader Class Initialized
DEBUG - 2011-08-09 09:46:57 --> Controller Class Initialized
DEBUG - 2011-08-09 09:46:57 --> Model Class Initialized
DEBUG - 2011-08-09 09:46:57 --> Model Class Initialized
DEBUG - 2011-08-09 09:46:57 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-09 09:46:57 --> Database Driver Class Initialized
DEBUG - 2011-08-09 09:46:58 --> Config Class Initialized
DEBUG - 2011-08-09 09:46:58 --> Hooks Class Initialized
DEBUG - 2011-08-09 09:46:58 --> Utf8 Class Initialized
DEBUG - 2011-08-09 09:46:58 --> UTF-8 Support Enabled
DEBUG - 2011-08-09 09:46:58 --> URI Class Initialized
DEBUG - 2011-08-09 09:46:58 --> Router Class Initialized
DEBUG - 2011-08-09 09:46:58 --> Output Class Initialized
DEBUG - 2011-08-09 09:46:58 --> Input Class Initialized
DEBUG - 2011-08-09 09:46:58 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-09 09:46:58 --> Language Class Initialized
DEBUG - 2011-08-09 09:46:58 --> Loader Class Initialized
DEBUG - 2011-08-09 09:46:58 --> Controller Class Initialized
ERROR - 2011-08-09 09:46:58 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-09 09:46:58 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-09 09:46:58 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-09 09:46:58 --> Model Class Initialized
DEBUG - 2011-08-09 09:46:58 --> Model Class Initialized
DEBUG - 2011-08-09 09:46:58 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-09 09:46:58 --> Database Driver Class Initialized
DEBUG - 2011-08-09 09:46:58 --> Final output sent to browser
DEBUG - 2011-08-09 09:46:58 --> Total execution time: 0.8903
DEBUG - 2011-08-09 09:46:58 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-09 09:46:58 --> Helper loaded: url_helper
DEBUG - 2011-08-09 09:46:58 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-09 09:46:58 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-09 09:46:58 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-09 09:46:58 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-09 09:46:58 --> Final output sent to browser
DEBUG - 2011-08-09 09:46:58 --> Total execution time: 0.0941
DEBUG - 2011-08-09 09:47:09 --> Config Class Initialized
DEBUG - 2011-08-09 09:47:09 --> Hooks Class Initialized
DEBUG - 2011-08-09 09:47:09 --> Utf8 Class Initialized
DEBUG - 2011-08-09 09:47:09 --> UTF-8 Support Enabled
DEBUG - 2011-08-09 09:47:09 --> URI Class Initialized
DEBUG - 2011-08-09 09:47:09 --> Router Class Initialized
DEBUG - 2011-08-09 09:47:09 --> Output Class Initialized
DEBUG - 2011-08-09 09:47:09 --> Input Class Initialized
DEBUG - 2011-08-09 09:47:09 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-09 09:47:09 --> Language Class Initialized
DEBUG - 2011-08-09 09:47:09 --> Loader Class Initialized
DEBUG - 2011-08-09 09:47:09 --> Controller Class Initialized
ERROR - 2011-08-09 09:47:09 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-09 09:47:09 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-09 09:47:09 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-09 09:47:09 --> Model Class Initialized
DEBUG - 2011-08-09 09:47:09 --> Model Class Initialized
DEBUG - 2011-08-09 09:47:09 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-09 09:47:09 --> Database Driver Class Initialized
DEBUG - 2011-08-09 09:47:09 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-09 09:47:09 --> Helper loaded: url_helper
DEBUG - 2011-08-09 09:47:09 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-09 09:47:09 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-09 09:47:09 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-09 09:47:09 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-09 09:47:09 --> Final output sent to browser
DEBUG - 2011-08-09 09:47:09 --> Total execution time: 0.0331
DEBUG - 2011-08-09 09:47:10 --> Config Class Initialized
DEBUG - 2011-08-09 09:47:10 --> Hooks Class Initialized
DEBUG - 2011-08-09 09:47:10 --> Utf8 Class Initialized
DEBUG - 2011-08-09 09:47:10 --> UTF-8 Support Enabled
DEBUG - 2011-08-09 09:47:10 --> URI Class Initialized
DEBUG - 2011-08-09 09:47:10 --> Router Class Initialized
DEBUG - 2011-08-09 09:47:10 --> Output Class Initialized
DEBUG - 2011-08-09 09:47:10 --> Input Class Initialized
DEBUG - 2011-08-09 09:47:10 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-09 09:47:10 --> Language Class Initialized
DEBUG - 2011-08-09 09:47:10 --> Loader Class Initialized
DEBUG - 2011-08-09 09:47:10 --> Controller Class Initialized
DEBUG - 2011-08-09 09:47:10 --> Model Class Initialized
DEBUG - 2011-08-09 09:47:10 --> Model Class Initialized
DEBUG - 2011-08-09 09:47:10 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-09 09:47:10 --> Database Driver Class Initialized
DEBUG - 2011-08-09 09:47:11 --> Final output sent to browser
DEBUG - 2011-08-09 09:47:11 --> Total execution time: 0.8735
DEBUG - 2011-08-09 09:47:22 --> Config Class Initialized
DEBUG - 2011-08-09 09:47:22 --> Hooks Class Initialized
DEBUG - 2011-08-09 09:47:22 --> Utf8 Class Initialized
DEBUG - 2011-08-09 09:47:22 --> UTF-8 Support Enabled
DEBUG - 2011-08-09 09:47:22 --> URI Class Initialized
DEBUG - 2011-08-09 09:47:22 --> Router Class Initialized
DEBUG - 2011-08-09 09:47:22 --> Output Class Initialized
DEBUG - 2011-08-09 09:47:22 --> Input Class Initialized
DEBUG - 2011-08-09 09:47:22 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-09 09:47:22 --> Language Class Initialized
DEBUG - 2011-08-09 09:47:22 --> Loader Class Initialized
DEBUG - 2011-08-09 09:47:22 --> Controller Class Initialized
ERROR - 2011-08-09 09:47:22 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-09 09:47:22 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-09 09:47:22 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-09 09:47:22 --> Model Class Initialized
DEBUG - 2011-08-09 09:47:22 --> Model Class Initialized
DEBUG - 2011-08-09 09:47:22 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-09 09:47:22 --> Database Driver Class Initialized
DEBUG - 2011-08-09 09:47:22 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-09 09:47:22 --> Helper loaded: url_helper
DEBUG - 2011-08-09 09:47:22 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-09 09:47:22 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-09 09:47:22 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-09 09:47:22 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-09 09:47:22 --> Final output sent to browser
DEBUG - 2011-08-09 09:47:22 --> Total execution time: 0.0985
DEBUG - 2011-08-09 09:47:23 --> Config Class Initialized
DEBUG - 2011-08-09 09:47:23 --> Hooks Class Initialized
DEBUG - 2011-08-09 09:47:23 --> Utf8 Class Initialized
DEBUG - 2011-08-09 09:47:23 --> UTF-8 Support Enabled
DEBUG - 2011-08-09 09:47:23 --> URI Class Initialized
DEBUG - 2011-08-09 09:47:23 --> Router Class Initialized
DEBUG - 2011-08-09 09:47:23 --> Output Class Initialized
DEBUG - 2011-08-09 09:47:23 --> Input Class Initialized
DEBUG - 2011-08-09 09:47:23 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-09 09:47:23 --> Language Class Initialized
DEBUG - 2011-08-09 09:47:23 --> Loader Class Initialized
DEBUG - 2011-08-09 09:47:23 --> Controller Class Initialized
DEBUG - 2011-08-09 09:47:23 --> Model Class Initialized
DEBUG - 2011-08-09 09:47:23 --> Model Class Initialized
DEBUG - 2011-08-09 09:47:23 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-09 09:47:23 --> Database Driver Class Initialized
DEBUG - 2011-08-09 09:47:23 --> Final output sent to browser
DEBUG - 2011-08-09 09:47:23 --> Total execution time: 0.6476
DEBUG - 2011-08-09 09:47:40 --> Config Class Initialized
DEBUG - 2011-08-09 09:47:40 --> Hooks Class Initialized
DEBUG - 2011-08-09 09:47:40 --> Utf8 Class Initialized
DEBUG - 2011-08-09 09:47:40 --> UTF-8 Support Enabled
DEBUG - 2011-08-09 09:47:40 --> URI Class Initialized
DEBUG - 2011-08-09 09:47:40 --> Router Class Initialized
DEBUG - 2011-08-09 09:47:40 --> Output Class Initialized
DEBUG - 2011-08-09 09:47:40 --> Input Class Initialized
DEBUG - 2011-08-09 09:47:40 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-09 09:47:40 --> Language Class Initialized
DEBUG - 2011-08-09 09:47:40 --> Loader Class Initialized
DEBUG - 2011-08-09 09:47:40 --> Controller Class Initialized
ERROR - 2011-08-09 09:47:40 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-09 09:47:40 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-09 09:47:40 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-09 09:47:40 --> Model Class Initialized
DEBUG - 2011-08-09 09:47:40 --> Model Class Initialized
DEBUG - 2011-08-09 09:47:40 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-09 09:47:40 --> Database Driver Class Initialized
DEBUG - 2011-08-09 09:47:40 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-09 09:47:40 --> Helper loaded: url_helper
DEBUG - 2011-08-09 09:47:40 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-09 09:47:40 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-09 09:47:40 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-09 09:47:40 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-09 09:47:40 --> Final output sent to browser
DEBUG - 2011-08-09 09:47:40 --> Total execution time: 0.0293
DEBUG - 2011-08-09 09:47:41 --> Config Class Initialized
DEBUG - 2011-08-09 09:47:41 --> Hooks Class Initialized
DEBUG - 2011-08-09 09:47:41 --> Utf8 Class Initialized
DEBUG - 2011-08-09 09:47:41 --> UTF-8 Support Enabled
DEBUG - 2011-08-09 09:47:41 --> URI Class Initialized
DEBUG - 2011-08-09 09:47:41 --> Router Class Initialized
DEBUG - 2011-08-09 09:47:41 --> Output Class Initialized
DEBUG - 2011-08-09 09:47:41 --> Input Class Initialized
DEBUG - 2011-08-09 09:47:41 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-09 09:47:41 --> Language Class Initialized
DEBUG - 2011-08-09 09:47:41 --> Loader Class Initialized
DEBUG - 2011-08-09 09:47:41 --> Controller Class Initialized
DEBUG - 2011-08-09 09:47:41 --> Model Class Initialized
DEBUG - 2011-08-09 09:47:41 --> Model Class Initialized
DEBUG - 2011-08-09 09:47:41 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-09 09:47:41 --> Database Driver Class Initialized
DEBUG - 2011-08-09 09:47:42 --> Final output sent to browser
DEBUG - 2011-08-09 09:47:42 --> Total execution time: 0.9532
DEBUG - 2011-08-09 09:47:51 --> Config Class Initialized
DEBUG - 2011-08-09 09:47:51 --> Hooks Class Initialized
DEBUG - 2011-08-09 09:47:51 --> Utf8 Class Initialized
DEBUG - 2011-08-09 09:47:51 --> UTF-8 Support Enabled
DEBUG - 2011-08-09 09:47:51 --> URI Class Initialized
DEBUG - 2011-08-09 09:47:51 --> Router Class Initialized
DEBUG - 2011-08-09 09:47:51 --> Output Class Initialized
DEBUG - 2011-08-09 09:47:51 --> Input Class Initialized
DEBUG - 2011-08-09 09:47:51 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-09 09:47:51 --> Language Class Initialized
DEBUG - 2011-08-09 09:47:51 --> Loader Class Initialized
DEBUG - 2011-08-09 09:47:51 --> Controller Class Initialized
ERROR - 2011-08-09 09:47:51 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-09 09:47:51 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-09 09:47:51 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-09 09:47:51 --> Model Class Initialized
DEBUG - 2011-08-09 09:47:51 --> Model Class Initialized
DEBUG - 2011-08-09 09:47:51 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-09 09:47:51 --> Database Driver Class Initialized
DEBUG - 2011-08-09 09:47:51 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-09 09:47:51 --> Helper loaded: url_helper
DEBUG - 2011-08-09 09:47:51 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-09 09:47:51 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-09 09:47:51 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-09 09:47:51 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-09 09:47:51 --> Final output sent to browser
DEBUG - 2011-08-09 09:47:51 --> Total execution time: 0.0338
DEBUG - 2011-08-09 09:47:51 --> Config Class Initialized
DEBUG - 2011-08-09 09:47:51 --> Hooks Class Initialized
DEBUG - 2011-08-09 09:47:51 --> Utf8 Class Initialized
DEBUG - 2011-08-09 09:47:51 --> UTF-8 Support Enabled
DEBUG - 2011-08-09 09:47:51 --> URI Class Initialized
DEBUG - 2011-08-09 09:47:51 --> Router Class Initialized
DEBUG - 2011-08-09 09:47:51 --> Output Class Initialized
DEBUG - 2011-08-09 09:47:51 --> Input Class Initialized
DEBUG - 2011-08-09 09:47:51 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-09 09:47:51 --> Language Class Initialized
DEBUG - 2011-08-09 09:47:51 --> Loader Class Initialized
DEBUG - 2011-08-09 09:47:51 --> Controller Class Initialized
DEBUG - 2011-08-09 09:47:51 --> Model Class Initialized
DEBUG - 2011-08-09 09:47:51 --> Model Class Initialized
DEBUG - 2011-08-09 09:47:51 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-09 09:47:51 --> Database Driver Class Initialized
DEBUG - 2011-08-09 09:47:52 --> Final output sent to browser
DEBUG - 2011-08-09 09:47:52 --> Total execution time: 0.7090
DEBUG - 2011-08-09 09:48:13 --> Config Class Initialized
DEBUG - 2011-08-09 09:48:13 --> Hooks Class Initialized
DEBUG - 2011-08-09 09:48:13 --> Utf8 Class Initialized
DEBUG - 2011-08-09 09:48:13 --> UTF-8 Support Enabled
DEBUG - 2011-08-09 09:48:13 --> URI Class Initialized
DEBUG - 2011-08-09 09:48:13 --> Router Class Initialized
DEBUG - 2011-08-09 09:48:13 --> Output Class Initialized
DEBUG - 2011-08-09 09:48:13 --> Input Class Initialized
DEBUG - 2011-08-09 09:48:13 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-09 09:48:13 --> Language Class Initialized
DEBUG - 2011-08-09 09:48:13 --> Loader Class Initialized
DEBUG - 2011-08-09 09:48:13 --> Controller Class Initialized
ERROR - 2011-08-09 09:48:13 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-09 09:48:13 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-09 09:48:13 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-09 09:48:13 --> Model Class Initialized
DEBUG - 2011-08-09 09:48:13 --> Model Class Initialized
DEBUG - 2011-08-09 09:48:13 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-09 09:48:13 --> Database Driver Class Initialized
DEBUG - 2011-08-09 09:48:13 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-09 09:48:13 --> Helper loaded: url_helper
DEBUG - 2011-08-09 09:48:13 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-09 09:48:13 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-09 09:48:13 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-09 09:48:13 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-09 09:48:13 --> Final output sent to browser
DEBUG - 2011-08-09 09:48:13 --> Total execution time: 0.0282
DEBUG - 2011-08-09 10:42:00 --> Config Class Initialized
DEBUG - 2011-08-09 10:42:00 --> Hooks Class Initialized
DEBUG - 2011-08-09 10:42:00 --> Utf8 Class Initialized
DEBUG - 2011-08-09 10:42:00 --> UTF-8 Support Enabled
DEBUG - 2011-08-09 10:42:00 --> URI Class Initialized
DEBUG - 2011-08-09 10:42:00 --> Router Class Initialized
DEBUG - 2011-08-09 10:42:00 --> Output Class Initialized
DEBUG - 2011-08-09 10:42:00 --> Input Class Initialized
DEBUG - 2011-08-09 10:42:00 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-09 10:42:00 --> Language Class Initialized
DEBUG - 2011-08-09 10:42:00 --> Loader Class Initialized
DEBUG - 2011-08-09 10:42:00 --> Controller Class Initialized
DEBUG - 2011-08-09 10:42:00 --> Model Class Initialized
DEBUG - 2011-08-09 10:42:00 --> Model Class Initialized
DEBUG - 2011-08-09 10:42:00 --> Model Class Initialized
DEBUG - 2011-08-09 10:42:00 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-09 10:42:00 --> Database Driver Class Initialized
DEBUG - 2011-08-09 10:42:01 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-09 10:42:01 --> Helper loaded: url_helper
DEBUG - 2011-08-09 10:42:01 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-09 10:42:01 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-09 10:42:01 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-09 10:42:01 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-09 10:42:01 --> Final output sent to browser
DEBUG - 2011-08-09 10:42:01 --> Total execution time: 0.3184
DEBUG - 2011-08-09 12:00:49 --> Config Class Initialized
DEBUG - 2011-08-09 12:00:49 --> Hooks Class Initialized
DEBUG - 2011-08-09 12:00:49 --> Utf8 Class Initialized
DEBUG - 2011-08-09 12:00:49 --> UTF-8 Support Enabled
DEBUG - 2011-08-09 12:00:49 --> URI Class Initialized
DEBUG - 2011-08-09 12:00:49 --> Router Class Initialized
DEBUG - 2011-08-09 12:00:49 --> Output Class Initialized
DEBUG - 2011-08-09 12:00:49 --> Input Class Initialized
DEBUG - 2011-08-09 12:00:49 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-09 12:00:49 --> Language Class Initialized
DEBUG - 2011-08-09 12:00:49 --> Loader Class Initialized
DEBUG - 2011-08-09 12:00:49 --> Controller Class Initialized
ERROR - 2011-08-09 12:00:49 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-09 12:00:49 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-09 12:00:49 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-09 12:00:49 --> Model Class Initialized
DEBUG - 2011-08-09 12:00:49 --> Model Class Initialized
DEBUG - 2011-08-09 12:00:49 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-09 12:00:49 --> Database Driver Class Initialized
DEBUG - 2011-08-09 12:00:49 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-09 12:00:49 --> Helper loaded: url_helper
DEBUG - 2011-08-09 12:00:49 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-09 12:00:49 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-09 12:00:49 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-09 12:00:49 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-09 12:00:49 --> Final output sent to browser
DEBUG - 2011-08-09 12:00:49 --> Total execution time: 0.1426
DEBUG - 2011-08-09 12:00:50 --> Config Class Initialized
DEBUG - 2011-08-09 12:00:50 --> Hooks Class Initialized
DEBUG - 2011-08-09 12:00:50 --> Utf8 Class Initialized
DEBUG - 2011-08-09 12:00:50 --> UTF-8 Support Enabled
DEBUG - 2011-08-09 12:00:50 --> URI Class Initialized
DEBUG - 2011-08-09 12:00:50 --> Router Class Initialized
DEBUG - 2011-08-09 12:00:50 --> Output Class Initialized
DEBUG - 2011-08-09 12:00:50 --> Input Class Initialized
DEBUG - 2011-08-09 12:00:50 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-09 12:00:50 --> Language Class Initialized
DEBUG - 2011-08-09 12:00:50 --> Loader Class Initialized
DEBUG - 2011-08-09 12:00:50 --> Controller Class Initialized
DEBUG - 2011-08-09 12:00:50 --> Model Class Initialized
DEBUG - 2011-08-09 12:00:50 --> Model Class Initialized
DEBUG - 2011-08-09 12:00:50 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-09 12:00:50 --> Database Driver Class Initialized
DEBUG - 2011-08-09 12:00:50 --> Final output sent to browser
DEBUG - 2011-08-09 12:00:50 --> Total execution time: 0.6188
DEBUG - 2011-08-09 12:00:51 --> Config Class Initialized
DEBUG - 2011-08-09 12:00:51 --> Hooks Class Initialized
DEBUG - 2011-08-09 12:00:51 --> Utf8 Class Initialized
DEBUG - 2011-08-09 12:00:51 --> UTF-8 Support Enabled
DEBUG - 2011-08-09 12:00:51 --> URI Class Initialized
DEBUG - 2011-08-09 12:00:51 --> Router Class Initialized
ERROR - 2011-08-09 12:00:51 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-09 12:00:51 --> Config Class Initialized
DEBUG - 2011-08-09 12:00:51 --> Hooks Class Initialized
DEBUG - 2011-08-09 12:00:51 --> Utf8 Class Initialized
DEBUG - 2011-08-09 12:00:51 --> UTF-8 Support Enabled
DEBUG - 2011-08-09 12:00:51 --> URI Class Initialized
DEBUG - 2011-08-09 12:00:51 --> Router Class Initialized
ERROR - 2011-08-09 12:00:51 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-09 13:02:40 --> Config Class Initialized
DEBUG - 2011-08-09 13:02:40 --> Hooks Class Initialized
DEBUG - 2011-08-09 13:02:40 --> Utf8 Class Initialized
DEBUG - 2011-08-09 13:02:40 --> UTF-8 Support Enabled
DEBUG - 2011-08-09 13:02:40 --> URI Class Initialized
DEBUG - 2011-08-09 13:02:40 --> Router Class Initialized
DEBUG - 2011-08-09 13:02:40 --> Output Class Initialized
DEBUG - 2011-08-09 13:02:40 --> Input Class Initialized
DEBUG - 2011-08-09 13:02:40 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-09 13:02:40 --> Language Class Initialized
DEBUG - 2011-08-09 13:02:40 --> Loader Class Initialized
DEBUG - 2011-08-09 13:02:40 --> Controller Class Initialized
ERROR - 2011-08-09 13:02:40 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-09 13:02:40 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-09 13:02:40 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-09 13:02:40 --> Model Class Initialized
DEBUG - 2011-08-09 13:02:40 --> Model Class Initialized
DEBUG - 2011-08-09 13:02:40 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-09 13:02:40 --> Database Driver Class Initialized
DEBUG - 2011-08-09 13:02:40 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-09 13:02:40 --> Helper loaded: url_helper
DEBUG - 2011-08-09 13:02:40 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-09 13:02:40 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-09 13:02:40 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-09 13:02:40 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-09 13:02:40 --> Final output sent to browser
DEBUG - 2011-08-09 13:02:40 --> Total execution time: 0.0993
DEBUG - 2011-08-09 13:02:45 --> Config Class Initialized
DEBUG - 2011-08-09 13:02:45 --> Hooks Class Initialized
DEBUG - 2011-08-09 13:02:45 --> Utf8 Class Initialized
DEBUG - 2011-08-09 13:02:45 --> UTF-8 Support Enabled
DEBUG - 2011-08-09 13:02:45 --> URI Class Initialized
DEBUG - 2011-08-09 13:02:45 --> Router Class Initialized
DEBUG - 2011-08-09 13:02:45 --> Output Class Initialized
DEBUG - 2011-08-09 13:02:45 --> Input Class Initialized
DEBUG - 2011-08-09 13:02:45 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-09 13:02:45 --> Language Class Initialized
DEBUG - 2011-08-09 13:02:45 --> Loader Class Initialized
DEBUG - 2011-08-09 13:02:45 --> Controller Class Initialized
DEBUG - 2011-08-09 13:02:45 --> Model Class Initialized
DEBUG - 2011-08-09 13:02:45 --> Model Class Initialized
DEBUG - 2011-08-09 13:02:45 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-09 13:02:45 --> Database Driver Class Initialized
DEBUG - 2011-08-09 13:02:45 --> Final output sent to browser
DEBUG - 2011-08-09 13:02:45 --> Total execution time: 0.5085
DEBUG - 2011-08-09 13:02:52 --> Config Class Initialized
DEBUG - 2011-08-09 13:02:52 --> Hooks Class Initialized
DEBUG - 2011-08-09 13:02:52 --> Utf8 Class Initialized
DEBUG - 2011-08-09 13:02:52 --> UTF-8 Support Enabled
DEBUG - 2011-08-09 13:02:52 --> URI Class Initialized
DEBUG - 2011-08-09 13:02:52 --> Router Class Initialized
ERROR - 2011-08-09 13:02:52 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-09 13:04:45 --> Config Class Initialized
DEBUG - 2011-08-09 13:04:45 --> Hooks Class Initialized
DEBUG - 2011-08-09 13:04:45 --> Utf8 Class Initialized
DEBUG - 2011-08-09 13:04:45 --> UTF-8 Support Enabled
DEBUG - 2011-08-09 13:04:45 --> URI Class Initialized
DEBUG - 2011-08-09 13:04:45 --> Router Class Initialized
DEBUG - 2011-08-09 13:04:45 --> Output Class Initialized
DEBUG - 2011-08-09 13:04:45 --> Input Class Initialized
DEBUG - 2011-08-09 13:04:45 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-09 13:04:45 --> Language Class Initialized
DEBUG - 2011-08-09 13:04:45 --> Loader Class Initialized
DEBUG - 2011-08-09 13:04:45 --> Controller Class Initialized
ERROR - 2011-08-09 13:04:45 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-09 13:04:45 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-09 13:04:45 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-09 13:04:45 --> Model Class Initialized
DEBUG - 2011-08-09 13:04:45 --> Model Class Initialized
DEBUG - 2011-08-09 13:04:45 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-09 13:04:45 --> Database Driver Class Initialized
DEBUG - 2011-08-09 13:04:45 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-09 13:04:45 --> Helper loaded: url_helper
DEBUG - 2011-08-09 13:04:45 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-09 13:04:45 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-09 13:04:45 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-09 13:04:45 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-09 13:04:45 --> Final output sent to browser
DEBUG - 2011-08-09 13:04:45 --> Total execution time: 0.0300
DEBUG - 2011-08-09 13:04:47 --> Config Class Initialized
DEBUG - 2011-08-09 13:04:47 --> Hooks Class Initialized
DEBUG - 2011-08-09 13:04:47 --> Utf8 Class Initialized
DEBUG - 2011-08-09 13:04:47 --> UTF-8 Support Enabled
DEBUG - 2011-08-09 13:04:47 --> URI Class Initialized
DEBUG - 2011-08-09 13:04:47 --> Router Class Initialized
DEBUG - 2011-08-09 13:04:47 --> Output Class Initialized
DEBUG - 2011-08-09 13:04:47 --> Input Class Initialized
DEBUG - 2011-08-09 13:04:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-09 13:04:47 --> Language Class Initialized
DEBUG - 2011-08-09 13:04:47 --> Loader Class Initialized
DEBUG - 2011-08-09 13:04:47 --> Controller Class Initialized
DEBUG - 2011-08-09 13:04:47 --> Model Class Initialized
DEBUG - 2011-08-09 13:04:47 --> Model Class Initialized
DEBUG - 2011-08-09 13:04:47 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-09 13:04:47 --> Database Driver Class Initialized
DEBUG - 2011-08-09 13:04:48 --> Final output sent to browser
DEBUG - 2011-08-09 13:04:48 --> Total execution time: 0.5009
DEBUG - 2011-08-09 13:04:51 --> Config Class Initialized
DEBUG - 2011-08-09 13:04:51 --> Hooks Class Initialized
DEBUG - 2011-08-09 13:04:51 --> Utf8 Class Initialized
DEBUG - 2011-08-09 13:04:51 --> UTF-8 Support Enabled
DEBUG - 2011-08-09 13:04:51 --> URI Class Initialized
DEBUG - 2011-08-09 13:04:51 --> Router Class Initialized
ERROR - 2011-08-09 13:04:51 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-09 13:05:22 --> Config Class Initialized
DEBUG - 2011-08-09 13:05:22 --> Hooks Class Initialized
DEBUG - 2011-08-09 13:05:22 --> Utf8 Class Initialized
DEBUG - 2011-08-09 13:05:22 --> UTF-8 Support Enabled
DEBUG - 2011-08-09 13:05:22 --> URI Class Initialized
DEBUG - 2011-08-09 13:05:22 --> Router Class Initialized
DEBUG - 2011-08-09 13:05:22 --> Output Class Initialized
DEBUG - 2011-08-09 13:05:22 --> Input Class Initialized
DEBUG - 2011-08-09 13:05:22 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-09 13:05:22 --> Language Class Initialized
DEBUG - 2011-08-09 13:05:22 --> Loader Class Initialized
DEBUG - 2011-08-09 13:05:22 --> Controller Class Initialized
ERROR - 2011-08-09 13:05:22 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-09 13:05:22 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-09 13:05:22 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-09 13:05:22 --> Model Class Initialized
DEBUG - 2011-08-09 13:05:22 --> Model Class Initialized
DEBUG - 2011-08-09 13:05:22 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-09 13:05:22 --> Database Driver Class Initialized
DEBUG - 2011-08-09 13:05:22 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-09 13:05:22 --> Helper loaded: url_helper
DEBUG - 2011-08-09 13:05:22 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-09 13:05:22 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-09 13:05:22 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-09 13:05:22 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-09 13:05:22 --> Final output sent to browser
DEBUG - 2011-08-09 13:05:22 --> Total execution time: 0.0268
DEBUG - 2011-08-09 13:05:23 --> Config Class Initialized
DEBUG - 2011-08-09 13:05:23 --> Hooks Class Initialized
DEBUG - 2011-08-09 13:05:23 --> Utf8 Class Initialized
DEBUG - 2011-08-09 13:05:23 --> UTF-8 Support Enabled
DEBUG - 2011-08-09 13:05:23 --> URI Class Initialized
DEBUG - 2011-08-09 13:05:23 --> Router Class Initialized
DEBUG - 2011-08-09 13:05:23 --> Output Class Initialized
DEBUG - 2011-08-09 13:05:23 --> Input Class Initialized
DEBUG - 2011-08-09 13:05:23 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-09 13:05:23 --> Language Class Initialized
DEBUG - 2011-08-09 13:05:23 --> Loader Class Initialized
DEBUG - 2011-08-09 13:05:23 --> Controller Class Initialized
DEBUG - 2011-08-09 13:05:23 --> Model Class Initialized
DEBUG - 2011-08-09 13:05:23 --> Model Class Initialized
DEBUG - 2011-08-09 13:05:23 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-09 13:05:23 --> Database Driver Class Initialized
DEBUG - 2011-08-09 13:05:24 --> Final output sent to browser
DEBUG - 2011-08-09 13:05:24 --> Total execution time: 0.6806
DEBUG - 2011-08-09 13:05:28 --> Config Class Initialized
DEBUG - 2011-08-09 13:05:28 --> Hooks Class Initialized
DEBUG - 2011-08-09 13:05:28 --> Utf8 Class Initialized
DEBUG - 2011-08-09 13:05:28 --> UTF-8 Support Enabled
DEBUG - 2011-08-09 13:05:28 --> URI Class Initialized
DEBUG - 2011-08-09 13:05:28 --> Router Class Initialized
ERROR - 2011-08-09 13:05:28 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-09 13:05:41 --> Config Class Initialized
DEBUG - 2011-08-09 13:05:41 --> Hooks Class Initialized
DEBUG - 2011-08-09 13:05:41 --> Utf8 Class Initialized
DEBUG - 2011-08-09 13:05:41 --> UTF-8 Support Enabled
DEBUG - 2011-08-09 13:05:41 --> URI Class Initialized
DEBUG - 2011-08-09 13:05:41 --> Router Class Initialized
DEBUG - 2011-08-09 13:05:41 --> Output Class Initialized
DEBUG - 2011-08-09 13:05:41 --> Input Class Initialized
DEBUG - 2011-08-09 13:05:41 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-09 13:05:41 --> Language Class Initialized
DEBUG - 2011-08-09 13:05:41 --> Loader Class Initialized
DEBUG - 2011-08-09 13:05:41 --> Controller Class Initialized
ERROR - 2011-08-09 13:05:41 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-09 13:05:41 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-09 13:05:41 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-09 13:05:41 --> Model Class Initialized
DEBUG - 2011-08-09 13:05:41 --> Model Class Initialized
DEBUG - 2011-08-09 13:05:41 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-09 13:05:41 --> Database Driver Class Initialized
DEBUG - 2011-08-09 13:05:41 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-09 13:05:41 --> Helper loaded: url_helper
DEBUG - 2011-08-09 13:05:41 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-09 13:05:41 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-09 13:05:41 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-09 13:05:41 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-09 13:05:41 --> Final output sent to browser
DEBUG - 2011-08-09 13:05:41 --> Total execution time: 0.0295
DEBUG - 2011-08-09 13:05:44 --> Config Class Initialized
DEBUG - 2011-08-09 13:05:44 --> Hooks Class Initialized
DEBUG - 2011-08-09 13:05:44 --> Utf8 Class Initialized
DEBUG - 2011-08-09 13:05:44 --> UTF-8 Support Enabled
DEBUG - 2011-08-09 13:05:44 --> URI Class Initialized
DEBUG - 2011-08-09 13:05:44 --> Router Class Initialized
DEBUG - 2011-08-09 13:05:44 --> Output Class Initialized
DEBUG - 2011-08-09 13:05:44 --> Input Class Initialized
DEBUG - 2011-08-09 13:05:44 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-09 13:05:44 --> Language Class Initialized
DEBUG - 2011-08-09 13:05:44 --> Loader Class Initialized
DEBUG - 2011-08-09 13:05:44 --> Controller Class Initialized
ERROR - 2011-08-09 13:05:44 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-09 13:05:44 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-09 13:05:44 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-09 13:05:44 --> Model Class Initialized
DEBUG - 2011-08-09 13:05:44 --> Model Class Initialized
DEBUG - 2011-08-09 13:05:44 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-09 13:05:44 --> Database Driver Class Initialized
DEBUG - 2011-08-09 13:05:44 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-09 13:05:44 --> Helper loaded: url_helper
DEBUG - 2011-08-09 13:05:44 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-09 13:05:44 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-09 13:05:44 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-09 13:05:44 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-09 13:05:44 --> Final output sent to browser
DEBUG - 2011-08-09 13:05:44 --> Total execution time: 0.0352
DEBUG - 2011-08-09 13:05:45 --> Config Class Initialized
DEBUG - 2011-08-09 13:05:45 --> Hooks Class Initialized
DEBUG - 2011-08-09 13:05:45 --> Utf8 Class Initialized
DEBUG - 2011-08-09 13:05:45 --> UTF-8 Support Enabled
DEBUG - 2011-08-09 13:05:45 --> URI Class Initialized
DEBUG - 2011-08-09 13:05:45 --> Router Class Initialized
DEBUG - 2011-08-09 13:05:45 --> Output Class Initialized
DEBUG - 2011-08-09 13:05:45 --> Input Class Initialized
DEBUG - 2011-08-09 13:05:45 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-09 13:05:45 --> Language Class Initialized
DEBUG - 2011-08-09 13:05:45 --> Loader Class Initialized
DEBUG - 2011-08-09 13:05:45 --> Controller Class Initialized
DEBUG - 2011-08-09 13:05:45 --> Model Class Initialized
DEBUG - 2011-08-09 13:05:45 --> Model Class Initialized
DEBUG - 2011-08-09 13:05:45 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-09 13:05:45 --> Database Driver Class Initialized
DEBUG - 2011-08-09 13:05:46 --> Final output sent to browser
DEBUG - 2011-08-09 13:05:46 --> Total execution time: 0.4901
DEBUG - 2011-08-09 13:05:49 --> Config Class Initialized
DEBUG - 2011-08-09 13:05:49 --> Hooks Class Initialized
DEBUG - 2011-08-09 13:05:49 --> Utf8 Class Initialized
DEBUG - 2011-08-09 13:05:49 --> UTF-8 Support Enabled
DEBUG - 2011-08-09 13:05:49 --> URI Class Initialized
DEBUG - 2011-08-09 13:05:49 --> Router Class Initialized
ERROR - 2011-08-09 13:05:49 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-09 13:06:27 --> Config Class Initialized
DEBUG - 2011-08-09 13:06:27 --> Hooks Class Initialized
DEBUG - 2011-08-09 13:06:27 --> Utf8 Class Initialized
DEBUG - 2011-08-09 13:06:27 --> UTF-8 Support Enabled
DEBUG - 2011-08-09 13:06:27 --> URI Class Initialized
DEBUG - 2011-08-09 13:06:27 --> Router Class Initialized
DEBUG - 2011-08-09 13:06:27 --> Output Class Initialized
DEBUG - 2011-08-09 13:06:27 --> Input Class Initialized
DEBUG - 2011-08-09 13:06:27 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-09 13:06:27 --> Language Class Initialized
DEBUG - 2011-08-09 13:06:27 --> Loader Class Initialized
DEBUG - 2011-08-09 13:06:27 --> Controller Class Initialized
ERROR - 2011-08-09 13:06:27 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-09 13:06:27 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-09 13:06:27 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-09 13:06:27 --> Model Class Initialized
DEBUG - 2011-08-09 13:06:27 --> Model Class Initialized
DEBUG - 2011-08-09 13:06:27 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-09 13:06:27 --> Database Driver Class Initialized
DEBUG - 2011-08-09 13:06:28 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-09 13:06:28 --> Helper loaded: url_helper
DEBUG - 2011-08-09 13:06:28 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-09 13:06:28 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-09 13:06:28 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-09 13:06:28 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-09 13:06:28 --> Final output sent to browser
DEBUG - 2011-08-09 13:06:28 --> Total execution time: 0.0270
DEBUG - 2011-08-09 13:06:29 --> Config Class Initialized
DEBUG - 2011-08-09 13:06:29 --> Hooks Class Initialized
DEBUG - 2011-08-09 13:06:29 --> Utf8 Class Initialized
DEBUG - 2011-08-09 13:06:29 --> UTF-8 Support Enabled
DEBUG - 2011-08-09 13:06:29 --> URI Class Initialized
DEBUG - 2011-08-09 13:06:29 --> Router Class Initialized
DEBUG - 2011-08-09 13:06:29 --> Output Class Initialized
DEBUG - 2011-08-09 13:06:29 --> Input Class Initialized
DEBUG - 2011-08-09 13:06:29 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-09 13:06:29 --> Language Class Initialized
DEBUG - 2011-08-09 13:06:29 --> Loader Class Initialized
DEBUG - 2011-08-09 13:06:29 --> Controller Class Initialized
DEBUG - 2011-08-09 13:06:29 --> Model Class Initialized
DEBUG - 2011-08-09 13:06:29 --> Model Class Initialized
DEBUG - 2011-08-09 13:06:29 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-09 13:06:29 --> Database Driver Class Initialized
DEBUG - 2011-08-09 13:06:30 --> Final output sent to browser
DEBUG - 2011-08-09 13:06:30 --> Total execution time: 0.5306
DEBUG - 2011-08-09 13:06:34 --> Config Class Initialized
DEBUG - 2011-08-09 13:06:34 --> Hooks Class Initialized
DEBUG - 2011-08-09 13:06:34 --> Utf8 Class Initialized
DEBUG - 2011-08-09 13:06:34 --> UTF-8 Support Enabled
DEBUG - 2011-08-09 13:06:34 --> URI Class Initialized
DEBUG - 2011-08-09 13:06:34 --> Router Class Initialized
ERROR - 2011-08-09 13:06:34 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-09 13:07:03 --> Config Class Initialized
DEBUG - 2011-08-09 13:07:03 --> Hooks Class Initialized
DEBUG - 2011-08-09 13:07:03 --> Utf8 Class Initialized
DEBUG - 2011-08-09 13:07:03 --> UTF-8 Support Enabled
DEBUG - 2011-08-09 13:07:03 --> URI Class Initialized
DEBUG - 2011-08-09 13:07:03 --> Router Class Initialized
DEBUG - 2011-08-09 13:07:03 --> Output Class Initialized
DEBUG - 2011-08-09 13:07:03 --> Input Class Initialized
DEBUG - 2011-08-09 13:07:03 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-09 13:07:03 --> Language Class Initialized
DEBUG - 2011-08-09 13:07:03 --> Loader Class Initialized
DEBUG - 2011-08-09 13:07:03 --> Controller Class Initialized
ERROR - 2011-08-09 13:07:03 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-09 13:07:03 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-09 13:07:03 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-09 13:07:03 --> Model Class Initialized
DEBUG - 2011-08-09 13:07:03 --> Model Class Initialized
DEBUG - 2011-08-09 13:07:03 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-09 13:07:03 --> Database Driver Class Initialized
DEBUG - 2011-08-09 13:07:03 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-09 13:07:03 --> Helper loaded: url_helper
DEBUG - 2011-08-09 13:07:03 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-09 13:07:03 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-09 13:07:03 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-09 13:07:03 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-09 13:07:03 --> Final output sent to browser
DEBUG - 2011-08-09 13:07:03 --> Total execution time: 0.0300
DEBUG - 2011-08-09 13:07:05 --> Config Class Initialized
DEBUG - 2011-08-09 13:07:05 --> Hooks Class Initialized
DEBUG - 2011-08-09 13:07:05 --> Utf8 Class Initialized
DEBUG - 2011-08-09 13:07:05 --> UTF-8 Support Enabled
DEBUG - 2011-08-09 13:07:05 --> URI Class Initialized
DEBUG - 2011-08-09 13:07:05 --> Router Class Initialized
DEBUG - 2011-08-09 13:07:05 --> Output Class Initialized
DEBUG - 2011-08-09 13:07:05 --> Input Class Initialized
DEBUG - 2011-08-09 13:07:05 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-09 13:07:05 --> Language Class Initialized
DEBUG - 2011-08-09 13:07:05 --> Loader Class Initialized
DEBUG - 2011-08-09 13:07:05 --> Controller Class Initialized
DEBUG - 2011-08-09 13:07:05 --> Model Class Initialized
DEBUG - 2011-08-09 13:07:05 --> Model Class Initialized
DEBUG - 2011-08-09 13:07:05 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-09 13:07:05 --> Database Driver Class Initialized
DEBUG - 2011-08-09 13:07:06 --> Final output sent to browser
DEBUG - 2011-08-09 13:07:06 --> Total execution time: 0.6548
DEBUG - 2011-08-09 13:07:10 --> Config Class Initialized
DEBUG - 2011-08-09 13:07:10 --> Hooks Class Initialized
DEBUG - 2011-08-09 13:07:10 --> Utf8 Class Initialized
DEBUG - 2011-08-09 13:07:10 --> UTF-8 Support Enabled
DEBUG - 2011-08-09 13:07:10 --> URI Class Initialized
DEBUG - 2011-08-09 13:07:10 --> Router Class Initialized
ERROR - 2011-08-09 13:07:10 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-09 13:07:28 --> Config Class Initialized
DEBUG - 2011-08-09 13:07:28 --> Hooks Class Initialized
DEBUG - 2011-08-09 13:07:28 --> Utf8 Class Initialized
DEBUG - 2011-08-09 13:07:28 --> UTF-8 Support Enabled
DEBUG - 2011-08-09 13:07:28 --> URI Class Initialized
DEBUG - 2011-08-09 13:07:28 --> Router Class Initialized
DEBUG - 2011-08-09 13:07:28 --> Output Class Initialized
DEBUG - 2011-08-09 13:07:28 --> Input Class Initialized
DEBUG - 2011-08-09 13:07:28 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-09 13:07:28 --> Language Class Initialized
DEBUG - 2011-08-09 13:07:28 --> Loader Class Initialized
DEBUG - 2011-08-09 13:07:28 --> Controller Class Initialized
ERROR - 2011-08-09 13:07:28 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-09 13:07:28 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-09 13:07:28 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-09 13:07:28 --> Model Class Initialized
DEBUG - 2011-08-09 13:07:28 --> Model Class Initialized
DEBUG - 2011-08-09 13:07:28 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-09 13:07:28 --> Database Driver Class Initialized
DEBUG - 2011-08-09 13:07:28 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-09 13:07:28 --> Helper loaded: url_helper
DEBUG - 2011-08-09 13:07:28 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-09 13:07:28 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-09 13:07:28 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-09 13:07:28 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-09 13:07:28 --> Final output sent to browser
DEBUG - 2011-08-09 13:07:28 --> Total execution time: 0.0298
DEBUG - 2011-08-09 13:07:30 --> Config Class Initialized
DEBUG - 2011-08-09 13:07:30 --> Hooks Class Initialized
DEBUG - 2011-08-09 13:07:30 --> Utf8 Class Initialized
DEBUG - 2011-08-09 13:07:30 --> UTF-8 Support Enabled
DEBUG - 2011-08-09 13:07:30 --> URI Class Initialized
DEBUG - 2011-08-09 13:07:30 --> Router Class Initialized
DEBUG - 2011-08-09 13:07:30 --> Output Class Initialized
DEBUG - 2011-08-09 13:07:30 --> Input Class Initialized
DEBUG - 2011-08-09 13:07:30 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-09 13:07:30 --> Language Class Initialized
DEBUG - 2011-08-09 13:07:30 --> Loader Class Initialized
DEBUG - 2011-08-09 13:07:30 --> Controller Class Initialized
DEBUG - 2011-08-09 13:07:30 --> Model Class Initialized
DEBUG - 2011-08-09 13:07:30 --> Model Class Initialized
DEBUG - 2011-08-09 13:07:30 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-09 13:07:30 --> Database Driver Class Initialized
DEBUG - 2011-08-09 13:07:31 --> Final output sent to browser
DEBUG - 2011-08-09 13:07:31 --> Total execution time: 0.5974
DEBUG - 2011-08-09 13:07:35 --> Config Class Initialized
DEBUG - 2011-08-09 13:07:35 --> Hooks Class Initialized
DEBUG - 2011-08-09 13:07:35 --> Utf8 Class Initialized
DEBUG - 2011-08-09 13:07:35 --> UTF-8 Support Enabled
DEBUG - 2011-08-09 13:07:35 --> URI Class Initialized
DEBUG - 2011-08-09 13:07:35 --> Router Class Initialized
ERROR - 2011-08-09 13:07:35 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-09 13:07:36 --> Config Class Initialized
DEBUG - 2011-08-09 13:07:36 --> Hooks Class Initialized
DEBUG - 2011-08-09 13:07:36 --> Utf8 Class Initialized
DEBUG - 2011-08-09 13:07:36 --> UTF-8 Support Enabled
DEBUG - 2011-08-09 13:07:36 --> URI Class Initialized
DEBUG - 2011-08-09 13:07:36 --> Router Class Initialized
DEBUG - 2011-08-09 13:07:36 --> Output Class Initialized
DEBUG - 2011-08-09 13:07:36 --> Input Class Initialized
DEBUG - 2011-08-09 13:07:36 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-09 13:07:36 --> Language Class Initialized
DEBUG - 2011-08-09 13:07:36 --> Loader Class Initialized
DEBUG - 2011-08-09 13:07:36 --> Controller Class Initialized
ERROR - 2011-08-09 13:07:36 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-09 13:07:36 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-09 13:07:36 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-09 13:07:36 --> Model Class Initialized
DEBUG - 2011-08-09 13:07:36 --> Model Class Initialized
DEBUG - 2011-08-09 13:07:36 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-09 13:07:36 --> Database Driver Class Initialized
DEBUG - 2011-08-09 13:07:36 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-09 13:07:36 --> Helper loaded: url_helper
DEBUG - 2011-08-09 13:07:36 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-09 13:07:36 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-09 13:07:36 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-09 13:07:36 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-09 13:07:36 --> Final output sent to browser
DEBUG - 2011-08-09 13:07:36 --> Total execution time: 0.0410
DEBUG - 2011-08-09 13:07:57 --> Config Class Initialized
DEBUG - 2011-08-09 13:07:57 --> Hooks Class Initialized
DEBUG - 2011-08-09 13:07:57 --> Utf8 Class Initialized
DEBUG - 2011-08-09 13:07:57 --> UTF-8 Support Enabled
DEBUG - 2011-08-09 13:07:57 --> URI Class Initialized
DEBUG - 2011-08-09 13:07:57 --> Router Class Initialized
DEBUG - 2011-08-09 13:07:57 --> Output Class Initialized
DEBUG - 2011-08-09 13:07:57 --> Input Class Initialized
DEBUG - 2011-08-09 13:07:57 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-09 13:07:57 --> Language Class Initialized
DEBUG - 2011-08-09 13:07:57 --> Loader Class Initialized
DEBUG - 2011-08-09 13:07:57 --> Controller Class Initialized
ERROR - 2011-08-09 13:07:57 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-09 13:07:57 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-09 13:07:57 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-09 13:07:57 --> Model Class Initialized
DEBUG - 2011-08-09 13:07:57 --> Model Class Initialized
DEBUG - 2011-08-09 13:07:57 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-09 13:07:57 --> Database Driver Class Initialized
DEBUG - 2011-08-09 13:07:57 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-09 13:07:57 --> Helper loaded: url_helper
DEBUG - 2011-08-09 13:07:57 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-09 13:07:57 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-09 13:07:57 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-09 13:07:57 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-09 13:07:57 --> Final output sent to browser
DEBUG - 2011-08-09 13:07:57 --> Total execution time: 0.1019
DEBUG - 2011-08-09 13:07:59 --> Config Class Initialized
DEBUG - 2011-08-09 13:07:59 --> Hooks Class Initialized
DEBUG - 2011-08-09 13:07:59 --> Utf8 Class Initialized
DEBUG - 2011-08-09 13:07:59 --> UTF-8 Support Enabled
DEBUG - 2011-08-09 13:07:59 --> URI Class Initialized
DEBUG - 2011-08-09 13:07:59 --> Router Class Initialized
DEBUG - 2011-08-09 13:07:59 --> Output Class Initialized
DEBUG - 2011-08-09 13:07:59 --> Input Class Initialized
DEBUG - 2011-08-09 13:07:59 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-09 13:07:59 --> Language Class Initialized
DEBUG - 2011-08-09 13:07:59 --> Loader Class Initialized
DEBUG - 2011-08-09 13:07:59 --> Controller Class Initialized
DEBUG - 2011-08-09 13:07:59 --> Model Class Initialized
DEBUG - 2011-08-09 13:07:59 --> Model Class Initialized
DEBUG - 2011-08-09 13:07:59 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-09 13:07:59 --> Database Driver Class Initialized
DEBUG - 2011-08-09 13:07:59 --> Final output sent to browser
DEBUG - 2011-08-09 13:07:59 --> Total execution time: 0.5632
DEBUG - 2011-08-09 13:08:03 --> Config Class Initialized
DEBUG - 2011-08-09 13:08:03 --> Hooks Class Initialized
DEBUG - 2011-08-09 13:08:03 --> Utf8 Class Initialized
DEBUG - 2011-08-09 13:08:03 --> UTF-8 Support Enabled
DEBUG - 2011-08-09 13:08:03 --> URI Class Initialized
DEBUG - 2011-08-09 13:08:03 --> Router Class Initialized
ERROR - 2011-08-09 13:08:03 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-09 13:08:41 --> Config Class Initialized
DEBUG - 2011-08-09 13:08:41 --> Hooks Class Initialized
DEBUG - 2011-08-09 13:08:41 --> Utf8 Class Initialized
DEBUG - 2011-08-09 13:08:41 --> UTF-8 Support Enabled
DEBUG - 2011-08-09 13:08:41 --> URI Class Initialized
DEBUG - 2011-08-09 13:08:41 --> Router Class Initialized
DEBUG - 2011-08-09 13:08:41 --> Output Class Initialized
DEBUG - 2011-08-09 13:08:41 --> Input Class Initialized
DEBUG - 2011-08-09 13:08:41 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-09 13:08:41 --> Language Class Initialized
DEBUG - 2011-08-09 13:08:41 --> Loader Class Initialized
DEBUG - 2011-08-09 13:08:41 --> Controller Class Initialized
ERROR - 2011-08-09 13:08:41 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-09 13:08:41 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-09 13:08:41 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-09 13:08:41 --> Model Class Initialized
DEBUG - 2011-08-09 13:08:41 --> Model Class Initialized
DEBUG - 2011-08-09 13:08:41 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-09 13:08:41 --> Database Driver Class Initialized
DEBUG - 2011-08-09 13:08:41 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-09 13:08:41 --> Helper loaded: url_helper
DEBUG - 2011-08-09 13:08:41 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-09 13:08:41 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-09 13:08:41 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-09 13:08:41 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-09 13:08:41 --> Final output sent to browser
DEBUG - 2011-08-09 13:08:41 --> Total execution time: 0.0292
DEBUG - 2011-08-09 13:08:43 --> Config Class Initialized
DEBUG - 2011-08-09 13:08:43 --> Hooks Class Initialized
DEBUG - 2011-08-09 13:08:43 --> Utf8 Class Initialized
DEBUG - 2011-08-09 13:08:43 --> UTF-8 Support Enabled
DEBUG - 2011-08-09 13:08:43 --> URI Class Initialized
DEBUG - 2011-08-09 13:08:43 --> Router Class Initialized
DEBUG - 2011-08-09 13:08:43 --> Output Class Initialized
DEBUG - 2011-08-09 13:08:43 --> Input Class Initialized
DEBUG - 2011-08-09 13:08:43 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-09 13:08:43 --> Language Class Initialized
DEBUG - 2011-08-09 13:08:43 --> Loader Class Initialized
DEBUG - 2011-08-09 13:08:43 --> Controller Class Initialized
DEBUG - 2011-08-09 13:08:43 --> Model Class Initialized
DEBUG - 2011-08-09 13:08:43 --> Model Class Initialized
DEBUG - 2011-08-09 13:08:43 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-09 13:08:43 --> Database Driver Class Initialized
DEBUG - 2011-08-09 13:08:43 --> Final output sent to browser
DEBUG - 2011-08-09 13:08:43 --> Total execution time: 0.5576
DEBUG - 2011-08-09 13:08:49 --> Config Class Initialized
DEBUG - 2011-08-09 13:08:49 --> Hooks Class Initialized
DEBUG - 2011-08-09 13:08:49 --> Utf8 Class Initialized
DEBUG - 2011-08-09 13:08:49 --> UTF-8 Support Enabled
DEBUG - 2011-08-09 13:08:49 --> URI Class Initialized
DEBUG - 2011-08-09 13:08:49 --> Router Class Initialized
ERROR - 2011-08-09 13:08:49 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-09 13:09:00 --> Config Class Initialized
DEBUG - 2011-08-09 13:09:00 --> Hooks Class Initialized
DEBUG - 2011-08-09 13:09:00 --> Utf8 Class Initialized
DEBUG - 2011-08-09 13:09:00 --> UTF-8 Support Enabled
DEBUG - 2011-08-09 13:09:00 --> URI Class Initialized
DEBUG - 2011-08-09 13:09:00 --> Router Class Initialized
DEBUG - 2011-08-09 13:09:00 --> Output Class Initialized
DEBUG - 2011-08-09 13:09:00 --> Input Class Initialized
DEBUG - 2011-08-09 13:09:00 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-09 13:09:00 --> Language Class Initialized
DEBUG - 2011-08-09 13:09:00 --> Loader Class Initialized
DEBUG - 2011-08-09 13:09:00 --> Controller Class Initialized
ERROR - 2011-08-09 13:09:00 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-09 13:09:00 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-09 13:09:00 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-09 13:09:00 --> Model Class Initialized
DEBUG - 2011-08-09 13:09:00 --> Model Class Initialized
DEBUG - 2011-08-09 13:09:00 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-09 13:09:00 --> Database Driver Class Initialized
DEBUG - 2011-08-09 13:09:00 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-09 13:09:00 --> Helper loaded: url_helper
DEBUG - 2011-08-09 13:09:00 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-09 13:09:00 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-09 13:09:00 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-09 13:09:00 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-09 13:09:00 --> Final output sent to browser
DEBUG - 2011-08-09 13:09:00 --> Total execution time: 0.0307
DEBUG - 2011-08-09 13:09:02 --> Config Class Initialized
DEBUG - 2011-08-09 13:09:02 --> Hooks Class Initialized
DEBUG - 2011-08-09 13:09:02 --> Utf8 Class Initialized
DEBUG - 2011-08-09 13:09:02 --> UTF-8 Support Enabled
DEBUG - 2011-08-09 13:09:02 --> URI Class Initialized
DEBUG - 2011-08-09 13:09:02 --> Router Class Initialized
DEBUG - 2011-08-09 13:09:02 --> Output Class Initialized
DEBUG - 2011-08-09 13:09:02 --> Input Class Initialized
DEBUG - 2011-08-09 13:09:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-09 13:09:02 --> Language Class Initialized
DEBUG - 2011-08-09 13:09:02 --> Loader Class Initialized
DEBUG - 2011-08-09 13:09:02 --> Controller Class Initialized
DEBUG - 2011-08-09 13:09:02 --> Model Class Initialized
DEBUG - 2011-08-09 13:09:02 --> Model Class Initialized
DEBUG - 2011-08-09 13:09:02 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-09 13:09:02 --> Database Driver Class Initialized
DEBUG - 2011-08-09 13:09:03 --> Final output sent to browser
DEBUG - 2011-08-09 13:09:03 --> Total execution time: 0.5052
DEBUG - 2011-08-09 13:09:07 --> Config Class Initialized
DEBUG - 2011-08-09 13:09:07 --> Hooks Class Initialized
DEBUG - 2011-08-09 13:09:07 --> Utf8 Class Initialized
DEBUG - 2011-08-09 13:09:07 --> UTF-8 Support Enabled
DEBUG - 2011-08-09 13:09:07 --> URI Class Initialized
DEBUG - 2011-08-09 13:09:07 --> Router Class Initialized
ERROR - 2011-08-09 13:09:07 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-09 13:09:28 --> Config Class Initialized
DEBUG - 2011-08-09 13:09:28 --> Hooks Class Initialized
DEBUG - 2011-08-09 13:09:28 --> Utf8 Class Initialized
DEBUG - 2011-08-09 13:09:28 --> UTF-8 Support Enabled
DEBUG - 2011-08-09 13:09:28 --> URI Class Initialized
DEBUG - 2011-08-09 13:09:28 --> Router Class Initialized
DEBUG - 2011-08-09 13:09:28 --> Output Class Initialized
DEBUG - 2011-08-09 13:09:28 --> Input Class Initialized
DEBUG - 2011-08-09 13:09:28 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-09 13:09:28 --> Language Class Initialized
DEBUG - 2011-08-09 13:09:28 --> Loader Class Initialized
DEBUG - 2011-08-09 13:09:28 --> Controller Class Initialized
ERROR - 2011-08-09 13:09:28 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-09 13:09:28 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-09 13:09:28 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-09 13:09:28 --> Model Class Initialized
DEBUG - 2011-08-09 13:09:28 --> Model Class Initialized
DEBUG - 2011-08-09 13:09:28 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-09 13:09:28 --> Database Driver Class Initialized
DEBUG - 2011-08-09 13:09:28 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-09 13:09:28 --> Helper loaded: url_helper
DEBUG - 2011-08-09 13:09:28 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-09 13:09:28 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-09 13:09:28 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-09 13:09:28 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-09 13:09:28 --> Final output sent to browser
DEBUG - 2011-08-09 13:09:28 --> Total execution time: 0.0386
DEBUG - 2011-08-09 13:09:30 --> Config Class Initialized
DEBUG - 2011-08-09 13:09:30 --> Hooks Class Initialized
DEBUG - 2011-08-09 13:09:30 --> Utf8 Class Initialized
DEBUG - 2011-08-09 13:09:30 --> UTF-8 Support Enabled
DEBUG - 2011-08-09 13:09:30 --> URI Class Initialized
DEBUG - 2011-08-09 13:09:30 --> Router Class Initialized
DEBUG - 2011-08-09 13:09:30 --> Output Class Initialized
DEBUG - 2011-08-09 13:09:30 --> Input Class Initialized
DEBUG - 2011-08-09 13:09:30 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-09 13:09:30 --> Language Class Initialized
DEBUG - 2011-08-09 13:09:30 --> Loader Class Initialized
DEBUG - 2011-08-09 13:09:30 --> Controller Class Initialized
DEBUG - 2011-08-09 13:09:30 --> Model Class Initialized
DEBUG - 2011-08-09 13:09:30 --> Model Class Initialized
DEBUG - 2011-08-09 13:09:30 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-09 13:09:30 --> Database Driver Class Initialized
DEBUG - 2011-08-09 13:09:30 --> Final output sent to browser
DEBUG - 2011-08-09 13:09:30 --> Total execution time: 0.5654
DEBUG - 2011-08-09 13:09:35 --> Config Class Initialized
DEBUG - 2011-08-09 13:09:35 --> Hooks Class Initialized
DEBUG - 2011-08-09 13:09:35 --> Utf8 Class Initialized
DEBUG - 2011-08-09 13:09:35 --> UTF-8 Support Enabled
DEBUG - 2011-08-09 13:09:35 --> URI Class Initialized
DEBUG - 2011-08-09 13:09:35 --> Router Class Initialized
ERROR - 2011-08-09 13:09:35 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-09 13:09:59 --> Config Class Initialized
DEBUG - 2011-08-09 13:09:59 --> Hooks Class Initialized
DEBUG - 2011-08-09 13:09:59 --> Utf8 Class Initialized
DEBUG - 2011-08-09 13:09:59 --> UTF-8 Support Enabled
DEBUG - 2011-08-09 13:09:59 --> URI Class Initialized
DEBUG - 2011-08-09 13:09:59 --> Router Class Initialized
DEBUG - 2011-08-09 13:09:59 --> Output Class Initialized
DEBUG - 2011-08-09 13:09:59 --> Input Class Initialized
DEBUG - 2011-08-09 13:09:59 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-09 13:09:59 --> Language Class Initialized
DEBUG - 2011-08-09 13:09:59 --> Loader Class Initialized
DEBUG - 2011-08-09 13:09:59 --> Controller Class Initialized
ERROR - 2011-08-09 13:09:59 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-09 13:09:59 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-09 13:09:59 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-09 13:09:59 --> Model Class Initialized
DEBUG - 2011-08-09 13:09:59 --> Model Class Initialized
DEBUG - 2011-08-09 13:09:59 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-09 13:09:59 --> Database Driver Class Initialized
DEBUG - 2011-08-09 13:09:59 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-09 13:09:59 --> Helper loaded: url_helper
DEBUG - 2011-08-09 13:09:59 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-09 13:09:59 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-09 13:09:59 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-09 13:09:59 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-09 13:09:59 --> Final output sent to browser
DEBUG - 2011-08-09 13:09:59 --> Total execution time: 0.0285
DEBUG - 2011-08-09 13:10:01 --> Config Class Initialized
DEBUG - 2011-08-09 13:10:01 --> Hooks Class Initialized
DEBUG - 2011-08-09 13:10:01 --> Utf8 Class Initialized
DEBUG - 2011-08-09 13:10:01 --> UTF-8 Support Enabled
DEBUG - 2011-08-09 13:10:01 --> URI Class Initialized
DEBUG - 2011-08-09 13:10:01 --> Router Class Initialized
DEBUG - 2011-08-09 13:10:01 --> Output Class Initialized
DEBUG - 2011-08-09 13:10:01 --> Input Class Initialized
DEBUG - 2011-08-09 13:10:01 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-09 13:10:01 --> Language Class Initialized
DEBUG - 2011-08-09 13:10:01 --> Loader Class Initialized
DEBUG - 2011-08-09 13:10:01 --> Controller Class Initialized
DEBUG - 2011-08-09 13:10:01 --> Model Class Initialized
DEBUG - 2011-08-09 13:10:01 --> Model Class Initialized
DEBUG - 2011-08-09 13:10:01 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-09 13:10:01 --> Database Driver Class Initialized
DEBUG - 2011-08-09 13:10:01 --> Final output sent to browser
DEBUG - 2011-08-09 13:10:01 --> Total execution time: 0.6107
DEBUG - 2011-08-09 13:10:05 --> Config Class Initialized
DEBUG - 2011-08-09 13:10:05 --> Hooks Class Initialized
DEBUG - 2011-08-09 13:10:05 --> Utf8 Class Initialized
DEBUG - 2011-08-09 13:10:05 --> UTF-8 Support Enabled
DEBUG - 2011-08-09 13:10:05 --> URI Class Initialized
DEBUG - 2011-08-09 13:10:05 --> Router Class Initialized
ERROR - 2011-08-09 13:10:05 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-09 13:10:56 --> Config Class Initialized
DEBUG - 2011-08-09 13:10:56 --> Hooks Class Initialized
DEBUG - 2011-08-09 13:10:56 --> Utf8 Class Initialized
DEBUG - 2011-08-09 13:10:56 --> UTF-8 Support Enabled
DEBUG - 2011-08-09 13:10:56 --> URI Class Initialized
DEBUG - 2011-08-09 13:10:56 --> Router Class Initialized
DEBUG - 2011-08-09 13:10:56 --> Output Class Initialized
DEBUG - 2011-08-09 13:10:56 --> Input Class Initialized
DEBUG - 2011-08-09 13:10:56 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-09 13:10:56 --> Language Class Initialized
DEBUG - 2011-08-09 13:10:56 --> Loader Class Initialized
DEBUG - 2011-08-09 13:10:56 --> Controller Class Initialized
ERROR - 2011-08-09 13:10:56 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-09 13:10:56 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-09 13:10:56 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-09 13:10:56 --> Model Class Initialized
DEBUG - 2011-08-09 13:10:56 --> Model Class Initialized
DEBUG - 2011-08-09 13:10:56 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-09 13:10:56 --> Database Driver Class Initialized
DEBUG - 2011-08-09 13:10:56 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-09 13:10:56 --> Helper loaded: url_helper
DEBUG - 2011-08-09 13:10:56 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-09 13:10:56 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-09 13:10:56 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-09 13:10:56 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-09 13:10:56 --> Final output sent to browser
DEBUG - 2011-08-09 13:10:56 --> Total execution time: 0.0288
DEBUG - 2011-08-09 13:10:58 --> Config Class Initialized
DEBUG - 2011-08-09 13:10:58 --> Hooks Class Initialized
DEBUG - 2011-08-09 13:10:58 --> Utf8 Class Initialized
DEBUG - 2011-08-09 13:10:58 --> UTF-8 Support Enabled
DEBUG - 2011-08-09 13:10:58 --> URI Class Initialized
DEBUG - 2011-08-09 13:10:58 --> Router Class Initialized
DEBUG - 2011-08-09 13:10:58 --> Output Class Initialized
DEBUG - 2011-08-09 13:10:58 --> Input Class Initialized
DEBUG - 2011-08-09 13:10:58 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-09 13:10:58 --> Language Class Initialized
DEBUG - 2011-08-09 13:10:58 --> Loader Class Initialized
DEBUG - 2011-08-09 13:10:58 --> Controller Class Initialized
DEBUG - 2011-08-09 13:10:58 --> Model Class Initialized
DEBUG - 2011-08-09 13:10:58 --> Model Class Initialized
DEBUG - 2011-08-09 13:10:58 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-09 13:10:58 --> Database Driver Class Initialized
DEBUG - 2011-08-09 13:10:58 --> Final output sent to browser
DEBUG - 2011-08-09 13:10:58 --> Total execution time: 0.6175
DEBUG - 2011-08-09 13:11:02 --> Config Class Initialized
DEBUG - 2011-08-09 13:11:02 --> Hooks Class Initialized
DEBUG - 2011-08-09 13:11:02 --> Utf8 Class Initialized
DEBUG - 2011-08-09 13:11:02 --> UTF-8 Support Enabled
DEBUG - 2011-08-09 13:11:02 --> URI Class Initialized
DEBUG - 2011-08-09 13:11:02 --> Router Class Initialized
ERROR - 2011-08-09 13:11:02 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-09 13:11:18 --> Config Class Initialized
DEBUG - 2011-08-09 13:11:18 --> Hooks Class Initialized
DEBUG - 2011-08-09 13:11:18 --> Utf8 Class Initialized
DEBUG - 2011-08-09 13:11:18 --> UTF-8 Support Enabled
DEBUG - 2011-08-09 13:11:18 --> URI Class Initialized
DEBUG - 2011-08-09 13:11:18 --> Router Class Initialized
DEBUG - 2011-08-09 13:11:18 --> Output Class Initialized
DEBUG - 2011-08-09 13:11:18 --> Input Class Initialized
DEBUG - 2011-08-09 13:11:18 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-09 13:11:18 --> Language Class Initialized
DEBUG - 2011-08-09 13:11:18 --> Loader Class Initialized
DEBUG - 2011-08-09 13:11:18 --> Controller Class Initialized
ERROR - 2011-08-09 13:11:18 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-09 13:11:18 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-09 13:11:18 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-09 13:11:18 --> Model Class Initialized
DEBUG - 2011-08-09 13:11:18 --> Model Class Initialized
DEBUG - 2011-08-09 13:11:18 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-09 13:11:18 --> Database Driver Class Initialized
DEBUG - 2011-08-09 13:11:18 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-09 13:11:18 --> Helper loaded: url_helper
DEBUG - 2011-08-09 13:11:18 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-09 13:11:18 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-09 13:11:18 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-09 13:11:18 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-09 13:11:18 --> Final output sent to browser
DEBUG - 2011-08-09 13:11:18 --> Total execution time: 0.0291
DEBUG - 2011-08-09 13:11:20 --> Config Class Initialized
DEBUG - 2011-08-09 13:11:20 --> Hooks Class Initialized
DEBUG - 2011-08-09 13:11:20 --> Utf8 Class Initialized
DEBUG - 2011-08-09 13:11:20 --> UTF-8 Support Enabled
DEBUG - 2011-08-09 13:11:20 --> URI Class Initialized
DEBUG - 2011-08-09 13:11:20 --> Router Class Initialized
DEBUG - 2011-08-09 13:11:20 --> Output Class Initialized
DEBUG - 2011-08-09 13:11:20 --> Input Class Initialized
DEBUG - 2011-08-09 13:11:20 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-09 13:11:20 --> Language Class Initialized
DEBUG - 2011-08-09 13:11:20 --> Loader Class Initialized
DEBUG - 2011-08-09 13:11:20 --> Controller Class Initialized
DEBUG - 2011-08-09 13:11:20 --> Model Class Initialized
DEBUG - 2011-08-09 13:11:20 --> Model Class Initialized
DEBUG - 2011-08-09 13:11:20 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-09 13:11:20 --> Database Driver Class Initialized
DEBUG - 2011-08-09 13:11:21 --> Final output sent to browser
DEBUG - 2011-08-09 13:11:21 --> Total execution time: 0.5106
DEBUG - 2011-08-09 13:11:25 --> Config Class Initialized
DEBUG - 2011-08-09 13:11:25 --> Hooks Class Initialized
DEBUG - 2011-08-09 13:11:25 --> Utf8 Class Initialized
DEBUG - 2011-08-09 13:11:25 --> UTF-8 Support Enabled
DEBUG - 2011-08-09 13:11:25 --> URI Class Initialized
DEBUG - 2011-08-09 13:11:25 --> Router Class Initialized
ERROR - 2011-08-09 13:11:25 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-08-09 13:11:27 --> Config Class Initialized
DEBUG - 2011-08-09 13:11:27 --> Hooks Class Initialized
DEBUG - 2011-08-09 13:11:27 --> Utf8 Class Initialized
DEBUG - 2011-08-09 13:11:27 --> UTF-8 Support Enabled
DEBUG - 2011-08-09 13:11:27 --> URI Class Initialized
DEBUG - 2011-08-09 13:11:27 --> Router Class Initialized
ERROR - 2011-08-09 13:11:27 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-09 13:11:34 --> Config Class Initialized
DEBUG - 2011-08-09 13:11:34 --> Hooks Class Initialized
DEBUG - 2011-08-09 13:11:34 --> Utf8 Class Initialized
DEBUG - 2011-08-09 13:11:34 --> UTF-8 Support Enabled
DEBUG - 2011-08-09 13:11:34 --> URI Class Initialized
DEBUG - 2011-08-09 13:11:34 --> Router Class Initialized
DEBUG - 2011-08-09 13:11:34 --> Output Class Initialized
DEBUG - 2011-08-09 13:11:34 --> Input Class Initialized
DEBUG - 2011-08-09 13:11:34 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-09 13:11:34 --> Language Class Initialized
DEBUG - 2011-08-09 13:11:34 --> Loader Class Initialized
DEBUG - 2011-08-09 13:11:34 --> Controller Class Initialized
ERROR - 2011-08-09 13:11:34 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-09 13:11:34 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-09 13:11:34 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-09 13:11:34 --> Model Class Initialized
DEBUG - 2011-08-09 13:11:34 --> Model Class Initialized
DEBUG - 2011-08-09 13:11:34 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-09 13:11:34 --> Database Driver Class Initialized
DEBUG - 2011-08-09 13:11:34 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-09 13:11:34 --> Helper loaded: url_helper
DEBUG - 2011-08-09 13:11:34 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-09 13:11:34 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-09 13:11:34 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-09 13:11:34 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-09 13:11:34 --> Final output sent to browser
DEBUG - 2011-08-09 13:11:34 --> Total execution time: 0.0587
DEBUG - 2011-08-09 13:11:37 --> Config Class Initialized
DEBUG - 2011-08-09 13:11:37 --> Hooks Class Initialized
DEBUG - 2011-08-09 13:11:37 --> Utf8 Class Initialized
DEBUG - 2011-08-09 13:11:37 --> UTF-8 Support Enabled
DEBUG - 2011-08-09 13:11:37 --> URI Class Initialized
DEBUG - 2011-08-09 13:11:37 --> Router Class Initialized
DEBUG - 2011-08-09 13:11:37 --> Output Class Initialized
DEBUG - 2011-08-09 13:11:37 --> Input Class Initialized
DEBUG - 2011-08-09 13:11:37 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-09 13:11:37 --> Language Class Initialized
DEBUG - 2011-08-09 13:11:37 --> Loader Class Initialized
DEBUG - 2011-08-09 13:11:37 --> Controller Class Initialized
DEBUG - 2011-08-09 13:11:37 --> Model Class Initialized
DEBUG - 2011-08-09 13:11:37 --> Model Class Initialized
DEBUG - 2011-08-09 13:11:37 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-09 13:11:37 --> Database Driver Class Initialized
DEBUG - 2011-08-09 13:11:37 --> Final output sent to browser
DEBUG - 2011-08-09 13:11:37 --> Total execution time: 0.6781
DEBUG - 2011-08-09 13:11:42 --> Config Class Initialized
DEBUG - 2011-08-09 13:11:42 --> Hooks Class Initialized
DEBUG - 2011-08-09 13:11:42 --> Utf8 Class Initialized
DEBUG - 2011-08-09 13:11:42 --> UTF-8 Support Enabled
DEBUG - 2011-08-09 13:11:42 --> URI Class Initialized
DEBUG - 2011-08-09 13:11:42 --> Router Class Initialized
ERROR - 2011-08-09 13:11:42 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-09 13:11:48 --> Config Class Initialized
DEBUG - 2011-08-09 13:11:48 --> Hooks Class Initialized
DEBUG - 2011-08-09 13:11:48 --> Utf8 Class Initialized
DEBUG - 2011-08-09 13:11:48 --> UTF-8 Support Enabled
DEBUG - 2011-08-09 13:11:48 --> URI Class Initialized
DEBUG - 2011-08-09 13:11:48 --> Router Class Initialized
DEBUG - 2011-08-09 13:11:48 --> Output Class Initialized
DEBUG - 2011-08-09 13:11:48 --> Input Class Initialized
DEBUG - 2011-08-09 13:11:48 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-09 13:11:48 --> Language Class Initialized
DEBUG - 2011-08-09 13:11:48 --> Loader Class Initialized
DEBUG - 2011-08-09 13:11:48 --> Controller Class Initialized
ERROR - 2011-08-09 13:11:48 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-09 13:11:48 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-09 13:11:48 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-09 13:11:48 --> Model Class Initialized
DEBUG - 2011-08-09 13:11:48 --> Model Class Initialized
DEBUG - 2011-08-09 13:11:48 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-09 13:11:48 --> Database Driver Class Initialized
DEBUG - 2011-08-09 13:11:48 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-09 13:11:48 --> Helper loaded: url_helper
DEBUG - 2011-08-09 13:11:48 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-09 13:11:48 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-09 13:11:48 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-09 13:11:48 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-09 13:11:48 --> Final output sent to browser
DEBUG - 2011-08-09 13:11:48 --> Total execution time: 0.0586
DEBUG - 2011-08-09 13:11:50 --> Config Class Initialized
DEBUG - 2011-08-09 13:11:50 --> Hooks Class Initialized
DEBUG - 2011-08-09 13:11:50 --> Utf8 Class Initialized
DEBUG - 2011-08-09 13:11:50 --> UTF-8 Support Enabled
DEBUG - 2011-08-09 13:11:50 --> URI Class Initialized
DEBUG - 2011-08-09 13:11:50 --> Router Class Initialized
DEBUG - 2011-08-09 13:11:50 --> Output Class Initialized
DEBUG - 2011-08-09 13:11:50 --> Input Class Initialized
DEBUG - 2011-08-09 13:11:50 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-09 13:11:50 --> Language Class Initialized
DEBUG - 2011-08-09 13:11:50 --> Loader Class Initialized
DEBUG - 2011-08-09 13:11:50 --> Controller Class Initialized
DEBUG - 2011-08-09 13:11:50 --> Model Class Initialized
DEBUG - 2011-08-09 13:11:50 --> Model Class Initialized
DEBUG - 2011-08-09 13:11:50 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-09 13:11:50 --> Database Driver Class Initialized
DEBUG - 2011-08-09 13:11:51 --> Final output sent to browser
DEBUG - 2011-08-09 13:11:51 --> Total execution time: 0.5662
DEBUG - 2011-08-09 13:11:55 --> Config Class Initialized
DEBUG - 2011-08-09 13:11:55 --> Hooks Class Initialized
DEBUG - 2011-08-09 13:11:55 --> Utf8 Class Initialized
DEBUG - 2011-08-09 13:11:55 --> UTF-8 Support Enabled
DEBUG - 2011-08-09 13:11:55 --> URI Class Initialized
DEBUG - 2011-08-09 13:11:55 --> Router Class Initialized
ERROR - 2011-08-09 13:11:55 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-09 13:25:16 --> Config Class Initialized
DEBUG - 2011-08-09 13:25:16 --> Hooks Class Initialized
DEBUG - 2011-08-09 13:25:16 --> Utf8 Class Initialized
DEBUG - 2011-08-09 13:25:16 --> UTF-8 Support Enabled
DEBUG - 2011-08-09 13:25:16 --> URI Class Initialized
DEBUG - 2011-08-09 13:25:16 --> Router Class Initialized
DEBUG - 2011-08-09 13:25:16 --> Output Class Initialized
DEBUG - 2011-08-09 13:25:16 --> Input Class Initialized
DEBUG - 2011-08-09 13:25:16 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-09 13:25:16 --> Language Class Initialized
DEBUG - 2011-08-09 13:25:16 --> Loader Class Initialized
DEBUG - 2011-08-09 13:25:16 --> Controller Class Initialized
ERROR - 2011-08-09 13:25:16 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-09 13:25:16 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-09 13:25:16 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-09 13:25:16 --> Model Class Initialized
DEBUG - 2011-08-09 13:25:16 --> Model Class Initialized
DEBUG - 2011-08-09 13:25:16 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-09 13:25:16 --> Database Driver Class Initialized
DEBUG - 2011-08-09 13:25:16 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-09 13:25:16 --> Helper loaded: url_helper
DEBUG - 2011-08-09 13:25:16 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-09 13:25:16 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-09 13:25:16 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-09 13:25:16 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-09 13:25:16 --> Final output sent to browser
DEBUG - 2011-08-09 13:25:16 --> Total execution time: 0.0319
DEBUG - 2011-08-09 13:25:17 --> Config Class Initialized
DEBUG - 2011-08-09 13:25:17 --> Hooks Class Initialized
DEBUG - 2011-08-09 13:25:17 --> Utf8 Class Initialized
DEBUG - 2011-08-09 13:25:17 --> UTF-8 Support Enabled
DEBUG - 2011-08-09 13:25:17 --> URI Class Initialized
DEBUG - 2011-08-09 13:25:17 --> Router Class Initialized
DEBUG - 2011-08-09 13:25:17 --> Output Class Initialized
DEBUG - 2011-08-09 13:25:17 --> Input Class Initialized
DEBUG - 2011-08-09 13:25:17 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-09 13:25:17 --> Language Class Initialized
DEBUG - 2011-08-09 13:25:17 --> Loader Class Initialized
DEBUG - 2011-08-09 13:25:17 --> Controller Class Initialized
DEBUG - 2011-08-09 13:25:17 --> Model Class Initialized
DEBUG - 2011-08-09 13:25:17 --> Model Class Initialized
DEBUG - 2011-08-09 13:25:17 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-09 13:25:17 --> Database Driver Class Initialized
DEBUG - 2011-08-09 13:25:18 --> Final output sent to browser
DEBUG - 2011-08-09 13:25:18 --> Total execution time: 0.6457
DEBUG - 2011-08-09 13:25:19 --> Config Class Initialized
DEBUG - 2011-08-09 13:25:19 --> Hooks Class Initialized
DEBUG - 2011-08-09 13:25:19 --> Utf8 Class Initialized
DEBUG - 2011-08-09 13:25:19 --> UTF-8 Support Enabled
DEBUG - 2011-08-09 13:25:19 --> URI Class Initialized
DEBUG - 2011-08-09 13:25:19 --> Router Class Initialized
ERROR - 2011-08-09 13:25:19 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-09 13:25:19 --> Config Class Initialized
DEBUG - 2011-08-09 13:25:19 --> Hooks Class Initialized
DEBUG - 2011-08-09 13:25:19 --> Utf8 Class Initialized
DEBUG - 2011-08-09 13:25:19 --> UTF-8 Support Enabled
DEBUG - 2011-08-09 13:25:19 --> URI Class Initialized
DEBUG - 2011-08-09 13:25:19 --> Router Class Initialized
ERROR - 2011-08-09 13:25:19 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-09 13:25:29 --> Config Class Initialized
DEBUG - 2011-08-09 13:25:29 --> Hooks Class Initialized
DEBUG - 2011-08-09 13:25:29 --> Utf8 Class Initialized
DEBUG - 2011-08-09 13:25:29 --> UTF-8 Support Enabled
DEBUG - 2011-08-09 13:25:29 --> URI Class Initialized
DEBUG - 2011-08-09 13:25:29 --> Router Class Initialized
DEBUG - 2011-08-09 13:25:29 --> Output Class Initialized
DEBUG - 2011-08-09 13:25:29 --> Input Class Initialized
DEBUG - 2011-08-09 13:25:29 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-09 13:25:29 --> Language Class Initialized
DEBUG - 2011-08-09 13:25:29 --> Loader Class Initialized
DEBUG - 2011-08-09 13:25:29 --> Controller Class Initialized
ERROR - 2011-08-09 13:25:29 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-09 13:25:29 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-09 13:25:29 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-09 13:25:29 --> Model Class Initialized
DEBUG - 2011-08-09 13:25:29 --> Model Class Initialized
DEBUG - 2011-08-09 13:25:29 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-09 13:25:29 --> Database Driver Class Initialized
DEBUG - 2011-08-09 13:25:29 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-09 13:25:29 --> Helper loaded: url_helper
DEBUG - 2011-08-09 13:25:29 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-09 13:25:29 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-09 13:25:29 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-09 13:25:29 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-09 13:25:29 --> Final output sent to browser
DEBUG - 2011-08-09 13:25:29 --> Total execution time: 0.0297
DEBUG - 2011-08-09 13:25:30 --> Config Class Initialized
DEBUG - 2011-08-09 13:25:30 --> Hooks Class Initialized
DEBUG - 2011-08-09 13:25:30 --> Utf8 Class Initialized
DEBUG - 2011-08-09 13:25:30 --> UTF-8 Support Enabled
DEBUG - 2011-08-09 13:25:30 --> URI Class Initialized
DEBUG - 2011-08-09 13:25:30 --> Router Class Initialized
DEBUG - 2011-08-09 13:25:30 --> Output Class Initialized
DEBUG - 2011-08-09 13:25:30 --> Input Class Initialized
DEBUG - 2011-08-09 13:25:30 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-09 13:25:30 --> Language Class Initialized
DEBUG - 2011-08-09 13:25:30 --> Loader Class Initialized
DEBUG - 2011-08-09 13:25:30 --> Controller Class Initialized
DEBUG - 2011-08-09 13:25:30 --> Model Class Initialized
DEBUG - 2011-08-09 13:25:30 --> Model Class Initialized
DEBUG - 2011-08-09 13:25:30 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-09 13:25:30 --> Database Driver Class Initialized
DEBUG - 2011-08-09 13:25:31 --> Final output sent to browser
DEBUG - 2011-08-09 13:25:31 --> Total execution time: 0.5503
DEBUG - 2011-08-09 13:25:39 --> Config Class Initialized
DEBUG - 2011-08-09 13:25:39 --> Hooks Class Initialized
DEBUG - 2011-08-09 13:25:39 --> Utf8 Class Initialized
DEBUG - 2011-08-09 13:25:39 --> UTF-8 Support Enabled
DEBUG - 2011-08-09 13:25:39 --> URI Class Initialized
DEBUG - 2011-08-09 13:25:39 --> Router Class Initialized
DEBUG - 2011-08-09 13:25:39 --> Output Class Initialized
DEBUG - 2011-08-09 13:25:39 --> Input Class Initialized
DEBUG - 2011-08-09 13:25:39 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-09 13:25:39 --> Language Class Initialized
DEBUG - 2011-08-09 13:25:39 --> Loader Class Initialized
DEBUG - 2011-08-09 13:25:39 --> Controller Class Initialized
ERROR - 2011-08-09 13:25:39 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-09 13:25:39 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-09 13:25:39 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-09 13:25:39 --> Model Class Initialized
DEBUG - 2011-08-09 13:25:39 --> Model Class Initialized
DEBUG - 2011-08-09 13:25:39 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-09 13:25:39 --> Database Driver Class Initialized
DEBUG - 2011-08-09 13:25:39 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-09 13:25:39 --> Helper loaded: url_helper
DEBUG - 2011-08-09 13:25:39 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-09 13:25:39 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-09 13:25:39 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-09 13:25:39 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-09 13:25:39 --> Final output sent to browser
DEBUG - 2011-08-09 13:25:39 --> Total execution time: 0.0672
DEBUG - 2011-08-09 13:25:45 --> Config Class Initialized
DEBUG - 2011-08-09 13:25:45 --> Hooks Class Initialized
DEBUG - 2011-08-09 13:25:45 --> Utf8 Class Initialized
DEBUG - 2011-08-09 13:25:45 --> UTF-8 Support Enabled
DEBUG - 2011-08-09 13:25:45 --> URI Class Initialized
DEBUG - 2011-08-09 13:25:45 --> Router Class Initialized
DEBUG - 2011-08-09 13:25:45 --> Output Class Initialized
DEBUG - 2011-08-09 13:25:45 --> Input Class Initialized
DEBUG - 2011-08-09 13:25:45 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-09 13:25:45 --> Language Class Initialized
DEBUG - 2011-08-09 13:25:45 --> Loader Class Initialized
DEBUG - 2011-08-09 13:25:45 --> Controller Class Initialized
ERROR - 2011-08-09 13:25:45 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-09 13:25:45 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-09 13:25:45 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-09 13:25:45 --> Model Class Initialized
DEBUG - 2011-08-09 13:25:45 --> Model Class Initialized
DEBUG - 2011-08-09 13:25:45 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-09 13:25:45 --> Database Driver Class Initialized
DEBUG - 2011-08-09 13:25:45 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-09 13:25:45 --> Helper loaded: url_helper
DEBUG - 2011-08-09 13:25:45 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-09 13:25:45 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-09 13:25:45 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-09 13:25:45 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-09 13:25:45 --> Final output sent to browser
DEBUG - 2011-08-09 13:25:45 --> Total execution time: 0.0286
DEBUG - 2011-08-09 13:25:46 --> Config Class Initialized
DEBUG - 2011-08-09 13:25:46 --> Hooks Class Initialized
DEBUG - 2011-08-09 13:25:46 --> Utf8 Class Initialized
DEBUG - 2011-08-09 13:25:46 --> UTF-8 Support Enabled
DEBUG - 2011-08-09 13:25:46 --> URI Class Initialized
DEBUG - 2011-08-09 13:25:46 --> Router Class Initialized
DEBUG - 2011-08-09 13:25:46 --> Output Class Initialized
DEBUG - 2011-08-09 13:25:46 --> Input Class Initialized
DEBUG - 2011-08-09 13:25:46 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-09 13:25:46 --> Language Class Initialized
DEBUG - 2011-08-09 13:25:46 --> Loader Class Initialized
DEBUG - 2011-08-09 13:25:46 --> Controller Class Initialized
DEBUG - 2011-08-09 13:25:46 --> Model Class Initialized
DEBUG - 2011-08-09 13:25:46 --> Model Class Initialized
DEBUG - 2011-08-09 13:25:46 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-09 13:25:46 --> Database Driver Class Initialized
DEBUG - 2011-08-09 13:25:46 --> Final output sent to browser
DEBUG - 2011-08-09 13:25:46 --> Total execution time: 0.5943
DEBUG - 2011-08-09 13:26:36 --> Config Class Initialized
DEBUG - 2011-08-09 13:26:36 --> Hooks Class Initialized
DEBUG - 2011-08-09 13:26:36 --> Utf8 Class Initialized
DEBUG - 2011-08-09 13:26:36 --> UTF-8 Support Enabled
DEBUG - 2011-08-09 13:26:36 --> URI Class Initialized
DEBUG - 2011-08-09 13:26:36 --> Router Class Initialized
DEBUG - 2011-08-09 13:26:36 --> Output Class Initialized
DEBUG - 2011-08-09 13:26:36 --> Input Class Initialized
DEBUG - 2011-08-09 13:26:36 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-09 13:26:36 --> Language Class Initialized
DEBUG - 2011-08-09 13:26:36 --> Loader Class Initialized
DEBUG - 2011-08-09 13:26:36 --> Controller Class Initialized
DEBUG - 2011-08-09 13:26:36 --> Model Class Initialized
DEBUG - 2011-08-09 13:26:36 --> Model Class Initialized
DEBUG - 2011-08-09 13:26:36 --> Model Class Initialized
DEBUG - 2011-08-09 13:26:36 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-09 13:26:36 --> Database Driver Class Initialized
DEBUG - 2011-08-09 13:26:37 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-09 13:26:37 --> Helper loaded: url_helper
DEBUG - 2011-08-09 13:26:37 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-09 13:26:37 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-09 13:26:37 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-09 13:26:37 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-09 13:26:37 --> Final output sent to browser
DEBUG - 2011-08-09 13:26:37 --> Total execution time: 0.2778
DEBUG - 2011-08-09 14:48:58 --> Config Class Initialized
DEBUG - 2011-08-09 14:48:58 --> Hooks Class Initialized
DEBUG - 2011-08-09 14:48:58 --> Utf8 Class Initialized
DEBUG - 2011-08-09 14:48:58 --> UTF-8 Support Enabled
DEBUG - 2011-08-09 14:48:58 --> URI Class Initialized
DEBUG - 2011-08-09 14:48:58 --> Router Class Initialized
DEBUG - 2011-08-09 14:48:58 --> No URI present. Default controller set.
DEBUG - 2011-08-09 14:48:58 --> Output Class Initialized
DEBUG - 2011-08-09 14:48:58 --> Input Class Initialized
DEBUG - 2011-08-09 14:48:58 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-09 14:48:58 --> Language Class Initialized
DEBUG - 2011-08-09 14:48:58 --> Loader Class Initialized
DEBUG - 2011-08-09 14:48:58 --> Controller Class Initialized
DEBUG - 2011-08-09 14:48:58 --> File loaded: application/views/splash/main.php
DEBUG - 2011-08-09 14:48:58 --> Helper loaded: url_helper
DEBUG - 2011-08-09 14:48:58 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-09 14:48:58 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-09 14:48:58 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-09 14:48:58 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-09 14:48:58 --> Final output sent to browser
DEBUG - 2011-08-09 14:48:58 --> Total execution time: 0.1034
DEBUG - 2011-08-09 14:49:11 --> Config Class Initialized
DEBUG - 2011-08-09 14:49:11 --> Hooks Class Initialized
DEBUG - 2011-08-09 14:49:11 --> Utf8 Class Initialized
DEBUG - 2011-08-09 14:49:11 --> UTF-8 Support Enabled
DEBUG - 2011-08-09 14:49:11 --> URI Class Initialized
DEBUG - 2011-08-09 14:49:11 --> Router Class Initialized
DEBUG - 2011-08-09 14:49:11 --> Output Class Initialized
DEBUG - 2011-08-09 14:49:11 --> Input Class Initialized
DEBUG - 2011-08-09 14:49:11 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-09 14:49:11 --> Language Class Initialized
DEBUG - 2011-08-09 14:49:11 --> Loader Class Initialized
DEBUG - 2011-08-09 14:49:11 --> Controller Class Initialized
ERROR - 2011-08-09 14:49:11 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-09 14:49:11 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-09 14:49:11 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-09 14:49:11 --> Model Class Initialized
DEBUG - 2011-08-09 14:49:11 --> Model Class Initialized
DEBUG - 2011-08-09 14:49:11 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-09 14:49:11 --> Database Driver Class Initialized
DEBUG - 2011-08-09 14:49:11 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-09 14:49:11 --> Helper loaded: url_helper
DEBUG - 2011-08-09 14:49:11 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-09 14:49:11 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-09 14:49:11 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-09 14:49:11 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-09 14:49:11 --> Final output sent to browser
DEBUG - 2011-08-09 14:49:11 --> Total execution time: 0.0848
DEBUG - 2011-08-09 14:49:13 --> Config Class Initialized
DEBUG - 2011-08-09 14:49:13 --> Hooks Class Initialized
DEBUG - 2011-08-09 14:49:13 --> Utf8 Class Initialized
DEBUG - 2011-08-09 14:49:13 --> UTF-8 Support Enabled
DEBUG - 2011-08-09 14:49:13 --> URI Class Initialized
DEBUG - 2011-08-09 14:49:13 --> Router Class Initialized
DEBUG - 2011-08-09 14:49:13 --> Output Class Initialized
DEBUG - 2011-08-09 14:49:13 --> Input Class Initialized
DEBUG - 2011-08-09 14:49:13 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-09 14:49:13 --> Language Class Initialized
DEBUG - 2011-08-09 14:49:13 --> Loader Class Initialized
DEBUG - 2011-08-09 14:49:13 --> Controller Class Initialized
DEBUG - 2011-08-09 14:49:13 --> Model Class Initialized
DEBUG - 2011-08-09 14:49:13 --> Model Class Initialized
DEBUG - 2011-08-09 14:49:13 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-09 14:49:13 --> Database Driver Class Initialized
DEBUG - 2011-08-09 14:49:13 --> Final output sent to browser
DEBUG - 2011-08-09 14:49:13 --> Total execution time: 0.5652
DEBUG - 2011-08-09 14:50:29 --> Config Class Initialized
DEBUG - 2011-08-09 14:50:29 --> Hooks Class Initialized
DEBUG - 2011-08-09 14:50:29 --> Utf8 Class Initialized
DEBUG - 2011-08-09 14:50:29 --> UTF-8 Support Enabled
DEBUG - 2011-08-09 14:50:29 --> URI Class Initialized
DEBUG - 2011-08-09 14:50:29 --> Router Class Initialized
DEBUG - 2011-08-09 14:50:29 --> Output Class Initialized
DEBUG - 2011-08-09 14:50:29 --> Input Class Initialized
DEBUG - 2011-08-09 14:50:29 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-09 14:50:29 --> Language Class Initialized
DEBUG - 2011-08-09 14:50:29 --> Loader Class Initialized
DEBUG - 2011-08-09 14:50:29 --> Controller Class Initialized
ERROR - 2011-08-09 14:50:29 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-09 14:50:29 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-09 14:50:29 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-09 14:50:29 --> Model Class Initialized
DEBUG - 2011-08-09 14:50:29 --> Model Class Initialized
DEBUG - 2011-08-09 14:50:29 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-09 14:50:29 --> Database Driver Class Initialized
DEBUG - 2011-08-09 14:50:29 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-09 14:50:29 --> Helper loaded: url_helper
DEBUG - 2011-08-09 14:50:29 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-09 14:50:29 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-09 14:50:29 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-09 14:50:29 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-09 14:50:29 --> Final output sent to browser
DEBUG - 2011-08-09 14:50:29 --> Total execution time: 0.0272
DEBUG - 2011-08-09 14:50:31 --> Config Class Initialized
DEBUG - 2011-08-09 14:50:31 --> Hooks Class Initialized
DEBUG - 2011-08-09 14:50:31 --> Utf8 Class Initialized
DEBUG - 2011-08-09 14:50:31 --> UTF-8 Support Enabled
DEBUG - 2011-08-09 14:50:31 --> URI Class Initialized
DEBUG - 2011-08-09 14:50:31 --> Router Class Initialized
DEBUG - 2011-08-09 14:50:31 --> Output Class Initialized
DEBUG - 2011-08-09 14:50:31 --> Input Class Initialized
DEBUG - 2011-08-09 14:50:31 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-09 14:50:31 --> Language Class Initialized
DEBUG - 2011-08-09 14:50:31 --> Loader Class Initialized
DEBUG - 2011-08-09 14:50:31 --> Controller Class Initialized
DEBUG - 2011-08-09 14:50:31 --> Model Class Initialized
DEBUG - 2011-08-09 14:50:31 --> Model Class Initialized
DEBUG - 2011-08-09 14:50:31 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-09 14:50:31 --> Database Driver Class Initialized
DEBUG - 2011-08-09 14:50:31 --> Final output sent to browser
DEBUG - 2011-08-09 14:50:31 --> Total execution time: 0.5377
DEBUG - 2011-08-09 14:51:40 --> Config Class Initialized
DEBUG - 2011-08-09 14:51:40 --> Hooks Class Initialized
DEBUG - 2011-08-09 14:51:40 --> Utf8 Class Initialized
DEBUG - 2011-08-09 14:51:40 --> UTF-8 Support Enabled
DEBUG - 2011-08-09 14:51:40 --> URI Class Initialized
DEBUG - 2011-08-09 14:51:40 --> Router Class Initialized
DEBUG - 2011-08-09 14:51:40 --> Output Class Initialized
DEBUG - 2011-08-09 14:51:40 --> Input Class Initialized
DEBUG - 2011-08-09 14:51:40 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-09 14:51:40 --> Language Class Initialized
DEBUG - 2011-08-09 14:51:40 --> Loader Class Initialized
DEBUG - 2011-08-09 14:51:40 --> Controller Class Initialized
ERROR - 2011-08-09 14:51:40 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-09 14:51:40 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-09 14:51:40 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-09 14:51:40 --> Model Class Initialized
DEBUG - 2011-08-09 14:51:40 --> Model Class Initialized
DEBUG - 2011-08-09 14:51:40 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-09 14:51:40 --> Database Driver Class Initialized
DEBUG - 2011-08-09 14:51:40 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-09 14:51:40 --> Helper loaded: url_helper
DEBUG - 2011-08-09 14:51:40 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-09 14:51:40 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-09 14:51:40 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-09 14:51:40 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-09 14:51:40 --> Final output sent to browser
DEBUG - 2011-08-09 14:51:40 --> Total execution time: 0.0269
DEBUG - 2011-08-09 14:51:42 --> Config Class Initialized
DEBUG - 2011-08-09 14:51:42 --> Hooks Class Initialized
DEBUG - 2011-08-09 14:51:42 --> Utf8 Class Initialized
DEBUG - 2011-08-09 14:51:42 --> UTF-8 Support Enabled
DEBUG - 2011-08-09 14:51:42 --> URI Class Initialized
DEBUG - 2011-08-09 14:51:42 --> Router Class Initialized
DEBUG - 2011-08-09 14:51:42 --> Output Class Initialized
DEBUG - 2011-08-09 14:51:42 --> Input Class Initialized
DEBUG - 2011-08-09 14:51:42 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-09 14:51:42 --> Language Class Initialized
DEBUG - 2011-08-09 14:51:42 --> Loader Class Initialized
DEBUG - 2011-08-09 14:51:42 --> Controller Class Initialized
DEBUG - 2011-08-09 14:51:42 --> Model Class Initialized
DEBUG - 2011-08-09 14:51:42 --> Model Class Initialized
DEBUG - 2011-08-09 14:51:42 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-09 14:51:42 --> Database Driver Class Initialized
DEBUG - 2011-08-09 14:51:43 --> Final output sent to browser
DEBUG - 2011-08-09 14:51:43 --> Total execution time: 0.5345
DEBUG - 2011-08-09 15:02:34 --> Config Class Initialized
DEBUG - 2011-08-09 15:02:34 --> Hooks Class Initialized
DEBUG - 2011-08-09 15:02:34 --> Utf8 Class Initialized
DEBUG - 2011-08-09 15:02:34 --> UTF-8 Support Enabled
DEBUG - 2011-08-09 15:02:34 --> URI Class Initialized
DEBUG - 2011-08-09 15:02:34 --> Router Class Initialized
DEBUG - 2011-08-09 15:02:34 --> Output Class Initialized
DEBUG - 2011-08-09 15:02:34 --> Input Class Initialized
DEBUG - 2011-08-09 15:02:34 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-09 15:02:34 --> Language Class Initialized
DEBUG - 2011-08-09 15:02:34 --> Loader Class Initialized
DEBUG - 2011-08-09 15:02:34 --> Controller Class Initialized
DEBUG - 2011-08-09 15:02:34 --> Model Class Initialized
DEBUG - 2011-08-09 15:02:34 --> Model Class Initialized
DEBUG - 2011-08-09 15:02:34 --> Model Class Initialized
DEBUG - 2011-08-09 15:02:34 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-09 15:02:34 --> Database Driver Class Initialized
DEBUG - 2011-08-09 15:02:34 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-09 15:02:34 --> Helper loaded: url_helper
DEBUG - 2011-08-09 15:02:34 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-09 15:02:34 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-09 15:02:34 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-09 15:02:34 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-09 15:02:34 --> Final output sent to browser
DEBUG - 2011-08-09 15:02:34 --> Total execution time: 0.2931
DEBUG - 2011-08-09 15:02:36 --> Config Class Initialized
DEBUG - 2011-08-09 15:02:36 --> Hooks Class Initialized
DEBUG - 2011-08-09 15:02:36 --> Utf8 Class Initialized
DEBUG - 2011-08-09 15:02:36 --> UTF-8 Support Enabled
DEBUG - 2011-08-09 15:02:36 --> URI Class Initialized
DEBUG - 2011-08-09 15:02:36 --> Router Class Initialized
ERROR - 2011-08-09 15:02:36 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-09 15:02:46 --> Config Class Initialized
DEBUG - 2011-08-09 15:02:46 --> Hooks Class Initialized
DEBUG - 2011-08-09 15:02:46 --> Utf8 Class Initialized
DEBUG - 2011-08-09 15:02:46 --> UTF-8 Support Enabled
DEBUG - 2011-08-09 15:02:46 --> URI Class Initialized
DEBUG - 2011-08-09 15:02:46 --> Router Class Initialized
DEBUG - 2011-08-09 15:02:46 --> Output Class Initialized
DEBUG - 2011-08-09 15:02:46 --> Input Class Initialized
DEBUG - 2011-08-09 15:02:46 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-09 15:02:46 --> Language Class Initialized
DEBUG - 2011-08-09 15:02:46 --> Loader Class Initialized
DEBUG - 2011-08-09 15:02:46 --> Controller Class Initialized
DEBUG - 2011-08-09 15:02:46 --> Model Class Initialized
DEBUG - 2011-08-09 15:02:46 --> Model Class Initialized
DEBUG - 2011-08-09 15:02:46 --> Model Class Initialized
DEBUG - 2011-08-09 15:02:46 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-09 15:02:47 --> Database Driver Class Initialized
DEBUG - 2011-08-09 15:02:47 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-09 15:02:47 --> Helper loaded: url_helper
DEBUG - 2011-08-09 15:02:47 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-09 15:02:47 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-09 15:02:47 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-09 15:02:47 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-09 15:02:47 --> Final output sent to browser
DEBUG - 2011-08-09 15:02:47 --> Total execution time: 0.2696
DEBUG - 2011-08-09 15:02:48 --> Config Class Initialized
DEBUG - 2011-08-09 15:02:48 --> Hooks Class Initialized
DEBUG - 2011-08-09 15:02:48 --> Utf8 Class Initialized
DEBUG - 2011-08-09 15:02:48 --> UTF-8 Support Enabled
DEBUG - 2011-08-09 15:02:48 --> URI Class Initialized
DEBUG - 2011-08-09 15:02:48 --> Router Class Initialized
ERROR - 2011-08-09 15:02:48 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-09 15:03:29 --> Config Class Initialized
DEBUG - 2011-08-09 15:03:29 --> Hooks Class Initialized
DEBUG - 2011-08-09 15:03:29 --> Utf8 Class Initialized
DEBUG - 2011-08-09 15:03:29 --> UTF-8 Support Enabled
DEBUG - 2011-08-09 15:03:29 --> URI Class Initialized
DEBUG - 2011-08-09 15:03:29 --> Router Class Initialized
DEBUG - 2011-08-09 15:03:29 --> Output Class Initialized
DEBUG - 2011-08-09 15:03:29 --> Input Class Initialized
DEBUG - 2011-08-09 15:03:29 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-09 15:03:29 --> Language Class Initialized
DEBUG - 2011-08-09 15:03:29 --> Loader Class Initialized
DEBUG - 2011-08-09 15:03:29 --> Controller Class Initialized
ERROR - 2011-08-09 15:03:29 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-09 15:03:29 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-09 15:03:29 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-09 15:03:29 --> Model Class Initialized
DEBUG - 2011-08-09 15:03:29 --> Model Class Initialized
DEBUG - 2011-08-09 15:03:29 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-09 15:03:29 --> Database Driver Class Initialized
DEBUG - 2011-08-09 15:03:29 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-09 15:03:29 --> Helper loaded: url_helper
DEBUG - 2011-08-09 15:03:29 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-09 15:03:29 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-09 15:03:29 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-09 15:03:29 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-09 15:03:29 --> Final output sent to browser
DEBUG - 2011-08-09 15:03:29 --> Total execution time: 0.0288
DEBUG - 2011-08-09 15:03:30 --> Config Class Initialized
DEBUG - 2011-08-09 15:03:30 --> Hooks Class Initialized
DEBUG - 2011-08-09 15:03:30 --> Utf8 Class Initialized
DEBUG - 2011-08-09 15:03:30 --> UTF-8 Support Enabled
DEBUG - 2011-08-09 15:03:30 --> URI Class Initialized
DEBUG - 2011-08-09 15:03:30 --> Router Class Initialized
DEBUG - 2011-08-09 15:03:30 --> Output Class Initialized
DEBUG - 2011-08-09 15:03:30 --> Input Class Initialized
DEBUG - 2011-08-09 15:03:30 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-09 15:03:30 --> Language Class Initialized
DEBUG - 2011-08-09 15:03:30 --> Loader Class Initialized
DEBUG - 2011-08-09 15:03:30 --> Controller Class Initialized
DEBUG - 2011-08-09 15:03:30 --> Model Class Initialized
DEBUG - 2011-08-09 15:03:30 --> Model Class Initialized
DEBUG - 2011-08-09 15:03:30 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-09 15:03:30 --> Database Driver Class Initialized
DEBUG - 2011-08-09 15:03:31 --> Final output sent to browser
DEBUG - 2011-08-09 15:03:31 --> Total execution time: 0.5076
DEBUG - 2011-08-09 15:03:32 --> Config Class Initialized
DEBUG - 2011-08-09 15:03:32 --> Hooks Class Initialized
DEBUG - 2011-08-09 15:03:32 --> Utf8 Class Initialized
DEBUG - 2011-08-09 15:03:32 --> UTF-8 Support Enabled
DEBUG - 2011-08-09 15:03:32 --> URI Class Initialized
DEBUG - 2011-08-09 15:03:32 --> Router Class Initialized
ERROR - 2011-08-09 15:03:32 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-09 15:07:02 --> Config Class Initialized
DEBUG - 2011-08-09 15:07:02 --> Hooks Class Initialized
DEBUG - 2011-08-09 15:07:02 --> Utf8 Class Initialized
DEBUG - 2011-08-09 15:07:02 --> UTF-8 Support Enabled
DEBUG - 2011-08-09 15:07:02 --> URI Class Initialized
DEBUG - 2011-08-09 15:07:02 --> Router Class Initialized
DEBUG - 2011-08-09 15:07:02 --> Output Class Initialized
DEBUG - 2011-08-09 15:07:02 --> Input Class Initialized
DEBUG - 2011-08-09 15:07:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-09 15:07:02 --> Language Class Initialized
DEBUG - 2011-08-09 15:07:02 --> Loader Class Initialized
DEBUG - 2011-08-09 15:07:02 --> Controller Class Initialized
DEBUG - 2011-08-09 15:07:02 --> Model Class Initialized
DEBUG - 2011-08-09 15:07:02 --> Model Class Initialized
DEBUG - 2011-08-09 15:07:02 --> Model Class Initialized
DEBUG - 2011-08-09 15:07:02 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-09 15:07:02 --> Database Driver Class Initialized
DEBUG - 2011-08-09 15:07:02 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-09 15:07:02 --> Helper loaded: url_helper
DEBUG - 2011-08-09 15:07:02 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-09 15:07:02 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-09 15:07:02 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-09 15:07:02 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-09 15:07:02 --> Final output sent to browser
DEBUG - 2011-08-09 15:07:02 --> Total execution time: 0.0476
DEBUG - 2011-08-09 15:07:23 --> Config Class Initialized
DEBUG - 2011-08-09 15:07:23 --> Hooks Class Initialized
DEBUG - 2011-08-09 15:07:23 --> Utf8 Class Initialized
DEBUG - 2011-08-09 15:07:23 --> UTF-8 Support Enabled
DEBUG - 2011-08-09 15:07:23 --> URI Class Initialized
DEBUG - 2011-08-09 15:07:23 --> Router Class Initialized
DEBUG - 2011-08-09 15:07:23 --> Output Class Initialized
DEBUG - 2011-08-09 15:07:23 --> Input Class Initialized
DEBUG - 2011-08-09 15:07:23 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-09 15:07:23 --> Language Class Initialized
DEBUG - 2011-08-09 15:07:23 --> Loader Class Initialized
DEBUG - 2011-08-09 15:07:23 --> Controller Class Initialized
DEBUG - 2011-08-09 15:07:23 --> Model Class Initialized
DEBUG - 2011-08-09 15:07:23 --> Model Class Initialized
DEBUG - 2011-08-09 15:07:23 --> Model Class Initialized
DEBUG - 2011-08-09 15:07:23 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-09 15:07:23 --> Database Driver Class Initialized
DEBUG - 2011-08-09 15:07:23 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-09 15:07:23 --> Helper loaded: url_helper
DEBUG - 2011-08-09 15:07:23 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-09 15:07:23 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-09 15:07:23 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-09 15:07:23 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-09 15:07:23 --> Final output sent to browser
DEBUG - 2011-08-09 15:07:23 --> Total execution time: 0.0836
DEBUG - 2011-08-09 15:07:44 --> Config Class Initialized
DEBUG - 2011-08-09 15:07:44 --> Hooks Class Initialized
DEBUG - 2011-08-09 15:07:44 --> Utf8 Class Initialized
DEBUG - 2011-08-09 15:07:44 --> UTF-8 Support Enabled
DEBUG - 2011-08-09 15:07:44 --> URI Class Initialized
DEBUG - 2011-08-09 15:07:44 --> Router Class Initialized
DEBUG - 2011-08-09 15:07:44 --> Output Class Initialized
DEBUG - 2011-08-09 15:07:44 --> Input Class Initialized
DEBUG - 2011-08-09 15:07:44 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-09 15:07:44 --> Language Class Initialized
DEBUG - 2011-08-09 15:07:44 --> Loader Class Initialized
DEBUG - 2011-08-09 15:07:44 --> Controller Class Initialized
DEBUG - 2011-08-09 15:07:44 --> Model Class Initialized
DEBUG - 2011-08-09 15:07:44 --> Model Class Initialized
DEBUG - 2011-08-09 15:07:44 --> Model Class Initialized
DEBUG - 2011-08-09 15:07:44 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-09 15:07:44 --> Database Driver Class Initialized
DEBUG - 2011-08-09 15:07:44 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-09 15:07:44 --> Helper loaded: url_helper
DEBUG - 2011-08-09 15:07:44 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-09 15:07:44 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-09 15:07:44 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-09 15:07:44 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-09 15:07:44 --> Final output sent to browser
DEBUG - 2011-08-09 15:07:44 --> Total execution time: 0.0460
DEBUG - 2011-08-09 15:07:56 --> Config Class Initialized
DEBUG - 2011-08-09 15:07:56 --> Hooks Class Initialized
DEBUG - 2011-08-09 15:07:56 --> Utf8 Class Initialized
DEBUG - 2011-08-09 15:07:56 --> UTF-8 Support Enabled
DEBUG - 2011-08-09 15:07:56 --> URI Class Initialized
DEBUG - 2011-08-09 15:07:56 --> Router Class Initialized
DEBUG - 2011-08-09 15:07:56 --> Output Class Initialized
DEBUG - 2011-08-09 15:07:56 --> Input Class Initialized
DEBUG - 2011-08-09 15:07:56 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-09 15:07:56 --> Language Class Initialized
DEBUG - 2011-08-09 15:07:56 --> Loader Class Initialized
DEBUG - 2011-08-09 15:07:56 --> Controller Class Initialized
DEBUG - 2011-08-09 15:07:56 --> Model Class Initialized
DEBUG - 2011-08-09 15:07:56 --> Model Class Initialized
DEBUG - 2011-08-09 15:07:56 --> Model Class Initialized
DEBUG - 2011-08-09 15:07:56 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-09 15:07:56 --> Database Driver Class Initialized
DEBUG - 2011-08-09 15:07:56 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-09 15:07:56 --> Helper loaded: url_helper
DEBUG - 2011-08-09 15:07:56 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-09 15:07:56 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-09 15:07:56 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-09 15:07:56 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-09 15:07:56 --> Final output sent to browser
DEBUG - 2011-08-09 15:07:56 --> Total execution time: 0.0465
DEBUG - 2011-08-09 15:08:18 --> Config Class Initialized
DEBUG - 2011-08-09 15:08:18 --> Hooks Class Initialized
DEBUG - 2011-08-09 15:08:18 --> Utf8 Class Initialized
DEBUG - 2011-08-09 15:08:18 --> UTF-8 Support Enabled
DEBUG - 2011-08-09 15:08:18 --> URI Class Initialized
DEBUG - 2011-08-09 15:08:18 --> Router Class Initialized
DEBUG - 2011-08-09 15:08:18 --> Output Class Initialized
DEBUG - 2011-08-09 15:08:18 --> Input Class Initialized
DEBUG - 2011-08-09 15:08:18 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-09 15:08:18 --> Language Class Initialized
DEBUG - 2011-08-09 15:08:18 --> Loader Class Initialized
DEBUG - 2011-08-09 15:08:18 --> Controller Class Initialized
DEBUG - 2011-08-09 15:08:18 --> Model Class Initialized
DEBUG - 2011-08-09 15:08:18 --> Model Class Initialized
DEBUG - 2011-08-09 15:08:18 --> Model Class Initialized
DEBUG - 2011-08-09 15:08:18 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-09 15:08:18 --> Database Driver Class Initialized
DEBUG - 2011-08-09 15:08:18 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-09 15:08:18 --> Helper loaded: url_helper
DEBUG - 2011-08-09 15:08:18 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-09 15:08:18 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-09 15:08:18 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-09 15:08:18 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-09 15:08:18 --> Final output sent to browser
DEBUG - 2011-08-09 15:08:18 --> Total execution time: 0.2285
DEBUG - 2011-08-09 15:08:25 --> Config Class Initialized
DEBUG - 2011-08-09 15:08:25 --> Hooks Class Initialized
DEBUG - 2011-08-09 15:08:25 --> Utf8 Class Initialized
DEBUG - 2011-08-09 15:08:25 --> UTF-8 Support Enabled
DEBUG - 2011-08-09 15:08:25 --> URI Class Initialized
DEBUG - 2011-08-09 15:08:25 --> Router Class Initialized
DEBUG - 2011-08-09 15:08:25 --> Output Class Initialized
DEBUG - 2011-08-09 15:08:25 --> Input Class Initialized
DEBUG - 2011-08-09 15:08:25 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-09 15:08:25 --> Language Class Initialized
DEBUG - 2011-08-09 15:08:25 --> Loader Class Initialized
DEBUG - 2011-08-09 15:08:25 --> Controller Class Initialized
DEBUG - 2011-08-09 15:08:25 --> Model Class Initialized
DEBUG - 2011-08-09 15:08:25 --> Model Class Initialized
DEBUG - 2011-08-09 15:08:25 --> Model Class Initialized
DEBUG - 2011-08-09 15:08:25 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-09 15:08:25 --> Database Driver Class Initialized
DEBUG - 2011-08-09 15:08:25 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-09 15:08:25 --> Helper loaded: url_helper
DEBUG - 2011-08-09 15:08:25 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-09 15:08:25 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-09 15:08:25 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-09 15:08:25 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-09 15:08:25 --> Final output sent to browser
DEBUG - 2011-08-09 15:08:25 --> Total execution time: 0.0425
DEBUG - 2011-08-09 15:08:40 --> Config Class Initialized
DEBUG - 2011-08-09 15:08:40 --> Hooks Class Initialized
DEBUG - 2011-08-09 15:08:40 --> Utf8 Class Initialized
DEBUG - 2011-08-09 15:08:40 --> UTF-8 Support Enabled
DEBUG - 2011-08-09 15:08:40 --> URI Class Initialized
DEBUG - 2011-08-09 15:08:40 --> Router Class Initialized
DEBUG - 2011-08-09 15:08:40 --> Output Class Initialized
DEBUG - 2011-08-09 15:08:40 --> Input Class Initialized
DEBUG - 2011-08-09 15:08:40 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-09 15:08:40 --> Language Class Initialized
DEBUG - 2011-08-09 15:08:40 --> Loader Class Initialized
DEBUG - 2011-08-09 15:08:40 --> Controller Class Initialized
DEBUG - 2011-08-09 15:08:40 --> Model Class Initialized
DEBUG - 2011-08-09 15:08:40 --> Model Class Initialized
DEBUG - 2011-08-09 15:08:40 --> Model Class Initialized
DEBUG - 2011-08-09 15:08:40 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-09 15:08:40 --> Database Driver Class Initialized
DEBUG - 2011-08-09 15:08:40 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-09 15:08:40 --> Helper loaded: url_helper
DEBUG - 2011-08-09 15:08:40 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-09 15:08:40 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-09 15:08:40 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-09 15:08:40 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-09 15:08:40 --> Final output sent to browser
DEBUG - 2011-08-09 15:08:40 --> Total execution time: 0.4877
DEBUG - 2011-08-09 15:08:42 --> Config Class Initialized
DEBUG - 2011-08-09 15:08:42 --> Hooks Class Initialized
DEBUG - 2011-08-09 15:08:42 --> Utf8 Class Initialized
DEBUG - 2011-08-09 15:08:42 --> UTF-8 Support Enabled
DEBUG - 2011-08-09 15:08:42 --> URI Class Initialized
DEBUG - 2011-08-09 15:08:42 --> Router Class Initialized
DEBUG - 2011-08-09 15:08:42 --> Output Class Initialized
DEBUG - 2011-08-09 15:08:42 --> Input Class Initialized
DEBUG - 2011-08-09 15:08:42 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-09 15:08:42 --> Language Class Initialized
DEBUG - 2011-08-09 15:08:42 --> Loader Class Initialized
DEBUG - 2011-08-09 15:08:42 --> Controller Class Initialized
DEBUG - 2011-08-09 15:08:42 --> Model Class Initialized
DEBUG - 2011-08-09 15:08:42 --> Model Class Initialized
DEBUG - 2011-08-09 15:08:42 --> Model Class Initialized
DEBUG - 2011-08-09 15:08:42 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-09 15:08:42 --> Database Driver Class Initialized
DEBUG - 2011-08-09 15:08:42 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-09 15:08:42 --> Helper loaded: url_helper
DEBUG - 2011-08-09 15:08:42 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-09 15:08:42 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-09 15:08:42 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-09 15:08:42 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-09 15:08:42 --> Final output sent to browser
DEBUG - 2011-08-09 15:08:42 --> Total execution time: 0.0809
DEBUG - 2011-08-09 15:08:43 --> Config Class Initialized
DEBUG - 2011-08-09 15:08:43 --> Hooks Class Initialized
DEBUG - 2011-08-09 15:08:43 --> Utf8 Class Initialized
DEBUG - 2011-08-09 15:08:43 --> UTF-8 Support Enabled
DEBUG - 2011-08-09 15:08:43 --> URI Class Initialized
DEBUG - 2011-08-09 15:08:43 --> Router Class Initialized
DEBUG - 2011-08-09 15:08:43 --> Output Class Initialized
DEBUG - 2011-08-09 15:08:43 --> Input Class Initialized
DEBUG - 2011-08-09 15:08:43 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-09 15:08:43 --> Language Class Initialized
DEBUG - 2011-08-09 15:08:43 --> Loader Class Initialized
DEBUG - 2011-08-09 15:08:43 --> Controller Class Initialized
DEBUG - 2011-08-09 15:08:43 --> Model Class Initialized
DEBUG - 2011-08-09 15:08:43 --> Model Class Initialized
DEBUG - 2011-08-09 15:08:43 --> Model Class Initialized
DEBUG - 2011-08-09 15:08:43 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-09 15:08:43 --> Database Driver Class Initialized
DEBUG - 2011-08-09 15:08:43 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-09 15:08:43 --> Helper loaded: url_helper
DEBUG - 2011-08-09 15:08:43 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-09 15:08:43 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-09 15:08:43 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-09 15:08:43 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-09 15:08:43 --> Final output sent to browser
DEBUG - 2011-08-09 15:08:43 --> Total execution time: 0.1635
DEBUG - 2011-08-09 16:02:54 --> Config Class Initialized
DEBUG - 2011-08-09 16:02:54 --> Hooks Class Initialized
DEBUG - 2011-08-09 16:02:54 --> Utf8 Class Initialized
DEBUG - 2011-08-09 16:02:54 --> UTF-8 Support Enabled
DEBUG - 2011-08-09 16:02:54 --> URI Class Initialized
DEBUG - 2011-08-09 16:02:54 --> Router Class Initialized
DEBUG - 2011-08-09 16:02:54 --> Output Class Initialized
DEBUG - 2011-08-09 16:02:54 --> Input Class Initialized
DEBUG - 2011-08-09 16:02:54 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-09 16:02:54 --> Language Class Initialized
DEBUG - 2011-08-09 16:02:54 --> Loader Class Initialized
DEBUG - 2011-08-09 16:02:54 --> Controller Class Initialized
ERROR - 2011-08-09 16:02:54 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-09 16:02:54 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-09 16:02:54 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-09 16:02:54 --> Model Class Initialized
DEBUG - 2011-08-09 16:02:54 --> Model Class Initialized
DEBUG - 2011-08-09 16:02:54 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-09 16:02:54 --> Database Driver Class Initialized
DEBUG - 2011-08-09 16:02:54 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-09 16:02:54 --> Helper loaded: url_helper
DEBUG - 2011-08-09 16:02:54 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-09 16:02:54 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-09 16:02:54 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-09 16:02:54 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-09 16:02:54 --> Final output sent to browser
DEBUG - 2011-08-09 16:02:54 --> Total execution time: 0.0686
DEBUG - 2011-08-09 16:02:55 --> Config Class Initialized
DEBUG - 2011-08-09 16:02:55 --> Hooks Class Initialized
DEBUG - 2011-08-09 16:02:55 --> Utf8 Class Initialized
DEBUG - 2011-08-09 16:02:55 --> UTF-8 Support Enabled
DEBUG - 2011-08-09 16:02:55 --> URI Class Initialized
DEBUG - 2011-08-09 16:02:55 --> Router Class Initialized
DEBUG - 2011-08-09 16:02:55 --> Output Class Initialized
DEBUG - 2011-08-09 16:02:55 --> Input Class Initialized
DEBUG - 2011-08-09 16:02:55 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-09 16:02:55 --> Language Class Initialized
DEBUG - 2011-08-09 16:02:55 --> Loader Class Initialized
DEBUG - 2011-08-09 16:02:55 --> Controller Class Initialized
DEBUG - 2011-08-09 16:02:55 --> Model Class Initialized
DEBUG - 2011-08-09 16:02:55 --> Model Class Initialized
DEBUG - 2011-08-09 16:02:55 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-09 16:02:55 --> Database Driver Class Initialized
DEBUG - 2011-08-09 16:02:55 --> Final output sent to browser
DEBUG - 2011-08-09 16:02:55 --> Total execution time: 0.6414
DEBUG - 2011-08-09 16:02:56 --> Config Class Initialized
DEBUG - 2011-08-09 16:02:56 --> Hooks Class Initialized
DEBUG - 2011-08-09 16:02:56 --> Utf8 Class Initialized
DEBUG - 2011-08-09 16:02:56 --> UTF-8 Support Enabled
DEBUG - 2011-08-09 16:02:56 --> URI Class Initialized
DEBUG - 2011-08-09 16:02:56 --> Router Class Initialized
DEBUG - 2011-08-09 16:02:56 --> Output Class Initialized
DEBUG - 2011-08-09 16:02:56 --> Input Class Initialized
DEBUG - 2011-08-09 16:02:56 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-09 16:02:56 --> Language Class Initialized
DEBUG - 2011-08-09 16:02:56 --> Loader Class Initialized
DEBUG - 2011-08-09 16:02:56 --> Controller Class Initialized
ERROR - 2011-08-09 16:02:56 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-09 16:02:56 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-09 16:02:56 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-09 16:02:56 --> Model Class Initialized
DEBUG - 2011-08-09 16:02:56 --> Model Class Initialized
DEBUG - 2011-08-09 16:02:56 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-09 16:02:56 --> Database Driver Class Initialized
DEBUG - 2011-08-09 16:02:56 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-09 16:02:56 --> Helper loaded: url_helper
DEBUG - 2011-08-09 16:02:56 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-09 16:02:56 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-09 16:02:56 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-09 16:02:56 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-09 16:02:56 --> Final output sent to browser
DEBUG - 2011-08-09 16:02:56 --> Total execution time: 0.0553
DEBUG - 2011-08-09 16:02:57 --> Config Class Initialized
DEBUG - 2011-08-09 16:02:57 --> Hooks Class Initialized
DEBUG - 2011-08-09 16:02:57 --> Utf8 Class Initialized
DEBUG - 2011-08-09 16:02:57 --> UTF-8 Support Enabled
DEBUG - 2011-08-09 16:02:57 --> URI Class Initialized
DEBUG - 2011-08-09 16:02:57 --> Router Class Initialized
DEBUG - 2011-08-09 16:02:57 --> Output Class Initialized
DEBUG - 2011-08-09 16:02:57 --> Input Class Initialized
DEBUG - 2011-08-09 16:02:57 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-09 16:02:57 --> Language Class Initialized
DEBUG - 2011-08-09 16:02:57 --> Loader Class Initialized
DEBUG - 2011-08-09 16:02:57 --> Controller Class Initialized
DEBUG - 2011-08-09 16:02:57 --> Model Class Initialized
DEBUG - 2011-08-09 16:02:57 --> Model Class Initialized
DEBUG - 2011-08-09 16:02:57 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-09 16:02:57 --> Database Driver Class Initialized
DEBUG - 2011-08-09 16:02:57 --> Final output sent to browser
DEBUG - 2011-08-09 16:02:57 --> Total execution time: 0.4836
DEBUG - 2011-08-09 16:02:57 --> Config Class Initialized
DEBUG - 2011-08-09 16:02:57 --> Hooks Class Initialized
DEBUG - 2011-08-09 16:02:57 --> Utf8 Class Initialized
DEBUG - 2011-08-09 16:02:57 --> UTF-8 Support Enabled
DEBUG - 2011-08-09 16:02:57 --> URI Class Initialized
DEBUG - 2011-08-09 16:02:57 --> Router Class Initialized
ERROR - 2011-08-09 16:02:57 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-09 16:02:58 --> Config Class Initialized
DEBUG - 2011-08-09 16:02:58 --> Hooks Class Initialized
DEBUG - 2011-08-09 16:02:58 --> Utf8 Class Initialized
DEBUG - 2011-08-09 16:02:58 --> UTF-8 Support Enabled
DEBUG - 2011-08-09 16:02:58 --> URI Class Initialized
DEBUG - 2011-08-09 16:02:58 --> Router Class Initialized
ERROR - 2011-08-09 16:02:58 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-09 16:02:58 --> Config Class Initialized
DEBUG - 2011-08-09 16:02:58 --> Hooks Class Initialized
DEBUG - 2011-08-09 16:02:58 --> Utf8 Class Initialized
DEBUG - 2011-08-09 16:02:58 --> UTF-8 Support Enabled
DEBUG - 2011-08-09 16:02:58 --> URI Class Initialized
DEBUG - 2011-08-09 16:02:58 --> Router Class Initialized
ERROR - 2011-08-09 16:02:58 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-09 16:02:59 --> Config Class Initialized
DEBUG - 2011-08-09 16:02:59 --> Hooks Class Initialized
DEBUG - 2011-08-09 16:02:59 --> Utf8 Class Initialized
DEBUG - 2011-08-09 16:02:59 --> UTF-8 Support Enabled
DEBUG - 2011-08-09 16:02:59 --> URI Class Initialized
DEBUG - 2011-08-09 16:02:59 --> Router Class Initialized
ERROR - 2011-08-09 16:02:59 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-09 16:02:59 --> Config Class Initialized
DEBUG - 2011-08-09 16:02:59 --> Hooks Class Initialized
DEBUG - 2011-08-09 16:02:59 --> Utf8 Class Initialized
DEBUG - 2011-08-09 16:02:59 --> UTF-8 Support Enabled
DEBUG - 2011-08-09 16:02:59 --> URI Class Initialized
DEBUG - 2011-08-09 16:02:59 --> Router Class Initialized
ERROR - 2011-08-09 16:02:59 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-09 16:03:07 --> Config Class Initialized
DEBUG - 2011-08-09 16:03:07 --> Hooks Class Initialized
DEBUG - 2011-08-09 16:03:07 --> Utf8 Class Initialized
DEBUG - 2011-08-09 16:03:07 --> UTF-8 Support Enabled
DEBUG - 2011-08-09 16:03:07 --> URI Class Initialized
DEBUG - 2011-08-09 16:03:07 --> Router Class Initialized
DEBUG - 2011-08-09 16:03:07 --> Output Class Initialized
DEBUG - 2011-08-09 16:03:07 --> Input Class Initialized
DEBUG - 2011-08-09 16:03:07 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-09 16:03:07 --> Language Class Initialized
DEBUG - 2011-08-09 16:03:07 --> Loader Class Initialized
DEBUG - 2011-08-09 16:03:07 --> Controller Class Initialized
ERROR - 2011-08-09 16:03:07 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-09 16:03:07 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-09 16:03:07 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-09 16:03:07 --> Model Class Initialized
DEBUG - 2011-08-09 16:03:07 --> Model Class Initialized
DEBUG - 2011-08-09 16:03:07 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-09 16:03:07 --> Database Driver Class Initialized
DEBUG - 2011-08-09 16:03:07 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-09 16:03:07 --> Helper loaded: url_helper
DEBUG - 2011-08-09 16:03:07 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-09 16:03:07 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-09 16:03:07 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-09 16:03:07 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-09 16:03:07 --> Final output sent to browser
DEBUG - 2011-08-09 16:03:07 --> Total execution time: 0.0279
DEBUG - 2011-08-09 16:03:07 --> Config Class Initialized
DEBUG - 2011-08-09 16:03:07 --> Hooks Class Initialized
DEBUG - 2011-08-09 16:03:07 --> Utf8 Class Initialized
DEBUG - 2011-08-09 16:03:07 --> UTF-8 Support Enabled
DEBUG - 2011-08-09 16:03:07 --> URI Class Initialized
DEBUG - 2011-08-09 16:03:07 --> Router Class Initialized
DEBUG - 2011-08-09 16:03:07 --> Output Class Initialized
DEBUG - 2011-08-09 16:03:07 --> Input Class Initialized
DEBUG - 2011-08-09 16:03:07 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-09 16:03:07 --> Language Class Initialized
DEBUG - 2011-08-09 16:03:07 --> Loader Class Initialized
DEBUG - 2011-08-09 16:03:07 --> Controller Class Initialized
DEBUG - 2011-08-09 16:03:07 --> Model Class Initialized
DEBUG - 2011-08-09 16:03:07 --> Model Class Initialized
DEBUG - 2011-08-09 16:03:07 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-09 16:03:07 --> Database Driver Class Initialized
DEBUG - 2011-08-09 16:03:08 --> Final output sent to browser
DEBUG - 2011-08-09 16:03:08 --> Total execution time: 0.5530
DEBUG - 2011-08-09 16:03:08 --> Config Class Initialized
DEBUG - 2011-08-09 16:03:08 --> Hooks Class Initialized
DEBUG - 2011-08-09 16:03:08 --> Utf8 Class Initialized
DEBUG - 2011-08-09 16:03:08 --> UTF-8 Support Enabled
DEBUG - 2011-08-09 16:03:08 --> URI Class Initialized
DEBUG - 2011-08-09 16:03:08 --> Router Class Initialized
DEBUG - 2011-08-09 16:03:08 --> Output Class Initialized
DEBUG - 2011-08-09 16:03:08 --> Input Class Initialized
DEBUG - 2011-08-09 16:03:08 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-09 16:03:08 --> Language Class Initialized
DEBUG - 2011-08-09 16:03:08 --> Loader Class Initialized
DEBUG - 2011-08-09 16:03:08 --> Controller Class Initialized
ERROR - 2011-08-09 16:03:08 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-09 16:03:08 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-09 16:03:08 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-09 16:03:08 --> Model Class Initialized
DEBUG - 2011-08-09 16:03:08 --> Model Class Initialized
DEBUG - 2011-08-09 16:03:08 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-09 16:03:08 --> Database Driver Class Initialized
DEBUG - 2011-08-09 16:03:08 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-09 16:03:08 --> Helper loaded: url_helper
DEBUG - 2011-08-09 16:03:08 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-09 16:03:08 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-09 16:03:08 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-09 16:03:08 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-09 16:03:08 --> Final output sent to browser
DEBUG - 2011-08-09 16:03:08 --> Total execution time: 0.0286
DEBUG - 2011-08-09 16:03:24 --> Config Class Initialized
DEBUG - 2011-08-09 16:03:24 --> Hooks Class Initialized
DEBUG - 2011-08-09 16:03:24 --> Utf8 Class Initialized
DEBUG - 2011-08-09 16:03:24 --> UTF-8 Support Enabled
DEBUG - 2011-08-09 16:03:24 --> URI Class Initialized
DEBUG - 2011-08-09 16:03:24 --> Router Class Initialized
DEBUG - 2011-08-09 16:03:24 --> Output Class Initialized
DEBUG - 2011-08-09 16:03:24 --> Input Class Initialized
DEBUG - 2011-08-09 16:03:24 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-09 16:03:24 --> Language Class Initialized
DEBUG - 2011-08-09 16:03:24 --> Loader Class Initialized
DEBUG - 2011-08-09 16:03:24 --> Controller Class Initialized
ERROR - 2011-08-09 16:03:24 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-09 16:03:24 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-09 16:03:24 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-09 16:03:24 --> Model Class Initialized
DEBUG - 2011-08-09 16:03:24 --> Model Class Initialized
DEBUG - 2011-08-09 16:03:24 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-09 16:03:24 --> Database Driver Class Initialized
DEBUG - 2011-08-09 16:03:24 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-09 16:03:24 --> Helper loaded: url_helper
DEBUG - 2011-08-09 16:03:24 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-09 16:03:24 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-09 16:03:24 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-09 16:03:24 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-09 16:03:24 --> Final output sent to browser
DEBUG - 2011-08-09 16:03:24 --> Total execution time: 0.0268
DEBUG - 2011-08-09 16:03:25 --> Config Class Initialized
DEBUG - 2011-08-09 16:03:25 --> Hooks Class Initialized
DEBUG - 2011-08-09 16:03:25 --> Utf8 Class Initialized
DEBUG - 2011-08-09 16:03:25 --> UTF-8 Support Enabled
DEBUG - 2011-08-09 16:03:25 --> URI Class Initialized
DEBUG - 2011-08-09 16:03:25 --> Router Class Initialized
DEBUG - 2011-08-09 16:03:25 --> Output Class Initialized
DEBUG - 2011-08-09 16:03:25 --> Input Class Initialized
DEBUG - 2011-08-09 16:03:25 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-09 16:03:25 --> Language Class Initialized
DEBUG - 2011-08-09 16:03:25 --> Loader Class Initialized
DEBUG - 2011-08-09 16:03:25 --> Controller Class Initialized
DEBUG - 2011-08-09 16:03:25 --> Model Class Initialized
DEBUG - 2011-08-09 16:03:25 --> Model Class Initialized
DEBUG - 2011-08-09 16:03:25 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-09 16:03:25 --> Database Driver Class Initialized
DEBUG - 2011-08-09 16:03:25 --> Final output sent to browser
DEBUG - 2011-08-09 16:03:25 --> Total execution time: 0.5105
DEBUG - 2011-08-09 16:03:26 --> Config Class Initialized
DEBUG - 2011-08-09 16:03:26 --> Hooks Class Initialized
DEBUG - 2011-08-09 16:03:26 --> Utf8 Class Initialized
DEBUG - 2011-08-09 16:03:26 --> UTF-8 Support Enabled
DEBUG - 2011-08-09 16:03:26 --> URI Class Initialized
DEBUG - 2011-08-09 16:03:26 --> Router Class Initialized
DEBUG - 2011-08-09 16:03:26 --> Output Class Initialized
DEBUG - 2011-08-09 16:03:26 --> Input Class Initialized
DEBUG - 2011-08-09 16:03:26 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-09 16:03:26 --> Language Class Initialized
DEBUG - 2011-08-09 16:03:26 --> Loader Class Initialized
DEBUG - 2011-08-09 16:03:26 --> Controller Class Initialized
ERROR - 2011-08-09 16:03:26 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-09 16:03:26 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-09 16:03:26 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-09 16:03:26 --> Model Class Initialized
DEBUG - 2011-08-09 16:03:26 --> Model Class Initialized
DEBUG - 2011-08-09 16:03:26 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-09 16:03:26 --> Database Driver Class Initialized
DEBUG - 2011-08-09 16:03:26 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-09 16:03:26 --> Helper loaded: url_helper
DEBUG - 2011-08-09 16:03:26 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-09 16:03:26 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-09 16:03:26 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-09 16:03:26 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-09 16:03:26 --> Final output sent to browser
DEBUG - 2011-08-09 16:03:26 --> Total execution time: 0.0265
DEBUG - 2011-08-09 16:03:36 --> Config Class Initialized
DEBUG - 2011-08-09 16:03:36 --> Hooks Class Initialized
DEBUG - 2011-08-09 16:03:36 --> Utf8 Class Initialized
DEBUG - 2011-08-09 16:03:36 --> UTF-8 Support Enabled
DEBUG - 2011-08-09 16:03:36 --> URI Class Initialized
DEBUG - 2011-08-09 16:03:36 --> Router Class Initialized
DEBUG - 2011-08-09 16:03:36 --> Output Class Initialized
DEBUG - 2011-08-09 16:03:36 --> Input Class Initialized
DEBUG - 2011-08-09 16:03:36 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-09 16:03:36 --> Language Class Initialized
DEBUG - 2011-08-09 16:03:36 --> Loader Class Initialized
DEBUG - 2011-08-09 16:03:36 --> Controller Class Initialized
ERROR - 2011-08-09 16:03:36 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-09 16:03:36 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-09 16:03:36 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-09 16:03:36 --> Model Class Initialized
DEBUG - 2011-08-09 16:03:36 --> Model Class Initialized
DEBUG - 2011-08-09 16:03:36 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-09 16:03:36 --> Database Driver Class Initialized
DEBUG - 2011-08-09 16:03:36 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-09 16:03:36 --> Helper loaded: url_helper
DEBUG - 2011-08-09 16:03:36 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-09 16:03:36 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-09 16:03:36 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-09 16:03:36 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-09 16:03:36 --> Final output sent to browser
DEBUG - 2011-08-09 16:03:36 --> Total execution time: 0.0288
DEBUG - 2011-08-09 16:03:37 --> Config Class Initialized
DEBUG - 2011-08-09 16:03:37 --> Hooks Class Initialized
DEBUG - 2011-08-09 16:03:37 --> Utf8 Class Initialized
DEBUG - 2011-08-09 16:03:37 --> UTF-8 Support Enabled
DEBUG - 2011-08-09 16:03:37 --> URI Class Initialized
DEBUG - 2011-08-09 16:03:37 --> Router Class Initialized
DEBUG - 2011-08-09 16:03:37 --> Output Class Initialized
DEBUG - 2011-08-09 16:03:37 --> Input Class Initialized
DEBUG - 2011-08-09 16:03:37 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-09 16:03:37 --> Language Class Initialized
DEBUG - 2011-08-09 16:03:37 --> Loader Class Initialized
DEBUG - 2011-08-09 16:03:37 --> Controller Class Initialized
DEBUG - 2011-08-09 16:03:37 --> Model Class Initialized
DEBUG - 2011-08-09 16:03:37 --> Model Class Initialized
DEBUG - 2011-08-09 16:03:37 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-09 16:03:37 --> Database Driver Class Initialized
DEBUG - 2011-08-09 16:03:37 --> Final output sent to browser
DEBUG - 2011-08-09 16:03:37 --> Total execution time: 0.5009
DEBUG - 2011-08-09 17:37:22 --> Config Class Initialized
DEBUG - 2011-08-09 17:37:22 --> Hooks Class Initialized
DEBUG - 2011-08-09 17:37:22 --> Utf8 Class Initialized
DEBUG - 2011-08-09 17:37:22 --> UTF-8 Support Enabled
DEBUG - 2011-08-09 17:37:22 --> URI Class Initialized
DEBUG - 2011-08-09 17:37:22 --> Router Class Initialized
DEBUG - 2011-08-09 17:37:23 --> Output Class Initialized
DEBUG - 2011-08-09 17:37:23 --> Input Class Initialized
DEBUG - 2011-08-09 17:37:23 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-09 17:37:23 --> Language Class Initialized
DEBUG - 2011-08-09 17:37:23 --> Loader Class Initialized
DEBUG - 2011-08-09 17:37:23 --> Controller Class Initialized
DEBUG - 2011-08-09 17:37:23 --> Model Class Initialized
DEBUG - 2011-08-09 17:37:23 --> Model Class Initialized
DEBUG - 2011-08-09 17:37:23 --> Model Class Initialized
DEBUG - 2011-08-09 17:37:23 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-09 17:37:23 --> Database Driver Class Initialized
DEBUG - 2011-08-09 17:37:24 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-09 17:37:24 --> Helper loaded: url_helper
DEBUG - 2011-08-09 17:37:24 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-09 17:37:24 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-09 17:37:24 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-09 17:37:24 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-09 17:37:24 --> Final output sent to browser
DEBUG - 2011-08-09 17:37:24 --> Total execution time: 1.7688
DEBUG - 2011-08-09 17:37:50 --> Config Class Initialized
DEBUG - 2011-08-09 17:37:50 --> Hooks Class Initialized
DEBUG - 2011-08-09 17:37:50 --> Utf8 Class Initialized
DEBUG - 2011-08-09 17:37:50 --> UTF-8 Support Enabled
DEBUG - 2011-08-09 17:37:50 --> URI Class Initialized
DEBUG - 2011-08-09 17:37:50 --> Router Class Initialized
DEBUG - 2011-08-09 17:37:50 --> Output Class Initialized
DEBUG - 2011-08-09 17:37:50 --> Input Class Initialized
DEBUG - 2011-08-09 17:37:50 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-09 17:37:50 --> Language Class Initialized
DEBUG - 2011-08-09 17:37:50 --> Loader Class Initialized
DEBUG - 2011-08-09 17:37:50 --> Controller Class Initialized
DEBUG - 2011-08-09 17:37:50 --> Model Class Initialized
DEBUG - 2011-08-09 17:37:50 --> Model Class Initialized
DEBUG - 2011-08-09 17:37:50 --> Model Class Initialized
DEBUG - 2011-08-09 17:37:50 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-09 17:37:50 --> Database Driver Class Initialized
DEBUG - 2011-08-09 17:37:51 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-09 17:37:51 --> Helper loaded: url_helper
DEBUG - 2011-08-09 17:37:51 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-09 17:37:51 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-09 17:37:51 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-09 17:37:51 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-09 17:37:51 --> Final output sent to browser
DEBUG - 2011-08-09 17:37:51 --> Total execution time: 1.0162
DEBUG - 2011-08-09 17:37:53 --> Config Class Initialized
DEBUG - 2011-08-09 17:37:53 --> Hooks Class Initialized
DEBUG - 2011-08-09 17:37:53 --> Utf8 Class Initialized
DEBUG - 2011-08-09 17:37:53 --> UTF-8 Support Enabled
DEBUG - 2011-08-09 17:37:53 --> URI Class Initialized
DEBUG - 2011-08-09 17:37:53 --> Router Class Initialized
DEBUG - 2011-08-09 17:37:53 --> Output Class Initialized
DEBUG - 2011-08-09 17:37:53 --> Input Class Initialized
DEBUG - 2011-08-09 17:37:53 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-09 17:37:53 --> Language Class Initialized
DEBUG - 2011-08-09 17:37:53 --> Loader Class Initialized
DEBUG - 2011-08-09 17:37:53 --> Controller Class Initialized
DEBUG - 2011-08-09 17:37:53 --> Model Class Initialized
DEBUG - 2011-08-09 17:37:53 --> Model Class Initialized
DEBUG - 2011-08-09 17:37:53 --> Model Class Initialized
DEBUG - 2011-08-09 17:37:53 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-09 17:37:53 --> Database Driver Class Initialized
DEBUG - 2011-08-09 17:37:53 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-09 17:37:53 --> Helper loaded: url_helper
DEBUG - 2011-08-09 17:37:53 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-09 17:37:53 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-09 17:37:53 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-09 17:37:53 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-09 17:37:53 --> Final output sent to browser
DEBUG - 2011-08-09 17:37:53 --> Total execution time: 0.0416
DEBUG - 2011-08-09 17:37:54 --> Config Class Initialized
DEBUG - 2011-08-09 17:37:54 --> Hooks Class Initialized
DEBUG - 2011-08-09 17:37:54 --> Utf8 Class Initialized
DEBUG - 2011-08-09 17:37:54 --> UTF-8 Support Enabled
DEBUG - 2011-08-09 17:37:54 --> URI Class Initialized
DEBUG - 2011-08-09 17:37:54 --> Router Class Initialized
DEBUG - 2011-08-09 17:37:54 --> Output Class Initialized
DEBUG - 2011-08-09 17:37:54 --> Input Class Initialized
DEBUG - 2011-08-09 17:37:54 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-09 17:37:54 --> Language Class Initialized
DEBUG - 2011-08-09 17:37:54 --> Loader Class Initialized
DEBUG - 2011-08-09 17:37:54 --> Controller Class Initialized
DEBUG - 2011-08-09 17:37:54 --> Model Class Initialized
DEBUG - 2011-08-09 17:37:54 --> Model Class Initialized
DEBUG - 2011-08-09 17:37:54 --> Model Class Initialized
DEBUG - 2011-08-09 17:37:54 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-09 17:37:54 --> Database Driver Class Initialized
DEBUG - 2011-08-09 17:37:54 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-09 17:37:54 --> Helper loaded: url_helper
DEBUG - 2011-08-09 17:37:54 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-09 17:37:54 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-09 17:37:54 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-09 17:37:54 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-09 17:37:54 --> Final output sent to browser
DEBUG - 2011-08-09 17:37:54 --> Total execution time: 0.0476
DEBUG - 2011-08-09 17:38:11 --> Config Class Initialized
DEBUG - 2011-08-09 17:38:11 --> Hooks Class Initialized
DEBUG - 2011-08-09 17:38:11 --> Utf8 Class Initialized
DEBUG - 2011-08-09 17:38:11 --> UTF-8 Support Enabled
DEBUG - 2011-08-09 17:38:11 --> URI Class Initialized
DEBUG - 2011-08-09 17:38:11 --> Router Class Initialized
DEBUG - 2011-08-09 17:38:11 --> Output Class Initialized
DEBUG - 2011-08-09 17:38:11 --> Input Class Initialized
DEBUG - 2011-08-09 17:38:11 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-09 17:38:11 --> Language Class Initialized
DEBUG - 2011-08-09 17:38:11 --> Loader Class Initialized
DEBUG - 2011-08-09 17:38:11 --> Controller Class Initialized
DEBUG - 2011-08-09 17:38:11 --> Model Class Initialized
DEBUG - 2011-08-09 17:38:11 --> Model Class Initialized
DEBUG - 2011-08-09 17:38:11 --> Model Class Initialized
DEBUG - 2011-08-09 17:38:11 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-09 17:38:11 --> Database Driver Class Initialized
DEBUG - 2011-08-09 17:38:11 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-09 17:38:11 --> Helper loaded: url_helper
DEBUG - 2011-08-09 17:38:11 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-09 17:38:11 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-09 17:38:11 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-09 17:38:11 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-09 17:38:11 --> Final output sent to browser
DEBUG - 2011-08-09 17:38:11 --> Total execution time: 0.2633
DEBUG - 2011-08-09 17:38:23 --> Config Class Initialized
DEBUG - 2011-08-09 17:38:23 --> Hooks Class Initialized
DEBUG - 2011-08-09 17:38:23 --> Utf8 Class Initialized
DEBUG - 2011-08-09 17:38:23 --> UTF-8 Support Enabled
DEBUG - 2011-08-09 17:38:23 --> URI Class Initialized
DEBUG - 2011-08-09 17:38:23 --> Router Class Initialized
DEBUG - 2011-08-09 17:38:23 --> Output Class Initialized
DEBUG - 2011-08-09 17:38:23 --> Input Class Initialized
DEBUG - 2011-08-09 17:38:23 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-09 17:38:23 --> Language Class Initialized
DEBUG - 2011-08-09 17:38:23 --> Loader Class Initialized
DEBUG - 2011-08-09 17:38:23 --> Controller Class Initialized
DEBUG - 2011-08-09 17:38:23 --> Model Class Initialized
DEBUG - 2011-08-09 17:38:23 --> Model Class Initialized
DEBUG - 2011-08-09 17:38:23 --> Model Class Initialized
DEBUG - 2011-08-09 17:38:23 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-09 17:38:23 --> Database Driver Class Initialized
DEBUG - 2011-08-09 17:38:23 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-09 17:38:23 --> Helper loaded: url_helper
DEBUG - 2011-08-09 17:38:23 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-09 17:38:23 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-09 17:38:23 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-09 17:38:23 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-09 17:38:23 --> Final output sent to browser
DEBUG - 2011-08-09 17:38:23 --> Total execution time: 0.2850
DEBUG - 2011-08-09 17:38:35 --> Config Class Initialized
DEBUG - 2011-08-09 17:38:35 --> Hooks Class Initialized
DEBUG - 2011-08-09 17:38:35 --> Utf8 Class Initialized
DEBUG - 2011-08-09 17:38:35 --> UTF-8 Support Enabled
DEBUG - 2011-08-09 17:38:35 --> URI Class Initialized
DEBUG - 2011-08-09 17:38:35 --> Router Class Initialized
DEBUG - 2011-08-09 17:38:35 --> Output Class Initialized
DEBUG - 2011-08-09 17:38:35 --> Input Class Initialized
DEBUG - 2011-08-09 17:38:35 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-09 17:38:35 --> Language Class Initialized
DEBUG - 2011-08-09 17:38:35 --> Loader Class Initialized
DEBUG - 2011-08-09 17:38:35 --> Controller Class Initialized
DEBUG - 2011-08-09 17:38:35 --> Model Class Initialized
DEBUG - 2011-08-09 17:38:35 --> Model Class Initialized
DEBUG - 2011-08-09 17:38:35 --> Model Class Initialized
DEBUG - 2011-08-09 17:38:35 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-09 17:38:35 --> Database Driver Class Initialized
DEBUG - 2011-08-09 17:38:36 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-09 17:38:36 --> Helper loaded: url_helper
DEBUG - 2011-08-09 17:38:36 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-09 17:38:36 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-09 17:38:36 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-09 17:38:36 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-09 17:38:36 --> Final output sent to browser
DEBUG - 2011-08-09 17:38:36 --> Total execution time: 0.5151
DEBUG - 2011-08-09 17:38:44 --> Config Class Initialized
DEBUG - 2011-08-09 17:38:44 --> Hooks Class Initialized
DEBUG - 2011-08-09 17:38:44 --> Utf8 Class Initialized
DEBUG - 2011-08-09 17:38:44 --> UTF-8 Support Enabled
DEBUG - 2011-08-09 17:38:44 --> URI Class Initialized
DEBUG - 2011-08-09 17:38:44 --> Router Class Initialized
DEBUG - 2011-08-09 17:38:44 --> Output Class Initialized
DEBUG - 2011-08-09 17:38:44 --> Input Class Initialized
DEBUG - 2011-08-09 17:38:44 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-09 17:38:44 --> Language Class Initialized
DEBUG - 2011-08-09 17:38:44 --> Loader Class Initialized
DEBUG - 2011-08-09 17:38:44 --> Controller Class Initialized
DEBUG - 2011-08-09 17:38:44 --> Model Class Initialized
DEBUG - 2011-08-09 17:38:44 --> Model Class Initialized
DEBUG - 2011-08-09 17:38:44 --> Model Class Initialized
DEBUG - 2011-08-09 17:38:44 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-09 17:38:44 --> Database Driver Class Initialized
DEBUG - 2011-08-09 17:38:45 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-09 17:38:45 --> Helper loaded: url_helper
DEBUG - 2011-08-09 17:38:45 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-09 17:38:45 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-09 17:38:45 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-09 17:38:45 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-09 17:38:45 --> Final output sent to browser
DEBUG - 2011-08-09 17:38:45 --> Total execution time: 0.0462
DEBUG - 2011-08-09 17:39:06 --> Config Class Initialized
DEBUG - 2011-08-09 17:39:06 --> Hooks Class Initialized
DEBUG - 2011-08-09 17:39:06 --> Utf8 Class Initialized
DEBUG - 2011-08-09 17:39:06 --> UTF-8 Support Enabled
DEBUG - 2011-08-09 17:39:06 --> URI Class Initialized
DEBUG - 2011-08-09 17:39:06 --> Router Class Initialized
DEBUG - 2011-08-09 17:39:06 --> Output Class Initialized
DEBUG - 2011-08-09 17:39:06 --> Input Class Initialized
DEBUG - 2011-08-09 17:39:06 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-09 17:39:06 --> Language Class Initialized
DEBUG - 2011-08-09 17:39:06 --> Loader Class Initialized
DEBUG - 2011-08-09 17:39:06 --> Controller Class Initialized
DEBUG - 2011-08-09 17:39:06 --> Model Class Initialized
DEBUG - 2011-08-09 17:39:06 --> Model Class Initialized
DEBUG - 2011-08-09 17:39:06 --> Model Class Initialized
DEBUG - 2011-08-09 17:39:06 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-09 17:39:06 --> Database Driver Class Initialized
DEBUG - 2011-08-09 17:39:06 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-09 17:39:06 --> Helper loaded: url_helper
DEBUG - 2011-08-09 17:39:06 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-09 17:39:06 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-09 17:39:06 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-09 17:39:06 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-09 17:39:06 --> Final output sent to browser
DEBUG - 2011-08-09 17:39:06 --> Total execution time: 0.2753
DEBUG - 2011-08-09 17:39:22 --> Config Class Initialized
DEBUG - 2011-08-09 17:39:22 --> Hooks Class Initialized
DEBUG - 2011-08-09 17:39:22 --> Utf8 Class Initialized
DEBUG - 2011-08-09 17:39:22 --> UTF-8 Support Enabled
DEBUG - 2011-08-09 17:39:22 --> URI Class Initialized
DEBUG - 2011-08-09 17:39:22 --> Router Class Initialized
DEBUG - 2011-08-09 17:39:22 --> Output Class Initialized
DEBUG - 2011-08-09 17:39:22 --> Input Class Initialized
DEBUG - 2011-08-09 17:39:22 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-09 17:39:22 --> Language Class Initialized
DEBUG - 2011-08-09 17:39:22 --> Loader Class Initialized
DEBUG - 2011-08-09 17:39:22 --> Controller Class Initialized
DEBUG - 2011-08-09 17:39:22 --> Model Class Initialized
DEBUG - 2011-08-09 17:39:22 --> Model Class Initialized
DEBUG - 2011-08-09 17:39:22 --> Model Class Initialized
DEBUG - 2011-08-09 17:39:22 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-09 17:39:22 --> Database Driver Class Initialized
DEBUG - 2011-08-09 17:39:22 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-09 17:39:22 --> Helper loaded: url_helper
DEBUG - 2011-08-09 17:39:22 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-09 17:39:22 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-09 17:39:22 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-09 17:39:22 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-09 17:39:22 --> Final output sent to browser
DEBUG - 2011-08-09 17:39:22 --> Total execution time: 0.2327
DEBUG - 2011-08-09 17:39:35 --> Config Class Initialized
DEBUG - 2011-08-09 17:39:35 --> Hooks Class Initialized
DEBUG - 2011-08-09 17:39:35 --> Utf8 Class Initialized
DEBUG - 2011-08-09 17:39:35 --> UTF-8 Support Enabled
DEBUG - 2011-08-09 17:39:35 --> URI Class Initialized
DEBUG - 2011-08-09 17:39:35 --> Router Class Initialized
DEBUG - 2011-08-09 17:39:35 --> Output Class Initialized
DEBUG - 2011-08-09 17:39:35 --> Input Class Initialized
DEBUG - 2011-08-09 17:39:35 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-09 17:39:35 --> Language Class Initialized
DEBUG - 2011-08-09 17:39:35 --> Loader Class Initialized
DEBUG - 2011-08-09 17:39:35 --> Controller Class Initialized
DEBUG - 2011-08-09 17:39:35 --> Model Class Initialized
DEBUG - 2011-08-09 17:39:35 --> Model Class Initialized
DEBUG - 2011-08-09 17:39:35 --> Model Class Initialized
DEBUG - 2011-08-09 17:39:35 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-09 17:39:35 --> Database Driver Class Initialized
DEBUG - 2011-08-09 17:39:36 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-09 17:39:36 --> Helper loaded: url_helper
DEBUG - 2011-08-09 17:39:36 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-09 17:39:36 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-09 17:39:36 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-09 17:39:36 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-09 17:39:36 --> Final output sent to browser
DEBUG - 2011-08-09 17:39:36 --> Total execution time: 0.2756
DEBUG - 2011-08-09 17:39:54 --> Config Class Initialized
DEBUG - 2011-08-09 17:39:54 --> Hooks Class Initialized
DEBUG - 2011-08-09 17:39:54 --> Utf8 Class Initialized
DEBUG - 2011-08-09 17:39:54 --> UTF-8 Support Enabled
DEBUG - 2011-08-09 17:39:54 --> URI Class Initialized
DEBUG - 2011-08-09 17:39:54 --> Router Class Initialized
DEBUG - 2011-08-09 17:39:54 --> Output Class Initialized
DEBUG - 2011-08-09 17:39:54 --> Input Class Initialized
DEBUG - 2011-08-09 17:39:54 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-09 17:39:54 --> Language Class Initialized
DEBUG - 2011-08-09 17:39:54 --> Loader Class Initialized
DEBUG - 2011-08-09 17:39:54 --> Controller Class Initialized
DEBUG - 2011-08-09 17:39:54 --> Model Class Initialized
DEBUG - 2011-08-09 17:39:54 --> Model Class Initialized
DEBUG - 2011-08-09 17:39:54 --> Model Class Initialized
DEBUG - 2011-08-09 17:39:54 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-09 17:39:54 --> Database Driver Class Initialized
DEBUG - 2011-08-09 17:39:54 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-09 17:39:54 --> Helper loaded: url_helper
DEBUG - 2011-08-09 17:39:54 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-09 17:39:54 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-09 17:39:54 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-09 17:39:54 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-09 17:39:54 --> Final output sent to browser
DEBUG - 2011-08-09 17:39:54 --> Total execution time: 0.2792
DEBUG - 2011-08-09 17:39:56 --> Config Class Initialized
DEBUG - 2011-08-09 17:39:56 --> Hooks Class Initialized
DEBUG - 2011-08-09 17:39:56 --> Utf8 Class Initialized
DEBUG - 2011-08-09 17:39:56 --> UTF-8 Support Enabled
DEBUG - 2011-08-09 17:39:56 --> URI Class Initialized
DEBUG - 2011-08-09 17:39:56 --> Router Class Initialized
DEBUG - 2011-08-09 17:39:56 --> Output Class Initialized
DEBUG - 2011-08-09 17:39:56 --> Input Class Initialized
DEBUG - 2011-08-09 17:39:56 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-09 17:39:56 --> Language Class Initialized
DEBUG - 2011-08-09 17:39:56 --> Loader Class Initialized
DEBUG - 2011-08-09 17:39:56 --> Controller Class Initialized
DEBUG - 2011-08-09 17:39:56 --> Model Class Initialized
DEBUG - 2011-08-09 17:39:56 --> Model Class Initialized
DEBUG - 2011-08-09 17:39:56 --> Model Class Initialized
DEBUG - 2011-08-09 17:39:56 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-09 17:39:56 --> Database Driver Class Initialized
DEBUG - 2011-08-09 17:39:56 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-09 17:39:56 --> Helper loaded: url_helper
DEBUG - 2011-08-09 17:39:56 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-09 17:39:56 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-09 17:39:56 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-09 17:39:56 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-09 17:39:56 --> Final output sent to browser
DEBUG - 2011-08-09 17:39:56 --> Total execution time: 0.0468
DEBUG - 2011-08-09 17:40:05 --> Config Class Initialized
DEBUG - 2011-08-09 17:40:05 --> Hooks Class Initialized
DEBUG - 2011-08-09 17:40:05 --> Utf8 Class Initialized
DEBUG - 2011-08-09 17:40:05 --> UTF-8 Support Enabled
DEBUG - 2011-08-09 17:40:05 --> URI Class Initialized
DEBUG - 2011-08-09 17:40:05 --> Router Class Initialized
DEBUG - 2011-08-09 17:40:05 --> Output Class Initialized
DEBUG - 2011-08-09 17:40:05 --> Input Class Initialized
DEBUG - 2011-08-09 17:40:05 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-09 17:40:05 --> Language Class Initialized
DEBUG - 2011-08-09 17:40:05 --> Loader Class Initialized
DEBUG - 2011-08-09 17:40:05 --> Controller Class Initialized
DEBUG - 2011-08-09 17:40:05 --> Model Class Initialized
DEBUG - 2011-08-09 17:40:05 --> Model Class Initialized
DEBUG - 2011-08-09 17:40:05 --> Model Class Initialized
DEBUG - 2011-08-09 17:40:05 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-09 17:40:05 --> Database Driver Class Initialized
DEBUG - 2011-08-09 17:40:05 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-09 17:40:05 --> Helper loaded: url_helper
DEBUG - 2011-08-09 17:40:05 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-09 17:40:05 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-09 17:40:05 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-09 17:40:05 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-09 17:40:05 --> Final output sent to browser
DEBUG - 2011-08-09 17:40:05 --> Total execution time: 0.2414
DEBUG - 2011-08-09 17:40:07 --> Config Class Initialized
DEBUG - 2011-08-09 17:40:07 --> Hooks Class Initialized
DEBUG - 2011-08-09 17:40:07 --> Utf8 Class Initialized
DEBUG - 2011-08-09 17:40:07 --> UTF-8 Support Enabled
DEBUG - 2011-08-09 17:40:07 --> URI Class Initialized
DEBUG - 2011-08-09 17:40:07 --> Router Class Initialized
DEBUG - 2011-08-09 17:40:07 --> Output Class Initialized
DEBUG - 2011-08-09 17:40:07 --> Input Class Initialized
DEBUG - 2011-08-09 17:40:07 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-09 17:40:07 --> Language Class Initialized
DEBUG - 2011-08-09 17:40:07 --> Loader Class Initialized
DEBUG - 2011-08-09 17:40:07 --> Controller Class Initialized
DEBUG - 2011-08-09 17:40:07 --> Model Class Initialized
DEBUG - 2011-08-09 17:40:07 --> Model Class Initialized
DEBUG - 2011-08-09 17:40:07 --> Model Class Initialized
DEBUG - 2011-08-09 17:40:07 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-09 17:40:07 --> Database Driver Class Initialized
DEBUG - 2011-08-09 17:40:07 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-09 17:40:07 --> Helper loaded: url_helper
DEBUG - 2011-08-09 17:40:07 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-09 17:40:07 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-09 17:40:07 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-09 17:40:07 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-09 17:40:07 --> Final output sent to browser
DEBUG - 2011-08-09 17:40:07 --> Total execution time: 0.0421
DEBUG - 2011-08-09 17:40:15 --> Config Class Initialized
DEBUG - 2011-08-09 17:40:15 --> Hooks Class Initialized
DEBUG - 2011-08-09 17:40:15 --> Utf8 Class Initialized
DEBUG - 2011-08-09 17:40:15 --> UTF-8 Support Enabled
DEBUG - 2011-08-09 17:40:15 --> URI Class Initialized
DEBUG - 2011-08-09 17:40:15 --> Router Class Initialized
DEBUG - 2011-08-09 17:40:15 --> Output Class Initialized
DEBUG - 2011-08-09 17:40:15 --> Input Class Initialized
DEBUG - 2011-08-09 17:40:15 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-09 17:40:15 --> Language Class Initialized
DEBUG - 2011-08-09 17:40:15 --> Loader Class Initialized
DEBUG - 2011-08-09 17:40:15 --> Controller Class Initialized
DEBUG - 2011-08-09 17:40:15 --> Model Class Initialized
DEBUG - 2011-08-09 17:40:15 --> Model Class Initialized
DEBUG - 2011-08-09 17:40:15 --> Model Class Initialized
DEBUG - 2011-08-09 17:40:15 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-09 17:40:15 --> Database Driver Class Initialized
DEBUG - 2011-08-09 17:40:15 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-09 17:40:15 --> Helper loaded: url_helper
DEBUG - 2011-08-09 17:40:15 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-09 17:40:15 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-09 17:40:15 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-09 17:40:15 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-09 17:40:15 --> Final output sent to browser
DEBUG - 2011-08-09 17:40:15 --> Total execution time: 0.1974
DEBUG - 2011-08-09 17:40:17 --> Config Class Initialized
DEBUG - 2011-08-09 17:40:17 --> Hooks Class Initialized
DEBUG - 2011-08-09 17:40:17 --> Utf8 Class Initialized
DEBUG - 2011-08-09 17:40:17 --> UTF-8 Support Enabled
DEBUG - 2011-08-09 17:40:17 --> URI Class Initialized
DEBUG - 2011-08-09 17:40:17 --> Router Class Initialized
DEBUG - 2011-08-09 17:40:17 --> Output Class Initialized
DEBUG - 2011-08-09 17:40:17 --> Input Class Initialized
DEBUG - 2011-08-09 17:40:17 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-09 17:40:17 --> Language Class Initialized
DEBUG - 2011-08-09 17:40:17 --> Loader Class Initialized
DEBUG - 2011-08-09 17:40:17 --> Controller Class Initialized
DEBUG - 2011-08-09 17:40:17 --> Model Class Initialized
DEBUG - 2011-08-09 17:40:17 --> Model Class Initialized
DEBUG - 2011-08-09 17:40:17 --> Model Class Initialized
DEBUG - 2011-08-09 17:40:17 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-09 17:40:17 --> Database Driver Class Initialized
DEBUG - 2011-08-09 17:40:17 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-09 17:40:17 --> Helper loaded: url_helper
DEBUG - 2011-08-09 17:40:17 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-09 17:40:17 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-09 17:40:17 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-09 17:40:17 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-09 17:40:17 --> Final output sent to browser
DEBUG - 2011-08-09 17:40:17 --> Total execution time: 0.0474
DEBUG - 2011-08-09 17:40:25 --> Config Class Initialized
DEBUG - 2011-08-09 17:40:25 --> Hooks Class Initialized
DEBUG - 2011-08-09 17:40:25 --> Utf8 Class Initialized
DEBUG - 2011-08-09 17:40:25 --> UTF-8 Support Enabled
DEBUG - 2011-08-09 17:40:25 --> URI Class Initialized
DEBUG - 2011-08-09 17:40:25 --> Router Class Initialized
DEBUG - 2011-08-09 17:40:25 --> Output Class Initialized
DEBUG - 2011-08-09 17:40:25 --> Input Class Initialized
DEBUG - 2011-08-09 17:40:25 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-09 17:40:25 --> Language Class Initialized
DEBUG - 2011-08-09 17:40:25 --> Loader Class Initialized
DEBUG - 2011-08-09 17:40:25 --> Controller Class Initialized
DEBUG - 2011-08-09 17:40:25 --> Model Class Initialized
DEBUG - 2011-08-09 17:40:25 --> Model Class Initialized
DEBUG - 2011-08-09 17:40:25 --> Model Class Initialized
DEBUG - 2011-08-09 17:40:25 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-09 17:40:25 --> Database Driver Class Initialized
DEBUG - 2011-08-09 17:40:26 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-09 17:40:26 --> Helper loaded: url_helper
DEBUG - 2011-08-09 17:40:26 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-09 17:40:26 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-09 17:40:26 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-09 17:40:26 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-09 17:40:26 --> Final output sent to browser
DEBUG - 2011-08-09 17:40:26 --> Total execution time: 0.3501
DEBUG - 2011-08-09 17:40:38 --> Config Class Initialized
DEBUG - 2011-08-09 17:40:38 --> Hooks Class Initialized
DEBUG - 2011-08-09 17:40:38 --> Utf8 Class Initialized
DEBUG - 2011-08-09 17:40:38 --> UTF-8 Support Enabled
DEBUG - 2011-08-09 17:40:38 --> URI Class Initialized
DEBUG - 2011-08-09 17:40:38 --> Router Class Initialized
DEBUG - 2011-08-09 17:40:38 --> Output Class Initialized
DEBUG - 2011-08-09 17:40:38 --> Input Class Initialized
DEBUG - 2011-08-09 17:40:38 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-09 17:40:38 --> Language Class Initialized
DEBUG - 2011-08-09 17:40:38 --> Loader Class Initialized
DEBUG - 2011-08-09 17:40:38 --> Controller Class Initialized
DEBUG - 2011-08-09 17:40:38 --> Model Class Initialized
DEBUG - 2011-08-09 17:40:38 --> Model Class Initialized
DEBUG - 2011-08-09 17:40:38 --> Model Class Initialized
DEBUG - 2011-08-09 17:40:38 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-09 17:40:38 --> Database Driver Class Initialized
DEBUG - 2011-08-09 17:40:39 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-09 17:40:39 --> Helper loaded: url_helper
DEBUG - 2011-08-09 17:40:39 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-09 17:40:39 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-09 17:40:39 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-09 17:40:39 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-09 17:40:39 --> Final output sent to browser
DEBUG - 2011-08-09 17:40:39 --> Total execution time: 0.3345
DEBUG - 2011-08-09 17:40:41 --> Config Class Initialized
DEBUG - 2011-08-09 17:40:41 --> Hooks Class Initialized
DEBUG - 2011-08-09 17:40:41 --> Utf8 Class Initialized
DEBUG - 2011-08-09 17:40:41 --> UTF-8 Support Enabled
DEBUG - 2011-08-09 17:40:41 --> URI Class Initialized
DEBUG - 2011-08-09 17:40:41 --> Router Class Initialized
DEBUG - 2011-08-09 17:40:41 --> Output Class Initialized
DEBUG - 2011-08-09 17:40:41 --> Input Class Initialized
DEBUG - 2011-08-09 17:40:41 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-09 17:40:41 --> Language Class Initialized
DEBUG - 2011-08-09 17:40:41 --> Loader Class Initialized
DEBUG - 2011-08-09 17:40:41 --> Controller Class Initialized
DEBUG - 2011-08-09 17:40:41 --> Model Class Initialized
DEBUG - 2011-08-09 17:40:41 --> Model Class Initialized
DEBUG - 2011-08-09 17:40:41 --> Model Class Initialized
DEBUG - 2011-08-09 17:40:41 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-09 17:40:41 --> Database Driver Class Initialized
DEBUG - 2011-08-09 17:40:41 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-09 17:40:41 --> Helper loaded: url_helper
DEBUG - 2011-08-09 17:40:41 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-09 17:40:41 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-09 17:40:41 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-09 17:40:41 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-09 17:40:41 --> Final output sent to browser
DEBUG - 2011-08-09 17:40:41 --> Total execution time: 0.0478
DEBUG - 2011-08-09 17:40:48 --> Config Class Initialized
DEBUG - 2011-08-09 17:40:48 --> Hooks Class Initialized
DEBUG - 2011-08-09 17:40:48 --> Utf8 Class Initialized
DEBUG - 2011-08-09 17:40:48 --> UTF-8 Support Enabled
DEBUG - 2011-08-09 17:40:48 --> URI Class Initialized
DEBUG - 2011-08-09 17:40:48 --> Router Class Initialized
DEBUG - 2011-08-09 17:40:48 --> Output Class Initialized
DEBUG - 2011-08-09 17:40:48 --> Input Class Initialized
DEBUG - 2011-08-09 17:40:48 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-09 17:40:48 --> Language Class Initialized
DEBUG - 2011-08-09 17:40:48 --> Loader Class Initialized
DEBUG - 2011-08-09 17:40:48 --> Controller Class Initialized
DEBUG - 2011-08-09 17:40:48 --> Model Class Initialized
DEBUG - 2011-08-09 17:40:48 --> Model Class Initialized
DEBUG - 2011-08-09 17:40:48 --> Model Class Initialized
DEBUG - 2011-08-09 17:40:48 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-09 17:40:48 --> Database Driver Class Initialized
DEBUG - 2011-08-09 17:40:49 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-09 17:40:49 --> Helper loaded: url_helper
DEBUG - 2011-08-09 17:40:49 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-09 17:40:49 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-09 17:40:49 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-09 17:40:49 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-09 17:40:49 --> Final output sent to browser
DEBUG - 2011-08-09 17:40:49 --> Total execution time: 0.3482
DEBUG - 2011-08-09 17:40:59 --> Config Class Initialized
DEBUG - 2011-08-09 17:40:59 --> Hooks Class Initialized
DEBUG - 2011-08-09 17:40:59 --> Utf8 Class Initialized
DEBUG - 2011-08-09 17:40:59 --> UTF-8 Support Enabled
DEBUG - 2011-08-09 17:40:59 --> URI Class Initialized
DEBUG - 2011-08-09 17:40:59 --> Router Class Initialized
DEBUG - 2011-08-09 17:40:59 --> Output Class Initialized
DEBUG - 2011-08-09 17:40:59 --> Input Class Initialized
DEBUG - 2011-08-09 17:40:59 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-09 17:40:59 --> Language Class Initialized
DEBUG - 2011-08-09 17:40:59 --> Loader Class Initialized
DEBUG - 2011-08-09 17:40:59 --> Controller Class Initialized
DEBUG - 2011-08-09 17:40:59 --> Model Class Initialized
DEBUG - 2011-08-09 17:40:59 --> Model Class Initialized
DEBUG - 2011-08-09 17:40:59 --> Model Class Initialized
DEBUG - 2011-08-09 17:40:59 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-09 17:41:00 --> Database Driver Class Initialized
DEBUG - 2011-08-09 17:41:00 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-09 17:41:00 --> Helper loaded: url_helper
DEBUG - 2011-08-09 17:41:00 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-09 17:41:00 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-09 17:41:00 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-09 17:41:00 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-09 17:41:00 --> Final output sent to browser
DEBUG - 2011-08-09 17:41:00 --> Total execution time: 0.2931
DEBUG - 2011-08-09 17:41:01 --> Config Class Initialized
DEBUG - 2011-08-09 17:41:01 --> Hooks Class Initialized
DEBUG - 2011-08-09 17:41:01 --> Utf8 Class Initialized
DEBUG - 2011-08-09 17:41:01 --> UTF-8 Support Enabled
DEBUG - 2011-08-09 17:41:01 --> URI Class Initialized
DEBUG - 2011-08-09 17:41:01 --> Router Class Initialized
DEBUG - 2011-08-09 17:41:01 --> Output Class Initialized
DEBUG - 2011-08-09 17:41:01 --> Input Class Initialized
DEBUG - 2011-08-09 17:41:01 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-09 17:41:01 --> Language Class Initialized
DEBUG - 2011-08-09 17:41:01 --> Loader Class Initialized
DEBUG - 2011-08-09 17:41:01 --> Controller Class Initialized
DEBUG - 2011-08-09 17:41:01 --> Model Class Initialized
DEBUG - 2011-08-09 17:41:01 --> Model Class Initialized
DEBUG - 2011-08-09 17:41:01 --> Model Class Initialized
DEBUG - 2011-08-09 17:41:01 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-09 17:41:01 --> Database Driver Class Initialized
DEBUG - 2011-08-09 17:41:01 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-09 17:41:01 --> Helper loaded: url_helper
DEBUG - 2011-08-09 17:41:01 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-09 17:41:01 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-09 17:41:01 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-09 17:41:01 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-09 17:41:01 --> Final output sent to browser
DEBUG - 2011-08-09 17:41:01 --> Total execution time: 0.0627
DEBUG - 2011-08-09 17:41:13 --> Config Class Initialized
DEBUG - 2011-08-09 17:41:13 --> Hooks Class Initialized
DEBUG - 2011-08-09 17:41:13 --> Utf8 Class Initialized
DEBUG - 2011-08-09 17:41:13 --> UTF-8 Support Enabled
DEBUG - 2011-08-09 17:41:13 --> URI Class Initialized
DEBUG - 2011-08-09 17:41:13 --> Router Class Initialized
DEBUG - 2011-08-09 17:41:13 --> Output Class Initialized
DEBUG - 2011-08-09 17:41:13 --> Input Class Initialized
DEBUG - 2011-08-09 17:41:13 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-09 17:41:13 --> Language Class Initialized
DEBUG - 2011-08-09 17:41:13 --> Loader Class Initialized
DEBUG - 2011-08-09 17:41:13 --> Controller Class Initialized
DEBUG - 2011-08-09 17:41:13 --> Model Class Initialized
DEBUG - 2011-08-09 17:41:13 --> Model Class Initialized
DEBUG - 2011-08-09 17:41:13 --> Model Class Initialized
DEBUG - 2011-08-09 17:41:13 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-09 17:41:13 --> Database Driver Class Initialized
DEBUG - 2011-08-09 17:41:13 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-09 17:41:13 --> Helper loaded: url_helper
DEBUG - 2011-08-09 17:41:13 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-09 17:41:13 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-09 17:41:13 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-09 17:41:13 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-09 17:41:13 --> Final output sent to browser
DEBUG - 2011-08-09 17:41:13 --> Total execution time: 0.0473
DEBUG - 2011-08-09 17:41:17 --> Config Class Initialized
DEBUG - 2011-08-09 17:41:17 --> Hooks Class Initialized
DEBUG - 2011-08-09 17:41:17 --> Utf8 Class Initialized
DEBUG - 2011-08-09 17:41:17 --> UTF-8 Support Enabled
DEBUG - 2011-08-09 17:41:17 --> URI Class Initialized
DEBUG - 2011-08-09 17:41:17 --> Router Class Initialized
ERROR - 2011-08-09 17:41:17 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-08-09 18:47:47 --> Config Class Initialized
DEBUG - 2011-08-09 18:47:47 --> Hooks Class Initialized
DEBUG - 2011-08-09 18:47:47 --> Utf8 Class Initialized
DEBUG - 2011-08-09 18:47:47 --> UTF-8 Support Enabled
DEBUG - 2011-08-09 18:47:47 --> URI Class Initialized
DEBUG - 2011-08-09 18:47:47 --> Router Class Initialized
DEBUG - 2011-08-09 18:47:47 --> Output Class Initialized
DEBUG - 2011-08-09 18:47:47 --> Input Class Initialized
DEBUG - 2011-08-09 18:47:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-09 18:47:47 --> Language Class Initialized
DEBUG - 2011-08-09 18:47:47 --> Loader Class Initialized
DEBUG - 2011-08-09 18:47:47 --> Controller Class Initialized
DEBUG - 2011-08-09 18:47:47 --> Model Class Initialized
DEBUG - 2011-08-09 18:47:47 --> Model Class Initialized
DEBUG - 2011-08-09 18:47:47 --> Model Class Initialized
DEBUG - 2011-08-09 18:47:47 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-09 18:47:47 --> Database Driver Class Initialized
DEBUG - 2011-08-09 18:47:47 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-09 18:47:47 --> Helper loaded: url_helper
DEBUG - 2011-08-09 18:47:47 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-09 18:47:47 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-09 18:47:47 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-09 18:47:47 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-09 18:47:47 --> Final output sent to browser
DEBUG - 2011-08-09 18:47:47 --> Total execution time: 0.2456
DEBUG - 2011-08-09 18:47:50 --> Config Class Initialized
DEBUG - 2011-08-09 18:47:50 --> Hooks Class Initialized
DEBUG - 2011-08-09 18:47:50 --> Utf8 Class Initialized
DEBUG - 2011-08-09 18:47:50 --> UTF-8 Support Enabled
DEBUG - 2011-08-09 18:47:50 --> URI Class Initialized
DEBUG - 2011-08-09 18:47:50 --> Router Class Initialized
ERROR - 2011-08-09 18:47:50 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-09 21:33:54 --> Config Class Initialized
DEBUG - 2011-08-09 21:33:54 --> Hooks Class Initialized
DEBUG - 2011-08-09 21:33:54 --> Utf8 Class Initialized
DEBUG - 2011-08-09 21:33:54 --> UTF-8 Support Enabled
DEBUG - 2011-08-09 21:33:54 --> URI Class Initialized
DEBUG - 2011-08-09 21:33:54 --> Router Class Initialized
DEBUG - 2011-08-09 21:33:54 --> Output Class Initialized
DEBUG - 2011-08-09 21:33:54 --> Input Class Initialized
DEBUG - 2011-08-09 21:33:54 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-09 21:33:54 --> Language Class Initialized
DEBUG - 2011-08-09 21:33:54 --> Loader Class Initialized
DEBUG - 2011-08-09 21:33:54 --> Controller Class Initialized
DEBUG - 2011-08-09 21:33:54 --> Model Class Initialized
DEBUG - 2011-08-09 21:33:54 --> Model Class Initialized
DEBUG - 2011-08-09 21:33:54 --> Model Class Initialized
DEBUG - 2011-08-09 21:33:54 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-09 21:33:54 --> Database Driver Class Initialized
DEBUG - 2011-08-09 21:33:55 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-09 21:33:55 --> Helper loaded: url_helper
DEBUG - 2011-08-09 21:33:55 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-09 21:33:55 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-09 21:33:55 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-09 21:33:55 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-09 21:33:55 --> Final output sent to browser
DEBUG - 2011-08-09 21:33:55 --> Total execution time: 1.0564
DEBUG - 2011-08-09 21:33:57 --> Config Class Initialized
DEBUG - 2011-08-09 21:33:57 --> Hooks Class Initialized
DEBUG - 2011-08-09 21:33:57 --> Utf8 Class Initialized
DEBUG - 2011-08-09 21:33:57 --> UTF-8 Support Enabled
DEBUG - 2011-08-09 21:33:57 --> URI Class Initialized
DEBUG - 2011-08-09 21:33:57 --> Router Class Initialized
ERROR - 2011-08-09 21:33:57 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-09 21:34:10 --> Config Class Initialized
DEBUG - 2011-08-09 21:34:10 --> Hooks Class Initialized
DEBUG - 2011-08-09 21:34:10 --> Utf8 Class Initialized
DEBUG - 2011-08-09 21:34:10 --> UTF-8 Support Enabled
DEBUG - 2011-08-09 21:34:10 --> URI Class Initialized
DEBUG - 2011-08-09 21:34:10 --> Router Class Initialized
DEBUG - 2011-08-09 21:34:10 --> Output Class Initialized
DEBUG - 2011-08-09 21:34:10 --> Input Class Initialized
DEBUG - 2011-08-09 21:34:10 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-09 21:34:10 --> Language Class Initialized
DEBUG - 2011-08-09 21:34:10 --> Loader Class Initialized
DEBUG - 2011-08-09 21:34:10 --> Controller Class Initialized
DEBUG - 2011-08-09 21:34:10 --> Model Class Initialized
DEBUG - 2011-08-09 21:34:10 --> Model Class Initialized
DEBUG - 2011-08-09 21:34:10 --> Model Class Initialized
DEBUG - 2011-08-09 21:34:10 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-09 21:34:10 --> Database Driver Class Initialized
DEBUG - 2011-08-09 21:34:10 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-09 21:34:10 --> Helper loaded: url_helper
DEBUG - 2011-08-09 21:34:10 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-09 21:34:10 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-09 21:34:10 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-09 21:34:10 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-09 21:34:10 --> Final output sent to browser
DEBUG - 2011-08-09 21:34:10 --> Total execution time: 0.7001
DEBUG - 2011-08-09 21:34:12 --> Config Class Initialized
DEBUG - 2011-08-09 21:34:12 --> Hooks Class Initialized
DEBUG - 2011-08-09 21:34:12 --> Utf8 Class Initialized
DEBUG - 2011-08-09 21:34:12 --> UTF-8 Support Enabled
DEBUG - 2011-08-09 21:34:12 --> URI Class Initialized
DEBUG - 2011-08-09 21:34:12 --> Router Class Initialized
ERROR - 2011-08-09 21:34:12 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-09 21:39:12 --> Config Class Initialized
DEBUG - 2011-08-09 21:39:12 --> Hooks Class Initialized
DEBUG - 2011-08-09 21:39:12 --> Utf8 Class Initialized
DEBUG - 2011-08-09 21:39:12 --> UTF-8 Support Enabled
DEBUG - 2011-08-09 21:39:12 --> URI Class Initialized
DEBUG - 2011-08-09 21:39:12 --> Router Class Initialized
DEBUG - 2011-08-09 21:39:12 --> No URI present. Default controller set.
DEBUG - 2011-08-09 21:39:12 --> Output Class Initialized
DEBUG - 2011-08-09 21:39:12 --> Input Class Initialized
DEBUG - 2011-08-09 21:39:12 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-09 21:39:12 --> Language Class Initialized
DEBUG - 2011-08-09 21:39:12 --> Loader Class Initialized
DEBUG - 2011-08-09 21:39:12 --> Controller Class Initialized
DEBUG - 2011-08-09 21:39:12 --> File loaded: application/views/splash/main.php
DEBUG - 2011-08-09 21:39:12 --> Helper loaded: url_helper
DEBUG - 2011-08-09 21:39:12 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-09 21:39:12 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-09 21:39:12 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-09 21:39:12 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-09 21:39:12 --> Final output sent to browser
DEBUG - 2011-08-09 21:39:12 --> Total execution time: 0.0830
DEBUG - 2011-08-09 21:39:14 --> Config Class Initialized
DEBUG - 2011-08-09 21:39:14 --> Hooks Class Initialized
DEBUG - 2011-08-09 21:39:14 --> Utf8 Class Initialized
DEBUG - 2011-08-09 21:39:14 --> UTF-8 Support Enabled
DEBUG - 2011-08-09 21:39:14 --> URI Class Initialized
DEBUG - 2011-08-09 21:39:14 --> Router Class Initialized
ERROR - 2011-08-09 21:39:14 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-09 21:39:16 --> Config Class Initialized
DEBUG - 2011-08-09 21:39:16 --> Hooks Class Initialized
DEBUG - 2011-08-09 21:39:16 --> Utf8 Class Initialized
DEBUG - 2011-08-09 21:39:16 --> UTF-8 Support Enabled
DEBUG - 2011-08-09 21:39:16 --> URI Class Initialized
DEBUG - 2011-08-09 21:39:16 --> Router Class Initialized
DEBUG - 2011-08-09 21:39:16 --> Output Class Initialized
DEBUG - 2011-08-09 21:39:16 --> Input Class Initialized
DEBUG - 2011-08-09 21:39:16 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-09 21:39:16 --> Language Class Initialized
DEBUG - 2011-08-09 21:39:16 --> Loader Class Initialized
DEBUG - 2011-08-09 21:39:16 --> Controller Class Initialized
DEBUG - 2011-08-09 21:39:16 --> Model Class Initialized
DEBUG - 2011-08-09 21:39:16 --> Model Class Initialized
DEBUG - 2011-08-09 21:39:16 --> Model Class Initialized
DEBUG - 2011-08-09 21:39:16 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-09 21:39:16 --> Database Driver Class Initialized
DEBUG - 2011-08-09 21:39:16 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-09 21:39:16 --> Helper loaded: url_helper
DEBUG - 2011-08-09 21:39:16 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-09 21:39:16 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-09 21:39:16 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-09 21:39:16 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-09 21:39:16 --> Final output sent to browser
DEBUG - 2011-08-09 21:39:16 --> Total execution time: 0.0490
DEBUG - 2011-08-09 21:39:18 --> Config Class Initialized
DEBUG - 2011-08-09 21:39:18 --> Hooks Class Initialized
DEBUG - 2011-08-09 21:39:18 --> Utf8 Class Initialized
DEBUG - 2011-08-09 21:39:18 --> UTF-8 Support Enabled
DEBUG - 2011-08-09 21:39:18 --> URI Class Initialized
DEBUG - 2011-08-09 21:39:18 --> Router Class Initialized
ERROR - 2011-08-09 21:39:18 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-09 21:39:36 --> Config Class Initialized
DEBUG - 2011-08-09 21:39:36 --> Hooks Class Initialized
DEBUG - 2011-08-09 21:39:36 --> Utf8 Class Initialized
DEBUG - 2011-08-09 21:39:36 --> UTF-8 Support Enabled
DEBUG - 2011-08-09 21:39:36 --> URI Class Initialized
DEBUG - 2011-08-09 21:39:36 --> Router Class Initialized
DEBUG - 2011-08-09 21:39:36 --> Output Class Initialized
DEBUG - 2011-08-09 21:39:36 --> Input Class Initialized
DEBUG - 2011-08-09 21:39:36 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-09 21:39:36 --> Language Class Initialized
DEBUG - 2011-08-09 21:39:36 --> Loader Class Initialized
DEBUG - 2011-08-09 21:39:36 --> Controller Class Initialized
DEBUG - 2011-08-09 21:39:36 --> Model Class Initialized
DEBUG - 2011-08-09 21:39:36 --> Model Class Initialized
DEBUG - 2011-08-09 21:39:36 --> Model Class Initialized
DEBUG - 2011-08-09 21:39:36 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-09 21:39:36 --> Database Driver Class Initialized
DEBUG - 2011-08-09 21:39:36 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-09 21:39:36 --> Helper loaded: url_helper
DEBUG - 2011-08-09 21:39:36 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-09 21:39:36 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-09 21:39:36 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-09 21:39:36 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-09 21:39:36 --> Final output sent to browser
DEBUG - 2011-08-09 21:39:36 --> Total execution time: 0.2773
DEBUG - 2011-08-09 21:39:38 --> Config Class Initialized
DEBUG - 2011-08-09 21:39:38 --> Hooks Class Initialized
DEBUG - 2011-08-09 21:39:38 --> Utf8 Class Initialized
DEBUG - 2011-08-09 21:39:38 --> UTF-8 Support Enabled
DEBUG - 2011-08-09 21:39:38 --> URI Class Initialized
DEBUG - 2011-08-09 21:39:38 --> Router Class Initialized
ERROR - 2011-08-09 21:39:38 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-09 22:03:32 --> Config Class Initialized
DEBUG - 2011-08-09 22:03:32 --> Hooks Class Initialized
DEBUG - 2011-08-09 22:03:32 --> Utf8 Class Initialized
DEBUG - 2011-08-09 22:03:32 --> UTF-8 Support Enabled
DEBUG - 2011-08-09 22:03:32 --> URI Class Initialized
DEBUG - 2011-08-09 22:03:32 --> Router Class Initialized
ERROR - 2011-08-09 22:03:32 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-08-09 22:16:58 --> Config Class Initialized
DEBUG - 2011-08-09 22:16:58 --> Hooks Class Initialized
DEBUG - 2011-08-09 22:16:58 --> Utf8 Class Initialized
DEBUG - 2011-08-09 22:16:58 --> UTF-8 Support Enabled
DEBUG - 2011-08-09 22:16:58 --> URI Class Initialized
DEBUG - 2011-08-09 22:16:58 --> Router Class Initialized
DEBUG - 2011-08-09 22:16:58 --> No URI present. Default controller set.
DEBUG - 2011-08-09 22:16:58 --> Output Class Initialized
DEBUG - 2011-08-09 22:16:58 --> Input Class Initialized
DEBUG - 2011-08-09 22:16:58 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-09 22:16:58 --> Language Class Initialized
DEBUG - 2011-08-09 22:16:58 --> Loader Class Initialized
DEBUG - 2011-08-09 22:16:58 --> Controller Class Initialized
DEBUG - 2011-08-09 22:16:58 --> File loaded: application/views/splash/main.php
DEBUG - 2011-08-09 22:16:58 --> Helper loaded: url_helper
DEBUG - 2011-08-09 22:16:58 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-09 22:16:58 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-09 22:16:58 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-09 22:16:58 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-09 22:16:58 --> Final output sent to browser
DEBUG - 2011-08-09 22:16:58 --> Total execution time: 0.0144
DEBUG - 2011-08-09 23:31:31 --> Config Class Initialized
DEBUG - 2011-08-09 23:31:31 --> Hooks Class Initialized
DEBUG - 2011-08-09 23:31:31 --> Utf8 Class Initialized
DEBUG - 2011-08-09 23:31:31 --> UTF-8 Support Enabled
DEBUG - 2011-08-09 23:31:31 --> URI Class Initialized
DEBUG - 2011-08-09 23:31:31 --> Router Class Initialized
DEBUG - 2011-08-09 23:31:31 --> Output Class Initialized
DEBUG - 2011-08-09 23:31:31 --> Input Class Initialized
DEBUG - 2011-08-09 23:31:31 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-09 23:31:31 --> Language Class Initialized
DEBUG - 2011-08-09 23:31:31 --> Loader Class Initialized
DEBUG - 2011-08-09 23:31:31 --> Controller Class Initialized
ERROR - 2011-08-09 23:31:31 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-09 23:31:31 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-09 23:31:31 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-09 23:31:31 --> Model Class Initialized
DEBUG - 2011-08-09 23:31:31 --> Model Class Initialized
DEBUG - 2011-08-09 23:31:31 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-09 23:31:31 --> Database Driver Class Initialized
DEBUG - 2011-08-09 23:31:31 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-09 23:31:31 --> Helper loaded: url_helper
DEBUG - 2011-08-09 23:31:31 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-09 23:31:31 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-09 23:31:31 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-09 23:31:31 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-09 23:31:31 --> Final output sent to browser
DEBUG - 2011-08-09 23:31:31 --> Total execution time: 0.1199
DEBUG - 2011-08-09 23:31:31 --> Config Class Initialized
DEBUG - 2011-08-09 23:31:31 --> Hooks Class Initialized
DEBUG - 2011-08-09 23:31:31 --> Utf8 Class Initialized
DEBUG - 2011-08-09 23:31:31 --> UTF-8 Support Enabled
DEBUG - 2011-08-09 23:31:31 --> URI Class Initialized
DEBUG - 2011-08-09 23:31:31 --> Router Class Initialized
DEBUG - 2011-08-09 23:31:31 --> Output Class Initialized
DEBUG - 2011-08-09 23:31:31 --> Input Class Initialized
DEBUG - 2011-08-09 23:31:31 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-09 23:31:31 --> Language Class Initialized
DEBUG - 2011-08-09 23:31:31 --> Loader Class Initialized
DEBUG - 2011-08-09 23:31:31 --> Controller Class Initialized
DEBUG - 2011-08-09 23:31:31 --> Model Class Initialized
DEBUG - 2011-08-09 23:31:31 --> Model Class Initialized
DEBUG - 2011-08-09 23:31:31 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-09 23:31:31 --> Database Driver Class Initialized
DEBUG - 2011-08-09 23:31:33 --> Final output sent to browser
DEBUG - 2011-08-09 23:31:33 --> Total execution time: 1.3595

<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2011-08-23 01:20:06 --> Config Class Initialized
DEBUG - 2011-08-23 01:20:06 --> Hooks Class Initialized
DEBUG - 2011-08-23 01:20:06 --> Utf8 Class Initialized
DEBUG - 2011-08-23 01:20:06 --> UTF-8 Support Enabled
DEBUG - 2011-08-23 01:20:06 --> URI Class Initialized
DEBUG - 2011-08-23 01:20:06 --> Router Class Initialized
ERROR - 2011-08-23 01:20:06 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-08-23 02:19:54 --> Config Class Initialized
DEBUG - 2011-08-23 02:19:54 --> Hooks Class Initialized
DEBUG - 2011-08-23 02:19:54 --> Utf8 Class Initialized
DEBUG - 2011-08-23 02:19:54 --> UTF-8 Support Enabled
DEBUG - 2011-08-23 02:19:54 --> URI Class Initialized
DEBUG - 2011-08-23 02:19:54 --> Router Class Initialized
ERROR - 2011-08-23 02:19:54 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-08-23 02:19:54 --> Config Class Initialized
DEBUG - 2011-08-23 02:19:54 --> Hooks Class Initialized
DEBUG - 2011-08-23 02:19:54 --> Utf8 Class Initialized
DEBUG - 2011-08-23 02:19:54 --> UTF-8 Support Enabled
DEBUG - 2011-08-23 02:19:54 --> URI Class Initialized
DEBUG - 2011-08-23 02:19:54 --> Router Class Initialized
DEBUG - 2011-08-23 02:19:54 --> Output Class Initialized
DEBUG - 2011-08-23 02:19:54 --> Input Class Initialized
DEBUG - 2011-08-23 02:19:54 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-23 02:19:54 --> Language Class Initialized
DEBUG - 2011-08-23 02:19:54 --> Loader Class Initialized
DEBUG - 2011-08-23 02:19:54 --> Controller Class Initialized
DEBUG - 2011-08-23 02:19:54 --> Model Class Initialized
DEBUG - 2011-08-23 02:19:54 --> Model Class Initialized
DEBUG - 2011-08-23 02:19:54 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-23 02:19:54 --> Database Driver Class Initialized
DEBUG - 2011-08-23 02:19:57 --> Final output sent to browser
DEBUG - 2011-08-23 02:19:57 --> Total execution time: 2.6068
DEBUG - 2011-08-23 02:33:13 --> Config Class Initialized
DEBUG - 2011-08-23 02:33:13 --> Hooks Class Initialized
DEBUG - 2011-08-23 02:33:13 --> Utf8 Class Initialized
DEBUG - 2011-08-23 02:33:13 --> UTF-8 Support Enabled
DEBUG - 2011-08-23 02:33:13 --> URI Class Initialized
DEBUG - 2011-08-23 02:33:13 --> Router Class Initialized
DEBUG - 2011-08-23 02:33:13 --> No URI present. Default controller set.
DEBUG - 2011-08-23 02:33:13 --> Output Class Initialized
DEBUG - 2011-08-23 02:33:13 --> Input Class Initialized
DEBUG - 2011-08-23 02:33:13 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-23 02:33:13 --> Language Class Initialized
DEBUG - 2011-08-23 02:33:13 --> Loader Class Initialized
DEBUG - 2011-08-23 02:33:13 --> Controller Class Initialized
DEBUG - 2011-08-23 02:33:13 --> File loaded: application/views/splash/main.php
DEBUG - 2011-08-23 02:33:13 --> Helper loaded: url_helper
DEBUG - 2011-08-23 02:33:13 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-23 02:33:13 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-23 02:33:13 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-23 02:33:13 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-23 02:33:13 --> Final output sent to browser
DEBUG - 2011-08-23 02:33:13 --> Total execution time: 0.3860
DEBUG - 2011-08-23 03:32:19 --> Config Class Initialized
DEBUG - 2011-08-23 03:32:19 --> Hooks Class Initialized
DEBUG - 2011-08-23 03:32:19 --> Utf8 Class Initialized
DEBUG - 2011-08-23 03:32:19 --> UTF-8 Support Enabled
DEBUG - 2011-08-23 03:32:19 --> URI Class Initialized
DEBUG - 2011-08-23 03:32:19 --> Router Class Initialized
DEBUG - 2011-08-23 03:32:19 --> No URI present. Default controller set.
DEBUG - 2011-08-23 03:32:19 --> Output Class Initialized
DEBUG - 2011-08-23 03:32:19 --> Input Class Initialized
DEBUG - 2011-08-23 03:32:19 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-23 03:32:19 --> Language Class Initialized
DEBUG - 2011-08-23 03:32:19 --> Loader Class Initialized
DEBUG - 2011-08-23 03:32:19 --> Controller Class Initialized
DEBUG - 2011-08-23 03:32:19 --> File loaded: application/views/splash/main.php
DEBUG - 2011-08-23 03:32:19 --> Helper loaded: url_helper
DEBUG - 2011-08-23 03:32:19 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-23 03:32:19 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-23 03:32:19 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-23 03:32:19 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-23 03:32:19 --> Final output sent to browser
DEBUG - 2011-08-23 03:32:19 --> Total execution time: 0.5620
DEBUG - 2011-08-23 03:44:09 --> Config Class Initialized
DEBUG - 2011-08-23 03:44:09 --> Hooks Class Initialized
DEBUG - 2011-08-23 03:44:09 --> Utf8 Class Initialized
DEBUG - 2011-08-23 03:44:09 --> UTF-8 Support Enabled
DEBUG - 2011-08-23 03:44:09 --> URI Class Initialized
DEBUG - 2011-08-23 03:44:09 --> Router Class Initialized
DEBUG - 2011-08-23 03:44:09 --> Output Class Initialized
DEBUG - 2011-08-23 03:44:09 --> Input Class Initialized
DEBUG - 2011-08-23 03:44:09 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-23 03:44:09 --> Language Class Initialized
DEBUG - 2011-08-23 03:44:09 --> Loader Class Initialized
DEBUG - 2011-08-23 03:44:09 --> Controller Class Initialized
ERROR - 2011-08-23 03:44:09 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-23 03:44:09 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-23 03:44:09 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-23 03:44:09 --> Model Class Initialized
DEBUG - 2011-08-23 03:44:09 --> Model Class Initialized
DEBUG - 2011-08-23 03:44:09 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-23 03:44:10 --> Database Driver Class Initialized
DEBUG - 2011-08-23 03:44:10 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-23 03:44:10 --> Helper loaded: url_helper
DEBUG - 2011-08-23 03:44:10 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-23 03:44:10 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-23 03:44:10 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-23 03:44:10 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-23 03:44:10 --> Final output sent to browser
DEBUG - 2011-08-23 03:44:10 --> Total execution time: 0.5410
DEBUG - 2011-08-23 03:44:14 --> Config Class Initialized
DEBUG - 2011-08-23 03:44:14 --> Hooks Class Initialized
DEBUG - 2011-08-23 03:44:14 --> Utf8 Class Initialized
DEBUG - 2011-08-23 03:44:14 --> UTF-8 Support Enabled
DEBUG - 2011-08-23 03:44:14 --> URI Class Initialized
DEBUG - 2011-08-23 03:44:14 --> Router Class Initialized
DEBUG - 2011-08-23 03:44:14 --> Output Class Initialized
DEBUG - 2011-08-23 03:44:14 --> Input Class Initialized
DEBUG - 2011-08-23 03:44:14 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-23 03:44:14 --> Language Class Initialized
DEBUG - 2011-08-23 03:44:14 --> Loader Class Initialized
DEBUG - 2011-08-23 03:44:14 --> Controller Class Initialized
DEBUG - 2011-08-23 03:44:14 --> Model Class Initialized
DEBUG - 2011-08-23 03:44:14 --> Model Class Initialized
DEBUG - 2011-08-23 03:44:14 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-23 03:44:14 --> Database Driver Class Initialized
DEBUG - 2011-08-23 03:44:16 --> Final output sent to browser
DEBUG - 2011-08-23 03:44:16 --> Total execution time: 1.4805
DEBUG - 2011-08-23 03:44:18 --> Config Class Initialized
DEBUG - 2011-08-23 03:44:18 --> Hooks Class Initialized
DEBUG - 2011-08-23 03:44:18 --> Utf8 Class Initialized
DEBUG - 2011-08-23 03:44:18 --> UTF-8 Support Enabled
DEBUG - 2011-08-23 03:44:18 --> URI Class Initialized
DEBUG - 2011-08-23 03:44:18 --> Router Class Initialized
ERROR - 2011-08-23 03:44:18 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-23 03:44:44 --> Config Class Initialized
DEBUG - 2011-08-23 03:44:44 --> Hooks Class Initialized
DEBUG - 2011-08-23 03:44:44 --> Utf8 Class Initialized
DEBUG - 2011-08-23 03:44:44 --> UTF-8 Support Enabled
DEBUG - 2011-08-23 03:44:44 --> URI Class Initialized
DEBUG - 2011-08-23 03:44:44 --> Router Class Initialized
DEBUG - 2011-08-23 03:44:44 --> Output Class Initialized
DEBUG - 2011-08-23 03:44:44 --> Input Class Initialized
DEBUG - 2011-08-23 03:44:44 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-23 03:44:44 --> Language Class Initialized
DEBUG - 2011-08-23 03:44:44 --> Loader Class Initialized
DEBUG - 2011-08-23 03:44:44 --> Controller Class Initialized
ERROR - 2011-08-23 03:44:44 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-23 03:44:44 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-23 03:44:44 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-23 03:44:44 --> Model Class Initialized
DEBUG - 2011-08-23 03:44:44 --> Model Class Initialized
DEBUG - 2011-08-23 03:44:44 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-23 03:44:44 --> Database Driver Class Initialized
DEBUG - 2011-08-23 03:44:44 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-23 03:44:44 --> Helper loaded: url_helper
DEBUG - 2011-08-23 03:44:44 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-23 03:44:44 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-23 03:44:44 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-23 03:44:44 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-23 03:44:44 --> Final output sent to browser
DEBUG - 2011-08-23 03:44:44 --> Total execution time: 0.0481
DEBUG - 2011-08-23 03:44:46 --> Config Class Initialized
DEBUG - 2011-08-23 03:44:46 --> Hooks Class Initialized
DEBUG - 2011-08-23 03:44:46 --> Utf8 Class Initialized
DEBUG - 2011-08-23 03:44:46 --> UTF-8 Support Enabled
DEBUG - 2011-08-23 03:44:46 --> URI Class Initialized
DEBUG - 2011-08-23 03:44:46 --> Router Class Initialized
DEBUG - 2011-08-23 03:44:46 --> Output Class Initialized
DEBUG - 2011-08-23 03:44:46 --> Input Class Initialized
DEBUG - 2011-08-23 03:44:46 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-23 03:44:46 --> Language Class Initialized
DEBUG - 2011-08-23 03:44:46 --> Loader Class Initialized
DEBUG - 2011-08-23 03:44:46 --> Controller Class Initialized
DEBUG - 2011-08-23 03:44:46 --> Model Class Initialized
DEBUG - 2011-08-23 03:44:46 --> Model Class Initialized
DEBUG - 2011-08-23 03:44:46 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-23 03:44:46 --> Database Driver Class Initialized
DEBUG - 2011-08-23 03:44:47 --> Final output sent to browser
DEBUG - 2011-08-23 03:44:47 --> Total execution time: 1.2439
DEBUG - 2011-08-23 03:44:51 --> Config Class Initialized
DEBUG - 2011-08-23 03:44:51 --> Hooks Class Initialized
DEBUG - 2011-08-23 03:44:51 --> Utf8 Class Initialized
DEBUG - 2011-08-23 03:44:51 --> UTF-8 Support Enabled
DEBUG - 2011-08-23 03:44:51 --> URI Class Initialized
DEBUG - 2011-08-23 03:44:51 --> Router Class Initialized
ERROR - 2011-08-23 03:44:51 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-23 03:44:55 --> Config Class Initialized
DEBUG - 2011-08-23 03:44:55 --> Hooks Class Initialized
DEBUG - 2011-08-23 03:44:55 --> Utf8 Class Initialized
DEBUG - 2011-08-23 03:44:55 --> UTF-8 Support Enabled
DEBUG - 2011-08-23 03:44:55 --> URI Class Initialized
DEBUG - 2011-08-23 03:44:55 --> Router Class Initialized
DEBUG - 2011-08-23 03:44:55 --> Output Class Initialized
DEBUG - 2011-08-23 03:44:55 --> Input Class Initialized
DEBUG - 2011-08-23 03:44:55 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-23 03:44:55 --> Language Class Initialized
DEBUG - 2011-08-23 03:44:55 --> Loader Class Initialized
DEBUG - 2011-08-23 03:44:55 --> Controller Class Initialized
ERROR - 2011-08-23 03:44:55 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-23 03:44:55 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-23 03:44:55 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-23 03:44:55 --> Model Class Initialized
DEBUG - 2011-08-23 03:44:55 --> Model Class Initialized
DEBUG - 2011-08-23 03:44:55 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-23 03:44:55 --> Database Driver Class Initialized
DEBUG - 2011-08-23 03:44:55 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-23 03:44:55 --> Helper loaded: url_helper
DEBUG - 2011-08-23 03:44:55 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-23 03:44:55 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-23 03:44:55 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-23 03:44:55 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-23 03:44:55 --> Final output sent to browser
DEBUG - 2011-08-23 03:44:55 --> Total execution time: 0.0348
DEBUG - 2011-08-23 03:44:56 --> Config Class Initialized
DEBUG - 2011-08-23 03:44:56 --> Hooks Class Initialized
DEBUG - 2011-08-23 03:44:56 --> Utf8 Class Initialized
DEBUG - 2011-08-23 03:44:56 --> UTF-8 Support Enabled
DEBUG - 2011-08-23 03:44:56 --> URI Class Initialized
DEBUG - 2011-08-23 03:44:56 --> Router Class Initialized
DEBUG - 2011-08-23 03:44:56 --> Output Class Initialized
DEBUG - 2011-08-23 03:44:56 --> Input Class Initialized
DEBUG - 2011-08-23 03:44:56 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-23 03:44:56 --> Language Class Initialized
DEBUG - 2011-08-23 03:44:56 --> Loader Class Initialized
DEBUG - 2011-08-23 03:44:56 --> Controller Class Initialized
DEBUG - 2011-08-23 03:44:56 --> Model Class Initialized
DEBUG - 2011-08-23 03:44:56 --> Model Class Initialized
DEBUG - 2011-08-23 03:44:56 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-23 03:44:56 --> Database Driver Class Initialized
DEBUG - 2011-08-23 03:44:57 --> Final output sent to browser
DEBUG - 2011-08-23 03:44:57 --> Total execution time: 0.5459
DEBUG - 2011-08-23 03:44:59 --> Config Class Initialized
DEBUG - 2011-08-23 03:44:59 --> Hooks Class Initialized
DEBUG - 2011-08-23 03:44:59 --> Utf8 Class Initialized
DEBUG - 2011-08-23 03:44:59 --> UTF-8 Support Enabled
DEBUG - 2011-08-23 03:44:59 --> URI Class Initialized
DEBUG - 2011-08-23 03:44:59 --> Router Class Initialized
ERROR - 2011-08-23 03:45:00 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-23 03:45:07 --> Config Class Initialized
DEBUG - 2011-08-23 03:45:07 --> Hooks Class Initialized
DEBUG - 2011-08-23 03:45:07 --> Utf8 Class Initialized
DEBUG - 2011-08-23 03:45:07 --> UTF-8 Support Enabled
DEBUG - 2011-08-23 03:45:07 --> URI Class Initialized
DEBUG - 2011-08-23 03:45:07 --> Router Class Initialized
DEBUG - 2011-08-23 03:45:07 --> Output Class Initialized
DEBUG - 2011-08-23 03:45:07 --> Input Class Initialized
DEBUG - 2011-08-23 03:45:07 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-23 03:45:07 --> Language Class Initialized
DEBUG - 2011-08-23 03:45:07 --> Loader Class Initialized
DEBUG - 2011-08-23 03:45:07 --> Controller Class Initialized
ERROR - 2011-08-23 03:45:07 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-23 03:45:07 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-23 03:45:07 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-23 03:45:07 --> Model Class Initialized
DEBUG - 2011-08-23 03:45:07 --> Model Class Initialized
DEBUG - 2011-08-23 03:45:07 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-23 03:45:07 --> Database Driver Class Initialized
DEBUG - 2011-08-23 03:45:07 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-23 03:45:07 --> Helper loaded: url_helper
DEBUG - 2011-08-23 03:45:07 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-23 03:45:07 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-23 03:45:07 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-23 03:45:07 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-23 03:45:07 --> Final output sent to browser
DEBUG - 2011-08-23 03:45:07 --> Total execution time: 0.0813
DEBUG - 2011-08-23 03:45:10 --> Config Class Initialized
DEBUG - 2011-08-23 03:45:10 --> Hooks Class Initialized
DEBUG - 2011-08-23 03:45:10 --> Utf8 Class Initialized
DEBUG - 2011-08-23 03:45:10 --> UTF-8 Support Enabled
DEBUG - 2011-08-23 03:45:10 --> URI Class Initialized
DEBUG - 2011-08-23 03:45:10 --> Router Class Initialized
DEBUG - 2011-08-23 03:45:10 --> Output Class Initialized
DEBUG - 2011-08-23 03:45:10 --> Input Class Initialized
DEBUG - 2011-08-23 03:45:10 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-23 03:45:10 --> Language Class Initialized
DEBUG - 2011-08-23 03:45:10 --> Loader Class Initialized
DEBUG - 2011-08-23 03:45:10 --> Controller Class Initialized
DEBUG - 2011-08-23 03:45:10 --> Model Class Initialized
DEBUG - 2011-08-23 03:45:10 --> Model Class Initialized
DEBUG - 2011-08-23 03:45:10 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-23 03:45:10 --> Database Driver Class Initialized
DEBUG - 2011-08-23 03:45:11 --> Final output sent to browser
DEBUG - 2011-08-23 03:45:11 --> Total execution time: 1.7078
DEBUG - 2011-08-23 03:45:14 --> Config Class Initialized
DEBUG - 2011-08-23 03:45:14 --> Hooks Class Initialized
DEBUG - 2011-08-23 03:45:14 --> Utf8 Class Initialized
DEBUG - 2011-08-23 03:45:14 --> UTF-8 Support Enabled
DEBUG - 2011-08-23 03:45:14 --> URI Class Initialized
DEBUG - 2011-08-23 03:45:14 --> Router Class Initialized
ERROR - 2011-08-23 03:45:14 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-23 03:45:17 --> Config Class Initialized
DEBUG - 2011-08-23 03:45:17 --> Hooks Class Initialized
DEBUG - 2011-08-23 03:45:17 --> Utf8 Class Initialized
DEBUG - 2011-08-23 03:45:17 --> UTF-8 Support Enabled
DEBUG - 2011-08-23 03:45:17 --> URI Class Initialized
DEBUG - 2011-08-23 03:45:17 --> Router Class Initialized
DEBUG - 2011-08-23 03:45:17 --> Output Class Initialized
DEBUG - 2011-08-23 03:45:17 --> Input Class Initialized
DEBUG - 2011-08-23 03:45:17 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-23 03:45:17 --> Language Class Initialized
DEBUG - 2011-08-23 03:45:17 --> Loader Class Initialized
DEBUG - 2011-08-23 03:45:17 --> Controller Class Initialized
ERROR - 2011-08-23 03:45:17 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-23 03:45:17 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-23 03:45:17 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-23 03:45:17 --> Model Class Initialized
DEBUG - 2011-08-23 03:45:17 --> Model Class Initialized
DEBUG - 2011-08-23 03:45:17 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-23 03:45:17 --> Database Driver Class Initialized
DEBUG - 2011-08-23 03:45:17 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-23 03:45:17 --> Helper loaded: url_helper
DEBUG - 2011-08-23 03:45:17 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-23 03:45:17 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-23 03:45:17 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-23 03:45:17 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-23 03:45:17 --> Final output sent to browser
DEBUG - 2011-08-23 03:45:17 --> Total execution time: 0.0302
DEBUG - 2011-08-23 03:45:19 --> Config Class Initialized
DEBUG - 2011-08-23 03:45:19 --> Hooks Class Initialized
DEBUG - 2011-08-23 03:45:19 --> Utf8 Class Initialized
DEBUG - 2011-08-23 03:45:19 --> UTF-8 Support Enabled
DEBUG - 2011-08-23 03:45:19 --> URI Class Initialized
DEBUG - 2011-08-23 03:45:19 --> Router Class Initialized
DEBUG - 2011-08-23 03:45:19 --> Output Class Initialized
DEBUG - 2011-08-23 03:45:19 --> Input Class Initialized
DEBUG - 2011-08-23 03:45:19 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-23 03:45:19 --> Language Class Initialized
DEBUG - 2011-08-23 03:45:19 --> Loader Class Initialized
DEBUG - 2011-08-23 03:45:19 --> Controller Class Initialized
DEBUG - 2011-08-23 03:45:19 --> Model Class Initialized
DEBUG - 2011-08-23 03:45:19 --> Model Class Initialized
DEBUG - 2011-08-23 03:45:19 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-23 03:45:19 --> Database Driver Class Initialized
DEBUG - 2011-08-23 03:45:20 --> Final output sent to browser
DEBUG - 2011-08-23 03:45:20 --> Total execution time: 1.8860
DEBUG - 2011-08-23 03:45:26 --> Config Class Initialized
DEBUG - 2011-08-23 03:45:26 --> Hooks Class Initialized
DEBUG - 2011-08-23 03:45:26 --> Utf8 Class Initialized
DEBUG - 2011-08-23 03:45:26 --> UTF-8 Support Enabled
DEBUG - 2011-08-23 03:45:26 --> URI Class Initialized
DEBUG - 2011-08-23 03:45:26 --> Router Class Initialized
ERROR - 2011-08-23 03:45:26 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-23 03:45:26 --> Config Class Initialized
DEBUG - 2011-08-23 03:45:26 --> Hooks Class Initialized
DEBUG - 2011-08-23 03:45:26 --> Utf8 Class Initialized
DEBUG - 2011-08-23 03:45:26 --> UTF-8 Support Enabled
DEBUG - 2011-08-23 03:45:26 --> URI Class Initialized
DEBUG - 2011-08-23 03:45:26 --> Router Class Initialized
ERROR - 2011-08-23 03:45:26 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-23 03:45:39 --> Config Class Initialized
DEBUG - 2011-08-23 03:45:39 --> Hooks Class Initialized
DEBUG - 2011-08-23 03:45:39 --> Utf8 Class Initialized
DEBUG - 2011-08-23 03:45:39 --> UTF-8 Support Enabled
DEBUG - 2011-08-23 03:45:39 --> URI Class Initialized
DEBUG - 2011-08-23 03:45:39 --> Router Class Initialized
DEBUG - 2011-08-23 03:45:39 --> Output Class Initialized
DEBUG - 2011-08-23 03:45:39 --> Input Class Initialized
DEBUG - 2011-08-23 03:45:39 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-23 03:45:39 --> Language Class Initialized
DEBUG - 2011-08-23 03:45:39 --> Loader Class Initialized
DEBUG - 2011-08-23 03:45:39 --> Controller Class Initialized
ERROR - 2011-08-23 03:45:39 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-23 03:45:39 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-23 03:45:39 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-23 03:45:39 --> Model Class Initialized
DEBUG - 2011-08-23 03:45:39 --> Model Class Initialized
DEBUG - 2011-08-23 03:45:39 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-23 03:45:39 --> Database Driver Class Initialized
DEBUG - 2011-08-23 03:45:39 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-23 03:45:39 --> Helper loaded: url_helper
DEBUG - 2011-08-23 03:45:39 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-23 03:45:39 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-23 03:45:39 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-23 03:45:39 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-23 03:45:39 --> Final output sent to browser
DEBUG - 2011-08-23 03:45:39 --> Total execution time: 0.0289
DEBUG - 2011-08-23 03:45:40 --> Config Class Initialized
DEBUG - 2011-08-23 03:45:40 --> Hooks Class Initialized
DEBUG - 2011-08-23 03:45:40 --> Utf8 Class Initialized
DEBUG - 2011-08-23 03:45:40 --> UTF-8 Support Enabled
DEBUG - 2011-08-23 03:45:40 --> URI Class Initialized
DEBUG - 2011-08-23 03:45:40 --> Router Class Initialized
DEBUG - 2011-08-23 03:45:40 --> Output Class Initialized
DEBUG - 2011-08-23 03:45:40 --> Input Class Initialized
DEBUG - 2011-08-23 03:45:40 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-23 03:45:40 --> Language Class Initialized
DEBUG - 2011-08-23 03:45:40 --> Loader Class Initialized
DEBUG - 2011-08-23 03:45:40 --> Controller Class Initialized
DEBUG - 2011-08-23 03:45:40 --> Model Class Initialized
DEBUG - 2011-08-23 03:45:40 --> Model Class Initialized
DEBUG - 2011-08-23 03:45:40 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-23 03:45:40 --> Database Driver Class Initialized
DEBUG - 2011-08-23 03:45:41 --> Final output sent to browser
DEBUG - 2011-08-23 03:45:41 --> Total execution time: 1.1387
DEBUG - 2011-08-23 03:45:44 --> Config Class Initialized
DEBUG - 2011-08-23 03:45:44 --> Hooks Class Initialized
DEBUG - 2011-08-23 03:45:44 --> Utf8 Class Initialized
DEBUG - 2011-08-23 03:45:44 --> UTF-8 Support Enabled
DEBUG - 2011-08-23 03:45:44 --> URI Class Initialized
DEBUG - 2011-08-23 03:45:44 --> Router Class Initialized
ERROR - 2011-08-23 03:45:44 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-23 03:46:02 --> Config Class Initialized
DEBUG - 2011-08-23 03:46:02 --> Hooks Class Initialized
DEBUG - 2011-08-23 03:46:02 --> Utf8 Class Initialized
DEBUG - 2011-08-23 03:46:02 --> UTF-8 Support Enabled
DEBUG - 2011-08-23 03:46:02 --> URI Class Initialized
DEBUG - 2011-08-23 03:46:02 --> Router Class Initialized
DEBUG - 2011-08-23 03:46:02 --> Output Class Initialized
DEBUG - 2011-08-23 03:46:02 --> Input Class Initialized
DEBUG - 2011-08-23 03:46:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-23 03:46:02 --> Language Class Initialized
DEBUG - 2011-08-23 03:46:02 --> Loader Class Initialized
DEBUG - 2011-08-23 03:46:02 --> Controller Class Initialized
ERROR - 2011-08-23 03:46:02 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-23 03:46:02 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-23 03:46:02 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-23 03:46:02 --> Model Class Initialized
DEBUG - 2011-08-23 03:46:02 --> Model Class Initialized
DEBUG - 2011-08-23 03:46:02 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-23 03:46:02 --> Database Driver Class Initialized
DEBUG - 2011-08-23 03:46:02 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-23 03:46:02 --> Helper loaded: url_helper
DEBUG - 2011-08-23 03:46:02 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-23 03:46:02 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-23 03:46:02 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-23 03:46:02 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-23 03:46:02 --> Final output sent to browser
DEBUG - 2011-08-23 03:46:02 --> Total execution time: 0.0940
DEBUG - 2011-08-23 03:46:04 --> Config Class Initialized
DEBUG - 2011-08-23 03:46:04 --> Hooks Class Initialized
DEBUG - 2011-08-23 03:46:04 --> Utf8 Class Initialized
DEBUG - 2011-08-23 03:46:04 --> UTF-8 Support Enabled
DEBUG - 2011-08-23 03:46:04 --> URI Class Initialized
DEBUG - 2011-08-23 03:46:04 --> Router Class Initialized
DEBUG - 2011-08-23 03:46:04 --> Output Class Initialized
DEBUG - 2011-08-23 03:46:04 --> Input Class Initialized
DEBUG - 2011-08-23 03:46:04 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-23 03:46:04 --> Language Class Initialized
DEBUG - 2011-08-23 03:46:04 --> Loader Class Initialized
DEBUG - 2011-08-23 03:46:04 --> Controller Class Initialized
ERROR - 2011-08-23 03:46:04 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-23 03:46:04 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-23 03:46:04 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-23 03:46:04 --> Model Class Initialized
DEBUG - 2011-08-23 03:46:04 --> Model Class Initialized
DEBUG - 2011-08-23 03:46:04 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-23 03:46:04 --> Database Driver Class Initialized
DEBUG - 2011-08-23 03:46:04 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-23 03:46:04 --> Helper loaded: url_helper
DEBUG - 2011-08-23 03:46:04 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-23 03:46:04 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-23 03:46:04 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-23 03:46:04 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-23 03:46:04 --> Final output sent to browser
DEBUG - 2011-08-23 03:46:04 --> Total execution time: 0.0598
DEBUG - 2011-08-23 03:46:04 --> Config Class Initialized
DEBUG - 2011-08-23 03:46:04 --> Hooks Class Initialized
DEBUG - 2011-08-23 03:46:04 --> Utf8 Class Initialized
DEBUG - 2011-08-23 03:46:04 --> UTF-8 Support Enabled
DEBUG - 2011-08-23 03:46:04 --> URI Class Initialized
DEBUG - 2011-08-23 03:46:04 --> Router Class Initialized
DEBUG - 2011-08-23 03:46:04 --> Output Class Initialized
DEBUG - 2011-08-23 03:46:04 --> Input Class Initialized
DEBUG - 2011-08-23 03:46:04 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-23 03:46:04 --> Language Class Initialized
DEBUG - 2011-08-23 03:46:04 --> Loader Class Initialized
DEBUG - 2011-08-23 03:46:04 --> Controller Class Initialized
DEBUG - 2011-08-23 03:46:04 --> Model Class Initialized
DEBUG - 2011-08-23 03:46:04 --> Model Class Initialized
DEBUG - 2011-08-23 03:46:04 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-23 03:46:04 --> Database Driver Class Initialized
DEBUG - 2011-08-23 03:46:06 --> Final output sent to browser
DEBUG - 2011-08-23 03:46:06 --> Total execution time: 1.3482
DEBUG - 2011-08-23 03:46:08 --> Config Class Initialized
DEBUG - 2011-08-23 03:46:08 --> Hooks Class Initialized
DEBUG - 2011-08-23 03:46:08 --> Utf8 Class Initialized
DEBUG - 2011-08-23 03:46:08 --> UTF-8 Support Enabled
DEBUG - 2011-08-23 03:46:08 --> URI Class Initialized
DEBUG - 2011-08-23 03:46:08 --> Router Class Initialized
ERROR - 2011-08-23 03:46:08 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-23 03:46:22 --> Config Class Initialized
DEBUG - 2011-08-23 03:46:22 --> Hooks Class Initialized
DEBUG - 2011-08-23 03:46:22 --> Utf8 Class Initialized
DEBUG - 2011-08-23 03:46:22 --> UTF-8 Support Enabled
DEBUG - 2011-08-23 03:46:22 --> URI Class Initialized
DEBUG - 2011-08-23 03:46:22 --> Router Class Initialized
DEBUG - 2011-08-23 03:46:22 --> Output Class Initialized
DEBUG - 2011-08-23 03:46:22 --> Input Class Initialized
DEBUG - 2011-08-23 03:46:22 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-23 03:46:22 --> Language Class Initialized
DEBUG - 2011-08-23 03:46:22 --> Loader Class Initialized
DEBUG - 2011-08-23 03:46:22 --> Controller Class Initialized
ERROR - 2011-08-23 03:46:22 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-23 03:46:22 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-23 03:46:22 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-23 03:46:22 --> Model Class Initialized
DEBUG - 2011-08-23 03:46:22 --> Model Class Initialized
DEBUG - 2011-08-23 03:46:22 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-23 03:46:22 --> Database Driver Class Initialized
DEBUG - 2011-08-23 03:46:22 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-23 03:46:22 --> Helper loaded: url_helper
DEBUG - 2011-08-23 03:46:22 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-23 03:46:22 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-23 03:46:22 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-23 03:46:22 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-23 03:46:22 --> Final output sent to browser
DEBUG - 2011-08-23 03:46:22 --> Total execution time: 0.0316
DEBUG - 2011-08-23 03:46:23 --> Config Class Initialized
DEBUG - 2011-08-23 03:46:23 --> Hooks Class Initialized
DEBUG - 2011-08-23 03:46:23 --> Utf8 Class Initialized
DEBUG - 2011-08-23 03:46:23 --> UTF-8 Support Enabled
DEBUG - 2011-08-23 03:46:23 --> URI Class Initialized
DEBUG - 2011-08-23 03:46:23 --> Router Class Initialized
DEBUG - 2011-08-23 03:46:23 --> Output Class Initialized
DEBUG - 2011-08-23 03:46:23 --> Input Class Initialized
DEBUG - 2011-08-23 03:46:23 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-23 03:46:23 --> Language Class Initialized
DEBUG - 2011-08-23 03:46:23 --> Loader Class Initialized
DEBUG - 2011-08-23 03:46:23 --> Controller Class Initialized
DEBUG - 2011-08-23 03:46:23 --> Model Class Initialized
DEBUG - 2011-08-23 03:46:23 --> Model Class Initialized
DEBUG - 2011-08-23 03:46:23 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-23 03:46:24 --> Database Driver Class Initialized
DEBUG - 2011-08-23 03:46:24 --> Config Class Initialized
DEBUG - 2011-08-23 03:46:24 --> Hooks Class Initialized
DEBUG - 2011-08-23 03:46:24 --> Utf8 Class Initialized
DEBUG - 2011-08-23 03:46:24 --> UTF-8 Support Enabled
DEBUG - 2011-08-23 03:46:24 --> URI Class Initialized
DEBUG - 2011-08-23 03:46:24 --> Router Class Initialized
DEBUG - 2011-08-23 03:46:24 --> Output Class Initialized
DEBUG - 2011-08-23 03:46:24 --> Input Class Initialized
DEBUG - 2011-08-23 03:46:24 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-23 03:46:24 --> Language Class Initialized
DEBUG - 2011-08-23 03:46:24 --> Loader Class Initialized
DEBUG - 2011-08-23 03:46:24 --> Controller Class Initialized
ERROR - 2011-08-23 03:46:24 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-23 03:46:24 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-23 03:46:24 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-23 03:46:24 --> Model Class Initialized
DEBUG - 2011-08-23 03:46:24 --> Model Class Initialized
DEBUG - 2011-08-23 03:46:24 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-23 03:46:24 --> Database Driver Class Initialized
DEBUG - 2011-08-23 03:46:24 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-23 03:46:24 --> Helper loaded: url_helper
DEBUG - 2011-08-23 03:46:24 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-23 03:46:24 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-23 03:46:24 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-23 03:46:24 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-23 03:46:24 --> Final output sent to browser
DEBUG - 2011-08-23 03:46:24 --> Total execution time: 0.0290
DEBUG - 2011-08-23 03:46:25 --> Final output sent to browser
DEBUG - 2011-08-23 03:46:25 --> Total execution time: 1.1932
DEBUG - 2011-08-23 03:46:28 --> Config Class Initialized
DEBUG - 2011-08-23 03:46:28 --> Hooks Class Initialized
DEBUG - 2011-08-23 03:46:28 --> Utf8 Class Initialized
DEBUG - 2011-08-23 03:46:28 --> UTF-8 Support Enabled
DEBUG - 2011-08-23 03:46:28 --> URI Class Initialized
DEBUG - 2011-08-23 03:46:28 --> Router Class Initialized
ERROR - 2011-08-23 03:46:28 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-23 03:46:37 --> Config Class Initialized
DEBUG - 2011-08-23 03:46:37 --> Hooks Class Initialized
DEBUG - 2011-08-23 03:46:37 --> Utf8 Class Initialized
DEBUG - 2011-08-23 03:46:37 --> UTF-8 Support Enabled
DEBUG - 2011-08-23 03:46:37 --> URI Class Initialized
DEBUG - 2011-08-23 03:46:37 --> Router Class Initialized
DEBUG - 2011-08-23 03:46:37 --> Output Class Initialized
DEBUG - 2011-08-23 03:46:37 --> Input Class Initialized
DEBUG - 2011-08-23 03:46:37 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-23 03:46:37 --> Language Class Initialized
DEBUG - 2011-08-23 03:46:37 --> Loader Class Initialized
DEBUG - 2011-08-23 03:46:37 --> Controller Class Initialized
ERROR - 2011-08-23 03:46:37 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-23 03:46:37 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-23 03:46:37 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-23 03:46:37 --> Model Class Initialized
DEBUG - 2011-08-23 03:46:37 --> Model Class Initialized
DEBUG - 2011-08-23 03:46:37 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-23 03:46:37 --> Database Driver Class Initialized
DEBUG - 2011-08-23 03:46:37 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-23 03:46:37 --> Helper loaded: url_helper
DEBUG - 2011-08-23 03:46:37 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-23 03:46:37 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-23 03:46:37 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-23 03:46:37 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-23 03:46:37 --> Final output sent to browser
DEBUG - 2011-08-23 03:46:37 --> Total execution time: 0.0278
DEBUG - 2011-08-23 03:46:39 --> Config Class Initialized
DEBUG - 2011-08-23 03:46:39 --> Hooks Class Initialized
DEBUG - 2011-08-23 03:46:39 --> Utf8 Class Initialized
DEBUG - 2011-08-23 03:46:39 --> UTF-8 Support Enabled
DEBUG - 2011-08-23 03:46:39 --> URI Class Initialized
DEBUG - 2011-08-23 03:46:39 --> Router Class Initialized
DEBUG - 2011-08-23 03:46:39 --> Output Class Initialized
DEBUG - 2011-08-23 03:46:39 --> Input Class Initialized
DEBUG - 2011-08-23 03:46:39 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-23 03:46:39 --> Language Class Initialized
DEBUG - 2011-08-23 03:46:39 --> Loader Class Initialized
DEBUG - 2011-08-23 03:46:39 --> Controller Class Initialized
DEBUG - 2011-08-23 03:46:39 --> Model Class Initialized
DEBUG - 2011-08-23 03:46:39 --> Model Class Initialized
DEBUG - 2011-08-23 03:46:39 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-23 03:46:39 --> Database Driver Class Initialized
DEBUG - 2011-08-23 03:46:40 --> Final output sent to browser
DEBUG - 2011-08-23 03:46:40 --> Total execution time: 1.0641
DEBUG - 2011-08-23 03:46:43 --> Config Class Initialized
DEBUG - 2011-08-23 03:46:43 --> Hooks Class Initialized
DEBUG - 2011-08-23 03:46:43 --> Utf8 Class Initialized
DEBUG - 2011-08-23 03:46:43 --> UTF-8 Support Enabled
DEBUG - 2011-08-23 03:46:43 --> URI Class Initialized
DEBUG - 2011-08-23 03:46:43 --> Router Class Initialized
ERROR - 2011-08-23 03:46:43 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-23 03:46:54 --> Config Class Initialized
DEBUG - 2011-08-23 03:46:54 --> Hooks Class Initialized
DEBUG - 2011-08-23 03:46:54 --> Utf8 Class Initialized
DEBUG - 2011-08-23 03:46:54 --> UTF-8 Support Enabled
DEBUG - 2011-08-23 03:46:54 --> URI Class Initialized
DEBUG - 2011-08-23 03:46:54 --> Router Class Initialized
DEBUG - 2011-08-23 03:46:54 --> Output Class Initialized
DEBUG - 2011-08-23 03:46:54 --> Input Class Initialized
DEBUG - 2011-08-23 03:46:54 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-23 03:46:54 --> Language Class Initialized
DEBUG - 2011-08-23 03:46:54 --> Loader Class Initialized
DEBUG - 2011-08-23 03:46:54 --> Controller Class Initialized
ERROR - 2011-08-23 03:46:54 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-23 03:46:54 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-23 03:46:54 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-23 03:46:54 --> Model Class Initialized
DEBUG - 2011-08-23 03:46:54 --> Model Class Initialized
DEBUG - 2011-08-23 03:46:54 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-23 03:46:54 --> Database Driver Class Initialized
DEBUG - 2011-08-23 03:46:54 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-23 03:46:54 --> Helper loaded: url_helper
DEBUG - 2011-08-23 03:46:54 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-23 03:46:54 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-23 03:46:54 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-23 03:46:54 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-23 03:46:54 --> Final output sent to browser
DEBUG - 2011-08-23 03:46:54 --> Total execution time: 0.0663
DEBUG - 2011-08-23 03:46:56 --> Config Class Initialized
DEBUG - 2011-08-23 03:46:56 --> Hooks Class Initialized
DEBUG - 2011-08-23 03:46:56 --> Utf8 Class Initialized
DEBUG - 2011-08-23 03:46:56 --> UTF-8 Support Enabled
DEBUG - 2011-08-23 03:46:56 --> URI Class Initialized
DEBUG - 2011-08-23 03:46:56 --> Router Class Initialized
DEBUG - 2011-08-23 03:46:56 --> Output Class Initialized
DEBUG - 2011-08-23 03:46:56 --> Input Class Initialized
DEBUG - 2011-08-23 03:46:56 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-23 03:46:56 --> Language Class Initialized
DEBUG - 2011-08-23 03:46:56 --> Loader Class Initialized
DEBUG - 2011-08-23 03:46:56 --> Controller Class Initialized
DEBUG - 2011-08-23 03:46:56 --> Model Class Initialized
DEBUG - 2011-08-23 03:46:56 --> Model Class Initialized
DEBUG - 2011-08-23 03:46:56 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-23 03:46:56 --> Database Driver Class Initialized
DEBUG - 2011-08-23 03:46:57 --> Final output sent to browser
DEBUG - 2011-08-23 03:46:57 --> Total execution time: 1.3119
DEBUG - 2011-08-23 03:47:00 --> Config Class Initialized
DEBUG - 2011-08-23 03:47:00 --> Hooks Class Initialized
DEBUG - 2011-08-23 03:47:00 --> Utf8 Class Initialized
DEBUG - 2011-08-23 03:47:00 --> UTF-8 Support Enabled
DEBUG - 2011-08-23 03:47:00 --> URI Class Initialized
DEBUG - 2011-08-23 03:47:00 --> Router Class Initialized
ERROR - 2011-08-23 03:47:00 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-23 03:47:16 --> Config Class Initialized
DEBUG - 2011-08-23 03:47:16 --> Hooks Class Initialized
DEBUG - 2011-08-23 03:47:16 --> Utf8 Class Initialized
DEBUG - 2011-08-23 03:47:16 --> UTF-8 Support Enabled
DEBUG - 2011-08-23 03:47:16 --> URI Class Initialized
DEBUG - 2011-08-23 03:47:16 --> Router Class Initialized
DEBUG - 2011-08-23 03:47:16 --> Output Class Initialized
DEBUG - 2011-08-23 03:47:16 --> Input Class Initialized
DEBUG - 2011-08-23 03:47:16 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-23 03:47:16 --> Language Class Initialized
DEBUG - 2011-08-23 03:47:16 --> Loader Class Initialized
DEBUG - 2011-08-23 03:47:16 --> Controller Class Initialized
ERROR - 2011-08-23 03:47:16 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-23 03:47:16 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-23 03:47:16 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-23 03:47:16 --> Model Class Initialized
DEBUG - 2011-08-23 03:47:16 --> Model Class Initialized
DEBUG - 2011-08-23 03:47:16 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-23 03:47:16 --> Database Driver Class Initialized
DEBUG - 2011-08-23 03:47:16 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-23 03:47:16 --> Helper loaded: url_helper
DEBUG - 2011-08-23 03:47:16 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-23 03:47:16 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-23 03:47:16 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-23 03:47:16 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-23 03:47:16 --> Final output sent to browser
DEBUG - 2011-08-23 03:47:16 --> Total execution time: 0.0364
DEBUG - 2011-08-23 03:47:17 --> Config Class Initialized
DEBUG - 2011-08-23 03:47:17 --> Hooks Class Initialized
DEBUG - 2011-08-23 03:47:17 --> Utf8 Class Initialized
DEBUG - 2011-08-23 03:47:17 --> UTF-8 Support Enabled
DEBUG - 2011-08-23 03:47:17 --> URI Class Initialized
DEBUG - 2011-08-23 03:47:17 --> Router Class Initialized
DEBUG - 2011-08-23 03:47:17 --> Output Class Initialized
DEBUG - 2011-08-23 03:47:17 --> Input Class Initialized
DEBUG - 2011-08-23 03:47:17 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-23 03:47:17 --> Language Class Initialized
DEBUG - 2011-08-23 03:47:17 --> Loader Class Initialized
DEBUG - 2011-08-23 03:47:17 --> Controller Class Initialized
DEBUG - 2011-08-23 03:47:17 --> Model Class Initialized
DEBUG - 2011-08-23 03:47:17 --> Model Class Initialized
DEBUG - 2011-08-23 03:47:17 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-23 03:47:17 --> Database Driver Class Initialized
DEBUG - 2011-08-23 03:47:19 --> Config Class Initialized
DEBUG - 2011-08-23 03:47:19 --> Hooks Class Initialized
DEBUG - 2011-08-23 03:47:19 --> Utf8 Class Initialized
DEBUG - 2011-08-23 03:47:19 --> UTF-8 Support Enabled
DEBUG - 2011-08-23 03:47:19 --> URI Class Initialized
DEBUG - 2011-08-23 03:47:19 --> Router Class Initialized
DEBUG - 2011-08-23 03:47:19 --> Output Class Initialized
DEBUG - 2011-08-23 03:47:19 --> Input Class Initialized
DEBUG - 2011-08-23 03:47:19 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-23 03:47:19 --> Language Class Initialized
DEBUG - 2011-08-23 03:47:19 --> Loader Class Initialized
DEBUG - 2011-08-23 03:47:19 --> Controller Class Initialized
ERROR - 2011-08-23 03:47:19 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-23 03:47:19 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-23 03:47:19 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-23 03:47:19 --> Model Class Initialized
DEBUG - 2011-08-23 03:47:19 --> Model Class Initialized
DEBUG - 2011-08-23 03:47:19 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-23 03:47:19 --> Database Driver Class Initialized
DEBUG - 2011-08-23 03:47:19 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-23 03:47:19 --> Helper loaded: url_helper
DEBUG - 2011-08-23 03:47:19 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-23 03:47:19 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-23 03:47:19 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-23 03:47:19 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-23 03:47:19 --> Final output sent to browser
DEBUG - 2011-08-23 03:47:19 --> Total execution time: 0.0569
DEBUG - 2011-08-23 03:47:20 --> Final output sent to browser
DEBUG - 2011-08-23 03:47:20 --> Total execution time: 2.3199
DEBUG - 2011-08-23 03:47:22 --> Config Class Initialized
DEBUG - 2011-08-23 03:47:22 --> Hooks Class Initialized
DEBUG - 2011-08-23 03:47:22 --> Utf8 Class Initialized
DEBUG - 2011-08-23 03:47:22 --> UTF-8 Support Enabled
DEBUG - 2011-08-23 03:47:22 --> URI Class Initialized
DEBUG - 2011-08-23 03:47:22 --> Router Class Initialized
ERROR - 2011-08-23 03:47:22 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-23 03:47:25 --> Config Class Initialized
DEBUG - 2011-08-23 03:47:25 --> Hooks Class Initialized
DEBUG - 2011-08-23 03:47:25 --> Utf8 Class Initialized
DEBUG - 2011-08-23 03:47:25 --> UTF-8 Support Enabled
DEBUG - 2011-08-23 03:47:25 --> URI Class Initialized
DEBUG - 2011-08-23 03:47:25 --> Router Class Initialized
DEBUG - 2011-08-23 03:47:25 --> Output Class Initialized
DEBUG - 2011-08-23 03:47:25 --> Input Class Initialized
DEBUG - 2011-08-23 03:47:25 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-23 03:47:25 --> Language Class Initialized
DEBUG - 2011-08-23 03:47:25 --> Loader Class Initialized
DEBUG - 2011-08-23 03:47:25 --> Controller Class Initialized
ERROR - 2011-08-23 03:47:25 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-23 03:47:25 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-23 03:47:25 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-23 03:47:25 --> Model Class Initialized
DEBUG - 2011-08-23 03:47:25 --> Model Class Initialized
DEBUG - 2011-08-23 03:47:25 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-23 03:47:25 --> Database Driver Class Initialized
DEBUG - 2011-08-23 03:47:25 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-23 03:47:25 --> Helper loaded: url_helper
DEBUG - 2011-08-23 03:47:25 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-23 03:47:25 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-23 03:47:25 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-23 03:47:25 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-23 03:47:25 --> Final output sent to browser
DEBUG - 2011-08-23 03:47:25 --> Total execution time: 0.0286
DEBUG - 2011-08-23 03:47:26 --> Config Class Initialized
DEBUG - 2011-08-23 03:47:26 --> Hooks Class Initialized
DEBUG - 2011-08-23 03:47:26 --> Utf8 Class Initialized
DEBUG - 2011-08-23 03:47:26 --> UTF-8 Support Enabled
DEBUG - 2011-08-23 03:47:26 --> URI Class Initialized
DEBUG - 2011-08-23 03:47:26 --> Router Class Initialized
DEBUG - 2011-08-23 03:47:26 --> Output Class Initialized
DEBUG - 2011-08-23 03:47:26 --> Input Class Initialized
DEBUG - 2011-08-23 03:47:26 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-23 03:47:26 --> Language Class Initialized
DEBUG - 2011-08-23 03:47:26 --> Loader Class Initialized
DEBUG - 2011-08-23 03:47:26 --> Controller Class Initialized
DEBUG - 2011-08-23 03:47:26 --> Model Class Initialized
DEBUG - 2011-08-23 03:47:26 --> Model Class Initialized
DEBUG - 2011-08-23 03:47:26 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-23 03:47:26 --> Database Driver Class Initialized
DEBUG - 2011-08-23 03:47:27 --> Final output sent to browser
DEBUG - 2011-08-23 03:47:27 --> Total execution time: 1.4564
DEBUG - 2011-08-23 03:47:30 --> Config Class Initialized
DEBUG - 2011-08-23 03:47:30 --> Hooks Class Initialized
DEBUG - 2011-08-23 03:47:30 --> Utf8 Class Initialized
DEBUG - 2011-08-23 03:47:30 --> UTF-8 Support Enabled
DEBUG - 2011-08-23 03:47:30 --> URI Class Initialized
DEBUG - 2011-08-23 03:47:30 --> Router Class Initialized
ERROR - 2011-08-23 03:47:30 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-23 03:47:41 --> Config Class Initialized
DEBUG - 2011-08-23 03:47:41 --> Hooks Class Initialized
DEBUG - 2011-08-23 03:47:41 --> Utf8 Class Initialized
DEBUG - 2011-08-23 03:47:41 --> UTF-8 Support Enabled
DEBUG - 2011-08-23 03:47:41 --> URI Class Initialized
DEBUG - 2011-08-23 03:47:41 --> Router Class Initialized
DEBUG - 2011-08-23 03:47:41 --> Output Class Initialized
DEBUG - 2011-08-23 03:47:41 --> Input Class Initialized
DEBUG - 2011-08-23 03:47:41 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-23 03:47:41 --> Language Class Initialized
DEBUG - 2011-08-23 03:47:41 --> Loader Class Initialized
DEBUG - 2011-08-23 03:47:41 --> Controller Class Initialized
ERROR - 2011-08-23 03:47:41 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-23 03:47:41 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-23 03:47:41 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-23 03:47:41 --> Model Class Initialized
DEBUG - 2011-08-23 03:47:41 --> Model Class Initialized
DEBUG - 2011-08-23 03:47:41 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-23 03:47:41 --> Database Driver Class Initialized
DEBUG - 2011-08-23 03:47:41 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-23 03:47:41 --> Helper loaded: url_helper
DEBUG - 2011-08-23 03:47:41 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-23 03:47:41 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-23 03:47:41 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-23 03:47:41 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-23 03:47:41 --> Final output sent to browser
DEBUG - 2011-08-23 03:47:41 --> Total execution time: 0.0351
DEBUG - 2011-08-23 03:47:42 --> Config Class Initialized
DEBUG - 2011-08-23 03:47:42 --> Hooks Class Initialized
DEBUG - 2011-08-23 03:47:42 --> Utf8 Class Initialized
DEBUG - 2011-08-23 03:47:42 --> UTF-8 Support Enabled
DEBUG - 2011-08-23 03:47:42 --> URI Class Initialized
DEBUG - 2011-08-23 03:47:42 --> Router Class Initialized
DEBUG - 2011-08-23 03:47:42 --> Output Class Initialized
DEBUG - 2011-08-23 03:47:42 --> Input Class Initialized
DEBUG - 2011-08-23 03:47:42 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-23 03:47:42 --> Language Class Initialized
DEBUG - 2011-08-23 03:47:42 --> Loader Class Initialized
DEBUG - 2011-08-23 03:47:42 --> Controller Class Initialized
DEBUG - 2011-08-23 03:47:42 --> Model Class Initialized
DEBUG - 2011-08-23 03:47:42 --> Model Class Initialized
DEBUG - 2011-08-23 03:47:42 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-23 03:47:42 --> Database Driver Class Initialized
DEBUG - 2011-08-23 03:47:43 --> Final output sent to browser
DEBUG - 2011-08-23 03:47:43 --> Total execution time: 1.3021
DEBUG - 2011-08-23 03:47:45 --> Config Class Initialized
DEBUG - 2011-08-23 03:47:45 --> Hooks Class Initialized
DEBUG - 2011-08-23 03:47:45 --> Utf8 Class Initialized
DEBUG - 2011-08-23 03:47:45 --> UTF-8 Support Enabled
DEBUG - 2011-08-23 03:47:45 --> URI Class Initialized
DEBUG - 2011-08-23 03:47:45 --> Router Class Initialized
DEBUG - 2011-08-23 03:47:45 --> Output Class Initialized
DEBUG - 2011-08-23 03:47:45 --> Input Class Initialized
DEBUG - 2011-08-23 03:47:45 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-23 03:47:45 --> Language Class Initialized
DEBUG - 2011-08-23 03:47:45 --> Loader Class Initialized
DEBUG - 2011-08-23 03:47:45 --> Controller Class Initialized
ERROR - 2011-08-23 03:47:45 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-23 03:47:45 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-23 03:47:45 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-23 03:47:45 --> Model Class Initialized
DEBUG - 2011-08-23 03:47:45 --> Model Class Initialized
DEBUG - 2011-08-23 03:47:45 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-23 03:47:45 --> Database Driver Class Initialized
DEBUG - 2011-08-23 03:47:45 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-23 03:47:45 --> Helper loaded: url_helper
DEBUG - 2011-08-23 03:47:45 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-23 03:47:45 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-23 03:47:45 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-23 03:47:45 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-23 03:47:45 --> Final output sent to browser
DEBUG - 2011-08-23 03:47:45 --> Total execution time: 0.0279
DEBUG - 2011-08-23 03:47:47 --> Config Class Initialized
DEBUG - 2011-08-23 03:47:47 --> Hooks Class Initialized
DEBUG - 2011-08-23 03:47:47 --> Utf8 Class Initialized
DEBUG - 2011-08-23 03:47:47 --> UTF-8 Support Enabled
DEBUG - 2011-08-23 03:47:47 --> URI Class Initialized
DEBUG - 2011-08-23 03:47:47 --> Router Class Initialized
ERROR - 2011-08-23 03:47:47 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-23 03:47:54 --> Config Class Initialized
DEBUG - 2011-08-23 03:47:54 --> Hooks Class Initialized
DEBUG - 2011-08-23 03:47:54 --> Utf8 Class Initialized
DEBUG - 2011-08-23 03:47:54 --> UTF-8 Support Enabled
DEBUG - 2011-08-23 03:47:54 --> URI Class Initialized
DEBUG - 2011-08-23 03:47:54 --> Router Class Initialized
DEBUG - 2011-08-23 03:47:54 --> Output Class Initialized
DEBUG - 2011-08-23 03:47:54 --> Input Class Initialized
DEBUG - 2011-08-23 03:47:54 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-23 03:47:54 --> Language Class Initialized
DEBUG - 2011-08-23 03:47:54 --> Loader Class Initialized
DEBUG - 2011-08-23 03:47:54 --> Controller Class Initialized
ERROR - 2011-08-23 03:47:54 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-23 03:47:54 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-23 03:47:54 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-23 03:47:54 --> Model Class Initialized
DEBUG - 2011-08-23 03:47:54 --> Model Class Initialized
DEBUG - 2011-08-23 03:47:54 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-23 03:47:54 --> Database Driver Class Initialized
DEBUG - 2011-08-23 03:47:54 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-23 03:47:54 --> Helper loaded: url_helper
DEBUG - 2011-08-23 03:47:54 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-23 03:47:54 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-23 03:47:54 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-23 03:47:54 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-23 03:47:54 --> Final output sent to browser
DEBUG - 2011-08-23 03:47:54 --> Total execution time: 0.0337
DEBUG - 2011-08-23 03:47:55 --> Config Class Initialized
DEBUG - 2011-08-23 03:47:55 --> Hooks Class Initialized
DEBUG - 2011-08-23 03:47:55 --> Utf8 Class Initialized
DEBUG - 2011-08-23 03:47:55 --> UTF-8 Support Enabled
DEBUG - 2011-08-23 03:47:55 --> URI Class Initialized
DEBUG - 2011-08-23 03:47:55 --> Router Class Initialized
DEBUG - 2011-08-23 03:47:55 --> Output Class Initialized
DEBUG - 2011-08-23 03:47:55 --> Input Class Initialized
DEBUG - 2011-08-23 03:47:55 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-23 03:47:55 --> Language Class Initialized
DEBUG - 2011-08-23 03:47:55 --> Loader Class Initialized
DEBUG - 2011-08-23 03:47:55 --> Controller Class Initialized
DEBUG - 2011-08-23 03:47:55 --> Model Class Initialized
DEBUG - 2011-08-23 03:47:55 --> Model Class Initialized
DEBUG - 2011-08-23 03:47:55 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-23 03:47:55 --> Database Driver Class Initialized
DEBUG - 2011-08-23 03:47:56 --> Final output sent to browser
DEBUG - 2011-08-23 03:47:56 --> Total execution time: 0.6172
DEBUG - 2011-08-23 03:47:58 --> Config Class Initialized
DEBUG - 2011-08-23 03:47:58 --> Hooks Class Initialized
DEBUG - 2011-08-23 03:47:58 --> Utf8 Class Initialized
DEBUG - 2011-08-23 03:47:58 --> UTF-8 Support Enabled
DEBUG - 2011-08-23 03:47:58 --> URI Class Initialized
DEBUG - 2011-08-23 03:47:58 --> Router Class Initialized
ERROR - 2011-08-23 03:47:58 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-23 03:48:08 --> Config Class Initialized
DEBUG - 2011-08-23 03:48:08 --> Hooks Class Initialized
DEBUG - 2011-08-23 03:48:08 --> Utf8 Class Initialized
DEBUG - 2011-08-23 03:48:08 --> UTF-8 Support Enabled
DEBUG - 2011-08-23 03:48:08 --> URI Class Initialized
DEBUG - 2011-08-23 03:48:08 --> Router Class Initialized
DEBUG - 2011-08-23 03:48:08 --> Output Class Initialized
DEBUG - 2011-08-23 03:48:08 --> Input Class Initialized
DEBUG - 2011-08-23 03:48:08 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-23 03:48:08 --> Language Class Initialized
DEBUG - 2011-08-23 03:48:08 --> Loader Class Initialized
DEBUG - 2011-08-23 03:48:08 --> Controller Class Initialized
ERROR - 2011-08-23 03:48:08 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-23 03:48:08 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-23 03:48:08 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-23 03:48:08 --> Model Class Initialized
DEBUG - 2011-08-23 03:48:08 --> Model Class Initialized
DEBUG - 2011-08-23 03:48:08 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-23 03:48:08 --> Database Driver Class Initialized
DEBUG - 2011-08-23 03:48:08 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-23 03:48:08 --> Helper loaded: url_helper
DEBUG - 2011-08-23 03:48:08 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-23 03:48:08 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-23 03:48:08 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-23 03:48:08 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-23 03:48:08 --> Final output sent to browser
DEBUG - 2011-08-23 03:48:08 --> Total execution time: 0.0274
DEBUG - 2011-08-23 03:48:09 --> Config Class Initialized
DEBUG - 2011-08-23 03:48:09 --> Hooks Class Initialized
DEBUG - 2011-08-23 03:48:09 --> Utf8 Class Initialized
DEBUG - 2011-08-23 03:48:09 --> UTF-8 Support Enabled
DEBUG - 2011-08-23 03:48:09 --> URI Class Initialized
DEBUG - 2011-08-23 03:48:09 --> Router Class Initialized
DEBUG - 2011-08-23 03:48:09 --> Output Class Initialized
DEBUG - 2011-08-23 03:48:09 --> Input Class Initialized
DEBUG - 2011-08-23 03:48:09 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-23 03:48:09 --> Language Class Initialized
DEBUG - 2011-08-23 03:48:09 --> Loader Class Initialized
DEBUG - 2011-08-23 03:48:09 --> Controller Class Initialized
DEBUG - 2011-08-23 03:48:09 --> Model Class Initialized
DEBUG - 2011-08-23 03:48:09 --> Model Class Initialized
DEBUG - 2011-08-23 03:48:09 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-23 03:48:09 --> Database Driver Class Initialized
DEBUG - 2011-08-23 03:48:10 --> Final output sent to browser
DEBUG - 2011-08-23 03:48:10 --> Total execution time: 1.1467
DEBUG - 2011-08-23 03:48:15 --> Config Class Initialized
DEBUG - 2011-08-23 03:48:15 --> Hooks Class Initialized
DEBUG - 2011-08-23 03:48:15 --> Utf8 Class Initialized
DEBUG - 2011-08-23 03:48:15 --> UTF-8 Support Enabled
DEBUG - 2011-08-23 03:48:15 --> URI Class Initialized
DEBUG - 2011-08-23 03:48:15 --> Router Class Initialized
ERROR - 2011-08-23 03:48:15 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-23 03:48:16 --> Config Class Initialized
DEBUG - 2011-08-23 03:48:16 --> Hooks Class Initialized
DEBUG - 2011-08-23 03:48:16 --> Utf8 Class Initialized
DEBUG - 2011-08-23 03:48:16 --> UTF-8 Support Enabled
DEBUG - 2011-08-23 03:48:16 --> URI Class Initialized
DEBUG - 2011-08-23 03:48:16 --> Router Class Initialized
DEBUG - 2011-08-23 03:48:16 --> Output Class Initialized
DEBUG - 2011-08-23 03:48:16 --> Input Class Initialized
DEBUG - 2011-08-23 03:48:16 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-23 03:48:16 --> Language Class Initialized
DEBUG - 2011-08-23 03:48:16 --> Loader Class Initialized
DEBUG - 2011-08-23 03:48:16 --> Controller Class Initialized
ERROR - 2011-08-23 03:48:16 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-23 03:48:16 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-23 03:48:16 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-23 03:48:16 --> Model Class Initialized
DEBUG - 2011-08-23 03:48:16 --> Model Class Initialized
DEBUG - 2011-08-23 03:48:16 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-23 03:48:16 --> Database Driver Class Initialized
DEBUG - 2011-08-23 03:48:16 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-23 03:48:16 --> Helper loaded: url_helper
DEBUG - 2011-08-23 03:48:16 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-23 03:48:16 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-23 03:48:16 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-23 03:48:16 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-23 03:48:16 --> Final output sent to browser
DEBUG - 2011-08-23 03:48:16 --> Total execution time: 0.1040
DEBUG - 2011-08-23 03:48:20 --> Config Class Initialized
DEBUG - 2011-08-23 03:48:20 --> Hooks Class Initialized
DEBUG - 2011-08-23 03:48:20 --> Utf8 Class Initialized
DEBUG - 2011-08-23 03:48:20 --> UTF-8 Support Enabled
DEBUG - 2011-08-23 03:48:20 --> URI Class Initialized
DEBUG - 2011-08-23 03:48:20 --> Router Class Initialized
DEBUG - 2011-08-23 03:48:20 --> Output Class Initialized
DEBUG - 2011-08-23 03:48:20 --> Input Class Initialized
DEBUG - 2011-08-23 03:48:20 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-23 03:48:20 --> Language Class Initialized
DEBUG - 2011-08-23 03:48:20 --> Loader Class Initialized
DEBUG - 2011-08-23 03:48:20 --> Controller Class Initialized
ERROR - 2011-08-23 03:48:20 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-23 03:48:20 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-23 03:48:20 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-23 03:48:20 --> Model Class Initialized
DEBUG - 2011-08-23 03:48:20 --> Model Class Initialized
DEBUG - 2011-08-23 03:48:20 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-23 03:48:20 --> Database Driver Class Initialized
DEBUG - 2011-08-23 03:48:20 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-23 03:48:20 --> Helper loaded: url_helper
DEBUG - 2011-08-23 03:48:20 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-23 03:48:20 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-23 03:48:20 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-23 03:48:20 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-23 03:48:20 --> Final output sent to browser
DEBUG - 2011-08-23 03:48:20 --> Total execution time: 0.0334
DEBUG - 2011-08-23 03:48:21 --> Config Class Initialized
DEBUG - 2011-08-23 03:48:21 --> Hooks Class Initialized
DEBUG - 2011-08-23 03:48:21 --> Utf8 Class Initialized
DEBUG - 2011-08-23 03:48:21 --> UTF-8 Support Enabled
DEBUG - 2011-08-23 03:48:21 --> URI Class Initialized
DEBUG - 2011-08-23 03:48:21 --> Router Class Initialized
DEBUG - 2011-08-23 03:48:21 --> Output Class Initialized
DEBUG - 2011-08-23 03:48:21 --> Input Class Initialized
DEBUG - 2011-08-23 03:48:21 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-23 03:48:21 --> Language Class Initialized
DEBUG - 2011-08-23 03:48:21 --> Loader Class Initialized
DEBUG - 2011-08-23 03:48:21 --> Controller Class Initialized
DEBUG - 2011-08-23 03:48:21 --> Model Class Initialized
DEBUG - 2011-08-23 03:48:21 --> Model Class Initialized
DEBUG - 2011-08-23 03:48:21 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-23 03:48:21 --> Database Driver Class Initialized
DEBUG - 2011-08-23 03:48:23 --> Final output sent to browser
DEBUG - 2011-08-23 03:48:23 --> Total execution time: 1.4300
DEBUG - 2011-08-23 03:48:26 --> Config Class Initialized
DEBUG - 2011-08-23 03:48:26 --> Hooks Class Initialized
DEBUG - 2011-08-23 03:48:26 --> Utf8 Class Initialized
DEBUG - 2011-08-23 03:48:26 --> UTF-8 Support Enabled
DEBUG - 2011-08-23 03:48:26 --> URI Class Initialized
DEBUG - 2011-08-23 03:48:26 --> Router Class Initialized
ERROR - 2011-08-23 03:48:26 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-23 03:48:41 --> Config Class Initialized
DEBUG - 2011-08-23 03:48:41 --> Hooks Class Initialized
DEBUG - 2011-08-23 03:48:41 --> Utf8 Class Initialized
DEBUG - 2011-08-23 03:48:41 --> UTF-8 Support Enabled
DEBUG - 2011-08-23 03:48:42 --> URI Class Initialized
DEBUG - 2011-08-23 03:48:42 --> Router Class Initialized
DEBUG - 2011-08-23 03:48:42 --> Output Class Initialized
DEBUG - 2011-08-23 03:48:42 --> Input Class Initialized
DEBUG - 2011-08-23 03:48:42 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-23 03:48:42 --> Language Class Initialized
DEBUG - 2011-08-23 03:48:42 --> Loader Class Initialized
DEBUG - 2011-08-23 03:48:42 --> Controller Class Initialized
ERROR - 2011-08-23 03:48:42 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-23 03:48:42 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-23 03:48:42 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-23 03:48:42 --> Model Class Initialized
DEBUG - 2011-08-23 03:48:42 --> Model Class Initialized
DEBUG - 2011-08-23 03:48:42 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-23 03:48:42 --> Database Driver Class Initialized
DEBUG - 2011-08-23 03:48:42 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-23 03:48:42 --> Helper loaded: url_helper
DEBUG - 2011-08-23 03:48:42 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-23 03:48:42 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-23 03:48:42 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-23 03:48:42 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-23 03:48:42 --> Final output sent to browser
DEBUG - 2011-08-23 03:48:42 --> Total execution time: 0.0499
DEBUG - 2011-08-23 03:48:43 --> Config Class Initialized
DEBUG - 2011-08-23 03:48:43 --> Hooks Class Initialized
DEBUG - 2011-08-23 03:48:43 --> Utf8 Class Initialized
DEBUG - 2011-08-23 03:48:43 --> UTF-8 Support Enabled
DEBUG - 2011-08-23 03:48:43 --> URI Class Initialized
DEBUG - 2011-08-23 03:48:43 --> Router Class Initialized
DEBUG - 2011-08-23 03:48:43 --> Output Class Initialized
DEBUG - 2011-08-23 03:48:43 --> Input Class Initialized
DEBUG - 2011-08-23 03:48:43 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-23 03:48:43 --> Language Class Initialized
DEBUG - 2011-08-23 03:48:43 --> Loader Class Initialized
DEBUG - 2011-08-23 03:48:43 --> Controller Class Initialized
DEBUG - 2011-08-23 03:48:43 --> Model Class Initialized
DEBUG - 2011-08-23 03:48:43 --> Model Class Initialized
DEBUG - 2011-08-23 03:48:43 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-23 03:48:43 --> Database Driver Class Initialized
DEBUG - 2011-08-23 03:48:44 --> Final output sent to browser
DEBUG - 2011-08-23 03:48:44 --> Total execution time: 0.7877
DEBUG - 2011-08-23 03:48:48 --> Config Class Initialized
DEBUG - 2011-08-23 03:48:48 --> Hooks Class Initialized
DEBUG - 2011-08-23 03:48:48 --> Utf8 Class Initialized
DEBUG - 2011-08-23 03:48:48 --> UTF-8 Support Enabled
DEBUG - 2011-08-23 03:48:48 --> URI Class Initialized
DEBUG - 2011-08-23 03:48:48 --> Router Class Initialized
ERROR - 2011-08-23 03:48:48 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-23 03:48:58 --> Config Class Initialized
DEBUG - 2011-08-23 03:48:58 --> Hooks Class Initialized
DEBUG - 2011-08-23 03:48:58 --> Utf8 Class Initialized
DEBUG - 2011-08-23 03:48:58 --> UTF-8 Support Enabled
DEBUG - 2011-08-23 03:48:58 --> URI Class Initialized
DEBUG - 2011-08-23 03:48:58 --> Router Class Initialized
DEBUG - 2011-08-23 03:48:58 --> Output Class Initialized
DEBUG - 2011-08-23 03:48:58 --> Input Class Initialized
DEBUG - 2011-08-23 03:48:58 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-23 03:48:58 --> Language Class Initialized
DEBUG - 2011-08-23 03:48:58 --> Loader Class Initialized
DEBUG - 2011-08-23 03:48:58 --> Controller Class Initialized
ERROR - 2011-08-23 03:48:58 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-23 03:48:58 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-23 03:48:58 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-23 03:48:58 --> Model Class Initialized
DEBUG - 2011-08-23 03:48:58 --> Model Class Initialized
DEBUG - 2011-08-23 03:48:58 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-23 03:48:58 --> Database Driver Class Initialized
DEBUG - 2011-08-23 03:48:58 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-23 03:48:58 --> Helper loaded: url_helper
DEBUG - 2011-08-23 03:48:58 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-23 03:48:58 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-23 03:48:58 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-23 03:48:58 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-23 03:48:58 --> Final output sent to browser
DEBUG - 2011-08-23 03:48:58 --> Total execution time: 0.0335
DEBUG - 2011-08-23 03:49:00 --> Config Class Initialized
DEBUG - 2011-08-23 03:49:00 --> Hooks Class Initialized
DEBUG - 2011-08-23 03:49:00 --> Utf8 Class Initialized
DEBUG - 2011-08-23 03:49:00 --> UTF-8 Support Enabled
DEBUG - 2011-08-23 03:49:00 --> URI Class Initialized
DEBUG - 2011-08-23 03:49:00 --> Router Class Initialized
DEBUG - 2011-08-23 03:49:00 --> Output Class Initialized
DEBUG - 2011-08-23 03:49:00 --> Input Class Initialized
DEBUG - 2011-08-23 03:49:00 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-23 03:49:00 --> Language Class Initialized
DEBUG - 2011-08-23 03:49:00 --> Loader Class Initialized
DEBUG - 2011-08-23 03:49:00 --> Controller Class Initialized
DEBUG - 2011-08-23 03:49:00 --> Model Class Initialized
DEBUG - 2011-08-23 03:49:00 --> Model Class Initialized
DEBUG - 2011-08-23 03:49:00 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-23 03:49:00 --> Database Driver Class Initialized
DEBUG - 2011-08-23 03:49:01 --> Final output sent to browser
DEBUG - 2011-08-23 03:49:01 --> Total execution time: 1.1112
DEBUG - 2011-08-23 03:49:04 --> Config Class Initialized
DEBUG - 2011-08-23 03:49:04 --> Hooks Class Initialized
DEBUG - 2011-08-23 03:49:04 --> Utf8 Class Initialized
DEBUG - 2011-08-23 03:49:04 --> UTF-8 Support Enabled
DEBUG - 2011-08-23 03:49:04 --> URI Class Initialized
DEBUG - 2011-08-23 03:49:04 --> Router Class Initialized
ERROR - 2011-08-23 03:49:04 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-23 03:49:28 --> Config Class Initialized
DEBUG - 2011-08-23 03:49:28 --> Hooks Class Initialized
DEBUG - 2011-08-23 03:49:28 --> Utf8 Class Initialized
DEBUG - 2011-08-23 03:49:28 --> UTF-8 Support Enabled
DEBUG - 2011-08-23 03:49:28 --> URI Class Initialized
DEBUG - 2011-08-23 03:49:28 --> Router Class Initialized
DEBUG - 2011-08-23 03:49:28 --> Output Class Initialized
DEBUG - 2011-08-23 03:49:28 --> Input Class Initialized
DEBUG - 2011-08-23 03:49:28 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-23 03:49:28 --> Language Class Initialized
DEBUG - 2011-08-23 03:49:28 --> Loader Class Initialized
DEBUG - 2011-08-23 03:49:28 --> Controller Class Initialized
ERROR - 2011-08-23 03:49:28 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-23 03:49:28 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-23 03:49:28 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-23 03:49:28 --> Model Class Initialized
DEBUG - 2011-08-23 03:49:28 --> Model Class Initialized
DEBUG - 2011-08-23 03:49:28 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-23 03:49:28 --> Database Driver Class Initialized
DEBUG - 2011-08-23 03:49:28 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-23 03:49:28 --> Helper loaded: url_helper
DEBUG - 2011-08-23 03:49:28 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-23 03:49:28 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-23 03:49:28 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-23 03:49:28 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-23 03:49:28 --> Final output sent to browser
DEBUG - 2011-08-23 03:49:28 --> Total execution time: 0.0376
DEBUG - 2011-08-23 03:49:41 --> Config Class Initialized
DEBUG - 2011-08-23 03:49:41 --> Hooks Class Initialized
DEBUG - 2011-08-23 03:49:41 --> Utf8 Class Initialized
DEBUG - 2011-08-23 03:49:41 --> UTF-8 Support Enabled
DEBUG - 2011-08-23 03:49:41 --> URI Class Initialized
DEBUG - 2011-08-23 03:49:41 --> Router Class Initialized
DEBUG - 2011-08-23 03:49:41 --> Output Class Initialized
DEBUG - 2011-08-23 03:49:41 --> Input Class Initialized
DEBUG - 2011-08-23 03:49:41 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-23 03:49:41 --> Language Class Initialized
DEBUG - 2011-08-23 03:49:41 --> Loader Class Initialized
DEBUG - 2011-08-23 03:49:41 --> Controller Class Initialized
ERROR - 2011-08-23 03:49:41 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-23 03:49:41 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-23 03:49:41 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-23 03:49:41 --> Model Class Initialized
DEBUG - 2011-08-23 03:49:41 --> Model Class Initialized
DEBUG - 2011-08-23 03:49:41 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-23 03:49:42 --> Database Driver Class Initialized
DEBUG - 2011-08-23 03:49:42 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-23 03:49:42 --> Helper loaded: url_helper
DEBUG - 2011-08-23 03:49:42 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-23 03:49:42 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-23 03:49:42 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-23 03:49:42 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-23 03:49:42 --> Final output sent to browser
DEBUG - 2011-08-23 03:49:42 --> Total execution time: 0.1218
DEBUG - 2011-08-23 03:49:44 --> Config Class Initialized
DEBUG - 2011-08-23 03:49:44 --> Hooks Class Initialized
DEBUG - 2011-08-23 03:49:44 --> Utf8 Class Initialized
DEBUG - 2011-08-23 03:49:44 --> UTF-8 Support Enabled
DEBUG - 2011-08-23 03:49:44 --> URI Class Initialized
DEBUG - 2011-08-23 03:49:44 --> Router Class Initialized
DEBUG - 2011-08-23 03:49:44 --> Output Class Initialized
DEBUG - 2011-08-23 03:49:44 --> Input Class Initialized
DEBUG - 2011-08-23 03:49:44 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-23 03:49:44 --> Language Class Initialized
DEBUG - 2011-08-23 03:49:44 --> Loader Class Initialized
DEBUG - 2011-08-23 03:49:44 --> Controller Class Initialized
DEBUG - 2011-08-23 03:49:44 --> Model Class Initialized
DEBUG - 2011-08-23 03:49:44 --> Model Class Initialized
DEBUG - 2011-08-23 03:49:44 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-23 03:49:44 --> Database Driver Class Initialized
DEBUG - 2011-08-23 03:49:45 --> Final output sent to browser
DEBUG - 2011-08-23 03:49:45 --> Total execution time: 1.6887
DEBUG - 2011-08-23 03:49:48 --> Config Class Initialized
DEBUG - 2011-08-23 03:49:48 --> Hooks Class Initialized
DEBUG - 2011-08-23 03:49:48 --> Utf8 Class Initialized
DEBUG - 2011-08-23 03:49:48 --> UTF-8 Support Enabled
DEBUG - 2011-08-23 03:49:48 --> URI Class Initialized
DEBUG - 2011-08-23 03:49:48 --> Router Class Initialized
ERROR - 2011-08-23 03:49:48 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-23 04:37:45 --> Config Class Initialized
DEBUG - 2011-08-23 04:37:45 --> Hooks Class Initialized
DEBUG - 2011-08-23 04:37:45 --> Utf8 Class Initialized
DEBUG - 2011-08-23 04:37:45 --> UTF-8 Support Enabled
DEBUG - 2011-08-23 04:37:45 --> URI Class Initialized
DEBUG - 2011-08-23 04:37:46 --> Router Class Initialized
DEBUG - 2011-08-23 04:37:46 --> Output Class Initialized
DEBUG - 2011-08-23 04:37:46 --> Input Class Initialized
DEBUG - 2011-08-23 04:37:46 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-23 04:37:46 --> Language Class Initialized
DEBUG - 2011-08-23 04:37:46 --> Loader Class Initialized
DEBUG - 2011-08-23 04:37:46 --> Controller Class Initialized
ERROR - 2011-08-23 04:37:46 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-23 04:37:46 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-23 04:37:46 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-23 04:37:46 --> Model Class Initialized
DEBUG - 2011-08-23 04:37:46 --> Model Class Initialized
DEBUG - 2011-08-23 04:37:46 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-23 04:37:46 --> Database Driver Class Initialized
DEBUG - 2011-08-23 04:37:46 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-23 04:37:46 --> Helper loaded: url_helper
DEBUG - 2011-08-23 04:37:46 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-23 04:37:46 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-23 04:37:46 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-23 04:37:46 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-23 04:37:46 --> Final output sent to browser
DEBUG - 2011-08-23 04:37:46 --> Total execution time: 0.6836
DEBUG - 2011-08-23 04:37:47 --> Config Class Initialized
DEBUG - 2011-08-23 04:37:47 --> Hooks Class Initialized
DEBUG - 2011-08-23 04:37:47 --> Utf8 Class Initialized
DEBUG - 2011-08-23 04:37:47 --> UTF-8 Support Enabled
DEBUG - 2011-08-23 04:37:47 --> URI Class Initialized
DEBUG - 2011-08-23 04:37:47 --> Router Class Initialized
DEBUG - 2011-08-23 04:37:47 --> Output Class Initialized
DEBUG - 2011-08-23 04:37:47 --> Input Class Initialized
DEBUG - 2011-08-23 04:37:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-23 04:37:47 --> Language Class Initialized
DEBUG - 2011-08-23 04:37:47 --> Loader Class Initialized
DEBUG - 2011-08-23 04:37:47 --> Controller Class Initialized
DEBUG - 2011-08-23 04:37:47 --> Model Class Initialized
DEBUG - 2011-08-23 04:37:47 --> Model Class Initialized
DEBUG - 2011-08-23 04:37:47 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-23 04:37:47 --> Database Driver Class Initialized
DEBUG - 2011-08-23 04:37:49 --> Final output sent to browser
DEBUG - 2011-08-23 04:37:49 --> Total execution time: 1.2261
DEBUG - 2011-08-23 04:37:50 --> Config Class Initialized
DEBUG - 2011-08-23 04:37:50 --> Hooks Class Initialized
DEBUG - 2011-08-23 04:37:50 --> Utf8 Class Initialized
DEBUG - 2011-08-23 04:37:50 --> UTF-8 Support Enabled
DEBUG - 2011-08-23 04:37:50 --> URI Class Initialized
DEBUG - 2011-08-23 04:37:50 --> Router Class Initialized
ERROR - 2011-08-23 04:37:50 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-23 04:37:50 --> Config Class Initialized
DEBUG - 2011-08-23 04:37:50 --> Hooks Class Initialized
DEBUG - 2011-08-23 04:37:50 --> Utf8 Class Initialized
DEBUG - 2011-08-23 04:37:50 --> UTF-8 Support Enabled
DEBUG - 2011-08-23 04:37:50 --> URI Class Initialized
DEBUG - 2011-08-23 04:37:50 --> Router Class Initialized
ERROR - 2011-08-23 04:37:50 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-23 04:37:50 --> Config Class Initialized
DEBUG - 2011-08-23 04:37:50 --> Hooks Class Initialized
DEBUG - 2011-08-23 04:37:50 --> Utf8 Class Initialized
DEBUG - 2011-08-23 04:37:50 --> UTF-8 Support Enabled
DEBUG - 2011-08-23 04:37:50 --> URI Class Initialized
DEBUG - 2011-08-23 04:37:50 --> Router Class Initialized
ERROR - 2011-08-23 04:37:50 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-23 04:38:14 --> Config Class Initialized
DEBUG - 2011-08-23 04:38:14 --> Hooks Class Initialized
DEBUG - 2011-08-23 04:38:14 --> Utf8 Class Initialized
DEBUG - 2011-08-23 04:38:14 --> UTF-8 Support Enabled
DEBUG - 2011-08-23 04:38:14 --> URI Class Initialized
DEBUG - 2011-08-23 04:38:14 --> Router Class Initialized
DEBUG - 2011-08-23 04:38:14 --> Output Class Initialized
DEBUG - 2011-08-23 04:38:14 --> Input Class Initialized
DEBUG - 2011-08-23 04:38:14 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-23 04:38:14 --> Language Class Initialized
DEBUG - 2011-08-23 04:38:14 --> Loader Class Initialized
DEBUG - 2011-08-23 04:38:14 --> Controller Class Initialized
ERROR - 2011-08-23 04:38:14 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-23 04:38:14 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-23 04:38:14 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-23 04:38:14 --> Model Class Initialized
DEBUG - 2011-08-23 04:38:14 --> Model Class Initialized
DEBUG - 2011-08-23 04:38:14 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-23 04:38:14 --> Database Driver Class Initialized
DEBUG - 2011-08-23 04:38:14 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-23 04:38:14 --> Helper loaded: url_helper
DEBUG - 2011-08-23 04:38:14 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-23 04:38:14 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-23 04:38:14 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-23 04:38:14 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-23 04:38:14 --> Final output sent to browser
DEBUG - 2011-08-23 04:38:14 --> Total execution time: 0.0582
DEBUG - 2011-08-23 04:38:15 --> Config Class Initialized
DEBUG - 2011-08-23 04:38:15 --> Hooks Class Initialized
DEBUG - 2011-08-23 04:38:15 --> Utf8 Class Initialized
DEBUG - 2011-08-23 04:38:15 --> UTF-8 Support Enabled
DEBUG - 2011-08-23 04:38:15 --> URI Class Initialized
DEBUG - 2011-08-23 04:38:15 --> Router Class Initialized
DEBUG - 2011-08-23 04:38:15 --> Output Class Initialized
DEBUG - 2011-08-23 04:38:15 --> Input Class Initialized
DEBUG - 2011-08-23 04:38:15 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-23 04:38:15 --> Language Class Initialized
DEBUG - 2011-08-23 04:38:15 --> Loader Class Initialized
DEBUG - 2011-08-23 04:38:15 --> Controller Class Initialized
DEBUG - 2011-08-23 04:38:15 --> Model Class Initialized
DEBUG - 2011-08-23 04:38:15 --> Model Class Initialized
DEBUG - 2011-08-23 04:38:15 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-23 04:38:15 --> Database Driver Class Initialized
DEBUG - 2011-08-23 04:38:15 --> Final output sent to browser
DEBUG - 2011-08-23 04:38:15 --> Total execution time: 0.8960
DEBUG - 2011-08-23 04:39:00 --> Config Class Initialized
DEBUG - 2011-08-23 04:39:00 --> Hooks Class Initialized
DEBUG - 2011-08-23 04:39:00 --> Utf8 Class Initialized
DEBUG - 2011-08-23 04:39:00 --> UTF-8 Support Enabled
DEBUG - 2011-08-23 04:39:00 --> URI Class Initialized
DEBUG - 2011-08-23 04:39:00 --> Router Class Initialized
DEBUG - 2011-08-23 04:39:00 --> Output Class Initialized
DEBUG - 2011-08-23 04:39:00 --> Input Class Initialized
DEBUG - 2011-08-23 04:39:00 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-23 04:39:00 --> Language Class Initialized
DEBUG - 2011-08-23 04:39:00 --> Loader Class Initialized
DEBUG - 2011-08-23 04:39:00 --> Controller Class Initialized
ERROR - 2011-08-23 04:39:00 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-23 04:39:00 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-23 04:39:00 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-23 04:39:00 --> Model Class Initialized
DEBUG - 2011-08-23 04:39:00 --> Model Class Initialized
DEBUG - 2011-08-23 04:39:00 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-23 04:39:00 --> Database Driver Class Initialized
DEBUG - 2011-08-23 04:39:00 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-23 04:39:00 --> Helper loaded: url_helper
DEBUG - 2011-08-23 04:39:00 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-23 04:39:00 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-23 04:39:00 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-23 04:39:00 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-23 04:39:00 --> Final output sent to browser
DEBUG - 2011-08-23 04:39:00 --> Total execution time: 0.0338
DEBUG - 2011-08-23 04:39:00 --> Config Class Initialized
DEBUG - 2011-08-23 04:39:00 --> Hooks Class Initialized
DEBUG - 2011-08-23 04:39:00 --> Utf8 Class Initialized
DEBUG - 2011-08-23 04:39:00 --> UTF-8 Support Enabled
DEBUG - 2011-08-23 04:39:00 --> URI Class Initialized
DEBUG - 2011-08-23 04:39:00 --> Router Class Initialized
DEBUG - 2011-08-23 04:39:00 --> Output Class Initialized
DEBUG - 2011-08-23 04:39:00 --> Input Class Initialized
DEBUG - 2011-08-23 04:39:00 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-23 04:39:00 --> Language Class Initialized
DEBUG - 2011-08-23 04:39:00 --> Loader Class Initialized
DEBUG - 2011-08-23 04:39:00 --> Controller Class Initialized
DEBUG - 2011-08-23 04:39:00 --> Model Class Initialized
DEBUG - 2011-08-23 04:39:00 --> Model Class Initialized
DEBUG - 2011-08-23 04:39:00 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-23 04:39:00 --> Database Driver Class Initialized
DEBUG - 2011-08-23 04:39:01 --> Final output sent to browser
DEBUG - 2011-08-23 04:39:01 --> Total execution time: 0.6926
DEBUG - 2011-08-23 04:39:02 --> Config Class Initialized
DEBUG - 2011-08-23 04:39:02 --> Hooks Class Initialized
DEBUG - 2011-08-23 04:39:02 --> Utf8 Class Initialized
DEBUG - 2011-08-23 04:39:02 --> UTF-8 Support Enabled
DEBUG - 2011-08-23 04:39:02 --> URI Class Initialized
DEBUG - 2011-08-23 04:39:02 --> Router Class Initialized
DEBUG - 2011-08-23 04:39:02 --> Output Class Initialized
DEBUG - 2011-08-23 04:39:02 --> Input Class Initialized
DEBUG - 2011-08-23 04:39:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-23 04:39:02 --> Language Class Initialized
DEBUG - 2011-08-23 04:39:02 --> Loader Class Initialized
DEBUG - 2011-08-23 04:39:02 --> Controller Class Initialized
ERROR - 2011-08-23 04:39:02 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-23 04:39:02 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-23 04:39:02 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-23 04:39:02 --> Model Class Initialized
DEBUG - 2011-08-23 04:39:02 --> Model Class Initialized
DEBUG - 2011-08-23 04:39:02 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-23 04:39:02 --> Database Driver Class Initialized
DEBUG - 2011-08-23 04:39:02 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-23 04:39:02 --> Helper loaded: url_helper
DEBUG - 2011-08-23 04:39:02 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-23 04:39:02 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-23 04:39:02 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-23 04:39:02 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-23 04:39:02 --> Final output sent to browser
DEBUG - 2011-08-23 04:39:02 --> Total execution time: 0.1391
DEBUG - 2011-08-23 04:39:04 --> Config Class Initialized
DEBUG - 2011-08-23 04:39:04 --> Hooks Class Initialized
DEBUG - 2011-08-23 04:39:04 --> Utf8 Class Initialized
DEBUG - 2011-08-23 04:39:04 --> UTF-8 Support Enabled
DEBUG - 2011-08-23 04:39:04 --> URI Class Initialized
DEBUG - 2011-08-23 04:39:04 --> Router Class Initialized
DEBUG - 2011-08-23 04:39:04 --> Output Class Initialized
DEBUG - 2011-08-23 04:39:04 --> Input Class Initialized
DEBUG - 2011-08-23 04:39:04 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-23 04:39:04 --> Language Class Initialized
DEBUG - 2011-08-23 04:39:04 --> Loader Class Initialized
DEBUG - 2011-08-23 04:39:04 --> Controller Class Initialized
ERROR - 2011-08-23 04:39:04 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-23 04:39:04 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-23 04:39:04 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-23 04:39:04 --> Model Class Initialized
DEBUG - 2011-08-23 04:39:04 --> Model Class Initialized
DEBUG - 2011-08-23 04:39:04 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-23 04:39:04 --> Database Driver Class Initialized
DEBUG - 2011-08-23 04:39:04 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-23 04:39:04 --> Helper loaded: url_helper
DEBUG - 2011-08-23 04:39:04 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-23 04:39:04 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-23 04:39:04 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-23 04:39:04 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-23 04:39:04 --> Final output sent to browser
DEBUG - 2011-08-23 04:39:04 --> Total execution time: 0.0463
DEBUG - 2011-08-23 04:39:05 --> Config Class Initialized
DEBUG - 2011-08-23 04:39:05 --> Hooks Class Initialized
DEBUG - 2011-08-23 04:39:05 --> Utf8 Class Initialized
DEBUG - 2011-08-23 04:39:05 --> UTF-8 Support Enabled
DEBUG - 2011-08-23 04:39:05 --> URI Class Initialized
DEBUG - 2011-08-23 04:39:05 --> Router Class Initialized
DEBUG - 2011-08-23 04:39:05 --> Output Class Initialized
DEBUG - 2011-08-23 04:39:05 --> Input Class Initialized
DEBUG - 2011-08-23 04:39:05 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-23 04:39:05 --> Language Class Initialized
DEBUG - 2011-08-23 04:39:05 --> Loader Class Initialized
DEBUG - 2011-08-23 04:39:05 --> Controller Class Initialized
DEBUG - 2011-08-23 04:39:05 --> Model Class Initialized
DEBUG - 2011-08-23 04:39:05 --> Model Class Initialized
DEBUG - 2011-08-23 04:39:05 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-23 04:39:05 --> Database Driver Class Initialized
DEBUG - 2011-08-23 04:39:05 --> Config Class Initialized
DEBUG - 2011-08-23 04:39:05 --> Hooks Class Initialized
DEBUG - 2011-08-23 04:39:05 --> Utf8 Class Initialized
DEBUG - 2011-08-23 04:39:05 --> UTF-8 Support Enabled
DEBUG - 2011-08-23 04:39:05 --> URI Class Initialized
DEBUG - 2011-08-23 04:39:05 --> Router Class Initialized
DEBUG - 2011-08-23 04:39:05 --> Output Class Initialized
DEBUG - 2011-08-23 04:39:05 --> Input Class Initialized
DEBUG - 2011-08-23 04:39:05 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-23 04:39:05 --> Language Class Initialized
DEBUG - 2011-08-23 04:39:06 --> Loader Class Initialized
DEBUG - 2011-08-23 04:39:06 --> Controller Class Initialized
ERROR - 2011-08-23 04:39:06 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-23 04:39:06 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-23 04:39:06 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-23 04:39:06 --> Model Class Initialized
DEBUG - 2011-08-23 04:39:06 --> Model Class Initialized
DEBUG - 2011-08-23 04:39:06 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-23 04:39:06 --> Database Driver Class Initialized
DEBUG - 2011-08-23 04:39:06 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-23 04:39:06 --> Helper loaded: url_helper
DEBUG - 2011-08-23 04:39:06 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-23 04:39:06 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-23 04:39:06 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-23 04:39:06 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-23 04:39:06 --> Final output sent to browser
DEBUG - 2011-08-23 04:39:06 --> Total execution time: 0.0385
DEBUG - 2011-08-23 04:39:07 --> Final output sent to browser
DEBUG - 2011-08-23 04:39:07 --> Total execution time: 2.0751
DEBUG - 2011-08-23 04:39:15 --> Config Class Initialized
DEBUG - 2011-08-23 04:39:15 --> Hooks Class Initialized
DEBUG - 2011-08-23 04:39:15 --> Utf8 Class Initialized
DEBUG - 2011-08-23 04:39:15 --> UTF-8 Support Enabled
DEBUG - 2011-08-23 04:39:15 --> URI Class Initialized
DEBUG - 2011-08-23 04:39:15 --> Router Class Initialized
DEBUG - 2011-08-23 04:39:15 --> Output Class Initialized
DEBUG - 2011-08-23 04:39:15 --> Input Class Initialized
DEBUG - 2011-08-23 04:39:15 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-23 04:39:15 --> Language Class Initialized
DEBUG - 2011-08-23 04:39:15 --> Loader Class Initialized
DEBUG - 2011-08-23 04:39:15 --> Controller Class Initialized
ERROR - 2011-08-23 04:39:15 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-23 04:39:15 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-23 04:39:15 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-23 04:39:15 --> Model Class Initialized
DEBUG - 2011-08-23 04:39:15 --> Model Class Initialized
DEBUG - 2011-08-23 04:39:15 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-23 04:39:15 --> Database Driver Class Initialized
DEBUG - 2011-08-23 04:39:15 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-23 04:39:15 --> Helper loaded: url_helper
DEBUG - 2011-08-23 04:39:15 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-23 04:39:15 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-23 04:39:15 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-23 04:39:15 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-23 04:39:15 --> Final output sent to browser
DEBUG - 2011-08-23 04:39:15 --> Total execution time: 0.0297
DEBUG - 2011-08-23 04:39:16 --> Config Class Initialized
DEBUG - 2011-08-23 04:39:16 --> Hooks Class Initialized
DEBUG - 2011-08-23 04:39:16 --> Utf8 Class Initialized
DEBUG - 2011-08-23 04:39:16 --> UTF-8 Support Enabled
DEBUG - 2011-08-23 04:39:16 --> URI Class Initialized
DEBUG - 2011-08-23 04:39:16 --> Router Class Initialized
DEBUG - 2011-08-23 04:39:16 --> Output Class Initialized
DEBUG - 2011-08-23 04:39:16 --> Input Class Initialized
DEBUG - 2011-08-23 04:39:16 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-23 04:39:16 --> Language Class Initialized
DEBUG - 2011-08-23 04:39:16 --> Loader Class Initialized
DEBUG - 2011-08-23 04:39:16 --> Controller Class Initialized
DEBUG - 2011-08-23 04:39:16 --> Model Class Initialized
DEBUG - 2011-08-23 04:39:16 --> Model Class Initialized
DEBUG - 2011-08-23 04:39:16 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-23 04:39:16 --> Database Driver Class Initialized
DEBUG - 2011-08-23 04:39:16 --> Final output sent to browser
DEBUG - 2011-08-23 04:39:16 --> Total execution time: 0.5880
DEBUG - 2011-08-23 05:50:07 --> Config Class Initialized
DEBUG - 2011-08-23 05:50:07 --> Hooks Class Initialized
DEBUG - 2011-08-23 05:50:07 --> Utf8 Class Initialized
DEBUG - 2011-08-23 05:50:07 --> UTF-8 Support Enabled
DEBUG - 2011-08-23 05:50:07 --> URI Class Initialized
DEBUG - 2011-08-23 05:50:07 --> Router Class Initialized
DEBUG - 2011-08-23 05:50:07 --> Output Class Initialized
DEBUG - 2011-08-23 05:50:07 --> Input Class Initialized
DEBUG - 2011-08-23 05:50:07 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-23 05:50:07 --> Language Class Initialized
DEBUG - 2011-08-23 05:50:07 --> Loader Class Initialized
DEBUG - 2011-08-23 05:50:07 --> Controller Class Initialized
ERROR - 2011-08-23 05:50:07 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-23 05:50:07 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-23 05:50:07 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-23 05:50:07 --> Model Class Initialized
DEBUG - 2011-08-23 05:50:07 --> Model Class Initialized
DEBUG - 2011-08-23 05:50:07 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-23 05:50:07 --> Database Driver Class Initialized
DEBUG - 2011-08-23 05:50:07 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-23 05:50:07 --> Helper loaded: url_helper
DEBUG - 2011-08-23 05:50:07 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-23 05:50:07 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-23 05:50:07 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-23 05:50:07 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-23 05:50:07 --> Final output sent to browser
DEBUG - 2011-08-23 05:50:07 --> Total execution time: 0.6305
DEBUG - 2011-08-23 05:50:08 --> Config Class Initialized
DEBUG - 2011-08-23 05:50:08 --> Hooks Class Initialized
DEBUG - 2011-08-23 05:50:08 --> Utf8 Class Initialized
DEBUG - 2011-08-23 05:50:08 --> UTF-8 Support Enabled
DEBUG - 2011-08-23 05:50:08 --> URI Class Initialized
DEBUG - 2011-08-23 05:50:08 --> Router Class Initialized
DEBUG - 2011-08-23 05:50:08 --> Output Class Initialized
DEBUG - 2011-08-23 05:50:08 --> Input Class Initialized
DEBUG - 2011-08-23 05:50:08 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-23 05:50:08 --> Language Class Initialized
DEBUG - 2011-08-23 05:50:08 --> Loader Class Initialized
DEBUG - 2011-08-23 05:50:08 --> Controller Class Initialized
DEBUG - 2011-08-23 05:50:08 --> Model Class Initialized
DEBUG - 2011-08-23 05:50:08 --> Model Class Initialized
DEBUG - 2011-08-23 05:50:08 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-23 05:50:08 --> Database Driver Class Initialized
DEBUG - 2011-08-23 05:50:09 --> Final output sent to browser
DEBUG - 2011-08-23 05:50:09 --> Total execution time: 0.6587
DEBUG - 2011-08-23 05:50:10 --> Config Class Initialized
DEBUG - 2011-08-23 05:50:10 --> Hooks Class Initialized
DEBUG - 2011-08-23 05:50:10 --> Utf8 Class Initialized
DEBUG - 2011-08-23 05:50:10 --> UTF-8 Support Enabled
DEBUG - 2011-08-23 05:50:10 --> URI Class Initialized
DEBUG - 2011-08-23 05:50:10 --> Router Class Initialized
ERROR - 2011-08-23 05:50:10 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-23 05:50:11 --> Config Class Initialized
DEBUG - 2011-08-23 05:50:11 --> Hooks Class Initialized
DEBUG - 2011-08-23 05:50:11 --> Utf8 Class Initialized
DEBUG - 2011-08-23 05:50:11 --> UTF-8 Support Enabled
DEBUG - 2011-08-23 05:50:11 --> URI Class Initialized
DEBUG - 2011-08-23 05:50:11 --> Router Class Initialized
ERROR - 2011-08-23 05:50:11 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-23 05:50:18 --> Config Class Initialized
DEBUG - 2011-08-23 05:50:18 --> Hooks Class Initialized
DEBUG - 2011-08-23 05:50:18 --> Utf8 Class Initialized
DEBUG - 2011-08-23 05:50:18 --> UTF-8 Support Enabled
DEBUG - 2011-08-23 05:50:18 --> URI Class Initialized
DEBUG - 2011-08-23 05:50:18 --> Router Class Initialized
DEBUG - 2011-08-23 05:50:18 --> Output Class Initialized
DEBUG - 2011-08-23 05:50:18 --> Input Class Initialized
DEBUG - 2011-08-23 05:50:18 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-23 05:50:18 --> Language Class Initialized
DEBUG - 2011-08-23 05:50:18 --> Loader Class Initialized
DEBUG - 2011-08-23 05:50:18 --> Controller Class Initialized
ERROR - 2011-08-23 05:50:18 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-23 05:50:18 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-23 05:50:18 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-23 05:50:18 --> Model Class Initialized
DEBUG - 2011-08-23 05:50:18 --> Model Class Initialized
DEBUG - 2011-08-23 05:50:18 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-23 05:50:18 --> Database Driver Class Initialized
DEBUG - 2011-08-23 05:50:18 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-23 05:50:18 --> Helper loaded: url_helper
DEBUG - 2011-08-23 05:50:18 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-23 05:50:18 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-23 05:50:18 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-23 05:50:18 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-23 05:50:18 --> Final output sent to browser
DEBUG - 2011-08-23 05:50:18 --> Total execution time: 0.0316
DEBUG - 2011-08-23 05:50:19 --> Config Class Initialized
DEBUG - 2011-08-23 05:50:19 --> Hooks Class Initialized
DEBUG - 2011-08-23 05:50:19 --> Utf8 Class Initialized
DEBUG - 2011-08-23 05:50:19 --> UTF-8 Support Enabled
DEBUG - 2011-08-23 05:50:19 --> URI Class Initialized
DEBUG - 2011-08-23 05:50:19 --> Router Class Initialized
DEBUG - 2011-08-23 05:50:19 --> Output Class Initialized
DEBUG - 2011-08-23 05:50:19 --> Input Class Initialized
DEBUG - 2011-08-23 05:50:19 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-23 05:50:19 --> Language Class Initialized
DEBUG - 2011-08-23 05:50:19 --> Loader Class Initialized
DEBUG - 2011-08-23 05:50:19 --> Controller Class Initialized
DEBUG - 2011-08-23 05:50:19 --> Model Class Initialized
DEBUG - 2011-08-23 05:50:19 --> Model Class Initialized
DEBUG - 2011-08-23 05:50:19 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-23 05:50:19 --> Database Driver Class Initialized
DEBUG - 2011-08-23 05:50:19 --> Final output sent to browser
DEBUG - 2011-08-23 05:50:19 --> Total execution time: 0.5356
DEBUG - 2011-08-23 05:50:20 --> Config Class Initialized
DEBUG - 2011-08-23 05:50:20 --> Hooks Class Initialized
DEBUG - 2011-08-23 05:50:20 --> Utf8 Class Initialized
DEBUG - 2011-08-23 05:50:20 --> UTF-8 Support Enabled
DEBUG - 2011-08-23 05:50:20 --> URI Class Initialized
DEBUG - 2011-08-23 05:50:20 --> Router Class Initialized
ERROR - 2011-08-23 05:50:20 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-23 06:23:25 --> Config Class Initialized
DEBUG - 2011-08-23 06:23:25 --> Hooks Class Initialized
DEBUG - 2011-08-23 06:23:25 --> Utf8 Class Initialized
DEBUG - 2011-08-23 06:23:25 --> UTF-8 Support Enabled
DEBUG - 2011-08-23 06:23:25 --> URI Class Initialized
DEBUG - 2011-08-23 06:23:25 --> Router Class Initialized
ERROR - 2011-08-23 06:23:25 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-08-23 07:33:56 --> Config Class Initialized
DEBUG - 2011-08-23 07:33:56 --> Hooks Class Initialized
DEBUG - 2011-08-23 07:33:56 --> Utf8 Class Initialized
DEBUG - 2011-08-23 07:33:56 --> UTF-8 Support Enabled
DEBUG - 2011-08-23 07:33:56 --> URI Class Initialized
DEBUG - 2011-08-23 07:33:56 --> Router Class Initialized
DEBUG - 2011-08-23 07:33:56 --> Output Class Initialized
DEBUG - 2011-08-23 07:33:56 --> Input Class Initialized
DEBUG - 2011-08-23 07:33:56 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-23 07:33:56 --> Language Class Initialized
DEBUG - 2011-08-23 07:33:56 --> Loader Class Initialized
DEBUG - 2011-08-23 07:33:56 --> Controller Class Initialized
ERROR - 2011-08-23 07:33:56 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-23 07:33:56 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-23 07:33:56 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-23 07:33:56 --> Model Class Initialized
DEBUG - 2011-08-23 07:33:56 --> Model Class Initialized
DEBUG - 2011-08-23 07:33:56 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-23 07:33:56 --> Database Driver Class Initialized
DEBUG - 2011-08-23 07:33:56 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-23 07:33:56 --> Helper loaded: url_helper
DEBUG - 2011-08-23 07:33:56 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-23 07:33:56 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-23 07:33:56 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-23 07:33:56 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-23 07:33:56 --> Final output sent to browser
DEBUG - 2011-08-23 07:33:56 --> Total execution time: 0.4235
DEBUG - 2011-08-23 07:33:57 --> Config Class Initialized
DEBUG - 2011-08-23 07:33:57 --> Hooks Class Initialized
DEBUG - 2011-08-23 07:33:57 --> Utf8 Class Initialized
DEBUG - 2011-08-23 07:33:57 --> UTF-8 Support Enabled
DEBUG - 2011-08-23 07:33:57 --> URI Class Initialized
DEBUG - 2011-08-23 07:33:57 --> Router Class Initialized
DEBUG - 2011-08-23 07:33:57 --> Output Class Initialized
DEBUG - 2011-08-23 07:33:57 --> Input Class Initialized
DEBUG - 2011-08-23 07:33:57 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-23 07:33:57 --> Language Class Initialized
DEBUG - 2011-08-23 07:33:57 --> Loader Class Initialized
DEBUG - 2011-08-23 07:33:57 --> Controller Class Initialized
DEBUG - 2011-08-23 07:33:57 --> Model Class Initialized
DEBUG - 2011-08-23 07:33:57 --> Model Class Initialized
DEBUG - 2011-08-23 07:33:57 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-23 07:33:57 --> Database Driver Class Initialized
DEBUG - 2011-08-23 07:33:58 --> Final output sent to browser
DEBUG - 2011-08-23 07:33:58 --> Total execution time: 0.7220
DEBUG - 2011-08-23 07:33:59 --> Config Class Initialized
DEBUG - 2011-08-23 07:33:59 --> Hooks Class Initialized
DEBUG - 2011-08-23 07:33:59 --> Utf8 Class Initialized
DEBUG - 2011-08-23 07:33:59 --> UTF-8 Support Enabled
DEBUG - 2011-08-23 07:33:59 --> URI Class Initialized
DEBUG - 2011-08-23 07:33:59 --> Router Class Initialized
ERROR - 2011-08-23 07:33:59 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-23 07:34:09 --> Config Class Initialized
DEBUG - 2011-08-23 07:34:09 --> Hooks Class Initialized
DEBUG - 2011-08-23 07:34:09 --> Utf8 Class Initialized
DEBUG - 2011-08-23 07:34:09 --> UTF-8 Support Enabled
DEBUG - 2011-08-23 07:34:09 --> URI Class Initialized
DEBUG - 2011-08-23 07:34:09 --> Router Class Initialized
DEBUG - 2011-08-23 07:34:09 --> Output Class Initialized
DEBUG - 2011-08-23 07:34:09 --> Input Class Initialized
DEBUG - 2011-08-23 07:34:09 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-23 07:34:09 --> Language Class Initialized
DEBUG - 2011-08-23 07:34:09 --> Loader Class Initialized
DEBUG - 2011-08-23 07:34:09 --> Controller Class Initialized
ERROR - 2011-08-23 07:34:09 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-23 07:34:09 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-23 07:34:09 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-23 07:34:09 --> Model Class Initialized
DEBUG - 2011-08-23 07:34:09 --> Model Class Initialized
DEBUG - 2011-08-23 07:34:09 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-23 07:34:09 --> Database Driver Class Initialized
DEBUG - 2011-08-23 07:34:09 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-23 07:34:09 --> Helper loaded: url_helper
DEBUG - 2011-08-23 07:34:09 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-23 07:34:09 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-23 07:34:09 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-23 07:34:09 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-23 07:34:09 --> Final output sent to browser
DEBUG - 2011-08-23 07:34:09 --> Total execution time: 0.0338
DEBUG - 2011-08-23 07:34:10 --> Config Class Initialized
DEBUG - 2011-08-23 07:34:10 --> Hooks Class Initialized
DEBUG - 2011-08-23 07:34:10 --> Utf8 Class Initialized
DEBUG - 2011-08-23 07:34:10 --> UTF-8 Support Enabled
DEBUG - 2011-08-23 07:34:10 --> URI Class Initialized
DEBUG - 2011-08-23 07:34:10 --> Router Class Initialized
DEBUG - 2011-08-23 07:34:10 --> Output Class Initialized
DEBUG - 2011-08-23 07:34:10 --> Input Class Initialized
DEBUG - 2011-08-23 07:34:10 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-23 07:34:10 --> Language Class Initialized
DEBUG - 2011-08-23 07:34:10 --> Loader Class Initialized
DEBUG - 2011-08-23 07:34:10 --> Controller Class Initialized
DEBUG - 2011-08-23 07:34:10 --> Model Class Initialized
DEBUG - 2011-08-23 07:34:10 --> Model Class Initialized
DEBUG - 2011-08-23 07:34:10 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-23 07:34:10 --> Database Driver Class Initialized
DEBUG - 2011-08-23 07:34:10 --> Final output sent to browser
DEBUG - 2011-08-23 07:34:10 --> Total execution time: 0.7193
DEBUG - 2011-08-23 07:34:11 --> Config Class Initialized
DEBUG - 2011-08-23 07:34:11 --> Hooks Class Initialized
DEBUG - 2011-08-23 07:34:11 --> Utf8 Class Initialized
DEBUG - 2011-08-23 07:34:11 --> UTF-8 Support Enabled
DEBUG - 2011-08-23 07:34:11 --> URI Class Initialized
DEBUG - 2011-08-23 07:34:11 --> Router Class Initialized
ERROR - 2011-08-23 07:34:11 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-23 07:34:14 --> Config Class Initialized
DEBUG - 2011-08-23 07:34:14 --> Hooks Class Initialized
DEBUG - 2011-08-23 07:34:14 --> Utf8 Class Initialized
DEBUG - 2011-08-23 07:34:14 --> UTF-8 Support Enabled
DEBUG - 2011-08-23 07:34:14 --> URI Class Initialized
DEBUG - 2011-08-23 07:34:14 --> Router Class Initialized
DEBUG - 2011-08-23 07:34:14 --> Output Class Initialized
DEBUG - 2011-08-23 07:34:14 --> Input Class Initialized
DEBUG - 2011-08-23 07:34:14 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-23 07:34:14 --> Language Class Initialized
DEBUG - 2011-08-23 07:34:14 --> Loader Class Initialized
DEBUG - 2011-08-23 07:34:14 --> Controller Class Initialized
ERROR - 2011-08-23 07:34:14 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-23 07:34:14 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-23 07:34:14 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-23 07:34:14 --> Model Class Initialized
DEBUG - 2011-08-23 07:34:14 --> Model Class Initialized
DEBUG - 2011-08-23 07:34:14 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-23 07:34:14 --> Database Driver Class Initialized
DEBUG - 2011-08-23 07:34:14 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-23 07:34:14 --> Helper loaded: url_helper
DEBUG - 2011-08-23 07:34:14 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-23 07:34:14 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-23 07:34:14 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-23 07:34:14 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-23 07:34:14 --> Final output sent to browser
DEBUG - 2011-08-23 07:34:14 --> Total execution time: 0.0293
DEBUG - 2011-08-23 07:34:15 --> Config Class Initialized
DEBUG - 2011-08-23 07:34:15 --> Hooks Class Initialized
DEBUG - 2011-08-23 07:34:15 --> Utf8 Class Initialized
DEBUG - 2011-08-23 07:34:15 --> UTF-8 Support Enabled
DEBUG - 2011-08-23 07:34:15 --> URI Class Initialized
DEBUG - 2011-08-23 07:34:15 --> Router Class Initialized
DEBUG - 2011-08-23 07:34:15 --> Output Class Initialized
DEBUG - 2011-08-23 07:34:15 --> Input Class Initialized
DEBUG - 2011-08-23 07:34:15 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-23 07:34:15 --> Language Class Initialized
DEBUG - 2011-08-23 07:34:15 --> Loader Class Initialized
DEBUG - 2011-08-23 07:34:15 --> Controller Class Initialized
DEBUG - 2011-08-23 07:34:15 --> Model Class Initialized
DEBUG - 2011-08-23 07:34:15 --> Model Class Initialized
DEBUG - 2011-08-23 07:34:15 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-23 07:34:15 --> Database Driver Class Initialized
DEBUG - 2011-08-23 07:34:15 --> Final output sent to browser
DEBUG - 2011-08-23 07:34:15 --> Total execution time: 0.4980
DEBUG - 2011-08-23 07:34:16 --> Config Class Initialized
DEBUG - 2011-08-23 07:34:16 --> Hooks Class Initialized
DEBUG - 2011-08-23 07:34:16 --> Utf8 Class Initialized
DEBUG - 2011-08-23 07:34:16 --> UTF-8 Support Enabled
DEBUG - 2011-08-23 07:34:16 --> URI Class Initialized
DEBUG - 2011-08-23 07:34:16 --> Router Class Initialized
ERROR - 2011-08-23 07:34:16 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-23 07:34:19 --> Config Class Initialized
DEBUG - 2011-08-23 07:34:19 --> Hooks Class Initialized
DEBUG - 2011-08-23 07:34:19 --> Utf8 Class Initialized
DEBUG - 2011-08-23 07:34:19 --> UTF-8 Support Enabled
DEBUG - 2011-08-23 07:34:19 --> URI Class Initialized
DEBUG - 2011-08-23 07:34:19 --> Router Class Initialized
DEBUG - 2011-08-23 07:34:19 --> Output Class Initialized
DEBUG - 2011-08-23 07:34:19 --> Input Class Initialized
DEBUG - 2011-08-23 07:34:19 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-23 07:34:19 --> Language Class Initialized
DEBUG - 2011-08-23 07:34:19 --> Loader Class Initialized
DEBUG - 2011-08-23 07:34:19 --> Controller Class Initialized
ERROR - 2011-08-23 07:34:19 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-23 07:34:19 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-23 07:34:19 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-23 07:34:19 --> Model Class Initialized
DEBUG - 2011-08-23 07:34:19 --> Model Class Initialized
DEBUG - 2011-08-23 07:34:19 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-23 07:34:19 --> Database Driver Class Initialized
DEBUG - 2011-08-23 07:34:19 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-23 07:34:19 --> Helper loaded: url_helper
DEBUG - 2011-08-23 07:34:19 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-23 07:34:19 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-23 07:34:19 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-23 07:34:19 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-23 07:34:19 --> Final output sent to browser
DEBUG - 2011-08-23 07:34:19 --> Total execution time: 0.0370
DEBUG - 2011-08-23 07:34:19 --> Config Class Initialized
DEBUG - 2011-08-23 07:34:19 --> Hooks Class Initialized
DEBUG - 2011-08-23 07:34:19 --> Utf8 Class Initialized
DEBUG - 2011-08-23 07:34:19 --> UTF-8 Support Enabled
DEBUG - 2011-08-23 07:34:19 --> URI Class Initialized
DEBUG - 2011-08-23 07:34:19 --> Router Class Initialized
DEBUG - 2011-08-23 07:34:19 --> Output Class Initialized
DEBUG - 2011-08-23 07:34:19 --> Input Class Initialized
DEBUG - 2011-08-23 07:34:19 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-23 07:34:19 --> Language Class Initialized
DEBUG - 2011-08-23 07:34:19 --> Loader Class Initialized
DEBUG - 2011-08-23 07:34:19 --> Controller Class Initialized
DEBUG - 2011-08-23 07:34:19 --> Model Class Initialized
DEBUG - 2011-08-23 07:34:19 --> Model Class Initialized
DEBUG - 2011-08-23 07:34:19 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-23 07:34:19 --> Database Driver Class Initialized
DEBUG - 2011-08-23 07:34:20 --> Final output sent to browser
DEBUG - 2011-08-23 07:34:20 --> Total execution time: 0.8511
DEBUG - 2011-08-23 07:34:21 --> Config Class Initialized
DEBUG - 2011-08-23 07:34:21 --> Hooks Class Initialized
DEBUG - 2011-08-23 07:34:21 --> Utf8 Class Initialized
DEBUG - 2011-08-23 07:34:21 --> UTF-8 Support Enabled
DEBUG - 2011-08-23 07:34:21 --> URI Class Initialized
DEBUG - 2011-08-23 07:34:21 --> Router Class Initialized
ERROR - 2011-08-23 07:34:21 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-23 07:34:32 --> Config Class Initialized
DEBUG - 2011-08-23 07:34:32 --> Hooks Class Initialized
DEBUG - 2011-08-23 07:34:32 --> Utf8 Class Initialized
DEBUG - 2011-08-23 07:34:32 --> UTF-8 Support Enabled
DEBUG - 2011-08-23 07:34:32 --> URI Class Initialized
DEBUG - 2011-08-23 07:34:32 --> Router Class Initialized
DEBUG - 2011-08-23 07:34:32 --> Output Class Initialized
DEBUG - 2011-08-23 07:34:32 --> Input Class Initialized
DEBUG - 2011-08-23 07:34:32 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-23 07:34:32 --> Language Class Initialized
DEBUG - 2011-08-23 07:34:32 --> Loader Class Initialized
DEBUG - 2011-08-23 07:34:32 --> Controller Class Initialized
ERROR - 2011-08-23 07:34:32 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-23 07:34:32 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-23 07:34:32 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-23 07:34:32 --> Model Class Initialized
DEBUG - 2011-08-23 07:34:32 --> Model Class Initialized
DEBUG - 2011-08-23 07:34:32 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-23 07:34:32 --> Database Driver Class Initialized
DEBUG - 2011-08-23 07:34:32 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-23 07:34:32 --> Helper loaded: url_helper
DEBUG - 2011-08-23 07:34:32 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-23 07:34:32 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-23 07:34:32 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-23 07:34:32 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-23 07:34:32 --> Final output sent to browser
DEBUG - 2011-08-23 07:34:32 --> Total execution time: 0.0296
DEBUG - 2011-08-23 07:34:32 --> Config Class Initialized
DEBUG - 2011-08-23 07:34:32 --> Hooks Class Initialized
DEBUG - 2011-08-23 07:34:32 --> Utf8 Class Initialized
DEBUG - 2011-08-23 07:34:32 --> UTF-8 Support Enabled
DEBUG - 2011-08-23 07:34:32 --> URI Class Initialized
DEBUG - 2011-08-23 07:34:32 --> Router Class Initialized
DEBUG - 2011-08-23 07:34:32 --> Output Class Initialized
DEBUG - 2011-08-23 07:34:32 --> Input Class Initialized
DEBUG - 2011-08-23 07:34:32 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-23 07:34:32 --> Language Class Initialized
DEBUG - 2011-08-23 07:34:32 --> Loader Class Initialized
DEBUG - 2011-08-23 07:34:32 --> Controller Class Initialized
DEBUG - 2011-08-23 07:34:32 --> Model Class Initialized
DEBUG - 2011-08-23 07:34:32 --> Model Class Initialized
DEBUG - 2011-08-23 07:34:32 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-23 07:34:32 --> Database Driver Class Initialized
DEBUG - 2011-08-23 07:34:33 --> Final output sent to browser
DEBUG - 2011-08-23 07:34:33 --> Total execution time: 0.7229
DEBUG - 2011-08-23 07:34:34 --> Config Class Initialized
DEBUG - 2011-08-23 07:34:34 --> Hooks Class Initialized
DEBUG - 2011-08-23 07:34:34 --> Utf8 Class Initialized
DEBUG - 2011-08-23 07:34:34 --> UTF-8 Support Enabled
DEBUG - 2011-08-23 07:34:34 --> URI Class Initialized
DEBUG - 2011-08-23 07:34:34 --> Router Class Initialized
ERROR - 2011-08-23 07:34:34 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-23 07:34:39 --> Config Class Initialized
DEBUG - 2011-08-23 07:34:39 --> Hooks Class Initialized
DEBUG - 2011-08-23 07:34:39 --> Utf8 Class Initialized
DEBUG - 2011-08-23 07:34:39 --> UTF-8 Support Enabled
DEBUG - 2011-08-23 07:34:39 --> URI Class Initialized
DEBUG - 2011-08-23 07:34:39 --> Router Class Initialized
DEBUG - 2011-08-23 07:34:39 --> Output Class Initialized
DEBUG - 2011-08-23 07:34:39 --> Input Class Initialized
DEBUG - 2011-08-23 07:34:39 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-23 07:34:39 --> Language Class Initialized
DEBUG - 2011-08-23 07:34:39 --> Loader Class Initialized
DEBUG - 2011-08-23 07:34:39 --> Controller Class Initialized
ERROR - 2011-08-23 07:34:39 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-23 07:34:39 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-23 07:34:39 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-23 07:34:39 --> Model Class Initialized
DEBUG - 2011-08-23 07:34:39 --> Model Class Initialized
DEBUG - 2011-08-23 07:34:39 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-23 07:34:39 --> Database Driver Class Initialized
DEBUG - 2011-08-23 07:34:39 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-23 07:34:39 --> Helper loaded: url_helper
DEBUG - 2011-08-23 07:34:39 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-23 07:34:39 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-23 07:34:39 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-23 07:34:39 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-23 07:34:39 --> Final output sent to browser
DEBUG - 2011-08-23 07:34:39 --> Total execution time: 0.1082
DEBUG - 2011-08-23 07:34:40 --> Config Class Initialized
DEBUG - 2011-08-23 07:34:40 --> Hooks Class Initialized
DEBUG - 2011-08-23 07:34:40 --> Utf8 Class Initialized
DEBUG - 2011-08-23 07:34:40 --> UTF-8 Support Enabled
DEBUG - 2011-08-23 07:34:40 --> URI Class Initialized
DEBUG - 2011-08-23 07:34:40 --> Router Class Initialized
DEBUG - 2011-08-23 07:34:40 --> Output Class Initialized
DEBUG - 2011-08-23 07:34:40 --> Input Class Initialized
DEBUG - 2011-08-23 07:34:40 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-23 07:34:40 --> Language Class Initialized
DEBUG - 2011-08-23 07:34:40 --> Loader Class Initialized
DEBUG - 2011-08-23 07:34:40 --> Controller Class Initialized
DEBUG - 2011-08-23 07:34:40 --> Model Class Initialized
DEBUG - 2011-08-23 07:34:40 --> Model Class Initialized
DEBUG - 2011-08-23 07:34:40 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-23 07:34:40 --> Database Driver Class Initialized
DEBUG - 2011-08-23 07:34:41 --> Final output sent to browser
DEBUG - 2011-08-23 07:34:41 --> Total execution time: 1.1414
DEBUG - 2011-08-23 07:34:42 --> Config Class Initialized
DEBUG - 2011-08-23 07:34:42 --> Hooks Class Initialized
DEBUG - 2011-08-23 07:34:42 --> Utf8 Class Initialized
DEBUG - 2011-08-23 07:34:42 --> UTF-8 Support Enabled
DEBUG - 2011-08-23 07:34:42 --> URI Class Initialized
DEBUG - 2011-08-23 07:34:42 --> Router Class Initialized
ERROR - 2011-08-23 07:34:42 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-23 07:34:46 --> Config Class Initialized
DEBUG - 2011-08-23 07:34:46 --> Hooks Class Initialized
DEBUG - 2011-08-23 07:34:46 --> Utf8 Class Initialized
DEBUG - 2011-08-23 07:34:46 --> UTF-8 Support Enabled
DEBUG - 2011-08-23 07:34:46 --> URI Class Initialized
DEBUG - 2011-08-23 07:34:46 --> Router Class Initialized
DEBUG - 2011-08-23 07:34:46 --> Output Class Initialized
DEBUG - 2011-08-23 07:34:46 --> Input Class Initialized
DEBUG - 2011-08-23 07:34:46 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-23 07:34:46 --> Language Class Initialized
DEBUG - 2011-08-23 07:34:46 --> Loader Class Initialized
DEBUG - 2011-08-23 07:34:46 --> Controller Class Initialized
ERROR - 2011-08-23 07:34:46 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-23 07:34:46 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-23 07:34:46 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-23 07:34:46 --> Model Class Initialized
DEBUG - 2011-08-23 07:34:46 --> Model Class Initialized
DEBUG - 2011-08-23 07:34:46 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-23 07:34:46 --> Database Driver Class Initialized
DEBUG - 2011-08-23 07:34:46 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-23 07:34:46 --> Helper loaded: url_helper
DEBUG - 2011-08-23 07:34:46 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-23 07:34:46 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-23 07:34:46 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-23 07:34:46 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-23 07:34:46 --> Final output sent to browser
DEBUG - 2011-08-23 07:34:46 --> Total execution time: 0.0731
DEBUG - 2011-08-23 07:34:46 --> Config Class Initialized
DEBUG - 2011-08-23 07:34:46 --> Hooks Class Initialized
DEBUG - 2011-08-23 07:34:46 --> Utf8 Class Initialized
DEBUG - 2011-08-23 07:34:46 --> UTF-8 Support Enabled
DEBUG - 2011-08-23 07:34:46 --> URI Class Initialized
DEBUG - 2011-08-23 07:34:46 --> Router Class Initialized
DEBUG - 2011-08-23 07:34:46 --> Output Class Initialized
DEBUG - 2011-08-23 07:34:46 --> Input Class Initialized
DEBUG - 2011-08-23 07:34:46 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-23 07:34:46 --> Language Class Initialized
DEBUG - 2011-08-23 07:34:46 --> Loader Class Initialized
DEBUG - 2011-08-23 07:34:46 --> Controller Class Initialized
DEBUG - 2011-08-23 07:34:46 --> Model Class Initialized
DEBUG - 2011-08-23 07:34:46 --> Model Class Initialized
DEBUG - 2011-08-23 07:34:46 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-23 07:34:46 --> Database Driver Class Initialized
DEBUG - 2011-08-23 07:34:47 --> Final output sent to browser
DEBUG - 2011-08-23 07:34:47 --> Total execution time: 0.6043
DEBUG - 2011-08-23 07:34:48 --> Config Class Initialized
DEBUG - 2011-08-23 07:34:48 --> Hooks Class Initialized
DEBUG - 2011-08-23 07:34:48 --> Utf8 Class Initialized
DEBUG - 2011-08-23 07:34:48 --> UTF-8 Support Enabled
DEBUG - 2011-08-23 07:34:48 --> URI Class Initialized
DEBUG - 2011-08-23 07:34:48 --> Router Class Initialized
ERROR - 2011-08-23 07:34:48 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-23 07:34:51 --> Config Class Initialized
DEBUG - 2011-08-23 07:34:51 --> Hooks Class Initialized
DEBUG - 2011-08-23 07:34:51 --> Utf8 Class Initialized
DEBUG - 2011-08-23 07:34:51 --> UTF-8 Support Enabled
DEBUG - 2011-08-23 07:34:51 --> URI Class Initialized
DEBUG - 2011-08-23 07:34:51 --> Router Class Initialized
DEBUG - 2011-08-23 07:34:51 --> Output Class Initialized
DEBUG - 2011-08-23 07:34:51 --> Input Class Initialized
DEBUG - 2011-08-23 07:34:51 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-23 07:34:51 --> Language Class Initialized
DEBUG - 2011-08-23 07:34:51 --> Loader Class Initialized
DEBUG - 2011-08-23 07:34:51 --> Controller Class Initialized
ERROR - 2011-08-23 07:34:51 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-23 07:34:51 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-23 07:34:51 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-23 07:34:51 --> Model Class Initialized
DEBUG - 2011-08-23 07:34:51 --> Model Class Initialized
DEBUG - 2011-08-23 07:34:51 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-23 07:34:51 --> Database Driver Class Initialized
DEBUG - 2011-08-23 07:34:51 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-23 07:34:51 --> Helper loaded: url_helper
DEBUG - 2011-08-23 07:34:51 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-23 07:34:51 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-23 07:34:51 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-23 07:34:51 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-23 07:34:51 --> Final output sent to browser
DEBUG - 2011-08-23 07:34:51 --> Total execution time: 0.0286
DEBUG - 2011-08-23 07:34:51 --> Config Class Initialized
DEBUG - 2011-08-23 07:34:51 --> Hooks Class Initialized
DEBUG - 2011-08-23 07:34:51 --> Utf8 Class Initialized
DEBUG - 2011-08-23 07:34:51 --> UTF-8 Support Enabled
DEBUG - 2011-08-23 07:34:51 --> URI Class Initialized
DEBUG - 2011-08-23 07:34:51 --> Router Class Initialized
DEBUG - 2011-08-23 07:34:51 --> Output Class Initialized
DEBUG - 2011-08-23 07:34:51 --> Input Class Initialized
DEBUG - 2011-08-23 07:34:51 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-23 07:34:51 --> Language Class Initialized
DEBUG - 2011-08-23 07:34:51 --> Loader Class Initialized
DEBUG - 2011-08-23 07:34:51 --> Controller Class Initialized
DEBUG - 2011-08-23 07:34:51 --> Model Class Initialized
DEBUG - 2011-08-23 07:34:51 --> Model Class Initialized
DEBUG - 2011-08-23 07:34:51 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-23 07:34:51 --> Database Driver Class Initialized
DEBUG - 2011-08-23 07:34:52 --> Final output sent to browser
DEBUG - 2011-08-23 07:34:52 --> Total execution time: 0.5161
DEBUG - 2011-08-23 07:34:53 --> Config Class Initialized
DEBUG - 2011-08-23 07:34:53 --> Hooks Class Initialized
DEBUG - 2011-08-23 07:34:53 --> Utf8 Class Initialized
DEBUG - 2011-08-23 07:34:53 --> UTF-8 Support Enabled
DEBUG - 2011-08-23 07:34:53 --> URI Class Initialized
DEBUG - 2011-08-23 07:34:53 --> Router Class Initialized
ERROR - 2011-08-23 07:34:53 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-23 07:34:57 --> Config Class Initialized
DEBUG - 2011-08-23 07:34:57 --> Hooks Class Initialized
DEBUG - 2011-08-23 07:34:57 --> Utf8 Class Initialized
DEBUG - 2011-08-23 07:34:57 --> UTF-8 Support Enabled
DEBUG - 2011-08-23 07:34:57 --> URI Class Initialized
DEBUG - 2011-08-23 07:34:57 --> Router Class Initialized
DEBUG - 2011-08-23 07:34:57 --> Output Class Initialized
DEBUG - 2011-08-23 07:34:57 --> Input Class Initialized
DEBUG - 2011-08-23 07:34:57 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-23 07:34:57 --> Language Class Initialized
DEBUG - 2011-08-23 07:34:57 --> Loader Class Initialized
DEBUG - 2011-08-23 07:34:57 --> Controller Class Initialized
ERROR - 2011-08-23 07:34:57 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-23 07:34:57 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-23 07:34:57 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-23 07:34:57 --> Model Class Initialized
DEBUG - 2011-08-23 07:34:57 --> Model Class Initialized
DEBUG - 2011-08-23 07:34:57 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-23 07:34:57 --> Database Driver Class Initialized
DEBUG - 2011-08-23 07:34:57 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-23 07:34:57 --> Helper loaded: url_helper
DEBUG - 2011-08-23 07:34:57 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-23 07:34:57 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-23 07:34:57 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-23 07:34:57 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-23 07:34:57 --> Final output sent to browser
DEBUG - 2011-08-23 07:34:57 --> Total execution time: 0.0300
DEBUG - 2011-08-23 07:34:58 --> Config Class Initialized
DEBUG - 2011-08-23 07:34:58 --> Hooks Class Initialized
DEBUG - 2011-08-23 07:34:58 --> Utf8 Class Initialized
DEBUG - 2011-08-23 07:34:58 --> UTF-8 Support Enabled
DEBUG - 2011-08-23 07:34:58 --> URI Class Initialized
DEBUG - 2011-08-23 07:34:58 --> Router Class Initialized
DEBUG - 2011-08-23 07:34:58 --> Output Class Initialized
DEBUG - 2011-08-23 07:34:58 --> Input Class Initialized
DEBUG - 2011-08-23 07:34:58 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-23 07:34:58 --> Language Class Initialized
DEBUG - 2011-08-23 07:34:58 --> Loader Class Initialized
DEBUG - 2011-08-23 07:34:58 --> Controller Class Initialized
DEBUG - 2011-08-23 07:34:58 --> Model Class Initialized
DEBUG - 2011-08-23 07:34:58 --> Model Class Initialized
DEBUG - 2011-08-23 07:34:58 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-23 07:34:58 --> Database Driver Class Initialized
DEBUG - 2011-08-23 07:34:58 --> Final output sent to browser
DEBUG - 2011-08-23 07:34:58 --> Total execution time: 0.5580
DEBUG - 2011-08-23 07:34:59 --> Config Class Initialized
DEBUG - 2011-08-23 07:34:59 --> Hooks Class Initialized
DEBUG - 2011-08-23 07:34:59 --> Utf8 Class Initialized
DEBUG - 2011-08-23 07:34:59 --> UTF-8 Support Enabled
DEBUG - 2011-08-23 07:34:59 --> URI Class Initialized
DEBUG - 2011-08-23 07:34:59 --> Router Class Initialized
ERROR - 2011-08-23 07:34:59 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-23 07:35:14 --> Config Class Initialized
DEBUG - 2011-08-23 07:35:14 --> Hooks Class Initialized
DEBUG - 2011-08-23 07:35:14 --> Utf8 Class Initialized
DEBUG - 2011-08-23 07:35:14 --> UTF-8 Support Enabled
DEBUG - 2011-08-23 07:35:14 --> URI Class Initialized
DEBUG - 2011-08-23 07:35:14 --> Router Class Initialized
DEBUG - 2011-08-23 07:35:14 --> Output Class Initialized
DEBUG - 2011-08-23 07:35:14 --> Input Class Initialized
DEBUG - 2011-08-23 07:35:14 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-23 07:35:14 --> Language Class Initialized
DEBUG - 2011-08-23 07:35:14 --> Loader Class Initialized
DEBUG - 2011-08-23 07:35:14 --> Controller Class Initialized
ERROR - 2011-08-23 07:35:14 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-23 07:35:14 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-23 07:35:14 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-23 07:35:14 --> Model Class Initialized
DEBUG - 2011-08-23 07:35:14 --> Model Class Initialized
DEBUG - 2011-08-23 07:35:14 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-23 07:35:14 --> Database Driver Class Initialized
DEBUG - 2011-08-23 07:35:14 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-23 07:35:14 --> Helper loaded: url_helper
DEBUG - 2011-08-23 07:35:14 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-23 07:35:14 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-23 07:35:14 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-23 07:35:14 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-23 07:35:14 --> Final output sent to browser
DEBUG - 2011-08-23 07:35:14 --> Total execution time: 0.0557
DEBUG - 2011-08-23 07:35:15 --> Config Class Initialized
DEBUG - 2011-08-23 07:35:15 --> Hooks Class Initialized
DEBUG - 2011-08-23 07:35:15 --> Utf8 Class Initialized
DEBUG - 2011-08-23 07:35:15 --> UTF-8 Support Enabled
DEBUG - 2011-08-23 07:35:15 --> URI Class Initialized
DEBUG - 2011-08-23 07:35:15 --> Router Class Initialized
DEBUG - 2011-08-23 07:35:15 --> Output Class Initialized
DEBUG - 2011-08-23 07:35:15 --> Input Class Initialized
DEBUG - 2011-08-23 07:35:15 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-23 07:35:15 --> Language Class Initialized
DEBUG - 2011-08-23 07:35:15 --> Loader Class Initialized
DEBUG - 2011-08-23 07:35:15 --> Controller Class Initialized
DEBUG - 2011-08-23 07:35:15 --> Model Class Initialized
DEBUG - 2011-08-23 07:35:15 --> Model Class Initialized
DEBUG - 2011-08-23 07:35:15 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-23 07:35:15 --> Database Driver Class Initialized
DEBUG - 2011-08-23 07:35:16 --> Final output sent to browser
DEBUG - 2011-08-23 07:35:16 --> Total execution time: 0.6171
DEBUG - 2011-08-23 07:35:16 --> Config Class Initialized
DEBUG - 2011-08-23 07:35:16 --> Hooks Class Initialized
DEBUG - 2011-08-23 07:35:16 --> Utf8 Class Initialized
DEBUG - 2011-08-23 07:35:16 --> UTF-8 Support Enabled
DEBUG - 2011-08-23 07:35:16 --> URI Class Initialized
DEBUG - 2011-08-23 07:35:16 --> Router Class Initialized
ERROR - 2011-08-23 07:35:16 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-23 07:35:24 --> Config Class Initialized
DEBUG - 2011-08-23 07:35:24 --> Hooks Class Initialized
DEBUG - 2011-08-23 07:35:24 --> Utf8 Class Initialized
DEBUG - 2011-08-23 07:35:24 --> UTF-8 Support Enabled
DEBUG - 2011-08-23 07:35:24 --> URI Class Initialized
DEBUG - 2011-08-23 07:35:24 --> Router Class Initialized
DEBUG - 2011-08-23 07:35:24 --> Output Class Initialized
DEBUG - 2011-08-23 07:35:24 --> Input Class Initialized
DEBUG - 2011-08-23 07:35:24 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-23 07:35:24 --> Language Class Initialized
DEBUG - 2011-08-23 07:35:24 --> Loader Class Initialized
DEBUG - 2011-08-23 07:35:24 --> Controller Class Initialized
ERROR - 2011-08-23 07:35:24 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-23 07:35:24 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-23 07:35:24 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-23 07:35:24 --> Model Class Initialized
DEBUG - 2011-08-23 07:35:24 --> Model Class Initialized
DEBUG - 2011-08-23 07:35:24 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-23 07:35:24 --> Database Driver Class Initialized
DEBUG - 2011-08-23 07:35:24 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-23 07:35:24 --> Helper loaded: url_helper
DEBUG - 2011-08-23 07:35:24 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-23 07:35:24 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-23 07:35:24 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-23 07:35:24 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-23 07:35:24 --> Final output sent to browser
DEBUG - 2011-08-23 07:35:24 --> Total execution time: 0.0274
DEBUG - 2011-08-23 07:35:24 --> Config Class Initialized
DEBUG - 2011-08-23 07:35:24 --> Hooks Class Initialized
DEBUG - 2011-08-23 07:35:24 --> Utf8 Class Initialized
DEBUG - 2011-08-23 07:35:24 --> UTF-8 Support Enabled
DEBUG - 2011-08-23 07:35:24 --> URI Class Initialized
DEBUG - 2011-08-23 07:35:24 --> Router Class Initialized
DEBUG - 2011-08-23 07:35:24 --> Output Class Initialized
DEBUG - 2011-08-23 07:35:24 --> Input Class Initialized
DEBUG - 2011-08-23 07:35:24 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-23 07:35:24 --> Language Class Initialized
DEBUG - 2011-08-23 07:35:24 --> Loader Class Initialized
DEBUG - 2011-08-23 07:35:24 --> Controller Class Initialized
DEBUG - 2011-08-23 07:35:24 --> Model Class Initialized
DEBUG - 2011-08-23 07:35:24 --> Model Class Initialized
DEBUG - 2011-08-23 07:35:24 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-23 07:35:24 --> Database Driver Class Initialized
DEBUG - 2011-08-23 07:35:25 --> Final output sent to browser
DEBUG - 2011-08-23 07:35:25 --> Total execution time: 0.4998
DEBUG - 2011-08-23 07:35:26 --> Config Class Initialized
DEBUG - 2011-08-23 07:35:26 --> Hooks Class Initialized
DEBUG - 2011-08-23 07:35:26 --> Utf8 Class Initialized
DEBUG - 2011-08-23 07:35:26 --> UTF-8 Support Enabled
DEBUG - 2011-08-23 07:35:26 --> URI Class Initialized
DEBUG - 2011-08-23 07:35:26 --> Router Class Initialized
ERROR - 2011-08-23 07:35:26 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-23 07:35:32 --> Config Class Initialized
DEBUG - 2011-08-23 07:35:32 --> Hooks Class Initialized
DEBUG - 2011-08-23 07:35:32 --> Utf8 Class Initialized
DEBUG - 2011-08-23 07:35:32 --> UTF-8 Support Enabled
DEBUG - 2011-08-23 07:35:32 --> URI Class Initialized
DEBUG - 2011-08-23 07:35:32 --> Router Class Initialized
DEBUG - 2011-08-23 07:35:32 --> Output Class Initialized
DEBUG - 2011-08-23 07:35:32 --> Input Class Initialized
DEBUG - 2011-08-23 07:35:32 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-23 07:35:32 --> Language Class Initialized
DEBUG - 2011-08-23 07:35:32 --> Loader Class Initialized
DEBUG - 2011-08-23 07:35:32 --> Controller Class Initialized
ERROR - 2011-08-23 07:35:32 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-23 07:35:32 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-23 07:35:32 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-23 07:35:32 --> Model Class Initialized
DEBUG - 2011-08-23 07:35:32 --> Model Class Initialized
DEBUG - 2011-08-23 07:35:32 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-23 07:35:32 --> Database Driver Class Initialized
DEBUG - 2011-08-23 07:35:32 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-23 07:35:32 --> Helper loaded: url_helper
DEBUG - 2011-08-23 07:35:32 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-23 07:35:32 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-23 07:35:32 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-23 07:35:32 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-23 07:35:32 --> Final output sent to browser
DEBUG - 2011-08-23 07:35:32 --> Total execution time: 0.0279
DEBUG - 2011-08-23 07:35:32 --> Config Class Initialized
DEBUG - 2011-08-23 07:35:32 --> Hooks Class Initialized
DEBUG - 2011-08-23 07:35:32 --> Utf8 Class Initialized
DEBUG - 2011-08-23 07:35:32 --> UTF-8 Support Enabled
DEBUG - 2011-08-23 07:35:32 --> URI Class Initialized
DEBUG - 2011-08-23 07:35:32 --> Router Class Initialized
DEBUG - 2011-08-23 07:35:32 --> Output Class Initialized
DEBUG - 2011-08-23 07:35:32 --> Input Class Initialized
DEBUG - 2011-08-23 07:35:32 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-23 07:35:32 --> Language Class Initialized
DEBUG - 2011-08-23 07:35:32 --> Loader Class Initialized
DEBUG - 2011-08-23 07:35:32 --> Controller Class Initialized
DEBUG - 2011-08-23 07:35:32 --> Model Class Initialized
DEBUG - 2011-08-23 07:35:32 --> Model Class Initialized
DEBUG - 2011-08-23 07:35:32 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-23 07:35:32 --> Database Driver Class Initialized
DEBUG - 2011-08-23 07:35:33 --> Final output sent to browser
DEBUG - 2011-08-23 07:35:33 --> Total execution time: 0.4912
DEBUG - 2011-08-23 07:35:33 --> Config Class Initialized
DEBUG - 2011-08-23 07:35:33 --> Hooks Class Initialized
DEBUG - 2011-08-23 07:35:33 --> Utf8 Class Initialized
DEBUG - 2011-08-23 07:35:33 --> UTF-8 Support Enabled
DEBUG - 2011-08-23 07:35:33 --> URI Class Initialized
DEBUG - 2011-08-23 07:35:33 --> Router Class Initialized
DEBUG - 2011-08-23 07:35:33 --> Output Class Initialized
DEBUG - 2011-08-23 07:35:33 --> Input Class Initialized
DEBUG - 2011-08-23 07:35:33 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-23 07:35:33 --> Language Class Initialized
DEBUG - 2011-08-23 07:35:33 --> Loader Class Initialized
DEBUG - 2011-08-23 07:35:33 --> Controller Class Initialized
ERROR - 2011-08-23 07:35:33 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-23 07:35:33 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-23 07:35:33 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-23 07:35:33 --> Model Class Initialized
DEBUG - 2011-08-23 07:35:33 --> Model Class Initialized
DEBUG - 2011-08-23 07:35:33 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-23 07:35:33 --> Database Driver Class Initialized
DEBUG - 2011-08-23 07:35:33 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-23 07:35:33 --> Config Class Initialized
DEBUG - 2011-08-23 07:35:33 --> Hooks Class Initialized
DEBUG - 2011-08-23 07:35:33 --> Utf8 Class Initialized
DEBUG - 2011-08-23 07:35:33 --> UTF-8 Support Enabled
DEBUG - 2011-08-23 07:35:33 --> Helper loaded: url_helper
DEBUG - 2011-08-23 07:35:33 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-23 07:35:33 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-23 07:35:33 --> URI Class Initialized
DEBUG - 2011-08-23 07:35:33 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-23 07:35:33 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-23 07:35:33 --> Final output sent to browser
DEBUG - 2011-08-23 07:35:33 --> Total execution time: 0.0296
DEBUG - 2011-08-23 07:35:33 --> Router Class Initialized
ERROR - 2011-08-23 07:35:33 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-23 07:43:39 --> Config Class Initialized
DEBUG - 2011-08-23 07:43:39 --> Hooks Class Initialized
DEBUG - 2011-08-23 07:43:39 --> Utf8 Class Initialized
DEBUG - 2011-08-23 07:43:39 --> UTF-8 Support Enabled
DEBUG - 2011-08-23 07:43:39 --> URI Class Initialized
DEBUG - 2011-08-23 07:43:39 --> Router Class Initialized
DEBUG - 2011-08-23 07:43:39 --> Output Class Initialized
DEBUG - 2011-08-23 07:43:39 --> Input Class Initialized
DEBUG - 2011-08-23 07:43:39 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-23 07:43:39 --> Language Class Initialized
DEBUG - 2011-08-23 07:43:39 --> Loader Class Initialized
DEBUG - 2011-08-23 07:43:39 --> Controller Class Initialized
DEBUG - 2011-08-23 07:43:39 --> Model Class Initialized
DEBUG - 2011-08-23 07:43:39 --> Model Class Initialized
DEBUG - 2011-08-23 07:43:39 --> Model Class Initialized
DEBUG - 2011-08-23 07:43:39 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-23 07:43:39 --> Database Driver Class Initialized
DEBUG - 2011-08-23 07:43:40 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-23 07:43:40 --> Helper loaded: url_helper
DEBUG - 2011-08-23 07:43:40 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-23 07:43:40 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-23 07:43:40 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-23 07:43:40 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-23 07:43:40 --> Final output sent to browser
DEBUG - 2011-08-23 07:43:40 --> Total execution time: 0.7907
DEBUG - 2011-08-23 07:43:42 --> Config Class Initialized
DEBUG - 2011-08-23 07:43:42 --> Hooks Class Initialized
DEBUG - 2011-08-23 07:43:42 --> Utf8 Class Initialized
DEBUG - 2011-08-23 07:43:42 --> UTF-8 Support Enabled
DEBUG - 2011-08-23 07:43:42 --> URI Class Initialized
DEBUG - 2011-08-23 07:43:42 --> Router Class Initialized
ERROR - 2011-08-23 07:43:42 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-23 07:43:42 --> Config Class Initialized
DEBUG - 2011-08-23 07:43:42 --> Hooks Class Initialized
DEBUG - 2011-08-23 07:43:42 --> Utf8 Class Initialized
DEBUG - 2011-08-23 07:43:42 --> UTF-8 Support Enabled
DEBUG - 2011-08-23 07:43:42 --> URI Class Initialized
DEBUG - 2011-08-23 07:43:42 --> Router Class Initialized
ERROR - 2011-08-23 07:43:42 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-23 07:43:43 --> Config Class Initialized
DEBUG - 2011-08-23 07:43:43 --> Hooks Class Initialized
DEBUG - 2011-08-23 07:43:43 --> Utf8 Class Initialized
DEBUG - 2011-08-23 07:43:43 --> UTF-8 Support Enabled
DEBUG - 2011-08-23 07:43:43 --> URI Class Initialized
DEBUG - 2011-08-23 07:43:43 --> Router Class Initialized
ERROR - 2011-08-23 07:43:43 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-23 07:44:03 --> Config Class Initialized
DEBUG - 2011-08-23 07:44:03 --> Hooks Class Initialized
DEBUG - 2011-08-23 07:44:03 --> Utf8 Class Initialized
DEBUG - 2011-08-23 07:44:03 --> UTF-8 Support Enabled
DEBUG - 2011-08-23 07:44:03 --> URI Class Initialized
DEBUG - 2011-08-23 07:44:03 --> Router Class Initialized
DEBUG - 2011-08-23 07:44:03 --> Output Class Initialized
DEBUG - 2011-08-23 07:44:03 --> Input Class Initialized
DEBUG - 2011-08-23 07:44:03 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-23 07:44:03 --> Language Class Initialized
DEBUG - 2011-08-23 07:44:03 --> Loader Class Initialized
DEBUG - 2011-08-23 07:44:03 --> Controller Class Initialized
DEBUG - 2011-08-23 07:44:03 --> Model Class Initialized
DEBUG - 2011-08-23 07:44:03 --> Model Class Initialized
DEBUG - 2011-08-23 07:44:03 --> Model Class Initialized
DEBUG - 2011-08-23 07:44:03 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-23 07:44:03 --> Database Driver Class Initialized
DEBUG - 2011-08-23 07:44:04 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-23 07:44:04 --> Helper loaded: url_helper
DEBUG - 2011-08-23 07:44:04 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-23 07:44:04 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-23 07:44:04 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-23 07:44:04 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-23 07:44:04 --> Final output sent to browser
DEBUG - 2011-08-23 07:44:04 --> Total execution time: 0.8898
DEBUG - 2011-08-23 07:44:06 --> Config Class Initialized
DEBUG - 2011-08-23 07:44:06 --> Hooks Class Initialized
DEBUG - 2011-08-23 07:44:06 --> Utf8 Class Initialized
DEBUG - 2011-08-23 07:44:06 --> UTF-8 Support Enabled
DEBUG - 2011-08-23 07:44:06 --> URI Class Initialized
DEBUG - 2011-08-23 07:44:06 --> Router Class Initialized
DEBUG - 2011-08-23 07:44:06 --> Output Class Initialized
DEBUG - 2011-08-23 07:44:06 --> Input Class Initialized
DEBUG - 2011-08-23 07:44:06 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-23 07:44:06 --> Language Class Initialized
DEBUG - 2011-08-23 07:44:06 --> Loader Class Initialized
DEBUG - 2011-08-23 07:44:06 --> Controller Class Initialized
DEBUG - 2011-08-23 07:44:06 --> Model Class Initialized
DEBUG - 2011-08-23 07:44:06 --> Model Class Initialized
DEBUG - 2011-08-23 07:44:06 --> Model Class Initialized
DEBUG - 2011-08-23 07:44:06 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-23 07:44:06 --> Database Driver Class Initialized
DEBUG - 2011-08-23 07:44:06 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-23 07:44:06 --> Helper loaded: url_helper
DEBUG - 2011-08-23 07:44:06 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-23 07:44:06 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-23 07:44:06 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-23 07:44:06 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-23 07:44:06 --> Final output sent to browser
DEBUG - 2011-08-23 07:44:06 --> Total execution time: 0.0463
DEBUG - 2011-08-23 07:44:13 --> Config Class Initialized
DEBUG - 2011-08-23 07:44:13 --> Hooks Class Initialized
DEBUG - 2011-08-23 07:44:13 --> Utf8 Class Initialized
DEBUG - 2011-08-23 07:44:13 --> UTF-8 Support Enabled
DEBUG - 2011-08-23 07:44:13 --> URI Class Initialized
DEBUG - 2011-08-23 07:44:13 --> Router Class Initialized
DEBUG - 2011-08-23 07:44:13 --> Output Class Initialized
DEBUG - 2011-08-23 07:44:13 --> Input Class Initialized
DEBUG - 2011-08-23 07:44:13 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-23 07:44:13 --> Language Class Initialized
DEBUG - 2011-08-23 07:44:13 --> Loader Class Initialized
DEBUG - 2011-08-23 07:44:13 --> Controller Class Initialized
DEBUG - 2011-08-23 07:44:13 --> Model Class Initialized
DEBUG - 2011-08-23 07:44:13 --> Model Class Initialized
DEBUG - 2011-08-23 07:44:13 --> Model Class Initialized
DEBUG - 2011-08-23 07:44:13 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-23 07:44:13 --> Database Driver Class Initialized
DEBUG - 2011-08-23 07:44:14 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-23 07:44:14 --> Helper loaded: url_helper
DEBUG - 2011-08-23 07:44:14 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-23 07:44:14 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-23 07:44:14 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-23 07:44:14 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-23 07:44:14 --> Final output sent to browser
DEBUG - 2011-08-23 07:44:14 --> Total execution time: 0.2223
DEBUG - 2011-08-23 07:44:18 --> Config Class Initialized
DEBUG - 2011-08-23 07:44:18 --> Hooks Class Initialized
DEBUG - 2011-08-23 07:44:18 --> Utf8 Class Initialized
DEBUG - 2011-08-23 07:44:18 --> UTF-8 Support Enabled
DEBUG - 2011-08-23 07:44:18 --> URI Class Initialized
DEBUG - 2011-08-23 07:44:18 --> Router Class Initialized
DEBUG - 2011-08-23 07:44:18 --> Output Class Initialized
DEBUG - 2011-08-23 07:44:18 --> Input Class Initialized
DEBUG - 2011-08-23 07:44:18 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-23 07:44:18 --> Language Class Initialized
DEBUG - 2011-08-23 07:44:18 --> Loader Class Initialized
DEBUG - 2011-08-23 07:44:18 --> Controller Class Initialized
DEBUG - 2011-08-23 07:44:18 --> Model Class Initialized
DEBUG - 2011-08-23 07:44:18 --> Model Class Initialized
DEBUG - 2011-08-23 07:44:18 --> Model Class Initialized
DEBUG - 2011-08-23 07:44:18 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-23 07:44:18 --> Database Driver Class Initialized
DEBUG - 2011-08-23 07:44:18 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-23 07:44:18 --> Helper loaded: url_helper
DEBUG - 2011-08-23 07:44:18 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-23 07:44:18 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-23 07:44:18 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-23 07:44:18 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-23 07:44:18 --> Final output sent to browser
DEBUG - 2011-08-23 07:44:18 --> Total execution time: 0.0462
DEBUG - 2011-08-23 07:44:21 --> Config Class Initialized
DEBUG - 2011-08-23 07:44:21 --> Hooks Class Initialized
DEBUG - 2011-08-23 07:44:21 --> Utf8 Class Initialized
DEBUG - 2011-08-23 07:44:21 --> UTF-8 Support Enabled
DEBUG - 2011-08-23 07:44:21 --> URI Class Initialized
DEBUG - 2011-08-23 07:44:21 --> Router Class Initialized
DEBUG - 2011-08-23 07:44:21 --> Output Class Initialized
DEBUG - 2011-08-23 07:44:21 --> Input Class Initialized
DEBUG - 2011-08-23 07:44:21 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-23 07:44:21 --> Language Class Initialized
DEBUG - 2011-08-23 07:44:21 --> Loader Class Initialized
DEBUG - 2011-08-23 07:44:21 --> Controller Class Initialized
DEBUG - 2011-08-23 07:44:21 --> Model Class Initialized
DEBUG - 2011-08-23 07:44:21 --> Model Class Initialized
DEBUG - 2011-08-23 07:44:21 --> Model Class Initialized
DEBUG - 2011-08-23 07:44:21 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-23 07:44:21 --> Database Driver Class Initialized
DEBUG - 2011-08-23 07:44:21 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-23 07:44:21 --> Helper loaded: url_helper
DEBUG - 2011-08-23 07:44:21 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-23 07:44:21 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-23 07:44:21 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-23 07:44:21 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-23 07:44:21 --> Final output sent to browser
DEBUG - 2011-08-23 07:44:21 --> Total execution time: 0.2211
DEBUG - 2011-08-23 07:44:23 --> Config Class Initialized
DEBUG - 2011-08-23 07:44:23 --> Hooks Class Initialized
DEBUG - 2011-08-23 07:44:23 --> Utf8 Class Initialized
DEBUG - 2011-08-23 07:44:23 --> UTF-8 Support Enabled
DEBUG - 2011-08-23 07:44:23 --> URI Class Initialized
DEBUG - 2011-08-23 07:44:23 --> Router Class Initialized
DEBUG - 2011-08-23 07:44:23 --> Output Class Initialized
DEBUG - 2011-08-23 07:44:23 --> Input Class Initialized
DEBUG - 2011-08-23 07:44:23 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-23 07:44:23 --> Language Class Initialized
DEBUG - 2011-08-23 07:44:23 --> Loader Class Initialized
DEBUG - 2011-08-23 07:44:23 --> Controller Class Initialized
DEBUG - 2011-08-23 07:44:23 --> Model Class Initialized
DEBUG - 2011-08-23 07:44:23 --> Model Class Initialized
DEBUG - 2011-08-23 07:44:23 --> Model Class Initialized
DEBUG - 2011-08-23 07:44:23 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-23 07:44:23 --> Database Driver Class Initialized
DEBUG - 2011-08-23 07:44:23 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-23 07:44:23 --> Helper loaded: url_helper
DEBUG - 2011-08-23 07:44:23 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-23 07:44:23 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-23 07:44:23 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-23 07:44:23 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-23 07:44:23 --> Final output sent to browser
DEBUG - 2011-08-23 07:44:23 --> Total execution time: 0.0545
DEBUG - 2011-08-23 07:44:25 --> Config Class Initialized
DEBUG - 2011-08-23 07:44:25 --> Hooks Class Initialized
DEBUG - 2011-08-23 07:44:25 --> Utf8 Class Initialized
DEBUG - 2011-08-23 07:44:25 --> UTF-8 Support Enabled
DEBUG - 2011-08-23 07:44:25 --> URI Class Initialized
DEBUG - 2011-08-23 07:44:25 --> Router Class Initialized
DEBUG - 2011-08-23 07:44:25 --> Output Class Initialized
DEBUG - 2011-08-23 07:44:25 --> Input Class Initialized
DEBUG - 2011-08-23 07:44:25 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-23 07:44:25 --> Language Class Initialized
DEBUG - 2011-08-23 07:44:25 --> Loader Class Initialized
DEBUG - 2011-08-23 07:44:25 --> Controller Class Initialized
DEBUG - 2011-08-23 07:44:25 --> Model Class Initialized
DEBUG - 2011-08-23 07:44:25 --> Model Class Initialized
DEBUG - 2011-08-23 07:44:25 --> Model Class Initialized
DEBUG - 2011-08-23 07:44:25 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-23 07:44:25 --> Database Driver Class Initialized
DEBUG - 2011-08-23 07:44:25 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-23 07:44:25 --> Helper loaded: url_helper
DEBUG - 2011-08-23 07:44:25 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-23 07:44:25 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-23 07:44:25 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-23 07:44:25 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-23 07:44:25 --> Final output sent to browser
DEBUG - 2011-08-23 07:44:25 --> Total execution time: 0.0648
DEBUG - 2011-08-23 07:45:00 --> Config Class Initialized
DEBUG - 2011-08-23 07:45:00 --> Hooks Class Initialized
DEBUG - 2011-08-23 07:45:00 --> Utf8 Class Initialized
DEBUG - 2011-08-23 07:45:00 --> UTF-8 Support Enabled
DEBUG - 2011-08-23 07:45:00 --> URI Class Initialized
DEBUG - 2011-08-23 07:45:00 --> Router Class Initialized
DEBUG - 2011-08-23 07:45:00 --> Output Class Initialized
DEBUG - 2011-08-23 07:45:00 --> Input Class Initialized
DEBUG - 2011-08-23 07:45:00 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-23 07:45:00 --> Language Class Initialized
DEBUG - 2011-08-23 07:45:00 --> Loader Class Initialized
DEBUG - 2011-08-23 07:45:00 --> Controller Class Initialized
DEBUG - 2011-08-23 07:45:00 --> Model Class Initialized
DEBUG - 2011-08-23 07:45:00 --> Model Class Initialized
DEBUG - 2011-08-23 07:45:00 --> Model Class Initialized
DEBUG - 2011-08-23 07:45:00 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-23 07:45:00 --> Database Driver Class Initialized
DEBUG - 2011-08-23 07:45:01 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-23 07:45:01 --> Helper loaded: url_helper
DEBUG - 2011-08-23 07:45:01 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-23 07:45:01 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-23 07:45:01 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-23 07:45:01 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-23 07:45:01 --> Final output sent to browser
DEBUG - 2011-08-23 07:45:01 --> Total execution time: 0.9350
DEBUG - 2011-08-23 07:45:03 --> Config Class Initialized
DEBUG - 2011-08-23 07:45:03 --> Hooks Class Initialized
DEBUG - 2011-08-23 07:45:03 --> Utf8 Class Initialized
DEBUG - 2011-08-23 07:45:03 --> UTF-8 Support Enabled
DEBUG - 2011-08-23 07:45:03 --> URI Class Initialized
DEBUG - 2011-08-23 07:45:03 --> Router Class Initialized
DEBUG - 2011-08-23 07:45:03 --> Output Class Initialized
DEBUG - 2011-08-23 07:45:03 --> Input Class Initialized
DEBUG - 2011-08-23 07:45:03 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-23 07:45:03 --> Language Class Initialized
DEBUG - 2011-08-23 07:45:03 --> Loader Class Initialized
DEBUG - 2011-08-23 07:45:03 --> Controller Class Initialized
DEBUG - 2011-08-23 07:45:03 --> Model Class Initialized
DEBUG - 2011-08-23 07:45:03 --> Model Class Initialized
DEBUG - 2011-08-23 07:45:03 --> Model Class Initialized
DEBUG - 2011-08-23 07:45:03 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-23 07:45:03 --> Database Driver Class Initialized
DEBUG - 2011-08-23 07:45:03 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-23 07:45:03 --> Helper loaded: url_helper
DEBUG - 2011-08-23 07:45:03 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-23 07:45:03 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-23 07:45:03 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-23 07:45:03 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-23 07:45:03 --> Final output sent to browser
DEBUG - 2011-08-23 07:45:03 --> Total execution time: 0.2155
DEBUG - 2011-08-23 07:45:03 --> Config Class Initialized
DEBUG - 2011-08-23 07:45:03 --> Hooks Class Initialized
DEBUG - 2011-08-23 07:45:03 --> Utf8 Class Initialized
DEBUG - 2011-08-23 07:45:03 --> UTF-8 Support Enabled
DEBUG - 2011-08-23 07:45:03 --> URI Class Initialized
DEBUG - 2011-08-23 07:45:03 --> Router Class Initialized
DEBUG - 2011-08-23 07:45:03 --> Output Class Initialized
DEBUG - 2011-08-23 07:45:03 --> Input Class Initialized
DEBUG - 2011-08-23 07:45:03 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-23 07:45:03 --> Language Class Initialized
DEBUG - 2011-08-23 07:45:03 --> Loader Class Initialized
DEBUG - 2011-08-23 07:45:03 --> Controller Class Initialized
DEBUG - 2011-08-23 07:45:03 --> Model Class Initialized
DEBUG - 2011-08-23 07:45:03 --> Model Class Initialized
DEBUG - 2011-08-23 07:45:03 --> Model Class Initialized
DEBUG - 2011-08-23 07:45:03 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-23 07:45:03 --> Database Driver Class Initialized
DEBUG - 2011-08-23 07:45:03 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-23 07:45:03 --> Helper loaded: url_helper
DEBUG - 2011-08-23 07:45:03 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-23 07:45:03 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-23 07:45:03 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-23 07:45:03 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-23 07:45:03 --> Final output sent to browser
DEBUG - 2011-08-23 07:45:03 --> Total execution time: 0.2026
DEBUG - 2011-08-23 07:45:12 --> Config Class Initialized
DEBUG - 2011-08-23 07:45:12 --> Hooks Class Initialized
DEBUG - 2011-08-23 07:45:12 --> Utf8 Class Initialized
DEBUG - 2011-08-23 07:45:12 --> UTF-8 Support Enabled
DEBUG - 2011-08-23 07:45:12 --> URI Class Initialized
DEBUG - 2011-08-23 07:45:12 --> Router Class Initialized
DEBUG - 2011-08-23 07:45:12 --> Output Class Initialized
DEBUG - 2011-08-23 07:45:12 --> Input Class Initialized
DEBUG - 2011-08-23 07:45:12 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-23 07:45:12 --> Language Class Initialized
DEBUG - 2011-08-23 07:45:12 --> Loader Class Initialized
DEBUG - 2011-08-23 07:45:12 --> Controller Class Initialized
DEBUG - 2011-08-23 07:45:12 --> Model Class Initialized
DEBUG - 2011-08-23 07:45:12 --> Model Class Initialized
DEBUG - 2011-08-23 07:45:12 --> Model Class Initialized
DEBUG - 2011-08-23 07:45:12 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-23 07:45:12 --> Database Driver Class Initialized
DEBUG - 2011-08-23 07:45:13 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-23 07:45:13 --> Helper loaded: url_helper
DEBUG - 2011-08-23 07:45:13 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-23 07:45:13 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-23 07:45:13 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-23 07:45:13 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-23 07:45:13 --> Final output sent to browser
DEBUG - 2011-08-23 07:45:13 --> Total execution time: 0.7626
DEBUG - 2011-08-23 07:45:18 --> Config Class Initialized
DEBUG - 2011-08-23 07:45:18 --> Hooks Class Initialized
DEBUG - 2011-08-23 07:45:18 --> Utf8 Class Initialized
DEBUG - 2011-08-23 07:45:18 --> UTF-8 Support Enabled
DEBUG - 2011-08-23 07:45:18 --> URI Class Initialized
DEBUG - 2011-08-23 07:45:18 --> Router Class Initialized
DEBUG - 2011-08-23 07:45:18 --> Output Class Initialized
DEBUG - 2011-08-23 07:45:18 --> Input Class Initialized
DEBUG - 2011-08-23 07:45:18 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-23 07:45:18 --> Language Class Initialized
DEBUG - 2011-08-23 07:45:18 --> Loader Class Initialized
DEBUG - 2011-08-23 07:45:18 --> Controller Class Initialized
DEBUG - 2011-08-23 07:45:18 --> Model Class Initialized
DEBUG - 2011-08-23 07:45:18 --> Model Class Initialized
DEBUG - 2011-08-23 07:45:18 --> Model Class Initialized
DEBUG - 2011-08-23 07:45:18 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-23 07:45:18 --> Database Driver Class Initialized
DEBUG - 2011-08-23 07:45:18 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-23 07:45:18 --> Helper loaded: url_helper
DEBUG - 2011-08-23 07:45:18 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-23 07:45:18 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-23 07:45:18 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-23 07:45:18 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-23 07:45:18 --> Final output sent to browser
DEBUG - 2011-08-23 07:45:18 --> Total execution time: 0.0469
DEBUG - 2011-08-23 07:45:32 --> Config Class Initialized
DEBUG - 2011-08-23 07:45:32 --> Hooks Class Initialized
DEBUG - 2011-08-23 07:45:32 --> Utf8 Class Initialized
DEBUG - 2011-08-23 07:45:32 --> UTF-8 Support Enabled
DEBUG - 2011-08-23 07:45:32 --> URI Class Initialized
DEBUG - 2011-08-23 07:45:32 --> Router Class Initialized
DEBUG - 2011-08-23 07:45:32 --> Output Class Initialized
DEBUG - 2011-08-23 07:45:32 --> Input Class Initialized
DEBUG - 2011-08-23 07:45:32 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-23 07:45:32 --> Language Class Initialized
DEBUG - 2011-08-23 07:45:32 --> Loader Class Initialized
DEBUG - 2011-08-23 07:45:32 --> Controller Class Initialized
DEBUG - 2011-08-23 07:45:32 --> Model Class Initialized
DEBUG - 2011-08-23 07:45:32 --> Model Class Initialized
DEBUG - 2011-08-23 07:45:32 --> Model Class Initialized
DEBUG - 2011-08-23 07:45:32 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-23 07:45:32 --> Database Driver Class Initialized
DEBUG - 2011-08-23 07:45:32 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-23 07:45:32 --> Helper loaded: url_helper
DEBUG - 2011-08-23 07:45:32 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-23 07:45:32 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-23 07:45:32 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-23 07:45:32 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-23 07:45:32 --> Final output sent to browser
DEBUG - 2011-08-23 07:45:32 --> Total execution time: 0.4345
DEBUG - 2011-08-23 07:45:35 --> Config Class Initialized
DEBUG - 2011-08-23 07:45:35 --> Hooks Class Initialized
DEBUG - 2011-08-23 07:45:35 --> Utf8 Class Initialized
DEBUG - 2011-08-23 07:45:35 --> UTF-8 Support Enabled
DEBUG - 2011-08-23 07:45:35 --> URI Class Initialized
DEBUG - 2011-08-23 07:45:35 --> Router Class Initialized
DEBUG - 2011-08-23 07:45:35 --> Output Class Initialized
DEBUG - 2011-08-23 07:45:35 --> Input Class Initialized
DEBUG - 2011-08-23 07:45:35 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-23 07:45:35 --> Language Class Initialized
DEBUG - 2011-08-23 07:45:35 --> Loader Class Initialized
DEBUG - 2011-08-23 07:45:35 --> Controller Class Initialized
DEBUG - 2011-08-23 07:45:35 --> Model Class Initialized
DEBUG - 2011-08-23 07:45:35 --> Model Class Initialized
DEBUG - 2011-08-23 07:45:35 --> Model Class Initialized
DEBUG - 2011-08-23 07:45:35 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-23 07:45:35 --> Database Driver Class Initialized
DEBUG - 2011-08-23 07:45:35 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-23 07:45:35 --> Helper loaded: url_helper
DEBUG - 2011-08-23 07:45:35 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-23 07:45:35 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-23 07:45:35 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-23 07:45:35 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-23 07:45:35 --> Final output sent to browser
DEBUG - 2011-08-23 07:45:35 --> Total execution time: 0.0600
DEBUG - 2011-08-23 08:48:56 --> Config Class Initialized
DEBUG - 2011-08-23 08:48:56 --> Hooks Class Initialized
DEBUG - 2011-08-23 08:48:56 --> Utf8 Class Initialized
DEBUG - 2011-08-23 08:48:56 --> UTF-8 Support Enabled
DEBUG - 2011-08-23 08:48:56 --> URI Class Initialized
DEBUG - 2011-08-23 08:48:56 --> Router Class Initialized
DEBUG - 2011-08-23 08:48:56 --> Output Class Initialized
DEBUG - 2011-08-23 08:48:56 --> Input Class Initialized
DEBUG - 2011-08-23 08:48:56 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-23 08:48:56 --> Language Class Initialized
DEBUG - 2011-08-23 08:48:56 --> Loader Class Initialized
DEBUG - 2011-08-23 08:48:56 --> Controller Class Initialized
ERROR - 2011-08-23 08:48:56 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-23 08:48:56 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-23 08:48:56 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-23 08:48:56 --> Model Class Initialized
DEBUG - 2011-08-23 08:48:56 --> Model Class Initialized
DEBUG - 2011-08-23 08:48:56 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-23 08:48:56 --> Database Driver Class Initialized
DEBUG - 2011-08-23 08:48:56 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-23 08:48:56 --> Helper loaded: url_helper
DEBUG - 2011-08-23 08:48:56 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-23 08:48:56 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-23 08:48:56 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-23 08:48:56 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-23 08:48:56 --> Final output sent to browser
DEBUG - 2011-08-23 08:48:56 --> Total execution time: 0.2659
DEBUG - 2011-08-23 08:48:57 --> Config Class Initialized
DEBUG - 2011-08-23 08:48:57 --> Hooks Class Initialized
DEBUG - 2011-08-23 08:48:57 --> Utf8 Class Initialized
DEBUG - 2011-08-23 08:48:57 --> UTF-8 Support Enabled
DEBUG - 2011-08-23 08:48:57 --> URI Class Initialized
DEBUG - 2011-08-23 08:48:57 --> Router Class Initialized
DEBUG - 2011-08-23 08:48:57 --> Output Class Initialized
DEBUG - 2011-08-23 08:48:57 --> Input Class Initialized
DEBUG - 2011-08-23 08:48:57 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-23 08:48:57 --> Language Class Initialized
DEBUG - 2011-08-23 08:48:57 --> Loader Class Initialized
DEBUG - 2011-08-23 08:48:57 --> Controller Class Initialized
DEBUG - 2011-08-23 08:48:57 --> Model Class Initialized
DEBUG - 2011-08-23 08:48:57 --> Model Class Initialized
DEBUG - 2011-08-23 08:48:57 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-23 08:48:57 --> Database Driver Class Initialized
DEBUG - 2011-08-23 08:48:57 --> Final output sent to browser
DEBUG - 2011-08-23 08:48:57 --> Total execution time: 0.5979
DEBUG - 2011-08-23 08:48:58 --> Config Class Initialized
DEBUG - 2011-08-23 08:48:58 --> Hooks Class Initialized
DEBUG - 2011-08-23 08:48:58 --> Utf8 Class Initialized
DEBUG - 2011-08-23 08:48:58 --> UTF-8 Support Enabled
DEBUG - 2011-08-23 08:48:58 --> URI Class Initialized
DEBUG - 2011-08-23 08:48:58 --> Router Class Initialized
ERROR - 2011-08-23 08:48:58 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-23 08:48:58 --> Config Class Initialized
DEBUG - 2011-08-23 08:48:58 --> Hooks Class Initialized
DEBUG - 2011-08-23 08:48:58 --> Utf8 Class Initialized
DEBUG - 2011-08-23 08:48:58 --> UTF-8 Support Enabled
DEBUG - 2011-08-23 08:48:58 --> URI Class Initialized
DEBUG - 2011-08-23 08:48:58 --> Router Class Initialized
ERROR - 2011-08-23 08:48:58 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-23 08:49:10 --> Config Class Initialized
DEBUG - 2011-08-23 08:49:10 --> Hooks Class Initialized
DEBUG - 2011-08-23 08:49:10 --> Utf8 Class Initialized
DEBUG - 2011-08-23 08:49:10 --> UTF-8 Support Enabled
DEBUG - 2011-08-23 08:49:10 --> URI Class Initialized
DEBUG - 2011-08-23 08:49:10 --> Router Class Initialized
DEBUG - 2011-08-23 08:49:10 --> Output Class Initialized
DEBUG - 2011-08-23 08:49:10 --> Input Class Initialized
DEBUG - 2011-08-23 08:49:10 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-23 08:49:10 --> Language Class Initialized
DEBUG - 2011-08-23 08:49:10 --> Loader Class Initialized
DEBUG - 2011-08-23 08:49:10 --> Controller Class Initialized
ERROR - 2011-08-23 08:49:10 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-23 08:49:10 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-23 08:49:10 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-23 08:49:10 --> Model Class Initialized
DEBUG - 2011-08-23 08:49:10 --> Model Class Initialized
DEBUG - 2011-08-23 08:49:10 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-23 08:49:10 --> Database Driver Class Initialized
DEBUG - 2011-08-23 08:49:10 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-23 08:49:10 --> Helper loaded: url_helper
DEBUG - 2011-08-23 08:49:10 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-23 08:49:10 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-23 08:49:10 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-23 08:49:10 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-23 08:49:10 --> Final output sent to browser
DEBUG - 2011-08-23 08:49:10 --> Total execution time: 0.0297
DEBUG - 2011-08-23 08:49:11 --> Config Class Initialized
DEBUG - 2011-08-23 08:49:11 --> Hooks Class Initialized
DEBUG - 2011-08-23 08:49:11 --> Utf8 Class Initialized
DEBUG - 2011-08-23 08:49:11 --> UTF-8 Support Enabled
DEBUG - 2011-08-23 08:49:11 --> URI Class Initialized
DEBUG - 2011-08-23 08:49:11 --> Router Class Initialized
DEBUG - 2011-08-23 08:49:11 --> Output Class Initialized
DEBUG - 2011-08-23 08:49:11 --> Input Class Initialized
DEBUG - 2011-08-23 08:49:11 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-23 08:49:11 --> Language Class Initialized
DEBUG - 2011-08-23 08:49:11 --> Loader Class Initialized
DEBUG - 2011-08-23 08:49:11 --> Controller Class Initialized
DEBUG - 2011-08-23 08:49:11 --> Model Class Initialized
DEBUG - 2011-08-23 08:49:11 --> Model Class Initialized
DEBUG - 2011-08-23 08:49:11 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-23 08:49:11 --> Database Driver Class Initialized
DEBUG - 2011-08-23 08:49:11 --> Final output sent to browser
DEBUG - 2011-08-23 08:49:11 --> Total execution time: 0.5653
DEBUG - 2011-08-23 08:49:12 --> Config Class Initialized
DEBUG - 2011-08-23 08:49:12 --> Hooks Class Initialized
DEBUG - 2011-08-23 08:49:12 --> Utf8 Class Initialized
DEBUG - 2011-08-23 08:49:12 --> UTF-8 Support Enabled
DEBUG - 2011-08-23 08:49:12 --> URI Class Initialized
DEBUG - 2011-08-23 08:49:12 --> Router Class Initialized
ERROR - 2011-08-23 08:49:12 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-23 08:50:27 --> Config Class Initialized
DEBUG - 2011-08-23 08:50:27 --> Hooks Class Initialized
DEBUG - 2011-08-23 08:50:27 --> Utf8 Class Initialized
DEBUG - 2011-08-23 08:50:27 --> UTF-8 Support Enabled
DEBUG - 2011-08-23 08:50:27 --> URI Class Initialized
DEBUG - 2011-08-23 08:50:27 --> Router Class Initialized
DEBUG - 2011-08-23 08:50:27 --> Output Class Initialized
DEBUG - 2011-08-23 08:50:27 --> Input Class Initialized
DEBUG - 2011-08-23 08:50:27 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-23 08:50:27 --> Language Class Initialized
DEBUG - 2011-08-23 08:50:27 --> Loader Class Initialized
DEBUG - 2011-08-23 08:50:27 --> Controller Class Initialized
DEBUG - 2011-08-23 08:50:27 --> Model Class Initialized
DEBUG - 2011-08-23 08:50:27 --> Model Class Initialized
DEBUG - 2011-08-23 08:50:27 --> Model Class Initialized
DEBUG - 2011-08-23 08:50:27 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-23 08:50:27 --> Database Driver Class Initialized
DEBUG - 2011-08-23 08:50:27 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-23 08:50:27 --> Helper loaded: url_helper
DEBUG - 2011-08-23 08:50:27 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-23 08:50:27 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-23 08:50:27 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-23 08:50:27 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-23 08:50:27 --> Final output sent to browser
DEBUG - 2011-08-23 08:50:27 --> Total execution time: 0.3514
DEBUG - 2011-08-23 08:50:39 --> Config Class Initialized
DEBUG - 2011-08-23 08:50:39 --> Hooks Class Initialized
DEBUG - 2011-08-23 08:50:39 --> Utf8 Class Initialized
DEBUG - 2011-08-23 08:50:39 --> UTF-8 Support Enabled
DEBUG - 2011-08-23 08:50:39 --> URI Class Initialized
DEBUG - 2011-08-23 08:50:39 --> Router Class Initialized
DEBUG - 2011-08-23 08:50:39 --> Output Class Initialized
DEBUG - 2011-08-23 08:50:39 --> Input Class Initialized
DEBUG - 2011-08-23 08:50:39 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-23 08:50:39 --> Language Class Initialized
DEBUG - 2011-08-23 08:50:39 --> Loader Class Initialized
DEBUG - 2011-08-23 08:50:39 --> Controller Class Initialized
DEBUG - 2011-08-23 08:50:39 --> Model Class Initialized
DEBUG - 2011-08-23 08:50:39 --> Model Class Initialized
DEBUG - 2011-08-23 08:50:39 --> Model Class Initialized
DEBUG - 2011-08-23 08:50:39 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-23 08:50:39 --> Database Driver Class Initialized
DEBUG - 2011-08-23 08:50:39 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-23 08:50:39 --> Helper loaded: url_helper
DEBUG - 2011-08-23 08:50:39 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-23 08:50:39 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-23 08:50:39 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-23 08:50:39 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-23 08:50:39 --> Final output sent to browser
DEBUG - 2011-08-23 08:50:39 --> Total execution time: 0.1871
DEBUG - 2011-08-23 08:56:32 --> Config Class Initialized
DEBUG - 2011-08-23 08:56:32 --> Hooks Class Initialized
DEBUG - 2011-08-23 08:56:32 --> Utf8 Class Initialized
DEBUG - 2011-08-23 08:56:32 --> UTF-8 Support Enabled
DEBUG - 2011-08-23 08:56:32 --> URI Class Initialized
DEBUG - 2011-08-23 08:56:32 --> Router Class Initialized
DEBUG - 2011-08-23 08:56:32 --> Output Class Initialized
DEBUG - 2011-08-23 08:56:32 --> Input Class Initialized
DEBUG - 2011-08-23 08:56:32 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-23 08:56:32 --> Language Class Initialized
DEBUG - 2011-08-23 08:56:32 --> Loader Class Initialized
DEBUG - 2011-08-23 08:56:32 --> Controller Class Initialized
DEBUG - 2011-08-23 08:56:32 --> Model Class Initialized
DEBUG - 2011-08-23 08:56:32 --> Model Class Initialized
DEBUG - 2011-08-23 08:56:32 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-23 08:56:32 --> Database Driver Class Initialized
DEBUG - 2011-08-23 08:56:33 --> Final output sent to browser
DEBUG - 2011-08-23 08:56:33 --> Total execution time: 0.4872
DEBUG - 2011-08-23 09:05:18 --> Config Class Initialized
DEBUG - 2011-08-23 09:05:18 --> Hooks Class Initialized
DEBUG - 2011-08-23 09:05:18 --> Utf8 Class Initialized
DEBUG - 2011-08-23 09:05:18 --> UTF-8 Support Enabled
DEBUG - 2011-08-23 09:05:18 --> URI Class Initialized
DEBUG - 2011-08-23 09:05:18 --> Router Class Initialized
DEBUG - 2011-08-23 09:05:18 --> Output Class Initialized
DEBUG - 2011-08-23 09:05:18 --> Input Class Initialized
DEBUG - 2011-08-23 09:05:18 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-23 09:05:18 --> Language Class Initialized
DEBUG - 2011-08-23 09:05:18 --> Loader Class Initialized
DEBUG - 2011-08-23 09:05:18 --> Controller Class Initialized
DEBUG - 2011-08-23 09:05:18 --> Model Class Initialized
DEBUG - 2011-08-23 09:05:18 --> Model Class Initialized
DEBUG - 2011-08-23 09:05:18 --> Model Class Initialized
DEBUG - 2011-08-23 09:05:18 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-23 09:05:18 --> Database Driver Class Initialized
DEBUG - 2011-08-23 09:05:18 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-23 09:05:18 --> Helper loaded: url_helper
DEBUG - 2011-08-23 09:05:18 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-23 09:05:18 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-23 09:05:18 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-23 09:05:18 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-23 09:05:18 --> Final output sent to browser
DEBUG - 2011-08-23 09:05:18 --> Total execution time: 0.0440
DEBUG - 2011-08-23 09:05:21 --> Config Class Initialized
DEBUG - 2011-08-23 09:05:21 --> Hooks Class Initialized
DEBUG - 2011-08-23 09:05:21 --> Utf8 Class Initialized
DEBUG - 2011-08-23 09:05:21 --> UTF-8 Support Enabled
DEBUG - 2011-08-23 09:05:21 --> URI Class Initialized
DEBUG - 2011-08-23 09:05:21 --> Router Class Initialized
DEBUG - 2011-08-23 09:05:21 --> Output Class Initialized
DEBUG - 2011-08-23 09:05:21 --> Input Class Initialized
DEBUG - 2011-08-23 09:05:21 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-23 09:05:21 --> Language Class Initialized
DEBUG - 2011-08-23 09:05:21 --> Loader Class Initialized
DEBUG - 2011-08-23 09:05:21 --> Controller Class Initialized
ERROR - 2011-08-23 09:05:21 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-23 09:05:21 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-23 09:05:21 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-23 09:05:21 --> Model Class Initialized
DEBUG - 2011-08-23 09:05:21 --> Model Class Initialized
DEBUG - 2011-08-23 09:05:21 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-23 09:05:21 --> Database Driver Class Initialized
DEBUG - 2011-08-23 09:05:21 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-23 09:05:21 --> Helper loaded: url_helper
DEBUG - 2011-08-23 09:05:21 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-23 09:05:21 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-23 09:05:21 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-23 09:05:21 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-23 09:05:21 --> Final output sent to browser
DEBUG - 2011-08-23 09:05:21 --> Total execution time: 0.0287
DEBUG - 2011-08-23 09:05:23 --> Config Class Initialized
DEBUG - 2011-08-23 09:05:23 --> Hooks Class Initialized
DEBUG - 2011-08-23 09:05:23 --> Utf8 Class Initialized
DEBUG - 2011-08-23 09:05:23 --> UTF-8 Support Enabled
DEBUG - 2011-08-23 09:05:23 --> URI Class Initialized
DEBUG - 2011-08-23 09:05:23 --> Router Class Initialized
DEBUG - 2011-08-23 09:05:23 --> Output Class Initialized
DEBUG - 2011-08-23 09:05:23 --> Input Class Initialized
DEBUG - 2011-08-23 09:05:23 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-23 09:05:23 --> Language Class Initialized
DEBUG - 2011-08-23 09:05:23 --> Loader Class Initialized
DEBUG - 2011-08-23 09:05:23 --> Controller Class Initialized
DEBUG - 2011-08-23 09:05:23 --> Model Class Initialized
DEBUG - 2011-08-23 09:05:23 --> Model Class Initialized
DEBUG - 2011-08-23 09:05:23 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-23 09:05:23 --> Database Driver Class Initialized
DEBUG - 2011-08-23 09:05:24 --> Final output sent to browser
DEBUG - 2011-08-23 09:05:24 --> Total execution time: 0.7260
DEBUG - 2011-08-23 09:05:31 --> Config Class Initialized
DEBUG - 2011-08-23 09:05:31 --> Hooks Class Initialized
DEBUG - 2011-08-23 09:05:31 --> Utf8 Class Initialized
DEBUG - 2011-08-23 09:05:31 --> UTF-8 Support Enabled
DEBUG - 2011-08-23 09:05:31 --> URI Class Initialized
DEBUG - 2011-08-23 09:05:31 --> Router Class Initialized
DEBUG - 2011-08-23 09:05:31 --> Output Class Initialized
DEBUG - 2011-08-23 09:05:31 --> Input Class Initialized
DEBUG - 2011-08-23 09:05:31 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-23 09:05:31 --> Language Class Initialized
DEBUG - 2011-08-23 09:05:31 --> Loader Class Initialized
DEBUG - 2011-08-23 09:05:31 --> Controller Class Initialized
DEBUG - 2011-08-23 09:05:31 --> Model Class Initialized
DEBUG - 2011-08-23 09:05:31 --> Model Class Initialized
DEBUG - 2011-08-23 09:05:31 --> Model Class Initialized
DEBUG - 2011-08-23 09:05:31 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-23 09:05:31 --> Database Driver Class Initialized
DEBUG - 2011-08-23 09:05:32 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-23 09:05:32 --> Helper loaded: url_helper
DEBUG - 2011-08-23 09:05:32 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-23 09:05:32 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-23 09:05:32 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-23 09:05:32 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-23 09:05:32 --> Final output sent to browser
DEBUG - 2011-08-23 09:05:32 --> Total execution time: 0.4239
DEBUG - 2011-08-23 09:05:32 --> Config Class Initialized
DEBUG - 2011-08-23 09:05:32 --> Hooks Class Initialized
DEBUG - 2011-08-23 09:05:32 --> Utf8 Class Initialized
DEBUG - 2011-08-23 09:05:32 --> UTF-8 Support Enabled
DEBUG - 2011-08-23 09:05:32 --> URI Class Initialized
DEBUG - 2011-08-23 09:05:32 --> Router Class Initialized
ERROR - 2011-08-23 09:05:32 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-23 09:05:33 --> Config Class Initialized
DEBUG - 2011-08-23 09:05:33 --> Hooks Class Initialized
DEBUG - 2011-08-23 09:05:33 --> Utf8 Class Initialized
DEBUG - 2011-08-23 09:05:33 --> UTF-8 Support Enabled
DEBUG - 2011-08-23 09:05:33 --> URI Class Initialized
DEBUG - 2011-08-23 09:05:33 --> Router Class Initialized
DEBUG - 2011-08-23 09:05:33 --> Output Class Initialized
DEBUG - 2011-08-23 09:05:33 --> Input Class Initialized
DEBUG - 2011-08-23 09:05:33 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-23 09:05:33 --> Language Class Initialized
DEBUG - 2011-08-23 09:05:33 --> Loader Class Initialized
DEBUG - 2011-08-23 09:05:33 --> Controller Class Initialized
DEBUG - 2011-08-23 09:05:33 --> Model Class Initialized
DEBUG - 2011-08-23 09:05:33 --> Model Class Initialized
DEBUG - 2011-08-23 09:05:33 --> Model Class Initialized
DEBUG - 2011-08-23 09:05:33 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-23 09:05:33 --> Database Driver Class Initialized
DEBUG - 2011-08-23 09:05:33 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-23 09:05:33 --> Helper loaded: url_helper
DEBUG - 2011-08-23 09:05:33 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-23 09:05:33 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-23 09:05:33 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-23 09:05:33 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-23 09:05:33 --> Final output sent to browser
DEBUG - 2011-08-23 09:05:33 --> Total execution time: 0.0451
DEBUG - 2011-08-23 09:05:35 --> Config Class Initialized
DEBUG - 2011-08-23 09:05:35 --> Hooks Class Initialized
DEBUG - 2011-08-23 09:05:35 --> Utf8 Class Initialized
DEBUG - 2011-08-23 09:05:35 --> UTF-8 Support Enabled
DEBUG - 2011-08-23 09:05:35 --> URI Class Initialized
DEBUG - 2011-08-23 09:05:35 --> Router Class Initialized
ERROR - 2011-08-23 09:05:35 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-23 09:05:37 --> Config Class Initialized
DEBUG - 2011-08-23 09:05:37 --> Hooks Class Initialized
DEBUG - 2011-08-23 09:05:37 --> Utf8 Class Initialized
DEBUG - 2011-08-23 09:05:37 --> UTF-8 Support Enabled
DEBUG - 2011-08-23 09:05:37 --> URI Class Initialized
DEBUG - 2011-08-23 09:05:37 --> Router Class Initialized
ERROR - 2011-08-23 09:05:37 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-23 09:08:08 --> Config Class Initialized
DEBUG - 2011-08-23 09:08:08 --> Hooks Class Initialized
DEBUG - 2011-08-23 09:08:08 --> Utf8 Class Initialized
DEBUG - 2011-08-23 09:08:08 --> UTF-8 Support Enabled
DEBUG - 2011-08-23 09:08:08 --> URI Class Initialized
DEBUG - 2011-08-23 09:08:08 --> Router Class Initialized
DEBUG - 2011-08-23 09:08:08 --> No URI present. Default controller set.
DEBUG - 2011-08-23 09:08:08 --> Output Class Initialized
DEBUG - 2011-08-23 09:08:08 --> Input Class Initialized
DEBUG - 2011-08-23 09:08:08 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-23 09:08:08 --> Language Class Initialized
DEBUG - 2011-08-23 09:08:08 --> Loader Class Initialized
DEBUG - 2011-08-23 09:08:08 --> Controller Class Initialized
DEBUG - 2011-08-23 09:08:08 --> File loaded: application/views/splash/main.php
DEBUG - 2011-08-23 09:08:08 --> Helper loaded: url_helper
DEBUG - 2011-08-23 09:08:08 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-23 09:08:08 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-23 09:08:08 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-23 09:08:08 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-23 09:08:08 --> Final output sent to browser
DEBUG - 2011-08-23 09:08:08 --> Total execution time: 0.0497
DEBUG - 2011-08-23 09:13:59 --> Config Class Initialized
DEBUG - 2011-08-23 09:13:59 --> Hooks Class Initialized
DEBUG - 2011-08-23 09:13:59 --> Utf8 Class Initialized
DEBUG - 2011-08-23 09:13:59 --> UTF-8 Support Enabled
DEBUG - 2011-08-23 09:13:59 --> URI Class Initialized
DEBUG - 2011-08-23 09:13:59 --> Router Class Initialized
DEBUG - 2011-08-23 09:13:59 --> Output Class Initialized
DEBUG - 2011-08-23 09:13:59 --> Input Class Initialized
DEBUG - 2011-08-23 09:13:59 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-23 09:13:59 --> Language Class Initialized
DEBUG - 2011-08-23 09:13:59 --> Loader Class Initialized
DEBUG - 2011-08-23 09:13:59 --> Controller Class Initialized
ERROR - 2011-08-23 09:13:59 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-23 09:13:59 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-23 09:13:59 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-23 09:13:59 --> Model Class Initialized
DEBUG - 2011-08-23 09:13:59 --> Model Class Initialized
DEBUG - 2011-08-23 09:13:59 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-23 09:13:59 --> Database Driver Class Initialized
DEBUG - 2011-08-23 09:13:59 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-23 09:13:59 --> Helper loaded: url_helper
DEBUG - 2011-08-23 09:13:59 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-23 09:13:59 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-23 09:13:59 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-23 09:13:59 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-23 09:13:59 --> Final output sent to browser
DEBUG - 2011-08-23 09:13:59 --> Total execution time: 0.0284
DEBUG - 2011-08-23 09:14:00 --> Config Class Initialized
DEBUG - 2011-08-23 09:14:00 --> Hooks Class Initialized
DEBUG - 2011-08-23 09:14:00 --> Utf8 Class Initialized
DEBUG - 2011-08-23 09:14:00 --> UTF-8 Support Enabled
DEBUG - 2011-08-23 09:14:00 --> URI Class Initialized
DEBUG - 2011-08-23 09:14:00 --> Router Class Initialized
DEBUG - 2011-08-23 09:14:00 --> Output Class Initialized
DEBUG - 2011-08-23 09:14:00 --> Input Class Initialized
DEBUG - 2011-08-23 09:14:00 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-23 09:14:00 --> Language Class Initialized
DEBUG - 2011-08-23 09:14:00 --> Loader Class Initialized
DEBUG - 2011-08-23 09:14:00 --> Controller Class Initialized
DEBUG - 2011-08-23 09:14:00 --> Model Class Initialized
DEBUG - 2011-08-23 09:14:00 --> Model Class Initialized
DEBUG - 2011-08-23 09:14:00 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-23 09:14:00 --> Database Driver Class Initialized
DEBUG - 2011-08-23 09:14:00 --> Final output sent to browser
DEBUG - 2011-08-23 09:14:00 --> Total execution time: 0.8386
DEBUG - 2011-08-23 09:14:07 --> Config Class Initialized
DEBUG - 2011-08-23 09:14:07 --> Hooks Class Initialized
DEBUG - 2011-08-23 09:14:07 --> Utf8 Class Initialized
DEBUG - 2011-08-23 09:14:07 --> UTF-8 Support Enabled
DEBUG - 2011-08-23 09:14:07 --> URI Class Initialized
DEBUG - 2011-08-23 09:14:07 --> Router Class Initialized
ERROR - 2011-08-23 09:14:07 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-23 09:23:41 --> Config Class Initialized
DEBUG - 2011-08-23 09:23:41 --> Hooks Class Initialized
DEBUG - 2011-08-23 09:23:41 --> Utf8 Class Initialized
DEBUG - 2011-08-23 09:23:41 --> UTF-8 Support Enabled
DEBUG - 2011-08-23 09:23:41 --> URI Class Initialized
DEBUG - 2011-08-23 09:23:41 --> Router Class Initialized
DEBUG - 2011-08-23 09:23:41 --> Output Class Initialized
DEBUG - 2011-08-23 09:23:41 --> Input Class Initialized
DEBUG - 2011-08-23 09:23:41 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-23 09:23:41 --> Language Class Initialized
DEBUG - 2011-08-23 09:23:41 --> Loader Class Initialized
DEBUG - 2011-08-23 09:23:41 --> Controller Class Initialized
ERROR - 2011-08-23 09:23:41 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-23 09:23:41 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-23 09:23:41 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-23 09:23:41 --> Model Class Initialized
DEBUG - 2011-08-23 09:23:41 --> Model Class Initialized
DEBUG - 2011-08-23 09:23:41 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-23 09:23:41 --> Database Driver Class Initialized
DEBUG - 2011-08-23 09:23:41 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-23 09:23:41 --> Helper loaded: url_helper
DEBUG - 2011-08-23 09:23:41 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-23 09:23:41 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-23 09:23:41 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-23 09:23:41 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-23 09:23:41 --> Final output sent to browser
DEBUG - 2011-08-23 09:23:41 --> Total execution time: 0.0301
DEBUG - 2011-08-23 09:23:41 --> Config Class Initialized
DEBUG - 2011-08-23 09:23:41 --> Hooks Class Initialized
DEBUG - 2011-08-23 09:23:41 --> Utf8 Class Initialized
DEBUG - 2011-08-23 09:23:41 --> UTF-8 Support Enabled
DEBUG - 2011-08-23 09:23:41 --> URI Class Initialized
DEBUG - 2011-08-23 09:23:42 --> Router Class Initialized
DEBUG - 2011-08-23 09:23:42 --> Output Class Initialized
DEBUG - 2011-08-23 09:23:42 --> Input Class Initialized
DEBUG - 2011-08-23 09:23:42 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-23 09:23:42 --> Language Class Initialized
DEBUG - 2011-08-23 09:23:42 --> Loader Class Initialized
DEBUG - 2011-08-23 09:23:42 --> Controller Class Initialized
DEBUG - 2011-08-23 09:23:42 --> Model Class Initialized
DEBUG - 2011-08-23 09:23:42 --> Model Class Initialized
DEBUG - 2011-08-23 09:23:42 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-23 09:23:42 --> Database Driver Class Initialized
DEBUG - 2011-08-23 09:23:42 --> Final output sent to browser
DEBUG - 2011-08-23 09:23:42 --> Total execution time: 0.5957
DEBUG - 2011-08-23 09:23:43 --> Config Class Initialized
DEBUG - 2011-08-23 09:23:43 --> Hooks Class Initialized
DEBUG - 2011-08-23 09:23:43 --> Utf8 Class Initialized
DEBUG - 2011-08-23 09:23:43 --> UTF-8 Support Enabled
DEBUG - 2011-08-23 09:23:43 --> URI Class Initialized
DEBUG - 2011-08-23 09:23:43 --> Router Class Initialized
ERROR - 2011-08-23 09:23:43 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-23 09:23:44 --> Config Class Initialized
DEBUG - 2011-08-23 09:23:44 --> Hooks Class Initialized
DEBUG - 2011-08-23 09:23:44 --> Utf8 Class Initialized
DEBUG - 2011-08-23 09:23:44 --> UTF-8 Support Enabled
DEBUG - 2011-08-23 09:23:44 --> URI Class Initialized
DEBUG - 2011-08-23 09:23:44 --> Router Class Initialized
ERROR - 2011-08-23 09:23:44 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-23 09:23:44 --> Config Class Initialized
DEBUG - 2011-08-23 09:23:44 --> Hooks Class Initialized
DEBUG - 2011-08-23 09:23:44 --> Utf8 Class Initialized
DEBUG - 2011-08-23 09:23:44 --> UTF-8 Support Enabled
DEBUG - 2011-08-23 09:23:44 --> URI Class Initialized
DEBUG - 2011-08-23 09:23:44 --> Router Class Initialized
ERROR - 2011-08-23 09:23:44 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-23 09:43:35 --> Config Class Initialized
DEBUG - 2011-08-23 09:43:35 --> Hooks Class Initialized
DEBUG - 2011-08-23 09:43:35 --> Utf8 Class Initialized
DEBUG - 2011-08-23 09:43:35 --> UTF-8 Support Enabled
DEBUG - 2011-08-23 09:43:35 --> URI Class Initialized
DEBUG - 2011-08-23 09:43:35 --> Router Class Initialized
DEBUG - 2011-08-23 09:43:35 --> Output Class Initialized
DEBUG - 2011-08-23 09:43:35 --> Input Class Initialized
DEBUG - 2011-08-23 09:43:35 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-23 09:43:35 --> Language Class Initialized
DEBUG - 2011-08-23 09:43:35 --> Loader Class Initialized
DEBUG - 2011-08-23 09:43:35 --> Controller Class Initialized
ERROR - 2011-08-23 09:43:35 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-23 09:43:35 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-23 09:43:35 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-23 09:43:35 --> Model Class Initialized
DEBUG - 2011-08-23 09:43:35 --> Model Class Initialized
DEBUG - 2011-08-23 09:43:35 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-23 09:43:35 --> Database Driver Class Initialized
DEBUG - 2011-08-23 09:43:35 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-23 09:43:35 --> Helper loaded: url_helper
DEBUG - 2011-08-23 09:43:35 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-23 09:43:35 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-23 09:43:35 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-23 09:43:35 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-23 09:43:35 --> Final output sent to browser
DEBUG - 2011-08-23 09:43:35 --> Total execution time: 0.0440
DEBUG - 2011-08-23 10:18:32 --> Config Class Initialized
DEBUG - 2011-08-23 10:18:32 --> Hooks Class Initialized
DEBUG - 2011-08-23 10:18:32 --> Utf8 Class Initialized
DEBUG - 2011-08-23 10:18:32 --> UTF-8 Support Enabled
DEBUG - 2011-08-23 10:18:32 --> URI Class Initialized
DEBUG - 2011-08-23 10:18:32 --> Router Class Initialized
DEBUG - 2011-08-23 10:18:32 --> Output Class Initialized
DEBUG - 2011-08-23 10:18:32 --> Input Class Initialized
DEBUG - 2011-08-23 10:18:32 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-23 10:18:32 --> Language Class Initialized
DEBUG - 2011-08-23 10:18:32 --> Loader Class Initialized
DEBUG - 2011-08-23 10:18:32 --> Controller Class Initialized
ERROR - 2011-08-23 10:18:32 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-23 10:18:32 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-23 10:18:32 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-23 10:18:32 --> Model Class Initialized
DEBUG - 2011-08-23 10:18:32 --> Model Class Initialized
DEBUG - 2011-08-23 10:18:32 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-23 10:18:32 --> Database Driver Class Initialized
DEBUG - 2011-08-23 10:18:32 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-23 10:18:32 --> Helper loaded: url_helper
DEBUG - 2011-08-23 10:18:32 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-23 10:18:32 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-23 10:18:32 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-23 10:18:32 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-23 10:18:32 --> Final output sent to browser
DEBUG - 2011-08-23 10:18:32 --> Total execution time: 0.0778
DEBUG - 2011-08-23 10:18:33 --> Config Class Initialized
DEBUG - 2011-08-23 10:18:33 --> Hooks Class Initialized
DEBUG - 2011-08-23 10:18:33 --> Utf8 Class Initialized
DEBUG - 2011-08-23 10:18:33 --> UTF-8 Support Enabled
DEBUG - 2011-08-23 10:18:33 --> URI Class Initialized
DEBUG - 2011-08-23 10:18:33 --> Router Class Initialized
DEBUG - 2011-08-23 10:18:33 --> Output Class Initialized
DEBUG - 2011-08-23 10:18:33 --> Input Class Initialized
DEBUG - 2011-08-23 10:18:33 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-23 10:18:33 --> Language Class Initialized
DEBUG - 2011-08-23 10:18:33 --> Loader Class Initialized
DEBUG - 2011-08-23 10:18:33 --> Controller Class Initialized
DEBUG - 2011-08-23 10:18:33 --> Model Class Initialized
DEBUG - 2011-08-23 10:18:33 --> Model Class Initialized
DEBUG - 2011-08-23 10:18:33 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-23 10:18:33 --> Database Driver Class Initialized
DEBUG - 2011-08-23 10:18:34 --> Final output sent to browser
DEBUG - 2011-08-23 10:18:34 --> Total execution time: 0.9622
DEBUG - 2011-08-23 10:18:36 --> Config Class Initialized
DEBUG - 2011-08-23 10:18:36 --> Hooks Class Initialized
DEBUG - 2011-08-23 10:18:36 --> Utf8 Class Initialized
DEBUG - 2011-08-23 10:18:36 --> UTF-8 Support Enabled
DEBUG - 2011-08-23 10:18:36 --> URI Class Initialized
DEBUG - 2011-08-23 10:18:36 --> Router Class Initialized
ERROR - 2011-08-23 10:18:36 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-23 10:19:19 --> Config Class Initialized
DEBUG - 2011-08-23 10:19:19 --> Hooks Class Initialized
DEBUG - 2011-08-23 10:19:19 --> Utf8 Class Initialized
DEBUG - 2011-08-23 10:19:19 --> UTF-8 Support Enabled
DEBUG - 2011-08-23 10:19:19 --> URI Class Initialized
DEBUG - 2011-08-23 10:19:19 --> Router Class Initialized
DEBUG - 2011-08-23 10:19:19 --> Output Class Initialized
DEBUG - 2011-08-23 10:19:19 --> Input Class Initialized
DEBUG - 2011-08-23 10:19:19 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-23 10:19:19 --> Language Class Initialized
DEBUG - 2011-08-23 10:19:19 --> Loader Class Initialized
DEBUG - 2011-08-23 10:19:19 --> Controller Class Initialized
ERROR - 2011-08-23 10:19:19 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-23 10:19:19 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-23 10:19:19 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-23 10:19:19 --> Model Class Initialized
DEBUG - 2011-08-23 10:19:19 --> Model Class Initialized
DEBUG - 2011-08-23 10:19:19 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-23 10:19:19 --> Database Driver Class Initialized
DEBUG - 2011-08-23 10:19:19 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-23 10:19:19 --> Helper loaded: url_helper
DEBUG - 2011-08-23 10:19:19 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-23 10:19:19 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-23 10:19:19 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-23 10:19:19 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-23 10:19:19 --> Final output sent to browser
DEBUG - 2011-08-23 10:19:19 --> Total execution time: 0.0503
DEBUG - 2011-08-23 10:19:20 --> Config Class Initialized
DEBUG - 2011-08-23 10:19:20 --> Hooks Class Initialized
DEBUG - 2011-08-23 10:19:20 --> Utf8 Class Initialized
DEBUG - 2011-08-23 10:19:20 --> UTF-8 Support Enabled
DEBUG - 2011-08-23 10:19:20 --> URI Class Initialized
DEBUG - 2011-08-23 10:19:20 --> Router Class Initialized
DEBUG - 2011-08-23 10:19:20 --> Output Class Initialized
DEBUG - 2011-08-23 10:19:20 --> Input Class Initialized
DEBUG - 2011-08-23 10:19:20 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-23 10:19:20 --> Language Class Initialized
DEBUG - 2011-08-23 10:19:20 --> Loader Class Initialized
DEBUG - 2011-08-23 10:19:20 --> Controller Class Initialized
DEBUG - 2011-08-23 10:19:20 --> Model Class Initialized
DEBUG - 2011-08-23 10:19:20 --> Model Class Initialized
DEBUG - 2011-08-23 10:19:20 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-23 10:19:20 --> Database Driver Class Initialized
DEBUG - 2011-08-23 10:19:21 --> Final output sent to browser
DEBUG - 2011-08-23 10:19:21 --> Total execution time: 0.8210
DEBUG - 2011-08-23 10:19:22 --> Config Class Initialized
DEBUG - 2011-08-23 10:19:22 --> Hooks Class Initialized
DEBUG - 2011-08-23 10:19:22 --> Utf8 Class Initialized
DEBUG - 2011-08-23 10:19:22 --> UTF-8 Support Enabled
DEBUG - 2011-08-23 10:19:22 --> URI Class Initialized
DEBUG - 2011-08-23 10:19:22 --> Router Class Initialized
ERROR - 2011-08-23 10:19:22 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-23 10:19:26 --> Config Class Initialized
DEBUG - 2011-08-23 10:19:26 --> Hooks Class Initialized
DEBUG - 2011-08-23 10:19:26 --> Utf8 Class Initialized
DEBUG - 2011-08-23 10:19:26 --> UTF-8 Support Enabled
DEBUG - 2011-08-23 10:19:26 --> URI Class Initialized
DEBUG - 2011-08-23 10:19:26 --> Router Class Initialized
DEBUG - 2011-08-23 10:19:26 --> Output Class Initialized
DEBUG - 2011-08-23 10:19:26 --> Input Class Initialized
DEBUG - 2011-08-23 10:19:26 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-23 10:19:26 --> Language Class Initialized
DEBUG - 2011-08-23 10:19:26 --> Loader Class Initialized
DEBUG - 2011-08-23 10:19:26 --> Controller Class Initialized
ERROR - 2011-08-23 10:19:26 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-23 10:19:26 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-23 10:19:26 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-23 10:19:26 --> Model Class Initialized
DEBUG - 2011-08-23 10:19:26 --> Model Class Initialized
DEBUG - 2011-08-23 10:19:26 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-23 10:19:26 --> Database Driver Class Initialized
DEBUG - 2011-08-23 10:19:26 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-23 10:19:26 --> Helper loaded: url_helper
DEBUG - 2011-08-23 10:19:26 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-23 10:19:26 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-23 10:19:26 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-23 10:19:26 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-23 10:19:26 --> Final output sent to browser
DEBUG - 2011-08-23 10:19:26 --> Total execution time: 0.0504
DEBUG - 2011-08-23 10:19:26 --> Config Class Initialized
DEBUG - 2011-08-23 10:19:26 --> Hooks Class Initialized
DEBUG - 2011-08-23 10:19:26 --> Utf8 Class Initialized
DEBUG - 2011-08-23 10:19:26 --> UTF-8 Support Enabled
DEBUG - 2011-08-23 10:19:26 --> URI Class Initialized
DEBUG - 2011-08-23 10:19:26 --> Router Class Initialized
DEBUG - 2011-08-23 10:19:26 --> Output Class Initialized
DEBUG - 2011-08-23 10:19:26 --> Input Class Initialized
DEBUG - 2011-08-23 10:19:26 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-23 10:19:26 --> Language Class Initialized
DEBUG - 2011-08-23 10:19:26 --> Loader Class Initialized
DEBUG - 2011-08-23 10:19:26 --> Controller Class Initialized
DEBUG - 2011-08-23 10:19:26 --> Model Class Initialized
DEBUG - 2011-08-23 10:19:26 --> Model Class Initialized
DEBUG - 2011-08-23 10:19:26 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-23 10:19:26 --> Database Driver Class Initialized
DEBUG - 2011-08-23 10:19:27 --> Final output sent to browser
DEBUG - 2011-08-23 10:19:27 --> Total execution time: 0.5519
DEBUG - 2011-08-23 10:19:29 --> Config Class Initialized
DEBUG - 2011-08-23 10:19:29 --> Hooks Class Initialized
DEBUG - 2011-08-23 10:19:29 --> Utf8 Class Initialized
DEBUG - 2011-08-23 10:19:29 --> UTF-8 Support Enabled
DEBUG - 2011-08-23 10:19:29 --> URI Class Initialized
DEBUG - 2011-08-23 10:19:29 --> Router Class Initialized
ERROR - 2011-08-23 10:19:29 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-23 10:19:36 --> Config Class Initialized
DEBUG - 2011-08-23 10:19:36 --> Hooks Class Initialized
DEBUG - 2011-08-23 10:19:36 --> Utf8 Class Initialized
DEBUG - 2011-08-23 10:19:36 --> UTF-8 Support Enabled
DEBUG - 2011-08-23 10:19:36 --> URI Class Initialized
DEBUG - 2011-08-23 10:19:36 --> Router Class Initialized
DEBUG - 2011-08-23 10:19:36 --> Output Class Initialized
DEBUG - 2011-08-23 10:19:36 --> Input Class Initialized
DEBUG - 2011-08-23 10:19:36 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-23 10:19:36 --> Language Class Initialized
DEBUG - 2011-08-23 10:19:36 --> Loader Class Initialized
DEBUG - 2011-08-23 10:19:36 --> Controller Class Initialized
ERROR - 2011-08-23 10:19:36 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-23 10:19:36 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-23 10:19:36 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-23 10:19:36 --> Model Class Initialized
DEBUG - 2011-08-23 10:19:36 --> Model Class Initialized
DEBUG - 2011-08-23 10:19:36 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-23 10:19:36 --> Database Driver Class Initialized
DEBUG - 2011-08-23 10:19:36 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-23 10:19:36 --> Helper loaded: url_helper
DEBUG - 2011-08-23 10:19:36 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-23 10:19:36 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-23 10:19:36 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-23 10:19:36 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-23 10:19:36 --> Final output sent to browser
DEBUG - 2011-08-23 10:19:36 --> Total execution time: 0.0273
DEBUG - 2011-08-23 10:19:37 --> Config Class Initialized
DEBUG - 2011-08-23 10:19:37 --> Hooks Class Initialized
DEBUG - 2011-08-23 10:19:37 --> Utf8 Class Initialized
DEBUG - 2011-08-23 10:19:37 --> UTF-8 Support Enabled
DEBUG - 2011-08-23 10:19:37 --> URI Class Initialized
DEBUG - 2011-08-23 10:19:37 --> Router Class Initialized
DEBUG - 2011-08-23 10:19:37 --> Output Class Initialized
DEBUG - 2011-08-23 10:19:37 --> Input Class Initialized
DEBUG - 2011-08-23 10:19:37 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-23 10:19:37 --> Language Class Initialized
DEBUG - 2011-08-23 10:19:37 --> Loader Class Initialized
DEBUG - 2011-08-23 10:19:37 --> Controller Class Initialized
DEBUG - 2011-08-23 10:19:37 --> Model Class Initialized
DEBUG - 2011-08-23 10:19:37 --> Model Class Initialized
DEBUG - 2011-08-23 10:19:37 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-23 10:19:37 --> Database Driver Class Initialized
DEBUG - 2011-08-23 10:19:38 --> Final output sent to browser
DEBUG - 2011-08-23 10:19:38 --> Total execution time: 0.5357
DEBUG - 2011-08-23 10:19:40 --> Config Class Initialized
DEBUG - 2011-08-23 10:19:40 --> Hooks Class Initialized
DEBUG - 2011-08-23 10:19:40 --> Utf8 Class Initialized
DEBUG - 2011-08-23 10:19:40 --> UTF-8 Support Enabled
DEBUG - 2011-08-23 10:19:40 --> URI Class Initialized
DEBUG - 2011-08-23 10:19:40 --> Router Class Initialized
ERROR - 2011-08-23 10:19:40 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-23 10:19:43 --> Config Class Initialized
DEBUG - 2011-08-23 10:19:43 --> Hooks Class Initialized
DEBUG - 2011-08-23 10:19:43 --> Utf8 Class Initialized
DEBUG - 2011-08-23 10:19:43 --> UTF-8 Support Enabled
DEBUG - 2011-08-23 10:19:43 --> URI Class Initialized
DEBUG - 2011-08-23 10:19:43 --> Router Class Initialized
DEBUG - 2011-08-23 10:19:43 --> Output Class Initialized
DEBUG - 2011-08-23 10:19:43 --> Input Class Initialized
DEBUG - 2011-08-23 10:19:43 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-23 10:19:43 --> Language Class Initialized
DEBUG - 2011-08-23 10:19:43 --> Loader Class Initialized
DEBUG - 2011-08-23 10:19:43 --> Controller Class Initialized
ERROR - 2011-08-23 10:19:43 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-23 10:19:43 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-23 10:19:43 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-23 10:19:43 --> Model Class Initialized
DEBUG - 2011-08-23 10:19:43 --> Model Class Initialized
DEBUG - 2011-08-23 10:19:43 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-23 10:19:43 --> Database Driver Class Initialized
DEBUG - 2011-08-23 10:19:43 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-23 10:19:43 --> Helper loaded: url_helper
DEBUG - 2011-08-23 10:19:43 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-23 10:19:43 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-23 10:19:43 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-23 10:19:43 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-23 10:19:43 --> Final output sent to browser
DEBUG - 2011-08-23 10:19:43 --> Total execution time: 0.0413
DEBUG - 2011-08-23 10:19:43 --> Config Class Initialized
DEBUG - 2011-08-23 10:19:43 --> Hooks Class Initialized
DEBUG - 2011-08-23 10:19:43 --> Utf8 Class Initialized
DEBUG - 2011-08-23 10:19:43 --> UTF-8 Support Enabled
DEBUG - 2011-08-23 10:19:43 --> URI Class Initialized
DEBUG - 2011-08-23 10:19:43 --> Router Class Initialized
DEBUG - 2011-08-23 10:19:43 --> Output Class Initialized
DEBUG - 2011-08-23 10:19:43 --> Input Class Initialized
DEBUG - 2011-08-23 10:19:43 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-23 10:19:43 --> Language Class Initialized
DEBUG - 2011-08-23 10:19:43 --> Loader Class Initialized
DEBUG - 2011-08-23 10:19:43 --> Controller Class Initialized
DEBUG - 2011-08-23 10:19:43 --> Model Class Initialized
DEBUG - 2011-08-23 10:19:43 --> Model Class Initialized
DEBUG - 2011-08-23 10:19:43 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-23 10:19:43 --> Database Driver Class Initialized
DEBUG - 2011-08-23 10:19:44 --> Final output sent to browser
DEBUG - 2011-08-23 10:19:44 --> Total execution time: 0.6136
DEBUG - 2011-08-23 10:19:45 --> Config Class Initialized
DEBUG - 2011-08-23 10:19:45 --> Hooks Class Initialized
DEBUG - 2011-08-23 10:19:45 --> Utf8 Class Initialized
DEBUG - 2011-08-23 10:19:45 --> UTF-8 Support Enabled
DEBUG - 2011-08-23 10:19:45 --> URI Class Initialized
DEBUG - 2011-08-23 10:19:45 --> Router Class Initialized
ERROR - 2011-08-23 10:19:45 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-23 10:19:49 --> Config Class Initialized
DEBUG - 2011-08-23 10:19:49 --> Hooks Class Initialized
DEBUG - 2011-08-23 10:19:49 --> Utf8 Class Initialized
DEBUG - 2011-08-23 10:19:49 --> UTF-8 Support Enabled
DEBUG - 2011-08-23 10:19:49 --> URI Class Initialized
DEBUG - 2011-08-23 10:19:49 --> Router Class Initialized
DEBUG - 2011-08-23 10:19:49 --> Output Class Initialized
DEBUG - 2011-08-23 10:19:49 --> Input Class Initialized
DEBUG - 2011-08-23 10:19:49 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-23 10:19:49 --> Language Class Initialized
DEBUG - 2011-08-23 10:19:49 --> Loader Class Initialized
DEBUG - 2011-08-23 10:19:49 --> Controller Class Initialized
ERROR - 2011-08-23 10:19:49 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-23 10:19:49 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-23 10:19:49 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-23 10:19:49 --> Model Class Initialized
DEBUG - 2011-08-23 10:19:49 --> Model Class Initialized
DEBUG - 2011-08-23 10:19:49 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-23 10:19:49 --> Database Driver Class Initialized
DEBUG - 2011-08-23 10:19:49 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-23 10:19:49 --> Helper loaded: url_helper
DEBUG - 2011-08-23 10:19:49 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-23 10:19:49 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-23 10:19:49 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-23 10:19:49 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-23 10:19:49 --> Final output sent to browser
DEBUG - 2011-08-23 10:19:49 --> Total execution time: 0.0286
DEBUG - 2011-08-23 10:19:49 --> Config Class Initialized
DEBUG - 2011-08-23 10:19:49 --> Hooks Class Initialized
DEBUG - 2011-08-23 10:19:49 --> Utf8 Class Initialized
DEBUG - 2011-08-23 10:19:49 --> UTF-8 Support Enabled
DEBUG - 2011-08-23 10:19:49 --> URI Class Initialized
DEBUG - 2011-08-23 10:19:49 --> Router Class Initialized
DEBUG - 2011-08-23 10:19:49 --> Output Class Initialized
DEBUG - 2011-08-23 10:19:49 --> Input Class Initialized
DEBUG - 2011-08-23 10:19:49 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-23 10:19:49 --> Language Class Initialized
DEBUG - 2011-08-23 10:19:49 --> Loader Class Initialized
DEBUG - 2011-08-23 10:19:49 --> Controller Class Initialized
DEBUG - 2011-08-23 10:19:49 --> Model Class Initialized
DEBUG - 2011-08-23 10:19:49 --> Model Class Initialized
DEBUG - 2011-08-23 10:19:49 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-23 10:19:49 --> Database Driver Class Initialized
DEBUG - 2011-08-23 10:19:50 --> Final output sent to browser
DEBUG - 2011-08-23 10:19:50 --> Total execution time: 1.0350
DEBUG - 2011-08-23 10:19:51 --> Config Class Initialized
DEBUG - 2011-08-23 10:19:51 --> Hooks Class Initialized
DEBUG - 2011-08-23 10:19:51 --> Utf8 Class Initialized
DEBUG - 2011-08-23 10:19:51 --> UTF-8 Support Enabled
DEBUG - 2011-08-23 10:19:51 --> URI Class Initialized
DEBUG - 2011-08-23 10:19:52 --> Router Class Initialized
ERROR - 2011-08-23 10:19:52 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-23 10:20:00 --> Config Class Initialized
DEBUG - 2011-08-23 10:20:00 --> Hooks Class Initialized
DEBUG - 2011-08-23 10:20:00 --> Utf8 Class Initialized
DEBUG - 2011-08-23 10:20:00 --> UTF-8 Support Enabled
DEBUG - 2011-08-23 10:20:00 --> URI Class Initialized
DEBUG - 2011-08-23 10:20:00 --> Router Class Initialized
DEBUG - 2011-08-23 10:20:00 --> Output Class Initialized
DEBUG - 2011-08-23 10:20:00 --> Input Class Initialized
DEBUG - 2011-08-23 10:20:00 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-23 10:20:00 --> Language Class Initialized
DEBUG - 2011-08-23 10:20:00 --> Loader Class Initialized
DEBUG - 2011-08-23 10:20:00 --> Controller Class Initialized
ERROR - 2011-08-23 10:20:00 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-23 10:20:00 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-23 10:20:00 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-23 10:20:00 --> Model Class Initialized
DEBUG - 2011-08-23 10:20:00 --> Model Class Initialized
DEBUG - 2011-08-23 10:20:00 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-23 10:20:00 --> Database Driver Class Initialized
DEBUG - 2011-08-23 10:20:00 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-23 10:20:00 --> Helper loaded: url_helper
DEBUG - 2011-08-23 10:20:00 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-23 10:20:00 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-23 10:20:00 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-23 10:20:00 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-23 10:20:00 --> Final output sent to browser
DEBUG - 2011-08-23 10:20:00 --> Total execution time: 0.1004
DEBUG - 2011-08-23 10:20:00 --> Config Class Initialized
DEBUG - 2011-08-23 10:20:00 --> Hooks Class Initialized
DEBUG - 2011-08-23 10:20:00 --> Utf8 Class Initialized
DEBUG - 2011-08-23 10:20:00 --> UTF-8 Support Enabled
DEBUG - 2011-08-23 10:20:00 --> URI Class Initialized
DEBUG - 2011-08-23 10:20:00 --> Router Class Initialized
DEBUG - 2011-08-23 10:20:00 --> Output Class Initialized
DEBUG - 2011-08-23 10:20:00 --> Input Class Initialized
DEBUG - 2011-08-23 10:20:00 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-23 10:20:00 --> Language Class Initialized
DEBUG - 2011-08-23 10:20:00 --> Loader Class Initialized
DEBUG - 2011-08-23 10:20:00 --> Controller Class Initialized
DEBUG - 2011-08-23 10:20:00 --> Model Class Initialized
DEBUG - 2011-08-23 10:20:00 --> Model Class Initialized
DEBUG - 2011-08-23 10:20:00 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-23 10:20:00 --> Database Driver Class Initialized
DEBUG - 2011-08-23 10:20:01 --> Final output sent to browser
DEBUG - 2011-08-23 10:20:01 --> Total execution time: 1.1418
DEBUG - 2011-08-23 10:20:03 --> Config Class Initialized
DEBUG - 2011-08-23 10:20:03 --> Hooks Class Initialized
DEBUG - 2011-08-23 10:20:03 --> Utf8 Class Initialized
DEBUG - 2011-08-23 10:20:03 --> UTF-8 Support Enabled
DEBUG - 2011-08-23 10:20:03 --> URI Class Initialized
DEBUG - 2011-08-23 10:20:03 --> Router Class Initialized
ERROR - 2011-08-23 10:20:03 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-23 10:20:06 --> Config Class Initialized
DEBUG - 2011-08-23 10:20:06 --> Hooks Class Initialized
DEBUG - 2011-08-23 10:20:06 --> Utf8 Class Initialized
DEBUG - 2011-08-23 10:20:06 --> UTF-8 Support Enabled
DEBUG - 2011-08-23 10:20:06 --> URI Class Initialized
DEBUG - 2011-08-23 10:20:06 --> Router Class Initialized
DEBUG - 2011-08-23 10:20:06 --> Output Class Initialized
DEBUG - 2011-08-23 10:20:06 --> Input Class Initialized
DEBUG - 2011-08-23 10:20:06 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-23 10:20:06 --> Language Class Initialized
DEBUG - 2011-08-23 10:20:06 --> Loader Class Initialized
DEBUG - 2011-08-23 10:20:06 --> Controller Class Initialized
ERROR - 2011-08-23 10:20:06 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-23 10:20:06 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-23 10:20:06 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-23 10:20:06 --> Model Class Initialized
DEBUG - 2011-08-23 10:20:06 --> Model Class Initialized
DEBUG - 2011-08-23 10:20:06 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-23 10:20:06 --> Database Driver Class Initialized
DEBUG - 2011-08-23 10:20:06 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-23 10:20:06 --> Helper loaded: url_helper
DEBUG - 2011-08-23 10:20:06 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-23 10:20:06 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-23 10:20:06 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-23 10:20:06 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-23 10:20:06 --> Final output sent to browser
DEBUG - 2011-08-23 10:20:06 --> Total execution time: 0.1911
DEBUG - 2011-08-23 10:20:07 --> Config Class Initialized
DEBUG - 2011-08-23 10:20:07 --> Hooks Class Initialized
DEBUG - 2011-08-23 10:20:07 --> Utf8 Class Initialized
DEBUG - 2011-08-23 10:20:07 --> UTF-8 Support Enabled
DEBUG - 2011-08-23 10:20:07 --> URI Class Initialized
DEBUG - 2011-08-23 10:20:07 --> Router Class Initialized
DEBUG - 2011-08-23 10:20:07 --> Output Class Initialized
DEBUG - 2011-08-23 10:20:07 --> Input Class Initialized
DEBUG - 2011-08-23 10:20:07 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-23 10:20:07 --> Language Class Initialized
DEBUG - 2011-08-23 10:20:07 --> Loader Class Initialized
DEBUG - 2011-08-23 10:20:07 --> Controller Class Initialized
DEBUG - 2011-08-23 10:20:07 --> Model Class Initialized
DEBUG - 2011-08-23 10:20:07 --> Model Class Initialized
DEBUG - 2011-08-23 10:20:07 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-23 10:20:07 --> Database Driver Class Initialized
DEBUG - 2011-08-23 10:20:08 --> Final output sent to browser
DEBUG - 2011-08-23 10:20:08 --> Total execution time: 1.1229
DEBUG - 2011-08-23 10:21:16 --> Config Class Initialized
DEBUG - 2011-08-23 10:21:16 --> Hooks Class Initialized
DEBUG - 2011-08-23 10:21:16 --> Utf8 Class Initialized
DEBUG - 2011-08-23 10:21:16 --> UTF-8 Support Enabled
DEBUG - 2011-08-23 10:21:16 --> URI Class Initialized
DEBUG - 2011-08-23 10:21:16 --> Router Class Initialized
DEBUG - 2011-08-23 10:21:16 --> Output Class Initialized
DEBUG - 2011-08-23 10:21:16 --> Input Class Initialized
DEBUG - 2011-08-23 10:21:16 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-23 10:21:16 --> Language Class Initialized
DEBUG - 2011-08-23 10:21:16 --> Loader Class Initialized
DEBUG - 2011-08-23 10:21:16 --> Controller Class Initialized
ERROR - 2011-08-23 10:21:16 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-23 10:21:16 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-23 10:21:16 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-23 10:21:16 --> Model Class Initialized
DEBUG - 2011-08-23 10:21:16 --> Model Class Initialized
DEBUG - 2011-08-23 10:21:16 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-23 10:21:16 --> Database Driver Class Initialized
DEBUG - 2011-08-23 10:21:16 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-23 10:21:16 --> Helper loaded: url_helper
DEBUG - 2011-08-23 10:21:16 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-23 10:21:16 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-23 10:21:16 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-23 10:21:16 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-23 10:21:16 --> Final output sent to browser
DEBUG - 2011-08-23 10:21:16 --> Total execution time: 0.0276
DEBUG - 2011-08-23 10:34:00 --> Config Class Initialized
DEBUG - 2011-08-23 10:34:00 --> Hooks Class Initialized
DEBUG - 2011-08-23 10:34:00 --> Utf8 Class Initialized
DEBUG - 2011-08-23 10:34:00 --> UTF-8 Support Enabled
DEBUG - 2011-08-23 10:34:00 --> URI Class Initialized
DEBUG - 2011-08-23 10:34:00 --> Router Class Initialized
DEBUG - 2011-08-23 10:34:00 --> Output Class Initialized
DEBUG - 2011-08-23 10:34:00 --> Input Class Initialized
DEBUG - 2011-08-23 10:34:00 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-23 10:34:00 --> Language Class Initialized
DEBUG - 2011-08-23 10:34:00 --> Loader Class Initialized
DEBUG - 2011-08-23 10:34:00 --> Controller Class Initialized
DEBUG - 2011-08-23 10:34:00 --> Model Class Initialized
DEBUG - 2011-08-23 10:34:00 --> Model Class Initialized
DEBUG - 2011-08-23 10:34:00 --> Model Class Initialized
DEBUG - 2011-08-23 10:34:00 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-23 10:34:00 --> Database Driver Class Initialized
DEBUG - 2011-08-23 10:34:01 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-23 10:34:01 --> Helper loaded: url_helper
DEBUG - 2011-08-23 10:34:01 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-23 10:34:01 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-23 10:34:01 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-23 10:34:01 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-23 10:34:01 --> Final output sent to browser
DEBUG - 2011-08-23 10:34:01 --> Total execution time: 0.7270
DEBUG - 2011-08-23 10:35:33 --> Config Class Initialized
DEBUG - 2011-08-23 10:35:33 --> Hooks Class Initialized
DEBUG - 2011-08-23 10:35:33 --> Utf8 Class Initialized
DEBUG - 2011-08-23 10:35:33 --> UTF-8 Support Enabled
DEBUG - 2011-08-23 10:35:33 --> URI Class Initialized
DEBUG - 2011-08-23 10:35:33 --> Router Class Initialized
DEBUG - 2011-08-23 10:35:33 --> Output Class Initialized
DEBUG - 2011-08-23 10:35:33 --> Input Class Initialized
DEBUG - 2011-08-23 10:35:33 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-23 10:35:33 --> Language Class Initialized
DEBUG - 2011-08-23 10:35:33 --> Loader Class Initialized
DEBUG - 2011-08-23 10:35:33 --> Controller Class Initialized
ERROR - 2011-08-23 10:35:33 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-23 10:35:33 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-23 10:35:33 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-23 10:35:33 --> Model Class Initialized
DEBUG - 2011-08-23 10:35:33 --> Model Class Initialized
DEBUG - 2011-08-23 10:35:33 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-23 10:35:33 --> Database Driver Class Initialized
DEBUG - 2011-08-23 10:35:33 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-23 10:35:34 --> Helper loaded: url_helper
DEBUG - 2011-08-23 10:35:34 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-23 10:35:34 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-23 10:35:34 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-23 10:35:34 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-23 10:35:34 --> Final output sent to browser
DEBUG - 2011-08-23 10:35:34 --> Total execution time: 0.1499
DEBUG - 2011-08-23 10:35:37 --> Config Class Initialized
DEBUG - 2011-08-23 10:35:37 --> Hooks Class Initialized
DEBUG - 2011-08-23 10:35:37 --> Utf8 Class Initialized
DEBUG - 2011-08-23 10:35:37 --> UTF-8 Support Enabled
DEBUG - 2011-08-23 10:35:37 --> URI Class Initialized
DEBUG - 2011-08-23 10:35:37 --> Router Class Initialized
DEBUG - 2011-08-23 10:35:37 --> Output Class Initialized
DEBUG - 2011-08-23 10:35:37 --> Input Class Initialized
DEBUG - 2011-08-23 10:35:37 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-23 10:35:37 --> Language Class Initialized
DEBUG - 2011-08-23 10:35:37 --> Loader Class Initialized
DEBUG - 2011-08-23 10:35:37 --> Controller Class Initialized
DEBUG - 2011-08-23 10:35:37 --> Model Class Initialized
DEBUG - 2011-08-23 10:35:37 --> Model Class Initialized
DEBUG - 2011-08-23 10:35:37 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-23 10:35:37 --> Database Driver Class Initialized
DEBUG - 2011-08-23 10:35:37 --> Final output sent to browser
DEBUG - 2011-08-23 10:35:37 --> Total execution time: 0.7338
DEBUG - 2011-08-23 10:35:40 --> Config Class Initialized
DEBUG - 2011-08-23 10:35:40 --> Hooks Class Initialized
DEBUG - 2011-08-23 10:35:40 --> Utf8 Class Initialized
DEBUG - 2011-08-23 10:35:40 --> UTF-8 Support Enabled
DEBUG - 2011-08-23 10:35:40 --> URI Class Initialized
DEBUG - 2011-08-23 10:35:40 --> Router Class Initialized
ERROR - 2011-08-23 10:35:40 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-23 10:35:40 --> Config Class Initialized
DEBUG - 2011-08-23 10:35:40 --> Hooks Class Initialized
DEBUG - 2011-08-23 10:35:40 --> Utf8 Class Initialized
DEBUG - 2011-08-23 10:35:40 --> UTF-8 Support Enabled
DEBUG - 2011-08-23 10:35:40 --> URI Class Initialized
DEBUG - 2011-08-23 10:35:40 --> Router Class Initialized
ERROR - 2011-08-23 10:35:40 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-23 11:35:29 --> Config Class Initialized
DEBUG - 2011-08-23 11:35:29 --> Hooks Class Initialized
DEBUG - 2011-08-23 11:35:29 --> Utf8 Class Initialized
DEBUG - 2011-08-23 11:35:29 --> UTF-8 Support Enabled
DEBUG - 2011-08-23 11:35:29 --> URI Class Initialized
DEBUG - 2011-08-23 11:35:29 --> Router Class Initialized
ERROR - 2011-08-23 11:35:29 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-08-23 12:32:56 --> Config Class Initialized
DEBUG - 2011-08-23 12:32:56 --> Hooks Class Initialized
DEBUG - 2011-08-23 12:32:56 --> Utf8 Class Initialized
DEBUG - 2011-08-23 12:32:56 --> UTF-8 Support Enabled
DEBUG - 2011-08-23 12:32:56 --> URI Class Initialized
DEBUG - 2011-08-23 12:32:56 --> Router Class Initialized
DEBUG - 2011-08-23 12:32:56 --> Output Class Initialized
DEBUG - 2011-08-23 12:32:56 --> Input Class Initialized
DEBUG - 2011-08-23 12:32:56 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-23 12:32:56 --> Language Class Initialized
DEBUG - 2011-08-23 12:32:56 --> Loader Class Initialized
DEBUG - 2011-08-23 12:32:56 --> Controller Class Initialized
ERROR - 2011-08-23 12:32:56 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-23 12:32:56 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-23 12:32:56 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-23 12:32:56 --> Model Class Initialized
DEBUG - 2011-08-23 12:32:56 --> Model Class Initialized
DEBUG - 2011-08-23 12:32:56 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-23 12:32:56 --> Database Driver Class Initialized
DEBUG - 2011-08-23 12:32:56 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-23 12:32:56 --> Helper loaded: url_helper
DEBUG - 2011-08-23 12:32:56 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-23 12:32:56 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-23 12:32:56 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-23 12:32:56 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-23 12:32:56 --> Final output sent to browser
DEBUG - 2011-08-23 12:32:56 --> Total execution time: 0.0872
DEBUG - 2011-08-23 12:32:59 --> Config Class Initialized
DEBUG - 2011-08-23 12:32:59 --> Hooks Class Initialized
DEBUG - 2011-08-23 12:32:59 --> Utf8 Class Initialized
DEBUG - 2011-08-23 12:32:59 --> UTF-8 Support Enabled
DEBUG - 2011-08-23 12:32:59 --> URI Class Initialized
DEBUG - 2011-08-23 12:32:59 --> Router Class Initialized
DEBUG - 2011-08-23 12:32:59 --> Output Class Initialized
DEBUG - 2011-08-23 12:32:59 --> Input Class Initialized
DEBUG - 2011-08-23 12:32:59 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-23 12:32:59 --> Language Class Initialized
DEBUG - 2011-08-23 12:32:59 --> Loader Class Initialized
DEBUG - 2011-08-23 12:32:59 --> Controller Class Initialized
DEBUG - 2011-08-23 12:32:59 --> Model Class Initialized
DEBUG - 2011-08-23 12:32:59 --> Model Class Initialized
DEBUG - 2011-08-23 12:32:59 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-23 12:32:59 --> Database Driver Class Initialized
DEBUG - 2011-08-23 12:33:06 --> Final output sent to browser
DEBUG - 2011-08-23 12:33:06 --> Total execution time: 6.4796
DEBUG - 2011-08-23 12:33:22 --> Config Class Initialized
DEBUG - 2011-08-23 12:33:22 --> Hooks Class Initialized
DEBUG - 2011-08-23 12:33:22 --> Utf8 Class Initialized
DEBUG - 2011-08-23 12:33:22 --> UTF-8 Support Enabled
DEBUG - 2011-08-23 12:33:22 --> URI Class Initialized
DEBUG - 2011-08-23 12:33:22 --> Router Class Initialized
ERROR - 2011-08-23 12:33:22 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-23 12:33:26 --> Config Class Initialized
DEBUG - 2011-08-23 12:33:26 --> Hooks Class Initialized
DEBUG - 2011-08-23 12:33:26 --> Utf8 Class Initialized
DEBUG - 2011-08-23 12:33:26 --> UTF-8 Support Enabled
DEBUG - 2011-08-23 12:33:26 --> URI Class Initialized
DEBUG - 2011-08-23 12:33:26 --> Router Class Initialized
ERROR - 2011-08-23 12:33:26 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-23 12:33:33 --> Config Class Initialized
DEBUG - 2011-08-23 12:33:33 --> Hooks Class Initialized
DEBUG - 2011-08-23 12:33:33 --> Utf8 Class Initialized
DEBUG - 2011-08-23 12:33:33 --> UTF-8 Support Enabled
DEBUG - 2011-08-23 12:33:33 --> URI Class Initialized
DEBUG - 2011-08-23 12:33:33 --> Router Class Initialized
DEBUG - 2011-08-23 12:33:33 --> Output Class Initialized
DEBUG - 2011-08-23 12:33:33 --> Input Class Initialized
DEBUG - 2011-08-23 12:33:33 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-23 12:33:33 --> Language Class Initialized
DEBUG - 2011-08-23 12:33:33 --> Loader Class Initialized
DEBUG - 2011-08-23 12:33:33 --> Controller Class Initialized
ERROR - 2011-08-23 12:33:33 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-23 12:33:33 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-23 12:33:33 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-23 12:33:33 --> Model Class Initialized
DEBUG - 2011-08-23 12:33:33 --> Model Class Initialized
DEBUG - 2011-08-23 12:33:33 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-23 12:33:33 --> Database Driver Class Initialized
DEBUG - 2011-08-23 12:33:33 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-23 12:33:33 --> Helper loaded: url_helper
DEBUG - 2011-08-23 12:33:33 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-23 12:33:33 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-23 12:33:33 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-23 12:33:33 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-23 12:33:33 --> Final output sent to browser
DEBUG - 2011-08-23 12:33:33 --> Total execution time: 0.0954
DEBUG - 2011-08-23 12:33:38 --> Config Class Initialized
DEBUG - 2011-08-23 12:33:38 --> Hooks Class Initialized
DEBUG - 2011-08-23 12:33:38 --> Utf8 Class Initialized
DEBUG - 2011-08-23 12:33:38 --> UTF-8 Support Enabled
DEBUG - 2011-08-23 12:33:38 --> URI Class Initialized
DEBUG - 2011-08-23 12:33:38 --> Router Class Initialized
DEBUG - 2011-08-23 12:33:38 --> Output Class Initialized
DEBUG - 2011-08-23 12:33:38 --> Input Class Initialized
DEBUG - 2011-08-23 12:33:38 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-23 12:33:38 --> Language Class Initialized
DEBUG - 2011-08-23 12:33:38 --> Loader Class Initialized
DEBUG - 2011-08-23 12:33:38 --> Controller Class Initialized
DEBUG - 2011-08-23 12:33:38 --> Model Class Initialized
DEBUG - 2011-08-23 12:33:38 --> Model Class Initialized
DEBUG - 2011-08-23 12:33:38 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-23 12:33:38 --> Database Driver Class Initialized
DEBUG - 2011-08-23 12:33:40 --> Final output sent to browser
DEBUG - 2011-08-23 12:33:40 --> Total execution time: 2.0214
DEBUG - 2011-08-23 12:33:56 --> Config Class Initialized
DEBUG - 2011-08-23 12:33:56 --> Hooks Class Initialized
DEBUG - 2011-08-23 12:33:56 --> Utf8 Class Initialized
DEBUG - 2011-08-23 12:33:56 --> UTF-8 Support Enabled
DEBUG - 2011-08-23 12:33:56 --> URI Class Initialized
DEBUG - 2011-08-23 12:33:56 --> Router Class Initialized
DEBUG - 2011-08-23 12:33:56 --> Output Class Initialized
DEBUG - 2011-08-23 12:33:56 --> Input Class Initialized
DEBUG - 2011-08-23 12:33:56 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-23 12:33:56 --> Language Class Initialized
DEBUG - 2011-08-23 12:33:56 --> Loader Class Initialized
DEBUG - 2011-08-23 12:33:56 --> Controller Class Initialized
ERROR - 2011-08-23 12:33:56 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-23 12:33:56 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-23 12:33:56 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-23 12:33:56 --> Model Class Initialized
DEBUG - 2011-08-23 12:33:56 --> Model Class Initialized
DEBUG - 2011-08-23 12:33:56 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-23 12:33:56 --> Database Driver Class Initialized
DEBUG - 2011-08-23 12:33:56 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-23 12:33:56 --> Helper loaded: url_helper
DEBUG - 2011-08-23 12:33:56 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-23 12:33:56 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-23 12:33:56 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-23 12:33:56 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-23 12:33:56 --> Final output sent to browser
DEBUG - 2011-08-23 12:33:56 --> Total execution time: 0.0292
DEBUG - 2011-08-23 12:33:58 --> Config Class Initialized
DEBUG - 2011-08-23 12:33:58 --> Hooks Class Initialized
DEBUG - 2011-08-23 12:33:58 --> Utf8 Class Initialized
DEBUG - 2011-08-23 12:33:58 --> UTF-8 Support Enabled
DEBUG - 2011-08-23 12:33:58 --> URI Class Initialized
DEBUG - 2011-08-23 12:33:58 --> Router Class Initialized
DEBUG - 2011-08-23 12:33:58 --> Output Class Initialized
DEBUG - 2011-08-23 12:33:58 --> Input Class Initialized
DEBUG - 2011-08-23 12:33:58 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-23 12:33:58 --> Language Class Initialized
DEBUG - 2011-08-23 12:33:58 --> Loader Class Initialized
DEBUG - 2011-08-23 12:33:58 --> Controller Class Initialized
DEBUG - 2011-08-23 12:33:58 --> Model Class Initialized
DEBUG - 2011-08-23 12:33:58 --> Model Class Initialized
DEBUG - 2011-08-23 12:33:58 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-23 12:33:58 --> Database Driver Class Initialized
DEBUG - 2011-08-23 12:34:01 --> Final output sent to browser
DEBUG - 2011-08-23 12:34:01 --> Total execution time: 3.1263
DEBUG - 2011-08-23 12:34:16 --> Config Class Initialized
DEBUG - 2011-08-23 12:34:16 --> Hooks Class Initialized
DEBUG - 2011-08-23 12:34:16 --> Utf8 Class Initialized
DEBUG - 2011-08-23 12:34:16 --> UTF-8 Support Enabled
DEBUG - 2011-08-23 12:34:16 --> URI Class Initialized
DEBUG - 2011-08-23 12:34:16 --> Router Class Initialized
DEBUG - 2011-08-23 12:34:16 --> Output Class Initialized
DEBUG - 2011-08-23 12:34:16 --> Input Class Initialized
DEBUG - 2011-08-23 12:34:16 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-23 12:34:16 --> Language Class Initialized
DEBUG - 2011-08-23 12:34:16 --> Loader Class Initialized
DEBUG - 2011-08-23 12:34:16 --> Controller Class Initialized
ERROR - 2011-08-23 12:34:16 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-23 12:34:16 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-23 12:34:16 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-23 12:34:16 --> Model Class Initialized
DEBUG - 2011-08-23 12:34:16 --> Model Class Initialized
DEBUG - 2011-08-23 12:34:16 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-23 12:34:16 --> Database Driver Class Initialized
DEBUG - 2011-08-23 12:34:16 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-23 12:34:16 --> Helper loaded: url_helper
DEBUG - 2011-08-23 12:34:16 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-23 12:34:16 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-23 12:34:16 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-23 12:34:16 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-23 12:34:16 --> Final output sent to browser
DEBUG - 2011-08-23 12:34:16 --> Total execution time: 0.0326
DEBUG - 2011-08-23 12:34:19 --> Config Class Initialized
DEBUG - 2011-08-23 12:34:19 --> Hooks Class Initialized
DEBUG - 2011-08-23 12:34:19 --> Utf8 Class Initialized
DEBUG - 2011-08-23 12:34:19 --> UTF-8 Support Enabled
DEBUG - 2011-08-23 12:34:19 --> URI Class Initialized
DEBUG - 2011-08-23 12:34:19 --> Router Class Initialized
DEBUG - 2011-08-23 12:34:19 --> Output Class Initialized
DEBUG - 2011-08-23 12:34:19 --> Input Class Initialized
DEBUG - 2011-08-23 12:34:19 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-23 12:34:19 --> Language Class Initialized
DEBUG - 2011-08-23 12:34:19 --> Loader Class Initialized
DEBUG - 2011-08-23 12:34:19 --> Controller Class Initialized
DEBUG - 2011-08-23 12:34:19 --> Model Class Initialized
DEBUG - 2011-08-23 12:34:19 --> Model Class Initialized
DEBUG - 2011-08-23 12:34:19 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-23 12:34:19 --> Database Driver Class Initialized
DEBUG - 2011-08-23 12:34:21 --> Final output sent to browser
DEBUG - 2011-08-23 12:34:21 --> Total execution time: 1.3790
DEBUG - 2011-08-23 12:34:42 --> Config Class Initialized
DEBUG - 2011-08-23 12:34:42 --> Hooks Class Initialized
DEBUG - 2011-08-23 12:34:42 --> Utf8 Class Initialized
DEBUG - 2011-08-23 12:34:42 --> UTF-8 Support Enabled
DEBUG - 2011-08-23 12:34:42 --> URI Class Initialized
DEBUG - 2011-08-23 12:34:42 --> Router Class Initialized
DEBUG - 2011-08-23 12:34:42 --> Output Class Initialized
DEBUG - 2011-08-23 12:34:42 --> Input Class Initialized
DEBUG - 2011-08-23 12:34:42 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-23 12:34:42 --> Language Class Initialized
DEBUG - 2011-08-23 12:34:42 --> Loader Class Initialized
DEBUG - 2011-08-23 12:34:42 --> Controller Class Initialized
ERROR - 2011-08-23 12:34:42 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-23 12:34:42 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-23 12:34:42 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-23 12:34:42 --> Model Class Initialized
DEBUG - 2011-08-23 12:34:42 --> Model Class Initialized
DEBUG - 2011-08-23 12:34:42 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-23 12:34:42 --> Database Driver Class Initialized
DEBUG - 2011-08-23 12:34:42 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-23 12:34:42 --> Helper loaded: url_helper
DEBUG - 2011-08-23 12:34:42 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-23 12:34:42 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-23 12:34:42 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-23 12:34:42 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-23 12:34:42 --> Final output sent to browser
DEBUG - 2011-08-23 12:34:42 --> Total execution time: 0.0454
DEBUG - 2011-08-23 12:34:43 --> Config Class Initialized
DEBUG - 2011-08-23 12:34:43 --> Hooks Class Initialized
DEBUG - 2011-08-23 12:34:43 --> Utf8 Class Initialized
DEBUG - 2011-08-23 12:34:43 --> UTF-8 Support Enabled
DEBUG - 2011-08-23 12:34:43 --> URI Class Initialized
DEBUG - 2011-08-23 12:34:43 --> Router Class Initialized
DEBUG - 2011-08-23 12:34:43 --> Output Class Initialized
DEBUG - 2011-08-23 12:34:43 --> Input Class Initialized
DEBUG - 2011-08-23 12:34:43 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-23 12:34:43 --> Language Class Initialized
DEBUG - 2011-08-23 12:34:43 --> Loader Class Initialized
DEBUG - 2011-08-23 12:34:43 --> Controller Class Initialized
DEBUG - 2011-08-23 12:34:43 --> Model Class Initialized
DEBUG - 2011-08-23 12:34:43 --> Model Class Initialized
DEBUG - 2011-08-23 12:34:43 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-23 12:34:43 --> Database Driver Class Initialized
DEBUG - 2011-08-23 12:34:47 --> Final output sent to browser
DEBUG - 2011-08-23 12:34:47 --> Total execution time: 3.1669
DEBUG - 2011-08-23 12:34:55 --> Config Class Initialized
DEBUG - 2011-08-23 12:34:55 --> Hooks Class Initialized
DEBUG - 2011-08-23 12:34:55 --> Utf8 Class Initialized
DEBUG - 2011-08-23 12:34:55 --> UTF-8 Support Enabled
DEBUG - 2011-08-23 12:34:55 --> URI Class Initialized
DEBUG - 2011-08-23 12:34:55 --> Router Class Initialized
DEBUG - 2011-08-23 12:34:55 --> Output Class Initialized
DEBUG - 2011-08-23 12:34:55 --> Input Class Initialized
DEBUG - 2011-08-23 12:34:55 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-23 12:34:55 --> Language Class Initialized
DEBUG - 2011-08-23 12:34:55 --> Loader Class Initialized
DEBUG - 2011-08-23 12:34:55 --> Controller Class Initialized
ERROR - 2011-08-23 12:34:55 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-23 12:34:55 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-23 12:34:55 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-23 12:34:55 --> Model Class Initialized
DEBUG - 2011-08-23 12:34:55 --> Model Class Initialized
DEBUG - 2011-08-23 12:34:55 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-23 12:34:55 --> Database Driver Class Initialized
DEBUG - 2011-08-23 12:34:55 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-23 12:34:55 --> Helper loaded: url_helper
DEBUG - 2011-08-23 12:34:55 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-23 12:34:55 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-23 12:34:55 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-23 12:34:55 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-23 12:34:55 --> Final output sent to browser
DEBUG - 2011-08-23 12:34:55 --> Total execution time: 0.0470
DEBUG - 2011-08-23 12:34:58 --> Config Class Initialized
DEBUG - 2011-08-23 12:34:58 --> Hooks Class Initialized
DEBUG - 2011-08-23 12:34:58 --> Utf8 Class Initialized
DEBUG - 2011-08-23 12:34:58 --> UTF-8 Support Enabled
DEBUG - 2011-08-23 12:34:58 --> URI Class Initialized
DEBUG - 2011-08-23 12:34:58 --> Router Class Initialized
DEBUG - 2011-08-23 12:34:58 --> Output Class Initialized
DEBUG - 2011-08-23 12:34:58 --> Input Class Initialized
DEBUG - 2011-08-23 12:34:58 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-23 12:34:58 --> Language Class Initialized
DEBUG - 2011-08-23 12:34:58 --> Loader Class Initialized
DEBUG - 2011-08-23 12:34:58 --> Controller Class Initialized
DEBUG - 2011-08-23 12:34:58 --> Model Class Initialized
DEBUG - 2011-08-23 12:34:58 --> Model Class Initialized
DEBUG - 2011-08-23 12:34:58 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-23 12:34:58 --> Database Driver Class Initialized
DEBUG - 2011-08-23 12:34:59 --> Final output sent to browser
DEBUG - 2011-08-23 12:34:59 --> Total execution time: 0.5066
DEBUG - 2011-08-23 12:35:00 --> Config Class Initialized
DEBUG - 2011-08-23 12:35:00 --> Hooks Class Initialized
DEBUG - 2011-08-23 12:35:00 --> Utf8 Class Initialized
DEBUG - 2011-08-23 12:35:00 --> UTF-8 Support Enabled
DEBUG - 2011-08-23 12:35:00 --> URI Class Initialized
DEBUG - 2011-08-23 12:35:00 --> Router Class Initialized
DEBUG - 2011-08-23 12:35:00 --> Output Class Initialized
DEBUG - 2011-08-23 12:35:00 --> Input Class Initialized
DEBUG - 2011-08-23 12:35:00 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-23 12:35:00 --> Language Class Initialized
DEBUG - 2011-08-23 12:35:00 --> Loader Class Initialized
DEBUG - 2011-08-23 12:35:00 --> Controller Class Initialized
ERROR - 2011-08-23 12:35:00 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-23 12:35:00 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-23 12:35:00 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-23 12:35:00 --> Model Class Initialized
DEBUG - 2011-08-23 12:35:00 --> Model Class Initialized
DEBUG - 2011-08-23 12:35:00 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-23 12:35:00 --> Database Driver Class Initialized
DEBUG - 2011-08-23 12:35:00 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-23 12:35:00 --> Helper loaded: url_helper
DEBUG - 2011-08-23 12:35:00 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-23 12:35:00 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-23 12:35:00 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-23 12:35:00 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-23 12:35:00 --> Final output sent to browser
DEBUG - 2011-08-23 12:35:00 --> Total execution time: 0.0674
DEBUG - 2011-08-23 12:35:08 --> Config Class Initialized
DEBUG - 2011-08-23 12:35:08 --> Hooks Class Initialized
DEBUG - 2011-08-23 12:35:08 --> Utf8 Class Initialized
DEBUG - 2011-08-23 12:35:08 --> UTF-8 Support Enabled
DEBUG - 2011-08-23 12:35:08 --> URI Class Initialized
DEBUG - 2011-08-23 12:35:08 --> Router Class Initialized
DEBUG - 2011-08-23 12:35:08 --> Output Class Initialized
DEBUG - 2011-08-23 12:35:08 --> Input Class Initialized
DEBUG - 2011-08-23 12:35:08 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-23 12:35:08 --> Language Class Initialized
DEBUG - 2011-08-23 12:35:08 --> Loader Class Initialized
DEBUG - 2011-08-23 12:35:08 --> Controller Class Initialized
DEBUG - 2011-08-23 12:35:08 --> Model Class Initialized
DEBUG - 2011-08-23 12:35:08 --> Model Class Initialized
DEBUG - 2011-08-23 12:35:08 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-23 12:35:08 --> Database Driver Class Initialized
DEBUG - 2011-08-23 12:35:11 --> Final output sent to browser
DEBUG - 2011-08-23 12:35:11 --> Total execution time: 3.1084
DEBUG - 2011-08-23 12:35:16 --> Config Class Initialized
DEBUG - 2011-08-23 12:35:16 --> Hooks Class Initialized
DEBUG - 2011-08-23 12:35:16 --> Utf8 Class Initialized
DEBUG - 2011-08-23 12:35:16 --> UTF-8 Support Enabled
DEBUG - 2011-08-23 12:35:16 --> URI Class Initialized
DEBUG - 2011-08-23 12:35:16 --> Router Class Initialized
DEBUG - 2011-08-23 12:35:16 --> Output Class Initialized
DEBUG - 2011-08-23 12:35:16 --> Input Class Initialized
DEBUG - 2011-08-23 12:35:16 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-23 12:35:16 --> Language Class Initialized
DEBUG - 2011-08-23 12:35:16 --> Loader Class Initialized
DEBUG - 2011-08-23 12:35:16 --> Controller Class Initialized
ERROR - 2011-08-23 12:35:16 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-23 12:35:16 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-23 12:35:16 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-23 12:35:16 --> Model Class Initialized
DEBUG - 2011-08-23 12:35:16 --> Model Class Initialized
DEBUG - 2011-08-23 12:35:16 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-23 12:35:16 --> Database Driver Class Initialized
DEBUG - 2011-08-23 12:35:16 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-23 12:35:16 --> Helper loaded: url_helper
DEBUG - 2011-08-23 12:35:16 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-23 12:35:16 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-23 12:35:16 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-23 12:35:16 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-23 12:35:16 --> Final output sent to browser
DEBUG - 2011-08-23 12:35:16 --> Total execution time: 0.0744
DEBUG - 2011-08-23 12:35:21 --> Config Class Initialized
DEBUG - 2011-08-23 12:35:21 --> Hooks Class Initialized
DEBUG - 2011-08-23 12:35:21 --> Utf8 Class Initialized
DEBUG - 2011-08-23 12:35:21 --> UTF-8 Support Enabled
DEBUG - 2011-08-23 12:35:21 --> URI Class Initialized
DEBUG - 2011-08-23 12:35:21 --> Router Class Initialized
DEBUG - 2011-08-23 12:35:21 --> Output Class Initialized
DEBUG - 2011-08-23 12:35:21 --> Input Class Initialized
DEBUG - 2011-08-23 12:35:21 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-23 12:35:21 --> Language Class Initialized
DEBUG - 2011-08-23 12:35:21 --> Loader Class Initialized
DEBUG - 2011-08-23 12:35:21 --> Controller Class Initialized
ERROR - 2011-08-23 12:35:21 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-23 12:35:21 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-23 12:35:21 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-23 12:35:21 --> Model Class Initialized
DEBUG - 2011-08-23 12:35:21 --> Model Class Initialized
DEBUG - 2011-08-23 12:35:21 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-23 12:35:21 --> Database Driver Class Initialized
DEBUG - 2011-08-23 12:35:21 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-23 12:35:21 --> Helper loaded: url_helper
DEBUG - 2011-08-23 12:35:21 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-23 12:35:21 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-23 12:35:21 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-23 12:35:21 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-23 12:35:21 --> Final output sent to browser
DEBUG - 2011-08-23 12:35:21 --> Total execution time: 0.0317
DEBUG - 2011-08-23 12:35:23 --> Config Class Initialized
DEBUG - 2011-08-23 12:35:23 --> Hooks Class Initialized
DEBUG - 2011-08-23 12:35:23 --> Utf8 Class Initialized
DEBUG - 2011-08-23 12:35:23 --> UTF-8 Support Enabled
DEBUG - 2011-08-23 12:35:23 --> URI Class Initialized
DEBUG - 2011-08-23 12:35:23 --> Router Class Initialized
DEBUG - 2011-08-23 12:35:23 --> Output Class Initialized
DEBUG - 2011-08-23 12:35:23 --> Input Class Initialized
DEBUG - 2011-08-23 12:35:23 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-23 12:35:23 --> Language Class Initialized
DEBUG - 2011-08-23 12:35:23 --> Loader Class Initialized
DEBUG - 2011-08-23 12:35:23 --> Controller Class Initialized
DEBUG - 2011-08-23 12:35:23 --> Model Class Initialized
DEBUG - 2011-08-23 12:35:23 --> Model Class Initialized
DEBUG - 2011-08-23 12:35:23 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-23 12:35:23 --> Database Driver Class Initialized
DEBUG - 2011-08-23 12:35:23 --> Final output sent to browser
DEBUG - 2011-08-23 12:35:23 --> Total execution time: 0.5165
DEBUG - 2011-08-23 12:35:40 --> Config Class Initialized
DEBUG - 2011-08-23 12:35:40 --> Hooks Class Initialized
DEBUG - 2011-08-23 12:35:40 --> Utf8 Class Initialized
DEBUG - 2011-08-23 12:35:40 --> UTF-8 Support Enabled
DEBUG - 2011-08-23 12:35:40 --> URI Class Initialized
DEBUG - 2011-08-23 12:35:40 --> Router Class Initialized
DEBUG - 2011-08-23 12:35:40 --> Output Class Initialized
DEBUG - 2011-08-23 12:35:40 --> Input Class Initialized
DEBUG - 2011-08-23 12:35:40 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-23 12:35:40 --> Language Class Initialized
DEBUG - 2011-08-23 12:35:40 --> Loader Class Initialized
DEBUG - 2011-08-23 12:35:40 --> Controller Class Initialized
ERROR - 2011-08-23 12:35:40 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-23 12:35:40 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-23 12:35:40 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-23 12:35:40 --> Model Class Initialized
DEBUG - 2011-08-23 12:35:40 --> Model Class Initialized
DEBUG - 2011-08-23 12:35:40 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-23 12:35:40 --> Database Driver Class Initialized
DEBUG - 2011-08-23 12:35:40 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-23 12:35:40 --> Helper loaded: url_helper
DEBUG - 2011-08-23 12:35:40 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-23 12:35:40 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-23 12:35:40 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-23 12:35:40 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-23 12:35:40 --> Final output sent to browser
DEBUG - 2011-08-23 12:35:40 --> Total execution time: 0.0284
DEBUG - 2011-08-23 12:35:42 --> Config Class Initialized
DEBUG - 2011-08-23 12:35:42 --> Hooks Class Initialized
DEBUG - 2011-08-23 12:35:42 --> Utf8 Class Initialized
DEBUG - 2011-08-23 12:35:42 --> UTF-8 Support Enabled
DEBUG - 2011-08-23 12:35:42 --> URI Class Initialized
DEBUG - 2011-08-23 12:35:42 --> Router Class Initialized
DEBUG - 2011-08-23 12:35:42 --> Output Class Initialized
DEBUG - 2011-08-23 12:35:42 --> Input Class Initialized
DEBUG - 2011-08-23 12:35:42 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-23 12:35:42 --> Language Class Initialized
DEBUG - 2011-08-23 12:35:42 --> Loader Class Initialized
DEBUG - 2011-08-23 12:35:42 --> Controller Class Initialized
DEBUG - 2011-08-23 12:35:42 --> Model Class Initialized
DEBUG - 2011-08-23 12:35:42 --> Model Class Initialized
DEBUG - 2011-08-23 12:35:42 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-23 12:35:42 --> Database Driver Class Initialized
DEBUG - 2011-08-23 12:35:45 --> Final output sent to browser
DEBUG - 2011-08-23 12:35:45 --> Total execution time: 2.4439
DEBUG - 2011-08-23 12:35:51 --> Config Class Initialized
DEBUG - 2011-08-23 12:35:51 --> Hooks Class Initialized
DEBUG - 2011-08-23 12:35:51 --> Utf8 Class Initialized
DEBUG - 2011-08-23 12:35:51 --> UTF-8 Support Enabled
DEBUG - 2011-08-23 12:35:51 --> URI Class Initialized
DEBUG - 2011-08-23 12:35:51 --> Router Class Initialized
DEBUG - 2011-08-23 12:35:51 --> Output Class Initialized
DEBUG - 2011-08-23 12:35:51 --> Input Class Initialized
DEBUG - 2011-08-23 12:35:51 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-23 12:35:51 --> Language Class Initialized
DEBUG - 2011-08-23 12:35:51 --> Loader Class Initialized
DEBUG - 2011-08-23 12:35:51 --> Controller Class Initialized
ERROR - 2011-08-23 12:35:51 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-23 12:35:51 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-23 12:35:51 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-23 12:35:51 --> Model Class Initialized
DEBUG - 2011-08-23 12:35:51 --> Model Class Initialized
DEBUG - 2011-08-23 12:35:51 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-23 12:35:51 --> Database Driver Class Initialized
DEBUG - 2011-08-23 12:35:51 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-23 12:35:51 --> Helper loaded: url_helper
DEBUG - 2011-08-23 12:35:51 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-23 12:35:51 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-23 12:35:51 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-23 12:35:51 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-23 12:35:51 --> Final output sent to browser
DEBUG - 2011-08-23 12:35:51 --> Total execution time: 0.0468
DEBUG - 2011-08-23 12:35:52 --> Config Class Initialized
DEBUG - 2011-08-23 12:35:52 --> Hooks Class Initialized
DEBUG - 2011-08-23 12:35:52 --> Utf8 Class Initialized
DEBUG - 2011-08-23 12:35:52 --> UTF-8 Support Enabled
DEBUG - 2011-08-23 12:35:52 --> URI Class Initialized
DEBUG - 2011-08-23 12:35:52 --> Router Class Initialized
DEBUG - 2011-08-23 12:35:52 --> Output Class Initialized
DEBUG - 2011-08-23 12:35:52 --> Input Class Initialized
DEBUG - 2011-08-23 12:35:52 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-23 12:35:52 --> Language Class Initialized
DEBUG - 2011-08-23 12:35:52 --> Loader Class Initialized
DEBUG - 2011-08-23 12:35:52 --> Controller Class Initialized
DEBUG - 2011-08-23 12:35:52 --> Model Class Initialized
DEBUG - 2011-08-23 12:35:52 --> Model Class Initialized
DEBUG - 2011-08-23 12:35:52 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-23 12:35:52 --> Database Driver Class Initialized
DEBUG - 2011-08-23 12:35:53 --> Final output sent to browser
DEBUG - 2011-08-23 12:35:53 --> Total execution time: 0.5019
DEBUG - 2011-08-23 12:39:08 --> Config Class Initialized
DEBUG - 2011-08-23 12:39:08 --> Hooks Class Initialized
DEBUG - 2011-08-23 12:39:08 --> Utf8 Class Initialized
DEBUG - 2011-08-23 12:39:08 --> UTF-8 Support Enabled
DEBUG - 2011-08-23 12:39:08 --> URI Class Initialized
DEBUG - 2011-08-23 12:39:08 --> Router Class Initialized
DEBUG - 2011-08-23 12:39:08 --> Output Class Initialized
DEBUG - 2011-08-23 12:39:09 --> Input Class Initialized
DEBUG - 2011-08-23 12:39:09 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-23 12:39:09 --> Language Class Initialized
DEBUG - 2011-08-23 12:39:09 --> Loader Class Initialized
DEBUG - 2011-08-23 12:39:09 --> Controller Class Initialized
DEBUG - 2011-08-23 12:39:09 --> Model Class Initialized
DEBUG - 2011-08-23 12:39:09 --> Model Class Initialized
DEBUG - 2011-08-23 12:39:09 --> Model Class Initialized
DEBUG - 2011-08-23 12:39:09 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-23 12:39:09 --> Database Driver Class Initialized
DEBUG - 2011-08-23 12:39:11 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-23 12:39:11 --> Helper loaded: url_helper
DEBUG - 2011-08-23 12:39:11 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-23 12:39:11 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-23 12:39:11 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-23 12:39:11 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-23 12:39:11 --> Final output sent to browser
DEBUG - 2011-08-23 12:39:11 --> Total execution time: 2.0802
DEBUG - 2011-08-23 12:39:11 --> Config Class Initialized
DEBUG - 2011-08-23 12:39:11 --> Hooks Class Initialized
DEBUG - 2011-08-23 12:39:11 --> Utf8 Class Initialized
DEBUG - 2011-08-23 12:39:11 --> UTF-8 Support Enabled
DEBUG - 2011-08-23 12:39:11 --> URI Class Initialized
DEBUG - 2011-08-23 12:39:11 --> Router Class Initialized
DEBUG - 2011-08-23 12:39:11 --> Output Class Initialized
DEBUG - 2011-08-23 12:39:11 --> Input Class Initialized
DEBUG - 2011-08-23 12:39:11 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-23 12:39:11 --> Language Class Initialized
DEBUG - 2011-08-23 12:39:11 --> Config Class Initialized
DEBUG - 2011-08-23 12:39:11 --> Hooks Class Initialized
DEBUG - 2011-08-23 12:39:11 --> Utf8 Class Initialized
DEBUG - 2011-08-23 12:39:11 --> UTF-8 Support Enabled
DEBUG - 2011-08-23 12:39:11 --> URI Class Initialized
DEBUG - 2011-08-23 12:39:11 --> Loader Class Initialized
DEBUG - 2011-08-23 12:39:11 --> Controller Class Initialized
DEBUG - 2011-08-23 12:39:11 --> Router Class Initialized
ERROR - 2011-08-23 12:39:11 --> 404 Page Not Found --> favicon.ico
ERROR - 2011-08-23 12:39:11 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-23 12:39:11 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-23 12:39:11 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-23 12:39:11 --> Model Class Initialized
DEBUG - 2011-08-23 12:39:11 --> Model Class Initialized
DEBUG - 2011-08-23 12:39:11 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-23 12:39:11 --> Database Driver Class Initialized
DEBUG - 2011-08-23 12:39:11 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-23 12:39:11 --> Helper loaded: url_helper
DEBUG - 2011-08-23 12:39:11 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-23 12:39:11 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-23 12:39:11 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-23 12:39:11 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-23 12:39:11 --> Final output sent to browser
DEBUG - 2011-08-23 12:39:11 --> Total execution time: 0.1194
DEBUG - 2011-08-23 12:39:12 --> Config Class Initialized
DEBUG - 2011-08-23 12:39:12 --> Hooks Class Initialized
DEBUG - 2011-08-23 12:39:12 --> Utf8 Class Initialized
DEBUG - 2011-08-23 12:39:12 --> UTF-8 Support Enabled
DEBUG - 2011-08-23 12:39:12 --> URI Class Initialized
DEBUG - 2011-08-23 12:39:12 --> Router Class Initialized
ERROR - 2011-08-23 12:39:12 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-23 12:39:12 --> Config Class Initialized
DEBUG - 2011-08-23 12:39:12 --> Hooks Class Initialized
DEBUG - 2011-08-23 12:39:12 --> Utf8 Class Initialized
DEBUG - 2011-08-23 12:39:12 --> UTF-8 Support Enabled
DEBUG - 2011-08-23 12:39:12 --> URI Class Initialized
DEBUG - 2011-08-23 12:39:12 --> Router Class Initialized
DEBUG - 2011-08-23 12:39:12 --> Output Class Initialized
DEBUG - 2011-08-23 12:39:12 --> Input Class Initialized
DEBUG - 2011-08-23 12:39:12 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-23 12:39:12 --> Language Class Initialized
DEBUG - 2011-08-23 12:39:12 --> Loader Class Initialized
DEBUG - 2011-08-23 12:39:12 --> Controller Class Initialized
DEBUG - 2011-08-23 12:39:12 --> Model Class Initialized
DEBUG - 2011-08-23 12:39:12 --> Model Class Initialized
DEBUG - 2011-08-23 12:39:12 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-23 12:39:12 --> Database Driver Class Initialized
DEBUG - 2011-08-23 12:39:13 --> Final output sent to browser
DEBUG - 2011-08-23 12:39:13 --> Total execution time: 0.7804
DEBUG - 2011-08-23 12:39:32 --> Config Class Initialized
DEBUG - 2011-08-23 12:39:32 --> Hooks Class Initialized
DEBUG - 2011-08-23 12:39:32 --> Utf8 Class Initialized
DEBUG - 2011-08-23 12:39:32 --> UTF-8 Support Enabled
DEBUG - 2011-08-23 12:39:32 --> URI Class Initialized
DEBUG - 2011-08-23 12:39:32 --> Router Class Initialized
DEBUG - 2011-08-23 12:39:32 --> Output Class Initialized
DEBUG - 2011-08-23 12:39:32 --> Input Class Initialized
DEBUG - 2011-08-23 12:39:32 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-23 12:39:32 --> Language Class Initialized
DEBUG - 2011-08-23 12:39:32 --> Loader Class Initialized
DEBUG - 2011-08-23 12:39:32 --> Controller Class Initialized
ERROR - 2011-08-23 12:39:32 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-23 12:39:32 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-23 12:39:32 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-23 12:39:32 --> Model Class Initialized
DEBUG - 2011-08-23 12:39:32 --> Model Class Initialized
DEBUG - 2011-08-23 12:39:32 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-23 12:39:32 --> Database Driver Class Initialized
DEBUG - 2011-08-23 12:39:32 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-23 12:39:32 --> Helper loaded: url_helper
DEBUG - 2011-08-23 12:39:32 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-23 12:39:32 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-23 12:39:32 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-23 12:39:32 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-23 12:39:32 --> Final output sent to browser
DEBUG - 2011-08-23 12:39:32 --> Total execution time: 0.0295
DEBUG - 2011-08-23 12:39:32 --> Config Class Initialized
DEBUG - 2011-08-23 12:39:32 --> Hooks Class Initialized
DEBUG - 2011-08-23 12:39:32 --> Utf8 Class Initialized
DEBUG - 2011-08-23 12:39:32 --> UTF-8 Support Enabled
DEBUG - 2011-08-23 12:39:32 --> URI Class Initialized
DEBUG - 2011-08-23 12:39:32 --> Router Class Initialized
DEBUG - 2011-08-23 12:39:32 --> Output Class Initialized
DEBUG - 2011-08-23 12:39:32 --> Input Class Initialized
DEBUG - 2011-08-23 12:39:32 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-23 12:39:32 --> Language Class Initialized
DEBUG - 2011-08-23 12:39:32 --> Loader Class Initialized
DEBUG - 2011-08-23 12:39:32 --> Controller Class Initialized
DEBUG - 2011-08-23 12:39:32 --> Model Class Initialized
DEBUG - 2011-08-23 12:39:32 --> Model Class Initialized
DEBUG - 2011-08-23 12:39:32 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-23 12:39:32 --> Database Driver Class Initialized
DEBUG - 2011-08-23 12:39:33 --> Final output sent to browser
DEBUG - 2011-08-23 12:39:33 --> Total execution time: 0.4494
DEBUG - 2011-08-23 12:39:42 --> Config Class Initialized
DEBUG - 2011-08-23 12:39:42 --> Hooks Class Initialized
DEBUG - 2011-08-23 12:39:42 --> Utf8 Class Initialized
DEBUG - 2011-08-23 12:39:42 --> UTF-8 Support Enabled
DEBUG - 2011-08-23 12:39:42 --> URI Class Initialized
DEBUG - 2011-08-23 12:39:42 --> Router Class Initialized
DEBUG - 2011-08-23 12:39:42 --> Output Class Initialized
DEBUG - 2011-08-23 12:39:42 --> Input Class Initialized
DEBUG - 2011-08-23 12:39:42 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-23 12:39:42 --> Language Class Initialized
DEBUG - 2011-08-23 12:39:42 --> Loader Class Initialized
DEBUG - 2011-08-23 12:39:42 --> Controller Class Initialized
ERROR - 2011-08-23 12:39:42 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-23 12:39:42 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-23 12:39:42 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-23 12:39:42 --> Model Class Initialized
DEBUG - 2011-08-23 12:39:42 --> Model Class Initialized
DEBUG - 2011-08-23 12:39:42 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-23 12:39:42 --> Database Driver Class Initialized
DEBUG - 2011-08-23 12:39:42 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-23 12:39:42 --> Helper loaded: url_helper
DEBUG - 2011-08-23 12:39:42 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-23 12:39:42 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-23 12:39:42 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-23 12:39:42 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-23 12:39:42 --> Final output sent to browser
DEBUG - 2011-08-23 12:39:42 --> Total execution time: 0.0401
DEBUG - 2011-08-23 12:39:42 --> Config Class Initialized
DEBUG - 2011-08-23 12:39:42 --> Hooks Class Initialized
DEBUG - 2011-08-23 12:39:42 --> Utf8 Class Initialized
DEBUG - 2011-08-23 12:39:42 --> UTF-8 Support Enabled
DEBUG - 2011-08-23 12:39:42 --> URI Class Initialized
DEBUG - 2011-08-23 12:39:42 --> Router Class Initialized
DEBUG - 2011-08-23 12:39:42 --> Output Class Initialized
DEBUG - 2011-08-23 12:39:42 --> Input Class Initialized
DEBUG - 2011-08-23 12:39:42 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-23 12:39:42 --> Language Class Initialized
DEBUG - 2011-08-23 12:39:42 --> Loader Class Initialized
DEBUG - 2011-08-23 12:39:42 --> Controller Class Initialized
DEBUG - 2011-08-23 12:39:42 --> Model Class Initialized
DEBUG - 2011-08-23 12:39:42 --> Model Class Initialized
DEBUG - 2011-08-23 12:39:42 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-23 12:39:42 --> Database Driver Class Initialized
DEBUG - 2011-08-23 12:39:43 --> Final output sent to browser
DEBUG - 2011-08-23 12:39:43 --> Total execution time: 0.5540
DEBUG - 2011-08-23 12:39:56 --> Config Class Initialized
DEBUG - 2011-08-23 12:39:56 --> Hooks Class Initialized
DEBUG - 2011-08-23 12:39:56 --> Utf8 Class Initialized
DEBUG - 2011-08-23 12:39:56 --> UTF-8 Support Enabled
DEBUG - 2011-08-23 12:39:56 --> URI Class Initialized
DEBUG - 2011-08-23 12:39:56 --> Router Class Initialized
DEBUG - 2011-08-23 12:39:56 --> Output Class Initialized
DEBUG - 2011-08-23 12:39:56 --> Input Class Initialized
DEBUG - 2011-08-23 12:39:56 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-23 12:39:56 --> Language Class Initialized
DEBUG - 2011-08-23 12:39:56 --> Loader Class Initialized
DEBUG - 2011-08-23 12:39:56 --> Controller Class Initialized
ERROR - 2011-08-23 12:39:56 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-23 12:39:56 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-23 12:39:56 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-23 12:39:56 --> Model Class Initialized
DEBUG - 2011-08-23 12:39:56 --> Model Class Initialized
DEBUG - 2011-08-23 12:39:56 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-23 12:39:57 --> Database Driver Class Initialized
DEBUG - 2011-08-23 12:39:57 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-23 12:39:57 --> Helper loaded: url_helper
DEBUG - 2011-08-23 12:39:57 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-23 12:39:57 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-23 12:39:57 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-23 12:39:57 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-23 12:39:57 --> Final output sent to browser
DEBUG - 2011-08-23 12:39:57 --> Total execution time: 0.0887
DEBUG - 2011-08-23 12:39:57 --> Config Class Initialized
DEBUG - 2011-08-23 12:39:57 --> Hooks Class Initialized
DEBUG - 2011-08-23 12:39:57 --> Utf8 Class Initialized
DEBUG - 2011-08-23 12:39:57 --> UTF-8 Support Enabled
DEBUG - 2011-08-23 12:39:57 --> URI Class Initialized
DEBUG - 2011-08-23 12:39:57 --> Router Class Initialized
DEBUG - 2011-08-23 12:39:57 --> Output Class Initialized
DEBUG - 2011-08-23 12:39:57 --> Input Class Initialized
DEBUG - 2011-08-23 12:39:57 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-23 12:39:57 --> Language Class Initialized
DEBUG - 2011-08-23 12:39:57 --> Loader Class Initialized
DEBUG - 2011-08-23 12:39:57 --> Controller Class Initialized
DEBUG - 2011-08-23 12:39:57 --> Model Class Initialized
DEBUG - 2011-08-23 12:39:57 --> Model Class Initialized
DEBUG - 2011-08-23 12:39:57 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-23 12:39:57 --> Database Driver Class Initialized
DEBUG - 2011-08-23 12:39:58 --> Final output sent to browser
DEBUG - 2011-08-23 12:39:58 --> Total execution time: 0.5507
DEBUG - 2011-08-23 12:40:12 --> Config Class Initialized
DEBUG - 2011-08-23 12:40:12 --> Hooks Class Initialized
DEBUG - 2011-08-23 12:40:12 --> Utf8 Class Initialized
DEBUG - 2011-08-23 12:40:12 --> UTF-8 Support Enabled
DEBUG - 2011-08-23 12:40:12 --> URI Class Initialized
DEBUG - 2011-08-23 12:40:12 --> Router Class Initialized
DEBUG - 2011-08-23 12:40:12 --> Output Class Initialized
DEBUG - 2011-08-23 12:40:12 --> Input Class Initialized
DEBUG - 2011-08-23 12:40:12 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-23 12:40:12 --> Language Class Initialized
DEBUG - 2011-08-23 12:40:12 --> Loader Class Initialized
DEBUG - 2011-08-23 12:40:12 --> Controller Class Initialized
DEBUG - 2011-08-23 12:40:12 --> Model Class Initialized
DEBUG - 2011-08-23 12:40:12 --> Model Class Initialized
DEBUG - 2011-08-23 12:40:12 --> Model Class Initialized
DEBUG - 2011-08-23 12:40:12 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-23 12:40:12 --> Database Driver Class Initialized
DEBUG - 2011-08-23 12:40:12 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-23 12:40:12 --> Helper loaded: url_helper
DEBUG - 2011-08-23 12:40:12 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-23 12:40:12 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-23 12:40:12 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-23 12:40:12 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-23 12:40:12 --> Final output sent to browser
DEBUG - 2011-08-23 12:40:12 --> Total execution time: 0.0746
DEBUG - 2011-08-23 12:40:24 --> Config Class Initialized
DEBUG - 2011-08-23 12:40:24 --> Hooks Class Initialized
DEBUG - 2011-08-23 12:40:24 --> Utf8 Class Initialized
DEBUG - 2011-08-23 12:40:24 --> UTF-8 Support Enabled
DEBUG - 2011-08-23 12:40:24 --> URI Class Initialized
DEBUG - 2011-08-23 12:40:24 --> Router Class Initialized
DEBUG - 2011-08-23 12:40:24 --> Output Class Initialized
DEBUG - 2011-08-23 12:40:24 --> Input Class Initialized
DEBUG - 2011-08-23 12:40:24 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-23 12:40:24 --> Language Class Initialized
DEBUG - 2011-08-23 12:40:24 --> Loader Class Initialized
DEBUG - 2011-08-23 12:40:24 --> Controller Class Initialized
DEBUG - 2011-08-23 12:40:24 --> Model Class Initialized
DEBUG - 2011-08-23 12:40:24 --> Model Class Initialized
DEBUG - 2011-08-23 12:40:24 --> Model Class Initialized
DEBUG - 2011-08-23 12:40:24 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-23 12:40:25 --> Database Driver Class Initialized
DEBUG - 2011-08-23 12:40:25 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-23 12:40:25 --> Helper loaded: url_helper
DEBUG - 2011-08-23 12:40:25 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-23 12:40:25 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-23 12:40:25 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-23 12:40:25 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-23 12:40:25 --> Final output sent to browser
DEBUG - 2011-08-23 12:40:25 --> Total execution time: 0.2803
DEBUG - 2011-08-23 12:40:32 --> Config Class Initialized
DEBUG - 2011-08-23 12:40:32 --> Hooks Class Initialized
DEBUG - 2011-08-23 12:40:32 --> Utf8 Class Initialized
DEBUG - 2011-08-23 12:40:32 --> UTF-8 Support Enabled
DEBUG - 2011-08-23 12:40:32 --> URI Class Initialized
DEBUG - 2011-08-23 12:40:32 --> Router Class Initialized
DEBUG - 2011-08-23 12:40:32 --> Output Class Initialized
DEBUG - 2011-08-23 12:40:32 --> Input Class Initialized
DEBUG - 2011-08-23 12:40:32 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-23 12:40:32 --> Language Class Initialized
DEBUG - 2011-08-23 12:40:32 --> Loader Class Initialized
DEBUG - 2011-08-23 12:40:32 --> Controller Class Initialized
DEBUG - 2011-08-23 12:40:32 --> Model Class Initialized
DEBUG - 2011-08-23 12:40:32 --> Model Class Initialized
DEBUG - 2011-08-23 12:40:32 --> Model Class Initialized
DEBUG - 2011-08-23 12:40:32 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-23 12:40:32 --> Database Driver Class Initialized
DEBUG - 2011-08-23 12:40:32 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-23 12:40:32 --> Helper loaded: url_helper
DEBUG - 2011-08-23 12:40:32 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-23 12:40:32 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-23 12:40:32 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-23 12:40:32 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-23 12:40:32 --> Final output sent to browser
DEBUG - 2011-08-23 12:40:32 --> Total execution time: 0.1202
DEBUG - 2011-08-23 12:40:36 --> Config Class Initialized
DEBUG - 2011-08-23 12:40:36 --> Hooks Class Initialized
DEBUG - 2011-08-23 12:40:36 --> Utf8 Class Initialized
DEBUG - 2011-08-23 12:40:36 --> UTF-8 Support Enabled
DEBUG - 2011-08-23 12:40:36 --> URI Class Initialized
DEBUG - 2011-08-23 12:40:36 --> Router Class Initialized
DEBUG - 2011-08-23 12:40:36 --> Output Class Initialized
DEBUG - 2011-08-23 12:40:36 --> Input Class Initialized
DEBUG - 2011-08-23 12:40:36 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-23 12:40:36 --> Language Class Initialized
DEBUG - 2011-08-23 12:40:36 --> Loader Class Initialized
DEBUG - 2011-08-23 12:40:36 --> Controller Class Initialized
DEBUG - 2011-08-23 12:40:36 --> Model Class Initialized
DEBUG - 2011-08-23 12:40:36 --> Model Class Initialized
DEBUG - 2011-08-23 12:40:36 --> Model Class Initialized
DEBUG - 2011-08-23 12:40:36 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-23 12:40:36 --> Database Driver Class Initialized
DEBUG - 2011-08-23 12:40:36 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-23 12:40:36 --> Helper loaded: url_helper
DEBUG - 2011-08-23 12:40:36 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-23 12:40:36 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-23 12:40:36 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-23 12:40:36 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-23 12:40:36 --> Final output sent to browser
DEBUG - 2011-08-23 12:40:36 --> Total execution time: 0.2853
DEBUG - 2011-08-23 12:40:37 --> Config Class Initialized
DEBUG - 2011-08-23 12:40:37 --> Hooks Class Initialized
DEBUG - 2011-08-23 12:40:37 --> Utf8 Class Initialized
DEBUG - 2011-08-23 12:40:37 --> UTF-8 Support Enabled
DEBUG - 2011-08-23 12:40:37 --> URI Class Initialized
DEBUG - 2011-08-23 12:40:37 --> Router Class Initialized
DEBUG - 2011-08-23 12:40:37 --> Output Class Initialized
DEBUG - 2011-08-23 12:40:37 --> Input Class Initialized
DEBUG - 2011-08-23 12:40:37 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-23 12:40:37 --> Language Class Initialized
DEBUG - 2011-08-23 12:40:37 --> Loader Class Initialized
DEBUG - 2011-08-23 12:40:37 --> Controller Class Initialized
DEBUG - 2011-08-23 12:40:37 --> Model Class Initialized
DEBUG - 2011-08-23 12:40:37 --> Model Class Initialized
DEBUG - 2011-08-23 12:40:37 --> Model Class Initialized
DEBUG - 2011-08-23 12:40:37 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-23 12:40:37 --> Database Driver Class Initialized
DEBUG - 2011-08-23 12:40:37 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-23 12:40:37 --> Helper loaded: url_helper
DEBUG - 2011-08-23 12:40:37 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-23 12:40:37 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-23 12:40:37 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-23 12:40:37 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-23 12:40:37 --> Final output sent to browser
DEBUG - 2011-08-23 12:40:37 --> Total execution time: 0.0432
DEBUG - 2011-08-23 12:40:43 --> Config Class Initialized
DEBUG - 2011-08-23 12:40:43 --> Hooks Class Initialized
DEBUG - 2011-08-23 12:40:43 --> Utf8 Class Initialized
DEBUG - 2011-08-23 12:40:43 --> UTF-8 Support Enabled
DEBUG - 2011-08-23 12:40:43 --> URI Class Initialized
DEBUG - 2011-08-23 12:40:43 --> Router Class Initialized
DEBUG - 2011-08-23 12:40:43 --> Output Class Initialized
DEBUG - 2011-08-23 12:40:43 --> Input Class Initialized
DEBUG - 2011-08-23 12:40:43 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-23 12:40:43 --> Language Class Initialized
DEBUG - 2011-08-23 12:40:43 --> Loader Class Initialized
DEBUG - 2011-08-23 12:40:43 --> Controller Class Initialized
DEBUG - 2011-08-23 12:40:43 --> Model Class Initialized
DEBUG - 2011-08-23 12:40:43 --> Model Class Initialized
DEBUG - 2011-08-23 12:40:43 --> Model Class Initialized
DEBUG - 2011-08-23 12:40:43 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-23 12:40:43 --> Database Driver Class Initialized
DEBUG - 2011-08-23 12:40:44 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-23 12:40:44 --> Helper loaded: url_helper
DEBUG - 2011-08-23 12:40:44 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-23 12:40:44 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-23 12:40:44 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-23 12:40:44 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-23 12:40:44 --> Final output sent to browser
DEBUG - 2011-08-23 12:40:44 --> Total execution time: 1.0594
DEBUG - 2011-08-23 12:40:46 --> Config Class Initialized
DEBUG - 2011-08-23 12:40:46 --> Hooks Class Initialized
DEBUG - 2011-08-23 12:40:46 --> Utf8 Class Initialized
DEBUG - 2011-08-23 12:40:46 --> UTF-8 Support Enabled
DEBUG - 2011-08-23 12:40:46 --> URI Class Initialized
DEBUG - 2011-08-23 12:40:46 --> Router Class Initialized
DEBUG - 2011-08-23 12:40:46 --> Output Class Initialized
DEBUG - 2011-08-23 12:40:46 --> Input Class Initialized
DEBUG - 2011-08-23 12:40:46 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-23 12:40:46 --> Language Class Initialized
DEBUG - 2011-08-23 12:40:46 --> Loader Class Initialized
DEBUG - 2011-08-23 12:40:46 --> Controller Class Initialized
DEBUG - 2011-08-23 12:40:46 --> Model Class Initialized
DEBUG - 2011-08-23 12:40:46 --> Model Class Initialized
DEBUG - 2011-08-23 12:40:46 --> Model Class Initialized
DEBUG - 2011-08-23 12:40:46 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-23 12:40:46 --> Database Driver Class Initialized
DEBUG - 2011-08-23 12:40:46 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-23 12:40:46 --> Helper loaded: url_helper
DEBUG - 2011-08-23 12:40:46 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-23 12:40:46 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-23 12:40:46 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-23 12:40:46 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-23 12:40:46 --> Final output sent to browser
DEBUG - 2011-08-23 12:40:46 --> Total execution time: 0.0674
DEBUG - 2011-08-23 13:08:07 --> Config Class Initialized
DEBUG - 2011-08-23 13:08:07 --> Hooks Class Initialized
DEBUG - 2011-08-23 13:08:07 --> Utf8 Class Initialized
DEBUG - 2011-08-23 13:08:07 --> UTF-8 Support Enabled
DEBUG - 2011-08-23 13:08:07 --> URI Class Initialized
DEBUG - 2011-08-23 13:08:07 --> Router Class Initialized
DEBUG - 2011-08-23 13:08:07 --> Output Class Initialized
DEBUG - 2011-08-23 13:08:07 --> Input Class Initialized
DEBUG - 2011-08-23 13:08:07 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-23 13:08:07 --> Language Class Initialized
DEBUG - 2011-08-23 13:08:07 --> Loader Class Initialized
DEBUG - 2011-08-23 13:08:07 --> Controller Class Initialized
DEBUG - 2011-08-23 13:08:07 --> Model Class Initialized
DEBUG - 2011-08-23 13:08:07 --> Model Class Initialized
DEBUG - 2011-08-23 13:08:07 --> Model Class Initialized
DEBUG - 2011-08-23 13:08:07 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-23 13:08:07 --> Database Driver Class Initialized
DEBUG - 2011-08-23 13:08:07 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-23 13:08:07 --> Helper loaded: url_helper
DEBUG - 2011-08-23 13:08:07 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-23 13:08:07 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-23 13:08:07 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-23 13:08:07 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-23 13:08:07 --> Final output sent to browser
DEBUG - 2011-08-23 13:08:07 --> Total execution time: 0.3676
DEBUG - 2011-08-23 13:08:10 --> Config Class Initialized
DEBUG - 2011-08-23 13:08:10 --> Hooks Class Initialized
DEBUG - 2011-08-23 13:08:10 --> Utf8 Class Initialized
DEBUG - 2011-08-23 13:08:10 --> UTF-8 Support Enabled
DEBUG - 2011-08-23 13:08:10 --> URI Class Initialized
DEBUG - 2011-08-23 13:08:10 --> Router Class Initialized
ERROR - 2011-08-23 13:08:10 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-23 13:08:11 --> Config Class Initialized
DEBUG - 2011-08-23 13:08:11 --> Hooks Class Initialized
DEBUG - 2011-08-23 13:08:11 --> Utf8 Class Initialized
DEBUG - 2011-08-23 13:08:11 --> UTF-8 Support Enabled
DEBUG - 2011-08-23 13:08:11 --> URI Class Initialized
DEBUG - 2011-08-23 13:08:11 --> Router Class Initialized
ERROR - 2011-08-23 13:08:11 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-23 13:08:11 --> Config Class Initialized
DEBUG - 2011-08-23 13:08:11 --> Hooks Class Initialized
DEBUG - 2011-08-23 13:08:11 --> Utf8 Class Initialized
DEBUG - 2011-08-23 13:08:11 --> UTF-8 Support Enabled
DEBUG - 2011-08-23 13:08:11 --> URI Class Initialized
DEBUG - 2011-08-23 13:08:11 --> Router Class Initialized
ERROR - 2011-08-23 13:08:11 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-23 13:18:54 --> Config Class Initialized
DEBUG - 2011-08-23 13:18:54 --> Hooks Class Initialized
DEBUG - 2011-08-23 13:18:54 --> Utf8 Class Initialized
DEBUG - 2011-08-23 13:18:54 --> UTF-8 Support Enabled
DEBUG - 2011-08-23 13:18:54 --> URI Class Initialized
DEBUG - 2011-08-23 13:18:54 --> Router Class Initialized
DEBUG - 2011-08-23 13:18:54 --> Output Class Initialized
DEBUG - 2011-08-23 13:18:54 --> Input Class Initialized
DEBUG - 2011-08-23 13:18:54 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-23 13:18:54 --> Language Class Initialized
DEBUG - 2011-08-23 13:18:54 --> Loader Class Initialized
DEBUG - 2011-08-23 13:18:54 --> Controller Class Initialized
DEBUG - 2011-08-23 13:18:54 --> Model Class Initialized
DEBUG - 2011-08-23 13:18:54 --> Model Class Initialized
DEBUG - 2011-08-23 13:18:54 --> Model Class Initialized
DEBUG - 2011-08-23 13:18:54 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-23 13:18:54 --> Database Driver Class Initialized
DEBUG - 2011-08-23 13:18:54 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-23 13:18:54 --> Helper loaded: url_helper
DEBUG - 2011-08-23 13:18:54 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-23 13:18:54 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-23 13:18:54 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-23 13:18:54 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-23 13:18:54 --> Final output sent to browser
DEBUG - 2011-08-23 13:18:54 --> Total execution time: 0.0652
DEBUG - 2011-08-23 13:18:56 --> Config Class Initialized
DEBUG - 2011-08-23 13:18:56 --> Hooks Class Initialized
DEBUG - 2011-08-23 13:18:56 --> Utf8 Class Initialized
DEBUG - 2011-08-23 13:18:56 --> UTF-8 Support Enabled
DEBUG - 2011-08-23 13:18:56 --> URI Class Initialized
DEBUG - 2011-08-23 13:18:56 --> Router Class Initialized
ERROR - 2011-08-23 13:18:56 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-23 13:19:22 --> Config Class Initialized
DEBUG - 2011-08-23 13:19:22 --> Hooks Class Initialized
DEBUG - 2011-08-23 13:19:22 --> Utf8 Class Initialized
DEBUG - 2011-08-23 13:19:22 --> UTF-8 Support Enabled
DEBUG - 2011-08-23 13:19:22 --> URI Class Initialized
DEBUG - 2011-08-23 13:19:22 --> Router Class Initialized
DEBUG - 2011-08-23 13:19:22 --> Output Class Initialized
DEBUG - 2011-08-23 13:19:22 --> Input Class Initialized
DEBUG - 2011-08-23 13:19:22 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-23 13:19:22 --> Language Class Initialized
DEBUG - 2011-08-23 13:19:22 --> Loader Class Initialized
DEBUG - 2011-08-23 13:19:22 --> Controller Class Initialized
ERROR - 2011-08-23 13:19:22 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-23 13:19:22 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-23 13:19:22 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-23 13:19:22 --> Model Class Initialized
DEBUG - 2011-08-23 13:19:22 --> Model Class Initialized
DEBUG - 2011-08-23 13:19:22 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-23 13:19:22 --> Database Driver Class Initialized
DEBUG - 2011-08-23 13:19:22 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-23 13:19:22 --> Helper loaded: url_helper
DEBUG - 2011-08-23 13:19:22 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-23 13:19:22 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-23 13:19:22 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-23 13:19:22 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-23 13:19:22 --> Final output sent to browser
DEBUG - 2011-08-23 13:19:22 --> Total execution time: 0.0309
DEBUG - 2011-08-23 13:19:23 --> Config Class Initialized
DEBUG - 2011-08-23 13:19:23 --> Hooks Class Initialized
DEBUG - 2011-08-23 13:19:23 --> Utf8 Class Initialized
DEBUG - 2011-08-23 13:19:23 --> UTF-8 Support Enabled
DEBUG - 2011-08-23 13:19:23 --> URI Class Initialized
DEBUG - 2011-08-23 13:19:23 --> Router Class Initialized
DEBUG - 2011-08-23 13:19:23 --> Output Class Initialized
DEBUG - 2011-08-23 13:19:23 --> Input Class Initialized
DEBUG - 2011-08-23 13:19:23 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-23 13:19:23 --> Language Class Initialized
DEBUG - 2011-08-23 13:19:23 --> Loader Class Initialized
DEBUG - 2011-08-23 13:19:23 --> Controller Class Initialized
DEBUG - 2011-08-23 13:19:23 --> Model Class Initialized
DEBUG - 2011-08-23 13:19:23 --> Model Class Initialized
DEBUG - 2011-08-23 13:19:23 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-23 13:19:23 --> Database Driver Class Initialized
DEBUG - 2011-08-23 13:19:24 --> Final output sent to browser
DEBUG - 2011-08-23 13:19:24 --> Total execution time: 0.5033
DEBUG - 2011-08-23 13:19:26 --> Config Class Initialized
DEBUG - 2011-08-23 13:19:26 --> Hooks Class Initialized
DEBUG - 2011-08-23 13:19:26 --> Utf8 Class Initialized
DEBUG - 2011-08-23 13:19:26 --> UTF-8 Support Enabled
DEBUG - 2011-08-23 13:19:26 --> URI Class Initialized
DEBUG - 2011-08-23 13:19:26 --> Router Class Initialized
ERROR - 2011-08-23 13:19:26 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-23 13:19:27 --> Config Class Initialized
DEBUG - 2011-08-23 13:19:27 --> Hooks Class Initialized
DEBUG - 2011-08-23 13:19:27 --> Utf8 Class Initialized
DEBUG - 2011-08-23 13:19:27 --> UTF-8 Support Enabled
DEBUG - 2011-08-23 13:19:27 --> URI Class Initialized
DEBUG - 2011-08-23 13:19:27 --> Router Class Initialized
ERROR - 2011-08-23 13:19:27 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-23 13:19:42 --> Config Class Initialized
DEBUG - 2011-08-23 13:19:42 --> Hooks Class Initialized
DEBUG - 2011-08-23 13:19:42 --> Utf8 Class Initialized
DEBUG - 2011-08-23 13:19:42 --> UTF-8 Support Enabled
DEBUG - 2011-08-23 13:19:42 --> URI Class Initialized
DEBUG - 2011-08-23 13:19:42 --> Router Class Initialized
DEBUG - 2011-08-23 13:19:42 --> Output Class Initialized
DEBUG - 2011-08-23 13:19:42 --> Input Class Initialized
DEBUG - 2011-08-23 13:19:42 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-23 13:19:42 --> Language Class Initialized
DEBUG - 2011-08-23 13:19:42 --> Loader Class Initialized
DEBUG - 2011-08-23 13:19:42 --> Controller Class Initialized
ERROR - 2011-08-23 13:19:42 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-23 13:19:42 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-23 13:19:42 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-23 13:19:42 --> Model Class Initialized
DEBUG - 2011-08-23 13:19:42 --> Model Class Initialized
DEBUG - 2011-08-23 13:19:42 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-23 13:19:43 --> Database Driver Class Initialized
DEBUG - 2011-08-23 13:19:43 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-23 13:19:43 --> Helper loaded: url_helper
DEBUG - 2011-08-23 13:19:43 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-23 13:19:43 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-23 13:19:43 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-23 13:19:43 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-23 13:19:43 --> Final output sent to browser
DEBUG - 2011-08-23 13:19:43 --> Total execution time: 0.1367
DEBUG - 2011-08-23 13:19:44 --> Config Class Initialized
DEBUG - 2011-08-23 13:19:44 --> Hooks Class Initialized
DEBUG - 2011-08-23 13:19:44 --> Utf8 Class Initialized
DEBUG - 2011-08-23 13:19:44 --> UTF-8 Support Enabled
DEBUG - 2011-08-23 13:19:44 --> URI Class Initialized
DEBUG - 2011-08-23 13:19:44 --> Router Class Initialized
DEBUG - 2011-08-23 13:19:44 --> Output Class Initialized
DEBUG - 2011-08-23 13:19:44 --> Input Class Initialized
DEBUG - 2011-08-23 13:19:44 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-23 13:19:44 --> Language Class Initialized
DEBUG - 2011-08-23 13:19:44 --> Loader Class Initialized
DEBUG - 2011-08-23 13:19:44 --> Controller Class Initialized
DEBUG - 2011-08-23 13:19:44 --> Model Class Initialized
DEBUG - 2011-08-23 13:19:44 --> Model Class Initialized
DEBUG - 2011-08-23 13:19:44 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-23 13:19:44 --> Database Driver Class Initialized
DEBUG - 2011-08-23 13:19:45 --> Final output sent to browser
DEBUG - 2011-08-23 13:19:45 --> Total execution time: 0.6491
DEBUG - 2011-08-23 13:19:46 --> Config Class Initialized
DEBUG - 2011-08-23 13:19:46 --> Hooks Class Initialized
DEBUG - 2011-08-23 13:19:46 --> Utf8 Class Initialized
DEBUG - 2011-08-23 13:19:46 --> UTF-8 Support Enabled
DEBUG - 2011-08-23 13:19:46 --> URI Class Initialized
DEBUG - 2011-08-23 13:19:46 --> Router Class Initialized
ERROR - 2011-08-23 13:19:46 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-23 13:19:55 --> Config Class Initialized
DEBUG - 2011-08-23 13:19:55 --> Hooks Class Initialized
DEBUG - 2011-08-23 13:19:55 --> Utf8 Class Initialized
DEBUG - 2011-08-23 13:19:55 --> UTF-8 Support Enabled
DEBUG - 2011-08-23 13:19:55 --> URI Class Initialized
DEBUG - 2011-08-23 13:19:55 --> Router Class Initialized
DEBUG - 2011-08-23 13:19:55 --> Output Class Initialized
DEBUG - 2011-08-23 13:19:55 --> Input Class Initialized
DEBUG - 2011-08-23 13:19:55 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-23 13:19:55 --> Language Class Initialized
DEBUG - 2011-08-23 13:19:55 --> Loader Class Initialized
DEBUG - 2011-08-23 13:19:55 --> Controller Class Initialized
ERROR - 2011-08-23 13:19:55 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-23 13:19:55 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-23 13:19:55 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-23 13:19:55 --> Model Class Initialized
DEBUG - 2011-08-23 13:19:55 --> Model Class Initialized
DEBUG - 2011-08-23 13:19:55 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-23 13:19:55 --> Database Driver Class Initialized
DEBUG - 2011-08-23 13:19:55 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-23 13:19:55 --> Helper loaded: url_helper
DEBUG - 2011-08-23 13:19:55 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-23 13:19:55 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-23 13:19:55 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-23 13:19:55 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-23 13:19:55 --> Final output sent to browser
DEBUG - 2011-08-23 13:19:55 --> Total execution time: 0.0623
DEBUG - 2011-08-23 13:19:55 --> Config Class Initialized
DEBUG - 2011-08-23 13:19:55 --> Hooks Class Initialized
DEBUG - 2011-08-23 13:19:55 --> Utf8 Class Initialized
DEBUG - 2011-08-23 13:19:55 --> UTF-8 Support Enabled
DEBUG - 2011-08-23 13:19:55 --> URI Class Initialized
DEBUG - 2011-08-23 13:19:55 --> Router Class Initialized
DEBUG - 2011-08-23 13:19:55 --> Output Class Initialized
DEBUG - 2011-08-23 13:19:55 --> Input Class Initialized
DEBUG - 2011-08-23 13:19:55 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-23 13:19:55 --> Language Class Initialized
DEBUG - 2011-08-23 13:19:55 --> Loader Class Initialized
DEBUG - 2011-08-23 13:19:55 --> Controller Class Initialized
DEBUG - 2011-08-23 13:19:55 --> Model Class Initialized
DEBUG - 2011-08-23 13:19:55 --> Model Class Initialized
DEBUG - 2011-08-23 13:19:55 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-23 13:19:55 --> Database Driver Class Initialized
DEBUG - 2011-08-23 13:19:56 --> Config Class Initialized
DEBUG - 2011-08-23 13:19:56 --> Hooks Class Initialized
DEBUG - 2011-08-23 13:19:56 --> Utf8 Class Initialized
DEBUG - 2011-08-23 13:19:56 --> UTF-8 Support Enabled
DEBUG - 2011-08-23 13:19:56 --> URI Class Initialized
DEBUG - 2011-08-23 13:19:56 --> Router Class Initialized
DEBUG - 2011-08-23 13:19:56 --> Output Class Initialized
DEBUG - 2011-08-23 13:19:56 --> Input Class Initialized
DEBUG - 2011-08-23 13:19:56 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-23 13:19:56 --> Language Class Initialized
DEBUG - 2011-08-23 13:19:56 --> Loader Class Initialized
DEBUG - 2011-08-23 13:19:56 --> Controller Class Initialized
ERROR - 2011-08-23 13:19:56 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-23 13:19:56 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-23 13:19:56 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-23 13:19:56 --> Model Class Initialized
DEBUG - 2011-08-23 13:19:56 --> Model Class Initialized
DEBUG - 2011-08-23 13:19:56 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-23 13:19:56 --> Database Driver Class Initialized
DEBUG - 2011-08-23 13:19:56 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-23 13:19:56 --> Helper loaded: url_helper
DEBUG - 2011-08-23 13:19:56 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-23 13:19:56 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-23 13:19:56 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-23 13:19:56 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-23 13:19:56 --> Final output sent to browser
DEBUG - 2011-08-23 13:19:56 --> Total execution time: 0.0338
DEBUG - 2011-08-23 13:19:56 --> Final output sent to browser
DEBUG - 2011-08-23 13:19:56 --> Total execution time: 0.5225
DEBUG - 2011-08-23 13:19:57 --> Config Class Initialized
DEBUG - 2011-08-23 13:19:57 --> Hooks Class Initialized
DEBUG - 2011-08-23 13:19:57 --> Utf8 Class Initialized
DEBUG - 2011-08-23 13:19:57 --> UTF-8 Support Enabled
DEBUG - 2011-08-23 13:19:57 --> URI Class Initialized
DEBUG - 2011-08-23 13:19:57 --> Router Class Initialized
ERROR - 2011-08-23 13:19:57 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-23 13:20:00 --> Config Class Initialized
DEBUG - 2011-08-23 13:20:00 --> Hooks Class Initialized
DEBUG - 2011-08-23 13:20:00 --> Utf8 Class Initialized
DEBUG - 2011-08-23 13:20:00 --> UTF-8 Support Enabled
DEBUG - 2011-08-23 13:20:00 --> URI Class Initialized
DEBUG - 2011-08-23 13:20:00 --> Router Class Initialized
DEBUG - 2011-08-23 13:20:00 --> Output Class Initialized
DEBUG - 2011-08-23 13:20:00 --> Input Class Initialized
DEBUG - 2011-08-23 13:20:00 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-23 13:20:00 --> Language Class Initialized
DEBUG - 2011-08-23 13:20:00 --> Loader Class Initialized
DEBUG - 2011-08-23 13:20:00 --> Controller Class Initialized
ERROR - 2011-08-23 13:20:00 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-23 13:20:00 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-23 13:20:00 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-23 13:20:00 --> Model Class Initialized
DEBUG - 2011-08-23 13:20:00 --> Model Class Initialized
DEBUG - 2011-08-23 13:20:00 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-23 13:20:00 --> Database Driver Class Initialized
DEBUG - 2011-08-23 13:20:00 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-23 13:20:00 --> Helper loaded: url_helper
DEBUG - 2011-08-23 13:20:00 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-23 13:20:00 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-23 13:20:00 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-23 13:20:00 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-23 13:20:00 --> Final output sent to browser
DEBUG - 2011-08-23 13:20:00 --> Total execution time: 0.0286
DEBUG - 2011-08-23 13:20:01 --> Config Class Initialized
DEBUG - 2011-08-23 13:20:01 --> Hooks Class Initialized
DEBUG - 2011-08-23 13:20:01 --> Utf8 Class Initialized
DEBUG - 2011-08-23 13:20:01 --> UTF-8 Support Enabled
DEBUG - 2011-08-23 13:20:01 --> URI Class Initialized
DEBUG - 2011-08-23 13:20:01 --> Router Class Initialized
DEBUG - 2011-08-23 13:20:01 --> Output Class Initialized
DEBUG - 2011-08-23 13:20:01 --> Input Class Initialized
DEBUG - 2011-08-23 13:20:01 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-23 13:20:01 --> Language Class Initialized
DEBUG - 2011-08-23 13:20:01 --> Loader Class Initialized
DEBUG - 2011-08-23 13:20:01 --> Controller Class Initialized
DEBUG - 2011-08-23 13:20:01 --> Model Class Initialized
DEBUG - 2011-08-23 13:20:01 --> Model Class Initialized
DEBUG - 2011-08-23 13:20:01 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-23 13:20:01 --> Database Driver Class Initialized
DEBUG - 2011-08-23 13:20:02 --> Final output sent to browser
DEBUG - 2011-08-23 13:20:02 --> Total execution time: 0.5669
DEBUG - 2011-08-23 13:20:03 --> Config Class Initialized
DEBUG - 2011-08-23 13:20:03 --> Hooks Class Initialized
DEBUG - 2011-08-23 13:20:03 --> Utf8 Class Initialized
DEBUG - 2011-08-23 13:20:03 --> UTF-8 Support Enabled
DEBUG - 2011-08-23 13:20:03 --> URI Class Initialized
DEBUG - 2011-08-23 13:20:03 --> Router Class Initialized
ERROR - 2011-08-23 13:20:03 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-23 13:20:07 --> Config Class Initialized
DEBUG - 2011-08-23 13:20:07 --> Hooks Class Initialized
DEBUG - 2011-08-23 13:20:07 --> Utf8 Class Initialized
DEBUG - 2011-08-23 13:20:07 --> UTF-8 Support Enabled
DEBUG - 2011-08-23 13:20:07 --> URI Class Initialized
DEBUG - 2011-08-23 13:20:07 --> Router Class Initialized
DEBUG - 2011-08-23 13:20:07 --> Output Class Initialized
DEBUG - 2011-08-23 13:20:07 --> Input Class Initialized
DEBUG - 2011-08-23 13:20:07 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-23 13:20:07 --> Language Class Initialized
DEBUG - 2011-08-23 13:20:07 --> Loader Class Initialized
DEBUG - 2011-08-23 13:20:07 --> Controller Class Initialized
ERROR - 2011-08-23 13:20:07 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-23 13:20:07 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-23 13:20:07 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-23 13:20:07 --> Model Class Initialized
DEBUG - 2011-08-23 13:20:07 --> Model Class Initialized
DEBUG - 2011-08-23 13:20:07 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-23 13:20:07 --> Database Driver Class Initialized
DEBUG - 2011-08-23 13:20:07 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-23 13:20:07 --> Helper loaded: url_helper
DEBUG - 2011-08-23 13:20:07 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-23 13:20:07 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-23 13:20:07 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-23 13:20:07 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-23 13:20:07 --> Final output sent to browser
DEBUG - 2011-08-23 13:20:07 --> Total execution time: 0.0870
DEBUG - 2011-08-23 13:20:08 --> Config Class Initialized
DEBUG - 2011-08-23 13:20:09 --> Hooks Class Initialized
DEBUG - 2011-08-23 13:20:09 --> Utf8 Class Initialized
DEBUG - 2011-08-23 13:20:09 --> UTF-8 Support Enabled
DEBUG - 2011-08-23 13:20:09 --> URI Class Initialized
DEBUG - 2011-08-23 13:20:09 --> Router Class Initialized
DEBUG - 2011-08-23 13:20:09 --> Output Class Initialized
DEBUG - 2011-08-23 13:20:09 --> Input Class Initialized
DEBUG - 2011-08-23 13:20:09 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-23 13:20:09 --> Language Class Initialized
DEBUG - 2011-08-23 13:20:09 --> Loader Class Initialized
DEBUG - 2011-08-23 13:20:09 --> Controller Class Initialized
DEBUG - 2011-08-23 13:20:09 --> Model Class Initialized
DEBUG - 2011-08-23 13:20:09 --> Model Class Initialized
DEBUG - 2011-08-23 13:20:09 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-23 13:20:09 --> Database Driver Class Initialized
DEBUG - 2011-08-23 13:20:09 --> Config Class Initialized
DEBUG - 2011-08-23 13:20:09 --> Hooks Class Initialized
DEBUG - 2011-08-23 13:20:09 --> Utf8 Class Initialized
DEBUG - 2011-08-23 13:20:09 --> UTF-8 Support Enabled
DEBUG - 2011-08-23 13:20:09 --> URI Class Initialized
DEBUG - 2011-08-23 13:20:09 --> Router Class Initialized
DEBUG - 2011-08-23 13:20:09 --> Output Class Initialized
DEBUG - 2011-08-23 13:20:09 --> Final output sent to browser
DEBUG - 2011-08-23 13:20:09 --> Total execution time: 0.6498
DEBUG - 2011-08-23 13:20:09 --> Input Class Initialized
DEBUG - 2011-08-23 13:20:09 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-23 13:20:09 --> Language Class Initialized
DEBUG - 2011-08-23 13:20:09 --> Loader Class Initialized
DEBUG - 2011-08-23 13:20:09 --> Controller Class Initialized
ERROR - 2011-08-23 13:20:09 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-23 13:20:09 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-23 13:20:09 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-23 13:20:09 --> Model Class Initialized
DEBUG - 2011-08-23 13:20:09 --> Model Class Initialized
DEBUG - 2011-08-23 13:20:09 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-23 13:20:09 --> Database Driver Class Initialized
DEBUG - 2011-08-23 13:20:09 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-23 13:20:09 --> Helper loaded: url_helper
DEBUG - 2011-08-23 13:20:09 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-23 13:20:09 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-23 13:20:09 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-23 13:20:09 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-23 13:20:09 --> Final output sent to browser
DEBUG - 2011-08-23 13:20:09 --> Total execution time: 0.0378
DEBUG - 2011-08-23 13:20:11 --> Config Class Initialized
DEBUG - 2011-08-23 13:20:11 --> Hooks Class Initialized
DEBUG - 2011-08-23 13:20:11 --> Utf8 Class Initialized
DEBUG - 2011-08-23 13:20:11 --> UTF-8 Support Enabled
DEBUG - 2011-08-23 13:20:11 --> URI Class Initialized
DEBUG - 2011-08-23 13:20:11 --> Router Class Initialized
ERROR - 2011-08-23 13:20:11 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-23 13:45:56 --> Config Class Initialized
DEBUG - 2011-08-23 13:45:56 --> Hooks Class Initialized
DEBUG - 2011-08-23 13:45:56 --> Utf8 Class Initialized
DEBUG - 2011-08-23 13:45:56 --> UTF-8 Support Enabled
DEBUG - 2011-08-23 13:45:56 --> URI Class Initialized
DEBUG - 2011-08-23 13:45:56 --> Router Class Initialized
DEBUG - 2011-08-23 13:45:56 --> Output Class Initialized
DEBUG - 2011-08-23 13:45:56 --> Input Class Initialized
DEBUG - 2011-08-23 13:45:56 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-23 13:45:56 --> Language Class Initialized
DEBUG - 2011-08-23 13:45:56 --> Loader Class Initialized
DEBUG - 2011-08-23 13:45:56 --> Controller Class Initialized
ERROR - 2011-08-23 13:45:56 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-23 13:45:56 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-23 13:45:56 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-23 13:45:56 --> Model Class Initialized
DEBUG - 2011-08-23 13:45:56 --> Model Class Initialized
DEBUG - 2011-08-23 13:45:56 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-23 13:45:56 --> Database Driver Class Initialized
DEBUG - 2011-08-23 13:45:56 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-23 13:45:56 --> Helper loaded: url_helper
DEBUG - 2011-08-23 13:45:56 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-23 13:45:56 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-23 13:45:56 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-23 13:45:56 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-23 13:45:56 --> Final output sent to browser
DEBUG - 2011-08-23 13:45:56 --> Total execution time: 0.0414
DEBUG - 2011-08-23 13:45:57 --> Config Class Initialized
DEBUG - 2011-08-23 13:45:57 --> Hooks Class Initialized
DEBUG - 2011-08-23 13:45:57 --> Utf8 Class Initialized
DEBUG - 2011-08-23 13:45:57 --> UTF-8 Support Enabled
DEBUG - 2011-08-23 13:45:57 --> URI Class Initialized
DEBUG - 2011-08-23 13:45:57 --> Router Class Initialized
DEBUG - 2011-08-23 13:45:57 --> Output Class Initialized
DEBUG - 2011-08-23 13:45:57 --> Input Class Initialized
DEBUG - 2011-08-23 13:45:57 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-23 13:45:57 --> Language Class Initialized
DEBUG - 2011-08-23 13:45:57 --> Loader Class Initialized
DEBUG - 2011-08-23 13:45:57 --> Controller Class Initialized
DEBUG - 2011-08-23 13:45:57 --> Model Class Initialized
DEBUG - 2011-08-23 13:45:57 --> Model Class Initialized
DEBUG - 2011-08-23 13:45:57 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-23 13:45:57 --> Database Driver Class Initialized
DEBUG - 2011-08-23 13:45:58 --> Final output sent to browser
DEBUG - 2011-08-23 13:45:58 --> Total execution time: 0.4975
DEBUG - 2011-08-23 13:46:01 --> Config Class Initialized
DEBUG - 2011-08-23 13:46:01 --> Hooks Class Initialized
DEBUG - 2011-08-23 13:46:01 --> Utf8 Class Initialized
DEBUG - 2011-08-23 13:46:01 --> UTF-8 Support Enabled
DEBUG - 2011-08-23 13:46:01 --> URI Class Initialized
DEBUG - 2011-08-23 13:46:01 --> Router Class Initialized
ERROR - 2011-08-23 13:46:01 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-23 14:30:41 --> Config Class Initialized
DEBUG - 2011-08-23 14:30:41 --> Hooks Class Initialized
DEBUG - 2011-08-23 14:30:41 --> Utf8 Class Initialized
DEBUG - 2011-08-23 14:30:41 --> UTF-8 Support Enabled
DEBUG - 2011-08-23 14:30:41 --> URI Class Initialized
DEBUG - 2011-08-23 14:30:41 --> Router Class Initialized
ERROR - 2011-08-23 14:30:41 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-08-23 14:30:41 --> Config Class Initialized
DEBUG - 2011-08-23 14:30:41 --> Hooks Class Initialized
DEBUG - 2011-08-23 14:30:41 --> Utf8 Class Initialized
DEBUG - 2011-08-23 14:30:41 --> UTF-8 Support Enabled
DEBUG - 2011-08-23 14:30:41 --> URI Class Initialized
DEBUG - 2011-08-23 14:30:41 --> Router Class Initialized
DEBUG - 2011-08-23 14:30:41 --> Output Class Initialized
DEBUG - 2011-08-23 14:30:41 --> Input Class Initialized
DEBUG - 2011-08-23 14:30:41 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-23 14:30:41 --> Language Class Initialized
DEBUG - 2011-08-23 14:30:41 --> Loader Class Initialized
DEBUG - 2011-08-23 14:30:41 --> Controller Class Initialized
ERROR - 2011-08-23 14:30:41 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-23 14:30:41 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-23 14:30:41 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-23 14:30:41 --> Model Class Initialized
DEBUG - 2011-08-23 14:30:41 --> Model Class Initialized
DEBUG - 2011-08-23 14:30:41 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-23 14:30:41 --> Database Driver Class Initialized
DEBUG - 2011-08-23 14:30:41 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-23 14:30:41 --> Helper loaded: url_helper
DEBUG - 2011-08-23 14:30:41 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-23 14:30:41 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-23 14:30:41 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-23 14:30:41 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-23 14:30:41 --> Final output sent to browser
DEBUG - 2011-08-23 14:30:41 --> Total execution time: 0.0299
DEBUG - 2011-08-23 14:43:53 --> Config Class Initialized
DEBUG - 2011-08-23 14:43:53 --> Hooks Class Initialized
DEBUG - 2011-08-23 14:43:53 --> Utf8 Class Initialized
DEBUG - 2011-08-23 14:43:53 --> UTF-8 Support Enabled
DEBUG - 2011-08-23 14:43:53 --> URI Class Initialized
DEBUG - 2011-08-23 14:43:53 --> Router Class Initialized
DEBUG - 2011-08-23 14:43:53 --> Output Class Initialized
DEBUG - 2011-08-23 14:43:53 --> Input Class Initialized
DEBUG - 2011-08-23 14:43:53 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-23 14:43:53 --> Language Class Initialized
DEBUG - 2011-08-23 14:43:53 --> Loader Class Initialized
DEBUG - 2011-08-23 14:43:53 --> Controller Class Initialized
DEBUG - 2011-08-23 14:43:53 --> Model Class Initialized
DEBUG - 2011-08-23 14:43:53 --> Model Class Initialized
DEBUG - 2011-08-23 14:43:53 --> Model Class Initialized
DEBUG - 2011-08-23 14:43:53 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-23 14:43:53 --> Database Driver Class Initialized
DEBUG - 2011-08-23 14:43:53 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-23 14:43:53 --> Helper loaded: url_helper
DEBUG - 2011-08-23 14:43:53 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-23 14:43:53 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-23 14:43:53 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-23 14:43:53 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-23 14:43:53 --> Final output sent to browser
DEBUG - 2011-08-23 14:43:53 --> Total execution time: 0.6136
DEBUG - 2011-08-23 14:45:18 --> Config Class Initialized
DEBUG - 2011-08-23 14:45:18 --> Hooks Class Initialized
DEBUG - 2011-08-23 14:45:18 --> Utf8 Class Initialized
DEBUG - 2011-08-23 14:45:18 --> UTF-8 Support Enabled
DEBUG - 2011-08-23 14:45:18 --> URI Class Initialized
DEBUG - 2011-08-23 14:45:18 --> Router Class Initialized
ERROR - 2011-08-23 14:45:18 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-23 14:47:50 --> Config Class Initialized
DEBUG - 2011-08-23 14:47:50 --> Hooks Class Initialized
DEBUG - 2011-08-23 14:47:50 --> Utf8 Class Initialized
DEBUG - 2011-08-23 14:47:50 --> UTF-8 Support Enabled
DEBUG - 2011-08-23 14:47:50 --> URI Class Initialized
DEBUG - 2011-08-23 14:47:50 --> Router Class Initialized
DEBUG - 2011-08-23 14:47:50 --> Output Class Initialized
DEBUG - 2011-08-23 14:47:50 --> Input Class Initialized
DEBUG - 2011-08-23 14:47:50 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-23 14:47:50 --> Language Class Initialized
DEBUG - 2011-08-23 14:47:50 --> Loader Class Initialized
DEBUG - 2011-08-23 14:47:50 --> Controller Class Initialized
DEBUG - 2011-08-23 14:47:50 --> Model Class Initialized
DEBUG - 2011-08-23 14:47:50 --> Model Class Initialized
DEBUG - 2011-08-23 14:47:50 --> Model Class Initialized
DEBUG - 2011-08-23 14:47:50 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-23 14:47:50 --> Database Driver Class Initialized
DEBUG - 2011-08-23 14:47:50 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-23 14:47:50 --> Helper loaded: url_helper
DEBUG - 2011-08-23 14:47:50 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-23 14:47:50 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-23 14:47:50 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-23 14:47:50 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-23 14:47:50 --> Final output sent to browser
DEBUG - 2011-08-23 14:47:50 --> Total execution time: 0.7488
DEBUG - 2011-08-23 15:32:33 --> Config Class Initialized
DEBUG - 2011-08-23 15:32:33 --> Hooks Class Initialized
DEBUG - 2011-08-23 15:32:33 --> Utf8 Class Initialized
DEBUG - 2011-08-23 15:32:33 --> UTF-8 Support Enabled
DEBUG - 2011-08-23 15:32:33 --> URI Class Initialized
DEBUG - 2011-08-23 15:32:33 --> Router Class Initialized
DEBUG - 2011-08-23 15:32:33 --> Output Class Initialized
DEBUG - 2011-08-23 15:32:33 --> Input Class Initialized
DEBUG - 2011-08-23 15:32:33 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-23 15:32:33 --> Language Class Initialized
DEBUG - 2011-08-23 15:32:33 --> Loader Class Initialized
DEBUG - 2011-08-23 15:32:33 --> Controller Class Initialized
ERROR - 2011-08-23 15:32:33 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-23 15:32:33 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-23 15:32:33 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-23 15:32:33 --> Model Class Initialized
DEBUG - 2011-08-23 15:32:33 --> Model Class Initialized
DEBUG - 2011-08-23 15:32:33 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-23 15:32:33 --> Database Driver Class Initialized
DEBUG - 2011-08-23 15:32:34 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-23 15:32:34 --> Helper loaded: url_helper
DEBUG - 2011-08-23 15:32:34 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-23 15:32:34 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-23 15:32:34 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-23 15:32:34 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-23 15:32:34 --> Final output sent to browser
DEBUG - 2011-08-23 15:32:34 --> Total execution time: 0.0790
DEBUG - 2011-08-23 15:32:35 --> Config Class Initialized
DEBUG - 2011-08-23 15:32:35 --> Hooks Class Initialized
DEBUG - 2011-08-23 15:32:35 --> Utf8 Class Initialized
DEBUG - 2011-08-23 15:32:35 --> UTF-8 Support Enabled
DEBUG - 2011-08-23 15:32:35 --> URI Class Initialized
DEBUG - 2011-08-23 15:32:35 --> Router Class Initialized
DEBUG - 2011-08-23 15:32:35 --> Output Class Initialized
DEBUG - 2011-08-23 15:32:35 --> Input Class Initialized
DEBUG - 2011-08-23 15:32:35 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-23 15:32:35 --> Language Class Initialized
DEBUG - 2011-08-23 15:32:35 --> Loader Class Initialized
DEBUG - 2011-08-23 15:32:35 --> Controller Class Initialized
DEBUG - 2011-08-23 15:32:35 --> Model Class Initialized
DEBUG - 2011-08-23 15:32:35 --> Model Class Initialized
DEBUG - 2011-08-23 15:32:35 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-23 15:32:35 --> Database Driver Class Initialized
DEBUG - 2011-08-23 15:32:36 --> Final output sent to browser
DEBUG - 2011-08-23 15:32:36 --> Total execution time: 0.6936
DEBUG - 2011-08-23 15:32:38 --> Config Class Initialized
DEBUG - 2011-08-23 15:32:38 --> Hooks Class Initialized
DEBUG - 2011-08-23 15:32:38 --> Utf8 Class Initialized
DEBUG - 2011-08-23 15:32:38 --> UTF-8 Support Enabled
DEBUG - 2011-08-23 15:32:38 --> URI Class Initialized
DEBUG - 2011-08-23 15:32:38 --> Router Class Initialized
ERROR - 2011-08-23 15:32:38 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-23 15:33:40 --> Config Class Initialized
DEBUG - 2011-08-23 15:33:40 --> Hooks Class Initialized
DEBUG - 2011-08-23 15:33:40 --> Utf8 Class Initialized
DEBUG - 2011-08-23 15:33:40 --> UTF-8 Support Enabled
DEBUG - 2011-08-23 15:33:40 --> URI Class Initialized
DEBUG - 2011-08-23 15:33:40 --> Router Class Initialized
DEBUG - 2011-08-23 15:33:40 --> Output Class Initialized
DEBUG - 2011-08-23 15:33:40 --> Input Class Initialized
DEBUG - 2011-08-23 15:33:40 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-23 15:33:40 --> Language Class Initialized
DEBUG - 2011-08-23 15:33:40 --> Loader Class Initialized
DEBUG - 2011-08-23 15:33:40 --> Controller Class Initialized
ERROR - 2011-08-23 15:33:40 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-23 15:33:40 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-23 15:33:40 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-23 15:33:40 --> Model Class Initialized
DEBUG - 2011-08-23 15:33:40 --> Model Class Initialized
DEBUG - 2011-08-23 15:33:40 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-23 15:33:40 --> Database Driver Class Initialized
DEBUG - 2011-08-23 15:33:40 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-23 15:33:40 --> Helper loaded: url_helper
DEBUG - 2011-08-23 15:33:40 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-23 15:33:40 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-23 15:33:40 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-23 15:33:40 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-23 15:33:40 --> Final output sent to browser
DEBUG - 2011-08-23 15:33:40 --> Total execution time: 0.0528
DEBUG - 2011-08-23 15:33:42 --> Config Class Initialized
DEBUG - 2011-08-23 15:33:42 --> Hooks Class Initialized
DEBUG - 2011-08-23 15:33:42 --> Utf8 Class Initialized
DEBUG - 2011-08-23 15:33:42 --> UTF-8 Support Enabled
DEBUG - 2011-08-23 15:33:42 --> URI Class Initialized
DEBUG - 2011-08-23 15:33:42 --> Router Class Initialized
DEBUG - 2011-08-23 15:33:42 --> Output Class Initialized
DEBUG - 2011-08-23 15:33:42 --> Input Class Initialized
DEBUG - 2011-08-23 15:33:42 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-23 15:33:42 --> Language Class Initialized
DEBUG - 2011-08-23 15:33:42 --> Loader Class Initialized
DEBUG - 2011-08-23 15:33:42 --> Controller Class Initialized
DEBUG - 2011-08-23 15:33:42 --> Model Class Initialized
DEBUG - 2011-08-23 15:33:42 --> Model Class Initialized
DEBUG - 2011-08-23 15:33:42 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-23 15:33:42 --> Database Driver Class Initialized
DEBUG - 2011-08-23 15:33:42 --> Final output sent to browser
DEBUG - 2011-08-23 15:33:42 --> Total execution time: 0.5734
DEBUG - 2011-08-23 15:33:45 --> Config Class Initialized
DEBUG - 2011-08-23 15:33:45 --> Hooks Class Initialized
DEBUG - 2011-08-23 15:33:45 --> Utf8 Class Initialized
DEBUG - 2011-08-23 15:33:45 --> UTF-8 Support Enabled
DEBUG - 2011-08-23 15:33:45 --> URI Class Initialized
DEBUG - 2011-08-23 15:33:45 --> Router Class Initialized
ERROR - 2011-08-23 15:33:45 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-23 15:33:50 --> Config Class Initialized
DEBUG - 2011-08-23 15:33:50 --> Hooks Class Initialized
DEBUG - 2011-08-23 15:33:50 --> Utf8 Class Initialized
DEBUG - 2011-08-23 15:33:50 --> UTF-8 Support Enabled
DEBUG - 2011-08-23 15:33:50 --> URI Class Initialized
DEBUG - 2011-08-23 15:33:50 --> Router Class Initialized
DEBUG - 2011-08-23 15:33:50 --> Output Class Initialized
DEBUG - 2011-08-23 15:33:50 --> Input Class Initialized
DEBUG - 2011-08-23 15:33:50 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-23 15:33:50 --> Language Class Initialized
DEBUG - 2011-08-23 15:33:50 --> Loader Class Initialized
DEBUG - 2011-08-23 15:33:50 --> Controller Class Initialized
ERROR - 2011-08-23 15:33:50 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-23 15:33:50 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-23 15:33:50 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-23 15:33:50 --> Model Class Initialized
DEBUG - 2011-08-23 15:33:50 --> Model Class Initialized
DEBUG - 2011-08-23 15:33:50 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-23 15:33:50 --> Database Driver Class Initialized
DEBUG - 2011-08-23 15:33:50 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-23 15:33:50 --> Helper loaded: url_helper
DEBUG - 2011-08-23 15:33:50 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-23 15:33:50 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-23 15:33:50 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-23 15:33:50 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-23 15:33:50 --> Final output sent to browser
DEBUG - 2011-08-23 15:33:50 --> Total execution time: 0.0309
DEBUG - 2011-08-23 15:33:51 --> Config Class Initialized
DEBUG - 2011-08-23 15:33:51 --> Hooks Class Initialized
DEBUG - 2011-08-23 15:33:51 --> Utf8 Class Initialized
DEBUG - 2011-08-23 15:33:51 --> UTF-8 Support Enabled
DEBUG - 2011-08-23 15:33:51 --> URI Class Initialized
DEBUG - 2011-08-23 15:33:51 --> Router Class Initialized
ERROR - 2011-08-23 15:33:51 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-08-23 15:33:51 --> Config Class Initialized
DEBUG - 2011-08-23 15:33:51 --> Hooks Class Initialized
DEBUG - 2011-08-23 15:33:51 --> Utf8 Class Initialized
DEBUG - 2011-08-23 15:33:51 --> UTF-8 Support Enabled
DEBUG - 2011-08-23 15:33:51 --> URI Class Initialized
DEBUG - 2011-08-23 15:33:51 --> Router Class Initialized
DEBUG - 2011-08-23 15:33:51 --> Output Class Initialized
DEBUG - 2011-08-23 15:33:51 --> Input Class Initialized
DEBUG - 2011-08-23 15:33:51 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-23 15:33:51 --> Language Class Initialized
DEBUG - 2011-08-23 15:33:51 --> Loader Class Initialized
DEBUG - 2011-08-23 15:33:51 --> Controller Class Initialized
ERROR - 2011-08-23 15:33:51 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-23 15:33:51 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-23 15:33:51 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-23 15:33:51 --> Model Class Initialized
DEBUG - 2011-08-23 15:33:51 --> Model Class Initialized
DEBUG - 2011-08-23 15:33:51 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-23 15:33:51 --> Database Driver Class Initialized
DEBUG - 2011-08-23 15:33:51 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-23 15:33:51 --> Helper loaded: url_helper
DEBUG - 2011-08-23 15:33:51 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-23 15:33:51 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-23 15:33:51 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-23 15:33:51 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-23 15:33:51 --> Final output sent to browser
DEBUG - 2011-08-23 15:33:51 --> Total execution time: 0.0276
DEBUG - 2011-08-23 15:33:52 --> Config Class Initialized
DEBUG - 2011-08-23 15:33:52 --> Hooks Class Initialized
DEBUG - 2011-08-23 15:33:52 --> Utf8 Class Initialized
DEBUG - 2011-08-23 15:33:52 --> UTF-8 Support Enabled
DEBUG - 2011-08-23 15:33:52 --> URI Class Initialized
DEBUG - 2011-08-23 15:33:52 --> Router Class Initialized
DEBUG - 2011-08-23 15:33:52 --> Output Class Initialized
DEBUG - 2011-08-23 15:33:52 --> Input Class Initialized
DEBUG - 2011-08-23 15:33:52 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-23 15:33:52 --> Language Class Initialized
DEBUG - 2011-08-23 15:33:52 --> Loader Class Initialized
DEBUG - 2011-08-23 15:33:52 --> Controller Class Initialized
DEBUG - 2011-08-23 15:33:52 --> Model Class Initialized
DEBUG - 2011-08-23 15:33:52 --> Model Class Initialized
DEBUG - 2011-08-23 15:33:52 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-23 15:33:52 --> Database Driver Class Initialized
DEBUG - 2011-08-23 15:33:52 --> Final output sent to browser
DEBUG - 2011-08-23 15:33:52 --> Total execution time: 0.5858
DEBUG - 2011-08-23 15:33:56 --> Config Class Initialized
DEBUG - 2011-08-23 15:33:56 --> Hooks Class Initialized
DEBUG - 2011-08-23 15:33:56 --> Utf8 Class Initialized
DEBUG - 2011-08-23 15:33:56 --> UTF-8 Support Enabled
DEBUG - 2011-08-23 15:33:56 --> URI Class Initialized
DEBUG - 2011-08-23 15:33:56 --> Router Class Initialized
ERROR - 2011-08-23 15:33:56 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-23 15:34:01 --> Config Class Initialized
DEBUG - 2011-08-23 15:34:01 --> Hooks Class Initialized
DEBUG - 2011-08-23 15:34:01 --> Utf8 Class Initialized
DEBUG - 2011-08-23 15:34:01 --> UTF-8 Support Enabled
DEBUG - 2011-08-23 15:34:01 --> URI Class Initialized
DEBUG - 2011-08-23 15:34:01 --> Router Class Initialized
DEBUG - 2011-08-23 15:34:01 --> Output Class Initialized
DEBUG - 2011-08-23 15:34:01 --> Input Class Initialized
DEBUG - 2011-08-23 15:34:01 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-23 15:34:01 --> Language Class Initialized
DEBUG - 2011-08-23 15:34:01 --> Loader Class Initialized
DEBUG - 2011-08-23 15:34:01 --> Controller Class Initialized
ERROR - 2011-08-23 15:34:01 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-23 15:34:01 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-23 15:34:01 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-23 15:34:01 --> Model Class Initialized
DEBUG - 2011-08-23 15:34:01 --> Model Class Initialized
DEBUG - 2011-08-23 15:34:01 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-23 15:34:01 --> Database Driver Class Initialized
DEBUG - 2011-08-23 15:34:01 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-23 15:34:01 --> Helper loaded: url_helper
DEBUG - 2011-08-23 15:34:01 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-23 15:34:01 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-23 15:34:01 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-23 15:34:01 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-23 15:34:01 --> Final output sent to browser
DEBUG - 2011-08-23 15:34:01 --> Total execution time: 0.0314
DEBUG - 2011-08-23 15:34:02 --> Config Class Initialized
DEBUG - 2011-08-23 15:34:02 --> Hooks Class Initialized
DEBUG - 2011-08-23 15:34:02 --> Utf8 Class Initialized
DEBUG - 2011-08-23 15:34:02 --> UTF-8 Support Enabled
DEBUG - 2011-08-23 15:34:02 --> URI Class Initialized
DEBUG - 2011-08-23 15:34:02 --> Router Class Initialized
DEBUG - 2011-08-23 15:34:02 --> Output Class Initialized
DEBUG - 2011-08-23 15:34:02 --> Input Class Initialized
DEBUG - 2011-08-23 15:34:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-23 15:34:02 --> Language Class Initialized
DEBUG - 2011-08-23 15:34:02 --> Loader Class Initialized
DEBUG - 2011-08-23 15:34:02 --> Controller Class Initialized
ERROR - 2011-08-23 15:34:02 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-23 15:34:02 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-23 15:34:02 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-23 15:34:02 --> Model Class Initialized
DEBUG - 2011-08-23 15:34:02 --> Model Class Initialized
DEBUG - 2011-08-23 15:34:02 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-23 15:34:02 --> Database Driver Class Initialized
DEBUG - 2011-08-23 15:34:02 --> Config Class Initialized
DEBUG - 2011-08-23 15:34:02 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-23 15:34:02 --> Helper loaded: url_helper
DEBUG - 2011-08-23 15:34:02 --> Hooks Class Initialized
DEBUG - 2011-08-23 15:34:02 --> Utf8 Class Initialized
DEBUG - 2011-08-23 15:34:02 --> UTF-8 Support Enabled
DEBUG - 2011-08-23 15:34:02 --> URI Class Initialized
DEBUG - 2011-08-23 15:34:02 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-23 15:34:02 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-23 15:34:02 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-23 15:34:02 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-23 15:34:02 --> Router Class Initialized
DEBUG - 2011-08-23 15:34:02 --> Final output sent to browser
DEBUG - 2011-08-23 15:34:02 --> Total execution time: 0.0948
DEBUG - 2011-08-23 15:34:02 --> Output Class Initialized
DEBUG - 2011-08-23 15:34:02 --> Input Class Initialized
DEBUG - 2011-08-23 15:34:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-23 15:34:02 --> Language Class Initialized
DEBUG - 2011-08-23 15:34:02 --> Loader Class Initialized
DEBUG - 2011-08-23 15:34:02 --> Controller Class Initialized
DEBUG - 2011-08-23 15:34:02 --> Model Class Initialized
DEBUG - 2011-08-23 15:34:02 --> Model Class Initialized
DEBUG - 2011-08-23 15:34:02 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-23 15:34:02 --> Database Driver Class Initialized
DEBUG - 2011-08-23 15:34:07 --> Final output sent to browser
DEBUG - 2011-08-23 15:34:07 --> Total execution time: 5.8027
DEBUG - 2011-08-23 15:34:10 --> Config Class Initialized
DEBUG - 2011-08-23 15:34:10 --> Hooks Class Initialized
DEBUG - 2011-08-23 15:34:10 --> Utf8 Class Initialized
DEBUG - 2011-08-23 15:34:10 --> UTF-8 Support Enabled
DEBUG - 2011-08-23 15:34:10 --> URI Class Initialized
DEBUG - 2011-08-23 15:34:10 --> Router Class Initialized
ERROR - 2011-08-23 15:34:10 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-23 15:34:20 --> Config Class Initialized
DEBUG - 2011-08-23 15:34:20 --> Hooks Class Initialized
DEBUG - 2011-08-23 15:34:20 --> Utf8 Class Initialized
DEBUG - 2011-08-23 15:34:20 --> UTF-8 Support Enabled
DEBUG - 2011-08-23 15:34:20 --> URI Class Initialized
DEBUG - 2011-08-23 15:34:20 --> Router Class Initialized
DEBUG - 2011-08-23 15:34:20 --> Output Class Initialized
DEBUG - 2011-08-23 15:34:20 --> Input Class Initialized
DEBUG - 2011-08-23 15:34:20 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-23 15:34:20 --> Language Class Initialized
DEBUG - 2011-08-23 15:34:20 --> Loader Class Initialized
DEBUG - 2011-08-23 15:34:20 --> Controller Class Initialized
ERROR - 2011-08-23 15:34:20 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-23 15:34:20 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-23 15:34:20 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-23 15:34:20 --> Model Class Initialized
DEBUG - 2011-08-23 15:34:20 --> Model Class Initialized
DEBUG - 2011-08-23 15:34:20 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-23 15:34:20 --> Database Driver Class Initialized
DEBUG - 2011-08-23 15:34:20 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-23 15:34:20 --> Helper loaded: url_helper
DEBUG - 2011-08-23 15:34:20 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-23 15:34:20 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-23 15:34:20 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-23 15:34:20 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-23 15:34:20 --> Final output sent to browser
DEBUG - 2011-08-23 15:34:20 --> Total execution time: 0.0302
DEBUG - 2011-08-23 15:34:21 --> Config Class Initialized
DEBUG - 2011-08-23 15:34:21 --> Hooks Class Initialized
DEBUG - 2011-08-23 15:34:21 --> Utf8 Class Initialized
DEBUG - 2011-08-23 15:34:21 --> UTF-8 Support Enabled
DEBUG - 2011-08-23 15:34:21 --> URI Class Initialized
DEBUG - 2011-08-23 15:34:21 --> Router Class Initialized
DEBUG - 2011-08-23 15:34:21 --> Output Class Initialized
DEBUG - 2011-08-23 15:34:21 --> Input Class Initialized
DEBUG - 2011-08-23 15:34:21 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-23 15:34:21 --> Language Class Initialized
DEBUG - 2011-08-23 15:34:21 --> Loader Class Initialized
DEBUG - 2011-08-23 15:34:21 --> Controller Class Initialized
DEBUG - 2011-08-23 15:34:21 --> Model Class Initialized
DEBUG - 2011-08-23 15:34:21 --> Model Class Initialized
DEBUG - 2011-08-23 15:34:21 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-23 15:34:21 --> Database Driver Class Initialized
DEBUG - 2011-08-23 15:34:21 --> Final output sent to browser
DEBUG - 2011-08-23 15:34:21 --> Total execution time: 0.5498
DEBUG - 2011-08-23 15:34:24 --> Config Class Initialized
DEBUG - 2011-08-23 15:34:24 --> Hooks Class Initialized
DEBUG - 2011-08-23 15:34:24 --> Utf8 Class Initialized
DEBUG - 2011-08-23 15:34:24 --> UTF-8 Support Enabled
DEBUG - 2011-08-23 15:34:24 --> URI Class Initialized
DEBUG - 2011-08-23 15:34:24 --> Router Class Initialized
ERROR - 2011-08-23 15:34:24 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-23 15:37:14 --> Config Class Initialized
DEBUG - 2011-08-23 15:37:14 --> Hooks Class Initialized
DEBUG - 2011-08-23 15:37:14 --> Utf8 Class Initialized
DEBUG - 2011-08-23 15:37:14 --> UTF-8 Support Enabled
DEBUG - 2011-08-23 15:37:14 --> URI Class Initialized
DEBUG - 2011-08-23 15:37:14 --> Router Class Initialized
DEBUG - 2011-08-23 15:37:14 --> Output Class Initialized
DEBUG - 2011-08-23 15:37:14 --> Input Class Initialized
DEBUG - 2011-08-23 15:37:14 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-23 15:37:14 --> Language Class Initialized
DEBUG - 2011-08-23 15:37:14 --> Loader Class Initialized
DEBUG - 2011-08-23 15:37:14 --> Controller Class Initialized
ERROR - 2011-08-23 15:37:14 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-23 15:37:14 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-23 15:37:14 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-23 15:37:14 --> Model Class Initialized
DEBUG - 2011-08-23 15:37:14 --> Model Class Initialized
DEBUG - 2011-08-23 15:37:14 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-23 15:37:14 --> Database Driver Class Initialized
DEBUG - 2011-08-23 15:37:14 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-23 15:37:14 --> Helper loaded: url_helper
DEBUG - 2011-08-23 15:37:14 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-23 15:37:14 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-23 15:37:14 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-23 15:37:14 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-23 15:37:14 --> Final output sent to browser
DEBUG - 2011-08-23 15:37:14 --> Total execution time: 0.0313
DEBUG - 2011-08-23 15:37:16 --> Config Class Initialized
DEBUG - 2011-08-23 15:37:16 --> Hooks Class Initialized
DEBUG - 2011-08-23 15:37:16 --> Utf8 Class Initialized
DEBUG - 2011-08-23 15:37:16 --> UTF-8 Support Enabled
DEBUG - 2011-08-23 15:37:16 --> URI Class Initialized
DEBUG - 2011-08-23 15:37:16 --> Router Class Initialized
DEBUG - 2011-08-23 15:37:16 --> Output Class Initialized
DEBUG - 2011-08-23 15:37:16 --> Input Class Initialized
DEBUG - 2011-08-23 15:37:16 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-23 15:37:16 --> Language Class Initialized
DEBUG - 2011-08-23 15:37:16 --> Loader Class Initialized
DEBUG - 2011-08-23 15:37:16 --> Controller Class Initialized
DEBUG - 2011-08-23 15:37:16 --> Model Class Initialized
DEBUG - 2011-08-23 15:37:16 --> Model Class Initialized
DEBUG - 2011-08-23 15:37:16 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-23 15:37:16 --> Database Driver Class Initialized
DEBUG - 2011-08-23 15:37:16 --> Final output sent to browser
DEBUG - 2011-08-23 15:37:16 --> Total execution time: 0.5769
DEBUG - 2011-08-23 15:37:18 --> Config Class Initialized
DEBUG - 2011-08-23 15:37:18 --> Hooks Class Initialized
DEBUG - 2011-08-23 15:37:18 --> Utf8 Class Initialized
DEBUG - 2011-08-23 15:37:18 --> UTF-8 Support Enabled
DEBUG - 2011-08-23 15:37:18 --> URI Class Initialized
DEBUG - 2011-08-23 15:37:18 --> Router Class Initialized
ERROR - 2011-08-23 15:37:18 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-23 15:37:19 --> Config Class Initialized
DEBUG - 2011-08-23 15:37:19 --> Hooks Class Initialized
DEBUG - 2011-08-23 15:37:19 --> Utf8 Class Initialized
DEBUG - 2011-08-23 15:37:19 --> UTF-8 Support Enabled
DEBUG - 2011-08-23 15:37:19 --> URI Class Initialized
DEBUG - 2011-08-23 15:37:19 --> Router Class Initialized
ERROR - 2011-08-23 15:37:19 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-23 15:43:36 --> Config Class Initialized
DEBUG - 2011-08-23 15:43:36 --> Hooks Class Initialized
DEBUG - 2011-08-23 15:43:36 --> Utf8 Class Initialized
DEBUG - 2011-08-23 15:43:36 --> UTF-8 Support Enabled
DEBUG - 2011-08-23 15:43:36 --> URI Class Initialized
DEBUG - 2011-08-23 15:43:36 --> Router Class Initialized
DEBUG - 2011-08-23 15:43:36 --> Output Class Initialized
DEBUG - 2011-08-23 15:43:36 --> Input Class Initialized
DEBUG - 2011-08-23 15:43:36 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-23 15:43:36 --> Language Class Initialized
DEBUG - 2011-08-23 15:43:36 --> Loader Class Initialized
DEBUG - 2011-08-23 15:43:36 --> Controller Class Initialized
ERROR - 2011-08-23 15:43:36 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-23 15:43:36 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-23 15:43:36 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-23 15:43:36 --> Model Class Initialized
DEBUG - 2011-08-23 15:43:36 --> Model Class Initialized
DEBUG - 2011-08-23 15:43:36 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-23 15:43:36 --> Database Driver Class Initialized
DEBUG - 2011-08-23 15:43:36 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-23 15:43:36 --> Helper loaded: url_helper
DEBUG - 2011-08-23 15:43:36 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-23 15:43:36 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-23 15:43:36 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-23 15:43:36 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-23 15:43:36 --> Final output sent to browser
DEBUG - 2011-08-23 15:43:36 --> Total execution time: 0.0288
DEBUG - 2011-08-23 15:43:37 --> Config Class Initialized
DEBUG - 2011-08-23 15:43:37 --> Hooks Class Initialized
DEBUG - 2011-08-23 15:43:37 --> Utf8 Class Initialized
DEBUG - 2011-08-23 15:43:37 --> UTF-8 Support Enabled
DEBUG - 2011-08-23 15:43:37 --> URI Class Initialized
DEBUG - 2011-08-23 15:43:37 --> Router Class Initialized
DEBUG - 2011-08-23 15:43:37 --> Output Class Initialized
DEBUG - 2011-08-23 15:43:37 --> Input Class Initialized
DEBUG - 2011-08-23 15:43:37 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-23 15:43:37 --> Language Class Initialized
DEBUG - 2011-08-23 15:43:37 --> Loader Class Initialized
DEBUG - 2011-08-23 15:43:37 --> Controller Class Initialized
DEBUG - 2011-08-23 15:43:37 --> Model Class Initialized
DEBUG - 2011-08-23 15:43:37 --> Model Class Initialized
DEBUG - 2011-08-23 15:43:37 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-23 15:43:37 --> Database Driver Class Initialized
DEBUG - 2011-08-23 15:43:37 --> Final output sent to browser
DEBUG - 2011-08-23 15:43:37 --> Total execution time: 0.5641
DEBUG - 2011-08-23 15:43:38 --> Config Class Initialized
DEBUG - 2011-08-23 15:43:38 --> Hooks Class Initialized
DEBUG - 2011-08-23 15:43:38 --> Utf8 Class Initialized
DEBUG - 2011-08-23 15:43:38 --> UTF-8 Support Enabled
DEBUG - 2011-08-23 15:43:38 --> URI Class Initialized
DEBUG - 2011-08-23 15:43:38 --> Router Class Initialized
ERROR - 2011-08-23 15:43:38 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-23 15:53:26 --> Config Class Initialized
DEBUG - 2011-08-23 15:53:26 --> Hooks Class Initialized
DEBUG - 2011-08-23 15:53:26 --> Utf8 Class Initialized
DEBUG - 2011-08-23 15:53:26 --> UTF-8 Support Enabled
DEBUG - 2011-08-23 15:53:26 --> URI Class Initialized
DEBUG - 2011-08-23 15:53:26 --> Router Class Initialized
DEBUG - 2011-08-23 15:53:26 --> No URI present. Default controller set.
DEBUG - 2011-08-23 15:53:26 --> Output Class Initialized
DEBUG - 2011-08-23 15:53:26 --> Input Class Initialized
DEBUG - 2011-08-23 15:53:26 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-23 15:53:26 --> Language Class Initialized
DEBUG - 2011-08-23 15:53:26 --> Loader Class Initialized
DEBUG - 2011-08-23 15:53:26 --> Controller Class Initialized
DEBUG - 2011-08-23 15:53:26 --> File loaded: application/views/splash/main.php
DEBUG - 2011-08-23 15:53:26 --> Helper loaded: url_helper
DEBUG - 2011-08-23 15:53:26 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-23 15:53:26 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-23 15:53:26 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-23 15:53:26 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-23 15:53:26 --> Final output sent to browser
DEBUG - 2011-08-23 15:53:26 --> Total execution time: 0.0840
DEBUG - 2011-08-23 16:16:32 --> Config Class Initialized
DEBUG - 2011-08-23 16:16:32 --> Hooks Class Initialized
DEBUG - 2011-08-23 16:16:32 --> Utf8 Class Initialized
DEBUG - 2011-08-23 16:16:32 --> UTF-8 Support Enabled
DEBUG - 2011-08-23 16:16:32 --> URI Class Initialized
DEBUG - 2011-08-23 16:16:32 --> Router Class Initialized
DEBUG - 2011-08-23 16:16:32 --> Output Class Initialized
DEBUG - 2011-08-23 16:16:32 --> Input Class Initialized
DEBUG - 2011-08-23 16:16:32 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-23 16:16:32 --> Language Class Initialized
DEBUG - 2011-08-23 16:16:32 --> Loader Class Initialized
DEBUG - 2011-08-23 16:16:32 --> Controller Class Initialized
DEBUG - 2011-08-23 16:16:32 --> Model Class Initialized
DEBUG - 2011-08-23 16:16:32 --> Model Class Initialized
DEBUG - 2011-08-23 16:16:32 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-23 16:16:32 --> Database Driver Class Initialized
DEBUG - 2011-08-23 16:16:32 --> Final output sent to browser
DEBUG - 2011-08-23 16:16:32 --> Total execution time: 0.5026
DEBUG - 2011-08-23 16:49:51 --> Config Class Initialized
DEBUG - 2011-08-23 16:49:51 --> Hooks Class Initialized
DEBUG - 2011-08-23 16:49:51 --> Utf8 Class Initialized
DEBUG - 2011-08-23 16:49:51 --> UTF-8 Support Enabled
DEBUG - 2011-08-23 16:49:51 --> URI Class Initialized
DEBUG - 2011-08-23 16:49:51 --> Router Class Initialized
DEBUG - 2011-08-23 16:49:51 --> No URI present. Default controller set.
DEBUG - 2011-08-23 16:49:51 --> Output Class Initialized
DEBUG - 2011-08-23 16:49:51 --> Input Class Initialized
DEBUG - 2011-08-23 16:49:51 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-23 16:49:51 --> Language Class Initialized
DEBUG - 2011-08-23 16:49:51 --> Loader Class Initialized
DEBUG - 2011-08-23 16:49:51 --> Controller Class Initialized
DEBUG - 2011-08-23 16:49:51 --> File loaded: application/views/splash/main.php
DEBUG - 2011-08-23 16:49:51 --> Helper loaded: url_helper
DEBUG - 2011-08-23 16:49:51 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-23 16:49:51 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-23 16:49:51 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-23 16:49:51 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-23 16:49:51 --> Final output sent to browser
DEBUG - 2011-08-23 16:49:51 --> Total execution time: 0.0136
DEBUG - 2011-08-23 17:03:51 --> Config Class Initialized
DEBUG - 2011-08-23 17:03:51 --> Hooks Class Initialized
DEBUG - 2011-08-23 17:03:51 --> Utf8 Class Initialized
DEBUG - 2011-08-23 17:03:51 --> UTF-8 Support Enabled
DEBUG - 2011-08-23 17:03:51 --> URI Class Initialized
DEBUG - 2011-08-23 17:03:51 --> Router Class Initialized
ERROR - 2011-08-23 17:03:51 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-08-23 17:12:33 --> Config Class Initialized
DEBUG - 2011-08-23 17:12:33 --> Hooks Class Initialized
DEBUG - 2011-08-23 17:12:33 --> Utf8 Class Initialized
DEBUG - 2011-08-23 17:12:33 --> UTF-8 Support Enabled
DEBUG - 2011-08-23 17:12:33 --> URI Class Initialized
DEBUG - 2011-08-23 17:12:33 --> Router Class Initialized
DEBUG - 2011-08-23 17:12:33 --> Output Class Initialized
DEBUG - 2011-08-23 17:12:33 --> Input Class Initialized
DEBUG - 2011-08-23 17:12:33 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-23 17:12:33 --> Language Class Initialized
DEBUG - 2011-08-23 17:12:33 --> Loader Class Initialized
DEBUG - 2011-08-23 17:12:33 --> Controller Class Initialized
DEBUG - 2011-08-23 17:12:33 --> Model Class Initialized
DEBUG - 2011-08-23 17:12:33 --> Model Class Initialized
DEBUG - 2011-08-23 17:12:33 --> Model Class Initialized
DEBUG - 2011-08-23 17:12:33 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-23 17:12:33 --> Database Driver Class Initialized
DEBUG - 2011-08-23 17:12:34 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-23 17:12:34 --> Helper loaded: url_helper
DEBUG - 2011-08-23 17:12:34 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-23 17:12:34 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-23 17:12:34 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-23 17:12:34 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-23 17:12:34 --> Final output sent to browser
DEBUG - 2011-08-23 17:12:34 --> Total execution time: 0.6087
DEBUG - 2011-08-23 17:12:36 --> Config Class Initialized
DEBUG - 2011-08-23 17:12:36 --> Hooks Class Initialized
DEBUG - 2011-08-23 17:12:36 --> Utf8 Class Initialized
DEBUG - 2011-08-23 17:12:36 --> UTF-8 Support Enabled
DEBUG - 2011-08-23 17:12:36 --> URI Class Initialized
DEBUG - 2011-08-23 17:12:36 --> Router Class Initialized
ERROR - 2011-08-23 17:12:36 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-23 17:12:58 --> Config Class Initialized
DEBUG - 2011-08-23 17:12:58 --> Hooks Class Initialized
DEBUG - 2011-08-23 17:12:58 --> Utf8 Class Initialized
DEBUG - 2011-08-23 17:12:58 --> UTF-8 Support Enabled
DEBUG - 2011-08-23 17:12:58 --> URI Class Initialized
DEBUG - 2011-08-23 17:12:58 --> Router Class Initialized
DEBUG - 2011-08-23 17:12:58 --> Output Class Initialized
DEBUG - 2011-08-23 17:12:58 --> Input Class Initialized
DEBUG - 2011-08-23 17:12:58 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-23 17:12:58 --> Language Class Initialized
DEBUG - 2011-08-23 17:12:58 --> Loader Class Initialized
DEBUG - 2011-08-23 17:12:58 --> Controller Class Initialized
DEBUG - 2011-08-23 17:12:58 --> Model Class Initialized
DEBUG - 2011-08-23 17:12:58 --> Model Class Initialized
DEBUG - 2011-08-23 17:12:58 --> Model Class Initialized
DEBUG - 2011-08-23 17:12:58 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-23 17:12:58 --> Database Driver Class Initialized
DEBUG - 2011-08-23 17:12:59 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-23 17:12:59 --> Helper loaded: url_helper
DEBUG - 2011-08-23 17:12:59 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-23 17:12:59 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-23 17:12:59 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-23 17:12:59 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-23 17:12:59 --> Final output sent to browser
DEBUG - 2011-08-23 17:12:59 --> Total execution time: 1.4678
DEBUG - 2011-08-23 17:13:01 --> Config Class Initialized
DEBUG - 2011-08-23 17:13:01 --> Hooks Class Initialized
DEBUG - 2011-08-23 17:13:01 --> Utf8 Class Initialized
DEBUG - 2011-08-23 17:13:01 --> UTF-8 Support Enabled
DEBUG - 2011-08-23 17:13:01 --> URI Class Initialized
DEBUG - 2011-08-23 17:13:01 --> Router Class Initialized
DEBUG - 2011-08-23 17:13:01 --> Output Class Initialized
DEBUG - 2011-08-23 17:13:01 --> Input Class Initialized
DEBUG - 2011-08-23 17:13:01 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-23 17:13:01 --> Language Class Initialized
DEBUG - 2011-08-23 17:13:01 --> Loader Class Initialized
DEBUG - 2011-08-23 17:13:01 --> Controller Class Initialized
DEBUG - 2011-08-23 17:13:01 --> Model Class Initialized
DEBUG - 2011-08-23 17:13:01 --> Model Class Initialized
DEBUG - 2011-08-23 17:13:01 --> Model Class Initialized
DEBUG - 2011-08-23 17:13:01 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-23 17:13:01 --> Database Driver Class Initialized
DEBUG - 2011-08-23 17:13:01 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-23 17:13:01 --> Helper loaded: url_helper
DEBUG - 2011-08-23 17:13:01 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-23 17:13:01 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-23 17:13:01 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-23 17:13:01 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-23 17:13:01 --> Final output sent to browser
DEBUG - 2011-08-23 17:13:01 --> Total execution time: 0.1332
DEBUG - 2011-08-23 17:13:08 --> Config Class Initialized
DEBUG - 2011-08-23 17:13:08 --> Hooks Class Initialized
DEBUG - 2011-08-23 17:13:08 --> Utf8 Class Initialized
DEBUG - 2011-08-23 17:13:08 --> UTF-8 Support Enabled
DEBUG - 2011-08-23 17:13:08 --> URI Class Initialized
DEBUG - 2011-08-23 17:13:08 --> Router Class Initialized
DEBUG - 2011-08-23 17:13:08 --> Output Class Initialized
DEBUG - 2011-08-23 17:13:08 --> Input Class Initialized
DEBUG - 2011-08-23 17:13:08 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-23 17:13:08 --> Language Class Initialized
DEBUG - 2011-08-23 17:13:08 --> Loader Class Initialized
DEBUG - 2011-08-23 17:13:08 --> Controller Class Initialized
DEBUG - 2011-08-23 17:13:08 --> Model Class Initialized
DEBUG - 2011-08-23 17:13:08 --> Model Class Initialized
DEBUG - 2011-08-23 17:13:08 --> Model Class Initialized
DEBUG - 2011-08-23 17:13:08 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-23 17:13:08 --> Database Driver Class Initialized
DEBUG - 2011-08-23 17:13:09 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-23 17:13:09 --> Helper loaded: url_helper
DEBUG - 2011-08-23 17:13:09 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-23 17:13:09 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-23 17:13:09 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-23 17:13:09 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-23 17:13:09 --> Final output sent to browser
DEBUG - 2011-08-23 17:13:09 --> Total execution time: 0.6406
DEBUG - 2011-08-23 17:13:11 --> Config Class Initialized
DEBUG - 2011-08-23 17:13:11 --> Hooks Class Initialized
DEBUG - 2011-08-23 17:13:11 --> Utf8 Class Initialized
DEBUG - 2011-08-23 17:13:11 --> UTF-8 Support Enabled
DEBUG - 2011-08-23 17:13:11 --> URI Class Initialized
DEBUG - 2011-08-23 17:13:11 --> Router Class Initialized
DEBUG - 2011-08-23 17:13:11 --> Output Class Initialized
DEBUG - 2011-08-23 17:13:11 --> Input Class Initialized
DEBUG - 2011-08-23 17:13:11 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-23 17:13:11 --> Language Class Initialized
DEBUG - 2011-08-23 17:13:11 --> Loader Class Initialized
DEBUG - 2011-08-23 17:13:11 --> Controller Class Initialized
DEBUG - 2011-08-23 17:13:11 --> Model Class Initialized
DEBUG - 2011-08-23 17:13:11 --> Model Class Initialized
DEBUG - 2011-08-23 17:13:11 --> Model Class Initialized
DEBUG - 2011-08-23 17:13:11 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-23 17:13:11 --> Database Driver Class Initialized
DEBUG - 2011-08-23 17:13:11 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-23 17:13:11 --> Helper loaded: url_helper
DEBUG - 2011-08-23 17:13:11 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-23 17:13:11 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-23 17:13:11 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-23 17:13:11 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-23 17:13:11 --> Final output sent to browser
DEBUG - 2011-08-23 17:13:11 --> Total execution time: 0.0570
DEBUG - 2011-08-23 17:13:22 --> Config Class Initialized
DEBUG - 2011-08-23 17:13:22 --> Hooks Class Initialized
DEBUG - 2011-08-23 17:13:22 --> Utf8 Class Initialized
DEBUG - 2011-08-23 17:13:22 --> UTF-8 Support Enabled
DEBUG - 2011-08-23 17:13:22 --> URI Class Initialized
DEBUG - 2011-08-23 17:13:22 --> Router Class Initialized
DEBUG - 2011-08-23 17:13:22 --> Output Class Initialized
DEBUG - 2011-08-23 17:13:22 --> Input Class Initialized
DEBUG - 2011-08-23 17:13:22 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-23 17:13:22 --> Language Class Initialized
DEBUG - 2011-08-23 17:13:22 --> Loader Class Initialized
DEBUG - 2011-08-23 17:13:22 --> Controller Class Initialized
DEBUG - 2011-08-23 17:13:22 --> Model Class Initialized
DEBUG - 2011-08-23 17:13:22 --> Model Class Initialized
DEBUG - 2011-08-23 17:13:22 --> Model Class Initialized
DEBUG - 2011-08-23 17:13:22 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-23 17:13:22 --> Database Driver Class Initialized
DEBUG - 2011-08-23 17:13:23 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-23 17:13:23 --> Helper loaded: url_helper
DEBUG - 2011-08-23 17:13:23 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-23 17:13:23 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-23 17:13:23 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-23 17:13:23 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-23 17:13:23 --> Final output sent to browser
DEBUG - 2011-08-23 17:13:23 --> Total execution time: 0.4995
DEBUG - 2011-08-23 17:13:25 --> Config Class Initialized
DEBUG - 2011-08-23 17:13:25 --> Hooks Class Initialized
DEBUG - 2011-08-23 17:13:25 --> Utf8 Class Initialized
DEBUG - 2011-08-23 17:13:25 --> UTF-8 Support Enabled
DEBUG - 2011-08-23 17:13:25 --> URI Class Initialized
DEBUG - 2011-08-23 17:13:25 --> Router Class Initialized
DEBUG - 2011-08-23 17:13:25 --> Output Class Initialized
DEBUG - 2011-08-23 17:13:25 --> Input Class Initialized
DEBUG - 2011-08-23 17:13:25 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-23 17:13:25 --> Language Class Initialized
DEBUG - 2011-08-23 17:13:25 --> Loader Class Initialized
DEBUG - 2011-08-23 17:13:25 --> Controller Class Initialized
DEBUG - 2011-08-23 17:13:25 --> Model Class Initialized
DEBUG - 2011-08-23 17:13:25 --> Model Class Initialized
DEBUG - 2011-08-23 17:13:25 --> Model Class Initialized
DEBUG - 2011-08-23 17:13:25 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-23 17:13:25 --> Database Driver Class Initialized
DEBUG - 2011-08-23 17:13:25 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-23 17:13:25 --> Helper loaded: url_helper
DEBUG - 2011-08-23 17:13:25 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-23 17:13:25 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-23 17:13:25 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-23 17:13:25 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-23 17:13:25 --> Final output sent to browser
DEBUG - 2011-08-23 17:13:25 --> Total execution time: 0.0526
DEBUG - 2011-08-23 17:13:32 --> Config Class Initialized
DEBUG - 2011-08-23 17:13:32 --> Hooks Class Initialized
DEBUG - 2011-08-23 17:13:32 --> Utf8 Class Initialized
DEBUG - 2011-08-23 17:13:32 --> UTF-8 Support Enabled
DEBUG - 2011-08-23 17:13:32 --> URI Class Initialized
DEBUG - 2011-08-23 17:13:32 --> Router Class Initialized
DEBUG - 2011-08-23 17:13:32 --> Output Class Initialized
DEBUG - 2011-08-23 17:13:32 --> Input Class Initialized
DEBUG - 2011-08-23 17:13:32 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-23 17:13:32 --> Language Class Initialized
DEBUG - 2011-08-23 17:13:32 --> Loader Class Initialized
DEBUG - 2011-08-23 17:13:32 --> Controller Class Initialized
DEBUG - 2011-08-23 17:13:32 --> Model Class Initialized
DEBUG - 2011-08-23 17:13:32 --> Model Class Initialized
DEBUG - 2011-08-23 17:13:32 --> Model Class Initialized
DEBUG - 2011-08-23 17:13:32 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-23 17:13:32 --> Database Driver Class Initialized
DEBUG - 2011-08-23 17:13:32 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-23 17:13:32 --> Helper loaded: url_helper
DEBUG - 2011-08-23 17:13:32 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-23 17:13:32 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-23 17:13:32 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-23 17:13:32 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-23 17:13:32 --> Final output sent to browser
DEBUG - 2011-08-23 17:13:32 --> Total execution time: 0.3047
DEBUG - 2011-08-23 17:13:33 --> Config Class Initialized
DEBUG - 2011-08-23 17:13:33 --> Hooks Class Initialized
DEBUG - 2011-08-23 17:13:33 --> Utf8 Class Initialized
DEBUG - 2011-08-23 17:13:33 --> UTF-8 Support Enabled
DEBUG - 2011-08-23 17:13:33 --> URI Class Initialized
DEBUG - 2011-08-23 17:13:33 --> Router Class Initialized
DEBUG - 2011-08-23 17:13:33 --> Output Class Initialized
DEBUG - 2011-08-23 17:13:33 --> Input Class Initialized
DEBUG - 2011-08-23 17:13:33 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-23 17:13:33 --> Language Class Initialized
DEBUG - 2011-08-23 17:13:33 --> Loader Class Initialized
DEBUG - 2011-08-23 17:13:33 --> Controller Class Initialized
DEBUG - 2011-08-23 17:13:33 --> Model Class Initialized
DEBUG - 2011-08-23 17:13:33 --> Model Class Initialized
DEBUG - 2011-08-23 17:13:33 --> Model Class Initialized
DEBUG - 2011-08-23 17:13:33 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-23 17:13:33 --> Database Driver Class Initialized
DEBUG - 2011-08-23 17:13:33 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-23 17:13:33 --> Helper loaded: url_helper
DEBUG - 2011-08-23 17:13:33 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-23 17:13:33 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-23 17:13:33 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-23 17:13:33 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-23 17:13:33 --> Final output sent to browser
DEBUG - 2011-08-23 17:13:33 --> Total execution time: 0.0464
DEBUG - 2011-08-23 17:13:39 --> Config Class Initialized
DEBUG - 2011-08-23 17:13:39 --> Hooks Class Initialized
DEBUG - 2011-08-23 17:13:39 --> Utf8 Class Initialized
DEBUG - 2011-08-23 17:13:39 --> UTF-8 Support Enabled
DEBUG - 2011-08-23 17:13:39 --> URI Class Initialized
DEBUG - 2011-08-23 17:13:39 --> Router Class Initialized
DEBUG - 2011-08-23 17:13:39 --> Output Class Initialized
DEBUG - 2011-08-23 17:13:39 --> Input Class Initialized
DEBUG - 2011-08-23 17:13:39 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-23 17:13:39 --> Language Class Initialized
DEBUG - 2011-08-23 17:13:39 --> Loader Class Initialized
DEBUG - 2011-08-23 17:13:39 --> Controller Class Initialized
DEBUG - 2011-08-23 17:13:39 --> Model Class Initialized
DEBUG - 2011-08-23 17:13:39 --> Model Class Initialized
DEBUG - 2011-08-23 17:13:39 --> Model Class Initialized
DEBUG - 2011-08-23 17:13:39 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-23 17:13:39 --> Database Driver Class Initialized
DEBUG - 2011-08-23 17:13:39 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-23 17:13:39 --> Helper loaded: url_helper
DEBUG - 2011-08-23 17:13:39 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-23 17:13:39 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-23 17:13:39 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-23 17:13:39 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-23 17:13:39 --> Final output sent to browser
DEBUG - 2011-08-23 17:13:39 --> Total execution time: 0.3316
DEBUG - 2011-08-23 17:13:41 --> Config Class Initialized
DEBUG - 2011-08-23 17:13:41 --> Hooks Class Initialized
DEBUG - 2011-08-23 17:13:41 --> Utf8 Class Initialized
DEBUG - 2011-08-23 17:13:41 --> UTF-8 Support Enabled
DEBUG - 2011-08-23 17:13:41 --> URI Class Initialized
DEBUG - 2011-08-23 17:13:41 --> Router Class Initialized
DEBUG - 2011-08-23 17:13:41 --> Output Class Initialized
DEBUG - 2011-08-23 17:13:41 --> Input Class Initialized
DEBUG - 2011-08-23 17:13:41 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-23 17:13:41 --> Language Class Initialized
DEBUG - 2011-08-23 17:13:41 --> Loader Class Initialized
DEBUG - 2011-08-23 17:13:41 --> Controller Class Initialized
DEBUG - 2011-08-23 17:13:41 --> Model Class Initialized
DEBUG - 2011-08-23 17:13:41 --> Model Class Initialized
DEBUG - 2011-08-23 17:13:41 --> Model Class Initialized
DEBUG - 2011-08-23 17:13:41 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-23 17:13:41 --> Database Driver Class Initialized
DEBUG - 2011-08-23 17:13:41 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-23 17:13:41 --> Helper loaded: url_helper
DEBUG - 2011-08-23 17:13:41 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-23 17:13:41 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-23 17:13:41 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-23 17:13:41 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-23 17:13:41 --> Final output sent to browser
DEBUG - 2011-08-23 17:13:41 --> Total execution time: 0.1003
DEBUG - 2011-08-23 17:13:41 --> Config Class Initialized
DEBUG - 2011-08-23 17:13:41 --> Hooks Class Initialized
DEBUG - 2011-08-23 17:13:41 --> Utf8 Class Initialized
DEBUG - 2011-08-23 17:13:41 --> UTF-8 Support Enabled
DEBUG - 2011-08-23 17:13:41 --> URI Class Initialized
DEBUG - 2011-08-23 17:13:41 --> Router Class Initialized
DEBUG - 2011-08-23 17:13:41 --> Output Class Initialized
DEBUG - 2011-08-23 17:13:41 --> Input Class Initialized
DEBUG - 2011-08-23 17:13:41 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-23 17:13:41 --> Language Class Initialized
DEBUG - 2011-08-23 17:13:41 --> Loader Class Initialized
DEBUG - 2011-08-23 17:13:41 --> Controller Class Initialized
DEBUG - 2011-08-23 17:13:41 --> Model Class Initialized
DEBUG - 2011-08-23 17:13:41 --> Model Class Initialized
DEBUG - 2011-08-23 17:13:41 --> Model Class Initialized
DEBUG - 2011-08-23 17:13:41 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-23 17:13:41 --> Database Driver Class Initialized
DEBUG - 2011-08-23 17:13:41 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-23 17:13:41 --> Helper loaded: url_helper
DEBUG - 2011-08-23 17:13:41 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-23 17:13:41 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-23 17:13:41 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-23 17:13:41 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-23 17:13:41 --> Final output sent to browser
DEBUG - 2011-08-23 17:13:41 --> Total execution time: 0.1337
DEBUG - 2011-08-23 17:13:49 --> Config Class Initialized
DEBUG - 2011-08-23 17:13:49 --> Hooks Class Initialized
DEBUG - 2011-08-23 17:13:49 --> Utf8 Class Initialized
DEBUG - 2011-08-23 17:13:49 --> UTF-8 Support Enabled
DEBUG - 2011-08-23 17:13:49 --> URI Class Initialized
DEBUG - 2011-08-23 17:13:49 --> Router Class Initialized
DEBUG - 2011-08-23 17:13:49 --> Output Class Initialized
DEBUG - 2011-08-23 17:13:49 --> Input Class Initialized
DEBUG - 2011-08-23 17:13:49 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-23 17:13:49 --> Language Class Initialized
DEBUG - 2011-08-23 17:13:49 --> Loader Class Initialized
DEBUG - 2011-08-23 17:13:49 --> Controller Class Initialized
DEBUG - 2011-08-23 17:13:49 --> Model Class Initialized
DEBUG - 2011-08-23 17:13:49 --> Model Class Initialized
DEBUG - 2011-08-23 17:13:49 --> Model Class Initialized
DEBUG - 2011-08-23 17:13:49 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-23 17:13:49 --> Database Driver Class Initialized
DEBUG - 2011-08-23 17:13:49 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-23 17:13:49 --> Helper loaded: url_helper
DEBUG - 2011-08-23 17:13:49 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-23 17:13:49 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-23 17:13:49 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-23 17:13:49 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-23 17:13:49 --> Final output sent to browser
DEBUG - 2011-08-23 17:13:49 --> Total execution time: 0.4471
DEBUG - 2011-08-23 17:13:50 --> Config Class Initialized
DEBUG - 2011-08-23 17:13:50 --> Hooks Class Initialized
DEBUG - 2011-08-23 17:13:50 --> Utf8 Class Initialized
DEBUG - 2011-08-23 17:13:50 --> UTF-8 Support Enabled
DEBUG - 2011-08-23 17:13:50 --> URI Class Initialized
DEBUG - 2011-08-23 17:13:50 --> Router Class Initialized
DEBUG - 2011-08-23 17:13:50 --> Output Class Initialized
DEBUG - 2011-08-23 17:13:50 --> Input Class Initialized
DEBUG - 2011-08-23 17:13:50 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-23 17:13:50 --> Language Class Initialized
DEBUG - 2011-08-23 17:13:50 --> Loader Class Initialized
DEBUG - 2011-08-23 17:13:50 --> Controller Class Initialized
DEBUG - 2011-08-23 17:13:50 --> Model Class Initialized
DEBUG - 2011-08-23 17:13:50 --> Model Class Initialized
DEBUG - 2011-08-23 17:13:50 --> Model Class Initialized
DEBUG - 2011-08-23 17:13:50 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-23 17:13:50 --> Database Driver Class Initialized
DEBUG - 2011-08-23 17:13:50 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-23 17:13:50 --> Helper loaded: url_helper
DEBUG - 2011-08-23 17:13:50 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-23 17:13:50 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-23 17:13:50 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-23 17:13:50 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-23 17:13:50 --> Final output sent to browser
DEBUG - 2011-08-23 17:13:50 --> Total execution time: 0.0438
DEBUG - 2011-08-23 17:13:56 --> Config Class Initialized
DEBUG - 2011-08-23 17:13:56 --> Hooks Class Initialized
DEBUG - 2011-08-23 17:13:56 --> Utf8 Class Initialized
DEBUG - 2011-08-23 17:13:56 --> UTF-8 Support Enabled
DEBUG - 2011-08-23 17:13:56 --> URI Class Initialized
DEBUG - 2011-08-23 17:13:56 --> Router Class Initialized
DEBUG - 2011-08-23 17:13:56 --> Output Class Initialized
DEBUG - 2011-08-23 17:13:56 --> Input Class Initialized
DEBUG - 2011-08-23 17:13:56 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-23 17:13:56 --> Language Class Initialized
DEBUG - 2011-08-23 17:13:56 --> Loader Class Initialized
DEBUG - 2011-08-23 17:13:56 --> Controller Class Initialized
DEBUG - 2011-08-23 17:13:56 --> Model Class Initialized
DEBUG - 2011-08-23 17:13:56 --> Model Class Initialized
DEBUG - 2011-08-23 17:13:56 --> Model Class Initialized
DEBUG - 2011-08-23 17:13:56 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-23 17:13:56 --> Database Driver Class Initialized
DEBUG - 2011-08-23 17:13:56 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-23 17:13:56 --> Helper loaded: url_helper
DEBUG - 2011-08-23 17:13:56 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-23 17:13:56 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-23 17:13:56 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-23 17:13:56 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-23 17:13:56 --> Final output sent to browser
DEBUG - 2011-08-23 17:13:56 --> Total execution time: 0.3266
DEBUG - 2011-08-23 17:13:57 --> Config Class Initialized
DEBUG - 2011-08-23 17:13:57 --> Hooks Class Initialized
DEBUG - 2011-08-23 17:13:57 --> Utf8 Class Initialized
DEBUG - 2011-08-23 17:13:57 --> UTF-8 Support Enabled
DEBUG - 2011-08-23 17:13:57 --> URI Class Initialized
DEBUG - 2011-08-23 17:13:57 --> Router Class Initialized
DEBUG - 2011-08-23 17:13:57 --> Output Class Initialized
DEBUG - 2011-08-23 17:13:57 --> Input Class Initialized
DEBUG - 2011-08-23 17:13:57 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-23 17:13:57 --> Language Class Initialized
DEBUG - 2011-08-23 17:13:57 --> Loader Class Initialized
DEBUG - 2011-08-23 17:13:57 --> Controller Class Initialized
DEBUG - 2011-08-23 17:13:57 --> Model Class Initialized
DEBUG - 2011-08-23 17:13:57 --> Model Class Initialized
DEBUG - 2011-08-23 17:13:57 --> Model Class Initialized
DEBUG - 2011-08-23 17:13:57 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-23 17:13:57 --> Database Driver Class Initialized
DEBUG - 2011-08-23 17:13:57 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-23 17:13:57 --> Helper loaded: url_helper
DEBUG - 2011-08-23 17:13:57 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-23 17:13:57 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-23 17:13:57 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-23 17:13:57 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-23 17:13:57 --> Final output sent to browser
DEBUG - 2011-08-23 17:13:57 --> Total execution time: 0.0482
DEBUG - 2011-08-23 17:14:50 --> Config Class Initialized
DEBUG - 2011-08-23 17:14:50 --> Hooks Class Initialized
DEBUG - 2011-08-23 17:14:50 --> Utf8 Class Initialized
DEBUG - 2011-08-23 17:14:50 --> UTF-8 Support Enabled
DEBUG - 2011-08-23 17:14:50 --> URI Class Initialized
DEBUG - 2011-08-23 17:14:50 --> Router Class Initialized
DEBUG - 2011-08-23 17:14:50 --> Output Class Initialized
DEBUG - 2011-08-23 17:14:50 --> Input Class Initialized
DEBUG - 2011-08-23 17:14:50 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-23 17:14:50 --> Language Class Initialized
DEBUG - 2011-08-23 17:14:50 --> Loader Class Initialized
DEBUG - 2011-08-23 17:14:50 --> Controller Class Initialized
DEBUG - 2011-08-23 17:14:50 --> Model Class Initialized
DEBUG - 2011-08-23 17:14:50 --> Model Class Initialized
DEBUG - 2011-08-23 17:14:50 --> Model Class Initialized
DEBUG - 2011-08-23 17:14:50 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-23 17:14:50 --> Database Driver Class Initialized
DEBUG - 2011-08-23 17:14:50 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-23 17:14:50 --> Helper loaded: url_helper
DEBUG - 2011-08-23 17:14:50 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-23 17:14:50 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-23 17:14:50 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-23 17:14:50 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-23 17:14:50 --> Final output sent to browser
DEBUG - 2011-08-23 17:14:50 --> Total execution time: 0.0950
DEBUG - 2011-08-23 17:14:57 --> Config Class Initialized
DEBUG - 2011-08-23 17:14:57 --> Hooks Class Initialized
DEBUG - 2011-08-23 17:14:57 --> Utf8 Class Initialized
DEBUG - 2011-08-23 17:14:57 --> UTF-8 Support Enabled
DEBUG - 2011-08-23 17:14:57 --> URI Class Initialized
DEBUG - 2011-08-23 17:14:57 --> Router Class Initialized
DEBUG - 2011-08-23 17:14:57 --> Output Class Initialized
DEBUG - 2011-08-23 17:14:57 --> Input Class Initialized
DEBUG - 2011-08-23 17:14:57 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-23 17:14:57 --> Language Class Initialized
DEBUG - 2011-08-23 17:14:57 --> Loader Class Initialized
DEBUG - 2011-08-23 17:14:57 --> Controller Class Initialized
ERROR - 2011-08-23 17:14:57 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-23 17:14:57 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-23 17:14:57 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-23 17:14:57 --> Model Class Initialized
DEBUG - 2011-08-23 17:14:57 --> Model Class Initialized
DEBUG - 2011-08-23 17:14:57 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-23 17:14:57 --> Database Driver Class Initialized
DEBUG - 2011-08-23 17:14:57 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-23 17:14:57 --> Helper loaded: url_helper
DEBUG - 2011-08-23 17:14:57 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-23 17:14:57 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-23 17:14:57 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-23 17:14:57 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-23 17:14:57 --> Final output sent to browser
DEBUG - 2011-08-23 17:14:57 --> Total execution time: 0.0263
DEBUG - 2011-08-23 17:14:58 --> Config Class Initialized
DEBUG - 2011-08-23 17:14:58 --> Hooks Class Initialized
DEBUG - 2011-08-23 17:14:58 --> Utf8 Class Initialized
DEBUG - 2011-08-23 17:14:58 --> UTF-8 Support Enabled
DEBUG - 2011-08-23 17:14:58 --> URI Class Initialized
DEBUG - 2011-08-23 17:14:58 --> Router Class Initialized
DEBUG - 2011-08-23 17:14:58 --> Output Class Initialized
DEBUG - 2011-08-23 17:14:58 --> Input Class Initialized
DEBUG - 2011-08-23 17:14:58 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-23 17:14:58 --> Language Class Initialized
DEBUG - 2011-08-23 17:14:58 --> Loader Class Initialized
DEBUG - 2011-08-23 17:14:58 --> Controller Class Initialized
DEBUG - 2011-08-23 17:14:58 --> Model Class Initialized
DEBUG - 2011-08-23 17:14:58 --> Model Class Initialized
DEBUG - 2011-08-23 17:14:58 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-23 17:14:58 --> Database Driver Class Initialized
DEBUG - 2011-08-23 17:14:59 --> Final output sent to browser
DEBUG - 2011-08-23 17:14:59 --> Total execution time: 0.5570
DEBUG - 2011-08-23 17:28:02 --> Config Class Initialized
DEBUG - 2011-08-23 17:28:02 --> Hooks Class Initialized
DEBUG - 2011-08-23 17:28:02 --> Utf8 Class Initialized
DEBUG - 2011-08-23 17:28:02 --> UTF-8 Support Enabled
DEBUG - 2011-08-23 17:28:02 --> URI Class Initialized
DEBUG - 2011-08-23 17:28:02 --> Router Class Initialized
DEBUG - 2011-08-23 17:28:02 --> No URI present. Default controller set.
DEBUG - 2011-08-23 17:28:02 --> Output Class Initialized
DEBUG - 2011-08-23 17:28:02 --> Input Class Initialized
DEBUG - 2011-08-23 17:28:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-23 17:28:02 --> Language Class Initialized
DEBUG - 2011-08-23 17:28:02 --> Loader Class Initialized
DEBUG - 2011-08-23 17:28:02 --> Controller Class Initialized
DEBUG - 2011-08-23 17:28:02 --> File loaded: application/views/splash/main.php
DEBUG - 2011-08-23 17:28:02 --> Helper loaded: url_helper
DEBUG - 2011-08-23 17:28:02 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-23 17:28:02 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-23 17:28:02 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-23 17:28:02 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-23 17:28:02 --> Final output sent to browser
DEBUG - 2011-08-23 17:28:02 --> Total execution time: 0.0146
DEBUG - 2011-08-23 17:28:44 --> Config Class Initialized
DEBUG - 2011-08-23 17:28:44 --> Hooks Class Initialized
DEBUG - 2011-08-23 17:28:44 --> Utf8 Class Initialized
DEBUG - 2011-08-23 17:28:44 --> UTF-8 Support Enabled
DEBUG - 2011-08-23 17:28:44 --> URI Class Initialized
DEBUG - 2011-08-23 17:28:44 --> Router Class Initialized
DEBUG - 2011-08-23 17:28:44 --> Output Class Initialized
DEBUG - 2011-08-23 17:28:44 --> Input Class Initialized
DEBUG - 2011-08-23 17:28:44 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-23 17:28:44 --> Language Class Initialized
DEBUG - 2011-08-23 17:28:44 --> Loader Class Initialized
DEBUG - 2011-08-23 17:28:44 --> Controller Class Initialized
DEBUG - 2011-08-23 17:28:44 --> Model Class Initialized
DEBUG - 2011-08-23 17:28:44 --> Model Class Initialized
DEBUG - 2011-08-23 17:28:44 --> Model Class Initialized
DEBUG - 2011-08-23 17:28:44 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-23 17:28:44 --> Database Driver Class Initialized
DEBUG - 2011-08-23 17:28:44 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-23 17:28:44 --> Helper loaded: url_helper
DEBUG - 2011-08-23 17:28:44 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-23 17:28:44 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-23 17:28:44 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-23 17:28:44 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-23 17:28:44 --> Final output sent to browser
DEBUG - 2011-08-23 17:28:44 --> Total execution time: 0.0636
DEBUG - 2011-08-23 17:28:47 --> Config Class Initialized
DEBUG - 2011-08-23 17:28:47 --> Hooks Class Initialized
DEBUG - 2011-08-23 17:28:47 --> Utf8 Class Initialized
DEBUG - 2011-08-23 17:28:47 --> UTF-8 Support Enabled
DEBUG - 2011-08-23 17:28:47 --> URI Class Initialized
DEBUG - 2011-08-23 17:28:47 --> Router Class Initialized
ERROR - 2011-08-23 17:28:47 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-23 17:28:47 --> Config Class Initialized
DEBUG - 2011-08-23 17:28:47 --> Hooks Class Initialized
DEBUG - 2011-08-23 17:28:47 --> Utf8 Class Initialized
DEBUG - 2011-08-23 17:28:47 --> UTF-8 Support Enabled
DEBUG - 2011-08-23 17:28:47 --> URI Class Initialized
DEBUG - 2011-08-23 17:28:47 --> Router Class Initialized
ERROR - 2011-08-23 17:28:47 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-23 17:29:18 --> Config Class Initialized
DEBUG - 2011-08-23 17:29:18 --> Hooks Class Initialized
DEBUG - 2011-08-23 17:29:18 --> Utf8 Class Initialized
DEBUG - 2011-08-23 17:29:18 --> UTF-8 Support Enabled
DEBUG - 2011-08-23 17:29:18 --> URI Class Initialized
DEBUG - 2011-08-23 17:29:18 --> Router Class Initialized
DEBUG - 2011-08-23 17:29:18 --> Output Class Initialized
DEBUG - 2011-08-23 17:29:18 --> Input Class Initialized
DEBUG - 2011-08-23 17:29:18 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-23 17:29:18 --> Language Class Initialized
DEBUG - 2011-08-23 17:29:18 --> Loader Class Initialized
DEBUG - 2011-08-23 17:29:18 --> Controller Class Initialized
DEBUG - 2011-08-23 17:29:18 --> Model Class Initialized
DEBUG - 2011-08-23 17:29:18 --> Model Class Initialized
DEBUG - 2011-08-23 17:29:18 --> Model Class Initialized
DEBUG - 2011-08-23 17:29:18 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-23 17:29:18 --> Database Driver Class Initialized
DEBUG - 2011-08-23 17:29:18 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-23 17:29:18 --> Helper loaded: url_helper
DEBUG - 2011-08-23 17:29:18 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-23 17:29:18 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-23 17:29:18 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-23 17:29:18 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-23 17:29:18 --> Final output sent to browser
DEBUG - 2011-08-23 17:29:18 --> Total execution time: 0.0462
DEBUG - 2011-08-23 17:29:21 --> Config Class Initialized
DEBUG - 2011-08-23 17:29:21 --> Hooks Class Initialized
DEBUG - 2011-08-23 17:29:21 --> Utf8 Class Initialized
DEBUG - 2011-08-23 17:29:21 --> UTF-8 Support Enabled
DEBUG - 2011-08-23 17:29:21 --> URI Class Initialized
DEBUG - 2011-08-23 17:29:21 --> Router Class Initialized
DEBUG - 2011-08-23 17:29:21 --> Output Class Initialized
DEBUG - 2011-08-23 17:29:21 --> Input Class Initialized
DEBUG - 2011-08-23 17:29:21 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-23 17:29:21 --> Language Class Initialized
DEBUG - 2011-08-23 17:29:21 --> Loader Class Initialized
DEBUG - 2011-08-23 17:29:21 --> Controller Class Initialized
DEBUG - 2011-08-23 17:29:21 --> Model Class Initialized
DEBUG - 2011-08-23 17:29:21 --> Model Class Initialized
DEBUG - 2011-08-23 17:29:21 --> Model Class Initialized
DEBUG - 2011-08-23 17:29:21 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-23 17:29:21 --> Database Driver Class Initialized
DEBUG - 2011-08-23 17:29:21 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-23 17:29:21 --> Helper loaded: url_helper
DEBUG - 2011-08-23 17:29:21 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-23 17:29:21 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-23 17:29:21 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-23 17:29:21 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-23 17:29:21 --> Final output sent to browser
DEBUG - 2011-08-23 17:29:21 --> Total execution time: 0.0487
DEBUG - 2011-08-23 17:29:26 --> Config Class Initialized
DEBUG - 2011-08-23 17:29:26 --> Hooks Class Initialized
DEBUG - 2011-08-23 17:29:26 --> Utf8 Class Initialized
DEBUG - 2011-08-23 17:29:26 --> UTF-8 Support Enabled
DEBUG - 2011-08-23 17:29:26 --> URI Class Initialized
DEBUG - 2011-08-23 17:29:26 --> Router Class Initialized
DEBUG - 2011-08-23 17:29:26 --> Output Class Initialized
DEBUG - 2011-08-23 17:29:26 --> Input Class Initialized
DEBUG - 2011-08-23 17:29:26 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-23 17:29:26 --> Language Class Initialized
DEBUG - 2011-08-23 17:29:26 --> Loader Class Initialized
DEBUG - 2011-08-23 17:29:26 --> Controller Class Initialized
DEBUG - 2011-08-23 17:29:26 --> Model Class Initialized
DEBUG - 2011-08-23 17:29:26 --> Model Class Initialized
DEBUG - 2011-08-23 17:29:26 --> Model Class Initialized
DEBUG - 2011-08-23 17:29:26 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-23 17:29:26 --> Database Driver Class Initialized
DEBUG - 2011-08-23 17:29:27 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-23 17:29:27 --> Helper loaded: url_helper
DEBUG - 2011-08-23 17:29:27 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-23 17:29:27 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-23 17:29:27 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-23 17:29:27 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-23 17:29:27 --> Final output sent to browser
DEBUG - 2011-08-23 17:29:27 --> Total execution time: 0.2381
DEBUG - 2011-08-23 17:29:28 --> Config Class Initialized
DEBUG - 2011-08-23 17:29:28 --> Hooks Class Initialized
DEBUG - 2011-08-23 17:29:28 --> Utf8 Class Initialized
DEBUG - 2011-08-23 17:29:28 --> UTF-8 Support Enabled
DEBUG - 2011-08-23 17:29:28 --> URI Class Initialized
DEBUG - 2011-08-23 17:29:28 --> Router Class Initialized
DEBUG - 2011-08-23 17:29:28 --> Output Class Initialized
DEBUG - 2011-08-23 17:29:28 --> Input Class Initialized
DEBUG - 2011-08-23 17:29:28 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-23 17:29:28 --> Language Class Initialized
DEBUG - 2011-08-23 17:29:28 --> Loader Class Initialized
DEBUG - 2011-08-23 17:29:28 --> Controller Class Initialized
DEBUG - 2011-08-23 17:29:28 --> Model Class Initialized
DEBUG - 2011-08-23 17:29:28 --> Model Class Initialized
DEBUG - 2011-08-23 17:29:28 --> Model Class Initialized
DEBUG - 2011-08-23 17:29:28 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-23 17:29:28 --> Database Driver Class Initialized
DEBUG - 2011-08-23 17:29:28 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-23 17:29:28 --> Helper loaded: url_helper
DEBUG - 2011-08-23 17:29:28 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-23 17:29:28 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-23 17:29:28 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-23 17:29:28 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-23 17:29:28 --> Final output sent to browser
DEBUG - 2011-08-23 17:29:28 --> Total execution time: 0.0669
DEBUG - 2011-08-23 17:29:42 --> Config Class Initialized
DEBUG - 2011-08-23 17:29:42 --> Hooks Class Initialized
DEBUG - 2011-08-23 17:29:42 --> Utf8 Class Initialized
DEBUG - 2011-08-23 17:29:42 --> UTF-8 Support Enabled
DEBUG - 2011-08-23 17:29:42 --> URI Class Initialized
DEBUG - 2011-08-23 17:29:42 --> Router Class Initialized
DEBUG - 2011-08-23 17:29:42 --> Output Class Initialized
DEBUG - 2011-08-23 17:29:42 --> Input Class Initialized
DEBUG - 2011-08-23 17:29:42 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-23 17:29:42 --> Language Class Initialized
DEBUG - 2011-08-23 17:29:42 --> Loader Class Initialized
DEBUG - 2011-08-23 17:29:42 --> Controller Class Initialized
DEBUG - 2011-08-23 17:29:42 --> Model Class Initialized
DEBUG - 2011-08-23 17:29:42 --> Model Class Initialized
DEBUG - 2011-08-23 17:29:42 --> Model Class Initialized
DEBUG - 2011-08-23 17:29:42 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-23 17:29:42 --> Database Driver Class Initialized
DEBUG - 2011-08-23 17:29:42 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-23 17:29:42 --> Helper loaded: url_helper
DEBUG - 2011-08-23 17:29:42 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-23 17:29:42 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-23 17:29:42 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-23 17:29:42 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-23 17:29:42 --> Final output sent to browser
DEBUG - 2011-08-23 17:29:42 --> Total execution time: 0.2241
DEBUG - 2011-08-23 17:29:43 --> Config Class Initialized
DEBUG - 2011-08-23 17:29:43 --> Hooks Class Initialized
DEBUG - 2011-08-23 17:29:43 --> Utf8 Class Initialized
DEBUG - 2011-08-23 17:29:43 --> UTF-8 Support Enabled
DEBUG - 2011-08-23 17:29:43 --> URI Class Initialized
DEBUG - 2011-08-23 17:29:43 --> Router Class Initialized
DEBUG - 2011-08-23 17:29:43 --> Output Class Initialized
DEBUG - 2011-08-23 17:29:43 --> Input Class Initialized
DEBUG - 2011-08-23 17:29:43 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-23 17:29:43 --> Language Class Initialized
DEBUG - 2011-08-23 17:29:43 --> Loader Class Initialized
DEBUG - 2011-08-23 17:29:43 --> Controller Class Initialized
DEBUG - 2011-08-23 17:29:43 --> Model Class Initialized
DEBUG - 2011-08-23 17:29:43 --> Model Class Initialized
DEBUG - 2011-08-23 17:29:43 --> Model Class Initialized
DEBUG - 2011-08-23 17:29:43 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-23 17:29:43 --> Database Driver Class Initialized
DEBUG - 2011-08-23 17:29:43 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-23 17:29:43 --> Helper loaded: url_helper
DEBUG - 2011-08-23 17:29:43 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-23 17:29:43 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-23 17:29:43 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-23 17:29:43 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-23 17:29:43 --> Final output sent to browser
DEBUG - 2011-08-23 17:29:43 --> Total execution time: 0.0470
DEBUG - 2011-08-23 17:29:44 --> Config Class Initialized
DEBUG - 2011-08-23 17:29:44 --> Hooks Class Initialized
DEBUG - 2011-08-23 17:29:44 --> Utf8 Class Initialized
DEBUG - 2011-08-23 17:29:44 --> UTF-8 Support Enabled
DEBUG - 2011-08-23 17:29:44 --> URI Class Initialized
DEBUG - 2011-08-23 17:29:44 --> Router Class Initialized
DEBUG - 2011-08-23 17:29:44 --> Output Class Initialized
DEBUG - 2011-08-23 17:29:44 --> Input Class Initialized
DEBUG - 2011-08-23 17:29:44 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-23 17:29:44 --> Language Class Initialized
DEBUG - 2011-08-23 17:29:44 --> Loader Class Initialized
DEBUG - 2011-08-23 17:29:44 --> Controller Class Initialized
DEBUG - 2011-08-23 17:29:44 --> Model Class Initialized
DEBUG - 2011-08-23 17:29:44 --> Model Class Initialized
DEBUG - 2011-08-23 17:29:44 --> Model Class Initialized
DEBUG - 2011-08-23 17:29:44 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-23 17:29:44 --> Database Driver Class Initialized
DEBUG - 2011-08-23 17:29:44 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-23 17:29:44 --> Helper loaded: url_helper
DEBUG - 2011-08-23 17:29:44 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-23 17:29:44 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-23 17:29:44 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-23 17:29:44 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-23 17:29:44 --> Final output sent to browser
DEBUG - 2011-08-23 17:29:44 --> Total execution time: 0.0506
DEBUG - 2011-08-23 17:29:55 --> Config Class Initialized
DEBUG - 2011-08-23 17:29:55 --> Hooks Class Initialized
DEBUG - 2011-08-23 17:29:55 --> Utf8 Class Initialized
DEBUG - 2011-08-23 17:29:55 --> UTF-8 Support Enabled
DEBUG - 2011-08-23 17:29:55 --> URI Class Initialized
DEBUG - 2011-08-23 17:29:55 --> Router Class Initialized
DEBUG - 2011-08-23 17:29:55 --> Output Class Initialized
DEBUG - 2011-08-23 17:29:55 --> Input Class Initialized
DEBUG - 2011-08-23 17:29:55 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-23 17:29:55 --> Language Class Initialized
DEBUG - 2011-08-23 17:29:55 --> Loader Class Initialized
DEBUG - 2011-08-23 17:29:55 --> Controller Class Initialized
DEBUG - 2011-08-23 17:29:55 --> Model Class Initialized
DEBUG - 2011-08-23 17:29:55 --> Model Class Initialized
DEBUG - 2011-08-23 17:29:55 --> Model Class Initialized
DEBUG - 2011-08-23 17:29:55 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-23 17:29:55 --> Database Driver Class Initialized
DEBUG - 2011-08-23 17:29:55 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-23 17:29:55 --> Helper loaded: url_helper
DEBUG - 2011-08-23 17:29:55 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-23 17:29:55 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-23 17:29:55 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-23 17:29:55 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-23 17:29:55 --> Final output sent to browser
DEBUG - 2011-08-23 17:29:55 --> Total execution time: 0.2323
DEBUG - 2011-08-23 17:29:56 --> Config Class Initialized
DEBUG - 2011-08-23 17:29:56 --> Hooks Class Initialized
DEBUG - 2011-08-23 17:29:56 --> Utf8 Class Initialized
DEBUG - 2011-08-23 17:29:56 --> UTF-8 Support Enabled
DEBUG - 2011-08-23 17:29:56 --> URI Class Initialized
DEBUG - 2011-08-23 17:29:56 --> Router Class Initialized
DEBUG - 2011-08-23 17:29:56 --> Output Class Initialized
DEBUG - 2011-08-23 17:29:56 --> Input Class Initialized
DEBUG - 2011-08-23 17:29:56 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-23 17:29:56 --> Language Class Initialized
DEBUG - 2011-08-23 17:29:56 --> Loader Class Initialized
DEBUG - 2011-08-23 17:29:56 --> Controller Class Initialized
DEBUG - 2011-08-23 17:29:56 --> Model Class Initialized
DEBUG - 2011-08-23 17:29:56 --> Model Class Initialized
DEBUG - 2011-08-23 17:29:56 --> Model Class Initialized
DEBUG - 2011-08-23 17:29:56 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-23 17:29:56 --> Database Driver Class Initialized
DEBUG - 2011-08-23 17:29:56 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-23 17:29:56 --> Helper loaded: url_helper
DEBUG - 2011-08-23 17:29:56 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-23 17:29:56 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-23 17:29:56 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-23 17:29:56 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-23 17:29:56 --> Final output sent to browser
DEBUG - 2011-08-23 17:29:56 --> Total execution time: 0.0704
DEBUG - 2011-08-23 17:30:11 --> Config Class Initialized
DEBUG - 2011-08-23 17:30:11 --> Hooks Class Initialized
DEBUG - 2011-08-23 17:30:11 --> Utf8 Class Initialized
DEBUG - 2011-08-23 17:30:11 --> UTF-8 Support Enabled
DEBUG - 2011-08-23 17:30:11 --> URI Class Initialized
DEBUG - 2011-08-23 17:30:11 --> Router Class Initialized
DEBUG - 2011-08-23 17:30:11 --> Output Class Initialized
DEBUG - 2011-08-23 17:30:11 --> Input Class Initialized
DEBUG - 2011-08-23 17:30:11 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-23 17:30:11 --> Language Class Initialized
DEBUG - 2011-08-23 17:30:11 --> Loader Class Initialized
DEBUG - 2011-08-23 17:30:11 --> Controller Class Initialized
DEBUG - 2011-08-23 17:30:11 --> Model Class Initialized
DEBUG - 2011-08-23 17:30:11 --> Model Class Initialized
DEBUG - 2011-08-23 17:30:11 --> Model Class Initialized
DEBUG - 2011-08-23 17:30:11 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-23 17:30:11 --> Database Driver Class Initialized
DEBUG - 2011-08-23 17:30:12 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-23 17:30:12 --> Helper loaded: url_helper
DEBUG - 2011-08-23 17:30:12 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-23 17:30:12 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-23 17:30:12 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-23 17:30:12 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-23 17:30:12 --> Final output sent to browser
DEBUG - 2011-08-23 17:30:12 --> Total execution time: 0.8421
DEBUG - 2011-08-23 17:30:15 --> Config Class Initialized
DEBUG - 2011-08-23 17:30:15 --> Hooks Class Initialized
DEBUG - 2011-08-23 17:30:15 --> Utf8 Class Initialized
DEBUG - 2011-08-23 17:30:15 --> UTF-8 Support Enabled
DEBUG - 2011-08-23 17:30:15 --> URI Class Initialized
DEBUG - 2011-08-23 17:30:15 --> Router Class Initialized
DEBUG - 2011-08-23 17:30:15 --> Output Class Initialized
DEBUG - 2011-08-23 17:30:15 --> Input Class Initialized
DEBUG - 2011-08-23 17:30:15 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-23 17:30:15 --> Language Class Initialized
DEBUG - 2011-08-23 17:30:15 --> Loader Class Initialized
DEBUG - 2011-08-23 17:30:15 --> Controller Class Initialized
DEBUG - 2011-08-23 17:30:15 --> Model Class Initialized
DEBUG - 2011-08-23 17:30:15 --> Model Class Initialized
DEBUG - 2011-08-23 17:30:15 --> Model Class Initialized
DEBUG - 2011-08-23 17:30:15 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-23 17:30:15 --> Database Driver Class Initialized
DEBUG - 2011-08-23 17:30:15 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-23 17:30:15 --> Helper loaded: url_helper
DEBUG - 2011-08-23 17:30:15 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-23 17:30:15 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-23 17:30:15 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-23 17:30:15 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-23 17:30:15 --> Final output sent to browser
DEBUG - 2011-08-23 17:30:15 --> Total execution time: 0.0653
DEBUG - 2011-08-23 17:30:20 --> Config Class Initialized
DEBUG - 2011-08-23 17:30:20 --> Hooks Class Initialized
DEBUG - 2011-08-23 17:30:20 --> Utf8 Class Initialized
DEBUG - 2011-08-23 17:30:20 --> UTF-8 Support Enabled
DEBUG - 2011-08-23 17:30:20 --> URI Class Initialized
DEBUG - 2011-08-23 17:30:20 --> Router Class Initialized
DEBUG - 2011-08-23 17:30:20 --> Output Class Initialized
DEBUG - 2011-08-23 17:30:20 --> Input Class Initialized
DEBUG - 2011-08-23 17:30:20 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-23 17:30:20 --> Language Class Initialized
DEBUG - 2011-08-23 17:30:20 --> Loader Class Initialized
DEBUG - 2011-08-23 17:30:20 --> Controller Class Initialized
ERROR - 2011-08-23 17:30:20 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-23 17:30:20 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-23 17:30:20 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-23 17:30:20 --> Model Class Initialized
DEBUG - 2011-08-23 17:30:20 --> Model Class Initialized
DEBUG - 2011-08-23 17:30:20 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-23 17:30:20 --> Database Driver Class Initialized
DEBUG - 2011-08-23 17:30:20 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-23 17:30:20 --> Helper loaded: url_helper
DEBUG - 2011-08-23 17:30:20 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-23 17:30:20 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-23 17:30:20 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-23 17:30:20 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-23 17:30:20 --> Final output sent to browser
DEBUG - 2011-08-23 17:30:20 --> Total execution time: 0.0322
DEBUG - 2011-08-23 17:30:21 --> Config Class Initialized
DEBUG - 2011-08-23 17:30:21 --> Hooks Class Initialized
DEBUG - 2011-08-23 17:30:21 --> Utf8 Class Initialized
DEBUG - 2011-08-23 17:30:21 --> UTF-8 Support Enabled
DEBUG - 2011-08-23 17:30:21 --> URI Class Initialized
DEBUG - 2011-08-23 17:30:21 --> Router Class Initialized
DEBUG - 2011-08-23 17:30:21 --> Output Class Initialized
DEBUG - 2011-08-23 17:30:21 --> Input Class Initialized
DEBUG - 2011-08-23 17:30:21 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-23 17:30:21 --> Language Class Initialized
DEBUG - 2011-08-23 17:30:21 --> Loader Class Initialized
DEBUG - 2011-08-23 17:30:21 --> Controller Class Initialized
DEBUG - 2011-08-23 17:30:21 --> Model Class Initialized
DEBUG - 2011-08-23 17:30:21 --> Model Class Initialized
DEBUG - 2011-08-23 17:30:21 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-23 17:30:21 --> Database Driver Class Initialized
DEBUG - 2011-08-23 17:30:22 --> Final output sent to browser
DEBUG - 2011-08-23 17:30:22 --> Total execution time: 0.5087
DEBUG - 2011-08-23 17:56:19 --> Config Class Initialized
DEBUG - 2011-08-23 17:56:19 --> Hooks Class Initialized
DEBUG - 2011-08-23 17:56:19 --> Utf8 Class Initialized
DEBUG - 2011-08-23 17:56:19 --> UTF-8 Support Enabled
DEBUG - 2011-08-23 17:56:19 --> URI Class Initialized
DEBUG - 2011-08-23 17:56:19 --> Router Class Initialized
DEBUG - 2011-08-23 17:56:19 --> No URI present. Default controller set.
DEBUG - 2011-08-23 17:56:19 --> Output Class Initialized
DEBUG - 2011-08-23 17:56:19 --> Input Class Initialized
DEBUG - 2011-08-23 17:56:19 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-23 17:56:19 --> Language Class Initialized
DEBUG - 2011-08-23 17:56:19 --> Loader Class Initialized
DEBUG - 2011-08-23 17:56:19 --> Controller Class Initialized
DEBUG - 2011-08-23 17:56:19 --> File loaded: application/views/splash/main.php
DEBUG - 2011-08-23 17:56:19 --> Helper loaded: url_helper
DEBUG - 2011-08-23 17:56:19 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-23 17:56:19 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-23 17:56:19 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-23 17:56:19 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-23 17:56:19 --> Final output sent to browser
DEBUG - 2011-08-23 17:56:19 --> Total execution time: 0.0119
DEBUG - 2011-08-23 18:11:24 --> Config Class Initialized
DEBUG - 2011-08-23 18:11:24 --> Hooks Class Initialized
DEBUG - 2011-08-23 18:11:24 --> Utf8 Class Initialized
DEBUG - 2011-08-23 18:11:24 --> UTF-8 Support Enabled
DEBUG - 2011-08-23 18:11:24 --> URI Class Initialized
DEBUG - 2011-08-23 18:11:24 --> Router Class Initialized
ERROR - 2011-08-23 18:11:24 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-08-23 18:29:22 --> Config Class Initialized
DEBUG - 2011-08-23 18:29:22 --> Hooks Class Initialized
DEBUG - 2011-08-23 18:29:22 --> Utf8 Class Initialized
DEBUG - 2011-08-23 18:29:22 --> UTF-8 Support Enabled
DEBUG - 2011-08-23 18:29:22 --> URI Class Initialized
DEBUG - 2011-08-23 18:29:22 --> Router Class Initialized
DEBUG - 2011-08-23 18:29:22 --> Output Class Initialized
DEBUG - 2011-08-23 18:29:22 --> Input Class Initialized
DEBUG - 2011-08-23 18:29:22 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-23 18:29:22 --> Language Class Initialized
DEBUG - 2011-08-23 18:29:22 --> Loader Class Initialized
DEBUG - 2011-08-23 18:29:22 --> Controller Class Initialized
DEBUG - 2011-08-23 18:29:22 --> Model Class Initialized
DEBUG - 2011-08-23 18:29:22 --> Model Class Initialized
DEBUG - 2011-08-23 18:29:22 --> Model Class Initialized
DEBUG - 2011-08-23 18:29:22 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-23 18:29:22 --> Database Driver Class Initialized
DEBUG - 2011-08-23 18:29:22 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-23 18:29:22 --> Helper loaded: url_helper
DEBUG - 2011-08-23 18:29:22 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-23 18:29:22 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-23 18:29:22 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-23 18:29:22 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-23 18:29:22 --> Final output sent to browser
DEBUG - 2011-08-23 18:29:22 --> Total execution time: 0.2615
DEBUG - 2011-08-23 18:29:24 --> Config Class Initialized
DEBUG - 2011-08-23 18:29:24 --> Hooks Class Initialized
DEBUG - 2011-08-23 18:29:24 --> Utf8 Class Initialized
DEBUG - 2011-08-23 18:29:24 --> UTF-8 Support Enabled
DEBUG - 2011-08-23 18:29:24 --> URI Class Initialized
DEBUG - 2011-08-23 18:29:24 --> Router Class Initialized
ERROR - 2011-08-23 18:29:24 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-23 18:29:24 --> Config Class Initialized
DEBUG - 2011-08-23 18:29:24 --> Hooks Class Initialized
DEBUG - 2011-08-23 18:29:24 --> Utf8 Class Initialized
DEBUG - 2011-08-23 18:29:24 --> UTF-8 Support Enabled
DEBUG - 2011-08-23 18:29:24 --> URI Class Initialized
DEBUG - 2011-08-23 18:29:24 --> Router Class Initialized
ERROR - 2011-08-23 18:29:24 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-23 18:29:37 --> Config Class Initialized
DEBUG - 2011-08-23 18:29:37 --> Hooks Class Initialized
DEBUG - 2011-08-23 18:29:37 --> Utf8 Class Initialized
DEBUG - 2011-08-23 18:29:37 --> UTF-8 Support Enabled
DEBUG - 2011-08-23 18:29:37 --> URI Class Initialized
DEBUG - 2011-08-23 18:29:37 --> Router Class Initialized
DEBUG - 2011-08-23 18:29:37 --> Output Class Initialized
DEBUG - 2011-08-23 18:29:37 --> Input Class Initialized
DEBUG - 2011-08-23 18:29:37 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-23 18:29:37 --> Language Class Initialized
DEBUG - 2011-08-23 18:29:37 --> Loader Class Initialized
DEBUG - 2011-08-23 18:29:37 --> Controller Class Initialized
DEBUG - 2011-08-23 18:29:37 --> Model Class Initialized
DEBUG - 2011-08-23 18:29:37 --> Model Class Initialized
DEBUG - 2011-08-23 18:29:37 --> Model Class Initialized
DEBUG - 2011-08-23 18:29:37 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-23 18:29:37 --> Database Driver Class Initialized
DEBUG - 2011-08-23 18:29:37 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-23 18:29:37 --> Helper loaded: url_helper
DEBUG - 2011-08-23 18:29:37 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-23 18:29:37 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-23 18:29:37 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-23 18:29:37 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-23 18:29:37 --> Final output sent to browser
DEBUG - 2011-08-23 18:29:37 --> Total execution time: 0.2167
DEBUG - 2011-08-23 18:29:38 --> Config Class Initialized
DEBUG - 2011-08-23 18:29:38 --> Hooks Class Initialized
DEBUG - 2011-08-23 18:29:38 --> Utf8 Class Initialized
DEBUG - 2011-08-23 18:29:38 --> UTF-8 Support Enabled
DEBUG - 2011-08-23 18:29:38 --> URI Class Initialized
DEBUG - 2011-08-23 18:29:38 --> Router Class Initialized
DEBUG - 2011-08-23 18:29:38 --> Output Class Initialized
DEBUG - 2011-08-23 18:29:38 --> Input Class Initialized
DEBUG - 2011-08-23 18:29:38 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-23 18:29:38 --> Language Class Initialized
DEBUG - 2011-08-23 18:29:38 --> Loader Class Initialized
DEBUG - 2011-08-23 18:29:38 --> Controller Class Initialized
DEBUG - 2011-08-23 18:29:38 --> Model Class Initialized
DEBUG - 2011-08-23 18:29:38 --> Model Class Initialized
DEBUG - 2011-08-23 18:29:38 --> Model Class Initialized
DEBUG - 2011-08-23 18:29:38 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-23 18:29:38 --> Database Driver Class Initialized
DEBUG - 2011-08-23 18:29:38 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-23 18:29:38 --> Helper loaded: url_helper
DEBUG - 2011-08-23 18:29:38 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-23 18:29:38 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-23 18:29:38 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-23 18:29:38 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-23 18:29:38 --> Final output sent to browser
DEBUG - 2011-08-23 18:29:38 --> Total execution time: 0.0423
DEBUG - 2011-08-23 18:29:38 --> Config Class Initialized
DEBUG - 2011-08-23 18:29:38 --> Hooks Class Initialized
DEBUG - 2011-08-23 18:29:38 --> Utf8 Class Initialized
DEBUG - 2011-08-23 18:29:38 --> UTF-8 Support Enabled
DEBUG - 2011-08-23 18:29:38 --> URI Class Initialized
DEBUG - 2011-08-23 18:29:38 --> Router Class Initialized
ERROR - 2011-08-23 18:29:38 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-23 18:30:11 --> Config Class Initialized
DEBUG - 2011-08-23 18:30:11 --> Hooks Class Initialized
DEBUG - 2011-08-23 18:30:11 --> Utf8 Class Initialized
DEBUG - 2011-08-23 18:30:11 --> UTF-8 Support Enabled
DEBUG - 2011-08-23 18:30:11 --> URI Class Initialized
DEBUG - 2011-08-23 18:30:11 --> Router Class Initialized
DEBUG - 2011-08-23 18:30:11 --> Output Class Initialized
DEBUG - 2011-08-23 18:30:11 --> Input Class Initialized
DEBUG - 2011-08-23 18:30:11 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-23 18:30:11 --> Language Class Initialized
DEBUG - 2011-08-23 18:30:11 --> Loader Class Initialized
DEBUG - 2011-08-23 18:30:11 --> Controller Class Initialized
DEBUG - 2011-08-23 18:30:11 --> Model Class Initialized
DEBUG - 2011-08-23 18:30:11 --> Model Class Initialized
DEBUG - 2011-08-23 18:30:11 --> Model Class Initialized
DEBUG - 2011-08-23 18:30:11 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-23 18:30:11 --> Database Driver Class Initialized
DEBUG - 2011-08-23 18:30:11 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-23 18:30:11 --> Helper loaded: url_helper
DEBUG - 2011-08-23 18:30:11 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-23 18:30:11 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-23 18:30:11 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-23 18:30:11 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-23 18:30:11 --> Final output sent to browser
DEBUG - 2011-08-23 18:30:11 --> Total execution time: 0.2755
DEBUG - 2011-08-23 18:30:12 --> Config Class Initialized
DEBUG - 2011-08-23 18:30:12 --> Hooks Class Initialized
DEBUG - 2011-08-23 18:30:12 --> Utf8 Class Initialized
DEBUG - 2011-08-23 18:30:12 --> UTF-8 Support Enabled
DEBUG - 2011-08-23 18:30:12 --> URI Class Initialized
DEBUG - 2011-08-23 18:30:12 --> Router Class Initialized
ERROR - 2011-08-23 18:30:12 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-23 18:30:14 --> Config Class Initialized
DEBUG - 2011-08-23 18:30:14 --> Hooks Class Initialized
DEBUG - 2011-08-23 18:30:14 --> Utf8 Class Initialized
DEBUG - 2011-08-23 18:30:14 --> UTF-8 Support Enabled
DEBUG - 2011-08-23 18:30:14 --> URI Class Initialized
DEBUG - 2011-08-23 18:30:14 --> Router Class Initialized
DEBUG - 2011-08-23 18:30:14 --> Output Class Initialized
DEBUG - 2011-08-23 18:30:14 --> Input Class Initialized
DEBUG - 2011-08-23 18:30:14 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-23 18:30:14 --> Language Class Initialized
DEBUG - 2011-08-23 18:30:14 --> Loader Class Initialized
DEBUG - 2011-08-23 18:30:14 --> Controller Class Initialized
DEBUG - 2011-08-23 18:30:14 --> Model Class Initialized
DEBUG - 2011-08-23 18:30:14 --> Model Class Initialized
DEBUG - 2011-08-23 18:30:14 --> Model Class Initialized
DEBUG - 2011-08-23 18:30:14 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-23 18:30:14 --> Database Driver Class Initialized
DEBUG - 2011-08-23 18:30:14 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-23 18:30:14 --> Helper loaded: url_helper
DEBUG - 2011-08-23 18:30:14 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-23 18:30:14 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-23 18:30:14 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-23 18:30:14 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-23 18:30:14 --> Final output sent to browser
DEBUG - 2011-08-23 18:30:14 --> Total execution time: 0.2024
DEBUG - 2011-08-23 18:30:24 --> Config Class Initialized
DEBUG - 2011-08-23 18:30:24 --> Hooks Class Initialized
DEBUG - 2011-08-23 18:30:24 --> Utf8 Class Initialized
DEBUG - 2011-08-23 18:30:24 --> UTF-8 Support Enabled
DEBUG - 2011-08-23 18:30:24 --> URI Class Initialized
DEBUG - 2011-08-23 18:30:24 --> Router Class Initialized
DEBUG - 2011-08-23 18:30:24 --> Output Class Initialized
DEBUG - 2011-08-23 18:30:24 --> Input Class Initialized
DEBUG - 2011-08-23 18:30:24 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-23 18:30:24 --> Language Class Initialized
DEBUG - 2011-08-23 18:30:24 --> Loader Class Initialized
DEBUG - 2011-08-23 18:30:24 --> Controller Class Initialized
DEBUG - 2011-08-23 18:30:24 --> Model Class Initialized
DEBUG - 2011-08-23 18:30:24 --> Model Class Initialized
DEBUG - 2011-08-23 18:30:24 --> Model Class Initialized
DEBUG - 2011-08-23 18:30:24 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-23 18:30:24 --> Database Driver Class Initialized
DEBUG - 2011-08-23 18:30:24 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-23 18:30:24 --> Helper loaded: url_helper
DEBUG - 2011-08-23 18:30:24 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-23 18:30:24 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-23 18:30:24 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-23 18:30:24 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-23 18:30:24 --> Final output sent to browser
DEBUG - 2011-08-23 18:30:24 --> Total execution time: 0.2283
DEBUG - 2011-08-23 18:30:25 --> Config Class Initialized
DEBUG - 2011-08-23 18:30:25 --> Hooks Class Initialized
DEBUG - 2011-08-23 18:30:25 --> Utf8 Class Initialized
DEBUG - 2011-08-23 18:30:25 --> UTF-8 Support Enabled
DEBUG - 2011-08-23 18:30:25 --> URI Class Initialized
DEBUG - 2011-08-23 18:30:25 --> Router Class Initialized
DEBUG - 2011-08-23 18:30:25 --> Output Class Initialized
DEBUG - 2011-08-23 18:30:25 --> Input Class Initialized
DEBUG - 2011-08-23 18:30:25 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-23 18:30:25 --> Language Class Initialized
DEBUG - 2011-08-23 18:30:25 --> Loader Class Initialized
DEBUG - 2011-08-23 18:30:25 --> Controller Class Initialized
DEBUG - 2011-08-23 18:30:25 --> Model Class Initialized
DEBUG - 2011-08-23 18:30:25 --> Model Class Initialized
DEBUG - 2011-08-23 18:30:25 --> Model Class Initialized
DEBUG - 2011-08-23 18:30:25 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-23 18:30:25 --> Database Driver Class Initialized
DEBUG - 2011-08-23 18:30:25 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-23 18:30:25 --> Helper loaded: url_helper
DEBUG - 2011-08-23 18:30:25 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-23 18:30:25 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-23 18:30:25 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-23 18:30:25 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-23 18:30:25 --> Final output sent to browser
DEBUG - 2011-08-23 18:30:25 --> Total execution time: 0.1094
DEBUG - 2011-08-23 18:30:25 --> Config Class Initialized
DEBUG - 2011-08-23 18:30:25 --> Hooks Class Initialized
DEBUG - 2011-08-23 18:30:25 --> Utf8 Class Initialized
DEBUG - 2011-08-23 18:30:25 --> UTF-8 Support Enabled
DEBUG - 2011-08-23 18:30:25 --> URI Class Initialized
DEBUG - 2011-08-23 18:30:25 --> Router Class Initialized
ERROR - 2011-08-23 18:30:25 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-23 18:30:42 --> Config Class Initialized
DEBUG - 2011-08-23 18:30:42 --> Hooks Class Initialized
DEBUG - 2011-08-23 18:30:42 --> Utf8 Class Initialized
DEBUG - 2011-08-23 18:30:42 --> UTF-8 Support Enabled
DEBUG - 2011-08-23 18:30:42 --> URI Class Initialized
DEBUG - 2011-08-23 18:30:42 --> Router Class Initialized
DEBUG - 2011-08-23 18:30:42 --> Output Class Initialized
DEBUG - 2011-08-23 18:30:42 --> Input Class Initialized
DEBUG - 2011-08-23 18:30:42 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-23 18:30:42 --> Language Class Initialized
DEBUG - 2011-08-23 18:30:42 --> Loader Class Initialized
DEBUG - 2011-08-23 18:30:42 --> Controller Class Initialized
DEBUG - 2011-08-23 18:30:42 --> Model Class Initialized
DEBUG - 2011-08-23 18:30:42 --> Model Class Initialized
DEBUG - 2011-08-23 18:30:42 --> Model Class Initialized
DEBUG - 2011-08-23 18:30:42 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-23 18:30:42 --> Database Driver Class Initialized
DEBUG - 2011-08-23 18:30:42 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-23 18:30:42 --> Helper loaded: url_helper
DEBUG - 2011-08-23 18:30:42 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-23 18:30:42 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-23 18:30:42 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-23 18:30:42 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-23 18:30:42 --> Final output sent to browser
DEBUG - 2011-08-23 18:30:42 --> Total execution time: 0.2771
DEBUG - 2011-08-23 18:30:43 --> Config Class Initialized
DEBUG - 2011-08-23 18:30:43 --> Hooks Class Initialized
DEBUG - 2011-08-23 18:30:43 --> Utf8 Class Initialized
DEBUG - 2011-08-23 18:30:43 --> UTF-8 Support Enabled
DEBUG - 2011-08-23 18:30:43 --> URI Class Initialized
DEBUG - 2011-08-23 18:30:43 --> Router Class Initialized
ERROR - 2011-08-23 18:30:43 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-23 18:31:00 --> Config Class Initialized
DEBUG - 2011-08-23 18:31:00 --> Hooks Class Initialized
DEBUG - 2011-08-23 18:31:00 --> Utf8 Class Initialized
DEBUG - 2011-08-23 18:31:00 --> UTF-8 Support Enabled
DEBUG - 2011-08-23 18:31:00 --> URI Class Initialized
DEBUG - 2011-08-23 18:31:00 --> Router Class Initialized
DEBUG - 2011-08-23 18:31:00 --> Output Class Initialized
DEBUG - 2011-08-23 18:31:00 --> Input Class Initialized
DEBUG - 2011-08-23 18:31:00 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-23 18:31:00 --> Language Class Initialized
DEBUG - 2011-08-23 18:31:00 --> Loader Class Initialized
DEBUG - 2011-08-23 18:31:00 --> Controller Class Initialized
DEBUG - 2011-08-23 18:31:00 --> Model Class Initialized
DEBUG - 2011-08-23 18:31:00 --> Model Class Initialized
DEBUG - 2011-08-23 18:31:00 --> Model Class Initialized
DEBUG - 2011-08-23 18:31:00 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-23 18:31:00 --> Database Driver Class Initialized
DEBUG - 2011-08-23 18:31:00 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-23 18:31:00 --> Helper loaded: url_helper
DEBUG - 2011-08-23 18:31:00 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-23 18:31:00 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-23 18:31:00 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-23 18:31:00 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-23 18:31:00 --> Final output sent to browser
DEBUG - 2011-08-23 18:31:00 --> Total execution time: 0.2146
DEBUG - 2011-08-23 18:31:01 --> Config Class Initialized
DEBUG - 2011-08-23 18:31:01 --> Hooks Class Initialized
DEBUG - 2011-08-23 18:31:01 --> Utf8 Class Initialized
DEBUG - 2011-08-23 18:31:01 --> UTF-8 Support Enabled
DEBUG - 2011-08-23 18:31:01 --> URI Class Initialized
DEBUG - 2011-08-23 18:31:01 --> Router Class Initialized
DEBUG - 2011-08-23 18:31:01 --> Output Class Initialized
DEBUG - 2011-08-23 18:31:01 --> Input Class Initialized
DEBUG - 2011-08-23 18:31:01 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-23 18:31:01 --> Language Class Initialized
DEBUG - 2011-08-23 18:31:01 --> Loader Class Initialized
DEBUG - 2011-08-23 18:31:01 --> Controller Class Initialized
DEBUG - 2011-08-23 18:31:01 --> Model Class Initialized
DEBUG - 2011-08-23 18:31:01 --> Model Class Initialized
DEBUG - 2011-08-23 18:31:01 --> Model Class Initialized
DEBUG - 2011-08-23 18:31:01 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-23 18:31:01 --> Database Driver Class Initialized
DEBUG - 2011-08-23 18:31:01 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-23 18:31:01 --> Helper loaded: url_helper
DEBUG - 2011-08-23 18:31:01 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-23 18:31:01 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-23 18:31:01 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-23 18:31:01 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-23 18:31:01 --> Final output sent to browser
DEBUG - 2011-08-23 18:31:01 --> Total execution time: 0.0424
DEBUG - 2011-08-23 18:31:01 --> Config Class Initialized
DEBUG - 2011-08-23 18:31:01 --> Hooks Class Initialized
DEBUG - 2011-08-23 18:31:01 --> Utf8 Class Initialized
DEBUG - 2011-08-23 18:31:01 --> UTF-8 Support Enabled
DEBUG - 2011-08-23 18:31:01 --> URI Class Initialized
DEBUG - 2011-08-23 18:31:01 --> Router Class Initialized
ERROR - 2011-08-23 18:31:01 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-23 18:31:27 --> Config Class Initialized
DEBUG - 2011-08-23 18:31:27 --> Hooks Class Initialized
DEBUG - 2011-08-23 18:31:27 --> Utf8 Class Initialized
DEBUG - 2011-08-23 18:31:27 --> UTF-8 Support Enabled
DEBUG - 2011-08-23 18:31:27 --> URI Class Initialized
DEBUG - 2011-08-23 18:31:27 --> Router Class Initialized
DEBUG - 2011-08-23 18:31:27 --> Output Class Initialized
DEBUG - 2011-08-23 18:31:27 --> Input Class Initialized
DEBUG - 2011-08-23 18:31:27 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-23 18:31:27 --> Language Class Initialized
DEBUG - 2011-08-23 18:31:27 --> Loader Class Initialized
DEBUG - 2011-08-23 18:31:27 --> Controller Class Initialized
DEBUG - 2011-08-23 18:31:27 --> Model Class Initialized
DEBUG - 2011-08-23 18:31:27 --> Model Class Initialized
DEBUG - 2011-08-23 18:31:27 --> Model Class Initialized
DEBUG - 2011-08-23 18:31:27 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-23 18:31:27 --> Database Driver Class Initialized
DEBUG - 2011-08-23 18:31:27 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-23 18:31:27 --> Helper loaded: url_helper
DEBUG - 2011-08-23 18:31:27 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-23 18:31:27 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-23 18:31:27 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-23 18:31:27 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-23 18:31:27 --> Final output sent to browser
DEBUG - 2011-08-23 18:31:27 --> Total execution time: 0.2725
DEBUG - 2011-08-23 18:31:28 --> Config Class Initialized
DEBUG - 2011-08-23 18:31:28 --> Hooks Class Initialized
DEBUG - 2011-08-23 18:31:28 --> Utf8 Class Initialized
DEBUG - 2011-08-23 18:31:28 --> UTF-8 Support Enabled
DEBUG - 2011-08-23 18:31:28 --> URI Class Initialized
DEBUG - 2011-08-23 18:31:28 --> Router Class Initialized
ERROR - 2011-08-23 18:31:28 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-23 18:31:51 --> Config Class Initialized
DEBUG - 2011-08-23 18:31:51 --> Hooks Class Initialized
DEBUG - 2011-08-23 18:31:51 --> Utf8 Class Initialized
DEBUG - 2011-08-23 18:31:51 --> UTF-8 Support Enabled
DEBUG - 2011-08-23 18:31:51 --> URI Class Initialized
DEBUG - 2011-08-23 18:31:51 --> Router Class Initialized
DEBUG - 2011-08-23 18:31:51 --> Output Class Initialized
DEBUG - 2011-08-23 18:31:51 --> Input Class Initialized
DEBUG - 2011-08-23 18:31:51 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-23 18:31:51 --> Language Class Initialized
DEBUG - 2011-08-23 18:31:51 --> Loader Class Initialized
DEBUG - 2011-08-23 18:31:51 --> Controller Class Initialized
DEBUG - 2011-08-23 18:31:51 --> Model Class Initialized
DEBUG - 2011-08-23 18:31:51 --> Model Class Initialized
DEBUG - 2011-08-23 18:31:51 --> Model Class Initialized
DEBUG - 2011-08-23 18:31:51 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-23 18:31:51 --> Database Driver Class Initialized
DEBUG - 2011-08-23 18:31:51 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-23 18:31:51 --> Helper loaded: url_helper
DEBUG - 2011-08-23 18:31:51 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-23 18:31:51 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-23 18:31:51 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-23 18:31:51 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-23 18:31:51 --> Final output sent to browser
DEBUG - 2011-08-23 18:31:51 --> Total execution time: 0.2789
DEBUG - 2011-08-23 18:31:52 --> Config Class Initialized
DEBUG - 2011-08-23 18:31:52 --> Hooks Class Initialized
DEBUG - 2011-08-23 18:31:52 --> Utf8 Class Initialized
DEBUG - 2011-08-23 18:31:52 --> UTF-8 Support Enabled
DEBUG - 2011-08-23 18:31:52 --> URI Class Initialized
DEBUG - 2011-08-23 18:31:52 --> Router Class Initialized
ERROR - 2011-08-23 18:31:52 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-23 18:31:53 --> Config Class Initialized
DEBUG - 2011-08-23 18:31:53 --> Hooks Class Initialized
DEBUG - 2011-08-23 18:31:53 --> Utf8 Class Initialized
DEBUG - 2011-08-23 18:31:53 --> UTF-8 Support Enabled
DEBUG - 2011-08-23 18:31:53 --> URI Class Initialized
DEBUG - 2011-08-23 18:31:53 --> Router Class Initialized
DEBUG - 2011-08-23 18:31:53 --> Output Class Initialized
DEBUG - 2011-08-23 18:31:53 --> Input Class Initialized
DEBUG - 2011-08-23 18:31:53 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-23 18:31:53 --> Language Class Initialized
DEBUG - 2011-08-23 18:31:53 --> Loader Class Initialized
DEBUG - 2011-08-23 18:31:53 --> Controller Class Initialized
DEBUG - 2011-08-23 18:31:53 --> Model Class Initialized
DEBUG - 2011-08-23 18:31:53 --> Model Class Initialized
DEBUG - 2011-08-23 18:31:53 --> Model Class Initialized
DEBUG - 2011-08-23 18:31:53 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-23 18:31:53 --> Database Driver Class Initialized
DEBUG - 2011-08-23 18:31:53 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-23 18:31:53 --> Helper loaded: url_helper
DEBUG - 2011-08-23 18:31:53 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-23 18:31:53 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-23 18:31:53 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-23 18:31:53 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-23 18:31:53 --> Final output sent to browser
DEBUG - 2011-08-23 18:31:53 --> Total execution time: 0.1020
DEBUG - 2011-08-23 18:32:02 --> Config Class Initialized
DEBUG - 2011-08-23 18:32:02 --> Hooks Class Initialized
DEBUG - 2011-08-23 18:32:02 --> Utf8 Class Initialized
DEBUG - 2011-08-23 18:32:02 --> UTF-8 Support Enabled
DEBUG - 2011-08-23 18:32:02 --> URI Class Initialized
DEBUG - 2011-08-23 18:32:02 --> Router Class Initialized
DEBUG - 2011-08-23 18:32:02 --> Output Class Initialized
DEBUG - 2011-08-23 18:32:02 --> Input Class Initialized
DEBUG - 2011-08-23 18:32:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-23 18:32:02 --> Language Class Initialized
DEBUG - 2011-08-23 18:32:02 --> Loader Class Initialized
DEBUG - 2011-08-23 18:32:02 --> Controller Class Initialized
DEBUG - 2011-08-23 18:32:02 --> Model Class Initialized
DEBUG - 2011-08-23 18:32:02 --> Model Class Initialized
DEBUG - 2011-08-23 18:32:02 --> Model Class Initialized
DEBUG - 2011-08-23 18:32:02 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-23 18:32:02 --> Database Driver Class Initialized
DEBUG - 2011-08-23 18:32:02 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-23 18:32:02 --> Helper loaded: url_helper
DEBUG - 2011-08-23 18:32:02 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-23 18:32:02 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-23 18:32:02 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-23 18:32:02 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-23 18:32:02 --> Final output sent to browser
DEBUG - 2011-08-23 18:32:02 --> Total execution time: 0.3068
DEBUG - 2011-08-23 18:32:03 --> Config Class Initialized
DEBUG - 2011-08-23 18:32:03 --> Hooks Class Initialized
DEBUG - 2011-08-23 18:32:03 --> Utf8 Class Initialized
DEBUG - 2011-08-23 18:32:03 --> UTF-8 Support Enabled
DEBUG - 2011-08-23 18:32:03 --> URI Class Initialized
DEBUG - 2011-08-23 18:32:03 --> Router Class Initialized
ERROR - 2011-08-23 18:32:03 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-23 18:32:25 --> Config Class Initialized
DEBUG - 2011-08-23 18:32:25 --> Hooks Class Initialized
DEBUG - 2011-08-23 18:32:25 --> Utf8 Class Initialized
DEBUG - 2011-08-23 18:32:25 --> UTF-8 Support Enabled
DEBUG - 2011-08-23 18:32:25 --> URI Class Initialized
DEBUG - 2011-08-23 18:32:25 --> Router Class Initialized
DEBUG - 2011-08-23 18:32:25 --> Output Class Initialized
DEBUG - 2011-08-23 18:32:25 --> Input Class Initialized
DEBUG - 2011-08-23 18:32:25 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-23 18:32:25 --> Language Class Initialized
DEBUG - 2011-08-23 18:32:25 --> Loader Class Initialized
DEBUG - 2011-08-23 18:32:25 --> Controller Class Initialized
DEBUG - 2011-08-23 18:32:25 --> Model Class Initialized
DEBUG - 2011-08-23 18:32:25 --> Model Class Initialized
DEBUG - 2011-08-23 18:32:25 --> Model Class Initialized
DEBUG - 2011-08-23 18:32:25 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-23 18:32:25 --> Database Driver Class Initialized
DEBUG - 2011-08-23 18:32:26 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-23 18:32:26 --> Helper loaded: url_helper
DEBUG - 2011-08-23 18:32:26 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-23 18:32:26 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-23 18:32:26 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-23 18:32:26 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-23 18:32:26 --> Final output sent to browser
DEBUG - 2011-08-23 18:32:26 --> Total execution time: 0.2623
DEBUG - 2011-08-23 18:32:27 --> Config Class Initialized
DEBUG - 2011-08-23 18:32:27 --> Hooks Class Initialized
DEBUG - 2011-08-23 18:32:27 --> Utf8 Class Initialized
DEBUG - 2011-08-23 18:32:27 --> UTF-8 Support Enabled
DEBUG - 2011-08-23 18:32:27 --> URI Class Initialized
DEBUG - 2011-08-23 18:32:27 --> Router Class Initialized
ERROR - 2011-08-23 18:32:27 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-23 18:55:26 --> Config Class Initialized
DEBUG - 2011-08-23 18:55:26 --> Hooks Class Initialized
DEBUG - 2011-08-23 18:55:26 --> Utf8 Class Initialized
DEBUG - 2011-08-23 18:55:26 --> UTF-8 Support Enabled
DEBUG - 2011-08-23 18:55:26 --> URI Class Initialized
DEBUG - 2011-08-23 18:55:26 --> Router Class Initialized
DEBUG - 2011-08-23 18:55:26 --> Output Class Initialized
DEBUG - 2011-08-23 18:55:26 --> Input Class Initialized
DEBUG - 2011-08-23 18:55:26 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-23 18:55:26 --> Language Class Initialized
DEBUG - 2011-08-23 18:55:26 --> Loader Class Initialized
DEBUG - 2011-08-23 18:55:26 --> Controller Class Initialized
DEBUG - 2011-08-23 18:55:26 --> Model Class Initialized
DEBUG - 2011-08-23 18:55:26 --> Model Class Initialized
DEBUG - 2011-08-23 18:55:26 --> Model Class Initialized
DEBUG - 2011-08-23 18:55:26 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-23 18:55:26 --> Database Driver Class Initialized
DEBUG - 2011-08-23 18:55:26 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-23 18:55:26 --> Helper loaded: url_helper
DEBUG - 2011-08-23 18:55:26 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-23 18:55:26 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-23 18:55:26 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-23 18:55:26 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-23 18:55:26 --> Final output sent to browser
DEBUG - 2011-08-23 18:55:26 --> Total execution time: 0.3147
DEBUG - 2011-08-23 18:55:27 --> Config Class Initialized
DEBUG - 2011-08-23 18:55:27 --> Hooks Class Initialized
DEBUG - 2011-08-23 18:55:27 --> Utf8 Class Initialized
DEBUG - 2011-08-23 18:55:27 --> UTF-8 Support Enabled
DEBUG - 2011-08-23 18:55:27 --> URI Class Initialized
DEBUG - 2011-08-23 18:55:27 --> Router Class Initialized
ERROR - 2011-08-23 18:55:27 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-23 18:55:37 --> Config Class Initialized
DEBUG - 2011-08-23 18:55:37 --> Hooks Class Initialized
DEBUG - 2011-08-23 18:55:37 --> Utf8 Class Initialized
DEBUG - 2011-08-23 18:55:37 --> UTF-8 Support Enabled
DEBUG - 2011-08-23 18:55:37 --> URI Class Initialized
DEBUG - 2011-08-23 18:55:37 --> Router Class Initialized
DEBUG - 2011-08-23 18:55:37 --> Output Class Initialized
DEBUG - 2011-08-23 18:55:37 --> Input Class Initialized
DEBUG - 2011-08-23 18:55:37 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-23 18:55:37 --> Language Class Initialized
DEBUG - 2011-08-23 18:55:37 --> Loader Class Initialized
DEBUG - 2011-08-23 18:55:37 --> Controller Class Initialized
DEBUG - 2011-08-23 18:55:37 --> Model Class Initialized
DEBUG - 2011-08-23 18:55:37 --> Model Class Initialized
DEBUG - 2011-08-23 18:55:37 --> Model Class Initialized
DEBUG - 2011-08-23 18:55:37 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-23 18:55:37 --> Database Driver Class Initialized
DEBUG - 2011-08-23 18:55:37 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-23 18:55:37 --> Helper loaded: url_helper
DEBUG - 2011-08-23 18:55:37 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-23 18:55:37 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-23 18:55:37 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-23 18:55:37 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-23 18:55:37 --> Final output sent to browser
DEBUG - 2011-08-23 18:55:37 --> Total execution time: 0.2018
DEBUG - 2011-08-23 18:55:38 --> Config Class Initialized
DEBUG - 2011-08-23 18:55:38 --> Hooks Class Initialized
DEBUG - 2011-08-23 18:55:38 --> Utf8 Class Initialized
DEBUG - 2011-08-23 18:55:38 --> UTF-8 Support Enabled
DEBUG - 2011-08-23 18:55:38 --> URI Class Initialized
DEBUG - 2011-08-23 18:55:38 --> Router Class Initialized
DEBUG - 2011-08-23 18:55:38 --> Output Class Initialized
DEBUG - 2011-08-23 18:55:38 --> Input Class Initialized
DEBUG - 2011-08-23 18:55:38 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-23 18:55:38 --> Language Class Initialized
DEBUG - 2011-08-23 18:55:38 --> Loader Class Initialized
DEBUG - 2011-08-23 18:55:38 --> Controller Class Initialized
DEBUG - 2011-08-23 18:55:38 --> Model Class Initialized
DEBUG - 2011-08-23 18:55:38 --> Model Class Initialized
DEBUG - 2011-08-23 18:55:38 --> Model Class Initialized
DEBUG - 2011-08-23 18:55:38 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-23 18:55:38 --> Database Driver Class Initialized
DEBUG - 2011-08-23 18:55:38 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-23 18:55:38 --> Helper loaded: url_helper
DEBUG - 2011-08-23 18:55:38 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-23 18:55:38 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-23 18:55:38 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-23 18:55:38 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-23 18:55:38 --> Final output sent to browser
DEBUG - 2011-08-23 18:55:38 --> Total execution time: 0.0496
DEBUG - 2011-08-23 18:55:39 --> Config Class Initialized
DEBUG - 2011-08-23 18:55:39 --> Hooks Class Initialized
DEBUG - 2011-08-23 18:55:39 --> Utf8 Class Initialized
DEBUG - 2011-08-23 18:55:39 --> UTF-8 Support Enabled
DEBUG - 2011-08-23 18:55:39 --> URI Class Initialized
DEBUG - 2011-08-23 18:55:39 --> Router Class Initialized
ERROR - 2011-08-23 18:55:39 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-23 18:56:01 --> Config Class Initialized
DEBUG - 2011-08-23 18:56:01 --> Hooks Class Initialized
DEBUG - 2011-08-23 18:56:01 --> Utf8 Class Initialized
DEBUG - 2011-08-23 18:56:01 --> UTF-8 Support Enabled
DEBUG - 2011-08-23 18:56:01 --> URI Class Initialized
DEBUG - 2011-08-23 18:56:01 --> Router Class Initialized
DEBUG - 2011-08-23 18:56:01 --> Output Class Initialized
DEBUG - 2011-08-23 18:56:01 --> Input Class Initialized
DEBUG - 2011-08-23 18:56:01 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-23 18:56:01 --> Language Class Initialized
DEBUG - 2011-08-23 18:56:01 --> Loader Class Initialized
DEBUG - 2011-08-23 18:56:01 --> Controller Class Initialized
DEBUG - 2011-08-23 18:56:01 --> Model Class Initialized
DEBUG - 2011-08-23 18:56:01 --> Model Class Initialized
DEBUG - 2011-08-23 18:56:01 --> Model Class Initialized
DEBUG - 2011-08-23 18:56:01 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-23 18:56:01 --> Database Driver Class Initialized
DEBUG - 2011-08-23 18:56:02 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-23 18:56:02 --> Helper loaded: url_helper
DEBUG - 2011-08-23 18:56:02 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-23 18:56:02 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-23 18:56:02 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-23 18:56:02 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-23 18:56:02 --> Final output sent to browser
DEBUG - 2011-08-23 18:56:02 --> Total execution time: 1.0683
DEBUG - 2011-08-23 18:56:03 --> Config Class Initialized
DEBUG - 2011-08-23 18:56:03 --> Hooks Class Initialized
DEBUG - 2011-08-23 18:56:03 --> Utf8 Class Initialized
DEBUG - 2011-08-23 18:56:03 --> UTF-8 Support Enabled
DEBUG - 2011-08-23 18:56:03 --> URI Class Initialized
DEBUG - 2011-08-23 18:56:03 --> Router Class Initialized
DEBUG - 2011-08-23 18:56:03 --> Output Class Initialized
DEBUG - 2011-08-23 18:56:03 --> Input Class Initialized
DEBUG - 2011-08-23 18:56:03 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-23 18:56:03 --> Language Class Initialized
DEBUG - 2011-08-23 18:56:03 --> Loader Class Initialized
DEBUG - 2011-08-23 18:56:03 --> Controller Class Initialized
DEBUG - 2011-08-23 18:56:03 --> Model Class Initialized
DEBUG - 2011-08-23 18:56:03 --> Model Class Initialized
DEBUG - 2011-08-23 18:56:03 --> Model Class Initialized
DEBUG - 2011-08-23 18:56:03 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-23 18:56:03 --> Database Driver Class Initialized
DEBUG - 2011-08-23 18:56:03 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-23 18:56:03 --> Helper loaded: url_helper
DEBUG - 2011-08-23 18:56:03 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-23 18:56:03 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-23 18:56:03 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-23 18:56:03 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-23 18:56:03 --> Final output sent to browser
DEBUG - 2011-08-23 18:56:03 --> Total execution time: 0.1293
DEBUG - 2011-08-23 18:56:03 --> Config Class Initialized
DEBUG - 2011-08-23 18:56:03 --> Hooks Class Initialized
DEBUG - 2011-08-23 18:56:03 --> Utf8 Class Initialized
DEBUG - 2011-08-23 18:56:03 --> UTF-8 Support Enabled
DEBUG - 2011-08-23 18:56:03 --> URI Class Initialized
DEBUG - 2011-08-23 18:56:03 --> Router Class Initialized
DEBUG - 2011-08-23 18:56:03 --> Output Class Initialized
DEBUG - 2011-08-23 18:56:03 --> Input Class Initialized
DEBUG - 2011-08-23 18:56:03 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-23 18:56:03 --> Language Class Initialized
DEBUG - 2011-08-23 18:56:03 --> Loader Class Initialized
DEBUG - 2011-08-23 18:56:03 --> Controller Class Initialized
DEBUG - 2011-08-23 18:56:03 --> Model Class Initialized
DEBUG - 2011-08-23 18:56:03 --> Model Class Initialized
DEBUG - 2011-08-23 18:56:03 --> Model Class Initialized
DEBUG - 2011-08-23 18:56:03 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-23 18:56:03 --> Database Driver Class Initialized
DEBUG - 2011-08-23 18:56:03 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-23 18:56:03 --> Helper loaded: url_helper
DEBUG - 2011-08-23 18:56:03 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-23 18:56:03 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-23 18:56:03 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-23 18:56:03 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-23 18:56:03 --> Final output sent to browser
DEBUG - 2011-08-23 18:56:03 --> Total execution time: 0.1238
DEBUG - 2011-08-23 18:56:04 --> Config Class Initialized
DEBUG - 2011-08-23 18:56:04 --> Hooks Class Initialized
DEBUG - 2011-08-23 18:56:04 --> Utf8 Class Initialized
DEBUG - 2011-08-23 18:56:04 --> UTF-8 Support Enabled
DEBUG - 2011-08-23 18:56:04 --> URI Class Initialized
DEBUG - 2011-08-23 18:56:04 --> Router Class Initialized
ERROR - 2011-08-23 18:56:04 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-23 18:56:35 --> Config Class Initialized
DEBUG - 2011-08-23 18:56:35 --> Hooks Class Initialized
DEBUG - 2011-08-23 18:56:35 --> Utf8 Class Initialized
DEBUG - 2011-08-23 18:56:35 --> UTF-8 Support Enabled
DEBUG - 2011-08-23 18:56:35 --> URI Class Initialized
DEBUG - 2011-08-23 18:56:35 --> Router Class Initialized
DEBUG - 2011-08-23 18:56:35 --> Output Class Initialized
DEBUG - 2011-08-23 18:56:35 --> Input Class Initialized
DEBUG - 2011-08-23 18:56:35 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-23 18:56:35 --> Language Class Initialized
DEBUG - 2011-08-23 18:56:35 --> Loader Class Initialized
DEBUG - 2011-08-23 18:56:35 --> Controller Class Initialized
DEBUG - 2011-08-23 18:56:35 --> Model Class Initialized
DEBUG - 2011-08-23 18:56:35 --> Model Class Initialized
DEBUG - 2011-08-23 18:56:35 --> Model Class Initialized
DEBUG - 2011-08-23 18:56:35 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-23 18:56:35 --> Database Driver Class Initialized
DEBUG - 2011-08-23 18:56:35 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-23 18:56:35 --> Helper loaded: url_helper
DEBUG - 2011-08-23 18:56:35 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-23 18:56:35 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-23 18:56:35 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-23 18:56:35 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-23 18:56:35 --> Final output sent to browser
DEBUG - 2011-08-23 18:56:35 --> Total execution time: 0.3405
DEBUG - 2011-08-23 18:56:36 --> Config Class Initialized
DEBUG - 2011-08-23 18:56:36 --> Hooks Class Initialized
DEBUG - 2011-08-23 18:56:36 --> Utf8 Class Initialized
DEBUG - 2011-08-23 18:56:36 --> UTF-8 Support Enabled
DEBUG - 2011-08-23 18:56:36 --> URI Class Initialized
DEBUG - 2011-08-23 18:56:36 --> Router Class Initialized
DEBUG - 2011-08-23 18:56:36 --> Output Class Initialized
DEBUG - 2011-08-23 18:56:36 --> Input Class Initialized
DEBUG - 2011-08-23 18:56:36 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-23 18:56:36 --> Language Class Initialized
DEBUG - 2011-08-23 18:56:36 --> Loader Class Initialized
DEBUG - 2011-08-23 18:56:36 --> Controller Class Initialized
DEBUG - 2011-08-23 18:56:36 --> Model Class Initialized
DEBUG - 2011-08-23 18:56:36 --> Model Class Initialized
DEBUG - 2011-08-23 18:56:36 --> Model Class Initialized
DEBUG - 2011-08-23 18:56:36 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-23 18:56:36 --> Database Driver Class Initialized
DEBUG - 2011-08-23 18:56:36 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-23 18:56:36 --> Helper loaded: url_helper
DEBUG - 2011-08-23 18:56:36 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-23 18:56:36 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-23 18:56:36 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-23 18:56:36 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-23 18:56:36 --> Final output sent to browser
DEBUG - 2011-08-23 18:56:36 --> Total execution time: 0.0485
DEBUG - 2011-08-23 18:56:36 --> Config Class Initialized
DEBUG - 2011-08-23 18:56:36 --> Hooks Class Initialized
DEBUG - 2011-08-23 18:56:36 --> Utf8 Class Initialized
DEBUG - 2011-08-23 18:56:36 --> UTF-8 Support Enabled
DEBUG - 2011-08-23 18:56:36 --> URI Class Initialized
DEBUG - 2011-08-23 18:56:36 --> Router Class Initialized
ERROR - 2011-08-23 18:56:36 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-23 18:56:43 --> Config Class Initialized
DEBUG - 2011-08-23 18:56:43 --> Hooks Class Initialized
DEBUG - 2011-08-23 18:56:43 --> Utf8 Class Initialized
DEBUG - 2011-08-23 18:56:43 --> UTF-8 Support Enabled
DEBUG - 2011-08-23 18:56:43 --> URI Class Initialized
DEBUG - 2011-08-23 18:56:43 --> Router Class Initialized
DEBUG - 2011-08-23 18:56:43 --> Output Class Initialized
DEBUG - 2011-08-23 18:56:43 --> Input Class Initialized
DEBUG - 2011-08-23 18:56:43 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-23 18:56:43 --> Language Class Initialized
DEBUG - 2011-08-23 18:56:43 --> Loader Class Initialized
DEBUG - 2011-08-23 18:56:43 --> Controller Class Initialized
DEBUG - 2011-08-23 18:56:43 --> Model Class Initialized
DEBUG - 2011-08-23 18:56:43 --> Model Class Initialized
DEBUG - 2011-08-23 18:56:43 --> Model Class Initialized
DEBUG - 2011-08-23 18:56:43 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-23 18:56:43 --> Database Driver Class Initialized
DEBUG - 2011-08-23 18:56:43 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-23 18:56:43 --> Helper loaded: url_helper
DEBUG - 2011-08-23 18:56:43 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-23 18:56:43 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-23 18:56:43 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-23 18:56:43 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-23 18:56:43 --> Final output sent to browser
DEBUG - 2011-08-23 18:56:43 --> Total execution time: 0.2351
DEBUG - 2011-08-23 18:56:44 --> Config Class Initialized
DEBUG - 2011-08-23 18:56:44 --> Hooks Class Initialized
DEBUG - 2011-08-23 18:56:44 --> Utf8 Class Initialized
DEBUG - 2011-08-23 18:56:44 --> UTF-8 Support Enabled
DEBUG - 2011-08-23 18:56:44 --> URI Class Initialized
DEBUG - 2011-08-23 18:56:44 --> Router Class Initialized
ERROR - 2011-08-23 18:56:44 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-23 18:56:52 --> Config Class Initialized
DEBUG - 2011-08-23 18:56:52 --> Hooks Class Initialized
DEBUG - 2011-08-23 18:56:52 --> Utf8 Class Initialized
DEBUG - 2011-08-23 18:56:52 --> UTF-8 Support Enabled
DEBUG - 2011-08-23 18:56:52 --> URI Class Initialized
DEBUG - 2011-08-23 18:56:52 --> Router Class Initialized
DEBUG - 2011-08-23 18:56:52 --> Output Class Initialized
DEBUG - 2011-08-23 18:56:52 --> Input Class Initialized
DEBUG - 2011-08-23 18:56:52 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-23 18:56:52 --> Language Class Initialized
DEBUG - 2011-08-23 18:56:52 --> Loader Class Initialized
DEBUG - 2011-08-23 18:56:52 --> Controller Class Initialized
DEBUG - 2011-08-23 18:56:52 --> Model Class Initialized
DEBUG - 2011-08-23 18:56:52 --> Model Class Initialized
DEBUG - 2011-08-23 18:56:52 --> Model Class Initialized
DEBUG - 2011-08-23 18:56:52 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-23 18:56:52 --> Database Driver Class Initialized
DEBUG - 2011-08-23 18:56:53 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-23 18:56:53 --> Helper loaded: url_helper
DEBUG - 2011-08-23 18:56:53 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-23 18:56:53 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-23 18:56:53 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-23 18:56:53 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-23 18:56:53 --> Final output sent to browser
DEBUG - 2011-08-23 18:56:53 --> Total execution time: 0.2868
DEBUG - 2011-08-23 18:56:54 --> Config Class Initialized
DEBUG - 2011-08-23 18:56:54 --> Hooks Class Initialized
DEBUG - 2011-08-23 18:56:54 --> Utf8 Class Initialized
DEBUG - 2011-08-23 18:56:54 --> UTF-8 Support Enabled
DEBUG - 2011-08-23 18:56:54 --> URI Class Initialized
DEBUG - 2011-08-23 18:56:54 --> Router Class Initialized
ERROR - 2011-08-23 18:56:54 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-23 19:22:16 --> Config Class Initialized
DEBUG - 2011-08-23 19:22:16 --> Hooks Class Initialized
DEBUG - 2011-08-23 19:22:16 --> Utf8 Class Initialized
DEBUG - 2011-08-23 19:22:16 --> UTF-8 Support Enabled
DEBUG - 2011-08-23 19:22:16 --> URI Class Initialized
DEBUG - 2011-08-23 19:22:16 --> Router Class Initialized
DEBUG - 2011-08-23 19:22:16 --> Output Class Initialized
DEBUG - 2011-08-23 19:22:16 --> Input Class Initialized
DEBUG - 2011-08-23 19:22:16 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-23 19:22:16 --> Language Class Initialized
DEBUG - 2011-08-23 19:22:16 --> Loader Class Initialized
DEBUG - 2011-08-23 19:22:16 --> Controller Class Initialized
ERROR - 2011-08-23 19:22:16 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-23 19:22:16 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-23 19:22:16 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-23 19:22:16 --> Model Class Initialized
DEBUG - 2011-08-23 19:22:16 --> Model Class Initialized
DEBUG - 2011-08-23 19:22:16 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-23 19:22:16 --> Database Driver Class Initialized
DEBUG - 2011-08-23 19:22:16 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-23 19:22:16 --> Helper loaded: url_helper
DEBUG - 2011-08-23 19:22:16 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-23 19:22:16 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-23 19:22:16 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-23 19:22:16 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-23 19:22:16 --> Final output sent to browser
DEBUG - 2011-08-23 19:22:16 --> Total execution time: 0.1007
DEBUG - 2011-08-23 19:22:18 --> Config Class Initialized
DEBUG - 2011-08-23 19:22:18 --> Hooks Class Initialized
DEBUG - 2011-08-23 19:22:18 --> Utf8 Class Initialized
DEBUG - 2011-08-23 19:22:18 --> UTF-8 Support Enabled
DEBUG - 2011-08-23 19:22:18 --> URI Class Initialized
DEBUG - 2011-08-23 19:22:18 --> Router Class Initialized
DEBUG - 2011-08-23 19:22:18 --> Output Class Initialized
DEBUG - 2011-08-23 19:22:18 --> Input Class Initialized
DEBUG - 2011-08-23 19:22:18 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-23 19:22:18 --> Language Class Initialized
DEBUG - 2011-08-23 19:22:18 --> Loader Class Initialized
DEBUG - 2011-08-23 19:22:18 --> Controller Class Initialized
DEBUG - 2011-08-23 19:22:18 --> Model Class Initialized
DEBUG - 2011-08-23 19:22:18 --> Model Class Initialized
DEBUG - 2011-08-23 19:22:18 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-23 19:22:18 --> Database Driver Class Initialized
DEBUG - 2011-08-23 19:22:18 --> Final output sent to browser
DEBUG - 2011-08-23 19:22:18 --> Total execution time: 0.7755
DEBUG - 2011-08-23 20:19:15 --> Config Class Initialized
DEBUG - 2011-08-23 20:19:15 --> Hooks Class Initialized
DEBUG - 2011-08-23 20:19:15 --> Utf8 Class Initialized
DEBUG - 2011-08-23 20:19:15 --> UTF-8 Support Enabled
DEBUG - 2011-08-23 20:19:15 --> URI Class Initialized
DEBUG - 2011-08-23 20:19:15 --> Router Class Initialized
DEBUG - 2011-08-23 20:19:15 --> Output Class Initialized
DEBUG - 2011-08-23 20:19:15 --> Input Class Initialized
DEBUG - 2011-08-23 20:19:15 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-23 20:19:15 --> Language Class Initialized
DEBUG - 2011-08-23 20:19:15 --> Loader Class Initialized
DEBUG - 2011-08-23 20:19:15 --> Controller Class Initialized
DEBUG - 2011-08-23 20:19:15 --> Model Class Initialized
DEBUG - 2011-08-23 20:19:15 --> Model Class Initialized
DEBUG - 2011-08-23 20:19:15 --> Model Class Initialized
DEBUG - 2011-08-23 20:19:15 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-23 20:19:15 --> Database Driver Class Initialized
DEBUG - 2011-08-23 20:19:15 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-23 20:19:15 --> Helper loaded: url_helper
DEBUG - 2011-08-23 20:19:15 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-23 20:19:15 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-23 20:19:15 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-23 20:19:15 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-23 20:19:15 --> Final output sent to browser
DEBUG - 2011-08-23 20:19:15 --> Total execution time: 0.5107
DEBUG - 2011-08-23 20:19:15 --> Config Class Initialized
DEBUG - 2011-08-23 20:19:15 --> Hooks Class Initialized
DEBUG - 2011-08-23 20:19:15 --> Utf8 Class Initialized
DEBUG - 2011-08-23 20:19:15 --> UTF-8 Support Enabled
DEBUG - 2011-08-23 20:19:15 --> URI Class Initialized
DEBUG - 2011-08-23 20:19:15 --> Router Class Initialized
DEBUG - 2011-08-23 20:19:15 --> Output Class Initialized
DEBUG - 2011-08-23 20:19:15 --> Input Class Initialized
DEBUG - 2011-08-23 20:19:15 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-23 20:19:15 --> Language Class Initialized
DEBUG - 2011-08-23 20:19:15 --> Loader Class Initialized
DEBUG - 2011-08-23 20:19:15 --> Controller Class Initialized
ERROR - 2011-08-23 20:19:15 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-23 20:19:15 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-23 20:19:15 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-23 20:19:15 --> Model Class Initialized
DEBUG - 2011-08-23 20:19:15 --> Model Class Initialized
DEBUG - 2011-08-23 20:19:15 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-23 20:19:15 --> Database Driver Class Initialized
DEBUG - 2011-08-23 20:19:16 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-23 20:19:16 --> Helper loaded: url_helper
DEBUG - 2011-08-23 20:19:16 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-23 20:19:16 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-23 20:19:16 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-23 20:19:16 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-23 20:19:16 --> Final output sent to browser
DEBUG - 2011-08-23 20:19:16 --> Total execution time: 0.0297
DEBUG - 2011-08-23 20:22:46 --> Config Class Initialized
DEBUG - 2011-08-23 20:22:46 --> Hooks Class Initialized
DEBUG - 2011-08-23 20:22:46 --> Utf8 Class Initialized
DEBUG - 2011-08-23 20:22:46 --> UTF-8 Support Enabled
DEBUG - 2011-08-23 20:22:46 --> URI Class Initialized
DEBUG - 2011-08-23 20:22:46 --> Router Class Initialized
DEBUG - 2011-08-23 20:22:46 --> Output Class Initialized
DEBUG - 2011-08-23 20:22:46 --> Input Class Initialized
DEBUG - 2011-08-23 20:22:46 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-23 20:22:46 --> Language Class Initialized
DEBUG - 2011-08-23 20:22:46 --> Loader Class Initialized
DEBUG - 2011-08-23 20:22:46 --> Controller Class Initialized
DEBUG - 2011-08-23 20:22:46 --> Model Class Initialized
DEBUG - 2011-08-23 20:22:46 --> Model Class Initialized
DEBUG - 2011-08-23 20:22:46 --> Model Class Initialized
DEBUG - 2011-08-23 20:22:46 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-23 20:22:46 --> Database Driver Class Initialized
DEBUG - 2011-08-23 20:22:46 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-23 20:22:46 --> Helper loaded: url_helper
DEBUG - 2011-08-23 20:22:46 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-23 20:22:46 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-23 20:22:46 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-23 20:22:46 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-23 20:22:46 --> Final output sent to browser
DEBUG - 2011-08-23 20:22:46 --> Total execution time: 0.0442
DEBUG - 2011-08-23 20:22:48 --> Config Class Initialized
DEBUG - 2011-08-23 20:22:48 --> Hooks Class Initialized
DEBUG - 2011-08-23 20:22:48 --> Utf8 Class Initialized
DEBUG - 2011-08-23 20:22:48 --> UTF-8 Support Enabled
DEBUG - 2011-08-23 20:22:48 --> URI Class Initialized
DEBUG - 2011-08-23 20:22:48 --> Router Class Initialized
ERROR - 2011-08-23 20:22:48 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-23 20:22:49 --> Config Class Initialized
DEBUG - 2011-08-23 20:22:49 --> Hooks Class Initialized
DEBUG - 2011-08-23 20:22:49 --> Utf8 Class Initialized
DEBUG - 2011-08-23 20:22:49 --> UTF-8 Support Enabled
DEBUG - 2011-08-23 20:22:49 --> URI Class Initialized
DEBUG - 2011-08-23 20:22:49 --> Router Class Initialized
ERROR - 2011-08-23 20:22:49 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-23 20:22:49 --> Config Class Initialized
DEBUG - 2011-08-23 20:22:49 --> Hooks Class Initialized
DEBUG - 2011-08-23 20:22:49 --> Utf8 Class Initialized
DEBUG - 2011-08-23 20:22:49 --> UTF-8 Support Enabled
DEBUG - 2011-08-23 20:22:49 --> URI Class Initialized
DEBUG - 2011-08-23 20:22:49 --> Router Class Initialized
ERROR - 2011-08-23 20:22:49 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-23 20:23:04 --> Config Class Initialized
DEBUG - 2011-08-23 20:23:04 --> Hooks Class Initialized
DEBUG - 2011-08-23 20:23:04 --> Utf8 Class Initialized
DEBUG - 2011-08-23 20:23:04 --> UTF-8 Support Enabled
DEBUG - 2011-08-23 20:23:04 --> URI Class Initialized
DEBUG - 2011-08-23 20:23:04 --> Router Class Initialized
DEBUG - 2011-08-23 20:23:04 --> Output Class Initialized
DEBUG - 2011-08-23 20:23:04 --> Input Class Initialized
DEBUG - 2011-08-23 20:23:04 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-23 20:23:04 --> Language Class Initialized
DEBUG - 2011-08-23 20:23:04 --> Loader Class Initialized
DEBUG - 2011-08-23 20:23:04 --> Controller Class Initialized
DEBUG - 2011-08-23 20:23:04 --> Model Class Initialized
DEBUG - 2011-08-23 20:23:04 --> Model Class Initialized
DEBUG - 2011-08-23 20:23:04 --> Model Class Initialized
DEBUG - 2011-08-23 20:23:04 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-23 20:23:04 --> Database Driver Class Initialized
DEBUG - 2011-08-23 20:23:04 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-23 20:23:04 --> Helper loaded: url_helper
DEBUG - 2011-08-23 20:23:04 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-23 20:23:04 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-23 20:23:04 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-23 20:23:04 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-23 20:23:04 --> Final output sent to browser
DEBUG - 2011-08-23 20:23:04 --> Total execution time: 0.3314
DEBUG - 2011-08-23 21:01:15 --> Config Class Initialized
DEBUG - 2011-08-23 21:01:15 --> Hooks Class Initialized
DEBUG - 2011-08-23 21:01:15 --> Utf8 Class Initialized
DEBUG - 2011-08-23 21:01:15 --> UTF-8 Support Enabled
DEBUG - 2011-08-23 21:01:15 --> URI Class Initialized
DEBUG - 2011-08-23 21:01:15 --> Router Class Initialized
DEBUG - 2011-08-23 21:01:15 --> Output Class Initialized
DEBUG - 2011-08-23 21:01:15 --> Input Class Initialized
DEBUG - 2011-08-23 21:01:15 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-23 21:01:15 --> Language Class Initialized
DEBUG - 2011-08-23 21:01:15 --> Loader Class Initialized
DEBUG - 2011-08-23 21:01:15 --> Controller Class Initialized
DEBUG - 2011-08-23 21:01:15 --> Model Class Initialized
DEBUG - 2011-08-23 21:01:15 --> Model Class Initialized
DEBUG - 2011-08-23 21:01:15 --> Model Class Initialized
DEBUG - 2011-08-23 21:01:15 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-23 21:01:15 --> Database Driver Class Initialized
DEBUG - 2011-08-23 21:01:16 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-23 21:01:16 --> Helper loaded: url_helper
DEBUG - 2011-08-23 21:01:16 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-23 21:01:16 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-23 21:01:16 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-23 21:01:16 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-23 21:01:16 --> Final output sent to browser
DEBUG - 2011-08-23 21:01:16 --> Total execution time: 0.5787
DEBUG - 2011-08-23 21:01:18 --> Config Class Initialized
DEBUG - 2011-08-23 21:01:18 --> Hooks Class Initialized
DEBUG - 2011-08-23 21:01:18 --> Utf8 Class Initialized
DEBUG - 2011-08-23 21:01:18 --> UTF-8 Support Enabled
DEBUG - 2011-08-23 21:01:18 --> URI Class Initialized
DEBUG - 2011-08-23 21:01:18 --> Router Class Initialized
ERROR - 2011-08-23 21:01:18 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-23 21:01:53 --> Config Class Initialized
DEBUG - 2011-08-23 21:01:53 --> Hooks Class Initialized
DEBUG - 2011-08-23 21:01:53 --> Utf8 Class Initialized
DEBUG - 2011-08-23 21:01:53 --> UTF-8 Support Enabled
DEBUG - 2011-08-23 21:01:53 --> URI Class Initialized
DEBUG - 2011-08-23 21:01:53 --> Router Class Initialized
DEBUG - 2011-08-23 21:01:53 --> Output Class Initialized
DEBUG - 2011-08-23 21:01:53 --> Input Class Initialized
DEBUG - 2011-08-23 21:01:53 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-23 21:01:53 --> Language Class Initialized
DEBUG - 2011-08-23 21:01:53 --> Loader Class Initialized
DEBUG - 2011-08-23 21:01:53 --> Controller Class Initialized
DEBUG - 2011-08-23 21:01:53 --> Model Class Initialized
DEBUG - 2011-08-23 21:01:53 --> Model Class Initialized
DEBUG - 2011-08-23 21:01:53 --> Model Class Initialized
DEBUG - 2011-08-23 21:01:53 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-23 21:01:53 --> Database Driver Class Initialized
DEBUG - 2011-08-23 21:01:53 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-23 21:01:53 --> Helper loaded: url_helper
DEBUG - 2011-08-23 21:01:53 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-23 21:01:53 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-23 21:01:53 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-23 21:01:53 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-23 21:01:53 --> Final output sent to browser
DEBUG - 2011-08-23 21:01:53 --> Total execution time: 0.2047
DEBUG - 2011-08-23 21:01:55 --> Config Class Initialized
DEBUG - 2011-08-23 21:01:55 --> Hooks Class Initialized
DEBUG - 2011-08-23 21:01:55 --> Utf8 Class Initialized
DEBUG - 2011-08-23 21:01:55 --> UTF-8 Support Enabled
DEBUG - 2011-08-23 21:01:55 --> URI Class Initialized
DEBUG - 2011-08-23 21:01:55 --> Router Class Initialized
ERROR - 2011-08-23 21:01:55 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-23 21:02:15 --> Config Class Initialized
DEBUG - 2011-08-23 21:02:15 --> Hooks Class Initialized
DEBUG - 2011-08-23 21:02:15 --> Utf8 Class Initialized
DEBUG - 2011-08-23 21:02:15 --> UTF-8 Support Enabled
DEBUG - 2011-08-23 21:02:15 --> URI Class Initialized
DEBUG - 2011-08-23 21:02:15 --> Router Class Initialized
DEBUG - 2011-08-23 21:02:15 --> Output Class Initialized
DEBUG - 2011-08-23 21:02:15 --> Input Class Initialized
DEBUG - 2011-08-23 21:02:15 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-23 21:02:15 --> Language Class Initialized
DEBUG - 2011-08-23 21:02:15 --> Loader Class Initialized
DEBUG - 2011-08-23 21:02:15 --> Controller Class Initialized
DEBUG - 2011-08-23 21:02:15 --> Model Class Initialized
DEBUG - 2011-08-23 21:02:15 --> Model Class Initialized
DEBUG - 2011-08-23 21:02:15 --> Model Class Initialized
DEBUG - 2011-08-23 21:02:15 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-23 21:02:15 --> Database Driver Class Initialized
DEBUG - 2011-08-23 21:02:16 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-23 21:02:16 --> Helper loaded: url_helper
DEBUG - 2011-08-23 21:02:16 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-23 21:02:16 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-23 21:02:16 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-23 21:02:16 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-23 21:02:16 --> Final output sent to browser
DEBUG - 2011-08-23 21:02:16 --> Total execution time: 0.5075
DEBUG - 2011-08-23 21:02:17 --> Config Class Initialized
DEBUG - 2011-08-23 21:02:17 --> Hooks Class Initialized
DEBUG - 2011-08-23 21:02:17 --> Utf8 Class Initialized
DEBUG - 2011-08-23 21:02:17 --> UTF-8 Support Enabled
DEBUG - 2011-08-23 21:02:17 --> URI Class Initialized
DEBUG - 2011-08-23 21:02:17 --> Router Class Initialized
ERROR - 2011-08-23 21:02:17 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-23 21:53:20 --> Config Class Initialized
DEBUG - 2011-08-23 21:53:20 --> Hooks Class Initialized
DEBUG - 2011-08-23 21:53:20 --> Utf8 Class Initialized
DEBUG - 2011-08-23 21:53:20 --> UTF-8 Support Enabled
DEBUG - 2011-08-23 21:53:20 --> URI Class Initialized
DEBUG - 2011-08-23 21:53:20 --> Router Class Initialized
DEBUG - 2011-08-23 21:53:20 --> Output Class Initialized
DEBUG - 2011-08-23 21:53:20 --> Input Class Initialized
DEBUG - 2011-08-23 21:53:20 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-23 21:53:20 --> Language Class Initialized
DEBUG - 2011-08-23 21:53:20 --> Loader Class Initialized
DEBUG - 2011-08-23 21:53:20 --> Controller Class Initialized
DEBUG - 2011-08-23 21:53:20 --> Model Class Initialized
DEBUG - 2011-08-23 21:53:20 --> Model Class Initialized
DEBUG - 2011-08-23 21:53:20 --> Model Class Initialized
DEBUG - 2011-08-23 21:53:20 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-23 21:53:20 --> Database Driver Class Initialized
DEBUG - 2011-08-23 21:53:21 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-23 21:53:21 --> Helper loaded: url_helper
DEBUG - 2011-08-23 21:53:21 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-23 21:53:21 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-23 21:53:21 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-23 21:53:21 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-23 21:53:21 --> Final output sent to browser
DEBUG - 2011-08-23 21:53:21 --> Total execution time: 0.3328
DEBUG - 2011-08-23 21:53:22 --> Config Class Initialized
DEBUG - 2011-08-23 21:53:22 --> Hooks Class Initialized
DEBUG - 2011-08-23 21:53:22 --> Utf8 Class Initialized
DEBUG - 2011-08-23 21:53:22 --> UTF-8 Support Enabled
DEBUG - 2011-08-23 21:53:22 --> URI Class Initialized
DEBUG - 2011-08-23 21:53:22 --> Router Class Initialized
ERROR - 2011-08-23 21:53:22 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-23 21:53:25 --> Config Class Initialized
DEBUG - 2011-08-23 21:53:25 --> Hooks Class Initialized
DEBUG - 2011-08-23 21:53:25 --> Utf8 Class Initialized
DEBUG - 2011-08-23 21:53:25 --> UTF-8 Support Enabled
DEBUG - 2011-08-23 21:53:25 --> URI Class Initialized
DEBUG - 2011-08-23 21:53:25 --> Router Class Initialized
ERROR - 2011-08-23 21:53:25 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-23 22:00:30 --> Config Class Initialized
DEBUG - 2011-08-23 22:00:30 --> Hooks Class Initialized
DEBUG - 2011-08-23 22:00:30 --> Utf8 Class Initialized
DEBUG - 2011-08-23 22:00:30 --> UTF-8 Support Enabled
DEBUG - 2011-08-23 22:00:30 --> URI Class Initialized
DEBUG - 2011-08-23 22:00:30 --> Router Class Initialized
DEBUG - 2011-08-23 22:00:30 --> Output Class Initialized
DEBUG - 2011-08-23 22:00:30 --> Input Class Initialized
DEBUG - 2011-08-23 22:00:30 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-23 22:00:30 --> Language Class Initialized
DEBUG - 2011-08-23 22:00:30 --> Loader Class Initialized
DEBUG - 2011-08-23 22:00:30 --> Controller Class Initialized
DEBUG - 2011-08-23 22:00:30 --> Model Class Initialized
DEBUG - 2011-08-23 22:00:30 --> Model Class Initialized
DEBUG - 2011-08-23 22:00:30 --> Model Class Initialized
DEBUG - 2011-08-23 22:00:30 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-23 22:00:30 --> Database Driver Class Initialized
DEBUG - 2011-08-23 22:00:30 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-23 22:00:30 --> Helper loaded: url_helper
DEBUG - 2011-08-23 22:00:30 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-23 22:00:30 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-23 22:00:30 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-23 22:00:30 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-23 22:00:30 --> Final output sent to browser
DEBUG - 2011-08-23 22:00:30 --> Total execution time: 0.0705
DEBUG - 2011-08-23 22:24:05 --> Config Class Initialized
DEBUG - 2011-08-23 22:24:05 --> Hooks Class Initialized
DEBUG - 2011-08-23 22:24:05 --> Utf8 Class Initialized
DEBUG - 2011-08-23 22:24:05 --> UTF-8 Support Enabled
DEBUG - 2011-08-23 22:24:05 --> URI Class Initialized
DEBUG - 2011-08-23 22:24:05 --> Router Class Initialized
ERROR - 2011-08-23 22:24:05 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-08-23 22:45:03 --> Config Class Initialized
DEBUG - 2011-08-23 22:45:03 --> Hooks Class Initialized
DEBUG - 2011-08-23 22:45:03 --> Utf8 Class Initialized
DEBUG - 2011-08-23 22:45:03 --> UTF-8 Support Enabled
DEBUG - 2011-08-23 22:45:03 --> URI Class Initialized
DEBUG - 2011-08-23 22:45:03 --> Router Class Initialized
DEBUG - 2011-08-23 22:45:03 --> No URI present. Default controller set.
DEBUG - 2011-08-23 22:45:03 --> Output Class Initialized
DEBUG - 2011-08-23 22:45:03 --> Input Class Initialized
DEBUG - 2011-08-23 22:45:03 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-23 22:45:03 --> Language Class Initialized
DEBUG - 2011-08-23 22:45:03 --> Loader Class Initialized
DEBUG - 2011-08-23 22:45:03 --> Controller Class Initialized
DEBUG - 2011-08-23 22:45:04 --> File loaded: application/views/splash/main.php
DEBUG - 2011-08-23 22:45:04 --> Helper loaded: url_helper
DEBUG - 2011-08-23 22:45:04 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-23 22:45:04 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-23 22:45:04 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-23 22:45:04 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-23 22:45:04 --> Final output sent to browser
DEBUG - 2011-08-23 22:45:04 --> Total execution time: 0.1734
DEBUG - 2011-08-23 22:50:48 --> Config Class Initialized
DEBUG - 2011-08-23 22:50:48 --> Hooks Class Initialized
DEBUG - 2011-08-23 22:50:48 --> Utf8 Class Initialized
DEBUG - 2011-08-23 22:50:48 --> UTF-8 Support Enabled
DEBUG - 2011-08-23 22:50:48 --> URI Class Initialized
DEBUG - 2011-08-23 22:50:48 --> Router Class Initialized
DEBUG - 2011-08-23 22:50:48 --> Output Class Initialized
DEBUG - 2011-08-23 22:50:48 --> Input Class Initialized
DEBUG - 2011-08-23 22:50:48 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-23 22:50:48 --> Language Class Initialized
DEBUG - 2011-08-23 22:50:48 --> Loader Class Initialized
DEBUG - 2011-08-23 22:50:48 --> Controller Class Initialized
ERROR - 2011-08-23 22:50:48 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-23 22:50:48 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-23 22:50:48 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-23 22:50:48 --> Model Class Initialized
DEBUG - 2011-08-23 22:50:48 --> Model Class Initialized
DEBUG - 2011-08-23 22:50:48 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-23 22:50:48 --> Database Driver Class Initialized
DEBUG - 2011-08-23 22:50:48 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-23 22:50:48 --> Helper loaded: url_helper
DEBUG - 2011-08-23 22:50:48 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-23 22:50:48 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-23 22:50:48 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-23 22:50:48 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-23 22:50:48 --> Final output sent to browser
DEBUG - 2011-08-23 22:50:48 --> Total execution time: 0.0779
DEBUG - 2011-08-23 22:50:50 --> Config Class Initialized
DEBUG - 2011-08-23 22:50:50 --> Hooks Class Initialized
DEBUG - 2011-08-23 22:50:50 --> Utf8 Class Initialized
DEBUG - 2011-08-23 22:50:50 --> UTF-8 Support Enabled
DEBUG - 2011-08-23 22:50:50 --> URI Class Initialized
DEBUG - 2011-08-23 22:50:50 --> Router Class Initialized
DEBUG - 2011-08-23 22:50:50 --> Output Class Initialized
DEBUG - 2011-08-23 22:50:50 --> Input Class Initialized
DEBUG - 2011-08-23 22:50:50 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-23 22:50:50 --> Language Class Initialized
DEBUG - 2011-08-23 22:50:50 --> Loader Class Initialized
DEBUG - 2011-08-23 22:50:50 --> Controller Class Initialized
DEBUG - 2011-08-23 22:50:50 --> Model Class Initialized
DEBUG - 2011-08-23 22:50:50 --> Model Class Initialized
DEBUG - 2011-08-23 22:50:50 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-23 22:50:50 --> Database Driver Class Initialized
DEBUG - 2011-08-23 22:50:51 --> Final output sent to browser
DEBUG - 2011-08-23 22:50:51 --> Total execution time: 0.8185
DEBUG - 2011-08-23 22:50:54 --> Config Class Initialized
DEBUG - 2011-08-23 22:50:54 --> Hooks Class Initialized
DEBUG - 2011-08-23 22:50:54 --> Utf8 Class Initialized
DEBUG - 2011-08-23 22:50:54 --> UTF-8 Support Enabled
DEBUG - 2011-08-23 22:50:54 --> URI Class Initialized
DEBUG - 2011-08-23 22:50:54 --> Router Class Initialized
ERROR - 2011-08-23 22:50:54 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-23 22:59:13 --> Config Class Initialized
DEBUG - 2011-08-23 22:59:13 --> Hooks Class Initialized
DEBUG - 2011-08-23 22:59:13 --> Utf8 Class Initialized
DEBUG - 2011-08-23 22:59:13 --> UTF-8 Support Enabled
DEBUG - 2011-08-23 22:59:13 --> URI Class Initialized
DEBUG - 2011-08-23 22:59:13 --> Router Class Initialized
DEBUG - 2011-08-23 22:59:13 --> Output Class Initialized
DEBUG - 2011-08-23 22:59:13 --> Input Class Initialized
DEBUG - 2011-08-23 22:59:13 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-23 22:59:13 --> Language Class Initialized
DEBUG - 2011-08-23 22:59:13 --> Loader Class Initialized
DEBUG - 2011-08-23 22:59:13 --> Controller Class Initialized
DEBUG - 2011-08-23 22:59:13 --> Model Class Initialized
DEBUG - 2011-08-23 22:59:13 --> Model Class Initialized
DEBUG - 2011-08-23 22:59:13 --> Model Class Initialized
DEBUG - 2011-08-23 22:59:13 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-23 22:59:13 --> Database Driver Class Initialized
DEBUG - 2011-08-23 22:59:13 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-23 22:59:13 --> Helper loaded: url_helper
DEBUG - 2011-08-23 22:59:13 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-23 22:59:13 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-23 22:59:13 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-23 22:59:13 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-23 22:59:13 --> Final output sent to browser
DEBUG - 2011-08-23 22:59:13 --> Total execution time: 0.2857
DEBUG - 2011-08-23 22:59:15 --> Config Class Initialized
DEBUG - 2011-08-23 22:59:15 --> Hooks Class Initialized
DEBUG - 2011-08-23 22:59:15 --> Utf8 Class Initialized
DEBUG - 2011-08-23 22:59:15 --> UTF-8 Support Enabled
DEBUG - 2011-08-23 22:59:15 --> URI Class Initialized
DEBUG - 2011-08-23 22:59:15 --> Router Class Initialized
ERROR - 2011-08-23 22:59:15 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-23 22:59:15 --> Config Class Initialized
DEBUG - 2011-08-23 22:59:15 --> Hooks Class Initialized
DEBUG - 2011-08-23 22:59:15 --> Utf8 Class Initialized
DEBUG - 2011-08-23 22:59:15 --> UTF-8 Support Enabled
DEBUG - 2011-08-23 22:59:15 --> URI Class Initialized
DEBUG - 2011-08-23 22:59:15 --> Router Class Initialized
ERROR - 2011-08-23 22:59:15 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-23 22:59:16 --> Config Class Initialized
DEBUG - 2011-08-23 22:59:16 --> Hooks Class Initialized
DEBUG - 2011-08-23 22:59:16 --> Utf8 Class Initialized
DEBUG - 2011-08-23 22:59:16 --> UTF-8 Support Enabled
DEBUG - 2011-08-23 22:59:16 --> URI Class Initialized
DEBUG - 2011-08-23 22:59:16 --> Router Class Initialized
ERROR - 2011-08-23 22:59:16 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-23 22:59:37 --> Config Class Initialized
DEBUG - 2011-08-23 22:59:37 --> Hooks Class Initialized
DEBUG - 2011-08-23 22:59:37 --> Utf8 Class Initialized
DEBUG - 2011-08-23 22:59:37 --> UTF-8 Support Enabled
DEBUG - 2011-08-23 22:59:37 --> URI Class Initialized
DEBUG - 2011-08-23 22:59:37 --> Router Class Initialized
DEBUG - 2011-08-23 22:59:37 --> Output Class Initialized
DEBUG - 2011-08-23 22:59:37 --> Input Class Initialized
DEBUG - 2011-08-23 22:59:37 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-23 22:59:37 --> Language Class Initialized
DEBUG - 2011-08-23 22:59:37 --> Loader Class Initialized
DEBUG - 2011-08-23 22:59:37 --> Controller Class Initialized
DEBUG - 2011-08-23 22:59:37 --> Model Class Initialized
DEBUG - 2011-08-23 22:59:37 --> Model Class Initialized
DEBUG - 2011-08-23 22:59:37 --> Model Class Initialized
DEBUG - 2011-08-23 22:59:37 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-23 22:59:37 --> Database Driver Class Initialized
DEBUG - 2011-08-23 22:59:38 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-23 22:59:38 --> Helper loaded: url_helper
DEBUG - 2011-08-23 22:59:38 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-23 22:59:38 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-23 22:59:38 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-23 22:59:38 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-23 22:59:38 --> Final output sent to browser
DEBUG - 2011-08-23 22:59:38 --> Total execution time: 0.2415
DEBUG - 2011-08-23 22:59:39 --> Config Class Initialized
DEBUG - 2011-08-23 22:59:39 --> Hooks Class Initialized
DEBUG - 2011-08-23 22:59:39 --> Utf8 Class Initialized
DEBUG - 2011-08-23 22:59:39 --> UTF-8 Support Enabled
DEBUG - 2011-08-23 22:59:39 --> URI Class Initialized
DEBUG - 2011-08-23 22:59:39 --> Router Class Initialized
DEBUG - 2011-08-23 22:59:39 --> Output Class Initialized
DEBUG - 2011-08-23 22:59:39 --> Input Class Initialized
DEBUG - 2011-08-23 22:59:39 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-23 22:59:39 --> Language Class Initialized
DEBUG - 2011-08-23 22:59:39 --> Loader Class Initialized
DEBUG - 2011-08-23 22:59:39 --> Controller Class Initialized
DEBUG - 2011-08-23 22:59:39 --> Model Class Initialized
DEBUG - 2011-08-23 22:59:39 --> Model Class Initialized
DEBUG - 2011-08-23 22:59:39 --> Model Class Initialized
DEBUG - 2011-08-23 22:59:39 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-23 22:59:39 --> Database Driver Class Initialized
DEBUG - 2011-08-23 22:59:39 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-23 22:59:39 --> Helper loaded: url_helper
DEBUG - 2011-08-23 22:59:39 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-23 22:59:39 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-23 22:59:39 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-23 22:59:39 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-23 22:59:39 --> Final output sent to browser
DEBUG - 2011-08-23 22:59:39 --> Total execution time: 0.0485
DEBUG - 2011-08-23 23:18:48 --> Config Class Initialized
DEBUG - 2011-08-23 23:18:48 --> Hooks Class Initialized
DEBUG - 2011-08-23 23:18:48 --> Utf8 Class Initialized
DEBUG - 2011-08-23 23:18:48 --> UTF-8 Support Enabled
DEBUG - 2011-08-23 23:18:48 --> URI Class Initialized
DEBUG - 2011-08-23 23:18:48 --> Router Class Initialized
DEBUG - 2011-08-23 23:18:48 --> Output Class Initialized
DEBUG - 2011-08-23 23:18:48 --> Input Class Initialized
DEBUG - 2011-08-23 23:18:48 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-23 23:18:48 --> Language Class Initialized
DEBUG - 2011-08-23 23:18:48 --> Loader Class Initialized
DEBUG - 2011-08-23 23:18:48 --> Controller Class Initialized
DEBUG - 2011-08-23 23:18:48 --> Model Class Initialized
DEBUG - 2011-08-23 23:18:48 --> Model Class Initialized
DEBUG - 2011-08-23 23:18:48 --> Model Class Initialized
DEBUG - 2011-08-23 23:18:48 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-23 23:18:48 --> Database Driver Class Initialized
DEBUG - 2011-08-23 23:18:48 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-23 23:18:48 --> Helper loaded: url_helper
DEBUG - 2011-08-23 23:18:48 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-23 23:18:48 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-23 23:18:48 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-23 23:18:48 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-23 23:18:48 --> Final output sent to browser
DEBUG - 2011-08-23 23:18:48 --> Total execution time: 0.2725
DEBUG - 2011-08-23 23:19:34 --> Config Class Initialized
DEBUG - 2011-08-23 23:19:34 --> Hooks Class Initialized
DEBUG - 2011-08-23 23:19:34 --> Utf8 Class Initialized
DEBUG - 2011-08-23 23:19:34 --> UTF-8 Support Enabled
DEBUG - 2011-08-23 23:19:34 --> URI Class Initialized
DEBUG - 2011-08-23 23:19:34 --> Router Class Initialized
ERROR - 2011-08-23 23:19:34 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-23 23:19:35 --> Config Class Initialized
DEBUG - 2011-08-23 23:19:35 --> Hooks Class Initialized
DEBUG - 2011-08-23 23:19:35 --> Utf8 Class Initialized
DEBUG - 2011-08-23 23:19:35 --> UTF-8 Support Enabled
DEBUG - 2011-08-23 23:19:35 --> URI Class Initialized
DEBUG - 2011-08-23 23:19:35 --> Router Class Initialized
ERROR - 2011-08-23 23:19:35 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-23 23:19:36 --> Config Class Initialized
DEBUG - 2011-08-23 23:19:36 --> Hooks Class Initialized
DEBUG - 2011-08-23 23:19:36 --> Utf8 Class Initialized
DEBUG - 2011-08-23 23:19:36 --> UTF-8 Support Enabled
DEBUG - 2011-08-23 23:19:36 --> URI Class Initialized
DEBUG - 2011-08-23 23:19:36 --> Router Class Initialized
ERROR - 2011-08-23 23:19:36 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-23 23:19:38 --> Config Class Initialized
DEBUG - 2011-08-23 23:19:38 --> Hooks Class Initialized
DEBUG - 2011-08-23 23:19:38 --> Utf8 Class Initialized
DEBUG - 2011-08-23 23:19:38 --> UTF-8 Support Enabled
DEBUG - 2011-08-23 23:19:38 --> URI Class Initialized
DEBUG - 2011-08-23 23:19:38 --> Router Class Initialized
DEBUG - 2011-08-23 23:19:38 --> Output Class Initialized
DEBUG - 2011-08-23 23:19:38 --> Input Class Initialized
DEBUG - 2011-08-23 23:19:38 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-23 23:19:38 --> Language Class Initialized
DEBUG - 2011-08-23 23:19:38 --> Loader Class Initialized
DEBUG - 2011-08-23 23:19:38 --> Controller Class Initialized
DEBUG - 2011-08-23 23:19:38 --> Model Class Initialized
DEBUG - 2011-08-23 23:19:38 --> Model Class Initialized
DEBUG - 2011-08-23 23:19:38 --> Model Class Initialized
DEBUG - 2011-08-23 23:19:38 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-23 23:19:38 --> Database Driver Class Initialized
DEBUG - 2011-08-23 23:19:39 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-23 23:19:39 --> Helper loaded: url_helper
DEBUG - 2011-08-23 23:19:39 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-23 23:19:39 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-23 23:19:39 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-23 23:19:39 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-23 23:19:39 --> Final output sent to browser
DEBUG - 2011-08-23 23:19:39 --> Total execution time: 0.1555
DEBUG - 2011-08-23 23:19:41 --> Config Class Initialized
DEBUG - 2011-08-23 23:19:41 --> Hooks Class Initialized
DEBUG - 2011-08-23 23:19:41 --> Utf8 Class Initialized
DEBUG - 2011-08-23 23:19:41 --> UTF-8 Support Enabled
DEBUG - 2011-08-23 23:19:41 --> URI Class Initialized
DEBUG - 2011-08-23 23:19:41 --> Router Class Initialized
DEBUG - 2011-08-23 23:19:41 --> Output Class Initialized
DEBUG - 2011-08-23 23:19:41 --> Input Class Initialized
DEBUG - 2011-08-23 23:19:41 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-23 23:19:41 --> Language Class Initialized
DEBUG - 2011-08-23 23:19:41 --> Loader Class Initialized
DEBUG - 2011-08-23 23:19:41 --> Controller Class Initialized
DEBUG - 2011-08-23 23:19:41 --> Model Class Initialized
DEBUG - 2011-08-23 23:19:41 --> Model Class Initialized
DEBUG - 2011-08-23 23:19:41 --> Model Class Initialized
DEBUG - 2011-08-23 23:19:41 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-23 23:19:41 --> Database Driver Class Initialized
DEBUG - 2011-08-23 23:19:41 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-23 23:19:41 --> Helper loaded: url_helper
DEBUG - 2011-08-23 23:19:41 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-23 23:19:41 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-23 23:19:41 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-23 23:19:41 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-23 23:19:41 --> Final output sent to browser
DEBUG - 2011-08-23 23:19:41 --> Total execution time: 0.1420
DEBUG - 2011-08-23 23:33:15 --> Config Class Initialized
DEBUG - 2011-08-23 23:33:15 --> Hooks Class Initialized
DEBUG - 2011-08-23 23:33:15 --> Utf8 Class Initialized
DEBUG - 2011-08-23 23:33:15 --> UTF-8 Support Enabled
DEBUG - 2011-08-23 23:33:15 --> URI Class Initialized
DEBUG - 2011-08-23 23:33:15 --> Router Class Initialized
DEBUG - 2011-08-23 23:33:15 --> Output Class Initialized
DEBUG - 2011-08-23 23:33:15 --> Input Class Initialized
DEBUG - 2011-08-23 23:33:15 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-23 23:33:15 --> Language Class Initialized
DEBUG - 2011-08-23 23:33:15 --> Loader Class Initialized
DEBUG - 2011-08-23 23:33:15 --> Controller Class Initialized
DEBUG - 2011-08-23 23:33:15 --> Model Class Initialized
DEBUG - 2011-08-23 23:33:15 --> Model Class Initialized
DEBUG - 2011-08-23 23:33:15 --> Model Class Initialized
DEBUG - 2011-08-23 23:33:15 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-23 23:33:15 --> Database Driver Class Initialized
DEBUG - 2011-08-23 23:33:15 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-23 23:33:15 --> Helper loaded: url_helper
DEBUG - 2011-08-23 23:33:15 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-23 23:33:15 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-23 23:33:15 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-23 23:33:15 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-23 23:33:15 --> Final output sent to browser
DEBUG - 2011-08-23 23:33:15 --> Total execution time: 0.0851

<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2011-10-09 04:27:34 --> Config Class Initialized
DEBUG - 2011-10-09 04:27:34 --> Hooks Class Initialized
DEBUG - 2011-10-09 04:27:34 --> Utf8 Class Initialized
DEBUG - 2011-10-09 04:27:34 --> UTF-8 Support Enabled
DEBUG - 2011-10-09 04:27:34 --> URI Class Initialized
DEBUG - 2011-10-09 04:27:34 --> Router Class Initialized
DEBUG - 2011-10-09 04:27:34 --> Output Class Initialized
DEBUG - 2011-10-09 04:27:34 --> Input Class Initialized
DEBUG - 2011-10-09 04:27:34 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-09 04:27:34 --> Language Class Initialized
DEBUG - 2011-10-09 04:27:34 --> Loader Class Initialized
DEBUG - 2011-10-09 04:27:34 --> Controller Class Initialized
DEBUG - 2011-10-09 04:27:34 --> Model Class Initialized
DEBUG - 2011-10-09 04:27:34 --> Model Class Initialized
DEBUG - 2011-10-09 04:27:34 --> Model Class Initialized
DEBUG - 2011-10-09 04:27:34 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-09 04:27:34 --> Database Driver Class Initialized
DEBUG - 2011-10-09 04:27:35 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-09 04:27:35 --> Helper loaded: url_helper
DEBUG - 2011-10-09 04:27:35 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-09 04:27:35 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-09 04:27:35 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-09 04:27:35 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-09 04:27:35 --> Final output sent to browser
DEBUG - 2011-10-09 04:27:35 --> Total execution time: 1.4983
DEBUG - 2011-10-09 04:27:40 --> Config Class Initialized
DEBUG - 2011-10-09 04:27:40 --> Hooks Class Initialized
DEBUG - 2011-10-09 04:27:40 --> Utf8 Class Initialized
DEBUG - 2011-10-09 04:27:40 --> UTF-8 Support Enabled
DEBUG - 2011-10-09 04:27:40 --> URI Class Initialized
DEBUG - 2011-10-09 04:27:40 --> Router Class Initialized
ERROR - 2011-10-09 04:27:40 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-09 04:27:40 --> Config Class Initialized
DEBUG - 2011-10-09 04:27:40 --> Hooks Class Initialized
DEBUG - 2011-10-09 04:27:40 --> Utf8 Class Initialized
DEBUG - 2011-10-09 04:27:40 --> UTF-8 Support Enabled
DEBUG - 2011-10-09 04:27:40 --> URI Class Initialized
DEBUG - 2011-10-09 04:27:40 --> Router Class Initialized
ERROR - 2011-10-09 04:27:40 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-09 04:29:47 --> Config Class Initialized
DEBUG - 2011-10-09 04:29:47 --> Hooks Class Initialized
DEBUG - 2011-10-09 04:29:47 --> Utf8 Class Initialized
DEBUG - 2011-10-09 04:29:47 --> UTF-8 Support Enabled
DEBUG - 2011-10-09 04:29:47 --> URI Class Initialized
DEBUG - 2011-10-09 04:29:47 --> Router Class Initialized
DEBUG - 2011-10-09 04:29:47 --> Output Class Initialized
DEBUG - 2011-10-09 04:29:47 --> Input Class Initialized
DEBUG - 2011-10-09 04:29:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-09 04:29:47 --> Language Class Initialized
DEBUG - 2011-10-09 04:29:47 --> Loader Class Initialized
DEBUG - 2011-10-09 04:29:47 --> Controller Class Initialized
DEBUG - 2011-10-09 04:29:47 --> Model Class Initialized
DEBUG - 2011-10-09 04:29:47 --> Model Class Initialized
DEBUG - 2011-10-09 04:29:47 --> Model Class Initialized
DEBUG - 2011-10-09 04:29:47 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-09 04:29:47 --> Database Driver Class Initialized
DEBUG - 2011-10-09 04:29:47 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-09 04:29:47 --> Helper loaded: url_helper
DEBUG - 2011-10-09 04:29:47 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-09 04:29:47 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-09 04:29:47 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-09 04:29:47 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-09 04:29:47 --> Final output sent to browser
DEBUG - 2011-10-09 04:29:47 --> Total execution time: 0.0708
DEBUG - 2011-10-09 04:29:48 --> Config Class Initialized
DEBUG - 2011-10-09 04:29:48 --> Hooks Class Initialized
DEBUG - 2011-10-09 04:29:48 --> Utf8 Class Initialized
DEBUG - 2011-10-09 04:29:48 --> UTF-8 Support Enabled
DEBUG - 2011-10-09 04:29:48 --> URI Class Initialized
DEBUG - 2011-10-09 04:29:48 --> Router Class Initialized
DEBUG - 2011-10-09 04:29:48 --> Output Class Initialized
DEBUG - 2011-10-09 04:29:48 --> Input Class Initialized
DEBUG - 2011-10-09 04:29:48 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-09 04:29:48 --> Language Class Initialized
DEBUG - 2011-10-09 04:29:48 --> Loader Class Initialized
DEBUG - 2011-10-09 04:29:48 --> Controller Class Initialized
ERROR - 2011-10-09 04:29:48 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-10-09 04:29:48 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-10-09 04:29:48 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-09 04:29:48 --> Model Class Initialized
DEBUG - 2011-10-09 04:29:48 --> Model Class Initialized
DEBUG - 2011-10-09 04:29:48 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-09 04:29:48 --> Database Driver Class Initialized
DEBUG - 2011-10-09 04:29:48 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-09 04:29:48 --> Helper loaded: url_helper
DEBUG - 2011-10-09 04:29:48 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-09 04:29:48 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-09 04:29:48 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-09 04:29:48 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-09 04:29:48 --> Final output sent to browser
DEBUG - 2011-10-09 04:29:48 --> Total execution time: 0.0816
DEBUG - 2011-10-09 05:15:14 --> Config Class Initialized
DEBUG - 2011-10-09 05:15:14 --> Hooks Class Initialized
DEBUG - 2011-10-09 05:15:14 --> Utf8 Class Initialized
DEBUG - 2011-10-09 05:15:14 --> UTF-8 Support Enabled
DEBUG - 2011-10-09 05:15:14 --> URI Class Initialized
DEBUG - 2011-10-09 05:15:14 --> Router Class Initialized
ERROR - 2011-10-09 05:15:14 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-10-09 05:15:14 --> Config Class Initialized
DEBUG - 2011-10-09 05:15:14 --> Hooks Class Initialized
DEBUG - 2011-10-09 05:15:14 --> Utf8 Class Initialized
DEBUG - 2011-10-09 05:15:14 --> UTF-8 Support Enabled
DEBUG - 2011-10-09 05:15:14 --> URI Class Initialized
DEBUG - 2011-10-09 05:15:14 --> Router Class Initialized
DEBUG - 2011-10-09 05:15:14 --> Output Class Initialized
DEBUG - 2011-10-09 05:15:14 --> Input Class Initialized
DEBUG - 2011-10-09 05:15:14 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-09 05:15:14 --> Language Class Initialized
DEBUG - 2011-10-09 05:15:14 --> Loader Class Initialized
DEBUG - 2011-10-09 05:15:14 --> Controller Class Initialized
ERROR - 2011-10-09 05:15:14 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-10-09 05:15:14 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-10-09 05:15:14 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-09 05:15:14 --> Model Class Initialized
DEBUG - 2011-10-09 05:15:14 --> Model Class Initialized
DEBUG - 2011-10-09 05:15:14 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-09 05:15:14 --> Database Driver Class Initialized
DEBUG - 2011-10-09 05:15:14 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-09 05:15:14 --> Helper loaded: url_helper
DEBUG - 2011-10-09 05:15:14 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-09 05:15:14 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-09 05:15:14 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-09 05:15:14 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-09 05:15:14 --> Final output sent to browser
DEBUG - 2011-10-09 05:15:14 --> Total execution time: 0.5160
DEBUG - 2011-10-09 06:57:29 --> Config Class Initialized
DEBUG - 2011-10-09 06:57:29 --> Hooks Class Initialized
DEBUG - 2011-10-09 06:57:29 --> Utf8 Class Initialized
DEBUG - 2011-10-09 06:57:29 --> UTF-8 Support Enabled
DEBUG - 2011-10-09 06:57:29 --> URI Class Initialized
DEBUG - 2011-10-09 06:57:29 --> Router Class Initialized
DEBUG - 2011-10-09 06:57:29 --> No URI present. Default controller set.
DEBUG - 2011-10-09 06:57:29 --> Output Class Initialized
DEBUG - 2011-10-09 06:57:29 --> Input Class Initialized
DEBUG - 2011-10-09 06:57:29 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-09 06:57:29 --> Language Class Initialized
DEBUG - 2011-10-09 06:57:29 --> Loader Class Initialized
DEBUG - 2011-10-09 06:57:29 --> Controller Class Initialized
DEBUG - 2011-10-09 06:57:30 --> File loaded: application/views/splash/main.php
DEBUG - 2011-10-09 06:57:30 --> Helper loaded: url_helper
DEBUG - 2011-10-09 06:57:30 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-09 06:57:30 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-09 06:57:30 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-09 06:57:30 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-09 06:57:30 --> Final output sent to browser
DEBUG - 2011-10-09 06:57:30 --> Total execution time: 0.2326
DEBUG - 2011-10-09 09:04:03 --> Config Class Initialized
DEBUG - 2011-10-09 09:04:03 --> Hooks Class Initialized
DEBUG - 2011-10-09 09:04:03 --> Utf8 Class Initialized
DEBUG - 2011-10-09 09:04:03 --> UTF-8 Support Enabled
DEBUG - 2011-10-09 09:04:03 --> URI Class Initialized
DEBUG - 2011-10-09 09:04:03 --> Router Class Initialized
ERROR - 2011-10-09 09:04:03 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-10-09 09:05:08 --> Config Class Initialized
DEBUG - 2011-10-09 09:05:08 --> Hooks Class Initialized
DEBUG - 2011-10-09 09:05:08 --> Utf8 Class Initialized
DEBUG - 2011-10-09 09:05:08 --> UTF-8 Support Enabled
DEBUG - 2011-10-09 09:05:08 --> URI Class Initialized
DEBUG - 2011-10-09 09:05:08 --> Router Class Initialized
DEBUG - 2011-10-09 09:05:08 --> Output Class Initialized
DEBUG - 2011-10-09 09:05:08 --> Input Class Initialized
DEBUG - 2011-10-09 09:05:08 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-09 09:05:08 --> Language Class Initialized
DEBUG - 2011-10-09 09:05:08 --> Loader Class Initialized
DEBUG - 2011-10-09 09:05:08 --> Controller Class Initialized
DEBUG - 2011-10-09 09:05:08 --> Model Class Initialized
DEBUG - 2011-10-09 09:05:08 --> Model Class Initialized
DEBUG - 2011-10-09 09:05:08 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-09 09:05:08 --> Database Driver Class Initialized
DEBUG - 2011-10-09 09:05:09 --> Final output sent to browser
DEBUG - 2011-10-09 09:05:09 --> Total execution time: 1.5184
DEBUG - 2011-10-09 09:15:38 --> Config Class Initialized
DEBUG - 2011-10-09 09:15:38 --> Hooks Class Initialized
DEBUG - 2011-10-09 09:15:38 --> Utf8 Class Initialized
DEBUG - 2011-10-09 09:15:38 --> UTF-8 Support Enabled
DEBUG - 2011-10-09 09:15:38 --> URI Class Initialized
DEBUG - 2011-10-09 09:15:38 --> Router Class Initialized
DEBUG - 2011-10-09 09:15:38 --> Output Class Initialized
DEBUG - 2011-10-09 09:15:38 --> Input Class Initialized
DEBUG - 2011-10-09 09:15:38 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-09 09:15:38 --> Language Class Initialized
DEBUG - 2011-10-09 09:15:38 --> Loader Class Initialized
DEBUG - 2011-10-09 09:15:38 --> Controller Class Initialized
DEBUG - 2011-10-09 09:15:38 --> Model Class Initialized
DEBUG - 2011-10-09 09:15:38 --> Model Class Initialized
DEBUG - 2011-10-09 09:15:38 --> Model Class Initialized
DEBUG - 2011-10-09 09:15:38 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-09 09:15:38 --> Database Driver Class Initialized
DEBUG - 2011-10-09 09:15:39 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-09 09:15:39 --> Helper loaded: url_helper
DEBUG - 2011-10-09 09:15:39 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-09 09:15:39 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-09 09:15:39 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-09 09:15:39 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-09 09:15:39 --> Final output sent to browser
DEBUG - 2011-10-09 09:15:39 --> Total execution time: 1.0089
DEBUG - 2011-10-09 09:15:40 --> Config Class Initialized
DEBUG - 2011-10-09 09:15:40 --> Hooks Class Initialized
DEBUG - 2011-10-09 09:15:40 --> Utf8 Class Initialized
DEBUG - 2011-10-09 09:15:40 --> UTF-8 Support Enabled
DEBUG - 2011-10-09 09:15:40 --> URI Class Initialized
DEBUG - 2011-10-09 09:15:40 --> Router Class Initialized
DEBUG - 2011-10-09 09:15:40 --> Output Class Initialized
DEBUG - 2011-10-09 09:15:40 --> Input Class Initialized
DEBUG - 2011-10-09 09:15:40 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-09 09:15:40 --> Language Class Initialized
DEBUG - 2011-10-09 09:15:40 --> Loader Class Initialized
DEBUG - 2011-10-09 09:15:40 --> Controller Class Initialized
ERROR - 2011-10-09 09:15:40 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-10-09 09:15:40 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-10-09 09:15:40 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-09 09:15:40 --> Model Class Initialized
DEBUG - 2011-10-09 09:15:40 --> Model Class Initialized
DEBUG - 2011-10-09 09:15:40 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-09 09:15:40 --> Database Driver Class Initialized
DEBUG - 2011-10-09 09:15:40 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-09 09:15:40 --> Helper loaded: url_helper
DEBUG - 2011-10-09 09:15:40 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-09 09:15:40 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-09 09:15:40 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-09 09:15:40 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-09 09:15:40 --> Final output sent to browser
DEBUG - 2011-10-09 09:15:40 --> Total execution time: 0.0666
DEBUG - 2011-10-09 09:32:15 --> Config Class Initialized
DEBUG - 2011-10-09 09:32:15 --> Hooks Class Initialized
DEBUG - 2011-10-09 09:32:15 --> Utf8 Class Initialized
DEBUG - 2011-10-09 09:32:15 --> UTF-8 Support Enabled
DEBUG - 2011-10-09 09:32:15 --> URI Class Initialized
DEBUG - 2011-10-09 09:32:15 --> Router Class Initialized
DEBUG - 2011-10-09 09:32:15 --> No URI present. Default controller set.
DEBUG - 2011-10-09 09:32:15 --> Output Class Initialized
DEBUG - 2011-10-09 09:32:15 --> Input Class Initialized
DEBUG - 2011-10-09 09:32:15 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-09 09:32:15 --> Language Class Initialized
DEBUG - 2011-10-09 09:32:15 --> Loader Class Initialized
DEBUG - 2011-10-09 09:32:15 --> Controller Class Initialized
DEBUG - 2011-10-09 09:32:15 --> File loaded: application/views/splash/main.php
DEBUG - 2011-10-09 09:32:15 --> Helper loaded: url_helper
DEBUG - 2011-10-09 09:32:15 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-09 09:32:15 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-09 09:32:15 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-09 09:32:15 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-09 09:32:15 --> Final output sent to browser
DEBUG - 2011-10-09 09:32:15 --> Total execution time: 0.0595
DEBUG - 2011-10-09 09:51:35 --> Config Class Initialized
DEBUG - 2011-10-09 09:51:35 --> Hooks Class Initialized
DEBUG - 2011-10-09 09:51:35 --> Utf8 Class Initialized
DEBUG - 2011-10-09 09:51:35 --> UTF-8 Support Enabled
DEBUG - 2011-10-09 09:51:35 --> URI Class Initialized
DEBUG - 2011-10-09 09:51:35 --> Router Class Initialized
DEBUG - 2011-10-09 09:51:35 --> Output Class Initialized
DEBUG - 2011-10-09 09:51:35 --> Input Class Initialized
DEBUG - 2011-10-09 09:51:35 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-09 09:51:35 --> Language Class Initialized
DEBUG - 2011-10-09 09:51:35 --> Loader Class Initialized
DEBUG - 2011-10-09 09:51:35 --> Controller Class Initialized
DEBUG - 2011-10-09 09:51:35 --> Model Class Initialized
DEBUG - 2011-10-09 09:51:35 --> Model Class Initialized
DEBUG - 2011-10-09 09:51:35 --> Model Class Initialized
DEBUG - 2011-10-09 09:51:35 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-09 09:51:35 --> Database Driver Class Initialized
DEBUG - 2011-10-09 09:51:38 --> Config Class Initialized
DEBUG - 2011-10-09 09:51:38 --> Hooks Class Initialized
DEBUG - 2011-10-09 09:51:38 --> Utf8 Class Initialized
DEBUG - 2011-10-09 09:51:38 --> UTF-8 Support Enabled
DEBUG - 2011-10-09 09:51:38 --> URI Class Initialized
DEBUG - 2011-10-09 09:51:38 --> Router Class Initialized
DEBUG - 2011-10-09 09:51:38 --> Output Class Initialized
DEBUG - 2011-10-09 09:51:38 --> Input Class Initialized
DEBUG - 2011-10-09 09:51:38 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-09 09:51:38 --> Language Class Initialized
DEBUG - 2011-10-09 09:51:38 --> Loader Class Initialized
DEBUG - 2011-10-09 09:51:38 --> Controller Class Initialized
DEBUG - 2011-10-09 09:51:38 --> Model Class Initialized
DEBUG - 2011-10-09 09:51:38 --> Model Class Initialized
DEBUG - 2011-10-09 09:51:38 --> Model Class Initialized
DEBUG - 2011-10-09 09:51:38 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-09 09:51:38 --> Database Driver Class Initialized
DEBUG - 2011-10-09 09:51:38 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-09 09:51:38 --> Helper loaded: url_helper
DEBUG - 2011-10-09 09:51:38 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-09 09:51:38 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-09 09:51:38 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-09 09:51:38 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-09 09:51:38 --> Final output sent to browser
DEBUG - 2011-10-09 09:51:38 --> Total execution time: 0.6301
DEBUG - 2011-10-09 09:51:38 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-09 09:51:38 --> Helper loaded: url_helper
DEBUG - 2011-10-09 09:51:38 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-09 09:51:38 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-09 09:51:38 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-09 09:51:38 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-09 09:51:38 --> Final output sent to browser
DEBUG - 2011-10-09 09:51:38 --> Total execution time: 3.2185
DEBUG - 2011-10-09 09:51:44 --> Config Class Initialized
DEBUG - 2011-10-09 09:51:44 --> Hooks Class Initialized
DEBUG - 2011-10-09 09:51:44 --> Utf8 Class Initialized
DEBUG - 2011-10-09 09:51:44 --> UTF-8 Support Enabled
DEBUG - 2011-10-09 09:51:44 --> URI Class Initialized
DEBUG - 2011-10-09 09:51:44 --> Router Class Initialized
ERROR - 2011-10-09 09:51:44 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-09 10:31:47 --> Config Class Initialized
DEBUG - 2011-10-09 10:31:47 --> Hooks Class Initialized
DEBUG - 2011-10-09 10:31:47 --> Utf8 Class Initialized
DEBUG - 2011-10-09 10:31:47 --> UTF-8 Support Enabled
DEBUG - 2011-10-09 10:31:47 --> URI Class Initialized
DEBUG - 2011-10-09 10:31:47 --> Router Class Initialized
DEBUG - 2011-10-09 10:31:47 --> Output Class Initialized
DEBUG - 2011-10-09 10:31:47 --> Input Class Initialized
DEBUG - 2011-10-09 10:31:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-09 10:31:47 --> Language Class Initialized
DEBUG - 2011-10-09 10:31:47 --> Loader Class Initialized
DEBUG - 2011-10-09 10:31:47 --> Controller Class Initialized
DEBUG - 2011-10-09 10:31:47 --> Model Class Initialized
DEBUG - 2011-10-09 10:31:47 --> Model Class Initialized
DEBUG - 2011-10-09 10:31:47 --> Model Class Initialized
DEBUG - 2011-10-09 10:31:47 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-09 10:31:47 --> Database Driver Class Initialized
DEBUG - 2011-10-09 10:31:48 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-09 10:31:48 --> Helper loaded: url_helper
DEBUG - 2011-10-09 10:31:48 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-09 10:31:48 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-09 10:31:48 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-09 10:31:48 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-09 10:31:48 --> Final output sent to browser
DEBUG - 2011-10-09 10:31:48 --> Total execution time: 1.2473
DEBUG - 2011-10-09 10:31:52 --> Config Class Initialized
DEBUG - 2011-10-09 10:31:52 --> Hooks Class Initialized
DEBUG - 2011-10-09 10:31:52 --> Utf8 Class Initialized
DEBUG - 2011-10-09 10:31:52 --> UTF-8 Support Enabled
DEBUG - 2011-10-09 10:31:52 --> URI Class Initialized
DEBUG - 2011-10-09 10:31:52 --> Router Class Initialized
ERROR - 2011-10-09 10:31:52 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-09 10:31:52 --> Config Class Initialized
DEBUG - 2011-10-09 10:31:52 --> Hooks Class Initialized
DEBUG - 2011-10-09 10:31:52 --> Utf8 Class Initialized
DEBUG - 2011-10-09 10:31:52 --> UTF-8 Support Enabled
DEBUG - 2011-10-09 10:31:52 --> URI Class Initialized
DEBUG - 2011-10-09 10:31:52 --> Router Class Initialized
ERROR - 2011-10-09 10:31:52 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-09 10:31:53 --> Config Class Initialized
DEBUG - 2011-10-09 10:31:53 --> Hooks Class Initialized
DEBUG - 2011-10-09 10:31:53 --> Utf8 Class Initialized
DEBUG - 2011-10-09 10:31:53 --> UTF-8 Support Enabled
DEBUG - 2011-10-09 10:31:53 --> URI Class Initialized
DEBUG - 2011-10-09 10:31:53 --> Router Class Initialized
ERROR - 2011-10-09 10:31:53 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-09 10:32:09 --> Config Class Initialized
DEBUG - 2011-10-09 10:32:09 --> Hooks Class Initialized
DEBUG - 2011-10-09 10:32:09 --> Utf8 Class Initialized
DEBUG - 2011-10-09 10:32:09 --> UTF-8 Support Enabled
DEBUG - 2011-10-09 10:32:09 --> URI Class Initialized
DEBUG - 2011-10-09 10:32:09 --> Router Class Initialized
DEBUG - 2011-10-09 10:32:09 --> Output Class Initialized
DEBUG - 2011-10-09 10:32:09 --> Input Class Initialized
DEBUG - 2011-10-09 10:32:09 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-09 10:32:09 --> Language Class Initialized
DEBUG - 2011-10-09 10:32:09 --> Loader Class Initialized
DEBUG - 2011-10-09 10:32:09 --> Controller Class Initialized
DEBUG - 2011-10-09 10:32:09 --> Model Class Initialized
DEBUG - 2011-10-09 10:32:09 --> Model Class Initialized
DEBUG - 2011-10-09 10:32:09 --> Model Class Initialized
DEBUG - 2011-10-09 10:32:09 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-09 10:32:09 --> Database Driver Class Initialized
DEBUG - 2011-10-09 10:32:09 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-09 10:32:09 --> Helper loaded: url_helper
DEBUG - 2011-10-09 10:32:09 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-09 10:32:09 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-09 10:32:09 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-09 10:32:09 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-09 10:32:09 --> Final output sent to browser
DEBUG - 2011-10-09 10:32:09 --> Total execution time: 0.7582
DEBUG - 2011-10-09 10:32:11 --> Config Class Initialized
DEBUG - 2011-10-09 10:32:11 --> Hooks Class Initialized
DEBUG - 2011-10-09 10:32:11 --> Utf8 Class Initialized
DEBUG - 2011-10-09 10:32:11 --> UTF-8 Support Enabled
DEBUG - 2011-10-09 10:32:11 --> URI Class Initialized
DEBUG - 2011-10-09 10:32:11 --> Router Class Initialized
DEBUG - 2011-10-09 10:32:11 --> Output Class Initialized
DEBUG - 2011-10-09 10:32:11 --> Input Class Initialized
DEBUG - 2011-10-09 10:32:11 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-09 10:32:11 --> Language Class Initialized
DEBUG - 2011-10-09 10:32:11 --> Loader Class Initialized
DEBUG - 2011-10-09 10:32:11 --> Controller Class Initialized
DEBUG - 2011-10-09 10:32:11 --> Model Class Initialized
DEBUG - 2011-10-09 10:32:11 --> Model Class Initialized
DEBUG - 2011-10-09 10:32:11 --> Model Class Initialized
DEBUG - 2011-10-09 10:32:11 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-09 10:32:11 --> Database Driver Class Initialized
DEBUG - 2011-10-09 10:32:11 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-09 10:32:11 --> Helper loaded: url_helper
DEBUG - 2011-10-09 10:32:11 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-09 10:32:11 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-09 10:32:11 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-09 10:32:11 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-09 10:32:11 --> Final output sent to browser
DEBUG - 2011-10-09 10:32:11 --> Total execution time: 0.0492
DEBUG - 2011-10-09 11:03:28 --> Config Class Initialized
DEBUG - 2011-10-09 11:03:28 --> Hooks Class Initialized
DEBUG - 2011-10-09 11:03:28 --> Utf8 Class Initialized
DEBUG - 2011-10-09 11:03:28 --> UTF-8 Support Enabled
DEBUG - 2011-10-09 11:03:28 --> URI Class Initialized
DEBUG - 2011-10-09 11:03:28 --> Router Class Initialized
DEBUG - 2011-10-09 11:03:28 --> Output Class Initialized
DEBUG - 2011-10-09 11:03:28 --> Input Class Initialized
DEBUG - 2011-10-09 11:03:28 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-09 11:03:28 --> Language Class Initialized
DEBUG - 2011-10-09 11:03:28 --> Loader Class Initialized
DEBUG - 2011-10-09 11:03:28 --> Controller Class Initialized
DEBUG - 2011-10-09 11:03:28 --> Model Class Initialized
DEBUG - 2011-10-09 11:03:28 --> Model Class Initialized
DEBUG - 2011-10-09 11:03:28 --> Model Class Initialized
DEBUG - 2011-10-09 11:03:28 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-09 11:03:28 --> Database Driver Class Initialized
DEBUG - 2011-10-09 11:03:28 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-09 11:03:28 --> Helper loaded: url_helper
DEBUG - 2011-10-09 11:03:28 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-09 11:03:28 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-09 11:03:28 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-09 11:03:28 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-09 11:03:28 --> Final output sent to browser
DEBUG - 2011-10-09 11:03:28 --> Total execution time: 0.3658
DEBUG - 2011-10-09 11:03:38 --> Config Class Initialized
DEBUG - 2011-10-09 11:03:38 --> Hooks Class Initialized
DEBUG - 2011-10-09 11:03:38 --> Utf8 Class Initialized
DEBUG - 2011-10-09 11:03:38 --> UTF-8 Support Enabled
DEBUG - 2011-10-09 11:03:38 --> URI Class Initialized
DEBUG - 2011-10-09 11:03:38 --> Router Class Initialized
ERROR - 2011-10-09 11:03:38 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-09 11:03:38 --> Config Class Initialized
DEBUG - 2011-10-09 11:03:38 --> Hooks Class Initialized
DEBUG - 2011-10-09 11:03:38 --> Utf8 Class Initialized
DEBUG - 2011-10-09 11:03:38 --> UTF-8 Support Enabled
DEBUG - 2011-10-09 11:03:38 --> URI Class Initialized
DEBUG - 2011-10-09 11:03:38 --> Router Class Initialized
ERROR - 2011-10-09 11:03:38 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-09 11:04:04 --> Config Class Initialized
DEBUG - 2011-10-09 11:04:04 --> Hooks Class Initialized
DEBUG - 2011-10-09 11:04:04 --> Utf8 Class Initialized
DEBUG - 2011-10-09 11:04:04 --> UTF-8 Support Enabled
DEBUG - 2011-10-09 11:04:04 --> URI Class Initialized
DEBUG - 2011-10-09 11:04:04 --> Router Class Initialized
DEBUG - 2011-10-09 11:04:04 --> Output Class Initialized
DEBUG - 2011-10-09 11:04:04 --> Input Class Initialized
DEBUG - 2011-10-09 11:04:04 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-09 11:04:04 --> Language Class Initialized
DEBUG - 2011-10-09 11:04:04 --> Loader Class Initialized
DEBUG - 2011-10-09 11:04:04 --> Controller Class Initialized
DEBUG - 2011-10-09 11:04:04 --> Model Class Initialized
DEBUG - 2011-10-09 11:04:04 --> Model Class Initialized
DEBUG - 2011-10-09 11:04:04 --> Model Class Initialized
DEBUG - 2011-10-09 11:04:04 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-09 11:04:04 --> Database Driver Class Initialized
DEBUG - 2011-10-09 11:04:05 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-09 11:04:05 --> Helper loaded: url_helper
DEBUG - 2011-10-09 11:04:05 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-09 11:04:05 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-09 11:04:05 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-09 11:04:05 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-09 11:04:05 --> Final output sent to browser
DEBUG - 2011-10-09 11:04:05 --> Total execution time: 0.5066
DEBUG - 2011-10-09 11:04:09 --> Config Class Initialized
DEBUG - 2011-10-09 11:04:09 --> Hooks Class Initialized
DEBUG - 2011-10-09 11:04:09 --> Utf8 Class Initialized
DEBUG - 2011-10-09 11:04:09 --> UTF-8 Support Enabled
DEBUG - 2011-10-09 11:04:09 --> URI Class Initialized
DEBUG - 2011-10-09 11:04:09 --> Router Class Initialized
DEBUG - 2011-10-09 11:04:09 --> Output Class Initialized
DEBUG - 2011-10-09 11:04:09 --> Input Class Initialized
DEBUG - 2011-10-09 11:04:09 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-09 11:04:09 --> Language Class Initialized
DEBUG - 2011-10-09 11:04:09 --> Loader Class Initialized
DEBUG - 2011-10-09 11:04:09 --> Controller Class Initialized
DEBUG - 2011-10-09 11:04:09 --> Model Class Initialized
DEBUG - 2011-10-09 11:04:09 --> Model Class Initialized
DEBUG - 2011-10-09 11:04:09 --> Model Class Initialized
DEBUG - 2011-10-09 11:04:09 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-09 11:04:09 --> Database Driver Class Initialized
DEBUG - 2011-10-09 11:04:09 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-09 11:04:09 --> Helper loaded: url_helper
DEBUG - 2011-10-09 11:04:09 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-09 11:04:09 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-09 11:04:09 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-09 11:04:09 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-09 11:04:09 --> Final output sent to browser
DEBUG - 2011-10-09 11:04:09 --> Total execution time: 0.0483
DEBUG - 2011-10-09 11:07:46 --> Config Class Initialized
DEBUG - 2011-10-09 11:07:46 --> Hooks Class Initialized
DEBUG - 2011-10-09 11:07:46 --> Utf8 Class Initialized
DEBUG - 2011-10-09 11:07:46 --> UTF-8 Support Enabled
DEBUG - 2011-10-09 11:07:46 --> URI Class Initialized
DEBUG - 2011-10-09 11:07:46 --> Router Class Initialized
DEBUG - 2011-10-09 11:07:46 --> Output Class Initialized
DEBUG - 2011-10-09 11:07:46 --> Input Class Initialized
DEBUG - 2011-10-09 11:07:46 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-09 11:07:46 --> Language Class Initialized
DEBUG - 2011-10-09 11:07:46 --> Loader Class Initialized
DEBUG - 2011-10-09 11:07:46 --> Controller Class Initialized
ERROR - 2011-10-09 11:07:46 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-10-09 11:07:46 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-10-09 11:07:46 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-09 11:07:46 --> Model Class Initialized
DEBUG - 2011-10-09 11:07:46 --> Model Class Initialized
DEBUG - 2011-10-09 11:07:46 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-09 11:07:46 --> Database Driver Class Initialized
DEBUG - 2011-10-09 11:07:46 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-09 11:07:46 --> Helper loaded: url_helper
DEBUG - 2011-10-09 11:07:46 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-09 11:07:46 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-09 11:07:46 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-09 11:07:46 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-09 11:07:46 --> Final output sent to browser
DEBUG - 2011-10-09 11:07:46 --> Total execution time: 0.0401
DEBUG - 2011-10-09 11:07:51 --> Config Class Initialized
DEBUG - 2011-10-09 11:07:51 --> Hooks Class Initialized
DEBUG - 2011-10-09 11:07:51 --> Utf8 Class Initialized
DEBUG - 2011-10-09 11:07:51 --> UTF-8 Support Enabled
DEBUG - 2011-10-09 11:07:51 --> URI Class Initialized
DEBUG - 2011-10-09 11:07:51 --> Router Class Initialized
DEBUG - 2011-10-09 11:07:51 --> Output Class Initialized
DEBUG - 2011-10-09 11:07:51 --> Input Class Initialized
DEBUG - 2011-10-09 11:07:51 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-09 11:07:51 --> Language Class Initialized
DEBUG - 2011-10-09 11:07:51 --> Loader Class Initialized
DEBUG - 2011-10-09 11:07:51 --> Controller Class Initialized
DEBUG - 2011-10-09 11:07:51 --> Model Class Initialized
DEBUG - 2011-10-09 11:07:51 --> Model Class Initialized
DEBUG - 2011-10-09 11:07:51 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-09 11:07:51 --> Database Driver Class Initialized
DEBUG - 2011-10-09 11:07:51 --> Final output sent to browser
DEBUG - 2011-10-09 11:07:51 --> Total execution time: 0.7374
DEBUG - 2011-10-09 11:07:57 --> Config Class Initialized
DEBUG - 2011-10-09 11:07:57 --> Hooks Class Initialized
DEBUG - 2011-10-09 11:07:57 --> Utf8 Class Initialized
DEBUG - 2011-10-09 11:07:57 --> UTF-8 Support Enabled
DEBUG - 2011-10-09 11:07:57 --> URI Class Initialized
DEBUG - 2011-10-09 11:07:57 --> Router Class Initialized
ERROR - 2011-10-09 11:07:57 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-09 11:08:05 --> Config Class Initialized
DEBUG - 2011-10-09 11:08:05 --> Hooks Class Initialized
DEBUG - 2011-10-09 11:08:05 --> Utf8 Class Initialized
DEBUG - 2011-10-09 11:08:05 --> UTF-8 Support Enabled
DEBUG - 2011-10-09 11:08:05 --> URI Class Initialized
DEBUG - 2011-10-09 11:08:05 --> Router Class Initialized
DEBUG - 2011-10-09 11:08:05 --> Output Class Initialized
DEBUG - 2011-10-09 11:08:05 --> Input Class Initialized
DEBUG - 2011-10-09 11:08:05 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-09 11:08:05 --> Language Class Initialized
DEBUG - 2011-10-09 11:08:05 --> Loader Class Initialized
DEBUG - 2011-10-09 11:08:05 --> Controller Class Initialized
ERROR - 2011-10-09 11:08:05 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-10-09 11:08:05 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-10-09 11:08:05 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-09 11:08:05 --> Model Class Initialized
DEBUG - 2011-10-09 11:08:05 --> Model Class Initialized
DEBUG - 2011-10-09 11:08:05 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-09 11:08:05 --> Database Driver Class Initialized
DEBUG - 2011-10-09 11:08:05 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-09 11:08:05 --> Helper loaded: url_helper
DEBUG - 2011-10-09 11:08:05 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-09 11:08:05 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-09 11:08:05 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-09 11:08:05 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-09 11:08:05 --> Final output sent to browser
DEBUG - 2011-10-09 11:08:05 --> Total execution time: 0.0310
DEBUG - 2011-10-09 11:08:06 --> Config Class Initialized
DEBUG - 2011-10-09 11:08:06 --> Hooks Class Initialized
DEBUG - 2011-10-09 11:08:06 --> Utf8 Class Initialized
DEBUG - 2011-10-09 11:08:06 --> UTF-8 Support Enabled
DEBUG - 2011-10-09 11:08:06 --> URI Class Initialized
DEBUG - 2011-10-09 11:08:06 --> Router Class Initialized
DEBUG - 2011-10-09 11:08:06 --> Output Class Initialized
DEBUG - 2011-10-09 11:08:06 --> Input Class Initialized
DEBUG - 2011-10-09 11:08:06 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-09 11:08:06 --> Language Class Initialized
DEBUG - 2011-10-09 11:08:06 --> Loader Class Initialized
DEBUG - 2011-10-09 11:08:06 --> Controller Class Initialized
DEBUG - 2011-10-09 11:08:06 --> Model Class Initialized
DEBUG - 2011-10-09 11:08:06 --> Model Class Initialized
DEBUG - 2011-10-09 11:08:06 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-09 11:08:06 --> Database Driver Class Initialized
DEBUG - 2011-10-09 11:08:06 --> Final output sent to browser
DEBUG - 2011-10-09 11:08:06 --> Total execution time: 0.4844
DEBUG - 2011-10-09 11:08:10 --> Config Class Initialized
DEBUG - 2011-10-09 11:08:10 --> Hooks Class Initialized
DEBUG - 2011-10-09 11:08:10 --> Utf8 Class Initialized
DEBUG - 2011-10-09 11:08:10 --> UTF-8 Support Enabled
DEBUG - 2011-10-09 11:08:10 --> URI Class Initialized
DEBUG - 2011-10-09 11:08:10 --> Router Class Initialized
ERROR - 2011-10-09 11:08:10 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-09 11:08:32 --> Config Class Initialized
DEBUG - 2011-10-09 11:08:32 --> Hooks Class Initialized
DEBUG - 2011-10-09 11:08:32 --> Utf8 Class Initialized
DEBUG - 2011-10-09 11:08:32 --> UTF-8 Support Enabled
DEBUG - 2011-10-09 11:08:32 --> URI Class Initialized
DEBUG - 2011-10-09 11:08:32 --> Router Class Initialized
DEBUG - 2011-10-09 11:08:32 --> Output Class Initialized
DEBUG - 2011-10-09 11:08:32 --> Input Class Initialized
DEBUG - 2011-10-09 11:08:32 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-09 11:08:32 --> Language Class Initialized
DEBUG - 2011-10-09 11:08:32 --> Loader Class Initialized
DEBUG - 2011-10-09 11:08:32 --> Controller Class Initialized
ERROR - 2011-10-09 11:08:32 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-10-09 11:08:32 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-10-09 11:08:32 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-09 11:08:32 --> Model Class Initialized
DEBUG - 2011-10-09 11:08:32 --> Model Class Initialized
DEBUG - 2011-10-09 11:08:32 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-09 11:08:32 --> Database Driver Class Initialized
DEBUG - 2011-10-09 11:08:32 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-09 11:08:32 --> Helper loaded: url_helper
DEBUG - 2011-10-09 11:08:32 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-09 11:08:32 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-09 11:08:32 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-09 11:08:32 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-09 11:08:32 --> Final output sent to browser
DEBUG - 2011-10-09 11:08:32 --> Total execution time: 0.1748
DEBUG - 2011-10-09 11:08:44 --> Config Class Initialized
DEBUG - 2011-10-09 11:08:44 --> Hooks Class Initialized
DEBUG - 2011-10-09 11:08:44 --> Utf8 Class Initialized
DEBUG - 2011-10-09 11:08:44 --> UTF-8 Support Enabled
DEBUG - 2011-10-09 11:08:44 --> URI Class Initialized
DEBUG - 2011-10-09 11:08:44 --> Router Class Initialized
DEBUG - 2011-10-09 11:08:44 --> Output Class Initialized
DEBUG - 2011-10-09 11:08:44 --> Input Class Initialized
DEBUG - 2011-10-09 11:08:44 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-09 11:08:44 --> Language Class Initialized
DEBUG - 2011-10-09 11:08:44 --> Loader Class Initialized
DEBUG - 2011-10-09 11:08:44 --> Controller Class Initialized
DEBUG - 2011-10-09 11:08:44 --> Model Class Initialized
DEBUG - 2011-10-09 11:08:44 --> Model Class Initialized
DEBUG - 2011-10-09 11:08:44 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-09 11:08:44 --> Database Driver Class Initialized
DEBUG - 2011-10-09 11:08:45 --> Final output sent to browser
DEBUG - 2011-10-09 11:08:45 --> Total execution time: 0.6122
DEBUG - 2011-10-09 11:08:50 --> Config Class Initialized
DEBUG - 2011-10-09 11:08:50 --> Hooks Class Initialized
DEBUG - 2011-10-09 11:08:50 --> Utf8 Class Initialized
DEBUG - 2011-10-09 11:08:50 --> UTF-8 Support Enabled
DEBUG - 2011-10-09 11:08:50 --> URI Class Initialized
DEBUG - 2011-10-09 11:08:50 --> Router Class Initialized
ERROR - 2011-10-09 11:08:50 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-09 11:56:40 --> Config Class Initialized
DEBUG - 2011-10-09 11:56:40 --> Hooks Class Initialized
DEBUG - 2011-10-09 11:56:40 --> Utf8 Class Initialized
DEBUG - 2011-10-09 11:56:40 --> UTF-8 Support Enabled
DEBUG - 2011-10-09 11:56:40 --> URI Class Initialized
DEBUG - 2011-10-09 11:56:40 --> Router Class Initialized
ERROR - 2011-10-09 11:56:40 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-10-09 11:56:40 --> Config Class Initialized
DEBUG - 2011-10-09 11:56:40 --> Hooks Class Initialized
DEBUG - 2011-10-09 11:56:40 --> Utf8 Class Initialized
DEBUG - 2011-10-09 11:56:40 --> UTF-8 Support Enabled
DEBUG - 2011-10-09 11:56:40 --> URI Class Initialized
DEBUG - 2011-10-09 11:56:40 --> Router Class Initialized
DEBUG - 2011-10-09 11:56:40 --> Output Class Initialized
DEBUG - 2011-10-09 11:56:40 --> Input Class Initialized
DEBUG - 2011-10-09 11:56:40 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-09 11:56:40 --> Language Class Initialized
DEBUG - 2011-10-09 11:56:40 --> Loader Class Initialized
DEBUG - 2011-10-09 11:56:40 --> Controller Class Initialized
ERROR - 2011-10-09 11:56:40 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-10-09 11:56:40 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-10-09 11:56:40 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-09 11:56:40 --> Model Class Initialized
DEBUG - 2011-10-09 11:56:40 --> Model Class Initialized
DEBUG - 2011-10-09 11:56:40 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-09 11:56:40 --> Database Driver Class Initialized
DEBUG - 2011-10-09 11:56:40 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-09 11:56:40 --> Helper loaded: url_helper
DEBUG - 2011-10-09 11:56:40 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-09 11:56:40 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-09 11:56:40 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-09 11:56:40 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-09 11:56:40 --> Final output sent to browser
DEBUG - 2011-10-09 11:56:40 --> Total execution time: 0.3183
DEBUG - 2011-10-09 12:37:47 --> Config Class Initialized
DEBUG - 2011-10-09 12:37:47 --> Hooks Class Initialized
DEBUG - 2011-10-09 12:37:47 --> Utf8 Class Initialized
DEBUG - 2011-10-09 12:37:47 --> UTF-8 Support Enabled
DEBUG - 2011-10-09 12:37:47 --> URI Class Initialized
DEBUG - 2011-10-09 12:37:47 --> Router Class Initialized
DEBUG - 2011-10-09 12:37:47 --> Output Class Initialized
DEBUG - 2011-10-09 12:37:47 --> Input Class Initialized
DEBUG - 2011-10-09 12:37:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-09 12:37:47 --> Language Class Initialized
DEBUG - 2011-10-09 12:37:47 --> Loader Class Initialized
DEBUG - 2011-10-09 12:37:47 --> Controller Class Initialized
DEBUG - 2011-10-09 12:37:47 --> Model Class Initialized
DEBUG - 2011-10-09 12:37:47 --> Model Class Initialized
DEBUG - 2011-10-09 12:37:47 --> Model Class Initialized
DEBUG - 2011-10-09 12:37:47 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-09 12:37:47 --> Database Driver Class Initialized
DEBUG - 2011-10-09 12:37:49 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-09 12:37:49 --> Helper loaded: url_helper
DEBUG - 2011-10-09 12:37:49 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-09 12:37:49 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-09 12:37:49 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-09 12:37:49 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-09 12:37:49 --> Final output sent to browser
DEBUG - 2011-10-09 12:37:49 --> Total execution time: 1.3604
DEBUG - 2011-10-09 15:43:48 --> Config Class Initialized
DEBUG - 2011-10-09 15:43:48 --> Hooks Class Initialized
DEBUG - 2011-10-09 15:43:48 --> Utf8 Class Initialized
DEBUG - 2011-10-09 15:43:48 --> UTF-8 Support Enabled
DEBUG - 2011-10-09 15:43:48 --> URI Class Initialized
DEBUG - 2011-10-09 15:43:48 --> Router Class Initialized
DEBUG - 2011-10-09 15:43:48 --> Output Class Initialized
DEBUG - 2011-10-09 15:43:48 --> Input Class Initialized
DEBUG - 2011-10-09 15:43:48 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-09 15:43:48 --> Language Class Initialized
DEBUG - 2011-10-09 15:43:48 --> Loader Class Initialized
DEBUG - 2011-10-09 15:43:48 --> Controller Class Initialized
DEBUG - 2011-10-09 15:43:48 --> Model Class Initialized
DEBUG - 2011-10-09 15:43:48 --> Model Class Initialized
DEBUG - 2011-10-09 15:43:48 --> Model Class Initialized
DEBUG - 2011-10-09 15:43:48 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-09 15:43:48 --> Database Driver Class Initialized
DEBUG - 2011-10-09 15:43:49 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-09 15:43:49 --> Helper loaded: url_helper
DEBUG - 2011-10-09 15:43:49 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-09 15:43:49 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-09 15:43:49 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-09 15:43:49 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-09 15:43:49 --> Final output sent to browser
DEBUG - 2011-10-09 15:43:49 --> Total execution time: 1.2577
DEBUG - 2011-10-09 15:43:50 --> Config Class Initialized
DEBUG - 2011-10-09 15:43:50 --> Hooks Class Initialized
DEBUG - 2011-10-09 15:43:50 --> Utf8 Class Initialized
DEBUG - 2011-10-09 15:43:50 --> UTF-8 Support Enabled
DEBUG - 2011-10-09 15:43:50 --> URI Class Initialized
DEBUG - 2011-10-09 15:43:50 --> Router Class Initialized
DEBUG - 2011-10-09 15:43:50 --> Output Class Initialized
DEBUG - 2011-10-09 15:43:50 --> Input Class Initialized
DEBUG - 2011-10-09 15:43:50 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-09 15:43:50 --> Language Class Initialized
DEBUG - 2011-10-09 15:43:50 --> Loader Class Initialized
DEBUG - 2011-10-09 15:43:50 --> Controller Class Initialized
ERROR - 2011-10-09 15:43:50 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-10-09 15:43:50 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-10-09 15:43:50 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-09 15:43:50 --> Model Class Initialized
DEBUG - 2011-10-09 15:43:50 --> Model Class Initialized
DEBUG - 2011-10-09 15:43:50 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-09 15:43:50 --> Database Driver Class Initialized
DEBUG - 2011-10-09 15:43:50 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-09 15:43:50 --> Helper loaded: url_helper
DEBUG - 2011-10-09 15:43:50 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-09 15:43:50 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-09 15:43:50 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-09 15:43:50 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-09 15:43:50 --> Final output sent to browser
DEBUG - 2011-10-09 15:43:50 --> Total execution time: 0.1460
DEBUG - 2011-10-09 17:53:21 --> Config Class Initialized
DEBUG - 2011-10-09 17:53:21 --> Hooks Class Initialized
DEBUG - 2011-10-09 17:53:21 --> Utf8 Class Initialized
DEBUG - 2011-10-09 17:53:21 --> UTF-8 Support Enabled
DEBUG - 2011-10-09 17:53:21 --> URI Class Initialized
DEBUG - 2011-10-09 17:53:21 --> Router Class Initialized
DEBUG - 2011-10-09 17:53:21 --> No URI present. Default controller set.
DEBUG - 2011-10-09 17:53:21 --> Output Class Initialized
DEBUG - 2011-10-09 17:53:22 --> Input Class Initialized
DEBUG - 2011-10-09 17:53:22 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-09 17:53:22 --> Language Class Initialized
DEBUG - 2011-10-09 17:53:22 --> Loader Class Initialized
DEBUG - 2011-10-09 17:53:22 --> Controller Class Initialized
DEBUG - 2011-10-09 17:53:22 --> File loaded: application/views/splash/main.php
DEBUG - 2011-10-09 17:53:22 --> Helper loaded: url_helper
DEBUG - 2011-10-09 17:53:22 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-09 17:53:22 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-09 17:53:22 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-09 17:53:22 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-09 17:53:22 --> Final output sent to browser
DEBUG - 2011-10-09 17:53:22 --> Total execution time: 0.6732
DEBUG - 2011-10-09 22:06:23 --> Config Class Initialized
DEBUG - 2011-10-09 22:06:23 --> Hooks Class Initialized
DEBUG - 2011-10-09 22:06:23 --> Utf8 Class Initialized
DEBUG - 2011-10-09 22:06:23 --> UTF-8 Support Enabled
DEBUG - 2011-10-09 22:06:23 --> URI Class Initialized
DEBUG - 2011-10-09 22:06:23 --> Router Class Initialized
ERROR - 2011-10-09 22:06:23 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-10-09 22:08:42 --> Config Class Initialized
DEBUG - 2011-10-09 22:08:42 --> Hooks Class Initialized
DEBUG - 2011-10-09 22:08:42 --> Utf8 Class Initialized
DEBUG - 2011-10-09 22:08:42 --> UTF-8 Support Enabled
DEBUG - 2011-10-09 22:08:42 --> URI Class Initialized
DEBUG - 2011-10-09 22:08:42 --> Router Class Initialized
ERROR - 2011-10-09 22:08:42 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-10-09 22:08:46 --> Config Class Initialized
DEBUG - 2011-10-09 22:08:46 --> Hooks Class Initialized
DEBUG - 2011-10-09 22:08:46 --> Utf8 Class Initialized
DEBUG - 2011-10-09 22:08:46 --> UTF-8 Support Enabled
DEBUG - 2011-10-09 22:08:46 --> URI Class Initialized
DEBUG - 2011-10-09 22:08:46 --> Router Class Initialized
DEBUG - 2011-10-09 22:08:46 --> Output Class Initialized
DEBUG - 2011-10-09 22:08:46 --> Input Class Initialized
DEBUG - 2011-10-09 22:08:46 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-09 22:08:46 --> Language Class Initialized
DEBUG - 2011-10-09 22:08:46 --> Loader Class Initialized
DEBUG - 2011-10-09 22:08:46 --> Controller Class Initialized
ERROR - 2011-10-09 22:08:47 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-10-09 22:08:47 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-10-09 22:08:47 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-09 22:08:47 --> Model Class Initialized
DEBUG - 2011-10-09 22:08:47 --> Model Class Initialized
DEBUG - 2011-10-09 22:08:47 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-09 22:08:48 --> Database Driver Class Initialized
DEBUG - 2011-10-09 22:08:50 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-09 22:08:50 --> Helper loaded: url_helper
DEBUG - 2011-10-09 22:08:50 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-09 22:08:50 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-09 22:08:50 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-09 22:08:50 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-09 22:08:50 --> Final output sent to browser
DEBUG - 2011-10-09 22:08:50 --> Total execution time: 4.4517
DEBUG - 2011-10-09 22:15:42 --> Config Class Initialized
DEBUG - 2011-10-09 22:15:42 --> Hooks Class Initialized
DEBUG - 2011-10-09 22:15:42 --> Utf8 Class Initialized
DEBUG - 2011-10-09 22:15:42 --> UTF-8 Support Enabled
DEBUG - 2011-10-09 22:15:42 --> URI Class Initialized
DEBUG - 2011-10-09 22:15:42 --> Router Class Initialized
DEBUG - 2011-10-09 22:15:42 --> Output Class Initialized
DEBUG - 2011-10-09 22:15:42 --> Input Class Initialized
DEBUG - 2011-10-09 22:15:42 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-09 22:15:42 --> Language Class Initialized
DEBUG - 2011-10-09 22:15:42 --> Loader Class Initialized
DEBUG - 2011-10-09 22:15:42 --> Controller Class Initialized
ERROR - 2011-10-09 22:15:42 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-10-09 22:15:42 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-10-09 22:15:42 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-09 22:15:42 --> Model Class Initialized
DEBUG - 2011-10-09 22:15:42 --> Model Class Initialized
DEBUG - 2011-10-09 22:15:42 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-09 22:15:42 --> Database Driver Class Initialized
DEBUG - 2011-10-09 22:15:42 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-09 22:15:42 --> Helper loaded: url_helper
DEBUG - 2011-10-09 22:15:42 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-09 22:15:42 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-09 22:15:42 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-09 22:15:42 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-09 22:15:42 --> Final output sent to browser
DEBUG - 2011-10-09 22:15:42 --> Total execution time: 0.0342
DEBUG - 2011-10-09 22:15:43 --> Config Class Initialized
DEBUG - 2011-10-09 22:15:43 --> Hooks Class Initialized
DEBUG - 2011-10-09 22:15:43 --> Utf8 Class Initialized
DEBUG - 2011-10-09 22:15:43 --> UTF-8 Support Enabled
DEBUG - 2011-10-09 22:15:43 --> URI Class Initialized
DEBUG - 2011-10-09 22:15:43 --> Router Class Initialized
DEBUG - 2011-10-09 22:15:43 --> Output Class Initialized
DEBUG - 2011-10-09 22:15:43 --> Input Class Initialized
DEBUG - 2011-10-09 22:15:43 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-09 22:15:43 --> Language Class Initialized
DEBUG - 2011-10-09 22:15:43 --> Loader Class Initialized
DEBUG - 2011-10-09 22:15:43 --> Controller Class Initialized
DEBUG - 2011-10-09 22:15:43 --> Model Class Initialized
DEBUG - 2011-10-09 22:15:43 --> Model Class Initialized
DEBUG - 2011-10-09 22:15:43 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-09 22:15:43 --> Database Driver Class Initialized
DEBUG - 2011-10-09 22:15:44 --> Final output sent to browser
DEBUG - 2011-10-09 22:15:44 --> Total execution time: 1.4970
DEBUG - 2011-10-09 22:15:46 --> Config Class Initialized
DEBUG - 2011-10-09 22:15:46 --> Hooks Class Initialized
DEBUG - 2011-10-09 22:15:46 --> Utf8 Class Initialized
DEBUG - 2011-10-09 22:15:46 --> UTF-8 Support Enabled
DEBUG - 2011-10-09 22:15:46 --> URI Class Initialized
DEBUG - 2011-10-09 22:15:46 --> Router Class Initialized
ERROR - 2011-10-09 22:15:46 --> 404 Page Not Found --> favicon.ico

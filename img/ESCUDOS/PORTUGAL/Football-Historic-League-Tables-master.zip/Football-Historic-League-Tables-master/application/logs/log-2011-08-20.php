<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2011-08-20 03:11:01 --> Config Class Initialized
DEBUG - 2011-08-20 03:11:01 --> Hooks Class Initialized
DEBUG - 2011-08-20 03:11:01 --> Utf8 Class Initialized
DEBUG - 2011-08-20 03:11:01 --> UTF-8 Support Enabled
DEBUG - 2011-08-20 03:11:01 --> URI Class Initialized
DEBUG - 2011-08-20 03:11:01 --> Router Class Initialized
DEBUG - 2011-08-20 03:11:01 --> No URI present. Default controller set.
DEBUG - 2011-08-20 03:11:02 --> Output Class Initialized
DEBUG - 2011-08-20 03:11:02 --> Input Class Initialized
DEBUG - 2011-08-20 03:11:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-20 03:11:02 --> Language Class Initialized
DEBUG - 2011-08-20 03:11:02 --> Loader Class Initialized
DEBUG - 2011-08-20 03:11:02 --> Controller Class Initialized
DEBUG - 2011-08-20 03:11:02 --> File loaded: application/views/splash/main.php
DEBUG - 2011-08-20 03:11:02 --> Helper loaded: url_helper
DEBUG - 2011-08-20 03:11:02 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-20 03:11:02 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-20 03:11:02 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-20 03:11:02 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-20 03:11:02 --> Final output sent to browser
DEBUG - 2011-08-20 03:11:02 --> Total execution time: 0.2553
DEBUG - 2011-08-20 04:30:08 --> Config Class Initialized
DEBUG - 2011-08-20 04:30:08 --> Hooks Class Initialized
DEBUG - 2011-08-20 04:30:08 --> Utf8 Class Initialized
DEBUG - 2011-08-20 04:30:08 --> UTF-8 Support Enabled
DEBUG - 2011-08-20 04:30:08 --> URI Class Initialized
DEBUG - 2011-08-20 04:30:08 --> Router Class Initialized
ERROR - 2011-08-20 04:30:08 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-08-20 05:00:59 --> Config Class Initialized
DEBUG - 2011-08-20 05:00:59 --> Hooks Class Initialized
DEBUG - 2011-08-20 05:00:59 --> Utf8 Class Initialized
DEBUG - 2011-08-20 05:00:59 --> UTF-8 Support Enabled
DEBUG - 2011-08-20 05:00:59 --> URI Class Initialized
DEBUG - 2011-08-20 05:00:59 --> Router Class Initialized
ERROR - 2011-08-20 05:00:59 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-08-20 06:40:06 --> Config Class Initialized
DEBUG - 2011-08-20 06:40:06 --> Hooks Class Initialized
DEBUG - 2011-08-20 06:40:06 --> Utf8 Class Initialized
DEBUG - 2011-08-20 06:40:06 --> UTF-8 Support Enabled
DEBUG - 2011-08-20 06:40:06 --> URI Class Initialized
DEBUG - 2011-08-20 06:40:06 --> Router Class Initialized
DEBUG - 2011-08-20 06:40:06 --> No URI present. Default controller set.
DEBUG - 2011-08-20 06:40:06 --> Output Class Initialized
DEBUG - 2011-08-20 06:40:06 --> Input Class Initialized
DEBUG - 2011-08-20 06:40:06 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-20 06:40:06 --> Language Class Initialized
DEBUG - 2011-08-20 06:40:06 --> Loader Class Initialized
DEBUG - 2011-08-20 06:40:06 --> Controller Class Initialized
DEBUG - 2011-08-20 06:40:06 --> File loaded: application/views/splash/main.php
DEBUG - 2011-08-20 06:40:06 --> Helper loaded: url_helper
DEBUG - 2011-08-20 06:40:06 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-20 06:40:06 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-20 06:40:06 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-20 06:40:06 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-20 06:40:06 --> Final output sent to browser
DEBUG - 2011-08-20 06:40:06 --> Total execution time: 0.8747
DEBUG - 2011-08-20 07:11:51 --> Config Class Initialized
DEBUG - 2011-08-20 07:11:51 --> Hooks Class Initialized
DEBUG - 2011-08-20 07:11:51 --> Utf8 Class Initialized
DEBUG - 2011-08-20 07:11:51 --> UTF-8 Support Enabled
DEBUG - 2011-08-20 07:11:51 --> URI Class Initialized
DEBUG - 2011-08-20 07:11:51 --> Router Class Initialized
DEBUG - 2011-08-20 07:11:51 --> Output Class Initialized
DEBUG - 2011-08-20 07:11:51 --> Input Class Initialized
DEBUG - 2011-08-20 07:11:51 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-20 07:11:51 --> Language Class Initialized
DEBUG - 2011-08-20 07:11:51 --> Loader Class Initialized
DEBUG - 2011-08-20 07:11:51 --> Controller Class Initialized
DEBUG - 2011-08-20 07:11:51 --> Model Class Initialized
DEBUG - 2011-08-20 07:11:51 --> Model Class Initialized
DEBUG - 2011-08-20 07:11:51 --> Model Class Initialized
DEBUG - 2011-08-20 07:11:51 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-20 07:11:52 --> Database Driver Class Initialized
DEBUG - 2011-08-20 07:11:53 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-20 07:11:53 --> Helper loaded: url_helper
DEBUG - 2011-08-20 07:11:53 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-20 07:11:53 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-20 07:11:53 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-20 07:11:53 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-20 07:11:53 --> Final output sent to browser
DEBUG - 2011-08-20 07:11:53 --> Total execution time: 1.6903
DEBUG - 2011-08-20 07:11:54 --> Config Class Initialized
DEBUG - 2011-08-20 07:11:54 --> Hooks Class Initialized
DEBUG - 2011-08-20 07:11:54 --> Utf8 Class Initialized
DEBUG - 2011-08-20 07:11:54 --> UTF-8 Support Enabled
DEBUG - 2011-08-20 07:11:54 --> URI Class Initialized
DEBUG - 2011-08-20 07:11:54 --> Router Class Initialized
ERROR - 2011-08-20 07:11:54 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-20 07:12:15 --> Config Class Initialized
DEBUG - 2011-08-20 07:12:15 --> Hooks Class Initialized
DEBUG - 2011-08-20 07:12:15 --> Utf8 Class Initialized
DEBUG - 2011-08-20 07:12:15 --> UTF-8 Support Enabled
DEBUG - 2011-08-20 07:12:15 --> URI Class Initialized
DEBUG - 2011-08-20 07:12:15 --> Router Class Initialized
DEBUG - 2011-08-20 07:12:15 --> Output Class Initialized
DEBUG - 2011-08-20 07:12:15 --> Input Class Initialized
DEBUG - 2011-08-20 07:12:15 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-20 07:12:15 --> Language Class Initialized
DEBUG - 2011-08-20 07:12:15 --> Loader Class Initialized
DEBUG - 2011-08-20 07:12:15 --> Controller Class Initialized
DEBUG - 2011-08-20 07:12:15 --> Model Class Initialized
DEBUG - 2011-08-20 07:12:15 --> Model Class Initialized
DEBUG - 2011-08-20 07:12:15 --> Model Class Initialized
DEBUG - 2011-08-20 07:12:15 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-20 07:12:15 --> Database Driver Class Initialized
DEBUG - 2011-08-20 07:12:16 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-20 07:12:16 --> Helper loaded: url_helper
DEBUG - 2011-08-20 07:12:16 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-20 07:12:16 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-20 07:12:16 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-20 07:12:16 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-20 07:12:16 --> Final output sent to browser
DEBUG - 2011-08-20 07:12:16 --> Total execution time: 0.4636
DEBUG - 2011-08-20 07:12:17 --> Config Class Initialized
DEBUG - 2011-08-20 07:12:17 --> Hooks Class Initialized
DEBUG - 2011-08-20 07:12:17 --> Utf8 Class Initialized
DEBUG - 2011-08-20 07:12:17 --> UTF-8 Support Enabled
DEBUG - 2011-08-20 07:12:17 --> URI Class Initialized
DEBUG - 2011-08-20 07:12:17 --> Router Class Initialized
ERROR - 2011-08-20 07:12:17 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-20 07:12:17 --> Config Class Initialized
DEBUG - 2011-08-20 07:12:17 --> Hooks Class Initialized
DEBUG - 2011-08-20 07:12:17 --> Utf8 Class Initialized
DEBUG - 2011-08-20 07:12:17 --> UTF-8 Support Enabled
DEBUG - 2011-08-20 07:12:17 --> URI Class Initialized
DEBUG - 2011-08-20 07:12:17 --> Router Class Initialized
ERROR - 2011-08-20 07:12:17 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-20 07:12:17 --> Config Class Initialized
DEBUG - 2011-08-20 07:12:17 --> Hooks Class Initialized
DEBUG - 2011-08-20 07:12:17 --> Utf8 Class Initialized
DEBUG - 2011-08-20 07:12:17 --> UTF-8 Support Enabled
DEBUG - 2011-08-20 07:12:17 --> URI Class Initialized
DEBUG - 2011-08-20 07:12:17 --> Router Class Initialized
ERROR - 2011-08-20 07:12:18 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-20 07:12:18 --> Config Class Initialized
DEBUG - 2011-08-20 07:12:18 --> Hooks Class Initialized
DEBUG - 2011-08-20 07:12:18 --> Utf8 Class Initialized
DEBUG - 2011-08-20 07:12:18 --> UTF-8 Support Enabled
DEBUG - 2011-08-20 07:12:18 --> URI Class Initialized
DEBUG - 2011-08-20 07:12:18 --> Router Class Initialized
ERROR - 2011-08-20 07:12:18 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-08-20 07:12:18 --> Config Class Initialized
DEBUG - 2011-08-20 07:12:18 --> Hooks Class Initialized
DEBUG - 2011-08-20 07:12:18 --> Utf8 Class Initialized
DEBUG - 2011-08-20 07:12:18 --> UTF-8 Support Enabled
DEBUG - 2011-08-20 07:12:18 --> URI Class Initialized
DEBUG - 2011-08-20 07:12:18 --> Router Class Initialized
DEBUG - 2011-08-20 07:12:18 --> Output Class Initialized
DEBUG - 2011-08-20 07:12:18 --> Input Class Initialized
DEBUG - 2011-08-20 07:12:18 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-20 07:12:18 --> Language Class Initialized
DEBUG - 2011-08-20 07:12:18 --> Loader Class Initialized
DEBUG - 2011-08-20 07:12:18 --> Controller Class Initialized
DEBUG - 2011-08-20 07:12:18 --> Model Class Initialized
DEBUG - 2011-08-20 07:12:18 --> Model Class Initialized
DEBUG - 2011-08-20 07:12:18 --> Model Class Initialized
DEBUG - 2011-08-20 07:12:18 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-20 07:12:18 --> Database Driver Class Initialized
DEBUG - 2011-08-20 07:12:18 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-20 07:12:18 --> Helper loaded: url_helper
DEBUG - 2011-08-20 07:12:18 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-20 07:12:18 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-20 07:12:18 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-20 07:12:18 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-20 07:12:18 --> Final output sent to browser
DEBUG - 2011-08-20 07:12:18 --> Total execution time: 0.0385
DEBUG - 2011-08-20 07:29:23 --> Config Class Initialized
DEBUG - 2011-08-20 07:29:23 --> Hooks Class Initialized
DEBUG - 2011-08-20 07:29:23 --> Utf8 Class Initialized
DEBUG - 2011-08-20 07:29:23 --> UTF-8 Support Enabled
DEBUG - 2011-08-20 07:29:23 --> URI Class Initialized
DEBUG - 2011-08-20 07:29:23 --> Router Class Initialized
DEBUG - 2011-08-20 07:29:23 --> Output Class Initialized
DEBUG - 2011-08-20 07:29:23 --> Input Class Initialized
DEBUG - 2011-08-20 07:29:23 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-20 07:29:23 --> Language Class Initialized
DEBUG - 2011-08-20 07:29:23 --> Loader Class Initialized
DEBUG - 2011-08-20 07:29:23 --> Controller Class Initialized
DEBUG - 2011-08-20 07:29:23 --> Model Class Initialized
DEBUG - 2011-08-20 07:29:23 --> Model Class Initialized
DEBUG - 2011-08-20 07:29:23 --> Model Class Initialized
DEBUG - 2011-08-20 07:29:23 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-20 07:29:23 --> Database Driver Class Initialized
DEBUG - 2011-08-20 07:29:23 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-20 07:29:23 --> Helper loaded: url_helper
DEBUG - 2011-08-20 07:29:23 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-20 07:29:23 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-20 07:29:23 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-20 07:29:23 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-20 07:29:23 --> Final output sent to browser
DEBUG - 2011-08-20 07:29:23 --> Total execution time: 0.0733
DEBUG - 2011-08-20 07:29:24 --> Config Class Initialized
DEBUG - 2011-08-20 07:29:24 --> Hooks Class Initialized
DEBUG - 2011-08-20 07:29:24 --> Utf8 Class Initialized
DEBUG - 2011-08-20 07:29:24 --> UTF-8 Support Enabled
DEBUG - 2011-08-20 07:29:24 --> URI Class Initialized
DEBUG - 2011-08-20 07:29:24 --> Router Class Initialized
DEBUG - 2011-08-20 07:29:24 --> Output Class Initialized
DEBUG - 2011-08-20 07:29:24 --> Input Class Initialized
DEBUG - 2011-08-20 07:29:24 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-20 07:29:24 --> Language Class Initialized
DEBUG - 2011-08-20 07:29:24 --> Loader Class Initialized
DEBUG - 2011-08-20 07:29:24 --> Controller Class Initialized
ERROR - 2011-08-20 07:29:25 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-20 07:29:25 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-20 07:29:25 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-20 07:29:25 --> Model Class Initialized
DEBUG - 2011-08-20 07:29:25 --> Model Class Initialized
DEBUG - 2011-08-20 07:29:25 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-20 07:29:25 --> Database Driver Class Initialized
DEBUG - 2011-08-20 07:29:25 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-20 07:29:25 --> Helper loaded: url_helper
DEBUG - 2011-08-20 07:29:25 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-20 07:29:25 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-20 07:29:25 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-20 07:29:25 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-20 07:29:25 --> Final output sent to browser
DEBUG - 2011-08-20 07:29:25 --> Total execution time: 0.0852
DEBUG - 2011-08-20 07:29:26 --> Config Class Initialized
DEBUG - 2011-08-20 07:29:26 --> Hooks Class Initialized
DEBUG - 2011-08-20 07:29:26 --> Utf8 Class Initialized
DEBUG - 2011-08-20 07:29:26 --> UTF-8 Support Enabled
DEBUG - 2011-08-20 07:29:26 --> URI Class Initialized
DEBUG - 2011-08-20 07:29:26 --> Router Class Initialized
ERROR - 2011-08-20 07:29:26 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-20 07:29:26 --> Config Class Initialized
DEBUG - 2011-08-20 07:29:26 --> Hooks Class Initialized
DEBUG - 2011-08-20 07:29:26 --> Utf8 Class Initialized
DEBUG - 2011-08-20 07:29:26 --> UTF-8 Support Enabled
DEBUG - 2011-08-20 07:29:26 --> URI Class Initialized
DEBUG - 2011-08-20 07:29:26 --> Router Class Initialized
DEBUG - 2011-08-20 07:29:26 --> Output Class Initialized
DEBUG - 2011-08-20 07:29:26 --> Input Class Initialized
DEBUG - 2011-08-20 07:29:26 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-20 07:29:26 --> Language Class Initialized
DEBUG - 2011-08-20 07:29:26 --> Loader Class Initialized
DEBUG - 2011-08-20 07:29:26 --> Controller Class Initialized
DEBUG - 2011-08-20 07:29:26 --> Model Class Initialized
DEBUG - 2011-08-20 07:29:26 --> Model Class Initialized
DEBUG - 2011-08-20 07:29:26 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-20 07:29:26 --> Database Driver Class Initialized
DEBUG - 2011-08-20 07:29:26 --> Final output sent to browser
DEBUG - 2011-08-20 07:29:26 --> Total execution time: 0.5519
DEBUG - 2011-08-20 07:29:27 --> Config Class Initialized
DEBUG - 2011-08-20 07:29:27 --> Hooks Class Initialized
DEBUG - 2011-08-20 07:29:27 --> Utf8 Class Initialized
DEBUG - 2011-08-20 07:29:27 --> UTF-8 Support Enabled
DEBUG - 2011-08-20 07:29:27 --> URI Class Initialized
DEBUG - 2011-08-20 07:29:27 --> Router Class Initialized
ERROR - 2011-08-20 07:29:27 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-20 07:29:28 --> Config Class Initialized
DEBUG - 2011-08-20 07:29:28 --> Hooks Class Initialized
DEBUG - 2011-08-20 07:29:28 --> Utf8 Class Initialized
DEBUG - 2011-08-20 07:29:28 --> UTF-8 Support Enabled
DEBUG - 2011-08-20 07:29:28 --> URI Class Initialized
DEBUG - 2011-08-20 07:29:28 --> Router Class Initialized
ERROR - 2011-08-20 07:29:28 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-20 07:29:43 --> Config Class Initialized
DEBUG - 2011-08-20 07:29:43 --> Hooks Class Initialized
DEBUG - 2011-08-20 07:29:43 --> Utf8 Class Initialized
DEBUG - 2011-08-20 07:29:43 --> UTF-8 Support Enabled
DEBUG - 2011-08-20 07:29:43 --> URI Class Initialized
DEBUG - 2011-08-20 07:29:43 --> Router Class Initialized
DEBUG - 2011-08-20 07:29:43 --> Output Class Initialized
DEBUG - 2011-08-20 07:29:43 --> Input Class Initialized
DEBUG - 2011-08-20 07:29:43 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-20 07:29:43 --> Language Class Initialized
DEBUG - 2011-08-20 07:29:43 --> Loader Class Initialized
DEBUG - 2011-08-20 07:29:43 --> Controller Class Initialized
DEBUG - 2011-08-20 07:29:43 --> Model Class Initialized
DEBUG - 2011-08-20 07:29:43 --> Model Class Initialized
DEBUG - 2011-08-20 07:29:43 --> Model Class Initialized
DEBUG - 2011-08-20 07:29:43 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-20 07:29:43 --> Database Driver Class Initialized
DEBUG - 2011-08-20 07:29:43 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-20 07:29:43 --> Helper loaded: url_helper
DEBUG - 2011-08-20 07:29:43 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-20 07:29:43 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-20 07:29:43 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-20 07:29:43 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-20 07:29:43 --> Final output sent to browser
DEBUG - 2011-08-20 07:29:43 --> Total execution time: 0.6518
DEBUG - 2011-08-20 07:29:46 --> Config Class Initialized
DEBUG - 2011-08-20 07:29:46 --> Hooks Class Initialized
DEBUG - 2011-08-20 07:29:46 --> Utf8 Class Initialized
DEBUG - 2011-08-20 07:29:46 --> UTF-8 Support Enabled
DEBUG - 2011-08-20 07:29:46 --> URI Class Initialized
DEBUG - 2011-08-20 07:29:46 --> Router Class Initialized
ERROR - 2011-08-20 07:29:46 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-20 07:29:55 --> Config Class Initialized
DEBUG - 2011-08-20 07:29:55 --> Hooks Class Initialized
DEBUG - 2011-08-20 07:29:55 --> Utf8 Class Initialized
DEBUG - 2011-08-20 07:29:55 --> UTF-8 Support Enabled
DEBUG - 2011-08-20 07:29:55 --> URI Class Initialized
DEBUG - 2011-08-20 07:29:55 --> Router Class Initialized
DEBUG - 2011-08-20 07:29:55 --> Output Class Initialized
DEBUG - 2011-08-20 07:29:55 --> Input Class Initialized
DEBUG - 2011-08-20 07:29:55 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-20 07:29:55 --> Language Class Initialized
DEBUG - 2011-08-20 07:29:55 --> Loader Class Initialized
DEBUG - 2011-08-20 07:29:55 --> Controller Class Initialized
DEBUG - 2011-08-20 07:29:55 --> Model Class Initialized
DEBUG - 2011-08-20 07:29:55 --> Model Class Initialized
DEBUG - 2011-08-20 07:29:55 --> Model Class Initialized
DEBUG - 2011-08-20 07:29:55 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-20 07:29:55 --> Database Driver Class Initialized
DEBUG - 2011-08-20 07:29:55 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-20 07:29:55 --> Helper loaded: url_helper
DEBUG - 2011-08-20 07:29:55 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-20 07:29:55 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-20 07:29:55 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-20 07:29:55 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-20 07:29:55 --> Final output sent to browser
DEBUG - 2011-08-20 07:29:55 --> Total execution time: 0.3082
DEBUG - 2011-08-20 07:29:58 --> Config Class Initialized
DEBUG - 2011-08-20 07:29:58 --> Hooks Class Initialized
DEBUG - 2011-08-20 07:29:58 --> Utf8 Class Initialized
DEBUG - 2011-08-20 07:29:58 --> UTF-8 Support Enabled
DEBUG - 2011-08-20 07:29:58 --> URI Class Initialized
DEBUG - 2011-08-20 07:29:58 --> Router Class Initialized
ERROR - 2011-08-20 07:29:58 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-20 07:30:07 --> Config Class Initialized
DEBUG - 2011-08-20 07:30:07 --> Hooks Class Initialized
DEBUG - 2011-08-20 07:30:07 --> Utf8 Class Initialized
DEBUG - 2011-08-20 07:30:07 --> UTF-8 Support Enabled
DEBUG - 2011-08-20 07:30:07 --> URI Class Initialized
DEBUG - 2011-08-20 07:30:07 --> Router Class Initialized
DEBUG - 2011-08-20 07:30:07 --> Output Class Initialized
DEBUG - 2011-08-20 07:30:07 --> Input Class Initialized
DEBUG - 2011-08-20 07:30:07 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-20 07:30:07 --> Language Class Initialized
DEBUG - 2011-08-20 07:30:07 --> Loader Class Initialized
DEBUG - 2011-08-20 07:30:07 --> Controller Class Initialized
DEBUG - 2011-08-20 07:30:07 --> Model Class Initialized
DEBUG - 2011-08-20 07:30:07 --> Model Class Initialized
DEBUG - 2011-08-20 07:30:07 --> Model Class Initialized
DEBUG - 2011-08-20 07:30:07 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-20 07:30:07 --> Database Driver Class Initialized
DEBUG - 2011-08-20 07:30:08 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-20 07:30:08 --> Helper loaded: url_helper
DEBUG - 2011-08-20 07:30:08 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-20 07:30:08 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-20 07:30:08 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-20 07:30:08 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-20 07:30:08 --> Final output sent to browser
DEBUG - 2011-08-20 07:30:08 --> Total execution time: 0.9669
DEBUG - 2011-08-20 07:30:10 --> Config Class Initialized
DEBUG - 2011-08-20 07:30:10 --> Hooks Class Initialized
DEBUG - 2011-08-20 07:30:10 --> Utf8 Class Initialized
DEBUG - 2011-08-20 07:30:10 --> UTF-8 Support Enabled
DEBUG - 2011-08-20 07:30:10 --> URI Class Initialized
DEBUG - 2011-08-20 07:30:10 --> Router Class Initialized
ERROR - 2011-08-20 07:30:10 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-20 07:30:23 --> Config Class Initialized
DEBUG - 2011-08-20 07:30:23 --> Hooks Class Initialized
DEBUG - 2011-08-20 07:30:23 --> Utf8 Class Initialized
DEBUG - 2011-08-20 07:30:23 --> UTF-8 Support Enabled
DEBUG - 2011-08-20 07:30:23 --> URI Class Initialized
DEBUG - 2011-08-20 07:30:23 --> Router Class Initialized
DEBUG - 2011-08-20 07:30:23 --> Output Class Initialized
DEBUG - 2011-08-20 07:30:23 --> Input Class Initialized
DEBUG - 2011-08-20 07:30:23 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-20 07:30:23 --> Language Class Initialized
DEBUG - 2011-08-20 07:30:23 --> Loader Class Initialized
DEBUG - 2011-08-20 07:30:23 --> Controller Class Initialized
DEBUG - 2011-08-20 07:30:23 --> Model Class Initialized
DEBUG - 2011-08-20 07:30:23 --> Model Class Initialized
DEBUG - 2011-08-20 07:30:23 --> Model Class Initialized
DEBUG - 2011-08-20 07:30:23 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-20 07:30:23 --> Database Driver Class Initialized
DEBUG - 2011-08-20 07:30:24 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-20 07:30:24 --> Helper loaded: url_helper
DEBUG - 2011-08-20 07:30:24 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-20 07:30:24 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-20 07:30:24 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-20 07:30:24 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-20 07:30:24 --> Final output sent to browser
DEBUG - 2011-08-20 07:30:24 --> Total execution time: 0.7160
DEBUG - 2011-08-20 07:30:26 --> Config Class Initialized
DEBUG - 2011-08-20 07:30:26 --> Hooks Class Initialized
DEBUG - 2011-08-20 07:30:26 --> Utf8 Class Initialized
DEBUG - 2011-08-20 07:30:26 --> UTF-8 Support Enabled
DEBUG - 2011-08-20 07:30:26 --> URI Class Initialized
DEBUG - 2011-08-20 07:30:26 --> Router Class Initialized
ERROR - 2011-08-20 07:30:26 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-20 07:30:34 --> Config Class Initialized
DEBUG - 2011-08-20 07:30:34 --> Hooks Class Initialized
DEBUG - 2011-08-20 07:30:34 --> Utf8 Class Initialized
DEBUG - 2011-08-20 07:30:34 --> UTF-8 Support Enabled
DEBUG - 2011-08-20 07:30:34 --> URI Class Initialized
DEBUG - 2011-08-20 07:30:34 --> Router Class Initialized
DEBUG - 2011-08-20 07:30:34 --> Output Class Initialized
DEBUG - 2011-08-20 07:30:34 --> Input Class Initialized
DEBUG - 2011-08-20 07:30:34 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-20 07:30:34 --> Language Class Initialized
DEBUG - 2011-08-20 07:30:34 --> Loader Class Initialized
DEBUG - 2011-08-20 07:30:34 --> Controller Class Initialized
DEBUG - 2011-08-20 07:30:34 --> Model Class Initialized
DEBUG - 2011-08-20 07:30:34 --> Model Class Initialized
DEBUG - 2011-08-20 07:30:34 --> Model Class Initialized
DEBUG - 2011-08-20 07:30:34 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-20 07:30:34 --> Database Driver Class Initialized
DEBUG - 2011-08-20 07:30:34 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-20 07:30:34 --> Helper loaded: url_helper
DEBUG - 2011-08-20 07:30:34 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-20 07:30:34 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-20 07:30:34 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-20 07:30:34 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-20 07:30:34 --> Final output sent to browser
DEBUG - 2011-08-20 07:30:34 --> Total execution time: 0.1884
DEBUG - 2011-08-20 07:30:36 --> Config Class Initialized
DEBUG - 2011-08-20 07:30:36 --> Hooks Class Initialized
DEBUG - 2011-08-20 07:30:36 --> Utf8 Class Initialized
DEBUG - 2011-08-20 07:30:36 --> UTF-8 Support Enabled
DEBUG - 2011-08-20 07:30:36 --> URI Class Initialized
DEBUG - 2011-08-20 07:30:36 --> Router Class Initialized
ERROR - 2011-08-20 07:30:36 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-20 07:32:10 --> Config Class Initialized
DEBUG - 2011-08-20 07:32:10 --> Hooks Class Initialized
DEBUG - 2011-08-20 07:32:10 --> Utf8 Class Initialized
DEBUG - 2011-08-20 07:32:10 --> UTF-8 Support Enabled
DEBUG - 2011-08-20 07:32:10 --> URI Class Initialized
DEBUG - 2011-08-20 07:32:10 --> Router Class Initialized
DEBUG - 2011-08-20 07:32:10 --> Output Class Initialized
DEBUG - 2011-08-20 07:32:10 --> Input Class Initialized
DEBUG - 2011-08-20 07:32:10 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-20 07:32:10 --> Language Class Initialized
DEBUG - 2011-08-20 07:32:10 --> Loader Class Initialized
DEBUG - 2011-08-20 07:32:10 --> Controller Class Initialized
DEBUG - 2011-08-20 07:32:10 --> Model Class Initialized
DEBUG - 2011-08-20 07:32:10 --> Model Class Initialized
DEBUG - 2011-08-20 07:32:10 --> Model Class Initialized
DEBUG - 2011-08-20 07:32:10 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-20 07:32:10 --> Database Driver Class Initialized
DEBUG - 2011-08-20 07:32:10 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-20 07:32:10 --> Helper loaded: url_helper
DEBUG - 2011-08-20 07:32:10 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-20 07:32:10 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-20 07:32:10 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-20 07:32:10 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-20 07:32:10 --> Final output sent to browser
DEBUG - 2011-08-20 07:32:10 --> Total execution time: 0.0460
DEBUG - 2011-08-20 07:32:13 --> Config Class Initialized
DEBUG - 2011-08-20 07:32:13 --> Hooks Class Initialized
DEBUG - 2011-08-20 07:32:13 --> Utf8 Class Initialized
DEBUG - 2011-08-20 07:32:13 --> UTF-8 Support Enabled
DEBUG - 2011-08-20 07:32:13 --> URI Class Initialized
DEBUG - 2011-08-20 07:32:13 --> Router Class Initialized
DEBUG - 2011-08-20 07:32:13 --> Output Class Initialized
DEBUG - 2011-08-20 07:32:13 --> Input Class Initialized
DEBUG - 2011-08-20 07:32:13 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-20 07:32:13 --> Language Class Initialized
DEBUG - 2011-08-20 07:32:13 --> Loader Class Initialized
DEBUG - 2011-08-20 07:32:13 --> Controller Class Initialized
DEBUG - 2011-08-20 07:32:13 --> Model Class Initialized
DEBUG - 2011-08-20 07:32:13 --> Model Class Initialized
DEBUG - 2011-08-20 07:32:13 --> Model Class Initialized
DEBUG - 2011-08-20 07:32:13 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-20 07:32:13 --> Database Driver Class Initialized
DEBUG - 2011-08-20 07:32:13 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-20 07:32:13 --> Helper loaded: url_helper
DEBUG - 2011-08-20 07:32:13 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-20 07:32:13 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-20 07:32:13 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-20 07:32:13 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-20 07:32:13 --> Final output sent to browser
DEBUG - 2011-08-20 07:32:13 --> Total execution time: 0.0466
DEBUG - 2011-08-20 07:32:14 --> Config Class Initialized
DEBUG - 2011-08-20 07:32:14 --> Hooks Class Initialized
DEBUG - 2011-08-20 07:32:14 --> Utf8 Class Initialized
DEBUG - 2011-08-20 07:32:14 --> UTF-8 Support Enabled
DEBUG - 2011-08-20 07:32:14 --> URI Class Initialized
DEBUG - 2011-08-20 07:32:14 --> Router Class Initialized
DEBUG - 2011-08-20 07:32:14 --> Output Class Initialized
DEBUG - 2011-08-20 07:32:14 --> Input Class Initialized
DEBUG - 2011-08-20 07:32:14 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-20 07:32:14 --> Language Class Initialized
DEBUG - 2011-08-20 07:32:14 --> Loader Class Initialized
DEBUG - 2011-08-20 07:32:14 --> Controller Class Initialized
DEBUG - 2011-08-20 07:32:14 --> Model Class Initialized
DEBUG - 2011-08-20 07:32:14 --> Model Class Initialized
DEBUG - 2011-08-20 07:32:14 --> Model Class Initialized
DEBUG - 2011-08-20 07:32:14 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-20 07:32:14 --> Database Driver Class Initialized
DEBUG - 2011-08-20 07:32:14 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-20 07:32:14 --> Helper loaded: url_helper
DEBUG - 2011-08-20 07:32:14 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-20 07:32:14 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-20 07:32:14 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-20 07:32:14 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-20 07:32:14 --> Final output sent to browser
DEBUG - 2011-08-20 07:32:14 --> Total execution time: 0.0469
DEBUG - 2011-08-20 07:32:18 --> Config Class Initialized
DEBUG - 2011-08-20 07:32:18 --> Hooks Class Initialized
DEBUG - 2011-08-20 07:32:18 --> Utf8 Class Initialized
DEBUG - 2011-08-20 07:32:18 --> UTF-8 Support Enabled
DEBUG - 2011-08-20 07:32:18 --> URI Class Initialized
DEBUG - 2011-08-20 07:32:18 --> Router Class Initialized
DEBUG - 2011-08-20 07:32:18 --> Output Class Initialized
DEBUG - 2011-08-20 07:32:18 --> Input Class Initialized
DEBUG - 2011-08-20 07:32:18 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-20 07:32:18 --> Language Class Initialized
DEBUG - 2011-08-20 07:32:18 --> Loader Class Initialized
DEBUG - 2011-08-20 07:32:18 --> Controller Class Initialized
DEBUG - 2011-08-20 07:32:18 --> Model Class Initialized
DEBUG - 2011-08-20 07:32:18 --> Model Class Initialized
DEBUG - 2011-08-20 07:32:18 --> Model Class Initialized
DEBUG - 2011-08-20 07:32:18 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-20 07:32:18 --> Database Driver Class Initialized
DEBUG - 2011-08-20 07:32:18 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-20 07:32:18 --> Helper loaded: url_helper
DEBUG - 2011-08-20 07:32:18 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-20 07:32:18 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-20 07:32:18 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-20 07:32:18 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-20 07:32:18 --> Final output sent to browser
DEBUG - 2011-08-20 07:32:18 --> Total execution time: 0.0470
DEBUG - 2011-08-20 07:32:27 --> Config Class Initialized
DEBUG - 2011-08-20 07:32:27 --> Hooks Class Initialized
DEBUG - 2011-08-20 07:32:27 --> Utf8 Class Initialized
DEBUG - 2011-08-20 07:32:27 --> UTF-8 Support Enabled
DEBUG - 2011-08-20 07:32:27 --> URI Class Initialized
DEBUG - 2011-08-20 07:32:27 --> Router Class Initialized
DEBUG - 2011-08-20 07:32:27 --> Output Class Initialized
DEBUG - 2011-08-20 07:32:27 --> Input Class Initialized
DEBUG - 2011-08-20 07:32:27 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-20 07:32:27 --> Language Class Initialized
DEBUG - 2011-08-20 07:32:27 --> Loader Class Initialized
DEBUG - 2011-08-20 07:32:27 --> Controller Class Initialized
DEBUG - 2011-08-20 07:32:27 --> Model Class Initialized
DEBUG - 2011-08-20 07:32:27 --> Model Class Initialized
DEBUG - 2011-08-20 07:32:27 --> Model Class Initialized
DEBUG - 2011-08-20 07:32:27 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-20 07:32:27 --> Database Driver Class Initialized
DEBUG - 2011-08-20 07:32:27 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-20 07:32:27 --> Helper loaded: url_helper
DEBUG - 2011-08-20 07:32:27 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-20 07:32:27 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-20 07:32:27 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-20 07:32:27 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-20 07:32:27 --> Final output sent to browser
DEBUG - 2011-08-20 07:32:27 --> Total execution time: 0.0487
DEBUG - 2011-08-20 07:34:36 --> Config Class Initialized
DEBUG - 2011-08-20 07:34:36 --> Hooks Class Initialized
DEBUG - 2011-08-20 07:34:36 --> Utf8 Class Initialized
DEBUG - 2011-08-20 07:34:36 --> UTF-8 Support Enabled
DEBUG - 2011-08-20 07:34:36 --> URI Class Initialized
DEBUG - 2011-08-20 07:34:36 --> Router Class Initialized
DEBUG - 2011-08-20 07:34:36 --> Output Class Initialized
DEBUG - 2011-08-20 07:34:36 --> Input Class Initialized
DEBUG - 2011-08-20 07:34:36 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-20 07:34:36 --> Language Class Initialized
DEBUG - 2011-08-20 07:34:36 --> Loader Class Initialized
DEBUG - 2011-08-20 07:34:36 --> Controller Class Initialized
DEBUG - 2011-08-20 07:34:36 --> Model Class Initialized
DEBUG - 2011-08-20 07:34:36 --> Model Class Initialized
DEBUG - 2011-08-20 07:34:36 --> Model Class Initialized
DEBUG - 2011-08-20 07:34:36 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-20 07:34:36 --> Database Driver Class Initialized
DEBUG - 2011-08-20 07:34:36 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-20 07:34:36 --> Helper loaded: url_helper
DEBUG - 2011-08-20 07:34:36 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-20 07:34:36 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-20 07:34:36 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-20 07:34:36 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-20 07:34:36 --> Final output sent to browser
DEBUG - 2011-08-20 07:34:36 --> Total execution time: 0.0432
DEBUG - 2011-08-20 07:34:40 --> Config Class Initialized
DEBUG - 2011-08-20 07:34:40 --> Hooks Class Initialized
DEBUG - 2011-08-20 07:34:40 --> Utf8 Class Initialized
DEBUG - 2011-08-20 07:34:40 --> UTF-8 Support Enabled
DEBUG - 2011-08-20 07:34:40 --> URI Class Initialized
DEBUG - 2011-08-20 07:34:40 --> Router Class Initialized
ERROR - 2011-08-20 07:34:40 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-20 07:34:56 --> Config Class Initialized
DEBUG - 2011-08-20 07:34:56 --> Hooks Class Initialized
DEBUG - 2011-08-20 07:34:56 --> Utf8 Class Initialized
DEBUG - 2011-08-20 07:34:56 --> UTF-8 Support Enabled
DEBUG - 2011-08-20 07:34:56 --> URI Class Initialized
DEBUG - 2011-08-20 07:34:56 --> Router Class Initialized
DEBUG - 2011-08-20 07:34:56 --> Output Class Initialized
DEBUG - 2011-08-20 07:34:56 --> Input Class Initialized
DEBUG - 2011-08-20 07:34:56 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-20 07:34:56 --> Language Class Initialized
DEBUG - 2011-08-20 07:34:56 --> Loader Class Initialized
DEBUG - 2011-08-20 07:34:56 --> Controller Class Initialized
DEBUG - 2011-08-20 07:34:56 --> Model Class Initialized
DEBUG - 2011-08-20 07:34:56 --> Model Class Initialized
DEBUG - 2011-08-20 07:34:56 --> Model Class Initialized
DEBUG - 2011-08-20 07:34:56 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-20 07:34:56 --> Database Driver Class Initialized
DEBUG - 2011-08-20 07:34:57 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-20 07:34:57 --> Helper loaded: url_helper
DEBUG - 2011-08-20 07:34:57 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-20 07:34:57 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-20 07:34:57 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-20 07:34:57 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-20 07:34:57 --> Final output sent to browser
DEBUG - 2011-08-20 07:34:57 --> Total execution time: 0.8005
DEBUG - 2011-08-20 07:34:59 --> Config Class Initialized
DEBUG - 2011-08-20 07:34:59 --> Hooks Class Initialized
DEBUG - 2011-08-20 07:34:59 --> Utf8 Class Initialized
DEBUG - 2011-08-20 07:34:59 --> UTF-8 Support Enabled
DEBUG - 2011-08-20 07:34:59 --> URI Class Initialized
DEBUG - 2011-08-20 07:34:59 --> Router Class Initialized
DEBUG - 2011-08-20 07:34:59 --> Output Class Initialized
DEBUG - 2011-08-20 07:34:59 --> Input Class Initialized
DEBUG - 2011-08-20 07:34:59 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-20 07:34:59 --> Language Class Initialized
DEBUG - 2011-08-20 07:34:59 --> Loader Class Initialized
DEBUG - 2011-08-20 07:34:59 --> Controller Class Initialized
DEBUG - 2011-08-20 07:34:59 --> Model Class Initialized
DEBUG - 2011-08-20 07:34:59 --> Model Class Initialized
DEBUG - 2011-08-20 07:34:59 --> Model Class Initialized
DEBUG - 2011-08-20 07:34:59 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-20 07:34:59 --> Database Driver Class Initialized
DEBUG - 2011-08-20 07:34:59 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-20 07:34:59 --> Helper loaded: url_helper
DEBUG - 2011-08-20 07:34:59 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-20 07:34:59 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-20 07:34:59 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-20 07:34:59 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-20 07:34:59 --> Final output sent to browser
DEBUG - 2011-08-20 07:34:59 --> Total execution time: 0.0591
DEBUG - 2011-08-20 07:34:59 --> Config Class Initialized
DEBUG - 2011-08-20 07:34:59 --> Hooks Class Initialized
DEBUG - 2011-08-20 07:34:59 --> Utf8 Class Initialized
DEBUG - 2011-08-20 07:34:59 --> UTF-8 Support Enabled
DEBUG - 2011-08-20 07:34:59 --> URI Class Initialized
DEBUG - 2011-08-20 07:34:59 --> Router Class Initialized
ERROR - 2011-08-20 07:34:59 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-20 07:35:06 --> Config Class Initialized
DEBUG - 2011-08-20 07:35:06 --> Hooks Class Initialized
DEBUG - 2011-08-20 07:35:06 --> Utf8 Class Initialized
DEBUG - 2011-08-20 07:35:06 --> UTF-8 Support Enabled
DEBUG - 2011-08-20 07:35:06 --> URI Class Initialized
DEBUG - 2011-08-20 07:35:06 --> Router Class Initialized
DEBUG - 2011-08-20 07:35:06 --> Output Class Initialized
DEBUG - 2011-08-20 07:35:06 --> Input Class Initialized
DEBUG - 2011-08-20 07:35:06 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-20 07:35:06 --> Language Class Initialized
DEBUG - 2011-08-20 07:35:06 --> Loader Class Initialized
DEBUG - 2011-08-20 07:35:06 --> Controller Class Initialized
DEBUG - 2011-08-20 07:35:06 --> Model Class Initialized
DEBUG - 2011-08-20 07:35:06 --> Model Class Initialized
DEBUG - 2011-08-20 07:35:06 --> Model Class Initialized
DEBUG - 2011-08-20 07:35:06 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-20 07:35:06 --> Database Driver Class Initialized
DEBUG - 2011-08-20 07:35:07 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-20 07:35:07 --> Helper loaded: url_helper
DEBUG - 2011-08-20 07:35:07 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-20 07:35:07 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-20 07:35:07 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-20 07:35:07 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-20 07:35:07 --> Final output sent to browser
DEBUG - 2011-08-20 07:35:07 --> Total execution time: 0.3139
DEBUG - 2011-08-20 07:35:09 --> Config Class Initialized
DEBUG - 2011-08-20 07:35:09 --> Hooks Class Initialized
DEBUG - 2011-08-20 07:35:09 --> Utf8 Class Initialized
DEBUG - 2011-08-20 07:35:09 --> UTF-8 Support Enabled
DEBUG - 2011-08-20 07:35:09 --> URI Class Initialized
DEBUG - 2011-08-20 07:35:09 --> Router Class Initialized
ERROR - 2011-08-20 07:35:09 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-20 07:35:11 --> Config Class Initialized
DEBUG - 2011-08-20 07:35:11 --> Hooks Class Initialized
DEBUG - 2011-08-20 07:35:11 --> Utf8 Class Initialized
DEBUG - 2011-08-20 07:35:11 --> UTF-8 Support Enabled
DEBUG - 2011-08-20 07:35:11 --> URI Class Initialized
DEBUG - 2011-08-20 07:35:11 --> Router Class Initialized
DEBUG - 2011-08-20 07:35:11 --> Output Class Initialized
DEBUG - 2011-08-20 07:35:11 --> Input Class Initialized
DEBUG - 2011-08-20 07:35:11 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-20 07:35:11 --> Language Class Initialized
DEBUG - 2011-08-20 07:35:11 --> Loader Class Initialized
DEBUG - 2011-08-20 07:35:11 --> Controller Class Initialized
DEBUG - 2011-08-20 07:35:11 --> Model Class Initialized
DEBUG - 2011-08-20 07:35:11 --> Model Class Initialized
DEBUG - 2011-08-20 07:35:11 --> Model Class Initialized
DEBUG - 2011-08-20 07:35:11 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-20 07:35:11 --> Database Driver Class Initialized
DEBUG - 2011-08-20 07:35:11 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-20 07:35:11 --> Helper loaded: url_helper
DEBUG - 2011-08-20 07:35:11 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-20 07:35:11 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-20 07:35:11 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-20 07:35:11 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-20 07:35:11 --> Final output sent to browser
DEBUG - 2011-08-20 07:35:11 --> Total execution time: 0.0455
DEBUG - 2011-08-20 07:36:28 --> Config Class Initialized
DEBUG - 2011-08-20 07:36:28 --> Hooks Class Initialized
DEBUG - 2011-08-20 07:36:28 --> Utf8 Class Initialized
DEBUG - 2011-08-20 07:36:28 --> UTF-8 Support Enabled
DEBUG - 2011-08-20 07:36:28 --> URI Class Initialized
DEBUG - 2011-08-20 07:36:28 --> Router Class Initialized
DEBUG - 2011-08-20 07:36:28 --> Output Class Initialized
DEBUG - 2011-08-20 07:36:28 --> Input Class Initialized
DEBUG - 2011-08-20 07:36:28 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-20 07:36:28 --> Language Class Initialized
DEBUG - 2011-08-20 07:36:28 --> Loader Class Initialized
DEBUG - 2011-08-20 07:36:28 --> Controller Class Initialized
DEBUG - 2011-08-20 07:36:28 --> Model Class Initialized
DEBUG - 2011-08-20 07:36:28 --> Model Class Initialized
DEBUG - 2011-08-20 07:36:28 --> Model Class Initialized
DEBUG - 2011-08-20 07:36:28 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-20 07:36:28 --> Database Driver Class Initialized
DEBUG - 2011-08-20 07:36:29 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-20 07:36:29 --> Helper loaded: url_helper
DEBUG - 2011-08-20 07:36:29 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-20 07:36:29 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-20 07:36:29 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-20 07:36:29 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-20 07:36:29 --> Final output sent to browser
DEBUG - 2011-08-20 07:36:29 --> Total execution time: 0.1978
DEBUG - 2011-08-20 07:36:30 --> Config Class Initialized
DEBUG - 2011-08-20 07:36:30 --> Hooks Class Initialized
DEBUG - 2011-08-20 07:36:30 --> Utf8 Class Initialized
DEBUG - 2011-08-20 07:36:30 --> UTF-8 Support Enabled
DEBUG - 2011-08-20 07:36:30 --> URI Class Initialized
DEBUG - 2011-08-20 07:36:30 --> Router Class Initialized
ERROR - 2011-08-20 07:36:30 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-20 07:36:30 --> Config Class Initialized
DEBUG - 2011-08-20 07:36:30 --> Hooks Class Initialized
DEBUG - 2011-08-20 07:36:30 --> Utf8 Class Initialized
DEBUG - 2011-08-20 07:36:30 --> UTF-8 Support Enabled
DEBUG - 2011-08-20 07:36:30 --> URI Class Initialized
DEBUG - 2011-08-20 07:36:30 --> Router Class Initialized
ERROR - 2011-08-20 07:36:30 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-20 07:36:30 --> Config Class Initialized
DEBUG - 2011-08-20 07:36:30 --> Hooks Class Initialized
DEBUG - 2011-08-20 07:36:30 --> Utf8 Class Initialized
DEBUG - 2011-08-20 07:36:30 --> UTF-8 Support Enabled
DEBUG - 2011-08-20 07:36:30 --> URI Class Initialized
DEBUG - 2011-08-20 07:36:30 --> Router Class Initialized
ERROR - 2011-08-20 07:36:30 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-20 07:46:35 --> Config Class Initialized
DEBUG - 2011-08-20 07:46:35 --> Hooks Class Initialized
DEBUG - 2011-08-20 07:46:35 --> Utf8 Class Initialized
DEBUG - 2011-08-20 07:46:35 --> UTF-8 Support Enabled
DEBUG - 2011-08-20 07:46:35 --> URI Class Initialized
DEBUG - 2011-08-20 07:46:35 --> Router Class Initialized
DEBUG - 2011-08-20 07:46:35 --> Output Class Initialized
DEBUG - 2011-08-20 07:46:35 --> Input Class Initialized
DEBUG - 2011-08-20 07:46:35 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-20 07:46:35 --> Language Class Initialized
DEBUG - 2011-08-20 07:46:35 --> Loader Class Initialized
DEBUG - 2011-08-20 07:46:35 --> Controller Class Initialized
ERROR - 2011-08-20 07:46:35 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-20 07:46:35 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-20 07:46:35 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-20 07:46:35 --> Model Class Initialized
DEBUG - 2011-08-20 07:46:35 --> Model Class Initialized
DEBUG - 2011-08-20 07:46:35 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-20 07:46:35 --> Database Driver Class Initialized
DEBUG - 2011-08-20 07:46:35 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-20 07:46:35 --> Helper loaded: url_helper
DEBUG - 2011-08-20 07:46:35 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-20 07:46:35 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-20 07:46:35 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-20 07:46:35 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-20 07:46:35 --> Final output sent to browser
DEBUG - 2011-08-20 07:46:35 --> Total execution time: 0.0455
DEBUG - 2011-08-20 07:46:37 --> Config Class Initialized
DEBUG - 2011-08-20 07:46:37 --> Hooks Class Initialized
DEBUG - 2011-08-20 07:46:37 --> Utf8 Class Initialized
DEBUG - 2011-08-20 07:46:37 --> UTF-8 Support Enabled
DEBUG - 2011-08-20 07:46:37 --> URI Class Initialized
DEBUG - 2011-08-20 07:46:37 --> Router Class Initialized
DEBUG - 2011-08-20 07:46:37 --> Output Class Initialized
DEBUG - 2011-08-20 07:46:37 --> Input Class Initialized
DEBUG - 2011-08-20 07:46:37 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-20 07:46:37 --> Language Class Initialized
DEBUG - 2011-08-20 07:46:37 --> Loader Class Initialized
DEBUG - 2011-08-20 07:46:37 --> Controller Class Initialized
DEBUG - 2011-08-20 07:46:37 --> Model Class Initialized
DEBUG - 2011-08-20 07:46:37 --> Model Class Initialized
DEBUG - 2011-08-20 07:46:37 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-20 07:46:37 --> Database Driver Class Initialized
DEBUG - 2011-08-20 07:46:38 --> Final output sent to browser
DEBUG - 2011-08-20 07:46:38 --> Total execution time: 0.6690
DEBUG - 2011-08-20 07:46:41 --> Config Class Initialized
DEBUG - 2011-08-20 07:46:41 --> Hooks Class Initialized
DEBUG - 2011-08-20 07:46:41 --> Utf8 Class Initialized
DEBUG - 2011-08-20 07:46:41 --> UTF-8 Support Enabled
DEBUG - 2011-08-20 07:46:41 --> URI Class Initialized
DEBUG - 2011-08-20 07:46:41 --> Router Class Initialized
ERROR - 2011-08-20 07:46:41 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-20 07:47:06 --> Config Class Initialized
DEBUG - 2011-08-20 07:47:06 --> Hooks Class Initialized
DEBUG - 2011-08-20 07:47:06 --> Utf8 Class Initialized
DEBUG - 2011-08-20 07:47:06 --> UTF-8 Support Enabled
DEBUG - 2011-08-20 07:47:06 --> URI Class Initialized
DEBUG - 2011-08-20 07:47:06 --> Router Class Initialized
DEBUG - 2011-08-20 07:47:06 --> Output Class Initialized
DEBUG - 2011-08-20 07:47:06 --> Input Class Initialized
DEBUG - 2011-08-20 07:47:06 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-20 07:47:06 --> Language Class Initialized
DEBUG - 2011-08-20 07:47:06 --> Loader Class Initialized
DEBUG - 2011-08-20 07:47:06 --> Controller Class Initialized
ERROR - 2011-08-20 07:47:06 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-20 07:47:06 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-20 07:47:06 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-20 07:47:06 --> Model Class Initialized
DEBUG - 2011-08-20 07:47:06 --> Model Class Initialized
DEBUG - 2011-08-20 07:47:06 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-20 07:47:06 --> Database Driver Class Initialized
DEBUG - 2011-08-20 07:47:06 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-20 07:47:06 --> Helper loaded: url_helper
DEBUG - 2011-08-20 07:47:06 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-20 07:47:06 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-20 07:47:06 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-20 07:47:06 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-20 07:47:06 --> Final output sent to browser
DEBUG - 2011-08-20 07:47:06 --> Total execution time: 0.0415
DEBUG - 2011-08-20 07:47:07 --> Config Class Initialized
DEBUG - 2011-08-20 07:47:07 --> Hooks Class Initialized
DEBUG - 2011-08-20 07:47:07 --> Utf8 Class Initialized
DEBUG - 2011-08-20 07:47:07 --> UTF-8 Support Enabled
DEBUG - 2011-08-20 07:47:07 --> URI Class Initialized
DEBUG - 2011-08-20 07:47:07 --> Router Class Initialized
DEBUG - 2011-08-20 07:47:07 --> Output Class Initialized
DEBUG - 2011-08-20 07:47:07 --> Input Class Initialized
DEBUG - 2011-08-20 07:47:07 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-20 07:47:07 --> Language Class Initialized
DEBUG - 2011-08-20 07:47:07 --> Loader Class Initialized
DEBUG - 2011-08-20 07:47:07 --> Controller Class Initialized
DEBUG - 2011-08-20 07:47:07 --> Model Class Initialized
DEBUG - 2011-08-20 07:47:07 --> Model Class Initialized
DEBUG - 2011-08-20 07:47:07 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-20 07:47:07 --> Database Driver Class Initialized
DEBUG - 2011-08-20 07:47:08 --> Final output sent to browser
DEBUG - 2011-08-20 07:47:08 --> Total execution time: 0.6431
DEBUG - 2011-08-20 07:47:16 --> Config Class Initialized
DEBUG - 2011-08-20 07:47:16 --> Hooks Class Initialized
DEBUG - 2011-08-20 07:47:16 --> Utf8 Class Initialized
DEBUG - 2011-08-20 07:47:16 --> UTF-8 Support Enabled
DEBUG - 2011-08-20 07:47:16 --> URI Class Initialized
DEBUG - 2011-08-20 07:47:16 --> Router Class Initialized
DEBUG - 2011-08-20 07:47:16 --> Output Class Initialized
DEBUG - 2011-08-20 07:47:16 --> Input Class Initialized
DEBUG - 2011-08-20 07:47:16 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-20 07:47:16 --> Language Class Initialized
DEBUG - 2011-08-20 07:47:16 --> Loader Class Initialized
DEBUG - 2011-08-20 07:47:16 --> Controller Class Initialized
ERROR - 2011-08-20 07:47:16 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-20 07:47:16 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-20 07:47:16 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-20 07:47:16 --> Model Class Initialized
DEBUG - 2011-08-20 07:47:16 --> Model Class Initialized
DEBUG - 2011-08-20 07:47:16 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-20 07:47:16 --> Database Driver Class Initialized
DEBUG - 2011-08-20 07:47:16 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-20 07:47:16 --> Helper loaded: url_helper
DEBUG - 2011-08-20 07:47:16 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-20 07:47:16 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-20 07:47:16 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-20 07:47:16 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-20 07:47:16 --> Final output sent to browser
DEBUG - 2011-08-20 07:47:16 --> Total execution time: 0.0277
DEBUG - 2011-08-20 07:47:17 --> Config Class Initialized
DEBUG - 2011-08-20 07:47:17 --> Hooks Class Initialized
DEBUG - 2011-08-20 07:47:17 --> Utf8 Class Initialized
DEBUG - 2011-08-20 07:47:17 --> UTF-8 Support Enabled
DEBUG - 2011-08-20 07:47:17 --> URI Class Initialized
DEBUG - 2011-08-20 07:47:17 --> Router Class Initialized
DEBUG - 2011-08-20 07:47:17 --> Output Class Initialized
DEBUG - 2011-08-20 07:47:17 --> Input Class Initialized
DEBUG - 2011-08-20 07:47:17 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-20 07:47:17 --> Language Class Initialized
DEBUG - 2011-08-20 07:47:17 --> Loader Class Initialized
DEBUG - 2011-08-20 07:47:17 --> Controller Class Initialized
DEBUG - 2011-08-20 07:47:17 --> Model Class Initialized
DEBUG - 2011-08-20 07:47:17 --> Model Class Initialized
DEBUG - 2011-08-20 07:47:17 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-20 07:47:17 --> Database Driver Class Initialized
DEBUG - 2011-08-20 07:47:18 --> Final output sent to browser
DEBUG - 2011-08-20 07:47:18 --> Total execution time: 0.5219
DEBUG - 2011-08-20 07:47:45 --> Config Class Initialized
DEBUG - 2011-08-20 07:47:45 --> Hooks Class Initialized
DEBUG - 2011-08-20 07:47:45 --> Utf8 Class Initialized
DEBUG - 2011-08-20 07:47:45 --> UTF-8 Support Enabled
DEBUG - 2011-08-20 07:47:45 --> URI Class Initialized
DEBUG - 2011-08-20 07:47:45 --> Router Class Initialized
DEBUG - 2011-08-20 07:47:45 --> Output Class Initialized
DEBUG - 2011-08-20 07:47:45 --> Input Class Initialized
DEBUG - 2011-08-20 07:47:45 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-20 07:47:45 --> Language Class Initialized
DEBUG - 2011-08-20 07:47:45 --> Loader Class Initialized
DEBUG - 2011-08-20 07:47:45 --> Controller Class Initialized
ERROR - 2011-08-20 07:47:45 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-20 07:47:45 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-20 07:47:45 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-20 07:47:45 --> Model Class Initialized
DEBUG - 2011-08-20 07:47:45 --> Model Class Initialized
DEBUG - 2011-08-20 07:47:45 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-20 07:47:45 --> Database Driver Class Initialized
DEBUG - 2011-08-20 07:47:45 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-20 07:47:45 --> Helper loaded: url_helper
DEBUG - 2011-08-20 07:47:45 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-20 07:47:45 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-20 07:47:45 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-20 07:47:45 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-20 07:47:45 --> Final output sent to browser
DEBUG - 2011-08-20 07:47:45 --> Total execution time: 0.0306
DEBUG - 2011-08-20 07:47:55 --> Config Class Initialized
DEBUG - 2011-08-20 07:47:55 --> Hooks Class Initialized
DEBUG - 2011-08-20 07:47:55 --> Utf8 Class Initialized
DEBUG - 2011-08-20 07:47:55 --> UTF-8 Support Enabled
DEBUG - 2011-08-20 07:47:55 --> URI Class Initialized
DEBUG - 2011-08-20 07:47:55 --> Router Class Initialized
DEBUG - 2011-08-20 07:47:55 --> Output Class Initialized
DEBUG - 2011-08-20 07:47:55 --> Input Class Initialized
DEBUG - 2011-08-20 07:47:55 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-20 07:47:55 --> Language Class Initialized
DEBUG - 2011-08-20 07:47:55 --> Loader Class Initialized
DEBUG - 2011-08-20 07:47:55 --> Controller Class Initialized
DEBUG - 2011-08-20 07:47:55 --> Model Class Initialized
DEBUG - 2011-08-20 07:47:55 --> Model Class Initialized
DEBUG - 2011-08-20 07:47:55 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-20 07:47:55 --> Database Driver Class Initialized
DEBUG - 2011-08-20 07:47:56 --> Final output sent to browser
DEBUG - 2011-08-20 07:47:56 --> Total execution time: 0.4517
DEBUG - 2011-08-20 07:48:15 --> Config Class Initialized
DEBUG - 2011-08-20 07:48:15 --> Hooks Class Initialized
DEBUG - 2011-08-20 07:48:15 --> Utf8 Class Initialized
DEBUG - 2011-08-20 07:48:15 --> UTF-8 Support Enabled
DEBUG - 2011-08-20 07:48:15 --> URI Class Initialized
DEBUG - 2011-08-20 07:48:15 --> Router Class Initialized
ERROR - 2011-08-20 07:48:15 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-20 07:48:22 --> Config Class Initialized
DEBUG - 2011-08-20 07:48:22 --> Hooks Class Initialized
DEBUG - 2011-08-20 07:48:22 --> Utf8 Class Initialized
DEBUG - 2011-08-20 07:48:22 --> UTF-8 Support Enabled
DEBUG - 2011-08-20 07:48:22 --> URI Class Initialized
DEBUG - 2011-08-20 07:48:22 --> Router Class Initialized
DEBUG - 2011-08-20 07:48:22 --> Output Class Initialized
DEBUG - 2011-08-20 07:48:22 --> Input Class Initialized
DEBUG - 2011-08-20 07:48:22 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-20 07:48:22 --> Language Class Initialized
DEBUG - 2011-08-20 07:48:22 --> Loader Class Initialized
DEBUG - 2011-08-20 07:48:22 --> Controller Class Initialized
ERROR - 2011-08-20 07:48:22 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-20 07:48:22 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-20 07:48:22 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-20 07:48:22 --> Model Class Initialized
DEBUG - 2011-08-20 07:48:22 --> Model Class Initialized
DEBUG - 2011-08-20 07:48:22 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-20 07:48:22 --> Database Driver Class Initialized
DEBUG - 2011-08-20 07:48:22 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-20 07:48:22 --> Helper loaded: url_helper
DEBUG - 2011-08-20 07:48:22 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-20 07:48:22 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-20 07:48:22 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-20 07:48:22 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-20 07:48:22 --> Final output sent to browser
DEBUG - 2011-08-20 07:48:22 --> Total execution time: 0.0312
DEBUG - 2011-08-20 07:48:29 --> Config Class Initialized
DEBUG - 2011-08-20 07:48:29 --> Hooks Class Initialized
DEBUG - 2011-08-20 07:48:29 --> Utf8 Class Initialized
DEBUG - 2011-08-20 07:48:29 --> UTF-8 Support Enabled
DEBUG - 2011-08-20 07:48:29 --> URI Class Initialized
DEBUG - 2011-08-20 07:48:29 --> Router Class Initialized
DEBUG - 2011-08-20 07:48:29 --> Output Class Initialized
DEBUG - 2011-08-20 07:48:29 --> Input Class Initialized
DEBUG - 2011-08-20 07:48:29 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-20 07:48:29 --> Language Class Initialized
DEBUG - 2011-08-20 07:48:29 --> Loader Class Initialized
DEBUG - 2011-08-20 07:48:29 --> Controller Class Initialized
DEBUG - 2011-08-20 07:48:29 --> Model Class Initialized
DEBUG - 2011-08-20 07:48:29 --> Model Class Initialized
DEBUG - 2011-08-20 07:48:29 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-20 07:48:29 --> Database Driver Class Initialized
DEBUG - 2011-08-20 07:48:30 --> Final output sent to browser
DEBUG - 2011-08-20 07:48:30 --> Total execution time: 0.5405
DEBUG - 2011-08-20 07:48:31 --> Config Class Initialized
DEBUG - 2011-08-20 07:48:31 --> Hooks Class Initialized
DEBUG - 2011-08-20 07:48:31 --> Utf8 Class Initialized
DEBUG - 2011-08-20 07:48:31 --> UTF-8 Support Enabled
DEBUG - 2011-08-20 07:48:31 --> URI Class Initialized
DEBUG - 2011-08-20 07:48:31 --> Router Class Initialized
DEBUG - 2011-08-20 07:48:31 --> Output Class Initialized
DEBUG - 2011-08-20 07:48:31 --> Input Class Initialized
DEBUG - 2011-08-20 07:48:31 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-20 07:48:31 --> Language Class Initialized
DEBUG - 2011-08-20 07:48:31 --> Loader Class Initialized
DEBUG - 2011-08-20 07:48:31 --> Controller Class Initialized
ERROR - 2011-08-20 07:48:31 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-20 07:48:31 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-20 07:48:31 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-20 07:48:31 --> Model Class Initialized
DEBUG - 2011-08-20 07:48:31 --> Model Class Initialized
DEBUG - 2011-08-20 07:48:31 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-20 07:48:31 --> Database Driver Class Initialized
DEBUG - 2011-08-20 07:48:31 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-20 07:48:31 --> Helper loaded: url_helper
DEBUG - 2011-08-20 07:48:31 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-20 07:48:31 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-20 07:48:31 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-20 07:48:31 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-20 07:48:31 --> Final output sent to browser
DEBUG - 2011-08-20 07:48:31 --> Total execution time: 0.0281
DEBUG - 2011-08-20 08:11:35 --> Config Class Initialized
DEBUG - 2011-08-20 08:11:35 --> Hooks Class Initialized
DEBUG - 2011-08-20 08:11:35 --> Utf8 Class Initialized
DEBUG - 2011-08-20 08:11:35 --> UTF-8 Support Enabled
DEBUG - 2011-08-20 08:11:35 --> URI Class Initialized
DEBUG - 2011-08-20 08:11:35 --> Router Class Initialized
DEBUG - 2011-08-20 08:11:35 --> Output Class Initialized
DEBUG - 2011-08-20 08:11:35 --> Input Class Initialized
DEBUG - 2011-08-20 08:11:35 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-20 08:11:35 --> Language Class Initialized
DEBUG - 2011-08-20 08:11:35 --> Loader Class Initialized
DEBUG - 2011-08-20 08:11:35 --> Controller Class Initialized
DEBUG - 2011-08-20 08:11:35 --> Model Class Initialized
DEBUG - 2011-08-20 08:11:35 --> Model Class Initialized
DEBUG - 2011-08-20 08:11:35 --> Model Class Initialized
DEBUG - 2011-08-20 08:11:35 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-20 08:11:35 --> Database Driver Class Initialized
DEBUG - 2011-08-20 08:11:35 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-20 08:11:35 --> Helper loaded: url_helper
DEBUG - 2011-08-20 08:11:35 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-20 08:11:35 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-20 08:11:35 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-20 08:11:35 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-20 08:11:35 --> Final output sent to browser
DEBUG - 2011-08-20 08:11:35 --> Total execution time: 0.3130
DEBUG - 2011-08-20 08:11:37 --> Config Class Initialized
DEBUG - 2011-08-20 08:11:37 --> Hooks Class Initialized
DEBUG - 2011-08-20 08:11:37 --> Utf8 Class Initialized
DEBUG - 2011-08-20 08:11:37 --> UTF-8 Support Enabled
DEBUG - 2011-08-20 08:11:37 --> URI Class Initialized
DEBUG - 2011-08-20 08:11:37 --> Router Class Initialized
DEBUG - 2011-08-20 08:11:37 --> Output Class Initialized
DEBUG - 2011-08-20 08:11:37 --> Input Class Initialized
DEBUG - 2011-08-20 08:11:37 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-20 08:11:37 --> Language Class Initialized
DEBUG - 2011-08-20 08:11:37 --> Loader Class Initialized
DEBUG - 2011-08-20 08:11:37 --> Controller Class Initialized
DEBUG - 2011-08-20 08:11:37 --> Model Class Initialized
DEBUG - 2011-08-20 08:11:37 --> Model Class Initialized
DEBUG - 2011-08-20 08:11:37 --> Model Class Initialized
DEBUG - 2011-08-20 08:11:37 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-20 08:11:37 --> Database Driver Class Initialized
DEBUG - 2011-08-20 08:11:37 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-20 08:11:37 --> Helper loaded: url_helper
DEBUG - 2011-08-20 08:11:37 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-20 08:11:37 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-20 08:11:37 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-20 08:11:37 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-20 08:11:37 --> Final output sent to browser
DEBUG - 2011-08-20 08:11:37 --> Total execution time: 0.0417
DEBUG - 2011-08-20 08:11:39 --> Config Class Initialized
DEBUG - 2011-08-20 08:11:39 --> Hooks Class Initialized
DEBUG - 2011-08-20 08:11:39 --> Utf8 Class Initialized
DEBUG - 2011-08-20 08:11:39 --> UTF-8 Support Enabled
DEBUG - 2011-08-20 08:11:39 --> URI Class Initialized
DEBUG - 2011-08-20 08:11:39 --> Router Class Initialized
ERROR - 2011-08-20 08:11:39 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-20 08:24:43 --> Config Class Initialized
DEBUG - 2011-08-20 08:24:43 --> Hooks Class Initialized
DEBUG - 2011-08-20 08:24:43 --> Utf8 Class Initialized
DEBUG - 2011-08-20 08:24:43 --> UTF-8 Support Enabled
DEBUG - 2011-08-20 08:24:43 --> URI Class Initialized
DEBUG - 2011-08-20 08:24:43 --> Router Class Initialized
DEBUG - 2011-08-20 08:24:43 --> Output Class Initialized
DEBUG - 2011-08-20 08:24:43 --> Input Class Initialized
DEBUG - 2011-08-20 08:24:43 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-20 08:24:43 --> Language Class Initialized
DEBUG - 2011-08-20 08:24:43 --> Loader Class Initialized
DEBUG - 2011-08-20 08:24:43 --> Controller Class Initialized
ERROR - 2011-08-20 08:24:43 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-20 08:24:43 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-20 08:24:43 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-20 08:24:43 --> Model Class Initialized
DEBUG - 2011-08-20 08:24:43 --> Model Class Initialized
DEBUG - 2011-08-20 08:24:43 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-20 08:24:44 --> Database Driver Class Initialized
DEBUG - 2011-08-20 08:24:44 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-20 08:24:44 --> Helper loaded: url_helper
DEBUG - 2011-08-20 08:24:44 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-20 08:24:44 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-20 08:24:44 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-20 08:24:44 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-20 08:24:44 --> Final output sent to browser
DEBUG - 2011-08-20 08:24:44 --> Total execution time: 0.1442
DEBUG - 2011-08-20 08:24:50 --> Config Class Initialized
DEBUG - 2011-08-20 08:24:50 --> Hooks Class Initialized
DEBUG - 2011-08-20 08:24:50 --> Utf8 Class Initialized
DEBUG - 2011-08-20 08:24:50 --> UTF-8 Support Enabled
DEBUG - 2011-08-20 08:24:50 --> URI Class Initialized
DEBUG - 2011-08-20 08:24:50 --> Router Class Initialized
DEBUG - 2011-08-20 08:24:50 --> Output Class Initialized
DEBUG - 2011-08-20 08:24:50 --> Input Class Initialized
DEBUG - 2011-08-20 08:24:50 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-20 08:24:50 --> Language Class Initialized
DEBUG - 2011-08-20 08:24:50 --> Loader Class Initialized
DEBUG - 2011-08-20 08:24:50 --> Controller Class Initialized
DEBUG - 2011-08-20 08:24:50 --> Model Class Initialized
DEBUG - 2011-08-20 08:24:50 --> Model Class Initialized
DEBUG - 2011-08-20 08:24:50 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-20 08:24:50 --> Database Driver Class Initialized
DEBUG - 2011-08-20 08:24:51 --> Final output sent to browser
DEBUG - 2011-08-20 08:24:51 --> Total execution time: 0.8320
DEBUG - 2011-08-20 08:24:56 --> Config Class Initialized
DEBUG - 2011-08-20 08:24:56 --> Hooks Class Initialized
DEBUG - 2011-08-20 08:24:56 --> Utf8 Class Initialized
DEBUG - 2011-08-20 08:24:56 --> UTF-8 Support Enabled
DEBUG - 2011-08-20 08:24:56 --> URI Class Initialized
DEBUG - 2011-08-20 08:24:56 --> Router Class Initialized
ERROR - 2011-08-20 08:24:56 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-20 08:27:00 --> Config Class Initialized
DEBUG - 2011-08-20 08:27:00 --> Hooks Class Initialized
DEBUG - 2011-08-20 08:27:00 --> Utf8 Class Initialized
DEBUG - 2011-08-20 08:27:00 --> UTF-8 Support Enabled
DEBUG - 2011-08-20 08:27:00 --> URI Class Initialized
DEBUG - 2011-08-20 08:27:00 --> Router Class Initialized
DEBUG - 2011-08-20 08:27:00 --> Output Class Initialized
DEBUG - 2011-08-20 08:27:00 --> Input Class Initialized
DEBUG - 2011-08-20 08:27:00 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-20 08:27:00 --> Language Class Initialized
DEBUG - 2011-08-20 08:27:00 --> Loader Class Initialized
DEBUG - 2011-08-20 08:27:00 --> Controller Class Initialized
ERROR - 2011-08-20 08:27:00 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-20 08:27:00 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-20 08:27:00 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-20 08:27:00 --> Model Class Initialized
DEBUG - 2011-08-20 08:27:00 --> Model Class Initialized
DEBUG - 2011-08-20 08:27:00 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-20 08:27:00 --> Database Driver Class Initialized
DEBUG - 2011-08-20 08:27:00 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-20 08:27:00 --> Helper loaded: url_helper
DEBUG - 2011-08-20 08:27:00 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-20 08:27:00 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-20 08:27:00 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-20 08:27:00 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-20 08:27:00 --> Final output sent to browser
DEBUG - 2011-08-20 08:27:00 --> Total execution time: 0.0709
DEBUG - 2011-08-20 08:27:01 --> Config Class Initialized
DEBUG - 2011-08-20 08:27:01 --> Hooks Class Initialized
DEBUG - 2011-08-20 08:27:01 --> Utf8 Class Initialized
DEBUG - 2011-08-20 08:27:01 --> UTF-8 Support Enabled
DEBUG - 2011-08-20 08:27:01 --> URI Class Initialized
DEBUG - 2011-08-20 08:27:01 --> Router Class Initialized
DEBUG - 2011-08-20 08:27:01 --> Output Class Initialized
DEBUG - 2011-08-20 08:27:01 --> Input Class Initialized
DEBUG - 2011-08-20 08:27:01 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-20 08:27:01 --> Language Class Initialized
DEBUG - 2011-08-20 08:27:01 --> Loader Class Initialized
DEBUG - 2011-08-20 08:27:01 --> Controller Class Initialized
DEBUG - 2011-08-20 08:27:01 --> Model Class Initialized
DEBUG - 2011-08-20 08:27:01 --> Model Class Initialized
DEBUG - 2011-08-20 08:27:01 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-20 08:27:01 --> Database Driver Class Initialized
DEBUG - 2011-08-20 08:27:02 --> Final output sent to browser
DEBUG - 2011-08-20 08:27:02 --> Total execution time: 0.5317
DEBUG - 2011-08-20 08:27:03 --> Config Class Initialized
DEBUG - 2011-08-20 08:27:03 --> Hooks Class Initialized
DEBUG - 2011-08-20 08:27:03 --> Utf8 Class Initialized
DEBUG - 2011-08-20 08:27:03 --> UTF-8 Support Enabled
DEBUG - 2011-08-20 08:27:03 --> URI Class Initialized
DEBUG - 2011-08-20 08:27:03 --> Router Class Initialized
ERROR - 2011-08-20 08:27:03 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-20 08:56:07 --> Config Class Initialized
DEBUG - 2011-08-20 08:56:07 --> Hooks Class Initialized
DEBUG - 2011-08-20 08:56:07 --> Utf8 Class Initialized
DEBUG - 2011-08-20 08:56:07 --> UTF-8 Support Enabled
DEBUG - 2011-08-20 08:56:07 --> URI Class Initialized
DEBUG - 2011-08-20 08:56:07 --> Router Class Initialized
ERROR - 2011-08-20 08:56:07 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-08-20 08:57:00 --> Config Class Initialized
DEBUG - 2011-08-20 08:57:00 --> Hooks Class Initialized
DEBUG - 2011-08-20 08:57:00 --> Utf8 Class Initialized
DEBUG - 2011-08-20 08:57:00 --> UTF-8 Support Enabled
DEBUG - 2011-08-20 08:57:00 --> URI Class Initialized
DEBUG - 2011-08-20 08:57:00 --> Router Class Initialized
DEBUG - 2011-08-20 08:57:00 --> Output Class Initialized
DEBUG - 2011-08-20 08:57:00 --> Input Class Initialized
DEBUG - 2011-08-20 08:57:00 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-20 08:57:00 --> Language Class Initialized
DEBUG - 2011-08-20 08:57:00 --> Loader Class Initialized
DEBUG - 2011-08-20 08:57:00 --> Controller Class Initialized
ERROR - 2011-08-20 08:57:00 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-20 08:57:00 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-20 08:57:00 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-20 08:57:00 --> Model Class Initialized
DEBUG - 2011-08-20 08:57:00 --> Model Class Initialized
DEBUG - 2011-08-20 08:57:00 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-20 08:57:00 --> Database Driver Class Initialized
DEBUG - 2011-08-20 08:57:00 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-20 08:57:00 --> Helper loaded: url_helper
DEBUG - 2011-08-20 08:57:00 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-20 08:57:00 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-20 08:57:00 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-20 08:57:00 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-20 08:57:00 --> Final output sent to browser
DEBUG - 2011-08-20 08:57:00 --> Total execution time: 0.0473
DEBUG - 2011-08-20 09:00:54 --> Config Class Initialized
DEBUG - 2011-08-20 09:00:54 --> Hooks Class Initialized
DEBUG - 2011-08-20 09:00:54 --> Utf8 Class Initialized
DEBUG - 2011-08-20 09:00:54 --> UTF-8 Support Enabled
DEBUG - 2011-08-20 09:00:54 --> URI Class Initialized
DEBUG - 2011-08-20 09:00:54 --> Router Class Initialized
DEBUG - 2011-08-20 09:00:54 --> Output Class Initialized
DEBUG - 2011-08-20 09:00:54 --> Input Class Initialized
DEBUG - 2011-08-20 09:00:54 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-20 09:00:54 --> Language Class Initialized
DEBUG - 2011-08-20 09:00:54 --> Loader Class Initialized
DEBUG - 2011-08-20 09:00:54 --> Controller Class Initialized
ERROR - 2011-08-20 09:00:54 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-20 09:00:54 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-20 09:00:54 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-20 09:00:54 --> Model Class Initialized
DEBUG - 2011-08-20 09:00:54 --> Model Class Initialized
DEBUG - 2011-08-20 09:00:54 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-20 09:00:54 --> Database Driver Class Initialized
DEBUG - 2011-08-20 09:00:54 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-20 09:00:54 --> Helper loaded: url_helper
DEBUG - 2011-08-20 09:00:54 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-20 09:00:54 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-20 09:00:54 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-20 09:00:54 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-20 09:00:54 --> Final output sent to browser
DEBUG - 2011-08-20 09:00:54 --> Total execution time: 0.0647
DEBUG - 2011-08-20 09:00:55 --> Config Class Initialized
DEBUG - 2011-08-20 09:00:55 --> Hooks Class Initialized
DEBUG - 2011-08-20 09:00:55 --> Utf8 Class Initialized
DEBUG - 2011-08-20 09:00:55 --> UTF-8 Support Enabled
DEBUG - 2011-08-20 09:00:55 --> URI Class Initialized
DEBUG - 2011-08-20 09:00:55 --> Router Class Initialized
DEBUG - 2011-08-20 09:00:55 --> Output Class Initialized
DEBUG - 2011-08-20 09:00:55 --> Input Class Initialized
DEBUG - 2011-08-20 09:00:55 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-20 09:00:55 --> Language Class Initialized
DEBUG - 2011-08-20 09:00:55 --> Loader Class Initialized
DEBUG - 2011-08-20 09:00:55 --> Controller Class Initialized
DEBUG - 2011-08-20 09:00:55 --> Model Class Initialized
DEBUG - 2011-08-20 09:00:55 --> Model Class Initialized
DEBUG - 2011-08-20 09:00:55 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-20 09:00:55 --> Database Driver Class Initialized
DEBUG - 2011-08-20 09:00:56 --> Final output sent to browser
DEBUG - 2011-08-20 09:00:56 --> Total execution time: 0.5089
DEBUG - 2011-08-20 09:01:02 --> Config Class Initialized
DEBUG - 2011-08-20 09:01:02 --> Hooks Class Initialized
DEBUG - 2011-08-20 09:01:02 --> Utf8 Class Initialized
DEBUG - 2011-08-20 09:01:02 --> UTF-8 Support Enabled
DEBUG - 2011-08-20 09:01:02 --> URI Class Initialized
DEBUG - 2011-08-20 09:01:02 --> Router Class Initialized
ERROR - 2011-08-20 09:01:02 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-20 09:01:24 --> Config Class Initialized
DEBUG - 2011-08-20 09:01:24 --> Hooks Class Initialized
DEBUG - 2011-08-20 09:01:24 --> Utf8 Class Initialized
DEBUG - 2011-08-20 09:01:24 --> UTF-8 Support Enabled
DEBUG - 2011-08-20 09:01:24 --> URI Class Initialized
DEBUG - 2011-08-20 09:01:24 --> Router Class Initialized
DEBUG - 2011-08-20 09:01:24 --> Output Class Initialized
DEBUG - 2011-08-20 09:01:24 --> Input Class Initialized
DEBUG - 2011-08-20 09:01:24 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-20 09:01:24 --> Language Class Initialized
DEBUG - 2011-08-20 09:01:24 --> Loader Class Initialized
DEBUG - 2011-08-20 09:01:24 --> Controller Class Initialized
ERROR - 2011-08-20 09:01:24 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-20 09:01:24 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-20 09:01:24 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-20 09:01:24 --> Model Class Initialized
DEBUG - 2011-08-20 09:01:24 --> Model Class Initialized
DEBUG - 2011-08-20 09:01:24 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-20 09:01:24 --> Database Driver Class Initialized
DEBUG - 2011-08-20 09:01:24 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-20 09:01:24 --> Helper loaded: url_helper
DEBUG - 2011-08-20 09:01:24 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-20 09:01:24 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-20 09:01:24 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-20 09:01:24 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-20 09:01:24 --> Final output sent to browser
DEBUG - 2011-08-20 09:01:24 --> Total execution time: 0.1690
DEBUG - 2011-08-20 09:01:27 --> Config Class Initialized
DEBUG - 2011-08-20 09:01:27 --> Hooks Class Initialized
DEBUG - 2011-08-20 09:01:27 --> Utf8 Class Initialized
DEBUG - 2011-08-20 09:01:27 --> UTF-8 Support Enabled
DEBUG - 2011-08-20 09:01:27 --> URI Class Initialized
DEBUG - 2011-08-20 09:01:27 --> Router Class Initialized
DEBUG - 2011-08-20 09:01:27 --> Output Class Initialized
DEBUG - 2011-08-20 09:01:27 --> Input Class Initialized
DEBUG - 2011-08-20 09:01:27 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-20 09:01:27 --> Language Class Initialized
DEBUG - 2011-08-20 09:01:27 --> Loader Class Initialized
DEBUG - 2011-08-20 09:01:27 --> Controller Class Initialized
DEBUG - 2011-08-20 09:01:27 --> Model Class Initialized
DEBUG - 2011-08-20 09:01:27 --> Model Class Initialized
DEBUG - 2011-08-20 09:01:27 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-20 09:01:27 --> Database Driver Class Initialized
DEBUG - 2011-08-20 09:01:28 --> Final output sent to browser
DEBUG - 2011-08-20 09:01:28 --> Total execution time: 1.0281
DEBUG - 2011-08-20 09:01:33 --> Config Class Initialized
DEBUG - 2011-08-20 09:01:33 --> Hooks Class Initialized
DEBUG - 2011-08-20 09:01:33 --> Utf8 Class Initialized
DEBUG - 2011-08-20 09:01:33 --> UTF-8 Support Enabled
DEBUG - 2011-08-20 09:01:33 --> URI Class Initialized
DEBUG - 2011-08-20 09:01:33 --> Router Class Initialized
ERROR - 2011-08-20 09:01:33 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-20 09:18:44 --> Config Class Initialized
DEBUG - 2011-08-20 09:18:44 --> Hooks Class Initialized
DEBUG - 2011-08-20 09:18:44 --> Utf8 Class Initialized
DEBUG - 2011-08-20 09:18:44 --> UTF-8 Support Enabled
DEBUG - 2011-08-20 09:18:44 --> URI Class Initialized
DEBUG - 2011-08-20 09:18:44 --> Router Class Initialized
ERROR - 2011-08-20 09:18:44 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-08-20 09:18:44 --> Config Class Initialized
DEBUG - 2011-08-20 09:18:44 --> Hooks Class Initialized
DEBUG - 2011-08-20 09:18:44 --> Utf8 Class Initialized
DEBUG - 2011-08-20 09:18:44 --> UTF-8 Support Enabled
DEBUG - 2011-08-20 09:18:44 --> URI Class Initialized
DEBUG - 2011-08-20 09:18:44 --> Router Class Initialized
DEBUG - 2011-08-20 09:18:44 --> Output Class Initialized
DEBUG - 2011-08-20 09:18:44 --> Input Class Initialized
DEBUG - 2011-08-20 09:18:44 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-20 09:18:44 --> Language Class Initialized
DEBUG - 2011-08-20 09:18:44 --> Loader Class Initialized
DEBUG - 2011-08-20 09:18:44 --> Controller Class Initialized
ERROR - 2011-08-20 09:18:44 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-20 09:18:44 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-20 09:18:44 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-20 09:18:44 --> Model Class Initialized
DEBUG - 2011-08-20 09:18:44 --> Model Class Initialized
DEBUG - 2011-08-20 09:18:44 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-20 09:18:44 --> Database Driver Class Initialized
DEBUG - 2011-08-20 09:18:44 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-20 09:18:44 --> Helper loaded: url_helper
DEBUG - 2011-08-20 09:18:44 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-20 09:18:44 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-20 09:18:44 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-20 09:18:44 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-20 09:18:44 --> Final output sent to browser
DEBUG - 2011-08-20 09:18:44 --> Total execution time: 0.0492
DEBUG - 2011-08-20 09:37:21 --> Config Class Initialized
DEBUG - 2011-08-20 09:37:21 --> Hooks Class Initialized
DEBUG - 2011-08-20 09:37:21 --> Utf8 Class Initialized
DEBUG - 2011-08-20 09:37:21 --> UTF-8 Support Enabled
DEBUG - 2011-08-20 09:37:21 --> URI Class Initialized
DEBUG - 2011-08-20 09:37:21 --> Router Class Initialized
DEBUG - 2011-08-20 09:37:21 --> Output Class Initialized
DEBUG - 2011-08-20 09:37:21 --> Input Class Initialized
DEBUG - 2011-08-20 09:37:21 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-20 09:37:21 --> Language Class Initialized
DEBUG - 2011-08-20 09:37:21 --> Loader Class Initialized
DEBUG - 2011-08-20 09:37:21 --> Controller Class Initialized
ERROR - 2011-08-20 09:37:21 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-20 09:37:21 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-20 09:37:21 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-20 09:37:21 --> Model Class Initialized
DEBUG - 2011-08-20 09:37:21 --> Model Class Initialized
DEBUG - 2011-08-20 09:37:21 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-20 09:37:21 --> Database Driver Class Initialized
DEBUG - 2011-08-20 09:37:21 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-20 09:37:21 --> Helper loaded: url_helper
DEBUG - 2011-08-20 09:37:21 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-20 09:37:21 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-20 09:37:21 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-20 09:37:21 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-20 09:37:21 --> Final output sent to browser
DEBUG - 2011-08-20 09:37:21 --> Total execution time: 0.1620
DEBUG - 2011-08-20 09:37:23 --> Config Class Initialized
DEBUG - 2011-08-20 09:37:23 --> Hooks Class Initialized
DEBUG - 2011-08-20 09:37:23 --> Utf8 Class Initialized
DEBUG - 2011-08-20 09:37:23 --> UTF-8 Support Enabled
DEBUG - 2011-08-20 09:37:23 --> URI Class Initialized
DEBUG - 2011-08-20 09:37:23 --> Router Class Initialized
DEBUG - 2011-08-20 09:37:23 --> Output Class Initialized
DEBUG - 2011-08-20 09:37:23 --> Input Class Initialized
DEBUG - 2011-08-20 09:37:23 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-20 09:37:23 --> Language Class Initialized
DEBUG - 2011-08-20 09:37:23 --> Loader Class Initialized
DEBUG - 2011-08-20 09:37:23 --> Controller Class Initialized
DEBUG - 2011-08-20 09:37:23 --> Model Class Initialized
DEBUG - 2011-08-20 09:37:23 --> Model Class Initialized
DEBUG - 2011-08-20 09:37:23 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-20 09:37:24 --> Database Driver Class Initialized
DEBUG - 2011-08-20 09:37:24 --> Final output sent to browser
DEBUG - 2011-08-20 09:37:24 --> Total execution time: 1.4627
DEBUG - 2011-08-20 09:37:26 --> Config Class Initialized
DEBUG - 2011-08-20 09:37:26 --> Hooks Class Initialized
DEBUG - 2011-08-20 09:37:26 --> Utf8 Class Initialized
DEBUG - 2011-08-20 09:37:26 --> UTF-8 Support Enabled
DEBUG - 2011-08-20 09:37:26 --> URI Class Initialized
DEBUG - 2011-08-20 09:37:26 --> Router Class Initialized
ERROR - 2011-08-20 09:37:26 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-20 09:37:34 --> Config Class Initialized
DEBUG - 2011-08-20 09:37:34 --> Hooks Class Initialized
DEBUG - 2011-08-20 09:37:34 --> Utf8 Class Initialized
DEBUG - 2011-08-20 09:37:34 --> UTF-8 Support Enabled
DEBUG - 2011-08-20 09:37:34 --> URI Class Initialized
DEBUG - 2011-08-20 09:37:34 --> Router Class Initialized
DEBUG - 2011-08-20 09:37:34 --> Output Class Initialized
DEBUG - 2011-08-20 09:37:34 --> Input Class Initialized
DEBUG - 2011-08-20 09:37:34 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-20 09:37:34 --> Language Class Initialized
DEBUG - 2011-08-20 09:37:34 --> Loader Class Initialized
DEBUG - 2011-08-20 09:37:34 --> Controller Class Initialized
ERROR - 2011-08-20 09:37:34 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-20 09:37:34 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-20 09:37:34 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-20 09:37:34 --> Model Class Initialized
DEBUG - 2011-08-20 09:37:34 --> Model Class Initialized
DEBUG - 2011-08-20 09:37:34 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-20 09:37:34 --> Database Driver Class Initialized
DEBUG - 2011-08-20 09:37:34 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-20 09:37:34 --> Helper loaded: url_helper
DEBUG - 2011-08-20 09:37:34 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-20 09:37:34 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-20 09:37:34 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-20 09:37:34 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-20 09:37:34 --> Final output sent to browser
DEBUG - 2011-08-20 09:37:34 --> Total execution time: 0.0334
DEBUG - 2011-08-20 09:37:35 --> Config Class Initialized
DEBUG - 2011-08-20 09:37:35 --> Hooks Class Initialized
DEBUG - 2011-08-20 09:37:35 --> Utf8 Class Initialized
DEBUG - 2011-08-20 09:37:35 --> UTF-8 Support Enabled
DEBUG - 2011-08-20 09:37:35 --> URI Class Initialized
DEBUG - 2011-08-20 09:37:35 --> Router Class Initialized
DEBUG - 2011-08-20 09:37:35 --> Output Class Initialized
DEBUG - 2011-08-20 09:37:35 --> Input Class Initialized
DEBUG - 2011-08-20 09:37:35 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-20 09:37:35 --> Language Class Initialized
DEBUG - 2011-08-20 09:37:35 --> Loader Class Initialized
DEBUG - 2011-08-20 09:37:35 --> Controller Class Initialized
DEBUG - 2011-08-20 09:37:35 --> Model Class Initialized
DEBUG - 2011-08-20 09:37:35 --> Model Class Initialized
DEBUG - 2011-08-20 09:37:35 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-20 09:37:35 --> Database Driver Class Initialized
DEBUG - 2011-08-20 09:37:36 --> Final output sent to browser
DEBUG - 2011-08-20 09:37:36 --> Total execution time: 1.3031
DEBUG - 2011-08-20 09:37:37 --> Config Class Initialized
DEBUG - 2011-08-20 09:37:37 --> Hooks Class Initialized
DEBUG - 2011-08-20 09:37:37 --> Utf8 Class Initialized
DEBUG - 2011-08-20 09:37:37 --> UTF-8 Support Enabled
DEBUG - 2011-08-20 09:37:37 --> URI Class Initialized
DEBUG - 2011-08-20 09:37:37 --> Router Class Initialized
ERROR - 2011-08-20 09:37:37 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-20 09:37:54 --> Config Class Initialized
DEBUG - 2011-08-20 09:37:54 --> Hooks Class Initialized
DEBUG - 2011-08-20 09:37:54 --> Utf8 Class Initialized
DEBUG - 2011-08-20 09:37:54 --> UTF-8 Support Enabled
DEBUG - 2011-08-20 09:37:54 --> URI Class Initialized
DEBUG - 2011-08-20 09:37:54 --> Router Class Initialized
DEBUG - 2011-08-20 09:37:54 --> Output Class Initialized
DEBUG - 2011-08-20 09:37:54 --> Input Class Initialized
DEBUG - 2011-08-20 09:37:54 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-20 09:37:54 --> Language Class Initialized
DEBUG - 2011-08-20 09:37:54 --> Loader Class Initialized
DEBUG - 2011-08-20 09:37:54 --> Controller Class Initialized
ERROR - 2011-08-20 09:37:54 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-20 09:37:54 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-20 09:37:54 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-20 09:37:54 --> Model Class Initialized
DEBUG - 2011-08-20 09:37:54 --> Model Class Initialized
DEBUG - 2011-08-20 09:37:54 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-20 09:37:54 --> Database Driver Class Initialized
DEBUG - 2011-08-20 09:37:54 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-20 09:37:54 --> Helper loaded: url_helper
DEBUG - 2011-08-20 09:37:54 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-20 09:37:54 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-20 09:37:54 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-20 09:37:54 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-20 09:37:54 --> Final output sent to browser
DEBUG - 2011-08-20 09:37:54 --> Total execution time: 0.0515
DEBUG - 2011-08-20 09:37:55 --> Config Class Initialized
DEBUG - 2011-08-20 09:37:55 --> Hooks Class Initialized
DEBUG - 2011-08-20 09:37:55 --> Utf8 Class Initialized
DEBUG - 2011-08-20 09:37:55 --> UTF-8 Support Enabled
DEBUG - 2011-08-20 09:37:55 --> URI Class Initialized
DEBUG - 2011-08-20 09:37:55 --> Router Class Initialized
DEBUG - 2011-08-20 09:37:55 --> Output Class Initialized
DEBUG - 2011-08-20 09:37:55 --> Input Class Initialized
DEBUG - 2011-08-20 09:37:55 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-20 09:37:55 --> Language Class Initialized
DEBUG - 2011-08-20 09:37:55 --> Loader Class Initialized
DEBUG - 2011-08-20 09:37:55 --> Controller Class Initialized
DEBUG - 2011-08-20 09:37:55 --> Model Class Initialized
DEBUG - 2011-08-20 09:37:55 --> Model Class Initialized
DEBUG - 2011-08-20 09:37:55 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-20 09:37:55 --> Database Driver Class Initialized
DEBUG - 2011-08-20 09:37:56 --> Final output sent to browser
DEBUG - 2011-08-20 09:37:56 --> Total execution time: 0.5923
DEBUG - 2011-08-20 09:53:45 --> Config Class Initialized
DEBUG - 2011-08-20 09:53:45 --> Hooks Class Initialized
DEBUG - 2011-08-20 09:53:45 --> Utf8 Class Initialized
DEBUG - 2011-08-20 09:53:45 --> UTF-8 Support Enabled
DEBUG - 2011-08-20 09:53:45 --> URI Class Initialized
DEBUG - 2011-08-20 09:53:45 --> Router Class Initialized
ERROR - 2011-08-20 09:53:45 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-08-20 10:17:59 --> Config Class Initialized
DEBUG - 2011-08-20 10:17:59 --> Hooks Class Initialized
DEBUG - 2011-08-20 10:17:59 --> Utf8 Class Initialized
DEBUG - 2011-08-20 10:17:59 --> UTF-8 Support Enabled
DEBUG - 2011-08-20 10:17:59 --> URI Class Initialized
DEBUG - 2011-08-20 10:17:59 --> Router Class Initialized
DEBUG - 2011-08-20 10:17:59 --> Output Class Initialized
DEBUG - 2011-08-20 10:17:59 --> Input Class Initialized
DEBUG - 2011-08-20 10:17:59 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-20 10:17:59 --> Language Class Initialized
DEBUG - 2011-08-20 10:17:59 --> Loader Class Initialized
DEBUG - 2011-08-20 10:17:59 --> Controller Class Initialized
DEBUG - 2011-08-20 10:17:59 --> Model Class Initialized
DEBUG - 2011-08-20 10:17:59 --> Model Class Initialized
DEBUG - 2011-08-20 10:17:59 --> Model Class Initialized
DEBUG - 2011-08-20 10:17:59 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-20 10:17:59 --> Database Driver Class Initialized
DEBUG - 2011-08-20 10:17:59 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-20 10:17:59 --> Helper loaded: url_helper
DEBUG - 2011-08-20 10:17:59 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-20 10:17:59 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-20 10:17:59 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-20 10:17:59 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-20 10:17:59 --> Final output sent to browser
DEBUG - 2011-08-20 10:17:59 --> Total execution time: 0.2825
DEBUG - 2011-08-20 10:18:02 --> Config Class Initialized
DEBUG - 2011-08-20 10:18:02 --> Hooks Class Initialized
DEBUG - 2011-08-20 10:18:02 --> Utf8 Class Initialized
DEBUG - 2011-08-20 10:18:02 --> UTF-8 Support Enabled
DEBUG - 2011-08-20 10:18:02 --> URI Class Initialized
DEBUG - 2011-08-20 10:18:02 --> Router Class Initialized
ERROR - 2011-08-20 10:18:02 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-20 10:18:02 --> Config Class Initialized
DEBUG - 2011-08-20 10:18:02 --> Hooks Class Initialized
DEBUG - 2011-08-20 10:18:02 --> Utf8 Class Initialized
DEBUG - 2011-08-20 10:18:02 --> UTF-8 Support Enabled
DEBUG - 2011-08-20 10:18:02 --> URI Class Initialized
DEBUG - 2011-08-20 10:18:02 --> Router Class Initialized
ERROR - 2011-08-20 10:18:02 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-20 10:18:13 --> Config Class Initialized
DEBUG - 2011-08-20 10:18:13 --> Hooks Class Initialized
DEBUG - 2011-08-20 10:18:13 --> Utf8 Class Initialized
DEBUG - 2011-08-20 10:18:13 --> UTF-8 Support Enabled
DEBUG - 2011-08-20 10:18:13 --> URI Class Initialized
DEBUG - 2011-08-20 10:18:13 --> Router Class Initialized
DEBUG - 2011-08-20 10:18:13 --> Output Class Initialized
DEBUG - 2011-08-20 10:18:13 --> Input Class Initialized
DEBUG - 2011-08-20 10:18:13 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-20 10:18:13 --> Language Class Initialized
DEBUG - 2011-08-20 10:18:13 --> Loader Class Initialized
DEBUG - 2011-08-20 10:18:13 --> Controller Class Initialized
DEBUG - 2011-08-20 10:18:13 --> Model Class Initialized
DEBUG - 2011-08-20 10:18:13 --> Model Class Initialized
DEBUG - 2011-08-20 10:18:13 --> Model Class Initialized
DEBUG - 2011-08-20 10:18:13 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-20 10:18:13 --> Database Driver Class Initialized
DEBUG - 2011-08-20 10:18:14 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-20 10:18:14 --> Helper loaded: url_helper
DEBUG - 2011-08-20 10:18:14 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-20 10:18:14 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-20 10:18:14 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-20 10:18:14 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-20 10:18:14 --> Final output sent to browser
DEBUG - 2011-08-20 10:18:14 --> Total execution time: 0.2333
DEBUG - 2011-08-20 10:18:15 --> Config Class Initialized
DEBUG - 2011-08-20 10:18:15 --> Hooks Class Initialized
DEBUG - 2011-08-20 10:18:15 --> Utf8 Class Initialized
DEBUG - 2011-08-20 10:18:15 --> UTF-8 Support Enabled
DEBUG - 2011-08-20 10:18:15 --> URI Class Initialized
DEBUG - 2011-08-20 10:18:15 --> Router Class Initialized
DEBUG - 2011-08-20 10:18:15 --> Output Class Initialized
DEBUG - 2011-08-20 10:18:15 --> Input Class Initialized
DEBUG - 2011-08-20 10:18:15 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-20 10:18:15 --> Language Class Initialized
DEBUG - 2011-08-20 10:18:15 --> Loader Class Initialized
DEBUG - 2011-08-20 10:18:15 --> Controller Class Initialized
DEBUG - 2011-08-20 10:18:15 --> Model Class Initialized
DEBUG - 2011-08-20 10:18:15 --> Model Class Initialized
DEBUG - 2011-08-20 10:18:15 --> Model Class Initialized
DEBUG - 2011-08-20 10:18:15 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-20 10:18:15 --> Database Driver Class Initialized
DEBUG - 2011-08-20 10:18:15 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-20 10:18:15 --> Helper loaded: url_helper
DEBUG - 2011-08-20 10:18:15 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-20 10:18:15 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-20 10:18:15 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-20 10:18:15 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-20 10:18:15 --> Final output sent to browser
DEBUG - 2011-08-20 10:18:15 --> Total execution time: 0.0449
DEBUG - 2011-08-20 10:18:15 --> Config Class Initialized
DEBUG - 2011-08-20 10:18:15 --> Hooks Class Initialized
DEBUG - 2011-08-20 10:18:15 --> Utf8 Class Initialized
DEBUG - 2011-08-20 10:18:15 --> UTF-8 Support Enabled
DEBUG - 2011-08-20 10:18:15 --> URI Class Initialized
DEBUG - 2011-08-20 10:18:15 --> Router Class Initialized
ERROR - 2011-08-20 10:18:15 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-20 10:18:35 --> Config Class Initialized
DEBUG - 2011-08-20 10:18:35 --> Hooks Class Initialized
DEBUG - 2011-08-20 10:18:35 --> Utf8 Class Initialized
DEBUG - 2011-08-20 10:18:35 --> UTF-8 Support Enabled
DEBUG - 2011-08-20 10:18:35 --> URI Class Initialized
DEBUG - 2011-08-20 10:18:35 --> Router Class Initialized
DEBUG - 2011-08-20 10:18:35 --> Output Class Initialized
DEBUG - 2011-08-20 10:18:35 --> Input Class Initialized
DEBUG - 2011-08-20 10:18:35 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-20 10:18:35 --> Language Class Initialized
DEBUG - 2011-08-20 10:18:35 --> Loader Class Initialized
DEBUG - 2011-08-20 10:18:35 --> Controller Class Initialized
DEBUG - 2011-08-20 10:18:35 --> Model Class Initialized
DEBUG - 2011-08-20 10:18:35 --> Model Class Initialized
DEBUG - 2011-08-20 10:18:35 --> Model Class Initialized
DEBUG - 2011-08-20 10:18:35 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-20 10:18:35 --> Database Driver Class Initialized
DEBUG - 2011-08-20 10:18:36 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-20 10:18:36 --> Helper loaded: url_helper
DEBUG - 2011-08-20 10:18:36 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-20 10:18:36 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-20 10:18:36 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-20 10:18:36 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-20 10:18:36 --> Final output sent to browser
DEBUG - 2011-08-20 10:18:36 --> Total execution time: 0.3180
DEBUG - 2011-08-20 10:18:36 --> Config Class Initialized
DEBUG - 2011-08-20 10:18:36 --> Hooks Class Initialized
DEBUG - 2011-08-20 10:18:36 --> Utf8 Class Initialized
DEBUG - 2011-08-20 10:18:36 --> UTF-8 Support Enabled
DEBUG - 2011-08-20 10:18:36 --> URI Class Initialized
DEBUG - 2011-08-20 10:18:36 --> Router Class Initialized
DEBUG - 2011-08-20 10:18:36 --> Output Class Initialized
DEBUG - 2011-08-20 10:18:36 --> Input Class Initialized
DEBUG - 2011-08-20 10:18:36 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-20 10:18:36 --> Language Class Initialized
DEBUG - 2011-08-20 10:18:36 --> Loader Class Initialized
DEBUG - 2011-08-20 10:18:36 --> Controller Class Initialized
DEBUG - 2011-08-20 10:18:36 --> Model Class Initialized
DEBUG - 2011-08-20 10:18:36 --> Model Class Initialized
DEBUG - 2011-08-20 10:18:36 --> Model Class Initialized
DEBUG - 2011-08-20 10:18:36 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-20 10:18:36 --> Database Driver Class Initialized
DEBUG - 2011-08-20 10:18:36 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-20 10:18:36 --> Helper loaded: url_helper
DEBUG - 2011-08-20 10:18:36 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-20 10:18:36 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-20 10:18:36 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-20 10:18:36 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-20 10:18:36 --> Final output sent to browser
DEBUG - 2011-08-20 10:18:36 --> Total execution time: 0.0605
DEBUG - 2011-08-20 10:18:37 --> Config Class Initialized
DEBUG - 2011-08-20 10:18:37 --> Hooks Class Initialized
DEBUG - 2011-08-20 10:18:37 --> Utf8 Class Initialized
DEBUG - 2011-08-20 10:18:37 --> UTF-8 Support Enabled
DEBUG - 2011-08-20 10:18:37 --> URI Class Initialized
DEBUG - 2011-08-20 10:18:37 --> Router Class Initialized
ERROR - 2011-08-20 10:18:37 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-20 10:18:45 --> Config Class Initialized
DEBUG - 2011-08-20 10:18:45 --> Hooks Class Initialized
DEBUG - 2011-08-20 10:18:45 --> Utf8 Class Initialized
DEBUG - 2011-08-20 10:18:45 --> UTF-8 Support Enabled
DEBUG - 2011-08-20 10:18:45 --> URI Class Initialized
DEBUG - 2011-08-20 10:18:45 --> Router Class Initialized
DEBUG - 2011-08-20 10:18:45 --> Output Class Initialized
DEBUG - 2011-08-20 10:18:45 --> Input Class Initialized
DEBUG - 2011-08-20 10:18:45 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-20 10:18:45 --> Language Class Initialized
DEBUG - 2011-08-20 10:18:45 --> Loader Class Initialized
DEBUG - 2011-08-20 10:18:45 --> Controller Class Initialized
DEBUG - 2011-08-20 10:18:45 --> Model Class Initialized
DEBUG - 2011-08-20 10:18:45 --> Model Class Initialized
DEBUG - 2011-08-20 10:18:45 --> Model Class Initialized
DEBUG - 2011-08-20 10:18:45 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-20 10:18:45 --> Database Driver Class Initialized
DEBUG - 2011-08-20 10:18:45 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-20 10:18:45 --> Helper loaded: url_helper
DEBUG - 2011-08-20 10:18:45 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-20 10:18:45 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-20 10:18:45 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-20 10:18:45 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-20 10:18:45 --> Final output sent to browser
DEBUG - 2011-08-20 10:18:45 --> Total execution time: 0.2472
DEBUG - 2011-08-20 10:18:46 --> Config Class Initialized
DEBUG - 2011-08-20 10:18:46 --> Hooks Class Initialized
DEBUG - 2011-08-20 10:18:46 --> Utf8 Class Initialized
DEBUG - 2011-08-20 10:18:46 --> UTF-8 Support Enabled
DEBUG - 2011-08-20 10:18:46 --> URI Class Initialized
DEBUG - 2011-08-20 10:18:46 --> Router Class Initialized
DEBUG - 2011-08-20 10:18:46 --> Output Class Initialized
DEBUG - 2011-08-20 10:18:46 --> Input Class Initialized
DEBUG - 2011-08-20 10:18:46 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-20 10:18:46 --> Language Class Initialized
DEBUG - 2011-08-20 10:18:46 --> Loader Class Initialized
DEBUG - 2011-08-20 10:18:46 --> Controller Class Initialized
DEBUG - 2011-08-20 10:18:46 --> Model Class Initialized
DEBUG - 2011-08-20 10:18:46 --> Model Class Initialized
DEBUG - 2011-08-20 10:18:46 --> Model Class Initialized
DEBUG - 2011-08-20 10:18:46 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-20 10:18:46 --> Database Driver Class Initialized
DEBUG - 2011-08-20 10:18:46 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-20 10:18:46 --> Helper loaded: url_helper
DEBUG - 2011-08-20 10:18:46 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-20 10:18:46 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-20 10:18:46 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-20 10:18:46 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-20 10:18:46 --> Final output sent to browser
DEBUG - 2011-08-20 10:18:46 --> Total execution time: 0.0482
DEBUG - 2011-08-20 10:18:46 --> Config Class Initialized
DEBUG - 2011-08-20 10:18:46 --> Hooks Class Initialized
DEBUG - 2011-08-20 10:18:46 --> Utf8 Class Initialized
DEBUG - 2011-08-20 10:18:46 --> UTF-8 Support Enabled
DEBUG - 2011-08-20 10:18:46 --> URI Class Initialized
DEBUG - 2011-08-20 10:18:46 --> Router Class Initialized
ERROR - 2011-08-20 10:18:46 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-20 10:18:47 --> Config Class Initialized
DEBUG - 2011-08-20 10:18:47 --> Hooks Class Initialized
DEBUG - 2011-08-20 10:18:47 --> Utf8 Class Initialized
DEBUG - 2011-08-20 10:18:47 --> UTF-8 Support Enabled
DEBUG - 2011-08-20 10:18:47 --> URI Class Initialized
DEBUG - 2011-08-20 10:18:47 --> Router Class Initialized
ERROR - 2011-08-20 10:18:47 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-20 10:18:56 --> Config Class Initialized
DEBUG - 2011-08-20 10:18:56 --> Hooks Class Initialized
DEBUG - 2011-08-20 10:18:56 --> Utf8 Class Initialized
DEBUG - 2011-08-20 10:18:56 --> UTF-8 Support Enabled
DEBUG - 2011-08-20 10:18:56 --> URI Class Initialized
DEBUG - 2011-08-20 10:18:56 --> Router Class Initialized
DEBUG - 2011-08-20 10:18:56 --> Output Class Initialized
DEBUG - 2011-08-20 10:18:56 --> Input Class Initialized
DEBUG - 2011-08-20 10:18:56 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-20 10:18:56 --> Language Class Initialized
DEBUG - 2011-08-20 10:18:56 --> Loader Class Initialized
DEBUG - 2011-08-20 10:18:56 --> Controller Class Initialized
DEBUG - 2011-08-20 10:18:56 --> Model Class Initialized
DEBUG - 2011-08-20 10:18:56 --> Model Class Initialized
DEBUG - 2011-08-20 10:18:56 --> Model Class Initialized
DEBUG - 2011-08-20 10:18:56 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-20 10:18:56 --> Database Driver Class Initialized
DEBUG - 2011-08-20 10:18:57 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-20 10:18:57 --> Helper loaded: url_helper
DEBUG - 2011-08-20 10:18:57 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-20 10:18:57 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-20 10:18:57 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-20 10:18:57 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-20 10:18:57 --> Final output sent to browser
DEBUG - 2011-08-20 10:18:57 --> Total execution time: 0.2686
DEBUG - 2011-08-20 10:18:58 --> Config Class Initialized
DEBUG - 2011-08-20 10:18:58 --> Hooks Class Initialized
DEBUG - 2011-08-20 10:18:58 --> Utf8 Class Initialized
DEBUG - 2011-08-20 10:18:58 --> UTF-8 Support Enabled
DEBUG - 2011-08-20 10:18:58 --> URI Class Initialized
DEBUG - 2011-08-20 10:18:58 --> Router Class Initialized
ERROR - 2011-08-20 10:18:58 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-20 10:18:58 --> Config Class Initialized
DEBUG - 2011-08-20 10:18:58 --> Hooks Class Initialized
DEBUG - 2011-08-20 10:18:58 --> Utf8 Class Initialized
DEBUG - 2011-08-20 10:18:58 --> UTF-8 Support Enabled
DEBUG - 2011-08-20 10:18:58 --> URI Class Initialized
DEBUG - 2011-08-20 10:18:58 --> Router Class Initialized
DEBUG - 2011-08-20 10:18:58 --> Output Class Initialized
DEBUG - 2011-08-20 10:18:58 --> Input Class Initialized
DEBUG - 2011-08-20 10:18:58 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-20 10:18:58 --> Language Class Initialized
DEBUG - 2011-08-20 10:18:58 --> Loader Class Initialized
DEBUG - 2011-08-20 10:18:58 --> Controller Class Initialized
DEBUG - 2011-08-20 10:18:58 --> Model Class Initialized
DEBUG - 2011-08-20 10:18:58 --> Model Class Initialized
DEBUG - 2011-08-20 10:18:58 --> Model Class Initialized
DEBUG - 2011-08-20 10:18:58 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-20 10:18:58 --> Database Driver Class Initialized
DEBUG - 2011-08-20 10:18:58 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-20 10:18:58 --> Helper loaded: url_helper
DEBUG - 2011-08-20 10:18:58 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-20 10:18:58 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-20 10:18:58 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-20 10:18:58 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-20 10:18:58 --> Final output sent to browser
DEBUG - 2011-08-20 10:18:58 --> Total execution time: 0.0488
DEBUG - 2011-08-20 10:24:25 --> Config Class Initialized
DEBUG - 2011-08-20 10:24:25 --> Hooks Class Initialized
DEBUG - 2011-08-20 10:24:25 --> Utf8 Class Initialized
DEBUG - 2011-08-20 10:24:25 --> UTF-8 Support Enabled
DEBUG - 2011-08-20 10:24:25 --> URI Class Initialized
DEBUG - 2011-08-20 10:24:25 --> Router Class Initialized
DEBUG - 2011-08-20 10:24:25 --> Output Class Initialized
DEBUG - 2011-08-20 10:24:25 --> Input Class Initialized
DEBUG - 2011-08-20 10:24:25 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-20 10:24:25 --> Language Class Initialized
DEBUG - 2011-08-20 10:24:25 --> Loader Class Initialized
DEBUG - 2011-08-20 10:24:25 --> Controller Class Initialized
DEBUG - 2011-08-20 10:24:25 --> Model Class Initialized
DEBUG - 2011-08-20 10:24:25 --> Model Class Initialized
DEBUG - 2011-08-20 10:24:25 --> Model Class Initialized
DEBUG - 2011-08-20 10:24:25 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-20 10:24:25 --> Database Driver Class Initialized
DEBUG - 2011-08-20 10:24:25 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-20 10:24:25 --> Helper loaded: url_helper
DEBUG - 2011-08-20 10:24:25 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-20 10:24:25 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-20 10:24:25 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-20 10:24:25 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-20 10:24:25 --> Final output sent to browser
DEBUG - 2011-08-20 10:24:25 --> Total execution time: 0.0544
DEBUG - 2011-08-20 10:44:42 --> Config Class Initialized
DEBUG - 2011-08-20 10:44:42 --> Hooks Class Initialized
DEBUG - 2011-08-20 10:44:42 --> Utf8 Class Initialized
DEBUG - 2011-08-20 10:44:42 --> UTF-8 Support Enabled
DEBUG - 2011-08-20 10:44:42 --> URI Class Initialized
DEBUG - 2011-08-20 10:44:42 --> Router Class Initialized
DEBUG - 2011-08-20 10:44:42 --> Output Class Initialized
DEBUG - 2011-08-20 10:44:42 --> Input Class Initialized
DEBUG - 2011-08-20 10:44:42 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-20 10:44:42 --> Language Class Initialized
DEBUG - 2011-08-20 10:44:42 --> Loader Class Initialized
DEBUG - 2011-08-20 10:44:42 --> Controller Class Initialized
ERROR - 2011-08-20 10:44:42 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-20 10:44:42 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-20 10:44:42 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-20 10:44:42 --> Model Class Initialized
DEBUG - 2011-08-20 10:44:42 --> Model Class Initialized
DEBUG - 2011-08-20 10:44:42 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-20 10:44:42 --> Database Driver Class Initialized
DEBUG - 2011-08-20 10:44:42 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-20 10:44:42 --> Helper loaded: url_helper
DEBUG - 2011-08-20 10:44:42 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-20 10:44:42 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-20 10:44:42 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-20 10:44:42 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-20 10:44:42 --> Final output sent to browser
DEBUG - 2011-08-20 10:44:42 --> Total execution time: 0.0736
DEBUG - 2011-08-20 10:44:44 --> Config Class Initialized
DEBUG - 2011-08-20 10:44:44 --> Hooks Class Initialized
DEBUG - 2011-08-20 10:44:44 --> Utf8 Class Initialized
DEBUG - 2011-08-20 10:44:44 --> UTF-8 Support Enabled
DEBUG - 2011-08-20 10:44:44 --> URI Class Initialized
DEBUG - 2011-08-20 10:44:44 --> Router Class Initialized
DEBUG - 2011-08-20 10:44:44 --> Output Class Initialized
DEBUG - 2011-08-20 10:44:44 --> Input Class Initialized
DEBUG - 2011-08-20 10:44:44 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-20 10:44:44 --> Language Class Initialized
DEBUG - 2011-08-20 10:44:44 --> Loader Class Initialized
DEBUG - 2011-08-20 10:44:44 --> Controller Class Initialized
DEBUG - 2011-08-20 10:44:44 --> Model Class Initialized
DEBUG - 2011-08-20 10:44:44 --> Model Class Initialized
DEBUG - 2011-08-20 10:44:44 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-20 10:44:44 --> Database Driver Class Initialized
DEBUG - 2011-08-20 10:44:44 --> Final output sent to browser
DEBUG - 2011-08-20 10:44:44 --> Total execution time: 0.8575
DEBUG - 2011-08-20 10:44:46 --> Config Class Initialized
DEBUG - 2011-08-20 10:44:46 --> Hooks Class Initialized
DEBUG - 2011-08-20 10:44:46 --> Utf8 Class Initialized
DEBUG - 2011-08-20 10:44:46 --> UTF-8 Support Enabled
DEBUG - 2011-08-20 10:44:46 --> URI Class Initialized
DEBUG - 2011-08-20 10:44:46 --> Router Class Initialized
ERROR - 2011-08-20 10:44:46 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-20 10:44:46 --> Config Class Initialized
DEBUG - 2011-08-20 10:44:46 --> Hooks Class Initialized
DEBUG - 2011-08-20 10:44:46 --> Utf8 Class Initialized
DEBUG - 2011-08-20 10:44:46 --> UTF-8 Support Enabled
DEBUG - 2011-08-20 10:44:46 --> URI Class Initialized
DEBUG - 2011-08-20 10:44:46 --> Router Class Initialized
ERROR - 2011-08-20 10:44:46 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-20 10:44:58 --> Config Class Initialized
DEBUG - 2011-08-20 10:44:58 --> Hooks Class Initialized
DEBUG - 2011-08-20 10:44:58 --> Utf8 Class Initialized
DEBUG - 2011-08-20 10:44:58 --> UTF-8 Support Enabled
DEBUG - 2011-08-20 10:44:58 --> URI Class Initialized
DEBUG - 2011-08-20 10:44:58 --> Router Class Initialized
DEBUG - 2011-08-20 10:44:58 --> Output Class Initialized
DEBUG - 2011-08-20 10:44:58 --> Input Class Initialized
DEBUG - 2011-08-20 10:44:58 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-20 10:44:58 --> Language Class Initialized
DEBUG - 2011-08-20 10:44:58 --> Loader Class Initialized
DEBUG - 2011-08-20 10:44:58 --> Controller Class Initialized
DEBUG - 2011-08-20 10:44:58 --> Model Class Initialized
DEBUG - 2011-08-20 10:44:58 --> Model Class Initialized
DEBUG - 2011-08-20 10:44:58 --> Model Class Initialized
DEBUG - 2011-08-20 10:44:58 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-20 10:44:58 --> Database Driver Class Initialized
DEBUG - 2011-08-20 10:44:59 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-20 10:44:59 --> Helper loaded: url_helper
DEBUG - 2011-08-20 10:44:59 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-20 10:44:59 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-20 10:44:59 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-20 10:44:59 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-20 10:44:59 --> Final output sent to browser
DEBUG - 2011-08-20 10:44:59 --> Total execution time: 0.0496
DEBUG - 2011-08-20 10:45:00 --> Config Class Initialized
DEBUG - 2011-08-20 10:45:00 --> Hooks Class Initialized
DEBUG - 2011-08-20 10:45:00 --> Utf8 Class Initialized
DEBUG - 2011-08-20 10:45:00 --> UTF-8 Support Enabled
DEBUG - 2011-08-20 10:45:00 --> URI Class Initialized
DEBUG - 2011-08-20 10:45:00 --> Router Class Initialized
ERROR - 2011-08-20 10:45:00 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-20 10:45:14 --> Config Class Initialized
DEBUG - 2011-08-20 10:45:14 --> Hooks Class Initialized
DEBUG - 2011-08-20 10:45:14 --> Utf8 Class Initialized
DEBUG - 2011-08-20 10:45:14 --> UTF-8 Support Enabled
DEBUG - 2011-08-20 10:45:14 --> URI Class Initialized
DEBUG - 2011-08-20 10:45:14 --> Router Class Initialized
DEBUG - 2011-08-20 10:45:14 --> Output Class Initialized
DEBUG - 2011-08-20 10:45:14 --> Input Class Initialized
DEBUG - 2011-08-20 10:45:14 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-20 10:45:14 --> Language Class Initialized
DEBUG - 2011-08-20 10:45:14 --> Loader Class Initialized
DEBUG - 2011-08-20 10:45:14 --> Controller Class Initialized
DEBUG - 2011-08-20 10:45:14 --> Model Class Initialized
DEBUG - 2011-08-20 10:45:14 --> Model Class Initialized
DEBUG - 2011-08-20 10:45:14 --> Model Class Initialized
DEBUG - 2011-08-20 10:45:14 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-20 10:45:14 --> Database Driver Class Initialized
DEBUG - 2011-08-20 10:45:14 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-20 10:45:14 --> Helper loaded: url_helper
DEBUG - 2011-08-20 10:45:14 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-20 10:45:14 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-20 10:45:14 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-20 10:45:14 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-20 10:45:14 --> Final output sent to browser
DEBUG - 2011-08-20 10:45:14 --> Total execution time: 0.2494
DEBUG - 2011-08-20 10:45:15 --> Config Class Initialized
DEBUG - 2011-08-20 10:45:15 --> Hooks Class Initialized
DEBUG - 2011-08-20 10:45:15 --> Utf8 Class Initialized
DEBUG - 2011-08-20 10:45:15 --> UTF-8 Support Enabled
DEBUG - 2011-08-20 10:45:15 --> URI Class Initialized
DEBUG - 2011-08-20 10:45:15 --> Router Class Initialized
ERROR - 2011-08-20 10:45:15 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-20 10:45:20 --> Config Class Initialized
DEBUG - 2011-08-20 10:45:20 --> Hooks Class Initialized
DEBUG - 2011-08-20 10:45:20 --> Utf8 Class Initialized
DEBUG - 2011-08-20 10:45:20 --> UTF-8 Support Enabled
DEBUG - 2011-08-20 10:45:20 --> URI Class Initialized
DEBUG - 2011-08-20 10:45:20 --> Router Class Initialized
DEBUG - 2011-08-20 10:45:20 --> No URI present. Default controller set.
DEBUG - 2011-08-20 10:45:20 --> Output Class Initialized
DEBUG - 2011-08-20 10:45:20 --> Input Class Initialized
DEBUG - 2011-08-20 10:45:20 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-20 10:45:20 --> Language Class Initialized
DEBUG - 2011-08-20 10:45:20 --> Loader Class Initialized
DEBUG - 2011-08-20 10:45:20 --> Controller Class Initialized
DEBUG - 2011-08-20 10:45:20 --> File loaded: application/views/splash/main.php
DEBUG - 2011-08-20 10:45:20 --> Helper loaded: url_helper
DEBUG - 2011-08-20 10:45:20 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-20 10:45:20 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-20 10:45:20 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-20 10:45:20 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-20 10:45:20 --> Final output sent to browser
DEBUG - 2011-08-20 10:45:20 --> Total execution time: 0.0575
DEBUG - 2011-08-20 11:15:46 --> Config Class Initialized
DEBUG - 2011-08-20 11:15:46 --> Hooks Class Initialized
DEBUG - 2011-08-20 11:15:46 --> Utf8 Class Initialized
DEBUG - 2011-08-20 11:15:46 --> UTF-8 Support Enabled
DEBUG - 2011-08-20 11:15:46 --> URI Class Initialized
DEBUG - 2011-08-20 11:15:46 --> Router Class Initialized
ERROR - 2011-08-20 11:15:46 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-08-20 11:35:49 --> Config Class Initialized
DEBUG - 2011-08-20 11:35:49 --> Hooks Class Initialized
DEBUG - 2011-08-20 11:35:49 --> Utf8 Class Initialized
DEBUG - 2011-08-20 11:35:49 --> UTF-8 Support Enabled
DEBUG - 2011-08-20 11:35:49 --> URI Class Initialized
DEBUG - 2011-08-20 11:35:49 --> Router Class Initialized
DEBUG - 2011-08-20 11:35:49 --> No URI present. Default controller set.
DEBUG - 2011-08-20 11:35:49 --> Output Class Initialized
DEBUG - 2011-08-20 11:35:49 --> Input Class Initialized
DEBUG - 2011-08-20 11:35:49 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-20 11:35:49 --> Language Class Initialized
DEBUG - 2011-08-20 11:35:49 --> Loader Class Initialized
DEBUG - 2011-08-20 11:35:49 --> Controller Class Initialized
DEBUG - 2011-08-20 11:35:49 --> File loaded: application/views/splash/main.php
DEBUG - 2011-08-20 11:35:49 --> Helper loaded: url_helper
DEBUG - 2011-08-20 11:35:49 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-20 11:35:49 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-20 11:35:49 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-20 11:35:49 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-20 11:35:49 --> Final output sent to browser
DEBUG - 2011-08-20 11:35:49 --> Total execution time: 0.0473
DEBUG - 2011-08-20 12:07:17 --> Config Class Initialized
DEBUG - 2011-08-20 12:07:17 --> Hooks Class Initialized
DEBUG - 2011-08-20 12:07:17 --> Utf8 Class Initialized
DEBUG - 2011-08-20 12:07:17 --> UTF-8 Support Enabled
DEBUG - 2011-08-20 12:07:17 --> URI Class Initialized
DEBUG - 2011-08-20 12:07:17 --> Router Class Initialized
DEBUG - 2011-08-20 12:07:17 --> Output Class Initialized
DEBUG - 2011-08-20 12:07:18 --> Input Class Initialized
DEBUG - 2011-08-20 12:07:18 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-20 12:07:18 --> Language Class Initialized
DEBUG - 2011-08-20 12:07:18 --> Loader Class Initialized
DEBUG - 2011-08-20 12:07:18 --> Controller Class Initialized
ERROR - 2011-08-20 12:07:18 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-20 12:07:18 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-20 12:07:18 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-20 12:07:18 --> Model Class Initialized
DEBUG - 2011-08-20 12:07:18 --> Model Class Initialized
DEBUG - 2011-08-20 12:07:18 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-20 12:07:18 --> Database Driver Class Initialized
DEBUG - 2011-08-20 12:07:18 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-20 12:07:18 --> Helper loaded: url_helper
DEBUG - 2011-08-20 12:07:18 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-20 12:07:18 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-20 12:07:18 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-20 12:07:18 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-20 12:07:18 --> Final output sent to browser
DEBUG - 2011-08-20 12:07:18 --> Total execution time: 0.2755
DEBUG - 2011-08-20 12:07:18 --> Config Class Initialized
DEBUG - 2011-08-20 12:07:18 --> Hooks Class Initialized
DEBUG - 2011-08-20 12:07:18 --> Utf8 Class Initialized
DEBUG - 2011-08-20 12:07:18 --> UTF-8 Support Enabled
DEBUG - 2011-08-20 12:07:18 --> URI Class Initialized
DEBUG - 2011-08-20 12:07:18 --> Router Class Initialized
DEBUG - 2011-08-20 12:07:18 --> Output Class Initialized
DEBUG - 2011-08-20 12:07:18 --> Input Class Initialized
DEBUG - 2011-08-20 12:07:18 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-20 12:07:18 --> Language Class Initialized
DEBUG - 2011-08-20 12:07:18 --> Loader Class Initialized
DEBUG - 2011-08-20 12:07:18 --> Controller Class Initialized
DEBUG - 2011-08-20 12:07:18 --> Model Class Initialized
DEBUG - 2011-08-20 12:07:19 --> Model Class Initialized
DEBUG - 2011-08-20 12:07:19 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-20 12:07:19 --> Database Driver Class Initialized
DEBUG - 2011-08-20 12:07:19 --> Config Class Initialized
DEBUG - 2011-08-20 12:07:19 --> Hooks Class Initialized
DEBUG - 2011-08-20 12:07:19 --> Utf8 Class Initialized
DEBUG - 2011-08-20 12:07:19 --> UTF-8 Support Enabled
DEBUG - 2011-08-20 12:07:19 --> URI Class Initialized
DEBUG - 2011-08-20 12:07:19 --> Router Class Initialized
ERROR - 2011-08-20 12:07:19 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-20 12:07:19 --> Config Class Initialized
DEBUG - 2011-08-20 12:07:19 --> Hooks Class Initialized
DEBUG - 2011-08-20 12:07:19 --> Utf8 Class Initialized
DEBUG - 2011-08-20 12:07:19 --> UTF-8 Support Enabled
DEBUG - 2011-08-20 12:07:19 --> URI Class Initialized
DEBUG - 2011-08-20 12:07:19 --> Router Class Initialized
DEBUG - 2011-08-20 12:07:19 --> Output Class Initialized
DEBUG - 2011-08-20 12:07:19 --> Input Class Initialized
DEBUG - 2011-08-20 12:07:19 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-20 12:07:19 --> Language Class Initialized
DEBUG - 2011-08-20 12:07:19 --> Loader Class Initialized
DEBUG - 2011-08-20 12:07:19 --> Controller Class Initialized
ERROR - 2011-08-20 12:07:19 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-20 12:07:19 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-20 12:07:19 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-20 12:07:19 --> Model Class Initialized
DEBUG - 2011-08-20 12:07:19 --> Model Class Initialized
DEBUG - 2011-08-20 12:07:19 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-20 12:07:19 --> Database Driver Class Initialized
DEBUG - 2011-08-20 12:07:19 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-20 12:07:19 --> Helper loaded: url_helper
DEBUG - 2011-08-20 12:07:19 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-20 12:07:19 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-20 12:07:19 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-20 12:07:19 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-20 12:07:19 --> Final output sent to browser
DEBUG - 2011-08-20 12:07:19 --> Total execution time: 0.0330
DEBUG - 2011-08-20 12:07:19 --> Final output sent to browser
DEBUG - 2011-08-20 12:07:19 --> Total execution time: 0.8526
DEBUG - 2011-08-20 12:07:20 --> Config Class Initialized
DEBUG - 2011-08-20 12:07:20 --> Hooks Class Initialized
DEBUG - 2011-08-20 12:07:20 --> Utf8 Class Initialized
DEBUG - 2011-08-20 12:07:20 --> UTF-8 Support Enabled
DEBUG - 2011-08-20 12:07:20 --> URI Class Initialized
DEBUG - 2011-08-20 12:07:20 --> Router Class Initialized
ERROR - 2011-08-20 12:07:20 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-20 12:07:20 --> Config Class Initialized
DEBUG - 2011-08-20 12:07:20 --> Hooks Class Initialized
DEBUG - 2011-08-20 12:07:20 --> Utf8 Class Initialized
DEBUG - 2011-08-20 12:07:20 --> UTF-8 Support Enabled
DEBUG - 2011-08-20 12:07:20 --> URI Class Initialized
DEBUG - 2011-08-20 12:07:20 --> Router Class Initialized
DEBUG - 2011-08-20 12:07:20 --> Output Class Initialized
DEBUG - 2011-08-20 12:07:20 --> Input Class Initialized
DEBUG - 2011-08-20 12:07:20 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-20 12:07:20 --> Language Class Initialized
DEBUG - 2011-08-20 12:07:20 --> Loader Class Initialized
DEBUG - 2011-08-20 12:07:20 --> Controller Class Initialized
DEBUG - 2011-08-20 12:07:20 --> Model Class Initialized
DEBUG - 2011-08-20 12:07:20 --> Model Class Initialized
DEBUG - 2011-08-20 12:07:20 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-20 12:07:20 --> Database Driver Class Initialized
DEBUG - 2011-08-20 12:07:21 --> Final output sent to browser
DEBUG - 2011-08-20 12:07:21 --> Total execution time: 0.4833
DEBUG - 2011-08-20 12:08:20 --> Config Class Initialized
DEBUG - 2011-08-20 12:08:20 --> Hooks Class Initialized
DEBUG - 2011-08-20 12:08:20 --> Utf8 Class Initialized
DEBUG - 2011-08-20 12:08:20 --> UTF-8 Support Enabled
DEBUG - 2011-08-20 12:08:20 --> URI Class Initialized
DEBUG - 2011-08-20 12:08:20 --> Router Class Initialized
DEBUG - 2011-08-20 12:08:20 --> Output Class Initialized
DEBUG - 2011-08-20 12:08:20 --> Input Class Initialized
DEBUG - 2011-08-20 12:08:20 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-20 12:08:20 --> Language Class Initialized
DEBUG - 2011-08-20 12:08:20 --> Loader Class Initialized
DEBUG - 2011-08-20 12:08:20 --> Controller Class Initialized
ERROR - 2011-08-20 12:08:20 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-20 12:08:20 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-20 12:08:20 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-20 12:08:20 --> Model Class Initialized
DEBUG - 2011-08-20 12:08:20 --> Model Class Initialized
DEBUG - 2011-08-20 12:08:20 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-20 12:08:20 --> Database Driver Class Initialized
DEBUG - 2011-08-20 12:08:20 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-20 12:08:20 --> Helper loaded: url_helper
DEBUG - 2011-08-20 12:08:20 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-20 12:08:20 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-20 12:08:20 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-20 12:08:20 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-20 12:08:20 --> Final output sent to browser
DEBUG - 2011-08-20 12:08:20 --> Total execution time: 0.0364
DEBUG - 2011-08-20 12:08:20 --> Config Class Initialized
DEBUG - 2011-08-20 12:08:20 --> Hooks Class Initialized
DEBUG - 2011-08-20 12:08:20 --> Utf8 Class Initialized
DEBUG - 2011-08-20 12:08:20 --> UTF-8 Support Enabled
DEBUG - 2011-08-20 12:08:20 --> URI Class Initialized
DEBUG - 2011-08-20 12:08:20 --> Router Class Initialized
DEBUG - 2011-08-20 12:08:20 --> Output Class Initialized
DEBUG - 2011-08-20 12:08:20 --> Input Class Initialized
DEBUG - 2011-08-20 12:08:20 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-20 12:08:20 --> Language Class Initialized
DEBUG - 2011-08-20 12:08:20 --> Loader Class Initialized
DEBUG - 2011-08-20 12:08:20 --> Controller Class Initialized
DEBUG - 2011-08-20 12:08:20 --> Model Class Initialized
DEBUG - 2011-08-20 12:08:20 --> Model Class Initialized
DEBUG - 2011-08-20 12:08:20 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-20 12:08:20 --> Database Driver Class Initialized
DEBUG - 2011-08-20 12:08:21 --> Final output sent to browser
DEBUG - 2011-08-20 12:08:21 --> Total execution time: 0.5490
DEBUG - 2011-08-20 12:38:24 --> Config Class Initialized
DEBUG - 2011-08-20 12:38:24 --> Hooks Class Initialized
DEBUG - 2011-08-20 12:38:24 --> Utf8 Class Initialized
DEBUG - 2011-08-20 12:38:24 --> UTF-8 Support Enabled
DEBUG - 2011-08-20 12:38:24 --> URI Class Initialized
DEBUG - 2011-08-20 12:38:24 --> Router Class Initialized
DEBUG - 2011-08-20 12:38:24 --> Output Class Initialized
DEBUG - 2011-08-20 12:38:24 --> Input Class Initialized
DEBUG - 2011-08-20 12:38:24 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-20 12:38:24 --> Language Class Initialized
DEBUG - 2011-08-20 12:38:24 --> Loader Class Initialized
DEBUG - 2011-08-20 12:38:24 --> Controller Class Initialized
ERROR - 2011-08-20 12:38:24 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-20 12:38:24 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-20 12:38:24 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-20 12:38:24 --> Model Class Initialized
DEBUG - 2011-08-20 12:38:24 --> Model Class Initialized
DEBUG - 2011-08-20 12:38:24 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-20 12:38:24 --> Database Driver Class Initialized
DEBUG - 2011-08-20 12:38:25 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-20 12:38:25 --> Helper loaded: url_helper
DEBUG - 2011-08-20 12:38:25 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-20 12:38:25 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-20 12:38:25 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-20 12:38:25 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-20 12:38:25 --> Final output sent to browser
DEBUG - 2011-08-20 12:38:25 --> Total execution time: 0.0352
DEBUG - 2011-08-20 12:38:26 --> Config Class Initialized
DEBUG - 2011-08-20 12:38:26 --> Hooks Class Initialized
DEBUG - 2011-08-20 12:38:26 --> Utf8 Class Initialized
DEBUG - 2011-08-20 12:38:26 --> UTF-8 Support Enabled
DEBUG - 2011-08-20 12:38:26 --> URI Class Initialized
DEBUG - 2011-08-20 12:38:26 --> Router Class Initialized
DEBUG - 2011-08-20 12:38:26 --> Output Class Initialized
DEBUG - 2011-08-20 12:38:26 --> Input Class Initialized
DEBUG - 2011-08-20 12:38:26 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-20 12:38:26 --> Language Class Initialized
DEBUG - 2011-08-20 12:38:26 --> Loader Class Initialized
DEBUG - 2011-08-20 12:38:26 --> Controller Class Initialized
DEBUG - 2011-08-20 12:38:26 --> Model Class Initialized
DEBUG - 2011-08-20 12:38:26 --> Model Class Initialized
DEBUG - 2011-08-20 12:38:26 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-20 12:38:26 --> Database Driver Class Initialized
DEBUG - 2011-08-20 12:38:26 --> Final output sent to browser
DEBUG - 2011-08-20 12:38:26 --> Total execution time: 0.6321
DEBUG - 2011-08-20 12:38:28 --> Config Class Initialized
DEBUG - 2011-08-20 12:38:28 --> Hooks Class Initialized
DEBUG - 2011-08-20 12:38:28 --> Utf8 Class Initialized
DEBUG - 2011-08-20 12:38:28 --> UTF-8 Support Enabled
DEBUG - 2011-08-20 12:38:28 --> URI Class Initialized
DEBUG - 2011-08-20 12:38:28 --> Router Class Initialized
ERROR - 2011-08-20 12:38:28 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-20 12:38:28 --> Config Class Initialized
DEBUG - 2011-08-20 12:38:28 --> Hooks Class Initialized
DEBUG - 2011-08-20 12:38:28 --> Utf8 Class Initialized
DEBUG - 2011-08-20 12:38:28 --> UTF-8 Support Enabled
DEBUG - 2011-08-20 12:38:28 --> URI Class Initialized
DEBUG - 2011-08-20 12:38:28 --> Router Class Initialized
ERROR - 2011-08-20 12:38:28 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-20 15:18:45 --> Config Class Initialized
DEBUG - 2011-08-20 15:18:45 --> Hooks Class Initialized
DEBUG - 2011-08-20 15:18:45 --> Utf8 Class Initialized
DEBUG - 2011-08-20 15:18:45 --> UTF-8 Support Enabled
DEBUG - 2011-08-20 15:18:45 --> URI Class Initialized
DEBUG - 2011-08-20 15:18:45 --> Router Class Initialized
ERROR - 2011-08-20 15:18:45 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-08-20 16:28:02 --> Config Class Initialized
DEBUG - 2011-08-20 16:28:02 --> Hooks Class Initialized
DEBUG - 2011-08-20 16:28:02 --> Utf8 Class Initialized
DEBUG - 2011-08-20 16:28:02 --> UTF-8 Support Enabled
DEBUG - 2011-08-20 16:28:02 --> URI Class Initialized
DEBUG - 2011-08-20 16:28:02 --> Router Class Initialized
DEBUG - 2011-08-20 16:28:02 --> No URI present. Default controller set.
DEBUG - 2011-08-20 16:28:02 --> Output Class Initialized
DEBUG - 2011-08-20 16:28:02 --> Input Class Initialized
DEBUG - 2011-08-20 16:28:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-20 16:28:02 --> Language Class Initialized
DEBUG - 2011-08-20 16:28:02 --> Loader Class Initialized
DEBUG - 2011-08-20 16:28:02 --> Controller Class Initialized
DEBUG - 2011-08-20 16:28:02 --> File loaded: application/views/splash/main.php
DEBUG - 2011-08-20 16:28:02 --> Helper loaded: url_helper
DEBUG - 2011-08-20 16:28:02 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-20 16:28:02 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-20 16:28:02 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-20 16:28:02 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-20 16:28:02 --> Final output sent to browser
DEBUG - 2011-08-20 16:28:02 --> Total execution time: 0.2160
DEBUG - 2011-08-20 16:46:55 --> Config Class Initialized
DEBUG - 2011-08-20 16:46:55 --> Hooks Class Initialized
DEBUG - 2011-08-20 16:46:55 --> Utf8 Class Initialized
DEBUG - 2011-08-20 16:46:55 --> UTF-8 Support Enabled
DEBUG - 2011-08-20 16:46:55 --> URI Class Initialized
DEBUG - 2011-08-20 16:46:55 --> Router Class Initialized
ERROR - 2011-08-20 16:46:55 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-08-20 16:46:57 --> Config Class Initialized
DEBUG - 2011-08-20 16:46:57 --> Hooks Class Initialized
DEBUG - 2011-08-20 16:46:57 --> Utf8 Class Initialized
DEBUG - 2011-08-20 16:46:57 --> UTF-8 Support Enabled
DEBUG - 2011-08-20 16:46:57 --> URI Class Initialized
DEBUG - 2011-08-20 16:46:57 --> Router Class Initialized
DEBUG - 2011-08-20 16:46:57 --> No URI present. Default controller set.
DEBUG - 2011-08-20 16:46:57 --> Output Class Initialized
DEBUG - 2011-08-20 16:46:57 --> Input Class Initialized
DEBUG - 2011-08-20 16:46:57 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-20 16:46:57 --> Language Class Initialized
DEBUG - 2011-08-20 16:46:57 --> Loader Class Initialized
DEBUG - 2011-08-20 16:46:57 --> Controller Class Initialized
DEBUG - 2011-08-20 16:46:57 --> File loaded: application/views/splash/main.php
DEBUG - 2011-08-20 16:46:57 --> Helper loaded: url_helper
DEBUG - 2011-08-20 16:46:57 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-20 16:46:57 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-20 16:46:57 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-20 16:46:57 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-20 16:46:57 --> Final output sent to browser
DEBUG - 2011-08-20 16:46:57 --> Total execution time: 0.0293
DEBUG - 2011-08-20 17:11:36 --> Config Class Initialized
DEBUG - 2011-08-20 17:11:36 --> Hooks Class Initialized
DEBUG - 2011-08-20 17:11:36 --> Utf8 Class Initialized
DEBUG - 2011-08-20 17:11:36 --> UTF-8 Support Enabled
DEBUG - 2011-08-20 17:11:36 --> URI Class Initialized
DEBUG - 2011-08-20 17:11:36 --> Router Class Initialized
DEBUG - 2011-08-20 17:11:36 --> Output Class Initialized
DEBUG - 2011-08-20 17:11:36 --> Input Class Initialized
DEBUG - 2011-08-20 17:11:36 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-20 17:11:36 --> Language Class Initialized
DEBUG - 2011-08-20 17:11:36 --> Loader Class Initialized
DEBUG - 2011-08-20 17:11:36 --> Controller Class Initialized
ERROR - 2011-08-20 17:11:36 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-20 17:11:36 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-20 17:11:36 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-20 17:11:36 --> Model Class Initialized
DEBUG - 2011-08-20 17:11:36 --> Model Class Initialized
DEBUG - 2011-08-20 17:11:36 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-20 17:11:36 --> Database Driver Class Initialized
DEBUG - 2011-08-20 17:11:36 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-20 17:11:36 --> Helper loaded: url_helper
DEBUG - 2011-08-20 17:11:36 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-20 17:11:36 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-20 17:11:36 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-20 17:11:36 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-20 17:11:36 --> Final output sent to browser
DEBUG - 2011-08-20 17:11:36 --> Total execution time: 0.1896
DEBUG - 2011-08-20 17:11:37 --> Config Class Initialized
DEBUG - 2011-08-20 17:11:37 --> Hooks Class Initialized
DEBUG - 2011-08-20 17:11:37 --> Utf8 Class Initialized
DEBUG - 2011-08-20 17:11:37 --> UTF-8 Support Enabled
DEBUG - 2011-08-20 17:11:37 --> URI Class Initialized
DEBUG - 2011-08-20 17:11:37 --> Router Class Initialized
DEBUG - 2011-08-20 17:11:37 --> Output Class Initialized
DEBUG - 2011-08-20 17:11:37 --> Input Class Initialized
DEBUG - 2011-08-20 17:11:37 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-20 17:11:37 --> Language Class Initialized
DEBUG - 2011-08-20 17:11:37 --> Loader Class Initialized
DEBUG - 2011-08-20 17:11:37 --> Controller Class Initialized
DEBUG - 2011-08-20 17:11:37 --> Model Class Initialized
DEBUG - 2011-08-20 17:11:37 --> Model Class Initialized
DEBUG - 2011-08-20 17:11:37 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-20 17:11:37 --> Database Driver Class Initialized
DEBUG - 2011-08-20 17:11:38 --> Final output sent to browser
DEBUG - 2011-08-20 17:11:38 --> Total execution time: 0.7997
DEBUG - 2011-08-20 17:11:38 --> Config Class Initialized
DEBUG - 2011-08-20 17:11:38 --> Hooks Class Initialized
DEBUG - 2011-08-20 17:11:38 --> Utf8 Class Initialized
DEBUG - 2011-08-20 17:11:38 --> UTF-8 Support Enabled
DEBUG - 2011-08-20 17:11:38 --> URI Class Initialized
DEBUG - 2011-08-20 17:11:38 --> Router Class Initialized
ERROR - 2011-08-20 17:11:38 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-20 17:11:38 --> Config Class Initialized
DEBUG - 2011-08-20 17:11:38 --> Hooks Class Initialized
DEBUG - 2011-08-20 17:11:38 --> Utf8 Class Initialized
DEBUG - 2011-08-20 17:11:38 --> UTF-8 Support Enabled
DEBUG - 2011-08-20 17:11:38 --> URI Class Initialized
DEBUG - 2011-08-20 17:11:38 --> Router Class Initialized
ERROR - 2011-08-20 17:11:38 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-20 17:11:43 --> Config Class Initialized
DEBUG - 2011-08-20 17:11:43 --> Hooks Class Initialized
DEBUG - 2011-08-20 17:11:43 --> Utf8 Class Initialized
DEBUG - 2011-08-20 17:11:43 --> UTF-8 Support Enabled
DEBUG - 2011-08-20 17:11:43 --> URI Class Initialized
DEBUG - 2011-08-20 17:11:43 --> Router Class Initialized
DEBUG - 2011-08-20 17:11:43 --> Output Class Initialized
DEBUG - 2011-08-20 17:11:43 --> Input Class Initialized
DEBUG - 2011-08-20 17:11:43 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-20 17:11:43 --> Language Class Initialized
DEBUG - 2011-08-20 17:11:43 --> Loader Class Initialized
DEBUG - 2011-08-20 17:11:43 --> Controller Class Initialized
ERROR - 2011-08-20 17:11:43 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-20 17:11:43 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-20 17:11:43 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-20 17:11:43 --> Model Class Initialized
DEBUG - 2011-08-20 17:11:43 --> Model Class Initialized
DEBUG - 2011-08-20 17:11:43 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-20 17:11:43 --> Database Driver Class Initialized
DEBUG - 2011-08-20 17:11:43 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-20 17:11:43 --> Helper loaded: url_helper
DEBUG - 2011-08-20 17:11:43 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-20 17:11:43 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-20 17:11:43 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-20 17:11:43 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-20 17:11:43 --> Final output sent to browser
DEBUG - 2011-08-20 17:11:43 --> Total execution time: 0.0272
DEBUG - 2011-08-20 17:11:43 --> Config Class Initialized
DEBUG - 2011-08-20 17:11:43 --> Hooks Class Initialized
DEBUG - 2011-08-20 17:11:43 --> Utf8 Class Initialized
DEBUG - 2011-08-20 17:11:43 --> UTF-8 Support Enabled
DEBUG - 2011-08-20 17:11:43 --> URI Class Initialized
DEBUG - 2011-08-20 17:11:43 --> Router Class Initialized
DEBUG - 2011-08-20 17:11:43 --> Output Class Initialized
DEBUG - 2011-08-20 17:11:43 --> Input Class Initialized
DEBUG - 2011-08-20 17:11:43 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-20 17:11:43 --> Language Class Initialized
DEBUG - 2011-08-20 17:11:43 --> Loader Class Initialized
DEBUG - 2011-08-20 17:11:43 --> Controller Class Initialized
DEBUG - 2011-08-20 17:11:43 --> Model Class Initialized
DEBUG - 2011-08-20 17:11:43 --> Model Class Initialized
DEBUG - 2011-08-20 17:11:43 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-20 17:11:43 --> Database Driver Class Initialized
DEBUG - 2011-08-20 17:11:44 --> Final output sent to browser
DEBUG - 2011-08-20 17:11:44 --> Total execution time: 0.5320
DEBUG - 2011-08-20 17:11:44 --> Config Class Initialized
DEBUG - 2011-08-20 17:11:44 --> Hooks Class Initialized
DEBUG - 2011-08-20 17:11:44 --> Utf8 Class Initialized
DEBUG - 2011-08-20 17:11:44 --> UTF-8 Support Enabled
DEBUG - 2011-08-20 17:11:44 --> URI Class Initialized
DEBUG - 2011-08-20 17:11:44 --> Router Class Initialized
ERROR - 2011-08-20 17:11:44 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-20 17:11:49 --> Config Class Initialized
DEBUG - 2011-08-20 17:11:49 --> Hooks Class Initialized
DEBUG - 2011-08-20 17:11:49 --> Utf8 Class Initialized
DEBUG - 2011-08-20 17:11:49 --> UTF-8 Support Enabled
DEBUG - 2011-08-20 17:11:49 --> URI Class Initialized
DEBUG - 2011-08-20 17:11:49 --> Router Class Initialized
DEBUG - 2011-08-20 17:11:49 --> Output Class Initialized
DEBUG - 2011-08-20 17:11:49 --> Input Class Initialized
DEBUG - 2011-08-20 17:11:49 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-20 17:11:49 --> Language Class Initialized
DEBUG - 2011-08-20 17:11:49 --> Loader Class Initialized
DEBUG - 2011-08-20 17:11:49 --> Controller Class Initialized
ERROR - 2011-08-20 17:11:49 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-20 17:11:49 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-20 17:11:49 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-20 17:11:49 --> Model Class Initialized
DEBUG - 2011-08-20 17:11:49 --> Model Class Initialized
DEBUG - 2011-08-20 17:11:49 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-20 17:11:49 --> Database Driver Class Initialized
DEBUG - 2011-08-20 17:11:49 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-20 17:11:49 --> Helper loaded: url_helper
DEBUG - 2011-08-20 17:11:49 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-20 17:11:49 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-20 17:11:49 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-20 17:11:49 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-20 17:11:49 --> Final output sent to browser
DEBUG - 2011-08-20 17:11:49 --> Total execution time: 0.0722
DEBUG - 2011-08-20 17:11:50 --> Config Class Initialized
DEBUG - 2011-08-20 17:11:50 --> Hooks Class Initialized
DEBUG - 2011-08-20 17:11:50 --> Utf8 Class Initialized
DEBUG - 2011-08-20 17:11:50 --> UTF-8 Support Enabled
DEBUG - 2011-08-20 17:11:50 --> URI Class Initialized
DEBUG - 2011-08-20 17:11:50 --> Router Class Initialized
DEBUG - 2011-08-20 17:11:50 --> Output Class Initialized
DEBUG - 2011-08-20 17:11:50 --> Input Class Initialized
DEBUG - 2011-08-20 17:11:50 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-20 17:11:50 --> Language Class Initialized
DEBUG - 2011-08-20 17:11:50 --> Loader Class Initialized
DEBUG - 2011-08-20 17:11:50 --> Controller Class Initialized
DEBUG - 2011-08-20 17:11:50 --> Model Class Initialized
DEBUG - 2011-08-20 17:11:50 --> Model Class Initialized
DEBUG - 2011-08-20 17:11:50 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-20 17:11:50 --> Database Driver Class Initialized
DEBUG - 2011-08-20 17:11:50 --> Final output sent to browser
DEBUG - 2011-08-20 17:11:50 --> Total execution time: 0.5986
DEBUG - 2011-08-20 17:11:51 --> Config Class Initialized
DEBUG - 2011-08-20 17:11:51 --> Hooks Class Initialized
DEBUG - 2011-08-20 17:11:51 --> Utf8 Class Initialized
DEBUG - 2011-08-20 17:11:51 --> UTF-8 Support Enabled
DEBUG - 2011-08-20 17:11:51 --> URI Class Initialized
DEBUG - 2011-08-20 17:11:51 --> Router Class Initialized
ERROR - 2011-08-20 17:11:51 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-20 17:12:02 --> Config Class Initialized
DEBUG - 2011-08-20 17:12:02 --> Hooks Class Initialized
DEBUG - 2011-08-20 17:12:02 --> Utf8 Class Initialized
DEBUG - 2011-08-20 17:12:02 --> UTF-8 Support Enabled
DEBUG - 2011-08-20 17:12:02 --> URI Class Initialized
DEBUG - 2011-08-20 17:12:02 --> Router Class Initialized
DEBUG - 2011-08-20 17:12:02 --> Output Class Initialized
DEBUG - 2011-08-20 17:12:02 --> Input Class Initialized
DEBUG - 2011-08-20 17:12:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-20 17:12:02 --> Language Class Initialized
DEBUG - 2011-08-20 17:12:02 --> Loader Class Initialized
DEBUG - 2011-08-20 17:12:02 --> Controller Class Initialized
ERROR - 2011-08-20 17:12:02 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-20 17:12:02 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-20 17:12:02 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-20 17:12:02 --> Model Class Initialized
DEBUG - 2011-08-20 17:12:02 --> Model Class Initialized
DEBUG - 2011-08-20 17:12:02 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-20 17:12:02 --> Database Driver Class Initialized
DEBUG - 2011-08-20 17:12:02 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-20 17:12:02 --> Helper loaded: url_helper
DEBUG - 2011-08-20 17:12:02 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-20 17:12:02 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-20 17:12:02 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-20 17:12:02 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-20 17:12:02 --> Final output sent to browser
DEBUG - 2011-08-20 17:12:02 --> Total execution time: 0.0474
DEBUG - 2011-08-20 17:12:03 --> Config Class Initialized
DEBUG - 2011-08-20 17:12:03 --> Hooks Class Initialized
DEBUG - 2011-08-20 17:12:03 --> Utf8 Class Initialized
DEBUG - 2011-08-20 17:12:03 --> UTF-8 Support Enabled
DEBUG - 2011-08-20 17:12:03 --> URI Class Initialized
DEBUG - 2011-08-20 17:12:03 --> Router Class Initialized
DEBUG - 2011-08-20 17:12:03 --> Output Class Initialized
DEBUG - 2011-08-20 17:12:03 --> Input Class Initialized
DEBUG - 2011-08-20 17:12:03 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-20 17:12:03 --> Language Class Initialized
DEBUG - 2011-08-20 17:12:03 --> Loader Class Initialized
DEBUG - 2011-08-20 17:12:03 --> Controller Class Initialized
DEBUG - 2011-08-20 17:12:03 --> Model Class Initialized
DEBUG - 2011-08-20 17:12:03 --> Model Class Initialized
DEBUG - 2011-08-20 17:12:03 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-20 17:12:03 --> Database Driver Class Initialized
DEBUG - 2011-08-20 17:12:03 --> Final output sent to browser
DEBUG - 2011-08-20 17:12:03 --> Total execution time: 0.6757
DEBUG - 2011-08-20 17:12:04 --> Config Class Initialized
DEBUG - 2011-08-20 17:12:04 --> Hooks Class Initialized
DEBUG - 2011-08-20 17:12:04 --> Utf8 Class Initialized
DEBUG - 2011-08-20 17:12:04 --> UTF-8 Support Enabled
DEBUG - 2011-08-20 17:12:04 --> URI Class Initialized
DEBUG - 2011-08-20 17:12:04 --> Router Class Initialized
ERROR - 2011-08-20 17:12:04 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-20 17:12:11 --> Config Class Initialized
DEBUG - 2011-08-20 17:12:11 --> Hooks Class Initialized
DEBUG - 2011-08-20 17:12:11 --> Utf8 Class Initialized
DEBUG - 2011-08-20 17:12:11 --> UTF-8 Support Enabled
DEBUG - 2011-08-20 17:12:11 --> URI Class Initialized
DEBUG - 2011-08-20 17:12:11 --> Router Class Initialized
DEBUG - 2011-08-20 17:12:11 --> Output Class Initialized
DEBUG - 2011-08-20 17:12:11 --> Input Class Initialized
DEBUG - 2011-08-20 17:12:11 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-20 17:12:11 --> Language Class Initialized
DEBUG - 2011-08-20 17:12:11 --> Loader Class Initialized
DEBUG - 2011-08-20 17:12:11 --> Controller Class Initialized
ERROR - 2011-08-20 17:12:11 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-20 17:12:11 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-20 17:12:11 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-20 17:12:11 --> Model Class Initialized
DEBUG - 2011-08-20 17:12:11 --> Model Class Initialized
DEBUG - 2011-08-20 17:12:11 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-20 17:12:11 --> Database Driver Class Initialized
DEBUG - 2011-08-20 17:12:11 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-20 17:12:11 --> Helper loaded: url_helper
DEBUG - 2011-08-20 17:12:11 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-20 17:12:11 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-20 17:12:11 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-20 17:12:11 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-20 17:12:11 --> Final output sent to browser
DEBUG - 2011-08-20 17:12:11 --> Total execution time: 0.0332
DEBUG - 2011-08-20 17:12:12 --> Config Class Initialized
DEBUG - 2011-08-20 17:12:12 --> Hooks Class Initialized
DEBUG - 2011-08-20 17:12:12 --> Utf8 Class Initialized
DEBUG - 2011-08-20 17:12:12 --> UTF-8 Support Enabled
DEBUG - 2011-08-20 17:12:12 --> URI Class Initialized
DEBUG - 2011-08-20 17:12:12 --> Router Class Initialized
DEBUG - 2011-08-20 17:12:12 --> Output Class Initialized
DEBUG - 2011-08-20 17:12:12 --> Input Class Initialized
DEBUG - 2011-08-20 17:12:12 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-20 17:12:12 --> Language Class Initialized
DEBUG - 2011-08-20 17:12:12 --> Loader Class Initialized
DEBUG - 2011-08-20 17:12:12 --> Controller Class Initialized
DEBUG - 2011-08-20 17:12:12 --> Model Class Initialized
DEBUG - 2011-08-20 17:12:12 --> Model Class Initialized
DEBUG - 2011-08-20 17:12:12 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-20 17:12:12 --> Database Driver Class Initialized
DEBUG - 2011-08-20 17:12:12 --> Final output sent to browser
DEBUG - 2011-08-20 17:12:12 --> Total execution time: 0.4980
DEBUG - 2011-08-20 17:12:13 --> Config Class Initialized
DEBUG - 2011-08-20 17:12:13 --> Hooks Class Initialized
DEBUG - 2011-08-20 17:12:13 --> Utf8 Class Initialized
DEBUG - 2011-08-20 17:12:13 --> UTF-8 Support Enabled
DEBUG - 2011-08-20 17:12:13 --> URI Class Initialized
DEBUG - 2011-08-20 17:12:13 --> Router Class Initialized
ERROR - 2011-08-20 17:12:13 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-20 17:12:24 --> Config Class Initialized
DEBUG - 2011-08-20 17:12:24 --> Hooks Class Initialized
DEBUG - 2011-08-20 17:12:24 --> Utf8 Class Initialized
DEBUG - 2011-08-20 17:12:24 --> UTF-8 Support Enabled
DEBUG - 2011-08-20 17:12:24 --> URI Class Initialized
DEBUG - 2011-08-20 17:12:24 --> Router Class Initialized
DEBUG - 2011-08-20 17:12:24 --> Output Class Initialized
DEBUG - 2011-08-20 17:12:24 --> Input Class Initialized
DEBUG - 2011-08-20 17:12:24 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-20 17:12:24 --> Language Class Initialized
DEBUG - 2011-08-20 17:12:24 --> Loader Class Initialized
DEBUG - 2011-08-20 17:12:24 --> Controller Class Initialized
ERROR - 2011-08-20 17:12:24 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-20 17:12:24 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-20 17:12:24 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-20 17:12:24 --> Model Class Initialized
DEBUG - 2011-08-20 17:12:24 --> Model Class Initialized
DEBUG - 2011-08-20 17:12:24 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-20 17:12:24 --> Database Driver Class Initialized
DEBUG - 2011-08-20 17:12:24 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-20 17:12:24 --> Helper loaded: url_helper
DEBUG - 2011-08-20 17:12:24 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-20 17:12:24 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-20 17:12:24 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-20 17:12:24 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-20 17:12:24 --> Final output sent to browser
DEBUG - 2011-08-20 17:12:24 --> Total execution time: 0.0276
DEBUG - 2011-08-20 17:12:24 --> Config Class Initialized
DEBUG - 2011-08-20 17:12:24 --> Hooks Class Initialized
DEBUG - 2011-08-20 17:12:24 --> Utf8 Class Initialized
DEBUG - 2011-08-20 17:12:24 --> UTF-8 Support Enabled
DEBUG - 2011-08-20 17:12:24 --> URI Class Initialized
DEBUG - 2011-08-20 17:12:24 --> Router Class Initialized
DEBUG - 2011-08-20 17:12:24 --> Output Class Initialized
DEBUG - 2011-08-20 17:12:24 --> Input Class Initialized
DEBUG - 2011-08-20 17:12:24 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-20 17:12:24 --> Language Class Initialized
DEBUG - 2011-08-20 17:12:24 --> Loader Class Initialized
DEBUG - 2011-08-20 17:12:24 --> Controller Class Initialized
DEBUG - 2011-08-20 17:12:24 --> Model Class Initialized
DEBUG - 2011-08-20 17:12:24 --> Model Class Initialized
DEBUG - 2011-08-20 17:12:24 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-20 17:12:24 --> Database Driver Class Initialized
DEBUG - 2011-08-20 17:12:25 --> Final output sent to browser
DEBUG - 2011-08-20 17:12:25 --> Total execution time: 0.6242
DEBUG - 2011-08-20 17:12:25 --> Config Class Initialized
DEBUG - 2011-08-20 17:12:25 --> Hooks Class Initialized
DEBUG - 2011-08-20 17:12:25 --> Utf8 Class Initialized
DEBUG - 2011-08-20 17:12:25 --> UTF-8 Support Enabled
DEBUG - 2011-08-20 17:12:25 --> URI Class Initialized
DEBUG - 2011-08-20 17:12:25 --> Router Class Initialized
ERROR - 2011-08-20 17:12:25 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-20 17:12:36 --> Config Class Initialized
DEBUG - 2011-08-20 17:12:36 --> Hooks Class Initialized
DEBUG - 2011-08-20 17:12:36 --> Utf8 Class Initialized
DEBUG - 2011-08-20 17:12:36 --> UTF-8 Support Enabled
DEBUG - 2011-08-20 17:12:36 --> URI Class Initialized
DEBUG - 2011-08-20 17:12:36 --> Router Class Initialized
DEBUG - 2011-08-20 17:12:36 --> Output Class Initialized
DEBUG - 2011-08-20 17:12:36 --> Input Class Initialized
DEBUG - 2011-08-20 17:12:36 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-20 17:12:36 --> Language Class Initialized
DEBUG - 2011-08-20 17:12:36 --> Loader Class Initialized
DEBUG - 2011-08-20 17:12:36 --> Controller Class Initialized
ERROR - 2011-08-20 17:12:36 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-20 17:12:36 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-20 17:12:36 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-20 17:12:36 --> Model Class Initialized
DEBUG - 2011-08-20 17:12:36 --> Model Class Initialized
DEBUG - 2011-08-20 17:12:36 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-20 17:12:36 --> Database Driver Class Initialized
DEBUG - 2011-08-20 17:12:36 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-20 17:12:36 --> Helper loaded: url_helper
DEBUG - 2011-08-20 17:12:36 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-20 17:12:36 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-20 17:12:36 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-20 17:12:36 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-20 17:12:36 --> Final output sent to browser
DEBUG - 2011-08-20 17:12:36 --> Total execution time: 0.0294
DEBUG - 2011-08-20 17:12:36 --> Config Class Initialized
DEBUG - 2011-08-20 17:12:36 --> Hooks Class Initialized
DEBUG - 2011-08-20 17:12:36 --> Utf8 Class Initialized
DEBUG - 2011-08-20 17:12:36 --> UTF-8 Support Enabled
DEBUG - 2011-08-20 17:12:36 --> URI Class Initialized
DEBUG - 2011-08-20 17:12:36 --> Router Class Initialized
DEBUG - 2011-08-20 17:12:36 --> Output Class Initialized
DEBUG - 2011-08-20 17:12:36 --> Input Class Initialized
DEBUG - 2011-08-20 17:12:36 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-20 17:12:36 --> Language Class Initialized
DEBUG - 2011-08-20 17:12:36 --> Loader Class Initialized
DEBUG - 2011-08-20 17:12:36 --> Controller Class Initialized
DEBUG - 2011-08-20 17:12:36 --> Model Class Initialized
DEBUG - 2011-08-20 17:12:36 --> Model Class Initialized
DEBUG - 2011-08-20 17:12:36 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-20 17:12:36 --> Database Driver Class Initialized
DEBUG - 2011-08-20 17:12:37 --> Final output sent to browser
DEBUG - 2011-08-20 17:12:37 --> Total execution time: 0.5242
DEBUG - 2011-08-20 17:12:37 --> Config Class Initialized
DEBUG - 2011-08-20 17:12:37 --> Hooks Class Initialized
DEBUG - 2011-08-20 17:12:37 --> Utf8 Class Initialized
DEBUG - 2011-08-20 17:12:37 --> UTF-8 Support Enabled
DEBUG - 2011-08-20 17:12:37 --> URI Class Initialized
DEBUG - 2011-08-20 17:12:37 --> Router Class Initialized
ERROR - 2011-08-20 17:12:37 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-20 17:12:44 --> Config Class Initialized
DEBUG - 2011-08-20 17:12:44 --> Hooks Class Initialized
DEBUG - 2011-08-20 17:12:44 --> Utf8 Class Initialized
DEBUG - 2011-08-20 17:12:44 --> UTF-8 Support Enabled
DEBUG - 2011-08-20 17:12:44 --> URI Class Initialized
DEBUG - 2011-08-20 17:12:44 --> Router Class Initialized
DEBUG - 2011-08-20 17:12:44 --> Output Class Initialized
DEBUG - 2011-08-20 17:12:44 --> Input Class Initialized
DEBUG - 2011-08-20 17:12:44 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-20 17:12:44 --> Language Class Initialized
DEBUG - 2011-08-20 17:12:44 --> Loader Class Initialized
DEBUG - 2011-08-20 17:12:44 --> Controller Class Initialized
ERROR - 2011-08-20 17:12:44 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-20 17:12:44 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-20 17:12:44 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-20 17:12:44 --> Model Class Initialized
DEBUG - 2011-08-20 17:12:44 --> Model Class Initialized
DEBUG - 2011-08-20 17:12:44 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-20 17:12:44 --> Database Driver Class Initialized
DEBUG - 2011-08-20 17:12:44 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-20 17:12:44 --> Helper loaded: url_helper
DEBUG - 2011-08-20 17:12:44 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-20 17:12:44 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-20 17:12:44 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-20 17:12:44 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-20 17:12:44 --> Final output sent to browser
DEBUG - 2011-08-20 17:12:44 --> Total execution time: 0.0336
DEBUG - 2011-08-20 17:12:45 --> Config Class Initialized
DEBUG - 2011-08-20 17:12:45 --> Hooks Class Initialized
DEBUG - 2011-08-20 17:12:45 --> Utf8 Class Initialized
DEBUG - 2011-08-20 17:12:45 --> UTF-8 Support Enabled
DEBUG - 2011-08-20 17:12:45 --> URI Class Initialized
DEBUG - 2011-08-20 17:12:45 --> Router Class Initialized
DEBUG - 2011-08-20 17:12:45 --> Output Class Initialized
DEBUG - 2011-08-20 17:12:45 --> Input Class Initialized
DEBUG - 2011-08-20 17:12:45 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-20 17:12:45 --> Language Class Initialized
DEBUG - 2011-08-20 17:12:45 --> Loader Class Initialized
DEBUG - 2011-08-20 17:12:45 --> Controller Class Initialized
DEBUG - 2011-08-20 17:12:45 --> Model Class Initialized
DEBUG - 2011-08-20 17:12:45 --> Model Class Initialized
DEBUG - 2011-08-20 17:12:45 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-20 17:12:45 --> Database Driver Class Initialized
DEBUG - 2011-08-20 17:12:46 --> Final output sent to browser
DEBUG - 2011-08-20 17:12:46 --> Total execution time: 0.6294
DEBUG - 2011-08-20 17:12:46 --> Config Class Initialized
DEBUG - 2011-08-20 17:12:46 --> Hooks Class Initialized
DEBUG - 2011-08-20 17:12:46 --> Utf8 Class Initialized
DEBUG - 2011-08-20 17:12:46 --> UTF-8 Support Enabled
DEBUG - 2011-08-20 17:12:46 --> URI Class Initialized
DEBUG - 2011-08-20 17:12:46 --> Router Class Initialized
ERROR - 2011-08-20 17:12:46 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-20 17:12:53 --> Config Class Initialized
DEBUG - 2011-08-20 17:12:53 --> Hooks Class Initialized
DEBUG - 2011-08-20 17:12:53 --> Utf8 Class Initialized
DEBUG - 2011-08-20 17:12:53 --> UTF-8 Support Enabled
DEBUG - 2011-08-20 17:12:53 --> URI Class Initialized
DEBUG - 2011-08-20 17:12:53 --> Router Class Initialized
DEBUG - 2011-08-20 17:12:53 --> Output Class Initialized
DEBUG - 2011-08-20 17:12:53 --> Input Class Initialized
DEBUG - 2011-08-20 17:12:53 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-20 17:12:53 --> Language Class Initialized
DEBUG - 2011-08-20 17:12:53 --> Loader Class Initialized
DEBUG - 2011-08-20 17:12:53 --> Controller Class Initialized
ERROR - 2011-08-20 17:12:53 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-20 17:12:53 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-20 17:12:53 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-20 17:12:53 --> Model Class Initialized
DEBUG - 2011-08-20 17:12:53 --> Model Class Initialized
DEBUG - 2011-08-20 17:12:53 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-20 17:12:53 --> Database Driver Class Initialized
DEBUG - 2011-08-20 17:12:53 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-20 17:12:53 --> Helper loaded: url_helper
DEBUG - 2011-08-20 17:12:53 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-20 17:12:53 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-20 17:12:53 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-20 17:12:53 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-20 17:12:53 --> Final output sent to browser
DEBUG - 2011-08-20 17:12:53 --> Total execution time: 0.0308
DEBUG - 2011-08-20 17:12:53 --> Config Class Initialized
DEBUG - 2011-08-20 17:12:53 --> Hooks Class Initialized
DEBUG - 2011-08-20 17:12:53 --> Utf8 Class Initialized
DEBUG - 2011-08-20 17:12:53 --> UTF-8 Support Enabled
DEBUG - 2011-08-20 17:12:53 --> URI Class Initialized
DEBUG - 2011-08-20 17:12:53 --> Router Class Initialized
DEBUG - 2011-08-20 17:12:53 --> Output Class Initialized
DEBUG - 2011-08-20 17:12:53 --> Input Class Initialized
DEBUG - 2011-08-20 17:12:53 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-20 17:12:53 --> Language Class Initialized
DEBUG - 2011-08-20 17:12:53 --> Loader Class Initialized
DEBUG - 2011-08-20 17:12:53 --> Controller Class Initialized
DEBUG - 2011-08-20 17:12:53 --> Model Class Initialized
DEBUG - 2011-08-20 17:12:53 --> Model Class Initialized
DEBUG - 2011-08-20 17:12:53 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-20 17:12:53 --> Database Driver Class Initialized
DEBUG - 2011-08-20 17:12:54 --> Final output sent to browser
DEBUG - 2011-08-20 17:12:54 --> Total execution time: 0.5134
DEBUG - 2011-08-20 17:12:54 --> Config Class Initialized
DEBUG - 2011-08-20 17:12:54 --> Hooks Class Initialized
DEBUG - 2011-08-20 17:12:54 --> Utf8 Class Initialized
DEBUG - 2011-08-20 17:12:54 --> UTF-8 Support Enabled
DEBUG - 2011-08-20 17:12:54 --> URI Class Initialized
DEBUG - 2011-08-20 17:12:54 --> Router Class Initialized
ERROR - 2011-08-20 17:12:54 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-20 17:12:58 --> Config Class Initialized
DEBUG - 2011-08-20 17:12:58 --> Hooks Class Initialized
DEBUG - 2011-08-20 17:12:58 --> Utf8 Class Initialized
DEBUG - 2011-08-20 17:12:58 --> UTF-8 Support Enabled
DEBUG - 2011-08-20 17:12:58 --> URI Class Initialized
DEBUG - 2011-08-20 17:12:58 --> Router Class Initialized
DEBUG - 2011-08-20 17:12:58 --> Output Class Initialized
DEBUG - 2011-08-20 17:12:58 --> Input Class Initialized
DEBUG - 2011-08-20 17:12:58 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-20 17:12:58 --> Language Class Initialized
DEBUG - 2011-08-20 17:12:58 --> Loader Class Initialized
DEBUG - 2011-08-20 17:12:58 --> Controller Class Initialized
ERROR - 2011-08-20 17:12:58 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-20 17:12:58 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-20 17:12:58 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-20 17:12:58 --> Model Class Initialized
DEBUG - 2011-08-20 17:12:58 --> Model Class Initialized
DEBUG - 2011-08-20 17:12:58 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-20 17:12:58 --> Database Driver Class Initialized
DEBUG - 2011-08-20 17:12:58 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-20 17:12:58 --> Helper loaded: url_helper
DEBUG - 2011-08-20 17:12:58 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-20 17:12:58 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-20 17:12:58 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-20 17:12:58 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-20 17:12:58 --> Final output sent to browser
DEBUG - 2011-08-20 17:12:58 --> Total execution time: 0.0282
DEBUG - 2011-08-20 17:12:59 --> Config Class Initialized
DEBUG - 2011-08-20 17:12:59 --> Hooks Class Initialized
DEBUG - 2011-08-20 17:12:59 --> Utf8 Class Initialized
DEBUG - 2011-08-20 17:12:59 --> UTF-8 Support Enabled
DEBUG - 2011-08-20 17:12:59 --> URI Class Initialized
DEBUG - 2011-08-20 17:12:59 --> Router Class Initialized
DEBUG - 2011-08-20 17:12:59 --> Output Class Initialized
DEBUG - 2011-08-20 17:12:59 --> Input Class Initialized
DEBUG - 2011-08-20 17:12:59 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-20 17:12:59 --> Language Class Initialized
DEBUG - 2011-08-20 17:12:59 --> Loader Class Initialized
DEBUG - 2011-08-20 17:12:59 --> Controller Class Initialized
DEBUG - 2011-08-20 17:12:59 --> Model Class Initialized
DEBUG - 2011-08-20 17:12:59 --> Model Class Initialized
DEBUG - 2011-08-20 17:12:59 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-20 17:12:59 --> Database Driver Class Initialized
DEBUG - 2011-08-20 17:12:59 --> Final output sent to browser
DEBUG - 2011-08-20 17:12:59 --> Total execution time: 0.5519
DEBUG - 2011-08-20 17:13:00 --> Config Class Initialized
DEBUG - 2011-08-20 17:13:00 --> Hooks Class Initialized
DEBUG - 2011-08-20 17:13:00 --> Utf8 Class Initialized
DEBUG - 2011-08-20 17:13:00 --> UTF-8 Support Enabled
DEBUG - 2011-08-20 17:13:00 --> URI Class Initialized
DEBUG - 2011-08-20 17:13:00 --> Router Class Initialized
ERROR - 2011-08-20 17:13:00 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-20 17:13:04 --> Config Class Initialized
DEBUG - 2011-08-20 17:13:04 --> Hooks Class Initialized
DEBUG - 2011-08-20 17:13:04 --> Utf8 Class Initialized
DEBUG - 2011-08-20 17:13:04 --> UTF-8 Support Enabled
DEBUG - 2011-08-20 17:13:04 --> URI Class Initialized
DEBUG - 2011-08-20 17:13:04 --> Router Class Initialized
DEBUG - 2011-08-20 17:13:04 --> Output Class Initialized
DEBUG - 2011-08-20 17:13:04 --> Input Class Initialized
DEBUG - 2011-08-20 17:13:04 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-20 17:13:04 --> Language Class Initialized
DEBUG - 2011-08-20 17:13:04 --> Loader Class Initialized
DEBUG - 2011-08-20 17:13:04 --> Controller Class Initialized
ERROR - 2011-08-20 17:13:04 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-20 17:13:04 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-20 17:13:04 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-20 17:13:04 --> Model Class Initialized
DEBUG - 2011-08-20 17:13:04 --> Model Class Initialized
DEBUG - 2011-08-20 17:13:04 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-20 17:13:04 --> Database Driver Class Initialized
DEBUG - 2011-08-20 17:13:04 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-20 17:13:04 --> Helper loaded: url_helper
DEBUG - 2011-08-20 17:13:04 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-20 17:13:04 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-20 17:13:04 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-20 17:13:04 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-20 17:13:04 --> Final output sent to browser
DEBUG - 2011-08-20 17:13:04 --> Total execution time: 0.0422
DEBUG - 2011-08-20 17:13:05 --> Config Class Initialized
DEBUG - 2011-08-20 17:13:05 --> Hooks Class Initialized
DEBUG - 2011-08-20 17:13:05 --> Utf8 Class Initialized
DEBUG - 2011-08-20 17:13:05 --> UTF-8 Support Enabled
DEBUG - 2011-08-20 17:13:05 --> URI Class Initialized
DEBUG - 2011-08-20 17:13:05 --> Router Class Initialized
DEBUG - 2011-08-20 17:13:05 --> Output Class Initialized
DEBUG - 2011-08-20 17:13:05 --> Input Class Initialized
DEBUG - 2011-08-20 17:13:05 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-20 17:13:05 --> Language Class Initialized
DEBUG - 2011-08-20 17:13:05 --> Loader Class Initialized
DEBUG - 2011-08-20 17:13:05 --> Controller Class Initialized
DEBUG - 2011-08-20 17:13:05 --> Model Class Initialized
DEBUG - 2011-08-20 17:13:05 --> Model Class Initialized
DEBUG - 2011-08-20 17:13:05 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-20 17:13:05 --> Database Driver Class Initialized
DEBUG - 2011-08-20 17:13:05 --> Final output sent to browser
DEBUG - 2011-08-20 17:13:05 --> Total execution time: 0.5581
DEBUG - 2011-08-20 17:13:06 --> Config Class Initialized
DEBUG - 2011-08-20 17:13:06 --> Hooks Class Initialized
DEBUG - 2011-08-20 17:13:06 --> Utf8 Class Initialized
DEBUG - 2011-08-20 17:13:06 --> UTF-8 Support Enabled
DEBUG - 2011-08-20 17:13:06 --> URI Class Initialized
DEBUG - 2011-08-20 17:13:06 --> Router Class Initialized
ERROR - 2011-08-20 17:13:06 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-20 17:13:09 --> Config Class Initialized
DEBUG - 2011-08-20 17:13:09 --> Hooks Class Initialized
DEBUG - 2011-08-20 17:13:09 --> Utf8 Class Initialized
DEBUG - 2011-08-20 17:13:09 --> UTF-8 Support Enabled
DEBUG - 2011-08-20 17:13:09 --> URI Class Initialized
DEBUG - 2011-08-20 17:13:09 --> Router Class Initialized
DEBUG - 2011-08-20 17:13:09 --> Output Class Initialized
DEBUG - 2011-08-20 17:13:09 --> Input Class Initialized
DEBUG - 2011-08-20 17:13:09 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-20 17:13:09 --> Language Class Initialized
DEBUG - 2011-08-20 17:13:09 --> Loader Class Initialized
DEBUG - 2011-08-20 17:13:09 --> Controller Class Initialized
ERROR - 2011-08-20 17:13:09 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-20 17:13:09 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-20 17:13:09 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-20 17:13:09 --> Model Class Initialized
DEBUG - 2011-08-20 17:13:09 --> Model Class Initialized
DEBUG - 2011-08-20 17:13:09 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-20 17:13:09 --> Database Driver Class Initialized
DEBUG - 2011-08-20 17:13:09 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-20 17:13:09 --> Helper loaded: url_helper
DEBUG - 2011-08-20 17:13:09 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-20 17:13:09 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-20 17:13:09 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-20 17:13:09 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-20 17:13:09 --> Final output sent to browser
DEBUG - 2011-08-20 17:13:09 --> Total execution time: 0.0268
DEBUG - 2011-08-20 17:13:10 --> Config Class Initialized
DEBUG - 2011-08-20 17:13:10 --> Hooks Class Initialized
DEBUG - 2011-08-20 17:13:10 --> Utf8 Class Initialized
DEBUG - 2011-08-20 17:13:10 --> UTF-8 Support Enabled
DEBUG - 2011-08-20 17:13:10 --> URI Class Initialized
DEBUG - 2011-08-20 17:13:10 --> Router Class Initialized
DEBUG - 2011-08-20 17:13:10 --> Output Class Initialized
DEBUG - 2011-08-20 17:13:10 --> Input Class Initialized
DEBUG - 2011-08-20 17:13:10 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-20 17:13:10 --> Language Class Initialized
DEBUG - 2011-08-20 17:13:10 --> Loader Class Initialized
DEBUG - 2011-08-20 17:13:10 --> Controller Class Initialized
DEBUG - 2011-08-20 17:13:10 --> Model Class Initialized
DEBUG - 2011-08-20 17:13:10 --> Model Class Initialized
DEBUG - 2011-08-20 17:13:10 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-20 17:13:10 --> Database Driver Class Initialized
DEBUG - 2011-08-20 17:13:10 --> Final output sent to browser
DEBUG - 2011-08-20 17:13:10 --> Total execution time: 0.4122
DEBUG - 2011-08-20 17:13:10 --> Config Class Initialized
DEBUG - 2011-08-20 17:13:10 --> Hooks Class Initialized
DEBUG - 2011-08-20 17:13:10 --> Utf8 Class Initialized
DEBUG - 2011-08-20 17:13:10 --> UTF-8 Support Enabled
DEBUG - 2011-08-20 17:13:10 --> URI Class Initialized
DEBUG - 2011-08-20 17:13:10 --> Router Class Initialized
ERROR - 2011-08-20 17:13:10 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-20 17:13:30 --> Config Class Initialized
DEBUG - 2011-08-20 17:13:30 --> Hooks Class Initialized
DEBUG - 2011-08-20 17:13:30 --> Utf8 Class Initialized
DEBUG - 2011-08-20 17:13:30 --> UTF-8 Support Enabled
DEBUG - 2011-08-20 17:13:30 --> URI Class Initialized
DEBUG - 2011-08-20 17:13:30 --> Router Class Initialized
DEBUG - 2011-08-20 17:13:30 --> Output Class Initialized
DEBUG - 2011-08-20 17:13:30 --> Input Class Initialized
DEBUG - 2011-08-20 17:13:30 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-20 17:13:30 --> Language Class Initialized
DEBUG - 2011-08-20 17:13:30 --> Loader Class Initialized
DEBUG - 2011-08-20 17:13:30 --> Controller Class Initialized
ERROR - 2011-08-20 17:13:30 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-20 17:13:30 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-20 17:13:30 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-20 17:13:30 --> Model Class Initialized
DEBUG - 2011-08-20 17:13:30 --> Model Class Initialized
DEBUG - 2011-08-20 17:13:30 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-20 17:13:30 --> Database Driver Class Initialized
DEBUG - 2011-08-20 17:13:30 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-20 17:13:30 --> Helper loaded: url_helper
DEBUG - 2011-08-20 17:13:30 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-20 17:13:30 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-20 17:13:30 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-20 17:13:30 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-20 17:13:30 --> Final output sent to browser
DEBUG - 2011-08-20 17:13:30 --> Total execution time: 0.0333
DEBUG - 2011-08-20 17:30:40 --> Config Class Initialized
DEBUG - 2011-08-20 17:30:40 --> Hooks Class Initialized
DEBUG - 2011-08-20 17:30:40 --> Utf8 Class Initialized
DEBUG - 2011-08-20 17:30:40 --> UTF-8 Support Enabled
DEBUG - 2011-08-20 17:30:40 --> URI Class Initialized
DEBUG - 2011-08-20 17:30:40 --> Router Class Initialized
ERROR - 2011-08-20 17:30:40 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-08-20 17:41:48 --> Config Class Initialized
DEBUG - 2011-08-20 17:41:48 --> Hooks Class Initialized
DEBUG - 2011-08-20 17:41:48 --> Utf8 Class Initialized
DEBUG - 2011-08-20 17:41:48 --> UTF-8 Support Enabled
DEBUG - 2011-08-20 17:41:48 --> URI Class Initialized
DEBUG - 2011-08-20 17:41:48 --> Router Class Initialized
DEBUG - 2011-08-20 17:41:48 --> No URI present. Default controller set.
DEBUG - 2011-08-20 17:41:48 --> Output Class Initialized
DEBUG - 2011-08-20 17:41:48 --> Input Class Initialized
DEBUG - 2011-08-20 17:41:48 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-20 17:41:48 --> Language Class Initialized
DEBUG - 2011-08-20 17:41:48 --> Loader Class Initialized
DEBUG - 2011-08-20 17:41:48 --> Controller Class Initialized
DEBUG - 2011-08-20 17:41:48 --> File loaded: application/views/splash/main.php
DEBUG - 2011-08-20 17:41:48 --> Helper loaded: url_helper
DEBUG - 2011-08-20 17:41:48 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-20 17:41:48 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-20 17:41:48 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-20 17:41:48 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-20 17:41:48 --> Final output sent to browser
DEBUG - 2011-08-20 17:41:48 --> Total execution time: 0.0131
DEBUG - 2011-08-20 17:54:48 --> Config Class Initialized
DEBUG - 2011-08-20 17:54:48 --> Hooks Class Initialized
DEBUG - 2011-08-20 17:54:48 --> Utf8 Class Initialized
DEBUG - 2011-08-20 17:54:48 --> UTF-8 Support Enabled
DEBUG - 2011-08-20 17:54:48 --> URI Class Initialized
DEBUG - 2011-08-20 17:54:48 --> Router Class Initialized
DEBUG - 2011-08-20 17:54:48 --> Output Class Initialized
DEBUG - 2011-08-20 17:54:48 --> Input Class Initialized
DEBUG - 2011-08-20 17:54:48 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-20 17:54:48 --> Language Class Initialized
DEBUG - 2011-08-20 17:54:48 --> Loader Class Initialized
DEBUG - 2011-08-20 17:54:48 --> Controller Class Initialized
ERROR - 2011-08-20 17:54:48 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-20 17:54:48 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-20 17:54:48 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-20 17:54:48 --> Model Class Initialized
DEBUG - 2011-08-20 17:54:48 --> Model Class Initialized
DEBUG - 2011-08-20 17:54:48 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-20 17:54:48 --> Database Driver Class Initialized
DEBUG - 2011-08-20 17:54:48 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-20 17:54:48 --> Helper loaded: url_helper
DEBUG - 2011-08-20 17:54:48 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-20 17:54:48 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-20 17:54:48 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-20 17:54:48 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-20 17:54:48 --> Final output sent to browser
DEBUG - 2011-08-20 17:54:48 --> Total execution time: 0.0320
DEBUG - 2011-08-20 17:54:48 --> Config Class Initialized
DEBUG - 2011-08-20 17:54:48 --> Hooks Class Initialized
DEBUG - 2011-08-20 17:54:48 --> Utf8 Class Initialized
DEBUG - 2011-08-20 17:54:48 --> UTF-8 Support Enabled
DEBUG - 2011-08-20 17:54:48 --> URI Class Initialized
DEBUG - 2011-08-20 17:54:48 --> Router Class Initialized
DEBUG - 2011-08-20 17:54:48 --> Output Class Initialized
DEBUG - 2011-08-20 17:54:48 --> Input Class Initialized
DEBUG - 2011-08-20 17:54:48 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-20 17:54:48 --> Language Class Initialized
DEBUG - 2011-08-20 17:54:48 --> Loader Class Initialized
DEBUG - 2011-08-20 17:54:48 --> Controller Class Initialized
DEBUG - 2011-08-20 17:54:48 --> Model Class Initialized
DEBUG - 2011-08-20 17:54:48 --> Model Class Initialized
DEBUG - 2011-08-20 17:54:48 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-20 17:54:48 --> Database Driver Class Initialized
DEBUG - 2011-08-20 17:54:49 --> Final output sent to browser
DEBUG - 2011-08-20 17:54:49 --> Total execution time: 0.5200
DEBUG - 2011-08-20 17:54:50 --> Config Class Initialized
DEBUG - 2011-08-20 17:54:50 --> Hooks Class Initialized
DEBUG - 2011-08-20 17:54:50 --> Utf8 Class Initialized
DEBUG - 2011-08-20 17:54:50 --> UTF-8 Support Enabled
DEBUG - 2011-08-20 17:54:50 --> URI Class Initialized
DEBUG - 2011-08-20 17:54:50 --> Router Class Initialized
ERROR - 2011-08-20 17:54:50 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-20 17:54:50 --> Config Class Initialized
DEBUG - 2011-08-20 17:54:50 --> Hooks Class Initialized
DEBUG - 2011-08-20 17:54:50 --> Utf8 Class Initialized
DEBUG - 2011-08-20 17:54:50 --> UTF-8 Support Enabled
DEBUG - 2011-08-20 17:54:50 --> URI Class Initialized
DEBUG - 2011-08-20 17:54:50 --> Router Class Initialized
ERROR - 2011-08-20 17:54:50 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-20 17:54:51 --> Config Class Initialized
DEBUG - 2011-08-20 17:54:51 --> Hooks Class Initialized
DEBUG - 2011-08-20 17:54:51 --> Utf8 Class Initialized
DEBUG - 2011-08-20 17:54:51 --> UTF-8 Support Enabled
DEBUG - 2011-08-20 17:54:51 --> URI Class Initialized
DEBUG - 2011-08-20 17:54:51 --> Router Class Initialized
ERROR - 2011-08-20 17:54:51 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-20 18:14:49 --> Config Class Initialized
DEBUG - 2011-08-20 18:14:49 --> Hooks Class Initialized
DEBUG - 2011-08-20 18:14:49 --> Utf8 Class Initialized
DEBUG - 2011-08-20 18:14:49 --> UTF-8 Support Enabled
DEBUG - 2011-08-20 18:14:49 --> URI Class Initialized
DEBUG - 2011-08-20 18:14:49 --> Router Class Initialized
DEBUG - 2011-08-20 18:14:49 --> Output Class Initialized
DEBUG - 2011-08-20 18:14:49 --> Input Class Initialized
DEBUG - 2011-08-20 18:14:49 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-20 18:14:49 --> Language Class Initialized
DEBUG - 2011-08-20 18:14:49 --> Loader Class Initialized
DEBUG - 2011-08-20 18:14:49 --> Controller Class Initialized
DEBUG - 2011-08-20 18:14:49 --> Model Class Initialized
DEBUG - 2011-08-20 18:14:49 --> Model Class Initialized
DEBUG - 2011-08-20 18:14:49 --> Model Class Initialized
DEBUG - 2011-08-20 18:14:49 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-20 18:14:49 --> Database Driver Class Initialized
DEBUG - 2011-08-20 18:14:50 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-20 18:14:50 --> Helper loaded: url_helper
DEBUG - 2011-08-20 18:14:50 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-20 18:14:50 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-20 18:14:50 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-20 18:14:50 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-20 18:14:50 --> Final output sent to browser
DEBUG - 2011-08-20 18:14:50 --> Total execution time: 0.8311
DEBUG - 2011-08-20 18:16:16 --> Config Class Initialized
DEBUG - 2011-08-20 18:16:16 --> Hooks Class Initialized
DEBUG - 2011-08-20 18:16:16 --> Utf8 Class Initialized
DEBUG - 2011-08-20 18:16:16 --> UTF-8 Support Enabled
DEBUG - 2011-08-20 18:16:16 --> URI Class Initialized
DEBUG - 2011-08-20 18:16:16 --> Router Class Initialized
DEBUG - 2011-08-20 18:16:16 --> Output Class Initialized
DEBUG - 2011-08-20 18:16:16 --> Input Class Initialized
DEBUG - 2011-08-20 18:16:16 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-20 18:16:16 --> Language Class Initialized
DEBUG - 2011-08-20 18:16:16 --> Loader Class Initialized
DEBUG - 2011-08-20 18:16:16 --> Controller Class Initialized
ERROR - 2011-08-20 18:16:16 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-20 18:16:16 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-20 18:16:16 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-20 18:16:16 --> Model Class Initialized
DEBUG - 2011-08-20 18:16:16 --> Model Class Initialized
DEBUG - 2011-08-20 18:16:16 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-20 18:16:16 --> Database Driver Class Initialized
DEBUG - 2011-08-20 18:16:16 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-20 18:16:16 --> Helper loaded: url_helper
DEBUG - 2011-08-20 18:16:16 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-20 18:16:16 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-20 18:16:16 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-20 18:16:16 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-20 18:16:16 --> Final output sent to browser
DEBUG - 2011-08-20 18:16:16 --> Total execution time: 0.0292
DEBUG - 2011-08-20 18:16:18 --> Config Class Initialized
DEBUG - 2011-08-20 18:16:18 --> Hooks Class Initialized
DEBUG - 2011-08-20 18:16:18 --> Utf8 Class Initialized
DEBUG - 2011-08-20 18:16:18 --> UTF-8 Support Enabled
DEBUG - 2011-08-20 18:16:18 --> URI Class Initialized
DEBUG - 2011-08-20 18:16:18 --> Router Class Initialized
DEBUG - 2011-08-20 18:16:18 --> Output Class Initialized
DEBUG - 2011-08-20 18:16:18 --> Input Class Initialized
DEBUG - 2011-08-20 18:16:18 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-20 18:16:18 --> Language Class Initialized
DEBUG - 2011-08-20 18:16:18 --> Loader Class Initialized
DEBUG - 2011-08-20 18:16:18 --> Controller Class Initialized
DEBUG - 2011-08-20 18:16:18 --> Model Class Initialized
DEBUG - 2011-08-20 18:16:18 --> Model Class Initialized
DEBUG - 2011-08-20 18:16:18 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-20 18:16:18 --> Database Driver Class Initialized
DEBUG - 2011-08-20 18:16:18 --> Final output sent to browser
DEBUG - 2011-08-20 18:16:18 --> Total execution time: 0.7241
DEBUG - 2011-08-20 18:16:20 --> Config Class Initialized
DEBUG - 2011-08-20 18:16:20 --> Hooks Class Initialized
DEBUG - 2011-08-20 18:16:20 --> Utf8 Class Initialized
DEBUG - 2011-08-20 18:16:20 --> UTF-8 Support Enabled
DEBUG - 2011-08-20 18:16:20 --> URI Class Initialized
DEBUG - 2011-08-20 18:16:20 --> Router Class Initialized
ERROR - 2011-08-20 18:16:20 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-20 18:28:53 --> Config Class Initialized
DEBUG - 2011-08-20 18:28:53 --> Hooks Class Initialized
DEBUG - 2011-08-20 18:28:53 --> Utf8 Class Initialized
DEBUG - 2011-08-20 18:28:53 --> UTF-8 Support Enabled
DEBUG - 2011-08-20 18:28:53 --> URI Class Initialized
DEBUG - 2011-08-20 18:28:53 --> Router Class Initialized
DEBUG - 2011-08-20 18:28:53 --> Output Class Initialized
DEBUG - 2011-08-20 18:28:53 --> Input Class Initialized
DEBUG - 2011-08-20 18:28:53 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-20 18:28:53 --> Language Class Initialized
DEBUG - 2011-08-20 18:28:53 --> Loader Class Initialized
DEBUG - 2011-08-20 18:28:53 --> Controller Class Initialized
DEBUG - 2011-08-20 18:28:53 --> Model Class Initialized
DEBUG - 2011-08-20 18:28:53 --> Model Class Initialized
DEBUG - 2011-08-20 18:28:53 --> Model Class Initialized
DEBUG - 2011-08-20 18:28:53 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-20 18:28:53 --> Database Driver Class Initialized
DEBUG - 2011-08-20 18:28:53 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-20 18:28:53 --> Helper loaded: url_helper
DEBUG - 2011-08-20 18:28:53 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-20 18:28:53 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-20 18:28:53 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-20 18:28:53 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-20 18:28:53 --> Final output sent to browser
DEBUG - 2011-08-20 18:28:53 --> Total execution time: 0.0421
DEBUG - 2011-08-20 18:28:54 --> Config Class Initialized
DEBUG - 2011-08-20 18:28:54 --> Hooks Class Initialized
DEBUG - 2011-08-20 18:28:54 --> Utf8 Class Initialized
DEBUG - 2011-08-20 18:28:54 --> UTF-8 Support Enabled
DEBUG - 2011-08-20 18:28:54 --> URI Class Initialized
DEBUG - 2011-08-20 18:28:54 --> Router Class Initialized
ERROR - 2011-08-20 18:28:54 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-20 19:09:43 --> Config Class Initialized
DEBUG - 2011-08-20 19:09:43 --> Hooks Class Initialized
DEBUG - 2011-08-20 19:09:43 --> Utf8 Class Initialized
DEBUG - 2011-08-20 19:09:43 --> UTF-8 Support Enabled
DEBUG - 2011-08-20 19:09:43 --> URI Class Initialized
DEBUG - 2011-08-20 19:09:43 --> Router Class Initialized
DEBUG - 2011-08-20 19:09:43 --> Output Class Initialized
DEBUG - 2011-08-20 19:09:43 --> Input Class Initialized
DEBUG - 2011-08-20 19:09:43 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-20 19:09:43 --> Language Class Initialized
DEBUG - 2011-08-20 19:09:43 --> Loader Class Initialized
DEBUG - 2011-08-20 19:09:43 --> Controller Class Initialized
DEBUG - 2011-08-20 19:09:43 --> Model Class Initialized
DEBUG - 2011-08-20 19:09:43 --> Model Class Initialized
DEBUG - 2011-08-20 19:09:43 --> Model Class Initialized
DEBUG - 2011-08-20 19:09:43 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-20 19:09:43 --> Database Driver Class Initialized
DEBUG - 2011-08-20 19:09:43 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-20 19:09:43 --> Helper loaded: url_helper
DEBUG - 2011-08-20 19:09:43 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-20 19:09:43 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-20 19:09:43 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-20 19:09:43 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-20 19:09:43 --> Final output sent to browser
DEBUG - 2011-08-20 19:09:43 --> Total execution time: 0.6227
DEBUG - 2011-08-20 19:09:45 --> Config Class Initialized
DEBUG - 2011-08-20 19:09:45 --> Hooks Class Initialized
DEBUG - 2011-08-20 19:09:45 --> Utf8 Class Initialized
DEBUG - 2011-08-20 19:09:45 --> UTF-8 Support Enabled
DEBUG - 2011-08-20 19:09:45 --> URI Class Initialized
DEBUG - 2011-08-20 19:09:45 --> Router Class Initialized
DEBUG - 2011-08-20 19:09:45 --> Output Class Initialized
DEBUG - 2011-08-20 19:09:45 --> Input Class Initialized
DEBUG - 2011-08-20 19:09:45 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-20 19:09:45 --> Language Class Initialized
DEBUG - 2011-08-20 19:09:45 --> Loader Class Initialized
DEBUG - 2011-08-20 19:09:45 --> Controller Class Initialized
ERROR - 2011-08-20 19:09:45 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-20 19:09:45 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-20 19:09:45 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-20 19:09:45 --> Model Class Initialized
DEBUG - 2011-08-20 19:09:45 --> Model Class Initialized
DEBUG - 2011-08-20 19:09:45 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-20 19:09:45 --> Database Driver Class Initialized
DEBUG - 2011-08-20 19:09:45 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-20 19:09:45 --> Helper loaded: url_helper
DEBUG - 2011-08-20 19:09:45 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-20 19:09:45 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-20 19:09:45 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-20 19:09:45 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-20 19:09:45 --> Final output sent to browser
DEBUG - 2011-08-20 19:09:45 --> Total execution time: 0.0291
DEBUG - 2011-08-20 20:23:26 --> Config Class Initialized
DEBUG - 2011-08-20 20:23:26 --> Hooks Class Initialized
DEBUG - 2011-08-20 20:23:26 --> Utf8 Class Initialized
DEBUG - 2011-08-20 20:23:26 --> UTF-8 Support Enabled
DEBUG - 2011-08-20 20:23:26 --> URI Class Initialized
DEBUG - 2011-08-20 20:23:26 --> Router Class Initialized
DEBUG - 2011-08-20 20:23:26 --> Output Class Initialized
DEBUG - 2011-08-20 20:23:26 --> Input Class Initialized
DEBUG - 2011-08-20 20:23:26 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-20 20:23:26 --> Language Class Initialized
DEBUG - 2011-08-20 20:23:26 --> Loader Class Initialized
DEBUG - 2011-08-20 20:23:26 --> Controller Class Initialized
ERROR - 2011-08-20 20:23:26 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-20 20:23:26 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-20 20:23:26 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-20 20:23:26 --> Model Class Initialized
DEBUG - 2011-08-20 20:23:26 --> Model Class Initialized
DEBUG - 2011-08-20 20:23:26 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-20 20:23:26 --> Database Driver Class Initialized
DEBUG - 2011-08-20 20:23:26 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-20 20:23:26 --> Helper loaded: url_helper
DEBUG - 2011-08-20 20:23:26 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-20 20:23:26 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-20 20:23:26 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-20 20:23:26 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-20 20:23:26 --> Final output sent to browser
DEBUG - 2011-08-20 20:23:26 --> Total execution time: 0.0958
DEBUG - 2011-08-20 20:23:28 --> Config Class Initialized
DEBUG - 2011-08-20 20:23:28 --> Hooks Class Initialized
DEBUG - 2011-08-20 20:23:28 --> Utf8 Class Initialized
DEBUG - 2011-08-20 20:23:28 --> UTF-8 Support Enabled
DEBUG - 2011-08-20 20:23:28 --> URI Class Initialized
DEBUG - 2011-08-20 20:23:28 --> Router Class Initialized
DEBUG - 2011-08-20 20:23:28 --> Output Class Initialized
DEBUG - 2011-08-20 20:23:28 --> Input Class Initialized
DEBUG - 2011-08-20 20:23:28 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-20 20:23:28 --> Language Class Initialized
DEBUG - 2011-08-20 20:23:28 --> Loader Class Initialized
DEBUG - 2011-08-20 20:23:28 --> Controller Class Initialized
DEBUG - 2011-08-20 20:23:28 --> Model Class Initialized
DEBUG - 2011-08-20 20:23:28 --> Model Class Initialized
DEBUG - 2011-08-20 20:23:28 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-20 20:23:28 --> Database Driver Class Initialized
DEBUG - 2011-08-20 20:23:29 --> Final output sent to browser
DEBUG - 2011-08-20 20:23:29 --> Total execution time: 0.6891
DEBUG - 2011-08-20 20:23:30 --> Config Class Initialized
DEBUG - 2011-08-20 20:23:30 --> Hooks Class Initialized
DEBUG - 2011-08-20 20:23:30 --> Utf8 Class Initialized
DEBUG - 2011-08-20 20:23:30 --> UTF-8 Support Enabled
DEBUG - 2011-08-20 20:23:30 --> URI Class Initialized
DEBUG - 2011-08-20 20:23:30 --> Router Class Initialized
ERROR - 2011-08-20 20:23:30 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-20 20:23:31 --> Config Class Initialized
DEBUG - 2011-08-20 20:23:31 --> Hooks Class Initialized
DEBUG - 2011-08-20 20:23:31 --> Utf8 Class Initialized
DEBUG - 2011-08-20 20:23:31 --> UTF-8 Support Enabled
DEBUG - 2011-08-20 20:23:31 --> URI Class Initialized
DEBUG - 2011-08-20 20:23:31 --> Router Class Initialized
ERROR - 2011-08-20 20:23:31 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-20 20:23:41 --> Config Class Initialized
DEBUG - 2011-08-20 20:23:41 --> Hooks Class Initialized
DEBUG - 2011-08-20 20:23:41 --> Utf8 Class Initialized
DEBUG - 2011-08-20 20:23:41 --> UTF-8 Support Enabled
DEBUG - 2011-08-20 20:23:41 --> URI Class Initialized
DEBUG - 2011-08-20 20:23:41 --> Router Class Initialized
DEBUG - 2011-08-20 20:23:41 --> Output Class Initialized
DEBUG - 2011-08-20 20:23:41 --> Input Class Initialized
DEBUG - 2011-08-20 20:23:41 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-20 20:23:41 --> Language Class Initialized
DEBUG - 2011-08-20 20:23:41 --> Loader Class Initialized
DEBUG - 2011-08-20 20:23:41 --> Controller Class Initialized
ERROR - 2011-08-20 20:23:41 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-20 20:23:41 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-20 20:23:41 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-20 20:23:41 --> Model Class Initialized
DEBUG - 2011-08-20 20:23:41 --> Model Class Initialized
DEBUG - 2011-08-20 20:23:41 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-20 20:23:41 --> Database Driver Class Initialized
DEBUG - 2011-08-20 20:23:41 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-20 20:23:41 --> Helper loaded: url_helper
DEBUG - 2011-08-20 20:23:41 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-20 20:23:41 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-20 20:23:41 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-20 20:23:41 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-20 20:23:41 --> Final output sent to browser
DEBUG - 2011-08-20 20:23:41 --> Total execution time: 0.0293
DEBUG - 2011-08-20 20:23:42 --> Config Class Initialized
DEBUG - 2011-08-20 20:23:42 --> Hooks Class Initialized
DEBUG - 2011-08-20 20:23:42 --> Utf8 Class Initialized
DEBUG - 2011-08-20 20:23:42 --> UTF-8 Support Enabled
DEBUG - 2011-08-20 20:23:42 --> URI Class Initialized
DEBUG - 2011-08-20 20:23:42 --> Router Class Initialized
DEBUG - 2011-08-20 20:23:42 --> Output Class Initialized
DEBUG - 2011-08-20 20:23:42 --> Input Class Initialized
DEBUG - 2011-08-20 20:23:42 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-20 20:23:42 --> Language Class Initialized
DEBUG - 2011-08-20 20:23:42 --> Loader Class Initialized
DEBUG - 2011-08-20 20:23:42 --> Controller Class Initialized
DEBUG - 2011-08-20 20:23:42 --> Model Class Initialized
DEBUG - 2011-08-20 20:23:42 --> Model Class Initialized
DEBUG - 2011-08-20 20:23:42 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-20 20:23:42 --> Database Driver Class Initialized
DEBUG - 2011-08-20 20:23:42 --> Final output sent to browser
DEBUG - 2011-08-20 20:23:42 --> Total execution time: 0.6041
DEBUG - 2011-08-20 20:23:44 --> Config Class Initialized
DEBUG - 2011-08-20 20:23:44 --> Hooks Class Initialized
DEBUG - 2011-08-20 20:23:44 --> Utf8 Class Initialized
DEBUG - 2011-08-20 20:23:44 --> UTF-8 Support Enabled
DEBUG - 2011-08-20 20:23:44 --> URI Class Initialized
DEBUG - 2011-08-20 20:23:44 --> Router Class Initialized
ERROR - 2011-08-20 20:23:44 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-20 20:23:48 --> Config Class Initialized
DEBUG - 2011-08-20 20:23:48 --> Hooks Class Initialized
DEBUG - 2011-08-20 20:23:48 --> Utf8 Class Initialized
DEBUG - 2011-08-20 20:23:48 --> UTF-8 Support Enabled
DEBUG - 2011-08-20 20:23:48 --> URI Class Initialized
DEBUG - 2011-08-20 20:23:48 --> Router Class Initialized
DEBUG - 2011-08-20 20:23:48 --> Output Class Initialized
DEBUG - 2011-08-20 20:23:48 --> Input Class Initialized
DEBUG - 2011-08-20 20:23:48 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-20 20:23:48 --> Language Class Initialized
DEBUG - 2011-08-20 20:23:48 --> Loader Class Initialized
DEBUG - 2011-08-20 20:23:48 --> Controller Class Initialized
ERROR - 2011-08-20 20:23:48 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-20 20:23:48 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-20 20:23:48 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-20 20:23:48 --> Model Class Initialized
DEBUG - 2011-08-20 20:23:48 --> Model Class Initialized
DEBUG - 2011-08-20 20:23:48 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-20 20:23:48 --> Database Driver Class Initialized
DEBUG - 2011-08-20 20:23:48 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-20 20:23:48 --> Helper loaded: url_helper
DEBUG - 2011-08-20 20:23:48 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-20 20:23:48 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-20 20:23:48 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-20 20:23:48 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-20 20:23:48 --> Final output sent to browser
DEBUG - 2011-08-20 20:23:48 --> Total execution time: 0.0293
DEBUG - 2011-08-20 20:23:49 --> Config Class Initialized
DEBUG - 2011-08-20 20:23:49 --> Hooks Class Initialized
DEBUG - 2011-08-20 20:23:49 --> Utf8 Class Initialized
DEBUG - 2011-08-20 20:23:49 --> UTF-8 Support Enabled
DEBUG - 2011-08-20 20:23:49 --> URI Class Initialized
DEBUG - 2011-08-20 20:23:49 --> Router Class Initialized
DEBUG - 2011-08-20 20:23:49 --> Output Class Initialized
DEBUG - 2011-08-20 20:23:49 --> Input Class Initialized
DEBUG - 2011-08-20 20:23:49 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-20 20:23:49 --> Language Class Initialized
DEBUG - 2011-08-20 20:23:49 --> Loader Class Initialized
DEBUG - 2011-08-20 20:23:49 --> Controller Class Initialized
DEBUG - 2011-08-20 20:23:49 --> Model Class Initialized
DEBUG - 2011-08-20 20:23:49 --> Model Class Initialized
DEBUG - 2011-08-20 20:23:49 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-20 20:23:49 --> Database Driver Class Initialized
DEBUG - 2011-08-20 20:23:49 --> Final output sent to browser
DEBUG - 2011-08-20 20:23:49 --> Total execution time: 0.8182
DEBUG - 2011-08-20 20:23:51 --> Config Class Initialized
DEBUG - 2011-08-20 20:23:51 --> Hooks Class Initialized
DEBUG - 2011-08-20 20:23:51 --> Utf8 Class Initialized
DEBUG - 2011-08-20 20:23:51 --> UTF-8 Support Enabled
DEBUG - 2011-08-20 20:23:51 --> URI Class Initialized
DEBUG - 2011-08-20 20:23:51 --> Router Class Initialized
ERROR - 2011-08-20 20:23:51 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-20 20:33:44 --> Config Class Initialized
DEBUG - 2011-08-20 20:33:44 --> Hooks Class Initialized
DEBUG - 2011-08-20 20:33:44 --> Utf8 Class Initialized
DEBUG - 2011-08-20 20:33:44 --> UTF-8 Support Enabled
DEBUG - 2011-08-20 20:33:44 --> URI Class Initialized
DEBUG - 2011-08-20 20:33:44 --> Router Class Initialized
ERROR - 2011-08-20 20:33:44 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-08-20 20:46:53 --> Config Class Initialized
DEBUG - 2011-08-20 20:46:53 --> Hooks Class Initialized
DEBUG - 2011-08-20 20:46:53 --> Utf8 Class Initialized
DEBUG - 2011-08-20 20:46:53 --> UTF-8 Support Enabled
DEBUG - 2011-08-20 20:46:53 --> URI Class Initialized
DEBUG - 2011-08-20 20:46:53 --> Router Class Initialized
DEBUG - 2011-08-20 20:46:53 --> Output Class Initialized
DEBUG - 2011-08-20 20:46:53 --> Input Class Initialized
DEBUG - 2011-08-20 20:46:53 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-20 20:46:53 --> Language Class Initialized
DEBUG - 2011-08-20 20:46:53 --> Loader Class Initialized
DEBUG - 2011-08-20 20:46:53 --> Controller Class Initialized
ERROR - 2011-08-20 20:46:53 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-20 20:46:53 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-20 20:46:53 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-20 20:46:53 --> Model Class Initialized
DEBUG - 2011-08-20 20:46:53 --> Model Class Initialized
DEBUG - 2011-08-20 20:46:53 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-20 20:46:53 --> Database Driver Class Initialized
DEBUG - 2011-08-20 20:46:53 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-20 20:46:53 --> Helper loaded: url_helper
DEBUG - 2011-08-20 20:46:53 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-20 20:46:53 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-20 20:46:53 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-20 20:46:53 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-20 20:46:53 --> Final output sent to browser
DEBUG - 2011-08-20 20:46:53 --> Total execution time: 0.0529
DEBUG - 2011-08-20 20:46:55 --> Config Class Initialized
DEBUG - 2011-08-20 20:46:55 --> Hooks Class Initialized
DEBUG - 2011-08-20 20:46:55 --> Utf8 Class Initialized
DEBUG - 2011-08-20 20:46:55 --> UTF-8 Support Enabled
DEBUG - 2011-08-20 20:46:55 --> URI Class Initialized
DEBUG - 2011-08-20 20:46:55 --> Router Class Initialized
DEBUG - 2011-08-20 20:46:55 --> Output Class Initialized
DEBUG - 2011-08-20 20:46:55 --> Input Class Initialized
DEBUG - 2011-08-20 20:46:55 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-20 20:46:55 --> Language Class Initialized
DEBUG - 2011-08-20 20:46:55 --> Loader Class Initialized
DEBUG - 2011-08-20 20:46:55 --> Controller Class Initialized
DEBUG - 2011-08-20 20:46:55 --> Model Class Initialized
DEBUG - 2011-08-20 20:46:55 --> Model Class Initialized
DEBUG - 2011-08-20 20:46:55 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-20 20:46:55 --> Database Driver Class Initialized
DEBUG - 2011-08-20 20:46:55 --> Final output sent to browser
DEBUG - 2011-08-20 20:46:55 --> Total execution time: 0.5462
DEBUG - 2011-08-20 20:46:57 --> Config Class Initialized
DEBUG - 2011-08-20 20:46:57 --> Hooks Class Initialized
DEBUG - 2011-08-20 20:46:57 --> Utf8 Class Initialized
DEBUG - 2011-08-20 20:46:57 --> UTF-8 Support Enabled
DEBUG - 2011-08-20 20:46:57 --> URI Class Initialized
DEBUG - 2011-08-20 20:46:57 --> Router Class Initialized
ERROR - 2011-08-20 20:46:57 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-20 20:47:11 --> Config Class Initialized
DEBUG - 2011-08-20 20:47:11 --> Hooks Class Initialized
DEBUG - 2011-08-20 20:47:11 --> Utf8 Class Initialized
DEBUG - 2011-08-20 20:47:11 --> UTF-8 Support Enabled
DEBUG - 2011-08-20 20:47:12 --> URI Class Initialized
DEBUG - 2011-08-20 20:47:12 --> Router Class Initialized
DEBUG - 2011-08-20 20:47:12 --> Output Class Initialized
DEBUG - 2011-08-20 20:47:12 --> Input Class Initialized
DEBUG - 2011-08-20 20:47:12 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-20 20:47:12 --> Language Class Initialized
DEBUG - 2011-08-20 20:47:12 --> Loader Class Initialized
DEBUG - 2011-08-20 20:47:12 --> Controller Class Initialized
ERROR - 2011-08-20 20:47:12 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-20 20:47:12 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-20 20:47:12 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-20 20:47:12 --> Model Class Initialized
DEBUG - 2011-08-20 20:47:12 --> Model Class Initialized
DEBUG - 2011-08-20 20:47:12 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-20 20:47:12 --> Database Driver Class Initialized
DEBUG - 2011-08-20 20:47:12 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-20 20:47:12 --> Helper loaded: url_helper
DEBUG - 2011-08-20 20:47:12 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-20 20:47:12 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-20 20:47:12 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-20 20:47:12 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-20 20:47:12 --> Final output sent to browser
DEBUG - 2011-08-20 20:47:12 --> Total execution time: 0.0275
DEBUG - 2011-08-20 20:47:12 --> Config Class Initialized
DEBUG - 2011-08-20 20:47:12 --> Hooks Class Initialized
DEBUG - 2011-08-20 20:47:12 --> Utf8 Class Initialized
DEBUG - 2011-08-20 20:47:12 --> UTF-8 Support Enabled
DEBUG - 2011-08-20 20:47:12 --> URI Class Initialized
DEBUG - 2011-08-20 20:47:12 --> Router Class Initialized
DEBUG - 2011-08-20 20:47:12 --> Output Class Initialized
DEBUG - 2011-08-20 20:47:12 --> Input Class Initialized
DEBUG - 2011-08-20 20:47:12 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-20 20:47:12 --> Language Class Initialized
DEBUG - 2011-08-20 20:47:12 --> Loader Class Initialized
DEBUG - 2011-08-20 20:47:12 --> Controller Class Initialized
DEBUG - 2011-08-20 20:47:12 --> Model Class Initialized
DEBUG - 2011-08-20 20:47:12 --> Model Class Initialized
DEBUG - 2011-08-20 20:47:12 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-20 20:47:12 --> Database Driver Class Initialized
DEBUG - 2011-08-20 20:47:13 --> Final output sent to browser
DEBUG - 2011-08-20 20:47:13 --> Total execution time: 0.4457
DEBUG - 2011-08-20 20:47:14 --> Config Class Initialized
DEBUG - 2011-08-20 20:47:14 --> Hooks Class Initialized
DEBUG - 2011-08-20 20:47:14 --> Utf8 Class Initialized
DEBUG - 2011-08-20 20:47:14 --> UTF-8 Support Enabled
DEBUG - 2011-08-20 20:47:14 --> URI Class Initialized
DEBUG - 2011-08-20 20:47:14 --> Router Class Initialized
ERROR - 2011-08-20 20:47:14 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-20 20:47:22 --> Config Class Initialized
DEBUG - 2011-08-20 20:47:22 --> Hooks Class Initialized
DEBUG - 2011-08-20 20:47:22 --> Utf8 Class Initialized
DEBUG - 2011-08-20 20:47:22 --> UTF-8 Support Enabled
DEBUG - 2011-08-20 20:47:22 --> URI Class Initialized
DEBUG - 2011-08-20 20:47:22 --> Router Class Initialized
DEBUG - 2011-08-20 20:47:22 --> Output Class Initialized
DEBUG - 2011-08-20 20:47:22 --> Input Class Initialized
DEBUG - 2011-08-20 20:47:22 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-20 20:47:22 --> Language Class Initialized
DEBUG - 2011-08-20 20:47:22 --> Loader Class Initialized
DEBUG - 2011-08-20 20:47:22 --> Controller Class Initialized
ERROR - 2011-08-20 20:47:22 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-20 20:47:22 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-20 20:47:22 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-20 20:47:22 --> Model Class Initialized
DEBUG - 2011-08-20 20:47:22 --> Model Class Initialized
DEBUG - 2011-08-20 20:47:22 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-20 20:47:22 --> Database Driver Class Initialized
DEBUG - 2011-08-20 20:47:22 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-20 20:47:22 --> Helper loaded: url_helper
DEBUG - 2011-08-20 20:47:22 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-20 20:47:22 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-20 20:47:22 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-20 20:47:22 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-20 20:47:22 --> Final output sent to browser
DEBUG - 2011-08-20 20:47:22 --> Total execution time: 0.0272
DEBUG - 2011-08-20 20:47:22 --> Config Class Initialized
DEBUG - 2011-08-20 20:47:22 --> Hooks Class Initialized
DEBUG - 2011-08-20 20:47:22 --> Utf8 Class Initialized
DEBUG - 2011-08-20 20:47:22 --> UTF-8 Support Enabled
DEBUG - 2011-08-20 20:47:22 --> URI Class Initialized
DEBUG - 2011-08-20 20:47:22 --> Router Class Initialized
DEBUG - 2011-08-20 20:47:22 --> Output Class Initialized
DEBUG - 2011-08-20 20:47:22 --> Input Class Initialized
DEBUG - 2011-08-20 20:47:22 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-20 20:47:22 --> Language Class Initialized
DEBUG - 2011-08-20 20:47:22 --> Loader Class Initialized
DEBUG - 2011-08-20 20:47:22 --> Controller Class Initialized
DEBUG - 2011-08-20 20:47:22 --> Model Class Initialized
DEBUG - 2011-08-20 20:47:22 --> Model Class Initialized
DEBUG - 2011-08-20 20:47:22 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-20 20:47:22 --> Database Driver Class Initialized
DEBUG - 2011-08-20 20:47:23 --> Final output sent to browser
DEBUG - 2011-08-20 20:47:23 --> Total execution time: 0.4358
DEBUG - 2011-08-20 20:47:24 --> Config Class Initialized
DEBUG - 2011-08-20 20:47:24 --> Hooks Class Initialized
DEBUG - 2011-08-20 20:47:24 --> Utf8 Class Initialized
DEBUG - 2011-08-20 20:47:24 --> UTF-8 Support Enabled
DEBUG - 2011-08-20 20:47:24 --> URI Class Initialized
DEBUG - 2011-08-20 20:47:24 --> Router Class Initialized
ERROR - 2011-08-20 20:47:24 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-20 22:49:14 --> Config Class Initialized
DEBUG - 2011-08-20 22:49:14 --> Hooks Class Initialized
DEBUG - 2011-08-20 22:49:14 --> Utf8 Class Initialized
DEBUG - 2011-08-20 22:49:14 --> UTF-8 Support Enabled
DEBUG - 2011-08-20 22:49:14 --> URI Class Initialized
DEBUG - 2011-08-20 22:49:14 --> Router Class Initialized
DEBUG - 2011-08-20 22:49:14 --> No URI present. Default controller set.
DEBUG - 2011-08-20 22:49:14 --> Output Class Initialized
DEBUG - 2011-08-20 22:49:14 --> Input Class Initialized
DEBUG - 2011-08-20 22:49:14 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-20 22:49:14 --> Language Class Initialized
DEBUG - 2011-08-20 22:49:14 --> Loader Class Initialized
DEBUG - 2011-08-20 22:49:14 --> Controller Class Initialized
DEBUG - 2011-08-20 22:49:14 --> File loaded: application/views/splash/main.php
DEBUG - 2011-08-20 22:49:14 --> Helper loaded: url_helper
DEBUG - 2011-08-20 22:49:14 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-20 22:49:14 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-20 22:49:14 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-20 22:49:14 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-20 22:49:14 --> Final output sent to browser
DEBUG - 2011-08-20 22:49:14 --> Total execution time: 0.0708
DEBUG - 2011-08-20 23:07:59 --> Config Class Initialized
DEBUG - 2011-08-20 23:07:59 --> Hooks Class Initialized
DEBUG - 2011-08-20 23:07:59 --> Utf8 Class Initialized
DEBUG - 2011-08-20 23:07:59 --> UTF-8 Support Enabled
DEBUG - 2011-08-20 23:07:59 --> URI Class Initialized
DEBUG - 2011-08-20 23:07:59 --> Router Class Initialized
DEBUG - 2011-08-20 23:07:59 --> Output Class Initialized
DEBUG - 2011-08-20 23:07:59 --> Input Class Initialized
DEBUG - 2011-08-20 23:07:59 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-20 23:07:59 --> Language Class Initialized
DEBUG - 2011-08-20 23:07:59 --> Loader Class Initialized
DEBUG - 2011-08-20 23:07:59 --> Controller Class Initialized
ERROR - 2011-08-20 23:07:59 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-20 23:07:59 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-20 23:07:59 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-20 23:07:59 --> Model Class Initialized
DEBUG - 2011-08-20 23:07:59 --> Model Class Initialized
DEBUG - 2011-08-20 23:07:59 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-20 23:07:59 --> Database Driver Class Initialized
DEBUG - 2011-08-20 23:07:59 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-20 23:07:59 --> Helper loaded: url_helper
DEBUG - 2011-08-20 23:07:59 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-20 23:07:59 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-20 23:07:59 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-20 23:07:59 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-20 23:07:59 --> Final output sent to browser
DEBUG - 2011-08-20 23:07:59 --> Total execution time: 0.0390
DEBUG - 2011-08-20 23:08:03 --> Config Class Initialized
DEBUG - 2011-08-20 23:08:03 --> Hooks Class Initialized
DEBUG - 2011-08-20 23:08:03 --> Utf8 Class Initialized
DEBUG - 2011-08-20 23:08:03 --> UTF-8 Support Enabled
DEBUG - 2011-08-20 23:08:03 --> URI Class Initialized
DEBUG - 2011-08-20 23:08:03 --> Router Class Initialized
DEBUG - 2011-08-20 23:08:03 --> Output Class Initialized
DEBUG - 2011-08-20 23:08:03 --> Input Class Initialized
DEBUG - 2011-08-20 23:08:03 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-20 23:08:03 --> Language Class Initialized
DEBUG - 2011-08-20 23:08:03 --> Loader Class Initialized
DEBUG - 2011-08-20 23:08:03 --> Controller Class Initialized
DEBUG - 2011-08-20 23:08:03 --> Model Class Initialized
DEBUG - 2011-08-20 23:08:03 --> Model Class Initialized
DEBUG - 2011-08-20 23:08:03 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-20 23:08:03 --> Database Driver Class Initialized
DEBUG - 2011-08-20 23:08:04 --> Final output sent to browser
DEBUG - 2011-08-20 23:08:04 --> Total execution time: 0.6210
DEBUG - 2011-08-20 23:41:26 --> Config Class Initialized
DEBUG - 2011-08-20 23:41:26 --> Hooks Class Initialized
DEBUG - 2011-08-20 23:41:26 --> Utf8 Class Initialized
DEBUG - 2011-08-20 23:41:26 --> UTF-8 Support Enabled
DEBUG - 2011-08-20 23:41:26 --> URI Class Initialized
DEBUG - 2011-08-20 23:41:26 --> Router Class Initialized
DEBUG - 2011-08-20 23:41:26 --> No URI present. Default controller set.
DEBUG - 2011-08-20 23:41:26 --> Output Class Initialized
DEBUG - 2011-08-20 23:41:26 --> Input Class Initialized
DEBUG - 2011-08-20 23:41:26 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-20 23:41:26 --> Language Class Initialized
DEBUG - 2011-08-20 23:41:26 --> Loader Class Initialized
DEBUG - 2011-08-20 23:41:26 --> Controller Class Initialized
DEBUG - 2011-08-20 23:41:26 --> File loaded: application/views/splash/main.php
DEBUG - 2011-08-20 23:41:26 --> Helper loaded: url_helper
DEBUG - 2011-08-20 23:41:26 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-20 23:41:26 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-20 23:41:26 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-20 23:41:26 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-20 23:41:26 --> Final output sent to browser
DEBUG - 2011-08-20 23:41:26 --> Total execution time: 0.0279

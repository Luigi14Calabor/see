<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2011-06-12 02:09:30 --> Config Class Initialized
DEBUG - 2011-06-12 02:09:30 --> Hooks Class Initialized
DEBUG - 2011-06-12 02:09:30 --> Utf8 Class Initialized
DEBUG - 2011-06-12 02:09:30 --> UTF-8 Support Enabled
DEBUG - 2011-06-12 02:09:30 --> URI Class Initialized
DEBUG - 2011-06-12 02:09:30 --> Router Class Initialized
DEBUG - 2011-06-12 02:09:31 --> No URI present. Default controller set.
DEBUG - 2011-06-12 02:09:31 --> Output Class Initialized
DEBUG - 2011-06-12 02:09:31 --> Input Class Initialized
DEBUG - 2011-06-12 02:09:31 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-12 02:09:31 --> Language Class Initialized
DEBUG - 2011-06-12 02:09:31 --> Loader Class Initialized
DEBUG - 2011-06-12 02:09:31 --> Controller Class Initialized
DEBUG - 2011-06-12 02:09:31 --> File loaded: application/views/splash/main.php
DEBUG - 2011-06-12 02:09:31 --> Helper loaded: url_helper
DEBUG - 2011-06-12 02:09:31 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-12 02:09:31 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-12 02:09:31 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-12 02:09:31 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-12 02:09:31 --> Final output sent to browser
DEBUG - 2011-06-12 02:09:31 --> Total execution time: 0.3333
DEBUG - 2011-06-12 02:09:33 --> Config Class Initialized
DEBUG - 2011-06-12 02:09:33 --> Hooks Class Initialized
DEBUG - 2011-06-12 02:09:33 --> Utf8 Class Initialized
DEBUG - 2011-06-12 02:09:33 --> UTF-8 Support Enabled
DEBUG - 2011-06-12 02:09:33 --> URI Class Initialized
DEBUG - 2011-06-12 02:09:33 --> Router Class Initialized
ERROR - 2011-06-12 02:09:33 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-12 02:09:33 --> Config Class Initialized
DEBUG - 2011-06-12 02:09:33 --> Hooks Class Initialized
DEBUG - 2011-06-12 02:09:33 --> Utf8 Class Initialized
DEBUG - 2011-06-12 02:09:33 --> UTF-8 Support Enabled
DEBUG - 2011-06-12 02:09:33 --> URI Class Initialized
DEBUG - 2011-06-12 02:09:33 --> Router Class Initialized
ERROR - 2011-06-12 02:09:33 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-12 02:09:36 --> Config Class Initialized
DEBUG - 2011-06-12 02:09:36 --> Hooks Class Initialized
DEBUG - 2011-06-12 02:09:36 --> Utf8 Class Initialized
DEBUG - 2011-06-12 02:09:36 --> UTF-8 Support Enabled
DEBUG - 2011-06-12 02:09:36 --> URI Class Initialized
DEBUG - 2011-06-12 02:09:36 --> Router Class Initialized
DEBUG - 2011-06-12 02:09:36 --> Output Class Initialized
DEBUG - 2011-06-12 02:09:36 --> Input Class Initialized
DEBUG - 2011-06-12 02:09:36 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-12 02:09:36 --> Language Class Initialized
DEBUG - 2011-06-12 02:09:36 --> Loader Class Initialized
DEBUG - 2011-06-12 02:09:36 --> Controller Class Initialized
DEBUG - 2011-06-12 02:09:36 --> Model Class Initialized
DEBUG - 2011-06-12 02:09:36 --> Model Class Initialized
DEBUG - 2011-06-12 02:09:36 --> Model Class Initialized
DEBUG - 2011-06-12 02:09:36 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-12 02:09:36 --> Database Driver Class Initialized
DEBUG - 2011-06-12 02:09:38 --> Config Class Initialized
DEBUG - 2011-06-12 02:09:38 --> Hooks Class Initialized
DEBUG - 2011-06-12 02:09:38 --> Utf8 Class Initialized
DEBUG - 2011-06-12 02:09:38 --> UTF-8 Support Enabled
DEBUG - 2011-06-12 02:09:38 --> URI Class Initialized
DEBUG - 2011-06-12 02:09:38 --> Router Class Initialized
DEBUG - 2011-06-12 02:09:38 --> Output Class Initialized
DEBUG - 2011-06-12 02:09:38 --> Input Class Initialized
DEBUG - 2011-06-12 02:09:38 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-12 02:09:38 --> Language Class Initialized
DEBUG - 2011-06-12 02:09:38 --> Loader Class Initialized
DEBUG - 2011-06-12 02:09:38 --> Controller Class Initialized
ERROR - 2011-06-12 02:09:38 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-12 02:09:38 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-12 02:09:38 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-12 02:09:38 --> Model Class Initialized
DEBUG - 2011-06-12 02:09:38 --> Model Class Initialized
DEBUG - 2011-06-12 02:09:38 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-12 02:09:38 --> Database Driver Class Initialized
DEBUG - 2011-06-12 02:09:40 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-12 02:09:40 --> Helper loaded: url_helper
DEBUG - 2011-06-12 02:09:40 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-12 02:09:40 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-12 02:09:40 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-12 02:09:40 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-12 02:09:40 --> Final output sent to browser
DEBUG - 2011-06-12 02:09:40 --> Total execution time: 1.5201
DEBUG - 2011-06-12 02:09:40 --> Config Class Initialized
DEBUG - 2011-06-12 02:09:40 --> Hooks Class Initialized
DEBUG - 2011-06-12 02:09:40 --> Utf8 Class Initialized
DEBUG - 2011-06-12 02:09:40 --> UTF-8 Support Enabled
DEBUG - 2011-06-12 02:09:40 --> URI Class Initialized
DEBUG - 2011-06-12 02:09:40 --> Router Class Initialized
DEBUG - 2011-06-12 02:09:40 --> Output Class Initialized
DEBUG - 2011-06-12 02:09:40 --> Input Class Initialized
DEBUG - 2011-06-12 02:09:40 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-12 02:09:40 --> Language Class Initialized
DEBUG - 2011-06-12 02:09:40 --> Loader Class Initialized
DEBUG - 2011-06-12 02:09:40 --> Controller Class Initialized
DEBUG - 2011-06-12 02:09:40 --> Model Class Initialized
DEBUG - 2011-06-12 02:09:40 --> Model Class Initialized
DEBUG - 2011-06-12 02:09:40 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-12 02:09:40 --> Database Driver Class Initialized
DEBUG - 2011-06-12 02:09:42 --> Final output sent to browser
DEBUG - 2011-06-12 02:09:42 --> Total execution time: 1.6996
DEBUG - 2011-06-12 02:09:42 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-12 02:09:42 --> Helper loaded: url_helper
DEBUG - 2011-06-12 02:09:42 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-12 02:09:42 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-12 02:09:42 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-12 02:09:42 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-12 02:09:42 --> Final output sent to browser
DEBUG - 2011-06-12 02:09:42 --> Total execution time: 5.9057
DEBUG - 2011-06-12 02:10:30 --> Config Class Initialized
DEBUG - 2011-06-12 02:10:30 --> Hooks Class Initialized
DEBUG - 2011-06-12 02:10:30 --> Utf8 Class Initialized
DEBUG - 2011-06-12 02:10:30 --> UTF-8 Support Enabled
DEBUG - 2011-06-12 02:10:30 --> URI Class Initialized
DEBUG - 2011-06-12 02:10:30 --> Router Class Initialized
DEBUG - 2011-06-12 02:10:30 --> Output Class Initialized
DEBUG - 2011-06-12 02:10:30 --> Input Class Initialized
DEBUG - 2011-06-12 02:10:30 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-12 02:10:30 --> Language Class Initialized
DEBUG - 2011-06-12 02:10:30 --> Loader Class Initialized
DEBUG - 2011-06-12 02:10:30 --> Controller Class Initialized
ERROR - 2011-06-12 02:10:30 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-12 02:10:30 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-12 02:10:30 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-12 02:10:30 --> Model Class Initialized
DEBUG - 2011-06-12 02:10:30 --> Model Class Initialized
DEBUG - 2011-06-12 02:10:30 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-12 02:10:30 --> Database Driver Class Initialized
DEBUG - 2011-06-12 02:10:30 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-12 02:10:30 --> Helper loaded: url_helper
DEBUG - 2011-06-12 02:10:30 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-12 02:10:30 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-12 02:10:30 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-12 02:10:30 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-12 02:10:30 --> Final output sent to browser
DEBUG - 2011-06-12 02:10:30 --> Total execution time: 0.0299
DEBUG - 2011-06-12 02:10:31 --> Config Class Initialized
DEBUG - 2011-06-12 02:10:31 --> Hooks Class Initialized
DEBUG - 2011-06-12 02:10:31 --> Utf8 Class Initialized
DEBUG - 2011-06-12 02:10:31 --> UTF-8 Support Enabled
DEBUG - 2011-06-12 02:10:31 --> URI Class Initialized
DEBUG - 2011-06-12 02:10:31 --> Router Class Initialized
DEBUG - 2011-06-12 02:10:31 --> Output Class Initialized
DEBUG - 2011-06-12 02:10:31 --> Input Class Initialized
DEBUG - 2011-06-12 02:10:31 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-12 02:10:31 --> Language Class Initialized
DEBUG - 2011-06-12 02:10:31 --> Loader Class Initialized
DEBUG - 2011-06-12 02:10:31 --> Controller Class Initialized
DEBUG - 2011-06-12 02:10:31 --> Model Class Initialized
DEBUG - 2011-06-12 02:10:31 --> Model Class Initialized
DEBUG - 2011-06-12 02:10:31 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-12 02:10:31 --> Database Driver Class Initialized
DEBUG - 2011-06-12 02:10:32 --> Final output sent to browser
DEBUG - 2011-06-12 02:10:32 --> Total execution time: 0.7940
DEBUG - 2011-06-12 03:10:00 --> Config Class Initialized
DEBUG - 2011-06-12 03:10:00 --> Hooks Class Initialized
DEBUG - 2011-06-12 03:10:00 --> Utf8 Class Initialized
DEBUG - 2011-06-12 03:10:00 --> UTF-8 Support Enabled
DEBUG - 2011-06-12 03:10:00 --> URI Class Initialized
DEBUG - 2011-06-12 03:10:00 --> Router Class Initialized
DEBUG - 2011-06-12 03:10:00 --> Output Class Initialized
DEBUG - 2011-06-12 03:10:00 --> Input Class Initialized
DEBUG - 2011-06-12 03:10:00 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-12 03:10:00 --> Language Class Initialized
DEBUG - 2011-06-12 03:10:00 --> Loader Class Initialized
DEBUG - 2011-06-12 03:10:00 --> Controller Class Initialized
DEBUG - 2011-06-12 03:10:00 --> Model Class Initialized
DEBUG - 2011-06-12 03:10:00 --> Model Class Initialized
DEBUG - 2011-06-12 03:10:00 --> Model Class Initialized
DEBUG - 2011-06-12 03:10:00 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-12 03:10:00 --> Database Driver Class Initialized
DEBUG - 2011-06-12 03:10:01 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-12 03:10:01 --> Helper loaded: url_helper
DEBUG - 2011-06-12 03:10:01 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-12 03:10:01 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-12 03:10:01 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-12 03:10:01 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-12 03:10:01 --> Final output sent to browser
DEBUG - 2011-06-12 03:10:01 --> Total execution time: 1.6425
DEBUG - 2011-06-12 03:10:02 --> Config Class Initialized
DEBUG - 2011-06-12 03:10:02 --> Hooks Class Initialized
DEBUG - 2011-06-12 03:10:02 --> Utf8 Class Initialized
DEBUG - 2011-06-12 03:10:02 --> UTF-8 Support Enabled
DEBUG - 2011-06-12 03:10:02 --> URI Class Initialized
DEBUG - 2011-06-12 03:10:02 --> Router Class Initialized
DEBUG - 2011-06-12 03:10:02 --> Output Class Initialized
DEBUG - 2011-06-12 03:10:02 --> Input Class Initialized
DEBUG - 2011-06-12 03:10:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-12 03:10:02 --> Language Class Initialized
DEBUG - 2011-06-12 03:10:02 --> Loader Class Initialized
DEBUG - 2011-06-12 03:10:02 --> Controller Class Initialized
ERROR - 2011-06-12 03:10:02 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-12 03:10:02 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-12 03:10:02 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-12 03:10:02 --> Model Class Initialized
DEBUG - 2011-06-12 03:10:02 --> Model Class Initialized
DEBUG - 2011-06-12 03:10:02 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-12 03:10:02 --> Database Driver Class Initialized
DEBUG - 2011-06-12 03:10:02 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-12 03:10:02 --> Helper loaded: url_helper
DEBUG - 2011-06-12 03:10:02 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-12 03:10:02 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-12 03:10:02 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-12 03:10:02 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-12 03:10:02 --> Final output sent to browser
DEBUG - 2011-06-12 03:10:02 --> Total execution time: 0.2181
DEBUG - 2011-06-12 03:56:04 --> Config Class Initialized
DEBUG - 2011-06-12 03:56:04 --> Hooks Class Initialized
DEBUG - 2011-06-12 03:56:04 --> Utf8 Class Initialized
DEBUG - 2011-06-12 03:56:04 --> UTF-8 Support Enabled
DEBUG - 2011-06-12 03:56:05 --> URI Class Initialized
DEBUG - 2011-06-12 03:56:05 --> Router Class Initialized
DEBUG - 2011-06-12 03:56:05 --> Output Class Initialized
DEBUG - 2011-06-12 03:56:05 --> Input Class Initialized
DEBUG - 2011-06-12 03:56:05 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-12 03:56:05 --> Language Class Initialized
DEBUG - 2011-06-12 03:56:05 --> Loader Class Initialized
DEBUG - 2011-06-12 03:56:05 --> Controller Class Initialized
ERROR - 2011-06-12 03:56:05 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-12 03:56:05 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-12 03:56:05 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-12 03:56:05 --> Model Class Initialized
DEBUG - 2011-06-12 03:56:05 --> Model Class Initialized
DEBUG - 2011-06-12 03:56:05 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-12 03:56:05 --> Database Driver Class Initialized
DEBUG - 2011-06-12 03:56:05 --> Config Class Initialized
DEBUG - 2011-06-12 03:56:05 --> Hooks Class Initialized
DEBUG - 2011-06-12 03:56:05 --> Utf8 Class Initialized
DEBUG - 2011-06-12 03:56:05 --> UTF-8 Support Enabled
DEBUG - 2011-06-12 03:56:05 --> URI Class Initialized
DEBUG - 2011-06-12 03:56:05 --> Router Class Initialized
DEBUG - 2011-06-12 03:56:05 --> Output Class Initialized
DEBUG - 2011-06-12 03:56:05 --> Input Class Initialized
DEBUG - 2011-06-12 03:56:05 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-12 03:56:05 --> Language Class Initialized
DEBUG - 2011-06-12 03:56:05 --> Loader Class Initialized
DEBUG - 2011-06-12 03:56:05 --> Controller Class Initialized
ERROR - 2011-06-12 03:56:05 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-12 03:56:05 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-12 03:56:05 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-12 03:56:05 --> Model Class Initialized
DEBUG - 2011-06-12 03:56:05 --> Model Class Initialized
DEBUG - 2011-06-12 03:56:05 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-12 03:56:05 --> Database Driver Class Initialized
DEBUG - 2011-06-12 03:56:05 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-12 03:56:05 --> Helper loaded: url_helper
DEBUG - 2011-06-12 03:56:05 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-12 03:56:05 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-12 03:56:05 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-12 03:56:05 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-12 03:56:05 --> Final output sent to browser
DEBUG - 2011-06-12 03:56:05 --> Total execution time: 0.9777
DEBUG - 2011-06-12 03:56:06 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-12 03:56:06 --> Helper loaded: url_helper
DEBUG - 2011-06-12 03:56:06 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-12 03:56:06 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-12 03:56:06 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-12 03:56:06 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-12 03:56:06 --> Final output sent to browser
DEBUG - 2011-06-12 03:56:06 --> Total execution time: 1.2171
DEBUG - 2011-06-12 03:56:08 --> Config Class Initialized
DEBUG - 2011-06-12 03:56:08 --> Hooks Class Initialized
DEBUG - 2011-06-12 03:56:08 --> Utf8 Class Initialized
DEBUG - 2011-06-12 03:56:08 --> UTF-8 Support Enabled
DEBUG - 2011-06-12 03:56:08 --> URI Class Initialized
DEBUG - 2011-06-12 03:56:08 --> Router Class Initialized
DEBUG - 2011-06-12 03:56:08 --> Output Class Initialized
DEBUG - 2011-06-12 03:56:08 --> Input Class Initialized
DEBUG - 2011-06-12 03:56:08 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-12 03:56:08 --> Language Class Initialized
DEBUG - 2011-06-12 03:56:08 --> Loader Class Initialized
DEBUG - 2011-06-12 03:56:08 --> Controller Class Initialized
DEBUG - 2011-06-12 03:56:08 --> Model Class Initialized
DEBUG - 2011-06-12 03:56:08 --> Model Class Initialized
DEBUG - 2011-06-12 03:56:08 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-12 03:56:08 --> Database Driver Class Initialized
DEBUG - 2011-06-12 03:56:15 --> Config Class Initialized
DEBUG - 2011-06-12 03:56:15 --> Hooks Class Initialized
DEBUG - 2011-06-12 03:56:15 --> Utf8 Class Initialized
DEBUG - 2011-06-12 03:56:15 --> UTF-8 Support Enabled
DEBUG - 2011-06-12 03:56:15 --> URI Class Initialized
DEBUG - 2011-06-12 03:56:15 --> Router Class Initialized
ERROR - 2011-06-12 03:56:15 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-12 03:56:15 --> Config Class Initialized
DEBUG - 2011-06-12 03:56:15 --> Hooks Class Initialized
DEBUG - 2011-06-12 03:56:15 --> Utf8 Class Initialized
DEBUG - 2011-06-12 03:56:15 --> UTF-8 Support Enabled
DEBUG - 2011-06-12 03:56:15 --> URI Class Initialized
DEBUG - 2011-06-12 03:56:15 --> Router Class Initialized
ERROR - 2011-06-12 03:56:15 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-12 03:56:27 --> Final output sent to browser
DEBUG - 2011-06-12 03:56:27 --> Total execution time: 19.5652
DEBUG - 2011-06-12 05:00:34 --> Config Class Initialized
DEBUG - 2011-06-12 05:00:34 --> Hooks Class Initialized
DEBUG - 2011-06-12 05:00:34 --> Utf8 Class Initialized
DEBUG - 2011-06-12 05:00:34 --> UTF-8 Support Enabled
DEBUG - 2011-06-12 05:00:34 --> URI Class Initialized
DEBUG - 2011-06-12 05:00:34 --> Router Class Initialized
DEBUG - 2011-06-12 05:00:34 --> Output Class Initialized
DEBUG - 2011-06-12 05:00:34 --> Input Class Initialized
DEBUG - 2011-06-12 05:00:34 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-12 05:00:34 --> Language Class Initialized
DEBUG - 2011-06-12 05:00:34 --> Loader Class Initialized
DEBUG - 2011-06-12 05:00:34 --> Controller Class Initialized
DEBUG - 2011-06-12 05:00:34 --> Model Class Initialized
DEBUG - 2011-06-12 05:00:35 --> Model Class Initialized
DEBUG - 2011-06-12 05:00:35 --> Model Class Initialized
DEBUG - 2011-06-12 05:00:35 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-12 05:00:35 --> Database Driver Class Initialized
DEBUG - 2011-06-12 05:00:37 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-12 05:00:37 --> Helper loaded: url_helper
DEBUG - 2011-06-12 05:00:37 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-12 05:00:37 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-12 05:00:37 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-12 05:00:37 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-12 05:00:37 --> Final output sent to browser
DEBUG - 2011-06-12 05:00:37 --> Total execution time: 2.9826
DEBUG - 2011-06-12 06:08:34 --> Config Class Initialized
DEBUG - 2011-06-12 06:08:34 --> Hooks Class Initialized
DEBUG - 2011-06-12 06:08:34 --> Utf8 Class Initialized
DEBUG - 2011-06-12 06:08:34 --> UTF-8 Support Enabled
DEBUG - 2011-06-12 06:08:34 --> URI Class Initialized
DEBUG - 2011-06-12 06:08:34 --> Router Class Initialized
ERROR - 2011-06-12 06:08:34 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-06-12 06:08:35 --> Config Class Initialized
DEBUG - 2011-06-12 06:08:35 --> Hooks Class Initialized
DEBUG - 2011-06-12 06:08:35 --> Utf8 Class Initialized
DEBUG - 2011-06-12 06:08:35 --> UTF-8 Support Enabled
DEBUG - 2011-06-12 06:08:35 --> URI Class Initialized
DEBUG - 2011-06-12 06:08:35 --> Router Class Initialized
DEBUG - 2011-06-12 06:08:35 --> Output Class Initialized
DEBUG - 2011-06-12 06:08:35 --> Input Class Initialized
DEBUG - 2011-06-12 06:08:35 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-12 06:08:35 --> Language Class Initialized
DEBUG - 2011-06-12 06:08:35 --> Loader Class Initialized
DEBUG - 2011-06-12 06:08:35 --> Controller Class Initialized
ERROR - 2011-06-12 06:08:35 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-12 06:08:35 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-12 06:08:35 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-12 06:08:35 --> Model Class Initialized
DEBUG - 2011-06-12 06:08:35 --> Model Class Initialized
DEBUG - 2011-06-12 06:08:35 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-12 06:08:35 --> Database Driver Class Initialized
DEBUG - 2011-06-12 06:08:35 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-12 06:08:35 --> Helper loaded: url_helper
DEBUG - 2011-06-12 06:08:35 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-12 06:08:35 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-12 06:08:35 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-12 06:08:35 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-12 06:08:35 --> Final output sent to browser
DEBUG - 2011-06-12 06:08:35 --> Total execution time: 0.2232
DEBUG - 2011-06-12 06:08:38 --> Config Class Initialized
DEBUG - 2011-06-12 06:08:38 --> Hooks Class Initialized
DEBUG - 2011-06-12 06:08:38 --> Utf8 Class Initialized
DEBUG - 2011-06-12 06:08:38 --> UTF-8 Support Enabled
DEBUG - 2011-06-12 06:08:38 --> URI Class Initialized
DEBUG - 2011-06-12 06:08:38 --> Router Class Initialized
DEBUG - 2011-06-12 06:08:38 --> Output Class Initialized
DEBUG - 2011-06-12 06:08:38 --> Input Class Initialized
DEBUG - 2011-06-12 06:08:38 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-12 06:08:38 --> Language Class Initialized
DEBUG - 2011-06-12 06:08:38 --> Loader Class Initialized
DEBUG - 2011-06-12 06:08:38 --> Controller Class Initialized
DEBUG - 2011-06-12 06:08:38 --> Model Class Initialized
DEBUG - 2011-06-12 06:08:38 --> Model Class Initialized
DEBUG - 2011-06-12 06:08:38 --> Model Class Initialized
DEBUG - 2011-06-12 06:08:38 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-12 06:08:38 --> Database Driver Class Initialized
DEBUG - 2011-06-12 06:08:38 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-12 06:08:38 --> Helper loaded: url_helper
DEBUG - 2011-06-12 06:08:38 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-12 06:08:38 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-12 06:08:38 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-12 06:08:38 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-12 06:08:38 --> Final output sent to browser
DEBUG - 2011-06-12 06:08:38 --> Total execution time: 0.2866
DEBUG - 2011-06-12 06:17:44 --> Config Class Initialized
DEBUG - 2011-06-12 06:17:44 --> Hooks Class Initialized
DEBUG - 2011-06-12 06:17:44 --> Utf8 Class Initialized
DEBUG - 2011-06-12 06:17:44 --> UTF-8 Support Enabled
DEBUG - 2011-06-12 06:17:44 --> URI Class Initialized
DEBUG - 2011-06-12 06:17:44 --> Router Class Initialized
DEBUG - 2011-06-12 06:17:44 --> Output Class Initialized
DEBUG - 2011-06-12 06:17:44 --> Input Class Initialized
DEBUG - 2011-06-12 06:17:44 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-12 06:17:44 --> Language Class Initialized
DEBUG - 2011-06-12 06:17:44 --> Loader Class Initialized
DEBUG - 2011-06-12 06:17:44 --> Controller Class Initialized
DEBUG - 2011-06-12 06:17:44 --> Model Class Initialized
DEBUG - 2011-06-12 06:17:44 --> Model Class Initialized
DEBUG - 2011-06-12 06:17:44 --> Model Class Initialized
DEBUG - 2011-06-12 06:17:44 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-12 06:17:44 --> Database Driver Class Initialized
DEBUG - 2011-06-12 06:17:44 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-12 06:17:44 --> Helper loaded: url_helper
DEBUG - 2011-06-12 06:17:44 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-12 06:17:44 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-12 06:17:44 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-12 06:17:44 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-12 06:17:44 --> Final output sent to browser
DEBUG - 2011-06-12 06:17:44 --> Total execution time: 0.1316
DEBUG - 2011-06-12 06:28:08 --> Config Class Initialized
DEBUG - 2011-06-12 06:28:08 --> Hooks Class Initialized
DEBUG - 2011-06-12 06:28:08 --> Utf8 Class Initialized
DEBUG - 2011-06-12 06:28:08 --> UTF-8 Support Enabled
DEBUG - 2011-06-12 06:28:08 --> URI Class Initialized
DEBUG - 2011-06-12 06:28:08 --> Router Class Initialized
ERROR - 2011-06-12 06:28:08 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-06-12 07:01:35 --> Config Class Initialized
DEBUG - 2011-06-12 07:01:35 --> Hooks Class Initialized
DEBUG - 2011-06-12 07:01:35 --> Utf8 Class Initialized
DEBUG - 2011-06-12 07:01:35 --> UTF-8 Support Enabled
DEBUG - 2011-06-12 07:01:35 --> URI Class Initialized
DEBUG - 2011-06-12 07:01:35 --> Router Class Initialized
DEBUG - 2011-06-12 07:01:35 --> Output Class Initialized
DEBUG - 2011-06-12 07:01:35 --> Input Class Initialized
DEBUG - 2011-06-12 07:01:35 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-12 07:01:35 --> Language Class Initialized
DEBUG - 2011-06-12 07:01:35 --> Loader Class Initialized
DEBUG - 2011-06-12 07:01:35 --> Controller Class Initialized
DEBUG - 2011-06-12 07:01:35 --> Model Class Initialized
DEBUG - 2011-06-12 07:01:36 --> Model Class Initialized
DEBUG - 2011-06-12 07:01:36 --> Model Class Initialized
DEBUG - 2011-06-12 07:01:36 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-12 07:01:36 --> Database Driver Class Initialized
DEBUG - 2011-06-12 07:01:36 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-12 07:01:37 --> Helper loaded: url_helper
DEBUG - 2011-06-12 07:01:37 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-12 07:01:37 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-12 07:01:37 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-12 07:01:37 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-12 07:01:37 --> Final output sent to browser
DEBUG - 2011-06-12 07:01:37 --> Total execution time: 1.7516
DEBUG - 2011-06-12 07:01:43 --> Config Class Initialized
DEBUG - 2011-06-12 07:01:43 --> Hooks Class Initialized
DEBUG - 2011-06-12 07:01:43 --> Utf8 Class Initialized
DEBUG - 2011-06-12 07:01:43 --> UTF-8 Support Enabled
DEBUG - 2011-06-12 07:01:43 --> URI Class Initialized
DEBUG - 2011-06-12 07:01:43 --> Router Class Initialized
ERROR - 2011-06-12 07:01:43 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-12 07:01:44 --> Config Class Initialized
DEBUG - 2011-06-12 07:01:44 --> Hooks Class Initialized
DEBUG - 2011-06-12 07:01:44 --> Utf8 Class Initialized
DEBUG - 2011-06-12 07:01:44 --> UTF-8 Support Enabled
DEBUG - 2011-06-12 07:01:44 --> URI Class Initialized
DEBUG - 2011-06-12 07:01:44 --> Router Class Initialized
ERROR - 2011-06-12 07:01:44 --> 404 Page Not Found --> crossdomain.xml
DEBUG - 2011-06-12 07:01:46 --> Config Class Initialized
DEBUG - 2011-06-12 07:01:46 --> Hooks Class Initialized
DEBUG - 2011-06-12 07:01:46 --> Utf8 Class Initialized
DEBUG - 2011-06-12 07:01:46 --> UTF-8 Support Enabled
DEBUG - 2011-06-12 07:01:46 --> URI Class Initialized
DEBUG - 2011-06-12 07:01:46 --> Router Class Initialized
ERROR - 2011-06-12 07:01:46 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-12 07:23:17 --> Config Class Initialized
DEBUG - 2011-06-12 07:23:18 --> Hooks Class Initialized
DEBUG - 2011-06-12 07:23:18 --> Utf8 Class Initialized
DEBUG - 2011-06-12 07:23:18 --> UTF-8 Support Enabled
DEBUG - 2011-06-12 07:23:18 --> URI Class Initialized
DEBUG - 2011-06-12 07:23:18 --> Router Class Initialized
ERROR - 2011-06-12 07:23:18 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-12 07:29:19 --> Config Class Initialized
DEBUG - 2011-06-12 07:29:19 --> Hooks Class Initialized
DEBUG - 2011-06-12 07:29:19 --> Utf8 Class Initialized
DEBUG - 2011-06-12 07:29:19 --> UTF-8 Support Enabled
DEBUG - 2011-06-12 07:29:19 --> URI Class Initialized
DEBUG - 2011-06-12 07:29:19 --> Router Class Initialized
DEBUG - 2011-06-12 07:29:19 --> Output Class Initialized
DEBUG - 2011-06-12 07:29:19 --> Input Class Initialized
DEBUG - 2011-06-12 07:29:19 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-12 07:29:19 --> Language Class Initialized
DEBUG - 2011-06-12 07:29:19 --> Loader Class Initialized
DEBUG - 2011-06-12 07:29:19 --> Controller Class Initialized
ERROR - 2011-06-12 07:29:19 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-12 07:29:19 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-12 07:29:19 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-12 07:29:19 --> Model Class Initialized
DEBUG - 2011-06-12 07:29:19 --> Model Class Initialized
DEBUG - 2011-06-12 07:29:20 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-12 07:29:20 --> Database Driver Class Initialized
DEBUG - 2011-06-12 07:29:20 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-12 07:29:20 --> Helper loaded: url_helper
DEBUG - 2011-06-12 07:29:20 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-12 07:29:20 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-12 07:29:20 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-12 07:29:20 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-12 07:29:20 --> Final output sent to browser
DEBUG - 2011-06-12 07:29:20 --> Total execution time: 0.4048
DEBUG - 2011-06-12 07:29:20 --> Config Class Initialized
DEBUG - 2011-06-12 07:29:20 --> Hooks Class Initialized
DEBUG - 2011-06-12 07:29:20 --> Utf8 Class Initialized
DEBUG - 2011-06-12 07:29:20 --> UTF-8 Support Enabled
DEBUG - 2011-06-12 07:29:20 --> URI Class Initialized
DEBUG - 2011-06-12 07:29:20 --> Router Class Initialized
DEBUG - 2011-06-12 07:29:20 --> Output Class Initialized
DEBUG - 2011-06-12 07:29:20 --> Input Class Initialized
DEBUG - 2011-06-12 07:29:20 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-12 07:29:20 --> Language Class Initialized
DEBUG - 2011-06-12 07:29:20 --> Loader Class Initialized
DEBUG - 2011-06-12 07:29:20 --> Controller Class Initialized
DEBUG - 2011-06-12 07:29:20 --> Model Class Initialized
DEBUG - 2011-06-12 07:29:20 --> Model Class Initialized
DEBUG - 2011-06-12 07:29:20 --> Model Class Initialized
DEBUG - 2011-06-12 07:29:20 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-12 07:29:20 --> Database Driver Class Initialized
DEBUG - 2011-06-12 07:29:21 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-12 07:29:21 --> Helper loaded: url_helper
DEBUG - 2011-06-12 07:29:21 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-12 07:29:21 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-12 07:29:21 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-12 07:29:21 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-12 07:29:21 --> Final output sent to browser
DEBUG - 2011-06-12 07:29:21 --> Total execution time: 0.4912
DEBUG - 2011-06-12 07:29:21 --> Config Class Initialized
DEBUG - 2011-06-12 07:29:21 --> Hooks Class Initialized
DEBUG - 2011-06-12 07:29:21 --> Utf8 Class Initialized
DEBUG - 2011-06-12 07:29:21 --> UTF-8 Support Enabled
DEBUG - 2011-06-12 07:29:21 --> URI Class Initialized
DEBUG - 2011-06-12 07:29:21 --> Router Class Initialized
DEBUG - 2011-06-12 07:29:21 --> Output Class Initialized
DEBUG - 2011-06-12 07:29:21 --> Input Class Initialized
DEBUG - 2011-06-12 07:29:21 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-12 07:29:21 --> Language Class Initialized
DEBUG - 2011-06-12 07:29:21 --> Loader Class Initialized
DEBUG - 2011-06-12 07:29:21 --> Controller Class Initialized
DEBUG - 2011-06-12 07:29:21 --> Model Class Initialized
DEBUG - 2011-06-12 07:29:21 --> Model Class Initialized
DEBUG - 2011-06-12 07:29:21 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-12 07:29:21 --> Database Driver Class Initialized
DEBUG - 2011-06-12 07:29:22 --> Final output sent to browser
DEBUG - 2011-06-12 07:29:22 --> Total execution time: 0.7706
DEBUG - 2011-06-12 07:29:23 --> Config Class Initialized
DEBUG - 2011-06-12 07:29:23 --> Hooks Class Initialized
DEBUG - 2011-06-12 07:29:23 --> Utf8 Class Initialized
DEBUG - 2011-06-12 07:29:23 --> UTF-8 Support Enabled
DEBUG - 2011-06-12 07:29:23 --> URI Class Initialized
DEBUG - 2011-06-12 07:29:23 --> Router Class Initialized
ERROR - 2011-06-12 07:29:23 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-12 07:29:24 --> Config Class Initialized
DEBUG - 2011-06-12 07:29:24 --> Hooks Class Initialized
DEBUG - 2011-06-12 07:29:24 --> Utf8 Class Initialized
DEBUG - 2011-06-12 07:29:24 --> UTF-8 Support Enabled
DEBUG - 2011-06-12 07:29:24 --> URI Class Initialized
DEBUG - 2011-06-12 07:29:24 --> Router Class Initialized
ERROR - 2011-06-12 07:29:24 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-12 10:04:39 --> Config Class Initialized
DEBUG - 2011-06-12 10:04:39 --> Hooks Class Initialized
DEBUG - 2011-06-12 10:04:39 --> Utf8 Class Initialized
DEBUG - 2011-06-12 10:04:39 --> UTF-8 Support Enabled
DEBUG - 2011-06-12 10:04:39 --> URI Class Initialized
DEBUG - 2011-06-12 10:04:39 --> Router Class Initialized
DEBUG - 2011-06-12 10:04:39 --> Output Class Initialized
DEBUG - 2011-06-12 10:04:39 --> Input Class Initialized
DEBUG - 2011-06-12 10:04:39 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-12 10:04:39 --> Language Class Initialized
DEBUG - 2011-06-12 10:04:39 --> Loader Class Initialized
DEBUG - 2011-06-12 10:04:39 --> Controller Class Initialized
ERROR - 2011-06-12 10:04:39 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-12 10:04:39 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-12 10:04:39 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-12 10:04:39 --> Model Class Initialized
DEBUG - 2011-06-12 10:04:39 --> Model Class Initialized
DEBUG - 2011-06-12 10:04:39 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-12 10:04:39 --> Database Driver Class Initialized
DEBUG - 2011-06-12 10:04:39 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-12 10:04:39 --> Helper loaded: url_helper
DEBUG - 2011-06-12 10:04:39 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-12 10:04:39 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-12 10:04:39 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-12 10:04:39 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-12 10:04:39 --> Final output sent to browser
DEBUG - 2011-06-12 10:04:39 --> Total execution time: 0.3552
DEBUG - 2011-06-12 10:04:42 --> Config Class Initialized
DEBUG - 2011-06-12 10:04:42 --> Hooks Class Initialized
DEBUG - 2011-06-12 10:04:42 --> Utf8 Class Initialized
DEBUG - 2011-06-12 10:04:42 --> UTF-8 Support Enabled
DEBUG - 2011-06-12 10:04:42 --> URI Class Initialized
DEBUG - 2011-06-12 10:04:42 --> Router Class Initialized
DEBUG - 2011-06-12 10:04:42 --> Output Class Initialized
DEBUG - 2011-06-12 10:04:42 --> Input Class Initialized
DEBUG - 2011-06-12 10:04:42 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-12 10:04:42 --> Language Class Initialized
DEBUG - 2011-06-12 10:04:42 --> Loader Class Initialized
DEBUG - 2011-06-12 10:04:42 --> Controller Class Initialized
DEBUG - 2011-06-12 10:04:42 --> Model Class Initialized
DEBUG - 2011-06-12 10:04:42 --> Model Class Initialized
DEBUG - 2011-06-12 10:04:42 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-12 10:04:42 --> Database Driver Class Initialized
DEBUG - 2011-06-12 10:04:44 --> Final output sent to browser
DEBUG - 2011-06-12 10:04:44 --> Total execution time: 1.2250
DEBUG - 2011-06-12 10:04:45 --> Config Class Initialized
DEBUG - 2011-06-12 10:04:45 --> Hooks Class Initialized
DEBUG - 2011-06-12 10:04:45 --> Utf8 Class Initialized
DEBUG - 2011-06-12 10:04:45 --> UTF-8 Support Enabled
DEBUG - 2011-06-12 10:04:45 --> URI Class Initialized
DEBUG - 2011-06-12 10:04:45 --> Router Class Initialized
ERROR - 2011-06-12 10:04:45 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-12 10:04:45 --> Config Class Initialized
DEBUG - 2011-06-12 10:04:45 --> Hooks Class Initialized
DEBUG - 2011-06-12 10:04:45 --> Utf8 Class Initialized
DEBUG - 2011-06-12 10:04:45 --> UTF-8 Support Enabled
DEBUG - 2011-06-12 10:04:45 --> URI Class Initialized
DEBUG - 2011-06-12 10:04:45 --> Router Class Initialized
ERROR - 2011-06-12 10:04:45 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-12 10:04:51 --> Config Class Initialized
DEBUG - 2011-06-12 10:04:51 --> Hooks Class Initialized
DEBUG - 2011-06-12 10:04:51 --> Utf8 Class Initialized
DEBUG - 2011-06-12 10:04:51 --> UTF-8 Support Enabled
DEBUG - 2011-06-12 10:04:51 --> URI Class Initialized
DEBUG - 2011-06-12 10:04:51 --> Router Class Initialized
DEBUG - 2011-06-12 10:04:51 --> Output Class Initialized
DEBUG - 2011-06-12 10:04:51 --> Input Class Initialized
DEBUG - 2011-06-12 10:04:51 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-12 10:04:51 --> Language Class Initialized
DEBUG - 2011-06-12 10:04:51 --> Loader Class Initialized
DEBUG - 2011-06-12 10:04:51 --> Controller Class Initialized
ERROR - 2011-06-12 10:04:51 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-12 10:04:51 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-12 10:04:51 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-12 10:04:51 --> Model Class Initialized
DEBUG - 2011-06-12 10:04:51 --> Model Class Initialized
DEBUG - 2011-06-12 10:04:51 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-12 10:04:51 --> Database Driver Class Initialized
DEBUG - 2011-06-12 10:04:51 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-12 10:04:51 --> Helper loaded: url_helper
DEBUG - 2011-06-12 10:04:51 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-12 10:04:51 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-12 10:04:51 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-12 10:04:51 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-12 10:04:51 --> Final output sent to browser
DEBUG - 2011-06-12 10:04:51 --> Total execution time: 0.0292
DEBUG - 2011-06-12 10:04:52 --> Config Class Initialized
DEBUG - 2011-06-12 10:04:52 --> Hooks Class Initialized
DEBUG - 2011-06-12 10:04:52 --> Utf8 Class Initialized
DEBUG - 2011-06-12 10:04:52 --> UTF-8 Support Enabled
DEBUG - 2011-06-12 10:04:52 --> URI Class Initialized
DEBUG - 2011-06-12 10:04:52 --> Router Class Initialized
DEBUG - 2011-06-12 10:04:52 --> Output Class Initialized
DEBUG - 2011-06-12 10:04:52 --> Input Class Initialized
DEBUG - 2011-06-12 10:04:52 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-12 10:04:52 --> Language Class Initialized
DEBUG - 2011-06-12 10:04:52 --> Loader Class Initialized
DEBUG - 2011-06-12 10:04:52 --> Controller Class Initialized
DEBUG - 2011-06-12 10:04:52 --> Model Class Initialized
DEBUG - 2011-06-12 10:04:52 --> Model Class Initialized
DEBUG - 2011-06-12 10:04:52 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-12 10:04:52 --> Database Driver Class Initialized
DEBUG - 2011-06-12 10:04:52 --> Final output sent to browser
DEBUG - 2011-06-12 10:04:52 --> Total execution time: 0.6472
DEBUG - 2011-06-12 10:04:59 --> Config Class Initialized
DEBUG - 2011-06-12 10:04:59 --> Hooks Class Initialized
DEBUG - 2011-06-12 10:04:59 --> Utf8 Class Initialized
DEBUG - 2011-06-12 10:04:59 --> UTF-8 Support Enabled
DEBUG - 2011-06-12 10:04:59 --> URI Class Initialized
DEBUG - 2011-06-12 10:04:59 --> Router Class Initialized
ERROR - 2011-06-12 10:04:59 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-06-12 10:04:59 --> Config Class Initialized
DEBUG - 2011-06-12 10:04:59 --> Hooks Class Initialized
DEBUG - 2011-06-12 10:04:59 --> Utf8 Class Initialized
DEBUG - 2011-06-12 10:04:59 --> UTF-8 Support Enabled
DEBUG - 2011-06-12 10:04:59 --> URI Class Initialized
DEBUG - 2011-06-12 10:04:59 --> Router Class Initialized
DEBUG - 2011-06-12 10:04:59 --> Output Class Initialized
DEBUG - 2011-06-12 10:04:59 --> Input Class Initialized
DEBUG - 2011-06-12 10:04:59 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-12 10:04:59 --> Language Class Initialized
DEBUG - 2011-06-12 10:04:59 --> Loader Class Initialized
DEBUG - 2011-06-12 10:04:59 --> Controller Class Initialized
ERROR - 2011-06-12 10:04:59 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-12 10:04:59 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-12 10:04:59 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-12 10:04:59 --> Model Class Initialized
DEBUG - 2011-06-12 10:04:59 --> Model Class Initialized
DEBUG - 2011-06-12 10:04:59 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-12 10:04:59 --> Database Driver Class Initialized
DEBUG - 2011-06-12 10:04:59 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-12 10:04:59 --> Helper loaded: url_helper
DEBUG - 2011-06-12 10:04:59 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-12 10:04:59 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-12 10:04:59 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-12 10:04:59 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-12 10:05:00 --> Config Class Initialized
DEBUG - 2011-06-12 10:05:00 --> Hooks Class Initialized
DEBUG - 2011-06-12 10:05:00 --> Final output sent to browser
DEBUG - 2011-06-12 10:05:00 --> Total execution time: 0.4778
DEBUG - 2011-06-12 10:05:00 --> Utf8 Class Initialized
DEBUG - 2011-06-12 10:05:00 --> UTF-8 Support Enabled
DEBUG - 2011-06-12 10:05:00 --> URI Class Initialized
DEBUG - 2011-06-12 10:05:00 --> Router Class Initialized
DEBUG - 2011-06-12 10:05:00 --> Output Class Initialized
DEBUG - 2011-06-12 10:05:00 --> Input Class Initialized
DEBUG - 2011-06-12 10:05:00 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-12 10:05:00 --> Language Class Initialized
DEBUG - 2011-06-12 10:05:00 --> Loader Class Initialized
DEBUG - 2011-06-12 10:05:00 --> Controller Class Initialized
ERROR - 2011-06-12 10:05:00 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-12 10:05:00 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-12 10:05:00 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-12 10:05:00 --> Model Class Initialized
DEBUG - 2011-06-12 10:05:00 --> Model Class Initialized
DEBUG - 2011-06-12 10:05:00 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-12 10:05:00 --> Database Driver Class Initialized
DEBUG - 2011-06-12 10:05:00 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-12 10:05:00 --> Helper loaded: url_helper
DEBUG - 2011-06-12 10:05:00 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-12 10:05:00 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-12 10:05:00 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-12 10:05:00 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-12 10:05:00 --> Final output sent to browser
DEBUG - 2011-06-12 10:05:00 --> Total execution time: 0.2252
DEBUG - 2011-06-12 10:05:01 --> Config Class Initialized
DEBUG - 2011-06-12 10:05:01 --> Hooks Class Initialized
DEBUG - 2011-06-12 10:05:01 --> Utf8 Class Initialized
DEBUG - 2011-06-12 10:05:01 --> UTF-8 Support Enabled
DEBUG - 2011-06-12 10:05:01 --> URI Class Initialized
DEBUG - 2011-06-12 10:05:01 --> Router Class Initialized
DEBUG - 2011-06-12 10:05:01 --> Output Class Initialized
DEBUG - 2011-06-12 10:05:01 --> Input Class Initialized
DEBUG - 2011-06-12 10:05:01 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-12 10:05:01 --> Language Class Initialized
DEBUG - 2011-06-12 10:05:01 --> Loader Class Initialized
DEBUG - 2011-06-12 10:05:01 --> Controller Class Initialized
DEBUG - 2011-06-12 10:05:01 --> Model Class Initialized
DEBUG - 2011-06-12 10:05:01 --> Model Class Initialized
DEBUG - 2011-06-12 10:05:01 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-12 10:05:01 --> Database Driver Class Initialized
DEBUG - 2011-06-12 10:05:01 --> Config Class Initialized
DEBUG - 2011-06-12 10:05:01 --> Hooks Class Initialized
DEBUG - 2011-06-12 10:05:01 --> Utf8 Class Initialized
DEBUG - 2011-06-12 10:05:01 --> UTF-8 Support Enabled
DEBUG - 2011-06-12 10:05:01 --> URI Class Initialized
DEBUG - 2011-06-12 10:05:01 --> Router Class Initialized
DEBUG - 2011-06-12 10:05:01 --> Output Class Initialized
DEBUG - 2011-06-12 10:05:01 --> Input Class Initialized
DEBUG - 2011-06-12 10:05:01 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-12 10:05:01 --> Language Class Initialized
DEBUG - 2011-06-12 10:05:01 --> Loader Class Initialized
DEBUG - 2011-06-12 10:05:01 --> Controller Class Initialized
ERROR - 2011-06-12 10:05:01 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-12 10:05:01 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-12 10:05:01 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-12 10:05:01 --> Model Class Initialized
DEBUG - 2011-06-12 10:05:01 --> Model Class Initialized
DEBUG - 2011-06-12 10:05:01 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-12 10:05:01 --> Database Driver Class Initialized
DEBUG - 2011-06-12 10:05:01 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-12 10:05:01 --> Helper loaded: url_helper
DEBUG - 2011-06-12 10:05:01 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-12 10:05:01 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-12 10:05:01 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-12 10:05:01 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-12 10:05:01 --> Final output sent to browser
DEBUG - 2011-06-12 10:05:01 --> Total execution time: 0.0430
DEBUG - 2011-06-12 10:05:02 --> Final output sent to browser
DEBUG - 2011-06-12 10:05:02 --> Total execution time: 0.9242
DEBUG - 2011-06-12 10:05:12 --> Config Class Initialized
DEBUG - 2011-06-12 10:05:12 --> Hooks Class Initialized
DEBUG - 2011-06-12 10:05:12 --> Utf8 Class Initialized
DEBUG - 2011-06-12 10:05:12 --> UTF-8 Support Enabled
DEBUG - 2011-06-12 10:05:12 --> URI Class Initialized
DEBUG - 2011-06-12 10:05:12 --> Router Class Initialized
DEBUG - 2011-06-12 10:05:12 --> Output Class Initialized
DEBUG - 2011-06-12 10:05:12 --> Input Class Initialized
DEBUG - 2011-06-12 10:05:12 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-12 10:05:12 --> Language Class Initialized
DEBUG - 2011-06-12 10:05:12 --> Loader Class Initialized
DEBUG - 2011-06-12 10:05:12 --> Controller Class Initialized
ERROR - 2011-06-12 10:05:12 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-12 10:05:12 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-12 10:05:12 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-12 10:05:12 --> Model Class Initialized
DEBUG - 2011-06-12 10:05:12 --> Model Class Initialized
DEBUG - 2011-06-12 10:05:12 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-12 10:05:12 --> Database Driver Class Initialized
DEBUG - 2011-06-12 10:05:12 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-12 10:05:12 --> Helper loaded: url_helper
DEBUG - 2011-06-12 10:05:12 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-12 10:05:12 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-12 10:05:12 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-12 10:05:12 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-12 10:05:12 --> Final output sent to browser
DEBUG - 2011-06-12 10:05:12 --> Total execution time: 0.0317
DEBUG - 2011-06-12 10:05:21 --> Config Class Initialized
DEBUG - 2011-06-12 10:05:21 --> Hooks Class Initialized
DEBUG - 2011-06-12 10:05:21 --> Utf8 Class Initialized
DEBUG - 2011-06-12 10:05:21 --> UTF-8 Support Enabled
DEBUG - 2011-06-12 10:05:21 --> URI Class Initialized
DEBUG - 2011-06-12 10:05:21 --> Router Class Initialized
DEBUG - 2011-06-12 10:05:21 --> Output Class Initialized
DEBUG - 2011-06-12 10:05:21 --> Input Class Initialized
DEBUG - 2011-06-12 10:05:21 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-12 10:05:21 --> Language Class Initialized
DEBUG - 2011-06-12 10:05:21 --> Loader Class Initialized
DEBUG - 2011-06-12 10:05:21 --> Controller Class Initialized
ERROR - 2011-06-12 10:05:21 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-12 10:05:21 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-12 10:05:21 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-12 10:05:21 --> Model Class Initialized
DEBUG - 2011-06-12 10:05:21 --> Model Class Initialized
DEBUG - 2011-06-12 10:05:21 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-12 10:05:21 --> Database Driver Class Initialized
DEBUG - 2011-06-12 10:05:21 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-12 10:05:21 --> Helper loaded: url_helper
DEBUG - 2011-06-12 10:05:21 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-12 10:05:21 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-12 10:05:21 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-12 10:05:21 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-12 10:05:21 --> Final output sent to browser
DEBUG - 2011-06-12 10:05:21 --> Total execution time: 0.0499
DEBUG - 2011-06-12 10:05:22 --> Config Class Initialized
DEBUG - 2011-06-12 10:05:22 --> Hooks Class Initialized
DEBUG - 2011-06-12 10:05:22 --> Utf8 Class Initialized
DEBUG - 2011-06-12 10:05:22 --> UTF-8 Support Enabled
DEBUG - 2011-06-12 10:05:22 --> URI Class Initialized
DEBUG - 2011-06-12 10:05:22 --> Router Class Initialized
DEBUG - 2011-06-12 10:05:22 --> Output Class Initialized
DEBUG - 2011-06-12 10:05:22 --> Input Class Initialized
DEBUG - 2011-06-12 10:05:22 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-12 10:05:22 --> Language Class Initialized
DEBUG - 2011-06-12 10:05:22 --> Loader Class Initialized
DEBUG - 2011-06-12 10:05:22 --> Controller Class Initialized
DEBUG - 2011-06-12 10:05:22 --> Model Class Initialized
DEBUG - 2011-06-12 10:05:22 --> Model Class Initialized
DEBUG - 2011-06-12 10:05:22 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-12 10:05:22 --> Database Driver Class Initialized
DEBUG - 2011-06-12 10:05:22 --> Config Class Initialized
DEBUG - 2011-06-12 10:05:22 --> Hooks Class Initialized
DEBUG - 2011-06-12 10:05:22 --> Utf8 Class Initialized
DEBUG - 2011-06-12 10:05:22 --> UTF-8 Support Enabled
DEBUG - 2011-06-12 10:05:22 --> URI Class Initialized
DEBUG - 2011-06-12 10:05:22 --> Router Class Initialized
DEBUG - 2011-06-12 10:05:22 --> Output Class Initialized
DEBUG - 2011-06-12 10:05:22 --> Input Class Initialized
DEBUG - 2011-06-12 10:05:22 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-12 10:05:22 --> Language Class Initialized
DEBUG - 2011-06-12 10:05:22 --> Loader Class Initialized
DEBUG - 2011-06-12 10:05:22 --> Controller Class Initialized
ERROR - 2011-06-12 10:05:22 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-12 10:05:22 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-12 10:05:22 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-12 10:05:22 --> Model Class Initialized
DEBUG - 2011-06-12 10:05:22 --> Model Class Initialized
DEBUG - 2011-06-12 10:05:22 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-12 10:05:22 --> Database Driver Class Initialized
DEBUG - 2011-06-12 10:05:22 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-12 10:05:22 --> Helper loaded: url_helper
DEBUG - 2011-06-12 10:05:22 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-12 10:05:22 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-12 10:05:22 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-12 10:05:22 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-12 10:05:22 --> Final output sent to browser
DEBUG - 2011-06-12 10:05:22 --> Total execution time: 0.0320
DEBUG - 2011-06-12 10:05:23 --> Final output sent to browser
DEBUG - 2011-06-12 10:05:23 --> Total execution time: 0.6465
DEBUG - 2011-06-12 10:05:31 --> Config Class Initialized
DEBUG - 2011-06-12 10:05:31 --> Hooks Class Initialized
DEBUG - 2011-06-12 10:05:31 --> Utf8 Class Initialized
DEBUG - 2011-06-12 10:05:31 --> UTF-8 Support Enabled
DEBUG - 2011-06-12 10:05:31 --> URI Class Initialized
DEBUG - 2011-06-12 10:05:31 --> Router Class Initialized
DEBUG - 2011-06-12 10:05:31 --> Output Class Initialized
DEBUG - 2011-06-12 10:05:31 --> Input Class Initialized
DEBUG - 2011-06-12 10:05:31 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-12 10:05:31 --> Language Class Initialized
DEBUG - 2011-06-12 10:05:31 --> Loader Class Initialized
DEBUG - 2011-06-12 10:05:31 --> Controller Class Initialized
ERROR - 2011-06-12 10:05:31 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-12 10:05:31 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-12 10:05:31 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-12 10:05:31 --> Model Class Initialized
DEBUG - 2011-06-12 10:05:31 --> Model Class Initialized
DEBUG - 2011-06-12 10:05:31 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-12 10:05:31 --> Database Driver Class Initialized
DEBUG - 2011-06-12 10:05:31 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-12 10:05:31 --> Helper loaded: url_helper
DEBUG - 2011-06-12 10:05:31 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-12 10:05:31 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-12 10:05:31 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-12 10:05:31 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-12 10:05:31 --> Final output sent to browser
DEBUG - 2011-06-12 10:05:31 --> Total execution time: 0.0287
DEBUG - 2011-06-12 10:05:32 --> Config Class Initialized
DEBUG - 2011-06-12 10:05:32 --> Hooks Class Initialized
DEBUG - 2011-06-12 10:05:32 --> Utf8 Class Initialized
DEBUG - 2011-06-12 10:05:32 --> UTF-8 Support Enabled
DEBUG - 2011-06-12 10:05:32 --> URI Class Initialized
DEBUG - 2011-06-12 10:05:32 --> Router Class Initialized
DEBUG - 2011-06-12 10:05:32 --> Output Class Initialized
DEBUG - 2011-06-12 10:05:32 --> Input Class Initialized
DEBUG - 2011-06-12 10:05:32 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-12 10:05:32 --> Language Class Initialized
DEBUG - 2011-06-12 10:05:32 --> Loader Class Initialized
DEBUG - 2011-06-12 10:05:32 --> Controller Class Initialized
ERROR - 2011-06-12 10:05:32 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-12 10:05:32 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-12 10:05:32 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-12 10:05:32 --> Model Class Initialized
DEBUG - 2011-06-12 10:05:32 --> Model Class Initialized
DEBUG - 2011-06-12 10:05:32 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-12 10:05:32 --> Database Driver Class Initialized
DEBUG - 2011-06-12 10:05:32 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-12 10:05:32 --> Helper loaded: url_helper
DEBUG - 2011-06-12 10:05:32 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-12 10:05:32 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-12 10:05:32 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-12 10:05:32 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-12 10:05:32 --> Final output sent to browser
DEBUG - 2011-06-12 10:05:32 --> Total execution time: 0.0413
DEBUG - 2011-06-12 10:05:32 --> Config Class Initialized
DEBUG - 2011-06-12 10:05:32 --> Hooks Class Initialized
DEBUG - 2011-06-12 10:05:32 --> Utf8 Class Initialized
DEBUG - 2011-06-12 10:05:32 --> UTF-8 Support Enabled
DEBUG - 2011-06-12 10:05:32 --> URI Class Initialized
DEBUG - 2011-06-12 10:05:32 --> Router Class Initialized
DEBUG - 2011-06-12 10:05:32 --> Output Class Initialized
DEBUG - 2011-06-12 10:05:32 --> Input Class Initialized
DEBUG - 2011-06-12 10:05:32 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-12 10:05:32 --> Language Class Initialized
DEBUG - 2011-06-12 10:05:32 --> Loader Class Initialized
DEBUG - 2011-06-12 10:05:32 --> Controller Class Initialized
DEBUG - 2011-06-12 10:05:32 --> Model Class Initialized
DEBUG - 2011-06-12 10:05:32 --> Model Class Initialized
DEBUG - 2011-06-12 10:05:32 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-12 10:05:32 --> Database Driver Class Initialized
DEBUG - 2011-06-12 10:05:33 --> Final output sent to browser
DEBUG - 2011-06-12 10:05:33 --> Total execution time: 0.6260
DEBUG - 2011-06-12 10:05:42 --> Config Class Initialized
DEBUG - 2011-06-12 10:05:42 --> Hooks Class Initialized
DEBUG - 2011-06-12 10:05:42 --> Utf8 Class Initialized
DEBUG - 2011-06-12 10:05:42 --> UTF-8 Support Enabled
DEBUG - 2011-06-12 10:05:42 --> URI Class Initialized
DEBUG - 2011-06-12 10:05:42 --> Router Class Initialized
DEBUG - 2011-06-12 10:05:42 --> Output Class Initialized
DEBUG - 2011-06-12 10:05:42 --> Input Class Initialized
DEBUG - 2011-06-12 10:05:42 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-12 10:05:42 --> Language Class Initialized
DEBUG - 2011-06-12 10:05:42 --> Loader Class Initialized
DEBUG - 2011-06-12 10:05:42 --> Controller Class Initialized
ERROR - 2011-06-12 10:05:42 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-12 10:05:42 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-12 10:05:42 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-12 10:05:42 --> Model Class Initialized
DEBUG - 2011-06-12 10:05:42 --> Model Class Initialized
DEBUG - 2011-06-12 10:05:42 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-12 10:05:42 --> Database Driver Class Initialized
DEBUG - 2011-06-12 10:05:42 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-12 10:05:42 --> Helper loaded: url_helper
DEBUG - 2011-06-12 10:05:42 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-12 10:05:42 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-12 10:05:42 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-12 10:05:42 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-12 10:05:42 --> Final output sent to browser
DEBUG - 2011-06-12 10:05:42 --> Total execution time: 0.0298
DEBUG - 2011-06-12 10:05:43 --> Config Class Initialized
DEBUG - 2011-06-12 10:05:43 --> Hooks Class Initialized
DEBUG - 2011-06-12 10:05:43 --> Utf8 Class Initialized
DEBUG - 2011-06-12 10:05:43 --> UTF-8 Support Enabled
DEBUG - 2011-06-12 10:05:43 --> URI Class Initialized
DEBUG - 2011-06-12 10:05:43 --> Router Class Initialized
DEBUG - 2011-06-12 10:05:43 --> Output Class Initialized
DEBUG - 2011-06-12 10:05:43 --> Input Class Initialized
DEBUG - 2011-06-12 10:05:43 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-12 10:05:43 --> Language Class Initialized
DEBUG - 2011-06-12 10:05:43 --> Loader Class Initialized
DEBUG - 2011-06-12 10:05:43 --> Controller Class Initialized
DEBUG - 2011-06-12 10:05:43 --> Model Class Initialized
DEBUG - 2011-06-12 10:05:43 --> Model Class Initialized
DEBUG - 2011-06-12 10:05:43 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-12 10:05:43 --> Database Driver Class Initialized
DEBUG - 2011-06-12 10:05:44 --> Final output sent to browser
DEBUG - 2011-06-12 10:05:44 --> Total execution time: 0.6173
DEBUG - 2011-06-12 10:05:46 --> Config Class Initialized
DEBUG - 2011-06-12 10:05:46 --> Hooks Class Initialized
DEBUG - 2011-06-12 10:05:46 --> Utf8 Class Initialized
DEBUG - 2011-06-12 10:05:46 --> UTF-8 Support Enabled
DEBUG - 2011-06-12 10:05:46 --> URI Class Initialized
DEBUG - 2011-06-12 10:05:46 --> Router Class Initialized
DEBUG - 2011-06-12 10:05:46 --> Output Class Initialized
DEBUG - 2011-06-12 10:05:46 --> Input Class Initialized
DEBUG - 2011-06-12 10:05:46 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-12 10:05:46 --> Language Class Initialized
DEBUG - 2011-06-12 10:05:46 --> Loader Class Initialized
DEBUG - 2011-06-12 10:05:46 --> Controller Class Initialized
ERROR - 2011-06-12 10:05:46 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-12 10:05:46 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-12 10:05:46 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-12 10:05:46 --> Model Class Initialized
DEBUG - 2011-06-12 10:05:46 --> Model Class Initialized
DEBUG - 2011-06-12 10:05:46 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-12 10:05:46 --> Database Driver Class Initialized
DEBUG - 2011-06-12 10:05:46 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-12 10:05:46 --> Helper loaded: url_helper
DEBUG - 2011-06-12 10:05:46 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-12 10:05:46 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-12 10:05:46 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-12 10:05:46 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-12 10:05:46 --> Final output sent to browser
DEBUG - 2011-06-12 10:05:46 --> Total execution time: 0.0270
DEBUG - 2011-06-12 10:05:55 --> Config Class Initialized
DEBUG - 2011-06-12 10:05:55 --> Hooks Class Initialized
DEBUG - 2011-06-12 10:05:55 --> Utf8 Class Initialized
DEBUG - 2011-06-12 10:05:55 --> UTF-8 Support Enabled
DEBUG - 2011-06-12 10:05:55 --> URI Class Initialized
DEBUG - 2011-06-12 10:05:55 --> Router Class Initialized
DEBUG - 2011-06-12 10:05:55 --> Output Class Initialized
DEBUG - 2011-06-12 10:05:55 --> Input Class Initialized
DEBUG - 2011-06-12 10:05:55 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-12 10:05:55 --> Language Class Initialized
DEBUG - 2011-06-12 10:05:55 --> Loader Class Initialized
DEBUG - 2011-06-12 10:05:55 --> Controller Class Initialized
ERROR - 2011-06-12 10:05:55 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-12 10:05:55 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-12 10:05:55 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-12 10:05:55 --> Model Class Initialized
DEBUG - 2011-06-12 10:05:55 --> Model Class Initialized
DEBUG - 2011-06-12 10:05:55 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-12 10:05:55 --> Database Driver Class Initialized
DEBUG - 2011-06-12 10:05:55 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-12 10:05:55 --> Helper loaded: url_helper
DEBUG - 2011-06-12 10:05:55 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-12 10:05:55 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-12 10:05:55 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-12 10:05:55 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-12 10:05:55 --> Final output sent to browser
DEBUG - 2011-06-12 10:05:55 --> Total execution time: 0.0274
DEBUG - 2011-06-12 10:05:56 --> Config Class Initialized
DEBUG - 2011-06-12 10:05:56 --> Hooks Class Initialized
DEBUG - 2011-06-12 10:05:56 --> Utf8 Class Initialized
DEBUG - 2011-06-12 10:05:56 --> UTF-8 Support Enabled
DEBUG - 2011-06-12 10:05:56 --> URI Class Initialized
DEBUG - 2011-06-12 10:05:56 --> Router Class Initialized
DEBUG - 2011-06-12 10:05:56 --> Output Class Initialized
DEBUG - 2011-06-12 10:05:56 --> Input Class Initialized
DEBUG - 2011-06-12 10:05:56 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-12 10:05:56 --> Language Class Initialized
DEBUG - 2011-06-12 10:05:56 --> Loader Class Initialized
DEBUG - 2011-06-12 10:05:56 --> Controller Class Initialized
DEBUG - 2011-06-12 10:05:56 --> Model Class Initialized
DEBUG - 2011-06-12 10:05:56 --> Model Class Initialized
DEBUG - 2011-06-12 10:05:56 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-12 10:05:56 --> Database Driver Class Initialized
DEBUG - 2011-06-12 10:05:56 --> Config Class Initialized
DEBUG - 2011-06-12 10:05:56 --> Hooks Class Initialized
DEBUG - 2011-06-12 10:05:56 --> Utf8 Class Initialized
DEBUG - 2011-06-12 10:05:56 --> UTF-8 Support Enabled
DEBUG - 2011-06-12 10:05:56 --> URI Class Initialized
DEBUG - 2011-06-12 10:05:56 --> Router Class Initialized
DEBUG - 2011-06-12 10:05:56 --> Output Class Initialized
DEBUG - 2011-06-12 10:05:56 --> Input Class Initialized
DEBUG - 2011-06-12 10:05:56 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-12 10:05:56 --> Language Class Initialized
DEBUG - 2011-06-12 10:05:56 --> Loader Class Initialized
DEBUG - 2011-06-12 10:05:56 --> Controller Class Initialized
ERROR - 2011-06-12 10:05:56 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-12 10:05:56 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-12 10:05:56 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-12 10:05:56 --> Model Class Initialized
DEBUG - 2011-06-12 10:05:56 --> Model Class Initialized
DEBUG - 2011-06-12 10:05:56 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-12 10:05:56 --> Database Driver Class Initialized
DEBUG - 2011-06-12 10:05:56 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-12 10:05:56 --> Helper loaded: url_helper
DEBUG - 2011-06-12 10:05:56 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-12 10:05:56 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-12 10:05:56 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-12 10:05:56 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-12 10:05:56 --> Final output sent to browser
DEBUG - 2011-06-12 10:05:56 --> Total execution time: 0.0261
DEBUG - 2011-06-12 10:05:56 --> Final output sent to browser
DEBUG - 2011-06-12 10:05:56 --> Total execution time: 0.5655
DEBUG - 2011-06-12 10:06:02 --> Config Class Initialized
DEBUG - 2011-06-12 10:06:02 --> Hooks Class Initialized
DEBUG - 2011-06-12 10:06:02 --> Utf8 Class Initialized
DEBUG - 2011-06-12 10:06:02 --> UTF-8 Support Enabled
DEBUG - 2011-06-12 10:06:02 --> URI Class Initialized
DEBUG - 2011-06-12 10:06:02 --> Router Class Initialized
DEBUG - 2011-06-12 10:06:02 --> Output Class Initialized
DEBUG - 2011-06-12 10:06:02 --> Input Class Initialized
DEBUG - 2011-06-12 10:06:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-12 10:06:02 --> Language Class Initialized
DEBUG - 2011-06-12 10:06:02 --> Loader Class Initialized
DEBUG - 2011-06-12 10:06:02 --> Controller Class Initialized
ERROR - 2011-06-12 10:06:02 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-12 10:06:02 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-12 10:06:02 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-12 10:06:02 --> Model Class Initialized
DEBUG - 2011-06-12 10:06:02 --> Model Class Initialized
DEBUG - 2011-06-12 10:06:02 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-12 10:06:02 --> Database Driver Class Initialized
DEBUG - 2011-06-12 10:06:02 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-12 10:06:02 --> Helper loaded: url_helper
DEBUG - 2011-06-12 10:06:02 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-12 10:06:02 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-12 10:06:02 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-12 10:06:02 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-12 10:06:02 --> Final output sent to browser
DEBUG - 2011-06-12 10:06:02 --> Total execution time: 0.0299
DEBUG - 2011-06-12 10:06:02 --> Config Class Initialized
DEBUG - 2011-06-12 10:06:02 --> Hooks Class Initialized
DEBUG - 2011-06-12 10:06:02 --> Utf8 Class Initialized
DEBUG - 2011-06-12 10:06:02 --> UTF-8 Support Enabled
DEBUG - 2011-06-12 10:06:02 --> URI Class Initialized
DEBUG - 2011-06-12 10:06:02 --> Router Class Initialized
DEBUG - 2011-06-12 10:06:02 --> Output Class Initialized
DEBUG - 2011-06-12 10:06:02 --> Input Class Initialized
DEBUG - 2011-06-12 10:06:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-12 10:06:02 --> Language Class Initialized
DEBUG - 2011-06-12 10:06:02 --> Loader Class Initialized
DEBUG - 2011-06-12 10:06:02 --> Controller Class Initialized
DEBUG - 2011-06-12 10:06:02 --> Model Class Initialized
DEBUG - 2011-06-12 10:06:02 --> Model Class Initialized
DEBUG - 2011-06-12 10:06:02 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-12 10:06:02 --> Database Driver Class Initialized
DEBUG - 2011-06-12 10:06:03 --> Final output sent to browser
DEBUG - 2011-06-12 10:06:03 --> Total execution time: 0.5485
DEBUG - 2011-06-12 10:06:03 --> Config Class Initialized
DEBUG - 2011-06-12 10:06:03 --> Hooks Class Initialized
DEBUG - 2011-06-12 10:06:03 --> Utf8 Class Initialized
DEBUG - 2011-06-12 10:06:03 --> UTF-8 Support Enabled
DEBUG - 2011-06-12 10:06:03 --> URI Class Initialized
DEBUG - 2011-06-12 10:06:03 --> Router Class Initialized
DEBUG - 2011-06-12 10:06:03 --> Output Class Initialized
DEBUG - 2011-06-12 10:06:03 --> Input Class Initialized
DEBUG - 2011-06-12 10:06:03 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-12 10:06:03 --> Language Class Initialized
DEBUG - 2011-06-12 10:06:03 --> Loader Class Initialized
DEBUG - 2011-06-12 10:06:03 --> Controller Class Initialized
ERROR - 2011-06-12 10:06:03 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-12 10:06:03 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-12 10:06:03 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-12 10:06:03 --> Model Class Initialized
DEBUG - 2011-06-12 10:06:03 --> Model Class Initialized
DEBUG - 2011-06-12 10:06:03 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-12 10:06:03 --> Database Driver Class Initialized
DEBUG - 2011-06-12 10:06:03 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-12 10:06:03 --> Helper loaded: url_helper
DEBUG - 2011-06-12 10:06:03 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-12 10:06:03 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-12 10:06:03 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-12 10:06:03 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-12 10:06:03 --> Final output sent to browser
DEBUG - 2011-06-12 10:06:03 --> Total execution time: 0.0298
DEBUG - 2011-06-12 10:06:07 --> Config Class Initialized
DEBUG - 2011-06-12 10:06:07 --> Hooks Class Initialized
DEBUG - 2011-06-12 10:06:07 --> Utf8 Class Initialized
DEBUG - 2011-06-12 10:06:07 --> UTF-8 Support Enabled
DEBUG - 2011-06-12 10:06:07 --> URI Class Initialized
DEBUG - 2011-06-12 10:06:07 --> Router Class Initialized
DEBUG - 2011-06-12 10:06:07 --> Output Class Initialized
DEBUG - 2011-06-12 10:06:07 --> Input Class Initialized
DEBUG - 2011-06-12 10:06:07 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-12 10:06:07 --> Language Class Initialized
DEBUG - 2011-06-12 10:06:07 --> Loader Class Initialized
DEBUG - 2011-06-12 10:06:07 --> Controller Class Initialized
ERROR - 2011-06-12 10:06:07 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-12 10:06:07 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-12 10:06:07 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-12 10:06:07 --> Model Class Initialized
DEBUG - 2011-06-12 10:06:07 --> Model Class Initialized
DEBUG - 2011-06-12 10:06:07 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-12 10:06:07 --> Database Driver Class Initialized
DEBUG - 2011-06-12 10:06:07 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-12 10:06:07 --> Helper loaded: url_helper
DEBUG - 2011-06-12 10:06:07 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-12 10:06:07 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-12 10:06:07 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-12 10:06:07 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-12 10:06:07 --> Final output sent to browser
DEBUG - 2011-06-12 10:06:07 --> Total execution time: 0.0318
DEBUG - 2011-06-12 10:06:08 --> Config Class Initialized
DEBUG - 2011-06-12 10:06:08 --> Hooks Class Initialized
DEBUG - 2011-06-12 10:06:08 --> Utf8 Class Initialized
DEBUG - 2011-06-12 10:06:08 --> UTF-8 Support Enabled
DEBUG - 2011-06-12 10:06:08 --> URI Class Initialized
DEBUG - 2011-06-12 10:06:08 --> Router Class Initialized
DEBUG - 2011-06-12 10:06:08 --> Output Class Initialized
DEBUG - 2011-06-12 10:06:08 --> Input Class Initialized
DEBUG - 2011-06-12 10:06:08 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-12 10:06:08 --> Language Class Initialized
DEBUG - 2011-06-12 10:06:08 --> Loader Class Initialized
DEBUG - 2011-06-12 10:06:08 --> Controller Class Initialized
DEBUG - 2011-06-12 10:06:08 --> Model Class Initialized
DEBUG - 2011-06-12 10:06:08 --> Model Class Initialized
DEBUG - 2011-06-12 10:06:08 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-12 10:06:08 --> Database Driver Class Initialized
DEBUG - 2011-06-12 10:06:08 --> Config Class Initialized
DEBUG - 2011-06-12 10:06:08 --> Hooks Class Initialized
DEBUG - 2011-06-12 10:06:08 --> Utf8 Class Initialized
DEBUG - 2011-06-12 10:06:08 --> UTF-8 Support Enabled
DEBUG - 2011-06-12 10:06:08 --> URI Class Initialized
DEBUG - 2011-06-12 10:06:08 --> Router Class Initialized
DEBUG - 2011-06-12 10:06:08 --> Output Class Initialized
DEBUG - 2011-06-12 10:06:08 --> Input Class Initialized
DEBUG - 2011-06-12 10:06:08 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-12 10:06:08 --> Language Class Initialized
DEBUG - 2011-06-12 10:06:08 --> Loader Class Initialized
DEBUG - 2011-06-12 10:06:08 --> Controller Class Initialized
ERROR - 2011-06-12 10:06:08 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-12 10:06:08 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-12 10:06:08 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-12 10:06:08 --> Model Class Initialized
DEBUG - 2011-06-12 10:06:08 --> Model Class Initialized
DEBUG - 2011-06-12 10:06:08 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-12 10:06:08 --> Database Driver Class Initialized
DEBUG - 2011-06-12 10:06:08 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-12 10:06:08 --> Helper loaded: url_helper
DEBUG - 2011-06-12 10:06:08 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-12 10:06:08 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-12 10:06:08 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-12 10:06:08 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-12 10:06:08 --> Final output sent to browser
DEBUG - 2011-06-12 10:06:08 --> Total execution time: 0.0396
DEBUG - 2011-06-12 10:06:08 --> Final output sent to browser
DEBUG - 2011-06-12 10:06:08 --> Total execution time: 0.7103
DEBUG - 2011-06-12 10:06:27 --> Config Class Initialized
DEBUG - 2011-06-12 10:06:27 --> Hooks Class Initialized
DEBUG - 2011-06-12 10:06:27 --> Utf8 Class Initialized
DEBUG - 2011-06-12 10:06:27 --> UTF-8 Support Enabled
DEBUG - 2011-06-12 10:06:27 --> URI Class Initialized
DEBUG - 2011-06-12 10:06:27 --> Router Class Initialized
DEBUG - 2011-06-12 10:06:27 --> Output Class Initialized
DEBUG - 2011-06-12 10:06:27 --> Input Class Initialized
DEBUG - 2011-06-12 10:06:27 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-12 10:06:27 --> Language Class Initialized
DEBUG - 2011-06-12 10:06:27 --> Loader Class Initialized
DEBUG - 2011-06-12 10:06:27 --> Controller Class Initialized
ERROR - 2011-06-12 10:06:27 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-12 10:06:27 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-12 10:06:27 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-12 10:06:27 --> Model Class Initialized
DEBUG - 2011-06-12 10:06:27 --> Model Class Initialized
DEBUG - 2011-06-12 10:06:27 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-12 10:06:27 --> Database Driver Class Initialized
DEBUG - 2011-06-12 10:06:27 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-12 10:06:27 --> Helper loaded: url_helper
DEBUG - 2011-06-12 10:06:27 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-12 10:06:27 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-12 10:06:27 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-12 10:06:27 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-12 10:06:27 --> Final output sent to browser
DEBUG - 2011-06-12 10:06:27 --> Total execution time: 0.0276
DEBUG - 2011-06-12 10:06:27 --> Config Class Initialized
DEBUG - 2011-06-12 10:06:27 --> Hooks Class Initialized
DEBUG - 2011-06-12 10:06:27 --> Utf8 Class Initialized
DEBUG - 2011-06-12 10:06:27 --> UTF-8 Support Enabled
DEBUG - 2011-06-12 10:06:27 --> URI Class Initialized
DEBUG - 2011-06-12 10:06:27 --> Router Class Initialized
DEBUG - 2011-06-12 10:06:27 --> Output Class Initialized
DEBUG - 2011-06-12 10:06:27 --> Input Class Initialized
DEBUG - 2011-06-12 10:06:27 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-12 10:06:27 --> Language Class Initialized
DEBUG - 2011-06-12 10:06:27 --> Loader Class Initialized
DEBUG - 2011-06-12 10:06:27 --> Controller Class Initialized
DEBUG - 2011-06-12 10:06:27 --> Model Class Initialized
DEBUG - 2011-06-12 10:06:27 --> Model Class Initialized
DEBUG - 2011-06-12 10:06:27 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-12 10:06:27 --> Database Driver Class Initialized
DEBUG - 2011-06-12 10:06:28 --> Final output sent to browser
DEBUG - 2011-06-12 10:06:28 --> Total execution time: 0.5672
DEBUG - 2011-06-12 10:06:28 --> Config Class Initialized
DEBUG - 2011-06-12 10:06:28 --> Hooks Class Initialized
DEBUG - 2011-06-12 10:06:28 --> Utf8 Class Initialized
DEBUG - 2011-06-12 10:06:28 --> UTF-8 Support Enabled
DEBUG - 2011-06-12 10:06:28 --> URI Class Initialized
DEBUG - 2011-06-12 10:06:28 --> Router Class Initialized
DEBUG - 2011-06-12 10:06:28 --> Output Class Initialized
DEBUG - 2011-06-12 10:06:28 --> Input Class Initialized
DEBUG - 2011-06-12 10:06:28 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-12 10:06:28 --> Language Class Initialized
DEBUG - 2011-06-12 10:06:28 --> Loader Class Initialized
DEBUG - 2011-06-12 10:06:28 --> Controller Class Initialized
ERROR - 2011-06-12 10:06:28 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-12 10:06:28 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-12 10:06:28 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-12 10:06:28 --> Model Class Initialized
DEBUG - 2011-06-12 10:06:28 --> Model Class Initialized
DEBUG - 2011-06-12 10:06:28 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-12 10:06:28 --> Database Driver Class Initialized
DEBUG - 2011-06-12 10:06:28 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-12 10:06:28 --> Helper loaded: url_helper
DEBUG - 2011-06-12 10:06:28 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-12 10:06:28 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-12 10:06:28 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-12 10:06:28 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-12 10:06:28 --> Final output sent to browser
DEBUG - 2011-06-12 10:06:28 --> Total execution time: 0.0281
DEBUG - 2011-06-12 10:06:39 --> Config Class Initialized
DEBUG - 2011-06-12 10:06:39 --> Hooks Class Initialized
DEBUG - 2011-06-12 10:06:39 --> Utf8 Class Initialized
DEBUG - 2011-06-12 10:06:39 --> UTF-8 Support Enabled
DEBUG - 2011-06-12 10:06:39 --> URI Class Initialized
DEBUG - 2011-06-12 10:06:39 --> Router Class Initialized
DEBUG - 2011-06-12 10:06:39 --> Output Class Initialized
DEBUG - 2011-06-12 10:06:39 --> Input Class Initialized
DEBUG - 2011-06-12 10:06:39 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-12 10:06:39 --> Language Class Initialized
DEBUG - 2011-06-12 10:06:39 --> Loader Class Initialized
DEBUG - 2011-06-12 10:06:39 --> Controller Class Initialized
ERROR - 2011-06-12 10:06:39 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-12 10:06:39 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-12 10:06:39 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-12 10:06:39 --> Model Class Initialized
DEBUG - 2011-06-12 10:06:39 --> Model Class Initialized
DEBUG - 2011-06-12 10:06:39 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-12 10:06:39 --> Database Driver Class Initialized
DEBUG - 2011-06-12 10:06:39 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-12 10:06:39 --> Helper loaded: url_helper
DEBUG - 2011-06-12 10:06:39 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-12 10:06:39 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-12 10:06:39 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-12 10:06:39 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-12 10:06:39 --> Final output sent to browser
DEBUG - 2011-06-12 10:06:39 --> Total execution time: 0.0298
DEBUG - 2011-06-12 10:06:40 --> Config Class Initialized
DEBUG - 2011-06-12 10:06:40 --> Hooks Class Initialized
DEBUG - 2011-06-12 10:06:40 --> Utf8 Class Initialized
DEBUG - 2011-06-12 10:06:40 --> UTF-8 Support Enabled
DEBUG - 2011-06-12 10:06:40 --> URI Class Initialized
DEBUG - 2011-06-12 10:06:40 --> Router Class Initialized
DEBUG - 2011-06-12 10:06:40 --> Output Class Initialized
DEBUG - 2011-06-12 10:06:40 --> Input Class Initialized
DEBUG - 2011-06-12 10:06:40 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-12 10:06:40 --> Language Class Initialized
DEBUG - 2011-06-12 10:06:40 --> Loader Class Initialized
DEBUG - 2011-06-12 10:06:40 --> Controller Class Initialized
DEBUG - 2011-06-12 10:06:40 --> Model Class Initialized
DEBUG - 2011-06-12 10:06:40 --> Model Class Initialized
DEBUG - 2011-06-12 10:06:40 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-12 10:06:40 --> Database Driver Class Initialized
DEBUG - 2011-06-12 10:06:40 --> Config Class Initialized
DEBUG - 2011-06-12 10:06:40 --> Hooks Class Initialized
DEBUG - 2011-06-12 10:06:40 --> Utf8 Class Initialized
DEBUG - 2011-06-12 10:06:40 --> UTF-8 Support Enabled
DEBUG - 2011-06-12 10:06:40 --> URI Class Initialized
DEBUG - 2011-06-12 10:06:40 --> Router Class Initialized
DEBUG - 2011-06-12 10:06:40 --> Output Class Initialized
DEBUG - 2011-06-12 10:06:40 --> Input Class Initialized
DEBUG - 2011-06-12 10:06:40 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-12 10:06:40 --> Language Class Initialized
DEBUG - 2011-06-12 10:06:40 --> Loader Class Initialized
DEBUG - 2011-06-12 10:06:40 --> Controller Class Initialized
ERROR - 2011-06-12 10:06:40 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-12 10:06:40 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-12 10:06:40 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-12 10:06:40 --> Model Class Initialized
DEBUG - 2011-06-12 10:06:40 --> Model Class Initialized
DEBUG - 2011-06-12 10:06:40 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-12 10:06:40 --> Database Driver Class Initialized
DEBUG - 2011-06-12 10:06:40 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-12 10:06:40 --> Helper loaded: url_helper
DEBUG - 2011-06-12 10:06:40 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-12 10:06:40 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-12 10:06:40 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-12 10:06:40 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-12 10:06:40 --> Final output sent to browser
DEBUG - 2011-06-12 10:06:40 --> Total execution time: 0.0301
DEBUG - 2011-06-12 10:06:40 --> Final output sent to browser
DEBUG - 2011-06-12 10:06:40 --> Total execution time: 0.6069
DEBUG - 2011-06-12 10:06:42 --> Config Class Initialized
DEBUG - 2011-06-12 10:06:42 --> Hooks Class Initialized
DEBUG - 2011-06-12 10:06:42 --> Utf8 Class Initialized
DEBUG - 2011-06-12 10:06:42 --> UTF-8 Support Enabled
DEBUG - 2011-06-12 10:06:42 --> URI Class Initialized
DEBUG - 2011-06-12 10:06:42 --> Router Class Initialized
DEBUG - 2011-06-12 10:06:42 --> Output Class Initialized
DEBUG - 2011-06-12 10:06:42 --> Input Class Initialized
DEBUG - 2011-06-12 10:06:42 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-12 10:06:42 --> Language Class Initialized
DEBUG - 2011-06-12 10:06:42 --> Loader Class Initialized
DEBUG - 2011-06-12 10:06:42 --> Controller Class Initialized
ERROR - 2011-06-12 10:06:42 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-12 10:06:42 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-12 10:06:42 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-12 10:06:42 --> Model Class Initialized
DEBUG - 2011-06-12 10:06:42 --> Model Class Initialized
DEBUG - 2011-06-12 10:06:42 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-12 10:06:42 --> Database Driver Class Initialized
DEBUG - 2011-06-12 10:06:42 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-12 10:06:42 --> Helper loaded: url_helper
DEBUG - 2011-06-12 10:06:42 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-12 10:06:42 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-12 10:06:42 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-12 10:06:42 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-12 10:06:42 --> Final output sent to browser
DEBUG - 2011-06-12 10:06:42 --> Total execution time: 0.0289
DEBUG - 2011-06-12 10:06:44 --> Config Class Initialized
DEBUG - 2011-06-12 10:06:44 --> Hooks Class Initialized
DEBUG - 2011-06-12 10:06:44 --> Utf8 Class Initialized
DEBUG - 2011-06-12 10:06:44 --> UTF-8 Support Enabled
DEBUG - 2011-06-12 10:06:44 --> URI Class Initialized
DEBUG - 2011-06-12 10:06:44 --> Router Class Initialized
DEBUG - 2011-06-12 10:06:44 --> Output Class Initialized
DEBUG - 2011-06-12 10:06:44 --> Input Class Initialized
DEBUG - 2011-06-12 10:06:44 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-12 10:06:44 --> Language Class Initialized
DEBUG - 2011-06-12 10:06:44 --> Loader Class Initialized
DEBUG - 2011-06-12 10:06:44 --> Controller Class Initialized
ERROR - 2011-06-12 10:06:44 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-12 10:06:44 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-12 10:06:44 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-12 10:06:44 --> Model Class Initialized
DEBUG - 2011-06-12 10:06:44 --> Model Class Initialized
DEBUG - 2011-06-12 10:06:44 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-12 10:06:44 --> Database Driver Class Initialized
DEBUG - 2011-06-12 10:06:45 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-12 10:06:45 --> Helper loaded: url_helper
DEBUG - 2011-06-12 10:06:45 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-12 10:06:45 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-12 10:06:45 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-12 10:06:45 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-12 10:06:45 --> Final output sent to browser
DEBUG - 2011-06-12 10:06:45 --> Total execution time: 0.0425
DEBUG - 2011-06-12 10:06:45 --> Config Class Initialized
DEBUG - 2011-06-12 10:06:45 --> Hooks Class Initialized
DEBUG - 2011-06-12 10:06:45 --> Utf8 Class Initialized
DEBUG - 2011-06-12 10:06:45 --> UTF-8 Support Enabled
DEBUG - 2011-06-12 10:06:45 --> URI Class Initialized
DEBUG - 2011-06-12 10:06:45 --> Router Class Initialized
DEBUG - 2011-06-12 10:06:45 --> Output Class Initialized
DEBUG - 2011-06-12 10:06:45 --> Input Class Initialized
DEBUG - 2011-06-12 10:06:45 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-12 10:06:45 --> Language Class Initialized
DEBUG - 2011-06-12 10:06:45 --> Loader Class Initialized
DEBUG - 2011-06-12 10:06:45 --> Controller Class Initialized
ERROR - 2011-06-12 10:06:45 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-12 10:06:45 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-12 10:06:45 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-12 10:06:45 --> Model Class Initialized
DEBUG - 2011-06-12 10:06:45 --> Model Class Initialized
DEBUG - 2011-06-12 10:06:45 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-12 10:06:45 --> Database Driver Class Initialized
DEBUG - 2011-06-12 10:06:45 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-12 10:06:45 --> Helper loaded: url_helper
DEBUG - 2011-06-12 10:06:45 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-12 10:06:45 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-12 10:06:45 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-12 10:06:45 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-12 10:06:45 --> Final output sent to browser
DEBUG - 2011-06-12 10:06:45 --> Total execution time: 0.0278
DEBUG - 2011-06-12 10:06:46 --> Config Class Initialized
DEBUG - 2011-06-12 10:06:46 --> Hooks Class Initialized
DEBUG - 2011-06-12 10:06:46 --> Utf8 Class Initialized
DEBUG - 2011-06-12 10:06:46 --> UTF-8 Support Enabled
DEBUG - 2011-06-12 10:06:46 --> URI Class Initialized
DEBUG - 2011-06-12 10:06:46 --> Router Class Initialized
DEBUG - 2011-06-12 10:06:46 --> Output Class Initialized
DEBUG - 2011-06-12 10:06:46 --> Input Class Initialized
DEBUG - 2011-06-12 10:06:46 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-12 10:06:46 --> Language Class Initialized
DEBUG - 2011-06-12 10:06:46 --> Loader Class Initialized
DEBUG - 2011-06-12 10:06:46 --> Controller Class Initialized
DEBUG - 2011-06-12 10:06:46 --> Model Class Initialized
DEBUG - 2011-06-12 10:06:46 --> Model Class Initialized
DEBUG - 2011-06-12 10:06:46 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-12 10:06:46 --> Database Driver Class Initialized
DEBUG - 2011-06-12 10:06:47 --> Final output sent to browser
DEBUG - 2011-06-12 10:06:47 --> Total execution time: 1.2065
DEBUG - 2011-06-12 10:06:56 --> Config Class Initialized
DEBUG - 2011-06-12 10:06:56 --> Hooks Class Initialized
DEBUG - 2011-06-12 10:06:56 --> Utf8 Class Initialized
DEBUG - 2011-06-12 10:06:56 --> UTF-8 Support Enabled
DEBUG - 2011-06-12 10:06:56 --> URI Class Initialized
DEBUG - 2011-06-12 10:06:56 --> Router Class Initialized
DEBUG - 2011-06-12 10:06:56 --> Output Class Initialized
DEBUG - 2011-06-12 10:06:56 --> Input Class Initialized
DEBUG - 2011-06-12 10:06:56 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-12 10:06:56 --> Language Class Initialized
DEBUG - 2011-06-12 10:06:56 --> Loader Class Initialized
DEBUG - 2011-06-12 10:06:56 --> Controller Class Initialized
ERROR - 2011-06-12 10:06:56 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-12 10:06:56 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-12 10:06:56 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-12 10:06:56 --> Model Class Initialized
DEBUG - 2011-06-12 10:06:56 --> Model Class Initialized
DEBUG - 2011-06-12 10:06:56 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-12 10:06:56 --> Database Driver Class Initialized
DEBUG - 2011-06-12 10:06:56 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-12 10:06:56 --> Helper loaded: url_helper
DEBUG - 2011-06-12 10:06:56 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-12 10:06:56 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-12 10:06:56 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-12 10:06:56 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-12 10:06:56 --> Final output sent to browser
DEBUG - 2011-06-12 10:06:56 --> Total execution time: 0.0304
DEBUG - 2011-06-12 10:06:57 --> Config Class Initialized
DEBUG - 2011-06-12 10:06:57 --> Hooks Class Initialized
DEBUG - 2011-06-12 10:06:57 --> Utf8 Class Initialized
DEBUG - 2011-06-12 10:06:57 --> UTF-8 Support Enabled
DEBUG - 2011-06-12 10:06:57 --> URI Class Initialized
DEBUG - 2011-06-12 10:06:57 --> Router Class Initialized
DEBUG - 2011-06-12 10:06:57 --> Output Class Initialized
DEBUG - 2011-06-12 10:06:57 --> Input Class Initialized
DEBUG - 2011-06-12 10:06:57 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-12 10:06:57 --> Language Class Initialized
DEBUG - 2011-06-12 10:06:57 --> Loader Class Initialized
DEBUG - 2011-06-12 10:06:57 --> Controller Class Initialized
DEBUG - 2011-06-12 10:06:57 --> Model Class Initialized
DEBUG - 2011-06-12 10:06:57 --> Model Class Initialized
DEBUG - 2011-06-12 10:06:57 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-12 10:06:57 --> Database Driver Class Initialized
DEBUG - 2011-06-12 10:06:58 --> Final output sent to browser
DEBUG - 2011-06-12 10:06:58 --> Total execution time: 0.5472
DEBUG - 2011-06-12 10:07:05 --> Config Class Initialized
DEBUG - 2011-06-12 10:07:05 --> Hooks Class Initialized
DEBUG - 2011-06-12 10:07:05 --> Utf8 Class Initialized
DEBUG - 2011-06-12 10:07:05 --> UTF-8 Support Enabled
DEBUG - 2011-06-12 10:07:05 --> URI Class Initialized
DEBUG - 2011-06-12 10:07:05 --> Router Class Initialized
DEBUG - 2011-06-12 10:07:05 --> Output Class Initialized
DEBUG - 2011-06-12 10:07:05 --> Input Class Initialized
DEBUG - 2011-06-12 10:07:05 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-12 10:07:05 --> Language Class Initialized
DEBUG - 2011-06-12 10:07:05 --> Loader Class Initialized
DEBUG - 2011-06-12 10:07:05 --> Controller Class Initialized
ERROR - 2011-06-12 10:07:05 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-12 10:07:05 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-12 10:07:05 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-12 10:07:05 --> Model Class Initialized
DEBUG - 2011-06-12 10:07:05 --> Model Class Initialized
DEBUG - 2011-06-12 10:07:05 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-12 10:07:05 --> Database Driver Class Initialized
DEBUG - 2011-06-12 10:07:05 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-12 10:07:05 --> Helper loaded: url_helper
DEBUG - 2011-06-12 10:07:05 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-12 10:07:05 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-12 10:07:05 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-12 10:07:05 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-12 10:07:05 --> Final output sent to browser
DEBUG - 2011-06-12 10:07:05 --> Total execution time: 0.0319
DEBUG - 2011-06-12 11:01:14 --> Config Class Initialized
DEBUG - 2011-06-12 11:01:14 --> Hooks Class Initialized
DEBUG - 2011-06-12 11:01:14 --> Utf8 Class Initialized
DEBUG - 2011-06-12 11:01:14 --> UTF-8 Support Enabled
DEBUG - 2011-06-12 11:01:14 --> URI Class Initialized
DEBUG - 2011-06-12 11:01:14 --> Router Class Initialized
DEBUG - 2011-06-12 11:01:14 --> No URI present. Default controller set.
DEBUG - 2011-06-12 11:01:14 --> Output Class Initialized
DEBUG - 2011-06-12 11:01:14 --> Input Class Initialized
DEBUG - 2011-06-12 11:01:14 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-12 11:01:14 --> Language Class Initialized
DEBUG - 2011-06-12 11:01:14 --> Loader Class Initialized
DEBUG - 2011-06-12 11:01:14 --> Controller Class Initialized
DEBUG - 2011-06-12 11:01:14 --> File loaded: application/views/splash/main.php
DEBUG - 2011-06-12 11:01:14 --> Helper loaded: url_helper
DEBUG - 2011-06-12 11:01:14 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-12 11:01:14 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-12 11:01:14 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-12 11:01:14 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-12 11:01:14 --> Final output sent to browser
DEBUG - 2011-06-12 11:01:14 --> Total execution time: 0.3144
DEBUG - 2011-06-12 11:01:18 --> Config Class Initialized
DEBUG - 2011-06-12 11:01:18 --> Hooks Class Initialized
DEBUG - 2011-06-12 11:01:18 --> Utf8 Class Initialized
DEBUG - 2011-06-12 11:01:18 --> UTF-8 Support Enabled
DEBUG - 2011-06-12 11:01:18 --> URI Class Initialized
DEBUG - 2011-06-12 11:01:18 --> Router Class Initialized
ERROR - 2011-06-12 11:01:18 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-12 11:38:46 --> Config Class Initialized
DEBUG - 2011-06-12 11:38:46 --> Hooks Class Initialized
DEBUG - 2011-06-12 11:38:46 --> Utf8 Class Initialized
DEBUG - 2011-06-12 11:38:46 --> UTF-8 Support Enabled
DEBUG - 2011-06-12 11:38:46 --> URI Class Initialized
DEBUG - 2011-06-12 11:38:46 --> Router Class Initialized
DEBUG - 2011-06-12 11:38:46 --> Output Class Initialized
DEBUG - 2011-06-12 11:38:46 --> Input Class Initialized
DEBUG - 2011-06-12 11:38:46 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-12 11:38:46 --> Language Class Initialized
DEBUG - 2011-06-12 11:38:46 --> Loader Class Initialized
DEBUG - 2011-06-12 11:38:46 --> Controller Class Initialized
DEBUG - 2011-06-12 11:38:46 --> Model Class Initialized
DEBUG - 2011-06-12 11:38:46 --> Model Class Initialized
DEBUG - 2011-06-12 11:38:46 --> Model Class Initialized
DEBUG - 2011-06-12 11:38:46 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-12 11:38:46 --> Database Driver Class Initialized
DEBUG - 2011-06-12 11:38:47 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-12 11:38:47 --> Helper loaded: url_helper
DEBUG - 2011-06-12 11:38:47 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-12 11:38:47 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-12 11:38:47 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-12 11:38:47 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-12 11:38:47 --> Final output sent to browser
DEBUG - 2011-06-12 11:38:47 --> Total execution time: 0.7809
DEBUG - 2011-06-12 11:38:48 --> Config Class Initialized
DEBUG - 2011-06-12 11:38:48 --> Hooks Class Initialized
DEBUG - 2011-06-12 11:38:48 --> Utf8 Class Initialized
DEBUG - 2011-06-12 11:38:48 --> UTF-8 Support Enabled
DEBUG - 2011-06-12 11:38:48 --> URI Class Initialized
DEBUG - 2011-06-12 11:38:48 --> Router Class Initialized
DEBUG - 2011-06-12 11:38:48 --> Output Class Initialized
DEBUG - 2011-06-12 11:38:48 --> Input Class Initialized
DEBUG - 2011-06-12 11:38:48 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-12 11:38:48 --> Language Class Initialized
DEBUG - 2011-06-12 11:38:48 --> Loader Class Initialized
DEBUG - 2011-06-12 11:38:48 --> Controller Class Initialized
ERROR - 2011-06-12 11:38:48 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-12 11:38:48 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-12 11:38:48 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-12 11:38:48 --> Model Class Initialized
DEBUG - 2011-06-12 11:38:48 --> Model Class Initialized
DEBUG - 2011-06-12 11:38:48 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-12 11:38:48 --> Database Driver Class Initialized
DEBUG - 2011-06-12 11:38:48 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-12 11:38:48 --> Helper loaded: url_helper
DEBUG - 2011-06-12 11:38:48 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-12 11:38:48 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-12 11:38:48 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-12 11:38:48 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-12 11:38:48 --> Final output sent to browser
DEBUG - 2011-06-12 11:38:48 --> Total execution time: 0.1847
DEBUG - 2011-06-12 12:08:10 --> Config Class Initialized
DEBUG - 2011-06-12 12:08:10 --> Hooks Class Initialized
DEBUG - 2011-06-12 12:08:10 --> Utf8 Class Initialized
DEBUG - 2011-06-12 12:08:10 --> UTF-8 Support Enabled
DEBUG - 2011-06-12 12:08:10 --> URI Class Initialized
DEBUG - 2011-06-12 12:08:10 --> Router Class Initialized
ERROR - 2011-06-12 12:08:10 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-06-12 12:08:11 --> Config Class Initialized
DEBUG - 2011-06-12 12:08:11 --> Hooks Class Initialized
DEBUG - 2011-06-12 12:08:11 --> Utf8 Class Initialized
DEBUG - 2011-06-12 12:08:11 --> UTF-8 Support Enabled
DEBUG - 2011-06-12 12:08:11 --> URI Class Initialized
DEBUG - 2011-06-12 12:08:11 --> Router Class Initialized
DEBUG - 2011-06-12 12:08:11 --> Output Class Initialized
DEBUG - 2011-06-12 12:08:11 --> Input Class Initialized
DEBUG - 2011-06-12 12:08:11 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-12 12:08:11 --> Language Class Initialized
DEBUG - 2011-06-12 12:08:11 --> Loader Class Initialized
DEBUG - 2011-06-12 12:08:11 --> Controller Class Initialized
DEBUG - 2011-06-12 12:08:11 --> Model Class Initialized
DEBUG - 2011-06-12 12:08:11 --> Model Class Initialized
DEBUG - 2011-06-12 12:08:11 --> Model Class Initialized
DEBUG - 2011-06-12 12:08:11 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-12 12:08:11 --> Database Driver Class Initialized
DEBUG - 2011-06-12 12:08:11 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-12 12:08:11 --> Helper loaded: url_helper
DEBUG - 2011-06-12 12:08:11 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-12 12:08:11 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-12 12:08:11 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-12 12:08:11 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-12 12:08:11 --> Final output sent to browser
DEBUG - 2011-06-12 12:08:11 --> Total execution time: 0.4944
DEBUG - 2011-06-12 12:08:41 --> Config Class Initialized
DEBUG - 2011-06-12 12:08:41 --> Hooks Class Initialized
DEBUG - 2011-06-12 12:08:41 --> Utf8 Class Initialized
DEBUG - 2011-06-12 12:08:41 --> UTF-8 Support Enabled
DEBUG - 2011-06-12 12:08:41 --> URI Class Initialized
DEBUG - 2011-06-12 12:08:41 --> Router Class Initialized
DEBUG - 2011-06-12 12:08:41 --> Output Class Initialized
DEBUG - 2011-06-12 12:08:41 --> Input Class Initialized
DEBUG - 2011-06-12 12:08:41 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-12 12:08:41 --> Language Class Initialized
DEBUG - 2011-06-12 12:08:41 --> Loader Class Initialized
DEBUG - 2011-06-12 12:08:41 --> Controller Class Initialized
ERROR - 2011-06-12 12:08:41 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-12 12:08:41 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-12 12:08:41 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-12 12:08:41 --> Model Class Initialized
DEBUG - 2011-06-12 12:08:41 --> Model Class Initialized
DEBUG - 2011-06-12 12:08:41 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-12 12:08:41 --> Database Driver Class Initialized
DEBUG - 2011-06-12 12:08:42 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-12 12:08:42 --> Helper loaded: url_helper
DEBUG - 2011-06-12 12:08:42 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-12 12:08:42 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-12 12:08:42 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-12 12:08:42 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-12 12:08:42 --> Final output sent to browser
DEBUG - 2011-06-12 12:08:42 --> Total execution time: 0.1001
DEBUG - 2011-06-12 14:00:52 --> Config Class Initialized
DEBUG - 2011-06-12 14:00:52 --> Hooks Class Initialized
DEBUG - 2011-06-12 14:00:52 --> Utf8 Class Initialized
DEBUG - 2011-06-12 14:00:52 --> UTF-8 Support Enabled
DEBUG - 2011-06-12 14:00:52 --> URI Class Initialized
DEBUG - 2011-06-12 14:00:52 --> Router Class Initialized
DEBUG - 2011-06-12 14:00:52 --> No URI present. Default controller set.
DEBUG - 2011-06-12 14:00:52 --> Output Class Initialized
DEBUG - 2011-06-12 14:00:52 --> Input Class Initialized
DEBUG - 2011-06-12 14:00:52 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-12 14:00:52 --> Language Class Initialized
DEBUG - 2011-06-12 14:00:53 --> Loader Class Initialized
DEBUG - 2011-06-12 14:00:53 --> Controller Class Initialized
DEBUG - 2011-06-12 14:00:53 --> File loaded: application/views/splash/main.php
DEBUG - 2011-06-12 14:00:53 --> Helper loaded: url_helper
DEBUG - 2011-06-12 14:00:53 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-12 14:00:53 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-12 14:00:53 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-12 14:00:53 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-12 14:00:53 --> Final output sent to browser
DEBUG - 2011-06-12 14:00:53 --> Total execution time: 0.3744
DEBUG - 2011-06-12 15:28:57 --> Config Class Initialized
DEBUG - 2011-06-12 15:28:57 --> Hooks Class Initialized
DEBUG - 2011-06-12 15:28:57 --> Utf8 Class Initialized
DEBUG - 2011-06-12 15:28:57 --> UTF-8 Support Enabled
DEBUG - 2011-06-12 15:28:57 --> URI Class Initialized
DEBUG - 2011-06-12 15:28:57 --> Router Class Initialized
DEBUG - 2011-06-12 15:28:57 --> Output Class Initialized
DEBUG - 2011-06-12 15:28:57 --> Input Class Initialized
DEBUG - 2011-06-12 15:28:57 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-12 15:28:57 --> Language Class Initialized
DEBUG - 2011-06-12 15:28:57 --> Loader Class Initialized
DEBUG - 2011-06-12 15:28:57 --> Controller Class Initialized
DEBUG - 2011-06-12 15:28:57 --> Model Class Initialized
DEBUG - 2011-06-12 15:28:57 --> Model Class Initialized
DEBUG - 2011-06-12 15:28:57 --> Model Class Initialized
DEBUG - 2011-06-12 15:28:57 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-12 15:28:57 --> Database Driver Class Initialized
DEBUG - 2011-06-12 15:28:57 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-12 15:28:57 --> Helper loaded: url_helper
DEBUG - 2011-06-12 15:28:57 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-12 15:28:57 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-12 15:28:57 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-12 15:28:57 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-12 15:28:57 --> Final output sent to browser
DEBUG - 2011-06-12 15:28:57 --> Total execution time: 0.6386
DEBUG - 2011-06-12 15:29:02 --> Config Class Initialized
DEBUG - 2011-06-12 15:29:02 --> Hooks Class Initialized
DEBUG - 2011-06-12 15:29:02 --> Utf8 Class Initialized
DEBUG - 2011-06-12 15:29:02 --> UTF-8 Support Enabled
DEBUG - 2011-06-12 15:29:02 --> URI Class Initialized
DEBUG - 2011-06-12 15:29:02 --> Router Class Initialized
ERROR - 2011-06-12 15:29:02 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-12 15:46:09 --> Config Class Initialized
DEBUG - 2011-06-12 15:46:09 --> Hooks Class Initialized
DEBUG - 2011-06-12 15:46:09 --> Utf8 Class Initialized
DEBUG - 2011-06-12 15:46:09 --> UTF-8 Support Enabled
DEBUG - 2011-06-12 15:46:09 --> URI Class Initialized
DEBUG - 2011-06-12 15:46:09 --> Router Class Initialized
ERROR - 2011-06-12 15:46:09 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-06-12 15:46:10 --> Config Class Initialized
DEBUG - 2011-06-12 15:46:10 --> Hooks Class Initialized
DEBUG - 2011-06-12 15:46:10 --> Utf8 Class Initialized
DEBUG - 2011-06-12 15:46:10 --> UTF-8 Support Enabled
DEBUG - 2011-06-12 15:46:10 --> URI Class Initialized
DEBUG - 2011-06-12 15:46:10 --> Router Class Initialized
DEBUG - 2011-06-12 15:46:10 --> No URI present. Default controller set.
DEBUG - 2011-06-12 15:46:10 --> Output Class Initialized
DEBUG - 2011-06-12 15:46:10 --> Input Class Initialized
DEBUG - 2011-06-12 15:46:10 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-12 15:46:10 --> Language Class Initialized
DEBUG - 2011-06-12 15:46:10 --> Loader Class Initialized
DEBUG - 2011-06-12 15:46:10 --> Controller Class Initialized
DEBUG - 2011-06-12 15:46:11 --> File loaded: application/views/splash/main.php
DEBUG - 2011-06-12 15:46:11 --> Helper loaded: url_helper
DEBUG - 2011-06-12 15:46:11 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-12 15:46:11 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-12 15:46:11 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-12 15:46:11 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-12 15:46:11 --> Final output sent to browser
DEBUG - 2011-06-12 15:46:11 --> Total execution time: 0.1816
DEBUG - 2011-06-12 16:06:58 --> Config Class Initialized
DEBUG - 2011-06-12 16:06:58 --> Hooks Class Initialized
DEBUG - 2011-06-12 16:06:58 --> Utf8 Class Initialized
DEBUG - 2011-06-12 16:06:58 --> UTF-8 Support Enabled
DEBUG - 2011-06-12 16:06:58 --> URI Class Initialized
DEBUG - 2011-06-12 16:06:58 --> Router Class Initialized
DEBUG - 2011-06-12 16:06:58 --> Output Class Initialized
DEBUG - 2011-06-12 16:06:58 --> Input Class Initialized
DEBUG - 2011-06-12 16:06:58 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-12 16:06:58 --> Language Class Initialized
DEBUG - 2011-06-12 16:06:58 --> Loader Class Initialized
DEBUG - 2011-06-12 16:06:58 --> Controller Class Initialized
ERROR - 2011-06-12 16:06:58 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-12 16:06:58 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-12 16:06:58 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-12 16:06:58 --> Model Class Initialized
DEBUG - 2011-06-12 16:06:58 --> Model Class Initialized
DEBUG - 2011-06-12 16:06:58 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-12 16:06:58 --> Database Driver Class Initialized
DEBUG - 2011-06-12 16:06:58 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-12 16:06:58 --> Helper loaded: url_helper
DEBUG - 2011-06-12 16:06:58 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-12 16:06:59 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-12 16:06:59 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-12 16:06:59 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-12 16:06:59 --> Final output sent to browser
DEBUG - 2011-06-12 16:06:59 --> Total execution time: 0.3103
DEBUG - 2011-06-12 16:07:00 --> Config Class Initialized
DEBUG - 2011-06-12 16:07:00 --> Hooks Class Initialized
DEBUG - 2011-06-12 16:07:00 --> Utf8 Class Initialized
DEBUG - 2011-06-12 16:07:00 --> UTF-8 Support Enabled
DEBUG - 2011-06-12 16:07:00 --> URI Class Initialized
DEBUG - 2011-06-12 16:07:00 --> Router Class Initialized
DEBUG - 2011-06-12 16:07:00 --> Output Class Initialized
DEBUG - 2011-06-12 16:07:00 --> Input Class Initialized
DEBUG - 2011-06-12 16:07:00 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-12 16:07:00 --> Language Class Initialized
DEBUG - 2011-06-12 16:07:00 --> Loader Class Initialized
DEBUG - 2011-06-12 16:07:00 --> Controller Class Initialized
DEBUG - 2011-06-12 16:07:00 --> Model Class Initialized
DEBUG - 2011-06-12 16:07:00 --> Model Class Initialized
DEBUG - 2011-06-12 16:07:00 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-12 16:07:00 --> Database Driver Class Initialized
DEBUG - 2011-06-12 16:07:01 --> Final output sent to browser
DEBUG - 2011-06-12 16:07:01 --> Total execution time: 0.6227
DEBUG - 2011-06-12 16:07:02 --> Config Class Initialized
DEBUG - 2011-06-12 16:07:02 --> Hooks Class Initialized
DEBUG - 2011-06-12 16:07:02 --> Utf8 Class Initialized
DEBUG - 2011-06-12 16:07:02 --> UTF-8 Support Enabled
DEBUG - 2011-06-12 16:07:02 --> URI Class Initialized
DEBUG - 2011-06-12 16:07:02 --> Router Class Initialized
ERROR - 2011-06-12 16:07:02 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-12 16:08:22 --> Config Class Initialized
DEBUG - 2011-06-12 16:08:22 --> Hooks Class Initialized
DEBUG - 2011-06-12 16:08:22 --> Utf8 Class Initialized
DEBUG - 2011-06-12 16:08:22 --> UTF-8 Support Enabled
DEBUG - 2011-06-12 16:08:22 --> URI Class Initialized
DEBUG - 2011-06-12 16:08:22 --> Router Class Initialized
ERROR - 2011-06-12 16:08:22 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-12 17:00:18 --> Config Class Initialized
DEBUG - 2011-06-12 17:00:18 --> Hooks Class Initialized
DEBUG - 2011-06-12 17:00:18 --> Utf8 Class Initialized
DEBUG - 2011-06-12 17:00:18 --> UTF-8 Support Enabled
DEBUG - 2011-06-12 17:00:18 --> URI Class Initialized
DEBUG - 2011-06-12 17:00:18 --> Router Class Initialized
DEBUG - 2011-06-12 17:00:18 --> Output Class Initialized
DEBUG - 2011-06-12 17:00:18 --> Input Class Initialized
DEBUG - 2011-06-12 17:00:18 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-12 17:00:18 --> Language Class Initialized
DEBUG - 2011-06-12 17:00:18 --> Loader Class Initialized
DEBUG - 2011-06-12 17:00:18 --> Controller Class Initialized
ERROR - 2011-06-12 17:00:18 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-12 17:00:18 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-12 17:00:18 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-12 17:00:18 --> Model Class Initialized
DEBUG - 2011-06-12 17:00:18 --> Model Class Initialized
DEBUG - 2011-06-12 17:00:18 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-12 17:00:18 --> Database Driver Class Initialized
DEBUG - 2011-06-12 17:00:18 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-12 17:00:18 --> Helper loaded: url_helper
DEBUG - 2011-06-12 17:00:18 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-12 17:00:18 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-12 17:00:18 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-12 17:00:18 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-12 17:00:18 --> Final output sent to browser
DEBUG - 2011-06-12 17:00:18 --> Total execution time: 0.2318
DEBUG - 2011-06-12 18:18:41 --> Config Class Initialized
DEBUG - 2011-06-12 18:18:41 --> Hooks Class Initialized
DEBUG - 2011-06-12 18:18:41 --> Utf8 Class Initialized
DEBUG - 2011-06-12 18:18:41 --> UTF-8 Support Enabled
DEBUG - 2011-06-12 18:18:41 --> URI Class Initialized
DEBUG - 2011-06-12 18:18:41 --> Router Class Initialized
DEBUG - 2011-06-12 18:18:41 --> Output Class Initialized
DEBUG - 2011-06-12 18:18:41 --> Input Class Initialized
DEBUG - 2011-06-12 18:18:41 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-12 18:18:41 --> Language Class Initialized
DEBUG - 2011-06-12 18:18:41 --> Loader Class Initialized
DEBUG - 2011-06-12 18:18:41 --> Controller Class Initialized
ERROR - 2011-06-12 18:18:41 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-12 18:18:41 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-12 18:18:41 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-12 18:18:41 --> Model Class Initialized
DEBUG - 2011-06-12 18:18:41 --> Model Class Initialized
DEBUG - 2011-06-12 18:18:41 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-12 18:18:41 --> Database Driver Class Initialized
DEBUG - 2011-06-12 18:18:41 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-12 18:18:41 --> Helper loaded: url_helper
DEBUG - 2011-06-12 18:18:41 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-12 18:18:41 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-12 18:18:41 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-12 18:18:41 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-12 18:18:41 --> Final output sent to browser
DEBUG - 2011-06-12 18:18:41 --> Total execution time: 0.4227
DEBUG - 2011-06-12 18:18:42 --> Config Class Initialized
DEBUG - 2011-06-12 18:18:42 --> Hooks Class Initialized
DEBUG - 2011-06-12 18:18:42 --> Utf8 Class Initialized
DEBUG - 2011-06-12 18:18:42 --> UTF-8 Support Enabled
DEBUG - 2011-06-12 18:18:42 --> URI Class Initialized
DEBUG - 2011-06-12 18:18:42 --> Router Class Initialized
DEBUG - 2011-06-12 18:18:42 --> Output Class Initialized
DEBUG - 2011-06-12 18:18:42 --> Input Class Initialized
DEBUG - 2011-06-12 18:18:42 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-12 18:18:42 --> Language Class Initialized
DEBUG - 2011-06-12 18:18:42 --> Loader Class Initialized
DEBUG - 2011-06-12 18:18:42 --> Controller Class Initialized
DEBUG - 2011-06-12 18:18:42 --> Model Class Initialized
DEBUG - 2011-06-12 18:18:42 --> Model Class Initialized
DEBUG - 2011-06-12 18:18:42 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-12 18:18:42 --> Database Driver Class Initialized
DEBUG - 2011-06-12 18:18:43 --> Final output sent to browser
DEBUG - 2011-06-12 18:18:43 --> Total execution time: 0.7569
DEBUG - 2011-06-12 18:18:44 --> Config Class Initialized
DEBUG - 2011-06-12 18:18:44 --> Hooks Class Initialized
DEBUG - 2011-06-12 18:18:44 --> Utf8 Class Initialized
DEBUG - 2011-06-12 18:18:44 --> UTF-8 Support Enabled
DEBUG - 2011-06-12 18:18:44 --> URI Class Initialized
DEBUG - 2011-06-12 18:18:44 --> Router Class Initialized
ERROR - 2011-06-12 18:18:44 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-12 18:19:01 --> Config Class Initialized
DEBUG - 2011-06-12 18:19:01 --> Hooks Class Initialized
DEBUG - 2011-06-12 18:19:01 --> Utf8 Class Initialized
DEBUG - 2011-06-12 18:19:01 --> UTF-8 Support Enabled
DEBUG - 2011-06-12 18:19:01 --> URI Class Initialized
DEBUG - 2011-06-12 18:19:01 --> Router Class Initialized
DEBUG - 2011-06-12 18:19:01 --> Output Class Initialized
DEBUG - 2011-06-12 18:19:01 --> Input Class Initialized
DEBUG - 2011-06-12 18:19:01 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-12 18:19:01 --> Language Class Initialized
DEBUG - 2011-06-12 18:19:01 --> Loader Class Initialized
DEBUG - 2011-06-12 18:19:01 --> Controller Class Initialized
ERROR - 2011-06-12 18:19:01 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-12 18:19:01 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-12 18:19:01 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-12 18:19:01 --> Model Class Initialized
DEBUG - 2011-06-12 18:19:01 --> Model Class Initialized
DEBUG - 2011-06-12 18:19:01 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-12 18:19:01 --> Database Driver Class Initialized
DEBUG - 2011-06-12 18:19:01 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-12 18:19:01 --> Helper loaded: url_helper
DEBUG - 2011-06-12 18:19:01 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-12 18:19:01 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-12 18:19:01 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-12 18:19:01 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-12 18:19:01 --> Final output sent to browser
DEBUG - 2011-06-12 18:19:01 --> Total execution time: 0.0274
DEBUG - 2011-06-12 18:19:01 --> Config Class Initialized
DEBUG - 2011-06-12 18:19:01 --> Hooks Class Initialized
DEBUG - 2011-06-12 18:19:01 --> Utf8 Class Initialized
DEBUG - 2011-06-12 18:19:01 --> UTF-8 Support Enabled
DEBUG - 2011-06-12 18:19:01 --> URI Class Initialized
DEBUG - 2011-06-12 18:19:01 --> Router Class Initialized
DEBUG - 2011-06-12 18:19:01 --> Output Class Initialized
DEBUG - 2011-06-12 18:19:01 --> Input Class Initialized
DEBUG - 2011-06-12 18:19:01 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-12 18:19:01 --> Language Class Initialized
DEBUG - 2011-06-12 18:19:01 --> Loader Class Initialized
DEBUG - 2011-06-12 18:19:01 --> Controller Class Initialized
DEBUG - 2011-06-12 18:19:01 --> Model Class Initialized
DEBUG - 2011-06-12 18:19:01 --> Model Class Initialized
DEBUG - 2011-06-12 18:19:01 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-12 18:19:01 --> Database Driver Class Initialized
DEBUG - 2011-06-12 18:19:02 --> Final output sent to browser
DEBUG - 2011-06-12 18:19:02 --> Total execution time: 0.6484
DEBUG - 2011-06-12 18:19:03 --> Config Class Initialized
DEBUG - 2011-06-12 18:19:03 --> Hooks Class Initialized
DEBUG - 2011-06-12 18:19:03 --> Utf8 Class Initialized
DEBUG - 2011-06-12 18:19:03 --> UTF-8 Support Enabled
DEBUG - 2011-06-12 18:19:03 --> URI Class Initialized
DEBUG - 2011-06-12 18:19:03 --> Router Class Initialized
ERROR - 2011-06-12 18:19:03 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-12 18:19:28 --> Config Class Initialized
DEBUG - 2011-06-12 18:19:28 --> Hooks Class Initialized
DEBUG - 2011-06-12 18:19:28 --> Utf8 Class Initialized
DEBUG - 2011-06-12 18:19:28 --> UTF-8 Support Enabled
DEBUG - 2011-06-12 18:19:28 --> URI Class Initialized
DEBUG - 2011-06-12 18:19:28 --> Router Class Initialized
DEBUG - 2011-06-12 18:19:28 --> Output Class Initialized
DEBUG - 2011-06-12 18:19:28 --> Input Class Initialized
DEBUG - 2011-06-12 18:19:28 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-12 18:19:28 --> Language Class Initialized
DEBUG - 2011-06-12 18:19:28 --> Loader Class Initialized
DEBUG - 2011-06-12 18:19:28 --> Controller Class Initialized
ERROR - 2011-06-12 18:19:28 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-12 18:19:28 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-12 18:19:28 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-12 18:19:28 --> Model Class Initialized
DEBUG - 2011-06-12 18:19:28 --> Model Class Initialized
DEBUG - 2011-06-12 18:19:28 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-12 18:19:28 --> Database Driver Class Initialized
DEBUG - 2011-06-12 18:19:28 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-12 18:19:28 --> Helper loaded: url_helper
DEBUG - 2011-06-12 18:19:28 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-12 18:19:28 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-12 18:19:28 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-12 18:19:28 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-12 18:19:28 --> Final output sent to browser
DEBUG - 2011-06-12 18:19:28 --> Total execution time: 0.0342
DEBUG - 2011-06-12 18:19:29 --> Config Class Initialized
DEBUG - 2011-06-12 18:19:29 --> Hooks Class Initialized
DEBUG - 2011-06-12 18:19:29 --> Utf8 Class Initialized
DEBUG - 2011-06-12 18:19:29 --> UTF-8 Support Enabled
DEBUG - 2011-06-12 18:19:29 --> URI Class Initialized
DEBUG - 2011-06-12 18:19:29 --> Router Class Initialized
DEBUG - 2011-06-12 18:19:29 --> Output Class Initialized
DEBUG - 2011-06-12 18:19:29 --> Input Class Initialized
DEBUG - 2011-06-12 18:19:29 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-12 18:19:29 --> Language Class Initialized
DEBUG - 2011-06-12 18:19:29 --> Loader Class Initialized
DEBUG - 2011-06-12 18:19:29 --> Controller Class Initialized
DEBUG - 2011-06-12 18:19:29 --> Model Class Initialized
DEBUG - 2011-06-12 18:19:29 --> Model Class Initialized
DEBUG - 2011-06-12 18:19:29 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-12 18:19:29 --> Database Driver Class Initialized
DEBUG - 2011-06-12 18:19:29 --> Final output sent to browser
DEBUG - 2011-06-12 18:19:29 --> Total execution time: 0.5797
DEBUG - 2011-06-12 18:19:30 --> Config Class Initialized
DEBUG - 2011-06-12 18:19:30 --> Hooks Class Initialized
DEBUG - 2011-06-12 18:19:30 --> Utf8 Class Initialized
DEBUG - 2011-06-12 18:19:30 --> UTF-8 Support Enabled
DEBUG - 2011-06-12 18:19:30 --> URI Class Initialized
DEBUG - 2011-06-12 18:19:30 --> Router Class Initialized
ERROR - 2011-06-12 18:19:30 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-12 18:19:33 --> Config Class Initialized
DEBUG - 2011-06-12 18:19:33 --> Hooks Class Initialized
DEBUG - 2011-06-12 18:19:33 --> Utf8 Class Initialized
DEBUG - 2011-06-12 18:19:33 --> UTF-8 Support Enabled
DEBUG - 2011-06-12 18:19:33 --> URI Class Initialized
DEBUG - 2011-06-12 18:19:33 --> Router Class Initialized
DEBUG - 2011-06-12 18:19:33 --> Output Class Initialized
DEBUG - 2011-06-12 18:19:33 --> Input Class Initialized
DEBUG - 2011-06-12 18:19:33 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-12 18:19:33 --> Language Class Initialized
DEBUG - 2011-06-12 18:19:33 --> Loader Class Initialized
DEBUG - 2011-06-12 18:19:33 --> Controller Class Initialized
ERROR - 2011-06-12 18:19:33 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-12 18:19:33 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-12 18:19:33 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-12 18:19:33 --> Model Class Initialized
DEBUG - 2011-06-12 18:19:33 --> Model Class Initialized
DEBUG - 2011-06-12 18:19:33 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-12 18:19:33 --> Database Driver Class Initialized
DEBUG - 2011-06-12 18:19:33 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-12 18:19:33 --> Helper loaded: url_helper
DEBUG - 2011-06-12 18:19:33 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-12 18:19:33 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-12 18:19:33 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-12 18:19:33 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-12 18:19:33 --> Final output sent to browser
DEBUG - 2011-06-12 18:19:33 --> Total execution time: 0.0322
DEBUG - 2011-06-12 18:19:33 --> Config Class Initialized
DEBUG - 2011-06-12 18:19:33 --> Hooks Class Initialized
DEBUG - 2011-06-12 18:19:33 --> Utf8 Class Initialized
DEBUG - 2011-06-12 18:19:33 --> UTF-8 Support Enabled
DEBUG - 2011-06-12 18:19:33 --> URI Class Initialized
DEBUG - 2011-06-12 18:19:33 --> Router Class Initialized
DEBUG - 2011-06-12 18:19:33 --> Output Class Initialized
DEBUG - 2011-06-12 18:19:33 --> Input Class Initialized
DEBUG - 2011-06-12 18:19:33 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-12 18:19:33 --> Language Class Initialized
DEBUG - 2011-06-12 18:19:33 --> Loader Class Initialized
DEBUG - 2011-06-12 18:19:33 --> Controller Class Initialized
DEBUG - 2011-06-12 18:19:33 --> Model Class Initialized
DEBUG - 2011-06-12 18:19:33 --> Model Class Initialized
DEBUG - 2011-06-12 18:19:33 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-12 18:19:33 --> Database Driver Class Initialized
DEBUG - 2011-06-12 18:19:33 --> Config Class Initialized
DEBUG - 2011-06-12 18:19:33 --> Hooks Class Initialized
DEBUG - 2011-06-12 18:19:33 --> Utf8 Class Initialized
DEBUG - 2011-06-12 18:19:33 --> UTF-8 Support Enabled
DEBUG - 2011-06-12 18:19:33 --> URI Class Initialized
DEBUG - 2011-06-12 18:19:33 --> Router Class Initialized
DEBUG - 2011-06-12 18:19:33 --> Output Class Initialized
DEBUG - 2011-06-12 18:19:33 --> Input Class Initialized
DEBUG - 2011-06-12 18:19:33 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-12 18:19:33 --> Language Class Initialized
DEBUG - 2011-06-12 18:19:33 --> Loader Class Initialized
DEBUG - 2011-06-12 18:19:33 --> Controller Class Initialized
ERROR - 2011-06-12 18:19:33 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-12 18:19:33 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-12 18:19:33 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-12 18:19:33 --> Model Class Initialized
DEBUG - 2011-06-12 18:19:33 --> Model Class Initialized
DEBUG - 2011-06-12 18:19:33 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-12 18:19:33 --> Database Driver Class Initialized
DEBUG - 2011-06-12 18:19:33 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-12 18:19:33 --> Helper loaded: url_helper
DEBUG - 2011-06-12 18:19:33 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-12 18:19:33 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-12 18:19:33 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-12 18:19:33 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-12 18:19:33 --> Final output sent to browser
DEBUG - 2011-06-12 18:19:33 --> Total execution time: 0.0283
DEBUG - 2011-06-12 18:19:34 --> Final output sent to browser
DEBUG - 2011-06-12 18:19:34 --> Total execution time: 0.6405
DEBUG - 2011-06-12 18:19:35 --> Config Class Initialized
DEBUG - 2011-06-12 18:19:35 --> Hooks Class Initialized
DEBUG - 2011-06-12 18:19:35 --> Utf8 Class Initialized
DEBUG - 2011-06-12 18:19:35 --> UTF-8 Support Enabled
DEBUG - 2011-06-12 18:19:35 --> URI Class Initialized
DEBUG - 2011-06-12 18:19:35 --> Router Class Initialized
ERROR - 2011-06-12 18:19:35 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-12 18:19:40 --> Config Class Initialized
DEBUG - 2011-06-12 18:19:40 --> Hooks Class Initialized
DEBUG - 2011-06-12 18:19:40 --> Utf8 Class Initialized
DEBUG - 2011-06-12 18:19:40 --> UTF-8 Support Enabled
DEBUG - 2011-06-12 18:19:40 --> URI Class Initialized
DEBUG - 2011-06-12 18:19:40 --> Router Class Initialized
DEBUG - 2011-06-12 18:19:40 --> Output Class Initialized
DEBUG - 2011-06-12 18:19:40 --> Input Class Initialized
DEBUG - 2011-06-12 18:19:40 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-12 18:19:40 --> Language Class Initialized
DEBUG - 2011-06-12 18:19:40 --> Loader Class Initialized
DEBUG - 2011-06-12 18:19:40 --> Controller Class Initialized
ERROR - 2011-06-12 18:19:40 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-12 18:19:40 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-12 18:19:40 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-12 18:19:40 --> Model Class Initialized
DEBUG - 2011-06-12 18:19:40 --> Model Class Initialized
DEBUG - 2011-06-12 18:19:40 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-12 18:19:40 --> Database Driver Class Initialized
DEBUG - 2011-06-12 18:19:40 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-12 18:19:40 --> Helper loaded: url_helper
DEBUG - 2011-06-12 18:19:40 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-12 18:19:40 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-12 18:19:40 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-12 18:19:40 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-12 18:19:40 --> Final output sent to browser
DEBUG - 2011-06-12 18:19:40 --> Total execution time: 0.0312
DEBUG - 2011-06-12 18:19:40 --> Config Class Initialized
DEBUG - 2011-06-12 18:19:40 --> Hooks Class Initialized
DEBUG - 2011-06-12 18:19:40 --> Utf8 Class Initialized
DEBUG - 2011-06-12 18:19:40 --> UTF-8 Support Enabled
DEBUG - 2011-06-12 18:19:40 --> URI Class Initialized
DEBUG - 2011-06-12 18:19:40 --> Router Class Initialized
DEBUG - 2011-06-12 18:19:40 --> Output Class Initialized
DEBUG - 2011-06-12 18:19:40 --> Input Class Initialized
DEBUG - 2011-06-12 18:19:40 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-12 18:19:40 --> Language Class Initialized
DEBUG - 2011-06-12 18:19:40 --> Loader Class Initialized
DEBUG - 2011-06-12 18:19:40 --> Controller Class Initialized
DEBUG - 2011-06-12 18:19:40 --> Model Class Initialized
DEBUG - 2011-06-12 18:19:40 --> Model Class Initialized
DEBUG - 2011-06-12 18:19:40 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-12 18:19:40 --> Database Driver Class Initialized
DEBUG - 2011-06-12 18:19:41 --> Final output sent to browser
DEBUG - 2011-06-12 18:19:41 --> Total execution time: 0.5491
DEBUG - 2011-06-12 18:19:41 --> Config Class Initialized
DEBUG - 2011-06-12 18:19:41 --> Hooks Class Initialized
DEBUG - 2011-06-12 18:19:41 --> Utf8 Class Initialized
DEBUG - 2011-06-12 18:19:41 --> UTF-8 Support Enabled
DEBUG - 2011-06-12 18:19:41 --> URI Class Initialized
DEBUG - 2011-06-12 18:19:41 --> Router Class Initialized
ERROR - 2011-06-12 18:19:41 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-12 18:19:44 --> Config Class Initialized
DEBUG - 2011-06-12 18:19:44 --> Hooks Class Initialized
DEBUG - 2011-06-12 18:19:44 --> Utf8 Class Initialized
DEBUG - 2011-06-12 18:19:44 --> UTF-8 Support Enabled
DEBUG - 2011-06-12 18:19:44 --> URI Class Initialized
DEBUG - 2011-06-12 18:19:44 --> Router Class Initialized
ERROR - 2011-06-12 18:19:44 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-12 18:19:45 --> Config Class Initialized
DEBUG - 2011-06-12 18:19:45 --> Hooks Class Initialized
DEBUG - 2011-06-12 18:19:45 --> Utf8 Class Initialized
DEBUG - 2011-06-12 18:19:45 --> UTF-8 Support Enabled
DEBUG - 2011-06-12 18:19:45 --> URI Class Initialized
DEBUG - 2011-06-12 18:19:45 --> Router Class Initialized
ERROR - 2011-06-12 18:19:45 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-12 18:19:45 --> Config Class Initialized
DEBUG - 2011-06-12 18:19:45 --> Hooks Class Initialized
DEBUG - 2011-06-12 18:19:45 --> Utf8 Class Initialized
DEBUG - 2011-06-12 18:19:45 --> UTF-8 Support Enabled
DEBUG - 2011-06-12 18:19:45 --> URI Class Initialized
DEBUG - 2011-06-12 18:19:45 --> Router Class Initialized
ERROR - 2011-06-12 18:19:45 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-12 18:19:46 --> Config Class Initialized
DEBUG - 2011-06-12 18:19:46 --> Hooks Class Initialized
DEBUG - 2011-06-12 18:19:46 --> Utf8 Class Initialized
DEBUG - 2011-06-12 18:19:46 --> UTF-8 Support Enabled
DEBUG - 2011-06-12 18:19:46 --> URI Class Initialized
DEBUG - 2011-06-12 18:19:46 --> Router Class Initialized
ERROR - 2011-06-12 18:19:46 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-12 20:05:48 --> Config Class Initialized
DEBUG - 2011-06-12 20:05:48 --> Hooks Class Initialized
DEBUG - 2011-06-12 20:05:48 --> Utf8 Class Initialized
DEBUG - 2011-06-12 20:05:48 --> UTF-8 Support Enabled
DEBUG - 2011-06-12 20:05:48 --> URI Class Initialized
DEBUG - 2011-06-12 20:05:48 --> Router Class Initialized
DEBUG - 2011-06-12 20:05:48 --> Output Class Initialized
DEBUG - 2011-06-12 20:05:48 --> Input Class Initialized
DEBUG - 2011-06-12 20:05:48 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-12 20:05:48 --> Language Class Initialized
DEBUG - 2011-06-12 20:05:48 --> Loader Class Initialized
DEBUG - 2011-06-12 20:05:48 --> Controller Class Initialized
DEBUG - 2011-06-12 20:05:48 --> Model Class Initialized
DEBUG - 2011-06-12 20:05:48 --> Model Class Initialized
DEBUG - 2011-06-12 20:05:48 --> Model Class Initialized
DEBUG - 2011-06-12 20:05:48 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-12 20:05:48 --> Database Driver Class Initialized
DEBUG - 2011-06-12 20:05:48 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-12 20:05:48 --> Helper loaded: url_helper
DEBUG - 2011-06-12 20:05:48 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-12 20:05:48 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-12 20:05:48 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-12 20:05:48 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-12 20:05:48 --> Final output sent to browser
DEBUG - 2011-06-12 20:05:48 --> Total execution time: 0.6728
DEBUG - 2011-06-12 20:05:53 --> Config Class Initialized
DEBUG - 2011-06-12 20:05:53 --> Hooks Class Initialized
DEBUG - 2011-06-12 20:05:53 --> Utf8 Class Initialized
DEBUG - 2011-06-12 20:05:53 --> UTF-8 Support Enabled
DEBUG - 2011-06-12 20:05:53 --> URI Class Initialized
DEBUG - 2011-06-12 20:05:53 --> Router Class Initialized
ERROR - 2011-06-12 20:05:53 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-12 20:05:53 --> Config Class Initialized
DEBUG - 2011-06-12 20:05:53 --> Hooks Class Initialized
DEBUG - 2011-06-12 20:05:53 --> Utf8 Class Initialized
DEBUG - 2011-06-12 20:05:53 --> UTF-8 Support Enabled
DEBUG - 2011-06-12 20:05:53 --> URI Class Initialized
DEBUG - 2011-06-12 20:05:53 --> Router Class Initialized
ERROR - 2011-06-12 20:05:53 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-12 21:56:51 --> Config Class Initialized
DEBUG - 2011-06-12 21:56:51 --> Hooks Class Initialized
DEBUG - 2011-06-12 21:56:51 --> Utf8 Class Initialized
DEBUG - 2011-06-12 21:56:51 --> UTF-8 Support Enabled
DEBUG - 2011-06-12 21:56:51 --> URI Class Initialized
DEBUG - 2011-06-12 21:56:51 --> Router Class Initialized
ERROR - 2011-06-12 21:56:52 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-06-12 21:56:54 --> Config Class Initialized
DEBUG - 2011-06-12 21:56:54 --> Hooks Class Initialized
DEBUG - 2011-06-12 21:56:54 --> Utf8 Class Initialized
DEBUG - 2011-06-12 21:56:54 --> UTF-8 Support Enabled
DEBUG - 2011-06-12 21:56:54 --> URI Class Initialized
DEBUG - 2011-06-12 21:56:54 --> Router Class Initialized
DEBUG - 2011-06-12 21:56:54 --> Output Class Initialized
DEBUG - 2011-06-12 21:56:55 --> Input Class Initialized
DEBUG - 2011-06-12 21:56:55 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-12 21:56:55 --> Language Class Initialized
DEBUG - 2011-06-12 21:56:55 --> Loader Class Initialized
DEBUG - 2011-06-12 21:56:56 --> Controller Class Initialized
ERROR - 2011-06-12 21:56:56 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-12 21:56:56 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-12 21:56:56 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-12 21:56:56 --> Model Class Initialized
DEBUG - 2011-06-12 21:56:56 --> Model Class Initialized
DEBUG - 2011-06-12 21:56:57 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-12 21:56:57 --> Database Driver Class Initialized
DEBUG - 2011-06-12 21:56:57 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-12 21:56:58 --> Helper loaded: url_helper
DEBUG - 2011-06-12 21:56:58 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-12 21:56:58 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-12 21:56:58 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-12 21:56:58 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-12 21:56:58 --> Final output sent to browser
DEBUG - 2011-06-12 21:56:58 --> Total execution time: 3.9339
DEBUG - 2011-06-12 22:29:59 --> Config Class Initialized
DEBUG - 2011-06-12 22:29:59 --> Hooks Class Initialized
DEBUG - 2011-06-12 22:29:59 --> Utf8 Class Initialized
DEBUG - 2011-06-12 22:29:59 --> UTF-8 Support Enabled
DEBUG - 2011-06-12 22:29:59 --> URI Class Initialized
DEBUG - 2011-06-12 22:29:59 --> Router Class Initialized
DEBUG - 2011-06-12 22:29:59 --> No URI present. Default controller set.
DEBUG - 2011-06-12 22:29:59 --> Output Class Initialized
DEBUG - 2011-06-12 22:29:59 --> Input Class Initialized
DEBUG - 2011-06-12 22:29:59 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-12 22:29:59 --> Language Class Initialized
DEBUG - 2011-06-12 22:29:59 --> Loader Class Initialized
DEBUG - 2011-06-12 22:29:59 --> Controller Class Initialized
DEBUG - 2011-06-12 22:29:59 --> File loaded: application/views/splash/main.php
DEBUG - 2011-06-12 22:29:59 --> Helper loaded: url_helper
DEBUG - 2011-06-12 22:29:59 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-12 22:29:59 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-12 22:29:59 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-12 22:29:59 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-12 22:29:59 --> Final output sent to browser
DEBUG - 2011-06-12 22:29:59 --> Total execution time: 0.1856

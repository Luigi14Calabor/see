<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2011-04-26 00:36:02 --> Config Class Initialized
DEBUG - 2011-04-26 00:36:02 --> Hooks Class Initialized
DEBUG - 2011-04-26 00:36:02 --> Utf8 Class Initialized
DEBUG - 2011-04-26 00:36:02 --> UTF-8 Support Enabled
DEBUG - 2011-04-26 00:36:02 --> URI Class Initialized
DEBUG - 2011-04-26 00:36:02 --> Router Class Initialized
DEBUG - 2011-04-26 00:36:02 --> Output Class Initialized
DEBUG - 2011-04-26 00:36:02 --> Input Class Initialized
DEBUG - 2011-04-26 00:36:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-26 00:36:02 --> Language Class Initialized
DEBUG - 2011-04-26 00:36:02 --> Loader Class Initialized
DEBUG - 2011-04-26 00:36:02 --> Controller Class Initialized
DEBUG - 2011-04-26 00:36:02 --> Model Class Initialized
DEBUG - 2011-04-26 00:36:02 --> Model Class Initialized
DEBUG - 2011-04-26 00:36:02 --> Model Class Initialized
DEBUG - 2011-04-26 00:36:02 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-26 00:36:02 --> Database Driver Class Initialized
DEBUG - 2011-04-26 00:36:03 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-26 00:36:03 --> Helper loaded: url_helper
DEBUG - 2011-04-26 00:36:03 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-26 00:36:03 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-26 00:36:03 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-26 00:36:03 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-26 00:36:03 --> Final output sent to browser
DEBUG - 2011-04-26 00:36:03 --> Total execution time: 1.7026
DEBUG - 2011-04-26 00:55:37 --> Config Class Initialized
DEBUG - 2011-04-26 00:55:37 --> Hooks Class Initialized
DEBUG - 2011-04-26 00:55:37 --> Utf8 Class Initialized
DEBUG - 2011-04-26 00:55:37 --> UTF-8 Support Enabled
DEBUG - 2011-04-26 00:55:37 --> URI Class Initialized
DEBUG - 2011-04-26 00:55:37 --> Router Class Initialized
DEBUG - 2011-04-26 00:55:37 --> Output Class Initialized
DEBUG - 2011-04-26 00:55:37 --> Input Class Initialized
DEBUG - 2011-04-26 00:55:37 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-26 00:55:37 --> Language Class Initialized
DEBUG - 2011-04-26 00:55:37 --> Loader Class Initialized
DEBUG - 2011-04-26 00:55:37 --> Controller Class Initialized
DEBUG - 2011-04-26 00:55:37 --> Model Class Initialized
DEBUG - 2011-04-26 00:55:37 --> Model Class Initialized
DEBUG - 2011-04-26 00:55:37 --> Model Class Initialized
DEBUG - 2011-04-26 00:55:37 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-26 00:55:37 --> Database Driver Class Initialized
DEBUG - 2011-04-26 00:55:37 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-26 00:55:37 --> Helper loaded: url_helper
DEBUG - 2011-04-26 00:55:37 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-26 00:55:37 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-26 00:55:37 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-26 00:55:37 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-26 00:55:37 --> Final output sent to browser
DEBUG - 2011-04-26 00:55:37 --> Total execution time: 0.4408
DEBUG - 2011-04-26 01:13:10 --> Config Class Initialized
DEBUG - 2011-04-26 01:13:10 --> Hooks Class Initialized
DEBUG - 2011-04-26 01:13:10 --> Utf8 Class Initialized
DEBUG - 2011-04-26 01:13:10 --> UTF-8 Support Enabled
DEBUG - 2011-04-26 01:13:10 --> URI Class Initialized
DEBUG - 2011-04-26 01:13:10 --> Router Class Initialized
DEBUG - 2011-04-26 01:13:10 --> Output Class Initialized
DEBUG - 2011-04-26 01:13:10 --> Input Class Initialized
DEBUG - 2011-04-26 01:13:10 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-26 01:13:10 --> Language Class Initialized
DEBUG - 2011-04-26 01:13:10 --> Loader Class Initialized
DEBUG - 2011-04-26 01:13:10 --> Controller Class Initialized
DEBUG - 2011-04-26 01:13:10 --> Model Class Initialized
DEBUG - 2011-04-26 01:13:10 --> Model Class Initialized
DEBUG - 2011-04-26 01:13:10 --> Model Class Initialized
DEBUG - 2011-04-26 01:13:10 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-26 01:13:10 --> Database Driver Class Initialized
DEBUG - 2011-04-26 01:13:11 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-26 01:13:11 --> Helper loaded: url_helper
DEBUG - 2011-04-26 01:13:11 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-26 01:13:11 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-26 01:13:11 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-26 01:13:11 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-26 01:13:11 --> Final output sent to browser
DEBUG - 2011-04-26 01:13:11 --> Total execution time: 0.7887
DEBUG - 2011-04-26 01:13:15 --> Config Class Initialized
DEBUG - 2011-04-26 01:13:15 --> Hooks Class Initialized
DEBUG - 2011-04-26 01:13:15 --> Utf8 Class Initialized
DEBUG - 2011-04-26 01:13:15 --> UTF-8 Support Enabled
DEBUG - 2011-04-26 01:13:15 --> URI Class Initialized
DEBUG - 2011-04-26 01:13:15 --> Router Class Initialized
DEBUG - 2011-04-26 01:13:15 --> Output Class Initialized
DEBUG - 2011-04-26 01:13:15 --> Input Class Initialized
DEBUG - 2011-04-26 01:13:15 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-26 01:13:15 --> Language Class Initialized
DEBUG - 2011-04-26 01:13:15 --> Loader Class Initialized
DEBUG - 2011-04-26 01:13:15 --> Controller Class Initialized
ERROR - 2011-04-26 01:13:15 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-26 01:13:15 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-26 01:13:15 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-26 01:13:15 --> Model Class Initialized
DEBUG - 2011-04-26 01:13:15 --> Model Class Initialized
DEBUG - 2011-04-26 01:13:15 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-26 01:13:15 --> Database Driver Class Initialized
DEBUG - 2011-04-26 01:13:15 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-26 01:13:15 --> Helper loaded: url_helper
DEBUG - 2011-04-26 01:13:15 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-26 01:13:15 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-26 01:13:15 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-26 01:13:15 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-26 01:13:15 --> Final output sent to browser
DEBUG - 2011-04-26 01:13:15 --> Total execution time: 0.1233
DEBUG - 2011-04-26 01:19:24 --> Config Class Initialized
DEBUG - 2011-04-26 01:19:24 --> Hooks Class Initialized
DEBUG - 2011-04-26 01:19:24 --> Utf8 Class Initialized
DEBUG - 2011-04-26 01:19:24 --> UTF-8 Support Enabled
DEBUG - 2011-04-26 01:19:24 --> URI Class Initialized
DEBUG - 2011-04-26 01:19:24 --> Router Class Initialized
DEBUG - 2011-04-26 01:19:24 --> Output Class Initialized
DEBUG - 2011-04-26 01:19:24 --> Input Class Initialized
DEBUG - 2011-04-26 01:19:24 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-26 01:19:24 --> Language Class Initialized
DEBUG - 2011-04-26 01:19:24 --> Loader Class Initialized
DEBUG - 2011-04-26 01:19:24 --> Controller Class Initialized
DEBUG - 2011-04-26 01:19:24 --> Model Class Initialized
DEBUG - 2011-04-26 01:19:24 --> Model Class Initialized
DEBUG - 2011-04-26 01:19:24 --> Model Class Initialized
DEBUG - 2011-04-26 01:19:24 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-26 01:19:24 --> Database Driver Class Initialized
DEBUG - 2011-04-26 01:19:25 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-26 01:19:25 --> Helper loaded: url_helper
DEBUG - 2011-04-26 01:19:25 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-26 01:19:25 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-26 01:19:25 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-26 01:19:25 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-26 01:19:25 --> Final output sent to browser
DEBUG - 2011-04-26 01:19:25 --> Total execution time: 0.2105
DEBUG - 2011-04-26 02:37:41 --> Config Class Initialized
DEBUG - 2011-04-26 02:37:41 --> Hooks Class Initialized
DEBUG - 2011-04-26 02:37:41 --> Utf8 Class Initialized
DEBUG - 2011-04-26 02:37:41 --> UTF-8 Support Enabled
DEBUG - 2011-04-26 02:37:41 --> URI Class Initialized
DEBUG - 2011-04-26 02:37:41 --> Router Class Initialized
DEBUG - 2011-04-26 02:37:42 --> Output Class Initialized
DEBUG - 2011-04-26 02:37:42 --> Input Class Initialized
DEBUG - 2011-04-26 02:37:42 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-26 02:37:42 --> Language Class Initialized
DEBUG - 2011-04-26 02:37:42 --> Loader Class Initialized
DEBUG - 2011-04-26 02:37:42 --> Controller Class Initialized
DEBUG - 2011-04-26 02:37:42 --> Model Class Initialized
DEBUG - 2011-04-26 02:37:42 --> Model Class Initialized
DEBUG - 2011-04-26 02:37:42 --> Model Class Initialized
DEBUG - 2011-04-26 02:37:42 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-26 02:37:43 --> Database Driver Class Initialized
DEBUG - 2011-04-26 02:38:09 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-26 02:38:09 --> Helper loaded: url_helper
DEBUG - 2011-04-26 02:38:09 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-26 02:38:09 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-26 02:38:09 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-26 02:38:09 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-26 02:38:09 --> Final output sent to browser
DEBUG - 2011-04-26 02:38:09 --> Total execution time: 27.3559
DEBUG - 2011-04-26 02:38:11 --> Config Class Initialized
DEBUG - 2011-04-26 02:38:11 --> Hooks Class Initialized
DEBUG - 2011-04-26 02:38:11 --> Utf8 Class Initialized
DEBUG - 2011-04-26 02:38:11 --> UTF-8 Support Enabled
DEBUG - 2011-04-26 02:38:11 --> URI Class Initialized
DEBUG - 2011-04-26 02:38:11 --> Router Class Initialized
DEBUG - 2011-04-26 02:38:11 --> Output Class Initialized
DEBUG - 2011-04-26 02:38:11 --> Input Class Initialized
DEBUG - 2011-04-26 02:38:11 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-26 02:38:11 --> Language Class Initialized
DEBUG - 2011-04-26 02:38:11 --> Loader Class Initialized
DEBUG - 2011-04-26 02:38:11 --> Controller Class Initialized
ERROR - 2011-04-26 02:38:11 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-26 02:38:11 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-26 02:38:11 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-26 02:38:11 --> Model Class Initialized
DEBUG - 2011-04-26 02:38:11 --> Model Class Initialized
DEBUG - 2011-04-26 02:38:11 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-26 02:38:11 --> Database Driver Class Initialized
DEBUG - 2011-04-26 02:38:11 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-26 02:38:11 --> Helper loaded: url_helper
DEBUG - 2011-04-26 02:38:11 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-26 02:38:11 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-26 02:38:11 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-26 02:38:11 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-26 02:38:11 --> Final output sent to browser
DEBUG - 2011-04-26 02:38:11 --> Total execution time: 0.1569
DEBUG - 2011-04-26 03:31:22 --> Config Class Initialized
DEBUG - 2011-04-26 03:31:22 --> Hooks Class Initialized
DEBUG - 2011-04-26 03:31:22 --> Utf8 Class Initialized
DEBUG - 2011-04-26 03:31:22 --> UTF-8 Support Enabled
DEBUG - 2011-04-26 03:31:22 --> URI Class Initialized
DEBUG - 2011-04-26 03:31:22 --> Router Class Initialized
DEBUG - 2011-04-26 03:31:22 --> No URI present. Default controller set.
DEBUG - 2011-04-26 03:31:22 --> Output Class Initialized
DEBUG - 2011-04-26 03:31:22 --> Input Class Initialized
DEBUG - 2011-04-26 03:31:22 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-26 03:31:22 --> Language Class Initialized
DEBUG - 2011-04-26 03:31:22 --> Loader Class Initialized
DEBUG - 2011-04-26 03:31:22 --> Controller Class Initialized
DEBUG - 2011-04-26 03:31:22 --> File loaded: application/views/splash/main.php
DEBUG - 2011-04-26 03:31:22 --> Helper loaded: url_helper
DEBUG - 2011-04-26 03:31:22 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-26 03:31:22 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-26 03:31:22 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-26 03:31:22 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-26 03:31:22 --> Final output sent to browser
DEBUG - 2011-04-26 03:31:22 --> Total execution time: 0.1536
DEBUG - 2011-04-26 04:25:38 --> Config Class Initialized
DEBUG - 2011-04-26 04:25:38 --> Hooks Class Initialized
DEBUG - 2011-04-26 04:25:38 --> Utf8 Class Initialized
DEBUG - 2011-04-26 04:25:38 --> UTF-8 Support Enabled
DEBUG - 2011-04-26 04:25:38 --> URI Class Initialized
DEBUG - 2011-04-26 04:25:38 --> Router Class Initialized
DEBUG - 2011-04-26 04:25:39 --> Output Class Initialized
DEBUG - 2011-04-26 04:25:39 --> Input Class Initialized
DEBUG - 2011-04-26 04:25:39 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-26 04:25:39 --> Language Class Initialized
DEBUG - 2011-04-26 04:25:39 --> Loader Class Initialized
DEBUG - 2011-04-26 04:25:39 --> Controller Class Initialized
DEBUG - 2011-04-26 04:25:39 --> Model Class Initialized
DEBUG - 2011-04-26 04:25:39 --> Model Class Initialized
DEBUG - 2011-04-26 04:25:39 --> Model Class Initialized
DEBUG - 2011-04-26 04:25:39 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-26 04:25:39 --> Database Driver Class Initialized
DEBUG - 2011-04-26 04:25:41 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-26 04:25:41 --> Helper loaded: url_helper
DEBUG - 2011-04-26 04:25:41 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-26 04:25:41 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-26 04:25:41 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-26 04:25:41 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-26 04:25:41 --> Final output sent to browser
DEBUG - 2011-04-26 04:25:41 --> Total execution time: 2.5275
DEBUG - 2011-04-26 04:25:42 --> Config Class Initialized
DEBUG - 2011-04-26 04:25:42 --> Hooks Class Initialized
DEBUG - 2011-04-26 04:25:42 --> Utf8 Class Initialized
DEBUG - 2011-04-26 04:25:42 --> UTF-8 Support Enabled
DEBUG - 2011-04-26 04:25:42 --> URI Class Initialized
DEBUG - 2011-04-26 04:25:42 --> Router Class Initialized
DEBUG - 2011-04-26 04:25:42 --> Output Class Initialized
DEBUG - 2011-04-26 04:25:42 --> Input Class Initialized
DEBUG - 2011-04-26 04:25:42 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-26 04:25:42 --> Language Class Initialized
DEBUG - 2011-04-26 04:25:42 --> Loader Class Initialized
DEBUG - 2011-04-26 04:25:42 --> Controller Class Initialized
ERROR - 2011-04-26 04:25:43 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-26 04:25:43 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-26 04:25:43 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-26 04:25:43 --> Model Class Initialized
DEBUG - 2011-04-26 04:25:43 --> Model Class Initialized
DEBUG - 2011-04-26 04:25:43 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-26 04:25:43 --> Database Driver Class Initialized
DEBUG - 2011-04-26 04:25:43 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-26 04:25:43 --> Helper loaded: url_helper
DEBUG - 2011-04-26 04:25:43 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-26 04:25:43 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-26 04:25:43 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-26 04:25:43 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-26 04:25:43 --> Final output sent to browser
DEBUG - 2011-04-26 04:25:43 --> Total execution time: 0.5491
DEBUG - 2011-04-26 05:02:50 --> Config Class Initialized
DEBUG - 2011-04-26 05:02:50 --> Hooks Class Initialized
DEBUG - 2011-04-26 05:02:50 --> Utf8 Class Initialized
DEBUG - 2011-04-26 05:02:50 --> UTF-8 Support Enabled
DEBUG - 2011-04-26 05:02:50 --> URI Class Initialized
DEBUG - 2011-04-26 05:02:50 --> Router Class Initialized
DEBUG - 2011-04-26 05:02:50 --> No URI present. Default controller set.
DEBUG - 2011-04-26 05:02:50 --> Output Class Initialized
DEBUG - 2011-04-26 05:02:50 --> Input Class Initialized
DEBUG - 2011-04-26 05:02:50 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-26 05:02:50 --> Language Class Initialized
DEBUG - 2011-04-26 05:02:50 --> Loader Class Initialized
DEBUG - 2011-04-26 05:02:50 --> Controller Class Initialized
DEBUG - 2011-04-26 05:02:50 --> File loaded: application/views/splash/main.php
DEBUG - 2011-04-26 05:02:50 --> Helper loaded: url_helper
DEBUG - 2011-04-26 05:02:50 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-26 05:02:50 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-26 05:02:50 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-26 05:02:50 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-26 05:02:50 --> Final output sent to browser
DEBUG - 2011-04-26 05:02:50 --> Total execution time: 0.2488
DEBUG - 2011-04-26 05:02:52 --> Config Class Initialized
DEBUG - 2011-04-26 05:02:52 --> Hooks Class Initialized
DEBUG - 2011-04-26 05:02:52 --> Utf8 Class Initialized
DEBUG - 2011-04-26 05:02:52 --> UTF-8 Support Enabled
DEBUG - 2011-04-26 05:02:52 --> URI Class Initialized
DEBUG - 2011-04-26 05:02:52 --> Router Class Initialized
ERROR - 2011-04-26 05:02:52 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-26 05:02:53 --> Config Class Initialized
DEBUG - 2011-04-26 05:02:53 --> Hooks Class Initialized
DEBUG - 2011-04-26 05:02:53 --> Utf8 Class Initialized
DEBUG - 2011-04-26 05:02:53 --> UTF-8 Support Enabled
DEBUG - 2011-04-26 05:02:53 --> URI Class Initialized
DEBUG - 2011-04-26 05:02:53 --> Router Class Initialized
ERROR - 2011-04-26 05:02:53 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-26 05:02:54 --> Config Class Initialized
DEBUG - 2011-04-26 05:02:54 --> Hooks Class Initialized
DEBUG - 2011-04-26 05:02:54 --> Utf8 Class Initialized
DEBUG - 2011-04-26 05:02:54 --> UTF-8 Support Enabled
DEBUG - 2011-04-26 05:02:54 --> URI Class Initialized
DEBUG - 2011-04-26 05:02:54 --> Router Class Initialized
ERROR - 2011-04-26 05:02:54 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-26 05:02:57 --> Config Class Initialized
DEBUG - 2011-04-26 05:02:57 --> Hooks Class Initialized
DEBUG - 2011-04-26 05:02:57 --> Utf8 Class Initialized
DEBUG - 2011-04-26 05:02:57 --> UTF-8 Support Enabled
DEBUG - 2011-04-26 05:02:57 --> URI Class Initialized
DEBUG - 2011-04-26 05:02:57 --> Router Class Initialized
DEBUG - 2011-04-26 05:02:57 --> No URI present. Default controller set.
DEBUG - 2011-04-26 05:02:57 --> Output Class Initialized
DEBUG - 2011-04-26 05:02:57 --> Input Class Initialized
DEBUG - 2011-04-26 05:02:57 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-26 05:02:57 --> Language Class Initialized
DEBUG - 2011-04-26 05:02:57 --> Loader Class Initialized
DEBUG - 2011-04-26 05:02:57 --> Controller Class Initialized
DEBUG - 2011-04-26 05:02:57 --> File loaded: application/views/splash/main.php
DEBUG - 2011-04-26 05:02:57 --> Helper loaded: url_helper
DEBUG - 2011-04-26 05:02:57 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-26 05:02:57 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-26 05:02:57 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-26 05:02:57 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-26 05:02:57 --> Final output sent to browser
DEBUG - 2011-04-26 05:02:57 --> Total execution time: 0.0139
DEBUG - 2011-04-26 05:21:53 --> Config Class Initialized
DEBUG - 2011-04-26 05:21:53 --> Hooks Class Initialized
DEBUG - 2011-04-26 05:21:53 --> Utf8 Class Initialized
DEBUG - 2011-04-26 05:21:53 --> UTF-8 Support Enabled
DEBUG - 2011-04-26 05:21:53 --> URI Class Initialized
DEBUG - 2011-04-26 05:21:53 --> Router Class Initialized
DEBUG - 2011-04-26 05:21:53 --> Output Class Initialized
DEBUG - 2011-04-26 05:21:53 --> Input Class Initialized
DEBUG - 2011-04-26 05:21:53 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-26 05:21:53 --> Language Class Initialized
DEBUG - 2011-04-26 05:21:53 --> Loader Class Initialized
DEBUG - 2011-04-26 05:21:53 --> Controller Class Initialized
DEBUG - 2011-04-26 05:21:53 --> Model Class Initialized
DEBUG - 2011-04-26 05:21:53 --> Model Class Initialized
DEBUG - 2011-04-26 05:21:53 --> Model Class Initialized
DEBUG - 2011-04-26 05:21:53 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-26 05:21:53 --> Database Driver Class Initialized
DEBUG - 2011-04-26 05:21:53 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-26 05:21:53 --> Helper loaded: url_helper
DEBUG - 2011-04-26 05:21:53 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-26 05:21:53 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-26 05:21:53 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-26 05:21:53 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-26 05:21:53 --> Final output sent to browser
DEBUG - 2011-04-26 05:21:53 --> Total execution time: 0.5587
DEBUG - 2011-04-26 05:21:54 --> Config Class Initialized
DEBUG - 2011-04-26 05:21:54 --> Hooks Class Initialized
DEBUG - 2011-04-26 05:21:54 --> Utf8 Class Initialized
DEBUG - 2011-04-26 05:21:54 --> UTF-8 Support Enabled
DEBUG - 2011-04-26 05:21:54 --> URI Class Initialized
DEBUG - 2011-04-26 05:21:54 --> Router Class Initialized
DEBUG - 2011-04-26 05:21:54 --> Output Class Initialized
DEBUG - 2011-04-26 05:21:54 --> Input Class Initialized
DEBUG - 2011-04-26 05:21:54 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-26 05:21:54 --> Language Class Initialized
DEBUG - 2011-04-26 05:21:54 --> Loader Class Initialized
DEBUG - 2011-04-26 05:21:54 --> Controller Class Initialized
ERROR - 2011-04-26 05:21:54 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-26 05:21:54 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-26 05:21:54 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-26 05:21:54 --> Model Class Initialized
DEBUG - 2011-04-26 05:21:54 --> Model Class Initialized
DEBUG - 2011-04-26 05:21:54 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-26 05:21:54 --> Database Driver Class Initialized
DEBUG - 2011-04-26 05:21:54 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-26 05:21:54 --> Helper loaded: url_helper
DEBUG - 2011-04-26 05:21:54 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-26 05:21:54 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-26 05:21:54 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-26 05:21:54 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-26 05:21:54 --> Final output sent to browser
DEBUG - 2011-04-26 05:21:54 --> Total execution time: 0.0930
DEBUG - 2011-04-26 06:09:57 --> Config Class Initialized
DEBUG - 2011-04-26 06:09:57 --> Hooks Class Initialized
DEBUG - 2011-04-26 06:09:57 --> Utf8 Class Initialized
DEBUG - 2011-04-26 06:09:57 --> UTF-8 Support Enabled
DEBUG - 2011-04-26 06:09:57 --> URI Class Initialized
DEBUG - 2011-04-26 06:09:57 --> Router Class Initialized
DEBUG - 2011-04-26 06:09:57 --> Output Class Initialized
DEBUG - 2011-04-26 06:09:57 --> Input Class Initialized
DEBUG - 2011-04-26 06:09:57 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-26 06:09:57 --> Language Class Initialized
DEBUG - 2011-04-26 06:09:57 --> Loader Class Initialized
DEBUG - 2011-04-26 06:09:57 --> Controller Class Initialized
ERROR - 2011-04-26 06:09:57 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-26 06:09:57 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-26 06:09:57 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-26 06:09:57 --> Model Class Initialized
DEBUG - 2011-04-26 06:09:57 --> Model Class Initialized
DEBUG - 2011-04-26 06:09:57 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-26 06:09:57 --> Database Driver Class Initialized
DEBUG - 2011-04-26 06:09:57 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-26 06:09:57 --> Helper loaded: url_helper
DEBUG - 2011-04-26 06:09:57 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-26 06:09:57 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-26 06:09:58 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-26 06:09:58 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-26 06:09:58 --> Final output sent to browser
DEBUG - 2011-04-26 06:09:58 --> Total execution time: 0.5981
DEBUG - 2011-04-26 06:09:59 --> Config Class Initialized
DEBUG - 2011-04-26 06:09:59 --> Hooks Class Initialized
DEBUG - 2011-04-26 06:09:59 --> Utf8 Class Initialized
DEBUG - 2011-04-26 06:09:59 --> UTF-8 Support Enabled
DEBUG - 2011-04-26 06:09:59 --> URI Class Initialized
DEBUG - 2011-04-26 06:09:59 --> Router Class Initialized
DEBUG - 2011-04-26 06:09:59 --> Output Class Initialized
DEBUG - 2011-04-26 06:09:59 --> Input Class Initialized
DEBUG - 2011-04-26 06:09:59 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-26 06:09:59 --> Language Class Initialized
DEBUG - 2011-04-26 06:09:59 --> Loader Class Initialized
DEBUG - 2011-04-26 06:09:59 --> Controller Class Initialized
DEBUG - 2011-04-26 06:09:59 --> Model Class Initialized
DEBUG - 2011-04-26 06:09:59 --> Model Class Initialized
DEBUG - 2011-04-26 06:09:59 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-26 06:09:59 --> Database Driver Class Initialized
DEBUG - 2011-04-26 06:10:00 --> Final output sent to browser
DEBUG - 2011-04-26 06:10:00 --> Total execution time: 0.6100
DEBUG - 2011-04-26 06:10:21 --> Config Class Initialized
DEBUG - 2011-04-26 06:10:21 --> Hooks Class Initialized
DEBUG - 2011-04-26 06:10:21 --> Utf8 Class Initialized
DEBUG - 2011-04-26 06:10:21 --> UTF-8 Support Enabled
DEBUG - 2011-04-26 06:10:21 --> URI Class Initialized
DEBUG - 2011-04-26 06:10:21 --> Router Class Initialized
DEBUG - 2011-04-26 06:10:21 --> Output Class Initialized
DEBUG - 2011-04-26 06:10:21 --> Input Class Initialized
DEBUG - 2011-04-26 06:10:21 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-26 06:10:21 --> Language Class Initialized
DEBUG - 2011-04-26 06:10:21 --> Loader Class Initialized
DEBUG - 2011-04-26 06:10:21 --> Controller Class Initialized
ERROR - 2011-04-26 06:10:21 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-26 06:10:21 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-26 06:10:21 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-26 06:10:21 --> Model Class Initialized
DEBUG - 2011-04-26 06:10:21 --> Model Class Initialized
DEBUG - 2011-04-26 06:10:21 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-26 06:10:21 --> Database Driver Class Initialized
DEBUG - 2011-04-26 06:10:21 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-26 06:10:21 --> Helper loaded: url_helper
DEBUG - 2011-04-26 06:10:21 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-26 06:10:21 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-26 06:10:21 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-26 06:10:21 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-26 06:10:21 --> Final output sent to browser
DEBUG - 2011-04-26 06:10:21 --> Total execution time: 0.5869
DEBUG - 2011-04-26 06:10:22 --> Config Class Initialized
DEBUG - 2011-04-26 06:10:22 --> Hooks Class Initialized
DEBUG - 2011-04-26 06:10:22 --> Utf8 Class Initialized
DEBUG - 2011-04-26 06:10:22 --> UTF-8 Support Enabled
DEBUG - 2011-04-26 06:10:22 --> URI Class Initialized
DEBUG - 2011-04-26 06:10:22 --> Router Class Initialized
DEBUG - 2011-04-26 06:10:22 --> Output Class Initialized
DEBUG - 2011-04-26 06:10:22 --> Input Class Initialized
DEBUG - 2011-04-26 06:10:22 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-26 06:10:22 --> Language Class Initialized
DEBUG - 2011-04-26 06:10:22 --> Loader Class Initialized
DEBUG - 2011-04-26 06:10:22 --> Controller Class Initialized
DEBUG - 2011-04-26 06:10:22 --> Model Class Initialized
DEBUG - 2011-04-26 06:10:22 --> Model Class Initialized
DEBUG - 2011-04-26 06:10:22 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-26 06:10:22 --> Database Driver Class Initialized
DEBUG - 2011-04-26 06:10:25 --> Final output sent to browser
DEBUG - 2011-04-26 06:10:25 --> Total execution time: 2.8287
DEBUG - 2011-04-26 06:46:04 --> Config Class Initialized
DEBUG - 2011-04-26 06:46:04 --> Hooks Class Initialized
DEBUG - 2011-04-26 06:46:04 --> Utf8 Class Initialized
DEBUG - 2011-04-26 06:46:04 --> UTF-8 Support Enabled
DEBUG - 2011-04-26 06:46:04 --> URI Class Initialized
DEBUG - 2011-04-26 06:46:04 --> Router Class Initialized
DEBUG - 2011-04-26 06:46:04 --> No URI present. Default controller set.
DEBUG - 2011-04-26 06:46:04 --> Output Class Initialized
DEBUG - 2011-04-26 06:46:04 --> Input Class Initialized
DEBUG - 2011-04-26 06:46:04 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-26 06:46:04 --> Language Class Initialized
DEBUG - 2011-04-26 06:46:04 --> Loader Class Initialized
DEBUG - 2011-04-26 06:46:04 --> Controller Class Initialized
DEBUG - 2011-04-26 06:46:04 --> File loaded: application/views/splash/main.php
DEBUG - 2011-04-26 06:46:04 --> Helper loaded: url_helper
DEBUG - 2011-04-26 06:46:04 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-26 06:46:04 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-26 06:46:04 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-26 06:46:04 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-26 06:46:04 --> Final output sent to browser
DEBUG - 2011-04-26 06:46:04 --> Total execution time: 0.2157
DEBUG - 2011-04-26 06:46:06 --> Config Class Initialized
DEBUG - 2011-04-26 06:46:06 --> Hooks Class Initialized
DEBUG - 2011-04-26 06:46:06 --> Utf8 Class Initialized
DEBUG - 2011-04-26 06:46:06 --> UTF-8 Support Enabled
DEBUG - 2011-04-26 06:46:06 --> URI Class Initialized
DEBUG - 2011-04-26 06:46:06 --> Router Class Initialized
ERROR - 2011-04-26 06:46:06 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-26 06:46:09 --> Config Class Initialized
DEBUG - 2011-04-26 06:46:09 --> Hooks Class Initialized
DEBUG - 2011-04-26 06:46:09 --> Utf8 Class Initialized
DEBUG - 2011-04-26 06:46:09 --> UTF-8 Support Enabled
DEBUG - 2011-04-26 06:46:09 --> URI Class Initialized
DEBUG - 2011-04-26 06:46:09 --> Router Class Initialized
DEBUG - 2011-04-26 06:46:09 --> Output Class Initialized
DEBUG - 2011-04-26 06:46:09 --> Input Class Initialized
DEBUG - 2011-04-26 06:46:09 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-26 06:46:09 --> Language Class Initialized
DEBUG - 2011-04-26 06:46:09 --> Loader Class Initialized
DEBUG - 2011-04-26 06:46:09 --> Controller Class Initialized
ERROR - 2011-04-26 06:46:09 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-26 06:46:09 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-26 06:46:09 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-26 06:46:09 --> Model Class Initialized
DEBUG - 2011-04-26 06:46:09 --> Model Class Initialized
DEBUG - 2011-04-26 06:46:09 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-26 06:46:09 --> Database Driver Class Initialized
DEBUG - 2011-04-26 06:46:09 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-26 06:46:09 --> Helper loaded: url_helper
DEBUG - 2011-04-26 06:46:09 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-26 06:46:09 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-26 06:46:09 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-26 06:46:09 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-26 06:46:09 --> Final output sent to browser
DEBUG - 2011-04-26 06:46:09 --> Total execution time: 0.3499
DEBUG - 2011-04-26 06:46:10 --> Config Class Initialized
DEBUG - 2011-04-26 06:46:10 --> Hooks Class Initialized
DEBUG - 2011-04-26 06:46:10 --> Utf8 Class Initialized
DEBUG - 2011-04-26 06:46:10 --> UTF-8 Support Enabled
DEBUG - 2011-04-26 06:46:10 --> URI Class Initialized
DEBUG - 2011-04-26 06:46:10 --> Router Class Initialized
DEBUG - 2011-04-26 06:46:10 --> Output Class Initialized
DEBUG - 2011-04-26 06:46:10 --> Input Class Initialized
DEBUG - 2011-04-26 06:46:10 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-26 06:46:10 --> Language Class Initialized
DEBUG - 2011-04-26 06:46:10 --> Loader Class Initialized
DEBUG - 2011-04-26 06:46:10 --> Controller Class Initialized
DEBUG - 2011-04-26 06:46:10 --> Model Class Initialized
DEBUG - 2011-04-26 06:46:10 --> Model Class Initialized
DEBUG - 2011-04-26 06:46:10 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-26 06:46:10 --> Database Driver Class Initialized
DEBUG - 2011-04-26 06:46:11 --> Final output sent to browser
DEBUG - 2011-04-26 06:46:11 --> Total execution time: 1.0903
DEBUG - 2011-04-26 06:55:25 --> Config Class Initialized
DEBUG - 2011-04-26 06:55:25 --> Hooks Class Initialized
DEBUG - 2011-04-26 06:55:25 --> Utf8 Class Initialized
DEBUG - 2011-04-26 06:55:25 --> UTF-8 Support Enabled
DEBUG - 2011-04-26 06:55:25 --> URI Class Initialized
DEBUG - 2011-04-26 06:55:25 --> Router Class Initialized
DEBUG - 2011-04-26 06:55:25 --> Output Class Initialized
DEBUG - 2011-04-26 06:55:25 --> Input Class Initialized
DEBUG - 2011-04-26 06:55:25 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-26 06:55:25 --> Language Class Initialized
DEBUG - 2011-04-26 06:55:25 --> Loader Class Initialized
DEBUG - 2011-04-26 06:55:25 --> Controller Class Initialized
DEBUG - 2011-04-26 06:55:25 --> Model Class Initialized
DEBUG - 2011-04-26 06:55:25 --> Model Class Initialized
DEBUG - 2011-04-26 06:55:25 --> Model Class Initialized
DEBUG - 2011-04-26 06:55:25 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-26 06:55:25 --> Database Driver Class Initialized
DEBUG - 2011-04-26 06:55:26 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-26 06:55:26 --> Helper loaded: url_helper
DEBUG - 2011-04-26 06:55:26 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-26 06:55:26 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-26 06:55:26 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-26 06:55:26 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-26 06:55:26 --> Final output sent to browser
DEBUG - 2011-04-26 06:55:26 --> Total execution time: 2.3836
DEBUG - 2011-04-26 06:55:29 --> Config Class Initialized
DEBUG - 2011-04-26 06:55:29 --> Hooks Class Initialized
DEBUG - 2011-04-26 06:55:29 --> Utf8 Class Initialized
DEBUG - 2011-04-26 06:55:29 --> UTF-8 Support Enabled
DEBUG - 2011-04-26 06:55:29 --> URI Class Initialized
DEBUG - 2011-04-26 06:55:29 --> Router Class Initialized
ERROR - 2011-04-26 06:55:29 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-26 06:55:30 --> Config Class Initialized
DEBUG - 2011-04-26 06:55:30 --> Hooks Class Initialized
DEBUG - 2011-04-26 06:55:30 --> Utf8 Class Initialized
DEBUG - 2011-04-26 06:55:30 --> UTF-8 Support Enabled
DEBUG - 2011-04-26 06:55:30 --> URI Class Initialized
DEBUG - 2011-04-26 06:55:30 --> Router Class Initialized
ERROR - 2011-04-26 06:55:30 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-26 06:55:33 --> Config Class Initialized
DEBUG - 2011-04-26 06:55:33 --> Hooks Class Initialized
DEBUG - 2011-04-26 06:55:33 --> Utf8 Class Initialized
DEBUG - 2011-04-26 06:55:33 --> UTF-8 Support Enabled
DEBUG - 2011-04-26 06:55:33 --> URI Class Initialized
DEBUG - 2011-04-26 06:55:33 --> Router Class Initialized
DEBUG - 2011-04-26 06:55:33 --> Output Class Initialized
DEBUG - 2011-04-26 06:55:33 --> Input Class Initialized
DEBUG - 2011-04-26 06:55:33 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-26 06:55:33 --> Language Class Initialized
DEBUG - 2011-04-26 06:55:33 --> Loader Class Initialized
DEBUG - 2011-04-26 06:55:33 --> Controller Class Initialized
DEBUG - 2011-04-26 06:55:33 --> Model Class Initialized
DEBUG - 2011-04-26 06:55:33 --> Model Class Initialized
DEBUG - 2011-04-26 06:55:33 --> Model Class Initialized
DEBUG - 2011-04-26 06:55:33 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-26 06:55:33 --> Database Driver Class Initialized
DEBUG - 2011-04-26 06:55:33 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-26 06:55:33 --> Helper loaded: url_helper
DEBUG - 2011-04-26 06:55:33 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-26 06:55:33 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-26 06:55:33 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-26 06:55:33 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-26 06:55:33 --> Final output sent to browser
DEBUG - 2011-04-26 06:55:33 --> Total execution time: 0.0486
DEBUG - 2011-04-26 06:55:38 --> Config Class Initialized
DEBUG - 2011-04-26 06:55:38 --> Hooks Class Initialized
DEBUG - 2011-04-26 06:55:38 --> Utf8 Class Initialized
DEBUG - 2011-04-26 06:55:38 --> UTF-8 Support Enabled
DEBUG - 2011-04-26 06:55:38 --> URI Class Initialized
DEBUG - 2011-04-26 06:55:38 --> Router Class Initialized
DEBUG - 2011-04-26 06:55:38 --> Output Class Initialized
DEBUG - 2011-04-26 06:55:38 --> Input Class Initialized
DEBUG - 2011-04-26 06:55:38 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-26 06:55:38 --> Language Class Initialized
DEBUG - 2011-04-26 06:55:38 --> Loader Class Initialized
DEBUG - 2011-04-26 06:55:38 --> Controller Class Initialized
DEBUG - 2011-04-26 06:55:38 --> Model Class Initialized
DEBUG - 2011-04-26 06:55:38 --> Model Class Initialized
DEBUG - 2011-04-26 06:55:38 --> Model Class Initialized
DEBUG - 2011-04-26 06:55:38 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-26 06:55:38 --> Database Driver Class Initialized
DEBUG - 2011-04-26 06:55:38 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-26 06:55:38 --> Helper loaded: url_helper
DEBUG - 2011-04-26 06:55:38 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-26 06:55:38 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-26 06:55:38 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-26 06:55:38 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-26 06:55:38 --> Final output sent to browser
DEBUG - 2011-04-26 06:55:38 --> Total execution time: 0.0523
DEBUG - 2011-04-26 06:55:51 --> Config Class Initialized
DEBUG - 2011-04-26 06:55:51 --> Hooks Class Initialized
DEBUG - 2011-04-26 06:55:51 --> Utf8 Class Initialized
DEBUG - 2011-04-26 06:55:51 --> UTF-8 Support Enabled
DEBUG - 2011-04-26 06:55:51 --> URI Class Initialized
DEBUG - 2011-04-26 06:55:51 --> Router Class Initialized
DEBUG - 2011-04-26 06:55:51 --> Output Class Initialized
DEBUG - 2011-04-26 06:55:51 --> Input Class Initialized
DEBUG - 2011-04-26 06:55:51 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-26 06:55:51 --> Language Class Initialized
DEBUG - 2011-04-26 06:55:51 --> Loader Class Initialized
DEBUG - 2011-04-26 06:55:51 --> Controller Class Initialized
DEBUG - 2011-04-26 06:55:51 --> Model Class Initialized
DEBUG - 2011-04-26 06:55:51 --> Model Class Initialized
DEBUG - 2011-04-26 06:55:51 --> Model Class Initialized
DEBUG - 2011-04-26 06:55:51 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-26 06:55:51 --> Database Driver Class Initialized
DEBUG - 2011-04-26 06:55:51 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-26 06:55:51 --> Helper loaded: url_helper
DEBUG - 2011-04-26 06:55:51 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-26 06:55:51 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-26 06:55:51 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-26 06:55:51 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-26 06:55:51 --> Final output sent to browser
DEBUG - 2011-04-26 06:55:51 --> Total execution time: 0.1772
DEBUG - 2011-04-26 06:55:53 --> Config Class Initialized
DEBUG - 2011-04-26 06:55:53 --> Hooks Class Initialized
DEBUG - 2011-04-26 06:55:53 --> Utf8 Class Initialized
DEBUG - 2011-04-26 06:55:53 --> UTF-8 Support Enabled
DEBUG - 2011-04-26 06:55:53 --> URI Class Initialized
DEBUG - 2011-04-26 06:55:53 --> Router Class Initialized
ERROR - 2011-04-26 06:55:53 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-04-26 06:55:53 --> Config Class Initialized
DEBUG - 2011-04-26 06:55:53 --> Hooks Class Initialized
DEBUG - 2011-04-26 06:55:53 --> Utf8 Class Initialized
DEBUG - 2011-04-26 06:55:53 --> UTF-8 Support Enabled
DEBUG - 2011-04-26 06:55:53 --> URI Class Initialized
DEBUG - 2011-04-26 06:55:53 --> Router Class Initialized
DEBUG - 2011-04-26 06:55:53 --> Output Class Initialized
DEBUG - 2011-04-26 06:55:53 --> Input Class Initialized
DEBUG - 2011-04-26 06:55:53 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-26 06:55:53 --> Language Class Initialized
DEBUG - 2011-04-26 06:55:53 --> Loader Class Initialized
DEBUG - 2011-04-26 06:55:53 --> Controller Class Initialized
DEBUG - 2011-04-26 06:55:53 --> Model Class Initialized
DEBUG - 2011-04-26 06:55:53 --> Model Class Initialized
DEBUG - 2011-04-26 06:55:53 --> Model Class Initialized
DEBUG - 2011-04-26 06:55:53 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-26 06:55:53 --> Database Driver Class Initialized
DEBUG - 2011-04-26 06:55:53 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-26 06:55:53 --> Helper loaded: url_helper
DEBUG - 2011-04-26 06:55:53 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-26 06:55:53 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-26 06:55:53 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-26 06:55:53 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-26 06:55:53 --> Final output sent to browser
DEBUG - 2011-04-26 06:55:53 --> Total execution time: 0.0473
DEBUG - 2011-04-26 06:56:19 --> Config Class Initialized
DEBUG - 2011-04-26 06:56:19 --> Hooks Class Initialized
DEBUG - 2011-04-26 06:56:19 --> Utf8 Class Initialized
DEBUG - 2011-04-26 06:56:19 --> UTF-8 Support Enabled
DEBUG - 2011-04-26 06:56:19 --> URI Class Initialized
DEBUG - 2011-04-26 06:56:19 --> Router Class Initialized
DEBUG - 2011-04-26 06:56:19 --> Output Class Initialized
DEBUG - 2011-04-26 06:56:19 --> Input Class Initialized
DEBUG - 2011-04-26 06:56:19 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-26 06:56:19 --> Language Class Initialized
DEBUG - 2011-04-26 06:56:19 --> Loader Class Initialized
DEBUG - 2011-04-26 06:56:19 --> Controller Class Initialized
DEBUG - 2011-04-26 06:56:19 --> Model Class Initialized
DEBUG - 2011-04-26 06:56:19 --> Model Class Initialized
DEBUG - 2011-04-26 06:56:19 --> Model Class Initialized
DEBUG - 2011-04-26 06:56:19 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-26 06:56:19 --> Database Driver Class Initialized
DEBUG - 2011-04-26 06:56:19 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-26 06:56:19 --> Helper loaded: url_helper
DEBUG - 2011-04-26 06:56:19 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-26 06:56:19 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-26 06:56:19 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-26 06:56:19 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-26 06:56:19 --> Final output sent to browser
DEBUG - 2011-04-26 06:56:19 --> Total execution time: 0.2401
DEBUG - 2011-04-26 06:56:28 --> Config Class Initialized
DEBUG - 2011-04-26 06:56:28 --> Hooks Class Initialized
DEBUG - 2011-04-26 06:56:28 --> Utf8 Class Initialized
DEBUG - 2011-04-26 06:56:28 --> UTF-8 Support Enabled
DEBUG - 2011-04-26 06:56:28 --> URI Class Initialized
DEBUG - 2011-04-26 06:56:28 --> Router Class Initialized
DEBUG - 2011-04-26 06:56:28 --> Output Class Initialized
DEBUG - 2011-04-26 06:56:28 --> Input Class Initialized
DEBUG - 2011-04-26 06:56:28 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-26 06:56:28 --> Language Class Initialized
DEBUG - 2011-04-26 06:56:28 --> Loader Class Initialized
DEBUG - 2011-04-26 06:56:28 --> Controller Class Initialized
DEBUG - 2011-04-26 06:56:28 --> Model Class Initialized
DEBUG - 2011-04-26 06:56:28 --> Model Class Initialized
DEBUG - 2011-04-26 06:56:28 --> Model Class Initialized
DEBUG - 2011-04-26 06:56:28 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-26 06:56:28 --> Database Driver Class Initialized
DEBUG - 2011-04-26 06:56:28 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-26 06:56:28 --> Helper loaded: url_helper
DEBUG - 2011-04-26 06:56:28 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-26 06:56:28 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-26 06:56:28 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-26 06:56:28 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-26 06:56:28 --> Final output sent to browser
DEBUG - 2011-04-26 06:56:28 --> Total execution time: 0.1320
DEBUG - 2011-04-26 06:59:55 --> Config Class Initialized
DEBUG - 2011-04-26 06:59:55 --> Hooks Class Initialized
DEBUG - 2011-04-26 06:59:55 --> Utf8 Class Initialized
DEBUG - 2011-04-26 06:59:55 --> UTF-8 Support Enabled
DEBUG - 2011-04-26 06:59:55 --> URI Class Initialized
DEBUG - 2011-04-26 06:59:55 --> Router Class Initialized
DEBUG - 2011-04-26 06:59:55 --> Output Class Initialized
DEBUG - 2011-04-26 06:59:55 --> Input Class Initialized
DEBUG - 2011-04-26 06:59:55 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-26 06:59:55 --> Language Class Initialized
DEBUG - 2011-04-26 06:59:55 --> Loader Class Initialized
DEBUG - 2011-04-26 06:59:55 --> Controller Class Initialized
DEBUG - 2011-04-26 06:59:55 --> Model Class Initialized
DEBUG - 2011-04-26 06:59:55 --> Model Class Initialized
DEBUG - 2011-04-26 06:59:55 --> Model Class Initialized
DEBUG - 2011-04-26 06:59:55 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-26 06:59:55 --> Database Driver Class Initialized
DEBUG - 2011-04-26 06:59:55 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-26 06:59:55 --> Helper loaded: url_helper
DEBUG - 2011-04-26 06:59:55 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-26 06:59:55 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-26 06:59:55 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-26 06:59:55 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-26 06:59:55 --> Final output sent to browser
DEBUG - 2011-04-26 06:59:55 --> Total execution time: 0.0699
DEBUG - 2011-04-26 07:00:03 --> Config Class Initialized
DEBUG - 2011-04-26 07:00:03 --> Hooks Class Initialized
DEBUG - 2011-04-26 07:00:03 --> Utf8 Class Initialized
DEBUG - 2011-04-26 07:00:03 --> UTF-8 Support Enabled
DEBUG - 2011-04-26 07:00:03 --> URI Class Initialized
DEBUG - 2011-04-26 07:00:03 --> Router Class Initialized
DEBUG - 2011-04-26 07:00:03 --> Output Class Initialized
DEBUG - 2011-04-26 07:00:03 --> Input Class Initialized
DEBUG - 2011-04-26 07:00:03 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-26 07:00:03 --> Language Class Initialized
DEBUG - 2011-04-26 07:00:03 --> Loader Class Initialized
DEBUG - 2011-04-26 07:00:03 --> Controller Class Initialized
DEBUG - 2011-04-26 07:00:03 --> Model Class Initialized
DEBUG - 2011-04-26 07:00:03 --> Model Class Initialized
DEBUG - 2011-04-26 07:00:03 --> Model Class Initialized
DEBUG - 2011-04-26 07:00:03 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-26 07:00:03 --> Database Driver Class Initialized
DEBUG - 2011-04-26 07:00:04 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-26 07:00:04 --> Helper loaded: url_helper
DEBUG - 2011-04-26 07:00:04 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-26 07:00:04 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-26 07:00:04 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-26 07:00:04 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-26 07:00:04 --> Final output sent to browser
DEBUG - 2011-04-26 07:00:04 --> Total execution time: 1.5426
DEBUG - 2011-04-26 07:00:08 --> Config Class Initialized
DEBUG - 2011-04-26 07:00:08 --> Hooks Class Initialized
DEBUG - 2011-04-26 07:00:08 --> Utf8 Class Initialized
DEBUG - 2011-04-26 07:00:08 --> UTF-8 Support Enabled
DEBUG - 2011-04-26 07:00:08 --> URI Class Initialized
DEBUG - 2011-04-26 07:00:08 --> Router Class Initialized
DEBUG - 2011-04-26 07:00:08 --> Output Class Initialized
DEBUG - 2011-04-26 07:00:08 --> Input Class Initialized
DEBUG - 2011-04-26 07:00:08 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-26 07:00:08 --> Language Class Initialized
DEBUG - 2011-04-26 07:00:08 --> Loader Class Initialized
DEBUG - 2011-04-26 07:00:08 --> Controller Class Initialized
DEBUG - 2011-04-26 07:00:08 --> Model Class Initialized
DEBUG - 2011-04-26 07:00:08 --> Model Class Initialized
DEBUG - 2011-04-26 07:00:08 --> Model Class Initialized
DEBUG - 2011-04-26 07:00:08 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-26 07:00:08 --> Database Driver Class Initialized
DEBUG - 2011-04-26 07:00:08 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-26 07:00:08 --> Helper loaded: url_helper
DEBUG - 2011-04-26 07:00:08 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-26 07:00:08 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-26 07:00:08 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-26 07:00:08 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-26 07:00:08 --> Final output sent to browser
DEBUG - 2011-04-26 07:00:08 --> Total execution time: 0.1174
DEBUG - 2011-04-26 07:00:16 --> Config Class Initialized
DEBUG - 2011-04-26 07:00:16 --> Hooks Class Initialized
DEBUG - 2011-04-26 07:00:16 --> Utf8 Class Initialized
DEBUG - 2011-04-26 07:00:16 --> UTF-8 Support Enabled
DEBUG - 2011-04-26 07:00:16 --> URI Class Initialized
DEBUG - 2011-04-26 07:00:16 --> Router Class Initialized
DEBUG - 2011-04-26 07:00:16 --> Output Class Initialized
DEBUG - 2011-04-26 07:00:16 --> Input Class Initialized
DEBUG - 2011-04-26 07:00:16 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-26 07:00:16 --> Language Class Initialized
DEBUG - 2011-04-26 07:00:16 --> Loader Class Initialized
DEBUG - 2011-04-26 07:00:16 --> Controller Class Initialized
DEBUG - 2011-04-26 07:00:16 --> Model Class Initialized
DEBUG - 2011-04-26 07:00:16 --> Model Class Initialized
DEBUG - 2011-04-26 07:00:16 --> Model Class Initialized
DEBUG - 2011-04-26 07:00:16 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-26 07:00:16 --> Database Driver Class Initialized
DEBUG - 2011-04-26 07:00:16 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-26 07:00:16 --> Helper loaded: url_helper
DEBUG - 2011-04-26 07:00:16 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-26 07:00:16 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-26 07:00:16 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-26 07:00:16 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-26 07:00:16 --> Final output sent to browser
DEBUG - 2011-04-26 07:00:16 --> Total execution time: 0.3284
DEBUG - 2011-04-26 07:00:19 --> Config Class Initialized
DEBUG - 2011-04-26 07:00:19 --> Hooks Class Initialized
DEBUG - 2011-04-26 07:00:19 --> Utf8 Class Initialized
DEBUG - 2011-04-26 07:00:19 --> UTF-8 Support Enabled
DEBUG - 2011-04-26 07:00:19 --> URI Class Initialized
DEBUG - 2011-04-26 07:00:19 --> Router Class Initialized
DEBUG - 2011-04-26 07:00:19 --> Output Class Initialized
DEBUG - 2011-04-26 07:00:19 --> Input Class Initialized
DEBUG - 2011-04-26 07:00:19 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-26 07:00:19 --> Language Class Initialized
DEBUG - 2011-04-26 07:00:19 --> Loader Class Initialized
DEBUG - 2011-04-26 07:00:19 --> Controller Class Initialized
DEBUG - 2011-04-26 07:00:19 --> Model Class Initialized
DEBUG - 2011-04-26 07:00:19 --> Model Class Initialized
DEBUG - 2011-04-26 07:00:19 --> Model Class Initialized
DEBUG - 2011-04-26 07:00:19 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-26 07:00:19 --> Database Driver Class Initialized
DEBUG - 2011-04-26 07:00:19 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-26 07:00:19 --> Helper loaded: url_helper
DEBUG - 2011-04-26 07:00:19 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-26 07:00:19 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-26 07:00:19 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-26 07:00:19 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-26 07:00:19 --> Final output sent to browser
DEBUG - 2011-04-26 07:00:19 --> Total execution time: 0.7272
DEBUG - 2011-04-26 07:00:24 --> Config Class Initialized
DEBUG - 2011-04-26 07:00:24 --> Hooks Class Initialized
DEBUG - 2011-04-26 07:00:24 --> Utf8 Class Initialized
DEBUG - 2011-04-26 07:00:24 --> UTF-8 Support Enabled
DEBUG - 2011-04-26 07:00:24 --> URI Class Initialized
DEBUG - 2011-04-26 07:00:24 --> Router Class Initialized
DEBUG - 2011-04-26 07:00:24 --> Output Class Initialized
DEBUG - 2011-04-26 07:00:24 --> Input Class Initialized
DEBUG - 2011-04-26 07:00:24 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-26 07:00:24 --> Language Class Initialized
DEBUG - 2011-04-26 07:00:24 --> Loader Class Initialized
DEBUG - 2011-04-26 07:00:24 --> Controller Class Initialized
DEBUG - 2011-04-26 07:00:24 --> Model Class Initialized
DEBUG - 2011-04-26 07:00:24 --> Model Class Initialized
DEBUG - 2011-04-26 07:00:24 --> Model Class Initialized
DEBUG - 2011-04-26 07:00:24 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-26 07:00:24 --> Database Driver Class Initialized
DEBUG - 2011-04-26 07:00:27 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-26 07:00:27 --> Helper loaded: url_helper
DEBUG - 2011-04-26 07:00:27 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-26 07:00:27 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-26 07:00:27 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-26 07:00:27 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-26 07:00:27 --> Final output sent to browser
DEBUG - 2011-04-26 07:00:27 --> Total execution time: 2.9460
DEBUG - 2011-04-26 07:00:29 --> Config Class Initialized
DEBUG - 2011-04-26 07:00:29 --> Hooks Class Initialized
DEBUG - 2011-04-26 07:00:29 --> Utf8 Class Initialized
DEBUG - 2011-04-26 07:00:29 --> UTF-8 Support Enabled
DEBUG - 2011-04-26 07:00:29 --> URI Class Initialized
DEBUG - 2011-04-26 07:00:29 --> Router Class Initialized
DEBUG - 2011-04-26 07:00:29 --> Output Class Initialized
DEBUG - 2011-04-26 07:00:29 --> Input Class Initialized
DEBUG - 2011-04-26 07:00:29 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-26 07:00:29 --> Language Class Initialized
DEBUG - 2011-04-26 07:00:29 --> Loader Class Initialized
DEBUG - 2011-04-26 07:00:29 --> Controller Class Initialized
DEBUG - 2011-04-26 07:00:29 --> Model Class Initialized
DEBUG - 2011-04-26 07:00:29 --> Model Class Initialized
DEBUG - 2011-04-26 07:00:29 --> Model Class Initialized
DEBUG - 2011-04-26 07:00:29 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-26 07:00:29 --> Database Driver Class Initialized
DEBUG - 2011-04-26 07:00:29 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-26 07:00:29 --> Helper loaded: url_helper
DEBUG - 2011-04-26 07:00:29 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-26 07:00:29 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-26 07:00:29 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-26 07:00:29 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-26 07:00:29 --> Final output sent to browser
DEBUG - 2011-04-26 07:00:29 --> Total execution time: 0.0606
DEBUG - 2011-04-26 07:00:29 --> Config Class Initialized
DEBUG - 2011-04-26 07:00:29 --> Hooks Class Initialized
DEBUG - 2011-04-26 07:00:29 --> Utf8 Class Initialized
DEBUG - 2011-04-26 07:00:29 --> UTF-8 Support Enabled
DEBUG - 2011-04-26 07:00:29 --> URI Class Initialized
DEBUG - 2011-04-26 07:00:29 --> Router Class Initialized
DEBUG - 2011-04-26 07:00:29 --> Output Class Initialized
DEBUG - 2011-04-26 07:00:29 --> Input Class Initialized
DEBUG - 2011-04-26 07:00:29 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-26 07:00:29 --> Language Class Initialized
DEBUG - 2011-04-26 07:00:29 --> Loader Class Initialized
DEBUG - 2011-04-26 07:00:29 --> Controller Class Initialized
DEBUG - 2011-04-26 07:00:29 --> Model Class Initialized
DEBUG - 2011-04-26 07:00:29 --> Model Class Initialized
DEBUG - 2011-04-26 07:00:29 --> Model Class Initialized
DEBUG - 2011-04-26 07:00:29 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-26 07:00:29 --> Database Driver Class Initialized
DEBUG - 2011-04-26 07:00:29 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-26 07:00:29 --> Helper loaded: url_helper
DEBUG - 2011-04-26 07:00:29 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-26 07:00:29 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-26 07:00:29 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-26 07:00:29 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-26 07:00:29 --> Final output sent to browser
DEBUG - 2011-04-26 07:00:29 --> Total execution time: 0.0596
DEBUG - 2011-04-26 07:01:08 --> Config Class Initialized
DEBUG - 2011-04-26 07:01:08 --> Hooks Class Initialized
DEBUG - 2011-04-26 07:01:08 --> Utf8 Class Initialized
DEBUG - 2011-04-26 07:01:08 --> UTF-8 Support Enabled
DEBUG - 2011-04-26 07:01:08 --> URI Class Initialized
DEBUG - 2011-04-26 07:01:08 --> Router Class Initialized
DEBUG - 2011-04-26 07:01:08 --> Output Class Initialized
DEBUG - 2011-04-26 07:01:08 --> Input Class Initialized
DEBUG - 2011-04-26 07:01:08 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-26 07:01:08 --> Language Class Initialized
DEBUG - 2011-04-26 07:01:08 --> Loader Class Initialized
DEBUG - 2011-04-26 07:01:08 --> Controller Class Initialized
DEBUG - 2011-04-26 07:01:08 --> Model Class Initialized
DEBUG - 2011-04-26 07:01:08 --> Model Class Initialized
DEBUG - 2011-04-26 07:01:08 --> Model Class Initialized
DEBUG - 2011-04-26 07:01:08 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-26 07:01:08 --> Database Driver Class Initialized
DEBUG - 2011-04-26 07:01:08 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-26 07:01:08 --> Helper loaded: url_helper
DEBUG - 2011-04-26 07:01:08 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-26 07:01:08 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-26 07:01:08 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-26 07:01:08 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-26 07:01:08 --> Final output sent to browser
DEBUG - 2011-04-26 07:01:08 --> Total execution time: 0.4764
DEBUG - 2011-04-26 07:01:12 --> Config Class Initialized
DEBUG - 2011-04-26 07:01:12 --> Hooks Class Initialized
DEBUG - 2011-04-26 07:01:12 --> Utf8 Class Initialized
DEBUG - 2011-04-26 07:01:12 --> UTF-8 Support Enabled
DEBUG - 2011-04-26 07:01:12 --> URI Class Initialized
DEBUG - 2011-04-26 07:01:12 --> Router Class Initialized
DEBUG - 2011-04-26 07:01:12 --> Output Class Initialized
DEBUG - 2011-04-26 07:01:12 --> Input Class Initialized
DEBUG - 2011-04-26 07:01:12 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-26 07:01:12 --> Language Class Initialized
DEBUG - 2011-04-26 07:01:12 --> Loader Class Initialized
DEBUG - 2011-04-26 07:01:12 --> Controller Class Initialized
DEBUG - 2011-04-26 07:01:12 --> Model Class Initialized
DEBUG - 2011-04-26 07:01:12 --> Model Class Initialized
DEBUG - 2011-04-26 07:01:12 --> Model Class Initialized
DEBUG - 2011-04-26 07:01:12 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-26 07:01:12 --> Database Driver Class Initialized
DEBUG - 2011-04-26 07:01:12 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-26 07:01:12 --> Helper loaded: url_helper
DEBUG - 2011-04-26 07:01:12 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-26 07:01:12 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-26 07:01:12 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-26 07:01:12 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-26 07:01:12 --> Final output sent to browser
DEBUG - 2011-04-26 07:01:12 --> Total execution time: 0.0489
DEBUG - 2011-04-26 07:01:24 --> Config Class Initialized
DEBUG - 2011-04-26 07:01:24 --> Hooks Class Initialized
DEBUG - 2011-04-26 07:01:24 --> Utf8 Class Initialized
DEBUG - 2011-04-26 07:01:24 --> UTF-8 Support Enabled
DEBUG - 2011-04-26 07:01:24 --> URI Class Initialized
DEBUG - 2011-04-26 07:01:24 --> Router Class Initialized
DEBUG - 2011-04-26 07:01:24 --> Output Class Initialized
DEBUG - 2011-04-26 07:01:24 --> Input Class Initialized
DEBUG - 2011-04-26 07:01:24 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-26 07:01:24 --> Language Class Initialized
DEBUG - 2011-04-26 07:01:24 --> Loader Class Initialized
DEBUG - 2011-04-26 07:01:24 --> Controller Class Initialized
DEBUG - 2011-04-26 07:01:24 --> Model Class Initialized
DEBUG - 2011-04-26 07:01:24 --> Model Class Initialized
DEBUG - 2011-04-26 07:01:24 --> Model Class Initialized
DEBUG - 2011-04-26 07:01:24 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-26 07:01:24 --> Database Driver Class Initialized
DEBUG - 2011-04-26 07:01:24 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-26 07:01:24 --> Helper loaded: url_helper
DEBUG - 2011-04-26 07:01:24 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-26 07:01:24 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-26 07:01:24 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-26 07:01:24 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-26 07:01:24 --> Final output sent to browser
DEBUG - 2011-04-26 07:01:24 --> Total execution time: 0.7293
DEBUG - 2011-04-26 07:01:26 --> Config Class Initialized
DEBUG - 2011-04-26 07:01:26 --> Hooks Class Initialized
DEBUG - 2011-04-26 07:01:26 --> Utf8 Class Initialized
DEBUG - 2011-04-26 07:01:26 --> UTF-8 Support Enabled
DEBUG - 2011-04-26 07:01:26 --> URI Class Initialized
DEBUG - 2011-04-26 07:01:26 --> Router Class Initialized
DEBUG - 2011-04-26 07:01:26 --> Output Class Initialized
DEBUG - 2011-04-26 07:01:26 --> Input Class Initialized
DEBUG - 2011-04-26 07:01:26 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-26 07:01:26 --> Language Class Initialized
DEBUG - 2011-04-26 07:01:26 --> Loader Class Initialized
DEBUG - 2011-04-26 07:01:26 --> Controller Class Initialized
DEBUG - 2011-04-26 07:01:26 --> Model Class Initialized
DEBUG - 2011-04-26 07:01:26 --> Model Class Initialized
DEBUG - 2011-04-26 07:01:26 --> Model Class Initialized
DEBUG - 2011-04-26 07:01:26 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-26 07:01:26 --> Database Driver Class Initialized
DEBUG - 2011-04-26 07:01:27 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-26 07:01:27 --> Helper loaded: url_helper
DEBUG - 2011-04-26 07:01:27 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-26 07:01:27 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-26 07:01:27 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-26 07:01:27 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-26 07:01:27 --> Final output sent to browser
DEBUG - 2011-04-26 07:01:27 --> Total execution time: 0.0788
DEBUG - 2011-04-26 07:31:34 --> Config Class Initialized
DEBUG - 2011-04-26 07:31:34 --> Hooks Class Initialized
DEBUG - 2011-04-26 07:31:34 --> Utf8 Class Initialized
DEBUG - 2011-04-26 07:31:34 --> UTF-8 Support Enabled
DEBUG - 2011-04-26 07:31:34 --> URI Class Initialized
DEBUG - 2011-04-26 07:31:34 --> Router Class Initialized
DEBUG - 2011-04-26 07:31:34 --> Output Class Initialized
DEBUG - 2011-04-26 07:31:34 --> Input Class Initialized
DEBUG - 2011-04-26 07:31:34 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-26 07:31:34 --> Language Class Initialized
DEBUG - 2011-04-26 07:31:34 --> Loader Class Initialized
DEBUG - 2011-04-26 07:31:34 --> Controller Class Initialized
DEBUG - 2011-04-26 07:31:34 --> Model Class Initialized
DEBUG - 2011-04-26 07:31:34 --> Model Class Initialized
DEBUG - 2011-04-26 07:31:34 --> Model Class Initialized
DEBUG - 2011-04-26 07:31:34 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-26 07:31:34 --> Database Driver Class Initialized
DEBUG - 2011-04-26 07:31:35 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-26 07:31:35 --> Helper loaded: url_helper
DEBUG - 2011-04-26 07:31:35 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-26 07:31:35 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-26 07:31:35 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-26 07:31:35 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-26 07:31:35 --> Final output sent to browser
DEBUG - 2011-04-26 07:31:35 --> Total execution time: 0.6726
DEBUG - 2011-04-26 07:31:54 --> Config Class Initialized
DEBUG - 2011-04-26 07:31:54 --> Hooks Class Initialized
DEBUG - 2011-04-26 07:31:54 --> Utf8 Class Initialized
DEBUG - 2011-04-26 07:31:54 --> UTF-8 Support Enabled
DEBUG - 2011-04-26 07:31:54 --> URI Class Initialized
DEBUG - 2011-04-26 07:31:54 --> Router Class Initialized
DEBUG - 2011-04-26 07:31:54 --> Output Class Initialized
DEBUG - 2011-04-26 07:31:54 --> Input Class Initialized
DEBUG - 2011-04-26 07:31:54 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-26 07:31:54 --> Language Class Initialized
DEBUG - 2011-04-26 07:31:54 --> Loader Class Initialized
DEBUG - 2011-04-26 07:31:54 --> Controller Class Initialized
DEBUG - 2011-04-26 07:31:54 --> Model Class Initialized
DEBUG - 2011-04-26 07:31:54 --> Model Class Initialized
DEBUG - 2011-04-26 07:31:54 --> Model Class Initialized
DEBUG - 2011-04-26 07:31:54 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-26 07:31:54 --> Database Driver Class Initialized
DEBUG - 2011-04-26 07:31:54 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-26 07:31:54 --> Helper loaded: url_helper
DEBUG - 2011-04-26 07:31:54 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-26 07:31:54 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-26 07:31:54 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-26 07:31:54 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-26 07:31:54 --> Final output sent to browser
DEBUG - 2011-04-26 07:31:54 --> Total execution time: 0.1916
DEBUG - 2011-04-26 07:31:56 --> Config Class Initialized
DEBUG - 2011-04-26 07:31:56 --> Hooks Class Initialized
DEBUG - 2011-04-26 07:31:56 --> Utf8 Class Initialized
DEBUG - 2011-04-26 07:31:56 --> UTF-8 Support Enabled
DEBUG - 2011-04-26 07:31:56 --> URI Class Initialized
DEBUG - 2011-04-26 07:31:56 --> Router Class Initialized
DEBUG - 2011-04-26 07:31:56 --> Output Class Initialized
DEBUG - 2011-04-26 07:31:56 --> Input Class Initialized
DEBUG - 2011-04-26 07:31:56 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-26 07:31:56 --> Language Class Initialized
DEBUG - 2011-04-26 07:31:56 --> Loader Class Initialized
DEBUG - 2011-04-26 07:31:56 --> Controller Class Initialized
DEBUG - 2011-04-26 07:31:56 --> Model Class Initialized
DEBUG - 2011-04-26 07:31:56 --> Model Class Initialized
DEBUG - 2011-04-26 07:31:56 --> Model Class Initialized
DEBUG - 2011-04-26 07:31:56 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-26 07:31:56 --> Database Driver Class Initialized
DEBUG - 2011-04-26 07:31:56 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-26 07:31:56 --> Helper loaded: url_helper
DEBUG - 2011-04-26 07:31:56 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-26 07:31:56 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-26 07:31:56 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-26 07:31:56 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-26 07:31:56 --> Final output sent to browser
DEBUG - 2011-04-26 07:31:56 --> Total execution time: 0.0546
DEBUG - 2011-04-26 07:32:05 --> Config Class Initialized
DEBUG - 2011-04-26 07:32:05 --> Hooks Class Initialized
DEBUG - 2011-04-26 07:32:05 --> Utf8 Class Initialized
DEBUG - 2011-04-26 07:32:05 --> UTF-8 Support Enabled
DEBUG - 2011-04-26 07:32:05 --> URI Class Initialized
DEBUG - 2011-04-26 07:32:05 --> Router Class Initialized
DEBUG - 2011-04-26 07:32:05 --> Output Class Initialized
DEBUG - 2011-04-26 07:32:05 --> Input Class Initialized
DEBUG - 2011-04-26 07:32:05 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-26 07:32:05 --> Language Class Initialized
DEBUG - 2011-04-26 07:32:05 --> Loader Class Initialized
DEBUG - 2011-04-26 07:32:05 --> Controller Class Initialized
DEBUG - 2011-04-26 07:32:05 --> Model Class Initialized
DEBUG - 2011-04-26 07:32:05 --> Model Class Initialized
DEBUG - 2011-04-26 07:32:05 --> Model Class Initialized
DEBUG - 2011-04-26 07:32:05 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-26 07:32:05 --> Database Driver Class Initialized
DEBUG - 2011-04-26 07:32:05 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-26 07:32:05 --> Helper loaded: url_helper
DEBUG - 2011-04-26 07:32:05 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-26 07:32:05 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-26 07:32:05 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-26 07:32:05 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-26 07:32:05 --> Final output sent to browser
DEBUG - 2011-04-26 07:32:05 --> Total execution time: 0.0582
DEBUG - 2011-04-26 07:32:15 --> Config Class Initialized
DEBUG - 2011-04-26 07:32:15 --> Hooks Class Initialized
DEBUG - 2011-04-26 07:32:15 --> Utf8 Class Initialized
DEBUG - 2011-04-26 07:32:15 --> UTF-8 Support Enabled
DEBUG - 2011-04-26 07:32:15 --> URI Class Initialized
DEBUG - 2011-04-26 07:32:15 --> Router Class Initialized
DEBUG - 2011-04-26 07:32:15 --> Output Class Initialized
DEBUG - 2011-04-26 07:32:15 --> Input Class Initialized
DEBUG - 2011-04-26 07:32:15 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-26 07:32:15 --> Language Class Initialized
DEBUG - 2011-04-26 07:32:15 --> Loader Class Initialized
DEBUG - 2011-04-26 07:32:15 --> Controller Class Initialized
DEBUG - 2011-04-26 07:32:15 --> Model Class Initialized
DEBUG - 2011-04-26 07:32:15 --> Model Class Initialized
DEBUG - 2011-04-26 07:32:15 --> Model Class Initialized
DEBUG - 2011-04-26 07:32:15 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-26 07:32:15 --> Database Driver Class Initialized
DEBUG - 2011-04-26 07:32:15 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-26 07:32:15 --> Helper loaded: url_helper
DEBUG - 2011-04-26 07:32:15 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-26 07:32:15 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-26 07:32:15 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-26 07:32:15 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-26 07:32:15 --> Final output sent to browser
DEBUG - 2011-04-26 07:32:15 --> Total execution time: 0.2187
DEBUG - 2011-04-26 07:32:16 --> Config Class Initialized
DEBUG - 2011-04-26 07:32:16 --> Hooks Class Initialized
DEBUG - 2011-04-26 07:32:16 --> Utf8 Class Initialized
DEBUG - 2011-04-26 07:32:16 --> UTF-8 Support Enabled
DEBUG - 2011-04-26 07:32:16 --> URI Class Initialized
DEBUG - 2011-04-26 07:32:16 --> Router Class Initialized
DEBUG - 2011-04-26 07:32:16 --> Output Class Initialized
DEBUG - 2011-04-26 07:32:16 --> Input Class Initialized
DEBUG - 2011-04-26 07:32:16 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-26 07:32:16 --> Language Class Initialized
DEBUG - 2011-04-26 07:32:16 --> Loader Class Initialized
DEBUG - 2011-04-26 07:32:16 --> Controller Class Initialized
DEBUG - 2011-04-26 07:32:16 --> Model Class Initialized
DEBUG - 2011-04-26 07:32:16 --> Model Class Initialized
DEBUG - 2011-04-26 07:32:16 --> Model Class Initialized
DEBUG - 2011-04-26 07:32:16 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-26 07:32:16 --> Database Driver Class Initialized
DEBUG - 2011-04-26 07:32:16 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-26 07:32:16 --> Helper loaded: url_helper
DEBUG - 2011-04-26 07:32:16 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-26 07:32:16 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-26 07:32:16 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-26 07:32:16 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-26 07:32:16 --> Final output sent to browser
DEBUG - 2011-04-26 07:32:16 --> Total execution time: 0.0511
DEBUG - 2011-04-26 07:32:17 --> Config Class Initialized
DEBUG - 2011-04-26 07:32:17 --> Hooks Class Initialized
DEBUG - 2011-04-26 07:32:17 --> Utf8 Class Initialized
DEBUG - 2011-04-26 07:32:17 --> UTF-8 Support Enabled
DEBUG - 2011-04-26 07:32:17 --> URI Class Initialized
DEBUG - 2011-04-26 07:32:17 --> Router Class Initialized
DEBUG - 2011-04-26 07:32:17 --> Output Class Initialized
DEBUG - 2011-04-26 07:32:17 --> Input Class Initialized
DEBUG - 2011-04-26 07:32:17 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-26 07:32:17 --> Language Class Initialized
DEBUG - 2011-04-26 07:32:17 --> Loader Class Initialized
DEBUG - 2011-04-26 07:32:17 --> Controller Class Initialized
DEBUG - 2011-04-26 07:32:17 --> Model Class Initialized
DEBUG - 2011-04-26 07:32:17 --> Model Class Initialized
DEBUG - 2011-04-26 07:32:17 --> Model Class Initialized
DEBUG - 2011-04-26 07:32:17 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-26 07:32:17 --> Database Driver Class Initialized
DEBUG - 2011-04-26 07:32:17 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-26 07:32:17 --> Helper loaded: url_helper
DEBUG - 2011-04-26 07:32:17 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-26 07:32:17 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-26 07:32:17 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-26 07:32:17 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-26 07:32:17 --> Final output sent to browser
DEBUG - 2011-04-26 07:32:17 --> Total execution time: 0.0461
DEBUG - 2011-04-26 07:32:25 --> Config Class Initialized
DEBUG - 2011-04-26 07:32:25 --> Hooks Class Initialized
DEBUG - 2011-04-26 07:32:25 --> Utf8 Class Initialized
DEBUG - 2011-04-26 07:32:25 --> UTF-8 Support Enabled
DEBUG - 2011-04-26 07:32:25 --> URI Class Initialized
DEBUG - 2011-04-26 07:32:25 --> Router Class Initialized
DEBUG - 2011-04-26 07:32:25 --> Output Class Initialized
DEBUG - 2011-04-26 07:32:25 --> Input Class Initialized
DEBUG - 2011-04-26 07:32:25 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-26 07:32:25 --> Language Class Initialized
DEBUG - 2011-04-26 07:32:25 --> Loader Class Initialized
DEBUG - 2011-04-26 07:32:25 --> Controller Class Initialized
DEBUG - 2011-04-26 07:32:25 --> Model Class Initialized
DEBUG - 2011-04-26 07:32:25 --> Model Class Initialized
DEBUG - 2011-04-26 07:32:25 --> Model Class Initialized
DEBUG - 2011-04-26 07:32:25 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-26 07:32:25 --> Database Driver Class Initialized
DEBUG - 2011-04-26 07:32:25 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-26 07:32:25 --> Helper loaded: url_helper
DEBUG - 2011-04-26 07:32:25 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-26 07:32:25 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-26 07:32:25 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-26 07:32:25 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-26 07:32:25 --> Final output sent to browser
DEBUG - 2011-04-26 07:32:25 --> Total execution time: 0.5118
DEBUG - 2011-04-26 07:32:27 --> Config Class Initialized
DEBUG - 2011-04-26 07:32:27 --> Hooks Class Initialized
DEBUG - 2011-04-26 07:32:27 --> Utf8 Class Initialized
DEBUG - 2011-04-26 07:32:27 --> UTF-8 Support Enabled
DEBUG - 2011-04-26 07:32:27 --> URI Class Initialized
DEBUG - 2011-04-26 07:32:27 --> Router Class Initialized
DEBUG - 2011-04-26 07:32:27 --> Output Class Initialized
DEBUG - 2011-04-26 07:32:27 --> Input Class Initialized
DEBUG - 2011-04-26 07:32:27 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-26 07:32:27 --> Language Class Initialized
DEBUG - 2011-04-26 07:32:27 --> Loader Class Initialized
DEBUG - 2011-04-26 07:32:27 --> Controller Class Initialized
DEBUG - 2011-04-26 07:32:27 --> Model Class Initialized
DEBUG - 2011-04-26 07:32:27 --> Model Class Initialized
DEBUG - 2011-04-26 07:32:27 --> Model Class Initialized
DEBUG - 2011-04-26 07:32:27 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-26 07:32:27 --> Database Driver Class Initialized
DEBUG - 2011-04-26 07:32:27 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-26 07:32:27 --> Helper loaded: url_helper
DEBUG - 2011-04-26 07:32:27 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-26 07:32:27 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-26 07:32:27 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-26 07:32:27 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-26 07:32:27 --> Final output sent to browser
DEBUG - 2011-04-26 07:32:27 --> Total execution time: 0.0454
DEBUG - 2011-04-26 07:32:34 --> Config Class Initialized
DEBUG - 2011-04-26 07:32:34 --> Hooks Class Initialized
DEBUG - 2011-04-26 07:32:34 --> Utf8 Class Initialized
DEBUG - 2011-04-26 07:32:34 --> UTF-8 Support Enabled
DEBUG - 2011-04-26 07:32:34 --> URI Class Initialized
DEBUG - 2011-04-26 07:32:34 --> Router Class Initialized
DEBUG - 2011-04-26 07:32:34 --> Output Class Initialized
DEBUG - 2011-04-26 07:32:34 --> Input Class Initialized
DEBUG - 2011-04-26 07:32:34 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-26 07:32:34 --> Language Class Initialized
DEBUG - 2011-04-26 07:32:34 --> Loader Class Initialized
DEBUG - 2011-04-26 07:32:34 --> Controller Class Initialized
DEBUG - 2011-04-26 07:32:34 --> Model Class Initialized
DEBUG - 2011-04-26 07:32:34 --> Model Class Initialized
DEBUG - 2011-04-26 07:32:34 --> Model Class Initialized
DEBUG - 2011-04-26 07:32:34 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-26 07:32:34 --> Database Driver Class Initialized
DEBUG - 2011-04-26 07:32:35 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-26 07:32:35 --> Helper loaded: url_helper
DEBUG - 2011-04-26 07:32:35 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-26 07:32:35 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-26 07:32:35 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-26 07:32:35 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-26 07:32:35 --> Final output sent to browser
DEBUG - 2011-04-26 07:32:35 --> Total execution time: 0.2075
DEBUG - 2011-04-26 07:32:37 --> Config Class Initialized
DEBUG - 2011-04-26 07:32:37 --> Hooks Class Initialized
DEBUG - 2011-04-26 07:32:37 --> Utf8 Class Initialized
DEBUG - 2011-04-26 07:32:37 --> UTF-8 Support Enabled
DEBUG - 2011-04-26 07:32:37 --> URI Class Initialized
DEBUG - 2011-04-26 07:32:37 --> Router Class Initialized
DEBUG - 2011-04-26 07:32:37 --> Output Class Initialized
DEBUG - 2011-04-26 07:32:37 --> Input Class Initialized
DEBUG - 2011-04-26 07:32:37 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-26 07:32:37 --> Language Class Initialized
DEBUG - 2011-04-26 07:32:37 --> Loader Class Initialized
DEBUG - 2011-04-26 07:32:37 --> Controller Class Initialized
DEBUG - 2011-04-26 07:32:37 --> Model Class Initialized
DEBUG - 2011-04-26 07:32:37 --> Model Class Initialized
DEBUG - 2011-04-26 07:32:37 --> Model Class Initialized
DEBUG - 2011-04-26 07:32:37 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-26 07:32:37 --> Database Driver Class Initialized
DEBUG - 2011-04-26 07:32:37 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-26 07:32:37 --> Helper loaded: url_helper
DEBUG - 2011-04-26 07:32:37 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-26 07:32:37 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-26 07:32:37 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-26 07:32:37 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-26 07:32:37 --> Final output sent to browser
DEBUG - 2011-04-26 07:32:37 --> Total execution time: 0.0491
DEBUG - 2011-04-26 07:57:57 --> Config Class Initialized
DEBUG - 2011-04-26 07:57:57 --> Hooks Class Initialized
DEBUG - 2011-04-26 07:57:57 --> Utf8 Class Initialized
DEBUG - 2011-04-26 07:57:57 --> UTF-8 Support Enabled
DEBUG - 2011-04-26 07:57:57 --> URI Class Initialized
DEBUG - 2011-04-26 07:57:57 --> Router Class Initialized
DEBUG - 2011-04-26 07:57:57 --> No URI present. Default controller set.
DEBUG - 2011-04-26 07:57:57 --> Output Class Initialized
DEBUG - 2011-04-26 07:57:57 --> Input Class Initialized
DEBUG - 2011-04-26 07:57:57 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-26 07:57:57 --> Language Class Initialized
DEBUG - 2011-04-26 07:57:57 --> Loader Class Initialized
DEBUG - 2011-04-26 07:57:57 --> Controller Class Initialized
DEBUG - 2011-04-26 07:57:57 --> File loaded: application/views/splash/main.php
DEBUG - 2011-04-26 07:57:57 --> Helper loaded: url_helper
DEBUG - 2011-04-26 07:57:57 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-26 07:57:57 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-26 07:57:57 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-26 07:57:57 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-26 07:57:57 --> Final output sent to browser
DEBUG - 2011-04-26 07:57:57 --> Total execution time: 0.2850
DEBUG - 2011-04-26 08:52:03 --> Config Class Initialized
DEBUG - 2011-04-26 08:52:03 --> Hooks Class Initialized
DEBUG - 2011-04-26 08:52:03 --> Utf8 Class Initialized
DEBUG - 2011-04-26 08:52:03 --> UTF-8 Support Enabled
DEBUG - 2011-04-26 08:52:03 --> URI Class Initialized
DEBUG - 2011-04-26 08:52:03 --> Router Class Initialized
DEBUG - 2011-04-26 08:52:03 --> Output Class Initialized
DEBUG - 2011-04-26 08:52:03 --> Input Class Initialized
DEBUG - 2011-04-26 08:52:03 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-26 08:52:03 --> Language Class Initialized
DEBUG - 2011-04-26 08:52:03 --> Loader Class Initialized
DEBUG - 2011-04-26 08:52:03 --> Controller Class Initialized
ERROR - 2011-04-26 08:52:03 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-26 08:52:03 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-26 08:52:03 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-26 08:52:03 --> Model Class Initialized
DEBUG - 2011-04-26 08:52:03 --> Model Class Initialized
DEBUG - 2011-04-26 08:52:03 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-26 08:52:03 --> Database Driver Class Initialized
DEBUG - 2011-04-26 08:52:03 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-26 08:52:04 --> Helper loaded: url_helper
DEBUG - 2011-04-26 08:52:04 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-26 08:52:04 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-26 08:52:04 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-26 08:52:04 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-26 08:52:04 --> Final output sent to browser
DEBUG - 2011-04-26 08:52:04 --> Total execution time: 1.3999
DEBUG - 2011-04-26 08:52:06 --> Config Class Initialized
DEBUG - 2011-04-26 08:52:06 --> Hooks Class Initialized
DEBUG - 2011-04-26 08:52:06 --> Utf8 Class Initialized
DEBUG - 2011-04-26 08:52:06 --> UTF-8 Support Enabled
DEBUG - 2011-04-26 08:52:06 --> URI Class Initialized
DEBUG - 2011-04-26 08:52:06 --> Router Class Initialized
DEBUG - 2011-04-26 08:52:06 --> Output Class Initialized
DEBUG - 2011-04-26 08:52:06 --> Input Class Initialized
DEBUG - 2011-04-26 08:52:06 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-26 08:52:06 --> Language Class Initialized
DEBUG - 2011-04-26 08:52:06 --> Loader Class Initialized
DEBUG - 2011-04-26 08:52:06 --> Controller Class Initialized
DEBUG - 2011-04-26 08:52:06 --> Model Class Initialized
DEBUG - 2011-04-26 08:52:06 --> Model Class Initialized
DEBUG - 2011-04-26 08:52:06 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-26 08:52:06 --> Database Driver Class Initialized
DEBUG - 2011-04-26 08:52:07 --> Final output sent to browser
DEBUG - 2011-04-26 08:52:07 --> Total execution time: 1.1538
DEBUG - 2011-04-26 08:52:07 --> Config Class Initialized
DEBUG - 2011-04-26 08:52:07 --> Hooks Class Initialized
DEBUG - 2011-04-26 08:52:07 --> Utf8 Class Initialized
DEBUG - 2011-04-26 08:52:07 --> UTF-8 Support Enabled
DEBUG - 2011-04-26 08:52:07 --> URI Class Initialized
DEBUG - 2011-04-26 08:52:07 --> Router Class Initialized
ERROR - 2011-04-26 08:52:07 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-26 08:52:07 --> Config Class Initialized
DEBUG - 2011-04-26 08:52:07 --> Hooks Class Initialized
DEBUG - 2011-04-26 08:52:07 --> Utf8 Class Initialized
DEBUG - 2011-04-26 08:52:07 --> UTF-8 Support Enabled
DEBUG - 2011-04-26 08:52:07 --> URI Class Initialized
DEBUG - 2011-04-26 08:52:07 --> Router Class Initialized
ERROR - 2011-04-26 08:52:07 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-26 08:52:09 --> Config Class Initialized
DEBUG - 2011-04-26 08:52:09 --> Hooks Class Initialized
DEBUG - 2011-04-26 08:52:09 --> Utf8 Class Initialized
DEBUG - 2011-04-26 08:52:09 --> UTF-8 Support Enabled
DEBUG - 2011-04-26 08:52:09 --> URI Class Initialized
DEBUG - 2011-04-26 08:52:09 --> Router Class Initialized
ERROR - 2011-04-26 08:52:09 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-26 08:52:20 --> Config Class Initialized
DEBUG - 2011-04-26 08:52:20 --> Hooks Class Initialized
DEBUG - 2011-04-26 08:52:20 --> Utf8 Class Initialized
DEBUG - 2011-04-26 08:52:20 --> UTF-8 Support Enabled
DEBUG - 2011-04-26 08:52:20 --> URI Class Initialized
DEBUG - 2011-04-26 08:52:20 --> Router Class Initialized
DEBUG - 2011-04-26 08:52:20 --> Output Class Initialized
DEBUG - 2011-04-26 08:52:20 --> Input Class Initialized
DEBUG - 2011-04-26 08:52:20 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-26 08:52:20 --> Language Class Initialized
DEBUG - 2011-04-26 08:52:20 --> Loader Class Initialized
DEBUG - 2011-04-26 08:52:20 --> Controller Class Initialized
ERROR - 2011-04-26 08:52:20 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-26 08:52:20 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-26 08:52:20 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-26 08:52:20 --> Model Class Initialized
DEBUG - 2011-04-26 08:52:20 --> Model Class Initialized
DEBUG - 2011-04-26 08:52:20 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-26 08:52:20 --> Database Driver Class Initialized
DEBUG - 2011-04-26 08:52:20 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-26 08:52:20 --> Helper loaded: url_helper
DEBUG - 2011-04-26 08:52:20 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-26 08:52:20 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-26 08:52:20 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-26 08:52:20 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-26 08:52:20 --> Final output sent to browser
DEBUG - 2011-04-26 08:52:20 --> Total execution time: 0.0321
DEBUG - 2011-04-26 09:28:21 --> Config Class Initialized
DEBUG - 2011-04-26 09:28:21 --> Hooks Class Initialized
DEBUG - 2011-04-26 09:28:21 --> Utf8 Class Initialized
DEBUG - 2011-04-26 09:28:21 --> UTF-8 Support Enabled
DEBUG - 2011-04-26 09:28:21 --> URI Class Initialized
DEBUG - 2011-04-26 09:28:21 --> Router Class Initialized
DEBUG - 2011-04-26 09:28:21 --> Output Class Initialized
DEBUG - 2011-04-26 09:28:21 --> Input Class Initialized
DEBUG - 2011-04-26 09:28:21 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-26 09:28:21 --> Language Class Initialized
DEBUG - 2011-04-26 09:28:21 --> Loader Class Initialized
DEBUG - 2011-04-26 09:28:21 --> Controller Class Initialized
DEBUG - 2011-04-26 09:28:21 --> Model Class Initialized
DEBUG - 2011-04-26 09:28:21 --> Model Class Initialized
DEBUG - 2011-04-26 09:28:21 --> Model Class Initialized
DEBUG - 2011-04-26 09:28:21 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-26 09:28:21 --> Database Driver Class Initialized
DEBUG - 2011-04-26 09:28:21 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-26 09:28:21 --> Helper loaded: url_helper
DEBUG - 2011-04-26 09:28:21 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-26 09:28:21 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-26 09:28:21 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-26 09:28:21 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-26 09:28:21 --> Final output sent to browser
DEBUG - 2011-04-26 09:28:21 --> Total execution time: 0.6557
DEBUG - 2011-04-26 09:28:22 --> Config Class Initialized
DEBUG - 2011-04-26 09:28:22 --> Hooks Class Initialized
DEBUG - 2011-04-26 09:28:22 --> Utf8 Class Initialized
DEBUG - 2011-04-26 09:28:22 --> UTF-8 Support Enabled
DEBUG - 2011-04-26 09:28:22 --> URI Class Initialized
DEBUG - 2011-04-26 09:28:22 --> Router Class Initialized
DEBUG - 2011-04-26 09:28:22 --> Output Class Initialized
DEBUG - 2011-04-26 09:28:22 --> Input Class Initialized
DEBUG - 2011-04-26 09:28:22 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-26 09:28:22 --> Language Class Initialized
DEBUG - 2011-04-26 09:28:22 --> Loader Class Initialized
DEBUG - 2011-04-26 09:28:22 --> Controller Class Initialized
ERROR - 2011-04-26 09:28:22 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-26 09:28:22 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-26 09:28:22 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-26 09:28:22 --> Model Class Initialized
DEBUG - 2011-04-26 09:28:22 --> Model Class Initialized
DEBUG - 2011-04-26 09:28:22 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-26 09:28:22 --> Database Driver Class Initialized
DEBUG - 2011-04-26 09:28:22 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-26 09:28:22 --> Helper loaded: url_helper
DEBUG - 2011-04-26 09:28:22 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-26 09:28:22 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-26 09:28:22 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-26 09:28:22 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-26 09:28:22 --> Final output sent to browser
DEBUG - 2011-04-26 09:28:22 --> Total execution time: 0.0865
DEBUG - 2011-04-26 09:46:29 --> Config Class Initialized
DEBUG - 2011-04-26 09:46:29 --> Hooks Class Initialized
DEBUG - 2011-04-26 09:46:29 --> Utf8 Class Initialized
DEBUG - 2011-04-26 09:46:29 --> UTF-8 Support Enabled
DEBUG - 2011-04-26 09:46:29 --> URI Class Initialized
DEBUG - 2011-04-26 09:46:29 --> Router Class Initialized
DEBUG - 2011-04-26 09:46:29 --> Output Class Initialized
DEBUG - 2011-04-26 09:46:29 --> Input Class Initialized
DEBUG - 2011-04-26 09:46:29 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-26 09:46:29 --> Language Class Initialized
DEBUG - 2011-04-26 09:46:29 --> Loader Class Initialized
DEBUG - 2011-04-26 09:46:29 --> Controller Class Initialized
ERROR - 2011-04-26 09:46:29 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-26 09:46:29 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-26 09:46:29 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-26 09:46:29 --> Model Class Initialized
DEBUG - 2011-04-26 09:46:29 --> Model Class Initialized
DEBUG - 2011-04-26 09:46:29 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-26 09:46:30 --> Database Driver Class Initialized
DEBUG - 2011-04-26 09:46:30 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-26 09:46:30 --> Helper loaded: url_helper
DEBUG - 2011-04-26 09:46:30 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-26 09:46:30 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-26 09:46:30 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-26 09:46:30 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-26 09:46:30 --> Final output sent to browser
DEBUG - 2011-04-26 09:46:30 --> Total execution time: 1.0807
DEBUG - 2011-04-26 09:46:32 --> Config Class Initialized
DEBUG - 2011-04-26 09:46:32 --> Hooks Class Initialized
DEBUG - 2011-04-26 09:46:32 --> Utf8 Class Initialized
DEBUG - 2011-04-26 09:46:32 --> UTF-8 Support Enabled
DEBUG - 2011-04-26 09:46:32 --> URI Class Initialized
DEBUG - 2011-04-26 09:46:32 --> Router Class Initialized
DEBUG - 2011-04-26 09:46:32 --> Output Class Initialized
DEBUG - 2011-04-26 09:46:32 --> Input Class Initialized
DEBUG - 2011-04-26 09:46:32 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-26 09:46:32 --> Language Class Initialized
DEBUG - 2011-04-26 09:46:32 --> Loader Class Initialized
DEBUG - 2011-04-26 09:46:32 --> Controller Class Initialized
DEBUG - 2011-04-26 09:46:32 --> Model Class Initialized
DEBUG - 2011-04-26 09:46:32 --> Model Class Initialized
DEBUG - 2011-04-26 09:46:32 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-26 09:46:32 --> Database Driver Class Initialized
DEBUG - 2011-04-26 09:46:33 --> Final output sent to browser
DEBUG - 2011-04-26 09:46:33 --> Total execution time: 1.2688
DEBUG - 2011-04-26 10:38:21 --> Config Class Initialized
DEBUG - 2011-04-26 10:38:21 --> Hooks Class Initialized
DEBUG - 2011-04-26 10:38:21 --> Utf8 Class Initialized
DEBUG - 2011-04-26 10:38:21 --> UTF-8 Support Enabled
DEBUG - 2011-04-26 10:38:21 --> URI Class Initialized
DEBUG - 2011-04-26 10:38:21 --> Router Class Initialized
DEBUG - 2011-04-26 10:38:21 --> Output Class Initialized
DEBUG - 2011-04-26 10:38:21 --> Input Class Initialized
DEBUG - 2011-04-26 10:38:21 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-26 10:38:21 --> Language Class Initialized
DEBUG - 2011-04-26 10:38:21 --> Loader Class Initialized
DEBUG - 2011-04-26 10:38:21 --> Controller Class Initialized
ERROR - 2011-04-26 10:38:21 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-26 10:38:21 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-26 10:38:21 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-26 10:38:21 --> Model Class Initialized
DEBUG - 2011-04-26 10:38:21 --> Model Class Initialized
DEBUG - 2011-04-26 10:38:21 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-26 10:38:21 --> Database Driver Class Initialized
DEBUG - 2011-04-26 10:38:21 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-26 10:38:21 --> Helper loaded: url_helper
DEBUG - 2011-04-26 10:38:21 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-26 10:38:21 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-26 10:38:21 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-26 10:38:21 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-26 10:38:21 --> Final output sent to browser
DEBUG - 2011-04-26 10:38:21 --> Total execution time: 0.3249
DEBUG - 2011-04-26 10:38:24 --> Config Class Initialized
DEBUG - 2011-04-26 10:38:24 --> Hooks Class Initialized
DEBUG - 2011-04-26 10:38:24 --> Utf8 Class Initialized
DEBUG - 2011-04-26 10:38:24 --> UTF-8 Support Enabled
DEBUG - 2011-04-26 10:38:24 --> URI Class Initialized
DEBUG - 2011-04-26 10:38:24 --> Router Class Initialized
DEBUG - 2011-04-26 10:38:24 --> Output Class Initialized
DEBUG - 2011-04-26 10:38:24 --> Input Class Initialized
DEBUG - 2011-04-26 10:38:24 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-26 10:38:24 --> Language Class Initialized
DEBUG - 2011-04-26 10:38:24 --> Loader Class Initialized
DEBUG - 2011-04-26 10:38:24 --> Controller Class Initialized
DEBUG - 2011-04-26 10:38:24 --> Model Class Initialized
DEBUG - 2011-04-26 10:38:24 --> Model Class Initialized
DEBUG - 2011-04-26 10:38:24 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-26 10:38:24 --> Database Driver Class Initialized
DEBUG - 2011-04-26 10:38:26 --> Final output sent to browser
DEBUG - 2011-04-26 10:38:26 --> Total execution time: 1.4361
DEBUG - 2011-04-26 11:30:21 --> Config Class Initialized
DEBUG - 2011-04-26 11:30:21 --> Hooks Class Initialized
DEBUG - 2011-04-26 11:30:21 --> Utf8 Class Initialized
DEBUG - 2011-04-26 11:30:21 --> UTF-8 Support Enabled
DEBUG - 2011-04-26 11:30:21 --> URI Class Initialized
DEBUG - 2011-04-26 11:30:21 --> Router Class Initialized
DEBUG - 2011-04-26 11:30:23 --> Output Class Initialized
DEBUG - 2011-04-26 11:30:24 --> Input Class Initialized
DEBUG - 2011-04-26 11:30:24 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-26 11:30:24 --> Language Class Initialized
DEBUG - 2011-04-26 11:30:24 --> Loader Class Initialized
DEBUG - 2011-04-26 11:30:25 --> Controller Class Initialized
DEBUG - 2011-04-26 11:30:26 --> Model Class Initialized
DEBUG - 2011-04-26 11:30:26 --> Model Class Initialized
DEBUG - 2011-04-26 11:30:26 --> Model Class Initialized
DEBUG - 2011-04-26 11:30:26 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-26 11:30:27 --> Database Driver Class Initialized
DEBUG - 2011-04-26 11:30:28 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-26 11:30:28 --> Helper loaded: url_helper
DEBUG - 2011-04-26 11:30:28 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-26 11:30:28 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-26 11:30:28 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-26 11:30:28 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-26 11:30:28 --> Final output sent to browser
DEBUG - 2011-04-26 11:30:28 --> Total execution time: 8.4936
DEBUG - 2011-04-26 11:30:30 --> Config Class Initialized
DEBUG - 2011-04-26 11:30:30 --> Hooks Class Initialized
DEBUG - 2011-04-26 11:30:30 --> Utf8 Class Initialized
DEBUG - 2011-04-26 11:30:30 --> UTF-8 Support Enabled
DEBUG - 2011-04-26 11:30:30 --> URI Class Initialized
DEBUG - 2011-04-26 11:30:30 --> Router Class Initialized
DEBUG - 2011-04-26 11:30:30 --> Output Class Initialized
DEBUG - 2011-04-26 11:30:30 --> Input Class Initialized
DEBUG - 2011-04-26 11:30:30 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-26 11:30:30 --> Language Class Initialized
DEBUG - 2011-04-26 11:30:30 --> Loader Class Initialized
DEBUG - 2011-04-26 11:30:30 --> Controller Class Initialized
ERROR - 2011-04-26 11:30:30 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-26 11:30:30 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-26 11:30:30 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-26 11:30:30 --> Model Class Initialized
DEBUG - 2011-04-26 11:30:30 --> Model Class Initialized
DEBUG - 2011-04-26 11:30:30 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-26 11:30:30 --> Database Driver Class Initialized
DEBUG - 2011-04-26 11:30:30 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-26 11:30:30 --> Helper loaded: url_helper
DEBUG - 2011-04-26 11:30:30 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-26 11:30:30 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-26 11:30:30 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-26 11:30:30 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-26 11:30:30 --> Final output sent to browser
DEBUG - 2011-04-26 11:30:30 --> Total execution time: 0.2038
DEBUG - 2011-04-26 11:33:08 --> Config Class Initialized
DEBUG - 2011-04-26 11:33:08 --> Hooks Class Initialized
DEBUG - 2011-04-26 11:33:08 --> Utf8 Class Initialized
DEBUG - 2011-04-26 11:33:08 --> UTF-8 Support Enabled
DEBUG - 2011-04-26 11:33:08 --> URI Class Initialized
DEBUG - 2011-04-26 11:33:08 --> Router Class Initialized
DEBUG - 2011-04-26 11:33:08 --> Output Class Initialized
DEBUG - 2011-04-26 11:33:08 --> Input Class Initialized
DEBUG - 2011-04-26 11:33:08 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-26 11:33:08 --> Language Class Initialized
DEBUG - 2011-04-26 11:33:08 --> Loader Class Initialized
DEBUG - 2011-04-26 11:33:08 --> Controller Class Initialized
DEBUG - 2011-04-26 11:33:08 --> Model Class Initialized
DEBUG - 2011-04-26 11:33:08 --> Model Class Initialized
DEBUG - 2011-04-26 11:33:08 --> Model Class Initialized
DEBUG - 2011-04-26 11:33:08 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-26 11:33:08 --> Database Driver Class Initialized
DEBUG - 2011-04-26 11:33:08 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-26 11:33:08 --> Helper loaded: url_helper
DEBUG - 2011-04-26 11:33:08 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-26 11:33:08 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-26 11:33:08 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-26 11:33:08 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-26 11:33:08 --> Final output sent to browser
DEBUG - 2011-04-26 11:33:08 --> Total execution time: 0.0717
DEBUG - 2011-04-26 11:33:10 --> Config Class Initialized
DEBUG - 2011-04-26 11:33:10 --> Hooks Class Initialized
DEBUG - 2011-04-26 11:33:10 --> Utf8 Class Initialized
DEBUG - 2011-04-26 11:33:10 --> UTF-8 Support Enabled
DEBUG - 2011-04-26 11:33:10 --> URI Class Initialized
DEBUG - 2011-04-26 11:33:10 --> Router Class Initialized
ERROR - 2011-04-26 11:33:10 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-26 11:33:11 --> Config Class Initialized
DEBUG - 2011-04-26 11:33:11 --> Hooks Class Initialized
DEBUG - 2011-04-26 11:33:11 --> Utf8 Class Initialized
DEBUG - 2011-04-26 11:33:11 --> UTF-8 Support Enabled
DEBUG - 2011-04-26 11:33:11 --> URI Class Initialized
DEBUG - 2011-04-26 11:33:11 --> Router Class Initialized
ERROR - 2011-04-26 11:33:11 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-26 11:48:52 --> Config Class Initialized
DEBUG - 2011-04-26 11:48:52 --> Hooks Class Initialized
DEBUG - 2011-04-26 11:48:52 --> Utf8 Class Initialized
DEBUG - 2011-04-26 11:48:52 --> UTF-8 Support Enabled
DEBUG - 2011-04-26 11:48:52 --> URI Class Initialized
DEBUG - 2011-04-26 11:48:52 --> Router Class Initialized
DEBUG - 2011-04-26 11:48:52 --> Output Class Initialized
DEBUG - 2011-04-26 11:48:52 --> Input Class Initialized
DEBUG - 2011-04-26 11:48:52 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-26 11:48:52 --> Language Class Initialized
DEBUG - 2011-04-26 11:48:52 --> Loader Class Initialized
DEBUG - 2011-04-26 11:48:52 --> Controller Class Initialized
DEBUG - 2011-04-26 11:48:52 --> Model Class Initialized
DEBUG - 2011-04-26 11:48:52 --> Model Class Initialized
DEBUG - 2011-04-26 11:48:52 --> Model Class Initialized
DEBUG - 2011-04-26 11:48:52 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-26 11:48:52 --> Database Driver Class Initialized
DEBUG - 2011-04-26 11:48:53 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-26 11:48:53 --> Helper loaded: url_helper
DEBUG - 2011-04-26 11:48:53 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-26 11:48:53 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-26 11:48:53 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-26 11:48:53 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-26 11:48:53 --> Final output sent to browser
DEBUG - 2011-04-26 11:48:53 --> Total execution time: 0.7068
DEBUG - 2011-04-26 12:27:47 --> Config Class Initialized
DEBUG - 2011-04-26 12:27:47 --> Hooks Class Initialized
DEBUG - 2011-04-26 12:27:47 --> Utf8 Class Initialized
DEBUG - 2011-04-26 12:27:47 --> UTF-8 Support Enabled
DEBUG - 2011-04-26 12:27:47 --> URI Class Initialized
DEBUG - 2011-04-26 12:27:47 --> Router Class Initialized
DEBUG - 2011-04-26 12:27:47 --> Output Class Initialized
DEBUG - 2011-04-26 12:27:47 --> Input Class Initialized
DEBUG - 2011-04-26 12:27:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-26 12:27:47 --> Language Class Initialized
DEBUG - 2011-04-26 12:27:47 --> Loader Class Initialized
DEBUG - 2011-04-26 12:27:47 --> Controller Class Initialized
DEBUG - 2011-04-26 12:27:47 --> Model Class Initialized
DEBUG - 2011-04-26 12:27:47 --> Model Class Initialized
DEBUG - 2011-04-26 12:27:47 --> Model Class Initialized
DEBUG - 2011-04-26 12:27:47 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-26 12:27:47 --> Database Driver Class Initialized
DEBUG - 2011-04-26 12:27:48 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-26 12:27:48 --> Helper loaded: url_helper
DEBUG - 2011-04-26 12:27:48 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-26 12:27:48 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-26 12:27:48 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-26 12:27:48 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-26 12:27:48 --> Final output sent to browser
DEBUG - 2011-04-26 12:27:48 --> Total execution time: 0.5479
DEBUG - 2011-04-26 12:27:51 --> Config Class Initialized
DEBUG - 2011-04-26 12:27:51 --> Hooks Class Initialized
DEBUG - 2011-04-26 12:27:51 --> Utf8 Class Initialized
DEBUG - 2011-04-26 12:27:51 --> UTF-8 Support Enabled
DEBUG - 2011-04-26 12:27:51 --> URI Class Initialized
DEBUG - 2011-04-26 12:27:51 --> Router Class Initialized
ERROR - 2011-04-26 12:27:51 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-26 12:27:52 --> Config Class Initialized
DEBUG - 2011-04-26 12:27:52 --> Hooks Class Initialized
DEBUG - 2011-04-26 12:27:52 --> Utf8 Class Initialized
DEBUG - 2011-04-26 12:27:52 --> UTF-8 Support Enabled
DEBUG - 2011-04-26 12:27:52 --> URI Class Initialized
DEBUG - 2011-04-26 12:27:52 --> Router Class Initialized
ERROR - 2011-04-26 12:27:52 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-26 12:28:00 --> Config Class Initialized
DEBUG - 2011-04-26 12:28:00 --> Hooks Class Initialized
DEBUG - 2011-04-26 12:28:00 --> Utf8 Class Initialized
DEBUG - 2011-04-26 12:28:00 --> UTF-8 Support Enabled
DEBUG - 2011-04-26 12:28:00 --> URI Class Initialized
DEBUG - 2011-04-26 12:28:00 --> Router Class Initialized
DEBUG - 2011-04-26 12:28:00 --> Output Class Initialized
DEBUG - 2011-04-26 12:28:00 --> Input Class Initialized
DEBUG - 2011-04-26 12:28:00 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-26 12:28:00 --> Language Class Initialized
DEBUG - 2011-04-26 12:28:00 --> Loader Class Initialized
DEBUG - 2011-04-26 12:28:00 --> Controller Class Initialized
DEBUG - 2011-04-26 12:28:00 --> Model Class Initialized
DEBUG - 2011-04-26 12:28:00 --> Model Class Initialized
DEBUG - 2011-04-26 12:28:00 --> Model Class Initialized
DEBUG - 2011-04-26 12:28:00 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-26 12:28:00 --> Database Driver Class Initialized
DEBUG - 2011-04-26 12:28:00 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-26 12:28:00 --> Helper loaded: url_helper
DEBUG - 2011-04-26 12:28:00 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-26 12:28:00 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-26 12:28:00 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-26 12:28:00 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-26 12:28:00 --> Final output sent to browser
DEBUG - 2011-04-26 12:28:00 --> Total execution time: 0.4838
DEBUG - 2011-04-26 12:28:05 --> Config Class Initialized
DEBUG - 2011-04-26 12:28:05 --> Hooks Class Initialized
DEBUG - 2011-04-26 12:28:05 --> Utf8 Class Initialized
DEBUG - 2011-04-26 12:28:05 --> UTF-8 Support Enabled
DEBUG - 2011-04-26 12:28:05 --> URI Class Initialized
DEBUG - 2011-04-26 12:28:05 --> Router Class Initialized
DEBUG - 2011-04-26 12:28:05 --> Output Class Initialized
DEBUG - 2011-04-26 12:28:05 --> Input Class Initialized
DEBUG - 2011-04-26 12:28:05 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-26 12:28:05 --> Language Class Initialized
DEBUG - 2011-04-26 12:28:05 --> Loader Class Initialized
DEBUG - 2011-04-26 12:28:05 --> Controller Class Initialized
DEBUG - 2011-04-26 12:28:05 --> Model Class Initialized
DEBUG - 2011-04-26 12:28:05 --> Model Class Initialized
DEBUG - 2011-04-26 12:28:05 --> Model Class Initialized
DEBUG - 2011-04-26 12:28:05 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-26 12:28:05 --> Database Driver Class Initialized
DEBUG - 2011-04-26 12:28:06 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-26 12:28:06 --> Helper loaded: url_helper
DEBUG - 2011-04-26 12:28:06 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-26 12:28:06 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-26 12:28:06 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-26 12:28:06 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-26 12:28:06 --> Final output sent to browser
DEBUG - 2011-04-26 12:28:06 --> Total execution time: 0.6994
DEBUG - 2011-04-26 12:28:12 --> Config Class Initialized
DEBUG - 2011-04-26 12:28:12 --> Hooks Class Initialized
DEBUG - 2011-04-26 12:28:12 --> Utf8 Class Initialized
DEBUG - 2011-04-26 12:28:12 --> UTF-8 Support Enabled
DEBUG - 2011-04-26 12:28:12 --> URI Class Initialized
DEBUG - 2011-04-26 12:28:12 --> Router Class Initialized
DEBUG - 2011-04-26 12:28:12 --> Output Class Initialized
DEBUG - 2011-04-26 12:28:12 --> Input Class Initialized
DEBUG - 2011-04-26 12:28:12 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-26 12:28:12 --> Language Class Initialized
DEBUG - 2011-04-26 12:28:12 --> Loader Class Initialized
DEBUG - 2011-04-26 12:28:12 --> Controller Class Initialized
DEBUG - 2011-04-26 12:28:12 --> Model Class Initialized
DEBUG - 2011-04-26 12:28:12 --> Model Class Initialized
DEBUG - 2011-04-26 12:28:12 --> Model Class Initialized
DEBUG - 2011-04-26 12:28:12 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-26 12:28:12 --> Database Driver Class Initialized
DEBUG - 2011-04-26 12:28:13 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-26 12:28:13 --> Helper loaded: url_helper
DEBUG - 2011-04-26 12:28:13 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-26 12:28:13 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-26 12:28:13 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-26 12:28:13 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-26 12:28:13 --> Final output sent to browser
DEBUG - 2011-04-26 12:28:13 --> Total execution time: 0.2232
DEBUG - 2011-04-26 13:46:25 --> Config Class Initialized
DEBUG - 2011-04-26 13:46:25 --> Hooks Class Initialized
DEBUG - 2011-04-26 13:46:25 --> Utf8 Class Initialized
DEBUG - 2011-04-26 13:46:25 --> UTF-8 Support Enabled
DEBUG - 2011-04-26 13:46:25 --> URI Class Initialized
DEBUG - 2011-04-26 13:46:25 --> Router Class Initialized
DEBUG - 2011-04-26 13:46:25 --> Output Class Initialized
DEBUG - 2011-04-26 13:46:25 --> Input Class Initialized
DEBUG - 2011-04-26 13:46:25 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-26 13:46:25 --> Language Class Initialized
DEBUG - 2011-04-26 13:46:26 --> Loader Class Initialized
DEBUG - 2011-04-26 13:46:26 --> Controller Class Initialized
DEBUG - 2011-04-26 13:46:26 --> Model Class Initialized
DEBUG - 2011-04-26 13:46:26 --> Model Class Initialized
DEBUG - 2011-04-26 13:46:26 --> Model Class Initialized
DEBUG - 2011-04-26 13:46:26 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-26 13:46:26 --> Database Driver Class Initialized
DEBUG - 2011-04-26 13:46:26 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-26 13:46:27 --> Helper loaded: url_helper
DEBUG - 2011-04-26 13:46:27 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-26 13:46:27 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-26 13:46:27 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-26 13:46:27 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-26 13:46:27 --> Final output sent to browser
DEBUG - 2011-04-26 13:46:27 --> Total execution time: 1.2617
DEBUG - 2011-04-26 13:46:54 --> Config Class Initialized
DEBUG - 2011-04-26 13:46:54 --> Hooks Class Initialized
DEBUG - 2011-04-26 13:46:54 --> Utf8 Class Initialized
DEBUG - 2011-04-26 13:46:54 --> UTF-8 Support Enabled
DEBUG - 2011-04-26 13:46:54 --> URI Class Initialized
DEBUG - 2011-04-26 13:46:54 --> Router Class Initialized
DEBUG - 2011-04-26 13:46:54 --> Output Class Initialized
DEBUG - 2011-04-26 13:46:54 --> Input Class Initialized
DEBUG - 2011-04-26 13:46:54 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-26 13:46:54 --> Language Class Initialized
DEBUG - 2011-04-26 13:46:54 --> Loader Class Initialized
DEBUG - 2011-04-26 13:46:54 --> Controller Class Initialized
DEBUG - 2011-04-26 13:46:54 --> Model Class Initialized
DEBUG - 2011-04-26 13:46:54 --> Model Class Initialized
DEBUG - 2011-04-26 13:46:54 --> Model Class Initialized
DEBUG - 2011-04-26 13:46:54 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-26 13:46:54 --> Database Driver Class Initialized
DEBUG - 2011-04-26 13:46:54 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-26 13:46:54 --> Helper loaded: url_helper
DEBUG - 2011-04-26 13:46:54 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-26 13:46:54 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-26 13:46:54 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-26 13:46:54 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-26 13:46:54 --> Final output sent to browser
DEBUG - 2011-04-26 13:46:54 --> Total execution time: 0.1553
DEBUG - 2011-04-26 13:46:56 --> Config Class Initialized
DEBUG - 2011-04-26 13:46:56 --> Hooks Class Initialized
DEBUG - 2011-04-26 13:46:56 --> Utf8 Class Initialized
DEBUG - 2011-04-26 13:46:56 --> UTF-8 Support Enabled
DEBUG - 2011-04-26 13:46:56 --> URI Class Initialized
DEBUG - 2011-04-26 13:46:56 --> Router Class Initialized
DEBUG - 2011-04-26 13:46:56 --> Output Class Initialized
DEBUG - 2011-04-26 13:46:56 --> Input Class Initialized
DEBUG - 2011-04-26 13:46:56 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-26 13:46:56 --> Language Class Initialized
DEBUG - 2011-04-26 13:46:56 --> Loader Class Initialized
DEBUG - 2011-04-26 13:46:56 --> Controller Class Initialized
DEBUG - 2011-04-26 13:46:56 --> Model Class Initialized
DEBUG - 2011-04-26 13:46:56 --> Model Class Initialized
DEBUG - 2011-04-26 13:46:56 --> Model Class Initialized
DEBUG - 2011-04-26 13:46:56 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-26 13:46:56 --> Database Driver Class Initialized
DEBUG - 2011-04-26 13:46:56 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-26 13:46:56 --> Helper loaded: url_helper
DEBUG - 2011-04-26 13:46:56 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-26 13:46:56 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-26 13:46:56 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-26 13:46:56 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-26 13:46:56 --> Final output sent to browser
DEBUG - 2011-04-26 13:46:56 --> Total execution time: 0.0656
DEBUG - 2011-04-26 13:47:00 --> Config Class Initialized
DEBUG - 2011-04-26 13:47:00 --> Hooks Class Initialized
DEBUG - 2011-04-26 13:47:00 --> Utf8 Class Initialized
DEBUG - 2011-04-26 13:47:00 --> UTF-8 Support Enabled
DEBUG - 2011-04-26 13:47:00 --> URI Class Initialized
DEBUG - 2011-04-26 13:47:00 --> Router Class Initialized
DEBUG - 2011-04-26 13:47:00 --> Output Class Initialized
DEBUG - 2011-04-26 13:47:00 --> Input Class Initialized
DEBUG - 2011-04-26 13:47:00 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-26 13:47:00 --> Language Class Initialized
DEBUG - 2011-04-26 13:47:00 --> Loader Class Initialized
DEBUG - 2011-04-26 13:47:00 --> Controller Class Initialized
DEBUG - 2011-04-26 13:47:00 --> Model Class Initialized
DEBUG - 2011-04-26 13:47:00 --> Model Class Initialized
DEBUG - 2011-04-26 13:47:00 --> Model Class Initialized
DEBUG - 2011-04-26 13:47:00 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-26 13:47:00 --> Database Driver Class Initialized
DEBUG - 2011-04-26 13:47:00 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-26 13:47:00 --> Helper loaded: url_helper
DEBUG - 2011-04-26 13:47:00 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-26 13:47:00 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-26 13:47:00 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-26 13:47:00 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-26 13:47:00 --> Final output sent to browser
DEBUG - 2011-04-26 13:47:00 --> Total execution time: 0.1364
DEBUG - 2011-04-26 13:47:29 --> Config Class Initialized
DEBUG - 2011-04-26 13:47:29 --> Hooks Class Initialized
DEBUG - 2011-04-26 13:47:29 --> Utf8 Class Initialized
DEBUG - 2011-04-26 13:47:29 --> UTF-8 Support Enabled
DEBUG - 2011-04-26 13:47:29 --> URI Class Initialized
DEBUG - 2011-04-26 13:47:29 --> Router Class Initialized
DEBUG - 2011-04-26 13:47:29 --> Output Class Initialized
DEBUG - 2011-04-26 13:47:29 --> Input Class Initialized
DEBUG - 2011-04-26 13:47:29 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-26 13:47:29 --> Language Class Initialized
DEBUG - 2011-04-26 13:47:29 --> Loader Class Initialized
DEBUG - 2011-04-26 13:47:29 --> Controller Class Initialized
DEBUG - 2011-04-26 13:47:29 --> Model Class Initialized
DEBUG - 2011-04-26 13:47:29 --> Model Class Initialized
DEBUG - 2011-04-26 13:47:29 --> Model Class Initialized
DEBUG - 2011-04-26 13:47:29 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-26 13:47:29 --> Database Driver Class Initialized
DEBUG - 2011-04-26 13:47:29 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-26 13:47:29 --> Helper loaded: url_helper
DEBUG - 2011-04-26 13:47:29 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-26 13:47:29 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-26 13:47:29 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-26 13:47:29 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-26 13:47:29 --> Final output sent to browser
DEBUG - 2011-04-26 13:47:29 --> Total execution time: 0.2269
DEBUG - 2011-04-26 13:47:32 --> Config Class Initialized
DEBUG - 2011-04-26 13:47:32 --> Hooks Class Initialized
DEBUG - 2011-04-26 13:47:32 --> Utf8 Class Initialized
DEBUG - 2011-04-26 13:47:32 --> UTF-8 Support Enabled
DEBUG - 2011-04-26 13:47:32 --> URI Class Initialized
DEBUG - 2011-04-26 13:47:32 --> Router Class Initialized
DEBUG - 2011-04-26 13:47:32 --> Output Class Initialized
DEBUG - 2011-04-26 13:47:32 --> Input Class Initialized
DEBUG - 2011-04-26 13:47:32 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-26 13:47:32 --> Language Class Initialized
DEBUG - 2011-04-26 13:47:32 --> Loader Class Initialized
DEBUG - 2011-04-26 13:47:32 --> Controller Class Initialized
DEBUG - 2011-04-26 13:47:32 --> Model Class Initialized
DEBUG - 2011-04-26 13:47:32 --> Model Class Initialized
DEBUG - 2011-04-26 13:47:32 --> Model Class Initialized
DEBUG - 2011-04-26 13:47:32 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-26 13:47:32 --> Database Driver Class Initialized
DEBUG - 2011-04-26 13:47:32 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-26 13:47:32 --> Helper loaded: url_helper
DEBUG - 2011-04-26 13:47:32 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-26 13:47:32 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-26 13:47:32 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-26 13:47:32 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-26 13:47:32 --> Final output sent to browser
DEBUG - 2011-04-26 13:47:32 --> Total execution time: 0.1642
DEBUG - 2011-04-26 13:47:54 --> Config Class Initialized
DEBUG - 2011-04-26 13:47:54 --> Hooks Class Initialized
DEBUG - 2011-04-26 13:47:54 --> Utf8 Class Initialized
DEBUG - 2011-04-26 13:47:54 --> UTF-8 Support Enabled
DEBUG - 2011-04-26 13:47:54 --> URI Class Initialized
DEBUG - 2011-04-26 13:47:54 --> Router Class Initialized
DEBUG - 2011-04-26 13:47:54 --> Output Class Initialized
DEBUG - 2011-04-26 13:47:54 --> Input Class Initialized
DEBUG - 2011-04-26 13:47:54 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-26 13:47:54 --> Language Class Initialized
DEBUG - 2011-04-26 13:47:54 --> Loader Class Initialized
DEBUG - 2011-04-26 13:47:54 --> Controller Class Initialized
DEBUG - 2011-04-26 13:47:54 --> Model Class Initialized
DEBUG - 2011-04-26 13:47:54 --> Model Class Initialized
DEBUG - 2011-04-26 13:47:54 --> Model Class Initialized
DEBUG - 2011-04-26 13:47:54 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-26 13:47:54 --> Database Driver Class Initialized
DEBUG - 2011-04-26 13:47:54 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-26 13:47:54 --> Helper loaded: url_helper
DEBUG - 2011-04-26 13:47:54 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-26 13:47:54 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-26 13:47:54 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-26 13:47:54 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-26 13:47:54 --> Final output sent to browser
DEBUG - 2011-04-26 13:47:54 --> Total execution time: 0.0772
DEBUG - 2011-04-26 13:48:09 --> Config Class Initialized
DEBUG - 2011-04-26 13:48:09 --> Hooks Class Initialized
DEBUG - 2011-04-26 13:48:09 --> Utf8 Class Initialized
DEBUG - 2011-04-26 13:48:09 --> UTF-8 Support Enabled
DEBUG - 2011-04-26 13:48:09 --> URI Class Initialized
DEBUG - 2011-04-26 13:48:09 --> Router Class Initialized
DEBUG - 2011-04-26 13:48:09 --> Output Class Initialized
DEBUG - 2011-04-26 13:48:09 --> Input Class Initialized
DEBUG - 2011-04-26 13:48:09 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-26 13:48:09 --> Language Class Initialized
DEBUG - 2011-04-26 13:48:09 --> Loader Class Initialized
DEBUG - 2011-04-26 13:48:09 --> Controller Class Initialized
DEBUG - 2011-04-26 13:48:09 --> Model Class Initialized
DEBUG - 2011-04-26 13:48:09 --> Model Class Initialized
DEBUG - 2011-04-26 13:48:09 --> Model Class Initialized
DEBUG - 2011-04-26 13:48:09 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-26 13:48:09 --> Database Driver Class Initialized
DEBUG - 2011-04-26 13:48:09 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-26 13:48:09 --> Helper loaded: url_helper
DEBUG - 2011-04-26 13:48:09 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-26 13:48:09 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-26 13:48:09 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-26 13:48:09 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-26 13:48:09 --> Final output sent to browser
DEBUG - 2011-04-26 13:48:09 --> Total execution time: 0.2068
DEBUG - 2011-04-26 13:48:10 --> Config Class Initialized
DEBUG - 2011-04-26 13:48:10 --> Hooks Class Initialized
DEBUG - 2011-04-26 13:48:10 --> Utf8 Class Initialized
DEBUG - 2011-04-26 13:48:10 --> UTF-8 Support Enabled
DEBUG - 2011-04-26 13:48:10 --> URI Class Initialized
DEBUG - 2011-04-26 13:48:10 --> Router Class Initialized
DEBUG - 2011-04-26 13:48:10 --> Output Class Initialized
DEBUG - 2011-04-26 13:48:10 --> Input Class Initialized
DEBUG - 2011-04-26 13:48:10 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-26 13:48:10 --> Language Class Initialized
DEBUG - 2011-04-26 13:48:10 --> Loader Class Initialized
DEBUG - 2011-04-26 13:48:10 --> Controller Class Initialized
DEBUG - 2011-04-26 13:48:10 --> Model Class Initialized
DEBUG - 2011-04-26 13:48:10 --> Model Class Initialized
DEBUG - 2011-04-26 13:48:10 --> Model Class Initialized
DEBUG - 2011-04-26 13:48:10 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-26 13:48:11 --> Database Driver Class Initialized
DEBUG - 2011-04-26 13:48:11 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-26 13:48:11 --> Helper loaded: url_helper
DEBUG - 2011-04-26 13:48:11 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-26 13:48:11 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-26 13:48:11 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-26 13:48:11 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-26 13:48:11 --> Final output sent to browser
DEBUG - 2011-04-26 13:48:11 --> Total execution time: 0.0463
DEBUG - 2011-04-26 13:48:30 --> Config Class Initialized
DEBUG - 2011-04-26 13:48:30 --> Hooks Class Initialized
DEBUG - 2011-04-26 13:48:30 --> Utf8 Class Initialized
DEBUG - 2011-04-26 13:48:30 --> UTF-8 Support Enabled
DEBUG - 2011-04-26 13:48:30 --> URI Class Initialized
DEBUG - 2011-04-26 13:48:30 --> Router Class Initialized
DEBUG - 2011-04-26 13:48:30 --> Output Class Initialized
DEBUG - 2011-04-26 13:48:30 --> Input Class Initialized
DEBUG - 2011-04-26 13:48:30 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-26 13:48:30 --> Language Class Initialized
DEBUG - 2011-04-26 13:48:30 --> Loader Class Initialized
DEBUG - 2011-04-26 13:48:30 --> Controller Class Initialized
DEBUG - 2011-04-26 13:48:30 --> Model Class Initialized
DEBUG - 2011-04-26 13:48:30 --> Model Class Initialized
DEBUG - 2011-04-26 13:48:30 --> Model Class Initialized
DEBUG - 2011-04-26 13:48:30 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-26 13:48:30 --> Database Driver Class Initialized
DEBUG - 2011-04-26 13:48:30 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-26 13:48:30 --> Helper loaded: url_helper
DEBUG - 2011-04-26 13:48:30 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-26 13:48:30 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-26 13:48:30 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-26 13:48:30 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-26 13:48:30 --> Final output sent to browser
DEBUG - 2011-04-26 13:48:30 --> Total execution time: 0.0738
DEBUG - 2011-04-26 13:48:44 --> Config Class Initialized
DEBUG - 2011-04-26 13:48:44 --> Hooks Class Initialized
DEBUG - 2011-04-26 13:48:44 --> Utf8 Class Initialized
DEBUG - 2011-04-26 13:48:44 --> UTF-8 Support Enabled
DEBUG - 2011-04-26 13:48:44 --> URI Class Initialized
DEBUG - 2011-04-26 13:48:44 --> Router Class Initialized
DEBUG - 2011-04-26 13:48:44 --> Output Class Initialized
DEBUG - 2011-04-26 13:48:44 --> Input Class Initialized
DEBUG - 2011-04-26 13:48:44 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-26 13:48:44 --> Language Class Initialized
DEBUG - 2011-04-26 13:48:44 --> Loader Class Initialized
DEBUG - 2011-04-26 13:48:44 --> Controller Class Initialized
DEBUG - 2011-04-26 13:48:44 --> Model Class Initialized
DEBUG - 2011-04-26 13:48:44 --> Model Class Initialized
DEBUG - 2011-04-26 13:48:44 --> Model Class Initialized
DEBUG - 2011-04-26 13:48:44 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-26 13:48:44 --> Database Driver Class Initialized
DEBUG - 2011-04-26 13:48:44 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-26 13:48:44 --> Helper loaded: url_helper
DEBUG - 2011-04-26 13:48:44 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-26 13:48:44 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-26 13:48:44 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-26 13:48:44 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-26 13:48:44 --> Final output sent to browser
DEBUG - 2011-04-26 13:48:44 --> Total execution time: 0.2811
DEBUG - 2011-04-26 13:48:46 --> Config Class Initialized
DEBUG - 2011-04-26 13:48:46 --> Hooks Class Initialized
DEBUG - 2011-04-26 13:48:46 --> Utf8 Class Initialized
DEBUG - 2011-04-26 13:48:46 --> UTF-8 Support Enabled
DEBUG - 2011-04-26 13:48:46 --> URI Class Initialized
DEBUG - 2011-04-26 13:48:46 --> Router Class Initialized
DEBUG - 2011-04-26 13:48:46 --> Output Class Initialized
DEBUG - 2011-04-26 13:48:46 --> Input Class Initialized
DEBUG - 2011-04-26 13:48:46 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-26 13:48:46 --> Language Class Initialized
DEBUG - 2011-04-26 13:48:46 --> Loader Class Initialized
DEBUG - 2011-04-26 13:48:46 --> Controller Class Initialized
DEBUG - 2011-04-26 13:48:46 --> Model Class Initialized
DEBUG - 2011-04-26 13:48:46 --> Model Class Initialized
DEBUG - 2011-04-26 13:48:46 --> Model Class Initialized
DEBUG - 2011-04-26 13:48:46 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-26 13:48:46 --> Database Driver Class Initialized
DEBUG - 2011-04-26 13:48:46 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-26 13:48:46 --> Helper loaded: url_helper
DEBUG - 2011-04-26 13:48:46 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-26 13:48:46 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-26 13:48:46 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-26 13:48:46 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-26 13:48:46 --> Final output sent to browser
DEBUG - 2011-04-26 13:48:46 --> Total execution time: 0.0487
DEBUG - 2011-04-26 13:49:01 --> Config Class Initialized
DEBUG - 2011-04-26 13:49:01 --> Hooks Class Initialized
DEBUG - 2011-04-26 13:49:01 --> Utf8 Class Initialized
DEBUG - 2011-04-26 13:49:01 --> UTF-8 Support Enabled
DEBUG - 2011-04-26 13:49:01 --> URI Class Initialized
DEBUG - 2011-04-26 13:49:01 --> Router Class Initialized
DEBUG - 2011-04-26 13:49:01 --> Output Class Initialized
DEBUG - 2011-04-26 13:49:01 --> Input Class Initialized
DEBUG - 2011-04-26 13:49:01 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-26 13:49:01 --> Language Class Initialized
DEBUG - 2011-04-26 13:49:01 --> Loader Class Initialized
DEBUG - 2011-04-26 13:49:01 --> Controller Class Initialized
DEBUG - 2011-04-26 13:49:01 --> Model Class Initialized
DEBUG - 2011-04-26 13:49:01 --> Model Class Initialized
DEBUG - 2011-04-26 13:49:01 --> Model Class Initialized
DEBUG - 2011-04-26 13:49:01 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-26 13:49:01 --> Database Driver Class Initialized
DEBUG - 2011-04-26 13:49:02 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-26 13:49:02 --> Helper loaded: url_helper
DEBUG - 2011-04-26 13:49:02 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-26 13:49:02 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-26 13:49:02 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-26 13:49:02 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-26 13:49:02 --> Final output sent to browser
DEBUG - 2011-04-26 13:49:02 --> Total execution time: 1.1325
DEBUG - 2011-04-26 13:49:06 --> Config Class Initialized
DEBUG - 2011-04-26 13:49:06 --> Hooks Class Initialized
DEBUG - 2011-04-26 13:49:06 --> Utf8 Class Initialized
DEBUG - 2011-04-26 13:49:06 --> UTF-8 Support Enabled
DEBUG - 2011-04-26 13:49:06 --> URI Class Initialized
DEBUG - 2011-04-26 13:49:06 --> Router Class Initialized
ERROR - 2011-04-26 13:49:06 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-26 13:49:11 --> Config Class Initialized
DEBUG - 2011-04-26 13:49:11 --> Hooks Class Initialized
DEBUG - 2011-04-26 13:49:11 --> Utf8 Class Initialized
DEBUG - 2011-04-26 13:49:11 --> UTF-8 Support Enabled
DEBUG - 2011-04-26 13:49:11 --> URI Class Initialized
DEBUG - 2011-04-26 13:49:11 --> Router Class Initialized
DEBUG - 2011-04-26 13:49:11 --> Output Class Initialized
DEBUG - 2011-04-26 13:49:11 --> Input Class Initialized
DEBUG - 2011-04-26 13:49:11 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-26 13:49:11 --> Language Class Initialized
DEBUG - 2011-04-26 13:49:11 --> Loader Class Initialized
DEBUG - 2011-04-26 13:49:11 --> Controller Class Initialized
DEBUG - 2011-04-26 13:49:11 --> Model Class Initialized
DEBUG - 2011-04-26 13:49:11 --> Model Class Initialized
DEBUG - 2011-04-26 13:49:11 --> Model Class Initialized
DEBUG - 2011-04-26 13:49:11 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-26 13:49:11 --> Database Driver Class Initialized
DEBUG - 2011-04-26 13:49:11 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-26 13:49:11 --> Helper loaded: url_helper
DEBUG - 2011-04-26 13:49:11 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-26 13:49:11 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-26 13:49:11 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-26 13:49:11 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-26 13:49:11 --> Final output sent to browser
DEBUG - 2011-04-26 13:49:11 --> Total execution time: 0.0502
DEBUG - 2011-04-26 13:49:16 --> Config Class Initialized
DEBUG - 2011-04-26 13:49:16 --> Hooks Class Initialized
DEBUG - 2011-04-26 13:49:16 --> Utf8 Class Initialized
DEBUG - 2011-04-26 13:49:16 --> UTF-8 Support Enabled
DEBUG - 2011-04-26 13:49:16 --> URI Class Initialized
DEBUG - 2011-04-26 13:49:16 --> Router Class Initialized
DEBUG - 2011-04-26 13:49:16 --> Output Class Initialized
DEBUG - 2011-04-26 13:49:16 --> Input Class Initialized
DEBUG - 2011-04-26 13:49:16 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-26 13:49:16 --> Language Class Initialized
DEBUG - 2011-04-26 13:49:16 --> Loader Class Initialized
DEBUG - 2011-04-26 13:49:16 --> Controller Class Initialized
DEBUG - 2011-04-26 13:49:16 --> Model Class Initialized
DEBUG - 2011-04-26 13:49:16 --> Model Class Initialized
DEBUG - 2011-04-26 13:49:16 --> Model Class Initialized
DEBUG - 2011-04-26 13:49:16 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-26 13:49:16 --> Database Driver Class Initialized
DEBUG - 2011-04-26 13:49:17 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-26 13:49:17 --> Helper loaded: url_helper
DEBUG - 2011-04-26 13:49:17 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-26 13:49:17 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-26 13:49:17 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-26 13:49:17 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-26 13:49:17 --> Final output sent to browser
DEBUG - 2011-04-26 13:49:17 --> Total execution time: 0.3300
DEBUG - 2011-04-26 13:49:22 --> Config Class Initialized
DEBUG - 2011-04-26 13:49:22 --> Hooks Class Initialized
DEBUG - 2011-04-26 13:49:22 --> Utf8 Class Initialized
DEBUG - 2011-04-26 13:49:22 --> UTF-8 Support Enabled
DEBUG - 2011-04-26 13:49:22 --> URI Class Initialized
DEBUG - 2011-04-26 13:49:22 --> Router Class Initialized
DEBUG - 2011-04-26 13:49:22 --> Output Class Initialized
DEBUG - 2011-04-26 13:49:22 --> Input Class Initialized
DEBUG - 2011-04-26 13:49:22 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-26 13:49:22 --> Language Class Initialized
DEBUG - 2011-04-26 13:49:22 --> Loader Class Initialized
DEBUG - 2011-04-26 13:49:22 --> Controller Class Initialized
DEBUG - 2011-04-26 13:49:22 --> Model Class Initialized
DEBUG - 2011-04-26 13:49:22 --> Model Class Initialized
DEBUG - 2011-04-26 13:49:22 --> Model Class Initialized
DEBUG - 2011-04-26 13:49:22 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-26 13:49:22 --> Database Driver Class Initialized
DEBUG - 2011-04-26 13:49:23 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-26 13:49:23 --> Helper loaded: url_helper
DEBUG - 2011-04-26 13:49:23 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-26 13:49:23 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-26 13:49:23 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-26 13:49:23 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-26 13:49:23 --> Final output sent to browser
DEBUG - 2011-04-26 13:49:23 --> Total execution time: 0.2656
DEBUG - 2011-04-26 14:08:30 --> Config Class Initialized
DEBUG - 2011-04-26 14:08:30 --> Hooks Class Initialized
DEBUG - 2011-04-26 14:08:30 --> Utf8 Class Initialized
DEBUG - 2011-04-26 14:08:30 --> UTF-8 Support Enabled
DEBUG - 2011-04-26 14:08:30 --> URI Class Initialized
DEBUG - 2011-04-26 14:08:30 --> Router Class Initialized
DEBUG - 2011-04-26 14:08:30 --> Output Class Initialized
DEBUG - 2011-04-26 14:08:30 --> Input Class Initialized
DEBUG - 2011-04-26 14:08:30 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-26 14:08:30 --> Language Class Initialized
DEBUG - 2011-04-26 14:08:30 --> Loader Class Initialized
DEBUG - 2011-04-26 14:08:30 --> Controller Class Initialized
DEBUG - 2011-04-26 14:08:30 --> Model Class Initialized
DEBUG - 2011-04-26 14:08:30 --> Model Class Initialized
DEBUG - 2011-04-26 14:08:30 --> Model Class Initialized
DEBUG - 2011-04-26 14:08:30 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-26 14:08:30 --> Database Driver Class Initialized
DEBUG - 2011-04-26 14:08:30 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-26 14:08:30 --> Helper loaded: url_helper
DEBUG - 2011-04-26 14:08:30 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-26 14:08:30 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-26 14:08:30 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-26 14:08:30 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-26 14:08:30 --> Final output sent to browser
DEBUG - 2011-04-26 14:08:30 --> Total execution time: 0.7156
DEBUG - 2011-04-26 14:08:31 --> Config Class Initialized
DEBUG - 2011-04-26 14:08:31 --> Hooks Class Initialized
DEBUG - 2011-04-26 14:08:31 --> Utf8 Class Initialized
DEBUG - 2011-04-26 14:08:31 --> UTF-8 Support Enabled
DEBUG - 2011-04-26 14:08:31 --> URI Class Initialized
DEBUG - 2011-04-26 14:08:31 --> Router Class Initialized
DEBUG - 2011-04-26 14:08:31 --> Output Class Initialized
DEBUG - 2011-04-26 14:08:31 --> Input Class Initialized
DEBUG - 2011-04-26 14:08:31 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-26 14:08:31 --> Language Class Initialized
DEBUG - 2011-04-26 14:08:31 --> Loader Class Initialized
DEBUG - 2011-04-26 14:08:31 --> Controller Class Initialized
ERROR - 2011-04-26 14:08:31 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-26 14:08:31 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-26 14:08:31 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-26 14:08:31 --> Model Class Initialized
DEBUG - 2011-04-26 14:08:31 --> Model Class Initialized
DEBUG - 2011-04-26 14:08:31 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-26 14:08:31 --> Database Driver Class Initialized
DEBUG - 2011-04-26 14:08:31 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-26 14:08:31 --> Helper loaded: url_helper
DEBUG - 2011-04-26 14:08:31 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-26 14:08:31 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-26 14:08:31 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-26 14:08:31 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-26 14:08:31 --> Final output sent to browser
DEBUG - 2011-04-26 14:08:31 --> Total execution time: 0.0802
DEBUG - 2011-04-26 16:16:04 --> Config Class Initialized
DEBUG - 2011-04-26 16:16:04 --> Hooks Class Initialized
DEBUG - 2011-04-26 16:16:04 --> Utf8 Class Initialized
DEBUG - 2011-04-26 16:16:04 --> UTF-8 Support Enabled
DEBUG - 2011-04-26 16:16:04 --> URI Class Initialized
DEBUG - 2011-04-26 16:16:04 --> Router Class Initialized
ERROR - 2011-04-26 16:16:04 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-04-26 16:16:05 --> Config Class Initialized
DEBUG - 2011-04-26 16:16:05 --> Hooks Class Initialized
DEBUG - 2011-04-26 16:16:05 --> Utf8 Class Initialized
DEBUG - 2011-04-26 16:16:05 --> UTF-8 Support Enabled
DEBUG - 2011-04-26 16:16:05 --> URI Class Initialized
DEBUG - 2011-04-26 16:16:05 --> Router Class Initialized
DEBUG - 2011-04-26 16:16:05 --> Output Class Initialized
DEBUG - 2011-04-26 16:16:05 --> Input Class Initialized
DEBUG - 2011-04-26 16:16:05 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-26 16:16:05 --> Language Class Initialized
DEBUG - 2011-04-26 16:16:05 --> Loader Class Initialized
DEBUG - 2011-04-26 16:16:05 --> Controller Class Initialized
DEBUG - 2011-04-26 16:16:05 --> Model Class Initialized
DEBUG - 2011-04-26 16:16:05 --> Model Class Initialized
DEBUG - 2011-04-26 16:16:05 --> Model Class Initialized
DEBUG - 2011-04-26 16:16:05 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-26 16:16:05 --> Database Driver Class Initialized
DEBUG - 2011-04-26 16:16:06 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-26 16:16:06 --> Helper loaded: url_helper
DEBUG - 2011-04-26 16:16:06 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-26 16:16:06 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-26 16:16:06 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-26 16:16:06 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-26 16:16:06 --> Final output sent to browser
DEBUG - 2011-04-26 16:16:06 --> Total execution time: 1.1682
DEBUG - 2011-04-26 16:30:43 --> Config Class Initialized
DEBUG - 2011-04-26 16:30:43 --> Hooks Class Initialized
DEBUG - 2011-04-26 16:30:43 --> Utf8 Class Initialized
DEBUG - 2011-04-26 16:30:43 --> UTF-8 Support Enabled
DEBUG - 2011-04-26 16:30:43 --> URI Class Initialized
DEBUG - 2011-04-26 16:30:43 --> Router Class Initialized
DEBUG - 2011-04-26 16:30:43 --> Output Class Initialized
DEBUG - 2011-04-26 16:30:43 --> Input Class Initialized
DEBUG - 2011-04-26 16:30:43 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-26 16:30:43 --> Language Class Initialized
DEBUG - 2011-04-26 16:30:43 --> Loader Class Initialized
DEBUG - 2011-04-26 16:30:43 --> Controller Class Initialized
ERROR - 2011-04-26 16:30:43 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-26 16:30:43 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-26 16:30:43 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-26 16:30:43 --> Model Class Initialized
DEBUG - 2011-04-26 16:30:43 --> Model Class Initialized
DEBUG - 2011-04-26 16:30:43 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-26 16:30:43 --> Database Driver Class Initialized
DEBUG - 2011-04-26 16:30:44 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-26 16:30:44 --> Helper loaded: url_helper
DEBUG - 2011-04-26 16:30:44 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-26 16:30:44 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-26 16:30:44 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-26 16:30:44 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-26 16:30:44 --> Final output sent to browser
DEBUG - 2011-04-26 16:30:44 --> Total execution time: 0.3476
DEBUG - 2011-04-26 16:30:45 --> Config Class Initialized
DEBUG - 2011-04-26 16:30:45 --> Hooks Class Initialized
DEBUG - 2011-04-26 16:30:45 --> Utf8 Class Initialized
DEBUG - 2011-04-26 16:30:45 --> UTF-8 Support Enabled
DEBUG - 2011-04-26 16:30:45 --> URI Class Initialized
DEBUG - 2011-04-26 16:30:45 --> Router Class Initialized
DEBUG - 2011-04-26 16:30:45 --> Output Class Initialized
DEBUG - 2011-04-26 16:30:45 --> Input Class Initialized
DEBUG - 2011-04-26 16:30:45 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-26 16:30:45 --> Language Class Initialized
DEBUG - 2011-04-26 16:30:45 --> Loader Class Initialized
DEBUG - 2011-04-26 16:30:45 --> Controller Class Initialized
DEBUG - 2011-04-26 16:30:45 --> Model Class Initialized
DEBUG - 2011-04-26 16:30:45 --> Model Class Initialized
DEBUG - 2011-04-26 16:30:45 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-26 16:30:45 --> Database Driver Class Initialized
DEBUG - 2011-04-26 16:30:46 --> Final output sent to browser
DEBUG - 2011-04-26 16:30:46 --> Total execution time: 0.9381
DEBUG - 2011-04-26 16:30:47 --> Config Class Initialized
DEBUG - 2011-04-26 16:30:47 --> Hooks Class Initialized
DEBUG - 2011-04-26 16:30:47 --> Utf8 Class Initialized
DEBUG - 2011-04-26 16:30:47 --> UTF-8 Support Enabled
DEBUG - 2011-04-26 16:30:47 --> URI Class Initialized
DEBUG - 2011-04-26 16:30:47 --> Router Class Initialized
ERROR - 2011-04-26 16:30:47 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-26 16:30:49 --> Config Class Initialized
DEBUG - 2011-04-26 16:30:49 --> Hooks Class Initialized
DEBUG - 2011-04-26 16:30:49 --> Utf8 Class Initialized
DEBUG - 2011-04-26 16:30:49 --> UTF-8 Support Enabled
DEBUG - 2011-04-26 16:30:49 --> URI Class Initialized
DEBUG - 2011-04-26 16:30:49 --> Router Class Initialized
ERROR - 2011-04-26 16:30:49 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-26 16:31:05 --> Config Class Initialized
DEBUG - 2011-04-26 16:31:05 --> Hooks Class Initialized
DEBUG - 2011-04-26 16:31:05 --> Utf8 Class Initialized
DEBUG - 2011-04-26 16:31:05 --> UTF-8 Support Enabled
DEBUG - 2011-04-26 16:31:05 --> URI Class Initialized
DEBUG - 2011-04-26 16:31:05 --> Router Class Initialized
DEBUG - 2011-04-26 16:31:05 --> Output Class Initialized
DEBUG - 2011-04-26 16:31:05 --> Input Class Initialized
DEBUG - 2011-04-26 16:31:05 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-26 16:31:05 --> Language Class Initialized
DEBUG - 2011-04-26 16:31:05 --> Loader Class Initialized
DEBUG - 2011-04-26 16:31:05 --> Controller Class Initialized
ERROR - 2011-04-26 16:31:05 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-26 16:31:05 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-26 16:31:05 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-26 16:31:05 --> Model Class Initialized
DEBUG - 2011-04-26 16:31:05 --> Model Class Initialized
DEBUG - 2011-04-26 16:31:05 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-26 16:31:05 --> Database Driver Class Initialized
DEBUG - 2011-04-26 16:31:05 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-26 16:31:05 --> Helper loaded: url_helper
DEBUG - 2011-04-26 16:31:05 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-26 16:31:05 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-26 16:31:05 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-26 16:31:05 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-26 16:31:05 --> Final output sent to browser
DEBUG - 2011-04-26 16:31:05 --> Total execution time: 0.0696
DEBUG - 2011-04-26 16:31:06 --> Config Class Initialized
DEBUG - 2011-04-26 16:31:06 --> Hooks Class Initialized
DEBUG - 2011-04-26 16:31:06 --> Utf8 Class Initialized
DEBUG - 2011-04-26 16:31:06 --> UTF-8 Support Enabled
DEBUG - 2011-04-26 16:31:06 --> URI Class Initialized
DEBUG - 2011-04-26 16:31:06 --> Router Class Initialized
DEBUG - 2011-04-26 16:31:06 --> Output Class Initialized
DEBUG - 2011-04-26 16:31:06 --> Input Class Initialized
DEBUG - 2011-04-26 16:31:06 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-26 16:31:06 --> Language Class Initialized
DEBUG - 2011-04-26 16:31:06 --> Loader Class Initialized
DEBUG - 2011-04-26 16:31:06 --> Controller Class Initialized
DEBUG - 2011-04-26 16:31:06 --> Model Class Initialized
DEBUG - 2011-04-26 16:31:06 --> Model Class Initialized
DEBUG - 2011-04-26 16:31:06 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-26 16:31:06 --> Database Driver Class Initialized
DEBUG - 2011-04-26 16:31:06 --> Final output sent to browser
DEBUG - 2011-04-26 16:31:06 --> Total execution time: 0.7335
DEBUG - 2011-04-26 16:31:27 --> Config Class Initialized
DEBUG - 2011-04-26 16:31:27 --> Hooks Class Initialized
DEBUG - 2011-04-26 16:31:27 --> Utf8 Class Initialized
DEBUG - 2011-04-26 16:31:27 --> UTF-8 Support Enabled
DEBUG - 2011-04-26 16:31:27 --> URI Class Initialized
DEBUG - 2011-04-26 16:31:27 --> Router Class Initialized
DEBUG - 2011-04-26 16:31:27 --> Output Class Initialized
DEBUG - 2011-04-26 16:31:27 --> Input Class Initialized
DEBUG - 2011-04-26 16:31:27 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-26 16:31:27 --> Language Class Initialized
DEBUG - 2011-04-26 16:31:27 --> Loader Class Initialized
DEBUG - 2011-04-26 16:31:27 --> Controller Class Initialized
DEBUG - 2011-04-26 16:31:27 --> Model Class Initialized
DEBUG - 2011-04-26 16:31:27 --> Model Class Initialized
DEBUG - 2011-04-26 16:31:27 --> Model Class Initialized
DEBUG - 2011-04-26 16:31:27 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-26 16:31:27 --> Database Driver Class Initialized
DEBUG - 2011-04-26 16:31:27 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-26 16:31:27 --> Helper loaded: url_helper
DEBUG - 2011-04-26 16:31:27 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-26 16:31:27 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-26 16:31:27 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-26 16:31:27 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-26 16:31:27 --> Final output sent to browser
DEBUG - 2011-04-26 16:31:27 --> Total execution time: 0.1751
DEBUG - 2011-04-26 16:32:46 --> Config Class Initialized
DEBUG - 2011-04-26 16:32:46 --> Hooks Class Initialized
DEBUG - 2011-04-26 16:32:46 --> Utf8 Class Initialized
DEBUG - 2011-04-26 16:32:46 --> UTF-8 Support Enabled
DEBUG - 2011-04-26 16:32:46 --> URI Class Initialized
DEBUG - 2011-04-26 16:32:46 --> Router Class Initialized
DEBUG - 2011-04-26 16:32:46 --> Output Class Initialized
DEBUG - 2011-04-26 16:32:46 --> Input Class Initialized
DEBUG - 2011-04-26 16:32:46 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-26 16:32:46 --> Language Class Initialized
DEBUG - 2011-04-26 16:32:46 --> Loader Class Initialized
DEBUG - 2011-04-26 16:32:46 --> Controller Class Initialized
DEBUG - 2011-04-26 16:32:46 --> Model Class Initialized
DEBUG - 2011-04-26 16:32:46 --> Model Class Initialized
DEBUG - 2011-04-26 16:32:46 --> Model Class Initialized
DEBUG - 2011-04-26 16:32:46 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-26 16:32:46 --> Database Driver Class Initialized
DEBUG - 2011-04-26 16:32:46 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-26 16:32:46 --> Helper loaded: url_helper
DEBUG - 2011-04-26 16:32:46 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-26 16:32:46 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-26 16:32:46 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-26 16:32:46 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-26 16:32:46 --> Final output sent to browser
DEBUG - 2011-04-26 16:32:46 --> Total execution time: 0.2060
DEBUG - 2011-04-26 16:32:53 --> Config Class Initialized
DEBUG - 2011-04-26 16:32:53 --> Hooks Class Initialized
DEBUG - 2011-04-26 16:32:53 --> Utf8 Class Initialized
DEBUG - 2011-04-26 16:32:53 --> UTF-8 Support Enabled
DEBUG - 2011-04-26 16:32:53 --> URI Class Initialized
DEBUG - 2011-04-26 16:32:53 --> Router Class Initialized
DEBUG - 2011-04-26 16:32:53 --> Output Class Initialized
DEBUG - 2011-04-26 16:32:53 --> Input Class Initialized
DEBUG - 2011-04-26 16:32:53 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-26 16:32:53 --> Language Class Initialized
DEBUG - 2011-04-26 16:32:53 --> Loader Class Initialized
DEBUG - 2011-04-26 16:32:53 --> Controller Class Initialized
DEBUG - 2011-04-26 16:32:53 --> Model Class Initialized
DEBUG - 2011-04-26 16:32:53 --> Model Class Initialized
DEBUG - 2011-04-26 16:32:53 --> Model Class Initialized
DEBUG - 2011-04-26 16:32:53 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-26 16:32:53 --> Database Driver Class Initialized
DEBUG - 2011-04-26 16:32:53 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-26 16:32:53 --> Helper loaded: url_helper
DEBUG - 2011-04-26 16:32:53 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-26 16:32:53 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-26 16:32:53 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-26 16:32:53 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-26 16:32:53 --> Final output sent to browser
DEBUG - 2011-04-26 16:32:53 --> Total execution time: 0.0463
DEBUG - 2011-04-26 16:33:01 --> Config Class Initialized
DEBUG - 2011-04-26 16:33:01 --> Hooks Class Initialized
DEBUG - 2011-04-26 16:33:01 --> Utf8 Class Initialized
DEBUG - 2011-04-26 16:33:01 --> UTF-8 Support Enabled
DEBUG - 2011-04-26 16:33:01 --> URI Class Initialized
DEBUG - 2011-04-26 16:33:01 --> Router Class Initialized
DEBUG - 2011-04-26 16:33:01 --> Output Class Initialized
DEBUG - 2011-04-26 16:33:01 --> Input Class Initialized
DEBUG - 2011-04-26 16:33:01 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-26 16:33:01 --> Language Class Initialized
DEBUG - 2011-04-26 16:33:01 --> Loader Class Initialized
DEBUG - 2011-04-26 16:33:01 --> Controller Class Initialized
DEBUG - 2011-04-26 16:33:01 --> Model Class Initialized
DEBUG - 2011-04-26 16:33:01 --> Model Class Initialized
DEBUG - 2011-04-26 16:33:01 --> Model Class Initialized
DEBUG - 2011-04-26 16:33:01 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-26 16:33:01 --> Database Driver Class Initialized
DEBUG - 2011-04-26 16:33:01 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-26 16:33:01 --> Helper loaded: url_helper
DEBUG - 2011-04-26 16:33:01 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-26 16:33:01 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-26 16:33:01 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-26 16:33:01 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-26 16:33:01 --> Final output sent to browser
DEBUG - 2011-04-26 16:33:01 --> Total execution time: 0.2784
DEBUG - 2011-04-26 16:33:21 --> Config Class Initialized
DEBUG - 2011-04-26 16:33:21 --> Hooks Class Initialized
DEBUG - 2011-04-26 16:33:21 --> Utf8 Class Initialized
DEBUG - 2011-04-26 16:33:21 --> UTF-8 Support Enabled
DEBUG - 2011-04-26 16:33:21 --> URI Class Initialized
DEBUG - 2011-04-26 16:33:21 --> Router Class Initialized
DEBUG - 2011-04-26 16:33:21 --> Output Class Initialized
DEBUG - 2011-04-26 16:33:21 --> Input Class Initialized
DEBUG - 2011-04-26 16:33:21 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-26 16:33:21 --> Language Class Initialized
DEBUG - 2011-04-26 16:33:21 --> Loader Class Initialized
DEBUG - 2011-04-26 16:33:21 --> Controller Class Initialized
DEBUG - 2011-04-26 16:33:21 --> Model Class Initialized
DEBUG - 2011-04-26 16:33:21 --> Model Class Initialized
DEBUG - 2011-04-26 16:33:21 --> Model Class Initialized
DEBUG - 2011-04-26 16:33:21 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-26 16:33:21 --> Database Driver Class Initialized
DEBUG - 2011-04-26 16:33:21 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-26 16:33:21 --> Helper loaded: url_helper
DEBUG - 2011-04-26 16:33:21 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-26 16:33:21 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-26 16:33:21 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-26 16:33:21 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-26 16:33:21 --> Final output sent to browser
DEBUG - 2011-04-26 16:33:21 --> Total execution time: 0.0877
DEBUG - 2011-04-26 16:33:26 --> Config Class Initialized
DEBUG - 2011-04-26 16:33:26 --> Hooks Class Initialized
DEBUG - 2011-04-26 16:33:26 --> Utf8 Class Initialized
DEBUG - 2011-04-26 16:33:26 --> UTF-8 Support Enabled
DEBUG - 2011-04-26 16:33:26 --> URI Class Initialized
DEBUG - 2011-04-26 16:33:26 --> Router Class Initialized
DEBUG - 2011-04-26 16:33:26 --> Output Class Initialized
DEBUG - 2011-04-26 16:33:26 --> Input Class Initialized
DEBUG - 2011-04-26 16:33:26 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-26 16:33:26 --> Language Class Initialized
DEBUG - 2011-04-26 16:33:26 --> Loader Class Initialized
DEBUG - 2011-04-26 16:33:26 --> Controller Class Initialized
DEBUG - 2011-04-26 16:33:26 --> Model Class Initialized
DEBUG - 2011-04-26 16:33:26 --> Model Class Initialized
DEBUG - 2011-04-26 16:33:26 --> Model Class Initialized
DEBUG - 2011-04-26 16:33:26 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-26 16:33:26 --> Database Driver Class Initialized
DEBUG - 2011-04-26 16:33:26 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-26 16:33:26 --> Helper loaded: url_helper
DEBUG - 2011-04-26 16:33:26 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-26 16:33:26 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-26 16:33:26 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-26 16:33:26 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-26 16:33:26 --> Final output sent to browser
DEBUG - 2011-04-26 16:33:26 --> Total execution time: 0.0487
DEBUG - 2011-04-26 16:33:43 --> Config Class Initialized
DEBUG - 2011-04-26 16:33:43 --> Hooks Class Initialized
DEBUG - 2011-04-26 16:33:43 --> Utf8 Class Initialized
DEBUG - 2011-04-26 16:33:43 --> UTF-8 Support Enabled
DEBUG - 2011-04-26 16:33:43 --> URI Class Initialized
DEBUG - 2011-04-26 16:33:43 --> Router Class Initialized
DEBUG - 2011-04-26 16:33:43 --> Output Class Initialized
DEBUG - 2011-04-26 16:33:43 --> Input Class Initialized
DEBUG - 2011-04-26 16:33:43 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-26 16:33:43 --> Language Class Initialized
DEBUG - 2011-04-26 16:33:43 --> Loader Class Initialized
DEBUG - 2011-04-26 16:33:43 --> Controller Class Initialized
DEBUG - 2011-04-26 16:33:43 --> Model Class Initialized
DEBUG - 2011-04-26 16:33:43 --> Model Class Initialized
DEBUG - 2011-04-26 16:33:43 --> Model Class Initialized
DEBUG - 2011-04-26 16:33:43 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-26 16:33:43 --> Database Driver Class Initialized
DEBUG - 2011-04-26 16:33:44 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-26 16:33:44 --> Helper loaded: url_helper
DEBUG - 2011-04-26 16:33:44 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-26 16:33:44 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-26 16:33:44 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-26 16:33:44 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-26 16:33:44 --> Final output sent to browser
DEBUG - 2011-04-26 16:33:44 --> Total execution time: 0.6761
DEBUG - 2011-04-26 16:33:57 --> Config Class Initialized
DEBUG - 2011-04-26 16:33:57 --> Hooks Class Initialized
DEBUG - 2011-04-26 16:33:57 --> Utf8 Class Initialized
DEBUG - 2011-04-26 16:33:57 --> UTF-8 Support Enabled
DEBUG - 2011-04-26 16:33:57 --> URI Class Initialized
DEBUG - 2011-04-26 16:33:57 --> Router Class Initialized
DEBUG - 2011-04-26 16:33:57 --> Output Class Initialized
DEBUG - 2011-04-26 16:33:57 --> Input Class Initialized
DEBUG - 2011-04-26 16:33:57 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-26 16:33:57 --> Language Class Initialized
DEBUG - 2011-04-26 16:33:57 --> Loader Class Initialized
DEBUG - 2011-04-26 16:33:57 --> Controller Class Initialized
DEBUG - 2011-04-26 16:33:57 --> Model Class Initialized
DEBUG - 2011-04-26 16:33:57 --> Model Class Initialized
DEBUG - 2011-04-26 16:33:57 --> Model Class Initialized
DEBUG - 2011-04-26 16:33:57 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-26 16:33:57 --> Database Driver Class Initialized
DEBUG - 2011-04-26 16:33:57 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-26 16:33:57 --> Helper loaded: url_helper
DEBUG - 2011-04-26 16:33:57 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-26 16:33:57 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-26 16:33:57 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-26 16:33:57 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-26 16:33:57 --> Final output sent to browser
DEBUG - 2011-04-26 16:33:57 --> Total execution time: 0.0621
DEBUG - 2011-04-26 16:34:12 --> Config Class Initialized
DEBUG - 2011-04-26 16:34:12 --> Hooks Class Initialized
DEBUG - 2011-04-26 16:34:12 --> Utf8 Class Initialized
DEBUG - 2011-04-26 16:34:12 --> UTF-8 Support Enabled
DEBUG - 2011-04-26 16:34:12 --> URI Class Initialized
DEBUG - 2011-04-26 16:34:12 --> Router Class Initialized
DEBUG - 2011-04-26 16:34:12 --> Output Class Initialized
DEBUG - 2011-04-26 16:34:12 --> Input Class Initialized
DEBUG - 2011-04-26 16:34:12 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-26 16:34:12 --> Language Class Initialized
DEBUG - 2011-04-26 16:34:12 --> Loader Class Initialized
DEBUG - 2011-04-26 16:34:12 --> Controller Class Initialized
DEBUG - 2011-04-26 16:34:12 --> Model Class Initialized
DEBUG - 2011-04-26 16:34:12 --> Model Class Initialized
DEBUG - 2011-04-26 16:34:12 --> Model Class Initialized
DEBUG - 2011-04-26 16:34:12 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-26 16:34:12 --> Database Driver Class Initialized
DEBUG - 2011-04-26 16:34:12 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-26 16:34:12 --> Helper loaded: url_helper
DEBUG - 2011-04-26 16:34:12 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-26 16:34:12 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-26 16:34:12 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-26 16:34:12 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-26 16:34:12 --> Final output sent to browser
DEBUG - 2011-04-26 16:34:12 --> Total execution time: 0.0465
DEBUG - 2011-04-26 16:34:49 --> Config Class Initialized
DEBUG - 2011-04-26 16:34:49 --> Hooks Class Initialized
DEBUG - 2011-04-26 16:34:49 --> Utf8 Class Initialized
DEBUG - 2011-04-26 16:34:49 --> UTF-8 Support Enabled
DEBUG - 2011-04-26 16:34:49 --> URI Class Initialized
DEBUG - 2011-04-26 16:34:49 --> Router Class Initialized
DEBUG - 2011-04-26 16:34:49 --> Output Class Initialized
DEBUG - 2011-04-26 16:34:49 --> Input Class Initialized
DEBUG - 2011-04-26 16:34:49 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-26 16:34:49 --> Language Class Initialized
DEBUG - 2011-04-26 16:34:49 --> Loader Class Initialized
DEBUG - 2011-04-26 16:34:49 --> Controller Class Initialized
DEBUG - 2011-04-26 16:34:49 --> Model Class Initialized
DEBUG - 2011-04-26 16:34:49 --> Model Class Initialized
DEBUG - 2011-04-26 16:34:49 --> Model Class Initialized
DEBUG - 2011-04-26 16:34:49 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-26 16:34:49 --> Database Driver Class Initialized
DEBUG - 2011-04-26 16:34:50 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-26 16:34:50 --> Helper loaded: url_helper
DEBUG - 2011-04-26 16:34:50 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-26 16:34:50 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-26 16:34:50 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-26 16:34:50 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-26 16:34:50 --> Final output sent to browser
DEBUG - 2011-04-26 16:34:50 --> Total execution time: 0.3935
DEBUG - 2011-04-26 16:35:05 --> Config Class Initialized
DEBUG - 2011-04-26 16:35:05 --> Hooks Class Initialized
DEBUG - 2011-04-26 16:35:05 --> Utf8 Class Initialized
DEBUG - 2011-04-26 16:35:05 --> UTF-8 Support Enabled
DEBUG - 2011-04-26 16:35:05 --> URI Class Initialized
DEBUG - 2011-04-26 16:35:05 --> Router Class Initialized
DEBUG - 2011-04-26 16:35:05 --> Output Class Initialized
DEBUG - 2011-04-26 16:35:05 --> Input Class Initialized
DEBUG - 2011-04-26 16:35:05 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-26 16:35:05 --> Language Class Initialized
DEBUG - 2011-04-26 16:35:05 --> Loader Class Initialized
DEBUG - 2011-04-26 16:35:05 --> Controller Class Initialized
DEBUG - 2011-04-26 16:35:05 --> Model Class Initialized
DEBUG - 2011-04-26 16:35:05 --> Model Class Initialized
DEBUG - 2011-04-26 16:35:05 --> Model Class Initialized
DEBUG - 2011-04-26 16:35:05 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-26 16:35:05 --> Database Driver Class Initialized
DEBUG - 2011-04-26 16:35:06 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-26 16:35:06 --> Helper loaded: url_helper
DEBUG - 2011-04-26 16:35:06 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-26 16:35:06 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-26 16:35:06 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-26 16:35:06 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-26 16:35:06 --> Final output sent to browser
DEBUG - 2011-04-26 16:35:06 --> Total execution time: 0.3357
DEBUG - 2011-04-26 16:35:14 --> Config Class Initialized
DEBUG - 2011-04-26 16:35:14 --> Hooks Class Initialized
DEBUG - 2011-04-26 16:35:14 --> Utf8 Class Initialized
DEBUG - 2011-04-26 16:35:14 --> UTF-8 Support Enabled
DEBUG - 2011-04-26 16:35:14 --> URI Class Initialized
DEBUG - 2011-04-26 16:35:14 --> Router Class Initialized
DEBUG - 2011-04-26 16:35:14 --> Output Class Initialized
DEBUG - 2011-04-26 16:35:14 --> Input Class Initialized
DEBUG - 2011-04-26 16:35:14 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-26 16:35:14 --> Language Class Initialized
DEBUG - 2011-04-26 16:35:14 --> Loader Class Initialized
DEBUG - 2011-04-26 16:35:14 --> Controller Class Initialized
DEBUG - 2011-04-26 16:35:14 --> Model Class Initialized
DEBUG - 2011-04-26 16:35:14 --> Model Class Initialized
DEBUG - 2011-04-26 16:35:14 --> Model Class Initialized
DEBUG - 2011-04-26 16:35:14 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-26 16:35:14 --> Database Driver Class Initialized
DEBUG - 2011-04-26 16:35:14 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-26 16:35:15 --> Helper loaded: url_helper
DEBUG - 2011-04-26 16:35:15 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-26 16:35:15 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-26 16:35:15 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-26 16:35:15 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-26 16:35:15 --> Final output sent to browser
DEBUG - 2011-04-26 16:35:15 --> Total execution time: 0.6875
DEBUG - 2011-04-26 16:36:02 --> Config Class Initialized
DEBUG - 2011-04-26 16:36:02 --> Hooks Class Initialized
DEBUG - 2011-04-26 16:36:02 --> Utf8 Class Initialized
DEBUG - 2011-04-26 16:36:02 --> UTF-8 Support Enabled
DEBUG - 2011-04-26 16:36:02 --> URI Class Initialized
DEBUG - 2011-04-26 16:36:02 --> Router Class Initialized
DEBUG - 2011-04-26 16:36:02 --> Output Class Initialized
DEBUG - 2011-04-26 16:36:02 --> Input Class Initialized
DEBUG - 2011-04-26 16:36:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-26 16:36:02 --> Language Class Initialized
DEBUG - 2011-04-26 16:36:02 --> Loader Class Initialized
DEBUG - 2011-04-26 16:36:02 --> Controller Class Initialized
DEBUG - 2011-04-26 16:36:02 --> Model Class Initialized
DEBUG - 2011-04-26 16:36:02 --> Model Class Initialized
DEBUG - 2011-04-26 16:36:02 --> Model Class Initialized
DEBUG - 2011-04-26 16:36:02 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-26 16:36:02 --> Database Driver Class Initialized
DEBUG - 2011-04-26 16:36:02 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-26 16:36:02 --> Helper loaded: url_helper
DEBUG - 2011-04-26 16:36:02 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-26 16:36:02 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-26 16:36:02 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-26 16:36:02 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-26 16:36:02 --> Final output sent to browser
DEBUG - 2011-04-26 16:36:02 --> Total execution time: 0.3724
DEBUG - 2011-04-26 16:37:31 --> Config Class Initialized
DEBUG - 2011-04-26 16:37:31 --> Hooks Class Initialized
DEBUG - 2011-04-26 16:37:31 --> Utf8 Class Initialized
DEBUG - 2011-04-26 16:37:31 --> UTF-8 Support Enabled
DEBUG - 2011-04-26 16:37:31 --> URI Class Initialized
DEBUG - 2011-04-26 16:37:31 --> Router Class Initialized
DEBUG - 2011-04-26 16:37:31 --> Output Class Initialized
DEBUG - 2011-04-26 16:37:31 --> Input Class Initialized
DEBUG - 2011-04-26 16:37:31 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-26 16:37:31 --> Language Class Initialized
DEBUG - 2011-04-26 16:37:31 --> Loader Class Initialized
DEBUG - 2011-04-26 16:37:31 --> Controller Class Initialized
DEBUG - 2011-04-26 16:37:31 --> Model Class Initialized
DEBUG - 2011-04-26 16:37:31 --> Model Class Initialized
DEBUG - 2011-04-26 16:37:31 --> Model Class Initialized
DEBUG - 2011-04-26 16:37:31 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-26 16:37:32 --> Database Driver Class Initialized
DEBUG - 2011-04-26 16:37:33 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-26 16:37:33 --> Helper loaded: url_helper
DEBUG - 2011-04-26 16:37:33 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-26 16:37:33 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-26 16:37:33 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-26 16:37:33 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-26 16:37:33 --> Final output sent to browser
DEBUG - 2011-04-26 16:37:33 --> Total execution time: 1.3895
DEBUG - 2011-04-26 16:37:47 --> Config Class Initialized
DEBUG - 2011-04-26 16:37:47 --> Hooks Class Initialized
DEBUG - 2011-04-26 16:37:47 --> Utf8 Class Initialized
DEBUG - 2011-04-26 16:37:47 --> UTF-8 Support Enabled
DEBUG - 2011-04-26 16:37:47 --> URI Class Initialized
DEBUG - 2011-04-26 16:37:47 --> Router Class Initialized
DEBUG - 2011-04-26 16:37:47 --> Output Class Initialized
DEBUG - 2011-04-26 16:37:47 --> Input Class Initialized
DEBUG - 2011-04-26 16:37:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-26 16:37:47 --> Language Class Initialized
DEBUG - 2011-04-26 16:37:47 --> Loader Class Initialized
DEBUG - 2011-04-26 16:37:47 --> Controller Class Initialized
DEBUG - 2011-04-26 16:37:47 --> Model Class Initialized
DEBUG - 2011-04-26 16:37:47 --> Model Class Initialized
DEBUG - 2011-04-26 16:37:47 --> Model Class Initialized
DEBUG - 2011-04-26 16:37:47 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-26 16:37:47 --> Database Driver Class Initialized
DEBUG - 2011-04-26 16:37:47 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-26 16:37:47 --> Helper loaded: url_helper
DEBUG - 2011-04-26 16:37:47 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-26 16:37:47 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-26 16:37:47 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-26 16:37:47 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-26 16:37:47 --> Final output sent to browser
DEBUG - 2011-04-26 16:37:47 --> Total execution time: 0.2027
DEBUG - 2011-04-26 16:38:27 --> Config Class Initialized
DEBUG - 2011-04-26 16:38:27 --> Hooks Class Initialized
DEBUG - 2011-04-26 16:38:27 --> Utf8 Class Initialized
DEBUG - 2011-04-26 16:38:27 --> UTF-8 Support Enabled
DEBUG - 2011-04-26 16:38:27 --> URI Class Initialized
DEBUG - 2011-04-26 16:38:27 --> Router Class Initialized
DEBUG - 2011-04-26 16:38:27 --> Output Class Initialized
DEBUG - 2011-04-26 16:38:27 --> Input Class Initialized
DEBUG - 2011-04-26 16:38:27 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-26 16:38:27 --> Language Class Initialized
DEBUG - 2011-04-26 16:38:27 --> Loader Class Initialized
DEBUG - 2011-04-26 16:38:27 --> Controller Class Initialized
DEBUG - 2011-04-26 16:38:27 --> Model Class Initialized
DEBUG - 2011-04-26 16:38:27 --> Model Class Initialized
DEBUG - 2011-04-26 16:38:27 --> Model Class Initialized
DEBUG - 2011-04-26 16:38:27 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-26 16:38:27 --> Database Driver Class Initialized
DEBUG - 2011-04-26 16:38:27 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-26 16:38:27 --> Helper loaded: url_helper
DEBUG - 2011-04-26 16:38:27 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-26 16:38:27 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-26 16:38:27 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-26 16:38:27 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-26 16:38:27 --> Final output sent to browser
DEBUG - 2011-04-26 16:38:27 --> Total execution time: 0.4492
DEBUG - 2011-04-26 16:38:37 --> Config Class Initialized
DEBUG - 2011-04-26 16:38:37 --> Hooks Class Initialized
DEBUG - 2011-04-26 16:38:37 --> Utf8 Class Initialized
DEBUG - 2011-04-26 16:38:37 --> UTF-8 Support Enabled
DEBUG - 2011-04-26 16:38:37 --> URI Class Initialized
DEBUG - 2011-04-26 16:38:37 --> Router Class Initialized
DEBUG - 2011-04-26 16:38:37 --> Output Class Initialized
DEBUG - 2011-04-26 16:38:37 --> Input Class Initialized
DEBUG - 2011-04-26 16:38:37 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-26 16:38:37 --> Language Class Initialized
DEBUG - 2011-04-26 16:38:37 --> Loader Class Initialized
DEBUG - 2011-04-26 16:38:37 --> Controller Class Initialized
DEBUG - 2011-04-26 16:38:37 --> Model Class Initialized
DEBUG - 2011-04-26 16:38:37 --> Model Class Initialized
DEBUG - 2011-04-26 16:38:37 --> Model Class Initialized
DEBUG - 2011-04-26 16:38:37 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-26 16:38:37 --> Database Driver Class Initialized
DEBUG - 2011-04-26 16:38:38 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-26 16:38:38 --> Helper loaded: url_helper
DEBUG - 2011-04-26 16:38:38 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-26 16:38:38 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-26 16:38:38 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-26 16:38:38 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-26 16:38:38 --> Final output sent to browser
DEBUG - 2011-04-26 16:38:38 --> Total execution time: 0.4830
DEBUG - 2011-04-26 16:38:49 --> Config Class Initialized
DEBUG - 2011-04-26 16:38:49 --> Hooks Class Initialized
DEBUG - 2011-04-26 16:38:49 --> Utf8 Class Initialized
DEBUG - 2011-04-26 16:38:49 --> UTF-8 Support Enabled
DEBUG - 2011-04-26 16:38:49 --> URI Class Initialized
DEBUG - 2011-04-26 16:38:49 --> Router Class Initialized
DEBUG - 2011-04-26 16:38:49 --> Output Class Initialized
DEBUG - 2011-04-26 16:38:49 --> Input Class Initialized
DEBUG - 2011-04-26 16:38:49 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-26 16:38:49 --> Language Class Initialized
DEBUG - 2011-04-26 16:38:49 --> Loader Class Initialized
DEBUG - 2011-04-26 16:38:49 --> Controller Class Initialized
DEBUG - 2011-04-26 16:38:49 --> Model Class Initialized
DEBUG - 2011-04-26 16:38:49 --> Model Class Initialized
DEBUG - 2011-04-26 16:38:49 --> Model Class Initialized
DEBUG - 2011-04-26 16:38:49 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-26 16:38:49 --> Database Driver Class Initialized
DEBUG - 2011-04-26 16:38:49 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-26 16:38:49 --> Helper loaded: url_helper
DEBUG - 2011-04-26 16:38:49 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-26 16:38:49 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-26 16:38:49 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-26 16:38:49 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-26 16:38:49 --> Final output sent to browser
DEBUG - 2011-04-26 16:38:49 --> Total execution time: 0.2369
DEBUG - 2011-04-26 20:02:28 --> Config Class Initialized
DEBUG - 2011-04-26 20:02:28 --> Hooks Class Initialized
DEBUG - 2011-04-26 20:02:28 --> Utf8 Class Initialized
DEBUG - 2011-04-26 20:02:28 --> UTF-8 Support Enabled
DEBUG - 2011-04-26 20:02:28 --> URI Class Initialized
DEBUG - 2011-04-26 20:02:28 --> Router Class Initialized
DEBUG - 2011-04-26 20:02:28 --> Output Class Initialized
DEBUG - 2011-04-26 20:02:28 --> Input Class Initialized
DEBUG - 2011-04-26 20:02:28 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-26 20:02:28 --> Language Class Initialized
DEBUG - 2011-04-26 20:02:28 --> Loader Class Initialized
DEBUG - 2011-04-26 20:02:29 --> Controller Class Initialized
DEBUG - 2011-04-26 20:02:29 --> Model Class Initialized
DEBUG - 2011-04-26 20:02:29 --> Model Class Initialized
DEBUG - 2011-04-26 20:02:29 --> Model Class Initialized
DEBUG - 2011-04-26 20:02:29 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-26 20:02:30 --> Database Driver Class Initialized
DEBUG - 2011-04-26 20:02:30 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-26 20:02:30 --> Helper loaded: url_helper
DEBUG - 2011-04-26 20:02:30 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-26 20:02:30 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-26 20:02:30 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-26 20:02:30 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-26 20:02:30 --> Final output sent to browser
DEBUG - 2011-04-26 20:02:30 --> Total execution time: 2.1253
DEBUG - 2011-04-26 20:02:31 --> Config Class Initialized
DEBUG - 2011-04-26 20:02:31 --> Hooks Class Initialized
DEBUG - 2011-04-26 20:02:31 --> Utf8 Class Initialized
DEBUG - 2011-04-26 20:02:31 --> UTF-8 Support Enabled
DEBUG - 2011-04-26 20:02:31 --> URI Class Initialized
DEBUG - 2011-04-26 20:02:31 --> Router Class Initialized
DEBUG - 2011-04-26 20:02:31 --> Output Class Initialized
DEBUG - 2011-04-26 20:02:31 --> Input Class Initialized
DEBUG - 2011-04-26 20:02:31 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-26 20:02:31 --> Language Class Initialized
DEBUG - 2011-04-26 20:02:31 --> Loader Class Initialized
DEBUG - 2011-04-26 20:02:31 --> Controller Class Initialized
ERROR - 2011-04-26 20:02:31 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-26 20:02:31 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-26 20:02:31 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-26 20:02:31 --> Model Class Initialized
DEBUG - 2011-04-26 20:02:31 --> Model Class Initialized
DEBUG - 2011-04-26 20:02:31 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-26 20:02:31 --> Database Driver Class Initialized
DEBUG - 2011-04-26 20:02:31 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-26 20:02:31 --> Helper loaded: url_helper
DEBUG - 2011-04-26 20:02:31 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-26 20:02:31 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-26 20:02:31 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-26 20:02:31 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-26 20:02:31 --> Final output sent to browser
DEBUG - 2011-04-26 20:02:31 --> Total execution time: 0.2587
DEBUG - 2011-04-26 20:59:05 --> Config Class Initialized
DEBUG - 2011-04-26 20:59:05 --> Hooks Class Initialized
DEBUG - 2011-04-26 20:59:05 --> Utf8 Class Initialized
DEBUG - 2011-04-26 20:59:05 --> UTF-8 Support Enabled
DEBUG - 2011-04-26 20:59:05 --> URI Class Initialized
DEBUG - 2011-04-26 20:59:05 --> Router Class Initialized
ERROR - 2011-04-26 20:59:05 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-04-26 21:00:35 --> Config Class Initialized
DEBUG - 2011-04-26 21:00:35 --> Hooks Class Initialized
DEBUG - 2011-04-26 21:00:35 --> Utf8 Class Initialized
DEBUG - 2011-04-26 21:00:35 --> UTF-8 Support Enabled
DEBUG - 2011-04-26 21:00:35 --> URI Class Initialized
DEBUG - 2011-04-26 21:00:35 --> Router Class Initialized
DEBUG - 2011-04-26 21:00:35 --> No URI present. Default controller set.
DEBUG - 2011-04-26 21:00:35 --> Output Class Initialized
DEBUG - 2011-04-26 21:00:35 --> Input Class Initialized
DEBUG - 2011-04-26 21:00:35 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-26 21:00:35 --> Language Class Initialized
DEBUG - 2011-04-26 21:00:35 --> Loader Class Initialized
DEBUG - 2011-04-26 21:00:35 --> Controller Class Initialized
DEBUG - 2011-04-26 21:00:35 --> File loaded: application/views/splash/main.php
DEBUG - 2011-04-26 21:00:35 --> Helper loaded: url_helper
DEBUG - 2011-04-26 21:00:35 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-26 21:00:35 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-26 21:00:35 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-26 21:00:35 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-26 21:00:35 --> Final output sent to browser
DEBUG - 2011-04-26 21:00:35 --> Total execution time: 0.3330
DEBUG - 2011-04-26 22:41:46 --> Config Class Initialized
DEBUG - 2011-04-26 22:41:46 --> Hooks Class Initialized
DEBUG - 2011-04-26 22:41:46 --> Utf8 Class Initialized
DEBUG - 2011-04-26 22:41:46 --> UTF-8 Support Enabled
DEBUG - 2011-04-26 22:41:46 --> URI Class Initialized
DEBUG - 2011-04-26 22:41:46 --> Router Class Initialized
DEBUG - 2011-04-26 22:41:46 --> Output Class Initialized
DEBUG - 2011-04-26 22:41:46 --> Input Class Initialized
DEBUG - 2011-04-26 22:41:46 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-26 22:41:46 --> Language Class Initialized
DEBUG - 2011-04-26 22:41:46 --> Loader Class Initialized
DEBUG - 2011-04-26 22:41:46 --> Controller Class Initialized
DEBUG - 2011-04-26 22:41:46 --> Model Class Initialized
DEBUG - 2011-04-26 22:41:46 --> Model Class Initialized
DEBUG - 2011-04-26 22:41:46 --> Model Class Initialized
DEBUG - 2011-04-26 22:41:46 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-26 22:41:46 --> Database Driver Class Initialized
DEBUG - 2011-04-26 22:41:46 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-26 22:41:46 --> Helper loaded: url_helper
DEBUG - 2011-04-26 22:41:46 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-26 22:41:46 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-26 22:41:46 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-26 22:41:46 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-26 22:41:46 --> Final output sent to browser
DEBUG - 2011-04-26 22:41:46 --> Total execution time: 0.7913
DEBUG - 2011-04-26 22:41:47 --> Config Class Initialized
DEBUG - 2011-04-26 22:41:47 --> Hooks Class Initialized
DEBUG - 2011-04-26 22:41:47 --> Utf8 Class Initialized
DEBUG - 2011-04-26 22:41:47 --> UTF-8 Support Enabled
DEBUG - 2011-04-26 22:41:47 --> URI Class Initialized
DEBUG - 2011-04-26 22:41:47 --> Router Class Initialized
DEBUG - 2011-04-26 22:41:47 --> Output Class Initialized
DEBUG - 2011-04-26 22:41:47 --> Input Class Initialized
DEBUG - 2011-04-26 22:41:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-26 22:41:47 --> Language Class Initialized
DEBUG - 2011-04-26 22:41:47 --> Loader Class Initialized
DEBUG - 2011-04-26 22:41:47 --> Controller Class Initialized
ERROR - 2011-04-26 22:41:47 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-26 22:41:47 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-26 22:41:47 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-26 22:41:47 --> Model Class Initialized
DEBUG - 2011-04-26 22:41:47 --> Model Class Initialized
DEBUG - 2011-04-26 22:41:47 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-26 22:41:47 --> Database Driver Class Initialized
DEBUG - 2011-04-26 22:41:47 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-26 22:41:47 --> Helper loaded: url_helper
DEBUG - 2011-04-26 22:41:47 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-26 22:41:47 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-26 22:41:47 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-26 22:41:47 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-26 22:41:47 --> Final output sent to browser
DEBUG - 2011-04-26 22:41:47 --> Total execution time: 0.0809
DEBUG - 2011-04-26 23:04:58 --> Config Class Initialized
DEBUG - 2011-04-26 23:04:58 --> Hooks Class Initialized
DEBUG - 2011-04-26 23:04:58 --> Utf8 Class Initialized
DEBUG - 2011-04-26 23:04:58 --> UTF-8 Support Enabled
DEBUG - 2011-04-26 23:04:58 --> URI Class Initialized
DEBUG - 2011-04-26 23:04:58 --> Router Class Initialized
ERROR - 2011-04-26 23:04:58 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-04-26 23:04:58 --> Config Class Initialized
DEBUG - 2011-04-26 23:04:58 --> Hooks Class Initialized
DEBUG - 2011-04-26 23:04:58 --> Utf8 Class Initialized
DEBUG - 2011-04-26 23:04:58 --> UTF-8 Support Enabled
DEBUG - 2011-04-26 23:04:58 --> URI Class Initialized
DEBUG - 2011-04-26 23:04:58 --> Router Class Initialized
DEBUG - 2011-04-26 23:04:58 --> Output Class Initialized
DEBUG - 2011-04-26 23:04:58 --> Input Class Initialized
DEBUG - 2011-04-26 23:04:58 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-26 23:04:58 --> Language Class Initialized
DEBUG - 2011-04-26 23:04:59 --> Loader Class Initialized
DEBUG - 2011-04-26 23:04:59 --> Controller Class Initialized
DEBUG - 2011-04-26 23:04:59 --> Model Class Initialized
DEBUG - 2011-04-26 23:04:59 --> Model Class Initialized
DEBUG - 2011-04-26 23:04:59 --> Model Class Initialized
DEBUG - 2011-04-26 23:04:59 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-26 23:04:59 --> Database Driver Class Initialized
DEBUG - 2011-04-26 23:04:59 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-26 23:04:59 --> Helper loaded: url_helper
DEBUG - 2011-04-26 23:04:59 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-26 23:04:59 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-26 23:04:59 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-26 23:04:59 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-26 23:04:59 --> Final output sent to browser
DEBUG - 2011-04-26 23:04:59 --> Total execution time: 0.9180
DEBUG - 2011-04-26 23:09:50 --> Config Class Initialized
DEBUG - 2011-04-26 23:09:50 --> Hooks Class Initialized
DEBUG - 2011-04-26 23:09:50 --> Utf8 Class Initialized
DEBUG - 2011-04-26 23:09:50 --> UTF-8 Support Enabled
DEBUG - 2011-04-26 23:09:50 --> URI Class Initialized
DEBUG - 2011-04-26 23:09:50 --> Router Class Initialized
ERROR - 2011-04-26 23:09:50 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-04-26 23:09:50 --> Config Class Initialized
DEBUG - 2011-04-26 23:09:50 --> Hooks Class Initialized
DEBUG - 2011-04-26 23:09:50 --> Utf8 Class Initialized
DEBUG - 2011-04-26 23:09:50 --> UTF-8 Support Enabled
DEBUG - 2011-04-26 23:09:50 --> URI Class Initialized
DEBUG - 2011-04-26 23:09:50 --> Router Class Initialized
DEBUG - 2011-04-26 23:09:50 --> Output Class Initialized
DEBUG - 2011-04-26 23:09:50 --> Input Class Initialized
DEBUG - 2011-04-26 23:09:50 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-26 23:09:50 --> Language Class Initialized
DEBUG - 2011-04-26 23:09:50 --> Loader Class Initialized
DEBUG - 2011-04-26 23:09:50 --> Controller Class Initialized
DEBUG - 2011-04-26 23:09:50 --> Model Class Initialized
DEBUG - 2011-04-26 23:09:50 --> Model Class Initialized
DEBUG - 2011-04-26 23:09:50 --> Model Class Initialized
DEBUG - 2011-04-26 23:09:50 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-26 23:09:50 --> Database Driver Class Initialized
DEBUG - 2011-04-26 23:09:51 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-26 23:09:51 --> Helper loaded: url_helper
DEBUG - 2011-04-26 23:09:51 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-26 23:09:51 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-26 23:09:51 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-26 23:09:51 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-26 23:09:51 --> Final output sent to browser
DEBUG - 2011-04-26 23:09:51 --> Total execution time: 0.0596
DEBUG - 2011-04-26 23:32:09 --> Config Class Initialized
DEBUG - 2011-04-26 23:32:09 --> Hooks Class Initialized
DEBUG - 2011-04-26 23:32:09 --> Utf8 Class Initialized
DEBUG - 2011-04-26 23:32:09 --> UTF-8 Support Enabled
DEBUG - 2011-04-26 23:32:09 --> URI Class Initialized
DEBUG - 2011-04-26 23:32:09 --> Router Class Initialized
DEBUG - 2011-04-26 23:32:10 --> Output Class Initialized
DEBUG - 2011-04-26 23:32:10 --> Input Class Initialized
DEBUG - 2011-04-26 23:32:10 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-26 23:32:10 --> Language Class Initialized
DEBUG - 2011-04-26 23:32:10 --> Loader Class Initialized
DEBUG - 2011-04-26 23:32:10 --> Controller Class Initialized
DEBUG - 2011-04-26 23:32:10 --> Model Class Initialized
DEBUG - 2011-04-26 23:32:10 --> Model Class Initialized
DEBUG - 2011-04-26 23:32:10 --> Model Class Initialized
DEBUG - 2011-04-26 23:32:10 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-26 23:32:10 --> Database Driver Class Initialized
DEBUG - 2011-04-26 23:32:10 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-26 23:32:10 --> Helper loaded: url_helper
DEBUG - 2011-04-26 23:32:10 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-26 23:32:10 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-26 23:32:10 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-26 23:32:10 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-26 23:32:10 --> Final output sent to browser
DEBUG - 2011-04-26 23:32:10 --> Total execution time: 0.6872
DEBUG - 2011-04-26 23:38:43 --> Config Class Initialized
DEBUG - 2011-04-26 23:38:43 --> Hooks Class Initialized
DEBUG - 2011-04-26 23:38:43 --> Utf8 Class Initialized
DEBUG - 2011-04-26 23:38:43 --> UTF-8 Support Enabled
DEBUG - 2011-04-26 23:38:43 --> URI Class Initialized
DEBUG - 2011-04-26 23:38:43 --> Router Class Initialized
ERROR - 2011-04-26 23:38:43 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-04-26 23:39:31 --> Config Class Initialized
DEBUG - 2011-04-26 23:39:31 --> Hooks Class Initialized
DEBUG - 2011-04-26 23:39:31 --> Utf8 Class Initialized
DEBUG - 2011-04-26 23:39:31 --> UTF-8 Support Enabled
DEBUG - 2011-04-26 23:39:31 --> URI Class Initialized
DEBUG - 2011-04-26 23:39:31 --> Router Class Initialized
DEBUG - 2011-04-26 23:39:31 --> Output Class Initialized
DEBUG - 2011-04-26 23:39:31 --> Input Class Initialized
DEBUG - 2011-04-26 23:39:31 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-26 23:39:31 --> Language Class Initialized
DEBUG - 2011-04-26 23:39:31 --> Loader Class Initialized
DEBUG - 2011-04-26 23:39:31 --> Controller Class Initialized
ERROR - 2011-04-26 23:39:31 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-26 23:39:31 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-26 23:39:31 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-26 23:39:31 --> Model Class Initialized
DEBUG - 2011-04-26 23:39:31 --> Model Class Initialized
DEBUG - 2011-04-26 23:39:31 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-26 23:39:31 --> Database Driver Class Initialized
DEBUG - 2011-04-26 23:39:31 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-26 23:39:31 --> Helper loaded: url_helper
DEBUG - 2011-04-26 23:39:31 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-26 23:39:31 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-26 23:39:31 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-26 23:39:31 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-26 23:39:31 --> Final output sent to browser
DEBUG - 2011-04-26 23:39:31 --> Total execution time: 0.0956

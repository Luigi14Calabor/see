<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2011-09-26 00:16:03 --> Config Class Initialized
DEBUG - 2011-09-26 00:16:03 --> Hooks Class Initialized
DEBUG - 2011-09-26 00:16:03 --> Utf8 Class Initialized
DEBUG - 2011-09-26 00:16:03 --> UTF-8 Support Enabled
DEBUG - 2011-09-26 00:16:03 --> URI Class Initialized
DEBUG - 2011-09-26 00:16:03 --> Router Class Initialized
DEBUG - 2011-09-26 00:16:03 --> Output Class Initialized
DEBUG - 2011-09-26 00:16:03 --> Input Class Initialized
DEBUG - 2011-09-26 00:16:03 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-26 00:16:03 --> Language Class Initialized
DEBUG - 2011-09-26 00:16:03 --> Loader Class Initialized
DEBUG - 2011-09-26 00:16:03 --> Controller Class Initialized
DEBUG - 2011-09-26 00:16:03 --> Model Class Initialized
DEBUG - 2011-09-26 00:16:03 --> Model Class Initialized
DEBUG - 2011-09-26 00:16:03 --> Model Class Initialized
DEBUG - 2011-09-26 00:16:03 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-26 00:16:03 --> Database Driver Class Initialized
DEBUG - 2011-09-26 00:16:03 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-26 00:16:03 --> Helper loaded: url_helper
DEBUG - 2011-09-26 00:16:03 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-26 00:16:03 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-26 00:16:03 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-26 00:16:03 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-26 00:16:03 --> Final output sent to browser
DEBUG - 2011-09-26 00:16:03 --> Total execution time: 0.4671
DEBUG - 2011-09-26 00:16:06 --> Config Class Initialized
DEBUG - 2011-09-26 00:16:06 --> Hooks Class Initialized
DEBUG - 2011-09-26 00:16:06 --> Utf8 Class Initialized
DEBUG - 2011-09-26 00:16:06 --> UTF-8 Support Enabled
DEBUG - 2011-09-26 00:16:06 --> URI Class Initialized
DEBUG - 2011-09-26 00:16:06 --> Router Class Initialized
ERROR - 2011-09-26 00:16:06 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-26 00:42:37 --> Config Class Initialized
DEBUG - 2011-09-26 00:42:37 --> Hooks Class Initialized
DEBUG - 2011-09-26 00:42:37 --> Utf8 Class Initialized
DEBUG - 2011-09-26 00:42:37 --> UTF-8 Support Enabled
DEBUG - 2011-09-26 00:42:37 --> URI Class Initialized
DEBUG - 2011-09-26 00:42:37 --> Router Class Initialized
ERROR - 2011-09-26 00:42:37 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-09-26 00:42:38 --> Config Class Initialized
DEBUG - 2011-09-26 00:42:38 --> Hooks Class Initialized
DEBUG - 2011-09-26 00:42:38 --> Utf8 Class Initialized
DEBUG - 2011-09-26 00:42:38 --> UTF-8 Support Enabled
DEBUG - 2011-09-26 00:42:38 --> URI Class Initialized
DEBUG - 2011-09-26 00:42:38 --> Router Class Initialized
DEBUG - 2011-09-26 00:42:38 --> No URI present. Default controller set.
DEBUG - 2011-09-26 00:42:38 --> Output Class Initialized
DEBUG - 2011-09-26 00:42:38 --> Input Class Initialized
DEBUG - 2011-09-26 00:42:38 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-26 00:42:38 --> Language Class Initialized
DEBUG - 2011-09-26 00:42:38 --> Loader Class Initialized
DEBUG - 2011-09-26 00:42:38 --> Controller Class Initialized
DEBUG - 2011-09-26 00:42:38 --> File loaded: application/views/splash/main.php
DEBUG - 2011-09-26 00:42:38 --> Helper loaded: url_helper
DEBUG - 2011-09-26 00:42:38 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-26 00:42:38 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-26 00:42:38 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-26 00:42:38 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-26 00:42:38 --> Final output sent to browser
DEBUG - 2011-09-26 00:42:38 --> Total execution time: 0.1031
DEBUG - 2011-09-26 01:28:52 --> Config Class Initialized
DEBUG - 2011-09-26 01:28:52 --> Hooks Class Initialized
DEBUG - 2011-09-26 01:28:52 --> Utf8 Class Initialized
DEBUG - 2011-09-26 01:28:52 --> UTF-8 Support Enabled
DEBUG - 2011-09-26 01:28:52 --> URI Class Initialized
DEBUG - 2011-09-26 01:28:52 --> Router Class Initialized
DEBUG - 2011-09-26 01:28:52 --> No URI present. Default controller set.
DEBUG - 2011-09-26 01:28:52 --> Output Class Initialized
DEBUG - 2011-09-26 01:28:52 --> Input Class Initialized
DEBUG - 2011-09-26 01:28:52 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-26 01:28:52 --> Language Class Initialized
DEBUG - 2011-09-26 01:28:52 --> Loader Class Initialized
DEBUG - 2011-09-26 01:28:52 --> Controller Class Initialized
DEBUG - 2011-09-26 01:28:52 --> File loaded: application/views/splash/main.php
DEBUG - 2011-09-26 01:28:52 --> Helper loaded: url_helper
DEBUG - 2011-09-26 01:28:52 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-26 01:28:52 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-26 01:28:52 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-26 01:28:52 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-26 01:28:52 --> Final output sent to browser
DEBUG - 2011-09-26 01:28:52 --> Total execution time: 0.0555
DEBUG - 2011-09-26 01:42:04 --> Config Class Initialized
DEBUG - 2011-09-26 01:42:04 --> Hooks Class Initialized
DEBUG - 2011-09-26 01:42:04 --> Utf8 Class Initialized
DEBUG - 2011-09-26 01:42:04 --> UTF-8 Support Enabled
DEBUG - 2011-09-26 01:42:04 --> URI Class Initialized
DEBUG - 2011-09-26 01:42:04 --> Router Class Initialized
ERROR - 2011-09-26 01:42:04 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-09-26 01:43:08 --> Config Class Initialized
DEBUG - 2011-09-26 01:43:08 --> Hooks Class Initialized
DEBUG - 2011-09-26 01:43:08 --> Utf8 Class Initialized
DEBUG - 2011-09-26 01:43:08 --> UTF-8 Support Enabled
DEBUG - 2011-09-26 01:43:08 --> URI Class Initialized
DEBUG - 2011-09-26 01:43:08 --> Router Class Initialized
DEBUG - 2011-09-26 01:43:08 --> Output Class Initialized
DEBUG - 2011-09-26 01:43:08 --> Input Class Initialized
DEBUG - 2011-09-26 01:43:08 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-26 01:43:08 --> Language Class Initialized
DEBUG - 2011-09-26 01:43:08 --> Loader Class Initialized
DEBUG - 2011-09-26 01:43:08 --> Controller Class Initialized
DEBUG - 2011-09-26 01:43:08 --> Model Class Initialized
DEBUG - 2011-09-26 01:43:08 --> Model Class Initialized
DEBUG - 2011-09-26 01:43:08 --> Model Class Initialized
DEBUG - 2011-09-26 01:43:08 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-26 01:43:08 --> Database Driver Class Initialized
DEBUG - 2011-09-26 01:43:10 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-26 01:43:10 --> Helper loaded: url_helper
DEBUG - 2011-09-26 01:43:10 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-26 01:43:10 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-26 01:43:10 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-26 01:43:10 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-26 01:43:10 --> Final output sent to browser
DEBUG - 2011-09-26 01:43:10 --> Total execution time: 1.6599
DEBUG - 2011-09-26 03:20:25 --> Config Class Initialized
DEBUG - 2011-09-26 03:20:25 --> Hooks Class Initialized
DEBUG - 2011-09-26 03:20:25 --> Utf8 Class Initialized
DEBUG - 2011-09-26 03:20:25 --> UTF-8 Support Enabled
DEBUG - 2011-09-26 03:20:25 --> URI Class Initialized
DEBUG - 2011-09-26 03:20:25 --> Router Class Initialized
DEBUG - 2011-09-26 03:20:25 --> Output Class Initialized
DEBUG - 2011-09-26 03:20:25 --> Input Class Initialized
DEBUG - 2011-09-26 03:20:25 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-26 03:20:25 --> Language Class Initialized
DEBUG - 2011-09-26 03:20:25 --> Loader Class Initialized
DEBUG - 2011-09-26 03:20:25 --> Controller Class Initialized
DEBUG - 2011-09-26 03:20:25 --> Model Class Initialized
DEBUG - 2011-09-26 03:20:25 --> Model Class Initialized
DEBUG - 2011-09-26 03:20:25 --> Model Class Initialized
DEBUG - 2011-09-26 03:20:25 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-26 03:20:25 --> Database Driver Class Initialized
DEBUG - 2011-09-26 03:20:27 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-26 03:20:27 --> Helper loaded: url_helper
DEBUG - 2011-09-26 03:20:27 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-26 03:20:27 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-26 03:20:27 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-26 03:20:27 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-26 03:20:27 --> Final output sent to browser
DEBUG - 2011-09-26 03:20:27 --> Total execution time: 2.1740
DEBUG - 2011-09-26 03:20:29 --> Config Class Initialized
DEBUG - 2011-09-26 03:20:29 --> Hooks Class Initialized
DEBUG - 2011-09-26 03:20:29 --> Utf8 Class Initialized
DEBUG - 2011-09-26 03:20:29 --> UTF-8 Support Enabled
DEBUG - 2011-09-26 03:20:29 --> URI Class Initialized
DEBUG - 2011-09-26 03:20:29 --> Router Class Initialized
ERROR - 2011-09-26 03:20:29 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-26 03:20:31 --> Config Class Initialized
DEBUG - 2011-09-26 03:20:31 --> Hooks Class Initialized
DEBUG - 2011-09-26 03:20:31 --> Utf8 Class Initialized
DEBUG - 2011-09-26 03:20:31 --> UTF-8 Support Enabled
DEBUG - 2011-09-26 03:20:31 --> URI Class Initialized
DEBUG - 2011-09-26 03:20:31 --> Router Class Initialized
ERROR - 2011-09-26 03:20:31 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-26 03:20:45 --> Config Class Initialized
DEBUG - 2011-09-26 03:20:45 --> Hooks Class Initialized
DEBUG - 2011-09-26 03:20:45 --> Utf8 Class Initialized
DEBUG - 2011-09-26 03:20:45 --> UTF-8 Support Enabled
DEBUG - 2011-09-26 03:20:45 --> URI Class Initialized
DEBUG - 2011-09-26 03:20:45 --> Router Class Initialized
DEBUG - 2011-09-26 03:20:45 --> Output Class Initialized
DEBUG - 2011-09-26 03:20:45 --> Input Class Initialized
DEBUG - 2011-09-26 03:20:45 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-26 03:20:45 --> Language Class Initialized
DEBUG - 2011-09-26 03:20:45 --> Loader Class Initialized
DEBUG - 2011-09-26 03:20:45 --> Controller Class Initialized
DEBUG - 2011-09-26 03:20:45 --> Model Class Initialized
DEBUG - 2011-09-26 03:20:45 --> Model Class Initialized
DEBUG - 2011-09-26 03:20:45 --> Model Class Initialized
DEBUG - 2011-09-26 03:20:45 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-26 03:20:45 --> Database Driver Class Initialized
DEBUG - 2011-09-26 03:20:46 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-26 03:20:46 --> Helper loaded: url_helper
DEBUG - 2011-09-26 03:20:46 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-26 03:20:46 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-26 03:20:46 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-26 03:20:46 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-26 03:20:46 --> Final output sent to browser
DEBUG - 2011-09-26 03:20:46 --> Total execution time: 0.1058
DEBUG - 2011-09-26 03:20:47 --> Config Class Initialized
DEBUG - 2011-09-26 03:20:47 --> Hooks Class Initialized
DEBUG - 2011-09-26 03:20:47 --> Utf8 Class Initialized
DEBUG - 2011-09-26 03:20:47 --> UTF-8 Support Enabled
DEBUG - 2011-09-26 03:20:47 --> URI Class Initialized
DEBUG - 2011-09-26 03:20:47 --> Router Class Initialized
ERROR - 2011-09-26 03:20:47 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-26 03:20:48 --> Config Class Initialized
DEBUG - 2011-09-26 03:20:48 --> Hooks Class Initialized
DEBUG - 2011-09-26 03:20:48 --> Utf8 Class Initialized
DEBUG - 2011-09-26 03:20:48 --> UTF-8 Support Enabled
DEBUG - 2011-09-26 03:20:48 --> URI Class Initialized
DEBUG - 2011-09-26 03:20:48 --> Router Class Initialized
DEBUG - 2011-09-26 03:20:48 --> Output Class Initialized
DEBUG - 2011-09-26 03:20:48 --> Input Class Initialized
DEBUG - 2011-09-26 03:20:48 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-26 03:20:48 --> Language Class Initialized
DEBUG - 2011-09-26 03:20:48 --> Loader Class Initialized
DEBUG - 2011-09-26 03:20:48 --> Controller Class Initialized
DEBUG - 2011-09-26 03:20:48 --> Model Class Initialized
DEBUG - 2011-09-26 03:20:48 --> Model Class Initialized
DEBUG - 2011-09-26 03:20:48 --> Model Class Initialized
DEBUG - 2011-09-26 03:20:48 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-26 03:20:48 --> Database Driver Class Initialized
DEBUG - 2011-09-26 03:20:48 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-26 03:20:48 --> Helper loaded: url_helper
DEBUG - 2011-09-26 03:20:48 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-26 03:20:48 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-26 03:20:48 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-26 03:20:48 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-26 03:20:48 --> Final output sent to browser
DEBUG - 2011-09-26 03:20:48 --> Total execution time: 0.0503
DEBUG - 2011-09-26 03:20:56 --> Config Class Initialized
DEBUG - 2011-09-26 03:20:56 --> Hooks Class Initialized
DEBUG - 2011-09-26 03:20:56 --> Utf8 Class Initialized
DEBUG - 2011-09-26 03:20:56 --> UTF-8 Support Enabled
DEBUG - 2011-09-26 03:20:56 --> URI Class Initialized
DEBUG - 2011-09-26 03:20:56 --> Router Class Initialized
ERROR - 2011-09-26 03:20:56 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-09-26 03:20:56 --> Config Class Initialized
DEBUG - 2011-09-26 03:20:56 --> Hooks Class Initialized
DEBUG - 2011-09-26 03:20:56 --> Utf8 Class Initialized
DEBUG - 2011-09-26 03:20:56 --> UTF-8 Support Enabled
DEBUG - 2011-09-26 03:20:56 --> URI Class Initialized
DEBUG - 2011-09-26 03:20:56 --> Router Class Initialized
DEBUG - 2011-09-26 03:20:56 --> Output Class Initialized
DEBUG - 2011-09-26 03:20:56 --> Input Class Initialized
DEBUG - 2011-09-26 03:20:56 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-26 03:20:56 --> Language Class Initialized
DEBUG - 2011-09-26 03:20:56 --> Loader Class Initialized
DEBUG - 2011-09-26 03:20:56 --> Controller Class Initialized
DEBUG - 2011-09-26 03:20:56 --> Model Class Initialized
DEBUG - 2011-09-26 03:20:56 --> Model Class Initialized
DEBUG - 2011-09-26 03:20:56 --> Model Class Initialized
DEBUG - 2011-09-26 03:20:56 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-26 03:20:56 --> Database Driver Class Initialized
DEBUG - 2011-09-26 03:20:56 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-26 03:20:56 --> Helper loaded: url_helper
DEBUG - 2011-09-26 03:20:56 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-26 03:20:56 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-26 03:20:56 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-26 03:20:56 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-26 03:20:56 --> Final output sent to browser
DEBUG - 2011-09-26 03:20:56 --> Total execution time: 0.1085
DEBUG - 2011-09-26 03:21:01 --> Config Class Initialized
DEBUG - 2011-09-26 03:21:01 --> Hooks Class Initialized
DEBUG - 2011-09-26 03:21:01 --> Utf8 Class Initialized
DEBUG - 2011-09-26 03:21:01 --> UTF-8 Support Enabled
DEBUG - 2011-09-26 03:21:01 --> URI Class Initialized
DEBUG - 2011-09-26 03:21:01 --> Router Class Initialized
DEBUG - 2011-09-26 03:21:01 --> Output Class Initialized
DEBUG - 2011-09-26 03:21:01 --> Input Class Initialized
DEBUG - 2011-09-26 03:21:01 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-26 03:21:01 --> Language Class Initialized
DEBUG - 2011-09-26 03:21:01 --> Loader Class Initialized
DEBUG - 2011-09-26 03:21:01 --> Controller Class Initialized
DEBUG - 2011-09-26 03:21:01 --> Model Class Initialized
DEBUG - 2011-09-26 03:21:01 --> Model Class Initialized
DEBUG - 2011-09-26 03:21:01 --> Model Class Initialized
DEBUG - 2011-09-26 03:21:01 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-26 03:21:01 --> Database Driver Class Initialized
DEBUG - 2011-09-26 03:21:01 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-26 03:21:01 --> Helper loaded: url_helper
DEBUG - 2011-09-26 03:21:01 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-26 03:21:01 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-26 03:21:01 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-26 03:21:01 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-26 03:21:01 --> Final output sent to browser
DEBUG - 2011-09-26 03:21:01 --> Total execution time: 0.2107
DEBUG - 2011-09-26 03:21:02 --> Config Class Initialized
DEBUG - 2011-09-26 03:21:02 --> Hooks Class Initialized
DEBUG - 2011-09-26 03:21:02 --> Utf8 Class Initialized
DEBUG - 2011-09-26 03:21:02 --> UTF-8 Support Enabled
DEBUG - 2011-09-26 03:21:02 --> URI Class Initialized
DEBUG - 2011-09-26 03:21:02 --> Router Class Initialized
ERROR - 2011-09-26 03:21:02 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-26 03:21:09 --> Config Class Initialized
DEBUG - 2011-09-26 03:21:09 --> Hooks Class Initialized
DEBUG - 2011-09-26 03:21:09 --> Utf8 Class Initialized
DEBUG - 2011-09-26 03:21:09 --> UTF-8 Support Enabled
DEBUG - 2011-09-26 03:21:09 --> URI Class Initialized
DEBUG - 2011-09-26 03:21:09 --> Router Class Initialized
DEBUG - 2011-09-26 03:21:09 --> Output Class Initialized
DEBUG - 2011-09-26 03:21:09 --> Input Class Initialized
DEBUG - 2011-09-26 03:21:09 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-26 03:21:09 --> Language Class Initialized
DEBUG - 2011-09-26 03:21:09 --> Loader Class Initialized
DEBUG - 2011-09-26 03:21:09 --> Controller Class Initialized
DEBUG - 2011-09-26 03:21:09 --> Model Class Initialized
DEBUG - 2011-09-26 03:21:09 --> Model Class Initialized
DEBUG - 2011-09-26 03:21:09 --> Model Class Initialized
DEBUG - 2011-09-26 03:21:09 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-26 03:21:09 --> Database Driver Class Initialized
DEBUG - 2011-09-26 03:21:10 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-26 03:21:10 --> Helper loaded: url_helper
DEBUG - 2011-09-26 03:21:10 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-26 03:21:10 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-26 03:21:10 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-26 03:21:10 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-26 03:21:10 --> Final output sent to browser
DEBUG - 2011-09-26 03:21:10 --> Total execution time: 1.0768
DEBUG - 2011-09-26 03:21:11 --> Config Class Initialized
DEBUG - 2011-09-26 03:21:11 --> Hooks Class Initialized
DEBUG - 2011-09-26 03:21:11 --> Utf8 Class Initialized
DEBUG - 2011-09-26 03:21:11 --> UTF-8 Support Enabled
DEBUG - 2011-09-26 03:21:11 --> URI Class Initialized
DEBUG - 2011-09-26 03:21:11 --> Router Class Initialized
DEBUG - 2011-09-26 03:21:11 --> Output Class Initialized
DEBUG - 2011-09-26 03:21:11 --> Input Class Initialized
DEBUG - 2011-09-26 03:21:11 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-26 03:21:11 --> Language Class Initialized
DEBUG - 2011-09-26 03:21:11 --> Loader Class Initialized
DEBUG - 2011-09-26 03:21:11 --> Controller Class Initialized
DEBUG - 2011-09-26 03:21:11 --> Model Class Initialized
DEBUG - 2011-09-26 03:21:11 --> Model Class Initialized
DEBUG - 2011-09-26 03:21:11 --> Model Class Initialized
DEBUG - 2011-09-26 03:21:11 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-26 03:21:11 --> Database Driver Class Initialized
DEBUG - 2011-09-26 03:21:11 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-26 03:21:11 --> Helper loaded: url_helper
DEBUG - 2011-09-26 03:21:11 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-26 03:21:11 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-26 03:21:11 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-26 03:21:11 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-26 03:21:11 --> Final output sent to browser
DEBUG - 2011-09-26 03:21:11 --> Total execution time: 0.1268
DEBUG - 2011-09-26 03:21:11 --> Config Class Initialized
DEBUG - 2011-09-26 03:21:11 --> Hooks Class Initialized
DEBUG - 2011-09-26 03:21:11 --> Utf8 Class Initialized
DEBUG - 2011-09-26 03:21:11 --> UTF-8 Support Enabled
DEBUG - 2011-09-26 03:21:11 --> URI Class Initialized
DEBUG - 2011-09-26 03:21:11 --> Router Class Initialized
ERROR - 2011-09-26 03:21:11 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-26 03:21:14 --> Config Class Initialized
DEBUG - 2011-09-26 03:21:14 --> Hooks Class Initialized
DEBUG - 2011-09-26 03:21:14 --> Utf8 Class Initialized
DEBUG - 2011-09-26 03:21:14 --> UTF-8 Support Enabled
DEBUG - 2011-09-26 03:21:14 --> URI Class Initialized
DEBUG - 2011-09-26 03:21:14 --> Router Class Initialized
DEBUG - 2011-09-26 03:21:14 --> No URI present. Default controller set.
DEBUG - 2011-09-26 03:21:14 --> Output Class Initialized
DEBUG - 2011-09-26 03:21:14 --> Input Class Initialized
DEBUG - 2011-09-26 03:21:14 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-26 03:21:14 --> Language Class Initialized
DEBUG - 2011-09-26 03:21:14 --> Loader Class Initialized
DEBUG - 2011-09-26 03:21:14 --> Controller Class Initialized
DEBUG - 2011-09-26 03:21:14 --> File loaded: application/views/splash/main.php
DEBUG - 2011-09-26 03:21:14 --> Helper loaded: url_helper
DEBUG - 2011-09-26 03:21:14 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-26 03:21:14 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-26 03:21:14 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-26 03:21:14 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-26 03:21:14 --> Final output sent to browser
DEBUG - 2011-09-26 03:21:14 --> Total execution time: 0.0586
DEBUG - 2011-09-26 03:21:19 --> Config Class Initialized
DEBUG - 2011-09-26 03:21:19 --> Hooks Class Initialized
DEBUG - 2011-09-26 03:21:19 --> Utf8 Class Initialized
DEBUG - 2011-09-26 03:21:19 --> UTF-8 Support Enabled
DEBUG - 2011-09-26 03:21:19 --> URI Class Initialized
DEBUG - 2011-09-26 03:21:19 --> Router Class Initialized
DEBUG - 2011-09-26 03:21:19 --> Output Class Initialized
DEBUG - 2011-09-26 03:21:19 --> Input Class Initialized
DEBUG - 2011-09-26 03:21:19 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-26 03:21:19 --> Language Class Initialized
DEBUG - 2011-09-26 03:21:19 --> Loader Class Initialized
DEBUG - 2011-09-26 03:21:19 --> Controller Class Initialized
DEBUG - 2011-09-26 03:21:19 --> Model Class Initialized
DEBUG - 2011-09-26 03:21:19 --> Model Class Initialized
DEBUG - 2011-09-26 03:21:19 --> Model Class Initialized
DEBUG - 2011-09-26 03:21:19 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-26 03:21:19 --> Database Driver Class Initialized
DEBUG - 2011-09-26 03:21:20 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-26 03:21:20 --> Helper loaded: url_helper
DEBUG - 2011-09-26 03:21:20 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-26 03:21:20 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-26 03:21:20 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-26 03:21:20 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-26 03:21:20 --> Final output sent to browser
DEBUG - 2011-09-26 03:21:20 --> Total execution time: 0.3800
DEBUG - 2011-09-26 03:21:21 --> Config Class Initialized
DEBUG - 2011-09-26 03:21:21 --> Hooks Class Initialized
DEBUG - 2011-09-26 03:21:21 --> Utf8 Class Initialized
DEBUG - 2011-09-26 03:21:21 --> UTF-8 Support Enabled
DEBUG - 2011-09-26 03:21:21 --> URI Class Initialized
DEBUG - 2011-09-26 03:21:21 --> Router Class Initialized
ERROR - 2011-09-26 03:21:21 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-26 03:21:22 --> Config Class Initialized
DEBUG - 2011-09-26 03:21:22 --> Hooks Class Initialized
DEBUG - 2011-09-26 03:21:22 --> Utf8 Class Initialized
DEBUG - 2011-09-26 03:21:22 --> UTF-8 Support Enabled
DEBUG - 2011-09-26 03:21:22 --> URI Class Initialized
DEBUG - 2011-09-26 03:21:22 --> Router Class Initialized
DEBUG - 2011-09-26 03:21:22 --> Output Class Initialized
DEBUG - 2011-09-26 03:21:22 --> Input Class Initialized
DEBUG - 2011-09-26 03:21:22 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-26 03:21:22 --> Language Class Initialized
DEBUG - 2011-09-26 03:21:22 --> Loader Class Initialized
DEBUG - 2011-09-26 03:21:22 --> Controller Class Initialized
DEBUG - 2011-09-26 03:21:22 --> Model Class Initialized
DEBUG - 2011-09-26 03:21:22 --> Model Class Initialized
DEBUG - 2011-09-26 03:21:22 --> Model Class Initialized
DEBUG - 2011-09-26 03:21:22 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-26 03:21:22 --> Database Driver Class Initialized
DEBUG - 2011-09-26 03:21:22 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-26 03:21:22 --> Helper loaded: url_helper
DEBUG - 2011-09-26 03:21:22 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-26 03:21:22 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-26 03:21:22 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-26 03:21:22 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-26 03:21:22 --> Final output sent to browser
DEBUG - 2011-09-26 03:21:22 --> Total execution time: 0.0824
DEBUG - 2011-09-26 03:21:35 --> Config Class Initialized
DEBUG - 2011-09-26 03:21:35 --> Hooks Class Initialized
DEBUG - 2011-09-26 03:21:35 --> Utf8 Class Initialized
DEBUG - 2011-09-26 03:21:35 --> UTF-8 Support Enabled
DEBUG - 2011-09-26 03:21:35 --> URI Class Initialized
DEBUG - 2011-09-26 03:21:35 --> Router Class Initialized
DEBUG - 2011-09-26 03:21:36 --> Output Class Initialized
DEBUG - 2011-09-26 03:21:36 --> Input Class Initialized
DEBUG - 2011-09-26 03:21:36 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-26 03:21:36 --> Language Class Initialized
DEBUG - 2011-09-26 03:21:36 --> Loader Class Initialized
DEBUG - 2011-09-26 03:21:36 --> Controller Class Initialized
DEBUG - 2011-09-26 03:21:36 --> Model Class Initialized
DEBUG - 2011-09-26 03:21:36 --> Model Class Initialized
DEBUG - 2011-09-26 03:21:36 --> Model Class Initialized
DEBUG - 2011-09-26 03:21:36 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-26 03:21:36 --> Database Driver Class Initialized
DEBUG - 2011-09-26 03:21:37 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-26 03:21:37 --> Helper loaded: url_helper
DEBUG - 2011-09-26 03:21:37 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-26 03:21:37 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-26 03:21:37 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-26 03:21:37 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-26 03:21:37 --> Final output sent to browser
DEBUG - 2011-09-26 03:21:37 --> Total execution time: 1.5578
DEBUG - 2011-09-26 03:21:38 --> Config Class Initialized
DEBUG - 2011-09-26 03:21:38 --> Hooks Class Initialized
DEBUG - 2011-09-26 03:21:38 --> Utf8 Class Initialized
DEBUG - 2011-09-26 03:21:38 --> UTF-8 Support Enabled
DEBUG - 2011-09-26 03:21:38 --> URI Class Initialized
DEBUG - 2011-09-26 03:21:38 --> Router Class Initialized
ERROR - 2011-09-26 03:21:38 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-26 03:21:42 --> Config Class Initialized
DEBUG - 2011-09-26 03:21:42 --> Hooks Class Initialized
DEBUG - 2011-09-26 03:21:42 --> Utf8 Class Initialized
DEBUG - 2011-09-26 03:21:42 --> UTF-8 Support Enabled
DEBUG - 2011-09-26 03:21:42 --> URI Class Initialized
DEBUG - 2011-09-26 03:21:42 --> Router Class Initialized
DEBUG - 2011-09-26 03:21:42 --> Output Class Initialized
DEBUG - 2011-09-26 03:21:42 --> Input Class Initialized
DEBUG - 2011-09-26 03:21:42 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-26 03:21:42 --> Language Class Initialized
DEBUG - 2011-09-26 03:21:42 --> Loader Class Initialized
DEBUG - 2011-09-26 03:21:42 --> Controller Class Initialized
DEBUG - 2011-09-26 03:21:42 --> Model Class Initialized
DEBUG - 2011-09-26 03:21:42 --> Model Class Initialized
DEBUG - 2011-09-26 03:21:42 --> Model Class Initialized
DEBUG - 2011-09-26 03:21:42 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-26 03:21:42 --> Database Driver Class Initialized
DEBUG - 2011-09-26 03:21:42 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-26 03:21:42 --> Helper loaded: url_helper
DEBUG - 2011-09-26 03:21:42 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-26 03:21:42 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-26 03:21:42 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-26 03:21:42 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-26 03:21:42 --> Final output sent to browser
DEBUG - 2011-09-26 03:21:42 --> Total execution time: 0.1202
DEBUG - 2011-09-26 03:22:42 --> Config Class Initialized
DEBUG - 2011-09-26 03:22:42 --> Hooks Class Initialized
DEBUG - 2011-09-26 03:22:42 --> Utf8 Class Initialized
DEBUG - 2011-09-26 03:22:42 --> UTF-8 Support Enabled
DEBUG - 2011-09-26 03:22:42 --> URI Class Initialized
DEBUG - 2011-09-26 03:22:42 --> Router Class Initialized
ERROR - 2011-09-26 03:22:42 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-26 03:23:15 --> Config Class Initialized
DEBUG - 2011-09-26 03:23:15 --> Hooks Class Initialized
DEBUG - 2011-09-26 03:23:15 --> Utf8 Class Initialized
DEBUG - 2011-09-26 03:23:15 --> UTF-8 Support Enabled
DEBUG - 2011-09-26 03:23:15 --> URI Class Initialized
DEBUG - 2011-09-26 03:23:15 --> Router Class Initialized
DEBUG - 2011-09-26 03:23:15 --> Output Class Initialized
DEBUG - 2011-09-26 03:23:15 --> Input Class Initialized
DEBUG - 2011-09-26 03:23:15 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-26 03:23:15 --> Language Class Initialized
DEBUG - 2011-09-26 03:23:15 --> Loader Class Initialized
DEBUG - 2011-09-26 03:23:15 --> Controller Class Initialized
ERROR - 2011-09-26 03:23:15 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-26 03:23:15 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-26 03:23:15 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-26 03:23:15 --> Model Class Initialized
DEBUG - 2011-09-26 03:23:15 --> Model Class Initialized
DEBUG - 2011-09-26 03:23:15 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-26 03:23:15 --> Database Driver Class Initialized
DEBUG - 2011-09-26 03:23:15 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-26 03:23:15 --> Helper loaded: url_helper
DEBUG - 2011-09-26 03:23:15 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-26 03:23:15 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-26 03:23:15 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-26 03:23:15 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-26 03:23:15 --> Final output sent to browser
DEBUG - 2011-09-26 03:23:15 --> Total execution time: 0.0868
DEBUG - 2011-09-26 03:23:16 --> Config Class Initialized
DEBUG - 2011-09-26 03:23:16 --> Hooks Class Initialized
DEBUG - 2011-09-26 03:23:16 --> Utf8 Class Initialized
DEBUG - 2011-09-26 03:23:16 --> UTF-8 Support Enabled
DEBUG - 2011-09-26 03:23:16 --> URI Class Initialized
DEBUG - 2011-09-26 03:23:16 --> Router Class Initialized
DEBUG - 2011-09-26 03:23:16 --> Output Class Initialized
DEBUG - 2011-09-26 03:23:16 --> Input Class Initialized
DEBUG - 2011-09-26 03:23:16 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-26 03:23:16 --> Language Class Initialized
DEBUG - 2011-09-26 03:23:16 --> Loader Class Initialized
DEBUG - 2011-09-26 03:23:16 --> Controller Class Initialized
DEBUG - 2011-09-26 03:23:16 --> Model Class Initialized
DEBUG - 2011-09-26 03:23:16 --> Model Class Initialized
DEBUG - 2011-09-26 03:23:16 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-26 03:23:16 --> Database Driver Class Initialized
DEBUG - 2011-09-26 03:23:17 --> Final output sent to browser
DEBUG - 2011-09-26 03:23:17 --> Total execution time: 0.9605
DEBUG - 2011-09-26 03:23:19 --> Config Class Initialized
DEBUG - 2011-09-26 03:23:19 --> Hooks Class Initialized
DEBUG - 2011-09-26 03:23:19 --> Utf8 Class Initialized
DEBUG - 2011-09-26 03:23:19 --> UTF-8 Support Enabled
DEBUG - 2011-09-26 03:23:19 --> URI Class Initialized
DEBUG - 2011-09-26 03:23:19 --> Router Class Initialized
ERROR - 2011-09-26 03:23:19 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-26 03:23:26 --> Config Class Initialized
DEBUG - 2011-09-26 03:23:26 --> Hooks Class Initialized
DEBUG - 2011-09-26 03:23:26 --> Utf8 Class Initialized
DEBUG - 2011-09-26 03:23:26 --> UTF-8 Support Enabled
DEBUG - 2011-09-26 03:23:26 --> URI Class Initialized
DEBUG - 2011-09-26 03:23:26 --> Router Class Initialized
DEBUG - 2011-09-26 03:23:26 --> Output Class Initialized
DEBUG - 2011-09-26 03:23:26 --> Input Class Initialized
DEBUG - 2011-09-26 03:23:26 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-26 03:23:26 --> Language Class Initialized
DEBUG - 2011-09-26 03:23:26 --> Loader Class Initialized
DEBUG - 2011-09-26 03:23:26 --> Controller Class Initialized
ERROR - 2011-09-26 03:23:26 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-26 03:23:26 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-26 03:23:26 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-26 03:23:26 --> Model Class Initialized
DEBUG - 2011-09-26 03:23:26 --> Model Class Initialized
DEBUG - 2011-09-26 03:23:26 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-26 03:23:26 --> Database Driver Class Initialized
DEBUG - 2011-09-26 03:23:26 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-26 03:23:26 --> Helper loaded: url_helper
DEBUG - 2011-09-26 03:23:26 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-26 03:23:26 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-26 03:23:26 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-26 03:23:26 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-26 03:23:26 --> Final output sent to browser
DEBUG - 2011-09-26 03:23:26 --> Total execution time: 0.0428
DEBUG - 2011-09-26 03:23:27 --> Config Class Initialized
DEBUG - 2011-09-26 03:23:27 --> Hooks Class Initialized
DEBUG - 2011-09-26 03:23:27 --> Utf8 Class Initialized
DEBUG - 2011-09-26 03:23:27 --> UTF-8 Support Enabled
DEBUG - 2011-09-26 03:23:27 --> URI Class Initialized
DEBUG - 2011-09-26 03:23:27 --> Router Class Initialized
DEBUG - 2011-09-26 03:23:27 --> Output Class Initialized
DEBUG - 2011-09-26 03:23:27 --> Input Class Initialized
DEBUG - 2011-09-26 03:23:27 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-26 03:23:27 --> Language Class Initialized
DEBUG - 2011-09-26 03:23:27 --> Loader Class Initialized
DEBUG - 2011-09-26 03:23:27 --> Controller Class Initialized
DEBUG - 2011-09-26 03:23:27 --> Model Class Initialized
DEBUG - 2011-09-26 03:23:27 --> Model Class Initialized
DEBUG - 2011-09-26 03:23:27 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-26 03:23:27 --> Database Driver Class Initialized
DEBUG - 2011-09-26 03:23:27 --> Final output sent to browser
DEBUG - 2011-09-26 03:23:27 --> Total execution time: 0.7076
DEBUG - 2011-09-26 03:23:28 --> Config Class Initialized
DEBUG - 2011-09-26 03:23:28 --> Hooks Class Initialized
DEBUG - 2011-09-26 03:23:28 --> Utf8 Class Initialized
DEBUG - 2011-09-26 03:23:28 --> UTF-8 Support Enabled
DEBUG - 2011-09-26 03:23:28 --> URI Class Initialized
DEBUG - 2011-09-26 03:23:28 --> Router Class Initialized
ERROR - 2011-09-26 03:23:28 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-26 03:23:36 --> Config Class Initialized
DEBUG - 2011-09-26 03:23:36 --> Hooks Class Initialized
DEBUG - 2011-09-26 03:23:36 --> Utf8 Class Initialized
DEBUG - 2011-09-26 03:23:36 --> UTF-8 Support Enabled
DEBUG - 2011-09-26 03:23:36 --> URI Class Initialized
DEBUG - 2011-09-26 03:23:36 --> Router Class Initialized
DEBUG - 2011-09-26 03:23:36 --> Output Class Initialized
DEBUG - 2011-09-26 03:23:36 --> Input Class Initialized
DEBUG - 2011-09-26 03:23:36 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-26 03:23:36 --> Language Class Initialized
DEBUG - 2011-09-26 03:23:36 --> Loader Class Initialized
DEBUG - 2011-09-26 03:23:36 --> Controller Class Initialized
ERROR - 2011-09-26 03:23:36 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-26 03:23:36 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-26 03:23:36 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-26 03:23:36 --> Model Class Initialized
DEBUG - 2011-09-26 03:23:36 --> Model Class Initialized
DEBUG - 2011-09-26 03:23:36 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-26 03:23:36 --> Database Driver Class Initialized
DEBUG - 2011-09-26 03:23:36 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-26 03:23:36 --> Helper loaded: url_helper
DEBUG - 2011-09-26 03:23:36 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-26 03:23:36 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-26 03:23:36 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-26 03:23:36 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-26 03:23:36 --> Final output sent to browser
DEBUG - 2011-09-26 03:23:36 --> Total execution time: 0.0713
DEBUG - 2011-09-26 03:23:37 --> Config Class Initialized
DEBUG - 2011-09-26 03:23:37 --> Hooks Class Initialized
DEBUG - 2011-09-26 03:23:37 --> Utf8 Class Initialized
DEBUG - 2011-09-26 03:23:37 --> UTF-8 Support Enabled
DEBUG - 2011-09-26 03:23:37 --> URI Class Initialized
DEBUG - 2011-09-26 03:23:37 --> Router Class Initialized
DEBUG - 2011-09-26 03:23:37 --> Output Class Initialized
DEBUG - 2011-09-26 03:23:37 --> Input Class Initialized
DEBUG - 2011-09-26 03:23:37 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-26 03:23:37 --> Language Class Initialized
DEBUG - 2011-09-26 03:23:37 --> Loader Class Initialized
DEBUG - 2011-09-26 03:23:37 --> Controller Class Initialized
DEBUG - 2011-09-26 03:23:37 --> Model Class Initialized
DEBUG - 2011-09-26 03:23:37 --> Model Class Initialized
DEBUG - 2011-09-26 03:23:37 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-26 03:23:37 --> Database Driver Class Initialized
DEBUG - 2011-09-26 03:23:37 --> Final output sent to browser
DEBUG - 2011-09-26 03:23:37 --> Total execution time: 0.6967
DEBUG - 2011-09-26 03:23:39 --> Config Class Initialized
DEBUG - 2011-09-26 03:23:39 --> Hooks Class Initialized
DEBUG - 2011-09-26 03:23:39 --> Utf8 Class Initialized
DEBUG - 2011-09-26 03:23:39 --> UTF-8 Support Enabled
DEBUG - 2011-09-26 03:23:39 --> URI Class Initialized
DEBUG - 2011-09-26 03:23:39 --> Router Class Initialized
ERROR - 2011-09-26 03:23:39 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-26 03:23:47 --> Config Class Initialized
DEBUG - 2011-09-26 03:23:47 --> Hooks Class Initialized
DEBUG - 2011-09-26 03:23:47 --> Utf8 Class Initialized
DEBUG - 2011-09-26 03:23:47 --> UTF-8 Support Enabled
DEBUG - 2011-09-26 03:23:47 --> URI Class Initialized
DEBUG - 2011-09-26 03:23:47 --> Router Class Initialized
ERROR - 2011-09-26 03:23:47 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-09-26 03:23:48 --> Config Class Initialized
DEBUG - 2011-09-26 03:23:48 --> Hooks Class Initialized
DEBUG - 2011-09-26 03:23:48 --> Utf8 Class Initialized
DEBUG - 2011-09-26 03:23:48 --> UTF-8 Support Enabled
DEBUG - 2011-09-26 03:23:48 --> URI Class Initialized
DEBUG - 2011-09-26 03:23:48 --> Router Class Initialized
DEBUG - 2011-09-26 03:23:48 --> Output Class Initialized
DEBUG - 2011-09-26 03:23:48 --> Input Class Initialized
DEBUG - 2011-09-26 03:23:48 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-26 03:23:48 --> Language Class Initialized
DEBUG - 2011-09-26 03:23:48 --> Loader Class Initialized
DEBUG - 2011-09-26 03:23:48 --> Controller Class Initialized
ERROR - 2011-09-26 03:23:48 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-26 03:23:48 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-26 03:23:48 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-26 03:23:48 --> Model Class Initialized
DEBUG - 2011-09-26 03:23:48 --> Model Class Initialized
DEBUG - 2011-09-26 03:23:48 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-26 03:23:48 --> Database Driver Class Initialized
DEBUG - 2011-09-26 03:23:48 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-26 03:23:48 --> Helper loaded: url_helper
DEBUG - 2011-09-26 03:23:48 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-26 03:23:48 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-26 03:23:48 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-26 03:23:48 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-26 03:23:48 --> Final output sent to browser
DEBUG - 2011-09-26 03:23:48 --> Total execution time: 0.0442
DEBUG - 2011-09-26 03:23:48 --> Config Class Initialized
DEBUG - 2011-09-26 03:23:48 --> Hooks Class Initialized
DEBUG - 2011-09-26 03:23:48 --> Utf8 Class Initialized
DEBUG - 2011-09-26 03:23:48 --> UTF-8 Support Enabled
DEBUG - 2011-09-26 03:23:48 --> URI Class Initialized
DEBUG - 2011-09-26 03:23:48 --> Router Class Initialized
DEBUG - 2011-09-26 03:23:48 --> Output Class Initialized
DEBUG - 2011-09-26 03:23:48 --> Input Class Initialized
DEBUG - 2011-09-26 03:23:48 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-26 03:23:48 --> Language Class Initialized
DEBUG - 2011-09-26 03:23:48 --> Loader Class Initialized
DEBUG - 2011-09-26 03:23:48 --> Controller Class Initialized
DEBUG - 2011-09-26 03:23:48 --> Model Class Initialized
DEBUG - 2011-09-26 03:23:48 --> Model Class Initialized
DEBUG - 2011-09-26 03:23:48 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-26 03:23:48 --> Database Driver Class Initialized
DEBUG - 2011-09-26 03:23:49 --> Final output sent to browser
DEBUG - 2011-09-26 03:23:49 --> Total execution time: 0.3379
DEBUG - 2011-09-26 03:51:53 --> Config Class Initialized
DEBUG - 2011-09-26 03:51:53 --> Hooks Class Initialized
DEBUG - 2011-09-26 03:51:53 --> Utf8 Class Initialized
DEBUG - 2011-09-26 03:51:53 --> UTF-8 Support Enabled
DEBUG - 2011-09-26 03:51:53 --> URI Class Initialized
DEBUG - 2011-09-26 03:51:53 --> Router Class Initialized
DEBUG - 2011-09-26 03:51:53 --> Output Class Initialized
DEBUG - 2011-09-26 03:51:53 --> Input Class Initialized
DEBUG - 2011-09-26 03:51:53 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-26 03:51:53 --> Language Class Initialized
DEBUG - 2011-09-26 03:51:53 --> Loader Class Initialized
DEBUG - 2011-09-26 03:51:53 --> Controller Class Initialized
DEBUG - 2011-09-26 03:51:53 --> Model Class Initialized
DEBUG - 2011-09-26 03:51:53 --> Model Class Initialized
DEBUG - 2011-09-26 03:51:53 --> Model Class Initialized
DEBUG - 2011-09-26 03:51:53 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-26 03:51:53 --> Database Driver Class Initialized
DEBUG - 2011-09-26 03:51:58 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-26 03:51:58 --> Helper loaded: url_helper
DEBUG - 2011-09-26 03:51:58 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-26 03:51:58 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-26 03:51:58 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-26 03:51:58 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-26 03:51:58 --> Final output sent to browser
DEBUG - 2011-09-26 03:51:58 --> Total execution time: 5.2740
DEBUG - 2011-09-26 03:52:16 --> Config Class Initialized
DEBUG - 2011-09-26 03:52:16 --> Hooks Class Initialized
DEBUG - 2011-09-26 03:52:16 --> Utf8 Class Initialized
DEBUG - 2011-09-26 03:52:16 --> UTF-8 Support Enabled
DEBUG - 2011-09-26 03:52:16 --> URI Class Initialized
DEBUG - 2011-09-26 03:52:16 --> Router Class Initialized
ERROR - 2011-09-26 03:52:16 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-26 03:52:17 --> Config Class Initialized
DEBUG - 2011-09-26 03:52:17 --> Hooks Class Initialized
DEBUG - 2011-09-26 03:52:17 --> Utf8 Class Initialized
DEBUG - 2011-09-26 03:52:17 --> UTF-8 Support Enabled
DEBUG - 2011-09-26 03:52:17 --> URI Class Initialized
DEBUG - 2011-09-26 03:52:17 --> Router Class Initialized
ERROR - 2011-09-26 03:52:17 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-26 03:52:17 --> Config Class Initialized
DEBUG - 2011-09-26 03:52:17 --> Hooks Class Initialized
DEBUG - 2011-09-26 03:52:17 --> Utf8 Class Initialized
DEBUG - 2011-09-26 03:52:17 --> UTF-8 Support Enabled
DEBUG - 2011-09-26 03:52:17 --> URI Class Initialized
DEBUG - 2011-09-26 03:52:17 --> Router Class Initialized
ERROR - 2011-09-26 03:52:17 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-26 03:52:23 --> Config Class Initialized
DEBUG - 2011-09-26 03:52:24 --> Hooks Class Initialized
DEBUG - 2011-09-26 03:52:24 --> Utf8 Class Initialized
DEBUG - 2011-09-26 03:52:24 --> UTF-8 Support Enabled
DEBUG - 2011-09-26 03:52:24 --> URI Class Initialized
DEBUG - 2011-09-26 03:52:24 --> Router Class Initialized
DEBUG - 2011-09-26 03:52:24 --> Output Class Initialized
DEBUG - 2011-09-26 03:52:24 --> Input Class Initialized
DEBUG - 2011-09-26 03:52:24 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-26 03:52:24 --> Language Class Initialized
DEBUG - 2011-09-26 03:52:24 --> Loader Class Initialized
DEBUG - 2011-09-26 03:52:24 --> Controller Class Initialized
DEBUG - 2011-09-26 03:52:24 --> Model Class Initialized
DEBUG - 2011-09-26 03:52:24 --> Model Class Initialized
DEBUG - 2011-09-26 03:52:24 --> Model Class Initialized
DEBUG - 2011-09-26 03:52:24 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-26 03:52:24 --> Database Driver Class Initialized
DEBUG - 2011-09-26 03:52:24 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-26 03:52:24 --> Helper loaded: url_helper
DEBUG - 2011-09-26 03:52:24 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-26 03:52:24 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-26 03:52:24 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-26 03:52:24 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-26 03:52:24 --> Final output sent to browser
DEBUG - 2011-09-26 03:52:24 --> Total execution time: 0.2841
DEBUG - 2011-09-26 04:28:04 --> Config Class Initialized
DEBUG - 2011-09-26 04:28:04 --> Hooks Class Initialized
DEBUG - 2011-09-26 04:28:04 --> Utf8 Class Initialized
DEBUG - 2011-09-26 04:28:04 --> UTF-8 Support Enabled
DEBUG - 2011-09-26 04:28:04 --> URI Class Initialized
DEBUG - 2011-09-26 04:28:04 --> Router Class Initialized
ERROR - 2011-09-26 04:28:04 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-09-26 04:28:43 --> Config Class Initialized
DEBUG - 2011-09-26 04:28:43 --> Hooks Class Initialized
DEBUG - 2011-09-26 04:28:43 --> Utf8 Class Initialized
DEBUG - 2011-09-26 04:28:43 --> UTF-8 Support Enabled
DEBUG - 2011-09-26 04:28:43 --> URI Class Initialized
DEBUG - 2011-09-26 04:28:43 --> Router Class Initialized
DEBUG - 2011-09-26 04:28:43 --> Output Class Initialized
DEBUG - 2011-09-26 04:28:43 --> Input Class Initialized
DEBUG - 2011-09-26 04:28:43 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-26 04:28:43 --> Language Class Initialized
DEBUG - 2011-09-26 04:28:43 --> Loader Class Initialized
DEBUG - 2011-09-26 04:28:43 --> Controller Class Initialized
DEBUG - 2011-09-26 04:28:43 --> Model Class Initialized
DEBUG - 2011-09-26 04:28:43 --> Model Class Initialized
DEBUG - 2011-09-26 04:28:43 --> Model Class Initialized
DEBUG - 2011-09-26 04:28:43 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-26 04:28:43 --> Database Driver Class Initialized
DEBUG - 2011-09-26 04:28:44 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-26 04:28:44 --> Helper loaded: url_helper
DEBUG - 2011-09-26 04:28:44 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-26 04:28:44 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-26 04:28:44 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-26 04:28:44 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-26 04:28:44 --> Final output sent to browser
DEBUG - 2011-09-26 04:28:44 --> Total execution time: 1.5268
DEBUG - 2011-09-26 04:30:18 --> Config Class Initialized
DEBUG - 2011-09-26 04:30:18 --> Hooks Class Initialized
DEBUG - 2011-09-26 04:30:18 --> Utf8 Class Initialized
DEBUG - 2011-09-26 04:30:18 --> UTF-8 Support Enabled
DEBUG - 2011-09-26 04:30:18 --> URI Class Initialized
DEBUG - 2011-09-26 04:30:18 --> Router Class Initialized
DEBUG - 2011-09-26 04:30:18 --> Output Class Initialized
DEBUG - 2011-09-26 04:30:18 --> Input Class Initialized
DEBUG - 2011-09-26 04:30:18 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-26 04:30:18 --> Language Class Initialized
DEBUG - 2011-09-26 04:30:18 --> Loader Class Initialized
DEBUG - 2011-09-26 04:30:18 --> Controller Class Initialized
ERROR - 2011-09-26 04:30:18 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-26 04:30:18 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-26 04:30:18 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-26 04:30:18 --> Model Class Initialized
DEBUG - 2011-09-26 04:30:18 --> Model Class Initialized
DEBUG - 2011-09-26 04:30:18 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-26 04:30:18 --> Database Driver Class Initialized
DEBUG - 2011-09-26 04:30:18 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-26 04:30:18 --> Helper loaded: url_helper
DEBUG - 2011-09-26 04:30:18 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-26 04:30:18 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-26 04:30:18 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-26 04:30:18 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-26 04:30:18 --> Final output sent to browser
DEBUG - 2011-09-26 04:30:18 --> Total execution time: 0.0902
DEBUG - 2011-09-26 04:30:53 --> Config Class Initialized
DEBUG - 2011-09-26 04:30:53 --> Hooks Class Initialized
DEBUG - 2011-09-26 04:30:53 --> Utf8 Class Initialized
DEBUG - 2011-09-26 04:30:53 --> UTF-8 Support Enabled
DEBUG - 2011-09-26 04:30:53 --> URI Class Initialized
DEBUG - 2011-09-26 04:30:54 --> Router Class Initialized
DEBUG - 2011-09-26 04:30:54 --> Output Class Initialized
DEBUG - 2011-09-26 04:30:54 --> Input Class Initialized
DEBUG - 2011-09-26 04:30:54 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-26 04:30:54 --> Language Class Initialized
DEBUG - 2011-09-26 04:30:54 --> Loader Class Initialized
DEBUG - 2011-09-26 04:30:54 --> Controller Class Initialized
DEBUG - 2011-09-26 04:30:54 --> Model Class Initialized
DEBUG - 2011-09-26 04:30:54 --> Model Class Initialized
DEBUG - 2011-09-26 04:30:54 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-26 04:30:54 --> Database Driver Class Initialized
DEBUG - 2011-09-26 04:40:02 --> Config Class Initialized
DEBUG - 2011-09-26 04:40:02 --> Hooks Class Initialized
DEBUG - 2011-09-26 04:40:02 --> Utf8 Class Initialized
DEBUG - 2011-09-26 04:40:02 --> UTF-8 Support Enabled
DEBUG - 2011-09-26 04:40:02 --> URI Class Initialized
DEBUG - 2011-09-26 04:40:02 --> Router Class Initialized
DEBUG - 2011-09-26 04:40:02 --> Output Class Initialized
DEBUG - 2011-09-26 04:40:02 --> Input Class Initialized
DEBUG - 2011-09-26 04:40:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-26 04:40:02 --> Language Class Initialized
DEBUG - 2011-09-26 04:40:02 --> Loader Class Initialized
DEBUG - 2011-09-26 04:40:02 --> Controller Class Initialized
ERROR - 2011-09-26 04:40:02 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-26 04:40:02 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-26 04:40:02 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-26 04:40:02 --> Model Class Initialized
DEBUG - 2011-09-26 04:40:02 --> Model Class Initialized
DEBUG - 2011-09-26 04:40:02 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-26 04:40:02 --> Database Driver Class Initialized
DEBUG - 2011-09-26 04:40:02 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-26 04:40:02 --> Helper loaded: url_helper
DEBUG - 2011-09-26 04:40:02 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-26 04:40:02 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-26 04:40:02 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-26 04:40:02 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-26 04:40:02 --> Final output sent to browser
DEBUG - 2011-09-26 04:40:02 --> Total execution time: 0.0497
DEBUG - 2011-09-26 04:40:04 --> Config Class Initialized
DEBUG - 2011-09-26 04:40:04 --> Hooks Class Initialized
DEBUG - 2011-09-26 04:40:04 --> Utf8 Class Initialized
DEBUG - 2011-09-26 04:40:04 --> UTF-8 Support Enabled
DEBUG - 2011-09-26 04:40:04 --> URI Class Initialized
DEBUG - 2011-09-26 04:40:04 --> Router Class Initialized
DEBUG - 2011-09-26 04:40:04 --> Output Class Initialized
DEBUG - 2011-09-26 04:40:04 --> Input Class Initialized
DEBUG - 2011-09-26 04:40:04 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-26 04:40:04 --> Language Class Initialized
DEBUG - 2011-09-26 04:40:04 --> Loader Class Initialized
DEBUG - 2011-09-26 04:40:04 --> Controller Class Initialized
DEBUG - 2011-09-26 04:40:04 --> Model Class Initialized
DEBUG - 2011-09-26 04:40:04 --> Model Class Initialized
DEBUG - 2011-09-26 04:40:04 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-26 04:40:04 --> Database Driver Class Initialized
DEBUG - 2011-09-26 04:40:05 --> Final output sent to browser
DEBUG - 2011-09-26 04:40:05 --> Total execution time: 0.6892
DEBUG - 2011-09-26 04:42:29 --> Config Class Initialized
DEBUG - 2011-09-26 04:42:29 --> Hooks Class Initialized
DEBUG - 2011-09-26 04:42:29 --> Utf8 Class Initialized
DEBUG - 2011-09-26 04:42:29 --> UTF-8 Support Enabled
DEBUG - 2011-09-26 04:42:29 --> URI Class Initialized
DEBUG - 2011-09-26 04:42:29 --> Router Class Initialized
DEBUG - 2011-09-26 04:42:29 --> Output Class Initialized
DEBUG - 2011-09-26 04:42:29 --> Input Class Initialized
DEBUG - 2011-09-26 04:42:29 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-26 04:42:29 --> Language Class Initialized
DEBUG - 2011-09-26 04:42:29 --> Loader Class Initialized
DEBUG - 2011-09-26 04:42:29 --> Controller Class Initialized
DEBUG - 2011-09-26 04:42:29 --> Model Class Initialized
DEBUG - 2011-09-26 04:42:29 --> Model Class Initialized
DEBUG - 2011-09-26 04:42:29 --> Model Class Initialized
DEBUG - 2011-09-26 04:42:29 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-26 04:42:29 --> Database Driver Class Initialized
DEBUG - 2011-09-26 04:42:29 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-26 04:42:29 --> Helper loaded: url_helper
DEBUG - 2011-09-26 04:42:29 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-26 04:42:29 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-26 04:42:29 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-26 04:42:29 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-26 04:42:29 --> Final output sent to browser
DEBUG - 2011-09-26 04:42:29 --> Total execution time: 0.1987
DEBUG - 2011-09-26 05:55:09 --> Config Class Initialized
DEBUG - 2011-09-26 05:55:09 --> Hooks Class Initialized
DEBUG - 2011-09-26 05:55:09 --> Utf8 Class Initialized
DEBUG - 2011-09-26 05:55:09 --> UTF-8 Support Enabled
DEBUG - 2011-09-26 05:55:09 --> URI Class Initialized
DEBUG - 2011-09-26 05:55:09 --> Router Class Initialized
DEBUG - 2011-09-26 05:55:09 --> Output Class Initialized
DEBUG - 2011-09-26 05:55:09 --> Input Class Initialized
DEBUG - 2011-09-26 05:55:09 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-26 05:55:09 --> Language Class Initialized
DEBUG - 2011-09-26 05:55:09 --> Loader Class Initialized
DEBUG - 2011-09-26 05:55:09 --> Controller Class Initialized
ERROR - 2011-09-26 05:55:09 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-26 05:55:09 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-26 05:55:09 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-26 05:55:09 --> Model Class Initialized
DEBUG - 2011-09-26 05:55:09 --> Model Class Initialized
DEBUG - 2011-09-26 05:55:09 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-26 05:55:09 --> Database Driver Class Initialized
DEBUG - 2011-09-26 05:55:10 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-26 05:55:10 --> Helper loaded: url_helper
DEBUG - 2011-09-26 05:55:10 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-26 05:55:10 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-26 05:55:10 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-26 05:55:10 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-26 05:55:10 --> Final output sent to browser
DEBUG - 2011-09-26 05:55:10 --> Total execution time: 0.8897
DEBUG - 2011-09-26 05:55:22 --> Config Class Initialized
DEBUG - 2011-09-26 05:55:22 --> Hooks Class Initialized
DEBUG - 2011-09-26 05:55:22 --> Utf8 Class Initialized
DEBUG - 2011-09-26 05:55:22 --> UTF-8 Support Enabled
DEBUG - 2011-09-26 05:55:22 --> URI Class Initialized
DEBUG - 2011-09-26 05:55:22 --> Router Class Initialized
DEBUG - 2011-09-26 05:55:22 --> Output Class Initialized
DEBUG - 2011-09-26 05:55:22 --> Input Class Initialized
DEBUG - 2011-09-26 05:55:22 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-26 05:55:22 --> Language Class Initialized
DEBUG - 2011-09-26 05:55:22 --> Loader Class Initialized
DEBUG - 2011-09-26 05:55:22 --> Controller Class Initialized
DEBUG - 2011-09-26 05:55:22 --> Model Class Initialized
DEBUG - 2011-09-26 05:55:22 --> Model Class Initialized
DEBUG - 2011-09-26 05:55:22 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-26 05:55:22 --> Database Driver Class Initialized
DEBUG - 2011-09-26 05:55:23 --> Config Class Initialized
DEBUG - 2011-09-26 05:55:23 --> Hooks Class Initialized
DEBUG - 2011-09-26 05:55:23 --> Utf8 Class Initialized
DEBUG - 2011-09-26 05:55:23 --> UTF-8 Support Enabled
DEBUG - 2011-09-26 05:55:23 --> URI Class Initialized
DEBUG - 2011-09-26 05:55:23 --> Router Class Initialized
ERROR - 2011-09-26 05:55:23 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-26 05:55:23 --> Final output sent to browser
DEBUG - 2011-09-26 05:55:24 --> Total execution time: 1.9467
DEBUG - 2011-09-26 05:55:39 --> Config Class Initialized
DEBUG - 2011-09-26 05:55:39 --> Hooks Class Initialized
DEBUG - 2011-09-26 05:55:39 --> Utf8 Class Initialized
DEBUG - 2011-09-26 05:55:39 --> UTF-8 Support Enabled
DEBUG - 2011-09-26 05:55:39 --> URI Class Initialized
DEBUG - 2011-09-26 05:55:39 --> Router Class Initialized
DEBUG - 2011-09-26 05:55:39 --> Output Class Initialized
DEBUG - 2011-09-26 05:55:39 --> Input Class Initialized
DEBUG - 2011-09-26 05:55:39 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-26 05:55:39 --> Language Class Initialized
DEBUG - 2011-09-26 05:55:39 --> Loader Class Initialized
DEBUG - 2011-09-26 05:55:39 --> Controller Class Initialized
ERROR - 2011-09-26 05:55:39 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-26 05:55:39 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-26 05:55:39 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-26 05:55:39 --> Model Class Initialized
DEBUG - 2011-09-26 05:55:39 --> Model Class Initialized
DEBUG - 2011-09-26 05:55:39 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-26 05:55:39 --> Database Driver Class Initialized
DEBUG - 2011-09-26 05:55:39 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-26 05:55:39 --> Helper loaded: url_helper
DEBUG - 2011-09-26 05:55:39 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-26 05:55:39 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-26 05:55:39 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-26 05:55:39 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-26 05:55:39 --> Final output sent to browser
DEBUG - 2011-09-26 05:55:39 --> Total execution time: 0.0642
DEBUG - 2011-09-26 05:55:40 --> Config Class Initialized
DEBUG - 2011-09-26 05:55:40 --> Hooks Class Initialized
DEBUG - 2011-09-26 05:55:40 --> Utf8 Class Initialized
DEBUG - 2011-09-26 05:55:40 --> UTF-8 Support Enabled
DEBUG - 2011-09-26 05:55:40 --> URI Class Initialized
DEBUG - 2011-09-26 05:55:40 --> Router Class Initialized
DEBUG - 2011-09-26 05:55:40 --> Output Class Initialized
DEBUG - 2011-09-26 05:55:40 --> Input Class Initialized
DEBUG - 2011-09-26 05:55:40 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-26 05:55:40 --> Language Class Initialized
DEBUG - 2011-09-26 05:55:40 --> Loader Class Initialized
DEBUG - 2011-09-26 05:55:40 --> Controller Class Initialized
DEBUG - 2011-09-26 05:55:40 --> Model Class Initialized
DEBUG - 2011-09-26 05:55:40 --> Model Class Initialized
DEBUG - 2011-09-26 05:55:40 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-26 05:55:40 --> Database Driver Class Initialized
DEBUG - 2011-09-26 05:55:41 --> Final output sent to browser
DEBUG - 2011-09-26 05:55:41 --> Total execution time: 0.6224
DEBUG - 2011-09-26 06:01:34 --> Config Class Initialized
DEBUG - 2011-09-26 06:01:34 --> Hooks Class Initialized
DEBUG - 2011-09-26 06:01:34 --> Utf8 Class Initialized
DEBUG - 2011-09-26 06:01:34 --> UTF-8 Support Enabled
DEBUG - 2011-09-26 06:01:34 --> URI Class Initialized
DEBUG - 2011-09-26 06:01:34 --> Router Class Initialized
DEBUG - 2011-09-26 06:01:35 --> Output Class Initialized
DEBUG - 2011-09-26 06:01:35 --> Input Class Initialized
DEBUG - 2011-09-26 06:01:35 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-26 06:01:35 --> Language Class Initialized
DEBUG - 2011-09-26 06:01:35 --> Loader Class Initialized
DEBUG - 2011-09-26 06:01:35 --> Controller Class Initialized
DEBUG - 2011-09-26 06:01:35 --> Model Class Initialized
DEBUG - 2011-09-26 06:01:35 --> Model Class Initialized
DEBUG - 2011-09-26 06:01:35 --> Model Class Initialized
DEBUG - 2011-09-26 06:01:35 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-26 06:01:35 --> Database Driver Class Initialized
DEBUG - 2011-09-26 06:01:39 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-26 06:01:39 --> Helper loaded: url_helper
DEBUG - 2011-09-26 06:01:39 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-26 06:01:39 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-26 06:01:39 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-26 06:01:39 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-26 06:01:39 --> Final output sent to browser
DEBUG - 2011-09-26 06:01:39 --> Total execution time: 4.7891
DEBUG - 2011-09-26 06:01:44 --> Config Class Initialized
DEBUG - 2011-09-26 06:01:44 --> Hooks Class Initialized
DEBUG - 2011-09-26 06:01:44 --> Utf8 Class Initialized
DEBUG - 2011-09-26 06:01:44 --> UTF-8 Support Enabled
DEBUG - 2011-09-26 06:01:44 --> URI Class Initialized
DEBUG - 2011-09-26 06:01:44 --> Router Class Initialized
DEBUG - 2011-09-26 06:01:44 --> Output Class Initialized
DEBUG - 2011-09-26 06:01:44 --> Input Class Initialized
DEBUG - 2011-09-26 06:01:44 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-26 06:01:44 --> Language Class Initialized
DEBUG - 2011-09-26 06:01:44 --> Loader Class Initialized
DEBUG - 2011-09-26 06:01:44 --> Controller Class Initialized
ERROR - 2011-09-26 06:01:44 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-26 06:01:44 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-26 06:01:44 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-26 06:01:44 --> Model Class Initialized
DEBUG - 2011-09-26 06:01:44 --> Model Class Initialized
DEBUG - 2011-09-26 06:01:44 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-26 06:01:44 --> Database Driver Class Initialized
DEBUG - 2011-09-26 06:01:44 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-26 06:01:44 --> Helper loaded: url_helper
DEBUG - 2011-09-26 06:01:44 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-26 06:01:44 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-26 06:01:44 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-26 06:01:44 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-26 06:01:44 --> Final output sent to browser
DEBUG - 2011-09-26 06:01:44 --> Total execution time: 0.1082
DEBUG - 2011-09-26 06:02:06 --> Config Class Initialized
DEBUG - 2011-09-26 06:02:06 --> Hooks Class Initialized
DEBUG - 2011-09-26 06:02:06 --> Utf8 Class Initialized
DEBUG - 2011-09-26 06:02:06 --> UTF-8 Support Enabled
DEBUG - 2011-09-26 06:02:06 --> URI Class Initialized
DEBUG - 2011-09-26 06:02:06 --> Router Class Initialized
DEBUG - 2011-09-26 06:02:06 --> Output Class Initialized
DEBUG - 2011-09-26 06:02:06 --> Input Class Initialized
DEBUG - 2011-09-26 06:02:06 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-26 06:02:06 --> Language Class Initialized
DEBUG - 2011-09-26 06:02:06 --> Loader Class Initialized
DEBUG - 2011-09-26 06:02:06 --> Controller Class Initialized
ERROR - 2011-09-26 06:02:06 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-26 06:02:06 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-26 06:02:06 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-26 06:02:06 --> Model Class Initialized
DEBUG - 2011-09-26 06:02:06 --> Model Class Initialized
DEBUG - 2011-09-26 06:02:06 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-26 06:02:06 --> Database Driver Class Initialized
DEBUG - 2011-09-26 06:02:06 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-26 06:02:06 --> Helper loaded: url_helper
DEBUG - 2011-09-26 06:02:06 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-26 06:02:06 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-26 06:02:06 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-26 06:02:06 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-26 06:02:06 --> Final output sent to browser
DEBUG - 2011-09-26 06:02:06 --> Total execution time: 0.2029
DEBUG - 2011-09-26 06:02:09 --> Config Class Initialized
DEBUG - 2011-09-26 06:02:09 --> Hooks Class Initialized
DEBUG - 2011-09-26 06:02:09 --> Utf8 Class Initialized
DEBUG - 2011-09-26 06:02:09 --> UTF-8 Support Enabled
DEBUG - 2011-09-26 06:02:09 --> URI Class Initialized
DEBUG - 2011-09-26 06:02:09 --> Router Class Initialized
DEBUG - 2011-09-26 06:02:09 --> Output Class Initialized
DEBUG - 2011-09-26 06:02:09 --> Input Class Initialized
DEBUG - 2011-09-26 06:02:09 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-26 06:02:09 --> Language Class Initialized
DEBUG - 2011-09-26 06:02:09 --> Loader Class Initialized
DEBUG - 2011-09-26 06:02:09 --> Controller Class Initialized
DEBUG - 2011-09-26 06:02:09 --> Model Class Initialized
DEBUG - 2011-09-26 06:02:09 --> Model Class Initialized
DEBUG - 2011-09-26 06:02:09 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-26 06:02:09 --> Database Driver Class Initialized
DEBUG - 2011-09-26 06:02:10 --> Final output sent to browser
DEBUG - 2011-09-26 06:02:10 --> Total execution time: 1.3666
DEBUG - 2011-09-26 06:02:12 --> Config Class Initialized
DEBUG - 2011-09-26 06:02:12 --> Hooks Class Initialized
DEBUG - 2011-09-26 06:02:12 --> Utf8 Class Initialized
DEBUG - 2011-09-26 06:02:12 --> UTF-8 Support Enabled
DEBUG - 2011-09-26 06:02:12 --> URI Class Initialized
DEBUG - 2011-09-26 06:02:12 --> Router Class Initialized
ERROR - 2011-09-26 06:02:12 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-26 06:02:13 --> Config Class Initialized
DEBUG - 2011-09-26 06:02:13 --> Hooks Class Initialized
DEBUG - 2011-09-26 06:02:13 --> Utf8 Class Initialized
DEBUG - 2011-09-26 06:02:13 --> UTF-8 Support Enabled
DEBUG - 2011-09-26 06:02:13 --> URI Class Initialized
DEBUG - 2011-09-26 06:02:13 --> Router Class Initialized
ERROR - 2011-09-26 06:02:13 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-26 06:02:50 --> Config Class Initialized
DEBUG - 2011-09-26 06:02:50 --> Hooks Class Initialized
DEBUG - 2011-09-26 06:02:50 --> Utf8 Class Initialized
DEBUG - 2011-09-26 06:02:50 --> UTF-8 Support Enabled
DEBUG - 2011-09-26 06:02:50 --> URI Class Initialized
DEBUG - 2011-09-26 06:02:50 --> Router Class Initialized
DEBUG - 2011-09-26 06:02:50 --> Output Class Initialized
DEBUG - 2011-09-26 06:02:50 --> Input Class Initialized
DEBUG - 2011-09-26 06:02:50 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-26 06:02:50 --> Language Class Initialized
DEBUG - 2011-09-26 06:02:50 --> Loader Class Initialized
DEBUG - 2011-09-26 06:02:50 --> Controller Class Initialized
ERROR - 2011-09-26 06:02:50 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-26 06:02:50 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-26 06:02:50 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-26 06:02:50 --> Model Class Initialized
DEBUG - 2011-09-26 06:02:50 --> Model Class Initialized
DEBUG - 2011-09-26 06:02:50 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-26 06:02:50 --> Database Driver Class Initialized
DEBUG - 2011-09-26 06:02:50 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-26 06:02:50 --> Helper loaded: url_helper
DEBUG - 2011-09-26 06:02:50 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-26 06:02:50 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-26 06:02:50 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-26 06:02:50 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-26 06:02:50 --> Final output sent to browser
DEBUG - 2011-09-26 06:02:50 --> Total execution time: 0.1612
DEBUG - 2011-09-26 06:02:51 --> Config Class Initialized
DEBUG - 2011-09-26 06:02:51 --> Hooks Class Initialized
DEBUG - 2011-09-26 06:02:51 --> Utf8 Class Initialized
DEBUG - 2011-09-26 06:02:51 --> UTF-8 Support Enabled
DEBUG - 2011-09-26 06:02:51 --> URI Class Initialized
DEBUG - 2011-09-26 06:02:51 --> Router Class Initialized
DEBUG - 2011-09-26 06:02:51 --> Output Class Initialized
DEBUG - 2011-09-26 06:02:51 --> Input Class Initialized
DEBUG - 2011-09-26 06:02:51 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-26 06:02:51 --> Language Class Initialized
DEBUG - 2011-09-26 06:02:51 --> Loader Class Initialized
DEBUG - 2011-09-26 06:02:51 --> Controller Class Initialized
DEBUG - 2011-09-26 06:02:51 --> Model Class Initialized
DEBUG - 2011-09-26 06:02:51 --> Model Class Initialized
DEBUG - 2011-09-26 06:02:51 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-26 06:02:51 --> Database Driver Class Initialized
DEBUG - 2011-09-26 06:02:52 --> Final output sent to browser
DEBUG - 2011-09-26 06:02:52 --> Total execution time: 0.4876
DEBUG - 2011-09-26 06:02:52 --> Config Class Initialized
DEBUG - 2011-09-26 06:02:52 --> Hooks Class Initialized
DEBUG - 2011-09-26 06:02:52 --> Utf8 Class Initialized
DEBUG - 2011-09-26 06:02:52 --> UTF-8 Support Enabled
DEBUG - 2011-09-26 06:02:52 --> URI Class Initialized
DEBUG - 2011-09-26 06:02:52 --> Router Class Initialized
ERROR - 2011-09-26 06:02:52 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-26 06:03:14 --> Config Class Initialized
DEBUG - 2011-09-26 06:03:14 --> Hooks Class Initialized
DEBUG - 2011-09-26 06:03:14 --> Utf8 Class Initialized
DEBUG - 2011-09-26 06:03:14 --> UTF-8 Support Enabled
DEBUG - 2011-09-26 06:03:14 --> URI Class Initialized
DEBUG - 2011-09-26 06:03:14 --> Router Class Initialized
ERROR - 2011-09-26 06:03:14 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-26 06:29:05 --> Config Class Initialized
DEBUG - 2011-09-26 06:29:05 --> Hooks Class Initialized
DEBUG - 2011-09-26 06:29:05 --> Utf8 Class Initialized
DEBUG - 2011-09-26 06:29:05 --> UTF-8 Support Enabled
DEBUG - 2011-09-26 06:29:05 --> URI Class Initialized
DEBUG - 2011-09-26 06:29:05 --> Router Class Initialized
DEBUG - 2011-09-26 06:29:05 --> Output Class Initialized
DEBUG - 2011-09-26 06:29:05 --> Input Class Initialized
DEBUG - 2011-09-26 06:29:05 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-26 06:29:05 --> Language Class Initialized
DEBUG - 2011-09-26 06:29:05 --> Loader Class Initialized
DEBUG - 2011-09-26 06:29:05 --> Controller Class Initialized
DEBUG - 2011-09-26 06:29:05 --> Model Class Initialized
DEBUG - 2011-09-26 06:29:05 --> Model Class Initialized
DEBUG - 2011-09-26 06:29:05 --> Model Class Initialized
DEBUG - 2011-09-26 06:29:05 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-26 06:29:05 --> Database Driver Class Initialized
DEBUG - 2011-09-26 06:29:06 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-26 06:29:06 --> Helper loaded: url_helper
DEBUG - 2011-09-26 06:29:06 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-26 06:29:06 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-26 06:29:06 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-26 06:29:06 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-26 06:29:06 --> Final output sent to browser
DEBUG - 2011-09-26 06:29:06 --> Total execution time: 1.4052
DEBUG - 2011-09-26 06:29:25 --> Config Class Initialized
DEBUG - 2011-09-26 06:29:25 --> Hooks Class Initialized
DEBUG - 2011-09-26 06:29:25 --> Utf8 Class Initialized
DEBUG - 2011-09-26 06:29:25 --> UTF-8 Support Enabled
DEBUG - 2011-09-26 06:29:25 --> URI Class Initialized
DEBUG - 2011-09-26 06:29:25 --> Router Class Initialized
ERROR - 2011-09-26 06:29:25 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-26 06:30:33 --> Config Class Initialized
DEBUG - 2011-09-26 06:30:33 --> Hooks Class Initialized
DEBUG - 2011-09-26 06:30:33 --> Utf8 Class Initialized
DEBUG - 2011-09-26 06:30:33 --> UTF-8 Support Enabled
DEBUG - 2011-09-26 06:30:33 --> URI Class Initialized
DEBUG - 2011-09-26 06:30:33 --> Router Class Initialized
DEBUG - 2011-09-26 06:30:33 --> Output Class Initialized
DEBUG - 2011-09-26 06:30:33 --> Input Class Initialized
DEBUG - 2011-09-26 06:30:33 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-26 06:30:33 --> Language Class Initialized
DEBUG - 2011-09-26 06:30:33 --> Loader Class Initialized
DEBUG - 2011-09-26 06:30:33 --> Controller Class Initialized
ERROR - 2011-09-26 06:30:33 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-26 06:30:33 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-26 06:30:33 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-26 06:30:33 --> Model Class Initialized
DEBUG - 2011-09-26 06:30:33 --> Model Class Initialized
DEBUG - 2011-09-26 06:30:33 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-26 06:30:33 --> Database Driver Class Initialized
DEBUG - 2011-09-26 06:30:33 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-26 06:30:33 --> Helper loaded: url_helper
DEBUG - 2011-09-26 06:30:33 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-26 06:30:33 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-26 06:30:33 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-26 06:30:33 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-26 06:30:33 --> Final output sent to browser
DEBUG - 2011-09-26 06:30:33 --> Total execution time: 0.1709
DEBUG - 2011-09-26 06:30:34 --> Config Class Initialized
DEBUG - 2011-09-26 06:30:34 --> Hooks Class Initialized
DEBUG - 2011-09-26 06:30:34 --> Utf8 Class Initialized
DEBUG - 2011-09-26 06:30:34 --> UTF-8 Support Enabled
DEBUG - 2011-09-26 06:30:34 --> URI Class Initialized
DEBUG - 2011-09-26 06:30:34 --> Router Class Initialized
DEBUG - 2011-09-26 06:30:34 --> Output Class Initialized
DEBUG - 2011-09-26 06:30:34 --> Input Class Initialized
DEBUG - 2011-09-26 06:30:34 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-26 06:30:34 --> Language Class Initialized
DEBUG - 2011-09-26 06:30:34 --> Loader Class Initialized
DEBUG - 2011-09-26 06:30:34 --> Controller Class Initialized
DEBUG - 2011-09-26 06:30:34 --> Model Class Initialized
DEBUG - 2011-09-26 06:30:34 --> Model Class Initialized
DEBUG - 2011-09-26 06:30:34 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-26 06:30:34 --> Database Driver Class Initialized
DEBUG - 2011-09-26 06:30:36 --> Final output sent to browser
DEBUG - 2011-09-26 06:30:36 --> Total execution time: 1.6762
DEBUG - 2011-09-26 06:50:10 --> Config Class Initialized
DEBUG - 2011-09-26 06:50:10 --> Hooks Class Initialized
DEBUG - 2011-09-26 06:50:10 --> Utf8 Class Initialized
DEBUG - 2011-09-26 06:50:10 --> UTF-8 Support Enabled
DEBUG - 2011-09-26 06:50:10 --> URI Class Initialized
DEBUG - 2011-09-26 06:50:10 --> Router Class Initialized
DEBUG - 2011-09-26 06:50:10 --> No URI present. Default controller set.
DEBUG - 2011-09-26 06:50:10 --> Output Class Initialized
DEBUG - 2011-09-26 06:50:10 --> Input Class Initialized
DEBUG - 2011-09-26 06:50:10 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-26 06:50:10 --> Language Class Initialized
DEBUG - 2011-09-26 06:50:10 --> Loader Class Initialized
DEBUG - 2011-09-26 06:50:10 --> Controller Class Initialized
DEBUG - 2011-09-26 06:50:10 --> File loaded: application/views/splash/main.php
DEBUG - 2011-09-26 06:50:10 --> Helper loaded: url_helper
DEBUG - 2011-09-26 06:50:10 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-26 06:50:10 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-26 06:50:10 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-26 06:50:10 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-26 06:50:10 --> Final output sent to browser
DEBUG - 2011-09-26 06:50:10 --> Total execution time: 0.4464
DEBUG - 2011-09-26 06:55:35 --> Config Class Initialized
DEBUG - 2011-09-26 06:55:35 --> Hooks Class Initialized
DEBUG - 2011-09-26 06:55:35 --> Utf8 Class Initialized
DEBUG - 2011-09-26 06:55:35 --> UTF-8 Support Enabled
DEBUG - 2011-09-26 06:55:35 --> URI Class Initialized
DEBUG - 2011-09-26 06:55:35 --> Router Class Initialized
DEBUG - 2011-09-26 06:55:35 --> Output Class Initialized
DEBUG - 2011-09-26 06:55:35 --> Input Class Initialized
DEBUG - 2011-09-26 06:55:35 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-26 06:55:35 --> Language Class Initialized
DEBUG - 2011-09-26 06:55:35 --> Loader Class Initialized
DEBUG - 2011-09-26 06:55:35 --> Controller Class Initialized
ERROR - 2011-09-26 06:55:35 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-26 06:55:35 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-26 06:55:35 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-26 06:55:35 --> Model Class Initialized
DEBUG - 2011-09-26 06:55:35 --> Model Class Initialized
DEBUG - 2011-09-26 06:55:35 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-26 06:55:35 --> Database Driver Class Initialized
DEBUG - 2011-09-26 06:55:35 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-26 06:55:35 --> Helper loaded: url_helper
DEBUG - 2011-09-26 06:55:35 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-26 06:55:35 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-26 06:55:35 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-26 06:55:35 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-26 06:55:35 --> Final output sent to browser
DEBUG - 2011-09-26 06:55:35 --> Total execution time: 0.0499
DEBUG - 2011-09-26 06:55:36 --> Config Class Initialized
DEBUG - 2011-09-26 06:55:36 --> Hooks Class Initialized
DEBUG - 2011-09-26 06:55:36 --> Utf8 Class Initialized
DEBUG - 2011-09-26 06:55:36 --> UTF-8 Support Enabled
DEBUG - 2011-09-26 06:55:36 --> URI Class Initialized
DEBUG - 2011-09-26 06:55:36 --> Router Class Initialized
DEBUG - 2011-09-26 06:55:36 --> Output Class Initialized
DEBUG - 2011-09-26 06:55:36 --> Input Class Initialized
DEBUG - 2011-09-26 06:55:36 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-26 06:55:36 --> Language Class Initialized
DEBUG - 2011-09-26 06:55:36 --> Loader Class Initialized
DEBUG - 2011-09-26 06:55:36 --> Controller Class Initialized
DEBUG - 2011-09-26 06:55:36 --> Model Class Initialized
DEBUG - 2011-09-26 06:55:36 --> Model Class Initialized
DEBUG - 2011-09-26 06:55:36 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-26 06:55:36 --> Database Driver Class Initialized
DEBUG - 2011-09-26 06:55:39 --> Final output sent to browser
DEBUG - 2011-09-26 06:55:39 --> Total execution time: 2.2565
DEBUG - 2011-09-26 06:55:41 --> Config Class Initialized
DEBUG - 2011-09-26 06:55:41 --> Hooks Class Initialized
DEBUG - 2011-09-26 06:55:41 --> Utf8 Class Initialized
DEBUG - 2011-09-26 06:55:41 --> UTF-8 Support Enabled
DEBUG - 2011-09-26 06:55:41 --> URI Class Initialized
DEBUG - 2011-09-26 06:55:41 --> Router Class Initialized
ERROR - 2011-09-26 06:55:41 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-26 06:55:44 --> Config Class Initialized
DEBUG - 2011-09-26 06:55:44 --> Hooks Class Initialized
DEBUG - 2011-09-26 06:55:44 --> Utf8 Class Initialized
DEBUG - 2011-09-26 06:55:44 --> UTF-8 Support Enabled
DEBUG - 2011-09-26 06:55:44 --> URI Class Initialized
DEBUG - 2011-09-26 06:55:44 --> Router Class Initialized
ERROR - 2011-09-26 06:55:44 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-26 06:56:22 --> Config Class Initialized
DEBUG - 2011-09-26 06:56:22 --> Hooks Class Initialized
DEBUG - 2011-09-26 06:56:22 --> Utf8 Class Initialized
DEBUG - 2011-09-26 06:56:22 --> UTF-8 Support Enabled
DEBUG - 2011-09-26 06:56:22 --> URI Class Initialized
DEBUG - 2011-09-26 06:56:22 --> Router Class Initialized
DEBUG - 2011-09-26 06:56:22 --> Output Class Initialized
DEBUG - 2011-09-26 06:56:22 --> Input Class Initialized
DEBUG - 2011-09-26 06:56:22 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-26 06:56:22 --> Language Class Initialized
DEBUG - 2011-09-26 06:56:22 --> Loader Class Initialized
DEBUG - 2011-09-26 06:56:22 --> Controller Class Initialized
ERROR - 2011-09-26 06:56:22 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-26 06:56:22 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-26 06:56:22 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-26 06:56:22 --> Model Class Initialized
DEBUG - 2011-09-26 06:56:22 --> Model Class Initialized
DEBUG - 2011-09-26 06:56:22 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-26 06:56:22 --> Database Driver Class Initialized
DEBUG - 2011-09-26 06:56:22 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-26 06:56:22 --> Helper loaded: url_helper
DEBUG - 2011-09-26 06:56:22 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-26 06:56:22 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-26 06:56:22 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-26 06:56:22 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-26 06:56:22 --> Final output sent to browser
DEBUG - 2011-09-26 06:56:22 --> Total execution time: 0.0877
DEBUG - 2011-09-26 06:56:27 --> Config Class Initialized
DEBUG - 2011-09-26 06:56:27 --> Hooks Class Initialized
DEBUG - 2011-09-26 06:56:27 --> Utf8 Class Initialized
DEBUG - 2011-09-26 06:56:27 --> UTF-8 Support Enabled
DEBUG - 2011-09-26 06:56:27 --> URI Class Initialized
DEBUG - 2011-09-26 06:56:27 --> Router Class Initialized
DEBUG - 2011-09-26 06:56:27 --> Output Class Initialized
DEBUG - 2011-09-26 06:56:27 --> Input Class Initialized
DEBUG - 2011-09-26 06:56:27 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-26 06:56:27 --> Language Class Initialized
DEBUG - 2011-09-26 06:56:27 --> Loader Class Initialized
DEBUG - 2011-09-26 06:56:27 --> Controller Class Initialized
DEBUG - 2011-09-26 06:56:27 --> Model Class Initialized
DEBUG - 2011-09-26 06:56:27 --> Model Class Initialized
DEBUG - 2011-09-26 06:56:27 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-26 06:56:27 --> Database Driver Class Initialized
DEBUG - 2011-09-26 06:56:28 --> Final output sent to browser
DEBUG - 2011-09-26 06:56:28 --> Total execution time: 1.4757
DEBUG - 2011-09-26 06:56:30 --> Config Class Initialized
DEBUG - 2011-09-26 06:56:30 --> Hooks Class Initialized
DEBUG - 2011-09-26 06:56:30 --> Utf8 Class Initialized
DEBUG - 2011-09-26 06:56:30 --> UTF-8 Support Enabled
DEBUG - 2011-09-26 06:56:30 --> URI Class Initialized
DEBUG - 2011-09-26 06:56:30 --> Router Class Initialized
ERROR - 2011-09-26 06:56:30 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-26 06:56:31 --> Config Class Initialized
DEBUG - 2011-09-26 06:56:31 --> Hooks Class Initialized
DEBUG - 2011-09-26 06:56:31 --> Utf8 Class Initialized
DEBUG - 2011-09-26 06:56:31 --> UTF-8 Support Enabled
DEBUG - 2011-09-26 06:56:31 --> URI Class Initialized
DEBUG - 2011-09-26 06:56:31 --> Router Class Initialized
ERROR - 2011-09-26 06:56:31 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-26 06:56:31 --> Config Class Initialized
DEBUG - 2011-09-26 06:56:31 --> Hooks Class Initialized
DEBUG - 2011-09-26 06:56:31 --> Utf8 Class Initialized
DEBUG - 2011-09-26 06:56:31 --> UTF-8 Support Enabled
DEBUG - 2011-09-26 06:56:31 --> URI Class Initialized
DEBUG - 2011-09-26 06:56:31 --> Router Class Initialized
ERROR - 2011-09-26 06:56:31 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-26 06:57:26 --> Config Class Initialized
DEBUG - 2011-09-26 06:57:26 --> Hooks Class Initialized
DEBUG - 2011-09-26 06:57:26 --> Utf8 Class Initialized
DEBUG - 2011-09-26 06:57:26 --> UTF-8 Support Enabled
DEBUG - 2011-09-26 06:57:26 --> URI Class Initialized
DEBUG - 2011-09-26 06:57:26 --> Router Class Initialized
DEBUG - 2011-09-26 06:57:26 --> Output Class Initialized
DEBUG - 2011-09-26 06:57:26 --> Input Class Initialized
DEBUG - 2011-09-26 06:57:26 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-26 06:57:26 --> Language Class Initialized
DEBUG - 2011-09-26 06:57:26 --> Loader Class Initialized
DEBUG - 2011-09-26 06:57:26 --> Controller Class Initialized
ERROR - 2011-09-26 06:57:26 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-26 06:57:26 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-26 06:57:26 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-26 06:57:26 --> Model Class Initialized
DEBUG - 2011-09-26 06:57:26 --> Model Class Initialized
DEBUG - 2011-09-26 06:57:26 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-26 06:57:26 --> Database Driver Class Initialized
DEBUG - 2011-09-26 06:57:26 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-26 06:57:26 --> Helper loaded: url_helper
DEBUG - 2011-09-26 06:57:26 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-26 06:57:26 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-26 06:57:26 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-26 06:57:26 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-26 06:57:26 --> Final output sent to browser
DEBUG - 2011-09-26 06:57:26 --> Total execution time: 0.0565
DEBUG - 2011-09-26 06:57:28 --> Config Class Initialized
DEBUG - 2011-09-26 06:57:28 --> Hooks Class Initialized
DEBUG - 2011-09-26 06:57:28 --> Utf8 Class Initialized
DEBUG - 2011-09-26 06:57:28 --> UTF-8 Support Enabled
DEBUG - 2011-09-26 06:57:28 --> URI Class Initialized
DEBUG - 2011-09-26 06:57:28 --> Router Class Initialized
DEBUG - 2011-09-26 06:57:28 --> Output Class Initialized
DEBUG - 2011-09-26 06:57:28 --> Input Class Initialized
DEBUG - 2011-09-26 06:57:28 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-26 06:57:28 --> Language Class Initialized
DEBUG - 2011-09-26 06:57:28 --> Loader Class Initialized
DEBUG - 2011-09-26 06:57:28 --> Controller Class Initialized
DEBUG - 2011-09-26 06:57:28 --> Model Class Initialized
DEBUG - 2011-09-26 06:57:28 --> Model Class Initialized
DEBUG - 2011-09-26 06:57:28 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-26 06:57:28 --> Database Driver Class Initialized
DEBUG - 2011-09-26 06:57:28 --> Final output sent to browser
DEBUG - 2011-09-26 06:57:28 --> Total execution time: 0.6551
DEBUG - 2011-09-26 08:19:12 --> Config Class Initialized
DEBUG - 2011-09-26 08:19:12 --> Hooks Class Initialized
DEBUG - 2011-09-26 08:19:12 --> Utf8 Class Initialized
DEBUG - 2011-09-26 08:19:12 --> UTF-8 Support Enabled
DEBUG - 2011-09-26 08:19:12 --> URI Class Initialized
DEBUG - 2011-09-26 08:19:12 --> Router Class Initialized
DEBUG - 2011-09-26 08:19:12 --> Output Class Initialized
DEBUG - 2011-09-26 08:19:12 --> Input Class Initialized
DEBUG - 2011-09-26 08:19:12 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-26 08:19:12 --> Language Class Initialized
DEBUG - 2011-09-26 08:19:12 --> Loader Class Initialized
DEBUG - 2011-09-26 08:19:12 --> Controller Class Initialized
DEBUG - 2011-09-26 08:19:12 --> Model Class Initialized
DEBUG - 2011-09-26 08:19:12 --> Model Class Initialized
DEBUG - 2011-09-26 08:19:12 --> Model Class Initialized
DEBUG - 2011-09-26 08:19:12 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-26 08:19:12 --> Database Driver Class Initialized
DEBUG - 2011-09-26 08:19:13 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-26 08:19:13 --> Helper loaded: url_helper
DEBUG - 2011-09-26 08:19:13 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-26 08:19:13 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-26 08:19:13 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-26 08:19:13 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-26 08:19:13 --> Final output sent to browser
DEBUG - 2011-09-26 08:19:13 --> Total execution time: 1.4853
DEBUG - 2011-09-26 08:42:44 --> Config Class Initialized
DEBUG - 2011-09-26 08:42:44 --> Hooks Class Initialized
DEBUG - 2011-09-26 08:42:44 --> Utf8 Class Initialized
DEBUG - 2011-09-26 08:42:44 --> UTF-8 Support Enabled
DEBUG - 2011-09-26 08:42:44 --> URI Class Initialized
DEBUG - 2011-09-26 08:42:44 --> Router Class Initialized
DEBUG - 2011-09-26 08:42:44 --> Output Class Initialized
DEBUG - 2011-09-26 08:42:44 --> Input Class Initialized
DEBUG - 2011-09-26 08:42:44 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-26 08:42:44 --> Language Class Initialized
DEBUG - 2011-09-26 08:42:44 --> Loader Class Initialized
DEBUG - 2011-09-26 08:42:44 --> Controller Class Initialized
DEBUG - 2011-09-26 08:42:44 --> Model Class Initialized
DEBUG - 2011-09-26 08:42:44 --> Model Class Initialized
DEBUG - 2011-09-26 08:42:44 --> Model Class Initialized
DEBUG - 2011-09-26 08:42:44 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-26 08:42:44 --> Database Driver Class Initialized
DEBUG - 2011-09-26 08:42:45 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-26 08:42:45 --> Helper loaded: url_helper
DEBUG - 2011-09-26 08:42:45 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-26 08:42:45 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-26 08:42:45 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-26 08:42:45 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-26 08:42:45 --> Final output sent to browser
DEBUG - 2011-09-26 08:42:45 --> Total execution time: 0.4034
DEBUG - 2011-09-26 08:42:48 --> Config Class Initialized
DEBUG - 2011-09-26 08:42:48 --> Hooks Class Initialized
DEBUG - 2011-09-26 08:42:48 --> Utf8 Class Initialized
DEBUG - 2011-09-26 08:42:48 --> UTF-8 Support Enabled
DEBUG - 2011-09-26 08:42:48 --> URI Class Initialized
DEBUG - 2011-09-26 08:42:48 --> Router Class Initialized
ERROR - 2011-09-26 08:42:48 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-26 08:44:34 --> Config Class Initialized
DEBUG - 2011-09-26 08:44:34 --> Hooks Class Initialized
DEBUG - 2011-09-26 08:44:34 --> Utf8 Class Initialized
DEBUG - 2011-09-26 08:44:34 --> UTF-8 Support Enabled
DEBUG - 2011-09-26 08:44:34 --> URI Class Initialized
DEBUG - 2011-09-26 08:44:34 --> Router Class Initialized
DEBUG - 2011-09-26 08:44:34 --> Output Class Initialized
DEBUG - 2011-09-26 08:44:34 --> Input Class Initialized
DEBUG - 2011-09-26 08:44:34 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-26 08:44:34 --> Language Class Initialized
DEBUG - 2011-09-26 08:44:34 --> Loader Class Initialized
DEBUG - 2011-09-26 08:44:34 --> Controller Class Initialized
ERROR - 2011-09-26 08:44:34 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-26 08:44:34 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-26 08:44:34 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-26 08:44:34 --> Model Class Initialized
DEBUG - 2011-09-26 08:44:34 --> Model Class Initialized
DEBUG - 2011-09-26 08:44:34 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-26 08:44:34 --> Database Driver Class Initialized
DEBUG - 2011-09-26 08:44:34 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-26 08:44:34 --> Helper loaded: url_helper
DEBUG - 2011-09-26 08:44:34 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-26 08:44:34 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-26 08:44:34 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-26 08:44:34 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-26 08:44:34 --> Final output sent to browser
DEBUG - 2011-09-26 08:44:34 --> Total execution time: 0.1377
DEBUG - 2011-09-26 08:44:35 --> Config Class Initialized
DEBUG - 2011-09-26 08:44:35 --> Hooks Class Initialized
DEBUG - 2011-09-26 08:44:35 --> Utf8 Class Initialized
DEBUG - 2011-09-26 08:44:35 --> UTF-8 Support Enabled
DEBUG - 2011-09-26 08:44:35 --> URI Class Initialized
DEBUG - 2011-09-26 08:44:35 --> Router Class Initialized
DEBUG - 2011-09-26 08:44:35 --> Output Class Initialized
DEBUG - 2011-09-26 08:44:35 --> Input Class Initialized
DEBUG - 2011-09-26 08:44:35 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-26 08:44:35 --> Language Class Initialized
DEBUG - 2011-09-26 08:44:35 --> Loader Class Initialized
DEBUG - 2011-09-26 08:44:35 --> Controller Class Initialized
DEBUG - 2011-09-26 08:44:35 --> Model Class Initialized
DEBUG - 2011-09-26 08:44:35 --> Model Class Initialized
DEBUG - 2011-09-26 08:44:35 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-26 08:44:36 --> Database Driver Class Initialized
DEBUG - 2011-09-26 08:44:37 --> Final output sent to browser
DEBUG - 2011-09-26 08:44:37 --> Total execution time: 1.1532
DEBUG - 2011-09-26 08:44:38 --> Config Class Initialized
DEBUG - 2011-09-26 08:44:38 --> Hooks Class Initialized
DEBUG - 2011-09-26 08:44:38 --> Utf8 Class Initialized
DEBUG - 2011-09-26 08:44:38 --> UTF-8 Support Enabled
DEBUG - 2011-09-26 08:44:38 --> URI Class Initialized
DEBUG - 2011-09-26 08:44:38 --> Router Class Initialized
ERROR - 2011-09-26 08:44:38 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-26 08:45:06 --> Config Class Initialized
DEBUG - 2011-09-26 08:45:06 --> Hooks Class Initialized
DEBUG - 2011-09-26 08:45:06 --> Utf8 Class Initialized
DEBUG - 2011-09-26 08:45:06 --> UTF-8 Support Enabled
DEBUG - 2011-09-26 08:45:06 --> URI Class Initialized
DEBUG - 2011-09-26 08:45:06 --> Router Class Initialized
DEBUG - 2011-09-26 08:45:06 --> Output Class Initialized
DEBUG - 2011-09-26 08:45:06 --> Input Class Initialized
DEBUG - 2011-09-26 08:45:06 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-26 08:45:06 --> Language Class Initialized
DEBUG - 2011-09-26 08:45:06 --> Loader Class Initialized
DEBUG - 2011-09-26 08:45:06 --> Controller Class Initialized
DEBUG - 2011-09-26 08:45:06 --> Model Class Initialized
DEBUG - 2011-09-26 08:45:06 --> Model Class Initialized
DEBUG - 2011-09-26 08:45:06 --> Model Class Initialized
DEBUG - 2011-09-26 08:45:06 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-26 08:45:06 --> Database Driver Class Initialized
DEBUG - 2011-09-26 08:45:06 --> Config Class Initialized
DEBUG - 2011-09-26 08:45:06 --> Hooks Class Initialized
DEBUG - 2011-09-26 08:45:06 --> Utf8 Class Initialized
DEBUG - 2011-09-26 08:45:06 --> UTF-8 Support Enabled
DEBUG - 2011-09-26 08:45:06 --> URI Class Initialized
DEBUG - 2011-09-26 08:45:06 --> Router Class Initialized
DEBUG - 2011-09-26 08:45:06 --> Output Class Initialized
DEBUG - 2011-09-26 08:45:06 --> Input Class Initialized
DEBUG - 2011-09-26 08:45:06 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-26 08:45:06 --> Language Class Initialized
DEBUG - 2011-09-26 08:45:07 --> Loader Class Initialized
DEBUG - 2011-09-26 08:45:07 --> Controller Class Initialized
ERROR - 2011-09-26 08:45:07 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-26 08:45:07 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-26 08:45:07 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-26 08:45:07 --> Model Class Initialized
DEBUG - 2011-09-26 08:45:07 --> Model Class Initialized
DEBUG - 2011-09-26 08:45:07 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-26 08:45:07 --> Database Driver Class Initialized
DEBUG - 2011-09-26 08:45:07 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-26 08:45:07 --> Helper loaded: url_helper
DEBUG - 2011-09-26 08:45:07 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-26 08:45:07 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-26 08:45:07 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-26 08:45:07 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-26 08:45:07 --> Final output sent to browser
DEBUG - 2011-09-26 08:45:07 --> Total execution time: 0.3906
DEBUG - 2011-09-26 08:45:08 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-26 08:45:08 --> Helper loaded: url_helper
DEBUG - 2011-09-26 08:45:08 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-26 08:45:08 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-26 08:45:08 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-26 08:45:08 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-26 08:45:08 --> Final output sent to browser
DEBUG - 2011-09-26 08:45:08 --> Total execution time: 2.1508
DEBUG - 2011-09-26 08:45:34 --> Config Class Initialized
DEBUG - 2011-09-26 08:45:34 --> Hooks Class Initialized
DEBUG - 2011-09-26 08:45:34 --> Utf8 Class Initialized
DEBUG - 2011-09-26 08:45:34 --> UTF-8 Support Enabled
DEBUG - 2011-09-26 08:45:34 --> URI Class Initialized
DEBUG - 2011-09-26 08:45:34 --> Router Class Initialized
DEBUG - 2011-09-26 08:45:34 --> Output Class Initialized
DEBUG - 2011-09-26 08:45:34 --> Input Class Initialized
DEBUG - 2011-09-26 08:45:34 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-26 08:45:34 --> Language Class Initialized
DEBUG - 2011-09-26 08:45:34 --> Loader Class Initialized
DEBUG - 2011-09-26 08:45:34 --> Controller Class Initialized
DEBUG - 2011-09-26 08:45:34 --> Model Class Initialized
DEBUG - 2011-09-26 08:45:34 --> Model Class Initialized
DEBUG - 2011-09-26 08:45:34 --> Model Class Initialized
DEBUG - 2011-09-26 08:45:34 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-26 08:45:34 --> Database Driver Class Initialized
DEBUG - 2011-09-26 08:45:34 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-26 08:45:34 --> Helper loaded: url_helper
DEBUG - 2011-09-26 08:45:34 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-26 08:45:34 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-26 08:45:34 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-26 08:45:34 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-26 08:45:34 --> Final output sent to browser
DEBUG - 2011-09-26 08:45:34 --> Total execution time: 0.0843
DEBUG - 2011-09-26 09:11:49 --> Config Class Initialized
DEBUG - 2011-09-26 09:11:49 --> Hooks Class Initialized
DEBUG - 2011-09-26 09:11:49 --> Utf8 Class Initialized
DEBUG - 2011-09-26 09:11:49 --> UTF-8 Support Enabled
DEBUG - 2011-09-26 09:11:49 --> URI Class Initialized
DEBUG - 2011-09-26 09:11:49 --> Router Class Initialized
DEBUG - 2011-09-26 09:11:49 --> Output Class Initialized
DEBUG - 2011-09-26 09:11:49 --> Input Class Initialized
DEBUG - 2011-09-26 09:11:49 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-26 09:11:49 --> Language Class Initialized
DEBUG - 2011-09-26 09:11:49 --> Loader Class Initialized
DEBUG - 2011-09-26 09:11:49 --> Controller Class Initialized
DEBUG - 2011-09-26 09:11:49 --> Model Class Initialized
DEBUG - 2011-09-26 09:11:49 --> Model Class Initialized
DEBUG - 2011-09-26 09:11:49 --> Model Class Initialized
DEBUG - 2011-09-26 09:11:49 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-26 09:11:49 --> Database Driver Class Initialized
DEBUG - 2011-09-26 09:11:51 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-26 09:11:51 --> Helper loaded: url_helper
DEBUG - 2011-09-26 09:11:51 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-26 09:11:51 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-26 09:11:51 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-26 09:11:51 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-26 09:11:51 --> Final output sent to browser
DEBUG - 2011-09-26 09:11:51 --> Total execution time: 1.7232
DEBUG - 2011-09-26 09:11:53 --> Config Class Initialized
DEBUG - 2011-09-26 09:11:53 --> Hooks Class Initialized
DEBUG - 2011-09-26 09:11:53 --> Utf8 Class Initialized
DEBUG - 2011-09-26 09:11:53 --> UTF-8 Support Enabled
DEBUG - 2011-09-26 09:11:53 --> URI Class Initialized
DEBUG - 2011-09-26 09:11:53 --> Router Class Initialized
ERROR - 2011-09-26 09:11:53 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-26 09:12:05 --> Config Class Initialized
DEBUG - 2011-09-26 09:12:05 --> Hooks Class Initialized
DEBUG - 2011-09-26 09:12:05 --> Utf8 Class Initialized
DEBUG - 2011-09-26 09:12:05 --> UTF-8 Support Enabled
DEBUG - 2011-09-26 09:12:05 --> URI Class Initialized
DEBUG - 2011-09-26 09:12:05 --> Router Class Initialized
DEBUG - 2011-09-26 09:12:05 --> Output Class Initialized
DEBUG - 2011-09-26 09:12:05 --> Input Class Initialized
DEBUG - 2011-09-26 09:12:05 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-26 09:12:05 --> Language Class Initialized
DEBUG - 2011-09-26 09:12:05 --> Loader Class Initialized
DEBUG - 2011-09-26 09:12:05 --> Controller Class Initialized
DEBUG - 2011-09-26 09:12:05 --> Model Class Initialized
DEBUG - 2011-09-26 09:12:05 --> Model Class Initialized
DEBUG - 2011-09-26 09:12:05 --> Model Class Initialized
DEBUG - 2011-09-26 09:12:05 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-26 09:12:05 --> Database Driver Class Initialized
DEBUG - 2011-09-26 09:12:05 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-26 09:12:05 --> Helper loaded: url_helper
DEBUG - 2011-09-26 09:12:05 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-26 09:12:05 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-26 09:12:05 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-26 09:12:05 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-26 09:12:05 --> Final output sent to browser
DEBUG - 2011-09-26 09:12:05 --> Total execution time: 0.3130
DEBUG - 2011-09-26 09:12:06 --> Config Class Initialized
DEBUG - 2011-09-26 09:12:06 --> Hooks Class Initialized
DEBUG - 2011-09-26 09:12:06 --> Utf8 Class Initialized
DEBUG - 2011-09-26 09:12:06 --> UTF-8 Support Enabled
DEBUG - 2011-09-26 09:12:06 --> URI Class Initialized
DEBUG - 2011-09-26 09:12:06 --> Router Class Initialized
DEBUG - 2011-09-26 09:12:06 --> Output Class Initialized
DEBUG - 2011-09-26 09:12:06 --> Input Class Initialized
DEBUG - 2011-09-26 09:12:06 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-26 09:12:06 --> Language Class Initialized
DEBUG - 2011-09-26 09:12:06 --> Loader Class Initialized
DEBUG - 2011-09-26 09:12:06 --> Controller Class Initialized
DEBUG - 2011-09-26 09:12:06 --> Model Class Initialized
DEBUG - 2011-09-26 09:12:06 --> Model Class Initialized
DEBUG - 2011-09-26 09:12:06 --> Model Class Initialized
DEBUG - 2011-09-26 09:12:06 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-26 09:12:06 --> Database Driver Class Initialized
DEBUG - 2011-09-26 09:12:06 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-26 09:12:06 --> Helper loaded: url_helper
DEBUG - 2011-09-26 09:12:06 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-26 09:12:06 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-26 09:12:06 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-26 09:12:06 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-26 09:12:06 --> Final output sent to browser
DEBUG - 2011-09-26 09:12:06 --> Total execution time: 0.0544
DEBUG - 2011-09-26 09:12:07 --> Config Class Initialized
DEBUG - 2011-09-26 09:12:07 --> Hooks Class Initialized
DEBUG - 2011-09-26 09:12:07 --> Utf8 Class Initialized
DEBUG - 2011-09-26 09:12:07 --> UTF-8 Support Enabled
DEBUG - 2011-09-26 09:12:07 --> URI Class Initialized
DEBUG - 2011-09-26 09:12:07 --> Router Class Initialized
DEBUG - 2011-09-26 09:12:07 --> Output Class Initialized
DEBUG - 2011-09-26 09:12:07 --> Input Class Initialized
DEBUG - 2011-09-26 09:12:07 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-26 09:12:07 --> Language Class Initialized
DEBUG - 2011-09-26 09:12:07 --> Loader Class Initialized
DEBUG - 2011-09-26 09:12:07 --> Controller Class Initialized
DEBUG - 2011-09-26 09:12:07 --> Model Class Initialized
DEBUG - 2011-09-26 09:12:07 --> Model Class Initialized
DEBUG - 2011-09-26 09:12:07 --> Model Class Initialized
DEBUG - 2011-09-26 09:12:07 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-26 09:12:07 --> Database Driver Class Initialized
DEBUG - 2011-09-26 09:12:07 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-26 09:12:07 --> Helper loaded: url_helper
DEBUG - 2011-09-26 09:12:07 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-26 09:12:07 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-26 09:12:07 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-26 09:12:07 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-26 09:12:07 --> Final output sent to browser
DEBUG - 2011-09-26 09:12:07 --> Total execution time: 0.0755
DEBUG - 2011-09-26 09:12:15 --> Config Class Initialized
DEBUG - 2011-09-26 09:12:15 --> Hooks Class Initialized
DEBUG - 2011-09-26 09:12:15 --> Utf8 Class Initialized
DEBUG - 2011-09-26 09:12:15 --> UTF-8 Support Enabled
DEBUG - 2011-09-26 09:12:15 --> URI Class Initialized
DEBUG - 2011-09-26 09:12:15 --> Router Class Initialized
DEBUG - 2011-09-26 09:12:15 --> Output Class Initialized
DEBUG - 2011-09-26 09:12:15 --> Input Class Initialized
DEBUG - 2011-09-26 09:12:15 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-26 09:12:15 --> Language Class Initialized
DEBUG - 2011-09-26 09:12:15 --> Loader Class Initialized
DEBUG - 2011-09-26 09:12:15 --> Controller Class Initialized
DEBUG - 2011-09-26 09:12:15 --> Model Class Initialized
DEBUG - 2011-09-26 09:12:15 --> Model Class Initialized
DEBUG - 2011-09-26 09:12:15 --> Model Class Initialized
DEBUG - 2011-09-26 09:12:15 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-26 09:12:15 --> Database Driver Class Initialized
DEBUG - 2011-09-26 09:12:15 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-26 09:12:15 --> Helper loaded: url_helper
DEBUG - 2011-09-26 09:12:15 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-26 09:12:15 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-26 09:12:15 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-26 09:12:15 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-26 09:12:15 --> Final output sent to browser
DEBUG - 2011-09-26 09:12:15 --> Total execution time: 0.1101
DEBUG - 2011-09-26 09:12:16 --> Config Class Initialized
DEBUG - 2011-09-26 09:12:16 --> Hooks Class Initialized
DEBUG - 2011-09-26 09:12:16 --> Utf8 Class Initialized
DEBUG - 2011-09-26 09:12:16 --> UTF-8 Support Enabled
DEBUG - 2011-09-26 09:12:16 --> URI Class Initialized
DEBUG - 2011-09-26 09:12:16 --> Router Class Initialized
DEBUG - 2011-09-26 09:12:16 --> Output Class Initialized
DEBUG - 2011-09-26 09:12:16 --> Input Class Initialized
DEBUG - 2011-09-26 09:12:16 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-26 09:12:16 --> Language Class Initialized
DEBUG - 2011-09-26 09:12:16 --> Loader Class Initialized
DEBUG - 2011-09-26 09:12:16 --> Controller Class Initialized
DEBUG - 2011-09-26 09:12:16 --> Model Class Initialized
DEBUG - 2011-09-26 09:12:16 --> Model Class Initialized
DEBUG - 2011-09-26 09:12:16 --> Model Class Initialized
DEBUG - 2011-09-26 09:12:16 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-26 09:12:16 --> Database Driver Class Initialized
DEBUG - 2011-09-26 09:12:16 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-26 09:12:16 --> Helper loaded: url_helper
DEBUG - 2011-09-26 09:12:16 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-26 09:12:16 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-26 09:12:16 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-26 09:12:16 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-26 09:12:16 --> Final output sent to browser
DEBUG - 2011-09-26 09:12:16 --> Total execution time: 0.0451
DEBUG - 2011-09-26 09:12:28 --> Config Class Initialized
DEBUG - 2011-09-26 09:12:28 --> Hooks Class Initialized
DEBUG - 2011-09-26 09:12:28 --> Utf8 Class Initialized
DEBUG - 2011-09-26 09:12:28 --> UTF-8 Support Enabled
DEBUG - 2011-09-26 09:12:28 --> URI Class Initialized
DEBUG - 2011-09-26 09:12:28 --> Router Class Initialized
DEBUG - 2011-09-26 09:12:28 --> Output Class Initialized
DEBUG - 2011-09-26 09:12:28 --> Input Class Initialized
DEBUG - 2011-09-26 09:12:28 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-26 09:12:28 --> Language Class Initialized
DEBUG - 2011-09-26 09:12:28 --> Loader Class Initialized
DEBUG - 2011-09-26 09:12:28 --> Controller Class Initialized
DEBUG - 2011-09-26 09:12:28 --> Model Class Initialized
DEBUG - 2011-09-26 09:12:28 --> Model Class Initialized
DEBUG - 2011-09-26 09:12:28 --> Model Class Initialized
DEBUG - 2011-09-26 09:12:28 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-26 09:12:28 --> Database Driver Class Initialized
DEBUG - 2011-09-26 09:12:29 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-26 09:12:29 --> Helper loaded: url_helper
DEBUG - 2011-09-26 09:12:29 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-26 09:12:29 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-26 09:12:29 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-26 09:12:29 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-26 09:12:29 --> Final output sent to browser
DEBUG - 2011-09-26 09:12:29 --> Total execution time: 0.9274
DEBUG - 2011-09-26 09:12:31 --> Config Class Initialized
DEBUG - 2011-09-26 09:12:31 --> Hooks Class Initialized
DEBUG - 2011-09-26 09:12:31 --> Utf8 Class Initialized
DEBUG - 2011-09-26 09:12:31 --> UTF-8 Support Enabled
DEBUG - 2011-09-26 09:12:31 --> URI Class Initialized
DEBUG - 2011-09-26 09:12:31 --> Router Class Initialized
DEBUG - 2011-09-26 09:12:31 --> Output Class Initialized
DEBUG - 2011-09-26 09:12:31 --> Input Class Initialized
DEBUG - 2011-09-26 09:12:31 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-26 09:12:31 --> Language Class Initialized
DEBUG - 2011-09-26 09:12:31 --> Loader Class Initialized
DEBUG - 2011-09-26 09:12:31 --> Controller Class Initialized
DEBUG - 2011-09-26 09:12:31 --> Model Class Initialized
DEBUG - 2011-09-26 09:12:31 --> Model Class Initialized
DEBUG - 2011-09-26 09:12:31 --> Model Class Initialized
DEBUG - 2011-09-26 09:12:31 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-26 09:12:31 --> Database Driver Class Initialized
DEBUG - 2011-09-26 09:12:31 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-26 09:12:31 --> Helper loaded: url_helper
DEBUG - 2011-09-26 09:12:31 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-26 09:12:31 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-26 09:12:31 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-26 09:12:31 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-26 09:12:31 --> Final output sent to browser
DEBUG - 2011-09-26 09:12:31 --> Total execution time: 0.1778
DEBUG - 2011-09-26 09:12:35 --> Config Class Initialized
DEBUG - 2011-09-26 09:12:35 --> Hooks Class Initialized
DEBUG - 2011-09-26 09:12:35 --> Utf8 Class Initialized
DEBUG - 2011-09-26 09:12:35 --> UTF-8 Support Enabled
DEBUG - 2011-09-26 09:12:35 --> URI Class Initialized
DEBUG - 2011-09-26 09:12:35 --> Router Class Initialized
DEBUG - 2011-09-26 09:12:35 --> Output Class Initialized
DEBUG - 2011-09-26 09:12:35 --> Input Class Initialized
DEBUG - 2011-09-26 09:12:35 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-26 09:12:35 --> Language Class Initialized
DEBUG - 2011-09-26 09:12:35 --> Loader Class Initialized
DEBUG - 2011-09-26 09:12:35 --> Controller Class Initialized
DEBUG - 2011-09-26 09:12:35 --> Model Class Initialized
DEBUG - 2011-09-26 09:12:35 --> Model Class Initialized
DEBUG - 2011-09-26 09:12:35 --> Model Class Initialized
DEBUG - 2011-09-26 09:12:35 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-26 09:12:35 --> Database Driver Class Initialized
DEBUG - 2011-09-26 09:12:35 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-26 09:12:35 --> Helper loaded: url_helper
DEBUG - 2011-09-26 09:12:35 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-26 09:12:35 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-26 09:12:35 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-26 09:12:35 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-26 09:12:35 --> Final output sent to browser
DEBUG - 2011-09-26 09:12:35 --> Total execution time: 0.2337
DEBUG - 2011-09-26 09:12:36 --> Config Class Initialized
DEBUG - 2011-09-26 09:12:36 --> Hooks Class Initialized
DEBUG - 2011-09-26 09:12:36 --> Utf8 Class Initialized
DEBUG - 2011-09-26 09:12:36 --> UTF-8 Support Enabled
DEBUG - 2011-09-26 09:12:36 --> URI Class Initialized
DEBUG - 2011-09-26 09:12:36 --> Router Class Initialized
DEBUG - 2011-09-26 09:12:36 --> Output Class Initialized
DEBUG - 2011-09-26 09:12:36 --> Input Class Initialized
DEBUG - 2011-09-26 09:12:36 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-26 09:12:36 --> Language Class Initialized
DEBUG - 2011-09-26 09:12:36 --> Loader Class Initialized
DEBUG - 2011-09-26 09:12:36 --> Controller Class Initialized
DEBUG - 2011-09-26 09:12:36 --> Model Class Initialized
DEBUG - 2011-09-26 09:12:36 --> Model Class Initialized
DEBUG - 2011-09-26 09:12:36 --> Model Class Initialized
DEBUG - 2011-09-26 09:12:36 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-26 09:12:36 --> Database Driver Class Initialized
DEBUG - 2011-09-26 09:12:36 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-26 09:12:36 --> Helper loaded: url_helper
DEBUG - 2011-09-26 09:12:36 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-26 09:12:36 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-26 09:12:36 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-26 09:12:36 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-26 09:12:36 --> Final output sent to browser
DEBUG - 2011-09-26 09:12:36 --> Total execution time: 0.1618
DEBUG - 2011-09-26 09:12:43 --> Config Class Initialized
DEBUG - 2011-09-26 09:12:43 --> Hooks Class Initialized
DEBUG - 2011-09-26 09:12:43 --> Utf8 Class Initialized
DEBUG - 2011-09-26 09:12:43 --> UTF-8 Support Enabled
DEBUG - 2011-09-26 09:12:43 --> URI Class Initialized
DEBUG - 2011-09-26 09:12:43 --> Router Class Initialized
DEBUG - 2011-09-26 09:12:43 --> Output Class Initialized
DEBUG - 2011-09-26 09:12:43 --> Input Class Initialized
DEBUG - 2011-09-26 09:12:43 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-26 09:12:43 --> Language Class Initialized
DEBUG - 2011-09-26 09:12:43 --> Loader Class Initialized
DEBUG - 2011-09-26 09:12:43 --> Controller Class Initialized
DEBUG - 2011-09-26 09:12:43 --> Model Class Initialized
DEBUG - 2011-09-26 09:12:43 --> Model Class Initialized
DEBUG - 2011-09-26 09:12:43 --> Model Class Initialized
DEBUG - 2011-09-26 09:12:43 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-26 09:12:43 --> Database Driver Class Initialized
DEBUG - 2011-09-26 09:12:43 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-26 09:12:43 --> Helper loaded: url_helper
DEBUG - 2011-09-26 09:12:43 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-26 09:12:43 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-26 09:12:43 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-26 09:12:43 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-26 09:12:43 --> Final output sent to browser
DEBUG - 2011-09-26 09:12:43 --> Total execution time: 0.0502
DEBUG - 2011-09-26 09:12:59 --> Config Class Initialized
DEBUG - 2011-09-26 09:12:59 --> Hooks Class Initialized
DEBUG - 2011-09-26 09:12:59 --> Utf8 Class Initialized
DEBUG - 2011-09-26 09:12:59 --> UTF-8 Support Enabled
DEBUG - 2011-09-26 09:12:59 --> URI Class Initialized
DEBUG - 2011-09-26 09:12:59 --> Router Class Initialized
DEBUG - 2011-09-26 09:12:59 --> Output Class Initialized
DEBUG - 2011-09-26 09:12:59 --> Input Class Initialized
DEBUG - 2011-09-26 09:12:59 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-26 09:12:59 --> Language Class Initialized
DEBUG - 2011-09-26 09:12:59 --> Loader Class Initialized
DEBUG - 2011-09-26 09:12:59 --> Controller Class Initialized
DEBUG - 2011-09-26 09:12:59 --> Model Class Initialized
DEBUG - 2011-09-26 09:12:59 --> Model Class Initialized
DEBUG - 2011-09-26 09:12:59 --> Model Class Initialized
DEBUG - 2011-09-26 09:12:59 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-26 09:12:59 --> Database Driver Class Initialized
DEBUG - 2011-09-26 09:12:59 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-26 09:12:59 --> Helper loaded: url_helper
DEBUG - 2011-09-26 09:12:59 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-26 09:12:59 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-26 09:12:59 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-26 09:12:59 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-26 09:12:59 --> Final output sent to browser
DEBUG - 2011-09-26 09:12:59 --> Total execution time: 0.4808
DEBUG - 2011-09-26 09:13:01 --> Config Class Initialized
DEBUG - 2011-09-26 09:13:01 --> Hooks Class Initialized
DEBUG - 2011-09-26 09:13:01 --> Utf8 Class Initialized
DEBUG - 2011-09-26 09:13:01 --> UTF-8 Support Enabled
DEBUG - 2011-09-26 09:13:01 --> URI Class Initialized
DEBUG - 2011-09-26 09:13:01 --> Router Class Initialized
DEBUG - 2011-09-26 09:13:01 --> Output Class Initialized
DEBUG - 2011-09-26 09:13:01 --> Input Class Initialized
DEBUG - 2011-09-26 09:13:01 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-26 09:13:01 --> Language Class Initialized
DEBUG - 2011-09-26 09:13:01 --> Loader Class Initialized
DEBUG - 2011-09-26 09:13:01 --> Controller Class Initialized
DEBUG - 2011-09-26 09:13:01 --> Model Class Initialized
DEBUG - 2011-09-26 09:13:01 --> Model Class Initialized
DEBUG - 2011-09-26 09:13:01 --> Model Class Initialized
DEBUG - 2011-09-26 09:13:01 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-26 09:13:01 --> Database Driver Class Initialized
DEBUG - 2011-09-26 09:13:01 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-26 09:13:01 --> Helper loaded: url_helper
DEBUG - 2011-09-26 09:13:01 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-26 09:13:01 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-26 09:13:01 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-26 09:13:01 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-26 09:13:01 --> Final output sent to browser
DEBUG - 2011-09-26 09:13:01 --> Total execution time: 0.0566
DEBUG - 2011-09-26 09:13:10 --> Config Class Initialized
DEBUG - 2011-09-26 09:13:10 --> Hooks Class Initialized
DEBUG - 2011-09-26 09:13:10 --> Utf8 Class Initialized
DEBUG - 2011-09-26 09:13:10 --> UTF-8 Support Enabled
DEBUG - 2011-09-26 09:13:10 --> URI Class Initialized
DEBUG - 2011-09-26 09:13:10 --> Router Class Initialized
DEBUG - 2011-09-26 09:13:10 --> Output Class Initialized
DEBUG - 2011-09-26 09:13:10 --> Input Class Initialized
DEBUG - 2011-09-26 09:13:10 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-26 09:13:10 --> Language Class Initialized
DEBUG - 2011-09-26 09:13:10 --> Loader Class Initialized
DEBUG - 2011-09-26 09:13:10 --> Controller Class Initialized
DEBUG - 2011-09-26 09:13:10 --> Model Class Initialized
DEBUG - 2011-09-26 09:13:10 --> Model Class Initialized
DEBUG - 2011-09-26 09:13:10 --> Model Class Initialized
DEBUG - 2011-09-26 09:13:10 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-26 09:13:10 --> Database Driver Class Initialized
DEBUG - 2011-09-26 09:13:10 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-26 09:13:10 --> Helper loaded: url_helper
DEBUG - 2011-09-26 09:13:10 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-26 09:13:10 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-26 09:13:10 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-26 09:13:10 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-26 09:13:10 --> Final output sent to browser
DEBUG - 2011-09-26 09:13:10 --> Total execution time: 0.2935
DEBUG - 2011-09-26 09:13:29 --> Config Class Initialized
DEBUG - 2011-09-26 09:13:29 --> Hooks Class Initialized
DEBUG - 2011-09-26 09:13:29 --> Utf8 Class Initialized
DEBUG - 2011-09-26 09:13:29 --> UTF-8 Support Enabled
DEBUG - 2011-09-26 09:13:29 --> URI Class Initialized
DEBUG - 2011-09-26 09:13:29 --> Router Class Initialized
DEBUG - 2011-09-26 09:13:29 --> Output Class Initialized
DEBUG - 2011-09-26 09:13:29 --> Input Class Initialized
DEBUG - 2011-09-26 09:13:29 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-26 09:13:29 --> Language Class Initialized
DEBUG - 2011-09-26 09:13:29 --> Loader Class Initialized
DEBUG - 2011-09-26 09:13:29 --> Controller Class Initialized
DEBUG - 2011-09-26 09:13:29 --> Model Class Initialized
DEBUG - 2011-09-26 09:13:29 --> Model Class Initialized
DEBUG - 2011-09-26 09:13:29 --> Model Class Initialized
DEBUG - 2011-09-26 09:13:29 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-26 09:13:29 --> Database Driver Class Initialized
DEBUG - 2011-09-26 09:13:29 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-26 09:13:29 --> Helper loaded: url_helper
DEBUG - 2011-09-26 09:13:29 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-26 09:13:29 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-26 09:13:29 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-26 09:13:29 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-26 09:13:29 --> Final output sent to browser
DEBUG - 2011-09-26 09:13:29 --> Total execution time: 0.0485
DEBUG - 2011-09-26 09:13:33 --> Config Class Initialized
DEBUG - 2011-09-26 09:13:33 --> Hooks Class Initialized
DEBUG - 2011-09-26 09:13:33 --> Utf8 Class Initialized
DEBUG - 2011-09-26 09:13:33 --> UTF-8 Support Enabled
DEBUG - 2011-09-26 09:13:33 --> URI Class Initialized
DEBUG - 2011-09-26 09:13:33 --> Router Class Initialized
DEBUG - 2011-09-26 09:13:33 --> Output Class Initialized
DEBUG - 2011-09-26 09:13:33 --> Input Class Initialized
DEBUG - 2011-09-26 09:13:33 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-26 09:13:33 --> Language Class Initialized
DEBUG - 2011-09-26 09:13:33 --> Loader Class Initialized
DEBUG - 2011-09-26 09:13:33 --> Controller Class Initialized
DEBUG - 2011-09-26 09:13:33 --> Model Class Initialized
DEBUG - 2011-09-26 09:13:33 --> Model Class Initialized
DEBUG - 2011-09-26 09:13:33 --> Model Class Initialized
DEBUG - 2011-09-26 09:13:33 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-26 09:13:33 --> Database Driver Class Initialized
DEBUG - 2011-09-26 09:13:33 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-26 09:13:33 --> Helper loaded: url_helper
DEBUG - 2011-09-26 09:13:33 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-26 09:13:33 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-26 09:13:33 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-26 09:13:33 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-26 09:13:33 --> Final output sent to browser
DEBUG - 2011-09-26 09:13:33 --> Total execution time: 0.2874
DEBUG - 2011-09-26 09:13:35 --> Config Class Initialized
DEBUG - 2011-09-26 09:13:35 --> Hooks Class Initialized
DEBUG - 2011-09-26 09:13:35 --> Utf8 Class Initialized
DEBUG - 2011-09-26 09:13:35 --> UTF-8 Support Enabled
DEBUG - 2011-09-26 09:13:35 --> URI Class Initialized
DEBUG - 2011-09-26 09:13:35 --> Router Class Initialized
DEBUG - 2011-09-26 09:13:35 --> Output Class Initialized
DEBUG - 2011-09-26 09:13:35 --> Input Class Initialized
DEBUG - 2011-09-26 09:13:35 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-26 09:13:35 --> Language Class Initialized
DEBUG - 2011-09-26 09:13:35 --> Loader Class Initialized
DEBUG - 2011-09-26 09:13:35 --> Controller Class Initialized
DEBUG - 2011-09-26 09:13:35 --> Model Class Initialized
DEBUG - 2011-09-26 09:13:35 --> Model Class Initialized
DEBUG - 2011-09-26 09:13:35 --> Model Class Initialized
DEBUG - 2011-09-26 09:13:35 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-26 09:13:35 --> Database Driver Class Initialized
DEBUG - 2011-09-26 09:13:35 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-26 09:13:35 --> Helper loaded: url_helper
DEBUG - 2011-09-26 09:13:35 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-26 09:13:35 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-26 09:13:35 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-26 09:13:35 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-26 09:13:35 --> Final output sent to browser
DEBUG - 2011-09-26 09:13:35 --> Total execution time: 0.1275
DEBUG - 2011-09-26 09:13:45 --> Config Class Initialized
DEBUG - 2011-09-26 09:13:45 --> Hooks Class Initialized
DEBUG - 2011-09-26 09:13:45 --> Utf8 Class Initialized
DEBUG - 2011-09-26 09:13:45 --> UTF-8 Support Enabled
DEBUG - 2011-09-26 09:13:45 --> URI Class Initialized
DEBUG - 2011-09-26 09:13:45 --> Router Class Initialized
DEBUG - 2011-09-26 09:13:45 --> Output Class Initialized
DEBUG - 2011-09-26 09:13:45 --> Input Class Initialized
DEBUG - 2011-09-26 09:13:45 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-26 09:13:45 --> Language Class Initialized
DEBUG - 2011-09-26 09:13:45 --> Loader Class Initialized
DEBUG - 2011-09-26 09:13:45 --> Controller Class Initialized
DEBUG - 2011-09-26 09:13:45 --> Model Class Initialized
DEBUG - 2011-09-26 09:13:45 --> Model Class Initialized
DEBUG - 2011-09-26 09:13:45 --> Model Class Initialized
DEBUG - 2011-09-26 09:13:45 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-26 09:13:45 --> Database Driver Class Initialized
DEBUG - 2011-09-26 09:13:45 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-26 09:13:45 --> Helper loaded: url_helper
DEBUG - 2011-09-26 09:13:45 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-26 09:13:45 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-26 09:13:45 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-26 09:13:45 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-26 09:13:45 --> Final output sent to browser
DEBUG - 2011-09-26 09:13:45 --> Total execution time: 0.3996
DEBUG - 2011-09-26 09:13:46 --> Config Class Initialized
DEBUG - 2011-09-26 09:13:46 --> Hooks Class Initialized
DEBUG - 2011-09-26 09:13:46 --> Utf8 Class Initialized
DEBUG - 2011-09-26 09:13:46 --> UTF-8 Support Enabled
DEBUG - 2011-09-26 09:13:46 --> URI Class Initialized
DEBUG - 2011-09-26 09:13:46 --> Router Class Initialized
DEBUG - 2011-09-26 09:13:46 --> Output Class Initialized
DEBUG - 2011-09-26 09:13:46 --> Input Class Initialized
DEBUG - 2011-09-26 09:13:46 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-26 09:13:46 --> Language Class Initialized
DEBUG - 2011-09-26 09:13:46 --> Loader Class Initialized
DEBUG - 2011-09-26 09:13:46 --> Controller Class Initialized
DEBUG - 2011-09-26 09:13:46 --> Model Class Initialized
DEBUG - 2011-09-26 09:13:46 --> Model Class Initialized
DEBUG - 2011-09-26 09:13:46 --> Model Class Initialized
DEBUG - 2011-09-26 09:13:46 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-26 09:13:46 --> Database Driver Class Initialized
DEBUG - 2011-09-26 09:13:46 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-26 09:13:46 --> Helper loaded: url_helper
DEBUG - 2011-09-26 09:13:46 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-26 09:13:46 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-26 09:13:46 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-26 09:13:46 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-26 09:13:46 --> Final output sent to browser
DEBUG - 2011-09-26 09:13:46 --> Total execution time: 0.0487
DEBUG - 2011-09-26 09:13:56 --> Config Class Initialized
DEBUG - 2011-09-26 09:13:56 --> Hooks Class Initialized
DEBUG - 2011-09-26 09:13:56 --> Utf8 Class Initialized
DEBUG - 2011-09-26 09:13:56 --> UTF-8 Support Enabled
DEBUG - 2011-09-26 09:13:56 --> URI Class Initialized
DEBUG - 2011-09-26 09:13:56 --> Router Class Initialized
DEBUG - 2011-09-26 09:13:56 --> Output Class Initialized
DEBUG - 2011-09-26 09:13:56 --> Input Class Initialized
DEBUG - 2011-09-26 09:13:56 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-26 09:13:56 --> Language Class Initialized
DEBUG - 2011-09-26 09:13:56 --> Loader Class Initialized
DEBUG - 2011-09-26 09:13:56 --> Controller Class Initialized
DEBUG - 2011-09-26 09:13:56 --> Model Class Initialized
DEBUG - 2011-09-26 09:13:56 --> Model Class Initialized
DEBUG - 2011-09-26 09:13:56 --> Model Class Initialized
DEBUG - 2011-09-26 09:13:56 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-26 09:13:56 --> Database Driver Class Initialized
DEBUG - 2011-09-26 09:13:56 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-26 09:13:56 --> Helper loaded: url_helper
DEBUG - 2011-09-26 09:13:57 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-26 09:13:57 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-26 09:13:57 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-26 09:13:57 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-26 09:13:57 --> Final output sent to browser
DEBUG - 2011-09-26 09:13:57 --> Total execution time: 0.2044
DEBUG - 2011-09-26 09:14:03 --> Config Class Initialized
DEBUG - 2011-09-26 09:14:03 --> Hooks Class Initialized
DEBUG - 2011-09-26 09:14:03 --> Utf8 Class Initialized
DEBUG - 2011-09-26 09:14:03 --> UTF-8 Support Enabled
DEBUG - 2011-09-26 09:14:03 --> URI Class Initialized
DEBUG - 2011-09-26 09:14:03 --> Router Class Initialized
DEBUG - 2011-09-26 09:14:03 --> Output Class Initialized
DEBUG - 2011-09-26 09:14:03 --> Input Class Initialized
DEBUG - 2011-09-26 09:14:03 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-26 09:14:03 --> Language Class Initialized
DEBUG - 2011-09-26 09:14:03 --> Loader Class Initialized
DEBUG - 2011-09-26 09:14:03 --> Controller Class Initialized
DEBUG - 2011-09-26 09:14:03 --> Model Class Initialized
DEBUG - 2011-09-26 09:14:03 --> Model Class Initialized
DEBUG - 2011-09-26 09:14:03 --> Model Class Initialized
DEBUG - 2011-09-26 09:14:03 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-26 09:14:03 --> Database Driver Class Initialized
DEBUG - 2011-09-26 09:14:03 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-26 09:14:03 --> Helper loaded: url_helper
DEBUG - 2011-09-26 09:14:03 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-26 09:14:03 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-26 09:14:03 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-26 09:14:03 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-26 09:14:03 --> Final output sent to browser
DEBUG - 2011-09-26 09:14:03 --> Total execution time: 0.3271
DEBUG - 2011-09-26 09:14:04 --> Config Class Initialized
DEBUG - 2011-09-26 09:14:04 --> Hooks Class Initialized
DEBUG - 2011-09-26 09:14:04 --> Utf8 Class Initialized
DEBUG - 2011-09-26 09:14:04 --> UTF-8 Support Enabled
DEBUG - 2011-09-26 09:14:04 --> URI Class Initialized
DEBUG - 2011-09-26 09:14:04 --> Router Class Initialized
DEBUG - 2011-09-26 09:14:04 --> Output Class Initialized
DEBUG - 2011-09-26 09:14:04 --> Input Class Initialized
DEBUG - 2011-09-26 09:14:04 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-26 09:14:04 --> Language Class Initialized
DEBUG - 2011-09-26 09:14:04 --> Loader Class Initialized
DEBUG - 2011-09-26 09:14:04 --> Controller Class Initialized
DEBUG - 2011-09-26 09:14:04 --> Model Class Initialized
DEBUG - 2011-09-26 09:14:04 --> Model Class Initialized
DEBUG - 2011-09-26 09:14:04 --> Model Class Initialized
DEBUG - 2011-09-26 09:14:04 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-26 09:14:04 --> Database Driver Class Initialized
DEBUG - 2011-09-26 09:14:04 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-26 09:14:04 --> Helper loaded: url_helper
DEBUG - 2011-09-26 09:14:04 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-26 09:14:04 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-26 09:14:04 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-26 09:14:04 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-26 09:14:04 --> Final output sent to browser
DEBUG - 2011-09-26 09:14:04 --> Total execution time: 0.0534
DEBUG - 2011-09-26 09:14:10 --> Config Class Initialized
DEBUG - 2011-09-26 09:14:10 --> Hooks Class Initialized
DEBUG - 2011-09-26 09:14:10 --> Utf8 Class Initialized
DEBUG - 2011-09-26 09:14:10 --> UTF-8 Support Enabled
DEBUG - 2011-09-26 09:14:10 --> URI Class Initialized
DEBUG - 2011-09-26 09:14:10 --> Router Class Initialized
DEBUG - 2011-09-26 09:14:10 --> Output Class Initialized
DEBUG - 2011-09-26 09:14:10 --> Input Class Initialized
DEBUG - 2011-09-26 09:14:10 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-26 09:14:10 --> Language Class Initialized
DEBUG - 2011-09-26 09:14:10 --> Loader Class Initialized
DEBUG - 2011-09-26 09:14:10 --> Controller Class Initialized
DEBUG - 2011-09-26 09:14:10 --> Model Class Initialized
DEBUG - 2011-09-26 09:14:10 --> Model Class Initialized
DEBUG - 2011-09-26 09:14:10 --> Model Class Initialized
DEBUG - 2011-09-26 09:14:10 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-26 09:14:10 --> Database Driver Class Initialized
DEBUG - 2011-09-26 09:14:11 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-26 09:14:11 --> Helper loaded: url_helper
DEBUG - 2011-09-26 09:14:11 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-26 09:14:11 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-26 09:14:11 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-26 09:14:11 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-26 09:14:11 --> Final output sent to browser
DEBUG - 2011-09-26 09:14:11 --> Total execution time: 0.7515
DEBUG - 2011-09-26 09:14:22 --> Config Class Initialized
DEBUG - 2011-09-26 09:14:22 --> Hooks Class Initialized
DEBUG - 2011-09-26 09:14:22 --> Utf8 Class Initialized
DEBUG - 2011-09-26 09:14:22 --> UTF-8 Support Enabled
DEBUG - 2011-09-26 09:14:22 --> URI Class Initialized
DEBUG - 2011-09-26 09:14:22 --> Router Class Initialized
DEBUG - 2011-09-26 09:14:22 --> Output Class Initialized
DEBUG - 2011-09-26 09:14:22 --> Input Class Initialized
DEBUG - 2011-09-26 09:14:22 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-26 09:14:22 --> Language Class Initialized
DEBUG - 2011-09-26 09:14:22 --> Loader Class Initialized
DEBUG - 2011-09-26 09:14:22 --> Controller Class Initialized
DEBUG - 2011-09-26 09:14:22 --> Model Class Initialized
DEBUG - 2011-09-26 09:14:22 --> Model Class Initialized
DEBUG - 2011-09-26 09:14:22 --> Model Class Initialized
DEBUG - 2011-09-26 09:14:22 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-26 09:14:22 --> Database Driver Class Initialized
DEBUG - 2011-09-26 09:14:22 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-26 09:14:22 --> Helper loaded: url_helper
DEBUG - 2011-09-26 09:14:22 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-26 09:14:22 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-26 09:14:22 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-26 09:14:22 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-26 09:14:22 --> Final output sent to browser
DEBUG - 2011-09-26 09:14:22 --> Total execution time: 0.0527
DEBUG - 2011-09-26 09:25:19 --> Config Class Initialized
DEBUG - 2011-09-26 09:25:19 --> Hooks Class Initialized
DEBUG - 2011-09-26 09:25:19 --> Utf8 Class Initialized
DEBUG - 2011-09-26 09:25:19 --> UTF-8 Support Enabled
DEBUG - 2011-09-26 09:25:19 --> URI Class Initialized
DEBUG - 2011-09-26 09:25:19 --> Router Class Initialized
DEBUG - 2011-09-26 09:25:19 --> Output Class Initialized
DEBUG - 2011-09-26 09:25:19 --> Input Class Initialized
DEBUG - 2011-09-26 09:25:19 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-26 09:25:19 --> Language Class Initialized
DEBUG - 2011-09-26 09:25:19 --> Loader Class Initialized
DEBUG - 2011-09-26 09:25:19 --> Controller Class Initialized
DEBUG - 2011-09-26 09:25:19 --> Model Class Initialized
DEBUG - 2011-09-26 09:25:19 --> Model Class Initialized
DEBUG - 2011-09-26 09:25:19 --> Model Class Initialized
DEBUG - 2011-09-26 09:25:19 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-26 09:25:19 --> Database Driver Class Initialized
DEBUG - 2011-09-26 09:25:19 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-26 09:25:19 --> Helper loaded: url_helper
DEBUG - 2011-09-26 09:25:19 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-26 09:25:19 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-26 09:25:19 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-26 09:25:19 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-26 09:25:19 --> Final output sent to browser
DEBUG - 2011-09-26 09:25:19 --> Total execution time: 0.0666
DEBUG - 2011-09-26 09:56:19 --> Config Class Initialized
DEBUG - 2011-09-26 09:56:19 --> Hooks Class Initialized
DEBUG - 2011-09-26 09:56:19 --> Utf8 Class Initialized
DEBUG - 2011-09-26 09:56:19 --> UTF-8 Support Enabled
DEBUG - 2011-09-26 09:56:19 --> URI Class Initialized
DEBUG - 2011-09-26 09:56:19 --> Router Class Initialized
DEBUG - 2011-09-26 09:56:19 --> Output Class Initialized
DEBUG - 2011-09-26 09:56:19 --> Input Class Initialized
DEBUG - 2011-09-26 09:56:19 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-26 09:56:19 --> Language Class Initialized
DEBUG - 2011-09-26 09:56:19 --> Loader Class Initialized
DEBUG - 2011-09-26 09:56:19 --> Controller Class Initialized
DEBUG - 2011-09-26 09:56:19 --> Model Class Initialized
DEBUG - 2011-09-26 09:56:19 --> Model Class Initialized
DEBUG - 2011-09-26 09:56:19 --> Model Class Initialized
DEBUG - 2011-09-26 09:56:19 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-26 09:56:19 --> Database Driver Class Initialized
DEBUG - 2011-09-26 09:56:21 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-26 09:56:21 --> Helper loaded: url_helper
DEBUG - 2011-09-26 09:56:21 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-26 09:56:21 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-26 09:56:21 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-26 09:56:21 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-26 09:56:21 --> Final output sent to browser
DEBUG - 2011-09-26 09:56:21 --> Total execution time: 1.2611
DEBUG - 2011-09-26 09:56:23 --> Config Class Initialized
DEBUG - 2011-09-26 09:56:23 --> Hooks Class Initialized
DEBUG - 2011-09-26 09:56:23 --> Utf8 Class Initialized
DEBUG - 2011-09-26 09:56:23 --> UTF-8 Support Enabled
DEBUG - 2011-09-26 09:56:23 --> URI Class Initialized
DEBUG - 2011-09-26 09:56:23 --> Router Class Initialized
ERROR - 2011-09-26 09:56:23 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-26 09:56:23 --> Config Class Initialized
DEBUG - 2011-09-26 09:56:23 --> Hooks Class Initialized
DEBUG - 2011-09-26 09:56:23 --> Utf8 Class Initialized
DEBUG - 2011-09-26 09:56:23 --> UTF-8 Support Enabled
DEBUG - 2011-09-26 09:56:23 --> URI Class Initialized
DEBUG - 2011-09-26 09:56:23 --> Router Class Initialized
ERROR - 2011-09-26 09:56:23 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-26 09:56:24 --> Config Class Initialized
DEBUG - 2011-09-26 09:56:24 --> Hooks Class Initialized
DEBUG - 2011-09-26 09:56:24 --> Utf8 Class Initialized
DEBUG - 2011-09-26 09:56:24 --> UTF-8 Support Enabled
DEBUG - 2011-09-26 09:56:24 --> URI Class Initialized
DEBUG - 2011-09-26 09:56:24 --> Router Class Initialized
ERROR - 2011-09-26 09:56:24 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-26 09:57:37 --> Config Class Initialized
DEBUG - 2011-09-26 09:57:37 --> Hooks Class Initialized
DEBUG - 2011-09-26 09:57:37 --> Utf8 Class Initialized
DEBUG - 2011-09-26 09:57:37 --> UTF-8 Support Enabled
DEBUG - 2011-09-26 09:57:37 --> URI Class Initialized
DEBUG - 2011-09-26 09:57:37 --> Router Class Initialized
DEBUG - 2011-09-26 09:57:37 --> Output Class Initialized
DEBUG - 2011-09-26 09:57:37 --> Input Class Initialized
DEBUG - 2011-09-26 09:57:37 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-26 09:57:37 --> Language Class Initialized
DEBUG - 2011-09-26 09:57:37 --> Loader Class Initialized
DEBUG - 2011-09-26 09:57:37 --> Controller Class Initialized
DEBUG - 2011-09-26 09:57:37 --> Model Class Initialized
DEBUG - 2011-09-26 09:57:37 --> Model Class Initialized
DEBUG - 2011-09-26 09:57:37 --> Model Class Initialized
DEBUG - 2011-09-26 09:57:37 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-26 09:57:37 --> Database Driver Class Initialized
DEBUG - 2011-09-26 09:57:38 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-26 09:57:38 --> Helper loaded: url_helper
DEBUG - 2011-09-26 09:57:38 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-26 09:57:38 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-26 09:57:38 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-26 09:57:38 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-26 09:57:38 --> Final output sent to browser
DEBUG - 2011-09-26 09:57:38 --> Total execution time: 0.2944
DEBUG - 2011-09-26 09:57:40 --> Config Class Initialized
DEBUG - 2011-09-26 09:57:40 --> Hooks Class Initialized
DEBUG - 2011-09-26 09:57:40 --> Utf8 Class Initialized
DEBUG - 2011-09-26 09:57:40 --> UTF-8 Support Enabled
DEBUG - 2011-09-26 09:57:40 --> URI Class Initialized
DEBUG - 2011-09-26 09:57:40 --> Router Class Initialized
ERROR - 2011-09-26 09:57:40 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-09-26 09:57:40 --> Config Class Initialized
DEBUG - 2011-09-26 09:57:40 --> Hooks Class Initialized
DEBUG - 2011-09-26 09:57:40 --> Utf8 Class Initialized
DEBUG - 2011-09-26 09:57:40 --> UTF-8 Support Enabled
DEBUG - 2011-09-26 09:57:40 --> URI Class Initialized
DEBUG - 2011-09-26 09:57:40 --> Router Class Initialized
DEBUG - 2011-09-26 09:57:40 --> Output Class Initialized
DEBUG - 2011-09-26 09:57:40 --> Input Class Initialized
DEBUG - 2011-09-26 09:57:40 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-26 09:57:40 --> Language Class Initialized
DEBUG - 2011-09-26 09:57:40 --> Loader Class Initialized
DEBUG - 2011-09-26 09:57:40 --> Controller Class Initialized
DEBUG - 2011-09-26 09:57:40 --> Model Class Initialized
DEBUG - 2011-09-26 09:57:40 --> Model Class Initialized
DEBUG - 2011-09-26 09:57:40 --> Model Class Initialized
DEBUG - 2011-09-26 09:57:40 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-26 09:57:40 --> Database Driver Class Initialized
DEBUG - 2011-09-26 09:57:40 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-26 09:57:40 --> Helper loaded: url_helper
DEBUG - 2011-09-26 09:57:40 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-26 09:57:40 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-26 09:57:40 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-26 09:57:40 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-26 09:57:40 --> Final output sent to browser
DEBUG - 2011-09-26 09:57:40 --> Total execution time: 0.1810
DEBUG - 2011-09-26 09:58:46 --> Config Class Initialized
DEBUG - 2011-09-26 09:58:46 --> Hooks Class Initialized
DEBUG - 2011-09-26 09:58:46 --> Utf8 Class Initialized
DEBUG - 2011-09-26 09:58:46 --> UTF-8 Support Enabled
DEBUG - 2011-09-26 09:58:46 --> URI Class Initialized
DEBUG - 2011-09-26 09:58:46 --> Router Class Initialized
DEBUG - 2011-09-26 09:58:46 --> Output Class Initialized
DEBUG - 2011-09-26 09:58:46 --> Input Class Initialized
DEBUG - 2011-09-26 09:58:46 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-26 09:58:46 --> Language Class Initialized
DEBUG - 2011-09-26 09:58:46 --> Loader Class Initialized
DEBUG - 2011-09-26 09:58:46 --> Controller Class Initialized
DEBUG - 2011-09-26 09:58:46 --> Model Class Initialized
DEBUG - 2011-09-26 09:58:46 --> Model Class Initialized
DEBUG - 2011-09-26 09:58:46 --> Model Class Initialized
DEBUG - 2011-09-26 09:58:46 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-26 09:58:46 --> Database Driver Class Initialized
DEBUG - 2011-09-26 09:58:46 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-26 09:58:46 --> Helper loaded: url_helper
DEBUG - 2011-09-26 09:58:46 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-26 09:58:46 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-26 09:58:46 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-26 09:58:46 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-26 09:58:46 --> Final output sent to browser
DEBUG - 2011-09-26 09:58:46 --> Total execution time: 0.4902
DEBUG - 2011-09-26 09:58:52 --> Config Class Initialized
DEBUG - 2011-09-26 09:58:52 --> Hooks Class Initialized
DEBUG - 2011-09-26 09:58:52 --> Utf8 Class Initialized
DEBUG - 2011-09-26 09:58:52 --> UTF-8 Support Enabled
DEBUG - 2011-09-26 09:58:52 --> URI Class Initialized
DEBUG - 2011-09-26 09:58:52 --> Router Class Initialized
DEBUG - 2011-09-26 09:58:52 --> Output Class Initialized
DEBUG - 2011-09-26 09:58:52 --> Input Class Initialized
DEBUG - 2011-09-26 09:58:52 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-26 09:58:52 --> Language Class Initialized
DEBUG - 2011-09-26 09:58:52 --> Loader Class Initialized
DEBUG - 2011-09-26 09:58:52 --> Controller Class Initialized
DEBUG - 2011-09-26 09:58:52 --> Model Class Initialized
DEBUG - 2011-09-26 09:58:52 --> Model Class Initialized
DEBUG - 2011-09-26 09:58:52 --> Model Class Initialized
DEBUG - 2011-09-26 09:58:52 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-26 09:58:52 --> Database Driver Class Initialized
DEBUG - 2011-09-26 09:58:52 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-26 09:58:52 --> Helper loaded: url_helper
DEBUG - 2011-09-26 09:58:52 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-26 09:58:52 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-26 09:58:52 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-26 09:58:52 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-26 09:58:52 --> Final output sent to browser
DEBUG - 2011-09-26 09:58:52 --> Total execution time: 0.1654
DEBUG - 2011-09-26 09:59:19 --> Config Class Initialized
DEBUG - 2011-09-26 09:59:19 --> Hooks Class Initialized
DEBUG - 2011-09-26 09:59:19 --> Utf8 Class Initialized
DEBUG - 2011-09-26 09:59:19 --> UTF-8 Support Enabled
DEBUG - 2011-09-26 09:59:19 --> URI Class Initialized
DEBUG - 2011-09-26 09:59:19 --> Router Class Initialized
DEBUG - 2011-09-26 09:59:19 --> Output Class Initialized
DEBUG - 2011-09-26 09:59:19 --> Input Class Initialized
DEBUG - 2011-09-26 09:59:19 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-26 09:59:19 --> Language Class Initialized
DEBUG - 2011-09-26 09:59:19 --> Loader Class Initialized
DEBUG - 2011-09-26 09:59:19 --> Controller Class Initialized
DEBUG - 2011-09-26 09:59:19 --> Model Class Initialized
DEBUG - 2011-09-26 09:59:19 --> Model Class Initialized
DEBUG - 2011-09-26 09:59:19 --> Model Class Initialized
DEBUG - 2011-09-26 09:59:19 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-26 09:59:19 --> Database Driver Class Initialized
DEBUG - 2011-09-26 09:59:19 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-26 09:59:19 --> Helper loaded: url_helper
DEBUG - 2011-09-26 09:59:19 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-26 09:59:19 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-26 09:59:19 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-26 09:59:19 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-26 09:59:19 --> Final output sent to browser
DEBUG - 2011-09-26 09:59:19 --> Total execution time: 0.4507
DEBUG - 2011-09-26 09:59:24 --> Config Class Initialized
DEBUG - 2011-09-26 09:59:24 --> Hooks Class Initialized
DEBUG - 2011-09-26 09:59:24 --> Utf8 Class Initialized
DEBUG - 2011-09-26 09:59:24 --> UTF-8 Support Enabled
DEBUG - 2011-09-26 09:59:24 --> URI Class Initialized
DEBUG - 2011-09-26 09:59:24 --> Router Class Initialized
DEBUG - 2011-09-26 09:59:24 --> Output Class Initialized
DEBUG - 2011-09-26 09:59:24 --> Input Class Initialized
DEBUG - 2011-09-26 09:59:24 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-26 09:59:24 --> Language Class Initialized
DEBUG - 2011-09-26 09:59:24 --> Loader Class Initialized
DEBUG - 2011-09-26 09:59:24 --> Controller Class Initialized
DEBUG - 2011-09-26 09:59:24 --> Model Class Initialized
DEBUG - 2011-09-26 09:59:24 --> Model Class Initialized
DEBUG - 2011-09-26 09:59:24 --> Model Class Initialized
DEBUG - 2011-09-26 09:59:24 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-26 09:59:24 --> Database Driver Class Initialized
DEBUG - 2011-09-26 09:59:24 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-26 09:59:24 --> Helper loaded: url_helper
DEBUG - 2011-09-26 09:59:24 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-26 09:59:24 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-26 09:59:24 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-26 09:59:24 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-26 09:59:24 --> Final output sent to browser
DEBUG - 2011-09-26 09:59:24 --> Total execution time: 0.0830
DEBUG - 2011-09-26 10:00:09 --> Config Class Initialized
DEBUG - 2011-09-26 10:00:09 --> Hooks Class Initialized
DEBUG - 2011-09-26 10:00:09 --> Utf8 Class Initialized
DEBUG - 2011-09-26 10:00:09 --> UTF-8 Support Enabled
DEBUG - 2011-09-26 10:00:09 --> URI Class Initialized
DEBUG - 2011-09-26 10:00:09 --> Router Class Initialized
DEBUG - 2011-09-26 10:00:09 --> Output Class Initialized
DEBUG - 2011-09-26 10:00:09 --> Input Class Initialized
DEBUG - 2011-09-26 10:00:09 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-26 10:00:09 --> Language Class Initialized
DEBUG - 2011-09-26 10:00:09 --> Loader Class Initialized
DEBUG - 2011-09-26 10:00:09 --> Controller Class Initialized
DEBUG - 2011-09-26 10:00:09 --> Model Class Initialized
DEBUG - 2011-09-26 10:00:09 --> Model Class Initialized
DEBUG - 2011-09-26 10:00:09 --> Model Class Initialized
DEBUG - 2011-09-26 10:00:09 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-26 10:00:10 --> Database Driver Class Initialized
DEBUG - 2011-09-26 10:00:12 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-26 10:00:12 --> Helper loaded: url_helper
DEBUG - 2011-09-26 10:00:12 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-26 10:00:12 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-26 10:00:12 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-26 10:00:12 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-26 10:00:12 --> Final output sent to browser
DEBUG - 2011-09-26 10:00:12 --> Total execution time: 2.5934
DEBUG - 2011-09-26 10:00:18 --> Config Class Initialized
DEBUG - 2011-09-26 10:00:18 --> Hooks Class Initialized
DEBUG - 2011-09-26 10:00:18 --> Utf8 Class Initialized
DEBUG - 2011-09-26 10:00:18 --> UTF-8 Support Enabled
DEBUG - 2011-09-26 10:00:18 --> URI Class Initialized
DEBUG - 2011-09-26 10:00:18 --> Router Class Initialized
DEBUG - 2011-09-26 10:00:18 --> Output Class Initialized
DEBUG - 2011-09-26 10:00:18 --> Input Class Initialized
DEBUG - 2011-09-26 10:00:18 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-26 10:00:18 --> Language Class Initialized
DEBUG - 2011-09-26 10:00:18 --> Loader Class Initialized
DEBUG - 2011-09-26 10:00:18 --> Controller Class Initialized
DEBUG - 2011-09-26 10:00:18 --> Model Class Initialized
DEBUG - 2011-09-26 10:00:18 --> Model Class Initialized
DEBUG - 2011-09-26 10:00:18 --> Model Class Initialized
DEBUG - 2011-09-26 10:00:18 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-26 10:00:18 --> Database Driver Class Initialized
DEBUG - 2011-09-26 10:00:18 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-26 10:00:18 --> Helper loaded: url_helper
DEBUG - 2011-09-26 10:00:18 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-26 10:00:18 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-26 10:00:18 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-26 10:00:18 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-26 10:00:18 --> Final output sent to browser
DEBUG - 2011-09-26 10:00:18 --> Total execution time: 0.4179
DEBUG - 2011-09-26 10:00:43 --> Config Class Initialized
DEBUG - 2011-09-26 10:00:43 --> Hooks Class Initialized
DEBUG - 2011-09-26 10:00:43 --> Utf8 Class Initialized
DEBUG - 2011-09-26 10:00:43 --> UTF-8 Support Enabled
DEBUG - 2011-09-26 10:00:43 --> URI Class Initialized
DEBUG - 2011-09-26 10:00:43 --> Router Class Initialized
DEBUG - 2011-09-26 10:00:43 --> Output Class Initialized
DEBUG - 2011-09-26 10:00:43 --> Input Class Initialized
DEBUG - 2011-09-26 10:00:43 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-26 10:00:43 --> Language Class Initialized
DEBUG - 2011-09-26 10:00:43 --> Loader Class Initialized
DEBUG - 2011-09-26 10:00:43 --> Controller Class Initialized
DEBUG - 2011-09-26 10:00:43 --> Model Class Initialized
DEBUG - 2011-09-26 10:00:43 --> Model Class Initialized
DEBUG - 2011-09-26 10:00:43 --> Model Class Initialized
DEBUG - 2011-09-26 10:00:43 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-26 10:00:43 --> Database Driver Class Initialized
DEBUG - 2011-09-26 10:00:45 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-26 10:00:45 --> Helper loaded: url_helper
DEBUG - 2011-09-26 10:00:45 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-26 10:00:45 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-26 10:00:45 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-26 10:00:45 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-26 10:00:45 --> Final output sent to browser
DEBUG - 2011-09-26 10:00:45 --> Total execution time: 1.7464
DEBUG - 2011-09-26 10:16:40 --> Config Class Initialized
DEBUG - 2011-09-26 10:16:40 --> Hooks Class Initialized
DEBUG - 2011-09-26 10:16:40 --> Utf8 Class Initialized
DEBUG - 2011-09-26 10:16:40 --> UTF-8 Support Enabled
DEBUG - 2011-09-26 10:16:40 --> URI Class Initialized
DEBUG - 2011-09-26 10:16:40 --> Router Class Initialized
DEBUG - 2011-09-26 10:16:40 --> Output Class Initialized
DEBUG - 2011-09-26 10:16:40 --> Input Class Initialized
DEBUG - 2011-09-26 10:16:40 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-26 10:16:40 --> Language Class Initialized
DEBUG - 2011-09-26 10:16:40 --> Loader Class Initialized
DEBUG - 2011-09-26 10:16:40 --> Controller Class Initialized
DEBUG - 2011-09-26 10:16:40 --> Model Class Initialized
DEBUG - 2011-09-26 10:16:40 --> Model Class Initialized
DEBUG - 2011-09-26 10:16:40 --> Model Class Initialized
DEBUG - 2011-09-26 10:16:40 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-26 10:16:40 --> Database Driver Class Initialized
DEBUG - 2011-09-26 10:16:41 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-26 10:16:41 --> Helper loaded: url_helper
DEBUG - 2011-09-26 10:16:41 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-26 10:16:41 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-26 10:16:41 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-26 10:16:41 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-26 10:16:41 --> Final output sent to browser
DEBUG - 2011-09-26 10:16:41 --> Total execution time: 1.0417
DEBUG - 2011-09-26 10:16:42 --> Config Class Initialized
DEBUG - 2011-09-26 10:16:42 --> Hooks Class Initialized
DEBUG - 2011-09-26 10:16:42 --> Utf8 Class Initialized
DEBUG - 2011-09-26 10:16:42 --> UTF-8 Support Enabled
DEBUG - 2011-09-26 10:16:42 --> URI Class Initialized
DEBUG - 2011-09-26 10:16:42 --> Router Class Initialized
DEBUG - 2011-09-26 10:16:42 --> Output Class Initialized
DEBUG - 2011-09-26 10:16:42 --> Input Class Initialized
DEBUG - 2011-09-26 10:16:42 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-26 10:16:42 --> Language Class Initialized
DEBUG - 2011-09-26 10:16:42 --> Loader Class Initialized
DEBUG - 2011-09-26 10:16:42 --> Controller Class Initialized
ERROR - 2011-09-26 10:16:42 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-26 10:16:42 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-26 10:16:42 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-26 10:16:42 --> Model Class Initialized
DEBUG - 2011-09-26 10:16:42 --> Model Class Initialized
DEBUG - 2011-09-26 10:16:42 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-26 10:16:42 --> Database Driver Class Initialized
DEBUG - 2011-09-26 10:16:42 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-26 10:16:42 --> Helper loaded: url_helper
DEBUG - 2011-09-26 10:16:42 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-26 10:16:42 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-26 10:16:42 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-26 10:16:42 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-26 10:16:42 --> Final output sent to browser
DEBUG - 2011-09-26 10:16:42 --> Total execution time: 0.0417
DEBUG - 2011-09-26 10:34:16 --> Config Class Initialized
DEBUG - 2011-09-26 10:34:16 --> Hooks Class Initialized
DEBUG - 2011-09-26 10:34:16 --> Utf8 Class Initialized
DEBUG - 2011-09-26 10:34:16 --> UTF-8 Support Enabled
DEBUG - 2011-09-26 10:34:16 --> URI Class Initialized
DEBUG - 2011-09-26 10:34:16 --> Router Class Initialized
DEBUG - 2011-09-26 10:34:16 --> Output Class Initialized
DEBUG - 2011-09-26 10:34:16 --> Input Class Initialized
DEBUG - 2011-09-26 10:34:16 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-26 10:34:16 --> Language Class Initialized
DEBUG - 2011-09-26 10:34:16 --> Loader Class Initialized
DEBUG - 2011-09-26 10:34:16 --> Controller Class Initialized
ERROR - 2011-09-26 10:34:16 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-26 10:34:16 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-26 10:34:16 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-26 10:34:16 --> Model Class Initialized
DEBUG - 2011-09-26 10:34:16 --> Model Class Initialized
DEBUG - 2011-09-26 10:34:16 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-26 10:34:16 --> Database Driver Class Initialized
DEBUG - 2011-09-26 10:34:16 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-26 10:34:16 --> Helper loaded: url_helper
DEBUG - 2011-09-26 10:34:16 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-26 10:34:16 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-26 10:34:16 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-26 10:34:16 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-26 10:34:16 --> Final output sent to browser
DEBUG - 2011-09-26 10:34:16 --> Total execution time: 0.2156
DEBUG - 2011-09-26 10:34:19 --> Config Class Initialized
DEBUG - 2011-09-26 10:34:19 --> Hooks Class Initialized
DEBUG - 2011-09-26 10:34:19 --> Utf8 Class Initialized
DEBUG - 2011-09-26 10:34:19 --> UTF-8 Support Enabled
DEBUG - 2011-09-26 10:34:19 --> URI Class Initialized
DEBUG - 2011-09-26 10:34:19 --> Router Class Initialized
DEBUG - 2011-09-26 10:34:19 --> Output Class Initialized
DEBUG - 2011-09-26 10:34:19 --> Input Class Initialized
DEBUG - 2011-09-26 10:34:19 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-26 10:34:19 --> Language Class Initialized
DEBUG - 2011-09-26 10:34:19 --> Loader Class Initialized
DEBUG - 2011-09-26 10:34:19 --> Controller Class Initialized
DEBUG - 2011-09-26 10:34:19 --> Model Class Initialized
DEBUG - 2011-09-26 10:34:19 --> Model Class Initialized
DEBUG - 2011-09-26 10:34:19 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-26 10:34:19 --> Database Driver Class Initialized
DEBUG - 2011-09-26 10:34:20 --> Final output sent to browser
DEBUG - 2011-09-26 10:34:20 --> Total execution time: 1.1586
DEBUG - 2011-09-26 10:34:23 --> Config Class Initialized
DEBUG - 2011-09-26 10:34:23 --> Hooks Class Initialized
DEBUG - 2011-09-26 10:34:23 --> Utf8 Class Initialized
DEBUG - 2011-09-26 10:34:23 --> UTF-8 Support Enabled
DEBUG - 2011-09-26 10:34:23 --> URI Class Initialized
DEBUG - 2011-09-26 10:34:23 --> Router Class Initialized
ERROR - 2011-09-26 10:34:23 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-26 10:34:47 --> Config Class Initialized
DEBUG - 2011-09-26 10:34:47 --> Hooks Class Initialized
DEBUG - 2011-09-26 10:34:47 --> Utf8 Class Initialized
DEBUG - 2011-09-26 10:34:47 --> UTF-8 Support Enabled
DEBUG - 2011-09-26 10:34:47 --> URI Class Initialized
DEBUG - 2011-09-26 10:34:47 --> Router Class Initialized
DEBUG - 2011-09-26 10:34:47 --> Output Class Initialized
DEBUG - 2011-09-26 10:34:47 --> Input Class Initialized
DEBUG - 2011-09-26 10:34:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-26 10:34:47 --> Language Class Initialized
DEBUG - 2011-09-26 10:34:47 --> Loader Class Initialized
DEBUG - 2011-09-26 10:34:47 --> Controller Class Initialized
ERROR - 2011-09-26 10:34:47 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-26 10:34:47 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-26 10:34:47 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-26 10:34:47 --> Model Class Initialized
DEBUG - 2011-09-26 10:34:47 --> Model Class Initialized
DEBUG - 2011-09-26 10:34:47 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-26 10:34:47 --> Database Driver Class Initialized
DEBUG - 2011-09-26 10:34:47 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-26 10:34:47 --> Helper loaded: url_helper
DEBUG - 2011-09-26 10:34:47 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-26 10:34:47 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-26 10:34:47 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-26 10:34:47 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-26 10:34:47 --> Final output sent to browser
DEBUG - 2011-09-26 10:34:47 --> Total execution time: 0.0418
DEBUG - 2011-09-26 10:34:48 --> Config Class Initialized
DEBUG - 2011-09-26 10:34:48 --> Hooks Class Initialized
DEBUG - 2011-09-26 10:34:48 --> Utf8 Class Initialized
DEBUG - 2011-09-26 10:34:48 --> UTF-8 Support Enabled
DEBUG - 2011-09-26 10:34:48 --> URI Class Initialized
DEBUG - 2011-09-26 10:34:48 --> Router Class Initialized
DEBUG - 2011-09-26 10:34:48 --> Output Class Initialized
DEBUG - 2011-09-26 10:34:48 --> Input Class Initialized
DEBUG - 2011-09-26 10:34:48 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-26 10:34:48 --> Language Class Initialized
DEBUG - 2011-09-26 10:34:48 --> Loader Class Initialized
DEBUG - 2011-09-26 10:34:48 --> Controller Class Initialized
DEBUG - 2011-09-26 10:34:48 --> Model Class Initialized
DEBUG - 2011-09-26 10:34:48 --> Model Class Initialized
DEBUG - 2011-09-26 10:34:48 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-26 10:34:48 --> Database Driver Class Initialized
DEBUG - 2011-09-26 10:34:49 --> Final output sent to browser
DEBUG - 2011-09-26 10:34:49 --> Total execution time: 0.5756
DEBUG - 2011-09-26 10:34:52 --> Config Class Initialized
DEBUG - 2011-09-26 10:34:52 --> Hooks Class Initialized
DEBUG - 2011-09-26 10:34:52 --> Utf8 Class Initialized
DEBUG - 2011-09-26 10:34:52 --> UTF-8 Support Enabled
DEBUG - 2011-09-26 10:34:52 --> URI Class Initialized
DEBUG - 2011-09-26 10:34:52 --> Router Class Initialized
ERROR - 2011-09-26 10:34:52 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-26 10:34:55 --> Config Class Initialized
DEBUG - 2011-09-26 10:34:55 --> Hooks Class Initialized
DEBUG - 2011-09-26 10:34:55 --> Utf8 Class Initialized
DEBUG - 2011-09-26 10:34:55 --> UTF-8 Support Enabled
DEBUG - 2011-09-26 10:34:55 --> URI Class Initialized
DEBUG - 2011-09-26 10:34:55 --> Router Class Initialized
DEBUG - 2011-09-26 10:34:55 --> Output Class Initialized
DEBUG - 2011-09-26 10:34:55 --> Input Class Initialized
DEBUG - 2011-09-26 10:34:55 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-26 10:34:55 --> Language Class Initialized
DEBUG - 2011-09-26 10:34:55 --> Loader Class Initialized
DEBUG - 2011-09-26 10:34:55 --> Controller Class Initialized
ERROR - 2011-09-26 10:34:55 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-26 10:34:55 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-26 10:34:55 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-26 10:34:55 --> Model Class Initialized
DEBUG - 2011-09-26 10:34:55 --> Model Class Initialized
DEBUG - 2011-09-26 10:34:55 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-26 10:34:55 --> Database Driver Class Initialized
DEBUG - 2011-09-26 10:34:55 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-26 10:34:55 --> Helper loaded: url_helper
DEBUG - 2011-09-26 10:34:55 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-26 10:34:55 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-26 10:34:55 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-26 10:34:55 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-26 10:34:55 --> Final output sent to browser
DEBUG - 2011-09-26 10:34:55 --> Total execution time: 0.0388
DEBUG - 2011-09-26 10:34:57 --> Config Class Initialized
DEBUG - 2011-09-26 10:34:57 --> Hooks Class Initialized
DEBUG - 2011-09-26 10:34:57 --> Utf8 Class Initialized
DEBUG - 2011-09-26 10:34:57 --> UTF-8 Support Enabled
DEBUG - 2011-09-26 10:34:57 --> URI Class Initialized
DEBUG - 2011-09-26 10:34:57 --> Router Class Initialized
DEBUG - 2011-09-26 10:34:57 --> Output Class Initialized
DEBUG - 2011-09-26 10:34:57 --> Input Class Initialized
DEBUG - 2011-09-26 10:34:57 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-26 10:34:57 --> Language Class Initialized
DEBUG - 2011-09-26 10:34:57 --> Loader Class Initialized
DEBUG - 2011-09-26 10:34:57 --> Controller Class Initialized
DEBUG - 2011-09-26 10:34:57 --> Model Class Initialized
DEBUG - 2011-09-26 10:34:57 --> Model Class Initialized
DEBUG - 2011-09-26 10:34:57 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-26 10:34:57 --> Database Driver Class Initialized
DEBUG - 2011-09-26 10:34:58 --> Final output sent to browser
DEBUG - 2011-09-26 10:34:58 --> Total execution time: 0.8741
DEBUG - 2011-09-26 10:35:00 --> Config Class Initialized
DEBUG - 2011-09-26 10:35:00 --> Hooks Class Initialized
DEBUG - 2011-09-26 10:35:00 --> Utf8 Class Initialized
DEBUG - 2011-09-26 10:35:00 --> UTF-8 Support Enabled
DEBUG - 2011-09-26 10:35:00 --> URI Class Initialized
DEBUG - 2011-09-26 10:35:00 --> Router Class Initialized
ERROR - 2011-09-26 10:35:00 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-26 10:35:08 --> Config Class Initialized
DEBUG - 2011-09-26 10:35:08 --> Hooks Class Initialized
DEBUG - 2011-09-26 10:35:08 --> Utf8 Class Initialized
DEBUG - 2011-09-26 10:35:08 --> UTF-8 Support Enabled
DEBUG - 2011-09-26 10:35:08 --> URI Class Initialized
DEBUG - 2011-09-26 10:35:08 --> Router Class Initialized
DEBUG - 2011-09-26 10:35:08 --> Output Class Initialized
DEBUG - 2011-09-26 10:35:08 --> Input Class Initialized
DEBUG - 2011-09-26 10:35:08 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-26 10:35:08 --> Language Class Initialized
DEBUG - 2011-09-26 10:35:08 --> Loader Class Initialized
DEBUG - 2011-09-26 10:35:08 --> Controller Class Initialized
ERROR - 2011-09-26 10:35:08 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-26 10:35:08 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-26 10:35:08 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-26 10:35:08 --> Model Class Initialized
DEBUG - 2011-09-26 10:35:08 --> Model Class Initialized
DEBUG - 2011-09-26 10:35:08 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-26 10:35:08 --> Database Driver Class Initialized
DEBUG - 2011-09-26 10:35:08 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-26 10:35:08 --> Helper loaded: url_helper
DEBUG - 2011-09-26 10:35:08 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-26 10:35:08 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-26 10:35:08 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-26 10:35:08 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-26 10:35:08 --> Final output sent to browser
DEBUG - 2011-09-26 10:35:08 --> Total execution time: 0.0331
DEBUG - 2011-09-26 10:35:09 --> Config Class Initialized
DEBUG - 2011-09-26 10:35:09 --> Hooks Class Initialized
DEBUG - 2011-09-26 10:35:09 --> Utf8 Class Initialized
DEBUG - 2011-09-26 10:35:09 --> UTF-8 Support Enabled
DEBUG - 2011-09-26 10:35:09 --> URI Class Initialized
DEBUG - 2011-09-26 10:35:09 --> Router Class Initialized
DEBUG - 2011-09-26 10:35:09 --> Output Class Initialized
DEBUG - 2011-09-26 10:35:09 --> Input Class Initialized
DEBUG - 2011-09-26 10:35:09 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-26 10:35:09 --> Language Class Initialized
DEBUG - 2011-09-26 10:35:09 --> Loader Class Initialized
DEBUG - 2011-09-26 10:35:09 --> Controller Class Initialized
DEBUG - 2011-09-26 10:35:09 --> Model Class Initialized
DEBUG - 2011-09-26 10:35:09 --> Model Class Initialized
DEBUG - 2011-09-26 10:35:09 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-26 10:35:09 --> Database Driver Class Initialized
DEBUG - 2011-09-26 10:35:10 --> Final output sent to browser
DEBUG - 2011-09-26 10:35:10 --> Total execution time: 0.6039
DEBUG - 2011-09-26 10:35:12 --> Config Class Initialized
DEBUG - 2011-09-26 10:35:12 --> Hooks Class Initialized
DEBUG - 2011-09-26 10:35:12 --> Utf8 Class Initialized
DEBUG - 2011-09-26 10:35:12 --> UTF-8 Support Enabled
DEBUG - 2011-09-26 10:35:12 --> URI Class Initialized
DEBUG - 2011-09-26 10:35:12 --> Router Class Initialized
ERROR - 2011-09-26 10:35:12 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-26 10:35:15 --> Config Class Initialized
DEBUG - 2011-09-26 10:35:15 --> Hooks Class Initialized
DEBUG - 2011-09-26 10:35:15 --> Utf8 Class Initialized
DEBUG - 2011-09-26 10:35:15 --> UTF-8 Support Enabled
DEBUG - 2011-09-26 10:35:15 --> URI Class Initialized
DEBUG - 2011-09-26 10:35:15 --> Router Class Initialized
DEBUG - 2011-09-26 10:35:15 --> Output Class Initialized
DEBUG - 2011-09-26 10:35:15 --> Input Class Initialized
DEBUG - 2011-09-26 10:35:15 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-26 10:35:15 --> Language Class Initialized
DEBUG - 2011-09-26 10:35:15 --> Loader Class Initialized
DEBUG - 2011-09-26 10:35:15 --> Controller Class Initialized
ERROR - 2011-09-26 10:35:15 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-26 10:35:15 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-26 10:35:15 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-26 10:35:15 --> Model Class Initialized
DEBUG - 2011-09-26 10:35:15 --> Model Class Initialized
DEBUG - 2011-09-26 10:35:15 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-26 10:35:15 --> Database Driver Class Initialized
DEBUG - 2011-09-26 10:35:15 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-26 10:35:15 --> Helper loaded: url_helper
DEBUG - 2011-09-26 10:35:15 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-26 10:35:15 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-26 10:35:15 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-26 10:35:15 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-26 10:35:15 --> Final output sent to browser
DEBUG - 2011-09-26 10:35:15 --> Total execution time: 0.0331
DEBUG - 2011-09-26 10:35:17 --> Config Class Initialized
DEBUG - 2011-09-26 10:35:17 --> Hooks Class Initialized
DEBUG - 2011-09-26 10:35:17 --> Utf8 Class Initialized
DEBUG - 2011-09-26 10:35:17 --> UTF-8 Support Enabled
DEBUG - 2011-09-26 10:35:17 --> URI Class Initialized
DEBUG - 2011-09-26 10:35:17 --> Router Class Initialized
DEBUG - 2011-09-26 10:35:17 --> Output Class Initialized
DEBUG - 2011-09-26 10:35:17 --> Input Class Initialized
DEBUG - 2011-09-26 10:35:17 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-26 10:35:17 --> Language Class Initialized
DEBUG - 2011-09-26 10:35:17 --> Loader Class Initialized
DEBUG - 2011-09-26 10:35:17 --> Controller Class Initialized
DEBUG - 2011-09-26 10:35:17 --> Model Class Initialized
DEBUG - 2011-09-26 10:35:17 --> Model Class Initialized
DEBUG - 2011-09-26 10:35:17 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-26 10:35:17 --> Database Driver Class Initialized
DEBUG - 2011-09-26 10:35:18 --> Final output sent to browser
DEBUG - 2011-09-26 10:35:18 --> Total execution time: 1.0659
DEBUG - 2011-09-26 10:35:20 --> Config Class Initialized
DEBUG - 2011-09-26 10:35:20 --> Hooks Class Initialized
DEBUG - 2011-09-26 10:35:20 --> Utf8 Class Initialized
DEBUG - 2011-09-26 10:35:20 --> UTF-8 Support Enabled
DEBUG - 2011-09-26 10:35:20 --> URI Class Initialized
DEBUG - 2011-09-26 10:35:20 --> Router Class Initialized
ERROR - 2011-09-26 10:35:20 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-26 10:35:26 --> Config Class Initialized
DEBUG - 2011-09-26 10:35:26 --> Hooks Class Initialized
DEBUG - 2011-09-26 10:35:26 --> Utf8 Class Initialized
DEBUG - 2011-09-26 10:35:26 --> UTF-8 Support Enabled
DEBUG - 2011-09-26 10:35:26 --> URI Class Initialized
DEBUG - 2011-09-26 10:35:26 --> Router Class Initialized
DEBUG - 2011-09-26 10:35:26 --> Output Class Initialized
DEBUG - 2011-09-26 10:35:26 --> Input Class Initialized
DEBUG - 2011-09-26 10:35:26 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-26 10:35:26 --> Language Class Initialized
DEBUG - 2011-09-26 10:35:26 --> Loader Class Initialized
DEBUG - 2011-09-26 10:35:26 --> Controller Class Initialized
ERROR - 2011-09-26 10:35:26 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-26 10:35:26 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-26 10:35:26 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-26 10:35:26 --> Model Class Initialized
DEBUG - 2011-09-26 10:35:26 --> Model Class Initialized
DEBUG - 2011-09-26 10:35:26 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-26 10:35:26 --> Database Driver Class Initialized
DEBUG - 2011-09-26 10:35:26 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-26 10:35:26 --> Helper loaded: url_helper
DEBUG - 2011-09-26 10:35:26 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-26 10:35:26 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-26 10:35:26 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-26 10:35:26 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-26 10:35:26 --> Final output sent to browser
DEBUG - 2011-09-26 10:35:26 --> Total execution time: 0.0727
DEBUG - 2011-09-26 10:35:28 --> Config Class Initialized
DEBUG - 2011-09-26 10:35:28 --> Hooks Class Initialized
DEBUG - 2011-09-26 10:35:28 --> Utf8 Class Initialized
DEBUG - 2011-09-26 10:35:28 --> UTF-8 Support Enabled
DEBUG - 2011-09-26 10:35:28 --> URI Class Initialized
DEBUG - 2011-09-26 10:35:28 --> Router Class Initialized
DEBUG - 2011-09-26 10:35:28 --> Output Class Initialized
DEBUG - 2011-09-26 10:35:28 --> Input Class Initialized
DEBUG - 2011-09-26 10:35:28 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-26 10:35:28 --> Language Class Initialized
DEBUG - 2011-09-26 10:35:28 --> Loader Class Initialized
DEBUG - 2011-09-26 10:35:28 --> Controller Class Initialized
DEBUG - 2011-09-26 10:35:28 --> Model Class Initialized
DEBUG - 2011-09-26 10:35:28 --> Model Class Initialized
DEBUG - 2011-09-26 10:35:28 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-26 10:35:28 --> Database Driver Class Initialized
DEBUG - 2011-09-26 10:35:29 --> Final output sent to browser
DEBUG - 2011-09-26 10:35:29 --> Total execution time: 0.6909
DEBUG - 2011-09-26 10:35:31 --> Config Class Initialized
DEBUG - 2011-09-26 10:35:31 --> Hooks Class Initialized
DEBUG - 2011-09-26 10:35:31 --> Utf8 Class Initialized
DEBUG - 2011-09-26 10:35:31 --> UTF-8 Support Enabled
DEBUG - 2011-09-26 10:35:31 --> URI Class Initialized
DEBUG - 2011-09-26 10:35:31 --> Router Class Initialized
ERROR - 2011-09-26 10:35:31 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-26 10:35:36 --> Config Class Initialized
DEBUG - 2011-09-26 10:35:36 --> Hooks Class Initialized
DEBUG - 2011-09-26 10:35:36 --> Utf8 Class Initialized
DEBUG - 2011-09-26 10:35:36 --> UTF-8 Support Enabled
DEBUG - 2011-09-26 10:35:36 --> URI Class Initialized
DEBUG - 2011-09-26 10:35:36 --> Router Class Initialized
DEBUG - 2011-09-26 10:35:36 --> Output Class Initialized
DEBUG - 2011-09-26 10:35:36 --> Input Class Initialized
DEBUG - 2011-09-26 10:35:36 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-26 10:35:36 --> Language Class Initialized
DEBUG - 2011-09-26 10:35:36 --> Loader Class Initialized
DEBUG - 2011-09-26 10:35:36 --> Controller Class Initialized
ERROR - 2011-09-26 10:35:36 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-26 10:35:36 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-26 10:35:36 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-26 10:35:36 --> Model Class Initialized
DEBUG - 2011-09-26 10:35:36 --> Model Class Initialized
DEBUG - 2011-09-26 10:35:36 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-26 10:35:36 --> Database Driver Class Initialized
DEBUG - 2011-09-26 10:35:36 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-26 10:35:36 --> Helper loaded: url_helper
DEBUG - 2011-09-26 10:35:36 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-26 10:35:36 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-26 10:35:36 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-26 10:35:36 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-26 10:35:36 --> Final output sent to browser
DEBUG - 2011-09-26 10:35:36 --> Total execution time: 0.0369
DEBUG - 2011-09-26 10:35:37 --> Config Class Initialized
DEBUG - 2011-09-26 10:35:37 --> Hooks Class Initialized
DEBUG - 2011-09-26 10:35:37 --> Utf8 Class Initialized
DEBUG - 2011-09-26 10:35:37 --> UTF-8 Support Enabled
DEBUG - 2011-09-26 10:35:37 --> URI Class Initialized
DEBUG - 2011-09-26 10:35:37 --> Router Class Initialized
DEBUG - 2011-09-26 10:35:37 --> Output Class Initialized
DEBUG - 2011-09-26 10:35:37 --> Input Class Initialized
DEBUG - 2011-09-26 10:35:37 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-26 10:35:37 --> Language Class Initialized
DEBUG - 2011-09-26 10:35:37 --> Loader Class Initialized
DEBUG - 2011-09-26 10:35:37 --> Controller Class Initialized
DEBUG - 2011-09-26 10:35:37 --> Model Class Initialized
DEBUG - 2011-09-26 10:35:37 --> Model Class Initialized
DEBUG - 2011-09-26 10:35:37 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-26 10:35:37 --> Database Driver Class Initialized
DEBUG - 2011-09-26 10:35:38 --> Final output sent to browser
DEBUG - 2011-09-26 10:35:38 --> Total execution time: 1.2953
DEBUG - 2011-09-26 10:35:40 --> Config Class Initialized
DEBUG - 2011-09-26 10:35:40 --> Hooks Class Initialized
DEBUG - 2011-09-26 10:35:40 --> Utf8 Class Initialized
DEBUG - 2011-09-26 10:35:40 --> UTF-8 Support Enabled
DEBUG - 2011-09-26 10:35:40 --> URI Class Initialized
DEBUG - 2011-09-26 10:35:40 --> Router Class Initialized
ERROR - 2011-09-26 10:35:40 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-26 10:35:42 --> Config Class Initialized
DEBUG - 2011-09-26 10:35:42 --> Hooks Class Initialized
DEBUG - 2011-09-26 10:35:42 --> Utf8 Class Initialized
DEBUG - 2011-09-26 10:35:42 --> UTF-8 Support Enabled
DEBUG - 2011-09-26 10:35:42 --> URI Class Initialized
DEBUG - 2011-09-26 10:35:42 --> Router Class Initialized
DEBUG - 2011-09-26 10:35:42 --> Output Class Initialized
DEBUG - 2011-09-26 10:35:42 --> Input Class Initialized
DEBUG - 2011-09-26 10:35:42 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-26 10:35:42 --> Language Class Initialized
DEBUG - 2011-09-26 10:35:42 --> Loader Class Initialized
DEBUG - 2011-09-26 10:35:42 --> Controller Class Initialized
ERROR - 2011-09-26 10:35:42 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-26 10:35:42 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-26 10:35:42 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-26 10:35:42 --> Model Class Initialized
DEBUG - 2011-09-26 10:35:42 --> Model Class Initialized
DEBUG - 2011-09-26 10:35:42 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-26 10:35:42 --> Database Driver Class Initialized
DEBUG - 2011-09-26 10:35:42 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-26 10:35:42 --> Helper loaded: url_helper
DEBUG - 2011-09-26 10:35:42 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-26 10:35:42 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-26 10:35:42 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-26 10:35:42 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-26 10:35:42 --> Final output sent to browser
DEBUG - 2011-09-26 10:35:42 --> Total execution time: 0.0853
DEBUG - 2011-09-26 10:35:43 --> Config Class Initialized
DEBUG - 2011-09-26 10:35:43 --> Hooks Class Initialized
DEBUG - 2011-09-26 10:35:43 --> Utf8 Class Initialized
DEBUG - 2011-09-26 10:35:43 --> UTF-8 Support Enabled
DEBUG - 2011-09-26 10:35:43 --> URI Class Initialized
DEBUG - 2011-09-26 10:35:43 --> Router Class Initialized
DEBUG - 2011-09-26 10:35:43 --> Output Class Initialized
DEBUG - 2011-09-26 10:35:43 --> Input Class Initialized
DEBUG - 2011-09-26 10:35:43 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-26 10:35:43 --> Language Class Initialized
DEBUG - 2011-09-26 10:35:43 --> Loader Class Initialized
DEBUG - 2011-09-26 10:35:43 --> Controller Class Initialized
DEBUG - 2011-09-26 10:35:43 --> Model Class Initialized
DEBUG - 2011-09-26 10:35:43 --> Model Class Initialized
DEBUG - 2011-09-26 10:35:43 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-26 10:35:43 --> Database Driver Class Initialized
DEBUG - 2011-09-26 10:35:43 --> Final output sent to browser
DEBUG - 2011-09-26 10:35:43 --> Total execution time: 0.5652
DEBUG - 2011-09-26 10:35:46 --> Config Class Initialized
DEBUG - 2011-09-26 10:35:46 --> Hooks Class Initialized
DEBUG - 2011-09-26 10:35:46 --> Utf8 Class Initialized
DEBUG - 2011-09-26 10:35:46 --> UTF-8 Support Enabled
DEBUG - 2011-09-26 10:35:46 --> URI Class Initialized
DEBUG - 2011-09-26 10:35:46 --> Router Class Initialized
ERROR - 2011-09-26 10:35:46 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-26 10:43:12 --> Config Class Initialized
DEBUG - 2011-09-26 10:43:12 --> Hooks Class Initialized
DEBUG - 2011-09-26 10:43:12 --> Utf8 Class Initialized
DEBUG - 2011-09-26 10:43:12 --> UTF-8 Support Enabled
DEBUG - 2011-09-26 10:43:12 --> URI Class Initialized
DEBUG - 2011-09-26 10:43:12 --> Router Class Initialized
DEBUG - 2011-09-26 10:43:12 --> No URI present. Default controller set.
DEBUG - 2011-09-26 10:43:12 --> Output Class Initialized
DEBUG - 2011-09-26 10:43:12 --> Input Class Initialized
DEBUG - 2011-09-26 10:43:12 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-26 10:43:12 --> Language Class Initialized
DEBUG - 2011-09-26 10:43:12 --> Loader Class Initialized
DEBUG - 2011-09-26 10:43:12 --> Controller Class Initialized
DEBUG - 2011-09-26 10:43:12 --> File loaded: application/views/splash/main.php
DEBUG - 2011-09-26 10:43:12 --> Helper loaded: url_helper
DEBUG - 2011-09-26 10:43:12 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-26 10:43:12 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-26 10:43:12 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-26 10:43:12 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-26 10:43:12 --> Final output sent to browser
DEBUG - 2011-09-26 10:43:12 --> Total execution time: 0.2045
DEBUG - 2011-09-26 10:57:41 --> Config Class Initialized
DEBUG - 2011-09-26 10:57:41 --> Hooks Class Initialized
DEBUG - 2011-09-26 10:57:41 --> Utf8 Class Initialized
DEBUG - 2011-09-26 10:57:41 --> UTF-8 Support Enabled
DEBUG - 2011-09-26 10:57:41 --> URI Class Initialized
DEBUG - 2011-09-26 10:57:41 --> Router Class Initialized
ERROR - 2011-09-26 10:57:41 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-09-26 10:57:42 --> Config Class Initialized
DEBUG - 2011-09-26 10:57:42 --> Hooks Class Initialized
DEBUG - 2011-09-26 10:57:42 --> Utf8 Class Initialized
DEBUG - 2011-09-26 10:57:42 --> UTF-8 Support Enabled
DEBUG - 2011-09-26 10:57:42 --> URI Class Initialized
DEBUG - 2011-09-26 10:57:42 --> Router Class Initialized
DEBUG - 2011-09-26 10:57:42 --> Output Class Initialized
DEBUG - 2011-09-26 10:57:42 --> Input Class Initialized
DEBUG - 2011-09-26 10:57:42 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-26 10:57:42 --> Language Class Initialized
DEBUG - 2011-09-26 10:57:42 --> Loader Class Initialized
DEBUG - 2011-09-26 10:57:42 --> Controller Class Initialized
ERROR - 2011-09-26 10:57:42 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-26 10:57:42 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-26 10:57:42 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-26 10:57:42 --> Model Class Initialized
DEBUG - 2011-09-26 10:57:42 --> Model Class Initialized
DEBUG - 2011-09-26 10:57:42 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-26 10:57:42 --> Database Driver Class Initialized
DEBUG - 2011-09-26 10:57:42 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-26 10:57:42 --> Helper loaded: url_helper
DEBUG - 2011-09-26 10:57:42 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-26 10:57:42 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-26 10:57:42 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-26 10:57:42 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-26 10:57:42 --> Final output sent to browser
DEBUG - 2011-09-26 10:57:42 --> Total execution time: 0.3452
DEBUG - 2011-09-26 11:23:26 --> Config Class Initialized
DEBUG - 2011-09-26 11:23:26 --> Hooks Class Initialized
DEBUG - 2011-09-26 11:23:26 --> Utf8 Class Initialized
DEBUG - 2011-09-26 11:23:26 --> UTF-8 Support Enabled
DEBUG - 2011-09-26 11:23:26 --> URI Class Initialized
DEBUG - 2011-09-26 11:23:26 --> Router Class Initialized
DEBUG - 2011-09-26 11:23:26 --> Output Class Initialized
DEBUG - 2011-09-26 11:23:26 --> Input Class Initialized
DEBUG - 2011-09-26 11:23:26 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-26 11:23:26 --> Language Class Initialized
DEBUG - 2011-09-26 11:23:26 --> Loader Class Initialized
DEBUG - 2011-09-26 11:23:26 --> Controller Class Initialized
DEBUG - 2011-09-26 11:23:26 --> Model Class Initialized
DEBUG - 2011-09-26 11:23:26 --> Model Class Initialized
DEBUG - 2011-09-26 11:23:26 --> Model Class Initialized
DEBUG - 2011-09-26 11:23:26 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-26 11:23:26 --> Database Driver Class Initialized
DEBUG - 2011-09-26 11:23:27 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-26 11:23:27 --> Helper loaded: url_helper
DEBUG - 2011-09-26 11:23:27 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-26 11:23:27 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-26 11:23:27 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-26 11:23:27 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-26 11:23:27 --> Final output sent to browser
DEBUG - 2011-09-26 11:23:27 --> Total execution time: 1.2603
DEBUG - 2011-09-26 11:23:29 --> Config Class Initialized
DEBUG - 2011-09-26 11:23:29 --> Hooks Class Initialized
DEBUG - 2011-09-26 11:23:29 --> Utf8 Class Initialized
DEBUG - 2011-09-26 11:23:29 --> UTF-8 Support Enabled
DEBUG - 2011-09-26 11:23:29 --> URI Class Initialized
DEBUG - 2011-09-26 11:23:29 --> Router Class Initialized
ERROR - 2011-09-26 11:23:29 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-26 11:23:30 --> Config Class Initialized
DEBUG - 2011-09-26 11:23:30 --> Hooks Class Initialized
DEBUG - 2011-09-26 11:23:30 --> Utf8 Class Initialized
DEBUG - 2011-09-26 11:23:30 --> UTF-8 Support Enabled
DEBUG - 2011-09-26 11:23:30 --> URI Class Initialized
DEBUG - 2011-09-26 11:23:30 --> Router Class Initialized
ERROR - 2011-09-26 11:23:30 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-26 11:30:18 --> Config Class Initialized
DEBUG - 2011-09-26 11:30:18 --> Hooks Class Initialized
DEBUG - 2011-09-26 11:30:18 --> Utf8 Class Initialized
DEBUG - 2011-09-26 11:30:18 --> UTF-8 Support Enabled
DEBUG - 2011-09-26 11:30:18 --> URI Class Initialized
DEBUG - 2011-09-26 11:30:18 --> Router Class Initialized
DEBUG - 2011-09-26 11:30:18 --> Output Class Initialized
DEBUG - 2011-09-26 11:30:18 --> Input Class Initialized
DEBUG - 2011-09-26 11:30:18 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-26 11:30:18 --> Language Class Initialized
DEBUG - 2011-09-26 11:30:18 --> Loader Class Initialized
DEBUG - 2011-09-26 11:30:18 --> Controller Class Initialized
DEBUG - 2011-09-26 11:30:18 --> Model Class Initialized
DEBUG - 2011-09-26 11:30:18 --> Model Class Initialized
DEBUG - 2011-09-26 11:30:18 --> Model Class Initialized
DEBUG - 2011-09-26 11:30:18 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-26 11:30:18 --> Database Driver Class Initialized
DEBUG - 2011-09-26 11:30:18 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-26 11:30:18 --> Helper loaded: url_helper
DEBUG - 2011-09-26 11:30:18 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-26 11:30:18 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-26 11:30:18 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-26 11:30:18 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-26 11:30:18 --> Final output sent to browser
DEBUG - 2011-09-26 11:30:18 --> Total execution time: 0.3603
DEBUG - 2011-09-26 11:30:20 --> Config Class Initialized
DEBUG - 2011-09-26 11:30:20 --> Hooks Class Initialized
DEBUG - 2011-09-26 11:30:20 --> Utf8 Class Initialized
DEBUG - 2011-09-26 11:30:20 --> UTF-8 Support Enabled
DEBUG - 2011-09-26 11:30:20 --> URI Class Initialized
DEBUG - 2011-09-26 11:30:20 --> Router Class Initialized
DEBUG - 2011-09-26 11:30:20 --> Output Class Initialized
DEBUG - 2011-09-26 11:30:20 --> Input Class Initialized
DEBUG - 2011-09-26 11:30:20 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-26 11:30:20 --> Language Class Initialized
DEBUG - 2011-09-26 11:30:21 --> Loader Class Initialized
DEBUG - 2011-09-26 11:30:21 --> Controller Class Initialized
ERROR - 2011-09-26 11:30:21 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-26 11:30:21 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-26 11:30:21 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-26 11:30:21 --> Model Class Initialized
DEBUG - 2011-09-26 11:30:21 --> Model Class Initialized
DEBUG - 2011-09-26 11:30:21 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-26 11:30:21 --> Database Driver Class Initialized
DEBUG - 2011-09-26 11:30:21 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-26 11:30:21 --> Helper loaded: url_helper
DEBUG - 2011-09-26 11:30:21 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-26 11:30:21 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-26 11:30:21 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-26 11:30:21 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-26 11:30:21 --> Final output sent to browser
DEBUG - 2011-09-26 11:30:21 --> Total execution time: 0.3176
DEBUG - 2011-09-26 11:40:21 --> Config Class Initialized
DEBUG - 2011-09-26 11:40:21 --> Hooks Class Initialized
DEBUG - 2011-09-26 11:40:21 --> Utf8 Class Initialized
DEBUG - 2011-09-26 11:40:21 --> UTF-8 Support Enabled
DEBUG - 2011-09-26 11:40:21 --> URI Class Initialized
DEBUG - 2011-09-26 11:40:21 --> Router Class Initialized
DEBUG - 2011-09-26 11:40:21 --> Output Class Initialized
DEBUG - 2011-09-26 11:40:21 --> Input Class Initialized
DEBUG - 2011-09-26 11:40:21 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-26 11:40:21 --> Language Class Initialized
DEBUG - 2011-09-26 11:40:21 --> Loader Class Initialized
DEBUG - 2011-09-26 11:40:21 --> Controller Class Initialized
DEBUG - 2011-09-26 11:40:21 --> Model Class Initialized
DEBUG - 2011-09-26 11:40:21 --> Model Class Initialized
DEBUG - 2011-09-26 11:40:21 --> Model Class Initialized
DEBUG - 2011-09-26 11:40:21 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-26 11:40:21 --> Database Driver Class Initialized
DEBUG - 2011-09-26 11:40:21 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-26 11:40:21 --> Helper loaded: url_helper
DEBUG - 2011-09-26 11:40:21 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-26 11:40:21 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-26 11:40:21 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-26 11:40:21 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-26 11:40:21 --> Final output sent to browser
DEBUG - 2011-09-26 11:40:21 --> Total execution time: 0.1592
DEBUG - 2011-09-26 11:40:26 --> Config Class Initialized
DEBUG - 2011-09-26 11:40:26 --> Hooks Class Initialized
DEBUG - 2011-09-26 11:40:26 --> Utf8 Class Initialized
DEBUG - 2011-09-26 11:40:26 --> UTF-8 Support Enabled
DEBUG - 2011-09-26 11:40:26 --> URI Class Initialized
DEBUG - 2011-09-26 11:40:26 --> Router Class Initialized
ERROR - 2011-09-26 11:40:26 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-26 12:01:41 --> Config Class Initialized
DEBUG - 2011-09-26 12:01:41 --> Hooks Class Initialized
DEBUG - 2011-09-26 12:01:41 --> Utf8 Class Initialized
DEBUG - 2011-09-26 12:01:41 --> UTF-8 Support Enabled
DEBUG - 2011-09-26 12:01:41 --> URI Class Initialized
DEBUG - 2011-09-26 12:01:41 --> Router Class Initialized
DEBUG - 2011-09-26 12:01:41 --> Output Class Initialized
DEBUG - 2011-09-26 12:01:41 --> Input Class Initialized
DEBUG - 2011-09-26 12:01:41 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-26 12:01:41 --> Language Class Initialized
DEBUG - 2011-09-26 12:01:41 --> Loader Class Initialized
DEBUG - 2011-09-26 12:01:41 --> Controller Class Initialized
ERROR - 2011-09-26 12:01:41 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-26 12:01:41 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-26 12:01:41 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-26 12:01:41 --> Model Class Initialized
DEBUG - 2011-09-26 12:01:41 --> Model Class Initialized
DEBUG - 2011-09-26 12:01:41 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-26 12:01:41 --> Database Driver Class Initialized
DEBUG - 2011-09-26 12:01:41 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-26 12:01:41 --> Helper loaded: url_helper
DEBUG - 2011-09-26 12:01:41 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-26 12:01:41 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-26 12:01:41 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-26 12:01:41 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-26 12:01:41 --> Final output sent to browser
DEBUG - 2011-09-26 12:01:41 --> Total execution time: 0.5279
DEBUG - 2011-09-26 12:01:44 --> Config Class Initialized
DEBUG - 2011-09-26 12:01:44 --> Hooks Class Initialized
DEBUG - 2011-09-26 12:01:44 --> Utf8 Class Initialized
DEBUG - 2011-09-26 12:01:44 --> UTF-8 Support Enabled
DEBUG - 2011-09-26 12:01:44 --> URI Class Initialized
DEBUG - 2011-09-26 12:01:44 --> Router Class Initialized
DEBUG - 2011-09-26 12:01:44 --> Output Class Initialized
DEBUG - 2011-09-26 12:01:44 --> Input Class Initialized
DEBUG - 2011-09-26 12:01:44 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-26 12:01:44 --> Language Class Initialized
DEBUG - 2011-09-26 12:01:44 --> Loader Class Initialized
DEBUG - 2011-09-26 12:01:44 --> Controller Class Initialized
DEBUG - 2011-09-26 12:01:44 --> Model Class Initialized
DEBUG - 2011-09-26 12:01:44 --> Model Class Initialized
DEBUG - 2011-09-26 12:01:44 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-26 12:01:44 --> Database Driver Class Initialized
DEBUG - 2011-09-26 12:01:44 --> Final output sent to browser
DEBUG - 2011-09-26 12:01:44 --> Total execution time: 0.7692
DEBUG - 2011-09-26 12:01:48 --> Config Class Initialized
DEBUG - 2011-09-26 12:01:48 --> Hooks Class Initialized
DEBUG - 2011-09-26 12:01:48 --> Utf8 Class Initialized
DEBUG - 2011-09-26 12:01:48 --> UTF-8 Support Enabled
DEBUG - 2011-09-26 12:01:48 --> URI Class Initialized
DEBUG - 2011-09-26 12:01:48 --> Router Class Initialized
ERROR - 2011-09-26 12:01:48 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-26 12:01:49 --> Config Class Initialized
DEBUG - 2011-09-26 12:01:49 --> Hooks Class Initialized
DEBUG - 2011-09-26 12:01:49 --> Utf8 Class Initialized
DEBUG - 2011-09-26 12:01:49 --> UTF-8 Support Enabled
DEBUG - 2011-09-26 12:01:49 --> URI Class Initialized
DEBUG - 2011-09-26 12:01:49 --> Router Class Initialized
ERROR - 2011-09-26 12:01:49 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-26 12:01:59 --> Config Class Initialized
DEBUG - 2011-09-26 12:01:59 --> Hooks Class Initialized
DEBUG - 2011-09-26 12:01:59 --> Utf8 Class Initialized
DEBUG - 2011-09-26 12:01:59 --> UTF-8 Support Enabled
DEBUG - 2011-09-26 12:01:59 --> URI Class Initialized
DEBUG - 2011-09-26 12:01:59 --> Router Class Initialized
DEBUG - 2011-09-26 12:01:59 --> Output Class Initialized
DEBUG - 2011-09-26 12:01:59 --> Input Class Initialized
DEBUG - 2011-09-26 12:01:59 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-26 12:01:59 --> Language Class Initialized
DEBUG - 2011-09-26 12:01:59 --> Loader Class Initialized
DEBUG - 2011-09-26 12:01:59 --> Controller Class Initialized
ERROR - 2011-09-26 12:01:59 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-26 12:01:59 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-26 12:01:59 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-26 12:01:59 --> Model Class Initialized
DEBUG - 2011-09-26 12:01:59 --> Model Class Initialized
DEBUG - 2011-09-26 12:01:59 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-26 12:01:59 --> Database Driver Class Initialized
DEBUG - 2011-09-26 12:01:59 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-26 12:01:59 --> Helper loaded: url_helper
DEBUG - 2011-09-26 12:01:59 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-26 12:01:59 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-26 12:01:59 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-26 12:01:59 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-26 12:01:59 --> Final output sent to browser
DEBUG - 2011-09-26 12:01:59 --> Total execution time: 0.0311
DEBUG - 2011-09-26 12:02:00 --> Config Class Initialized
DEBUG - 2011-09-26 12:02:00 --> Hooks Class Initialized
DEBUG - 2011-09-26 12:02:00 --> Utf8 Class Initialized
DEBUG - 2011-09-26 12:02:00 --> UTF-8 Support Enabled
DEBUG - 2011-09-26 12:02:00 --> URI Class Initialized
DEBUG - 2011-09-26 12:02:00 --> Router Class Initialized
DEBUG - 2011-09-26 12:02:00 --> Output Class Initialized
DEBUG - 2011-09-26 12:02:00 --> Input Class Initialized
DEBUG - 2011-09-26 12:02:00 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-26 12:02:00 --> Language Class Initialized
DEBUG - 2011-09-26 12:02:00 --> Loader Class Initialized
DEBUG - 2011-09-26 12:02:00 --> Controller Class Initialized
DEBUG - 2011-09-26 12:02:00 --> Model Class Initialized
DEBUG - 2011-09-26 12:02:00 --> Model Class Initialized
DEBUG - 2011-09-26 12:02:00 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-26 12:02:00 --> Database Driver Class Initialized
DEBUG - 2011-09-26 12:02:01 --> Final output sent to browser
DEBUG - 2011-09-26 12:02:01 --> Total execution time: 0.6672
DEBUG - 2011-09-26 13:18:25 --> Config Class Initialized
DEBUG - 2011-09-26 13:18:25 --> Hooks Class Initialized
DEBUG - 2011-09-26 13:18:25 --> Utf8 Class Initialized
DEBUG - 2011-09-26 13:18:25 --> UTF-8 Support Enabled
DEBUG - 2011-09-26 13:18:25 --> URI Class Initialized
DEBUG - 2011-09-26 13:18:25 --> Router Class Initialized
DEBUG - 2011-09-26 13:18:25 --> Output Class Initialized
DEBUG - 2011-09-26 13:18:25 --> Input Class Initialized
DEBUG - 2011-09-26 13:18:25 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-26 13:18:25 --> Language Class Initialized
DEBUG - 2011-09-26 13:18:25 --> Loader Class Initialized
DEBUG - 2011-09-26 13:18:25 --> Controller Class Initialized
ERROR - 2011-09-26 13:18:25 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-26 13:18:25 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-26 13:18:25 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-26 13:18:25 --> Model Class Initialized
DEBUG - 2011-09-26 13:18:25 --> Model Class Initialized
DEBUG - 2011-09-26 13:18:25 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-26 13:18:25 --> Database Driver Class Initialized
DEBUG - 2011-09-26 13:18:25 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-26 13:18:25 --> Helper loaded: url_helper
DEBUG - 2011-09-26 13:18:25 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-26 13:18:25 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-26 13:18:25 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-26 13:18:25 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-26 13:18:25 --> Final output sent to browser
DEBUG - 2011-09-26 13:18:25 --> Total execution time: 0.3282
DEBUG - 2011-09-26 13:18:27 --> Config Class Initialized
DEBUG - 2011-09-26 13:18:27 --> Hooks Class Initialized
DEBUG - 2011-09-26 13:18:27 --> Utf8 Class Initialized
DEBUG - 2011-09-26 13:18:27 --> UTF-8 Support Enabled
DEBUG - 2011-09-26 13:18:27 --> URI Class Initialized
DEBUG - 2011-09-26 13:18:27 --> Router Class Initialized
DEBUG - 2011-09-26 13:18:27 --> Output Class Initialized
DEBUG - 2011-09-26 13:18:27 --> Input Class Initialized
DEBUG - 2011-09-26 13:18:27 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-26 13:18:27 --> Language Class Initialized
DEBUG - 2011-09-26 13:18:27 --> Loader Class Initialized
DEBUG - 2011-09-26 13:18:27 --> Controller Class Initialized
DEBUG - 2011-09-26 13:18:27 --> Model Class Initialized
DEBUG - 2011-09-26 13:18:27 --> Model Class Initialized
DEBUG - 2011-09-26 13:18:27 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-26 13:18:27 --> Database Driver Class Initialized
DEBUG - 2011-09-26 13:18:27 --> Final output sent to browser
DEBUG - 2011-09-26 13:18:27 --> Total execution time: 0.7819
DEBUG - 2011-09-26 13:18:29 --> Config Class Initialized
DEBUG - 2011-09-26 13:18:29 --> Hooks Class Initialized
DEBUG - 2011-09-26 13:18:29 --> Utf8 Class Initialized
DEBUG - 2011-09-26 13:18:29 --> UTF-8 Support Enabled
DEBUG - 2011-09-26 13:18:29 --> URI Class Initialized
DEBUG - 2011-09-26 13:18:29 --> Router Class Initialized
ERROR - 2011-09-26 13:18:29 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-26 13:18:44 --> Config Class Initialized
DEBUG - 2011-09-26 13:18:44 --> Hooks Class Initialized
DEBUG - 2011-09-26 13:18:44 --> Utf8 Class Initialized
DEBUG - 2011-09-26 13:18:44 --> UTF-8 Support Enabled
DEBUG - 2011-09-26 13:18:44 --> URI Class Initialized
DEBUG - 2011-09-26 13:18:44 --> Router Class Initialized
DEBUG - 2011-09-26 13:18:44 --> Output Class Initialized
DEBUG - 2011-09-26 13:18:44 --> Input Class Initialized
DEBUG - 2011-09-26 13:18:44 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-26 13:18:44 --> Language Class Initialized
DEBUG - 2011-09-26 13:18:44 --> Loader Class Initialized
DEBUG - 2011-09-26 13:18:44 --> Controller Class Initialized
ERROR - 2011-09-26 13:18:44 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-26 13:18:44 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-26 13:18:44 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-26 13:18:44 --> Model Class Initialized
DEBUG - 2011-09-26 13:18:44 --> Model Class Initialized
DEBUG - 2011-09-26 13:18:44 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-26 13:18:44 --> Database Driver Class Initialized
DEBUG - 2011-09-26 13:18:44 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-26 13:18:44 --> Helper loaded: url_helper
DEBUG - 2011-09-26 13:18:44 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-26 13:18:44 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-26 13:18:44 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-26 13:18:44 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-26 13:18:44 --> Final output sent to browser
DEBUG - 2011-09-26 13:18:44 --> Total execution time: 0.0327
DEBUG - 2011-09-26 13:18:45 --> Config Class Initialized
DEBUG - 2011-09-26 13:18:45 --> Hooks Class Initialized
DEBUG - 2011-09-26 13:18:45 --> Utf8 Class Initialized
DEBUG - 2011-09-26 13:18:45 --> UTF-8 Support Enabled
DEBUG - 2011-09-26 13:18:45 --> URI Class Initialized
DEBUG - 2011-09-26 13:18:45 --> Router Class Initialized
DEBUG - 2011-09-26 13:18:45 --> Output Class Initialized
DEBUG - 2011-09-26 13:18:45 --> Input Class Initialized
DEBUG - 2011-09-26 13:18:45 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-26 13:18:45 --> Language Class Initialized
DEBUG - 2011-09-26 13:18:45 --> Loader Class Initialized
DEBUG - 2011-09-26 13:18:45 --> Controller Class Initialized
DEBUG - 2011-09-26 13:18:45 --> Model Class Initialized
DEBUG - 2011-09-26 13:18:45 --> Model Class Initialized
DEBUG - 2011-09-26 13:18:45 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-26 13:18:45 --> Database Driver Class Initialized
DEBUG - 2011-09-26 13:18:46 --> Final output sent to browser
DEBUG - 2011-09-26 13:18:46 --> Total execution time: 0.6790
DEBUG - 2011-09-26 13:18:47 --> Config Class Initialized
DEBUG - 2011-09-26 13:18:47 --> Hooks Class Initialized
DEBUG - 2011-09-26 13:18:47 --> Utf8 Class Initialized
DEBUG - 2011-09-26 13:18:47 --> UTF-8 Support Enabled
DEBUG - 2011-09-26 13:18:47 --> URI Class Initialized
DEBUG - 2011-09-26 13:18:47 --> Router Class Initialized
ERROR - 2011-09-26 13:18:47 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-26 13:19:09 --> Config Class Initialized
DEBUG - 2011-09-26 13:19:09 --> Hooks Class Initialized
DEBUG - 2011-09-26 13:19:09 --> Utf8 Class Initialized
DEBUG - 2011-09-26 13:19:09 --> UTF-8 Support Enabled
DEBUG - 2011-09-26 13:19:09 --> URI Class Initialized
DEBUG - 2011-09-26 13:19:09 --> Router Class Initialized
DEBUG - 2011-09-26 13:19:09 --> Output Class Initialized
DEBUG - 2011-09-26 13:19:09 --> Input Class Initialized
DEBUG - 2011-09-26 13:19:09 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-26 13:19:09 --> Language Class Initialized
DEBUG - 2011-09-26 13:19:09 --> Loader Class Initialized
DEBUG - 2011-09-26 13:19:09 --> Controller Class Initialized
ERROR - 2011-09-26 13:19:09 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-26 13:19:09 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-26 13:19:09 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-26 13:19:09 --> Model Class Initialized
DEBUG - 2011-09-26 13:19:09 --> Model Class Initialized
DEBUG - 2011-09-26 13:19:09 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-26 13:19:09 --> Database Driver Class Initialized
DEBUG - 2011-09-26 13:19:09 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-26 13:19:09 --> Helper loaded: url_helper
DEBUG - 2011-09-26 13:19:09 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-26 13:19:09 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-26 13:19:09 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-26 13:19:09 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-26 13:19:09 --> Final output sent to browser
DEBUG - 2011-09-26 13:19:09 --> Total execution time: 0.0799
DEBUG - 2011-09-26 13:19:10 --> Config Class Initialized
DEBUG - 2011-09-26 13:19:10 --> Hooks Class Initialized
DEBUG - 2011-09-26 13:19:10 --> Utf8 Class Initialized
DEBUG - 2011-09-26 13:19:10 --> UTF-8 Support Enabled
DEBUG - 2011-09-26 13:19:10 --> URI Class Initialized
DEBUG - 2011-09-26 13:19:10 --> Router Class Initialized
DEBUG - 2011-09-26 13:19:10 --> Output Class Initialized
DEBUG - 2011-09-26 13:19:10 --> Input Class Initialized
DEBUG - 2011-09-26 13:19:10 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-26 13:19:10 --> Language Class Initialized
DEBUG - 2011-09-26 13:19:10 --> Loader Class Initialized
DEBUG - 2011-09-26 13:19:10 --> Controller Class Initialized
DEBUG - 2011-09-26 13:19:10 --> Model Class Initialized
DEBUG - 2011-09-26 13:19:10 --> Model Class Initialized
DEBUG - 2011-09-26 13:19:10 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-26 13:19:10 --> Database Driver Class Initialized
DEBUG - 2011-09-26 13:19:11 --> Final output sent to browser
DEBUG - 2011-09-26 13:19:11 --> Total execution time: 0.9709
DEBUG - 2011-09-26 13:19:12 --> Config Class Initialized
DEBUG - 2011-09-26 13:19:12 --> Hooks Class Initialized
DEBUG - 2011-09-26 13:19:12 --> Utf8 Class Initialized
DEBUG - 2011-09-26 13:19:12 --> UTF-8 Support Enabled
DEBUG - 2011-09-26 13:19:12 --> URI Class Initialized
DEBUG - 2011-09-26 13:19:12 --> Router Class Initialized
ERROR - 2011-09-26 13:19:12 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-26 13:19:31 --> Config Class Initialized
DEBUG - 2011-09-26 13:19:31 --> Hooks Class Initialized
DEBUG - 2011-09-26 13:19:31 --> Utf8 Class Initialized
DEBUG - 2011-09-26 13:19:31 --> UTF-8 Support Enabled
DEBUG - 2011-09-26 13:19:31 --> URI Class Initialized
DEBUG - 2011-09-26 13:19:31 --> Router Class Initialized
DEBUG - 2011-09-26 13:19:31 --> Output Class Initialized
DEBUG - 2011-09-26 13:19:31 --> Input Class Initialized
DEBUG - 2011-09-26 13:19:31 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-26 13:19:31 --> Language Class Initialized
DEBUG - 2011-09-26 13:19:31 --> Loader Class Initialized
DEBUG - 2011-09-26 13:19:31 --> Controller Class Initialized
ERROR - 2011-09-26 13:19:31 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-26 13:19:31 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-26 13:19:31 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-26 13:19:31 --> Model Class Initialized
DEBUG - 2011-09-26 13:19:31 --> Model Class Initialized
DEBUG - 2011-09-26 13:19:31 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-26 13:19:31 --> Database Driver Class Initialized
DEBUG - 2011-09-26 13:19:31 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-26 13:19:31 --> Helper loaded: url_helper
DEBUG - 2011-09-26 13:19:31 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-26 13:19:31 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-26 13:19:31 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-26 13:19:31 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-26 13:19:31 --> Final output sent to browser
DEBUG - 2011-09-26 13:19:31 --> Total execution time: 0.0291
DEBUG - 2011-09-26 13:19:31 --> Config Class Initialized
DEBUG - 2011-09-26 13:19:31 --> Hooks Class Initialized
DEBUG - 2011-09-26 13:19:31 --> Utf8 Class Initialized
DEBUG - 2011-09-26 13:19:31 --> UTF-8 Support Enabled
DEBUG - 2011-09-26 13:19:31 --> URI Class Initialized
DEBUG - 2011-09-26 13:19:31 --> Router Class Initialized
DEBUG - 2011-09-26 13:19:31 --> Output Class Initialized
DEBUG - 2011-09-26 13:19:31 --> Input Class Initialized
DEBUG - 2011-09-26 13:19:31 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-26 13:19:31 --> Language Class Initialized
DEBUG - 2011-09-26 13:19:31 --> Loader Class Initialized
DEBUG - 2011-09-26 13:19:31 --> Controller Class Initialized
DEBUG - 2011-09-26 13:19:31 --> Model Class Initialized
DEBUG - 2011-09-26 13:19:31 --> Model Class Initialized
DEBUG - 2011-09-26 13:19:31 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-26 13:19:31 --> Database Driver Class Initialized
DEBUG - 2011-09-26 13:19:32 --> Final output sent to browser
DEBUG - 2011-09-26 13:19:32 --> Total execution time: 0.5845
DEBUG - 2011-09-26 13:19:33 --> Config Class Initialized
DEBUG - 2011-09-26 13:19:33 --> Hooks Class Initialized
DEBUG - 2011-09-26 13:19:33 --> Utf8 Class Initialized
DEBUG - 2011-09-26 13:19:33 --> UTF-8 Support Enabled
DEBUG - 2011-09-26 13:19:33 --> URI Class Initialized
DEBUG - 2011-09-26 13:19:33 --> Router Class Initialized
ERROR - 2011-09-26 13:19:33 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-26 13:19:39 --> Config Class Initialized
DEBUG - 2011-09-26 13:19:39 --> Hooks Class Initialized
DEBUG - 2011-09-26 13:19:39 --> Utf8 Class Initialized
DEBUG - 2011-09-26 13:19:39 --> UTF-8 Support Enabled
DEBUG - 2011-09-26 13:19:39 --> URI Class Initialized
DEBUG - 2011-09-26 13:19:39 --> Router Class Initialized
DEBUG - 2011-09-26 13:19:39 --> Output Class Initialized
DEBUG - 2011-09-26 13:19:39 --> Input Class Initialized
DEBUG - 2011-09-26 13:19:39 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-26 13:19:39 --> Language Class Initialized
DEBUG - 2011-09-26 13:19:39 --> Loader Class Initialized
DEBUG - 2011-09-26 13:19:39 --> Controller Class Initialized
ERROR - 2011-09-26 13:19:39 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-26 13:19:39 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-26 13:19:39 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-26 13:19:39 --> Model Class Initialized
DEBUG - 2011-09-26 13:19:39 --> Model Class Initialized
DEBUG - 2011-09-26 13:19:39 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-26 13:19:39 --> Database Driver Class Initialized
DEBUG - 2011-09-26 13:19:39 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-26 13:19:39 --> Helper loaded: url_helper
DEBUG - 2011-09-26 13:19:39 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-26 13:19:39 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-26 13:19:39 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-26 13:19:39 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-26 13:19:39 --> Final output sent to browser
DEBUG - 2011-09-26 13:19:39 --> Total execution time: 0.0534
DEBUG - 2011-09-26 13:19:40 --> Config Class Initialized
DEBUG - 2011-09-26 13:19:40 --> Hooks Class Initialized
DEBUG - 2011-09-26 13:19:40 --> Utf8 Class Initialized
DEBUG - 2011-09-26 13:19:40 --> UTF-8 Support Enabled
DEBUG - 2011-09-26 13:19:40 --> URI Class Initialized
DEBUG - 2011-09-26 13:19:40 --> Router Class Initialized
DEBUG - 2011-09-26 13:19:40 --> Output Class Initialized
DEBUG - 2011-09-26 13:19:40 --> Input Class Initialized
DEBUG - 2011-09-26 13:19:40 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-26 13:19:40 --> Language Class Initialized
DEBUG - 2011-09-26 13:19:40 --> Loader Class Initialized
DEBUG - 2011-09-26 13:19:40 --> Controller Class Initialized
DEBUG - 2011-09-26 13:19:40 --> Model Class Initialized
DEBUG - 2011-09-26 13:19:40 --> Model Class Initialized
DEBUG - 2011-09-26 13:19:40 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-26 13:19:40 --> Database Driver Class Initialized
DEBUG - 2011-09-26 13:19:41 --> Final output sent to browser
DEBUG - 2011-09-26 13:19:41 --> Total execution time: 0.7064
DEBUG - 2011-09-26 13:19:42 --> Config Class Initialized
DEBUG - 2011-09-26 13:19:42 --> Hooks Class Initialized
DEBUG - 2011-09-26 13:19:42 --> Utf8 Class Initialized
DEBUG - 2011-09-26 13:19:42 --> UTF-8 Support Enabled
DEBUG - 2011-09-26 13:19:42 --> URI Class Initialized
DEBUG - 2011-09-26 13:19:42 --> Router Class Initialized
ERROR - 2011-09-26 13:19:42 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-26 13:19:48 --> Config Class Initialized
DEBUG - 2011-09-26 13:19:48 --> Hooks Class Initialized
DEBUG - 2011-09-26 13:19:48 --> Utf8 Class Initialized
DEBUG - 2011-09-26 13:19:48 --> UTF-8 Support Enabled
DEBUG - 2011-09-26 13:19:48 --> URI Class Initialized
DEBUG - 2011-09-26 13:19:48 --> Router Class Initialized
DEBUG - 2011-09-26 13:19:48 --> Output Class Initialized
DEBUG - 2011-09-26 13:19:48 --> Input Class Initialized
DEBUG - 2011-09-26 13:19:48 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-26 13:19:48 --> Language Class Initialized
DEBUG - 2011-09-26 13:19:48 --> Loader Class Initialized
DEBUG - 2011-09-26 13:19:48 --> Controller Class Initialized
ERROR - 2011-09-26 13:19:48 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-26 13:19:48 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-26 13:19:48 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-26 13:19:48 --> Model Class Initialized
DEBUG - 2011-09-26 13:19:48 --> Model Class Initialized
DEBUG - 2011-09-26 13:19:48 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-26 13:19:48 --> Database Driver Class Initialized
DEBUG - 2011-09-26 13:19:48 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-26 13:19:48 --> Helper loaded: url_helper
DEBUG - 2011-09-26 13:19:48 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-26 13:19:48 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-26 13:19:48 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-26 13:19:48 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-26 13:19:48 --> Final output sent to browser
DEBUG - 2011-09-26 13:19:48 --> Total execution time: 0.0819
DEBUG - 2011-09-26 13:19:49 --> Config Class Initialized
DEBUG - 2011-09-26 13:19:49 --> Hooks Class Initialized
DEBUG - 2011-09-26 13:19:49 --> Utf8 Class Initialized
DEBUG - 2011-09-26 13:19:49 --> UTF-8 Support Enabled
DEBUG - 2011-09-26 13:19:49 --> URI Class Initialized
DEBUG - 2011-09-26 13:19:49 --> Router Class Initialized
DEBUG - 2011-09-26 13:19:49 --> Output Class Initialized
DEBUG - 2011-09-26 13:19:49 --> Input Class Initialized
DEBUG - 2011-09-26 13:19:49 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-26 13:19:49 --> Language Class Initialized
DEBUG - 2011-09-26 13:19:49 --> Loader Class Initialized
DEBUG - 2011-09-26 13:19:49 --> Controller Class Initialized
DEBUG - 2011-09-26 13:19:49 --> Model Class Initialized
DEBUG - 2011-09-26 13:19:49 --> Model Class Initialized
DEBUG - 2011-09-26 13:19:49 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-26 13:19:49 --> Database Driver Class Initialized
DEBUG - 2011-09-26 13:19:50 --> Final output sent to browser
DEBUG - 2011-09-26 13:19:50 --> Total execution time: 0.7050
DEBUG - 2011-09-26 13:19:50 --> Config Class Initialized
DEBUG - 2011-09-26 13:19:50 --> Hooks Class Initialized
DEBUG - 2011-09-26 13:19:50 --> Utf8 Class Initialized
DEBUG - 2011-09-26 13:19:50 --> UTF-8 Support Enabled
DEBUG - 2011-09-26 13:19:50 --> URI Class Initialized
DEBUG - 2011-09-26 13:19:50 --> Router Class Initialized
ERROR - 2011-09-26 13:19:50 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-26 13:19:59 --> Config Class Initialized
DEBUG - 2011-09-26 13:19:59 --> Hooks Class Initialized
DEBUG - 2011-09-26 13:19:59 --> Utf8 Class Initialized
DEBUG - 2011-09-26 13:19:59 --> UTF-8 Support Enabled
DEBUG - 2011-09-26 13:19:59 --> URI Class Initialized
DEBUG - 2011-09-26 13:19:59 --> Router Class Initialized
DEBUG - 2011-09-26 13:19:59 --> Output Class Initialized
DEBUG - 2011-09-26 13:19:59 --> Input Class Initialized
DEBUG - 2011-09-26 13:19:59 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-26 13:19:59 --> Language Class Initialized
DEBUG - 2011-09-26 13:19:59 --> Loader Class Initialized
DEBUG - 2011-09-26 13:19:59 --> Controller Class Initialized
ERROR - 2011-09-26 13:19:59 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-26 13:19:59 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-26 13:19:59 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-26 13:19:59 --> Model Class Initialized
DEBUG - 2011-09-26 13:19:59 --> Model Class Initialized
DEBUG - 2011-09-26 13:19:59 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-26 13:19:59 --> Database Driver Class Initialized
DEBUG - 2011-09-26 13:19:59 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-26 13:19:59 --> Helper loaded: url_helper
DEBUG - 2011-09-26 13:19:59 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-26 13:19:59 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-26 13:19:59 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-26 13:19:59 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-26 13:19:59 --> Final output sent to browser
DEBUG - 2011-09-26 13:19:59 --> Total execution time: 0.0908
DEBUG - 2011-09-26 13:20:00 --> Config Class Initialized
DEBUG - 2011-09-26 13:20:00 --> Hooks Class Initialized
DEBUG - 2011-09-26 13:20:00 --> Utf8 Class Initialized
DEBUG - 2011-09-26 13:20:00 --> UTF-8 Support Enabled
DEBUG - 2011-09-26 13:20:00 --> URI Class Initialized
DEBUG - 2011-09-26 13:20:00 --> Router Class Initialized
DEBUG - 2011-09-26 13:20:00 --> Output Class Initialized
DEBUG - 2011-09-26 13:20:00 --> Input Class Initialized
DEBUG - 2011-09-26 13:20:00 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-26 13:20:00 --> Language Class Initialized
DEBUG - 2011-09-26 13:20:00 --> Loader Class Initialized
DEBUG - 2011-09-26 13:20:00 --> Controller Class Initialized
DEBUG - 2011-09-26 13:20:00 --> Model Class Initialized
DEBUG - 2011-09-26 13:20:00 --> Model Class Initialized
DEBUG - 2011-09-26 13:20:00 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-26 13:20:00 --> Database Driver Class Initialized
DEBUG - 2011-09-26 13:20:00 --> Final output sent to browser
DEBUG - 2011-09-26 13:20:00 --> Total execution time: 0.7505
DEBUG - 2011-09-26 13:20:01 --> Config Class Initialized
DEBUG - 2011-09-26 13:20:01 --> Hooks Class Initialized
DEBUG - 2011-09-26 13:20:01 --> Utf8 Class Initialized
DEBUG - 2011-09-26 13:20:01 --> UTF-8 Support Enabled
DEBUG - 2011-09-26 13:20:01 --> URI Class Initialized
DEBUG - 2011-09-26 13:20:01 --> Router Class Initialized
ERROR - 2011-09-26 13:20:01 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-26 13:20:08 --> Config Class Initialized
DEBUG - 2011-09-26 13:20:08 --> Hooks Class Initialized
DEBUG - 2011-09-26 13:20:08 --> Utf8 Class Initialized
DEBUG - 2011-09-26 13:20:08 --> UTF-8 Support Enabled
DEBUG - 2011-09-26 13:20:08 --> URI Class Initialized
DEBUG - 2011-09-26 13:20:08 --> Router Class Initialized
DEBUG - 2011-09-26 13:20:08 --> Output Class Initialized
DEBUG - 2011-09-26 13:20:08 --> Input Class Initialized
DEBUG - 2011-09-26 13:20:08 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-26 13:20:08 --> Language Class Initialized
DEBUG - 2011-09-26 13:20:08 --> Loader Class Initialized
DEBUG - 2011-09-26 13:20:08 --> Controller Class Initialized
ERROR - 2011-09-26 13:20:08 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-26 13:20:08 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-26 13:20:08 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-26 13:20:08 --> Model Class Initialized
DEBUG - 2011-09-26 13:20:08 --> Model Class Initialized
DEBUG - 2011-09-26 13:20:08 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-26 13:20:08 --> Database Driver Class Initialized
DEBUG - 2011-09-26 13:20:08 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-26 13:20:08 --> Helper loaded: url_helper
DEBUG - 2011-09-26 13:20:08 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-26 13:20:08 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-26 13:20:08 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-26 13:20:08 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-26 13:20:08 --> Final output sent to browser
DEBUG - 2011-09-26 13:20:08 --> Total execution time: 0.1446
DEBUG - 2011-09-26 13:20:09 --> Config Class Initialized
DEBUG - 2011-09-26 13:20:09 --> Hooks Class Initialized
DEBUG - 2011-09-26 13:20:09 --> Utf8 Class Initialized
DEBUG - 2011-09-26 13:20:09 --> UTF-8 Support Enabled
DEBUG - 2011-09-26 13:20:09 --> URI Class Initialized
DEBUG - 2011-09-26 13:20:09 --> Router Class Initialized
DEBUG - 2011-09-26 13:20:09 --> Output Class Initialized
DEBUG - 2011-09-26 13:20:09 --> Input Class Initialized
DEBUG - 2011-09-26 13:20:09 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-26 13:20:09 --> Language Class Initialized
DEBUG - 2011-09-26 13:20:09 --> Loader Class Initialized
DEBUG - 2011-09-26 13:20:09 --> Controller Class Initialized
DEBUG - 2011-09-26 13:20:09 --> Model Class Initialized
DEBUG - 2011-09-26 13:20:09 --> Model Class Initialized
DEBUG - 2011-09-26 13:20:09 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-26 13:20:09 --> Database Driver Class Initialized
DEBUG - 2011-09-26 13:20:10 --> Final output sent to browser
DEBUG - 2011-09-26 13:20:10 --> Total execution time: 1.0096
DEBUG - 2011-09-26 13:20:11 --> Config Class Initialized
DEBUG - 2011-09-26 13:20:11 --> Hooks Class Initialized
DEBUG - 2011-09-26 13:20:11 --> Utf8 Class Initialized
DEBUG - 2011-09-26 13:20:11 --> UTF-8 Support Enabled
DEBUG - 2011-09-26 13:20:11 --> URI Class Initialized
DEBUG - 2011-09-26 13:20:11 --> Router Class Initialized
ERROR - 2011-09-26 13:20:11 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-26 13:20:16 --> Config Class Initialized
DEBUG - 2011-09-26 13:20:16 --> Hooks Class Initialized
DEBUG - 2011-09-26 13:20:16 --> Utf8 Class Initialized
DEBUG - 2011-09-26 13:20:16 --> UTF-8 Support Enabled
DEBUG - 2011-09-26 13:20:16 --> URI Class Initialized
DEBUG - 2011-09-26 13:20:16 --> Router Class Initialized
DEBUG - 2011-09-26 13:20:16 --> Output Class Initialized
DEBUG - 2011-09-26 13:20:16 --> Input Class Initialized
DEBUG - 2011-09-26 13:20:16 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-26 13:20:16 --> Language Class Initialized
DEBUG - 2011-09-26 13:20:16 --> Loader Class Initialized
DEBUG - 2011-09-26 13:20:16 --> Controller Class Initialized
ERROR - 2011-09-26 13:20:16 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-26 13:20:16 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-26 13:20:16 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-26 13:20:16 --> Model Class Initialized
DEBUG - 2011-09-26 13:20:16 --> Model Class Initialized
DEBUG - 2011-09-26 13:20:16 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-26 13:20:16 --> Database Driver Class Initialized
DEBUG - 2011-09-26 13:20:17 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-26 13:20:17 --> Helper loaded: url_helper
DEBUG - 2011-09-26 13:20:17 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-26 13:20:17 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-26 13:20:17 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-26 13:20:17 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-26 13:20:17 --> Final output sent to browser
DEBUG - 2011-09-26 13:20:17 --> Total execution time: 0.2547
DEBUG - 2011-09-26 13:20:18 --> Config Class Initialized
DEBUG - 2011-09-26 13:20:18 --> Hooks Class Initialized
DEBUG - 2011-09-26 13:20:18 --> Utf8 Class Initialized
DEBUG - 2011-09-26 13:20:18 --> UTF-8 Support Enabled
DEBUG - 2011-09-26 13:20:18 --> URI Class Initialized
DEBUG - 2011-09-26 13:20:18 --> Router Class Initialized
DEBUG - 2011-09-26 13:20:18 --> Output Class Initialized
DEBUG - 2011-09-26 13:20:18 --> Input Class Initialized
DEBUG - 2011-09-26 13:20:18 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-26 13:20:18 --> Language Class Initialized
DEBUG - 2011-09-26 13:20:18 --> Loader Class Initialized
DEBUG - 2011-09-26 13:20:18 --> Controller Class Initialized
DEBUG - 2011-09-26 13:20:18 --> Model Class Initialized
DEBUG - 2011-09-26 13:20:18 --> Model Class Initialized
DEBUG - 2011-09-26 13:20:18 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-26 13:20:18 --> Database Driver Class Initialized
DEBUG - 2011-09-26 13:20:18 --> Final output sent to browser
DEBUG - 2011-09-26 13:20:18 --> Total execution time: 0.7270
DEBUG - 2011-09-26 13:20:19 --> Config Class Initialized
DEBUG - 2011-09-26 13:20:19 --> Hooks Class Initialized
DEBUG - 2011-09-26 13:20:19 --> Utf8 Class Initialized
DEBUG - 2011-09-26 13:20:19 --> UTF-8 Support Enabled
DEBUG - 2011-09-26 13:20:19 --> URI Class Initialized
DEBUG - 2011-09-26 13:20:20 --> Router Class Initialized
ERROR - 2011-09-26 13:20:20 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-26 13:31:17 --> Config Class Initialized
DEBUG - 2011-09-26 13:31:17 --> Hooks Class Initialized
DEBUG - 2011-09-26 13:31:17 --> Utf8 Class Initialized
DEBUG - 2011-09-26 13:31:17 --> UTF-8 Support Enabled
DEBUG - 2011-09-26 13:31:17 --> URI Class Initialized
DEBUG - 2011-09-26 13:31:17 --> Router Class Initialized
DEBUG - 2011-09-26 13:31:17 --> Output Class Initialized
DEBUG - 2011-09-26 13:31:17 --> Input Class Initialized
DEBUG - 2011-09-26 13:31:17 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-26 13:31:17 --> Language Class Initialized
DEBUG - 2011-09-26 13:31:17 --> Loader Class Initialized
DEBUG - 2011-09-26 13:31:17 --> Controller Class Initialized
DEBUG - 2011-09-26 13:31:17 --> Model Class Initialized
DEBUG - 2011-09-26 13:31:17 --> Model Class Initialized
DEBUG - 2011-09-26 13:31:17 --> Model Class Initialized
DEBUG - 2011-09-26 13:31:17 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-26 13:31:17 --> Database Driver Class Initialized
DEBUG - 2011-09-26 13:31:18 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-26 13:31:18 --> Helper loaded: url_helper
DEBUG - 2011-09-26 13:31:18 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-26 13:31:18 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-26 13:31:18 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-26 13:31:18 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-26 13:31:18 --> Final output sent to browser
DEBUG - 2011-09-26 13:31:18 --> Total execution time: 0.7749
DEBUG - 2011-09-26 13:31:19 --> Config Class Initialized
DEBUG - 2011-09-26 13:31:19 --> Hooks Class Initialized
DEBUG - 2011-09-26 13:31:19 --> Utf8 Class Initialized
DEBUG - 2011-09-26 13:31:19 --> UTF-8 Support Enabled
DEBUG - 2011-09-26 13:31:19 --> URI Class Initialized
DEBUG - 2011-09-26 13:31:19 --> Router Class Initialized
DEBUG - 2011-09-26 13:31:19 --> Output Class Initialized
DEBUG - 2011-09-26 13:31:19 --> Input Class Initialized
DEBUG - 2011-09-26 13:31:19 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-26 13:31:19 --> Language Class Initialized
DEBUG - 2011-09-26 13:31:19 --> Loader Class Initialized
DEBUG - 2011-09-26 13:31:19 --> Controller Class Initialized
ERROR - 2011-09-26 13:31:19 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-26 13:31:19 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-26 13:31:19 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-26 13:31:19 --> Model Class Initialized
DEBUG - 2011-09-26 13:31:19 --> Model Class Initialized
DEBUG - 2011-09-26 13:31:19 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-26 13:31:19 --> Database Driver Class Initialized
DEBUG - 2011-09-26 13:31:19 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-26 13:31:19 --> Helper loaded: url_helper
DEBUG - 2011-09-26 13:31:19 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-26 13:31:20 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-26 13:31:20 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-26 13:31:20 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-26 13:31:20 --> Final output sent to browser
DEBUG - 2011-09-26 13:31:20 --> Total execution time: 0.0810
DEBUG - 2011-09-26 15:05:13 --> Config Class Initialized
DEBUG - 2011-09-26 15:05:13 --> Hooks Class Initialized
DEBUG - 2011-09-26 15:05:13 --> Utf8 Class Initialized
DEBUG - 2011-09-26 15:05:13 --> UTF-8 Support Enabled
DEBUG - 2011-09-26 15:05:13 --> URI Class Initialized
DEBUG - 2011-09-26 15:05:13 --> Router Class Initialized
DEBUG - 2011-09-26 15:05:13 --> Output Class Initialized
DEBUG - 2011-09-26 15:05:13 --> Input Class Initialized
DEBUG - 2011-09-26 15:05:13 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-26 15:05:13 --> Language Class Initialized
DEBUG - 2011-09-26 15:05:13 --> Loader Class Initialized
DEBUG - 2011-09-26 15:05:13 --> Controller Class Initialized
DEBUG - 2011-09-26 15:05:13 --> Model Class Initialized
DEBUG - 2011-09-26 15:05:13 --> Model Class Initialized
DEBUG - 2011-09-26 15:05:13 --> Model Class Initialized
DEBUG - 2011-09-26 15:05:13 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-26 15:05:13 --> Database Driver Class Initialized
DEBUG - 2011-09-26 15:05:14 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-26 15:05:14 --> Helper loaded: url_helper
DEBUG - 2011-09-26 15:05:14 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-26 15:05:14 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-26 15:05:14 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-26 15:05:14 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-26 15:05:14 --> Final output sent to browser
DEBUG - 2011-09-26 15:05:14 --> Total execution time: 0.9898
DEBUG - 2011-09-26 15:05:19 --> Config Class Initialized
DEBUG - 2011-09-26 15:05:19 --> Hooks Class Initialized
DEBUG - 2011-09-26 15:05:19 --> Utf8 Class Initialized
DEBUG - 2011-09-26 15:05:19 --> UTF-8 Support Enabled
DEBUG - 2011-09-26 15:05:19 --> URI Class Initialized
DEBUG - 2011-09-26 15:05:19 --> Router Class Initialized
ERROR - 2011-09-26 15:05:19 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-26 15:05:48 --> Config Class Initialized
DEBUG - 2011-09-26 15:05:48 --> Hooks Class Initialized
DEBUG - 2011-09-26 15:05:48 --> Utf8 Class Initialized
DEBUG - 2011-09-26 15:05:48 --> UTF-8 Support Enabled
DEBUG - 2011-09-26 15:05:48 --> URI Class Initialized
DEBUG - 2011-09-26 15:05:48 --> Router Class Initialized
DEBUG - 2011-09-26 15:05:48 --> Output Class Initialized
DEBUG - 2011-09-26 15:05:48 --> Input Class Initialized
DEBUG - 2011-09-26 15:05:48 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-26 15:05:48 --> Language Class Initialized
DEBUG - 2011-09-26 15:05:48 --> Loader Class Initialized
DEBUG - 2011-09-26 15:05:48 --> Controller Class Initialized
DEBUG - 2011-09-26 15:05:48 --> Model Class Initialized
DEBUG - 2011-09-26 15:05:48 --> Model Class Initialized
DEBUG - 2011-09-26 15:05:48 --> Model Class Initialized
DEBUG - 2011-09-26 15:05:48 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-26 15:05:48 --> Database Driver Class Initialized
DEBUG - 2011-09-26 15:05:49 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-26 15:05:49 --> Helper loaded: url_helper
DEBUG - 2011-09-26 15:05:49 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-26 15:05:49 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-26 15:05:49 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-26 15:05:49 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-26 15:05:49 --> Final output sent to browser
DEBUG - 2011-09-26 15:05:49 --> Total execution time: 0.4939
DEBUG - 2011-09-26 15:05:51 --> Config Class Initialized
DEBUG - 2011-09-26 15:05:51 --> Hooks Class Initialized
DEBUG - 2011-09-26 15:05:51 --> Utf8 Class Initialized
DEBUG - 2011-09-26 15:05:51 --> UTF-8 Support Enabled
DEBUG - 2011-09-26 15:05:51 --> URI Class Initialized
DEBUG - 2011-09-26 15:05:51 --> Router Class Initialized
ERROR - 2011-09-26 15:05:51 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-26 15:07:26 --> Config Class Initialized
DEBUG - 2011-09-26 15:07:26 --> Hooks Class Initialized
DEBUG - 2011-09-26 15:07:26 --> Utf8 Class Initialized
DEBUG - 2011-09-26 15:07:26 --> UTF-8 Support Enabled
DEBUG - 2011-09-26 15:07:26 --> URI Class Initialized
DEBUG - 2011-09-26 15:07:26 --> Router Class Initialized
DEBUG - 2011-09-26 15:07:26 --> Output Class Initialized
DEBUG - 2011-09-26 15:07:26 --> Input Class Initialized
DEBUG - 2011-09-26 15:07:26 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-26 15:07:26 --> Language Class Initialized
DEBUG - 2011-09-26 15:07:26 --> Loader Class Initialized
DEBUG - 2011-09-26 15:07:26 --> Controller Class Initialized
ERROR - 2011-09-26 15:07:26 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-26 15:07:26 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-26 15:07:26 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-26 15:07:26 --> Model Class Initialized
DEBUG - 2011-09-26 15:07:26 --> Model Class Initialized
DEBUG - 2011-09-26 15:07:26 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-26 15:07:26 --> Database Driver Class Initialized
DEBUG - 2011-09-26 15:07:26 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-26 15:07:26 --> Helper loaded: url_helper
DEBUG - 2011-09-26 15:07:26 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-26 15:07:26 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-26 15:07:26 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-26 15:07:26 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-26 15:07:26 --> Final output sent to browser
DEBUG - 2011-09-26 15:07:26 --> Total execution time: 0.3040
DEBUG - 2011-09-26 15:07:29 --> Config Class Initialized
DEBUG - 2011-09-26 15:07:29 --> Hooks Class Initialized
DEBUG - 2011-09-26 15:07:29 --> Utf8 Class Initialized
DEBUG - 2011-09-26 15:07:29 --> UTF-8 Support Enabled
DEBUG - 2011-09-26 15:07:29 --> URI Class Initialized
DEBUG - 2011-09-26 15:07:29 --> Router Class Initialized
DEBUG - 2011-09-26 15:07:29 --> Output Class Initialized
DEBUG - 2011-09-26 15:07:29 --> Input Class Initialized
DEBUG - 2011-09-26 15:07:29 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-26 15:07:29 --> Language Class Initialized
DEBUG - 2011-09-26 15:07:29 --> Loader Class Initialized
DEBUG - 2011-09-26 15:07:29 --> Controller Class Initialized
DEBUG - 2011-09-26 15:07:29 --> Model Class Initialized
DEBUG - 2011-09-26 15:07:29 --> Model Class Initialized
DEBUG - 2011-09-26 15:07:29 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-26 15:07:29 --> Database Driver Class Initialized
DEBUG - 2011-09-26 15:07:30 --> Final output sent to browser
DEBUG - 2011-09-26 15:07:30 --> Total execution time: 0.9747
DEBUG - 2011-09-26 15:07:33 --> Config Class Initialized
DEBUG - 2011-09-26 15:07:33 --> Hooks Class Initialized
DEBUG - 2011-09-26 15:07:33 --> Utf8 Class Initialized
DEBUG - 2011-09-26 15:07:33 --> UTF-8 Support Enabled
DEBUG - 2011-09-26 15:07:33 --> URI Class Initialized
DEBUG - 2011-09-26 15:07:33 --> Router Class Initialized
ERROR - 2011-09-26 15:07:33 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-26 15:07:49 --> Config Class Initialized
DEBUG - 2011-09-26 15:07:49 --> Hooks Class Initialized
DEBUG - 2011-09-26 15:07:49 --> Utf8 Class Initialized
DEBUG - 2011-09-26 15:07:49 --> UTF-8 Support Enabled
DEBUG - 2011-09-26 15:07:49 --> URI Class Initialized
DEBUG - 2011-09-26 15:07:49 --> Router Class Initialized
DEBUG - 2011-09-26 15:07:49 --> Output Class Initialized
DEBUG - 2011-09-26 15:07:49 --> Input Class Initialized
DEBUG - 2011-09-26 15:07:49 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-26 15:07:49 --> Language Class Initialized
DEBUG - 2011-09-26 15:07:49 --> Loader Class Initialized
DEBUG - 2011-09-26 15:07:49 --> Controller Class Initialized
ERROR - 2011-09-26 15:07:49 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-26 15:07:49 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-26 15:07:49 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-26 15:07:49 --> Model Class Initialized
DEBUG - 2011-09-26 15:07:49 --> Model Class Initialized
DEBUG - 2011-09-26 15:07:49 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-26 15:07:49 --> Database Driver Class Initialized
DEBUG - 2011-09-26 15:07:49 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-26 15:07:49 --> Helper loaded: url_helper
DEBUG - 2011-09-26 15:07:49 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-26 15:07:49 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-26 15:07:49 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-26 15:07:49 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-26 15:07:49 --> Final output sent to browser
DEBUG - 2011-09-26 15:07:49 --> Total execution time: 0.3002
DEBUG - 2011-09-26 15:07:51 --> Config Class Initialized
DEBUG - 2011-09-26 15:07:51 --> Hooks Class Initialized
DEBUG - 2011-09-26 15:07:51 --> Utf8 Class Initialized
DEBUG - 2011-09-26 15:07:51 --> UTF-8 Support Enabled
DEBUG - 2011-09-26 15:07:51 --> URI Class Initialized
DEBUG - 2011-09-26 15:07:51 --> Router Class Initialized
DEBUG - 2011-09-26 15:07:51 --> Output Class Initialized
DEBUG - 2011-09-26 15:07:51 --> Input Class Initialized
DEBUG - 2011-09-26 15:07:51 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-26 15:07:51 --> Language Class Initialized
DEBUG - 2011-09-26 15:07:51 --> Loader Class Initialized
DEBUG - 2011-09-26 15:07:51 --> Controller Class Initialized
DEBUG - 2011-09-26 15:07:51 --> Model Class Initialized
DEBUG - 2011-09-26 15:07:51 --> Model Class Initialized
DEBUG - 2011-09-26 15:07:51 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-26 15:07:51 --> Database Driver Class Initialized
DEBUG - 2011-09-26 15:07:57 --> Final output sent to browser
DEBUG - 2011-09-26 15:07:57 --> Total execution time: 6.3956
DEBUG - 2011-09-26 15:08:02 --> Config Class Initialized
DEBUG - 2011-09-26 15:08:03 --> Hooks Class Initialized
DEBUG - 2011-09-26 15:08:03 --> Utf8 Class Initialized
DEBUG - 2011-09-26 15:08:03 --> UTF-8 Support Enabled
DEBUG - 2011-09-26 15:08:03 --> URI Class Initialized
DEBUG - 2011-09-26 15:08:03 --> Router Class Initialized
ERROR - 2011-09-26 15:08:03 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-26 16:07:00 --> Config Class Initialized
DEBUG - 2011-09-26 16:07:00 --> Hooks Class Initialized
DEBUG - 2011-09-26 16:07:00 --> Utf8 Class Initialized
DEBUG - 2011-09-26 16:07:00 --> UTF-8 Support Enabled
DEBUG - 2011-09-26 16:07:00 --> URI Class Initialized
DEBUG - 2011-09-26 16:07:00 --> Router Class Initialized
DEBUG - 2011-09-26 16:07:00 --> Output Class Initialized
DEBUG - 2011-09-26 16:07:00 --> Input Class Initialized
DEBUG - 2011-09-26 16:07:00 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-26 16:07:00 --> Language Class Initialized
DEBUG - 2011-09-26 16:07:00 --> Loader Class Initialized
DEBUG - 2011-09-26 16:07:00 --> Controller Class Initialized
ERROR - 2011-09-26 16:07:00 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-26 16:07:00 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-26 16:07:00 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-26 16:07:00 --> Model Class Initialized
DEBUG - 2011-09-26 16:07:00 --> Model Class Initialized
DEBUG - 2011-09-26 16:07:00 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-26 16:07:00 --> Database Driver Class Initialized
DEBUG - 2011-09-26 16:07:00 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-26 16:07:00 --> Helper loaded: url_helper
DEBUG - 2011-09-26 16:07:00 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-26 16:07:00 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-26 16:07:00 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-26 16:07:00 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-26 16:07:00 --> Final output sent to browser
DEBUG - 2011-09-26 16:07:00 --> Total execution time: 0.2349
DEBUG - 2011-09-26 16:07:02 --> Config Class Initialized
DEBUG - 2011-09-26 16:07:02 --> Hooks Class Initialized
DEBUG - 2011-09-26 16:07:02 --> Utf8 Class Initialized
DEBUG - 2011-09-26 16:07:02 --> UTF-8 Support Enabled
DEBUG - 2011-09-26 16:07:02 --> URI Class Initialized
DEBUG - 2011-09-26 16:07:02 --> Router Class Initialized
DEBUG - 2011-09-26 16:07:02 --> Output Class Initialized
DEBUG - 2011-09-26 16:07:02 --> Input Class Initialized
DEBUG - 2011-09-26 16:07:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-26 16:07:02 --> Language Class Initialized
DEBUG - 2011-09-26 16:07:02 --> Loader Class Initialized
DEBUG - 2011-09-26 16:07:02 --> Controller Class Initialized
DEBUG - 2011-09-26 16:07:02 --> Model Class Initialized
DEBUG - 2011-09-26 16:07:02 --> Model Class Initialized
DEBUG - 2011-09-26 16:07:02 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-26 16:07:02 --> Database Driver Class Initialized
DEBUG - 2011-09-26 16:07:03 --> Final output sent to browser
DEBUG - 2011-09-26 16:07:03 --> Total execution time: 0.8465
DEBUG - 2011-09-26 17:32:27 --> Config Class Initialized
DEBUG - 2011-09-26 17:32:27 --> Hooks Class Initialized
DEBUG - 2011-09-26 17:32:27 --> Utf8 Class Initialized
DEBUG - 2011-09-26 17:32:27 --> UTF-8 Support Enabled
DEBUG - 2011-09-26 17:32:27 --> URI Class Initialized
DEBUG - 2011-09-26 17:32:27 --> Router Class Initialized
DEBUG - 2011-09-26 17:32:27 --> Output Class Initialized
DEBUG - 2011-09-26 17:32:27 --> Input Class Initialized
DEBUG - 2011-09-26 17:32:27 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-26 17:32:27 --> Language Class Initialized
DEBUG - 2011-09-26 17:32:27 --> Loader Class Initialized
DEBUG - 2011-09-26 17:32:27 --> Controller Class Initialized
DEBUG - 2011-09-26 17:32:27 --> Model Class Initialized
DEBUG - 2011-09-26 17:32:27 --> Model Class Initialized
DEBUG - 2011-09-26 17:32:27 --> Model Class Initialized
DEBUG - 2011-09-26 17:32:27 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-26 17:32:27 --> Database Driver Class Initialized
DEBUG - 2011-09-26 17:32:28 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-26 17:32:28 --> Helper loaded: url_helper
DEBUG - 2011-09-26 17:32:28 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-26 17:32:28 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-26 17:32:28 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-26 17:32:28 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-26 17:32:28 --> Final output sent to browser
DEBUG - 2011-09-26 17:32:28 --> Total execution time: 0.8040
DEBUG - 2011-09-26 17:32:32 --> Config Class Initialized
DEBUG - 2011-09-26 17:32:32 --> Hooks Class Initialized
DEBUG - 2011-09-26 17:32:32 --> Utf8 Class Initialized
DEBUG - 2011-09-26 17:32:32 --> UTF-8 Support Enabled
DEBUG - 2011-09-26 17:32:32 --> URI Class Initialized
DEBUG - 2011-09-26 17:32:32 --> Router Class Initialized
ERROR - 2011-09-26 17:32:32 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-26 17:32:48 --> Config Class Initialized
DEBUG - 2011-09-26 17:32:48 --> Hooks Class Initialized
DEBUG - 2011-09-26 17:32:48 --> Utf8 Class Initialized
DEBUG - 2011-09-26 17:32:48 --> UTF-8 Support Enabled
DEBUG - 2011-09-26 17:32:48 --> URI Class Initialized
DEBUG - 2011-09-26 17:32:48 --> Router Class Initialized
DEBUG - 2011-09-26 17:32:48 --> Output Class Initialized
DEBUG - 2011-09-26 17:32:48 --> Input Class Initialized
DEBUG - 2011-09-26 17:32:48 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-26 17:32:48 --> Language Class Initialized
DEBUG - 2011-09-26 17:32:48 --> Loader Class Initialized
DEBUG - 2011-09-26 17:32:48 --> Controller Class Initialized
DEBUG - 2011-09-26 17:32:48 --> Model Class Initialized
DEBUG - 2011-09-26 17:32:48 --> Model Class Initialized
DEBUG - 2011-09-26 17:32:48 --> Model Class Initialized
DEBUG - 2011-09-26 17:32:48 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-26 17:32:48 --> Database Driver Class Initialized
DEBUG - 2011-09-26 17:32:48 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-26 17:32:48 --> Helper loaded: url_helper
DEBUG - 2011-09-26 17:32:48 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-26 17:32:48 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-26 17:32:48 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-26 17:32:48 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-26 17:32:48 --> Final output sent to browser
DEBUG - 2011-09-26 17:32:48 --> Total execution time: 0.6190
DEBUG - 2011-09-26 17:33:04 --> Config Class Initialized
DEBUG - 2011-09-26 17:33:04 --> Hooks Class Initialized
DEBUG - 2011-09-26 17:33:04 --> Utf8 Class Initialized
DEBUG - 2011-09-26 17:33:04 --> UTF-8 Support Enabled
DEBUG - 2011-09-26 17:33:04 --> URI Class Initialized
DEBUG - 2011-09-26 17:33:04 --> Router Class Initialized
DEBUG - 2011-09-26 17:33:04 --> Output Class Initialized
DEBUG - 2011-09-26 17:33:04 --> Input Class Initialized
DEBUG - 2011-09-26 17:33:04 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-26 17:33:04 --> Language Class Initialized
DEBUG - 2011-09-26 17:33:04 --> Loader Class Initialized
DEBUG - 2011-09-26 17:33:04 --> Controller Class Initialized
DEBUG - 2011-09-26 17:33:04 --> Model Class Initialized
DEBUG - 2011-09-26 17:33:04 --> Model Class Initialized
DEBUG - 2011-09-26 17:33:04 --> Model Class Initialized
DEBUG - 2011-09-26 17:33:04 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-26 17:33:04 --> Database Driver Class Initialized
DEBUG - 2011-09-26 17:33:05 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-26 17:33:05 --> Helper loaded: url_helper
DEBUG - 2011-09-26 17:33:05 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-26 17:33:05 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-26 17:33:05 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-26 17:33:05 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-26 17:33:05 --> Final output sent to browser
DEBUG - 2011-09-26 17:33:05 --> Total execution time: 0.7350
DEBUG - 2011-09-26 17:33:16 --> Config Class Initialized
DEBUG - 2011-09-26 17:33:16 --> Hooks Class Initialized
DEBUG - 2011-09-26 17:33:16 --> Utf8 Class Initialized
DEBUG - 2011-09-26 17:33:16 --> UTF-8 Support Enabled
DEBUG - 2011-09-26 17:33:16 --> URI Class Initialized
DEBUG - 2011-09-26 17:33:16 --> Router Class Initialized
DEBUG - 2011-09-26 17:33:16 --> Output Class Initialized
DEBUG - 2011-09-26 17:33:16 --> Input Class Initialized
DEBUG - 2011-09-26 17:33:16 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-26 17:33:16 --> Language Class Initialized
DEBUG - 2011-09-26 17:33:16 --> Loader Class Initialized
DEBUG - 2011-09-26 17:33:16 --> Controller Class Initialized
DEBUG - 2011-09-26 17:33:16 --> Model Class Initialized
DEBUG - 2011-09-26 17:33:16 --> Model Class Initialized
DEBUG - 2011-09-26 17:33:16 --> Model Class Initialized
DEBUG - 2011-09-26 17:33:16 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-26 17:33:16 --> Database Driver Class Initialized
DEBUG - 2011-09-26 17:33:16 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-26 17:33:16 --> Helper loaded: url_helper
DEBUG - 2011-09-26 17:33:16 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-26 17:33:16 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-26 17:33:16 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-26 17:33:16 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-26 17:33:16 --> Final output sent to browser
DEBUG - 2011-09-26 17:33:16 --> Total execution time: 0.4643
DEBUG - 2011-09-26 17:33:23 --> Config Class Initialized
DEBUG - 2011-09-26 17:33:23 --> Hooks Class Initialized
DEBUG - 2011-09-26 17:33:23 --> Utf8 Class Initialized
DEBUG - 2011-09-26 17:33:23 --> UTF-8 Support Enabled
DEBUG - 2011-09-26 17:33:23 --> URI Class Initialized
DEBUG - 2011-09-26 17:33:23 --> Router Class Initialized
DEBUG - 2011-09-26 17:33:23 --> Output Class Initialized
DEBUG - 2011-09-26 17:33:23 --> Input Class Initialized
DEBUG - 2011-09-26 17:33:23 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-26 17:33:23 --> Language Class Initialized
DEBUG - 2011-09-26 17:33:23 --> Loader Class Initialized
DEBUG - 2011-09-26 17:33:23 --> Controller Class Initialized
DEBUG - 2011-09-26 17:33:23 --> Model Class Initialized
DEBUG - 2011-09-26 17:33:23 --> Model Class Initialized
DEBUG - 2011-09-26 17:33:23 --> Model Class Initialized
DEBUG - 2011-09-26 17:33:23 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-26 17:33:23 --> Database Driver Class Initialized
DEBUG - 2011-09-26 17:33:23 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-26 17:33:23 --> Helper loaded: url_helper
DEBUG - 2011-09-26 17:33:23 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-26 17:33:23 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-26 17:33:23 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-26 17:33:23 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-26 17:33:23 --> Final output sent to browser
DEBUG - 2011-09-26 17:33:23 --> Total execution time: 0.2992
DEBUG - 2011-09-26 17:33:30 --> Config Class Initialized
DEBUG - 2011-09-26 17:33:30 --> Hooks Class Initialized
DEBUG - 2011-09-26 17:33:30 --> Utf8 Class Initialized
DEBUG - 2011-09-26 17:33:30 --> UTF-8 Support Enabled
DEBUG - 2011-09-26 17:33:30 --> URI Class Initialized
DEBUG - 2011-09-26 17:33:30 --> Router Class Initialized
DEBUG - 2011-09-26 17:33:30 --> Output Class Initialized
DEBUG - 2011-09-26 17:33:30 --> Input Class Initialized
DEBUG - 2011-09-26 17:33:30 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-26 17:33:30 --> Language Class Initialized
DEBUG - 2011-09-26 17:33:30 --> Loader Class Initialized
DEBUG - 2011-09-26 17:33:30 --> Controller Class Initialized
DEBUG - 2011-09-26 17:33:30 --> Model Class Initialized
DEBUG - 2011-09-26 17:33:30 --> Model Class Initialized
DEBUG - 2011-09-26 17:33:30 --> Model Class Initialized
DEBUG - 2011-09-26 17:33:30 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-26 17:33:30 --> Database Driver Class Initialized
DEBUG - 2011-09-26 17:33:30 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-26 17:33:30 --> Helper loaded: url_helper
DEBUG - 2011-09-26 17:33:30 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-26 17:33:30 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-26 17:33:30 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-26 17:33:30 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-26 17:33:30 --> Final output sent to browser
DEBUG - 2011-09-26 17:33:30 --> Total execution time: 0.7070
DEBUG - 2011-09-26 17:33:31 --> Config Class Initialized
DEBUG - 2011-09-26 17:33:31 --> Hooks Class Initialized
DEBUG - 2011-09-26 17:33:31 --> Utf8 Class Initialized
DEBUG - 2011-09-26 17:33:31 --> UTF-8 Support Enabled
DEBUG - 2011-09-26 17:33:31 --> URI Class Initialized
DEBUG - 2011-09-26 17:33:31 --> Router Class Initialized
DEBUG - 2011-09-26 17:33:31 --> Output Class Initialized
DEBUG - 2011-09-26 17:33:31 --> Input Class Initialized
DEBUG - 2011-09-26 17:33:31 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-26 17:33:31 --> Language Class Initialized
DEBUG - 2011-09-26 17:33:31 --> Loader Class Initialized
DEBUG - 2011-09-26 17:33:31 --> Controller Class Initialized
DEBUG - 2011-09-26 17:33:31 --> Model Class Initialized
DEBUG - 2011-09-26 17:33:31 --> Model Class Initialized
DEBUG - 2011-09-26 17:33:31 --> Model Class Initialized
DEBUG - 2011-09-26 17:33:31 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-26 17:33:31 --> Database Driver Class Initialized
DEBUG - 2011-09-26 17:33:31 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-26 17:33:31 --> Helper loaded: url_helper
DEBUG - 2011-09-26 17:33:31 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-26 17:33:31 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-26 17:33:31 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-26 17:33:31 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-26 17:33:31 --> Final output sent to browser
DEBUG - 2011-09-26 17:33:31 --> Total execution time: 0.0495
DEBUG - 2011-09-26 17:33:32 --> Config Class Initialized
DEBUG - 2011-09-26 17:33:32 --> Hooks Class Initialized
DEBUG - 2011-09-26 17:33:32 --> Utf8 Class Initialized
DEBUG - 2011-09-26 17:33:32 --> UTF-8 Support Enabled
DEBUG - 2011-09-26 17:33:32 --> URI Class Initialized
DEBUG - 2011-09-26 17:33:32 --> Router Class Initialized
DEBUG - 2011-09-26 17:33:32 --> Output Class Initialized
DEBUG - 2011-09-26 17:33:32 --> Input Class Initialized
DEBUG - 2011-09-26 17:33:32 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-26 17:33:32 --> Language Class Initialized
DEBUG - 2011-09-26 17:33:32 --> Loader Class Initialized
DEBUG - 2011-09-26 17:33:32 --> Controller Class Initialized
DEBUG - 2011-09-26 17:33:32 --> Model Class Initialized
DEBUG - 2011-09-26 17:33:32 --> Model Class Initialized
DEBUG - 2011-09-26 17:33:32 --> Model Class Initialized
DEBUG - 2011-09-26 17:33:32 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-26 17:33:32 --> Database Driver Class Initialized
DEBUG - 2011-09-26 17:33:32 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-26 17:33:32 --> Helper loaded: url_helper
DEBUG - 2011-09-26 17:33:32 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-26 17:33:32 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-26 17:33:32 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-26 17:33:32 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-26 17:33:32 --> Final output sent to browser
DEBUG - 2011-09-26 17:33:32 --> Total execution time: 0.0531
DEBUG - 2011-09-26 17:33:39 --> Config Class Initialized
DEBUG - 2011-09-26 17:33:39 --> Hooks Class Initialized
DEBUG - 2011-09-26 17:33:39 --> Utf8 Class Initialized
DEBUG - 2011-09-26 17:33:39 --> UTF-8 Support Enabled
DEBUG - 2011-09-26 17:33:39 --> URI Class Initialized
DEBUG - 2011-09-26 17:33:39 --> Router Class Initialized
DEBUG - 2011-09-26 17:33:39 --> Output Class Initialized
DEBUG - 2011-09-26 17:33:39 --> Input Class Initialized
DEBUG - 2011-09-26 17:33:39 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-26 17:33:39 --> Language Class Initialized
DEBUG - 2011-09-26 17:33:39 --> Loader Class Initialized
DEBUG - 2011-09-26 17:33:39 --> Controller Class Initialized
DEBUG - 2011-09-26 17:33:39 --> Model Class Initialized
DEBUG - 2011-09-26 17:33:39 --> Model Class Initialized
DEBUG - 2011-09-26 17:33:39 --> Model Class Initialized
DEBUG - 2011-09-26 17:33:39 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-26 17:33:39 --> Database Driver Class Initialized
DEBUG - 2011-09-26 17:33:40 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-26 17:33:40 --> Helper loaded: url_helper
DEBUG - 2011-09-26 17:33:40 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-26 17:33:40 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-26 17:33:40 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-26 17:33:40 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-26 17:33:40 --> Final output sent to browser
DEBUG - 2011-09-26 17:33:40 --> Total execution time: 1.1957
DEBUG - 2011-09-26 17:33:46 --> Config Class Initialized
DEBUG - 2011-09-26 17:33:46 --> Hooks Class Initialized
DEBUG - 2011-09-26 17:33:46 --> Utf8 Class Initialized
DEBUG - 2011-09-26 17:33:46 --> UTF-8 Support Enabled
DEBUG - 2011-09-26 17:33:46 --> URI Class Initialized
DEBUG - 2011-09-26 17:33:46 --> Router Class Initialized
DEBUG - 2011-09-26 17:33:46 --> Output Class Initialized
DEBUG - 2011-09-26 17:33:46 --> Input Class Initialized
DEBUG - 2011-09-26 17:33:46 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-26 17:33:46 --> Language Class Initialized
DEBUG - 2011-09-26 17:33:46 --> Loader Class Initialized
DEBUG - 2011-09-26 17:33:46 --> Controller Class Initialized
DEBUG - 2011-09-26 17:33:46 --> Model Class Initialized
DEBUG - 2011-09-26 17:33:46 --> Model Class Initialized
DEBUG - 2011-09-26 17:33:46 --> Model Class Initialized
DEBUG - 2011-09-26 17:33:46 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-26 17:33:46 --> Database Driver Class Initialized
DEBUG - 2011-09-26 17:33:46 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-26 17:33:46 --> Helper loaded: url_helper
DEBUG - 2011-09-26 17:33:46 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-26 17:33:46 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-26 17:33:46 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-26 17:33:46 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-26 17:33:46 --> Final output sent to browser
DEBUG - 2011-09-26 17:33:46 --> Total execution time: 0.2354
DEBUG - 2011-09-26 17:58:35 --> Config Class Initialized
DEBUG - 2011-09-26 17:58:35 --> Hooks Class Initialized
DEBUG - 2011-09-26 17:58:35 --> Utf8 Class Initialized
DEBUG - 2011-09-26 17:58:35 --> UTF-8 Support Enabled
DEBUG - 2011-09-26 17:58:35 --> URI Class Initialized
DEBUG - 2011-09-26 17:58:35 --> Router Class Initialized
ERROR - 2011-09-26 17:58:35 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-09-26 18:13:10 --> Config Class Initialized
DEBUG - 2011-09-26 18:13:10 --> Hooks Class Initialized
DEBUG - 2011-09-26 18:13:10 --> Utf8 Class Initialized
DEBUG - 2011-09-26 18:13:10 --> UTF-8 Support Enabled
DEBUG - 2011-09-26 18:13:10 --> URI Class Initialized
DEBUG - 2011-09-26 18:13:10 --> Router Class Initialized
DEBUG - 2011-09-26 18:13:10 --> No URI present. Default controller set.
DEBUG - 2011-09-26 18:13:10 --> Output Class Initialized
DEBUG - 2011-09-26 18:13:10 --> Input Class Initialized
DEBUG - 2011-09-26 18:13:10 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-26 18:13:10 --> Language Class Initialized
DEBUG - 2011-09-26 18:13:10 --> Loader Class Initialized
DEBUG - 2011-09-26 18:13:10 --> Controller Class Initialized
DEBUG - 2011-09-26 18:13:10 --> File loaded: application/views/splash/main.php
DEBUG - 2011-09-26 18:13:10 --> Helper loaded: url_helper
DEBUG - 2011-09-26 18:13:10 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-26 18:13:10 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-26 18:13:10 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-26 18:13:10 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-26 18:13:10 --> Final output sent to browser
DEBUG - 2011-09-26 18:13:10 --> Total execution time: 0.1551
DEBUG - 2011-09-26 18:32:22 --> Config Class Initialized
DEBUG - 2011-09-26 18:32:22 --> Hooks Class Initialized
DEBUG - 2011-09-26 18:32:22 --> Utf8 Class Initialized
DEBUG - 2011-09-26 18:32:22 --> UTF-8 Support Enabled
DEBUG - 2011-09-26 18:32:22 --> URI Class Initialized
DEBUG - 2011-09-26 18:32:22 --> Router Class Initialized
ERROR - 2011-09-26 18:32:22 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-09-26 18:32:23 --> Config Class Initialized
DEBUG - 2011-09-26 18:32:23 --> Hooks Class Initialized
DEBUG - 2011-09-26 18:32:23 --> Utf8 Class Initialized
DEBUG - 2011-09-26 18:32:23 --> UTF-8 Support Enabled
DEBUG - 2011-09-26 18:32:23 --> URI Class Initialized
DEBUG - 2011-09-26 18:32:23 --> Router Class Initialized
DEBUG - 2011-09-26 18:32:23 --> Output Class Initialized
DEBUG - 2011-09-26 18:32:23 --> Input Class Initialized
DEBUG - 2011-09-26 18:32:23 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-26 18:32:23 --> Language Class Initialized
DEBUG - 2011-09-26 18:32:23 --> Loader Class Initialized
DEBUG - 2011-09-26 18:32:23 --> Controller Class Initialized
DEBUG - 2011-09-26 18:32:23 --> Model Class Initialized
DEBUG - 2011-09-26 18:32:23 --> Model Class Initialized
DEBUG - 2011-09-26 18:32:23 --> Model Class Initialized
DEBUG - 2011-09-26 18:32:23 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-26 18:32:24 --> Database Driver Class Initialized
DEBUG - 2011-09-26 18:32:25 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-26 18:32:25 --> Helper loaded: url_helper
DEBUG - 2011-09-26 18:32:25 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-26 18:32:25 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-26 18:32:25 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-26 18:32:25 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-26 18:32:25 --> Final output sent to browser
DEBUG - 2011-09-26 18:32:25 --> Total execution time: 1.8316
DEBUG - 2011-09-26 19:26:32 --> Config Class Initialized
DEBUG - 2011-09-26 19:26:32 --> Hooks Class Initialized
DEBUG - 2011-09-26 19:26:32 --> Utf8 Class Initialized
DEBUG - 2011-09-26 19:26:32 --> UTF-8 Support Enabled
DEBUG - 2011-09-26 19:26:32 --> URI Class Initialized
DEBUG - 2011-09-26 19:26:32 --> Router Class Initialized
ERROR - 2011-09-26 19:26:32 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-09-26 20:21:49 --> Config Class Initialized
DEBUG - 2011-09-26 20:21:49 --> Hooks Class Initialized
DEBUG - 2011-09-26 20:21:49 --> Utf8 Class Initialized
DEBUG - 2011-09-26 20:21:49 --> UTF-8 Support Enabled
DEBUG - 2011-09-26 20:21:49 --> URI Class Initialized
DEBUG - 2011-09-26 20:21:49 --> Router Class Initialized
ERROR - 2011-09-26 20:21:49 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-09-26 21:55:24 --> Config Class Initialized
DEBUG - 2011-09-26 21:55:24 --> Hooks Class Initialized
DEBUG - 2011-09-26 21:55:24 --> Utf8 Class Initialized
DEBUG - 2011-09-26 21:55:24 --> UTF-8 Support Enabled
DEBUG - 2011-09-26 21:55:24 --> URI Class Initialized
DEBUG - 2011-09-26 21:55:24 --> Router Class Initialized
DEBUG - 2011-09-26 21:55:24 --> No URI present. Default controller set.
DEBUG - 2011-09-26 21:55:24 --> Output Class Initialized
DEBUG - 2011-09-26 21:55:24 --> Input Class Initialized
DEBUG - 2011-09-26 21:55:24 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-26 21:55:24 --> Language Class Initialized
DEBUG - 2011-09-26 21:55:24 --> Loader Class Initialized
DEBUG - 2011-09-26 21:55:24 --> Controller Class Initialized
DEBUG - 2011-09-26 21:55:24 --> File loaded: application/views/splash/main.php
DEBUG - 2011-09-26 21:55:24 --> Helper loaded: url_helper
DEBUG - 2011-09-26 21:55:24 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-26 21:55:24 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-26 21:55:24 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-26 21:55:24 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-26 21:55:24 --> Final output sent to browser
DEBUG - 2011-09-26 21:55:24 --> Total execution time: 0.1515
DEBUG - 2011-09-26 23:30:22 --> Config Class Initialized
DEBUG - 2011-09-26 23:30:22 --> Hooks Class Initialized
DEBUG - 2011-09-26 23:30:22 --> Utf8 Class Initialized
DEBUG - 2011-09-26 23:30:22 --> UTF-8 Support Enabled
DEBUG - 2011-09-26 23:30:22 --> URI Class Initialized
DEBUG - 2011-09-26 23:30:22 --> Router Class Initialized
ERROR - 2011-09-26 23:30:22 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-09-26 23:30:22 --> Config Class Initialized
DEBUG - 2011-09-26 23:30:22 --> Hooks Class Initialized
DEBUG - 2011-09-26 23:30:22 --> Utf8 Class Initialized
DEBUG - 2011-09-26 23:30:22 --> UTF-8 Support Enabled
DEBUG - 2011-09-26 23:30:22 --> URI Class Initialized
DEBUG - 2011-09-26 23:30:22 --> Router Class Initialized
DEBUG - 2011-09-26 23:30:22 --> No URI present. Default controller set.
DEBUG - 2011-09-26 23:30:22 --> Output Class Initialized
DEBUG - 2011-09-26 23:30:22 --> Input Class Initialized
DEBUG - 2011-09-26 23:30:22 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-26 23:30:22 --> Language Class Initialized
DEBUG - 2011-09-26 23:30:22 --> Loader Class Initialized
DEBUG - 2011-09-26 23:30:22 --> Controller Class Initialized
DEBUG - 2011-09-26 23:30:22 --> File loaded: application/views/splash/main.php
DEBUG - 2011-09-26 23:30:22 --> Helper loaded: url_helper
DEBUG - 2011-09-26 23:30:22 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-26 23:30:22 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-26 23:30:22 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-26 23:30:22 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-26 23:30:22 --> Final output sent to browser
DEBUG - 2011-09-26 23:30:22 --> Total execution time: 0.0332

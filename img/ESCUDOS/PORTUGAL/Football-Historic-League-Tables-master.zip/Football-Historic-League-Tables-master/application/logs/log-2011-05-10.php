<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2011-05-10 03:57:21 --> Config Class Initialized
DEBUG - 2011-05-10 03:57:21 --> Hooks Class Initialized
DEBUG - 2011-05-10 03:57:21 --> Utf8 Class Initialized
DEBUG - 2011-05-10 03:57:21 --> UTF-8 Support Enabled
DEBUG - 2011-05-10 03:57:21 --> URI Class Initialized
DEBUG - 2011-05-10 03:57:21 --> Router Class Initialized
ERROR - 2011-05-10 03:57:21 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-05-10 06:24:32 --> Config Class Initialized
DEBUG - 2011-05-10 06:24:32 --> Hooks Class Initialized
DEBUG - 2011-05-10 06:24:32 --> Utf8 Class Initialized
DEBUG - 2011-05-10 06:24:32 --> UTF-8 Support Enabled
DEBUG - 2011-05-10 06:24:32 --> URI Class Initialized
DEBUG - 2011-05-10 06:24:32 --> Router Class Initialized
DEBUG - 2011-05-10 06:24:32 --> Output Class Initialized
DEBUG - 2011-05-10 06:24:32 --> Input Class Initialized
DEBUG - 2011-05-10 06:24:32 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-10 06:24:32 --> Language Class Initialized
DEBUG - 2011-05-10 06:24:32 --> Loader Class Initialized
DEBUG - 2011-05-10 06:24:32 --> Controller Class Initialized
ERROR - 2011-05-10 06:24:32 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-10 06:24:32 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-10 06:24:32 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-10 06:24:32 --> Model Class Initialized
DEBUG - 2011-05-10 06:24:32 --> Model Class Initialized
DEBUG - 2011-05-10 06:24:32 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-10 06:24:32 --> Database Driver Class Initialized
DEBUG - 2011-05-10 06:24:33 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-10 06:24:33 --> Helper loaded: url_helper
DEBUG - 2011-05-10 06:24:33 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-10 06:24:33 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-10 06:24:33 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-10 06:24:33 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-10 06:24:33 --> Final output sent to browser
DEBUG - 2011-05-10 06:24:33 --> Total execution time: 0.9646
DEBUG - 2011-05-10 06:24:34 --> Config Class Initialized
DEBUG - 2011-05-10 06:24:34 --> Hooks Class Initialized
DEBUG - 2011-05-10 06:24:34 --> Utf8 Class Initialized
DEBUG - 2011-05-10 06:24:34 --> UTF-8 Support Enabled
DEBUG - 2011-05-10 06:24:34 --> URI Class Initialized
DEBUG - 2011-05-10 06:24:34 --> Router Class Initialized
DEBUG - 2011-05-10 06:24:34 --> Output Class Initialized
DEBUG - 2011-05-10 06:24:34 --> Input Class Initialized
DEBUG - 2011-05-10 06:24:34 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-10 06:24:34 --> Language Class Initialized
DEBUG - 2011-05-10 06:24:34 --> Loader Class Initialized
DEBUG - 2011-05-10 06:24:34 --> Controller Class Initialized
DEBUG - 2011-05-10 06:24:34 --> Model Class Initialized
DEBUG - 2011-05-10 06:24:34 --> Model Class Initialized
DEBUG - 2011-05-10 06:24:34 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-10 06:24:34 --> Database Driver Class Initialized
DEBUG - 2011-05-10 06:24:35 --> Config Class Initialized
DEBUG - 2011-05-10 06:24:35 --> Hooks Class Initialized
DEBUG - 2011-05-10 06:24:35 --> Utf8 Class Initialized
DEBUG - 2011-05-10 06:24:35 --> UTF-8 Support Enabled
DEBUG - 2011-05-10 06:24:35 --> URI Class Initialized
DEBUG - 2011-05-10 06:24:35 --> Router Class Initialized
DEBUG - 2011-05-10 06:24:35 --> Output Class Initialized
DEBUG - 2011-05-10 06:24:35 --> Input Class Initialized
DEBUG - 2011-05-10 06:24:35 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-10 06:24:35 --> Language Class Initialized
DEBUG - 2011-05-10 06:24:35 --> Loader Class Initialized
DEBUG - 2011-05-10 06:24:35 --> Controller Class Initialized
DEBUG - 2011-05-10 06:24:35 --> Final output sent to browser
DEBUG - 2011-05-10 06:24:35 --> Total execution time: 1.2741
ERROR - 2011-05-10 06:24:35 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-10 06:24:35 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-10 06:24:35 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-10 06:24:35 --> Model Class Initialized
DEBUG - 2011-05-10 06:24:35 --> Model Class Initialized
DEBUG - 2011-05-10 06:24:35 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-10 06:24:35 --> Database Driver Class Initialized
DEBUG - 2011-05-10 06:24:35 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-10 06:24:35 --> Helper loaded: url_helper
DEBUG - 2011-05-10 06:24:35 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-10 06:24:35 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-10 06:24:35 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-10 06:24:35 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-10 06:24:35 --> Final output sent to browser
DEBUG - 2011-05-10 06:24:35 --> Total execution time: 0.2231
DEBUG - 2011-05-10 06:24:36 --> Config Class Initialized
DEBUG - 2011-05-10 06:24:36 --> Hooks Class Initialized
DEBUG - 2011-05-10 06:24:36 --> Utf8 Class Initialized
DEBUG - 2011-05-10 06:24:36 --> UTF-8 Support Enabled
DEBUG - 2011-05-10 06:24:36 --> URI Class Initialized
DEBUG - 2011-05-10 06:24:36 --> Router Class Initialized
ERROR - 2011-05-10 06:24:36 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-10 06:24:37 --> Config Class Initialized
DEBUG - 2011-05-10 06:24:37 --> Hooks Class Initialized
DEBUG - 2011-05-10 06:24:37 --> Utf8 Class Initialized
DEBUG - 2011-05-10 06:24:37 --> UTF-8 Support Enabled
DEBUG - 2011-05-10 06:24:37 --> URI Class Initialized
DEBUG - 2011-05-10 06:24:37 --> Router Class Initialized
ERROR - 2011-05-10 06:24:37 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-10 06:24:37 --> Config Class Initialized
DEBUG - 2011-05-10 06:24:37 --> Hooks Class Initialized
DEBUG - 2011-05-10 06:24:37 --> Utf8 Class Initialized
DEBUG - 2011-05-10 06:24:37 --> UTF-8 Support Enabled
DEBUG - 2011-05-10 06:24:37 --> URI Class Initialized
DEBUG - 2011-05-10 06:24:37 --> Router Class Initialized
ERROR - 2011-05-10 06:24:37 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-10 06:24:48 --> Config Class Initialized
DEBUG - 2011-05-10 06:24:48 --> Hooks Class Initialized
DEBUG - 2011-05-10 06:24:48 --> Utf8 Class Initialized
DEBUG - 2011-05-10 06:24:48 --> UTF-8 Support Enabled
DEBUG - 2011-05-10 06:24:48 --> URI Class Initialized
DEBUG - 2011-05-10 06:24:48 --> Router Class Initialized
DEBUG - 2011-05-10 06:24:48 --> Output Class Initialized
DEBUG - 2011-05-10 06:24:48 --> Input Class Initialized
DEBUG - 2011-05-10 06:24:48 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-10 06:24:48 --> Language Class Initialized
DEBUG - 2011-05-10 06:24:48 --> Loader Class Initialized
DEBUG - 2011-05-10 06:24:48 --> Controller Class Initialized
ERROR - 2011-05-10 06:24:48 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-10 06:24:48 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-10 06:24:48 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-10 06:24:48 --> Model Class Initialized
DEBUG - 2011-05-10 06:24:48 --> Model Class Initialized
DEBUG - 2011-05-10 06:24:48 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-10 06:24:48 --> Database Driver Class Initialized
DEBUG - 2011-05-10 06:24:48 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-10 06:24:48 --> Helper loaded: url_helper
DEBUG - 2011-05-10 06:24:48 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-10 06:24:48 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-10 06:24:48 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-10 06:24:48 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-10 06:24:48 --> Final output sent to browser
DEBUG - 2011-05-10 06:24:48 --> Total execution time: 0.2087
DEBUG - 2011-05-10 06:24:49 --> Config Class Initialized
DEBUG - 2011-05-10 06:24:49 --> Hooks Class Initialized
DEBUG - 2011-05-10 06:24:49 --> Utf8 Class Initialized
DEBUG - 2011-05-10 06:24:49 --> UTF-8 Support Enabled
DEBUG - 2011-05-10 06:24:49 --> URI Class Initialized
DEBUG - 2011-05-10 06:24:49 --> Router Class Initialized
DEBUG - 2011-05-10 06:24:49 --> Output Class Initialized
DEBUG - 2011-05-10 06:24:49 --> Input Class Initialized
DEBUG - 2011-05-10 06:24:49 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-10 06:24:49 --> Language Class Initialized
DEBUG - 2011-05-10 06:24:49 --> Loader Class Initialized
DEBUG - 2011-05-10 06:24:49 --> Controller Class Initialized
DEBUG - 2011-05-10 06:24:49 --> Model Class Initialized
DEBUG - 2011-05-10 06:24:49 --> Model Class Initialized
DEBUG - 2011-05-10 06:24:49 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-10 06:24:49 --> Database Driver Class Initialized
DEBUG - 2011-05-10 06:24:50 --> Final output sent to browser
DEBUG - 2011-05-10 06:24:50 --> Total execution time: 0.7445
DEBUG - 2011-05-10 06:32:23 --> Config Class Initialized
DEBUG - 2011-05-10 06:32:23 --> Hooks Class Initialized
DEBUG - 2011-05-10 06:32:23 --> Utf8 Class Initialized
DEBUG - 2011-05-10 06:32:23 --> UTF-8 Support Enabled
DEBUG - 2011-05-10 06:32:23 --> URI Class Initialized
DEBUG - 2011-05-10 06:32:23 --> Router Class Initialized
DEBUG - 2011-05-10 06:32:24 --> Output Class Initialized
DEBUG - 2011-05-10 06:32:24 --> Input Class Initialized
DEBUG - 2011-05-10 06:32:24 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-10 06:32:24 --> Language Class Initialized
DEBUG - 2011-05-10 06:32:24 --> Loader Class Initialized
DEBUG - 2011-05-10 06:32:24 --> Controller Class Initialized
DEBUG - 2011-05-10 06:32:24 --> Model Class Initialized
DEBUG - 2011-05-10 06:32:24 --> Model Class Initialized
DEBUG - 2011-05-10 06:32:24 --> Model Class Initialized
DEBUG - 2011-05-10 06:32:24 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-10 06:32:24 --> Database Driver Class Initialized
DEBUG - 2011-05-10 06:32:27 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-10 06:32:27 --> Helper loaded: url_helper
DEBUG - 2011-05-10 06:32:27 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-10 06:32:27 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-10 06:32:27 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-10 06:32:27 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-10 06:32:27 --> Final output sent to browser
DEBUG - 2011-05-10 06:32:27 --> Total execution time: 4.5744
DEBUG - 2011-05-10 06:32:30 --> Config Class Initialized
DEBUG - 2011-05-10 06:32:30 --> Hooks Class Initialized
DEBUG - 2011-05-10 06:32:30 --> Utf8 Class Initialized
DEBUG - 2011-05-10 06:32:30 --> UTF-8 Support Enabled
DEBUG - 2011-05-10 06:32:30 --> URI Class Initialized
DEBUG - 2011-05-10 06:32:30 --> Router Class Initialized
ERROR - 2011-05-10 06:32:30 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-10 06:32:30 --> Config Class Initialized
DEBUG - 2011-05-10 06:32:30 --> Hooks Class Initialized
DEBUG - 2011-05-10 06:32:30 --> Utf8 Class Initialized
DEBUG - 2011-05-10 06:32:30 --> UTF-8 Support Enabled
DEBUG - 2011-05-10 06:32:30 --> URI Class Initialized
DEBUG - 2011-05-10 06:32:30 --> Router Class Initialized
ERROR - 2011-05-10 06:32:30 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-10 06:32:42 --> Config Class Initialized
DEBUG - 2011-05-10 06:32:42 --> Hooks Class Initialized
DEBUG - 2011-05-10 06:32:42 --> Utf8 Class Initialized
DEBUG - 2011-05-10 06:32:42 --> UTF-8 Support Enabled
DEBUG - 2011-05-10 06:32:42 --> URI Class Initialized
DEBUG - 2011-05-10 06:32:42 --> Router Class Initialized
DEBUG - 2011-05-10 06:32:42 --> Output Class Initialized
DEBUG - 2011-05-10 06:32:42 --> Input Class Initialized
DEBUG - 2011-05-10 06:32:42 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-10 06:32:42 --> Language Class Initialized
DEBUG - 2011-05-10 06:32:42 --> Loader Class Initialized
DEBUG - 2011-05-10 06:32:42 --> Controller Class Initialized
DEBUG - 2011-05-10 06:32:42 --> Model Class Initialized
DEBUG - 2011-05-10 06:32:42 --> Model Class Initialized
DEBUG - 2011-05-10 06:32:42 --> Model Class Initialized
DEBUG - 2011-05-10 06:32:42 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-10 06:32:42 --> Database Driver Class Initialized
DEBUG - 2011-05-10 06:32:42 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-10 06:32:42 --> Helper loaded: url_helper
DEBUG - 2011-05-10 06:32:42 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-10 06:32:42 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-10 06:32:42 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-10 06:32:42 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-10 06:32:42 --> Final output sent to browser
DEBUG - 2011-05-10 06:32:42 --> Total execution time: 0.6954
DEBUG - 2011-05-10 06:33:02 --> Config Class Initialized
DEBUG - 2011-05-10 06:33:02 --> Hooks Class Initialized
DEBUG - 2011-05-10 06:33:02 --> Utf8 Class Initialized
DEBUG - 2011-05-10 06:33:02 --> UTF-8 Support Enabled
DEBUG - 2011-05-10 06:33:02 --> URI Class Initialized
DEBUG - 2011-05-10 06:33:02 --> Router Class Initialized
DEBUG - 2011-05-10 06:33:02 --> Output Class Initialized
DEBUG - 2011-05-10 06:33:02 --> Input Class Initialized
DEBUG - 2011-05-10 06:33:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-10 06:33:02 --> Language Class Initialized
DEBUG - 2011-05-10 06:33:02 --> Loader Class Initialized
DEBUG - 2011-05-10 06:33:02 --> Controller Class Initialized
DEBUG - 2011-05-10 06:33:02 --> Model Class Initialized
DEBUG - 2011-05-10 06:33:02 --> Model Class Initialized
DEBUG - 2011-05-10 06:33:02 --> Model Class Initialized
DEBUG - 2011-05-10 06:33:02 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-10 06:33:02 --> Database Driver Class Initialized
DEBUG - 2011-05-10 06:33:03 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-10 06:33:03 --> Helper loaded: url_helper
DEBUG - 2011-05-10 06:33:03 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-10 06:33:03 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-10 06:33:03 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-10 06:33:03 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-10 06:33:03 --> Final output sent to browser
DEBUG - 2011-05-10 06:33:03 --> Total execution time: 0.5882
DEBUG - 2011-05-10 06:33:37 --> Config Class Initialized
DEBUG - 2011-05-10 06:33:37 --> Hooks Class Initialized
DEBUG - 2011-05-10 06:33:37 --> Utf8 Class Initialized
DEBUG - 2011-05-10 06:33:37 --> UTF-8 Support Enabled
DEBUG - 2011-05-10 06:33:37 --> URI Class Initialized
DEBUG - 2011-05-10 06:33:37 --> Router Class Initialized
DEBUG - 2011-05-10 06:33:37 --> Output Class Initialized
DEBUG - 2011-05-10 06:33:37 --> Input Class Initialized
DEBUG - 2011-05-10 06:33:37 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-10 06:33:37 --> Language Class Initialized
DEBUG - 2011-05-10 06:33:37 --> Loader Class Initialized
DEBUG - 2011-05-10 06:33:37 --> Controller Class Initialized
DEBUG - 2011-05-10 06:33:37 --> Model Class Initialized
DEBUG - 2011-05-10 06:33:37 --> Model Class Initialized
DEBUG - 2011-05-10 06:33:37 --> Model Class Initialized
DEBUG - 2011-05-10 06:33:37 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-10 06:33:37 --> Database Driver Class Initialized
DEBUG - 2011-05-10 06:33:38 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-10 06:33:38 --> Helper loaded: url_helper
DEBUG - 2011-05-10 06:33:38 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-10 06:33:38 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-10 06:33:38 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-10 06:33:38 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-10 06:33:38 --> Final output sent to browser
DEBUG - 2011-05-10 06:33:38 --> Total execution time: 1.3298
DEBUG - 2011-05-10 06:34:00 --> Config Class Initialized
DEBUG - 2011-05-10 06:34:00 --> Hooks Class Initialized
DEBUG - 2011-05-10 06:34:00 --> Utf8 Class Initialized
DEBUG - 2011-05-10 06:34:00 --> UTF-8 Support Enabled
DEBUG - 2011-05-10 06:34:00 --> URI Class Initialized
DEBUG - 2011-05-10 06:34:00 --> Router Class Initialized
DEBUG - 2011-05-10 06:34:00 --> Output Class Initialized
DEBUG - 2011-05-10 06:34:00 --> Input Class Initialized
DEBUG - 2011-05-10 06:34:00 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-10 06:34:00 --> Language Class Initialized
DEBUG - 2011-05-10 06:34:00 --> Loader Class Initialized
DEBUG - 2011-05-10 06:34:00 --> Controller Class Initialized
DEBUG - 2011-05-10 06:34:00 --> Model Class Initialized
DEBUG - 2011-05-10 06:34:00 --> Model Class Initialized
DEBUG - 2011-05-10 06:34:00 --> Model Class Initialized
DEBUG - 2011-05-10 06:34:00 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-10 06:34:00 --> Database Driver Class Initialized
DEBUG - 2011-05-10 06:34:00 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-10 06:34:00 --> Helper loaded: url_helper
DEBUG - 2011-05-10 06:34:00 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-10 06:34:00 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-10 06:34:00 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-10 06:34:00 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-10 06:34:00 --> Final output sent to browser
DEBUG - 2011-05-10 06:34:00 --> Total execution time: 0.2497
DEBUG - 2011-05-10 06:34:12 --> Config Class Initialized
DEBUG - 2011-05-10 06:34:12 --> Hooks Class Initialized
DEBUG - 2011-05-10 06:34:12 --> Utf8 Class Initialized
DEBUG - 2011-05-10 06:34:12 --> UTF-8 Support Enabled
DEBUG - 2011-05-10 06:34:12 --> URI Class Initialized
DEBUG - 2011-05-10 06:34:12 --> Router Class Initialized
DEBUG - 2011-05-10 06:34:12 --> Output Class Initialized
DEBUG - 2011-05-10 06:34:12 --> Input Class Initialized
DEBUG - 2011-05-10 06:34:12 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-10 06:34:12 --> Language Class Initialized
DEBUG - 2011-05-10 06:34:12 --> Loader Class Initialized
DEBUG - 2011-05-10 06:34:12 --> Controller Class Initialized
DEBUG - 2011-05-10 06:34:12 --> Model Class Initialized
DEBUG - 2011-05-10 06:34:12 --> Model Class Initialized
DEBUG - 2011-05-10 06:34:12 --> Model Class Initialized
DEBUG - 2011-05-10 06:34:12 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-10 06:34:12 --> Database Driver Class Initialized
DEBUG - 2011-05-10 06:34:12 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-10 06:34:12 --> Helper loaded: url_helper
DEBUG - 2011-05-10 06:34:12 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-10 06:34:12 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-10 06:34:12 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-10 06:34:12 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-10 06:34:12 --> Final output sent to browser
DEBUG - 2011-05-10 06:34:12 --> Total execution time: 0.1729
DEBUG - 2011-05-10 06:34:14 --> Config Class Initialized
DEBUG - 2011-05-10 06:34:14 --> Hooks Class Initialized
DEBUG - 2011-05-10 06:34:14 --> Utf8 Class Initialized
DEBUG - 2011-05-10 06:34:16 --> UTF-8 Support Enabled
DEBUG - 2011-05-10 06:34:16 --> URI Class Initialized
DEBUG - 2011-05-10 06:34:16 --> Router Class Initialized
DEBUG - 2011-05-10 06:34:16 --> Output Class Initialized
DEBUG - 2011-05-10 06:34:16 --> Input Class Initialized
DEBUG - 2011-05-10 06:34:16 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-10 06:34:16 --> Language Class Initialized
DEBUG - 2011-05-10 06:34:16 --> Loader Class Initialized
DEBUG - 2011-05-10 06:34:16 --> Controller Class Initialized
DEBUG - 2011-05-10 06:34:16 --> Model Class Initialized
DEBUG - 2011-05-10 06:34:16 --> Model Class Initialized
DEBUG - 2011-05-10 06:34:16 --> Model Class Initialized
DEBUG - 2011-05-10 06:34:16 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-10 06:34:16 --> Database Driver Class Initialized
DEBUG - 2011-05-10 06:34:16 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-10 06:34:16 --> Helper loaded: url_helper
DEBUG - 2011-05-10 06:34:16 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-10 06:34:16 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-10 06:34:16 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-10 06:34:16 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-10 06:34:16 --> Final output sent to browser
DEBUG - 2011-05-10 06:34:16 --> Total execution time: 1.8684
DEBUG - 2011-05-10 06:34:19 --> Config Class Initialized
DEBUG - 2011-05-10 06:34:19 --> Hooks Class Initialized
DEBUG - 2011-05-10 06:34:19 --> Utf8 Class Initialized
DEBUG - 2011-05-10 06:34:19 --> UTF-8 Support Enabled
DEBUG - 2011-05-10 06:34:19 --> URI Class Initialized
DEBUG - 2011-05-10 06:34:19 --> Router Class Initialized
DEBUG - 2011-05-10 06:34:19 --> Output Class Initialized
DEBUG - 2011-05-10 06:34:19 --> Input Class Initialized
DEBUG - 2011-05-10 06:34:19 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-10 06:34:19 --> Language Class Initialized
DEBUG - 2011-05-10 06:34:19 --> Loader Class Initialized
DEBUG - 2011-05-10 06:34:19 --> Controller Class Initialized
DEBUG - 2011-05-10 06:34:19 --> Model Class Initialized
DEBUG - 2011-05-10 06:34:19 --> Model Class Initialized
DEBUG - 2011-05-10 06:34:19 --> Model Class Initialized
DEBUG - 2011-05-10 06:34:19 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-10 06:34:19 --> Database Driver Class Initialized
DEBUG - 2011-05-10 06:34:19 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-10 06:34:19 --> Helper loaded: url_helper
DEBUG - 2011-05-10 06:34:19 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-10 06:34:19 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-10 06:34:19 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-10 06:34:19 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-10 06:34:19 --> Final output sent to browser
DEBUG - 2011-05-10 06:34:19 --> Total execution time: 0.8337
DEBUG - 2011-05-10 06:34:22 --> Config Class Initialized
DEBUG - 2011-05-10 06:34:22 --> Hooks Class Initialized
DEBUG - 2011-05-10 06:34:22 --> Utf8 Class Initialized
DEBUG - 2011-05-10 06:34:22 --> UTF-8 Support Enabled
DEBUG - 2011-05-10 06:34:22 --> URI Class Initialized
DEBUG - 2011-05-10 06:34:22 --> Router Class Initialized
DEBUG - 2011-05-10 06:34:22 --> Output Class Initialized
DEBUG - 2011-05-10 06:34:22 --> Input Class Initialized
DEBUG - 2011-05-10 06:34:22 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-10 06:34:22 --> Language Class Initialized
DEBUG - 2011-05-10 06:34:22 --> Loader Class Initialized
DEBUG - 2011-05-10 06:34:22 --> Controller Class Initialized
DEBUG - 2011-05-10 06:34:22 --> Model Class Initialized
DEBUG - 2011-05-10 06:34:22 --> Model Class Initialized
DEBUG - 2011-05-10 06:34:22 --> Model Class Initialized
DEBUG - 2011-05-10 06:34:22 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-10 06:34:22 --> Database Driver Class Initialized
DEBUG - 2011-05-10 06:34:22 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-10 06:34:22 --> Helper loaded: url_helper
DEBUG - 2011-05-10 06:34:22 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-10 06:34:22 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-10 06:34:22 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-10 06:34:22 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-10 06:34:22 --> Final output sent to browser
DEBUG - 2011-05-10 06:34:22 --> Total execution time: 0.0464
DEBUG - 2011-05-10 06:34:25 --> Config Class Initialized
DEBUG - 2011-05-10 06:34:25 --> Hooks Class Initialized
DEBUG - 2011-05-10 06:34:25 --> Utf8 Class Initialized
DEBUG - 2011-05-10 06:34:25 --> UTF-8 Support Enabled
DEBUG - 2011-05-10 06:34:25 --> URI Class Initialized
DEBUG - 2011-05-10 06:34:25 --> Router Class Initialized
DEBUG - 2011-05-10 06:34:25 --> Output Class Initialized
DEBUG - 2011-05-10 06:34:25 --> Input Class Initialized
DEBUG - 2011-05-10 06:34:25 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-10 06:34:25 --> Language Class Initialized
DEBUG - 2011-05-10 06:34:25 --> Loader Class Initialized
DEBUG - 2011-05-10 06:34:25 --> Controller Class Initialized
DEBUG - 2011-05-10 06:34:25 --> Model Class Initialized
DEBUG - 2011-05-10 06:34:25 --> Model Class Initialized
DEBUG - 2011-05-10 06:34:25 --> Model Class Initialized
DEBUG - 2011-05-10 06:34:25 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-10 06:34:25 --> Database Driver Class Initialized
DEBUG - 2011-05-10 06:34:25 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-10 06:34:25 --> Helper loaded: url_helper
DEBUG - 2011-05-10 06:34:25 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-10 06:34:25 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-10 06:34:25 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-10 06:34:25 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-10 06:34:25 --> Final output sent to browser
DEBUG - 2011-05-10 06:34:25 --> Total execution time: 0.1342
DEBUG - 2011-05-10 06:34:26 --> Config Class Initialized
DEBUG - 2011-05-10 06:34:26 --> Hooks Class Initialized
DEBUG - 2011-05-10 06:34:26 --> Utf8 Class Initialized
DEBUG - 2011-05-10 06:34:26 --> UTF-8 Support Enabled
DEBUG - 2011-05-10 06:34:26 --> URI Class Initialized
DEBUG - 2011-05-10 06:34:26 --> Router Class Initialized
DEBUG - 2011-05-10 06:34:26 --> Output Class Initialized
DEBUG - 2011-05-10 06:34:26 --> Input Class Initialized
DEBUG - 2011-05-10 06:34:26 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-10 06:34:26 --> Language Class Initialized
DEBUG - 2011-05-10 06:34:26 --> Loader Class Initialized
DEBUG - 2011-05-10 06:34:26 --> Controller Class Initialized
DEBUG - 2011-05-10 06:34:26 --> Model Class Initialized
DEBUG - 2011-05-10 06:34:26 --> Model Class Initialized
DEBUG - 2011-05-10 06:34:26 --> Model Class Initialized
DEBUG - 2011-05-10 06:34:26 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-10 06:34:26 --> Database Driver Class Initialized
DEBUG - 2011-05-10 06:34:26 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-10 06:34:26 --> Helper loaded: url_helper
DEBUG - 2011-05-10 06:34:26 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-10 06:34:26 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-10 06:34:26 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-10 06:34:26 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-10 06:34:26 --> Final output sent to browser
DEBUG - 2011-05-10 06:34:26 --> Total execution time: 0.0544
DEBUG - 2011-05-10 06:34:35 --> Config Class Initialized
DEBUG - 2011-05-10 06:34:35 --> Hooks Class Initialized
DEBUG - 2011-05-10 06:34:35 --> Utf8 Class Initialized
DEBUG - 2011-05-10 06:34:35 --> UTF-8 Support Enabled
DEBUG - 2011-05-10 06:34:35 --> URI Class Initialized
DEBUG - 2011-05-10 06:34:35 --> Router Class Initialized
DEBUG - 2011-05-10 06:34:35 --> Output Class Initialized
DEBUG - 2011-05-10 06:34:35 --> Input Class Initialized
DEBUG - 2011-05-10 06:34:35 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-10 06:34:35 --> Language Class Initialized
DEBUG - 2011-05-10 06:34:35 --> Loader Class Initialized
DEBUG - 2011-05-10 06:34:35 --> Controller Class Initialized
DEBUG - 2011-05-10 06:34:35 --> Model Class Initialized
DEBUG - 2011-05-10 06:34:35 --> Model Class Initialized
DEBUG - 2011-05-10 06:34:35 --> Model Class Initialized
DEBUG - 2011-05-10 06:34:35 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-10 06:34:35 --> Database Driver Class Initialized
DEBUG - 2011-05-10 06:34:36 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-10 06:34:36 --> Helper loaded: url_helper
DEBUG - 2011-05-10 06:34:36 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-10 06:34:36 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-10 06:34:36 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-10 06:34:36 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-10 06:34:36 --> Final output sent to browser
DEBUG - 2011-05-10 06:34:36 --> Total execution time: 0.5891
DEBUG - 2011-05-10 06:34:38 --> Config Class Initialized
DEBUG - 2011-05-10 06:34:38 --> Hooks Class Initialized
DEBUG - 2011-05-10 06:34:38 --> Utf8 Class Initialized
DEBUG - 2011-05-10 06:34:38 --> UTF-8 Support Enabled
DEBUG - 2011-05-10 06:34:38 --> URI Class Initialized
DEBUG - 2011-05-10 06:34:38 --> Router Class Initialized
DEBUG - 2011-05-10 06:34:38 --> Output Class Initialized
DEBUG - 2011-05-10 06:34:38 --> Input Class Initialized
DEBUG - 2011-05-10 06:34:38 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-10 06:34:38 --> Language Class Initialized
DEBUG - 2011-05-10 06:34:38 --> Loader Class Initialized
DEBUG - 2011-05-10 06:34:38 --> Controller Class Initialized
DEBUG - 2011-05-10 06:34:38 --> Model Class Initialized
DEBUG - 2011-05-10 06:34:38 --> Model Class Initialized
DEBUG - 2011-05-10 06:34:38 --> Model Class Initialized
DEBUG - 2011-05-10 06:34:38 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-10 06:34:38 --> Database Driver Class Initialized
DEBUG - 2011-05-10 06:34:38 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-10 06:34:39 --> Helper loaded: url_helper
DEBUG - 2011-05-10 06:34:39 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-10 06:34:39 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-10 06:34:39 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-10 06:34:39 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-10 06:34:39 --> Final output sent to browser
DEBUG - 2011-05-10 06:34:39 --> Total execution time: 1.6345
DEBUG - 2011-05-10 06:34:48 --> Config Class Initialized
DEBUG - 2011-05-10 06:34:48 --> Hooks Class Initialized
DEBUG - 2011-05-10 06:34:48 --> Utf8 Class Initialized
DEBUG - 2011-05-10 06:34:48 --> UTF-8 Support Enabled
DEBUG - 2011-05-10 06:34:48 --> URI Class Initialized
DEBUG - 2011-05-10 06:34:48 --> Router Class Initialized
DEBUG - 2011-05-10 06:34:48 --> Output Class Initialized
DEBUG - 2011-05-10 06:34:48 --> Input Class Initialized
DEBUG - 2011-05-10 06:34:48 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-10 06:34:48 --> Language Class Initialized
DEBUG - 2011-05-10 06:34:48 --> Loader Class Initialized
DEBUG - 2011-05-10 06:34:48 --> Controller Class Initialized
DEBUG - 2011-05-10 06:34:48 --> Model Class Initialized
DEBUG - 2011-05-10 06:34:48 --> Model Class Initialized
DEBUG - 2011-05-10 06:34:48 --> Model Class Initialized
DEBUG - 2011-05-10 06:34:48 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-10 06:34:48 --> Database Driver Class Initialized
DEBUG - 2011-05-10 06:34:48 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-10 06:34:48 --> Helper loaded: url_helper
DEBUG - 2011-05-10 06:34:48 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-10 06:34:48 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-10 06:34:48 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-10 06:34:48 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-10 06:34:48 --> Final output sent to browser
DEBUG - 2011-05-10 06:34:48 --> Total execution time: 0.0908
DEBUG - 2011-05-10 06:34:58 --> Config Class Initialized
DEBUG - 2011-05-10 06:34:58 --> Hooks Class Initialized
DEBUG - 2011-05-10 06:34:58 --> Utf8 Class Initialized
DEBUG - 2011-05-10 06:34:58 --> UTF-8 Support Enabled
DEBUG - 2011-05-10 06:34:58 --> URI Class Initialized
DEBUG - 2011-05-10 06:34:58 --> Router Class Initialized
DEBUG - 2011-05-10 06:34:58 --> Output Class Initialized
DEBUG - 2011-05-10 06:34:58 --> Input Class Initialized
DEBUG - 2011-05-10 06:34:58 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-10 06:34:58 --> Language Class Initialized
DEBUG - 2011-05-10 06:34:58 --> Loader Class Initialized
DEBUG - 2011-05-10 06:34:58 --> Controller Class Initialized
DEBUG - 2011-05-10 06:34:58 --> Model Class Initialized
DEBUG - 2011-05-10 06:34:58 --> Model Class Initialized
DEBUG - 2011-05-10 06:34:58 --> Model Class Initialized
DEBUG - 2011-05-10 06:34:58 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-10 06:34:58 --> Database Driver Class Initialized
DEBUG - 2011-05-10 06:34:58 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-10 06:34:58 --> Helper loaded: url_helper
DEBUG - 2011-05-10 06:34:58 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-10 06:34:58 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-10 06:34:58 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-10 06:34:58 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-10 06:34:58 --> Final output sent to browser
DEBUG - 2011-05-10 06:34:58 --> Total execution time: 0.0757
DEBUG - 2011-05-10 06:35:08 --> Config Class Initialized
DEBUG - 2011-05-10 06:35:08 --> Hooks Class Initialized
DEBUG - 2011-05-10 06:35:08 --> Utf8 Class Initialized
DEBUG - 2011-05-10 06:35:08 --> UTF-8 Support Enabled
DEBUG - 2011-05-10 06:35:08 --> URI Class Initialized
DEBUG - 2011-05-10 06:35:08 --> Router Class Initialized
DEBUG - 2011-05-10 06:35:08 --> Output Class Initialized
DEBUG - 2011-05-10 06:35:08 --> Input Class Initialized
DEBUG - 2011-05-10 06:35:08 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-10 06:35:08 --> Language Class Initialized
DEBUG - 2011-05-10 06:35:08 --> Loader Class Initialized
DEBUG - 2011-05-10 06:35:08 --> Controller Class Initialized
DEBUG - 2011-05-10 06:35:08 --> Model Class Initialized
DEBUG - 2011-05-10 06:35:08 --> Model Class Initialized
DEBUG - 2011-05-10 06:35:08 --> Model Class Initialized
DEBUG - 2011-05-10 06:35:08 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-10 06:35:08 --> Database Driver Class Initialized
DEBUG - 2011-05-10 06:35:09 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-10 06:35:09 --> Helper loaded: url_helper
DEBUG - 2011-05-10 06:35:09 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-10 06:35:09 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-10 06:35:09 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-10 06:35:09 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-10 06:35:09 --> Final output sent to browser
DEBUG - 2011-05-10 06:35:09 --> Total execution time: 0.6461
DEBUG - 2011-05-10 06:35:30 --> Config Class Initialized
DEBUG - 2011-05-10 06:35:30 --> Hooks Class Initialized
DEBUG - 2011-05-10 06:35:30 --> Utf8 Class Initialized
DEBUG - 2011-05-10 06:35:30 --> UTF-8 Support Enabled
DEBUG - 2011-05-10 06:35:30 --> URI Class Initialized
DEBUG - 2011-05-10 06:35:30 --> Router Class Initialized
DEBUG - 2011-05-10 06:35:30 --> Output Class Initialized
DEBUG - 2011-05-10 06:35:30 --> Input Class Initialized
DEBUG - 2011-05-10 06:35:30 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-10 06:35:30 --> Language Class Initialized
DEBUG - 2011-05-10 06:35:30 --> Loader Class Initialized
DEBUG - 2011-05-10 06:35:30 --> Controller Class Initialized
DEBUG - 2011-05-10 06:35:30 --> Model Class Initialized
DEBUG - 2011-05-10 06:35:30 --> Model Class Initialized
DEBUG - 2011-05-10 06:35:30 --> Model Class Initialized
DEBUG - 2011-05-10 06:35:30 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-10 06:35:30 --> Database Driver Class Initialized
DEBUG - 2011-05-10 06:35:30 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-10 06:35:30 --> Helper loaded: url_helper
DEBUG - 2011-05-10 06:35:30 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-10 06:35:30 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-10 06:35:30 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-10 06:35:30 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-10 06:35:30 --> Final output sent to browser
DEBUG - 2011-05-10 06:35:30 --> Total execution time: 0.1749
DEBUG - 2011-05-10 06:35:38 --> Config Class Initialized
DEBUG - 2011-05-10 06:35:38 --> Hooks Class Initialized
DEBUG - 2011-05-10 06:35:38 --> Utf8 Class Initialized
DEBUG - 2011-05-10 06:35:38 --> UTF-8 Support Enabled
DEBUG - 2011-05-10 06:35:38 --> URI Class Initialized
DEBUG - 2011-05-10 06:35:38 --> Router Class Initialized
DEBUG - 2011-05-10 06:35:38 --> Output Class Initialized
DEBUG - 2011-05-10 06:35:38 --> Input Class Initialized
DEBUG - 2011-05-10 06:35:38 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-10 06:35:38 --> Language Class Initialized
DEBUG - 2011-05-10 06:35:38 --> Loader Class Initialized
DEBUG - 2011-05-10 06:35:38 --> Controller Class Initialized
DEBUG - 2011-05-10 06:35:38 --> Model Class Initialized
DEBUG - 2011-05-10 06:35:38 --> Model Class Initialized
DEBUG - 2011-05-10 06:35:38 --> Model Class Initialized
DEBUG - 2011-05-10 06:35:38 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-10 06:35:38 --> Database Driver Class Initialized
DEBUG - 2011-05-10 06:35:44 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-10 06:35:44 --> Helper loaded: url_helper
DEBUG - 2011-05-10 06:35:44 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-10 06:35:44 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-10 06:35:44 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-10 06:35:44 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-10 06:35:44 --> Final output sent to browser
DEBUG - 2011-05-10 06:35:44 --> Total execution time: 5.6724
DEBUG - 2011-05-10 06:36:01 --> Config Class Initialized
DEBUG - 2011-05-10 06:36:01 --> Hooks Class Initialized
DEBUG - 2011-05-10 06:36:01 --> Utf8 Class Initialized
DEBUG - 2011-05-10 06:36:01 --> UTF-8 Support Enabled
DEBUG - 2011-05-10 06:36:01 --> URI Class Initialized
DEBUG - 2011-05-10 06:36:01 --> Router Class Initialized
DEBUG - 2011-05-10 06:36:01 --> Output Class Initialized
DEBUG - 2011-05-10 06:36:01 --> Input Class Initialized
DEBUG - 2011-05-10 06:36:01 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-10 06:36:01 --> Language Class Initialized
DEBUG - 2011-05-10 06:36:01 --> Loader Class Initialized
DEBUG - 2011-05-10 06:36:01 --> Controller Class Initialized
DEBUG - 2011-05-10 06:36:01 --> Model Class Initialized
DEBUG - 2011-05-10 06:36:01 --> Model Class Initialized
DEBUG - 2011-05-10 06:36:01 --> Model Class Initialized
DEBUG - 2011-05-10 06:36:01 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-10 06:36:01 --> Database Driver Class Initialized
DEBUG - 2011-05-10 06:36:02 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-10 06:36:02 --> Helper loaded: url_helper
DEBUG - 2011-05-10 06:36:02 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-10 06:36:02 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-10 06:36:02 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-10 06:36:02 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-10 06:36:02 --> Final output sent to browser
DEBUG - 2011-05-10 06:36:02 --> Total execution time: 1.6296
DEBUG - 2011-05-10 06:36:06 --> Config Class Initialized
DEBUG - 2011-05-10 06:36:06 --> Hooks Class Initialized
DEBUG - 2011-05-10 06:36:06 --> Utf8 Class Initialized
DEBUG - 2011-05-10 06:36:06 --> UTF-8 Support Enabled
DEBUG - 2011-05-10 06:36:06 --> URI Class Initialized
DEBUG - 2011-05-10 06:36:06 --> Router Class Initialized
DEBUG - 2011-05-10 06:36:06 --> Output Class Initialized
DEBUG - 2011-05-10 06:36:06 --> Input Class Initialized
DEBUG - 2011-05-10 06:36:06 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-10 06:36:06 --> Language Class Initialized
DEBUG - 2011-05-10 06:36:06 --> Loader Class Initialized
DEBUG - 2011-05-10 06:36:06 --> Controller Class Initialized
DEBUG - 2011-05-10 06:36:06 --> Model Class Initialized
DEBUG - 2011-05-10 06:36:06 --> Model Class Initialized
DEBUG - 2011-05-10 06:36:06 --> Model Class Initialized
DEBUG - 2011-05-10 06:36:06 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-10 06:36:06 --> Database Driver Class Initialized
DEBUG - 2011-05-10 06:36:06 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-10 06:36:06 --> Helper loaded: url_helper
DEBUG - 2011-05-10 06:36:06 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-10 06:36:06 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-10 06:36:06 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-10 06:36:06 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-10 06:36:06 --> Final output sent to browser
DEBUG - 2011-05-10 06:36:06 --> Total execution time: 0.2327
DEBUG - 2011-05-10 06:36:09 --> Config Class Initialized
DEBUG - 2011-05-10 06:36:09 --> Hooks Class Initialized
DEBUG - 2011-05-10 06:36:09 --> Utf8 Class Initialized
DEBUG - 2011-05-10 06:36:09 --> UTF-8 Support Enabled
DEBUG - 2011-05-10 06:36:09 --> URI Class Initialized
DEBUG - 2011-05-10 06:36:09 --> Router Class Initialized
DEBUG - 2011-05-10 06:36:09 --> Output Class Initialized
DEBUG - 2011-05-10 06:36:09 --> Input Class Initialized
DEBUG - 2011-05-10 06:36:09 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-10 06:36:09 --> Language Class Initialized
DEBUG - 2011-05-10 06:36:09 --> Loader Class Initialized
DEBUG - 2011-05-10 06:36:09 --> Controller Class Initialized
DEBUG - 2011-05-10 06:36:09 --> Model Class Initialized
DEBUG - 2011-05-10 06:36:09 --> Model Class Initialized
DEBUG - 2011-05-10 06:36:09 --> Model Class Initialized
DEBUG - 2011-05-10 06:36:09 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-10 06:36:09 --> Database Driver Class Initialized
DEBUG - 2011-05-10 06:36:09 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-10 06:36:09 --> Helper loaded: url_helper
DEBUG - 2011-05-10 06:36:09 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-10 06:36:09 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-10 06:36:09 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-10 06:36:09 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-10 06:36:09 --> Final output sent to browser
DEBUG - 2011-05-10 06:36:09 --> Total execution time: 0.9430
DEBUG - 2011-05-10 06:36:17 --> Config Class Initialized
DEBUG - 2011-05-10 06:36:17 --> Hooks Class Initialized
DEBUG - 2011-05-10 06:36:17 --> Utf8 Class Initialized
DEBUG - 2011-05-10 06:36:17 --> UTF-8 Support Enabled
DEBUG - 2011-05-10 06:36:17 --> URI Class Initialized
DEBUG - 2011-05-10 06:36:17 --> Router Class Initialized
DEBUG - 2011-05-10 06:36:17 --> Output Class Initialized
DEBUG - 2011-05-10 06:36:17 --> Input Class Initialized
DEBUG - 2011-05-10 06:36:17 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-10 06:36:17 --> Language Class Initialized
DEBUG - 2011-05-10 06:36:17 --> Loader Class Initialized
DEBUG - 2011-05-10 06:36:17 --> Controller Class Initialized
DEBUG - 2011-05-10 06:36:17 --> Model Class Initialized
DEBUG - 2011-05-10 06:36:17 --> Model Class Initialized
DEBUG - 2011-05-10 06:36:17 --> Model Class Initialized
DEBUG - 2011-05-10 06:36:17 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-10 06:36:17 --> Database Driver Class Initialized
DEBUG - 2011-05-10 06:36:17 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-10 06:36:17 --> Helper loaded: url_helper
DEBUG - 2011-05-10 06:36:17 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-10 06:36:17 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-10 06:36:17 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-10 06:36:17 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-10 06:36:17 --> Final output sent to browser
DEBUG - 2011-05-10 06:36:17 --> Total execution time: 0.2335
DEBUG - 2011-05-10 06:36:18 --> Config Class Initialized
DEBUG - 2011-05-10 06:36:18 --> Hooks Class Initialized
DEBUG - 2011-05-10 06:36:18 --> Utf8 Class Initialized
DEBUG - 2011-05-10 06:36:18 --> UTF-8 Support Enabled
DEBUG - 2011-05-10 06:36:18 --> URI Class Initialized
DEBUG - 2011-05-10 06:36:18 --> Router Class Initialized
DEBUG - 2011-05-10 06:36:18 --> Output Class Initialized
DEBUG - 2011-05-10 06:36:18 --> Input Class Initialized
DEBUG - 2011-05-10 06:36:18 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-10 06:36:18 --> Language Class Initialized
DEBUG - 2011-05-10 06:36:18 --> Loader Class Initialized
DEBUG - 2011-05-10 06:36:18 --> Controller Class Initialized
DEBUG - 2011-05-10 06:36:18 --> Model Class Initialized
DEBUG - 2011-05-10 06:36:18 --> Model Class Initialized
DEBUG - 2011-05-10 06:36:18 --> Model Class Initialized
DEBUG - 2011-05-10 06:36:18 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-10 06:36:18 --> Database Driver Class Initialized
DEBUG - 2011-05-10 06:36:18 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-10 06:36:18 --> Helper loaded: url_helper
DEBUG - 2011-05-10 06:36:18 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-10 06:36:18 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-10 06:36:18 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-10 06:36:18 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-10 06:36:18 --> Final output sent to browser
DEBUG - 2011-05-10 06:36:18 --> Total execution time: 0.0470
DEBUG - 2011-05-10 06:36:27 --> Config Class Initialized
DEBUG - 2011-05-10 06:36:27 --> Hooks Class Initialized
DEBUG - 2011-05-10 06:36:27 --> Utf8 Class Initialized
DEBUG - 2011-05-10 06:36:27 --> UTF-8 Support Enabled
DEBUG - 2011-05-10 06:36:27 --> URI Class Initialized
DEBUG - 2011-05-10 06:36:27 --> Router Class Initialized
DEBUG - 2011-05-10 06:36:27 --> Output Class Initialized
DEBUG - 2011-05-10 06:36:27 --> Input Class Initialized
DEBUG - 2011-05-10 06:36:27 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-10 06:36:27 --> Language Class Initialized
DEBUG - 2011-05-10 06:36:27 --> Loader Class Initialized
DEBUG - 2011-05-10 06:36:27 --> Controller Class Initialized
DEBUG - 2011-05-10 06:36:27 --> Model Class Initialized
DEBUG - 2011-05-10 06:36:27 --> Model Class Initialized
DEBUG - 2011-05-10 06:36:27 --> Model Class Initialized
DEBUG - 2011-05-10 06:36:27 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-10 06:36:27 --> Database Driver Class Initialized
DEBUG - 2011-05-10 06:36:27 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-10 06:36:27 --> Helper loaded: url_helper
DEBUG - 2011-05-10 06:36:27 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-10 06:36:27 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-10 06:36:27 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-10 06:36:27 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-10 06:36:27 --> Final output sent to browser
DEBUG - 2011-05-10 06:36:27 --> Total execution time: 0.0492
DEBUG - 2011-05-10 06:36:35 --> Config Class Initialized
DEBUG - 2011-05-10 06:36:35 --> Hooks Class Initialized
DEBUG - 2011-05-10 06:36:35 --> Utf8 Class Initialized
DEBUG - 2011-05-10 06:36:35 --> UTF-8 Support Enabled
DEBUG - 2011-05-10 06:36:35 --> URI Class Initialized
DEBUG - 2011-05-10 06:36:35 --> Router Class Initialized
DEBUG - 2011-05-10 06:36:35 --> Output Class Initialized
DEBUG - 2011-05-10 06:36:35 --> Input Class Initialized
DEBUG - 2011-05-10 06:36:35 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-10 06:36:35 --> Language Class Initialized
DEBUG - 2011-05-10 06:36:35 --> Loader Class Initialized
DEBUG - 2011-05-10 06:36:35 --> Controller Class Initialized
DEBUG - 2011-05-10 06:36:35 --> Model Class Initialized
DEBUG - 2011-05-10 06:36:35 --> Model Class Initialized
DEBUG - 2011-05-10 06:36:35 --> Model Class Initialized
DEBUG - 2011-05-10 06:36:35 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-10 06:36:35 --> Database Driver Class Initialized
DEBUG - 2011-05-10 06:36:35 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-10 06:36:35 --> Helper loaded: url_helper
DEBUG - 2011-05-10 06:36:35 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-10 06:36:35 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-10 06:36:35 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-10 06:36:35 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-10 06:36:35 --> Final output sent to browser
DEBUG - 2011-05-10 06:36:35 --> Total execution time: 0.4224
DEBUG - 2011-05-10 06:36:47 --> Config Class Initialized
DEBUG - 2011-05-10 06:36:47 --> Hooks Class Initialized
DEBUG - 2011-05-10 06:36:47 --> Utf8 Class Initialized
DEBUG - 2011-05-10 06:36:47 --> UTF-8 Support Enabled
DEBUG - 2011-05-10 06:36:47 --> URI Class Initialized
DEBUG - 2011-05-10 06:36:47 --> Router Class Initialized
DEBUG - 2011-05-10 06:36:47 --> Output Class Initialized
DEBUG - 2011-05-10 06:36:47 --> Input Class Initialized
DEBUG - 2011-05-10 06:36:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-10 06:36:47 --> Language Class Initialized
DEBUG - 2011-05-10 06:36:47 --> Loader Class Initialized
DEBUG - 2011-05-10 06:36:47 --> Controller Class Initialized
DEBUG - 2011-05-10 06:36:47 --> Model Class Initialized
DEBUG - 2011-05-10 06:36:47 --> Model Class Initialized
DEBUG - 2011-05-10 06:36:47 --> Model Class Initialized
DEBUG - 2011-05-10 06:36:47 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-10 06:36:47 --> Database Driver Class Initialized
DEBUG - 2011-05-10 06:36:48 --> Config Class Initialized
DEBUG - 2011-05-10 06:36:48 --> Hooks Class Initialized
DEBUG - 2011-05-10 06:36:48 --> Utf8 Class Initialized
DEBUG - 2011-05-10 06:36:48 --> UTF-8 Support Enabled
DEBUG - 2011-05-10 06:36:48 --> URI Class Initialized
DEBUG - 2011-05-10 06:36:48 --> Router Class Initialized
DEBUG - 2011-05-10 06:36:48 --> Output Class Initialized
DEBUG - 2011-05-10 06:36:48 --> Input Class Initialized
DEBUG - 2011-05-10 06:36:48 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-10 06:36:48 --> Language Class Initialized
DEBUG - 2011-05-10 06:36:48 --> Loader Class Initialized
DEBUG - 2011-05-10 06:36:48 --> Controller Class Initialized
DEBUG - 2011-05-10 06:36:48 --> Model Class Initialized
DEBUG - 2011-05-10 06:36:48 --> Model Class Initialized
DEBUG - 2011-05-10 06:36:48 --> Model Class Initialized
DEBUG - 2011-05-10 06:36:48 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-10 06:36:48 --> Database Driver Class Initialized
DEBUG - 2011-05-10 06:36:48 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-10 06:36:48 --> Helper loaded: url_helper
DEBUG - 2011-05-10 06:36:48 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-10 06:36:48 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-10 06:36:48 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-10 06:36:48 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-10 06:36:48 --> Final output sent to browser
DEBUG - 2011-05-10 06:36:48 --> Total execution time: 0.3937
DEBUG - 2011-05-10 06:36:48 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-10 06:36:48 --> Helper loaded: url_helper
DEBUG - 2011-05-10 06:36:48 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-10 06:36:48 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-10 06:36:48 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-10 06:36:48 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-10 06:36:48 --> Final output sent to browser
DEBUG - 2011-05-10 06:36:48 --> Total execution time: 0.1169
DEBUG - 2011-05-10 06:37:06 --> Config Class Initialized
DEBUG - 2011-05-10 06:37:06 --> Hooks Class Initialized
DEBUG - 2011-05-10 06:37:06 --> Utf8 Class Initialized
DEBUG - 2011-05-10 06:37:06 --> UTF-8 Support Enabled
DEBUG - 2011-05-10 06:37:06 --> URI Class Initialized
DEBUG - 2011-05-10 06:37:06 --> Router Class Initialized
DEBUG - 2011-05-10 06:37:06 --> Output Class Initialized
DEBUG - 2011-05-10 06:37:06 --> Input Class Initialized
DEBUG - 2011-05-10 06:37:06 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-10 06:37:06 --> Language Class Initialized
DEBUG - 2011-05-10 06:37:06 --> Loader Class Initialized
DEBUG - 2011-05-10 06:37:06 --> Controller Class Initialized
DEBUG - 2011-05-10 06:37:06 --> Model Class Initialized
DEBUG - 2011-05-10 06:37:06 --> Model Class Initialized
DEBUG - 2011-05-10 06:37:06 --> Model Class Initialized
DEBUG - 2011-05-10 06:37:06 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-10 06:37:06 --> Database Driver Class Initialized
DEBUG - 2011-05-10 06:37:07 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-10 06:37:07 --> Helper loaded: url_helper
DEBUG - 2011-05-10 06:37:07 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-10 06:37:07 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-10 06:37:07 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-10 06:37:07 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-10 06:37:07 --> Final output sent to browser
DEBUG - 2011-05-10 06:37:07 --> Total execution time: 0.4119
DEBUG - 2011-05-10 06:37:08 --> Config Class Initialized
DEBUG - 2011-05-10 06:37:08 --> Hooks Class Initialized
DEBUG - 2011-05-10 06:37:08 --> Utf8 Class Initialized
DEBUG - 2011-05-10 06:37:08 --> UTF-8 Support Enabled
DEBUG - 2011-05-10 06:37:08 --> URI Class Initialized
DEBUG - 2011-05-10 06:37:08 --> Router Class Initialized
DEBUG - 2011-05-10 06:37:08 --> Output Class Initialized
DEBUG - 2011-05-10 06:37:08 --> Input Class Initialized
DEBUG - 2011-05-10 06:37:08 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-10 06:37:08 --> Language Class Initialized
DEBUG - 2011-05-10 06:37:08 --> Loader Class Initialized
DEBUG - 2011-05-10 06:37:08 --> Controller Class Initialized
DEBUG - 2011-05-10 06:37:08 --> Model Class Initialized
DEBUG - 2011-05-10 06:37:08 --> Model Class Initialized
DEBUG - 2011-05-10 06:37:08 --> Model Class Initialized
DEBUG - 2011-05-10 06:37:08 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-10 06:37:08 --> Database Driver Class Initialized
DEBUG - 2011-05-10 06:37:08 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-10 06:37:08 --> Helper loaded: url_helper
DEBUG - 2011-05-10 06:37:08 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-10 06:37:08 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-10 06:37:08 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-10 06:37:08 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-10 06:37:08 --> Final output sent to browser
DEBUG - 2011-05-10 06:37:08 --> Total execution time: 0.0514
DEBUG - 2011-05-10 06:37:20 --> Config Class Initialized
DEBUG - 2011-05-10 06:37:20 --> Hooks Class Initialized
DEBUG - 2011-05-10 06:37:20 --> Utf8 Class Initialized
DEBUG - 2011-05-10 06:37:20 --> UTF-8 Support Enabled
DEBUG - 2011-05-10 06:37:20 --> URI Class Initialized
DEBUG - 2011-05-10 06:37:20 --> Router Class Initialized
DEBUG - 2011-05-10 06:37:20 --> Output Class Initialized
DEBUG - 2011-05-10 06:37:20 --> Input Class Initialized
DEBUG - 2011-05-10 06:37:20 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-10 06:37:20 --> Language Class Initialized
DEBUG - 2011-05-10 06:37:20 --> Loader Class Initialized
DEBUG - 2011-05-10 06:37:20 --> Controller Class Initialized
DEBUG - 2011-05-10 06:37:20 --> Model Class Initialized
DEBUG - 2011-05-10 06:37:20 --> Model Class Initialized
DEBUG - 2011-05-10 06:37:20 --> Model Class Initialized
DEBUG - 2011-05-10 06:37:20 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-10 06:37:20 --> Database Driver Class Initialized
DEBUG - 2011-05-10 06:37:20 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-10 06:37:20 --> Helper loaded: url_helper
DEBUG - 2011-05-10 06:37:20 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-10 06:37:20 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-10 06:37:20 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-10 06:37:20 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-10 06:37:20 --> Final output sent to browser
DEBUG - 2011-05-10 06:37:20 --> Total execution time: 0.4316
DEBUG - 2011-05-10 06:37:23 --> Config Class Initialized
DEBUG - 2011-05-10 06:37:23 --> Hooks Class Initialized
DEBUG - 2011-05-10 06:37:23 --> Utf8 Class Initialized
DEBUG - 2011-05-10 06:37:23 --> UTF-8 Support Enabled
DEBUG - 2011-05-10 06:37:23 --> URI Class Initialized
DEBUG - 2011-05-10 06:37:23 --> Router Class Initialized
DEBUG - 2011-05-10 06:37:23 --> Output Class Initialized
DEBUG - 2011-05-10 06:37:23 --> Input Class Initialized
DEBUG - 2011-05-10 06:37:23 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-10 06:37:23 --> Language Class Initialized
DEBUG - 2011-05-10 06:37:23 --> Loader Class Initialized
DEBUG - 2011-05-10 06:37:23 --> Controller Class Initialized
DEBUG - 2011-05-10 06:37:23 --> Model Class Initialized
DEBUG - 2011-05-10 06:37:23 --> Model Class Initialized
DEBUG - 2011-05-10 06:37:23 --> Model Class Initialized
DEBUG - 2011-05-10 06:37:23 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-10 06:37:23 --> Database Driver Class Initialized
DEBUG - 2011-05-10 06:37:23 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-10 06:37:23 --> Helper loaded: url_helper
DEBUG - 2011-05-10 06:37:23 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-10 06:37:23 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-10 06:37:23 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-10 06:37:23 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-10 06:37:23 --> Final output sent to browser
DEBUG - 2011-05-10 06:37:23 --> Total execution time: 0.0478
DEBUG - 2011-05-10 06:37:35 --> Config Class Initialized
DEBUG - 2011-05-10 06:37:35 --> Hooks Class Initialized
DEBUG - 2011-05-10 06:37:35 --> Utf8 Class Initialized
DEBUG - 2011-05-10 06:37:35 --> UTF-8 Support Enabled
DEBUG - 2011-05-10 06:37:35 --> URI Class Initialized
DEBUG - 2011-05-10 06:37:35 --> Router Class Initialized
DEBUG - 2011-05-10 06:37:35 --> Output Class Initialized
DEBUG - 2011-05-10 06:37:35 --> Input Class Initialized
DEBUG - 2011-05-10 06:37:35 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-10 06:37:35 --> Language Class Initialized
DEBUG - 2011-05-10 06:37:35 --> Loader Class Initialized
DEBUG - 2011-05-10 06:37:35 --> Controller Class Initialized
DEBUG - 2011-05-10 06:37:35 --> Model Class Initialized
DEBUG - 2011-05-10 06:37:35 --> Model Class Initialized
DEBUG - 2011-05-10 06:37:35 --> Model Class Initialized
DEBUG - 2011-05-10 06:37:35 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-10 06:37:35 --> Database Driver Class Initialized
DEBUG - 2011-05-10 06:37:37 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-10 06:37:37 --> Helper loaded: url_helper
DEBUG - 2011-05-10 06:37:37 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-10 06:37:37 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-10 06:37:37 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-10 06:37:37 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-10 06:37:37 --> Final output sent to browser
DEBUG - 2011-05-10 06:37:37 --> Total execution time: 2.6837
DEBUG - 2011-05-10 06:37:39 --> Config Class Initialized
DEBUG - 2011-05-10 06:37:39 --> Hooks Class Initialized
DEBUG - 2011-05-10 06:37:39 --> Utf8 Class Initialized
DEBUG - 2011-05-10 06:37:39 --> UTF-8 Support Enabled
DEBUG - 2011-05-10 06:37:39 --> URI Class Initialized
DEBUG - 2011-05-10 06:37:39 --> Router Class Initialized
DEBUG - 2011-05-10 06:37:39 --> Output Class Initialized
DEBUG - 2011-05-10 06:37:39 --> Input Class Initialized
DEBUG - 2011-05-10 06:37:39 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-10 06:37:39 --> Language Class Initialized
DEBUG - 2011-05-10 06:37:39 --> Loader Class Initialized
DEBUG - 2011-05-10 06:37:39 --> Controller Class Initialized
DEBUG - 2011-05-10 06:37:39 --> Model Class Initialized
DEBUG - 2011-05-10 06:37:39 --> Model Class Initialized
DEBUG - 2011-05-10 06:37:39 --> Model Class Initialized
DEBUG - 2011-05-10 06:37:39 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-10 06:37:39 --> Database Driver Class Initialized
DEBUG - 2011-05-10 06:37:39 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-10 06:37:39 --> Helper loaded: url_helper
DEBUG - 2011-05-10 06:37:39 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-10 06:37:39 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-10 06:37:39 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-10 06:37:39 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-10 06:37:39 --> Final output sent to browser
DEBUG - 2011-05-10 06:37:39 --> Total execution time: 0.0862
DEBUG - 2011-05-10 06:37:47 --> Config Class Initialized
DEBUG - 2011-05-10 06:37:47 --> Hooks Class Initialized
DEBUG - 2011-05-10 06:37:47 --> Utf8 Class Initialized
DEBUG - 2011-05-10 06:37:47 --> UTF-8 Support Enabled
DEBUG - 2011-05-10 06:37:47 --> URI Class Initialized
DEBUG - 2011-05-10 06:37:47 --> Router Class Initialized
DEBUG - 2011-05-10 06:37:47 --> Output Class Initialized
DEBUG - 2011-05-10 06:37:47 --> Input Class Initialized
DEBUG - 2011-05-10 06:37:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-10 06:37:47 --> Language Class Initialized
DEBUG - 2011-05-10 06:37:47 --> Loader Class Initialized
DEBUG - 2011-05-10 06:37:47 --> Controller Class Initialized
DEBUG - 2011-05-10 06:37:47 --> Model Class Initialized
DEBUG - 2011-05-10 06:37:47 --> Model Class Initialized
DEBUG - 2011-05-10 06:37:47 --> Model Class Initialized
DEBUG - 2011-05-10 06:37:47 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-10 06:37:47 --> Database Driver Class Initialized
DEBUG - 2011-05-10 06:37:47 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-10 06:37:47 --> Helper loaded: url_helper
DEBUG - 2011-05-10 06:37:47 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-10 06:37:47 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-10 06:37:47 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-10 06:37:47 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-10 06:37:47 --> Final output sent to browser
DEBUG - 2011-05-10 06:37:47 --> Total execution time: 0.2563
DEBUG - 2011-05-10 06:37:49 --> Config Class Initialized
DEBUG - 2011-05-10 06:37:49 --> Hooks Class Initialized
DEBUG - 2011-05-10 06:37:49 --> Utf8 Class Initialized
DEBUG - 2011-05-10 06:37:49 --> UTF-8 Support Enabled
DEBUG - 2011-05-10 06:37:49 --> URI Class Initialized
DEBUG - 2011-05-10 06:37:49 --> Router Class Initialized
DEBUG - 2011-05-10 06:37:49 --> Output Class Initialized
DEBUG - 2011-05-10 06:37:49 --> Input Class Initialized
DEBUG - 2011-05-10 06:37:49 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-10 06:37:49 --> Language Class Initialized
DEBUG - 2011-05-10 06:37:49 --> Loader Class Initialized
DEBUG - 2011-05-10 06:37:49 --> Controller Class Initialized
DEBUG - 2011-05-10 06:37:49 --> Model Class Initialized
DEBUG - 2011-05-10 06:37:49 --> Model Class Initialized
DEBUG - 2011-05-10 06:37:49 --> Model Class Initialized
DEBUG - 2011-05-10 06:37:49 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-10 06:37:49 --> Database Driver Class Initialized
DEBUG - 2011-05-10 06:37:49 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-10 06:37:49 --> Helper loaded: url_helper
DEBUG - 2011-05-10 06:37:49 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-10 06:37:49 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-10 06:37:49 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-10 06:37:49 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-10 06:37:49 --> Final output sent to browser
DEBUG - 2011-05-10 06:37:49 --> Total execution time: 0.0503
DEBUG - 2011-05-10 06:37:55 --> Config Class Initialized
DEBUG - 2011-05-10 06:37:55 --> Hooks Class Initialized
DEBUG - 2011-05-10 06:37:55 --> Utf8 Class Initialized
DEBUG - 2011-05-10 06:37:55 --> UTF-8 Support Enabled
DEBUG - 2011-05-10 06:37:55 --> URI Class Initialized
DEBUG - 2011-05-10 06:37:55 --> Router Class Initialized
DEBUG - 2011-05-10 06:37:55 --> Output Class Initialized
DEBUG - 2011-05-10 06:37:55 --> Input Class Initialized
DEBUG - 2011-05-10 06:37:55 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-10 06:37:55 --> Language Class Initialized
DEBUG - 2011-05-10 06:37:55 --> Loader Class Initialized
DEBUG - 2011-05-10 06:37:55 --> Controller Class Initialized
DEBUG - 2011-05-10 06:37:55 --> Model Class Initialized
DEBUG - 2011-05-10 06:37:55 --> Model Class Initialized
DEBUG - 2011-05-10 06:37:55 --> Model Class Initialized
DEBUG - 2011-05-10 06:37:55 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-10 06:37:55 --> Database Driver Class Initialized
DEBUG - 2011-05-10 06:37:56 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-10 06:37:56 --> Helper loaded: url_helper
DEBUG - 2011-05-10 06:37:56 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-10 06:37:56 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-10 06:37:56 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-10 06:37:56 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-10 06:37:56 --> Final output sent to browser
DEBUG - 2011-05-10 06:37:56 --> Total execution time: 0.2545
DEBUG - 2011-05-10 06:38:05 --> Config Class Initialized
DEBUG - 2011-05-10 06:38:05 --> Hooks Class Initialized
DEBUG - 2011-05-10 06:38:05 --> Utf8 Class Initialized
DEBUG - 2011-05-10 06:38:05 --> UTF-8 Support Enabled
DEBUG - 2011-05-10 06:38:05 --> URI Class Initialized
DEBUG - 2011-05-10 06:38:05 --> Router Class Initialized
DEBUG - 2011-05-10 06:38:05 --> Output Class Initialized
DEBUG - 2011-05-10 06:38:05 --> Input Class Initialized
DEBUG - 2011-05-10 06:38:05 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-10 06:38:05 --> Language Class Initialized
DEBUG - 2011-05-10 06:38:05 --> Loader Class Initialized
DEBUG - 2011-05-10 06:38:05 --> Controller Class Initialized
DEBUG - 2011-05-10 06:38:05 --> Model Class Initialized
DEBUG - 2011-05-10 06:38:05 --> Model Class Initialized
DEBUG - 2011-05-10 06:38:05 --> Model Class Initialized
DEBUG - 2011-05-10 06:38:05 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-10 06:38:05 --> Database Driver Class Initialized
DEBUG - 2011-05-10 06:38:05 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-10 06:38:05 --> Helper loaded: url_helper
DEBUG - 2011-05-10 06:38:05 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-10 06:38:05 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-10 06:38:05 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-10 06:38:05 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-10 06:38:05 --> Final output sent to browser
DEBUG - 2011-05-10 06:38:05 --> Total execution time: 0.2029
DEBUG - 2011-05-10 06:38:08 --> Config Class Initialized
DEBUG - 2011-05-10 06:38:08 --> Hooks Class Initialized
DEBUG - 2011-05-10 06:38:08 --> Utf8 Class Initialized
DEBUG - 2011-05-10 06:38:08 --> UTF-8 Support Enabled
DEBUG - 2011-05-10 06:38:08 --> URI Class Initialized
DEBUG - 2011-05-10 06:38:08 --> Router Class Initialized
DEBUG - 2011-05-10 06:38:08 --> Output Class Initialized
DEBUG - 2011-05-10 06:38:08 --> Input Class Initialized
DEBUG - 2011-05-10 06:38:08 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-10 06:38:08 --> Language Class Initialized
DEBUG - 2011-05-10 06:38:08 --> Loader Class Initialized
DEBUG - 2011-05-10 06:38:08 --> Controller Class Initialized
DEBUG - 2011-05-10 06:38:08 --> Model Class Initialized
DEBUG - 2011-05-10 06:38:08 --> Model Class Initialized
DEBUG - 2011-05-10 06:38:08 --> Model Class Initialized
DEBUG - 2011-05-10 06:38:08 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-10 06:38:08 --> Database Driver Class Initialized
DEBUG - 2011-05-10 06:38:08 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-10 06:38:08 --> Helper loaded: url_helper
DEBUG - 2011-05-10 06:38:08 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-10 06:38:08 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-10 06:38:08 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-10 06:38:08 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-10 06:38:08 --> Final output sent to browser
DEBUG - 2011-05-10 06:38:08 --> Total execution time: 0.0721
DEBUG - 2011-05-10 06:38:08 --> Config Class Initialized
DEBUG - 2011-05-10 06:38:08 --> Hooks Class Initialized
DEBUG - 2011-05-10 06:38:08 --> Utf8 Class Initialized
DEBUG - 2011-05-10 06:38:08 --> UTF-8 Support Enabled
DEBUG - 2011-05-10 06:38:08 --> URI Class Initialized
DEBUG - 2011-05-10 06:38:08 --> Router Class Initialized
DEBUG - 2011-05-10 06:38:08 --> Output Class Initialized
DEBUG - 2011-05-10 06:38:08 --> Input Class Initialized
DEBUG - 2011-05-10 06:38:08 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-10 06:38:08 --> Language Class Initialized
DEBUG - 2011-05-10 06:38:08 --> Loader Class Initialized
DEBUG - 2011-05-10 06:38:08 --> Controller Class Initialized
DEBUG - 2011-05-10 06:38:08 --> Model Class Initialized
DEBUG - 2011-05-10 06:38:08 --> Model Class Initialized
DEBUG - 2011-05-10 06:38:08 --> Model Class Initialized
DEBUG - 2011-05-10 06:38:08 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-10 06:38:08 --> Database Driver Class Initialized
DEBUG - 2011-05-10 06:38:08 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-10 06:38:08 --> Helper loaded: url_helper
DEBUG - 2011-05-10 06:38:08 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-10 06:38:08 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-10 06:38:08 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-10 06:38:08 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-10 06:38:08 --> Final output sent to browser
DEBUG - 2011-05-10 06:38:08 --> Total execution time: 0.0512
DEBUG - 2011-05-10 06:38:37 --> Config Class Initialized
DEBUG - 2011-05-10 06:38:37 --> Hooks Class Initialized
DEBUG - 2011-05-10 06:38:37 --> Utf8 Class Initialized
DEBUG - 2011-05-10 06:38:37 --> UTF-8 Support Enabled
DEBUG - 2011-05-10 06:38:37 --> URI Class Initialized
DEBUG - 2011-05-10 06:38:37 --> Router Class Initialized
DEBUG - 2011-05-10 06:38:37 --> Output Class Initialized
DEBUG - 2011-05-10 06:38:37 --> Input Class Initialized
DEBUG - 2011-05-10 06:38:37 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-10 06:38:37 --> Language Class Initialized
DEBUG - 2011-05-10 06:38:37 --> Loader Class Initialized
DEBUG - 2011-05-10 06:38:37 --> Controller Class Initialized
ERROR - 2011-05-10 06:38:37 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-10 06:38:37 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-10 06:38:37 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-10 06:38:37 --> Model Class Initialized
DEBUG - 2011-05-10 06:38:37 --> Model Class Initialized
DEBUG - 2011-05-10 06:38:37 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-10 06:38:37 --> Database Driver Class Initialized
DEBUG - 2011-05-10 06:38:37 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-10 06:38:37 --> Helper loaded: url_helper
DEBUG - 2011-05-10 06:38:37 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-10 06:38:37 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-10 06:38:37 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-10 06:38:37 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-10 06:38:37 --> Final output sent to browser
DEBUG - 2011-05-10 06:38:37 --> Total execution time: 0.2565
DEBUG - 2011-05-10 06:38:38 --> Config Class Initialized
DEBUG - 2011-05-10 06:38:38 --> Hooks Class Initialized
DEBUG - 2011-05-10 06:38:38 --> Utf8 Class Initialized
DEBUG - 2011-05-10 06:38:38 --> UTF-8 Support Enabled
DEBUG - 2011-05-10 06:38:38 --> URI Class Initialized
DEBUG - 2011-05-10 06:38:38 --> Router Class Initialized
DEBUG - 2011-05-10 06:38:38 --> Output Class Initialized
DEBUG - 2011-05-10 06:38:38 --> Input Class Initialized
DEBUG - 2011-05-10 06:38:38 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-10 06:38:38 --> Language Class Initialized
DEBUG - 2011-05-10 06:38:38 --> Loader Class Initialized
DEBUG - 2011-05-10 06:38:38 --> Controller Class Initialized
DEBUG - 2011-05-10 06:38:38 --> Model Class Initialized
DEBUG - 2011-05-10 06:38:38 --> Model Class Initialized
DEBUG - 2011-05-10 06:38:38 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-10 06:38:38 --> Database Driver Class Initialized
DEBUG - 2011-05-10 06:38:39 --> Final output sent to browser
DEBUG - 2011-05-10 06:38:39 --> Total execution time: 0.9219
DEBUG - 2011-05-10 06:39:18 --> Config Class Initialized
DEBUG - 2011-05-10 06:39:18 --> Hooks Class Initialized
DEBUG - 2011-05-10 06:39:18 --> Utf8 Class Initialized
DEBUG - 2011-05-10 06:39:18 --> UTF-8 Support Enabled
DEBUG - 2011-05-10 06:39:18 --> URI Class Initialized
DEBUG - 2011-05-10 06:39:18 --> Router Class Initialized
DEBUG - 2011-05-10 06:39:18 --> Output Class Initialized
DEBUG - 2011-05-10 06:39:18 --> Input Class Initialized
DEBUG - 2011-05-10 06:39:18 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-10 06:39:18 --> Language Class Initialized
DEBUG - 2011-05-10 06:39:18 --> Loader Class Initialized
DEBUG - 2011-05-10 06:39:18 --> Controller Class Initialized
ERROR - 2011-05-10 06:39:18 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-10 06:39:18 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-10 06:39:18 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-10 06:39:18 --> Model Class Initialized
DEBUG - 2011-05-10 06:39:18 --> Model Class Initialized
DEBUG - 2011-05-10 06:39:18 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-10 06:39:18 --> Database Driver Class Initialized
DEBUG - 2011-05-10 06:39:18 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-10 06:39:18 --> Helper loaded: url_helper
DEBUG - 2011-05-10 06:39:18 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-10 06:39:18 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-10 06:39:18 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-10 06:39:18 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-10 06:39:18 --> Final output sent to browser
DEBUG - 2011-05-10 06:39:18 --> Total execution time: 0.0453
DEBUG - 2011-05-10 06:39:19 --> Config Class Initialized
DEBUG - 2011-05-10 06:39:19 --> Hooks Class Initialized
DEBUG - 2011-05-10 06:39:19 --> Utf8 Class Initialized
DEBUG - 2011-05-10 06:39:19 --> UTF-8 Support Enabled
DEBUG - 2011-05-10 06:39:19 --> URI Class Initialized
DEBUG - 2011-05-10 06:39:19 --> Router Class Initialized
DEBUG - 2011-05-10 06:39:19 --> Output Class Initialized
DEBUG - 2011-05-10 06:39:19 --> Input Class Initialized
DEBUG - 2011-05-10 06:39:19 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-10 06:39:19 --> Language Class Initialized
DEBUG - 2011-05-10 06:39:19 --> Loader Class Initialized
DEBUG - 2011-05-10 06:39:19 --> Controller Class Initialized
DEBUG - 2011-05-10 06:39:19 --> Model Class Initialized
DEBUG - 2011-05-10 06:39:19 --> Model Class Initialized
DEBUG - 2011-05-10 06:39:19 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-10 06:39:19 --> Database Driver Class Initialized
DEBUG - 2011-05-10 06:39:19 --> Final output sent to browser
DEBUG - 2011-05-10 06:39:19 --> Total execution time: 0.7400
DEBUG - 2011-05-10 06:39:49 --> Config Class Initialized
DEBUG - 2011-05-10 06:39:49 --> Hooks Class Initialized
DEBUG - 2011-05-10 06:39:49 --> Utf8 Class Initialized
DEBUG - 2011-05-10 06:39:49 --> UTF-8 Support Enabled
DEBUG - 2011-05-10 06:39:49 --> URI Class Initialized
DEBUG - 2011-05-10 06:39:49 --> Router Class Initialized
DEBUG - 2011-05-10 06:39:49 --> Output Class Initialized
DEBUG - 2011-05-10 06:39:49 --> Input Class Initialized
DEBUG - 2011-05-10 06:39:49 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-10 06:39:49 --> Language Class Initialized
DEBUG - 2011-05-10 06:39:49 --> Loader Class Initialized
DEBUG - 2011-05-10 06:39:49 --> Controller Class Initialized
ERROR - 2011-05-10 06:39:49 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-10 06:39:49 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-10 06:39:49 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-10 06:39:49 --> Model Class Initialized
DEBUG - 2011-05-10 06:39:49 --> Model Class Initialized
DEBUG - 2011-05-10 06:39:49 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-10 06:39:49 --> Database Driver Class Initialized
DEBUG - 2011-05-10 06:39:49 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-10 06:39:49 --> Helper loaded: url_helper
DEBUG - 2011-05-10 06:39:49 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-10 06:39:49 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-10 06:39:49 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-10 06:39:49 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-10 06:39:49 --> Final output sent to browser
DEBUG - 2011-05-10 06:39:49 --> Total execution time: 0.0356
DEBUG - 2011-05-10 06:39:50 --> Config Class Initialized
DEBUG - 2011-05-10 06:39:50 --> Hooks Class Initialized
DEBUG - 2011-05-10 06:39:50 --> Utf8 Class Initialized
DEBUG - 2011-05-10 06:39:50 --> UTF-8 Support Enabled
DEBUG - 2011-05-10 06:39:50 --> URI Class Initialized
DEBUG - 2011-05-10 06:39:50 --> Router Class Initialized
DEBUG - 2011-05-10 06:39:50 --> Output Class Initialized
DEBUG - 2011-05-10 06:39:50 --> Input Class Initialized
DEBUG - 2011-05-10 06:39:50 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-10 06:39:50 --> Language Class Initialized
DEBUG - 2011-05-10 06:39:50 --> Loader Class Initialized
DEBUG - 2011-05-10 06:39:50 --> Controller Class Initialized
DEBUG - 2011-05-10 06:39:50 --> Model Class Initialized
DEBUG - 2011-05-10 06:39:50 --> Model Class Initialized
DEBUG - 2011-05-10 06:39:50 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-10 06:39:50 --> Database Driver Class Initialized
DEBUG - 2011-05-10 06:39:50 --> Final output sent to browser
DEBUG - 2011-05-10 06:39:50 --> Total execution time: 0.6035
DEBUG - 2011-05-10 06:40:14 --> Config Class Initialized
DEBUG - 2011-05-10 06:40:14 --> Hooks Class Initialized
DEBUG - 2011-05-10 06:40:14 --> Utf8 Class Initialized
DEBUG - 2011-05-10 06:40:14 --> UTF-8 Support Enabled
DEBUG - 2011-05-10 06:40:14 --> URI Class Initialized
DEBUG - 2011-05-10 06:40:14 --> Router Class Initialized
DEBUG - 2011-05-10 06:40:14 --> Output Class Initialized
DEBUG - 2011-05-10 06:40:14 --> Input Class Initialized
DEBUG - 2011-05-10 06:40:14 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-10 06:40:14 --> Language Class Initialized
DEBUG - 2011-05-10 06:40:14 --> Loader Class Initialized
DEBUG - 2011-05-10 06:40:14 --> Controller Class Initialized
ERROR - 2011-05-10 06:40:14 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-10 06:40:14 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-10 06:40:14 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-10 06:40:14 --> Model Class Initialized
DEBUG - 2011-05-10 06:40:14 --> Model Class Initialized
DEBUG - 2011-05-10 06:40:14 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-10 06:40:14 --> Database Driver Class Initialized
DEBUG - 2011-05-10 06:40:14 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-10 06:40:14 --> Helper loaded: url_helper
DEBUG - 2011-05-10 06:40:14 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-10 06:40:14 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-10 06:40:14 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-10 06:40:14 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-10 06:40:14 --> Final output sent to browser
DEBUG - 2011-05-10 06:40:14 --> Total execution time: 0.0369
DEBUG - 2011-05-10 06:40:15 --> Config Class Initialized
DEBUG - 2011-05-10 06:40:15 --> Hooks Class Initialized
DEBUG - 2011-05-10 06:40:15 --> Utf8 Class Initialized
DEBUG - 2011-05-10 06:40:15 --> UTF-8 Support Enabled
DEBUG - 2011-05-10 06:40:15 --> URI Class Initialized
DEBUG - 2011-05-10 06:40:15 --> Router Class Initialized
DEBUG - 2011-05-10 06:40:15 --> Output Class Initialized
DEBUG - 2011-05-10 06:40:15 --> Input Class Initialized
DEBUG - 2011-05-10 06:40:15 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-10 06:40:15 --> Language Class Initialized
DEBUG - 2011-05-10 06:40:15 --> Loader Class Initialized
DEBUG - 2011-05-10 06:40:15 --> Controller Class Initialized
DEBUG - 2011-05-10 06:40:15 --> Model Class Initialized
DEBUG - 2011-05-10 06:40:15 --> Model Class Initialized
DEBUG - 2011-05-10 06:40:15 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-10 06:40:15 --> Database Driver Class Initialized
DEBUG - 2011-05-10 06:40:16 --> Final output sent to browser
DEBUG - 2011-05-10 06:40:16 --> Total execution time: 0.8755
DEBUG - 2011-05-10 06:40:23 --> Config Class Initialized
DEBUG - 2011-05-10 06:40:23 --> Hooks Class Initialized
DEBUG - 2011-05-10 06:40:23 --> Utf8 Class Initialized
DEBUG - 2011-05-10 06:40:23 --> UTF-8 Support Enabled
DEBUG - 2011-05-10 06:40:23 --> URI Class Initialized
DEBUG - 2011-05-10 06:40:23 --> Router Class Initialized
DEBUG - 2011-05-10 06:40:23 --> Output Class Initialized
DEBUG - 2011-05-10 06:40:23 --> Input Class Initialized
DEBUG - 2011-05-10 06:40:23 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-10 06:40:23 --> Language Class Initialized
DEBUG - 2011-05-10 06:40:23 --> Loader Class Initialized
DEBUG - 2011-05-10 06:40:23 --> Controller Class Initialized
ERROR - 2011-05-10 06:40:23 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-10 06:40:23 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-10 06:40:23 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-10 06:40:23 --> Model Class Initialized
DEBUG - 2011-05-10 06:40:23 --> Model Class Initialized
DEBUG - 2011-05-10 06:40:23 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-10 06:40:23 --> Database Driver Class Initialized
DEBUG - 2011-05-10 06:40:23 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-10 06:40:23 --> Helper loaded: url_helper
DEBUG - 2011-05-10 06:40:23 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-10 06:40:23 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-10 06:40:23 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-10 06:40:23 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-10 06:40:23 --> Final output sent to browser
DEBUG - 2011-05-10 06:40:23 --> Total execution time: 0.0335
DEBUG - 2011-05-10 06:40:35 --> Config Class Initialized
DEBUG - 2011-05-10 06:40:35 --> Hooks Class Initialized
DEBUG - 2011-05-10 06:40:35 --> Utf8 Class Initialized
DEBUG - 2011-05-10 06:40:35 --> UTF-8 Support Enabled
DEBUG - 2011-05-10 06:40:35 --> URI Class Initialized
DEBUG - 2011-05-10 06:40:35 --> Router Class Initialized
DEBUG - 2011-05-10 06:40:35 --> Output Class Initialized
DEBUG - 2011-05-10 06:40:35 --> Input Class Initialized
DEBUG - 2011-05-10 06:40:35 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-10 06:40:35 --> Language Class Initialized
DEBUG - 2011-05-10 06:40:35 --> Loader Class Initialized
DEBUG - 2011-05-10 06:40:35 --> Controller Class Initialized
ERROR - 2011-05-10 06:40:35 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-10 06:40:35 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-10 06:40:35 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-10 06:40:35 --> Model Class Initialized
DEBUG - 2011-05-10 06:40:35 --> Model Class Initialized
DEBUG - 2011-05-10 06:40:35 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-10 06:40:35 --> Database Driver Class Initialized
DEBUG - 2011-05-10 06:40:35 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-10 06:40:35 --> Helper loaded: url_helper
DEBUG - 2011-05-10 06:40:35 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-10 06:40:35 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-10 06:40:35 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-10 06:40:35 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-10 06:40:35 --> Final output sent to browser
DEBUG - 2011-05-10 06:40:35 --> Total execution time: 0.0293
DEBUG - 2011-05-10 06:40:36 --> Config Class Initialized
DEBUG - 2011-05-10 06:40:36 --> Hooks Class Initialized
DEBUG - 2011-05-10 06:40:36 --> Utf8 Class Initialized
DEBUG - 2011-05-10 06:40:36 --> UTF-8 Support Enabled
DEBUG - 2011-05-10 06:40:36 --> URI Class Initialized
DEBUG - 2011-05-10 06:40:36 --> Router Class Initialized
DEBUG - 2011-05-10 06:40:36 --> Output Class Initialized
DEBUG - 2011-05-10 06:40:36 --> Input Class Initialized
DEBUG - 2011-05-10 06:40:36 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-10 06:40:36 --> Language Class Initialized
DEBUG - 2011-05-10 06:40:36 --> Loader Class Initialized
DEBUG - 2011-05-10 06:40:36 --> Controller Class Initialized
DEBUG - 2011-05-10 06:40:36 --> Model Class Initialized
DEBUG - 2011-05-10 06:40:36 --> Model Class Initialized
DEBUG - 2011-05-10 06:40:36 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-10 06:40:36 --> Database Driver Class Initialized
DEBUG - 2011-05-10 06:40:37 --> Final output sent to browser
DEBUG - 2011-05-10 06:40:37 --> Total execution time: 0.6520
DEBUG - 2011-05-10 06:40:46 --> Config Class Initialized
DEBUG - 2011-05-10 06:40:46 --> Hooks Class Initialized
DEBUG - 2011-05-10 06:40:46 --> Utf8 Class Initialized
DEBUG - 2011-05-10 06:40:46 --> UTF-8 Support Enabled
DEBUG - 2011-05-10 06:40:46 --> URI Class Initialized
DEBUG - 2011-05-10 06:40:46 --> Router Class Initialized
DEBUG - 2011-05-10 06:40:46 --> Output Class Initialized
DEBUG - 2011-05-10 06:40:46 --> Input Class Initialized
DEBUG - 2011-05-10 06:40:46 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-10 06:40:46 --> Language Class Initialized
DEBUG - 2011-05-10 06:40:46 --> Loader Class Initialized
DEBUG - 2011-05-10 06:40:46 --> Controller Class Initialized
ERROR - 2011-05-10 06:40:46 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-10 06:40:46 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-10 06:40:46 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-10 06:40:46 --> Model Class Initialized
DEBUG - 2011-05-10 06:40:46 --> Model Class Initialized
DEBUG - 2011-05-10 06:40:46 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-10 06:40:46 --> Database Driver Class Initialized
DEBUG - 2011-05-10 06:40:46 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-10 06:40:46 --> Helper loaded: url_helper
DEBUG - 2011-05-10 06:40:46 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-10 06:40:46 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-10 06:40:46 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-10 06:40:46 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-10 06:40:46 --> Final output sent to browser
DEBUG - 2011-05-10 06:40:46 --> Total execution time: 0.0656
DEBUG - 2011-05-10 06:40:47 --> Config Class Initialized
DEBUG - 2011-05-10 06:40:47 --> Hooks Class Initialized
DEBUG - 2011-05-10 06:40:47 --> Utf8 Class Initialized
DEBUG - 2011-05-10 06:40:47 --> UTF-8 Support Enabled
DEBUG - 2011-05-10 06:40:47 --> URI Class Initialized
DEBUG - 2011-05-10 06:40:47 --> Router Class Initialized
DEBUG - 2011-05-10 06:40:47 --> Output Class Initialized
DEBUG - 2011-05-10 06:40:47 --> Input Class Initialized
DEBUG - 2011-05-10 06:40:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-10 06:40:47 --> Language Class Initialized
DEBUG - 2011-05-10 06:40:47 --> Loader Class Initialized
DEBUG - 2011-05-10 06:40:47 --> Controller Class Initialized
DEBUG - 2011-05-10 06:40:47 --> Model Class Initialized
DEBUG - 2011-05-10 06:40:47 --> Model Class Initialized
DEBUG - 2011-05-10 06:40:47 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-10 06:40:47 --> Database Driver Class Initialized
DEBUG - 2011-05-10 06:40:48 --> Final output sent to browser
DEBUG - 2011-05-10 06:40:48 --> Total execution time: 1.8503
DEBUG - 2011-05-10 06:41:04 --> Config Class Initialized
DEBUG - 2011-05-10 06:41:04 --> Hooks Class Initialized
DEBUG - 2011-05-10 06:41:04 --> Utf8 Class Initialized
DEBUG - 2011-05-10 06:41:04 --> UTF-8 Support Enabled
DEBUG - 2011-05-10 06:41:04 --> URI Class Initialized
DEBUG - 2011-05-10 06:41:04 --> Router Class Initialized
DEBUG - 2011-05-10 06:41:04 --> Output Class Initialized
DEBUG - 2011-05-10 06:41:04 --> Input Class Initialized
DEBUG - 2011-05-10 06:41:04 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-10 06:41:04 --> Language Class Initialized
DEBUG - 2011-05-10 06:41:04 --> Loader Class Initialized
DEBUG - 2011-05-10 06:41:04 --> Controller Class Initialized
ERROR - 2011-05-10 06:41:04 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-10 06:41:04 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-10 06:41:04 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-10 06:41:04 --> Model Class Initialized
DEBUG - 2011-05-10 06:41:04 --> Model Class Initialized
DEBUG - 2011-05-10 06:41:04 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-10 06:41:04 --> Database Driver Class Initialized
DEBUG - 2011-05-10 06:41:04 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-10 06:41:04 --> Helper loaded: url_helper
DEBUG - 2011-05-10 06:41:04 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-10 06:41:04 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-10 06:41:04 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-10 06:41:04 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-10 06:41:04 --> Final output sent to browser
DEBUG - 2011-05-10 06:41:04 --> Total execution time: 0.0326
DEBUG - 2011-05-10 06:41:04 --> Config Class Initialized
DEBUG - 2011-05-10 06:41:04 --> Hooks Class Initialized
DEBUG - 2011-05-10 06:41:04 --> Utf8 Class Initialized
DEBUG - 2011-05-10 06:41:04 --> UTF-8 Support Enabled
DEBUG - 2011-05-10 06:41:04 --> URI Class Initialized
DEBUG - 2011-05-10 06:41:04 --> Router Class Initialized
DEBUG - 2011-05-10 06:41:04 --> Output Class Initialized
DEBUG - 2011-05-10 06:41:04 --> Input Class Initialized
DEBUG - 2011-05-10 06:41:04 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-10 06:41:04 --> Language Class Initialized
DEBUG - 2011-05-10 06:41:04 --> Loader Class Initialized
DEBUG - 2011-05-10 06:41:04 --> Controller Class Initialized
DEBUG - 2011-05-10 06:41:04 --> Model Class Initialized
DEBUG - 2011-05-10 06:41:04 --> Model Class Initialized
DEBUG - 2011-05-10 06:41:04 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-10 06:41:04 --> Database Driver Class Initialized
DEBUG - 2011-05-10 06:41:05 --> Final output sent to browser
DEBUG - 2011-05-10 06:41:05 --> Total execution time: 0.5181
DEBUG - 2011-05-10 06:41:17 --> Config Class Initialized
DEBUG - 2011-05-10 06:41:17 --> Hooks Class Initialized
DEBUG - 2011-05-10 06:41:17 --> Utf8 Class Initialized
DEBUG - 2011-05-10 06:41:17 --> UTF-8 Support Enabled
DEBUG - 2011-05-10 06:41:17 --> URI Class Initialized
DEBUG - 2011-05-10 06:41:17 --> Router Class Initialized
DEBUG - 2011-05-10 06:41:17 --> Output Class Initialized
DEBUG - 2011-05-10 06:41:17 --> Input Class Initialized
DEBUG - 2011-05-10 06:41:17 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-10 06:41:17 --> Language Class Initialized
DEBUG - 2011-05-10 06:41:17 --> Loader Class Initialized
DEBUG - 2011-05-10 06:41:17 --> Controller Class Initialized
ERROR - 2011-05-10 06:41:17 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-10 06:41:17 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-10 06:41:17 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-10 06:41:17 --> Model Class Initialized
DEBUG - 2011-05-10 06:41:17 --> Model Class Initialized
DEBUG - 2011-05-10 06:41:17 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-10 06:41:17 --> Database Driver Class Initialized
DEBUG - 2011-05-10 06:41:17 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-10 06:41:17 --> Helper loaded: url_helper
DEBUG - 2011-05-10 06:41:17 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-10 06:41:17 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-10 06:41:17 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-10 06:41:17 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-10 06:41:17 --> Final output sent to browser
DEBUG - 2011-05-10 06:41:17 --> Total execution time: 0.0310
DEBUG - 2011-05-10 06:41:18 --> Config Class Initialized
DEBUG - 2011-05-10 06:41:18 --> Hooks Class Initialized
DEBUG - 2011-05-10 06:41:18 --> Utf8 Class Initialized
DEBUG - 2011-05-10 06:41:18 --> UTF-8 Support Enabled
DEBUG - 2011-05-10 06:41:18 --> URI Class Initialized
DEBUG - 2011-05-10 06:41:18 --> Router Class Initialized
DEBUG - 2011-05-10 06:41:18 --> Output Class Initialized
DEBUG - 2011-05-10 06:41:18 --> Input Class Initialized
DEBUG - 2011-05-10 06:41:18 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-10 06:41:18 --> Language Class Initialized
DEBUG - 2011-05-10 06:41:18 --> Loader Class Initialized
DEBUG - 2011-05-10 06:41:18 --> Controller Class Initialized
DEBUG - 2011-05-10 06:41:18 --> Model Class Initialized
DEBUG - 2011-05-10 06:41:18 --> Model Class Initialized
DEBUG - 2011-05-10 06:41:18 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-10 06:41:18 --> Database Driver Class Initialized
DEBUG - 2011-05-10 06:41:18 --> Final output sent to browser
DEBUG - 2011-05-10 06:41:18 --> Total execution time: 0.4987
DEBUG - 2011-05-10 06:41:21 --> Config Class Initialized
DEBUG - 2011-05-10 06:41:21 --> Hooks Class Initialized
DEBUG - 2011-05-10 06:41:21 --> Utf8 Class Initialized
DEBUG - 2011-05-10 06:41:21 --> UTF-8 Support Enabled
DEBUG - 2011-05-10 06:41:21 --> URI Class Initialized
DEBUG - 2011-05-10 06:41:21 --> Router Class Initialized
DEBUG - 2011-05-10 06:41:21 --> Output Class Initialized
DEBUG - 2011-05-10 06:41:21 --> Input Class Initialized
DEBUG - 2011-05-10 06:41:21 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-10 06:41:21 --> Language Class Initialized
DEBUG - 2011-05-10 06:41:21 --> Loader Class Initialized
DEBUG - 2011-05-10 06:41:21 --> Controller Class Initialized
ERROR - 2011-05-10 06:41:21 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-10 06:41:21 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-10 06:41:21 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-10 06:41:21 --> Model Class Initialized
DEBUG - 2011-05-10 06:41:21 --> Model Class Initialized
DEBUG - 2011-05-10 06:41:21 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-10 06:41:21 --> Database Driver Class Initialized
DEBUG - 2011-05-10 06:41:21 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-10 06:41:21 --> Helper loaded: url_helper
DEBUG - 2011-05-10 06:41:21 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-10 06:41:21 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-10 06:41:21 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-10 06:41:21 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-10 06:41:21 --> Final output sent to browser
DEBUG - 2011-05-10 06:41:21 --> Total execution time: 0.0425
DEBUG - 2011-05-10 06:41:21 --> Config Class Initialized
DEBUG - 2011-05-10 06:41:21 --> Hooks Class Initialized
DEBUG - 2011-05-10 06:41:21 --> Utf8 Class Initialized
DEBUG - 2011-05-10 06:41:21 --> UTF-8 Support Enabled
DEBUG - 2011-05-10 06:41:21 --> URI Class Initialized
DEBUG - 2011-05-10 06:41:21 --> Router Class Initialized
DEBUG - 2011-05-10 06:41:21 --> Output Class Initialized
DEBUG - 2011-05-10 06:41:21 --> Input Class Initialized
DEBUG - 2011-05-10 06:41:21 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-10 06:41:21 --> Language Class Initialized
DEBUG - 2011-05-10 06:41:21 --> Loader Class Initialized
DEBUG - 2011-05-10 06:41:21 --> Controller Class Initialized
ERROR - 2011-05-10 06:41:21 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-10 06:41:21 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-10 06:41:21 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-10 06:41:21 --> Model Class Initialized
DEBUG - 2011-05-10 06:41:21 --> Model Class Initialized
DEBUG - 2011-05-10 06:41:21 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-10 06:41:21 --> Database Driver Class Initialized
DEBUG - 2011-05-10 06:41:21 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-10 06:41:21 --> Helper loaded: url_helper
DEBUG - 2011-05-10 06:41:21 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-10 06:41:21 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-10 06:41:21 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-10 06:41:21 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-10 06:41:21 --> Final output sent to browser
DEBUG - 2011-05-10 06:41:21 --> Total execution time: 0.0336
DEBUG - 2011-05-10 06:41:21 --> Config Class Initialized
DEBUG - 2011-05-10 06:41:21 --> Hooks Class Initialized
DEBUG - 2011-05-10 06:41:21 --> Utf8 Class Initialized
DEBUG - 2011-05-10 06:41:21 --> UTF-8 Support Enabled
DEBUG - 2011-05-10 06:41:21 --> URI Class Initialized
DEBUG - 2011-05-10 06:41:21 --> Router Class Initialized
DEBUG - 2011-05-10 06:41:21 --> Output Class Initialized
DEBUG - 2011-05-10 06:41:21 --> Input Class Initialized
DEBUG - 2011-05-10 06:41:21 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-10 06:41:21 --> Language Class Initialized
DEBUG - 2011-05-10 06:41:21 --> Loader Class Initialized
DEBUG - 2011-05-10 06:41:21 --> Controller Class Initialized
DEBUG - 2011-05-10 06:41:21 --> Model Class Initialized
DEBUG - 2011-05-10 06:41:21 --> Model Class Initialized
DEBUG - 2011-05-10 06:41:21 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-10 06:41:21 --> Database Driver Class Initialized
DEBUG - 2011-05-10 06:41:22 --> Final output sent to browser
DEBUG - 2011-05-10 06:41:22 --> Total execution time: 0.5367
DEBUG - 2011-05-10 06:41:25 --> Config Class Initialized
DEBUG - 2011-05-10 06:41:25 --> Hooks Class Initialized
DEBUG - 2011-05-10 06:41:25 --> Utf8 Class Initialized
DEBUG - 2011-05-10 06:41:25 --> UTF-8 Support Enabled
DEBUG - 2011-05-10 06:41:25 --> URI Class Initialized
DEBUG - 2011-05-10 06:41:25 --> Router Class Initialized
DEBUG - 2011-05-10 06:41:25 --> Output Class Initialized
DEBUG - 2011-05-10 06:41:25 --> Input Class Initialized
DEBUG - 2011-05-10 06:41:25 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-10 06:41:25 --> Language Class Initialized
DEBUG - 2011-05-10 06:41:25 --> Loader Class Initialized
DEBUG - 2011-05-10 06:41:25 --> Controller Class Initialized
ERROR - 2011-05-10 06:41:25 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-10 06:41:25 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-10 06:41:25 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-10 06:41:25 --> Model Class Initialized
DEBUG - 2011-05-10 06:41:25 --> Model Class Initialized
DEBUG - 2011-05-10 06:41:25 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-10 06:41:25 --> Database Driver Class Initialized
DEBUG - 2011-05-10 06:41:25 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-10 06:41:25 --> Helper loaded: url_helper
DEBUG - 2011-05-10 06:41:25 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-10 06:41:25 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-10 06:41:25 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-10 06:41:25 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-10 06:41:25 --> Final output sent to browser
DEBUG - 2011-05-10 06:41:25 --> Total execution time: 0.0363
DEBUG - 2011-05-10 06:41:26 --> Config Class Initialized
DEBUG - 2011-05-10 06:41:26 --> Hooks Class Initialized
DEBUG - 2011-05-10 06:41:26 --> Utf8 Class Initialized
DEBUG - 2011-05-10 06:41:26 --> UTF-8 Support Enabled
DEBUG - 2011-05-10 06:41:26 --> URI Class Initialized
DEBUG - 2011-05-10 06:41:26 --> Router Class Initialized
DEBUG - 2011-05-10 06:41:26 --> Output Class Initialized
DEBUG - 2011-05-10 06:41:26 --> Input Class Initialized
DEBUG - 2011-05-10 06:41:26 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-10 06:41:26 --> Language Class Initialized
DEBUG - 2011-05-10 06:41:26 --> Loader Class Initialized
DEBUG - 2011-05-10 06:41:26 --> Controller Class Initialized
DEBUG - 2011-05-10 06:41:26 --> Model Class Initialized
DEBUG - 2011-05-10 06:41:26 --> Model Class Initialized
DEBUG - 2011-05-10 06:41:26 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-10 06:41:26 --> Database Driver Class Initialized
DEBUG - 2011-05-10 06:41:28 --> Final output sent to browser
DEBUG - 2011-05-10 06:41:28 --> Total execution time: 2.0333
DEBUG - 2011-05-10 07:09:30 --> Config Class Initialized
DEBUG - 2011-05-10 07:09:30 --> Hooks Class Initialized
DEBUG - 2011-05-10 07:09:30 --> Utf8 Class Initialized
DEBUG - 2011-05-10 07:09:30 --> UTF-8 Support Enabled
DEBUG - 2011-05-10 07:09:30 --> URI Class Initialized
DEBUG - 2011-05-10 07:09:30 --> Router Class Initialized
DEBUG - 2011-05-10 07:09:30 --> Output Class Initialized
DEBUG - 2011-05-10 07:09:30 --> Input Class Initialized
DEBUG - 2011-05-10 07:09:30 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-10 07:09:30 --> Language Class Initialized
DEBUG - 2011-05-10 07:09:30 --> Loader Class Initialized
DEBUG - 2011-05-10 07:09:30 --> Controller Class Initialized
DEBUG - 2011-05-10 07:09:30 --> Model Class Initialized
DEBUG - 2011-05-10 07:09:30 --> Model Class Initialized
DEBUG - 2011-05-10 07:09:30 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-10 07:09:30 --> Database Driver Class Initialized
DEBUG - 2011-05-10 07:09:31 --> Final output sent to browser
DEBUG - 2011-05-10 07:09:31 --> Total execution time: 1.0302
DEBUG - 2011-05-10 09:12:49 --> Config Class Initialized
DEBUG - 2011-05-10 09:12:49 --> Hooks Class Initialized
DEBUG - 2011-05-10 09:12:49 --> Utf8 Class Initialized
DEBUG - 2011-05-10 09:12:49 --> UTF-8 Support Enabled
DEBUG - 2011-05-10 09:12:49 --> URI Class Initialized
DEBUG - 2011-05-10 09:12:49 --> Router Class Initialized
DEBUG - 2011-05-10 09:12:50 --> Output Class Initialized
DEBUG - 2011-05-10 09:12:50 --> Input Class Initialized
DEBUG - 2011-05-10 09:12:50 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-10 09:12:50 --> Language Class Initialized
DEBUG - 2011-05-10 09:12:50 --> Loader Class Initialized
DEBUG - 2011-05-10 09:12:50 --> Controller Class Initialized
DEBUG - 2011-05-10 09:12:51 --> Model Class Initialized
DEBUG - 2011-05-10 09:12:51 --> Model Class Initialized
DEBUG - 2011-05-10 09:12:51 --> Model Class Initialized
DEBUG - 2011-05-10 09:12:51 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-10 09:12:51 --> Database Driver Class Initialized
DEBUG - 2011-05-10 09:12:56 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-10 09:12:57 --> Helper loaded: url_helper
DEBUG - 2011-05-10 09:12:57 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-10 09:12:57 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-10 09:12:57 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-10 09:12:57 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-10 09:12:57 --> Final output sent to browser
DEBUG - 2011-05-10 09:12:57 --> Total execution time: 8.5378
DEBUG - 2011-05-10 09:55:03 --> Config Class Initialized
DEBUG - 2011-05-10 09:55:03 --> Hooks Class Initialized
DEBUG - 2011-05-10 09:55:03 --> Utf8 Class Initialized
DEBUG - 2011-05-10 09:55:03 --> UTF-8 Support Enabled
DEBUG - 2011-05-10 09:55:03 --> URI Class Initialized
DEBUG - 2011-05-10 09:55:03 --> Router Class Initialized
ERROR - 2011-05-10 09:55:03 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-05-10 10:09:15 --> Config Class Initialized
DEBUG - 2011-05-10 10:09:15 --> Hooks Class Initialized
DEBUG - 2011-05-10 10:09:15 --> Utf8 Class Initialized
DEBUG - 2011-05-10 10:09:15 --> UTF-8 Support Enabled
DEBUG - 2011-05-10 10:09:15 --> URI Class Initialized
DEBUG - 2011-05-10 10:09:15 --> Router Class Initialized
DEBUG - 2011-05-10 10:09:15 --> Output Class Initialized
DEBUG - 2011-05-10 10:09:15 --> Input Class Initialized
DEBUG - 2011-05-10 10:09:15 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-10 10:09:15 --> Language Class Initialized
DEBUG - 2011-05-10 10:09:15 --> Loader Class Initialized
DEBUG - 2011-05-10 10:09:15 --> Controller Class Initialized
ERROR - 2011-05-10 10:09:15 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-10 10:09:15 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-10 10:09:15 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-10 10:09:15 --> Model Class Initialized
DEBUG - 2011-05-10 10:09:15 --> Model Class Initialized
DEBUG - 2011-05-10 10:09:15 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-10 10:09:15 --> Database Driver Class Initialized
DEBUG - 2011-05-10 10:09:15 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-10 10:09:15 --> Helper loaded: url_helper
DEBUG - 2011-05-10 10:09:15 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-10 10:09:15 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-10 10:09:15 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-10 10:09:15 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-10 10:09:15 --> Final output sent to browser
DEBUG - 2011-05-10 10:09:15 --> Total execution time: 0.2293
DEBUG - 2011-05-10 10:09:19 --> Config Class Initialized
DEBUG - 2011-05-10 10:09:19 --> Hooks Class Initialized
DEBUG - 2011-05-10 10:09:19 --> Utf8 Class Initialized
DEBUG - 2011-05-10 10:09:19 --> UTF-8 Support Enabled
DEBUG - 2011-05-10 10:09:19 --> URI Class Initialized
DEBUG - 2011-05-10 10:09:19 --> Router Class Initialized
DEBUG - 2011-05-10 10:09:19 --> Output Class Initialized
DEBUG - 2011-05-10 10:09:19 --> Input Class Initialized
DEBUG - 2011-05-10 10:09:19 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-10 10:09:19 --> Language Class Initialized
DEBUG - 2011-05-10 10:09:19 --> Loader Class Initialized
DEBUG - 2011-05-10 10:09:19 --> Controller Class Initialized
DEBUG - 2011-05-10 10:09:19 --> Model Class Initialized
DEBUG - 2011-05-10 10:09:19 --> Model Class Initialized
DEBUG - 2011-05-10 10:09:19 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-10 10:09:19 --> Database Driver Class Initialized
DEBUG - 2011-05-10 10:09:20 --> Final output sent to browser
DEBUG - 2011-05-10 10:09:20 --> Total execution time: 1.3036
DEBUG - 2011-05-10 10:09:45 --> Config Class Initialized
DEBUG - 2011-05-10 10:09:45 --> Hooks Class Initialized
DEBUG - 2011-05-10 10:09:45 --> Utf8 Class Initialized
DEBUG - 2011-05-10 10:09:45 --> UTF-8 Support Enabled
DEBUG - 2011-05-10 10:09:45 --> URI Class Initialized
DEBUG - 2011-05-10 10:09:45 --> Router Class Initialized
DEBUG - 2011-05-10 10:09:45 --> Output Class Initialized
DEBUG - 2011-05-10 10:09:45 --> Input Class Initialized
DEBUG - 2011-05-10 10:09:45 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-10 10:09:45 --> Language Class Initialized
DEBUG - 2011-05-10 10:09:45 --> Loader Class Initialized
DEBUG - 2011-05-10 10:09:45 --> Controller Class Initialized
ERROR - 2011-05-10 10:09:45 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-10 10:09:45 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-10 10:09:45 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-10 10:09:45 --> Model Class Initialized
DEBUG - 2011-05-10 10:09:45 --> Model Class Initialized
DEBUG - 2011-05-10 10:09:45 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-10 10:09:45 --> Database Driver Class Initialized
DEBUG - 2011-05-10 10:09:45 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-10 10:09:45 --> Helper loaded: url_helper
DEBUG - 2011-05-10 10:09:45 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-10 10:09:45 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-10 10:09:45 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-10 10:09:45 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-10 10:09:45 --> Final output sent to browser
DEBUG - 2011-05-10 10:09:45 --> Total execution time: 0.1006
DEBUG - 2011-05-10 10:09:46 --> Config Class Initialized
DEBUG - 2011-05-10 10:09:46 --> Hooks Class Initialized
DEBUG - 2011-05-10 10:09:46 --> Utf8 Class Initialized
DEBUG - 2011-05-10 10:09:46 --> UTF-8 Support Enabled
DEBUG - 2011-05-10 10:09:46 --> URI Class Initialized
DEBUG - 2011-05-10 10:09:46 --> Router Class Initialized
DEBUG - 2011-05-10 10:09:46 --> Output Class Initialized
DEBUG - 2011-05-10 10:09:46 --> Input Class Initialized
DEBUG - 2011-05-10 10:09:46 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-10 10:09:46 --> Language Class Initialized
DEBUG - 2011-05-10 10:09:46 --> Loader Class Initialized
DEBUG - 2011-05-10 10:09:46 --> Controller Class Initialized
DEBUG - 2011-05-10 10:09:46 --> Model Class Initialized
DEBUG - 2011-05-10 10:09:46 --> Model Class Initialized
DEBUG - 2011-05-10 10:09:46 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-10 10:09:46 --> Database Driver Class Initialized
DEBUG - 2011-05-10 10:09:47 --> Final output sent to browser
DEBUG - 2011-05-10 10:09:47 --> Total execution time: 1.1797
DEBUG - 2011-05-10 10:09:55 --> Config Class Initialized
DEBUG - 2011-05-10 10:09:55 --> Hooks Class Initialized
DEBUG - 2011-05-10 10:09:55 --> Utf8 Class Initialized
DEBUG - 2011-05-10 10:09:55 --> UTF-8 Support Enabled
DEBUG - 2011-05-10 10:09:55 --> URI Class Initialized
DEBUG - 2011-05-10 10:09:55 --> Router Class Initialized
DEBUG - 2011-05-10 10:09:55 --> Output Class Initialized
DEBUG - 2011-05-10 10:09:55 --> Input Class Initialized
DEBUG - 2011-05-10 10:09:55 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-10 10:09:55 --> Language Class Initialized
DEBUG - 2011-05-10 10:09:55 --> Loader Class Initialized
DEBUG - 2011-05-10 10:09:55 --> Controller Class Initialized
ERROR - 2011-05-10 10:09:55 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-10 10:09:55 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-10 10:09:55 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-10 10:09:55 --> Model Class Initialized
DEBUG - 2011-05-10 10:09:55 --> Model Class Initialized
DEBUG - 2011-05-10 10:09:55 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-10 10:09:55 --> Database Driver Class Initialized
DEBUG - 2011-05-10 10:09:55 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-10 10:09:55 --> Helper loaded: url_helper
DEBUG - 2011-05-10 10:09:55 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-10 10:09:55 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-10 10:09:55 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-10 10:09:55 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-10 10:09:55 --> Final output sent to browser
DEBUG - 2011-05-10 10:09:55 --> Total execution time: 0.0282
DEBUG - 2011-05-10 10:09:56 --> Config Class Initialized
DEBUG - 2011-05-10 10:09:56 --> Hooks Class Initialized
DEBUG - 2011-05-10 10:09:56 --> Utf8 Class Initialized
DEBUG - 2011-05-10 10:09:56 --> UTF-8 Support Enabled
DEBUG - 2011-05-10 10:09:56 --> URI Class Initialized
DEBUG - 2011-05-10 10:09:56 --> Router Class Initialized
DEBUG - 2011-05-10 10:09:56 --> Output Class Initialized
DEBUG - 2011-05-10 10:09:56 --> Input Class Initialized
DEBUG - 2011-05-10 10:09:56 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-10 10:09:56 --> Language Class Initialized
DEBUG - 2011-05-10 10:09:56 --> Loader Class Initialized
DEBUG - 2011-05-10 10:09:56 --> Controller Class Initialized
DEBUG - 2011-05-10 10:09:56 --> Model Class Initialized
DEBUG - 2011-05-10 10:09:56 --> Model Class Initialized
DEBUG - 2011-05-10 10:09:56 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-10 10:09:56 --> Database Driver Class Initialized
DEBUG - 2011-05-10 10:09:57 --> Final output sent to browser
DEBUG - 2011-05-10 10:09:57 --> Total execution time: 0.7994
DEBUG - 2011-05-10 10:10:04 --> Config Class Initialized
DEBUG - 2011-05-10 10:10:04 --> Hooks Class Initialized
DEBUG - 2011-05-10 10:10:04 --> Utf8 Class Initialized
DEBUG - 2011-05-10 10:10:04 --> UTF-8 Support Enabled
DEBUG - 2011-05-10 10:10:04 --> URI Class Initialized
DEBUG - 2011-05-10 10:10:04 --> Router Class Initialized
DEBUG - 2011-05-10 10:10:04 --> Output Class Initialized
DEBUG - 2011-05-10 10:10:04 --> Input Class Initialized
DEBUG - 2011-05-10 10:10:04 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-10 10:10:04 --> Language Class Initialized
DEBUG - 2011-05-10 10:10:04 --> Loader Class Initialized
DEBUG - 2011-05-10 10:10:04 --> Controller Class Initialized
ERROR - 2011-05-10 10:10:04 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-10 10:10:04 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-10 10:10:04 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-10 10:10:04 --> Model Class Initialized
DEBUG - 2011-05-10 10:10:04 --> Model Class Initialized
DEBUG - 2011-05-10 10:10:04 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-10 10:10:04 --> Database Driver Class Initialized
DEBUG - 2011-05-10 10:10:04 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-10 10:10:04 --> Helper loaded: url_helper
DEBUG - 2011-05-10 10:10:04 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-10 10:10:04 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-10 10:10:04 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-10 10:10:04 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-10 10:10:04 --> Final output sent to browser
DEBUG - 2011-05-10 10:10:04 --> Total execution time: 0.1027
DEBUG - 2011-05-10 10:10:05 --> Config Class Initialized
DEBUG - 2011-05-10 10:10:05 --> Hooks Class Initialized
DEBUG - 2011-05-10 10:10:05 --> Utf8 Class Initialized
DEBUG - 2011-05-10 10:10:05 --> UTF-8 Support Enabled
DEBUG - 2011-05-10 10:10:05 --> URI Class Initialized
DEBUG - 2011-05-10 10:10:05 --> Router Class Initialized
DEBUG - 2011-05-10 10:10:05 --> Output Class Initialized
DEBUG - 2011-05-10 10:10:05 --> Input Class Initialized
DEBUG - 2011-05-10 10:10:05 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-10 10:10:05 --> Language Class Initialized
DEBUG - 2011-05-10 10:10:05 --> Loader Class Initialized
DEBUG - 2011-05-10 10:10:05 --> Controller Class Initialized
DEBUG - 2011-05-10 10:10:05 --> Model Class Initialized
DEBUG - 2011-05-10 10:10:05 --> Model Class Initialized
DEBUG - 2011-05-10 10:10:05 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-10 10:10:05 --> Database Driver Class Initialized
DEBUG - 2011-05-10 10:10:07 --> Final output sent to browser
DEBUG - 2011-05-10 10:10:07 --> Total execution time: 1.4888
DEBUG - 2011-05-10 10:10:17 --> Config Class Initialized
DEBUG - 2011-05-10 10:10:17 --> Hooks Class Initialized
DEBUG - 2011-05-10 10:10:17 --> Utf8 Class Initialized
DEBUG - 2011-05-10 10:10:17 --> UTF-8 Support Enabled
DEBUG - 2011-05-10 10:10:17 --> URI Class Initialized
DEBUG - 2011-05-10 10:10:17 --> Router Class Initialized
DEBUG - 2011-05-10 10:10:17 --> Output Class Initialized
DEBUG - 2011-05-10 10:10:17 --> Input Class Initialized
DEBUG - 2011-05-10 10:10:17 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-10 10:10:17 --> Language Class Initialized
DEBUG - 2011-05-10 10:10:17 --> Loader Class Initialized
DEBUG - 2011-05-10 10:10:17 --> Controller Class Initialized
ERROR - 2011-05-10 10:10:17 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-10 10:10:17 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-10 10:10:17 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-10 10:10:17 --> Model Class Initialized
DEBUG - 2011-05-10 10:10:17 --> Model Class Initialized
DEBUG - 2011-05-10 10:10:17 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-10 10:10:17 --> Database Driver Class Initialized
DEBUG - 2011-05-10 10:10:17 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-10 10:10:17 --> Helper loaded: url_helper
DEBUG - 2011-05-10 10:10:17 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-10 10:10:17 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-10 10:10:17 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-10 10:10:17 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-10 10:10:17 --> Final output sent to browser
DEBUG - 2011-05-10 10:10:17 --> Total execution time: 0.0293
DEBUG - 2011-05-10 10:10:18 --> Config Class Initialized
DEBUG - 2011-05-10 10:10:18 --> Hooks Class Initialized
DEBUG - 2011-05-10 10:10:18 --> Utf8 Class Initialized
DEBUG - 2011-05-10 10:10:18 --> UTF-8 Support Enabled
DEBUG - 2011-05-10 10:10:18 --> URI Class Initialized
DEBUG - 2011-05-10 10:10:18 --> Router Class Initialized
DEBUG - 2011-05-10 10:10:18 --> Output Class Initialized
DEBUG - 2011-05-10 10:10:18 --> Input Class Initialized
DEBUG - 2011-05-10 10:10:18 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-10 10:10:18 --> Language Class Initialized
DEBUG - 2011-05-10 10:10:18 --> Loader Class Initialized
DEBUG - 2011-05-10 10:10:18 --> Controller Class Initialized
DEBUG - 2011-05-10 10:10:18 --> Model Class Initialized
DEBUG - 2011-05-10 10:10:18 --> Model Class Initialized
DEBUG - 2011-05-10 10:10:18 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-10 10:10:18 --> Database Driver Class Initialized
DEBUG - 2011-05-10 10:10:24 --> Config Class Initialized
DEBUG - 2011-05-10 10:10:24 --> Hooks Class Initialized
DEBUG - 2011-05-10 10:10:24 --> Utf8 Class Initialized
DEBUG - 2011-05-10 10:10:24 --> UTF-8 Support Enabled
DEBUG - 2011-05-10 10:10:24 --> URI Class Initialized
DEBUG - 2011-05-10 10:10:24 --> Router Class Initialized
DEBUG - 2011-05-10 10:10:24 --> Output Class Initialized
DEBUG - 2011-05-10 10:10:24 --> Input Class Initialized
DEBUG - 2011-05-10 10:10:24 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-10 10:10:24 --> Language Class Initialized
DEBUG - 2011-05-10 10:10:24 --> Loader Class Initialized
DEBUG - 2011-05-10 10:10:24 --> Controller Class Initialized
ERROR - 2011-05-10 10:10:24 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-10 10:10:24 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-10 10:10:24 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-10 10:10:24 --> Model Class Initialized
DEBUG - 2011-05-10 10:10:24 --> Model Class Initialized
DEBUG - 2011-05-10 10:10:24 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-10 10:10:24 --> Database Driver Class Initialized
DEBUG - 2011-05-10 10:10:24 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-10 10:10:24 --> Helper loaded: url_helper
DEBUG - 2011-05-10 10:10:24 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-10 10:10:24 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-10 10:10:24 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-10 10:10:24 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-10 10:10:24 --> Final output sent to browser
DEBUG - 2011-05-10 10:10:24 --> Total execution time: 0.1095
DEBUG - 2011-05-10 10:10:24 --> Final output sent to browser
DEBUG - 2011-05-10 10:10:24 --> Total execution time: 6.4201
DEBUG - 2011-05-10 10:10:25 --> Config Class Initialized
DEBUG - 2011-05-10 10:10:25 --> Hooks Class Initialized
DEBUG - 2011-05-10 10:10:25 --> Utf8 Class Initialized
DEBUG - 2011-05-10 10:10:25 --> UTF-8 Support Enabled
DEBUG - 2011-05-10 10:10:25 --> URI Class Initialized
DEBUG - 2011-05-10 10:10:25 --> Router Class Initialized
DEBUG - 2011-05-10 10:10:25 --> Output Class Initialized
DEBUG - 2011-05-10 10:10:25 --> Input Class Initialized
DEBUG - 2011-05-10 10:10:25 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-10 10:10:25 --> Language Class Initialized
DEBUG - 2011-05-10 10:10:25 --> Loader Class Initialized
DEBUG - 2011-05-10 10:10:25 --> Controller Class Initialized
DEBUG - 2011-05-10 10:10:25 --> Model Class Initialized
DEBUG - 2011-05-10 10:10:25 --> Model Class Initialized
DEBUG - 2011-05-10 10:10:25 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-10 10:10:25 --> Database Driver Class Initialized
DEBUG - 2011-05-10 10:10:26 --> Final output sent to browser
DEBUG - 2011-05-10 10:10:26 --> Total execution time: 1.2058
DEBUG - 2011-05-10 14:06:34 --> Config Class Initialized
DEBUG - 2011-05-10 14:06:34 --> Hooks Class Initialized
DEBUG - 2011-05-10 14:06:34 --> Utf8 Class Initialized
DEBUG - 2011-05-10 14:06:34 --> UTF-8 Support Enabled
DEBUG - 2011-05-10 14:06:34 --> URI Class Initialized
DEBUG - 2011-05-10 14:06:34 --> Router Class Initialized
ERROR - 2011-05-10 14:06:34 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-05-10 14:06:37 --> Config Class Initialized
DEBUG - 2011-05-10 14:06:37 --> Hooks Class Initialized
DEBUG - 2011-05-10 14:06:37 --> Utf8 Class Initialized
DEBUG - 2011-05-10 14:06:37 --> UTF-8 Support Enabled
DEBUG - 2011-05-10 14:06:37 --> URI Class Initialized
DEBUG - 2011-05-10 14:06:37 --> Router Class Initialized
DEBUG - 2011-05-10 14:06:38 --> Output Class Initialized
DEBUG - 2011-05-10 14:06:38 --> Input Class Initialized
DEBUG - 2011-05-10 14:06:38 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-10 14:06:38 --> Language Class Initialized
DEBUG - 2011-05-10 14:06:38 --> Loader Class Initialized
DEBUG - 2011-05-10 14:06:38 --> Controller Class Initialized
ERROR - 2011-05-10 14:06:38 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-10 14:06:38 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-10 14:06:38 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-10 14:06:38 --> Model Class Initialized
DEBUG - 2011-05-10 14:06:38 --> Model Class Initialized
DEBUG - 2011-05-10 14:06:38 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-10 14:06:38 --> Database Driver Class Initialized
DEBUG - 2011-05-10 14:06:38 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-10 14:06:39 --> Helper loaded: url_helper
DEBUG - 2011-05-10 14:06:39 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-10 14:06:39 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-10 14:06:39 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-10 14:06:39 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-10 14:06:39 --> Final output sent to browser
DEBUG - 2011-05-10 14:06:39 --> Total execution time: 1.7310
DEBUG - 2011-05-10 14:06:44 --> Config Class Initialized
DEBUG - 2011-05-10 14:06:44 --> Hooks Class Initialized
DEBUG - 2011-05-10 14:06:44 --> Utf8 Class Initialized
DEBUG - 2011-05-10 14:06:44 --> UTF-8 Support Enabled
DEBUG - 2011-05-10 14:06:44 --> URI Class Initialized
DEBUG - 2011-05-10 14:06:44 --> Router Class Initialized
ERROR - 2011-05-10 14:06:44 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-05-10 14:06:47 --> Config Class Initialized
DEBUG - 2011-05-10 14:06:47 --> Hooks Class Initialized
DEBUG - 2011-05-10 14:06:47 --> Utf8 Class Initialized
DEBUG - 2011-05-10 14:06:47 --> UTF-8 Support Enabled
DEBUG - 2011-05-10 14:06:47 --> URI Class Initialized
DEBUG - 2011-05-10 14:06:47 --> Router Class Initialized
DEBUG - 2011-05-10 14:06:47 --> Output Class Initialized
DEBUG - 2011-05-10 14:06:47 --> Input Class Initialized
DEBUG - 2011-05-10 14:06:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-10 14:06:47 --> Language Class Initialized
DEBUG - 2011-05-10 14:06:47 --> Loader Class Initialized
DEBUG - 2011-05-10 14:06:47 --> Controller Class Initialized
ERROR - 2011-05-10 14:06:47 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-10 14:06:47 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-10 14:06:47 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-10 14:06:47 --> Model Class Initialized
DEBUG - 2011-05-10 14:06:47 --> Model Class Initialized
DEBUG - 2011-05-10 14:06:47 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-10 14:06:47 --> Database Driver Class Initialized
DEBUG - 2011-05-10 14:06:47 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-10 14:06:47 --> Helper loaded: url_helper
DEBUG - 2011-05-10 14:06:47 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-10 14:06:47 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-10 14:06:47 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-10 14:06:47 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-10 14:06:47 --> Final output sent to browser
DEBUG - 2011-05-10 14:06:47 --> Total execution time: 0.1177
DEBUG - 2011-05-10 15:20:46 --> Config Class Initialized
DEBUG - 2011-05-10 15:20:46 --> Hooks Class Initialized
DEBUG - 2011-05-10 15:20:46 --> Utf8 Class Initialized
DEBUG - 2011-05-10 15:20:46 --> UTF-8 Support Enabled
DEBUG - 2011-05-10 15:20:46 --> URI Class Initialized
DEBUG - 2011-05-10 15:20:46 --> Router Class Initialized
DEBUG - 2011-05-10 15:20:46 --> Output Class Initialized
DEBUG - 2011-05-10 15:20:46 --> Input Class Initialized
DEBUG - 2011-05-10 15:20:46 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-10 15:20:46 --> Language Class Initialized
DEBUG - 2011-05-10 15:20:46 --> Loader Class Initialized
DEBUG - 2011-05-10 15:20:46 --> Controller Class Initialized
DEBUG - 2011-05-10 15:20:46 --> Model Class Initialized
DEBUG - 2011-05-10 15:20:46 --> Model Class Initialized
DEBUG - 2011-05-10 15:20:46 --> Model Class Initialized
DEBUG - 2011-05-10 15:20:46 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-10 15:20:46 --> Database Driver Class Initialized
DEBUG - 2011-05-10 15:20:47 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-10 15:20:47 --> Helper loaded: url_helper
DEBUG - 2011-05-10 15:20:47 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-10 15:20:47 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-10 15:20:47 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-10 15:20:47 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-10 15:20:47 --> Final output sent to browser
DEBUG - 2011-05-10 15:20:47 --> Total execution time: 0.8298
DEBUG - 2011-05-10 15:20:54 --> Config Class Initialized
DEBUG - 2011-05-10 15:20:54 --> Hooks Class Initialized
DEBUG - 2011-05-10 15:20:54 --> Utf8 Class Initialized
DEBUG - 2011-05-10 15:20:54 --> UTF-8 Support Enabled
DEBUG - 2011-05-10 15:20:54 --> URI Class Initialized
DEBUG - 2011-05-10 15:20:54 --> Router Class Initialized
ERROR - 2011-05-10 15:20:54 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-10 15:21:21 --> Config Class Initialized
DEBUG - 2011-05-10 15:21:21 --> Hooks Class Initialized
DEBUG - 2011-05-10 15:21:21 --> Utf8 Class Initialized
DEBUG - 2011-05-10 15:21:21 --> UTF-8 Support Enabled
DEBUG - 2011-05-10 15:21:21 --> URI Class Initialized
DEBUG - 2011-05-10 15:21:21 --> Router Class Initialized
DEBUG - 2011-05-10 15:21:21 --> Output Class Initialized
DEBUG - 2011-05-10 15:21:21 --> Input Class Initialized
DEBUG - 2011-05-10 15:21:21 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-10 15:21:21 --> Language Class Initialized
DEBUG - 2011-05-10 15:21:21 --> Loader Class Initialized
DEBUG - 2011-05-10 15:21:21 --> Controller Class Initialized
DEBUG - 2011-05-10 15:21:21 --> Model Class Initialized
DEBUG - 2011-05-10 15:21:21 --> Model Class Initialized
DEBUG - 2011-05-10 15:21:21 --> Model Class Initialized
DEBUG - 2011-05-10 15:21:21 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-10 15:21:21 --> Database Driver Class Initialized
DEBUG - 2011-05-10 15:21:21 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-10 15:21:21 --> Helper loaded: url_helper
DEBUG - 2011-05-10 15:21:21 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-10 15:21:21 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-10 15:21:21 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-10 15:21:21 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-10 15:21:21 --> Final output sent to browser
DEBUG - 2011-05-10 15:21:21 --> Total execution time: 0.2528
DEBUG - 2011-05-10 15:21:23 --> Config Class Initialized
DEBUG - 2011-05-10 15:21:23 --> Hooks Class Initialized
DEBUG - 2011-05-10 15:21:23 --> Utf8 Class Initialized
DEBUG - 2011-05-10 15:21:23 --> UTF-8 Support Enabled
DEBUG - 2011-05-10 15:21:23 --> URI Class Initialized
DEBUG - 2011-05-10 15:21:23 --> Router Class Initialized
ERROR - 2011-05-10 15:21:23 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-05-10 15:21:23 --> Config Class Initialized
DEBUG - 2011-05-10 15:21:23 --> Hooks Class Initialized
DEBUG - 2011-05-10 15:21:23 --> Utf8 Class Initialized
DEBUG - 2011-05-10 15:21:23 --> UTF-8 Support Enabled
DEBUG - 2011-05-10 15:21:23 --> URI Class Initialized
DEBUG - 2011-05-10 15:21:23 --> Router Class Initialized
DEBUG - 2011-05-10 15:21:23 --> Output Class Initialized
DEBUG - 2011-05-10 15:21:23 --> Input Class Initialized
DEBUG - 2011-05-10 15:21:23 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-10 15:21:23 --> Language Class Initialized
DEBUG - 2011-05-10 15:21:23 --> Loader Class Initialized
DEBUG - 2011-05-10 15:21:23 --> Controller Class Initialized
DEBUG - 2011-05-10 15:21:23 --> Model Class Initialized
DEBUG - 2011-05-10 15:21:23 --> Model Class Initialized
DEBUG - 2011-05-10 15:21:23 --> Model Class Initialized
DEBUG - 2011-05-10 15:21:23 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-10 15:21:23 --> Database Driver Class Initialized
DEBUG - 2011-05-10 15:21:23 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-10 15:21:23 --> Helper loaded: url_helper
DEBUG - 2011-05-10 15:21:23 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-10 15:21:23 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-10 15:21:23 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-10 15:21:23 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-10 15:21:23 --> Final output sent to browser
DEBUG - 2011-05-10 15:21:23 --> Total execution time: 0.0471
DEBUG - 2011-05-10 15:21:55 --> Config Class Initialized
DEBUG - 2011-05-10 15:21:55 --> Hooks Class Initialized
DEBUG - 2011-05-10 15:21:55 --> Utf8 Class Initialized
DEBUG - 2011-05-10 15:21:55 --> UTF-8 Support Enabled
DEBUG - 2011-05-10 15:21:55 --> URI Class Initialized
DEBUG - 2011-05-10 15:21:55 --> Router Class Initialized
DEBUG - 2011-05-10 15:21:55 --> Output Class Initialized
DEBUG - 2011-05-10 15:21:55 --> Input Class Initialized
DEBUG - 2011-05-10 15:21:55 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-10 15:21:55 --> Language Class Initialized
DEBUG - 2011-05-10 15:21:55 --> Loader Class Initialized
DEBUG - 2011-05-10 15:21:55 --> Controller Class Initialized
DEBUG - 2011-05-10 15:21:55 --> Model Class Initialized
DEBUG - 2011-05-10 15:21:55 --> Model Class Initialized
DEBUG - 2011-05-10 15:21:55 --> Model Class Initialized
DEBUG - 2011-05-10 15:21:55 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-10 15:21:55 --> Database Driver Class Initialized
DEBUG - 2011-05-10 15:21:55 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-10 15:21:55 --> Helper loaded: url_helper
DEBUG - 2011-05-10 15:21:55 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-10 15:21:55 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-10 15:21:55 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-10 15:21:55 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-10 15:21:55 --> Final output sent to browser
DEBUG - 2011-05-10 15:21:55 --> Total execution time: 0.0925
DEBUG - 2011-05-10 16:31:13 --> Config Class Initialized
DEBUG - 2011-05-10 16:31:13 --> Hooks Class Initialized
DEBUG - 2011-05-10 16:31:13 --> Utf8 Class Initialized
DEBUG - 2011-05-10 16:31:13 --> UTF-8 Support Enabled
DEBUG - 2011-05-10 16:31:13 --> URI Class Initialized
DEBUG - 2011-05-10 16:31:13 --> Router Class Initialized
DEBUG - 2011-05-10 16:31:13 --> Output Class Initialized
DEBUG - 2011-05-10 16:31:13 --> Input Class Initialized
DEBUG - 2011-05-10 16:31:13 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-10 16:31:13 --> Language Class Initialized
DEBUG - 2011-05-10 16:31:13 --> Loader Class Initialized
DEBUG - 2011-05-10 16:31:13 --> Controller Class Initialized
ERROR - 2011-05-10 16:31:13 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-10 16:31:13 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-10 16:31:13 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-10 16:31:13 --> Model Class Initialized
DEBUG - 2011-05-10 16:31:13 --> Model Class Initialized
DEBUG - 2011-05-10 16:31:13 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-10 16:31:13 --> Database Driver Class Initialized
DEBUG - 2011-05-10 16:31:13 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-10 16:31:13 --> Helper loaded: url_helper
DEBUG - 2011-05-10 16:31:13 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-10 16:31:13 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-10 16:31:13 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-10 16:31:13 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-10 16:31:13 --> Final output sent to browser
DEBUG - 2011-05-10 16:31:13 --> Total execution time: 0.3237
DEBUG - 2011-05-10 16:31:18 --> Config Class Initialized
DEBUG - 2011-05-10 16:31:18 --> Hooks Class Initialized
DEBUG - 2011-05-10 16:31:18 --> Utf8 Class Initialized
DEBUG - 2011-05-10 16:31:18 --> UTF-8 Support Enabled
DEBUG - 2011-05-10 16:31:18 --> URI Class Initialized
DEBUG - 2011-05-10 16:31:18 --> Router Class Initialized
DEBUG - 2011-05-10 16:31:18 --> Output Class Initialized
DEBUG - 2011-05-10 16:31:18 --> Input Class Initialized
DEBUG - 2011-05-10 16:31:18 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-10 16:31:18 --> Language Class Initialized
DEBUG - 2011-05-10 16:31:18 --> Loader Class Initialized
DEBUG - 2011-05-10 16:31:18 --> Controller Class Initialized
DEBUG - 2011-05-10 16:31:18 --> Model Class Initialized
DEBUG - 2011-05-10 16:31:18 --> Model Class Initialized
DEBUG - 2011-05-10 16:31:18 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-10 16:31:18 --> Database Driver Class Initialized
DEBUG - 2011-05-10 16:31:18 --> Final output sent to browser
DEBUG - 2011-05-10 16:31:18 --> Total execution time: 0.6886
DEBUG - 2011-05-10 16:31:23 --> Config Class Initialized
DEBUG - 2011-05-10 16:31:23 --> Hooks Class Initialized
DEBUG - 2011-05-10 16:31:23 --> Utf8 Class Initialized
DEBUG - 2011-05-10 16:31:23 --> UTF-8 Support Enabled
DEBUG - 2011-05-10 16:31:23 --> URI Class Initialized
DEBUG - 2011-05-10 16:31:23 --> Router Class Initialized
ERROR - 2011-05-10 16:31:23 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-10 16:35:49 --> Config Class Initialized
DEBUG - 2011-05-10 16:35:49 --> Hooks Class Initialized
DEBUG - 2011-05-10 16:35:49 --> Utf8 Class Initialized
DEBUG - 2011-05-10 16:35:49 --> UTF-8 Support Enabled
DEBUG - 2011-05-10 16:35:49 --> URI Class Initialized
DEBUG - 2011-05-10 16:35:49 --> Router Class Initialized
DEBUG - 2011-05-10 16:35:49 --> Output Class Initialized
DEBUG - 2011-05-10 16:35:49 --> Input Class Initialized
DEBUG - 2011-05-10 16:35:49 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-10 16:35:49 --> Language Class Initialized
DEBUG - 2011-05-10 16:35:49 --> Loader Class Initialized
DEBUG - 2011-05-10 16:35:49 --> Controller Class Initialized
ERROR - 2011-05-10 16:35:49 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-10 16:35:49 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-10 16:35:49 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-10 16:35:49 --> Model Class Initialized
DEBUG - 2011-05-10 16:35:49 --> Model Class Initialized
DEBUG - 2011-05-10 16:35:49 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-10 16:35:49 --> Database Driver Class Initialized
DEBUG - 2011-05-10 16:35:49 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-10 16:35:49 --> Helper loaded: url_helper
DEBUG - 2011-05-10 16:35:49 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-10 16:35:49 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-10 16:35:49 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-10 16:35:49 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-10 16:35:49 --> Final output sent to browser
DEBUG - 2011-05-10 16:35:49 --> Total execution time: 0.0589
DEBUG - 2011-05-10 16:35:50 --> Config Class Initialized
DEBUG - 2011-05-10 16:35:50 --> Hooks Class Initialized
DEBUG - 2011-05-10 16:35:50 --> Utf8 Class Initialized
DEBUG - 2011-05-10 16:35:50 --> UTF-8 Support Enabled
DEBUG - 2011-05-10 16:35:50 --> URI Class Initialized
DEBUG - 2011-05-10 16:35:50 --> Router Class Initialized
DEBUG - 2011-05-10 16:35:50 --> Output Class Initialized
DEBUG - 2011-05-10 16:35:50 --> Input Class Initialized
DEBUG - 2011-05-10 16:35:50 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-10 16:35:50 --> Language Class Initialized
DEBUG - 2011-05-10 16:35:50 --> Loader Class Initialized
DEBUG - 2011-05-10 16:35:50 --> Controller Class Initialized
DEBUG - 2011-05-10 16:35:50 --> Model Class Initialized
DEBUG - 2011-05-10 16:35:50 --> Model Class Initialized
DEBUG - 2011-05-10 16:35:50 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-10 16:35:50 --> Database Driver Class Initialized
DEBUG - 2011-05-10 16:35:51 --> Final output sent to browser
DEBUG - 2011-05-10 16:35:51 --> Total execution time: 0.7232
DEBUG - 2011-05-10 16:35:52 --> Config Class Initialized
DEBUG - 2011-05-10 16:35:52 --> Hooks Class Initialized
DEBUG - 2011-05-10 16:35:52 --> Utf8 Class Initialized
DEBUG - 2011-05-10 16:35:52 --> UTF-8 Support Enabled
DEBUG - 2011-05-10 16:35:52 --> URI Class Initialized
DEBUG - 2011-05-10 16:35:52 --> Router Class Initialized
ERROR - 2011-05-10 16:35:52 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-10 16:35:53 --> Config Class Initialized
DEBUG - 2011-05-10 16:35:53 --> Hooks Class Initialized
DEBUG - 2011-05-10 16:35:53 --> Utf8 Class Initialized
DEBUG - 2011-05-10 16:35:53 --> UTF-8 Support Enabled
DEBUG - 2011-05-10 16:35:53 --> URI Class Initialized
DEBUG - 2011-05-10 16:35:53 --> Router Class Initialized
ERROR - 2011-05-10 16:35:53 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-10 16:36:30 --> Config Class Initialized
DEBUG - 2011-05-10 16:36:30 --> Hooks Class Initialized
DEBUG - 2011-05-10 16:36:30 --> Utf8 Class Initialized
DEBUG - 2011-05-10 16:36:30 --> UTF-8 Support Enabled
DEBUG - 2011-05-10 16:36:30 --> URI Class Initialized
DEBUG - 2011-05-10 16:36:30 --> Router Class Initialized
DEBUG - 2011-05-10 16:36:30 --> Output Class Initialized
DEBUG - 2011-05-10 16:36:30 --> Input Class Initialized
DEBUG - 2011-05-10 16:36:30 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-10 16:36:30 --> Language Class Initialized
DEBUG - 2011-05-10 16:36:30 --> Loader Class Initialized
DEBUG - 2011-05-10 16:36:30 --> Controller Class Initialized
ERROR - 2011-05-10 16:36:30 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-10 16:36:30 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-10 16:36:30 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-10 16:36:30 --> Model Class Initialized
DEBUG - 2011-05-10 16:36:30 --> Model Class Initialized
DEBUG - 2011-05-10 16:36:30 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-10 16:36:30 --> Database Driver Class Initialized
DEBUG - 2011-05-10 16:36:30 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-10 16:36:30 --> Helper loaded: url_helper
DEBUG - 2011-05-10 16:36:30 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-10 16:36:30 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-10 16:36:30 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-10 16:36:30 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-10 16:36:30 --> Final output sent to browser
DEBUG - 2011-05-10 16:36:30 --> Total execution time: 0.0309
DEBUG - 2011-05-10 16:36:30 --> Config Class Initialized
DEBUG - 2011-05-10 16:36:30 --> Hooks Class Initialized
DEBUG - 2011-05-10 16:36:30 --> Utf8 Class Initialized
DEBUG - 2011-05-10 16:36:30 --> UTF-8 Support Enabled
DEBUG - 2011-05-10 16:36:30 --> URI Class Initialized
DEBUG - 2011-05-10 16:36:30 --> Router Class Initialized
DEBUG - 2011-05-10 16:36:30 --> Output Class Initialized
DEBUG - 2011-05-10 16:36:30 --> Input Class Initialized
DEBUG - 2011-05-10 16:36:30 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-10 16:36:30 --> Language Class Initialized
DEBUG - 2011-05-10 16:36:30 --> Loader Class Initialized
DEBUG - 2011-05-10 16:36:30 --> Controller Class Initialized
DEBUG - 2011-05-10 16:36:30 --> Model Class Initialized
DEBUG - 2011-05-10 16:36:30 --> Model Class Initialized
DEBUG - 2011-05-10 16:36:30 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-10 16:36:30 --> Database Driver Class Initialized
DEBUG - 2011-05-10 16:36:31 --> Final output sent to browser
DEBUG - 2011-05-10 16:36:31 --> Total execution time: 0.6211
DEBUG - 2011-05-10 16:36:31 --> Config Class Initialized
DEBUG - 2011-05-10 16:36:31 --> Hooks Class Initialized
DEBUG - 2011-05-10 16:36:31 --> Utf8 Class Initialized
DEBUG - 2011-05-10 16:36:31 --> UTF-8 Support Enabled
DEBUG - 2011-05-10 16:36:31 --> URI Class Initialized
DEBUG - 2011-05-10 16:36:31 --> Router Class Initialized
DEBUG - 2011-05-10 16:36:31 --> Output Class Initialized
DEBUG - 2011-05-10 16:36:31 --> Input Class Initialized
DEBUG - 2011-05-10 16:36:31 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-10 16:36:31 --> Language Class Initialized
DEBUG - 2011-05-10 16:36:31 --> Loader Class Initialized
DEBUG - 2011-05-10 16:36:31 --> Controller Class Initialized
ERROR - 2011-05-10 16:36:31 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-10 16:36:31 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-10 16:36:31 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-10 16:36:31 --> Model Class Initialized
DEBUG - 2011-05-10 16:36:31 --> Model Class Initialized
DEBUG - 2011-05-10 16:36:31 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-10 16:36:31 --> Database Driver Class Initialized
DEBUG - 2011-05-10 16:36:31 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-10 16:36:31 --> Helper loaded: url_helper
DEBUG - 2011-05-10 16:36:31 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-10 16:36:31 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-10 16:36:31 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-10 16:36:31 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-10 16:36:31 --> Final output sent to browser
DEBUG - 2011-05-10 16:36:31 --> Total execution time: 0.0277
DEBUG - 2011-05-10 16:58:51 --> Config Class Initialized
DEBUG - 2011-05-10 16:58:51 --> Hooks Class Initialized
DEBUG - 2011-05-10 16:58:51 --> Utf8 Class Initialized
DEBUG - 2011-05-10 16:58:51 --> UTF-8 Support Enabled
DEBUG - 2011-05-10 16:58:51 --> URI Class Initialized
DEBUG - 2011-05-10 16:58:51 --> Router Class Initialized
DEBUG - 2011-05-10 16:58:51 --> Output Class Initialized
DEBUG - 2011-05-10 16:58:51 --> Input Class Initialized
DEBUG - 2011-05-10 16:58:51 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-10 16:58:51 --> Language Class Initialized
DEBUG - 2011-05-10 16:58:51 --> Loader Class Initialized
DEBUG - 2011-05-10 16:58:51 --> Controller Class Initialized
ERROR - 2011-05-10 16:58:51 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-10 16:58:51 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-10 16:58:51 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-10 16:58:51 --> Model Class Initialized
DEBUG - 2011-05-10 16:58:51 --> Model Class Initialized
DEBUG - 2011-05-10 16:58:51 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-10 16:58:51 --> Database Driver Class Initialized
DEBUG - 2011-05-10 16:58:51 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-10 16:58:51 --> Helper loaded: url_helper
DEBUG - 2011-05-10 16:58:51 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-10 16:58:51 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-10 16:58:51 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-10 16:58:51 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-10 16:58:51 --> Final output sent to browser
DEBUG - 2011-05-10 16:58:51 --> Total execution time: 0.0897
DEBUG - 2011-05-10 18:04:57 --> Config Class Initialized
DEBUG - 2011-05-10 18:04:57 --> Hooks Class Initialized
DEBUG - 2011-05-10 18:04:57 --> Utf8 Class Initialized
DEBUG - 2011-05-10 18:04:57 --> UTF-8 Support Enabled
DEBUG - 2011-05-10 18:04:57 --> URI Class Initialized
DEBUG - 2011-05-10 18:04:57 --> Router Class Initialized
DEBUG - 2011-05-10 18:04:57 --> Output Class Initialized
DEBUG - 2011-05-10 18:04:57 --> Input Class Initialized
DEBUG - 2011-05-10 18:04:57 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-10 18:04:57 --> Language Class Initialized
DEBUG - 2011-05-10 18:04:57 --> Loader Class Initialized
DEBUG - 2011-05-10 18:04:57 --> Controller Class Initialized
DEBUG - 2011-05-10 18:04:57 --> Model Class Initialized
DEBUG - 2011-05-10 18:04:57 --> Model Class Initialized
DEBUG - 2011-05-10 18:04:57 --> Model Class Initialized
DEBUG - 2011-05-10 18:04:57 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-10 18:04:57 --> Database Driver Class Initialized
DEBUG - 2011-05-10 18:04:57 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-10 18:04:57 --> Helper loaded: url_helper
DEBUG - 2011-05-10 18:04:57 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-10 18:04:57 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-10 18:04:57 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-10 18:04:57 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-10 18:04:57 --> Final output sent to browser
DEBUG - 2011-05-10 18:04:57 --> Total execution time: 0.4979
DEBUG - 2011-05-10 18:04:59 --> Config Class Initialized
DEBUG - 2011-05-10 18:04:59 --> Hooks Class Initialized
DEBUG - 2011-05-10 18:04:59 --> Utf8 Class Initialized
DEBUG - 2011-05-10 18:04:59 --> UTF-8 Support Enabled
DEBUG - 2011-05-10 18:04:59 --> URI Class Initialized
DEBUG - 2011-05-10 18:04:59 --> Router Class Initialized
ERROR - 2011-05-10 18:04:59 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-10 20:16:35 --> Config Class Initialized
DEBUG - 2011-05-10 20:16:35 --> Hooks Class Initialized
DEBUG - 2011-05-10 20:16:35 --> Utf8 Class Initialized
DEBUG - 2011-05-10 20:16:35 --> UTF-8 Support Enabled
DEBUG - 2011-05-10 20:16:35 --> URI Class Initialized
DEBUG - 2011-05-10 20:16:35 --> Router Class Initialized
DEBUG - 2011-05-10 20:16:35 --> Output Class Initialized
DEBUG - 2011-05-10 20:16:35 --> Input Class Initialized
DEBUG - 2011-05-10 20:16:35 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-10 20:16:35 --> Language Class Initialized
DEBUG - 2011-05-10 20:16:35 --> Loader Class Initialized
DEBUG - 2011-05-10 20:16:35 --> Controller Class Initialized
DEBUG - 2011-05-10 20:16:35 --> Model Class Initialized
DEBUG - 2011-05-10 20:16:35 --> Model Class Initialized
DEBUG - 2011-05-10 20:16:35 --> Model Class Initialized
DEBUG - 2011-05-10 20:16:35 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-10 20:16:35 --> Database Driver Class Initialized
DEBUG - 2011-05-10 20:16:35 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-10 20:16:35 --> Helper loaded: url_helper
DEBUG - 2011-05-10 20:16:35 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-10 20:16:35 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-10 20:16:35 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-10 20:16:35 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-10 20:16:35 --> Final output sent to browser
DEBUG - 2011-05-10 20:16:35 --> Total execution time: 0.6709
DEBUG - 2011-05-10 20:23:53 --> Config Class Initialized
DEBUG - 2011-05-10 20:23:53 --> Hooks Class Initialized
DEBUG - 2011-05-10 20:23:53 --> Utf8 Class Initialized
DEBUG - 2011-05-10 20:23:53 --> UTF-8 Support Enabled
DEBUG - 2011-05-10 20:23:53 --> URI Class Initialized
DEBUG - 2011-05-10 20:23:53 --> Router Class Initialized
ERROR - 2011-05-10 20:23:53 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-10 20:30:17 --> Config Class Initialized
DEBUG - 2011-05-10 20:30:17 --> Hooks Class Initialized
DEBUG - 2011-05-10 20:30:17 --> Utf8 Class Initialized
DEBUG - 2011-05-10 20:30:17 --> UTF-8 Support Enabled
DEBUG - 2011-05-10 20:30:17 --> URI Class Initialized
DEBUG - 2011-05-10 20:30:17 --> Router Class Initialized
DEBUG - 2011-05-10 20:30:17 --> Output Class Initialized
DEBUG - 2011-05-10 20:30:18 --> Input Class Initialized
DEBUG - 2011-05-10 20:30:18 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-10 20:30:18 --> Language Class Initialized
DEBUG - 2011-05-10 20:30:18 --> Loader Class Initialized
DEBUG - 2011-05-10 20:30:18 --> Controller Class Initialized
DEBUG - 2011-05-10 20:30:18 --> Model Class Initialized
DEBUG - 2011-05-10 20:30:18 --> Model Class Initialized
DEBUG - 2011-05-10 20:30:18 --> Model Class Initialized
DEBUG - 2011-05-10 20:30:19 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-10 20:30:20 --> Database Driver Class Initialized
DEBUG - 2011-05-10 20:30:20 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-10 20:30:20 --> Helper loaded: url_helper
DEBUG - 2011-05-10 20:30:20 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-10 20:30:20 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-10 20:30:20 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-10 20:30:20 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-10 20:30:20 --> Final output sent to browser
DEBUG - 2011-05-10 20:30:20 --> Total execution time: 3.8752
DEBUG - 2011-05-10 20:30:58 --> Config Class Initialized
DEBUG - 2011-05-10 20:30:58 --> Hooks Class Initialized
DEBUG - 2011-05-10 20:30:58 --> Utf8 Class Initialized
DEBUG - 2011-05-10 20:30:58 --> UTF-8 Support Enabled
DEBUG - 2011-05-10 20:30:58 --> URI Class Initialized
DEBUG - 2011-05-10 20:30:58 --> Router Class Initialized
DEBUG - 2011-05-10 20:30:58 --> Output Class Initialized
DEBUG - 2011-05-10 20:30:58 --> Input Class Initialized
DEBUG - 2011-05-10 20:30:58 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-10 20:30:58 --> Language Class Initialized
DEBUG - 2011-05-10 20:30:58 --> Loader Class Initialized
DEBUG - 2011-05-10 20:30:58 --> Controller Class Initialized
DEBUG - 2011-05-10 20:30:58 --> Model Class Initialized
DEBUG - 2011-05-10 20:30:58 --> Model Class Initialized
DEBUG - 2011-05-10 20:30:58 --> Model Class Initialized
DEBUG - 2011-05-10 20:30:58 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-10 20:30:58 --> Database Driver Class Initialized
DEBUG - 2011-05-10 20:30:58 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-10 20:30:58 --> Helper loaded: url_helper
DEBUG - 2011-05-10 20:30:58 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-10 20:30:58 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-10 20:30:58 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-10 20:30:58 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-10 20:30:58 --> Final output sent to browser
DEBUG - 2011-05-10 20:30:58 --> Total execution time: 0.1561
DEBUG - 2011-05-10 20:31:23 --> Config Class Initialized
DEBUG - 2011-05-10 20:31:23 --> Hooks Class Initialized
DEBUG - 2011-05-10 20:31:23 --> Utf8 Class Initialized
DEBUG - 2011-05-10 20:31:23 --> UTF-8 Support Enabled
DEBUG - 2011-05-10 20:31:23 --> URI Class Initialized
DEBUG - 2011-05-10 20:31:23 --> Router Class Initialized
ERROR - 2011-05-10 20:31:23 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-10 20:31:53 --> Config Class Initialized
DEBUG - 2011-05-10 20:31:53 --> Hooks Class Initialized
DEBUG - 2011-05-10 20:31:53 --> Utf8 Class Initialized
DEBUG - 2011-05-10 20:31:53 --> UTF-8 Support Enabled
DEBUG - 2011-05-10 20:31:53 --> URI Class Initialized
DEBUG - 2011-05-10 20:31:53 --> Router Class Initialized
DEBUG - 2011-05-10 20:31:53 --> Output Class Initialized
DEBUG - 2011-05-10 20:31:54 --> Input Class Initialized
DEBUG - 2011-05-10 20:31:54 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-10 20:31:54 --> Language Class Initialized
DEBUG - 2011-05-10 20:31:54 --> Loader Class Initialized
DEBUG - 2011-05-10 20:31:54 --> Controller Class Initialized
DEBUG - 2011-05-10 20:31:54 --> Model Class Initialized
DEBUG - 2011-05-10 20:31:54 --> Model Class Initialized
DEBUG - 2011-05-10 20:31:54 --> Model Class Initialized
DEBUG - 2011-05-10 20:31:54 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-10 20:31:54 --> Database Driver Class Initialized
DEBUG - 2011-05-10 20:31:54 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-10 20:31:54 --> Helper loaded: url_helper
DEBUG - 2011-05-10 20:31:54 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-10 20:31:54 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-10 20:31:54 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-10 20:31:54 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-10 20:31:54 --> Final output sent to browser
DEBUG - 2011-05-10 20:31:54 --> Total execution time: 0.2906
DEBUG - 2011-05-10 20:34:24 --> Config Class Initialized
DEBUG - 2011-05-10 20:34:24 --> Hooks Class Initialized
DEBUG - 2011-05-10 20:34:24 --> Utf8 Class Initialized
DEBUG - 2011-05-10 20:34:24 --> UTF-8 Support Enabled
DEBUG - 2011-05-10 20:34:24 --> URI Class Initialized
DEBUG - 2011-05-10 20:34:24 --> Router Class Initialized
DEBUG - 2011-05-10 20:34:24 --> Output Class Initialized
DEBUG - 2011-05-10 20:34:24 --> Input Class Initialized
DEBUG - 2011-05-10 20:34:24 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-10 20:34:24 --> Language Class Initialized
DEBUG - 2011-05-10 20:34:24 --> Loader Class Initialized
DEBUG - 2011-05-10 20:34:24 --> Controller Class Initialized
DEBUG - 2011-05-10 20:34:24 --> Model Class Initialized
DEBUG - 2011-05-10 20:34:24 --> Model Class Initialized
DEBUG - 2011-05-10 20:34:24 --> Model Class Initialized
DEBUG - 2011-05-10 20:34:24 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-10 20:34:24 --> Database Driver Class Initialized
DEBUG - 2011-05-10 20:34:24 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-10 20:34:24 --> Helper loaded: url_helper
DEBUG - 2011-05-10 20:34:24 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-10 20:34:24 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-10 20:34:24 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-10 20:34:24 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-10 20:34:24 --> Final output sent to browser
DEBUG - 2011-05-10 20:34:24 --> Total execution time: 0.0894
DEBUG - 2011-05-10 20:35:00 --> Config Class Initialized
DEBUG - 2011-05-10 20:35:00 --> Hooks Class Initialized
DEBUG - 2011-05-10 20:35:00 --> Utf8 Class Initialized
DEBUG - 2011-05-10 20:35:00 --> UTF-8 Support Enabled
DEBUG - 2011-05-10 20:35:00 --> URI Class Initialized
DEBUG - 2011-05-10 20:35:00 --> Router Class Initialized
ERROR - 2011-05-10 20:35:01 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-10 20:35:31 --> Config Class Initialized
DEBUG - 2011-05-10 20:35:31 --> Hooks Class Initialized
DEBUG - 2011-05-10 20:35:31 --> Utf8 Class Initialized
DEBUG - 2011-05-10 20:35:31 --> UTF-8 Support Enabled
DEBUG - 2011-05-10 20:35:31 --> URI Class Initialized
DEBUG - 2011-05-10 20:35:31 --> Router Class Initialized
DEBUG - 2011-05-10 20:35:31 --> Output Class Initialized
DEBUG - 2011-05-10 20:35:31 --> Input Class Initialized
DEBUG - 2011-05-10 20:35:31 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-10 20:35:31 --> Language Class Initialized
DEBUG - 2011-05-10 20:35:32 --> Loader Class Initialized
DEBUG - 2011-05-10 20:35:32 --> Controller Class Initialized
DEBUG - 2011-05-10 20:35:32 --> Model Class Initialized
DEBUG - 2011-05-10 20:35:32 --> Model Class Initialized
DEBUG - 2011-05-10 20:35:32 --> Model Class Initialized
DEBUG - 2011-05-10 20:35:32 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-10 20:35:32 --> Database Driver Class Initialized
DEBUG - 2011-05-10 20:35:32 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-10 20:35:32 --> Helper loaded: url_helper
DEBUG - 2011-05-10 20:35:32 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-10 20:35:32 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-10 20:35:32 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-10 20:35:32 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-10 20:35:32 --> Final output sent to browser
DEBUG - 2011-05-10 20:35:32 --> Total execution time: 0.1019
DEBUG - 2011-05-10 20:35:41 --> Config Class Initialized
DEBUG - 2011-05-10 20:35:41 --> Hooks Class Initialized
DEBUG - 2011-05-10 20:35:41 --> Utf8 Class Initialized
DEBUG - 2011-05-10 20:35:41 --> UTF-8 Support Enabled
DEBUG - 2011-05-10 20:35:41 --> URI Class Initialized
DEBUG - 2011-05-10 20:35:41 --> Router Class Initialized
ERROR - 2011-05-10 20:35:41 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-10 20:36:03 --> Config Class Initialized
DEBUG - 2011-05-10 20:36:03 --> Hooks Class Initialized
DEBUG - 2011-05-10 20:36:03 --> Utf8 Class Initialized
DEBUG - 2011-05-10 20:36:03 --> UTF-8 Support Enabled
DEBUG - 2011-05-10 20:36:03 --> URI Class Initialized
DEBUG - 2011-05-10 20:36:03 --> Router Class Initialized
DEBUG - 2011-05-10 20:36:03 --> Output Class Initialized
DEBUG - 2011-05-10 20:36:03 --> Input Class Initialized
DEBUG - 2011-05-10 20:36:03 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-10 20:36:03 --> Language Class Initialized
DEBUG - 2011-05-10 20:36:03 --> Loader Class Initialized
DEBUG - 2011-05-10 20:36:03 --> Controller Class Initialized
DEBUG - 2011-05-10 20:36:03 --> Model Class Initialized
DEBUG - 2011-05-10 20:36:03 --> Model Class Initialized
DEBUG - 2011-05-10 20:36:03 --> Model Class Initialized
DEBUG - 2011-05-10 20:36:03 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-10 20:36:03 --> Database Driver Class Initialized
DEBUG - 2011-05-10 20:36:04 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-10 20:36:04 --> Helper loaded: url_helper
DEBUG - 2011-05-10 20:36:04 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-10 20:36:04 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-10 20:36:04 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-10 20:36:04 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-10 20:36:04 --> Final output sent to browser
DEBUG - 2011-05-10 20:36:04 --> Total execution time: 0.3640
DEBUG - 2011-05-10 20:36:06 --> Config Class Initialized
DEBUG - 2011-05-10 20:36:06 --> Hooks Class Initialized
DEBUG - 2011-05-10 20:36:06 --> Utf8 Class Initialized
DEBUG - 2011-05-10 20:36:06 --> UTF-8 Support Enabled
DEBUG - 2011-05-10 20:36:06 --> URI Class Initialized
DEBUG - 2011-05-10 20:36:06 --> Router Class Initialized
DEBUG - 2011-05-10 20:36:06 --> Output Class Initialized
DEBUG - 2011-05-10 20:36:06 --> Input Class Initialized
DEBUG - 2011-05-10 20:36:06 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-10 20:36:06 --> Language Class Initialized
DEBUG - 2011-05-10 20:36:06 --> Loader Class Initialized
DEBUG - 2011-05-10 20:36:06 --> Controller Class Initialized
DEBUG - 2011-05-10 20:36:06 --> Model Class Initialized
DEBUG - 2011-05-10 20:36:06 --> Model Class Initialized
DEBUG - 2011-05-10 20:36:06 --> Model Class Initialized
DEBUG - 2011-05-10 20:36:06 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-10 20:36:06 --> Database Driver Class Initialized
DEBUG - 2011-05-10 20:36:06 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-10 20:36:06 --> Helper loaded: url_helper
DEBUG - 2011-05-10 20:36:06 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-10 20:36:06 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-10 20:36:06 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-10 20:36:06 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-10 20:36:06 --> Final output sent to browser
DEBUG - 2011-05-10 20:36:06 --> Total execution time: 0.0458
DEBUG - 2011-05-10 20:36:06 --> Config Class Initialized
DEBUG - 2011-05-10 20:36:06 --> Hooks Class Initialized
DEBUG - 2011-05-10 20:36:06 --> Utf8 Class Initialized
DEBUG - 2011-05-10 20:36:06 --> UTF-8 Support Enabled
DEBUG - 2011-05-10 20:36:06 --> URI Class Initialized
DEBUG - 2011-05-10 20:36:06 --> Router Class Initialized
DEBUG - 2011-05-10 20:36:06 --> Output Class Initialized
DEBUG - 2011-05-10 20:36:06 --> Input Class Initialized
DEBUG - 2011-05-10 20:36:06 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-10 20:36:06 --> Language Class Initialized
DEBUG - 2011-05-10 20:36:06 --> Loader Class Initialized
DEBUG - 2011-05-10 20:36:06 --> Controller Class Initialized
DEBUG - 2011-05-10 20:36:06 --> Model Class Initialized
DEBUG - 2011-05-10 20:36:06 --> Model Class Initialized
DEBUG - 2011-05-10 20:36:06 --> Model Class Initialized
DEBUG - 2011-05-10 20:36:06 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-10 20:36:06 --> Database Driver Class Initialized
DEBUG - 2011-05-10 20:36:06 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-10 20:36:06 --> Helper loaded: url_helper
DEBUG - 2011-05-10 20:36:06 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-10 20:36:06 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-10 20:36:06 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-10 20:36:06 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-10 20:36:06 --> Final output sent to browser
DEBUG - 2011-05-10 20:36:06 --> Total execution time: 0.0459
DEBUG - 2011-05-10 20:36:13 --> Config Class Initialized
DEBUG - 2011-05-10 20:36:13 --> Hooks Class Initialized
DEBUG - 2011-05-10 20:36:13 --> Utf8 Class Initialized
DEBUG - 2011-05-10 20:36:13 --> UTF-8 Support Enabled
DEBUG - 2011-05-10 20:36:13 --> URI Class Initialized
DEBUG - 2011-05-10 20:36:13 --> Router Class Initialized
ERROR - 2011-05-10 20:36:13 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-10 20:36:20 --> Config Class Initialized
DEBUG - 2011-05-10 20:36:20 --> Hooks Class Initialized
DEBUG - 2011-05-10 20:36:20 --> Utf8 Class Initialized
DEBUG - 2011-05-10 20:36:20 --> UTF-8 Support Enabled
DEBUG - 2011-05-10 20:36:20 --> URI Class Initialized
DEBUG - 2011-05-10 20:36:20 --> Router Class Initialized
DEBUG - 2011-05-10 20:36:20 --> Output Class Initialized
DEBUG - 2011-05-10 20:36:20 --> Input Class Initialized
DEBUG - 2011-05-10 20:36:20 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-10 20:36:20 --> Language Class Initialized
DEBUG - 2011-05-10 20:36:20 --> Loader Class Initialized
DEBUG - 2011-05-10 20:36:20 --> Controller Class Initialized
DEBUG - 2011-05-10 20:36:20 --> Model Class Initialized
DEBUG - 2011-05-10 20:36:20 --> Model Class Initialized
DEBUG - 2011-05-10 20:36:20 --> Model Class Initialized
DEBUG - 2011-05-10 20:36:20 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-10 20:36:20 --> Database Driver Class Initialized
DEBUG - 2011-05-10 20:36:20 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-10 20:36:20 --> Helper loaded: url_helper
DEBUG - 2011-05-10 20:36:20 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-10 20:36:20 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-10 20:36:20 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-10 20:36:20 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-10 20:36:20 --> Final output sent to browser
DEBUG - 2011-05-10 20:36:20 --> Total execution time: 0.4823
DEBUG - 2011-05-10 20:36:23 --> Config Class Initialized
DEBUG - 2011-05-10 20:36:23 --> Hooks Class Initialized
DEBUG - 2011-05-10 20:36:23 --> Utf8 Class Initialized
DEBUG - 2011-05-10 20:36:23 --> UTF-8 Support Enabled
DEBUG - 2011-05-10 20:36:23 --> URI Class Initialized
DEBUG - 2011-05-10 20:36:23 --> Router Class Initialized
DEBUG - 2011-05-10 20:36:23 --> Output Class Initialized
DEBUG - 2011-05-10 20:36:23 --> Input Class Initialized
DEBUG - 2011-05-10 20:36:23 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-10 20:36:23 --> Language Class Initialized
DEBUG - 2011-05-10 20:36:23 --> Loader Class Initialized
DEBUG - 2011-05-10 20:36:23 --> Controller Class Initialized
DEBUG - 2011-05-10 20:36:23 --> Model Class Initialized
DEBUG - 2011-05-10 20:36:23 --> Model Class Initialized
DEBUG - 2011-05-10 20:36:23 --> Model Class Initialized
DEBUG - 2011-05-10 20:36:23 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-10 20:36:23 --> Database Driver Class Initialized
DEBUG - 2011-05-10 20:36:23 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-10 20:36:23 --> Helper loaded: url_helper
DEBUG - 2011-05-10 20:36:23 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-10 20:36:23 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-10 20:36:23 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-10 20:36:23 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-10 20:36:23 --> Final output sent to browser
DEBUG - 2011-05-10 20:36:23 --> Total execution time: 0.1140
DEBUG - 2011-05-10 20:36:25 --> Config Class Initialized
DEBUG - 2011-05-10 20:36:25 --> Hooks Class Initialized
DEBUG - 2011-05-10 20:36:25 --> Utf8 Class Initialized
DEBUG - 2011-05-10 20:36:25 --> UTF-8 Support Enabled
DEBUG - 2011-05-10 20:36:25 --> URI Class Initialized
DEBUG - 2011-05-10 20:36:25 --> Router Class Initialized
ERROR - 2011-05-10 20:36:25 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-10 22:07:18 --> Config Class Initialized
DEBUG - 2011-05-10 22:07:18 --> Hooks Class Initialized
DEBUG - 2011-05-10 22:07:18 --> Utf8 Class Initialized
DEBUG - 2011-05-10 22:07:18 --> UTF-8 Support Enabled
DEBUG - 2011-05-10 22:07:18 --> URI Class Initialized
DEBUG - 2011-05-10 22:07:18 --> Router Class Initialized
DEBUG - 2011-05-10 22:07:18 --> No URI present. Default controller set.
DEBUG - 2011-05-10 22:07:18 --> Output Class Initialized
DEBUG - 2011-05-10 22:07:18 --> Input Class Initialized
DEBUG - 2011-05-10 22:07:18 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-10 22:07:18 --> Language Class Initialized
DEBUG - 2011-05-10 22:07:18 --> Loader Class Initialized
DEBUG - 2011-05-10 22:07:18 --> Controller Class Initialized
DEBUG - 2011-05-10 22:07:18 --> File loaded: application/views/splash/main.php
DEBUG - 2011-05-10 22:07:18 --> Helper loaded: url_helper
DEBUG - 2011-05-10 22:07:18 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-10 22:07:18 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-10 22:07:18 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-10 22:07:18 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-10 22:07:18 --> Final output sent to browser
DEBUG - 2011-05-10 22:07:18 --> Total execution time: 0.2485
DEBUG - 2011-05-10 23:43:16 --> Config Class Initialized
DEBUG - 2011-05-10 23:43:16 --> Config Class Initialized
DEBUG - 2011-05-10 23:43:16 --> Hooks Class Initialized
DEBUG - 2011-05-10 23:43:16 --> Hooks Class Initialized
DEBUG - 2011-05-10 23:43:16 --> Utf8 Class Initialized
DEBUG - 2011-05-10 23:43:16 --> UTF-8 Support Enabled
DEBUG - 2011-05-10 23:43:16 --> Utf8 Class Initialized
DEBUG - 2011-05-10 23:43:16 --> UTF-8 Support Enabled
DEBUG - 2011-05-10 23:43:16 --> URI Class Initialized
DEBUG - 2011-05-10 23:43:16 --> URI Class Initialized
DEBUG - 2011-05-10 23:43:16 --> Router Class Initialized
DEBUG - 2011-05-10 23:43:16 --> Router Class Initialized
DEBUG - 2011-05-10 23:43:16 --> Output Class Initialized
DEBUG - 2011-05-10 23:43:16 --> Output Class Initialized
DEBUG - 2011-05-10 23:43:16 --> Input Class Initialized
DEBUG - 2011-05-10 23:43:16 --> Input Class Initialized
DEBUG - 2011-05-10 23:43:16 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-10 23:43:16 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-10 23:43:16 --> Language Class Initialized
DEBUG - 2011-05-10 23:43:16 --> Language Class Initialized
DEBUG - 2011-05-10 23:43:16 --> Loader Class Initialized
DEBUG - 2011-05-10 23:43:16 --> Loader Class Initialized
DEBUG - 2011-05-10 23:43:16 --> Controller Class Initialized
DEBUG - 2011-05-10 23:43:16 --> Controller Class Initialized
DEBUG - 2011-05-10 23:43:16 --> Model Class Initialized
ERROR - 2011-05-10 23:43:16 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-10 23:43:16 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-10 23:43:16 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-10 23:43:16 --> Model Class Initialized
DEBUG - 2011-05-10 23:43:16 --> Model Class Initialized
DEBUG - 2011-05-10 23:43:16 --> Model Class Initialized
DEBUG - 2011-05-10 23:43:16 --> Model Class Initialized
DEBUG - 2011-05-10 23:43:16 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-10 23:43:16 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-10 23:43:16 --> Database Driver Class Initialized
DEBUG - 2011-05-10 23:43:16 --> Database Driver Class Initialized
DEBUG - 2011-05-10 23:43:16 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-10 23:43:16 --> Helper loaded: url_helper
DEBUG - 2011-05-10 23:43:16 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-10 23:43:16 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-10 23:43:16 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-10 23:43:16 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-10 23:43:16 --> Final output sent to browser
DEBUG - 2011-05-10 23:43:16 --> Total execution time: 0.4297
DEBUG - 2011-05-10 23:43:17 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-10 23:43:17 --> Helper loaded: url_helper
DEBUG - 2011-05-10 23:43:17 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-10 23:43:17 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-10 23:43:17 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-10 23:43:17 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-10 23:43:17 --> Final output sent to browser
DEBUG - 2011-05-10 23:43:17 --> Total execution time: 0.7237

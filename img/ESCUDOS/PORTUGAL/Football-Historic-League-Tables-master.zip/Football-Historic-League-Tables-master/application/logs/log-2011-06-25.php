<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2011-06-25 04:49:12 --> Config Class Initialized
DEBUG - 2011-06-25 04:49:12 --> Hooks Class Initialized
DEBUG - 2011-06-25 04:49:12 --> Utf8 Class Initialized
DEBUG - 2011-06-25 04:49:12 --> UTF-8 Support Enabled
DEBUG - 2011-06-25 04:49:12 --> URI Class Initialized
DEBUG - 2011-06-25 04:49:12 --> Router Class Initialized
DEBUG - 2011-06-25 04:49:12 --> Output Class Initialized
DEBUG - 2011-06-25 04:49:12 --> Input Class Initialized
DEBUG - 2011-06-25 04:49:12 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-25 04:49:12 --> Language Class Initialized
DEBUG - 2011-06-25 04:49:12 --> Loader Class Initialized
DEBUG - 2011-06-25 04:49:12 --> Controller Class Initialized
DEBUG - 2011-06-25 04:49:12 --> Model Class Initialized
DEBUG - 2011-06-25 04:49:12 --> Model Class Initialized
DEBUG - 2011-06-25 04:49:12 --> Model Class Initialized
DEBUG - 2011-06-25 04:49:12 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-25 04:49:12 --> Database Driver Class Initialized
DEBUG - 2011-06-25 04:49:13 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-25 04:49:13 --> Helper loaded: url_helper
DEBUG - 2011-06-25 04:49:13 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-25 04:49:13 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-25 04:49:13 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-25 04:49:13 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-25 04:49:13 --> Final output sent to browser
DEBUG - 2011-06-25 04:49:13 --> Total execution time: 1.2137
DEBUG - 2011-06-25 04:49:16 --> Config Class Initialized
DEBUG - 2011-06-25 04:49:16 --> Hooks Class Initialized
DEBUG - 2011-06-25 04:49:16 --> Utf8 Class Initialized
DEBUG - 2011-06-25 04:49:16 --> UTF-8 Support Enabled
DEBUG - 2011-06-25 04:49:16 --> URI Class Initialized
DEBUG - 2011-06-25 04:49:16 --> Router Class Initialized
ERROR - 2011-06-25 04:49:16 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-25 04:49:16 --> Config Class Initialized
DEBUG - 2011-06-25 04:49:16 --> Hooks Class Initialized
DEBUG - 2011-06-25 04:49:16 --> Utf8 Class Initialized
DEBUG - 2011-06-25 04:49:16 --> UTF-8 Support Enabled
DEBUG - 2011-06-25 04:49:16 --> URI Class Initialized
DEBUG - 2011-06-25 04:49:16 --> Router Class Initialized
ERROR - 2011-06-25 04:49:16 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-25 04:49:16 --> Config Class Initialized
DEBUG - 2011-06-25 04:49:16 --> Hooks Class Initialized
DEBUG - 2011-06-25 04:49:16 --> Utf8 Class Initialized
DEBUG - 2011-06-25 04:49:16 --> UTF-8 Support Enabled
DEBUG - 2011-06-25 04:49:16 --> URI Class Initialized
DEBUG - 2011-06-25 04:49:16 --> Router Class Initialized
ERROR - 2011-06-25 04:49:16 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-25 07:21:08 --> Config Class Initialized
DEBUG - 2011-06-25 07:21:08 --> Hooks Class Initialized
DEBUG - 2011-06-25 07:21:08 --> Utf8 Class Initialized
DEBUG - 2011-06-25 07:21:08 --> UTF-8 Support Enabled
DEBUG - 2011-06-25 07:21:08 --> URI Class Initialized
DEBUG - 2011-06-25 07:21:08 --> Router Class Initialized
DEBUG - 2011-06-25 07:21:08 --> Output Class Initialized
DEBUG - 2011-06-25 07:21:08 --> Input Class Initialized
DEBUG - 2011-06-25 07:21:08 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-25 07:21:08 --> Language Class Initialized
DEBUG - 2011-06-25 07:21:08 --> Loader Class Initialized
DEBUG - 2011-06-25 07:21:08 --> Controller Class Initialized
ERROR - 2011-06-25 07:21:08 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-25 07:21:08 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-25 07:21:08 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-25 07:21:08 --> Model Class Initialized
DEBUG - 2011-06-25 07:21:08 --> Model Class Initialized
DEBUG - 2011-06-25 07:21:08 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-25 07:21:08 --> Database Driver Class Initialized
DEBUG - 2011-06-25 07:21:08 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-25 07:21:08 --> Helper loaded: url_helper
DEBUG - 2011-06-25 07:21:08 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-25 07:21:08 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-25 07:21:08 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-25 07:21:08 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-25 07:21:08 --> Final output sent to browser
DEBUG - 2011-06-25 07:21:08 --> Total execution time: 0.3716
DEBUG - 2011-06-25 07:21:09 --> Config Class Initialized
DEBUG - 2011-06-25 07:21:09 --> Hooks Class Initialized
DEBUG - 2011-06-25 07:21:09 --> Utf8 Class Initialized
DEBUG - 2011-06-25 07:21:09 --> UTF-8 Support Enabled
DEBUG - 2011-06-25 07:21:09 --> URI Class Initialized
DEBUG - 2011-06-25 07:21:09 --> Router Class Initialized
DEBUG - 2011-06-25 07:21:09 --> Output Class Initialized
DEBUG - 2011-06-25 07:21:09 --> Input Class Initialized
DEBUG - 2011-06-25 07:21:09 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-25 07:21:09 --> Language Class Initialized
DEBUG - 2011-06-25 07:21:09 --> Loader Class Initialized
DEBUG - 2011-06-25 07:21:09 --> Controller Class Initialized
DEBUG - 2011-06-25 07:21:09 --> Model Class Initialized
DEBUG - 2011-06-25 07:21:09 --> Model Class Initialized
DEBUG - 2011-06-25 07:21:09 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-25 07:21:09 --> Database Driver Class Initialized
DEBUG - 2011-06-25 07:21:10 --> Final output sent to browser
DEBUG - 2011-06-25 07:21:10 --> Total execution time: 0.7494
DEBUG - 2011-06-25 07:21:12 --> Config Class Initialized
DEBUG - 2011-06-25 07:21:12 --> Hooks Class Initialized
DEBUG - 2011-06-25 07:21:12 --> Utf8 Class Initialized
DEBUG - 2011-06-25 07:21:12 --> UTF-8 Support Enabled
DEBUG - 2011-06-25 07:21:12 --> URI Class Initialized
DEBUG - 2011-06-25 07:21:12 --> Router Class Initialized
ERROR - 2011-06-25 07:21:12 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-25 07:21:45 --> Config Class Initialized
DEBUG - 2011-06-25 07:21:45 --> Hooks Class Initialized
DEBUG - 2011-06-25 07:21:45 --> Utf8 Class Initialized
DEBUG - 2011-06-25 07:21:45 --> UTF-8 Support Enabled
DEBUG - 2011-06-25 07:21:45 --> URI Class Initialized
DEBUG - 2011-06-25 07:21:45 --> Router Class Initialized
DEBUG - 2011-06-25 07:21:45 --> Output Class Initialized
DEBUG - 2011-06-25 07:21:45 --> Input Class Initialized
DEBUG - 2011-06-25 07:21:45 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-25 07:21:45 --> Language Class Initialized
DEBUG - 2011-06-25 07:21:45 --> Loader Class Initialized
DEBUG - 2011-06-25 07:21:45 --> Controller Class Initialized
ERROR - 2011-06-25 07:21:45 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-25 07:21:45 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-25 07:21:45 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-25 07:21:45 --> Model Class Initialized
DEBUG - 2011-06-25 07:21:45 --> Model Class Initialized
DEBUG - 2011-06-25 07:21:45 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-25 07:21:45 --> Database Driver Class Initialized
DEBUG - 2011-06-25 07:21:45 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-25 07:21:45 --> Helper loaded: url_helper
DEBUG - 2011-06-25 07:21:45 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-25 07:21:45 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-25 07:21:45 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-25 07:21:45 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-25 07:21:45 --> Final output sent to browser
DEBUG - 2011-06-25 07:21:45 --> Total execution time: 0.0320
DEBUG - 2011-06-25 07:21:45 --> Config Class Initialized
DEBUG - 2011-06-25 07:21:45 --> Hooks Class Initialized
DEBUG - 2011-06-25 07:21:45 --> Utf8 Class Initialized
DEBUG - 2011-06-25 07:21:45 --> UTF-8 Support Enabled
DEBUG - 2011-06-25 07:21:45 --> URI Class Initialized
DEBUG - 2011-06-25 07:21:45 --> Router Class Initialized
DEBUG - 2011-06-25 07:21:45 --> Output Class Initialized
DEBUG - 2011-06-25 07:21:45 --> Input Class Initialized
DEBUG - 2011-06-25 07:21:45 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-25 07:21:45 --> Language Class Initialized
DEBUG - 2011-06-25 07:21:45 --> Loader Class Initialized
DEBUG - 2011-06-25 07:21:45 --> Controller Class Initialized
DEBUG - 2011-06-25 07:21:45 --> Model Class Initialized
DEBUG - 2011-06-25 07:21:45 --> Model Class Initialized
DEBUG - 2011-06-25 07:21:45 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-25 07:21:45 --> Database Driver Class Initialized
DEBUG - 2011-06-25 07:21:46 --> Final output sent to browser
DEBUG - 2011-06-25 07:21:46 --> Total execution time: 0.9231
DEBUG - 2011-06-25 07:21:47 --> Config Class Initialized
DEBUG - 2011-06-25 07:21:47 --> Hooks Class Initialized
DEBUG - 2011-06-25 07:21:47 --> Utf8 Class Initialized
DEBUG - 2011-06-25 07:21:47 --> UTF-8 Support Enabled
DEBUG - 2011-06-25 07:21:47 --> URI Class Initialized
DEBUG - 2011-06-25 07:21:47 --> Router Class Initialized
ERROR - 2011-06-25 07:21:47 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-25 07:21:50 --> Config Class Initialized
DEBUG - 2011-06-25 07:21:50 --> Hooks Class Initialized
DEBUG - 2011-06-25 07:21:50 --> Utf8 Class Initialized
DEBUG - 2011-06-25 07:21:50 --> UTF-8 Support Enabled
DEBUG - 2011-06-25 07:21:50 --> URI Class Initialized
DEBUG - 2011-06-25 07:21:50 --> Router Class Initialized
DEBUG - 2011-06-25 07:21:50 --> Output Class Initialized
DEBUG - 2011-06-25 07:21:50 --> Input Class Initialized
DEBUG - 2011-06-25 07:21:50 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-25 07:21:50 --> Language Class Initialized
DEBUG - 2011-06-25 07:21:50 --> Loader Class Initialized
DEBUG - 2011-06-25 07:21:50 --> Controller Class Initialized
ERROR - 2011-06-25 07:21:50 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-25 07:21:50 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-25 07:21:50 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-25 07:21:50 --> Model Class Initialized
DEBUG - 2011-06-25 07:21:50 --> Model Class Initialized
DEBUG - 2011-06-25 07:21:50 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-25 07:21:50 --> Database Driver Class Initialized
DEBUG - 2011-06-25 07:21:50 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-25 07:21:50 --> Helper loaded: url_helper
DEBUG - 2011-06-25 07:21:50 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-25 07:21:50 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-25 07:21:50 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-25 07:21:50 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-25 07:21:50 --> Final output sent to browser
DEBUG - 2011-06-25 07:21:50 --> Total execution time: 0.0361
DEBUG - 2011-06-25 07:21:51 --> Config Class Initialized
DEBUG - 2011-06-25 07:21:51 --> Hooks Class Initialized
DEBUG - 2011-06-25 07:21:51 --> Utf8 Class Initialized
DEBUG - 2011-06-25 07:21:51 --> UTF-8 Support Enabled
DEBUG - 2011-06-25 07:21:51 --> URI Class Initialized
DEBUG - 2011-06-25 07:21:51 --> Router Class Initialized
DEBUG - 2011-06-25 07:21:51 --> Output Class Initialized
DEBUG - 2011-06-25 07:21:51 --> Input Class Initialized
DEBUG - 2011-06-25 07:21:51 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-25 07:21:51 --> Language Class Initialized
DEBUG - 2011-06-25 07:21:51 --> Loader Class Initialized
DEBUG - 2011-06-25 07:21:51 --> Controller Class Initialized
DEBUG - 2011-06-25 07:21:51 --> Model Class Initialized
DEBUG - 2011-06-25 07:21:51 --> Model Class Initialized
DEBUG - 2011-06-25 07:21:51 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-25 07:21:51 --> Database Driver Class Initialized
DEBUG - 2011-06-25 07:21:51 --> Final output sent to browser
DEBUG - 2011-06-25 07:21:51 --> Total execution time: 0.6760
DEBUG - 2011-06-25 07:21:53 --> Config Class Initialized
DEBUG - 2011-06-25 07:21:53 --> Hooks Class Initialized
DEBUG - 2011-06-25 07:21:53 --> Utf8 Class Initialized
DEBUG - 2011-06-25 07:21:53 --> UTF-8 Support Enabled
DEBUG - 2011-06-25 07:21:53 --> URI Class Initialized
DEBUG - 2011-06-25 07:21:53 --> Router Class Initialized
ERROR - 2011-06-25 07:21:53 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-25 07:22:14 --> Config Class Initialized
DEBUG - 2011-06-25 07:22:14 --> Hooks Class Initialized
DEBUG - 2011-06-25 07:22:14 --> Utf8 Class Initialized
DEBUG - 2011-06-25 07:22:14 --> UTF-8 Support Enabled
DEBUG - 2011-06-25 07:22:14 --> URI Class Initialized
DEBUG - 2011-06-25 07:22:14 --> Router Class Initialized
DEBUG - 2011-06-25 07:22:14 --> Output Class Initialized
DEBUG - 2011-06-25 07:22:14 --> Input Class Initialized
DEBUG - 2011-06-25 07:22:14 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-25 07:22:14 --> Language Class Initialized
DEBUG - 2011-06-25 07:22:14 --> Loader Class Initialized
DEBUG - 2011-06-25 07:22:14 --> Controller Class Initialized
ERROR - 2011-06-25 07:22:14 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-25 07:22:14 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-25 07:22:14 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-25 07:22:14 --> Model Class Initialized
DEBUG - 2011-06-25 07:22:14 --> Model Class Initialized
DEBUG - 2011-06-25 07:22:14 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-25 07:22:14 --> Database Driver Class Initialized
DEBUG - 2011-06-25 07:22:14 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-25 07:22:14 --> Helper loaded: url_helper
DEBUG - 2011-06-25 07:22:14 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-25 07:22:14 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-25 07:22:14 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-25 07:22:14 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-25 07:22:14 --> Final output sent to browser
DEBUG - 2011-06-25 07:22:14 --> Total execution time: 0.0297
DEBUG - 2011-06-25 07:22:15 --> Config Class Initialized
DEBUG - 2011-06-25 07:22:15 --> Hooks Class Initialized
DEBUG - 2011-06-25 07:22:15 --> Utf8 Class Initialized
DEBUG - 2011-06-25 07:22:15 --> UTF-8 Support Enabled
DEBUG - 2011-06-25 07:22:15 --> URI Class Initialized
DEBUG - 2011-06-25 07:22:15 --> Router Class Initialized
DEBUG - 2011-06-25 07:22:15 --> Output Class Initialized
DEBUG - 2011-06-25 07:22:15 --> Input Class Initialized
DEBUG - 2011-06-25 07:22:15 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-25 07:22:15 --> Language Class Initialized
DEBUG - 2011-06-25 07:22:15 --> Loader Class Initialized
DEBUG - 2011-06-25 07:22:15 --> Controller Class Initialized
DEBUG - 2011-06-25 07:22:15 --> Model Class Initialized
DEBUG - 2011-06-25 07:22:15 --> Model Class Initialized
DEBUG - 2011-06-25 07:22:15 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-25 07:22:15 --> Database Driver Class Initialized
DEBUG - 2011-06-25 07:22:15 --> Final output sent to browser
DEBUG - 2011-06-25 07:22:15 --> Total execution time: 0.5646
DEBUG - 2011-06-25 07:22:16 --> Config Class Initialized
DEBUG - 2011-06-25 07:22:16 --> Hooks Class Initialized
DEBUG - 2011-06-25 07:22:16 --> Utf8 Class Initialized
DEBUG - 2011-06-25 07:22:16 --> UTF-8 Support Enabled
DEBUG - 2011-06-25 07:22:16 --> URI Class Initialized
DEBUG - 2011-06-25 07:22:16 --> Router Class Initialized
ERROR - 2011-06-25 07:22:16 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-25 07:22:21 --> Config Class Initialized
DEBUG - 2011-06-25 07:22:21 --> Hooks Class Initialized
DEBUG - 2011-06-25 07:22:21 --> Utf8 Class Initialized
DEBUG - 2011-06-25 07:22:21 --> UTF-8 Support Enabled
DEBUG - 2011-06-25 07:22:21 --> URI Class Initialized
DEBUG - 2011-06-25 07:22:21 --> Router Class Initialized
DEBUG - 2011-06-25 07:22:21 --> Output Class Initialized
DEBUG - 2011-06-25 07:22:21 --> Input Class Initialized
DEBUG - 2011-06-25 07:22:21 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-25 07:22:21 --> Language Class Initialized
DEBUG - 2011-06-25 07:22:21 --> Loader Class Initialized
DEBUG - 2011-06-25 07:22:21 --> Controller Class Initialized
ERROR - 2011-06-25 07:22:21 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-25 07:22:21 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-25 07:22:21 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-25 07:22:21 --> Model Class Initialized
DEBUG - 2011-06-25 07:22:21 --> Model Class Initialized
DEBUG - 2011-06-25 07:22:21 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-25 07:22:21 --> Database Driver Class Initialized
DEBUG - 2011-06-25 07:22:21 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-25 07:22:21 --> Helper loaded: url_helper
DEBUG - 2011-06-25 07:22:21 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-25 07:22:21 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-25 07:22:21 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-25 07:22:21 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-25 07:22:21 --> Final output sent to browser
DEBUG - 2011-06-25 07:22:21 --> Total execution time: 0.0385
DEBUG - 2011-06-25 07:22:21 --> Config Class Initialized
DEBUG - 2011-06-25 07:22:21 --> Hooks Class Initialized
DEBUG - 2011-06-25 07:22:21 --> Utf8 Class Initialized
DEBUG - 2011-06-25 07:22:21 --> UTF-8 Support Enabled
DEBUG - 2011-06-25 07:22:21 --> URI Class Initialized
DEBUG - 2011-06-25 07:22:21 --> Router Class Initialized
DEBUG - 2011-06-25 07:22:21 --> Output Class Initialized
DEBUG - 2011-06-25 07:22:21 --> Input Class Initialized
DEBUG - 2011-06-25 07:22:21 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-25 07:22:21 --> Language Class Initialized
DEBUG - 2011-06-25 07:22:21 --> Loader Class Initialized
DEBUG - 2011-06-25 07:22:21 --> Controller Class Initialized
DEBUG - 2011-06-25 07:22:21 --> Model Class Initialized
DEBUG - 2011-06-25 07:22:21 --> Model Class Initialized
DEBUG - 2011-06-25 07:22:21 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-25 07:22:21 --> Database Driver Class Initialized
DEBUG - 2011-06-25 07:22:22 --> Final output sent to browser
DEBUG - 2011-06-25 07:22:22 --> Total execution time: 0.6072
DEBUG - 2011-06-25 07:22:23 --> Config Class Initialized
DEBUG - 2011-06-25 07:22:23 --> Hooks Class Initialized
DEBUG - 2011-06-25 07:22:23 --> Utf8 Class Initialized
DEBUG - 2011-06-25 07:22:23 --> UTF-8 Support Enabled
DEBUG - 2011-06-25 07:22:23 --> URI Class Initialized
DEBUG - 2011-06-25 07:22:23 --> Router Class Initialized
ERROR - 2011-06-25 07:22:23 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-06-25 07:22:23 --> Config Class Initialized
DEBUG - 2011-06-25 07:22:23 --> Hooks Class Initialized
DEBUG - 2011-06-25 07:22:23 --> Utf8 Class Initialized
DEBUG - 2011-06-25 07:22:23 --> UTF-8 Support Enabled
DEBUG - 2011-06-25 07:22:23 --> URI Class Initialized
DEBUG - 2011-06-25 07:22:23 --> Router Class Initialized
DEBUG - 2011-06-25 07:22:23 --> Output Class Initialized
DEBUG - 2011-06-25 07:22:23 --> Input Class Initialized
DEBUG - 2011-06-25 07:22:23 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-25 07:22:23 --> Language Class Initialized
DEBUG - 2011-06-25 07:22:23 --> Loader Class Initialized
DEBUG - 2011-06-25 07:22:23 --> Controller Class Initialized
ERROR - 2011-06-25 07:22:23 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-25 07:22:23 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-25 07:22:23 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-25 07:22:23 --> Model Class Initialized
DEBUG - 2011-06-25 07:22:23 --> Model Class Initialized
DEBUG - 2011-06-25 07:22:23 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-25 07:22:23 --> Database Driver Class Initialized
DEBUG - 2011-06-25 07:22:23 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-25 07:22:23 --> Helper loaded: url_helper
DEBUG - 2011-06-25 07:22:23 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-25 07:22:23 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-25 07:22:23 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-25 07:22:23 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-25 07:22:23 --> Final output sent to browser
DEBUG - 2011-06-25 07:22:23 --> Total execution time: 0.0301
DEBUG - 2011-06-25 07:22:23 --> Config Class Initialized
DEBUG - 2011-06-25 07:22:23 --> Hooks Class Initialized
DEBUG - 2011-06-25 07:22:23 --> Utf8 Class Initialized
DEBUG - 2011-06-25 07:22:23 --> UTF-8 Support Enabled
DEBUG - 2011-06-25 07:22:23 --> URI Class Initialized
DEBUG - 2011-06-25 07:22:23 --> Router Class Initialized
ERROR - 2011-06-25 07:22:23 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-25 07:22:27 --> Config Class Initialized
DEBUG - 2011-06-25 07:22:27 --> Hooks Class Initialized
DEBUG - 2011-06-25 07:22:27 --> Utf8 Class Initialized
DEBUG - 2011-06-25 07:22:27 --> UTF-8 Support Enabled
DEBUG - 2011-06-25 07:22:27 --> URI Class Initialized
DEBUG - 2011-06-25 07:22:27 --> Router Class Initialized
DEBUG - 2011-06-25 07:22:27 --> Output Class Initialized
DEBUG - 2011-06-25 07:22:27 --> Input Class Initialized
DEBUG - 2011-06-25 07:22:27 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-25 07:22:27 --> Language Class Initialized
DEBUG - 2011-06-25 07:22:27 --> Loader Class Initialized
DEBUG - 2011-06-25 07:22:27 --> Controller Class Initialized
ERROR - 2011-06-25 07:22:27 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-25 07:22:27 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-25 07:22:27 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-25 07:22:27 --> Model Class Initialized
DEBUG - 2011-06-25 07:22:27 --> Model Class Initialized
DEBUG - 2011-06-25 07:22:27 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-25 07:22:27 --> Database Driver Class Initialized
DEBUG - 2011-06-25 07:22:27 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-25 07:22:27 --> Helper loaded: url_helper
DEBUG - 2011-06-25 07:22:27 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-25 07:22:27 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-25 07:22:27 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-25 07:22:27 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-25 07:22:27 --> Final output sent to browser
DEBUG - 2011-06-25 07:22:27 --> Total execution time: 0.0295
DEBUG - 2011-06-25 07:22:29 --> Config Class Initialized
DEBUG - 2011-06-25 07:22:29 --> Hooks Class Initialized
DEBUG - 2011-06-25 07:22:29 --> Utf8 Class Initialized
DEBUG - 2011-06-25 07:22:29 --> UTF-8 Support Enabled
DEBUG - 2011-06-25 07:22:29 --> URI Class Initialized
DEBUG - 2011-06-25 07:22:29 --> Router Class Initialized
DEBUG - 2011-06-25 07:22:29 --> Output Class Initialized
DEBUG - 2011-06-25 07:22:29 --> Input Class Initialized
DEBUG - 2011-06-25 07:22:29 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-25 07:22:29 --> Language Class Initialized
DEBUG - 2011-06-25 07:22:29 --> Loader Class Initialized
DEBUG - 2011-06-25 07:22:29 --> Controller Class Initialized
ERROR - 2011-06-25 07:22:29 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-25 07:22:29 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-25 07:22:29 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-25 07:22:29 --> Model Class Initialized
DEBUG - 2011-06-25 07:22:29 --> Model Class Initialized
DEBUG - 2011-06-25 07:22:29 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-25 07:22:29 --> Database Driver Class Initialized
DEBUG - 2011-06-25 07:22:29 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-25 07:22:29 --> Helper loaded: url_helper
DEBUG - 2011-06-25 07:22:29 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-25 07:22:29 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-25 07:22:29 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-25 07:22:29 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-25 07:22:29 --> Final output sent to browser
DEBUG - 2011-06-25 07:22:29 --> Total execution time: 0.0314
DEBUG - 2011-06-25 08:02:07 --> Config Class Initialized
DEBUG - 2011-06-25 08:02:07 --> Hooks Class Initialized
DEBUG - 2011-06-25 08:02:07 --> Utf8 Class Initialized
DEBUG - 2011-06-25 08:02:07 --> UTF-8 Support Enabled
DEBUG - 2011-06-25 08:02:07 --> URI Class Initialized
DEBUG - 2011-06-25 08:02:07 --> Router Class Initialized
DEBUG - 2011-06-25 08:02:07 --> Output Class Initialized
DEBUG - 2011-06-25 08:02:07 --> Input Class Initialized
DEBUG - 2011-06-25 08:02:07 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-25 08:02:07 --> Language Class Initialized
DEBUG - 2011-06-25 08:02:07 --> Loader Class Initialized
DEBUG - 2011-06-25 08:02:07 --> Controller Class Initialized
DEBUG - 2011-06-25 08:02:07 --> Model Class Initialized
DEBUG - 2011-06-25 08:02:07 --> Model Class Initialized
DEBUG - 2011-06-25 08:02:07 --> Model Class Initialized
DEBUG - 2011-06-25 08:02:07 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-25 08:02:07 --> Database Driver Class Initialized
DEBUG - 2011-06-25 08:02:08 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-25 08:02:08 --> Helper loaded: url_helper
DEBUG - 2011-06-25 08:02:08 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-25 08:02:08 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-25 08:02:08 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-25 08:02:08 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-25 08:02:08 --> Final output sent to browser
DEBUG - 2011-06-25 08:02:08 --> Total execution time: 1.0476
DEBUG - 2011-06-25 08:02:14 --> Config Class Initialized
DEBUG - 2011-06-25 08:02:14 --> Hooks Class Initialized
DEBUG - 2011-06-25 08:02:14 --> Utf8 Class Initialized
DEBUG - 2011-06-25 08:02:14 --> UTF-8 Support Enabled
DEBUG - 2011-06-25 08:02:14 --> URI Class Initialized
DEBUG - 2011-06-25 08:02:14 --> Router Class Initialized
DEBUG - 2011-06-25 08:02:14 --> Output Class Initialized
DEBUG - 2011-06-25 08:02:14 --> Input Class Initialized
DEBUG - 2011-06-25 08:02:14 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-25 08:02:14 --> Language Class Initialized
DEBUG - 2011-06-25 08:02:14 --> Loader Class Initialized
DEBUG - 2011-06-25 08:02:14 --> Controller Class Initialized
ERROR - 2011-06-25 08:02:14 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-25 08:02:14 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-25 08:02:14 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-25 08:02:14 --> Model Class Initialized
DEBUG - 2011-06-25 08:02:14 --> Model Class Initialized
DEBUG - 2011-06-25 08:02:14 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-25 08:02:14 --> Database Driver Class Initialized
DEBUG - 2011-06-25 08:02:14 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-25 08:02:14 --> Helper loaded: url_helper
DEBUG - 2011-06-25 08:02:14 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-25 08:02:14 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-25 08:02:14 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-25 08:02:14 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-25 08:02:14 --> Final output sent to browser
DEBUG - 2011-06-25 08:02:14 --> Total execution time: 0.1015
DEBUG - 2011-06-25 08:07:23 --> Config Class Initialized
DEBUG - 2011-06-25 08:07:23 --> Hooks Class Initialized
DEBUG - 2011-06-25 08:07:23 --> Utf8 Class Initialized
DEBUG - 2011-06-25 08:07:23 --> UTF-8 Support Enabled
DEBUG - 2011-06-25 08:07:23 --> URI Class Initialized
DEBUG - 2011-06-25 08:07:23 --> Router Class Initialized
DEBUG - 2011-06-25 08:07:23 --> Output Class Initialized
DEBUG - 2011-06-25 08:07:23 --> Input Class Initialized
DEBUG - 2011-06-25 08:07:23 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-25 08:07:23 --> Language Class Initialized
DEBUG - 2011-06-25 08:07:23 --> Loader Class Initialized
DEBUG - 2011-06-25 08:07:23 --> Controller Class Initialized
DEBUG - 2011-06-25 08:07:23 --> Model Class Initialized
DEBUG - 2011-06-25 08:07:23 --> Model Class Initialized
DEBUG - 2011-06-25 08:07:23 --> Model Class Initialized
DEBUG - 2011-06-25 08:07:23 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-25 08:07:23 --> Database Driver Class Initialized
DEBUG - 2011-06-25 08:07:23 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-25 08:07:23 --> Helper loaded: url_helper
DEBUG - 2011-06-25 08:07:23 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-25 08:07:23 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-25 08:07:23 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-25 08:07:23 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-25 08:07:23 --> Final output sent to browser
DEBUG - 2011-06-25 08:07:23 --> Total execution time: 0.1319
DEBUG - 2011-06-25 08:07:24 --> Config Class Initialized
DEBUG - 2011-06-25 08:07:24 --> Hooks Class Initialized
DEBUG - 2011-06-25 08:07:24 --> Utf8 Class Initialized
DEBUG - 2011-06-25 08:07:24 --> UTF-8 Support Enabled
DEBUG - 2011-06-25 08:07:24 --> URI Class Initialized
DEBUG - 2011-06-25 08:07:24 --> Router Class Initialized
DEBUG - 2011-06-25 08:07:24 --> Output Class Initialized
DEBUG - 2011-06-25 08:07:24 --> Input Class Initialized
DEBUG - 2011-06-25 08:07:24 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-25 08:07:24 --> Language Class Initialized
DEBUG - 2011-06-25 08:07:24 --> Loader Class Initialized
DEBUG - 2011-06-25 08:07:24 --> Controller Class Initialized
ERROR - 2011-06-25 08:07:24 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-25 08:07:24 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-25 08:07:24 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-25 08:07:24 --> Model Class Initialized
DEBUG - 2011-06-25 08:07:24 --> Model Class Initialized
DEBUG - 2011-06-25 08:07:24 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-25 08:07:24 --> Database Driver Class Initialized
DEBUG - 2011-06-25 08:07:24 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-25 08:07:24 --> Helper loaded: url_helper
DEBUG - 2011-06-25 08:07:24 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-25 08:07:24 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-25 08:07:24 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-25 08:07:24 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-25 08:07:24 --> Final output sent to browser
DEBUG - 2011-06-25 08:07:24 --> Total execution time: 0.0476
DEBUG - 2011-06-25 10:55:01 --> Config Class Initialized
DEBUG - 2011-06-25 10:55:01 --> Hooks Class Initialized
DEBUG - 2011-06-25 10:55:01 --> Utf8 Class Initialized
DEBUG - 2011-06-25 10:55:01 --> UTF-8 Support Enabled
DEBUG - 2011-06-25 10:55:01 --> URI Class Initialized
DEBUG - 2011-06-25 10:55:01 --> Router Class Initialized
DEBUG - 2011-06-25 10:55:01 --> No URI present. Default controller set.
DEBUG - 2011-06-25 10:55:01 --> Output Class Initialized
DEBUG - 2011-06-25 10:55:01 --> Input Class Initialized
DEBUG - 2011-06-25 10:55:01 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-25 10:55:01 --> Language Class Initialized
DEBUG - 2011-06-25 10:55:01 --> Loader Class Initialized
DEBUG - 2011-06-25 10:55:01 --> Controller Class Initialized
DEBUG - 2011-06-25 10:55:01 --> File loaded: application/views/splash/main.php
DEBUG - 2011-06-25 10:55:01 --> Helper loaded: url_helper
DEBUG - 2011-06-25 10:55:01 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-25 10:55:01 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-25 10:55:01 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-25 10:55:01 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-25 10:55:01 --> Final output sent to browser
DEBUG - 2011-06-25 10:55:01 --> Total execution time: 0.2045
DEBUG - 2011-06-25 13:45:49 --> Config Class Initialized
DEBUG - 2011-06-25 13:45:49 --> Hooks Class Initialized
DEBUG - 2011-06-25 13:45:49 --> Utf8 Class Initialized
DEBUG - 2011-06-25 13:45:49 --> UTF-8 Support Enabled
DEBUG - 2011-06-25 13:45:49 --> URI Class Initialized
DEBUG - 2011-06-25 13:45:49 --> Router Class Initialized
DEBUG - 2011-06-25 13:45:49 --> Output Class Initialized
DEBUG - 2011-06-25 13:45:49 --> Input Class Initialized
DEBUG - 2011-06-25 13:45:49 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-25 13:45:49 --> Language Class Initialized
DEBUG - 2011-06-25 13:45:49 --> Loader Class Initialized
DEBUG - 2011-06-25 13:45:49 --> Controller Class Initialized
ERROR - 2011-06-25 13:45:49 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-25 13:45:49 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-25 13:45:49 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-25 13:45:49 --> Model Class Initialized
DEBUG - 2011-06-25 13:45:49 --> Model Class Initialized
DEBUG - 2011-06-25 13:45:49 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-25 13:45:49 --> Database Driver Class Initialized
DEBUG - 2011-06-25 13:45:49 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-25 13:45:50 --> Helper loaded: url_helper
DEBUG - 2011-06-25 13:45:50 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-25 13:45:50 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-25 13:45:50 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-25 13:45:50 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-25 13:45:50 --> Final output sent to browser
DEBUG - 2011-06-25 13:45:50 --> Total execution time: 0.7883
DEBUG - 2011-06-25 13:45:50 --> Config Class Initialized
DEBUG - 2011-06-25 13:45:50 --> Hooks Class Initialized
DEBUG - 2011-06-25 13:45:50 --> Utf8 Class Initialized
DEBUG - 2011-06-25 13:45:50 --> UTF-8 Support Enabled
DEBUG - 2011-06-25 13:45:50 --> URI Class Initialized
DEBUG - 2011-06-25 13:45:50 --> Router Class Initialized
DEBUG - 2011-06-25 13:45:50 --> Output Class Initialized
DEBUG - 2011-06-25 13:45:50 --> Input Class Initialized
DEBUG - 2011-06-25 13:45:50 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-25 13:45:50 --> Language Class Initialized
DEBUG - 2011-06-25 13:45:50 --> Loader Class Initialized
DEBUG - 2011-06-25 13:45:50 --> Controller Class Initialized
DEBUG - 2011-06-25 13:45:50 --> Model Class Initialized
DEBUG - 2011-06-25 13:45:50 --> Model Class Initialized
DEBUG - 2011-06-25 13:45:50 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-25 13:45:50 --> Database Driver Class Initialized
DEBUG - 2011-06-25 13:45:51 --> Final output sent to browser
DEBUG - 2011-06-25 13:45:51 --> Total execution time: 0.7123
DEBUG - 2011-06-25 13:45:52 --> Config Class Initialized
DEBUG - 2011-06-25 13:45:52 --> Hooks Class Initialized
DEBUG - 2011-06-25 13:45:52 --> Utf8 Class Initialized
DEBUG - 2011-06-25 13:45:52 --> UTF-8 Support Enabled
DEBUG - 2011-06-25 13:45:52 --> URI Class Initialized
DEBUG - 2011-06-25 13:45:52 --> Router Class Initialized
ERROR - 2011-06-25 13:45:52 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-25 15:22:05 --> Config Class Initialized
DEBUG - 2011-06-25 15:22:05 --> Hooks Class Initialized
DEBUG - 2011-06-25 15:22:05 --> Utf8 Class Initialized
DEBUG - 2011-06-25 15:22:05 --> UTF-8 Support Enabled
DEBUG - 2011-06-25 15:22:05 --> URI Class Initialized
DEBUG - 2011-06-25 15:22:05 --> Router Class Initialized
ERROR - 2011-06-25 15:22:05 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-06-25 15:22:05 --> Config Class Initialized
DEBUG - 2011-06-25 15:22:05 --> Hooks Class Initialized
DEBUG - 2011-06-25 15:22:05 --> Utf8 Class Initialized
DEBUG - 2011-06-25 15:22:05 --> UTF-8 Support Enabled
DEBUG - 2011-06-25 15:22:05 --> URI Class Initialized
DEBUG - 2011-06-25 15:22:05 --> Router Class Initialized
DEBUG - 2011-06-25 15:22:05 --> Output Class Initialized
DEBUG - 2011-06-25 15:22:05 --> Input Class Initialized
DEBUG - 2011-06-25 15:22:05 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-25 15:22:05 --> Language Class Initialized
DEBUG - 2011-06-25 15:22:05 --> Loader Class Initialized
DEBUG - 2011-06-25 15:22:05 --> Controller Class Initialized
ERROR - 2011-06-25 15:22:05 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-25 15:22:05 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-25 15:22:05 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-25 15:22:05 --> Model Class Initialized
DEBUG - 2011-06-25 15:22:05 --> Model Class Initialized
DEBUG - 2011-06-25 15:22:05 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-25 15:22:05 --> Database Driver Class Initialized
DEBUG - 2011-06-25 15:22:05 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-25 15:22:05 --> Helper loaded: url_helper
DEBUG - 2011-06-25 15:22:05 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-25 15:22:05 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-25 15:22:05 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-25 15:22:05 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-25 15:22:05 --> Final output sent to browser
DEBUG - 2011-06-25 15:22:05 --> Total execution time: 0.3894
DEBUG - 2011-06-25 17:28:10 --> Config Class Initialized
DEBUG - 2011-06-25 17:28:10 --> Hooks Class Initialized
DEBUG - 2011-06-25 17:28:10 --> Utf8 Class Initialized
DEBUG - 2011-06-25 17:28:10 --> UTF-8 Support Enabled
DEBUG - 2011-06-25 17:28:10 --> URI Class Initialized
DEBUG - 2011-06-25 17:28:10 --> Router Class Initialized
DEBUG - 2011-06-25 17:28:10 --> Output Class Initialized
DEBUG - 2011-06-25 17:28:10 --> Input Class Initialized
DEBUG - 2011-06-25 17:28:10 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-25 17:28:10 --> Language Class Initialized
DEBUG - 2011-06-25 17:28:10 --> Loader Class Initialized
DEBUG - 2011-06-25 17:28:10 --> Controller Class Initialized
DEBUG - 2011-06-25 17:28:10 --> Model Class Initialized
DEBUG - 2011-06-25 17:28:10 --> Model Class Initialized
DEBUG - 2011-06-25 17:28:10 --> Model Class Initialized
DEBUG - 2011-06-25 17:28:10 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-25 17:28:10 --> Database Driver Class Initialized
DEBUG - 2011-06-25 17:28:11 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-25 17:28:11 --> Helper loaded: url_helper
DEBUG - 2011-06-25 17:28:11 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-25 17:28:11 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-25 17:28:11 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-25 17:28:11 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-25 17:28:11 --> Final output sent to browser
DEBUG - 2011-06-25 17:28:11 --> Total execution time: 0.6907
DEBUG - 2011-06-25 17:28:12 --> Config Class Initialized
DEBUG - 2011-06-25 17:28:12 --> Hooks Class Initialized
DEBUG - 2011-06-25 17:28:12 --> Utf8 Class Initialized
DEBUG - 2011-06-25 17:28:12 --> UTF-8 Support Enabled
DEBUG - 2011-06-25 17:28:12 --> URI Class Initialized
DEBUG - 2011-06-25 17:28:12 --> Router Class Initialized
DEBUG - 2011-06-25 17:28:12 --> Output Class Initialized
DEBUG - 2011-06-25 17:28:12 --> Input Class Initialized
DEBUG - 2011-06-25 17:28:12 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-25 17:28:12 --> Language Class Initialized
DEBUG - 2011-06-25 17:28:12 --> Loader Class Initialized
DEBUG - 2011-06-25 17:28:12 --> Controller Class Initialized
ERROR - 2011-06-25 17:28:12 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-25 17:28:12 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-25 17:28:12 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-25 17:28:12 --> Model Class Initialized
DEBUG - 2011-06-25 17:28:12 --> Model Class Initialized
DEBUG - 2011-06-25 17:28:12 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-25 17:28:12 --> Database Driver Class Initialized
DEBUG - 2011-06-25 17:28:12 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-25 17:28:12 --> Helper loaded: url_helper
DEBUG - 2011-06-25 17:28:12 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-25 17:28:12 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-25 17:28:12 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-25 17:28:12 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-25 17:28:12 --> Final output sent to browser
DEBUG - 2011-06-25 17:28:12 --> Total execution time: 0.0804
DEBUG - 2011-06-25 20:16:33 --> Config Class Initialized
DEBUG - 2011-06-25 20:16:33 --> Hooks Class Initialized
DEBUG - 2011-06-25 20:16:33 --> Utf8 Class Initialized
DEBUG - 2011-06-25 20:16:33 --> UTF-8 Support Enabled
DEBUG - 2011-06-25 20:16:33 --> URI Class Initialized
DEBUG - 2011-06-25 20:16:33 --> Router Class Initialized
ERROR - 2011-06-25 20:16:33 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-06-25 20:16:33 --> Config Class Initialized
DEBUG - 2011-06-25 20:16:33 --> Hooks Class Initialized
DEBUG - 2011-06-25 20:16:33 --> Utf8 Class Initialized
DEBUG - 2011-06-25 20:16:33 --> UTF-8 Support Enabled
DEBUG - 2011-06-25 20:16:33 --> URI Class Initialized
DEBUG - 2011-06-25 20:16:33 --> Router Class Initialized
DEBUG - 2011-06-25 20:16:33 --> No URI present. Default controller set.
DEBUG - 2011-06-25 20:16:33 --> Output Class Initialized
DEBUG - 2011-06-25 20:16:33 --> Input Class Initialized
DEBUG - 2011-06-25 20:16:33 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-25 20:16:33 --> Language Class Initialized
DEBUG - 2011-06-25 20:16:33 --> Loader Class Initialized
DEBUG - 2011-06-25 20:16:33 --> Controller Class Initialized
DEBUG - 2011-06-25 20:16:33 --> File loaded: application/views/splash/main.php
DEBUG - 2011-06-25 20:16:33 --> Helper loaded: url_helper
DEBUG - 2011-06-25 20:16:33 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-25 20:16:33 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-25 20:16:33 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-25 20:16:33 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-25 20:16:33 --> Final output sent to browser
DEBUG - 2011-06-25 20:16:33 --> Total execution time: 0.2149
DEBUG - 2011-06-25 22:28:05 --> Config Class Initialized
DEBUG - 2011-06-25 22:28:05 --> Hooks Class Initialized
DEBUG - 2011-06-25 22:28:05 --> Utf8 Class Initialized
DEBUG - 2011-06-25 22:28:05 --> UTF-8 Support Enabled
DEBUG - 2011-06-25 22:28:05 --> URI Class Initialized
DEBUG - 2011-06-25 22:28:05 --> Router Class Initialized
DEBUG - 2011-06-25 22:28:05 --> No URI present. Default controller set.
DEBUG - 2011-06-25 22:28:05 --> Output Class Initialized
DEBUG - 2011-06-25 22:28:05 --> Input Class Initialized
DEBUG - 2011-06-25 22:28:05 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-25 22:28:05 --> Language Class Initialized
DEBUG - 2011-06-25 22:28:05 --> Loader Class Initialized
DEBUG - 2011-06-25 22:28:05 --> Controller Class Initialized
DEBUG - 2011-06-25 22:28:05 --> File loaded: application/views/splash/main.php
DEBUG - 2011-06-25 22:28:05 --> Helper loaded: url_helper
DEBUG - 2011-06-25 22:28:05 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-25 22:28:05 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-25 22:28:05 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-25 22:28:05 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-25 22:28:05 --> Final output sent to browser
DEBUG - 2011-06-25 22:28:05 --> Total execution time: 0.1984
DEBUG - 2011-06-25 23:54:36 --> Config Class Initialized
DEBUG - 2011-06-25 23:54:36 --> Hooks Class Initialized
DEBUG - 2011-06-25 23:54:36 --> Utf8 Class Initialized
DEBUG - 2011-06-25 23:54:36 --> UTF-8 Support Enabled
DEBUG - 2011-06-25 23:54:36 --> URI Class Initialized
DEBUG - 2011-06-25 23:54:36 --> Router Class Initialized
DEBUG - 2011-06-25 23:54:36 --> Output Class Initialized
DEBUG - 2011-06-25 23:54:36 --> Input Class Initialized
DEBUG - 2011-06-25 23:54:36 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-25 23:54:36 --> Language Class Initialized
DEBUG - 2011-06-25 23:54:36 --> Loader Class Initialized
DEBUG - 2011-06-25 23:54:36 --> Controller Class Initialized
DEBUG - 2011-06-25 23:54:36 --> Model Class Initialized
DEBUG - 2011-06-25 23:54:36 --> Model Class Initialized
DEBUG - 2011-06-25 23:54:36 --> Model Class Initialized
DEBUG - 2011-06-25 23:54:36 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-25 23:54:36 --> Database Driver Class Initialized
DEBUG - 2011-06-25 23:54:36 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-25 23:54:36 --> Helper loaded: url_helper
DEBUG - 2011-06-25 23:54:36 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-25 23:54:36 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-25 23:54:36 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-25 23:54:36 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-25 23:54:36 --> Final output sent to browser
DEBUG - 2011-06-25 23:54:36 --> Total execution time: 0.5229
